"""Test change and dependency request mixin for SprintWrapup."""

from __future__ import annotations

import re
import subprocess
from typing import Any, TYPE_CHECKING

from rich.panel import Panel
from rich.prompt import Prompt

from odd.config import PHASE_TOKEN_DEFAULTS
from odd.models import CEOGate, CEOStyle
from odd.tools import SUBMIT_TEST_REVIEW_DECISION

from odd.sprint._console import console
from odd.tdd.test_infra import _resolve_argv

if TYPE_CHECKING:
    from odd.models import Persona, Sprint

# Validate package names before installation - reject anything that could
# inject flags or smuggle extra arguments into pip/npm.
_SAFE_PACKAGE_RE = re.compile(
    r"^[a-zA-Z0-9][a-zA-Z0-9._\-]*(\[[\w,]+\])?(([=<>!~]+[\w.*]+))?$"
)


class TestReviewMixin:
    """Test change requests and dependency installation methods."""

    # --- Test change requests ---

    def handle_test_change_requests(
        self,
        sprint: Sprint,
        team: dict[str, Persona],
        project_context: str,
        *,
        cwd=None,
    ) -> list[dict[str, Any]]:
        """Route test change requests to Vera and return structured outcomes."""
        requests = self.engine.pop_submissions("submit_test_change_request")

        if not requests:
            return []

        qa = team.get("qa")
        if not qa:
            console.print("[red]No QA agent available to review test change requests.[/red]")
            return []

        outcomes: list[dict[str, Any]] = []

        for req in requests:
            outcome = self.review_single_test_change(
                req["data"], qa, project_context, cwd=cwd,
            )
            outcomes.append(outcome)

        return outcomes

    def review_single_test_change(
        self,
        data: dict[str, Any],
        qa: Persona,
        project_context: str,
        *,
        cwd=None,
    ) -> dict[str, Any]:
        """Have Vera review a single test change request in adversarial mode."""
        from odd.provider import StreamEvent, StreamEventType

        console.print(Panel(
            f"**Test file**: {data['test_file']}\n\n"
            f"**Reason**: {data['reason']}\n\n"
            f"**Proposed change**: {data['proposed_change']}",
            title="Test Change Request \u2192 Vera",
            style="yellow",
        ))
        console.print(
            f"[yellow]\u26a0 CEO: An implementation agent has requested changes to "
            f"{data['test_file']}. Vera is reviewing.[/yellow]"
        )

        review_prompt = (
            f"\u26a0\ufe0f ADVERSARIAL REVIEW MODE \u26a0\ufe0f\n\n"
            f"An implementation agent wants to change YOUR tests. Treat this "
            f"request with maximum skepticism - the most common reason agents "
            f"request test changes is because their implementation is wrong, "
            f"not your tests.\n\n"
            f"**Test file**: {data['test_file']}\n"
            f"**Their claimed reason**: {data['reason']}\n"
            f"**Their proposed change**: {data['proposed_change']}\n\n"
            f"Your job:\n"
            f"1. Read the test file and the relevant implementation code.\n"
            f"2. Determine: is the TEST wrong, or is the IMPLEMENTATION wrong?\n"
            f"3. Check if the proposed change would reduce coverage or weaken "
            f"assertions (e.g. assertEqual \u2192 assertAlmostEqual, removing edge "
            f"case tests, loosening expected values).\n"
            f"4. Only modify the test if it has an actual defect (wrong expected "
            f"value, testing an obsolete interface, etc.).\n"
            f"5. If the test is correct, do NOT change it. Explain why the "
            f"implementation needs to conform to the test, not vice versa.\n\n"
            f"BIAS: When in doubt, keep the test as-is. The burden of proof is "
            f"on the implementation agent.\n\n"
            f"After your review, you MUST use the submit_test_review_decision "
            f"tool to formally record your verdict (accept or reject)."
        )

        # Build inline stream callback
        style = self._gate(CEOGate.STREAMING)
        stream_cb = None
        if style == CEOStyle.HANDS_ON:
            def _on_event(event: StreamEvent) -> None:
                if event.event_type == StreamEventType.TEXT_DELTA:
                    console.print(event.text, end="", highlight=False)
                elif event.event_type == StreamEventType.TOOL_USE_START:
                    console.print(
                        f"\n[dim]  \u21b3 {qa.name} \u2192 {event.tool_name}[/dim]",
                        highlight=False,
                    )
                elif event.event_type == StreamEventType.MESSAGE_STOP:
                    console.print()
            stream_cb = _on_event
        elif style == CEOStyle.BALANCED:
            def _on_summary(event: StreamEvent) -> None:
                if event.event_type == StreamEventType.TOOL_USE_START:
                    console.print(
                        f"[dim]  \u21b3 {qa.name} \u2192 {event.tool_name}[/dim]",
                        highlight=False,
                    )
            stream_cb = _on_summary

        self.engine.invoke(
            persona=qa,
            user_message=review_prompt,
            project_context=project_context,
            max_tokens=PHASE_TOKEN_DEFAULTS.get("qa", 16384),
            extra_tools=[SUBMIT_TEST_REVIEW_DECISION],
            stream=stream_cb,
            phase="review",
        )

        # Capture Vera's structured decision
        verdict_subs = self.engine.pop_submissions("submit_test_review_decision")

        if verdict_subs:
            decision = verdict_subs[0]["data"]
            verdict = decision.get("verdict", "reject")
            reason = decision.get("reason", "")
            test_file = decision.get("test_file", data["test_file"])
        else:
            verdict = "reject"
            reason = "No formal verdict submitted; defaulting to rejection."
            test_file = data["test_file"]

        tests_pass = False
        if verdict == "accept":
            tests_pass, _ = self.tdd.run_tests(cwd=cwd)
            status_msg = "tests passing" if tests_pass else "tests still failing"
            console.print(
                f"[green]Vera accepted the change to {test_file} "
                f"({status_msg}).[/green]"
            )
        else:
            console.print(
                f"[red]Vera rejected the change to {test_file}: {reason}[/red]"
            )

        return {
            "verdict": verdict,
            "reason": reason,
            "test_file": test_file,
            "tests_pass": tests_pass,
        }

    # --- Dependency requests ---

    def handle_dependency_requests(
        self,
        team: dict[str, Persona],
        project_context: str,
    ) -> None:
        """Route dependency requests to the CEO for approval."""
        requests = self.engine.pop_submissions("submit_dependency_request")

        if not requests:
            return

        # Flatten all dependency items from all requests
        all_deps: list[dict] = []
        for req in requests:
            all_deps.extend(req["data"].get("dependencies", []))

        if not all_deps:
            return

        # Present to CEO
        console.print(Panel(
            "[bold]Dependency Request[/bold]\n\n"
            "An agent needs the following dependencies installed:",
            style="yellow",
        ))

        for i, dep in enumerate(all_deps, 1):
            console.print(
                f"  [bold]{i}.[/bold] [cyan]{dep['package']}[/cyan] "
                f"({dep.get('ecosystem', 'pip')})\n"
                f"     {dep.get('description', '(no description)')}\n"
                f"     [dim]Why: {dep.get('reason', '(no reason given)')}[/dim]"
            )

        console.print()
        choice = Prompt.ask(
            "[bold yellow]CEO[/bold yellow]: Approve dependencies?",
            choices=["all", "none", "pick"],
            default="none",
        )

        approved: list[dict] = []
        if choice == "all":
            approved = list(all_deps)
        elif choice == "pick":
            for i, dep in enumerate(all_deps, 1):
                dep_choice = Prompt.ask(
                    f"  [{i}] {dep['package']} ({dep.get('ecosystem', 'pip')})?",
                    choices=["y", "n"],
                    default="n",
                )
                if dep_choice == "y":
                    approved.append(dep)

        if not approved:
            console.print("[yellow]No dependencies approved.[/yellow]")
            return

        # Cody installs approved dependencies
        lead_dev = team.get("lead_dev")
        if not lead_dev:
            console.print("[red]No lead dev available to install dependencies.[/red]")
            return

        for dep in approved:
            pkg = dep["package"]
            if not _SAFE_PACKAGE_RE.match(pkg):
                console.print(
                    f"[red]\u2717 Rejected '{pkg}' - invalid package name. "
                    f"Package names must be alphanumeric with hyphens/dots only. "
                    f"No flags, URLs, or special characters.[/red]"
                )
                return

        # Group by ecosystem
        pip_deps = [d["package"] for d in approved if d.get("ecosystem") == "pip"]
        npm_deps = [d["package"] for d in approved if d.get("ecosystem") == "npm"]

        # Build install commands as explicit argv lists
        install_jobs: list[tuple[str, list[str]]] = []
        if pip_deps:
            install_jobs.append(("pip", ["pip", "install"] + pip_deps))
        if npm_deps:
            install_jobs.append(("npm", ["npm", "install"] + npm_deps))

        any_failed = False
        succeeded_ecosystems: list[str] = []
        for label, argv in install_jobs:
            resolved = _resolve_argv(argv)
            console.print(f"[green]Installing ({label}): {' '.join(argv[2:])}[/green]")
            try:
                result = subprocess.run(
                    resolved,
                    shell=False,
                    capture_output=True,
                    text=True,
                    encoding="utf-8",
                    errors="replace",
                    timeout=120,
                    cwd=self.state.root,
                )
                if result.returncode == 0:
                    console.print(f"[green]\u2713 Installed successfully[/green]")
                    succeeded_ecosystems.append(label)
                else:
                    any_failed = True
                    console.print(
                        f"[red]\u2717 Installation failed:[/red]\n{result.stderr[:500]}"
                    )
            except FileNotFoundError:
                any_failed = True
                console.print(
                    f"[red]\u2717 Command not found: {argv[0]}. "
                    f"Is {label} installed on this machine?[/red]"
                )
            except subprocess.TimeoutExpired:
                any_failed = True
                console.print(f"[red]\u2717 Installation timed out[/red]")

        # Ensure ecosystem artifact dirs are gitignored
        if succeeded_ecosystems:
            from odd.git.gitignore import ensure_ecosystem_patterns

            for eco in succeeded_ecosystems:
                added = ensure_ecosystem_patterns(self.state.root, eco)
                if added:
                    console.print(
                        f"[green]Updated .gitignore: {', '.join(added)}[/green]"
                    )

        names = ", ".join(d["package"] for d in approved)
        if any_failed:
            console.print(
                f"[red]Some dependencies failed to install: {names}[/red]\n"
                f"[yellow]Agents may not be able to pass tests until this is resolved.[/yellow]"
            )
        else:
            console.print(f"[green]Dependencies installed: {names}[/green]")
