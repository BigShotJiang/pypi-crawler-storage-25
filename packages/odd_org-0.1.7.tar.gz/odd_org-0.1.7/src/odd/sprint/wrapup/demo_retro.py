"""Demo and retrospective mixin for SprintWrapup."""

from __future__ import annotations

from typing import TYPE_CHECKING

from rich.panel import Panel
from rich.markdown import Markdown

from odd.config import PHASE_TOKEN_DEFAULTS
from odd.models import CEOGate, CEOStyle, RoleType, SprintStatus

from odd.sprint._console import console

if TYPE_CHECKING:
    from odd.models import Persona, Sprint
    from odd.provider import StreamCallback


class DemoRetroMixin:
    """Demo presentation and retrospective methods."""

    # --- Demo ---

    def demo(self, sprint: Sprint, lead_dev: Persona) -> str:
        """Sprint demo: Lead dev presents what was built to the CEO."""
        from odd.provider import StreamEvent, StreamEventType

        project_context = self._build_project_context(sprint.number)

        # Feed Cody the diff summary so he can describe changes accurately.
        diff_context = ""
        diff_summary = self.git.get_sprint_diff_summary(sprint.number) if self.git.available else ""
        if diff_summary:
            diff_context = (
                f"\n\nHere's what changed in the codebase this sprint "
                f"(use this to inform your demo, but do NOT show raw diffs "
                f"to the CEO - explain in plain language):\n\n{diff_summary}\n"
            )

        demo_prompt = (
            f"Sprint {sprint.number} is complete. Prepare a demo for the CEO.\n\n"
            f"Sprint goal: {sprint.goal}\n\n"
            f"Summarize:\n"
            f"1. What was built\n"
            f"2. How it works (brief technical overview)\n"
            f"3. How the CEO can try it out\n"
            f"4. Any known issues or incomplete items\n"
            f"5. Suggested focus for next sprint\n\n"
            f"Run the test suite and include the results."
            f"{diff_context}"
        )

        sprint.status = SprintStatus.DEMO
        self.state.save_sprint(sprint)

        # Use inline streaming (no war room for demo)
        style = self._gate(CEOGate.STREAMING)
        stream_cb: StreamCallback | None = None
        if style == CEOStyle.HANDS_ON:
            def _on_event(event: StreamEvent) -> None:
                if event.event_type == StreamEventType.TEXT_DELTA:
                    console.print(event.text, end="", highlight=False)
                elif event.event_type == StreamEventType.TOOL_USE_START:
                    console.print(
                        f"\n[dim]  \u21b3 {lead_dev.name} \u2192 {event.tool_name}[/dim]",
                        highlight=False,
                    )
                elif event.event_type == StreamEventType.MESSAGE_STOP:
                    console.print()
            stream_cb = _on_event
        elif style == CEOStyle.BALANCED:
            def _on_summary_event(event: StreamEvent) -> None:
                if event.event_type == StreamEventType.TOOL_USE_START:
                    console.print(
                        f"[dim]  \u21b3 {lead_dev.name} \u2192 {event.tool_name}[/dim]",
                        highlight=False,
                    )
            stream_cb = _on_summary_event

        demo_result = self.engine.invoke(
            persona=lead_dev,
            user_message=demo_prompt,
            project_context=project_context,
            max_tokens=PHASE_TOKEN_DEFAULTS["demo"],
            stream=stream_cb,
            phase="demo",
        )

        return demo_result

    # --- Retro ---

    def run_retro(self, sprint: Sprint, secretary: Persona) -> str:
        """Secretary consolidates agent notes into a retro summary."""
        notes = self.state.load_sprint_notes(sprint.number)
        if not notes:
            return "No agent notes found for this sprint."

        notes_text = "\n\n---\n\n".join(
            f"**{name}:**\n{content}" for name, content in notes.items()
        )

        project_context = self._build_project_context(sprint.number)

        summary = self.engine.invoke(
            persona=secretary,
            user_message=(
                f"Sprint {sprint.number} is complete. Here are the notes each team "
                f"member wrote about their work:\n\n"
                f"{notes_text}\n\n"
                f"Produce a retrospective report:\n"
                f"1. **Key wins** - what went well\n"
                f"2. **Pain points** - what was difficult or went wrong\n"
                f"3. **Action items** - specific changes for next sprint\n"
                f"4. **Team health** - any concerns about workload, skill gaps, or process\n\n"
                f"Save this to .odd/notes/retro_sprint{sprint.number}.md"
            ),
            project_context=project_context,
            phase="demo",
        )

        return summary

    # --- Standup ---

    def run_standup_with_notes(
        self,
        prev_sprint: Sprint,
        team: dict[str, Persona],
        secretary: Persona,
        prev_notes: dict[str, str],
    ) -> str:
        """Run a standup where each agent gets their own notes from last sprint."""
        project_context = self._build_project_context(prev_sprint.number)
        reports: list[str] = []

        for role_name, persona in team.items():
            if persona.role_type == RoleType.SECRETARY:
                continue

            # Find this agent's notes from last sprint
            agent_slug = persona.name.lower().replace(" ", "_")
            my_notes = prev_notes.get(agent_slug, "")
            notes_context = ""
            if my_notes:
                notes_context = (
                    f"\n\nHere's what you noted at the end of last sprint:\n"
                    f"---\n{my_notes}\n---\n\n"
                )

            report = self.engine.invoke(
                persona=persona,
                user_message=(
                    f"It's standup time. Sprint {prev_sprint.number} is done and "
                    f"we're about to start the next one.{notes_context}"
                    f"Briefly report:\n"
                    f"1. What you accomplished\n"
                    f"2. Anything carrying over or unresolved\n"
                    f"3. Any concerns for the upcoming sprint\n\n"
                    f"Keep it concise."
                ),
                project_context=project_context,
                tools=False,
            )
            reports.append(f"**{persona.name}:**\n{report}")
            console.print(Panel(Markdown(report), title=persona.name, style="cyan"))

        # Secretary summarizes
        all_reports = "\n".join(reports)
        summary = self.engine.invoke(
            persona=secretary,
            user_message=(
                f"Here are the standup reports:\n\n{all_reports}\n\n"
                f"Produce a brief structured summary: key highlights, carryover items, "
                f"and anything the upcoming sprint should account for."
            ),
            project_context=project_context,
            tools=False,
        )

        return summary
