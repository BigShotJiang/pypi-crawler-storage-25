"""Hiring flow mixin for SprintWrapup."""

from __future__ import annotations

from typing import Any, TYPE_CHECKING

from rich.panel import Panel
from rich.prompt import Prompt

from odd.backlog import Backlog, Priority
from odd.labels import compensation_quip, model_tier_label, resolve_model_choice
from odd.models import CEOGate, CEOStyle, ModelTier, TaskStatus
from odd.parsers import parse_hire_suggestions
from odd.tools import SUBMIT_HIRE_SUGGESTION

from odd.sprint._console import console

if TYPE_CHECKING:
    from odd.models import Persona, Sprint


class HiringMixin:
    """Hiring suggestions and backlog sweep methods."""

    # --- Hiring ---

    def handle_hire_suggestions(
        self,
        lead_dev: Persona,
        secretary: Persona,
        retro_summary: str,
        team: dict[str, Persona],
    ) -> None:
        """Cody suggests hires based on the retro; CEO approves/rejects each."""
        hire_suggestions = self.suggest_hires(lead_dev, retro_summary, team)
        if not hire_suggestions:
            return

        from odd.roles import recruit_consultant
        from odd.processes import generate_onboarding_brief

        recruiter = team["recruiter"]
        for suggestion in hire_suggestions:
            final_model = self.approve_hire(suggestion)
            if final_model is None:
                continue

            desc = suggestion["description"]
            quip = compensation_quip(final_model)
            comp_note = f" \u2014 [dim italic]{quip}[/dim italic]" if quip else ""
            console.print(f"[bold]Recruiting ({model_tier_label(final_model)}){comp_note}...[/bold]")
            consultant = recruit_consultant(
                self.engine, recruiter, desc, model_tier=final_model,
            )

            # Persist Cody's reasoning so he remembers why this hire was made
            config = self.state.load_config()
            hire_reason = suggestion.get("reasoning") or desc
            consultant = consultant.model_copy(update={
                "hire_reason": hire_reason,
                "hired_sprint": config.current_sprint,
            })
            self.state.save_persona(consultant)
            console.print(f"[green]\u2713 {consultant.name} is on board![/green]")

            console.print(f"[dim]Generating onboarding brief for {consultant.name}...[/dim]")
            generate_onboarding_brief(
                self.engine, secretary, self.state,
                target_persona=consultant,
            )
            console.print(f"[green]\u2713 {consultant.name} onboarded.[/green]")

    def approve_hire(self, suggestion: dict[str, Any]) -> ModelTier | None:
        """Approve or reject a single hire suggestion based on CEO style."""
        desc = suggestion["description"]
        model = suggestion["model"]
        reasoning = suggestion["reasoning"]

        model_label = model_tier_label(ModelTier.from_name(model))
        reason_text = f" - {reasoning}" if reasoning else ""

        style = self._gate(CEOGate.HIRING)

        if style == CEOStyle.DELEGATOR:
            console.print(f"[dim]Auto-hiring: {desc} ({model_label}){reason_text}[/dim]")
            return ModelTier.from_name(model)

        if style == CEOStyle.BALANCED:
            console.print(
                f"\nCody suggests: [bold]{desc}[/bold] "
                f"({model_label}){reason_text}"
            )
            approve = Prompt.ask("Approve?", choices=["y", "n"], default="y")
            return ModelTier.from_name(model) if approve == "y" else None

        # HANDS_ON: full control - CEO picks model tier
        prompt_text = (
            f"\nCody suggests: [bold]{desc}[/bold] "
            f"({model_label}){reason_text}\n"
            f"Approve? [y/1=Premium/2=Standard/3=Fast/n]"
        )
        approve = Prompt.ask(
            prompt_text,
            choices=["y", "1", "2", "3", "n"],
            default="n",
        )
        if approve == "n":
            return None
        if approve == "y":
            return ModelTier.from_name(model)
        ceo_tier = ModelTier.from_name(resolve_model_choice(approve))
        cody_tier = ModelTier.from_name(model)
        if ceo_tier != cody_tier:
            quip = compensation_quip(ceo_tier, old_tier=cody_tier)
            if quip:
                console.print(f"  [dim italic]{quip}[/dim italic]")
        return ceo_tier

    def suggest_hires(
        self,
        lead_dev: Persona,
        retro_summary: str,
        team: dict[str, Persona],
    ) -> list[dict[str, str]]:
        """Cody analyzes skill gaps and suggests hires."""
        roster = "\n".join(
            f"  - {p.name}: {p.title}" for p in team.values()
        )

        response = self.engine.invoke(
            persona=lead_dev,
            user_message=(
                f"Sprint retrospective summary:\n{retro_summary}\n\n"
                f"Current team:\n{roster}\n\n"
                f"Based on this sprint, are there any genuine skill gaps on the team "
                f"that slowed us down or produced lower quality work? Only suggest a "
                f"hire if there's a specific, concrete gap - not a nice-to-have.\n\n"
                f"For each suggestion, also recommend a model tier based on the "
                f"complexity of work they'll do:\n"
                f"  - opus: deep reasoning, architecture, complex design\n"
                f"  - sonnet: solid implementation, standard engineering tasks\n"
                f"  - haiku: simple/repetitive tasks, boilerplate, formatting\n\n"
                f"Use the submit_hire_suggestion tool to submit your suggestions "
                f"(pass an empty suggestions array if no hires are needed).\n\n"
                f"Fallback format (if you can't use the tool):\n"
                f"HIRE: <specific expertise description>\n"
                f"MODEL: <opus|sonnet|haiku> - <one-line reasoning>\n\n"
                f"If no hires are needed, just say NONE."
            ),
            tools=False,
            extra_tools=[SUBMIT_HIRE_SUGGESTION],
            phase="demo",
        )

        # Check for structured submission, fall back to string parsing
        hire_subs = self.engine.pop_submissions("submit_hire_suggestion")
        structured = hire_subs[0]["data"] if hire_subs else None

        if structured is not None:
            return parse_hire_suggestions(response, structured_data=structured)

        if "NONE" in response.upper() and "HIRE:" not in response.upper():
            return []

        return parse_hire_suggestions(response)

    # --- Backlog ---

    def sweep_to_backlog(self, sprint: Sprint) -> list[str]:
        """Move failed tasks to backlog, complete matched items."""
        backlog = Backlog(self.state.odd_dir)
        messages: list[str] = []

        for task in sprint.tasks:
            if task.status == TaskStatus.FAILED:
                item = backlog.add(
                    description=f"[From Sprint {sprint.number}] {task.description}",
                    priority=Priority.HIGH,
                    added_by="system",
                )
                messages.append(f"Failed task \u2192 backlog: {task.description}")

        # Mark backlog items assigned to this sprint as done
        for item in backlog.sprint_items(sprint.number):
            if item.status == "in_sprint":
                item.status = "done"
        backlog.save()

        completed = len([t for t in sprint.tasks if t.status == TaskStatus.DONE])
        failed = len([t for t in sprint.tasks if t.status == TaskStatus.FAILED])
        if completed:
            messages.insert(0, f"{completed} task(s) completed")
        if failed:
            messages.append(f"{failed} task(s) moved to backlog")

        return messages
