"""Sprint wrapup collaborator.

Owns the post-implementation lifecycle: demo, retro, ship/scrap,
changelog, backlog sweep, hiring suggestions, test change reviews,
and dependency requests. Declares its dependencies explicitly via
__init__ and is independently testable.
"""

from __future__ import annotations

import datetime
from typing import Callable, TYPE_CHECKING

from rich.panel import Panel
from rich.markdown import Markdown
from rich.prompt import Prompt

from odd.config import PHASE_TOKEN_DEFAULTS
from odd.git import MergeConflictError
from odd.models import (
    CEOGate,
    CEOStyle,
    SprintCheckpoint,
    SprintStatus,
    TaskStatus,
)
from odd.review import offer_code_review, run_code_review

from odd.sprint._console import console
from odd.sprint.wrapup.demo_retro import DemoRetroMixin
from odd.sprint.wrapup.hiring import HiringMixin
from odd.sprint.wrapup.test_review import TestReviewMixin

if TYPE_CHECKING:
    from odd.agent import AgentEngine
    from odd.git import GitManager
    from odd.models import Persona, Sprint
    from odd.provider import StreamCallback
    from odd.state import StateManager
    from odd.tdd.gate import TDDGate


class SprintWrapup(DemoRetroMixin, HiringMixin, TestReviewMixin):
    """Post-implementation lifecycle: demo, retro, ship, changelog, hiring.

    Each dependency is declared explicitly so the wrapup can be tested
    without constructing a full SprintEngine.
    """

    def __init__(
        self,
        state: StateManager,
        engine: AgentEngine,
        get_git: Callable[[], GitManager],
        tdd: TDDGate,
        gate: Callable[[CEOGate], CEOStyle],
        build_project_context: Callable[[int], str],
        get_phase_diff_stat: Callable[[int], str],
    ):
        self.state = state
        self.engine = engine
        self._get_git = get_git
        self.tdd = tdd
        self._gate = gate
        self._build_project_context = build_project_context
        self._get_phase_diff_stat = get_phase_diff_stat

    @property
    def git(self) -> GitManager:
        return self._get_git()

    # --- Changelog & metrics ---

    def write_changelog_entry(self, sprint: Sprint) -> None:
        """Append a mechanical changelog entry for this sprint.

        Pure data - no LLM calls, no agent involvement. Built from sprint
        metadata, task statuses, git diff stats, and test results.
        """
        done = [t for t in sprint.tasks if t.status == TaskStatus.DONE]
        failed = [t for t in sprint.tasks if t.status == TaskStatus.FAILED]

        lines: list[str] = []
        date_str = datetime.date.today().isoformat()
        lines.append(f"## Sprint {sprint.number} - {date_str}")
        lines.append(f"**Goal:** {sprint.goal}")

        if done:
            lines.append("")
            lines.append("### Completed")
            for t in done:
                lines.append(f"- {t.id}: {t.description}")

        if failed:
            lines.append("")
            lines.append("### Failed")
            for t in failed:
                lines.append(f"- {t.id}: {t.description}")

        # Git diff stat
        diff_stat = self._get_phase_diff_stat(sprint.number)
        if diff_stat:
            # Extract just the summary line (e.g. "5 files changed, 120 insertions(+)")
            stat_lines = diff_stat.strip().splitlines()
            summary_line = stat_lines[-1] if stat_lines else ""
            if summary_line:
                lines.append("")
                lines.append(f"**Changes:** {summary_line.strip()}")

        # Test status derived from task outcomes (tests already ran during TDD)
        total_tasks = len(sprint.tasks)
        done_count = len(done)
        failed_count = len(failed)
        if total_tasks > 0:
            status = "passing" if failed_count == 0 else "failing"
            lines.append(f"**Tests ({status}):** {done_count}/{total_tasks} tasks passed")

        lines.append("")  # trailing newline

        entry = "\n".join(lines) + "\n"

        # Prepend to CHANGELOG.md (newest first)
        changelog_path = self.state.root / "CHANGELOG.md"
        existing = ""
        if changelog_path.exists():
            existing = changelog_path.read_text(encoding="utf-8")

        if existing:
            changelog_path.write_text(entry + "\n" + existing, encoding="utf-8")
        else:
            header = "# Changelog\n\n"
            changelog_path.write_text(header + entry, encoding="utf-8")

        console.print(f"[dim]Changelog updated - Sprint {sprint.number}[/dim]")

    def show_running_costs(self, label: str) -> None:
        """Show per-agent cost breakdown at a milestone during the sprint."""
        cfo = self.engine.cfo
        if not cfo or not cfo.has_session_activity():
            return
        by_agent = cfo.session_cost_by_agent()
        parts = [f"{agent}: ${cost:.4f}" for agent, cost in sorted(by_agent.items(), key=lambda x: -x[1])]
        total = cfo.session_cost()
        sep = " \u00b7 "
        console.print(
            f"[dim]  \U0001f4ca {label} - ${total:.4f} total | {sep.join(parts)}[/dim]"
        )

    def show_sprint_performance(self, sprint: Sprint) -> None:
        """Show a performance snapshot for consultants who worked this sprint."""
        records = self.state.all_consultant_records()
        # Filter to consultants who have outcomes in this sprint
        sprint_records = {
            name: record for name, record in records.items()
            if any(o.sprint_number == sprint.number for o in record.outcomes)
        }
        if not sprint_records:
            return

        lines = []
        for name, record in sprint_records.items():
            sprint_outcomes = [o for o in record.outcomes if o.sprint_number == sprint.number]
            first_try = sum(1 for o in sprint_outcomes if o.passed and o.retries == 0)
            total = len(sprint_outcomes)
            retries = sum(o.retries for o in sprint_outcomes)
            failed = sum(1 for o in sprint_outcomes if not o.passed)

            parts = [f"  {name}:"]
            if first_try == total and total > 0:
                parts.append(f"tests passed first try \u2713")
            else:
                parts.append(f"{first_try}/{total} first try")
            if retries:
                parts.append(f"{retries} {'retry' if retries == 1 else 'retries'}")
            if failed:
                parts.append(f"{failed} unresolved")
            lines.append("  |  ".join(parts))

        console.print(Panel(
            "\n".join(lines),
            title=f"Sprint {sprint.number} - Performance",
            style="cyan",
        ))

    # --- Core post-implementation orchestration ---

    def post_implementation(
        self,
        sprint: Sprint,
        team: dict[str, Persona],
        sprint_number: int,
    ) -> None:
        """Post-implementation phase: review -> demo -> ship -> changelog -> retro -> backlog -> hiring."""
        lead_dev = team["lead_dev"]
        secretary = team["secretary"]
        project_context = self._build_project_context(sprint_number)

        self.maybe_run_code_review(sprint, lead_dev, sprint_number, project_context)

        # Checkpoint after review so a crash during demo can resume here.
        sprint.checkpoint = SprintCheckpoint(
            stage="review",
            completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            completed_task_ids=[t.id for t in sprint.tasks if t.status == TaskStatus.DONE],
        )
        self.state.save_sprint(sprint)

        # --- Demo ---
        console.print(Panel("Sprint complete! Preparing demo...", style="bold blue"))
        demo_text = self.demo(sprint, lead_dev)
        console.print(Panel(
            Markdown(demo_text),
            title=f"Sprint {sprint_number} Demo",
            style="bold green",
        ))

        # --- Performance snapshot ---
        self.show_sprint_performance(sprint)

        # --- CFO report ---
        if self.engine.cfo:
            console.print(Panel(
                Markdown(self.engine.cfo.sprint_report(sprint_number)),
                title="Bill the CFO - Sprint Costs",
                style="yellow",
            ))

        # --- Changelog (mechanical - no agents, before ship so it's in the merge) ---
        self.write_changelog_entry(sprint)

        # --- Ship / scrap ---
        self.ship_or_scrap(sprint_number, lead_dev)

        # --- CEO feedback ---
        console.print("\nWhat do you think? (Your feedback shapes what's next)")
        feedback = Prompt.ask("[bold yellow]CEO[/bold yellow]")

        # --- Retro (secretary consolidates real agent notes) ---
        console.print(Panel("Running retrospective...", style="cyan"))
        retro_summary = self.run_retro(sprint, secretary)
        console.print(Panel(
            Markdown(retro_summary),
            title=f"Retrospective - Sprint {sprint_number}",
            style="cyan",
        ))

        # --- Backlog sweep ---
        swept = self.sweep_to_backlog(sprint)
        if swept:
            console.print(Panel(
                "\n".join(f"  \u2022 {s}" for s in swept),
                title="Backlog Updated",
                style="yellow",
            ))

        # --- Hiring suggestions ---
        self.handle_hire_suggestions(lead_dev, secretary, retro_summary, team)

    # --- Code review ---

    def maybe_run_code_review(
        self,
        sprint: Sprint,
        lead_dev: Persona,
        sprint_number: int,
        project_context: str,
    ) -> None:
        """Run code review if CEO style and pass count warrant it."""
        from odd.config import CODE_REVIEW_THRESHOLD

        is_milestone = False
        if self.state.has_active_roadmap():
            roadmap = self.state.load_roadmap()
            for rs in roadmap.sprints:
                if rs.number == sprint_number and rs.is_milestone:
                    is_milestone = True
                    break
        review_passes = offer_code_review(
            self.state, sprint_number, lead_dev,
            ceo_style=self._gate(CEOGate.CODE_REVIEW), is_milestone=is_milestone,
        )
        if review_passes <= 0:
            return

        console.print(Panel(f"Running {review_passes}-pass code review...", style="magenta"))
        review = run_code_review(
            self.engine, self.state, self.git,
            sprint, lead_dev, review_passes, project_context,
        )
        if review.final_score is not None:
            score_style = "green" if review.final_score >= CODE_REVIEW_THRESHOLD else "yellow"
            console.print(Panel(
                f"Final score: [{score_style}]{review.final_score}/10[/{score_style}] "
                f"({len(review.passes)} pass{'es' if len(review.passes) != 1 else ''})",
                title="Code Review Complete",
                style="magenta",
            ))

    # --- Ship / scrap ---

    def ship_or_scrap(self, sprint_number: int, lead_dev: Persona) -> None:
        """CEO decides whether to merge or abandon the sprint branch."""
        if self._gate(CEOGate.SHIP_APPROVAL) == CEOStyle.DELEGATOR:
            ship_it = "y"
        else:
            ship_it = Prompt.ask(
                "\n[bold]Ship it?[/bold]",
                choices=["y", "n"],
                default="y",
            )

        if ship_it == "y":
            merge_status = self.merge_sprint_branch(sprint_number, lead_dev)
            if merge_status == "merged":
                console.print("[green]Shipped.[/green]")
            elif merge_status == "deferred":
                console.print(
                    "[yellow]Work preserved on sprint branch - "
                    "merge deferred to next sprint.[/yellow]"
                )
            else:
                console.print("[yellow]No git repo - changes are already on disk.[/yellow]")
        else:
            self.git.abandon_sprint(sprint_number)
            console.print("[yellow]Sprint work shelved. Main branch untouched.[/yellow]")

    # --- Git merge ---

    def merge_sprint_branch(
        self,
        sprint_number: int,
        lead_dev: Persona,
    ) -> str:
        """Merge the sprint branch into main. Handles conflicts internally.

        Returns:
            "merged"   - merge succeeded, code is on main.
            "deferred" - merge failed, work preserved on sprint branch.
            "no_git"   - git unavailable, no-op.
        """
        if not self.git.available:
            return "no_git"

        try:
            self.git.merge_sprint(sprint_number)
            return "merged"
        except MergeConflictError as e:
            console.print(Panel(
                "Team is resolving a technical issue...",
                style="dim",
            ))

            # Let Cody resolve the conflicts
            project_context = self._build_project_context(sprint_number)
            conflict_files = "\n".join(f"  - {f}" for f in e.conflicting_files)

            self.engine.invoke(
                persona=lead_dev,
                user_message=(
                    f"There are merge conflicts in the following files:\n"
                    f"{conflict_files}\n\n"
                    f"Resolve each conflict by reading the file, choosing the "
                    f"correct version (or combining both), and editing the file "
                    f"to remove all conflict markers (<<<<<<, ======, >>>>>>).\n\n"
                    f"After resolving all conflicts, verify the code still works."
                ),
                project_context=project_context,
                phase="review",
            )

            # Try to complete the merge
            if self.git.resolve_conflicts_and_commit(sprint_number):
                return "merged"

            # If still broken, escalate to CEO
            self.git.abort_merge()
            self.git.ensure_on_sprint_branch(sprint_number)
            console.print(Panel(
                "[bold red]The team couldn't resolve a merge issue automatically.[/bold red]\n"
                "Your sprint work is preserved on a separate branch.\n"
                "The team will address this in the next sprint.",
                style="red",
            ))
            return "deferred"
