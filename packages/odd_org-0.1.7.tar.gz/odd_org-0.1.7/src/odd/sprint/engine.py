"""Sprint cycle engine - orchestrates the agile process.

SprintEngine is a thin orchestrator that wires collaborator objects together
and drives the sprint lifecycle (run_sprint, run_full_sprint, resume_sprint).

Collaborators (each independently testable):
- briefing.py      - SprintBriefing accumulator
- planner.py       - SprintPlanner (roadmap / sprint / phase planning)
- tdd_gate.py      - TDDGate (test/retry loop, escalations)
- phase_runner.py  - PhaseRunner (parallel worktree execution)
- wrapup.py        - SprintWrapup (demo, retro, ship, hire)
- context.py       - SprintContext (project context, ecosystem, agent resolution)
- vacation_runner.py - VacationRunner (autonomous vacation lifecycle)
"""

from __future__ import annotations

import datetime
import subprocess
from collections.abc import Generator
from contextlib import contextmanager
from typing import Callable

from rich.panel import Panel
from rich.markdown import Markdown

from odd.agent import AgentEngine
from odd.config import GIT_COMMAND_TIMEOUT
from odd.display import AgentOutputStream
from odd.provider import StreamCallback
from odd.git import GitManager
from odd.models import (
    CEOGate,
    CEOStyle,
    Persona,
    ProjectConfig,
    Sprint,
    SprintCheckpoint,
    SprintStatus,
    TaskStatus,
)
from odd.state import StateManager
from odd.sprint._console import console
from odd.sprint.callbacks import (
    make_stream_callback,
    make_war_room_callback,
    make_tool_result_callback,
    war_room_context,
)
from odd.sprint.context import SprintContext
from odd.sprint.execution import SprintExecutor
from odd.sprint.standup import run_standup as _standalone_run_standup

from odd.sprint.briefing import SprintBriefing
from odd.tdd import TDDGate
from odd.sprint.phase_runner import PhaseRunner
from odd.sprint.planner import SprintPlanner
from odd.sprint.wrapup import SprintWrapup
from odd.sprint.vacation_runner import VacationRunner


class SprintEngine:
    """Manages the lifecycle of a sprint."""

    def __init__(
        self,
        engine: AgentEngine,
        state: StateManager,
        git: GitManager | None = None,
        streaming: bool = True,
    ):
        self.engine = engine
        self.state = state
        self.git = git or GitManager(state.root)
        self.streaming = streaming
        # Load config for CEO style resolution (default + per-gate overrides)
        try:
            self._config: ProjectConfig = state.load_config()
        except Exception:
            self._config = ProjectConfig(name="fallback", ceo_style=CEOStyle.BALANCED)

        # Collaborators
        self.context = SprintContext(state=state, git=self.git)
        self.tdd = TDDGate(state=state, gate=self.gate, main_engine=engine)
        self.phase_runner = PhaseRunner(
            git=self.git,
            engine=engine,
            tdd=self.tdd,
            gate=self.gate,
            streaming=streaming,
            resolve_agent=self.context.resolve_agent,
            build_phase_context=self.context.build_phase_context,
            make_war_room_callback=self._make_war_room_callback,
            make_tool_result_callback=self._make_tool_result_callback,
        )
        self.planner = SprintPlanner(
            state=state,
            engine=engine,
            build_project_context=self.context.build_project_context,
        )
        self.wrapup = SprintWrapup(
            state=state,
            engine=engine,
            get_git=lambda: self.git,
            tdd=self.tdd,
            gate=self.gate,
            build_project_context=self.context.build_project_context,
            get_phase_diff_stat=self._get_phase_diff_stat,
        )
        self.executor = SprintExecutor(
            engine=engine,
            state=state,
            git=self.git,
            tdd=self.tdd,
            phase_runner=self.phase_runner,
            planner=self.planner,
            wrapup=self.wrapup,
            context=self.context,
            make_stream_callback=self._make_stream_callback,
            make_war_room_callback=self._make_war_room_callback,
            make_tool_result_callback=self._make_tool_result_callback,
            war_room_context=self._war_room_context,
            get_phase_diff_stat=self._get_phase_diff_stat,
        )
        self.vacation = VacationRunner(
            state=state,
            engine=engine,
            git=self.git,
            planner=self.planner,
            wrapup=self.wrapup,
            build_project_context=self.context.build_project_context,
            run_sprint=self.run_sprint,
        )

    def gate(self, g: CEOGate) -> CEOStyle:
        """Resolve effective CEO style for a specific decision gate."""
        return self._config.style_at(g)

    # --- Streaming helpers ---

    def _make_stream_callback(self, agent_name: str) -> StreamCallback | None:
        """Build a Rich-based streaming callback for an agent, or None if disabled."""
        return make_stream_callback(
            agent_name, self.gate(CEOGate.STREAMING), self.streaming,
        )

    def _make_war_room_callback(
        self, stream: AgentOutputStream,
    ) -> StreamCallback | None:
        """Build a StreamCallback that feeds into an AgentOutputStream."""
        return make_war_room_callback(stream, self.gate(CEOGate.WAR_ROOM))

    def _make_tool_result_callback(
        self, stream: AgentOutputStream | None,
    ) -> Callable[[str, dict, str], None] | None:
        """Build an on_tool_result callback that feeds the War Room."""
        return make_tool_result_callback(stream, self.gate(CEOGate.WAR_ROOM))

    @contextmanager
    def _war_room_context(
        self, agent_names: list[str],
    ) -> Generator[dict[str, AgentOutputStream], None, None]:
        """Context manager that starts/stops a War Room for the given agents."""
        with war_room_context(
            self.streaming, self.gate(CEOGate.WAR_ROOM), agent_names,
        ) as streams:
            yield streams

    # --- Git utilities ---

    def _get_diff_stat(self) -> str:
        """Get git diff --stat for recent uncommitted + committed changes."""
        if not self.git.available:
            return ""
        try:
            result = subprocess.run(
                ["git", "diff", "--stat", "HEAD"],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=GIT_COMMAND_TIMEOUT,
                cwd=self.state.root,
            )
            return result.stdout.strip() if result.returncode == 0 else ""
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return ""

    def _get_phase_diff_stat(self, sprint_number: int) -> str:
        """Get git diff --stat for all changes on the sprint branch vs main."""
        if not self.git.available:
            return ""
        return self.git.get_sprint_diff_summary(sprint_number)

    # --- Core sprint lifecycle ---

    def run_sprint(
        self,
        sprint: Sprint,
        team: dict[str, Persona],
    ) -> Sprint:
        """Execute the sprint: QA writes tests (overlapping with phase planning),
        then phases execute sequentially with parallel tasks within each phase.
        """
        sprint.status = SprintStatus.IN_PROGRESS
        self.context.reset_cache()
        project_context = self.context.build_project_context(sprint.number)
        notes_path = f".odd/sprints/sprint_{sprint.number}/notes"
        briefing = SprintBriefing(sprint.number, sprint.goal)

        sprint, test_context = self.executor.run_qa_phase(
            sprint, team, project_context, notes_path, briefing,
        )

        sprint.checkpoint = SprintCheckpoint(
            stage="qa",
            completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            completed_task_ids=[],
            test_context=test_context,
        )
        self.state.save_sprint(sprint)

        self.executor.run_implementation_phases(
            sprint, team, project_context, notes_path, test_context, briefing,
        )

        sprint.status = SprintStatus.REVIEW
        self.state.save_sprint(sprint)
        return sprint

    def resume_sprint(
        self,
        sprint: Sprint,
        team: dict[str, Persona],
    ) -> Sprint:
        """Resume a sprint from its last checkpoint."""
        checkpoint = sprint.checkpoint
        if not checkpoint:
            return self.run_sprint(sprint, team)

        # Planning done but QA hasn't run yet - restart from QA onward.
        if checkpoint.stage == "planning":
            return self.run_sprint(sprint, team)

        # Review already done - nothing left for resume to do.
        if checkpoint.stage == "review":
            sprint.status = SprintStatus.REVIEW
            self.state.save_sprint(sprint)
            return sprint

        sprint.status = SprintStatus.IN_PROGRESS
        self.context.reset_cache()
        project_context = self.context.build_project_context(sprint.number)
        notes_path = f".odd/sprints/sprint_{sprint.number}/notes"
        briefing = SprintBriefing(sprint.number, sprint.goal)
        briefing.after_planning(sprint.tasks, sprint.phases)

        test_context = checkpoint.test_context or ""
        if not test_context:
            test_files = self.tdd.discover_test_files()
            test_names = self.tdd.collect_test_names()
            _, test_output = self.tdd.run_tests()
            if test_files:
                test_context = (
                    f"\n\nQA has written these test files:\n"
                    + "\n".join(f"  - {f}" for f in test_files)
                )
                if test_names:
                    test_context += "\n\nTest names (via pytest --collect-only):\n"
                    test_context += "\n".join(f"  - {n}" for n in test_names)
                test_context += f"\n\nBaseline test output:\n```\n{test_output[:2000]}\n```"

        # Restore task statuses from checkpoint
        if checkpoint.task_results:
            task_map = {t.id: t for t in sprint.tasks}
            for tr in checkpoint.task_results:
                if tr.task_id in task_map:
                    try:
                        task_map[tr.task_id].status = TaskStatus(tr.status)
                    except ValueError:
                        pass

        completed_phase_nums: set[int] = set()
        if checkpoint.stage.startswith("phase_"):
            try:
                last_done = int(checkpoint.stage.split("_", 1)[1])
                completed_phase_nums = set(range(1, last_done + 1))
            except (ValueError, IndexError):
                pass

        # Keep the current phase if it has incomplete tasks (task-level resume)
        completed_ids = set(checkpoint.completed_task_ids)
        current_phase_num = None
        if checkpoint.stage.startswith("phase_"):
            try:
                current_phase_num = int(checkpoint.stage.split("_", 1)[1])
            except (ValueError, IndexError):
                pass

        remaining_phases = []
        for p in sprint.phases:
            if p.number in completed_phase_nums:
                # Check if this phase has incomplete tasks (partial completion)
                if p.number == current_phase_num:
                    remaining_task_ids = [tid for tid in p.task_ids if tid not in completed_ids]
                    if remaining_task_ids:
                        remaining_phases.append(p)
                continue
            remaining_phases.append(p)

        if remaining_phases:
            console.print(Panel(
                f"[bold]Resuming Sprint {sprint.number}[/bold]\n"
                f"Skipping {len(completed_phase_nums)} completed phase(s), "
                f"{len(remaining_phases)} remaining.",
                style="bold green",
            ))
            self.executor.run_implementation_phases_subset(
                sprint, team, project_context, notes_path,
                test_context, briefing, remaining_phases,
            )

        sprint.status = SprintStatus.REVIEW
        self.state.save_sprint(sprint)
        return sprint

    # --- Standup ---

    def run_standup(self, sprint):
        """Mechanical sprint status dashboard - no LLM calls."""
        return _standalone_run_standup(
            sprint=sprint,
            run_tests=self.tdd.run_tests,
            get_phase_diff_stat=self._get_phase_diff_stat,
        )

    # --- Full sprint lifecycle ---

    def run_full_sprint(self, team, ceo_goal, sprint_number):
        """Full sprint lifecycle."""
        config = self.state.load_config()
        lead_dev = team["lead_dev"]
        qa = team["qa"]
        secretary = team["secretary"]

        # --- Standup (skip sprint 1) ---
        if sprint_number > 1:
            try:
                prev_sprint = self.state.load_sprint(sprint_number - 1)
                console.print(Panel(
                    f"[bold]Standup - catching up from Sprint {sprint_number - 1}[/bold]",
                    style="cyan",
                ))
                prev_notes = self.state.load_sprint_notes(sprint_number - 1)
                standup_summary = self.wrapup.run_standup_with_notes(
                    prev_sprint, team, secretary, prev_notes,
                )
                console.print(Panel(
                    Markdown(standup_summary), title="Standup Summary", style="cyan",
                ))
            except FileNotFoundError:
                pass

        # --- Plan ---
        sprint = self.planner.plan_sprint(
            lead_dev=lead_dev, qa=qa,
            ceo_input=ceo_goal, sprint_number=sprint_number,
        )
        self.wrapup.show_running_costs("After planning")

        # Show the plan to the CEO
        if sprint.tasks:
            task_lines = "\n".join(
                f"  {i}. {t.description} → {t.assigned_to}"
                for i, t in enumerate(sprint.tasks, 1)
            )
            console.print(Panel(
                task_lines,
                title=f"Sprint {sprint_number} Plan ({len(sprint.tasks)} tasks)",
                style="blue",
            ))

        # --- CEO approves plan ---
        # Access Prompt through the package so test patches on
        # "odd.sprint.Prompt" take effect.
        import odd.sprint as _sprint_pkg
        _Prompt = _sprint_pkg.Prompt

        if self.gate(CEOGate.PLAN_APPROVAL) == CEOStyle.DELEGATOR:
            console.print("[dim]Auto-proceeding with plan (delegator mode).[/dim]")
        else:
            proceed = _Prompt.ask(
                "\nProceed with this plan?",
                choices=["y", "n", "revise"], default="y",
            )
            if proceed == "n":
                console.print("[yellow]Sprint cancelled.[/yellow]")
                return sprint
            if proceed == "revise":
                revision = _Prompt.ask("[bold yellow]CEO[/bold yellow] What would you like changed?")
                sprint = self.planner.plan_sprint(
                    lead_dev=lead_dev, qa=qa,
                    ceo_input=f"{ceo_goal}\n\nCEO revision: {revision}",
                    sprint_number=sprint_number,
                )

        # --- Silent branch creation ---
        self.git.create_sprint_branch(sprint_number)

        # Checkpoint after planning so a crash during QA can resume here.
        sprint.checkpoint = SprintCheckpoint(
            stage="planning",
            completed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            completed_task_ids=[],
        )
        self.state.save_sprint(sprint)

        # --- Pre-flight: ensure test runner is available ---
        if not self.tdd.preflight_test_runner():
            console.print("[yellow]Sprint cancelled — test runner not available.[/yellow]")
            return sprint

        try:
            console.print(Panel("Sprint is underway!", style="bold green"))
            sprint = self.run_sprint(sprint, team)
            self.wrapup.show_running_costs("After implementation")

            self.wrapup.post_implementation(sprint, team, sprint_number)

            sprint.status = SprintStatus.COMPLETE
            self.state.save_sprint(sprint)
            config.current_sprint = sprint_number
            self.state.save_config(config)
        except KeyboardInterrupt:
            sprint.status = SprintStatus.CANCELLED
            self.state.save_sprint(sprint)
            console.print(Panel(
                "[bold yellow]Sprint interrupted by CEO.[/bold yellow]\n"
                f"Work preserved on branch [cyan]sprint-{sprint_number}[/cyan].\n"
                "Run [bold]odd sprint[/bold] to start a new sprint.",
                style="yellow",
            ))

        return sprint

