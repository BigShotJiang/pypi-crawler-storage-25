"""Vacation command - autonomous multi-sprint execution."""

from __future__ import annotations

import click
from rich.markdown import Markdown
from rich.panel import Panel
from rich.prompt import Prompt
from rich.table import Table

import odd.cli as _cli
from odd.agent import BudgetExceededError
from odd.cli import console, main
from odd.models import BlockerPolicy, VacationPlan
from odd.sprint import SprintEngine


def _display_feasibility(feasibility: dict, estimated_sprints: int) -> None:
    """Show the CFO's feasibility assessment panel."""
    avg_cost = feasibility["avg_cost_per_sprint"]
    budget = feasibility["vacation_budget"]
    estimated_cost = avg_cost * estimated_sprints
    headroom = budget - estimated_cost
    headroom_sprints = headroom / avg_cost if avg_cost > 0 else 0

    lines = []
    if feasibility["sprints_completed"] > 0:
        lines.append(f"Avg sprint cost: ${avg_cost:.4f}")
    else:
        lines.append("No sprint history yet (cost estimates will be rough)")
    lines.append(f"Cody estimates: {estimated_sprints} sprints -> ~${estimated_cost:.4f}")
    lines.append(f"Your budget: ${budget:.2f}")

    if headroom >= 0:
        lines.append(f"Headroom: ${headroom:.4f} (~{headroom_sprints:.1f} extra sprints)")
        lines.append("Verdict: Looks good")
    else:
        lines.append(f"Shortfall: ${abs(headroom):.4f}")
        affordable = feasibility["estimated_sprints_affordable"]
        lines.append(
            f"Verdict: Budget may only cover ~{affordable} of "
            f"{estimated_sprints} sprints"
        )

    console.print(Panel(
        "\n".join(lines),
        title="Bill the CFO - Feasibility",
        style="yellow",
    ))


def _display_vacation_report(report) -> None:
    """Show the vacation report when the CEO comes back."""
    # Sprint results table
    table = Table(title="Vacation Sprint Results", style="blue")
    table.add_column("Sprint", style="cyan", justify="right")
    table.add_column("Goal", style="white")
    table.add_column("Status", style="green")
    table.add_column("Cost", style="yellow", justify="right")
    table.add_column("Notes", style="dim")

    for r in report.sprint_results:
        status_style = "green" if r.status.value == "complete" else "red"
        table.add_row(
            str(r.sprint_number),
            r.goal[:60] + ("..." if len(r.goal) > 60 else ""),
            f"[{status_style}]{r.status.value}[/{status_style}]",
            f"${r.cost:.4f}",
            r.error or "",
        )

    console.print(table)

    # Financial summary
    console.print(Panel(
        f"Total cost: ${report.total_cost:.4f}\n"
        f"Budget remaining: ${report.budget_remaining:.4f}\n"
        f"Stopped because: {report.stopped_reason}",
        title="Financial Summary",
        style="yellow",
    ))

    # Cody's debrief
    if report.summary:
        console.print(Panel(
            Markdown(report.summary),
            title="Cody's Debrief",
            style="bold blue",
        ))


def _resume_vacation(state, sprint_engine, team) -> None:
    """Resume a paused vacation."""
    plan = state.load_vacation_plan()
    report = state.load_vacation_report()

    # Show what happened so far
    completed = [r for r in report.sprint_results if r.status.value == "complete"]
    remaining = [rs for rs in plan.roadmap.sprints if rs.status != "complete"]

    console.print(Panel(
        f"[bold]Vacation in progress[/bold]\n\n"
        f"Goal: {plan.goal}\n"
        f"Budget: ${plan.budget:.2f}\n"
        f"Sprints completed: {len(completed)} of {len(plan.roadmap.sprints)}\n"
        f"Spent so far: ${report.total_cost:.4f}\n"
        f"Stopped because: {report.stopped_reason}",
        style="blue",
    ))

    if report.stopped_reason == "paused":
        # Show the blocker that caused the pause
        last_result = report.sprint_results[-1] if report.sprint_results else None
        if last_result and last_result.error:
            console.print(Panel(
                last_result.error,
                title="Blocker that paused vacation",
                style="red",
            ))

    choice = Prompt.ask(
        "Resume vacation or abandon?",
        choices=["resume", "abandon"],
        default="resume",
    )

    if choice == "abandon":
        state.clear_vacation()
        console.print("[yellow]Vacation abandoned.[/yellow]")
        return

    # Resume the vacation loop
    report = sprint_engine.vacation.run_vacation(team, plan)
    _display_vacation_report(report)
    state.clear_vacation()
    _cli._print_cost_footer(sprint_engine.engine.cfo)


@main.command()
@click.option("--unsafe-shell", is_flag=True, default=False, hidden=True)
def vacation(unsafe_shell: bool):
    """Go on vacation. Set a budget, define goals, and let the team run autonomously."""
    if unsafe_shell:
        import odd.tools.execution as _tools_exec
        _tools_exec._unsafe_shell = True
        console.print("[bold red]WARNING: --unsafe-shell is active.[/bold red]")

    state = _cli._get_state()
    _cli._require_init(state)

    config = state.load_config()
    team = _cli._load_team(state)

    # --- Check for active vacation (resume support) ---
    if state.has_active_vacation():
        sprint_number = config.current_sprint + 1
        engine = _cli._get_engine(state, sprint=sprint_number)
        sprint_engine = SprintEngine(engine, state)
        _resume_vacation(state, sprint_engine, team)
        return

    # --- Budget ---
    console.print(Panel(
        "[bold]CEO Vacation[/bold]\n\n"
        "You're about to go on vacation. The team will run autonomously\n"
        "within a budget you set, working toward goals you define.",
        style="bold blue",
    ))

    budget_str = Prompt.ask("\nHow much are you leaving for the team? $")
    try:
        budget = float(budget_str)
    except ValueError:
        console.print("[red]Invalid budget amount.[/red]")
        return

    if budget <= 0:
        console.print("[red]Budget must be positive.[/red]")
        return

    # --- Goal ---
    console.print("\nWhat should the team accomplish while you're gone?")
    ceo_goal = Prompt.ask("[bold yellow]CEO[/bold yellow]")

    if not ceo_goal.strip():
        console.print("[red]Need a goal for the team.[/red]")
        return

    # --- Planning with Cody ---
    sprint_number = config.current_sprint + 1
    engine = _cli._get_engine(state, sprint=sprint_number)
    sprint_engine = SprintEngine(engine, state)

    cody_response, roadmap = sprint_engine.vacation.plan_vacation(
        team["lead_dev"], ceo_goal, budget,
    )

    console.print(Panel(
        Markdown(cody_response),
        title="Cody - Vacation Scope Assessment",
        style="blue",
    ))

    if not roadmap or not roadmap.sprints:
        console.print("[yellow]Cody couldn't break this into a roadmap. Try refining your goal.[/yellow]")
        _cli._print_cost_footer(engine.cfo)
        return

    # --- CFO feasibility ---
    if engine.cfo:
        feasibility = engine.cfo.vacation_feasibility(budget)
        _display_feasibility(feasibility, len(roadmap.sprints))

    # --- Blocker policy (Cody asks) ---
    console.print(Panel(
        "[bold]Cody:[/bold] One more thing before you go - if we hit a blocker "
        "while you're away, what do you want me to do?",
        style="blue",
    ))
    blocker_choice = Prompt.ask(
        "[bold yellow]CEO[/bold yellow]",
        choices=["You decide", "Skip it", "Stop and wait for me"],
        default="You decide",
    )
    blocker_map = {
        "You decide": BlockerPolicy.DELEGATE_TO_CODY,
        "Skip it": BlockerPolicy.PARK_AND_SKIP,
        "Stop and wait for me": BlockerPolicy.PAUSE_VACATION,
    }
    blocker_policy = blocker_map[blocker_choice]

    # --- Final approval ---
    proceed = Prompt.ask(
        "\nApprove this vacation plan?",
        choices=["y", "n", "adjust"],
        default="y",
    )

    if proceed == "n":
        console.print("[yellow]Vacation cancelled.[/yellow]")
        _cli._print_cost_footer(engine.cfo)
        return

    if proceed == "adjust":
        # Let CEO re-enter budget
        new_budget_str = Prompt.ask("New budget? $", default=str(budget))
        try:
            budget = float(new_budget_str)
        except ValueError:
            console.print("[red]Invalid budget. Using original.[/red]")

        # Re-scope with Cody
        cody_response, roadmap = sprint_engine.vacation.plan_vacation(
            team["lead_dev"], ceo_goal, budget,
        )
        console.print(Panel(
            Markdown(cody_response),
            title="Cody - Revised Assessment",
            style="blue",
        ))

        if not roadmap or not roadmap.sprints:
            console.print("[yellow]Couldn't build a roadmap. Vacation cancelled.[/yellow]")
            _cli._print_cost_footer(engine.cfo)
            return

        # Final confirmation
        final = Prompt.ask("Approve?", choices=["y", "n"], default="y")
        if final != "y":
            console.print("[yellow]Vacation cancelled.[/yellow]")
            _cli._print_cost_footer(engine.cfo)
            return

    # --- Build the plan ---
    avg_cost = engine.cfo.cost_per_sprint_average() if engine.cfo else 0.0
    estimated_cost = avg_cost * len(roadmap.sprints)

    plan = VacationPlan(
        goal=ceo_goal,
        budget=budget,
        roadmap=roadmap,
        estimated_cost=estimated_cost,
        avg_cost_per_sprint=avg_cost,
        blocker_policy=blocker_policy,
    )

    # Save the roadmap for sprint engine to use
    state.save_roadmap(roadmap)

    # --- Go on vacation ---
    console.print(Panel(
        "[bold green]Have a great vacation![/bold green]\n\n"
        "The team is taking it from here. Come back when you're ready.",
        style="bold green",
    ))

    try:
        report = sprint_engine.vacation.run_vacation(team, plan)
    except BudgetExceededError as e:
        console.print(Panel(
            f"[bold red]BUDGET EXCEEDED[/bold red]\n\n{e}",
            style="red",
        ))
        if state.vacation_report_path.exists():
            report = state.load_vacation_report()
            _display_vacation_report(report)
        _cli._print_cost_footer(engine.cfo)
        return

    # --- Welcome back ---
    console.print(Panel(
        "[bold]Welcome back![/bold]",
        style="bold green",
    ))
    _display_vacation_report(report)
    state.clear_vacation()
    _cli._print_cost_footer(engine.cfo)
