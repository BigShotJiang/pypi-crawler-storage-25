"""Consolidated string parsers for agent output.

All _parse_* functions live here so the fragile parsing logic is in one
place. Each parser accepts optional structured data (from tool_use
submission tools, Phase 7) and falls back to string parsing when
structured data is not available.
"""

from __future__ import annotations

import logging
from typing import Any

from odd.models import CodeReviewPass, RoadmapSprint, SprintPhase, SprintTask

logger = logging.getLogger("odd.parsers")


# ---------------------------------------------------------------------------
# Sprint planning
# ---------------------------------------------------------------------------

def parse_tasks(
    plan_text: str,
    sprint_number: int,
    structured_data: dict[str, Any] | None = None,
) -> list[SprintTask]:
    """Parse sprint tasks from the lead dev's plan.

    If structured_data is provided (from submit_sprint_plan tool), use it
    directly. Otherwise, fall back to string parsing.

    Expected string format:
        TASK: <description>
        ASSIGN: <role>
    """
    # Structured path
    if structured_data and "tasks" in structured_data:
        tasks = []
        for i, t in enumerate(structured_data["tasks"], 1):
            tasks.append(
                SprintTask(
                    id=f"s{sprint_number}_t{i}",
                    description=t["description"],
                    assigned_to=t["assigned_to"],
                )
            )
        if tasks:
            return tasks

    # String fallback
    tasks = []
    lines = plan_text.split("\n")
    current_desc = None
    task_count = 0

    for line in lines:
        line = line.strip()
        if line.upper().startswith("TASK:"):
            current_desc = line[5:].strip()
        elif line.upper().startswith("ASSIGN:") and current_desc:
            task_count += 1
            assigned = line[7:].strip()
            tasks.append(
                SprintTask(
                    id=f"s{sprint_number}_t{task_count}",
                    description=current_desc,
                    assigned_to=assigned,
                )
            )
            current_desc = None

    # If parsing didn't find structured tasks, warn and create a generic task
    if not tasks:
        logger.warning(
            "Lead dev did not produce a structured sprint plan; "
            "creating a generic task from CEO goal."
        )
        tasks.append(
            SprintTask(
                id=f"s{sprint_number}_t1",
                description="Implement the sprint goal (plan was not structured - consider revising)",
                assigned_to="Lead Developer",
            )
        )

    return tasks


def parse_roadmap(
    text: str,
    current_sprint: int,
    structured_data: dict[str, Any] | None = None,
) -> list[RoadmapSprint]:
    """Parse roadmap sprints from Cody's sizing response.

    If structured_data is provided (from submit_roadmap tool), use it
    directly. Otherwise, fall back to string parsing.

    Expected string format:
        SPRINT N: <deliverables>
        MILESTONE: yes/no
    """
    # Structured path
    if structured_data and "sprints" in structured_data:
        sprints = []
        for s in structured_data["sprints"]:
            sprints.append(RoadmapSprint(
                number=s["number"] + current_sprint,
                deliverables=s["deliverables"],
                is_milestone=s.get("is_milestone", False),
            ))
        if sprints:
            return sprints

    # String fallback
    sprints = []
    lines = text.split("\n")
    current_deliverables = None
    current_number = 0

    for line in lines:
        stripped = line.strip().upper()
        if stripped.startswith("SPRINT ") and ":" in line:
            # Parse "SPRINT N: deliverables"
            try:
                rest = line.strip()[7:]  # after "SPRINT "
                num_str, deliverables = rest.split(":", 1)
                current_number = int(num_str.strip()) + current_sprint
                current_deliverables = deliverables.strip()
            except (ValueError, IndexError):
                continue
        elif stripped.startswith("MILESTONE:") and current_deliverables:
            is_milestone = "yes" in stripped.lower()
            sprints.append(RoadmapSprint(
                number=current_number,
                deliverables=current_deliverables,
                is_milestone=is_milestone,
            ))
            current_deliverables = None

    # Catch last sprint if no MILESTONE line followed
    if current_deliverables and current_number > 0:
        sprints.append(RoadmapSprint(
            number=current_number,
            deliverables=current_deliverables,
        ))

    return sprints


# ---------------------------------------------------------------------------
# Phase planning
# ---------------------------------------------------------------------------

def parse_phase_plan(
    text: str,
    tasks: list[SprintTask],
    structured_data: dict[str, Any] | None = None,
) -> list[SprintPhase]:
    """Parse phase breakdown from Cody's detailed planning.

    If structured_data is provided (from submit_phase_plan tool), use it
    directly. Otherwise, fall back to string parsing.

    Expected string format:
        PHASE 1: <description>
        TASKS: <task_id>, <task_id>, ...

    If parsing fails or only one phase is found, returns a single phase
    containing all tasks (sequential fallback).
    """
    task_ids = {t.id for t in tasks}

    # Structured path
    if structured_data and "phases" in structured_data:
        phases = []
        for i, p in enumerate(structured_data["phases"], 1):
            # Only include task IDs that actually exist
            valid_ids = [tid for tid in p.get("task_ids", []) if tid in task_ids]
            phases.append(SprintPhase(
                number=i,
                description=p["description"],
                task_ids=valid_ids,
            ))
        if phases:
            # Ensure all tasks are assigned to a phase
            assigned = {tid for p in phases for tid in p.task_ids}
            unassigned = task_ids - assigned
            if unassigned:
                phases[-1].task_ids.extend(sorted(unassigned))
            return phases

    # String fallback
    phases: list[SprintPhase] = []
    lines = text.split("\n")
    current_desc: str | None = None
    phase_count = 0

    for line in lines:
        stripped = line.strip()
        upper = stripped.upper()
        if upper.startswith("PHASE ") and ":" in stripped:
            try:
                rest = stripped[6:]  # after "PHASE "
                _, desc = rest.split(":", 1)
                phase_count += 1
                current_desc = desc.strip()
            except (ValueError, IndexError):
                continue
        elif upper.startswith("TASKS:") and current_desc:
            ids_str = stripped[6:].strip()
            phase_task_ids = [
                tid.strip() for tid in ids_str.split(",")
                if tid.strip() in task_ids
            ]
            phases.append(SprintPhase(
                number=phase_count,
                description=current_desc,
                task_ids=phase_task_ids,
            ))
            current_desc = None

    # Catch last phase if no TASKS line followed
    if current_desc and phase_count > 0:
        phases.append(SprintPhase(
            number=phase_count,
            description=current_desc,
            task_ids=[],
        ))

    # Fallback: if parsing found nothing, create a single phase with all tasks.
    # If it found exactly one phase, keep the LLM's description rather than
    # discarding it.
    if not phases:
        logger.warning(
            "Phase plan parsing found no phases; falling back to single phase "
            "with all %d tasks",
            len(task_ids),
        )
        return [SprintPhase(
            number=1,
            description="All sprint work",
            task_ids=sorted(task_ids),
        )]

    # Ensure all tasks are assigned
    assigned = {tid for p in phases for tid in p.task_ids}
    unassigned = task_ids - assigned
    if unassigned:
        phases[-1].task_ids.extend(sorted(unassigned))

    return phases


# ---------------------------------------------------------------------------
# Code review
# ---------------------------------------------------------------------------

def parse_code_review(
    text: str,
    pass_number: int,
    structured_data: dict[str, Any] | None = None,
) -> CodeReviewPass:
    """Parse code review results from the prodigy reviewer.

    If structured_data is provided (from submit_code_review tool), use it
    directly. Otherwise, fall back to string parsing.

    Expected string format:
        SCORE: <1-10>
        FINDING: [severity] description
    """
    # Structured path
    if structured_data:
        findings = []
        has_critical = False
        for f in structured_data.get("findings", []):
            severity = f.get("severity", "minor")
            findings.append(f"[{severity}] {f['description']}")
            if severity == "critical":
                has_critical = True
        return CodeReviewPass(
            pass_number=pass_number,
            score=structured_data.get("score", 5),
            findings=findings,
            has_critical=has_critical,
        )

    # String fallback
    score = 5  # default
    findings: list[str] = []
    has_critical = False

    for line in text.split("\n"):
        stripped = line.strip()
        upper = stripped.upper()
        if upper.startswith("SCORE:"):
            try:
                score = int(stripped[6:].strip().split("/")[0].strip())
                score = max(1, min(10, score))
            except (ValueError, IndexError):
                logger.debug(
                    "Could not parse code review score from: %s", stripped
                )
        elif upper.startswith("FINDING:"):
            finding = stripped[8:].strip()
            findings.append(finding)
            if "[critical]" in finding.lower():
                has_critical = True

    return CodeReviewPass(
        pass_number=pass_number,
        score=score,
        findings=findings,
        has_critical=has_critical,
    )


# ---------------------------------------------------------------------------
# Hire suggestions
# ---------------------------------------------------------------------------

def parse_hire_suggestions(
    response: str,
    structured_data: dict[str, Any] | None = None,
) -> list[dict[str, str]]:
    """Parse HIRE:/MODEL: pairs from Cody's response.

    If structured_data is provided (from submit_hire_suggestion tool), use it
    directly. Otherwise, fall back to string parsing.

    Returns list of dicts with 'description', 'model', and 'reasoning' keys.
    """
    # Structured path
    if structured_data and "suggestions" in structured_data:
        suggestions = []
        for s in structured_data["suggestions"]:
            model = s.get("model", "sonnet")
            if model not in ("opus", "sonnet", "haiku"):
                model = "sonnet"
            suggestions.append({
                "description": s["description"],
                "model": model,
                "reasoning": s.get("reasoning", ""),
            })
        return suggestions

    # String fallback
    suggestions: list[dict[str, str]] = []
    current_desc: str | None = None

    for line in response.split("\n"):
        stripped = line.strip()
        if stripped.upper().startswith("HIRE:"):
            # If we had a previous HIRE without a MODEL, flush it
            if current_desc is not None:
                suggestions.append({
                    "description": current_desc,
                    "model": "sonnet",
                    "reasoning": "",
                })
            current_desc = stripped[5:].strip()
        elif stripped.upper().startswith("MODEL:") and current_desc is not None:
            model_rest = stripped[6:].strip()
            # Parse "opus - reasoning" or "opus - reasoning" or just "opus"
            model = "sonnet"  # default
            reasoning = ""
            for sep in [" - ", " - ", " – "]:
                if sep in model_rest:
                    model_part, reasoning = model_rest.split(sep, 1)
                    model = model_part.strip().lower()
                    break
            else:
                model = model_rest.strip().lower()

            if model not in ("opus", "sonnet", "haiku"):
                model = "sonnet"

            suggestions.append({
                "description": current_desc,
                "model": model,
                "reasoning": reasoning.strip(),
            })
            current_desc = None

    # Flush last HIRE if no MODEL followed
    if current_desc is not None:
        suggestions.append({
            "description": current_desc,
            "model": "sonnet",
            "reasoning": "",
        })

    return suggestions


# ---------------------------------------------------------------------------
# Consultant specs (init flow)
# ---------------------------------------------------------------------------

def parse_consultant_specs(
    text: str,
    structured_data: dict[str, Any] | None = None,
) -> list[tuple[str, str, str]]:
    """Parse consultant recommendations from the lead dev's response.

    If structured_data is provided (from submit_consultant_specs tool), use it
    directly. Otherwise, fall back to string parsing.

    Expected string format:
        CONSULTANT: <name>
        JD: <job description>
        MODEL: <opus|sonnet|haiku> - <reasoning>   (optional)

    Returns list of (name, jd, model_tier) tuples. model_tier defaults to 'sonnet'.
    """
    # Structured path
    if structured_data and "consultants" in structured_data:
        specs = []
        for c in structured_data["consultants"]:
            model = c.get("model", "sonnet")
            if model not in ("opus", "sonnet", "haiku"):
                model = "sonnet"
            specs.append((c["name"], c["job_description"], model))
        if specs:
            return specs

    # String fallback
    specs: list[tuple[str, str, str]] = []
    lines = text.split("\n")
    current_name: str | None = None
    current_jd: str | None = None

    for line in lines:
        line = line.strip()
        if line.upper().startswith("CONSULTANT:"):
            # Flush previous spec if we had name+jd but no model
            if current_name and current_jd:
                specs.append((current_name, current_jd, "sonnet"))
            current_name = line[11:].strip()
            current_jd = None
        elif line.upper().startswith("JD:") and current_name:
            current_jd = line[3:].strip()
        elif line.upper().startswith("MODEL:") and current_name and current_jd:
            model_rest = line[6:].strip()
            model = "sonnet"
            for sep in [" - ", " - ", " – "]:
                if sep in model_rest:
                    model = model_rest.split(sep, 1)[0].strip().lower()
                    break
            else:
                model = model_rest.strip().lower()
            if model not in ("opus", "sonnet", "haiku"):
                model = "sonnet"
            specs.append((current_name, current_jd, model))
            current_name = None
            current_jd = None

    # Flush last spec if no MODEL line followed
    if current_name and current_jd:
        specs.append((current_name, current_jd, "sonnet"))

    return specs


# ---------------------------------------------------------------------------
# Recruiter candidate
# ---------------------------------------------------------------------------

def parse_candidate(
    text: str,
    structured_data: dict[str, Any] | None = None,
) -> tuple[str | None, str | None, str]:
    """Parse NAME:/TITLE: from recruiter's response.

    If structured_data is provided (from submit_candidate tool), use it
    directly. Otherwise, fall back to string parsing.

    Returns (name, title, resume_text).
    """
    # Structured path
    if structured_data:
        return (
            structured_data.get("name"),
            structured_data.get("title"),
            structured_data.get("resume", text),
        )

    # String fallback
    name = None
    title = None
    for line in text.split("\n"):
        stripped = line.strip()
        if stripped.upper().startswith("NAME:"):
            name = stripped[5:].strip()
        elif stripped.upper().startswith("TITLE:"):
            title = stripped[6:].strip()

    return (name, title, text)


# ---------------------------------------------------------------------------
# Beta tester specs
# ---------------------------------------------------------------------------

def parse_tester_specs(
    text: str,
    structured_data: dict[str, Any] | None = None,
) -> list[tuple[str, str, str]]:
    """Parse tester specs from Lead Dev's response.

    If structured_data is provided (from submit_tester_specs tool), use it
    directly. Otherwise, fall back to string parsing.

    Expected string format:
        TESTER: <name>
        PROFILE: <who this person is>
        INSTRUCTIONS: <what they should test and how>
    """
    # Structured path
    if structured_data and "testers" in structured_data:
        specs = []
        for t in structured_data["testers"]:
            specs.append((t["name"], t["profile"], t["instructions"]))
        if specs:
            return specs

    # String fallback
    specs: list[tuple[str, str, str]] = []
    lines = text.split("\n")
    name = profile = instructions = None

    for line in lines:
        stripped = line.strip()
        if stripped.upper().startswith("TESTER:"):
            name = stripped[7:].strip()
        elif stripped.upper().startswith("PROFILE:"):
            profile = stripped[8:].strip()
        elif stripped.upper().startswith("INSTRUCTIONS:"):
            instructions = stripped[13:].strip()
            if name and profile and instructions:
                specs.append((name, profile, instructions))
                name = profile = instructions = None

    return specs
