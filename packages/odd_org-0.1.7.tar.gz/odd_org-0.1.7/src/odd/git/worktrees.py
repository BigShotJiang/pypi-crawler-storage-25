"""Worktree operations for GitManager (mixin)."""

from __future__ import annotations

import logging
import subprocess
from pathlib import Path

from odd.config import GIT_COMMAND_TIMEOUT, SPRINT_BRANCH_PREFIX, WORKTREE_DIR

logger = logging.getLogger(__name__)


class WorktreeMixin:
    """Worktree and task-branch methods, mixed into GitManager."""

    def _worktree_path(self, task_id: str) -> Path:
        """Return the worktree path for a task, inside .odd/worktrees/."""
        return self.root / WORKTREE_DIR / task_id

    def task_branch_name(self, sprint_number: int, task_id: str) -> str:
        return f"{SPRINT_BRANCH_PREFIX}-{sprint_number}-task-{task_id}"

    def create_task_worktree(self, sprint_number: int, task_id: str) -> Path | None:
        """Create a git worktree for a task branch.

        Returns the worktree path, or None if git is unavailable.
        The worktree is created from the sprint branch so each task
        starts with all sprint work so far.

        Prunes stale worktrees first to avoid git errors from previous
        crashed sprints.
        """
        from odd.git.manager import _validate_branch_name

        if not self.available:
            return None

        # Prune any leftover worktrees from previous crashes
        self._run(["git", "worktree", "prune"], check=False)

        branch = _validate_branch_name(self.task_branch_name(sprint_number, task_id))
        sprint_branch = _validate_branch_name(self.sprint_branch_name(sprint_number))
        worktree_path = self._worktree_path(task_id)

        # Create branch from sprint branch
        result = self._run(["git", "rev-parse", "--verify", branch], check=False)
        if result.returncode != 0:
            # Verify sprint branch exists before branching from it
            sprint_exists = self._run(
                ["git", "rev-parse", "--verify", sprint_branch], check=False,
            )
            if sprint_exists.returncode != 0:
                logger.error(
                    "Sprint branch %s does not exist - cannot create task worktree",
                    sprint_branch,
                )
                return None
            self._run(["git", "branch", branch, sprint_branch])

        # Create worktree (remove stale one if it exists)
        if worktree_path.exists():
            self._run(["git", "worktree", "remove", str(worktree_path), "--force"], check=False)

        worktree_path.parent.mkdir(parents=True, exist_ok=True)
        result = self._run(
            ["git", "worktree", "add", str(worktree_path), branch], check=False,
        )
        if result.returncode != 0:
            logger.error(
                "Failed to create worktree at %s: %s",
                worktree_path, result.stderr.strip()[:200],
            )
            return None

        return worktree_path

    def remove_task_worktree(self, task_id: str) -> None:
        """Remove a task worktree after the phase is done."""
        if not self.available:
            return
        worktree_path = self._worktree_path(task_id)
        if worktree_path.exists():
            self._run(["git", "worktree", "remove", str(worktree_path), "--force"], check=False)

    def commit_task_worktree(self, task_id: str, message: str) -> bool:
        """Commit all changes in a task worktree."""
        if not self.available:
            return False
        worktree_path = self._worktree_path(task_id)
        if not worktree_path.exists():
            return False
        # Stage all changes
        subprocess.run(
            ["git", "add", "-A"],
            shell=False, capture_output=True, text=True,
            encoding="utf-8", errors="replace",
            cwd=worktree_path, timeout=GIT_COMMAND_TIMEOUT,
        )
        # Check if there's anything to commit
        diff_result = subprocess.run(
            ["git", "diff", "--cached", "--quiet"],
            shell=False, capture_output=True, text=True,
            encoding="utf-8", errors="replace",
            cwd=worktree_path, timeout=GIT_COMMAND_TIMEOUT,
        )
        if diff_result.returncode == 0:
            return True  # Nothing to commit - that's fine
        # Commit
        result = subprocess.run(
            ["git", "commit", "-m", message],
            shell=False, capture_output=True, text=True,
            encoding="utf-8", errors="replace",
            cwd=worktree_path, timeout=GIT_COMMAND_TIMEOUT,
        )
        return result.returncode == 0

    def merge_task_branches(
        self,
        sprint_number: int,
        task_ids: list[str],
    ) -> list[str]:
        """Merge all task branches back into the sprint branch.

        Returns list of files with conflicts (empty on clean merge).
        Commits each task worktree first, then merges sequentially.

        When a merge has conflicts, they are recorded and the merge is
        aborted so that subsequent task branches can still be attempted.
        Tasks whose merges conflict are collected into `failed_task_ids`
        so the caller can retry them after the clean merges land.
        """
        from odd.git.manager import _validate_branch_name

        if not self.available:
            return []

        sprint_branch = _validate_branch_name(self.sprint_branch_name(sprint_number))

        # Commit any remaining work in each worktree
        for task_id in task_ids:
            self.commit_task_worktree(
                task_id, f"Sprint {sprint_number} - task {task_id}",
            )

        # Switch to sprint branch
        self._run(["git", "checkout", sprint_branch])

        # Merge each task branch - clean merges first, then retry conflicts
        all_conflicts: list[str] = []
        failed_task_ids: list[str] = []

        for task_id in task_ids:
            branch = _validate_branch_name(self.task_branch_name(sprint_number, task_id))
            # Verify the branch actually exists before merging
            exists = self._run(["git", "rev-parse", "--verify", branch], check=False)
            if exists.returncode != 0:
                logger.warning("Task branch %s does not exist - skipping merge", branch)
                continue
            result = self._run(["git", "merge", branch, "--no-edit"], check=False)
            if result.returncode != 0:
                conflicts = self._get_conflict_files()
                if conflicts:
                    all_conflicts.extend(conflicts)
                    failed_task_ids.append(task_id)
                    self._run(["git", "merge", "--abort"], check=False)
                elif "untracked working tree files" in result.stderr:
                    # Untracked files from a prior merge block this one.
                    # Stage them so git can merge over them, then retry.
                    self._run(["git", "merge", "--abort"], check=False)
                    self._run(["git", "add", "-A"], check=False)
                    self._run(
                        ["git", "commit", "-m", "stage untracked files before merge"],
                        check=False,
                    )
                    retry = self._run(["git", "merge", branch, "--no-edit"], check=False)
                    if retry.returncode != 0:
                        retry_conflicts = self._get_conflict_files()
                        if retry_conflicts:
                            all_conflicts.extend(retry_conflicts)
                            failed_task_ids.append(task_id)
                        self._run(["git", "merge", "--abort"], check=False)
                        logger.error(
                            "Merge of %s failed after staging untracked files: %s",
                            branch, retry.stderr.strip()[:200],
                        )
                else:
                    # Non-conflict merge failure (e.g. unrelated histories) - abort
                    self._run(["git", "merge", "--abort"], check=False)
                    logger.error(
                        "Merge of %s failed without conflicts: %s",
                        branch, result.stderr.strip()[:200],
                    )

        # Second pass: retry failed merges now that clean merges have landed.
        # The new base may resolve some conflicts automatically.
        if failed_task_ids:
            retry_conflicts: list[str] = []
            for task_id in failed_task_ids:
                branch = _validate_branch_name(self.task_branch_name(sprint_number, task_id))
                result = self._run(["git", "merge", branch, "--no-edit"], check=False)
                if result.returncode != 0:
                    conflicts = self._get_conflict_files()
                    if conflicts:
                        retry_conflicts.extend(conflicts)
                    self._run(["git", "merge", "--abort"], check=False)
            # Replace first-pass conflicts with retry results - we only
            # care about the final conflict state, not what conflicted on
            # the first pass, since those were against a different base.
            if retry_conflicts:
                all_conflicts = list(dict.fromkeys(retry_conflicts))
            else:
                all_conflicts = []  # All conflicts resolved on retry

        return all_conflicts

    def cleanup_task_branches(self, sprint_number: int, task_ids: list[str]) -> None:
        """Remove task worktrees and branches after a phase is merged."""
        from odd.git.manager import _validate_branch_name

        for task_id in task_ids:
            self.remove_task_worktree(task_id)
            branch = _validate_branch_name(self.task_branch_name(sprint_number, task_id))
            self._run(["git", "branch", "-D", branch], check=False)

    def prune_stale_worktrees(self) -> list[str]:
        """Remove worktrees left behind by crashed sprints.

        Returns list of cleaned-up worktree paths.
        """
        if not self.available:
            return []

        result = self._run(["git", "worktree", "list", "--porcelain"], check=False)
        if result.returncode != 0:
            return []

        worktrees_dir = self.root / WORKTREE_DIR

        cleaned: list[str] = []
        current_path = ""
        for line in result.stdout.splitlines():
            if line.startswith("worktree "):
                current_path = line[len("worktree "):]
            elif line == "prunable" or (
                current_path
                and str(worktrees_dir) in current_path
                and not Path(current_path).exists()
            ):
                cleaned.append(current_path)

        # Prune all stale entries
        if cleaned:
            self._run(["git", "worktree", "prune"], check=False)

        # Also remove any leftover worktree directories on disk
        if worktrees_dir.exists():
            known_result = self._run(
                ["git", "worktree", "list", "--porcelain"], check=False,
            )
            known_worktrees = known_result.stdout if known_result.returncode == 0 else ""
            for d in worktrees_dir.iterdir():
                if d.is_dir() and str(d) not in known_worktrees:
                    self._run(["git", "worktree", "remove", str(d), "--force"], check=False)
                    if not d.exists():
                        cleaned.append(str(d))

        return cleaned

    def cherry_pick_task_commits(
        self,
        sprint_number: int,
        task_id: str,
    ) -> bool:
        """Cherry-pick commits from a task branch onto the sprint branch.

        Used as a fallback when a full merge of the task branch fails.
        Picks each commit individually, skipping any that conflict, so
        partial work is salvaged rather than lost entirely.

        Returns True if at least one commit was applied.
        """
        from odd.git.manager import _validate_branch_name

        if not self.available:
            return False

        sprint_branch = _validate_branch_name(self.sprint_branch_name(sprint_number))
        task_branch = _validate_branch_name(self.task_branch_name(sprint_number, task_id))

        if not self.branch_exists(task_branch):
            return False

        # Find commits on task branch that aren't on sprint branch
        result = self._run(
            ["git", "rev-list", "--reverse", f"{sprint_branch}..{task_branch}"],
            check=False,
        )
        if result.returncode != 0 or not result.stdout.strip():
            return False

        commits = result.stdout.strip().splitlines()

        # Make sure we're on the sprint branch
        self._run(["git", "checkout", sprint_branch])

        applied = 0
        skipped = 0
        for commit in commits:
            pick_result = self._run(
                ["git", "cherry-pick", "--no-edit", commit], check=False,
            )
            if pick_result.returncode != 0:
                # Conflict - abort this cherry-pick and skip
                self._run(["git", "cherry-pick", "--abort"], check=False)
                skipped += 1
                logger.warning(
                    "Cherry-pick of %s from task %s skipped (conflict)",
                    commit[:12], task_id,
                )
            else:
                applied += 1

        if applied > 0:
            logger.info(
                "Cherry-picked %d/%d commits from task %s (%d skipped)",
                applied, len(commits), task_id, skipped,
            )

        return applied > 0
