"""Gitignore management — keep dependency artifacts out of version control.

Two responsibilities:
1. Seed a sensible .gitignore when a project is first initialised, based on
   the detected ecosystem (Python, JS/TS, or generic).
2. Ensure ecosystem-specific ignore patterns are present after dependency
   installation so ``node_modules/``, ``__pycache__/``, etc. never get
   committed by accident.
"""

from __future__ import annotations

from pathlib import Path
from typing import Sequence

# ── Pattern catalogue ────────────────────────────────────────────────
# Each list is a set of gitignore lines for one concern.  Patterns that
# apply to *every* project go in _UNIVERSAL; ecosystem-specific ones live
# under their own name and get added when we detect that ecosystem.

_UNIVERSAL: list[str] = [
    # ODD internal state
    ".odd/",
    # Editor / OS junk
    ".vscode/",
    ".idea/",
    "*.swp",
    "*.swo",
    "*~",
    ".DS_Store",
    "Thumbs.db",
    # Build output (common across ecosystems)
    "dist/",
    "build/",
]

_PYTHON: list[str] = [
    # Byte-compiled / optimised
    "__pycache__/",
    "*.py[cod]",
    "*.pyo",
    # Distribution / packaging
    "*.egg-info/",
    "*.egg",
    # Virtual environments
    ".venv/",
    "venv/",
    "env/",
    # Testing / coverage
    ".pytest_cache/",
    ".coverage",
    "htmlcov/",
    # Type checking
    ".mypy_cache/",
]

_JAVASCRIPT: list[str] = [
    "node_modules/",
    ".next/",
    "coverage/",
    ".env",
    ".env.local",
]

# Map from ecosystem label used during dependency install to the patterns
# that must be present once packages from that ecosystem are installed.
_ECOSYSTEM_INSTALL_PATTERNS: dict[str, list[str]] = {
    "pip": [
        "__pycache__/",
        "*.py[cod]",
        ".venv/",
        "venv/",
        "*.egg-info/",
    ],
    "npm": [
        "node_modules/",
    ],
}


# ── Public helpers ───────────────────────────────────────────────────

def detect_ecosystems(root: Path) -> list[str]:
    """Return a list of ecosystem names present in *root*.

    Recognised ecosystems: ``"python"``, ``"javascript"``.  An empty list
    means nothing recognisable was found (we still apply universal rules).
    """
    ecosystems: list[str] = []

    python_markers = ("pyproject.toml", "setup.py", "setup.cfg",
                      "requirements.txt", "Pipfile")
    if any((root / f).exists() for f in python_markers):
        ecosystems.append("python")

    js_markers = ("package.json", "tsconfig.json", ".npmrc", "yarn.lock",
                  "pnpm-lock.yaml")
    if any((root / f).exists() for f in js_markers):
        ecosystems.append("javascript")

    return ecosystems


def seed_gitignore(root: Path) -> tuple[list[str], bool]:
    """Create or enrich ``.gitignore`` with ecosystem-appropriate patterns.

    Called during ``odd init``.  Returns ``(groups, created_fresh)`` where
    *groups* lists the pattern groups that were added (empty when nothing
    new was written) and *created_fresh* is True when the file did not
    exist before this call.
    """
    created_fresh = not (root / ".gitignore").exists()
    ecosystems = detect_ecosystems(root)

    patterns: list[str] = list(_UNIVERSAL)
    groups: list[str] = ["universal"]

    if "python" in ecosystems:
        patterns.extend(_PYTHON)
        groups.append("python")
    if "javascript" in ecosystems:
        patterns.extend(_JAVASCRIPT)
        groups.append("javascript")

    added = ensure_patterns(root, patterns)
    return (groups if added else [], created_fresh)


def ensure_ecosystem_patterns(root: Path, ecosystem: str) -> list[str]:
    """Add gitignore entries required after installing *ecosystem* deps.

    *ecosystem* is the label from the dependency request tool (``"pip"``
    or ``"npm"``).  Returns the patterns that were actually added (empty
    if all were already present).
    """
    patterns = _ECOSYSTEM_INSTALL_PATTERNS.get(ecosystem, [])
    if not patterns:
        return []
    return ensure_patterns(root, patterns)


def ensure_patterns(root: Path, patterns: Sequence[str]) -> list[str]:
    """Ensure every pattern in *patterns* appears in ``.gitignore``.

    Creates the file if it doesn't exist.  Returns patterns that were
    actually appended (i.e. not already present).
    """
    gitignore = root / ".gitignore"

    existing_lines: set[str] = set()
    if gitignore.exists():
        content = gitignore.read_text(encoding="utf-8")
        for line in content.splitlines():
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                continue
            existing_lines.add(stripped)
            # Normalise leading-slash variants so /.odd/ matches .odd/
            existing_lines.add(stripped.lstrip("/"))
    else:
        content = ""

    missing = [
        p for p in patterns
        if p not in existing_lines and p.lstrip("/") not in existing_lines
    ]
    if not missing:
        return []

    # Build the block to append
    if content and not content.endswith("\n"):
        content += "\n"
    content += "\n".join(missing) + "\n"

    gitignore.write_text(content, encoding="utf-8")
    return missing
