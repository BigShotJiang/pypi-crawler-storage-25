"""Git subpackage - branch management for agent isolation."""

from odd.git.manager import (
    GitManager,
    GitNotAvailable,
    MergeConflictError,
    _validate_branch_name,
)

__all__ = ["GitManager", "GitNotAvailable", "MergeConflictError", "_validate_branch_name"]
