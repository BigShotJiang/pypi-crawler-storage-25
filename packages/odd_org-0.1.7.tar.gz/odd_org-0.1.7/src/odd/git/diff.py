"""Diff and conflict operations for GitManager (mixin)."""

from __future__ import annotations

import logging

from odd.config import SPRINT_BRANCH_PREFIX

logger = logging.getLogger(__name__)


class DiffMixin:
    """Diff and conflict resolution methods, mixed into GitManager."""

    def get_sprint_diff_summary(self, sprint_number: int) -> str:
        """Get a summary of changes on the sprint branch vs main.

        This is for Cody to read internally when preparing the demo -
        the CEO never sees this.
        """
        from odd.git.manager import _validate_branch_name

        if not self.available:
            return ""
        branch = _validate_branch_name(self.sprint_branch_name(sprint_number))
        main = self.main_branch()
        diff_range = f"{main}...{branch}"

        # Stat summary (files changed, insertions, deletions)
        result = self._run(["git", "diff", diff_range, "--stat"], check=False)
        stat = result.stdout.strip() if result.returncode == 0 else ""

        # File list
        result = self._run(["git", "diff", diff_range, "--name-only"], check=False)
        files = result.stdout.strip() if result.returncode == 0 else ""

        parts = []
        if files:
            parts.append(f"Files changed:\n{files}")
        if stat:
            parts.append(f"Summary:\n{stat}")
        return "\n\n".join(parts)

    def get_task_diff_stat(self, sprint_number: int, task_id: str) -> str:
        """Get git diff --stat for a task branch vs the sprint branch.

        Used to show what a specific agent changed in their worktree,
        scoped to just their branch rather than the whole phase.
        """
        from odd.git.manager import _validate_branch_name

        if not self.available:
            return ""
        task_branch = _validate_branch_name(self.task_branch_name(sprint_number, task_id))
        sprint_branch = _validate_branch_name(self.sprint_branch_name(sprint_number))

        result = self._run(
            ["git", "diff", f"{sprint_branch}...{task_branch}", "--stat"],
            check=False,
        )
        return result.stdout.strip() if result.returncode == 0 else ""

    def resolve_conflicts_and_commit(self, sprint_number: int) -> bool:
        """After conflicts are resolved by an agent, add and commit."""
        if not self.available:
            return True
        self._run(["git", "add", "-A"])
        result = self._run(
            ["git", "commit", "-m", f"Sprint {sprint_number} - merge conflicts resolved"],
            check=False,
        )
        return result.returncode == 0

    def abort_merge(self) -> None:
        """Abort an in-progress merge."""
        if not self.available:
            return
        self._run(["git", "merge", "--abort"], check=False)

    def _get_conflict_files(self) -> list[str]:
        """List files with merge conflicts."""
        result = self._run(["git", "diff", "--name-only", "--diff-filter=U"], check=False)
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout.strip().splitlines()
        return []
