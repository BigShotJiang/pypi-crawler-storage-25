"""Git branch management - invisible infrastructure for agent isolation.

Each sprint gets its own branch. Agents work on the branch. The CEO never
sees git operations - they just approve or reject the sprint's work, and
the merge/abandon happens silently.
"""

from __future__ import annotations

import json
import logging
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from odd.config import GIT_COMMAND_TIMEOUT, SPRINT_BRANCH_PREFIX
from odd.git.diff import DiffMixin
from odd.git.worktrees import WorktreeMixin

logger = logging.getLogger(__name__)


def _validate_branch_name(name: str) -> str:
    """Reject branch names with shell metacharacters."""
    if not re.match(r'^[\w\-./]+$', name):
        raise ValueError(f"Invalid branch name: {name}")
    return name


class GitNotAvailable(Exception):
    """Project is not a git repo or git is not installed."""
    pass


class MergeConflictError(Exception):
    """Branch merge produced conflicts that need resolution."""

    def __init__(self, conflicting_files: list[str]):
        self.conflicting_files = conflicting_files
        super().__init__(f"Merge conflicts in: {', '.join(conflicting_files)}")


class GitManager(DiffMixin, WorktreeMixin):
    """Manages sprint branches - completely invisible to the CEO.

    All operations are safe: if git isn't available or the project isn't
    a repo, everything degrades gracefully to no-ops.
    """

    def __init__(self, project_root: Path | None = None):
        self.root = (project_root or Path.cwd()).resolve()
        self._available: bool | None = None

    @property
    def available(self) -> bool:
        """Check if git is usable in this project."""
        if self._available is None:
            self._available = self._check_git()
        return self._available

    def sprint_branch_name(self, sprint_number: int) -> str:
        return f"{SPRINT_BRANCH_PREFIX}-{sprint_number}"

    def main_branch(self) -> str:
        """Detect the main branch name (main, master, etc.)."""
        if not self.available:
            return "main"
        # Use the HEAD of the default remote branch
        result = self._run(["git", "symbolic-ref", "refs/remotes/origin/HEAD"], check=False)
        if result.returncode == 0 and result.stdout.strip():
            # refs/remotes/origin/main -> main
            return result.stdout.strip().split("/")[-1]
        # Fallback: check if main or master exists
        for candidate in ("main", "master"):
            result = self._run(["git", "rev-parse", "--verify", candidate], check=False)
            if result.returncode == 0:
                return candidate
        # Last resort: current branch
        result = self._run(["git", "branch", "--show-current"], check=False)
        return result.stdout.strip() or "main"

    def create_sprint_branch(self, sprint_number: int) -> str | None:
        """Create and checkout a sprint branch. Returns branch name or None if git unavailable."""
        if not self.available:
            return None
        branch = _validate_branch_name(self.sprint_branch_name(sprint_number))
        main = self.main_branch()

        # If branch already exists, just check it out
        result = self._run(["git", "rev-parse", "--verify", branch], check=False)
        if result.returncode == 0:
            self._run(["git", "checkout", branch])
            return branch

        # Create from main
        self._run(["git", "checkout", main])
        self._run(["git", "checkout", "-b", branch])
        return branch

    def merge_sprint(self, sprint_number: int) -> bool:
        """Merge sprint branch into main. Returns True on success.

        Raises MergeConflictError if there are conflicts.
        """
        if not self.available:
            return True  # No-op success for non-git projects

        branch = _validate_branch_name(self.sprint_branch_name(sprint_number))
        main = self.main_branch()

        # Commit any uncommitted work on the sprint branch
        self._auto_commit(f"Sprint {sprint_number} - final work")

        # Switch to main
        self._run(["git", "checkout", main])

        # Attempt merge
        result = self._run(["git", "merge", branch, "--no-edit"], check=False)
        if result.returncode != 0:
            # Check for conflicts
            conflicts = self._get_conflict_files()
            if conflicts:
                raise MergeConflictError(conflicts)
            # Some other merge error - abort and report
            self._run(["git", "merge", "--abort"], check=False)
            return False

        return True

    def abandon_sprint(self, sprint_number: int) -> bool:
        """Abandon a sprint branch - switch back to main, leave branch intact."""
        if not self.available:
            return True

        main = self.main_branch()

        # Commit any work so it's not lost
        self._auto_commit(f"Sprint {sprint_number} - abandoned (work preserved)")

        self._run(["git", "checkout", main])
        return True

    def ensure_on_sprint_branch(self, sprint_number: int) -> None:
        """Make sure we're on the sprint branch (e.g., after escalation).

        Handles the case where the branch was deleted or never created.
        Attempts reflog recovery before falling back to recreating from main.
        """
        if not self.available:
            return
        branch = _validate_branch_name(self.sprint_branch_name(sprint_number))
        current = self._run(["git", "branch", "--show-current"], check=False).stdout.strip()
        if current != branch:
            self._auto_commit("WIP - switching branches")
            if not self.branch_exists(branch):
                recovered = self.recover_branch(branch)
                if not recovered:
                    logger.warning("Sprint branch %s missing - recreating from %s", branch, self.main_branch())
                    self.create_sprint_branch(sprint_number)
            else:
                self._run(["git", "checkout", branch])

    # ------------------------------------------------------------------
    # Rebase & divergence handling
    # ------------------------------------------------------------------

    def rebase_sprint_onto_main(self, sprint_number: int) -> bool:
        """Rebase the sprint branch onto the current tip of main.

        Keeps sprint history linear against an updated main. If conflicts
        arise during rebase, the rebase is aborted and False is returned
        so the caller can fall back to a merge strategy.
        """
        if not self.available:
            return True

        branch = _validate_branch_name(self.sprint_branch_name(sprint_number))
        main = self.main_branch()

        if not self.branch_exists(branch):
            logger.warning("Cannot rebase - sprint branch %s does not exist", branch)
            return False

        # Commit any uncommitted work first
        current = self._run(["git", "branch", "--show-current"], check=False).stdout.strip()
        if current == branch:
            self._auto_commit("WIP - before rebase")

        # Switch to the sprint branch
        self._run(["git", "checkout", branch])

        # Check if rebase is needed (sprint is already up to date with main)
        merge_base = self._run(["git", "merge-base", branch, main], check=False)
        main_tip = self._run(["git", "rev-parse", main], check=False)
        if (
            merge_base.returncode == 0
            and main_tip.returncode == 0
            and merge_base.stdout.strip() == main_tip.stdout.strip()
        ):
            return True  # Already up to date

        result = self._run(["git", "rebase", main], check=False)
        if result.returncode != 0:
            logger.warning(
                "Rebase of %s onto %s failed - aborting: %s",
                branch, main, result.stderr.strip()[:200],
            )
            self._run(["git", "rebase", "--abort"], check=False)
            return False

        return True

    def check_divergence(self, sprint_number: int) -> dict[str, Any]:
        """Check how far a sprint branch has diverged from main.

        Returns a dict with:
          - ahead: commits on sprint not on main
          - behind: commits on main not on sprint
          - diverged: True if both ahead and behind are > 0
          - merge_base: the common ancestor commit
        """
        if not self.available:
            return {"ahead": 0, "behind": 0, "diverged": False, "merge_base": None}

        branch = _validate_branch_name(self.sprint_branch_name(sprint_number))
        main = self.main_branch()

        if not self.branch_exists(branch):
            return {"ahead": 0, "behind": 0, "diverged": False, "merge_base": None}

        # rev-list --left-right --count main...branch gives "behind\tahead"
        result = self._run(
            ["git", "rev-list", "--left-right", "--count", f"{main}...{branch}"],
            check=False,
        )
        if result.returncode != 0:
            return {"ahead": 0, "behind": 0, "diverged": False, "merge_base": None}

        parts = result.stdout.strip().split()
        behind = int(parts[0]) if len(parts) >= 1 else 0
        ahead = int(parts[1]) if len(parts) >= 2 else 0

        merge_base_result = self._run(
            ["git", "merge-base", main, branch], check=False,
        )
        merge_base = (
            merge_base_result.stdout.strip()[:12]
            if merge_base_result.returncode == 0
            else None
        )

        return {
            "ahead": ahead,
            "behind": behind,
            "diverged": ahead > 0 and behind > 0,
            "merge_base": merge_base,
        }

    def recover_branch(self, branch: str) -> bool:
        """Try to recover a deleted branch using the reflog.

        Searches the reflog for the last known commit on the branch
        and recreates it. Returns True if recovery succeeded.
        """
        if not self.available:
            return False

        branch = _validate_branch_name(branch)

        # Search reflog for the branch name
        result = self._run(
            ["git", "reflog", "show", "--format=%H", branch],
            check=False,
        )
        if result.returncode == 0 and result.stdout.strip():
            # First line is the most recent commit on that branch
            last_commit = result.stdout.strip().splitlines()[0]
            recreate = self._run(
                ["git", "branch", branch, last_commit], check=False,
            )
            if recreate.returncode == 0:
                logger.info("Recovered branch %s from reflog at %s", branch, last_commit[:12])
                self._run(["git", "checkout", branch])
                return True

        # Fallback: search general HEAD reflog for checkout entries.
        # When we see "checkout: moving from {branch} to X", the %H on that
        # line is the destination commit (X's tip), not the branch's tip.
        # The PREVIOUS reflog entry (next line, since output is newest-first)
        # has the branch's last HEAD value.
        result = self._run(
            ["git", "reflog", "--format=%H %gs"],
            check=False,
        )
        if result.returncode == 0:
            lines = result.stdout.splitlines()
            for i, line in enumerate(lines):
                if f"checkout: moving from {branch} " in line:
                    if i + 1 < len(lines):
                        commit = lines[i + 1].split()[0]
                        recreate = self._run(
                            ["git", "branch", branch, commit], check=False,
                        )
                        if recreate.returncode == 0:
                            logger.info(
                                "Recovered branch %s from reflog at %s",
                                branch, commit[:12],
                            )
                            self._run(["git", "checkout", branch])
                            return True

        return False

    # ------------------------------------------------------------------
    # Utility methods
    # ------------------------------------------------------------------

    def branch_exists(self, branch: str) -> bool:
        """Check whether a local branch exists."""
        if not self.available:
            return False
        result = self._run(["git", "rev-parse", "--verify", branch], check=False)
        return result.returncode == 0

    def current_branch(self) -> str | None:
        """Return current branch name, or None if not in a git repo."""
        if not self.available:
            return None
        result = self._run(["git", "branch", "--show-current"], check=False)
        return result.stdout.strip() if result.returncode == 0 else None

    def has_uncommitted_changes(self) -> bool:
        """Check if there are uncommitted changes in the working tree."""
        if not self.available:
            return False
        result = self._run(["git", "status", "--porcelain"], check=False)
        return bool(result.stdout.strip())

    def _auto_commit(self, message: str) -> bool:
        """Stage and commit all changes if there are any. Returns True if committed."""
        if not self.has_uncommitted_changes():
            return False
        self._run(["git", "add", "-A"])
        result = self._run(["git", "commit", "-m", message], check=False)
        return result.returncode == 0

    def _check_git(self) -> bool:
        """Check if git is available and we're in a repo."""
        try:
            result = self._run(["git", "rev-parse", "--is-inside-work-tree"], check=False)
            return result.returncode == 0 and result.stdout.strip() == "true"
        except FileNotFoundError:
            return False

    def _run(
        self,
        cmd: list[str],
        check: bool = True,
    ) -> subprocess.CompletedProcess[str]:
        """Run a git command as an argument list (never a shell string)."""
        result = subprocess.run(
            cmd,
            shell=False,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            cwd=self.root,
            timeout=GIT_COMMAND_TIMEOUT,
        )
        # Log notable git operations (merges, branch deletes, force ops, commits)
        op = cmd[1] if len(cmd) > 1 else ""
        if op in ("merge", "branch", "commit", "checkout", "worktree", "reset"):
            logger.debug(
                "git %s → exit %d | %s",
                " ".join(cmd[1:]),
                result.returncode,
                result.stdout.strip()[:200] or result.stderr.strip()[:200],
            )
            self._write_git_log(cmd, result.returncode)
        return result

    def _write_git_log(self, cmd: list[str], exit_code: int) -> None:
        """Append git operation to .odd/logs/git.jsonl if .odd/ exists."""
        try:
            odd_dir = self.root / ".odd"
            if not odd_dir.exists():
                return  # No .odd/ directory - skip logging (e.g. in tests)
            log_path = odd_dir / "logs" / "git.jsonl"
            log_path.parent.mkdir(parents=True, exist_ok=True)
            record = {
                "ts": datetime.now(timezone.utc).isoformat(),
                "cmd": cmd,
                "exit_code": exit_code,
            }
            with log_path.open("a", encoding="utf-8") as f:
                f.write(json.dumps(record) + "\n")
        except Exception:
            logger.debug("Failed to write git log entry", exc_info=True)
