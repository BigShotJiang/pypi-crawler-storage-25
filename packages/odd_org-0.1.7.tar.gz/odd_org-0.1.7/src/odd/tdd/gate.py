"""TDD quality gate - test/retry loop, escalation handling.

Owns the mechanical TDD cycle: invoke agent -> run tests -> retry on failure.
Declares its dependencies explicitly via __init__ and is independently testable.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Callable, TYPE_CHECKING

from rich.panel import Panel
from rich.prompt import Prompt

from odd.config import PHASE_TOKEN_DEFAULTS, TDD_MAX_RETRIES
from odd.labels import escalation_label, escalation_style
from odd.models import (
    CEOGate,
    CEOStyle,
    RoleType,
    TaskStatus,
)
from odd.tools import SUBMIT_DEPENDENCY_REQUEST, SUBMIT_TEST_CHANGE_REQUEST

from odd.tdd.ecosystem import detect_ecosystem
from odd.tdd.test_infra import (
    run_tests as _run_tests,
    discover_test_files as _discover_test_files,
    collect_test_names as _collect_test_names,
    preflight_test_runner as _preflight_test_runner,
    _run_approved_command,
)

if TYPE_CHECKING:
    from odd.agent import AgentEngine
    from odd.models import Persona, Sprint, SprintTask
    from odd.provider import StreamCallback
    from odd.state import StateManager

from odd._console import console, _tprint


class TDDGate:
    """Mechanical TDD quality gate.

    Runs the invoke -> test -> retry loop and handles escalations.
    Each dependency is declared explicitly so the gate can be tested
    without constructing a full SprintEngine.
    """

    def __init__(
        self,
        state: StateManager,
        gate: Callable[[CEOGate], CEOStyle],
        main_engine: AgentEngine,
    ):
        self.state = state
        self._gate = gate
        self._main_engine = main_engine
        self._ecosystem: dict[str, Any] | None = None

    # --- Ecosystem detection (delegates to tdd.ecosystem) ---

    def _detect_ecosystem(self, cwd: Path | None = None) -> dict[str, Any]:
        """Detect the project's test ecosystem from root files.

        Cached after first call when cwd is None (project root).
        """
        if self._ecosystem is not None and cwd is None:
            return self._ecosystem

        root = cwd or self.state.root
        eco = detect_ecosystem(root)

        if cwd is None:
            self._ecosystem = eco
        return eco

    # --- Test runners (delegate to tdd.test_infra) ---

    def run_tests(self, cwd: Path | None = None) -> tuple[bool, str]:
        """Mechanically run the project's test framework and return (passed, output)."""
        base = cwd or self.state.root
        eco = self._detect_ecosystem(cwd)
        return _run_tests(base, eco)

    def discover_test_files(self, cwd: Path | None = None) -> list[str]:
        """Find test files in the project so agents know what QA wrote."""
        base = cwd or self.state.root
        eco = self._detect_ecosystem(cwd)
        return _discover_test_files(base, eco)

    def collect_test_names(self, cwd: Path | None = None) -> list[str]:
        """Run the test framework's collection command to list tests."""
        base = cwd or self.state.root
        eco = self._detect_ecosystem(cwd)
        return _collect_test_names(base, eco)

    def preflight_test_runner(self) -> bool:
        """Verify the test runner is installed; offer to install if missing."""
        eco = self._detect_ecosystem()
        return _preflight_test_runner(self.state.root, eco)

    def get_max_retries(self) -> int:
        """Get the TDD retry limit from CEO config, falling back to default."""
        try:
            config = self.state.load_config()
            return config.tdd_max_retries
        except Exception:
            return TDD_MAX_RETRIES

    # --- Prompt builders ---

    def build_impl_prompt(
        self,
        sprint_number: int,
        task_description: str,
        test_context: str,
        notes_path: str,
        agent_name: str,
    ) -> str:
        """Build the standard implementation prompt for a task."""
        eco = self._detect_ecosystem()
        runner = eco["runner_name"]
        agent_slug = agent_name.lower().replace(" ", "_")
        return (
            f"Your task for Sprint {sprint_number}:\n\n"
            f"{task_description}\n\n"
            f"Tests have already been written by QA. Your job is to make them pass."
            f"{test_context}\n\n"
            f"Read the test files to understand what's expected, then implement "
            f"the code to make them pass. The system will verify tests mechanically "
            f"(using {runner}) after you finish - you don't need to run tests "
            f"yourself, but you can if you want to check your work as you go.\n\n"
            f"When you're done, write a brief note about what you did, any "
            f"issues you hit, and anything the team should know to "
            f"{notes_path}/{agent_slug}.md"
        )

    def build_fix_prompt(self, test_output: str, review_feedback: str = "") -> str:
        """Build the TDD retry prompt from test output and optional review feedback."""
        eco = self._detect_ecosystem()
        runner = eco["runner_name"]
        prompt = (
            f"The system ran {runner} after your implementation and tests are failing:\n\n"
            f"```\n{test_output[:3000]}\n```\n\n"
        )
        if review_feedback:
            prompt += f"{review_feedback}\n\n"
        prompt += (
            f"Fix the failing tests. Do NOT modify the test files - fix your "
            f"implementation to match what QA specified.\n\n"
            f"If you believe a test is genuinely wrong (not just hard to pass), "
            f"use the submit_test_change_request tool to request a change from QA."
        )
        return prompt

    @staticmethod
    def format_review_feedback(outcomes: list[dict[str, Any]]) -> str:
        """Format test review outcomes into feedback for the implementation agent."""
        if not outcomes:
            return ""
        parts: list[str] = []
        for o in outcomes:
            if o["verdict"] == "accept":
                if o["tests_pass"]:
                    parts.append(
                        f"QA accepted your change request for {o['test_file']} and "
                        f"modified the test. Tests are now passing."
                    )
                else:
                    parts.append(
                        f"QA accepted your change request for {o['test_file']} and "
                        f"modified the test, but tests are still failing. "
                        f"Here's why she accepted: {o['reason']}"
                    )
            else:
                parts.append(
                    f"QA rejected your change request for {o['test_file']}: "
                    f"{o['reason']}. Fix your implementation to match the test."
                )
        return "**Test Review Feedback from QA:**\n" + "\n".join(f"- {p}" for p in parts)

    # --- Escalation handling ---

    def should_surface_escalation(self, severity: str) -> bool:
        """Determine if an escalation should be surfaced to the CEO based on style.

        HANDS_ON: info + needs_decision + blocker (everything)
        BALANCED: needs_decision + blocker
        DELEGATOR: blocker only
        command_request: always surfaced (CEO must approve/deny)
        """
        if severity == "command_request":
            return True
        style = self._gate(CEOGate.ESCALATIONS)
        if style == CEOStyle.HANDS_ON:
            return True
        if style == CEOStyle.BALANCED:
            return severity in ("needs_decision", "blocker")
        # DELEGATOR
        return severity == "blocker"

    def drain_escalations(
        self,
        engine: AgentEngine,
        agent: Persona,
        project_context: str,
        task_description: str,
        interactive: bool,
    ) -> bool:
        """Process escalations from the given engine.

        Escalations are filtered by CEO style - non-surfaced ones are
        auto-resolved (silently dropped).

        Interactive: prompts CEO for blockers/decisions via _handle_escalations.
        Non-interactive: displays surfaced escalations, re-queues blocker and
        needs_decision escalations on the engine for post-phase CEO review.

        Returns True if a blocker was re-queued (non-interactive only),
        signalling the caller to stop retrying until the CEO resolves it.
        """
        if interactive:
            self._handle_escalations(agent, project_context, task_description=task_description)
            return False

        # Non-interactive (worktree thread): filter, display, keep actionable ones
        all_escs = list(engine.escalations)
        engine.escalations.clear()

        for esc in all_escs:
            if not self.should_surface_escalation(esc["severity"]):
                continue
            deferred = esc["severity"] in ("blocker", "needs_decision", "command_request")
            suffix = (
                "\n\n[dim italic]CEO will be prompted after this phase completes.[/dim italic]"
                if deferred else ""
            )
            _tprint(Panel(
                f"[bold]{agent.name}[/bold] - {escalation_label(esc['severity'])}:\n\n{esc['reason']}{suffix}",
                title="Escalation (queued for CEO)",
                style=escalation_style(esc["severity"]),
            ))

        # Re-queue blocker/decision/command_request escalations for main thread
        requeued = [
            e for e in all_escs
            if e["severity"] in ("blocker", "needs_decision", "command_request")
            and self.should_surface_escalation(e["severity"])
        ]
        engine.escalations.extend(requeued)
        return bool(requeued)

    def _handle_escalations(
        self,
        agent: Persona,
        project_context: str,
        task_description: str = "",
    ) -> None:
        """Handle any escalations from the last agent invocation.

        Uses the main engine for interactive escalation resolution.
        Filtered by CEO style - non-surfaced escalations are auto-resolved.
        """
        escalations = self._main_engine.get_escalations()
        for esc in escalations:
            if not self.should_surface_escalation(esc["severity"]):
                continue

            console.print(Panel(
                f"[bold]{agent.name}[/bold] - {escalation_label(esc['severity'])}:\n\n{esc['reason']}",
                title="Escalation",
                style=escalation_style(esc["severity"]),
            ))
            if esc["severity"] == "command_request":
                command = esc.get("command", "")
                console.print(f"\n  [bold]Command:[/bold] [cyan]{command}[/cyan]")
                ceo_response = Prompt.ask(
                    "[bold yellow]CEO[/bold yellow] (approve / deny / edit)",
                    default="approve",
                )
                choice = ceo_response.lower().strip()
                if choice == "deny":
                    task_context = f"\n\nYour original task was:\n{task_description}" if task_description else ""
                    self._main_engine.invoke(
                        persona=agent,
                        user_message=(
                            f"The CEO denied your request to run: {command}\n\n"
                            f"Find another way to proceed.{task_context}"
                        ),
                        project_context=project_context,
                    )
                else:
                    # "approve" or anything else = treat as the command to run
                    # (typing a different command = edit)
                    cmd_to_run = command if choice in ("approve", "y", "yes", "") else ceo_response
                    output = _run_approved_command(cmd_to_run, self.state.root)
                    console.print(Panel(
                        output[:2000] + ("..." if len(output) > 2000 else ""),
                        title=f"Output: {cmd_to_run}",
                        style="dim",
                    ))
                    task_context = f"\n\nYour original task was:\n{task_description}" if task_description else ""
                    self._main_engine.invoke(
                        persona=agent,
                        user_message=(
                            f"The CEO approved and ran your requested command.\n\n"
                            f"$ {cmd_to_run}\n{output}{task_context}\n\n"
                            f"Please continue with your task."
                        ),
                        project_context=project_context,
                    )
            elif esc["severity"] == "blocker":
                ceo_response = Prompt.ask("[bold yellow]CEO[/bold yellow] (blocker - your input needed)")
                task_context = f"\n\nYour original task was:\n{task_description}" if task_description else ""
                self._main_engine.invoke(
                    persona=agent,
                    user_message=f"The CEO responded to your escalation:\n\n{ceo_response}{task_context}\n\nPlease continue with your task.",
                    project_context=project_context,
                )
            elif esc["severity"] == "needs_decision":
                ceo_response = Prompt.ask("[bold yellow]CEO[/bold yellow] (decision needed, or 'skip' to let agent proceed)")
                if ceo_response.lower().strip() != "skip":
                    self._main_engine.invoke(
                        persona=agent,
                        user_message=f"The CEO says:\n\n{ceo_response}",
                        project_context=project_context,
                    )

    # --- Main TDD gate ---

    def execute(
        self,
        engine: AgentEngine,
        agent: Persona,
        task: SprintTask,
        sprint: Sprint,
        impl_prompt: str,
        project_context: str,
        *,
        team: dict[str, Persona] | None = None,
        cwd: Path | None = None,
        stream_cb: StreamCallback | None = None,
        cancel_check: Callable[[], bool] | None = None,
        interactive: bool = True,
        on_test_change_requests: Callable | None = None,
        on_dependency_requests: Callable | None = None,
        on_tool_result: Callable[[str, dict, str], None] | None = None,
    ) -> None:
        """Shared TDD gate: invoke -> test -> retry loop -> status -> tracking.

        Used by both _run_task (interactive, main branch) and
        _run_task_in_worktree (non-interactive, worktree).

        When interactive=True, team must be provided. Escalations prompt the
        CEO inline, and test-change/dependency requests are routed via the
        provided callbacks.

        When interactive=False, escalations are displayed but blocker/decision
        escalations are re-queued on the engine for post-phase handling.

        Callbacks:
            on_test_change_requests(sprint, team, project_context, cwd=cwd) -> list[dict]
            on_dependency_requests(team, project_context) -> None
        """
        # --- Initial invoke ---
        engine.invoke(
            persona=agent,
            user_message=impl_prompt,
            project_context=project_context,
            max_tokens=PHASE_TOKEN_DEFAULTS["implementation"],
            extra_tools=[SUBMIT_TEST_CHANGE_REQUEST, SUBMIT_DEPENDENCY_REQUEST],
            stream=stream_cb,
            cancel_check=cancel_check,
            phase="implementation",
            on_tool_result=on_tool_result,
        )

        blocked = self.drain_escalations(engine, agent, project_context, task.description, interactive)
        review_feedback = ""
        if interactive and on_test_change_requests and on_dependency_requests:
            outcomes = on_test_change_requests(
                sprint, team, project_context, cwd=cwd,
            )
            review_feedback = self.format_review_feedback(outcomes)
            on_dependency_requests(team, project_context)

        # --- Mechanical TDD gate ---
        # Skip tests entirely if agent is already blocked (e.g. missing
        # dependency) - running tests would just fail for the same reason
        # and waste retries the agent can't resolve mid-phase.
        if blocked:
            passed, test_output = False, "(skipped - agent blocked on escalation)"
        else:
            passed, test_output = self.run_tests(cwd=cwd)
        max_retries = self.get_max_retries()

        retries = 0
        while not passed and not blocked and retries < max_retries:
            retries += 1
            if interactive:
                console.print(Panel(
                    f"Tests failing after {agent.name}'s implementation "
                    f"(attempt {retries}/{max_retries})",
                    style="yellow",
                ))
            else:
                _tprint(f"[yellow]  {agent.name}: tests failing, retry {retries}/{max_retries}[/yellow]")

            fix_prompt = self.build_fix_prompt(test_output, review_feedback)
            review_feedback = ""  # Only include once

            engine.invoke(
                persona=agent,
                user_message=fix_prompt,
                project_context=project_context,
                max_tokens=PHASE_TOKEN_DEFAULTS["implementation"],
                extra_tools=[SUBMIT_TEST_CHANGE_REQUEST, SUBMIT_DEPENDENCY_REQUEST],
                stream=stream_cb,
                cancel_check=cancel_check,
                phase="implementation",
                on_tool_result=on_tool_result,
            )

            blocked = self.drain_escalations(engine, agent, project_context, task.description, interactive)
            if interactive and on_test_change_requests and on_dependency_requests:
                outcomes = on_test_change_requests(
                    sprint, team, project_context, cwd=cwd,
                )
                review_feedback = self.format_review_feedback(outcomes)
                on_dependency_requests(team, project_context)

            passed, test_output = self.run_tests(cwd=cwd)

        # --- CEO retry extension (interactive only) ---
        if not passed and interactive:
            passed, test_output = self._ceo_retry_extension(
                engine, agent, task, sprint, project_context,
                test_output, review_feedback, max_retries,
                team=team, cwd=cwd, stream_cb=stream_cb, cancel_check=cancel_check,
                on_test_change_requests=on_test_change_requests,
                on_dependency_requests=on_dependency_requests,
                on_tool_result=on_tool_result,
            )

        # --- Status update ---
        if passed:
            task.status = TaskStatus.DONE
            if interactive:
                console.print(f"[green]{agent.name} completed: {task.description} (tests passing)[/green]")
            else:
                _tprint(f"[green]{agent.name} completed: {task.description} (tests passing)[/green]")
        else:
            task.status = TaskStatus.FAILED
            fail_reason = (
                f"Task failed TDD gate after {max_retries} retries: "
                f"{task.description}\n\nLatest output:\n{test_output[:500]}"
            )
            if interactive:
                console.print(f"[red]{agent.name} could not pass tests: {task.description}[/red]")
            else:
                _tprint(f"[red]{agent.name} could not pass tests: {task.description}[/red]")
            engine.escalations.append({
                "reason": fail_reason,
                "severity": "needs_decision",
            })

        # Record outcome for consultant reputation tracking
        if agent.role_type == RoleType.CONSULTANT:
            self.state.record_task_outcome(
                name=agent.name,
                sprint_number=sprint.number,
                task_id=task.id,
                task_description=task.description,
                passed=passed,
                retries=retries,
            )

    def _ceo_retry_extension(
        self,
        engine: AgentEngine,
        agent: Persona,
        task: SprintTask,
        sprint: Sprint,
        project_context: str,
        test_output: str,
        review_feedback: str,
        max_retries: int,
        *,
        team: dict[str, Persona] | None = None,
        cwd: Path | None = None,
        stream_cb: StreamCallback | None = None,
        cancel_check: Callable[[], bool] | None = None,
        on_test_change_requests: Callable | None = None,
        on_dependency_requests: Callable | None = None,
        on_tool_result: Callable[[str, dict, str], None] | None = None,
    ) -> tuple[bool, str]:
        """Prompt CEO for extra retries after the mechanical TDD gate exhausts its limit.

        Returns (passed, test_output) after the extension attempts (or immediately
        if the CEO chooses to fail).
        """
        console.print(Panel(
            f"[bold red]{agent.name}[/bold red] exhausted {max_retries} retries on: "
            f"{task.description}\n\n"
            f"Latest test output:\n[dim]{test_output[:500]}[/dim]",
            title="TDD Gate - Retry Limit Reached",
            style="red",
        ))
        ceo_choice = Prompt.ask(
            "[bold yellow]CEO[/bold yellow]: Keep trying, or mark failed?",
            choices=["retry", "fail"],
            default="fail",
        )
        if ceo_choice != "retry":
            return False, test_output

        try:
            extra = int(Prompt.ask("How many more attempts?", default="2"))
        except ValueError:
            extra = 2
        passed = False
        for _ in range(extra):
            fix_prompt = self.build_fix_prompt(test_output, review_feedback)
            review_feedback = ""
            engine.invoke(
                persona=agent,
                user_message=fix_prompt,
                project_context=project_context,
                max_tokens=PHASE_TOKEN_DEFAULTS["implementation"],
                extra_tools=[SUBMIT_TEST_CHANGE_REQUEST, SUBMIT_DEPENDENCY_REQUEST],
                stream=stream_cb,
                cancel_check=cancel_check,
                phase="implementation",
                on_tool_result=on_tool_result,
            )
            self.drain_escalations(engine, agent, project_context, task.description, True)
            if on_test_change_requests and on_dependency_requests:
                outcomes = on_test_change_requests(
                    sprint, team, project_context, cwd=cwd,
                )
                review_feedback = self.format_review_feedback(outcomes)
                on_dependency_requests(team, project_context)
            passed, test_output = self.run_tests(cwd=cwd)
            if passed:
                break
        return passed, test_output
