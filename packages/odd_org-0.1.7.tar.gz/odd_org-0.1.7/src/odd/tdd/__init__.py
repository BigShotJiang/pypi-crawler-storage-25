"""TDD subpackage - test infrastructure, ecosystem detection, quality gate.

External consumers should import from here:
    from odd.tdd import TDDGate
"""

from odd.tdd.gate import TDDGate

__all__ = ["TDDGate"]
