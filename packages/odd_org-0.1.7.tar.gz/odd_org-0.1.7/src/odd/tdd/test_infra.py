"""Test infrastructure - mechanical test running, discovery, preflight.

Standalone functions that accept project root and ecosystem config,
used by TDDGate methods.
"""

from __future__ import annotations

import re
import shlex
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

from odd.config import TDD_PYTEST_TIMEOUT


# --- Command helpers (module-level) ---


def _resolve_argv(argv: list[str]) -> list[str]:
    """Resolve the first element of an argv list via shutil.which.

    On Windows, tools like npm/npx are installed as .CMD batch files which
    subprocess.run(shell=False) cannot launch by bare name. Resolving
    through shutil.which returns the full path (e.g. npm.CMD) which
    CreateProcess can handle.
    """
    if not argv:
        return argv
    resolved = shutil.which(argv[0])
    if resolved:
        return [resolved] + argv[1:]
    return argv


def _extract_cd_prefix(command: str, default_cwd: Path | None) -> tuple[Path | None, str]:
    """Parse 'cd <dir> && <cmd>' into (cwd, cmd).

    Agents often send compound commands like:
        cd "C:\\project\\.odd\\worktrees\\s1_t4" && npm install
    which fail with shell=False. This extracts the directory and returns
    just the actual command to run.

    Returns (cwd, command) - cwd may be the extracted dir, the default,
    or None if no cd prefix was found.
    """
    m = re.match(r'^cd\s+(".*?"|\'.*?\'|\S+)\s*&&\s*(.+)$', command, re.IGNORECASE)
    if m:
        cd_dir = m.group(1).strip('"').strip("'")
        rest = m.group(2).strip()
        return Path(cd_dir), rest
    return default_cwd, command


def _run_approved_command(command: str, cwd: Path | None = None) -> str:
    """Run a CEO-approved command with no allowlist restrictions.

    This bypasses the normal agent command sandbox because the CEO
    has explicitly approved this specific command.

    Handles compound commands (cd ... && cmd) by extracting the
    directory as cwd and running the remaining command.
    """
    try:
        # Handle "cd <dir> && <actual command>" - extract dir as cwd
        run_cwd, actual_cmd = _extract_cd_prefix(command, cwd)

        if sys.platform == "win32":
            argv = shlex.split(actual_cmd, posix=False)
            argv = [t.strip('"').strip("'") for t in argv]
        else:
            argv = shlex.split(actual_cmd)
        argv = _resolve_argv(argv)
        result = subprocess.run(
            argv,
            shell=False,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=120,
            cwd=run_cwd,
        )
        output = ""
        if result.stdout:
            output += result.stdout
        if result.stderr:
            output += ("\n" if output else "") + result.stderr
        if result.returncode != 0:
            output += f"\n(exit code {result.returncode})"
        return output or "(no output)"
    except FileNotFoundError:
        return f"Error: command not found: {command}"
    except subprocess.TimeoutExpired:
        return f"Error: command timed out after 120s: {command}"


# --- Test execution ---


def run_tests(root: Path, eco: dict[str, Any]) -> tuple[bool, str]:
    """Run the project's test framework and return (passed, output).

    This is NOT an LLM decision - it's a system-level quality gate.
    """
    cmd = _resolve_argv(eco["test_cmd"])
    runner = eco["runner_name"]
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=TDD_PYTEST_TIMEOUT,
            cwd=root,
        )
        output = result.stdout
        if result.stderr:
            output += "\n" + result.stderr
        passed = result.returncode == 0
        return passed, output.strip()
    except FileNotFoundError:
        return False, f"({runner} not found - install {runner} to enable the TDD quality gate)"
    except subprocess.TimeoutExpired:
        return False, f"({runner} timed out after {TDD_PYTEST_TIMEOUT}s)"


def discover_test_files(root: Path, eco: dict[str, Any]) -> list[str]:
    """Find test files in the project so agents know what QA wrote."""
    tests_dir = root / "tests"
    if not tests_dir.exists():
        tests_dir = root / "__tests__"
        if not tests_dir.exists():
            return []
    found = []
    for pattern in eco["file_patterns"]:
        found.extend(
            str(p.relative_to(root))
            for p in tests_dir.rglob(pattern)
        )
    return sorted(set(found))


def collect_test_names(root: Path, eco: dict[str, Any]) -> list[str]:
    """Run the test framework's collection command to list tests."""
    collect_cmd = eco["collect_cmd"]
    if not collect_cmd:
        return []
    try:
        result = subprocess.run(
            _resolve_argv(collect_cmd),
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=TDD_PYTEST_TIMEOUT,
            cwd=root,
        )
        if result.returncode != 0:
            return []
        lines = result.stdout.strip().splitlines()
        return [ln.strip() for ln in lines if ln.strip()]
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return []


def preflight_test_runner(root: Path, eco: dict[str, Any]) -> bool:
    """Verify the test runner is installed; offer to install if missing.

    Called once before the sprint starts so agents never hit a missing
    runner mid-sprint. Returns True if ready, False if CEO chose to
    cancel the sprint.
    """
    from odd._console import console
    import odd.sprint as _sprint_pkg

    runner = eco["runner_name"]

    # Quick check: can we invoke the runner at all?
    if _test_runner_available(eco, root):
        return True

    # Runner not available - figure out how to install it
    if eco["test_framework"] == "pytest":
        install_cmd = [sys.executable, "-m", "pip", "install", "pytest"]
        install_label = "pip install pytest"
    else:
        # JS ecosystem - need npm to install packages
        npm = shutil.which("npm")
        if npm is None:
            console.print(
                f"[yellow]This project uses [bold]{runner}[/bold] for tests, "
                f"but [bold]npm[/bold] is not installed.[/yellow]"
            )
            choice = _sprint_pkg.Prompt.ask(
                "[bold yellow]CEO[/bold yellow]: Install Node.js "
                "(includes npm) now? (winget install OpenJS.NodeJS)",
                choices=["y", "n"],
                default="y",
            )
            if choice != "y":
                return False
            ok = _run_install(
                ["winget", "install", "OpenJS.NodeJS", "--accept-source-agreements"],
                "Node.js", root, console,
            )
            if not ok:
                return False
            # npm should now be available - re-run full preflight
            # to install project deps (node_modules)
            return preflight_test_runner(root, eco)

        install_cmd = [npm, "install"]
        install_label = "npm install"

    console.print(
        f"[yellow]This project uses [bold]{runner}[/bold] for tests, "
        f"but it's not installed yet.[/yellow]"
    )
    choice = _sprint_pkg.Prompt.ask(
        f"[bold yellow]CEO[/bold yellow]: Install now? ({install_label})",
        choices=["y", "n"],
        default="y",
    )
    if choice != "y":
        return False

    return _run_install(install_cmd, runner, root, console)


def _run_install(cmd: list[str], label: str, cwd: Path, console) -> bool:
    """Run an install command, report success/failure."""
    resolved = _resolve_argv(cmd)
    console.print(f"[green]Running: {' '.join(cmd)}[/green]")
    try:
        result = subprocess.run(
            resolved,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=120,
            cwd=cwd,
        )
        if result.returncode == 0:
            console.print(f"[green]\u2713 {label} installed successfully.[/green]")
            return True
        else:
            console.print(
                f"[red]\u2717 Installation failed:[/red]\n{result.stderr[:500]}"
            )
            return False
    except FileNotFoundError:
        console.print(f"[red]\u2717 Command not found: {cmd[0]}[/red]")
        return False
    except subprocess.TimeoutExpired:
        console.print(f"[red]\u2717 Installation timed out.[/red]")
        return False


def _test_runner_available(eco: dict[str, Any], root: Path) -> bool:
    """Check if the test runner binary is available."""
    check_cmd = eco["test_cmd"][0]
    if shutil.which(check_cmd) is None:
        return False
    # For npx-based runners, also verify the package is locally installed
    if check_cmd == "npx":
        return (root / "node_modules" / eco["test_framework"]).exists()
    return True
