"""Ecosystem detection for TDD infrastructure.

Detects the project's test ecosystem (Python/pytest, JS/vitest, etc.)
from root files. Used by TDDGate and potentially by sprint planning.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any


def detect_ecosystem(root: Path) -> dict[str, Any]:
    """Detect the project's test ecosystem from root files.

    Returns a dict with test_framework, test_cmd, collect_cmd,
    file_patterns, and runner_name.
    """
    # --- JavaScript / TypeScript (package.json) ---
    pkg_path = root / "package.json"
    if pkg_path.exists():
        try:
            pkg = json.loads(pkg_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            pkg = {}

        deps = {
            *pkg.get("dependencies", {}),
            *pkg.get("devDependencies", {}),
        }

        test_fw = None
        for name in ("vitest", "jest", "@jest/core", "mocha", "ava"):
            if name in deps:
                test_fw = name.lstrip("@").split("/")[0]
                break
        if not test_fw:
            test_fw = "vitest" if "vite" in deps else "jest"

        return _js_ecosystem(test_fw)

    # --- Python (default) ---
    return _python_ecosystem()


def _python_ecosystem() -> dict[str, Any]:
    """Static config for Python/pytest ecosystem."""
    return {
        "test_framework": "pytest",
        "test_cmd": ["pytest", "--tb=short", "-q"],
        "collect_cmd": ["pytest", "--collect-only", "-q"],
        "file_patterns": ["test_*.py", "*_test.py"],
        "runner_name": "pytest",
    }


def _js_ecosystem(test_fw: str) -> dict[str, Any]:
    """Static config for JavaScript test ecosystems."""
    if test_fw == "vitest":
        return {
            "test_framework": "vitest",
            "test_cmd": ["npx", "vitest", "run", "--reporter=verbose"],
            "collect_cmd": ["npx", "vitest", "list"],
            "file_patterns": ["*.test.js", "*.test.ts", "*.spec.js", "*.spec.ts"],
            "runner_name": "vitest",
        }
    if test_fw == "jest":
        return {
            "test_framework": "jest",
            "test_cmd": ["npx", "jest", "--verbose"],
            "collect_cmd": ["npx", "jest", "--listTests"],
            "file_patterns": ["*.test.js", "*.test.ts", "*.spec.js", "*.spec.ts"],
            "runner_name": "jest",
        }
    # Fallback for mocha, ava, etc.
    return {
        "test_framework": test_fw,
        "test_cmd": ["npx", test_fw],
        "collect_cmd": None,
        "file_patterns": ["*.test.js", "*.test.ts", "*.spec.js", "*.spec.ts"],
        "runner_name": test_fw,
    }
