"""Auxiliary service enumeration.

This enum represents external auxiliary services (not LLM providers).
Examples:
- Embedding services: Voyage AI
- Web research services: Tavily (search), Firecrawl (scraping)

These are separate from the Provider enum which represents AI model providers.
"""

from enum import Enum


class ToolService(str, Enum):
    """
    External auxiliary services.

    Values must match the service keys stored in organization_credentials.provider_key
    for org_tool credential types.
    """

    # Embedding and reranking services
    VOYAGE_AI = "voyage"

    MODAL = "modal"

    # Web research services
    EXA = "exa"
    TAVILY = "tavily"
    FIRECRAWL = "firecrawl"

    @classmethod
    def from_str(cls, value: str) -> "ToolService":
        """
        Convert string to ToolService enum.

        Args:
            value: Service key string (e.g., "tavily", "firecrawl")

        Returns:
            ToolService enum value

        Raises:
            ValueError: If value is not a valid tool service
        """
        try:
            return cls(value)
        except ValueError as e:
            valid_services = ", ".join([s.value for s in cls])
            raise ValueError(
                f"Invalid tool service '{value}'. Valid services: {valid_services}"
            ) from e
