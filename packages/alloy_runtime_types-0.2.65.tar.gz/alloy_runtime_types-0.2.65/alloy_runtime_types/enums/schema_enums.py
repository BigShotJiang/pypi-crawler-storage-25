from enum import Enum


class SchemaFormat(str, Enum):
    """Supported schema formats for input/output validation."""

    JSON_SCHEMA = "json_schema"
    REGEX = "regex"
