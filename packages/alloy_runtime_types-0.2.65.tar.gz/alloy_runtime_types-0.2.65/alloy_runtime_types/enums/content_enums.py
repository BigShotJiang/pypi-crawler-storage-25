"""Enums for content domain."""

from enum import Enum


class ContentStorageType(str, Enum):
    """Storage type for content parts - determines which column stores the data."""

    TEXT = "text"  # content_text column (plain text content)
    STRUCTURED = "structured"  # content_structured column (JSON/structured content)


class ContentSortField(str, Enum):
    """Fields available for sorting content parts."""

    CREATED_AT = "created_at"
    UPDATED_AT = "updated_at"


class SortOrder(str, Enum):
    """Sort order direction."""

    ASC = "asc"
    DESC = "desc"
