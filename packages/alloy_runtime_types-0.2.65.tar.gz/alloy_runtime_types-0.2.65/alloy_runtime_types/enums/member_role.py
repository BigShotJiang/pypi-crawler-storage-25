"""Organization member role enumeration."""

from enum import Enum


class MemberRole(str, Enum):
    """Roles that can be assigned to organization members."""

    OWNER = "owner"
    ADMIN = "admin"
    MEMBER = "member"
    VIEWER = "viewer"
