"""Enums for agent-related operations."""

from enum import Enum


class AgentSortBy(str, Enum):
    """Sort options for listing agents."""

    UPDATED_AT = "updated_at"
    CREATED_AT = "created_at"
    NAME = "name"
    USAGE = "usage"
