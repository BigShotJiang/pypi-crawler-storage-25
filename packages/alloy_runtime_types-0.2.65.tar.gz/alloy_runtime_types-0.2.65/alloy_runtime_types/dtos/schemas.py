"""DTOs for schema operations."""

import re
from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, Field, field_validator

from alloy_runtime_types.enums.ownership_scope import OwnershipScope
from alloy_runtime_types.enums.schema_enums import SchemaFormat


class CreateSchemaRequest(BaseModel):
    """Request to create a new schema."""

    name: str = Field(
        ...,
        min_length=1,
        max_length=255,
        description="Schema name (unique per owner scope)",
    )
    schema_format: SchemaFormat = Field(
        ...,
        description="Format of the schema (json_schema or regex)",
    )
    schema_definition: str = Field(
        ...,
        min_length=1,
        description="Schema definition (JSON string for json_schema, pattern string for regex)",
    )
    description: str | None = Field(
        default=None,
        description="Optional description of the schema",
    )
    scope: OwnershipScope = Field(
        default=OwnershipScope.ORGANIZATION,
        description="Ownership scope: user, organization, or global. Defaults to organization scope when omitted.",
    )

    @field_validator("name")
    @classmethod
    def validate_name(cls, v: str) -> str:
        """Schema name must be lowercase alphanumeric with dots, dashes, or underscores."""
        if not re.match(r"^[a-z0-9._-]+$", v):
            raise ValueError(
                "Schema name must be lowercase alphanumeric with dots, dashes, or underscores only"
            )
        return v


class CreateSchemaResponse(BaseModel):
    """Response after creating a schema."""

    id: UUID
    schema_name: str
    version: int
    schema_format_id: str
    schema_definition: str
    description: str | None
    is_latest: bool
    organization_id: UUID | None
    user_id: UUID | None
    created_at: datetime


# ============================================================================
# List Schemas DTOs
# ============================================================================


class SchemaSummary(BaseModel):
    """Summary of a schema for list responses."""

    id: UUID
    schema_name: str
    version: int
    schema_format_id: str
    description: str | None
    is_latest: bool
    organization_id: UUID | None
    user_id: UUID | None
    created_at: datetime
    updated_at: datetime


class ListSchemasResponse(BaseModel):
    """Response for listing schemas."""

    schemas: list[SchemaSummary]
    total: int


# ============================================================================
# Get Schema DTOs
# ============================================================================


class GetSchemaResponse(BaseModel):
    """Response for retrieving a single schema."""

    id: UUID
    schema_name: str
    version: int
    schema_format_id: str
    schema_definition: str
    description: str | None
    is_latest: bool
    organization_id: UUID | None
    user_id: UUID | None
    created_at: datetime


# ============================================================================
# Update Schema DTOs
# ============================================================================


class UpdateSchemaRequest(BaseModel):
    """Request to update an existing schema.

    All fields are optional. Providing schema_definition creates a new version.
    Providing name or description updates metadata on all versions.

    Note: Schema format cannot be changed (would break existing references).
    """

    name: str | None = Field(
        default=None,
        min_length=1,
        max_length=255,
        description="New schema name. Must be unique within scope. "
        "Updates all versions of this schema.",
    )
    description: str | None = Field(
        default=None,
        description="Updated description. Set to empty string to clear.",
    )
    schema_definition: str | None = Field(
        default=None,
        min_length=1,
        description="New schema definition. Creates a new version when provided. "
        "Must match the existing schema format (json_schema or regex).",
    )

    @field_validator("name")
    @classmethod
    def validate_name(cls, v: str | None) -> str | None:
        """Schema name must be lowercase alphanumeric with dots, dashes, or underscores."""
        if v is not None and not re.match(r"^[a-z0-9._-]+$", v):
            raise ValueError(
                "Schema name must be lowercase alphanumeric with dots, dashes, or underscores only"
            )
        return v


class UpdateSchemaResponse(BaseModel):
    """Response after updating a schema."""

    id: UUID
    schema_name: str
    version: int
    schema_format_id: str
    schema_definition: str
    description: str | None
    is_latest: bool
    organization_id: UUID | None
    user_id: UUID | None
    created_at: datetime


# ============================================================================
# Delete Schema DTOs
# ============================================================================


class DeletedSchemaResponse(BaseModel):
    """Final state of a deleted schema."""

    id: UUID
    schema_name: str
    version: int
    schema_format_id: str
    schema_definition: str
    description: str | None
    is_latest: bool
    organization_id: UUID | None
    user_id: UUID | None
    created_at: datetime


class DeleteSchemaResponse(BaseModel):
    """Response for deleting a schema."""

    deleted_schema: DeletedSchemaResponse
