"""DTOs for tool operations."""

from typing import Any

from pydantic import BaseModel, Field


class ToolListItemResponse(BaseModel):
    id: str = Field(description="Tool identifier (e.g., 'rag_search', 'web_search')")
    description: str = Field(description="Human-readable description of the tool")
    parameter_schema: dict[str, Any] | None = Field(
        default=None,
        description="JSON Schema defining configurable parameters for this tool. "
        "None means tool has no configurable parameters.",
    )
    credential_configured: bool = Field(
        description="Whether the caller has the credentials and provider support required to use this tool."
    )


class ToolResponse(BaseModel):
    """Response model for a tool."""

    id: str = Field(description="Tool identifier (e.g., 'rag_search', 'web_search')")
    description: str = Field(description="Human-readable description of the tool")
    parameter_schema: dict[str, Any] | None = Field(
        default=None,
        description="JSON Schema defining configurable parameters for this tool. "
        "None means tool has no configurable parameters.",
    )


class ListToolsResponse(BaseModel):
    """Response for listing tools."""

    tools: list[ToolListItemResponse]
    total: int
