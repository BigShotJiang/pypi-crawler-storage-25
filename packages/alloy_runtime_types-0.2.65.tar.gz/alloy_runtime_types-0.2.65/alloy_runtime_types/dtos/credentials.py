"""DTOs for credential operations."""

from datetime import datetime
from decimal import Decimal
from typing import Any
from uuid import UUID

from pydantic import BaseModel, Field, field_validator, model_validator

from alloy_runtime_types.enums.provider import Provider
from alloy_runtime_types.enums.tool_service import ToolService


class CreateSystemCredentialRequest(BaseModel):
    """Request to create a system credential."""

    credential_type_id: str = Field(
        ...,
        description="Type of credential (e.g., 'org_provider', 'system_tool'). Determines validation rules.",
    )
    name: str = Field(..., description="Human-readable name for the credential.")
    plaintext_value: str = Field(
        ...,
        description="The actual credential value (API key, token, etc.). Will be encrypted and never returned.",
    )
    description: str | None = Field(
        default=None, description="Optional description of the credential's purpose."
    )
    expires_at: datetime | None = Field(
        default=None,
        description="Optional expiration timestamp. Credential becomes invalid after this time.",
    )
    configuration: dict[str, Any] | None = Field(
        default=None,
        description="Additional provider-specific configuration (e.g., base URL, headers).",
    )
    provider_key: Provider = Field(
        ...,
        description="AI provider this credential is for (e.g., 'openai', 'anthropic').",
    )
    priority: int = Field(
        default=0,
        description="Priority when multiple credentials match. Higher values preferred. Defaults to 0.",
    )
    is_default: bool = Field(
        default=False,
        description="If true, used as fallback when no specific credential requested.",
    )
    daily_request_limit: int | None = Field(
        default=None, description="Maximum API calls per day. Null means unlimited."
    )
    monthly_cost_limit_usd: Decimal | None = Field(
        default=None, description="Maximum monthly spend in USD. Null means unlimited."
    )
    requests_per_minute_limit: int | None = Field(
        default=None,
        description="Rate limit for requests per minute. Null means unlimited.",
    )

    @field_validator("plaintext_value")
    @classmethod
    def validate_plaintext_value(cls, v: str) -> str:
        """Reject empty strings for plaintext_value."""
        if not v or not v.strip():
            raise ValueError("plaintext_value cannot be empty or whitespace")
        return v


class SystemCredentialResponse(BaseModel):
    """Response for system credential data (excludes encrypted_value)."""

    # From core.credentials
    id: UUID = Field(..., description="Unique identifier for the credential.")
    credential_type_id: str = Field(
        ..., description="Type of credential (e.g., 'org_provider', 'system_tool')."
    )
    name: str = Field(..., description="Human-readable name for the credential.")
    description: str | None = Field(
        ..., description="Optional description of the credential's purpose."
    )
    value_prefix: str | None = Field(
        ...,
        description="First few characters of the credential value for identification (e.g., 'sk-...').",
    )
    is_active: bool = Field(
        ..., description="Whether the credential is currently active and usable."
    )
    expires_at: datetime | None = Field(
        ..., description="Expiration timestamp, or null if no expiration."
    )
    last_used_at: datetime | None = Field(
        ..., description="Last time this credential was used, or null if never used."
    )
    configuration: dict[str, Any] | None = Field(
        ..., description="Additional provider-specific configuration."
    )
    created_at: datetime = Field(..., description="When the credential was created.")
    updated_at: datetime = Field(
        ..., description="When the credential was last updated."
    )

    # From core.system_credentials
    provider_key: Provider = Field(
        ..., description="AI provider this credential is for."
    )
    priority: int = Field(
        ..., description="Priority when selecting among multiple credentials."
    )
    is_default: bool = Field(
        ..., description="Whether this is the default credential for its type."
    )
    daily_request_limit: int | None = Field(
        ..., description="Maximum daily requests allowed, or null for unlimited."
    )
    monthly_cost_limit_usd: Decimal | None = Field(
        ..., description="Monthly spend limit in USD, or null for unlimited."
    )
    requests_per_minute_limit: int | None = Field(
        ..., description="Rate limit (requests/min), or null for unlimited."
    )
    current_daily_requests: int = Field(
        ..., description="Number of requests used today (resets daily)."
    )
    current_monthly_cost_usd: Decimal = Field(
        ..., description="Current month's spend in USD."
    )


class UpdateCredentialRequest(BaseModel):
    """Request to update a credential (partial update). Works for any credential type."""

    name: str | None = Field(default=None, min_length=1, max_length=255)
    description: str | None = Field(default=None, max_length=1000)
    plain_text_api_key: str | None = Field(
        default=None,
        min_length=1,
        description="Plaintext API key to be encrypted. Prefix will be computed automatically.",
    )

    @model_validator(mode="after")
    def validate_at_least_one_field(self) -> "UpdateCredentialRequest":
        """Ensure at least one field is provided for update."""
        if not any([self.name, self.description, self.plain_text_api_key]):
            raise ValueError("At least one field must be provided for update")
        return self


class CredentialResponse(BaseModel):
    """Generic response for credential data (excludes encrypted_value).

    Works for both system and organization credentials. Type-specific fields
    are optional and populated based on credential type.
    """

    # Common fields from core.credentials
    id: UUID = Field(..., description="Unique identifier for the credential.")
    credential_type_id: str = Field(
        ..., description="Type of credential (e.g., 'org_provider', 'system_tool')."
    )
    name: str = Field(..., description="Human-readable name for the credential.")
    description: str | None = Field(
        ..., description="Optional description of the credential's purpose."
    )
    value_prefix: str | None = Field(
        ...,
        description="First few characters of the credential value for identification.",
    )
    is_active: bool = Field(
        ..., description="Whether the credential is currently active."
    )
    expires_at: datetime | None = Field(
        ..., description="Expiration timestamp, or null if no expiration."
    )
    last_used_at: datetime | None = Field(
        ..., description="Last usage timestamp, or null if never used."
    )
    configuration: dict[str, Any] | None = Field(
        ..., description="Additional provider-specific configuration."
    )
    created_at: datetime = Field(..., description="When the credential was created.")
    updated_at: datetime = Field(
        ..., description="When the credential was last updated."
    )

    # Provider key for AI provider credentials (org_provider, system_provider)
    provider_key: Provider | None = Field(
        default=None, description="AI provider, if this is a provider credential."
    )

    # Tool service key for tool credentials (org_tool, system_tool)
    tool_service_key: ToolService | None = Field(
        default=None, description="Tool service, if this is a tool credential."
    )

    # Organization credential fields (optional)
    organization_id: UUID | None = Field(
        default=None, description="Owning organization ID, if org-scoped credential."
    )

    # System credential fields (optional)
    priority: int | None = Field(
        default=None,
        description="Priority for credential selection, if system credential.",
    )
    is_default: bool | None = Field(
        default=None, description="Whether default credential, if system credential."
    )
    daily_request_limit: int | None = Field(
        default=None, description="Daily request limit, if system credential."
    )
    monthly_cost_limit_usd: Decimal | None = Field(
        default=None, description="Monthly spend limit, if system credential."
    )
    requests_per_minute_limit: int | None = Field(
        default=None, description="Rate limit, if system credential."
    )
    current_daily_requests: int | None = Field(
        default=None, description="Today's request count, if system credential."
    )
    current_monthly_cost_usd: Decimal | None = Field(
        default=None, description="Current month's spend, if system credential."
    )


class GrantSystemCredentialRequest(BaseModel):
    """Request to grant system credential to user or organization."""

    credential_id: UUID = Field(
        ..., description="ID of the system credential to grant access to."
    )
    organization_id: UUID | None = Field(
        default=None,
        description="Organization to grant access to. Mutually exclusive with user_id.",
    )
    user_id: UUID | None = Field(
        default=None,
        description="User to grant access to. Mutually exclusive with organization_id.",
    )
    expires_at: datetime | None = Field(
        default=None,
        description="Optional expiration for this grant. After this date, access is revoked.",
    )

    @model_validator(mode="after")
    def validate_org_or_user_exclusive(self) -> "GrantSystemCredentialRequest":
        """Ensure exactly one of organization_id or user_id is set."""
        has_org = self.organization_id is not None
        has_user = self.user_id is not None

        if not has_org and not has_user:
            raise ValueError("Must provide either organization_id or user_id")
        if has_org and has_user:
            raise ValueError("Cannot set both organization_id and user_id")

        return self


class GrantSystemCredentialResponse(BaseModel):
    """Response for system credential grant data."""

    id: UUID = Field(..., description="Unique identifier for this grant record.")
    organization_id: UUID | None = Field(
        ..., description="Organization ID if granted to org, null if granted to user."
    )
    user_id: UUID | None = Field(
        ..., description="User ID if granted to user, null if granted to org."
    )
    credential_id: UUID = Field(
        ..., description="ID of the credential that was granted."
    )
    granted_by_user_id: UUID = Field(
        ..., description="ID of the user who performed the grant (for audit trail)."
    )
    granted_at: datetime = Field(..., description="When the grant was created.")
    expires_at: datetime | None = Field(
        ..., description="When the grant expires, or null if no expiration."
    )
