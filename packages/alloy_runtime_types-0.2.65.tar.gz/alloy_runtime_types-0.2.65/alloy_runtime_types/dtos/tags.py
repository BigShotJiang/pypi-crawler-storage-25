"""DTOs for tag operations."""

from pydantic import BaseModel, Field

from alloy_runtime_types.dtos.templates import TagResponse


class CreateTagRequest(BaseModel):
    """Request to create a tag in an organization.

    Tags are organization-scoped and use hierarchical paths with ltree.
    Only organization owners and admins can create tags.
    """

    tag_path: str = Field(
        ...,
        min_length=1,
        max_length=255,
        description="Hierarchical tag path using dots as separators (e.g., 'marketing.email.weekly'). "
        "Must be lowercase alphanumeric with underscores and dots only. Maximum 10 levels deep.",
    )
    display_name: str | None = Field(
        default=None,
        max_length=255,
        description="Human-friendly display name for UI (e.g., 'Email Marketing Weekly'). "
        "Defaults to tag_path if not provided.",
    )
    description: str | None = Field(
        default=None,
        max_length=1000,
        description="Optional description of the tag's purpose.",
    )


class CreateTagResponse(BaseModel):
    """Response after creating a tag."""

    tag: TagResponse = Field(description="The created tag")


class ListTagsResponse(BaseModel):
    """Response for listing tags with pagination."""

    tags: list[TagResponse] = Field(description="List of tags matching the query")
    total: int = Field(description="Total number of matching tags across all pages")


class GetTagResponse(BaseModel):
    """Response for retrieving a single tag by ID."""

    tag: TagResponse = Field(description="The requested tag")


class UpdateTagRequest(BaseModel):
    """Request to update an existing tag.

    All fields are optional - only provided fields are updated.
    The tag_path is immutable and cannot be changed.
    """

    display_name: str | None = Field(
        default=None,
        max_length=255,
        description="Human-friendly display name for UI. "
        "If omitted, current value is preserved.",
    )
    description: str | None = Field(
        default=None,
        max_length=1000,
        description="Optional description of the tag's purpose. "
        "Set to null to clear the description.",
    )


class UpdateTagResponse(BaseModel):
    """Response after updating a tag."""

    tag: TagResponse = Field(description="The updated tag")


# ============================================================================
# Delete Tag DTOs
# ============================================================================


class DeletedTagResponse(BaseModel):
    """Final state of a deleted tag."""

    id: str = Field(description="Tag UUID")
    organization_id: str = Field(description="Organization UUID the tag belonged to")
    tag_path: str = Field(description="Hierarchical tag path (e.g., 'marketing.email')")
    display_name: str = Field(description="Human-friendly display name")
    description: str | None = Field(
        description="Optional description of the tag's purpose"
    )


class DeleteTagResponse(BaseModel):
    """Response for deleting a tag."""

    deleted_tag: DeletedTagResponse = Field(description="The deleted tag's final state")
