"""DTOs for audio transcription endpoints."""

from datetime import datetime
from typing import Any, Literal
from uuid import UUID

from pydantic import AnyHttpUrl, BaseModel, Field, model_validator


def _empty_str_list() -> list[str]:
    return []


def _empty_float_list() -> list[float]:
    return []


AudioTranscriptionStatus = Literal[
    "pending", "running", "completed", "failed", "cancelled", "timeout"
]

AudioTranscriptionBackend = Literal["local", "elevenlabs"]

AudioTranscriptionOutputFormat = Literal["text", "json", "srt", "vtt"]


def _empty_audio_output_formats() -> list[AudioTranscriptionOutputFormat]:
    return []


ALL_AUDIO_TRANSCRIPTION_OUTPUT_FORMATS: tuple[AudioTranscriptionOutputFormat, ...] = (
    "text",
    "json",
    "srt",
    "vtt",
)

TERMINAL_AUDIO_TRANSCRIPTION_STATUSES: frozenset[AudioTranscriptionStatus] = frozenset(
    {"completed", "failed", "cancelled", "timeout"}
)


def is_terminal_audio_transcription_status(status: AudioTranscriptionStatus) -> bool:
    return status in TERMINAL_AUDIO_TRANSCRIPTION_STATUSES


class AudioTranscriptionSubmitResponse(BaseModel):
    transcription_id: UUID
    status: AudioTranscriptionStatus = "pending"
    message: str = "Transcription queued"
    backend: AudioTranscriptionBackend
    user_metadata: dict[str, Any] | None = None
    external_id: str | None = None


class AudioTranscriptionSubmitRequest(BaseModel):
    backend: AudioTranscriptionBackend
    diarize: bool
    audio_bytes: bytes | None = None
    filename: str | None = None
    content_type: str | None = None
    audio_url: AnyHttpUrl | str | None = None
    external_id: str | None = None
    metadata: dict[str, Any] | None = None

    @model_validator(mode="after")
    def validate_source_contract(self) -> "AudioTranscriptionSubmitRequest":
        has_file = self.audio_bytes is not None
        has_url = self.audio_url is not None

        if has_file == has_url:
            raise ValueError("exactly one source input is required")

        if has_file and (self.filename is None or self.content_type is None):
            raise ValueError(
                "filename and content_type are required for uploaded audio"
            )

        if self.backend == "local" and has_url:
            raise ValueError("audio_url is only supported for backend=elevenlabs")

        if self.backend == "local" and self.diarize:
            raise ValueError("diarize=true is only supported for backend=elevenlabs")

        return self


class AudioTranscriptionJSONSegment(BaseModel):
    segment_index: int
    start_seconds: float
    end_seconds: float
    text: str
    tokens: list[str] = Field(default_factory=_empty_str_list)
    token_timestamps_seconds: list[float] = Field(default_factory=_empty_float_list)
    token_logprobs: list[float] = Field(default_factory=_empty_float_list)


def _empty_audio_transcription_segments() -> list[AudioTranscriptionJSONSegment]:
    return []


class AudioTranscriptionJSONOutput(BaseModel):
    text: str = Field(min_length=1)
    segments: list[AudioTranscriptionJSONSegment] = Field(
        default_factory=_empty_audio_transcription_segments
    )


class AudioTranscriptionStatusResponse(BaseModel):
    transcription_id: UUID
    status: AudioTranscriptionStatus
    backend: AudioTranscriptionBackend = "local"
    diarize: bool = False
    is_terminal: bool = Field(
        description=(
            "True when transcription reached a terminal status and polling should stop."
        )
    )
    queued_at: datetime
    started_at: datetime | None = None
    completed_at: datetime | None = None
    total_duration_ms: int | None = Field(default=None, ge=0)
    user_metadata: dict[str, Any] | None = None
    external_id: str | None = None
    error_message: str | None = None
    error_type: str | None = None
    available_formats: list[AudioTranscriptionOutputFormat] = Field(
        default_factory=_empty_audio_output_formats
    )
    output_url: str | None = None
