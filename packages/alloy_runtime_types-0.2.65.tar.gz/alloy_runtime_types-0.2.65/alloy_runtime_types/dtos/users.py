"""DTOs for user operations."""

from uuid import UUID

from pydantic import BaseModel, Field, field_validator

from alloy_runtime_types.enums.api_key_scope import ApiKeyScope
from alloy_runtime_types.enums.member_role import MemberRole


class CreateUserRequest(BaseModel):
    """Request to create a new user."""

    email: str = Field(
        ...,
        description="User's email address. Must be valid format and will be normalized to lowercase.",
    )
    name: str = Field(..., description="User's display name.")
    role_id: MemberRole = Field(
        default=MemberRole.MEMBER,
        description="User's role in the organization. Defaults to MEMBER.",
    )

    @field_validator("email")
    @classmethod
    def validate_email(cls, value: str) -> str:
        """Validate email format and normalize to lowercase."""
        stripped = value.strip()
        if not stripped or "@" not in stripped:
            raise ValueError("email must be valid format")
        parts = stripped.split("@")
        if len(parts) != 2:
            raise ValueError("email must be valid format")
        local, domain = parts
        if not local or not domain or "." not in domain:
            raise ValueError("email must be valid format")
        return stripped.lower()


class CreateUserResponse(BaseModel):
    """Response after creating a user."""

    id: UUID = Field(..., description="Unique identifier for the user.")
    email: str = Field(..., description="User's email address.")
    name: str = Field(..., description="User's display name.")
    created_at: str = Field(
        ..., description="ISO 8601 timestamp of when the user was created."
    )
    updated_at: str = Field(
        ..., description="ISO 8601 timestamp of when the user was last updated."
    )


class MeResponse(BaseModel):
    """Response for /me endpoint - current authenticated user info."""

    user_id: UUID = Field(
        ..., description="Unique identifier for the authenticated user."
    )
    email: str = Field(..., description="User's email address.")
    name: str = Field(..., description="User's display name.")
    organization_id: UUID | None = Field(
        default=None,
        description="Organization ID if user belongs to one, null for personal accounts.",
    )
    organization_name: str | None = Field(
        default=None, description="Organization name if user belongs to one."
    )
    is_system_admin: bool = Field(
        ..., description="True if user has system-wide administrative privileges."
    )


class PingResponse(BaseModel):
    user_id: UUID = Field(
        ..., description="Unique identifier for the authenticated user."
    )
    email: str = Field(..., description="User's email address.")
    name: str = Field(..., description="User's display name.")
    organization_id: UUID | None = Field(
        default=None,
        description="Organization ID if user belongs to one, null for personal accounts.",
    )
    organization_name: str | None = Field(
        default=None, description="Organization name if user belongs to one."
    )
    is_system_admin: bool = Field(
        ..., description="True if user has system-wide administrative privileges."
    )
    scopes: list[ApiKeyScope] = Field(
        ...,
        description="Permission scopes for the authenticated API key in canonical order.",
    )
    api_key_prefix: str | None = Field(
        default=None,
        description="Masked API key prefix shown to users without exposing the raw key.",
    )
    release_version: str | None = Field(
        default=None, description="Public release version reported by the server build."
    )
    build_id: str | None = Field(
        default=None, description="Safe deploy-specific build identifier."
    )
    build_age: str | None = Field(
        default=None, description="Coarse relative age of the active server build."
    )
    build_age_seconds: int | None = Field(
        default=None,
        description="Approximate build age in seconds for consistent client formatting.",
    )
    instance_label: str | None = Field(
        default=None,
        description="Sanitized instance label derived from runtime context.",
    )
    api_host: str | None = Field(
        default=None, description="API host reached by the client."
    )
    http_status: int | None = Field(
        default=None, description="HTTP status observed by the client."
    )
    http_version: str | None = Field(
        default=None, description="HTTP protocol version observed by the client."
    )
    tls_version: str | None = Field(
        default=None,
        description="TLS protocol version observed by the client, if available.",
    )
    sdk_version: str | None = Field(
        default=None,
        description="Installed Alloy Runtime SDK version used for the request.",
    )
    types_version: str | None = Field(
        default=None,
        description="Installed Alloy Runtime types package version used for the request.",
    )
    dns_ms: float | None = Field(
        default=None,
        description="Observed DNS lookup time in milliseconds, if available.",
    )
    connect_ms: float | None = Field(
        default=None,
        description="Observed TCP connect time in milliseconds, if available.",
    )
    tls_ms: float | None = Field(
        default=None,
        description="Observed TLS handshake time in milliseconds, if available.",
    )
    ttfb_ms: float | None = Field(
        default=None,
        description="Observed time to first byte in milliseconds, if available.",
    )
    wait_ms: float | None = Field(
        default=None,
        description="Observed post-connect wait time before first byte in milliseconds, if available.",
    )
    transfer_ms: float | None = Field(
        default=None,
        description="Observed response body transfer time in milliseconds, if available.",
    )
    total_ms: float | None = Field(
        default=None, description="Observed total request duration in milliseconds."
    )
