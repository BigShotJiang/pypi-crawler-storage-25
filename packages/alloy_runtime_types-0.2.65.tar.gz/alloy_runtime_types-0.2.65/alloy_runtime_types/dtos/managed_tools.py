from copy import deepcopy
from collections.abc import Sequence
from typing import Any
from uuid import UUID

from pydantic import BaseModel, Field


class ManagedToolReference(BaseModel):
    """Reusable reference to an Alloy-managed tool.

    Used by both saved agent tool configs and request-level `managed_tools`
    entries for direct generation.
    """

    tool_id: str = Field(min_length=1)
    tool_alias: str | None = Field(
        default=None,
        min_length=1,
        description="Unique alias for this tool instance within the request or agent. "
        "Defaults to tool_id if not provided.",
    )
    config: dict[str, Any] | None = Field(
        default=None,
        description="Inline tool configuration. When tool_config_id is also provided, this acts as a shallow top-level override over the referenced ToolConfig.",
    )
    tool_config_id: UUID | None = Field(
        default=None,
        description="Reference to a reusable ToolConfig. If config is also provided, Alloy applies config as shallow top-level overrides over the referenced ToolConfig.",
    )
    llm_instruction: str | None = Field(
        default=None,
        description="Optional instruction appended to the tool description for the LLM.",
    )

    @property
    def effective_alias(self) -> str:
        return get_effective_managed_tool_alias(self.tool_id, self.tool_alias)


class ManagedToolRequest(ManagedToolReference):
    """Request-level Alloy-managed tool configuration for direct generation."""


def merge_managed_tool_config(
    base_config: dict[str, Any] | None,
    override_config: dict[str, Any] | None,
) -> dict[str, Any] | None:
    """Merge top-level alias/request overrides over a referenced ToolConfig.

    This intentionally performs a shallow top-level merge. Nested objects and
    arrays are replaced wholesale when the override provides the same key.
    """
    if base_config is None and override_config is None:
        return None
    if base_config is None:
        return deepcopy(override_config)
    if override_config is None:
        return deepcopy(base_config)

    merged = deepcopy(base_config)
    merged.update(deepcopy(override_config))
    return merged


def get_effective_managed_tool_alias(tool_id: str, tool_alias: str | None) -> str:
    return tool_alias if tool_alias else tool_id


def normalize_managed_tools(
    managed_tools: Sequence[ManagedToolReference] | None,
) -> list[ManagedToolReference] | None:
    if not managed_tools:
        return None
    return list(managed_tools)


def validate_unique_managed_tool_aliases(
    managed_tools: Sequence[ManagedToolReference] | None,
    *,
    field_name: str,
) -> None:
    normalized_managed_tools = normalize_managed_tools(managed_tools)
    if normalized_managed_tools is None:
        return

    aliases = [tool.effective_alias for tool in normalized_managed_tools]
    if len(aliases) != len(set(aliases)):
        raise ValueError(
            f"Each {field_name} entry must have a unique tool_alias. "
            f"Duplicate aliases found in {field_name} list."
        )
