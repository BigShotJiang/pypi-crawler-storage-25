from datetime import datetime
from typing import Any, Literal
from uuid import UUID

from pydantic import BaseModel


ExecutionActivityState = Literal["unavailable", "partial", "complete"]
ExecutionActivityKind = Literal[
    "reasoning",
    "assistant_text",
    "tool_call",
    "tool_started",
    "tool_completed",
    "tool_failed",
]


class ExecutionActivityItem(BaseModel):
    index: int
    kind: ExecutionActivityKind
    timestamp: datetime | None = None
    round_index: int | None = None
    tool_name: str | None = None
    content_text: str | None = None
    content_structured: dict[str, Any] | None = None


class GetExecutionResponse(BaseModel):
    execution_id: UUID
    origin_label: str
    status: str
    is_terminal: bool
    execution_purpose: str
    pipeline_execution_id: UUID | None = None
    provider_key: str
    provider_model_name: str
    queued_at: datetime
    started_at: datetime | None = None
    last_activity_at: datetime | None = None
    completed_at: datetime | None = None
    total_duration_ms: int | None = None
    output_text: str | None = None
    output_incomplete: bool = False
    error_message: str | None = None
    error_type: str | None = None
    activity_state: ExecutionActivityState
    activity: list[ExecutionActivityItem]
