"""DTOs for authentication operations."""

from uuid import UUID

from pydantic import BaseModel, Field, field_validator

from alloy_runtime_types.enums.api_key_scope import ApiKeyScope


class SignupRequest(BaseModel):
    """Request to create a new user account."""

    email: str
    password: str = Field(min_length=8, description="Password (minimum 8 characters)")
    name: str = Field(min_length=1, max_length=255, description="Display name")
    organization_name: str | None = Field(
        default=None,
        max_length=500,
        description="Organization name (defaults to '{name}'s Organization')",
    )

    @field_validator("email")
    @classmethod
    def validate_email(cls, value: str) -> str:
        """Validate email format and normalize to lowercase."""
        stripped = value.strip()
        if not stripped or "@" not in stripped:
            raise ValueError("email must be valid format")
        parts = stripped.split("@")
        if len(parts) != 2:
            raise ValueError("email must be valid format")
        local, domain = parts
        if not local or not domain or "." not in domain:
            raise ValueError("email must be valid format")
        return stripped.lower()


class SignupResponse(BaseModel):
    """Response after successful signup."""

    user_id: UUID
    organization_id: UUID
    api_key: str  # Plaintext, only returned once
    api_key_prefix: str
    name: str
    email: str
    created_at: str
    scopes: list[ApiKeyScope] = Field(
        ...,
        description="Full scope set granted to auto-issued API key",
    )


class LoginRequest(BaseModel):
    """Request to authenticate and get API key."""

    email: str
    password: str

    @field_validator("email")
    @classmethod
    def validate_email(cls, value: str) -> str:
        """Normalize email to lowercase."""
        return value.strip().lower()


class LoginResponse(BaseModel):
    """Response after successful login."""

    user_id: UUID
    organization_id: UUID
    api_key: str
    api_key_prefix: str
    name: str
    email: str
    is_new_user: bool  # True if first login (for CLI onboarding prompts)
    scopes: list[ApiKeyScope] = Field(
        ...,
        description="Full scope set granted to auto-issued API key",
    )


class BootstrapAdminRequest(BaseModel):
    """Request to bootstrap the first system administrator.

    This can only be used when the database has no users (fresh installation).
    Creates a system admin user with full privileges.
    """

    email: str
    password: str = Field(min_length=8, description="Password (minimum 8 characters)")
    name: str = Field(min_length=1, max_length=255, description="Admin display name")
    organization_name: str = Field(
        default="Platform Team",
        max_length=500,
        description="Organization name for system admin",
    )
    bootstrap_token: str = Field(
        description="Security token that must match server's BOOTSTRAP_TOKEN env var",
    )

    @field_validator("email")
    @classmethod
    def validate_email(cls, value: str) -> str:
        """Validate email format and normalize to lowercase."""
        stripped = value.strip()
        if not stripped or "@" not in stripped:
            raise ValueError("email must be valid format")
        parts = stripped.split("@")
        if len(parts) != 2:
            raise ValueError("email must be valid format")
        local, domain = parts
        if not local or not domain or "." not in domain:
            raise ValueError("email must be valid format")
        return stripped.lower()


class BootstrapAdminResponse(BaseModel):
    """Response after successful admin bootstrap."""

    user_id: UUID
    organization_id: UUID
    api_key: str  # Plaintext, only returned once
    api_key_prefix: str
    name: str
    email: str
    organization_name: str
    created_at: str
    scopes: list[ApiKeyScope] = Field(
        ...,
        description="Full scope set granted to auto-issued API key",
    )
