"""DTOs for structured JSONB filtering."""

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

# Type alias for condition operators
ConditionOperator = Literal[
    "eq",  # Equal
    "ne",  # Not equal
    "gt",  # Greater than
    "gte",  # Greater than or equal
    "lt",  # Less than
    "lte",  # Less than or equal
    "in",  # In list
    "nin",  # Not in list
    "like",  # SQL LIKE pattern
    "ilike",  # Case-insensitive LIKE
    "exists",  # Key exists
    "not_exists",  # Key does not exist
    "contains",  # JSONB containment
]

# Type alias for logical operators
LogicalOperator = Literal["and", "or", "not"]


class ConditionSpec(BaseModel):
    """Single filter condition on a JSONB field.

    Examples:
        - Simple equality: {"field": "status", "op": "eq", "value": "complete"}
        - Nested path: {"field": "data.count", "op": "gte", "value": 10}
        - Existence: {"field": "error", "op": "exists"}
    """

    model_config = ConfigDict(extra="forbid")

    field: str = Field(
        ...,
        description="Dot-path to JSONB field (e.g., 'status', 'data.count', 'metadata.email')",
        min_length=1,
    )
    op: ConditionOperator = Field(..., description="Comparison operator")
    value: Any = Field(
        None,
        description="Comparison value (not required for exists/not_exists)",
    )

    @model_validator(mode="after")
    def _check_op_value_arity(self) -> "ConditionSpec":
        if self.op in {"exists", "not_exists"} and self.value is not None:
            raise ValueError(f"op={self.op!r} must not carry a value")
        if self.op in {"in", "nin"} and not isinstance(self.value, list):
            raise ValueError(f"op={self.op!r} requires a list value")
        return self


class LogicalSpec(BaseModel):
    """Logical operation combining multiple conditions.

    Examples:
        - AND: {"op": "and", "conditions": [condition1, condition2]}
        - OR: {"op": "or", "conditions": [condition1, condition2]}
        - NOT: {"op": "not", "conditions": [condition1]}
    """

    model_config = ConfigDict(extra="forbid")

    op: LogicalOperator = Field(..., description="Logical operator")
    conditions: list["ConditionSpec | LogicalSpec"] = Field(
        ...,
        min_length=1,
        description="List of conditions to combine",
    )

    @model_validator(mode="after")
    def _check_not_arity(self) -> "LogicalSpec":
        if self.op == "not" and len(self.conditions) != 1:
            raise ValueError("op='not' requires exactly one condition")
        return self


# Enable self-referential models
LogicalSpec.model_rebuild()

# Type alias for top-level filter spec
StructuredFilterSpec = ConditionSpec | LogicalSpec
