from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, Field

from alloy_runtime_types.enums.provider import Provider


def _empty_credential_grants() -> list["CredentialGrantListItem"]:
    return []


class CredentialGrantListItem(BaseModel):
    id: UUID = Field(description="Unique identifier for this grant record.")
    organization_id: UUID | None = Field(
        description="Organization ID if the grant applies to an organization, else null."
    )
    user_id: UUID | None = Field(
        description="User ID if the grant applies to an individual user, else null."
    )
    granted_by_user_id: UUID = Field(
        description="User ID that created the grant for audit visibility."
    )
    granted_at: datetime = Field(description="When the grant was created.")
    expires_at: datetime | None = Field(
        description="When the grant expires, or null if it does not expire."
    )


class CredentialListItem(BaseModel):
    id: UUID = Field(description="Unique identifier for the credential.")
    type: str = Field(
        description="Credential type identifier (for example 'org_provider' or 'system_provider')."
    )
    name: str = Field(description="Human-readable credential name.")
    description: str | None = Field(description="Optional credential description.")
    value_prefix: str | None = Field(
        description="Non-sensitive prefix used to identify the credential value."
    )
    is_active: bool = Field(description="Whether the credential is currently active.")
    expires_at: datetime | None = Field(
        description="Credential expiration timestamp, or null if it does not expire."
    )
    last_used_at: datetime | None = Field(
        description="Last time the credential was used, or null if never used."
    )
    created_at: datetime = Field(description="When the credential was created.")
    updated_at: datetime = Field(description="When the credential was last updated.")
    provider_key: Provider | None = Field(
        default=None,
        description="Provider key for provider-backed credentials, else null.",
    )
    service_key: str | None = Field(
        default=None,
        description="Service or infrastructure key for org-backed tool credentials, else null.",
    )
    tool_ids: list[str] = Field(
        default_factory=list,
        description="Tool IDs enabled or satisfied by this credential.",
    )


class OrganizationCredentialListItem(CredentialListItem):
    pass


class SystemCredentialListItem(CredentialListItem):
    priority: int = Field(
        description="Credential priority for system credential selection."
    )
    is_default: bool = Field(
        description="Whether this credential is the default system credential for its provider."
    )
    grants: list[CredentialGrantListItem] = Field(
        default_factory=_empty_credential_grants,
        description="Active and expired grants visible to system administrators.",
    )


class ListOrganizationCredentialsResponse(BaseModel):
    credentials: list[OrganizationCredentialListItem] = Field(
        description="Organization credentials visible to the authenticated organization user."
    )
    total: int = Field(description="Total number of matching organization credentials.")


class ListSystemCredentialsResponse(BaseModel):
    credentials: list[SystemCredentialListItem] = Field(
        description="System credentials visible to the authenticated system admin."
    )
    total: int = Field(description="Total number of matching system credentials.")
