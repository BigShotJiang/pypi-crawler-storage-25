from datetime import datetime
from uuid import UUID

from pydantic import BaseModel


class WebhookTriggerSummary(BaseModel):
    id: UUID
    name: str
    description: str | None
    trigger_count: int
    last_triggered_at: datetime | None
    created_at: datetime


class ListTriggersResponse(BaseModel):
    triggers: list[WebhookTriggerSummary]
    total: int


class DeleteTriggerResponse(BaseModel):
    id: UUID
    deleted: bool = True
