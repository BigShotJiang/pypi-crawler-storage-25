# Copyright (c) Saga Inc.
# Distributed under the terms of the GNU Affero General Public License v3.0 License.

"""
This module contains constants used in prompts across the codebase.
These constants ensure consistency between prompt building and message trimming.
"""

import os
import json
from typing import Final

from mito_ai_core.completions.prompt_builders.excel_to_python_rules import EXCEL_TO_PYTHON_RULES
from mito_ai_core.utils.schema import MITO_FOLDER

CHART_CONFIG_RULES = """
When creating a matplotlib chart, you must use the `# === CHART CONFIG ===` and `# === END CONFIG ===` markers to indicate the start and end of the chart configuration section.

The chart configuration section is a list of variables used to customize the chart. This includes the titles, labels, colors, and any variables that affect the chart's appearance.

Rules:
- All imports must appear at the top, before the chart configuration section.
- Variables with multiple words should be underscore-separated.
- All colors should be in hex format (e.g., "#3498db"). Use quotes around the hex string: COLOR = "#3498db" or COLOR = '#3498db'. Do NOT nest quotes.
- Never use RGB/RGBA tuples/lists for colors (e.g. (0, 0.4, 0.8, 0.8) is forbidden).
- If transparency is needed, store it separately as ALPHA = 0.8 and apply it in code (e.g. to_rgba(HEX_COLOR, ALPHA)).
- Variables can only be strings, numbers, booleans, tuples, or lists. 
- NEVER include comments on the same line as a variable assignment. Each variable assignment must be on its own line with no trailing comments.
- For string values, use either single or double quotes (e.g., TITLE = "Sales by Product" or TITLE = 'Sales by Product'). Do not use nested quotes (e.g., do NOT use '"value"').

Fixed acceptable ranges (matplotlib constraints):
- For numeric variables that have a fixed acceptable range, add a line immediately BEFORE the variable assignment: # RANGE VARIABLE_NAME MIN MAX
- This allows the Chart Wizard to clamp inputs and prevent invalid values. Use the following ranges when you use these variables:
  - ALPHA (opacity): 0 1
  - FIGURE_SIZE (tuple width, height in inches): 1 24 (each element)
  - LINE_WIDTH, LINEWIDTH, LWD: 0 20
  - FONT_SIZE, FONTSIZE, FONT_SIZE_TITLE, FONT_SIZE_LABEL: 0.1 72
  - MARKER_SIZE, MARKERSIZE, S: 0 1000
  - DPI: 1 600
  - Any other numeric or tuple variable that you know has matplotlib constraints: add # RANGE VARIABLE_NAME MIN MAX with the appropriate min and max.

Common Mistakes to Avoid:
- WRONG: COLOR = '"#1877F2" # Meta Blue'  (nested quotes and inline comment)
- WRONG: COLOR = "#1877F2" # Meta Blue  (inline comment)
- WRONG: COLOR = '"#1877F2"'  (nested quotes)
- CORRECT: COLOR = "#1877F2"  (simple hex string, no nested quotes, no inline comments)

Example:
# === CHART CONFIG ===
TITLE = "Sales by Product"
X_LABEL = "Product"
Y_LABEL = "Sales"
BAR_COLOR = "#000000"
# RANGE ALPHA 0 1
ALPHA = 0.8
# RANGE FIGURE_SIZE 1 24
FIGURE_SIZE = (12, 6)
# === END CONFIG ===
"""

LATEX_RULES = """

- Rendering engine is MathJax, not a LaTeX compiler. Only math/equation syntax is supported — no custom packages, document-level commands, or non-math environments.
- LaTeX only renders in Markdown cells, not code cells.
- Use $...$ for inline math and $$...$$ (on its own line) for centered display math.
- No spaces directly inside the delimiters — $x^2$ works, $ x^2 $ may not.
- If generating markdown programmatically in Python, use raw strings (r"...") or double-escape backslashes (\\frac) to avoid broken syntax.
- Stray underscores outside math delimiters can break rendering — keep _ inside $...$ only.
- Avoid mixing LaTeX display blocks inside HTML tags in the same cell.
"""

CITATION_RULES = """
It is important that the user is able to verify any insights that you share with them about their data. To make this easy for the user, you must cite the lines of code that you are drawing the insight from. To provide a citation, use one of the following formats inline in your response:

Single line citation:
[MITO_CITATION:cell_id:line_number]

Multiline citation (for citing a range of lines):
[MITO_CITATION:cell_id:first_line-last_line]

Citation Rules:

1. Every fact or conclusion you draw based on the user's notebook must include a MITO_CITATION so that the user can verify your work.
2. When choosing the citation, select the code that will most help the user validate the fact or statement that you shared with them.
3. Place the citation immediately after the statement it supports. Do not explain the citation with phrases like "See", "Derived from", etc. Just provide the citation object.
4. For the "line_number" field, use the line number within the cell that is most relevant to the citation. Important: The cell line number should be 0-indexed and should not skip comments.
5. For multiline citations, use the "first_line-last_line" format when the insight spans multiple lines of code. Both line numbers should be 0-indexed.
6. If you cannot find relevant information in the notebook to answer a question, clearly state this and do not provide a citation.
7. You only need to provide a citation when sharing an insight with the user. For example you should use a MITO_CITATION when you writing insights like any of the following: "The highest trading volume day was on January 15th, 2025", "The MSE was 6.8", "Apple's COGS are represented by the Orange bar in the graph". If you are not writing a quantitative insight and instead are just referring to a block of code like "I updated Cell 5 to include a graph", then you should instead use a MITO_CELL_REF.
8. Do not include the citation in the code block as a comment. ONLY include the citation in the message field of your response.
"""

CELL_REFERENCE_RULES = """
When referring to specific cells in the notebook in your messages, use cell references so the user can easily navigate to the cell you're talking about. Cell references are displayed to the user  "Cell 1", "Cell 2", etc., but internally cells are identified by their unique IDs.

To reference a cell, use this format inline in your message:
[MITO_CELL_REF:cell_id]

This will be displayed to the user as a clickable "Cell N" link that navigates to the referenced cell.

Cell Reference Rules:

1. Use cell references when discussing specific cells you've created or modified (e.g., "I've added the data cleaning code in [MITO_CELL_REF:abc123]").
2. The cell_id must be an actual cell ID from the notebook - do not make up IDs.
3. Place the reference inline where it makes sense in your message, similar to how you would write "Cell 3" in natural language.
4. Do not use cell references in code - only in the message field of your responses.
5. You only need to provide a cell reference when you want to make it easy for the user to navigate to a specific cell in the notebook. For example you should use a MITO_CELL_REF when you are stating things like: "I've loaded the sales data in [MITO_CELL_REF:c68fdf19-db8c-46dd-926f-d90ad35bb3bc]" or "[MITO_CELL_REF:a91fde20-cc7f-g6ee-146g-e10bc34abdbh] creates the graph showing the total highest closing stock price for each company". If you are not referencing an entire code block and instead of providing justification for a specific conclucions that you drew like "The most common used car in the lot is a 2005 Honda CRV", then you should instead use a MITO_CITATION.
"""

ABOUT_MITO = """
Mito is the company behind this AI assistant. Our website is trymito.io and our docs are at docs.trymito.io.

Only when the user explicitly asks about Mito as a product (e.g. how to use Mito, how to deploy apps, or other product/usage questions): answer their question and include this resource: "You can also reach out to the Mito founders directly with any questions you have. Send an email to founders@sagacollab.com".
Do NOT include the founders email when the user is asking for data analysis, insights, code to analyze their data, or any task about their notebook/data—only when they are asking about the Mito product itself.
"""

def redact_sensitive_info(connections: dict) -> dict:
    """
    Redacts sensitive information from connections data.
    Returns a copy of the connections dict with sensitive fields masked.
    """
    redacted = {}
    for conn_name, conn_data in connections.items():
        redacted[conn_name] = conn_data.copy()
        for key, value in redacted[conn_name].items():
            redacted[conn_name][key] = 'redacted'
    return redacted

def get_database_rules() -> str:
    """
    Reads the user's database configurations,
    and returns the rules for the AI to follow.
    """

    # Get the db configuration from the user's mito folder

    APP_DIR_PATH: Final[str] = os.path.join(MITO_FOLDER)
    connections_path: Final[str] = os.path.join(APP_DIR_PATH, 'db', 'connections.json')
    schemas_path: Final[str] = os.path.join(APP_DIR_PATH, 'db', 'schemas.json')
    
    try:
        with open(connections_path, 'r') as f:
            connections = json.load(f)
            sanitized_connections = redact_sensitive_info(connections)
    except FileNotFoundError:
        connections = None
        sanitized_connections = None

    try:
        with open(schemas_path, 'r') as f:
            schemas = json.load(f)
    except FileNotFoundError:
        schemas = None

    # If there is a db configuration, add return the rules

    if connections is not None:
        DATABASE_RULES = f"""DATABASE RULES:
If the user has requested data that you believe is stored in the database:
- Use the provided schema.
- Only use SQLAlchemy to query the database.
- Do not use a with statement when creating the SQLAlchemy engine. Instead, initialize it once so it can be reused for multiple queries.
- Always return the results of the query in a pandas DataFrame, unless instructed otherwise.
- Every schema has a unique connection ID. This ID can be used to find the connection details in the connections.json file.
- Do not use the connection ID to query the database. It is only for matching the schema to the correct connection.
- When using the connection ID, do not include any comments about it in your code.
- Connection details are stored in a JSON file located at: `{connections_path}`
- Here is the sanitized contents of the connections.json file:

{sanitized_connections}

- Do not hard-code connection credentials into your code. Instead, load the connections.json file and access connection fields dynamically like so:

```
connections[connection_name]["username"]
```

- The user may colloquially ask for a "list of x", always assume they want a pandas DataFrame. 
- When working with dataframes created from an SQL query, ALWAYS use lowercase column names. 
- If you think the requested data is stored in the database, but you are unsure, then ask the user for clarification.

## Additional MSSQL Rules

- When connecting to a Microsoft SQL Server (MSSQL) database, use the following format:

```
import urllib.parse

encoded_password = urllib.parse.quote_plus(password) 
conn_str = f"mssql+pyodbc://username:encoded_password@host:port/database?driver=ODBC+Driver+18+for+SQL+Server&TrustServerCertificate=yes"
```

- Always URL-encode passwords for MSSQL connections to handle special characters properly.
- Include the port number in MSSQL connection strings.
- Use "ODBC+Driver+18+for+SQL+Server" (with plus signs) in the driver parameter.
- Always include "TrustServerCertificate=yes" for MSSQL connections to avoid SSL certificate issues.

## Additional Oracle Rules

- When connecting to an Oracle database, use the following format:
```
conn_str = f"oracle+oracledb://username:password@host:port?service_name=service_name"
```

Here is the schema:
{schemas}
        """
    else:
        DATABASE_RULES = ""

    return DATABASE_RULES


CHAT_CODE_FORMATTING_RULES = """
- COMPLETE REPLACEMENT: Your code will COMPLETELY REPLACE the entire contents of the active code cell. 
- INCLUDE ALL CODE: You MUST return the COMPLETE, FULL contents of the entire code cell - including ALL existing code that should remain plus your modifications.
- NEVER PARTIAL CODE: NEVER return only a portion, snippet, or subset of the code cell. Partial responses will break the user's notebook by deleting important code.
- PRESERVE EXISTING CODE: Always preserve imports, variable definitions, and other code that the user needs, even if you're only modifying one small part.
"""
