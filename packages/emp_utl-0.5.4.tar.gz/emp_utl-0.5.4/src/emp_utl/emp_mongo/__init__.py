# Importing emp_mongo module
from .utl_mongo import create_mongo_indexes, load_mongo

__all__ = ['create_mongo_indexes', 'load_mongo']
