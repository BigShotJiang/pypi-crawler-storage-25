# Standard Library Imports
import logging
from urllib.parse import ParseResult, urlparse

# Third party imports
import pandas as pd
from pymongo import MongoClient
from pymongo.collection import Collection
from pymongo.database import Database
from pymongo.results import InsertManyResult


# Function to create MongoDB indexes
def create_mongo_indexes(
	collection: Collection,
	indexes: list[tuple[list[tuple[str, int]], dict[str, object]]] | None,
) -> None:
	"""
	Creates indexes on a MongoDB collection.

	:param collection: Active MongoDB collection
	:param indexes: Optional index definitions
	:return: None
	"""

	if indexes:
		for fields, options in indexes:
			collection.create_index(keys=fields, **options)


# Function to load DataFrames to MongoDB
def load_mongo(
	mongo_uri: str,
	df_dict: dict[str, list[pd.DataFrame]],
	logger: logging.Logger,
	indexes: dict[str, list[tuple[list[tuple[str, int]], dict[str, object]]]]
	| None = None,
	reset_db: bool = False,
) -> None:
	"""
	Loads multiple DataFrames into a MongoDB database.
	The database name is automatically extracted from the MongoDB URI.
	Each dictionary key is interpreted as the target collection name.
	Multiple DataFrames per collection are concatenated before insertion.

	:param mongo_uri: MongoDB connection URI including database name.
	:param df_dict: Mapping of collection names to DataFrames.
	:param logger: Logger instance for structured logging.
	:param indexes: Optional collection index configuration.
	:param reset_db: If True, drops the database before insertion.
	:return: None.
	"""

	# Variables
	client: MongoClient | None = None

	try:
		parsed: ParseResult = urlparse(url=mongo_uri)
		db_name: str = parsed.path.lstrip('/').split('?')[0]

		if not db_name:
			raise ValueError('No Database name found in MongoDB URL')

		# Creating Client and Database reference
		client: MongoClient = MongoClient(host=mongo_uri)
		db: Database = client[db_name]

		# Optionally resetting Database
		if reset_db:
			client.drop_database(name_or_database=db_name)
			logger.info(msg=f"Dropped MongoDB Database: '{db_name}'")
			db = client[db_name]

		# Processing Collections
		for collection_name, dfs in df_dict.items():
			if not dfs:
				logger.warning(
					msg=f"No DataFrames provided for '{collection_name}'"
				)
				continue

			# Merging all DataFrames for this Collection
			df: pd.DataFrame = pd.concat(objs=dfs, ignore_index=True)
			if df.empty:
				logger.warning(
					msg=f"Collection '{collection_name}' is empty -> Skipping"
				)
				continue

			collection: Collection = db[collection_name]

			# Creating optional index
			create_mongo_indexes(
				collection=collection,
				indexes=indexes.get(collection_name) if indexes else None,
			)

			# Converting DataFrame to records
			records: list[dict[str, object]] = df.to_dict(orient='records')
			if not records:
				continue

			result: InsertManyResult = collection.insert_many(documents=records)
			logger.info(
				msg=f"Inserted '{len(result.inserted_ids)}' documents into collection '{collection_name}'"
			)
	except Exception:
		logger.exception(msg='Error occurred during upload of data to MongoDB')
		raise
