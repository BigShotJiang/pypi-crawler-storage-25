# Standard Library Imports
import contextlib
import io
import logging
import os
import tempfile

# Third party imports
import pandas as pd
from kaggle.api.kaggle_api_extended import KaggleApi


# Function to create Kaggle Client
def create_kaggle_client(
	kaggle_username: str, kaggle_key: str, logger: logging.Logger
) -> KaggleApi:
	"""
	Creates and authenticates a Kaggle API client.

	:param kaggle_username: Kaggle account username.
	:param kaggle_key: Kaggle API key.
	:param logger: Logger instance for structured logging.
	:return: Authenticated Kaggle API client.
	"""

	try:
		os.environ['KAGGLE_USERNAME'] = kaggle_username
		os.environ['KAGGLE_KEY'] = kaggle_key

		api: KaggleApi = KaggleApi()
		api.authenticate()

		logger.info(msg="Successfully authenticated with 'Kaggle' OpenAPI")

		return api
	except Exception:
		logger.exception(
			msg="Error occurred while authenticating with 'Kaggle' OpenAPI"
		)
		raise


# Function to download Kaggle Dataset
def download_kaggle_dataset(
	api: KaggleApi,
	source: str,
	logger: logging.Logger,
	filename: str | None = None,
) -> pd.DataFrame:
	"""
	Downloads and loads a Kaggle dataset into a pandas DataFrame.

	The function:
	- Downloads and extracts the dataset into a temporary directory
	- Resolves the target CSV file automatically or via explicit filename
	- Loads the dataset into a pandas DataFrame
	- Removes unnamed columns automatically

	:param api: Kaggle client (authenticated).
	:param source: Kaggle dataset source identifier (e.g. owner/dataset-name).
	:param logger: Logger instance for structured logging.
	:param filename: Optional explicit filename inside the dataset archive.
	:return: Pandas DataFrame containing the downloaded dataset.
	"""

	try:
		with tempfile.TemporaryDirectory() as tmp_dir:
			# Download and extract dataset
			with contextlib.redirect_stdout(io.StringIO()):
				api.dataset_download_files(
					dataset=source, path=tmp_dir, unzip=True
				)

			# Resolve target file if not explicitly provided
			if filename is None:
				files: list[str] = os.listdir(path=tmp_dir)

				if not files:
					raise FileNotFoundError(
						'No files found in downloaded dataset'
					)
				resolved_filename: str = files[0]
			else:
				resolved_filename: str = filename

			# Build absolute file path
			file_path: str = os.path.join(tmp_dir, resolved_filename)

			# Load DataFrame
			df: pd.DataFrame = pd.read_csv(
				filepath_or_buffer=file_path,
				sep=',',
				encoding='utf-8',
				usecols=lambda col: not str(col).startswith('Unnamed'),
			)

			logger.info(
				msg=f"Successfully loaded dataset file: '{resolved_filename}' into pandas DataFrame"
			)
			return df.reset_index(drop=True)
	except Exception:
		logger.exception(
			msg='Error occurred during download of dataset from Kaggle'
		)
		raise
