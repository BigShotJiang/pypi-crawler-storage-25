# Standard Library Imports
import json
import logging
import os
from datetime import date, datetime

# Third party imports
import mysql
import pandas as pd
from mysql.connector.connection import MySQLConnection
from mysql.connector.cursor import MySQLCursor
from mysql.connector.errors import Error

# Importing required module
from ..emp_logger import find_project_root


# Function to create MySQL Connection
def create_mysql_connection(
	env_vars: dict[str, str], port_key: str, logger: logging.Logger
) -> MySQLConnection:
	"""
	Establishes a connection to the MySQL server using environment configuration.

	The connection parameters (host, port, user, password) are retrieved from
	the provided environment variables dictionary.

	:param env_vars: Dictionary containing database connection configuration
	:param port_key: Key used to resolve the correct database port from env_vars
	:param logger: Logger instance for structured logging
	:return: Active MySQLConnection object
	"""

	try:
		return mysql.connector.connect(
			host=env_vars['DB_HOST'],
			port=env_vars[port_key],
			user=env_vars['DB_USER'],
			password=env_vars['DB_PASSWORD'],
		)
	except Error:
		logger.exception(
			msg=f"Error occurred in establishing connection to MySQL Server on environment '{env_vars['ENVIRONMENT']}'"
		)
		raise


# Function to select correct schema
def use_schema(
	schema: str, cursor: MySQLCursor, logger: logging.Logger
) -> None:
	"""
	Switches the active schema for the current MySQL session.

	:param schema: Name of the schema to activate.
	:param cursor: Active MySQL cursor used to execute the command.
	:param logger: Custom Logger
	:return: None
	"""

	try:
		cursor.execute(operation=f'USE `{schema}`;')
		logger.info(
			msg=f"-> Selection of SCHEMA: '{schema}' successfully performed"
		)
	except Error:
		logger.exception(
			msg=f"Error occurred during switch to SCHEMA: '{schema}'"
		)
		raise


# Function to enable foreign key check
def enable_fk_check(cursor: MySQLCursor, logger: logging.Logger) -> None:
	"""
	Enables foreign key checks for the current MySQL session.

	:param cursor: Active MySQL cursor used to execute the command.
	:param logger: Custom Logger
	:return: None
	"""

	try:
		cursor.execute(operation='SET FOREIGN_KEY_CHECKS = 1;')
		logger.info(msg='Foreign Key check successfully enabled')
	except Error:
		logger.exception(
			msg='Error occurred during enablement of foreign key check'
		)
		raise


# Function to disable foreign key check
def disable_fk_check(cursor: MySQLCursor, logger: logging.Logger) -> None:
	"""
	Disables foreign key checks for the current MySQL session.

	:param cursor: Active MySQL cursor used to execute the command.
	:param logger: Custom Logger
	:return: None
	"""

	try:
		cursor.execute(operation='SET FOREIGN_KEY_CHECKS = 0;')
		logger.info(msg='Foreign Key check successfully disabled')
	except Error:
		logger.exception(
			msg='Error occurred during disablement of foreign key check'
		)
		raise


# Function to load used location details (addresses)
def load_used_loc_details(
	connection: MySQLConnection, schema: str, table: str, logger: logging.Logger
) -> set[int]:
	"""
	Retrieves all used location IDs (`loc_id`) from a given table.

	The function validates the existence of the specified schema and table,
	then queries all non-null `loc_id` values and returns them as a set.

	:param connection: Active MySQL connection
	:param schema: Target database schema name
	:param table: Target table name
	:param logger: Logger instance for structured logging
	:return: Set of used location IDs
	"""

	try:
		cursor: MySQLCursor = connection.cursor(buffered=True)
		cursor.execute(operation=f"SHOW DATABASES LIKE '{schema}';")
		if not cursor.fetchone():
			logger.warning(msg=f'SCHEMA: `{schema}` does not exist -> Skipping')
			return set()
		cursor.execute(operation=f"SHOW TABLES FROM `{schema}` LIKE '{table}';")
		if not cursor.fetchone():
			logger.warning(
				msg=f'TABLE: `{schema}`.`{table}` does not exist -> Skipping'
			)
			return set()
		query: str = f'SELECT `loc_id` FROM `{schema}`.`{table}`;'
		df: pd.DataFrame = pd.read_sql(sql=query, con=connection)
		return set(df['loc_id'].dropna().astype(int).tolist())
	except Error as e:
		logger.warning(msg=f'Skipping `{schema}`.`{table}` due to error: {e}')
		return set()


# Function to get available location details (addresses)
def get_available_loc_details(
	env_vars: dict[str, str],
	logger: logging.Logger,
	frac: float = 0.25,
	query: str | None = None,
) -> pd.DataFrame:
	"""
	Retrieves a subset of available (unused) location details across services.

	The function aggregates all `loc_id` values currently used in other schemas
	(employee, customer, supplier, inventory), then queries the full location dataset
	and returns a filtered random sample excluding already assigned locations.

	:param env_vars: Dictionary containing environment and database configuration
	:param logger: Logger instance for structured logging
	:param frac: Fraction of available locations to sample (default: 0.25)
	:param query: Custom mysql query - Optional to pass
	:return: DataFrame containing available location details
	"""

	# Variables
	used_locs: set[int] = set()
	connection: MySQLConnection | None = None

	# Services to check
	sources: list[set[str]] = [
		('EMP_SCHEMA_EMPLOYEE', 'employee', 'DB_PORT_EMPLOYEE'),
		('EMP_SCHEMA_CUSTOMER', 'customer', 'DB_PORT_CUSTOMER'),
		('EMP_SCHEMA_INVENTORY', 'inventory', 'DB_PORT_INVENTORY'),
	]

	# Aggregating used locs
	for schema_key, table, port_key in sources:
		if schema_key not in env_vars or port_key not in env_vars:
			continue

		try:
			connection = create_mysql_connection(
				env_vars=env_vars, port_key=port_key, logger=logger
			)
			schema: str = env_vars[schema_key]
			locs: set[int] = load_used_loc_details(
				connection=connection, schema=schema, table=table, logger=logger
			)
			used_locs.update(locs)
		finally:
			if connection:
				connection.close()

	# Loading all locations
	connection = create_mysql_connection(
		env_vars=env_vars, port_key='DB_PORT_LOCATION', logger=logger
	)

	try:
		default_query: str = """
        SELECT l.`loc_id`, c.`country`, c.`phone_prefix`, c.`domain`, c.`language_code`, c.`continent`
        FROM `location_db`.`location` l
        JOIN `location_db`.`country` c ON l.`country_id` = c.`country_id`
        ORDER BY l.`loc_id`;
        """
		query = query if query is not None else default_query
		df: pd.DataFrame = pd.read_sql(sql=query, con=connection)
		logger.info(msg=f"Total used locations: '{len(used_locs)}'")
		return (
			df[~df['loc_id'].isin(values=used_locs)]
			.sample(frac=frac)
			.reset_index(drop=True)
		)
	finally:
		connection.close()


# Function to execute sql script
def run_sql_script(cursor: MySQLCursor, logger: logging.Logger) -> None:
	"""
	Reads and executes a SQL script file, including support for custom
	DELIMITER statements.

	The function parses the script into executable SQL statements and
	executes them sequentially using the active database cursor.

	:param cursor: Active MySQL cursor instance
	:param logger: Logger instance for structured logging
	:return: None
	"""

	# Reading sql script from ./sql directory
	root_dir: str = find_project_root()
	if root_dir is None:
		root_dir = os.getcwd()
	sql_dir: str = os.path.join(root_dir, 'sql')
	files: list[str] = sorted(os.listdir(path=sql_dir))

	for file in files:
		# Variables
		queries: list[str] = []
		delimiter: str = ';'
		query: str = ''
		filename: str = os.fsdecode(filename=file)

		if filename.endswith('.sql') and 'dummy' not in filename.lower():
			path_to_sql: str = os.path.join(sql_dir, filename)
			with open(file=path_to_sql, mode='r', encoding='utf-8') as f:
				for line in f.readlines():
					line: str = line.strip()
					if line.startswith('DELIMITER'):
						delimiter = line[10:]
					else:
						query += line + '\n'
						if line.endswith(delimiter):
							queries.append(query.strip().strip(delimiter))
							query = ''
			f.close()
		else:
			logger.warning(msg=f"Skipping SQL script: '{filename}'")
			continue

		try:
			for _, query in enumerate(iterable=queries):
				if not query.strip():
					continue
				cursor.execute(operation=query)
			logger.info(msg=f"Successfully executed SQL script: '{filename}'")
		except Error:
			logger.exception(
				msg=f"Error occurred during execution of SQL script: '{filename}'"
			)
			raise


# Function to execute sql script
def get_values(df: pd.DataFrame) -> str:
	"""
	Converts a pandas DataFrame into a SQL-compatible VALUES string.

	The function iterates over each row of the DataFrame and transforms
	the values into a tuple-based string representation suitable for
	bulk INSERT statements.

	Special handling:
	- Dictionaries are serialized to JSON
	- Date and datetime objects are formatted as 'YYYY-MM-DD'
	- Null or unsupported values are replaced with a default placeholder

	:param df: Input DataFrame containing rows to be converted
	:return: String representing multiple row values formatted for SQL insertion
	"""

	# Variables
	null_val: str = '1970-01-01 00:00:01'
	vals: str = ''

	for _, row in df.iterrows():
		row_values: list[str] = [
			json.dumps(obj=val)
			if isinstance(val, dict)
			else val.strftime(format='%Y-%m-%d %H:%M:%S')
			if isinstance(val, datetime) and pd.notnull(val)
			else val.strftime(format='%Y-%m-%d')
			if isinstance(val, date)
			and not isinstance(val, datetime)
			and pd.notnull(val)
			else val
			if pd.notnull(val)
			else null_val
			for val in row
		]
		row_string: str = str(tuple(row_values)) + ', '
		vals += row_string
	return vals[:-2]


# Function to reset null_values
def update_null_values(
	schema: str,
	table: str,
	connection: MySQLConnection,
	cursor: MySQLCursor,
	logger: logging.Logger,
) -> None:
	"""
	Replaces predefined placeholder values with NULL in the specified table.

	This function inspects the table's column definitions via
	INFORMATION_SCHEMA and updates columns of supported data types
	(e.g., date, datetime, timestamp, varchar, text) where a temporary
	placeholder value was inserted during bulk loading.

	:param schema: Name of the schema containing the target table.
	:param table: Name of the table to update.
	:param connection: Active MySQL connection used to connect to MySQL Server.
	:param cursor: Active MySQL cursor used to execute statements.
	:param logger: Custom logger object
	:return: None
	"""

	try:
		cursor.execute(
			operation=f"SELECT COLUMN_NAME, DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = '{schema}' AND TABLE_NAME = '{table}';"
		)
		column_info: list[set[str]] = cursor.fetchall()
	except Error:
		logger.exception(
			msg=f"Error occurred in selecting column definition for table '{table}'"
		)
		raise

	for col in column_info:
		col_name: str = col[0]
		data_type: str = col[1]

		# Building UPDATE statement for specific data types
		if data_type in ['date', 'datetime', 'timestamp', 'varchar', 'text']:
			update_query: str = f"UPDATE `{schema}`.`{table}` SET `{col_name}` = NULL WHERE `{col_name}` LIKE '1970-01-01%';"

			try:
				cursor.execute(operation=update_query)
				connection.commit()
			except Error:
				logger.exception(
					msg=f"Error occurred while updating column '{col_name}' at `{schema}`.`{table}`"
				)
				raise


# Function to insert values into tables
def insert_into_table(
	schema: str,
	df: pd.DataFrame,
	table: str,
	connection: MySQLConnection,
	cursor: MySQLCursor,
	logger: logging.Logger,
) -> None:
	"""
	Inserts a pandas DataFrame into the specified MySQL table using
	a bulk INSERT statement.

	The function:
	- Dynamically builds the column list from the DataFrame
	- Generates a VALUES clause via `get_values(...)`
	- Executes the INSERT statement
	- Resets temporary placeholder values to NULL
	- Commits the transaction

	:param schema: Target database schema.
	:param df: Source DataFrame containing rows to insert.
	:param table: Name of the destination table.
	:param connection: Active MySQL connection used to connect to MySQL Server.
	:param cursor: Active MySQL cursor used for execution.
	:param logger: Logger instance for structured logging.
	:return: None
	"""

	try:
		df_cols: str = '`' + '`, `'.join(df.columns) + '`'
		insert_statement: str = f'INSERT INTO `{schema}`.`{table}` ({df_cols}) VALUES {get_values(df=df)};'

		cursor.execute(operation=insert_statement)
		result: int = cursor.rowcount
		logger.info(msg=f'{result} affected rows on `{schema}`.`{table}`')

		update_null_values(
			schema=schema,
			table=table,
			connection=connection,
			cursor=cursor,
			logger=logger,
		)
	except Error:
		logger.exception(
			msg=f'Error occurred while inserting data into `{schema}`.`{table}`'
		)
		raise


# Function to upload DataFrames to MySQL
def load_mysql(
	env_vars: dict[str, str],
	schema: str,
	df_dict: dict[str, pd.DataFrame],
	logger: logging.Logger,
) -> None:
	"""
	Loads multiple pandas DataFrames into a MySQL schema.

	The function:
	- Establishes a MySQL connection
	- Executes schema, function, and trigger SQL scripts
	- Temporarily disables foreign key checks
	- Inserts DataFrame contents into their corresponding tables
	- Re-enables foreign key checks after insertion
	- Closes all active database resources safely

	This utility is primarily intended for:
	- Smoke testing
	- Integration testing
	- CI/CD database initialization
	- Data preparation workflows

	:param env_vars: Environment configuration dictionary
	:param schema: Target MySQL schema name
	:param df_dict: Dictionary mapping table names to DataFrames
	:param logger: Logger instance for structured logging
	:return: None
	"""

	# Final variable
	environment: str = env_vars['ENVIRONMENT']

	try:
		# Establishing MySQL connection
		connection: MySQLConnection = create_mysql_connection(
			env_vars=env_vars, port_key='DB_PORT', logger=logger
		)

		if connection.is_connected():
			logger.info(
				msg=f"Connection to MySQL Server on environment: '{environment}' successfully established"
			)
			cursor: MySQLCursor = connection.cursor(buffered=True)

			# Executing SQL scripts
			disable_fk_check(cursor=cursor, logger=logger)
			run_sql_script(cursor=cursor, logger=logger)

			# Loading DataFrames into tables
			for table, df in df_dict.items():
				insert_into_table(
					schema=schema,
					df=df,
					table=table,
					connection=connection,
					cursor=cursor,
					logger=logger,
				)

			enable_fk_check(cursor=cursor, logger=logger)
			connection.commit()
			cursor.close()
			connection.close()
	except Error:
		logger.exception(
			msg=f"Error occurred while performing MySQL operations on environment '{environment}'"
		)
		raise
