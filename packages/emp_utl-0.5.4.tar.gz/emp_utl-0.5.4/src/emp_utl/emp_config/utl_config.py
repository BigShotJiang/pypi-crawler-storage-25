# Standard Library Imports
import logging
import os
from collections.abc import Mapping

# Third party imports
from config import ConfigClient
from requests.auth import HTTPBasicAuth


# Function to dynamically retrieve nested keys
def get_nested_config(config: dict[str, object], keys: list[str]) -> str | None:
	"""
	Retrieves a nested configuration value from a dictionary using a list of keys.

	:param config: Root configuration dictionary.
	:param keys: Ordered list of nested keys.
	:return: The resolved value if found, otherwise None.
	"""

	value: object = config
	for key in keys:
		if not isinstance(value, dict):
			return None
		value = value.get(key)
		if value is None:
			return None

	return str(value)


# Function to load configurations
def load_cnf(
	service: str,
	keys: list[str],
	logger: logging.Logger,
) -> dict[str, str | None]:
	"""
	Loads configuration values from Spring Cloud Config Server (CNF-S)
	with fallback to local environment variables if the server is unavailable.

	:param service: Name of the requesting service.
	:param keys: List of configuration keys to resolve.
	:param logger: Logger instance for structured logging.
	:return: Dictionary containing resolved configuration values.
	"""

	# Final variables
	environment: str = os.getenv('ENVIRONMENT', default='dev')
	base_url: str = os.getenv(key='BASE_URL', default='http://localhost')
	configuration_port: str = os.getenv(
		key='CONFIGURATION_PORT', default='8888'
	)
	username: str = os.getenv(key='EMP_CONFIG_USERNAME', default='')
	password: str = os.getenv(key='EMP_ENCRYPT_KEY', default='')

	# Dictionary to store environment variables
	env_vars: dict[str, str | None] = {'ENVIRONMENT': environment}

	# Establishing connection to Spring Cloud Config Server - CNF-S
	try:
		cc: ConfigClient = ConfigClient(
			address=f'{base_url}:{configuration_port}',
			label=environment,
			app_name=service,
			profile=environment,
		)
		cc.get_config(auth=HTTPBasicAuth(username=username, password=password))
		logger.info(
			msg=f"Spring Cloud Config Server 'CNF-S' accessed successfully on environment: '{environment}'"
		)
	except SystemExit:
		logger.warning(
			msg=f"Not able to contact Spring Cloud Config Server 'CNF-S' on environment: '{environment}'"
		)

		# Fallback: In case Spring Cloud Config Server (CNF-S) isn't available
		try:
			for key in keys:
				if key not in env_vars:
					env_vars[key] = os.getenv(key=key)
			logger.info(
				msg=f"Successfully loaded environment variables from OS/Profile on environment: '{environment}'"
			)
			return env_vars
		except Exception:
			logger.exception(
				msg=f"Error occurred in loading environment variables from local OS/Profile on environment '{environment}'"
			)
			raise
	else:
		# Loading environment variables from Spring Cloud Config (CNF-S)
		try:
			config: Mapping[str, str | None] = cc.config
			for key in keys:
				if key not in env_vars:
					key_parts: list[str] = [
						part.lower() for part in key.split(sep='_')
					]
					value: str | None = get_nested_config(
						config=config, keys=key_parts
					)
					env_vars[key] = value
			logger.info(
				msg=f"Successfully loaded environment variables from Spring Cloud Config Server 'CNF-S' on environment: '{environment}'"
			)
			return env_vars
		except Exception:
			logger.exception(
				msg=f"Error occurred in loading environment variables from Spring Cloud Config Server 'CNF-S' on environment: '{environment}'"
			)
			raise
