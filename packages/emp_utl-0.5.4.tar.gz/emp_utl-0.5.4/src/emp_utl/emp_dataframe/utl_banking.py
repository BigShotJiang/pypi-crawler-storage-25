# Standard Library Imports
import logging
import random

# Third party imports
import pandas as pd
from faker import Faker
from kaggle.api.kaggle_api_extended import KaggleApi

# Importing required module
from ..emp_external import download_kaggle_dataset
from .utl_dataframe import add_audit_columns, create_faker


# Function to create banking mapper (international banks)
def create_banking_mapper(
	df_banks: pd.DataFrame, logger: logging.Logger
) -> dict[str, list[str]]:
	"""
	Creates a country-based banking mapper dictionary.
	The function groups bank names by country and returns a dictionary
	where:
	    - key   -> country name
	    - value -> list of bank names

	:param df_banks: DataFrame containing bank dataset
	:param logger: Custom Logger object
	:return: Dictionary mapping countries to bank names
	"""

	try:
		return {
			str(country): sorted(set(banks.astype(str)))
			for country, banks in (df_banks.groupby(by='Country')['Bank name'])
		}
	except Exception:
		logger.exception(msg="Error occurred during mapping of 'Largest Banks'")
		raise


# Function to create banking info (Dictionary / JSON)
def create_banking_info(
	loc_mapper: tuple[str, str, str], banking_mapper: dict[str, list[str]]
) -> tuple[str, dict[str, str]]:
	"""
	Creates banking information based on geographical location data.
	The function selects a realistic financial institute based on country
	and generates either:
	    - IBAN/BIC information for European countries
	    - BBAN/Routing information for non-european countries

	:param loc_mapper: Tuple containing location mapping information
	:param banking_mapper: Dictionary mapping countries to bank names
	:return: Tuple containing institute name and banking information
	"""

	# Variables
	locale: str = str(loc_mapper[1])
	country: str = str(loc_mapper[0])
	continent: str = str(loc_mapper[2])

	# Faker initialization
	try:
		faker: Faker = create_faker(locale=locale)
	except Exception:
		faker: Faker = create_faker(locale='en_US')

	# Selecting Banking institute
	if country in banking_mapper:
		institute: str = random.choice(seq=banking_mapper[country]).strip()
	else:
		institute: str = random.choice(
			seq=random.choice(seq=list(banking_mapper.values()))
		).strip()

	# European banking structure
	if continent == 'Europe':
		banking_info: dict[str, str] = {
			'iban': faker.iban(),
			'bic': faker.swift8(),
		}

	# International banking structure
	else:
		banking_info: dict[str, str] = {
			'accountNumber': faker.bban(),
			'routingNumber': faker.aba(),
		}

	return institute, banking_info


# Function to create Banking Row
def create_banking_row(
	user: pd.Series,
	loc_mapper: pd.Series,
	user_id_col: str,
	user_type: str,
	banking_mapper: dict[str, list[str]],
) -> dict[str, object]:
	"""
	Creates a banking document for a single user.

	The function generates realistic banking-related information
	based on geographical location data and user type.

	Depending on the continent, the generated banking structure
	contains either:
	    - IBAN/BIC information for European countries
	    - Account/Routing information for non-european countries

	Additional business attributes such as cashback eligibility
	and verification status are generated dynamically based on
	the provided user type.

	:param user: Pandas Series representing the user row
	:param loc_mapper: Pandas Series containing mapped location details
	:param user_id_col: Column name containing the user ID
	:param user_type: User type (e.g. EMPLOYEE, CUSTOMER, SUPPLIER)
	:param banking_mapper: Dictionary mapping countries to banking institutes
	:return: Dictionary representing a banking document
	"""

	# Banking Details
	institute, banking_info = create_banking_info(
		loc_mapper=(
			loc_mapper['country'],
			loc_mapper['language_code'],
			loc_mapper['continent'],
		),
		banking_mapper=banking_mapper,
	)

	# Cashback
	cashback: float = (
		round(number=random.uniform(a=0.0, b=0.15), ndigits=2)
		if user_type == 'CUSTOMER'
		else 0.0
	)

	# Supplier verification
	verified: bool = (
		random.choice(seq=[True, False]) if user_type == 'SUPPLIER' else True
	)

	return {
		'userId': str(user[user_id_col]),
		'userType': user_type,
		'institute': institute,
		'bankingInfo': banking_info,
		'cashback': cashback,
		'verified': verified,
		'preferred': random.choice(seq=[True, False]),
		'active': True,
	}


# Function to create Banking DataFrame
def create_banking(
	df: pd.DataFrame,
	df_loc_mapper: pd.DataFrame,
	user_id_col: str,
	user_type: str,
	date_column: str,
	api: KaggleApi,
	logger: logging.Logger,
	banking_mapper: dict[str, list[str]] | None = None,
) -> pd.DataFrame:
	"""
	Creates a banking DataFrame for the given user dataset.

	The function generates realistic banking information based on the
	user's geographical location and enriches the result with audit
	columns using the specified date column as the earliest valid date.

	:param df: Source DataFrame containing user records.
	:param df_loc_mapper: DataFrame containing location mapping details.
	:param user_id_col: Column name containing the user ID.
	:param user_type: User type (e.g. EMPLOYEE, CUSTOMER, SUPPLIER).
	:param date_column: Column used as the earliest valid audit date.
	:param api: Authenticated Kaggle API client.
	:param logger: Logger instance for structured logging.
	:param banking_mapper: Optional dictionary mapping countries to bank names.
	:return: DataFrame containing banking documents.
	"""

	try:
		# Creating Banking mapper once if not provided
		if banking_mapper is None:
			banking_mapper = create_banking_mapper(
				df_banks=download_kaggle_dataset(
					api=api, source='drahulsingh/largest-banks', logger=logger
				),
				logger=logger,
			)

		# Liking user with location details
		df_loc_mapper_merged: pd.DataFrame = df[[user_id_col, 'loc_id']].merge(
			right=df_loc_mapper, on='loc_id', how='left'
		)

		# Building Banking DataFrame
		return (
			add_audit_columns(
				df=pd.DataFrame(
					data=df.apply(
						lambda row: create_banking_row(
							user=row,
							loc_mapper=df_loc_mapper_merged.loc[
								df_loc_mapper_merged[user_id_col]
								== row[user_id_col]
							].iloc[0],
							user_id_col=user_id_col,
							user_type=user_type,
							banking_mapper=banking_mapper,
						),
						axis=1,
					).tolist()
				),
				date_column=date_column,
			)
			.rename(
				columns={
					'created_datetime': 'createdDatetime',
					'updated_datetime': 'updatedDatetime',
					'created_by': 'createdBy',
					'updated_by': 'updatedBy',
				}
			)
			.reset_index(drop=True)
		)
	except Exception:
		logger.exception(
			msg="Error occurred during creation of 'Banking' DataFrame"
		)
		raise
