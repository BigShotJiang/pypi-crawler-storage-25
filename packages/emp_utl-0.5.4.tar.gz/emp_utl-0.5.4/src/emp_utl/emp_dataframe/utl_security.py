# Standard Library Imports
import logging
import random

# Third party imports
import re
from datetime import UTC, datetime

import bcrypt
import pandas as pd

# Importing required module
from ..emp_dataframe import add_audit_columns


# Function to encode plain password
def encode_password(raw_password: str) -> str:
	"""
	Encodes a plaintext password using bcrypt hashing.

	The function generates a salted hash suitable for secure storage
	and authentication workflows.

	:param raw_password: Plaintext password to encode
	:return: Bcrypt-hashed password string
	"""

	return bcrypt.hashpw(
		password=raw_password.encode(), salt=bcrypt.gensalt()
	).decode()


# Function to create Credential Row
def create_credential_row(
	user: pd.Series,
	user_id_col: str,
	user_type: str,
	encoded_passwords: list[str],
	roles: list[str] | None,
) -> dict[str, object]:
	# Variables
	current_time: datetime = datetime.now(tz=UTC)
	username: str = re.sub(
		pattern=r'[^a-z0-9]',
		repl='',
		string=f'{user["firstname"][0]}{user["lastname"]}'.lower(),
	)

	# Role Handling
	roles = roles if roles else ['LIMITED']

	return {
		'userId': str(user[user_id_col]),
		'userType': user_type,
		'username': username,
		'email': user['email'],
		'password': random.choice(seq=encoded_passwords),
		'mfaEnabled': False,
		'active': True,
		'lastLogin': current_time,
		'lastLogout': None,
		'mustChangePassword': False,
		'resetToken': None,
		'resetTokenExpiration': None,
		'roles': [random.choice(seq=roles)],
	}


# Function to create Credential DataFrame
def create_credential(
	df: pd.DataFrame,
	user_id_col: str,
	user_type: str,
	date_column: str,
	logger: logging.Logger,
	roles: list[str] | None = None,
) -> pd.DataFrame:
	"""
	Creates a credential dataframe for students or staff.

	:param df: Source dataframe
	:param user_id_col: Column containing the user ID
	:param user_type: User type (STUDENT or STAFF)
	:param date_column: Column used as base for timestamps
	:param logger: Custom Logger object
	:param roles: Provided roles for specific userTypes
	:return: Credential dataframe
	"""

	try:
		encoded_passwords: list[str] = [
			encode_password(raw_password='Password123!') for _ in range(10)
		]

		return (
			add_audit_columns(
				df=pd.DataFrame(
					data=df.apply(
						lambda row: create_credential_row(
							user=row,
							user_id_col=user_id_col,
							user_type=user_type,
							encoded_passwords=encoded_passwords,
							roles=roles,
						),
						axis=1,
					).tolist()
				),
				date_column=date_column,
			)
			.rename(
				columns={
					'created_datetime': 'createdDatetime',
					'updated_datetime': 'updatedDatetime',
					'created_by': 'createdBy',
					'updated_by': 'updatedBy',
				}
			)
			.reset_index(drop=True)
		)
	except Exception:
		logger.exception(
			msg=f"Error occurred in building of 'Credential' DataFrame for '{user_type}'"
		)
		raise
