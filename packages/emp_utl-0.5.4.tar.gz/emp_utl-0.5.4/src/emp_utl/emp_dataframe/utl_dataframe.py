# Standard Library Imports
import logging
import os
import random
from datetime import date, datetime

# Third party imports
import pandas as pd
from countryinfo import CountryInfo
from faker import Faker
from faker.config import AVAILABLE_LOCALES
from unidecode import unidecode

# Importing required module
from ..emp_core import create_random_datetime


# Function to export DataFrame
def export_dataframe(
	path: str, df: pd.DataFrame, logger: logging.Logger
) -> None:
	"""
	Exporting dataframe to specified path as feather file.
	This function uses the 'feather-format' module to save the dataframe in feather format

	:param path: path to save the dataframe
	:param df: dataframe to export
	:param logger: Custom Logger object
	:return: None
	"""

	# Export DataFrame as feather file
	try:
		df.to_feather(path=path)
		filename: str = os.path.splitext(p=os.path.basename(p=path))[0]
		logger.info(msg=f"Pandas DataFrame '{filename}' exported successfully")
	except Exception:
		logger.exception(
			msg="Error occurred during export of DataFrame to 'data' dir"
		)
		raise


# Function to create audit columns for pandas DataFrame
def add_audit_columns(
	df: pd.DataFrame, date_column: str | None = None
) -> pd.DataFrame:
	"""
	Adds audit-related columns to the given DataFrame.
	This includes generating realistic `created_datetime` and
	`updated_datetime` values, as well as assigning default values
	for `created_by` and `updated_by`.

	If `date_column` is provided, the value of that column is used as the
	earliest possible `created_datetime` for each row. This allows audit
	timestamps to reflect domain-specific dates such as:

	- Employee   -> hired_date
	- Customer   -> registered_date
	- Supplier   -> registered_date
	- Product    -> introduced_date

	If `date_column` is not provided, the fallback start date is
	January 1st, 2020.

	:param df: Input DataFrame to enrich with audit columns.
	:param date_column: Optional column containing the earliest valid date.
	:return: DataFrame with added audit columns.
	"""

	# Collecting results
	machine_user: int = 9999
	fallback_start_date: date = date(year=2020, month=1, day=1)
	end_date: date = date.today()

	# Collecting results
	created_datetime_list: list[datetime] = []
	updated_datetime_list: list[datetime] = []

	for _, row in df.iterrows():
		# Determine earliest valid date for created_datetime
		if (
			date_column
			and date_column in df.columns
			and pd.notna(row[date_column])
		):
			start_value = row[date_column]

			# Converting pandas Timestamp / datetime to date
			if isinstance(start_value, pd.Timestamp | datetime):
				start_date: date = start_value.date()
			else:
				start_date: date = start_value
		else:
			start_date: date = fallback_start_date

		# Safety Check
		if start_date > end_date:
			start_date = fallback_start_date

		# Creating Timestamps
		created_datetime: datetime = create_random_datetime(
			start_date=start_date, end_date=end_date
		)
		updated_datetime: datetime = create_random_datetime(
			start_date=created_datetime.date(), end_date=end_date
		)
		created_datetime_list.append(created_datetime)
		updated_datetime_list.append(updated_datetime)

	# Modifying DateFrame
	df['created_datetime'] = pd.to_datetime(created_datetime_list)
	df['updated_datetime'] = pd.to_datetime(updated_datetime_list)
	df['created_by'] = machine_user
	df['updated_by'] = machine_user

	return df.reset_index(drop=True)


# Function to return random gender
def get_gender() -> str:
	"""
	Function to return a random gender 'MALE' or 'FEMALE'
	:return: Return randomly selected gender
	"""

	return random.choice(seq=['MALE', 'FEMALE'])


# Function to create Faker object
def create_faker(locale: str) -> Faker:
	"""
	Creating Faker module for data generation of fictional values.
	Dependent on locale, the fake data can approximate the passed language.

	:param locale: Country Code for Faker module i.e.: en_US, de_DE, fr_FR
	"""

	return Faker(locale=locale)


# Function to create secure demonym of given country
def get_demonym(country: str) -> str:
	"""
	Safely retrieves the demonym for a given country.

	The function attempts to resolve the demonym (e.g., "German" for Germany)
	using an external library. If the lookup fails, the original country name
	is returned as a fallback.

	:param country: Country name
	:return: Demonym or fallback country name
	"""

	try:
		return CountryInfo(country_name=country).info().get('demonym', country)
	except Exception:
		return country


# Function to normalize text
def normalize_text(value: str | None) -> str | None:
	"""
	Normalizes text by removing special characters and accents.

	The function converts Unicode characters into their closest ASCII
	representation to ensure consistency and compatibility.

	:param value: Input string value
	:return: Normalized string or None if input is None
	"""

	if value is None:
		return None
	return unidecode(string=value)


# Function to create phone no.
def get_phone_no(
	locale: str, country_code: str, fallback_locale: str = 'en_US'
) -> str:
	"""
	Generates a phone number aligned with a given locale and prefixes it
	with the provided country code.

	:param locale: Locale used for Faker (e.g., 'de_DE')
	:param country_code: Country phone prefix (e.g., '+49')
	:param fallback_locale: Fallback locale if the given locale is unsupported
	:return: Formatted phone number with country code
	"""

	# Validating locale
	if locale not in AVAILABLE_LOCALES:
		faker_phone: Faker = create_faker(locale=fallback_locale)
	else:
		try:
			faker_phone: Faker = create_faker(locale=locale)
			faker_phone.phone_number()
		except Exception:
			faker_phone: Faker = create_faker(locale=fallback_locale)

	# Generating phone no,
	phone_no: str = faker_phone.phone_number()
	phone_clean: str = phone_no.replace('x', '').strip()

	if phone_clean.startswith('+') or phone_clean.startswith('00'):
		phone_clean = phone_clean.lstrip('+').lstrip('0')

	return f'{country_code} {phone_clean}'
