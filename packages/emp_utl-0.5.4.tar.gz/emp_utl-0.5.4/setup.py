# Building setup to package 'emp-utl'
from setuptools import setup, find_packages

# Reading CHANGELOG.md
with open(file='CHANGELOG.md', mode='r', encoding='utf-8') as c:
    changelog: str = c.read()

# Reading README.md
with open(file='src/README.md', mode='r', encoding='utf-8') as rd:
    readme: str = rd.read()

# Reading requirements
with open(file='src/requirements.txt', mode='r', encoding='utf-8') as rq:
    requirements: list[str] = rq.read().splitlines()

# Merging README & CHANGELOG for PyPI page
long_description: str = f'{readme}\n\n{changelog}'

setup(
    name = 'emp-utl',
    version = '0.5.4',

    description = 'Reusable infrastructure and data utilities for the Enterprise Management Program (EMP)',
    long_description = long_description,
    long_description_content_type = 'text/markdown',

    author = 'AbdoCherry',
    url = 'https://github.com/AbdoCherry/EMP_UTL-S',

    packages = find_packages(
        where = 'src',
        include = ['emp_utl*']
    ),
    package_dir = {'' : 'src'},
    include_package_data = True,
    install_requires = requirements,
    python_requires = '>=3.10',
    license = 'MIT',
    classifiers = [
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'Topic :: Software Development :: Libraries',
        'Topic :: Software Development :: Libraries :: Python Modules',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3 :: Only',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Programming Language :: Python :: 3.13',
    ],

    keywords = [
        'emp',
        'microservices',
        'utility',
        'mysql',
        'mongodb',
        'logging',
        'configuration',
        'kafka',
        'dataframe',
        'pandas'
    ],

    project_urls = {
        'Source' : 'https://github.com/AbdoCherry/EMP_UTL-S',
        'Tracker' : 'https://github.com/AbdoCherry/EMP_UTL-S/issues'
    }
)