from __future__ import annotations

import copy
import inspect
import logging
import time
from typing import Optional, List

from oopz_sdk import models
from oopz_sdk.exceptions import OopzApiError

from . import BaseService

logger = logging.getLogger(__name__)


class AreaService(BaseService):
    """Area-related platform capabilities."""

    def _get_area_members_cache_store(self) -> dict:
        store = getattr(self, "_area_members_cache", None)
        if not isinstance(store, dict):
            store = {}
            self._area_members_cache = store
        return store

    def _cache_disabled(self) -> bool:
        """``cache_max_entries <= 0`` 视为完全关闭域成员缓存。

        这样既避免 ``min()`` 在空 store 上的 ``ValueError``（原先 `len >= 0` 恒真
        会直接对空字典执行 ``min``），也让 0/负数具备「关闭缓存」的自然语义。
        """
        try:
            max_entries = int(getattr(self._config, "cache_max_entries", 200))
        except (TypeError, ValueError):
            return False
        return max_entries <= 0

    def _get_cached_area_members(
        self,
        cache_key: tuple[str, int, int],
        *,
        max_age: float,
    ) -> Optional[dict]:
        if self._cache_disabled():
            return None
        store = self._get_area_members_cache_store()
        cached = store.get(cache_key)
        if not isinstance(cached, dict):
            return None
        ts = cached.get("ts")
        data = cached.get("data")
        if not isinstance(ts, (int, float)) or not isinstance(data, dict):
            return None
        if time.time() - float(ts) > max_age:
            return None
        return copy.deepcopy(data)

    def _set_cached_area_members(self, cache_key: tuple[str, int, int], data: dict) -> None:
        if self._cache_disabled():
            # 关闭缓存时，顺手清空历史残留，避免配置切换后命中脏条目
            store = getattr(self, "_area_members_cache", None)
            if isinstance(store, dict):
                store.clear()
            return
        store = self._get_area_members_cache_store()
        max_entries = int(getattr(self._config, "cache_max_entries", 200))
        # while 而非 if：之前若放宽过 max_entries 又调小，可能一次性要驱逐多条
        while store and len(store) >= max_entries:
            oldest = min(
                store,
                key=lambda k: store[k].get("ts", 0) if isinstance(store[k], dict) else 0,
            )
            store.pop(oldest, None)
        store[cache_key] = {"ts": time.time(), "data": copy.deepcopy(data)}

    async def get_area_members(
            self,
            area: str,
            offset_start: int = 0,
            offset_end: int = 49,
    ) -> models.AreaMembersPage:
        if area.strip() == "":
            raise ValueError("area cannot be empty")
        cache_key = (area, offset_start, offset_end)
        cache_ttl = float(getattr(self._config, "area_members_cache_ttl", 15.0))

        cached = self._get_cached_area_members(cache_key, max_age=cache_ttl)
        if cached is not None:
            cached["from_cache"] = True
            model = models.AreaMembersPage.from_api(cached)
            return model

        data = await self._request_data_with_retry(
            "GET",
            "/area/v3/members",
            params={
                "area": area,
                "offsetStart": str(offset_start),
                "offsetEnd": str(offset_end),
            },
            retry_on_429=True,
            max_attempts=3,
        )
        model = models.AreaMembersPage.from_api(data)

        normalized = {
            "members": copy.deepcopy(model.members),
            "roleCount": copy.deepcopy(model.role_count),
            "totalCount": model.total_count,
            "payload": copy.deepcopy(model.payload),
        }

        self._set_cached_area_members(cache_key, normalized)
        return model

    async def get_joined_areas(
        self
    ) -> List[models.JoinedAreaInfo]:
        """获取当前用户已加入（订阅）的域列表。"""
        url_path = "/userSubscribeArea/v1/list"
        data = await self._request_data("GET", url_path)
        result: list[models.JoinedAreaInfo] = []
        for i, item in enumerate(data):
            result.append(models.JoinedAreaInfo.from_api(item))
        return result

    async def get_area_info(self, area: str) -> models.AreaInfo:
        """获取域详细信息（含角色列表、主页频道等）。"""
        if area.strip() == "":
            raise ValueError("area cannot be empty")
        url_path = "/area/v3/info"
        params = {"area": area}
        data = await self._request_data("GET", url_path, params=params)
        return models.AreaInfo.from_api(data)

    async def edit_area_name(self, area: str, name: str) -> models.OperationResult:
        if area.strip() == "":
            raise ValueError("area cannot be empty")
        if name.strip() == "":
            raise ValueError("name cannot be empty")
        url_path = "/client/v1/area/v1/areaSettings/v1/editAreaName"
        data = await self._request_data("PUT", url_path, body={
            "area": area,
            "name": name,
        })
        return models.OperationResult.from_api(data)

    async def enter_area(self, area: str, recover: bool = False) -> dict:
        """进入指定域。"""
        if area.strip() == "":
            raise ValueError("area is required for enter_area")

        data = await self._request_data(
            "POST",
            "/client/v1/area/v1/enter",
            params={"area": area, "recover": str(recover).lower()},
            body={"area": area, "recover": recover},
        )
        return data if isinstance(data, dict) else {}



    async def get_area_channels(self, area: str) -> list[models.ChannelGroupInfo]:
        """Fetch all channel groups in an area."""
        if area.strip() == "":
            raise ValueError("area cannot be empty")
        url_path = "/client/v1/area/v1/detail/v1/channels"
        params = {"area": area}
        data = await self._request_data("GET", url_path, params=params)
        return [models.ChannelGroupInfo.from_api(item) for item in data]

    async def get_area_user_detail(self, area: str, target: str) -> models.AreaUserDetail:
        """获取指定用户在域内的角色列表和禁言/禁麦状态。"""
        if not target:
            raise ValueError("target is required for get_user_area_detail()")
        if not area:
            raise ValueError("area is required for get_user_area_detail()")

        url_path = "/area/v3/userDetail"
        params = {"area": area, "target": target}
        data = await self._request_data("GET", url_path, params=params)
        return models.AreaUserDetail.from_api(data)


    async def get_area_can_give_list(self, area: str, target: str) -> list[models.RoleInfo]:
        """获取当前用户可以分配给目标用户的角色列表。"""
        if not target:
            raise ValueError("target is required for get_assignable_roles()")
        if not area:
            raise ValueError("area is required for get_assignable_roles()")

        url_path = "/area/v3/role/canGiveList"

        data = await self._request_data("GET", url_path, params={"area": area, "target": target})

        if not isinstance(data, dict):
            raise OopzApiError(
                "area can give roles response format error: expected dict",
                payload=data,
            )
        roles = data.get("roles")
        if not isinstance(roles, list):
            raise OopzApiError(
                "area can give roles response format error: expected 'roles' list",
                payload=data,
            )

        return [models.RoleInfo.from_api(role) for role in roles]


    async def edit_user_role(
            self,
            area: str,
            target_uid: str,
            role_id: int,
            add: bool = True,
    ) -> models.OperationResult:
        """给目标用户添加或取消指定身份组。"""
        if target_uid.strip() == "":
            raise ValueError("target_uid is required for edit_user_role()")
        if area.strip() == "":
            raise ValueError("area is required for edit_user_role()")

        area_info = await self.get_area_user_detail(area, target_uid)

        current_ids = [role.role_id for role in area_info.roles]
        if add:
            if role_id not in current_ids:
                current_ids.append(role_id)
        else:
            current_ids = [x for x in current_ids if x != role_id]

        body = {"area": area, "target": target_uid, "targetRoleIDs": current_ids}
        resp = await self._request_data("POST", "/area/v3/role/editUserRole", body=body)
        return models.OperationResult.from_api(resp)

    async def get_user_area_nicknames(self, area: str, uids: list[str]) -> dict[str, str]:
        """批量获取用户在域内的昵称（备注）。

        Example:
              {"2ce12124c07111ef9e5dc6b17c3481f1": "盐盐盐"}
        """
        if not area:
            raise ValueError("area is required for getUserAreaNicknames()")
        if not uids:
            raise ValueError("uids list cannot be empty for getUserAreaNicknames()")

        url_path = "/area/v2/getUserAreaNicknames"
        body = {"area": area, "uids": uids}
        data = await self._request_data("POST", url_path, body=body)

        if not isinstance(data, dict):
            raise OopzApiError(
                "area nicknames response format error: expected dict",
                payload=data,
            )
        nicknames = data.get("nicknames")
        if not isinstance(nicknames, dict):
            raise OopzApiError(
                "area nicknames response format error: expected 'nicknames' dict",
                payload=data,
            )

        return {str(uid): str(nick) for uid, nick in nicknames.items()}

    async def leave_area(self, area: str) -> models.OperationResult:
        """离开指定域。"""
        if area.strip() == "":
            raise ValueError("area is required for leave_area")

        data = await self._request_data(
            "DELETE",
            "/client/v1/area/v1/quit",
            body={"area": area},
        )
        return models.OperationResult.from_api(data)

    # async def search_area_members(
    #         self,
    #         area: str,
    #         keyword: str = "",
    #         *,
    #         offset: int = 0,
    #         limit: int = 50,
    # ) -> None:
    #     """搜索域内成员。"""
    #     if not area:
    #         raise ValueError("area is required for search_area_members()")
    #
    #     url_path = "/area/v3/search/areaSettingMembers"
    #     body = {"area": area, "name": keyword, "offset": offset, "limit": limit}
    #
    #     raise NotImplementedError("unknown usage method")


    async def populate_names(self, *, set_area=None, set_channel=None) -> dict:
        """从 API 获取已加入域列表及各域频道列表，通过回调填充名称。

        Args:
            set_area: 可选回调 (area_id, area_name) -> None
            set_channel: 可选回调 (channel_id, channel_name) -> None

        Returns:
            {"areas_named": int, "channels_named": int}
        """
        areas_count = 0
        channels_count = 0

        areas = await self.get_joined_areas()

        for area in areas:
            if area.area_id and area.name:
                if set_area:
                    result = set_area(area.area_id, area.name)
                    if inspect.isawaitable(result):
                        await result
                    areas_count += 1

            groups = await self.get_area_channels(area.area_id)
            for group in groups:
                for ch in group.channels:
                    if ch.channel_id and ch.name:
                        if set_channel:
                            result = set_channel(ch.channel_id, ch.name)
                            if inspect.isawaitable(result):
                                await result
                            channels_count += 1

        logger.info("Name population completed: %d areas, %d channels", areas_count, channels_count)
        return {"areas_named": areas_count, "channels_named": channels_count}
