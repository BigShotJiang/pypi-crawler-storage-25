import time
import json
import threading
import requests
import psutil

from flask import Flask
from flask import request
from flask import jsonify
from flask import Response

class RapidBalancer:

    # ==========================================
    # CORE
    # ==========================================

    app = Flask("RapidBalancer")

    servers = []

    running = False

    retries = 2

    timeout = 3

    health_interval = 5

    sticky_sessions = {}

    # ==========================================
    # FEATURES
    # ==========================================

    dashboard_enabled = True

    live_stats = True

    realtime = True

    realtime_interval = 1000

    track_clients = True

    request_inspector = True

    logs = True

    alerts = True

    security = True

    firewall = False

    cache = False

    geolocation = False

    rate_limit = False

    ddos_protection = False

    ssl_enabled = False

    # ==========================================
    # STORAGE
    # ==========================================

    clients = {}

    requests_log = []

    system_logs = []

    terminal_logs = []

    alert_list = []

    banned_ips = set()

    allowed_ips = set()

    denied_ips = set()

    # ==========================================
    # GLOBAL STATS
    # ==========================================

    stats_data = {
        "requests": 0,
        "errors": 0,
        "traffic": 0,
        "started": time.time()
    }

    # ==========================================
    # ADD SERVERS
    # ==========================================

    @staticmethod
    def Servers(*servers):

        for server in servers:

            if ":" not in server:
                raise ValueError(
                    f"Invalid server: {server}"
                )

            host, port = server.split(":")

            RapidBalancer.servers.append({

                "host": host,

                "port": int(port),

                "alive": True,

                "latency": 0,

                "connections": 0,

                "traffic": 0,

                "requests": 0,

                "errors": 0,

                "fails": 0,

                "cpu": 0,

                "ram": 0,

                "last_check": 0
            })

    # ==========================================
    # LOG
    # ==========================================

    @staticmethod
    def _log(message):

        timestamp = time.strftime(
            "%H:%M:%S"
        )

        log = f"[{timestamp}] {message}"

        print(log)

        RapidBalancer.system_logs.append(log)

        RapidBalancer.terminal_logs.append(log)

        if len(RapidBalancer.system_logs) > 5000:
            RapidBalancer.system_logs.pop(0)

    # ==========================================
    # BEST SERVER
    # ==========================================

    @staticmethod
    def _best_server(client_ip=None):

        alive_servers = [

            s for s in RapidBalancer.servers

            if s["alive"]

        ]

        if not alive_servers:
            return None

        # Sticky Session

        if client_ip:

            if client_ip in RapidBalancer.sticky_sessions:

                old = RapidBalancer.sticky_sessions[
                    client_ip
                ]

                for s in alive_servers:

                    if (
                        s["host"] == old["host"]
                        and
                        s["port"] == old["port"]
                    ):
                        return s

        # Smart Score

        best = min(

            alive_servers,

            key=lambda s:

                (
                    (s["latency"] * 0.45)

                    +

                    (s["connections"] * 0.35)

                    +

                    ((s["traffic"] / 1000000) * 0.20)
                )
        )

        if client_ip:
            RapidBalancer.sticky_sessions[
                client_ip
            ] = best

        return best

    # ==========================================
    # HEALTH CHECK
    # ==========================================

    @staticmethod
    def _health_loop():

        while RapidBalancer.running:

            for server in RapidBalancer.servers:

                try:

                    start = time.time()

                    requests.get(

                        f"http://"
                        f"{server['host']}:"
                        f"{server['port']}",

                        timeout=RapidBalancer.timeout
                    )

                    latency = (
                        time.time() - start
                    ) * 1000

                    server["latency"] = latency

                    server["alive"] = True

                    server["fails"] = 0

                    server["last_check"] = time.time()

                except Exception:

                    server["fails"] += 1

                    if server["fails"] >= 2:

                        if server["alive"]:

                            RapidBalancer._log(
                                f"NODE DOWN "
                                f"{server['host']}:"
                                f"{server['port']}"
                            )

                        server["alive"] = False

            time.sleep(
                RapidBalancer.health_interval
            )

    # ==========================================
    # CLIENT TRACKING
    # ==========================================

    @staticmethod
    def _track_client(ip, path, size):

        if not RapidBalancer.track_clients:
            return

        if ip not in RapidBalancer.clients:

            RapidBalancer.clients[ip] = {

                "requests": 0,

                "traffic": 0,

                "first_seen": time.time(),

                "last_seen": time.time(),

                "paths": [],

                "user_agent": request.headers.get(
                    "User-Agent",
                    "Unknown"
                )
            }

        client = RapidBalancer.clients[ip]

        client["requests"] += 1

        client["traffic"] += size

        client["last_seen"] = time.time()

        if path not in client["paths"]:

            client["paths"].append(path)

    # ==========================================
    # REQUEST LOGGER
    # ==========================================

    @staticmethod
    def _log_request(ip, method, path):

        if not RapidBalancer.request_inspector:
            return

        RapidBalancer.requests_log.append({

            "ip": ip,

            "method": method,

            "path": path,

            "time": time.time()
        })

        if len(RapidBalancer.requests_log) > 5000:
            RapidBalancer.requests_log.pop(0)

    # ==========================================
    # PROXY
    # ==========================================

    @staticmethod
    def _proxy(path=""):

        RapidBalancer.stats_data[
            "requests"
        ] += 1

        client_ip = request.remote_addr

        # Firewall

        if client_ip in RapidBalancer.denied_ips:
            return "Forbidden", 403

        # Logging

        RapidBalancer._log_request(
            client_ip,
            request.method,
            path
        )

        for attempt in range(
            RapidBalancer.retries + 1
        ):

            server = RapidBalancer._best_server(
                client_ip
            )

            if not server:
                return (
                    "No available servers",
                    503
                )

            url = (
                f"http://"
                f"{server['host']}:"
                f"{server['port']}/"
                f"{path}"
            )

            try:

                server["connections"] += 1

                headers = {

                    key: value

                    for key, value

                    in request.headers

                    if key.lower() != "host"
                }

                headers[
                    "X-Forwarded-For"
                ] = client_ip

                headers[
                    "X-Real-IP"
                ] = client_ip

                response = requests.request(

                    method=request.method,

                    url=url,

                    headers=headers,

                    data=request.get_data(),

                    cookies=request.cookies,

                    allow_redirects=False,

                    stream=True,

                    timeout=RapidBalancer.timeout
                )

                server["requests"] += 1

                size = 0

                def generate():

                    nonlocal size

                    for chunk in response.iter_content(
                        chunk_size=8192
                    ):

                        size += len(chunk)

                        yield chunk

                RapidBalancer.stats_data[
                    "traffic"
                ] += size

                server["traffic"] += size

                excluded_headers = [

                    "content-encoding",

                    "content-length",

                    "transfer-encoding",

                    "connection"
                ]

                response_headers = [

                    (name, value)

                    for name, value

                    in response.raw.headers.items()

                    if name.lower()
                    not in excluded_headers
                ]

                RapidBalancer._track_client(
                    client_ip,
                    path,
                    size
                )

                return Response(

                    generate(),

                    response.status_code,

                    response_headers
                )

            except Exception as e:

                server["errors"] += 1

                RapidBalancer.stats_data[
                    "errors"
                ] += 1

                server["alive"] = False

                RapidBalancer._log(
                    f"ERROR {e}"
                )

            finally:

                if server["connections"] > 0:
                    server["connections"] -= 1

        return "All servers failed", 500

    # ==========================================
    # STATS
    # ==========================================

    @staticmethod
    def stats():

        uptime = int(
            time.time()
            -
            RapidBalancer.stats_data["started"]
        )

        return {

            "global": {

                **RapidBalancer.stats_data,

                "uptime": uptime,

                "online_nodes": len([
                    s for s in RapidBalancer.servers
                    if s["alive"]
                ]),

                "online_clients": len(
                    RapidBalancer.clients
                ),

                "cpu": psutil.cpu_percent(),

                "ram": psutil.virtual_memory().percent
            },

            "servers": RapidBalancer.servers,

            "clients": RapidBalancer.clients,

            "alerts": RapidBalancer.alert_list
        }

    # ==========================================
    # DASHBOARD
    # ==========================================

    @staticmethod
    def dashboard():

        return """
<!DOCTYPE html>
<html>
<head>

<title>RapidBalancer</title>

<meta charset="UTF-8">

<style>

body{
    background:#0f0f0f;
    color:white;
    font-family:Arial;
    margin:0;
    padding:20px;
}

.title{
    font-size:40px;
    font-weight:bold;
    margin-bottom:20px;
}

.grid{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(250px,1fr));
    gap:20px;
}

.card{
    background:#1a1a1a;
    border:1px solid #333;
    border-radius:15px;
    padding:20px;
}

.value{
    font-size:35px;
    margin-top:10px;
}

.green{
    color:lime;
}

.red{
    color:red;
}

.server{
    margin-top:20px;
}

table{
    width:100%;
    border-collapse:collapse;
}

td,th{
    padding:10px;
    border-bottom:1px solid #333;
}

</style>

</head>

<body>

<div class="title">
RapidBalancer
</div>

<div class="grid">

<div class="card">
<div>ONLINE NODES</div>
<div class="value" id="nodes">0</div>
</div>

<div class="card">
<div>ONLINE CLIENTS</div>
<div class="value" id="clients">0</div>
</div>

<div class="card">
<div>REQUESTS</div>
<div class="value" id="requests">0</div>
</div>

<div class="card">
<div>TRAFFIC</div>
<div class="value" id="traffic">0</div>
</div>

<div class="card">
<div>CPU</div>
<div class="value" id="cpu">0%</div>
</div>

<div class="card">
<div>RAM</div>
<div class="value" id="ram">0%</div>
</div>

</div>

<h1>Servers</h1>

<div id="servers"></div>

<h1>Clients</h1>

<table>

<thead>
<tr>
<th>IP</th>
<th>Requests</th>
<th>Traffic</th>
<th>User Agent</th>
</tr>
</thead>

<tbody id="clientsTable">
</tbody>

</table>

<script>

async function load(){

    let req = await fetch('/balancer_stats')

    let data = await req.json()

    document.getElementById(
        "nodes"
    ).innerText =
        data.global.online_nodes

    document.getElementById(
        "clients"
    ).innerText =
        data.global.online_clients

    document.getElementById(
        "requests"
    ).innerText =
        data.global.requests

    document.getElementById(
        "traffic"
    ).innerText =
        data.global.traffic

    document.getElementById(
        "cpu"
    ).innerText =
        data.global.cpu + "%"

    document.getElementById(
        "ram"
    ).innerText =
        data.global.ram + "%"

    let serverHTML = ''

    data.servers.forEach(server => {

        serverHTML += `

        <div class="card server">

            <h2>
            ${server.host}:${server.port}
            </h2>

            <p>
            STATUS:
            <span class="${
                server.alive
                ? 'green'
                : 'red'
            }">

            ${
                server.alive
                ? 'ONLINE'
                : 'OFFLINE'
            }

            </span>
            </p>

            <p>
            LATENCY:
            ${server.latency.toFixed(2)}ms
            </p>

            <p>
            CONNECTIONS:
            ${server.connections}
            </p>

            <p>
            REQUESTS:
            ${server.requests}
            </p>

            <p>
            TRAFFIC:
            ${server.traffic}
            </p>

        </div>
        `
    })

    document.getElementById(
        "servers"
    ).innerHTML = serverHTML

    let clientsHTML = ''

    Object.entries(
        data.clients
    ).forEach(([ip,client]) => {

        clientsHTML += `

        <tr>

        <td>${ip}</td>

        <td>${client.requests}</td>

        <td>${client.traffic}</td>

        <td>${client.user_agent}</td>

        </tr>
        `
    })

    document.getElementById(
        "clientsTable"
    ).innerHTML = clientsHTML
}

setInterval(load,1000)

load()

</script>

</body>
</html>
"""

    # ==========================================
    # RUN
    # ==========================================

    @staticmethod
    def run(

        host="0.0.0.0",

        port=8000,

        debug=False
    ):

        if not RapidBalancer.servers:

            raise Exception(
                "No servers added"
            )

        RapidBalancer.running = True

        RapidBalancer._log(
            "RapidBalancer started"
        )

        # Health Thread

        health = threading.Thread(
            target=RapidBalancer._health_loop
        )

        health.daemon = True

        health.start()

        # Stats API

        @RapidBalancer.app.route(
            "/balancer_stats"
        )
        def balancer_stats():

            return jsonify(
                RapidBalancer.stats()
            )

        # Dashboard

        @RapidBalancer.app.route(
            "/balancer_panel"
        )
        def balancer_panel():

            return RapidBalancer.dashboard()

        # Proxy

        @RapidBalancer.app.route(
            "/",
            defaults={"path": ""},
            methods=[
                "GET",
                "POST",
                "PUT",
                "DELETE",
                "PATCH",
                "OPTIONS"
            ]
        )

        @RapidBalancer.app.route(
            "/<path:path>",
            methods=[
                "GET",
                "POST",
                "PUT",
                "DELETE",
                "PATCH",
                "OPTIONS"
            ]
        )

        def proxy(path):

            return RapidBalancer._proxy(path)

        print()

        print("=" * 50)

        print(
            f"RapidBalancer running "
            f"on http://{host}:{port}"
        )

        print("=" * 50)

        print()

        for server in RapidBalancer.servers:

            print(
                f"[NODE] "
                f"{server['host']}:"
                f"{server['port']}"
            )

        print()

        if RapidBalancer.ssl_enabled:

            RapidBalancer.app.run(

                host=host,

                port=port,

                threaded=True,

                debug=debug,

                ssl_context=(
                    RapidBalancer.ssl_cert,
                    RapidBalancer.ssl_key
                ),

                use_reloader=False
            )

        else:

            RapidBalancer.app.run(

                host=host,

                port=port,

                threaded=True,

                debug=debug,

                use_reloader=False
            )