"""caliclaw mcp — manage Model Context Protocol servers.

MCP servers extend agent capabilities (Chrome DevTools, Playwright, GitHub,
Filesystem, etc.) by exposing extra tools to every agent subprocess
caliclaw spawns.

Storage: <project_root>/mcp.json — standard MCP server config shape
(`{"mcpServers": {"name": {"command": "...", "args": [...]}}}`). The agent
runner picks it up automatically when present (see core/agent.py).

Subcommands:
    list                       Show registered servers
    add <preset>               Add from preset (chrome / playwright / filesystem / github)
    add <name> --command CMD [--args ARG ARG]   Add custom server
    remove <name>              Unregister
    path                       Print config path
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

from cli.ui import ui
from core.config import get_settings
from security.engine_permissions import grant_tools, revoke_tools


_PRESETS = {
    "chrome": {
        "command": "npx",
        "args": ["-y", "chrome-devtools-mcp@latest"],
        "_hint": "Chrome DevTools — page navigation, screenshots, console, network",
    },
    "playwright": {
        "command": "npx",
        "args": ["-y", "@playwright/mcp@latest"],
        "_hint": "Playwright — multi-browser automation (chromium/firefox/webkit)",
    },
    "filesystem": {
        "command": "npx",
        "args": ["-y", "@modelcontextprotocol/server-filesystem", "/tmp"],
        "_hint": "Filesystem — read/write files in a sandbox path (default /tmp)",
    },
    "github": {
        "command": "npx",
        "args": ["-y", "@modelcontextprotocol/server-github"],
        "_hint": "GitHub — issues, PRs, repos",
        "_setup": (
            "Setup:\n"
            "  1. Generate a Personal Access Token at https://github.com/settings/tokens\n"
            "     Scopes: repo (private) or public_repo (public only)\n"
            "  2. Add to .env:\n"
            "       GITHUB_PERSONAL_ACCESS_TOKEN=ghp_...\n"
            "  3. caliclaw restart"
        ),
    },
    "telegram": {
        "command": "npx",
        "args": ["-y", "@chaindead/telegram-mcp"],
        "_hint": "Telegram (MTProto) — read chats/groups/channels, search history",
        "_setup": (
            "Setup:\n"
            "  1. Register an app at https://my.telegram.org/apps\n"
            "     → copy api_id and api_hash\n"
            "  2. Add to .env:\n"
            "       TELEGRAM_API_ID=12345678\n"
            "       TELEGRAM_API_HASH=abc123...\n"
            "  3. caliclaw restart\n"
            "  4. On first MCP call you'll get a code via Telegram — agent\n"
            "     prompts for it once; session caches in ~/.config/telegram-mcp/"
        ),
    },
    "obsidian": {
        "command": "npx",
        "args": ["-y", "obsidian-mcp"],
        "_hint": "Obsidian — read/write vault notes, links, daily notes (filesystem-direct, no plugin)",
        "_setup": (
            "Setup:\n"
            "  1. Add to .env (path to your Obsidian vault):\n"
            "       OBSIDIAN_VAULT_PATH=/home/atlant/Documents/MyVault\n"
            "  2. caliclaw restart\n\n"
            "Note: filesystem-direct (no Local REST API plugin needed). Works\n"
            "even when Obsidian is closed."
        ),
    },
    "sqlite": {
        "command": "npx",
        "args": ["-y", "mcp-sqlite-server"],
        "_hint": "SQLite — query databases, inspect schemas, explain queries (great for caliclaw.db self-diagnosis)",
        "_setup": (
            "Setup:\n"
            "  1. Add to .env (path to SQLite DB):\n"
            "       SQLITE_DB_PATH=/home/atlant/caliclaw/caliclaw.db\n"
            "  2. caliclaw restart\n\n"
            "Useful for: 'how many messages this week?', 'which tasks failed?',\n"
            "'show me sessions with most turns', etc."
        ),
    },
    "postgres": {
        "command": "npx",
        "args": ["-y", "@modelcontextprotocol/server-postgres"],
        "_hint": "PostgreSQL — query DBs, inspect schemas, run analytics",
        "_setup": (
            "Setup:\n"
            "  1. Add to .env (libpq connection string):\n"
            "       POSTGRES_URL=postgresql://user:pass@host:5432/dbname\n"
            "  2. caliclaw restart\n\n"
            "Read-only by default. Pass --read-only=false in args for write."
        ),
    },
    "brave-search": {
        "command": "npx",
        "args": ["-y", "@modelcontextprotocol/server-brave-search"],
        "_hint": "Brave Search — web search backup (when Claude's WebSearch is rate-limited)",
        "_setup": (
            "Setup:\n"
            "  1. Get API key at https://brave.com/search/api/ (free tier: 2000 queries/mo)\n"
            "  2. Add to .env:\n"
            "       BRAVE_API_KEY=BSA...\n"
            "  3. caliclaw restart"
        ),
    },
    "tavily": {
        "command": "npx",
        "args": ["-y", "tavily-mcp"],
        "_hint": "Tavily — AI-native search (deeper than Brave; built for agents). Returns clean markdown.",
        "_setup": (
            "Setup:\n"
            "  1. Get API key at https://tavily.com (free tier: 1000 queries/mo)\n"
            "  2. Add to .env:\n"
            "       TAVILY_API_KEY=tvly-...\n"
            "  3. caliclaw restart\n\n"
            "Tavily is generally better for agents than Brave — it summarizes results,\n"
            "extracts content, and supports `search_depth=\"advanced\"` for harder queries."
        ),
    },
    "meta-ads": {
        "command": "npx",
        "args": ["-y", "@mikusnuz/meta-ads-mcp"],
        "_hint": "Meta Ads — Facebook & Instagram campaigns: targeting, audiences, creatives, insights (135 tools, API v25.0)",
        "_setup": (
            "Setup:\n"
            "  1. Create a Meta app at https://developers.facebook.com/apps\n"
            "     → add 'Marketing API' product\n"
            "  2. Generate a long-lived access token at\n"
            "     https://developers.facebook.com/tools/explorer/\n"
            "     Required scopes: ads_read, ads_management, business_management\n"
            "  3. Find your Ad Account ID at https://business.facebook.com\n"
            "     Format: act_1234567890\n"
            "  4. Add to .env:\n"
            "       META_ACCESS_TOKEN=EAAxxxxx...\n"
            "       META_AD_ACCOUNT_ID=act_1234567890\n"
            "  5. caliclaw restart\n\n"
            "What agent will be able to do:\n"
            "  - Create/pause campaigns, ad sets, ads\n"
            "  - Manage custom audiences (lookalike, retargeting, exclusions)\n"
            "  - Configure targeting (age/geo/interests/behaviors/devices)\n"
            "  - Pull insights (CPM, CPC, ROAS, frequency, breakdown by demo)\n"
            "  - Upload creatives (images/videos), A/B test variants\n\n"
            "Token tip: long-lived tokens last 60 days. For production, use a\n"
            "System User token from Business Manager (no expiry)."
        ),
    },
}


def _config_path() -> Path:
    return get_settings().mcp_config_path


def _load() -> dict:
    p = _config_path()
    if p.exists():
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except json.JSONDecodeError as e:
            ui.fail(f"Malformed {p}: {e}")
            sys.exit(1)
    return {"mcpServers": {}}


def _save(data: dict) -> None:
    p = _config_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


def _strip_internal_keys(cfg: dict) -> dict:
    return {k: v for k, v in cfg.items() if not k.startswith("_")}


def _allow_pattern(server_name: str) -> str:
    """Pattern to allowlist every tool exposed by a given MCP server.

    MCP tools are namespaced as `mcp__<server>__<tool>`. We grant
    `mcp__<server>__*` so any tool the server exposes works without the
    agent hitting an interactive permission prompt — caliclaw runs the
    agent non-interactively (Telegram surface), so there's no UI for the
    user to click "Allow" on.
    """
    return f"mcp__{server_name}__*"


async def cmd_mcp(args) -> None:
    sub = getattr(args, "mcp_command", None)

    if sub == "list" or sub is None:
        data = _load()
        servers = data.get("mcpServers", {})
        if not servers:
            ui.info("No MCP servers registered.")
            ui.c.print(f"[dim]Config: {_config_path()}[/dim]\n")
            ui.c.print("Try: [bold]caliclaw mcp add chrome[/bold]")
            return
        ui.c.print(f"[bold]MCP servers[/bold] ({_config_path()}):\n")
        for name, cfg in servers.items():
            cmd = cfg.get("command", "")
            cargs = " ".join(cfg.get("args", []))
            ui.c.print(f"  [bold cyan]{name}[/bold cyan]: {cmd} {cargs}")
        ui.c.print()
        return

    if sub == "path":
        ui.c.print(str(_config_path()))
        return

    if sub == "add":
        name = args.name
        data = _load()
        data.setdefault("mcpServers", {})

        if name in _PRESETS and not args.cmd:
            preset_full = _PRESETS[name]
            preset = _strip_internal_keys(preset_full)
            data["mcpServers"][name] = preset
            _save(data)
            grant_tools([_allow_pattern(name)])
            ui.ok(f"Added {name} from preset.")
            ui.c.print(f"  [dim]{preset['command']} {' '.join(preset['args'])}[/dim]")
            ui.c.print(f"  [dim]allowlisted: mcp__{name}__*[/dim]")
            setup = preset_full.get("_setup")
            if setup:
                ui.c.print(f"\n[bold yellow]{setup}[/bold yellow]")
            else:
                ui.c.print(f"\nRestart caliclaw for the change to take effect: [bold]caliclaw restart[/bold]")
            return

        if not args.cmd:
            ui.fail(f"No preset named {name!r}.")
            ui.c.print(f"\nPresets: [bold]{', '.join(_PRESETS.keys())}[/bold]")
            ui.c.print("Or supply --command (and optional --args) for a custom server.")
            sys.exit(1)

        data["mcpServers"][name] = {
            "command": args.cmd,
            "args": args.cmd_args or [],
        }
        _save(data)
        grant_tools([_allow_pattern(name)])
        ui.ok(f"Added MCP server {name!r}.")
        ui.c.print(f"  [dim]allowlisted: mcp__{name}__*[/dim]")
        ui.c.print(f"\nRestart caliclaw for the change to take effect: [bold]caliclaw restart[/bold]")
        return

    if sub == "remove":
        data = _load()
        servers = data.get("mcpServers", {})
        if args.name not in servers:
            ui.warn(f"No MCP server named {args.name!r}.")
            return
        del servers[args.name]
        _save(data)
        revoke_tools([_allow_pattern(args.name)])
        ui.ok(f"Removed {args.name!r}.")
        ui.c.print(f"  [dim]revoked: mcp__{args.name}__*[/dim]")
        ui.c.print(f"\nRestart caliclaw for the change to take effect: [bold]caliclaw restart[/bold]")
        return

    if sub == "presets":
        ui.c.print("[bold]Available presets:[/bold]\n")
        for name, cfg in _PRESETS.items():
            ui.c.print(f"  [bold cyan]{name}[/bold cyan] — {cfg['_hint']}")
            ui.c.print(f"    [dim]{cfg['command']} {' '.join(cfg['args'])}[/dim]")
            if cfg.get("_setup"):
                ui.c.print("    [dim](needs setup — run `caliclaw mcp help " + name + "`)[/dim]")
            ui.c.print()
        return

    if sub == "help":
        name = args.name
        if name not in _PRESETS:
            ui.fail(f"No preset named {name!r}.")
            ui.c.print(f"\nPresets: [bold]{', '.join(_PRESETS.keys())}[/bold]")
            sys.exit(1)
        cfg = _PRESETS[name]
        ui.c.print(f"[bold cyan]{name}[/bold cyan] — {cfg['_hint']}\n")
        ui.c.print(f"Command: [dim]{cfg['command']} {' '.join(cfg['args'])}[/dim]\n")
        setup = cfg.get("_setup")
        if setup:
            ui.c.print(f"[bold yellow]{setup}[/bold yellow]")
        else:
            ui.c.print("[dim]No setup needed — just `caliclaw mcp add " + name + "` and restart.[/dim]")
        return

    ui.fail(f"Unknown subcommand: {sub}")
    sys.exit(1)
