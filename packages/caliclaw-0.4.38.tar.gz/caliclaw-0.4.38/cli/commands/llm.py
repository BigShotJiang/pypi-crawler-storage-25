"""caliclaw llm — point caliclaw at a different LLM provider endpoint.

The engine natively respects ANTHROPIC_BASE_URL / ANTHROPIC_AUTH_TOKEN.
We persist them into .env and the daemon picks them up on next restart.

Presets:
    anthropic   — default, no override (use Claude Code login or ANTHROPIC_API_KEY)
    openrouter  — https://openrouter.ai/api/v1 (any OR model via OR's
                  Anthropic-compatible /v1/messages endpoint — Claude,
                  DeepSeek, Qwen, Llama, Gemini, etc.)
    deepseek    — https://api.deepseek.com/anthropic (DeepSeek-direct via
                  their native Anthropic-compat endpoint; tier mapping
                  v4-pro for sonnet/opus, v4-flash for haiku)
    custom      — free-form URL + token (claude-code-router, LiteLLM, your own
                  proxy that translates to GPT/Gemini/Llama)

`status` prints the current provider without writing anything.
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path
from typing import Optional


_PRESETS = {
    "anthropic":  ("(default)",                          "Anthropic direct — Claude Code login or ANTHROPIC_API_KEY"),
    "openrouter": ("https://openrouter.ai/api",          "OpenRouter (Anthropic-compat — Claude / DeepSeek / Qwen / Llama / Gemini …)"),
    "deepseek":   ("https://api.deepseek.com/anthropic", "DeepSeek direct (native Anthropic-compat — v4-pro / v4-flash)"),
    "custom":     ("",                                   "Custom URL + token (ccr / LiteLLM / your proxy)"),
}

# Per-tier defaults shown as the prompt placeholder. Empty default means
# "pass the alias through unchanged" — appropriate for ccr-style proxies
# that already understand `haiku`/`sonnet`/`opus`.
_TIER_DEFAULTS_OPENROUTER = {
    "haiku":  "anthropic/claude-haiku-4.5",
    "sonnet": "anthropic/claude-sonnet-4.6",
    "opus":   "anthropic/claude-opus-4.7",
}
# OR docs default for built-in CC subagents — pinned to opus for capability;
# users can re-run the wizard if they want a cheaper subagent tier.
_OPENROUTER_SUBAGENT_DEFAULT = "anthropic/claude-opus-4.7"
# DeepSeek's own model IDs — pro for the heavy tiers, flash for haiku.
# Suffix `[1m]` selects the 1M-context variant (per DeepSeek's CC docs).
_TIER_DEFAULTS_DEEPSEEK = {
    "haiku":  "deepseek-v4-flash",
    "sonnet": "deepseek-v4-pro[1m]",
    "opus":   "deepseek-v4-pro[1m]",
}
_TIER_DEFAULTS_CUSTOM = {"haiku": "", "sonnet": "", "opus": ""}
_TIER_HINTS = {
    "haiku":  "cheap — image describer, summaries",
    "sonnet": "main agent (default)",
    "opus":   "reforge, deep work",
}


def _upsert_env(project_root: Path, key: str, value: Optional[str]) -> None:
    """Set or remove KEY=value in .env.

    None deletes the line. Empty string writes `KEY=""` — needed for
    ANTHROPIC_API_KEY which OR's docs require to be explicitly empty so
    it doesn't shadow ANTHROPIC_AUTH_TOKEN.
    """
    env_file = project_root / ".env"
    lines: list[str] = []
    found = False
    if env_file.exists():
        for line in env_file.read_text().splitlines():
            if line.startswith(f"{key}="):
                if value is not None:
                    quoted = f'"{value}"' if value == "" else value
                    lines.append(f"{key}={quoted}")
                    found = True
                # else: skip (delete)
            else:
                lines.append(line)
    if value is not None and not found:
        quoted = f'"{value}"' if value == "" else value
        lines.append(f"{key}={quoted}")
    env_file.parent.mkdir(parents=True, exist_ok=True)
    env_file.write_text("\n".join(lines) + "\n" if lines else "")


def _get_env(project_root: Path, key: str) -> str:
    env_file = project_root / ".env"
    if not env_file.exists():
        return ""
    for line in env_file.read_text().splitlines():
        if line.startswith(f"{key}="):
            return line.split("=", 1)[1].strip()
    return ""


def _is_bot_running(project_root: Path) -> tuple[bool, int | None]:
    pid_file = project_root / "data" / "caliclaw.pid"
    if not pid_file.exists():
        return False, None
    try:
        pid = int(pid_file.read_text().strip())
    except (ValueError, OSError):
        return False, None
    try:
        os.kill(pid, 0)
        return True, pid
    except ProcessLookupError:
        return False, pid
    except PermissionError:
        return True, pid


def _print_status(project_root: Path) -> None:
    from cli.ui import ui
    base = _get_env(project_root, "ANTHROPIC_BASE_URL")
    token = _get_env(project_root, "ANTHROPIC_AUTH_TOKEN")
    ui.c.print()
    if not base:
        ui.c.print("  [bold]Provider:[/bold]  [red]anthropic (default)[/red]")
        ui.c.print("  [dim]Using Claude Code login or ANTHROPIC_API_KEY.[/dim]")
    else:
        ui.c.print(f"  [bold]Endpoint:[/bold]  [red]{base}[/red]")
        if token:
            masked = token[:6] + "…" + token[-4:] if len(token) > 12 else "set"
            ui.c.print(f"  [bold]Token:[/bold]     [dim]{masked}[/dim]")
        else:
            ui.c.print("  [bold]Token:[/bold]     [yellow]not set[/yellow]")
        any_override = False
        for tier in ("haiku", "sonnet", "opus"):
            value = _get_env(project_root, _tier_env_key(tier))
            if value:
                if not any_override:
                    ui.c.print("  [bold]Models:[/bold]")
                    any_override = True
                ui.c.print(f"    [dim]{tier:<7}[/dim] [red]{value}[/red]")
        if not any_override:
            ui.c.print("  [bold]Models:[/bold]    [dim]passthrough (proxy must understand haiku/sonnet/opus)[/dim]")
        # Provider-specific extras (DeepSeek sets all three; ccr proxies often
        # set none). Only print the lines that are actually populated so the
        # OpenRouter case stays clean.
        for label, env_key in (
            ("Default model",  "ANTHROPIC_MODEL"),
            ("Subagent model", "CLAUDE_CODE_SUBAGENT_MODEL"),
            ("Effort level",   "CLAUDE_CODE_EFFORT_LEVEL"),
        ):
            value = _get_env(project_root, env_key)
            if value:
                ui.c.print(f"  [bold]{label}:[/bold] [red]{value}[/red]")
    ui.c.print()


def _restart_if_running(project_root: Path) -> None:
    from cli.ui import ui
    alive, pid = _is_bot_running(project_root)
    if not alive:
        ui.info("Start the bot with [bold red]caliclaw start[/bold red] to apply.")
        return
    ui.c.print()
    ui.info(f"Bot is running (pid {pid}). Restart to apply?")
    try:
        confirm = input("  Restart now? [Y/n]: ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        confirm = "n"
        ui.c.print()
    if confirm in ("", "y", "yes"):
        import subprocess
        with ui.spin("Restarting..."):
            subprocess.run(
                [sys.executable, "-m", "cli.caliclaw_cli", "restart"],
                cwd=str(project_root),
                capture_output=True,
            )
        ui.ok("Bot restarted")
    else:
        ui.info("Run [bold red]caliclaw restart[/bold red] manually when ready.")


def _tier_env_key(tier: str) -> str:
    """Native engine env-var name for a given tier."""
    return f"ANTHROPIC_DEFAULT_{tier.upper()}_MODEL"


async def _purge_claude_sessions(reason: str) -> int:
    """Drop every active claude_session_id so the next turn starts fresh.

    Provider-specific message encodings (e.g. OR's redacted_thinking blocks
    via Bedrock) get rejected by other providers' /v1/messages endpoints
    with 400 invalid_request_error. Switching providers without clearing
    the session leaves the user one click away from a session-reset hint.
    Doing it proactively avoids that — they switch and their next message
    just works.

    The DB-side `messages` log + session.summary handoffs are preserved,
    so caliclaw still knows the full prior conversation; only Claude's
    server-side history reference is cleared.
    """
    from core.db import Database
    from cli.ui import ui

    db = Database()
    await db.connect()
    try:
        async with db.db.execute(
            "UPDATE sessions SET claude_session_id = NULL "
            "WHERE claude_session_id IS NOT NULL"
        ) as cur:
            sessions_cleared = cur.rowcount or 0
        async with db.db.execute("DELETE FROM directory_sessions") as cur:
            dirs_cleared = cur.rowcount or 0
        await db.db.commit()
    finally:
        await db.close()

    total = sessions_cleared + dirs_cleared
    if total:
        ui.info(
            f"Cleared {sessions_cleared} active session(s) and "
            f"{dirs_cleared} directory pointer(s) — {reason}."
        )
    return total


def _apply_anthropic(project_root: Path) -> None:
    """Reset to Anthropic-direct: clear endpoint vars and any tier overrides.

    Also clears ANTHROPIC_API_KEY="" — when reverting to Anthropic-direct
    the user wants their normal Anthropic auth chain (login or API_KEY env
    var) back, so we shouldn't leave a forced-empty entry shadowing it.
    """
    from cli.ui import ui
    _upsert_env(project_root, "ANTHROPIC_BASE_URL", None)
    _upsert_env(project_root, "ANTHROPIC_AUTH_TOKEN", None)
    _upsert_env(project_root, "ANTHROPIC_API_KEY", None)
    for tier in ("haiku", "sonnet", "opus"):
        _upsert_env(project_root, _tier_env_key(tier), None)
    # Provider-specific extras written by openrouter/deepseek presets.
    _upsert_env(project_root, "ANTHROPIC_MODEL", None)
    _upsert_env(project_root, "CLAUDE_CODE_SUBAGENT_MODEL", None)
    _upsert_env(project_root, "CLAUDE_CODE_EFFORT_LEVEL", None)
    ui.ok("Provider reset to Anthropic direct (cleared BASE_URL + AUTH_TOKEN + tier overrides).")


def _prompt_tier_models(project_root: Path, defaults: dict) -> None:
    """Ask the user for a model ID per tier; persist non-empty answers.

    Writes ANTHROPIC_DEFAULT_{HAIKU,SONNET,OPUS}_MODEL — the engine
    reads these natively and remaps `--model haiku/sonnet/opus` aliases
    to the configured IDs before sending to the endpoint.

    Pressing Enter accepts the shown default. The default itself may be
    empty ("") for the custom-proxy flow, in which case Enter means
    "leave alias passthrough — proxy understands haiku/sonnet/opus".
    """
    from cli.ui import ui
    if not sys.stdin.isatty():
        # Non-interactive: write defaults so the user gets a usable config
        # without having to know the env-var names.
        for tier, default in defaults.items():
            if default:
                _upsert_env(project_root, _tier_env_key(tier), default)
        return
    ui.c.print()
    ui.c.print("  [dim]Pick a model per tier (Enter = default in brackets, '-' = passthrough).[/dim]")
    ui.c.print("  [dim]Examples: anthropic/claude-sonnet-4.5 · deepseek/deepseek-chat · qwen/qwen-2.5-coder-32b · meta-llama/llama-3.3-70b-instruct · google/gemini-2.5-pro[/dim]")
    for tier, default in defaults.items():
        hint = _TIER_HINTS[tier]
        shown = default or "passthrough"
        try:
            raw = input(f"  {tier:<7} [{shown}]  ({hint}): ").strip()
        except (EOFError, KeyboardInterrupt):
            ui.c.print()
            ui.info("Cancelled tier prompts — keeping whatever was already set.")
            return
        key = _tier_env_key(tier)
        if raw == "-":
            _upsert_env(project_root, key, None)
            continue
        value = raw or default
        if value:
            _upsert_env(project_root, key, value)
        else:
            _upsert_env(project_root, key, None)


def _apply_openrouter(project_root: Path, token: Optional[str]) -> None:
    from cli.ui import ui
    base = _PRESETS["openrouter"][0]
    if not token:
        if not sys.stdin.isatty():
            ui.fail("Non-interactive: pass token as 3rd arg — caliclaw llm openrouter <key>")
            sys.exit(1)
        ui.c.print()
        ui.c.print("  [dim]Get a key at https://openrouter.ai/keys (starts with sk-or-...)[/dim]")
        try:
            token = input("  OpenRouter API key: ").strip()
        except (EOFError, KeyboardInterrupt):
            ui.c.print()
            ui.info("Cancelled.")
            return
    if not token:
        ui.fail("Empty token — nothing written.")
        return
    # Clear DeepSeek-specific extras (ANTHROPIC_MODEL, EFFORT_LEVEL) that
    # don't apply to OR. Subagent model is shared between presets — overwrite
    # below rather than null it out.
    _upsert_env(project_root, "ANTHROPIC_MODEL", None)
    _upsert_env(project_root, "CLAUDE_CODE_EFFORT_LEVEL", None)
    _upsert_env(project_root, "ANTHROPIC_BASE_URL", base)
    _upsert_env(project_root, "ANTHROPIC_AUTH_TOKEN", token)
    # OR docs require ANTHROPIC_API_KEY="" — without it, an inherited
    # ANTHROPIC_API_KEY (from `claude login`, parent shell, etc.) shadows
    # AUTH_TOKEN and CC silently sends Anthropic auth to OR's endpoint.
    _upsert_env(project_root, "ANTHROPIC_API_KEY", "")
    _upsert_env(project_root, "CLAUDE_CODE_SUBAGENT_MODEL", _OPENROUTER_SUBAGENT_DEFAULT)
    ui.ok(f"Wrote ANTHROPIC_BASE_URL={base}")
    ui.ok("Wrote ANTHROPIC_AUTH_TOKEN=*****")
    ui.ok('Wrote ANTHROPIC_API_KEY="" (prevents shadowing of AUTH_TOKEN)')
    ui.ok(f"Wrote CLAUDE_CODE_SUBAGENT_MODEL={_OPENROUTER_SUBAGENT_DEFAULT}")
    _prompt_tier_models(project_root, _TIER_DEFAULTS_OPENROUTER)


def _apply_deepseek(project_root: Path, token: Optional[str]) -> None:
    """DeepSeek-direct via their native Anthropic-compat endpoint.

    Writes the full env block from DeepSeek's CC integration guide:
    BASE_URL, AUTH_TOKEN, ANTHROPIC_MODEL, the three tier overrides,
    CLAUDE_CODE_SUBAGENT_MODEL (built-in subagents) and EFFORT_LEVEL.
    Tier defaults map sonnet/opus → v4-pro[1m] and haiku → v4-flash;
    user can still override per tier in the prompt.
    """
    from cli.ui import ui
    base = _PRESETS["deepseek"][0]
    if not token:
        if not sys.stdin.isatty():
            ui.fail("Non-interactive: pass token as 3rd arg — caliclaw llm deepseek <key>")
            sys.exit(1)
        ui.c.print()
        ui.c.print("  [dim]Get a key at https://platform.deepseek.com/api_keys[/dim]")
        try:
            token = input("  DeepSeek API key: ").strip()
        except (EOFError, KeyboardInterrupt):
            ui.c.print()
            ui.info("Cancelled.")
            return
    if not token:
        ui.fail("Empty token — nothing written.")
        return
    _upsert_env(project_root, "ANTHROPIC_BASE_URL", base)
    _upsert_env(project_root, "ANTHROPIC_AUTH_TOKEN", token)
    # Same shadowing risk as OR: any inherited ANTHROPIC_API_KEY would
    # take precedence over our AUTH_TOKEN and route to Anthropic, not DS.
    _upsert_env(project_root, "ANTHROPIC_API_KEY", "")
    # ANTHROPIC_MODEL is the catch-all DeepSeek uses when CC asks for an
    # unrecognized model string; pinning it to v4-pro[1m] keeps any stray
    # call from falling back to a default we didn't authorize.
    _upsert_env(project_root, "ANTHROPIC_MODEL", "deepseek-v4-pro[1m]")
    _upsert_env(project_root, "CLAUDE_CODE_SUBAGENT_MODEL", "deepseek-v4-flash")
    _upsert_env(project_root, "CLAUDE_CODE_EFFORT_LEVEL", "max")
    ui.ok(f"Wrote ANTHROPIC_BASE_URL={base}")
    ui.ok("Wrote ANTHROPIC_AUTH_TOKEN=*****")
    ui.ok('Wrote ANTHROPIC_API_KEY="" (prevents shadowing of AUTH_TOKEN)')
    ui.ok("Wrote ANTHROPIC_MODEL=deepseek-v4-pro[1m]")
    ui.ok("Wrote CLAUDE_CODE_SUBAGENT_MODEL=deepseek-v4-flash")
    ui.ok("Wrote CLAUDE_CODE_EFFORT_LEVEL=max")
    _prompt_tier_models(project_root, _TIER_DEFAULTS_DEEPSEEK)


def _apply_custom(project_root: Path, url: Optional[str]) -> None:
    from cli.ui import ui
    if not url:
        if not sys.stdin.isatty():
            ui.fail("Non-interactive: pass URL as 3rd arg — caliclaw llm custom <url>")
            sys.exit(1)
        ui.c.print()
        ui.c.print("  [dim]Anthropic-compatible endpoint (claude-code-router, LiteLLM, …)[/dim]")
        try:
            url = input("  Base URL (e.g. http://localhost:3456): ").strip()
        except (EOFError, KeyboardInterrupt):
            ui.c.print()
            ui.info("Cancelled.")
            return
    if not url:
        ui.fail("Empty URL — nothing written.")
        return
    token = ""
    if sys.stdin.isatty():
        try:
            token = input("  Auth token (leave empty if proxy doesn't need one): ").strip()
        except (EOFError, KeyboardInterrupt):
            ui.c.print()
            return
    _upsert_env(project_root, "ANTHROPIC_BASE_URL", url)
    _upsert_env(project_root, "ANTHROPIC_AUTH_TOKEN", token or None)
    ui.ok(f"Wrote ANTHROPIC_BASE_URL={url}")
    if token:
        ui.ok("Wrote ANTHROPIC_AUTH_TOKEN=*****")
    else:
        ui.info("No auth token set — proxy must accept unauthenticated requests.")
    _prompt_tier_models(project_root, _TIER_DEFAULTS_CUSTOM)


def _list_presets() -> None:
    from cli.ui import ui
    ui.c.print()
    ui.c.print("  [bold]Available providers:[/bold]")
    for name, (default, desc) in _PRESETS.items():
        ui.c.print(f"    [bold red]{name:<11}[/bold red] [dim]{desc}[/dim]")
    ui.c.print()
    ui.c.print("  [dim]Usage:[/dim]")
    ui.c.print("    [bold]caliclaw llm[/bold]                  show current provider")
    ui.c.print("    [bold]caliclaw llm anthropic[/bold]            reset to Claude direct")
    ui.c.print("    [bold]caliclaw llm openrouter[/bold] [<key>]   route through OpenRouter")
    ui.c.print("    [bold]caliclaw llm deepseek[/bold]   [<key>]   DeepSeek-direct (v4-pro / v4-flash)")
    ui.c.print("    [bold]caliclaw llm custom[/bold]     [<url>]   custom Anthropic-compat proxy")
    ui.c.print()


async def cmd_llm(args: argparse.Namespace) -> None:
    """Configure which LLM endpoint caliclaw agents hit."""
    from core.config import get_settings
    from cli.ui import ui

    settings = get_settings()
    project_root = settings.project_root

    action = (getattr(args, "llm_action", "") or "").strip().lower()
    value = (getattr(args, "llm_value", "") or "").strip()

    if not action or action == "status":
        _print_status(project_root)
        if not action:
            _list_presets()
        return

    if action == "list" or action == "help":
        _list_presets()
        return

    if action == "anthropic":
        _apply_anthropic(project_root)
    elif action == "openrouter":
        _apply_openrouter(project_root, value or None)
    elif action == "deepseek":
        _apply_deepseek(project_root, value or None)
    elif action == "custom":
        _apply_custom(project_root, value or None)
    else:
        ui.fail(f"Unknown provider: {action}")
        _list_presets()
        sys.exit(1)
        return

    # Provider switched — drop active Claude session ids. Their server-side
    # history is encoded for the previous provider and other endpoints will
    # reject it (e.g. Anthropic-direct rejects OR's `redacted_thinking`
    # blocks with 400 invalid_request_error).
    await _purge_claude_sessions(reason=f"provider switched to {action}")

    _restart_if_running(project_root)
