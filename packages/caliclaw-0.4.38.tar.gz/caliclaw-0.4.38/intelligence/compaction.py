from __future__ import annotations

import asyncio
import logging
import subprocess
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import List, Optional

from core.agent import AgentConfig, AgentPool
from core.config import get_settings
from core.db import Database

logger = logging.getLogger(__name__)


class ConversationCompactor:
    """Compacts long conversations by archiving + lossless verbatim handoff.

    The compaction sequence:
      1. Archive the full conversation to `<workspace>/conversations/*.md`
         (audit trail; nothing depends on this file at runtime)
      2. Build a verbatim replay of the most recent N messages within a
         char budget — see `core.handoff.build_lossless_handoff`
      3. Drop the Claude-side session id (`claude_session_id = NULL`) so
         the next turn starts a fresh Claude session — context bloat gone
      4. Store the replay in `sessions.summary`; the bot consumes it once
         on the next user message and prepends it to the prompt

    Net effect: Claude reasoning becomes lean again, but no information is
    lost from the user's point of view — the next turn picks up with the
    full recent dialogue restored.
    """

    def __init__(self, db: Database):
        self.db = db
        self._max_messages_before_compaction = 100
        self._archive_dir = get_settings().workspace_dir / "conversations"
        self._archive_dir.mkdir(parents=True, exist_ok=True)

    async def check_and_compact(self, session_id: str, force: bool = False) -> bool:
        """Compact if needed (or always when `force=True`). Returns True if
        compaction actually ran. Manual `/squeeze` passes force=True so the
        user's explicit intent is honored regardless of message count."""
        count = await self.db.count_messages(session_id)
        if not force and count < self._max_messages_before_compaction:
            return False

        logger.info(
            "Session %s has %d messages, compacting (force=%s)...",
            session_id, count, force,
        )

        await self._archive_conversation(session_id)

        from core.handoff import build_lossless_handoff
        handoff = await build_lossless_handoff(self.db, session_id)

        # Drop Claude-side session — the bloated history goes with it.
        # Store the verbatim replay; bot picks it up on the next turn.
        await self.db.update_session(
            session_id,
            claude_session_id=None,
            summary=handoff,
            status="compacted",
        )

        logger.info(
            "Session %s compacted: claude_session_id cleared, "
            "%d-char handoff staged", session_id, len(handoff),
        )
        return True

    async def _archive_conversation(self, session_id: str) -> Path:
        """Save full conversation to markdown file."""
        messages = await self.db.get_messages(session_id, limit=10000)

        now = datetime.now(timezone.utc)
        filename = f"{now.strftime('%Y-%m-%d')}_{session_id[:12]}.md"
        path = self._archive_dir / filename

        lines = [f"# Conversation Archive\n", f"Session: {session_id}\n", f"Date: {now.isoformat()}\n\n---\n"]

        for msg in messages:
            role = msg["role"].upper()
            ts = datetime.fromtimestamp(msg["timestamp"], tz=timezone.utc).strftime("%H:%M:%S")
            content = msg["content"]
            lines.append(f"\n## [{ts}] {role}\n\n{content}\n")

        path.write_text("\n".join(lines), encoding="utf-8")
        logger.info("Archived conversation to %s", path)
        return path

class DreamingEngine:
    """Nightly memory consolidation — reads SQLite messages, writes memory.

    Runs at 3 AM via the task scheduler. Pulls every message logged in the
    previous 24h from the `messages` table (the canonical source — every
    Telegram turn lands there), summarises with haiku, and writes the
    digest to `memory/dream_YYYY_MM_DD.md` via MemoryManager.

    Why SQLite and not the .md archive glob (the old behavior): archives
    only get created when the user manually runs `/squeeze`. The user
    typed 463 messages between Apr 28 and May 2 with zero archives — the
    dreamer would have seen nothing to process every single night.
    """

    # Hard cap so a chatty day doesn't blow the haiku context window.
    # Each message gets truncated to MAX_PER_MSG; total prompt stays
    # bounded around (MAX_MESSAGES * MAX_PER_MSG) ≈ 60 KB worst case.
    MAX_MESSAGES = 300
    MAX_PER_MSG = 200
    MIN_MESSAGES_TO_DREAM = 5

    def __init__(self, db: Database, pool: AgentPool):
        self.db = db
        self.pool = pool

    async def dream(self, target_date: Optional[str] = None) -> str:
        """Consolidate the day. Returns digest text (also persisted to memory).

        target_date: ISO date string (YYYY-MM-DD) to consolidate. Defaults
        to "yesterday in the user's TZ" — cron fires at 3 AM local, so by
        then "today" is a few hours old; we want the day that just ended.
        """
        settings = get_settings()

        # Resolve target date in the user's TZ so a 3 AM cron fire wraps
        # up the calendar day that just ended in their timezone.
        try:
            from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
            tz = ZoneInfo(settings.tz)
        except (ZoneInfoNotFoundError, ImportError, ValueError):
            tz = timezone.utc

        if target_date:
            day_str = target_date
        else:
            # Cron fires at 3 AM local; "now - 1 day" lands on yesterday at
            # 3 AM, whose date string is the day that just ended.
            day_str = (datetime.now(tz) - timedelta(days=1)).strftime("%Y-%m-%d")

        # Compute UTC second bounds for that local day.
        day_start_local = datetime.strptime(day_str, "%Y-%m-%d").replace(tzinfo=tz)
        day_end_local = day_start_local.replace(hour=23, minute=59, second=59)
        ts_start = day_start_local.timestamp()
        ts_end = day_end_local.timestamp()

        # Pull messages directly from SQLite — bypass per-session API
        # because we want a cross-session daily view.
        async with self.db.db.execute(
            "SELECT role, content, timestamp FROM messages "
            "WHERE timestamp BETWEEN ? AND ? "
            "ORDER BY timestamp ASC LIMIT ?",
            (ts_start, ts_end, self.MAX_MESSAGES),
        ) as cur:
            rows = await cur.fetchall()

        if len(rows) < self.MIN_MESSAGES_TO_DREAM:
            logger.info(
                "Dreamer: %s had %d messages (<%d threshold), skipping",
                day_str, len(rows), self.MIN_MESSAGES_TO_DREAM,
            )
            return f"Skipped {day_str}: {len(rows)} messages (below threshold)."

        # Build a compact transcript. Roles get one-letter prefixes to
        # save tokens; very long messages get truncated mid-line so the
        # summariser sees enough context but doesn't drown.
        lines = []
        for role, content, ts in rows:
            content = (content or "").strip().replace("\n", " ")
            if len(content) > self.MAX_PER_MSG:
                content = content[: self.MAX_PER_MSG] + "…"
            tag = "U" if role == "user" else "A"
            lines.append(f"{tag}: {content}")
        transcript = "\n".join(lines)

        config = AgentConfig(
            name="dreamer",
            model="haiku",
            system_prompt=(
                "You are the dreaming engine — caliclaw's nightly memory consolidator.\n"
                "Read the day's conversation transcript (U=user, A=assistant) and write\n"
                "a tight digest of what's worth remembering long-term. Skip pleasantries,\n"
                "skip transient debugging chatter. Focus on:\n"
                "  - Decisions made (architectural, project, life)\n"
                "  - Facts learned about the user or their projects\n"
                "  - Recurring patterns / preferences worth noting\n"
                "  - Open threads / promises to follow up on\n\n"
                "Format (Markdown):\n"
                "## Decisions\n- ...\n\n"
                "## User & Project notes\n- ...\n\n"
                "## Patterns\n- ...\n\n"
                "## Open threads\n- ...\n\n"
                "Be terse. Empty section → omit it entirely."
            ),
            timeout_seconds=180,
            working_dir=settings.workspace_dir,
        )

        result = await self.pool.run(
            config,
            f"Date: {day_str}\nMessage count: {len(rows)}\n\nTranscript:\n{transcript}",
        )

        if not result.text or not result.text.strip():
            logger.warning("Dreamer: %s produced empty digest", day_str)
            return f"Dream for {day_str} produced no output."

        from intelligence.memory import MemoryManager
        mm = MemoryManager()
        mm.save(
            name=f"Dream {day_str}",
            description=f"Nightly digest of {len(rows)} messages from {day_str}",
            mem_type="project",
            content=result.text,
            filename=f"dream_{day_str.replace('-', '_')}.md",
        )

        logger.info(
            "Dreamer: wrote digest for %s (%d msgs in, %d chars out)",
            day_str, len(rows), len(result.text),
        )
        return result.text


class ContextInjector:
    """Automatically injects system context into agent prompts."""

    @staticmethod
    async def get_context() -> str:
        """Gather current system context for injection."""
        import asyncio
        from datetime import datetime

        parts = [f"Current time: {datetime.now().strftime('%Y-%m-%d %H:%M %Z')}"]

        # System stats
        try:
            proc = await asyncio.create_subprocess_exec(
                "sh", "-c",
                "echo \"Load: $(uptime | awk -F'load average:' '{print $2}')\"; "
                "echo \"Disk: $(df -h / | tail -1 | awk '{print $5}')\"; "
                "echo \"RAM: $(free -m | awk '/Mem:/{printf \"%d/%dMB\", $3, $2}')\"",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.DEVNULL,
            )
            stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=5)
            parts.append(stdout.decode().strip())
        except (subprocess.TimeoutExpired, OSError, asyncio.TimeoutError):
            pass

        return "\n".join(parts)
