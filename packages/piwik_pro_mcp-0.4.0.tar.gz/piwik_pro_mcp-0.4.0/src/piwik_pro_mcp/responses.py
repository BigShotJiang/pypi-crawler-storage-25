#!/usr/bin/env python3
"""
MCP-specific Response Models for Piwik PRO Analytics API

This module provides minimal Pydantic models for MCP-specific operations
like create/update/delete status responses. It complements the existing
piwik_pro_api models without duplicating API response structures.
"""

from pydantic import BaseModel, ConfigDict, Field, model_serializer

from piwik_pro_mcp.api.methods.tracker_settings.models import AppTrackerSettings, GlobalTrackerSettings


class OperationStatusResponse(BaseModel):
    """Standard response for create/update/delete operations."""

    status: str = Field(..., description="Operation status (success, error, etc.)")
    message: str = Field(..., description="Descriptive message about the operation")


class UpdateStatusResponse(BaseModel):
    """Response for update operations with field tracking."""

    status: str = Field(..., description="Update status")
    message: str = Field(..., description="Descriptive message about the update")
    updated_fields: list[str] = Field(..., description="List of fields that were updated")


class TrackerSettingsResponse(BaseModel):
    """Flat tracker settings response model."""

    # Shared v2 tracker settings fields
    anonymize_visitor_geolocation_level: str | None = Field(None, description="Geolocation anonymization level")
    anonymize_visitor_ip_level: int | None = Field(None, description="Anonymize 'n' octets of visitor IP addresses")
    campaign_content_params: list[str] = Field(default_factory=list, description="Campaign content parameters")
    campaign_id_params: list[str] = Field(default_factory=list, description="Campaign ID parameters")
    campaign_keyword_params: list[str] = Field(default_factory=list, description="Campaign keyword parameters")
    campaign_medium_params: list[str] = Field(default_factory=list, description="Campaign medium parameters")
    campaign_name_params: list[str] = Field(default_factory=list, description="Campaign name parameters")
    campaign_source_params: list[str] = Field(default_factory=list, description="Campaign source parameters")
    create_new_visit_when_campaign_changes: bool | None = Field(
        None, description="Create new visit when campaign changes"
    )
    create_new_visit_when_website_referrer_changes: bool | None = Field(
        None, description="Create new visit when referrer changes"
    )
    enable_fingerprinting_across_websites: bool | None = Field(
        None, description="Enable fingerprinting across websites"
    )
    set_ip_tracking: bool | None = Field(None, description="Enable IP tracking")
    exclude_crawlers: bool | None = Field(None, description="Exclude crawler bots")
    exclude_unknown_urls: bool | None = Field(None, description="Exclude unknown URLs")
    excluded_ips: list[str] = Field(default_factory=list, description="IPs excluded from tracking")
    excluded_user_agents: list[str] = Field(
        default_factory=list, description="User agent strings excluded from tracking"
    )
    site_search_query_params: list[str] = Field(default_factory=list, description="Site search query parameters")
    site_search_category_params: list[str] = Field(default_factory=list, description="Site search category parameters")
    fingerprint_based_on_anonymized_ip: bool | None = Field(None, description="Fingerprint based on anonymized IP")
    keep_url_fragment: bool | None = Field(None, description="Keep URL fragment in tracking")
    session_limit_exceeded_action: str | None = Field(None, description="Session limit exceeded action")
    session_max_duration_seconds: int | None = Field(None, description="Maximum session duration in seconds")
    session_max_event_count: int | None = Field(None, description="Maximum events per session")
    strip_site_search_query_parameters: bool | None = Field(None, description="Strip site search query parameters")
    tracking_fingerprint_disabled: bool | None = Field(None, description="Disable tracking fingerprint")
    use_session_hash: bool | None = Field(None, description="Use session hash for non-anonymous events")
    use_anonymous_session_hash: bool | None = Field(None, description="Use session hash for anonymous events")
    url_query_parameter_to_exclude_from_url: list[str] = Field(
        default_factory=list, description="URL query parameters to exclude"
    )
    urls: list[str] = Field(default_factory=list, description="Valid URLs for the app")

    # Common field
    updated_at: str | None = Field(None, description="Last modification timestamp")


class TrackerSettingsAppGetResponse(BaseModel):
    """Response model for app tracker settings with optional detailed breakdown."""

    model_config = ConfigDict(populate_by_name=True)

    settings: TrackerSettingsResponse = Field(..., description="Resolved effective settings for the app")
    app_settings: AppTrackerSettings | None = Field(
        None,
        description="Raw app-specific settings as returned by the app tracker settings endpoint",
    )
    global_settings: GlobalTrackerSettings | None = Field(
        None, description="Raw global tracker settings used as defaults for the app"
    )

    @model_serializer(mode="plain")
    def _serialize_without_none(self):
        """Omit optional detailed sections when they are not populated."""
        payload = {"settings": self.settings.model_dump(exclude_none=True)}
        if self.app_settings is not None:
            payload["app_settings"] = self.app_settings.model_dump()
        if self.global_settings is not None:
            payload["global_settings"] = self.global_settings.model_dump()
        return payload


class InstallationCodeMCPResponse(BaseModel):
    """Response model for container installation code tool."""

    code: str = Field("", description="Installation code snippet")


class CopyResourceResponse(BaseModel):
    """
    Normalized response for Tag Manager copy operations.

    Provides a consistent shape across tags, triggers, and variables, abstracting
    minor schema differences in API responses.

    Attributes:
        resource_id: UUID of the newly created resource copy
        resource_type: Resource type (tag | trigger | variable)
        operation_id: UUID of the background operation created by the copy call
        copied_into_app_id: App UUID where the copy was created
        name: Optional new name of the copied resource, when available
        with_triggers: Indicates whether triggers were copied (tags only)
    """

    resource_id: str = Field(..., description="UUID of the copied resource")
    resource_type: str = Field(..., description="Resource type")
    operation_id: str = Field(..., description="Operation UUID created by the copy call")
    copied_into_app_id: str = Field(..., description="Target app UUID")
    name: str | None = Field(None, description="Name of the copied resource if available")
    with_triggers: bool | None = Field(None, description="Whether triggers were copied (tags only)")
