"""Tests for the useless_advice core module."""

from collections import Counter

from useless_advice import get_advice
from useless_advice.cli import get_cli_version, main
from useless_advice.core import ADVICE


def test_get_advice_returns_string() -> None:
    advice = get_advice()
    assert isinstance(advice, str)



def test_get_advice_returns_known_value() -> None:
    advice = get_advice()
    assert advice in ADVICE
    assert advice


def test_cli_count_smoke(capsys) -> None:
    main(["--count", "1"])
    output = capsys.readouterr().out
    assert "Useless Advice Generator" in output
    assert any(advice in output for advice in ADVICE)


def test_cli_version_smoke(capsys) -> None:
    try:
        main(["--version"])
    except SystemExit as exc:
        assert exc.code == 0
    output = capsys.readouterr().out.strip()
    assert output == get_cli_version()


def test_advice_has_no_exact_duplicates() -> None:
    duplicates = [item for item, count in Counter(ADVICE).items() if count > 1]
    assert duplicates == []
