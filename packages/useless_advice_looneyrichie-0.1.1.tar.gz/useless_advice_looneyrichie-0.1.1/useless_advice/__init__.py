"""Public package interface for useless_advice."""

from .core import __version__, get_advice


__all__ = ["get_advice", "__version__"]