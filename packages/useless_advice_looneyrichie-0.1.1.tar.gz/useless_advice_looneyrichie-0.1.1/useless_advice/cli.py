"""Command-line interface for useless_advice."""

import argparse
from importlib import metadata
from collections.abc import Sequence

from .core import __version__, get_advice


def get_cli_version() -> str:
    """Return a human-readable CLI version string."""
    try:
        package_version = metadata.version("useless-advice-looneyrichie")
    except metadata.PackageNotFoundError:
        package_version = "uninstalled"
    return f"useless_advice {__version__} (package {package_version})"


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    """Parse command-line arguments for the advice generator."""
    parser = argparse.ArgumentParser(description="Generate completely useless advice.")
    parser.add_argument(
        "--version",
        action="version",
        version=get_cli_version(),
    )
    parser.add_argument(
        "--count",
        type=int,
        default=None,
        help="Print a fixed number of advice lines and exit.",
    )
    return parser.parse_args(argv)


def main(argv: Sequence[str] | None = None) -> None:
    """Print useless advice until the user stops the program."""
    args = parse_args(argv)

    print("=" * 30)
    print("Useless Advice Generator")
    print("=" * 30)

    if args.count is not None:
        for _ in range(max(args.count, 0)):
            print(get_advice())
            print("-" * 30)
        return

    while True:
        print(get_advice())
        input("Press Enter To Continue...")
        print("-" * 30)


if __name__ == "__main__":
    main()