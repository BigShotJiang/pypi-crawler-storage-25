# Useless Advice

Useless Advice is a small Python package and CLI that returns random, completely unhelpful advice.

## Installation

Install from the project directory:

```bash
pip install .
```

For development:

```bash
pip install -e .[dev]
```

## Python Usage

```python
import useless_advice

print(useless_advice.__version__)
print(useless_advice.get_advice())
```

## CLI Usage

Start the interactive CLI:

```bash
useless_advice
```

Print a fixed number of advice lines and exit:

```bash
useless_advice --count 3
```

Show the installed CLI version:

```bash
useless_advice --version
```

## Development

Run the test suite:

```bash
pytest
```

Build distribution artifacts:

```bash
python -m build
```

Validate the built artifacts:

```bash
python -m twine check dist/*
```

## Repository

- Homepage: https://github.com/LooneyRichie/Useless-Advice
- Issues: https://github.com/LooneyRichie/Useless-Advice/issues
