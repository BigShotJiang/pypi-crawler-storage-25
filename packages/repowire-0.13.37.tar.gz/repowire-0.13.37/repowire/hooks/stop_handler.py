#!/usr/bin/env python3
"""Stop / AfterAgent hook handler - captures responses and delivers to daemon."""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

from repowire.hooks._tmux import get_pane_id
from repowire.hooks.adapters import hook_output, normalize
from repowire.hooks.ask_lifecycle import fetch_and_filter_pending, format_reminder_block
from repowire.hooks.chat_delta_streamer import streamer_pid_path
from repowire.hooks.utils import (
    daemon_post,
    get_display_name,
    pop_query_cid,
    update_status,
)
from repowire.hooks.ws_hook_supervisor import maybe_respawn
from repowire.session.transcript import (
    extract_last_assistant_turn_id,
    extract_last_turn_pair,
    extract_last_turn_tool_calls,
)


def _stop_chat_delta_streamer(pane_id: str | None) -> None:
    """Signal the per-turn streamer (if any) to exit by removing its pidfile.

    Pidfile-driven shutdown rather than SIGTERM: the streamer is cooperatively
    polling the pidfile inside its tight loop, so removal is the lowest-coupling
    end-of-turn signal. Safe to no-op when streaming is disabled or the
    streamer already exited on its own.
    """
    if not pane_id:
        return
    try:
        streamer_pid_path(pane_id).unlink()
    except FileNotFoundError:
        pass
    except OSError:
        pass


def _post_chat_turn(
    peer_name: str,
    role: str,
    text: str,
    tool_calls: list[dict[str, str]] | None = None,
    pane_id: str | None = None,
    session_id: str | None = None,
    turn_id: str | None = None,
) -> None:
    """Post a chat turn to the daemon for dashboard display. Best-effort.

    ``turn_id`` is the assistant message uuid when known; it lets the dashboard
    reconcile streaming-delta bubbles to their final turn deterministically and
    lets the daemon reject late deltas server-side.
    """
    payload: dict = {"peer": peer_name, "role": role, "text": text}
    if tool_calls:
        payload["tool_calls"] = tool_calls
    if pane_id:
        payload["pane_id"] = pane_id
    if session_id:
        payload["session_id"] = session_id
    if turn_id:
        payload["turn_id"] = turn_id
    daemon_post("/events/chat", payload)


def main(backend: str = "claude-code") -> int:
    """Main entry point for stop hook."""
    try:
        input_data = json.loads(sys.stdin.read())
    except json.JSONDecodeError as e:
        print(f"repowire stop: invalid JSON input: {e}", file=sys.stderr)
        return 0

    if input_data.get("stop_hook_active", False):
        return 0

    payload = normalize(input_data, backend)

    peer_display = get_display_name()
    pane_id = get_pane_id()

    # Lazy-repair: if the ws-hook process for this pane died (OOM, SIGKILL,
    # unhandled exception), Stop is the cheapest place to notice and relaunch.
    # No new polling -- this piggy-backs on traffic that already runs every turn.
    maybe_respawn(pane_id, backend=backend, cwd=input_data.get("cwd") or os.getcwd())

    # Get response text: adapter extracts from agent-specific fields,
    # fall back to transcript parsing for Claude Code
    assistant_text = payload.response_text
    user_text = None
    tool_calls: list = []
    turn_id: str | None = None

    if payload.transcript_path:
        transcript_path = Path(payload.transcript_path).expanduser().resolve()
        user_text, transcript_text = extract_last_turn_pair(transcript_path)
        if transcript_text:
            assistant_text = transcript_text
        tool_calls = extract_last_turn_tool_calls(transcript_path) if assistant_text else []
        turn_id = extract_last_assistant_turn_id(transcript_path)

    # Strip whitespace-only texts to prevent empty chat bubbles
    if user_text and not user_text.strip():
        user_text = None
    if assistant_text and not assistant_text.strip():
        assistant_text = None

    # Signal the per-turn delta streamer (if running) to exit before posting
    # the final chat_turn. Order matters only weakly — the dashboard reconciles
    # by replacing accumulated deltas with the final turn — but stopping the
    # streamer first avoids a last-instant delta arriving after the final.
    _stop_chat_delta_streamer(pane_id)

    if user_text:
        _post_chat_turn(
            peer_display,
            "user",
            user_text,
            pane_id=pane_id,
            session_id=payload.session_id or None,
        )
    if assistant_text:
        _post_chat_turn(
            peer_display,
            "assistant",
            assistant_text,
            tool_calls or None,
            pane_id=pane_id,
            session_id=payload.session_id or None,
            turn_id=turn_id,
        )

    # Deliver response to daemon for legacy /query future resolution.
    # The query FIFO is single-purpose (only /query cids land here), so this
    # never collides with the ask-ack lifecycle.
    if pane_id and assistant_text:
        resp_payload: dict = {"pane_id": pane_id, "text": assistant_text}
        cid = pop_query_cid(pane_id)
        if cid:
            resp_payload["correlation_id"] = cid
        daemon_post("/response", resp_payload)

    # Ask-ack reminder: poll daemon for open asks targeting this peer.
    # Backstop only — ws-hook already pasted the original ask into the
    # terminal; this catches missed/un-acked asks on every Stop fire.
    # Surface via Stop's decision=block + reason: Stop doesn't accept
    # additionalContext, but block+reason keeps Claude generating with
    # the reason as continuation context. stop_hook_active=true on the
    # follow-up Stop (we early-return at top of main()) bounds it to one
    # nudge per response cycle.
    reminder_text: str | None = None
    if pane_id:
        transcript_path = (
            Path(payload.transcript_path).expanduser().resolve()
            if payload.transcript_path else None
        )
        due = fetch_and_filter_pending(pane_id, transcript_path)
        if due:
            reminder_text = format_reminder_block(due)

    # Mark peer online and turn_state=idle (turn finished cleanly).
    if pane_id:
        if not update_status(pane_id, "online", use_pane_id=True, turn_state="idle"):
            print(
                f"repowire stop: failed to update status for pane {pane_id}",
                file=sys.stderr,
            )
    else:
        if not update_status(peer_display, "online", turn_state="idle"):
            print(
                f"repowire stop: failed to update status for {peer_display}",
                file=sys.stderr,
            )

    if reminder_text:
        # Per-backend reminder injection. Each backend's end-of-turn hook
        # accepts a different decision keyword to inject `reason` as
        # continuation context for the next prompt:
        #   claude-code, codex: {"decision": "block", "reason": ...}
        #     Reason becomes continuation context (Claude) or a new
        #     continuation prompt (Codex). stop_hook_active=true on the
        #     follow-up Stop bounds the loop (early-return at top of main).
        #   gemini AfterAgent:  {"decision": "deny",  "reason": ...}
        #     Reason becomes a new prompt to force a retry turn.
        # opencode uses a plugin runtime, not this hook — see follow-up
        # issue for plugin-side reminder path.
        decision_keyword = {
            "claude-code": "block",
            "codex": "block",
            "gemini": "deny",
        }.get(backend)
        if decision_keyword:
            print(json.dumps({
                "decision": decision_keyword,
                "reason": reminder_text,
            }))
            return 0

    hook_output(backend)
    return 0


if __name__ == "__main__":
    sys.exit(main())
