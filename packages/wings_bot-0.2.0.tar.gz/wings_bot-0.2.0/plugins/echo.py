"""echo 插件 — 基础消息回显和命令示例。

展示：
- @bot.on_message() 消息处理
- @bot.use() 中间件
- @cmds.command() 命令路由
"""

from __future__ import annotations

import time
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from wings_bot.context import MessageContext


def register(bot, cmds=None):
    # ------------------------------------------------------------------
    # 中间件：日志
    # ------------------------------------------------------------------

    @bot.use()
    async def logging_mw(ctx: MessageContext, next):
        start = time.time()
        print(f"→ [{ctx.chat_type}] {ctx.sender_name or ctx.sender_id}: {ctx.text}")
        await next()
        elapsed = time.time() - start
        print(f"← 处理完成 ({elapsed:.3f}s)")

    # ------------------------------------------------------------------
    # 消息处理器
    # ------------------------------------------------------------------

    @bot.on_message(message_type="text")
    async def echo_text(ctx: MessageContext):
        await ctx.reply(f"🔊 {ctx.text}")

    @bot.on_message(chat_type="group", mentioned=True, priority=20)
    async def group_mention(ctx: MessageContext):
        await ctx.reply(f"你好！你 @ 了我，你说的是：{ctx.text}")

    # ------------------------------------------------------------------
    # 命令（需要 CommandsExtension）
    # ------------------------------------------------------------------

    if cmds is not None:
        @cmds.command("ping", description="测试机器人是否在线")
        async def ping(ctx: MessageContext, args: list[str]):
            await ctx.reply("🏓 Pong!")

        @cmds.command("help", description="显示可用命令列表")
        async def help_cmd(ctx: MessageContext, args: list[str]):
            await ctx.reply(cmds.generate_help())
