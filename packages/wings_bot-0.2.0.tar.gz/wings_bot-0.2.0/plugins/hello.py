"""hello 插件 — 展示正则路由和定时任务。

展示：
- @cmds.match() 正则路由
- @bot.scheduler.cron() 定时任务
- ctx.send() 向指定聊天发消息
- markdown 消息发送
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import re
    from wings_bot.context import MessageContext


def register(bot, cmds=None):
    # ------------------------------------------------------------------
    # 正则路由
    # ------------------------------------------------------------------

    if cmds is not None:
        @cmds.match(r"^(hi|hey|hello|你好)\b")
        async def casual_greet(ctx: MessageContext, match: re.Match):
            greeting = match.group(1)
            await ctx.reply(f"{greeting}！有什么可以帮你的吗？")

        @cmds.match(r"^(时间|几点|what time)\b")
        async def show_time(ctx: MessageContext, match: re.Match):
            from datetime import datetime
            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            await ctx.reply(f"现在是 {now}")

    # ------------------------------------------------------------------
    # 定时任务
    # ------------------------------------------------------------------

    @bot.scheduler.cron("*/5 * * * *")
    def heartbeat():
        print("[heartbeat] Bot is alive")

    # ------------------------------------------------------------------
    # 其他事件
    # ------------------------------------------------------------------

    @bot.on_event("botAdded")
    async def on_bot_added(event):
        print(f"[botAdded] 被添加到群聊: {getattr(event, 'chat_id', '?')}")
