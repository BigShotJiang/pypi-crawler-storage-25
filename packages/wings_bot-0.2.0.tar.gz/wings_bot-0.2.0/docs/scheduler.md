# 定时任务

`Scheduler` 提供基于 Cron 表达式的定时任务，运行在后台守护线程中。

## 基本用法

```python
@bot.scheduler.cron("0 9 * * *")  # 每天 9:00
async def morning_report():
    await bot.channel.send_text("oc_xxxx", "早上好！今日待办：...")

@bot.scheduler.cron("*/30 * * * *")  # 每 30 分钟
async def heartbeat():
    print(f"心跳: {datetime.now()}")
```

## Cron 表达式

标准 5 字段格式：

```
分钟 小时 日 月 星期
```

| 字段 | 范围 | 示例 |
|------|------|------|
| 分钟 | 0-59 | `*/5` 每 5 分钟 |
| 小时 | 0-23 | `9,18` 9 点和 18 点 |
| 日 | 1-31 | `1` 每月 1 日 |
| 月 | 1-12 | `1` 一月 |
| 星期 | 0-6 (0=周日) | `1` 周一 |

## 协程与同步函数

```python
# 协程任务：通过 channel.schedule() 在事件循环中执行
@bot.scheduler.cron("* * * * *")
async def async_task():
    await bot.channel.send_text("oc_xxxx", "每分钟提醒")

# 同步函数：直接在后台线程执行（不能调用 channel API）
@bot.scheduler.cron("0 0 * * *")
def sync_task():
    with open("log.txt", "a") as f:
        f.write(f"Daily report at {datetime.now()}\n")
```

## 生命周期

- `bot.run()` 自动启动调度器
- `bot.stop()` 自动停止调度器
- 调度器使用守护线程，主进程退出时自动结束

## 访问底层 Channel

```python
@bot.scheduler.cron("0 * * * *")
async def hourly_check():
    if bot.channel.state.is_connected:
        await bot.channel.send_text(GROUP_ID, "整点报时")
```

## 注意事项

- 调度器按分钟粒度检查，秒级精度通过 `croniter` 的 `get_prev()` 判断
- 协程任务的执行时机受事件循环负载影响，不保证严格的实时性
- 长时间运行的同步任务会阻塞调度线程，建议用协程或提交到线程池
