# 安装与配置

## 1. 安装依赖

推荐使用 `uv` 管理环境：

```bash
git clone <repo-url> && cd wings-bot
uv sync
```

依赖项：
- `lark-oapi>=1.6.5` — 飞书开放平台 SDK（含长连接支持）
- `python-dotenv>=1.2.2` — 环境变量加载
- `croniter>=6.2.2` — Cron 表达式解析

## 2. 创建飞书应用

1. 前往 [飞书开放平台](https://open.feishu.cn) 创建企业自建应用
2. 在「能力配置」中开启**机器人**功能
3. 在「事件订阅」中添加事件 `im.message.receive_v1`
4. 事件对接方式选择 **长连接**（WebSocket）

## 3. 配置环境变量

在项目根目录创建 `.env` 文件：

```
APPID=cli_xxxxxxxxxxxxx
APPSEC=xxxxxxxxxxxxxxxxxxxxxxxx
```

`APPID` 和 `APPSEC` 可在飞书开放平台「凭证与基础信息」页面获取。

## 4. 运行

```bash
uv run python main.py
```

启动后 Bot 会通过 WebSocket 长连接与飞书服务器建立持久连接，实时接收消息。

## 5. 作为库安装

```bash
pip install wings_bot-0.1.0-py3-none-any.whl
```
