# 插件系统

## 插件约定

每个插件是 `plugins/` 目录下的一个 `.py` 文件，必须导出 `register(bot, **kwargs)` 函数。

```python
# plugins/my_plugin.py

def register(bot, **kwargs):
    cmds = kwargs.get("cmds")  # 传入的额外参数

    @bot.on_message(message_type="text")
    async def my_handler(ctx):
        await ctx.reply(f"你好, {ctx.sender_name}")

    @cmds.command("info")
    async def cmd_info(ctx, args):
        await ctx.reply(f"Info: {args}")
```

## 自动发现

框架按**字母序**扫描 `plugins/` 目录，跳过：
- 以下划线 `_` 开头的文件
- 非 `.py` 文件
- 在 `disabled` 集合中的文件

```python
# main.py
from wings_bot import load_plugins

load_plugins(bot, cmds=cmds)  # cmds 会传给每个插件的 register()
```

## 禁用特定插件

```python
load_plugins(bot, cmds=cmds, disabled={"echo", "secrets"})
```

## 传递参数

`load_plugins` 的 `**kwargs` 会原样传给每个插件的 `register()`：

```python
# 传入数据库连接、配置等
db = await create_db_pool()
load_plugins(bot, cmds=cmds, db=db, config=app_config)

# 插件中获取
def register(bot, db, config, **kwargs):
    async def handler(ctx):
        user = await db.fetch_user(ctx.sender_id)
        ...
```

## 插件加载结果

```python
loaded = load_plugins(bot, cmds=cmds)
print(f"Loaded plugins: {loaded}")
# -> Loaded plugins: ['echo', 'hello', 'my_plugin']
```

## 内置示例插件

### echo.py

展示：
- 请求日志中间件（含耗时统计）
- 文本消息回显
- 群聊 @提及 高优先级处理
- `/ping` 和 `/help` 命令

### hello.py

展示：
- 正则匹配：`/你好` 和 `/现在几点`
- Cron 定时任务：每 5 分钟心跳
- `botAdded` 事件处理
