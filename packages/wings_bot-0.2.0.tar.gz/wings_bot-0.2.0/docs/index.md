# FeishuBot 文档

FeishuBot 是一个基于 `lark-oapi` SDK 的装饰器风格飞书 Bot 开发框架，提供 Koa.js 洋葱模型中间件、插件系统、命令路由、正则匹配、卡片构建、定时任务等特性。

## 快速开始

```python
# main.py
import os
from dotenv import load_dotenv
from wings_bot import FeishuBot
from wings_bot.ext.commands import CommandsExtension

load_dotenv()

bot = FeishuBot(os.getenv("APPID"), os.getenv("APPSEC"))
cmds = CommandsExtension(prefix="/")
bot.install(cmds)

@bot.on_message()
async def hello(ctx):
    await ctx.reply("Hello, 飞书!")

bot.run()
```

```bash
uv run python main.py
```

## 环境要求

- Python >= 3.11
- 飞书应用（开启机器人能力 + 事件订阅 + 长连接方式）

## 目录

- [安装与配置](installation.md)
- [核心概念](core-concepts.md) — Bot、处理器、中间件、上下文
- [插件系统](plugins.md)
- [卡片构建](cards.md)
- [命令路由](commands.md)
- [定时任务](scheduler.md)
- [API 参考](api-reference.md)
