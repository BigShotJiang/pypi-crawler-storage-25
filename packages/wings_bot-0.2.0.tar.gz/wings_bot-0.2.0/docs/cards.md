# 卡片构建

`Card` 类提供流式 API 构建飞书交互卡片 JSON（v1 格式）。

## 基本用法

```python
from wings_bot import Card

card = (
    Card()
    .config(wide_screen=False, enable_forward=True)
    .header("系统通知", template="blue")
    .add_text("您有一条新消息")
    .add_hr()
    .add_markdown("**重要提醒**：请及时处理")
    .add_button("查看详情", variant="primary", url="https://example.com")
    .add_button("忽略", variant="default", value="ignore")
    .add_button("删除", variant="danger", value="delete")
)

await ctx.reply(card)
```

## 方法链

所有方法返回 `self`，支持链式调用：

| 方法 | 说明 |
|------|------|
| `config(wide_screen, enable_forward)` | 卡片级配置 |
| `header(title, subtitle, template)` | 标题栏，template 可选：`blue`, `green`, `orange`, `red`, `violet` 等 |
| `add_text(text)` | 纯文本块 |
| `add_markdown(content)` | Markdown 块 |
| `add_hr()` | 分隔线 |
| `add_img(img_key, alt)` | 图片（需先上传获取 img_key） |
| `add_column_set(columns)` | 多列布局 |
| `add_button(text, variant, url, value, on_click)` | 按钮 |
| `build()` | 构建并返回卡片 JSON dict |

## 按钮

### 按钮变体

- `primary` — 蓝色主按钮
- `default` — 白色默认按钮（默认值）
- `danger` — 红色危险按钮

### 自动分组

连续调用 `add_button()` 的按钮会自动合并在同一个操作行中。插入其他元素（如 `add_hr()`）会打断分组：

```python
# 三个按钮在同一行
card.add_button("确定").add_button("取消").add_button("详情")

# 换行后不同行
card.add_button("确定").add_hr().add_button("取消")
```

### 点击回调

```python
card.add_button("点击我", value="btn_click", on_click=my_callback)

async def my_callback(ctx):
    # ctx 是新的 MessageContext，ctx.event 包含卡片事件信息
    await ctx.reply("按钮被点击了")
```

框架自动绑定回调：为每个 `on_click` 分配内部名称（`__w1`, `__w2`, ...），发送卡片后自动注册回调到消息 ID。

### 打开链接

```python
card.add_button("访问官网", url="https://example.com")
```

使用 `url` 参数时按钮变成超链接，不占用回调槽位。

## 更新卡片

在 `on_click` 回调中更新卡片：

```python
def register(bot, **kwargs):
    @bot.on_message(message_type="text")
    async def show_counter(ctx):
        counter = [0]
        card = (
            Card()
            .header("计数器", template="green")
            .add_text(f"当前计数: {counter[0]}")
            .add_button("+1", value="inc", on_click=inc_counter)
        )
        await ctx.reply(card)

    async def inc_counter(ctx):
        # 更新卡片（非线程安全，仅示例）
        updated = (
            Card()
            .header("计数器", template="green")
            .add_text(f"当前计数: {counter[0]}")  # 实际应持久化
            .add_button("+1", value="inc", on_click=inc_counter)
        )
        await ctx.update_card(updated)
```

## 原始卡片

也可以直接使用飞书卡片 JSON：

```python
raw_card = {
    "config": {"wide_screen_mode": False},
    "header": {"title": {"tag": "plain_text", "content": "标题"}},
    "elements": [{"tag": "div", "text": {"tag": "plain_text", "content": "内容"}}],
}
await ctx.reply(raw_card)
```

传入 dict 时不会自动提取回调，需自行管理。
