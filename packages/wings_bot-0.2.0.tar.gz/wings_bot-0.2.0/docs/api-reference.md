# API 参考

## FeishuBot

```python
class FeishuBot(app_id, app_secret, error_message="处理消息时发生错误", **channel_kwargs)
```

### 属性

| 属性 | 类型 | 说明 |
|------|------|------|
| `bot.channel` | `FeishuChannel` | 底层飞书 SDK Channel |
| `bot.scheduler` | `Scheduler` | 定时任务调度器 |

### 方法

| 方法 | 说明 |
|------|------|
| `bot.on_message(chat_type, message_type, mentioned, priority)` | 注册消息处理器（支持有/无括号） |
| `bot.on_event(event_name)` | 注册事件处理器 |
| `bot.use` | 注册洋葱模型中间件（支持有/无括号） |
| `bot.install(extension)` | 安装扩展 |
| `bot.run()` | 启动 Bot（阻塞） |
| `bot.stop()` | 停止 Bot |

## MessageContext

详见 [核心概念](core-concepts.md#messagecontext)。

### 消息操作

| 方法 | 说明 |
|------|------|
| `await ctx.reply(*parts, reply_to=None, **kwargs)` | 回复当前会话，自动类型分发 |
| `await ctx.quote(*parts, reply_to=None, **kwargs)` | 引用回复，默认带上行消息 ID |
| `await ctx.update_card(card)` | 更新已有卡片 |
| `await ctx.send(chat_id, *parts, reply_to=None, **kwargs)` | 发送到指定会话 |

### reply / send 接受的 parts 类型

| 输入 | 效果 |
|------|------|
| `str` | 文本消息（text） |
| `Markdown("**bold**")` | SDK 自动转 post 富文本 |
| `Card()` | 交互卡片（interactive） |
| `Image(source)` | 图片（自动上传本地/URL/bytes） |
| `File(source)` | 文件（自动上传） |
| `Audio(source)` | 音频 |
| `Video(source)` | 视频 |
| `Sticker(file_key)` | 表情贴纸 |
| `ShareChat(chat_id)` | 群聊名片 |
| `ShareUser(user_id)` | 用户名片 |
| `dict` | 直接透传 SDK |
| 多参数组合 | 自动构建 text（含 At 内联）或 post 富文本 |

### 资源操作

| 方法 | 说明 |
|------|------|
| `await ctx.upload(source, kind="image")` | 上传资源，返回 file_key |
| `await ctx.recall(message_id)` | 撤回消息 |
| `await ctx.add_reaction(message_id, emoji_type)` | 添加表情回应 |
| `await ctx.download(file_key, resource_type="image")` | 下载资源为 bytes |

## Card

```python
class Card()
```

### 方法链

| 方法 | 参数 | 说明 |
|------|------|------|
| `.config(wide_screen, enable_forward)` | `wide_screen=False`, `enable_forward=True` | 卡片配置 |
| `.header(title, subtitle, template)` | `title` 必填 | 标题栏 |
| `.add_text(text)` | `text: str` | 纯文本 |
| `.add_markdown(content)` | `content: str` | Markdown |
| `.add_hr()` | - | 分隔线 |
| `.add_img(img_key, alt)` | `img_key: str`, `alt=None` | 图片 |
| `.add_column_set(columns)` | `columns: list` | 多列布局 |
| `.add_button(text, variant, url, value, on_click)` | 见下方 | 按钮 |
| `.build()` | - | 构建 JSON dict |

### add_button 参数

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `text` | `str` | 必填 | 按钮文字 |
| `variant` | `str` | `"default"` | `"primary"`, `"default"`, `"danger"` |
| `url` | `str\|None` | `None` | 点击打开链接 |
| `value` | `str\|None` | `None` | 回调携带的值 |
| `on_click` | `Callable\|None` | `None` | 点击回调协程 |

## Scheduler

```python
class Scheduler(channel=None)
```

### 方法

| 方法 | 说明 |
|------|------|
| `@scheduler.cron(expression)` | 注册 Cron 任务 |
| `scheduler.start()` | 启动调度器 |
| `scheduler.stop()` | 停止调度器 |

## CommandsExtension

```python
class CommandsExtension(prefix="/")
```

### 方法

| 方法 | 说明 |
|------|------|
| `@cmds.command(name, aliases, description)` | 注册命令 |
| `@cmds.match(pattern)` | 注册正则匹配 |
| `cmds.resolve(text)` | 解析命令文本，返回 `(CommandEntry, args)` 或 `(None, [])` |
| `cmds.get_all_commands()` | 返回所有命令列表 |
| `cmds.generate_help()` | 生成格式化帮助文本 |

### _install(bot)

扩展安装方法，自动注册消息处理器（priority=100），实现命令→正则→透传的降级路由。

## MiddlewareChain

```python
class MiddlewareChain(middlewares: list, handler: Callable)
```

### 方法

| 方法 | 说明 |
|------|------|
| `await chain.execute(ctx)` | 执行中间件链 |

### 中间件签名

```python
@bot.use
async def my_middleware(ctx, next):
    # pre-processing
    await next()
    # post-processing
```

- 不调用 `await next()` 会中断链
- 多次调用 `await next()` 会引发 `RuntimeError`

## load_plugins

```python
def load_plugins(bot, plugins_dir="plugins", disabled: set = None, **kwargs) -> list[str]
```

| 参数 | 说明 |
|------|------|
| `bot` | FeishuBot 实例 |
| `plugins_dir` | 插件目录路径，默认 `"plugins"` |
| `disabled` | 要跳过的文件名集合 |
| `**kwargs` | 传给每个插件 `register()` 的额外参数 |

返回成功加载的插件名称列表。
