# 核心概念

## 架构概览

```
用户消息 → 飞书服务器 Push → WebSocket 长连接
  → FeishuChannel（消息解析、去重、策略检查）
  → FeishuBot._on_message()
  → 构建 MessageContext
  → 全局中间件链（洋葱模型）
  → 匹配的处理器链（优先级排序）
    ├── CommandsExtension（priority=100）
    ├── 自定义处理器
    └── ctx.reply() / ctx.send()
```

## FeishuBot

核心类，也是 Bot 实例。

```python
from wings_bot import FeishuBot

bot = FeishuBot(
    app_id="cli_xxxxxxxxxxxxx",
    app_secret="xxxxxxxxxxxxxxxxxxxxxxxx",
    error_message="处理消息时发生错误",  # 默认错误回复
)
```

### 策略配置

```python
from lark_oapi.websocket import PolicyConfig

bot.channel.policy = PolicyConfig(
    require_mention=False,   # 群聊中是否要求 @机器人
    dedup_timeout=60,        # 消息去重窗口（秒）
    dedup_algorithm="msg",   # 去重算法
)
```

## MessageContext

每个消息被包装为 `MessageContext` 对象，传给所有处理器和中间件。

### 只读属性

| 属性 | 类型 | 说明 |
|------|------|------|
| `ctx.text` | `str` | 消息纯文本（已规范化） |
| `ctx.sender_id` | `str` | 发送者 open_id |
| `ctx.sender_union_id` | `str` | 发送者 union_id |
| `ctx.sender_name` | `str` | 发送者显示名 |
| `ctx.chat_id` | `str` | 会话 ID |
| `ctx.chat_type` | `str` | `"p2p"`（私聊）或 `"group"`（群聊） |
| `ctx.message_type` | `str` | 消息类型（见下方） |
| `ctx.message_id` | `str` | 消息 ID |
| `ctx.mentions` | `list` | @提及列表 |
| `ctx.is_mentioned` | `bool` | 是否 @了机器人 |
| `ctx.reply_to_id` | `str\|None` | 被回复的消息 ID |
| `ctx.parent_message` | `Any\|None` | 被回复的消息对象 |
| `ctx.content` | `Any` | 结构化消息内容（`.kind` 区分类型） |
| `ctx.raw` | `InboundMessage` | 原始 SDK 消息对象 |
| `ctx.channel` | `FeishuChannel` | 底层 Channel（高级操作） |
| `ctx.event` | `CardActionEvent\|None` | 卡片交互事件 |

### 消息类型（`message_type` / `content.kind`）

`text`, `post`, `image`, `file`, `audio`, `media`, `sticker`, `interactive`, `share_chat`, `share_user`, `system`, `location`, `folder`, `hongbao`, `general_calendar`, `share_calendar_event`, `video_chat`, `calendar`, `vote`, `todo`, `merge_forward`, `unknown`

### 状态共享

```python
ctx.state["user_data"] = {"name": "Alice"}
```

`ctx.state` 是可变字典，中间件可以通过它在链中传递数据。

### 消息操作

```python
# 回复当前会话
await ctx.reply("你好")
await ctx.reply(Markdown("**Markdown** 内容"))
await ctx.reply("你好 ", At("ou_abc"), " 请查收")     # @+文本
await ctx.reply(Image("/path/photo.png"))            # 图片，SDK 自动上传
await ctx.reply(File("file_key", file_name="报告.pdf"))
await ctx.reply({"text": "raw dict"})                # 直接传 API dict

# 回复卡片
card = Card().header("标题").add_text("内容").add_button("确定")
await ctx.reply(card)

# 引用回复（自动带上行消息 ID）
await ctx.quote("收到")                               # 自动引用
await ctx.quote("补充", reply_to="om_xxxx")           # 指定引用

# 发送到指定会话
await ctx.send("ou_xxxx", "私信内容")

# 更新卡片（仅卡片回调中有效）
await ctx.update_card(modified_card)
```

## 消息处理器

通过 `@bot.on_message()` 装饰器注册，支持条件过滤：

```python
# 处理所有私聊消息
@bot.on_message(chat_type="p2p")
async def on_p2p(ctx):
    await ctx.reply(f"你好 {ctx.sender_name}")

# 仅处理群聊中 @机器人 的文本消息
@bot.on_message(chat_type="group", message_type="text", mentioned=True, priority=10)
async def on_group_mention(ctx):
    await ctx.reply("收到 @")

# priority 决定执行顺序，数字越大越优先。默认 0
@bot.on_message(priority=50)
async def high_priority(ctx):
    pass
```

### 可链式调用的处理器

处理器接受 `(ctx, next)` 时可以调用 `await next()` 将控制权交给下一个处理器：

```python
@bot.on_message()
async def guard(ctx, next):
    if ctx.sender_id not in ALLOWED_USERS:
        await ctx.reply("没有权限")
        return  # 不调用 next，中断链
    await next()  # 传给下一个处理器
```

仅接受 `(ctx)` 的处理器会自动终止中间件链。

## 洋葱模型中间件

```python
@bot.use
async def logger(ctx, next):
    start = time.time()
    await next()
    elapsed = time.time() - start
    print(f"[{elapsed:.2f}s] {ctx.text}")

@bot.use
async def auth(ctx, next):
    if not is_authorized(ctx.sender_id):
        await ctx.reply("未授权")
        return
    await next()
```

执行顺序（从外到内）：
```
logger pre → auth pre → handler → auth post → logger post
```

`@bot.use` 支持有/无括号两种写法。

## 事件处理器

处理非消息事件：

```python
@bot.on_event("botAdded")
async def on_bot_added(ctx):
    await ctx.send(ctx.chat_id, "大家好，我是机器人")

@bot.on_event("botLeave")
async def on_bot_leave(ctx):
    print(f"从 {ctx.chat_id} 离开")

@bot.on_event("cardAction")
async def on_card_action(ctx):
    print("卡片被点击")

@bot.on_event("reaction")
async def on_reaction(ctx):
    print("收到表情回应")

@bot.on_event("error")
async def on_error(ctx):
    print(f"处理错误: {ctx.state.get('error')}")

# 原始事件
@bot.on_event("raw")
async def on_raw(ctx):
    print(ctx.raw)
```

支持的事件：`botAdded`, `botLeave`, `reaction`, `messageRead`, `cardAction`, `comment`, `raw`, `error`, `reconnecting`, `reconnected`

## 错误处理

- 处理器抛出异常时，Bot 自动向用户回复 `error_message`（默认 "处理消息时发生错误"）
- 异常通过 `@bot.on_event("error")` 转发，可在 `ctx.state["error"]` 获取
- Bot 不会因异常而崩溃

## 扩展系统

第三方功能可以通过 Extension 协议接入：

```python
class MyExtension:
    def _install(self, bot):
        @bot.on_message()
        async def my_handler(ctx):
            pass

bot.install(MyExtension())
```

`CommandsExtension` 就是使用此模式实现的。
