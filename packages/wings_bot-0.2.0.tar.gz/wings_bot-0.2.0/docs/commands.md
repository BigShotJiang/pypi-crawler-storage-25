# 命令路由

`CommandsExtension` 提供前缀命令解析和正则匹配路由。

## 安装

```python
from wings_bot.ext.commands import CommandsExtension

cmds = CommandsExtension(prefix="/")  # 默认 "/"
bot.install(cmds)
load_plugins(bot, cmds=cmds)
```

扩展注册一个高优先级（100）的消息处理器，在普通处理器之前拦截消息：
1. 首先尝试命令匹配（以 `prefix` 开头）
2. 匹配不到则尝试正则匹配
3. 都不匹配则 `await next()`，交给其他处理器

## 命令处理器

```python
@cmds.command("ping")
async def cmd_ping(ctx, args):
    """Ping 命令 - 返回 pong"""
    await ctx.reply("pong!")

@cmds.command("echo", aliases=["say", "repeat"], description="复读消息")
async def cmd_echo(ctx, args):
    await ctx.reply(" ".join(args) or "什么都复读")
```

- 用户发送 `/ping` → `args=[]`
- 用户发送 `/echo hello world` → `args=["hello", "world"]`
- 用户发送 `/say test`（别名） → `args=["test"]`

## 正则匹配

```python
@cmds.match(r"^(你好|hello|hi)\b")
async def greet(ctx, match):
    await ctx.reply(f"你好！{ctx.sender_name}")

@cmds.match(r"(现在几点|当前时间)")
async def tell_time(ctx, match):
    from datetime import datetime
    await ctx.reply(f"现在是 {datetime.now():%H:%M:%S}")
```

- 处理器接收正则 `re.Match` 对象
- 按注册顺序匹配，**第一个匹配的生效**

## 帮助系统

```python
# 查看所有命令
@cmds.command("help")
async def cmd_help(ctx, args):
    await ctx.reply(cmds.generate_help())
```

`generate_help()` 输出格式：
```
可用命令：
/ping    - 测试连接
/echo    - 复读消息 (别名: say, repeat)
/help    - 显示帮助
```

## 遍历命令

```python
for cmd in cmds.get_all_commands():
    print(f"{cmd.name}: {cmd.description}")
    if cmd.aliases:
        print(f"  别名: {', '.join(cmd.aliases)}")
```
