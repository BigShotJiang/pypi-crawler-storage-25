"""飞书 Bot 入口。

使用插件自动加载：plugins/ 目录下所有 .py 文件会被自动发现并注册。
"""

import logging
import os

from dotenv import load_dotenv
from lark_oapi.channel.config import PolicyConfig

from wings_bot import FeishuBot, load_plugins
from wings_bot.ext.commands import CommandsExtension

# ------------------------------------------------------------------
# 初始化
# ------------------------------------------------------------------

load_dotenv()
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
)

bot = FeishuBot(
    app_id=os.environ["APPID"],
    app_secret=os.environ["APPSEC"],
    policy=PolicyConfig(require_mention=False),
)

# 可选：安装命令扩展
cmds = CommandsExtension(prefix="/")
bot.install(cmds)

# ------------------------------------------------------------------
# 自动加载插件
# ------------------------------------------------------------------

load_plugins(bot, cmds=cmds)

# ------------------------------------------------------------------
# 启动
# ------------------------------------------------------------------

if __name__ == "__main__":
    bot.run()
