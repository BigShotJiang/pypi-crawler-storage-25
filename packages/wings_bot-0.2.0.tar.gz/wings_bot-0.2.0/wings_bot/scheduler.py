"""bot.scheduler — 定时任务调度。

基于 croniter 解析 cron 表达式，在后台线程中按时触发任务。
利用 FeishuChannel.schedule() 在事件循环中执行协程。

用法::

    from wings_bot.scheduler import Scheduler

    scheduler = Scheduler(channel)

    @scheduler.cron("*/5 * * * *")
    async def heartbeat():
        await channel.send(chat_id, {"text": "ping"})

    scheduler.start()
"""

from __future__ import annotations

import asyncio
import logging
import threading
import time
from typing import Any, Callable, Optional, Sequence

import croniter

logger = logging.getLogger("feishu_bot.scheduler")


class Scheduler:
    """基于 cron 表达式的定时任务调度器。

    在后台守护线程中每分钟检查一次是否有任务需要触发。
    协程任务通过 FeishuChannel.schedule() 提交到事件循环。
    """

    def __init__(self, channel: Any = None) -> None:
        self._channel = channel
        self._jobs: list[tuple[str, Callable]] = []
        self._thread: Optional[threading.Thread] = None
        self._running = False

    def cron(self, expression: str) -> Callable:
        """注册定时任务。

        处理器可以是同步或异步函数。异步函数通过 channel.schedule() 执行。

        Args:
            expression: 5 字段 cron 表达式，如 ``"*/5 * * * *"``。
        """

        def decorator(f: Callable) -> Callable:
            self._jobs.append((expression, f))
            return f

        return decorator

    def start(self) -> None:
        """启动调度器后台线程。"""
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(
            target=self._loop, name="feishu-scheduler", daemon=True
        )
        self._thread.start()
        job_count = len(self._jobs)
        if job_count:
            logger.info("调度器已启动 — %d 个定时任务", job_count)

    def stop(self) -> None:
        """停止调度器。"""
        self._running = False

    def _loop(self) -> None:
        # 对齐到下一个整分钟
        now = time.time()
        sleep_until = (int(now) // 60 + 1) * 60
        time.sleep(max(0, sleep_until - now))

        while self._running:
            now = time.time()
            self._tick(now)

            # 睡到下一个整分钟
            next_minute = (int(now) // 60 + 1) * 60
            while self._running:
                wait = next_minute - time.time()
                if wait <= 0:
                    break
                time.sleep(min(wait, 1.0))

    def _tick(self, now: float) -> None:
        for expr, fn in self._jobs:
            try:
                cron = croniter.croniter(expr, now)
                prev = cron.get_prev()
                # 如果上一个触发时间在 1 秒内，说明现在就是触发时刻
                if abs(now - prev) < 1.0:
                    self._run_job(fn)
            except Exception:
                logger.exception("cron 任务检查失败: %s", expr)

    def _run_job(self, fn: Callable) -> None:
        if asyncio.iscoroutinefunction(fn):
            if self._channel is not None:
                self._channel.schedule(fn())
            else:
                logger.warning("异步 cron 任务 %s 没有 channel，无法调度", fn.__qualname__)
        else:
            try:
                fn()
            except Exception:
                logger.exception("同步 cron 任务 %s 执行失败", fn.__qualname__)
