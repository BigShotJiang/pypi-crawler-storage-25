"""bot.middleware — 洋葱模型中间件链。

中间件签名::

    async def my_middleware(ctx: MessageContext, next: Callable):
        # 前置逻辑
        await next()
        # 后置逻辑

不调用 ``next()`` 即可中断链（如鉴权失败）。
"""

from __future__ import annotations

import inspect
from typing import Any, Callable, Sequence

# Middleware 签名: async (ctx, next) -> None
Middleware = Callable[..., Any]


class MiddlewareChain:
    """将中间件列表 + 最终 handler 组装成洋葱调用链并执行。

    执行顺序::

        mw_0 → mw_1 → ... → mw_n → handler
             ← mw_1 ← ... ← mw_n ←

    任何中间件不调用 ``await next()`` 即可短路后续流程。
    """

    __slots__ = ("_middlewares", "_handler")

    def __init__(
        self,
        middlewares: Sequence[Middleware],
        handler: Callable,
    ) -> None:
        self._middlewares = list(middlewares)
        self._handler = handler

    async def execute(self, ctx: Any) -> None:
        """构建嵌套 next 闭包并从第一个中间件开始执行。"""

        async def _call_handler():
            result = self._handler(ctx)
            if inspect.isawaitable(result):
                await result

        # 从最内层（handler）向外层逐步包裹
        next_fn = _call_handler
        for mw in reversed(self._middlewares):
            next_fn = _make_next(mw, ctx, next_fn)

        await next_fn()


def _make_next(
    mw: Middleware,
    ctx: Any,
    downstream: Callable,
) -> Callable:
    """为单个中间件创建 next 闭包，避免循环变量捕获问题。"""

    called = False

    async def next_fn():
        nonlocal called
        if called:
            raise RuntimeError(
                f"中间件 {mw.__qualname__} 多次调用了 next()，"
                "每个中间件只能调用一次 next()"
            )
        called = True
        await downstream()

    async def invoke():
        result = mw(ctx, next_fn)
        if inspect.isawaitable(result):
            await result

    return invoke
