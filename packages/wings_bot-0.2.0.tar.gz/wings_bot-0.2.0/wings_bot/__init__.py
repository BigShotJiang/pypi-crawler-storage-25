"""bot — 飞书 Bot 开发框架。

基于 ``lark_oapi.channel.FeishuChannel`` 构建的装饰器风格框架。

快速开始::

    from wings_bot import FeishuBot

    bot = FeishuBot(app_id="...", app_secret="...")

    @bot.on_message()
    async def handle(ctx):
        await ctx.reply(f"收到: {ctx.text}")

    bot.run()
"""

from .app import FeishuBot
from .card import Card
from .context import MessageContext
from .middleware import MiddlewareChain
from .msg import At, Audio, File, Image, Markdown, ShareChat, ShareUser, Sticker, Video
from .plugin import load_plugins
from .scheduler import Scheduler

__all__ = [
    "FeishuBot", "Card", "MessageContext", "MiddlewareChain", "Scheduler",
    "load_plugins",
    "At", "Audio", "File", "Image", "Markdown", "ShareChat", "ShareUser", "Sticker", "Video",
]
