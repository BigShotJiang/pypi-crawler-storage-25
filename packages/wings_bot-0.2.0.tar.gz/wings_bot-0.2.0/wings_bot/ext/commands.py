"""bot.ext.commands — 命令路由 + 正则匹配扩展（可选语法糖）。

通过 ``bot.install()`` 安装后，自动拦截以指定前缀开头的文本消息，
解析为命令并分发给对应的处理器。还支持正则表达式匹配。

用法::

    from wings_bot import FeishuBot
    from wings_bot.ext.commands import CommandsExtension

    bot = FeishuBot(app_id="...", app_secret="...")

    cmds = CommandsExtension(prefix="/")
    bot.install(cmds)

    @cmds.command("echo", description="回复你发送的内容")
    async def echo(ctx, args):
        await ctx.reply(" ".join(args))

    @cmds.match(r"^(hi|hey|hello)\\b")
    async def greet(ctx, match):
        await ctx.reply(f"你好！")

    bot.run()
"""

from __future__ import annotations

import inspect
import logging
import re
import shlex
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from wings_bot.app import FeishuBot
    from wings_bot.context import MessageContext

logger = logging.getLogger("feishu_bot.commands")


@dataclass
class CommandEntry:
    """一个已注册的命令。"""

    name: str
    handler: Callable
    aliases: List[str] = field(default_factory=list)
    description: str = ""


@dataclass
class RegexEntry:
    """一个已注册的正则匹配处理器。"""

    pattern: re.Pattern
    handler: Callable


class CommandsExtension:
    """命令路由 + 正则匹配扩展。

    这是一个**可选扩展**，不影响核心框架的消息处理流程。
    安装后，它会注册一个高优先级（priority=100）的消息处理器，
    拦截匹配前缀的文本消息并路由到对应的命令处理器，以及正则匹配。

    未匹配任何命令或正则的消息会**继续**流入普通的 ``@on_message`` 处理器。
    """

    def __init__(self, prefix: str = "/") -> None:
        self._prefix = prefix
        self._commands: Dict[str, CommandEntry] = {}
        self._alias_map: Dict[str, str] = {}  # alias -> canonical name
        self._regex_handlers: List[RegexEntry] = []
        self._bot: Optional[FeishuBot] = None

    @property
    def prefix(self) -> str:
        return self._prefix

    def command(
        self,
        name: str,
        *,
        aliases: Optional[List[str]] = None,
        description: str = "",
    ) -> Callable:
        """注册命令处理器。

        处理器签名::

            async def my_command(ctx: MessageContext, args: list[str]):
                ...

        其中 ``args`` 是命令后面的参数列表（按空格分割）。

        Args:
            name: 命令名（不含前缀）。
            aliases: 可选的别名列表。
            description: 命令描述（用于自动生成帮助信息）。
        """

        def decorator(f: Callable) -> Callable:
            entry = CommandEntry(
                name=name,
                handler=f,
                aliases=aliases or [],
                description=description,
            )
            self._commands[name] = entry
            for alias in entry.aliases:
                self._alias_map[alias] = name
            return f

        return decorator

    def match(self, pattern: str) -> Callable:
        """注册正则匹配处理器。

        处理器签名::

            async def my_handler(ctx: MessageContext, match: re.Match):
                ...

        当消息文本匹配正则时调用 handler。按注册顺序尝试，第一个匹配即执行。

        Args:
            pattern: 正则表达式字符串。
        """

        compiled = re.compile(pattern)

        def decorator(f: Callable) -> Callable:
            self._regex_handlers.append(RegexEntry(pattern=compiled, handler=f))
            return f

        return decorator

    def resolve(self, text: str) -> tuple[Optional[CommandEntry], list[str]]:
        """解析文本，返回 (命令, 参数列表) 或 (None, [])。

        使用 shlex 解析，支持引号包裹含空格的参数和转义。
        """
        text = text.strip()
        if not text.startswith(self._prefix):
            return None, []

        rest = text[len(self._prefix):]
        try:
            parts = shlex.split(rest)
        except ValueError:
            # 引号未闭合等语法错误，回退到简单 split
            parts = rest.split()

        if not parts:
            return None, []

        cmd_name = parts[0].lower()
        args = parts[1:]

        # 先查精确匹配，再查别名
        entry = self._commands.get(cmd_name)
        if entry is None:
            canonical = self._alias_map.get(cmd_name)
            if canonical is not None:
                entry = self._commands.get(canonical)

        return entry, args

    def get_all_commands(self) -> List[CommandEntry]:
        """返回所有已注册命令的列表。"""
        return list(self._commands.values())

    def generate_help(self) -> str:
        """生成格式化的帮助文本。"""
        if not self._commands:
            return "暂无可用命令。"

        lines = ["📋 可用命令：", ""]
        for cmd in self._commands.values():
            alias_str = ""
            if cmd.aliases:
                alias_str = f" (别名: {', '.join(self._prefix + a for a in cmd.aliases)})"
            desc = cmd.description or "无描述"
            lines.append(f"  {self._prefix}{cmd.name}{alias_str} — {desc}")

        return "\n".join(lines)

    # ------------------------------------------------------------------
    # 扩展安装接口
    # ------------------------------------------------------------------

    def _install(self, bot: FeishuBot) -> None:
        """被 bot.install() 调用。注册高优先级消息处理器。"""
        self._bot = bot

        @bot.on_message(message_type="text", priority=100)
        async def _command_dispatch(ctx, next):
            # 先尝试命令匹配
            entry, args = self.resolve(ctx.text)
            if entry is not None:
                result = entry.handler(ctx, args)
                if inspect.isawaitable(result):
                    await result
                return

            # 再尝试正则匹配
            for regex_entry in self._regex_handlers:
                m = regex_entry.pattern.search(ctx.text)
                if m is not None:
                    result = regex_entry.handler(ctx, m)
                    if inspect.isawaitable(result):
                        await result
                    return

            # 未匹配命令或正则 — 传递给下一个 handler
            await next()
