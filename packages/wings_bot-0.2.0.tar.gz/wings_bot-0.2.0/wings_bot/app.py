"""bot.app — FeishuBot 框架核心。

提供装饰器风格的事件处理器注册和 AOP 中间件链。

基本用法::

    from wings_bot import FeishuBot

    bot = FeishuBot(app_id="...", app_secret="...")

    @bot.on_message()
    async def handle(ctx):
        await ctx.reply(f"收到: {ctx.text}")

    bot.run()
"""

from __future__ import annotations

import asyncio
import inspect
import logging
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Protocol, runtime_checkable

from lark_oapi.channel import FeishuChannel, InboundMessage

from .context import MessageContext
from .middleware import Middleware, MiddlewareChain
from .scheduler import Scheduler

logger = logging.getLogger("feishu_bot")


# ------------------------------------------------------------------
# 处理器注册数据结构
# ------------------------------------------------------------------

@dataclass
class MessageHandlerEntry:
    """一个已注册的消息处理器及其过滤条件。"""

    handler: Callable
    chat_type: Optional[str] = None
    message_type: Optional[str] = None
    mentioned: Optional[bool] = None
    sender_id: Optional[str] = None
    chat_id: Optional[str] = None
    filter: Optional[Callable[[MessageContext], bool]] = None
    priority: int = 10
    name: str = ""

    def matches(self, ctx: MessageContext) -> bool:
        """检查该处理器的过滤条件是否匹配当前消息。"""
        if self.chat_type is not None and ctx.chat_type != self.chat_type:
            return False
        if self.message_type is not None and ctx.message_type != self.message_type:
            return False
        if self.mentioned is not None and ctx.is_mentioned != self.mentioned:
            return False
        if self.sender_id is not None and ctx.sender_id != self.sender_id:
            return False
        if self.chat_id is not None and ctx.chat_id != self.chat_id:
            return False
        if self.filter is not None and not self.filter(ctx):
            return False
        return True


@runtime_checkable
class Extension(Protocol):
    """扩展协议 — 任何实现 _install(bot) 方法的对象都可以作为扩展安装。"""

    def _install(self, bot: FeishuBot) -> None: ...


# ------------------------------------------------------------------
# FeishuBot 核心类
# ------------------------------------------------------------------

class FeishuBot:
    """飞书 Bot 开发框架。

    基于 ``FeishuChannel`` 构建，提供：

    - ``@on_message()`` — 装饰器注册消息处理器（支持过滤条件和优先级）
    - ``@on_event()`` — 装饰器注册任意事件处理器
    - ``@use()`` — 装饰器注册全局中间件（洋葱模型）
    - ``install()`` — 安装可选扩展（如命令路由）
    - ``channel`` — 暴露底层 FeishuChannel 供高级用户使用
    """

    def __init__(
        self,
        app_id: str,
        app_secret: str,
        *,
        error_message: str = "处理消息时发生错误",
        **channel_kwargs: Any,
    ) -> None:
        self._channel = FeishuChannel(
            app_id=app_id,
            app_secret=app_secret,
            **channel_kwargs,
        )
        self._message_handlers: List[MessageHandlerEntry] = []
        self._middlewares: List[Middleware] = []
        self._event_handlers: Dict[str, List[Callable]] = {}
        self._extensions: List[Any] = []
        self._wired = False
        self._scheduler = Scheduler(self._channel)
        self._error_message = error_message
        self._card_callbacks: Dict[str, Dict[str, Callable]] = {}

    # ------------------------------------------------------------------
    # 公开属性
    # ------------------------------------------------------------------

    @property
    def channel(self) -> FeishuChannel:
        """底层 FeishuChannel 实例。

        高级用户可以直接使用它调用 ``channel.send()``、
        ``channel.stream()`` 等 API。
        """
        return self._channel

    @property
    def scheduler(self) -> Scheduler:
        """定时任务调度器。"""
        return self._scheduler

    # ------------------------------------------------------------------
    # 装饰器 API
    # ------------------------------------------------------------------

    def on_message(
        self,
        func: Optional[Callable] = None,
        *,
        chat_type: Optional[str] = None,
        message_type: Optional[str] = None,
        mentioned: Optional[bool] = None,
        sender_id: Optional[str] = None,
        chat_id: Optional[str] = None,
        filter: Optional[Callable[[MessageContext], bool]] = None,
        priority: int = 10,
    ) -> Callable:
        """注册消息处理器。

        可以直接用作装饰器::

            @bot.on_message()
            async def handle(ctx): ...

        也可以带过滤条件::

            @bot.on_message(chat_type="p2p", message_type="text")
            async def dm_text(ctx): ...

        更细粒度的过滤::

            @bot.on_message(sender_id="ou_xxx")
            async def from_user(ctx): ...

            @bot.on_message(filter=lambda ctx: "urgent" in ctx.text)
            async def urgent_only(ctx): ...

        Args:
            chat_type: 仅匹配指定聊天类型（"p2p" / "group"）。
            message_type: 仅匹配指定消息类型（"text" / "image" 等）。
            mentioned: 仅匹配 Bot 是否被 @。True = 被@, False = 未被@。
            sender_id: 仅匹配指定发送者 open_id。
            chat_id: 仅匹配指定聊天 chat_id。
            filter: 自定义过滤函数，接收 MessageContext，返回 bool。
            priority: 优先级，数值越大越先执行。默认 10。
        """

        def decorator(f: Callable) -> Callable:
            entry = MessageHandlerEntry(
                handler=f,
                chat_type=chat_type,
                message_type=message_type,
                mentioned=mentioned,
                sender_id=sender_id,
                chat_id=chat_id,
                filter=filter,
                priority=priority,
                name=f.__qualname__,
            )
            self._message_handlers.append(entry)
            # 保持按 priority 降序排列
            self._message_handlers.sort(key=lambda e: e.priority, reverse=True)
            return f

        if func is not None:
            # @bot.on_message 不带括号的用法
            return decorator(func)
        return decorator

    def on_event(self, event_name: str) -> Callable:
        """注册 FeishuChannel 事件处理器。

        支持的事件名：``"botAdded"``, ``"botLeave"``, ``"reaction"``,
        ``"messageRead"``, ``"cardAction"``, ``"comment"``, ``"raw"`` 等。

        用法::

            @bot.on_event("botAdded")
            async def on_added(event):
                print("Bot 被添加到群")
        """

        def decorator(f: Callable) -> Callable:
            self._event_handlers.setdefault(event_name, []).append(f)
            return f

        return decorator

    def use(self, func: Optional[Callable] = None) -> Callable:
        """注册全局中间件（洋葱模型）。

        中间件按注册顺序执行，签名为::

            async def my_middleware(ctx: MessageContext, next: Callable):
                # 前置逻辑
                await next()
                # 后置逻辑

        不调用 ``next()`` 即可中断后续处理。

        用法::

            @bot.use()
            async def logging_mw(ctx, next):
                print(f"收到: {ctx.text}")
                await next()
        """

        def decorator(f: Callable) -> Callable:
            self._middlewares.append(f)
            return f

        if func is not None:
            return decorator(func)
        return decorator

    def install(self, extension: Any) -> None:
        """安装扩展。

        扩展需实现 ``_install(bot)`` 方法。安装时会立即调用该方法，
        让扩展有机会注册自己的处理器和中间件。

        用法::

            from wings_bot.ext.commands import CommandsExtension

            cmds = CommandsExtension(prefix="/")
            bot.install(cmds)

            @cmds.command("echo")
            async def echo(ctx, args): ...
        """
        if hasattr(extension, "_install") and callable(extension._install):
            extension._install(self)
            self._extensions.append(extension)
        else:
            raise TypeError(
                f"{type(extension).__name__} 不是有效的扩展 — "
                f"缺少 _install(bot) 方法"
            )

    # ------------------------------------------------------------------
    # 内部事件分发
    # ------------------------------------------------------------------

    async def _on_message(self, msg: InboundMessage) -> None:
        """FeishuChannel 的 message 事件回调 — 构建 ctx 并分发。

        所有匹配的 handler 按 priority 降序组成调用链，每个 handler
        可以通过 ``await next()`` 传递给下一个 handler（Koa 风格）。

        handler 签名决定行为：

        - ``async def h(ctx, next)`` — 接受 next，自行决定是否传递
        - ``async def h(ctx)`` — 不接受 next，执行后链自动终止
        """
        ctx = MessageContext(msg=msg, channel=self._channel, bot=self)

        matched = [e for e in self._message_handlers if e.matches(ctx)]
        if not matched:
            logger.debug("没有匹配的消息处理器: %r", ctx)
            return

        handler_mws = [_wrap_handler(e.handler) for e in matched]
        chain = MiddlewareChain(self._middlewares + handler_mws, _noop)
        try:
            await chain.execute(ctx)
        except Exception as exc:
            logger.exception("消息处理异常: %r", ctx)
            await self._forward_error(ctx, exc)

    async def _forward_error(
        self, ctx: MessageContext, exc: Exception
    ) -> None:
        """转发 handler 异常：回复用户 + 通知 error 事件处理器。"""
        try:
            await ctx.reply(self._error_message)
        except Exception:
            logger.exception("错误回复失败")
        await self._channel._invoke("error", exc)

    # ------------------------------------------------------------------
    # 卡片回调
    # ------------------------------------------------------------------

    def _register_card_callbacks(
        self, message_id: str, callbacks: Dict[str, Callable]
    ) -> None:
        """将卡片按钮回调注册到 message_id 下。"""
        self._card_callbacks[message_id] = callbacks

    async def _on_card_action(self, event: Any) -> None:
        """FeishuChannel cardAction 事件回调 — 分发到绑定的按钮回调。"""
        from lark_oapi.channel.types import CardActionEvent

        if not isinstance(event, CardActionEvent):
            return

        msg_id = event.message_id
        btn_name = event.action.name if event.action else None

        callbacks = self._card_callbacks.get(msg_id)
        if callbacks and btn_name and btn_name in callbacks:
            callback = callbacks[btn_name]
            ctx = MessageContext(
                event=event, bot=self, channel=self._channel
            )
            try:
                result = callback(ctx)
                if inspect.isawaitable(result):
                    await result
            except Exception as exc:
                logger.exception("卡片回调异常: %s/%s", msg_id, btn_name)
                await self._forward_error(ctx, exc)

    # ------------------------------------------------------------------
    # 生命周期
    # ------------------------------------------------------------------

    def _wire_handlers(self) -> None:
        """将所有已注册的处理器接入 FeishuChannel 的事件系统。"""
        if self._wired:
            return
        self._wired = True

        # 注册消息处理
        self._channel.on("message", self._on_message)

        # 注册卡片回调分发器（优先级高于用户注册的 cardAction handler）
        self._channel.on("cardAction", self._on_card_action)

        # 注册其他事件
        for event_name, handlers in self._event_handlers.items():
            for handler in handlers:
                self._channel.on(event_name, handler)

    def run(self) -> None:
        """启动 Bot（阻塞）。

        内部调用 ``FeishuChannel.start()``，会阻塞主线程维持
        WebSocket 长连接。
        """
        self._wire_handlers()

        handler_count = len(self._message_handlers)
        mw_count = len(self._middlewares)
        event_count = sum(len(v) for v in self._event_handlers.values())
        ext_count = len(self._extensions)

        logger.info(
            "FeishuBot 启动 — %d 消息处理器, %d 中间件, %d 事件处理器, %d 扩展",
            handler_count, mw_count, event_count, ext_count,
        )

        self._scheduler.start()
        self._channel.start()

    def stop(self) -> None:
        """停止 Bot。"""
        self._scheduler.stop()
        self._channel.stop()


# ------------------------------------------------------------------
# 模块级辅助函数
# ------------------------------------------------------------------

async def _noop(ctx: Any) -> None:
    """链末端的空操作 handler。"""
    pass


def _wrap_handler(handler: Callable) -> Callable:
    """将 handler 包装为 (ctx, next) 签名以接入中间件链。

    签名检查：
    - 接受 2+ 参数 → 原样传入，由 handler 决定是否调 next()
    - 接受 1 个参数 → 包装后不调 next()，链终止
    """
    params = list(inspect.signature(handler).parameters.values())
    if len(params) >= 2:
        return handler

    async def _mw(ctx: Any, next: Callable) -> None:
        result = handler(ctx)
        if inspect.isawaitable(result):
            await result

    return _mw
