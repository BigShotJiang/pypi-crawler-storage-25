"""wings_bot.plugin — 插件自动发现与加载（支持热重载）。

扫描指定目录下的 ``.py`` 文件，自动 import 并调用 ``register(bot, **kwargs)``。

用法::

    from wings_bot.plugin import load_plugins

    # 一次性加载
    load_plugins(bot, cmds=cmds)

    # 开发模式：文件变更自动重载
    load_plugins(bot, cmds=cmds, hot_reload=True)
"""

from __future__ import annotations

import importlib
import logging
import os
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple

logger = logging.getLogger("feishu_bot.plugin")


# ------------------------------------------------------------------
# 注册追踪
# ------------------------------------------------------------------

@dataclass
class _PluginRecord:
    """一个已加载插件的追踪信息。"""

    name: str
    module: Any
    module_path: str
    kwargs: Dict[str, Any]
    snap_handlers: int = 0
    snap_middlewares: int = 0
    snap_event_handlers: Dict[str, int] = field(default_factory=dict)


_plugins: Dict[str, _PluginRecord] = {}
_bot_ref: Any = None
_plugins_dir: str = "plugins"
_observer: Any = None
_pending_reloads: Dict[str, float] = {}
_debounce_lock = threading.Lock()


def _snapshot(bot: Any) -> Tuple[int, int, Dict[str, int]]:
    """记录当前 bot 注册表的长度快照。"""
    event_lens = {
        k: len(v) for k, v in bot._event_handlers.items()
    }
    return len(bot._message_handlers), len(bot._middlewares), event_lens


def _remove_registrations(bot: Any, rec: _PluginRecord) -> None:
    """移除该插件在 register() 中注册的所有 handlers 和 middlewares。"""
    # handlers — 移除从 snap_handlers 位置开始、由该插件新增的部分
    old_len = rec.snap_handlers
    added = bot._message_handlers[old_len:]
    for h in added:
        # 只移除确实由该插件新增的（防止并发修改误删）
        if h in bot._message_handlers:
            bot._message_handlers.remove(h)

    # middlewares
    mw_old_len = rec.snap_middlewares
    added_mw = bot._middlewares[mw_old_len:]
    for mw in added_mw:
        if mw in bot._middlewares:
            bot._middlewares.remove(mw)

    # event handlers
    for evt_name, old_count in rec.snap_event_handlers.items():
        handlers = bot._event_handlers.get(evt_name, [])
        if len(handlers) > old_count:
            to_remove = handlers[old_count:]
            for h in to_remove:
                if h in handlers:
                    handlers.remove(h)


def _load_single_plugin(
    bot: Any,
    name: str,
    plugins_dir: str,
    **kwargs: Any,
) -> Optional[_PluginRecord]:
    """加载单个插件并记录注册追踪。"""
    module_path = f"{plugins_dir}.{name}"
    snap = _snapshot(bot)

    try:
        mod = importlib.import_module(module_path)
    except Exception:
        logger.exception("加载插件 %s 失败", name)
        return None

    register_fn = getattr(mod, "register", None)
    if not callable(register_fn):
        logger.warning("插件 %s 没有 register() 函数，跳过", name)
        return None

    try:
        register_fn(bot, **kwargs)
    except Exception:
        logger.exception("插件 %s 的 register() 执行失败", name)
        return None

    rec = _PluginRecord(
        name=name,
        module=mod,
        module_path=module_path,
        kwargs=kwargs,
        snap_handlers=snap[0],
        snap_middlewares=snap[1],
        snap_event_handlers=snap[2],
    )
    logger.info("已加载插件: %s", name)
    return rec


def _reload_plugin(name: str) -> None:
    """热重载指定插件。"""
    global _plugins

    bot = _bot_ref
    if bot is None:
        return

    rec = _plugins.get(name)
    if rec is None:
        return

    logger.info("热重载插件: %s", name)

    # 1. 移除旧注册
    _remove_registrations(bot, rec)

    # 2. 重新加载模块
    try:
        mod = importlib.reload(rec.module)
    except Exception:
        # reload 失败时尝试重新 import
        logger.exception("reload 插件 %s 失败，尝试重新 import", name)
        try:
            mod = importlib.import_module(rec.module_path)
        except Exception:
            logger.exception("重新 import 插件 %s 也失败", name)
            return

    # 3. 快照 + register
    snap = _snapshot(bot)
    register_fn = getattr(mod, "register", None)
    if not callable(register_fn):
        logger.warning("插件 %s reload 后没有 register()，跳过", name)
        return

    try:
        register_fn(bot, **rec.kwargs)
    except Exception:
        logger.exception("插件 %s reload 后 register() 失败", name)
        return

    # 4. 更新追踪记录
    rec.module = mod
    rec.snap_handlers = snap[0]
    rec.snap_middlewares = snap[1]
    rec.snap_event_handlers = snap[2]
    logger.info("插件 %s 热重载完成", name)


# ------------------------------------------------------------------
# 文件监控（watchdog）
# ------------------------------------------------------------------

def _start_watcher(plugins_dir: str) -> None:
    """启动 watchdog 文件监控。"""
    from watchdog.events import FileSystemEventHandler
    from watchdog.observers import Observer

    class PluginFileHandler(FileSystemEventHandler):
        def on_modified(self, event: Any) -> None:
            if event.is_directory or not event.src_path.endswith(".py"):
                return
            fname = os.path.basename(event.src_path)
            if fname.startswith("_"):
                return
            name = fname[:-3]
            if name not in _plugins:
                return
            # 去抖：记录时间，延迟执行
            with _debounce_lock:
                _pending_reloads[name] = time.monotonic()

    abs_dir = os.path.abspath(plugins_dir)
    if not os.path.isdir(abs_dir):
        return

    handler = PluginFileHandler()
    obs = Observer()
    obs.daemon_threads = True
    obs.schedule(handler, abs_dir, recursive=False)
    obs.start()

    global _observer
    _observer = obs

    # 去抖线程
    def _debounce_loop() -> None:
        while _observer is not None:
            time.sleep(0.3)
            now = time.monotonic()
            with _debounce_lock:
                ready = [
                    n for n, t in _pending_reloads.items()
                    if now - t > 0.5
                ]
                for n in ready:
                    del _pending_reloads[n]
            for plugin_name in ready:
                try:
                    _reload_plugin(plugin_name)
                except Exception:
                    logger.exception("热重载插件 %s 异常", plugin_name)

    t = threading.Thread(target=_debounce_loop, daemon=True)
    t.start()

    logger.info("插件热重载已启动，监控目录: %s", abs_dir)


# ------------------------------------------------------------------
# 公开 API
# ------------------------------------------------------------------

def load_plugins(
    bot: Any,
    plugins_dir: str = "plugins",
    disabled: Optional[List[str]] = None,
    *,
    hot_reload: bool = False,
    **kwargs: Any,
) -> List[str]:
    """扫描 plugins_dir 并加载所有插件。

    Args:
        bot: FeishuBot 实例。
        plugins_dir: 插件目录路径，相对于工作目录。
        disabled: 要跳过的插件名列表（不含 .py 后缀）。
        hot_reload: 是否启用文件变更热重载（开发模式）。
        **kwargs: 透传给每个插件 ``register()`` 的额外参数。

    Returns:
        成功加载的插件名列表。
    """
    global _bot_ref, _plugins_dir

    disabled_set = set(disabled or [])
    loaded: List[str] = []

    if not os.path.isdir(plugins_dir):
        logger.warning("插件目录不存在: %s", plugins_dir)
        return loaded

    _bot_ref = bot
    _plugins_dir = plugins_dir

    for fname in sorted(os.listdir(plugins_dir)):
        if fname.startswith("_") or not fname.endswith(".py"):
            continue

        name = fname[:-3]
        if name in disabled_set:
            logger.info("跳过已禁用的插件: %s", name)
            continue

        rec = _load_single_plugin(bot, name, plugins_dir, **kwargs)
        if rec is not None:
            _plugins[name] = rec
            loaded.append(name)

    if hot_reload and loaded:
        _start_watcher(plugins_dir)

    return loaded
