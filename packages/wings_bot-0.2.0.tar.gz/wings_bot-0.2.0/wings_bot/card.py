"""wings_bot.card — 飞书消息卡片构建器（v1 格式）。

Fluent API 构建飞书交互式卡片 JSON，配合 ``ctx.reply(card)`` 使用。

用法::

    from wings_bot.card import Card

    card = (
        Card()
        .header(title="标题", template="blue")
        .add_text("纯文本")
        .add_markdown("**粗体**")
        .add_hr()
        .add_button("确认", variant="primary", value={"action": "ok"})
        .add_button("取消", variant="default", url="https://example.com")
        .build()
    )
    await ctx.reply(card)
"""

from __future__ import annotations

from typing import Any, Callable, Dict, List, Optional

# Callback type: async (ctx: MessageContext) -> None
ButtonClick = Callable[..., Any]


class Card:
    """飞书卡片 v1 JSON 构建器。

    每个方法返回 ``self``，支持链式调用。
    调用 ``build()`` 获取最终的 dict。
    """

    def __init__(self) -> None:
        self._config: Dict[str, Any] = {}
        self._header: Optional[Dict[str, Any]] = None
        self._elements: List[Dict[str, Any]] = []
        self._callbacks: Dict[str, ButtonClick] = {}
        self._btn_counter: int = 0

    # -- Config --

    def config(
        self,
        *,
        wide_screen: bool = False,
        enable_forward: bool = True,
    ) -> Card:
        """设置卡片级别配置。"""
        self._config = {
            "wide_screen": wide_screen,
            "enable_forward": enable_forward,
        }
        return self

    # -- Header --

    def header(
        self,
        *,
        title: str,
        subtitle: Optional[str] = None,
        template: Optional[str] = None,
    ) -> Card:
        """设置卡片标题头。

        Args:
            title: 标题文本。
            subtitle: 副标题文本。
            template: 标题栏颜色主题（blue, wathet, turquoise, green,
                      yellow, orange, red, carmine, violet, purple,
                      indigo, grey, default）。
        """
        h: Dict[str, Any] = {
            "title": {"tag": "plain_text", "content": title},
        }
        if subtitle is not None:
            h["subtitle"] = {"tag": "plain_text", "content": subtitle}
        if template is not None:
            h["template"] = template
        self._header = h
        return self

    # -- 显示元素 --

    def add_text(self, text: str) -> Card:
        """添加纯文本 div 元素。"""
        self._elements.append({
            "tag": "div",
            "text": {"tag": "plain_text", "content": text},
        })
        return self

    def add_markdown(self, content: str) -> Card:
        """添加 Markdown 元素。"""
        self._elements.append({
            "tag": "markdown",
            "content": content,
        })
        return self

    def add_hr(self) -> Card:
        """添加分割线。"""
        self._elements.append({"tag": "hr"})
        return self

    def add_img(self, img_key: str, *, alt: Optional[str] = None) -> Card:
        """添加图片元素。

        Args:
            img_key: 飞书图片 key（通过上传获取）。
            alt: 图片替代文本。
        """
        el: Dict[str, Any] = {"tag": "img", "img_key": img_key}
        if alt is not None:
            el["alt"] = {"tag": "plain_text", "content": alt}
        self._elements.append(el)
        return self

    # -- 布局 --

    def add_column_set(self, columns: List[Dict[str, Any]]) -> Card:
        """添加多列布局。

        Args:
            columns: 列定义列表，每列需包含 ``weight`` 和 ``elements``。
        """
        self._elements.append({
            "tag": "column_set",
            "columns": columns,
        })
        return self

    # -- 交互元素 --

    def add_button(
        self,
        text: str,
        *,
        variant: str = "default",
        url: Optional[str] = None,
        value: Optional[Dict[str, Any]] = None,
        on_click: Optional[ButtonClick] = None,
    ) -> Card:
        """添加按钮。

        连续调用会自动合并到同一行（同一个 action 元素）。

        Args:
            text: 按钮文本。
            variant: 按钮样式 — primary / default / danger。
            url: 点击后跳转的 URL。
            value: 回调值（cardAction 事件中会返回）。
            on_click: 点击回调，接收 ``MessageContext``（带 ``ctx.event``）。
        """
        btn: Dict[str, Any] = {
            "tag": "button",
            "text": {"tag": "plain_text", "content": text},
            "type": variant,
        }
        if on_click is not None:
            self._btn_counter += 1
            name = f"__w{self._btn_counter}"
            btn["name"] = name
            self._callbacks[name] = on_click
        if url is not None:
            btn["url"] = url
        if value is not None:
            btn["value"] = value

        # 连续 add_button 合并到同一个 action 行
        if self._elements and self._elements[-1].get("tag") == "action":
            self._elements[-1]["actions"].append(btn)
        else:
            self._elements.append({"tag": "action", "actions": [btn]})
        return self

    # -- Build --

    def build(self) -> Dict[str, Any]:
        """构建卡片 JSON dict，传给 ``ctx.reply(card)``。"""
        card: Dict[str, Any] = {}
        if self._config:
            card["config"] = self._config
        if self._header is not None:
            card["header"] = self._header
        card["elements"] = list(self._elements)
        return card

    def _drain_callbacks(self) -> Dict[str, ButtonClick]:
        """提取并清空回调映射，由 ``reply`` 在发送成功后调用。"""
        cbs = self._callbacks
        self._callbacks = {}
        return cbs
