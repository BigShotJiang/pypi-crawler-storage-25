"""bot.context — 消息上下文封装。

每个消息处理器接收一个 ``MessageContext`` 实例，它封装了：

- **只读属性**：消息文本、发送者、聊天信息等
- **操作方法**：reply / quote / send
- **共享状态**：``ctx.state`` 字典，中间件和处理器之间传递数据
"""

from __future__ import annotations

import inspect
from typing import Any, Dict, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from lark_oapi.channel import FeishuChannel, InboundMessage, SendResult
    from lark_oapi.channel.types import CardActionEvent

    from .app import FeishuBot
    from .card import Card


class MessageContext:
    """消息上下文 — 处理器和卡片回调的统一入参。

    Attributes:
        event: CardActionEvent（仅在 cardAction 回调中可用，消息 handler 中为 None）。
        state: 可读写字典，中间件可写入数据供下游处理器读取。
    """

    __slots__ = ("_msg", "_channel", "_bot", "state", "_event")

    def __init__(
        self,
        *,
        msg: Optional[InboundMessage] = None,
        channel: Optional[FeishuChannel] = None,
        bot: Optional[FeishuBot] = None,
        event: Optional[CardActionEvent] = None,
    ) -> None:
        self._msg = msg
        self._channel = channel
        self._bot = bot
        self.state: Dict[str, Any] = {}
        self._event = event

    # ------------------------------------------------------------------
    # 只读属性
    # ------------------------------------------------------------------

    @property
    def event(self) -> Optional[CardActionEvent]:
        """卡片交互事件（仅在 cardAction 回调中可用）。"""
        return self._event

    @property
    def text(self) -> str:
        """消息的纯文本内容（已由 FeishuChannel 归一化）。"""
        if self._msg is not None:
            return self._msg.content_text or ""
        return ""

    @property
    def sender_id(self) -> str:
        """发送者的 open_id。"""
        if self._event is not None:
            return self._event.operator.open_id if self._event.operator else ""
        s = self._msg.sender
        return s.open_id if s else ""

    @property
    def sender_union_id(self) -> str:
        """发送者的 union_id。"""
        if self._msg is not None:
            s = self._msg.sender
            return (s.union_id if s else None) or ""
        return ""

    @property
    def sender_name(self) -> str:
        """发送者的显示名称（如果 FeishuChannel 解析了的话）。"""
        if self._msg is not None:
            s = self._msg.sender
            return (s.display_name if s else None) or ""
        return ""

    @property
    def chat_id(self) -> str:
        """所在聊天的 chat_id。"""
        if self._event is not None:
            return self._event.chat_id
        return self._msg.conversation.chat_id if self._msg and self._msg.conversation else ""

    @property
    def chat_type(self) -> str:
        """聊天类型："p2p" 或 "group"。"""
        return self._msg.conversation.chat_type if self._msg.conversation else ""

    @property
    def message_type(self) -> str:
        """消息类型："text", "image", "interactive" 等。

        取自 content.kind（归一化后的消息类型判别字段）。
        """
        c = self._msg.content
        return getattr(c, "kind", None) or self._msg.raw_content_type or ""

    @property
    def message_id(self) -> str:
        """消息 ID。"""
        return self._msg.message_id

    @property
    def mentions(self) -> list:
        """消息中的 @提及 列表。"""
        return self._msg.mentions or []

    @property
    def is_mentioned(self) -> bool:
        """Bot 是否在本条消息中被 @。"""
        return self._msg.mentioned_bot

    @property
    def reply_to_id(self) -> Optional[str]:
        """被回复的消息 ID，如果不是回复消息则为 None。"""
        return self._msg.reply.message_id if self._msg.reply else None

    @property
    def parent_message(self) -> Optional[Any]:
        """被回复的消息内容对象（如果有）。

        通过 ``reply`` 字段获取原始回复引用：
        ``msg.reply.text`` / ``msg.reply.sender_id`` 等。
        """
        return self._msg.reply

    @property
    def content(self) -> Any:
        """归一化后的消息内容对象（TextContent / ImageContent / ...）。

        通过 ``content.kind`` 判断类型，例如::

            if ctx.content.kind == "text":
                print(ctx.content.text)
            elif ctx.content.kind == "image":
                print(ctx.content.image_key)
        """
        return self._msg.content

    @property
    def raw(self) -> InboundMessage:
        """原始 InboundMessage 对象，用于访问框架未封装的字段。"""
        return self._msg

    @property
    def channel(self) -> FeishuChannel:
        """底层 FeishuChannel 实例，用于高级操作。"""
        return self._channel

    # ------------------------------------------------------------------
    # 操作方法
    # ------------------------------------------------------------------

    def _opts(self, reply_to: Optional[str] = None) -> Any:
        """构造 SendOpts（仅在 reply_to 非空时）。"""
        if reply_to is None:
            return None
        from lark_oapi.channel.types import SendOpts
        return SendOpts(reply_to=reply_to)

    # -- 统一回复 --

    async def quote(
        self,
        *parts: Any,
        reply_to: Optional[str] = None,
        **kwargs: Any,
    ) -> SendResult:
        """引用回复 — 默认引用当前消息，也可指定其他消息 ID。

        用法::

            await ctx.quote("收到")       # 自动引用上行消息
            await ctx.quote("补充", reply_to="om_xxxx")  # 指定引用
        """
        target = reply_to if reply_to is not None else self.reply_to_id
        return await self.reply(*parts, reply_to=target, **kwargs)

    async def reply(
        self,
        *parts: Any,
        reply_to: Optional[str] = None,
        **kwargs: Any,
    ) -> SendResult:
        """回复消息 — 统一入口，根据参数类型自动选择发送方式。

        单个参数时：

        - ``str`` → 文本消息
        - ``Markdown`` → markdown 消息
        - ``dict`` → 直接发送原始 dict
        - ``Card`` → 卡片消息（自动处理 on_click 绑定）
        - ``Image / File / Audio / Video / Sticker / ShareChat / ShareUser``
          → 对应消息类型

        多个参数时，自动组合为 post 富文本：

        - ``str`` 片段和 ``At`` 等元素按顺序拼接
        - 仅纯文本拼接时走 text 类型，含 ``At`` 等非文本元素时走 post

        用法::

            await ctx.reply("hello")
            await ctx.reply(Markdown("**bold**"))
            await ctx.reply(Image("/path/to/photo.png"))
            await ctx.reply("你好 ", At("ou_abc"), " 请查看")

        Args:
            *parts: 消息内容 — str、Markdown、消息类型类实例、Card、dict。
            reply_to: 回复指定消息的 message_id。
        """
        opts = self._opts(reply_to)
        chat_id = self.chat_id

        # 无参数 — 不应该发生，给个友好提示
        if not parts:
            return await self._channel.send(chat_id, {"text": ""}, opts=opts)

        # 单个参数 — 类型分发
        if len(parts) == 1:
            part = parts[0]

            if isinstance(part, str):
                return await self._channel.send(
                    chat_id, {"text": part}, opts=opts, **kwargs
                )

            if isinstance(part, dict):
                return await self._channel.send(chat_id, part, opts=opts, **kwargs)

            if isinstance(part, Card):
                return await self._send_card(chat_id, part, opts=opts, **kwargs)

            if hasattr(part, "_to_payload"):
                return await self._channel.send(
                    chat_id, part._to_payload(), opts=opts, **kwargs
                )

            return await self._channel.send(
                chat_id, {"text": str(part)}, opts=opts, **kwargs
            )

        # 多个参数 — 组合为 post 富文本或纯文本
        return await self._reply_composed(parts, opts=opts, **kwargs)

    async def _send_card(
        self, chat_id: str, card: Any, opts: Any = None, **kwargs: Any
    ) -> SendResult:
        """发送卡片消息（处理 Card 实例的 on_click 绑定）。"""
        callbacks = {}
        if isinstance(card, Card):
            callbacks = card._drain_callbacks()
            card = card.build()
        if isinstance(card, dict) and "card" not in card:
            card = {"card": card}
        result = await self._channel.send(chat_id, card, opts=opts, **kwargs)
        if callbacks and self._bot is not None and result.message_id:
            self._bot._register_card_callbacks(result.message_id, callbacks)
        return result

    async def _reply_composed(
        self, parts: tuple, opts: Any = None, **kwargs: Any
    ) -> SendResult:
        """多个 parts 组合发送：纯文本拼接走 text，含 At 等走 text 内联，仅纯 post 元素走 post。"""
        requires_post = any(
            hasattr(p, "_to_post_element")
            and not hasattr(p, "_to_text_inline")
            and not isinstance(p, str)
            for p in parts
        )

        if not requires_post:
            # 纯文本 + 可内联元素 — 拼接为 text
            fragments: list[str] = []
            for p in parts:
                if isinstance(p, str):
                    fragments.append(p)
                elif hasattr(p, "_to_text_inline"):
                    fragments.append(p._to_text_inline())
                else:
                    fragments.append(str(p))
            return await self._channel.send(
                self.chat_id, {"text": "".join(fragments)}, opts=opts, **kwargs
            )

        # 有富文本元素 — 构建 post
        elements: list[Dict[str, Any]] = []
        for p in parts:
            if isinstance(p, str):
                if p:
                    elements.append({"tag": "text", "text": p})
            elif hasattr(p, "_to_post_element"):
                elements.append(p._to_post_element())
            else:
                elements.append({"tag": "text", "text": str(p)})

        post = {"zh_cn": {"content": [elements]}}
        return await self._channel.send(
            self.chat_id, {"post": post}, opts=opts, **kwargs
        )

    # -- 卡片操作 --

    async def update_card(self, card: Any) -> SendResult:
        """更新当前卡片内容。

        Args:
            card: ``Card`` 实例或卡片 JSON dict。
        """
        if isinstance(card, Card):
            card = card.build()
        message_id = self._event.message_id if self._event else self.message_id
        return await self._channel.update_card(message_id, card)

    # -- 主动发送 --

    async def send(
        self,
        chat_id: str,
        *parts: Any,
        reply_to: Optional[str] = None,
        **kwargs: Any,
    ) -> SendResult:
        """向指定聊天发送消息（不限于当前聊天）。

        参数规则与 ``reply()`` 相同。
        """
        opts = self._opts(reply_to)

        if not parts:
            return await self._channel.send(chat_id, {"text": ""}, opts=opts)

        if len(parts) == 1:
            part = parts[0]
            if isinstance(part, str):
                return await self._channel.send(
                    chat_id, {"text": part}, opts=opts, **kwargs
                )
            if isinstance(part, dict):
                return await self._channel.send(chat_id, part, opts=opts, **kwargs)
            if isinstance(part, Card):
                return await self._send_card(chat_id, part, opts=opts, **kwargs)
            if hasattr(part, "_to_payload"):
                return await self._channel.send(
                    chat_id, part._to_payload(), opts=opts, **kwargs
                )
            return await self._channel.send(
                chat_id, {"text": str(part)}, opts=opts, **kwargs
            )

        # 多 parts 组合
        requires_post = any(
            hasattr(p, "_to_post_element")
            and not hasattr(p, "_to_text_inline")
            and not isinstance(p, str)
            for p in parts
        )
        if not requires_post:
            fragments: list[str] = []
            for p in parts:
                if isinstance(p, str):
                    fragments.append(p)
                elif hasattr(p, "_to_text_inline"):
                    fragments.append(p._to_text_inline())
                else:
                    fragments.append(str(p))
            return await self._channel.send(
                chat_id, {"text": "".join(fragments)}, opts=opts, **kwargs
            )

        elements: list[Dict[str, Any]] = []
        for p in parts:
            if isinstance(p, str):
                if p:
                    elements.append({"tag": "text", "text": p})
            elif hasattr(p, "_to_post_element"):
                elements.append(p._to_post_element())
            else:
                elements.append({"tag": "text", "text": str(p)})

        post = {"zh_cn": {"content": [elements]}}
        return await self._channel.send(chat_id, {"post": post}, opts=opts, **kwargs)

    # -- 资源操作 --

    async def upload(
        self,
        source: Any,
        *,
        kind: str = "image",
        file_name: Optional[str] = None,
        file_type: Optional[str] = None,
    ) -> str:
        """上传资源（不发送），返回 file key。

        Args:
            source: 本地路径 (str)、URL (str) 或 bytes。
            kind: 资源类型 — "image" 或 "file"。
            file_name: 文件名（kind="file" 时使用）。
            file_type: 文件类型（如 "opus"、"mp4"）。

        Returns:
            上传后的 file key（如 "img_xxx" 或 "file_xxx"）。
        """
        return await self._channel.upload_media(
            source, kind=kind, file_name=file_name, file_type=file_type
        )

    async def recall(self, message_id: str) -> SendResult:
        """撤回一条消息。"""
        return await self._channel.recall_message(message_id)

    async def add_reaction(self, message_id: str, emoji_type: str) -> SendResult:
        """给消息添加表情回应。

        Args:
            message_id: 目标消息 ID。
            emoji_type: 表情类型（如 "THUMBSUP"、"HEART"、"SMILE"）。
        """
        return await self._channel.add_reaction(message_id, emoji_type)

    async def download(
        self,
        file_key: str,
        *,
        resource_type: str = "image",
        message_id: Optional[str] = None,
    ) -> Optional[bytes]:
        """下载资源为 bytes。

        Args:
            file_key: 资源 key（如 "img_xxx"）。
            resource_type: 资源类型 — "image" 或 "file"。
            message_id: 关联的消息 ID（某些资源类型需要）。
        """
        return await self._channel.download_resource(
            file_key, resource_type, message_id=message_id
        )

    def __repr__(self) -> str:
        return (
            f"<MessageContext chat_type={self.chat_type!r} "
            f"sender={self.sender_id!r} text={self.text[:30]!r}>"
        )
