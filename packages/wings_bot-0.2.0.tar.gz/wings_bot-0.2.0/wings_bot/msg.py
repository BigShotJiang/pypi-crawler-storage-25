"""wings_bot.msg — 消息类型类。

与 ``ctx.reply()`` 配合使用，支持组合发送各类消息。

用法::

    from wings_bot.msg import At, Image, File

    # 单类型
    await ctx.reply(Image("/path/to/photo.png"))
    await ctx.reply(File(bytes_data, file_name="报告.pdf"))

    # 组合 — 自动构建 post 富文本
    await ctx.reply("你好 ", At("ou_abc"), " 请查看")
    await ctx.reply("附件：", File("file_xxx", file_name="doc.pdf"))
"""

from __future__ import annotations

from typing import Any, Dict, Optional


class At:
    """@提及元素。"""

    __slots__ = ("user_id", "name")

    def __init__(self, user_id: str, name: str = "") -> None:
        self.user_id = user_id
        self.name = name

    def _to_post_element(self) -> Dict[str, Any]:
        return {"tag": "at", "user_id": self.user_id, "user_name": self.name}

    def _to_text_inline(self) -> str:
        return f'<at user_id="{self.user_id}">{self.name}</at>'


class Image:
    """图片消息。source 可以是本地路径、URL、已上传 key 或 bytes。"""

    __slots__ = ("source", "caption")

    def __init__(self, source: Any, *, caption: Optional[str] = None) -> None:
        self.source = source
        self.caption = caption

    def _to_payload(self) -> Dict[str, Any]:
        payload: Dict[str, Any] = {"image": {"source": self.source}}
        if self.caption is not None:
            payload["image"]["caption"] = self.caption
        return payload

    def _to_post_element(self) -> Dict[str, Any]:
        return {"tag": "img", "image_key": self.source}


class File:
    """文件消息。source 可以是本地路径、URL、已上传 key 或 bytes。"""

    __slots__ = ("source", "file_name")

    def __init__(self, source: Any, *, file_name: Optional[str] = None) -> None:
        self.source = source
        self.file_name = file_name

    def _to_payload(self) -> Dict[str, Any]:
        payload: Dict[str, Any] = {"file": {"source": self.source}}
        if self.file_name is not None:
            payload["file"]["file_name"] = self.file_name
        return payload

    def _to_post_element(self) -> Dict[str, Any]:
        el: Dict[str, Any] = {"tag": "file", "file_key": self.source}
        if self.file_name is not None:
            el["file_name"] = self.file_name
        return el


class Audio:
    """音频消息。"""

    __slots__ = ("source",)

    def __init__(self, source: Any) -> None:
        self.source = source

    def _to_payload(self) -> Dict[str, Any]:
        return {"audio": {"source": self.source}}


class Video:
    """视频消息。"""

    __slots__ = ("source", "caption")

    def __init__(self, source: Any, *, caption: Optional[str] = None) -> None:
        self.source = source
        self.caption = caption

    def _to_payload(self) -> Dict[str, Any]:
        payload: Dict[str, Any] = {"video": {"source": self.source}}
        if self.caption is not None:
            payload["video"]["caption"] = self.caption
        return payload


class Markdown:
    """Markdown 消息。"""

    __slots__ = ("content",)

    def __init__(self, content: str) -> None:
        self.content = content

    def _to_payload(self) -> Dict[str, Any]:
        return {"markdown": self.content}


class Sticker:
    """表情贴纸消息。"""

    __slots__ = ("file_key",)

    def __init__(self, file_key: str) -> None:
        self.file_key = file_key

    def _to_payload(self) -> Dict[str, Any]:
        return {"sticker": self.file_key}


class ShareChat:
    """转发群聊名片。"""

    __slots__ = ("chat_id",)

    def __init__(self, chat_id: str) -> None:
        self.chat_id = chat_id

    def _to_payload(self) -> Dict[str, Any]:
        return {"share_chat": self.chat_id}


class ShareUser:
    """转发用户名片。"""

    __slots__ = ("user_id",)

    def __init__(self, user_id: str) -> None:
        self.user_id = user_id

    def _to_payload(self) -> Dict[str, Any]:
        return {"share_user": self.user_id}


# 类型标记：有 _to_payload 方法的类可以独立发送
# 有 _to_post_element 方法的类可以参与 post 富文本组合

def _has_payload(obj: Any) -> bool:
    return hasattr(obj, "_to_payload")

def _has_post_element(obj: Any) -> bool:
    return hasattr(obj, "_to_post_element")
