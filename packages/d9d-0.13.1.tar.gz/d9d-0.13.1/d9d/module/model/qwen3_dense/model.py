from collections.abc import Mapping
from typing import cast

import torch
from torch import nn
from torch.utils.checkpoint import checkpoint

from d9d.module.base import ModuleLateInit
from d9d.module.block.embedding import SplitTokenEmbeddings
from d9d.module.block.head import ClassificationHead, SplitLanguageModellingHead
from d9d.module.block.hidden_states_aggregator import HiddenStatesAggregationMode, create_hidden_states_aggregator
from d9d.module.block.normalization import RMSNorm
from d9d.module.block.positional import RotaryEmbeddingProvider, RotaryEmbeddingStyle
from d9d.pipelining.api import (
    ModuleSupportsPipelining,
    PipelineStageInfo,
    distribute_layers_for_pipeline_stage,
)

from .decoder_layer import Qwen3DenseLayer
from .params import Qwen3DenseForCausalLMParameters, Qwen3DenseForClassificationParameters, Qwen3DenseParameters


class Qwen3DenseModel(nn.Module, ModuleLateInit, ModuleSupportsPipelining):
    """
    The Qwen3 Dense Transformer Decoder backbone.

    It is designed to be split across multiple pipeline stages.
    """

    def __init__(
        self,
        params: Qwen3DenseParameters,
        stage: PipelineStageInfo,
        hidden_states_snapshot_mode: HiddenStatesAggregationMode,
        enable_checkpointing: bool,
    ):
        """
        Constructs the Qwen3DenseModel object.

        Args:
            params: Configuration parameters for the full model.
            stage: Information about the pipeline stage this instance belongs to.
            hidden_states_snapshot_mode: Configures intermediate hidden state aggregation & snapshotting mode.
            enable_checkpointing: If True, enables activation checkpointing for transformer layers to save memory.
        """

        super().__init__()

        if stage.is_current_stage_first:
            self.embed_tokens = SplitTokenEmbeddings(
                hidden_size=params.layer.hidden_size,
                split_vocab_size=params.split_vocab_size,
                split_order=params.split_vocab_order,
            )

        # we use ModuleDict here to properly handle pipelining and loading weights after the model
        # was pipelined
        layer_start, layer_end = distribute_layers_for_pipeline_stage(
            num_layers=params.num_hidden_layers,
            num_virtual_layers_pre=params.pipeline_num_virtual_layers_pre,  # embedding
            num_virtual_layers_post=params.pipeline_num_virtual_layers_post,  # LM head
            stage=stage,
        )

        self._num_layers_before = layer_start
        self._layers_iter = list(map(str, range(layer_start, layer_end)))
        layers = nn.ModuleDict(
            {str(layer_idx): Qwen3DenseLayer(params=params.layer) for layer_idx in self._layers_iter}
        )
        self.layers: Mapping[str, Qwen3DenseLayer] = cast(Mapping[str, Qwen3DenseLayer], layers)

        self.rope_provider = RotaryEmbeddingProvider(
            max_position_ids=params.max_position_ids,
            rope_base=params.rope_base,
            head_dim=params.layer.head_dim,
            style=RotaryEmbeddingStyle.HALF,
        )

        if stage.is_current_stage_last:
            self.norm = RMSNorm(params.layer.hidden_size, eps=params.layer.rms_norm_eps)

        self._stage = stage
        self._hidden_states_snapshot_mode = hidden_states_snapshot_mode
        self._hidden_size = params.layer.hidden_size
        self._enable_checkpointing = enable_checkpointing

    def output_dtype(self) -> torch.dtype:
        """
        Returns the data type of the model output hidden states.
        """
        return self.layers[self._layers_iter[0]].input_layernorm.weight.dtype

    def forward(
        self,
        input_ids: torch.Tensor | None = None,
        hidden_states: torch.Tensor | None = None,
        position_ids: torch.Tensor | None = None,
        hidden_states_snapshot: torch.Tensor | None = None,
        hidden_states_agg_mask: torch.Tensor | None = None,
    ) -> dict[str, torch.Tensor | None]:
        """
        Executes the forward pass for the current pipeline stage.

        Args:
            input_ids: Indices of input sequence tokens. Required if this is the
                first pipeline stage.
            hidden_states: Hidden states from the previous pipeline stage. Required
                if this is not the first pipeline stage.
            position_ids: Indices of positions of each input sequence tokens in the
                position embeddings.
            hidden_states_snapshot: Accumulated tensor of aggregated hidden states
                from previous stages. Used if snapshotting is enabled.
            hidden_states_agg_mask: Mask used to aggregate hidden states for
                snapshots.

        Returns:
            A dictionary containing:
                *   'hidden_states': The output of the last layer in this stage.
                *   'hidden_states_snapshot': (Optional) The updated snapshot tensor.
        """
        state_aggregator = create_hidden_states_aggregator(self._hidden_states_snapshot_mode, hidden_states_agg_mask)

        if input_ids is not None:
            last_hidden_states = self.embed_tokens(input_ids)
            state_aggregator.add_hidden_states(last_hidden_states)
        else:
            last_hidden_states = hidden_states

        rope_params = self.rope_provider(position_ids)

        for decoder_layer_name in self._layers_iter:
            decoder_layer = self.layers[decoder_layer_name]

            if self._enable_checkpointing:
                last_hidden_states = checkpoint(decoder_layer, last_hidden_states, rope_params, use_reentrant=False)
            else:
                last_hidden_states = decoder_layer(last_hidden_states, rope_params)

            state_aggregator.add_hidden_states(last_hidden_states)

        if self._stage.is_current_stage_last:
            last_hidden_states = self.norm(last_hidden_states)

        return {
            "hidden_states": last_hidden_states,
            "hidden_states_snapshot": state_aggregator.pack_with_snapshot(hidden_states_snapshot),
        }

    def reset_parameters(self):
        """Resets module parameters."""

        if self._stage.is_current_stage_first:
            self.embed_tokens.reset_parameters()

        self.rope_provider.reset_parameters()

        for decoder_layer_name in self._layers_iter:
            decoder_layer = self.layers[decoder_layer_name]
            decoder_layer.reset_parameters()

        if self._stage.is_current_stage_last:
            self.norm.reset_parameters()

    def infer_stage_inputs_from_pipeline_inputs(
        self, inputs: dict[str, torch.Tensor], n_microbatches: int
    ) -> dict[str, torch.Tensor]:
        input_ids = inputs["input_ids"]

        pp_inputs = {}

        # for calculation - input ids or prev hidden state
        if self._stage.is_current_stage_first:
            pp_inputs["input_ids"] = torch.empty(
                (input_ids.shape[0] // n_microbatches, input_ids.shape[1]), dtype=torch.long, device=input_ids.device
            )
        else:
            pp_inputs["hidden_states"] = torch.empty(
                (input_ids.shape[0] // n_microbatches, input_ids.shape[1], self._hidden_size),
                dtype=self.output_dtype(),
                device=input_ids.device,
            )
            if self._hidden_states_snapshot_mode != HiddenStatesAggregationMode.no:
                num_layers_before = self._num_layers_before + 1  # 1 for embedding
                pp_inputs["hidden_states_snapshot"] = torch.empty(
                    (num_layers_before, input_ids.shape[0] // n_microbatches, self._hidden_size),
                    dtype=self.output_dtype(),
                    device=input_ids.device,
                )

        return pp_inputs

    def infer_stage_outputs_from_pipeline_inputs(
        self, inputs: dict[str, torch.Tensor], n_microbatches: int
    ) -> dict[str, torch.Tensor]:
        input_ids = inputs["input_ids"]

        pp_outputs = {
            "hidden_states": torch.empty(
                (input_ids.shape[0] // n_microbatches, input_ids.shape[1], self._hidden_size),
                dtype=self.output_dtype(),
                device=input_ids.device,
            )
        }

        if self._hidden_states_snapshot_mode != HiddenStatesAggregationMode.no:
            num_layers_before = self._num_layers_before + 1
            num_layers_current = len(self.layers)
            num_layers_after = num_layers_before + num_layers_current
            pp_outputs["hidden_states_snapshot"] = torch.empty(
                (num_layers_after, input_ids.shape[0] // n_microbatches, self._hidden_size),
                dtype=self.output_dtype(),
                device=input_ids.device,
            )

        return pp_outputs


class Qwen3DenseForCausalLM(nn.Module, ModuleLateInit, ModuleSupportsPipelining):
    """
    A Qwen3 Dense model wrapped with a Causal Language Modeling head.

    It is designed to be split across multiple pipeline stages.
    """

    def __init__(
        self,
        params: Qwen3DenseForCausalLMParameters,
        stage: PipelineStageInfo,
        hidden_states_snapshot_mode: HiddenStatesAggregationMode,
        enable_checkpointing: bool,
    ):
        """
        Constructs the Qwen3DenseForCausalLM object.

        Args:
            params: Full model configuration parameters.
            stage: Pipeline stage information for this instance.
            hidden_states_snapshot_mode: Configures intermediate hidden state aggregation & snapshotting mode.
            enable_checkpointing: Whether to enable activation checkpointing.
        """

        super().__init__()

        self.model = Qwen3DenseModel(
            params.model,
            stage,
            hidden_states_snapshot_mode=hidden_states_snapshot_mode,
            enable_checkpointing=enable_checkpointing,
        )

        if stage.is_current_stage_last:
            self.lm_head = SplitLanguageModellingHead(
                split_vocab_size=params.model.split_vocab_size,
                split_order=params.model.split_vocab_order,
                hidden_size=params.model.layer.hidden_size,
            )

        self._stage = stage
        self._hidden_size = params.model.layer.hidden_size

    def forward(
        self,
        input_ids: torch.Tensor | None = None,
        hidden_states: torch.Tensor | None = None,
        position_ids: torch.Tensor | None = None,
        hidden_states_snapshot: torch.Tensor | None = None,
        hidden_states_agg_mask: torch.Tensor | None = None,
        labels: torch.Tensor | None = None,
    ) -> dict[str, torch.Tensor]:
        """
        Executes the model forward pass.

        If this is the last stage, it expects `labels` to be provided and computes
        the cross-entropy loss (returned as 'logps' typically representing per-token loss).

        Args:
            input_ids: Input token IDS (for Stage 0).
            hidden_states: Hidden states from previous stage (for Stage > 0).
            position_ids: Positional indices for RoPE.
            hidden_states_snapshot: Intermediate state collector.
            hidden_states_agg_mask: Mask for state aggregation.
            labels: Target tokens for loss computation (Last Stage).

        Returns:
            Dictionary containing 'hidden_states', optionally 'hidden_states_snapshot',
            and per-token 'logps' if on the last stage.
        """

        model_outputs = self.model(
            input_ids=input_ids,
            hidden_states=hidden_states,
            position_ids=position_ids,
            hidden_states_snapshot=hidden_states_snapshot,
            hidden_states_agg_mask=hidden_states_agg_mask,
        )
        if self._stage.is_current_stage_last:
            lm_out = self.lm_head(hidden_states=model_outputs["hidden_states"], labels=labels)
            model_outputs["logps"] = lm_out
        return model_outputs

    def reset_parameters(self):
        """
        Resets module parameters.
        """

        self.model.reset_parameters()

        if self._stage.is_current_stage_last:
            self.lm_head.reset_parameters()

    def infer_stage_inputs_from_pipeline_inputs(
        self, inputs: dict[str, torch.Tensor], n_microbatches: int
    ) -> dict[str, torch.Tensor]:
        return self.model.infer_stage_inputs_from_pipeline_inputs(inputs, n_microbatches)

    def infer_stage_outputs_from_pipeline_inputs(
        self, inputs: dict[str, torch.Tensor], n_microbatches: int
    ) -> dict[str, torch.Tensor]:
        pp_outputs = self.model.infer_stage_outputs_from_pipeline_inputs(inputs, n_microbatches)

        if self._stage.is_current_stage_last:
            pp_outputs["logps"] = torch.empty(inputs["input_ids"].shape, dtype=torch.float32)

        return pp_outputs


class Qwen3DenseForClassification(nn.Module, ModuleLateInit, ModuleSupportsPipelining):
    """
    A Qwen3 Dense model wrapped with a Sequence/Token Classification head.

    It is designed to be split across multiple pipeline stages.
    """

    def __init__(
        self,
        params: Qwen3DenseForClassificationParameters,
        stage: PipelineStageInfo,
        hidden_states_snapshot_mode: HiddenStatesAggregationMode,
        enable_checkpointing: bool,
    ):
        """
        Constructs the Qwen3DenseForClassification object.

        Args:
            params: Full model configuration parameters.
            stage: Pipeline stage information for this instance.
            hidden_states_snapshot_mode: Configures intermediate hidden state aggregation & snapshotting mode.
            enable_checkpointing: Whether to enable activation checkpointing.
        """

        super().__init__()

        self.model = Qwen3DenseModel(
            params.model,
            stage,
            hidden_states_snapshot_mode=hidden_states_snapshot_mode,
            enable_checkpointing=enable_checkpointing,
        )

        if stage.is_current_stage_last:
            self.cls_head = ClassificationHead(
                hidden_size=params.model.layer.hidden_size,
                num_labels=params.num_labels,
                dropout=params.classifier_dropout,
            )

        self._stage = stage
        self._hidden_size = params.model.layer.hidden_size
        self._num_labels = params.num_labels

    def forward(
        self,
        input_ids: torch.Tensor | None = None,
        hidden_states: torch.Tensor | None = None,
        position_ids: torch.Tensor | None = None,
        hidden_states_snapshot: torch.Tensor | None = None,
        hidden_states_agg_mask: torch.Tensor | None = None,
        pooling_mask: torch.Tensor | None = None,
    ) -> dict[str, torch.Tensor]:
        """
        Executes the classification model forward pass.

        Args:
            input_ids: Input token IDS (for Stage 0).
            hidden_states: Hidden states from previous stage (for Stage > 0).
            position_ids: Positional indices for RoPE.
            hidden_states_snapshot: Intermediate state collector.
            hidden_states_agg_mask: Mask for state aggregation.
            pooling_mask: Binary mask indicating which token(s) to pool for classification.
                Note: you can use `d9d.dataset.token_pooling_mask_from_attention_mask`
                in your Dataset to preallocate the pooling mask from attention mask.

        Returns:
            Dictionary containing 'hidden_states', optionally 'hidden_states_snapshot'.
                If on the last stage, also contains 'scores' (logits) of shape [batch, num_labels].
        """

        model_outputs = self.model(
            input_ids=input_ids,
            hidden_states=hidden_states,
            position_ids=position_ids,
            hidden_states_snapshot=hidden_states_snapshot,
            hidden_states_agg_mask=hidden_states_agg_mask,
        )
        if self._stage.is_current_stage_last:
            model_outputs["scores"] = self.cls_head(
                hidden_states=model_outputs["hidden_states"], pooling_mask=pooling_mask
            )
        return model_outputs

    def reset_parameters(self):
        """
        Resets module parameters.
        """

        self.model.reset_parameters()

        if self._stage.is_current_stage_last:
            self.cls_head.reset_parameters()

    def infer_stage_inputs_from_pipeline_inputs(
        self, inputs: dict[str, torch.Tensor], n_microbatches: int
    ) -> dict[str, torch.Tensor]:
        return self.model.infer_stage_inputs_from_pipeline_inputs(inputs, n_microbatches)

    def infer_stage_outputs_from_pipeline_inputs(
        self, inputs: dict[str, torch.Tensor], n_microbatches: int
    ) -> dict[str, torch.Tensor]:
        pp_outputs = self.model.infer_stage_outputs_from_pipeline_inputs(inputs, n_microbatches)

        if self._stage.is_current_stage_last:
            batch_size = inputs["input_ids"].shape[0] // n_microbatches
            pp_outputs["scores"] = torch.empty((batch_size, self._num_labels), dtype=torch.float32)

        return pp_outputs
