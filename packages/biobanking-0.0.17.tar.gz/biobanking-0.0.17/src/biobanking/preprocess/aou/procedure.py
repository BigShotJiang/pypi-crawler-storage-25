import os
import tqdm
import pandas as pd


# TODO: change to biobanking format i/o and config
# save procedure info
def save_procedure_info(cdr, bucket):
    procedure_table_query = f"""
    SELECT
    po.person_id,
    c.concept_name AS procedure,
    po.procedure_datetime,
    tc.concept_name AS procedure_type,
    po.procedure_source_value,
    po.visit_occurrence_id
    FROM `{cdr}.procedure_occurrence` po
    JOIN `{cdr}.concept` c
    ON po.procedure_concept_id = c.concept_id
    LEFT JOIN `{cdr}.concept` tc
    ON po.procedure_type_concept_id = tc.concept_id
    LEFT JOIN `{cdr}.cb_search_person` p
    ON p.person_id = po.person_id
    WHERE p.has_whole_genome_variant = 1
    """

    procedure_df = pd.read_gbq(
        procedure_table_query, dialect="standard",
        use_bqstorage_api=("BIGQUERY_STORAGE_API_ENABLED" in os.environ),
        progress_bar_type="tqdm_notebook"
    )
    procedure_df.to_csv(f"{bucket}/data/rwe_info/raw/procedure.csv.gz")
    return

