import os
import tqdm
import pandas as pd

# TODO: change to biobanking format i/o and config
# save survey info
def save_survey_info(cdr, bucket):
    ds_survey_query = f"""
    SELECT
    s.answer_concept_id,
    s.person_id,
    s.survey_datetime,
    s.survey,
    s.question,
    s.answer,
    ac.concept_name AS answer_category,
    s.survey_version_name
    
    FROM `{cdr}.ds_survey` s
    LEFT JOIN `{cdr}.concept` ac
    ON s.answer_concept_id = ac.concept_id
    LEFT JOIN `{cdr}.cb_search_person` p
    ON p.person_id = s.person_id
    WHERE p.has_whole_genome_variant = 1
        AND s.survey IN ('Overall Health', 'Personal and Family Health History')
    """
    survey_df = pd.read_gbq(
        ds_survey_query, dialect="standard",
        use_bqstorage_api=("BIGQUERY_STORAGE_API_ENABLED" in os.environ),
        progress_bar_type="tqdm_notebook"
    )
    survey_df.to_parquet(f"{bucket}/data/rwe_info/raw/survey_health.parquet", index=False)
    return

def clean_surveys():
    from rwe.parsers.aou.config import BUCKET, CDR, GOOGLE_PROJECT
    survey_df = pd.read_parquet(f"{BUCKET}/data/rwe_info/raw/survey_health.parquet")

    questions = [
    'Overall Health: General Health',
    'Overall Health: General Mental Health',
    'Overall Health: General Physical Health',
    'Overall Health: General Quality',
    ]

    selected_survey_df = survey_df.loc[survey_df.question.isin(questions)].copy()
    selected_survey_df.to_parquet(f"{BUCKET}/data/rwe_info/processed/selected_surveys.parquet")
    return

