import os
import tqdm
import pandas as pd


# TODO: change to biobanking format i/o and config
# save visit occurrence info
def save_visit_occurrence_info(cdr, bucket):
    visit_table_query = f"""
    SELECT
    vo.person_id,
    c.concept_name AS visit_type,
    vo.visit_start_datetime,
    vo.visit_end_datetime,
    ac.concept_name AS admitting_source,
    dc.concept_name AS discharge_to,
    vo.visit_source_value
    FROM `{cdr}.visit_occurrence` vo
    LEFT JOIN `{cdr}.concept` c
    ON vo.visit_concept_id = c.concept_id
    LEFT JOIN `{cdr}.concept` ac
    ON vo.admitting_source_concept_id = ac.concept_id
    LEFT JOIN `{cdr}.concept` dc
    ON vo.discharge_to_concept_id = dc.concept_id
    LEFT JOIN `{cdr}.cb_search_person` p
    ON p.person_id = vo.person_id
    WHERE p.has_whole_genome_variant = 1
    """

    visit_df = pd.read_gbq(
        visit_table_query, dialect="standard",
        use_bqstorage_api=("BIGQUERY_STORAGE_API_ENABLED" in os.environ),
        progress_bar_type="tqdm_notebook"
    )
    visit_df.to_csv(f"{bucket}/data/rwe_info/raw/visit.csv.gz")
    return