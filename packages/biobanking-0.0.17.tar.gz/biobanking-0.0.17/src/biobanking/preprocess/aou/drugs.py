import os
import tqdm
import pandas as pd

# TODO: change to biobanking format i/o and config
# save drug exposure info
def save_drug_exposure_info(cdr, bucket):
    drug_table_query = f"""
    SELECT
    de.person_id,
    c.concept_name AS drug,
    de.drug_exposure_start_datetime,
    de.drug_exposure_end_datetime,
    rc.concept_name AS route,
    de.quantity,
    de.days_supply,
    tc.concept_name AS drug_type,
    de.drug_source_value,
    de.visit_occurrence_id
    FROM `{cdr}.drug_exposure` de
    JOIN `{cdr}.concept` c
    ON de.drug_concept_id = c.concept_id
    LEFT JOIN `{cdr}.concept` rc
    ON de.route_concept_id = rc.concept_id
    LEFT JOIN `{cdr}.concept` tc
    ON de.drug_type_concept_id = tc.concept_id
    LEFT JOIN `{cdr}.cb_search_person` p
    ON p.person_id = de.person_id
    WHERE p.has_whole_genome_variant = 1
    """

    drug_df = pd.read_gbq(
        drug_table_query, dialect="standard",
        use_bqstorage_api=("BIGQUERY_STORAGE_API_ENABLED" in os.environ),
        progress_bar_type="tqdm_notebook"
    )
    drug_df.to_csv(f"{bucket}/data/rwe_info/raw/drug.csv.gz")
    return
