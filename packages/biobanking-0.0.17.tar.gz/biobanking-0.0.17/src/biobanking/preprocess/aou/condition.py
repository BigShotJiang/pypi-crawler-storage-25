import os
import tqdm
import pandas as pd


# TODO: change to biobanking format i/o and config
# save condition info
def save_condition_info(cdr, bucket):
    condition_table_query = f"""
    SELECT
    co.person_id,
    c.concept_name AS condition,
    co.condition_start_datetime,
    co.condition_end_datetime,
    tc.concept_name AS condition_type,
    sc.concept_name AS condition_status,
    co.condition_source_value,
    co.condition_status_source_value,
    co.visit_occurrence_id
    FROM `{cdr}.condition_occurrence` co
    JOIN `{cdr}.concept` c
    ON co.condition_concept_id = c.concept_id
    LEFT JOIN `{cdr}.concept` tc
    ON co.condition_type_concept_id = tc.concept_id
    LEFT JOIN `{cdr}.concept` sc
    ON co.condition_status_concept_id = sc.concept_id
    LEFT JOIN `{cdr}.cb_search_person` p
    ON p.person_id = co.person_id
    WHERE p.has_whole_genome_variant = 1
    """

    condition_df = pd.read_gbq(
        condition_table_query, dialect="standard",
        use_bqstorage_api=("BIGQUERY_STORAGE_API_ENABLED" in os.environ),
        progress_bar_type="tqdm_notebook"
    )
    condition_df.to_csv(f"{bucket}/data/rwe_info/raw/condition.csv.gz")
    return

