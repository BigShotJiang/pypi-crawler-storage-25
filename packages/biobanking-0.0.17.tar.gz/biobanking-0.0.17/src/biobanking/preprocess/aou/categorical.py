import os
import tqdm
import pandas as pd

# TODO: change to biobanking format i/o and config
# save categorical measurements info
def save_categorical_measurements_info(cdr, bucket, min_indv=4000):
    categorical_measurements_query = f"""
    WITH eligible_measurements AS (
    SELECT
        m.measurement_concept_id
    FROM `{cdr}.measurement` m
    LEFT JOIN `{cdr}.cb_search_person` p
        ON p.person_id = m.person_id
    WHERE p.has_whole_genome_variant = 1
        AND m.value_as_number IS NULL
        AND m.value_as_concept_id IS NOT NULL
    GROUP BY m.measurement_concept_id
    HAVING COUNT(DISTINCT m.person_id) >= {min_indv}
    ),

    categorical_raw_table AS (
    SELECT
        m.person_id,
        m.measurement_concept_id,
        c.concept_name AS measurement,
        m.measurement_datetime,
        m.value_as_concept_id,
        vc.concept_name AS value_category
    FROM `{cdr}.measurement` m
    JOIN eligible_measurements em
        ON m.measurement_concept_id = em.measurement_concept_id
    JOIN `{cdr}.concept` c
        ON m.measurement_concept_id = c.concept_id
    LEFT JOIN `{cdr}.concept` vc
        ON m.value_as_concept_id = vc.concept_id
    LEFT JOIN `{cdr}.cb_search_person` p
        ON p.person_id = m.person_id
    WHERE p.has_whole_genome_variant = 1
        AND m.value_as_number IS NULL
        AND m.value_as_concept_id IS NOT NULL
        AND vc.concept_name NOT IN ('No matching concept')
    ),

    consistency AS (
    -- compute counts and the (unique) categorical value per person/measurement
    SELECT
        person_id,
        measurement_concept_id,
        COUNT(*) AS n_obs,
        COUNT(DISTINCT value_as_concept_id) AS n_distinct_values,
        MIN(value_as_concept_id) AS value_as_concept_id
    FROM categorical_raw_table
    GROUP BY person_id, measurement_concept_id
    )

    SELECT
    cs.person_id,
    cs.measurement_concept_id,
    mc.concept_name AS measurement,
    cs.value_as_concept_id,
    vc.concept_name AS value_category,
    cs.n_obs
    FROM consistency cs
    JOIN `{cdr}.concept` mc
    ON cs.measurement_concept_id = mc.concept_id
    LEFT JOIN `{cdr}.concept` vc
    ON cs.value_as_concept_id = vc.concept_id
    WHERE cs.n_distinct_values = 1
    AND cs.n_obs >= 1  -- change to ">= 1" if you want to keep single-read cases
    """

    categorical_measurements_df = pd.read_gbq(
        categorical_measurements_query, dialect="standard",
        use_bqstorage_api=("BIGQUERY_STORAGE_API_ENABLED" in os.environ),
        progress_bar_type="tqdm_notebook"
    )
    categorical_measurements_df.to_parquet(f"{bucket}/data/rwe_info/raw/categorical_measurements.parquet", index=False)
    return
