import os
import tqdm
import pandas as pd


# TODO: change to biobanking format i/o and config
# save observation info
def save_observation_info(cdr, bucket):
    observation_table_query = f"""
    SELECT
    o.person_id,
    c.concept_name AS observation,
    o.observation_datetime,
    o.value_as_number,
    vc.concept_name AS value_category,
    uc.concept_name AS unit,
    o.value_as_string,
    o.value_source_value,
    o.observation_source_value,
    tc.concept_name AS observation_type
    FROM `{cdr}.observation` o
    JOIN `{cdr}.concept` c
    ON o.observation_concept_id = c.concept_id
    LEFT JOIN `{cdr}.concept` vc
    ON o.value_as_concept_id = vc.concept_id
    LEFT JOIN `{cdr}.concept` uc
    ON o.unit_concept_id = uc.concept_id
    LEFT JOIN `{cdr}.concept` tc
    ON o.observation_type_concept_id = tc.concept_id
    LEFT JOIN `{cdr}.cb_search_person` p
    ON p.person_id = o.person_id
    WHERE p.has_whole_genome_variant = 1
    """

    observation_df = pd.read_gbq(
        observation_table_query, dialect="standard",
        use_bqstorage_api=("BIGQUERY_STORAGE_API_ENABLED" in os.environ),
        progress_bar_type="tqdm_notebook"
    )
    observation_df.to_csv(f"{bucket}/data/rwe_info/raw/observation.csv.gz")
    return