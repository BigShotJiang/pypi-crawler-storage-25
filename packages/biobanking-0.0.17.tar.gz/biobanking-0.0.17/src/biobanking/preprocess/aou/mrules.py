
# Biologically plausible values of commmon lab measurements and vitals
PLAUSIBLE = {
    # --- Vitals / anthropometrics ---
    "Body mass index (BMI) [Ratio]": (10, 80),          # kg/m^2
    "Body height": (120, 230),                          # cm
    "Body weight": (30, 300),                           # kg
    "Systolic blood pressure": (70, 250),               # mmHg
    "Diastolic blood pressure": (40, 150),              # mmHg
    "Heart rate": (30, 220),                            # bpm

    # --- Hematology (AoU typical units: Hgb g/L, Hct %, RBC 10^12/L, RDW-SD fL, MCV fL, Plt 10^9/L) ---
    "Hemoglobin [Mass/volume] in Blood": (50, 230),     # g/L
    "Hematocrit [Volume Fraction] of Blood by Automated count": (15, 70),  # %
    "Erythrocytes [#/volume] in Blood by Automated count": (2.0, 7.5),      # 10^12/L
    "Erythrocyte distribution width [Entitic volume]": (25, 80),            # fL (RDW-SD-like)
    "Erythrocyte distribution width [Ratio] by Automated count": (8.0, 30.0), # %
    "MCV [Entitic volume] by Automated count": (50, 130),                   # fL
    "MCH [Entitic mass] by Automated count": (10.0, 50.0),             # pg
    "MCHC [Mass/volume] by Automated count": (20.0, 40.0),             # g/dL
    "Platelets [#/volume] in Blood by Automated count": (20, 1500),         # 10^9/L
    "Platelet mean volume [Entitic volume] in Blood by Automated count": (5.0, 20.0), # fL
    "Monocytes [#/volume] in Blood by Automated count": (0.0, 5.0),         # 10^9/L (loose)
    "Leukocytes [#/volume] in Blood by Automated count": (0.5, 50.0),  # 10^3/uL
    "Neutrophils [#/volume] in Blood by Automated count": (0.0, 50.0), # 10^3/uL
    "Lymphocytes [#/volume] in Blood by Automated count": (0.0, 20.0), # 10^3/uL
    "Eosinophils [#/volume] in Blood by Automated count": (0.0, 5.0),       # 10^9/L (loose)
    "Basophils [#/volume] in Blood by Automated count": (0.0, 5.0),         # 10^9/L (wide)
    "Basophils [#/volume] in Blood": (0.0, 5.0),                             # 10^9/L (wide)
    "Basophils/100 leukocytes in Blood by Automated count": (0.0, 5.0),      # %
    "Basophils/100 leukocytes in Blood by Manual count": (0.0, 5.0),         # %
    "Basophils/100 leukocytes in Blood": (0.0, 5.0),                          # %
    "Immature granulocytes [#/volume] in Blood by Automated count": (0.0, 5.0),  # 10^9/L (wide)
    "Immature granulocytes [#/volume] in Blood": (0.0, 5.0),                     # 10^9/L (wide)
    "Immature granulocytes/100 leukocytes in Blood by Automated count": (0.0, 20.0),  # %
    "Immature granulocytes/100 leukocytes in Blood": (0.0, 20.0),                     # %
    "Nucleated erythrocytes [#/volume] in Blood by Automated count": (0.0, 10.0),      # unit varies; wide
    "Nucleated erythrocytes/100 leukocytes [Ratio] in Blood by Automated count": (0.0, 50.0),
    "Nucleated erythrocytes/100 leukocytes [Ratio] in Blood": (0.0, 50.0),


    # --- Renal / electrolytes (common units: creatinine mg/dL, BUN mg/dL, eGFR mL/min/1.73m2, electrolytes mmol/L) ---
    "Creatinine [Mass/volume] in Serum or Plasma": (0.2, 15),               # mg/dL
    "Urea nitrogen [Mass/volume] in Serum or Plasma": (2, 200),             # mg/dL
    "Glomerular filtration rate/1.73 sq M.predicted [Volume Rate/Area] in Serum, Plasma or Blood by Creatinine-based formula (MDRD)": (2, 200),  # mL/min/1.73m2
    "Sodium [Moles/volume] in Serum or Plasma": (110, 170),                 # mmol/L
    "Potassium [Moles/volume] in Serum or Plasma": (1.5, 8.0),              # mmol/L
    "Bicarbonate [Moles/volume] in Serum or Plasma": (5, 45),              # mmol/L
    "Chloride [Moles/volume] in Serum or Plasma": (70, 130),           # mmol/L
    "Calcium [Mass/volume] in Serum or Plasma": (5.0, 15.0),           # mg/dL
    "Magnesium [Mass/volume] in Serum or Plasma": (0.5, 6.0),          # mg/dL
    "Phosphate [Mass/volume] in Serum or Plasma": (0.5, 20.0),         # mg/dL
    "Anion gap 3 in Serum or Plasma": (0.0, 40.0),                     # mEq/L

    # --- Liver / protein balance (AoU typical units: albumin g/L, protein g/L, enzymes U/L, bilirubin mg/dL OR umol/L; range is loose) ---
    "Albumin [Mass/volume] in Serum or Plasma": (15, 60),                   # g/L
    "Protein [Mass/volume] in Serum or Plasma": (3, 12),                  # g/dL
    "Alanine aminotransferase [Enzymatic activity/volume] in Serum or Plasma": (0, 1000),     # U/L
    "Aspartate aminotransferase [Enzymatic activity/volume] in Serum or Plasma": (0, 1000),   # U/L
    "Alkaline phosphatase [Enzymatic activity/volume] in Serum or Plasma": (10, 2000),        # U/L
    "Bilirubin.total [Mass/volume] in Serum or Plasma": (0, 50),            # very loose (covers mg/dL extremes; if your data is umol/L, widen to 0–500)

    # --- Metabolic (common units: glucose mg/dL, A1c %, lipids mg/dL) ---
    "Glucose [Mass/volume] in Serum or Plasma": (30, 800),                  # mg/dL
    "Hemoglobin A1c/Hemoglobin.total in Blood": (3.0, 20.0),                # %
    "Cholesterol [Mass/volume] in Serum or Plasma": (50, 500),              # mg/dL
    "Cholesterol in LDL [Mass/volume] in Serum or Plasma by calculation": (0, 400),         # mg/dL
    "Cholesterol in HDL [Mass/volume] in Serum or Plasma": (5, 150),        # mg/dL
    "Triglyceride [Mass/volume] in Serum or Plasma": (10, 5000),            # mg/dL
    "Thyroxine (T4) free [Mass/volume] in Serum or Plasma": (0.1, 10.0),# ng/dL (or unit-harmonize)
    "25-Hydroxyvitamin D3+25-Hydroxyvitamin D2 [Mass/volume] in Serum or Plasma": (0.0, 200.0), # ng/mL
    
    # --- Urine or kidney damage ---
    "Protein [Mass/volume] in Urine by Test strip": (0.0, 3000.0),
    "Leukocytes [#/area] in Urine sediment by Microscopy high power field": (0.0, 200.0),
    "Erythrocytes [#/area] in Urine sediment by Microscopy high power field": (0.0, 200.0),
    "Epithelial cells.squamous [#/area] in Urine sediment by Microscopy high power field": (0.0, 200.0),
    "Albumin/Creatinine [Mass Ratio] in Urine": (0.0, 10000.0),         # mg/g (confirm units)

    # --- Inflammation ---
    "C reactive protein [Mass/volume] in Serum or Plasma": (0.0, 500.0), # mg/L (convert if mg/dL)
    "Erythrocyte sedimentation rate by Westergren method": (0.0, 200.0), # mm/hr

    # --- Cardiac biomarkers ---
    "Natriuretic peptide B [Mass/volume] in Serum or Plasma": (0.0, 5000.0), # pg/mL
    "Natriuretic peptide.B prohormone N-Terminal [Mass/volume] in Serum or Plasma": (0.0, 100000.0), # pg/mL
    "Troponin I.cardiac [Mass/volume] in Serum or Plasma": (0.0, 100.0),     # ng/mL (very wide)
    "Creatine kinase [Enzymatic activity/volume] in Serum or Plasma": (0.0, 20000.0), # U/L
}

# Unit conversion lambdas for common AoU lab measurements and vitals
UNIT_CONVERSIONS = {
    '25-Hydroxyvitamin D3+25-Hydroxyvitamin D2 [Mass/volume] in Serum or Plasma': dict(),
    'Alanine aminotransferase [Enzymatic activity/volume] in Serum or Plasma': dict(),
    'Albumin [Mass/volume] in Serum or Plasma': {
        'No matching concept': (lambda x: x * 10),
        'milligram per liter': (lambda x: x * 10),
        'no value': (lambda x: x * 10),
        'unit': (lambda x: x * 10),
    },
    'Albumin/Creatinine [Mass Ratio] in Urine': dict(),
    'Alkaline phosphatase [Enzymatic activity/volume] in Serum or Plasma': dict(),
    'Anion gap 3 in Serum or Plasma': dict(),
    'Aspartate aminotransferase [Enzymatic activity/volume] in Serum or Plasma': dict(),
    'Basophils [#/volume] in Blood': {
        "per microliter": lambda x: x / 1000.0,
        "cells per microliter": lambda x: x / 1000.0,
    },
    'Basophils [#/volume] in Blood by Automated count': {
        "cells per microliter": lambda x: x / 1000.0,
        "cells/uL": lambda x: x / 1000.0,
        "per microliter": lambda x: x / 1000.0,
        "uL": lambda x: x / 1000.0,
        "second": lambda x: x / 1000.0,  # N=1, but clearly on cells/µL scale
    },
    'Basophils/100 leukocytes in Blood': dict(),
    'Basophils/100 leukocytes in Blood by Automated count': dict(),
    'Basophils/100 leukocytes in Blood by Manual count': dict(),
    'Bicarbonate [Moles/volume] in Serum or Plasma': dict(),
    'Bilirubin.total [Mass/volume] in Serum or Plasma': dict(),
    'Body height': {
        'foot (international)': lambda x: x * 30.48,
        'inch (international)': lambda x: x * 2.54,
    },
    'Body mass index (BMI) [Ratio]': dict(),
    'Body weight': {
        'gram': lambda x: x * 0.001,
        'ounce (avoirdupois)': lambda x: x * 0.028349523125,
        'pound (US)': lambda x: x * 0.45359237,
    },
    'C reactive protein [Mass/volume] in Serum or Plasma': {
        "milligram per deciliter": lambda x: x * 10.0,
    },
    'Calcium [Mass/volume] in Serum or Plasma': dict(),
    'Chloride [Moles/volume] in Serum or Plasma': dict(),
    'Cholesterol [Mass/volume] in Serum or Plasma': dict(),
    'Cholesterol in HDL [Mass/volume] in Serum or Plasma': dict(),
    'Cholesterol in LDL [Mass/volume] in Serum or Plasma by calculation': dict(),
    'Creatine kinase [Enzymatic activity/volume] in Serum or Plasma': dict(),
    'Creatinine [Mass/volume] in Serum or Plasma': dict(),
    'Diastolic blood pressure': dict(),
    'Eosinophils [#/volume] in Blood by Automated count': {
        "cells per microliter": lambda x: x / 1000.0,
        "cells/uL": lambda x: x / 1000.0,
        "per microliter": lambda x: x / 1000.0,
    },
    'Epithelial cells.squamous [#/area] in Urine sediment by Microscopy high power field': dict(),
    'Erythrocyte distribution width [Entitic volume]': dict(),
    'Erythrocyte distribution width [Ratio] by Automated count': dict(),
    'Erythrocyte sedimentation rate by Westergren method': dict(),
    'Erythrocytes [#/area] in Urine sediment by Microscopy high power field': dict(),
    'Erythrocytes [#/volume] in Blood by Automated count': dict(),
    'Glomerular filtration rate/1.73 sq M.predicted [Volume Rate/Area] in Serum, Plasma or Blood by Creatinine-based formula (MDRD)': dict(),
    'Glucose [Mass/volume] in Serum or Plasma': dict(), 
    'Heart rate': dict(),
    'Hematocrit [Volume Fraction] of Blood by Automated count': dict(),
    'Hemoglobin A1c/Hemoglobin.total in Blood': dict(),
    'Hemoglobin [Mass/volume] in Blood': {
        "No matching concept": lambda x: x * 10.0,
        "no value": lambda x: x * 10.0,
        "unit": lambda x: x * 10.0,
        "gram": lambda x: x * 10.0,
        "thousand per microliter": lambda x: x * 10.0,
    },
    'Immature granulocytes [#/volume] in Blood': {
        "per microliter": lambda x: x / 1000.0,
    },
    'Immature granulocytes [#/volume] in Blood by Automated count': {
        "per microliter": lambda x: x / 1000.0,
        "cells per microliter": lambda x: x / 1000.0,
    },
    'Immature granulocytes/100 leukocytes in Blood': dict(),
    'Immature granulocytes/100 leukocytes in Blood by Automated count': dict(),
    'Leukocytes [#/area] in Urine sediment by Microscopy high power field': dict(),
    'Leukocytes [#/volume] in Blood by Automated count': dict(),
    'Lymphocytes [#/volume] in Blood by Automated count': {
        "/mcL": lambda x: x / 1000.0,
        "cells per cubic millimeter": lambda x: x / 1000.0,    # same as cells/µL
        "cells per microliter": lambda x: x / 1000.0,
        "cells/uL": lambda x: x / 1000.0,
        "per microliter": lambda x: x / 1000.0,
        "per cubic millimeter": lambda x: x / 1000.0,          # same as per µL
        "unit per liter": lambda x: x / 1000.0,                # value 1855 looks like cells/µL
    },
    'MCH [Entitic mass] by Automated count': dict(),
    'MCHC [Mass/volume] by Automated count': dict(),
    'MCV [Entitic volume] by Automated count': dict(),
    'Magnesium [Mass/volume] in Serum or Plasma': {
        "mEq/L": lambda x: x * 1.21525,                    # mEq/L -> mg/dL (Mg2+)
        "milliequivalent per liter": lambda x: x * 1.21525 # same as mEq/L
    },
    'Monocytes [#/volume] in Blood by Automated count': {
        "cells per microliter": lambda x: x / 1000.0,
        "cells/uL": lambda x: x / 1000.0,
        "per microliter": lambda x: x / 1000.0,
    },
    'Natriuretic peptide B [Mass/volume] in Serum or Plasma': dict(),
    'Natriuretic peptide.B prohormone N-Terminal [Mass/volume] in Serum or Plasma': dict(),
    'Neutrophils [#/volume] in Blood by Automated count': {
        "cells per microliter": lambda x: x / 1000.0,  # cells/µL -> 10^3/µL
        "cells/uL": lambda x: x / 1000.0,              # same
        "per microliter": lambda x: x / 1000.0,        # values look like cells/µL here
    },
    'Nucleated erythrocytes [#/volume] in Blood by Automated count': dict(),
    'Nucleated erythrocytes/100 leukocytes [Ratio] in Blood': dict(),
    'Nucleated erythrocytes/100 leukocytes [Ratio] in Blood by Automated count': dict(),
    'Phosphate [Mass/volume] in Serum or Plasma': dict(),
    'Platelet mean volume [Entitic volume] in Blood by Automated count': dict(),
    'Platelets [#/volume] in Blood by Automated count': dict(),
    'Potassium [Moles/volume] in Serum or Plasma': dict(),
    'Protein [Mass/volume] in Serum or Plasma': dict(),
    'Protein [Mass/volume] in Urine by Test strip': dict(),
    'Sodium [Moles/volume] in Serum or Plasma': dict(),
    'Systolic blood pressure': dict(),
    'Thyroxine (T4) free [Mass/volume] in Serum or Plasma': {
        "picomole per liter": lambda x: x * 0.077687,
    },
    'Triglyceride [Mass/volume] in Serum or Plasma': dict(),
    'Troponin I.cardiac [Mass/volume] in Serum or Plasma': {
        "nanogram per liter": lambda x: x * 0.001,
        "picogram per milliliter": lambda x: x * 0.001,
    },
    'Urea nitrogen [Mass/volume] in Serum or Plasma': dict(),
}

# Units to drop for specific AoU lab measurements and vitals
UNIT_DROPS = {
    '25-Hydroxyvitamin D3+25-Hydroxyvitamin D2 [Mass/volume] in Serum or Plasma': {"no value", "pg/mL", "picogram per milliliter"},
    'Alanine aminotransferase [Enzymatic activity/volume] in Serum or Plasma': {'percent'},
    'Albumin [Mass/volume] in Serum or Plasma': {"milligram per milliliter"},
    'Albumin/Creatinine [Mass Ratio] in Urine': {"Ratio", "ratio", "milligram per deciliter", "microgram per millimole of creatinine"},
    'Alkaline phosphatase [Enzymatic activity/volume] in Serum or Plasma': {'microgram per liter', 'percent'},
    'Anion gap 3 in Serum or Plasma': {},
    'Aspartate aminotransferase [Enzymatic activity/volume] in Serum or Plasma': {'thousand per microliter', 'Henry', 'cells per microliter', 'no value'},
    'Basophils [#/volume] in Blood': {'No matching concept', 'billion per microliter', 'calculated', 'counts', 'microliter', 'no value', 'percent', 'ul'},
    'Basophils [#/volume] in Blood by Automated count': {"percent", "Percent", "no value", "billion per microliter", "kilounit per liter", "million per microliter", "unit"},
    'Basophils/100 leukocytes in Blood': {"thousand per cubic millimeter", "thousand per microliter"},
    'Basophils/100 leukocytes in Blood by Automated count': {
        "billion per liter", "cells per microliter", "gram per liter", "microgram per liter", "milligram per deciliter", "no value", "thousand per cubic millimeter", 
        "thousand per microliter"
        },
    'Basophils/100 leukocytes in Blood by Manual count': {"cells per microliter", "per microliter", "thousand per cubic millimeter", "thousand per microliter"},
    'Bicarbonate [Moles/volume] in Serum or Plasma': {},
    'Bilirubin.total [Mass/volume] in Serum or Plasma': {},
    'Body height': {'kilogram'},
    'Body mass index (BMI) [Ratio]': {},
    'Body weight': {'No matching concept', 'centimeter', 'inch (international)'},
    'C reactive protein [Mass/volume] in Serum or Plasma': {
        "No matching concept", "mg/dL", "mg/L", "milligram per milliliter", "nanogram per milliliter", "no value", "percent", "meter"
        },
    'Calcium [Mass/volume] in Serum or Plasma': {"milliliter per minute", "milligram per 24 hours"},
    'Chloride [Moles/volume] in Serum or Plasma': {},
    'Cholesterol [Mass/volume] in Serum or Plasma': {},
    'Cholesterol in HDL [Mass/volume] in Serum or Plasma': {'calculated', 'millimole per liter', 'ratio', 'unit'},
    'Cholesterol in LDL [Mass/volume] in Serum or Plasma by calculation': {'nanometer', 'nanomole per liter', 'ratio', 'unit'},
    'Creatine kinase [Enzymatic activity/volume] in Serum or Plasma': {"mU/L", "microliter", "nL", "nanogram per milliliter", "no value", "unit"},
    'Creatinine [Mass/volume] in Serum or Plasma': {
        'milliequivalent per liter', 'milligram per 24 hours', 'milliliter per minute', 'milliliter per minute per 1.73 square meter', 'no value'
        },
    'Diastolic blood pressure': {},
    'Eosinophils [#/volume] in Blood by Automated count': {"percent", "microliter", "cubic millimeter", "kilounit per liter"},
    'Epithelial cells.squamous [#/area] in Urine sediment by Microscopy high power field': {
        '/HPF', "cells per high power field", "per low powered field", "cells per microliter", "percent"
        },
    'Erythrocyte distribution width [Entitic volume]': {'percent'},
    'Erythrocyte distribution width [Ratio] by Automated count': {"femtoliter", "microgram per liter", "million per microliter", "per microliter"},
    'Erythrocyte sedimentation rate by Westergren method': {"millimole per hour", "no value", "per hour"},
    'Erythrocytes [#/area] in Urine sediment by Microscopy high power field': {
        "/HPF", "no value", "cells", "cells per microliter", "per microliter", "per cubic millimeter", "red blood cells per high power field"
        },
    'Erythrocytes [#/volume] in Blood by Automated count': {
        "liter per minute", "microliter", "per high power field", "red blood cells per high power field", "per 100 white blood cells", "percent", "cells/uL", "cubic millimeter"
        },
    'Glomerular filtration rate/1.73 sq M.predicted [Volume Rate/Area] in Serum, Plasma or Blood by Creatinine-based formula (MDRD)': {
        "milligram per deciliter", "nanogram per milliliter", "ampere", "milligram per minute"
        },
    'Glucose [Mass/volume] in Serum or Plasma': {'gram per deciliter', 'no value', 'times'},
    'Heart rate': {},
    'Hematocrit [Volume Fraction] of Blood by Automated count': {'gram per deciliter', 'international unit per milliliter', 'liter per liter'},
    'Hemoglobin A1c/Hemoglobin.total in Blood': {'Seconds per CO', 'gram per deciliter', 'milligram per deciliter'},
    'Hemoglobin [Mass/volume] in Blood': {'femtoliter', 'million per microliter'},
    'Immature granulocytes [#/volume] in Blood': {"percent", "no value", "microliter", "unit", "x10(3)/mcL", "thousand per cubic millimeter"},
    'Immature granulocytes [#/volume] in Blood by Automated count': {"percent", "thousand per milliliter", "unit"},
    'Immature granulocytes/100 leukocytes in Blood': {'no value', 'thousand per microliter', 'unit'},
    'Immature granulocytes/100 leukocytes in Blood by Automated count': {'No matching concept', 'microliter', 'no value', 'unit', 'ul'},
    'Leukocytes [#/area] in Urine sediment by Microscopy high power field': {
        "/HPF", "cells", "cells per high power field", "cells per microliter", "per microliter", "per cubic millimeter"
        },
    'Leukocytes [#/volume] in Blood by Automated count': {"cells per microliter", "cells/uL", "million per microliter", "nanoliter", "per high power field"},
    'Lymphocytes [#/volume] in Blood by Automated count': {"Percent", "percent", "the number ten"},
    'MCH [Entitic mass] by Automated count': {"femtoliter", "million per microliter", "percent"},
    'MCHC [Mass/volume] by Automated count': {"million", "picogram"},
    'MCV [Entitic volume] by Automated count': {'gram per deciliter', 'percent'},
    'Magnesium [Mass/volume] in Serum or Plasma': {"index", "millimole per liter"},
    'Monocytes [#/volume] in Blood by Automated count': {
        "percent", "femtoliter", "kilounit per liter", "no value", "microliter", "billion per microliter", "million per microliter"
        },
    'Natriuretic peptide B [Mass/volume] in Serum or Plasma': {"per milliliter", "pg", "ng/dL"},
    'Natriuretic peptide.B prohormone N-Terminal [Mass/volume] in Serum or Plasma': {"per milliliter"},
    'Neutrophils [#/volume] in Blood by Automated count': {"percent", "Percentage unit", "femtoliter", "million per microliter", "microliter"},
    'Nucleated erythrocytes [#/volume] in Blood by Automated count': {'million', 'million per microliter', 'per 100 white blood cells', 'per hundred', 'thousand'},
    'Nucleated erythrocytes/100 leukocytes [Ratio] in Blood': {'no value', 'thousand per microliter'},
    'Nucleated erythrocytes/100 leukocytes [Ratio] in Blood by Automated count': {'counts', 'per ten billion','thousand per microliter', 'thousand per cubic millimeter'},
    'Phosphate [Mass/volume] in Serum or Plasma': {},
    'Platelet mean volume [Entitic volume] in Blood by Automated count': {"per 100 white blood cells", "thousand per microliter", "percent"},
    'Platelets [#/volume] in Blood by Automated count': {"femtoliter", "percent", "millimeter"},
    'Potassium [Moles/volume] in Serum or Plasma': {'microgram per liter', 'milligram per deciliter'},
    'Protein [Mass/volume] in Serum or Plasma': {},
    'Protein [Mass/volume] in Urine by Test strip': {'gram per deciliter', 'milligram per milliliter'},
    'Sodium [Moles/volume] in Serum or Plasma': {'international unit per milliliter', 'nanogram per deciliter'},
    'Systolic blood pressure': {},
    'Thyroxine (T4) free [Mass/volume] in Serum or Plasma': {"mg/dL", "microgram per deciliter"},
    'Triglyceride [Mass/volume] in Serum or Plasma': {'Milligram per day', 'gram per deciliter', 'millimole per liter', 'no value'},
    'Troponin I.cardiac [Mass/volume] in Serum or Plasma': {"No matching concept", "nanogram", "nanogram per deciliter", "nanogram per milligram"},
    'Urea nitrogen [Mass/volume] in Serum or Plasma': {'gram per deciliter', 'per deciliter', 'ratio'},
}


MEASUREMENT_NAMES_MAP = {
    "25-Hydroxyvitamin D3+25-Hydroxyvitamin D2 [Mass/volume] in Serum or Plasma": "vitamin_d_25oh_total",
    "Alanine aminotransferase [Enzymatic activity/volume] in Serum or Plasma": "alt",
    "Albumin [Mass/volume] in Serum or Plasma": "albumin_serum",
    "Albumin/Creatinine [Mass Ratio] in Urine": "uacr",
    "Alkaline phosphatase [Enzymatic activity/volume] in Serum or Plasma": "alp",
    "Anion gap 3 in Serum or Plasma": "anion_gap",
    "Aspartate aminotransferase [Enzymatic activity/volume] in Serum or Plasma": "ast",
    "Basophils [#/volume] in Blood": "basophils_abs",
    "Basophils [#/volume] in Blood by Automated count": "basophils_abs_auto",
    "Basophils/100 leukocytes in Blood": "basophils_pct",
    "Basophils/100 leukocytes in Blood by Automated count": "basophils_pct_auto",
    "Basophils/100 leukocytes in Blood by Manual count": "basophils_pct_manual",
    "Bicarbonate [Moles/volume] in Serum or Plasma": "bicarbonate",
    "Bilirubin.total [Mass/volume] in Serum or Plasma": "bilirubin_total",
    "Body height": "height",
    "Body mass index (BMI) [Ratio]": "bmi",
    "Body weight": "weight",
    "C reactive protein [Mass/volume] in Serum or Plasma": "crp",
    "Calcium [Mass/volume] in Serum or Plasma": "calcium",
    "Chloride [Moles/volume] in Serum or Plasma": "chloride",
    "Cholesterol [Mass/volume] in Serum or Plasma": "chol_total",
    "Cholesterol in HDL [Mass/volume] in Serum or Plasma": "hdl_c",
    "Cholesterol in LDL [Mass/volume] in Serum or Plasma by calculation": "ldl_c_calc",
    "Creatine kinase [Enzymatic activity/volume] in Serum or Plasma": "ck",
    "Creatinine [Mass/volume] in Serum or Plasma": "creatinine",
    "Diastolic blood pressure": "dbp",
    "Eosinophils [#/volume] in Blood by Automated count": "eosinophils_abs_auto",
    "Epithelial cells.squamous [#/area] in Urine sediment by Microscopy high power field": "urine_squamous_epi_hpf",
    "Erythrocyte distribution width [Entitic volume]": "rdw_sd",
    "Erythrocyte distribution width [Ratio] by Automated count": "rdw_cv_auto",
    "Erythrocyte sedimentation rate by Westergren method": "esr_westergren",
    "Erythrocytes [#/area] in Urine sediment by Microscopy high power field": "urine_rbc_hpf",
    "Erythrocytes [#/volume] in Blood by Automated count": "rbc_abs_auto",
    "Glomerular filtration rate/1.73 sq M.predicted [Volume Rate/Area] in Serum, Plasma or Blood by Creatinine-based formula (MDRD)": "egfr_mdrd",
    "Glucose [Mass/volume] in Serum or Plasma": "glucose",
    "Heart rate": "heart_rate",
    "Hematocrit [Volume Fraction] of Blood by Automated count": "hematocrit_auto",
    "Hemoglobin A1c/Hemoglobin.total in Blood": "hba1c",
    "Hemoglobin [Mass/volume] in Blood": "hemoglobin",
    "Immature granulocytes [#/volume] in Blood": "immature_granulocytes_abs",
    "Immature granulocytes [#/volume] in Blood by Automated count": "immature_granulocytes_abs_auto",
    "Immature granulocytes/100 leukocytes in Blood": "immature_granulocytes_pct",
    "Immature granulocytes/100 leukocytes in Blood by Automated count": "immature_granulocytes_pct_auto",
    "Leukocytes [#/area] in Urine sediment by Microscopy high power field": "urine_wbc_hpf",
    "Leukocytes [#/volume] in Blood by Automated count": "wbc_abs_auto",
    "Lymphocytes [#/volume] in Blood by Automated count": "lymphocytes_abs_auto",
    "MCH [Entitic mass] by Automated count": "mch_auto",
    "MCHC [Mass/volume] by Automated count": "mchc_auto",
    "MCV [Entitic volume] by Automated count": "mcv_auto",
    "Magnesium [Mass/volume] in Serum or Plasma": "magnesium",
    "Monocytes [#/volume] in Blood by Automated count": "monocytes_abs_auto",
    "Natriuretic peptide B [Mass/volume] in Serum or Plasma": "bnp",
    "Natriuretic peptide.B prohormone N-Terminal [Mass/volume] in Serum or Plasma": "ntprobnp",
    "Neutrophils [#/volume] in Blood by Automated count": "neutrophils_abs_auto",
    "Nucleated erythrocytes [#/volume] in Blood by Automated count": "nrbc_abs_auto",
    "Nucleated erythrocytes/100 leukocytes [Ratio] in Blood": "nrbc_pct",
    "Nucleated erythrocytes/100 leukocytes [Ratio] in Blood by Automated count": "nrbc_pct_auto",
    "Phosphate [Mass/volume] in Serum or Plasma": "phosphate",
    "Platelet mean volume [Entitic volume] in Blood by Automated count": "mpv_auto",
    "Platelets [#/volume] in Blood by Automated count": "platelets_abs_auto",
    "Potassium [Moles/volume] in Serum or Plasma": "potassium",
    "Protein [Mass/volume] in Serum or Plasma": "protein_total_serum",
    "Protein [Mass/volume] in Urine by Test strip": "urine_protein_dipstick",
    "Sodium [Moles/volume] in Serum or Plasma": "sodium",
    "Systolic blood pressure": "sbp",
    "Thyroxine (T4) free [Mass/volume] in Serum or Plasma": "free_t4",
    "Triglyceride [Mass/volume] in Serum or Plasma": "triglycerides",
    "Troponin I.cardiac [Mass/volume] in Serum or Plasma": "troponin_i",
    "Urea nitrogen [Mass/volume] in Serum or Plasma": "bun",
}


