import re
import math
import gcsfs
import numpy as np
import pandas as pd
from tqdm.auto import tqdm

from biobanking.utils.config import AllofUs

MASK_ID_PATTERN = re.compile(
    r"(?P<gene>.+)\.(?P<mask>pLoF_strict|pLoF_lenient)\.(?P<aaf_bin>0\.01|0\.001|singleton)"
)

_PLINK_BED_MAGIC = b"\x6c\x1b\x01"


class CarrierCounter(AllofUs):

    def __init__(self):
        super().__init__()
        self.carriers_base = f"{self.bucket}/data/annotations/carriers"

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _mask_gcs_paths(self, burden_type: str, chrm: int | str) -> dict[str, str]:
        prefix = f"data/associations/masks/{burden_type}/chr{chrm}/"
        files = self.list_gcs_files(prefix)
        paths = {}
        for f in files:
            if f.endswith(".bed"):
                paths["bed"] = f
            elif f.endswith(".bim"):
                paths["bim"] = f
            elif f.endswith(".fam"):
                paths["fam"] = f
        return paths

    def _read_bim(self, gcs_path: str) -> pd.DataFrame:
        fs = gcsfs.GCSFileSystem()
        with fs.open(gcs_path, "rt") as f:
            return pd.read_csv(
                f, sep="\t", header=None,
                names=["chrom", "snp", "cm", "pos", "a1", "a2"]
            )

    def _read_fam(self, gcs_path: str) -> pd.DataFrame:
        fs = gcsfs.GCSFileSystem()
        with fs.open(gcs_path, "rt") as f:
            return pd.read_csv(
                f, sep=r"\s+", header=None, engine="python",
                names=["fid", "iid", "father", "mother", "sex", "pheno"]
            )

    def _extract_carriers(
        self, bed_gcs_path: str, bim: pd.DataFrame, fam: pd.DataFrame
    ) -> pd.DataFrame:
        """
        Parse a PLINK variant-major BED from GCS and return a long-format
        DataFrame of (gene, mask_type, aaf_bin, sample_id) for every carrier.

        PLINK BED 2-bit encoding per sample within each variant row:
          00 = hom-ref   (dosage 0) — not a carrier
          01 = missing              — not a carrier
          10 = het       (dosage 1) — carrier
          11 = hom-alt   (dosage 2) — carrier
        Carrier check: the high bit of each pair (bits[:, 1]) equals 1.
        """
        n_samples = len(fam)
        n_variants = len(bim)
        bytes_per_var = math.ceil(n_samples / 4)
        sample_ids = fam["iid"].values

        fs = gcsfs.GCSFileSystem()
        with fs.open(bed_gcs_path, "rb") as f:
            raw = np.frombuffer(f.read(), dtype=np.uint8)

        if bytes(raw[:3]) != _PLINK_BED_MAGIC:
            raise ValueError(f"Not a valid PLINK variant-major BED file: {bed_gcs_path}")

        # Shape: (n_variants, bytes_per_var) — one row per gene mask
        bed = raw[3:].reshape(n_variants, bytes_per_var)

        records = []
        for vi in range(n_variants):
            snp_id = bim["snp"].iat[vi]
            m = MASK_ID_PATTERN.match(str(snp_id))
            if m is None:
                continue

            # Unpack bits LSB-first, trim padding, reshape to (n_samples, 2)
            bits = (
                np.unpackbits(bed[vi], bitorder="little")
                [: n_samples * 2]
                .reshape(n_samples, 2)
            )
            carrier_ids = sample_ids[bits[:, 1].astype(bool)]

            gene = m.group("gene")
            mask_type = m.group("mask")
            aaf_bin = m.group("aaf_bin")
            for sid in carrier_ids:
                records.append((gene, mask_type, aaf_bin, sid))

        return pd.DataFrame(records, columns=["gene", "mask_type", "aaf_bin", "sample_id"])

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def compute_carriers_for_chrm(
        self,
        chrm: int | str,
        burden_type: str = "plof",
        overwrite: bool = False,
    ) -> pd.DataFrame:
        """Compute carrier table for one chromosome and save to GCS as parquet."""
        out_path = f"{self.carriers_base}/{burden_type}/chr{chrm}_carriers.parquet"

        if not overwrite:
            fs = gcsfs.GCSFileSystem()
            if fs.exists(out_path):
                return pd.read_parquet(out_path)

        gcs_paths = self._mask_gcs_paths(burden_type, chrm)
        missing = [ext for ext in ("bed", "bim", "fam") if ext not in gcs_paths]
        if missing:
            raise FileNotFoundError(
                f"Missing mask files for chr{chrm} ({burden_type}): {missing}"
            )

        bim = self._read_bim(gcs_paths["bim"])
        fam = self._read_fam(gcs_paths["fam"])
        df = self._extract_carriers(gcs_paths["bed"], bim, fam)

        df.to_parquet(out_path, index=False)
        print(f"chr{chrm}: {df['gene'].nunique()} genes, {len(df)} carrier records → {out_path}")
        return df

    def compute_all_carriers(
        self,
        burden_type: str = "plof",
        chrs: list[int] | None = None,
        overwrite: bool = False,
    ) -> pd.DataFrame:
        """Compute and save carrier tables for all chromosomes."""
        if chrs is None:
            chrs = list(range(1, 23))
        frames = []
        for chrm in tqdm(chrs, desc="Processing chromosomes"):
            try:
                frames.append(
                    self.compute_carriers_for_chrm(chrm, burden_type=burden_type, overwrite=overwrite)
                )
            except FileNotFoundError as e:
                print(f"Warning: {e}")
        return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame(
            columns=["gene", "mask_type", "aaf_bin", "sample_id"]
        )

    def load_carriers(
        self,
        burden_type: str = "plof",
        chrs: list[int] | None = None,
        genes: list[str] | None = None,
    ) -> pd.DataFrame:
        """Load pre-computed carrier parquet files from GCS."""
        if chrs is None:
            chrs = list(range(1, 23))
        frames = []
        for chrm in chrs:
            path = f"{self.carriers_base}/{burden_type}/chr{chrm}_carriers.parquet"
            try:
                df = pd.read_parquet(path)
                if genes is not None:
                    df = df[df["gene"].isin(genes)]
                frames.append(df)
            except Exception:
                pass
        return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame(
            columns=["gene", "mask_type", "aaf_bin", "sample_id"]
        )

    def count_carriers(
        self,
        burden_type: str = "plof",
        chrs: list[int] | None = None,
        genes: list[str] | None = None,
    ) -> pd.DataFrame:
        """Return carrier counts per (gene, mask_type, aaf_bin) from saved files."""
        df = self.load_carriers(burden_type=burden_type, chrs=chrs, genes=genes)
        if df.empty:
            return df
        return (
            df.groupby(["gene", "mask_type", "aaf_bin"])
            .size()
            .reset_index(name="n_carriers")
            .sort_values(["gene", "mask_type", "aaf_bin"])
            .reset_index(drop=True)
        )
