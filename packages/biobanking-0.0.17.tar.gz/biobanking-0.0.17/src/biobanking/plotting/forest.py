from pathlib import Path
import re
import textwrap
from typing import Iterable

import matplotlib.pyplot as plt
from matplotlib import transforms
import numpy as np
import pandas as pd


PathLike = str | Path


def _as_list(value: str | Iterable[str] | None) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        return [value]
    return list(value)


def _load_csv_results(data: pd.DataFrame | PathLike | Iterable[PathLike]) -> pd.DataFrame:
    if isinstance(data, pd.DataFrame):
        return data.copy()

    if isinstance(data, (str, Path)):
        paths = [data]
    else:
        paths = list(data)

    if not paths:
        raise ValueError("No burden result files were provided.")

    frames = []
    for path in paths:
        path = Path(path)
        suffixes = path.suffixes
        if suffixes[-2:] != [".csv", ".gz"] and suffixes[-1:] != [".csv"]:
            raise ValueError(f"Burden forest plots currently support CSV inputs only: {path}")
        frames.append(pd.read_csv(path))

    if not frames:
        raise ValueError("No burden result rows could be loaded.")
    return pd.concat(frames, ignore_index=True)


def _format_pvalue(pvalue: float) -> str:
    if pd.isna(pvalue):
        return "NA"
    if pvalue == 0:
        return r"$0.00 \times 10^{0}$"
    coeff, exp = f"{pvalue:.2e}".split("e")
    return rf"${coeff} \times 10^{{{int(exp)}}}$"


def _format_effect_ci(effect: float, ci_low: float, ci_high: float) -> str:
    if pd.isna(effect) or pd.isna(ci_low) or pd.isna(ci_high):
        return "NA"
    return f"{effect:.2f} ({ci_low:.2f}, {ci_high:.2f})"


def _format_pheno_label(value: object, wrap_width: int = 20, max_length: int = 40) -> tuple[str, int]:
    text = re.sub(r"_+", " ", str(value)).strip()
    if len(text) > max_length:
        text = text[: max_length - 3].rstrip() + "..."
    if len(text) <= wrap_width:
        return text, 9
    wrapped = textwrap.wrap(
        text,
        width=wrap_width,
        max_lines=2,
        placeholder="...",
        break_long_words=True,
        break_on_hyphens=False,
    )
    return "\n".join(wrapped), 8


def _resolve_first_present_column(df: pd.DataFrame, candidates: Iterable[str], label: str) -> str:
    for candidate in candidates:
        if candidate in df.columns:
            return candidate
    raise ValueError(f"Could not find a column for {label}. Tried: {list(candidates)}")


def _describe_interaction_test(test: str, anchor_label: str = "anchor", target_label: str = "target") -> str:
    if pd.isna(test):
        return "Unknown interaction term"
    if test == "ADD":
        return f"Marginal additive effect of {target_label}"
    if test == "ADD-CONDTL":
        return f"Conditional main effect of {target_label}"
    if test == "ADD-INT_SNP":
        return f"Main effect :: {target_label}"
    if test.startswith("ADD-INT_SNPx"):
        return "Interaction Effect"
    if re.fullmatch(r"ADD-INT_\d+DF", str(test)):
        return "Joint Effect"
    if str(test).startswith("ADD-INT_"):
        return f"Main effect :: {anchor_label}"
    return str(test)


def _interaction_test_category(test: str) -> str:
    test = str(test)
    if test == "ADD-INT_SNP":
        return "target_main"
    if test.startswith("ADD-INT_SNPx"):
        return "interaction"
    if re.fullmatch(r"ADD-INT_\d+DF", test):
        return "joint"
    if test.startswith("ADD-INT_"):
        return "anchor_main"
    if test == "ADD-CONDTL":
        return "conditional_main"
    if test == "ADD":
        return "marginal"
    return "other"


def plot_burden_forest(
    data: pd.DataFrame | PathLike | Iterable[PathLike],
    gene: str | Iterable[str] | None = None,
    pheno: str | Iterable[str] | None = None,
    top_n: int | None = None,
    pvalue_threshold: float = 0.05,
    gene_col: str = "gene",
    pheno_col: str = "pheno",
    effect_col: str = "beta",
    se_col: str = "se",
    pvalue_col: str = "pvalue",
    mask_col: str = "mask",
    aaf_bin_col: str = "aaf_bin",
    test_col: str = "test",
    test: str | None = "ADD",
    mask: str | None = "best",
    aaf_bin: str | None = None,
    ci_z: float = 1.96,
    figsize: tuple[float, float] | None = None,
    title: str | None = None,
    xlabel: str = "Effect size",
    point_color: str = "#1f5aa6",
    error_color: str = "#4a4a4a",
    reference_line_color: str = "#999999",
    alternate_row_color: str = "#f5f5f5",
    ax=None,
):
    """Create a generalized forest plot for burden association CSV results.

    Mode is inferred from ``gene`` and ``pheno``:
    - single phenotype: ``pheno`` is a single string and ``gene`` is None
    - single gene: ``gene`` is a single string and ``pheno`` is None
    - multi mode: any case where at least one of ``gene`` or ``pheno`` contains multiple values,
      or both are provided together

    In multi mode, rows are filtered by the supplied gene/pheno lists independently, then shown
    as gene | phenotype labels.

    By default, ``mask="best"`` keeps the single most significant row for each unique
    gene/phenotype pair after all other filters are applied.
    """
    df = _load_csv_results(data)

    required = [gene_col, pheno_col, effect_col, se_col, pvalue_col]
    missing = [col for col in required if col not in df.columns]
    if missing:
        raise ValueError(f"Missing required burden result columns: {missing}")

    genes = _as_list(gene)
    phenos = _as_list(pheno)

    work_df = df.copy()

    if test is not None:
        if test_col not in work_df.columns:
            raise ValueError(f"Column '{test_col}' is required when test filtering is used.")
        work_df = work_df.loc[work_df[test_col] == test].copy()

    if mask not in {None, "best"}:
        if mask_col not in work_df.columns:
            raise ValueError(f"Column '{mask_col}' is required when mask filtering is used.")
        work_df = work_df.loc[work_df[mask_col] == mask].copy()

    if aaf_bin is not None:
        if aaf_bin_col not in work_df.columns:
            raise ValueError(f"Column '{aaf_bin_col}' is required when aaf_bin filtering is used.")
        work_df = work_df.loc[work_df[aaf_bin_col] == aaf_bin].copy()

    if pvalue_threshold is not None:
        work_df = work_df.loc[work_df[pvalue_col] <= pvalue_threshold].copy()

    if genes:
        work_df = work_df.loc[work_df[gene_col].isin(genes)].copy()
    if phenos:
        work_df = work_df.loc[work_df[pheno_col].isin(phenos)].copy()

    if mask == "best":
        work_df = (
            work_df.sort_values([pvalue_col, effect_col], ascending=[True, False])
            .drop_duplicates(subset=[gene_col, pheno_col], keep="first")
            .copy()
        )

    single_gene_mode = len(genes) == 1 and not phenos
    single_pheno_mode = len(phenos) == 1 and not genes
    multi_mode = not single_gene_mode and not single_pheno_mode

    if work_df.empty:
        raise ValueError("No burden rows remain after filtering.")

    if single_pheno_mode:
        selected = work_df.sort_values([pvalue_col, effect_col], ascending=[True, False]).copy()
        selected["forest_label"] = selected[gene_col].astype(str)
        label_header = "Gene"
        if title is None:
            title = f"Top burden associations for {phenos[0]}"
    elif single_gene_mode:
        selected = work_df.sort_values([pvalue_col, effect_col], ascending=[True, False]).copy()
        selected["forest_label"] = selected[pheno_col].astype(str)
        label_header = "Phenotype"
        if title is None:
            title = f"Top phenotypes for {genes[0]}"
    else:
        selected = work_df.sort_values([gene_col, pheno_col, pvalue_col, effect_col], ascending=[True, True, True, False]).copy()
        selected["forest_label"] = selected[gene_col].astype(str) + " | " + selected[pheno_col].astype(str)
        label_header = "Gene | Phenotype"
        if title is None:
            title = "Selected burden associations"

    if top_n is not None:
        selected = selected.head(top_n).copy()

    if selected.empty:
        raise ValueError("No burden rows remain after applying top_n.")

    selected["ci_low"] = selected[effect_col] - ci_z * selected[se_col]
    selected["ci_high"] = selected[effect_col] + ci_z * selected[se_col]
    selected["pvalue_fmt"] = selected[pvalue_col].map(_format_pvalue)
    selected["effect_fmt"] = selected.apply(
        lambda row: f"{row[effect_col]:.2f} ({row['ci_low']:.2f}, {row['ci_high']:.2f})",
        axis=1,
    )
    selected = selected.sort_values(effect_col, ascending=False).reset_index(drop=True)

    n_rows = len(selected)
    if figsize is None:
        row_height = 0.6 if not single_pheno_mode else 0.5
        figsize = (7, min(6, max(2.5, n_rows * row_height)))

    created_fig = False
    if ax is None:
        fig, ax = plt.subplots(figsize=figsize)
        created_fig = True
    else:
        fig = ax.figure

    y = np.arange(n_rows)
    xerr = np.vstack([
        selected[effect_col] - selected["ci_low"],
        selected["ci_high"] - selected[effect_col],
    ])

    for idx in range(n_rows):
        if idx % 2 == 1:
            ax.axhspan(idx - 0.5, idx + 0.5, color=alternate_row_color, zorder=0)

    ax.errorbar(
        selected[effect_col],
        y,
        xerr=xerr,
        fmt="o",
        color=point_color,
        ecolor=error_color,
        elinewidth=1.6,
        capsize=3,
        markersize=6,
        zorder=3,
    )
    ax.axvline(0, color=reference_line_color, linestyle="--", linewidth=1)

    ax.set_yticks(y)
    ax.set_yticklabels([""] * n_rows)
    ax.tick_params(axis="y", length=0)
    ax.set_xlabel(xlabel)
    ax.set_ylabel("")
    ax.set_title(title)
    ax.set_ylim(n_rows - 0.5, -1.2)

    x_min = min(selected["ci_low"].min(), 0)
    x_max = max(selected["ci_high"].max(), 0)
    x_pad = max((x_max - x_min) * 0.12, 0.2)
    ax.set_xlim(x_min - x_pad, x_max + x_pad)

    row_transform = transforms.blended_transform_factory(ax.transAxes, ax.transData)
    header_y = -0.9

    if multi_mode:
        table_columns = [("Gene", -0.46, gene_col), ("Phenotype", -0.22, pheno_col)]
        left_margin = 0.38
    elif single_pheno_mode:
        table_columns = [(label_header, -0.28, gene_col)]
        left_margin = 0.24
    else:
        table_columns = [(label_header, -0.28, pheno_col)]
        left_margin = 0.24

    for header, xpos, col in table_columns:
        ax.text(
            xpos,
            header_y,
            header,
            transform=row_transform,
            fontsize=9,
            fontweight="bold",
            ha="left",
            va="center",
            clip_on=False,
        )
        for idx, row in selected.iterrows():
            value = str(row[col])
            fontsize = 9
            if col == pheno_col:
                value, fontsize = _format_pheno_label(row[col])
            ax.text(
                xpos,
                idx,
                value,
                transform=row_transform,
                fontsize=fontsize,
                ha="left",
                va="center",
                linespacing=0.95,
                clip_on=False,
            )

    effect_x = 1.03
    pvalue_x = 1.38
    ax.text(
        effect_x,
        header_y,
        "Effect (95% CI)",
        transform=row_transform,
        fontsize=9,
        fontweight="bold",
        ha="left",
        va="center",
        clip_on=False,
    )
    ax.text(
        pvalue_x,
        header_y,
        "p-value",
        transform=row_transform,
        fontsize=9,
        fontweight="bold",
        ha="left",
        va="center",
        clip_on=False,
    )
    for idx, row in selected.iterrows():
        ax.text(
            effect_x,
            idx,
            row["effect_fmt"],
            transform=row_transform,
            fontsize=9,
            ha="left",
            va="center",
            clip_on=False,
        )
        ax.text(
            pvalue_x,
            idx,
            row["pvalue_fmt"],
            transform=row_transform,
            fontsize=9,
            ha="left",
            va="center",
            clip_on=False,
        )

    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_visible(False)
    ax.grid(axis="x", color="#dddddd", linewidth=0.8, alpha=0.8)

    if created_fig:
        fig.subplots_adjust(left=left_margin, right=0.68, top=0.90, bottom=0.12)
        fig.tight_layout()

    return fig, ax, selected


def plot_interaction_forest(
    data: pd.DataFrame | PathLike | Iterable[PathLike],
    anchor_gene: str,
    target_gene: str,
    pheno: str | Iterable[str] | None = None,
    run_label: str | None = None,
    include_tests: Iterable[str] | None = None,
    exclude_tests: Iterable[str] = ("ADD", "ADD-CONDTL"),
    pvalue_threshold: float | None = 0.05,
    threshold_categories: Iterable[str] | None = ("interaction", "joint"),
    gene_col: str = "gene",
    pheno_col: str = "pheno",
    run_label_col: str = "run_label",
    test_col: str = "test",
    effect_col: str = "BETA",
    se_col: str = "SE",
    pvalue_col: str = "pvalue",
    ci_z: float = 1.96,
    figsize: tuple[float, float] | None = None,
    title: str | None = None,
    xlabel: str = "Effect size",
    point_color: str = "#1f5aa6",
    error_color: str = "#4a4a4a",
    reference_line_color: str = "#999999",
    alternate_row_color: str = "#f5f5f5",
    ax=None,
):
    """Create an interaction forest plot for one anchor/target gene pair.

    Rows correspond to REGENIE interaction-model terms. By default, plain marginal
    ``ADD`` and ``ADD-CONDTL`` rows are excluded so the plot emphasizes the
    interaction-model outputs. When ``pheno`` is omitted, phenotypes are filtered
    by ``pvalue_threshold`` using only the selected threshold-driving interaction
    test categories per phenotype, and each selected phenotype is shown as a
    grouped block of term rows.
    """
    df = _load_csv_results(data)

    required = [gene_col, pheno_col, test_col, pvalue_col]
    missing = [col for col in required if col not in df.columns]
    if missing:
        raise ValueError(f"Missing required interaction result columns: {missing}")

    work_df = df.copy()
    effect_col = _resolve_first_present_column(work_df, [effect_col, effect_col.lower(), effect_col.upper(), "beta", "BETA"], "effect size")
    se_col = _resolve_first_present_column(work_df, [se_col, se_col.lower(), se_col.upper(), "se", "SE"], "standard error")
    work_df = work_df.loc[work_df[gene_col] == target_gene].copy()
    phenos = _as_list(pheno)
    if phenos:
        work_df = work_df.loc[work_df[pheno_col].isin(phenos)].copy()

    if run_label is not None:
        if run_label_col not in work_df.columns:
            raise ValueError(f"Column '{run_label_col}' is required when run_label filtering is used.")
        work_df = work_df.loc[work_df[run_label_col] == run_label].copy()

    if include_tests is not None:
        include_tests = set(include_tests)
        work_df = work_df.loc[work_df[test_col].isin(include_tests)].copy()
    else:
        exclude_tests = set(exclude_tests)
        work_df = work_df.loc[~work_df[test_col].isin(exclude_tests)].copy()

    if work_df.empty:
        raise ValueError("No interaction rows remain after filtering.")

    work_df["term"] = work_df[test_col].map(lambda value: _describe_interaction_test(value, anchor_gene, target_gene))
    work_df["test_category"] = work_df[test_col].map(_interaction_test_category)

    if phenos:
        work_df = work_df.sort_values([pheno_col, pvalue_col, test_col]).drop_duplicates(subset=[pheno_col, test_col], keep="first").copy()
    else:
        if pvalue_threshold is None:
            raise ValueError("pvalue_threshold is required when pheno is not specified.")
        threshold_categories = tuple(threshold_categories) if threshold_categories is not None else ("interaction", "joint")
        threshold_df = work_df.loc[
            work_df["test_category"].isin(threshold_categories)
        ].copy()
        if threshold_df.empty:
            raise ValueError("No threshold-driving interaction rows are available for phenotype filtering.")
        pheno_hits = (
            threshold_df.groupby(pheno_col, sort=False)[pvalue_col]
            .min()
            .loc[lambda ser: ser <= pvalue_threshold]
            .sort_values()
        )
        if pheno_hits.empty:
            raise ValueError("No phenotypes remain after applying the interaction-term p-value threshold.")
        work_df = work_df.loc[work_df[pheno_col].isin(pheno_hits.index)].copy()
        work_df = work_df.sort_values([pheno_col, pvalue_col, test_col]).drop_duplicates(subset=[pheno_col, test_col], keep="first").copy()

    work_df[effect_col] = pd.to_numeric(work_df[effect_col], errors="coerce")
    work_df[se_col] = pd.to_numeric(work_df[se_col], errors="coerce")
    work_df["ci_low"] = work_df[effect_col] - ci_z * work_df[se_col]
    work_df["ci_high"] = work_df[effect_col] + ci_z * work_df[se_col]

    work_df["effect_fmt"] = work_df.apply(
        lambda row: _format_effect_ci(
            row.get(effect_col, np.nan),
            row["ci_low"],
            row["ci_high"],
        ),
        axis=1,
    )
    work_df["pvalue_fmt"] = work_df[pvalue_col].map(_format_pvalue)

    term_order = {
        f"Main effect :: {target_gene}": 0,
        f"Main effect :: {anchor_gene}": 1,
        "Interaction Effect": 2,
        "Joint Effect": 3,
    }
    pheno_order_map = None
    if not phenos:
        pheno_order_map = {str(name): idx for idx, name in enumerate(pheno_hits.index)}
    selected = (
        work_df.assign(
            _pheno_order=work_df[pheno_col].astype(str).map(lambda value: pheno_order_map.get(value, 0) if pheno_order_map is not None else 0),
            _term_order=work_df["term"].map(lambda value: term_order.get(value, 99)),
            _joint_df=work_df[test_col].map(
                lambda value: int(re.search(r"(\d+)DF", str(value)).group(1))
                if re.fullmatch(r"ADD-INT_\d+DF", str(value))
                else 0
            ),
        )
        .sort_values(["_pheno_order", pheno_col, "_term_order", "_joint_df", pvalue_col, test_col])
        .reset_index(drop=True)
    )

    n_rows = len(selected)
    if figsize is None:
        row_height = 0.6 if not (phenos and len(phenos) == 1) else 0.5
        figsize = (7, min(6, max(2.5, n_rows * row_height)))

    created_fig = False
    if ax is None:
        fig, ax = plt.subplots(figsize=figsize)
        created_fig = True
    else:
        fig = ax.figure

    pheno_labels = selected[pheno_col].astype(str).tolist()
    y_positions: list[float] = []
    curr_y = 0.0
    prev_pheno = None
    for pheno_name in pheno_labels:
        if prev_pheno is not None and pheno_name != prev_pheno:
            curr_y += 0.35
        y_positions.append(curr_y)
        curr_y += 1.0
        prev_pheno = pheno_name
    y = np.array(y_positions)
    valid_effects = selected[effect_col].notna() & selected["ci_low"].notna() & selected["ci_high"].notna()

    for idx, ypos in enumerate(y):
        if idx % 2 == 1:
            ax.axhspan(ypos - 0.5, ypos + 0.5, color=alternate_row_color, zorder=0)

    if valid_effects.any():
        valid = selected.loc[valid_effects].copy()
        valid_y = y[valid_effects.to_numpy()]
        xerr = np.vstack([
            valid[effect_col] - valid["ci_low"],
            valid["ci_high"] - valid[effect_col],
        ])
        ax.errorbar(
            valid[effect_col],
            valid_y,
            xerr=xerr,
            fmt="o",
            color=point_color,
            ecolor=error_color,
            elinewidth=1.6,
            capsize=3,
            markersize=6,
            zorder=3,
        )
        x_min = min(valid["ci_low"].min(), 0)
        x_max = max(valid["ci_high"].max(), 0)
    else:
        x_min, x_max = -1.0, 1.0

    ax.axvline(0, color=reference_line_color, linestyle="--", linewidth=1)
    ax.set_yticks(y)
    ax.set_yticklabels([""] * n_rows)
    ax.tick_params(axis="y", length=0)
    ax.set_xlabel(xlabel)
    ax.set_ylabel("")
    if title is None:
        if phenos and len(phenos) == 1:
            title = f"Interaction terms for {anchor_gene} x {target_gene} on {phenos[0]}"
        elif phenos:
            title = f"Interaction terms for {anchor_gene} x {target_gene}"
        else:
            title = f"Interaction terms for {anchor_gene} x {target_gene} across phenotypes"
    ax.set_title(title)
    ax.set_ylim(y[-1] + 0.5, -1.2)

    x_pad = max((x_max - x_min) * 0.12, 0.2)
    ax.set_xlim(x_min - x_pad, x_max + x_pad)

    row_transform = transforms.blended_transform_factory(ax.transAxes, ax.transData)
    header_y = -0.9

    if phenos and len(phenos) == 1:
        table_columns = [("Term", -0.36, "term")]
        left_margin = 0.34
    else:
        table_columns = [("Phenotype", -0.58, pheno_col), ("Term", -0.24, "term")]
        left_margin = 0.46
    for header, xpos, col in table_columns:
        ax.text(
            xpos,
            header_y,
            header,
            transform=row_transform,
            fontsize=9,
            fontweight="bold",
            ha="left",
            va="center",
            clip_on=False,
        )
        previous_value = None
        for idx, row in selected.iterrows():
            value = str(row[col])
            fontsize = 9
            if col == pheno_col and previous_value == value:
                value = ""
            elif col == pheno_col:
                value, fontsize = _format_pheno_label(row[col])
            ax.text(
                xpos,
                y[idx],
                value,
                transform=row_transform,
                fontsize=fontsize,
                ha="left",
                va="center",
                linespacing=0.95,
                clip_on=False,
            )
            previous_value = str(row[col])

    effect_x = 1.03
    pvalue_x = 1.38
    ax.text(
        effect_x,
        header_y,
        "Effect (95% CI)",
        transform=row_transform,
        fontsize=9,
        fontweight="bold",
        ha="left",
        va="center",
        clip_on=False,
    )
    ax.text(
        pvalue_x,
        header_y,
        "p-value",
        transform=row_transform,
        fontsize=9,
        fontweight="bold",
        ha="left",
        va="center",
        clip_on=False,
    )
    for idx, row in selected.iterrows():
        ax.text(
            effect_x,
            y[idx],
            row["effect_fmt"],
            transform=row_transform,
            fontsize=9,
            ha="left",
            va="center",
            clip_on=False,
        )
        ax.text(
            pvalue_x,
            y[idx],
            row["pvalue_fmt"],
            transform=row_transform,
            fontsize=9,
            ha="left",
            va="center",
            clip_on=False,
        )

    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_visible(False)
    ax.grid(axis="x", color="#dddddd", linewidth=0.8, alpha=0.8)

    if created_fig:
        fig.subplots_adjust(left=left_margin, right=0.68, top=0.90, bottom=0.12)
        fig.tight_layout()

    return fig, ax, selected.drop(columns=["_pheno_order", "_term_order", "_joint_df"])
