from __future__ import annotations

"""
Module-level global runtime state for execsql.

All mutable singletons and global variables that need to be shared across
the entire codebase are declared here.  Other modules do::

    import execsql.state as _state

and then access attributes (``_state.conf``, ``_state.subvars``, etc.)
inside function/method bodies — never at class-definition time — to avoid
circular-import issues at load time.

Internally, all mutable state lives on a :class:`RuntimeContext` instance
stored in a :class:`threading.local` so that each thread has its own
isolated context.  The module's ``__class__`` is swapped to a custom
:class:`types.ModuleType` subclass that transparently proxies attribute
reads and writes to the active thread's context via :func:`_get_ctx`.

- External code continues to use ``_state.conf``, ``_state.subvars = ...``,
  etc. with zero changes.
- Functions *within* this module use ``_get_ctx()`` to obtain the active
  context, ensuring thread-safe access.

Use :func:`get_context` / :func:`set_context` to obtain or replace the
active context programmatically.
"""

import re
import sys
import threading
import types
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    import multiprocessing as _mp

    from execsql.config import ConfigData, StatObj, WriteHooks
    from execsql.db.base import DatabasePool
    from execsql.exporters.base import ExportMetadata, WriteSpec
    from execsql.script import (
        CommandList,
        CounterVars,
        IfLevels,
        MetaCommandList,
        ScriptCmd,
        ScriptExecSpec,
        SubVarSet,
    )
    from execsql.utils.fileio import FileWriter, Logger, TempFileMgr
    from execsql.utils.mail import MailSpec
    from execsql.utils.timer import Timer

__all__ = [
    # Configuration / encoding
    "conf",
    "logfile_encoding",
    # Runtime state
    "last_command",
    "upass",
    "varlike",
    "err_halt_writespec",
    "err_halt_email",
    "err_halt_exec",
    "cancel_halt_writespec",
    "cancel_halt_mailspec",
    "cancel_halt_exec",
    "commandliststack",
    "savedscripts",
    "loopcommandstack",
    "compiling_loop",
    "endloop_rx",
    "loop_rx",
    "loop_nest_level",
    "cmds_run",
    "defer_rx",
    "stringtypes",
    "exec_log",
    "subvars",
    "status",
    # Lazy singletons
    "if_stack",
    "counters",
    "timer",
    "output",
    "dbs",
    "tempfiles",
    "export_metadata",
    "metacommandlist",
    "conditionallist",
    "filewriter",
    "gui_console",
    "gui_manager_queue",
    "gui_manager_thread",
    # Profiling
    "profile_data",
    # Debug REPL
    "step_mode",
    # Version
    "primary_vno",
    "secondary_vno",
    "tertiary_vno",
    # Functions
    "xcmd_test",
    "endloop",
    "reset",
    "initialize",
    # New public API
    "RuntimeContext",
    "get_context",
    "set_context",
    "active_context",
]

# ---------------------------------------------------------------------------
# Compile-time constants — immutable after module load, stay in __dict__
# ---------------------------------------------------------------------------

# A compiled regex to match prefixed regular expressions, used to check
# for unsubstituted variables.
varlike = re.compile(r"!![$@&~#]?\w+!!", re.I)

# Compiled regex for END LOOP metacommand, which is immediate.
endloop_rx = re.compile(r"^\s*END\s+LOOP\s*$", re.I)

# Compiled regex for *start of* LOOP metacommand, for testing while compiling
# commands within a loop.
loop_rx = re.compile(r"\s*LOOP\s+", re.I)

# Pattern for deferred substitution, e.g.: "!{somevar}!"
defer_rx = re.compile(r"(!{([$@&~#]?[a-z0-9_]+)}!)", re.I)

# The string type (str in Python 3).
stringtypes: type = str

# ---------------------------------------------------------------------------
# Version numbers (parsed from package __version__)
# ---------------------------------------------------------------------------

try:
    from execsql import __version__ as _pkg_version

    _vparts = _pkg_version.split(".")
    primary_vno: int = int(_vparts[0]) if len(_vparts) > 0 else 0
    secondary_vno: int = int(_vparts[1]) if len(_vparts) > 1 else 0
    tertiary_vno: int = int(_vparts[2]) if len(_vparts) > 2 else 0
except (ImportError, ValueError, IndexError):
    primary_vno = 0
    secondary_vno = 0
    tertiary_vno = 0


# ---------------------------------------------------------------------------
# RuntimeContext — holds all mutable state for a single execsql session
# ---------------------------------------------------------------------------

_CONTEXT_ATTRS: frozenset[str] = frozenset(
    {
        # Configuration
        "conf",
        "logfile_encoding",
        # Runtime flags
        "last_command",
        "upass",
        "err_halt_writespec",
        "err_halt_email",
        "err_halt_exec",
        "cancel_halt_writespec",
        "cancel_halt_mailspec",
        "cancel_halt_exec",
        # Execution stack
        "commandliststack",
        "savedscripts",
        "loopcommandstack",
        "compiling_loop",
        "loop_nest_level",
        "cmds_run",
        # I/O
        "exec_log",
        "subvars",
        "status",
        "output",
        "filewriter",
        # Lazy singletons
        "if_stack",
        "counters",
        "timer",
        "dbs",
        "tempfiles",
        "export_metadata",
        "metacommandlist",
        "conditionallist",
        # GUI
        "gui_console",
        "gui_manager_queue",
        "gui_manager_thread",
        # Profiling
        "profile_data",
        # Debug REPL
        "step_mode",
        # AST executor
        "ast_scripts",
        "include_chain",
    },
)


class RuntimeContext:
    """All mutable runtime state for a single execsql execution session.

    A fresh instance provides clean default values identical to the original
    module-level declarations.  Use :func:`get_context` to obtain the active
    instance, or :func:`set_context` to replace it.
    """

    __slots__ = (
        # Configuration
        "conf",
        "logfile_encoding",
        # Runtime flags
        "last_command",
        "upass",
        "err_halt_writespec",
        "err_halt_email",
        "err_halt_exec",
        "cancel_halt_writespec",
        "cancel_halt_mailspec",
        "cancel_halt_exec",
        # Execution stack
        "commandliststack",
        "savedscripts",
        "loopcommandstack",
        "compiling_loop",
        "loop_nest_level",
        "cmds_run",
        # I/O
        "exec_log",
        "subvars",
        "status",
        "output",
        "filewriter",
        # Lazy singletons
        "if_stack",
        "counters",
        "timer",
        "dbs",
        "tempfiles",
        "export_metadata",
        "metacommandlist",
        "conditionallist",
        # GUI
        "gui_console",
        "gui_manager_queue",
        "gui_manager_thread",
        # Profiling
        "profile_data",
        # Debug REPL
        "step_mode",
        # AST executor
        "ast_scripts",
        "include_chain",
    )

    def __init__(self) -> None:
        # Configuration
        self.conf: ConfigData | None = None
        self.logfile_encoding: str = "utf8"

        # Runtime flags
        self.last_command: ScriptCmd | None = None
        self.upass: str | None = None
        self.err_halt_writespec: WriteSpec | None = None
        self.err_halt_email: MailSpec | None = None
        self.err_halt_exec: ScriptExecSpec | None = None
        self.cancel_halt_writespec: WriteSpec | None = None
        self.cancel_halt_mailspec: MailSpec | None = None
        self.cancel_halt_exec: ScriptExecSpec | None = None

        # Execution stack
        self.commandliststack: list[CommandList] = []
        self.savedscripts: dict[str, CommandList] = {}
        self.loopcommandstack: list[CommandList] = []
        self.compiling_loop: bool = False
        self.loop_nest_level: int = 0
        self.cmds_run: int = 0

        # I/O
        self.exec_log: Logger | None = None
        self.subvars: SubVarSet | None = None
        self.status: StatObj | None = None
        self.output: WriteHooks | None = None
        self.filewriter: FileWriter | None = None

        # Lazy singletons
        self.if_stack: IfLevels | None = None
        self.counters: CounterVars | None = None
        self.timer: Timer | None = None
        self.dbs: DatabasePool | None = None
        self.tempfiles: TempFileMgr | None = None
        self.export_metadata: ExportMetadata | None = None
        self.metacommandlist: MetaCommandList | None = None
        self.conditionallist: MetaCommandList | None = None

        # GUI
        self.gui_console: Any = None
        self.gui_manager_queue: _mp.Queue | None = None
        self.gui_manager_thread: threading.Thread | None = None

        # Profiling — None means profiling is disabled; a list means it is enabled.
        # Each entry: (source, line_no, command_type, elapsed_secs, command_text_preview)
        self.profile_data: list[tuple] | None = None

        # Debug REPL — True after a ``next`` command; engine re-enters REPL after next statement.
        self.step_mode: bool = False

        # AST executor — script block registry and include-chain tracking.
        self.ast_scripts: dict = {}
        self.include_chain: list[str] = []


# ---------------------------------------------------------------------------
# Module proxy — transparently delegates context attr access to _ctx
# ---------------------------------------------------------------------------


class _StateModule(types.ModuleType):
    """Module subclass that proxies mutable state attributes to the active RuntimeContext."""

    def __getattr__(self, name: str) -> Any:
        if name in _CONTEXT_ATTRS:
            return getattr(_get_ctx(), name)
        raise AttributeError(f"module {self.__name__!r} has no attribute {name!r}")

    def __setattr__(self, name: str, value: Any) -> None:
        if name in _CONTEXT_ATTRS:
            setattr(_get_ctx(), name, value)
        else:
            super().__setattr__(name, value)

    def __delattr__(self, name: str) -> None:
        if name in _CONTEXT_ATTRS:
            # Reset to the fresh-context default.  Needed for
            # unittest.mock.patch compatibility: patch checks
            # ``name in target.__dict__`` to decide whether to restore
            # via setattr (local) or delattr (non-local).  Since context
            # attrs live on the RuntimeContext, not __dict__, patch takes
            # the delattr path.  We reset to the default rather than truly
            # deleting.  Instantiate a fresh context each time to avoid
            # sharing mutable defaults (lists/dicts) with a cached snapshot.
            fresh = RuntimeContext()
            setattr(_get_ctx(), name, getattr(fresh, name))
        else:
            super().__delattr__(name)

    def __dir__(self) -> list[str]:
        return sorted(set(super().__dir__()) | _CONTEXT_ATTRS)


# ---------------------------------------------------------------------------
# Utility functions
# ---------------------------------------------------------------------------


def xcmd_test(teststr: str) -> bool:
    """Evaluate a conditional test string and return a boolean result."""
    import execsql.exceptions as _exc
    import execsql.parser as _parser

    result = _parser.CondParser(teststr).parse().eval()
    if result is not None:
        return result
    raise _exc.ErrInfo(type="cmd", command_text=teststr, other_msg="Unrecognized conditional")


def endloop() -> None:
    """Complete the current loop being compiled and push it onto the command stack."""
    import execsql.exceptions as _exc

    ctx = _get_ctx()
    if len(ctx.loopcommandstack) == 0:
        raise _exc.ErrInfo("error", other_msg="END LOOP metacommand without a matching preceding LOOP metacommand.")
    ctx.compiling_loop = False
    ctx.commandliststack.append(ctx.loopcommandstack[-1])
    ctx.loopcommandstack.pop()


# ---------------------------------------------------------------------------
# Context management
# ---------------------------------------------------------------------------


def get_context() -> RuntimeContext:
    """Return the active :class:`RuntimeContext` for the current thread."""
    return _get_ctx()


def set_context(ctx: RuntimeContext) -> None:
    """Replace the active :class:`RuntimeContext` for the current thread.

    Args:
        ctx: The new context to install.  All subsequent ``_state.foo``
            accesses **in this thread** will resolve against this instance.
    """
    _tls.ctx = ctx


class active_context:
    """Context manager that installs a :class:`RuntimeContext` as active.

    All ``_state.foo`` accesses within the ``with`` block resolve against
    the given context.  The previous context is restored on exit, even if
    an exception occurs.

    Thread-safe: each thread has its own context via :data:`threading.local`,
    so concurrent ``active_context`` blocks in different threads do not
    interfere with each other.

    Usage::

        from execsql.state import RuntimeContext, active_context

        ctx = RuntimeContext()
        with active_context(ctx):
            # all _state.foo accesses use ctx
            ...
        # previous context is restored
    """

    def __init__(self, ctx: RuntimeContext) -> None:
        self._ctx = ctx
        self._prev: RuntimeContext | None = None

    def __enter__(self) -> RuntimeContext:
        self._prev = _get_ctx()
        _tls.ctx = self._ctx
        return self._ctx

    def __exit__(self, *exc: Any) -> None:
        _tls.ctx = self._prev


# ---------------------------------------------------------------------------
# Initialization and reset
# ---------------------------------------------------------------------------


def reset() -> None:
    """Reset all mutable state to initial values.

    Intended for use in tests.  Creates a fresh :class:`RuntimeContext`,
    preserving only the ``filewriter`` subprocess (which is ``atexit``-managed
    and must not be discarded while alive).
    """
    ctx = _get_ctx()

    # Preserve filewriter — it's atexit-managed and must survive resets.
    old_fw = ctx.filewriter

    # Close open database connections before discarding the pool.
    if ctx.dbs is not None:
        try:
            ctx.dbs.closeall()
        except Exception:
            pass

    new_ctx = RuntimeContext()
    new_ctx.filewriter = old_fw
    _tls.ctx = new_ctx


def initialize(
    config: ConfigData,
    dispatch_table: object,
    conditional_table: object,
) -> None:
    """Initialize the shared runtime singletons for a new execsql run.

    Called once from :func:`execsql.cli._run` after configuration has been
    loaded.  Consolidates object construction in one place so that the
    sequence is documented, testable, and not scattered across the CLI
    entry-point.

    Args:
        config: A fully-populated :class:`execsql.config.ConfigData` instance.
        dispatch_table: The metacommand dispatch table
            (``execsql.metacommands.DISPATCH_TABLE``).
        conditional_table: The conditional-predicate dispatch table
            (``execsql.metacommands.conditions.CONDITIONAL_TABLE``).

    Note:
        ``subvars``, ``status``, ``output``, ``filewriter``, and ``exec_log``
        are **not** set here because they require CLI-specific arguments
        (script path, subprocess queues, local class definitions).  Those are
        assigned directly in ``_run()`` before and after this call.
    """
    import execsql.db.base as _db_base
    import execsql.exporters.base as _exporters_base
    import execsql.script as _script
    import execsql.utils.fileio as _fileio_mod
    import execsql.utils.timer as _timer_mod

    ctx = _get_ctx()
    ctx.conf = config
    ctx.if_stack = _script.IfLevels()
    ctx.counters = _script.CounterVars()
    ctx.timer = _timer_mod.Timer()
    ctx.dbs = _db_base.DatabasePool()
    ctx.tempfiles = _fileio_mod.TempFileMgr()
    ctx.export_metadata = _exporters_base.ExportMetadata()
    ctx.metacommandlist = dispatch_table
    ctx.conditionallist = conditional_table

    # Discover and register metacommand plugins via entry points.
    # Runs here (not at import time) to avoid I/O side effects during import.
    from execsql.plugins import discover_metacommand_plugins

    discover_metacommand_plugins(dispatch_table)


# ---------------------------------------------------------------------------
# Thread-local storage and context helper
# ---------------------------------------------------------------------------

_tls = threading.local()


def _get_ctx() -> RuntimeContext:
    """Return the current thread's :class:`RuntimeContext`, creating one if needed.

    Each thread gets its own isolated context via :data:`threading.local`.
    The first access in a new thread lazily creates a fresh
    :class:`RuntimeContext` so that code which reads ``_state.foo`` never
    encounters an ``AttributeError``.
    """
    ctx = getattr(_tls, "ctx", None)
    if ctx is None:
        ctx = RuntimeContext()
        _tls.ctx = ctx
    return ctx


# ---------------------------------------------------------------------------
# Bootstrap — create the initial context and swap the module class
# ---------------------------------------------------------------------------

_tls.ctx = RuntimeContext()
sys.modules[__name__].__class__ = _StateModule
