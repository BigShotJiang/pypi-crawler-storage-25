# From 3.6 base64.py
# Bug was handling "and" condition in the presence of POP_JUMP_IF_FALSE
# locations
def _85encode(foldnuls, words) -> list[str]:
    return ['z' if foldnuls and word
                else  'y'
                for word in words]

# From Python 3.6 enum.py

def __new__(metacls, cls, bases, classdict) -> None:
    {k: classdict[k] for k in classdict._member_names}
