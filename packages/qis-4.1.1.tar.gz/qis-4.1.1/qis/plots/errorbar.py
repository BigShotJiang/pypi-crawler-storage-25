"""
errorbar plot
"""

# packages
import warnings
import pandas as pd
import matplotlib.pyplot as plt
from typing import List, Union, Tuple, Optional
# qis
import qis.plots.utils as put


def plot_errorbar(df: Union[pd.Series, pd.DataFrame],
                  y_std_errors: Union[float, pd.Series, pd.DataFrame] = 0.5,
                  exact: Union[pd.Series, pd.DataFrame] = None,  # can add exact solution
                  legend_title: str = None,
                  legend_loc: Optional[Union[str, bool]] = 'upper left',
                  xlabel: str = None,
                  ylabel: str = None,
                  var_format: Optional[str] = '{:.0f}',
                  title: Union[str, bool] = None,
                  fontsize: int = 10,
                  capsize: int = 10,
                  colors: List[str] = None,
                  exact_colors: Union[str, List[str]] = 'green',
                  marker: Optional[str] = 'o',
                  exact_marker: str = "v",
                  y_limits: Tuple[Optional[float], Optional[float]] = None,
                  add_zero_line: bool = False,
                  ax: plt.Subplot = None,
                  **kwargs
                  ) -> Optional[plt.Figure]:


    if ax is None:
        fig, ax = plt.subplots()
    else:
        fig = None

    if df.empty:
        warnings.warn('df is empty: no data to plot')
        return fig

    if isinstance(df, pd.DataFrame):
        pass
    elif isinstance(df, pd.Series):
        df = df.to_frame()
    else:
        raise TypeError(f"unsupported data type {type(df)}")

    columns = df.columns

    if colors is None:
        colors = put.get_n_colors(n=len(columns), **kwargs)

    for idx, column in enumerate(columns):
        if isinstance(y_std_errors, pd.DataFrame):
            yerr = y_std_errors[column].to_numpy()  # columnwese
        elif isinstance(y_std_errors, pd.Series):
            yerr = y_std_errors.to_numpy()
        else:
            yerr = y_std_errors

        ax.errorbar(x=df.index, y=df[column].to_numpy(), yerr=yerr, color=colors[idx], fmt=marker, capsize=capsize)

    if exact is not None:  # add exact as scatter points

        if isinstance(exact, pd.Series):
            exact = exact.to_frame()

        labels = columns.to_list()
        markers = [marker] * len(columns)
        if isinstance(exact_colors, str):
            exact_colors = [exact_colors] * len(columns)
        for idx1, column in enumerate(exact.columns):
            for idx, index in enumerate(df.index):
                put.add_scatter_points(ax=ax,
                                       label_x_y=[(index, exact.loc[index, column])],
                                       color=exact_colors[idx1],
                                       marker=exact_marker, **kwargs)
            labels = labels + [column]
            colors = colors + [exact_colors[idx1]]
            markers = markers + [exact_marker]
    else:
        labels = columns
        markers = [marker]*len(columns)

    if title is not None:
        put.set_title(ax=ax, title=title, fontsize=fontsize)

    if legend_loc is not None:
        put.set_legend(ax=ax,
                       markers=markers,
                       labels=labels,
                       colors=colors,
                       legend_loc=legend_loc,
                       legend_title=legend_title,
                       handlelength=0,
                       fontsize=fontsize,
                       **kwargs)

    else:
        ax.legend().set_visible(False)

    if y_limits is not None:
        put.set_y_limits(ax=ax, y_limits=y_limits)

    if var_format is not None:
        put.set_ax_ticks_format(ax=ax, fontsize=fontsize, xvar_format=None, yvar_format=var_format, **kwargs)
    else:
        put.set_ax_ticks_format(ax=ax, fontsize=fontsize, **kwargs)
    put.set_ax_xy_labels(ax=ax, xlabel=xlabel, ylabel=ylabel, fontsize=fontsize, **kwargs)
    put.set_spines(ax=ax, **kwargs)

    if add_zero_line:
        ax.axhline(0, color='black', lw=1)

    return fig
