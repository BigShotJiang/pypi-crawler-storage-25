from .core import VERSION
