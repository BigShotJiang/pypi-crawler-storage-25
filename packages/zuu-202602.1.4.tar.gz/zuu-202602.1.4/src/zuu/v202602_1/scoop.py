"""Utilities for interacting with Scoop on Windows.

This module separates three concerns:

- running Scoop commands
- resolving Scoop-managed filesystem paths
- exposing higher-level bucket and app helpers

The path-level helpers are designed to work without shelling out. Command helpers
accept a pluggable runner so the surface can be tested with pure unit tests.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
import json
import os
from pathlib import Path
import platform
import re
import subprocess
from typing import Any
from typing import List


if platform.system() != "Windows":
    raise ImportError("This module is only supported on Windows")


ScoopRunner = Callable[[list[str]], subprocess.CompletedProcess[str]]


@dataclass(frozen=True)
class ScoopBucketInfo:
    """Describe one configured Scoop bucket.

    Attributes:
        name: The bucket name shown by Scoop.
        source: The repository or source path associated with the bucket.
    """

    name: str
    source: str


@dataclass(frozen=True)
class ScoopKnownBucket:
    """Describe one well-known bucket advertised by Scoop.

    Attributes:
        name: The well-known bucket name.
        repository: The repository URL or location published for the bucket.
    """

    name: str
    repository: str


@dataclass(frozen=True)
class ScoopInstalledApp:
    """Describe one installed Scoop app.

    Attributes:
        name: Installed app name.
        version: Installed version string.
        bucket: Bucket name when the command output exposes it.
    """

    name: str
    version: str
    bucket: str | None = None


class ScoopCommandError(RuntimeError):
    """Raised when a Scoop command exits with a non-zero status."""


def run_scoop_command(
    args: list[str],
    *,
    scoop_executable: str = "scoop",
) -> subprocess.CompletedProcess[str]:
    """Run a Scoop command and return the completed process.

    Args:
        args: Command arguments passed after the Scoop executable name.
        scoop_executable: Executable or shim name used to invoke Scoop.

    Returns:
        The completed subprocess result with captured text streams.

    Notes:
        This function does not raise on non-zero exit codes. Higher-level helpers use
        :class:`ScoopCommandError` when they require successful execution. On Windows,
        the command is launched via `cmd.exe` so Scoop's `.cmd` shim resolves the same
        way it does in an interactive shell.
    """

    try:
        return subprocess.run(
            ["cmd", "/c", scoop_executable, *args],
            capture_output=True,
            check=False,
            text=True,
        )
    except FileNotFoundError as exc:
        raise ScoopCommandError(
            f"{scoop_executable!r} could not be launched in this Python process"
        ) from exc


def _raise_for_failed_scoop_command(
    args: list[str],
    result: subprocess.CompletedProcess[str],
) -> None:
    if result.returncode == 0:
        return

    message = result.stderr.strip() or result.stdout.strip() or f"exit code {result.returncode}"
    raise ScoopCommandError(f"scoop {' '.join(args)} failed: {message}")


def _split_table_columns(line: str) -> list[str]:
    return [part.strip() for part in re.split(r"\s{2,}", line.strip()) if part.strip()]


def _is_table_separator(line: str) -> bool:
    return re.fullmatch(r"[-\s]+", line) is not None


def _normalize_command_output_path(path_text: str) -> Path | None:
    cleaned = path_text.strip()
    if not cleaned:
        return None

    if cleaned.startswith("~/") or cleaned.startswith("~\\"):
        return Path(cleaned).expanduser()

    return Path(cleaned)


def parse_bucket_list(output: str) -> list[ScoopBucketInfo]:
    """Parse `scoop bucket list` output into bucket records."""

    buckets: list[ScoopBucketInfo] = []
    for line in output.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        if stripped.casefold().startswith("name") or _is_table_separator(stripped):
            continue

        columns = _split_table_columns(stripped)
        if not columns:
            continue

        name = columns[0]
        source = columns[1] if len(columns) > 1 else ""
        buckets.append(ScoopBucketInfo(name=name, source=source))

    return buckets


def parse_known_bucket_list(output: str) -> list[ScoopKnownBucket]:
    """Parse `scoop bucket known` output into well-known bucket records."""

    known_buckets: list[ScoopKnownBucket] = []
    for bucket in parse_bucket_list(output):
        known_buckets.append(ScoopKnownBucket(name=bucket.name, repository=bucket.source))

    return known_buckets


def parse_installed_apps(output: str) -> list[ScoopInstalledApp]:
    """Parse `scoop list` output into installed-app records."""

    apps: list[ScoopInstalledApp] = []
    for line in output.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        if stripped.casefold().startswith("installed apps"):
            continue
        if stripped.casefold().startswith("name") or _is_table_separator(stripped):
            continue

        columns = _split_table_columns(stripped)
        if len(columns) < 2:
            continue

        apps.append(
            ScoopInstalledApp(
                name=columns[0],
                version=columns[1],
                bucket=columns[2] if len(columns) > 2 else None,
            )
        )

    return apps


class ScoopPaths:
    """Resolve Scoop directory and manifest paths.

    The methods on this class never require the Scoop CLI. They compute locations
    from explicit constructor arguments, Scoop environment variables, and the
    standard Windows defaults used by Scoop.
    """

    def __init__(
        self,
        *,
        user_root: Path | str | None = None,
        global_root: Path | str | None = None,
    ) -> None:
        """Initialize path resolution for Scoop roots.

        Args:
            user_root: Explicit user-level Scoop root. When omitted, `SCOOP` is used
                if present, otherwise `~/scoop`.
            global_root: Explicit global Scoop root. When omitted, `SCOOP_GLOBAL` is
                used if present, otherwise `%ProgramData%/scoop`.
        """

        self._user_root = self._normalize_root(user_root, env_var="SCOOP", default=Path.home() / "scoop")
        program_data_root = Path(os.environ.get("ProgramData", r"C:\ProgramData")) / "scoop"
        self._global_root = self._normalize_root(global_root, env_var="SCOOP_GLOBAL", default=program_data_root)

    def _normalize_root(self, path: Path | str | None, *, env_var: str, default: Path) -> Path:
        if path is not None:
            return Path(path).expanduser()

        env_value = os.environ.get(env_var)
        if env_value:
            return Path(env_value).expanduser()

        return default.expanduser()

    def user_root(self) -> Path:
        """Return the user-level Scoop root directory."""

        return self._user_root

    def global_root(self) -> Path:
        """Return the global Scoop root directory."""

        return self._global_root

    def apps_dir(self, *, global_install: bool = False) -> Path:
        """Return the directory containing installed app folders."""

        return (self.global_root() if global_install else self.user_root()) / "apps"

    def buckets_dir(self, *, global_install: bool = False) -> Path:
        """Return the directory containing cloned bucket repositories."""

        return (self.global_root() if global_install else self.user_root()) / "buckets"

    def cache_dir(self, *, global_install: bool = False) -> Path:
        """Return the directory used for cached downloads."""

        return (self.global_root() if global_install else self.user_root()) / "cache"

    def persist_dir(self, *, global_install: bool = False) -> Path:
        """Return the directory containing persistent app data."""

        return (self.global_root() if global_install else self.user_root()) / "persist"

    def shims_dir(self, *, global_install: bool = False) -> Path:
        """Return the directory containing generated Scoop shims."""

        return (self.global_root() if global_install else self.user_root()) / "shims"

    def workspace_dir(self, *, global_install: bool = False) -> Path:
        """Return the optional Scoop workspace directory."""

        return (self.global_root() if global_install else self.user_root()) / "workspace"

    def scoop_app_dir(self, *, global_install: bool = False) -> Path:
        """Return the path to the currently installed Scoop app directory."""

        return self.app_current_dir("scoop", global_install=global_install)

    def bucket_dir(self, name: str, *, global_install: bool = False) -> Path:
        """Return the root directory of a configured bucket repository."""

        return self.buckets_dir(global_install=global_install) / name

    def bucket_manifest_dir(self, name: str, *, global_install: bool = False) -> Path:
        """Return the directory containing manifests for a bucket."""

        return self.bucket_dir(name, global_install=global_install) / "bucket"

    def bucket_manifest_path(self, bucket: str, manifest: str, *, global_install: bool = False) -> Path:
        """Return the expected JSON manifest path for one app inside a bucket."""

        manifest_name = manifest.removesuffix(".json")
        return self.bucket_manifest_dir(bucket, global_install=global_install) / f"{manifest_name}.json"

    def app_dir(self, name: str, *, global_install: bool = False) -> Path:
        """Return the base directory for one installed app."""

        return self.apps_dir(global_install=global_install) / name

    def app_current_dir(self, name: str, *, global_install: bool = False) -> Path:
        """Return the app's `current` junction or directory path."""

        return self.app_dir(name, global_install=global_install) / "current"

    def app_version_dir(self, name: str, version: str, *, global_install: bool = False) -> Path:
        """Return the app directory for a specific installed version."""

        return self.app_dir(name, global_install=global_install) / version

    def app_persist_dir(self, name: str, *, global_install: bool = False) -> Path:
        """Return the persistent data directory for an app."""

        return self.persist_dir(global_install=global_install) / name

    def shim_path(self, name: str, *, global_install: bool = False) -> Path:
        """Return the most likely shim path for an executable name.

        If `name` already includes a suffix, the returned path is direct. Otherwise
        the method prefers an existing `.exe`, `.cmd`, `.ps1`, or suffixless shim in
        that order and falls back to the suffixless path when none exist.
        """

        shims_dir = self.shims_dir(global_install=global_install)
        candidate = shims_dir / name
        if candidate.suffix:
            return candidate

        for suffix in (".exe", ".cmd", ".ps1", ""):
            shim_candidate = shims_dir / f"{name}{suffix}"
            if shim_candidate.exists():
                return shim_candidate

        return candidate

    def list_bucket_manifests(self, bucket: str, *, global_install: bool = False) -> list[Path]:
        """Return all manifest JSON files currently present for a bucket."""

        manifest_dir = self.bucket_manifest_dir(bucket, global_install=global_install)
        if not manifest_dir.exists():
            return []

        return sorted(path for path in manifest_dir.glob("*.json") if path.is_file())

    def find_manifest(
        self,
        app: str,
        *,
        bucket: str | None = None,
        global_install: bool = False,
    ) -> Path | None:
        """Find a manifest path by app name.

        Args:
            app: App manifest name, with or without a `.json` suffix.
            bucket: Optional bucket name to constrain the lookup.
            global_install: When true, search under the global Scoop root.

        Returns:
            The first matching manifest path, or `None` when no manifest is present.
        """

        if bucket is not None:
            candidate = self.bucket_manifest_path(bucket, app, global_install=global_install)
            return candidate if candidate.exists() else None

        buckets_dir = self.buckets_dir(global_install=global_install)
        if not buckets_dir.exists():
            return None

        for bucket_dir in sorted(buckets_dir.iterdir()):
            if not bucket_dir.is_dir():
                continue

            candidate = self.bucket_manifest_path(bucket_dir.name, app, global_install=global_install)
            if candidate.exists():
                return candidate

        return None

    def read_manifest(
        self,
        app: str,
        *,
        bucket: str | None = None,
        global_install: bool = False,
    ) -> dict[str, Any]:
        """Load and parse a manifest JSON document.

        Raises:
            FileNotFoundError: If the manifest cannot be found.
            json.JSONDecodeError: If the manifest file is not valid JSON.
        """

        manifest_path = self.find_manifest(app, bucket=bucket, global_install=global_install)
        if manifest_path is None:
            raise FileNotFoundError(f"Manifest not found for app={app!r} bucket={bucket!r}")

        return json.loads(manifest_path.read_text(encoding="utf-8"))


class ScoopBucket:
    """Manage Scoop buckets and bucket-backed manifest discovery."""

    def __init__(self, paths: ScoopPaths, runner: ScoopRunner) -> None:
        """Create a bucket helper bound to a path resolver and command runner."""

        self.paths = paths
        self._runner = runner

    def list(self) -> List[ScoopBucketInfo]:
        """Return configured buckets reported by `scoop bucket list`."""

        return parse_bucket_list(self._run(["bucket", "list"]))

    def known(self) -> List[ScoopKnownBucket]:
        """Return well-known buckets reported by `scoop bucket known`."""

        return parse_known_bucket_list(self._run(["bucket", "known"]))

    def add(self, name: str, repository: str | None = None) -> str:
        """Add a bucket by name and optional repository URL."""

        args = ["bucket", "add", name]
        if repository is not None:
            args.append(repository)
        return self._run(args)

    def remove(self, name: str) -> str:
        """Remove a configured bucket by name."""

        return self._run(["bucket", "rm", name])

    def exists(self, name: str, *, global_install: bool = False) -> bool:
        """Return whether a bucket directory exists on disk."""

        return self.paths.bucket_dir(name, global_install=global_install).exists()

    def manifest_names(self, name: str, *, global_install: bool = False) -> List[str]:
        """Return manifest names for one bucket without the `.json` suffix."""

        return [path.stem for path in self.manifest_paths(name, global_install=global_install)]

    def manifest_paths(self, name: str, *, global_install: bool = False) -> List[Path]:
        """Return manifest file paths for one bucket."""

        return self.paths.list_bucket_manifests(name, global_install=global_install)

    def find_manifest(
        self,
        app: str,
        *,
        bucket: str | None = None,
        global_install: bool = False,
    ) -> Path | None:
        """Return the manifest path for one app if it is available locally."""

        return self.paths.find_manifest(app, bucket=bucket, global_install=global_install)

    def read_manifest(
        self,
        app: str,
        *,
        bucket: str | None = None,
        global_install: bool = False,
    ) -> dict[str, Any]:
        """Read a local manifest JSON document into a dictionary."""

        return self.paths.read_manifest(app, bucket=bucket, global_install=global_install)

    def search_manifests(
        self,
        pattern: str,
        *,
        bucket: str | None = None,
        global_install: bool = False,
    ) -> List[Path]:
        """Search local bucket manifests by glob pattern.

        Args:
            pattern: Glob pattern such as `python*` or `*portable`.
            bucket: Optional bucket to search. When omitted, all local buckets are searched.
            global_install: When true, search under the global Scoop root.

        Returns:
            Sorted matching manifest file paths.
        """

        if bucket is not None:
            manifest_dir = self.paths.bucket_manifest_dir(bucket, global_install=global_install)
            if not manifest_dir.exists():
                return []
            return sorted(path for path in manifest_dir.glob(f"{pattern}.json") if path.is_file())

        matches: list[Path] = []
        buckets_dir = self.paths.buckets_dir(global_install=global_install)
        if not buckets_dir.exists():
            return matches

        for bucket_dir in sorted(path for path in buckets_dir.iterdir() if path.is_dir()):
            manifest_dir = bucket_dir / "bucket"
            if not manifest_dir.exists():
                continue
            matches.extend(path for path in manifest_dir.glob(f"{pattern}.json") if path.is_file())

        return sorted(matches)

    def _run(self, args: List[str]) -> str:
        result = self._runner(args)
        _raise_for_failed_scoop_command(args, result)
        return result.stdout.strip()


class Scoop:
    """High-level facade for Scoop command and path surfaces.

    This facade exposes three kinds of APIs:

    - typed bucket helpers via :attr:`bucket`
    - typed path helpers via :attr:`paths`
    - direct command wrappers for Scoop subcommands
    """

    def __init__(
        self,
        *,
        paths: ScoopPaths | None = None,
        runner: ScoopRunner | None = None,
        scoop_executable: str = "scoop",
    ) -> None:
        """Create a Scoop facade.

        Args:
            paths: Optional path resolver. When omitted, defaults are used.
            runner: Optional command runner used for testing or custom invocation.
            scoop_executable: Executable used by the default runner.
        """

        self.paths = paths or ScoopPaths()
        if runner is None:
            self._runner = lambda args: run_scoop_command(args, scoop_executable=scoop_executable)
        else:
            self._runner = runner
        self.bucket = ScoopBucket(self.paths, self._runner)
        self.buckets = self.bucket

    def is_available(self) -> bool:
        """Return whether the configured Scoop executable is available on PATH."""

        result = self._runner(["--version"])
        return result.returncode == 0

    def version(self) -> str:
        """Return the Scoop version string reported by `scoop --version`."""

        return self._run(["--version"])

    def help(self, command: str | None = None) -> str:
        """Return help output for Scoop or one specific command."""

        args = ["help"]
        if command is not None:
            args.append(command)
        return self._run(args)

    def alias(self, *args: str) -> str:
        """Run `scoop alias` with the provided arguments."""

        return self._run(["alias", *args])

    def cache(self, *args: str) -> str:
        """Run `scoop cache` with the provided arguments."""

        return self._run(["cache", *args])

    def cat(self, app: str, *, bucket: str | None = None) -> str:
        """Return manifest text reported by `scoop cat`.

        Args:
            app: App name to display.
            bucket: Optional bucket name. When provided, the command uses `bucket/app`.
        """

        target = f"{bucket}/{app}" if bucket is not None else app
        return self._run(["cat", target])

    def checkup(self) -> str:
        """Run `scoop checkup` and return its textual report."""

        return self._run(["checkup"])

    def cleanup(self, *apps: str, cache: bool = False, all_versions: bool = False) -> str:
        """Run `scoop cleanup` for one or more apps.

        Args:
            apps: Optional app names. When omitted, Scoop chooses its default target set.
            cache: When true, include Scoop's cache cleanup mode.
            all_versions: When true, request cleanup of all old versions.
        """

        args = ["cleanup"]
        if cache:
            args.append("--cache")
        if all_versions:
            args.append("--all")
        args.extend(apps)
        return self._run(args)

    def config_get(self, key: str) -> str:
        """Return the configured value for one Scoop config key."""

        return self._run(["config", key])

    def config_set(self, key: str, value: str) -> str:
        """Set one Scoop config key and return Scoop's textual response."""

        return self._run(["config", key, value])

    def config_remove(self, key: str) -> str:
        """Remove one Scoop config key and return Scoop's textual response."""

        return self._run(["config", "rm", key])

    def create(self, *args: str) -> str:
        """Run `scoop create` with the provided arguments."""

        return self._run(["create", *args])

    def depends(self, app: str) -> str:
        """Return dependency information for one app."""

        return self._run(["depends", app])

    def download(self, *apps: str) -> str:
        """Run `scoop download` for one or more apps."""

        return self._run(["download", *apps])

    def export(self, *, include_config: bool = False) -> str:
        """Return the JSON text produced by `scoop export`."""

        args = ["export"]
        if include_config:
            args.append("--config")
        return self._run(args)

    def hold(self, app: str) -> str:
        """Run `scoop hold` for one app."""

        return self._run(["hold", app])

    def home(self, app: str) -> str:
        """Run `scoop home` for one app.

        Notes:
            Scoop may open a browser window as a side effect.
        """

        return self._run(["home", app])

    def import_(self, scoopfile: Path | str, *, include_config: bool = False) -> str:
        """Run `scoop import` for a Scoopfile path."""

        args = ["import", str(scoopfile)]
        if include_config:
            args.append("--config")
        return self._run(args)

    def info(self, app: str, *, verbose: bool = False) -> str:
        """Return information for one app reported by `scoop info`."""

        args = ["info", app]
        if verbose:
            args.append("--verbose")
        return self._run(args)

    def install(self, *apps: str, global_install: bool = False) -> str:
        """Run `scoop install` for one or more apps."""

        args = ["install"]
        if global_install:
            args.append("--global")
        args.extend(apps)
        return self._run(args)

    def list(self) -> List[ScoopInstalledApp]:
        """Return installed apps parsed from `scoop list`."""

        return parse_installed_apps(self._run(["list"]))

    def prefix(self, app: str) -> Path | None:
        """Return the installation prefix path for one app.

        Returns:
            A resolved `Path` when Scoop prints a location, otherwise `None`.
        """

        return _normalize_command_output_path(self._run(["prefix", app]))

    def reset(self, app: str) -> str:
        """Run `scoop reset` for one app."""

        return self._run(["reset", app])

    def search(self, query: str) -> str:
        """Return the textual result of `scoop search`."""

        return self._run(["search", query])

    def shim(self, *args: str) -> str:
        """Run `scoop shim` with the provided arguments."""

        return self._run(["shim", *args])

    def status(self, *apps: str) -> str:
        """Return status information from `scoop status`."""

        return self._run(["status", *apps])

    def unhold(self, app: str) -> str:
        """Run `scoop unhold` for one app."""

        return self._run(["unhold", app])

    def uninstall(self, *apps: str, global_install: bool = False, purge: bool = False) -> str:
        """Run `scoop uninstall` for one or more apps."""

        args = ["uninstall"]
        if global_install:
            args.append("--global")
        if purge:
            args.append("--purge")
        args.extend(apps)
        return self._run(args)

    def update(self, *apps: str, scoop_itself: bool = False, all_apps: bool = False) -> str:
        """Run `scoop update` for Scoop itself or one or more apps."""

        args = ["update"]
        if scoop_itself:
            args.append("scoop")
        if all_apps:
            args.append("*")
        args.extend(apps)
        return self._run(args)

    def virustotal(self, app: str) -> str:
        """Run `scoop virustotal` for one app.

        Notes:
            Scoop may open external resources as a side effect.
        """

        return self._run(["virustotal", app])

    def which(self, command: str) -> Path | None:
        """Return the shim or executable path reported by `scoop which`."""

        return _normalize_command_output_path(self._run(["which", command]))

    def _run(self, args: List[str]) -> str:
        result = self._runner(args)
        _raise_for_failed_scoop_command(args, result)
        return result.stdout.strip()

