"""Convert PDF to structured text using Grobid"""

__version__ = "1.8.51"
