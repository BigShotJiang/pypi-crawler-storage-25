==============
atsphinx-typst
==============

Quickstart
==========

1. Add ``atsphinx-typst[pdf]`` into your project as documentation dependencies.
2. Run ``make typstpdf`` on your document.
3. You can open ``typstpdf/document.pdf`` on your document's build directory.

Contents
========

.. toctree::
   :maxdepth: 2

   overview
   usage/index
   tips/index

.. toctree::
   :maxdepth: 2
   :hidden:

   changes

References
==========

.. toctree::
    :maxdepth: 2
    :hidden:

    api/atsphinx.typst

- `Typst reference <https://typst.app/docs/reference/>`_.
