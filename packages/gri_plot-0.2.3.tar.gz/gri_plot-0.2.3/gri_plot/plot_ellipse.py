"""2D error ellipse plotting.

This module provides the plot_ellipse() convenience function for rendering
one or more 2D error ellipses as Plotly figures. Designed for visualizing
geolocation error ellipses from gri-ell's Ell.ellipse output.
"""

from __future__ import annotations

import math
from typing import TYPE_CHECKING

import plotly.graph_objects as go

from .figure3d import DEFAULT_COLORS

if TYPE_CHECKING:
    from .shapes.ellipse import Ellipse


def _hex_to_rgba(hex_color: str, alpha: float) -> str:
    """Convert hex color to rgba string.

    Args:
        hex_color: Hex color string (e.g., "#1f77b4").
        alpha: Opacity value between 0 and 1.

    Returns:
        RGBA color string (e.g., "rgba(31, 119, 180, 0.25)").
    """
    h = hex_color.lstrip("#")
    r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    return f"rgba({r}, {g}, {b}, {alpha})"


def _add_ellipse_trace(
    fig: go.Figure,
    ellipse: Ellipse,
    color: str,
    *,
    show_axes: bool,
    single: bool,
) -> None:
    """Add traces for a single ellipse to the figure.

    Args:
        fig: Plotly figure to add traces to.
        ellipse: Ellipse to render.
        color: Hex color for this ellipse.
        show_axes: Whether to draw SMA/SMI annotation lines.
        single: True if this is the only ellipse (affects axis colors).
    """
    east, north = ellipse.boundary()

    # Filled ellipse boundary
    fig.add_trace(
        go.Scatter(
            x=east,
            y=north,
            mode="lines",
            line={"color": color, "width": 2},
            fill="toself",
            fillcolor=_hex_to_rgba(color, 0.25),
            name=ellipse.label or "Ellipse",
            showlegend=True,
        ),
    )

    if not show_axes:
        return

    # SMA / SMI annotation lines from center
    ce, cn = ellipse.center
    sma_rad = math.radians(90.0 - ellipse.ori_deg)
    smi_rad = sma_rad + math.pi / 2

    # Color convention: single ellipse uses red/orange; multi uses own color
    if single:
        sma_color = DEFAULT_COLORS[3]  # red
        smi_color = DEFAULT_COLORS[1]  # orange
    else:
        sma_color = color
        smi_color = color

    for length, angle, axis_label, line_color in [
        (ellipse.sma, sma_rad, f"SMA = {ellipse.sma:.0f} m", sma_color),
        (ellipse.smi, smi_rad, f"SMI = {ellipse.smi:.0f} m", smi_color),
    ]:
        dx = length * math.cos(angle)
        dy = length * math.sin(angle)
        fig.add_trace(
            go.Scatter(
                x=[ce, ce + dx],
                y=[cn, cn + dy],
                mode="lines+text",
                line={"color": line_color, "width": 2, "dash": "dash"},
                text=["", axis_label],
                textposition="top right",
                textfont={"color": line_color, "size": 11},
                showlegend=False,
            ),
        )


def plot_ellipse(
    *ellipses: Ellipse,
    show_axes: bool = True,
    title: str | None = None,
    **kwargs,
) -> go.Figure:
    """Plot one or more 2D error ellipses.

    Creates a Plotly figure with filled ellipses rendered in an East/North
    coordinate frame. Designed for visualizing geolocation error ellipses.

    Args:
        *ellipses: One or more Ellipse objects to plot.
        show_axes: If True, draw dashed SMA/SMI annotation lines with
            length labels. For a single ellipse, uses red (SMA) and
            orange (SMI). For multiple ellipses, uses each ellipse's
            own color.
        title: Optional figure title.
        **kwargs: Additional arguments passed to fig.update_layout().

    Returns:
        Plotly Figure object. Call fig.show() to display.

    Raises:
        ValueError: If no ellipses are provided.
    """
    if not ellipses:
        msg = "At least one Ellipse must be provided"
        raise ValueError(msg)

    fig = go.Figure()
    single = len(ellipses) == 1

    for i, ellipse in enumerate(ellipses):
        color = DEFAULT_COLORS[i % len(DEFAULT_COLORS)]
        _add_ellipse_trace(
            fig,
            ellipse,
            color,
            show_axes=show_axes,
            single=single,
        )

    # Compute auto-padded range from all ellipses
    all_east = []
    all_north = []
    for ellipse in ellipses:
        east, north = ellipse.boundary()
        all_east.extend([east.min(), east.max()])
        all_north.extend([north.min(), north.max()])

    e_min, e_max = min(all_east), max(all_east)
    n_min, n_max = min(all_north), max(all_north)
    e_span = e_max - e_min
    n_span = n_max - n_min
    pad = max(e_span, n_span) * 0.15

    layout = {
        "template": "plotly_dark",
        "xaxis_title": "East (m)",
        "yaxis_title": "North (m)",
        "xaxis": {
            "scaleanchor": "y",
            "range": [e_min - pad, e_max + pad],
        },
        "yaxis": {
            "range": [n_min - pad, n_max + pad],
        },
    }

    if title is not None:
        layout["title"] = title

    layout.update(kwargs)
    fig.update_layout(**layout)
    return fig


__all__ = [
    "plot_ellipse",
]
