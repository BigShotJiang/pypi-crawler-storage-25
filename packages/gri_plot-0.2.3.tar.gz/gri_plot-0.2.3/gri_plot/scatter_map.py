"""Basic lat/lon plot to a scatter_map in plotly."""

from __future__ import annotations

from typing import TYPE_CHECKING

import plotly.graph_objects as go

if TYPE_CHECKING:
    from collections.abc import Sequence

    import numpy as np

# TODO lots of cleanup to do here


def scatter_map(*args: Sequence[Sequence[float]] | np.ndarray, **kwargs) -> None:
    """Make a plot from lists of lat/lon.

    Takes a list of lats and a list of lons as the first two indexes, or a row of lats
    and a row of lons. If your data is in numpy colums, just pass arr.T. If your list is
    lat/lon pairs, then something like np.asarray(arr).T should work.

    For example, pass in scatter_map((lats1,lons1),(lats2,lons2))
    To get to ((lats,lons)) from ((lat,lon),...), use np.asarray(arr).T

    Args:
        args(Sequence[Sequence[float]] | np.ndarray): any number of sequences or arrays
            where the first two rows are lat and lon
        kwargs: Any arguments to pass to plotly.express.scater_map like:
            zoom(1-20), height(pixel height of map), width(pixel height of width). Also
            can use a list of marker_sizes(diameters) and marker_colors(plotly colors)
            but must be the same length as *args
    """
    marker_sizes = kwargs.get("marker_sizes")
    marker_colors = kwargs.get("marker_colors")
    fig = go.Figure()
    traces = [
        go.Scattermap(
            lat=arg[0],
            lon=arg[1],
            mode="markers",
            marker={
                "size": marker_sizes[idx] if marker_sizes else None,
                "color": marker_colors[idx] if marker_colors else None,
                "sizemode": "diameter",
            },
        )
        for idx, arg in enumerate(args)
    ]
    fig.add_traces(traces)
    center = _center(*args)

    # fig.update_layout(map_style="open-street-map")
    # fig.update_layout(map_style="carto-darkmatter")
    # fig.update_layout(map_style="satellite-streets")
    # fig.update_layout(map_style="satellite")
    # fig.update_layout(map_style="streets")
    # fig.update_layout(map_style="carto-voyager")
    # fig.update_layout(map_style="carto-positron")
    # s = "https://gis.apfo.usda.gov/arcgis/rest/services/NAIP/USDA_CONUS_PRIME/ImageServer/tile/{z}/{y}/{x}"
    # s = "https://basemap.nationalmap.gov/arcgis/rest/services/USGSImageryOnly/MapServer/tile/{z}/{y}/{x}"
    s = "https://services.arcgisonline.com/arcgis/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"
    fig.update_layout(
        template="plotly_dark",
        map_style="white-bg",
        map_layers=[
            {
                "below": "traces",
                "sourcetype": "raster",
                "sourceattribution": "ArcGIS Online",
                "source": [s],
                "maxzoom": 18,
            },
        ],
        map_zoom=kwargs.get("zoom"),
        map_center=center,
        height=kwargs.get("height"),
        width=kwargs.get("width"),
    )
    fig.show()


def _center(*args: Sequence[Sequence[float]] | np.ndarray) -> dict[str, float]:
    """Get the center lat/lon of the data."""
    min_lat = 999
    min_lon = 999
    max_lat = -999
    max_lon = -999
    for arg in args:
        min_lat = min(min_lat, *arg[0])
        max_lat = max(max_lat, *arg[0])
        min_lon = min(min_lon, *arg[1])
        max_lon = max(max_lon, *arg[1])
    return {"lat": (min_lat + max_lat) / 2, "lon": (min_lon + max_lon) / 2}
