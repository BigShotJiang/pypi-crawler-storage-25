"""Plotting utilities for GeoSol Research.

This package provides utilities for 2D and 3D visualization using Plotly,
including scatter plots, geographic maps, and 3D surfaces for geolocation
observables.

Main components:
    - scatter: 2D scatter plots with Plotly
    - scatter_map: Geographic scatter maps
    - Figure3D: 3D figure for combining surfaces
    - shapes: Geometric shapes (Ellipsoid, Sphere, Cone, Cylinder)
    - observables: Geolocation surfaces (TDOA, FDOA, AOA, etc.)
    - surfaces: Low-level surface utilities
    - frames: Coordinate frame handling
"""

# 2D plotting
# 3D plotting infrastructure
from .figure3d import DEFAULT_COLORS, Figure3D, plot_surfaces
from .figure_map import FigureMap, MapStyle
from .frames import Bounds, Frame, FrameTransformer

# Observables
from .observables import (
    AoaSurface,
    FdoaSurface,
    LosSurface,
    RangeSphere,
    TdoaSurface,
    TerrainSurface,
)
from .plot_ellipse import plot_ellipse
from .scatter import scatter
from .scatter_map import scatter_map

# Shapes
from .shapes import Cone, Cylinder, Ellipse, Ellipsoid, Sphere

# Shape mesh generators
from .shapes.meshgen import cone_mesh, cylinder_mesh, ellipsoid_mesh, sphere_mesh

# Surface utilities
from .surfaces import (
    ImplicitShape,
    expand_bounds,
    merge_bounds,
)
from .surfaces.gradients import (
    axis_value,
    distance_from_axis,
    distance_from_line,
    distance_from_line_segment,
    distance_from_plane,
    distance_from_point,
)
from .surfaces.mesh import field_to_mesh, grid_to_mesh, vertices_to_mesh3d

__all__ = [
    "DEFAULT_COLORS",
    "AoaSurface",
    "Bounds",
    "Cone",
    "Cylinder",
    "Ellipse",
    "Ellipsoid",
    "FdoaSurface",
    "Figure3D",
    "FigureMap",
    "Frame",
    "FrameTransformer",
    "ImplicitShape",
    "LosSurface",
    "MapStyle",
    "RangeSphere",
    "Sphere",
    "TdoaSurface",
    "TerrainSurface",
    "axis_value",
    "cone_mesh",
    "cylinder_mesh",
    "distance_from_axis",
    "distance_from_line",
    "distance_from_line_segment",
    "distance_from_plane",
    "distance_from_point",
    "ellipsoid_mesh",
    "expand_bounds",
    "field_to_mesh",
    "grid_to_mesh",
    "merge_bounds",
    "plot_ellipse",
    "plot_surfaces",
    "scatter",
    "scatter_map",
    "sphere_mesh",
    "vertices_to_mesh3d",
]
