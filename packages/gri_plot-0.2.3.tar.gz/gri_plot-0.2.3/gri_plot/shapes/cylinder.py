"""Cylinder shape for 3D visualization."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from gri_plot.shapes.meshgen import AXIS_ALIGNMENT_THRESHOLD, cylinder_mesh
from gri_plot.surfaces import ImplicitShape
from gri_plot.surfaces.mesh import vertices_to_mesh3d

if TYPE_CHECKING:
    from collections.abc import Callable

    import plotly.graph_objects as go
    from numpy.typing import NDArray


class Cylinder(ImplicitShape):
    """A 3D cylinder defined by center, axis, radius, and height.

    The cylinder is centered at the given point and extends height/2
    in each direction along the axis.

    Attributes:
        center_xyz: Center of the cylinder in XYZ coordinates.
        axis: Normalized axis direction.
        radius: Radius of the cylinder.
        height: Total height of the cylinder.
        label: Optional label for legends.
        is_volume: Whether this shape represents a volume or surface.
    """

    def __init__(  # noqa: PLR0913 - 3D cylinder requires center + axis + radius + height
        self,
        center_xyz: NDArray[np.floating],
        axis: NDArray[np.floating],
        radius: float,
        height: float,
        label: str | None = None,
        *,
        as_volume: bool = True,
    ) -> None:
        """Initialize the cylinder.

        Args:
            center_xyz: Center of the cylinder, shape (3,).
            axis: Axis direction (will be normalized), shape (3,).
            radius: Radius of the cylinder (positive).
            height: Total height of the cylinder (positive).
            label: Optional label for legends.
            as_volume: Keyword-only. If True, interior is solution region.
                If False, boundary is solution locus. Default True.

        Raises:
            ValueError: If radius or height is not positive.
        """
        self._center = np.asarray(center_xyz, dtype=np.float64)
        axis = np.asarray(axis, dtype=np.float64)
        self._axis = axis / np.linalg.norm(axis)

        if radius <= 0:
            raise ValueError("radius must be positive")
        self._radius = float(radius)

        if height <= 0:
            raise ValueError("height must be positive")
        self._height = float(height)

        self._label = label
        self._is_volume = as_volume

        # Precompute orthonormal basis
        self._compute_basis()

    def _compute_basis(self) -> None:
        """Compute orthonormal basis vectors perpendicular to axis."""
        if abs(self._axis[2]) < AXIS_ALIGNMENT_THRESHOLD:
            perp1 = np.cross(self._axis, np.array([0.0, 0.0, 1.0]))
        else:
            perp1 = np.cross(self._axis, np.array([1.0, 0.0, 0.0]))
        self._perp1 = perp1 / np.linalg.norm(perp1)
        self._perp2 = np.cross(self._axis, self._perp1)

    @property
    def center_xyz(self) -> NDArray[np.floating]:
        """Get the center in XYZ coordinates."""
        return self._center

    @property
    def axis(self) -> NDArray[np.floating]:
        """Get the normalized axis direction."""
        return self._axis

    @property
    def radius(self) -> float:
        """Get the radius."""
        return self._radius

    @property
    def height(self) -> float:
        """Get the height."""
        return self._height

    @property
    def label(self) -> str | None:
        """Get the label."""
        return self._label

    @property
    def is_volume(self) -> bool:
        """Whether this shape represents a volume (True) or surface (False)."""
        return self._is_volume

    def residual_fn(self, xyz: NDArray[np.floating]) -> NDArray[np.floating]:
        """Compute the residual function for the cylinder.

        The residual is the perpendicular distance from the axis minus
        the radius, so:
        - 0 on the surface
        - Positive outside
        - Negative inside

        Note: This only considers the cylindrical surface, not the end caps.

        Args:
            xyz: Points to evaluate, shape (..., 3).

        Returns:
            Residual values, shape (...).
        """
        xyz = np.asarray(xyz)
        diff = xyz - self._center

        # Component along axis
        parallel = np.einsum("...i,i->...", diff, self._axis)

        # Perpendicular component
        parallel_vec = parallel[..., np.newaxis] * self._axis
        perp = diff - parallel_vec
        perp_dist = np.linalg.norm(perp, axis=-1)

        return perp_dist - self._radius

    def to_mesh(
        self,
        resolution: int | None = None,
    ) -> tuple[NDArray[np.floating], NDArray[np.integer]]:
        """Generate mesh vertices and faces.

        Args:
            resolution: Number of samples per dimension. If None, uses 50.

        Returns:
            Tuple of (vertices, faces).
        """
        if resolution is None:
            resolution = 50
        return cylinder_mesh(
            self._center,
            self._axis,
            self._radius,
            self._height,
            resolution,
        )

    def get_bounds_xyz(
        self,
    ) -> tuple[NDArray[np.floating], NDArray[np.floating]]:
        """Get axis-aligned bounding box in XYZ coordinates.

        Returns:
            Tuple of (min_corner, max_corner).
        """
        # Endpoints along axis
        half_h = self._height / 2
        end1 = self._center - half_h * self._axis
        end2 = self._center + half_h * self._axis

        # Sample the circles at each end
        perps = [self._perp1, -self._perp1, self._perp2, -self._perp2]
        points = [end + self._radius * perp for end in [end1, end2] for perp in perps]
        points = np.array(points)
        return points.min(axis=0), points.max(axis=0)

    def to_trace(
        self,
        resolution: int | None = None,
        intensity_fn: Callable[[NDArray[np.floating]], NDArray[np.floating]]
        | None = None,
        **kwargs,
    ) -> go.Mesh3d:
        """Generate a Plotly Mesh3d trace.

        Args:
            resolution: Mesh resolution.
            intensity_fn: Optional intensity function for coloring.
            **kwargs: Additional arguments for vertices_to_mesh3d.

        Returns:
            Plotly Mesh3d trace.
        """
        vertices, faces = self.to_mesh(resolution)
        return vertices_to_mesh3d(
            vertices,
            faces,
            intensity_fn=intensity_fn,
            name=self._label,
            **kwargs,
        )

    def __repr__(self) -> str:
        """Return string representation."""
        return (
            f"Cylinder(center={self._center}, axis={self._axis}, "
            f"radius={self._radius}, height={self._height})"
        )


__all__ = ["Cylinder"]
