"""Ellipsoid shape for 3D visualization."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from gri_plot.shapes.meshgen import ellipsoid_mesh
from gri_plot.surfaces import ImplicitShape
from gri_plot.surfaces.mesh import vertices_to_mesh3d

if TYPE_CHECKING:
    from collections.abc import Callable

    import plotly.graph_objects as go
    from numpy.typing import NDArray


class Ellipsoid(ImplicitShape):
    """A 3D ellipsoid defined by center and covariance matrix.

    The ellipsoid represents a 1-sigma contour of a 3D Gaussian distribution,
    or can be specified by semi-axes and rotation.

    The residual function returns Mahalanobis distance squared - 1, so:
    - 0 on the 1-sigma surface
    - Positive outside
    - Negative inside

    Attributes:
        center_xyz: Center of the ellipsoid in XYZ coordinates.
        covariance: Covariance matrix (3x3).
        semi_axes: Semi-axis lengths (a, b, c).
        rotation: Rotation matrix (3x3).
        label: Optional label for legends.
        is_volume: Whether this shape represents a volume or surface.
    """

    def __init__(  # noqa: PLR0913 - supports covariance or semi-axes + rotation
        self,
        center_xyz: NDArray[np.floating],
        covariance: NDArray[np.floating] | None = None,
        semi_axes: NDArray[np.floating] | None = None,
        rotation: NDArray[np.floating] | None = None,
        label: str | None = None,
        *,
        as_volume: bool = True,
    ) -> None:
        """Initialize the ellipsoid.

        The ellipsoid can be defined either by a covariance matrix or by
        semi-axes and rotation. If covariance is provided, semi_axes and
        rotation are derived from its eigendecomposition.

        Args:
            center_xyz: Center of the ellipsoid, shape (3,).
            covariance: Covariance matrix, shape (3, 3). Mutually exclusive
                with semi_axes/rotation.
            semi_axes: Semi-axis lengths (a, b, c) in descending order.
                Required if covariance is None.
            rotation: Rotation matrix, shape (3, 3). Columns are the principal
                axes. Defaults to identity if not provided.
            label: Optional label for legends.
            as_volume: Keyword-only. If True, interior is solution region.
                If False, boundary is solution locus. Default True.

        Raises:
            ValueError: If neither covariance nor semi_axes is provided, or
                if both are provided.
        """
        self._center = np.asarray(center_xyz, dtype=np.float64)
        self._label = label
        self._is_volume = as_volume

        if covariance is not None and semi_axes is not None:
            raise ValueError("Provide either covariance or semi_axes, not both")

        if covariance is not None:
            self._covariance = np.asarray(covariance, dtype=np.float64)
            # Eigendecomposition
            eigenvalues, eigenvectors = np.linalg.eigh(self._covariance)
            # Sort in descending order
            idx = np.argsort(eigenvalues)[::-1]
            eigenvalues = eigenvalues[idx]
            eigenvectors = eigenvectors[:, idx]

            self._semi_axes = np.sqrt(np.abs(eigenvalues))
            self._rotation = eigenvectors
            # Compute inverse covariance for residual
            self._cov_inv = np.linalg.inv(self._covariance)

        elif semi_axes is not None:
            self._semi_axes = np.asarray(semi_axes, dtype=np.float64)
            if rotation is None:
                self._rotation = np.eye(3)
            else:
                self._rotation = np.asarray(rotation, dtype=np.float64)

            # Reconstruct covariance: C = R @ diag(s^2) @ R.T
            s_squared = np.diag(self._semi_axes**2)
            self._covariance = self._rotation @ s_squared @ self._rotation.T
            self._cov_inv = np.linalg.inv(self._covariance)

        else:
            raise ValueError("Either covariance or semi_axes must be provided")

    @property
    def center_xyz(self) -> NDArray[np.floating]:
        """Get the center in XYZ coordinates."""
        return self._center

    @property
    def covariance(self) -> NDArray[np.floating]:
        """Get the covariance matrix."""
        return self._covariance

    @property
    def semi_axes(self) -> NDArray[np.floating]:
        """Get the semi-axis lengths."""
        return self._semi_axes

    @property
    def rotation(self) -> NDArray[np.floating]:
        """Get the rotation matrix."""
        return self._rotation

    @property
    def label(self) -> str | None:
        """Get the label."""
        return self._label

    @property
    def is_volume(self) -> bool:
        """Whether this shape represents a volume (True) or surface (False)."""
        return self._is_volume

    def residual_fn(self, xyz: NDArray[np.floating]) -> NDArray[np.floating]:
        """Compute the residual function (Mahalanobis distance squared - 1).

        Args:
            xyz: Points to evaluate, shape (..., 3).

        Returns:
            Residual values, shape (...). Zero on surface, positive outside,
            negative inside.
        """
        xyz = np.asarray(xyz)
        diff = xyz - self._center

        # Mahalanobis distance squared: d^2 = (x-mu)^T @ C^-1 @ (x-mu)
        # Using einsum for batch computation
        temp = np.einsum("...i,ij->...j", diff, self._cov_inv)
        mahal_sq = np.einsum("...i,...i->...", diff, temp)

        return mahal_sq - 1.0

    def to_mesh(
        self,
        resolution: int | None = None,
    ) -> tuple[NDArray[np.floating], NDArray[np.integer]]:
        """Generate mesh vertices and faces.

        Args:
            resolution: Number of samples per dimension. If None, uses 50.

        Returns:
            Tuple of (vertices, faces).
        """
        if resolution is None:
            resolution = 50
        return ellipsoid_mesh(
            self._center,
            semi_axes=self._semi_axes,
            rotation=self._rotation,
            resolution=resolution,
        )

    def get_bounds_xyz(
        self,
    ) -> tuple[NDArray[np.floating], NDArray[np.floating]]:
        """Get axis-aligned bounding box in XYZ coordinates.

        The bounding box accounts for the ellipsoid's rotation.

        Returns:
            Tuple of (min_corner, max_corner).
        """
        # The extent in each axis direction
        # For an ellipsoid with semi-axes s and rotation R, the extent along
        # axis e_i is sqrt(sum_j (R[i,j] * s[j])^2)
        extents = np.zeros(3)
        for i in range(3):
            extents[i] = np.sqrt(np.sum((self._rotation[i, :] * self._semi_axes) ** 2))

        return self._center - extents, self._center + extents

    def to_trace(
        self,
        resolution: int | None = None,
        intensity_fn: Callable[[NDArray[np.floating]], NDArray[np.floating]]
        | None = None,
        **kwargs,
    ) -> go.Mesh3d:
        """Generate a Plotly Mesh3d trace.

        Args:
            resolution: Mesh resolution.
            intensity_fn: Optional intensity function for coloring.
            **kwargs: Additional arguments for vertices_to_mesh3d.

        Returns:
            Plotly Mesh3d trace.
        """
        vertices, faces = self.to_mesh(resolution)
        return vertices_to_mesh3d(
            vertices,
            faces,
            intensity_fn=intensity_fn,
            name=self._label,
            **kwargs,
        )

    def __repr__(self) -> str:
        """Return string representation."""
        return f"Ellipsoid(center={self._center}, semi_axes={self._semi_axes})"


__all__ = ["Ellipsoid"]
