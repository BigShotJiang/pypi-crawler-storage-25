"""Geometric shape classes for visualization.

This module provides classes for common shapes that can be rendered
as either parametric meshes, isosurfaces, or 2D boundaries.
"""

from .cone import Cone
from .cylinder import Cylinder
from .ellipse import Ellipse
from .ellipsoid import Ellipsoid
from .sphere import Sphere

__all__ = [
    "Cone",
    "Cylinder",
    "Ellipse",
    "Ellipsoid",
    "Sphere",
]
