"""2D ellipse shape for error ellipse visualization.

This module provides a standalone 2D ellipse class for rendering geolocation
error ellipses. Unlike the 3D shapes that inherit from ImplicitShape, this
is a simple 2D boundary representation parameterized by semi-major axis,
semi-minor axis, and orientation.
"""

from __future__ import annotations

import math
from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from numpy.typing import NDArray


class Ellipse:
    """2D ellipse defined by semi-axes and orientation.

    Represents a 2D error ellipse in an East/North coordinate frame,
    parameterized the same way as gri-ell's Ell.ellipse output:
    semi-major axis, semi-minor axis, and orientation in degrees
    clockwise from North.

    Args:
        sma: Semi-major axis length in meters. Must be positive and >= smi.
        smi: Semi-minor axis length in meters. Must be positive.
        ori_deg: Orientation in degrees clockwise from North.
            Normalized to [0, 360).
        center: Center point as (east_m, north_m). Defaults to origin.
        label: Optional label for legend display.

    Raises:
        ValueError: If axes are non-positive or sma < smi.
    """

    def __init__(  # noqa: D107
        self,
        sma: float,
        smi: float,
        ori_deg: float,
        center: tuple[float, float] = (0.0, 0.0),
        label: str | None = None,
    ) -> None:
        if sma <= 0 or smi <= 0:
            msg = f"Semi-axes must be positive, got sma={sma}, smi={smi}"
            raise ValueError(msg)
        if sma < smi:
            msg = (
                f"Semi-major axis must be >= semi-minor axis, got sma={sma}, smi={smi}"
            )
            raise ValueError(msg)
        self._sma = float(sma)
        self._smi = float(smi)
        self._ori_deg = float(ori_deg) % 360.0
        self._center = (float(center[0]), float(center[1]))
        self._label = label

    @property
    def sma(self) -> float:
        """Semi-major axis length in meters."""
        return self._sma

    @property
    def smi(self) -> float:
        """Semi-minor axis length in meters."""
        return self._smi

    @property
    def ori_deg(self) -> float:
        """Orientation in degrees clockwise from North, in [0, 360)."""
        return self._ori_deg

    @property
    def center(self) -> tuple[float, float]:
        """Center point as (east_m, north_m)."""
        return self._center

    @property
    def label(self) -> str | None:
        """Optional label for legend display."""
        return self._label

    def boundary(self, n_pts: int = 200) -> tuple[NDArray, NDArray]:
        """Compute ellipse boundary points in East/North meters.

        Args:
            n_pts: Number of boundary points to generate.

        Returns:
            Tuple of (east, north) arrays, each of length n_pts.
        """
        theta = np.linspace(0, 2 * np.pi, n_pts)
        # Ellipse in local frame: SMA along x, SMI along y
        x_local = self._sma * np.cos(theta)
        y_local = self._smi * np.sin(theta)
        # Rotate: ori_deg CW from North -> CCW from East = (90 - ori_deg)
        angle_rad = math.radians(90.0 - self._ori_deg)
        cos_a = math.cos(angle_rad)
        sin_a = math.sin(angle_rad)
        east = cos_a * x_local - sin_a * y_local + self._center[0]
        north = sin_a * x_local + cos_a * y_local + self._center[1]
        return east, north

    def __repr__(self) -> str:
        """Return string representation."""
        parts = [
            f"Ellipse(sma={self._sma:.1f}",
            f"smi={self._smi:.1f}",
            f"ori={self._ori_deg:.1f} deg",
        ]
        if self._center != (0.0, 0.0):
            parts.append(f"center=({self._center[0]:.1f}, {self._center[1]:.1f})")
        if self._label is not None:
            parts.append(f"label={self._label!r}")
        return ", ".join(parts) + ")"
