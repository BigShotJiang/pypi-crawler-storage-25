"""Mesh generation for geometric shapes.

This module provides functions to generate vertices and faces for common
3D shapes. The output can be passed to vertices_to_mesh3d() for rendering.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from gri_plot.surfaces.mesh import grid_to_mesh

# Threshold for choosing perpendicular vector when building orthonormal basis.
# When |axis[2]| < this value, cross with Z-axis; otherwise cross with X-axis.
AXIS_ALIGNMENT_THRESHOLD = 0.9

if TYPE_CHECKING:
    from numpy.typing import NDArray


def sphere_mesh(
    center: NDArray[np.floating],
    radius: float,
    resolution: int = 50,
) -> tuple[NDArray[np.floating], NDArray[np.integer]]:
    """Generate vertices and faces for a sphere.

    Args:
        center: Center of the sphere, shape (3,).
        radius: Radius of the sphere.
        resolution: Number of samples per dimension.

    Returns:
        Tuple of (vertices, faces).
    """
    center = np.asarray(center)

    u = np.linspace(0, 2 * np.pi, resolution)
    v = np.linspace(0, np.pi, resolution)
    u_grid, v_grid = np.meshgrid(u, v)

    x = center[0] + radius * np.cos(u_grid) * np.sin(v_grid)
    y = center[1] + radius * np.sin(u_grid) * np.sin(v_grid)
    z = center[2] + radius * np.cos(v_grid)

    return grid_to_mesh(x, y, z)


def ellipsoid_mesh(
    center: NDArray[np.floating],
    covariance: NDArray[np.floating] | None = None,
    semi_axes: NDArray[np.floating] | None = None,
    rotation: NDArray[np.floating] | None = None,
    resolution: int = 50,
) -> tuple[NDArray[np.floating], NDArray[np.integer]]:
    """Generate vertices and faces for an ellipsoid.

    The ellipsoid can be specified either by a covariance matrix or by
    semi-axes and rotation matrix.

    Args:
        center: Center of the ellipsoid, shape (3,).
        covariance: Covariance matrix, shape (3, 3). If provided, semi_axes
            and rotation are computed from it.
        semi_axes: Semi-axis lengths (a, b, c). Required if covariance is None.
        rotation: Rotation matrix, shape (3, 3). Defaults to identity.
        resolution: Number of samples per dimension.

    Returns:
        Tuple of (vertices, faces).

    Raises:
        ValueError: If neither covariance nor semi_axes is provided.
    """
    center = np.asarray(center)

    if covariance is not None:
        covariance = np.asarray(covariance)
        eigenvalues, eigenvectors = np.linalg.eigh(covariance)
        # Sort in descending order
        idx = np.argsort(eigenvalues)[::-1]
        eigenvalues = eigenvalues[idx]
        eigenvectors = eigenvectors[:, idx]

        semi_axes = np.sqrt(np.abs(eigenvalues))
        rotation = eigenvectors

    elif semi_axes is not None:
        semi_axes = np.asarray(semi_axes)
        rotation = np.eye(3) if rotation is None else np.asarray(rotation)
    else:
        raise ValueError("Either covariance or semi_axes must be provided")

    # Generate unit sphere
    u = np.linspace(0, 2 * np.pi, resolution)
    v = np.linspace(0, np.pi, resolution)
    u_grid, v_grid = np.meshgrid(u, v)

    x_sphere = np.cos(u_grid) * np.sin(v_grid)
    y_sphere = np.sin(u_grid) * np.sin(v_grid)
    z_sphere = np.cos(v_grid)

    # Scale by semi-axes
    x_ellipsoid = semi_axes[0] * x_sphere
    y_ellipsoid = semi_axes[1] * y_sphere
    z_ellipsoid = semi_axes[2] * z_sphere

    # Stack and rotate
    points = np.stack([x_ellipsoid, y_ellipsoid, z_ellipsoid], axis=-1)
    rotated = np.einsum("ij,...j->...i", rotation, points)

    # Translate to center
    x = rotated[..., 0] + center[0]
    y = rotated[..., 1] + center[1]
    z = rotated[..., 2] + center[2]

    return grid_to_mesh(x, y, z)


def cone_mesh(
    apex: NDArray[np.floating],
    axis: NDArray[np.floating],
    half_angle: float,
    height: float,
    resolution: int = 50,
) -> tuple[NDArray[np.floating], NDArray[np.integer]]:
    """Generate vertices and faces for a cone.

    The cone extends from the apex along the axis direction.

    Args:
        apex: Apex (tip) of the cone, shape (3,).
        axis: Axis direction (normalized or not), shape (3,).
        half_angle: Half-angle of the cone in radians.
        height: Height (length along axis) of the cone.
        resolution: Number of samples per dimension.

    Returns:
        Tuple of (vertices, faces).
    """
    apex = np.asarray(apex)
    axis = np.asarray(axis)
    axis = axis / np.linalg.norm(axis)

    # Create orthonormal basis
    if abs(axis[2]) < AXIS_ALIGNMENT_THRESHOLD:
        perp1 = np.cross(axis, np.array([0.0, 0.0, 1.0]))
    else:
        perp1 = np.cross(axis, np.array([1.0, 0.0, 0.0]))
    perp1 = perp1 / np.linalg.norm(perp1)
    perp2 = np.cross(axis, perp1)

    # Parametric surface: h from 0 to height, theta from 0 to 2*pi
    h = np.linspace(0, height, resolution)
    theta = np.linspace(0, 2 * np.pi, resolution)
    h_grid, theta_grid = np.meshgrid(h, theta)

    # Radius at height h
    r = h_grid * np.tan(half_angle)

    # Position along cone surface
    x = (
        apex[0]
        + h_grid * axis[0]
        + r * (np.cos(theta_grid) * perp1[0] + np.sin(theta_grid) * perp2[0])
    )
    y = (
        apex[1]
        + h_grid * axis[1]
        + r * (np.cos(theta_grid) * perp1[1] + np.sin(theta_grid) * perp2[1])
    )
    z = (
        apex[2]
        + h_grid * axis[2]
        + r * (np.cos(theta_grid) * perp1[2] + np.sin(theta_grid) * perp2[2])
    )

    return grid_to_mesh(x, y, z)


def cylinder_mesh(
    center: NDArray[np.floating],
    axis: NDArray[np.floating],
    radius: float,
    height: float,
    resolution: int = 50,
) -> tuple[NDArray[np.floating], NDArray[np.integer]]:
    """Generate vertices and faces for a cylinder.

    The cylinder is centered at center and extends height/2 in each
    direction along the axis.

    Args:
        center: Center of the cylinder, shape (3,).
        axis: Axis direction (normalized or not), shape (3,).
        radius: Radius of the cylinder.
        height: Total height of the cylinder.
        resolution: Number of samples per dimension.

    Returns:
        Tuple of (vertices, faces).
    """
    center = np.asarray(center)
    axis = np.asarray(axis)
    axis = axis / np.linalg.norm(axis)

    # Create orthonormal basis
    if abs(axis[2]) < AXIS_ALIGNMENT_THRESHOLD:
        perp1 = np.cross(axis, np.array([0.0, 0.0, 1.0]))
    else:
        perp1 = np.cross(axis, np.array([1.0, 0.0, 0.0]))
    perp1 = perp1 / np.linalg.norm(perp1)
    perp2 = np.cross(axis, perp1)

    # Parametric surface: h from -height/2 to height/2, theta from 0 to 2*pi
    h = np.linspace(-height / 2, height / 2, resolution)
    theta = np.linspace(0, 2 * np.pi, resolution)
    h_grid, theta_grid = np.meshgrid(h, theta)

    # Position along cylinder surface
    x = (
        center[0]
        + h_grid * axis[0]
        + radius * (np.cos(theta_grid) * perp1[0] + np.sin(theta_grid) * perp2[0])
    )
    y = (
        center[1]
        + h_grid * axis[1]
        + radius * (np.cos(theta_grid) * perp1[1] + np.sin(theta_grid) * perp2[1])
    )
    z = (
        center[2]
        + h_grid * axis[2]
        + radius * (np.cos(theta_grid) * perp1[2] + np.sin(theta_grid) * perp2[2])
    )

    return grid_to_mesh(x, y, z)


__all__ = [
    "cone_mesh",
    "cylinder_mesh",
    "ellipsoid_mesh",
    "sphere_mesh",
]
