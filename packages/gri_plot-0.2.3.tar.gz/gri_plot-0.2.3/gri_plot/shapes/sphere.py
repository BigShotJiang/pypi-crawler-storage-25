"""Sphere shape for 3D visualization."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from gri_plot.shapes.meshgen import sphere_mesh
from gri_plot.surfaces import ImplicitShape
from gri_plot.surfaces.mesh import vertices_to_mesh3d

if TYPE_CHECKING:
    from collections.abc import Callable

    import plotly.graph_objects as go
    from numpy.typing import NDArray


class Sphere(ImplicitShape):
    """A 3D sphere defined by center and radius.

    Attributes:
        center_xyz: Center of the sphere in XYZ coordinates.
        radius: Radius of the sphere.
        label: Optional label for legends.
        is_volume: Whether this shape represents a volume or surface.
    """

    def __init__(
        self,
        center_xyz: NDArray[np.floating],
        radius: float,
        label: str | None = None,
        *,
        as_volume: bool = True,
    ) -> None:
        """Initialize the sphere.

        Args:
            center_xyz: Center of the sphere, shape (3,).
            radius: Radius of the sphere (positive).
            label: Optional label for legends.
            as_volume: Keyword-only. If True, interior is solution region.
                If False, boundary is solution locus. Default True.

        Raises:
            ValueError: If radius is not positive.
        """
        self._center = np.asarray(center_xyz, dtype=np.float64)
        if radius <= 0:
            raise ValueError("Radius must be positive")
        self._radius = float(radius)
        self._label = label
        self._is_volume = as_volume

    @property
    def center_xyz(self) -> NDArray[np.floating]:
        """Get the center in XYZ coordinates."""
        return self._center

    @property
    def radius(self) -> float:
        """Get the radius."""
        return self._radius

    @property
    def label(self) -> str | None:
        """Get the label."""
        return self._label

    @property
    def is_volume(self) -> bool:
        """Whether this shape represents a volume (True) or surface (False)."""
        return self._is_volume

    def residual_fn(self, xyz: NDArray[np.floating]) -> NDArray[np.floating]:
        """Compute the residual function for the sphere.

        The residual is distance_from_center - radius, so:
        - 0 on the surface
        - Positive outside
        - Negative inside

        Args:
            xyz: Points to evaluate, shape (..., 3).

        Returns:
            Residual values, shape (...).
        """
        xyz = np.asarray(xyz)
        diff = xyz - self._center
        distance = np.linalg.norm(diff, axis=-1)
        return distance - self._radius

    def to_mesh(
        self,
        resolution: int | None = None,
    ) -> tuple[NDArray[np.floating], NDArray[np.integer]]:
        """Generate mesh vertices and faces.

        Args:
            resolution: Number of samples per dimension. If None, uses 50.

        Returns:
            Tuple of (vertices, faces).
        """
        if resolution is None:
            resolution = 50
        return sphere_mesh(self._center, self._radius, resolution)

    def get_bounds_xyz(
        self,
    ) -> tuple[NDArray[np.floating], NDArray[np.floating]]:
        """Get axis-aligned bounding box in XYZ coordinates.

        Returns:
            Tuple of (min_corner, max_corner).
        """
        offset = np.array([self._radius, self._radius, self._radius])
        return self._center - offset, self._center + offset

    def to_trace(
        self,
        resolution: int | None = None,
        intensity_fn: Callable[[NDArray[np.floating]], NDArray[np.floating]]
        | None = None,
        **kwargs,
    ) -> go.Mesh3d:
        """Generate a Plotly Mesh3d trace.

        Args:
            resolution: Mesh resolution. If None, uses default (50).
            intensity_fn: Optional intensity function for coloring.
            **kwargs: Additional arguments for vertices_to_mesh3d.

        Returns:
            Plotly Mesh3d trace.
        """
        vertices, faces = self.to_mesh(resolution)
        return vertices_to_mesh3d(
            vertices,
            faces,
            intensity_fn=intensity_fn,
            name=self._label,
            **kwargs,
        )

    def __repr__(self) -> str:
        """Return string representation."""
        return f"Sphere(center={self._center}, radius={self._radius})"


__all__ = ["Sphere"]
