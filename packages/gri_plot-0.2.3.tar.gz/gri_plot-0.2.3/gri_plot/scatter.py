"""Simple helper to externalize the plotly scattergram. Make it a one-liner."""

from __future__ import annotations

from collections.abc import Sequence

import numpy as np
import plotly.graph_objects as go


def scatter(*trace_info: Sequence, **kwargs) -> None:
    """Scattergram with x defined or not. kwargs passed to update_layout.

    Pass in info like:
    scatter((y,))
    scatter((y1,), (y2,))
    scatter((y1,), (y2,), layout_args)
    scatter((y1, trace_args), (y2,), layout_args)
    scatter((x,y))
    scatter((x1,y1), (x2,y2))
    scatter((x1,y1), (x2,y2), layout_args)
    scatter((x1,y1), (x2,y2, trace_args), layout_args)

    Args:
        trace_info: sequnces or tuples of sequences. If just single sequences (or
            ndarrays) it plots the sequence as the y. If passed as tuples, uses seq[0]
            for x and seq[1] for y. If a dictionary is passed, it will be passed through
            to scatter as kwargs.
        kwargs: Additional arguments to pass to update_layout like:
            title="Plot Title", yaxis_range=[0,None], xaxis_title="Time (s)"
    """
    traces = _gather_data(trace_info)

    fig = go.Figure()
    fig.add_traces(traces)
    fig.update_layout(template="plotly_dark", **kwargs)
    fig.show()


def _check_xdef(trace_info: Sequence) -> bool:
    """Verify whether all or none have x defined and have only 2 or 3 args."""
    if len(trace_info) == 0:
        raise ValueError("No data passed in")
    # All inputs are sequences of data
    if any(not isinstance(t, Sequence) for t in trace_info):
        raise ValueError("Inputs must be sequences of data like (y,) or (x,y,kwargs)")

    x_def = False
    if len(trace_info[0]) > 1 and isinstance(trace_info[0][1], (Sequence, np.ndarray)):
        x_def = True
    for t in trace_info:
        if x_def:
            if len(t) == 1 or not isinstance(t[1], (Sequence, np.ndarray)):
                raise ValueError("All or no traces must have x defined")
            if len(t) > 3:  # noqa: PLR2004 - trace is (x, y, kwargs)
                raise ValueError("Extra information passed. Should be  (x,y,**args)")
        else:
            if len(t) > 1 and isinstance(t[1], (Sequence | np.ndarray)):
                raise ValueError("All or no traces must have x defined")
            if len(t) > 2:  # noqa: PLR2004 - trace is (y, kwargs)
                raise ValueError("Extra information passed. Should be  (x,y,**args)")
    return x_def


def _gather_data(trace_info: Sequence) -> list[go.Scatter]:
    """Gather all the traces for the plot."""
    x_def = _check_xdef(trace_info)
    traces: list[go.Scatter] = []
    t_len = 2 if x_def else 1
    for idx, t in enumerate(trace_info):
        trace_args = {} if len(t) == t_len else t[-1]
        if "name" not in trace_args:
            trace_args["name"] = f"D{idx}"
        if x_def:
            traces.append(go.Scatter(x=t[0], y=t[1], **trace_args))
        else:
            traces.append(go.Scatter(y=t[0], **trace_args))
    return traces
