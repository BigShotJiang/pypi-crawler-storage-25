"""TDOA (Time Difference of Arrival) hyperboloid surface.

This module provides the TdoaSurface class for visualizing TDOA isosurfaces.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from gri_utils import constants

from gri_plot.surfaces import ImplicitShape, expand_bounds
from gri_plot.surfaces.mesh import field_to_mesh, vertices_to_mesh3d

if TYPE_CHECKING:
    from collections.abc import Callable

    import plotly.graph_objects as go
    from numpy.typing import NDArray


class TdoaSurface(ImplicitShape):
    """TDOA hyperboloid surface where range_1 - range_2 = c * tdoa.

    The surface represents all points where the difference in range to two
    collectors equals the measured TDOA times the speed of light.

    Attributes:
        c1_xyz: First collector position in XYZ coordinates.
        c2_xyz: Second collector position in XYZ coordinates.
        tdoa_seconds: TDOA measurement in seconds (r1 - r2 = c * tdoa).
        bounds_xyz: Bounding box for visualization.
        label: Optional label for legends.
        is_volume: Always False for TDOA surfaces (target on hyperboloid).
    """

    def __init__(
        self,
        c1_xyz: NDArray[np.floating],
        c2_xyz: NDArray[np.floating],
        tdoa_seconds: float,
        bounds_xyz: tuple[NDArray[np.floating], NDArray[np.floating]] | None = None,
        label: str | None = None,
    ) -> None:
        """Initialize the TDOA surface.

        Args:
            c1_xyz: First collector position, shape (3,).
            c2_xyz: Second collector position, shape (3,).
            tdoa_seconds: TDOA in seconds. Positive means signal arrived at
                c1 first (r1 < r2), negative means c2 first.
            bounds_xyz: Optional bounding box for visualization. If None,
                computed automatically from collector positions.
            label: Optional label for legends.
        """
        self._c1 = np.asarray(c1_xyz, dtype=np.float64)
        self._c2 = np.asarray(c2_xyz, dtype=np.float64)
        self._tdoa = float(tdoa_seconds)
        self._label = label

        # Range difference
        self._range_diff = self._tdoa * constants.C

        # Compute default bounds if not provided
        if bounds_xyz is None:
            self._bounds_xyz = self._compute_default_bounds()
        else:
            self._bounds_xyz = (
                np.asarray(bounds_xyz[0], dtype=np.float64),
                np.asarray(bounds_xyz[1], dtype=np.float64),
            )

    def _compute_default_bounds(
        self,
    ) -> tuple[NDArray[np.floating], NDArray[np.floating]]:
        """Compute default bounding box from collector positions.

        The bounds are set to encompass both collectors with padding.
        """
        baseline = np.linalg.norm(self._c2 - self._c1)
        # Extend by 2x baseline in each direction
        padding = baseline * 2

        min_corner = np.minimum(self._c1, self._c2) - padding
        max_corner = np.maximum(self._c1, self._c2) + padding

        return min_corner, max_corner

    @property
    def c1_xyz(self) -> NDArray[np.floating]:
        """Get first collector position."""
        return self._c1

    @property
    def c2_xyz(self) -> NDArray[np.floating]:
        """Get second collector position."""
        return self._c2

    @property
    def tdoa_seconds(self) -> float:
        """Get TDOA in seconds."""
        return self._tdoa

    @property
    def range_difference(self) -> float:
        """Get range difference in meters (r1 - r2)."""
        return self._range_diff

    @property
    def label(self) -> str | None:
        """Get the label."""
        return self._label

    @property
    def is_volume(self) -> bool:
        """TDOA surfaces are not volumes (target on hyperboloid surface)."""
        return False

    def residual_fn(self, xyz: NDArray[np.floating]) -> NDArray[np.floating]:
        """Compute the TDOA residual.

        The residual is (r1 - r2) - (c * tdoa), normalized by baseline,
        so 0 on the surface, positive on the c1 side, negative on the c2 side.

        Args:
            xyz: Points to evaluate, shape (..., 3).

        Returns:
            Residual values, shape (...).
        """
        xyz = np.asarray(xyz)

        r1 = np.linalg.norm(xyz - self._c1, axis=-1)
        r2 = np.linalg.norm(xyz - self._c2, axis=-1)

        # Normalize by baseline for numerical stability
        baseline = np.linalg.norm(self._c2 - self._c1)
        if baseline > 0:
            return (r1 - r2 - self._range_diff) / baseline
        return r1 - r2 - self._range_diff

    def get_bounds_xyz(
        self,
    ) -> tuple[NDArray[np.floating], NDArray[np.floating]]:
        """Get bounding box in XYZ coordinates.

        Returns:
            Tuple of (min_corner, max_corner).
        """
        return self._bounds_xyz

    def to_mesh(
        self,
        resolution: int | None = None,
    ) -> tuple[NDArray[np.floating], NDArray[np.integer]]:
        """Generate mesh vertices and faces.

        Args:
            resolution: Grid resolution. If None, uses field_to_mesh default.

        Returns:
            Tuple of (vertices, faces).
        """
        bounds = expand_bounds(self._bounds_xyz, 1.05)
        if resolution is None:
            return field_to_mesh(self.residual_fn, bounds)
        return field_to_mesh(self.residual_fn, bounds, resolution=resolution)

    def to_trace(
        self,
        resolution: int | None = None,
        intensity_fn: Callable[[NDArray[np.floating]], NDArray[np.floating]]
        | None = None,
        **kwargs,
    ) -> go.Mesh3d:
        """Generate a Plotly Mesh3d trace.

        Args:
            resolution: Grid resolution. If None, uses field_to_mesh default.
            intensity_fn: Optional function to compute vertex intensities for
                coloring. Takes vertices (N, 3) and returns intensities (N,).
                If None, defaults to Z-coordinate coloring.
            **kwargs: Additional arguments for vertices_to_mesh3d.

        Returns:
            Plotly Mesh3d trace.
        """
        vertices, faces = self.to_mesh(resolution)
        return vertices_to_mesh3d(
            vertices,
            faces,
            intensity_fn=intensity_fn,
            name=self._label,
            **kwargs,
        )

    def __repr__(self) -> str:
        """Return string representation."""
        return f"TdoaSurface(c1={self._c1}, c2={self._c2}, tdoa={self._tdoa:.9f}s)"


__all__ = ["TdoaSurface"]
