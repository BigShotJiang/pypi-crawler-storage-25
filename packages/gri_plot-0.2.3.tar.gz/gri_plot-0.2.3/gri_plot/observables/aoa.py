"""AOA (Angle of Arrival) cone surface.

This module provides the AoaSurface class for visualizing AOA measurements.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from gri_plot.shapes.cone import Cone

if TYPE_CHECKING:
    from numpy.typing import NDArray


class AoaSurface(Cone):
    """AOA cone surface representing an angle of arrival measurement.

    The cone extends from the collector in the measured direction. If an
    error radius is specified, a cone with that half-angle is rendered;
    otherwise, a thin cone (line-like) is shown.

    For 1D AOA (azimuth only), use a half-plane or cylinder instead.

    This class inherits from Cone and always has is_volume=True since
    an AOA measurement defines a volume where the target could be.

    Attributes:
        collector_xyz: Collector position in XYZ coordinates.
        direction_xyz: Measured direction (unit vector).
        error_rad: Angular error (half-angle) in radians.
        max_range: Maximum range to extend the cone.
        label: Optional label for legends.
        is_volume: Always True for AOA surfaces.
    """

    def __init__(
        self,
        collector_xyz: NDArray[np.floating],
        direction_xyz: NDArray[np.floating],
        error_rad: float | None = None,
        max_range: float = 1e6,
        label: str | None = None,
    ) -> None:
        """Initialize the AOA surface.

        Args:
            collector_xyz: Collector position, shape (3,).
            direction_xyz: Measured direction (will be normalized), shape (3,).
            error_rad: Angular error (half-angle) in radians. If None or very
                small, renders a thin cone.
            max_range: Maximum range to extend the cone in meters.
            label: Optional label for legends.

        Raises:
            ValueError: If max_range is not positive.
        """
        # Normalize direction
        direction = np.asarray(direction_xyz, dtype=np.float64)
        direction = direction / np.linalg.norm(direction)

        # Minimum half-angle for visualization
        min_angle = 0.01  # ~0.5 degrees
        if error_rad is None or error_rad < min_angle:
            half_angle = min_angle
            self._is_exact = True
        else:
            half_angle = float(error_rad)
            self._is_exact = False

        if max_range <= 0:
            raise ValueError("max_range must be positive")

        # Initialize parent Cone
        super().__init__(
            apex_xyz=np.asarray(collector_xyz, dtype=np.float64),
            axis=direction,
            half_angle=half_angle,
            height=float(max_range),
            label=label,
            as_volume=True,  # AOA is always a volume
        )

    @property
    def is_volume(self) -> bool:
        """AOA surfaces always represent volumes."""
        return True

    @property
    def is_exact(self) -> bool:
        """Whether this represents an exact AOA (no error specified)."""
        return self._is_exact

    # Convenience aliases for AOA-specific terminology
    @property
    def collector_xyz(self) -> NDArray[np.floating]:
        """Get collector position."""
        return self.apex_xyz

    @property
    def direction_xyz(self) -> NDArray[np.floating]:
        """Get measured direction (unit vector)."""
        return self.axis

    @property
    def error_rad(self) -> float:
        """Get angular error in radians."""
        return self.half_angle

    @property
    def max_range(self) -> float:
        """Get maximum range."""
        return self.height

    def __repr__(self) -> str:
        """Return string representation."""
        return (
            f"AoaSurface(collector={self.apex_xyz}, "
            f"direction={self.axis}, error={self.half_angle:.4f}rad)"
        )


__all__ = ["AoaSurface"]
