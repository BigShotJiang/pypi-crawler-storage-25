"""Terrain surface from XYZ grid.

This module provides the TerrainSurface class for visualizing terrain.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from scipy.interpolate import RegularGridInterpolator

from gri_plot.surfaces import ImplicitShape
from gri_plot.surfaces.mesh import vertices_to_mesh3d

if TYPE_CHECKING:
    import plotly.graph_objects as go
    from numpy.typing import NDArray


class TerrainSurface(ImplicitShape):
    """Terrain surface from a grid of XYZ points.

    The terrain is defined by a 2D grid of points in 3D space. This can
    be used to visualize terrain elevation data or any sheet-like surface.

    This is always treated as a surface (is_volume=False) since the target
    is expected to be on the terrain surface, not inside a volume.

    Attributes:
        vertices: Grid vertices, shape (M, N, 3) or (M*N, 3).
        grid_shape: Shape of the grid (M, N).
        label: Optional label for legends.
        is_volume: Always False for terrain surfaces.
    """

    def __init__(
        self,
        vertices: NDArray[np.floating],
        grid_shape: tuple[int, int] | None = None,
        label: str | None = None,
    ) -> None:
        """Initialize the terrain surface.

        Args:
            vertices: Grid vertices. Can be:
                - Shape (M, N, 3): 2D grid of 3D points
                - Shape (M*N, 3): Flattened grid (requires grid_shape)
            grid_shape: Shape of the grid (M, N). Required if vertices is flat.
            label: Optional label for legends.

        Raises:
            ValueError: If vertices shape is invalid or grid_shape is missing.
        """
        vertices = np.asarray(vertices, dtype=np.float64)

        if vertices.ndim == 3:  # noqa: PLR2004 - 3D grid (M, N, 3)
            self._grid_shape = (vertices.shape[0], vertices.shape[1])
            self._vertices_grid = vertices
            self._vertices = vertices.reshape(-1, 3)
        elif vertices.ndim == 2 and vertices.shape[1] == 3:  # noqa: PLR2004 - flat (M*N, 3)
            if grid_shape is None:
                raise ValueError("grid_shape required for flat vertex array")
            self._grid_shape = grid_shape
            self._vertices = vertices
            self._vertices_grid = vertices.reshape(grid_shape[0], grid_shape[1], 3)
        else:
            raise ValueError(
                "vertices must be shape (M, N, 3) or (M*N, 3)",
            )

        if self._vertices.shape[0] != self._grid_shape[0] * self._grid_shape[1]:
            raise ValueError(
                f"Vertex count {self._vertices.shape[0]} does not match "
                f"grid shape {self._grid_shape}",
            )

        self._label = label
        self._faces = self._generate_faces()

        # Set up interpolator for residual_fn
        self._setup_interpolator()

    def _generate_faces(self) -> NDArray[np.integer]:
        """Generate triangular faces for the grid."""
        m, n = self._grid_shape
        faces = []

        for i in range(m - 1):
            for j in range(n - 1):
                idx00 = i * n + j
                idx01 = i * n + (j + 1)
                idx10 = (i + 1) * n + j
                idx11 = (i + 1) * n + (j + 1)

                faces.append([idx00, idx10, idx11])
                faces.append([idx00, idx11, idx01])

        return np.array(faces, dtype=np.int64)

    def _setup_interpolator(self) -> None:
        """Set up interpolator for computing residuals.

        Handles both meshgrid orientations:
        - indexing='xy' (default): x varies along axis 1, y along axis 0
        - indexing='ij': x varies along axis 0, y along axis 1
        """
        # Try to detect orientation by checking which axis has varying x
        x_along_0 = self._vertices_grid[:, 0, 0]
        x_along_1 = self._vertices_grid[0, :, 0]

        # Check which axis has more variation in x
        x_var_0 = np.ptp(x_along_0)  # peak-to-peak along axis 0
        x_var_1 = np.ptp(x_along_1)  # peak-to-peak along axis 1

        if x_var_0 > x_var_1:
            # indexing='ij': x varies along axis 0, y along axis 1
            x_coords = x_along_0
            y_coords = self._vertices_grid[0, :, 1]
            z_values = self._vertices_grid[:, :, 2]
        else:
            # indexing='xy' (default): x varies along axis 1, y along axis 0
            x_coords = x_along_1
            y_coords = self._vertices_grid[:, 0, 1]
            z_values = self._vertices_grid[:, :, 2].T  # Transpose to match

        self._x_coords = x_coords
        self._y_coords = y_coords

        # Create interpolator for z values
        # fill_value=None enables extrapolation (scipy accepts None despite type stubs)
        self._z_interp = RegularGridInterpolator(
            (x_coords, y_coords),
            z_values,
            method="linear",
            bounds_error=False,
            fill_value=None,  # type: ignore[arg-type]
        )

    @property
    def vertices(self) -> NDArray[np.floating]:
        """Get vertices, shape (M*N, 3)."""
        return self._vertices

    @property
    def grid_shape(self) -> tuple[int, int]:
        """Get grid shape (M, N)."""
        return self._grid_shape

    @property
    def label(self) -> str | None:
        """Get the label."""
        return self._label

    @property
    def is_volume(self) -> bool:
        """Terrain surfaces are not volumes (target on terrain surface)."""
        return False

    def residual_fn(self, xyz: NDArray[np.floating]) -> NDArray[np.floating]:
        """Compute the terrain residual (vertical distance from surface).

        The residual is z - z_terrain, so:
        - 0 on the terrain surface
        - Positive above the terrain
        - Negative below the terrain

        Args:
            xyz: Points to evaluate, shape (..., 3).

        Returns:
            Residual values, shape (...).
        """
        xyz = np.asarray(xyz)
        original_shape = xyz.shape[:-1]

        # Flatten for interpolation
        flat_xyz = xyz.reshape(-1, 3)
        xy_points = flat_xyz[:, :2]

        # Interpolate terrain height at each (x, y)
        z_terrain = self._z_interp(xy_points)

        # Residual is actual z minus terrain z
        residual = flat_xyz[:, 2] - z_terrain

        return residual.reshape(original_shape)

    def get_bounds_xyz(
        self,
    ) -> tuple[NDArray[np.floating], NDArray[np.floating]]:
        """Get bounding box in XYZ coordinates.

        Returns:
            Tuple of (min_corner, max_corner).
        """
        return self._vertices.min(axis=0), self._vertices.max(axis=0)

    def to_mesh(
        self,
        resolution: int | None = None,  # noqa: ARG002 - unused, mesh is pre-computed
    ) -> tuple[NDArray[np.floating], NDArray[np.integer]]:
        """Return mesh vertices and faces.

        Args:
            resolution: Unused (mesh is pre-computed from input grid).

        Returns:
            Tuple of (vertices, faces).
        """
        return self._vertices, self._faces

    def to_trace(
        self,
        resolution: int | None = None,  # noqa: ARG002 - unused but required by ABC
        colorscale: str = "earth",
        **kwargs,
    ) -> go.Mesh3d:
        """Generate a Plotly Mesh3d trace.

        Args:
            resolution: Unused (included for ABC compatibility).
            colorscale: Color scale for elevation coloring.
            **kwargs: Additional arguments for vertices_to_mesh3d.

        Returns:
            Plotly Mesh3d trace.
        """
        # Use z-coordinate for intensity if not specified
        if "intensity_fn" not in kwargs and "color" not in kwargs:
            # Default to Z-height intensity (vertices_to_mesh3d does this already)
            kwargs["colorscale"] = colorscale
            kwargs["showscale"] = True

        return vertices_to_mesh3d(
            self._vertices,
            self._faces,
            name=self._label,
            **kwargs,
        )

    @classmethod
    def from_xyz_grids(
        cls,
        x: NDArray[np.floating],
        y: NDArray[np.floating],
        z: NDArray[np.floating],
        label: str | None = None,
    ) -> TerrainSurface:
        """Create terrain from separate X, Y, Z grids.

        Args:
            x: X coordinates, shape (M, N).
            y: Y coordinates, shape (M, N).
            z: Z coordinates, shape (M, N).
            label: Optional label for legends.

        Returns:
            TerrainSurface instance.
        """
        x = np.asarray(x)
        y = np.asarray(y)
        z = np.asarray(z)

        vertices = np.stack([x, y, z], axis=-1)
        return cls(vertices, label=label)

    @classmethod
    def from_elevation_grid(
        cls,
        x_coords: NDArray[np.floating],
        y_coords: NDArray[np.floating],
        elevation: NDArray[np.floating],
        label: str | None = None,
    ) -> TerrainSurface:
        """Create terrain from 1D coordinate arrays and 2D elevation grid.

        Args:
            x_coords: X coordinates, shape (M,).
            y_coords: Y coordinates, shape (N,).
            elevation: Elevation values, shape (M, N).
            label: Optional label for legends.

        Returns:
            TerrainSurface instance.
        """
        x_grid, y_grid = np.meshgrid(x_coords, y_coords, indexing="ij")
        return cls.from_xyz_grids(x_grid, y_grid, elevation, label=label)

    def __repr__(self) -> str:
        """Return string representation."""
        return f"TerrainSurface(grid_shape={self._grid_shape})"


__all__ = ["TerrainSurface"]
