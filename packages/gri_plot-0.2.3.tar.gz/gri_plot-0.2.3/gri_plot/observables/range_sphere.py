"""Range sphere surface for TOA/range observables.

This module provides the RangeSphere class for visualizing range measurements.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from gri_plot.shapes.sphere import Sphere

if TYPE_CHECKING:
    from numpy.typing import NDArray


class RangeSphere(Sphere):
    """Range sphere representing a TOA or direct range measurement.

    The sphere is centered on a collector at the measured range distance.
    This is essentially a Sphere with collector/range semantics.

    This class inherits from Sphere and always has is_volume=True since
    a range measurement defines a volume where the target could be.

    Attributes:
        collector_xyz: Collector position in XYZ coordinates.
        range_m: Range in meters.
        label: Optional label for legends.
        is_volume: Always True for range spheres.
    """

    def __init__(
        self,
        collector_xyz: NDArray,
        range_m: float,
        label: str | None = None,
    ) -> None:
        """Initialize the range sphere.

        Args:
            collector_xyz: Collector position, shape (3,).
            range_m: Range measurement in meters (positive).
            label: Optional label for legends.

        Raises:
            ValueError: If range_m is not positive.
        """
        super().__init__(
            center_xyz=collector_xyz,
            radius=range_m,
            label=label,
            as_volume=True,  # Range sphere is always a volume
        )

    @property
    def is_volume(self) -> bool:
        """Range spheres always represent volumes."""
        return True

    # Convenience aliases for range-specific terminology
    @property
    def collector_xyz(self) -> NDArray:
        """Get collector position."""
        return self.center_xyz

    @property
    def range_m(self) -> float:
        """Get range in meters."""
        return self.radius

    def __repr__(self) -> str:
        """Return string representation."""
        return f"RangeSphere(collector={self.center_xyz}, range={self.radius}m)"


__all__ = ["RangeSphere"]
