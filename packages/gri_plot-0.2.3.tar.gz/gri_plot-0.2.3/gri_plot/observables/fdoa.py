"""FDOA (Frequency Difference of Arrival) iso-Doppler surface.

This module provides the FdoaSurface class for visualizing FDOA measurements.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from gri_utils import constants

from gri_plot.surfaces import ImplicitShape, expand_bounds
from gri_plot.surfaces.mesh import field_to_mesh, vertices_to_mesh3d

if TYPE_CHECKING:
    from collections.abc import Callable

    import plotly.graph_objects as go
    from numpy.typing import NDArray


class FdoaSurface(ImplicitShape):
    """FDOA iso-Doppler surface for frequency difference of arrival.

    The surface represents all points where the difference in Doppler shift
    between two collectors equals the measured FDOA.

    The Doppler shift at collector i is:
        f_doppler_i = f_tx * (v_i . r_hat_i) / c

    where r_hat_i is the unit vector from emitter to collector i.

    The FDOA is then:
        fdoa = f_doppler_1 - f_doppler_2
             = (f_tx / c) * (v_1 . r_hat_1 - v_2 . r_hat_2)

    Attributes:
        c1_xyz: First collector position in XYZ coordinates.
        c2_xyz: Second collector position in XYZ coordinates.
        c1_vel: First collector velocity in XYZ coordinates (m/s).
        c2_vel: Second collector velocity in XYZ coordinates (m/s).
        fdoa_hz: FDOA measurement in Hz.
        freq_hz: Carrier frequency in Hz.
        bounds_xyz: Bounding box for visualization.
        label: Optional label for legends.
        is_volume: Always False for FDOA surfaces (target on iso-doppler surface).
    """

    def __init__(  # noqa: PLR0913 - FDOA requires two positions + two velocities + freq
        self,
        c1_xyz: NDArray[np.floating],
        c2_xyz: NDArray[np.floating],
        c1_vel: NDArray[np.floating],
        c2_vel: NDArray[np.floating],
        fdoa_hz: float,
        freq_hz: float,
        bounds_xyz: tuple[NDArray[np.floating], NDArray[np.floating]] | None = None,
        label: str | None = None,
    ) -> None:
        """Initialize the FDOA surface.

        Args:
            c1_xyz: First collector position, shape (3,).
            c2_xyz: Second collector position, shape (3,).
            c1_vel: First collector velocity, shape (3,).
            c2_vel: Second collector velocity, shape (3,).
            fdoa_hz: FDOA measurement in Hz.
            freq_hz: Carrier frequency in Hz (must be positive).
            bounds_xyz: Optional bounding box for visualization.
            label: Optional label for legends.

        Raises:
            ValueError: If freq_hz is not positive.
        """
        self._c1 = np.asarray(c1_xyz, dtype=np.float64)
        self._c2 = np.asarray(c2_xyz, dtype=np.float64)
        self._v1 = np.asarray(c1_vel, dtype=np.float64)
        self._v2 = np.asarray(c2_vel, dtype=np.float64)
        self._fdoa = float(fdoa_hz)

        if freq_hz <= 0:
            raise ValueError("freq_hz must be positive")
        self._freq = float(freq_hz)

        self._label = label

        # Precompute scaling factor
        self._scale = self._freq / constants.C

        # Compute default bounds if not provided
        if bounds_xyz is None:
            self._bounds_xyz = self._compute_default_bounds()
        else:
            self._bounds_xyz = (
                np.asarray(bounds_xyz[0], dtype=np.float64),
                np.asarray(bounds_xyz[1], dtype=np.float64),
            )

    def _compute_default_bounds(
        self,
    ) -> tuple[NDArray[np.floating], NDArray[np.floating]]:
        """Compute default bounding box from collector positions."""
        baseline = np.linalg.norm(self._c2 - self._c1)
        padding = baseline * 2

        min_corner = np.minimum(self._c1, self._c2) - padding
        max_corner = np.maximum(self._c1, self._c2) + padding

        return min_corner, max_corner

    @property
    def c1_xyz(self) -> NDArray[np.floating]:
        """Get first collector position."""
        return self._c1

    @property
    def c2_xyz(self) -> NDArray[np.floating]:
        """Get second collector position."""
        return self._c2

    @property
    def c1_vel(self) -> NDArray[np.floating]:
        """Get first collector velocity."""
        return self._v1

    @property
    def c2_vel(self) -> NDArray[np.floating]:
        """Get second collector velocity."""
        return self._v2

    @property
    def fdoa_hz(self) -> float:
        """Get FDOA in Hz."""
        return self._fdoa

    @property
    def freq_hz(self) -> float:
        """Get carrier frequency in Hz."""
        return self._freq

    @property
    def label(self) -> str | None:
        """Get the label."""
        return self._label

    @property
    def is_volume(self) -> bool:
        """FDOA surfaces are not volumes (target on iso-doppler surface)."""
        return False

    def residual_fn(self, xyz: NDArray[np.floating]) -> NDArray[np.floating]:
        """Compute the FDOA residual.

        The residual is the computed FDOA minus the measured FDOA,
        normalized by the maximum possible FDOA for numerical stability.

        Args:
            xyz: Points to evaluate, shape (..., 3).

        Returns:
            Residual values, shape (...).
        """
        xyz = np.asarray(xyz)

        # Unit vectors from emitter to collectors
        diff1 = self._c1 - xyz
        diff2 = self._c2 - xyz

        r1 = np.linalg.norm(diff1, axis=-1, keepdims=True)
        r2 = np.linalg.norm(diff2, axis=-1, keepdims=True)

        # Avoid division by zero
        r1 = np.maximum(r1, 1e-10)
        r2 = np.maximum(r2, 1e-10)

        r_hat_1 = diff1 / r1
        r_hat_2 = diff2 / r2

        # Doppler shifts (negative because we're measuring approaching/receding)
        # When collector moves toward emitter (positive v.r_hat), frequency increases
        doppler_1 = self._scale * np.einsum("i,...i->...", self._v1, r_hat_1)
        doppler_2 = self._scale * np.einsum("i,...i->...", self._v2, r_hat_2)

        computed_fdoa = doppler_1 - doppler_2

        # Normalize by maximum possible FDOA (based on velocity magnitudes)
        max_fdoa = self._scale * (np.linalg.norm(self._v1) + np.linalg.norm(self._v2))
        if max_fdoa > 0:
            return (computed_fdoa - self._fdoa) / max_fdoa
        return computed_fdoa - self._fdoa

    def get_bounds_xyz(
        self,
    ) -> tuple[NDArray[np.floating], NDArray[np.floating]]:
        """Get bounding box in XYZ coordinates.

        Returns:
            Tuple of (min_corner, max_corner).
        """
        return self._bounds_xyz

    def to_mesh(
        self,
        resolution: int | None = None,
    ) -> tuple[NDArray[np.floating], NDArray[np.integer]]:
        """Generate mesh vertices and faces.

        Args:
            resolution: Grid resolution. If None, uses field_to_mesh default.

        Returns:
            Tuple of (vertices, faces).
        """
        bounds = expand_bounds(self._bounds_xyz, 1.05)
        if resolution is None:
            return field_to_mesh(self.residual_fn, bounds)
        return field_to_mesh(self.residual_fn, bounds, resolution=resolution)

    def to_trace(
        self,
        resolution: int | None = None,
        intensity_fn: Callable[[NDArray[np.floating]], NDArray[np.floating]]
        | None = None,
        **kwargs,
    ) -> go.Mesh3d:
        """Generate a Plotly Mesh3d trace.

        Args:
            resolution: Grid resolution. If None, uses field_to_mesh default.
            intensity_fn: Optional function to compute vertex intensities for
                coloring. Takes vertices (N, 3) and returns intensities (N,).
                If None, defaults to Z-coordinate coloring.
            **kwargs: Additional arguments for vertices_to_mesh3d.

        Returns:
            Plotly Mesh3d trace.
        """
        vertices, faces = self.to_mesh(resolution)
        return vertices_to_mesh3d(
            vertices,
            faces,
            intensity_fn=intensity_fn,
            name=self._label,
            **kwargs,
        )

    def __repr__(self) -> str:
        """Return string representation."""
        return (
            f"FdoaSurface(c1={self._c1}, c2={self._c2}, "
            f"fdoa={self._fdoa}Hz, freq={self._freq}Hz)"
        )


__all__ = ["FdoaSurface"]
