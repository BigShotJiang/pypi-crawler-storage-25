"""Line of Sight (LOS) ray/cylinder surface.

This module provides the LosSurface class for visualizing line of sight.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
import plotly.graph_objects as go

from gri_plot.shapes.cylinder import Cylinder

if TYPE_CHECKING:
    from numpy.typing import NDArray


class LosSurface(Cylinder):
    """Line of Sight surface rendered as a thin cylinder.

    Represents a line of sight from a collector in a given direction,
    optionally with a width to indicate uncertainty.

    This class inherits from Cylinder and always has is_volume=True since
    a LOS measurement defines a volume where the target could be.

    Attributes:
        start_xyz: Start point (collector position) in XYZ coordinates.
        direction_xyz: Direction of the LOS (unit vector).
        length: Length of the LOS ray.
        width: Width of the cylinder (for visualization).
        label: Optional label for legends.
        is_volume: Always True for LOS surfaces.
    """

    def __init__(
        self,
        start_xyz: NDArray[np.floating],
        direction_xyz: NDArray[np.floating],
        length: float,
        width: float | None = None,
        label: str | None = None,
    ) -> None:
        """Initialize the LOS surface.

        Args:
            start_xyz: Start point, shape (3,).
            direction_xyz: Direction (will be normalized), shape (3,).
            length: Length of the LOS in meters.
            width: Width of the cylinder. If None, uses length/500.
            label: Optional label for legends.

        Raises:
            ValueError: If length is not positive.
        """
        start = np.asarray(start_xyz, dtype=np.float64)
        direction = np.asarray(direction_xyz, dtype=np.float64)
        direction = direction / np.linalg.norm(direction)

        if length <= 0:
            raise ValueError("length must be positive")

        radius = length / 500 if width is None else float(width)

        # Store start point for convenience properties
        self._start = start

        # Cylinder is centered, so compute center point
        center = start + (length / 2) * direction

        # Initialize parent Cylinder
        super().__init__(
            center_xyz=center,
            axis=direction,
            radius=radius,
            height=float(length),
            label=label,
            as_volume=True,  # LOS is always a volume
        )

    @property
    def is_volume(self) -> bool:
        """LOS surfaces always represent volumes."""
        return True

    # Convenience aliases for LOS-specific terminology
    @property
    def start_xyz(self) -> NDArray[np.floating]:
        """Get start point."""
        return self._start

    @property
    def end_xyz(self) -> NDArray[np.floating]:
        """Get end point."""
        return self._start + self.height * self.axis

    @property
    def direction_xyz(self) -> NDArray[np.floating]:
        """Get direction (unit vector)."""
        return self.axis

    @property
    def length(self) -> float:
        """Get length."""
        return self.height

    @property
    def width(self) -> float:
        """Get width."""
        return self.radius

    def to_line_trace(
        self,
        color: str | None = None,
        width: int = 2,
        **kwargs,
    ) -> go.Scatter3d:
        """Generate a simple line trace (for cleaner visualization).

        Args:
            color: Line color.
            width: Line width.
            **kwargs: Additional arguments for go.Scatter3d.

        Returns:
            Plotly Scatter3d trace.
        """
        end = self.end_xyz
        trace_kwargs: dict = {
            "x": [self._start[0], end[0]],
            "y": [self._start[1], end[1]],
            "z": [self._start[2], end[2]],
            "mode": "lines",
            "line": {"width": width},
        }

        if color is not None:
            trace_kwargs["line"]["color"] = color

        if self.label:
            trace_kwargs["name"] = self.label
            trace_kwargs["showlegend"] = True

        trace_kwargs.update(kwargs)
        return go.Scatter3d(**trace_kwargs)

    def __repr__(self) -> str:
        """Return string representation."""
        return (
            f"LosSurface(start={self._start}, direction={self.axis}, "
            f"length={self.height})"
        )


__all__ = ["LosSurface"]
