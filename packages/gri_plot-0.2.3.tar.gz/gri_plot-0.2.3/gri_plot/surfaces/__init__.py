"""Surface ABC and base utilities for 3D visualization.

This module defines the ImplicitShape ABC that all plottable shapes must implement.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    import plotly.graph_objects as go
    from numpy.typing import NDArray


class ImplicitShape(ABC):
    """Base class for all plottable 3D shapes and observables.

    This ABC provides a unified interface for shapes that can be:
    - Evaluated via an implicit function (residual_fn)
    - Rendered as a Plotly Mesh3d trace
    - Used in intersection calculations

    Residual convention:
        - residual < 0: inside the shape
        - residual = 0: on the boundary
        - residual > 0: outside the shape

    The is_volume property determines intersection behavior:
        - True: interior (residual < 0) is the solution region
        - False: boundary (residual = 0) is the solution locus
    """

    @property
    @abstractmethod
    def is_volume(self) -> bool:
        """Whether this shape represents a volume (True) or surface (False).

        Volumes contribute to intersection everywhere inside (residual < 0).
        Surfaces contribute based on distance from boundary (|residual|).
        """
        ...

    @property
    @abstractmethod
    def label(self) -> str | None:
        """Optional label for the shape in legends."""
        ...

    @abstractmethod
    def residual_fn(self, xyz: NDArray[np.floating]) -> NDArray[np.floating]:
        """Evaluate the implicit function at given points.

        Args:
            xyz: Points to evaluate, shape (..., 3).

        Returns:
            Residual values, shape (...). Negative inside, zero on boundary,
            positive outside.
        """
        ...

    @abstractmethod
    def get_bounds_xyz(
        self,
    ) -> tuple[NDArray[np.floating], NDArray[np.floating]]:
        """Get axis-aligned bounding box in XYZ coordinates.

        Returns:
            Tuple of (min_corner, max_corner), each shape (3,).
        """
        ...

    @abstractmethod
    def to_mesh(
        self,
        resolution: int | None = None,
    ) -> tuple[NDArray[np.floating], NDArray[np.integer]]:
        """Generate mesh vertices and faces.

        Args:
            resolution: Number of samples per dimension. If None, uses
                shape-specific default.

        Returns:
            Tuple of (vertices, faces) where:
                - vertices: shape (N, 3) array of vertex positions
                - faces: shape (M, 3) array of triangle indices
        """
        ...

    @abstractmethod
    def to_trace(
        self,
        resolution: int | None = None,
        **kwargs,
    ) -> go.Mesh3d:
        """Generate a Plotly Mesh3d trace for visualization.

        Args:
            resolution: Mesh resolution. If None, uses shape-specific default.
            **kwargs: Additional arguments for the trace.

        Returns:
            Plotly Mesh3d trace.
        """
        ...

    def contains(self, xyz: NDArray[np.floating]) -> NDArray[np.bool_]:
        """Test if points are inside the shape.

        Args:
            xyz: Points to test, shape (..., 3).

        Returns:
            Boolean array, shape (...). True if inside (residual < 0).
        """
        return self.residual_fn(xyz) < 0


def merge_bounds(
    *bounds: tuple[NDArray[np.floating], NDArray[np.floating]],
) -> tuple[NDArray[np.floating], NDArray[np.floating]]:
    """Merge multiple bounding boxes into one.

    Args:
        *bounds: Tuples of (min_corner, max_corner), each shape (3,).

    Returns:
        Tuple of (min_corner, max_corner) encompassing all inputs.

    Raises:
        ValueError: If no bounds are provided.
    """
    if not bounds:
        raise ValueError("At least one bounds tuple required")

    all_mins = np.array([b[0] for b in bounds])
    all_maxs = np.array([b[1] for b in bounds])

    return all_mins.min(axis=0), all_maxs.max(axis=0)


def expand_bounds(
    bounds: tuple[NDArray[np.floating], NDArray[np.floating]],
    factor: float = 1.1,
) -> tuple[NDArray[np.floating], NDArray[np.floating]]:
    """Expand bounds by a factor around their center.

    Args:
        bounds: Tuple of (min_corner, max_corner), each shape (3,).
        factor: Expansion factor (1.0 = no change, 1.1 = 10% expansion).

    Returns:
        Expanded bounds tuple.
    """
    min_corner, max_corner = np.asarray(bounds[0]), np.asarray(bounds[1])
    center = (min_corner + max_corner) / 2
    half_extent = (max_corner - min_corner) / 2

    return center - half_extent * factor, center + half_extent * factor


from .intersection import IntersectionField  # noqa: E402

__all__ = [
    "ImplicitShape",
    "IntersectionField",
    "expand_bounds",
    "merge_bounds",
]
