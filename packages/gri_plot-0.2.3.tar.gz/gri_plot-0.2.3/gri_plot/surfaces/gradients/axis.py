"""Axis-based intensity functions."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from collections.abc import Callable

    from numpy.typing import NDArray


def axis_value(
    axis: int = 2,
) -> Callable[[NDArray[np.floating]], NDArray[np.floating]]:
    """Create function that returns raw axis coordinate value.

    Args:
        axis: Which axis index (0, 1, or 2 for X, Y, Z respectively).

    Returns:
        Function that maps vertices (N, 3) to coordinate values (N,).

    Example::

        # Color vertices by their Z coordinate
        intensity_fn = axis_value(2)
        intensities = intensity_fn(vertices)
    """
    if axis not in (0, 1, 2):
        msg = f"axis must be 0, 1, or 2, got {axis}"
        raise ValueError(msg)

    def fn(vertices: NDArray[np.floating]) -> NDArray[np.floating]:
        return vertices[:, axis]

    return fn


def distance_from_axis(
    axis: int = 2,
    center: float = 0.0,
) -> Callable[[NDArray[np.floating]], NDArray[np.floating]]:
    """Create function that computes distance from an axis value.

    This produces symmetric coloring around a reference value. Useful for
    showing distance from a ground plane (Z=0) or similar reference.

    Args:
        axis: Which axis index (0, 1, or 2 for X, Y, Z respectively).
        center: The reference value on that axis.

    Returns:
        Function that maps vertices (N, 3) to |axis_value - center| (N,).

    Example::

        # Color by distance from ground (Z=0)
        intensity_fn = distance_from_axis(2, center=0.0)

        # Color by distance from X=1000
        intensity_fn = distance_from_axis(0, center=1000.0)
    """
    if axis not in (0, 1, 2):
        msg = f"axis must be 0, 1, or 2, got {axis}"
        raise ValueError(msg)

    def fn(vertices: NDArray[np.floating]) -> NDArray[np.floating]:
        return np.abs(vertices[:, axis] - center)

    return fn


__all__ = ["axis_value", "distance_from_axis"]
