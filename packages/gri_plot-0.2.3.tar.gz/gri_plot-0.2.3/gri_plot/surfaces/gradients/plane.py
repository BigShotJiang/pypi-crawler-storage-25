"""Plane-based intensity functions."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from collections.abc import Callable

    from numpy.typing import NDArray


def distance_from_plane(
    normal: NDArray[np.floating],
    point_on_plane: NDArray[np.floating],
) -> Callable[[NDArray[np.floating]], NDArray[np.floating]]:
    """Create function that computes absolute distance from a plane.

    The plane is defined by a normal vector and a point on the plane.

    Args:
        normal: Plane normal vector (will be normalized), shape (3,).
        point_on_plane: Any point on the plane, shape (3,).

    Returns:
        Function that maps vertices (N, 3) to absolute distances (N,).

    Example::

        # Color by height above ground (horizontal plane at Z=0)
        intensity_fn = distance_from_plane(
            normal=np.array([0, 0, 1]),
            point_on_plane=np.array([0, 0, 0]),
        )

        # Color by distance from a tilted reference plane
        intensity_fn = distance_from_plane(
            normal=np.array([1, 1, 1]),  # Will be normalized
            point_on_plane=center_xyz,
        )
    """
    normal = np.asarray(normal, dtype=np.float64)
    normal = normal / np.linalg.norm(normal)
    point_on_plane = np.asarray(point_on_plane, dtype=np.float64)
    d = -np.dot(normal, point_on_plane)

    def fn(vertices: NDArray[np.floating]) -> NDArray[np.floating]:
        return np.abs(np.dot(vertices, normal) + d)

    return fn


__all__ = ["distance_from_plane"]
