"""Point-based intensity functions."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from collections.abc import Callable

    from numpy.typing import NDArray


def distance_from_point(
    point: NDArray[np.floating],
) -> Callable[[NDArray[np.floating]], NDArray[np.floating]]:
    """Create function that computes Euclidean distance from a point.

    Args:
        point: Reference point, shape (3,).

    Returns:
        Function that maps vertices (N, 3) to distances (N,).

    Example::

        # Color by distance from origin
        intensity_fn = distance_from_point(np.array([0, 0, 0]))

        # Color by distance from sensor location
        intensity_fn = distance_from_point(sensor_xyz)
    """
    point = np.asarray(point, dtype=np.float64)

    def fn(vertices: NDArray[np.floating]) -> NDArray[np.floating]:
        return np.linalg.norm(vertices - point, axis=1)

    return fn


__all__ = ["distance_from_point"]
