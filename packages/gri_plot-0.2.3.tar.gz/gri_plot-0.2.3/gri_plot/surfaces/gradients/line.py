"""Line-based intensity functions."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from collections.abc import Callable

    from numpy.typing import NDArray


def distance_from_line(
    point1: NDArray[np.floating],
    point2: NDArray[np.floating],
) -> Callable[[NDArray[np.floating]], NDArray[np.floating]]:
    """Create function that computes perpendicular distance from an infinite line.

    The line extends infinitely in both directions through the two points.

    Args:
        point1: First point on line, shape (3,).
        point2: Second point on line, shape (3,).

    Returns:
        Function that maps vertices (N, 3) to perpendicular distances (N,).

    Example::

        # Color by distance from baseline between two collectors
        intensity_fn = distance_from_line(collector1_xyz, collector2_xyz)
    """
    p1 = np.asarray(point1, dtype=np.float64)
    p2 = np.asarray(point2, dtype=np.float64)
    line_vec = p2 - p1
    line_len = np.linalg.norm(line_vec)
    line_dir = line_vec / line_len

    def fn(vertices: NDArray[np.floating]) -> NDArray[np.floating]:
        to_vert = vertices - p1
        # Project onto line direction
        proj_len = np.dot(to_vert, line_dir)
        proj_point = p1 + np.outer(proj_len, line_dir)
        return np.linalg.norm(vertices - proj_point, axis=1)

    return fn


def distance_from_line_segment(
    point1: NDArray[np.floating],
    point2: NDArray[np.floating],
) -> Callable[[NDArray[np.floating]], NDArray[np.floating]]:
    """Create function that computes distance from a line segment.

    Unlike distance_from_line, this clamps to the segment endpoints.
    Points beyond the endpoints measure distance to the nearest endpoint.

    Args:
        point1: Start of segment, shape (3,).
        point2: End of segment, shape (3,).

    Returns:
        Function that maps vertices (N, 3) to distances (N,).

    Example::

        # Color by distance from a finite baseline segment
        intensity_fn = distance_from_line_segment(start_xyz, end_xyz)
    """
    p1 = np.asarray(point1, dtype=np.float64)
    p2 = np.asarray(point2, dtype=np.float64)
    line_vec = p2 - p1
    line_len_sq = np.dot(line_vec, line_vec)

    def fn(vertices: NDArray[np.floating]) -> NDArray[np.floating]:
        to_vert = vertices - p1
        # Parameter t along segment, clamped to [0, 1]
        t = np.dot(to_vert, line_vec) / line_len_sq
        t = np.clip(t, 0, 1)
        proj_point = p1 + np.outer(t, line_vec)
        return np.linalg.norm(vertices - proj_point, axis=1)

    return fn


__all__ = ["distance_from_line", "distance_from_line_segment"]
