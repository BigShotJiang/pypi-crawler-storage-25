"""Intensity functions for mesh coloring.

This module provides factory functions that create intensity calculators
for coloring 3D mesh vertices. Each function returns a callable that takes
a vertex array and returns intensity values.

Example::

    from gri_plot.surfaces.gradients import distance_from_axis, distance_from_line
    from gri_plot.surfaces.mesh import vertices_to_mesh3d

    # Color by distance from Z=0 (axis 2)
    trace = vertices_to_mesh3d(
        verts, faces,
        intensity_fn=distance_from_axis(2, center=0.0),
        colorbar_title="|Z| (m)",
    )

    # Color by distance from baseline between two collectors
    trace = vertices_to_mesh3d(
        verts, faces,
        intensity_fn=distance_from_line(c1, c2),
        colorbar_title="Baseline distance (m)",
    )
"""

from .axis import axis_value, distance_from_axis
from .line import distance_from_line, distance_from_line_segment
from .plane import distance_from_plane
from .point import distance_from_point

__all__ = [
    "axis_value",
    "distance_from_axis",
    "distance_from_line",
    "distance_from_line_segment",
    "distance_from_plane",
    "distance_from_point",
]
