"""Intersection field for visualizing where multiple implicit shapes meet.

This module provides the IntersectionField class for highlighting regions
where multiple implicit shapes intersect. The intersection is computed using
Euclidean distance in residual space, giving a smooth tube-like volume around
the intersection curve/region.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

# Import directly to avoid circular import
from gri_plot.surfaces import merge_bounds

if TYPE_CHECKING:
    from gri_plot.surfaces import ImplicitShape

if TYPE_CHECKING:
    from collections.abc import Sequence

    from numpy.typing import NDArray


class IntersectionField:
    """Combined field showing where multiple implicit shapes intersect.

    Computes the Euclidean distance to the intersection of multiple shapes.
    For surfaces, this is sqrt(sum of squared residuals), giving a smooth
    tube-like volume around the intersection curve. A radius parameter
    controls the tube thickness.

    Shapes are treated differently based on their is_volume property:
    - Surfaces (is_volume=False): Use |residual| as distance to surface
    - Volumes (is_volume=True): Use max(0, residual) as distance outside

    Attributes:
        shapes: The implicit shapes being intersected.
        radius: Tube radius - distance from intersection where residual = 0.
    """

    def __init__(
        self,
        shapes: Sequence[ImplicitShape],
        radius: float | None = None,
        # Legacy parameters for backward compatibility
        threshold: float | None = None,
        steepness: float | None = None,
    ) -> None:
        """Initialize the intersection field.

        Args:
            shapes: Sequence of ImplicitShape objects to intersect.
                Must have at least 2 shapes.
            radius: Tube radius around the intersection. Points within this
                distance of the intersection curve have negative residual.
                If None, auto-computed as 5% of bounds diagonal.
            threshold: Deprecated, use radius instead.
            steepness: Deprecated, ignored.

        Raises:
            ValueError: If fewer than 2 shapes provided.
        """
        if len(shapes) < 2:  # noqa: PLR2004 - intersection requires >= 2 shapes
            raise ValueError("IntersectionField requires at least 2 shapes")

        self._shapes = list(shapes)

        # Compute characteristic scale from bounds
        bounds = self._compute_bounds()
        extent = bounds[1] - bounds[0]
        self._scale = float(np.linalg.norm(extent))
        if self._scale == 0:
            self._scale = 1.0

        # Handle radius - either explicit or auto-computed
        # The radius is in "residual space" - the same units as residual_fn outputs.
        # For normalized residuals (like TDOA), typical values are 0.01-0.5.
        # For spatial residuals (like distance to sphere), values are in meters.
        if radius is not None:
            self._radius = float(radius)
        else:
            # Default: 0.1 in residual space
            # This works well for normalized residuals (TDOA, etc.)
            # For spatial residuals, user should specify radius explicitly
            self._radius = 0.1

        # Keep for backward compatibility (though not used in new approach)
        self._threshold = threshold if threshold is not None else 1.5
        self._steepness = steepness if steepness is not None else 9.0

        self._label: str | None = None

    @property
    def shapes(self) -> list[ImplicitShape]:
        """Get the list of shapes."""
        return self._shapes

    # Backward compatibility alias
    @property
    def surfaces(self) -> list[ImplicitShape]:
        """Get the list of shapes (deprecated, use shapes instead)."""
        return self._shapes

    @property
    def radius(self) -> float:
        """Get the tube radius."""
        return self._radius

    @property
    def threshold(self) -> float:
        """Get the threshold value (deprecated)."""
        return self._threshold

    @property
    def steepness(self) -> float:
        """Get the steepness parameter (deprecated)."""
        return self._steepness

    @property
    def label(self) -> str | None:
        """Get the optional label."""
        return self._label

    @label.setter
    def label(self, value: str | None) -> None:
        """Set the label."""
        self._label = value

    def distance_to_intersection(
        self,
        xyz: NDArray[np.floating],
    ) -> NDArray[np.floating]:
        """Compute Euclidean distance to the intersection.

        For surfaces, computes sqrt(sum of squared residuals), which gives
        the distance to the intersection curve/region in residual space.

        For volumes, uses max(0, residual) so points inside contribute 0.

        Args:
            xyz: Points to evaluate, shape (..., 3).

        Returns:
            Distance values, shape (...). Zero exactly on the intersection,
            positive elsewhere.
        """
        xyz = np.asarray(xyz)
        sum_sq = np.zeros(xyz.shape[:-1], dtype=np.float64)

        for shape in self._shapes:
            residual = shape.residual_fn(xyz)

            if shape.is_volume:
                # Volume: only count distance if outside (residual > 0)
                distance = np.maximum(0.0, residual)
            else:
                # Surface: distance is |residual|
                distance = np.abs(residual)

            sum_sq += distance * distance

        return np.sqrt(sum_sq)

    def residual_fn(self, xyz: NDArray[np.floating]) -> NDArray[np.floating]:
        """Compute the intersection field residual.

        Returns distance_to_intersection - radius, so:
        - Negative inside the tube (within radius of intersection)
        - Zero on the tube surface
        - Positive outside the tube

        Args:
            xyz: Points to evaluate, shape (..., 3).

        Returns:
            Residual values, shape (...).
        """
        return self.distance_to_intersection(xyz) - self._radius

    # Keep for backward compatibility
    def combined_closeness(self, xyz: NDArray[np.floating]) -> NDArray[np.floating]:
        """Compute closeness to intersection (deprecated).

        This method is kept for backward compatibility but now uses the
        Euclidean distance approach internally.

        Args:
            xyz: Points to evaluate, shape (..., 3).

        Returns:
            Closeness values based on distance to intersection.
        """
        distance = self.distance_to_intersection(xyz)
        # Convert distance to closeness using exponential falloff
        # Normalize by radius so closeness ~ 1 at the intersection
        return np.exp(-distance / self._radius)

    def _compute_bounds(
        self,
    ) -> tuple[NDArray[np.floating], NDArray[np.floating]]:
        """Compute combined bounding box from all shapes."""
        all_bounds = [s.get_bounds_xyz() for s in self._shapes]
        return merge_bounds(*all_bounds)

    def get_bounds_xyz(
        self,
    ) -> tuple[NDArray[np.floating], NDArray[np.floating]]:
        """Get combined bounding box from all shapes.

        Returns:
            Tuple of (min_corner, max_corner) encompassing all shapes.
        """
        return self._compute_bounds()


__all__ = ["IntersectionField"]
