"""Frame definitions and coordinate transformations.

This module provides coordinate frame handling for 3D visualization using
gri-utils for coordinate conversions.
"""

from __future__ import annotations

from enum import Enum
from typing import TYPE_CHECKING, NamedTuple

import numpy as np
from gri_utils.conversion import get_enu, lla_to_xyz, translate_enu, xyz_to_lla

if TYPE_CHECKING:
    from numpy.typing import NDArray


class Frame(Enum):
    """Coordinate frame for 3D visualization.

    Attributes:
        XYZ: Earth-Centered Earth-Fixed (ECEF) Cartesian coordinates in meters.
        ENU: East-North-Up local tangent plane coordinates in meters.
        LLA: Latitude, Longitude, Altitude (degrees, degrees, meters).
    """

    XYZ = "xyz"
    ENU = "enu"
    LLA = "lla"


class Bounds(NamedTuple):
    """Axis-aligned bounding box in a specific frame.

    Attributes:
        min_corner: Minimum corner of the bounding box, shape (3,).
        max_corner: Maximum corner of the bounding box, shape (3,).
        frame: Coordinate frame of the bounds.
        origin_xyz: Origin in XYZ coordinates, required for ENU frame.
    """

    min_corner: NDArray[np.floating]
    max_corner: NDArray[np.floating]
    frame: Frame = Frame.XYZ
    origin_xyz: NDArray[np.floating] | None = None


class FrameTransformer:
    """Transforms coordinates between frames.

    All internal computation is done in XYZ (ECEF). This class handles
    conversion to/from the display frame.

    Attributes:
        display_frame: Target frame for visualization.
        origin_xyz: Origin for ENU frame in XYZ coordinates.
    """

    def __init__(
        self,
        display_frame: Frame = Frame.XYZ,
        origin_xyz: NDArray[np.floating] | None = None,
    ) -> None:
        """Initialize the frame transformer.

        Args:
            display_frame: Target frame for visualization.
            origin_xyz: Origin in XYZ, required if display_frame is ENU.

        Raises:
            ValueError: If display_frame is ENU but origin_xyz is not provided.
        """
        if display_frame == Frame.ENU and origin_xyz is None:
            raise ValueError("origin_xyz is required for ENU display frame")

        self.display_frame = display_frame
        self.origin_xyz = np.asarray(origin_xyz) if origin_xyz is not None else None

    def to_display(self, xyz: NDArray[np.floating]) -> NDArray[np.floating]:
        """Transform XYZ coordinates to display frame.

        Args:
            xyz: Coordinates in XYZ (ECEF), shape (..., 3).

        Returns:
            Coordinates in display frame, shape (..., 3).
        """
        xyz = np.asarray(xyz)

        if self.display_frame == Frame.XYZ:
            return xyz
        if self.display_frame == Frame.ENU:
            if self.origin_xyz is None:  # pragma: no cover
                raise RuntimeError("origin_xyz required for ENU frame")
            return get_enu(self.origin_xyz, xyz)
        if self.display_frame == Frame.LLA:
            return xyz_to_lla(xyz)
        raise ValueError(f"Unknown display frame: {self.display_frame}")

    def from_display(self, coords: NDArray[np.floating]) -> NDArray[np.floating]:
        """Transform display frame coordinates to XYZ.

        Args:
            coords: Coordinates in display frame, shape (..., 3).

        Returns:
            Coordinates in XYZ (ECEF), shape (..., 3).
        """
        coords = np.asarray(coords)

        if self.display_frame == Frame.XYZ:
            return coords
        if self.display_frame == Frame.ENU:
            if self.origin_xyz is None:  # pragma: no cover
                raise RuntimeError("origin_xyz required for ENU frame")
            return translate_enu(self.origin_xyz, coords)
        if self.display_frame == Frame.LLA:
            return lla_to_xyz(coords)
        raise ValueError(f"Unknown display frame: {self.display_frame}")

    def transform_bounds(self, bounds_xyz: tuple[NDArray, NDArray]) -> Bounds:
        """Transform XYZ bounds to display frame.

        For non-linear transforms (LLA), this samples the bounding box to
        find the actual extent in the display frame.

        Args:
            bounds_xyz: Tuple of (min_corner, max_corner) in XYZ.

        Returns:
            Bounds in the display frame.
        """
        min_xyz, max_xyz = np.asarray(bounds_xyz[0]), np.asarray(bounds_xyz[1])

        if self.display_frame == Frame.XYZ:
            return Bounds(min_xyz, max_xyz, Frame.XYZ, None)

        if self.display_frame == Frame.ENU:
            min_enu = self.to_display(min_xyz)
            max_enu = self.to_display(max_xyz)
            # Ensure min < max
            actual_min = np.minimum(min_enu, max_enu)
            actual_max = np.maximum(min_enu, max_enu)
            return Bounds(actual_min, actual_max, Frame.ENU, self.origin_xyz)

        if self.display_frame == Frame.LLA:
            # Sample corners of the bounding box
            corners = np.array(
                [
                    [min_xyz[0], min_xyz[1], min_xyz[2]],
                    [min_xyz[0], min_xyz[1], max_xyz[2]],
                    [min_xyz[0], max_xyz[1], min_xyz[2]],
                    [min_xyz[0], max_xyz[1], max_xyz[2]],
                    [max_xyz[0], min_xyz[1], min_xyz[2]],
                    [max_xyz[0], min_xyz[1], max_xyz[2]],
                    [max_xyz[0], max_xyz[1], min_xyz[2]],
                    [max_xyz[0], max_xyz[1], max_xyz[2]],
                ],
            )
            lla_corners = self.to_display(corners)
            return Bounds(
                lla_corners.min(axis=0),
                lla_corners.max(axis=0),
                Frame.LLA,
                None,
            )

        raise ValueError(f"Unknown display frame: {self.display_frame}")

    def get_axis_labels(self) -> tuple[str, str, str]:
        """Get axis labels for the display frame.

        Returns:
            Tuple of (x_label, y_label, z_label) for the display frame.
        """
        if self.display_frame == Frame.XYZ:
            return ("X (m)", "Y (m)", "Z (m)")
        if self.display_frame == Frame.ENU:
            return ("East (m)", "North (m)", "Up (m)")
        if self.display_frame == Frame.LLA:
            return ("Latitude (deg)", "Longitude (deg)", "Altitude (m)")
        raise ValueError(f"Unknown display frame: {self.display_frame}")
