"""2D map/plot figure builder for contours, bands, and markers.

Provides FigureMap for composing 2D visualizations of observable isochrones,
uncertainty bands, and point markers. Supports satellite map backgrounds
(Plotly Scattermap with ArcGIS imagery) or blank ENU/LLA axis plots.

Example::

    from gri_plot import FigureMap, MapStyle

    fig = FigureMap(title="TDOA Isochrones")
    fig.add_contours(tdoa_contours_xyz, color="#1f77b4", label="TDOA 1-2")
    fig.add_band(tdoa_contours_xyz, width_m=500, color="#1f77b4")
    fig.add_markers(collectors_xyz, labels=["C1", "C2", "C3", "C4"])
    fig.show()
"""

from __future__ import annotations

import enum
import math
from typing import TYPE_CHECKING

import numpy as np
import plotly.graph_objects as go
from gri_utils.conversion import get_enu, xyz_to_lla

from .figure3d import DEFAULT_COLORS

if TYPE_CHECKING:
    from collections.abc import Sequence

    from numpy.typing import NDArray


class MapStyle(enum.Enum):
    """Display style for FigureMap.

    Attributes:
        SATELLITE: ArcGIS World Imagery satellite tiles (Scattermap).
        BLANK: Plain axes with ENU or LLA coordinates (Scatter).
    """

    SATELLITE = "satellite"
    BLANK = "blank"


def _hex_to_rgba(hex_color: str, alpha: float) -> str:
    """Convert hex color to rgba string."""
    h = hex_color.lstrip("#")
    r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    return f"rgba({r}, {g}, {b}, {alpha})"


def _buffer_polyline_enu(
    enu_points: NDArray[np.floating],
    width_m: float,
) -> NDArray[np.floating]:
    """Buffer a 2D polyline orthogonally to form a closed polygon.

    Computes perpendicular offsets at each point using averaged tangent
    directions from neighboring segments.

    Args:
        enu_points: Polyline in ENU coordinates, shape (K, 2) or (K, 3).
            Only east/north (columns 0-1) are used.
        width_m: Orthogonal offset distance in meters.

    Returns:
        Closed polygon as (2K+1, 2) array of east/north coordinates.
        Forward edge at +width, reversed edge at -width, closed.
    """
    pts = np.asarray(enu_points[:, :2], dtype=np.float64)
    n = len(pts)
    if n < 2:  # noqa: PLR2004
        return pts

    # Compute tangent at each point from neighbors
    tangents = np.zeros_like(pts)
    tangents[0] = pts[1] - pts[0]
    tangents[-1] = pts[-1] - pts[-2]
    tangents[1:-1] = pts[2:] - pts[:-2]

    # Normalize tangents
    norms = np.linalg.norm(tangents, axis=1, keepdims=True)
    norms = np.maximum(norms, 1e-12)
    tangents = tangents / norms

    # Perpendicular: rotate 90 degrees CCW (east, north) -> (-north, east)
    normals = np.column_stack([-tangents[:, 1], tangents[:, 0]])

    # Offset edges
    upper = pts + normals * width_m
    lower = pts - normals * width_m

    # Form closed polygon: forward upper + reversed lower + close
    return np.concatenate([upper, lower[::-1], upper[:1]])


def _auto_zoom(lat_span: float, lon_span: float, center_lat: float) -> int:
    """Compute approximate map zoom level from data extent.

    Args:
        lat_span: Latitude range in degrees.
        lon_span: Longitude range in degrees.
        center_lat: Center latitude in degrees.

    Returns:
        Integer zoom level clamped to [1, 18].
    """
    cos_lat = math.cos(math.radians(center_lat))
    max_span = max(lat_span, lon_span * cos_lat)
    if max_span <= 0:
        return 10
    zoom = math.log2(360.0 / max_span)
    return max(1, min(18, int(zoom)))


class FigureMap:
    """2D figure builder for contours, bands, markers, and lines.

    Supports satellite map or blank plot backgrounds. Follows the
    Figure3D builder pattern with method chaining. All geometry input
    is in XYZ ECEF meters and converted internally to the display frame.

    Attributes:
        style: Display style (SATELLITE or BLANK).
        frame: Coordinate frame for display ("lla" or "enu").
        origin_xyz: Origin for ENU frame transformations.
    """

    def __init__(
        self,
        style: MapStyle = MapStyle.SATELLITE,
        title: str | None = None,
        frame: str = "lla",
        origin_xyz: NDArray[np.floating] | None = None,
    ) -> None:
        """Initialize the 2D figure.

        Args:
            style: Display style. SATELLITE uses Scattermap with ArcGIS
                imagery. BLANK uses regular Scatter on plain axes.
            title: Optional figure title.
            frame: Coordinate frame for display. "lla" for lat/lon degrees,
                "enu" for East/North meters. Ignored for SATELLITE (always
                uses lat/lon internally).
            origin_xyz: Origin in XYZ ECEF meters. Required when frame="enu"
                and style=BLANK. For SATELLITE, used as the reference for
                ENU buffer computations if provided; otherwise derived from
                the first data added.

        Raises:
            ValueError: If frame="enu" and origin_xyz is not provided.
        """
        if frame == "enu" and origin_xyz is None:
            msg = "origin_xyz is required when frame='enu'"
            raise ValueError(msg)

        self._style = style
        self._title = title
        self._frame = frame
        self._origin_xyz = (
            np.asarray(origin_xyz, dtype=np.float64) if origin_xyz is not None else None
        )
        self._traces: list[go.Scattermap | go.Scatter | go.Heatmap] = []
        self._color_index = 0
        self._all_lats: list[float] = []
        self._all_lons: list[float] = []

    @property
    def style(self) -> MapStyle:
        """Get the display style."""
        return self._style

    def _next_color(self) -> str:
        """Get the next color from the default palette."""
        color = DEFAULT_COLORS[self._color_index % len(DEFAULT_COLORS)]
        self._color_index += 1
        return color

    def _xyz_to_display(
        self,
        xyz: NDArray[np.floating],
    ) -> NDArray[np.floating]:
        """Convert XYZ ECEF to display coordinates.

        For SATELLITE or frame="lla": returns (N, 2) as [lat, lon].
        For BLANK frame="enu": returns (N, 2) as [east, north].

        Args:
            xyz: Points in ECEF meters, shape (K, 3).

        Returns:
            Display coordinates, shape (K, 2).
        """
        if self._style == MapStyle.SATELLITE or self._frame == "lla":
            lla = xyz_to_lla(xyz)
            coords = lla[:, :2]  # lat, lon
            self._all_lats.extend(coords[:, 0].tolist())
            self._all_lons.extend(coords[:, 1].tolist())
            return coords

        # ENU mode (origin validated in __init__ for frame="enu")
        if self._origin_xyz is None:
            msg = "origin_xyz must be set for ENU frame"
            raise ValueError(msg)
        enu = get_enu(self._origin_xyz, xyz)
        return enu[:, :2]  # east, north

    def _get_origin_for_buffer(
        self,
        xyz: NDArray[np.floating],
    ) -> NDArray[np.floating]:
        """Get an ENU origin for buffer computation.

        Uses the configured origin if available, otherwise the centroid
        of the provided points.
        """
        if self._origin_xyz is not None:
            return self._origin_xyz
        return np.mean(xyz, axis=0)

    def _add_line_trace(
        self,
        display_coords: NDArray[np.floating],
        color: str,
        width: int,
        label: str | None,
        *,
        show_legend: bool,
    ) -> None:
        """Add a line trace in the appropriate mode."""
        if self._style == MapStyle.SATELLITE:
            trace = go.Scattermap(
                lat=display_coords[:, 0],
                lon=display_coords[:, 1],
                mode="lines",
                line={"color": color, "width": width},
                name=label,
                showlegend=show_legend and label is not None,
            )
        else:
            trace = go.Scatter(
                x=display_coords[:, 1],
                y=display_coords[:, 0],
                mode="lines",
                line={"color": color, "width": width},
                name=label,
                showlegend=show_legend and label is not None,
            )
        self._traces.append(trace)

    def _add_fill_trace(
        self,
        display_coords: NDArray[np.floating],
        color: str,
        alpha: float,
        label: str | None,
        *,
        show_legend: bool,
    ) -> None:
        """Add a filled polygon trace in the appropriate mode."""
        fill_color = _hex_to_rgba(color, alpha)

        if self._style == MapStyle.SATELLITE:
            trace = go.Scattermap(
                lat=display_coords[:, 0],
                lon=display_coords[:, 1],
                mode="lines",
                fill="toself",
                fillcolor=fill_color,
                line={"color": _hex_to_rgba(color, 0.0), "width": 0},
                name=label,
                showlegend=show_legend and label is not None,
            )
        else:
            trace = go.Scatter(
                x=display_coords[:, 1],
                y=display_coords[:, 0],
                mode="lines",
                fill="toself",
                fillcolor=fill_color,
                line={"color": _hex_to_rgba(color, 0.0), "width": 0},
                name=label,
                showlegend=show_legend and label is not None,
            )
        self._traces.append(trace)

    def add_contour(
        self,
        points_xyz: NDArray[np.floating],
        color: str | None = None,
        width: int = 2,
        label: str | None = None,
    ) -> FigureMap:
        """Add a single polyline contour.

        Args:
            points_xyz: Polyline in ECEF meters, shape (K, 3).
            color: Line color. If None, uses next palette color.
            width: Line width in pixels.
            label: Legend label.

        Returns:
            Self for method chaining.
        """
        if color is None:
            color = self._next_color()
        points_xyz = np.asarray(points_xyz, dtype=np.float64)
        display = self._xyz_to_display(points_xyz)
        self._add_line_trace(display, color, width, label, show_legend=True)
        return self

    def add_contours(
        self,
        contours_xyz: list[NDArray[np.floating]],
        color: str | None = None,
        width: int = 2,
        label: str | None = None,
    ) -> FigureMap:
        """Add multiple polylines as one logical group.

        Each polyline becomes a separate trace to avoid connecting
        disjoint segments. Only the first trace shows in the legend.

        Args:
            contours_xyz: List of polylines, each (K, 3) in ECEF meters.
            color: Line color. If None, uses next palette color.
            width: Line width in pixels.
            label: Legend label (shown on first trace only).

        Returns:
            Self for method chaining.
        """
        if not contours_xyz:
            return self
        if color is None:
            color = self._next_color()
        for i, contour in enumerate(contours_xyz):
            pts = np.asarray(contour, dtype=np.float64)
            display = self._xyz_to_display(pts)
            self._add_line_trace(
                display,
                color,
                width,
                label,
                show_legend=(i == 0),
            )
        return self

    def add_band(
        self,
        contours_xyz: list[NDArray[np.floating]],
        width_m: float,
        color: str | None = None,
        alpha: float = 0.2,
        label: str | None = None,
    ) -> FigureMap:
        """Add filled uncertainty band around polylines.

        Buffers each polyline orthogonally by width_m in the local ENU
        plane, then renders as a filled polygon. Appropriate for
        TDOA/FDOA/Range isochrones where uncertainty is approximately
        constant width along the curve.

        For AOA where uncertainty grows with range, use
        add_filled_contour() with the projected cone outline instead.

        Args:
            contours_xyz: Polylines to buffer, each (K, 3) in ECEF meters.
            width_m: Orthogonal offset distance in meters.
            color: Fill color. If None, uses next palette color.
            alpha: Fill opacity (0-1). Default 0.2.
            label: Legend label (shown on first polygon only).

        Returns:
            Self for method chaining.
        """
        if not contours_xyz:
            return self
        if color is None:
            color = self._next_color()

        for i, contour_xyz in enumerate(contours_xyz):
            pts = np.asarray(contour_xyz, dtype=np.float64)
            origin = self._get_origin_for_buffer(pts)

            # Compute buffer in ENU space
            enu = get_enu(origin, pts)
            polygon_enu = _buffer_polyline_enu(enu, width_m)

            # Convert polygon back to XYZ for display conversion
            # Reconstruct 3D ENU with zero up component
            polygon_enu_3d = np.column_stack(
                [
                    polygon_enu,
                    np.zeros(len(polygon_enu)),
                ],
            )
            # ENU back to XYZ: translate from origin
            from gri_utils.conversion import translate_enu  # noqa: PLC0415

            polygon_xyz = np.array([translate_enu(origin, p) for p in polygon_enu_3d])

            display = self._xyz_to_display(polygon_xyz)
            self._add_fill_trace(
                display,
                color,
                alpha,
                label,
                show_legend=(i == 0),
            )
        return self

    def add_filled_contour(
        self,
        contour_xyz: NDArray[np.floating],
        color: str | None = None,
        alpha: float = 0.2,
        label: str | None = None,
    ) -> FigureMap:
        """Add a filled closed contour (polygon).

        For closed curves like AOA cone-plane intersections (ellipses),
        range circles, or any other closed region.

        Args:
            contour_xyz: Closed polyline in ECEF meters, shape (K, 3).
                The first and last points should be close to each other
                (will be closed automatically if not).
            color: Fill color. If None, uses next palette color.
            alpha: Fill opacity (0-1). Default 0.2.
            label: Legend label.

        Returns:
            Self for method chaining.
        """
        if color is None:
            color = self._next_color()
        contour_xyz = np.asarray(contour_xyz, dtype=np.float64)

        # Ensure closed (1mm tolerance)
        close_tolerance_m = 1e-3
        if np.linalg.norm(contour_xyz[0] - contour_xyz[-1]) > close_tolerance_m:
            contour_xyz = np.vstack([contour_xyz, contour_xyz[:1]])

        display = self._xyz_to_display(contour_xyz)
        self._add_fill_trace(display, color, alpha, label, show_legend=True)
        return self

    def add_line(
        self,
        start_xyz: NDArray[np.floating],
        end_xyz: NDArray[np.floating],
        color: str | None = None,
        width: int = 2,
        label: str | None = None,
    ) -> FigureMap:
        """Add a line segment between two points.

        Args:
            start_xyz: Start point in ECEF meters, shape (3,).
            end_xyz: End point in ECEF meters, shape (3,).
            color: Line color. If None, uses next palette color.
            width: Line width in pixels.
            label: Legend label.

        Returns:
            Self for method chaining.
        """
        if color is None:
            color = self._next_color()
        pts = np.array([start_xyz, end_xyz], dtype=np.float64)
        display = self._xyz_to_display(pts)
        self._add_line_trace(display, color, width, label, show_legend=True)
        return self

    def add_heatmap(  # noqa: PLR0913
        self,
        sheet_xyz: NDArray[np.floating],
        *,
        values: NDArray[np.floating] | None = None,
        lat_deg: NDArray[np.floating] | None = None,
        lon_deg: NDArray[np.floating] | None = None,
        colorscale: str = "earth",
        opacity: float = 0.6,
        label: str | None = None,
    ) -> FigureMap:
        """Add a heatmap over a spatial grid.

        Renders a 2D grid as a colored heatmap. When ``values`` is None,
        color represents the altitude of each grid point. When ``values``
        is provided, it is used as the color field instead (e.g. TDOA,
        TDOA-dot, or any scalar quantity defined on the grid).

        When ``lat_deg`` and ``lon_deg`` are provided they are used
        directly as the axis coordinates, bypassing extraction from
        ``sheet_xyz``. This is useful when the sheet contains NaN cells
        (e.g. a visibility-masked grid) that would corrupt the
        coordinate recovery.

        Only supported in BLANK mode.

        Args:
            sheet_xyz: Terrain sheet in ECEF meters, shape (M, N, 3).
            values: Optional scalar field to color by, shape (M, N).
                When None, altitude is used.
            lat_deg: Optional latitude axis, shape (M,). When None,
                extracted from sheet_xyz.
            lon_deg: Optional longitude axis, shape (N,). When None,
                extracted from sheet_xyz.
            colorscale: Plotly colorscale name. Default "earth".
            opacity: Heatmap opacity (0-1). Default 0.6.
            label: Colorbar title.

        Returns:
            Self for method chaining.

        Raises:
            ValueError: If style is SATELLITE (heatmaps require BLANK).
        """
        if self._style == MapStyle.SATELLITE:
            msg = "add_heatmap is only supported with MapStyle.BLANK"
            raise ValueError(msg)

        sheet_xyz = np.asarray(sheet_xyz, dtype=np.float64)
        m, n, _ = sheet_xyz.shape

        if lat_deg is not None and lon_deg is not None:
            x_vals = np.asarray(lon_deg, dtype=np.float64)
            y_vals = np.asarray(lat_deg, dtype=np.float64)
            z_vals = values
        elif self._frame == "enu":
            assert self._origin_xyz is not None  # noqa: S101
            flat = sheet_xyz.reshape(-1, 3)
            enu = get_enu(self._origin_xyz, flat)
            enu_grid = enu.reshape(m, n, 3)
            x_vals = enu_grid[0, :, 0]  # East values (constant per column)
            y_vals = enu_grid[:, 0, 1]  # North values (constant per row)
            z_vals = enu_grid[:, :, 2]  # Up = altitude in ENU
        else:
            from gri_utils.terrain import xyz_to_lla_sheet  # noqa: PLC0415

            lats, lons, alts = xyz_to_lla_sheet(sheet_xyz)
            x_vals = lons
            y_vals = lats
            z_vals = alts

        if values is not None:
            z_vals = np.asarray(values, dtype=np.float64)

        trace = go.Heatmap(
            x=x_vals,
            y=y_vals,
            z=z_vals,
            colorscale=colorscale,
            opacity=opacity,
            showscale=label is not None,
            colorbar={"title": label} if label else None,
            showlegend=False,
        )
        self._traces.insert(0, trace)
        return self

    def add_markers(
        self,
        points_xyz: NDArray[np.floating],
        labels: Sequence[str] | None = None,
        color: str | None = None,
        size: int = 10,
    ) -> FigureMap:
        """Add labeled marker points.

        Args:
            points_xyz: Points in ECEF meters, shape (N, 3).
            labels: Optional text labels for each point.
            color: Marker color. If None, uses next palette color.
            size: Marker size in pixels.

        Returns:
            Self for method chaining.
        """
        if color is None:
            color = self._next_color()
        points_xyz = np.asarray(points_xyz, dtype=np.float64)
        if points_xyz.ndim == 1:
            points_xyz = points_xyz.reshape(1, 3)

        display = self._xyz_to_display(points_xyz)
        mode = "markers+text" if labels else "markers"

        if self._style == MapStyle.SATELLITE:
            trace_kwargs: dict = {
                "lat": display[:, 0],
                "lon": display[:, 1],
                "mode": mode,
                "marker": {"size": size, "color": color},
                "showlegend": False,
            }
            if labels:
                trace_kwargs["text"] = list(labels)
                trace_kwargs["textposition"] = "top center"
            self._traces.append(go.Scattermap(**trace_kwargs))
        else:
            trace_kwargs = {
                "x": display[:, 1],
                "y": display[:, 0],
                "mode": mode,
                "marker": {"size": size, "color": color},
                "showlegend": False,
            }
            if labels:
                trace_kwargs["text"] = list(labels)
                trace_kwargs["textposition"] = "top center"
            self._traces.append(go.Scatter(**trace_kwargs))
        return self

    def build(self) -> go.Figure:
        """Build the Plotly Figure.

        Returns:
            Plotly Figure object.
        """
        fig = go.Figure(data=self._traces)

        if self._style == MapStyle.SATELLITE:
            self._apply_satellite_layout(fig)
        else:
            self._apply_blank_layout(fig)

        if self._title:
            fig.update_layout(title=self._title)

        return fig

    def _apply_satellite_layout(self, fig: go.Figure) -> None:
        """Configure satellite map layout."""
        tile_url = (
            "https://services.arcgisonline.com/arcgis/rest/services/"
            "World_Imagery/MapServer/tile/{z}/{y}/{x}"
        )

        center = {"lat": 0.0, "lon": 0.0}
        zoom = 2
        if self._all_lats:
            min_lat = min(self._all_lats)
            max_lat = max(self._all_lats)
            min_lon = min(self._all_lons)
            max_lon = max(self._all_lons)
            center = {
                "lat": (min_lat + max_lat) / 2,
                "lon": (min_lon + max_lon) / 2,
            }
            lat_span = max_lat - min_lat
            lon_span = max_lon - min_lon
            zoom = _auto_zoom(lat_span, lon_span, center["lat"])

        fig.update_layout(
            template="plotly_dark",
            map_style="white-bg",
            map_layers=[
                {
                    "below": "traces",
                    "sourcetype": "raster",
                    "sourceattribution": "ArcGIS Online",
                    "source": [tile_url],
                    "maxzoom": 18,
                },
            ],
            map_zoom=zoom,
            map_center=center,
        )

    def _apply_blank_layout(self, fig: go.Figure) -> None:
        """Configure blank axes layout."""
        if self._frame == "enu":
            x_label = "East (m)"
            y_label = "North (m)"
        else:
            x_label = "Longitude (deg)"
            y_label = "Latitude (deg)"

        fig.update_layout(
            template="plotly_dark",
            xaxis_title=x_label,
            yaxis_title=y_label,
            xaxis={"scaleanchor": "y"},
        )

    def show(self, **kwargs) -> None:
        """Build and display the figure.

        Args:
            **kwargs: Additional arguments passed to fig.show().
        """
        fig = self.build()
        fig.show(**kwargs)

    def write_html(self, path: str, **kwargs) -> None:
        """Build and save the figure as HTML.

        Args:
            path: Output file path.
            **kwargs: Additional arguments passed to fig.write_html().
        """
        fig = self.build()
        fig.write_html(path, **kwargs)


__all__ = [
    "FigureMap",
    "MapStyle",
]
