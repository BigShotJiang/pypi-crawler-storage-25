"""Tests for figure_map module."""

import numpy as np
import plotly.graph_objects as go
import pytest
from gri_utils.conversion import lla_to_xyz

from gri_plot import FigureMap, MapStyle

# --- Test helpers ---


def _make_collectors_xyz() -> np.ndarray:
    """Four collectors in a diamond around lat=39, lon=-105, alt=0."""
    return np.array(
        [
            lla_to_xyz([39.05, -105.0, 0.0]),
            lla_to_xyz([38.95, -105.0, 0.0]),
            lla_to_xyz([39.0, -105.05, 0.0]),
            lla_to_xyz([39.0, -104.95, 0.0]),
        ],
    )


def _make_contour_xyz() -> np.ndarray:
    """Simple arc polyline in XYZ around lat=39, lon=-105."""
    lats = np.linspace(38.96, 39.04, 20)
    lons = -105.0 + 0.02 * np.sin(np.linspace(0, np.pi, 20))
    alts = np.zeros(20)
    lla = np.column_stack([lats, lons, alts])
    return lla_to_xyz(lla)


def _make_closed_contour_xyz() -> np.ndarray:
    """Small closed contour (circle) in XYZ."""
    theta = np.linspace(0, 2 * np.pi, 50)
    lats = 39.0 + 0.01 * np.cos(theta)
    lons = -105.0 + 0.01 * np.sin(theta)
    lla = np.column_stack([lats, lons, np.zeros(50)])
    return lla_to_xyz(lla)


# --- Constructor tests ---


def test_default_init() -> None:
    """Default FigureMap uses SATELLITE style."""
    fig = FigureMap()
    assert fig.style == MapStyle.SATELLITE


def test_blank_enu_requires_origin() -> None:
    """BLANK style with frame='enu' requires origin_xyz."""
    with pytest.raises(ValueError, match="origin_xyz"):
        FigureMap(style=MapStyle.BLANK, frame="enu")


def test_blank_enu_with_origin() -> None:
    """BLANK style with frame='enu' and origin succeeds."""
    origin = lla_to_xyz([39.0, -105.0, 0.0])
    fig = FigureMap(style=MapStyle.BLANK, frame="enu", origin_xyz=origin)
    assert fig.style == MapStyle.BLANK


# --- Build tests ---


def test_build_satellite_returns_figure() -> None:
    """build() returns a Plotly Figure for satellite mode."""
    fig = FigureMap()
    result = fig.build()
    assert isinstance(result, go.Figure)


def test_build_blank_returns_figure() -> None:
    """build() returns a Plotly Figure for blank mode."""
    origin = lla_to_xyz([39.0, -105.0, 0.0])
    fig = FigureMap(style=MapStyle.BLANK, frame="enu", origin_xyz=origin)
    result = fig.build()
    assert isinstance(result, go.Figure)


def test_build_with_title() -> None:
    """build() includes title in layout."""
    fig = FigureMap(title="Test Title")
    result = fig.build()
    assert result.layout.title.text == "Test Title"  # type: ignore[union-attr]


# --- add_contour tests ---


def test_add_contour_returns_self() -> None:
    """add_contour returns self for method chaining."""
    fig = FigureMap()
    result = fig.add_contour(_make_contour_xyz())
    assert result is fig


def test_add_contour_satellite_creates_scattermap() -> None:
    """add_contour in satellite mode creates Scattermap trace with lines."""
    fig = FigureMap()
    fig.add_contour(_make_contour_xyz(), color="#1f77b4", label="Test")
    result = fig.build()

    assert len(result.data) == 1
    trace = result.data[0]
    assert isinstance(trace, go.Scattermap)
    assert trace.mode == "lines"


def test_add_contour_blank_creates_scatter() -> None:
    """add_contour in blank mode creates Scatter trace with lines."""
    origin = lla_to_xyz([39.0, -105.0, 0.0])
    fig = FigureMap(style=MapStyle.BLANK, frame="enu", origin_xyz=origin)
    fig.add_contour(_make_contour_xyz(), label="Test")
    result = fig.build()

    assert len(result.data) == 1
    trace = result.data[0]
    assert isinstance(trace, go.Scatter)
    assert trace.mode == "lines"


# --- add_contours tests ---


def test_add_contours_returns_self() -> None:
    """add_contours returns self for method chaining."""
    fig = FigureMap()
    result = fig.add_contours([_make_contour_xyz()])
    assert result is fig


def test_add_contours_creates_separate_traces() -> None:
    """Each polyline in add_contours gets its own trace."""
    c1 = _make_contour_xyz()
    c2 = _make_contour_xyz() + 100.0
    fig = FigureMap()
    fig.add_contours([c1, c2], label="Group")
    result = fig.build()

    assert len(result.data) == 2
    # Only first trace shows in legend
    assert result.data[0].showlegend is True
    assert result.data[1].showlegend is False


def test_add_contours_empty_list() -> None:
    """add_contours with empty list is a no-op."""
    fig = FigureMap()
    fig.add_contours([])
    result = fig.build()
    assert len(result.data) == 0


# --- add_band tests ---


def test_add_band_returns_self() -> None:
    """add_band returns self for method chaining."""
    fig = FigureMap()
    result = fig.add_band([_make_contour_xyz()], width_m=500.0)
    assert result is fig


def test_add_band_creates_filled_trace() -> None:
    """add_band creates a trace with fill='toself'."""
    fig = FigureMap()
    fig.add_band([_make_contour_xyz()], width_m=500.0, color="#1f77b4")
    result = fig.build()

    assert len(result.data) == 1
    trace = result.data[0]
    assert trace.fill == "toself"
    assert "rgba" in trace.fillcolor


def test_add_band_blank_mode() -> None:
    """add_band works in blank ENU mode."""
    origin = lla_to_xyz([39.0, -105.0, 0.0])
    fig = FigureMap(style=MapStyle.BLANK, frame="enu", origin_xyz=origin)
    fig.add_band([_make_contour_xyz()], width_m=500.0)
    result = fig.build()

    assert len(result.data) == 1
    assert isinstance(result.data[0], go.Scatter)
    assert result.data[0].fill == "toself"


def test_add_band_empty_list() -> None:
    """add_band with empty list is a no-op."""
    fig = FigureMap()
    fig.add_band([], width_m=500.0)
    result = fig.build()
    assert len(result.data) == 0


# --- add_filled_contour tests ---


def test_add_filled_contour_returns_self() -> None:
    """add_filled_contour returns self for method chaining."""
    fig = FigureMap()
    result = fig.add_filled_contour(_make_closed_contour_xyz())
    assert result is fig


def test_add_filled_contour_creates_fill() -> None:
    """add_filled_contour creates a filled polygon trace."""
    fig = FigureMap()
    fig.add_filled_contour(
        _make_closed_contour_xyz(),
        color="#ff7f0e",
        alpha=0.3,
    )
    result = fig.build()

    assert len(result.data) == 1
    assert result.data[0].fill == "toself"


# --- add_markers tests ---


def test_add_markers_returns_self() -> None:
    """add_markers returns self for method chaining."""
    fig = FigureMap()
    result = fig.add_markers(_make_collectors_xyz())
    assert result is fig


def test_add_markers_satellite() -> None:
    """add_markers in satellite mode creates Scattermap markers."""
    fig = FigureMap()
    fig.add_markers(
        _make_collectors_xyz(),
        labels=["C1", "C2", "C3", "C4"],
    )
    result = fig.build()

    assert len(result.data) == 1
    trace = result.data[0]
    assert isinstance(trace, go.Scattermap)
    assert trace.mode == "markers+text"


def test_add_markers_blank() -> None:
    """add_markers in blank mode creates Scatter markers."""
    origin = lla_to_xyz([39.0, -105.0, 0.0])
    fig = FigureMap(style=MapStyle.BLANK, frame="enu", origin_xyz=origin)
    fig.add_markers(_make_collectors_xyz())
    result = fig.build()

    assert len(result.data) == 1
    assert isinstance(result.data[0], go.Scatter)


def test_add_markers_single_point() -> None:
    """add_markers handles a single (3,) point."""
    fig = FigureMap()
    fig.add_markers(lla_to_xyz([39.0, -105.0, 0.0]))
    result = fig.build()
    assert len(result.data) == 1


# --- Method chaining tests ---


def test_full_chaining() -> None:
    """All add_* methods can be chained together."""
    contour = _make_contour_xyz()
    closed = _make_closed_contour_xyz()
    collectors = _make_collectors_xyz()

    fig = (
        FigureMap(title="Chained")
        .add_contours([contour], label="TDOA")
        .add_band([contour], width_m=300.0)
        .add_filled_contour(closed, label="AOA")
        .add_markers(collectors, labels=["C1", "C2", "C3", "C4"])
    )

    result = fig.build()
    # 1 contour + 1 band + 1 filled + 1 markers = 4 traces
    assert len(result.data) == 4


# --- Color cycling tests ---


def test_auto_color_cycling() -> None:
    """Contours without explicit color get different colors."""
    fig = FigureMap()
    c = _make_contour_xyz()
    fig.add_contour(c, label="A")
    fig.add_contour(c + 100.0, label="B")
    result = fig.build()

    color_a = result.data[0].line.color
    color_b = result.data[1].line.color
    assert color_a != color_b


# --- Visual tests (skipped by default) ---


@pytest.mark.skip(reason="Visual test - unskip to inspect satellite map")
def test_visual_satellite_contours() -> None:
    """Visual: contours + markers on satellite map."""
    contour = _make_contour_xyz()
    collectors = _make_collectors_xyz()

    fig = FigureMap(title="Satellite Contours")
    fig.add_contours([contour], color="#1f77b4", label="Isochrone")
    fig.add_band([contour], width_m=300.0, color="#1f77b4")
    fig.add_markers(collectors, labels=["C1", "C2", "C3", "C4"])
    fig.show()


@pytest.mark.skip(reason="Visual test - unskip to inspect blank ENU plot")
def test_visual_blank_enu() -> None:
    """Visual: contours + markers on blank ENU axes."""
    origin = lla_to_xyz([39.0, -105.0, 0.0])
    contour = _make_contour_xyz()
    collectors = _make_collectors_xyz()

    fig = FigureMap(
        style=MapStyle.BLANK,
        frame="enu",
        origin_xyz=origin,
        title="ENU Contours",
    )
    fig.add_contours([contour], color="#1f77b4", label="Isochrone")
    fig.add_band([contour], width_m=300.0, color="#1f77b4")
    fig.add_filled_contour(_make_closed_contour_xyz(), label="AOA region")
    fig.add_markers(collectors, labels=["C1", "C2", "C3", "C4"])
    fig.show()
