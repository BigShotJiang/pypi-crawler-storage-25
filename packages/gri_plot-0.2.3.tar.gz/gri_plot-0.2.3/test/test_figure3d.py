"""Tests for figure3d module."""

import numpy as np
import plotly.graph_objects as go
import pytest
from gri_utils import constants

from gri_plot import DEFAULT_COLORS, Figure3D, Frame, plot_surfaces
from gri_plot.observables import TdoaSurface, TerrainSurface
from gri_plot.shapes import Cone, Cylinder, Ellipsoid, Sphere


def test_enu_requires_origin():
    """ENU frame requires origin_xyz."""
    with pytest.raises(ValueError):
        Figure3D(display_frame=Frame.ENU)


def test_build_returns_plotly_figure():
    """build() returns a Plotly Figure with traces."""
    fig = Figure3D()
    fig.add_surface(Sphere(np.zeros(3), 100.0))

    plotly_fig = fig.build()

    assert isinstance(plotly_fig, go.Figure)
    assert len(list(plotly_fig.data)) > 0


def test_plot_surfaces_convenience():
    """plot_surfaces() creates a figure from multiple surfaces."""
    sphere1 = Sphere(np.zeros(3), 100.0)
    sphere2 = Sphere(np.array([200.0, 0.0, 0.0]), 50.0)

    fig = plot_surfaces(sphere1, sphere2)

    assert isinstance(fig, go.Figure)
    assert len(list(fig.data)) >= 2


@pytest.mark.skip(reason="Visual test - unskip to generate plot")
def test_visual_ellipsoid_enu():
    """Visual: Ellipsoid in ENU frame."""
    center = np.array([4e6, 3e6, 4e6])
    cov = np.diag([10000.0, 5000.0, 2500.0])
    ellipsoid = Ellipsoid(center, covariance=cov, label="1-sigma")

    fig = Figure3D(display_frame=Frame.ENU, origin_xyz=center, title="Ellipsoid (ENU)")
    fig.add_surface(ellipsoid)
    fig.add_points(center.reshape(1, 3), labels=["Center"])
    fig.show()


@pytest.mark.skip(reason="Visual test - unskip to generate plot")
def test_visual_multiple_spheres():
    """Visual: Multiple spheres."""
    fig = Figure3D(title="Multiple Spheres")

    for i in range(5):
        center = np.array([i * 300.0, 0.0, 0.0])
        fig.add_surface(Sphere(center, 100.0, label=f"Sphere {i + 1}"), opacity=0.6)

    fig.show()


@pytest.mark.skip(reason="Visual test - unskip to generate plot")
def test_visual_combined_surfaces():
    """Visual: Combined shapes in one figure."""
    fig = Figure3D(title="Combined Shapes")

    fig.add_surface(Sphere(np.zeros(3), 50.0, label="Sphere"))
    fig.add_surface(
        Cone(np.array([150.0, 0.0, 0.0]), np.array([0.0, 0.0, 1.0]), 0.4, 100.0),
        label="Cone",
    )
    fig.add_surface(
        Cylinder(np.array([300.0, 0.0, 0.0]), np.array([0.0, 0.0, 1.0]), 30.0, 100.0),
        label="Cylinder",
    )

    fig.show()


def test_add_intersection_requires_two_surfaces():
    """add_intersection requires at least 2 surfaces."""
    fig = Figure3D()
    sphere = Sphere(np.zeros(3), 100.0)

    with pytest.raises(ValueError, match="at least 2"):
        fig.add_intersection(sphere)


def test_add_intersection_returns_self():
    """add_intersection returns self for chaining."""
    fig = Figure3D()
    s1 = Sphere(np.zeros(3), 100.0)
    s2 = Sphere(np.array([80.0, 0.0, 0.0]), 100.0)

    result = fig.add_intersection(s1, s2, resolution=20)

    assert result is fig


def test_add_intersection_creates_trace():
    """add_intersection adds a Mesh3d trace."""
    fig = Figure3D()
    s1 = Sphere(np.zeros(3), 100.0)
    s2 = Sphere(np.array([80.0, 0.0, 0.0]), 100.0)

    fig.add_intersection(s1, s2, resolution=20)
    plotly_fig = fig.build()

    assert len(list(plotly_fig.data)) == 1
    assert isinstance(plotly_fig.data[0], go.Mesh3d)


@pytest.mark.skip(reason="Visual test - unskip to generate plot")
def test_visual_sphere_intersection():
    """Visual: Intersection of overlapping spheres."""
    fig = Figure3D(title="Sphere Intersection")

    s1 = Sphere(np.zeros(3), 100.0, label="Sphere 1")
    s2 = Sphere(np.array([80.0, 0.0, 0.0]), 100.0, label="Sphere 2")

    # Add both spheres with low opacity
    fig.add_surface(s1, opacity=0.3)
    fig.add_surface(s2, opacity=0.3)

    # Add intersection highlight
    fig.add_intersection(s1, s2, label="Intersection", opacity=0.9)

    fig.show()


def _make_geolocation_scenario() -> tuple:
    """Create geolocation scenario components for visual tests.

    Returns tuple of (terrain, tdoa_12, tdoa_13, collectors, emitter) where:
    - terrain: TerrainSurface with hills
    - tdoa_12: TdoaSurface between collectors 1 and 2
    - tdoa_13: TdoaSurface between collectors 1 and 3
    - collectors: list of 3 collector positions [c1, c2, c3]
    - emitter: emitter position on terrain
    """
    # Generate terrain covering the full viewing area with significant variation
    rng = np.random.default_rng(42)
    x_coords = np.linspace(-25000, 25000, 100)
    y_coords = np.linspace(-25000, 25000, 100)
    x_grid, y_grid = np.meshgrid(x_coords, y_coords, indexing="ij")

    # Terrain with hills up to ~2km variation
    elevation = 500.0 + 800.0 * np.sin(x_grid / 8000) * np.cos(y_grid / 6000)
    elevation += 400.0 * np.sin(x_grid / 3000 + y_grid / 4000)
    elevation += 200.0 * rng.random(elevation.shape)  # Add noise

    terrain = TerrainSurface.from_xyz_grids(x_grid, y_grid, elevation, label="Terrain")

    # Emitter location: on the terrain surface
    emitter_x, emitter_y = 5000.0, 4000.0
    emitter_z = -terrain.residual_fn(np.array([[emitter_x, emitter_y, 0.0]]))[0]
    emitter = np.array([emitter_x, emitter_y, emitter_z])

    # Three collectors at varying distances and elevations
    # C1: Near emitter (~1 km horizontal), slightly above terrain
    c1_x, c1_y = 4200.0, 3500.0
    c1_terrain_z = -terrain.residual_fn(np.array([[c1_x, c1_y, 0.0]]))[0]
    c1 = np.array([c1_x, c1_y, c1_terrain_z + 50.0])

    # C2: Medium distance (~5 km horizontal), slightly above terrain
    c2_x, c2_y = 0.0, 2000.0
    c2_terrain_z = -terrain.residual_fn(np.array([[c2_x, c2_y, 0.0]]))[0]
    c2 = np.array([c2_x, c2_y, c2_terrain_z + 50.0])

    # C3: Far away, elevated (~20 km slant range, ~30 deg elevation)
    c3 = np.array([22000.0, 8000.0, 10000.0])

    collectors = [c1, c2, c3]

    # Compute ranges and TDOAs
    ranges = [np.linalg.norm(emitter - c) for c in collectors]
    tdoa_12_sec = float((ranges[0] - ranges[1]) / constants.C)
    tdoa_13_sec = float((ranges[0] - ranges[2]) / constants.C)

    tdoa_12 = TdoaSurface(c1, c2, tdoa_12_sec, label="TDOA 1-2")
    tdoa_13 = TdoaSurface(c1, c3, tdoa_13_sec, label="TDOA 1-3")

    return terrain, tdoa_12, tdoa_13, collectors, emitter


def _add_geolocation_base(
    fig: Figure3D,
    terrain,
    tdoa_12,
    tdoa_13,
    collectors: list,
    emitter,
    *,
    tdoa_opacity: float = 0.4,
    terrain_opacity: float = 0.8,
) -> None:
    """Add terrain, TDOA surfaces, collectors, and emitter to figure."""

    # Intensity function based on Z (altitude) for terrain coloring
    def z_intensity(vertices: np.ndarray) -> np.ndarray:
        return vertices[:, 2]

    # Add terrain with earth colorscale and Z-based intensity
    terrain_trace = terrain.to_trace(
        colorscale="earth",
        opacity=terrain_opacity,
        intensity_fn=z_intensity,
        showscale=False,
    )
    fig._traces.append(terrain_trace)
    fig._surface_bounds.append(terrain.get_bounds_xyz())

    # Add TDOA surfaces with distinct colors
    fig.add_surface(tdoa_12, color=DEFAULT_COLORS[0], opacity=tdoa_opacity)
    fig.add_surface(tdoa_13, color=DEFAULT_COLORS[1], opacity=tdoa_opacity)

    # Add collectors
    fig.add_points(
        np.array(collectors),
        labels=["C1 (near)", "C2 (mid)", "C3 (far/high)"],
        color="#ffffff",
        size=10,
        name="Collectors",
    )
    # Add emitter
    fig.add_points(
        emitter.reshape(1, 3),
        labels=["Emitter"],
        color="#ff0000",
        size=12,
        name="Emitter",
    )


def _show_geolocation_figure(fig: Figure3D) -> None:
    """Build and show geolocation figure with constrained axis ranges."""
    plotly_fig = fig.build()
    plotly_fig.update_layout(
        scene={
            "xaxis": {"range": [-25000, 25000]},
            "yaxis": {"range": [-25000, 25000]},
            "zaxis": {"range": [-10000, 15000]},
        },
    )
    plotly_fig.show()


@pytest.mark.skip(reason="Visual test - unskip to generate plot")
def test_visual_geolocation_surfaces():
    """Visual: TDOA surfaces with terrain for geolocation scenario."""
    terrain, tdoa_12, tdoa_13, collectors, emitter = _make_geolocation_scenario()

    fig = Figure3D(title="Geolocation: Terrain + TDOA Surfaces")
    _add_geolocation_base(fig, terrain, tdoa_12, tdoa_13, collectors, emitter)
    _show_geolocation_figure(fig)


@pytest.mark.skip(reason="Visual test - unskip to generate plot")
def test_visual_geolocation_intersection():
    """Visual: TDOA surfaces with intersection highlight."""
    terrain, tdoa_12, tdoa_13, collectors, emitter = _make_geolocation_scenario()

    fig = Figure3D(title="Geolocation: TDOA Intersection (Fix Region)")
    _add_geolocation_base(
        fig,
        terrain,
        tdoa_12,
        tdoa_13,
        collectors,
        emitter,
        tdoa_opacity=0.15,
        terrain_opacity=0.6,
    )

    # Add intersection - higher resolution helps with the thin intersection curve
    fig.add_intersection(
        tdoa_12,
        tdoa_13,
        label="Intersection",
        opacity=0.5,
    )

    _show_geolocation_figure(fig)
