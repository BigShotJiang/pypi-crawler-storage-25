"""Tests for shapes.cylinder module."""

import numpy as np
import pytest

from gri_plot import Figure3D, Frame
from gri_plot.shapes import Cylinder


def test_residual_inside_outside():
    """Residual is negative inside, zero on surface, positive outside."""
    cylinder = Cylinder(
        center_xyz=np.zeros(3),
        axis=np.array([0.0, 0.0, 1.0]),
        radius=25.0,
        height=100.0,
    )

    # On surface
    assert abs(cylinder.residual_fn(np.array([25.0, 0.0, 0.0]))) < 1e-10

    # Inside
    assert cylinder.residual_fn(np.array([10.0, 0.0, 0.0])) < 0

    # Outside
    assert cylinder.residual_fn(np.array([50.0, 0.0, 0.0])) > 0


@pytest.mark.parametrize(
    ("radius", "height"),
    [
        (0.0, 100.0),
        (-10.0, 100.0),
        (25.0, 0.0),
        (25.0, -10.0),
    ],
)
def test_invalid_parameters(radius, height):
    """Invalid radius or height raises ValueError."""
    with pytest.raises(ValueError):
        Cylinder(np.zeros(3), np.array([0.0, 0.0, 1.0]), radius, height)


@pytest.mark.skip(reason="Visual test - unskip to generate plot")
def test_visual_cylinder():
    """Visual: vertical cylinder."""
    cylinder = Cylinder(
        center_xyz=np.zeros(3),
        axis=np.array([0.0, 0.0, 1.0]),
        radius=25.0,
        height=100.0,
        label="Cylinder",
    )

    fig = Figure3D(display_frame=Frame.XYZ, title="Cylinder")
    fig.add_surface(cylinder, opacity=0.7)
    fig.show()
