"""Tests for shapes.ellipsoid module."""

import numpy as np
import pytest

from gri_plot import Figure3D, Frame
from gri_plot.shapes import Ellipsoid


def test_residual_on_surface():
    """Residual is zero on 1-sigma surface."""
    cov = np.diag([100.0, 25.0, 81.0])  # semi-axes: 10, 5, 9
    ellipsoid = Ellipsoid(np.zeros(3), covariance=cov)

    # Point at (10, 0, 0) is on surface: Mahalanobis^2 = 100/100 = 1
    assert abs(ellipsoid.residual_fn(np.array([10.0, 0.0, 0.0]))) < 1e-10


def test_requires_covariance_or_semi_axes():
    """Must provide either covariance or semi_axes."""
    with pytest.raises(ValueError):
        Ellipsoid(np.zeros(3))


def test_rejects_both_covariance_and_semi_axes():
    """Cannot provide both covariance and semi_axes."""
    with pytest.raises(ValueError):
        Ellipsoid(np.zeros(3), covariance=np.eye(3), semi_axes=np.ones(3))


@pytest.mark.skip(reason="Visual test - unskip to generate plot")
def test_visual_ellipsoid_from_covariance():
    """Visual: ellipsoid from covariance matrix."""
    cov = np.diag([10000.0, 2500.0, 400.0])  # semi-axes: 100, 50, 20
    ellipsoid = Ellipsoid(np.zeros(3), covariance=cov, label="1-sigma")

    fig = Figure3D(display_frame=Frame.XYZ, title="Ellipsoid from Covariance")
    fig.add_surface(ellipsoid, opacity=0.7)
    fig.show()


@pytest.mark.skip(reason="Visual test - unskip to generate plot")
def test_visual_ellipsoid_from_semi_axes():
    """Visual: ellipsoid from semi-axes."""
    ellipsoid = Ellipsoid(
        np.zeros(3),
        semi_axes=np.array([100.0, 50.0, 25.0]),
        label="Ellipsoid",
    )

    fig = Figure3D(display_frame=Frame.XYZ, title="Ellipsoid from Semi-axes")
    fig.add_surface(ellipsoid, opacity=0.7)
    fig.show()
