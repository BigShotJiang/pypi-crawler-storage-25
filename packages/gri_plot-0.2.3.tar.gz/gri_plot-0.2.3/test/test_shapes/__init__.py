"""Tests for shapes module."""
