"""Tests for shapes.ellipse module."""

import numpy as np
import pytest

from gri_plot.shapes import Ellipse


def test_properties_stored():
    """Constructor stores and exposes all fields."""
    e = Ellipse(100.0, 50.0, 45.0, center=(10.0, 20.0), label="test")
    assert e.sma == 100.0
    assert e.smi == 50.0
    assert e.ori_deg == 45.0
    assert e.center == (10.0, 20.0)
    assert e.label == "test"


def test_center_defaults_to_origin():
    """Center defaults to (0, 0) when not specified."""
    e = Ellipse(100.0, 50.0, 0.0)
    assert e.center == (0.0, 0.0)


@pytest.mark.parametrize(
    ("ori_in", "ori_expected"),
    [(370.0, 10.0), (-10.0, 350.0), (0.0, 0.0), (360.0, 0.0), (720.0, 0.0)],
)
def test_ori_deg_normalized(ori_in: float, ori_expected: float):
    """Orientation is normalized to [0, 360)."""
    e = Ellipse(100.0, 50.0, ori_in)
    assert e.ori_deg == pytest.approx(ori_expected)


@pytest.mark.parametrize(("sma", "smi"), [(0, 50), (-10, 50), (100, 0), (100, -5)])
def test_rejects_non_positive_axes(sma: float, smi: float):
    """Non-positive axes raise ValueError."""
    with pytest.raises(ValueError, match="positive"):
        Ellipse(sma, smi, 0.0)


def test_rejects_sma_less_than_smi():
    """SMA < SMI raises ValueError."""
    with pytest.raises(ValueError, match="Semi-major"):
        Ellipse(50.0, 100.0, 0.0)


def test_boundary_shape():
    """Boundary returns arrays of requested length."""
    e = Ellipse(100.0, 50.0, 0.0)
    east, north = e.boundary(n_pts=300)
    assert east.shape == (300,)
    assert north.shape == (300,)


def test_boundary_extent_at_zero_orientation():
    """At ori=0 (North), SMA extends along North, SMI along East."""
    e = Ellipse(100.0, 50.0, 0.0)
    east, north = e.boundary(n_pts=1000)
    # SMA along North axis
    assert np.max(np.abs(north)) == pytest.approx(100.0, rel=1e-3)
    # SMI along East axis
    assert np.max(np.abs(east)) == pytest.approx(50.0, rel=1e-3)


def test_boundary_respects_center():
    """Mean of boundary points matches center."""
    center = (100.0, -200.0)
    e = Ellipse(80.0, 40.0, 30.0, center=center)
    east, north = e.boundary(n_pts=1000)
    # Mean of closed boundary approximates center
    assert np.mean(east) == pytest.approx(center[0], abs=1.0)
    assert np.mean(north) == pytest.approx(center[1], abs=1.0)


def test_repr():
    """Repr includes key parameters."""
    e = Ellipse(100.0, 50.0, 45.0, label="test")
    r = repr(e)
    assert "100.0" in r
    assert "50.0" in r
    assert "45.0" in r
    assert "test" in r
