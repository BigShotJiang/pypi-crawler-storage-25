"""Tests for shapes.cone module."""

import numpy as np
import pytest

from gri_plot import Figure3D, Frame
from gri_plot.shapes import Cone


def test_residual_inside_outside():
    """Residual is negative inside cone, positive outside."""
    cone = Cone(
        apex_xyz=np.zeros(3),
        axis=np.array([0.0, 0.0, 1.0]),
        half_angle=np.pi / 4,  # 45 degrees
        height=100.0,
    )

    # On axis (inside cone)
    assert cone.residual_fn(np.array([0.0, 0.0, 50.0])) < 0

    # Far off axis (outside cone)
    assert cone.residual_fn(np.array([100.0, 0.0, 10.0])) > 0


@pytest.mark.parametrize(
    ("half_angle", "height"),
    [
        (0.0, 100.0),  # invalid half_angle
        (np.pi / 2, 100.0),  # invalid half_angle
        (0.5, 0.0),  # invalid height
        (0.5, -10.0),  # invalid height
    ],
)
def test_invalid_parameters(half_angle, height):
    """Invalid half_angle or height raises ValueError."""
    with pytest.raises(ValueError):
        Cone(np.zeros(3), np.array([0.0, 0.0, 1.0]), half_angle, height)


@pytest.mark.skip(reason="Visual test - unskip to generate plot")
def test_visual_cone():
    """Visual: cone pointing up."""
    cone = Cone(
        apex_xyz=np.zeros(3),
        axis=np.array([0.0, 0.0, 1.0]),
        half_angle=0.3,
        height=100.0,
        label="Cone",
    )

    fig = Figure3D(display_frame=Frame.XYZ, title="Cone")
    fig.add_surface(cone, opacity=0.7)
    fig.show()
