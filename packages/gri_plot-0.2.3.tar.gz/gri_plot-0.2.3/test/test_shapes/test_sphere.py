"""Tests for shapes.sphere module."""

import numpy as np
import pytest

from gri_plot import Figure3D, Frame
from gri_plot.shapes import Sphere


@pytest.mark.parametrize(
    ("point_offset", "expected_sign"),
    [
        ([100, 0, 0], 0),  # on surface
        ([50, 0, 0], -1),  # inside
        ([150, 0, 0], 1),  # outside
    ],
)
def test_residual_fn(point_offset, expected_sign):
    """Residual is zero on surface, negative inside, positive outside."""
    sphere = Sphere(np.zeros(3), radius=100.0)
    residual = sphere.residual_fn(np.array(point_offset, dtype=float))

    if expected_sign == 0:
        assert abs(residual) < 1e-10
    elif expected_sign < 0:
        assert residual < 0
    else:
        assert residual > 0


def test_invalid_radius():
    """Non-positive radius raises ValueError."""
    with pytest.raises(ValueError):
        Sphere(np.zeros(3), radius=0.0)


@pytest.mark.skip(reason="Visual test - unskip to generate plot")
def test_visual_sphere():
    """Visual: sphere centered at origin."""
    sphere = Sphere(np.zeros(3), radius=100.0, label="Sphere")

    fig = Figure3D(display_frame=Frame.XYZ, title="Sphere")
    fig.add_surface(sphere, opacity=0.7)
    fig.show()
