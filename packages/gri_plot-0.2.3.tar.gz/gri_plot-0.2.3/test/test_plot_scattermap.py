import pytest

from gri_plot import scatter_map


@pytest.mark.skip(reason="manual only for demonstration and test")
def test_map_plot_single():
    lats: list[float] = []
    lons: list[float] = []
    for idx in range(10):
        lat = 39.751196 + (39.753636 - 39.751196) * idx / 10
        lon = -105.222291 + (-105.224555 + 105.222291) * idx / 10
        lats.append(lat)
        lons.append(lon)
    for idx in range(10):
        lat = 39.753636 + (39.756985 - 39.753636) * idx / 10
        lon = -105.224555 + (-105.218632 + 105.224555) * idx / 10
        lats.append(lat)
        lons.append(lon)
    scatter_map((lats, lons), zoom=16)


@pytest.mark.skip(reason="manual only for demonstration and test")
def test_map_plot_mult():
    lats1: list[float] = []
    lons1: list[float] = []
    for idx in range(10):
        lat = 39.751196 + (39.753636 - 39.751196) * idx / 10
        lon = -105.222291 + (-105.224555 + 105.222291) * idx / 10
        lats1.append(lat)
        lons1.append(lon)
    lats2: list[float] = []
    lons2: list[float] = []
    for idx in range(10):
        lat = 39.753636 + (39.756985 - 39.753636) * idx / 10
        lon = -105.224555 + (-105.218632 + 105.224555) * idx / 10
        lats2.append(lat)
        lons2.append(lon)
    scatter_map(
        (lats1, lons1),
        ((lats2, lons2)),
        zoom=16,
        marker_sizes=[10, 20],
        marker_colors=["#aaaaff", "white"],
    )
