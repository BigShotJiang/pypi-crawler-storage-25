import numpy as np
import pytest

from gri_plot import scatter


@pytest.mark.skip(reason="manual only for demonstration and test")
def test_single():
    x = np.linspace(-np.pi * 2, np.pi * 4, 200)
    y = np.sinc(x)
    scatter((y,))


@pytest.mark.skip(reason="manual only for demonstration and test")
def test_double():
    x = np.linspace(-np.pi * 2, np.pi * 4, 200)
    y1 = np.sinc(x)
    y2 = -np.sinc(x + np.pi / 2)
    scatter((y1,), (y2,))


@pytest.mark.skip(reason="manual only for demonstration and test")
def test_x_space():
    x = np.linspace(-np.pi * 2, np.pi * 4, 200)
    y1 = np.sinc(x)
    y2 = -np.sinc(x + np.pi / 2)
    scatter((x, y1), (x, y2))


@pytest.mark.skip(reason="manual only for demonstration and test")
def test_sequence():
    x = np.linspace(-np.pi * 2, np.pi * 4, 200)
    y1 = np.sinc(x)
    y2 = -np.sinc(x + np.pi / 2)
    scatter((x.tolist(), y1.tolist()), (x, y2))


@pytest.mark.skip(reason="manual only for demonstration and test")
def test_kwargs():
    x = np.linspace(-np.pi * 2, np.pi * 4, 200)
    y1 = np.sinc(x)
    y2 = -np.sinc(x + np.pi / 2)
    scatter((x, y1), (x, y2), title="Scattergram", yaxis_range=[0, None])


@pytest.mark.skip(reason="manual only for demonstration and test")
def test_trace_kwargs():
    x = np.linspace(-np.pi * 2, np.pi * 4, 200)
    y1 = np.sinc(x)
    y2 = -np.sinc(x + np.pi / 2)
    scatter((x, y1, {"name": "First"}), (x, y2))


@pytest.mark.skip(reason="manual only for demonstration and test")
def test_trace_kwargs2():
    x = np.linspace(-np.pi * 2, np.pi * 4, 200)
    y1 = np.sinc(x)
    x2 = np.linspace(-np.pi * 2, np.pi * 4, 7)
    y2 = np.sinc(x2)
    scatter(
        (x / np.pi, y1),
        (x2 / np.pi, y2, {"mode": "markers", "marker": {"symbol": "x", "size": 10}}),
        xaxis_title="Radians",
    )
