"""Tests for observables module."""
