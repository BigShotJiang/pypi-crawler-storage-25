"""Tests for observables.fdoa module."""

import numpy as np
import pytest

from gri_plot import Figure3D, Frame
from gri_plot.observables import FdoaSurface


def test_residual_symmetric_velocities():
    """Symmetric velocities give zero FDOA at midpoint."""
    c1 = np.array([0.0, 0.0, 0.0])
    c2 = np.array([1000.0, 0.0, 0.0])
    v1 = np.array([100.0, 0.0, 0.0])
    v2 = np.array([-100.0, 0.0, 0.0])

    surface = FdoaSurface(c1, c2, v1, v2, fdoa_hz=0.0, freq_hz=1e9)
    midpoint = np.array([500.0, 0.0, 0.0])

    assert abs(surface.residual_fn(midpoint)) < 0.01


def test_invalid_frequency():
    """Non-positive frequency raises ValueError."""
    with pytest.raises(ValueError):
        FdoaSurface(
            np.zeros(3),
            np.array([1000.0, 0.0, 0.0]),
            np.array([100.0, 0.0, 0.0]),
            np.zeros(3),
            fdoa_hz=10.0,
            freq_hz=0.0,
        )


@pytest.mark.skip(reason="Visual test - unskip to generate plot")
def test_visual_fdoa_surface():
    """Visual: FDOA iso-Doppler surface.

    Uses asymmetric velocities to create a curved surface. One collector
    moves along the baseline while the other moves perpendicular to it.
    """
    # Collectors offset in x-y plane
    c1 = np.array([0.0, 0.0, 0.0])
    c2 = np.array([8000.0, 4000.0, 0.0])

    # Asymmetric velocities create curved iso-Doppler surface
    # c1 moving along baseline direction
    # c2 moving perpendicular (in z)
    v1 = np.array([150.0, 75.0, 0.0])  # Along baseline
    v2 = np.array([0.0, 0.0, 200.0])  # Perpendicular

    surface = FdoaSurface(c1, c2, v1, v2, fdoa_hz=1.0, freq_hz=1e9, label="FDOA")

    # Use XYZ frame for local coordinates (ENU requires valid ECEF coordinates)
    fig = Figure3D(display_frame=Frame.XYZ, title="FDOA Iso-Doppler Surface")
    fig.add_surface(surface, opacity=0.5)
    fig.add_points(np.array([c1, c2]), labels=["C1", "C2"])
    fig.show()
