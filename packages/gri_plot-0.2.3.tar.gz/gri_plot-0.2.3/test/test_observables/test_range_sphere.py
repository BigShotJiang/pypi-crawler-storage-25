"""Tests for observables.range_sphere module."""

import numpy as np
import pytest

from gri_plot import Figure3D, Frame
from gri_plot.observables import RangeSphere


def test_residual_on_surface():
    """Residual is zero on surface, negative inside, positive outside."""
    sphere = RangeSphere(np.zeros(3), range_m=100.0)

    assert abs(sphere.residual_fn(np.array([100.0, 0.0, 0.0]))) < 1e-10
    assert sphere.residual_fn(np.array([50.0, 0.0, 0.0])) < 0
    assert sphere.residual_fn(np.array([150.0, 0.0, 0.0])) > 0


def test_invalid_range():
    """Non-positive range raises ValueError."""
    with pytest.raises(ValueError):
        RangeSphere(np.zeros(3), range_m=0.0)


@pytest.mark.skip(reason="Visual test - unskip to generate plot")
def test_visual_range_sphere():
    """Visual: Range sphere around collector."""
    collector = np.array([100.0, 200.0, 0.0])
    surface = RangeSphere(collector, range_m=500.0, label="Range")

    fig = Figure3D(display_frame=Frame.XYZ, title="Range Sphere")
    fig.add_surface(surface, opacity=0.5)
    fig.add_points(collector.reshape(1, 3), labels=["Collector"])
    fig.show()
