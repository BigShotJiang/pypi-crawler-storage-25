"""Tests for observables.tdoa module."""

import numpy as np
import pytest
from gri_utils.conversion import lla_to_xyz

from gri_plot import Figure3D, Frame
from gri_plot.observables import TdoaSurface


def test_residual_at_midpoint_zero_tdoa():
    """Midpoint has zero residual when TDOA is zero."""
    c1 = np.array([0.0, 0.0, 0.0])
    c2 = np.array([1000.0, 0.0, 0.0])
    surface = TdoaSurface(c1, c2, tdoa_seconds=0.0)

    midpoint = np.array([500.0, 0.0, 0.0])
    assert abs(surface.residual_fn(midpoint)) < 1e-10


def test_residual_sign():
    """Residual sign indicates which side of hyperboloid."""
    c1 = np.array([0.0, 0.0, 0.0])
    c2 = np.array([1000.0, 0.0, 0.0])
    surface = TdoaSurface(c1, c2, tdoa_seconds=0.0)

    # Near c1: r1 < r2, so residual < 0
    assert surface.residual_fn(np.array([100.0, 0.0, 0.0])) < 0

    # Near c2: r1 > r2, so residual > 0
    assert surface.residual_fn(np.array([900.0, 0.0, 0.0])) > 0


@pytest.mark.skip(reason="Visual test - unskip to generate plot")
def test_visual_tdoa_hyperboloid():
    """Visual: TDOA hyperboloid between two collectors (local XYZ frame)."""
    c1 = np.array([0.0, 0.0, 0.0])
    c2 = np.array([10000.0, 0.0, 0.0])

    surface = TdoaSurface(c1, c2, tdoa_seconds=5e-6, label="TDOA 5us")

    # Use XYZ frame for local coordinates (ENU requires valid ECEF coordinates)
    fig = Figure3D(display_frame=Frame.XYZ, title="TDOA Hyperboloid")
    fig.add_surface(surface, opacity=0.5)
    fig.add_points(np.array([c1, c2]), labels=["C1", "C2"])
    fig.show()


@pytest.mark.skip(reason="Visual test - unskip to generate plot")
def test_visual_tdoa_hyperboloid_enu():
    """Visual: TDOA hyperboloid in ENU frame with Earth-surface collectors.

    Uses realistic ECEF coordinates for collectors on Earth's surface,
    allowing proper ENU (East-North-Up) visualization.
    """
    # Two collectors near Denver, CO (40N, 105W) separated by ~10km
    # Collector 1: base location
    # Collector 2: ~10km to the east
    c1_lla = np.array([40.0, -105.0, 1000.0])  # lat, lon, alt(m)
    c2_lla = np.array([40.0, -104.88, 1000.0])  # ~10km east (0.12 deg at this lat)

    c1 = lla_to_xyz(c1_lla)
    c2 = lla_to_xyz(c2_lla)
    midpoint = (c1 + c2) / 2

    # 10 microsecond TDOA corresponds to ~3km range difference
    surface = TdoaSurface(c1, c2, tdoa_seconds=10e-6, label="TDOA 10us")

    fig = Figure3D(display_frame=Frame.ENU, origin_xyz=midpoint, title="TDOA (ENU)")
    fig.add_surface(surface, opacity=0.7)
    fig.add_points(np.array([c1, c2]), labels=["C1", "C2"])
    fig.show()
