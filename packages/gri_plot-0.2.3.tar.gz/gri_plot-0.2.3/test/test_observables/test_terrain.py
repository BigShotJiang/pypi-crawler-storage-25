"""Tests for observables.terrain module."""

import numpy as np
import pytest

from gri_plot import Figure3D, Frame
from gri_plot.observables import TerrainSurface


def test_from_xyz_grids():
    """TerrainSurface can be created from XYZ grids."""
    x = np.linspace(0, 100, 10)
    y = np.linspace(0, 100, 10)
    xx, yy = np.meshgrid(x, y)
    zz = np.sin(xx / 20) * np.cos(yy / 20) * 10

    surface = TerrainSurface.from_xyz_grids(xx, yy, zz)
    assert surface.label is None


def test_from_3d_vertices():
    """TerrainSurface can be created from 3D vertex array."""
    x = np.linspace(0, 100, 10)
    y = np.linspace(0, 100, 8)
    xx, yy = np.meshgrid(x, y)
    zz = np.zeros_like(xx)
    vertices = np.stack([xx, yy, zz], axis=-1)

    surface = TerrainSurface(vertices)
    assert surface.grid_shape == (8, 10)


@pytest.mark.skip(reason="Visual test - unskip to generate plot")
def test_visual_terrain():
    """Visual: Terrain surface with sinusoidal hills."""
    x = np.linspace(0, 1000, 50)
    y = np.linspace(0, 1000, 50)
    xx, yy = np.meshgrid(x, y)
    zz = 100 * np.sin(xx / 200) * np.cos(yy / 200) + 50

    surface = TerrainSurface.from_xyz_grids(xx, yy, zz, label="Terrain")

    fig = Figure3D(display_frame=Frame.XYZ, title="Terrain")
    fig.add_surface(surface, opacity=0.9)
    fig.show()
