"""Tests for observables.aoa module."""

import numpy as np
import pytest

from gri_plot import Figure3D, Frame
from gri_plot.observables import AoaSurface


def test_residual_on_axis_inside():
    """Point on axis is inside the AOA cone."""
    surface = AoaSurface(
        np.zeros(3),
        direction_xyz=np.array([1.0, 0.0, 0.0]),
        error_rad=0.2,
    )

    on_axis = np.array([1000.0, 0.0, 0.0])
    assert surface.residual_fn(on_axis) < 0


def test_residual_perpendicular_outside():
    """Point perpendicular to axis is outside the cone."""
    surface = AoaSurface(
        np.zeros(3),
        direction_xyz=np.array([1.0, 0.0, 0.0]),
        error_rad=0.1,
    )

    perpendicular = np.array([100.0, 1000.0, 0.0])
    assert surface.residual_fn(perpendicular) > 0


def test_invalid_max_range():
    """Non-positive max_range raises ValueError."""
    with pytest.raises(ValueError):
        AoaSurface(np.zeros(3), np.array([1.0, 0.0, 0.0]), max_range=0.0)


@pytest.mark.skip(reason="Visual test - unskip to generate plot")
def test_visual_aoa_cone():
    """Visual: AOA cone with angular uncertainty."""
    collector = np.zeros(3)
    direction = np.array([1.0, 0.2, 0.1])

    surface = AoaSurface(
        collector,
        direction,
        error_rad=0.15,
        max_range=1000.0,
        label="AOA",
    )

    fig = Figure3D(display_frame=Frame.XYZ, title="AOA Cone")
    fig.add_surface(surface, opacity=0.5)
    fig.add_points(collector.reshape(1, 3))
    fig.show()
