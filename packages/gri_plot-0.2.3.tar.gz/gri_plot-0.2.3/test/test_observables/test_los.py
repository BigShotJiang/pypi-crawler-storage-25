"""Tests for observables.los module."""

import numpy as np
import pytest

from gri_plot import Figure3D, Frame
from gri_plot.observables import LosSurface


def test_residual_inside_outside():
    """Point on line is inside, far perpendicular is outside."""
    los = LosSurface(
        start_xyz=np.zeros(3),
        direction_xyz=np.array([1.0, 0.0, 0.0]),
        length=1000.0,
        width=10.0,
    )

    # On the line
    assert los.residual_fn(np.array([500.0, 0.0, 0.0])) < 0

    # Far off the line
    assert los.residual_fn(np.array([500.0, 100.0, 0.0])) > 0


def test_invalid_length():
    """Non-positive length raises ValueError."""
    with pytest.raises(ValueError):
        LosSurface(np.zeros(3), np.array([1.0, 0.0, 0.0]), length=0.0)


@pytest.mark.skip(reason="Visual test - unskip to generate plot")
def test_visual_los_ray():
    """Visual: Line of sight cylinder."""
    origin = np.zeros(3)
    direction = np.array([1.0, 0.3, 0.2])

    surface = LosSurface(origin, direction, length=500.0, width=10.0, label="LOS")

    fig = Figure3D(display_frame=Frame.XYZ, title="Line of Sight")
    fig.add_surface(surface, opacity=0.7)
    fig.add_points(origin.reshape(1, 3), labels=["Origin"])
    fig.show()
