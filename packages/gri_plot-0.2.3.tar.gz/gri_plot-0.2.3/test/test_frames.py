"""Tests for frames module."""

import numpy as np
import pytest
from gri_utils.conversion import lla_to_xyz, xyz_to_lla

from gri_plot.frames import Frame, FrameTransformer


def test_xyz_lla_roundtrip():
    """XYZ to LLA and back preserves coordinates."""
    xyz_original = np.array([4e6, 3e6, 4e6])
    lla = xyz_to_lla(xyz_original)
    xyz_recovered = lla_to_xyz(lla)

    np.testing.assert_allclose(xyz_recovered, xyz_original, rtol=1e-6)


def test_enu_requires_origin():
    """ENU frame transformer requires origin_xyz."""
    with pytest.raises(ValueError):
        FrameTransformer(Frame.ENU)


def test_enu_roundtrip():
    """ENU frame transformer roundtrip preserves coordinates."""
    origin = np.array([4e6, 3e6, 4e6])
    transformer = FrameTransformer(Frame.ENU, origin)

    xyz_original = origin + np.array([100.0, 200.0, 50.0])
    enu = transformer.to_display(xyz_original)
    xyz_recovered = transformer.from_display(enu)

    np.testing.assert_allclose(xyz_recovered, xyz_original, rtol=1e-6)


def test_axis_labels():
    """Frame transformers return correct axis labels."""
    assert FrameTransformer(Frame.XYZ).get_axis_labels() == ("X (m)", "Y (m)", "Z (m)")
    assert FrameTransformer(Frame.LLA).get_axis_labels() == (
        "Latitude (deg)",
        "Longitude (deg)",
        "Altitude (m)",
    )
