"""Tests for plot_ellipse module."""

import plotly.graph_objects as go
import pytest

from gri_plot import plot_ellipse
from gri_plot.shapes import Ellipse


def test_returns_figure():
    """Returns a Plotly Figure."""
    e = Ellipse(100.0, 50.0, 30.0)
    fig = plot_ellipse(e)
    assert isinstance(fig, go.Figure)


def test_requires_at_least_one_ellipse():
    """Raises ValueError when no ellipses provided."""
    with pytest.raises(ValueError, match="At least one"):
        plot_ellipse()


def test_multiple_ellipses_create_traces():
    """Each ellipse produces at least one trace."""
    e1 = Ellipse(100.0, 50.0, 0.0, label="A")
    e2 = Ellipse(200.0, 80.0, 45.0, center=(50.0, 50.0), label="B")
    fig = plot_ellipse(e1, e2)
    # At least 2 traces (one boundary per ellipse), plus axis annotations
    assert len(fig.data) >= 2  # pyright: ignore[reportArgumentType]


def test_show_axes_false_reduces_traces():
    """show_axes=False produces fewer traces than show_axes=True."""
    e = Ellipse(100.0, 50.0, 30.0)
    fig_with = plot_ellipse(e, show_axes=True)
    fig_without = plot_ellipse(e, show_axes=False)
    assert len(fig_without.data) < len(fig_with.data)  # pyright: ignore[reportArgumentType]


@pytest.mark.skip(reason="Visual test - unskip to view")
def test_visual_single_ellipse():
    """Visual: single error ellipse with axis annotations."""
    e = Ellipse(500.0, 200.0, 30.0, label="95% Error Ellipse")
    fig = plot_ellipse(e, title="Single Ellipse - 30 deg CW from North")
    fig.show()


@pytest.mark.skip(reason="Visual test - unskip to view")
def test_visual_multiple_ellipses():
    """Visual: multiple overlapping error ellipses."""
    e1 = Ellipse(500.0, 200.0, 30.0, label="Scenario A")
    e2 = Ellipse(300.0, 150.0, 120.0, center=(100.0, -50.0), label="Scenario B")
    e3 = Ellipse(400.0, 100.0, 75.0, center=(-200.0, 100.0), label="Scenario C")
    fig = plot_ellipse(e1, e2, e3, title="Multiple Error Ellipses")
    fig.show()
