"""Tests for surfaces.intersection module."""

import numpy as np
import plotly.graph_objects as go
import pytest

from gri_plot.surfaces import ImplicitShape
from gri_plot.surfaces.intersection import IntersectionField


class MockImplicitSurface(ImplicitShape):
    """Simple sphere for testing intersection logic."""

    def __init__(
        self,
        center: np.ndarray,
        radius: float,
        *,
        is_volume: bool = False,
    ) -> None:
        """Initialize the mock surface."""
        self._center = np.asarray(center, dtype=np.float64)
        self._radius = float(radius)
        self._is_volume = is_volume

    @property
    def is_volume(self) -> bool:
        """Whether this is a volume or surface."""
        return self._is_volume

    @property
    def label(self) -> str | None:
        """Label for display."""
        return None

    def residual_fn(self, xyz: np.ndarray) -> np.ndarray:
        """Compute distance from sphere surface."""
        xyz = np.asarray(xyz)
        dist = np.linalg.norm(xyz - self._center, axis=-1)
        return dist - self._radius

    def get_bounds_xyz(self) -> tuple[np.ndarray, np.ndarray]:
        """Get bounding box."""
        return (
            self._center - self._radius,
            self._center + self._radius,
        )

    def to_mesh(
        self,
        resolution: int | None = None,  # noqa: ARG002
    ) -> tuple[np.ndarray, np.ndarray]:
        """Return empty mesh."""
        return np.zeros((0, 3)), np.zeros((0, 3), dtype=np.int64)

    def to_trace(
        self,
        resolution: int | None = None,  # noqa: ARG002
        **kwargs,  # noqa: ARG002
    ) -> go.Mesh3d:
        """Return empty trace."""
        return go.Mesh3d()


def test_requires_at_least_two_surfaces():
    """IntersectionField requires at least 2 surfaces."""
    sphere = MockImplicitSurface(np.zeros(3), 100.0)

    with pytest.raises(ValueError, match="at least 2"):
        IntersectionField([sphere])


def test_distance_zero_at_intersection():
    """Distance is zero exactly on the intersection curve."""
    # Two overlapping spheres centered at origin and [100, 0, 0]
    s1 = MockImplicitSurface(np.zeros(3), 100.0)
    s2 = MockImplicitSurface(np.array([100.0, 0, 0]), 100.0)

    field = IntersectionField([s1, s2])

    # Actual intersection: x=50 plane, y = sqrt(100^2 - 50^2) = 86.6
    y_intersect = np.sqrt(100.0**2 - 50.0**2)
    intersection_point = np.array([[50.0, y_intersect, 0.0]])
    distance = field.distance_to_intersection(intersection_point)

    # Both residuals are ~0 at intersection, so distance should be ~0
    assert distance[0] == pytest.approx(0.0, abs=1e-10)


def test_distance_increases_away_from_intersection():
    """Distance increases as we move away from the intersection."""
    s1 = MockImplicitSurface(np.zeros(3), 100.0)
    s2 = MockImplicitSurface(np.array([100.0, 0, 0]), 100.0)

    field = IntersectionField([s1, s2])

    # Intersection point
    y_intersect = np.sqrt(100.0**2 - 50.0**2)
    intersection_point = np.array([50.0, y_intersect, 0.0])

    # Move away from intersection
    near_point = intersection_point + np.array([5.0, 0.0, 0.0])
    far_point = intersection_point + np.array([50.0, 0.0, 0.0])

    d_intersection = field.distance_to_intersection(intersection_point.reshape(1, 3))
    d_near = field.distance_to_intersection(near_point.reshape(1, 3))
    d_far = field.distance_to_intersection(far_point.reshape(1, 3))

    assert d_near[0] > d_intersection[0]
    assert d_far[0] > d_near[0]


def test_residual_fn_negative_at_intersection():
    """Residual is negative (inside tube) at intersections."""
    s1 = MockImplicitSurface(np.zeros(3), 100.0)
    s2 = MockImplicitSurface(np.array([100.0, 0, 0]), 100.0)

    field = IntersectionField([s1, s2], radius=10.0)

    # Actual intersection point on both surfaces
    y_intersect = np.sqrt(100.0**2 - 50.0**2)
    intersection_point = np.array([[50.0, y_intersect, 0.0]])
    residual = field.residual_fn(intersection_point)

    # Negative means inside the tube (distance < radius)
    assert residual[0] < 0


def test_residual_fn_positive_away_from_surfaces():
    """Residual is positive (outside tube) far from all surfaces."""
    s1 = MockImplicitSurface(np.zeros(3), 100.0)
    s2 = MockImplicitSurface(np.array([100.0, 0, 0]), 100.0)

    field = IntersectionField([s1, s2], radius=10.0)

    far_point = np.array([[1000.0, 1000.0, 1000.0]])
    residual = field.residual_fn(far_point)

    # Positive means outside the tube
    assert residual[0] > 0


def test_radius_property():
    """Radius can be set explicitly."""
    s1 = MockImplicitSurface(np.zeros(3), 100.0)
    s2 = MockImplicitSurface(np.array([100.0, 0, 0]), 100.0)

    field = IntersectionField([s1, s2], radius=25.0)

    assert field.radius == 25.0


def test_default_radius():
    """Default radius is 0.1."""
    s1 = MockImplicitSurface(np.zeros(3), 100.0)
    s2 = MockImplicitSurface(np.array([100.0, 0, 0]), 100.0)

    field = IntersectionField([s1, s2])

    assert field.radius == 0.1


def test_bounds_merges_all_surfaces():
    """get_bounds_xyz merges bounds from all surfaces."""
    s1 = MockImplicitSurface(np.zeros(3), 100.0)
    s2 = MockImplicitSurface(np.array([500.0, 0, 0]), 50.0)

    field = IntersectionField([s1, s2])
    min_corner, max_corner = field.get_bounds_xyz()

    # Should encompass both spheres
    assert min_corner[0] == pytest.approx(-100.0)
    assert max_corner[0] == pytest.approx(550.0)


def test_label_property():
    """Label can be set and retrieved."""
    s1 = MockImplicitSurface(np.zeros(3), 100.0)
    s2 = MockImplicitSurface(np.array([100.0, 0, 0]), 100.0)

    field = IntersectionField([s1, s2])
    assert field.label is None

    field.label = "Test Intersection"
    assert field.label == "Test Intersection"


def test_volume_intersection():
    """Volumes contribute 0 distance when inside."""
    # Sphere as volume
    s1 = MockImplicitSurface(np.zeros(3), 100.0, is_volume=True)
    s2 = MockImplicitSurface(np.array([50.0, 0, 0]), 100.0)  # Surface

    field = IntersectionField([s1, s2], radius=10.0)

    # Point inside s1 (volume) and on surface of s2
    # s1 residual < 0 (inside), s2 residual = 0 (on surface)
    point = np.array([[50.0, 0.0, 0.0]])  # On s2's surface, inside s1
    distance = field.distance_to_intersection(point)

    # Only s2 contributes (s1 is inside, so max(0, residual) = 0)
    s2_residual = s2.residual_fn(point)[0]
    assert distance[0] == pytest.approx(abs(s2_residual), abs=1e-10)
