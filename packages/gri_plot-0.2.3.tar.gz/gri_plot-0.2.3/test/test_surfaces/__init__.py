"""Tests for surfaces module."""
