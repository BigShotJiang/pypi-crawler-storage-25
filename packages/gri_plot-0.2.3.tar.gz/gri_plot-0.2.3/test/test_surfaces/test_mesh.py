"""Tests for surfaces.mesh module."""

import numpy as np
import plotly.graph_objects as go
import pytest

from gri_plot.shapes.meshgen import sphere_mesh
from gri_plot.surfaces.mesh import (
    compute_edge_dihedral_angles,
    compute_face_normals,
    field_to_mesh,
    refine_mesh,
    vertices_to_mesh3d,
)


def test_vertices_to_mesh3d():
    """vertices_to_mesh3d creates a Mesh3d trace."""
    vertices = np.array([[0, 0, 0], [1, 0, 0], [0, 1, 0], [0, 0, 1]], dtype=float)
    faces = np.array([[0, 1, 2], [0, 1, 3], [0, 2, 3], [1, 2, 3]])

    trace = vertices_to_mesh3d(vertices, faces)

    assert isinstance(trace, go.Mesh3d)


def test_sphere_mesh_vertices_on_surface():
    """sphere_mesh vertices are at correct distance from center."""
    center = np.array([10.0, 20.0, 30.0])
    radius = 50.0

    vertices, _ = sphere_mesh(center, radius, resolution=20)
    distances = np.linalg.norm(vertices - center, axis=1)

    np.testing.assert_allclose(distances, radius, rtol=1e-6)


# --- Face normals tests ---


def test_compute_face_normals_single_triangle():
    """Face normal for an XY-plane triangle points in Z direction."""
    vertices = np.array([[0, 0, 0], [1, 0, 0], [0, 1, 0]], dtype=float)
    faces = np.array([[0, 1, 2]])

    normals = compute_face_normals(vertices, faces)

    assert normals.shape == (1, 3)
    # Normal should point in +Z or -Z direction (unit vector)
    np.testing.assert_allclose(np.abs(normals[0, 2]), 1.0, atol=1e-10)


def test_compute_face_normals_tetrahedron():
    """Tetrahedron faces have unit-length normals."""
    vertices = np.array([[0, 0, 0], [1, 0, 0], [0.5, 1, 0], [0.5, 0.5, 1]], dtype=float)
    faces = np.array([[0, 1, 2], [0, 1, 3], [1, 2, 3], [2, 0, 3]])

    normals = compute_face_normals(vertices, faces)

    assert normals.shape == (4, 3)
    lengths = np.linalg.norm(normals, axis=1)
    np.testing.assert_allclose(lengths, 1.0, atol=1e-10)


# --- Dihedral angle tests ---


def test_dihedral_angles_flat_surface():
    """Coplanar triangles have dihedral angle of 0."""
    # Two triangles sharing edge (0,1), both in XY plane
    vertices = np.array(
        [[0, 0, 0], [1, 0, 0], [0.5, 1, 0], [0.5, -1, 0]],
        dtype=float,
    )
    faces = np.array([[0, 1, 2], [0, 3, 1]])

    angles = compute_edge_dihedral_angles(vertices, faces)

    # The shared edge (0,1) should have angle ~0
    shared_edge = (0, 1)
    assert shared_edge in angles
    assert angles[shared_edge] == pytest.approx(0.0, abs=1e-10)


def test_dihedral_angles_right_angle():
    """Perpendicular triangles have dihedral angle of pi/2."""
    # Two triangles at 90 degrees
    vertices = np.array(
        [[0, 0, 0], [1, 0, 0], [0, 1, 0], [0, 0, 1]],
        dtype=float,
    )
    # Face 1: XY plane, Face 2: XZ plane, sharing edge (0,1)
    faces = np.array([[0, 1, 2], [0, 1, 3]])

    angles = compute_edge_dihedral_angles(vertices, faces)

    shared_edge = (0, 1)
    assert shared_edge in angles
    assert angles[shared_edge] == pytest.approx(np.pi / 2, abs=1e-10)


def test_dihedral_angles_boundary_edges_excluded():
    """Boundary edges (single face) are not in the result."""
    vertices = np.array([[0, 0, 0], [1, 0, 0], [0, 1, 0]], dtype=float)
    faces = np.array([[0, 1, 2]])

    angles = compute_edge_dihedral_angles(vertices, faces)

    # Single triangle has no interior edges
    assert len(angles) == 0


# --- Mesh refinement tests ---


def test_refine_mesh_no_refinement_when_flat():
    """Flat mesh with no high-curvature edges stays unchanged."""
    # Two coplanar triangles
    vertices = np.array(
        [[0, 0, 0], [1, 0, 0], [0.5, 1, 0], [0.5, -1, 0]],
        dtype=float,
    )
    faces = np.array([[0, 1, 2], [0, 3, 1]])

    refined_v, refined_f = refine_mesh(vertices, faces, angle_threshold=0.1)

    # Should remain unchanged (no high-curvature edges)
    assert len(refined_v) == len(vertices)
    assert len(refined_f) == len(faces)


def test_refine_mesh_subdivides_high_curvature():
    """High-curvature edges cause subdivision."""
    # Two triangles at 90 degrees (pi/2 dihedral angle)
    vertices = np.array(
        [[0, 0, 0], [1, 0, 0], [0, 1, 0], [0, 0, 1]],
        dtype=float,
    )
    faces = np.array([[0, 1, 2], [0, 1, 3]])

    # Threshold below pi/2 should trigger subdivision
    refined_v, refined_f = refine_mesh(vertices, faces, angle_threshold=0.3)

    # Should have more vertices and faces after subdivision
    assert len(refined_v) > len(vertices)
    assert len(refined_f) > len(faces)


def test_refine_mesh_with_projection():
    """Refinement with residual_fn projects new vertices onto surface."""
    # Simple sphere residual function
    center = np.array([0.5, 0.5, 0.5])
    radius = 1.0

    def sphere_residual(xyz: np.ndarray) -> np.ndarray:
        return np.linalg.norm(xyz - center, axis=-1) - radius

    # Two triangles with high dihedral angle
    vertices = np.array(
        [[0, 0, 0], [1, 0, 0], [0, 1, 0], [0, 0, 1]],
        dtype=float,
    )
    faces = np.array([[0, 1, 2], [0, 1, 3]])

    refined_v, _ = refine_mesh(
        vertices,
        faces,
        residual_fn=sphere_residual,
        angle_threshold=0.3,
    )

    # New vertices (beyond original 4) should be near the sphere surface
    if len(refined_v) > 4:
        new_vertices = refined_v[4:]
        residuals = sphere_residual(new_vertices)
        # Residuals should be small (projected onto surface)
        np.testing.assert_allclose(residuals, 0.0, atol=0.1)


def test_refine_mesh_max_iterations_limits_refinement():
    """max_iterations limits the number of refinement passes."""
    # Highly curved surface - octahedron has 90-degree edges
    vertices = np.array(
        [[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]],
        dtype=float,
    )
    faces = np.array(
        [
            [0, 2, 4],
            [2, 1, 4],
            [1, 3, 4],
            [3, 0, 4],
            [0, 3, 5],
            [3, 1, 5],
            [1, 2, 5],
            [2, 0, 5],
        ],
    )

    # Single iteration should produce fewer faces than multiple
    _v1, f1 = refine_mesh(vertices, faces, angle_threshold=0.3, max_iterations=1)
    _v3, f3 = refine_mesh(vertices, faces, angle_threshold=0.3, max_iterations=3)

    assert len(f3) >= len(f1)


# --- field_to_mesh with refinement ---


def test_field_to_mesh_with_refinement():
    """field_to_mesh with refine=True produces more faces than without."""
    center = np.array([0.0, 0.0, 0.0])
    radius = 100.0

    def sphere_residual(xyz: np.ndarray) -> np.ndarray:
        return np.linalg.norm(xyz - center, axis=-1) - radius

    bounds = (np.array([-150.0, -150.0, -150.0]), np.array([150.0, 150.0, 150.0]))

    # Without refinement
    _v_no_refine, f_no_refine = field_to_mesh(
        sphere_residual,
        bounds,
        resolution=15,
        refine=False,
    )

    # With refinement
    _v_refine, f_refine = field_to_mesh(
        sphere_residual,
        bounds,
        resolution=15,
        refine=True,
        refine_angle_threshold=0.2,
        refine_iterations=2,
    )

    # Refined mesh should have more faces
    assert len(f_refine) > len(f_no_refine)
