"""Tests for s41 P6 — smoke test + prompt-gated rollback.

P6 adds:
  - Stage 0: pre-update snapshot (pkg version, pkg git hash for editable,
    bridge git hash for git method) written to a temp JSON file.
  - Stage 4: replaces simple `eval "$check" || exit 1` with smoke-test +
    rollback-decision logic. On check failure:
      * --no-rollback:   exit 1 with hints, no rollback dispatched.
      * --auto-rollback: rollback without prompt (CI-friendly).
      * default (TTY):   prompt y/N before any rollback.
      * default (no-TTY): print actionable commands + exit 1, no auto-undo.
  - Rollback dispatch: editable does git reset + pip reinstall; pipx-pypi
    does pipx install --force <pkg>==<prev>; pipx-git is best-effort
    (warns + manual recovery); bridge git resets to prior hash; rsync
    bridge cannot be rolled back (warns).
"""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
SCRIPT = REPO_ROOT / "src" / "seif" / "scripts" / "host" / "seif-update.sh"


def _read_script() -> str:
    return SCRIPT.read_text()


# ── New flags surface ───────────────────────────────────────────


def test_no_rollback_flag_supported():
    text = _read_script()
    assert "--no-rollback" in text
    assert 'ROLLBACK_MODE="none"' in text


def test_auto_rollback_flag_supported():
    text = _read_script()
    assert "--auto-rollback" in text
    assert 'ROLLBACK_MODE="auto"' in text


def test_default_rollback_mode_is_prompt():
    text = _read_script()
    assert 'ROLLBACK_MODE="prompt"' in text


def test_help_documents_p6_flags():
    text = _read_script()
    head = text[:2000]
    assert "--no-rollback" in head
    assert "--auto-rollback" in head


# ── Stage 0: snapshot ───────────────────────────────────────────


def test_snapshot_stage_present():
    text = _read_script()
    assert "Stage 0: pre-update snapshot" in text
    assert "SNAPSHOT_FILE=" in text
    assert "mktemp" in text


def test_snapshot_traps_cleanup_on_exit():
    text = _read_script()
    assert 'trap \'rm -f "$SNAPSHOT_FILE"\' EXIT' in text


def test_snapshot_captures_editable_git_hash():
    text = _read_script()
    snap_start = text.find("Stage 0: pre-update snapshot")
    snap_end = text.find("Stage 1:", snap_start)
    block = text[snap_start:snap_end]
    assert 'pre_pkg_git_hash=' in block
    assert "rev-parse HEAD" in block


def test_snapshot_captures_bridge_git_hash():
    text = _read_script()
    snap_start = text.find("Stage 0: pre-update snapshot")
    snap_end = text.find("Stage 1:", snap_start)
    block = text[snap_start:snap_end]
    assert 'pre_bridge_git_hash=' in block


# ── Stage 4: rollback dispatch ──────────────────────────────────


def test_smoke_test_failure_prints_rollback_plan():
    text = _read_script()
    assert "ROLLBACK PLAN" in text
    assert "pre-pkg-version:" in text


def test_rollback_plan_shows_editable_recovery_commands():
    text = _read_script()
    plan_start = text.find("ROLLBACK PLAN")
    dispatch_start = text.find("ROLLBACK DISPATCH", plan_start)
    block = text[plan_start:dispatch_start]
    assert "git -C" in block and "reset --hard" in block
    # s46 p3 rewrote the editable rollback line to use the safer
    # `${PIP_CMD:-python3 -m pip}` brace-with-default form so PIP_CMD being
    # unset doesn't crash the rollback prompt. Accept either form: bare
    # `$PIP_CMD install -e` or `${PIP_CMD:-...} install -e`.
    assert (
        "$PIP_CMD install -e" in block
        or "${PIP_CMD:-" in block and "install -e" in block
    )


def test_rollback_plan_shows_pipx_pypi_recovery():
    text = _read_script()
    plan_start = text.find("ROLLBACK PLAN")
    dispatch_start = text.find("ROLLBACK DISPATCH", plan_start)
    block = text[plan_start:dispatch_start]
    assert "pipx install --force" in block


def test_rollback_plan_handles_rsync_bridge():
    """Post-s43 B3: rsync rollback is conditionally supported (when atomic
    swap created a fresh .prev). Plan must show both branches."""
    text = _read_script()
    plan_start = text.find("ROLLBACK PLAN")
    dispatch_start = text.find("ROLLBACK DISPATCH", plan_start)
    block = text[plan_start:dispatch_start]
    # Supported branch: swap-back from .prev
    assert ".prev" in block, "Plan must reference the .prev swap-back path"
    # Unavailable branch: clear messaging when prev wasn't created this run
    assert "rsync rollback unavailable" in block or "Manual recovery required" in block


def test_no_rollback_mode_exits_one_without_undo():
    text = _read_script()
    case_start = text.find('"$ROLLBACK_MODE"')
    auto_start = text.find("auto)", case_start)
    block = text[case_start:auto_start]
    assert "rollback skipped (--no-rollback)" in block
    assert "exit 1" in block


def test_auto_rollback_skips_prompt():
    text = _read_script()
    auto_start = text.find("auto)")
    prompt_start = text.find("prompt)", auto_start)
    block = text[auto_start:prompt_start]
    assert 'DECISION="y"' in block
    assert "without prompt" in block


def test_prompt_mode_only_prompts_when_tty():
    text = _read_script()
    prompt_start = text.find("prompt)")
    case_close = text.find("esac", prompt_start)
    block = text[prompt_start:case_close]
    assert "[ -t 0 ]" in block
    assert 'read -rp "Roll back' in block
    assert "stdin is not a TTY" in block


def test_post_rollback_check_runs_again():
    text = _read_script()
    assert "POST-ROLLBACK CHECK" in text
    assert "rollback verified" in text
    assert "post-rollback check ALSO failed" in text


def test_rollback_restarts_daemons_after_revert():
    text = _read_script()
    dispatch_start = text.find("ROLLBACK DISPATCH")
    assert "restart daemons after rollback" in text[dispatch_start:]
    assert "launchctl kickstart -k" in text[dispatch_start:]


# ── Backwards compatibility ─────────────────────────────────────


def test_check_mode_still_works(tmp_path):
    cfg_data = {
        "protocol": "SEIF-HOST-INSTALL-CONFIG-v2",
        "host_label": "p6-check-host",
        "install_method": "pipx",
        "package_name": "seif-cli",
        "package_source": "pypi",
        "extra_packages": [],
        "post_install_check": "true",
    }
    seif_dir = tmp_path / ".seif"
    seif_dir.mkdir()
    (seif_dir / "host-install-config.seif").write_text(json.dumps(cfg_data))

    result = subprocess.run(
        ["bash", str(SCRIPT), "--check"],
        capture_output=True,
        text=True,
        env={**os.environ, "HOME": str(tmp_path)},
        timeout=10,
    )
    assert result.returncode == 0, result.stderr
    assert "p6-check-host" in result.stdout
    # snapshot stage should NOT have run for --check
    assert "snapshot:" not in result.stdout


def test_no_restart_and_no_rollback_compose(tmp_path):
    """--no-restart and --no-rollback can be combined without parser errors."""
    cfg_data = {
        "protocol": "SEIF-HOST-INSTALL-CONFIG-v2",
        "host_label": "compose-host",
        "install_method": "editable",
        "package_name": "seif-cli",
        "source_repo": str(tmp_path / "src"),
        "source_branch": "main",
        "extra_packages": [],
        "post_install_check": "true",
    }
    seif_dir = tmp_path / ".seif"
    seif_dir.mkdir()
    (seif_dir / "host-install-config.seif").write_text(json.dumps(cfg_data))

    result = subprocess.run(
        ["bash", str(SCRIPT), "--no-restart", "--no-rollback", "--check"],
        capture_output=True,
        text=True,
        env={**os.environ, "HOME": str(tmp_path)},
        timeout=10,
    )
    assert result.returncode == 0, result.stderr


# ── Bash syntax ─────────────────────────────────────────────────


def test_bash_syntax_valid_after_p6():
    result = subprocess.run(
        ["bash", "-n", str(SCRIPT)],
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, f"bash -n failed: {result.stderr}"
