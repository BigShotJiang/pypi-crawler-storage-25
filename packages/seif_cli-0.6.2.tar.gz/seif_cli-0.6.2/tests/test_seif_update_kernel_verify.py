"""Tests for s44 v2 distribution — Stage 1.6 kernel-verify in seif-update.sh.

After the package install + template refresh, seif-update.sh runs
`seif --verify-resonance` against the kernel envelope shipped in the
installed package. Catches:
  - unsigned kernel envelopes (the s44 PR #75/#76 incident)
  - signature/canonical_hash mismatches (content tampered after sign)
  - unknown protocol versions (e.g., v3 on a v2 peer)

On failure, the stage exits 1 with rollback guidance — bridge sync
(Stage 2) is gated on this passing so a peer never sees a broken kernel
envelope.

These tests verify the script structure (presence of stage markers,
exit-on-fail, recovery section). End-to-end behavior requires a real
Air sandbox and is exercised manually during distribution rollout.
"""
from __future__ import annotations

from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
SCRIPT = REPO_ROOT / "src" / "seif" / "scripts" / "host" / "seif-update.sh"


def _read_script() -> str:
    return SCRIPT.read_text(encoding="utf-8")


def test_kernel_verify_stage_block_exists():
    text = _read_script()
    assert "Stage 1.6: kernel envelope verify" in text, (
        "Stage 1.6 marker missing from canonical template"
    )


def test_kernel_verify_positioned_between_template_refresh_and_bridge_sync():
    text = _read_script()
    template_idx = text.find("Stage 1.5: template refresh")
    kernel_idx = text.find("Stage 1.6: kernel envelope verify")
    bridge_idx = text.find("Stage 2: bridge repo sync")
    assert template_idx > 0, "Stage 1.5 marker missing"
    assert kernel_idx > 0, "Stage 1.6 marker missing"
    assert bridge_idx > 0, "Stage 2 marker missing"
    assert template_idx < kernel_idx < bridge_idx, (
        f"Stage ordering wrong: 1.5={template_idx}, 1.6={kernel_idx}, "
        f"2={bridge_idx}"
    )


def test_kernel_verify_uses_seif_cli_flag():
    text = _read_script()
    assert "seif --verify-resonance" in text, (
        "Stage 1.6 must call `seif --verify-resonance`"
    )


def test_kernel_verify_resolves_path_via_python_import():
    text = _read_script()
    assert "import seif" in text and "RESONANCE.json" in text, (
        "Stage 1.6 must resolve RESONANCE.json path via Python `import seif`"
    )


def test_kernel_verify_exits_on_failure():
    text = _read_script()
    # The fail branch must end with `exit 1` to gate Stage 2.
    fail_block_start = text.find("KERNEL ENVELOPE INVALID")
    assert fail_block_start > 0, "fail branch missing"
    fail_block = text[fail_block_start:fail_block_start + 1500]
    assert "exit 1" in fail_block, (
        "Stage 1.6 fail branch must `exit 1` to prevent Stage 2"
    )


def test_kernel_verify_emits_recovery_guidance():
    text = _read_script()
    fail_block_start = text.find("KERNEL ENVELOPE INVALID")
    fail_block = text[fail_block_start:fail_block_start + 2000]
    assert "Recovery:" in fail_block, "fail branch must print Recovery: section"
    # Recovery must mention pipx-from-git rollback (the dominant Air path).
    assert "pipx install --force" in fail_block, (
        "fail branch must include pipx rollback hint"
    )


def test_kernel_verify_skippable_via_env_flag():
    """KERNEL_VERIFY=0 disables the stage — useful for CI smoke runs that
    install a freshly-built unsigned dev kernel and don't want this stage
    to abort.
    """
    text = _read_script()
    assert 'KERNEL_VERIFY:-1' in text or "KERNEL_VERIFY=" in text, (
        "Stage 1.6 should respect KERNEL_VERIFY env var (default=1)"
    )
    skip_msg_idx = text.find("KERNEL_VERIFY=0")
    assert skip_msg_idx > 0 or "skipped" in text.lower(), (
        "skip path should emit a `skipped` message"
    )


def test_kernel_verify_skips_gracefully_when_resonance_missing():
    """If the package install didn't ship RESONANCE.json (impossible in
    canonical builds, but defensive), the stage warns and continues — does
    NOT abort the update. Stage 2 still runs.
    """
    text = _read_script()
    # Locate the empty-path branch: `if [ -z "$kernel_path" ]`
    miss_block = text.find("RESONANCE.json not found in installed package")
    assert miss_block > 0, "missing-kernel branch must warn"
    # The branch should NOT exit 1 — it should fall through to Stage 2.
    miss_section = text[miss_block:miss_block + 600]
    # First `exit 1` after the warn message belongs to the FAILED branch
    # (different `if` arm), not this one. The test asserts the warn message
    # itself is followed by `elif ! seif --verify-resonance` (the next arm),
    # not by an immediate `exit 1`.
    next_construct = miss_section.find("elif !")
    immediate_exit = miss_section.find("exit 1")
    if immediate_exit > 0:
        assert next_construct < immediate_exit, (
            "missing-kernel branch must fall through, not exit"
        )


if __name__ == "__main__":
    import pytest
    pytest.main([__file__, "-v"])
