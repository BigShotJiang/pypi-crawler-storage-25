"""Smoke test for the Wedge A end-to-end demo chain.

Runs ``demo/wedge-a/chain.py --no-docker --no-ots`` via subprocess and
asserts:

- exit 0
- all 3 local-only surfaces report a match (envelope / audio / signature)
- the deterministic input artifact hash appears in the output

Doesn't exercise the docker-dependent steps (log_append / log_get /
body upload-download) — those are validated by the live integration
test against the real seif-log compose stack (out of scope for this
suite).

Doesn't exercise the OTS bonus step either — `ots` may not be on the
CI runner's PATH.
"""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

import pytest


REPO_ROOT = Path(__file__).resolve().parent.parent
DEMO_DIR = REPO_ROOT / "demo" / "wedge-a"
EXPECTED_ARTIFACT_HASH = "a859fca2c7c4f959dcf34bc20f8cedbe7ccdb681f2a810c876f8de23f7f42d58"


pytest.importorskip("cryptography")
pytest.importorskip("numpy")


@pytest.fixture
def isolated_seif_home(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Redirect ~/.seif/ to a tmpdir + generate fresh keypair + identity.

    Without this, the chain mutates the real user's ~/.seif/keys/ and
    ~/.seif/identities/. With it, every test run starts from a clean
    Ed25519 state.
    """
    home = tmp_path / "seif_home"
    home.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("SEIF_HOME", str(home))
    from seif.core import signing
    signing.keygen()
    return home


def test_chain_no_docker_no_ots_exit_0(isolated_seif_home):
    result = subprocess.run(
        [sys.executable, str(DEMO_DIR / "chain.py"), "--no-docker", "--no-ots"],
        capture_output=True,
        text=True,
        cwd=REPO_ROOT,
        env={**os.environ, "SEIF_HOME": str(isolated_seif_home)},
        timeout=120,
    )
    if result.returncode != 0:
        # Surface stderr in the failure for fast triage
        pytest.fail(
            f"chain.py exited {result.returncode}\n"
            f"--- stdout ---\n{result.stdout}\n"
            f"--- stderr ---\n{result.stderr}"
        )

    output = result.stdout

    # Determinism: the input artifact hash must appear (and be the
    # canonical one we shipped). If artifact.json gets edited the gold-
    # file step will fail this anyway, but assert explicitly so the
    # error message is obvious.
    assert EXPECTED_ARTIFACT_HASH in output, (
        f"expected H_orig {EXPECTED_ARTIFACT_HASH!r} in chain output"
    )

    # Final summary should declare VERIFIED + 3/3 surfaces match
    assert "Wedge A end-to-end provenance" in output
    assert "VERIFIED" in output
    assert "3/3 surfaces match" in output


def test_chain_module_importable():
    """Sanity: every helper in chain.py imports without side effects."""
    from importlib.util import spec_from_file_location, module_from_spec

    chain_path = DEMO_DIR / "chain.py"
    spec = spec_from_file_location("wedge_a_chain", chain_path)
    assert spec is not None
    mod = module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(mod)

    # Confirm public step functions are present
    for name in (
        "step_hash_artifact",
        "step_quality_gate",
        "step_classify",
        "step_sign",
        "step_log_append",
        "step_upload_body",
        "step_embed_audio",
        "step_log_get",
        "step_download_body",
        "step_audio_verify",
        "step_provenance_verify",
        "step_ots_verify",
        "main",
    ):
        assert hasattr(mod, name), f"chain.py missing {name}"


def test_artifact_matches_gold_file():
    """The shipped artifact.json's sha256 must equal the gold-file value.

    Failing here means the artifact was edited without updating the
    gold-file — break the demo's reproducibility invariant.
    """
    import hashlib

    artifact = DEMO_DIR / "artifact.json"
    actual = hashlib.sha256(artifact.read_bytes()).hexdigest()
    assert actual == EXPECTED_ARTIFACT_HASH, (
        f"artifact.json sha256 changed: {actual} (expected: {EXPECTED_ARTIFACT_HASH}). "
        f"If intentional, update demo/wedge-a/expected-hashes.txt + this test constant."
    )

    gold_file = DEMO_DIR / "expected-hashes.txt"
    gold_content = gold_file.read_text().strip()
    assert gold_content == f"{EXPECTED_ARTIFACT_HASH}  artifact.json"
