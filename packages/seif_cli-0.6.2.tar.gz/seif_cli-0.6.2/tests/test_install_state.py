"""Tests for install-state drift detector (s46 p3).

Pre-fix: when host-install-config.seif declared install_method=editable
but the actual on-disk install was a frozen pipx-from-git, the host
ran stale code while operators believed source-repo edits reflected
immediately. Discovered on Mini in s46 diagnostic: pipx venv was 50+
commits behind main, soak-window assumptions broken.

Post-fix:
- `detect_editable_drift(config_path)` reads the config + the pipx
  venv's PEP 610 `direct_url.json`, classifies actual state as one
  of {editable-pipx, frozen-pipx, no-pipx-install, no-config}, and
  reports drift with an actionable remediation hint.
- `seif-update.sh` Stage 0.5 invokes this and emits a loud warning
  before Stage 1 dispatches the install.
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from seif.context.install_state import (  # noqa: E402
    _direct_url_state,
    _find_pipx_dist_info,
    _read_config,
    detect_editable_drift,
)


def _write_config(path: Path, **fields) -> None:
    base = {
        "protocol": "SEIF-HOST-INSTALL-CONFIG-v2",
        "host_label": "test-host",
        "package_name": "seif-cli",
    }
    base.update(fields)
    path.write_text(json.dumps(base, indent=2), encoding="utf-8")


def _write_direct_url(pipx_root: Path, pkg: str, *, editable: bool,
                      url: str = "git+https://example/x.git",
                      commit_id: str = "abc123") -> Path:
    """Create a fake pipx venv layout with a `direct_url.json` for `pkg`."""
    pkg_underscored = pkg.replace("-", "_")
    dist_info = (pipx_root / pkg / "lib" / "python3.14" /
                 "site-packages" / f"{pkg_underscored}-0.6.1.dist-info")
    dist_info.mkdir(parents=True)
    payload = {
        "url": url,
        "vcs_info": {"commit_id": commit_id, "vcs": "git"},
        "dir_info": {"editable": editable},
    }
    out = dist_info / "direct_url.json"
    out.write_text(json.dumps(payload), encoding="utf-8")
    return out


class ReadConfigTests(unittest.TestCase):
    def test_returns_empty_dict_on_missing_file(self):
        self.assertEqual(_read_config(Path("/nonexistent/x.seif")), {})

    def test_returns_empty_dict_on_invalid_json(self):
        with tempfile.NamedTemporaryFile(suffix=".seif",
                                         delete=False, mode="w") as f:
            f.write("{ malformed json")
            path = Path(f.name)
        try:
            self.assertEqual(_read_config(path), {})
        finally:
            path.unlink()

    def test_returns_dict_for_valid_config(self):
        with tempfile.NamedTemporaryFile(suffix=".seif",
                                         delete=False, mode="w") as f:
            json.dump({"install_method": "editable"}, f)
            path = Path(f.name)
        try:
            self.assertEqual(_read_config(path), {"install_method": "editable"})
        finally:
            path.unlink()


class FindPipxDistInfoTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.pipx_root = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def test_returns_none_when_venv_missing(self):
        self.assertIsNone(_find_pipx_dist_info("seif-cli", self.pipx_root))

    def test_locates_dist_info_for_hyphenated_pkg(self):
        path = _write_direct_url(self.pipx_root, "seif-cli", editable=True)
        found = _find_pipx_dist_info("seif-cli", self.pipx_root)
        self.assertEqual(found, path)


class DirectUrlStateTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.pipx_root = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def test_editable_true(self):
        path = _write_direct_url(self.pipx_root, "seif-cli", editable=True,
                                 url="file:///path/to/src", commit_id="")
        info = _direct_url_state(path)
        self.assertTrue(info["editable"])
        self.assertEqual(info["url"], "file:///path/to/src")
        self.assertEqual(info["commit_id"], "")

    def test_frozen_with_commit(self):
        path = _write_direct_url(self.pipx_root, "seif-cli", editable=False,
                                 commit_id="deadbeef")
        info = _direct_url_state(path)
        self.assertFalse(info["editable"])
        self.assertEqual(info["commit_id"], "deadbeef")

    def test_invalid_json_returns_zeros(self):
        path = self.pipx_root / "junk.json"
        path.write_text("not json")
        info = _direct_url_state(path)
        self.assertFalse(info["editable"])
        self.assertEqual(info["url"], "")
        self.assertEqual(info["commit_id"], "")


class DetectEditableDriftTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        root = Path(self.tmp.name)
        self.config = root / "host-install-config.seif"
        self.pipx_root = root / "pipx_venvs"
        self.pipx_root.mkdir()
        self.src = root / "src-repo"
        self.src.mkdir()

    def tearDown(self):
        self.tmp.cleanup()

    def test_no_config(self):
        result = detect_editable_drift(Path("/nonexistent/x.seif"),
                                       self.pipx_root)
        self.assertFalse(result["in_drift"])
        self.assertEqual(result["actual_state"], "no-config")

    def test_editable_declared_frozen_actual_drifts(self):
        _write_config(self.config, install_method="editable",
                      source_repo=str(self.src))
        _write_direct_url(self.pipx_root, "seif-cli", editable=False)
        result = detect_editable_drift(self.config, self.pipx_root)
        self.assertTrue(result["in_drift"])
        self.assertEqual(result["declared_method"], "editable")
        self.assertEqual(result["actual_state"], "frozen-pipx")
        self.assertIn("pipx install --editable --force", result["remediation"])
        self.assertIn(str(self.src), result["remediation"])

    def test_editable_declared_editable_actual_no_drift(self):
        _write_config(self.config, install_method="editable",
                      source_repo=str(self.src))
        _write_direct_url(self.pipx_root, "seif-cli", editable=True,
                          url=f"file://{self.src}", commit_id="")
        result = detect_editable_drift(self.config, self.pipx_root)
        self.assertFalse(result["in_drift"])
        self.assertEqual(result["actual_state"], "editable-pipx")
        self.assertEqual(result["remediation"], "")

    def test_editable_declared_no_pipx_drifts(self):
        _write_config(self.config, install_method="editable",
                      source_repo=str(self.src))
        # No direct_url.json written
        result = detect_editable_drift(self.config, self.pipx_root)
        self.assertTrue(result["in_drift"])
        self.assertEqual(result["actual_state"], "no-pipx-install")
        self.assertIn("pipx install --editable --force", result["remediation"])

    def test_pipx_declared_editable_actual_drifts(self):
        _write_config(self.config, install_method="pipx",
                      package_source="git+https://example/x@main")
        _write_direct_url(self.pipx_root, "seif-cli", editable=True)
        result = detect_editable_drift(self.config, self.pipx_root)
        self.assertTrue(result["in_drift"])
        self.assertIn("pipx install --force", result["remediation"])
        self.assertIn("git+https://example/x@main", result["remediation"])

    def test_pipx_declared_frozen_actual_no_drift(self):
        _write_config(self.config, install_method="pipx",
                      package_source="git+https://example/x@main")
        _write_direct_url(self.pipx_root, "seif-cli", editable=False)
        result = detect_editable_drift(self.config, self.pipx_root)
        self.assertFalse(result["in_drift"])

    def test_remediation_says_set_source_when_missing(self):
        _write_config(self.config, install_method="editable")
        _write_direct_url(self.pipx_root, "seif-cli", editable=False)
        result = detect_editable_drift(self.config, self.pipx_root)
        self.assertTrue(result["in_drift"])
        self.assertIn("source_repo", result["remediation"])

    def test_custom_package_name_resolves_in_drift(self):
        _write_config(self.config, install_method="editable",
                      package_name="custom-pkg",
                      source_repo=str(self.src))
        _write_direct_url(self.pipx_root, "custom-pkg", editable=False)
        result = detect_editable_drift(self.config, self.pipx_root)
        self.assertTrue(result["in_drift"])
        self.assertEqual(result["package_name"], "custom-pkg")


if __name__ == "__main__":
    unittest.main()
