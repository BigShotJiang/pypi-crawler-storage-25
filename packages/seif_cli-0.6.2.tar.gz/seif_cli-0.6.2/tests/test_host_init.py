"""Tests for seif.context.host_init."""

import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from seif.context import host_init as hi


class TestHostInit(unittest.TestCase):

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="seif_host_"))
        self._restore = self._monkey_home(self.tmp)

    def tearDown(self):
        import shutil
        self._restore()
        shutil.rmtree(self.tmp, ignore_errors=True)

    def _monkey_home(self, home):
        from seif.data import paths
        original_paths = paths.get_user_home
        original_hi = hi.get_user_home
        paths.get_user_home = lambda: home
        hi.get_user_home = lambda: home

        def restore():
            paths.get_user_home = original_paths
            hi.get_user_home = original_hi
        return restore

    # ── machine_id ──────────────────────────────────────────────────────────

    def test_generate_machine_id_has_required_fields(self):
        m = hi.generate_machine_id(hostname="test.local", label="test", role="dev")
        self.assertEqual(m["protocol"], hi.MACHINE_ID_PROTOCOL)
        self.assertEqual(m["hostname"], "test.local")
        self.assertEqual(m["label"], "test")
        self.assertEqual(m["role"], "dev")
        self.assertEqual(len(m["fingerprint"]), 32)  # 16 hex bytes
        self.assertIn("created_at", m)

    def test_generate_rejects_bad_role(self):
        with self.assertRaises(ValueError):
            hi.generate_machine_id(role="banana")

    def test_label_derived_from_hostname(self):
        m = hi.generate_machine_id(hostname="My-Box.local")
        self.assertEqual(m["label"], "my-box")

    def test_ensure_machine_id_creates_then_reuses(self):
        m1, c1 = hi.ensure_machine_id(label="foo", role="dev")
        self.assertTrue(c1)
        m2, c2 = hi.ensure_machine_id(label="foo", role="dev")
        self.assertFalse(c2)
        self.assertEqual(m1["fingerprint"], m2["fingerprint"])

    def test_ensure_machine_id_refreshes_label_without_rotating_fingerprint(self):
        m1, _ = hi.ensure_machine_id(label="old", role="dev")
        m2, created = hi.ensure_machine_id(label="new", role="production")
        self.assertFalse(created)
        self.assertEqual(m2["label"], "new")
        self.assertEqual(m2["role"], "production")
        self.assertEqual(m1["fingerprint"], m2["fingerprint"])

    def test_overwrite_rotates_fingerprint(self):
        m1, _ = hi.ensure_machine_id(label="x")
        m2, created = hi.ensure_machine_id(label="x", overwrite=True)
        self.assertTrue(created)
        self.assertNotEqual(m1["fingerprint"], m2["fingerprint"])

    # ── bridge-config.json ──────────────────────────────────────────────────

    def test_write_bridge_config(self):
        hubs = [hi.HubSpec(name="primary", host="1.2.3.4", port=7332,
                          ssh_host="mini", priority=1)]
        path = hi.write_bridge_config(hubs)
        data = json.loads(path.read_text())
        self.assertEqual(data["protocol"], hi.BRIDGE_CONFIG_PROTOCOL)
        self.assertEqual(len(data["hubs"]), 1)
        self.assertEqual(data["hubs"][0]["host"], "1.2.3.4")
        self.assertEqual(data["hubs"][0]["ssh_host"], "mini")
        self.assertIn("timeouts", data)
        self.assertIn("sync", data)

    def test_hubspec_to_dict_excludes_role_field(self):
        """gap-8: bridge-config schema is transport-only. Role assignments live in
        machine_id (host-role) + agent-roles-v*.seif (agent-role), never here."""
        hub = hi.HubSpec(name="p", host="1.2.3.4", ssh_host="x")
        self.assertNotIn("role", hub.to_dict())

    # ── sources.json ────────────────────────────────────────────────────────

    def test_parse_source_spec_full(self):
        s = hi.parse_source_spec("github.com/u/r:research:CONFIDENTIAL")
        self.assertEqual(s["repo"], "github.com/u/r")
        self.assertEqual(s["type"], "research")
        self.assertEqual(s["classification"], "CONFIDENTIAL")

    def test_parse_source_spec_default_classification(self):
        s = hi.parse_source_spec("github.com/u/seif")
        self.assertEqual(s["type"], "context")
        self.assertEqual(s["classification"], "INTERNAL")

    def test_parse_source_spec_research_default_classification(self):
        s = hi.parse_source_spec("github.com/u/research:research")
        self.assertEqual(s["classification"], "CONFIDENTIAL")

    def test_parse_source_spec_rejects_bad_type(self):
        with self.assertRaises(ValueError):
            hi.parse_source_spec("github.com/u/r:invalid")

    def test_merge_sources_dedups_by_repo(self):
        existing = [{"repo": "github.com/u/a", "type": "context",
                     "local_path": "/x", "last_synced": "", "classification": "INTERNAL"}]
        merged = hi.merge_sources(["github.com/u/a", "github.com/u/b:project"], existing)
        self.assertEqual(len(merged), 2)
        repos = [s["repo"] for s in merged]
        self.assertEqual(repos, ["github.com/u/a", "github.com/u/b"])

    # ── init_host orchestration ─────────────────────────────────────────────

    def test_init_host_creates_machine_id_only_when_no_optional_inputs(self):
        result = hi.init_host(label="test", role="dev")
        self.assertTrue(result.machine_id_created)
        self.assertIsNone(result.bridge_config)
        self.assertEqual(result.sources, [])
        self.assertTrue(hi.get_machine_id_path().exists())
        self.assertFalse(hi.get_bridge_config_path().exists())
        self.assertFalse(hi.get_sources_path().exists())

    def test_init_host_writes_bridge_when_hubs_given(self):
        hubs = [hi.HubSpec(name="p", host="1.2.3.4")]
        result = hi.init_host(label="x", hubs=hubs)
        self.assertTrue(result.bridge_config_created)
        self.assertTrue(hi.get_bridge_config_path().exists())

    def test_init_host_writes_sources_when_specs_given(self):
        result = hi.init_host(label="x", source_specs=["github.com/u/a", "github.com/u/b:project"])
        self.assertEqual(len(result.sources), 2)
        self.assertEqual(result.sources_added, 2)
        self.assertTrue(hi.get_sources_path().exists())

    def test_init_host_dry_run_writes_nothing(self):
        result = hi.init_host(label="x", hubs=[hi.HubSpec(name="p", host="1.2.3.4")],
                              source_specs=["github.com/u/a"], dry_run=True)
        self.assertTrue(result.machine_id_created)
        self.assertFalse(hi.get_machine_id_path().exists())
        self.assertFalse(hi.get_bridge_config_path().exists())
        self.assertFalse(hi.get_sources_path().exists())

    def test_init_host_idempotent_machine_id(self):
        hi.init_host(label="x")
        m1 = json.loads(hi.get_machine_id_path().read_text())
        hi.init_host(label="y", role="production")
        m2 = json.loads(hi.get_machine_id_path().read_text())
        self.assertEqual(m1["fingerprint"], m2["fingerprint"])
        self.assertEqual(m2["label"], "y")
        self.assertEqual(m2["role"], "production")


if __name__ == "__main__":
    unittest.main()
