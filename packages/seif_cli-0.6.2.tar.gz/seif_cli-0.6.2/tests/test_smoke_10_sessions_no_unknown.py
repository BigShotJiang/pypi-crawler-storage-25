"""s56 PR3 smoke test — acceptance criterion from
pending-2026-05-04-active-registry-hygiene.seif:

    Smoke test: 10 fresh wrapper sessions in a row → 0 unknown.json files in active/

Cumulative end-to-end: invoke session_lifecycle.py session-start 10 times with
a mix of stdin variants the bash hook can produce (valid UUID, literal
'unknown', empty string, malformed UUID, whitespace-only, long random
non-UUID). After all 10 calls, the registry must contain exactly 10
canonical-UUID entries and 0 unknown.json files.

This is the acceptance test that closes the s55 live regression captured
in evidence_pre_s55_pass / live_regression_evidence in the module.
"""

from __future__ import annotations

import json
import os
import re
import subprocess
import uuid
from pathlib import Path

import pytest

UUID_RE = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-"
                     r"[0-9a-f]{4}-[0-9a-f]{12}$", re.IGNORECASE)


# Variants the bash hook + library callers can emit. Together they cover
# every failure path a wrapper has historically used to produce 'unknown'.
STDIN_VARIANTS: list[str] = [
    str(uuid.uuid4()),                         # canonical UUID — passes through
    "unknown",                                 # the s55 regression literal
    "",                                        # empty after parse fallback
    "   ",                                     # whitespace-only
    "not-a-uuid",                              # malformed
    str(uuid.uuid4()).upper(),                 # uppercase canonical (accepted)
    "session-1234",                            # legacy-style friendly id
    f"  {uuid.uuid4()}  ",                     # padded canonical
    "00000000-0000-0000-0000-00000000000g",    # almost-UUID (one bad hex)
    str(uuid.uuid4()),                         # second valid UUID
]


def _make_workspace(tmp_path: Path) -> Path:
    seif_dir = tmp_path / ".seif"
    seif_dir.mkdir()
    (seif_dir / "config.json").write_text(json.dumps({
        "session_lifecycle": {"enabled": True, "co_author": ""},
    }))
    (seif_dir / "sessions").mkdir()
    (seif_dir / "modules").mkdir()
    (seif_dir / "mapper.json").write_text(json.dumps({"modules": [], "version": 1}))
    return seif_dir


def _git_init(path: Path):
    path.mkdir(parents=True, exist_ok=True)
    subprocess.run(["git", "init", "-q", "-b", "main", str(path)], check=True)
    subprocess.run(
        ["git", "-C", str(path),
         "-c", "user.email=t@t", "-c", "user.name=t",
         "commit", "-q", "--allow-empty", "-m", "init"],
        check=True,
        env={**os.environ, "HOME": str(path.parent)},
    )


def test_ten_fresh_sessions_produce_zero_unknown_files(tmp_path):
    """Acceptance: cumulative invocation across the full failure-mode matrix
    must leave active/ free of unknown.json."""
    seif_dir = _make_workspace(tmp_path)
    _git_init(tmp_path / "alpha")

    script = (
        Path(__file__).resolve().parents[1]
        / "src" / "seif" / "plugins" / "core" / "session_lifecycle.py"
    )
    env = {
        **os.environ,
        "PYTHONPATH": str(Path(__file__).resolve().parents[1] / "src"),
    }

    assert len(STDIN_VARIANTS) == 10, "smoke test signature is exactly 10"

    for variant in STDIN_VARIANTS:
        result = subprocess.run(
            ["python3", str(script), "session-start",
             "--session-id", variant,
             "--cwd", str(tmp_path),
             "--home", str(tmp_path),
             "--awareness",
             "--wrapper", "claude-code"],
            capture_output=True, text=True, timeout=15, env=env,
        )
        assert result.returncode == 0, (
            f"session-start failed for variant {variant!r}: {result.stderr}"
        )

    active = seif_dir / "sessions" / "active"
    files = sorted(active.iterdir()) if active.is_dir() else []

    # Acceptance assertion #1: zero unknown.json
    assert not (active / "unknown.json").exists(), \
        "PR3 acceptance failure: active/unknown.json present after 10 sessions"

    # Acceptance assertion #2: every entry is UUID-named (no friendly strings)
    bad_names = [f.name for f in files if not UUID_RE.match(f.stem)]
    assert not bad_names, f"non-UUID entries leaked into active/: {bad_names}"

    # Acceptance assertion #3: every entry's session_id field is a UUID
    bad_ids = []
    for f in files:
        sid = json.loads(f.read_text()).get("session_id", "")
        if not UUID_RE.match(sid or ""):
            bad_ids.append((f.name, sid))
    assert not bad_ids, f"non-UUID session_id field in: {bad_ids}"

    # Acceptance assertion #4: count is the expected number of distinct UUIDs.
    # Two of the variants are pre-validated canonical UUIDs and pass through;
    # the remaining 8 are normalized to fresh UUIDs at lifecycle entry. So we
    # expect 10 distinct files (no collisions, no overwrites).
    assert len(files) == 10, (
        f"expected 10 active session files after 10 starts, got {len(files)}: "
        f"{[f.name for f in files]}"
    )


def test_no_unknown_file_for_any_single_failure_variant(tmp_path):
    """Per-variant regression-pin: each failure mode in isolation must also
    not produce unknown.json (catches the case where one variant slips
    through but the cumulative total still happens to be clean)."""
    script = (
        Path(__file__).resolve().parents[1]
        / "src" / "seif" / "plugins" / "core" / "session_lifecycle.py"
    )
    env = {
        **os.environ,
        "PYTHONPATH": str(Path(__file__).resolve().parents[1] / "src"),
    }

    failures = ["unknown", "", "   ", "not-a-uuid",
                "00000000-0000-0000-0000-00000000000g", "session-1234"]

    for variant in failures:
        sub_workspace = tmp_path / f"ws-{abs(hash(variant))}"
        sub_workspace.mkdir()
        seif_dir = _make_workspace(sub_workspace)
        _git_init(sub_workspace / "alpha")

        result = subprocess.run(
            ["python3", str(script), "session-start",
             "--session-id", variant,
             "--cwd", str(sub_workspace),
             "--home", str(sub_workspace),
             "--awareness",
             "--wrapper", "claude-code"],
            capture_output=True, text=True, timeout=15, env=env,
        )
        assert result.returncode == 0, result.stderr
        assert not (seif_dir / "sessions" / "active" / "unknown.json").exists(), \
            f"unknown.json appeared for variant {variant!r}"
