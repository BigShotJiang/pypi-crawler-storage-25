"""s60 PR2 — get_user_home() honors SEIF_HOME for test isolation.

Two regressions this PR pins:

1. `get_user_home()` MUST respect $SEIF_HOME when set. Without this,
   the autouse conftest fixture cannot redirect host-level reads/writes
   to a tmpdir, and tests leak ephemeral paths into the real user's
   ~/.seif/registry.json (the s57 q2 incident).

2. The user's REAL ~/.seif/registry.json (resolved without SEIF_HOME)
   must NOT be written to during a pytest run. The autouse session
   fixture handles isolation; this regression test asserts that the
   isolation actually holds — by snapshotting the real user file's
   bytes (or absence) before/after a register()/save_registry() round
   trip and confirming they are unchanged.
"""

from __future__ import annotations

import json
import os
from pathlib import Path

import pytest

from seif.data.paths import get_user_home


def test_get_user_home_honors_seif_home_env_var(monkeypatch, tmp_path):
    target = tmp_path / "custom-seif"
    target.mkdir()
    monkeypatch.setenv("SEIF_HOME", str(target))
    resolved = get_user_home()
    assert resolved == target.resolve(), (
        f"get_user_home() must return $SEIF_HOME when set "
        f"(got {resolved}, expected {target.resolve()})"
    )


def test_get_user_home_falls_back_to_home_when_env_unset(monkeypatch):
    monkeypatch.delenv("SEIF_HOME", raising=False)
    resolved = get_user_home()
    assert resolved == Path.home() / ".seif", (
        "without SEIF_HOME, get_user_home() must use Path.home() / '.seif'"
    )


def test_seif_home_override_expanduser_and_resolve(monkeypatch, tmp_path):
    """$SEIF_HOME with ~/ prefix or relative path must be normalized."""
    nested = tmp_path / "nested"
    nested.mkdir()
    monkeypatch.setenv("SEIF_HOME", str(nested) + "/.")
    resolved = get_user_home()
    # `.` segments collapse via resolve(); also assert no trailing slash issue
    assert resolved == nested.resolve()


def test_user_global_registry_untouched_during_test_run(tmp_path):
    """BINDING regression: the conftest-level autouse SEIF_HOME isolation
    fixture must redirect register() writes to the tmpdir, leaving the real
    user's ~/.seif/registry.json (the path Path.home() / '.seif' would
    resolve without SEIF_HOME) byte-identical or absent.

    Implementation note: we capture Path.home() / '.seif' / 'registry.json'
    bytes BEFORE inducing a registry write, then again AFTER, and assert
    they match. This catches both "test wrote to user file" AND "test
    deleted user file" regressions.
    """
    real_user_registry = Path.home() / ".seif" / "registry.json"
    before_existed = real_user_registry.is_file()
    before_bytes = real_user_registry.read_bytes() if before_existed else None

    # Simulate a registry-relevant write by performing what the s57 q2
    # incident showed leaks: register a session with a tmp_path workspace
    # and let the registry path resolution run.
    from seif.plugins.core.session_registry import register, new_session_id
    seif_dir = tmp_path / ".seif"
    seif_dir.mkdir(parents=True)
    register(seif_dir=seif_dir, session_id=new_session_id(),
             wrapper="x", cwd=tmp_path)
    # Also exercise the higher-level register_context() if it's the leak
    # surface — best-effort import (skip if API moved).
    try:
        from seif.context.registry import register_context
        # register_context signature: (workspace_path: str|Path, ...) — try
        # the simplest possible call. If signature differs, ImportError on
        # import or TypeError below; either way the previous register() call
        # already exercised the leak path most acutely.
        try:
            register_context(workspace_path=tmp_path)
        except TypeError:
            pass
    except (ImportError, ModuleNotFoundError):
        pass

    after_existed = real_user_registry.is_file()
    after_bytes = real_user_registry.read_bytes() if after_existed else None

    assert before_existed == after_existed, (
        f"the real user's ~/.seif/registry.json existence flipped during "
        f"this test (before={before_existed}, after={after_existed}). "
        f"Either the conftest SEIF_HOME isolation fixture is not autouse, "
        f"or get_user_home() is not honoring $SEIF_HOME — both are PR2 "
        f"regressions."
    )
    assert before_bytes == after_bytes, (
        "the real user's ~/.seif/registry.json bytes changed during this "
        "test — the autouse SEIF_HOME isolation fixture failed to redirect "
        "the registry write (PR2 regression)"
    )


def test_seif_home_isolation_fixture_actually_redirects():
    """Sanity: confirm the autouse fixture is running for THIS test."""
    home = os.environ.get("SEIF_HOME", "")
    assert "seif-test-home-" in home, (
        f"autouse SEIF_HOME isolation fixture appears not to have set "
        f"the env var (got {home!r}). conftest.py may be missing or the "
        f"fixture decorator was changed."
    )
