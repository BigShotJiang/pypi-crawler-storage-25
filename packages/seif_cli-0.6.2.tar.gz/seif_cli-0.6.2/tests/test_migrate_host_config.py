"""Tests for s43 B4 — `seif --migrate-host-config` interactive schema bump.

Migrates ~/.seif/host-install-config.seif from v1 → v2 (current target).
v2 added three optional fields: package_source, bridge_repo, restart_jobs.

These tests exercise the function directly (not the CLI subprocess) for speed
and to isolate prompt mocking from argparse state.
"""

from __future__ import annotations

import io
import json
import os
import sys
from contextlib import redirect_stdout
from pathlib import Path
from unittest import mock

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from seif.cli.cli import _cmd_migrate_host_config  # noqa: E402


# ── Helpers ────────────────────────────────────────────────────


def _v1_editable_config(src: str = "/tmp/seif") -> dict:
    return {
        "_instruction": "test config",
        "protocol": "SEIF-HOST-INSTALL-CONFIG-v1",
        "host_label": "test-host",
        "host_role": "writer-canonical",
        "install_method": "editable",
        "source_repo": src,
        "source_branch": "main",
        "package_name": "seif-cli",
        "extra_packages": ["cryptography"],
        "post_install_check": "seif --version",
        "rationale": "test",
    }


def _v1_pipx_config() -> dict:
    return {
        "protocol": "SEIF-HOST-INSTALL-CONFIG-v1",
        "host_label": "pipx-host",
        "install_method": "pipx",
        "package_name": "seif-cli",
        "extra_packages": [],
        "post_install_check": "seif --version",
    }


def _write_cfg(tmp_path: Path, data: dict) -> Path:
    cfg = tmp_path / "host-install-config.seif"
    cfg.write_text(json.dumps(data, indent=2))
    return cfg


# ── Missing / malformed config ─────────────────────────────────


def test_missing_config_returns_1(tmp_path: Path):
    missing = tmp_path / "does-not-exist.seif"
    buf = io.StringIO()
    with redirect_stdout(buf):
        rc = _cmd_migrate_host_config(config_path=missing)
    assert rc == 1
    assert "config not found" in buf.getvalue()


def test_malformed_json_returns_1(tmp_path: Path):
    cfg = tmp_path / "host-install-config.seif"
    cfg.write_text("{ this is not json")
    buf = io.StringIO()
    with redirect_stdout(buf):
        rc = _cmd_migrate_host_config(config_path=cfg)
    assert rc == 1
    assert "malformed JSON" in buf.getvalue()


def test_unknown_protocol_returns_2(tmp_path: Path):
    cfg = _write_cfg(tmp_path, {"protocol": "OTHER-PROTOCOL-v9", "host_label": "x"})
    buf = io.StringIO()
    with redirect_stdout(buf):
        rc = _cmd_migrate_host_config(config_path=cfg)
    assert rc == 2
    assert "unrecognized protocol" in buf.getvalue()


def test_no_migration_path_returns_2(tmp_path: Path):
    """Hypothetical future v3 config with no v3→v2 migration."""
    cfg = _write_cfg(tmp_path, {
        "protocol": "SEIF-HOST-INSTALL-CONFIG-v3",
        "host_label": "future-host",
    })
    buf = io.StringIO()
    with redirect_stdout(buf):
        rc = _cmd_migrate_host_config(config_path=cfg, target_version="v2")
    assert rc == 2
    assert "no migration path" in buf.getvalue()


# ── Already at target ──────────────────────────────────────────


def test_already_at_target_is_noop(tmp_path: Path):
    cfg = _write_cfg(tmp_path, {
        "protocol": "SEIF-HOST-INSTALL-CONFIG-v2",
        "host_label": "already-v2",
        "install_method": "editable",
    })
    before = cfg.read_text()
    buf = io.StringIO()
    with redirect_stdout(buf):
        rc = _cmd_migrate_host_config(config_path=cfg)
    assert rc == 0
    assert "already at" in buf.getvalue()
    assert cfg.read_text() == before  # untouched


# ── Happy path: v1 → v2 with --yes ─────────────────────────────


def test_yes_mode_editable_v1_to_v2_writes_atomically(tmp_path: Path):
    cfg = _write_cfg(tmp_path, _v1_editable_config())
    buf = io.StringIO()
    with redirect_stdout(buf):
        rc = _cmd_migrate_host_config(config_path=cfg, yes=True)
    assert rc == 0
    out = json.loads(cfg.read_text())
    assert out["protocol"] == "SEIF-HOST-INSTALL-CONFIG-v2"
    # All v2 fields should be present with defaults
    assert out["package_source"] == "pypi"
    assert out["bridge_repo"] == {"method": "none"}
    assert out["restart_jobs"] == ["com.seif.*"]
    # Pre-existing fields preserved
    assert out["host_label"] == "test-host"
    assert out["source_repo"] == "/tmp/seif"
    assert out["extra_packages"] == ["cryptography"]
    # Migration metadata stamped
    assert "migrated_at" in out
    assert out["migrated_from"] == "SEIF-HOST-INSTALL-CONFIG-v1"


def test_yes_mode_pipx_v1_to_v2_keeps_pypi_default(tmp_path: Path):
    cfg = _write_cfg(tmp_path, _v1_pipx_config())
    with redirect_stdout(io.StringIO()):
        rc = _cmd_migrate_host_config(config_path=cfg, yes=True)
    assert rc == 0
    out = json.loads(cfg.read_text())
    # pipx hosts get package_source default 'pypi' under --yes (no prompt)
    assert out["package_source"] == "pypi"


# ── Backup behavior ────────────────────────────────────────────


def test_backup_created_by_default(tmp_path: Path):
    cfg = _write_cfg(tmp_path, _v1_editable_config())
    original = cfg.read_text()
    with redirect_stdout(io.StringIO()):
        _cmd_migrate_host_config(config_path=cfg, yes=True)
    # Find the .bak file
    baks = list(tmp_path.glob("host-install-config.seif*bak*"))
    assert len(baks) >= 1, f"backup not created in {tmp_path}; got {list(tmp_path.iterdir())}"
    assert baks[0].read_text() == original


def test_no_backup_skips_bak_file(tmp_path: Path):
    cfg = _write_cfg(tmp_path, _v1_editable_config())
    with redirect_stdout(io.StringIO()):
        _cmd_migrate_host_config(config_path=cfg, yes=True, backup=False)
    baks = list(tmp_path.glob("host-install-config.seif*bak*"))
    assert baks == [], f"--no-backup should skip backup; found {baks}"


# ── Dry-run ────────────────────────────────────────────────────


def test_dry_run_does_not_write(tmp_path: Path):
    cfg = _write_cfg(tmp_path, _v1_editable_config())
    before = cfg.read_text()
    buf = io.StringIO()
    with redirect_stdout(buf):
        rc = _cmd_migrate_host_config(config_path=cfg, yes=True, dry_run=True)
    assert rc == 0
    assert cfg.read_text() == before
    out = buf.getvalue()
    assert "dry-run" in out
    assert "no changes written" in out
    # Diff section should still display
    assert "+ package_source:" in out
    assert "+ bridge_repo:" in out


def test_dry_run_does_not_create_backup(tmp_path: Path):
    cfg = _write_cfg(tmp_path, _v1_editable_config())
    with redirect_stdout(io.StringIO()):
        _cmd_migrate_host_config(config_path=cfg, yes=True, dry_run=True)
    baks = list(tmp_path.glob("host-install-config.seif*bak*"))
    assert baks == []


# ── Field-already-present skip ─────────────────────────────────


def test_existing_v2_field_in_v1_config_is_preserved(tmp_path: Path):
    """If a v1 config somehow already has a v2 field, don't overwrite it."""
    cfg_data = _v1_editable_config()
    cfg_data["restart_jobs"] = ["com.example.*"]  # custom value present in v1 config
    cfg = _write_cfg(tmp_path, cfg_data)
    buf = io.StringIO()
    with redirect_stdout(buf):
        rc = _cmd_migrate_host_config(config_path=cfg, yes=True)
    assert rc == 0
    out = json.loads(cfg.read_text())
    assert out["restart_jobs"] == ["com.example.*"]
    assert "already present" in buf.getvalue()


# ── Atomic write: tmp file is gone after success ──────────────


def test_no_tmp_file_left_behind(tmp_path: Path):
    cfg = _write_cfg(tmp_path, _v1_editable_config())
    with redirect_stdout(io.StringIO()):
        _cmd_migrate_host_config(config_path=cfg, yes=True, backup=False)
    tmps = list(tmp_path.glob("host-install-config.seif.tmp.*"))
    assert tmps == [], f"tmp file leaked: {tmps}"


# ── Interactive prompts (mocked input) ─────────────────────────


def test_interactive_prompt_accepts_csv_for_restart_jobs(tmp_path: Path):
    cfg = _write_cfg(tmp_path, _v1_editable_config())
    # Sequence of inputs:
    #   bridge_repo method → "none" (skip nested fields)
    #   restart_jobs → "com.foo.*, com.bar.*"
    #   (package_source not prompted on editable hosts under interactive)
    inputs = iter(["none", "com.foo.*, com.bar.*"])
    with mock.patch("builtins.input", lambda *a, **k: next(inputs)):
        with redirect_stdout(io.StringIO()):
            rc = _cmd_migrate_host_config(config_path=cfg, yes=False)
    assert rc == 0
    out = json.loads(cfg.read_text())
    assert out["restart_jobs"] == ["com.foo.*", "com.bar.*"]
    assert out["bridge_repo"] == {"method": "none"}


def test_interactive_pipx_prompts_for_package_source(tmp_path: Path):
    cfg = _write_cfg(tmp_path, _v1_pipx_config())
    inputs = iter([
        "git+https://github.com/and2carvalho/seif.git@main",  # package_source
        "none",                                                # bridge_repo method
        "",                                                    # restart_jobs default
    ])
    with mock.patch("builtins.input", lambda *a, **k: next(inputs)):
        with redirect_stdout(io.StringIO()):
            rc = _cmd_migrate_host_config(config_path=cfg, yes=False)
    assert rc == 0
    out = json.loads(cfg.read_text())
    assert out["package_source"] == "git+https://github.com/and2carvalho/seif.git@main"
    assert out["restart_jobs"] == ["com.seif.*"]  # default kept on empty


def test_interactive_invalid_package_source_falls_back_to_default(tmp_path: Path):
    cfg = _write_cfg(tmp_path, _v1_pipx_config())
    inputs = iter([
        "ftp://invalid-source",  # invalid (not pypi or git+)
        "none",
        "",
    ])
    buf = io.StringIO()
    with mock.patch("builtins.input", lambda *a, **k: next(inputs)):
        with redirect_stdout(buf):
            rc = _cmd_migrate_host_config(config_path=cfg, yes=False)
    assert rc == 0
    out = json.loads(cfg.read_text())
    assert out["package_source"] == "pypi"
    assert "invalid value, using default" in buf.getvalue()


def test_interactive_bridge_repo_git_branch(tmp_path: Path):
    cfg = _write_cfg(tmp_path, _v1_editable_config())
    inputs = iter([
        "git",                                          # bridge_repo method
        "/Volumes/DockerData/seif-resonance-bridge",   # source_path
        "https://github.com/and2carvalho/seif-resonance-bridge.git",  # upstream
        "",                                             # restart_jobs default
    ])
    with mock.patch("builtins.input", lambda *a, **k: next(inputs)):
        with redirect_stdout(io.StringIO()):
            rc = _cmd_migrate_host_config(config_path=cfg, yes=False)
    assert rc == 0
    out = json.loads(cfg.read_text())
    assert out["bridge_repo"]["method"] == "git"
    assert out["bridge_repo"]["source_path"] == "/Volumes/DockerData/seif-resonance-bridge"
    assert out["bridge_repo"]["upstream"].endswith(".git")


def test_interactive_bridge_repo_empty_source_path_falls_back_to_none(tmp_path: Path):
    cfg = _write_cfg(tmp_path, _v1_editable_config())
    inputs = iter([
        "git",  # method
        "",     # source_path empty → fall back to none
        "",     # restart_jobs default
    ])
    buf = io.StringIO()
    with mock.patch("builtins.input", lambda *a, **k: next(inputs)):
        with redirect_stdout(buf):
            rc = _cmd_migrate_host_config(config_path=cfg, yes=False)
    assert rc == 0
    out = json.loads(cfg.read_text())
    assert out["bridge_repo"] == {"method": "none"}
    assert "falling back to method=none" in buf.getvalue()


def test_interactive_bridge_repo_unknown_method_falls_back_to_none(tmp_path: Path):
    cfg = _write_cfg(tmp_path, _v1_editable_config())
    inputs = iter([
        "magic",  # invalid method
        "",       # restart_jobs default
    ])
    buf = io.StringIO()
    with mock.patch("builtins.input", lambda *a, **k: next(inputs)):
        with redirect_stdout(buf):
            rc = _cmd_migrate_host_config(config_path=cfg, yes=False)
    assert rc == 0
    out = json.loads(cfg.read_text())
    assert out["bridge_repo"] == {"method": "none"}
    assert "unknown method" in buf.getvalue()
