"""
Tests for A22 governance/transfer.py (S37 steps 4 + 6 + 7).

Covers:
  - Signature happy path
  - Signature negative: tampered payload
  - Signature negative: chain pubkey mismatch (used by walker)
  - Module serialization round-trip
  - Chain-of-3 forward security (positive)
  - Chain rejects forged link (signed_by ≠ previous transfer_to → captures
    "old key cannot sign new module after transfer")
  - Chain rejects out-of-order dates (captures "new key cannot retroactively
    sign before its date")
  - Chain rejects scope mismatch
"""

import base64
import json
import sys
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

_REPO_ROOT = Path(__file__).resolve().parent.parent
_SRC = _REPO_ROOT / "src"
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization

from seif.governance.transfer import (
    TransferRecord,
    sign,
    verify,
    serialize_to_seif_module,
    verify_transfer_chain,
)


def _gen_keypair():
    priv = Ed25519PrivateKey.generate()
    pub_raw = priv.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    return priv, base64.b64encode(pub_raw).decode("ascii")


def _iso(dt: datetime) -> str:
    return dt.replace(tzinfo=timezone.utc).isoformat()


class TestTransferSignVerify(unittest.TestCase):
    def test_sign_and_verify_happy_path(self):
        old_priv, old_pub_b64 = _gen_keypair()
        _, new_pub_b64 = _gen_keypair()

        record = sign(
            prev_owner_priv_key=old_priv,
            transfer_to=new_pub_b64,
            scope="test-workspace",
            reason="acquisition by Acme Corp",
        )

        self.assertIsInstance(record, TransferRecord)
        self.assertEqual(record.transfer_to, new_pub_b64)
        self.assertEqual(record.scope, "test-workspace")
        self.assertEqual(record.signed_by, old_pub_b64)
        self.assertTrue(record.signature, "signature must be populated")

        result = verify(record)
        self.assertTrue(result["valid"], result["reason"])

    def test_verify_rejects_tampered_reason(self):
        old_priv, _ = _gen_keypair()
        _, new_pub_b64 = _gen_keypair()

        record = sign(
            prev_owner_priv_key=old_priv,
            transfer_to=new_pub_b64,
            scope="test-workspace",
            reason="original reason",
        )

        tampered = TransferRecord(
            transfer_to=record.transfer_to,
            scope=record.scope,
            date=record.date,
            reason="DIFFERENT reason",
            signed_by=record.signed_by,
            signature=record.signature,
        )

        result = verify(tampered)
        self.assertFalse(result["valid"])
        self.assertTrue(
            "INVALID" in result["reason"] or "does not match" in result["reason"],
            f"unexpected reason: {result['reason']}",
        )

    def test_verify_rejects_chain_pubkey_mismatch(self):
        old_priv, _ = _gen_keypair()
        _, new_pub_b64 = _gen_keypair()
        _, unrelated_pub_b64 = _gen_keypair()

        record = sign(
            prev_owner_priv_key=old_priv,
            transfer_to=new_pub_b64,
            scope="test-workspace",
            reason="any reason",
        )

        result = verify(record, expected_prev_owner_pubkey=unrelated_pub_b64)
        self.assertFalse(result["valid"])
        self.assertIn("expected previous owner", result["reason"])


class TestSerializeRoundTrip(unittest.TestCase):
    def test_serialize_and_reload(self):
        old_priv, _ = _gen_keypair()
        _, new_pub_b64 = _gen_keypair()

        record = sign(
            prev_owner_priv_key=old_priv,
            transfer_to=new_pub_b64,
            scope="round-trip-ws",
            reason="serialization test",
        )

        with tempfile.TemporaryDirectory() as td:
            out = Path(td) / "transfers" / "transfer-001.seif"
            module = serialize_to_seif_module(record, out)

            self.assertTrue(out.exists())
            self.assertEqual(module["protocol"], "SEIF-MODULE-v2")
            self.assertEqual(module["category"], "transfer")
            self.assertEqual(module["classification"], "INTERNAL")
            self.assertEqual(len(module["integrity_hash"]), 24)

            # Reload from disk and verify the embedded record's signature
            reloaded = json.loads(out.read_text())
            rec_dict = reloaded["transfer_record"]
            self.assertTrue(verify(rec_dict)["valid"])


class TestTransferChain(unittest.TestCase):
    """End-to-end chain walker — covers forward security in both directions."""

    def _build_chain_of_3(self, scope: str, transfers_dir: Path):
        """Build a valid 3-link chain: A → B → C → D for `scope`.

        Returns: (priv_A, pub_A_b64, priv_B, pub_B_b64, priv_C, pub_C_b64,
                  priv_D, pub_D_b64).
        """
        priv_A, pub_A = _gen_keypair()
        priv_B, pub_B = _gen_keypair()
        priv_C, pub_C = _gen_keypair()
        priv_D, pub_D = _gen_keypair()

        base = datetime(2026, 1, 1, tzinfo=timezone.utc)

        rec_AB = sign(prev_owner_priv_key=priv_A, transfer_to=pub_B, scope=scope,
                      reason="A→B", date=_iso(base))
        rec_BC = sign(prev_owner_priv_key=priv_B, transfer_to=pub_C, scope=scope,
                      reason="B→C", date=_iso(base + timedelta(days=30)))
        rec_CD = sign(prev_owner_priv_key=priv_C, transfer_to=pub_D, scope=scope,
                      reason="C→D", date=_iso(base + timedelta(days=60)))

        serialize_to_seif_module(rec_AB, transfers_dir / "001-AB.seif")
        serialize_to_seif_module(rec_BC, transfers_dir / "002-BC.seif")
        serialize_to_seif_module(rec_CD, transfers_dir / "003-CD.seif")

        return (priv_A, pub_A, priv_B, pub_B, priv_C, pub_C, priv_D, pub_D)

    def test_chain_of_three_happy_path(self):
        scope = "ws-alpha"
        with tempfile.TemporaryDirectory() as td:
            transfers_dir = Path(td)
            (priv_A, pub_A, *_rest) = self._build_chain_of_3(scope, transfers_dir)

            result = verify_transfer_chain(scope, transfers_dir, genesis_pubkey=pub_A)

            self.assertTrue(result["valid"], result["error"])
            self.assertEqual(len(result["chain"]), 3)
            self.assertIsNone(result["broken_at"])

    def test_chain_rejects_old_key_signing_after_transfer(self):
        """Forward security: after A→B, A cannot sign a 'new' link.

        Builds a valid first link A→B, then a malicious second link where
        A (the old owner) tries to assert a new transfer A→X. The chain walker
        must reject because link 1's signed_by (A) ≠ link 0's transfer_to (B).
        """
        scope = "ws-fs-old"
        with tempfile.TemporaryDirectory() as td:
            transfers_dir = Path(td)
            priv_A, pub_A = _gen_keypair()
            _priv_B, pub_B = _gen_keypair()
            _priv_X, pub_X = _gen_keypair()

            base = datetime(2026, 1, 1, tzinfo=timezone.utc)

            rec_AB = sign(prev_owner_priv_key=priv_A, transfer_to=pub_B,
                          scope=scope, reason="A→B", date=_iso(base))
            # Malicious: A signs a "new" transfer to X after A→B was already done
            rec_AX = sign(prev_owner_priv_key=priv_A, transfer_to=pub_X,
                          scope=scope, reason="A→X (forged)",
                          date=_iso(base + timedelta(days=30)))

            serialize_to_seif_module(rec_AB, transfers_dir / "001-AB.seif")
            serialize_to_seif_module(rec_AX, transfers_dir / "002-AX-forged.seif")

            result = verify_transfer_chain(scope, transfers_dir, genesis_pubkey=pub_A)
            self.assertFalse(result["valid"])
            self.assertEqual(result["broken_at"], 1)
            self.assertIn("expected previous owner", result["error"])

    def test_chain_rejects_backdated_link(self):
        """Forward security via strictly-increasing dates.

        A valid chain A→B→C→D where C→D is backdated to the same instant as
        B→C. All chain-of-trust bindings (signed_by ↔ previous transfer_to)
        are valid, so the walker reaches the date rule and rejects on
        'not strictly later'. This isolates rule (d) from rules (a)–(c).
        """
        scope = "ws-fs-back"
        with tempfile.TemporaryDirectory() as td:
            transfers_dir = Path(td)
            priv_A, pub_A = _gen_keypair()
            priv_B, pub_B = _gen_keypair()
            priv_C, pub_C = _gen_keypair()
            _priv_D, pub_D = _gen_keypair()

            base = datetime(2026, 1, 1, tzinfo=timezone.utc)
            t_BC = base + timedelta(days=30)

            rec_AB = sign(prev_owner_priv_key=priv_A, transfer_to=pub_B,
                          scope=scope, reason="A→B", date=_iso(base))
            rec_BC = sign(prev_owner_priv_key=priv_B, transfer_to=pub_C,
                          scope=scope, reason="B→C", date=_iso(t_BC))
            # C→D backdated to the same instant as B→C — chain bindings still
            # valid, but date rule must reject.
            rec_CD = sign(prev_owner_priv_key=priv_C, transfer_to=pub_D,
                          scope=scope, reason="C→D (backdated)", date=_iso(t_BC))

            serialize_to_seif_module(rec_AB, transfers_dir / "001-AB.seif")
            serialize_to_seif_module(rec_BC, transfers_dir / "002-BC.seif")
            serialize_to_seif_module(rec_CD, transfers_dir / "003-CD.seif")

            result = verify_transfer_chain(scope, transfers_dir, genesis_pubkey=pub_A)
            self.assertFalse(result["valid"])
            self.assertIn("strictly later", result["error"])

    def test_chain_rejects_scope_mismatch_via_genesis(self):
        """When chain is verified with a genesis_pubkey, a forged first link
        signed by the wrong key is rejected at link 0."""
        scope = "ws-real"
        with tempfile.TemporaryDirectory() as td:
            transfers_dir = Path(td)
            _real_priv_A, real_pub_A = _gen_keypair()
            attacker_priv, _attacker_pub = _gen_keypair()
            _, pub_B = _gen_keypair()

            base = datetime(2026, 1, 1, tzinfo=timezone.utc)

            # Attacker signs a transfer in this scope without owning the genesis key
            rec_forged = sign(prev_owner_priv_key=attacker_priv, transfer_to=pub_B,
                              scope=scope, reason="attacker→B", date=_iso(base))
            serialize_to_seif_module(rec_forged, transfers_dir / "001-forged.seif")

            result = verify_transfer_chain(scope, transfers_dir, genesis_pubkey=real_pub_A)
            self.assertFalse(result["valid"])
            self.assertEqual(result["broken_at"], 0)
            self.assertIn("expected previous owner", result["error"])


if __name__ == "__main__":
    unittest.main()
