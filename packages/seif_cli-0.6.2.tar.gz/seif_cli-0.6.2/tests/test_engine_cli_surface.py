"""Tests for Phase 2.A.cont — engine CLI surface for hookless adapters.

Adds:
- circuit_monitor.py --check-inbox / --drain
- seif --inbox (top-level wrapper)
- seif --classify TEXT_OR_FILE
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from seif.plugins.core import circuit_monitor as cm  # noqa: E402

REPO_ROOT = Path(__file__).resolve().parent.parent


class CircuitMonitorInboxTests(unittest.TestCase):

    def setUp(self):
        # Override module-level paths to point at a temp home for each test.
        self._tmp = tempfile.TemporaryDirectory()
        self.tmp = Path(self._tmp.name)
        self.inbox = self.tmp / ".seif" / "circuit" / "inbox"
        self.inbox.mkdir(parents=True)
        self.circuit_dir = self.tmp / ".seif" / "circuit"
        self.pending = self.circuit_dir / "pending-messages.json"
        self.watermark = self.circuit_dir / "inbox-watermark.json"

        # Patch module-level paths
        self._saved = (
            cm.SEIF_HOME, cm.CIRCUIT_DIR, cm.INBOX_DIR,
            cm.WATERMARK_FILE, cm.PENDING_FILE, cm.MONITOR_STATE_FILE,
            cm.ALERTS_FILE,
        )
        cm.SEIF_HOME = self.tmp / ".seif"
        cm.CIRCUIT_DIR = self.circuit_dir
        cm.INBOX_DIR = self.inbox
        cm.WATERMARK_FILE = self.watermark
        cm.PENDING_FILE = self.pending
        cm.MONITOR_STATE_FILE = self.circuit_dir / "monitor-state.json"
        cm.ALERTS_FILE = self.circuit_dir / "alerts.txt"

    def tearDown(self):
        (cm.SEIF_HOME, cm.CIRCUIT_DIR, cm.INBOX_DIR,
         cm.WATERMARK_FILE, cm.PENDING_FILE, cm.MONITOR_STATE_FILE,
         cm.ALERTS_FILE) = self._saved
        self._tmp.cleanup()

    def _drop(self, name: str, body: dict):
        (self.inbox / name).write_text(json.dumps(body))

    def test_check_inbox_with_no_messages_writes_no_pending(self):
        self.assertEqual(cm.check_inbox(), 0)
        self.assertFalse(self.pending.is_file())

    def test_check_inbox_writes_pending_for_new_messages(self):
        self._drop("bus-handoff-100.json",
                   {"from": "opencode", "to": "claude", "subject": "x"})
        self._drop("bus-handoff-200.json",
                   {"from": "grok", "to": "claude", "content": "y"})
        self.assertEqual(cm.check_inbox(), 0)
        self.assertTrue(self.pending.is_file())
        msgs = json.loads(self.pending.read_text())
        self.assertEqual(len(msgs), 2)
        names = {m["filename"] for m in msgs}
        self.assertEqual(names,
                         {"bus-handoff-100.json", "bus-handoff-200.json"})

    def test_drain_advances_watermark_and_clears_pending(self):
        self._drop("bus-handoff-100.json",
                   {"from": "opencode", "to": "claude", "subject": "test"})
        cm.check_inbox()
        self.assertTrue(self.pending.is_file())

        cm.drain_inbox()
        self.assertFalse(self.pending.is_file(),
                         "drain must delete pending file")
        wm = json.loads(self.watermark.read_text())
        self.assertIn("bus-handoff-100.json", wm["seen_files"])

    def test_check_inbox_skips_already_seen(self):
        self._drop("bus-handoff-100.json", {"x": 1})
        cm.check_inbox()
        cm.drain_inbox()
        # Second check: same file, should NOT reappear in pending
        cm.check_inbox()
        self.assertFalse(self.pending.is_file(),
                         "already-drained message must not re-appear")

    def test_drain_with_no_pending_is_safe_noop(self):
        # No check-inbox before drain → nothing to do
        self.assertEqual(cm.drain_inbox(), 0)

    def test_check_inbox_skips_non_bus_handoff_files(self):
        (self.inbox / "stray.txt").write_text("not a handoff")
        (self.inbox / "bus-handoff-1.json").write_text('{"a":1}')
        cm.check_inbox()
        msgs = json.loads(self.pending.read_text())
        self.assertEqual(len(msgs), 1)
        self.assertEqual(msgs[0]["filename"], "bus-handoff-1.json")


class TopLevelCliFlagTests(unittest.TestCase):
    """Subprocess-invoke `seif` with the new flags to verify wiring."""

    def _run_cli(self, *args, env_extra=None):
        env = os.environ.copy()
        env["PYTHONPATH"] = f"{REPO_ROOT}/src:{env.get('PYTHONPATH','')}"
        if env_extra:
            env.update(env_extra)
        result = subprocess.run(
            [sys.executable, "-m", "seif.cli.cli", *args],
            cwd=str(REPO_ROOT), env=env,
            capture_output=True, text=True, timeout=15,
        )
        return result.returncode, result.stdout, result.stderr

    def test_inbox_with_empty_inbox_exits_0(self):
        with tempfile.TemporaryDirectory() as tmp:
            rc, out, err = self._run_cli("--inbox", env_extra={"HOME": tmp})
            self.assertEqual(rc, 0,
                             f"inbox with no messages should exit 0; "
                             f"out={out!r} err={err!r}")

    def test_inbox_drains_pending_messages(self):
        with tempfile.TemporaryDirectory() as tmp:
            inbox = Path(tmp) / ".seif" / "circuit" / "inbox"
            inbox.mkdir(parents=True)
            (inbox / "bus-handoff-1.json").write_text(
                json.dumps({"from": "test", "subject": "smoke"})
            )
            rc, out, err = self._run_cli("--inbox", env_extra={"HOME": tmp})
            self.assertEqual(rc, 0)
            self.assertIn("CIRCUIT INBOX", out)
            self.assertIn("smoke", out)
            # Watermark advances → file marked seen
            wm_path = Path(tmp) / ".seif" / "circuit" / "inbox-watermark.json"
            self.assertTrue(wm_path.is_file())

    def test_classify_inline_text_internal(self):
        # Avoid any substring match against SENSITIVE_KEYWORDS (password,
        # secret, token, api_key, apikey, private_key, credential,
        # vulnerability, cve, exploit, breach, compliance, lgpd, gdpr).
        # The classifier substring-matches on lowercased content.
        rc, out, err = self._run_cli("--classify", "hello world plain text")
        self.assertEqual(rc, 1, "INTERNAL is exit 1 (no sensitive keyword)")
        self.assertIn("INTERNAL", out)

    def test_classify_inline_text_confidential(self):
        rc, out, err = self._run_cli(
            "--classify", "password=hunter2 API_KEY=sk-LIVE-abc",
        )
        self.assertEqual(rc, 2,
                         f"CONFIDENTIAL is exit 2; out={out!r}")
        self.assertIn("CONFIDENTIAL", out)

    def test_classify_file_path(self):
        with tempfile.TemporaryDirectory() as tmp:
            f = Path(tmp) / "config.txt"
            f.write_text("server=prod\napi_key=sensitive")
            rc, out, err = self._run_cli("--classify", str(f))
            self.assertEqual(rc, 2,
                             f"file with secret keyword → CONFIDENTIAL; "
                             f"out={out!r}")
            self.assertIn(str(f), out)

    def test_classify_exit_codes_distinct(self):
        # 0=PUBLIC (currently unused since classifier defaults to INTERNAL),
        # 1=INTERNAL, 2=CONFIDENTIAL — verify the 1/2 split is observable
        # from a single test pair.
        plain_rc, _, _ = self._run_cli("--classify", "plain")
        sens_rc, _, _ = self._run_cli("--classify", "password=hunter2")
        self.assertEqual(plain_rc, 1)
        self.assertEqual(sens_rc, 2)
        self.assertNotEqual(plain_rc, sens_rc,
                            "exit codes must distinguish INTERNAL from CONFIDENTIAL")


if __name__ == "__main__":
    unittest.main()
