"""Tests for setup._install_core_scripts (s39 P1 follow-up).

Regression: prior to this fix, `seif setup claude-code` deployed the adapter
shims under ~/.local/share/seif/claude-code/scripts/ but NEVER copied the
companion core modules (session_lifecycle.py, circuit_monitor.py) to
~/.local/share/seif/core/. The shim's lookup chain ended in the no-op
"session_lifecycle.py not found — skipping hook" branch on every fresh
install.
"""

from __future__ import annotations

from pathlib import Path

import pytest


@pytest.fixture
def fake_home(tmp_path, monkeypatch):
    monkeypatch.setattr(Path, "home", classmethod(lambda cls: tmp_path))
    return tmp_path


def test_install_core_scripts_writes_lifecycle_and_monitor(fake_home):
    from seif.cli.setup import _install_core_scripts, _get_core_install_dir

    installed = _install_core_scripts()

    assert "session_lifecycle.py" in installed
    assert "circuit_monitor.py" in installed

    core_dir = _get_core_install_dir()
    assert (core_dir / "session_lifecycle.py").is_file()
    assert (core_dir / "circuit_monitor.py").is_file()


def test_install_core_scripts_is_idempotent(fake_home):
    from seif.cli.setup import _install_core_scripts

    first = _install_core_scripts()
    second = _install_core_scripts()
    assert first == second
    assert "session_lifecycle.py" in second
