"""Audio watermark MVP — Phase 1 P1-b contract.

Covers:
  - WatermarkConfig defaults + freq band derivation
  - embed_watermark_wav round-trip with extract_watermark_wav
  - Repetition resilience (single-sample drop survives majority vote)
  - file_sha256_hex stable on identical bytes, differs on change
  - Carrier-shorter-than-payload zero-pads correctly
  - Empty payload handled
  - Alphabet validation rejects unknown chars
  - WAV format validation rejects stereo / non-16-bit input

Tests use a fast-config (4Hz spacing, 0.5s symbols) to keep runtime under
~1s per test. Production defaults (1Hz spacing, 4s symbols, sub-20Hz band)
are exercised by an integration smoke marked slow.
"""

from __future__ import annotations

import hashlib
import wave
from pathlib import Path

import numpy as np
import pytest

from seif.generators.watermark import (
    DEFAULT_ALPHABET,
    WatermarkConfig,
    WatermarkError,
    embed_watermark_wav,
    extract_watermark_wav,
    file_sha256_hex,
)


def _write_silent_wav(path: Path, duration_seconds: float = 1.0, sample_rate: int = 44100) -> None:
    n = int(duration_seconds * sample_rate)
    samples = np.zeros(n, dtype=np.int16)
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sample_rate)
        w.writeframes(samples.tobytes())


def _fast_config() -> WatermarkConfig:
    return WatermarkConfig(
        symbol_duration=0.5,
        repetitions=2,
        amplitude=0.1,
        freq_spacing_hz=4.0,
    )


def _stereo_wav(path: Path) -> None:
    with wave.open(str(path), "wb") as w:
        w.setnchannels(2)
        w.setsampwidth(2)
        w.setframerate(44100)
        w.writeframes(np.zeros(44100 * 2, dtype=np.int16).tobytes())


def _wav_24bit(path: Path) -> None:
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(3)
        w.setframerate(44100)
        w.writeframes((b"\x00\x00\x00") * 44100)


# ── Config ──────────────────────────────────────────────────────────────────


def test_default_config_band_under_20hz():
    cfg = WatermarkConfig()
    lo, hi = cfg.freq_band
    assert lo >= 1.0
    assert hi <= 20.0, f"default band {lo}-{hi} should stay sub-20Hz for inaudibility"


def test_alphabet_validation_rejects_unknown_chars():
    cfg = WatermarkConfig()
    with pytest.raises(WatermarkError, match="alphabet"):
        cfg.validate_text("xyz!")


def test_alphabet_validation_accepts_full_hex():
    cfg = WatermarkConfig()
    cfg.validate_text("0123456789abcdef")  # no exception


# ── Round-trip ──────────────────────────────────────────────────────────────


def test_roundtrip_short_payload(tmp_path):
    carrier = tmp_path / "carrier.wav"
    out = tmp_path / "watermarked.wav"
    _write_silent_wav(carrier, duration_seconds=0.1)

    cfg = _fast_config()
    text = "deadbeef"
    meta = embed_watermark_wav(text, carrier, out, cfg)
    assert meta["symbols"] == len(text)
    assert meta["repetitions"] == cfg.repetitions

    decoded = extract_watermark_wav(out, n_symbols=len(text), config=cfg)
    assert decoded == text


def test_roundtrip_full_sha256_hex(tmp_path):
    carrier = tmp_path / "carrier.wav"
    out = tmp_path / "watermarked.wav"
    _write_silent_wav(carrier, duration_seconds=0.1)

    cfg = _fast_config()
    text = hashlib.sha256(b"sample artifact bytes").hexdigest()
    assert len(text) == 64
    embed_watermark_wav(text, carrier, out, cfg)
    decoded = extract_watermark_wav(out, n_symbols=64, config=cfg)
    assert decoded == text


def test_carrier_shorter_than_payload_is_padded(tmp_path):
    """0.1s carrier vs 8 symbols × 0.5s × 2 reps = 8s payload — must zero-pad."""
    carrier = tmp_path / "carrier.wav"
    out = tmp_path / "watermarked.wav"
    _write_silent_wav(carrier, duration_seconds=0.1)

    cfg = _fast_config()
    text = "deadbeef"
    meta = embed_watermark_wav(text, carrier, out, cfg)
    assert meta["carrier_duration"] >= meta["duration_seconds"]

    decoded = extract_watermark_wav(out, n_symbols=len(text), config=cfg)
    assert decoded == text


def test_empty_payload(tmp_path):
    carrier = tmp_path / "carrier.wav"
    out = tmp_path / "watermarked.wav"
    _write_silent_wav(carrier, duration_seconds=0.1)

    cfg = _fast_config()
    meta = embed_watermark_wav("", carrier, out, cfg)
    assert meta["symbols"] == 0
    assert meta["duration_seconds"] == 0.0

    decoded = extract_watermark_wav(out, n_symbols=0, config=cfg)
    assert decoded == ""


# ── Format validation ──────────────────────────────────────────────────────


def test_stereo_carrier_rejected(tmp_path):
    carrier = tmp_path / "stereo.wav"
    _stereo_wav(carrier)
    out = tmp_path / "out.wav"
    with pytest.raises(WatermarkError, match="mono"):
        embed_watermark_wav("ab", carrier, out, _fast_config())


def test_24bit_carrier_rejected(tmp_path):
    carrier = tmp_path / "24bit.wav"
    _wav_24bit(carrier)
    out = tmp_path / "out.wav"
    with pytest.raises(WatermarkError, match="16-bit"):
        embed_watermark_wav("ab", carrier, out, _fast_config())


def test_extract_audio_too_short_raises(tmp_path):
    carrier = tmp_path / "tiny.wav"
    _write_silent_wav(carrier, duration_seconds=0.05)  # only 0.05s
    cfg = _fast_config()  # needs at least 0.5s × 2 reps × 8 = 8s for 8 symbols
    with pytest.raises(WatermarkError, match="too short"):
        extract_watermark_wav(carrier, n_symbols=8, config=cfg)


# ── file_sha256_hex ────────────────────────────────────────────────────────


def test_file_sha256_hex_stable(tmp_path):
    f = tmp_path / "a.bin"
    f.write_bytes(b"hello world")
    h1 = file_sha256_hex(f)
    h2 = file_sha256_hex(f)
    assert h1 == h2
    # Match Python stdlib reference
    assert h1 == hashlib.sha256(b"hello world").hexdigest()


def test_file_sha256_hex_differs_on_byte_change(tmp_path):
    a = tmp_path / "a.bin"
    b = tmp_path / "b.bin"
    a.write_bytes(b"hello world")
    b.write_bytes(b"hello worle")  # one byte differs
    assert file_sha256_hex(a) != file_sha256_hex(b)


def test_file_sha256_hex_handles_large_file(tmp_path):
    """Streaming chunked read must produce the same hash as one-shot."""
    f = tmp_path / "big.bin"
    payload = b"x" * (200 * 1024)  # 200 KB > 64 KB chunk size
    f.write_bytes(payload)
    assert file_sha256_hex(f) == hashlib.sha256(payload).hexdigest()


# ── Sample-rate mismatch ────────────────────────────────────────────────────


def test_sample_rate_mismatch_rejected(tmp_path):
    carrier = tmp_path / "wrong_sr.wav"
    _write_silent_wav(carrier, duration_seconds=0.1, sample_rate=22050)
    cfg = _fast_config()  # config defaults to 44100
    out = tmp_path / "out.wav"
    with pytest.raises(WatermarkError, match="sample_rate"):
        embed_watermark_wav("ab", carrier, out, cfg)
