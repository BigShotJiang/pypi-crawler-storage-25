"""Tests for load_module process-level cache (s44 INIT-SURFACING 2/2).

Pre-fix: every session-start opened, parsed, and verified each .seif
module 3× because three independent wrapper paths called load_module
on the same files (build_startup_context, _build_local_prompt loop,
_signal_protocol_status → list_modules). For ~64 modules in a typical
workspace, that was ~192 reads + 192 sig-verify ops + same warnings
logged 3× per startup. Distributing v2 to peers would multiply this 3×
for every host.

Post-fix: process-level cache keyed by (resolved-path, mtime_ns, verify
flag) returns the cached SeifModule. External edits invalidate
automatically via mtime change.
"""
from __future__ import annotations

import io
import json
import logging
import os
import sys
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from seif.context.context_manager import (  # noqa: E402
    _LOAD_CACHE,
    _clear_load_cache,
    load_module,
)


def _write_seif(path: Path, summary: str = "test summary") -> Path:
    import hashlib
    h = hashlib.sha256(summary.encode()).hexdigest()[:16]
    path.write_text(
        json.dumps(
            {
                "summary": summary,
                "compressed_words": len(summary.split()),
                "source": str(path),
                "integrity_hash": h,
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    return path


class LoadModuleCacheTests(unittest.TestCase):
    def setUp(self):
        _clear_load_cache()
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / "module.seif"
        _write_seif(self.path)

    def tearDown(self):
        _clear_load_cache()
        self.tmp.cleanup()

    def test_first_call_populates_cache(self):
        self.assertEqual(len(_LOAD_CACHE), 0)
        load_module(str(self.path))
        self.assertEqual(len(_LOAD_CACHE), 1)

    def test_second_call_returns_same_instance(self):
        m1 = load_module(str(self.path))
        m2 = load_module(str(self.path))
        # Same Python object → cache hit, not re-construction
        self.assertIs(m1, m2)

    def test_path_aliasing_normalizes_to_realpath(self):
        # Calling with a relative path resolves to the same cache key.
        m1 = load_module(str(self.path))
        cwd_before = os.getcwd()
        try:
            os.chdir(self.tmp.name)
            m2 = load_module("module.seif")
        finally:
            os.chdir(cwd_before)
        self.assertIs(m1, m2)

    def test_mtime_change_invalidates_cache(self):
        m1 = load_module(str(self.path))
        # Simulate external edit: rewrite content + bump mtime.
        time.sleep(0.01)
        _write_seif(self.path, summary="updated summary")
        os.utime(self.path, None)  # touch — guarantees mtime advance
        m2 = load_module(str(self.path))
        self.assertIsNot(m1, m2)
        self.assertEqual(m2.summary, "updated summary")

    def test_verify_flag_in_cache_key(self):
        # verify=True and verify=False are different entries.
        m_verify = load_module(str(self.path), verify=True)
        m_skip = load_module(str(self.path), verify=False)
        # Different cache keys → different instances even though file
        # content is identical (verify flag in key is intentional).
        self.assertIsNot(m_verify, m_skip)
        self.assertEqual(len(_LOAD_CACHE), 2)

    def test_warning_logged_only_once_for_repeat_loads(self):
        """The original triple-warning bug: same file → same warning 3×.
        With cache, the second/third call returns the cached module
        without re-running _verify_signature_on_load.
        """
        # File with signature block but no integrity_hash → fires warning.
        bad = Path(self.tmp.name) / "bad.seif"
        bad.write_text(
            json.dumps({
                "summary": "x",
                "compressed_words": 1,
                "source": str(bad),
                "integrity_hash": "",  # missing on purpose
                "signature": {"public_key": "abc", "signed_hash": "def"},
            }),
            encoding="utf-8",
        )

        with self.assertLogs("seif.context.context_manager", level="WARNING") as cm:
            load_module(str(bad))
            load_module(str(bad))
            load_module(str(bad))

        # Triple-load before fix produced 3 identical warnings; with the
        # cache only the first call performs verification.
        signature_warnings = [
            r for r in cm.records
            if "signature present but no integrity_hash" in r.getMessage()
        ]
        self.assertEqual(len(signature_warnings), 1,
                         "expected single warning, got "
                         f"{len(signature_warnings)}: "
                         f"{[r.getMessage() for r in signature_warnings]}")


class VerifySignatureOnLoadAcceptsFingerprintValueTests(unittest.TestCase):
    """gap-1 (s47 P1): _verify_signature_on_load must accept fingerprint.value
    when the legacy flat integrity_hash is absent. The signing path
    (sign_module / verify_module) was fixed in commit f7c4dff (s32) but the
    load-time verifier in context_manager kept the legacy-only check, so any
    module produced by `seif --fingerprint-update` + `seif --sign` triggered
    a "signature present but no integrity_hash" warning at every startup
    even though the signature was valid.

    Mirrors the resolution order in seif.core.signing.sign_module:204.
    """

    def setUp(self):
        _clear_load_cache()
        self.tmp = tempfile.TemporaryDirectory()

    def tearDown(self):
        _clear_load_cache()
        self.tmp.cleanup()

    def _build_signed_module(self, *, with_legacy_hash: bool) -> Path:
        try:
            from cryptography.hazmat.primitives.asymmetric.ed25519 import (
                Ed25519PrivateKey,
            )
            from cryptography.hazmat.primitives import serialization
        except ImportError:
            self.skipTest("cryptography not installed")

        import base64
        import hashlib

        # Modern module → fingerprint.value only (the case _verify_signature_on_load
        # used to reject). Legacy module → flat integrity_hash matching what
        # _compute_hash(summary) would produce (16-char sha256 prefix), so the
        # unrelated content-integrity check at load_module:274 also passes.
        path = Path(self.tmp.name) / (
            "legacy.seif" if with_legacy_hash else "modern.seif"
        )
        summary = "legacy module for verify-on-load test" if with_legacy_hash else "x"
        body: dict = {
            "summary": summary,
            "compressed_words": len(summary.split()),
            "source": str(path),
        }

        if with_legacy_hash:
            signed_hash = hashlib.sha256(summary.encode()).hexdigest()[:16]
            body["integrity_hash"] = signed_hash
        else:
            signed_hash = hashlib.sha256(
                json.dumps(body, separators=(",", ":")).encode()
            ).hexdigest()
            body["fingerprint"] = {"algorithm": "sha256", "value": signed_hash}

        priv = Ed25519PrivateKey.generate()
        pub = priv.public_key()
        pub_b64 = base64.b64encode(
            pub.public_bytes(
                encoding=serialization.Encoding.Raw,
                format=serialization.PublicFormat.Raw,
            )
        ).decode()
        sig_b64 = base64.b64encode(priv.sign(signed_hash.encode())).decode()
        body["signature"] = {
            "algorithm": "Ed25519",
            "public_key": pub_b64,
            "signed_hash": sig_b64,
        }
        path.write_text(json.dumps(body, indent=2), encoding="utf-8")
        return path

    def test_load_with_fingerprint_value_only_does_not_warn(self):
        path = self._build_signed_module(with_legacy_hash=False)
        with self.assertLogs(
            "seif.context.context_manager", level="WARNING"
        ) as cm:
            load_module(str(path))
            # Force at least one record so assertLogs doesn't itself raise
            # — emit a benign one if nothing else fired.
            logging.getLogger("seif.context.context_manager").warning(
                "test-sentinel"
            )

        offending = [
            r.getMessage() for r in cm.records
            if "signature present" in r.getMessage()
        ]
        self.assertEqual(
            offending, [],
            f"_verify_signature_on_load should accept fingerprint.value alone,"
            f" got warnings: {offending}",
        )

    def test_load_legacy_integrity_hash_still_works(self):
        path = self._build_signed_module(with_legacy_hash=True)
        with self.assertLogs(
            "seif.context.context_manager", level="WARNING"
        ) as cm:
            load_module(str(path))
            logging.getLogger("seif.context.context_manager").warning(
                "test-sentinel"
            )

        offending = [
            r.getMessage() for r in cm.records
            if "signature present" in r.getMessage()
        ]
        self.assertEqual(offending, [])


class VerifyImportFailureTests(unittest.TestCase):
    """gap (s48 P2): _verify_signature_on_load must return None (not raise
    UnboundLocalError) when `cryptography` is not importable.

    Pre-fix: imports lived inside the same try/except as the verification
    logic. If `from cryptography.exceptions import InvalidSignature` failed
    with ImportError, Python would then evaluate `except InvalidSignature:`
    against a name that was never bound → UnboundLocalError, defeating the
    "Never raises" contract documented in the function's docstring.

    Post-fix: imports live in their own outer try/except so the verification
    try/except below can reference InvalidSignature unconditionally.
    """

    def setUp(self):
        from seif.context.context_manager import _clear_load_cache
        _clear_load_cache()

    def test_returns_none_when_cryptography_missing(self):
        from seif.context.context_manager import _verify_signature_on_load
        data = {
            "fingerprint": {"value": "deadbeef" * 8},
            "signature": {
                "algorithm": "Ed25519",
                "public_key": "AAAA",
                "signed_hash": "BBBB",
                "key_fingerprint": "ff" * 8,
            },
        }
        real_import = __import__

        def _failing_import(name, *args, **kwargs):
            if name.startswith("cryptography"):
                raise ImportError(f"simulated: no module named '{name}'")
            return real_import(name, *args, **kwargs)

        with patch("builtins.__import__", side_effect=_failing_import):
            result = _verify_signature_on_load(data, "/tmp/fake.seif")

        self.assertIsNone(
            result,
            "When cryptography is unavailable, verify must return None "
            "(skip), not raise UnboundLocalError.",
        )


class ListModulesUsesCacheTests(unittest.TestCase):
    """Sanity check: list_modules should reuse cached entries when
    invoked twice in the same process (the wrapper does this when
    estimate_tokens → list_modules → load_module fires each iteration).
    """

    def setUp(self):
        _clear_load_cache()

    def tearDown(self):
        _clear_load_cache()

    def test_repeated_load_module_calls_share_cache(self):
        with tempfile.TemporaryDirectory() as tmp:
            f = Path(tmp) / "mod.seif"
            _write_seif(f)
            for _ in range(5):
                load_module(str(f))
            # All 5 calls hit the same cache entry → only 1 entry total.
            self.assertEqual(len(_LOAD_CACHE), 1)


if __name__ == "__main__":
    unittest.main()
