"""Tests for s58 PR2 — cycle_lifecycle host pointer + start/close.

Acceptance criterion (binding, per .seif/modules/decision-2026-05-04-host-vs-workspace-storage-policy.seif):
  ~/.seif/active-cycle.json MUST contain exactly {cycle_id, workspace_path,
  cycle_open_path}. ZERO substantive fields at host. test_pointer_is_pointer_only
  enforces this.
"""

from __future__ import annotations

import json
import os
import uuid
from pathlib import Path

import pytest

from seif.plugins.core.cycle_lifecycle import (
    ACTIVE_CYCLE_FILENAME,
    ALLOWED_POINTER_KEYS,
    active_cycle_pointer_path,
    clear_active_pointer,
    close_cycle,
    read_active_pointer,
    start_cycle,
    write_active_pointer,
)
from seif.plugins.core.session_registry import (
    new_session_id,
    register,
)


@pytest.fixture
def isolated_host(tmp_path, monkeypatch):
    """Redirect ~/.seif/ to a tmp dir via SEIF_HOME so the host pointer
    lives in tmp and never leaks to the developer's real ~/.seif/."""
    host = tmp_path / "host-seif"
    monkeypatch.setenv("SEIF_HOME", str(host))
    return host


@pytest.fixture
def workspace(tmp_path):
    ws = tmp_path / "workspace"
    (ws / ".seif" / "cycles").mkdir(parents=True)
    return ws


def test_active_cycle_pointer_path_honors_seif_home(isolated_host):
    assert active_cycle_pointer_path() == isolated_host / ACTIVE_CYCLE_FILENAME


def test_write_active_pointer_creates_pointer_file(isolated_host, workspace):
    cycle_open = workspace / ".seif" / "cycles" / "demo-OPEN.seif"
    path = write_active_pointer(
        cycle_id="demo",
        workspace_path=workspace,
        cycle_open_path=cycle_open,
    )
    assert path.is_file()
    data = json.loads(path.read_text())
    assert data["cycle_id"] == "demo"
    assert data["workspace_path"] == str(workspace)
    assert data["cycle_open_path"] == str(cycle_open)


def test_pointer_is_pointer_only(isolated_host, workspace):
    """BINDING acceptance criterion (s58 q5 / decision module).

    The host pointer file MUST NOT carry substantive cycle content. If a
    future change ever leaks contributors / observations / findings /
    rationale / branches into ~/.seif/active-cycle.json, this test must fail.
    """
    cycle_open = workspace / ".seif" / "cycles" / "demo-OPEN.seif"
    path = write_active_pointer(
        cycle_id="demo",
        workspace_path=workspace,
        cycle_open_path=cycle_open,
    )
    data = json.loads(path.read_text())
    keys = set(data.keys())
    assert keys == ALLOWED_POINTER_KEYS, (
        f"pointer must be pointer-only; got keys {sorted(keys)}, "
        f"expected exactly {sorted(ALLOWED_POINTER_KEYS)}"
    )
    forbidden = {
        "contributors", "observations", "findings", "rationale", "branches",
        "deliverables", "vision", "key_findings", "frequency_at_open",
        "integrity_hash", "memory_zeta", "session_start", "parent_hash",
    }
    assert keys.isdisjoint(forbidden), (
        f"pointer leaked substantive field(s): {keys & forbidden}"
    )


def test_read_active_pointer_returns_none_when_absent(isolated_host):
    assert read_active_pointer() is None


def test_clear_active_pointer_idempotent(isolated_host, workspace):
    assert clear_active_pointer() is False  # nothing to clear
    write_active_pointer(
        cycle_id="x",
        workspace_path=workspace,
        cycle_open_path=workspace / ".seif" / "cycles" / "x-OPEN.seif",
    )
    assert clear_active_pointer() is True
    assert clear_active_pointer() is False


def test_start_cycle_opens_workspace_cycle_and_writes_pointer(isolated_host, workspace):
    result = start_cycle("s58-test-cycle", workspace=workspace)
    assert result["status"] == "opened", result.get("message")
    assert result["cycle_id"] == "s58-test-cycle"

    # workspace substance landed
    open_file = workspace / ".seif" / "cycles" / "s58-test-cycle-OPEN.seif"
    assert open_file.is_file()
    cycle_data = json.loads(open_file.read_text())
    assert cycle_data["cycle_id"] == "s58-test-cycle"
    assert cycle_data["status"] == "OPEN"

    # host pointer landed and is pointer-only
    pointer = read_active_pointer()
    assert pointer is not None
    assert set(pointer.keys()) == ALLOWED_POINTER_KEYS


def test_start_cycle_refuses_when_other_cycle_open(isolated_host, workspace):
    start_cycle("first", workspace=workspace)
    second = start_cycle("second", workspace=workspace)
    assert second["status"] == "error"
    assert "already open" in second["message"]


def test_start_cycle_reuses_when_same_slug_already_open(isolated_host, workspace):
    start_cycle("dup", workspace=workspace)
    again = start_cycle("dup", workspace=workspace)
    assert again["status"] == "reused"


def test_start_cycle_errors_when_no_seif_dir(isolated_host, tmp_path):
    bad = tmp_path / "no-seif-here"
    bad.mkdir()
    result = start_cycle("ghost", workspace=bad)
    assert result["status"] == "error"
    assert "no .seif/" in result["message"]


def test_close_cycle_seals_and_clears_pointer(isolated_host, workspace):
    start_cycle("to-close", workspace=workspace)
    assert read_active_pointer() is not None

    result = close_cycle(workspace=workspace)
    assert result["status"] == "closed"
    assert result["cycle_id"] == "to-close"
    assert result["pointer_cleared"] is True
    assert read_active_pointer() is None


def test_close_cycle_uses_pointer_when_slug_omitted(isolated_host, workspace):
    start_cycle("infer-me", workspace=workspace)
    result = close_cycle(workspace=workspace)  # no slug — should infer from pointer
    assert result["status"] == "closed"
    assert result["cycle_id"] == "infer-me"


def test_close_cycle_errors_on_slug_mismatch(isolated_host, workspace):
    start_cycle("real-slug", workspace=workspace)
    result = close_cycle("wrong-slug", workspace=workspace)
    assert result["status"] == "error"
    assert "mismatch" in result["message"].lower()
    # pointer remains because close was refused
    assert read_active_pointer() is not None


def test_close_cycle_errors_when_nothing_active(isolated_host, workspace):
    result = close_cycle(workspace=workspace)
    assert result["status"] == "error"
    assert "no active cycle" in result["message"].lower()


# ── PR1 ↔ PR2 integration: env var fallback wires through register() ──


def test_register_picks_up_seif_active_cycle_set_by_start_cycle(
    isolated_host, workspace, monkeypatch
):
    """Smoke test for the integration intent: after --start-cycle exports
    SEIF_ACTIVE_CYCLE, a register() call without explicit cycle_id should
    inherit the binding (PR1 contract). This test simulates the export.
    """
    result = start_cycle("integration", workspace=workspace)
    assert result["status"] == "opened"

    # Simulate the shell `export SEIF_ACTIVE_CYCLE=<slug>` step printed by --start-cycle
    monkeypatch.setenv("SEIF_ACTIVE_CYCLE", result["cycle_id"])

    seif_dir = workspace / ".seif"
    sid = new_session_id()
    register(seif_dir=seif_dir, session_id=sid, wrapper="x", cwd=workspace)
    entry = json.loads((seif_dir / "sessions" / "active" / f"{sid}.json").read_text())
    assert entry["cycle_id"] == "integration"


# ── s59 PR4 Layer A — close_cycle seal-guard ──


def test_close_cycle_clean_seals_when_no_writers_pending(isolated_host, workspace):
    """Baseline: a cycle with no active writer sessions seals normally."""
    start_cycle("clean-seal", workspace=workspace)
    result = close_cycle(workspace=workspace)
    assert result["status"] == "closed"
    assert "blocked_writers" not in result
    assert "forced_with_blocked_writers" not in result


def test_close_cycle_refuses_when_active_writer_session_bound(
    isolated_host, workspace, monkeypatch
):
    """BINDING acceptance: if an active session declares cycle_id == about-to-seal
    cycle, close_cycle MUST refuse without --force (would create class-(c)
    coherence violation per PR3 audit)."""
    start_cycle("guarded", workspace=workspace)
    # Simulate a sibling session that registered against this cycle and is still active
    monkeypatch.setenv("SEIF_ACTIVE_CYCLE", "guarded")
    sid = new_session_id()
    register(seif_dir=workspace / ".seif", session_id=sid, wrapper="x", cwd=workspace)

    result = close_cycle(workspace=workspace)
    assert result["status"] == "error"
    assert "Refusing to seal" in result["message"]
    assert "guarded" in result["message"]
    assert sid in result["blocked_writers"]
    # Pointer must NOT be cleared on refusal
    assert read_active_pointer() is not None
    # OPEN file must NOT be sealed
    assert (workspace / ".seif" / "cycles" / "guarded-OPEN.seif").is_file()
    assert not (workspace / ".seif" / "cycles" / "guarded-SEALED.seif").is_file()


def test_close_cycle_force_succeeds_and_writes_audit_trail(
    isolated_host, workspace, monkeypatch
):
    """BINDING acceptance: --force overrides the guard AND records the bypassed
    sessions into force_seal_audit_trail block of the SEALED file."""
    start_cycle("override-me", workspace=workspace)
    monkeypatch.setenv("SEIF_ACTIVE_CYCLE", "override-me")
    sid = new_session_id()
    register(seif_dir=workspace / ".seif", session_id=sid, wrapper="x", cwd=workspace)

    result = close_cycle(workspace=workspace, force=True)
    assert result["status"] == "closed"
    assert sid in result["forced_with_blocked_writers"]

    sealed_path = workspace / ".seif" / "cycles" / "override-me-SEALED.seif"
    assert sealed_path.is_file()
    sealed = json.loads(sealed_path.read_text())
    trail = sealed.get("force_seal_audit_trail")
    assert trail is not None, "force seal must record audit trail in SEALED file"
    assert "force_sealed_at" in trail
    assert any(e["session_id"] == sid for e in trail["active_writer_sessions_at_force"])
    assert "Operator used --force" in trail["rationale"]


def test_close_cycle_guard_ignores_sessions_bound_to_other_cycles(
    isolated_host, workspace, monkeypatch
):
    """A session bound to a DIFFERENT cycle must not block the seal of THIS cycle."""
    start_cycle("seal-target", workspace=workspace)
    monkeypatch.setenv("SEIF_ACTIVE_CYCLE", "some-other-cycle")
    sid = new_session_id()
    register(seif_dir=workspace / ".seif", session_id=sid, wrapper="x", cwd=workspace)

    result = close_cycle(workspace=workspace)
    assert result["status"] == "closed", (
        f"unrelated session must not block seal; got: {result.get('message')}"
    )


# ── s69 Track B+C — SEAL ritual completeness + scanner defense ──
#
# Problem motivating these tests: 6 stale `<slug>-OPEN.seif` files survived
# their cycles' SEAL ritual in seif-admin (s44/s65/s66/s67 had SEALED
# counterparts but OPEN files lingered at root, blocking _find_open_cycle's
# lex-first scan from accepting new --start-cycle). Track B fixes the
# audit-side root cause (cycle_close defensive rename + canonical-path
# cleanup); Track C adds block-side defense (scanner skips OPENs with
# SEALED counterparts).


def test_find_open_cycle_skips_open_with_sealed_counterpart(workspace):
    """Track C: scanner must skip *-OPEN.seif when *-SEALED.seif with same
    stem exists at the same path. Without this defense, leftover OPENs
    from prior sealed cycles return as 'active' and block --start-cycle.
    """
    from seif.context.cycle import _find_open_cycle

    cycles = workspace / ".seif" / "cycles"
    # Stale OPEN with SEALED counterpart (should be skipped)
    (cycles / "stale-OPEN.seif").write_text(json.dumps({"status": "OPEN", "cycle_id": "stale"}))
    (cycles / "stale-SEALED.seif").write_text(json.dumps({"status": "SEALED", "cycle_id": "stale"}))

    result = _find_open_cycle(workspace / ".seif")
    assert result is None, (
        f"OPEN with SEALED counterpart must be skipped; got: {result}"
    )


def test_find_open_cycle_returns_orphan_open_without_sealed(workspace):
    """Regression: an OPEN with NO SEALED counterpart is a legitimate active
    cycle and must still be detected (Track C defense must be conservative).
    """
    from seif.context.cycle import _find_open_cycle

    cycles = workspace / ".seif" / "cycles"
    (cycles / "active-OPEN.seif").write_text(json.dumps({"status": "OPEN", "cycle_id": "active"}))

    result = _find_open_cycle(workspace / ".seif")
    assert result is not None, "orphan OPEN without SEALED must still be detected"
    assert result["cycle_id"] == "active"


def test_find_open_cycle_picks_active_when_stale_present(workspace):
    """Track C in mixed state: scanner skips stale (with SEALED) and picks
    the truly-active OPEN even when stale lex-precedes it.
    """
    from seif.context.cycle import _find_open_cycle

    cycles = workspace / ".seif" / "cycles"
    # 'aaa-stale' lex-precedes 'zzz-active' — without Track C scanner picks aaa
    (cycles / "aaa-stale-OPEN.seif").write_text(json.dumps({"status": "OPEN", "cycle_id": "aaa-stale"}))
    (cycles / "aaa-stale-SEALED.seif").write_text(json.dumps({"status": "SEALED", "cycle_id": "aaa-stale"}))
    (cycles / "zzz-active-OPEN.seif").write_text(json.dumps({"status": "OPEN", "cycle_id": "zzz-active"}))

    result = _find_open_cycle(workspace / ".seif")
    assert result is not None
    assert result["cycle_id"] == "zzz-active", (
        f"scanner must skip stale and pick active; got: {result.get('cycle_id')}"
    )


def test_close_cycle_renames_open_to_archived_and_leaves_no_open(
    isolated_host, workspace
):
    """Track B happy path: after seal, *-OPEN.seif must NOT exist at root;
    *-OPEN-archived.seif must exist."""
    start_cycle("seal-cleanup", workspace=workspace)
    cycles = workspace / ".seif" / "cycles"
    assert (cycles / "seal-cleanup-OPEN.seif").is_file()

    result = close_cycle(workspace=workspace)
    assert result["status"] == "closed"
    assert not (cycles / "seal-cleanup-OPEN.seif").is_file(), (
        "OPEN file must be renamed away after seal — leftover blocks --start-cycle"
    )
    assert (cycles / "seal-cleanup-OPEN-archived.seif").is_file()
    assert (cycles / "seal-cleanup-SEALED.seif").is_file()


def test_close_cycle_rotates_archived_when_existing(isolated_host, workspace):
    """Track B archive collision: if OPEN-archived already exists from a
    prior partial seal, rotate to OPEN-archived-N.seif instead of overwriting.
    """
    cycles = workspace / ".seif" / "cycles"
    # Pre-seed an archived from a prior life
    (cycles / "rotate-me-OPEN-archived.seif").write_text(json.dumps({
        "status": "OPEN-archived",
        "cycle_id": "rotate-me",
        "from_prior_life": True,
    }))

    start_cycle("rotate-me", workspace=workspace)
    result = close_cycle(workspace=workspace)
    assert result["status"] == "closed"
    # Original archived must survive
    original = json.loads((cycles / "rotate-me-OPEN-archived.seif").read_text())
    assert original.get("from_prior_life") is True, "prior archived must not be overwritten"
    # New archived must land at -archived-1
    assert (cycles / "rotate-me-OPEN-archived-1.seif").is_file()
    assert not (cycles / "rotate-me-OPEN.seif").is_file()


def test_close_cycle_cleans_apfs_leftover_at_canonical_path(
    isolated_host, workspace
):
    """Track B defensive cleanup: if (e.g.) APFS chained-mv anomaly or a
    daemon recreated *-OPEN.seif at the canonical path AFTER cycle_close
    began but BEFORE its rename, the canonical OPEN must NOT survive the
    seal — defensive unlink catches the leftover.

    Simulated by writing a duplicate OPEN file post-rename via a callback.
    """
    cycles = workspace / ".seif" / "cycles"
    start_cycle("apfs-leftover", workspace=workspace)

    # Mid-flight: simulate a duplicate OPEN appearing (APFS leftover scenario).
    # In real life this happens between _find_open_cycle and the rename;
    # here we pre-seed it before close_cycle so the defensive unlink fires.
    open_file = cycles / "apfs-leftover-OPEN.seif"
    duplicate_path = cycles / "apfs-leftover-OPEN.seif"
    # The file already exists from start_cycle. Snapshot it so we can
    # restore it AFTER the rename, simulating the APFS leftover.
    snapshot = open_file.read_bytes()

    result = close_cycle(workspace=workspace)
    assert result["status"] == "closed"
    # After the rename, simulate the APFS chained-mv leftover by writing
    # the snapshot back to the canonical path.
    duplicate_path.write_bytes(snapshot)
    # Now invoke the defensive cleanup path: re-call cycle_close which
    # should detect SEALED already exists (and refuse) but the next
    # --start-cycle attempt should not be blocked by this leftover thanks
    # to Track C scanner defense (which is what the next assertion exercises).
    from seif.context.cycle import _find_open_cycle
    detected = _find_open_cycle(workspace / ".seif")
    assert detected is None, (
        "APFS leftover OPEN with SEALED counterpart must not be detected as active "
        "(Track C defense — scanner skips OPEN when SEALED-with-same-stem exists)"
    )
