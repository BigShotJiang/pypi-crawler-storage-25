"""Tests for seed auto-surfacing (s44 INIT-SURFACING 1/2).

Pre-fix: SEED-*.json files written at session-seal were never read on
the next session-start. Operators had to surface seeds manually. The
auto-onboarding pattern silently broke.

Post-fix:
- `find_pending_seed(seif_dir, model_id)` returns the most recent
  unconsumed seed matching the caller's identity (or any if model_id
  is None). Skips seeds whose `<path>.consumed_at` sidecar exists.
- `mark_seed_consumed(path, at)` writes the sidecar.
- `_signal_pending_seed(seif_dir)` (wrapper) prints a [SEEDS PENDING
  ENTRY] block and consumes the seed.
"""
from __future__ import annotations

import io
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from seif.cli.wrapper import _signal_pending_seed  # noqa: E402
from seif.context.workspace import (  # noqa: E402
    _glob_token_matches,
    find_pending_seed,
    mark_seed_consumed,
)


class GlobTokenMatchTests(unittest.TestCase):
    def test_no_wildcard_substring_match(self):
        self.assertTrue(_glob_token_matches("claude", "claude-opus-4-7"))

    def test_no_wildcard_no_match(self):
        self.assertFalse(_glob_token_matches("gemini", "claude-opus-4-7"))

    def test_wildcard_prefix(self):
        self.assertTrue(_glob_token_matches("claude-*", "claude-opus-4-7"))

    def test_wildcard_in_middle(self):
        self.assertTrue(_glob_token_matches("claude-*-4-7", "claude-opus-4-7"))

    def test_wildcard_suffix(self):
        self.assertTrue(_glob_token_matches("*-4-7", "claude-opus-4-7"))

    def test_wildcard_no_match(self):
        self.assertFalse(_glob_token_matches("gemini-*", "claude-opus-4-7"))


class FindPendingSeedTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.seif_dir = Path(self.tmp.name) / ".seif"
        self.seeds_dir = self.seif_dir / "seeds"
        self.seeds_dir.mkdir(parents=True)

    def tearDown(self):
        self.tmp.cleanup()

    def _write_seed(self, name: str, *, seed_id: str, issued_at: str,
                    issued_to: str = "claude-* @ host (next session)",
                    objective: str = "do the thing"):
        path = self.seeds_dir / name
        path.write_text(
            json.dumps(
                {
                    "protocol": "SEIF-SEED-v1",
                    "seed_id": seed_id,
                    "issued_at": issued_at,
                    "issued_to": issued_to,
                    "session_objective_for_test": objective,
                },
                indent=2,
            ),
            encoding="utf-8",
        )
        return path

    def test_no_seeds_dir_returns_none(self):
        # Workspace without any seeds/ subdir
        empty = Path(self.tmp.name) / "empty"
        empty.mkdir()
        self.assertIsNone(find_pending_seed(empty))

    def test_empty_dir_returns_none(self):
        self.assertIsNone(find_pending_seed(self.seif_dir))

    def test_returns_only_unconsumed_seed(self):
        path = self._write_seed("SEED-old.json", seed_id="old",
                                issued_at="2026-04-01T00:00:00Z")
        result = find_pending_seed(self.seif_dir)
        self.assertIsNotNone(result)
        self.assertEqual(result["path"], path)
        self.assertEqual(result["data"]["seed_id"], "old")

    def test_skips_consumed_seed(self):
        consumed = self._write_seed("SEED-consumed.json", seed_id="c",
                                    issued_at="2026-04-01T00:00:00Z")
        consumed.with_suffix(consumed.suffix + ".consumed_at").write_text(
            "2026-04-01T00:01:00Z"
        )
        self.assertIsNone(find_pending_seed(self.seif_dir))

    def test_picks_most_recent_by_issued_at(self):
        self._write_seed("SEED-a.json", seed_id="a",
                         issued_at="2026-04-01T00:00:00Z")
        latest = self._write_seed("SEED-b.json", seed_id="b",
                                  issued_at="2026-05-02T01:40:00Z")
        result = find_pending_seed(self.seif_dir)
        self.assertEqual(result["path"], latest)

    def test_filters_by_model_id_glob(self):
        self._write_seed("SEED-claude.json", seed_id="cl",
                         issued_at="2026-05-01T00:00:00Z",
                         issued_to="claude-* @ host (next session)")
        self._write_seed("SEED-gemini.json", seed_id="ge",
                         issued_at="2026-05-02T00:00:00Z",
                         issued_to="gemini-* @ host (next session)")
        # Caller is claude — the newer gemini seed must be skipped.
        result = find_pending_seed(self.seif_dir, model_id="claude-opus-4-7")
        self.assertIsNotNone(result)
        self.assertEqual(result["data"]["seed_id"], "cl")

    def test_no_filter_returns_newest_regardless(self):
        self._write_seed("SEED-claude.json", seed_id="cl",
                         issued_at="2026-05-01T00:00:00Z",
                         issued_to="claude-* @ host")
        latest = self._write_seed("SEED-other.json", seed_id="ge",
                                  issued_at="2026-05-02T00:00:00Z",
                                  issued_to="gemini-* @ host")
        result = find_pending_seed(self.seif_dir)
        self.assertEqual(result["path"], latest)

    def test_skips_malformed_seed(self):
        bad = self.seeds_dir / "SEED-bad.json"
        bad.write_text("{ not valid", encoding="utf-8")
        self._write_seed("SEED-good.json", seed_id="g",
                         issued_at="2026-05-02T00:00:00Z")
        result = find_pending_seed(self.seif_dir)
        self.assertEqual(result["data"]["seed_id"], "g")


class MarkSeedConsumedTests(unittest.TestCase):
    def test_writes_sidecar_at_given_timestamp(self):
        with tempfile.TemporaryDirectory() as tmp:
            seed = Path(tmp) / "SEED-x.json"
            seed.write_text("{}")
            sidecar = mark_seed_consumed(seed, at="2026-05-02T01:40:00Z")
            self.assertTrue(sidecar.exists())
            self.assertEqual(sidecar.read_text(), "2026-05-02T01:40:00Z")
            self.assertEqual(sidecar.name, "SEED-x.json.consumed_at")

    def test_writes_now_when_no_timestamp_given(self):
        with tempfile.TemporaryDirectory() as tmp:
            seed = Path(tmp) / "SEED-x.json"
            seed.write_text("{}")
            sidecar = mark_seed_consumed(seed)
            self.assertTrue(sidecar.exists())
            self.assertGreater(len(sidecar.read_text()), 10)


class SignalPendingSeedOutputTests(unittest.TestCase):
    """Wrapper surface: stderr block, then sidecar marks consumed."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.seif_dir = Path(self.tmp.name) / ".seif"
        (self.seif_dir / "seeds").mkdir(parents=True)

    def tearDown(self):
        self.tmp.cleanup()

    def _capture(self) -> str:
        buf = io.StringIO()
        with patch("sys.stderr", buf):
            _signal_pending_seed(self.seif_dir)
        return buf.getvalue()

    def test_silent_when_no_seed(self):
        self.assertEqual(self._capture(), "")

    def test_prints_block_and_consumes(self):
        seed = self.seif_dir / "seeds" / "SEED-x.json"
        seed.write_text(
            json.dumps({
                "protocol": "SEIF-SEED-v1",
                "seed_id": "test-seed",
                "issued_at": "2026-05-02T00:00:00Z",
                "issued_to": "claude-* @ host",
                "session_objective_for_test": "verify the surface",
            }),
            encoding="utf-8",
        )
        out = self._capture()
        self.assertIn("[SEEDS PENDING ENTRY]", out)
        self.assertIn("test-seed", out)
        self.assertIn("verify the surface", out)
        self.assertIn("seeds/SEED-x.json", out)
        # Sidecar created → seed consumed
        sidecar = seed.with_suffix(seed.suffix + ".consumed_at")
        self.assertTrue(sidecar.exists())

    def test_does_not_resurface_consumed_seed(self):
        seed = self.seif_dir / "seeds" / "SEED-x.json"
        seed.write_text(
            json.dumps({
                "seed_id": "x",
                "issued_at": "2026-05-02T00:00:00Z",
            }),
            encoding="utf-8",
        )
        # First surface: prints + consumes
        first = self._capture()
        self.assertIn("[SEEDS PENDING ENTRY]", first)
        # Second invocation should be silent
        second = self._capture()
        self.assertEqual(second, "")

    def test_long_objective_truncated(self):
        seed = self.seif_dir / "seeds" / "SEED-long.json"
        seed.write_text(
            json.dumps({
                "seed_id": "lo",
                "issued_at": "2026-05-02T00:00:00Z",
                "session_objective_for_test": "x" * 500,
            }),
            encoding="utf-8",
        )
        out = self._capture()
        self.assertIn("...", out)
        # Output line for objective starts with "  ↳ " (4 chars) and
        # should not exceed 4 + 200 + newline.
        for line in out.splitlines():
            if line.startswith("  ↳"):
                self.assertLessEqual(len(line), 4 + 200 + 5)


if __name__ == "__main__":
    unittest.main()
