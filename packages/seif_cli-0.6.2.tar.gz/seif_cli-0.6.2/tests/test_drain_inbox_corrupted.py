"""Test for drain_inbox corrupted-file preservation (s39 P4 patch-2).

Regression: drain_inbox previously executed PENDING_FILE.unlink() on JSON
parse failure with no preservation, no log. Lost messages couldn't be
recovered. Same anti-pattern class as the s38 outbox silent-delete bug.

Fix: rename PENDING_FILE to pending-corrupted-<ts>.json + stderr message
instead of unlinking.
"""

from __future__ import annotations

import json

import pytest


@pytest.fixture
def tmp_circuit(tmp_path, monkeypatch):
    """Redirect CIRCUIT_DIR + PENDING_FILE to tmp_path."""
    circuit_dir = tmp_path / "circuit"
    circuit_dir.mkdir()
    pending = circuit_dir / "pending-messages.json"

    from seif.plugins.core import circuit_monitor as cm

    monkeypatch.setattr(cm, "CIRCUIT_DIR", circuit_dir)
    monkeypatch.setattr(cm, "PENDING_FILE", pending)
    return cm, circuit_dir, pending


def test_corrupted_pending_is_preserved_not_unlinked(tmp_circuit, capsys):
    cm, circuit_dir, pending = tmp_circuit
    pending.write_text("{not-json{{{")

    rc = cm.drain_inbox()
    assert rc == 0
    assert not pending.exists(), "original pending file should be renamed"

    corrupted = list(circuit_dir.glob("pending-corrupted-*.json"))
    assert len(corrupted) == 1, f"expected one preserved file, got {corrupted}"
    assert corrupted[0].read_text() == "{not-json{{{"

    captured = capsys.readouterr()
    assert "unparseable" in captured.err
    assert "preserved" in captured.err


def test_valid_pending_drains_and_unlinks_on_success(tmp_circuit, monkeypatch):
    cm, circuit_dir, pending = tmp_circuit
    monkeypatch.setattr(cm, "_load_watermark", lambda: set())
    monkeypatch.setattr(cm, "_save_watermark", lambda s: None)

    pending.write_text(json.dumps([
        {"filename": "test-1.json", "received_at": "2026-05-01T00:00:00+00:00", "body": {"content": "hi"}}
    ]))

    rc = cm.drain_inbox()
    assert rc == 0
    assert not pending.exists(), "successful drain should unlink (success-path is correct)"
    assert not list(circuit_dir.glob("pending-corrupted-*.json"))


def test_empty_pending_unlinks_immediately(tmp_circuit):
    cm, circuit_dir, pending = tmp_circuit
    pending.write_text("[]")

    rc = cm.drain_inbox()
    assert rc == 0
    assert not pending.exists()
    assert not list(circuit_dir.glob("pending-corrupted-*.json"))
