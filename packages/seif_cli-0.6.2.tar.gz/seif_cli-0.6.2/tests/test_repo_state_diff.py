"""Tests for repo-state-diff session-start surfacing (s46 p1).

Pre-fix: when a session ended on a transport interruption (SSH drop,
mid-cycle), the resuming session had no surface signal about commits
that landed in the meantime. Resume from transcript could redo work
already merged.

Post-fix:
- `_signal_repo_state_diff(seif_dir)` walks the workspace root, detects
  child directories with `.git/`, and surfaces `git log --oneline -5`
  per repo into stderr under one header block.
- Silent when no git repos sit beside `.seif/`.
- Bounded: stops after 8 repos, 3-second timeout per `git log`.
"""
from __future__ import annotations

import io
import os
import subprocess
import sys
import tempfile
import unittest
from contextlib import redirect_stderr
from pathlib import Path

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from seif.cli.wrapper import _signal_repo_state_diff  # noqa: E402


def _git(*args: str, cwd: Path) -> None:
    subprocess.run(["git", *args], cwd=str(cwd), check=True,
                   capture_output=True)


def _init_repo_with_commits(repo: Path, n: int = 2) -> None:
    repo.mkdir(parents=True, exist_ok=True)
    _git("init", "-q", "-b", "main", cwd=repo)
    _git("config", "user.email", "t@t", cwd=repo)
    _git("config", "user.name", "t", cwd=repo)
    _git("config", "commit.gpgsign", "false", cwd=repo)
    for i in range(n):
        (repo / f"f{i}.txt").write_text(str(i))
        _git("add", ".", cwd=repo)
        _git("commit", "-q", "-m", f"commit {i}", cwd=repo)


class RepoStateDiffTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.workspace = Path(self.tmp.name)
        self.seif_dir = self.workspace / ".seif"
        self.seif_dir.mkdir()

    def tearDown(self):
        self.tmp.cleanup()

    def _capture(self) -> str:
        buf = io.StringIO()
        with redirect_stderr(buf):
            _signal_repo_state_diff(self.seif_dir)
        return buf.getvalue()

    def test_silent_when_no_repos(self):
        out = self._capture()
        self.assertEqual(out, "")

    def test_skips_dirs_without_git(self):
        (self.workspace / "plain-dir").mkdir()
        out = self._capture()
        self.assertEqual(out, "")

    def test_surfaces_single_repo(self):
        _init_repo_with_commits(self.workspace / "repo-a", n=2)
        out = self._capture()
        self.assertIn("[REPO STATE", out)
        self.assertIn("repo-a/", out)
        self.assertIn("commit 1", out)
        self.assertIn("commit 0", out)

    def test_surfaces_multiple_repos_sorted(self):
        _init_repo_with_commits(self.workspace / "repo-z", n=1)
        _init_repo_with_commits(self.workspace / "repo-a", n=1)
        out = self._capture()
        a_pos = out.find("repo-a/")
        z_pos = out.find("repo-z/")
        self.assertGreater(a_pos, 0)
        self.assertGreater(z_pos, a_pos)

    def test_caps_log_at_5_commits(self):
        _init_repo_with_commits(self.workspace / "repo-deep", n=8)
        out = self._capture()
        commit_lines = [line for line in out.splitlines()
                        if "commit " in line]
        self.assertEqual(len(commit_lines), 5)

    def test_caps_repos_at_8(self):
        for i in range(10):
            _init_repo_with_commits(self.workspace / f"repo-{i:02d}",
                                    n=1)
        out = self._capture()
        repo_headers = [line for line in out.splitlines()
                        if line.strip().endswith("/")]
        self.assertEqual(len(repo_headers), 8)

    def test_swallows_bare_git_dir(self):
        bare = self.workspace / "repo-bare"
        bare.mkdir()
        (bare / ".git").write_text("not a git dir")
        out = self._capture()
        self.assertNotIn("repo-bare/", out)

    def test_silent_when_workspace_missing(self):
        bogus = self.workspace / "nonexistent" / ".seif"
        buf = io.StringIO()
        with redirect_stderr(buf):
            _signal_repo_state_diff(bogus)
        self.assertEqual(buf.getvalue(), "")


if __name__ == "__main__":
    unittest.main()
