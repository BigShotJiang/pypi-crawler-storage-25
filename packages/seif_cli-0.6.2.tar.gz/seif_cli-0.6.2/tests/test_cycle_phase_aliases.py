"""Cycle phase alias contract (s57 PR-5).

The CLI rename introduces canonical phase names verify/review/persist/close.
Legacy names audit/meditate/absorb remain accepted as aliases for one release
cycle. Both old and new must route to the same underlying handler.
"""

from __future__ import annotations

import re
from pathlib import Path

import pytest


CLI_PATH = Path(__file__).resolve().parents[1] / "src" / "seif" / "cli" / "cli.py"

CYCLE_ARG_PATTERN = re.compile(
    r'add_argument\("--cycle".*?choices=\[(.*?)\]',
    re.DOTALL,
)


@pytest.fixture(scope="module")
def cli_source() -> str:
    return CLI_PATH.read_text()


@pytest.fixture(scope="module")
def cycle_choices(cli_source: str) -> str:
    block = CYCLE_ARG_PATTERN.search(cli_source)
    assert block is not None, "Could not locate --cycle argparse block"
    return block.group(1)


def test_canonical_names_in_choices(cycle_choices: str):
    """Argparse must list canonical names verify/review/persist/close."""
    for name in ("verify", "review", "persist", "close"):
        assert f'"{name}"' in cycle_choices, f"missing canonical choice: {name}"


def test_legacy_aliases_in_choices(cycle_choices: str):
    """Argparse must still accept legacy names audit/meditate/absorb."""
    for legacy in ("audit", "meditate", "absorb"):
        assert f'"{legacy}"' in cycle_choices, f"missing legacy alias: {legacy}"


def test_alias_map_is_present(cli_source: str):
    """The dispatch must contain the legacy→canonical alias map."""
    assert '"audit": "verify"' in cli_source, "missing audit→verify alias"
    assert '"meditate": "review"' in cli_source, "missing meditate→review alias"
    assert '"absorb": "persist"' in cli_source, "missing absorb→persist alias"


def test_canonical_handlers_dispatch(cli_source: str):
    """Each canonical phase routes to its underlying handler."""
    assert re.search(r'action == "verify"\s*:\s*\n\s*print\(cycle_audit', cli_source), \
        "verify must dispatch to cycle_audit"
    assert re.search(r'action == "review"\s*:\s*\n\s*print\(cycle_meditate', cli_source), \
        "review must dispatch to cycle_meditate"
    assert re.search(r'action == "persist"\s*:\s*\n\s*print\(cycle_absorb', cli_source), \
        "persist must dispatch to cycle_absorb"


def test_help_text_documents_canonical_and_legacy(cli_source: str):
    """Help string for --cycle must mention canonical names + legacy alias note."""
    block = CYCLE_ARG_PATTERN.search(cli_source)
    assert block is not None
    # Find the help= text following the choices block
    after = cli_source[block.end():block.end() + 800]
    help_match = re.search(r'help=("(?:[^"\\]|\\.)*"(?:\s*\n\s*"(?:[^"\\]|\\.)*")*)', after, re.DOTALL)
    assert help_match is not None, "Could not extract help= text"
    help_text = help_match.group(1)
    assert "verify" in help_text and "review" in help_text and "persist" in help_text, \
        "help text must list canonical phases"
    assert "legacy" in help_text.lower() or "alias" in help_text.lower(), \
        "help text should mention legacy/alias status"
