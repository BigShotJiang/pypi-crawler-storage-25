"""Tests for session counter advance after seal (s44 INIT-FOUNDATION 4/4).

Pre-fix: `_observed_session_numbers` only extracted the `session_number`
int field from inside closure files. Closures written under newer
schemas carry `session_id` (string) instead, so they contributed nothing
to the observation set. A closure-only state (session-N.json archived
while session-N-closure.seif remained) silently regressed the next
session counter to N instead of N+1, attributing the new session to the
already-sealed predecessor.

Post-fix: filename `session-{N}-closure.seif` is the canonical source
for closure observations.
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from seif.plugins.core.session_lifecycle import (  # noqa: E402
    _observed_session_numbers,
    next_session_count,
)


class _SessionDirFixture(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.seif_dir = Path(self.tmp.name) / ".seif"
        self.session_dir = self.seif_dir / "sessions"
        self.session_dir.mkdir(parents=True)
        self.mapper_path = self.seif_dir / "mapper.json"
        self.mapper_path.write_text(
            json.dumps({"version": 1, "session_count": 0, "modules": []}),
            encoding="utf-8",
        )

    def tearDown(self):
        self.tmp.cleanup()

    def _write_session_json(self, n: int, *, status: str = "ACTIVE",
                            include_session_number: bool = True):
        data = {"session_id": f"session-{n}", "status": status}
        if include_session_number:
            data["session_number"] = n
        (self.session_dir / f"session-{n}.json").write_text(
            json.dumps(data), encoding="utf-8"
        )

    def _write_closure(self, n: int, *, include_session_number: bool):
        data = {
            "session_id": f"session-{n}",
            "protocol": "SEIF-SESSION-CLOSURE-v1",
            "sealed_at": "2026-05-02T00:00:00Z",
        }
        if include_session_number:
            data["session_number"] = n
        (self.session_dir / f"session-{n}-closure.seif").write_text(
            json.dumps(data), encoding="utf-8"
        )


class ObservedSessionNumbersTests(_SessionDirFixture):
    def test_empty_dir(self):
        self.assertEqual(_observed_session_numbers(self.session_dir), [])

    def test_missing_dir(self):
        self.assertEqual(
            _observed_session_numbers(self.seif_dir / "no-such-dir"), []
        )

    def test_closure_with_session_number_inner_field(self):
        self._write_closure(40, include_session_number=True)
        self.assertIn(40, _observed_session_numbers(self.session_dir))

    def test_closure_without_inner_session_number_via_filename(self):
        # Newer closures carry session_id (string), no session_number.
        # Filename must still be the source of truth.
        self._write_closure(43, include_session_number=False)
        self.assertIn(43, _observed_session_numbers(self.session_dir))

    def test_filename_only_when_closure_unparseable(self):
        # Closure file is malformed JSON — filename still wins.
        (self.session_dir / "session-50-closure.seif").write_text(
            "{ corrupt", encoding="utf-8"
        )
        self.assertIn(50, _observed_session_numbers(self.session_dir))

    def test_mixed_schema_picks_max(self):
        self._write_session_json(40, status="CLOSED",
                                 include_session_number=True)
        self._write_closure(40, include_session_number=True)
        self._write_session_json(41, status="CLOSED",
                                 include_session_number=True)
        self._write_closure(41, include_session_number=False)
        self._write_closure(43, include_session_number=False)
        observed = _observed_session_numbers(self.session_dir)
        self.assertEqual(max(observed), 43)


class NextSessionCountTests(_SessionDirFixture):
    def test_no_sessions_returns_one(self):
        # Fresh workspace: counter = stored(0) + 1 = 1
        self.assertEqual(next_session_count(self.seif_dir), 1)

    def test_advances_past_closure_only_state(self):
        # The s43→s44 case: closure exists, no JSON sidecar with
        # session_number. Pre-fix: returned 1. Post-fix: returns 44.
        self._write_closure(43, include_session_number=False)
        self.assertEqual(next_session_count(self.seif_dir), 44)

    def test_advances_when_closure_has_inner_field(self):
        # Older schema closures still work (filename + inner agree).
        self._write_closure(40, include_session_number=True)
        self.assertEqual(next_session_count(self.seif_dir), 41)

    def test_resume_open_session_does_not_advance(self):
        # ACTIVE session-N.json exists and no closure — next is N+1
        # but caller's resume logic is responsible for picking N over
        # N+1 if appropriate. This function returns the floor.
        self._write_session_json(43, status="ACTIVE",
                                 include_session_number=True)
        self.assertEqual(next_session_count(self.seif_dir), 44)

    def test_uses_max_of_stored_and_observed(self):
        # Stale mapper: stored=10 but disk shows session-43-closure.
        # Honest measurement: trust disk over mapper.
        self.mapper_path.write_text(
            json.dumps({"version": 1, "session_count": 10, "modules": []}),
            encoding="utf-8",
        )
        self._write_closure(43, include_session_number=False)
        self.assertEqual(next_session_count(self.seif_dir), 44)

    def test_uses_stored_when_higher_than_observed(self):
        # Future-stored case (e.g., closure not yet flushed).
        self.mapper_path.write_text(
            json.dumps({"version": 1, "session_count": 99, "modules": []}),
            encoding="utf-8",
        )
        self.assertEqual(next_session_count(self.seif_dir), 100)


if __name__ == "__main__":
    unittest.main()
