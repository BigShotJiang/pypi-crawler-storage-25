"""Tests for _pending_modules_summary — surfaces SEIF-PENDING-v1 modules at
session-start so deferred work is visible in the first frame.

Closes the discoverability gap that allowed the 2026-05-01 dual-source-of-
truth incident (cf. memory `feedback_pending_module_canonical`).
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from seif.plugins.core.session_lifecycle import _pending_modules_summary


@pytest.fixture
def seif_dir(tmp_path):
    d = tmp_path / ".seif"
    (d / "modules").mkdir(parents=True)
    return d


def _write_pending(modules_dir: Path, name: str, items: list[dict],
                   title: str = "test pending", protocol: str = "SEIF-PENDING-v1"):
    (modules_dir / name).write_text(json.dumps({
        "protocol": protocol,
        "module_id": Path(name).stem,
        "category": "pending",
        "title": title,
        "items": items,
    }))


def test_returns_empty_when_no_modules_dir(tmp_path):
    assert _pending_modules_summary(tmp_path / ".seif") == []


def test_returns_empty_when_no_pending_files(seif_dir):
    assert _pending_modules_summary(seif_dir) == []


def test_returns_empty_when_module_has_no_items(seif_dir):
    _write_pending(seif_dir / "modules", "pending-empty.seif", [])
    assert _pending_modules_summary(seif_dir) == []


def test_surfaces_single_pending_module(seif_dir):
    _write_pending(
        seif_dir / "modules",
        "pending-2026-05-01-test.seif",
        [
            {"id": "item-1", "severity": "MEDIUM", "title": "first"},
            {"id": "item-2", "severity": "LOW", "title": "second"},
        ],
        title="Two test items",
    )
    out = _pending_modules_summary(seif_dir)
    assert any("PENDING MODULES" in line for line in out)
    # s44 INIT-FOUNDATION 3/4: surface counts open items, filters LANDED.
    # All items here are open → "2 open items across 1 module(s)".
    assert any("2 open items across 1 module(s)" in line for line in out)
    assert any("pending-2026-05-01-test.seif" in line for line in out)
    assert any("Two test items" in line for line in out)


def test_aggregates_multiple_pending_modules(seif_dir):
    _write_pending(seif_dir / "modules", "pending-a.seif",
                   [{"id": "x"}, {"id": "y"}], title="alpha")
    _write_pending(seif_dir / "modules", "pending-b.seif",
                   [{"id": "z"}], title="beta")
    out = _pending_modules_summary(seif_dir)
    assert any("3 open items across 2 module(s)" in line for line in out)
    assert any("pending-a.seif: 2 item(s)" in line for line in out)
    assert any("pending-b.seif: 1 item(s)" in line for line in out)


def test_skips_non_pending_protocol(seif_dir):
    _write_pending(seif_dir / "modules", "pending-mismatch.seif",
                   [{"id": "x"}], protocol="OTHER-PROTOCOL-v1")
    assert _pending_modules_summary(seif_dir) == []


def test_skips_malformed_json(seif_dir):
    (seif_dir / "modules" / "pending-bad.seif").write_text("not json {")
    _write_pending(seif_dir / "modules", "pending-good.seif", [{"id": "x"}])
    out = _pending_modules_summary(seif_dir)
    assert any("pending-good.seif" in line for line in out)
    assert not any("pending-bad.seif" in line for line in out)


def test_truncates_long_titles(seif_dir):
    long_title = "x" * 200
    _write_pending(seif_dir / "modules", "pending-long.seif",
                   [{"id": "x"}], title=long_title)
    out = _pending_modules_summary(seif_dir)
    title_line = next(line for line in out if "pending-long.seif" in line)
    # Title is truncated to 70 chars in the output
    assert "x" * 70 in title_line
    assert "x" * 71 not in title_line


def test_surfaces_only_files_matching_pending_glob(seif_dir):
    """Files not matching pending-*.seif must be ignored even with right protocol."""
    (seif_dir / "modules" / "other.seif").write_text(json.dumps({
        "protocol": "SEIF-PENDING-v1",
        "items": [{"id": "x"}],
        "title": "ignored",
    }))
    assert _pending_modules_summary(seif_dir) == []
