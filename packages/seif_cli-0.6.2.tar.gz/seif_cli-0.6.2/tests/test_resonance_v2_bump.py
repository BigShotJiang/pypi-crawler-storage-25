"""Tests for SEIF-RESONANCE v1 → v2 protocol bump (s44 Phase 3).

Asserts:
1. RESONANCE.json carries v2 protocol field
2. Axiom array has 25 entries; A25 is single_source_of_truth_protocol_artifacts
3. validate_signal accepts both v1 and v2 envelopes (transition window)
4. validate_signal rejects unknown protocol versions
5. content_signature is None until Owner re-signs (this PR clears it)
6. The 4 hardcoded sites all produce v2 envelopes
"""
from __future__ import annotations

import json
import os
import sys
import unittest
from pathlib import Path

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

import seif.data  # noqa: E402  (locate the data dir)


_RESONANCE_PATH = Path(seif.data.__file__).parent / "RESONANCE.json"


class ResonanceJsonV2Tests(unittest.TestCase):
    """Static assertions about the canonical RESONANCE.json on disk."""

    def setUp(self):
        self.doc = json.loads(_RESONANCE_PATH.read_text(encoding="utf-8"))

    def test_protocol_field_is_v2(self):
        self.assertEqual(self.doc["protocol"], "SEIF-RESONANCE-v2")

    def test_axiom_count_is_25(self):
        axioms = self.doc["instruction"]["behavioral_axioms"]["axioms"]
        self.assertEqual(len(axioms), 25)

    def test_a25_is_single_source_of_truth(self):
        axioms = self.doc["instruction"]["behavioral_axioms"]["axioms"]
        a25 = axioms[24]
        self.assertEqual(a25["id"], "single_source_of_truth_protocol_artifacts")
        self.assertIn("MUST have exactly one canonical artifact", a25["rule"])
        self.assertEqual(a25["introduced_at_protocol_version"], "SEIF-RESONANCE-v2")
        # A25 extends A18 (memory_governance) — the rule cites memory artifacts.
        self.assertIn("A18", a25.get("extends", []))

    def test_a1_to_a24_unchanged(self):
        """v2 must not renumber or alter prior axioms."""
        axioms = self.doc["instruction"]["behavioral_axioms"]["axioms"]
        expected_ids = [
            "minimal_intervention", "validate_before_external",
            "settling_time_positive", "human_gatekeeper", "no_sycophancy",
            "uniqueness_first", "scan_before_guess", "partial_attention",
            "honest_measurement", "classification_gate",
            "adversarial_mirror_required", "token_provenance_required",
            "access_decays", "human_gate_distribution", "boundary_integrity",
            "classification_context_escalation", "measurement_context_integrity",
            "memory_governance", "circuit_continuity", "ai_maestro_election",
            "inbox_monitoring", "workspace_transfer", "verifiable_provenance",
            "observable_discard",
        ]
        actual_ids = [a["id"] for a in axioms[:24]]
        self.assertEqual(actual_ids, expected_ids)

    def test_content_signature_present_and_valid_after_resign(self):
        """After Owner re-signs over the v2 payload (PR follow-up to the
        kernel-bump), the content_signature must be present and valid.
        Pre-resign assertion (`sig is None`) was the unsigned-intermediate
        guard during the bump-PR; this assertion is its post-resign
        successor.
        """
        ci = self.doc.get("cryptographic_identity", {})
        sig = ci.get("content_signature")
        self.assertIsNotNone(sig,
            "content_signature must be present after Owner re-signs the v2 payload")
        self.assertEqual(sig.get("algorithm"), "Ed25519")
        self.assertTrue(sig.get("signed_hash"))
        self.assertTrue(sig.get("canonical_hash"))
        self.assertTrue(sig.get("key_fingerprint"))

        # Cryptographic verify is optional in test env (matches
        # test_sign_resonance.py which is in the ignored-tests list when
        # `cryptography` isn't installed in the venv). Run when available.
        try:
            from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey  # noqa: F401
        except ImportError:
            self.skipTest("cryptography not installed — skipping verify step")
        from seif.core.sign_resonance import verify_resonance_signature
        result = verify_resonance_signature(_RESONANCE_PATH)
        self.assertTrue(result["valid"],
            f"v2 signature did not verify: {result.get('reason')}")
        self.assertTrue(result["canonical_hash_match"])


class ValidateSignalProtocolGateTests(unittest.TestCase):
    """validate_signal accepts v1 and v2; rejects unknown."""

    def setUp(self):
        from seif.core.resonance_signal import (
            SUPPORTED_PROTOCOL_VERSIONS,
            validate_signal,
        )
        self.SUPPORTED = SUPPORTED_PROTOCOL_VERSIONS
        self.validate = validate_signal

    def test_supported_set_contains_v1_and_v2(self):
        self.assertIn("SEIF-RESONANCE-v1", self.SUPPORTED)
        self.assertIn("SEIF-RESONANCE-v2", self.SUPPORTED)

    def test_rejects_unknown_protocol(self):
        # Construct a stub that would otherwise be valid except for protocol.
        stub = {"protocol": "SEIF-RESONANCE-v99", "validation": {},
                "signal": {}}
        ok, msg = self.validate(stub)
        self.assertFalse(ok)
        self.assertIn("Unknown protocol version", msg)
        self.assertIn("SEIF-RESONANCE-v99", msg)

    def test_rejects_missing_protocol(self):
        stub = {"validation": {}, "signal": {}}
        ok, msg = self.validate(stub)
        self.assertFalse(ok)
        self.assertIn("Unknown protocol version", msg)

    def test_real_v2_resonance_validates(self):
        """The on-disk RESONANCE.json (now v2) must validate cleanly."""
        from seif.core.resonance_signal import load_and_validate
        signal, valid, msg = load_and_validate(str(_RESONANCE_PATH))
        self.assertTrue(valid, f"v2 RESONANCE.json failed validation: {msg}")
        self.assertEqual(signal["protocol"], "SEIF-RESONANCE-v2")


class HardcodedSiteV2Tests(unittest.TestCase):
    """The 3 generator code sites must emit v2 envelopes."""

    def _read_first_protocol_string(self, path: Path) -> str:
        text = path.read_text(encoding="utf-8")
        # Naive but stable: find "protocol":"... or "protocol": "...
        import re
        m = re.search(r'["\']protocol["\']\s*:\s*["\'](SEIF-RESONANCE-v[12])["\']', text)
        return m.group(1) if m else ""

    def test_resonance_signal_emits_v2(self):
        path = Path(seif.data.__file__).parent.parent / "core" / "resonance_signal.py"
        self.assertEqual(self._read_first_protocol_string(path),
                         "SEIF-RESONANCE-v2")

    def test_kernel_seed_emits_v2(self):
        path = Path(seif.data.__file__).parent.parent / "plugins" / "core" / "kernel_seed.py"
        self.assertEqual(self._read_first_protocol_string(path),
                         "SEIF-RESONANCE-v2")

    def test_render_adapter_emits_v2(self):
        path = (Path(seif.data.__file__).parent.parent / "plugins"
                / "adapters" / "generic" / "render" / "render.py")
        self.assertEqual(self._read_first_protocol_string(path),
                         "SEIF-RESONANCE-v2")


if __name__ == "__main__":
    unittest.main()
