"""Tests for the s62 PR4 integrity orchestrator.

Resolves admin-docs cold-AI Gaps 22, 23, 24, 25, 39, 40 in one architectural
change. The orchestrator's contract:

    update_integrity → all three integrity facts simultaneously valid
    verify_integrity → joined verdict (no surface left disjoint)
    Mutual destruction is gone (v2 scope excludes signature).

These tests cover the round-trip, tamper detection, the half-valid case
(no signature), legacy v1 backward-compat, scope_version recording on
signatures, and the bulk migration command.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

import pytest

from seif.core.fingerprint import (
    SCOPE_V1, SCOPE_V2, calculate_fingerprint, verify_fingerprint,
)
from seif.core.integrity import (
    INTEGRITY_VALID, INTEGRITY_PENDING, INTEGRITY_HALF_VALID, INTEGRITY_INVALID,
    update_integrity, verify_integrity, migrate_integrity,
)


SAMPLE_MODULE = {
    "protocol": "SEIF-MODULE-v2",
    "classification": "INTERNAL",
    "summary": "test module for integrity orchestrator",
    "contributors": [],
}


def _write_module(path: Path, payload: dict | None = None) -> Path:
    path.write_text(json.dumps(payload or SAMPLE_MODULE, indent=2),
                    encoding="utf-8")
    return path


# ── fingerprint scope dispatch ─────────────────────────────────────


def test_calculate_fingerprint_v1_excludes_only_fingerprint_and_integrity_hash():
    data = {"a": 1, "fingerprint": {"value": "X"}, "integrity_hash": "Y"}
    fp = calculate_fingerprint(data, scope=SCOPE_V1)
    assert isinstance(fp, str) and len(fp) == 64


def test_calculate_fingerprint_v2_also_excludes_signature():
    data_no_sig = {"a": 1}
    data_with_sig = {"a": 1, "signature": {"signed_hash": "Z"}}
    fp_no_sig = calculate_fingerprint(data_no_sig, scope=SCOPE_V2)
    fp_with_sig = calculate_fingerprint(data_with_sig, scope=SCOPE_V2)
    assert fp_no_sig == fp_with_sig, (
        "v2 fingerprint must be invariant to presence of signature field — "
        "this is the load-bearing fix for Gap 24 mutual destruction"
    )


def test_calculate_fingerprint_v1_changes_when_signature_added():
    """Sanity: v1 keeps its bug — adding signature DOES change v1 fp.
    This documents WHY v2 was necessary."""
    data_no_sig = {"a": 1}
    data_with_sig = {"a": 1, "signature": {"signed_hash": "Z"}}
    fp_no_sig = calculate_fingerprint(data_no_sig, scope=SCOPE_V1)
    fp_with_sig = calculate_fingerprint(data_with_sig, scope=SCOPE_V1)
    assert fp_no_sig != fp_with_sig


def test_verify_fingerprint_dispatches_on_scope():
    data = {"a": 1, "signature": {"signed_hash": "Z"}}
    fp_v2 = calculate_fingerprint(data, scope=SCOPE_V2)
    data_v2_block = dict(data)
    data_v2_block["fingerprint"] = {"value": fp_v2, "scope": SCOPE_V2}
    ok, _ = verify_fingerprint(data_v2_block)
    assert ok, "v2-scoped fingerprint must verify when block records scope=v2"


def test_verify_fingerprint_legacy_default_is_v1():
    """Modules without a scope field default to v1 verification (legacy)."""
    data = {"a": 1}
    fp_v1 = calculate_fingerprint(data, scope=SCOPE_V1)
    data_v1_block = dict(data)
    # Note: omit `scope` to simulate legacy module written before scope dispatch.
    data_v1_block["fingerprint"] = {"value": fp_v1}
    ok, _ = verify_fingerprint(data_v1_block)
    assert ok


# ── update_integrity round-trip ────────────────────────────────────


def test_update_integrity_skip_sign_skip_stamp_round_trip(tmp_path):
    mod = _write_module(tmp_path / "m.seif")
    report = update_integrity(mod, skip_sign=True, skip_stamp=True)
    assert report.scope_version == SCOPE_V2
    assert report.fingerprint_status == "VALID"
    assert "sign" in report.skipped
    assert "stamp" in report.skipped

    # Re-verify: fingerprint VALID, others MISSING → overall HALF_VALID.
    verdict = verify_integrity(mod)
    assert verdict.fingerprint == "VALID"
    assert verdict.signature == "MISSING"
    assert verdict.stamp in ("MISSING", "OTS_NOT_INSTALLED")
    assert verdict.overall == INTEGRITY_HALF_VALID


def test_update_integrity_strips_legacy_integrity_hash(tmp_path):
    """v2 orchestrator removes the legacy integrity_hash field — single source of truth."""
    mod = tmp_path / "m.seif"
    payload = dict(SAMPLE_MODULE)
    payload["integrity_hash"] = "stale-legacy-value"
    _write_module(mod, payload)

    update_integrity(mod, skip_sign=True, skip_stamp=True)
    after = json.loads(mod.read_text(encoding="utf-8"))
    assert "integrity_hash" not in after
    assert after["fingerprint"]["scope"] == SCOPE_V2


def test_update_integrity_writes_atomic_no_temp_files_left(tmp_path):
    """Atomic write must clean up the temp file after successful rename."""
    mod = _write_module(tmp_path / "m.seif")
    update_integrity(mod, skip_sign=True, skip_stamp=True)
    leftovers = [p for p in tmp_path.iterdir() if p.name.startswith(".") and p.name.endswith(".tmp")]
    assert leftovers == []


# ── tamper detection ───────────────────────────────────────────────


def test_verify_integrity_detects_content_tampering(tmp_path):
    mod = _write_module(tmp_path / "m.seif")
    update_integrity(mod, skip_sign=True, skip_stamp=True)

    data = json.loads(mod.read_text(encoding="utf-8"))
    data["summary"] = "MUTATED"
    mod.write_text(json.dumps(data, indent=2), encoding="utf-8")

    verdict = verify_integrity(mod)
    assert verdict.fingerprint == "INVALID"
    assert verdict.overall == INTEGRITY_INVALID


# ── joined verdict states ──────────────────────────────────────────


def test_verify_integrity_missing_fingerprint_block_is_half_valid(tmp_path):
    mod = _write_module(tmp_path / "m.seif")
    verdict = verify_integrity(mod)
    assert verdict.fingerprint == "MISSING"
    assert verdict.signature == "MISSING"
    assert verdict.overall == INTEGRITY_INVALID or verdict.overall == INTEGRITY_HALF_VALID
    # When fingerprint is MISSING (no value), it's recorded as MISSING — NOT
    # INVALID. Combined with no signature, overall must be HALF_VALID.
    assert verdict.overall == INTEGRITY_HALF_VALID


def test_verify_integrity_invalid_signature_overrides_to_invalid(tmp_path):
    """If fingerprint is VALID but signature explicitly INVALID, overall is INVALID."""
    mod = _write_module(tmp_path / "m.seif")
    update_integrity(mod, skip_sign=True, skip_stamp=True)
    # Inject a malformed signature block to force INVALID.
    data = json.loads(mod.read_text(encoding="utf-8"))
    data["signature"] = {
        "algorithm": "Ed25519",
        "public_key": "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=",
        "signed_hash": "ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ==",
        "signed_at": "2026-05-05T00:00:00Z",
        "key_fingerprint": "deadbeefdeadbeef",
    }
    # This breaks the v2 fingerprint UNLESS we re-fingerprint. v2 scope
    # excludes signature — so the existing fingerprint stays VALID. Perfect:
    # this is the design intent.
    mod.write_text(json.dumps(data, indent=2), encoding="utf-8")

    verdict = verify_integrity(mod)
    assert verdict.fingerprint == "VALID", (
        "v2 scope excludes signature; fingerprint must remain VALID after "
        "signature mutation. This is the Gap 24 fix in action."
    )
    assert verdict.signature == "INVALID"
    assert verdict.overall == INTEGRITY_INVALID


# ── migrate_integrity ──────────────────────────────────────────────


def test_migrate_integrity_processes_all_seif_files(tmp_path):
    for i in range(3):
        _write_module(tmp_path / f"mod_{i}.seif")
    reports = migrate_integrity(tmp_path, skip_stamp=True)
    assert len(reports) == 3
    for r in reports:
        assert r.fingerprint_status == "VALID"


def test_migrate_integrity_honors_exclude_from(tmp_path):
    for i in range(3):
        _write_module(tmp_path / f"mod_{i}.seif")
    excl = tmp_path / "exclude.txt"
    excl.write_text("mod_1.seif\n", encoding="utf-8")
    reports = migrate_integrity(tmp_path, exclude_from=excl, skip_stamp=True)
    names = sorted(Path(r.file).name for r in reports)
    assert "mod_1.seif" not in names
    assert "mod_0.seif" in names and "mod_2.seif" in names


def test_migrate_integrity_records_failure_on_unparseable_file(tmp_path):
    _write_module(tmp_path / "good.seif")
    bad = tmp_path / "bad.seif"
    bad.write_text("{not valid json", encoding="utf-8")
    reports = migrate_integrity(tmp_path, skip_stamp=True)
    statuses = {Path(r.file).name: r.fingerprint_status for r in reports}
    assert statuses["good.seif"] == "VALID"
    assert "FAILED" in statuses["bad.seif"]


# ── CLI integration ───────────────────────────────────────────────


def _run_cli(workspace: Path, *args, env_extra: dict | None = None):
    env = dict(os.environ)
    env["SEIF_HOME"] = str(workspace / ".seif-home")
    src_path = str(Path(__file__).resolve().parents[1] / "src")
    env["PYTHONPATH"] = src_path + os.pathsep + env.get("PYTHONPATH", "")
    if env_extra:
        env.update(env_extra)
    return subprocess.run(
        [sys.executable, "-m", "seif.cli", *args],
        cwd=str(workspace), env=env, capture_output=True, text=True, timeout=30,
    )


def test_cli_integrity_update_then_verify_integrity_exit_codes(tmp_path):
    mod = _write_module(tmp_path / "m.seif")

    update = _run_cli(tmp_path, "--integrity-update", str(mod),
                      "--integrity-skip-sign", "--integrity-skip-stamp")
    assert update.returncode == 0, f"stderr: {update.stderr}\nstdout: {update.stdout}"
    assert "fingerprint:" in update.stdout

    # Verify with no sig/stamp present → HALF_VALID → exit non-zero.
    verify = _run_cli(tmp_path, "--verify-integrity", str(mod))
    assert verify.returncode != 0, f"expected non-zero on HALF_VALID, got {verify.returncode}"
    assert "Overall:" in verify.stdout


def test_cli_fingerprint_update_emits_warning(tmp_path):
    mod = _write_module(tmp_path / "m.seif")
    result = _run_cli(tmp_path, "--fingerprint-update", str(mod))
    # Warning goes to stderr; exit 0 because the legacy command still runs.
    assert "Run --integrity-update" in result.stderr
    assert result.returncode == 0


def test_cli_sign_all_emits_warning(tmp_path):
    # Even if signing fails (no keys), the warning fires before the operation.
    (tmp_path / ".seif").mkdir()
    _write_module(tmp_path / ".seif" / "m.seif")
    result = _run_cli(tmp_path, "--sign-all", str(tmp_path / ".seif"))
    assert "Run --integrity-update" in result.stderr


def test_cli_stamp_all_emits_warning(tmp_path):
    (tmp_path / ".seif").mkdir()
    _write_module(tmp_path / ".seif" / "m.seif")
    result = _run_cli(tmp_path, "--stamp-all", str(tmp_path / ".seif"))
    assert "Run --integrity-update" in result.stderr
