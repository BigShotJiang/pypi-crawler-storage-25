"""Tests for s43 B3 — rsync bridge rollback via atomic-swap.

Closes the s41 P6 known limitation. Previously, rsync rollback was
"not supported (no pre-update snapshot of remote)" — operator was warned
and rollback skipped. B3 replaces in-place rsync with an atomic-swap
pattern: rsync into <bridge_source>.next/, then rename old → .prev/ and
new → live. Rollback swaps .prev back.

Disk overhead is bounded: .prev is reaped on the next successful update.
A scheduled cleanup agent (3-day soak) tracks whether the .prev/ accumulation
needs further pruning — see pending module rsync-rollback-prev-soak-window.
"""

from __future__ import annotations

import json
import os
import shutil
import stat
import subprocess
import textwrap
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
SCRIPT = REPO_ROOT / "src" / "seif" / "scripts" / "host" / "seif-update.sh"


def _read_script() -> str:
    return SCRIPT.read_text()


# ── Stage 0: swap_done flag declaration ────────────────────────


def test_swap_done_flag_declared_at_stage_0():
    text = _read_script()
    assert "bridge_rsync_swap_done=0" in text, (
        "Stage 0 must initialize bridge_rsync_swap_done=0 before Stage 2 runs"
    )


# ── Stage 2: atomic-swap pattern ───────────────────────────────


def test_stage_2_rsync_uses_next_sibling_path():
    text = _read_script()
    bridge_start = text.find("# ── Stage 2: bridge")
    restart_start = text.find("# ── Stage 3:", bridge_start)
    block = text[bridge_start:restart_start]
    # bridge_next computed as <source>.next
    assert 'bridge_next="${bridge_source_path%/}.next"' in block
    # rsync target is .next, never the live <source>
    assert 'rsync -avz --delete --exclude=\'.git/\' "$bridge_upstream" "$bridge_next/"' in block


def test_stage_2_rsync_uses_prev_sibling_path():
    text = _read_script()
    bridge_start = text.find("# ── Stage 2: bridge")
    restart_start = text.find("# ── Stage 3:", bridge_start)
    block = text[bridge_start:restart_start]
    assert 'bridge_prev="${bridge_source_path%/}.prev"' in block


def test_stage_2_cleans_stale_next_before_rsync():
    text = _read_script()
    bridge_start = text.find("# ── Stage 2: bridge")
    restart_start = text.find("# ── Stage 3:", bridge_start)
    block = text[bridge_start:restart_start]
    # Must rm -rf .next BEFORE rsync (avoid leftover from interrupted prior run)
    next_clean_pos = block.find('rm -rf "$bridge_next"')
    rsync_pos = block.find("rsync -avz")
    assert 0 < next_clean_pos < rsync_pos, (
        "rm -rf .next must precede rsync invocation"
    )


def test_stage_2_swap_replaces_stale_prev():
    text = _read_script()
    bridge_start = text.find("# ── Stage 2: bridge")
    restart_start = text.find("# ── Stage 3:", bridge_start)
    block = text[bridge_start:restart_start]
    # On successful rsync: rm -rf old .prev, then mv current → .prev
    assert 'rm -rf "$bridge_prev"' in block
    assert 'mv "$bridge_source_path" "$bridge_prev"' in block


def test_stage_2_swap_makes_next_live():
    text = _read_script()
    bridge_start = text.find("# ── Stage 2: bridge")
    restart_start = text.find("# ── Stage 3:", bridge_start)
    block = text[bridge_start:restart_start]
    assert 'mv "$bridge_next" "$bridge_source_path"' in block


def test_stage_2_sets_swap_done_flag():
    text = _read_script()
    bridge_start = text.find("# ── Stage 2: bridge")
    restart_start = text.find("# ── Stage 3:", bridge_start)
    block = text[bridge_start:restart_start]
    assert "bridge_rsync_swap_done=1" in block, (
        "Successful swap must set the flag for Stage 4 to detect"
    )


def test_stage_2_rsync_failure_cleans_next_and_exits():
    text = _read_script()
    bridge_start = text.find("# ── Stage 2: bridge")
    restart_start = text.find("# ── Stage 3:", bridge_start)
    block = text[bridge_start:restart_start]
    # On rsync fail: rm -rf .next + exit 1 (live <source> untouched)
    assert "rsync failed" in block
    # Live source is preserved on rsync failure (no swap)
    assert "live state untouched" in block.lower() or "no swap" in block
    # Failure path includes exit (Stage 2 is fatal on rsync error)
    fail_branch = block[block.find("else", block.find("if rsync")):]
    assert "exit 1" in fail_branch


# ── Stage 4: rollback plan branches ────────────────────────────


def test_rollback_plan_rsync_branches_on_swap_done_and_prev():
    text = _read_script()
    plan_start = text.find("ROLLBACK PLAN")
    dispatch_start = text.find("ROLLBACK DISPATCH", plan_start)
    block = text[plan_start:dispatch_start]
    rsync_block_start = block.find("  rsync)")
    rsync_block_end = block.find("esac", rsync_block_start)
    rsync_block = block[rsync_block_start:rsync_block_end]
    # Conditional: only show swap-back when swap_done=1 AND .prev exists
    assert '[ "$bridge_rsync_swap_done" = "1" ]' in rsync_block
    assert '${bridge_source_path%/}.prev' in rsync_block
    # Both branches present
    assert "rsync rollback unavailable" in rsync_block


def test_rollback_plan_rsync_swap_back_command_shown():
    text = _read_script()
    plan_start = text.find("ROLLBACK PLAN")
    dispatch_start = text.find("ROLLBACK DISPATCH", plan_start)
    block = text[plan_start:dispatch_start]
    rsync_block_start = block.find("  rsync)")
    rsync_block_end = block.find("esac", rsync_block_start)
    rsync_block = block[rsync_block_start:rsync_block_end]
    # The swap-back commands appear in the plan output as escaped strings
    # (inside echo "..." literals).
    assert "rm -rf" in rsync_block
    assert ".prev" in rsync_block
    # Source-path reference appears in escaped form: \"$bridge_source_path\"
    assert "$bridge_source_path" in rsync_block


# ── Stage 4: rollback dispatch ─────────────────────────────────


def test_rollback_dispatch_rsync_swaps_back_when_prev_exists():
    text = _read_script()
    dispatch_start = text.find("ROLLBACK DISPATCH")
    end = text.find("# Re-restart", dispatch_start)
    block = text[dispatch_start:end]
    # New elif branch for rsync rollback
    assert 'elif [ "$bridge_method" = "rsync" ]' in block
    assert '[ "$bridge_rsync_swap_done" = "1" ]' in block
    assert '[ -d "${bridge_source_path%/}.prev" ]' in block
    # Actual rollback commands
    assert 'rm -rf "$bridge_source_path"' in block
    assert 'mv "${bridge_source_path%/}.prev" "$bridge_source_path"' in block


def test_rollback_dispatch_rsync_propagates_failure():
    text = _read_script()
    dispatch_start = text.find("ROLLBACK DISPATCH")
    end = text.find("# Re-restart", dispatch_start)
    block = text[dispatch_start:end]
    rsync_branch_start = block.find('elif [ "$bridge_method" = "rsync"')
    # Find end of this elif branch (next elif/fi at same indent)
    rsync_branch_end = block.find("\n    fi", rsync_branch_start)
    rsync_branch = block[rsync_branch_start:rsync_branch_end]
    # Both rm + mv must propagate failure
    assert rsync_branch.count("|| rollback_failed=1") >= 2, (
        "Both rm -rf and mv in rsync rollback must propagate failure"
    )


# ── Bash syntax ────────────────────────────────────────────────


def test_bash_syntax_valid_after_b3():
    result = subprocess.run(["bash", "-n", str(SCRIPT)], capture_output=True, text=True)
    assert result.returncode == 0, f"bash -n failed: {result.stderr}"


# ── End-to-end: stub rsync, verify swap behavior ───────────────


def _make_fake_rsync(bin_dir: Path, succeed: bool = True) -> None:
    """Create a fake `rsync` on PATH that copies a known marker file
    into the destination dir. Lets us verify the swap pattern e2e
    without an upstream remote."""
    rsync_stub = bin_dir / "rsync"
    rsync_stub.write_text(textwrap.dedent(f"""\
        #!/usr/bin/env bash
        # Fake rsync for B3 tests: copies a marker file into the destination.
        # Real arg form: rsync -avz --delete --exclude=... <src> <dst>
        # We just look at the last arg as destination.
        dst="${{!#}}"
        if [ "{int(succeed)}" = "0" ]; then
          echo "fake rsync: simulated failure" >&2
          exit 1
        fi
        mkdir -p "$dst"
        echo "marker:from-rsync-stub" > "$dst/marker.txt"
        exit 0
    """))
    rsync_stub.chmod(rsync_stub.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)


def _make_fake_pipx(bin_dir: Path) -> None:
    """Stub `pipx` so Stage 1 (pipx install path) is a no-op success.
    Avoids needing real pipx on the test runner."""
    pipx_stub = bin_dir / "pipx"
    pipx_stub.write_text(textwrap.dedent("""\
        #!/usr/bin/env bash
        case "$1" in
          list)    echo '{"venvs":{}}' ;;
          environment) echo "/tmp/fake-pipx-venvs" ;;
          *)       exit 0 ;;
        esac
    """))
    pipx_stub.chmod(pipx_stub.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)


def _e2e_run_seif_update(
    tmp_path: Path,
    *,
    rsync_succeeds: bool = True,
    extra_flags: list[str] | None = None,
    pre_existing_bridge: bool = True,
):
    """Set up a sandbox and run seif-update.sh through Stage 2 only.

    Uses a config that makes Stage 1 + Stage 1.5 + Stage 3 + Stage 4 all
    skip or no-op, so we can isolate Stage 2 behavior.
    """
    bin_dir = tmp_path / "bin"
    bin_dir.mkdir()
    _make_fake_rsync(bin_dir, succeed=rsync_succeeds)
    _make_fake_pipx(bin_dir)

    bridge = tmp_path / "bridge"
    if pre_existing_bridge:
        bridge.mkdir()
        (bridge / "marker.txt").write_text("marker:pre-existing")

    # Use pipx (not editable) so Stage 1 is a stubbed no-op — keeps the e2e
    # focus on Stage 2's swap pattern.
    cfg_data = {
        "protocol": "SEIF-HOST-INSTALL-CONFIG-v2",
        "host_label": "b3-rsync-host",
        "install_method": "pipx",
        "package_name": "seif-cli",
        "package_source": "pypi",
        "extra_packages": [],
        "post_install_check": "true",
        "bridge_repo": {
            "method": "rsync",
            "source_path": str(bridge),
            "upstream": "fake-upstream:/path/",
        },
        "restart_jobs": [],
    }
    seif_dir = tmp_path / ".seif"
    seif_dir.mkdir()
    (seif_dir / "host-install-config.seif").write_text(json.dumps(cfg_data))

    env = {
        **os.environ,
        "HOME": str(tmp_path),
        "PATH": f"{bin_dir}:{os.environ['PATH']}",
    }
    flags = extra_flags or ["--no-restart", "--no-template-refresh", "--auto-rollback"]
    return subprocess.run(
        ["bash", str(SCRIPT)] + flags,
        capture_output=True, text=True, env=env, timeout=30,
    ), bridge


def test_e2e_rsync_success_creates_prev_directory(tmp_path):
    """After successful rsync swap, <bridge>.prev/ must exist with the
    pre-update marker. <bridge>/ must have the new marker."""
    result, bridge = _e2e_run_seif_update(tmp_path)
    # The script may exit non-zero due to other unrelated stages — we just
    # verify Stage 2's swap effects on the filesystem.
    prev = Path(str(bridge) + ".prev")
    nxt = Path(str(bridge) + ".next")
    assert prev.is_dir(), f"<bridge>.prev should exist after swap; output:\n{result.stdout}\n{result.stderr}"
    assert (prev / "marker.txt").read_text() == "marker:pre-existing"
    assert bridge.is_dir(), "<bridge> must be present (the new live version)"
    assert (bridge / "marker.txt").read_text().strip() == "marker:from-rsync-stub"
    assert not nxt.exists(), "<bridge>.next must be cleaned up after swap"


def test_e2e_rsync_failure_preserves_live_bridge(tmp_path):
    """If rsync fails, the live <bridge>/ must be untouched and .next cleaned."""
    result, bridge = _e2e_run_seif_update(tmp_path, rsync_succeeds=False)
    prev = Path(str(bridge) + ".prev")
    nxt = Path(str(bridge) + ".next")
    # Live untouched
    assert bridge.is_dir()
    assert (bridge / "marker.txt").read_text() == "marker:pre-existing"
    # No swap happened → no fresh .prev created from THIS run
    # (a stale prev might exist from older runs but tmp_path is clean)
    assert not prev.exists() or not (prev / "marker.txt").exists()
    # .next cleaned up
    assert not nxt.exists(), "<bridge>.next must be cleaned up on rsync failure"


def test_e2e_rsync_replaces_stale_prev(tmp_path):
    """Successful rsync must replace any pre-existing .prev (no accumulation
    beyond N=1 prior version)."""
    bridge = tmp_path / "bridge"
    bridge.mkdir()
    (bridge / "marker.txt").write_text("marker:current")

    # Pre-existing stale .prev from a "previous" update
    stale_prev = Path(str(bridge) + ".prev")
    stale_prev.mkdir()
    (stale_prev / "marker.txt").write_text("marker:STALE-from-old-update")
    (stale_prev / "stale-extra-file").write_text("should be gone after swap")

    bin_dir = tmp_path / "bin"
    bin_dir.mkdir()
    _make_fake_rsync(bin_dir)
    _make_fake_pipx(bin_dir)

    cfg_data = {
        "protocol": "SEIF-HOST-INSTALL-CONFIG-v2",
        "host_label": "b3-stale-prev-host",
        "install_method": "pipx",
        "package_name": "seif-cli",
        "package_source": "pypi",
        "extra_packages": [],
        "post_install_check": "true",
        "bridge_repo": {
            "method": "rsync",
            "source_path": str(bridge),
            "upstream": "fake:/path/",
        },
        "restart_jobs": [],
    }
    seif_dir = tmp_path / ".seif"
    seif_dir.mkdir()
    (seif_dir / "host-install-config.seif").write_text(json.dumps(cfg_data))

    env = {
        **os.environ,
        "HOME": str(tmp_path),
        "PATH": f"{bin_dir}:{os.environ['PATH']}",
    }
    subprocess.run(
        ["bash", str(SCRIPT), "--no-restart", "--no-template-refresh", "--auto-rollback"],
        capture_output=True, text=True, env=env, timeout=30,
    )
    # New .prev must be the prior live (marker:current), not the stale one
    assert (stale_prev / "marker.txt").read_text() == "marker:current"
    # Stale extra file from the OLD prev must be gone
    assert not (stale_prev / "stale-extra-file").exists(), (
        "stale .prev contents must be replaced, not merged"
    )
