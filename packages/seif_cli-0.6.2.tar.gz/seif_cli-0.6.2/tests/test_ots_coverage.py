"""Tests for OTS-coverage detection in session-start signal (s44 PR #1)."""
from __future__ import annotations

import io
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from seif.cli.wrapper import check_ots_coverage, _signal_ots_coverage  # noqa: E402


class CheckOtsCoverageTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.seif_dir = Path(self.tmp.name)
        (self.seif_dir / "cycles").mkdir()
        (self.seif_dir / "sessions").mkdir()

    def tearDown(self):
        self.tmp.cleanup()

    def _touch(self, path: Path) -> Path:
        path.write_text("{}", encoding="utf-8")
        return path

    def test_empty_dirs_total_zero(self):
        cov = check_ots_coverage(self.seif_dir)
        self.assertEqual(cov, {"stamped": 0, "missing": [], "total": 0})

    def test_missing_seif_dir_returns_zero_total(self):
        cov = check_ots_coverage(self.seif_dir / "does-not-exist")
        self.assertEqual(cov["total"], 0)

    def test_only_sealed_cycles_counted(self):
        sealed = self._touch(self.seif_dir / "cycles" / "s43-foo-SEALED.seif")
        # Non-sealed cycle file must be ignored.
        self._touch(self.seif_dir / "cycles" / "s43-foo-OPEN.seif")
        cov = check_ots_coverage(self.seif_dir)
        self.assertEqual(cov["total"], 1)
        self.assertEqual(cov["missing"], [sealed])

    def test_only_closure_sessions_counted(self):
        closure = self._touch(self.seif_dir / "sessions" / "session-43-closure.seif")
        # Open session file (not -closure) must be ignored.
        self._touch(self.seif_dir / "sessions" / "session-44-open.seif")
        cov = check_ots_coverage(self.seif_dir)
        self.assertEqual(cov["total"], 1)
        self.assertEqual(cov["missing"], [closure])

    def test_ots_sibling_marks_stamped(self):
        sealed = self._touch(self.seif_dir / "cycles" / "s43-bar-SEALED.seif")
        self._touch(sealed.with_suffix(sealed.suffix + ".ots"))
        cov = check_ots_coverage(self.seif_dir)
        self.assertEqual(cov, {"stamped": 1, "missing": [], "total": 1})

    def test_mixed_stamped_and_missing(self):
        a = self._touch(self.seif_dir / "cycles" / "s41-SEALED.seif")
        self._touch(a.with_suffix(a.suffix + ".ots"))
        b = self._touch(self.seif_dir / "cycles" / "s43-SEALED.seif")
        c = self._touch(self.seif_dir / "sessions" / "session-43-closure.seif")
        self._touch(c.with_suffix(c.suffix + ".ots"))
        d = self._touch(self.seif_dir / "sessions" / "session-44-closure.seif")
        cov = check_ots_coverage(self.seif_dir)
        self.assertEqual(cov["stamped"], 2)
        self.assertEqual(set(cov["missing"]), {b, d})
        self.assertEqual(cov["total"], 4)


class SignalOtsCoverageOutputTests(unittest.TestCase):
    """Stderr surface format — must be one line, A8-honest, action-suggesting."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.seif_dir = Path(self.tmp.name)
        (self.seif_dir / "cycles").mkdir()
        (self.seif_dir / "sessions").mkdir()

    def tearDown(self):
        self.tmp.cleanup()

    def _capture(self) -> str:
        buf = io.StringIO()
        with patch("sys.stderr", buf):
            _signal_ots_coverage(self.seif_dir)
        return buf.getvalue()

    def test_silent_when_no_sealed_artifacts(self):
        self.assertEqual(self._capture(), "")

    def test_full_coverage_clean_message(self):
        f = self.seif_dir / "cycles" / "s43-SEALED.seif"
        f.write_text("{}", encoding="utf-8")
        f.with_suffix(f.suffix + ".ots").write_text("x", encoding="utf-8")
        out = self._capture()
        self.assertIn("OTS: ✓1/1 sealed artifacts stamped", out)
        self.assertNotIn("✗", out)

    def test_partial_coverage_lists_missing_and_suggests_action(self):
        a = self.seif_dir / "cycles" / "s41-SEALED.seif"
        a.write_text("{}", encoding="utf-8")
        a.with_suffix(a.suffix + ".ots").write_text("x", encoding="utf-8")
        b = self.seif_dir / "cycles" / "s43-SEALED.seif"
        b.write_text("{}", encoding="utf-8")
        out = self._capture()
        self.assertIn("✓1/2", out)
        self.assertIn("✗1", out)
        self.assertIn("s43-SEALED.seif", out)
        self.assertIn("seif --stamp", out)

    def test_truncates_missing_list_when_more_than_three(self):
        for i in range(5):
            f = self.seif_dir / "cycles" / f"s{40 + i}-SEALED.seif"
            f.write_text("{}", encoding="utf-8")
        out = self._capture()
        self.assertIn("✗5", out)
        self.assertIn("+2 more", out)


if __name__ == "__main__":
    unittest.main()
