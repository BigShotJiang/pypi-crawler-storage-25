"""Tests for s41 P2+P4+P5 schema-bump trio in seif-update.sh.

Schema v2 adds three optional fields:
  - package_source: 'pypi' (default) | 'git+<url>'  → P2
  - bridge_repo: { method, source_path, upstream }  → P4
  - restart_jobs: [pattern...]                      → P5

These tests verify the script parses each field, dispatches the right action,
and falls back to v1 behavior when fields are absent (permissive v2).
"""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
HOST_DIR = REPO_ROOT / "src" / "seif" / "scripts" / "host"
SCRIPT = HOST_DIR / "seif-update.sh"
SAMPLE = HOST_DIR / "host-install-config.sample.seif"


def _read_script() -> str:
    return SCRIPT.read_text()


# ── P2: pipx --force for git source ─────────────────────────────


def test_p2_parses_package_source():
    text = _read_script()
    assert 'package_source=' in text
    # default → 'pypi' (escaped in shell heredoc)
    assert '"package_source",\\"pypi\\"' in text or '"package_source", "pypi"' in text or 'get(\\"package_source\\",\\"pypi\\"' in text


def test_p2_pipx_force_for_git_source():
    text = _read_script()
    assert "pipx install --force" in text
    assert "git+*" in text, "pipx branch must dispatch on git+ prefix"
    assert "version-equality" in text, "must explain why force is needed"


def test_p2_keeps_upgrade_path_for_pypi():
    text = _read_script()
    assert "pipx upgrade" in text


def test_p2_rejects_unknown_package_source():
    text = _read_script()
    pipx_block_start = text.find('  pipx)')
    bridge_stage_start = text.find("# ── Stage 2: bridge", pipx_block_start)
    block = text[pipx_block_start:bridge_stage_start]
    assert "Unknown package_source" in block


# ── P4: bridge repo sync ────────────────────────────────────────


def test_p4_parses_bridge_fields():
    text = _read_script()
    assert "bridge_method=" in text
    assert "bridge_source_path=" in text
    assert "bridge_upstream=" in text


def test_p4_dispatches_three_bridge_methods():
    text = _read_script()
    bridge_start = text.find("# ── Stage 2: bridge")
    restart_start = text.find("# ── Stage 3:", bridge_start)
    block = text[bridge_start:restart_start]
    assert "none|" in block, "method=none must skip cleanly"
    assert "git)" in block
    assert "git -C" in block and "pull --ff-only" in block
    assert "rsync)" in block
    assert "rsync -avz" in block


def test_p4_rejects_unknown_bridge_method():
    text = _read_script()
    bridge_start = text.find("# ── Stage 2: bridge")
    restart_start = text.find("# ── Stage 3:", bridge_start)
    block = text[bridge_start:restart_start]
    assert "Unknown bridge_repo.method" in block


def test_p4_validates_required_fields():
    text = _read_script()
    bridge_start = text.find("# ── Stage 2: bridge")
    restart_start = text.find("# ── Stage 3:", bridge_start)
    block = text[bridge_start:restart_start]
    assert "source_path not set" in block
    assert "upstream not set" in block


# ── P5: restart launchd/systemd daemons ─────────────────────────


def test_p5_parses_restart_jobs_with_default():
    text = _read_script()
    assert "restart_jobs=" in text
    assert "'com.seif.*'" in text  # default in python literal


def test_p5_no_restart_flag_supported():
    text = _read_script()
    assert "--no-restart" in text
    assert "RESTART=0" in text


def test_p5_dispatches_launchctl_and_systemctl():
    text = _read_script()
    restart_start = text.find("# ── Stage 3:")
    post_check_start = text.find("POST-INSTALL CHECK", restart_start)
    block = text[restart_start:post_check_start]
    assert "launchctl kickstart -k" in block
    assert "systemctl --user restart" in block


def test_p5_no_restart_prints_manual_hint():
    text = _read_script()
    restart_start = text.find("# ── Stage 3:")
    post_check_start = text.find("POST-INSTALL CHECK", restart_start)
    block = text[restart_start:post_check_start]
    assert "Manual restart hint" in block


# ── Integration: schema v1 still works (permissive v2) ──────────


def test_v1_config_without_new_fields_is_accepted(tmp_path, monkeypatch):
    """A schema-v1 config (no package_source / bridge_repo / restart_jobs)
    must not crash the script — defaults preserve current behavior."""
    cfg = tmp_path / "host-install-config.seif"
    cfg.write_text(
        json.dumps({
            "protocol": "SEIF-HOST-INSTALL-CONFIG-v1",
            "host_label": "v1-host",
            "install_method": "editable",
            "package_name": "seif-cli",
            "source_repo": str(tmp_path / "src"),
            "source_branch": "main",
            "extra_packages": [],
            "post_install_check": "true",
        })
    )
    seif_dir = tmp_path / ".seif"
    seif_dir.mkdir()
    (seif_dir / "host-install-config.seif").write_text(cfg.read_text())

    result = subprocess.run(
        ["bash", str(SCRIPT), "--check"],
        capture_output=True,
        text=True,
        env={**os.environ, "HOME": str(tmp_path)},
        timeout=10,
    )
    assert result.returncode == 0, (
        f"v1 config should pass --check\nstdout={result.stdout}\nstderr={result.stderr}"
    )
    assert "v1-host" in result.stdout
    # Defaults must surface in the header
    assert "source: pypi" in result.stdout
    assert "bridge:  none" in result.stdout


def test_v2_config_full_check_dispatch(tmp_path):
    """Full v2 config with all new fields populated parses + dry-runs cleanly."""
    cfg_data = {
        "protocol": "SEIF-HOST-INSTALL-CONFIG-v2",
        "host_label": "v2-host",
        "install_method": "pipx",
        "package_name": "seif-cli",
        "package_source": "git+https://github.com/and2carvalho/seif.git@main",
        "extra_packages": [],
        "post_install_check": "true",
        "bridge_repo": {
            "method": "rsync",
            "source_path": "/tmp/test-bridge",
            "upstream": "user@mini:/path/to/bridge/",
        },
        "restart_jobs": ["com.seif.test.*"],
    }
    seif_dir = tmp_path / ".seif"
    seif_dir.mkdir()
    (seif_dir / "host-install-config.seif").write_text(json.dumps(cfg_data))

    result = subprocess.run(
        ["bash", str(SCRIPT), "--check"],
        capture_output=True,
        text=True,
        env={**os.environ, "HOME": str(tmp_path)},
        timeout=10,
    )
    assert result.returncode == 0, result.stderr
    out = result.stdout
    assert "v2-host" in out
    assert "git+https://github.com/and2carvalho/seif.git@main" in out
    assert "bridge:  rsync" in out
    assert "com.seif.test.*" in out


def test_no_restart_flag_disables_restart_in_check(tmp_path):
    """`--no-restart` must surface in the header so operators can confirm
    intent before running."""
    cfg_data = {
        "protocol": "SEIF-HOST-INSTALL-CONFIG-v2",
        "host_label": "no-restart-host",
        "install_method": "editable",
        "package_name": "seif-cli",
        "source_repo": str(tmp_path / "src"),
        "source_branch": "main",
        "extra_packages": [],
        "post_install_check": "true",
    }
    seif_dir = tmp_path / ".seif"
    seif_dir.mkdir()
    (seif_dir / "host-install-config.seif").write_text(json.dumps(cfg_data))

    result = subprocess.run(
        ["bash", str(SCRIPT), "--no-restart", "--check"],
        capture_output=True,
        text=True,
        env={**os.environ, "HOME": str(tmp_path)},
        timeout=10,
    )
    assert result.returncode == 0, result.stderr
    assert "restart: no (--no-restart)" in result.stdout


# ── Sample config sanity ────────────────────────────────────────


def test_sample_config_is_valid_json():
    """The shipped sample must parse — operators copy from it."""
    SAMPLE.exists() or (_ for _ in ()).throw(
        FileNotFoundError(f"sample missing: {SAMPLE}")
    )
    data = json.loads(SAMPLE.read_text())
    assert data["protocol"] == "SEIF-HOST-INSTALL-CONFIG-v2"
    assert "package_source" in data
    assert "bridge_repo" in data
    assert "restart_jobs" in data


def test_sample_config_documents_v2_fields_via_underscore_keys():
    """Sample uses _underscored keys to inline-document each v2 field."""
    data = json.loads(SAMPLE.read_text())
    assert any(k.startswith("_") and "v2" in k.lower() for k in data.keys())


# ── Bash syntax ─────────────────────────────────────────────────


def test_bash_syntax_valid():
    result = subprocess.run(
        ["bash", "-n", str(SCRIPT)],
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, f"bash -n failed: {result.stderr}"
