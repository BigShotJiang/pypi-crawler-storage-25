"""Tests for s43 rsync-soak-inspect.sh — soak-window validation script.

Standalone inspector run on rsync bridge hosts after the s43 B3 atomic-swap
deployment. Pure read-only inspection: never mutates state.
"""

from __future__ import annotations

import json
import os
import subprocess
import time
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
SCRIPT = REPO_ROOT / "src" / "seif" / "scripts" / "host" / "rsync-soak-inspect.sh"


def _write_cfg(home: Path, bridge_method: str, bridge_path: str = "") -> None:
    cfg = {
        "protocol": "SEIF-HOST-INSTALL-CONFIG-v2",
        "host_label": "test-soak-host",
        "install_method": "pipx",
        "package_name": "seif-cli",
    }
    if bridge_method == "rsync":
        cfg["bridge_repo"] = {
            "method": "rsync",
            "source_path": bridge_path,
            "upstream": "fake@host:/path/",
        }
    elif bridge_method == "git":
        cfg["bridge_repo"] = {"method": "git", "source_path": bridge_path}
    else:
        cfg["bridge_repo"] = {"method": "none"}
    seif_dir = home / ".seif"
    seif_dir.mkdir(exist_ok=True)
    (seif_dir / "host-install-config.seif").write_text(json.dumps(cfg))


def _run(home: Path) -> subprocess.CompletedProcess:
    return subprocess.run(
        ["bash", str(SCRIPT)],
        capture_output=True, text=True,
        env={**os.environ, "HOME": str(home)},
        timeout=10,
    )


# ── Static structure ──────────────────────────────────────────


def test_script_exists_and_executable():
    assert SCRIPT.is_file()
    assert os.access(SCRIPT, os.X_OK), "rsync-soak-inspect.sh must be executable"


def test_script_documents_three_exit_codes():
    text = SCRIPT.read_text()
    assert "Exit codes:" in text
    assert "0 — clean" in text
    assert "1 — issues" in text
    assert "2 — host not configured" in text


# ── Skip cases (exit 2) ───────────────────────────────────────


def test_no_config_exits_2(tmp_path):
    result = _run(tmp_path)
    assert result.returncode == 2
    assert "no host-install-config.seif" in result.stdout


def test_non_rsync_host_exits_2(tmp_path):
    _write_cfg(tmp_path, "git", str(tmp_path / "bridge"))
    result = _run(tmp_path)
    assert result.returncode == 2
    assert "not rsync" in result.stdout or "soak inspection N/A" in result.stdout


def test_none_bridge_method_exits_2(tmp_path):
    _write_cfg(tmp_path, "none")
    result = _run(tmp_path)
    assert result.returncode == 2


# ── Clean state (exit 0) ──────────────────────────────────────


def test_clean_no_prev_no_next_exits_0(tmp_path):
    """Fresh rsync host, no updates run yet — no .prev, no .next, no rollbacks."""
    bridge = tmp_path / "bridge"
    bridge.mkdir()
    _write_cfg(tmp_path, "rsync", str(bridge))
    result = _run(tmp_path)
    assert result.returncode == 0, f"stdout:\n{result.stdout}\nstderr:\n{result.stderr}"
    assert "CLEAN" in result.stdout
    assert "LANDED" in result.stdout


def test_clean_with_prev_exits_0(tmp_path):
    """Normal post-update state: live bridge + one .prev (older mtime)."""
    bridge = tmp_path / "bridge"
    prev = tmp_path / "bridge.prev"
    bridge.mkdir()
    prev.mkdir()
    # Make .prev older than live bridge (correct swap order)
    old_t = time.time() - 3600
    os.utime(prev, (old_t, old_t))
    _write_cfg(tmp_path, "rsync", str(bridge))
    result = _run(tmp_path)
    assert result.returncode == 0, result.stdout
    assert ".prev: present" in result.stdout
    assert ".next: absent" in result.stdout


# ── Issues (exit 1) ───────────────────────────────────────────


def test_leftover_next_directory_exits_1(tmp_path):
    """A .next/ leftover means an update was interrupted mid-swap."""
    bridge = tmp_path / "bridge"
    nxt = tmp_path / "bridge.next"
    bridge.mkdir()
    nxt.mkdir()
    _write_cfg(tmp_path, "rsync", str(bridge))
    result = _run(tmp_path)
    assert result.returncode == 1, result.stdout
    assert "ISSUE" in result.stdout
    assert "exists between updates" in result.stdout
    assert "HARDEN" in result.stdout


def test_prev_newer_than_live_exits_1(tmp_path):
    """If .prev mtime > live mtime, swap order may be broken."""
    bridge = tmp_path / "bridge"
    prev = tmp_path / "bridge.prev"
    bridge.mkdir()
    prev.mkdir()
    # Backwards: live is older than prev (broken swap order)
    old_t = time.time() - 3600
    os.utime(bridge, (old_t, old_t))
    _write_cfg(tmp_path, "rsync", str(bridge))
    result = _run(tmp_path)
    assert result.returncode == 1, result.stdout
    assert "swap order" in result.stdout


def test_empty_source_path_exits_1(tmp_path):
    """Misconfigured: rsync method but empty source_path."""
    _write_cfg(tmp_path, "rsync", "")
    result = _run(tmp_path)
    assert result.returncode == 1
    assert "config broken" in result.stdout or "source_path empty" in result.stdout


# ── Rollback signals (exit 1, "VALIDATED") ────────────────────


def test_bus_metrics_rsync_rollback_counter_triggers_validated(tmp_path):
    bridge = tmp_path / "bridge"
    prev = tmp_path / "bridge.prev"
    bridge.mkdir()
    prev.mkdir()
    old_t = time.time() - 3600
    os.utime(prev, (old_t, old_t))
    _write_cfg(tmp_path, "rsync", str(bridge))
    # Inject a counter
    metrics = tmp_path / ".seif" / "bus_metrics.json"
    metrics.write_text(json.dumps({"rsync_bridge_rollback_count": 2}))
    result = _run(tmp_path)
    assert result.returncode == 1, result.stdout
    assert "VALIDATED" in result.stdout or "ROLLBACKS OBSERVED" in result.stdout


# ── pyproject package_data declaration ───────────────────────


def test_pyproject_includes_inspect_script_in_package_data():
    pyproject = (REPO_ROOT / "pyproject.toml").read_text()
    assert '"scripts/host/rsync-soak-inspect.sh"' in pyproject, (
        "pyproject.toml must include rsync-soak-inspect.sh in package_data"
    )
