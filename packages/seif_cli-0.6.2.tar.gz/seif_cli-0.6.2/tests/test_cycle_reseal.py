"""Tests for s59 PR5 — cycle_reseal (codified amendment-chain re-seal).

Acceptance criteria (binding, per SEED-s59 PR5 scope):
  - re_seal_history[] is APPEND-ONLY. Prior entries MUST survive untouched
    across multiple re_seal calls. test_history_is_append_only_no_mutation
    is the binding regression for that contract.
  - Legacy s52-style flat re_sealed_at + re_seal_rationale fields MUST be
    migrated into a synthesized first history entry on the FIRST re-seal
    (so no historical context is lost).
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from seif.plugins.core.cycle_reseal import re_seal_cycle


@pytest.fixture
def workspace(tmp_path):
    ws = tmp_path / "workspace"
    (ws / ".seif" / "cycles").mkdir(parents=True)
    return ws


def _write_sealed(workspace: Path, slug: str, **fields) -> Path:
    path = workspace / ".seif" / "cycles" / f"{slug}-SEALED.seif"
    payload = {
        "cycle_id": slug,
        "status": "SEALED",
        **fields,
    }
    path.write_text(json.dumps(payload, indent=2))
    return path


def _write_open(workspace: Path, slug: str, **fields) -> Path:
    path = workspace / ".seif" / "cycles" / f"{slug}-OPEN.seif"
    payload = {
        "cycle_id": slug,
        "status": "OPEN",
        **fields,
    }
    path.write_text(json.dumps(payload, indent=2))
    return path


def test_re_seal_appends_to_empty_history(workspace):
    sealed_path = _write_sealed(workspace, "fresh")
    result = re_seal_cycle(
        "fresh",
        rationale="add forgotten PR #42",
        deltas=["PR #42 packaging fix"],
        workspace=workspace,
    )
    assert result["status"] == "resealed"
    assert result["history_length"] == 1

    sealed = json.loads(sealed_path.read_text())
    history = sealed["re_seal_history"]
    assert len(history) == 1
    assert history[0]["re_seal_rationale"] == "add forgotten PR #42"
    assert history[0]["deltas"] == ["PR #42 packaging fix"]
    assert "re_sealed_at" in history[0]
    assert "re_sealed_by" in history[0]


def test_re_seal_appends_to_existing_history(workspace):
    """Multiple re-seals append; do not replace."""
    _write_sealed(workspace, "incremental")
    re_seal_cycle("incremental", rationale="first amendment",
                  deltas=["d1"], workspace=workspace)
    re_seal_cycle("incremental", rationale="second amendment",
                  deltas=["d2", "d3"], workspace=workspace)
    result = re_seal_cycle("incremental", rationale="third amendment",
                           deltas=[], workspace=workspace)

    assert result["history_length"] == 3
    sealed = json.loads(
        (workspace / ".seif" / "cycles" / "incremental-SEALED.seif").read_text()
    )
    rationales = [e["re_seal_rationale"] for e in sealed["re_seal_history"]]
    assert rationales == ["first amendment", "second amendment", "third amendment"]


def test_history_is_append_only_no_mutation(workspace):
    """BINDING: prior entries must NEVER be mutated by subsequent re-seals."""
    _write_sealed(workspace, "audit-trail")
    re_seal_cycle("audit-trail", rationale="initial",
                  deltas=["alpha"], workspace=workspace)

    sealed_path = workspace / ".seif" / "cycles" / "audit-trail-SEALED.seif"
    snapshot_first = json.loads(sealed_path.read_text())["re_seal_history"][0]

    re_seal_cycle("audit-trail", rationale="follow-up",
                  deltas=["beta"], workspace=workspace)
    re_seal_cycle("audit-trail", rationale="another",
                  deltas=["gamma"], workspace=workspace)

    sealed = json.loads(sealed_path.read_text())
    assert sealed["re_seal_history"][0] == snapshot_first, (
        "first history entry must survive byte-for-byte across subsequent re-seals"
    )


def test_re_seal_migrates_legacy_flat_fields_into_history(workspace):
    """s52-style flat re_sealed_at + re_seal_rationale fields must be
    migrated into a synthesized first history entry on the FIRST re-seal."""
    sealed_path = _write_sealed(
        workspace, "legacy-s52",
        re_sealed_at="2026-05-03T23:10:00Z",
        re_seal_rationale="Initial seal premature; PRs landed after.",
    )

    result = re_seal_cycle("legacy-s52", rationale="post-PR5 amendment",
                           deltas=["fix"], workspace=workspace)
    assert result["history_length"] == 2  # migrated legacy + new entry

    sealed = json.loads(sealed_path.read_text())
    history = sealed["re_seal_history"]
    legacy = history[0]
    assert legacy["re_sealed_at"] == "2026-05-03T23:10:00Z"
    assert "premature" in legacy["re_seal_rationale"]
    assert legacy["_migrated_from_legacy_flat_fields"] is True

    # The legacy flat fields are not removed (read-only by old path is fine);
    # new readers consume re_seal_history.
    assert sealed["re_sealed_at"] == "2026-05-03T23:10:00Z"


def test_re_seal_does_not_remigrate_when_history_already_present(workspace):
    """Legacy flat fields must only migrate ONCE — subsequent re-seals must
    NOT re-add them as a second migration entry."""
    _write_sealed(
        workspace, "legacy-once",
        re_sealed_at="2026-05-03T23:10:00Z",
        re_seal_rationale="legacy",
    )
    re_seal_cycle("legacy-once", rationale="first",
                  deltas=[], workspace=workspace)
    re_seal_cycle("legacy-once", rationale="second",
                  deltas=[], workspace=workspace)

    sealed = json.loads(
        (workspace / ".seif" / "cycles" / "legacy-once-SEALED.seif").read_text()
    )
    migrated = [e for e in sealed["re_seal_history"]
                if e.get("_migrated_from_legacy_flat_fields")]
    assert len(migrated) == 1, "legacy fields must be migrated exactly once"


def test_re_seal_refuses_non_existent_cycle(workspace):
    result = re_seal_cycle("ghost", rationale="x",
                           deltas=[], workspace=workspace)
    assert result["status"] == "error"
    assert "No SEALED cycle" in result["message"]


def test_re_seal_refuses_open_cycle(workspace):
    """Re-seal targets only already-SEALED cycles. OPEN must be sealed first
    (subject to the s59 PR4 seal-guard)."""
    _write_open(workspace, "still-open")
    result = re_seal_cycle("still-open", rationale="x",
                           deltas=[], workspace=workspace)
    assert result["status"] == "error"
    assert "OPEN, not SEALED" in result["message"]
    assert "--close-cycle" in result["message"]


def test_re_seal_requires_non_empty_rationale(workspace):
    _write_sealed(workspace, "needs-why")
    result = re_seal_cycle("needs-why", rationale="   ",
                           deltas=[], workspace=workspace)
    assert result["status"] == "error"
    assert "rationale" in result["message"]


def test_re_seal_requires_string_slug(workspace):
    result = re_seal_cycle("", rationale="x",
                           deltas=[], workspace=workspace)
    assert result["status"] == "error"


def test_re_seal_with_delta_list_json_literal(workspace):
    _write_sealed(workspace, "json-deltas")
    result = re_seal_cycle("json-deltas", rationale="batch",
                           deltas='["PR #100", "PR #101", "PR #102"]',
                           workspace=workspace)
    assert result["status"] == "resealed"
    assert result["entry"]["deltas"] == ["PR #100", "PR #101", "PR #102"]


def test_re_seal_with_delta_list_file(workspace, tmp_path):
    _write_sealed(workspace, "file-deltas")
    delta_file = tmp_path / "deltas.json"
    delta_file.write_text(json.dumps(["change-1", "change-2"]))
    result = re_seal_cycle("file-deltas", rationale="from file",
                           deltas=str(delta_file), workspace=workspace)
    assert result["status"] == "resealed"
    assert result["entry"]["deltas"] == ["change-1", "change-2"]


def test_re_seal_with_delta_list_invalid_json_returns_error(workspace):
    _write_sealed(workspace, "bad-json")
    result = re_seal_cycle("bad-json", rationale="x",
                           deltas="[broken",
                           workspace=workspace)
    assert result["status"] == "error"
    assert "JSON" in result["message"]


def test_re_seal_with_delta_list_non_list_json_returns_error(workspace):
    _write_sealed(workspace, "not-a-list")
    result = re_seal_cycle("not-a-list", rationale="x",
                           deltas='{"not": "a list"}',
                           workspace=workspace)
    assert result["status"] == "error"
    assert "list" in result["message"].lower()


def test_re_seal_refuses_when_history_field_is_not_a_list(workspace):
    """Defensive: if re_seal_history exists but is not a list (corruption),
    refuse rather than clobber."""
    _write_sealed(workspace, "corrupt", re_seal_history={"not": "a list"})
    result = re_seal_cycle("corrupt", rationale="x",
                           deltas=[], workspace=workspace)
    assert result["status"] == "error"
    assert "non-list" in result["message"]


def test_re_seal_with_explicit_actor(workspace):
    _write_sealed(workspace, "with-actor")
    result = re_seal_cycle("with-actor", rationale="explicit actor",
                           deltas=[], actor="claude-opus-4-7 @ Mini",
                           workspace=workspace)
    assert result["status"] == "resealed"
    assert result["entry"]["re_sealed_by"] == "claude-opus-4-7 @ Mini"


def test_re_seal_does_not_mutate_unrelated_fields(workspace):
    """The original SEALED body (vision, sealed_at, integrity_hash, etc.)
    must survive re-seal untouched. Only re_seal_history changes."""
    sealed_path = _write_sealed(
        workspace, "preserve-body",
        vision="original vision text",
        sealed_at="2026-05-04T22:00:00Z",
        integrity_hash="abc123",
        arc_summary="full arc here",
    )
    before = json.loads(sealed_path.read_text())

    re_seal_cycle("preserve-body", rationale="amend",
                  deltas=["x"], workspace=workspace)

    after = json.loads(sealed_path.read_text())
    for key in ("cycle_id", "status", "vision", "sealed_at",
                "integrity_hash", "arc_summary"):
        assert after[key] == before[key], (
            f"re-seal must not mutate field '{key}'"
        )
