"""Tests for next_session_count — root fix for the SessionStart counter bug.

Regression: session-start read mapper.session_count + 1 without consulting
existing session files. If session-end failed to fire (abrupt close, /clear,
crash), mapper stayed stale and the next start clobbered an existing
session-N.json. The fix: scan sessions/ for observed session_number values
in both .json contracts and -closure.seif modules, and return
max(stored, max(observed)) + 1.
"""

from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from seif.plugins.core.session_lifecycle import next_session_count


def _write_mapper(seif_dir: Path, session_count: int) -> None:
    seif_dir.mkdir(parents=True, exist_ok=True)
    (seif_dir / "mapper.json").write_text(
        json.dumps({"protocol": "SEIF-MAPPER-v1", "session_count": session_count})
    )


def _write_session_json(seif_dir: Path, n: int) -> None:
    sd = seif_dir / "sessions"
    sd.mkdir(parents=True, exist_ok=True)
    (sd / f"session-{n}.json").write_text(json.dumps({"session_number": n, "status": "CLOSED"}))


def _write_closure(seif_dir: Path, n: int) -> None:
    sd = seif_dir / "sessions"
    sd.mkdir(parents=True, exist_ok=True)
    (sd / f"session-{n}-closure.seif").write_text(
        json.dumps({"protocol": "SEIF-MODULE-v2", "session_number": n})
    )


class NextSessionCountTests(unittest.TestCase):

    def test_no_mapper_returns_zero(self):
        with tempfile.TemporaryDirectory() as td:
            seif_dir = Path(td) / ".seif"
            seif_dir.mkdir()
            self.assertEqual(next_session_count(seif_dir), 0)

    def test_stored_only_increments_by_one(self):
        with tempfile.TemporaryDirectory() as td:
            seif_dir = Path(td) / ".seif"
            _write_mapper(seif_dir, 5)
            self.assertEqual(next_session_count(seif_dir), 6)

    def test_observed_higher_than_stored_wins(self):
        with tempfile.TemporaryDirectory() as td:
            seif_dir = Path(td) / ".seif"
            _write_mapper(seif_dir, 34)
            for n in (35, 36, 37):
                _write_session_json(seif_dir, n)
            self.assertEqual(next_session_count(seif_dir), 38)

    def test_stored_higher_than_observed_wins(self):
        with tempfile.TemporaryDirectory() as td:
            seif_dir = Path(td) / ".seif"
            _write_mapper(seif_dir, 10)
            _write_session_json(seif_dir, 5)
            self.assertEqual(next_session_count(seif_dir), 11)

    def test_closure_seif_files_counted(self):
        with tempfile.TemporaryDirectory() as td:
            seif_dir = Path(td) / ".seif"
            _write_mapper(seif_dir, 0)
            _write_closure(seif_dir, 12)
            self.assertEqual(next_session_count(seif_dir), 13)

    def test_mixed_json_and_closure_takes_max(self):
        with tempfile.TemporaryDirectory() as td:
            seif_dir = Path(td) / ".seif"
            _write_mapper(seif_dir, 0)
            _write_session_json(seif_dir, 7)
            _write_closure(seif_dir, 9)
            self.assertEqual(next_session_count(seif_dir), 10)

    def test_corrupt_mapper_falls_back_to_observed(self):
        with tempfile.TemporaryDirectory() as td:
            seif_dir = Path(td) / ".seif"
            seif_dir.mkdir(parents=True)
            (seif_dir / "mapper.json").write_text("not-json{{{")
            _write_session_json(seif_dir, 4)
            self.assertEqual(next_session_count(seif_dir), 5)

    def test_corrupt_session_file_skipped(self):
        with tempfile.TemporaryDirectory() as td:
            seif_dir = Path(td) / ".seif"
            _write_mapper(seif_dir, 2)
            _write_session_json(seif_dir, 5)
            (seif_dir / "sessions" / "session-bad.json").write_text("not-json")
            self.assertEqual(next_session_count(seif_dir), 6)

    def test_session_dir_missing_uses_stored(self):
        with tempfile.TemporaryDirectory() as td:
            seif_dir = Path(td) / ".seif"
            _write_mapper(seif_dir, 3)
            self.assertEqual(next_session_count(seif_dir), 4)


class ClaimOrphanSessionSlotTests(unittest.TestCase):
    """F6 — bash hook falls back to session_id='unknown' on JSON parse race.

    The combination of unconditional advance + retry produces orphan slots
    bound to 'unknown' with the next real session attached one slot ahead.
    claim_orphan_session_slot() lets a real-id caller reclaim a fresh
    orphan instead of advancing past it.
    """

    def _write_session(self, seif_dir, n, session_id):
        sd = seif_dir / "sessions"
        sd.mkdir(parents=True, exist_ok=True)
        (sd / f"session-{n}.json").write_text(
            json.dumps({"session_number": n, "session_id": session_id})
        )
        return sd / f"session-{n}.json"

    def test_real_id_claims_fresh_unknown_orphan(self):
        from seif.plugins.core.session_lifecycle import claim_orphan_session_slot
        with tempfile.TemporaryDirectory() as td:
            seif_dir = Path(td) / ".seif"
            self._write_session(seif_dir, 7, "unknown")
            self.assertEqual(claim_orphan_session_slot(seif_dir, "real-uuid"), 7)

    def test_unknown_caller_does_not_chain_rescue(self):
        from seif.plugins.core.session_lifecycle import claim_orphan_session_slot
        with tempfile.TemporaryDirectory() as td:
            seif_dir = Path(td) / ".seif"
            self._write_session(seif_dir, 7, "unknown")
            self.assertIsNone(claim_orphan_session_slot(seif_dir, "unknown"))
            self.assertIsNone(claim_orphan_session_slot(seif_dir, ""))

    def test_stale_orphan_outside_window_not_claimed(self):
        import os, time
        from seif.plugins.core.session_lifecycle import claim_orphan_session_slot
        with tempfile.TemporaryDirectory() as td:
            seif_dir = Path(td) / ".seif"
            p = self._write_session(seif_dir, 7, "unknown")
            old = time.time() - 120
            os.utime(p, (old, old))
            self.assertIsNone(claim_orphan_session_slot(seif_dir, "real-uuid"))

    def test_non_orphan_latest_blocks_rescue(self):
        from seif.plugins.core.session_lifecycle import claim_orphan_session_slot
        with tempfile.TemporaryDirectory() as td:
            seif_dir = Path(td) / ".seif"
            self._write_session(seif_dir, 7, "unknown")
            self._write_session(seif_dir, 8, "real-prev-uuid")
            self.assertIsNone(claim_orphan_session_slot(seif_dir, "real-new-uuid"))


if __name__ == "__main__":
    unittest.main()
