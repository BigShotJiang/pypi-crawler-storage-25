"""Tests for s42 awareness MVP — session_registry."""

from __future__ import annotations

import json
import os
import time
from pathlib import Path

import pytest

from seif.plugins.core.session_registry import (
    SessionEntry,
    gc_stale,
    heartbeat,
    list_active,
    move_to_sealed,
    new_session_id,
    register,
    unregister,
)


@pytest.fixture
def seif_dir(tmp_path):
    d = tmp_path / ".seif"
    d.mkdir()
    return d


def test_register_writes_entry(seif_dir):
    sid = new_session_id()
    path = register(
        seif_dir=seif_dir,
        session_id=sid,
        wrapper="claude-code",
        cwd=Path("/Volumes/test"),
        repo_heads={"seif": "abc123"},
    )
    assert path.is_file()
    data = json.loads(path.read_text())
    assert data["session_id"] == sid
    assert data["wrapper"] == "claude-code"
    assert data["repos_observed"] == {"seif": "abc123"}
    assert data["pid"] == os.getpid()
    assert "started_at" in data and "last_heartbeat" in data


def test_register_is_idempotent_on_same_id(seif_dir):
    sid = new_session_id()
    register(seif_dir=seif_dir, session_id=sid, wrapper="x", cwd=Path("/a"))
    register(seif_dir=seif_dir, session_id=sid, wrapper="y", cwd=Path("/b"))
    entries = list_active(seif_dir)
    assert len(entries) == 1
    assert entries[0]["wrapper"] == "y"
    assert entries[0]["cwd"] == "/b"


def test_unique_session_ids():
    seen = {new_session_id() for _ in range(50)}
    assert len(seen) == 50


def test_heartbeat_updates_timestamp(seif_dir, monkeypatch):
    sid = new_session_id()
    register(seif_dir=seif_dir, session_id=sid, wrapper="x", cwd=Path("/a"))
    path = seif_dir / "sessions" / "active" / f"{sid}.json"
    initial = json.loads(path.read_text())["last_heartbeat"]

    # Force a different timestamp so the test isn't sensitive to clock granularity
    fake_now = "2099-01-01T12:34:56Z"
    monkeypatch.setattr(
        "seif.plugins.core.session_registry._now_iso", lambda: fake_now
    )
    assert heartbeat(seif_dir, sid) is True

    after = json.loads(path.read_text())["last_heartbeat"]
    assert after == fake_now
    assert after != initial


def test_heartbeat_returns_false_when_missing(seif_dir):
    assert heartbeat(seif_dir, "nonexistent") is False


def test_unregister_removes_file(seif_dir):
    sid = new_session_id()
    register(seif_dir=seif_dir, session_id=sid, wrapper="x", cwd=Path("/a"))
    assert unregister(seif_dir, sid) is True
    assert not (seif_dir / "sessions" / "active" / f"{sid}.json").exists()


def test_unregister_idempotent_on_missing(seif_dir):
    assert unregister(seif_dir, "never-registered") is False


def test_list_active_returns_all_fresh(seif_dir):
    a = new_session_id()
    b = new_session_id()
    register(seif_dir=seif_dir, session_id=a, wrapper="x", cwd=Path("/a"))
    register(seif_dir=seif_dir, session_id=b, wrapper="y", cwd=Path("/b"))
    entries = list_active(seif_dir)
    ids = {e["session_id"] for e in entries}
    assert ids == {a, b}


def test_list_active_excludes_self(seif_dir):
    a = new_session_id()
    b = new_session_id()
    register(seif_dir=seif_dir, session_id=a, wrapper="x", cwd=Path("/a"))
    register(seif_dir=seif_dir, session_id=b, wrapper="y", cwd=Path("/b"))
    entries = list_active(seif_dir, exclude=[a])
    assert {e["session_id"] for e in entries} == {b}


def test_list_active_filters_stale(seif_dir):
    sid = new_session_id()
    register(seif_dir=seif_dir, session_id=sid, wrapper="x", cwd=Path("/a"))
    # Backdate last_heartbeat to 30 min ago
    path = seif_dir / "sessions" / "active" / f"{sid}.json"
    data = json.loads(path.read_text())
    data["last_heartbeat"] = time.strftime(
        "%Y-%m-%dT%H:%M:%SZ", time.gmtime(time.time() - 1800)
    )
    path.write_text(json.dumps(data))

    entries = list_active(seif_dir, stale_after_seconds=900)
    assert entries == []


def test_list_active_returns_empty_when_no_registry(seif_dir):
    assert list_active(seif_dir) == []


def test_gc_stale_removes_expired_entries(seif_dir):
    fresh = new_session_id()
    stale = new_session_id()
    register(seif_dir=seif_dir, session_id=fresh, wrapper="x", cwd=Path("/a"))
    register(seif_dir=seif_dir, session_id=stale, wrapper="y", cwd=Path("/b"))

    stale_path = seif_dir / "sessions" / "active" / f"{stale}.json"
    data = json.loads(stale_path.read_text())
    data["last_heartbeat"] = time.strftime(
        "%Y-%m-%dT%H:%M:%SZ", time.gmtime(time.time() - 2000)
    )
    stale_path.write_text(json.dumps(data))

    removed = gc_stale(seif_dir, stale_after_seconds=900)
    assert removed == 1
    assert not stale_path.exists()
    assert (seif_dir / "sessions" / "active" / f"{fresh}.json").exists()


def test_gc_stale_removes_malformed_files(seif_dir):
    reg_dir = seif_dir / "sessions" / "active"
    reg_dir.mkdir(parents=True)
    bad = reg_dir / "garbage.json"
    bad.write_text("not valid JSON {")
    removed = gc_stale(seif_dir)
    assert removed == 1
    assert not bad.exists()


def test_gc_stale_safe_when_no_registry(seif_dir):
    assert gc_stale(seif_dir) == 0


def test_register_rejects_literal_unknown(seif_dir):
    """s55 live regression: bash hook fallback writes 'unknown' when stdin lacks
    session_id. Guard must reject before any FS write so active/ stays clean."""
    with pytest.raises(ValueError, match="canonical UUID"):
        register(seif_dir=seif_dir, session_id="unknown", wrapper="x", cwd=Path("/a"))
    assert not (seif_dir / "sessions" / "active").exists() or \
        list((seif_dir / "sessions" / "active").iterdir()) == []


def test_register_rejects_empty_string(seif_dir):
    with pytest.raises(ValueError, match="non-empty string"):
        register(seif_dir=seif_dir, session_id="", wrapper="x", cwd=Path("/a"))


def test_register_rejects_malformed_uuid(seif_dir):
    with pytest.raises(ValueError, match="canonical UUID"):
        register(seif_dir=seif_dir, session_id="not-a-uuid", wrapper="x", cwd=Path("/a"))


def test_register_rejects_none(seif_dir):
    with pytest.raises(ValueError, match="non-empty string"):
        register(seif_dir=seif_dir, session_id=None, wrapper="x", cwd=Path("/a"))  # type: ignore[arg-type]


def test_register_rejects_non_string(seif_dir):
    with pytest.raises(ValueError, match="non-empty string"):
        register(seif_dir=seif_dir, session_id=12345, wrapper="x", cwd=Path("/a"))  # type: ignore[arg-type]


def test_register_invalid_id_does_not_create_registry_dir(seif_dir):
    """Fail-closed: invalid id must not have side-effects on the FS."""
    reg_dir = seif_dir / "sessions" / "active"
    assert not reg_dir.exists()
    with pytest.raises(ValueError):
        register(seif_dir=seif_dir, session_id="unknown", wrapper="x", cwd=Path("/a"))
    assert not reg_dir.exists()


def test_register_accepts_canonical_uuid_uppercase(seif_dir):
    """uuid.UUID() normalizes case; both forms should be accepted."""
    sid = new_session_id().upper()
    path = register(seif_dir=seif_dir, session_id=sid, wrapper="x", cwd=Path("/a"))
    assert path.is_file()


def test_session_entry_dataclass_round_trips(seif_dir):
    sid = new_session_id()
    register(
        seif_dir=seif_dir,
        session_id=sid,
        wrapper="claude-code",
        cwd=Path("/Volumes/test"),
        repo_heads={"a": "1", "b": "2"},
        host="test-host",
        pid=99999,
    )
    entries = list_active(seif_dir)
    assert len(entries) == 1
    e = entries[0]
    # Confirm a SessionEntry can be reconstructed from disk
    rebuilt = SessionEntry(**e)
    assert rebuilt.session_id == sid
    assert rebuilt.host == "test-host"
    assert rebuilt.pid == 99999
    assert rebuilt.repos_observed == {"a": "1", "b": "2"}


# s58 PR1 — cycle_id binding (schema only; CLI in PR2, validator in PR3)


def test_register_persists_explicit_cycle_id(seif_dir, monkeypatch):
    monkeypatch.delenv("SEIF_ACTIVE_CYCLE", raising=False)
    sid = new_session_id()
    register(
        seif_dir=seif_dir, session_id=sid, wrapper="x", cwd=Path("/a"),
        cycle_id="s58-cycle-session-binding",
    )
    data = json.loads((seif_dir / "sessions" / "active" / f"{sid}.json").read_text())
    assert data["cycle_id"] == "s58-cycle-session-binding"


def test_register_without_cycle_id_persists_null(seif_dir, monkeypatch):
    """Backward compat: pre-s58 callers omit cycle_id; entry stays None."""
    monkeypatch.delenv("SEIF_ACTIVE_CYCLE", raising=False)
    sid = new_session_id()
    register(seif_dir=seif_dir, session_id=sid, wrapper="x", cwd=Path("/a"))
    data = json.loads((seif_dir / "sessions" / "active" / f"{sid}.json").read_text())
    assert data["cycle_id"] is None


def test_register_falls_back_to_env_var(seif_dir, monkeypatch):
    """SEIF_ACTIVE_CYCLE env var is the process-state pointer set by --start-cycle
    (PR2). When register() isn't passed cycle_id explicitly, env wins over None."""
    monkeypatch.setenv("SEIF_ACTIVE_CYCLE", "s58-from-env")
    sid = new_session_id()
    register(seif_dir=seif_dir, session_id=sid, wrapper="x", cwd=Path("/a"))
    data = json.loads((seif_dir / "sessions" / "active" / f"{sid}.json").read_text())
    assert data["cycle_id"] == "s58-from-env"


def test_explicit_cycle_id_overrides_env(seif_dir, monkeypatch):
    """Explicit kwarg beats env — caller-provided binding wins."""
    monkeypatch.setenv("SEIF_ACTIVE_CYCLE", "s58-from-env")
    sid = new_session_id()
    register(
        seif_dir=seif_dir, session_id=sid, wrapper="x", cwd=Path("/a"),
        cycle_id="s58-explicit",
    )
    data = json.loads((seif_dir / "sessions" / "active" / f"{sid}.json").read_text())
    assert data["cycle_id"] == "s58-explicit"


def test_pre_pr1_entry_loads_without_cycle_id(seif_dir):
    """Pre-PR1 registry entries (written before this schema change) lack
    cycle_id entirely. list_active must keep returning them; SessionEntry
    must reconstruct via dataclass default."""
    reg_dir = seif_dir / "sessions" / "active"
    reg_dir.mkdir(parents=True)
    sid = new_session_id()
    legacy = {
        "session_id": sid,
        "wrapper": "claude-code",
        "host": "legacy-host",
        "pid": 1,
        "cwd": "/legacy",
        "started_at": _now_iso_for_test(),
        "last_heartbeat": _now_iso_for_test(),
        "repos_observed": {},
    }
    (reg_dir / f"{sid}.json").write_text(json.dumps(legacy))

    entries = list_active(seif_dir)
    assert len(entries) == 1
    assert "cycle_id" not in entries[0]
    rebuilt = SessionEntry(**entries[0])
    assert rebuilt.cycle_id is None


def _now_iso_for_test():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


# ── move_to_sealed (s60 PR1, option E) ──────────────────────────────────


def test_move_to_sealed_moves_active_to_sealed_cycle_dir(seif_dir):
    sid = new_session_id()
    register(seif_dir=seif_dir, session_id=sid, wrapper="x", cwd=Path("/x"))
    src = seif_dir / "sessions" / "active" / f"{sid}.json"
    body = src.read_bytes()

    moved, dest = move_to_sealed(seif_dir, sid, "cyc-1")
    assert moved is True
    assert dest == seif_dir / "sessions" / "sealed" / "cyc-1" / f"{sid}.json"
    assert dest.is_file()
    assert dest.read_bytes() == body, (
        "move-not-delete must preserve session body byte-for-byte"
    )
    assert not src.exists(), "source must leave active/"


def test_move_to_sealed_idempotent_when_already_at_sealed(seif_dir):
    sid = new_session_id()
    register(seif_dir=seif_dir, session_id=sid, wrapper="x", cwd=Path("/x"))
    move_to_sealed(seif_dir, sid, "cyc-2")

    moved, dest = move_to_sealed(seif_dir, sid, "cyc-2")
    assert moved is False
    assert dest is not None and dest.is_file()


def test_move_to_sealed_returns_none_dest_when_session_absent(seif_dir):
    moved, dest = move_to_sealed(seif_dir, "nonexistent-sid", "cyc-3")
    assert moved is False
    assert dest is None


def test_move_to_sealed_handles_split_brain_prefer_sealed_copy(seif_dir):
    """Defensive: if both active/<sid>.json and sealed/<cycle>/<sid>.json
    exist (e.g., after a stale rsync left a copy in active/), prefer the
    sealed body (terminal storage) and drop the active straggler. Avoids
    clobbering the archived evidence with whatever ended up in active/."""
    sid = new_session_id()
    register(seif_dir=seif_dir, session_id=sid, wrapper="x", cwd=Path("/x"))
    sealed_dir = seif_dir / "sessions" / "sealed" / "split-brain"
    sealed_dir.mkdir(parents=True)
    (sealed_dir / f"{sid}.json").write_bytes(b'{"sealed": "authoritative"}')

    moved, dest = move_to_sealed(seif_dir, sid, "split-brain")
    assert moved is True
    assert dest is not None
    assert dest.read_bytes() == b'{"sealed": "authoritative"}', (
        "must preserve the sealed body, not overwrite with the active straggler"
    )
    assert not (seif_dir / "sessions" / "active" / f"{sid}.json").exists()
