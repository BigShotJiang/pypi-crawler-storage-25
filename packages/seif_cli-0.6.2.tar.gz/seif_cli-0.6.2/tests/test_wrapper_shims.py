"""Tests for seif setup wrapper-shims — Phase 2.D shell-level A4 enforcement."""
from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from seif.cli.wrapper_shims import (  # noqa: E402
    install,
    uninstall,
    status,
    _build_plan,
    _patch_rc_idempotent,
    _unpatch_rc,
    SHIM_GUARD_BEGIN,
    SHIM_GUARD_END,
    SHIM_PATH_LINE,
    DEFAULT_BINARIES,
)


REPO_ROOT = Path(__file__).resolve().parent.parent
SHIM_SH = REPO_ROOT / "src" / "seif" / "wrappers" / "shim.sh"
ACTIONS_JSON = REPO_ROOT / "src" / "seif" / "wrappers" / "destructive_actions.json"


class WrapperShimsInstallTests(unittest.TestCase):

    def test_build_plan_lists_default_binaries(self):
        with tempfile.TemporaryDirectory() as tmp:
            plan = _build_plan(home=Path(tmp), shell="zsh")
            self.assertEqual(plan.binaries, list(DEFAULT_BINARIES))
            kinds = [a.kind for a in plan.actions]
            self.assertIn("create_dir", kinds)
            self.assertIn("copy_template", kinds)
            self.assertIn("symlink", kinds)
            self.assertIn("patch_rc", kinds)
            self.assertIn("log_state", kinds)

    def test_install_creates_symlinks_and_state(self):
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp)
            state = install(home=home, shell="zsh")
            self.assertEqual(len(state["links"]), len(DEFAULT_BINARIES))
            for bin_name in DEFAULT_BINARIES:
                link = home / ".seif" / "bin" / bin_name
                self.assertTrue(link.is_symlink(), f"{bin_name} symlink missing")
                target = link.readlink()
                self.assertEqual(target.name, "shim.sh")
            state_file = home / ".seif" / "host" / "wrapper-shims.json"
            self.assertTrue(state_file.is_file())
            on_disk = json.loads(state_file.read_text())
            self.assertEqual(on_disk["schema"], "SEIF-WRAPPER-SHIMS-v1")

    def test_install_copies_shim_and_actions_config(self):
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp)
            install(home=home, shell="zsh")
            wrappers = home / ".seif" / "wrappers"
            self.assertTrue((wrappers / "shim.sh").is_file())
            self.assertTrue((wrappers / "destructive_actions.json").is_file())
            mode = (wrappers / "shim.sh").stat().st_mode & 0o777
            self.assertTrue(mode & 0o100, "shim.sh must be executable by owner")

    def test_install_is_idempotent(self):
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp)
            install(home=home, shell="zsh")
            install(home=home, shell="zsh")  # should not raise / duplicate

            for bin_name in DEFAULT_BINARIES:
                link = home / ".seif" / "bin" / bin_name
                self.assertTrue(link.is_symlink())

    def test_uninstall_reverses_install(self):
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp)
            install(home=home, shell="zsh")
            result = uninstall(home=home)
            self.assertEqual(len(result["removed_links"]), len(DEFAULT_BINARIES))
            for bin_name in DEFAULT_BINARIES:
                link = home / ".seif" / "bin" / bin_name
                self.assertFalse(link.exists() or link.is_symlink(),
                                 f"{bin_name} not removed")
            state_file = home / ".seif" / "host" / "wrapper-shims.json"
            self.assertFalse(state_file.is_file())

    def test_status_pre_and_post_install(self):
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp)
            self.assertFalse(status(home=home).get("installed"))
            install(home=home, shell="zsh")
            s = status(home=home)
            self.assertTrue(s["installed"])
            self.assertEqual(set(s["live_links"]), set(DEFAULT_BINARIES))


class RcPatchTests(unittest.TestCase):

    def test_patch_rc_creates_block_with_guards(self):
        with tempfile.TemporaryDirectory() as tmp:
            rc = Path(tmp) / ".zshrc"
            rc.write_text("# user content\nexport FOO=bar\n")
            result = _patch_rc_idempotent(rc)
            self.assertEqual(result, "added")
            text = rc.read_text()
            self.assertIn(SHIM_GUARD_BEGIN, text)
            self.assertIn(SHIM_GUARD_END, text)
            self.assertIn(SHIM_PATH_LINE, text)
            self.assertIn("# user content", text, "user content must be preserved")

    def test_patch_rc_is_idempotent(self):
        with tempfile.TemporaryDirectory() as tmp:
            rc = Path(tmp) / ".zshrc"
            rc.write_text("user\n")
            r1 = _patch_rc_idempotent(rc)
            r2 = _patch_rc_idempotent(rc)
            self.assertEqual(r1, "added")
            self.assertEqual(r2, "present")
            # Block must appear exactly once
            self.assertEqual(rc.read_text().count(SHIM_GUARD_BEGIN), 1)

    def test_unpatch_rc_strips_block(self):
        with tempfile.TemporaryDirectory() as tmp:
            rc = Path(tmp) / ".zshrc"
            rc.write_text("user content\nexport FOO=bar\n")
            _patch_rc_idempotent(rc)
            self.assertEqual(_unpatch_rc(rc), "removed")
            text = rc.read_text()
            self.assertNotIn(SHIM_GUARD_BEGIN, text)
            self.assertNotIn(SHIM_PATH_LINE, text)
            self.assertIn("user content", text, "user content preserved")
            self.assertIn("export FOO=bar", text)


class ShimRuntimeTests(unittest.TestCase):
    """Run the installed shim as a real subprocess and verify gate-vs-passthrough."""

    def setUp(self):
        if not SHIM_SH.is_file():
            self.skipTest("shim.sh not present in repo")
        if subprocess.run(["which", "git"], capture_output=True).returncode != 0:
            self.skipTest("git not in PATH")

    def _run_shim(self, tmp: Path, bin_name: str, *args,
                  env_extra=None, install_fake_seif: bool = True):
        """Invoke the shim as if it were `bin_name` with args. Returns (rc, stdout, stderr).

        install_fake_seif: when True (default), put a stub `seif` on PATH
        that mimics `seif --confirm-action` (prints AWAITING, exits 2).
        Lets these tests exercise shim logic without depending on a
        pip-installed seif (CI runners don't have seif on PATH)."""
        wrappers = tmp / "wrappers"
        bin_dir = tmp / "bin"
        fake_dir = tmp / "fake_seif_bin"
        wrappers.mkdir(parents=True, exist_ok=True)
        bin_dir.mkdir(parents=True, exist_ok=True)
        fake_dir.mkdir(parents=True, exist_ok=True)
        # Copy shim + actions
        import shutil
        shutil.copy2(SHIM_SH, wrappers / "shim.sh")
        (wrappers / "shim.sh").chmod(0o755)
        shutil.copy2(ACTIONS_JSON, wrappers / "destructive_actions.json")
        link = bin_dir / bin_name
        if link.exists() or link.is_symlink():
            link.unlink()
        link.symlink_to(wrappers / "shim.sh")

        env = os.environ.copy()
        env["SEIF_SHIM_DIR"] = str(bin_dir)
        env["SEIF_WRAPPERS_DIR"] = str(wrappers)
        # Prepend bin_dir to PATH so the AI's `git` resolves to our shim.
        # If install_fake_seif, also put a fake seif on the resolution path
        # (the path the shim uses AFTER stripping its own dir).
        path_parts = [str(bin_dir)]
        if install_fake_seif:
            fake_seif = fake_dir / "seif"
            fake_seif.write_text(
                '#!/bin/bash\n'
                '# Stub seif --confirm-action: emits AWAITING and exits 2.\n'
                'echo "[SEIF CONFIRM-ACTION] AWAITING_HUMAN_CONFIRMATION"\n'
                'action=""\n'
                'while [ "$#" -gt 0 ]; do\n'
                '  case "$1" in\n'
                '    --confirm-action) action="$2"; shift 2;;\n'
                '    *) shift;;\n'
                '  esac\n'
                'done\n'
                'echo "Action: $action"\n'
                'exit 2\n'
            )
            fake_seif.chmod(0o755)
            path_parts.append(str(fake_dir))
        path_parts.append(env.get("PATH", ""))
        env["PATH"] = ":".join(path_parts)
        if env_extra:
            env.update(env_extra)

        result = subprocess.run(
            [str(link)] + list(args),
            capture_output=True, text=True, env=env,
            timeout=15, check=False,
        )
        return result.returncode, result.stdout, result.stderr

    def test_passthrough_on_non_destructive(self):
        with tempfile.TemporaryDirectory() as tmp:
            rc, out, err = self._run_shim(Path(tmp), "git", "--version")
            self.assertEqual(rc, 0,
                             f"git --version should passthrough; got rc={rc} err={err}")
            self.assertIn("git version", out)

    def test_gate_fires_on_destructive(self):
        with tempfile.TemporaryDirectory() as tmp:
            rc, out, err = self._run_shim(
                Path(tmp), "git", "push", "--dry-run", "origin", "HEAD",
            )
            self.assertEqual(rc, 2,
                             f"destructive command must exit 2 (got {rc}); "
                             f"out={out!r} err={err!r}")
            self.assertIn("AWAITING_HUMAN_CONFIRMATION", out)
            self.assertIn("git push --dry-run origin HEAD", out)

    def test_multi_word_pattern_match(self):
        """`git reset --hard ...` should match the multi-word destructive pattern."""
        with tempfile.TemporaryDirectory() as tmp:
            rc, out, _ = self._run_shim(
                Path(tmp), "git", "reset", "--hard", "HEAD~1",
            )
            self.assertEqual(rc, 2)
            self.assertIn("git reset --hard HEAD~1", out)

    def test_seif_cli_missing_falls_through_with_warning(self):
        """If `seif` CLI is unreachable, shim must NOT lock the user out."""
        with tempfile.TemporaryDirectory() as tmp:
            # Strip seif from PATH by setting PATH to only /usr/bin (bare minimum
            # for the shim's tools). git push will try to push, exit non-zero.
            rc, out, err = self._run_shim(
                Path(tmp), "git", "log", "--oneline", "-1",
                env_extra={"PATH": "/usr/bin:/bin"},
            )
            # `git log` is non-destructive — passthrough regardless of seif presence
            self.assertEqual(rc, 0,
                             f"non-destructive should always passthrough; "
                             f"rc={rc} out={out!r} err={err!r}")


if __name__ == "__main__":
    unittest.main()
