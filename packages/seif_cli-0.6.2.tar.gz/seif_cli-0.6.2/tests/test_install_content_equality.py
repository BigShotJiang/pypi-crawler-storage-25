"""Content-equality tests for setup._install_scripts / _install_core_scripts.

s41 P3 regression: prior to this fix, `seif setup claude-code` would print
"Scripts: 5 installed" but the destination file could be byte-different from
source (silent-skip class observed during s40 deploy on Mini editable host).
The fix verifies md5(src) == md5(dst) after copy and exits non-zero on
mismatch. These tests pin that contract.
"""

from __future__ import annotations

import hashlib
from pathlib import Path

import pytest


@pytest.fixture
def fake_home(tmp_path, monkeypatch):
    monkeypatch.setattr(Path, "home", classmethod(lambda cls: tmp_path))
    return tmp_path


def _md5(path: Path) -> str:
    return hashlib.md5(path.read_bytes()).hexdigest()


def test_install_scripts_dst_matches_src_md5(fake_home):
    from seif.cli.setup import (
        _get_install_dir,
        _get_plugin_source_dir,
        _install_scripts,
    )

    source_dir = _get_plugin_source_dir()
    install_dir = _get_install_dir()
    installed = _install_scripts(source_dir, install_dir)

    assert installed, "install reported zero scripts but source has scripts"

    scripts_src = source_dir / "scripts"
    scripts_dst = install_dir / "scripts"
    for name in installed:
        src = scripts_src / name
        dst = scripts_dst / name
        assert dst.is_file(), f"{name} not copied to {dst}"
        assert _md5(src) == _md5(dst), (
            f"content drift after install: {name}\n"
            f"  src={src} md5={_md5(src)}\n"
            f"  dst={dst} md5={_md5(dst)}"
        )


def test_install_core_scripts_dst_matches_src_md5(fake_home):
    from seif.cli.setup import (
        _get_core_install_dir,
        _get_core_source_dir,
        _install_core_scripts,
    )

    installed = _install_core_scripts()
    core_src = _get_core_source_dir()
    core_dst = _get_core_install_dir()

    for name in installed:
        src = core_src / name
        dst = core_dst / name
        assert _md5(src) == _md5(dst), (
            f"content drift after core install: {name}\n"
            f"  src={src} md5={_md5(src)}\n"
            f"  dst={dst} md5={_md5(dst)}"
        )


def test_install_scripts_fails_loud_on_content_mismatch(
    fake_home, monkeypatch, capsys
):
    """If shutil.copy2 silently produces byte-different dst, _install_scripts
    must exit non-zero with a clear error rather than appending to the
    'installed' list."""
    import shutil

    from seif.cli.setup import (
        _get_install_dir,
        _get_plugin_source_dir,
        _install_scripts,
    )

    source_dir = _get_plugin_source_dir()
    install_dir = _get_install_dir()

    real_copy2 = shutil.copy2

    def fake_copy2(src, dst, *args, **kwargs):
        result = real_copy2(src, dst, *args, **kwargs)
        Path(dst).write_bytes(b"# tampered\n")
        return result

    monkeypatch.setattr("seif.cli.setup.shutil.copy2", fake_copy2)

    with pytest.raises(SystemExit) as exc_info:
        _install_scripts(source_dir, install_dir)

    assert exc_info.value.code == 1
    err = capsys.readouterr().err
    assert "FATAL" in err
    assert "content-mismatch" in err
    assert "s41 P3" in err


def test_install_core_scripts_fails_loud_on_content_mismatch(
    fake_home, monkeypatch, capsys
):
    import shutil

    from seif.cli.setup import _install_core_scripts

    real_copy2 = shutil.copy2

    def fake_copy2(src, dst, *args, **kwargs):
        result = real_copy2(src, dst, *args, **kwargs)
        Path(dst).write_bytes(b"# tampered\n")
        return result

    monkeypatch.setattr("seif.cli.setup.shutil.copy2", fake_copy2)

    with pytest.raises(SystemExit) as exc_info:
        _install_core_scripts()

    assert exc_info.value.code == 1
    err = capsys.readouterr().err
    assert "FATAL" in err
    assert "content-mismatch" in err


def test_install_core_scripts_includes_kernel_seed(fake_home):
    """s54 T1 regression: prior to this fix, _install_core_scripts copied
    only session_lifecycle.py + circuit_monitor.py, leaving kernel_seed.py
    absent from the canonical install path. session_lifecycle._run_core_script
    then resolved to the legacy hyphen-named shim at
    ~/.local/share/seif/claude-code/scripts/kernel-seed.py, which is NOT
    refreshed by `seif setup` — so a v1→v2 source bump produced a stale
    runtime banner until the shim was hot-patched manually. This test pins
    that kernel_seed.py is part of the canonical copy list."""
    from seif.cli.setup import (
        _get_core_install_dir,
        _get_core_source_dir,
        _install_core_scripts,
    )

    installed = _install_core_scripts()
    assert "kernel_seed.py" in installed, (
        "kernel_seed.py missing from canonical install — "
        "session-start would silently fall back to the legacy shim"
    )

    core_src = _get_core_source_dir()
    core_dst = _get_core_install_dir()
    src = core_src / "kernel_seed.py"
    dst = core_dst / "kernel_seed.py"
    assert dst.is_file(), f"kernel_seed.py not landed at {dst}"
    assert _md5(src) == _md5(dst), (
        f"content drift after install: kernel_seed.py\n"
        f"  src={src} md5={_md5(src)}\n"
        f"  dst={dst} md5={_md5(dst)}"
    )
