"""Tests for the audio-side provenance bridge (Wedge A v1.0 DoD #5 audio).

Covers seif.audio_provenance.verify_audio_against_envelope and the
file-loading wrapper. Exercises real watermark embed/extract math (no
mocking of the audio stack) plus envelope shape validation.

Tests use a fast watermark config (0.5s symbols, 2 repetitions) to keep
runtime <1s per test. The MCP server registry test uses per-test
importorskip to avoid the runner-mismatch trap (see
pending-2026-05-07-mcp-importorskip-runner-mismatch.seif).
"""

from __future__ import annotations

import json
import os
import sys
import wave
from pathlib import Path

import numpy as np
import pytest


sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

pytest.importorskip("cryptography", reason="cryptography not installed")

from seif.audio_provenance import (  # noqa: E402
    verify_audio_against_envelope,
    verify_audio_against_envelope_file,
)
from seif.generators.watermark import (  # noqa: E402
    WatermarkConfig,
    embed_watermark_wav,
)


# ── Fixtures ───────────────────────────────────────────────────────────


def _write_silent_wav(
    path: Path,
    duration_seconds: float = 35.0,
    sample_rate: int = 44100,
) -> None:
    """Write a silent mono 16-bit PCM WAV.

    Default duration is generous enough to fit 64 symbols × 0.5s × 2 reps
    plus padding (~64s with default repetitions=3, ~33s with rep=2).
    """
    n = int(duration_seconds * sample_rate)
    samples = np.zeros(n, dtype=np.int16)
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sample_rate)
        w.writeframes(samples.tobytes())


def _fast_config() -> WatermarkConfig:
    """Fast test config: 0.5s symbols + 4Hz spacing.

    Default freq_spacing=1Hz cannot be resolved by 0.5s symbols
    (FFT resolution = 1/duration = 2Hz). 4Hz spacing matches
    test_audio_watermark_mvp.py's working config.
    """
    return WatermarkConfig(
        symbol_duration=0.5,
        repetitions=2,
        amplitude=0.1,
        freq_spacing_hz=4.0,
    )


_VERIFY_FAST_KW = dict(repetitions=2, symbol_duration=0.5, freq_spacing_hz=4.0)


@pytest.fixture
def watermarked_wav(tmp_path: Path) -> tuple[Path, str]:
    """Returns (path_to_watermarked_wav, embedded_sha256_hex).

    Embeds a known 64-char hex digest into a silent WAV using the fast
    test config. The fixture decouples the embed step from each test so
    individual tests just exercise the verify side.
    """
    silent = tmp_path / "carrier.wav"
    _write_silent_wav(silent, duration_seconds=70.0)  # 64 sym × 0.5s × 2 rep = 64s + padding

    embedded_hash = "a" * 64  # arbitrary deterministic hex
    out = tmp_path / "carrier_watermarked.wav"
    embed_watermark_wav(embedded_hash, str(silent), str(out), _fast_config())
    return out, embedded_hash


# ── verify_audio_against_envelope ──────────────────────────────────────


def test_verify_matches_when_envelope_carries_embedded_hash(watermarked_wav):
    out, embedded_hash = watermarked_wav
    envelope = {"content_sha256": embedded_hash, "signature": {"algorithm": "Ed25519"}}

    result = verify_audio_against_envelope(
        out,
        envelope,
        n_symbols=64,
        **_VERIFY_FAST_KW,
    )
    assert result["ok"] is True
    assert result["valid"] is True
    assert result["extracted"] == embedded_hash
    assert result["expected_content_sha256"] == embedded_hash
    assert result["n_symbols"] == 64
    assert str(out) in result["input_wav"]


def test_verify_mismatch_when_envelope_hash_differs(watermarked_wav):
    out, _embedded = watermarked_wav
    envelope = {"content_sha256": "b" * 64}

    result = verify_audio_against_envelope(out, envelope, **_VERIFY_FAST_KW)
    assert result["ok"] is True
    assert result["valid"] is False
    assert result["extracted"] != result["expected_content_sha256"]


def test_verify_rejects_envelope_missing_hash(watermarked_wav):
    out, _ = watermarked_wav
    result = verify_audio_against_envelope(out, envelope={"signature": {}})
    assert result["ok"] is False
    assert result["error"] == "envelope_missing_or_invalid_content_sha256"


def test_verify_rejects_envelope_bad_hash_length(watermarked_wav):
    out, _ = watermarked_wav
    result = verify_audio_against_envelope(
        out, envelope={"content_sha256": "deadbeef"}
    )
    assert result["ok"] is False
    assert result["error"] == "envelope_missing_or_invalid_content_sha256"


def test_verify_rejects_envelope_non_hex(watermarked_wav):
    out, _ = watermarked_wav
    result = verify_audio_against_envelope(
        out, envelope={"content_sha256": "z" * 64}
    )
    assert result["ok"] is False
    assert result["error"] == "envelope_missing_or_invalid_content_sha256"


def test_verify_rejects_non_dict_envelope():
    result = verify_audio_against_envelope(
        "/tmp/anything.wav", envelope="not a dict"  # type: ignore[arg-type]
    )
    assert result["ok"] is False
    assert result["error"] == "envelope_missing_or_invalid_content_sha256"


def test_verify_handles_missing_audio(tmp_path: Path):
    envelope = {"content_sha256": "a" * 64}
    result = verify_audio_against_envelope(
        tmp_path / "does-not-exist.wav",
        envelope,
        **_VERIFY_FAST_KW,
    )
    assert result["ok"] is False
    assert result["error"] == "input_wav_unreadable"


# ── verify_audio_against_envelope_file (envelope from JSON) ────────────


def test_verify_from_file_happy_path(watermarked_wav, tmp_path: Path):
    out, embedded_hash = watermarked_wav
    env_path = tmp_path / "envelope.json"
    env_path.write_text(json.dumps({"content_sha256": embedded_hash}))

    result = verify_audio_against_envelope_file(out, env_path, **_VERIFY_FAST_KW)
    assert result["ok"] is True
    assert result["valid"] is True


def test_verify_from_file_envelope_not_found(watermarked_wav, tmp_path: Path):
    out, _ = watermarked_wav
    result = verify_audio_against_envelope_file(out, tmp_path / "nope.json")
    assert result["ok"] is False
    assert result["error"] == "envelope_file_not_found"


def test_verify_from_file_envelope_invalid_json(
    watermarked_wav, tmp_path: Path
):
    out, _ = watermarked_wav
    bad = tmp_path / "bad.json"
    bad.write_text("not valid json {")
    result = verify_audio_against_envelope_file(out, bad)
    assert result["ok"] is False
    assert result["error"] == "envelope_file_not_valid_json"


# ── End-to-end chain (provenance_sign → embed → verify) ────────────────


@pytest.fixture
def isolated_keys(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    home = tmp_path / "seif_home"
    home.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("SEIF_HOME", str(home))
    from seif.core import signing
    signing.keygen()
    return home


def test_full_chain_sign_embed_verify(isolated_keys, tmp_path: Path):
    """The canonical Wedge A audio-side demo:
    provenance_sign(text) → embed(content_sha256) → audio_provenance_verify(envelope)
    """
    from seif.mcp.server import provenance_sign_impl

    # 1. Sign an AI-side artifact (could be a podcast transcript, a script, etc.)
    artifact_text = "AI-generated podcast transcript v1"
    envelope = provenance_sign_impl(text=artifact_text)
    assert envelope["ok"] is True

    # 2. Embed envelope's content_sha256 onto a silent audio carrier
    silent = tmp_path / "silent.wav"
    _write_silent_wav(silent, duration_seconds=70.0)

    out = tmp_path / "podcast_watermarked.wav"
    embed_watermark_wav(
        envelope["content_sha256"], str(silent), str(out), _fast_config()
    )

    # 3. Verify audio against envelope — agent / verifier path
    result = verify_audio_against_envelope(out, envelope, **_VERIFY_FAST_KW)
    assert result["ok"] is True
    assert result["valid"] is True
    assert result["extracted"] == envelope["content_sha256"]


# ── MCP wrapper registers new tool ─────────────────────────────────────


def test_watermark_server_includes_audio_provenance_verify():
    pytest.importorskip("mcp", reason="MCP SDK not installed; skip [mcp] extra tests")
    import asyncio
    from seif.mcp.watermark_server import build_server

    server = build_server()
    tools = asyncio.run(server.list_tools())
    names = {t.name for t in tools}
    assert "seif_audio_provenance_verify" in names
    # Existing four tools still registered
    assert {
        "seif_watermark_embed",
        "seif_watermark_extract",
        "seif_fingerprint_file",
        "seif_watermark_verify",
    }.issubset(names)
