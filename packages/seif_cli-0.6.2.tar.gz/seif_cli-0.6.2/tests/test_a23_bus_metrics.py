"""Tests for s40 P5: A23 bus-metrics counter + alert.

A23 verifiable_provenance was promoted to kernel + Ed25519-signed in s39.
P1/P2/P3 carry the envelope through producer → transport → consumer.
P5 is observability: a counter at the consumer boundary so an operator
can see whether headless invocations are dominating bus traffic — which
contradicts A23's intent. Owner-confirmed alert threshold (s40 session-
start gate): 20% headless ratio over 24h rolling.

Properties under test:
  - classification mirrors the bridge-side classifier (same internal labels)
  - record_bus_message persists events, increments counters, trims window
  - compute_a23_alert respects threshold and window
  - read_metrics tolerates missing / corrupt files
  - format_status_block stays quiet when counter is empty
  - alert breached only when ratio > threshold (NOT >=) and total > 0
"""

from __future__ import annotations

import json
import sys
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT / "src"))

from seif.observability import bus_metrics as bm  # noqa: E402


# ── Classification ─────────────────────────────────────────────────────────

class ClassifySourceKindTests(unittest.TestCase):
    def test_envelope_with_internal_node_classifies_internal(self):
        payload = {
            "issued_by": {"node": "mini-m4", "context_loaded": False,
                          "agent": "claude-responder", "model": "m"},
            "timestamp": "2026-05-01T22:00:00+00:00",
        }
        self.assertEqual(bm.classify_source_kind(payload), "internal")

    def test_envelope_with_unknown_node_classifies_external(self):
        payload = {"issued_by": {"node": "rogue-host", "context_loaded": False,
                                 "agent": "a", "model": "m"},
                   "timestamp": "x"}
        self.assertEqual(bm.classify_source_kind(payload), "external")

    def test_legacy_from_field_falls_back(self):
        self.assertEqual(bm.classify_source_kind({"from": "air-m1"}), "internal")
        self.assertEqual(bm.classify_source_kind({"from": "stranger"}), "external")

    def test_non_dict_safe_default(self):
        self.assertEqual(bm.classify_source_kind("string"), "external")
        self.assertEqual(bm.classify_source_kind(None), "external")

    def test_custom_internal_labels(self):
        kind = bm.classify_source_kind(
            {"from": "my-laptop"},
            internal_node_labels={"my-laptop"},
        )
        self.assertEqual(kind, "internal")


class ExtractContextLoadedTests(unittest.TestCase):
    def test_present_bool_returned(self):
        self.assertEqual(
            bm.extract_context_loaded({"issued_by": {"context_loaded": True}}),
            True,
        )
        self.assertEqual(
            bm.extract_context_loaded({"issued_by": {"context_loaded": False}}),
            False,
        )

    def test_missing_returns_none(self):
        self.assertIsNone(bm.extract_context_loaded({}))
        self.assertIsNone(bm.extract_context_loaded({"issued_by": {}}))

    def test_non_bool_returns_none(self):
        self.assertIsNone(
            bm.extract_context_loaded({"issued_by": {"context_loaded": "false"}})
        )
        self.assertIsNone(
            bm.extract_context_loaded({"issued_by": {"context_loaded": 0}})
        )


# ── Persistence + record ───────────────────────────────────────────────────

class RecordBusMessageTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.metrics_path = Path(self.tmp.name) / "a23.json"

    def tearDown(self):
        self.tmp.cleanup()

    def _envelope(self, *, node="mini-m4", context_loaded=False) -> dict:
        return {
            "issued_by": {
                "node": node,
                "agent": "claude-responder",
                "model": "claude-code-cli (headless)",
                "context_loaded": context_loaded,
            },
            "timestamp": "2026-05-01T22:00:00+00:00",
        }

    def test_first_record_creates_file_with_one_event(self):
        bm.record_bus_message(self._envelope(), metrics_dir=self.metrics_path)
        d = json.loads(self.metrics_path.read_text())
        self.assertEqual(d["schema"], "A23-METRICS-v1")
        self.assertEqual(d["counters"]["total"], 1)
        self.assertEqual(d["counters"]["by_source"]["internal"], 1)
        self.assertEqual(d["counters"]["by_context_loaded"]["false"], 1)

    def test_multiple_records_accumulate(self):
        bm.record_bus_message(self._envelope(node="mini-m4"),
                              metrics_dir=self.metrics_path)
        bm.record_bus_message(self._envelope(node="air-m1", context_loaded=True),
                              metrics_dir=self.metrics_path)
        bm.record_bus_message(self._envelope(node="rogue"),
                              metrics_dir=self.metrics_path)
        d = json.loads(self.metrics_path.read_text())
        self.assertEqual(d["counters"]["total"], 3)
        self.assertEqual(d["counters"]["by_source"]["internal"], 2)
        self.assertEqual(d["counters"]["by_source"]["external"], 1)
        self.assertEqual(d["counters"]["by_context_loaded"]["true"], 1)
        self.assertEqual(d["counters"]["by_context_loaded"]["false"], 2)

    def test_explicit_source_kind_overrides_classification(self):
        bm.record_bus_message(
            self._envelope(node="mini-m4"),
            source_kind="external",
            metrics_dir=self.metrics_path,
        )
        d = json.loads(self.metrics_path.read_text())
        self.assertEqual(d["counters"]["by_source"]["external"], 1)
        self.assertEqual(d["counters"]["by_source"]["internal"], 0)

    def test_missing_envelope_labelled_headless_external(self):
        """Bare {content, from} with no envelope — the producer didn't
        declare context_loaded, so we treat as headless. Source classified
        from `from` field."""
        bm.record_bus_message(
            {"from": "stranger", "content": "hi"},
            metrics_dir=self.metrics_path,
        )
        d = json.loads(self.metrics_path.read_text())
        self.assertEqual(d["counters"]["by_source"]["external"], 1)
        self.assertEqual(d["counters"]["by_context_loaded"]["false"], 1)

    def test_window_trim_drops_old_events(self):
        old_ts = (datetime.now(timezone.utc) - timedelta(hours=48)).isoformat()
        # Seed an aged file directly
        seeded = bm._empty_metrics()
        seeded["events"] = [
            {"ts": old_ts, "source": "internal", "context_loaded": False},
            {"ts": old_ts, "source": "external", "context_loaded": False},
        ]
        seeded["counters"] = bm._recompute_counters(seeded["events"])
        self.metrics_path.parent.mkdir(parents=True, exist_ok=True)
        self.metrics_path.write_text(json.dumps(seeded))
        # New record forces trim under the 24h default window
        bm.record_bus_message(self._envelope(), metrics_dir=self.metrics_path)
        d = json.loads(self.metrics_path.read_text())
        self.assertEqual(d["counters"]["total"], 1, "old events should be trimmed")
        self.assertEqual(d["events"][0]["source"], "internal")


class ReadMetricsTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / "a23.json"

    def tearDown(self):
        self.tmp.cleanup()

    def test_missing_returns_empty_skeleton(self):
        m = bm.read_metrics(self.path)
        self.assertEqual(m["schema"], "A23-METRICS-v1")
        self.assertEqual(m["counters"]["total"], 0)
        self.assertEqual(m["events"], [])

    def test_corrupt_returns_empty_skeleton(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text("{not-json{{{")
        m = bm.read_metrics(self.path)
        self.assertEqual(m["counters"]["total"], 0)

    def test_wrong_schema_returns_empty(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps({"schema": "OTHER-v9"}))
        m = bm.read_metrics(self.path)
        self.assertEqual(m["counters"]["total"], 0)


# ── Alert ──────────────────────────────────────────────────────────────────

class ComputeA23AlertTests(unittest.TestCase):
    def _metrics(self, *, headless: int, with_context: int,
                source_split: tuple[int, int] = (0, 0)) -> dict:
        now = datetime.now(timezone.utc).isoformat()
        events = []
        for i in range(headless):
            events.append({"ts": now, "source": "internal" if i < source_split[0] else "external",
                           "context_loaded": False})
        for i in range(with_context):
            events.append({"ts": now, "source": "internal", "context_loaded": True})
        return {"schema": "A23-METRICS-v1", "events": events,
                "counters": bm._recompute_counters(events)}

    def test_breach_when_ratio_above_threshold(self):
        m = self._metrics(headless=30, with_context=70)  # 30%
        a = bm.compute_a23_alert(m, threshold=0.20)
        self.assertTrue(a.breached)
        self.assertAlmostEqual(a.ratio, 0.30, places=2)
        self.assertEqual(a.headless, 30)
        self.assertEqual(a.total, 100)

    def test_no_breach_at_threshold_exactly(self):
        """Owner-confirmed default: ratio > threshold (strict). 20% itself
        is not a breach — only above it."""
        m = self._metrics(headless=20, with_context=80)  # exactly 20%
        a = bm.compute_a23_alert(m, threshold=0.20)
        self.assertFalse(a.breached)

    def test_no_breach_below_threshold(self):
        m = self._metrics(headless=10, with_context=90)
        a = bm.compute_a23_alert(m, threshold=0.20)
        self.assertFalse(a.breached)
        self.assertAlmostEqual(a.ratio, 0.10, places=2)

    def test_no_breach_when_total_zero(self):
        m = bm._empty_metrics()
        a = bm.compute_a23_alert(m)
        self.assertFalse(a.breached)
        self.assertEqual(a.total, 0)
        self.assertEqual(a.ratio, 0.0)

    def test_window_excludes_old_events(self):
        old_ts = (datetime.now(timezone.utc) - timedelta(hours=48)).isoformat()
        new_ts = datetime.now(timezone.utc).isoformat()
        m = {"schema": "A23-METRICS-v1",
             "events": [{"ts": old_ts, "source": "internal", "context_loaded": False},
                        {"ts": new_ts, "source": "internal", "context_loaded": True}],
             "counters": {}}
        a = bm.compute_a23_alert(m, window_hours=24)
        self.assertEqual(a.total, 1)  # old event excluded
        self.assertEqual(a.headless, 0)


# ── format_status_block ────────────────────────────────────────────────────

class FormatStatusBlockTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / "a23.json"

    def tearDown(self):
        self.tmp.cleanup()

    def test_empty_returns_none(self):
        self.assertIsNone(bm.format_status_block(self.path))

    def test_block_includes_total_and_ratio(self):
        bm.record_bus_message({"from": "mini-m4"}, metrics_dir=self.path)
        bm.record_bus_message({"from": "stranger"}, metrics_dir=self.path)
        block = bm.format_status_block(self.path)
        self.assertIsNotNone(block)
        self.assertIn("A23 bus traffic", block)
        self.assertIn("Total:", block)
        self.assertIn("internal=1", block)
        self.assertIn("external=1", block)

    def test_alert_line_only_when_breached(self):
        # Below threshold — no alert line
        bm.record_bus_message({"from": "mini-m4",
                               "issued_by": {"node": "mini-m4", "agent": "a",
                                             "model": "m", "context_loaded": True},
                               "timestamp": "x"},
                              metrics_dir=self.path)
        block = bm.format_status_block(self.path)
        self.assertNotIn("A23 ALERT", block)
        # Now record several headless from rogue → ratio jumps
        for _ in range(3):
            bm.record_bus_message({"from": "stranger"}, metrics_dir=self.path)
        block = bm.format_status_block(self.path)
        self.assertIn("A23 ALERT", block)


if __name__ == "__main__":
    unittest.main()
