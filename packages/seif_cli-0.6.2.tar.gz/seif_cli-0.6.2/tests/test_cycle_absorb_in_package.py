"""cycle_absorb wiring — Gap 60 (s68).

Pins that cycle_absorb invokes the in-package implementation and runs cleanly
with NO sibling absorb-knowledge.py on disk (the original pipx failure mode).
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from seif.context.cycle import _find_absorb_script, cycle_absorb


def _write_json(path: Path, obj: dict) -> None:
    path.write_text(json.dumps(obj), encoding="utf-8")


@pytest.fixture
def isolated_ctx(tmp_path: Path, monkeypatch) -> Path:
    """A workspace with .seif/ but no absorb-knowledge.py anywhere on disk.

    monkeypatch.chdir keeps `_find_absorb_script` registry/home lookups from
    finding any real seif-admin install on the developer's machine.
    """
    # Isolate HOME so step 4 (~/.seif/scripts/absorb-knowledge.py) cannot match
    monkeypatch.setenv("HOME", str(tmp_path))
    workspace = tmp_path / "ws"
    workspace.mkdir()
    ctx = workspace / ".seif"
    ctx.mkdir()
    # Make ctx detectable via marker
    (ctx / "memory_state.json").write_text("{}", encoding="utf-8")
    monkeypatch.chdir(workspace)
    return ctx


def test_cycle_absorb_runs_with_no_sibling_script(isolated_ctx: Path):
    """The original Gap 60 failure mode: pipx install + workspace lacks the
    standalone absorb-knowledge.py. cycle_absorb must succeed regardless.
    """
    _write_json(isolated_ctx / "absorption-v1.seif", {
        "protocol": "SEIF-ABSORPTION-v1",
        "session": "test-session",
        "summary": "Gap 60 regression",
    })

    output = cycle_absorb(str(isolated_ctx))

    assert "in-package" in output
    assert "FULL" in output
    assert "1 files" in output
    # Confirm receipt + memory_state were written into ctx
    assert (isolated_ctx / "memory_state.json").read_text() != "{}"
    assert any(p.name.startswith("absorption-receipt-") for p in isolated_ctx.iterdir())


def test_cycle_absorb_empty_workspace_reports_status(isolated_ctx: Path):
    output = cycle_absorb(str(isolated_ctx))
    assert "in-package" in output
    assert "EMPTY" in output
    # Receipt file still emitted (in-package always reports)
    assert any(p.name.startswith("absorption-receipt-") for p in isolated_ctx.iterdir())


def test_cycle_absorb_does_not_invoke_subprocess(monkeypatch, isolated_ctx: Path):
    """Defensive: cycle_absorb post-Gap-60 must not shell out to python3.

    If a future regression reintroduces subprocess.run for the absorb path the
    test will fail because the boom() patch will fire.
    """
    import seif.context.cycle as cycle_mod
    # subprocess module was dropped at top-level; verify import is gone
    assert not hasattr(cycle_mod, "subprocess"), \
        "cycle.py should no longer import subprocess (Gap 60 close)"

    cycle_absorb(str(isolated_ctx))  # should not raise


def test_legacy_script_notice_when_present(tmp_path: Path, monkeypatch):
    """If a legacy absorb-knowledge.py is on disk next to .seif, cycle_absorb
    surfaces a 'Notice' line so operators know the script is superseded.
    """
    monkeypatch.setenv("HOME", str(tmp_path))
    workspace = tmp_path / "admin"
    workspace.mkdir()
    ctx = workspace / ".seif"
    ctx.mkdir()
    (ctx / "memory_state.json").write_text("{}", encoding="utf-8")
    legacy = workspace / "absorb-knowledge.py"
    legacy.write_text("# legacy\n", encoding="utf-8")
    monkeypatch.chdir(workspace)

    output = cycle_absorb(str(ctx))
    assert "Notice" in output
    assert "superseded" in output
    assert str(legacy) in output


def test_find_absorb_script_returns_none_when_absent(isolated_ctx: Path):
    assert _find_absorb_script(isolated_ctx) is None
