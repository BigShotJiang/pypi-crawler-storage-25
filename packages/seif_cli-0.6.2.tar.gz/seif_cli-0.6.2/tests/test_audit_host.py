"""Tests for cmd_audit_host (host-level structural audit)."""

import io
import json
import os
import sys
import tempfile
import time
import unittest
from contextlib import redirect_stdout
from pathlib import Path

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from seif.cli import cli as cli_module
from seif.context import host_init as hi
from seif.context import model_probe as mp
from seif.context import registry as reg
from seif.data import paths as paths_module


class TestAuditHost(unittest.TestCase):

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="seif_audit_"))
        self.home = self.tmp / "home_seif"
        self.home.mkdir()
        self.cwd = self.tmp / "workspace"
        self.cwd.mkdir()
        self._cwd_orig = os.getcwd()
        os.chdir(self.cwd)
        self._restore = self._monkey_home(self.home)
        self._original_ephemeral = reg.EPHEMERAL_PATH_PARTS
        reg.EPHEMERAL_PATH_PARTS = ()

    def tearDown(self):
        import shutil
        os.chdir(self._cwd_orig)
        reg.EPHEMERAL_PATH_PARTS = self._original_ephemeral
        self._restore()
        shutil.rmtree(self.tmp, ignore_errors=True)

    def _monkey_home(self, home):
        orig_paths = paths_module.get_user_home
        orig_hi = hi.get_user_home
        orig_mp = mp.get_user_home
        orig_reg = reg.get_user_home
        paths_module.get_user_home = lambda: home
        hi.get_user_home = lambda: home
        mp.get_user_home = lambda: home
        reg.get_user_home = lambda: home

        def restore():
            paths_module.get_user_home = orig_paths
            hi.get_user_home = orig_hi
            mp.get_user_home = orig_mp
            reg.get_user_home = orig_reg
        return restore

    def _capture(self, **kwargs):
        buf = io.StringIO()
        with redirect_stdout(buf):
            cli_module.cmd_audit_host(**kwargs)
        return buf.getvalue()

    def test_audit_reports_all_layers(self):
        out = self._capture(fix=False)
        self.assertIn("Protocol", out)
        self.assertIn("Init-generated", out)
        self.assertIn("Per-host", out)
        self.assertIn("Heartbeat", out)
        self.assertIn("Summary:", out)

    def test_audit_detects_missing_machine_id(self):
        out = self._capture(fix=False)
        self.assertIn("machine_id", out)
        self.assertIn("MISSING", out)

    def test_audit_fix_creates_machine_id(self):
        self.assertFalse((self.home / "machine_id").exists())
        # Set a stale model_registry too so we exercise both fixers.
        from unittest.mock import patch
        # Stub probe_all so the audit doesn't actually hit the network.
        with patch.object(mp, "probe_all", return_value=mp.ProbeResult(
                models=[], circuit={"connected": False, "error": "x"},
                health={}, duration_ms=1)):
            out = self._capture(fix=True)
        self.assertTrue((self.home / "machine_id").exists())
        self.assertIn("Auto-fixing", out)

    def test_audit_skips_workspace_layer_when_no_dot_seif(self):
        out = self._capture(fix=False)
        # No .seif/ in cwd — Layer C workspace files (mapper/nucleus) shouldn't
        # appear as findings (they're scoped to in-workspace audits).
        self.assertNotIn(".seif/mapper.json", out)
        self.assertNotIn(".seif/nucleus.seif", out)

    def test_audit_detects_workspace_files(self):
        seif_dir = self.cwd / ".seif"
        seif_dir.mkdir()
        # No mapper.json or nucleus.seif yet — should be flagged
        out = self._capture(fix=False)
        self.assertIn(".seif/mapper.json", out)
        self.assertIn(".seif/nucleus.seif", out)


if __name__ == "__main__":
    unittest.main()
