"""Tests for scripts/check_pointer_sync.py — cross-AI pointer enforcement."""

from __future__ import annotations

import importlib.util
import sys
import tempfile
import unittest
from pathlib import Path


# Import the script as a module without installing it as a package
SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "check_pointer_sync.py"
spec = importlib.util.spec_from_file_location("check_pointer_sync", SCRIPT)
mod = importlib.util.module_from_spec(spec)
sys.modules["check_pointer_sync"] = mod
spec.loader.exec_module(mod)


def _make_repo(tmpdir: Path, seif_content: str = "# SEIF\n\nCanonical.\n",
               pointers: dict[str, str] | None = None) -> Path:
    repo = tmpdir / "repo"
    repo.mkdir()
    (repo / "SEIF.md").write_text(seif_content)
    if pointers:
        for rel, content in pointers.items():
            p = repo / rel
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(content)
    return repo


class CheckPointerSyncTests(unittest.TestCase):

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.tmpdir = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def test_passes_when_no_pointers_present(self):
        repo = _make_repo(self.tmpdir)
        self.assertEqual(mod.check_repo(repo), 0)

    def test_passes_when_pointer_short_and_references_seif_md(self):
        repo = _make_repo(self.tmpdir, pointers={
            "CLAUDE.md": "# Claude\nRead SEIF.md first.\n",
            "AGENTS.md": "Read [`SEIF.md`](SEIF.md).\n",
        })
        self.assertEqual(mod.check_repo(repo), 0)

    def test_fails_when_seif_md_missing(self):
        repo = self.tmpdir / "repo"
        repo.mkdir()
        # No SEIF.md
        self.assertEqual(mod.check_repo(repo), 2)

    def test_fails_when_seif_md_empty(self):
        repo = _make_repo(self.tmpdir, seif_content="")
        self.assertEqual(mod.check_repo(repo), 2)

    def test_fails_when_pointer_misses_seif_reference(self):
        repo = _make_repo(self.tmpdir, pointers={
            "CLAUDE.md": "# Claude\nRandom content with no canonical reference.\n",
        })
        self.assertEqual(mod.check_repo(repo), 1)

    def test_fails_when_pointer_too_long(self):
        long_body = "Read SEIF.md.\n" + ("filler line\n" * 100)
        repo = _make_repo(self.tmpdir, pointers={"GEMINI.md": long_body})
        self.assertEqual(mod.check_repo(repo), 1)

    def test_fails_when_pointer_has_cross_ai_heading(self):
        body = (
            "Read SEIF.md.\n"
            "\n"
            "## Project Identity\n"
            "S.E.I.F. is...\n"
        )
        repo = _make_repo(self.tmpdir, pointers={"CLAUDE.md": body})
        self.assertEqual(mod.check_repo(repo), 1)

    def test_copilot_path_not_enforced(self):
        # .github/copilot-instructions.md is intentionally NOT in POINTER_FILES
        # (dual semantics: can be pointer OR PR-review instructions).
        repo = _make_repo(self.tmpdir, pointers={
            ".github/copilot-instructions.md": "arbitrary content, no SEIF reference\n",
        })
        self.assertEqual(mod.check_repo(repo), 0)

    def test_long_seif_md_is_fine_only_pointers_capped(self):
        # SEIF.md itself can be arbitrarily long — only pointers are capped
        long_seif = "# SEIF\n" + ("body line\n" * 500)
        repo = _make_repo(self.tmpdir, seif_content=long_seif, pointers={
            "CLAUDE.md": "Read SEIF.md.\n",
        })
        self.assertEqual(mod.check_repo(repo), 0)


if __name__ == "__main__":
    unittest.main()
