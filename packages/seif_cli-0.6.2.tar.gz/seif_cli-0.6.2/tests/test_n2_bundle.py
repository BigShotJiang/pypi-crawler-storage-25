"""Tests for SEIF-N2-BUNDLE-v1 weekly signing tier-3.

s60 PR5 (rank 3). Covers emit/sign/verify, drift detection, post-bundle
amendment-chain semantics, re-emit protection, and key/window guards.
"""

from __future__ import annotations

import base64
import json
from datetime import datetime, timezone
from pathlib import Path

import pytest


# ── Shared fixtures ────────────────────────────────────────────────


@pytest.fixture
def temp_keys(tmp_path, monkeypatch):
    """Fake ~/.seif/keys/ + generate a test keypair there."""
    fake_home = tmp_path / "fake-home" / ".seif"
    fake_home.mkdir(parents=True)

    from seif.core import signing as signing_mod
    monkeypatch.setattr(signing_mod, "get_user_home", lambda: fake_home)

    priv, pub = signing_mod.keygen(force=True)
    return priv, pub


@pytest.fixture
def workspace_with_artifacts(tmp_path):
    """Create a tmp workspace with .seif/ + RESONANCE.json + 2 SEALED cycles + 1 seed.

    SEALED cycles fall in ISO week W2026-W18 (Mon 2026-04-27 → Sun 2026-05-03).
    """
    ws = tmp_path / "ws"
    seif = ws / ".seif"
    cycles = seif / "cycles"
    seeds = seif / "seeds"
    cycles.mkdir(parents=True)
    seeds.mkdir(parents=True)

    # RESONANCE.json with kernel_anchor fields the bundle reads
    res = {
        "protocol": "SEIF-RESONANCE-v2",
        "cryptographic_identity": {
            "algorithm": "Ed25519",
            "key_fingerprint": "fpfpfpfpfpfpfpfp",
            "content_signature": {
                "key_fingerprint": "fpfpfpfpfpfpfpfp",
                "canonical_hash_method": "sha256_of_canonical_json_excluding_content_signature",
                "canonical_hash": "deadbeef" * 8,
            },
        },
        "axioms": {"A1": "minimal"},
    }
    (ws / "RESONANCE.json").write_text(json.dumps(res, indent=2))

    # SEALED cycle A — 2026-04-28 (in W2026-W18)
    cyc_a = {
        "protocol": "SEIF-CYCLE-v1",
        "cycle_id": "s99-test-alpha",
        "status": "SEALED",
        "sealed_at": "2026-04-28T12:00:00Z",
        "kernel_anchor": {"canonical_hash": "deadbeef" * 8},
    }
    (cycles / "s99-test-alpha-SEALED.seif").write_text(json.dumps(cyc_a, indent=2))

    # SEALED cycle B — 2026-04-30 (in W2026-W18)
    cyc_b = {
        "protocol": "SEIF-CYCLE-v1",
        "cycle_id": "s100-test-beta",
        "status": "SEALED",
        "sealed_at": "2026-04-30T09:00:00Z",
        "kernel_anchor": {"canonical_hash": "deadbeef" * 8},
    }
    (cycles / "s100-test-beta-SEALED.seif").write_text(json.dumps(cyc_b, indent=2))

    # SEED in same week
    seed = {
        "protocol": "SEIF-SEED-v2",
        "seed_id": "s99-2026-04-28-test",
        "issued_at": "2026-04-28T12:30:00Z",
    }
    (seeds / "SEED-s99-2026-04-28.json").write_text(json.dumps(seed, indent=2))

    return ws


# ── Tests ──────────────────────────────────────────────────────────


def test_n2_bundle_basic_emit(temp_keys, workspace_with_artifacts):
    from seif.core.n2_bundle import emit_bundle

    result = emit_bundle(
        workspace=workspace_with_artifacts,
        week="W2026-W18",
        actor="test-actor",
    )

    assert result["status"] == "emitted", result
    assert result["bundle_id"] == "N2-BUNDLE-W2026-W18"
    assert result["cycle_count"] == 2
    assert result["seed_count"] == 1

    bundle_path = Path(result["bundle_path"])
    assert bundle_path.is_file()
    assert bundle_path.name == "N2-BUNDLE-W2026-W18.json"

    doc = json.loads(bundle_path.read_text())
    assert doc["protocol"] == "SEIF-N2-BUNDLE-v1"
    assert doc["bundle_id"] == "N2-BUNDLE-W2026-W18"
    assert doc["iso_week"]["year"] == 2026
    assert doc["iso_week"]["week"] == 18
    assert "content_signature" in doc
    assert doc["content_signature"]["algorithm"] == "Ed25519"
    assert "canonical_hash" in doc["content_signature"]

    # Schema validator passes
    from seif.schemas.n2_bundle import validate_bundle
    ok, reason = validate_bundle(doc)
    assert ok, reason


def test_n2_bundle_canonical_hash_stable(temp_keys, workspace_with_artifacts):
    """Re-building the same bundle dict from the same FS yields the same canonical_hash.

    NOTE: full emit_bundle() includes issued_at/signed_at timestamps, which are
    expected to differ. This test verifies the *canonical_hash* over content is
    stable when content is fixed. We use build_bundle() (unsigned) and override
    issued_at to isolate content-only.
    """
    from seif.core.n2_bundle import build_bundle, _canonical_hash

    a = build_bundle(workspace=workspace_with_artifacts, week="W2026-W18", actor="t")
    b = build_bundle(workspace=workspace_with_artifacts, week="W2026-W18", actor="t")
    # Strip timestamps that vary between builds
    a["issued_at"] = "2026-04-28T00:00:00Z"
    b["issued_at"] = "2026-04-28T00:00:00Z"
    assert _canonical_hash(a) == _canonical_hash(b)


def test_n2_bundle_signature_verifies(temp_keys, workspace_with_artifacts):
    from seif.core.n2_bundle import emit_bundle, verify_bundle

    result = emit_bundle(workspace=workspace_with_artifacts, week="W2026-W18", stamp_ots=False)
    bundle_path = result["bundle_path"]

    v = verify_bundle(bundle_path, workspace=workspace_with_artifacts)
    assert v["status"] == "valid", v
    assert v["valid"] is True
    assert v["signature_valid"] is True
    assert v["body_canonical_hash_match"] is True
    assert v["kernel_anchor_match"] is True
    assert v["cycle_findings"] == []
    assert v["seed_findings"] == []


def test_n2_bundle_detects_cycle_tamper(temp_keys, workspace_with_artifacts):
    """Mutating a bundled cycle file (without using the re-seal API) is cycle_drift."""
    from seif.core.n2_bundle import emit_bundle, verify_bundle

    result = emit_bundle(workspace=workspace_with_artifacts, week="W2026-W18", stamp_ots=False)
    bundle_path = result["bundle_path"]

    # Tamper one of the SEALED cycle files
    target = workspace_with_artifacts / ".seif" / "cycles" / "s99-test-alpha-SEALED.seif"
    cur = json.loads(target.read_text())
    cur["evil_added_after_bundle"] = True
    target.write_text(json.dumps(cur, indent=2))

    v = verify_bundle(bundle_path, workspace=workspace_with_artifacts)
    assert v["status"] == "cycle_drift", v
    assert v["valid"] is False
    kinds = {f["kind"] for f in v["cycle_findings"]}
    assert "cycle_sha_mismatch" in kinds


def test_n2_bundle_detects_body_tamper(temp_keys, workspace_with_artifacts):
    """Editing the bundle body itself after sign breaks body_canonical_hash_match."""
    from seif.core.n2_bundle import emit_bundle, verify_bundle

    result = emit_bundle(workspace=workspace_with_artifacts, week="W2026-W18", stamp_ots=False)
    bundle_path = Path(result["bundle_path"])

    # Tamper the bundle body
    doc = json.loads(bundle_path.read_text())
    doc["cycles"].append({
        "slug": "s999-fake",
        "cycle_id": "s999-fake",
        "sealed_at": "2026-04-28T00:00:00Z",
        "sealed_path": ".seif/cycles/s999-fake-SEALED.seif",
        "sha256": "0" * 64,
        "re_seal_history_length": 0,
        "ots_present": False,
    })
    bundle_path.write_text(json.dumps(doc, indent=2))

    v = verify_bundle(bundle_path, workspace=workspace_with_artifacts)
    assert v["status"] == "body_tampered", v
    assert v["valid"] is False
    assert v["body_canonical_hash_match"] is False


def test_n2_bundle_post_bundle_amendment_is_drift_not_failure(
    temp_keys, workspace_with_artifacts
):
    """Adding a re_seal_history entry AFTER bundling is informational drift, not failure.

    Per amendment-chain semantics: SEALED cycles can grow re_seal_history[]; the
    bundle records the snapshot at bundle-time. A later, properly chained
    amendment is reported as `post_bundle_amendment` with overall valid=True.
    """
    from seif.core.n2_bundle import emit_bundle, verify_bundle

    result = emit_bundle(workspace=workspace_with_artifacts, week="W2026-W18", stamp_ots=False)
    bundle_path = result["bundle_path"]

    # Append an amendment to one cycle (legitimate post-bundle re-seal).
    target = workspace_with_artifacts / ".seif" / "cycles" / "s99-test-alpha-SEALED.seif"
    cur = json.loads(target.read_text())
    cur["re_seal_history"] = [
        {
            "re_sealed_at": "2026-05-04T00:00:00Z",
            "re_seal_rationale": "post-bundle amendment",
            "deltas": ["d1"],
            "re_sealed_by": "test",
        }
    ]
    target.write_text(json.dumps(cur, indent=2))

    v = verify_bundle(bundle_path, workspace=workspace_with_artifacts)
    # status='partial' (informational), valid=True
    assert v["status"] == "partial", v
    assert v["valid"] is True
    kinds = {f["kind"] for f in v["cycle_findings"]}
    assert "post_bundle_amendment" in kinds


def test_n2_bundle_refuses_without_private_key(tmp_path, monkeypatch, workspace_with_artifacts):
    """Per A22, emit must fail loudly without the Owner private key."""
    fake_home = tmp_path / "no-key-home" / ".seif"
    fake_home.mkdir(parents=True)

    from seif.core import signing as signing_mod
    monkeypatch.setattr(signing_mod, "get_user_home", lambda: fake_home)

    from seif.core.n2_bundle import emit_bundle

    with pytest.raises(FileNotFoundError, match="A22"):
        emit_bundle(workspace=workspace_with_artifacts, week="W2026-W18", stamp_ots=False)


def test_n2_bundle_empty_week_refused(temp_keys, workspace_with_artifacts):
    """A week with 0 SEALED cycles + 0 seeds is refused with status=error."""
    from seif.core.n2_bundle import emit_bundle

    # W2026-W01 has no artifacts in this fixture
    result = emit_bundle(workspace=workspace_with_artifacts, week="W2026-W01", stamp_ots=False)
    assert result["status"] == "error", result
    assert "Empty week" in result["message"]


def test_n2_bundle_v2_on_re_emit(temp_keys, workspace_with_artifacts):
    """Re-emitting the same week writes .json.v2 — v1 is preserved verbatim."""
    from seif.core.n2_bundle import emit_bundle

    r1 = emit_bundle(workspace=workspace_with_artifacts, week="W2026-W18", stamp_ots=False)
    p1 = Path(r1["bundle_path"])
    assert p1.name.endswith(".json")
    v1_bytes_before = p1.read_bytes()

    r2 = emit_bundle(workspace=workspace_with_artifacts, week="W2026-W18", stamp_ots=False)
    p2 = Path(r2["bundle_path"])
    assert p2.name.endswith(".json.v2")
    assert r2.get("is_re_emit") is True

    # v1 still intact byte-for-byte
    assert p1.read_bytes() == v1_bytes_before

    # A third emit goes to .json.v3
    r3 = emit_bundle(workspace=workspace_with_artifacts, week="W2026-W18", stamp_ots=False)
    p3 = Path(r3["bundle_path"])
    assert p3.name.endswith(".json.v3")


def test_n2_bundle_kernel_rotation_warning(temp_keys, workspace_with_artifacts):
    """Kernel rotation between bundle-time and verify-time is warn (default) / fail (--strict)."""
    from seif.core.n2_bundle import emit_bundle, verify_bundle

    result = emit_bundle(workspace=workspace_with_artifacts, week="W2026-W18", stamp_ots=False)
    bundle_path = result["bundle_path"]

    # Rotate the workspace RESONANCE.json (simulate kernel rotation)
    res_path = workspace_with_artifacts / "RESONANCE.json"
    cur = json.loads(res_path.read_text())
    cur["cryptographic_identity"]["content_signature"]["canonical_hash"] = "feedface" * 8
    cur["cryptographic_identity"]["content_signature"]["key_fingerprint"] = "newkeynewkeynew1"
    cur["cryptographic_identity"]["key_fingerprint"] = "newkeynewkeynew1"
    res_path.write_text(json.dumps(cur, indent=2))

    # Default: warn (valid=True, status=kernel_rotated)
    v = verify_bundle(bundle_path, workspace=workspace_with_artifacts)
    assert v["status"] == "kernel_rotated", v
    assert v["valid"] is True
    assert v["kernel_anchor_match"] is False

    # --strict: fail (valid=False)
    v2 = verify_bundle(bundle_path, workspace=workspace_with_artifacts, strict=True)
    assert v2["status"] == "kernel_rotated"
    assert v2["valid"] is False
