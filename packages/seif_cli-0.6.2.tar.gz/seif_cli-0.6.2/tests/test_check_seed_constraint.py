"""Tests for seed-constraint matcher (s46 p2).

Pre-fix: SEED-*.json files declare prohibitions under
`what_NOT_to_do_during`, but the AI workflow had no programmatic gate
that could be invoked before host-touching actions. Operators
sometimes pre-approved forward motion without re-reading the seed,
and the AI inherited the approval and acted, violating the
constraint.

Post-fix:
- `check_seed_constraint(action, seif_dir)` walks active (unconsumed)
  seeds, collects prohibitions from `_PROHIBITION_KEYS`, and matches
  any significant action token (whole-word, case-insensitive) against
  each constraint.
- Returns a structured result with `allowed`, `blocking_seed`,
  `blocking_constraint`, `matched_token`, and `active_seeds_checked`.
- The `seif --check-seed-constraint ACTION` CLI surface dispatches
  the same logic with exit codes 0 (allowed), 1 (blocked), 2 (no
  active seeds OR no .seif/).
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from seif.context.seed_constraint import (  # noqa: E402
    _constraint_matches,
    _significant_tokens,
    check_seed_constraint,
)


class SignificantTokensTests(unittest.TestCase):
    def test_drops_short_words(self):
        # All tokens here are <4 chars and not flag-like: filtered out.
        self.assertEqual(_significant_tokens("on the air"), [])

    def test_keeps_long_words(self):
        toks = _significant_tokens("self-update on air-m1")
        self.assertIn("self-update", toks)
        self.assertIn("air-m1", toks)

    def test_keeps_flag_like_short(self):
        toks = _significant_tokens("run -f now")
        self.assertIn("-f", toks)

    def test_keeps_double_dash_flags(self):
        toks = _significant_tokens("--rm dir")
        self.assertIn("--rm", toks)

    def test_lowercases(self):
        self.assertEqual(_significant_tokens("AIR-M1"), ["air-m1"])

    def test_empty_input(self):
        self.assertEqual(_significant_tokens(""), [])


class ConstraintMatchesTests(unittest.TestCase):
    def test_whole_word_hit(self):
        self.assertEqual(
            _constraint_matches("Do NOT log secrets", ["log"]),
            "log",
        )

    def test_substring_no_partial_match(self):
        # "log" should NOT match inside "logging" — whole-word boundary
        self.assertIsNone(
            _constraint_matches("the logging system", ["log"]),
        )

    def test_hyphenated_token_in_backticks(self):
        constraint = "Do NOT run `seif --self-update` on Mini."
        self.assertEqual(
            _constraint_matches(constraint, ["self-update"]),
            "self-update",
        )

    def test_case_insensitive(self):
        self.assertEqual(
            _constraint_matches("Do NOT touch ~/Library/LaunchAgents/",
                                ["launchagents"]),
            "launchagents",
        )

    def test_no_tokens(self):
        self.assertIsNone(_constraint_matches("anything", []))

    def test_empty_constraint(self):
        self.assertIsNone(_constraint_matches("", ["anything"]))


class CheckSeedConstraintTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.seif_dir = Path(self.tmp.name) / ".seif"
        self.seeds_dir = self.seif_dir / "seeds"
        self.seeds_dir.mkdir(parents=True)

    def tearDown(self):
        self.tmp.cleanup()

    def _write_seed(self, name: str, *, seed_id: str, prohibitions: list[str],
                    key: str = "what_NOT_to_do_during",
                    consumed: bool = False) -> Path:
        path = self.seeds_dir / name
        path.write_text(
            json.dumps(
                {
                    "protocol": "SEIF-SEED-v1",
                    "seed_id": seed_id,
                    "issued_at": "2026-05-03T00:00:00Z",
                    key: prohibitions,
                },
                indent=2,
            ),
            encoding="utf-8",
        )
        if consumed:
            path.with_suffix(path.suffix + ".consumed_at").write_text("now")
        return path

    def test_allowed_when_no_seeds(self):
        result = check_seed_constraint("self-update", self.seif_dir)
        self.assertTrue(result["allowed"])
        self.assertEqual(result["active_seeds_checked"], 0)

    def test_allowed_when_no_constraints(self):
        self._write_seed("SEED-empty.json", seed_id="empty",
                         prohibitions=[])
        result = check_seed_constraint("self-update", self.seif_dir)
        self.assertTrue(result["allowed"])
        self.assertEqual(result["active_seeds_checked"], 1)

    def test_blocked_by_matching_constraint(self):
        self._write_seed(
            "SEED-soak.json",
            seed_id="s44-soak",
            prohibitions=[
                "Do NOT run `seif --self-update` on Mini or Air unless rollback.",
            ],
        )
        result = check_seed_constraint("self-update on air-m1",
                                       self.seif_dir)
        self.assertFalse(result["allowed"])
        self.assertEqual(result["blocking_seed"], "s44-soak")
        self.assertEqual(result["matched_token"], "self-update")
        self.assertIn("self-update", result["blocking_constraint"])

    def test_allowed_when_action_does_not_match(self):
        self._write_seed(
            "SEED-soak.json",
            seed_id="s44-soak",
            prohibitions=["Do NOT clone seif-engine on Air."],
        )
        result = check_seed_constraint("audit canonical layout",
                                       self.seif_dir)
        self.assertTrue(result["allowed"])

    def test_consumed_seed_ignored(self):
        self._write_seed(
            "SEED-old.json",
            seed_id="s40-old",
            prohibitions=["Do NOT run --self-update."],
            consumed=True,
        )
        result = check_seed_constraint("self-update", self.seif_dir)
        self.assertTrue(result["allowed"])
        self.assertEqual(result["active_seeds_checked"], 0)

    def test_first_blocking_seed_wins(self):
        self._write_seed(
            "SEED-a.json",
            seed_id="seed-a",
            prohibitions=["Do NOT clone seif-engine"],
        )
        self._write_seed(
            "SEED-b.json",
            seed_id="seed-b",
            prohibitions=["Do NOT run self-update"],
        )
        result = check_seed_constraint("self-update + clone seif-engine",
                                       self.seif_dir)
        self.assertFalse(result["allowed"])
        # SEED-a sorts before SEED-b lexically, and "clone" / "seif-engine"
        # match in SEED-a's constraint, so SEED-a should block first.
        self.assertEqual(result["blocking_seed"], "seed-a")

    def test_forbidden_key_alias(self):
        self._write_seed(
            "SEED-alt.json",
            seed_id="alt",
            prohibitions=["No --self-update during freeze."],
            key="forbidden",
        )
        result = check_seed_constraint("--self-update", self.seif_dir)
        self.assertFalse(result["allowed"])
        self.assertEqual(result["matched_token"], "--self-update")

    def test_invalid_json_seed_skipped(self):
        bad = self.seeds_dir / "SEED-bad.json"
        bad.write_text("{ not valid json", encoding="utf-8")
        self._write_seed(
            "SEED-good.json",
            seed_id="good",
            prohibitions=["Do NOT run --self-update."],
        )
        result = check_seed_constraint("--self-update", self.seif_dir)
        self.assertFalse(result["allowed"])
        self.assertEqual(result["blocking_seed"], "good")

    def test_no_seeds_dir(self):
        empty = Path(self.tmp.name) / "empty" / ".seif"
        empty.mkdir(parents=True)
        result = check_seed_constraint("anything", empty)
        self.assertTrue(result["allowed"])
        self.assertEqual(result["active_seeds_checked"], 0)


if __name__ == "__main__":
    unittest.main()
