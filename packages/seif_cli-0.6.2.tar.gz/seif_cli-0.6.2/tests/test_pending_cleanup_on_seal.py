"""Tests for cleanup_pending_after_seal (s44 INIT-FOUNDATION 3/4).

Closes the gap where session-43's Cohort B landed 4 items but the pending
module surface still counted them. Items now get stamped LANDED at session
close so the open-item count tells the truth at the next session-start.
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from seif.plugins.core.session_lifecycle import (  # noqa: E402
    cleanup_pending_after_seal,
    _pending_modules_summary,
)


def _write_pending(path: Path, items: list[dict], title: str = "test pending") -> None:
    path.write_text(
        json.dumps(
            {
                "protocol": "SEIF-PENDING-v1",
                "module_id": path.stem,
                "title": title,
                "items": items,
            },
            indent=2,
        ),
        encoding="utf-8",
    )


class CleanupPendingAfterSealTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.seif_dir = Path(self.tmp.name) / ".seif"
        (self.seif_dir / "modules").mkdir(parents=True)

    def tearDown(self):
        self.tmp.cleanup()

    def test_empty_landed_ids_is_noop(self):
        _write_pending(
            self.seif_dir / "modules" / "pending-x.seif",
            [{"id": "a"}, {"id": "b"}],
        )
        result = cleanup_pending_after_seal(self.seif_dir, [])
        self.assertEqual(result["files_updated"], 0)
        self.assertEqual(result["items_landed"], 0)

    def test_no_modules_dir_returns_not_found(self):
        result = cleanup_pending_after_seal(
            Path(self.tmp.name) / "does-not-exist", ["a"]
        )
        self.assertEqual(result["files_updated"], 0)
        self.assertEqual(result["items_not_found"], ["a"])

    def test_marks_matching_id_landed(self):
        path = self.seif_dir / "modules" / "pending-cohort-b.seif"
        _write_pending(
            path,
            [
                {"id": "B1-template-refresh", "severity": "MEDIUM"},
                {"id": "B2-pipx-rollback", "severity": "LOW"},
                {"id": "open-item", "severity": "HIGH"},
            ],
        )
        result = cleanup_pending_after_seal(
            self.seif_dir,
            ["B1-template-refresh", "B2-pipx-rollback"],
            session_id="session-43",
            at="2026-05-02T01:40:00Z",
        )
        self.assertEqual(result["files_updated"], 1)
        self.assertEqual(result["items_landed"], 2)
        self.assertEqual(result["items_not_found"], [])

        data = json.loads(path.read_text(encoding="utf-8"))
        items_by_id = {i["id"]: i for i in data["items"]}
        self.assertEqual(items_by_id["B1-template-refresh"]["landed_at"],
                         "2026-05-02T01:40:00Z")
        self.assertEqual(items_by_id["B1-template-refresh"]["landed_in_session"],
                         "session-43")
        self.assertEqual(items_by_id["B2-pipx-rollback"]["landed_at"],
                         "2026-05-02T01:40:00Z")
        self.assertNotIn("landed_at", items_by_id["open-item"])

    def test_idempotent_does_not_overwrite_existing_landed_at(self):
        path = self.seif_dir / "modules" / "pending-x.seif"
        _write_pending(
            path,
            [{"id": "a", "landed_at": "2026-04-01T00:00:00Z"}],
        )
        result = cleanup_pending_after_seal(
            self.seif_dir, ["a"], at="2026-05-02T01:40:00Z"
        )
        self.assertEqual(result["items_landed"], 0)
        self.assertEqual(result["items_already_landed"], 1)
        self.assertEqual(result["files_updated"], 0)

        data = json.loads(path.read_text(encoding="utf-8"))
        self.assertEqual(data["items"][0]["landed_at"], "2026-04-01T00:00:00Z")

    def test_unknown_id_reported_in_items_not_found(self):
        _write_pending(self.seif_dir / "modules" / "pending-x.seif",
                       [{"id": "a"}])
        result = cleanup_pending_after_seal(self.seif_dir, ["a", "ghost"])
        self.assertEqual(result["items_landed"], 1)
        self.assertEqual(result["items_not_found"], ["ghost"])

    def test_walks_multiple_pending_files(self):
        _write_pending(self.seif_dir / "modules" / "pending-old.seif",
                       [{"id": "x"}])
        _write_pending(self.seif_dir / "modules" / "pending-new.seif",
                       [{"id": "y"}])
        result = cleanup_pending_after_seal(
            self.seif_dir, ["x", "y"], at="2026-05-02T01:40:00Z"
        )
        self.assertEqual(result["files_updated"], 2)
        self.assertEqual(result["items_landed"], 2)

    def test_skips_files_without_protocol_match(self):
        # File whose `items` is not a list (e.g., a different schema) is
        # silently skipped.
        path = self.seif_dir / "modules" / "pending-weird.seif"
        path.write_text(
            json.dumps({"protocol": "SEIF-PENDING-v1", "items": "wrong"}),
            encoding="utf-8",
        )
        result = cleanup_pending_after_seal(self.seif_dir, ["a"])
        self.assertEqual(result["files_updated"], 0)
        self.assertEqual(result["items_landed"], 0)


class PendingModulesSummaryFiltersLandedTests(unittest.TestCase):
    """Surface tells the truth about open vs landed items."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.seif_dir = Path(self.tmp.name) / ".seif"
        (self.seif_dir / "modules").mkdir(parents=True)

    def tearDown(self):
        self.tmp.cleanup()

    def test_no_pending_modules_returns_empty(self):
        self.assertEqual(_pending_modules_summary(self.seif_dir), [])

    def test_count_excludes_landed_items(self):
        _write_pending(
            self.seif_dir / "modules" / "pending-cohort-b.seif",
            [
                {"id": "B1", "landed_at": "2026-05-02T01:40:00Z"},
                {"id": "B2", "landed_at": "2026-05-02T01:40:00Z"},
                {"id": "open-1"},
                {"id": "open-2"},
            ],
            title="Cohort B + remaining work",
        )
        out = _pending_modules_summary(self.seif_dir)
        self.assertTrue(any("2 open items" in line for line in out))
        self.assertTrue(any("2 landed (not counted)" in line for line in out))
        self.assertTrue(any("(+2 landed)" in line for line in out))

    def test_all_landed_still_emits_audit_visibility(self):
        _write_pending(
            self.seif_dir / "modules" / "pending-x.seif",
            [
                {"id": "a", "landed_at": "2026-05-02T01:40:00Z"},
                {"id": "b", "landed_at": "2026-05-02T01:40:00Z"},
            ],
        )
        out = _pending_modules_summary(self.seif_dir)
        self.assertTrue(any("0 open items" in line for line in out))
        self.assertTrue(any("2 landed" in line for line in out))


if __name__ == "__main__":
    unittest.main()
