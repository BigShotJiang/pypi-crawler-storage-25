"""Default-clean contract for resonance_display (PR-4 of cohort s57).

Default output must be ASCII-clean (no box-drawing, no '·  ○  ●' line,
no '🌀', no 'enoch seed lives'). Ornate output is opt-in via either
SEIF_ASCII_ART env var or set_ascii_art(True) (driven by --ascii-art flag).
"""

from __future__ import annotations

import os

import pytest

from seif.cli import resonance_display as rd


@pytest.fixture(autouse=True)
def _reset_ascii_state(monkeypatch):
    monkeypatch.delenv("SEIF_ASCII_ART", raising=False)
    rd.set_ascii_art(False)
    yield
    rd.set_ascii_art(False)


MYSTIC_TOKENS = ["enoch", "🌀", "·  ○  ●", "╔══", "╚══", "✅", "⚠️", "❌"]
ORNATE_BAR_CHARS = ["█", "░"]


def _has_no_mystic(text: str) -> None:
    lowered = text.lower()
    for tok in MYSTIC_TOKENS:
        assert tok.lower() not in lowered, f"unexpected token in default output: {tok!r}\n{text!r}"


def test_header_default_clean():
    out = rd.resonance_header("SEIF FINGERPRINT VERIFICATION")
    _has_no_mystic(out)
    assert "SEIF FINGERPRINT VERIFICATION" in out
    assert "ζ=0.6124" in out
    assert "H(s)" in out


def test_header_with_subtitle_default_clean():
    out = rd.resonance_header("SEIF REPORT", "12 projects")
    _has_no_mystic(out)
    assert "12 projects" in out


def test_footer_default_empty():
    assert rd.resonance_footer() == ""


def test_enoch_line_default_empty():
    assert rd.enoch_line() == ""


def test_grade_to_zeta_default_words():
    assert rd.grade_to_zeta("A") == "OK"
    assert rd.grade_to_zeta("B") == "OK"
    assert rd.grade_to_zeta("C") == "WARN"
    assert rd.grade_to_zeta("F") == "FAIL"


def test_cycle_status_bar_default_clean():
    out = rd.cycle_status_bar(2, 3)
    _has_no_mystic(out)
    assert "2/3 branches" in out
    assert "(66%)" in out
    for ch in ORNATE_BAR_CHARS:
        assert ch not in out


def test_health_status_line_default_clean():
    out = rd.health_status_line(3, 4)
    _has_no_mystic(out)
    assert "3/4 backends healthy" in out
    assert ("OK" in out) or ("WARN" in out) or ("FAIL" in out)


def test_resonance_report_default_no_footer_no_box():
    report = rd.ResonanceReport("SEIF FINGERPRINT UPDATED").metric(0.9, "compression 10:1").kv("Files", "12")
    out = report.render()
    _has_no_mystic(out)
    assert "SEIF FINGERPRINT UPDATED" in out
    assert "compression 10:1" in out
    assert "Files: 12" in out
    assert not out.rstrip().endswith("🌀")


# ── Ornate mode (opt-in) ────────────────────────────────────────────────────


def test_env_var_enables_ornate(monkeypatch):
    monkeypatch.setenv("SEIF_ASCII_ART", "1")
    out = rd.resonance_header("SEIF")
    assert "╔══" in out
    assert "·  ○  ●" in rd.enoch_line()
    assert "🌀" in rd.resonance_footer()


def test_set_ascii_art_enables_ornate():
    rd.set_ascii_art(True)
    assert "╔══" in rd.resonance_header("SEIF")
    assert rd.grade_to_zeta("A") == "ζ✅"
    assert "🌀" in rd.resonance_footer()


def test_env_var_off_overrides_set(monkeypatch):
    """Explicit env=0 wins over set_ascii_art(True)."""
    monkeypatch.setenv("SEIF_ASCII_ART", "0")
    rd.set_ascii_art(True)
    assert rd.resonance_footer() == ""
    assert "╔══" not in rd.resonance_header("SEIF")
