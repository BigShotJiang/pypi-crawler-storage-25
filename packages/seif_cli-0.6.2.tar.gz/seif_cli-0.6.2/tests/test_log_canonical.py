"""Canonical JSON + SHA-256 — D3 client mirror of seif-log/api/canonical."""

from __future__ import annotations

import hashlib

from seif.log.canonical import canonical_json_bytes, canonical_sha256


def test_sorted_keys_are_canonical():
    a = canonical_json_bytes({"b": 1, "a": 2})
    b = canonical_json_bytes({"a": 2, "b": 1})
    assert a == b == b'{"a":2,"b":1}'


def test_compact_separators_no_whitespace():
    out = canonical_json_bytes({"a": [1, 2, 3], "b": {"c": "d"}})
    assert out == b'{"a":[1,2,3],"b":{"c":"d"}}'


def test_canonical_sha256_is_32_bytes():
    digest = canonical_sha256({"any": "thing"})
    assert isinstance(digest, bytes)
    assert len(digest) == 32


def test_canonical_sha256_matches_manual_hash():
    payload = {"x": 1, "y": "z"}
    expected = hashlib.sha256(b'{"x":1,"y":"z"}').digest()
    assert canonical_sha256(payload) == expected


def test_unicode_preserved_not_escaped():
    out = canonical_json_bytes({"name": "André"})
    assert out == '{"name":"André"}'.encode("utf-8")


def test_nested_keys_also_sorted():
    assert canonical_json_bytes({"o": {"z": 1, "a": 2}}) == b'{"o":{"a":2,"z":1}}'
