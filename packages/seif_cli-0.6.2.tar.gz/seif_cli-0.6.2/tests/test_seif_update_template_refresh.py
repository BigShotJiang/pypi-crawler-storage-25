"""Tests for s43 B1 — Stage 1.5 template-refresh in seif-update.sh.

After the package install succeeds, seif-update.sh copies its own canonical
template (shipped inside the package at seif/scripts/host/seif-update.sh) over
~/.seif/bin/seif-update.sh. Atomic via tmp+rename; non-fatal on failure.

These tests verify:
  - Stage 1.5 block exists and is positioned between Stage 1 and Stage 2
  - --no-template-refresh flag is parsed and surfaces in header
  - Template path is resolved via `import seif; Path(seif.__file__) / scripts / host / ...`
  - md5 no-op skip, atomic write via tmp+rename, +x permission preserved
  - Non-fatal failure modes: missing package source, missing dst file
"""

from __future__ import annotations

from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
SCRIPT = REPO_ROOT / "src" / "seif" / "scripts" / "host" / "seif-update.sh"


def _read_script() -> str:
    return SCRIPT.read_text()


def test_template_refresh_stage_block_exists():
    text = _read_script()
    assert "Stage 1.5: template refresh" in text, (
        "Stage 1.5 block must be present in canonical template"
    )


def test_template_refresh_stage_positioned_between_stage_1_and_stage_2():
    text = _read_script()
    s1_pos = text.find("Stage 1: package install")
    s15_pos = text.find("Stage 1.5: template refresh")
    s2_pos = text.find("Stage 2: bridge repo sync")
    assert 0 < s1_pos < s15_pos < s2_pos, (
        "Stage 1.5 must sit strictly between Stage 1 and Stage 2"
    )


def test_no_template_refresh_flag_is_parsed():
    text = _read_script()
    assert "--no-template-refresh)" in text, (
        "--no-template-refresh must be a parsed flag"
    )
    assert "TEMPLATE_REFRESH=0" in text, (
        "--no-template-refresh must set TEMPLATE_REFRESH=0"
    )


def test_template_refresh_default_on():
    text = _read_script()
    # Default is opt-out; TEMPLATE_REFRESH=1 must be set before flag parsing
    parse_block_start = text.find("# Parse flags. Order-independent.")
    parse_block_end = text.find("done", parse_block_start)
    assert parse_block_start > 0 and parse_block_end > parse_block_start
    parse_block = text[parse_block_start:parse_block_end]
    assert "TEMPLATE_REFRESH=1" in parse_block, (
        "TEMPLATE_REFRESH must default to 1 (opt-out semantics)"
    )


def test_header_surfaces_template_refresh_state():
    text = _read_script()
    assert 'template-refresh: $([ "$TEMPLATE_REFRESH" = "1" ]' in text, (
        "Header echo must reflect template-refresh state"
    )


def test_template_resolved_via_seif_package():
    text = _read_script()
    assert "import seif" in text, (
        "Template src must be resolved via `import seif; Path(seif.__file__)`"
    )
    assert "pathlib.Path(seif.__file__).parent / 'scripts' / 'host' / 'seif-update.sh'" in text, (
        "Resolved path must be <package>/scripts/host/seif-update.sh"
    )


def test_template_dst_is_user_seif_bin():
    text = _read_script()
    assert 'template_dst="$HOME/.seif/bin/seif-update.sh"' in text, (
        "Destination must be ~/.seif/bin/seif-update.sh"
    )


def test_md5_noop_branch_present():
    text = _read_script()
    # Both BSD (md5 -q) and GNU (md5sum) variants must be tried
    assert "md5 -q" in text and "md5sum" in text, (
        "Stage 1.5 must support both BSD and GNU md5 utilities"
    )
    assert 'if [ "$src_md5" = "$dst_md5" ]; then' in text, (
        "md5 equality must short-circuit with a no-op log"
    )
    assert "no change" in text, "no-op log line must be present"


def test_atomic_write_via_tmp_rename():
    text = _read_script()
    assert 'tmp_dst="${template_dst}.tmp.$$"' in text, (
        "Atomic write must use tmp file with $$ pid suffix"
    )
    assert 'mv "$tmp_dst" "$template_dst"' in text, (
        "Atomic rename must use mv on the tmp file"
    )


def test_executable_permission_preserved():
    text = _read_script()
    assert 'chmod +x "$tmp_dst"' in text, (
        "Executable bit must be set on tmp before rename"
    )


def test_failure_paths_are_non_fatal():
    """All four failure modes log + continue (no exit)."""
    text = _read_script()
    # Stage 1.5 block bounded by markers. Stage 1.6 (s44 kernel-verify)
    # was inserted between 1.5 and 2 and IS intentionally fatal — bound
    # on 1.6 so its `exit 1` is excluded from this stage's scan.
    s15_start = text.find("Stage 1.5: template refresh")
    s16_start = text.find("Stage 1.6:")
    s2_start = text.find("Stage 2: bridge repo sync")
    s15_end = s16_start if s16_start > 0 else s2_start
    block = text[s15_start:s15_end]

    # No bash-level `exit` in the block — every failure path is best-effort.
    # Strip the embedded Python heredoc (whose sys.exit() codes are caught
    # by `|| template_src=""` and don't bubble up to bash).
    py_start = block.find('python3 -c "')
    py_end = block.find('" 2>/dev/null)', py_start)
    bash_only = block[:py_start] + block[py_end:]
    # Match `exit <code>` with whitespace boundary (bash `exit` keyword)
    import re
    bash_exits = re.findall(r"\bexit\s+\d", bash_only)
    assert not bash_exits, (
        f"Stage 1.5 must be non-fatal — no bash `exit` allowed; found: {bash_exits}"
    )

    # All four expected log shapes
    assert "canonical template not found" in block
    assert "does not exist" in block
    assert "no change" in block
    assert "FAILED to write" in block


def test_tmp_file_cleanup_on_failure():
    text = _read_script()
    s15_start = text.find("Stage 1.5: template refresh")
    s15_end = text.find("Stage 2: bridge repo sync")
    block = text[s15_start:s15_end]
    assert 'rm -f "$tmp_dst"' in block, (
        "Failed atomic write must clean up the tmp file"
    )


def test_template_refresh_skip_logged_on_flag():
    text = _read_script()
    assert "skipped (--no-template-refresh)" in text, (
        "--no-template-refresh path must emit a skip log line"
    )


def test_canonical_template_ships_in_package():
    """The path the script will resolve at runtime must actually exist
    in the installed package layout."""
    template = REPO_ROOT / "src" / "seif" / "scripts" / "host" / "seif-update.sh"
    assert template.is_file(), (
        f"Canonical template must exist at {template} — "
        "B1 assumes scripts/host/* moved into package"
    )


def test_pyproject_includes_scripts_host_in_package_data():
    """package_data must declare scripts/host/* so wheels include them."""
    pyproject = (REPO_ROOT / "pyproject.toml").read_text()
    assert '"scripts/host/seif-update.sh"' in pyproject, (
        "pyproject.toml must include scripts/host/seif-update.sh in package_data"
    )
    assert '"scripts/host/host-install-config.sample.seif"' in pyproject, (
        "pyproject.toml must include sample config in package_data"
    )
