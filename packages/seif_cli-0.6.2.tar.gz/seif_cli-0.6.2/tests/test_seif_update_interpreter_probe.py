"""Tests for s41 P1 — seif-update.sh editable branch interpreter probe.

Regression: prior to this fix, the editable branch ran bare `pip install -e $src`
with a trailing `|| true` swallowing failures. On Mini during s40 deploy, the
`pip` shebang pointed at a removed `/usr/local/opt/python@3.9/bin/python3.9`
and the install silently no-op'd while --self-update reported success.

The fix:
  1. Probe `python3 -m pip --version`; fall back to `pip --version`.
  2. Use the discovered command for the install.
  3. Drop `|| true` so failures propagate via `set -euo pipefail`.
  4. On no-working-pip, print remediation and exit non-zero.
"""

from __future__ import annotations

import os
import subprocess
from pathlib import Path

import pytest

SCRIPT = (
    Path(__file__).resolve().parents[1]
    / "src"
    / "seif"
    / "scripts"
    / "host"
    / "seif-update.sh"
)


def test_script_exists_and_is_executable():
    assert SCRIPT.is_file()
    assert os.access(SCRIPT, os.X_OK), "seif-update.sh must be executable"


def test_editable_branch_uses_python3_m_pip_probe():
    """Canonical template must probe `python3 -m pip` before falling back."""
    text = SCRIPT.read_text()
    assert "python3 -m pip --version" in text, (
        "editable branch must probe `python3 -m pip --version`"
    )
    assert 'PIP_CMD="python3 -m pip"' in text


def test_editable_branch_drops_pipe_or_true():
    """`|| true` must NOT appear after `pip install -e` lines — failures must
    propagate so --self-update doesn't report success when pip silently
    failed (s40 Mini regression)."""
    text = SCRIPT.read_text()
    # Find the editable branch
    editable_start = text.find("  editable)")
    pipx_start = text.find("  pipx)", editable_start)
    assert editable_start != -1 and pipx_start != -1
    editable_block = text[editable_start:pipx_start]
    assert "|| true" not in editable_block, (
        "`|| true` swallows pip failures — must be removed for s41 P1"
    )


def test_editable_branch_emits_remediation_on_no_pip():
    """Remediation block must mention how to bootstrap pip."""
    text = SCRIPT.read_text()
    assert "no working pip found" in text
    assert "ensurepip" in text


def test_bash_syntax_valid():
    """`bash -n` must parse cleanly — protects against typo regressions."""
    result = subprocess.run(
        ["bash", "-n", str(SCRIPT)],
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, f"bash -n failed: {result.stderr}"


def test_probe_block_structure_complete():
    """The probe block must have all four branches: python3-m-pip ✓,
    pip fallback, no-pip remediation, install dispatch via $PIP_CMD."""
    text = SCRIPT.read_text()
    editable_start = text.find("  editable)")
    pipx_start = text.find("  pipx)", editable_start)
    block = text[editable_start:pipx_start]

    assert 'PIP_CMD="python3 -m pip"' in block
    assert 'PIP_CMD="pip"' in block
    assert "$PIP_CMD install -e" in block
    assert 'echo "✗ no working pip found"' in block
    assert "exit 1" in block
