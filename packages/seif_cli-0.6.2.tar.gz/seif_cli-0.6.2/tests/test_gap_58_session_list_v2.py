"""Regression tests for admin-docs Gap 58.

Pre-fix: --session list routed through _upgrade_message stub when seif-engine
was not installed (cli.py:7001 ImportError fallback). v2 sessions on disk
under .seif/sessions/active/ and .seif/sessions/sealed/<cycle>/ were
invisible to operators without the paid bridge.

Post-fix: --session list routes to _cmd_session_list_unified BEFORE the
engine import attempt. Walks active/ + sealed/<cycle>/, schema-validates
each entry via SessionEntry, and emits a grouped table or JSON.
"""
import json
import os
import subprocess
import sys
from pathlib import Path

import pytest


SAMPLE_ENTRY = {
    "session_id": "11111111-1111-1111-1111-111111111111",
    "wrapper": "claude",
    "host": "test-host",
    "pid": 12345,
    "cwd": "/tmp/workspace",
    "started_at": "2026-05-05T12:00:00Z",
    "last_heartbeat": "2026-05-05T12:00:00Z",
    "repos_observed": {},
    "cycle_id": "s62-test-cycle",
}


def _write_entry(d: Path, sid_suffix: str, **overrides) -> Path:
    d.mkdir(parents=True, exist_ok=True)
    entry = dict(SAMPLE_ENTRY)
    entry["session_id"] = f"{sid_suffix:0<8}-1111-1111-1111-111111111111"[:36]
    entry.update(overrides)
    p = d / f"{entry['session_id']}.json"
    p.write_text(json.dumps(entry), encoding="utf-8")
    return p


def _run_session_list(workspace: Path, as_json: bool = False, env_extra: dict = None):
    env = dict(os.environ)
    env["SEIF_HOME"] = str(workspace / ".seif-home")
    # Ensure the in-tree seif package is importable regardless of how pytest
    # was invoked (covers both editable installs and source-only checkouts).
    src_path = str(Path(__file__).resolve().parents[1] / "src")
    env["PYTHONPATH"] = src_path + os.pathsep + env.get("PYTHONPATH", "")
    if env_extra:
        env.update(env_extra)
    args = [sys.executable, "-m", "seif.cli", "--session", "list"]
    if as_json:
        args.append("--json")
    return subprocess.run(args, cwd=str(workspace), env=env,
                          capture_output=True, text=True, timeout=30)


# ── unit: helper directly ─────────────────────────────────────────


def test_session_list_unified_helper_active_only(tmp_path, monkeypatch, capsys):
    """Helper enumerates active/ entries, no sealed dir present."""
    workspace = tmp_path
    monkeypatch.chdir(workspace)
    _write_entry(workspace / ".seif" / "sessions" / "active", "aaaa")
    _write_entry(workspace / ".seif" / "sessions" / "active", "bbbb")

    from seif.cli.cli import _cmd_session_list_unified
    _cmd_session_list_unified(as_json=False)
    out = capsys.readouterr().out
    assert "active=2" in out
    assert "ACTIVE (2)" in out
    assert "aaaa" in out
    assert "bbbb" in out


def test_session_list_unified_helper_with_sealed(tmp_path, monkeypatch, capsys):
    """Helper enumerates sealed/<cycle>/ entries grouped by cycle_id."""
    workspace = tmp_path
    monkeypatch.chdir(workspace)
    _write_entry(workspace / ".seif" / "sessions" / "active", "aaaa")
    _write_entry(workspace / ".seif" / "sessions" / "sealed" / "s60-cycle", "cccc")
    _write_entry(workspace / ".seif" / "sessions" / "sealed" / "s61-cycle", "dddd")

    from seif.cli.cli import _cmd_session_list_unified
    _cmd_session_list_unified(as_json=False)
    out = capsys.readouterr().out
    assert "active=1 sealed=2" in out
    assert "SEALED s60-cycle (1)" in out
    assert "SEALED s61-cycle (1)" in out


def test_session_list_unified_json_shape(tmp_path, monkeypatch, capsys):
    """--json emits {active: [...], sealed: {cycle_id: [...]}} structure."""
    workspace = tmp_path
    monkeypatch.chdir(workspace)
    _write_entry(workspace / ".seif" / "sessions" / "active", "aaaa")
    _write_entry(workspace / ".seif" / "sessions" / "sealed" / "s60-cycle", "cccc")

    from seif.cli.cli import _cmd_session_list_unified
    _cmd_session_list_unified(as_json=True)
    out = capsys.readouterr().out
    parsed = json.loads(out)
    assert "active" in parsed and "sealed" in parsed
    assert len(parsed["active"]) == 1
    assert "s60-cycle" in parsed["sealed"]
    assert len(parsed["sealed"]["s60-cycle"]) == 1


def test_session_list_unified_skips_handoff_and_unknown(tmp_path, monkeypatch, capsys):
    """unknown.json and handoff-*.json are skipped (counted on stderr)."""
    workspace = tmp_path
    monkeypatch.chdir(workspace)
    active = workspace / ".seif" / "sessions" / "active"
    active.mkdir(parents=True)
    (active / "unknown.json").write_text(json.dumps({"foo": "bar"}), encoding="utf-8")
    (active / "handoff-x.json").write_text(json.dumps({"foo": "bar"}), encoding="utf-8")
    _write_entry(active, "aaaa")

    from seif.cli.cli import _cmd_session_list_unified
    _cmd_session_list_unified(as_json=False)
    captured = capsys.readouterr()
    assert "active=1" in captured.out
    assert "skipped 2" in captured.err


def test_session_list_unified_skips_invalid_json(tmp_path, monkeypatch, capsys):
    """Malformed JSON files are skipped (counted on stderr)."""
    workspace = tmp_path
    monkeypatch.chdir(workspace)
    active = workspace / ".seif" / "sessions" / "active"
    active.mkdir(parents=True)
    (active / "broken.json").write_text("{not valid", encoding="utf-8")
    _write_entry(active, "aaaa")

    from seif.cli.cli import _cmd_session_list_unified
    _cmd_session_list_unified(as_json=False)
    captured = capsys.readouterr()
    assert "active=1" in captured.out
    assert "skipped 1" in captured.err


def test_session_list_unified_no_seif_dir(tmp_path, monkeypatch, capsys):
    """Workspace without .seif/ shows the init hint."""
    monkeypatch.chdir(tmp_path)

    from seif.cli.cli import _cmd_session_list_unified
    _cmd_session_list_unified(as_json=False)
    out = capsys.readouterr().out
    assert "no .seif/" in out


def test_session_list_unified_empty_sessions_dir(tmp_path, monkeypatch, capsys):
    """Workspace with .seif/ but no session entries shows the empty hint."""
    monkeypatch.chdir(tmp_path)
    (tmp_path / ".seif").mkdir()

    from seif.cli.cli import _cmd_session_list_unified
    _cmd_session_list_unified(as_json=False)
    out = capsys.readouterr().out
    assert "(no v2 session entries found)" in out


# ── integration: --session list via subprocess works without engine ──


def test_cli_session_list_works_without_engine(tmp_path):
    """Pre-fix: this would hit _upgrade_message when engine absent. Post-fix: lists v2 sessions.

    Subprocess test forces a fresh import context where seif.context.sessions
    may or may not be importable; the unified helper does not depend on it.
    """
    _write_entry(tmp_path / ".seif" / "sessions" / "active", "aaaa")
    result = _run_session_list(tmp_path, as_json=True)
    assert result.returncode == 0, f"stderr: {result.stderr}\nstdout: {result.stdout}"
    parsed = json.loads(result.stdout)
    assert "active" in parsed
    assert len(parsed["active"]) == 1
    assert parsed["active"][0]["session_id"].startswith("aaaa")


def test_cli_session_list_does_not_emit_upgrade_message(tmp_path):
    """The pre-fix _upgrade_message stub printed 'Install seif-engine' or similar.
    Post-fix the list command should never emit that message."""
    _write_entry(tmp_path / ".seif" / "sessions" / "active", "aaaa")
    result = _run_session_list(tmp_path, as_json=False)
    assert result.returncode == 0
    combined = result.stdout + result.stderr
    # The upgrade message historically mentioned engine installation —
    # post-fix list should not surface it.
    assert "_upgrade_message" not in combined
    assert "Install seif-engine" not in combined
