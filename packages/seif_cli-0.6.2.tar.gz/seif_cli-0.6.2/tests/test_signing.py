"""Tests for seif.core.signing — sign_module / verify_module.

Covers gap-1 (s31 → s32): sign_module must accept the structured
`fingerprint.value` produced by `seif --fingerprint-update` AND the
legacy flat `integrity_hash` field.
"""

import json
import os
import sys
import tempfile
from pathlib import Path

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

pytest.importorskip("cryptography", reason="cryptography not installed")
pytest.importorskip("seif.core.signing", reason="seif not installed")

from seif.core import signing
from seif.core.signing import sign_module, verify_module


@pytest.fixture
def isolated_keys(tmp_path, monkeypatch):
    """Redirect keypair to a temp dir and generate a fresh Ed25519 pair."""
    home = tmp_path / "seif_home"
    home.mkdir(parents=True, exist_ok=True)
    monkeypatch.setattr(signing, "get_user_home", lambda: home)
    signing.keygen()
    return home


def _write_module(path: Path, data: dict) -> None:
    path.write_text(json.dumps(data, indent=2))


def test_sign_accepts_legacy_integrity_hash(tmp_path: Path, isolated_keys):
    mod_path = tmp_path / "legacy.seif"
    _write_module(
        mod_path,
        {
            "protocol": "SEIF-TEST-v1",
            "module_id": "legacy-test",
            "integrity_hash": "a" * 64,
        },
    )

    signed = sign_module(mod_path)

    assert "signature" in signed
    assert signed["signature"]["algorithm"] == "Ed25519"
    result = verify_module(mod_path)
    assert result["valid"] is True


def test_sign_accepts_modern_fingerprint_value(tmp_path: Path, isolated_keys):
    """gap-1 fix — modules produced by --fingerprint-update have only
    fingerprint.value, no flat integrity_hash. sign_module must accept this."""
    mod_path = tmp_path / "modern.seif"
    _write_module(
        mod_path,
        {
            "protocol": "SEIF-TEST-v1",
            "module_id": "modern-test",
            "fingerprint": {
                "algorithm": "sha256",
                "value": "b" * 64,
                "scope": "full_json_excluding_fingerprint",
            },
        },
    )

    signed = sign_module(mod_path)

    assert "signature" in signed
    result = verify_module(mod_path)
    assert result["valid"] is True


def test_sign_prefers_fingerprint_value_when_both_present(tmp_path: Path, isolated_keys):
    mod_path = tmp_path / "both.seif"
    _write_module(
        mod_path,
        {
            "protocol": "SEIF-TEST-v1",
            "module_id": "both-test",
            "integrity_hash": "a" * 64,
            "fingerprint": {"algorithm": "sha256", "value": "b" * 64},
        },
    )

    signed = sign_module(mod_path)
    sig = signed["signature"]["signed_hash"]
    assert sig  # signature exists; fingerprint.value path was used
    assert verify_module(mod_path)["valid"] is True


def test_sign_rejects_module_without_any_hash(tmp_path: Path, isolated_keys):
    mod_path = tmp_path / "empty.seif"
    _write_module(mod_path, {"protocol": "SEIF-TEST-v1", "module_id": "x"})

    with pytest.raises(ValueError, match="integrity_hash or fingerprint.value"):
        sign_module(mod_path)
