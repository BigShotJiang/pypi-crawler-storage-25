"""Tests for s58 PR3 — cycle ↔ session coherence audit (read-only)."""

from __future__ import annotations

import json
import uuid
from pathlib import Path

import pytest

from seif.plugins.core.cycle_coherence import (
    audit_cycle_coherence,
    find_writers_pending_close,
    format_report,
)
from seif.plugins.core.session_registry import (
    new_session_id,
    register,
)


@pytest.fixture
def workspace(tmp_path):
    ws = tmp_path / "workspace"
    (ws / ".seif" / "cycles").mkdir(parents=True)
    return ws


def _write_cycle(workspace: Path, slug: str, suffix: str, **fields) -> Path:
    path = workspace / ".seif" / "cycles" / f"{slug}-{suffix}.seif"
    payload = {
        "cycle_id": slug,
        "status": suffix,
        **fields,
    }
    path.write_text(json.dumps(payload, indent=2))
    return path


def test_clean_workspace_yields_no_findings(workspace):
    report = audit_cycle_coherence(workspace=workspace)
    assert report.total_findings == 0
    assert report.has_violations is False


def test_class_a_open_cycle_without_sessions(workspace):
    _write_cycle(workspace, "lonely", "OPEN")
    report = audit_cycle_coherence(workspace=workspace)
    assert len(report.cycles_without_sessions) == 1
    assert report.cycles_without_sessions[0].cycle_id == "lonely"
    assert report.has_violations is False  # advisory


def test_class_a_sealed_cycle_without_sessions(workspace):
    _write_cycle(workspace, "void", "SEALED")
    report = audit_cycle_coherence(workspace=workspace)
    assert len(report.cycles_without_sessions) == 1
    assert report.cycles_without_sessions[0].cycle_id == "void"


def test_class_a_satisfied_by_writer_sessions(workspace):
    _write_cycle(workspace, "ok-writer", "SEALED",
                 writer_sessions=[{"session_id": "abc", "role": "primary"}])
    report = audit_cycle_coherence(workspace=workspace)
    assert report.cycles_without_sessions == []


def test_class_a_satisfied_by_contributing_sessions(workspace):
    _write_cycle(workspace, "ok-contrib", "SEALED",
                 contributing_sessions=[{"session_id": "abc"}])
    report = audit_cycle_coherence(workspace=workspace)
    assert report.cycles_without_sessions == []


def test_class_a_satisfied_by_legacy_sessions_field(workspace):
    _write_cycle(workspace, "ok-legacy", "SEALED",
                 sessions=["session-1", "session-2"])
    report = audit_cycle_coherence(workspace=workspace)
    assert report.cycles_without_sessions == []


def test_class_b_active_session_without_cycle_id(workspace):
    sid = new_session_id()
    register(seif_dir=workspace / ".seif", session_id=sid, wrapper="x",
             cwd=workspace)
    report = audit_cycle_coherence(workspace=workspace)
    assert len(report.active_sessions_without_cycle_id) == 1
    assert report.active_sessions_without_cycle_id[0].session_id == sid
    assert report.has_violations is False  # informational


def test_class_b_silenced_when_cycle_id_set(workspace):
    sid = new_session_id()
    register(seif_dir=workspace / ".seif", session_id=sid, wrapper="x",
             cwd=workspace, cycle_id="bound-to-something")
    report = audit_cycle_coherence(workspace=workspace)
    assert report.active_sessions_without_cycle_id == []


def test_class_c_sealed_cycle_with_active_writer_session(workspace):
    """The real coherence violation: cycle was sealed but its writer session
    record is still in active/. Sibling-session discovery still treats it
    as live, which violates the seal contract."""
    sid = new_session_id()
    register(seif_dir=workspace / ".seif", session_id=sid, wrapper="x",
             cwd=workspace, cycle_id="sealed-but-leaky")
    _write_cycle(workspace, "sealed-but-leaky", "SEALED",
                 writer_sessions=[{"session_id": sid, "role": "primary"}])

    report = audit_cycle_coherence(workspace=workspace)
    assert len(report.sealed_cycles_with_active_writer_sessions) == 1
    assert report.has_violations is True  # CLASS C IS A VIOLATION


def test_class_c_silenced_when_session_was_unregistered(workspace):
    """Same setup as above but the session was properly unregistered before seal."""
    sid = new_session_id()
    _write_cycle(workspace, "sealed-clean", "SEALED",
                 writer_sessions=[{"session_id": sid, "role": "primary"}])
    # No register() — session is not in active/
    report = audit_cycle_coherence(workspace=workspace)
    assert report.sealed_cycles_with_active_writer_sessions == []
    assert report.has_violations is False


def test_classes_b_and_c_can_coexist(workspace):
    leaked_sid = new_session_id()
    orphan_sid = new_session_id()
    register(seif_dir=workspace / ".seif", session_id=leaked_sid, wrapper="x",
             cwd=workspace, cycle_id="some-cycle")
    register(seif_dir=workspace / ".seif", session_id=orphan_sid, wrapper="y",
             cwd=workspace)  # no cycle_id → class b
    _write_cycle(workspace, "some-cycle", "SEALED",
                 writer_sessions=[{"session_id": leaked_sid}])

    report = audit_cycle_coherence(workspace=workspace)
    assert len(report.sealed_cycles_with_active_writer_sessions) == 1
    assert len(report.active_sessions_without_cycle_id) == 1
    assert report.has_violations is True


def test_audit_is_read_only(workspace):
    """Strict guarantee: audit must not mutate workspace files."""
    sid = new_session_id()
    register(seif_dir=workspace / ".seif", session_id=sid, wrapper="x",
             cwd=workspace, cycle_id="rd-only")
    cycle_path = _write_cycle(workspace, "rd-only", "SEALED",
                              writer_sessions=[{"session_id": sid}])
    session_path = workspace / ".seif" / "sessions" / "active" / f"{sid}.json"

    cycle_mtime = cycle_path.stat().st_mtime_ns
    session_mtime = session_path.stat().st_mtime_ns
    cycle_bytes = cycle_path.read_bytes()
    session_bytes = session_path.read_bytes()

    audit_cycle_coherence(workspace=workspace)

    assert cycle_path.stat().st_mtime_ns == cycle_mtime
    assert session_path.stat().st_mtime_ns == session_mtime
    assert cycle_path.read_bytes() == cycle_bytes
    assert session_path.read_bytes() == session_bytes


def test_audit_errors_when_workspace_has_no_seif(tmp_path):
    bad = tmp_path / "bare"
    bad.mkdir()
    with pytest.raises(ValueError, match="no .seif/"):
        audit_cycle_coherence(workspace=bad)


def test_audit_handles_malformed_cycle_files(workspace):
    """Garbage cycle files must not crash the audit; they're skipped."""
    bad_path = workspace / ".seif" / "cycles" / "trash-OPEN.seif"
    bad_path.write_text("{not valid json")
    sid = new_session_id()
    register(seif_dir=workspace / ".seif", session_id=sid, wrapper="x",
             cwd=workspace, cycle_id="real-one")
    _write_cycle(workspace, "real-one", "SEALED",
                 writer_sessions=[{"session_id": sid}])

    report = audit_cycle_coherence(workspace=workspace)
    # Only the real cycle is detected (class c), trash is ignored
    assert len(report.sealed_cycles_with_active_writer_sessions) == 1


def test_audit_handles_malformed_session_files(workspace):
    """Malformed session files are skipped (not classified as class b)."""
    active_dir = workspace / ".seif" / "sessions" / "active"
    active_dir.mkdir(parents=True)
    (active_dir / "garbage.json").write_text("not json")
    report = audit_cycle_coherence(workspace=workspace)
    assert report.active_sessions_without_cycle_id == []


def test_format_report_clean(workspace):
    report = audit_cycle_coherence(workspace=workspace)
    out = format_report(report)
    assert "No incoherence" in out


def test_format_report_violation_marks_class_c(workspace):
    sid = new_session_id()
    register(seif_dir=workspace / ".seif", session_id=sid, wrapper="x",
             cwd=workspace, cycle_id="leaked")
    _write_cycle(workspace, "leaked", "SEALED",
                 writer_sessions=[{"session_id": sid}])
    report = audit_cycle_coherence(workspace=workspace)
    out = format_report(report)
    assert "VIOLATION" in out
    assert "Coherence violations present" in out


# ── s59 PR4 Layer A — find_writers_pending_close (seal-guard helper) ──


def test_find_writers_pending_close_clean_when_no_active_bound(workspace):
    """No active sessions bound to the cycle → empty list (seal would be clean)."""
    open_path = _write_cycle(workspace, "fresh", "OPEN")
    pending = find_writers_pending_close("fresh", open_path, workspace / ".seif")
    assert pending == []


def test_find_writers_pending_close_detects_session_with_matching_cycle_id(workspace):
    """Forward-compat: post-PR1 session declares cycle_id == about-to-seal cycle."""
    open_path = _write_cycle(workspace, "live-cycle", "OPEN")
    sid = new_session_id()
    register(seif_dir=workspace / ".seif", session_id=sid, wrapper="x",
             cwd=workspace, cycle_id="live-cycle")
    pending = find_writers_pending_close("live-cycle", open_path, workspace / ".seif")
    assert len(pending) == 1
    assert pending[0].session_id == sid
    assert "would orphan" in pending[0].detail


def test_find_writers_pending_close_detects_writer_session_in_open_cycle_file(workspace):
    """Backward-compat: session is active without cycle_id but is declared as
    writer in the OPEN cycle's writer_sessions[] (s54-s56 historical pattern)."""
    sid = new_session_id()
    register(seif_dir=workspace / ".seif", session_id=sid, wrapper="x",
             cwd=workspace)  # NO cycle_id on session
    open_path = _write_cycle(workspace, "legacy-style", "OPEN",
                             writer_sessions=[{"session_id": sid, "role": "primary"}])
    pending = find_writers_pending_close("legacy-style", open_path, workspace / ".seif")
    assert len(pending) == 1
    assert pending[0].session_id == sid
    assert "writer_session" in pending[0].detail


def test_find_writers_pending_close_dedupes_session_in_both_sources(workspace):
    """Session listed both with cycle_id AND in cycle file → reported once."""
    sid = new_session_id()
    register(seif_dir=workspace / ".seif", session_id=sid, wrapper="x",
             cwd=workspace, cycle_id="dup-source")
    open_path = _write_cycle(workspace, "dup-source", "OPEN",
                             writer_sessions=[{"session_id": sid}])
    pending = find_writers_pending_close("dup-source", open_path, workspace / ".seif")
    assert len(pending) == 1


def test_find_writers_pending_close_ignores_unrelated_active_sessions(workspace):
    """Sessions bound to OTHER cycles must not be reported."""
    open_path = _write_cycle(workspace, "target", "OPEN")
    sid = new_session_id()
    register(seif_dir=workspace / ".seif", session_id=sid, wrapper="x",
             cwd=workspace, cycle_id="not-the-target")
    pending = find_writers_pending_close("target", open_path, workspace / ".seif")
    assert pending == []


def test_find_writers_pending_close_handles_missing_open_file(workspace):
    """If the OPEN cycle file is absent, source (i) still works alone."""
    sid = new_session_id()
    register(seif_dir=workspace / ".seif", session_id=sid, wrapper="x",
             cwd=workspace, cycle_id="ghost")
    pending = find_writers_pending_close("ghost", workspace / ".seif" / "cycles" / "ghost-OPEN.seif",
                                         workspace / ".seif")
    assert len(pending) == 1
    assert pending[0].session_id == sid


# ── s60 PR1.5: audit reads sealed/<cycle_id>/ as resolved state ─────────


def _seal_writer_into_sealed(workspace: Path, slug: str, sid: str) -> Path:
    """Place a session entry in sessions/sealed/<slug>/ (post-heal state)."""
    sealed_dir = workspace / ".seif" / "sessions" / "sealed" / slug
    sealed_dir.mkdir(parents=True, exist_ok=True)
    p = sealed_dir / f"{sid}.json"
    p.write_text(json.dumps({"session_id": sid, "cycle_id": slug,
                             "wrapper": "x"}))
    return p


def test_class_d_resolved_when_writer_only_in_sealed_for_matching_cycle(workspace):
    """Post-heal happy path: writer is archived in sealed/<cycle>/<sid>.json
    and absent from active/ — audit reports class (d) resolved, NOT (c)."""
    sid = new_session_id()
    _write_cycle(workspace, "post-heal", "SEALED",
                 writer_sessions=[{"session_id": sid, "role": "primary"}])
    _seal_writer_into_sealed(workspace, "post-heal", sid)

    report = audit_cycle_coherence(workspace=workspace)
    assert len(report.sealed_cycles_with_active_writer_sessions) == 0, (
        "no class (c) when writer is in sealed/<matching cycle>/"
    )
    assert len(report.sealed_cycles_with_resolved_writer_sessions) == 1
    assert report.has_violations is False, (
        "class (d) is advisory; has_violations stays False"
    )


def test_class_e_sync_straggler_when_writer_in_both_active_and_sealed(workspace):
    """Sync-straggler path: heal moved the writer to sealed/, then an
    unidentified peer-restore daemon re-introduced it to active/. The
    sealed copy is authoritative; active is a sync side-effect, NOT a
    class (c) violation. This is the s60 rank-1 inert-the-bug invariant."""
    sid = new_session_id()
    _write_cycle(workspace, "straggler", "SEALED",
                 writer_sessions=[{"session_id": sid, "role": "primary"}])
    _seal_writer_into_sealed(workspace, "straggler", sid)
    # Restorer re-added active/<sid>.json
    register(seif_dir=workspace / ".seif", session_id=sid, wrapper="x",
             cwd=workspace, cycle_id="straggler")

    report = audit_cycle_coherence(workspace=workspace)
    assert len(report.sealed_cycles_with_active_writer_sessions) == 0, (
        "BINDING: presence in active/ does NOT trigger class (c) when the "
        "sealed/<matching cycle>/ copy exists. This is the s60 rank-1 fix."
    )
    assert len(report.sealed_cycles_with_sync_straggler_in_active) == 1
    assert report.has_violations is False


def test_class_c_still_fires_when_no_sealed_copy_exists(workspace):
    """Negative regression: a writer in active/ with NO sealed/<cycle>/
    copy MUST still fire class (c). Otherwise option E-prime would mask
    the original violation it was designed to surface."""
    sid = new_session_id()
    _write_cycle(workspace, "real-leak", "SEALED",
                 writer_sessions=[{"session_id": sid, "role": "primary"}])
    register(seif_dir=workspace / ".seif", session_id=sid, wrapper="x",
             cwd=workspace, cycle_id="real-leak")
    # NO sealed copy written — heal has not been run yet.

    report = audit_cycle_coherence(workspace=workspace)
    assert len(report.sealed_cycles_with_active_writer_sessions) == 1
    assert report.has_violations is True


def test_sealed_copy_under_wrong_cycle_does_not_resolve(workspace):
    """Defensive: a writer archived under sealed/<wrong_cycle>/<sid>.json
    is NOT a resolution for cycle X. Otherwise misplaced archives would
    mask real class (c) violations. The sealed copy must be under the
    cycle that declared the writer."""
    sid = new_session_id()
    _write_cycle(workspace, "real-cycle", "SEALED",
                 writer_sessions=[{"session_id": sid, "role": "primary"}])
    _seal_writer_into_sealed(workspace, "wrong-cycle", sid)
    register(seif_dir=workspace / ".seif", session_id=sid, wrapper="x",
             cwd=workspace, cycle_id="real-cycle")

    report = audit_cycle_coherence(workspace=workspace)
    assert len(report.sealed_cycles_with_active_writer_sessions) == 1, (
        "writer archived under wrong cycle does not resolve real-cycle's "
        "class (c) violation"
    )
    assert report.has_violations is True
