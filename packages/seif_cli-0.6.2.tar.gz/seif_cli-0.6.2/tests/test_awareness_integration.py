"""Integration test for s42 awareness MVP — session_start_logic wiring.

Verifies that when --awareness is enabled in the lifecycle:
  1. The current session is registered in .seif/sessions/active/
  2. Active siblings appear in the session-start output
  3. Drift is surfaced when sibling observed a different HEAD
  4. session_end_logic unregisters the session when given session_id
"""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

import pytest


# Canonical UUID fixtures — register() guard (s56 PR1) rejects non-UUID ids.
# The names below preserve the original test intent while satisfying the guard.
SID_ABC = "11111111-1111-1111-1111-111111111111"
SID_SOLO = "22222222-2222-2222-2222-222222222222"
SID_SIBLING = "33333333-3333-3333-3333-333333333333"
SID_ME = "44444444-4444-4444-4444-444444444444"
SID_ENDING = "55555555-5555-5555-5555-555555555555"
SID_LINGERING = "66666666-6666-6666-6666-666666666666"
SID_OPTED_OUT = "77777777-7777-7777-7777-777777777777"
SID_CLI = "88888888-8888-8888-8888-888888888888"
SID_COHERENCE = "99999999-9999-9999-9999-999999999999"
SID_COHERENCE_CLEAN = "aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa"
SID_COHERENCE_ADVISORY = "bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb"


def _git_init_with_commit(path: Path):
    path.mkdir(parents=True, exist_ok=True)
    subprocess.run(
        ["git", "init", "-q", "-b", "main", str(path)], check=True
    )
    subprocess.run(
        [
            "git", "-C", str(path),
            "-c", "user.email=t@t",
            "-c", "user.name=t",
            "commit", "-q", "--allow-empty", "-m", "init",
        ],
        check=True,
        env={**os.environ, "HOME": str(path.parent)},
    )


def _make_workspace(tmp_path: Path) -> Path:
    """Create workspace at tmp_path with .seif/ + repos/ structure."""
    seif_dir = tmp_path / ".seif"
    seif_dir.mkdir()
    config = {
        "session_lifecycle": {
            "enabled": True,
            "co_author": "",
        },
    }
    (seif_dir / "config.json").write_text(json.dumps(config))
    (seif_dir / "sessions").mkdir()
    (seif_dir / "modules").mkdir()
    (seif_dir / "mapper.json").write_text(
        json.dumps({"modules": [], "version": 1})
    )
    return seif_dir


def test_session_start_registers_session(tmp_path):
    seif_dir = _make_workspace(tmp_path)
    _git_init_with_commit(tmp_path / "alpha")

    from seif.plugins.core.session_lifecycle import session_start_logic

    result = session_start_logic(
        session_id=SID_ABC,
        cwd=tmp_path,
        home=tmp_path,
        enable_awareness=True,
        wrapper="claude-code",
    )
    assert not result.legacy_mode

    entry_path = seif_dir / "sessions" / "active" / f"{SID_ABC}.json"
    assert entry_path.is_file()
    entry = json.loads(entry_path.read_text())
    assert entry["session_id"] == SID_ABC
    assert entry["wrapper"] == "claude-code"
    assert "alpha" in entry["repos_observed"]


def test_session_start_solo_session_has_no_awareness_block(tmp_path):
    """When no siblings exist, no AWARENESS block should be emitted —
    silence is the right UX for solo sessions."""
    _make_workspace(tmp_path)
    _git_init_with_commit(tmp_path / "alpha")

    from seif.plugins.core.session_lifecycle import session_start_logic

    result = session_start_logic(
        session_id=SID_SOLO,
        cwd=tmp_path,
        home=tmp_path,
        enable_awareness=True,
    )
    assert "AWARENESS" not in result.output_text


def test_session_start_surfaces_sibling(tmp_path):
    seif_dir = _make_workspace(tmp_path)
    _git_init_with_commit(tmp_path / "alpha")

    from seif.plugins.core.session_lifecycle import session_start_logic
    from seif.plugins.core.session_registry import register

    # Pre-register a sibling with a different observed HEAD
    register(
        seif_dir=seif_dir,
        session_id=SID_SIBLING,
        wrapper="copilot",
        cwd=tmp_path,
        repo_heads={"alpha": "deadbeefcafebabedeadbeefcafebabedeadbeef"},
        host="other-host",
        pid=4242,
    )

    result = session_start_logic(
        session_id=SID_ME,
        cwd=tmp_path,
        home=tmp_path,
        enable_awareness=True,
    )
    assert "AWARENESS" in result.output_text
    assert "copilot" in result.output_text
    assert "other-host" in result.output_text
    assert "alpha" in result.output_text
    assert "diverges" in result.output_text


def test_session_end_unregisters(tmp_path):
    seif_dir = _make_workspace(tmp_path)
    _git_init_with_commit(tmp_path / "alpha")

    from seif.plugins.core.session_lifecycle import (
        session_end_logic, session_start_logic,
    )

    session_start_logic(
        session_id=SID_ENDING,
        cwd=tmp_path,
        home=tmp_path,
        enable_awareness=True,
    )
    entry_path = seif_dir / "sessions" / "active" / f"{SID_ENDING}.json"
    assert entry_path.is_file()

    session_end_logic(
        cwd=tmp_path, home=tmp_path, session_id=SID_ENDING
    )
    assert not entry_path.exists()


def test_session_end_without_session_id_leaves_registry_alone(tmp_path):
    """Backwards compat: session_end_logic without session_id (the prior
    signature) must not crash and must not touch the registry.

    Note: s60 PR4 added a gc_stale invocation to session_end. A FRESH
    sibling entry (heartbeat timestamp just-now) is not stale and must
    survive gc_stale. This test asserts that.
    """
    seif_dir = _make_workspace(tmp_path)
    _git_init_with_commit(tmp_path / "alpha")

    from seif.plugins.core.session_lifecycle import (
        session_end_logic, session_start_logic,
    )

    session_start_logic(
        session_id=SID_LINGERING,
        cwd=tmp_path, home=tmp_path,
        enable_awareness=True,
    )
    session_end_logic(cwd=tmp_path, home=tmp_path)
    # Fresh entry (heartbeat just-now) is NOT stale; gc_stale must not drop it.
    assert (seif_dir / "sessions" / "active" / f"{SID_LINGERING}.json").is_file()


# ── s60 PR4: gc_stale at session_end ────────────────────────────────────


def test_session_end_invokes_gc_stale_drops_stale_siblings(tmp_path):
    """A stale sibling entry (heartbeat older than STALE_AFTER_SECONDS_DEFAULT)
    must be dropped when ANY session ends — even if that session has no
    session_id of its own. Pre-PR4 the same sibling would linger until the
    NEXT session_start fired gc_stale; PR4 shrinks that window."""
    import json as _json

    seif_dir = _make_workspace(tmp_path)
    _git_init_with_commit(tmp_path / "alpha")

    from seif.plugins.core.session_lifecycle import session_end_logic
    from seif.plugins.core.session_registry import (
        STALE_AFTER_SECONDS_DEFAULT, register,
    )

    # Plant a fresh sibling, then artificially age its heartbeat to past stale.
    stale_sid = "cccccccc-cccc-cccc-cccc-cccccccccccc"
    register(
        seif_dir=seif_dir, session_id=stale_sid,
        wrapper="claude-code", cwd=tmp_path,
    )
    entry_path = seif_dir / "sessions" / "active" / f"{stale_sid}.json"
    assert entry_path.is_file()

    data = _json.loads(entry_path.read_text())
    # 2x the stale threshold is unambiguously stale.
    import time as _time
    aged = _time.gmtime(_time.time() - 2 * STALE_AFTER_SECONDS_DEFAULT)
    data["last_heartbeat"] = _time.strftime("%Y-%m-%dT%H:%M:%SZ", aged)
    entry_path.write_text(_json.dumps(data, indent=2))

    # End OUR session (no session_id) — gc_stale should still fire and
    # drop the artificially-aged sibling.
    session_end_logic(cwd=tmp_path, home=tmp_path)
    assert not entry_path.exists(), (
        "session_end_logic must invoke gc_stale (s60 PR4). The aged sibling "
        "entry was stale but persisted after session_end."
    )


def test_session_end_swallows_gc_stale_exceptions(tmp_path, monkeypatch):
    """gc_stale failures must NOT propagate out of session_end_logic. The
    GC is best-effort hygiene; closure_phase / audit_phase / absorb_phase
    are the correctness invariants and must run regardless."""
    seif_dir = _make_workspace(tmp_path)
    _git_init_with_commit(tmp_path / "alpha")

    from seif.plugins.core import session_registry
    monkeypatch.setattr(
        session_registry, "gc_stale",
        lambda _: (_ for _ in ()).throw(RuntimeError("simulated gc failure")),
    )

    from seif.plugins.core.session_lifecycle import session_end_logic
    # Must not raise.
    result = session_end_logic(cwd=tmp_path, home=tmp_path)
    assert result is not None


def test_awareness_disabled_skips_registration(tmp_path):
    seif_dir = _make_workspace(tmp_path)
    _git_init_with_commit(tmp_path / "alpha")

    from seif.plugins.core.session_lifecycle import session_start_logic

    session_start_logic(
        session_id=SID_OPTED_OUT,
        cwd=tmp_path,
        home=tmp_path,
        enable_awareness=False,
    )
    active_dir = seif_dir / "sessions" / "active"
    # Either dir doesn't exist or is empty — both mean no registration
    assert not active_dir.exists() or not list(active_dir.iterdir())


# ── s59 PR4 Layer B — auto-wire cycle coherence audit into session-start ──


def _write_cycle(seif_dir: Path, slug: str, suffix: str, **fields) -> Path:
    cycles = seif_dir / "cycles"
    cycles.mkdir(exist_ok=True)
    path = cycles / f"{slug}-{suffix}.seif"
    payload = {"cycle_id": slug, "status": suffix, **fields}
    path.write_text(json.dumps(payload, indent=2))
    return path


def test_session_start_surfaces_class_c_coherence_violation(tmp_path):
    """BINDING: when a class-(c) coherence violation exists (SEALED cycle
    with active writer session), session-start MUST surface a CYCLE
    COHERENCE banner. Implements s59 q2 owner decision."""
    seif_dir = _make_workspace(tmp_path)
    _git_init_with_commit(tmp_path / "alpha")

    from seif.plugins.core.session_registry import register
    # Pre-register a "leaked" session that's still active and bound to a sealed cycle
    register(
        seif_dir=seif_dir,
        session_id=SID_COHERENCE,
        wrapper="claude-code",
        cwd=tmp_path,
        cycle_id="leaky-sealed",
    )
    _write_cycle(seif_dir, "leaky-sealed", "SEALED",
                 writer_sessions=[{"session_id": SID_COHERENCE}])

    from seif.plugins.core.session_lifecycle import session_start_logic
    result = session_start_logic(
        session_id=SID_ME,
        cwd=tmp_path,
        home=tmp_path,
        enable_awareness=True,
    )
    assert "CYCLE COHERENCE" in result.output_text
    assert "leaky-sealed" in result.output_text
    assert "class-(c) violation" in result.output_text
    assert "seif --audit-cycle-coherence" in result.output_text


def test_session_start_silent_on_class_a_advisory_only(tmp_path):
    """q2 owner decision: class-(a) advisory findings (cycles without
    writer_sessions) MUST NOT surface a banner — they are too noisy at
    session-start. Operator runs `seif --audit-cycle-coherence` on demand."""
    seif_dir = _make_workspace(tmp_path)
    _git_init_with_commit(tmp_path / "alpha")

    # SEALED cycle without any writer_sessions → class-(a) only
    _write_cycle(seif_dir, "lonely-advisory", "SEALED")

    from seif.plugins.core.session_lifecycle import session_start_logic
    result = session_start_logic(
        session_id=SID_COHERENCE_ADVISORY,
        cwd=tmp_path,
        home=tmp_path,
        enable_awareness=True,
    )
    assert "CYCLE COHERENCE" not in result.output_text
    assert "lonely-advisory" not in result.output_text


def test_session_start_silent_on_clean_workspace_no_cycle_findings(tmp_path):
    """No cycles, no violations, no class-(c) findings → no CYCLE COHERENCE
    banner. Solo session must remain silent."""
    _make_workspace(tmp_path)
    _git_init_with_commit(tmp_path / "alpha")

    from seif.plugins.core.session_lifecycle import session_start_logic
    result = session_start_logic(
        session_id=SID_COHERENCE_CLEAN,
        cwd=tmp_path,
        home=tmp_path,
        enable_awareness=True,
    )
    assert "CYCLE COHERENCE" not in result.output_text


def test_cli_flag_wires_through(tmp_path):
    """End-to-end: invoke session_lifecycle.py with --awareness via subprocess
    and verify a registry entry appears."""
    seif_dir = _make_workspace(tmp_path)
    _git_init_with_commit(tmp_path / "alpha")

    script = (
        Path(__file__).resolve().parents[1]
        / "src" / "seif" / "plugins" / "core" / "session_lifecycle.py"
    )
    result = subprocess.run(
        [
            "python3", str(script), "session-start",
            "--session-id", SID_CLI,
            "--cwd", str(tmp_path),
            "--home", str(tmp_path),
            "--awareness",
            "--wrapper", "claude-code",
        ],
        capture_output=True,
        text=True,
        timeout=15,
        env={
            **os.environ,
            "PYTHONPATH": str(Path(__file__).resolve().parents[1] / "src"),
        },
    )
    assert result.returncode == 0, result.stderr
    entry_path = seif_dir / "sessions" / "active" / f"{SID_CLI}.json"
    assert entry_path.is_file()
