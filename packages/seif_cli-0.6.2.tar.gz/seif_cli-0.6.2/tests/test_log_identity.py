"""Workspace identity — Ed25519 keypair lifecycle."""

from __future__ import annotations

import os
import stat
from pathlib import Path

import pytest

cryptography = pytest.importorskip("cryptography")

from seif.log import identity as identity_mod
from seif.log.identity import ensure_identity, identity_paths


@pytest.fixture
def isolated_home(tmp_path: Path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    # Path.home() reads HOME on POSIX; force it to re-evaluate per test.
    return tmp_path


def test_ensure_identity_generates_keypair(isolated_home: Path):
    ident = ensure_identity("default")
    assert ident.name == "default"
    assert isinstance(ident.pubkey_bytes, bytes)
    assert len(ident.pubkey_bytes) == 32

    key_path, pub_path = identity_paths("default")
    assert key_path.exists()
    assert pub_path.exists()


def test_private_key_file_mode_is_0600(isolated_home: Path):
    ensure_identity("default")
    key_path, _ = identity_paths("default")
    mode = stat.S_IMODE(os.stat(key_path).st_mode)
    assert mode == 0o600, f"private key should be 0600, got {oct(mode)}"


def test_ensure_identity_is_idempotent(isolated_home: Path):
    a = ensure_identity("default")
    b = ensure_identity("default")
    assert a.pubkey_bytes == b.pubkey_bytes


def test_named_identities_are_independent(isolated_home: Path):
    a = ensure_identity("alpha")
    b = ensure_identity("beta")
    assert a.pubkey_bytes != b.pubkey_bytes


def test_identity_can_sign_and_verify(isolated_home: Path):
    ident = ensure_identity("default")
    pub = identity_mod.load_public_key(ident.pubkey_bytes)
    msg = b"attestation message"
    sig = ident.sign(msg)
    pub.verify(sig, msg)  # raises if invalid
