"""Tests for audit_phase ghost detection in session_lifecycle.

Covers the S33 mapper-normalization fix: when config.json declares a
context_repo, modules whose path resolves under that SCR are present
even if absent from seif_dir. Lexical path normalization (os.path.normpath)
must be used so a symlinked seif_dir does not break parent traversal.
"""

from __future__ import annotations

import json
import os
import tempfile
import unittest
from pathlib import Path

from seif.plugins.core.session_lifecycle import audit_phase


def _write_mapper(seif_dir: Path, paths: list[str]) -> None:
    seif_dir.mkdir(parents=True, exist_ok=True)
    mapper = {"protocol": "SEIF-MAPPER-v1",
              "modules": [{"path": p, "category": "context"} for p in paths]}
    (seif_dir / "mapper.json").write_text(json.dumps(mapper))


def _write_config(seif_dir: Path, **cfg) -> None:
    (seif_dir / "config.json").write_text(json.dumps(cfg))


class AuditPhaseTests(unittest.TestCase):

    def test_no_mapper_returns_skip(self):
        with tempfile.TemporaryDirectory() as td:
            seif_dir = Path(td) / ".seif"
            seif_dir.mkdir()
            self.assertEqual(audit_phase(seif_dir), "SKIP: no mapper")

    def test_all_modules_present_no_ghosts(self):
        with tempfile.TemporaryDirectory() as td:
            ws = Path(td)
            seif_dir = ws / ".seif"
            _write_mapper(seif_dir, ["a.seif", "b.seif"])
            (seif_dir / "a.seif").write_text("a")
            (seif_dir / "b.seif").write_text("b")
            self.assertEqual(audit_phase(seif_dir), "modules=2 ghosts=0")

    def test_missing_modules_counted_as_ghosts(self):
        with tempfile.TemporaryDirectory() as td:
            ws = Path(td)
            seif_dir = ws / ".seif"
            _write_mapper(seif_dir, ["present.seif", "ghost.seif"])
            (seif_dir / "present.seif").write_text("p")
            self.assertEqual(audit_phase(seif_dir), "modules=2 ghosts=1")

    def test_context_repo_resolves_ghosts(self):
        """When config declares context_repo, modules under SCR are present."""
        with tempfile.TemporaryDirectory() as td:
            ws = Path(td)
            seif_dir = ws / ".seif"
            scr = ws / "seif-context"
            scr.mkdir()
            (scr / "absorption-v3.1.seif").write_text("hist")
            (scr / "cycles").mkdir()
            (scr / "cycles" / "old.seif").write_text("c")
            _write_mapper(seif_dir, ["absorption-v3.1.seif", "cycles/old.seif"])
            _write_config(seif_dir, context_repo="../seif-context")
            self.assertEqual(audit_phase(seif_dir), "modules=2 ghosts=0")

    def test_context_repo_missing_dir_falls_back_to_legacy(self):
        with tempfile.TemporaryDirectory() as td:
            ws = Path(td)
            seif_dir = ws / ".seif"
            _write_mapper(seif_dir, ["x.seif"])
            _write_config(seif_dir, context_repo="../no-such-dir")
            self.assertEqual(audit_phase(seif_dir), "modules=1 ghosts=1")

    def test_no_context_repo_key_is_legacy_behavior(self):
        with tempfile.TemporaryDirectory() as td:
            ws = Path(td)
            seif_dir = ws / ".seif"
            _write_mapper(seif_dir, ["x.seif"])
            _write_config(seif_dir, autonomous_context=True)
            self.assertEqual(audit_phase(seif_dir), "modules=1 ghosts=1")

    def test_partial_resolution_only_some_in_scr(self):
        with tempfile.TemporaryDirectory() as td:
            ws = Path(td)
            seif_dir = ws / ".seif"
            scr = ws / "seif-context"
            scr.mkdir()
            (scr / "in-scr.seif").write_text("s")
            _write_mapper(seif_dir, ["in-scr.seif", "in-seif.seif", "ghost.seif"])
            (seif_dir / "in-seif.seif").write_text("l")
            _write_config(seif_dir, context_repo="../seif-context")
            self.assertEqual(audit_phase(seif_dir), "modules=3 ghosts=1")

    def test_symlinked_seif_dir_with_parent_traversal(self):
        """Regression: .seif/ may be a symlink (e.g. seif-projects/.seif →
        seif-admin/.seif on Mini-canonical setup). Lexical normalization
        must keep '../seif-context' anchored to the workspace, not the
        symlink target's parent."""
        with tempfile.TemporaryDirectory() as td:
            ws = Path(td)
            real_admin = ws / "seif-admin"
            real_admin.mkdir()
            real_seif = real_admin / ".seif"
            real_seif.mkdir()
            ws_proj = ws / "seif-projects"
            ws_proj.mkdir()
            seif_dir = ws_proj / ".seif"
            os.symlink(real_seif, seif_dir)
            scr = ws_proj / "seif-context"
            scr.mkdir()
            (scr / "hist.seif").write_text("h")
            _write_mapper(seif_dir, ["hist.seif"])
            _write_config(seif_dir, context_repo="../seif-context")
            self.assertEqual(audit_phase(seif_dir), "modules=1 ghosts=0")

    def test_dict_format_modules_unchanged(self):
        with tempfile.TemporaryDirectory() as td:
            seif_dir = Path(td) / ".seif"
            seif_dir.mkdir()
            (seif_dir / "mapper.json").write_text(json.dumps({"modules": {"a": {}, "b": {}}}))
            self.assertEqual(audit_phase(seif_dir), "modules=2 format=dict")


if __name__ == "__main__":
    unittest.main()
