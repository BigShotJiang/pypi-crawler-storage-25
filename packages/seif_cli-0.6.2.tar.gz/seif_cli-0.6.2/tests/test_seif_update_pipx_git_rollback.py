"""Tests for s43 B2 — pipx-from-git rollback automation.

Closes the s41 P6 best-effort gap: previously, `pipx install --force` destroyed
the venv before we could capture the prior commit, so rollback printed a hint
and required operator intervention. B2 snapshots `pipx list --json` (URL) +
`direct_url.json` (resolved commit_id) BEFORE the install --force, then uses
the captured ref to reconstruct `pipx install --force git+<url>@<commit>`.

These tests verify the static structure of Stage 0 capture + Stage 4 dispatch.
End-to-end behavior on a real pipx-from-git host requires Air or a mocked
runtime — those are deferred to integration testing post-merge.
"""

from __future__ import annotations

from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
SCRIPT = REPO_ROOT / "src" / "seif" / "scripts" / "host" / "seif-update.sh"


def _read_script() -> str:
    return SCRIPT.read_text()


# ── Stage 0: capture block ─────────────────────────────────────


def test_stage_0_declares_pipx_url_and_commit_vars():
    text = _read_script()
    assert 'pre_pkg_pipx_url=""' in text
    assert 'pre_pkg_pipx_commit=""' in text


def test_stage_0_capture_only_fires_on_pipx_git():
    """The Python helper must be guarded so it doesn't run on editable or
    pypi-pipx hosts."""
    text = _read_script()
    snap_start = text.find("Stage 0: pre-update snapshot")
    snap_end = text.find("Stage 1: package install", snap_start)
    block = text[snap_start:snap_end]
    # Guard checks both method=pipx AND package_source=git+*
    assert 'if [ "$method" = "pipx" ] && [[ "$package_source" == git+* ]]; then' in block, (
        "B2 capture must be guarded behind pipx + git+* check"
    )


def test_stage_0_uses_pipx_list_json():
    text = _read_script()
    assert 'subprocess.run(["pipx", "list", "--json"]' in text, (
        "Primary capture source must be `pipx list --json`"
    )


def test_stage_0_extracts_package_or_url():
    text = _read_script()
    assert 'main_package' in text and 'package_or_url' in text, (
        "Must read main_package.package_or_url from pipx list output"
    )


def test_stage_0_reads_direct_url_json():
    text = _read_script()
    assert 'direct_url.json' in text, (
        "Secondary source for resolved commit_id must be direct_url.json (PEP 610)"
    )
    assert 'vcs_info' in text and 'commit_id' in text, (
        "Must extract vcs_info.commit_id from direct_url.json"
    )


def test_stage_0_uses_pipx_environment_to_find_venvs_dir():
    text = _read_script()
    assert 'PIPX_LOCAL_VENVS' in text, (
        "Must resolve pipx venv dir via `pipx environment --value PIPX_LOCAL_VENVS`"
    )


def test_stage_0_snapshot_json_includes_new_fields():
    text = _read_script()
    snap_start = text.find("Stage 0: pre-update snapshot")
    snap_end = text.find("Stage 1: package install", snap_start)
    block = text[snap_start:snap_end]
    # Both fields written into the JSON snapshot
    assert '"pre_pkg_pipx_url": "$pre_pkg_pipx_url"' in block
    assert '"pre_pkg_pipx_commit": "$pre_pkg_pipx_commit"' in block


def test_stage_0_header_logs_captured_commit_when_present():
    text = _read_script()
    assert '[ -n "$pre_pkg_pipx_commit" ] && echo "  pre-pkg-pipx-commit:' in text, (
        "Header should surface captured commit when present"
    )


def test_stage_0_header_logs_url_when_no_commit():
    text = _read_script()
    # Falls back to URL line only when commit is empty
    assert '[ -n "$pre_pkg_pipx_url" ] && [ -z "$pre_pkg_pipx_commit" ] && echo "  pre-pkg-pipx-url:' in text


def test_stage_0_capture_failures_are_non_fatal():
    """The Python helper must swallow exceptions — pipx may not be installed,
    venv may not exist yet on first --self-update, etc."""
    text = _read_script()
    snap_start = text.find("Stage 0: pre-update snapshot")
    snap_end = text.find("Stage 1: package install", snap_start)
    block = text[snap_start:snap_end]
    # Two `try/except Exception: pass` blocks (one per data source)
    assert block.count("except Exception:") >= 2, (
        "Each capture source (pipx list, direct_url.json) must be in its own try/except"
    )
    # The bash command itself falls back if python exits non-zero
    assert '|| pipx_capture=' in block, (
        "Bash must default pipx_capture to empty JSON if python helper fails"
    )


# ── Stage 4: rollback plan ─────────────────────────────────────


def test_rollback_plan_branches_on_commit_url_or_neither():
    text = _read_script()
    plan_start = text.find("ROLLBACK PLAN")
    dispatch_start = text.find("ROLLBACK DISPATCH", plan_start)
    block = text[plan_start:dispatch_start]
    # 3 distinct branches in the git+* case
    assert 'if [ -n "$pre_pkg_pipx_commit" ]; then' in block, (
        "Plan must show pinned-commit rollback when commit captured"
    )
    assert 'elif [ -n "$pre_pkg_pipx_url" ]; then' in block, (
        "Plan must show url-only rollback as fallback"
    )
    # 'unavailable' or similar wording for the neither-captured case
    assert "rollback unavailable" in block or "manual recovery" in block.lower()


def test_rollback_plan_pipx_pinned_commit_uses_force():
    text = _read_script()
    plan_start = text.find("ROLLBACK PLAN")
    dispatch_start = text.find("ROLLBACK DISPATCH", plan_start)
    block = text[plan_start:dispatch_start]
    # The command shown must be `pipx install --force "<base>@<commit>"`
    assert "pipx install --force" in block
    assert "${package_source%@*}@$pre_pkg_pipx_commit" in block, (
        "Pinned-commit rollback must reconstruct base_url@commit form"
    )


# ── Stage 4: rollback dispatch ─────────────────────────────────


def test_rollback_dispatch_pipx_git_executes_pinned_commit():
    text = _read_script()
    dispatch_start = text.find("ROLLBACK DISPATCH")
    end = text.find("# Re-restart", dispatch_start)
    block = text[dispatch_start:end]
    # Pinned commit branch must actually invoke pipx install --force
    pipx_block_start = block.find("git+*)")
    pipx_block_end = block.find("*)", pipx_block_start + 5)
    pipx_block = block[pipx_block_start:pipx_block_end]
    assert 'pipx install --force "$base_url@$pre_pkg_pipx_commit"' in pipx_block, (
        "Pinned-commit dispatch must execute the rollback command"
    )


def test_rollback_dispatch_pipx_git_falls_back_to_url():
    text = _read_script()
    dispatch_start = text.find("ROLLBACK DISPATCH")
    end = text.find("# Re-restart", dispatch_start)
    block = text[dispatch_start:end]
    pipx_block_start = block.find("git+*)")
    pipx_block_end = block.find("*)", pipx_block_start + 5)
    pipx_block = block[pipx_block_start:pipx_block_end]
    # URL-only branch
    assert 'elif [ -n "$pre_pkg_pipx_url" ]; then' in pipx_block
    assert 'pipx install --force "$pre_pkg_pipx_url"' in pipx_block


def test_rollback_dispatch_pipx_git_neither_marks_failed():
    text = _read_script()
    dispatch_start = text.find("ROLLBACK DISPATCH")
    end = text.find("# Re-restart", dispatch_start)
    block = text[dispatch_start:end]
    pipx_block_start = block.find("git+*)")
    pipx_block_end = block.find("*)", pipx_block_start + 5)
    pipx_block = block[pipx_block_start:pipx_block_end]
    # Final else branch must still set rollback_failed=1 + log skip
    assert "rollback_failed=1" in pipx_block
    assert "no captured ref" in pipx_block or "manual recovery" in pipx_block


def test_rollback_dispatch_pinned_commit_marks_failure_on_pipx_error():
    """If pipx install --force itself fails during rollback, rollback_failed=1
    must be set (so post-rollback check still runs but exit code reflects)."""
    text = _read_script()
    dispatch_start = text.find("ROLLBACK DISPATCH")
    end = text.find("# Re-restart", dispatch_start)
    block = text[dispatch_start:end]
    pipx_block_start = block.find("git+*)")
    pipx_block_end = block.find("*)", pipx_block_start + 5)
    pipx_block = block[pipx_block_start:pipx_block_end]
    # `|| rollback_failed=1` must trail both the pinned and url branches
    pipx_lines = [l for l in pipx_block.split("\n") if "pipx install --force" in l and "echo" not in l]
    for line in pipx_lines:
        assert "|| rollback_failed=1" in line, (
            f"pipx install --force in rollback dispatch must propagate failure: {line!r}"
        )


# ── Bash syntax + integration ──────────────────────────────────


def test_bash_syntax_valid_after_b2():
    import subprocess
    result = subprocess.run(["bash", "-n", str(SCRIPT)], capture_output=True, text=True)
    assert result.returncode == 0, f"bash -n failed: {result.stderr}"


def test_check_mode_unaffected_by_b2(tmp_path):
    """B2 changes are inside Stage 0 + Stage 4, both of which --check skips.
    So --check output for a pipx-git config must be identical in shape."""
    import json, os, subprocess
    cfg_data = {
        "protocol": "SEIF-HOST-INSTALL-CONFIG-v2",
        "host_label": "b2-pipx-git-host",
        "install_method": "pipx",
        "package_name": "seif-cli",
        "package_source": "git+https://github.com/and2carvalho/seif.git@main",
        "extra_packages": [],
        "post_install_check": "true",
    }
    seif_dir = tmp_path / ".seif"
    seif_dir.mkdir()
    (seif_dir / "host-install-config.seif").write_text(json.dumps(cfg_data))

    result = subprocess.run(
        ["bash", str(SCRIPT), "--check"],
        capture_output=True,
        text=True,
        env={**os.environ, "HOME": str(tmp_path)},
        timeout=10,
    )
    assert result.returncode == 0, result.stderr
    out = result.stdout
    assert "b2-pipx-git-host" in out
    assert "git+https://github.com/and2carvalho/seif.git@main" in out
    # Stage 0 must NOT have run for --check
    assert "snapshot:" not in out
    assert "pre-pkg-pipx-commit:" not in out
