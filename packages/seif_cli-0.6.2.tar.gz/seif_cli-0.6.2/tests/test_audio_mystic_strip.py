"""Audio surface mystic-strip contract (s57 PR-7).

cmd_communicate output and --audio CLI help must not contain mystic framing
('Schumann resonance', 'human-machine resonance', 'experience the resonance').
The carrier 432Hz number itself stays — it's a math constant — but it must
not be embedded in user-facing help strings as the *purpose* of the flag.
"""

from __future__ import annotations

import re
from pathlib import Path

import pytest


CLI_PATH = Path(__file__).resolve().parents[1] / "src" / "seif" / "cli" / "cli.py"


@pytest.fixture(scope="module")
def cli_source() -> str:
    return CLI_PATH.read_text()


# ── cmd_communicate body ────────────────────────────────────────────────────


def _extract_function(source: str, name: str) -> str:
    m = re.search(rf'(^def {name}\b.*?)(?=\n^def |\Z)', source, re.DOTALL | re.MULTILINE)
    assert m is not None, f"function {name} not found"
    return m.group(1)


def test_cmd_communicate_no_schumann(cli_source: str):
    body = _extract_function(cli_source, "cmd_communicate")
    assert "Schumann" not in body, "cmd_communicate must not name Schumann in user-facing strings"


def test_cmd_communicate_no_human_machine_resonance(cli_source: str):
    body = _extract_function(cli_source, "cmd_communicate")
    assert "human-machine resonance" not in body
    assert "experience the resonance" not in body


def test_cmd_communicate_neutral_title(cli_source: str):
    body = _extract_function(cli_source, "cmd_communicate")
    # New canonical title: AUDIO CARRIER (engineering-honest demo path)
    assert "SEIF AUDIO CARRIER" in body, "cmd_communicate report title should be neutral"
    assert "SEIF OS COMMUNICATION" not in body, "old mystic title removed"


def test_cmd_communicate_points_to_watermark_for_payload(cli_source: str):
    """Demo path documents the real provenance escape hatch."""
    body = _extract_function(cli_source, "cmd_communicate")
    assert "--watermark-embed" in body, \
        "cmd_communicate must reference --watermark-embed as the real payload path"


# ── --audio CLI help ────────────────────────────────────────────────────────


def test_audio_help_neutral(cli_source: str):
    block = re.search(r'add_argument\("--audio".*?\)', cli_source, re.DOTALL)
    assert block is not None
    text = block.group(0)
    assert "432Hz" not in text and "432 Hz" not in text, \
        "--audio help must not bake the carrier frequency into the description"
    assert "Apenas áudio" not in text, "Portuguese mystic shorthand removed"
    assert "Render audio" in text or "audio output" in text.lower(), \
        "--audio help must describe the engineering function neutrally"
