"""Tests for tool-workspace-disambiguation (s44 INIT-FOUNDATION 4/4).

Closes the silent-symlink gap discovered when `seif --stamp` reported FAILED
paths because cwd `.seif/` resolved to a different physical workspace
(`/Volumes/DockerData/seif-projects/.seif` → `/Volumes/DockerData/seif-admin/.seif`)
without surfacing the redirection.
"""
from __future__ import annotations

import io
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from seif.cli.cli import _print_workspace_attribution  # noqa: E402
from seif.cli.wrapper import _signal_workspace_provenance  # noqa: E402
from seif.context.workspace import resolve_workspace_with_provenance  # noqa: E402


class ResolveWorkspaceWithProvenanceTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name).resolve()

    def tearDown(self):
        self.tmp.cleanup()

    def test_no_seif_returns_none(self):
        info = resolve_workspace_with_provenance(self.root)
        self.assertIsNone(info["seif_dir"])
        self.assertIsNone(info["real_path"])
        self.assertFalse(info["is_symlink"])
        self.assertIsNone(info["found_at"])
        self.assertEqual(info["cwd"], self.root)

    def test_seif_at_cwd_not_symlink(self):
        seif = self.root / ".seif"
        seif.mkdir()
        info = resolve_workspace_with_provenance(self.root)
        self.assertEqual(info["seif_dir"], seif)
        self.assertEqual(info["real_path"], seif.resolve())
        self.assertFalse(info["is_symlink"])
        self.assertEqual(info["found_at"], "cwd")

    def test_seif_at_parent(self):
        seif = self.root / ".seif"
        seif.mkdir()
        child = self.root / "subproject"
        child.mkdir()
        info = resolve_workspace_with_provenance(child)
        self.assertEqual(info["seif_dir"], seif)
        self.assertEqual(info["found_at"], "parent")
        self.assertFalse(info["is_symlink"])

    def test_symlinked_seif_marks_is_symlink_true(self):
        # Real .seif lives in admin; project has a symlink pointing there.
        admin = self.root / "admin"
        admin.mkdir()
        admin_seif = admin / ".seif"
        admin_seif.mkdir()

        project = self.root / "project"
        project.mkdir()
        link = project / ".seif"
        os.symlink(admin_seif, link)

        info = resolve_workspace_with_provenance(project)
        self.assertEqual(info["seif_dir"], link)
        self.assertEqual(info["real_path"], admin_seif.resolve())
        self.assertTrue(info["is_symlink"])
        self.assertEqual(info["found_at"], "cwd")


class SignalWorkspaceProvenanceOutputTests(unittest.TestCase):
    """Wrapper startup-line — must lead status surface, expose symlinks."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name).resolve()
        self.cwd_before = Path.cwd()

    def tearDown(self):
        os.chdir(self.cwd_before)
        self.tmp.cleanup()

    def _capture(self) -> str:
        buf = io.StringIO()
        with patch("sys.stderr", buf):
            _signal_workspace_provenance()
        return buf.getvalue()

    def test_silent_when_no_seif_dir(self):
        os.chdir(self.root)
        self.assertEqual(self._capture(), "")

    def test_plain_workspace_emits_one_line(self):
        seif = self.root / ".seif"
        seif.mkdir()
        os.chdir(self.root)
        out = self._capture()
        self.assertIn("[SEIF] Workspace:", out)
        self.assertIn(str(seif), out)
        self.assertNotIn(" → ", out)

    def test_symlinked_workspace_shows_realpath_after_arrow(self):
        admin = self.root / "admin"
        admin.mkdir()
        admin_seif = admin / ".seif"
        admin_seif.mkdir()
        project = self.root / "project"
        project.mkdir()
        os.symlink(admin_seif, project / ".seif")

        os.chdir(project)
        out = self._capture()
        self.assertIn("[SEIF] Workspace:", out)
        self.assertIn(" → ", out)
        self.assertIn(str(project / ".seif"), out)
        self.assertIn(str(admin_seif), out)


class CliCommandAttributionTests(unittest.TestCase):
    """`seif --stamp` and friends must show resolved target before acting."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name).resolve()

    def tearDown(self):
        self.tmp.cleanup()

    def _capture_stdout(self, target: Path) -> str:
        buf = io.StringIO()
        with patch("sys.stdout", buf):
            _print_workspace_attribution(target)
        return buf.getvalue()

    def test_plain_path_shows_absolute(self):
        f = self.root / "module.seif"
        f.write_text("{}", encoding="utf-8")
        out = self._capture_stdout(f)
        self.assertIn("[SEIF] Target:", out)
        self.assertIn(str(f), out)
        self.assertNotIn(" → ", out)

    def test_symlinked_path_shows_redirection(self):
        real = self.root / "real.seif"
        real.write_text("{}", encoding="utf-8")
        link = self.root / "link.seif"
        os.symlink(real, link)
        out = self._capture_stdout(link)
        self.assertIn(" → ", out)
        self.assertIn(str(link), out)
        self.assertIn(str(real), out)

    def test_nonexistent_path_falls_back_to_absolute(self):
        target = self.root / "does-not-exist.seif"
        out = self._capture_stdout(target)
        self.assertIn("[SEIF] Target:", out)
        self.assertIn(str(target), out)


if __name__ == "__main__":
    unittest.main()
