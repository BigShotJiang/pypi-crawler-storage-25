"""Tests for s56 PR2 Layer A — session-start.sh assigns UUID via python3
when stdin lacks/malforms session_id.

Replaces the legacy `'unknown'` fallback that produced active/unknown.json
(s55 live regression). These tests invoke only the SESSION_ID extraction
fragment, not the full hook (which depends on a real .seif/ workspace).
"""

from __future__ import annotations

import re
import subprocess
import uuid
from pathlib import Path

import pytest


HOOK = (
    Path(__file__).resolve().parents[1]
    / "src" / "seif" / "plugins" / "adapters" / "claude-code"
    / "scripts" / "session-start.sh"
)


# Mirror of the shell fragment so we can drive it with stdin variants
# without running the full hook (which requires a real .seif/ tree).
def _extract_session_id(stdin: str) -> str:
    """Run the same python3 invocation the shim uses and capture its output."""
    py = '''
import json, sys, uuid
try:
    sid = (json.load(sys.stdin).get("session_id") or "").strip()
except Exception:
    sid = ""
try:
    uuid.UUID(sid)
    print(sid)
except (ValueError, TypeError):
    print(uuid.uuid4())
'''
    result = subprocess.run(
        ["python3", "-c", py],
        input=stdin,
        capture_output=True,
        text=True,
        timeout=5,
    )
    return result.stdout.strip()


def test_valid_uuid_passes_through():
    sid = str(uuid.uuid4())
    out = _extract_session_id(f'{{"session_id": "{sid}"}}')
    assert out == sid


def test_missing_session_id_yields_fresh_uuid():
    out = _extract_session_id('{"other_field": "value"}')
    uuid.UUID(out)


def test_literal_unknown_yields_fresh_uuid():
    """The s55 regression payload — must NEVER produce 'unknown' anymore."""
    out = _extract_session_id('{"session_id": "unknown"}')
    assert out != "unknown"
    uuid.UUID(out)


def test_empty_session_id_yields_fresh_uuid():
    out = _extract_session_id('{"session_id": ""}')
    uuid.UUID(out)


def test_null_session_id_yields_fresh_uuid():
    out = _extract_session_id('{"session_id": null}')
    uuid.UUID(out)


def test_malformed_json_yields_fresh_uuid():
    out = _extract_session_id('{not valid json')
    uuid.UUID(out)


def test_empty_stdin_yields_fresh_uuid():
    out = _extract_session_id('')
    uuid.UUID(out)


def test_whitespace_padded_uuid_is_normalized():
    sid = str(uuid.uuid4())
    out = _extract_session_id(f'{{"session_id": "  {sid}  "}}')
    assert out == sid


def test_hook_script_contains_uuid_fallback():
    """Smoke check: the shipped script still uses python3 UUID generation,
    not the legacy 'unknown' literal."""
    text = HOOK.read_text()
    # Must NOT fall back to literal 'unknown' for SESSION_ID anymore
    legacy_pattern = re.compile(
        r"get\('session_id'\s*,\s*'unknown'\)"
    )
    assert not legacy_pattern.search(text), \
        "session-start.sh still has the legacy 'unknown' fallback"
    # Must invoke uuid for the fallback
    assert "uuid.uuid4()" in text or "uuid.UUID" in text, \
        "session-start.sh missing uuid-based fallback"
