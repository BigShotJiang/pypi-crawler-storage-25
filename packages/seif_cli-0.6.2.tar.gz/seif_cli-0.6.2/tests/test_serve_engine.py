"""Tests for `seif serve --engine` (Phase 2.B) HTTP service."""
from __future__ import annotations

import json
import os
import sys
import threading
import time
import unittest
import urllib.error
import urllib.request
from pathlib import Path
import tempfile

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from seif.cli import serve_engine as se  # noqa: E402


def _free_port() -> int:
    import socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


class _ServerThread:
    """Spin up the engine server in a thread for one test, tear down on exit."""

    def __init__(self, token: str, port: int):
        from http.server import ThreadingHTTPServer
        se._EngineHandler.expected_token = token
        se._EngineHandler.started_at = time.time()
        self.httpd = ThreadingHTTPServer(("127.0.0.1", port), se._EngineHandler)
        self.thread = threading.Thread(target=self.httpd.serve_forever,
                                       daemon=True)

    def __enter__(self):
        self.thread.start()
        # Tiny wait for socket ready
        for _ in range(20):
            try:
                with urllib.request.urlopen(
                    f"http://127.0.0.1:{self.httpd.server_port}/health", timeout=0.5
                ) as r:
                    if r.status == 200:
                        return self
            except Exception:
                time.sleep(0.05)
        return self

    def __exit__(self, *exc):
        self.httpd.shutdown()
        self.httpd.server_close()


def _post(port: int, path: str, body: dict, token: str | None = None) -> tuple[int, dict]:
    req = urllib.request.Request(
        f"http://127.0.0.1:{port}{path}",
        data=json.dumps(body).encode("utf-8"),
        method="POST",
    )
    req.add_header("Content-Type", "application/json")
    if token is not None:
        req.add_header("Authorization", f"Bearer {token}")
    try:
        with urllib.request.urlopen(req, timeout=2) as resp:
            return resp.status, json.loads(resp.read())
    except urllib.error.HTTPError as e:
        try:
            payload = json.loads(e.read())
        except Exception:
            payload = {}
        return e.code, payload


def _get(port: int, path: str) -> tuple[int, dict]:
    try:
        with urllib.request.urlopen(
            f"http://127.0.0.1:{port}{path}", timeout=2
        ) as resp:
            return resp.status, json.loads(resp.read())
    except urllib.error.HTTPError as e:
        return e.code, {}


class ServeEngineTests(unittest.TestCase):

    def setUp(self):
        self.port = _free_port()
        self.token = "test-token-" + os.urandom(8).hex()

    def test_health_does_not_require_auth(self):
        with _ServerThread(self.token, self.port):
            status, body = _get(self.port, "/health")
            self.assertEqual(status, 200)
            self.assertTrue(body["ok"])
            self.assertGreaterEqual(body["uptime_s"], 0)

    def test_unknown_path_returns_404(self):
        with _ServerThread(self.token, self.port):
            status, _ = _get(self.port, "/no-such-route")
            self.assertEqual(status, 404)

    def test_post_without_token_returns_401(self):
        with _ServerThread(self.token, self.port):
            status, body = _post(self.port, "/classify", {"text": "x"})
            self.assertEqual(status, 401)
            self.assertIn("unauthorized", body.get("error", "").lower())

    def test_post_with_wrong_token_returns_401(self):
        with _ServerThread(self.token, self.port):
            status, _ = _post(self.port, "/classify", {"text": "x"},
                              token="wrong")
            self.assertEqual(status, 401)

    def test_classify_internal(self):
        with _ServerThread(self.token, self.port):
            status, body = _post(
                self.port, "/classify",
                {"text": "plain helpful text"}, token=self.token,
            )
            self.assertEqual(status, 200)
            self.assertEqual(body["classification"], "INTERNAL")
            self.assertEqual(body["exit_code"], 1)

    def test_classify_confidential(self):
        with _ServerThread(self.token, self.port):
            status, body = _post(
                self.port, "/classify",
                {"text": "API_KEY=sk-LIVE password=hunter2"},
                token=self.token,
            )
            self.assertEqual(status, 200)
            self.assertEqual(body["classification"], "CONFIDENTIAL")
            self.assertEqual(body["exit_code"], 2)

    def test_confirm_action_returns_awaiting(self):
        with _ServerThread(self.token, self.port):
            status, body = _post(
                self.port, "/confirm-action",
                {"action": "git push origin main",
                 "reason": "merge feature",
                 "caller": "cursor/agent-001"},
                token=self.token,
            )
            self.assertEqual(status, 200)
            self.assertEqual(body["decision"], "AWAITING")
            self.assertEqual(body["exit_code"], 2)
            self.assertIn("AWAITING_HUMAN_CONFIRMATION", body["message"])

    def test_confirm_action_missing_action_400(self):
        with _ServerThread(self.token, self.port):
            status, body = _post(
                self.port, "/confirm-action",
                {"reason": "no action field"},
                token=self.token,
            )
            self.assertEqual(status, 400)


class TokenManagementTests(unittest.TestCase):

    def test_ensure_token_creates_file_with_0600(self):
        with tempfile.TemporaryDirectory() as tmp:
            saved_dir = se._HOST_DIR
            saved_file = se._TOKEN_FILE
            try:
                se._HOST_DIR = Path(tmp) / ".seif" / "host"
                se._TOKEN_FILE = se._HOST_DIR / "engine-token"
                token = se._ensure_token()
                self.assertEqual(len(token), 64)  # 256-bit hex
                self.assertTrue(se._TOKEN_FILE.is_file())
                mode = oct(se._TOKEN_FILE.stat().st_mode & 0o777)
                self.assertEqual(mode, "0o600")
            finally:
                se._HOST_DIR = saved_dir
                se._TOKEN_FILE = saved_file

    def test_ensure_token_is_idempotent(self):
        with tempfile.TemporaryDirectory() as tmp:
            saved_dir = se._HOST_DIR
            saved_file = se._TOKEN_FILE
            try:
                se._HOST_DIR = Path(tmp) / ".seif" / "host"
                se._TOKEN_FILE = se._HOST_DIR / "engine-token"
                t1 = se._ensure_token()
                t2 = se._ensure_token()
                self.assertEqual(t1, t2,
                                 "second call must return existing token, "
                                 "not a new one")
            finally:
                se._HOST_DIR = saved_dir
                se._TOKEN_FILE = saved_file


if __name__ == "__main__":
    unittest.main()
