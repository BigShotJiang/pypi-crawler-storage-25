"""Tests for SEIF-WORKSPACE-v1 (s70 implementation).

Covers:
- find_umbrella_workspace walk-up logic (with various workspace_type states)
- write_seif_pointer + read_seif_pointer round-trip
- WorkspaceRegistry schema 1.1 fields (workspace_id/workspace_type/etc.)
- load_registry round-trip preserves new fields and falls back for legacy

Tests are inert wrt user-global ~/.seif/ state (per feedback_test_pollution_global_state):
all artifacts created under tmp_path; never invokes register_context().
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from seif.context.workspace import (  # noqa: E402
    WorkspaceRegistry,
    find_umbrella_workspace,
    write_seif_pointer,
    read_seif_pointer,
    load_registry,
)


class FindUmbrellaWorkspaceTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name).resolve()

    def tearDown(self):
        self.tmp.cleanup()

    def _write_workspace_json(self, root: Path, workspace_type: str = None,
                               workspace_id: str = "test-umbrella"):
        seif = root / ".seif"
        seif.mkdir(parents=True, exist_ok=True)
        data = {
            "workspace_name": root.name,
            "workspace_path": str(root),
            "projects": [],
        }
        if workspace_type is not None:
            data["workspace_type"] = workspace_type
            data["workspace_id"] = workspace_id
            data["schema_version"] = "1.1"
        (seif / "workspace.json").write_text(json.dumps(data))

    def test_finds_umbrella_from_subproject(self):
        umbrella = self.root / "umbrella"
        umbrella.mkdir()
        self._write_workspace_json(umbrella, workspace_type="umbrella",
                                    workspace_id="my-umbrella")
        sub = umbrella / "subproj-a"
        sub.mkdir()
        result = find_umbrella_workspace(str(sub))
        self.assertIsNotNone(result)
        found_root, found_id = result
        self.assertEqual(found_root.resolve(), umbrella.resolve())
        self.assertEqual(found_id, "my-umbrella")

    def test_finds_umbrella_at_root_itself(self):
        umbrella = self.root / "umbrella"
        umbrella.mkdir()
        self._write_workspace_json(umbrella, workspace_type="umbrella",
                                    workspace_id="my-umbrella")
        result = find_umbrella_workspace(str(umbrella))
        self.assertIsNotNone(result)
        self.assertEqual(result[0].resolve(), umbrella.resolve())

    def test_returns_none_when_no_umbrella(self):
        sub = self.root / "lonely-project"
        sub.mkdir()
        result = find_umbrella_workspace(str(sub))
        self.assertIsNone(result)

    def test_returns_none_inside_standalone(self):
        standalone = self.root / "standalone-ws"
        standalone.mkdir()
        self._write_workspace_json(standalone, workspace_type="standalone",
                                    workspace_id="standalone-ws")
        sub = standalone / "child"
        sub.mkdir()
        result = find_umbrella_workspace(str(sub))
        self.assertIsNone(result)

    def test_skips_legacy_workspace_json_keeps_walking(self):
        # Outer = umbrella (new schema)
        outer = self.root / "outer"
        outer.mkdir()
        self._write_workspace_json(outer, workspace_type="umbrella",
                                    workspace_id="outer-umbrella")
        # Middle = legacy (no workspace_type)
        middle = outer / "middle-legacy"
        middle.mkdir()
        self._write_workspace_json(middle, workspace_type=None)
        # Inner = a sub-project under middle
        inner = middle / "inner"
        inner.mkdir()
        # find_umbrella from inner should walk past middle (legacy) and hit outer
        result = find_umbrella_workspace(str(inner))
        self.assertIsNotNone(result)
        self.assertEqual(result[0].resolve(), outer.resolve())
        self.assertEqual(result[1], "outer-umbrella")


class SeifPointerTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name).resolve()
        self.umbrella = self.root / "umbrella"
        self.umbrella.mkdir()
        self.sub = self.umbrella / "subproj"
        self.sub.mkdir()

    def tearDown(self):
        self.tmp.cleanup()

    def test_write_pointer_creates_valid_json(self):
        path = write_seif_pointer(str(self.sub), str(self.umbrella),
                                   "test-umbrella")
        self.assertTrue(path.exists())
        data = json.loads(path.read_text())
        self.assertEqual(data["schema_version"], "1.0")
        self.assertEqual(data["workspace_id"], "test-umbrella")
        self.assertTrue(data["workspace_root"].startswith(".."))
        self.assertTrue(data["store"].endswith(".seif/"))

    def test_write_pointer_rejects_non_ancestor(self):
        # umbrella is not an ancestor of an unrelated path
        unrelated = self.root / "unrelated"
        unrelated.mkdir()
        with self.assertRaises(ValueError):
            write_seif_pointer(str(unrelated), str(self.umbrella),
                                "test-umbrella")

    def test_read_pointer_round_trip(self):
        write_seif_pointer(str(self.sub), str(self.umbrella),
                            "test-umbrella")
        result = read_seif_pointer(str(self.sub))
        self.assertIsNotNone(result)
        self.assertEqual(result["workspace_id"], "test-umbrella")
        self.assertIn("resolved_store", result)
        # resolved_store should point at umbrella's .seif/
        self.assertEqual(
            result["resolved_store"].resolve(),
            (self.umbrella / ".seif").resolve(),
        )

    def test_read_pointer_returns_none_when_absent(self):
        result = read_seif_pointer(str(self.sub))
        self.assertIsNone(result)

    def test_pointer_is_compact(self):
        # Pointer should be small (decision module spec ~80 bytes)
        path = write_seif_pointer(str(self.sub), str(self.umbrella),
                                   "test-umbrella")
        size = path.stat().st_size
        self.assertLess(size, 200,
                         f"pointer too large: {size} bytes (spec: ~80 bytes)")


class WorkspaceRegistrySchema11Tests(unittest.TestCase):
    def test_default_fields_present(self):
        reg = WorkspaceRegistry(
            workspace_name="test",
            workspace_path="/tmp/test",
        )
        self.assertEqual(reg.schema_version, "1.1")
        self.assertEqual(reg.workspace_type, "umbrella")
        self.assertEqual(reg.canonical_store, ".seif/")
        self.assertEqual(reg.workspace_id, "")
        self.assertEqual(reg.anchor_ref, "")

    def test_custom_workspace_id_and_type(self):
        reg = WorkspaceRegistry(
            workspace_name="test",
            workspace_path="/tmp/test",
            workspace_id="custom-id",
            workspace_type="standalone",
        )
        self.assertEqual(reg.workspace_id, "custom-id")
        self.assertEqual(reg.workspace_type, "standalone")


class LoadRegistryRoundTripTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name).resolve()

    def tearDown(self):
        self.tmp.cleanup()

    def test_load_with_schema_1_1_fields(self):
        seif = self.root / ".seif"
        seif.mkdir()
        data = {
            "workspace_name": "test",
            "workspace_path": str(self.root),
            "projects": [],
            "schema_version": "1.1",
            "workspace_id": "test-umbrella",
            "workspace_type": "umbrella",
            "canonical_store": ".seif/",
            "anchor_ref": "abc123",
        }
        (seif / "workspace.json").write_text(json.dumps(data))
        reg = load_registry(str(self.root))
        self.assertIsNotNone(reg)
        self.assertEqual(reg.workspace_id, "test-umbrella")
        self.assertEqual(reg.workspace_type, "umbrella")
        self.assertEqual(reg.schema_version, "1.1")
        self.assertEqual(reg.anchor_ref, "abc123")

    def test_load_legacy_workspace_json_falls_back(self):
        seif = self.root / ".seif"
        seif.mkdir()
        data = {
            "workspace_name": "legacy-ws",
            "workspace_path": str(self.root),
            "projects": [],
            # No schema_version / workspace_type / workspace_id
        }
        (seif / "workspace.json").write_text(json.dumps(data))
        reg = load_registry(str(self.root))
        self.assertIsNotNone(reg)
        # Defaults from load_registry fallback path
        self.assertEqual(reg.schema_version, "1.0")  # legacy default
        self.assertEqual(reg.workspace_type, "umbrella")  # safe default
        self.assertEqual(reg.workspace_id, "")


if __name__ == "__main__":
    unittest.main()
