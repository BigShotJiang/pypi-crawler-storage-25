"""Tests for seif.context.registry.rebuild_registry."""

import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from seif.context import registry as reg


class TestRebuildRegistry(unittest.TestCase):

    def setUp(self):
        # Redirect ~/.seif to a tmp dir for isolation.
        self.tmp = Path(tempfile.mkdtemp(prefix="seif_reg_"))
        self.user_home = self.tmp / "user_seif"
        self.user_home.mkdir()
        self._patch = self._monkeypatch_user_home(self.user_home)
        # The test tmpdir lives under /var/folders/ on macOS, which the
        # detector would normally flag as ephemeral. Suppress that for tests
        # so the workspaces inside our tmp tree are treated as real.
        self._original_ephemeral = reg.EPHEMERAL_PATH_PARTS
        reg.EPHEMERAL_PATH_PARTS = ()

        # Create real workspaces and an ephemeral one.
        self.workspace_root = self.tmp / "projects"
        self.workspace_root.mkdir()
        for name in ("real-a", "real-b"):
            (self.workspace_root / name / ".seif").mkdir(parents=True)
        # Ephemeral path inside a tmp-style folder
        ephemeral_root = self.tmp / "private" / "var" / "folders" / "tmpXYZ"
        ephemeral_root.mkdir(parents=True)
        (ephemeral_root / ".seif").mkdir()
        self.ephemeral_seif = ephemeral_root / ".seif"

    def tearDown(self):
        import shutil
        self._patch()
        reg.EPHEMERAL_PATH_PARTS = self._original_ephemeral
        shutil.rmtree(self.tmp, ignore_errors=True)

    def _monkeypatch_user_home(self, home):
        # registry.py does `from seif.data.paths import get_user_home`, which
        # binds the function into the registry module's namespace at import
        # time. Patching `paths.get_user_home` alone has no effect on that
        # already-bound reference, so override the symbol in registry.py too.
        from seif.data import paths
        original_paths = paths.get_user_home
        original_reg = reg.get_user_home
        paths.get_user_home = lambda: home
        reg.get_user_home = lambda: home

        def restore():
            paths.get_user_home = original_paths
            reg.get_user_home = original_reg
        return restore

    def _seed_registry(self, contexts):
        reg.save_registry({
            "protocol": reg.REGISTRY_PROTOCOL,
            "created_at": "2026-01-01T00:00:00+00:00",
            "updated_at": "2026-01-01T00:00:00+00:00",
            "contexts": contexts,
        })

    def test_drops_missing_paths(self):
        self._seed_registry([
            {
                "name": "stale", "path": str(self.tmp / "does-not-exist" / ".seif"),
                "remote": None, "visibility": "private",
                "created_at": "x", "updated_at": "x", "last_sync": None,
            },
        ])
        result = reg.rebuild_registry([str(self.workspace_root)])
        self.assertEqual(result["dropped"], 1)
        self.assertEqual(result["added"], 2)
        names = [c["name"] for c in result["registry"]["contexts"]]
        self.assertIn("real-a", names)
        self.assertIn("real-b", names)
        self.assertNotIn("stale", names)

    def test_drops_ephemeral_tmp_paths(self):
        # Re-enable real detector for this one test.
        reg.EPHEMERAL_PATH_PARTS = self._original_ephemeral
        ephemeral_path = "/private/var/folders/abc/tmpXYZ/.seif"
        self._seed_registry([
            {
                "name": "tmpXYZ", "path": ephemeral_path,
                "remote": None, "visibility": "private",
                "created_at": "x", "updated_at": "x", "last_sync": None,
            },
        ])
        result = reg.rebuild_registry([])
        self.assertEqual(result["dropped"], 1)
        names = [c["name"] for c in result["registry"]["contexts"]]
        self.assertNotIn("tmpXYZ", names)

    def test_keeps_valid_existing_entries(self):
        existing_path = str(self.workspace_root / "real-a" / ".seif")
        self._seed_registry([
            {
                "name": "real-a-existing", "path": existing_path,
                "remote": None, "visibility": "private",
                "created_at": "x", "updated_at": "x", "last_sync": None,
            },
        ])
        result = reg.rebuild_registry([str(self.workspace_root)])
        self.assertEqual(result["kept"], 1)
        # Should add real-b only (real-a already kept)
        self.assertEqual(result["added"], 1)
        names = [c["name"] for c in result["registry"]["contexts"]]
        self.assertIn("real-a-existing", names)
        self.assertIn("real-b", names)

    def test_dry_run_does_not_persist(self):
        self._seed_registry([])
        before = reg.load_registry()
        result = reg.rebuild_registry([str(self.workspace_root)], dry_run=True)
        self.assertEqual(result["added"], 2)
        after = reg.load_registry()
        self.assertEqual(before, after)

    def test_skips_build_artifact_paths(self):
        # Create .seif/ buried inside .next/ and node_modules/
        (self.workspace_root / "real-a" / ".next" / "standalone" / ".seif").mkdir(parents=True)
        (self.workspace_root / "real-a" / "node_modules" / "pkg" / ".seif").mkdir(parents=True)
        result = reg.rebuild_registry([str(self.workspace_root)])
        # Should still find only the 2 top-level workspaces, not the buried ones.
        added_paths = [c["path"] for c in result["added_entries"]]
        for ap in added_paths:
            self.assertNotIn(".next", ap)
            self.assertNotIn("node_modules", ap)
        self.assertEqual(result["added"], 2)

    def test_deduplicates_entries(self):
        path = str(self.workspace_root / "real-a" / ".seif")
        self._seed_registry([
            {"name": "dup-1", "path": path, "remote": None, "visibility": "private",
             "created_at": "x", "updated_at": "x", "last_sync": None},
            {"name": "dup-2", "path": path, "remote": None, "visibility": "private",
             "created_at": "x", "updated_at": "x", "last_sync": None},
        ])
        result = reg.rebuild_registry([str(self.workspace_root)])
        # Both initial dups resolve to same path: kept=1, second dropped as duplicate
        paths = [c["path"] for c in result["registry"]["contexts"]]
        self.assertEqual(len(paths), len(set(paths)))


if __name__ == "__main__":
    unittest.main()
