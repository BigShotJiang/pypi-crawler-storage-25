"""Tests for the Claude Code memory symlink installer.

Covers:
- escape rule for harness path computation
- create symlink when nothing exists at the harness path
- skip silently when symlink already points at canonical
- migrate files when harness path is a real dir
- refuse to clobber an existing symlink that points elsewhere
"""

from __future__ import annotations

import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from seif.cli.setup import (
    _claude_harness_memory_path,
    _install_memory_symlink,
)


class HarnessPathEscapingTests(unittest.TestCase):

    def test_escape_replaces_slash_with_hyphen(self):
        ws = Path("/Volumes/DockerData/seif-projects")
        with mock.patch.object(Path, "home", return_value=Path("/u/x")):
            result = _claude_harness_memory_path(ws)
        self.assertEqual(
            result,
            Path("/u/x/.claude/projects/-Volumes-DockerData-seif-projects/memory"),
        )

    def test_escape_handles_users_home(self):
        ws = Path("/Users/alice/proj")
        with mock.patch.object(Path, "home", return_value=Path("/Users/alice")):
            result = _claude_harness_memory_path(ws)
        self.assertEqual(
            result,
            Path("/Users/alice/.claude/projects/-Users-alice-proj/memory"),
        )


class InstallMemorySymlinkTests(unittest.TestCase):

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.fake_home = self.root / "home"
        self.fake_home.mkdir()
        self.workspace = self.root / "workspace"
        self.workspace.mkdir()
        (self.workspace / ".seif").mkdir()
        self._home_patcher = mock.patch.object(
            Path, "home", return_value=self.fake_home
        )
        self._home_patcher.start()

    def tearDown(self):
        self._home_patcher.stop()
        self.tmp.cleanup()

    def _harness(self) -> Path:
        return _claude_harness_memory_path(self.workspace)

    def _canonical(self) -> Path:
        return (self.workspace / ".seif" / "memory").resolve()

    def test_creates_symlink_when_nothing_exists(self):
        ok, status = _install_memory_symlink(self.workspace)
        self.assertTrue(ok)
        self.assertEqual(status, "linked")
        h = self._harness()
        self.assertTrue(h.is_symlink())
        self.assertEqual(h.resolve(), self._canonical())

    def test_idempotent_when_already_correct(self):
        # First install
        _install_memory_symlink(self.workspace)
        # Second install — should be no-op
        ok, status = _install_memory_symlink(self.workspace)
        self.assertTrue(ok)
        self.assertEqual(status, "already linked")

    def test_migrates_files_from_real_dir(self):
        h = self._harness()
        h.mkdir(parents=True)
        (h / "user_x.md").write_text("alice")
        (h / "feedback_y.md").write_text("bob")
        ok, status = _install_memory_symlink(self.workspace)
        self.assertTrue(ok, f"failed: {status}")
        self.assertIn("migrated 2", status)
        self.assertTrue(h.is_symlink())
        self.assertEqual(h.resolve(), self._canonical())
        self.assertTrue((self._canonical() / "user_x.md").exists())
        self.assertEqual((self._canonical() / "user_x.md").read_text(), "alice")
        self.assertTrue((self._canonical() / "feedback_y.md").exists())

    def test_refuses_to_clobber_foreign_symlink(self):
        h = self._harness()
        elsewhere = self.root / "elsewhere"
        elsewhere.mkdir()
        h.parent.mkdir(parents=True)
        os.symlink(str(elsewhere), str(h))
        ok, status = _install_memory_symlink(self.workspace)
        self.assertFalse(ok)
        self.assertIn("elsewhere", status)
        # Symlink unchanged
        self.assertEqual(Path(os.readlink(h)), elsewhere)

    def test_creates_canonical_dir_if_missing(self):
        # Remove .seif/memory before install — should be created
        canonical_dir = self.workspace / ".seif" / "memory"
        if canonical_dir.exists():
            canonical_dir.rmdir()
        ok, _ = _install_memory_symlink(self.workspace)
        self.assertTrue(ok)
        self.assertTrue(canonical_dir.is_dir())

    def test_skips_non_md_files_during_migration(self):
        h = self._harness()
        h.mkdir(parents=True)
        (h / "ok.md").write_text("md content")
        (h / "stray.txt").write_text("not memory")
        ok, status = _install_memory_symlink(self.workspace)
        # rmdir fails because stray.txt remains → returns False with helpful msg
        self.assertFalse(ok)
        self.assertIn("not empty", status)


if __name__ == "__main__":
    unittest.main()
