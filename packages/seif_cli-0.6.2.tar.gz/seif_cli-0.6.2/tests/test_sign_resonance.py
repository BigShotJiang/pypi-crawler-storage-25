"""Round-trip + tamper tests for RESONANCE.json signing.

Generates a temporary keypair so tests don't depend on the Owner key.
"""

from __future__ import annotations

import json
import os
from pathlib import Path

import pytest


@pytest.fixture
def temp_keys(tmp_path, monkeypatch):
    """Redirect ~/.seif/keys/ to tmp_path and generate a keypair there."""
    fake_seif = tmp_path / "home" / ".seif"
    fake_seif.mkdir(parents=True)

    from seif.core import signing as signing_mod

    monkeypatch.setattr(signing_mod, "get_user_home", lambda: fake_seif)

    priv, pub = signing_mod.keygen(force=True)
    return priv, pub


@pytest.fixture
def sample_resonance(tmp_path):
    """Minimal RESONANCE.json shape for testing."""
    doc = {
        "protocol": "SEIF-RESONANCE-v1",
        "cryptographic_identity": {
            "algorithm": "Ed25519",
            "key_fingerprint": "test_fp",
        },
        "validation": {
            "integrity_hash": "abc123",
        },
        "axioms": {
            "A1": "minimal_intervention",
            "A22": "forward_security",
        },
    }
    path = tmp_path / "RESONANCE.json"
    path.write_text(json.dumps(doc, indent=2))
    return path


def test_sign_then_verify_roundtrip(temp_keys, sample_resonance):
    from seif.core.sign_resonance import sign_resonance, verify_resonance_signature

    sign_resonance(sample_resonance)
    result = verify_resonance_signature(sample_resonance)

    assert result["valid"] is True, result["reason"]
    assert result["canonical_hash_match"] is True


def test_verify_detects_content_tamper(temp_keys, sample_resonance):
    from seif.core.sign_resonance import sign_resonance, verify_resonance_signature

    sign_resonance(sample_resonance)

    doc = json.loads(sample_resonance.read_text())
    doc["axioms"]["A99"] = "evil_axiom_added_after_signing"
    sample_resonance.write_text(json.dumps(doc, indent=2))

    result = verify_resonance_signature(sample_resonance)
    assert result["valid"] is False
    assert "tampered" in result["reason"].lower()
    assert result["canonical_hash_match"] is False


def test_verify_detects_signature_tamper(temp_keys, sample_resonance):
    from seif.core.sign_resonance import sign_resonance, verify_resonance_signature

    sign_resonance(sample_resonance)

    doc = json.loads(sample_resonance.read_text())
    sig = doc["cryptographic_identity"]["content_signature"]
    raw = list(__import__("base64").b64decode(sig["signed_hash"]))
    raw[0] ^= 0xFF
    sig["signed_hash"] = __import__("base64").b64encode(bytes(raw)).decode()
    sample_resonance.write_text(json.dumps(doc, indent=2))

    result = verify_resonance_signature(sample_resonance)
    assert result["valid"] is False
    assert "INVALID" in result["reason"] or "signature does not match" in result["reason"]


def test_unsigned_resonance_returns_no_signature(temp_keys, sample_resonance):
    from seif.core.sign_resonance import verify_resonance_signature

    result = verify_resonance_signature(sample_resonance)
    assert result["valid"] is False
    assert "No content_signature" in result["reason"]


def test_signing_without_private_key_raises(tmp_path, monkeypatch, sample_resonance):
    """Signing on a non-Owner machine must fail loudly per A22."""
    fake_seif = tmp_path / "non-owner-home" / ".seif"
    fake_seif.mkdir(parents=True)

    from seif.core import signing as signing_mod

    monkeypatch.setattr(signing_mod, "get_user_home", lambda: fake_seif)

    from seif.core.sign_resonance import sign_resonance

    with pytest.raises(FileNotFoundError, match="A22"):
        sign_resonance(sample_resonance)
