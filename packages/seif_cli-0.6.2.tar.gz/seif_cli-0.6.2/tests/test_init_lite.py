"""Tests for `seif --init --lite` (ADR-006).

Spec: seif-product/30-technical/08-init-lite-implementation-draft.md §6.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from seif.init_lite import LITE_FILES, run_init_lite


EXPECTED_DEFAULT = {
    "README.md",
    "AGENTS.md",
    ".seif-lite/BOOT.md",
    ".seif-lite/refs.md",
    "session-log.md",
    "decisions-pending.md",
}


def _files_in(target: Path) -> set[str]:
    out: set[str] = set()
    for p in target.rglob("*"):
        if p.is_file():
            out.add(str(p.relative_to(target)))
    return out


def test_default_emits_six_files(tmp_path: Path) -> None:
    target = tmp_path / "lite-default"
    created = run_init_lite(target, project_title="Default Project")
    rel = {str(p.relative_to(target)) for p in created}
    assert rel == EXPECTED_DEFAULT
    assert _files_in(target) == EXPECTED_DEFAULT


def test_no_lite_agents_skips_only_agents(tmp_path: Path) -> None:
    target = tmp_path / "lite-no-agents"
    created = run_init_lite(
        target, project_title="No Agents", with_agents=False,
    )
    rel = {str(p.relative_to(target)) for p in created}
    assert "AGENTS.md" not in rel
    expected = EXPECTED_DEFAULT - {"AGENTS.md"}
    assert rel == expected


def test_substitutes_project_title_and_init_date(tmp_path: Path) -> None:
    target = tmp_path / "lite-sub"
    run_init_lite(
        target,
        project_title="Hermès Diary",
        init_date="2026-05-06",
    )
    readme = (target / "README.md").read_text(encoding="utf-8")
    assert "Hermès Diary" in readme
    assert "2026-05-06" in readme
    log = (target / "session-log.md").read_text(encoding="utf-8")
    assert "Hermès Diary" in log
    assert "2026-05-06" in log
    # Sanity: no leftover placeholders anywhere in emitted files.
    for path in target.rglob("*"):
        if path.is_file():
            text = path.read_text(encoding="utf-8")
            assert "{{PROJECT_TITLE}}" not in text, path
            assert "{{INIT_DATE}}" not in text, path


def test_idempotent_without_force_then_force_overwrites(tmp_path: Path) -> None:
    target = tmp_path / "lite-idem"
    run_init_lite(target, project_title="Idem", init_date="2026-05-06")

    readme = target / "README.md"
    readme.write_text("user-edited", encoding="utf-8")

    # Second run without force: skip existing files.
    second = run_init_lite(target, project_title="Idem-changed", init_date="2026-05-07")
    assert second == []
    assert readme.read_text(encoding="utf-8") == "user-edited"

    # Force re-emits the template set.
    third = run_init_lite(
        target, project_title="Idem-forced", init_date="2026-05-08", force=True,
    )
    assert {str(p.relative_to(target)) for p in third} == EXPECTED_DEFAULT
    text = readme.read_text(encoding="utf-8")
    assert "Idem-forced" in text
    assert "2026-05-08" in text


def test_refuses_when_full_seif_dir_exists(tmp_path: Path) -> None:
    target = tmp_path / "lite-collision"
    target.mkdir()
    (target / ".seif").mkdir()
    with pytest.raises(RuntimeError, match=r"\.seif/"):
        run_init_lite(target, project_title="Collision")


def test_lite_files_mapping_is_complete(tmp_path: Path) -> None:
    # Guard against silent template drops between code and templates.
    template_pkg = Path(__file__).resolve().parents[1] / "src" / "seif" / "data" / "init_lite"
    on_disk = {p.name for p in template_pkg.glob("*.md")}
    assert on_disk == set(LITE_FILES.keys())
