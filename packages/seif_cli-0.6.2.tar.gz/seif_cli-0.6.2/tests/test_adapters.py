"""Tests for plugins/adapters/ — manifest schema conformance + render parity.

Validates every adapter under plugins/adapters/<name>/ satisfies
plugins/adapters/CONTRACT.md. Tests run without pytest, in line with
the rest of this project's test suite (unittest + Makefile harness).
"""
from __future__ import annotations

import importlib.util
import json
import os
import sys
import unittest
from pathlib import Path

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from seif.cli.plugin_sync import (  # noqa: E402
    check_adapters,
    _find_seif_repo,
    _load_schema,
    _validate_manifest_minimal,
)


REPO = _find_seif_repo()
ADAPTERS_DIR = REPO / "plugins" / "adapters" if REPO else None
SCHEMA = _load_schema(REPO) if REPO else {}


def _adapter_dirs() -> list[Path]:
    if ADAPTERS_DIR is None or not ADAPTERS_DIR.is_dir():
        return []
    return sorted(p for p in ADAPTERS_DIR.iterdir()
                  if p.is_dir() and (p / "manifest.json").is_file())


def _load_manifest(adapter_dir: Path) -> dict:
    return json.loads((adapter_dir / "manifest.json").read_text())


class AdapterContractTests(unittest.TestCase):
    """Each adapter must satisfy CONTRACT.md v1."""

    def test_repo_located(self):
        self.assertIsNotNone(REPO,
                             "expected to find plugins/adapters/ via _find_seif_repo")

    def test_schema_loaded(self):
        self.assertTrue(SCHEMA,
                        "manifest.schema.json should load")
        self.assertEqual(SCHEMA.get("$id", "").split("-v")[-1].rstrip(".json"),
                         "1",
                         "schema $id should declare contract version v1")

    def test_at_least_three_adapters(self):
        # We ship: claude-code, generic, copilot, cursor → 4 minimum
        self.assertGreaterEqual(len(_adapter_dirs()), 4,
                                "expected at least claude-code, generic, "
                                "copilot, cursor")

    def test_check_adapters_all_conformant(self):
        reports, code = check_adapters(REPO)
        non_conformant = [r for r in reports if not r.conformant]
        self.assertEqual(non_conformant, [],
                         f"non-conformant adapters: "
                         f"{[(r.name, r.schema_violations + r.render_violations) for r in non_conformant]}")
        self.assertEqual(code, 0)


class AdapterManifestSchemaTests(unittest.TestCase):
    """Per-adapter schema validation."""

    def test_each_manifest_validates(self):
        for d in _adapter_dirs():
            with self.subTest(adapter=d.name):
                manifest = _load_manifest(d)
                violations = _validate_manifest_minimal(manifest, SCHEMA)
                self.assertEqual(violations, [],
                                 f"{d.name}: {violations}")

    def test_each_capability_is_boolean(self):
        cap_keys = (SCHEMA.get("properties", {})
                          .get("capabilities", {})
                          .get("required", []))
        for d in _adapter_dirs():
            with self.subTest(adapter=d.name):
                manifest = _load_manifest(d)
                caps = manifest.get("capabilities", {})
                for k in cap_keys:
                    self.assertIn(k, caps, f"{d.name}: missing {k}")
                    self.assertIsInstance(caps[k], bool,
                                          f"{d.name}: {k} not bool")

    def test_degradations_non_negative(self):
        for d in _adapter_dirs():
            with self.subTest(adapter=d.name):
                manifest = _load_manifest(d)
                degs = manifest.get("degradations", [])
                self.assertIsInstance(degs, list)
                for entry in degs:
                    self.assertIsInstance(entry, str)
                    self.assertTrue(entry.strip(),
                                    f"{d.name}: empty degradation entry")

    def test_render_targets_match_capabilities(self):
        """If any capability is False → adapter must have either
        render_targets OR a non-empty degradations list."""
        for d in _adapter_dirs():
            with self.subTest(adapter=d.name):
                manifest = _load_manifest(d)
                caps = manifest.get("capabilities", {})
                if all(caps.values()):
                    continue
                has_render = bool(manifest.get("render_targets"))
                has_degs = bool(manifest.get("degradations"))
                self.assertTrue(has_render or has_degs,
                                f"{d.name}: gap not covered")


class AdapterRenderParityTests(unittest.TestCase):
    """All hookless adapters render the SAME axiom set (same protocol body).

    This is the cross-platform thesis: protocol-level parity across clients,
    even when runtime parity differs.
    """

    @staticmethod
    def _import_render(adapter_dir: Path):
        render_py = adapter_dir / "render" / "render.py"
        if not render_py.is_file():
            return None
        spec = importlib.util.spec_from_file_location(
            f"_test_render_{adapter_dir.name}", render_py
        )
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod

    def _hookless_adapters(self) -> list[Path]:
        out = []
        for d in _adapter_dirs():
            m = _load_manifest(d)
            caps = m.get("capabilities", {})
            if not (caps.get("runtime_hooks") or caps.get("skills_commands")):
                out.append(d)
        return out

    def test_each_hookless_adapter_renders_full_seed(self):
        for d in self._hookless_adapters():
            with self.subTest(adapter=d.name):
                render = self._import_render(d)
                self.assertIsNotNone(render,
                                     f"{d.name}: render.py absent or unimportable")
                output = render.render_seed(
                    seif_dir=Path(),
                    project_dir=REPO,
                    home=Path.home(),
                    content_kind="full_seed",
                )
                self.assertIsInstance(output, str)
                self.assertGreater(len(output), 500,
                                   f"{d.name}: full_seed too short ({len(output)} chars)")
                self.assertIn("SEIF:BEGIN", output)
                self.assertIn("SEIF:END", output)

    def test_full_seed_includes_confirm_action_gate(self):
        """The render must instruct AIs to invoke `seif --confirm-action`
        before destructive ops. Without this, A4 (human_gatekeeper) cannot
        be enforced on hookless clients (Phase 0 finding F2)."""
        for d in self._hookless_adapters():
            with self.subTest(adapter=d.name):
                render = self._import_render(d)
                if render is None:
                    continue
                output = render.render_seed(
                    seif_dir=Path(),
                    project_dir=REPO,
                    home=Path.home(),
                    content_kind="full_seed",
                )
                self.assertIn("seif --confirm-action", output,
                              f"{d.name}: render missing --confirm-action invocation")
                self.assertIn("AWAITING_HUMAN_CONFIRMATION", output,
                              f"{d.name}: render missing exit-2 signal description")
                self.assertIn("STOP", output,
                              f"{d.name}: render missing explicit STOP instruction")

    def test_axiom_count_consistent_across_adapters(self):
        """Every hookless adapter renders the SAME number of axioms (same
        RESONANCE.json)."""
        counts: dict[str, int] = {}
        for d in self._hookless_adapters():
            render = self._import_render(d)
            if render is None:
                continue
            output = render.render_seed(
                seif_dir=Path(),
                project_dir=REPO,
                home=Path.home(),
                content_kind="full_seed",
            )
            # Lines like "1. **id** — rule"
            count = sum(1 for line in output.splitlines()
                        if line.lstrip().startswith(tuple(f"{n}. **" for n in range(1, 100))))
            counts[d.name] = count

        if len(counts) >= 2:
            unique_counts = set(counts.values())
            self.assertEqual(len(unique_counts), 1,
                             f"axiom counts diverge across adapters: {counts}")
            sole = next(iter(unique_counts))
            self.assertGreater(sole, 5,
                               f"expected >5 axioms; got {sole} (RESONANCE.json missing?)")

    def test_each_content_kind_produces_output(self):
        kinds = ("full_seed", "kernel_seed", "axioms_summary",
                 "session_contract_static", "degradation_notice")
        for d in self._hookless_adapters():
            render = self._import_render(d)
            if render is None:
                continue
            for kind in kinds:
                with self.subTest(adapter=d.name, kind=kind):
                    output = render.render_seed(
                        seif_dir=Path(),
                        project_dir=REPO,
                        home=Path.home(),
                        content_kind=kind,
                    )
                    self.assertIsInstance(output, str)
                    self.assertGreater(len(output.strip()), 0,
                                       f"{d.name}/{kind}: empty output")


class AdapterMirrorTests(unittest.TestCase):
    """plugins/adapters/<name>/ and src/seif/plugins/adapters/<name>/ should
    be byte-identical except for documented divergences.

    Documented divergence (S31): claude-code/scripts/session-start.sh
    enables A20 inbox drain only in the src/seif/ mirror.
    """

    DOCUMENTED_DIVERGENCES = {
        # adapter_relpath → reason
        "claude-code/scripts/session-start.sh":
            "src/seif/ mirror enables opt-in flags (--inbox-drain A20, "
            "--daemon-activity s40 P4, --awareness s42 MVP); plugins/ mirror "
            "leaves them off — preserves S31 mirror divergence pattern",
    }

    def test_mirrors_match_or_documented(self):
        if REPO is None:
            self.skipTest("repo not located")
        repo_root_adapters = REPO / "plugins" / "adapters"
        pkg_adapters = REPO / "src" / "seif" / "plugins" / "adapters"
        if not repo_root_adapters.is_dir() or not pkg_adapters.is_dir():
            self.skipTest("mirror dirs missing")

        for d in _adapter_dirs():
            mirror = pkg_adapters / d.name
            if not mirror.is_dir():
                continue
            for f in d.rglob("*"):
                if not f.is_file() or f.name == ".DS_Store":
                    continue
                # Skip generated artifacts: pycache, pyc, etc.
                if "__pycache__" in f.parts or f.suffix == ".pyc":
                    continue
                rel = f.relative_to(d)
                key = f"{d.name}/{rel.as_posix()}"
                mirror_f = mirror / rel
                with self.subTest(adapter=d.name, file=str(rel)):
                    if key in self.DOCUMENTED_DIVERGENCES:
                        self.assertTrue(mirror_f.is_file(),
                                        f"{key}: mirror missing")
                        continue
                    self.assertTrue(mirror_f.is_file(),
                                    f"{key}: mirror missing")
                    self.assertEqual(f.read_bytes(), mirror_f.read_bytes(),
                                     f"{key}: mirror diverges and not documented")


if __name__ == "__main__":
    unittest.main()
