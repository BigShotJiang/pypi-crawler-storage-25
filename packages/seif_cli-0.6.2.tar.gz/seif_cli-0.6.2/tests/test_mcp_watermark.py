"""Tests for the MCP watermark server (Wedge A v1.0 DoD item 6).

Verifies the FastMCP tool registry and the embed/extract/fingerprint/verify
contract end-to-end. Synchronous wrappers around the async tool API so the
tests run under stock pytest without pytest-asyncio.
"""

from __future__ import annotations

import asyncio
import json
import unittest
import wave
from pathlib import Path

import numpy as np
import pytest


# Module-level skip compatible with pytest, unittest discovery, AND the
# CI matrix job which runs `python tests/test_*.py` (script mode). Any
# exception raised at module import in script mode produces exit code 1
# regardless of whether it is pytest.Skipped or unittest.SkipTest, so we
# branch on __name__ and exit cleanly when run as a bare script.
try:
    import mcp  # noqa: F401
except ImportError:
    if __name__ == "__main__":
        import sys
        print("MCP SDK not installed; skip [mcp] extra tests")
        sys.exit(0)
    raise unittest.SkipTest(
        "MCP SDK not installed; skip [mcp] extra tests"
    )


# Import after the gate so collection doesn't fail on bare seif installs.
from seif.mcp.watermark_server import build_server  # noqa: E402


EXPECTED_TOOLS = {
    "seif_watermark_embed",
    "seif_watermark_extract",
    "seif_fingerprint_file",
    "seif_watermark_verify",
    "seif_audio_provenance_verify",
}


def test_server_registers_expected_tools() -> None:
    server = build_server()
    tools = asyncio.run(server.list_tools())
    names = {t.name for t in tools}
    assert names == EXPECTED_TOOLS


def test_fingerprint_tool_returns_sha256(tmp_path: Path) -> None:
    target = tmp_path / "claim.txt"
    target.write_text("hello provenance", encoding="utf-8")

    payload = _call("seif_fingerprint_file", {"path": str(target)})
    assert payload["ok"] is True
    assert payload["path"] == str(target)
    assert len(payload["sha256"]) == 64
    int(payload["sha256"], 16)  # parses as hex


def test_fingerprint_tool_rejects_missing_file(tmp_path: Path) -> None:
    payload = _call(
        "seif_fingerprint_file", {"path": str(tmp_path / "nope.bin")}
    )
    assert payload["ok"] is False
    assert "not a file" in payload["error"]


def test_embed_then_extract_roundtrips(tmp_path: Path) -> None:
    carrier = _silent_wav(tmp_path / "carrier.wav", duration_s=900)
    out = tmp_path / "stamped.wav"

    embed_payload = _call(
        "seif_watermark_embed",
        {
            "input_wav": str(carrier),
            "output_wav": str(out),
            "text": "deadbeef" * 8,  # 64 hex chars, sha256-shaped
        },
    )
    assert embed_payload["ok"] is True
    assert embed_payload["symbols"] == 64
    assert out.exists()

    extract_payload = _call(
        "seif_watermark_extract",
        {"input_wav": str(out), "n_symbols": 64},
    )
    assert extract_payload["ok"] is True
    assert extract_payload["payload"] == "deadbeef" * 8


def test_verify_tool_matches_fingerprint(tmp_path: Path) -> None:
    from seif.generators.watermark import file_sha256_hex

    claim = tmp_path / "claim.txt"
    claim.write_text("provenance demo", encoding="utf-8")
    expected = file_sha256_hex(claim)

    carrier = _silent_wav(tmp_path / "carrier.wav", duration_s=900)
    stamped = tmp_path / "stamped.wav"

    _call(
        "seif_watermark_embed",
        {
            "input_wav": str(carrier),
            "output_wav": str(stamped),
            "fingerprint_of": str(claim),
        },
    )
    payload = _call(
        "seif_watermark_verify",
        {"input_wav": str(stamped), "expected_path": str(claim)},
    )
    assert payload["ok"] is True
    assert payload["valid"] is True
    assert payload["extracted"] == expected
    assert payload["expected"] == expected


def test_embed_requires_exactly_one_payload_source(tmp_path: Path) -> None:
    carrier = _silent_wav(tmp_path / "carrier.wav", duration_s=900)
    out = tmp_path / "stamped.wav"

    with pytest.raises(Exception):
        _call(
            "seif_watermark_embed",
            {"input_wav": str(carrier), "output_wav": str(out)},
        )

    with pytest.raises(Exception):
        _call(
            "seif_watermark_embed",
            {
                "input_wav": str(carrier),
                "output_wav": str(out),
                "text": "abc",
                "fingerprint_of": str(carrier),
            },
        )


def _call(tool_name: str, args: dict) -> dict:
    server = build_server()
    result = asyncio.run(server.call_tool(tool_name, args))
    return _structured(result)


def _silent_wav(path: Path, *, duration_s: int, sample_rate: int = 44100) -> Path:
    """Write a mono 16-bit silent WAV long enough for a sha256-shaped payload.

    A 64-symbol payload at 4s × 3 reps = 768 s; pad headroom to 900 s.
    """
    n = duration_s * sample_rate
    silence = np.zeros(n, dtype=np.int16)
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sample_rate)
        w.writeframes(silence.tobytes())
    return path


def _structured(result: object) -> dict:
    """Pull the structured-content dict out of a FastMCP tool-call result.

    FastMCP wraps dict-returning tools as a list of TextContent blocks
    whose `.text` is the JSON-serialized payload. Some versions also
    return a tuple of (content_blocks, structured_content).
    """
    if isinstance(result, tuple) and len(result) == 2:
        return result[1]  # type: ignore[return-value]
    if isinstance(result, dict):
        return result
    if isinstance(result, list) and result:
        first = result[0]
        text = getattr(first, "text", None)
        if text is not None:
            return json.loads(text)
    raise AssertionError(f"unexpected tool result shape: {result!r}")
