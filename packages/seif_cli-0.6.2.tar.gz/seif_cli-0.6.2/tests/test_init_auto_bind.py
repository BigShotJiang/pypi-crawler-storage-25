"""Tests for `seif --init` auto-binding hookless adapters (Phase 1.B).

After `seif --init` finishes, hookless adapters whose client_detect
predicates match the new workspace should have their render_targets
written automatically. Eliminates the need for users to run
`seif --plugin-detect --apply` as a separate step."""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

REPO_ROOT = Path(__file__).resolve().parent.parent


class InitAutoBindTests(unittest.TestCase):

    def setUp(self):
        # Pre-flight: ensure plugin_detect is importable
        try:
            from seif.cli.plugin_detect import detect_adapters  # noqa: F401
        except ImportError:
            self.skipTest("plugin_detect not available in this build")

    def _run_init(self, project_dir: Path) -> tuple[int, str]:
        """Invoke `seif --init <dir>` as a subprocess. Returns (rc, stdout)."""
        env = os.environ.copy()
        env["PYTHONPATH"] = f"{REPO_ROOT}/src:{env.get('PYTHONPATH','')}"
        result = subprocess.run(
            [sys.executable, "-m", "seif.cli.cli", "--init", str(project_dir),
             "--yes"],
            cwd=str(REPO_ROOT),
            env=env,
            capture_output=True, text=True, timeout=30,
        )
        return result.returncode, (result.stdout or "") + (result.stderr or "")

    def test_init_renders_for_copilot_when_vscode_present(self):
        """If the project has .vscode/, copilot adapter detects and binds.
        seif --init should write .github/copilot-instructions.md."""
        with tempfile.TemporaryDirectory() as tmp:
            project = Path(tmp)
            (project / ".vscode").mkdir()
            (project / "README.md").write_text("# Test project\n")

            rc, output = self._run_init(project)
            self.assertEqual(rc, 0,
                             f"init exit non-zero ({rc}); output={output[:500]}")

            # CLAUDE.md is the existing init artifact — still expected
            self.assertTrue((project / "CLAUDE.md").exists() or
                            (project / "AGENTS.md").exists() or
                            (project / ".github" / "copilot-instructions.md").exists(),
                            f"no auto-bound files found; output={output[-1000:]}")

            # Copilot adapter should bind on .vscode/
            copilot_target = project / ".github" / "copilot-instructions.md"
            self.assertTrue(copilot_target.is_file(),
                            f"copilot-instructions.md not auto-bound; "
                            f"output tail:\n{output[-1500:]}")
            content = copilot_target.read_text()
            self.assertIn("SEIF:BEGIN", content)
            self.assertIn("seif --confirm-action", content)

    def test_init_does_not_bind_runtime_capable_adapters(self):
        """claude-code is runtime-capable; init should NOT auto-write its
        hooks (those go via `seif setup claude-code`). Only hookless
        adapters get rendered automatically."""
        with tempfile.TemporaryDirectory() as tmp:
            project = Path(tmp)
            (project / ".vscode").mkdir()  # triggers copilot only
            self._run_init(project)
            # No claude-code-specific hook files written by init
            # (~/.local/share/seif/claude-code/scripts/ is global; init
            # doesn't touch it. We just check the project tree stays clean
            # of claude-code runtime artifacts).
            self.assertFalse((project / ".claude" / "settings.json").is_file(),
                             "init should not write Claude Code settings")

    def test_init_preserves_existing_user_content_in_targets(self):
        """If a render target file already has user content outside SEIF
        markers, init should preserve it (between_markers strategy)."""
        with tempfile.TemporaryDirectory() as tmp:
            project = Path(tmp)
            (project / ".vscode").mkdir()
            (project / ".github").mkdir()
            target = project / ".github" / "copilot-instructions.md"
            target.write_text("# User-authored intro\n\nMy custom rules.\n")

            self._run_init(project)
            content = target.read_text()
            self.assertIn("# User-authored intro", content,
                          "user content not preserved")
            self.assertIn("My custom rules.", content)
            self.assertIn("SEIF:BEGIN", content,
                          "SEIF block not appended")


if __name__ == "__main__":
    unittest.main()
