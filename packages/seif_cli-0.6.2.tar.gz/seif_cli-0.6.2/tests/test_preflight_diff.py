"""Tests for s42 awareness MVP — preflight_diff."""

from __future__ import annotations

import os
import subprocess
from pathlib import Path

import pytest

from seif.plugins.core.preflight_diff import (
    current_heads,
    detect_sibling_drift,
    discover_repos,
    render_warning_block,
)


def _git_init(path: Path):
    path.mkdir(parents=True, exist_ok=True)
    subprocess.run(
        ["git", "init", "-q", "-b", "main", str(path)], check=True
    )
    subprocess.run(
        [
            "git", "-C", str(path),
            "-c", "user.email=t@t",
            "-c", "user.name=t",
            "commit", "-q", "--allow-empty", "-m", "init",
        ],
        check=True,
        env={**os.environ, "HOME": str(path.parent)},
    )


# ── discover_repos ──────────────────────────────────────────────


def test_discover_repos_finds_immediate_children(tmp_path):
    _git_init(tmp_path / "alpha")
    _git_init(tmp_path / "beta")
    (tmp_path / "not-a-repo").mkdir()
    (tmp_path / "file.txt").write_text("nope")

    repos = discover_repos(tmp_path)
    names = [r.name for r in repos]
    assert names == ["alpha", "beta"]  # sorted, only git dirs


def test_discover_repos_skips_dotfile_dirs(tmp_path):
    _git_init(tmp_path / "real")
    _git_init(tmp_path / ".hidden")
    repos = discover_repos(tmp_path)
    assert [r.name for r in repos] == ["real"]


def test_discover_repos_returns_empty_for_missing_root(tmp_path):
    assert discover_repos(tmp_path / "does-not-exist") == []


def test_discover_repos_returns_empty_for_no_git_children(tmp_path):
    (tmp_path / "plain").mkdir()
    assert discover_repos(tmp_path) == []


# ── current_heads ───────────────────────────────────────────────


def test_current_heads_returns_sha_per_repo(tmp_path):
    _git_init(tmp_path / "alpha")
    _git_init(tmp_path / "beta")
    repos = discover_repos(tmp_path)
    heads = current_heads(repos)
    assert set(heads.keys()) == {"alpha", "beta"}
    # Each value is a 40-char sha (or 64 if SHA-256)
    for sha in heads.values():
        assert len(sha) >= 40


def test_current_heads_drops_repo_with_unreadable_head(tmp_path):
    repo = tmp_path / "broken"
    repo.mkdir()
    (repo / ".git").mkdir()  # malformed git dir, no HEAD
    heads = current_heads([repo])
    assert "broken" not in heads


def test_current_heads_handles_empty_input():
    assert current_heads([]) == {}


# ── detect_sibling_drift ────────────────────────────────────────


def test_detect_sibling_drift_flags_mismatch():
    my = {"seif": "abc111", "bridge": "def222"}
    siblings = [
        {
            "session_id": "s1",
            "wrapper": "copilot",
            "host": "air-m1",
            "pid": 9876,
            "started_at": "2026-05-01T19:00:00Z",
            "repos_observed": {"seif": "abc999"},  # diff
        }
    ]
    drift = detect_sibling_drift(my, siblings)
    assert len(drift) == 1
    row = drift[0]
    assert row["repo"] == "seif"
    assert row["my_sha"] == "abc111"
    assert row["sibling_sha"] == "abc999"
    assert row["sibling_wrapper"] == "copilot"
    assert row["sibling_host"] == "air-m1"


def test_detect_sibling_drift_silent_when_aligned():
    my = {"seif": "abc111"}
    siblings = [{"session_id": "s1", "repos_observed": {"seif": "abc111"}}]
    assert detect_sibling_drift(my, siblings) == []


def test_detect_sibling_drift_ignores_repos_sibling_didnt_observe():
    my = {"seif": "abc", "private": "xyz"}
    siblings = [{"session_id": "s1", "repos_observed": {"seif": "abc"}}]
    # No conflict: both observed seif at same sha, sibling didn't observe private.
    assert detect_sibling_drift(my, siblings) == []


def test_detect_sibling_drift_aggregates_multiple_siblings():
    my = {"seif": "abc"}
    siblings = [
        {"session_id": "s1", "wrapper": "x", "repos_observed": {"seif": "111"}},
        {"session_id": "s2", "wrapper": "y", "repos_observed": {"seif": "222"}},
    ]
    drift = detect_sibling_drift(my, siblings)
    assert len(drift) == 2
    assert {r["sibling_sha"] for r in drift} == {"111", "222"}


def test_detect_sibling_drift_handles_empty_inputs():
    assert detect_sibling_drift({}, []) == []
    assert detect_sibling_drift({"a": "x"}, []) == []
    assert detect_sibling_drift({}, [{"session_id": "s", "repos_observed": {}}]) == []


# ── render_warning_block ────────────────────────────────────────


def test_render_warning_block_empty_when_no_siblings_no_drift():
    assert render_warning_block([], []) == ""


def test_render_warning_block_lists_siblings_without_drift():
    siblings = [
        {
            "wrapper": "copilot",
            "host": "air-m1",
            "pid": 1234,
            "started_at": "2026-05-01T19:55:00Z",
        }
    ]
    out = render_warning_block(siblings, [])
    assert "AWARENESS" in out
    assert "active siblings: 1" in out
    assert "copilot @ air-m1" in out
    assert "pid 1234" in out
    # No drift section when drift is empty
    assert "diverges" not in out


def test_render_warning_block_includes_drift_with_short_shas():
    siblings = [{"wrapper": "x", "host": "h", "pid": 1, "started_at": "t"}]
    drift = [
        {
            "repo": "seif",
            "my_sha": "1234567890abcdef",
            "sibling_session_id": "sid",
            "sibling_wrapper": "x",
            "sibling_host": "h",
            "sibling_pid": 1,
            "sibling_started_at": "t",
            "sibling_sha": "fedcba0987654321",
        }
    ]
    out = render_warning_block(siblings, drift)
    assert "diverges on 1 repo(s)" in out
    assert "seif:" in out
    # Short shas (7 chars) for readability
    assert "1234567" in out
    assert "fedcba0" in out
    assert "Verify before issuing seeds" in out
