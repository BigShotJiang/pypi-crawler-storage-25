"""Tests for gap-9 — `seif --agents-set` tier-1 role validation.

Per SEIF.md → Agent Roles (Two-Axis Taxonomy), tier-1 agent-roles are invariant
across SEIF deployments. The CLI must reject non-tier-1 names with a helpful
error pointing back to the kernel taxonomy.
"""
from __future__ import annotations

import io
import os
import sys
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from seif.cli import cli  # noqa: E402


class Tier1AgentRoleValidationTests(unittest.TestCase):

    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.ctx = Path(self._tmp.name)
        (self.ctx / "modules").mkdir(parents=True)

    def tearDown(self):
        self._tmp.cleanup()

    def _run(self, assignment: str) -> str:
        buf = io.StringIO()
        with redirect_stdout(buf):
            cli._cmd_agents_set(assignment, str(self.ctx))
        return buf.getvalue()

    def test_tier1_names_are_canonical(self):
        # The canonical eight per SEIF.md kernel section.
        self.assertEqual(
            set(cli._TIER1_AGENT_ROLES),
            {"maestro", "writer", "executor", "vigilant",
             "sentinel", "researcher", "analyst", "gatekeeper"},
        )

    def test_rejects_non_tier1_role_with_helpful_error(self):
        out = self._run("orchestrator=claude")
        self.assertIn("Unknown agent role 'orchestrator'", out)
        self.assertIn("SEIF.md", out)
        # Must enumerate tier-1 names so the user sees the valid set.
        for role in cli._TIER1_AGENT_ROLES:
            self.assertIn(role, out)
        # Must NOT have written the assignment.
        self.assertFalse(
            (self.ctx / "modules" / cli._AGENT_ROLES_FILE).exists()
        )

    def test_accepts_tier1_role(self):
        out = self._run("writer=claude")
        self.assertIn("AGENT ROLE UPDATED", out)
        self.assertTrue(
            (self.ctx / "modules" / cli._AGENT_ROLES_FILE).exists()
        )

    def test_format_error_unchanged(self):
        out = self._run("no-equals-sign")
        self.assertIn("ROLE=AGENT", out)


if __name__ == "__main__":
    unittest.main()
