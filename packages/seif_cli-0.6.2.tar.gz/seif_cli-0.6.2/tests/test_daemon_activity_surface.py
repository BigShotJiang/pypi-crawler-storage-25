"""Tests for s40 P4: session-start daemon-activity surface.

The interactive session has had no awareness that its sibling claude-responder
daemon emitted replies on its behalf — flagged in s39 P7 as
"Air-claude estava parado". This phase reads the daemon outbox at session
start and surfaces a [DAEMON ACTIVITY] block so the session can ACK to
the gatekeeper (per A23 / feedback_ai_ack_to_gatekeeper).

Properties under test:
  - empty / missing outbox → no surface
  - SEIF-SEED-v1 envelope renders with node + echo + reply preview
  - legacy {content, responder_tag, timestamp} renders too (until P1 deploys
    everywhere, both shapes coexist on the bus)
  - unreadable JSON does not crash the hook
  - watermark idempotency: second call after the same files surfaces nothing
  - max_items truncates head, summary line counts the remainder
  - never deletes the daemon outbox — surface-only contract
  - integration: session_start_logic threads the flag and embeds the block
"""

from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path


# tests/ is run as `python tests/test_*.py` per Makefile; src/ must be on path
REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT / "src"))

from seif.plugins.core import session_lifecycle as sl  # noqa: E402


def _envelope_reply(home: Path, name: str, *, node: str = "mini-m4",
                    reply: str = "all-ok", echo: str = "ping?",
                    ts: str = "2026-05-01T21:00:00+00:00") -> None:
    payload = {
        "schema": "SEIF-SEED-v1",
        "seed_id": f"claude-responder-{name}",
        "timestamp": ts,
        "issued_by": {
            "agent": "claude-responder",
            "node": node,
            "fingerprint": "abc123",
            "model": "claude-code-cli (headless)",
            "context_loaded": False,
        },
        "received_seed_echo": {
            "prompt_preview": echo,
            "arrival_timestamp": ts,
        },
        "processing_summary": {
            "rate_cap_remaining": 4,
            "claude_invocation_duration_ms": 100,
            "exit_status": "success",
        },
        "my_reply_content": reply,
        "output_to": {"channel": "bus/handoff", "target": "*"},
        "channel": "bus/handoff",
        "content": f"[claude-responder] {reply}",
        "responder_tag": "claude-responder",
    }
    (home / ".seif" / "circuit" / "outbox" / f"resp-{name}.json").write_text(
        json.dumps(payload)
    )


def _legacy_reply(home: Path, name: str, *,
                  content: str = "hi from past responder",
                  ts: str = "2026-04-01T10:00:00+00:00") -> None:
    payload = {
        "channel": "bus/handoff",
        "content": f"[claude-responder] {content}",
        "timestamp": ts,
        "responder_tag": "claude-responder",
    }
    (home / ".seif" / "circuit" / "outbox" / f"resp-{name}.json").write_text(
        json.dumps(payload)
    )


class _FakeHomeMixin:
    """Build a fake $HOME with .seif/circuit/outbox/ ready for resp-*.json."""

    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.home = Path(self._tmp.name)
        (self.home / ".seif" / "circuit" / "outbox").mkdir(parents=True)

    def tearDown(self) -> None:
        self._tmp.cleanup()


class EmptyOrMissingTests(unittest.TestCase):
    def test_no_outbox_returns_empty_string(self):
        with tempfile.TemporaryDirectory() as td:
            self.assertEqual(sl._run_daemon_activity_surface(Path(td)), "")

    def test_outbox_with_no_resp_files_returns_empty(self):
        with tempfile.TemporaryDirectory() as td:
            home = Path(td)
            outbox = home / ".seif" / "circuit" / "outbox"
            outbox.mkdir(parents=True)
            (outbox / "ignore-me.txt").write_text("x")
            (outbox / "other.json").write_text("{}")
            self.assertEqual(sl._run_daemon_activity_surface(home), "")


class EnvelopeShapeTests(_FakeHomeMixin, unittest.TestCase):
    def test_envelope_reply_renders_node_echo_and_preview(self):
        _envelope_reply(self.home, "001", node="air-m1",
                        reply="hello air", echo="oi mini")
        text = sl._run_daemon_activity_surface(self.home)
        self.assertIn("[DAEMON ACTIVITY]", text)
        self.assertIn("1 reply(ies)", text)
        self.assertIn("air-m1", text)
        self.assertIn("oi mini", text)
        self.assertIn("hello air", text)
        self.assertIn("feedback_ai_ack_to_gatekeeper", text)

    def test_legacy_reply_renders_with_legacy_marker(self):
        _legacy_reply(self.home, "002", content="legacy reply body")
        text = sl._run_daemon_activity_surface(self.home)
        self.assertIn("(legacy)", text)
        self.assertIn("legacy reply body", text)
        self.assertIn("[DAEMON ACTIVITY]", text)

    def test_mixed_shapes_both_render(self):
        _envelope_reply(self.home, "010", node="mini-m4", reply="new shape")
        _legacy_reply(self.home, "011", content="old shape")
        text = sl._run_daemon_activity_surface(self.home)
        self.assertIn("mini-m4", text)
        self.assertIn("new shape", text)
        self.assertIn("(legacy)", text)
        self.assertIn("old shape", text)


class FailureIsolationTests(_FakeHomeMixin, unittest.TestCase):
    def test_unreadable_json_does_not_crash(self):
        (self.home / ".seif" / "circuit" / "outbox" / "resp-bad.json").write_text(
            "{not json{{{"
        )
        _envelope_reply(self.home, "good", reply="still here")
        text = sl._run_daemon_activity_surface(self.home)
        self.assertIn("still here", text)
        self.assertIn("resp-bad.json (unreadable)", text)


class IdempotencyTests(_FakeHomeMixin, unittest.TestCase):
    def test_watermark_second_call_empty(self):
        _envelope_reply(self.home, "100", reply="first surface")
        text1 = sl._run_daemon_activity_surface(self.home)
        self.assertIn("first surface", text1)
        text2 = sl._run_daemon_activity_surface(self.home)
        self.assertEqual(text2, "")

    def test_new_reply_after_watermark_surfaces(self):
        _envelope_reply(self.home, "200", reply="first")
        sl._run_daemon_activity_surface(self.home)
        _envelope_reply(self.home, "201", reply="second")
        text = sl._run_daemon_activity_surface(self.home)
        self.assertIn("second", text)
        self.assertNotIn("first", text)

    def test_corrupt_watermark_treated_as_no_watermark(self):
        seen = self.home / ".seif" / "session-daemon-activity-seen.json"
        seen.write_text("{not-json{{{")
        _envelope_reply(self.home, "300", reply="please surface")
        text = sl._run_daemon_activity_surface(self.home)
        self.assertIn("please surface", text)


class TruncationTests(_FakeHomeMixin, unittest.TestCase):
    def test_max_items_truncates_with_summary(self):
        for i in range(8):
            _envelope_reply(
                self.home, f"4{i:02d}",
                reply=f"reply-{i}",
                ts=f"2026-05-01T21:0{i}:00+00:00",
            )
        text = sl._run_daemon_activity_surface(self.home, max_items=3)
        self.assertIn("8 reply(ies)", text)
        self.assertIn("reply-7", text)
        self.assertIn("reply-6", text)
        self.assertIn("reply-5", text)
        self.assertIn("and 5 earlier", text)
        self.assertNotIn("reply-0", text)


class SurfaceOnlyContractTests(_FakeHomeMixin, unittest.TestCase):
    def test_outbox_files_are_never_deleted(self):
        _envelope_reply(self.home, "500", reply="must persist")
        outbox = self.home / ".seif" / "circuit" / "outbox"
        before = sorted(p.name for p in outbox.iterdir())
        sl._run_daemon_activity_surface(self.home)
        after = sorted(p.name for p in outbox.iterdir())
        self.assertEqual(before, after,
                         "surface-only: peer-drainer / circuitd own deletion")


class SessionStartIntegrationTests(_FakeHomeMixin, unittest.TestCase):
    def _bootstrap_seif_dir(self) -> Path:
        seif_dir = self.home / ".seif"
        (seif_dir / "config.json").write_text(json.dumps({
            "session_lifecycle": {"enabled": True}
        }))
        (seif_dir / "sessions").mkdir(exist_ok=True)
        (seif_dir / "mapper.json").write_text(json.dumps({"session_count": 0}))
        return seif_dir

    def test_session_start_with_flag_surfaces_block(self):
        self._bootstrap_seif_dir()
        _envelope_reply(self.home, "999", node="mini-m4",
                        reply="surfaced via hook")
        result = sl.session_start_logic(
            session_id="test-session",
            cwd=self.home,
            home=self.home,
            core_dir=None,
            fallback_script_dir=None,
            enable_inbox_drain=False,
            enable_daemon_activity=True,
        )
        self.assertIn("[DAEMON ACTIVITY]", result.output_text)
        self.assertIn("surfaced via hook", result.output_text)

    def test_session_start_without_flag_skips_surface(self):
        self._bootstrap_seif_dir()
        _envelope_reply(self.home, "888", reply="should-not-show")
        result = sl.session_start_logic(
            session_id="test-no-flag",
            cwd=self.home,
            home=self.home,
            core_dir=None,
            fallback_script_dir=None,
            enable_inbox_drain=False,
            enable_daemon_activity=False,
        )
        self.assertNotIn("[DAEMON ACTIVITY]", result.output_text)
        self.assertNotIn("should-not-show", result.output_text)


if __name__ == "__main__":
    unittest.main()
