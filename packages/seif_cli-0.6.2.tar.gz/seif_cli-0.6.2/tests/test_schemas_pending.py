"""Tests for seif.schemas.pending — gap-14 Piece A schema + loader compat."""

import pytest

from seif.schemas.pending import (
    PENDING_V1,
    PENDING_V2,
    PENDING_ACCEPTED_PROTOCOLS,
    is_pending_module,
    migrate_pending_v1_to_v2,
)


def test_accepted_protocols_includes_both_versions():
    assert PENDING_V1 in PENDING_ACCEPTED_PROTOCOLS
    assert PENDING_V2 in PENDING_ACCEPTED_PROTOCOLS
    assert len(PENDING_ACCEPTED_PROTOCOLS) == 2


def test_is_pending_module_v1():
    assert is_pending_module({"protocol": PENDING_V1, "items": []})


def test_is_pending_module_v2():
    assert is_pending_module({"protocol": PENDING_V2, "items": []})


def test_is_pending_module_rejects_unknown_protocol():
    assert not is_pending_module({"protocol": "SEIF-PENDING-v99"})
    assert not is_pending_module({"protocol": "SEIF-CYCLE-v1"})


def test_is_pending_module_rejects_non_dict():
    assert not is_pending_module(None)
    assert not is_pending_module([])
    assert not is_pending_module("string")


def test_migrate_v1_to_v2_defaults_routing_fields_to_cwd():
    v1 = {
        "protocol": PENDING_V1,
        "module_id": "pending-test",
        "items": [],
        "workspace_relative_path": ".seif/modules/pending-test.seif",
    }
    v2 = migrate_pending_v1_to_v2(v1, cwd_workspace="seif-projects")
    assert v2["protocol"] == PENDING_V2
    assert v2["discovered_in_workspace"] == "seif-projects"
    assert v2["target_workspace"] == "seif-projects"
    assert v2["stored_in_workspace"] == "seif-projects"
    assert v2["target_consumer"] == "next_cycle"


def test_migrate_v1_to_v2_preserves_existing_routing_fields():
    v1 = {
        "protocol": PENDING_V1,
        "discovered_in_workspace": "seif-admin",
        "target_workspace": "seif-projects",
        "target_consumer": "owner",
        "stored_in_workspace": "seif-admin",
        "workspace_relative_path": ".seif/modules/x.seif",
    }
    v2 = migrate_pending_v1_to_v2(v1, cwd_workspace="seif-projects")
    assert v2["discovered_in_workspace"] == "seif-admin"
    assert v2["target_workspace"] == "seif-projects"
    assert v2["target_consumer"] == "owner"
    assert v2["stored_in_workspace"] == "seif-admin"


def test_migrate_v1_to_v2_rejects_absolute_path():
    v1 = {
        "protocol": PENDING_V1,
        "workspace_relative_path": "/Volumes/DockerData/seif-projects/x.seif",
    }
    with pytest.raises(ValueError, match="absolute paths"):
        migrate_pending_v1_to_v2(v1, cwd_workspace="seif-projects")


def test_migrate_v2_input_is_passthrough():
    v2_in = {"protocol": PENDING_V2, "module_id": "x"}
    v2_out = migrate_pending_v1_to_v2(v2_in, cwd_workspace="any")
    assert v2_out == v2_in
    assert v2_out is not v2_in  # shallow copy


def test_migrate_rejects_non_pending_protocol():
    with pytest.raises(ValueError, match="expected SEIF-PENDING-v1"):
        migrate_pending_v1_to_v2(
            {"protocol": "SEIF-CYCLE-v1"}, cwd_workspace="x"
        )
