"""Tests for seif.context.model_probe."""

import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from seif.context import model_probe as mp


def _ollama_response_with(*names):
    return {"models": [{"name": n, "size": 2_000_000_000} for n in names]}


class TestModelProbe(unittest.TestCase):

    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix="seif_probe_"))
        self._home_patch = self._monkey_home(self.tmp)

    def tearDown(self):
        import shutil
        self._home_patch()
        shutil.rmtree(self.tmp, ignore_errors=True)

    def _monkey_home(self, home):
        from seif.data import paths
        original_paths = paths.get_user_home
        original_mp = mp.get_user_home
        paths.get_user_home = lambda: home
        mp.get_user_home = lambda: home

        def restore():
            paths.get_user_home = original_paths
            mp.get_user_home = original_mp
        return restore

    # ── Individual probes ───────────────────────────────────────────────────

    def test_ollama_local_parses_models(self):
        with patch.object(mp, "_http_get", return_value=_ollama_response_with("llama3:8b", "mistral:7b")):
            models = mp.probe_ollama_local()
        self.assertEqual(len(models), 2)
        self.assertEqual(models[0]["id"], "ollama/llama3:8b")
        self.assertEqual(models[0]["machine"], "local")
        self.assertEqual(models[0]["status"], "online")
        self.assertAlmostEqual(models[0]["size_gb"], 2.0)

    def test_ollama_local_returns_empty_when_offline(self):
        with patch.object(mp, "_http_get", return_value=None):
            self.assertEqual(mp.probe_ollama_local(), [])

    def test_api_backends_detect_keys(self):
        env = {"XAI_API_KEY": "x", "ANTHROPIC_API_KEY": "a"}
        models = mp.probe_api_backends(env=env)
        ids = {m["id"] for m in models}
        self.assertIn("xai/grok-3", ids)
        self.assertIn("anthropic/claude-sonnet", ids)
        self.assertNotIn("google/gemini", ids)

    def test_api_backends_no_keys(self):
        self.assertEqual(mp.probe_api_backends(env={}), [])

    def test_circuit_offline(self):
        with patch.object(mp, "_http_get", return_value=None):
            c = mp.probe_circuit()
        self.assertFalse(c["connected"])
        self.assertIn("error", c)

    def test_circuit_connected(self):
        with patch.object(mp, "_http_get", return_value={
            "connected": True, "machine": "mini-m4",
            "hub_url": "ws://x", "transport": "websocket",
            "recent_message_count": 3,
        }):
            c = mp.probe_circuit()
        self.assertTrue(c["connected"])
        self.assertEqual(c["machine"], "mini-m4")
        self.assertEqual(c["transport"], "websocket")

    # ── Aggregation ─────────────────────────────────────────────────────────

    def test_probe_all_aggregates(self):
        with patch.object(mp, "probe_ollama_local", return_value=[{
                    "id": "ollama/x", "name": "x", "machine": "local",
                    "caps": [], "cost": "free", "status": "online", "size_gb": 1.0,
                }]), \
             patch.object(mp, "probe_cli_tools", return_value=[]), \
             patch.object(mp, "probe_api_backends", return_value=[]), \
             patch.object(mp, "probe_circuit", return_value={"connected": False, "error": "no"}), \
             patch.object(mp, "load_health", return_value={}):
            result = mp.probe_all(load_env=False)
        self.assertEqual(len(result.models), 1)
        self.assertFalse(result.circuit["connected"])
        self.assertGreaterEqual(result.duration_ms, 0)

    def test_write_and_read_registry(self):
        result = mp.ProbeResult(
            models=[{"id": "ollama/m", "name": "m", "machine": "local",
                     "caps": [], "cost": "free", "status": "online"}],
            circuit={"connected": False, "error": "x"},
            health={},
            duration_ms=42,
        )
        path = mp.write_registry(result)
        self.assertTrue(path.exists())
        data = json.loads(path.read_text())
        self.assertEqual(data["protocol"], mp.PROTOCOL)
        self.assertEqual(data["probe_ms"], 42)
        self.assertEqual(len(data["models"]), 1)

    def test_format_orchestra_offline_circuit(self):
        result = mp.ProbeResult(
            models=[],
            circuit={"connected": False, "error": "no"},
            health={},
            duration_ms=10,
        )
        text = mp.format_orchestra(result)
        self.assertIn("[MODEL ORCHESTRA]", text)
        self.assertIn("Circuit: OFFLINE", text)
        self.assertIn("none (single-pole mode)", text)

    def test_format_orchestra_with_models(self):
        result = mp.ProbeResult(
            models=[{"id": "cli/claude-code", "name": "Claude Code", "machine": "air-m1",
                     "caps": ["fs", "code"], "cost": "token", "status": "active"},
                    {"id": "ollama/m", "name": "m", "machine": "local",
                     "caps": ["reasoning"], "cost": "free", "status": "online", "size_gb": 1.5}],
            circuit={"connected": True, "machine": "mini-m4", "transport": "websocket"},
            health={},
            duration_ms=10,
        )
        text = mp.format_orchestra(result)
        self.assertIn("Air M1", text)
        self.assertIn("Local", text)
        self.assertIn("CONNECTED", text)
        self.assertIn("1.5GB", text)


if __name__ == "__main__":
    unittest.main()
