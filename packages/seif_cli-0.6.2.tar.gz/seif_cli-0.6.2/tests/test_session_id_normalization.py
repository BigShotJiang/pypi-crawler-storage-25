"""Tests for s56 PR2 Layer B — session_id normalization at lifecycle entry.

Defense-in-depth: even if a caller (wrapper, CLI, library client) passes a
non-UUID session_id, session_start_logic mints a fresh UUID before any
downstream call. Pairs with the bash hook fallback in session-start.sh
(Layer A) so the registry guard from PR1 is never hit by accident.
"""

from __future__ import annotations

import json
import os
import subprocess
import uuid
from pathlib import Path

import pytest

from seif.plugins.core.session_lifecycle import _normalize_session_id


def test_normalize_passes_canonical_uuid_through():
    sid = str(uuid.uuid4())
    assert _normalize_session_id(sid) == sid


def test_normalize_replaces_literal_unknown():
    out = _normalize_session_id("unknown")
    assert out != "unknown"
    uuid.UUID(out)  # raises if not a valid UUID


def test_normalize_replaces_empty_string():
    out = _normalize_session_id("")
    uuid.UUID(out)


def test_normalize_replaces_whitespace_only():
    out = _normalize_session_id("   ")
    uuid.UUID(out)


def test_normalize_replaces_none():
    out = _normalize_session_id(None)  # type: ignore[arg-type]
    uuid.UUID(out)


def test_normalize_replaces_non_string():
    out = _normalize_session_id(12345)  # type: ignore[arg-type]
    uuid.UUID(out)


def test_normalize_replaces_malformed_uuid():
    out = _normalize_session_id("not-a-uuid")
    assert out != "not-a-uuid"
    uuid.UUID(out)


def test_normalize_strips_whitespace_around_valid_uuid():
    sid = str(uuid.uuid4())
    assert _normalize_session_id(f"  {sid}  ") == sid


def _make_workspace(tmp_path: Path) -> Path:
    seif_dir = tmp_path / ".seif"
    seif_dir.mkdir()
    (seif_dir / "config.json").write_text(json.dumps({
        "session_lifecycle": {"enabled": True, "co_author": ""},
    }))
    (seif_dir / "sessions").mkdir()
    (seif_dir / "modules").mkdir()
    (seif_dir / "mapper.json").write_text(json.dumps({"modules": [], "version": 1}))
    return seif_dir


def _git_init(path: Path):
    path.mkdir(parents=True, exist_ok=True)
    subprocess.run(["git", "init", "-q", "-b", "main", str(path)], check=True)
    subprocess.run(
        ["git", "-C", str(path),
         "-c", "user.email=t@t", "-c", "user.name=t",
         "commit", "-q", "--allow-empty", "-m", "init"],
        check=True,
        env={**os.environ, "HOME": str(path.parent)},
    )


def test_session_start_logic_replaces_unknown_with_uuid(tmp_path):
    """End-to-end: session_start_logic called with 'unknown' must produce a
    UUID-named registry entry and never an unknown.json."""
    seif_dir = _make_workspace(tmp_path)
    _git_init(tmp_path / "alpha")

    from seif.plugins.core.session_lifecycle import session_start_logic

    result = session_start_logic(
        session_id="unknown",
        cwd=tmp_path,
        home=tmp_path,
        enable_awareness=True,
    )

    # The result carries the normalized id
    assert result.session_id != "unknown"
    uuid.UUID(result.session_id)

    # No unknown.json — that was the s55 regression
    active = seif_dir / "sessions" / "active"
    assert not (active / "unknown.json").exists()

    # The UUID-named entry exists
    assert (active / f"{result.session_id}.json").is_file()


def test_session_start_logic_preserves_valid_uuid(tmp_path):
    seif_dir = _make_workspace(tmp_path)
    _git_init(tmp_path / "alpha")

    from seif.plugins.core.session_lifecycle import session_start_logic

    sid = str(uuid.uuid4())
    result = session_start_logic(
        session_id=sid,
        cwd=tmp_path,
        home=tmp_path,
        enable_awareness=True,
    )
    assert result.session_id == sid
    assert (seif_dir / "sessions" / "active" / f"{sid}.json").is_file()


def test_session_start_logic_replaces_empty_with_uuid(tmp_path):
    seif_dir = _make_workspace(tmp_path)
    _git_init(tmp_path / "alpha")

    from seif.plugins.core.session_lifecycle import session_start_logic

    result = session_start_logic(
        session_id="",
        cwd=tmp_path,
        home=tmp_path,
        enable_awareness=True,
    )
    uuid.UUID(result.session_id)
    assert (seif_dir / "sessions" / "active" / f"{result.session_id}.json").is_file()
