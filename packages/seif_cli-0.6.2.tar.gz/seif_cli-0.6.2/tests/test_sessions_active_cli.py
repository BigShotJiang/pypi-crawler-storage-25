"""Tests for s60 PR3 — `seif --sessions-active` CLI subcommand.

Behavior under test (per s60 SEED amendment, rank 4 item 1):

  - Read schema-valid session entries from `.seif/sessions/active/*.json`.
  - Skip `unknown.json` (handoff straggler — non-UUID session_id).
  - Skip `handoff-*.json` (not session entries; share the directory
    historically with handoff artifacts).
  - Skip files that fail SessionEntry schema validation (malformed
    JSON, missing required field, wrong type).
  - Default output: pretty-printed table with columns including
    `session_id` and `wrapper`.
  - `--json`: list of valid SessionEntry asdict() dicts.
  - Read-only — must not mutate any file in active/.
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import unittest
from dataclasses import asdict
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
SRC = REPO_ROOT / "src"

sys.path.insert(0, str(SRC))

from seif.plugins.core.session_registry import (  # noqa: E402
    SessionEntry,
    new_session_id,
)


def _valid_entry_dict(**overrides) -> dict:
    """Return a dict that can construct SessionEntry(**dict) cleanly."""
    base = SessionEntry(
        session_id=new_session_id(),
        wrapper="claude-code",
        host="testhost",
        pid=12345,
        cwd="/tmp/some/workspace",
        started_at="2026-05-05T10:00:00Z",
        last_heartbeat="2026-05-05T10:00:00Z",
        repos_observed={"seif": "abc1234"},
        cycle_id=None,
    )
    d = asdict(base)
    d.update(overrides)
    return d


def _run_cli(args, cwd, env_extra=None):
    env = os.environ.copy()
    env["PYTHONPATH"] = f"{SRC}:{env.get('PYTHONPATH', '')}"
    if env_extra:
        env.update(env_extra)
    return subprocess.run(
        [sys.executable, "-m", "seif.cli.cli", *args],
        cwd=str(cwd),
        env=env,
        capture_output=True,
        text=True,
        timeout=30,
    )


class SessionsActiveCliTests(unittest.TestCase):
    """Subprocess-driven tests so the full argparse + dispatch path runs."""

    def setUp(self):
        import tempfile
        self._tmpdir = tempfile.TemporaryDirectory()
        self.workspace = Path(self._tmpdir.name)
        self.active = self.workspace / ".seif" / "sessions" / "active"
        self.active.mkdir(parents=True)

    def tearDown(self):
        self._tmpdir.cleanup()

    # -- skip filters --------------------------------------------------

    def test_sessions_active_skips_unknown_json(self):
        """unknown.json is a handoff straggler with a non-UUID session_id —
        it must NOT appear in --sessions-active output even though SessionEntry
        construction succeeds for it (the dataclass accepts any string)."""
        # Plant unknown.json with a (technically) constructable shape.
        bad = _valid_entry_dict(session_id="unknown")
        (self.active / "unknown.json").write_text(json.dumps(bad))
        # Plant one valid entry.
        good = _valid_entry_dict()
        (self.active / f"{good['session_id']}.json").write_text(json.dumps(good))

        result = _run_cli(["--sessions-active", "--json"], cwd=self.workspace)
        self.assertEqual(result.returncode, 0,
                         f"stdout={result.stdout!r} stderr={result.stderr!r}")
        out = json.loads(result.stdout)
        self.assertEqual(len(out), 1, f"expected 1 entry; got {out!r}")
        self.assertEqual(out[0]["session_id"], good["session_id"])

    def test_sessions_active_skips_handoff_files(self):
        """handoff-*.json are not session entries; they must be skipped
        regardless of internal shape."""
        # A handoff file that happens to parse as a SessionEntry shape — still skipped.
        handoff = _valid_entry_dict()
        (self.active / "handoff-foo.json").write_text(json.dumps(handoff))
        # A valid session entry.
        good = _valid_entry_dict()
        (self.active / f"{good['session_id']}.json").write_text(json.dumps(good))

        result = _run_cli(["--sessions-active", "--json"], cwd=self.workspace)
        self.assertEqual(result.returncode, 0,
                         f"stdout={result.stdout!r} stderr={result.stderr!r}")
        out = json.loads(result.stdout)
        self.assertEqual(len(out), 1)
        self.assertEqual(out[0]["session_id"], good["session_id"])

    def test_sessions_active_filters_schema_invalid(self):
        """Malformed JSON and dicts that don't satisfy SessionEntry's
        required fields are silently skipped (counted on stderr)."""
        # Malformed JSON.
        (self.active / "broken.json").write_text("{not valid json")
        # Missing required field (no `pid`).
        partial = _valid_entry_dict()
        del partial["pid"]
        (self.active / f"{partial['session_id']}.json").write_text(json.dumps(partial))
        # Wrong type for a list (top-level is a list, not a dict).
        (self.active / "wrong-type.json").write_text("[1, 2, 3]")
        # One valid entry.
        good = _valid_entry_dict()
        (self.active / f"{good['session_id']}.json").write_text(json.dumps(good))

        result = _run_cli(["--sessions-active", "--json"], cwd=self.workspace)
        self.assertEqual(result.returncode, 0,
                         f"stdout={result.stdout!r} stderr={result.stderr!r}")
        out = json.loads(result.stdout)
        self.assertEqual(len(out), 1, f"expected 1 entry; got {out!r}")
        self.assertEqual(out[0]["session_id"], good["session_id"])
        # Skipped count surfaced on stderr.
        self.assertIn("skipped", result.stderr)

    # -- output shape --------------------------------------------------

    def test_sessions_active_table_output_columns(self):
        """Default (no --json) output is a table with header line that
        includes the load-bearing column names `session_id` and `wrapper`."""
        good = _valid_entry_dict()
        (self.active / f"{good['session_id']}.json").write_text(json.dumps(good))

        result = _run_cli(["--sessions-active"], cwd=self.workspace)
        self.assertEqual(result.returncode, 0,
                         f"stdout={result.stdout!r} stderr={result.stderr!r}")
        self.assertIn("session_id", result.stdout)
        self.assertIn("wrapper", result.stdout)
        # First 8 chars of session_id must show up.
        self.assertIn(good["session_id"][:8], result.stdout)

    def test_sessions_active_json_output_shape(self):
        """--json output must parse to a list of dicts each with session_id."""
        e1 = _valid_entry_dict()
        e2 = _valid_entry_dict(wrapper="copilot")
        (self.active / f"{e1['session_id']}.json").write_text(json.dumps(e1))
        (self.active / f"{e2['session_id']}.json").write_text(json.dumps(e2))

        result = _run_cli(["--sessions-active", "--json"], cwd=self.workspace)
        self.assertEqual(result.returncode, 0,
                         f"stdout={result.stdout!r} stderr={result.stderr!r}")
        parsed = json.loads(result.stdout)
        self.assertIsInstance(parsed, list)
        self.assertEqual(len(parsed), 2)
        for entry in parsed:
            self.assertIsInstance(entry, dict)
            self.assertIn("session_id", entry)
            self.assertIn("wrapper", entry)

    # -- read-only contract --------------------------------------------

    def test_sessions_active_does_not_mutate_files(self):
        """--sessions-active must never delete or rewrite files in active/.
        Even malformed/skipped files must remain untouched (gc_stale owns
        cleanup, not this read-only command)."""
        # Plant one of each kind — all must survive the call.
        good = _valid_entry_dict()
        (self.active / f"{good['session_id']}.json").write_text(json.dumps(good))
        (self.active / "unknown.json").write_text("{}")
        (self.active / "handoff-foo.json").write_text("{}")
        (self.active / "broken.json").write_text("{not valid")

        before = {
            p.name: p.read_bytes()
            for p in self.active.iterdir()
        }

        result = _run_cli(["--sessions-active"], cwd=self.workspace)
        self.assertEqual(result.returncode, 0,
                         f"stdout={result.stdout!r} stderr={result.stderr!r}")

        after = {
            p.name: p.read_bytes()
            for p in self.active.iterdir()
        }
        self.assertEqual(before, after,
                         "--sessions-active must be read-only; files changed")


if __name__ == "__main__":
    unittest.main()
