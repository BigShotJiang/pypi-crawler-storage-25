"""In-package absorb_knowledge module — Gap 60 close (s68).

Pre-s68 the absorb logic lived in a standalone script at the seif-admin
workspace root, unreachable for pipx-installed users. These tests pin the
in-package implementation and its behavior on empty / partial / full inputs.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from seif.context.absorb_knowledge import (
    PHI,
    ZETA_OPTIMAL,
    absorb,
    main,
)


def _write_json(path: Path, obj: dict) -> None:
    path.write_text(json.dumps(obj), encoding="utf-8")


@pytest.fixture
def ctx_dir(tmp_path: Path) -> Path:
    d = tmp_path / "seif-context"
    d.mkdir()
    return d


def test_constants_exposed():
    # Cross-check against the legacy standalone script values.
    assert PHI == 1.618033988749895
    assert ZETA_OPTIMAL == 0.6123724356957945


def test_missing_context_dir_raises(tmp_path: Path):
    with pytest.raises(FileNotFoundError):
        absorb(tmp_path / "does-not-exist")


def test_empty_context_returns_empty_status(ctx_dir: Path):
    receipt = absorb(ctx_dir)
    assert receipt["protocol"] == "SEIF-RECEIPT-v1"
    assert receipt["absorption_status"] == "EMPTY"
    assert receipt["total_files_processed"] == 0
    assert receipt["total_knowledge_items"] == 0
    assert (ctx_dir / "memory_state.json").exists()
    assert any(p.name.startswith("absorption-receipt-") for p in ctx_dir.iterdir())


def test_absorption_file_with_summary_and_contributors(ctx_dir: Path):
    _write_json(ctx_dir / "absorption-v1.seif", {
        "protocol": "SEIF-ABSORPTION-v1",
        "session": "s67-test",
        "summary": "test summary",
        "contributors": [
            {"author": "alice", "action": "init", "at": "2026-05-06T00:00:00Z"},
            {"author": "bob", "action": "review", "at": "2026-05-06T01:00:00Z"},
        ],
    })

    receipt = absorb(ctx_dir)
    assert receipt["absorption_status"] == "FULL"
    assert receipt["total_files_processed"] == 1
    # 1 summary + 2 contributors
    assert receipt["total_knowledge_items"] == 3
    assert receipt["errors"] == []

    memory = json.loads((ctx_dir / "memory_state.json").read_text())
    assert "SEIF-ABSORPTION-v1-s67-test" in memory
    entry = memory["SEIF-ABSORPTION-v1-s67-test"]
    assert entry["knowledge_count"] == 3
    assert entry["source_file"] == "absorption-v1.seif"


def test_atomic_payload_state_and_transmissions(ctx_dir: Path):
    payload_dir = ctx_dir / "atomic_payload"
    payload_dir.mkdir()
    _write_json(payload_dir / "state.json", {
        "id": "state-1",
        "recipient": "claude",
        "status": "delivered",
        "chunks": [1, 2, 3],
    })
    (payload_dir / "transmissions.jsonl").write_text(
        '{"id":"tx-1","recipient":"claude","status":"ack","original_tokens":42}\n'
        '{"id":"tx-2","recipient":"grok","status":"pending","original_tokens":17}\n',
        encoding="utf-8",
    )

    receipt = absorb(ctx_dir)
    assert receipt["absorption_status"] == "FULL"
    # state + transmissions = 2 payload "files" processed
    assert receipt["total_files_processed"] == 2
    # 1 state item + 2 transmission items
    assert receipt["total_knowledge_items"] == 3

    memory = json.loads((ctx_dir / "memory_state.json").read_text())
    assert "state-state.json" in memory
    assert "transmissions-transmissions.jsonl" in memory


def test_malformed_absorption_file_recorded_as_error(ctx_dir: Path):
    (ctx_dir / "absorption-v1.seif").write_text("not-json{", encoding="utf-8")
    receipt = absorb(ctx_dir)
    # No files successfully absorbed → EMPTY
    assert receipt["absorption_status"] == "EMPTY"
    assert len(receipt["errors"]) == 1
    assert "absorption-v1.seif" in receipt["errors"][0]


def test_absorb_is_idempotent_on_repeat_with_new_receipt(ctx_dir: Path):
    _write_json(ctx_dir / "absorption-v1.seif", {
        "protocol": "X",
        "session": "y",
        "summary": "s",
    })
    r1 = absorb(ctx_dir)
    r2 = absorb(ctx_dir)
    # Same content → same resonance hash + same total knowledge items
    assert r1["resonance_hash"] == r2["resonance_hash"]
    assert r1["total_knowledge_items"] == r2["total_knowledge_items"]
    # Each call writes a separate receipt file
    receipts = sorted(p for p in ctx_dir.iterdir() if p.name.startswith("absorption-receipt-"))
    assert len(receipts) >= 1  # timestamp granularity may collide; >=1 always


def test_main_returns_2_on_empty(tmp_path: Path, capsys):
    d = tmp_path / "seif-context"
    d.mkdir()
    rc = main([str(d)])
    assert rc == 2
    out = capsys.readouterr().out
    payload = json.loads(out)
    assert payload["status"] == "EMPTY"
    assert payload["files"] == 0


def test_main_returns_1_on_missing_dir(tmp_path: Path, capsys):
    rc = main([str(tmp_path / "nope")])
    assert rc == 1
    err = capsys.readouterr().err
    assert "context_dir not found" in err


def test_main_returns_0_on_full(tmp_path: Path, capsys):
    d = tmp_path / "seif-context"
    d.mkdir()
    _write_json(d / "absorption-v1.seif", {
        "protocol": "P",
        "session": "S",
        "summary": "anything",
    })
    rc = main([str(d)])
    assert rc == 0
    out = capsys.readouterr().out
    payload = json.loads(out)
    assert payload["status"] == "FULL"
    assert payload["files"] == 1
