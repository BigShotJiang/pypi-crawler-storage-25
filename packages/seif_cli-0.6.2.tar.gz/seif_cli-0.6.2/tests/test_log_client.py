"""seif-log client — submit + verify with a stub HTTP server.

Spawns a tiny stdlib HTTPServer in a thread, captures the request, lets the
test assert on the SEIF-Ed25519 header structure and signature validity.
"""

from __future__ import annotations

import base64
import hashlib
import json
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

import pytest

cryptography = pytest.importorskip("cryptography")

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from seif.log.canonical import canonical_json_bytes
from seif.log.identity import ensure_identity
from seif.log.client import (
    DEFAULT_LOG_URL,
    LogHTTPError,
    list_entries,
    submit_entry,
    submit_file,
    verify_entry,
)


class _CaptureHandler(BaseHTTPRequestHandler):
    captured: list = []
    response_status: int = 201
    response_body: dict = {}

    def log_message(self, format, *args):  # silence
        pass

    def _read_body(self) -> bytes:
        length = int(self.headers.get("Content-Length", "0"))
        return self.rfile.read(length) if length else b""

    def do_POST(self):
        body = self._read_body()
        self.captured.append({
            "method": "POST",
            "path": self.path,
            "headers": dict(self.headers),
            "body": body,
        })
        self.send_response(self.response_status)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps(self.response_body).encode())

    def do_GET(self):
        self.captured.append({
            "method": "GET",
            "path": self.path,
            "headers": dict(self.headers),
            "body": b"",
        })
        self.send_response(self.response_status)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(json.dumps(self.response_body).encode())


@pytest.fixture
def stub_server():
    _CaptureHandler.captured = []
    _CaptureHandler.response_status = 201
    _CaptureHandler.response_body = {}
    httpd = HTTPServer(("127.0.0.1", 0), _CaptureHandler)
    port = httpd.server_address[1]
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    try:
        yield (f"http://127.0.0.1:{port}", _CaptureHandler)
    finally:
        httpd.shutdown()
        httpd.server_close()
        thread.join(timeout=2)


@pytest.fixture
def isolated_home(tmp_path: Path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    return tmp_path


def _decode_b64u(s: str) -> bytes:
    pad = "=" * (-len(s) % 4)
    return base64.urlsafe_b64decode(s + pad)


def _parse_seif_ed25519(header: str) -> dict[str, str]:
    assert header.startswith("SEIF-Ed25519 ")
    raw = header.removeprefix("SEIF-Ed25519 ").strip()
    return dict(chunk.split("=", 1) for chunk in raw.split())


def test_submit_entry_signs_canonical_envelope(stub_server, isolated_home):
    base_url, handler = stub_server
    handler.response_status = 201
    handler.response_body = {
        "id": "00000000-0000-0000-0000-000000000001",
        "tenant_id": "00000000-0000-0000-0000-000000000010",
        "sequence": 1,
        "canonical_sha256": "00" * 32,
        "entry_type": "test.x",
        "api_version": "1",
        "workspace_fingerprint": None,
        "classification_ceil": "INTERNAL",
        "primary_content_sha256": None,
        "body_storage": "inline",
        "body_ref": None,
        "submitted_at": "2026-05-06T19:00:00+00:00",
        "client_nonce": "00000000-0000-0000-0000-000000000020",
        "ingest_source": "workspace_ed25519",
    }
    ident = ensure_identity("test-default")
    resp = submit_entry(
        ident,
        entry_type="test.x",
        classification_ceil="INTERNAL",
        log_url=base_url,
    )
    assert resp["id"] == "00000000-0000-0000-0000-000000000001"

    [captured] = handler.captured
    assert captured["method"] == "POST"
    assert captured["path"] == "/v1/entries"

    auth = captured["headers"]["Authorization"]
    params = _parse_seif_ed25519(auth)
    assert set(params) == {"sig", "pubkey", "nonce", "ts"}

    pubkey_bytes = _decode_b64u(params["pubkey"])
    sig_bytes = _decode_b64u(params["sig"])
    body_sha256_hex = hashlib.sha256(captured["body"]).hexdigest()

    expected_message = canonical_json_bytes({
        "method": "POST",
        "path": "/v1/entries",
        "nonce": params["nonce"],
        "ts": params["ts"],
        "body_sha256": body_sha256_hex,
    })
    pub = Ed25519PublicKey.from_public_bytes(pubkey_bytes)
    pub.verify(sig_bytes, expected_message)


def test_submit_file_hashes_file_bytes(stub_server, isolated_home, tmp_path):
    base_url, handler = stub_server
    handler.response_status = 201
    handler.response_body = {
        "id": "00000000-0000-0000-0000-000000000099",
        "tenant_id": "00000000-0000-0000-0000-000000000010",
        "sequence": 1,
        "canonical_sha256": "00" * 32,
        "entry_type": "artifact.file",
        "api_version": "1",
        "workspace_fingerprint": None,
        "classification_ceil": "INTERNAL",
        "primary_content_sha256": hashlib.sha256(b"hello").hexdigest(),
        "body_storage": "inline",
        "body_ref": None,
        "submitted_at": "2026-05-06T19:00:00+00:00",
        "client_nonce": "00000000-0000-0000-0000-000000000020",
        "ingest_source": "workspace_ed25519",
    }
    f = tmp_path / "artifact.txt"
    f.write_bytes(b"hello")
    ident = ensure_identity("test-default")
    resp = submit_file(ident, str(f), log_url=base_url)

    [captured] = handler.captured
    body = json.loads(captured["body"])
    assert body["primary_content_sha256"] == hashlib.sha256(b"hello").hexdigest()
    assert resp["id"] == "00000000-0000-0000-0000-000000000099"


def test_verify_entry_signs_get_with_empty_body(stub_server, isolated_home):
    base_url, handler = stub_server
    handler.response_status = 200
    handler.response_body = {
        "id": "00000000-0000-0000-0000-000000000099",
        "tenant_id": "00000000-0000-0000-0000-000000000010",
        "sequence": 1,
        "canonical_sha256": "00" * 32,
        "entry_type": "artifact.file",
        "api_version": "1",
        "workspace_fingerprint": None,
        "classification_ceil": "INTERNAL",
        "primary_content_sha256": None,
        "body_storage": "inline",
        "body_ref": None,
        "submitted_at": "2026-05-06T19:00:00+00:00",
        "client_nonce": "00000000-0000-0000-0000-000000000020",
        "ingest_source": "workspace_ed25519",
    }
    ident = ensure_identity("test-default")
    resp = verify_entry(
        ident,
        "00000000-0000-0000-0000-000000000099",
        log_url=base_url,
    )

    [captured] = handler.captured
    assert captured["method"] == "GET"
    assert captured["path"] == "/v1/entries/00000000-0000-0000-0000-000000000099"
    assert captured["body"] == b""

    auth = captured["headers"]["Authorization"]
    params = _parse_seif_ed25519(auth)
    pubkey_bytes = _decode_b64u(params["pubkey"])
    sig_bytes = _decode_b64u(params["sig"])
    expected_message = canonical_json_bytes({
        "method": "GET",
        "path": "/v1/entries/00000000-0000-0000-0000-000000000099",
        "nonce": params["nonce"],
        "ts": params["ts"],
        "body_sha256": hashlib.sha256(b"").hexdigest(),
    })
    Ed25519PublicKey.from_public_bytes(pubkey_bytes).verify(sig_bytes, expected_message)
    assert resp["id"] == "00000000-0000-0000-0000-000000000099"


def test_submit_raises_on_4xx(stub_server, isolated_home):
    base_url, handler = stub_server
    handler.response_status = 401
    handler.response_body = {"detail": "ed25519_signature_invalid"}
    ident = ensure_identity("test-default")
    with pytest.raises(LogHTTPError) as exc_info:
        submit_entry(
            ident,
            entry_type="x",
            classification_ceil="INTERNAL",
            log_url=base_url,
        )
    assert exc_info.value.status == 401
    assert exc_info.value.detail == "ed25519_signature_invalid"


def test_default_log_url_constant():
    assert DEFAULT_LOG_URL == "http://localhost:8000"


def test_request_sets_seif_cli_user_agent(stub_server, isolated_home):
    # Live discovery against the CF-fronted pilot at log.seifprotocol.com:
    # urllib's default "Python-urllib/3.x" UA is rejected by Cloudflare
    # WAF / Bot Fight Mode with 403, breaking submit_entry / verify_entry
    # against any CF-tunneled deploy. Client must announce itself so WAF
    # rules pass and request logs identify the caller.
    base_url, handler = stub_server
    handler.response_status = 201
    handler.response_body = {
        "id": "00000000-0000-0000-0000-000000000001",
        "tenant_id": "00000000-0000-0000-0000-000000000010",
        "sequence": 1,
        "canonical_sha256": "00" * 32,
        "entry_type": "ua.test",
        "api_version": "1",
        "workspace_fingerprint": None,
        "classification_ceil": "INTERNAL",
        "primary_content_sha256": None,
        "body_storage": "inline",
        "body_ref": None,
        "submitted_at": "2026-05-06T19:00:00+00:00",
        "client_nonce": "00000000-0000-0000-0000-000000000020",
        "ingest_source": "workspace_ed25519",
    }
    ident = ensure_identity("test-default")
    submit_entry(
        ident,
        entry_type="ua.test",
        classification_ceil="INTERNAL",
        log_url=base_url,
    )
    [captured] = handler.captured
    ua = captured["headers"].get("User-Agent", "")
    assert ua.startswith("seif-cli/"), (
        f"expected seif-cli/<version> User-Agent (CF WAF compat), got: {ua!r}"
    )


# ── D4: list_entries (cursor-paginated GET /v1/entries) ──


_LIST_RESPONSE_BODY = {
    "entries": [
        {
            "id": "00000000-0000-0000-0000-000000000001",
            "tenant_id": "00000000-0000-0000-0000-000000000010",
            "sequence": 1,
            "canonical_sha256": "11" * 32,
            "entry_type": "test.x",
            "api_version": "1",
            "workspace_fingerprint": "fp-A",
            "classification_ceil": "INTERNAL",
            "primary_content_sha256": None,
            "body_storage": "inline",
            "body_ref": None,
            "submitted_at": "2026-05-06T19:00:00+00:00",
            "client_nonce": "00000000-0000-0000-0000-000000000020",
            "ingest_source": "workspace_ed25519",
        }
    ],
    "next_cursor": "00000000-0000-0000-0000-000000000001",
    "has_more": True,
}


def test_list_entries_default_args_omit_query_params(stub_server, isolated_home):
    """Default invocation (no after_id, limit=20, no fp filter) → bare /v1/entries
    path. Don't waste signed-path bytes on noise that can be derived server-side.
    """
    base_url, handler = stub_server
    handler.response_status = 200
    handler.response_body = _LIST_RESPONSE_BODY
    ident = ensure_identity("test-default")

    resp = list_entries(ident, log_url=base_url)

    [captured] = handler.captured
    assert captured["method"] == "GET"
    assert captured["path"] == "/v1/entries", (
        f"default args should send bare path; got: {captured['path']}"
    )
    assert captured["body"] == b""
    assert resp["entries"][0]["id"] == "00000000-0000-0000-0000-000000000001"
    assert resp["next_cursor"] == "00000000-0000-0000-0000-000000000001"
    assert resp["has_more"] is True


def test_list_entries_with_after_id_and_custom_limit_in_query(stub_server, isolated_home):
    """after_id + limit != 20 are sent as query params; signature still covers
    only the bare path (server-side request.url.path strips query string)."""
    base_url, handler = stub_server
    handler.response_status = 200
    handler.response_body = _LIST_RESPONSE_BODY
    ident = ensure_identity("test-default")

    cursor = "11111111-2222-3333-4444-555555555555"
    list_entries(ident, after_id=cursor, limit=5, log_url=base_url)

    [captured] = handler.captured
    assert captured["method"] == "GET"
    assert "after_id=" in captured["path"]
    assert cursor in captured["path"]
    assert "limit=5" in captured["path"]
    # Path before "?" must equal the signed path
    assert captured["path"].split("?")[0] == "/v1/entries"

    # Signature MUST cover bare /v1/entries (not /v1/entries?after_id=...)
    auth = captured["headers"]["Authorization"]
    params = _parse_seif_ed25519(auth)
    pubkey_bytes = _decode_b64u(params["pubkey"])
    sig_bytes = _decode_b64u(params["sig"])
    expected_message = canonical_json_bytes({
        "method": "GET",
        "path": "/v1/entries",  # NOT the query-laden version
        "nonce": params["nonce"],
        "ts": params["ts"],
        "body_sha256": hashlib.sha256(b"").hexdigest(),
    })
    Ed25519PublicKey.from_public_bytes(pubkey_bytes).verify(sig_bytes, expected_message)


def test_list_entries_with_workspace_fingerprint_filter(stub_server, isolated_home):
    base_url, handler = stub_server
    handler.response_status = 200
    handler.response_body = _LIST_RESPONSE_BODY
    ident = ensure_identity("test-default")

    list_entries(ident, workspace_fingerprint="fp-A", log_url=base_url)

    [captured] = handler.captured
    assert "workspace_fingerprint=fp-A" in captured["path"]


def test_list_entries_default_limit_does_not_pollute_query(stub_server, isolated_home):
    """limit=20 is the server default; client must not echo it in the URL
    (avoids cosmetic 'changes' on every page-1 fetch)."""
    base_url, handler = stub_server
    handler.response_status = 200
    handler.response_body = _LIST_RESPONSE_BODY
    ident = ensure_identity("test-default")

    list_entries(ident, limit=20, log_url=base_url)

    [captured] = handler.captured
    assert "limit=" not in captured["path"]


def test_list_entries_raises_on_4xx(stub_server, isolated_home):
    base_url, handler = stub_server
    handler.response_status = 422
    handler.response_body = {"detail": "after_id_not_found_for_tenant"}
    ident = ensure_identity("test-default")

    with pytest.raises(LogHTTPError) as exc_info:
        list_entries(ident, after_id="00000000-0000-0000-0000-000000000099", log_url=base_url)
    assert exc_info.value.status == 422
    assert exc_info.value.detail == "after_id_not_found_for_tenant"
