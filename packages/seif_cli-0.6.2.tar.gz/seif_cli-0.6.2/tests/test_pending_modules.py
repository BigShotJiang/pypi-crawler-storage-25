"""Tests for SEIF-PENDING-v1 registry support (gap-14 / branch-7 of s32).

Covers the cross-workspace pending discovery protocol:
  - register_pending_module / unregister_pending_module
  - find_pending_modules (filter)
  - resolve_pending_path (workspace-relative → absolute)
  - read_pending_status (open/consumed/missing)
  - list_open_pendings (relevance + status filter)
  - mark_pending_consumed (writes status + consumed_at into source module)
"""

import json
import os
import sys
from pathlib import Path

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

pytest.importorskip("seif.context.registry", reason="seif not installed")

from seif.context import registry as reg


def _make_workspace(root: Path, name: str) -> Path:
    """Create a fake workspace with .seif/modules/ and return its .seif/ path."""
    seif_dir = root / name / ".seif"
    (seif_dir / "modules").mkdir(parents=True, exist_ok=True)
    (seif_dir / "config.json").write_text("{}")
    return seif_dir


def _write_pending(path: Path, **fields) -> None:
    """Write a SEIF-PENDING-v1 module file."""
    data = {
        "protocol": "SEIF-PENDING-v1",
        "module_id": fields.get("module_id", "test-pending"),
        "category": "pending",
    }
    data.update(fields)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2))


@pytest.fixture
def workspace_pair(tmp_path):
    """Two registered workspaces (admin + ops) with .seif/ paths."""
    admin_seif = _make_workspace(tmp_path, "admin")
    ops_seif = _make_workspace(tmp_path, "ops")

    registry = reg._empty_registry()
    registry["contexts"] = [
        {"name": "admin", "path": str(admin_seif)},
        {"name": "ops", "path": str(ops_seif)},
    ]
    return registry, admin_seif, ops_seif


def test_register_and_find_pending(workspace_pair):
    registry, admin_seif, _ = workspace_pair
    pending_path = admin_seif / "modules" / "p1.seif"
    _write_pending(pending_path, module_id="p1")

    reg.register_pending_module(
        registry,
        module_id="p1",
        stored_in_workspace="admin",
        workspace_relative_path=".seif/modules/p1.seif",
        target_workspace="ops",
        target_consumer="next_cycle",
    )

    matches = reg.find_pending_modules(registry, target_workspace="ops")
    assert len(matches) == 1
    assert matches[0]["module_id"] == "p1"


def test_register_idempotent(workspace_pair):
    registry, admin_seif, _ = workspace_pair
    _write_pending(admin_seif / "modules" / "p1.seif", module_id="p1")

    for _ in range(3):
        reg.register_pending_module(
            registry,
            module_id="p1",
            stored_in_workspace="admin",
            workspace_relative_path=".seif/modules/p1.seif",
            target_workspace="ops",
            target_consumer="next_cycle",
        )

    assert len(registry["pending_modules"]) == 1


def test_resolve_pending_path(workspace_pair):
    registry, admin_seif, _ = workspace_pair
    pending_path = admin_seif / "modules" / "p1.seif"
    _write_pending(pending_path, module_id="p1")

    entry = reg.register_pending_module(
        registry,
        module_id="p1",
        stored_in_workspace="admin",
        workspace_relative_path=".seif/modules/p1.seif",
        target_workspace="ops",
        target_consumer="next_cycle",
    )

    resolved = reg.resolve_pending_path(registry, entry)
    assert resolved == pending_path


def test_resolve_pending_path_unknown_workspace(workspace_pair):
    registry, _, _ = workspace_pair
    bad = {"stored_in_workspace": "nowhere", "workspace_relative_path": "x.seif"}
    assert reg.resolve_pending_path(registry, bad) is None


def test_list_open_filters_consumed(workspace_pair):
    registry, admin_seif, _ = workspace_pair
    _write_pending(admin_seif / "modules" / "p1.seif", module_id="p1", status="open")
    _write_pending(admin_seif / "modules" / "p2.seif", module_id="p2", status="consumed")

    for mid in ("p1", "p2"):
        reg.register_pending_module(
            registry,
            module_id=mid,
            stored_in_workspace="admin",
            workspace_relative_path=f".seif/modules/{mid}.seif",
            target_workspace="ops",
            target_consumer="next_cycle",
        )

    open_pendings = reg.list_open_pendings(registry, current_workspace_id="ops")
    ids = [e["module_id"] for e in open_pendings]
    assert "p1" in ids
    assert "p2" not in ids


def test_list_open_surfaces_owner_targeted_regardless_of_workspace(workspace_pair):
    registry, admin_seif, _ = workspace_pair
    _write_pending(admin_seif / "modules" / "owner-pending.seif", module_id="op")

    reg.register_pending_module(
        registry,
        module_id="op",
        stored_in_workspace="admin",
        workspace_relative_path=".seif/modules/owner-pending.seif",
        target_workspace="admin",
        target_consumer="owner",
    )

    # Caller is in 'ops', but owner-targeted pendings are always surfaced.
    open_pendings = reg.list_open_pendings(registry, current_workspace_id="ops")
    assert any(e["module_id"] == "op" for e in open_pendings)


def test_mark_consumed_updates_source(workspace_pair):
    registry, admin_seif, _ = workspace_pair
    pending_path = admin_seif / "modules" / "p1.seif"
    _write_pending(pending_path, module_id="p1")

    entry = reg.register_pending_module(
        registry,
        module_id="p1",
        stored_in_workspace="admin",
        workspace_relative_path=".seif/modules/p1.seif",
        target_workspace="ops",
        target_consumer="next_cycle",
    )

    ok = reg.mark_pending_consumed(registry, entry, consumed_in_cycle="s32-test")
    assert ok is True

    persisted = json.loads(pending_path.read_text())
    assert persisted["status"] == "consumed"
    assert persisted["consumed_in_cycle"] == "s32-test"
    assert "consumed_at" in persisted


def test_unregister_pending(workspace_pair):
    registry, admin_seif, _ = workspace_pair
    _write_pending(admin_seif / "modules" / "p1.seif", module_id="p1")
    reg.register_pending_module(
        registry,
        module_id="p1",
        stored_in_workspace="admin",
        workspace_relative_path=".seif/modules/p1.seif",
        target_workspace="ops",
        target_consumer="next_cycle",
    )

    assert reg.unregister_pending_module(registry, "p1") is True
    assert reg.unregister_pending_module(registry, "missing") is False
    assert registry["pending_modules"] == []


def test_read_pending_status_missing_file(workspace_pair):
    registry, _, _ = workspace_pair
    bad = {"stored_in_workspace": "admin", "workspace_relative_path": ".seif/modules/nope.seif"}
    assert reg.read_pending_status(registry, bad) == "missing"


# ── Visibility tier (gap-14 follow-up) ──────────────────────────────────────


def test_register_personal_pending(tmp_path, monkeypatch):
    """Personal-tier pendings live under ~/.seif/ and need no workspace_id."""
    fake_home = tmp_path / "home"
    fake_seif = fake_home / ".seif"
    (fake_seif / "pending").mkdir(parents=True)
    monkeypatch.setattr(reg, "get_user_home", lambda: fake_seif)

    pending = fake_seif / "pending" / "personal-x.seif"
    _write_pending(pending, module_id="personal-x", status="open")

    registry = reg._empty_registry()
    entry = reg.register_pending_module(
        registry,
        module_id="personal-x",
        visibility="personal",
        workspace_relative_path="pending/personal-x.seif",
        target_consumer="owner",
    )
    assert entry["visibility"] == "personal"
    assert entry["stored_in_workspace"] is None
    assert entry["target_workspace"] is None

    resolved = reg.resolve_pending_path(registry, entry)
    assert resolved == pending


def test_personal_pending_surfaces_anywhere(tmp_path, monkeypatch):
    """Personal pendings should appear regardless of current workspace."""
    fake_home = tmp_path / "home"
    fake_seif = fake_home / ".seif"
    (fake_seif / "pending").mkdir(parents=True)
    monkeypatch.setattr(reg, "get_user_home", lambda: fake_seif)

    pending = fake_seif / "pending" / "p.seif"
    _write_pending(pending, module_id="p", status="open")

    registry = reg._empty_registry()
    reg.register_pending_module(
        registry,
        module_id="p",
        visibility="personal",
        workspace_relative_path="pending/p.seif",
        target_consumer="next_cycle",
    )

    # caller in workspace A, B, or no workspace — personal still surfaces
    for ws in ("workspace-A", "workspace-B", None):
        opens = reg.list_open_pendings(registry, current_workspace_id=ws)
        assert any(e["module_id"] == "p" for e in opens), \
            f"personal pending hidden when in workspace {ws}"


def test_register_team_requires_workspace():
    registry = reg._empty_registry()
    with pytest.raises(ValueError, match="stored_in_workspace"):
        reg.register_pending_module(
            registry,
            module_id="t",
            visibility="team",
            workspace_relative_path=".seif/pending/t.seif",
            target_consumer="next_cycle",
        )


def test_register_invalid_visibility():
    registry = reg._empty_registry()
    with pytest.raises(ValueError, match="visibility must be"):
        reg.register_pending_module(
            registry,
            module_id="x",
            visibility="public",  # not allowed
            workspace_relative_path="x.seif",
            target_consumer="owner",
        )


def test_legacy_entry_without_visibility_resolves(workspace_pair):
    """Entries written by PR #45 (no visibility field) keep working."""
    registry, admin_seif, _ = workspace_pair
    pending = admin_seif / "modules" / "legacy.seif"
    _write_pending(pending, module_id="legacy", status="open")

    # Manually craft a PR-#45-shaped entry with no visibility field
    registry["pending_modules"].append({
        "module_id": "legacy",
        "stored_in_workspace": "admin",
        "workspace_relative_path": ".seif/modules/legacy.seif",
        "target_workspace": "ops",
        "target_consumer": "next_cycle",
    })

    resolved = reg.resolve_pending_path(registry, registry["pending_modules"][0])
    assert resolved == pending

    opens = reg.list_open_pendings(registry, current_workspace_id="ops")
    assert any(e["module_id"] == "legacy" for e in opens)
