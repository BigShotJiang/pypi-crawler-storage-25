"""Tests for cycle_heal (consent-gated remediation, schema v2).

Acceptance criteria (binding):
  - build_heal_plan is READ-ONLY: must not mutate any session entry,
    cycle file, or registry. test_build_heal_plan_does_not_mutate_state
    is the binding regression for that contract.
  - apply_heal_plan only fires when invoked explicitly (separate function);
    no implicit application happens during plan construction. The CLI
    surface enforces a separate flag (--heal-apply) for the consent step.
  - Plan output is a stable, machine-readable schema (SEIF-HEAL-PLAN-v2).
  - apply_heal_plan MOVES session entries from active/ to
    sessions/sealed/<cycle_id>/ — does NOT delete. The s60 rank-1 finding
    showed delete-based heal is silently undone by heartbeatd
    rsync --ignore-existing pulls from peers; move-not-delete is sync-
    coherent (no deletion = nothing for sync to undo) AND preserves the
    session body as audit evidence in the sealed/<cycle_id>/ archive.
  - v1 plans (delete-based) are explicitly rejected with a migration hint.
"""

from __future__ import annotations

import json
import os
import uuid
from pathlib import Path

import pytest

from seif.plugins.core.cycle_heal import (
    apply_heal_plan,
    build_heal_plan,
    write_heal_plan,
)
from seif.plugins.core.session_registry import (
    new_session_id,
    register,
)


@pytest.fixture
def workspace(tmp_path):
    ws = tmp_path / "workspace"
    (ws / ".seif" / "cycles").mkdir(parents=True)
    return ws


def _write_sealed_with_writer_session(workspace: Path, slug: str, sid: str) -> Path:
    """Create a SEALED cycle that declares ``sid`` as a writer session AND
    register that session into active/ — the canonical class-(c) setup."""
    register(seif_dir=workspace / ".seif", session_id=sid, wrapper="x",
             cwd=workspace)
    path = workspace / ".seif" / "cycles" / f"{slug}-SEALED.seif"
    path.write_text(json.dumps({
        "cycle_id": slug,
        "status": "SEALED",
        "writer_sessions": [{"session_id": sid, "role": "primary"}],
    }, indent=2))
    return path


# ── build_heal_plan (READ-ONLY phase) ────────────────────────────────────


def test_build_heal_plan_clean_workspace_yields_empty_actions(workspace):
    plan = build_heal_plan(workspace=workspace)
    assert plan["schema"] == "SEIF-HEAL-PLAN-v2"
    assert plan["actions"] == []
    assert plan["based_on_audit"]["class_c_count"] == 0


def test_build_heal_plan_targets_class_c_violations(workspace):
    sid_a = new_session_id()
    sid_b = new_session_id()
    _write_sealed_with_writer_session(workspace, "leak-1", sid_a)
    _write_sealed_with_writer_session(workspace, "leak-2", sid_b)

    plan = build_heal_plan(workspace=workspace)
    assert plan["based_on_audit"]["class_c_count"] == 2
    assert len(plan["actions"]) == 2

    sids_in_plan = {a["session_id"] for a in plan["actions"]}
    assert sids_in_plan == {sid_a, sid_b}
    for a in plan["actions"]:
        assert a["kind"] == "move_session_to_sealed"
        assert "session_file" in a and a["session_file"]
        assert "cycle_id" in a and a["cycle_id"] in {"leak-1", "leak-2"}
        assert "dest_path" in a and a["dest_path"].endswith(
            f"sessions/sealed/{a['cycle_id']}/{a['session_id']}.json"
        )
        assert "reason" in a and "sealed" in a["reason"].lower()


def test_build_heal_plan_omits_advisory_class_a_b(workspace):
    """Class-(a) cycles-without-writers and class-(b) sessions-without-cycle_id
    must NOT generate heal actions — only class-(c) is in scope."""
    # Class-(a): SEALED cycle without writer_sessions
    (workspace / ".seif" / "cycles" / "void-SEALED.seif").write_text(json.dumps({
        "cycle_id": "void", "status": "SEALED",
    }))
    # Class-(b): active session without cycle_id
    sid = new_session_id()
    register(seif_dir=workspace / ".seif", session_id=sid, wrapper="x",
             cwd=workspace)

    plan = build_heal_plan(workspace=workspace)
    assert plan["actions"] == []
    assert plan["based_on_audit"]["class_a_count"] >= 1
    assert plan["based_on_audit"]["class_b_count"] >= 1
    assert plan["based_on_audit"]["class_c_count"] == 0


def test_build_heal_plan_does_not_mutate_state(workspace):
    """BINDING: building the plan must not touch any session entry, cycle
    file, registry, or filesystem state aside from itself."""
    sid = new_session_id()
    sealed_path = _write_sealed_with_writer_session(workspace, "binding", sid)
    session_path = workspace / ".seif" / "sessions" / "active" / f"{sid}.json"

    sealed_before = sealed_path.read_bytes()
    sealed_mtime_before = sealed_path.stat().st_mtime
    session_before = session_path.read_bytes()
    session_mtime_before = session_path.stat().st_mtime

    plan = build_heal_plan(workspace=workspace)
    assert len(plan["actions"]) == 1

    assert sealed_path.read_bytes() == sealed_before, (
        "build_heal_plan must not modify cycle file bytes"
    )
    assert sealed_path.stat().st_mtime == sealed_mtime_before, (
        "build_heal_plan must not even touch cycle file mtime"
    )
    assert session_path.read_bytes() == session_before, (
        "build_heal_plan must not modify session entry bytes"
    )
    assert session_path.stat().st_mtime == session_mtime_before, (
        "build_heal_plan must not even touch session entry mtime"
    )

    # No heal-plans dir created either (build is pure — write is separate)
    assert not (workspace / ".seif" / "heal-plans").exists()


def test_build_heal_plan_carries_workspace_for_apply_safety(workspace):
    plan = build_heal_plan(workspace=workspace)
    assert plan["workspace"] == str(workspace.resolve())
    assert plan["approval_required"] is True
    assert "to_apply" in plan and "--heal-apply" in plan["to_apply"]


# ── write_heal_plan (persistence) ────────────────────────────────────────


def test_write_heal_plan_persists_under_heal_plans_dir(workspace):
    sid = new_session_id()
    _write_sealed_with_writer_session(workspace, "persist", sid)
    plan = build_heal_plan(workspace=workspace)
    out = write_heal_plan(plan, workspace=workspace)

    assert out.is_file()
    assert out.parent == workspace / ".seif" / "heal-plans"
    # plan_id contains colons (ISO timestamp); filename strips them
    safe_id = plan["plan_id"].replace(":", "")
    assert safe_id in out.name

    persisted = json.loads(out.read_text())
    assert persisted == plan


# ── apply_heal_plan (MUTATION phase, consent-gated) ──────────────────────


def test_apply_heal_plan_moves_targeted_sessions_to_sealed(workspace):
    sid = new_session_id()
    session_path = _write_sealed_with_writer_session(
        workspace, "apply-me", sid
    ).parent.parent / "sessions" / "active" / f"{sid}.json"
    assert session_path.is_file()
    body_before = session_path.read_bytes()

    plan = build_heal_plan(workspace=workspace)
    plan_path = write_heal_plan(plan, workspace=workspace)
    outcome = apply_heal_plan(plan_path, workspace=workspace)

    assert outcome["summary"]["applied"] == 1
    assert outcome["summary"]["errors"] == 0
    assert not session_path.exists(), "session entry must leave active/"
    sealed_path = (
        workspace / ".seif" / "sessions" / "sealed" / "apply-me" / f"{sid}.json"
    )
    assert sealed_path.is_file(), (
        f"session must land at sealed/<cycle_id>/<sid>.json (got: {sealed_path})"
    )
    assert sealed_path.read_bytes() == body_before, (
        "move-not-delete preserves the session body as audit evidence"
    )


def test_apply_heal_plan_idempotent_when_already_at_sealed(workspace):
    """Re-applying a plan whose targets are already in sealed/<cycle_id>/
    must NOT error — each already-archived session is a benign skip."""
    sid = new_session_id()
    _write_sealed_with_writer_session(workspace, "idempotent", sid)

    plan = build_heal_plan(workspace=workspace)
    plan_path = write_heal_plan(plan, workspace=workspace)

    first = apply_heal_plan(plan_path, workspace=workspace)
    assert first["summary"]["applied"] == 1

    second = apply_heal_plan(plan_path, workspace=workspace)
    assert second["summary"]["errors"] == 0
    assert second["summary"]["applied"] == 0
    assert second["summary"]["skipped"] == 1
    assert "already" in second["results"][0]["message"].lower()


def test_apply_heal_plan_post_apply_audit_shows_zero_class_c(workspace):
    """Binding regression for the s60 rank-1 fix: after heal-apply moves
    sessions to sealed/, audit_cycle_coherence MUST report zero class-(c)
    violations. Pre-fix, sessions were deleted and rsync re-pulled them;
    post-fix, sessions are moved out of active/ entirely so audit's
    class-(c) check (writer in active/ + cycle SEALED) cannot fire."""
    from seif.plugins.core.cycle_coherence import audit_cycle_coherence

    sid = new_session_id()
    _write_sealed_with_writer_session(workspace, "post-audit", sid)

    pre = audit_cycle_coherence(workspace=workspace)
    assert len(pre.sealed_cycles_with_active_writer_sessions) == 1

    plan = build_heal_plan(workspace=workspace)
    plan_path = write_heal_plan(plan, workspace=workspace)
    apply_heal_plan(plan_path, workspace=workspace)

    post = audit_cycle_coherence(workspace=workspace)
    assert len(post.sealed_cycles_with_active_writer_sessions) == 0


def test_apply_heal_plan_sync_coherence_simulation(workspace):
    """Simulate a peer-rsync ``--ignore-existing`` pull AFTER heal-apply has
    moved a session to sealed/. The rsync pull only re-introduces files
    that DON'T exist locally — so a peer that still has the session at
    active/<sid>.json would re-write it locally if heal had deleted it.
    With move-not-delete, the active/ slot is empty AND the file body
    is in sealed/<cycle_id>/, so a re-pull from a peer that still has
    the active/ copy would land it at active/ — class-(c) returns IF
    audit is naive. The contract under option E is: after heal, audit
    treats the moved file as resolved, and the rsync ignore-existing
    semantics do not undo the move because nothing was deleted."""
    sid = new_session_id()
    _write_sealed_with_writer_session(workspace, "sync-test", sid)

    plan = build_heal_plan(workspace=workspace)
    plan_path = write_heal_plan(plan, workspace=workspace)
    apply_heal_plan(plan_path, workspace=workspace)

    # The sealed copy is the authoritative archive. heartbeatd's default
    # SYNC_PATHS does not include sessions/sealed/, so a peer-pull cannot
    # touch this file body.
    sealed_path = (
        workspace / ".seif" / "sessions" / "sealed" / "sync-test" / f"{sid}.json"
    )
    active_path = (
        workspace / ".seif" / "sessions" / "active" / f"{sid}.json"
    )
    assert sealed_path.is_file()
    assert not active_path.exists()


def test_apply_heal_plan_v1_schema_explicitly_rejected(workspace):
    """v1 plans (delete-based) are silently undone by sync. Reject
    explicitly with a migration hint pointing at the current build."""
    bad_v1 = {
        "schema": "SEIF-HEAL-PLAN-v1",
        "plan_id": "old-plan",
        "workspace": str(workspace.resolve()),
        "actions": [
            {"kind": "unregister_session", "session_id": "fake", "cycle_id": "old"}
        ],
    }
    plan_path = workspace / ".seif" / "v1-plan.json"
    plan_path.parent.mkdir(parents=True, exist_ok=True)
    plan_path.write_text(json.dumps(bad_v1))
    with pytest.raises(ValueError, match="schema v1.*retired"):
        apply_heal_plan(plan_path, workspace=workspace)


def test_apply_heal_plan_refuses_cross_workspace(workspace, tmp_path):
    """If a plan was built for workspace A but apply targets workspace B,
    refuse — defensive guard against accidental cross-workspace heal."""
    sid = new_session_id()
    _write_sealed_with_writer_session(workspace, "ws-a", sid)
    plan = build_heal_plan(workspace=workspace)
    plan_path = write_heal_plan(plan, workspace=workspace)

    other_ws = tmp_path / "other-workspace"
    (other_ws / ".seif").mkdir(parents=True)

    with pytest.raises(ValueError, match="does not match"):
        apply_heal_plan(plan_path, workspace=other_ws)


def test_apply_heal_plan_rejects_unknown_schema(workspace):
    bad = workspace / ".seif" / "bogus-plan.json"
    bad.write_text(json.dumps({"schema": "SOMETHING-ELSE", "actions": []}))
    with pytest.raises(ValueError, match="schema mismatch"):
        apply_heal_plan(bad, workspace=workspace)


def test_apply_heal_plan_rejects_missing_file(workspace):
    with pytest.raises(ValueError, match="not found"):
        apply_heal_plan(workspace / ".seif" / "no-such-plan.json",
                        workspace=workspace)


def test_apply_heal_plan_rejects_invalid_json(workspace):
    bad = workspace / ".seif" / "broken.json"
    bad.write_text("{not valid json")
    with pytest.raises(ValueError, match="not valid JSON"):
        apply_heal_plan(bad, workspace=workspace)


def test_apply_heal_plan_skips_unknown_action_kinds(workspace):
    """Forward-compat: a plan with an unknown action kind must skip
    cleanly (with diagnostic) rather than crashing."""
    plan = {
        "schema": "SEIF-HEAL-PLAN-v2",
        "plan_id": "test",
        "workspace": str(workspace.resolve()),
        "actions": [{"kind": "future_action_kind", "data": "x"}],
    }
    plan_path = workspace / ".seif" / "future-plan.json"
    plan_path.write_text(json.dumps(plan))
    outcome = apply_heal_plan(plan_path, workspace=workspace)
    assert outcome["summary"]["applied"] == 0
    assert outcome["summary"]["skipped"] == 1
    assert outcome["summary"]["errors"] == 0
    assert "unknown action kind" in outcome["results"][0]["message"]


# ── consent-gating: build never triggers apply ──────────────────────────


def test_build_does_not_move_sessions_implicitly(workspace):
    """BINDING: build_heal_plan must NEVER move/delete a session as a side
    effect — that's apply_heal_plan's job, behind --heal-apply."""
    sid = new_session_id()
    session_path = workspace / ".seif" / "sessions" / "active" / f"{sid}.json"
    _write_sealed_with_writer_session(workspace, "no-implicit", sid)
    assert session_path.is_file()

    build_heal_plan(workspace=workspace)
    assert session_path.is_file(), (
        "build_heal_plan must not touch sessions; only apply_heal_plan does"
    )
    sealed_dir = workspace / ".seif" / "sessions" / "sealed"
    assert not sealed_dir.exists(), (
        "build_heal_plan must not even create sessions/sealed/"
    )
