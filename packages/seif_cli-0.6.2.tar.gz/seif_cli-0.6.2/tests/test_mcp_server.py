"""Tests for the canonical SEIF MCP server (Wedge A Pillar 3, Phase 1).

Two layers:

1. Implementation tests — call ``provenance_sign_impl`` /
   ``provenance_verify_impl`` / ``classification_check_impl`` directly.
   These do not require the ``mcp`` extra and run on every install.
2. MCP wrapper tests — exercise ``build_server()`` + tool registry.
   Guarded by per-test ``importorskip("mcp")`` so CI without the extra
   skips them gracefully (avoids the runner-mismatch trap that bit
   tests/test_mcp_watermark.py — see pending-2026-05-07-mcp-
   importorskip-runner-mismatch.seif).
"""

from __future__ import annotations

import hashlib
import os
import sys
from pathlib import Path

import pytest


sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

pytest.importorskip("cryptography", reason="cryptography not installed")

from seif.mcp.server import (  # noqa: E402
    classification_check_impl,
    log_append_impl,
    log_get_impl,
    provenance_sign_impl,
    provenance_verify_impl,
)


@pytest.fixture
def isolated_keys(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Redirect ~/.seif/ to a tmpdir and generate a fresh Ed25519 keypair.

    Uses the SEIF_HOME env hook supported by seif.data.paths.get_user_home.
    """
    home = tmp_path / "seif_home"
    home.mkdir(parents=True, exist_ok=True)
    monkeypatch.setenv("SEIF_HOME", str(home))

    from seif.core import signing
    signing.keygen()
    return home


# ── provenance_sign_impl ───────────────────────────────────────────────


def test_sign_text_returns_envelope(isolated_keys):
    result = provenance_sign_impl(text="hello provenance")
    assert result["ok"] is True
    assert len(result["content_sha256"]) == 64
    int(result["content_sha256"], 16)  # parses as hex
    assert result["content_size"] == len(b"hello provenance")
    assert result["source"] == "text"
    assert result["signature"]["algorithm"] == "Ed25519"
    assert result["signature"]["public_key"]
    assert result["signature"]["signed_hash"]
    assert result["signature"]["key_fingerprint"]


def test_sign_file_returns_envelope(tmp_path: Path, isolated_keys):
    target = tmp_path / "artifact.txt"
    target.write_text("ai output to attest", encoding="utf-8")

    result = provenance_sign_impl(path=str(target))
    assert result["ok"] is True
    assert len(result["content_sha256"]) == 64
    assert result["content_size"] == len(b"ai output to attest")
    assert str(target) in result["source"]


def test_sign_rejects_both_text_and_path(tmp_path: Path, isolated_keys):
    target = tmp_path / "x.txt"
    target.write_text("x")
    with pytest.raises(ValueError):
        provenance_sign_impl(text="x", path=str(target))


def test_sign_rejects_neither_text_nor_path(isolated_keys):
    with pytest.raises(ValueError):
        provenance_sign_impl()


def test_sign_rejects_missing_file(tmp_path: Path, isolated_keys):
    with pytest.raises(FileNotFoundError):
        provenance_sign_impl(path=str(tmp_path / "does-not-exist.txt"))


def test_sign_without_keypair_raises(tmp_path: Path, monkeypatch: pytest.MonkeyPatch):
    """No keygen run → signing must fail with actionable error."""
    home = tmp_path / "empty_home"
    home.mkdir()
    monkeypatch.setenv("SEIF_HOME", str(home))
    with pytest.raises(FileNotFoundError, match="No signing key"):
        provenance_sign_impl(text="anything")


# ── provenance_verify_impl ─────────────────────────────────────────────


def test_verify_round_trip_text(isolated_keys):
    payload = "deterministic AI output"
    envelope = provenance_sign_impl(text=payload)
    result = provenance_verify_impl(envelope=envelope, text=payload)
    assert result["ok"] is True
    assert result["valid"] is True
    assert result["content_sha256_match"] is True
    assert result["signature_valid"] is True


def test_verify_round_trip_file(tmp_path: Path, isolated_keys):
    target = tmp_path / "artifact.bin"
    target.write_bytes(b"\x00\x01\x02 binary content \xff")

    envelope = provenance_sign_impl(path=str(target))
    result = provenance_verify_impl(envelope=envelope, path=str(target))
    assert result["valid"] is True


def test_verify_detects_tampered_content(isolated_keys):
    envelope = provenance_sign_impl(text="original")
    result = provenance_verify_impl(envelope=envelope, text="tampered")
    assert result["valid"] is False
    assert result["content_sha256_match"] is False
    # Signature itself is over the *original* hash, which we still have in the
    # envelope, so signature_valid stays True — only the content mismatches.
    assert result["signature_valid"] is True


def test_verify_detects_tampered_signature(isolated_keys):
    envelope = provenance_sign_impl(text="original")
    # Flip a bit in the signature
    bad = envelope["signature"]["signed_hash"]
    envelope["signature"]["signed_hash"] = (
        "A" + bad[1:] if bad[0] != "A" else "B" + bad[1:]
    )
    result = provenance_verify_impl(envelope=envelope, text="original")
    assert result["valid"] is False
    assert result["content_sha256_match"] is True
    assert result["signature_valid"] is False


def test_verify_envelope_missing_signature():
    result = provenance_verify_impl(envelope={"content_sha256": "x" * 64}, text="x")
    assert result["ok"] is False
    assert result["error"] == "envelope_missing_signature"


def test_verify_envelope_missing_content_hash():
    result = provenance_verify_impl(envelope={"signature": {}}, text="x")
    assert result["ok"] is False
    assert result["error"] == "envelope_missing_content_sha256"


# ── classification_check_impl ──────────────────────────────────────────


def test_classify_public_text():
    result = classification_check_impl("the sky is blue")
    assert result["ok"] is True
    assert result["level"] in ("PUBLIC", "INTERNAL", "CONFIDENTIAL")
    assert result["length"] == len("the sky is blue")
    if result["level"] == "PUBLIC":
        assert result["escalation_needed"] is False


def test_classify_confidential_credential():
    result = classification_check_impl("password=hunter2 access_token=abc123")
    assert result["ok"] is True
    assert result["level"] == "CONFIDENTIAL"
    assert result["escalation_needed"] is True


def test_classify_rejects_non_string():
    result = classification_check_impl(42)  # type: ignore[arg-type]
    assert result["ok"] is False
    assert result["error"] == "text_must_be_string"


# ── log_append_impl + log_get_impl (Phase 2 — network-mocked) ──────────


@pytest.fixture
def fake_log_response():
    """Canned successful response shape from POST /v1/entries."""
    return {
        "id": "11111111-1111-1111-1111-111111111111",
        "sequence": 7,
        "tenant_id": "22222222-2222-2222-2222-222222222222",
        "canonical_sha256": "c" * 64,
        "submitted_at": "2026-05-07T16:30:00+00:00",
        "entry_type": "ai.artifact",
        "primary_content_sha256": "a" * 64,
    }


def test_log_append_with_envelope_happy_path(
    isolated_keys, monkeypatch, fake_log_response
):
    captured = {}

    def fake_submit(identity, **kwargs):
        captured.update(kwargs)
        captured["identity_pubkey_len"] = len(identity.pubkey_bytes)
        return fake_log_response

    monkeypatch.setattr("seif.log.client.submit_entry", fake_submit)

    envelope = provenance_sign_impl(text="ai output to attest")
    result = log_append_impl(envelope=envelope, log_url="http://test:8000")

    assert result["ok"] is True
    assert result["entry_id"] == fake_log_response["id"]
    assert result["sequence"] == 7
    assert result["source"] == "envelope"
    assert result["submitted_content_sha256"] == envelope["content_sha256"]
    # Server received the right hash + classification + log url
    assert captured["primary_content_sha256_hex"] == envelope["content_sha256"]
    assert captured["classification_ceil"] == "INTERNAL"
    assert captured["log_url"] == "http://test:8000"
    assert captured["identity_pubkey_len"] == 32  # raw Ed25519 pubkey


def test_log_append_with_text_happy_path(
    isolated_keys, monkeypatch, fake_log_response
):
    monkeypatch.setattr(
        "seif.log.client.submit_entry",
        lambda identity, **kwargs: fake_log_response,
    )
    result = log_append_impl(
        text="raw payload",
        log_url="http://test:8000",
        classification_ceil="PUBLIC",
    )
    assert result["ok"] is True
    assert result["source"] == "text"
    # text path computes hash inline
    expected = hashlib.sha256(b"raw payload").hexdigest()
    assert result["submitted_content_sha256"] == expected


def test_log_append_with_path_happy_path(
    tmp_path: Path, isolated_keys, monkeypatch, fake_log_response
):
    target = tmp_path / "artifact.bin"
    target.write_bytes(b"\x00\x01\x02 binary")
    monkeypatch.setattr(
        "seif.log.client.submit_entry",
        lambda identity, **kwargs: fake_log_response,
    )
    result = log_append_impl(path=str(target), log_url="http://test:8000")
    assert result["ok"] is True
    assert "file:" in result["source"]


def test_log_append_rejects_no_args(isolated_keys):
    result = log_append_impl()
    assert result["ok"] is False
    assert "exactly_one_of" in result["error"]


def test_log_append_rejects_two_args(isolated_keys):
    env = provenance_sign_impl(text="x")
    result = log_append_impl(envelope=env, text="y")
    assert result["ok"] is False
    assert "exactly_one_of" in result["error"]


def test_log_append_rejects_envelope_without_hash(isolated_keys):
    result = log_append_impl(envelope={"signature": {}})
    assert result["ok"] is False
    assert "envelope_missing_or_invalid_content_sha256" in result["error"]


def test_log_append_rejects_envelope_with_bad_hash(isolated_keys):
    result = log_append_impl(envelope={"content_sha256": "not-hex-not-64-chars"})
    assert result["ok"] is False
    assert "envelope_missing_or_invalid_content_sha256" in result["error"]


def test_log_append_rejects_bad_classification(isolated_keys):
    result = log_append_impl(text="x", classification_ceil="SECRET")
    assert result["ok"] is False
    assert "classification_ceil" in result["error"]


def test_log_append_maps_http_error(isolated_keys, monkeypatch):
    from seif.log.client import LogHTTPError

    def fake_submit(identity, **kwargs):
        raise LogHTTPError(409, "client_nonce_already_used_for_tenant")

    monkeypatch.setattr("seif.log.client.submit_entry", fake_submit)

    result = log_append_impl(text="x", log_url="http://test:8000")
    assert result["ok"] is False
    assert result["error"] == "log_http_error"
    assert result["status"] == 409
    assert "client_nonce" in result["detail"]


def test_log_append_maps_connection_error(isolated_keys, monkeypatch):
    from seif.log.client import LogClientError

    def fake_submit(identity, **kwargs):
        raise LogClientError("connection refused")

    monkeypatch.setattr("seif.log.client.submit_entry", fake_submit)

    result = log_append_impl(text="x", log_url="http://test:8000")
    assert result["ok"] is False
    assert result["error"] == "log_client_error"
    assert "connection refused" in result["detail"]


def test_log_append_uses_env_log_url(
    isolated_keys, monkeypatch, fake_log_response
):
    """When log_url is None, falls back to $SEIF_LOG_URL."""
    captured = {}

    def fake_submit(identity, **kwargs):
        captured.update(kwargs)
        return fake_log_response

    monkeypatch.setattr("seif.log.client.submit_entry", fake_submit)
    monkeypatch.setenv("SEIF_LOG_URL", "http://from-env:9999")

    result = log_append_impl(text="x")
    assert result["ok"] is True
    assert captured["log_url"] == "http://from-env:9999"
    assert result["log_url"] == "http://from-env:9999"


def test_log_get_happy_path(isolated_keys, monkeypatch):
    canned_entry = {
        "id": "33333333-3333-3333-3333-333333333333",
        "sequence": 5,
        "primary_content_sha256": "b" * 64,
        "submitted_at": "2026-05-07T17:00:00+00:00",
    }
    monkeypatch.setattr(
        "seif.log.client.verify_entry",
        lambda identity, entry_id, **kwargs: canned_entry,
    )

    result = log_get_impl(canned_entry["id"], log_url="http://test:8000")
    assert result["ok"] is True
    assert result["entry"] == canned_entry
    assert result["log_url"] == "http://test:8000"


def test_log_get_rejects_empty_entry_id(isolated_keys):
    result = log_get_impl("")
    assert result["ok"] is False
    assert "entry_id_required" in result["error"]


def test_log_get_maps_404(isolated_keys, monkeypatch):
    from seif.log.client import LogHTTPError

    def fake_verify(identity, entry_id, **kwargs):
        raise LogHTTPError(404, "entry_not_found")

    monkeypatch.setattr("seif.log.client.verify_entry", fake_verify)

    result = log_get_impl("99999999-9999-9999-9999-999999999999")
    assert result["ok"] is False
    assert result["status"] == 404
    assert result["detail"] == "entry_not_found"


def test_chain_sign_log_get_round_trip(
    isolated_keys, monkeypatch, fake_log_response
):
    """Smoke-test the documented chain: sign → log → get → verify.

    Confirms hashes line up across surfaces. HTTP is mocked but the
    hash math runs for real.
    """
    payload = "hello chain"
    envelope = provenance_sign_impl(text=payload)

    submitted: dict[str, Any] = {}

    def fake_submit(identity, **kwargs):
        submitted.update(kwargs)
        # echo back the hash the server received
        return {
            **fake_log_response,
            "primary_content_sha256": kwargs["primary_content_sha256_hex"],
        }

    def fake_verify(identity, entry_id, **kwargs):
        return {
            "id": entry_id,
            "sequence": 7,
            "primary_content_sha256": submitted["primary_content_sha256_hex"],
            "submitted_at": "2026-05-07T16:30:00+00:00",
        }

    monkeypatch.setattr("seif.log.client.submit_entry", fake_submit)
    monkeypatch.setattr("seif.log.client.verify_entry", fake_verify)

    appended = log_append_impl(envelope=envelope, log_url="http://test:8000")
    assert appended["ok"] is True

    retrieved = log_get_impl(appended["entry_id"], log_url="http://test:8000")
    assert retrieved["ok"] is True

    # Hash matches across all three surfaces:
    assert envelope["content_sha256"] == \
        appended["submitted_content_sha256"] == \
        retrieved["entry"]["primary_content_sha256"]

    # And local verify still succeeds against the original payload:
    verified = provenance_verify_impl(envelope=envelope, text=payload)
    assert verified["valid"] is True


# ── build_server (MCP wrapper) ─────────────────────────────────────────
# Per-test importorskip — module-level skip would create the runner-
# mismatch trap (pending-2026-05-07-mcp-importorskip-runner-mismatch.seif).


def test_server_registers_expected_tools():
    pytest.importorskip("mcp", reason="MCP SDK not installed; skip [mcp] extra tests")
    import asyncio
    from seif.mcp.server import build_server

    server = build_server()
    tools = asyncio.run(server.list_tools())
    names = {t.name for t in tools}
    assert names == {
        "provenance_sign",
        "provenance_verify",
        "classification_check",
        "log_append",
        "log_get",
    }
