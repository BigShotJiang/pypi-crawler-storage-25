"""Regression tests for admin-docs Gap 47.

Pre-fix: SENSITIVE_KEYWORDS contained 'private_key' (underscore). The PEM canonical
marker is 'BEGIN RSA PRIVATE KEY' (space). _auto_classify lowercased the content
and substring-matched the keyword list — never matching the PEM space form.
PEM/OpenSSH/PGP keys were silently classified INTERNAL.

Post-fix: PRIVATE_KEY_MARKERS substring-matched against raw (uppercase) content
before the keyword loop. Any PEM/OpenSSH/PGP private-key marker → CONFIDENTIAL.
"""
from seif.context.file_extractor import _auto_classify


def test_classify_pem_rsa_marker_is_confidential():
    content = "-----BEGIN RSA PRIVATE KEY-----\nMIIEpAIBAAKCAQEA...\n-----END RSA PRIVATE KEY-----\n"
    assert _auto_classify(content) == "CONFIDENTIAL"


def test_classify_pem_dsa_marker_is_confidential():
    content = "-----BEGIN DSA PRIVATE KEY-----\nMIIBuwIBAAKBgQ...\n-----END DSA PRIVATE KEY-----\n"
    assert _auto_classify(content) == "CONFIDENTIAL"


def test_classify_pem_ec_marker_is_confidential():
    content = "-----BEGIN EC PRIVATE KEY-----\nMHQCAQEEIK...\n-----END EC PRIVATE KEY-----\n"
    assert _auto_classify(content) == "CONFIDENTIAL"


def test_classify_pem_pkcs8_unencrypted_marker_is_confidential():
    content = "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAA...\n-----END PRIVATE KEY-----\n"
    assert _auto_classify(content) == "CONFIDENTIAL"


def test_classify_pem_pkcs8_encrypted_marker_is_confidential():
    content = "-----BEGIN ENCRYPTED PRIVATE KEY-----\nMIIFDjBABgkqhkiG9w0BBQ0wMzAb...\n-----END ENCRYPTED PRIVATE KEY-----\n"
    assert _auto_classify(content) == "CONFIDENTIAL"


def test_classify_openssh_marker_is_confidential():
    content = "-----BEGIN OPENSSH PRIVATE KEY-----\nb3BlbnNzaC1rZXktdjEAAAAABG5vbmUAAAA...\n-----END OPENSSH PRIVATE KEY-----\n"
    assert _auto_classify(content) == "CONFIDENTIAL"


def test_classify_pgp_marker_is_confidential():
    content = "-----BEGIN PGP PRIVATE KEY BLOCK-----\nlQWGBGAaQc4BDADKy3...\n-----END PGP PRIVATE KEY BLOCK-----\n"
    assert _auto_classify(content) == "CONFIDENTIAL"


def test_classify_pem_marker_with_surrounding_text():
    """PEM markers anywhere in the file (e.g. embedded in a config) trigger CONFIDENTIAL."""
    content = (
        "# Server config\n"
        "host: example.com\n"
        "ssl_key: |\n"
        "  -----BEGIN RSA PRIVATE KEY-----\n"
        "  MIIEpAIBAAKCAQEA...\n"
        "  -----END RSA PRIVATE KEY-----\n"
    )
    assert _auto_classify(content) == "CONFIDENTIAL"


def test_classify_keyword_branch_still_works_for_password():
    """Pre-existing keyword classification (password/secret/token) is preserved."""
    assert _auto_classify("password: hunter2") == "CONFIDENTIAL"
    assert _auto_classify("API_KEY=abc123") == "CONFIDENTIAL"


def test_classify_benign_content_is_internal():
    """Sanity: ordinary text without sensitive markers stays INTERNAL."""
    assert _auto_classify("This is a project README.\n\nSee docs/.\n") == "INTERNAL"


def test_classify_mention_of_pem_in_docs_does_not_false_positive():
    """A doc mentioning 'private key' in prose (no PEM markers) does NOT trigger PEM branch.

    It still triggers the existing keyword branch via 'private_key' substring? No —
    SENSITIVE_KEYWORDS uses 'private_key' (underscore). Plain prose 'private key' (space)
    does NOT contain that token. So benign prose stays INTERNAL.
    """
    content = "To enable signing, place your private key in ~/.ssh/id_rsa.\n"
    assert _auto_classify(content) == "INTERNAL"
