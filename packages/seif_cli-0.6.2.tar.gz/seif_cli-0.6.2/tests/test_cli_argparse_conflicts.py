"""Regression: argparse parser construction must not crash with conflicts.

Pre-fix: `--dry-run` and `--yes` were each registered TWICE in cli.py
because PR #65 (--migrate-host-config) added new declarations without
checking that the same option strings already existed for other flags
(--rebuild-registry, --probe-models). The parser raised
`argparse.ArgumentError: argument --dry-run: conflicting option string`
on every CLI invocation. The seif binary became unusable.

Smoke run on Air during s44 v2 distribution caught this — Mini's test
suite did NOT catch it because tests exercise specific code paths via
mocks, not the full parser construction.

This regression test mimics what `seif --anything` does at the very
first instruction of main(): build the parser. If anyone adds a
conflicting option string in the future, this test fails immediately.
"""
from __future__ import annotations

import os
import sys
import unittest
from unittest.mock import patch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))


class ArgparseConstructionTests(unittest.TestCase):
    def test_main_parser_builds_without_conflict(self):
        """Calling main() with no args must not raise ArgumentError."""
        # Use --version so main exits cleanly after parser construction
        # (without doing real work).
        with patch.object(sys, "argv", ["seif", "--version"]):
            from seif.cli.cli import main
            try:
                main()
            except SystemExit:
                # --version triggers SystemExit(0) — expected
                pass
            except Exception as e:
                self.fail(
                    f"parser construction crashed with "
                    f"{type(e).__name__}: {e}"
                )

    def test_dry_run_only_registered_once(self):
        """--dry-run must be a single shared flag across all sub-features."""
        from pathlib import Path
        cli_src = (Path(__file__).resolve().parent.parent
                   / "src" / "seif" / "cli" / "cli.py").read_text()
        # Look for parser.add_argument with --dry-run as the first option
        import re
        matches = re.findall(
            r'add_argument\(\s*["\']--dry-run["\']',
            cli_src,
        )
        self.assertEqual(
            len(matches), 1,
            f"--dry-run must be declared exactly once; found {len(matches)} "
            f"declarations. Sharing one --dry-run across features is the "
            f"convention; per-feature redeclaration causes ArgumentError."
        )

    def test_yes_only_registered_once(self):
        from pathlib import Path
        cli_src = (Path(__file__).resolve().parent.parent
                   / "src" / "seif" / "cli" / "cli.py").read_text()
        import re
        # Match both `"--yes"` and `"-y", "--yes"` forms
        matches = re.findall(
            r'add_argument\(\s*(?:["\']-y["\'],\s*)?["\']--yes["\']',
            cli_src,
        )
        self.assertEqual(
            len(matches), 1,
            f"--yes must be declared exactly once; found {len(matches)} "
            f"declarations."
        )


if __name__ == "__main__":
    unittest.main()
