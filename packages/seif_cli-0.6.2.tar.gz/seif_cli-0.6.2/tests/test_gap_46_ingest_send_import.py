"""Regression tests for admin-docs Gap 46.

Pre-fix: seif/context/ingest.py:122 called send(...) without importing it.
On any --ingest invocation, the call raised NameError: name 'send' is not defined.

Post-fix: send is imported lazily inside _filter_via_ai (try/except ImportError),
mirroring the cli.py paywall pattern. Without seif-engine installed, the function
returns (text='', success=False, error='AI backend unavailable: ...') instead
of crashing.
"""
import sys
import types

import pytest

import seif.context.ingest as ingest_mod
from seif.context.ingest import _filter_via_ai


def test_filter_via_ai_does_not_raise_nameerror_on_send():
    """Pre-fix reproduction: this would raise NameError before the fix."""
    result = _filter_via_ai(
        raw_text="this is a sample meeting transcript with at least a few words",
        project_context="a test project",
    )
    assert isinstance(result, tuple) and len(result) == 3
    text, success, error = result
    assert isinstance(text, str)
    assert isinstance(success, bool)
    assert isinstance(error, str)


def test_filter_via_ai_returns_friendly_error_when_paywall(monkeypatch):
    """Without seif.bridge.ai_bridge installed, returns success=False with clear error."""
    # Force the import to fail by removing the module path
    monkeypatch.setitem(sys.modules, "seif.bridge.ai_bridge", None)

    text, success, error = _filter_via_ai(
        raw_text="this is a sample meeting transcript with at least a few words",
        project_context="a test project",
    )
    assert success is False
    assert text == ""
    assert "AI backend unavailable" in error


def test_filter_via_ai_uses_send_when_bridge_available(monkeypatch):
    """When seif.bridge.ai_bridge.send exists, it is called and its response is forwarded."""
    fake_response = types.SimpleNamespace(success=True, text="filtered output", error="")
    captured = {}

    def fake_send(message, backend, model, resonance_metadata):
        captured["message"] = message
        captured["backend"] = backend
        captured["model"] = model
        captured["resonance_metadata"] = resonance_metadata
        return fake_response

    fake_module = types.ModuleType("seif.bridge.ai_bridge")
    fake_module.send = fake_send
    monkeypatch.setitem(sys.modules, "seif.bridge.ai_bridge", fake_module)

    text, success, error = _filter_via_ai(
        raw_text="raw transcript text content",
        project_context="project description",
        backend="claude",
        model="sonnet",
    )
    assert success is True
    assert text == "filtered output"
    assert error == ""
    assert captured["backend"] == "claude"
    assert captured["model"] == "sonnet"
    assert captured["resonance_metadata"] == "ingest_filter=true"


def test_filter_via_ai_forwards_send_error(monkeypatch):
    """When send returns success=False, the error is propagated."""
    fake_response = types.SimpleNamespace(success=False, text="", error="rate limited")

    fake_module = types.ModuleType("seif.bridge.ai_bridge")
    fake_module.send = lambda **kwargs: fake_response
    monkeypatch.setitem(sys.modules, "seif.bridge.ai_bridge", fake_module)

    text, success, error = _filter_via_ai(
        raw_text="raw transcript text content here for sure",
        project_context="ctx",
    )
    assert success is False
    assert text == ""
    assert error == "rate limited"


def test_ingest_module_imports_cleanly():
    """Sanity: importing the ingest module does not perform a network call or crash."""
    assert hasattr(ingest_mod, "_filter_via_ai")
    assert hasattr(ingest_mod, "ingest")
