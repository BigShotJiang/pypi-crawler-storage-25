"""Tests for seif --confirm-action — pre-action gatekeeper for hookless clients."""
from __future__ import annotations

import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from seif.cli.confirm_action import run_confirm_action  # noqa: E402


class ConfirmActionTests(unittest.TestCase):

    def test_non_interactive_returns_exit_2(self):
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp)
            (home / ".seif" / "circuit").mkdir(parents=True)
            code = run_confirm_action(
                action="git push origin main",
                reason="merge feature",
                caller="test/non-interactive",
                home=home,
                cwd=home,
                force_interactive=False,
            )
            self.assertEqual(code, 2,
                             "non-interactive must exit 2 to signal "
                             "human-review-required (not 1=error, not 0=ok)")

    def test_non_interactive_writes_host_audit_log(self):
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp)
            run_confirm_action(
                action="git push --force",
                reason="force push to main",
                caller="test/audit",
                home=home, cwd=home,
                force_interactive=False,
            )
            log = home / ".seif" / "circuit" / "confirmations.log"
            self.assertTrue(log.is_file(), "audit log not created")
            entries = [json.loads(l) for l in log.read_text().splitlines()]
            self.assertEqual(len(entries), 1)
            self.assertEqual(entries[0]["action"], "git push --force")
            self.assertEqual(entries[0]["decision"], "AWAITING")
            self.assertEqual(entries[0]["caller"], "test/audit")

    def test_non_interactive_writes_session_scoped_log_when_seif_dir_present(self):
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp)
            project = home / "proj"
            seif_dir = project / ".seif"
            (seif_dir / "sessions").mkdir(parents=True)
            (seif_dir / "mapper.json").write_text(json.dumps({"session_count": 7}))

            run_confirm_action(
                action="rm -rf docs/",
                reason="cleanup",
                caller="test/session-log",
                home=home, cwd=project,
                force_interactive=False,
            )

            session_log = seif_dir / "sessions" / "session-7-confirmations.log"
            self.assertTrue(session_log.is_file(),
                            "session-scoped log not created")
            entry = json.loads(session_log.read_text().strip())
            self.assertEqual(entry["action"], "rm -rf docs/")
            self.assertEqual(entry["decision"], "AWAITING")

    def test_empty_action_returns_1(self):
        with tempfile.TemporaryDirectory() as tmp:
            code = run_confirm_action(
                action="",
                home=Path(tmp), cwd=Path(tmp),
                force_interactive=False,
            )
            self.assertEqual(code, 1, "empty action must be a real error (exit 1)")

    def test_decision_distinct_from_error(self):
        """Exit codes carry meaning: 0=approved, 1=denied/error, 2=awaiting human."""
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp)
            ok_code = run_confirm_action(
                action="any",
                home=home, cwd=home,
                force_interactive=False,
            )
            err_code = run_confirm_action(
                action="",
                home=home, cwd=home,
                force_interactive=False,
            )
            self.assertNotEqual(ok_code, err_code,
                                "AWAITING (2) must be distinguishable from "
                                "real error (1)")


if __name__ == "__main__":
    unittest.main()
