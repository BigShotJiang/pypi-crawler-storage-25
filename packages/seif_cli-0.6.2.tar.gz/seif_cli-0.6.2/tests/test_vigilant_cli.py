"""Tests for --vigilant-watch / --vigilant-list / --vigilant-stop CLI handlers.

Validates the CLI thin wrapper surface around seif_engine.vigilant.watch_registry.
The registry itself is unit-tested in seif-engine/tests/test_watch_registry.py.
"""
from __future__ import annotations

import io
import os
import shutil
import sys
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path
from unittest import mock

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from seif.cli import cli  # noqa: E402


def _engine_available() -> bool:
    try:
        import seif_engine.vigilant.watch_registry  # noqa: F401
        return True
    except ImportError:
        return False


@unittest.skipUnless(_engine_available(), "seif-engine not on PYTHONPATH")
class VigilantCLISmokeTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        # Redirect ~/.seif so the CLI handlers write into a sandbox.
        self._restore_home = self._monkey_home(self.tmp)

    def tearDown(self):
        self._restore_home()
        shutil.rmtree(self.tmp, ignore_errors=True)

    def _monkey_home(self, home: Path):
        original = os.path.expanduser
        def patched(p: str) -> str:
            if p.startswith("~"):
                return str(home) + p[1:]
            return original(p)
        patcher = mock.patch("os.path.expanduser", side_effect=patched)
        patcher.start()
        return patcher.stop

    def _capture(self, fn, *args, **kwargs) -> str:
        buf = io.StringIO()
        with redirect_stdout(buf):
            fn(*args, **kwargs)
        return buf.getvalue()

    def test_watch_requires_notify_target(self):
        out = self._capture(
            cli._cmd_vigilant_watch,
            pattern="x", notify_action="outbox",
            notify_target=None, watch_id=None,
        )
        self.assertIn("requires --notify-target", out)

    def test_watch_register_then_list(self):
        target = self.tmp / "out.log"
        out = self._capture(
            cli._cmd_vigilant_watch,
            pattern=str(self.tmp / "*.txt"),
            notify_action="outbox",
            notify_target=str(target),
            watch_id=None,
        )
        self.assertIn("WATCH REGISTERED", out)
        listing = self._capture(cli._cmd_vigilant_list, None)
        self.assertIn("file_glob", listing)
        self.assertIn("outbox", listing)

    def test_watch_unsupported_action_returns_error(self):
        out = self._capture(
            cli._cmd_vigilant_watch,
            pattern="x", notify_action="exec",
            notify_target="/bin/true", watch_id=None,
        )
        self.assertIn("Error", out)
        self.assertIn("unsupported notify_action", out)

    def test_watch_then_stop(self):
        out = self._capture(
            cli._cmd_vigilant_watch,
            pattern=str(self.tmp / "*.json"),
            notify_action="outbox",
            notify_target=str(self.tmp / "x.log"),
            watch_id="w-test",
        )
        self.assertIn("w-test", out)
        stop_out = self._capture(cli._cmd_vigilant_stop, "w-test")
        self.assertIn("removed watch", stop_out)
        # Second stop is no-op (helpful message).
        again = self._capture(cli._cmd_vigilant_stop, "w-test")
        self.assertIn("no watch with id", again)

    def test_list_status_filter(self):
        for i in range(2):
            self._capture(
                cli._cmd_vigilant_watch,
                pattern=f"p-{i}",
                notify_action="outbox",
                notify_target=str(self.tmp / "x.log"),
                watch_id=f"w-{i}",
            )
        active = self._capture(cli._cmd_vigilant_list, "active")
        self.assertIn("status == active", active)
        self.assertIn("Total    : 2", active)
        fired = self._capture(cli._cmd_vigilant_list, "fired")
        self.assertIn("Total    : 0", fired)


if __name__ == "__main__":
    unittest.main()
