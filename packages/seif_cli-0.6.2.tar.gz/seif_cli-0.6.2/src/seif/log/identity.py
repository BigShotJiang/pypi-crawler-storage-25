"""Ed25519 workspace identity for log attestations.

One identity per host (named, default = 'default') stored at
`~/.seif/identities/<name>.{key,pub}`. Private key is mode 0600.

The pubkey IS the tenant identity in the remote log: first signed submit
auto-bootstraps a 'personal'-plan tenant under that pubkey on the server side.
There is no separate enrollment step.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)
from cryptography.hazmat.primitives import serialization


@dataclass
class Identity:
    name: str
    private_key: Ed25519PrivateKey
    pubkey_bytes: bytes  # raw 32-byte Ed25519 public key

    def sign(self, message: bytes) -> bytes:
        return self.private_key.sign(message)


def _identity_dir() -> Path:
    """Per-host identity store: ~/.seif/identities/."""
    return Path.home() / ".seif" / "identities"


def identity_paths(name: str = "default") -> tuple[Path, Path]:
    base = _identity_dir() / name
    return Path(f"{base}.key"), Path(f"{base}.pub")


def _serialize_private_key(private_key: Ed25519PrivateKey) -> bytes:
    return private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )


def _deserialize_private_key(raw: bytes) -> Ed25519PrivateKey:
    key = serialization.load_pem_private_key(raw, password=None)
    if not isinstance(key, Ed25519PrivateKey):
        raise ValueError("identity key is not Ed25519")
    return key


def ensure_identity(name: str = "default") -> Identity:
    """Load identity `name`, generating + persisting it if missing.

    Private key file is created with mode 0600. Public key file is 0644.
    """
    key_path, pub_path = identity_paths(name)
    key_path.parent.mkdir(parents=True, exist_ok=True)

    if key_path.exists():
        private_key = _deserialize_private_key(key_path.read_bytes())
    else:
        private_key = Ed25519PrivateKey.generate()
        # Write private key with restrictive perms — mode 0600 even on first
        # write (avoid races where the file is briefly world-readable).
        fd = os.open(str(key_path), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        try:
            with os.fdopen(fd, "wb") as fh:
                fh.write(_serialize_private_key(private_key))
        except Exception:
            key_path.unlink(missing_ok=True)
            raise

    pubkey_bytes = private_key.public_key().public_bytes_raw()

    if not pub_path.exists():
        pub_pem = private_key.public_key().public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )
        pub_path.write_bytes(pub_pem)
        try:
            os.chmod(pub_path, 0o644)
        except OSError:
            pass

    return Identity(name=name, private_key=private_key, pubkey_bytes=pubkey_bytes)


def load_public_key(pubkey_bytes: bytes) -> Ed25519PublicKey:
    """Reconstruct an Ed25519PublicKey from raw 32-byte form."""
    return Ed25519PublicKey.from_public_bytes(pubkey_bytes)
