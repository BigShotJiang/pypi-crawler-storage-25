"""Canonical JSON encoder + SHA-256 hash.

Mirror of seif-log/api/canonical.py. Two clients submitting the same logical
payload (regardless of key order or whitespace) produce the same digest.
"""

from __future__ import annotations

import hashlib
import json
from typing import Any


def canonical_json_bytes(payload: Any) -> bytes:
    """Encode `payload` as canonical JSON bytes (sorted keys, compact, UTF-8)."""
    return json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    ).encode("utf-8")


def canonical_sha256(payload: Any) -> bytes:
    """Return the raw 32-byte SHA-256 digest of canonical JSON of `payload`."""
    return hashlib.sha256(canonical_json_bytes(payload)).digest()
