"""HTTP client for seif-log — submit + verify with SEIF-Ed25519 auth.

stdlib-only (urllib + json) so adding seif --log-* commands does not pull in
httpx for a few short request paths. The signature scheme matches what the
seif-log server expects (canonical JSON of method/path/nonce/ts/body_sha256).
"""

from __future__ import annotations

import base64
import hashlib
import json
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from typing import Any
from uuid import UUID, uuid4

from seif.log.canonical import canonical_json_bytes
from seif.log.identity import Identity


DEFAULT_LOG_URL = "http://localhost:8000"


class LogClientError(Exception):
    """Base class for seif-log client errors."""


class LogHTTPError(LogClientError):
    def __init__(self, status: int, detail: str, body: dict[str, Any] | None = None):
        super().__init__(f"HTTP {status}: {detail}")
        self.status = status
        self.detail = detail
        self.body = body or {}


def _b64u(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _build_authorization(
    identity: Identity,
    method: str,
    path: str,
    body_bytes: bytes,
    nonce: str,
    ts: str,
) -> str:
    body_sha256_hex = hashlib.sha256(body_bytes).hexdigest()
    message = canonical_json_bytes({
        "method": method,
        "path": path,
        "nonce": nonce,
        "ts": ts,
        "body_sha256": body_sha256_hex,
    })
    sig = identity.sign(message)
    return (
        f"SEIF-Ed25519 sig={_b64u(sig)} pubkey={_b64u(identity.pubkey_bytes)} "
        f"nonce={nonce} ts={ts}"
    )


try:
    from importlib.metadata import PackageNotFoundError, version as _pkg_version
    try:
        _SEIF_CLI_VERSION = _pkg_version("seif-cli")
    except PackageNotFoundError:
        _SEIF_CLI_VERSION = "unknown"
except Exception:
    _SEIF_CLI_VERSION = "unknown"

USER_AGENT = f"seif-cli/{_SEIF_CLI_VERSION}"


def _request(
    log_url: str,
    method: str,
    path: str,
    body_bytes: bytes,
    headers: dict[str, str],
    timeout: float = 10.0,
) -> dict[str, Any]:
    # Explicit User-Agent: Cloudflare-fronted deploys reject the urllib default
    # ("Python-urllib/3.x") with 403 via WAF / Bot Fight Mode; identifying as
    # seif-cli passes those rules and is also more useful for log analysis.
    url = log_url.rstrip("/") + path
    req = urllib.request.Request(
        url,
        data=body_bytes if method == "POST" else None,
        method=method,
        headers={
            **headers,
            "Content-Type": "application/json",
            "User-Agent": USER_AGENT,
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read())
    except urllib.error.HTTPError as e:
        try:
            body = json.loads(e.read())
            detail = body.get("detail", "unknown")
        except Exception:
            body = {}
            detail = e.reason or "unknown"
        raise LogHTTPError(e.code, detail, body) from None
    except urllib.error.URLError as e:
        raise LogClientError(f"connection to {url} failed: {e.reason}") from None


def submit_entry(
    identity: Identity,
    *,
    entry_type: str,
    classification_ceil: str,
    primary_content_sha256_hex: str | None = None,
    workspace_fingerprint: str | None = None,
    body_storage: str = "inline",
    body_ref: str | None = None,
    api_version: str = "1",
    client_nonce: UUID | None = None,
    log_url: str = DEFAULT_LOG_URL,
    timeout: float = 10.0,
) -> dict[str, Any]:
    """POST /v1/entries with SEIF-Ed25519 auth. Returns the server response dict."""
    payload = {
        "entry_type": entry_type,
        "api_version": api_version,
        "workspace_fingerprint": workspace_fingerprint,
        "classification_ceil": classification_ceil,
        "primary_content_sha256": primary_content_sha256_hex,
        "body_storage": body_storage,
        "body_ref": body_ref,
        "client_nonce": str(client_nonce or uuid4()),
    }
    body_bytes = json.dumps(payload).encode("utf-8")

    nonce = str(uuid4())
    ts = _now_iso()
    auth = _build_authorization(identity, "POST", "/v1/entries", body_bytes, nonce, ts)

    return _request(
        log_url,
        "POST",
        "/v1/entries",
        body_bytes,
        {"Authorization": auth},
        timeout=timeout,
    )


def verify_entry(
    identity: Identity,
    entry_id: str,
    *,
    log_url: str = DEFAULT_LOG_URL,
    timeout: float = 10.0,
) -> dict[str, Any]:
    """GET /v1/entries/{entry_id} with SEIF-Ed25519 auth.

    Returns the entry as the server stored it. Caller can compare
    `canonical_sha256` to a locally recomputed digest to verify the envelope.
    """
    nonce = str(uuid4())
    ts = _now_iso()
    path = f"/v1/entries/{entry_id}"
    auth = _build_authorization(identity, "GET", path, b"", nonce, ts)

    return _request(
        log_url,
        "GET",
        path,
        b"",
        {"Authorization": auth},
        timeout=timeout,
    )


def submit_file(
    identity: Identity,
    file_path: str,
    *,
    entry_type: str = "artifact.file",
    classification_ceil: str = "INTERNAL",
    workspace_fingerprint: str | None = None,
    log_url: str = DEFAULT_LOG_URL,
    timeout: float = 10.0,
) -> dict[str, Any]:
    """Convenience wrapper: SHA-256 a file's bytes, submit attestation."""
    from pathlib import Path
    raw = Path(file_path).read_bytes()
    digest_hex = hashlib.sha256(raw).hexdigest()
    return submit_entry(
        identity,
        entry_type=entry_type,
        classification_ceil=classification_ceil,
        primary_content_sha256_hex=digest_hex,
        workspace_fingerprint=workspace_fingerprint,
        log_url=log_url,
        timeout=timeout,
    )


def list_entries(
    identity: Identity,
    *,
    after_id: str | None = None,
    limit: int = 20,
    workspace_fingerprint: str | None = None,
    log_url: str = DEFAULT_LOG_URL,
    timeout: float = 10.0,
) -> dict[str, Any]:
    """GET /v1/entries (D4) — tenant-scoped cursor-paginated list.

    Returns server response: {entries: [...], next_cursor, has_more}.
    Server sorts by per-tenant `sequence` ascending; pass the previous
    response's `next_cursor` as `after_id` to fetch the next page. Server
    enforces 1 ≤ limit ≤ 200.

    The Ed25519 signature covers the bare path `/v1/entries` (server uses
    request.url.path which excludes the query string), matching how D3
    verify_entry signs `/v1/entries/{id}`.
    """
    query: dict[str, str] = {}
    if after_id is not None:
        query["after_id"] = after_id
    if limit != 20:
        query["limit"] = str(limit)
    if workspace_fingerprint is not None:
        query["workspace_fingerprint"] = workspace_fingerprint

    nonce = str(uuid4())
    ts = _now_iso()
    auth = _build_authorization(identity, "GET", "/v1/entries", b"", nonce, ts)

    suffix = f"?{urllib.parse.urlencode(query)}" if query else ""
    return _request(
        log_url,
        "GET",
        f"/v1/entries{suffix}",
        b"",
        {"Authorization": auth},
        timeout=timeout,
    )
