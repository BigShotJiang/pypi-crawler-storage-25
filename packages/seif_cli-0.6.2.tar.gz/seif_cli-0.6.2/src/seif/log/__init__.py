"""seif --log-submit / --log-verify — client for the seif-log transparency log.

Workspace-native Ed25519 identity (auto-generated on first submit) signs each
attestation request to the seif-log API. The remote service auto-bootstraps a
'personal'-plan tenant on first signed submit; subsequent submits with the
same pubkey land under the same tenant.
"""
