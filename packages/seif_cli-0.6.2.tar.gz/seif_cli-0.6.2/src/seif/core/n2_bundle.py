"""SEIF-N2-BUNDLE-v1 — weekly N2 (nucleus-of-nucleus) signing tier-3 bundle.

s60 PR5 (rank 3). Owner-decided at SEED-s60 q3: aggregate weekly bundles
rather than per-cycle signatures. Rationale: amendment-chain means
individual SEALs already have OTS stamps for proof-of-time; N2 adds
proof-of-author across a bundle, without multiplying key usage.

Shape (canonical):

    {
        "protocol": "SEIF-N2-BUNDLE-v1",
        "bundle_id": "N2-BUNDLE-WYYYY-Wnn",
        "iso_week": {"year", "week", "starts_at", "ends_at"},
        "issued_at": ISO-8601 UTC,
        "issued_by": str (canonical actor, like cycle_reseal._default_actor()),
        "kernel_anchor": {"canonical_hash", "key_fingerprint"} (from RESONANCE at bundle-time),
        "cycles": [
            {
                "slug", "cycle_id", "sealed_at", "sealed_path",
                "sha256", "re_seal_history_length",
                "re_seal_last_sha256",  (optional, sha256 of last entry if any)
                "ots_present"
            }, ...
        ],
        "seeds": [
            {
                "seed_id", "issued_at", "path", "sha256",
                "consumed",   (sibling .consumed_at file present?)
                "ots_present"
            }, ...
        ],
        "content_signature": {
            "algorithm": "Ed25519",
            "signed_hash": base64,
            "signed_at": ISO,
            "key_fingerprint": <SHA-256[:16] of pubkey>,
            "public_key_base64_at_signing": base64 raw pubkey,
            "canonical_hash_method": "sha256_of_canonical_json_excluding_content_signature",
            "canonical_hash": <hex>
        }
    }

Storage: workspace/.seif/n2/N2-BUNDLE-WYYYY-Wnn.json (per host-vs-workspace
storage decision — bundle is project-shared evidence, not host state).
Re-emit of an existing week writes ``.json.v2`` rather than overwriting.

Verification (verify_bundle):
    Returns dict with status in:
      valid | signature_invalid | body_tampered |
      cycle_drift | seed_drift | kernel_rotated | partial
    Plus structured findings about which cycles/seeds drifted.

Late amendment to a bundled cycle is reported as ``cycle_drift:
post_bundle_amendment`` (informational, not integrity failure): if the
recorded ``re_seal_history_length`` differs from current AND the recorded
``re_seal_last_sha256`` is not in the current chain, that's drift.

Per A22 (forward_security): emitting requires the Owner private key.
Verification works on any host with the public key.
"""

from __future__ import annotations

import base64
import hashlib
import json
import re
import socket
import os
from datetime import datetime, timezone, timedelta, date
from pathlib import Path
from typing import Optional, Union

from seif.core.signing import (
    _private_key_path,
    get_public_key_base64,
    get_public_key_fingerprint,
)


N2_BUNDLE_PROTOCOL = "SEIF-N2-BUNDLE-v1"
CONTENT_SIGNATURE_FIELD = "content_signature"
BUNDLE_DIRNAME = "n2"
SEED_FILENAME_RE = re.compile(r"^SEED-s\d+-\d{4}-\d{2}-\d{2}.*\.json$")


# ── Helpers ───────────────────────────────────────────────────────


def _now_iso_utc() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _default_actor() -> str:
    """Mirror cycle_reseal._default_actor() shape."""
    parts: list[str] = []
    wrapper = os.environ.get("SEIF_WRAPPER")
    if wrapper:
        parts.append(wrapper)
    fp = os.environ.get("SEIF_HOST_FINGERPRINT") or os.environ.get("SEIF_HOST_FP")
    if fp:
        parts.append(f"fp={fp[:16]}")
    try:
        parts.append(f"host={socket.gethostname()}")
    except Exception:
        pass
    return " / ".join(parts) if parts else "unknown"


def _canonical_json_bytes(doc: dict) -> bytes:
    """Deterministic JSON serialization minus content_signature (top-level for bundles)."""
    clone = json.loads(json.dumps(doc))
    clone.pop(CONTENT_SIGNATURE_FIELD, None)
    return json.dumps(clone, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def _canonical_hash(doc: dict) -> str:
    return hashlib.sha256(_canonical_json_bytes(doc)).hexdigest()


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _resolve_workspace(workspace: Optional[Union[Path, str]]) -> Path:
    ws = Path(workspace) if workspace else Path.cwd()
    ws = ws.resolve()
    if not (ws / ".seif").is_dir():
        raise ValueError(
            f"workspace {ws} has no .seif/ — run `seif --init` there first"
        )
    return ws


def _parse_iso_week(week_str: Optional[str]) -> tuple[int, int]:
    """Parse 'WYYYY-Wnn' → (year, week). If None, use current ISO week."""
    if not week_str:
        today = datetime.now(timezone.utc).date()
        iso = today.isocalendar()
        return (iso.year, iso.week)
    m = re.fullmatch(r"W?(\d{4})-W(\d{1,2})", week_str.strip())
    if not m:
        raise ValueError(
            f"--week must look like 'W2026-W18' (got {week_str!r}); "
            "format is W<year>-W<week-of-year>"
        )
    return (int(m.group(1)), int(m.group(2)))


def _iso_week_bounds(year: int, week: int) -> tuple[datetime, datetime]:
    """Return [starts_at, ends_at) for the given ISO week, both UTC datetimes."""
    monday = date.fromisocalendar(year, week, 1)
    starts = datetime(monday.year, monday.month, monday.day, 0, 0, 0, tzinfo=timezone.utc)
    ends = starts + timedelta(days=7)
    return starts, ends


def _parse_iso_dt(s: str) -> Optional[datetime]:
    """Tolerant ISO-8601 parser. Returns None if unparseable."""
    if not isinstance(s, str) or not s:
        return None
    s2 = s.strip()
    if s2.endswith("Z"):
        s2 = s2[:-1] + "+00:00"
    try:
        dt = datetime.fromisoformat(s2)
    except ValueError:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt


def _read_kernel_anchor(workspace: Path) -> dict:
    """Read the workspace RESONANCE.json and extract canonical_hash + key_fingerprint.

    RESONANCE.json is at <workspace>/RESONANCE.json by convention. If missing
    or unreadable, returns {"canonical_hash": "", "key_fingerprint": ""}.
    """
    res_path = workspace / "RESONANCE.json"
    if not res_path.is_file():
        return {"canonical_hash": "", "key_fingerprint": ""}
    try:
        doc = json.loads(res_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {"canonical_hash": "", "key_fingerprint": ""}
    ci = doc.get("cryptographic_identity", {})
    sig = ci.get("content_signature", {}) if isinstance(ci, dict) else {}
    return {
        "canonical_hash": sig.get("canonical_hash", "") or "",
        "key_fingerprint": sig.get("key_fingerprint", "") or ci.get("key_fingerprint", "") or "",
    }


# ── Aggregation ───────────────────────────────────────────────────


def _collect_cycles(workspace: Path, starts: datetime, ends: datetime) -> list[dict]:
    """Find every *-SEALED.seif whose sealed_at lies in [starts, ends)."""
    cycles_dir = workspace / ".seif" / "cycles"
    out: list[dict] = []
    if not cycles_dir.is_dir():
        return out
    for path in sorted(cycles_dir.glob("*-SEALED.seif")):
        try:
            doc = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        sealed_at = _parse_iso_dt(doc.get("sealed_at", ""))
        if sealed_at is None:
            continue
        if not (starts <= sealed_at < ends):
            continue
        slug = path.name[: -len("-SEALED.seif")]
        history = doc.get("re_seal_history") or []
        if not isinstance(history, list):
            history = []
        last_sha = ""
        if history:
            last_sha = hashlib.sha256(
                json.dumps(history[-1], sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
            ).hexdigest()
        ots_path = path.with_name(path.name + ".ots")
        out.append({
            "slug": slug,
            "cycle_id": doc.get("cycle_id") or doc.get("module_id") or slug,
            "sealed_at": doc.get("sealed_at"),
            "sealed_path": str(path.relative_to(workspace)),
            "sha256": _sha256_file(path),
            "re_seal_history_length": len(history),
            "re_seal_last_sha256": last_sha,
            "ots_present": ots_path.is_file(),
        })
    return out


def _collect_seeds(workspace: Path, starts: datetime, ends: datetime) -> list[dict]:
    """Find every SEED-s*-YYYY-MM-DD*.json whose issued_at lies in [starts, ends)."""
    seeds_dir = workspace / ".seif" / "seeds"
    out: list[dict] = []
    if not seeds_dir.is_dir():
        return out
    for path in sorted(seeds_dir.iterdir()):
        if not path.is_file() or not SEED_FILENAME_RE.match(path.name):
            continue
        try:
            doc = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        issued_at = _parse_iso_dt(doc.get("issued_at", ""))
        if issued_at is None:
            continue
        if not (starts <= issued_at < ends):
            continue
        consumed_marker = path.with_name(path.name + ".consumed_at")
        ots_path = path.with_name(path.name + ".ots")
        out.append({
            "seed_id": doc.get("seed_id") or path.stem,
            "issued_at": doc.get("issued_at"),
            "path": str(path.relative_to(workspace)),
            "sha256": _sha256_file(path),
            "consumed": consumed_marker.is_file(),
            "ots_present": ots_path.is_file(),
        })
    return out


# ── Build / sign / write ──────────────────────────────────────────


def build_bundle(
    workspace: Optional[Union[Path, str]] = None,
    *,
    week: Optional[str] = None,
    actor: Optional[str] = None,
) -> dict:
    """Aggregate SEALED cycles + seeds for one ISO week into an unsigned bundle dict."""
    ws = _resolve_workspace(workspace)
    year, week_num = _parse_iso_week(week)
    starts, ends = _iso_week_bounds(year, week_num)
    cycles = _collect_cycles(ws, starts, ends)
    seeds = _collect_seeds(ws, starts, ends)

    bundle_id = f"N2-BUNDLE-W{year}-W{week_num:02d}"
    bundle = {
        "protocol": N2_BUNDLE_PROTOCOL,
        "bundle_id": bundle_id,
        "iso_week": {
            "year": year,
            "week": week_num,
            "starts_at": starts.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "ends_at": ends.strftime("%Y-%m-%dT%H:%M:%SZ"),
        },
        "issued_at": _now_iso_utc(),
        "issued_by": actor or _default_actor(),
        "kernel_anchor": _read_kernel_anchor(ws),
        "cycles": cycles,
        "seeds": seeds,
    }
    return bundle


def _sign_bundle_dict(bundle: dict) -> dict:
    """Add canonical_hash + content_signature in place. Requires Owner private key."""
    from cryptography.hazmat.primitives.serialization import load_pem_private_key

    priv_path = _private_key_path()
    if not priv_path.exists():
        raise FileNotFoundError(
            f"No private key at {priv_path}. Per A22, signing must run on the "
            "Owner machine (Air). Run from there, not from a peer."
        )

    canonical_hash = _canonical_hash(bundle)

    private_key = load_pem_private_key(priv_path.read_bytes(), None)
    signature_bytes = private_key.sign(canonical_hash.encode())

    bundle[CONTENT_SIGNATURE_FIELD] = {
        "algorithm": "Ed25519",
        "signed_hash": base64.b64encode(signature_bytes).decode(),
        "signed_at": _now_iso_utc(),
        "key_fingerprint": get_public_key_fingerprint(),
        "public_key_base64_at_signing": get_public_key_base64(),
        "canonical_hash_method": "sha256_of_canonical_json_excluding_content_signature",
        "canonical_hash": canonical_hash,
    }
    return bundle


def _bundle_storage_path(workspace: Path, bundle_id: str) -> Path:
    """First emission: <ws>/.seif/n2/<bundle_id>.json
    Re-emission:    <ws>/.seif/n2/<bundle_id>.json.vN  (v2, v3, ...)
    """
    n2_dir = workspace / ".seif" / BUNDLE_DIRNAME
    base = n2_dir / f"{bundle_id}.json"
    if not base.exists():
        return base
    n = 2
    while True:
        candidate = n2_dir / f"{bundle_id}.json.v{n}"
        if not candidate.exists():
            return candidate
        n += 1


def emit_bundle(
    workspace: Optional[Union[Path, str]] = None,
    *,
    week: Optional[str] = None,
    actor: Optional[str] = None,
    stamp_ots: bool = True,
) -> dict:
    """Build, sign, and persist a weekly N2 bundle.

    Returns a dict: {status, bundle_path, bundle_id, cycle_count, seed_count, ots: {...}}.
    Refuses (status='error') if the week is empty (0 SEALED + 0 seeds).
    Raises FileNotFoundError if the Owner private key is missing (per A22).
    """
    ws = _resolve_workspace(workspace)
    bundle = build_bundle(ws, week=week, actor=actor)

    if not bundle["cycles"] and not bundle["seeds"]:
        return {
            "status": "error",
            "message": (
                f"Empty week: bundle {bundle['bundle_id']} has 0 SEALED cycles "
                "and 0 seeds. Refusing to emit. Pass --week WYYYY-Wnn to target a "
                "different week, or wait until at least one artifact is produced."
            ),
        }

    _sign_bundle_dict(bundle)

    n2_dir = ws / ".seif" / BUNDLE_DIRNAME
    n2_dir.mkdir(parents=True, exist_ok=True)
    out_path = _bundle_storage_path(ws, bundle["bundle_id"])
    out_path.write_text(json.dumps(bundle, indent=2, ensure_ascii=False), encoding="utf-8")

    ots_result: Optional[dict] = None
    if stamp_ots:
        try:
            from seif.core.timestamping import stamp as _stamp
            ok, msg = _stamp(out_path)
            ots_result = {"stamped": bool(ok), "message": msg}
        except Exception as e:
            ots_result = {"stamped": False, "message": f"OTS error (non-fatal): {e}"}

    return {
        "status": "emitted",
        "bundle_path": str(out_path),
        "bundle_id": bundle["bundle_id"],
        "cycle_count": len(bundle["cycles"]),
        "seed_count": len(bundle["seeds"]),
        "is_re_emit": out_path.name != f"{bundle['bundle_id']}.json",
        "ots": ots_result,
    }


# ── Verification ──────────────────────────────────────────────────


def verify_bundle(
    bundle_path: Union[Path, str],
    *,
    workspace: Optional[Union[Path, str]] = None,
    strict: bool = False,
) -> dict:
    """Verify a previously-emitted N2 bundle.

    Returns a structured dict:

        {
            "status": valid | signature_invalid | body_tampered |
                      cycle_drift | seed_drift | kernel_rotated | partial,
            "valid": bool,        (true only when status == 'valid')
            "signature_valid": bool,
            "body_canonical_hash_match": bool,
            "kernel_anchor_match": bool,   (vs current RESONANCE)
            "cycle_findings": [ {slug, kind, ...}, ... ],
            "seed_findings":  [ {seed_id, kind, ...}, ... ],
            "ots": {present, message},
            "reason": str,
        }

    `kind` values inside findings:
      cycle_missing, cycle_sha_mismatch, post_bundle_amendment, seed_missing,
      seed_sha_mismatch.
    """
    from cryptography.exceptions import InvalidSignature
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

    bp = Path(bundle_path).resolve()
    if not bp.is_file():
        return {
            "status": "body_tampered",
            "valid": False,
            "reason": f"bundle file not found: {bp}",
            "signature_valid": False,
            "body_canonical_hash_match": False,
            "kernel_anchor_match": False,
            "cycle_findings": [],
            "seed_findings": [],
            "ots": {"present": False, "message": ""},
        }

    try:
        bundle = json.loads(bp.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        return {
            "status": "body_tampered",
            "valid": False,
            "reason": f"bundle JSON invalid: {e}",
            "signature_valid": False,
            "body_canonical_hash_match": False,
            "kernel_anchor_match": False,
            "cycle_findings": [],
            "seed_findings": [],
            "ots": {"present": False, "message": ""},
        }

    sig = bundle.get(CONTENT_SIGNATURE_FIELD) if isinstance(bundle, dict) else None

    # 1. Recompute canonical hash → catches body tamper.
    recomputed = _canonical_hash(bundle)
    recorded = (sig or {}).get("canonical_hash", "")
    body_match = bool(recorded) and (recomputed == recorded)

    if not sig:
        return {
            "status": "signature_invalid",
            "valid": False,
            "reason": "No content_signature found",
            "signature_valid": False,
            "body_canonical_hash_match": body_match,
            "kernel_anchor_match": False,
            "cycle_findings": [],
            "seed_findings": [],
            "ots": {"present": False, "message": ""},
        }

    if not body_match:
        return {
            "status": "body_tampered",
            "valid": False,
            "reason": (
                f"body tampered after signing — canonical_hash mismatch "
                f"(recorded={recorded[:12]}…, recomputed={recomputed[:12]}…)"
            ),
            "signature_valid": False,
            "body_canonical_hash_match": False,
            "kernel_anchor_match": False,
            "cycle_findings": [],
            "seed_findings": [],
            "ots": {"present": False, "message": ""},
        }

    # 2. Verify Ed25519 signature.
    pub_b64 = sig.get("public_key_base64_at_signing", "")
    signature_valid = False
    sig_reason = ""
    if not pub_b64:
        sig_reason = "no public key embedded in signature"
    else:
        try:
            public_key = Ed25519PublicKey.from_public_bytes(base64.b64decode(pub_b64))
            public_key.verify(base64.b64decode(sig["signed_hash"]), recorded.encode())
            signature_valid = True
            sig_reason = "Ed25519 signature valid"
        except InvalidSignature:
            sig_reason = "INVALID Ed25519 signature"
        except Exception as e:
            sig_reason = f"signature verify error: {e}"

    if not signature_valid:
        return {
            "status": "signature_invalid",
            "valid": False,
            "reason": sig_reason,
            "signature_valid": False,
            "body_canonical_hash_match": True,
            "kernel_anchor_match": False,
            "cycle_findings": [],
            "seed_findings": [],
            "ots": {"present": False, "message": ""},
        }

    # 3. Resolve workspace (default = bundle parent's workspace root).
    ws: Optional[Path] = None
    try:
        if workspace is not None:
            ws = _resolve_workspace(workspace)
        else:
            # bundle lives at <ws>/.seif/n2/<file>.json
            candidate = bp.parent.parent.parent
            if (candidate / ".seif").is_dir():
                ws = candidate
    except ValueError:
        ws = None

    # 4. Re-hash each recorded cycle and seed; collect findings.
    cycle_findings: list[dict] = []
    seed_findings: list[dict] = []

    if ws is not None:
        for c in bundle.get("cycles", []):
            rel = c.get("sealed_path", "")
            target = ws / rel if rel else None
            if target is None or not target.is_file():
                cycle_findings.append({
                    "slug": c.get("slug", ""),
                    "kind": "cycle_missing",
                    "sealed_path": rel,
                })
                continue
            cur_sha = _sha256_file(target)
            recorded_sha = c.get("sha256", "")
            if cur_sha != recorded_sha:
                # Distinguish post-bundle amendment from arbitrary tamper.
                try:
                    cur_doc = json.loads(target.read_text(encoding="utf-8"))
                except (OSError, json.JSONDecodeError):
                    cur_doc = {}
                cur_history = cur_doc.get("re_seal_history") or []
                cur_history = cur_history if isinstance(cur_history, list) else []
                recorded_len = c.get("re_seal_history_length", 0)
                recorded_last_sha = c.get("re_seal_last_sha256", "") or ""
                # Amendment requires the chain to have GROWN (strict >, not >=).
                # Equal-length-but-different-sha means tamper, not amendment.
                if len(cur_history) > recorded_len:
                    if recorded_len == 0:
                        # First-ever amendment: bundle recorded an empty chain;
                        # any growth is a legitimate post-bundle re-seal.
                        cycle_findings.append({
                            "slug": c.get("slug", ""),
                            "kind": "post_bundle_amendment",
                            "recorded_history_length": recorded_len,
                            "current_history_length": len(cur_history),
                        })
                        continue
                    # Otherwise: prefix must end with recorded_last_sha to be a
                    # proper extension of the chain we observed at bundle-time.
                    prefix = cur_history[:recorded_len]
                    last_in_prefix = prefix[-1] if prefix else None
                    last_sha_in_prefix = ""
                    if last_in_prefix is not None:
                        last_sha_in_prefix = hashlib.sha256(
                            json.dumps(last_in_prefix, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
                        ).hexdigest()
                    if recorded_last_sha and last_sha_in_prefix == recorded_last_sha:
                        cycle_findings.append({
                            "slug": c.get("slug", ""),
                            "kind": "post_bundle_amendment",
                            "recorded_history_length": recorded_len,
                            "current_history_length": len(cur_history),
                        })
                        continue
                cycle_findings.append({
                    "slug": c.get("slug", ""),
                    "kind": "cycle_sha_mismatch",
                    "recorded_sha256": recorded_sha,
                    "current_sha256": cur_sha,
                })

        for s in bundle.get("seeds", []):
            rel = s.get("path", "")
            target = ws / rel if rel else None
            if target is None or not target.is_file():
                seed_findings.append({
                    "seed_id": s.get("seed_id", ""),
                    "kind": "seed_missing",
                    "path": rel,
                })
                continue
            cur_sha = _sha256_file(target)
            recorded_sha = s.get("sha256", "")
            if cur_sha != recorded_sha:
                seed_findings.append({
                    "seed_id": s.get("seed_id", ""),
                    "kind": "seed_sha_mismatch",
                    "recorded_sha256": recorded_sha,
                    "current_sha256": cur_sha,
                })

    # 5. Kernel rotation check (warn unless strict).
    kernel_match = True
    if ws is not None:
        cur_anchor = _read_kernel_anchor(ws)
        rec_anchor = bundle.get("kernel_anchor", {})
        if cur_anchor.get("canonical_hash") and rec_anchor.get("canonical_hash"):
            kernel_match = (
                cur_anchor.get("canonical_hash") == rec_anchor.get("canonical_hash")
                and cur_anchor.get("key_fingerprint") == rec_anchor.get("key_fingerprint")
            )

    # 6. Best-effort OTS verify (warn-only).
    ots_present = bp.with_name(bp.name + ".ots").is_file()
    ots_message = ""
    if ots_present:
        try:
            from seif.core.timestamping import verify as _ots_verify
            ok, msg = _ots_verify(bp)
            ots_message = msg if isinstance(msg, str) else str(msg)
            if not ok:
                ots_message = f"(warn) OTS verify did not succeed: {ots_message}"
        except Exception as e:
            ots_message = f"(warn) OTS verify error: {e}"

    # 7. Collapse to top-level status.
    has_cycle_drift = any(f["kind"] in ("cycle_missing", "cycle_sha_mismatch") for f in cycle_findings)
    has_amendment = any(f["kind"] == "post_bundle_amendment" for f in cycle_findings)
    has_seed_drift = bool(seed_findings)

    if has_cycle_drift:
        status = "cycle_drift"
        valid = False
        reason = "one or more bundled cycles drifted (missing or sha256 mismatch)"
    elif has_seed_drift:
        status = "seed_drift"
        valid = False
        reason = "one or more bundled seeds drifted (missing or sha256 mismatch)"
    elif not kernel_match:
        if strict:
            status = "kernel_rotated"
            valid = False
        else:
            status = "kernel_rotated"
            valid = True
        reason = "kernel anchor differs from current RESONANCE (kernel rotated since bundle)"
    elif has_amendment:
        # post_bundle_amendment is informational, NOT integrity failure.
        status = "partial"
        valid = True
        reason = "valid; post-bundle amendments observed on bundled cycles (informational)"
    else:
        status = "valid"
        valid = True
        reason = "signature valid; body untampered; all recorded artifacts intact"

    return {
        "status": status,
        "valid": valid,
        "reason": reason,
        "signature_valid": True,
        "body_canonical_hash_match": True,
        "kernel_anchor_match": kernel_match,
        "cycle_findings": cycle_findings,
        "seed_findings": seed_findings,
        "ots": {"present": ots_present, "message": ots_message},
    }
