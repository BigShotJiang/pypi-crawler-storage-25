"""
RESONANCE.json signing — the canonical, top-level proof of authorship.

Distinct from sign_module (which expects top-level integrity_hash or fingerprint.value):
RESONANCE.json carries integrity_hash nested under .validation, and adds a top-level
content_signature block under .cryptographic_identity.

Field layout after sign_resonance():
  .cryptographic_identity.content_signature = {
      "algorithm": "Ed25519",
      "signed_hash": "<base64>",
      "signed_at": "<ISO timestamp>",
      "key_fingerprint": "<SHA-256[:16] of pubkey>",
      "canonical_hash_method": "sha256_of_canonical_json_excluding_content_signature",
      "canonical_hash": "<sha256 hex>"
  }

The signed value is sha256 over the canonical JSON of the document with
.cryptographic_identity.content_signature removed (so re-signing the same content
twice yields the same canonical hash + same signature only if both are Ed25519
deterministic on the same private key, which they are).

Per A22 (forward_security): only the Owner machine holds the private key.
verify_resonance_signature() works anywhere with the public key.
"""

from __future__ import annotations

import base64
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

from seif.core.signing import (
    _private_key_path,
    get_public_key_base64,
    get_public_key_fingerprint,
)


CONTENT_SIGNATURE_FIELD = "content_signature"
CRYPTO_IDENTITY_FIELD = "cryptographic_identity"


def _canonical_json_bytes(doc: dict) -> bytes:
    """Deterministic JSON serialization for hashing.

    Drops cryptographic_identity.content_signature if present (you sign over the
    document MINUS its own signature). Sorts keys, no whitespace variance.
    """
    clone = json.loads(json.dumps(doc))
    ci = clone.get(CRYPTO_IDENTITY_FIELD, {})
    if isinstance(ci, dict):
        ci.pop(CONTENT_SIGNATURE_FIELD, None)
    return json.dumps(clone, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def _canonical_hash(doc: dict) -> str:
    return hashlib.sha256(_canonical_json_bytes(doc)).hexdigest()


def sign_resonance(resonance_path: Path) -> dict:
    """Sign RESONANCE.json with the Owner's Ed25519 private key.

    Mutates the file in place: adds/replaces .cryptographic_identity.content_signature.
    Returns the updated document dict.

    Raises:
        FileNotFoundError: if private key isn't present (run on non-Owner machine).
        ValueError: if RESONANCE.json lacks .cryptographic_identity.
    """
    from cryptography.hazmat.primitives.serialization import load_pem_private_key

    priv_path = _private_key_path()
    if not priv_path.exists():
        raise FileNotFoundError(
            f"No private key at {priv_path}. Per A22, signing must run on the "
            "Owner machine (Air). Run from there, not from a peer."
        )

    with open(resonance_path) as f:
        doc = json.load(f)

    if CRYPTO_IDENTITY_FIELD not in doc:
        raise ValueError(
            f"RESONANCE.json lacks '{CRYPTO_IDENTITY_FIELD}'; not a signable shape."
        )

    canonical_hash = _canonical_hash(doc)

    private_key = load_pem_private_key(priv_path.read_bytes(), None)
    signature_bytes = private_key.sign(canonical_hash.encode())

    doc[CRYPTO_IDENTITY_FIELD][CONTENT_SIGNATURE_FIELD] = {
        "algorithm": "Ed25519",
        "signed_hash": base64.b64encode(signature_bytes).decode(),
        "signed_at": datetime.now(timezone.utc).isoformat(),
        "key_fingerprint": get_public_key_fingerprint(),
        "public_key_base64_at_signing": get_public_key_base64(),
        "canonical_hash_method": "sha256_of_canonical_json_excluding_content_signature",
        "canonical_hash": canonical_hash,
    }

    with open(resonance_path, "w") as f:
        json.dump(doc, f, indent=2, ensure_ascii=False)

    return doc


def verify_resonance_signature(resonance_path: Path) -> dict:
    """Verify the content_signature on RESONANCE.json.

    Returns: {"valid": bool, "reason": str, "key_fingerprint": str, "canonical_hash_match": bool}

    Verification steps:
      1. Recompute canonical_hash from current document (minus content_signature).
      2. Compare to canonical_hash recorded in content_signature → catches content tampering.
      3. Verify Ed25519 signature against the recorded canonical_hash → catches key forgery.

    Both checks must pass for valid=True.
    """
    from cryptography.exceptions import InvalidSignature
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

    with open(resonance_path) as f:
        doc = json.load(f)

    ci = doc.get(CRYPTO_IDENTITY_FIELD, {})
    sig = ci.get(CONTENT_SIGNATURE_FIELD) if isinstance(ci, dict) else None
    if not sig:
        return {
            "valid": False,
            "reason": "No content_signature found",
            "key_fingerprint": "",
            "canonical_hash_match": False,
        }

    recomputed_hash = _canonical_hash(doc)
    recorded_hash = sig.get("canonical_hash", "")
    hash_match = recomputed_hash == recorded_hash
    if not hash_match:
        return {
            "valid": False,
            "reason": (
                f"Content tampered after signing — canonical_hash mismatch "
                f"(recorded={recorded_hash[:12]}…, recomputed={recomputed_hash[:12]}…)"
            ),
            "key_fingerprint": sig.get("key_fingerprint", ""),
            "canonical_hash_match": False,
        }

    pub_b64 = sig.get("public_key_base64_at_signing") or ci.get("public_key_base64", "")
    if not pub_b64:
        return {
            "valid": False,
            "reason": "No public key available for verification",
            "key_fingerprint": sig.get("key_fingerprint", ""),
            "canonical_hash_match": True,
        }

    try:
        public_key = Ed25519PublicKey.from_public_bytes(base64.b64decode(pub_b64))
        public_key.verify(base64.b64decode(sig["signed_hash"]), recomputed_hash.encode())
        return {
            "valid": True,
            "reason": "Signature valid; canonical_hash matches; key matches",
            "key_fingerprint": sig.get("key_fingerprint", ""),
            "canonical_hash_match": True,
        }
    except InvalidSignature:
        return {
            "valid": False,
            "reason": "INVALID — Ed25519 signature does not match (key forgery or sig corruption)",
            "key_fingerprint": sig.get("key_fingerprint", ""),
            "canonical_hash_match": True,
        }
    except Exception as e:
        return {
            "valid": False,
            "reason": f"Verification error: {e}",
            "key_fingerprint": sig.get("key_fingerprint", ""),
            "canonical_hash_match": True,
        }
