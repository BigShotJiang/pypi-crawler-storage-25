"""
SEIF Integrity Orchestrator — fingerprint, sign, stamp as one atomic chain.

Resolves admin-docs cold-AI Gaps 22, 23, 24, 25, 39, 40 in one architectural
change. Pre-orchestrator, the three integrity surfaces (--fingerprint-update,
--sign-all, --stamp-all) each invalidated the others — there was no sequence
that left a module simultaneously VALID under all three. This module
establishes a single deterministic order:

    fingerprint(scope=v2) → sign(commits scope_version) → write → stamp(force)

After update_integrity returns success, all three verifications pass:
    verify_fingerprint  → VALID
    verify_signature    → VALID
    verify_stamp_status → VALID or PENDING (awaiting Bitcoin)

The v2 fingerprint scope EXCLUDES the signature field (unlike v1). That is
the load-bearing design: signing after fingerprinting must not change the
canonical JSON, otherwise the chain is non-orchestratable.

verify_integrity returns a JoinedVerdict aggregating all three checks. The
CLI dispatches its exit code from the joined status (non-zero on HALF_VALID
and INVALID, 0 only on full VALID).
"""

from __future__ import annotations

import json
import os
import tempfile
from dataclasses import dataclass, asdict, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from seif.core.fingerprint import (
    SCOPE_V1, SCOPE_V2, calculate_fingerprint, verify_fingerprint,
)
from seif.core.signing import sign_module, verify_module, SIGNATURE_FIELD
from seif.core.timestamping import (
    STAMP_VALID, STAMP_PENDING, STAMP_MISSING, STAMP_INVALID, STAMP_OTS_ABSENT,
    stamp, verify_stamp_status,
)


# Joined verdict states.
INTEGRITY_VALID = "VALID"            # all three VALID
INTEGRITY_PENDING = "PENDING"        # fingerprint+signature VALID, stamp PENDING
INTEGRITY_HALF_VALID = "HALF_VALID"  # at least one missing/stale, none invalid
INTEGRITY_INVALID = "INVALID"        # at least one INVALID (active mismatch)


@dataclass
class IntegrityReport:
    """Result of update_integrity. Each surface report carries its own status
    string + a human-readable message. fingerprint_value is the new hash."""
    file: str
    scope_version: str
    fingerprint_value: str
    fingerprint_status: str
    signature_status: str
    stamp_status: str
    stamp_message: str = ""
    skipped: list[str] = field(default_factory=list)
    written_at: str = ""

    def asdict(self) -> dict:
        return asdict(self)


@dataclass
class JoinedVerdict:
    """Result of verify_integrity. overall is one of INTEGRITY_* constants."""
    file: str
    fingerprint: str            # "VALID" / "INVALID" / "MISSING"
    signature: str              # "VALID" / "INVALID" / "MISSING"
    stamp: str                  # STAMP_* enum
    overall: str                # INTEGRITY_* enum
    fingerprint_scope: str = ""
    signature_key: str = ""
    stamp_message: str = ""

    def asdict(self) -> dict:
        return asdict(self)


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _atomic_write(path: Path, data: dict) -> None:
    """Write JSON atomically: temp in same directory, fsync, rename.

    Same-directory temp is required so the rename is on the same filesystem
    (POSIX rename is atomic only within one fs). Same-directory also means
    the temp file inherits the right ACLs for the destination.
    """
    path = Path(path)
    parent = path.parent
    parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp",
                                     dir=str(parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_name, path)
    except Exception:
        # Best-effort cleanup; the rename either happened or it didn't.
        try:
            os.unlink(tmp_name)
        except OSError:
            pass
        raise


def update_integrity(file_path: Path, skip_sign: bool = False,
                     skip_stamp: bool = False) -> IntegrityReport:
    """Run the deterministic integrity chain on a single .seif module.

    Order (always):
        1. Compute v2 fingerprint over (data minus fingerprint, signature,
           integrity_hash).
        2. Write fingerprint block (algorithm, value, scope=v2, calculated_at).
        3. Atomic-write file with the new fingerprint. Defer signing+stamp
           to subsequent steps so the file always has a coherent fingerprint
           on disk even if a later step fails.
        4. If not skip_sign: sign over fingerprint.value, add signature block
           with scope_version=v2, atomic-write again.
        5. If not skip_stamp: call stamp(force=True) on the final bytes.

    Returns IntegrityReport. Failures in steps 4-5 are recorded but do not
    raise — the caller decides what to do (the orchestrator's contract is
    "best-effort; report the truth").
    """
    file_path = Path(file_path).resolve()
    if not file_path.exists():
        raise FileNotFoundError(f"Module not found: {file_path}")

    skipped: list[str] = []

    with open(file_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    # Step 1+2: compute v2 fingerprint, write block.
    fp_value = calculate_fingerprint(data, scope=SCOPE_V2)
    data["fingerprint"] = {
        "algorithm": "sha256",
        "value": fp_value,
        "scope": SCOPE_V2,
        "calculated_at": "auto",
        "note": "Auto-calculated by integrity orchestrator (v2 scope)",
    }
    # Drop legacy integrity_hash so we don't ship a stale parallel field.
    # (calculate_fingerprint already excludes it from the hash.)
    data.pop("integrity_hash", None)

    # Step 3: atomic write with fingerprint.
    _atomic_write(file_path, data)

    # Step 4: sign (commits scope_version into signature block via sign_module).
    sig_status = "MISSING"
    if skip_sign:
        skipped.append("sign")
    else:
        try:
            sign_module(file_path)
            sig_status = "VALID"
        except FileNotFoundError as e:
            sig_status = f"MISSING ({e})"
            skipped.append("sign")
        except Exception as e:
            sig_status = f"FAILED ({e})"

    # Step 5: stamp (force=True; prior .ots is stale because file bytes changed).
    stamp_status = "MISSING"
    stamp_message = ""
    if skip_stamp:
        skipped.append("stamp")
    else:
        ok, msg = stamp(file_path, force=True)
        stamp_message = msg
        if ok:
            stamp_status = STAMP_PENDING if "Pending" in msg or "pending" in msg else STAMP_VALID
        else:
            stamp_status = "FAILED"

    return IntegrityReport(
        file=str(file_path),
        scope_version=SCOPE_V2,
        fingerprint_value=fp_value,
        fingerprint_status="VALID",
        signature_status=sig_status,
        stamp_status=stamp_status,
        stamp_message=stamp_message,
        skipped=skipped,
        written_at=_now_iso(),
    )


def verify_integrity(file_path: Path) -> JoinedVerdict:
    """Run all three verifications and return a structured JoinedVerdict.

    The overall status is computed by:
        - INVALID if any of fingerprint/signature/stamp is INVALID
        - HALF_VALID if any is MISSING (and none INVALID)
        - PENDING if stamp is PENDING (and others VALID)
        - VALID otherwise
    """
    file_path = Path(file_path).resolve()
    if not file_path.exists():
        raise FileNotFoundError(f"Module not found: {file_path}")

    with open(file_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    fp_block = data.get("fingerprint", {}) if isinstance(data.get("fingerprint"), dict) else {}
    fp_scope = fp_block.get("scope", SCOPE_V1)

    # Fingerprint check.
    if not fp_block.get("value"):
        fp_state = "MISSING"
    else:
        ok, _calc = verify_fingerprint(data)
        fp_state = "VALID" if ok else "INVALID"

    # Signature check.
    sig_block = data.get(SIGNATURE_FIELD)
    if not sig_block:
        sig_state = "MISSING"
        sig_key = ""
    else:
        sig_result = verify_module(file_path)
        sig_state = "VALID" if sig_result.get("valid") else "INVALID"
        sig_key = sig_result.get("key_fingerprint", "")

    # Stamp check.
    stamp_state, stamp_msg = verify_stamp_status(file_path)

    # Compute overall.
    states = (fp_state, sig_state, stamp_state)
    if "INVALID" in states:
        overall = INTEGRITY_INVALID
    elif STAMP_MISSING in states or "MISSING" in (fp_state, sig_state):
        overall = INTEGRITY_HALF_VALID
    elif stamp_state == STAMP_PENDING:
        overall = INTEGRITY_PENDING
    elif fp_state == "VALID" and sig_state == "VALID" and stamp_state in (STAMP_VALID, STAMP_OTS_ABSENT):
        # OTS_NOT_INSTALLED is treated as "we cannot say" — degrades to
        # HALF_VALID overall when the verifier lacks the binary, so the
        # operator knows their local environment cannot fully attest.
        overall = INTEGRITY_VALID if stamp_state == STAMP_VALID else INTEGRITY_HALF_VALID
    else:
        overall = INTEGRITY_HALF_VALID

    return JoinedVerdict(
        file=str(file_path),
        fingerprint=fp_state,
        signature=sig_state,
        stamp=stamp_state,
        overall=overall,
        fingerprint_scope=fp_scope,
        signature_key=sig_key,
        stamp_message=stamp_msg,
    )


def migrate_integrity(directory: Path, exclude_from: Optional[Path] = None,
                      skip_stamp: bool = False) -> list[IntegrityReport]:
    """Walk directory, run update_integrity on each .seif file.

    exclude_from: optional path to a text file with one path-or-glob per
    line. Matching files are skipped. Used to preserve evidence files
    (e.g. admin-docs snapshots that must NOT be re-fingerprinted).
    """
    directory = Path(directory).resolve()
    if not directory.exists():
        raise FileNotFoundError(f"Directory not found: {directory}")

    excludes: set[str] = set()
    if exclude_from:
        exclude_from = Path(exclude_from)
        if exclude_from.exists():
            for line in exclude_from.read_text(encoding="utf-8").splitlines():
                stripped = line.strip()
                if stripped and not stripped.startswith("#"):
                    excludes.add(stripped)

    reports: list[IntegrityReport] = []
    for seif_file in sorted(directory.rglob("*.seif")):
        rel = str(seif_file.relative_to(directory))
        absolute = str(seif_file)
        if rel in excludes or absolute in excludes:
            continue
        # Glob match against excludes — minimal: prefix match for now.
        if any(rel.startswith(e) for e in excludes if e.endswith("/")):
            continue
        try:
            report = update_integrity(seif_file, skip_stamp=skip_stamp)
        except Exception as e:
            report = IntegrityReport(
                file=str(seif_file),
                scope_version="",
                fingerprint_value="",
                fingerprint_status=f"FAILED ({e})",
                signature_status="SKIPPED",
                stamp_status="SKIPPED",
                stamp_message=str(e),
                skipped=["all"],
                written_at=_now_iso(),
            )
        reports.append(report)
    return reports
