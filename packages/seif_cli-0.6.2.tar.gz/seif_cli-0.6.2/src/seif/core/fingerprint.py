"""
SEIF Fingerprint Module

Calculates and verifies cryptographic fingerprints for SEIF modules.
Fingerprint = sha256 of JSON content excluding the fingerprint field itself.
This ensures tamper detection: any modification to content breaks the hash.
"""

import hashlib
import json
from typing import Optional


# Scope tags written into fingerprint.scope. The scope drives which fields
# are excluded from the canonical JSON used for hashing. v1 is the legacy
# behavior (excludes fingerprint + integrity_hash but NOT signature — this
# is the root of admin-docs Gap 24, mutual destruction). v2 also excludes
# signature so signing a freshly-fingerprinted module does NOT invalidate
# the fingerprint. New writes through the integrity orchestrator use v2.
SCOPE_V1 = "full_json_excluding_fingerprint"
SCOPE_V2 = "full_json_excluding_fingerprint_signature_integrity_hash"


def _canonical_json(data: dict, scope: str) -> str:
    """Produce the canonical JSON used for fingerprint hashing.

    Strips fields per scope. v1 keeps insertion order (legacy bug retained
    for backward compat). v2 uses sort_keys for cross-implementation
    determinism.
    """
    clean = data.copy()
    clean.pop("fingerprint", None)
    clean.pop("integrity_hash", None)
    if scope == SCOPE_V2:
        clean.pop("signature", None)
        return json.dumps(clean, separators=(",", ":"), sort_keys=True,
                          ensure_ascii=False)
    return json.dumps(clean, separators=(",", ":"), ensure_ascii=False)


def calculate_fingerprint(data: dict, algorithm: str = "sha256",
                          scope: str = SCOPE_V1) -> str:
    """
    Calculate fingerprint hash of SEIF data.

    Args:
        data: SEIF module or RESONANCE.json as dict
        algorithm: Hash algorithm (default: sha256)
        scope: SCOPE_V1 (legacy) or SCOPE_V2 (orchestrator). Defaults to V1
            so existing callers keep their behavior — only the integrity
            orchestrator passes V2 explicitly.

    Returns:
        Hex digest of the hash
    """
    json_str = _canonical_json(data, scope)

    if algorithm == "sha256":
        return hashlib.sha256(json_str.encode("utf-8")).hexdigest()
    elif algorithm == "sha512":
        return hashlib.sha512(json_str.encode("utf-8")).hexdigest()
    else:
        raise ValueError(f"Unsupported algorithm: {algorithm}")


def verify_fingerprint(data: dict, expected_hash: Optional[str] = None) -> tuple[bool, str]:
    """
    Verify fingerprint of SEIF data.

    Reads fingerprint.scope from the embedded block to dispatch v1/v2 hashing.
    Modules written before scope-aware hashing default to v1.

    Args:
        data: SEIF module or RESONANCE.json as dict
        expected_hash: Expected hash (if None, reads from fingerprint.value)

    Returns:
        (is_valid, calculated_hash)
    """
    fingerprint = data.get("fingerprint", {})
    expected = expected_hash or fingerprint.get("value", "")
    scope = fingerprint.get("scope", SCOPE_V1) if isinstance(fingerprint, dict) else SCOPE_V1
    if scope not in (SCOPE_V1, SCOPE_V2):
        scope = SCOPE_V1

    if not expected or expected == "<calculate_on_save>":
        return False, calculate_fingerprint(data, scope=scope)

    calculated = calculate_fingerprint(data, scope=scope)
    return calculated == expected, calculated


def add_fingerprint(data: dict, save: bool = True, filepath: Optional[str] = None) -> dict:
    """
    Add or update fingerprint to SEIF data and optionally save to file.
    
    Args:
        data: SEIF module or RESONANCE.json as dict
        save: Whether to save to file
        filepath: Path to file (required if save=True)
    
    Returns:
        Data with fingerprint added
    """
    fp_hash = calculate_fingerprint(data)
    
    data['fingerprint'] = {
        'algorithm': 'sha256',
        'value': fp_hash,
        'scope': 'full_json_excluding_fingerprint',
        'calculated_at': 'auto'
    }
    
    if save and filepath:
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    
    return data


def remove_fingerprint_field(data: dict) -> dict:
    """Remove fingerprint field from data for clean serialization."""
    clean = data.copy()
    clean.pop('fingerprint', None)
    return clean
