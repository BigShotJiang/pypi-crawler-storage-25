"""Host-level initialization for ~/.seif/.

Each machine that participates in a SEIF circuit needs three host-specific
files that are NEVER synced between machines (Layer D in the sync architecture):

  machine_id          — identity of this host within the circuit
  bridge-config.json  — how this host reaches its peer hub (optional)
  sources.json        — git repos this host should pull seif context from (optional)

`seif --init-host` is the canonical way to create them. It is idempotent: running
it on an already-initialized host shows the current state and only writes
fields that are missing or explicitly overridden.
"""

import json
import socket
import secrets
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from seif.data.paths import get_user_home


MACHINE_ID_PROTOCOL = "SEIF-MACHINE-ID-v1"
BRIDGE_CONFIG_PROTOCOL = "SEIF-BRIDGE-CONFIG-v1"

DEFAULT_BRIDGE_TIMEOUTS = {
    "connect_seconds": 5,
    "ssh_seconds": 10,
    "heartbeat_seconds": 30,
    "hub_unreachable_threshold_seconds": 120,
    "reconnect_max_backoff_seconds": 60,
}
DEFAULT_BRIDGE_SYNC = {
    "interval_seconds": 300,
    "paths": ["modules/", "models/", "observations/", "nodes/", "sessions/active/"],
}
DEFAULT_BRIDGE_FALLBACK = {
    "file_relay_enabled": True,
    "relay_dir": "~/.seif/relay/",
    "message_ttl_hours": 24,
}
DEFAULT_BRIDGE_NETWORK = {
    "detect_changes": True,
    "force_reconnect_on_change": True,
    "stale_tunnel_timeout_seconds": 60,
}

VALID_ROLES = ("production", "dev", "edge", "ephemeral")
VALID_SOURCE_TYPES = ("context", "research", "project")
VALID_CLASSIFICATIONS = ("PUBLIC", "INTERNAL", "CONFIDENTIAL")


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _slug(s: str) -> str:
    """Reduce hostname to a stable short label suggestion."""
    base = re.sub(r"\.local$|\.lan$", "", s.strip().lower())
    base = re.sub(r"[^a-z0-9-]+", "-", base).strip("-")
    return base or "host"


# ── machine_id ───────────────────────────────────────────────────────────────


def get_machine_id_path() -> Path:
    return get_user_home() / "machine_id"


def load_machine_id() -> Optional[dict]:
    p = get_machine_id_path()
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text())
    except (json.JSONDecodeError, OSError):
        return None


def generate_machine_id(hostname: Optional[str] = None,
                       label: Optional[str] = None,
                       role: str = "dev") -> dict:
    """Build a fresh machine_id. Does not touch disk."""
    if role not in VALID_ROLES:
        raise ValueError(f"role must be one of {VALID_ROLES}, got {role!r}")
    h = hostname or socket.gethostname()
    return {
        "protocol": MACHINE_ID_PROTOCOL,
        "hostname": h,
        "fingerprint": secrets.token_hex(16),
        "label": label or _slug(h),
        "role": role,
        "created_at": _now_iso(),
    }


def write_machine_id(payload: dict, path: Optional[Path] = None) -> Path:
    target = path or get_machine_id_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(payload, indent=2, ensure_ascii=False))
    return target


def ensure_machine_id(label: Optional[str] = None,
                     role: str = "dev",
                     overwrite: bool = False) -> tuple[dict, bool]:
    """Read existing machine_id or create a new one.

    Returns (payload, created). `created` is True if a new id was generated.
    Does not regenerate the fingerprint when re-running unless overwrite=True
    (the fingerprint is part of the host's persistent identity).
    """
    existing = load_machine_id()
    if existing and not overwrite:
        # Allow label/role refresh without rotating fingerprint
        changed = False
        if label and existing.get("label") != label:
            existing["label"] = label
            changed = True
        if role and existing.get("role") != role and role in VALID_ROLES:
            existing["role"] = role
            changed = True
        if changed:
            write_machine_id(existing)
        return existing, False
    payload = generate_machine_id(label=label, role=role)
    write_machine_id(payload)
    return payload, True


# ── bridge-config.json ───────────────────────────────────────────────────────


def get_bridge_config_path() -> Path:
    return get_user_home() / "bridge-config.json"


def load_bridge_config() -> Optional[dict]:
    p = get_bridge_config_path()
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text())
    except (json.JSONDecodeError, OSError):
        return None


@dataclass
class HubSpec:
    """Transport spec for a peer hub. SEIF-BRIDGE-CONFIG-v1 schema is transport-only —
    role assignments live in two separate places (two-axis taxonomy per SEIF.md):

      • host-role (production | dev | edge | ephemeral | observer-pull) → ~/.seif/machine_id
      • agent-role (maestro | writer | executor | vigilant | ...)        → .seif/modules/agent-roles-v*.seif

    Do not add a `role` field here. Hand-edited bridge-config.json files that include
    `role` keys are non-canonical drift; `seif --init-host` will not preserve them.
    """
    name: str
    host: str
    port: int = 7332
    health_port: int = 7334
    ssh_host: Optional[str] = None
    ssh_key: Optional[str] = None
    priority: int = 1
    transport: str = "direct"

    def to_dict(self) -> dict:
        d = {"name": self.name, "host": self.host,
             "port": self.port, "health_port": self.health_port}
        if self.ssh_host:
            d["ssh_host"] = self.ssh_host
        if self.ssh_key:
            d["ssh_key"] = self.ssh_key
        d["priority"] = self.priority
        d["transport"] = self.transport
        return d


def write_bridge_config(hubs: list[HubSpec], path: Optional[Path] = None) -> Path:
    payload = {
        "protocol": BRIDGE_CONFIG_PROTOCOL,
        "hubs": [h.to_dict() for h in hubs],
        "timeouts": dict(DEFAULT_BRIDGE_TIMEOUTS),
        "sync": dict(DEFAULT_BRIDGE_SYNC),
        "fallback": dict(DEFAULT_BRIDGE_FALLBACK),
        "network": dict(DEFAULT_BRIDGE_NETWORK),
        "updated_at": _now_iso(),
    }
    target = path or get_bridge_config_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(payload, indent=2, ensure_ascii=False))
    return target


# ── sources.json ─────────────────────────────────────────────────────────────


def get_sources_path() -> Path:
    return get_user_home() / "sources.json"


def load_sources() -> list[dict]:
    p = get_sources_path()
    if not p.exists():
        return []
    try:
        data = json.loads(p.read_text())
        return data if isinstance(data, list) else []
    except (json.JSONDecodeError, OSError):
        return []


def parse_source_spec(spec: str) -> dict:
    """Parse "repo:type:classification" into a source dict.

    Accepts shorthand: "repo" → context/INTERNAL, "repo:research" →
    research/CONFIDENTIAL, etc.
    """
    parts = spec.split(":")
    repo = parts[0].strip()
    if not repo:
        raise ValueError(f"empty repo in source spec: {spec!r}")
    stype = (parts[1].strip() if len(parts) >= 2 and parts[1].strip() else "context")
    if stype not in VALID_SOURCE_TYPES:
        raise ValueError(f"source type must be one of {VALID_SOURCE_TYPES}, got {stype!r}")
    if len(parts) >= 3 and parts[2].strip():
        classification = parts[2].strip().upper()
    else:
        # Sensible default per type
        classification = {"context": "INTERNAL", "research": "CONFIDENTIAL",
                          "project": "PUBLIC"}[stype]
    if classification not in VALID_CLASSIFICATIONS:
        raise ValueError(f"classification must be one of {VALID_CLASSIFICATIONS}, "
                         f"got {classification!r}")
    name = Path(repo).name
    return {
        "repo": repo,
        "type": stype,
        "local_path": str(get_user_home() / "cache" / name),
        "last_synced": "",
        "classification": classification,
    }


def write_sources(sources: list[dict], path: Optional[Path] = None) -> Path:
    target = path or get_sources_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(sources, indent=2, ensure_ascii=False))
    return target


def merge_sources(new_specs: list[str], existing: Optional[list[dict]] = None) -> list[dict]:
    """Merge new spec strings into existing sources list, dedup by repo."""
    out = list(existing) if existing else []
    seen = {s.get("repo") for s in out}
    for spec in new_specs:
        s = parse_source_spec(spec)
        if s["repo"] in seen:
            continue
        out.append(s)
        seen.add(s["repo"])
    return out


# ── Top-level orchestration ──────────────────────────────────────────────────


@dataclass
class HostInitResult:
    machine_id: dict
    machine_id_created: bool
    bridge_config: Optional[dict] = None
    bridge_config_created: bool = False
    sources: list[dict] = field(default_factory=list)
    sources_added: int = 0


def init_host(label: Optional[str] = None,
              role: str = "dev",
              overwrite_machine_id: bool = False,
              hubs: Optional[list[HubSpec]] = None,
              source_specs: Optional[list[str]] = None,
              dry_run: bool = False) -> HostInitResult:
    """Run the full host-init flow.

    Steps (each is idempotent, idempotent skips don't write):
      1. ensure_machine_id (label/role refreshable; fingerprint stable)
      2. write_bridge_config if hubs given (overwrites existing)
      3. merge_sources if source_specs given (deduped by repo)
    """
    # 1. machine_id
    if dry_run:
        existing = load_machine_id()
        if existing:
            machine_id, created = existing, False
        else:
            machine_id, created = generate_machine_id(label=label, role=role), True
    else:
        machine_id, created = ensure_machine_id(label=label, role=role,
                                                overwrite=overwrite_machine_id)
    result = HostInitResult(machine_id=machine_id, machine_id_created=created)

    # 2. bridge-config.json
    if hubs:
        if not dry_run:
            write_bridge_config(hubs)
        result.bridge_config = {
            "protocol": BRIDGE_CONFIG_PROTOCOL,
            "hubs": [h.to_dict() for h in hubs],
        }
        result.bridge_config_created = True

    # 3. sources.json
    if source_specs:
        existing = load_sources()
        merged = merge_sources(source_specs, existing)
        if not dry_run:
            write_sources(merged)
        result.sources = merged
        result.sources_added = len(merged) - len(existing)

    return result
