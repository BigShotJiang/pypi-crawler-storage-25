"""Seed-constraint matcher: gate proposed actions against active seeds.

Closes a seed-discipline gap: SEED-*.json files declare prohibitions
under `what_NOT_to_do_during` (and forward-compatible `prohibited` /
`forbidden` keys). Operators sometimes pre-approve forward motion
without re-reading the seed; the AI inherits the approval and acts,
violating the seed's explicit constraint. The remediation pattern
codified in `feedback_re_read_seed_before_acting` says: re-read the
seed `what_NOT_to_do_during` before any host action, every time —
operator approval does NOT subsume seed verification.

`check_seed_constraint` makes that check programmatic. Workflow:

    seif --check-seed-constraint "self-update on air-m1"
        → exit 0 if no active seed prohibits the action
        → exit 1 if a seed prohibits it (prints blocking seed_id +
          quoted constraint to stderr)
        → exit 2 if no active seeds present (advisory)

Matching is conservative: tokenize the action by whitespace and
hyphen-aware boundaries, keep "significant tokens" (length >= 4 or
flag-like `--<x>` / `-<x>`), and report a constraint as blocking when
ANY significant action token appears as a whole word inside the
constraint text (case-insensitive). False positives surface to the
operator and to the AI — both are gatekeepers of last resort. False
negatives let the action through silently, which is the worse mode,
so the matcher errs toward broadcasting.
"""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Optional


# Keys under which a seed may declare prohibitions. `what_NOT_to_do_during`
# is the canonical SEIF-SEED-v1 field; the others are accepted for
# forward compatibility with seed schemas authored by peer agents.
_PROHIBITION_KEYS = (
    "what_NOT_to_do_during",
    "prohibited",
    "forbidden",
    "do_not",
)


def _significant_tokens(action: str) -> list[str]:
    """Extract distinctive tokens from an action string.

    Keeps tokens of length >= 4 OR flag-like (starts with `-`/`--`).
    Drops short common words and punctuation. Lowercased.
    """
    if not action:
        return []
    raw = re.split(r"[\s,;:.\(\)]+", action)
    out: list[str] = []
    for tok in raw:
        tok = tok.strip().lower()
        if not tok:
            continue
        if tok.startswith("-") or len(tok) >= 4:
            out.append(tok)
    return out


def _constraint_matches(constraint: str, tokens: list[str]) -> Optional[str]:
    """Return the matched token if the constraint contains any of the
    action's significant tokens as a whole word. Otherwise None.

    Whole-word matching avoids partial collisions ("log" inside
    "logging" or "psychological"). Constraint text is matched
    case-insensitively.
    """
    if not constraint or not tokens:
        return None
    lowered = constraint.lower()
    for tok in tokens:
        # Treat `[\w]` as the word class (so `-` and other punctuation
        # are boundaries). Lets `self-update` match inside `--self-update`
        # while still rejecting partials like `log` inside `logging`.
        pattern = r"(?<![\w])" + re.escape(tok) + r"(?![\w])"
        if re.search(pattern, lowered):
            return tok
    return None


def _iter_active_seeds(seeds_dir: Path):
    """Yield (path, data) for unconsumed seeds in the directory.

    A seed is "consumed" when a `<path>.consumed_at` sidecar exists.
    Mirrors the contract of `workspace.find_pending_seed`. Skips files
    that are not valid JSON.
    """
    if not seeds_dir.is_dir():
        return
    for path in sorted(seeds_dir.glob("SEED-*.json")):
        if path.with_suffix(path.suffix + ".consumed_at").exists():
            continue
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        yield path, data


def _collect_constraints(data: dict) -> list[str]:
    """Pull all prohibition strings out of a seed payload."""
    out: list[str] = []
    for key in _PROHIBITION_KEYS:
        value = data.get(key)
        if isinstance(value, list):
            for item in value:
                if isinstance(item, str) and item.strip():
                    out.append(item.strip())
        elif isinstance(value, str) and value.strip():
            out.append(value.strip())
    return out


def check_seed_constraint(action: str, seif_dir: Path) -> dict:
    """Check `action` against prohibitions in active seeds.

    Args:
        action: Free-text description of the planned action
            (e.g., "self-update on air-m1", "git push --force",
            "rename plist on Mini").
        seif_dir: The active `.seif/` directory whose `seeds/`
            subdir holds SEED-*.json candidates.

    Returns:
        {
            "allowed": bool,                # False if blocked
            "blocking_seed": str | None,    # seed_id of first match
            "blocking_seed_path": str | None,
            "blocking_constraint": str | None,  # the prohibition text
            "matched_token": str | None,    # which action token hit
            "active_seeds_checked": int,
        }

    Returns allowed=True when no active seeds exist (caller decides if
    that is advisory or hard-fail; the CLI surface uses exit code 2 to
    mark the no-seed case explicitly).
    """
    seeds_dir = seif_dir / "seeds"
    tokens = _significant_tokens(action)
    checked = 0

    for path, data in _iter_active_seeds(seeds_dir):
        checked += 1
        constraints = _collect_constraints(data)
        for constraint in constraints:
            matched = _constraint_matches(constraint, tokens)
            if matched is not None:
                seed_id = str(data.get("seed_id", path.stem))
                return {
                    "allowed": False,
                    "blocking_seed": seed_id,
                    "blocking_seed_path": str(path),
                    "blocking_constraint": constraint,
                    "matched_token": matched,
                    "active_seeds_checked": checked,
                }

    return {
        "allowed": True,
        "blocking_seed": None,
        "blocking_seed_path": None,
        "blocking_constraint": None,
        "matched_token": None,
        "active_seeds_checked": checked,
    }
