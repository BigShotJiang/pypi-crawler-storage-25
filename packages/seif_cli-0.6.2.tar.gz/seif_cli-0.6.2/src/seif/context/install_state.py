"""Detect drift between declared install_method and actual install state.

Closes a silent-corruption mode in `seif --self-update`: a host's
`host-install-config.seif` may declare `install_method: "editable"`
to express the operator's intent ("changes in source_repo reflect
immediately, no rebuild step"), but the actual binary on PATH may be
a frozen pipx install at a fixed commit. Edits to the source repo
land nowhere, the operator believes they reflect, and the host
silently runs stale code for sessions or weeks.

Root cause observed on Mini (s46 diagnostic):
  - Migration on 2026-05-01 set install_method=editable in the config
  - The migration step did NOT re-install the package in editable mode
  - subsequent `seif --self-update` calls hit the editable branch in
    seif-update.sh (which ran `pip install -e $src`), but `pip` was
    the system Python, not the pipx venv Python — pipx venv stayed
    frozen at the original commit
  - Result: 50+ commits behind, "v2 envelope" never reached the host

`detect_editable_drift` is the read-only check that surfaces the
condition before the install runs, so seif-update.sh (and the new
pipx-aware editable branch) can either auto-correct or warn loudly.

This module performs no I/O beyond the two state files it reads. It
does NOT shell out to pip/pipx — that runs in the bash dispatcher.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Optional


def _read_config(config_path: Path) -> dict:
    """Read host-install-config.seif as JSON. Returns {} on error."""
    try:
        return json.loads(config_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}


def _find_pipx_dist_info(pkg: str,
                         pipx_local_venvs: Optional[Path] = None) -> Optional[Path]:
    """Locate the package's `direct_url.json` inside its pipx venv.

    Args:
        pkg: pipx package name (e.g., "seif-cli").
        pipx_local_venvs: PIPX_LOCAL_VENVS path. Defaults to
            `~/.local/pipx/venvs/` which matches pipx's default on
            Linux + macOS user installs.

    Returns:
        Path to the first `direct_url.json` matching the package
        name, or None if no such file exists.
    """
    if pipx_local_venvs is None:
        pipx_local_venvs = Path.home() / ".local" / "pipx" / "venvs"
    venv = pipx_local_venvs / pkg
    if not venv.is_dir():
        return None
    pkg_underscored = pkg.replace("-", "_")
    for candidate in venv.glob(
        f"lib/python*/site-packages/{pkg_underscored}-*.dist-info/direct_url.json"
    ):
        return candidate
    return None


def _direct_url_state(direct_url_path: Path) -> dict:
    """Parse pip's `direct_url.json` (PEP 610) for editable + source info.

    Returns:
        {
            "editable": bool,        # True if installed via `pip install -e`
            "url": str,              # source URL (file:// for editable, git+ for VCS)
            "commit_id": str,        # VCS commit if known, else ''
        }
        All keys present; values may be empty strings.
    """
    try:
        data = json.loads(direct_url_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {"editable": False, "url": "", "commit_id": ""}
    return {
        "editable": bool(data.get("dir_info", {}).get("editable", False)),
        "url": str(data.get("url", "")),
        "commit_id": str(data.get("vcs_info", {}).get("commit_id", "")),
    }


def detect_editable_drift(config_path: Path,
                          pipx_local_venvs: Optional[Path] = None) -> dict:
    """Check whether install state matches the declared install_method.

    Args:
        config_path: `~/.seif/host-install-config.seif` path.
        pipx_local_venvs: Override for pipx's venv root (mostly for
            tests). Defaults to `~/.local/pipx/venvs/`.

    Returns:
        {
            "in_drift": bool,
            "declared_method": str,      # config's install_method
            "actual_state": str,         # one of:
                                         #   "editable-pipx", "frozen-pipx",
                                         #   "no-pipx-install", "no-config",
                                         #   "unknown"
            "package_name": str,
            "source_repo": str,          # config's source_repo (or '')
            "remediation": str,          # actionable hint (or '')
        }

    Drift definitions:
      - declared=editable AND actual=frozen-pipx → drift (remediation:
        `pipx install --editable --force <source_repo>`)
      - declared=pipx AND actual=editable-pipx → drift (remediation:
        `pipx install --force <package_source>`)
      - declared=editable AND actual=no-pipx-install → not drift if pip
        editable is plausible (we can't verify without invoking pip);
        report with remediation pointing to bare `pip install -e`
      - declared=editable AND actual=editable-pipx → no drift
      - declared=pipx AND actual=frozen-pipx → no drift
    """
    if not config_path.is_file():
        return {
            "in_drift": False,
            "declared_method": "",
            "actual_state": "no-config",
            "package_name": "",
            "source_repo": "",
            "remediation": "",
        }

    config = _read_config(config_path)
    declared = str(config.get("install_method", ""))
    pkg = str(config.get("package_name", "seif-cli"))
    src = str(config.get("source_repo", ""))

    direct_url = _find_pipx_dist_info(pkg, pipx_local_venvs)
    if direct_url is None:
        actual = "no-pipx-install"
        editable_pipx = False
    else:
        info = _direct_url_state(direct_url)
        editable_pipx = info["editable"]
        actual = "editable-pipx" if editable_pipx else "frozen-pipx"

    in_drift = False
    remediation = ""
    if declared == "editable" and actual == "frozen-pipx":
        in_drift = True
        remediation = (
            f"pipx install --editable --force {src}"
            if src else
            "pipx install --editable --force <source_repo> "
            "(set source_repo in host-install-config.seif first)"
        )
    elif declared == "editable" and actual == "no-pipx-install":
        in_drift = True
        remediation = (
            f"pipx install --editable --force {src} "
            "(no pipx install present; bare `pip install -e` will not "
            "match what `seif` resolves on PATH if pipx is the binary "
            "provider)"
            if src else
            "no source_repo declared; cannot remediate"
        )
    elif declared == "pipx" and actual == "editable-pipx":
        in_drift = True
        remediation = (
            f"pipx install --force {config.get('package_source','')} "
            "(re-freeze to match declared method)"
        )

    return {
        "in_drift": in_drift,
        "declared_method": declared,
        "actual_state": actual,
        "package_name": pkg,
        "source_repo": src,
        "remediation": remediation,
    }
