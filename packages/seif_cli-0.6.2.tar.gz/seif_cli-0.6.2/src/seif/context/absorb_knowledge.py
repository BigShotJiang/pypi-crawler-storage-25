"""SEIF knowledge absorption — in-package implementation.

Replaces the legacy standalone /Volumes/DockerData/seif-admin/absorb-knowledge.py
script that was unreachable for pipx-installed users (Gap 60). Behavior is
preserved end-to-end: scan absorption-v*.seif modules + atomic_payload/{state,
transmissions}, extract knowledge items, write absorption-receipt-<ts>.json +
memory_state.json into the context directory.

Public API:
    absorb(context_dir: Path) -> dict
        Run the full pipeline. Returns the receipt dict that was also persisted.
        Receipt status is "FULL" when at least one absorption file or atomic
        payload was processed, "EMPTY" otherwise.

CLI entrypoint:
    python -m seif.context.absorb_knowledge [context_dir]
        Defaults context_dir to ./seif-context (legacy script behavior).
"""

from __future__ import annotations

import hashlib
import json
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

PHI = 1.618033988749895
ZETA_OPTIMAL = 0.6123724356957945


def _resonance_hash(items: Any) -> str:
    return hashlib.sha256(json.dumps(items, sort_keys=True).encode()).hexdigest()[:16]


def _scan_absorption_files(context_dir: Path) -> list[Path]:
    return sorted(context_dir.glob("absorption-v*.seif"))


def _process_atomic_payloads(context_dir: Path) -> list[dict[str, Any]]:
    payloads: list[dict[str, Any]] = []
    payload_dir = context_dir / "atomic_payload"
    if not payload_dir.exists():
        return payloads

    state_file = payload_dir / "state.json"
    if state_file.exists():
        try:
            payloads.append({
                "type": "state",
                "data": json.loads(state_file.read_text(encoding="utf-8")),
                "file": state_file.name,
            })
        except (json.JSONDecodeError, OSError):
            pass

    transmissions_file = payload_dir / "transmissions.jsonl"
    if transmissions_file.exists():
        try:
            txs = [
                json.loads(line)
                for line in transmissions_file.read_text(encoding="utf-8").splitlines()
                if line.strip()
            ]
            payloads.append({
                "type": "transmissions",
                "data": txs,
                "file": transmissions_file.name,
            })
        except (json.JSONDecodeError, OSError):
            pass

    return payloads


def _extract_from_absorption(data: dict[str, Any]) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    if "summary" in data:
        items.append({
            "type": "summary",
            "content": data["summary"],
            "protocol": data.get("protocol", "unknown"),
            "session": data.get("session", "unknown"),
        })
    for c in data.get("contributors", []):
        items.append({
            "type": "contribution",
            "author": c.get("author", "unknown"),
            "action": c.get("action", "unknown"),
            "timestamp": c.get("at", "unknown"),
        })
    return items


def _extract_from_payload(payload: dict[str, Any]) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    if payload["type"] == "state":
        d = payload["data"]
        items.append({
            "type": "state",
            "id": d.get("id", "unknown"),
            "recipient": d.get("recipient", "unknown"),
            "status": d.get("status", "unknown"),
            "chunks": len(d.get("chunks", [])),
        })
    elif payload["type"] == "transmissions":
        for tx in payload["data"]:
            items.append({
                "type": "transmission",
                "id": tx.get("id", "unknown"),
                "recipient": tx.get("recipient", "unknown"),
                "status": tx.get("status", "unknown"),
                "tokens": tx.get("original_tokens", 0),
            })
    return items


def absorb(context_dir: Path) -> dict[str, Any]:
    """Run the full absorption pipeline against `context_dir`.

    Scans `absorption-v*.seif` + `atomic_payload/{state.json,transmissions.jsonl}`,
    extracts knowledge items, writes `memory_state.json` + a timestamped
    `absorption-receipt-<ts>.json` into `context_dir`, and returns the receipt.

    Args:
        context_dir: Directory containing absorption modules (typically `.seif/`
            or a legacy `seif-context/`).

    Returns:
        Receipt dict with absorption_status ("FULL" or "EMPTY"), counts, and
        a flat resonance hash.

    Raises:
        FileNotFoundError: if `context_dir` does not exist.
    """
    if not context_dir.exists():
        raise FileNotFoundError(f"context_dir not found: {context_dir}")

    absorption_files = _scan_absorption_files(context_dir)
    payloads = _process_atomic_payloads(context_dir)

    memory_state: dict[str, Any] = {}
    total_items = 0
    absorbed_files = 0
    errors: list[str] = []

    for f in absorption_files:
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
            items = _extract_from_absorption(data)
            total_items += len(items)
            key = f"{data.get('protocol', 'unknown')}-{data.get('session', data.get('id', 'unknown'))}"
            memory_state[key] = {
                "absorbed_at": datetime.now(timezone.utc).isoformat(),
                "knowledge_count": len(items),
                "resonance_hash": _resonance_hash(items),
                "source_file": f.name,
                "knowledge_items": items,
            }
            absorbed_files += 1
        except (json.JSONDecodeError, OSError) as e:
            errors.append(f"{f.name}: {type(e).__name__}: {e}")

    for p in payloads:
        try:
            items = _extract_from_payload(p)
            total_items += len(items)
            key = f"{p['type']}-{p['file']}"
            memory_state[key] = {
                "absorbed_at": datetime.now(timezone.utc).isoformat(),
                "knowledge_count": len(items),
                "resonance_hash": _resonance_hash(items),
                "source_file": p["file"],
                "knowledge_items": items,
            }
            absorbed_files += 1
        except Exception as e:
            errors.append(f"{p['file']}: {type(e).__name__}: {e}")

    receipt: dict[str, Any] = {
        "protocol": "SEIF-RECEIPT-v1",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "absorber": "seif-knowledge-absorber",
        "absorption_status": "FULL" if absorbed_files > 0 else "EMPTY",
        "total_files_processed": absorbed_files,
        "total_knowledge_items": total_items,
        "resonance_hash": _resonance_hash(list(memory_state.keys())),
        "memory_state_count": len(memory_state),
        "zeta_alignment": ZETA_OPTIMAL,
        "harmonic_balance": True,
        "errors": errors,
    }

    receipt_file = context_dir / f"absorption-receipt-{int(time.time())}.json"
    receipt_file.write_text(
        json.dumps(receipt, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    memory_file = context_dir / "memory_state.json"
    memory_file.write_text(
        json.dumps(memory_state, indent=2, ensure_ascii=False, default=str),
        encoding="utf-8",
    )

    return receipt


def main(argv: list[str] | None = None) -> int:
    """python -m seif.context.absorb_knowledge [context_dir]

    Defaults context_dir to ./seif-context (parity with the legacy script).
    Returns 0 on FULL absorption, 2 on EMPTY, 1 on missing context_dir.
    """
    args = argv if argv is not None else sys.argv[1:]
    context_dir = Path(args[0]) if args else Path("seif-context")

    if not context_dir.exists():
        print(f"context_dir not found: {context_dir}", file=sys.stderr)
        return 1

    receipt = absorb(context_dir)
    print(json.dumps({
        "status": receipt["absorption_status"],
        "files": receipt["total_files_processed"],
        "items": receipt["total_knowledge_items"],
        "errors": len(receipt["errors"]),
        "resonance_hash": receipt["resonance_hash"],
    }))
    return 0 if receipt["absorption_status"] == "FULL" else 2


if __name__ == "__main__":
    sys.exit(main())
