"""
SEIF Context Registry — Global index of all .seif contexts on this machine.

Lives at ~/.seif/registry.json. Tracks every context the user has initialized,
enabling `seif list`, `seif status`, and future `seif push/pull/clone`.

Analogous to how git tracks repos, but for context.

Also indexes pending_modules — pointers to SEIF-PENDING-v1 modules so future
sessions can discover them without owner-relay (gap-14 / branch-7 of s32).
The pending_modules section is INDEX ONLY: each entry is a workspace-relative
pointer; lifecycle state (open/consumed) lives in the source module file to
avoid drift.
"""

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Optional

from seif.data.paths import get_user_home


REGISTRY_PROTOCOL = "SEIF-REGISTRY-v1"


def get_registry_path() -> Path:
    """Return path to ~/.seif/registry.json."""
    return get_user_home() / "registry.json"


def _empty_registry() -> dict:
    """Create an empty registry structure."""
    return {
        "protocol": REGISTRY_PROTOCOL,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "updated_at": datetime.now(timezone.utc).isoformat(),
        "contexts": [],
        "pending_modules": [],
    }


def load_registry() -> dict:
    """Load the global registry. Creates it if it doesn't exist."""
    path = get_registry_path()
    if path.exists():
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if data.get("protocol") == REGISTRY_PROTOCOL:
                return data
        except (json.JSONDecodeError, OSError):
            pass
    return _empty_registry()


def save_registry(registry: dict) -> Path:
    """Save the registry to ~/.seif/registry.json. Creates ~/.seif/ if needed."""
    path = get_registry_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    registry["updated_at"] = datetime.now(timezone.utc).isoformat()
    with open(path, "w", encoding="utf-8") as f:
        json.dump(registry, f, indent=2, ensure_ascii=False)
    # Secure permissions (owner-only read/write)
    os.chmod(path, 0o600)
    return path


def find_context_entry(registry: dict, seif_path: str) -> Optional[dict]:
    """Find a context entry by its .seif/ path."""
    resolved = str(Path(seif_path).resolve())
    for ctx in registry.get("contexts", []):
        if str(Path(ctx["path"]).resolve()) == resolved:
            return ctx
    return None


def find_context_by_name(registry: dict, name: str) -> Optional[dict]:
    """Find a context entry by name."""
    for ctx in registry.get("contexts", []):
        if ctx.get("name") == name:
            return ctx
    return None


def register_context(
    seif_path: str,
    name: Optional[str] = None,
    remote: Optional[str] = None,
    visibility: str = "private",
) -> dict:
    """Register a .seif context in the global registry.

    Args:
        seif_path: Absolute path to the .seif/ directory
        name: Human-friendly name (defaults to parent directory name)
        remote: Remote URL on seifprotocol.com (None = local-only)
        visibility: 'private', 'public', or 'local'

    Returns:
        The created/updated context entry.
    """
    registry = load_registry()
    resolved = str(Path(seif_path).resolve())

    # Derive name from parent directory if not given
    if not name:
        parent = Path(resolved).parent
        name = parent.name if parent.name != ".seif" else parent.parent.name

    # Check if already registered
    existing = find_context_entry(registry, resolved)
    if existing:
        existing["name"] = name
        existing["updated_at"] = datetime.now(timezone.utc).isoformat()
        if remote is not None:
            existing["remote"] = remote
        if visibility:
            existing["visibility"] = visibility
        save_registry(registry)
        return existing

    # Create new entry
    entry = {
        "name": name,
        "path": resolved,
        "remote": remote,
        "visibility": visibility,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "updated_at": datetime.now(timezone.utc).isoformat(),
        "last_sync": None,
    }
    registry["contexts"].append(entry)
    save_registry(registry)
    return entry


def unregister_context(seif_path: str) -> bool:
    """Remove a context from the registry."""
    registry = load_registry()
    resolved = str(Path(seif_path).resolve())
    original_len = len(registry.get("contexts", []))
    registry["contexts"] = [
        c for c in registry.get("contexts", [])
        if str(Path(c["path"]).resolve()) != resolved
    ]
    if len(registry["contexts"]) < original_len:
        save_registry(registry)
        return True
    return False


def list_contexts(registry: Optional[dict] = None) -> list[dict]:
    """List all registered contexts with health status."""
    if registry is None:
        registry = load_registry()

    results = []
    for ctx in registry.get("contexts", []):
        path = Path(ctx["path"])
        exists = path.exists()
        has_mapper = (path / "mapper.json").exists() if exists else False
        has_config = (path / "config.json").exists() if exists else False

        # Count modules
        module_count = 0
        if exists:
            for ext_file in path.rglob("*.seif"):
                module_count += 1

        results.append({
            **ctx,
            "exists": exists,
            "has_mapper": has_mapper,
            "has_config": has_config,
            "module_count": module_count,
        })
    return results


def update_sync_timestamp(seif_path: str) -> None:
    """Mark a context as just synced."""
    registry = load_registry()
    entry = find_context_entry(registry, seif_path)
    if entry:
        entry["last_sync"] = datetime.now(timezone.utc).isoformat()
        entry["updated_at"] = datetime.now(timezone.utc).isoformat()
        save_registry(registry)


def detect_unregistered_contexts(scan_paths: Optional[list[str]] = None) -> list[Path]:
    """Scan specific directories for .seif/ dirs not in the registry.

    Only scans paths explicitly provided or configured in the registry.
    Never scans arbitrary user directories without consent.

    Args:
        scan_paths: Explicit list of directories to scan. If None, uses
                    paths from registry config (scan_roots field).
                    If neither exists, returns empty list (opt-in only).
    """
    registry = load_registry()
    registered_paths = {
        str(Path(c["path"]).resolve()) for c in registry.get("contexts", [])
    }

    # Determine scan roots: explicit > config > nothing (opt-in)
    if scan_paths:
        roots = [Path(p) for p in scan_paths]
    else:
        configured = registry.get("scan_roots", [])
        if not configured:
            return []
        roots = [Path(p).expanduser() for p in configured]

    candidates = []
    for root in roots:
        if not root.exists() or not root.is_dir():
            continue
        # Only scan 2 levels deep, skip hidden dirs
        try:
            for child in root.iterdir():
                if not child.is_dir() or child.name.startswith("."):
                    continue
                seif_dir = child / ".seif"
                if seif_dir.is_dir() and str(seif_dir.resolve()) not in registered_paths:
                    candidates.append(seif_dir)
                # One more level
                try:
                    for grandchild in child.iterdir():
                        if not grandchild.is_dir() or grandchild.name.startswith("."):
                            continue
                        seif_dir = grandchild / ".seif"
                        if seif_dir.is_dir() and str(seif_dir.resolve()) not in registered_paths:
                            candidates.append(seif_dir)
                except PermissionError:
                    continue
        except PermissionError:
            continue

    return candidates


# Paths that should never appear as workspaces in the registry. They are either
# OS tempdirs left behind by tests or runtime caches that have no human owner.
EPHEMERAL_PATH_PARTS = (
    "/private/var/folders/",
    "/var/folders/",
    "/tmp/",
    "/private/tmp/",
)
EPHEMERAL_NAME_PREFIXES = ("tmp", "workspace_", "test_", "_pytest_")

# Build artifact / dependency directories that occasionally contain copies of
# .seif/ but are not authored workspaces. We skip them during discovery but do
# not drop existing entries that match (in case someone deliberately initialized
# one).
BUILD_ARTIFACT_PARTS = (
    "/.next/",
    "/node_modules/",
    "/.venv/",
    "/venv/",
    "/dist/",
    "/build/",
    "/.git/",
    "/__pycache__/",
)


def _looks_ephemeral(seif_dir: Path) -> bool:
    """Detect tempdirs left over from test runs."""
    p = str(seif_dir)
    if any(part in p for part in EPHEMERAL_PATH_PARTS):
        return True
    parent_name = seif_dir.parent.name
    return any(parent_name.startswith(prefix) for prefix in EPHEMERAL_NAME_PREFIXES)


def _looks_build_artifact(seif_dir: Path) -> bool:
    """Detect .seif/ buried inside a build/dependency dir."""
    p = str(seif_dir)
    return any(part in p for part in BUILD_ARTIFACT_PARTS)


def rebuild_registry(scan_roots: list[str], dry_run: bool = False) -> dict:
    """Regenerate ~/.seif/registry.json by scanning the filesystem.

    Drops stale entries whose paths no longer exist or look ephemeral
    (tempdirs from old test runs). Adds .seif/ dirs found under scan_roots
    that are not yet registered.

    Returns a summary dict: {kept, dropped, added, total, registry}.
    Use dry_run=True to preview without writing.
    """
    registry = load_registry()
    existing = registry.get("contexts", [])
    created_at = registry.get("created_at") or datetime.now(timezone.utc).isoformat()

    kept_paths: set[str] = set()
    dropped: list[dict] = []

    new_contexts: list[dict] = []
    for ctx in existing:
        try:
            path = Path(ctx["path"])
        except (KeyError, TypeError):
            dropped.append(ctx)
            continue
        if not path.exists() or _looks_ephemeral(path):
            dropped.append(ctx)
            continue
        resolved = str(path.resolve())
        if resolved in kept_paths:
            dropped.append(ctx)
            continue
        kept_paths.add(resolved)
        new_contexts.append(ctx)

    # Discover unregistered .seif/ dirs under scan_roots.
    # Defensive: refuse pathological roots ($HOME, /, root with >50 top-level
    # entries) — rglob over those hangs for tens of seconds and is never the
    # caller's intent. Workspaces should be registered via explicit `seif --init`
    # or by being scanned in their own directory.
    added: list[dict] = []
    now_iso = datetime.now(timezone.utc).isoformat()
    pathological_roots = {Path.home().resolve(), Path("/").resolve()}
    for raw_root in scan_roots:
        root = Path(raw_root).expanduser()
        if not root.exists():
            continue
        if root.resolve() in pathological_roots:
            continue
        try:
            top_level_count = sum(1 for _ in root.iterdir())
        except (PermissionError, OSError):
            top_level_count = 0
        if top_level_count > 50:
            continue
        for found in root.rglob(".seif"):
            if not found.is_dir():
                continue
            if _looks_ephemeral(found) or _looks_build_artifact(found):
                continue
            resolved = str(found.resolve())
            if resolved in kept_paths:
                continue
            parent = found.parent
            name = parent.name if parent.name not in (".", "") else found.parent.name
            entry = {
                "name": name,
                "path": str(found),
                "remote": None,
                "visibility": "private",
                "created_at": now_iso,
                "updated_at": now_iso,
                "last_sync": None,
            }
            new_contexts.append(entry)
            added.append(entry)
            kept_paths.add(resolved)

    rebuilt = {
        "protocol": REGISTRY_PROTOCOL,
        "created_at": created_at,
        "updated_at": now_iso,
        "contexts": new_contexts,
    }

    if not dry_run:
        save_registry(rebuilt)

    return {
        "kept": len(new_contexts) - len(added),
        "dropped": len(dropped),
        "added": len(added),
        "total": len(new_contexts),
        "registry": rebuilt,
        "dropped_entries": dropped,
        "added_entries": added,
    }


# ── Pending Modules (gap-14 / branch-7 of s32) ──────────────────────────────
#
# A pending module is a SEIF-PENDING-v1 .seif file declaring future work.
# Different from contexts (workspaces): pendings are short-lived, may live
# in a workspace different from the one that should consume them, and need
# explicit discovery so future sessions don't miss them.
#
# Two visibility tiers (gap-14 follow-up):
#   personal — lives at ~/.seif/pending/<file>; never committed; per developer
#   team     — lives at <workspace>/.seif/pending/<file>; commitable; shared
#
# Registry entry shape (visibility-aware):
#   {
#     "module_id": str,
#     "visibility": "personal" | "team",
#     "workspace_relative_path": str,        # path under base directory
#     "stored_in_workspace": Optional[str],  # workspace_id when visibility=team
#     "target_workspace": Optional[str],     # only meaningful when visibility=team
#     "target_consumer": str,                # owner | next_cycle | vigilant | team
#     "target_cycle_pattern": str,
#     "discovered_at": str,
#     "indexed_at": str,
#   }
#
# Personal entries omit stored_in_workspace/target_workspace and resolve
# against ~/.seif/. Team entries resolve against the named workspace's
# .seif/ parent. Status (open|consumed) is read lazily from the source
# module — index never stores state.


PERSONAL_PENDING_DIR = "pending"  # under ~/.seif/


def register_pending_module(
    registry: dict,
    *,
    module_id: str,
    workspace_relative_path: str,
    target_consumer: str,
    visibility: str = "team",
    stored_in_workspace: Optional[str] = None,
    target_workspace: Optional[str] = None,
    target_cycle_pattern: str = "any",
    discovered_at: Optional[str] = None,
) -> dict:
    """Add a pending-module pointer to the registry.

    visibility="personal" → stored_in_workspace and target_workspace MUST be None.
                            Path resolves against ~/.seif/.
    visibility="team"     → stored_in_workspace REQUIRED; target_workspace
                            defaults to stored_in_workspace if not given.
                            Path resolves against the workspace's .seif/ parent.

    Idempotent: re-registering an existing module_id updates its fields.
    Mutates registry in place; caller is responsible for save_registry().
    """
    if visibility not in ("personal", "team"):
        raise ValueError(
            f"visibility must be 'personal' or 'team', got {visibility!r}"
        )
    if visibility == "personal":
        stored_in_workspace = None
        target_workspace = None
    else:  # team
        if not stored_in_workspace:
            raise ValueError(
                "visibility='team' requires stored_in_workspace"
            )
        if not target_workspace:
            target_workspace = stored_in_workspace

    pendings = registry.setdefault("pending_modules", [])
    now = datetime.now(timezone.utc).isoformat()
    entry = {
        "module_id": module_id,
        "visibility": visibility,
        "workspace_relative_path": workspace_relative_path,
        "stored_in_workspace": stored_in_workspace,
        "target_workspace": target_workspace,
        "target_consumer": target_consumer,
        "target_cycle_pattern": target_cycle_pattern,
        "discovered_at": discovered_at or now[:10],
        "indexed_at": now,
    }
    for i, existing in enumerate(pendings):
        if existing.get("module_id") == module_id:
            pendings[i] = entry
            return entry
    pendings.append(entry)
    return entry


def unregister_pending_module(registry: dict, module_id: str) -> bool:
    """Remove a pending-module pointer. Returns True if removed."""
    pendings = registry.get("pending_modules", [])
    for i, entry in enumerate(pendings):
        if entry.get("module_id") == module_id:
            pendings.pop(i)
            return True
    return False


def find_pending_modules(
    registry: dict,
    *,
    target_workspace: Optional[str] = None,
    target_consumer: Optional[str] = None,
) -> List[dict]:
    """Filter pending modules by target workspace and/or consumer."""
    out = []
    for entry in registry.get("pending_modules", []):
        if target_workspace and entry.get("target_workspace") != target_workspace:
            continue
        if target_consumer and entry.get("target_consumer") != target_consumer:
            continue
        out.append(entry)
    return out


def resolve_pending_path(registry: dict, entry: dict) -> Optional[Path]:
    """Resolve a pending entry's path into an absolute filesystem location.

    Resolution depends on visibility tier:
      personal → ~/.seif/<workspace_relative_path>
      team     → <workspace_root>/<workspace_relative_path>
                 where workspace_root is the parent of the .seif/ path
                 registered for stored_in_workspace.

    Legacy entries without `visibility` (PR #45 era) are treated as 'team'
    when stored_in_workspace is set; this preserves backward compatibility.

    Returns None if resolution is impossible or the file does not exist.
    """
    rel_path = entry.get("workspace_relative_path", "")
    if not rel_path:
        return None

    visibility = entry.get("visibility")
    if visibility is None:
        visibility = "team" if entry.get("stored_in_workspace") else None
    if visibility == "personal":
        candidate = get_user_home() / rel_path
        return candidate if candidate.exists() else None
    if visibility == "team":
        workspace_id = entry.get("stored_in_workspace")
        if not workspace_id:
            return None
        ws_entry = find_context_by_name(registry, workspace_id)
        if not ws_entry:
            return None
        seif_path = Path(ws_entry.get("path", ""))
        workspace_root = seif_path.parent if seif_path.name == ".seif" else seif_path
        candidate = workspace_root / rel_path
        return candidate if candidate.exists() else None
    return None


def read_pending_status(registry: dict, entry: dict) -> str:
    """Read the live status from the pending module's source file.

    Returns one of: "open", "consumed", "missing", or the module's own status
    string when present and non-empty. Falls back to "open" when the module
    exists but does not declare a status field (legacy modules).
    """
    path = resolve_pending_path(registry, entry)
    if path is None:
        return "missing"
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return "missing"
    status = data.get("status")
    if isinstance(status, str) and status:
        return status.lower()
    return "open"


def list_open_pendings(
    registry: dict,
    current_workspace_id: Optional[str] = None,
) -> List[dict]:
    """Return pending entries currently relevant to a session.

    Relevance rules:
      - personal-tier pendings (visibility=='personal') are ALWAYS surfaced —
        they belong to this developer regardless of which project they're in
      - team-tier pendings are surfaced when target_workspace ==
        current_workspace_id
      - target_consumer == "owner" is always surfaced (legacy compatibility +
        explicit owner-targeted items)
      - status (read from source module) must not be "consumed" or "missing"

    Each returned entry is augmented with `_status` (live status) and
    `_resolved_path` (absolute Path or None) for caller convenience.
    """
    out = []
    for entry in registry.get("pending_modules", []):
        visibility = entry.get("visibility")
        # legacy entries without visibility are treated as 'team' when they
        # carry stored_in_workspace, else 'personal'
        if visibility is None:
            visibility = "team" if entry.get("stored_in_workspace") else "personal"
        relevant = (
            visibility == "personal"
            or entry.get("target_consumer") == "owner"
            or (current_workspace_id and entry.get("target_workspace") == current_workspace_id)
        )
        if not relevant:
            continue
        status = read_pending_status(registry, entry)
        if status in ("consumed", "missing"):
            continue
        augmented = dict(entry)
        augmented["_status"] = status
        augmented["_resolved_path"] = resolve_pending_path(registry, entry)
        out.append(augmented)
    return out


def discover_personal_pendings_dir() -> Path:
    """Path of the personal pending dir at ~/.seif/pending/. Creates it if missing."""
    d = get_user_home() / PERSONAL_PENDING_DIR
    d.mkdir(parents=True, exist_ok=True)
    return d


def discover_team_pendings_dir(workspace_seif: Path) -> Path:
    """Path of the team pending dir at <workspace>/.seif/pending/."""
    return workspace_seif / "pending"


def mark_pending_consumed(
    registry: dict,
    entry: dict,
    consumed_in_cycle: Optional[str] = None,
) -> bool:
    """Mark a pending module as consumed by writing status into the source file.

    Updates the source module's `status` field to "consumed" and adds
    `consumed_at` + `consumed_in_cycle` metadata. Registry index is left
    intact — discovery still finds it but list_open_pendings filters it out.

    Returns True on success, False if the source file is missing.
    """
    path = resolve_pending_path(registry, entry)
    if path is None:
        return False
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return False
    data["status"] = "consumed"
    data["consumed_at"] = datetime.now(timezone.utc).isoformat()
    if consumed_in_cycle:
        data["consumed_in_cycle"] = consumed_in_cycle
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    return True
