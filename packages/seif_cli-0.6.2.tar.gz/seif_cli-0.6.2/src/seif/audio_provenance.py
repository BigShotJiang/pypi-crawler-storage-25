"""Audio-side AI artifact provenance bridge (Wedge A v1.0 DoD #5 — audio).

Bridges the canonical SEIF envelope (from ``provenance_sign`` /
``seif --log-submit``) and the engineer-honest infrasound watermark
(``seif.generators.watermark``).

The narrative this enables:

1. AI produces an artifact (a podcast, a synthetic voiceover, a music
   stem). The text representation can be `provenance_sign`-ed to a
   canonical envelope with a 64-char hex ``content_sha256``.
2. That ``content_sha256`` (or a transparency-log ``entry_id``) is
   embedded as a sub-20 Hz watermark on the audio carrier via
   ``seif.generators.watermark.embed_watermark_wav``.
3. **The audio file now carries cryptographic provenance.** Anyone
   with the audio + the envelope JSON can call
   :func:`verify_audio_against_envelope` and confirm: the watermarked
   hash matches the envelope's ``content_sha256``, which (combined with
   ``provenance_verify``) proves the envelope's signature is valid for
   the original artifact.

This closes the "provenance is just for text" market objection without
mysticism: it's standard sub-20 Hz steganography + standard SHA-256
hex matching. No psychoacoustic claims, no perceptual-coding bullshit.
The 64-char sha256 hex is what gets compared, byte-for-byte.

The CLI surface is ``seif --verify-audio-provenance INPUT.wav --envelope env.json``
and the MCP surface is ``seif_audio_provenance_verify`` (registered by
``seif --mcp-watermark``).
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any


DEFAULT_N_SYMBOLS = 64  # sha256 hex digest length


def verify_audio_against_envelope(
    input_wav: str | Path,
    envelope: dict[str, Any],
    *,
    n_symbols: int = DEFAULT_N_SYMBOLS,
    repetitions: int = 3,
    symbol_duration: float = 4.0,
    freq_spacing_hz: float | None = None,
) -> dict[str, Any]:
    """Extract the watermark from ``input_wav`` and compare to the
    envelope's ``content_sha256`` (sha256 of the original artifact).

    Returns a dict with deterministic shape:

        {
          "ok": True,
          "valid": <bool>,
          "extracted": "<64-char hex from audio>",
          "expected_content_sha256": "<envelope.content_sha256>",
          "input_wav": "<resolved path>",
          "n_symbols": <int>,
        }

    On structural error (envelope missing the field, audio unreadable,
    bad watermark config) returns ``{ok: false, error: <message>}``
    without raising — keeps the MCP / CLI surfaces uniform.

    The function does NOT verify the envelope's Ed25519 signature —
    that's ``provenance_verify``'s job, run separately against the
    original payload. Splitting concerns lets callers say "this audio
    binds to this envelope" and "this envelope binds to this signed
    artifact" as two independent claims.
    """
    expected = envelope.get("content_sha256") if isinstance(envelope, dict) else None
    if not expected or not _is_sha256_hex(expected):
        return {
            "ok": False,
            "error": "envelope_missing_or_invalid_content_sha256",
        }

    # Lazy-import the watermark + numpy stack so non-audio callers
    # don't pay the import cost.
    try:
        from seif.generators.watermark import (
            WatermarkConfig,
            WatermarkError,
            extract_watermark_wav,
        )
    except ImportError as e:
        return {
            "ok": False,
            "error": "watermark_extra_missing",
            "detail": str(e),
        }

    config_kwargs: dict[str, Any] = {
        "repetitions": repetitions,
        "symbol_duration": symbol_duration,
    }
    if freq_spacing_hz is not None:
        config_kwargs["freq_spacing_hz"] = freq_spacing_hz
    config = WatermarkConfig(**config_kwargs)
    try:
        extracted = extract_watermark_wav(str(input_wav), n_symbols, config)
    except (FileNotFoundError, OSError) as e:
        return {"ok": False, "error": "input_wav_unreadable", "detail": str(e)}
    except WatermarkError as e:
        return {"ok": False, "error": "watermark_extract_failed", "detail": str(e)}

    return {
        "ok": True,
        "valid": extracted == expected,
        "extracted": extracted,
        "expected_content_sha256": expected,
        "input_wav": str(input_wav),
        "n_symbols": n_symbols,
    }


def verify_audio_against_envelope_file(
    input_wav: str | Path,
    envelope_path: str | Path,
    **kwargs: Any,
) -> dict[str, Any]:
    """Convenience wrapper: load envelope from a JSON file then verify."""
    p = Path(envelope_path)
    if not p.exists() or not p.is_file():
        return {
            "ok": False,
            "error": "envelope_file_not_found",
            "detail": str(p),
        }
    try:
        envelope = json.loads(p.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        return {
            "ok": False,
            "error": "envelope_file_not_valid_json",
            "detail": str(e),
        }
    return verify_audio_against_envelope(input_wav, envelope, **kwargs)


def _is_sha256_hex(value: Any) -> bool:
    if not isinstance(value, str) or len(value) != 64:
        return False
    try:
        int(value, 16)
        return True
    except ValueError:
        return False
