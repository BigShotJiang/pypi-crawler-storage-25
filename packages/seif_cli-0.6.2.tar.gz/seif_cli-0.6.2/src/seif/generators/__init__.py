"""SEIF generators — produce derivative artifacts from text/spec inputs.

Currently exposes the audio watermark MVP. Other historical references
(harmonic_audio, dual_qr, fractal QR) are out of scope here and will land
in dedicated PRs as needed.
"""
