"""Audio watermark MVP — multi-frequency infrasound encoding (Phase 1).

Embeds a short text payload (typically a sha256 hex digest) as a sequence
of sub-20Hz tones overlaid on a carrier WAV. Decoding extracts the payload
via per-symbol FFT peak detection.

This is a demonstration substrate for the AI Artifact Provenance demo
(Wedge A v1.0). The encoding is intentionally simple — a small alphabet
(default: 16 hex chars), one tone per symbol, repetition coding for noise
resilience, evenly-spaced tones in the 1-16 Hz band so a typical speech
or music carrier carries minimal energy in the same band.

Limitations (documented; not bugs):
  - Mono 16-bit PCM only.
  - No robustness against lossy re-encoding (mp3 → wav round-trips).
  - Sub-20Hz tones can leak energy into low-end speakers; humans
    typically cannot perceive them, but vibration may be felt at high
    amplitude. Default amplitude is 0.005 (-46 dBFS-ish) to stay imperceptible.
"""

from __future__ import annotations

import wave
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np


DEFAULT_ALPHABET = "0123456789abcdef"
DEFAULT_FREQ_LO_HZ = 1.0
DEFAULT_FREQ_SPACING_HZ = 1.0


class WatermarkError(ValueError):
    """Watermark embed/extract failure."""


@dataclass
class WatermarkConfig:
    """Encoding parameters for embed_watermark_wav / extract_watermark_wav."""

    alphabet: str = DEFAULT_ALPHABET
    freq_lo_hz: float = DEFAULT_FREQ_LO_HZ
    freq_spacing_hz: float = DEFAULT_FREQ_SPACING_HZ
    symbol_duration: float = 4.0
    repetitions: int = 3
    amplitude: float = 0.005
    sample_rate: int = 44100

    def freq_for_index(self, idx: int) -> float:
        return self.freq_lo_hz + idx * self.freq_spacing_hz

    @property
    def freq_band(self) -> tuple[float, float]:
        return (self.freq_lo_hz, self.freq_for_index(len(self.alphabet) - 1))

    def validate_text(self, text: str) -> None:
        unknown = sorted(set(text) - set(self.alphabet))
        if unknown:
            raise WatermarkError(
                f"text contains chars outside alphabet {self.alphabet!r}: {unknown!r}"
            )

    def samples_per_repetition(self) -> int:
        return int(round(self.symbol_duration * self.sample_rate))

    def samples_per_symbol(self) -> int:
        return self.samples_per_repetition() * self.repetitions


def _tone(freq_hz: float, n_samples: int, sample_rate: int, amplitude: float) -> np.ndarray:
    t = np.arange(n_samples, dtype=np.float64) / sample_rate
    return amplitude * np.sin(2.0 * np.pi * freq_hz * t)


def _read_wav_mono16(path: Path) -> tuple[np.ndarray, int]:
    with wave.open(str(path), "rb") as w:
        if w.getnchannels() != 1:
            raise WatermarkError(f"expected mono WAV, got {w.getnchannels()} channels")
        if w.getsampwidth() != 2:
            raise WatermarkError(f"expected 16-bit PCM, got {w.getsampwidth()*8}-bit")
        sample_rate = w.getframerate()
        frames = w.readframes(w.getnframes())
    samples = np.frombuffer(frames, dtype=np.int16).astype(np.float64) / 32768.0
    return samples, sample_rate


def _write_wav_mono16(path: Path, samples: np.ndarray, sample_rate: int) -> None:
    clipped = np.clip(samples, -1.0, 1.0)
    pcm = (clipped * 32767.0).astype(np.int16)
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sample_rate)
        w.writeframes(pcm.tobytes())


def _build_payload_signal(text: str, config: WatermarkConfig) -> np.ndarray:
    config.validate_text(text)
    if not text:
        return np.zeros(0, dtype=np.float64)
    rep_samples = config.samples_per_repetition()
    chunks: list[np.ndarray] = []
    for ch in text:
        idx = config.alphabet.index(ch)
        freq = config.freq_for_index(idx)
        rep_tone = _tone(freq, rep_samples, config.sample_rate, config.amplitude)
        for _ in range(config.repetitions):
            chunks.append(rep_tone)
    return np.concatenate(chunks)


def embed_watermark_wav(
    text: str,
    input_wav: str | Path,
    output_wav: str | Path,
    config: WatermarkConfig | None = None,
) -> dict:
    """Overlay text payload as multi-frequency tones onto input WAV.

    If the carrier is shorter than the payload, it is right-padded with
    silence to fit. Returns a metadata dict for CLI display.
    """
    config = config or WatermarkConfig()
    input_path = Path(input_wav)
    output_path = Path(output_wav)

    carrier, carrier_sr = _read_wav_mono16(input_path)
    if carrier_sr != config.sample_rate:
        raise WatermarkError(
            f"carrier sample_rate {carrier_sr} != config.sample_rate {config.sample_rate}; "
            f"resample upstream or set config.sample_rate to match"
        )

    payload = _build_payload_signal(text, config)
    if payload.size > carrier.size:
        carrier = np.concatenate([carrier, np.zeros(payload.size - carrier.size)])

    mixed = carrier.copy()
    mixed[: payload.size] += payload

    _write_wav_mono16(output_path, mixed, config.sample_rate)

    return {
        "text": text,
        "symbols": len(text),
        "repetitions": config.repetitions,
        "duration_seconds": payload.size / config.sample_rate,
        "carrier_duration": carrier.size / config.sample_rate,
        "freq_band_hz": config.freq_band,
        "output_path": str(output_path),
    }


def extract_watermark_wav(
    input_wav: str | Path,
    n_symbols: int,
    config: WatermarkConfig | None = None,
) -> str:
    """Recover text payload from a watermarked WAV.

    Slices the leading payload region into symbol windows, FFT-detects the
    dominant tone in the configured band per repetition, and majority-votes
    across repetitions for each symbol.
    """
    config = config or WatermarkConfig()
    if n_symbols <= 0:
        return ""
    samples, sr = _read_wav_mono16(Path(input_wav))
    if sr != config.sample_rate:
        raise WatermarkError(
            f"WAV sample_rate {sr} != config.sample_rate {config.sample_rate}"
        )

    rep_samples = config.samples_per_repetition()
    sym_samples = config.samples_per_symbol()
    needed = n_symbols * sym_samples
    if samples.size < needed:
        raise WatermarkError(
            f"audio too short: have {samples.size} samples, need {needed} "
            f"for {n_symbols} symbols × {config.repetitions} reps × "
            f"{config.symbol_duration}s @ {config.sample_rate}Hz"
        )

    candidate_freqs = np.array(
        [config.freq_for_index(i) for i in range(len(config.alphabet))],
        dtype=np.float64,
    )

    decoded: list[str] = []
    for sym_i in range(n_symbols):
        votes: dict[str, int] = {}
        for rep_i in range(config.repetitions):
            start = sym_i * sym_samples + rep_i * rep_samples
            window = samples[start : start + rep_samples]
            ch = _detect_symbol(window, config, candidate_freqs)
            votes[ch] = votes.get(ch, 0) + 1
        winner = max(votes.items(), key=lambda kv: kv[1])[0]
        decoded.append(winner)
    return "".join(decoded)


def _detect_symbol(
    window: np.ndarray,
    config: WatermarkConfig,
    candidate_freqs: np.ndarray,
) -> str:
    """Per-window: find which candidate frequency has the strongest FFT response."""
    n = window.size
    if n == 0:
        return config.alphabet[0]
    spectrum = np.fft.rfft(window * np.hanning(n))
    bin_freqs = np.fft.rfftfreq(n, d=1.0 / config.sample_rate)
    powers = np.abs(spectrum)

    best_idx = 0
    best_power = -1.0
    for idx, f in enumerate(candidate_freqs):
        bin_idx = int(np.argmin(np.abs(bin_freqs - f)))
        p = powers[bin_idx]
        if p > best_power:
            best_power = p
            best_idx = idx
    return config.alphabet[best_idx]


def file_sha256_hex(path: str | Path) -> str:
    """Raw sha256 of file bytes, lowercase hex digest. Used by --fingerprint-of."""
    import hashlib

    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()
