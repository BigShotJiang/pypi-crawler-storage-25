# Decisions pending — operator inbox

> Items needing **human** choice. AI assistants: **do not** close items here
> unilaterally unless the operator said so in this session.

## Open

- _(none)_

## Resolved

> Move or summarize here when decided; keep a **one-line** record (date + outcome).

---

**A25:** If the same decision is also tracked in a `.seif` pending module or a
ticket system, **one** place should be primary — link the others, do not maintain
conflicting text.
