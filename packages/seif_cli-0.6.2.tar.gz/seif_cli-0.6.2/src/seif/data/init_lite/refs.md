# Canonical references (A25)

> Fill this table with **links** to authoritative facts. Do **not** paste full
> specifications here — **one canonical home** per topic.

| Name | Where | How to verify / notes |
|------|--------|------------------------|
| _(example)_ | _URL or repo path_ | _e.g. "latest on main", "contract v3"_ |

**Rule:** if a prose note in this folder repeats what a canonical row already
states in detail, the prose should be shortened to a **pointer** (A25).
