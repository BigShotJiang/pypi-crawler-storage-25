# BOOT.md — mechanical session checklist (SEIF Lite)

> **Mechanical** steps each session. **`AGENTS.md`** is the **contract**; this file
> is the **checklist**. Both matter.

## Every session (human or AI)

1. Read **`AGENTS.md`** at the workspace root.
2. Read **this file** (`.seif-lite/BOOT.md`).
3. Read **`decisions-pending.md`** — do not resolve blocked items without the operator.
4. Read the **last 1–2** entries in **`session-log.md`** (newest at bottom).
5. If you rely on external truth, confirm paths/URLs in **`refs.md`** are still current.
6. **Before ending:** append **`session-log.md`** (what was done, what is pending).

## Common mistakes

| Mistake | Fix |
|---------|-----|
| Skipping `AGENTS.md` | Read it first — it prevents scope and policy errors. |
| Duplicating the backlog | Use **one** queue (`decisions-pending.md` or an agreed external system). |
| Claiming SEIF verification without `.seif/` | Say **Lite** honestly; upgrade with `seif --init` full when needed. |

## Quick open (edit paths to your editor)

```text
AGENTS.md
.seif-lite/BOOT.md
decisions-pending.md
session-log.md
.seif-lite/refs.md
```

If you execute substantive work before steps 1–4, you are out of process for this
workspace.
