# Session log — append only

> Newest entries at the **bottom**. Do not rewrite past entries; add a correction
> as a new paragraph if needed.

---

## Session 0 — {{INIT_DATE}} — scaffold

**Workspace:** {{PROJECT_TITLE}}

**What was done:** Created with `seif --init --lite`.

**Next steps (suggested):** Fill `decisions-pending.md` and `.seif-lite/refs.md`;
confirm `AGENTS.md` matches your team policies.

---
