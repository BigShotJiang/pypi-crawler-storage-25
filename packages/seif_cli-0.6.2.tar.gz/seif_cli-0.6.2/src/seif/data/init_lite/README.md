# {{PROJECT_TITLE}} — SEIF Lite workspace

This folder uses **SEIF Lite**: a **lightweight, provenance-oriented** layout for
collaboration on documents, strategy, research, decks, reports, or other
**non-code-first** work — without requiring the full SEIF cryptographic workspace
(`.seif/`, kernel, module signing) on day one.

**Start here:** read [`AGENTS.md`](AGENTS.md) (cross-tool AI contract), then
[`.seif-lite/BOOT.md`](.seif-lite/BOOT.md) (session checklist).

---

## What SEIF Lite is

| Full SEIF workspace (`seif --init`) | SEIF Lite (`seif --init --lite`) |
|-------------------------------------|-----------------------------------|
| `.seif/`, `RESONANCE.json`, signing, module schemas | **Discipline + references + session continuity** only |
| Best for engineering repos and protocol work | Best for **knowledge work** where humans and AI co-author |

SEIF Lite is **honest**: it does **not** claim tamper-evident modules unless you
later run **`seif --init`** (full) in the same tree or attach external attestations.

SEIF Lite é o ponto de entrada ideal para quem quer disciplina de proveniência sem o overhead criptográfico completo.

---

## Product focus: **Wedge A — AI artifact provenance** (conceptual)

Even in Lite mode, this layout is aligned with the **AI artifact provenance**
story: *who produced what, under which sensitivity label, and (when you use the
tools) with which verifiable hashes.*

- **Classification:** treat material as **PUBLIC / INTERNAL / CONFIDENTIAL** in your
  own policy; do not paste secrets into AI chats marked PUBLIC.
- **Transparency log (optional):** when your organization runs a SEIF
  transparency log service and your CLI supports it, you can record **hashes and
  metadata** of important exports (e.g. `seif --log-submit`). Configure
  **`SEIF_LOG_URL`** and credentials per your operator — see public SEIF CLI docs.
- **MCP:** Model Context Protocol carries **context** between tools; SEIF-style
  discipline is **complementary** — it adds governance and attestation habits, not
  a replacement for MCP.

---

## A25 — single source of truth

**Axiom A25 (spirit):** every structured fact should have **one** canonical home.
If a decision, roadmap, or backlog already lives in a ticket system or a signed
`.seif` module elsewhere, **link it** in [`.seif-lite/refs.md`](.seif-lite/refs.md)
and do **not** maintain a parallel prose clone here. Documentation may **summarize**
and **point**; it must not **fork** the authoritative record.

Use **`decisions-pending.md`** as the **only** informal decision queue *inside this
folder*, unless your team agrees a different single surface (then say so in
`AGENTS.md` once).

---

## Suggested layout (customize freely)

You may add subfolders (`notes/`, `deliverables/`, etc.). Keep **root** `README.md`,
`AGENTS.md`, `session-log.md`, and `decisions-pending.md` discoverable.

---

## Living document

Update `README.md` when the scope of {{PROJECT_TITLE}} changes. Prefer dated notes
in `session-log.md` over silent rewrites.

**Initialized:** {{INIT_DATE}} with `seif --init --lite`.
