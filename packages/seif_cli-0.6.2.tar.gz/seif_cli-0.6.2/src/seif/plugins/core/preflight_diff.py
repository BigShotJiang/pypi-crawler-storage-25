"""Preflight diff check — sibling-session HEAD-drift detection.

s42 awareness MVP, primitive #3 of 5 (per project_parallel_session_awareness
memory + P8.1 seed §7). Companion: session_registry.py (primitive #1).

Purpose: at session-start, after registering this session, compare the
current HEAD of each tracked repo against what active siblings observed
when they registered. If any sibling observed a different HEAD on a repo
this session also tracks, surface a warning so the operator knows their
plan may be invalidated by sibling commits.

Scope (MVP):
  - Auto-discovery: immediate-child .git directories of the workspace
    root. Matches the multi-repo workspace layout used at
    /Volumes/DockerData/seif-projects/.
  - One-shot at session-start (not gating destructive operations — that's
    a separate s42 follow-up).
  - Warning-only — never blocks.
"""

from __future__ import annotations

import subprocess
from pathlib import Path


def discover_repos(workspace_root: Path) -> list[Path]:
    """Find immediate-child directories of workspace_root that are git
    repos. Returns sorted-by-name absolute paths. Skips dotfile dirs
    (`.git`, `.cache`, etc.) and the workspace_root itself."""
    if not workspace_root.is_dir():
        return []
    repos: list[Path] = []
    for child in sorted(workspace_root.iterdir()):
        if not child.is_dir():
            continue
        if child.name.startswith("."):
            continue
        if (child / ".git").exists():
            repos.append(child.resolve())
    return repos


def _git_head(repo: Path) -> str | None:
    """Return current HEAD sha for a repo, or None if git is unavailable
    or the call fails (treated as 'unknown' — never crashes the hook)."""
    try:
        result = subprocess.run(
            ["git", "-C", str(repo), "rev-parse", "HEAD"],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired, OSError):
        return None
    if result.returncode != 0:
        return None
    sha = result.stdout.strip()
    return sha or None


def current_heads(repos: list[Path]) -> dict[str, str]:
    """Map repo basename → current HEAD. Repos with unreadable HEAD are
    silently dropped from the result (warning surface treats absent ==
    'we have no opinion to compare against')."""
    out: dict[str, str] = {}
    for r in repos:
        head = _git_head(r)
        if head:
            out[r.name] = head
    return out


def detect_sibling_drift(
    my_observed: dict[str, str],
    sibling_entries: list[dict],
) -> list[dict]:
    """Compare my observed HEADs against each sibling's observed HEADs.
    For each repo where a sibling observed a different sha, return a row:
      {
        "repo": "seif",
        "my_sha": "abc...",
        "sibling_session_id": "<uuid>",
        "sibling_wrapper": "claude-code",
        "sibling_host": "air-m1",
        "sibling_pid": 9876,
        "sibling_started_at": "...",
        "sibling_sha": "def...",
      }
    A sibling that observed the same sha is NOT in the output. A sibling
    that didn't observe a repo I observed is also not in the output (no
    conflict to surface)."""
    rows: list[dict] = []
    for entry in sibling_entries:
        s_repos = entry.get("repos_observed", {}) or {}
        for repo_name, my_sha in my_observed.items():
            sibling_sha = s_repos.get(repo_name)
            if sibling_sha and sibling_sha != my_sha:
                rows.append({
                    "repo": repo_name,
                    "my_sha": my_sha,
                    "sibling_session_id": entry.get("session_id", ""),
                    "sibling_wrapper": entry.get("wrapper", ""),
                    "sibling_host": entry.get("host", ""),
                    "sibling_pid": entry.get("pid", 0),
                    "sibling_started_at": entry.get("started_at", ""),
                    "sibling_sha": sibling_sha,
                })
    return rows


def render_warning_block(
    sibling_entries: list[dict],
    drift: list[dict],
) -> str:
    """Render the awareness warning block for session-start output.
    Returns empty string if no siblings AND no drift (suppress noise)."""
    if not sibling_entries and not drift:
        return ""

    lines: list[str] = []
    lines.append("═══ AWARENESS ════════════════════════════════════════")
    lines.append(f"  active siblings: {len(sibling_entries)}")
    for s in sibling_entries:
        lines.append(
            f"    {s.get('wrapper','?')} @ {s.get('host','?')} "
            f"(pid {s.get('pid','?')}, started {s.get('started_at','?')})"
        )
    if drift:
        lines.append(f"  ⚠ sibling state diverges on {len(drift)} repo(s):")
        for d in drift:
            lines.append(
                f"    {d['repo']}: sibling at {d['sibling_sha'][:7]}... "
                f"— you observed {d['my_sha'][:7]}..."
            )
        lines.append(
            "    Verify before issuing seeds or making cross-repo changes."
        )
    lines.append("═══════════════════════════════════════════════════════")
    return "\n".join(lines)
