"""Cycle re-seal — codified amendment-chain mechanism for SEALED cycles.

s59 PR5 (companion to s58 PR1/PR2/PR3 + s59 PR4 seal-guard). Replaces the
ad-hoc s52 convention (flat ``re_sealed_at`` + ``re_seal_rationale`` fields
written manually) with a structured, append-only ``re_seal_history[]``
block on the SEALED cycle file.

Each entry:

    {
        "re_sealed_at":      ISO-8601 UTC timestamp,
        "re_seal_rationale": str (operator-provided),
        "deltas":            list[str] (operator-provided list of changes),
        "re_sealed_by":      str (host fingerprint / wrapper / actor)
    }

Amendment-chain semantics (per feedback_amendment_chain_over_host_resign):

  - The SEALED cycle's original body is never mutated.
  - Each call to ``re_seal_cycle`` APPENDS to ``re_seal_history[]``.
  - If the SEALED file carries the legacy flat fields (s52 pattern), the
    first call to ``re_seal_cycle`` migrates them into a synthesized
    history entry BEFORE appending the new entry, so no historical context
    is lost. The legacy flat fields are left in place (read-only by the
    legacy path is fine; new readers should consume ``re_seal_history[]``).

CLI surface:

    seif --re-seal-cycle <slug> --rationale <text>
                                --delta-list '[\"d1\",\"d2\"]' | --delta-list path/to/list.json

Refuses to operate on:
  - Cycles that don't exist (no <slug>-SEALED.seif file).
  - Cycles that are still OPEN (no SEALED file). The operator must first
    seal via ``seif --close-cycle`` (which now goes through the s59 PR4
    seal-guard).
"""

from __future__ import annotations

import datetime
import json
import os
import socket
from pathlib import Path
from typing import Optional, Union


def _now_iso_utc() -> str:
    return datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _default_actor() -> str:
    """Best-effort actor identifier when caller doesn't pass one explicitly."""
    parts: list[str] = []
    wrapper = os.environ.get("SEIF_WRAPPER")
    if wrapper:
        parts.append(wrapper)
    fp = os.environ.get("SEIF_HOST_FINGERPRINT") or os.environ.get("SEIF_HOST_FP")
    if fp:
        parts.append(f"fp={fp[:16]}")
    try:
        parts.append(f"host={socket.gethostname()}")
    except Exception:
        pass
    return " / ".join(parts) if parts else "unknown"


def _resolve_workspace(workspace: Optional[Union[Path, str]]) -> Path:
    ws = Path(workspace) if workspace else Path.cwd()
    ws = ws.resolve()
    if not (ws / ".seif").is_dir():
        raise ValueError(
            f"workspace {ws} has no .seif/ — run `seif --init` there first"
        )
    return ws


def _coerce_deltas(deltas: Union[list, str, None]) -> list[str]:
    """Normalize the deltas argument into a list[str]. Accepts:

      - already-list[str]: returned as-is (after str() coercion)
      - JSON string of a list: parsed and coerced
      - filesystem path to a JSON file containing a list: read + parsed
      - None: returns []
    """
    if deltas is None:
        return []
    if isinstance(deltas, list):
        return [str(x) for x in deltas]
    if isinstance(deltas, str):
        # Heuristic: starts with '[' → treat as JSON literal; else try as path
        stripped = deltas.strip()
        if stripped.startswith("["):
            try:
                data = json.loads(stripped)
            except json.JSONDecodeError as e:
                raise ValueError(f"--delta-list looks like JSON but failed to parse: {e}")
            if not isinstance(data, list):
                raise ValueError(
                    f"--delta-list JSON must decode to a list; got {type(data).__name__}"
                )
            return [str(x) for x in data]
        path = Path(stripped).expanduser()
        if not path.is_file():
            raise ValueError(
                f"--delta-list '{stripped}' is neither a JSON list literal nor an existing file"
            )
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as e:
            raise ValueError(f"--delta-list file {path} contained invalid JSON: {e}")
        if not isinstance(data, list):
            raise ValueError(
                f"--delta-list file {path} must contain a JSON list; got {type(data).__name__}"
            )
        return [str(x) for x in data]
    raise ValueError(f"--delta-list type {type(deltas).__name__} not supported")


def _migrate_legacy_flat_fields(sealed: dict) -> Optional[dict]:
    """If the SEALED file carries the s52-style flat ``re_sealed_at`` /
    ``re_seal_rationale`` fields and ``re_seal_history`` is absent, return a
    synthesized first history entry capturing them. Otherwise return None.
    """
    if "re_seal_history" in sealed:
        return None
    legacy_at = sealed.get("re_sealed_at")
    legacy_rationale = sealed.get("re_seal_rationale")
    if not legacy_at and not legacy_rationale:
        return None
    return {
        "re_sealed_at": legacy_at or "unknown",
        "re_seal_rationale": legacy_rationale or "(legacy flat field, no rationale recorded)",
        "deltas": [],
        "re_sealed_by": "legacy-pre-PR5 (migrated)",
        "_migrated_from_legacy_flat_fields": True,
    }


def re_seal_cycle(
    slug: str,
    *,
    rationale: str,
    deltas: Union[list, str, None] = None,
    workspace: Optional[Union[Path, str]] = None,
    actor: Optional[str] = None,
) -> dict:
    """Append a new entry to the SEALED cycle's ``re_seal_history[]``.

    Returns a dict: {status: 'resealed' | 'error', cycle_id, sealed_path,
    history_length, entry, message}.
    """
    if not isinstance(slug, str) or not slug:
        return {"status": "error", "message": "slug is required and must be a non-empty string"}
    if not isinstance(rationale, str) or not rationale.strip():
        return {"status": "error", "message": "rationale is required and must be a non-empty string"}

    try:
        ws = _resolve_workspace(workspace)
    except ValueError as e:
        return {"status": "error", "message": str(e)}

    try:
        delta_list = _coerce_deltas(deltas)
    except ValueError as e:
        return {"status": "error", "message": str(e)}

    sealed_path = ws / ".seif" / "cycles" / f"{slug}-SEALED.seif"
    open_path = ws / ".seif" / "cycles" / f"{slug}-OPEN.seif"

    if not sealed_path.is_file():
        if open_path.is_file():
            return {
                "status": "error",
                "message": (
                    f"Cycle '{slug}' is OPEN, not SEALED. Re-seal targets only "
                    f"already-sealed cycles. Run `seif --close-cycle {slug}` "
                    f"first (subject to PR4 seal-guard)."
                ),
            }
        return {
            "status": "error",
            "message": (
                f"No SEALED cycle found for slug '{slug}' "
                f"(looked at {sealed_path})."
            ),
        }

    try:
        sealed = json.loads(sealed_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as e:
        return {"status": "error", "message": f"failed to read {sealed_path}: {e}"}
    if not isinstance(sealed, dict):
        return {"status": "error", "message": f"{sealed_path} did not contain a JSON object"}

    history = sealed.get("re_seal_history")
    if history is not None and not isinstance(history, list):
        return {
            "status": "error",
            "message": (
                f"{sealed_path} has a non-list re_seal_history field "
                f"({type(history).__name__}); refusing to clobber"
            ),
        }
    if history is None:
        history = []
        legacy = _migrate_legacy_flat_fields(sealed)
        if legacy:
            history.append(legacy)

    new_entry = {
        "re_sealed_at": _now_iso_utc(),
        "re_seal_rationale": rationale.strip(),
        "deltas": delta_list,
        "re_sealed_by": actor or _default_actor(),
    }
    history.append(new_entry)
    sealed["re_seal_history"] = history

    sealed_path.write_text(json.dumps(sealed, indent=2), encoding="utf-8")

    return {
        "status": "resealed",
        "cycle_id": slug,
        "sealed_path": str(sealed_path),
        "history_length": len(history),
        "entry": new_entry,
        "message": (
            f"✅ Cycle '{slug}' re-sealed (entry #{len(history)} appended to "
            f"re_seal_history[]). Original body untouched per amendment-chain."
        ),
    }
