#!/usr/bin/env python3
"""SEIF Orchestra Probe — session-start model + circuit discovery.

Thin wrapper around `seif.context.model_probe`. Outputs the [MODEL ORCHESTRA]
block (under 500 tokens) for injection into Claude Code session context, and
refreshes `~/.seif/model_registry.json`.

The actual probe logic lives in seif.context.model_probe so that the same code
serves both the session-start hook and the `seif --probe-models` CLI command.
"""

import os
import sys
from pathlib import Path

# Allow this script to run before seif-cli is installed by adding src/ to path.
SRC = Path(__file__).resolve().parents[4]
if (SRC / "seif").is_dir():
    sys.path.insert(0, str(SRC))

from seif.context.model_probe import (
    probe_all, merge_cached_remote, write_registry, format_orchestra,
)


def main():
    # Hooks may run with a non-trivial machine label injected via env.
    machine_label = os.environ.get("SEIF_MACHINE_LABEL", "air-m1")
    result = probe_all(machine_label=machine_label)
    merge_cached_remote(result)
    print(format_orchestra(result))
    try:
        write_registry(result)
    except Exception:
        # Hook should never fail the session start; silent best-effort.
        pass


if __name__ == "__main__":
    main()
