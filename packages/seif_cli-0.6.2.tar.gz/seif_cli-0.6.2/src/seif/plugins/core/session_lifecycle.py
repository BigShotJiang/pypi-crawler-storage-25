#!/usr/bin/env python3
"""
SEIF session lifecycle — client-agnostic core.

Both session-start and session-end logic live here. AI client adapters
(claude-code, copilot, generic, ...) call this module via:

  - Shell shims for hook-capable clients (Claude Code, OpenCode, ...)
    e.g. session-start.sh runs:
      python3 session_lifecycle.py session-start --session-id $SID ...

  - Library import for hookless clients to render a static SEED at
    `seif --init` time (Copilot, Cursor, AGENTS.md, ...)
      from session_lifecycle import session_start_logic, SessionStartResult

Single source of truth for: locating .seif/, reading config, writing the
session contract, composing the SessionStart output text, and the
session-end CLOSURE/AUDIT/ABSORB phases (preserving the S30 atomic
write-back fix in absorb_phase via fcntl.flock).

Client-specific concerns NOT in core (live in adapter shim):
  - reading hook-input JSON (each client's hook contract differs)
  - injecting env vars into the client's runtime ($CLAUDE_ENV_FILE, etc.)
  - spawning background processes (shell-specific)
  - CIRCLE git auto-sync (currently shell-native; could move here later)
"""
from __future__ import annotations

import argparse
import fcntl
import json
import os
import re
import subprocess
import sys
import time
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path


def _normalize_session_id(session_id: str | None) -> str:
    """Return session_id if it's a canonical UUID, else mint a fresh one.

    Defense-in-depth for the s55 unknown.json regression: even if a wrapper
    or test passes a non-UUID string, downstream callers (registry,
    contract writer) receive a valid id. Pairs with the bash hook fallback
    in session-start.sh (s56 PR2 layer A).
    """
    if not isinstance(session_id, str) or not session_id.strip():
        return str(uuid.uuid4())
    candidate = session_id.strip()
    try:
        uuid.UUID(candidate)
        return candidate
    except ValueError:
        return str(uuid.uuid4())


# ── Path / IO helpers ──────────────────────────────────────────────────────

def find_seif_dir(cwd: Path, home: Path) -> Path | None:
    """Walk up from cwd looking for .seif/, fall back to ~/.seif/."""
    d = cwd.resolve()
    while d != d.parent:
        if (d / ".seif").is_dir():
            return d / ".seif"
        d = d.parent
    if (home / ".seif").is_dir():
        return home / ".seif"
    return None


def _read_json(path: Path) -> dict:
    try:
        return json.loads(path.read_text())
    except Exception:
        return {}


def _now_utc() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


# ── Config readers ─────────────────────────────────────────────────────────

def lifecycle_enabled(seif_dir: Path) -> bool:
    cfg = _read_json(seif_dir / "config.json")
    return bool(cfg.get("session_lifecycle", {}).get("enabled", False))


def conjugate_co_author(seif_dir: Path) -> str:
    cfg = _read_json(seif_dir / "config.json")
    cp = cfg.get("conjugate_pair", {})
    return cp.get("co_author", "") if cp.get("enabled") else ""


def autonomous_context_enabled(seif_dir: Path) -> bool:
    cfg = _read_json(seif_dir / "config.json")
    return bool(cfg.get("autonomous_context", False))


_CLOSURE_FILENAME_RE = re.compile(r"^session-(\d+)-closure\.seif$")


def _observed_session_numbers(session_dir: Path) -> list[int]:
    """Discover all session numbers visible on disk.

    Scans `session-*.json` for `session_number` int field AND filenames
    matching `session-{N}-closure.seif`. The filename is the canonical
    source for closures: closure files written under different schema
    revisions (some carry `session_number`, some only `session_id`
    string, some neither) all share the filename convention. Without
    parsing the filename, a closure-only state — e.g., `session-N.json`
    archived/missing while `session-N-closure.seif` remains — silently
    regressed the counter to N instead of N+1, and the next session
    started with the wrong attribution.
    """
    out: list[int] = []
    if not session_dir.is_dir():
        return out
    for sf in session_dir.glob("session-*.json"):
        try:
            n = json.loads(sf.read_text()).get("session_number")
            if isinstance(n, int):
                out.append(n)
        except Exception:
            continue
    for sf in session_dir.glob("session-*-closure.seif"):
        m = _CLOSURE_FILENAME_RE.match(sf.name)
        if m:
            try:
                out.append(int(m.group(1)))
            except ValueError:
                pass
        # Belt-and-braces: also try the inner field if present, in case
        # a future closure schema reverts to a different filename pattern.
        try:
            n = json.loads(sf.read_text()).get("session_number")
            if isinstance(n, int):
                out.append(n)
        except Exception:
            continue
    return out


def next_session_count(seif_dir: Path) -> int:
    """Authoritative next session number.

    mapper.session_count is written by absorb_phase at session-end. If
    session-end fails to fire (abrupt close, /clear, crash), the mapper
    goes stale and a naive `stored + 1` would clobber an existing
    session-N.json. We scan the sessions/ dir for observed session_number
    values (in both .json contracts and -closure.seif modules) and return
    max(stored, max(observed)) + 1.

    Missing mapper → 0 (preserves legacy shell fallback for fresh inits).
    """
    p = seif_dir / "mapper.json"
    if not p.is_file():
        return 0
    try:
        m = json.loads(p.read_text())
        stored = int(m.get("session_count", 0))
    except Exception:
        stored = 0
    observed_max = max(_observed_session_numbers(seif_dir / "sessions"), default=0)
    return max(stored, observed_max) + 1


_ORPHAN_RESCUE_WINDOW_SECONDS = 60


def claim_orphan_session_slot(seif_dir: Path, requested_session_id: str,
                              window_seconds: int = _ORPHAN_RESCUE_WINDOW_SECONDS
                              ) -> int | None:
    """Return the session_number of a recently-created orphan slot to claim.

    The bash hook falls back to session_id="unknown" when the JSON from the
    wrapper is malformed or the field is missing (cold-start race). That
    write produces a session-N.json with session_id="unknown" but the
    counter has already advanced. If the wrapper retries within seconds —
    or the user opens a fresh session immediately — `next_session_count()`
    advances again, leaving the orphan permanently bound to "unknown" and
    the new session attached one slot ahead. Two slots, one real session.

    This helper detects that case: scan the latest session-N.json; if its
    session_id is "unknown" AND its mtime is within window_seconds AND the
    caller has a real session_id (not "unknown"), return N. The caller
    overwrites session-N.json with the real session_id, claiming the slot.

    Returns None when no orphan exists, the latest is too old, or the
    caller is itself "unknown" (chain of unknowns is not a rescue).
    """
    if not requested_session_id or requested_session_id == "unknown":
        return None
    session_dir = seif_dir / "sessions"
    if not session_dir.is_dir():
        return None
    latest_n = -1
    latest_path: Path | None = None
    for sf in session_dir.glob("session-*.json"):
        try:
            n = json.loads(sf.read_text()).get("session_number")
            if not isinstance(n, int):
                continue
            if n > latest_n:
                latest_n = n
                latest_path = sf
        except Exception:
            continue
    if latest_path is None:
        return None
    try:
        latest_doc = json.loads(latest_path.read_text())
    except Exception:
        return None
    if latest_doc.get("session_id") != "unknown":
        return None
    age = time.time() - latest_path.stat().st_mtime
    if age > window_seconds:
        return None
    return latest_n


def persistence_routing_lines(seif_dir: Path) -> list[str]:
    cfg = _read_json(seif_dir / "config.json")
    rules = cfg.get("persistence_routing", {}).get("rules", {})
    overlap = cfg.get("persistence_routing", {}).get("overlap_resolution", "")
    out = [
        f"memory/: {rules.get('memory/', {}).get('what', [])}",
        f".seif/: {rules.get('.seif/', {}).get('what', [])}",
    ]
    if overlap:
        out.append(f"overlap: {overlap}")
    return out


# ── Session contract ───────────────────────────────────────────────────────

@dataclass
class SessionStartResult:
    seif_dir: Path
    session_count: int
    session_id: str
    session_type: str
    vigilant: str            # "NONE" or "CONFIGURED:<co-author>"
    co_author: str
    contract_path: Path
    output_text: str
    legacy_mode: bool = False  # lifecycle disabled or .seif/ missing


def write_session_contract(*, seif_dir: Path, session_count: int,
                           session_id: str, session_type: str, vigilant: str,
                           co_author: str, timestamp: str) -> Path:
    contract = {
        "protocol": "SEIF-SESSION-v1",
        "session_number": session_count,
        "session_id": session_id,
        "started_at": timestamp,
        "type": session_type,
        "writer": {"model": "claude", "role": "writer", "fs_access": True},
        "vigilant": {
            "model": co_author or "none",
            "role": "vigilant" if vigilant != "NONE" else "absent",
            "status": vigilant,
            "note": (
                "Configured but not active in CLI session. "
                "Single pole — reduced damping."
                if vigilant != "NONE"
                else "No vigilant. Writer applies self-damping "
                     "(confirm before irreversible actions)."
            ),
        },
        "persistence": {
            "memory/": ["user_profile", "feedback", "durable_decisions",
                        "project_status"],
            ".seif/": ["protocol_observations", "session_records",
                       "cross_ai_knowledge", "patterns", "intent"],
            "overlap_resolution": (
                "If only Claude Code needs it → memory/. "
                "If any AI might need it → .seif/."
            ),
        },
        "status": "ACTIVE",
    }
    session_dir = seif_dir / "sessions"
    session_dir.mkdir(parents=True, exist_ok=True)
    path = session_dir / f"session-{session_count}.json"
    path.write_text(json.dumps(contract, indent=2))
    return path


# ── Output composers ───────────────────────────────────────────────────────

def _run_core_script(core_dir: Path, name: str,
                     fallback_dir: Path | None = None,
                     extra_args: list[str] | None = None,
                     timeout: int = 5) -> str:
    """Run a core sibling script and return stdout.

    Resolution order (canonical first, legacy second):
      1. core_dir / "{name}.py" — the canonical install path populated by
         setup._install_core_scripts() at $HOME/.local/share/seif/core/.
         Always preferred when present.
      2. fallback_dir / "{name.replace('_','-')}.py" — legacy hyphen-named
         shim under $HOME/.local/share/seif/claude-code/scripts/. Kept for
         backward-compat with installs predating s54 T1 (which added
         kernel_seed.py to the canonical copy list). DEPRECATED: target
         removal cycle s56+ once the rollout window closes; the legacy
         path is NOT refreshed by `seif setup` for newly-tracked modules,
         so leaving it lingering risks a repeat of s54 (stale shim
         silently chosen because canonical was missing).
    """
    script = core_dir / f"{name}.py"
    if not script.is_file() and fallback_dir is not None:
        script = fallback_dir / f"{name.replace('_', '-')}.py"
    if not script.is_file():
        return ""
    cmd = ["python3", str(script)] + (extra_args or [])
    try:
        result = subprocess.run(cmd, capture_output=True, text=True,
                                timeout=timeout, check=False)
        return result.stdout.strip()
    except (subprocess.TimeoutExpired, OSError):
        return ""


def _mapper_top_modules(seif_dir: Path, n: int = 5) -> list[str]:
    m = _read_json(seif_dir / "mapper.json")
    modules = m.get("modules", [])
    out: list[str] = []
    if isinstance(modules, list):
        ranked = sorted(modules, key=lambda x: x.get("relevance", 0),
                        reverse=True)[:n]
        if ranked:
            out.append(f"[ACTIVE MODULES (top {n})]")
            for mod in ranked:
                out.append(
                    f"  [{mod.get('classification', 'PUBLIC')}] "
                    f"{mod.get('path', '?')} "
                    f"({mod.get('category', '?')}, "
                    f"relevance={mod.get('relevance', 0):.2f})"
                )
    elif isinstance(modules, dict):
        ranked = sorted(modules.items(),
                        key=lambda x: x[1].get("relevance", 0),
                        reverse=True)[:n]
        if ranked:
            out.append(f"[ACTIVE MODULES (top {n})]")
            for name, info in ranked:
                out.append(
                    f"  [{info.get('classification', 'PUBLIC')}] "
                    f"{name} ({info.get('category', '?')}, "
                    f"relevance={info.get('relevance', 0):.2f})"
                )
    return out


def _pending_observations(seif_dir: Path,
                          current_session_path: Path) -> list[str]:
    session_dir = seif_dir / "sessions"
    if not session_dir.is_dir():
        return []
    files = sorted(
        (p for p in session_dir.glob("session-*.json")
         if p != current_session_path),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )
    if not files:
        return []
    s = _read_json(files[0])
    obs = s.get("pending_observations", [])
    if not obs:
        return []
    out = ["[PENDING FROM LAST SESSION]"]
    for o in obs[:5]:
        out.append(f"  - {o}")
    return out


def _pending_modules_summary(seif_dir: Path) -> list[str]:
    """Surface SEIF-PENDING-v1/v2 modules at session-start so deferred work is
    visible in the first frame, never silently accumulating in
    .seif/modules/pending-*.seif. Closes the discoverability gap that let
    the 2026-05-01 dual-source-of-truth incident happen (cf. memory
    `feedback_pending_module_canonical`). v2 (gap-14 Piece A, s51)
    accepted alongside v1 for read-back-compat.

    Returns empty list when no pending modules exist or all are empty —
    sessions with nothing pending see nothing extra.
    """
    from seif.schemas import is_pending_module

    modules_dir = seif_dir / "modules"
    if not modules_dir.is_dir():
        return []
    pending_files = sorted(modules_dir.glob("pending-*.seif"))
    if not pending_files:
        return []

    rows: list[tuple[str, int, int, str]] = []  # (file, open, landed, title)
    total_open = 0
    total_landed = 0
    for f in pending_files:
        try:
            data = json.loads(f.read_text())
        except (json.JSONDecodeError, OSError):
            continue
        if not is_pending_module(data):
            continue
        items = data.get("items", [])
        if not isinstance(items, list):
            continue
        # Items stamped with `landed_at` are LANDED — kept for audit but
        # excluded from the active count so the surface tells the truth
        # about what still needs work.
        landed_n = sum(
            1 for i in items
            if isinstance(i, dict) and i.get("landed_at")
        )
        open_n = len(items) - landed_n
        title = str(data.get("title", f.stem))[:70]
        rows.append((f.name, open_n, landed_n, title))
        total_open += open_n
        total_landed += landed_n

    if not rows or (total_open == 0 and total_landed == 0):
        return []

    out = ["[PENDING MODULES — SEIF-PENDING-v1 canonical mechanism]"]
    landed_note = f", {total_landed} landed (not counted)" if total_landed else ""
    out.append(
        f"  ({total_open} open items across {len(rows)} module(s){landed_note} — "
        "triage at start of next cycle, not silently)"
    )
    for filename, open_n, landed_n, title in rows:
        suffix = f" (+{landed_n} landed)" if landed_n else ""
        out.append(f"  {filename}: {open_n} item(s){suffix} — {title}")
    return out


DAEMON_ACTIVITY_PREVIEW_REPLY = 80
DAEMON_ACTIVITY_PREVIEW_ECHO = 60
DAEMON_ACTIVITY_DEFAULT_MAX = 5
DAEMON_ACTIVITY_SEEN_CAP = 1000


def _run_daemon_activity_surface(home: Path,
                                 max_items: int = DAEMON_ACTIVITY_DEFAULT_MAX) -> str:
    """Phase 5c (s40 P4): surface unread daemon-mediated bus activity.

    Reads ~/.seif/circuit/outbox/resp-*.json files written by the on-host
    claude-responder daemon. Builds a "[DAEMON ACTIVITY]" block listing
    replies the daemon emitted on the user's behalf since this hook last
    surfaced (idempotent via a watermark file). Closes the visibility gap
    flagged in s39 P7 ('Air-claude estava parado' — the interactive session
    had no awareness its sibling daemon was talking on the bus).

    Surface-only; never deletes the daemon outbox (peer-drainer + circuitd
    own that path). Per feedback_silent_drainer_anti_pattern, this is read +
    surface, not drain — the watermark only tracks what the SESSION has
    already SHOWN, leaving the actual outbox intact for downstream consumers.

    Recognises both shapes:
      - SEIF-SEED-v1 envelope (post-s40 P1): node + reply + prompt echo
      - legacy {content, responder_tag, timestamp}: shows tagged content only
    """
    outbox = home / ".seif" / "circuit" / "outbox"
    if not outbox.is_dir():
        return ""

    seen_file = home / ".seif" / "session-daemon-activity-seen.json"
    try:
        seen_data = json.loads(seen_file.read_text()) if seen_file.is_file() else {}
        seen_names = set(seen_data.get("names", []))
    except Exception:
        seen_names = set()

    unread: list[Path] = []
    for f in sorted(outbox.glob("resp-*.json")):
        if f.name in seen_names:
            continue
        unread.append(f)
    if not unread:
        return ""

    lines = [
        f"[DAEMON ACTIVITY] {len(unread)} reply(ies) emitted by "
        f"claude-responder while you were away:"
    ]
    showable = unread[-max_items:]
    for f in showable:
        try:
            d = json.loads(f.read_text())
        except Exception:
            lines.append(f"  - {f.name} (unreadable)")
            continue
        ts = d.get("timestamp", "?")
        if d.get("schema") == "SEIF-SEED-v1" and isinstance(d.get("issued_by"), dict):
            node = d["issued_by"].get("node", "?")
            reply = d.get("my_reply_content") or d.get("content", "")
            echo_block = d.get("received_seed_echo") or {}
            echo = echo_block.get("prompt_preview", "") if isinstance(echo_block, dict) else ""
            reply_short = reply[:DAEMON_ACTIVITY_PREVIEW_REPLY].strip()
            echo_short = echo[:DAEMON_ACTIVITY_PREVIEW_ECHO].strip()
            lines.append(f'  - [{ts}] {node}: "{echo_short}…" → "{reply_short}…"')
        else:
            content = d.get("content", "")
            if isinstance(content, str) and content.startswith("[claude-responder] "):
                content = content[len("[claude-responder] "):]
            short = content[:DAEMON_ACTIVITY_PREVIEW_REPLY].strip() if isinstance(content, str) else ""
            lines.append(f'  - [{ts}] (legacy): "{short}…"')

    if len(unread) > max_items:
        lines.append(f"  - … and {len(unread) - max_items} earlier")
    lines.append(
        "Action: review and ACK to gatekeeper if relevant "
        "(per A23 / feedback_ai_ack_to_gatekeeper)."
    )

    new_seen_list = list(seen_names | {f.name for f in unread})
    if len(new_seen_list) > DAEMON_ACTIVITY_SEEN_CAP:
        new_seen_list = new_seen_list[-DAEMON_ACTIVITY_SEEN_CAP:]
    try:
        seen_file.parent.mkdir(parents=True, exist_ok=True)
        tmp = seen_file.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(
            {"names": new_seen_list, "watermark_ts": _now_utc()}, indent=2
        ))
        tmp.replace(seen_file)
    except Exception:
        pass  # best-effort: surface is more important than watermark persistence

    return "\n".join(lines)


def _run_a20_drain(core_dir: Path, fallback_dir: Path | None,
                   home: Path) -> str:
    """Phase 5b: A20 inbox drain. Some adapters opt-in via
    enable_inbox_drain=True (preserves S31 mirror divergence)."""
    monitor = core_dir / "circuit_monitor.py"
    if not monitor.is_file() and fallback_dir is not None:
        monitor = fallback_dir / "circuit-monitor.py"
    if not monitor.is_file():
        return ""

    try:
        subprocess.run(["python3", str(monitor), "--check-inbox"],
                       capture_output=True, timeout=5, check=False)
    except (subprocess.TimeoutExpired, OSError):
        return ""

    pending_file = home / ".seif" / "circuit" / "pending-messages.json"
    if not pending_file.is_file():
        return ""
    try:
        msgs = json.loads(pending_file.read_text())
        n = len(msgs)
    except Exception:
        return ""
    if n == 0:
        return ""

    try:
        drain = subprocess.run(
            ["python3", str(monitor), "--drain"],
            capture_output=True, text=True, timeout=5, check=False,
        )
        body = drain.stdout.strip()
    except (subprocess.TimeoutExpired, OSError):
        body = ""

    out = [f"[CIRCUIT INBOX] {n} message(s) accumulated while offline:"]
    if body:
        out.append(body)
    return "\n".join(out)


# ── session-start ──────────────────────────────────────────────────────────

def _run_awareness(seif_dir: Path, session_id: str, cwd: Path,
                   wrapper: str = "claude-code") -> str:
    """s42 awareness MVP: register this session, GC stale siblings, list
    active ones, and surface HEAD drift. Failures are silent (best-effort
    awareness must never block the hook)."""
    try:
        from seif.plugins.core.session_registry import (
            gc_stale, register, list_active,
        )
        from seif.plugins.core.preflight_diff import (
            current_heads, detect_sibling_drift, discover_repos,
            render_warning_block,
        )
    except ImportError:
        return ""

    try:
        gc_stale(seif_dir)
        workspace_root = seif_dir.parent
        repos = discover_repos(workspace_root)
        my_heads = current_heads(repos)
        siblings = list_active(seif_dir, exclude=[session_id])
        register(
            seif_dir=seif_dir, session_id=session_id,
            wrapper=wrapper, cwd=cwd, repo_heads=my_heads,
        )
        drift = detect_sibling_drift(my_heads, siblings)
        block = render_warning_block(siblings, drift)

        coherence_block = _render_coherence_violations(workspace_root)
        if coherence_block:
            block = (block + "\n" if block else "") + coherence_block

        return block
    except Exception:
        return ""


def _render_coherence_violations(workspace_root: Path) -> str:
    """s59 PR4 Layer B: surface class-(c) cycle ↔ session coherence
    violations at session-start. Class (a) and (b) are intentionally silent
    here per s59 q2 owner decision — operator runs `seif --audit-cycle-coherence`
    on demand for the advisory tiers.

    Best-effort: any failure returns empty string so the awareness block
    is never blocked by audit issues.
    """
    try:
        from seif.plugins.core.cycle_coherence import audit_cycle_coherence
        report = audit_cycle_coherence(workspace=workspace_root)
        if not report.has_violations:
            return ""
        violations = report.sealed_cycles_with_active_writer_sessions
        lines = [
            "═══ CYCLE COHERENCE ═══════════════════════════════════",
            f"  ✗ {len(violations)} class-(c) violation(s): "
            "SEALED cycles with active writer sessions",
        ]
        for f in violations:
            lines.append(f"    · {f.cycle_id}")
        lines.append(
            "  Run `seif --audit-cycle-coherence` for details, "
            "`seif --gc-stale` to clean."
        )
        lines.append("═══════════════════════════════════════════════════════")
        return "\n".join(lines)
    except Exception:
        return ""


def session_start_logic(*, session_id: str, cwd: Path, home: Path,
                        core_dir: Path | None = None,
                        fallback_script_dir: Path | None = None,
                        enable_inbox_drain: bool = False,
                        enable_daemon_activity: bool = False,
                        enable_awareness: bool = False,
                        wrapper: str = "claude-code"
                        ) -> SessionStartResult:
    session_id = _normalize_session_id(session_id)
    seif_dir = find_seif_dir(cwd, home)
    if seif_dir is None:
        return SessionStartResult(
            seif_dir=Path(), session_count=0, session_id=session_id,
            session_type="NONE", vigilant="NONE", co_author="",
            contract_path=Path(),
            output_text="[SEIF] No .seif/ context found. Run: seif --init",
            legacy_mode=True,
        )

    if not lifecycle_enabled(seif_dir):
        text = (f"[SEIF CONTEXT LOADED]\nPath: {seif_dir}\n"
                "Lifecycle: disabled (legacy mode)")
        return SessionStartResult(
            seif_dir=seif_dir, session_count=0, session_id=session_id,
            session_type="NONE", vigilant="NONE", co_author="",
            contract_path=Path(), output_text=text, legacy_mode=True,
        )

    co_author = conjugate_co_author(seif_dir)
    if co_author:
        vigilant = f"CONFIGURED:{co_author}"
        session_type = "SINGLE_POLE"
    else:
        vigilant = "NONE"
        session_type = "PRIVATE"

    orphan = claim_orphan_session_slot(seif_dir, session_id)
    if orphan is not None:
        session_count = orphan
    else:
        session_count = next_session_count(seif_dir)
    timestamp = _now_utc()
    contract_path = write_session_contract(
        seif_dir=seif_dir, session_count=session_count, session_id=session_id,
        session_type=session_type, vigilant=vigilant, co_author=co_author,
        timestamp=timestamp,
    )

    parts: list[str] = []

    # Phase 3.0: KERNEL seed
    if core_dir is not None:
        kernel = _run_core_script(core_dir, "kernel_seed",
                                  fallback_script_dir, timeout=3)
        if kernel:
            parts.append(kernel)
            parts.append("")

    # Phase 3: SEIF context + session contract + routing
    parts.append("[SEIF CONTEXT LOADED]")
    parts.append(f"Path: {seif_dir}")
    parts.append(f"Autonomous: {autonomous_context_enabled(seif_dir)}")
    parts.append("")
    parts.append("[SESSION CONTRACT]")
    parts.append(f"Session: #{session_count} ({session_id})")
    parts.append(f"Type: {session_type}")
    parts.append("Writer: claude (FS access)")
    parts.append(f"Vigilant: {vigilant}")
    parts.append(f"Started: {timestamp}")
    parts.append("")
    parts.append("[PERSISTENCE ROUTING]")
    parts.extend(persistence_routing_lines(seif_dir))
    parts.append("")

    top = _mapper_top_modules(seif_dir, 5)
    if top:
        parts.extend(top)
        parts.append("")

    pending = _pending_observations(seif_dir, contract_path)
    if pending:
        parts.extend(pending)
        parts.append("")

    pending_modules = _pending_modules_summary(seif_dir)
    if pending_modules:
        parts.extend(pending_modules)
        parts.append("")

    # Phase 4: Orchestra
    if core_dir is not None:
        orchestra = _run_core_script(core_dir, "orchestra_probe",
                                     fallback_script_dir, timeout=5)
        if orchestra:
            parts.append(orchestra)
            parts.append("")

    # Phase 5b (opt-in): A20 inbox drain. The src/seif/ mirror passes True;
    # the plugins/ tree leaves it False (preserves S31 mirror divergence).
    if enable_inbox_drain and core_dir is not None:
        drain_text = _run_a20_drain(core_dir, fallback_script_dir, home)
        if drain_text:
            parts.append(drain_text)

    # Phase 5c (s40 P4, opt-in): surface daemon-mediated bus activity to the
    # active session so it can ACK to gatekeeper (A23 visibility gap closure).
    if enable_daemon_activity:
        daemon_text = _run_daemon_activity_surface(home)
        if daemon_text:
            if parts and parts[-1] != "":
                parts.append("")
            parts.append(daemon_text)

    # Phase 5d (s42 awareness MVP, opt-in): sibling-session discovery + HEAD
    # drift surface. Suppresses output when no siblings AND no drift, so
    # solo sessions see no extra noise.
    if enable_awareness:
        awareness_text = _run_awareness(seif_dir, session_id, cwd, wrapper=wrapper)
        if awareness_text:
            if parts and parts[-1] != "":
                parts.append("")
            parts.append(awareness_text)

    return SessionStartResult(
        seif_dir=seif_dir, session_count=session_count, session_id=session_id,
        session_type=session_type, vigilant=vigilant, co_author=co_author,
        contract_path=contract_path,
        output_text="\n".join(parts).rstrip("\n"),
        legacy_mode=False,
    )


# ── session-end ────────────────────────────────────────────────────────────

@dataclass
class SessionEndResult:
    seif_dir: Path | None
    closed_session_path: Path | None
    audit_summary: str
    absorb_applied: bool
    legacy_mode: bool = False


def closure_phase(seif_dir: Path, timestamp: str,
                  closure_format: list[str]) -> Path | None:
    session_dir = seif_dir / "sessions"
    if not session_dir.is_dir():
        return None
    for sf in sorted(session_dir.glob("session-*.json"), reverse=True):
        try:
            s = json.loads(sf.read_text())
        except Exception:
            continue
        if s.get("status") != "ACTIVE":
            continue
        if "closure" not in s:
            s["closure"] = {field: [] for field in closure_format}
            s["closure_note"] = (
                "Auto-generated skeleton. AI did not produce closure "
                "during session."
            )
        s["status"] = "CLOSED"
        s["ended_at"] = timestamp
        sf.write_text(json.dumps(s, indent=2))
        return sf
    return None


def audit_phase(seif_dir: Path) -> str:
    mapper_path = seif_dir / "mapper.json"
    if not mapper_path.is_file():
        return "SKIP: no mapper"
    m = _read_json(mapper_path)
    modules = m.get("modules", [])
    if not isinstance(modules, list):
        return f"modules={len(modules)} format=dict"

    # Optional Separate Context Repo (SCR) fallback. When config.json
    # declares context_repo (e.g. "../seif-context", resolved lexically
    # relative to seif_dir), modules whose relative path resolves under
    # that root are present even if absent from seif_dir — preserves
    # the SCR boundary so historical archives stay in their own repo
    # while the live mapper indexes them. Uses lexical normalization
    # (os.path.normpath) rather than .resolve() so a symlinked seif_dir
    # (e.g. seif-projects/.seif → seif-admin/.seif) does not collapse
    # the parent traversal across the symlink target.
    cfg = _read_json(seif_dir / "config.json")
    ctx_repo_rel = cfg.get("context_repo")
    ctx_repo_dir: Path | None = None
    if isinstance(ctx_repo_rel, str) and ctx_repo_rel:
        candidate = Path(os.path.normpath(str(seif_dir / ctx_repo_rel)))
        if candidate.is_dir():
            ctx_repo_dir = candidate

    ghosts = 0
    for mod in modules:
        p = mod.get("path", "")
        if not p:
            continue
        full = Path(p) if Path(p).is_absolute() else (seif_dir / p)
        if full.exists():
            continue
        if ctx_repo_dir is not None and (ctx_repo_dir / p).exists():
            continue
        ghosts += 1
    return f"modules={len(modules)} ghosts={ghosts}"


def absorb_phase(seif_dir: Path, timestamp: str, decay: float = 0.02) -> bool:
    """Atomic read-modify-write under fcntl.flock. Preserves the S30 fix
    that prevents concurrent session-end races from clobbering session_count
    and overwriting session-N.json."""
    mapper_path = seif_dir / "mapper.json"
    session_dir = seif_dir / "sessions"
    if not mapper_path.is_file():
        return False

    lock_path = mapper_path.with_suffix(".json.lock")
    try:
        with open(lock_path, "w") as lf:
            fcntl.flock(lf.fileno(), fcntl.LOCK_EX)
            try:
                m = json.loads(mapper_path.read_text())

                modules = m.get("modules", [])
                if isinstance(modules, list):
                    for mod in modules:
                        rel = mod.get("relevance", 0.5)
                        mod["relevance"] = max(0.3, round(rel - decay, 4))
                elif isinstance(modules, dict):
                    for info in modules.values():
                        rel = info.get("relevance", 0.5)
                        info["relevance"] = max(0.3, round(rel - decay, 4))

                # Authoritative session_count = max(stored, max(observed))
                observed: list[int] = []
                if session_dir.is_dir():
                    for sf in session_dir.glob("session-*.json"):
                        try:
                            s = json.loads(sf.read_text())
                            n = s.get("session_number")
                            if isinstance(n, int):
                                observed.append(n)
                        except Exception:
                            continue
                if observed:
                    current = int(m.get("session_count", 0) or 0)
                    m["session_count"] = max(current, max(observed))

                m["last_session"] = timestamp

                tmp = mapper_path.with_suffix(".json.tmp")
                tmp.write_text(json.dumps(m, indent=2))
                os.replace(tmp, mapper_path)
            finally:
                fcntl.flock(lf.fileno(), fcntl.LOCK_UN)
    finally:
        try:
            os.remove(lock_path)
        except OSError:
            pass
    return True


def cleanup_pending_after_seal(seif_dir: Path,
                               landed_ids: list[str],
                               session_id: str = "",
                               at: str | None = None) -> dict:
    """Stamp pending-module items as LANDED at session/cycle close.

    Walks `.seif/modules/pending-*.seif` and, for each item.id matching
    `landed_ids`, sets `landed_at` (UTC ISO) + `landed_in_session`. Items
    are not removed — they remain in the file for audit, and the
    session-start surface can filter them out of the active count.
    Pending modules without an `items` list are skipped silently.

    Idempotent: re-stamping an already-landed id keeps the original
    `landed_at`. Reason: the BTC anchor is the authoritative timestamp;
    overwriting on re-run would smear the audit trail.

    Returns:
        {
            "files_updated": int,    # pending modules touched
            "items_landed": int,     # ids freshly stamped this run
            "items_already_landed": int,  # ids that already had landed_at
            "items_not_found": list[str], # ids in landed_ids not present
        }
    """
    if not landed_ids:
        return {"files_updated": 0, "items_landed": 0,
                "items_already_landed": 0, "items_not_found": []}

    landed_set = set(landed_ids)
    timestamp = at or _now_utc()
    modules_dir = seif_dir / "modules"
    files_updated = 0
    items_landed = 0
    items_already = 0
    found_ids: set[str] = set()

    if not modules_dir.is_dir():
        return {"files_updated": 0, "items_landed": 0,
                "items_already_landed": 0,
                "items_not_found": sorted(landed_set)}

    for pending_path in sorted(modules_dir.glob("pending-*.seif")):
        try:
            data = json.loads(pending_path.read_text(encoding="utf-8"))
        except Exception:
            continue
        items = data.get("items")
        if not isinstance(items, list):
            continue

        touched = False
        for item in items:
            if not isinstance(item, dict):
                continue
            iid = item.get("id")
            if iid not in landed_set:
                continue
            found_ids.add(iid)
            if item.get("landed_at"):
                items_already += 1
                continue
            item["landed_at"] = timestamp
            if session_id:
                item["landed_in_session"] = session_id
            items_landed += 1
            touched = True

        if touched:
            tmp = pending_path.with_suffix(pending_path.suffix + ".tmp")
            tmp.write_text(
                json.dumps(data, indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
            os.replace(tmp, pending_path)
            files_updated += 1

    return {
        "files_updated": files_updated,
        "items_landed": items_landed,
        "items_already_landed": items_already,
        "items_not_found": sorted(landed_set - found_ids),
    }


def session_end_logic(*, cwd: Path, home: Path,
                      timestamp: str | None = None,
                      session_id: str | None = None) -> SessionEndResult:
    seif_dir = find_seif_dir(cwd, home)
    if seif_dir is None:
        return SessionEndResult(seif_dir=None, closed_session_path=None,
                                audit_summary="", absorb_applied=False,
                                legacy_mode=True)
    if not lifecycle_enabled(seif_dir):
        return SessionEndResult(seif_dir=seif_dir, closed_session_path=None,
                                audit_summary="", absorb_applied=False,
                                legacy_mode=True)

    # s42 awareness MVP: drop this session from the registry on clean exit.
    # Stale entries are GC'd at next session-start anyway, but eager unregister
    # gives siblings an immediate accurate count.
    if session_id:
        try:
            from seif.plugins.core.session_registry import unregister
            unregister(seif_dir, session_id)
        except Exception:
            pass

    # s60 PR4: also run gc_stale at session-end. session_start_logic already
    # calls gc_stale on the way in — adding it on the way out shrinks the
    # window where a sibling sees a freshly-stale entry between when this
    # session crashed mid-flight (no clean session_end) and when the NEXT
    # session-start sweeps. For sessions that exit cleanly via session_end
    # this is largely redundant with the upcoming start sweep; the cost
    # is bounded by active/ size and is small (~ms). Errors are swallowed
    # to match the same discipline as the unregister call above — gc_stale
    # is best-effort hygiene, not a correctness invariant of session_end.
    try:
        from seif.plugins.core.session_registry import gc_stale
        gc_stale(seif_dir)
    except Exception:
        pass

    ts = timestamp or _now_utc()
    cfg = _read_json(seif_dir / "config.json")
    closure_format = cfg.get("session_lifecycle", {}).get(
        "closure_format",
        ["decided", "implemented", "why", "missing", "how_to_measure"],
    )

    closed_path = closure_phase(seif_dir, ts, closure_format)
    # Stamp pending items LANDED if the closing session declared them.
    # The active session contract may carry `landed_pending_ids: [...]`
    # populated during the session (e.g., by `seif --session contribute
    # --landed <id>`). Closure_phase has now flipped status=CLOSED, so the
    # ids here describe what landed in this just-closed session.
    if closed_path is not None:
        try:
            closed_data = json.loads(closed_path.read_text(encoding="utf-8"))
            ids = closed_data.get("landed_pending_ids", [])
            if isinstance(ids, list) and ids:
                cleanup_pending_after_seal(
                    seif_dir,
                    [i for i in ids if isinstance(i, str)],
                    session_id=str(closed_data.get("session_id", "")),
                    at=ts,
                )
        except Exception:
            pass
    audit_summary = audit_phase(seif_dir)
    absorb_applied = absorb_phase(seif_dir, ts)

    return SessionEndResult(
        seif_dir=seif_dir, closed_session_path=closed_path,
        audit_summary=audit_summary, absorb_applied=absorb_applied,
    )


# ── CLI (called by adapter shell shims) ────────────────────────────────────

def _emit_env(path: Path, env: dict[str, str]) -> None:
    """Write `KEY=value` lines to a file the shim can `source`."""
    path.write_text("".join(f"{k}={v}\n" for k, v in env.items()))


def _cli() -> int:
    parser = argparse.ArgumentParser(
        prog="session_lifecycle.py",
        description="SEIF session lifecycle (client-agnostic core)",
    )
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_start = sub.add_parser("session-start", help="Run session-start logic")
    p_start.add_argument("--session-id", required=True)
    p_start.add_argument("--cwd", default=os.getcwd())
    p_start.add_argument("--home", default=str(Path.home()))
    p_start.add_argument("--core-dir", default="")
    p_start.add_argument("--fallback-script-dir", default="")
    p_start.add_argument("--inbox-drain", action="store_true",
                         help="Run A20 inbox drain (some adapters opt-in)")
    p_start.add_argument("--daemon-activity", action="store_true",
                         help="Surface unread claude-responder daemon replies "
                              "(s40 P4, A23 visibility — adapters opt-in)")
    p_start.add_argument("--awareness", action="store_true",
                         help="Surface sibling sessions + HEAD drift "
                              "(s42 awareness MVP — adapters opt-in)")
    p_start.add_argument("--wrapper", default="claude-code",
                         help="Wrapper name for awareness registry "
                              "(claude-code, copilot, cursor, ...)")
    p_start.add_argument("--emit-env", default="",
                         help="Path to write `KEY=value` env file for shim")

    p_end = sub.add_parser("session-end", help="Run session-end logic")
    p_end.add_argument("--cwd", default=os.getcwd())
    p_end.add_argument("--home", default=str(Path.home()))
    p_end.add_argument("--session-id", default="",
                       help="Session ID to unregister from awareness "
                            "registry (s42 — empty = skip)")
    p_end.add_argument("--emit-env", default="")

    args = parser.parse_args()

    if args.cmd == "session-start":
        core_dir = (Path(args.core_dir) if args.core_dir
                    else Path(__file__).resolve().parent)
        fallback = (Path(args.fallback_script_dir)
                    if args.fallback_script_dir else None)
        result = session_start_logic(
            session_id=args.session_id,
            cwd=Path(args.cwd), home=Path(args.home),
            core_dir=core_dir, fallback_script_dir=fallback,
            enable_inbox_drain=args.inbox_drain,
            enable_daemon_activity=args.daemon_activity,
            enable_awareness=args.awareness,
            wrapper=args.wrapper,
        )
        if result.output_text:
            print(result.output_text)
        if args.emit_env:
            _emit_env(Path(args.emit_env), {
                "SEIF_DIR": str(result.seif_dir) if result.seif_dir else "",
                "SEIF_SESSION_NUMBER": str(result.session_count),
                "SEIF_SESSION_TYPE": result.session_type,
            })
        return 0

    if args.cmd == "session-end":
        result = session_end_logic(
            cwd=Path(args.cwd), home=Path(args.home),
            session_id=args.session_id or None,
        )
        if args.emit_env:
            _emit_env(Path(args.emit_env), {
                "SEIF_DIR": str(result.seif_dir) if result.seif_dir else "",
            })
        return 0

    return 1


if __name__ == "__main__":
    sys.exit(_cli())
