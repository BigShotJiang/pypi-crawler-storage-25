"""Cycle coherence audit — read-only validator for cycle ↔ session bindings.

s58 PR3 (companion to PR1 schema-cycle-id-field + PR2 cli-start-close-cycle).
Surfaces three classes of incoherence between workspace cycles and active
session entries:

(a) cycles with no recorded writer/contributing sessions
(b) active session entries whose cycle_id is None (informational — they may
    legitimately predate s58 PR1, or the operator may have opened them
    outside any cycle)
(c) SEALED cycles whose declared writer sessions still appear in
    .seif/sessions/active/ — the seal happened but the session record was
    never closed; sibling-session discovery still treats those as live

Read-only by design: this validator never mutates files. PR4 introduces the
seal-guard that *prevents* (c) at seal time; PR3 surfaces it for the cycles
that already exist.

The cycle field name has drifted across versions:
``writer_sessions`` (s53+ practice), ``contributing_sessions`` (the s58 pending
plan), and ``sessions`` (legacy ``cycle_new`` skeleton). The validator
accepts all three; (a) fires only when none of them carries entries.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable, Optional

CYCLE_SESSION_FIELDS = ("writer_sessions", "contributing_sessions", "sessions")


@dataclass
class CycleFinding:
    cycle_id: str
    cycle_file: str
    detail: str
    session_id: Optional[str] = None
    session_file: Optional[str] = None


@dataclass
class SessionFinding:
    session_id: str
    session_file: str
    detail: str


@dataclass
class CoherenceReport:
    workspace: str
    cycles_without_sessions: list[CycleFinding] = field(default_factory=list)
    active_sessions_without_cycle_id: list[SessionFinding] = field(default_factory=list)
    sealed_cycles_with_active_writer_sessions: list[CycleFinding] = field(default_factory=list)
    # s60 PR1.5: writers correctly archived in sessions/sealed/<cycle_id>/.
    # When a writer is in BOTH sealed/<matching cycle>/ AND active/, the
    # sealed copy is the authoritative archive; the active copy is a sync
    # straggler (not a violation). Surfaced advisory so heal-apply can be
    # re-run idempotently to drop the active straggler if desired.
    sealed_cycles_with_resolved_writer_sessions: list[CycleFinding] = field(default_factory=list)
    sealed_cycles_with_sync_straggler_in_active: list[CycleFinding] = field(default_factory=list)

    @property
    def has_violations(self) -> bool:
        """Class (c) is a real coherence violation; (a), (b), (d), (e) advisory."""
        return bool(self.sealed_cycles_with_active_writer_sessions)

    @property
    def total_findings(self) -> int:
        return (
            len(self.cycles_without_sessions)
            + len(self.active_sessions_without_cycle_id)
            + len(self.sealed_cycles_with_active_writer_sessions)
            + len(self.sealed_cycles_with_resolved_writer_sessions)
            + len(self.sealed_cycles_with_sync_straggler_in_active)
        )


def _resolve_workspace(workspace: Optional[Path | str]) -> Path:
    ws = Path(workspace) if workspace else Path.cwd()
    ws = ws.resolve()
    if not (ws / ".seif").is_dir():
        raise ValueError(
            f"workspace {ws} has no .seif/ — run `seif --init` there first"
        )
    return ws


def _iter_cycle_files(cycles_dir: Path, suffix: str) -> Iterable[Path]:
    if not cycles_dir.is_dir():
        return []
    return sorted(cycles_dir.glob(f"*-{suffix}.seif"))


def _load(path: Path) -> Optional[dict]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None
    return data if isinstance(data, dict) else None


def _cycle_session_ids(cycle_data: dict) -> list[str]:
    """Collect declared session_ids from any of the known cycle fields."""
    out: list[str] = []
    for field_name in CYCLE_SESSION_FIELDS:
        block = cycle_data.get(field_name)
        if not isinstance(block, list):
            continue
        for entry in block:
            if isinstance(entry, dict) and entry.get("session_id"):
                out.append(str(entry["session_id"]))
            elif isinstance(entry, str):
                out.append(entry)
    return out


def _sealed_session_ids(seif_dir: Path, cycle_id: str) -> dict[str, Path]:
    """Return {session_id: file_path} for entries archived in
    ``.seif/sessions/sealed/<cycle_id>/``.

    Sealed/<cycle_id>/ is terminal storage for writers whose cycle has
    been SEALED. A writer present here matches the resolved state; its
    presence in sessions/active/ alongside is a sync straggler (advisory),
    not a class-(c) coherence violation.
    """
    sealed_dir = seif_dir / "sessions" / "sealed" / cycle_id
    if not sealed_dir.is_dir():
        return {}
    out: dict[str, Path] = {}
    for f in sorted(sealed_dir.iterdir()):
        if not f.is_file() or f.suffix != ".json":
            continue
        # Filename convention: <session_id>.json. Body load is best-effort —
        # a sealed file with a missing/different session_id field still
        # counts toward "this writer was archived under this cycle".
        sid = f.stem
        out[sid] = f
        data = _load(f)
        if isinstance(data, dict):
            sid_in_body = data.get("session_id")
            if isinstance(sid_in_body, str) and sid_in_body and sid_in_body != sid:
                out[sid_in_body] = f
    return out


def _active_session_ids(seif_dir: Path) -> dict[str, Path]:
    """Return {session_id: file_path} for every active session entry."""
    active_dir = seif_dir / "sessions" / "active"
    if not active_dir.is_dir():
        return {}
    out: dict[str, Path] = {}
    for f in sorted(active_dir.iterdir()):
        if not f.is_file() or f.suffix != ".json":
            continue
        data = _load(f)
        if not data:
            continue
        sid = data.get("session_id")
        if isinstance(sid, str) and sid:
            out[sid] = f
    return out


def find_writers_pending_close(
    cycle_id: str,
    cycle_open_path: Optional[Path],
    seif_dir: Path,
) -> list[SessionFinding]:
    """Return active session findings that would orphan if ``cycle_id`` were
    sealed right now. Used by the s59 PR4 close_cycle seal-guard.

    Two complementary sources:
      (i)  active session entries whose ``cycle_id`` field equals ``cycle_id``
           (forward-compat: post-PR1 sessions self-declare their binding)
      (ii) session_ids declared in the OPEN cycle's writer_sessions /
           contributing_sessions / sessions blocks that are still present
           in .seif/sessions/active/ (backward-compat: handles cycles where
           writer_sessions is recorded in the cycle file but the session
           entries themselves predate PR1's cycle_id field)

    Each session is reported at most once; (i) takes precedence.
    """
    active = _active_session_ids(seif_dir)
    findings: list[SessionFinding] = []
    seen: set[str] = set()

    for sid, path in active.items():
        data = _load(path)
        if data and data.get("cycle_id") == cycle_id and sid not in seen:
            findings.append(SessionFinding(
                session_id=sid,
                session_file=str(path),
                detail=(
                    f"active session bound to cycle '{cycle_id}' (cycle_id "
                    f"field) would orphan after seal"
                ),
            ))
            seen.add(sid)

    if cycle_open_path and cycle_open_path.exists():
        cycle_data = _load(cycle_open_path)
        if cycle_data:
            for sid in _cycle_session_ids(cycle_data):
                if sid in active and sid not in seen:
                    findings.append(SessionFinding(
                        session_id=sid,
                        session_file=str(active[sid]),
                        detail=(
                            f"declared writer_session '{sid}' is still in "
                            f".seif/sessions/active/ — would orphan after seal"
                        ),
                    ))
                    seen.add(sid)

    return findings


def audit_cycle_coherence(workspace: Optional[Path | str] = None) -> CoherenceReport:
    """Run the full coherence audit. Read-only — never mutates files."""
    ws = _resolve_workspace(workspace)
    seif_dir = ws / ".seif"
    cycles_dir = seif_dir / "cycles"

    report = CoherenceReport(workspace=str(ws))
    active_sessions = _active_session_ids(seif_dir)

    # (a) cycles (OPEN or SEALED) with no recorded writer/contributing sessions
    for suffix in ("OPEN", "SEALED"):
        for cycle_file in _iter_cycle_files(cycles_dir, suffix):
            data = _load(cycle_file)
            if not data:
                continue
            cycle_id = str(data.get("cycle_id") or cycle_file.stem)
            if not _cycle_session_ids(data):
                report.cycles_without_sessions.append(CycleFinding(
                    cycle_id=cycle_id,
                    cycle_file=str(cycle_file),
                    detail=(
                        f"{suffix} cycle has no writer_sessions / "
                        f"contributing_sessions / sessions entries"
                    ),
                ))

    # (b) active sessions whose cycle_id is None
    for sid, path in active_sessions.items():
        data = _load(path)
        if not data:
            continue
        if data.get("cycle_id") in (None, ""):
            report.active_sessions_without_cycle_id.append(SessionFinding(
                session_id=sid,
                session_file=str(path),
                detail=(
                    "session is active but cycle_id is null — opened outside "
                    "a cycle or pre-s58 entry"
                ),
            ))

    # (c) / (d) / (e) SEALED cycles ↔ writer placement:
    #   in active/ only                          → class (c) violation
    #   in sealed/<cycle>/<sid>.json only        → class (d) RESOLVED (advisory)
    #   in BOTH active/ AND sealed/<cycle>/<sid> → class (e) sync straggler
    #                                              (advisory; sealed copy is
    #                                               authoritative; active is a
    #                                               sync side-effect, not a
    #                                               coherence violation)
    #
    # s60 rank-1 fix (option E-prime): the sealed/ archive is canonical
    # evidence the writer was processed at SEAL time. An unidentified peer
    # restorer can re-introduce the file to active/ within ~2 min of any
    # delete; before E-prime, audit naively flagged these as class (c) and
    # the heal CLI would thrash trying to clean them. After E-prime, the
    # presence of the sealed copy makes the active straggler a non-violation.
    for cycle_file in _iter_cycle_files(cycles_dir, "SEALED"):
        data = _load(cycle_file)
        if not data:
            continue
        cycle_id = str(data.get("cycle_id") or cycle_file.stem)
        sealed_for_cycle = _sealed_session_ids(seif_dir, cycle_id)
        for sid in _cycle_session_ids(data):
            in_active = sid in active_sessions
            in_sealed = sid in sealed_for_cycle
            if in_active and in_sealed:
                report.sealed_cycles_with_sync_straggler_in_active.append(CycleFinding(
                    cycle_id=cycle_id,
                    cycle_file=str(cycle_file),
                    detail=(
                        f"writer session {sid} is archived in "
                        f"sessions/sealed/{cycle_id}/ AND also present in "
                        f"sessions/active/ (sync straggler — sealed copy is "
                        f"authoritative; advisory). Re-run heal-apply to "
                        f"drop the active straggler."
                    ),
                    session_id=sid,
                    session_file=str(active_sessions[sid]),
                ))
            elif in_sealed:
                report.sealed_cycles_with_resolved_writer_sessions.append(CycleFinding(
                    cycle_id=cycle_id,
                    cycle_file=str(cycle_file),
                    detail=(
                        f"writer session {sid} is archived in "
                        f"sessions/sealed/{cycle_id}/ — class-(c) violation "
                        f"resolved."
                    ),
                    session_id=sid,
                    session_file=str(sealed_for_cycle[sid]),
                ))
            elif in_active:
                report.sealed_cycles_with_active_writer_sessions.append(CycleFinding(
                    cycle_id=cycle_id,
                    cycle_file=str(cycle_file),
                    detail=(
                        f"SEALED cycle declares writer session {sid} which "
                        f"is still present in .seif/sessions/active/ — run "
                        f"`seif --audit-cycle-coherence --heal` then "
                        f"`seif --heal-apply <plan>`"
                    ),
                    session_id=sid,
                    session_file=str(active_sessions[sid]),
                ))

    return report


def format_report(report: CoherenceReport) -> str:
    lines = [
        f"╔══ SEIF cycle ↔ session coherence audit ══════════════════════════╗",
        f"  Workspace : {report.workspace}",
    ]
    lines.append("")

    if report.total_findings == 0:
        lines.append("  ✓ No incoherence detected.")
        lines.append("╚══════════════════════════════════════════════════════════════════╝")
        return "\n".join(lines)

    if report.cycles_without_sessions:
        lines.append(
            f"  (a) Cycles without writer/contributing sessions "
            f"[{len(report.cycles_without_sessions)}] — advisory:"
        )
        for f in report.cycles_without_sessions:
            lines.append(f"      · {f.cycle_id}")
            lines.append(f"          {f.cycle_file}")
        lines.append("")

    if report.active_sessions_without_cycle_id:
        lines.append(
            f"  (b) Active sessions without cycle_id "
            f"[{len(report.active_sessions_without_cycle_id)}] — informational:"
        )
        for f in report.active_sessions_without_cycle_id:
            lines.append(f"      · {f.session_id[:8]}…")
            lines.append(f"          {f.session_file}")
        lines.append("")

    if report.sealed_cycles_with_active_writer_sessions:
        lines.append(
            f"  (c) SEALED cycles with writers still active "
            f"[{len(report.sealed_cycles_with_active_writer_sessions)}] — VIOLATION:"
        )
        for f in report.sealed_cycles_with_active_writer_sessions:
            lines.append(f"      · {f.cycle_id}")
            lines.append(f"          {f.cycle_file}")
            lines.append(f"          {f.detail}")
        lines.append("")

    if report.sealed_cycles_with_resolved_writer_sessions:
        lines.append(
            f"  (d) SEALED cycles with writers correctly archived "
            f"[{len(report.sealed_cycles_with_resolved_writer_sessions)}] — resolved:"
        )
        for f in report.sealed_cycles_with_resolved_writer_sessions:
            lines.append(f"      · {f.cycle_id}  ←  {(f.session_id or '')[:8]}…")
        lines.append("")

    if report.sealed_cycles_with_sync_straggler_in_active:
        lines.append(
            f"  (e) SEALED cycles with sync straggler in active "
            f"[{len(report.sealed_cycles_with_sync_straggler_in_active)}] — advisory:"
        )
        for f in report.sealed_cycles_with_sync_straggler_in_active:
            lines.append(f"      · {f.cycle_id}  ←  {(f.session_id or '')[:8]}…")
            lines.append(f"          {f.detail}")
        lines.append("")

    if report.has_violations:
        lines.append("  ✗ Coherence violations present (class c). Resolve before next seal.")
    else:
        lines.append("  ⚠  Advisory findings only — no hard violations.")
    lines.append("╚══════════════════════════════════════════════════════════════════╝")
    return "\n".join(lines)
