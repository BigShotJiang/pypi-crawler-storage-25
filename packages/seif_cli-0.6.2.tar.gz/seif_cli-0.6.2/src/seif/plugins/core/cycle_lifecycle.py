"""Cycle lifecycle — host-side process-state pointer for the active cycle.

s58 PR2 (companion to PR1 schema-cycle-id-field). Implements the canonical
``seif --start-cycle`` / ``seif --close-cycle`` surfaces that bind a workspace
SEIF cycle to the running shell via a pointer file at
``~/.seif/active-cycle.json`` and the ``SEIF_ACTIVE_CYCLE`` env var.

Storage policy (per .seif/modules/decision-2026-05-04-host-vs-workspace-storage-policy.seif):

- The host pointer is **process-state**: contains exactly
  ``{cycle_id, workspace_path, cycle_open_path}`` and nothing more. ZERO
  substantive cycle fields here.
- The cycle **substance** (vision, branches, contributors, observations,
  deliverables, integrity_hash, frequency_at_open, etc.) lives in the
  workspace at ``.seif/cycles/<cycle_id>-OPEN.seif``. That artifact is
  written / sealed by ``seif.context.cycle`` (existing surface).

Lifecycle:

1. ``start_cycle(slug, workspace)`` → calls ``cycle_new`` to write the
   workspace cycle file, then writes the host pointer. Returns the host
   pointer path so the caller can ``export SEIF_ACTIVE_CYCLE=<cycle_id>``
   if it wants register() to pick it up automatically.
2. ``close_cycle(slug, workspace)`` → calls ``cycle_close`` to seal the
   workspace cycle, then clears the host pointer.

The pointer is single-process-singleton by intent: a host has at most one
"active cycle" at a time. Re-running ``start_cycle`` overwrites; this is
correct for ``cd`` between workspaces because the new pointer reflects
the shell's new context. Sibling sessions on the same host that DON'T
share the shell rely on ``register(cycle_id=...)`` being passed
explicitly instead of via the env var.
"""

from __future__ import annotations

import datetime
import json
import os
from pathlib import Path
from typing import Optional

ACTIVE_CYCLE_FILENAME = "active-cycle.json"

ALLOWED_POINTER_KEYS = frozenset({"cycle_id", "workspace_path", "cycle_open_path"})


def _host_seif_dir() -> Path:
    """Resolve the host-level SEIF dir (~/.seif/). Honors $SEIF_HOME for tests."""
    override = os.environ.get("SEIF_HOME")
    if override:
        return Path(override).expanduser().resolve()
    return Path.home() / ".seif"


def active_cycle_pointer_path() -> Path:
    return _host_seif_dir() / ACTIVE_CYCLE_FILENAME


def _resolve_workspace(workspace: Optional[Path | str]) -> Path:
    """Resolve workspace root. Defaults to cwd. Workspace MUST contain .seif/."""
    ws = Path(workspace) if workspace else Path.cwd()
    ws = ws.resolve()
    if not (ws / ".seif").is_dir():
        raise ValueError(
            f"workspace {ws} has no .seif/ — run `seif --init` there first"
        )
    return ws


def write_active_pointer(
    *,
    cycle_id: str,
    workspace_path: Path,
    cycle_open_path: Path,
) -> Path:
    """Write the host pointer file. Pointer-only by contract: keys are
    restricted to ALLOWED_POINTER_KEYS. Raises ValueError if a caller tries
    to smuggle substantive fields through.
    """
    payload = {
        "cycle_id": cycle_id,
        "workspace_path": str(workspace_path),
        "cycle_open_path": str(cycle_open_path),
    }
    extra = set(payload.keys()) - ALLOWED_POINTER_KEYS
    if extra:
        raise ValueError(
            f"active-cycle pointer must be pointer-only; got extra keys: {sorted(extra)}"
        )

    host_dir = _host_seif_dir()
    host_dir.mkdir(parents=True, exist_ok=True)
    path = host_dir / ACTIVE_CYCLE_FILENAME
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return path


def read_active_pointer() -> Optional[dict]:
    """Return the active pointer as a dict, or None if no pointer is set
    or the file is malformed."""
    path = active_cycle_pointer_path()
    if not path.is_file():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None
    if not isinstance(data, dict):
        return None
    return data


def clear_active_pointer() -> bool:
    """Delete the host pointer. Returns True if removed, False if absent."""
    path = active_cycle_pointer_path()
    try:
        path.unlink()
        return True
    except FileNotFoundError:
        return False


def start_cycle(
    slug: str,
    *,
    workspace: Optional[Path | str] = None,
    parent_cycle: Optional[str] = None,
) -> dict:
    """Open a workspace cycle and bind it to this host as active.

    Returns a dict with: status ('opened' | 'reused' | 'error'), cycle_id,
    workspace_path, cycle_open_path, pointer_path, message.
    """
    try:
        ws = _resolve_workspace(workspace)
    except ValueError as e:
        return {"status": "error", "message": str(e)}

    from seif.context.cycle import cycle_new, _find_open_cycle  # local import

    ctx = ws / ".seif"
    existing = _find_open_cycle(ctx)
    if existing and existing.get("cycle_id") == slug:
        cycle_open_path = Path(existing["_file"])
        message = f"Cycle '{slug}' already open at {cycle_open_path}; re-binding host pointer."
        status = "reused"
    elif existing:
        return {
            "status": "error",
            "message": (
                f"Cycle '{existing.get('cycle_id')}' is already open in {ctx}.\n"
                f"   Run `seif --close-cycle` first, or use `seif --start-cycle {existing.get('cycle_id')}` to re-bind."
            ),
        }
    else:
        result = cycle_new(slug, parent_cycle, str(ctx))
        if result.startswith("⚠"):
            return {"status": "error", "message": result}
        cycle_open_path = ctx / "cycles" / f"{slug}-OPEN.seif"
        message = result
        status = "opened"

    pointer_path = write_active_pointer(
        cycle_id=slug,
        workspace_path=ws,
        cycle_open_path=cycle_open_path,
    )

    return {
        "status": status,
        "cycle_id": slug,
        "workspace_path": str(ws),
        "cycle_open_path": str(cycle_open_path),
        "pointer_path": str(pointer_path),
        "message": message,
    }


def close_cycle(
    slug: Optional[str] = None,
    *,
    workspace: Optional[Path | str] = None,
    force: bool = False,
) -> dict:
    """Seal the workspace cycle and clear the host pointer.

    If ``slug`` is omitted, uses the slug recorded in the active pointer
    (or the workspace's currently open cycle as a fallback). Errors if
    the pointer's slug and the discovered open cycle disagree.

    Seal-guard (s59 PR4 Layer A): refuses to seal when active session
    entries are still bound to this cycle (would create class-(c)
    coherence violations after seal). ``force=True`` bypasses the guard
    and writes a ``force_seal_audit_trail`` block into the resulting
    SEALED file.

    Returns a dict with: status ('closed' | 'error'), cycle_id,
    pointer_cleared (bool), message. On guard refusal, also returns
    ``blocked_writers`` listing the offending session_ids.
    """
    try:
        ws = _resolve_workspace(workspace)
    except ValueError as e:
        return {"status": "error", "message": str(e)}

    from seif.context.cycle import cycle_close, _find_open_cycle  # local import
    from seif.plugins.core.cycle_coherence import find_writers_pending_close

    ctx = ws / ".seif"
    pointer = read_active_pointer()
    discovered = _find_open_cycle(ctx)

    if slug is None:
        if pointer and pointer.get("cycle_id"):
            slug = pointer["cycle_id"]
        elif discovered:
            slug = discovered.get("cycle_id")
        else:
            return {
                "status": "error",
                "message": "No active cycle to close (no host pointer and no open cycle in workspace).",
            }

    if discovered and discovered.get("cycle_id") != slug:
        return {
            "status": "error",
            "message": (
                f"Slug mismatch: requested '{slug}' but workspace has open cycle "
                f"'{discovered.get('cycle_id')}'. Refusing to close — resolve manually."
            ),
        }

    cycle_open_path = ctx / "cycles" / f"{slug}-OPEN.seif"
    pending = find_writers_pending_close(slug, cycle_open_path, ctx)

    if pending and not force:
        lines = [
            f"Refusing to seal cycle '{slug}': {len(pending)} active writer "
            f"session(s) would orphan after seal (would become class-(c) "
            f"coherence violation per `seif --audit-cycle-coherence`).",
            "",
            "Sessions still in .seif/sessions/active/:",
        ]
        for f in pending:
            lines.append(f"  · {f.session_id}  ({f.session_file})")
        lines.append("")
        lines.append("Resolve via:")
        lines.append("  - run `seif --gc-stale` to clean abandoned sessions, or")
        lines.append("  - unregister specific sessions that are provably closed, or")
        lines.append(f"  - re-run with `seif --close-cycle {slug} --force` to override "
                     f"(writes audit trail into SEALED file).")
        return {
            "status": "error",
            "message": "\n".join(lines),
            "blocked_writers": [f.session_id for f in pending],
        }

    seal_result = cycle_close(context_repo=str(ctx))
    pointer_cleared = clear_active_pointer()

    if pending and force:
        sealed_path = ctx / "cycles" / f"{slug}-SEALED.seif"
        if sealed_path.is_file():
            try:
                sealed_data = json.loads(sealed_path.read_text(encoding="utf-8"))
                sealed_data["force_seal_audit_trail"] = {
                    "force_sealed_at": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
                    "active_writer_sessions_at_force": [
                        {
                            "session_id": f.session_id,
                            "session_file": f.session_file,
                            "detail": f.detail,
                        }
                        for f in pending
                    ],
                    "rationale": (
                        "Operator used --force to bypass s59 PR4 seal-guard "
                        "despite active writer sessions; recorded for audit."
                    ),
                }
                sealed_path.write_text(json.dumps(sealed_data, indent=2), encoding="utf-8")
            except (json.JSONDecodeError, OSError):
                pass

    result = {
        "status": "closed",
        "cycle_id": slug,
        "pointer_cleared": pointer_cleared,
        "message": seal_result,
    }
    if pending and force:
        result["forced_with_blocked_writers"] = [f.session_id for f in pending]
    return result
