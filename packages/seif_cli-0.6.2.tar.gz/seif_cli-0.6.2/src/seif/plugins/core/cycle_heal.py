"""Cycle coherence heal — consent-gated remediation for class-(c) violations.

s59 PR4 Layer C (companion to PR3 audit + PR4 Layer A guard + PR4 Layer B
auto-wire). Targets the specific historical pattern flagged at s59 boot:
SEALED cycles (s54 / s55 / s56) whose declared writer sessions never got
moved out of ``.seif/sessions/active/``, leaving them as class-(c)
coherence violations.

Two-phase, consent-gated by design:

  1. ``build_heal_plan(workspace) → dict``
     READ-ONLY. Inspects the audit report; emits a structured plan
     describing the proposed remediation actions. Does NOT mutate any
     session entry. The plan can be persisted to disk via
     ``write_heal_plan(plan, path)``.

  2. ``apply_heal_plan(plan_path, workspace) → dict``
     MUTATES STATE. Reads a plan written by phase 1, executes each
     action and returns a result dict listing per-action outcomes.

The split exists so the operator can review the plan before any write
hits ``.seif/``. CLI surface enforces the split: ``--audit-cycle-coherence
--heal`` only writes the plan; ``--heal-apply <plan-file>`` is the
explicit consent step that applies it.

Action kinds (schema v2):
  - ``move_session_to_sealed``: move a session entry from
    ``.seif/sessions/active/<sid>.json`` to
    ``.seif/sessions/sealed/<cycle_id>/<sid>.json``. Sealed/ is terminal
    storage and is NOT synced cross-host — see ``move_to_sealed`` in
    session_registry. This shape replaces v1's ``unregister_session``,
    which deleted the file outright; the v1 deletion was silently undone
    by heartbeatd's ``rsync --ignore-existing`` re-pulling the file from
    peers that still had it in active/. Move-not-delete is sync-coherent
    because there is no deletion for sync to undo, and preserves the
    session body as audit evidence.

s60 rank-1 finding (sync-coherence-deletion-non-propagation) drove the
v1 → v2 schema bump. Old v1 plans are rejected with a clear error so the
operator re-builds against the current code; mixing them would silently
fall back to the broken delete path.

Per s59 q1 owner decision: backfill-clean first; annotation only escalated
case-by-case if a session proves to be live. This module implements the
backfill-clean path; the annotation path is reserved for a future module.
"""

from __future__ import annotations

import datetime
import hashlib
import json
import os
from pathlib import Path
from typing import Optional, Union


def _now_iso_utc() -> str:
    return datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _resolve_workspace(workspace: Optional[Union[Path, str]]) -> Path:
    ws = Path(workspace) if workspace else Path.cwd()
    ws = ws.resolve()
    if not (ws / ".seif").is_dir():
        raise ValueError(
            f"workspace {ws} has no .seif/ — run `seif --init` there first"
        )
    return ws


def _plan_id(workspace_path: str, generated_at: str) -> str:
    """Deterministic short id for a heal plan, derived from workspace + ts."""
    h = hashlib.sha256(f"{workspace_path}|{generated_at}".encode()).hexdigest()
    return f"heal-{generated_at}-{h[:8]}"


def build_heal_plan(workspace: Optional[Union[Path, str]] = None) -> dict:
    """Phase 1 (READ-ONLY). Build a remediation plan for the workspace's
    current class-(c) coherence violations.

    Returns a plan dict; never writes to any session file. Pass the plan
    to ``write_heal_plan`` to persist it, then ``apply_heal_plan`` to
    actually execute the proposed actions.
    """
    from seif.plugins.core.cycle_coherence import audit_cycle_coherence

    ws = _resolve_workspace(workspace)
    report = audit_cycle_coherence(workspace=ws)
    generated_at = _now_iso_utc()

    actions: list[dict] = []
    for finding in report.sealed_cycles_with_active_writer_sessions:
        if not finding.session_id or not finding.session_file:
            continue  # defensive — class-(c) findings must carry session info
        actions.append({
            "kind": "move_session_to_sealed",
            "session_id": finding.session_id,
            "session_file": finding.session_file,
            "cycle_id": finding.cycle_id,
            "cycle_file": finding.cycle_file,
            "dest_path": str(
                ws / ".seif" / "sessions" / "sealed"
                / finding.cycle_id / f"{finding.session_id}.json"
            ),
            "reason": (
                f"Writer session declared in SEALED cycle '{finding.cycle_id}' "
                f"is still present in .seif/sessions/active/. Moving to "
                f"sessions/sealed/{finding.cycle_id}/ is sync-coherent "
                f"(no deletion = nothing for rsync to undo) and preserves "
                f"the session body as audit evidence."
            ),
        })

    return {
        "schema": "SEIF-HEAL-PLAN-v2",
        "plan_id": _plan_id(str(ws), generated_at),
        "generated_at": generated_at,
        "workspace": str(ws),
        "based_on_audit": {
            "class_a_count": len(report.cycles_without_sessions),
            "class_b_count": len(report.active_sessions_without_cycle_id),
            "class_c_count": len(report.sealed_cycles_with_active_writer_sessions),
        },
        "actions": actions,
        "approval_required": True,
        "to_apply": "seif --heal-apply <path-to-this-file>",
        "notes": (
            "READ-ONLY plan. No session entries are mutated until "
            "`seif --heal-apply` is invoked explicitly."
        ),
    }


def write_heal_plan(plan: dict, workspace: Optional[Union[Path, str]] = None) -> Path:
    """Persist the plan to ``.seif/heal-plans/<plan_id>.json``. Returns
    the absolute file path. The plan dict is not mutated."""
    ws = _resolve_workspace(workspace)
    plans_dir = ws / ".seif" / "heal-plans"
    plans_dir.mkdir(parents=True, exist_ok=True)
    plan_id = plan.get("plan_id", "heal-unknown")
    safe_id = plan_id.replace("/", "_").replace(":", "")
    out = plans_dir / f"{safe_id}.json"
    out.write_text(json.dumps(plan, indent=2), encoding="utf-8")
    return out


def apply_heal_plan(
    plan_path: Union[Path, str],
    workspace: Optional[Union[Path, str]] = None,
) -> dict:
    """Phase 2 (MUTATES STATE). Read a previously-built plan and execute
    each action. Returns ``{plan_id, applied_at, results: [...], summary}``
    where each result is ``{action, applied: bool, message}``.

    Idempotent for ``unregister_session``: if the session entry is already
    absent, the result records ``applied=False`` with a benign message.

    Raises ``ValueError`` if the plan file is missing, malformed, or carries
    a workspace path that doesn't match the resolved workspace (defensive
    guard against cross-workspace heal application).
    """
    from seif.plugins.core.session_registry import move_to_sealed

    ws = _resolve_workspace(workspace)
    plan_p = Path(plan_path).expanduser().resolve()
    if not plan_p.is_file():
        raise ValueError(f"heal plan not found at {plan_p}")
    try:
        plan = json.loads(plan_p.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        raise ValueError(f"heal plan {plan_p} is not valid JSON: {e}")
    if not isinstance(plan, dict):
        raise ValueError(f"heal plan {plan_p} did not decode to a JSON object")
    plan_schema = plan.get("schema")
    if plan_schema == "SEIF-HEAL-PLAN-v1":
        raise ValueError(
            f"heal plan {plan_p} is schema v1 (unregister_session, delete-based). "
            f"Schema v1 was retired in s60: deletes are silently undone by "
            f"heartbeatd rsync --ignore-existing. Re-build the plan with the "
            f"current `seif --audit-cycle-coherence --heal` to get a v2 plan "
            f"using move_session_to_sealed."
        )
    if plan_schema != "SEIF-HEAL-PLAN-v2":
        raise ValueError(
            f"heal plan {plan_p} schema mismatch "
            f"(got {plan_schema!r}, expected 'SEIF-HEAL-PLAN-v2')"
        )
    plan_ws = plan.get("workspace")
    if plan_ws and Path(plan_ws).resolve() != ws:
        raise ValueError(
            f"heal plan workspace ({plan_ws}) does not match resolved "
            f"workspace ({ws}); refusing to apply across workspaces"
        )

    seif_dir = ws / ".seif"
    results: list[dict] = []
    applied_count = 0
    skipped_count = 0
    error_count = 0

    for action in plan.get("actions", []):
        kind = action.get("kind")
        if kind == "move_session_to_sealed":
            sid = action.get("session_id")
            cid = action.get("cycle_id")
            if not sid or not cid:
                results.append({
                    "action": action,
                    "applied": False,
                    "message": "skipped — action missing session_id or cycle_id",
                })
                skipped_count += 1
                continue
            try:
                moved, dest = move_to_sealed(seif_dir, sid, cid)
            except Exception as e:
                results.append({
                    "action": action,
                    "applied": False,
                    "message": f"error: {e}",
                })
                error_count += 1
                continue
            if moved:
                results.append({
                    "action": action,
                    "applied": True,
                    "message": (
                        f"session {sid} moved to sessions/sealed/{cid}/ "
                        f"(dest: {dest})"
                    ),
                })
                applied_count += 1
            elif dest is not None:
                results.append({
                    "action": action,
                    "applied": False,
                    "message": (
                        f"session {sid} already at sessions/sealed/{cid}/ "
                        f"(idempotent skip)"
                    ),
                })
                skipped_count += 1
            else:
                results.append({
                    "action": action,
                    "applied": False,
                    "message": (
                        f"session {sid} not found in active/ nor in "
                        f"sessions/sealed/{cid}/ (already gone — idempotent skip)"
                    ),
                })
                skipped_count += 1
        else:
            results.append({
                "action": action,
                "applied": False,
                "message": f"unknown action kind {kind!r} — skipped",
            })
            skipped_count += 1

    return {
        "plan_id": plan.get("plan_id"),
        "plan_path": str(plan_p),
        "applied_at": _now_iso_utc(),
        "workspace": str(ws),
        "results": results,
        "summary": {
            "applied": applied_count,
            "skipped": skipped_count,
            "errors": error_count,
            "total": len(results),
        },
    }
