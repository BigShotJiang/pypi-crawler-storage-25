#!/usr/bin/env python3
"""
SEIF Circuit Monitor — mid-session circuit visibility for AI writers.

Queries circuitd /events endpoint, compares with last known state,
and outputs alerts when circuit stability degrades.

Designed for:
  - Background polling (every 30s from session-start.sh)
  - Direct invocation by the AI to check circuit health
  - Hook integration (PreToolUse / PostToolUse)

Execution budget: <1 second (single HTTP GET + file compare).
"""

import json
import os
import sys
import time
import urllib.request
import urllib.error
from datetime import datetime, timezone
from pathlib import Path

# ── Config ──────────────────────────────────────────────────────────────────

CIRCUIT_URL = "http://127.0.0.1:7333"
SEIF_HOME = Path.home() / ".seif"
CIRCUIT_DIR = SEIF_HOME / "circuit"
INBOX_DIR = CIRCUIT_DIR / "inbox"
MONITOR_STATE_FILE = CIRCUIT_DIR / "monitor-state.json"
ALERTS_FILE = CIRCUIT_DIR / "alerts.txt"
WATERMARK_FILE = CIRCUIT_DIR / "inbox-watermark.json"
PENDING_FILE = CIRCUIT_DIR / "pending-messages.json"

# Models affected when circuit goes down (remote delegation targets)
REMOTE_MODELS = [
    "OpenCode (Mini M4)",
    "Copilot (Mini M4)",
    "Ollama (Mini M4)",
]


def _http_get(url: str, timeout: float = 2) -> dict | None:
    """Quick HTTP GET, returns parsed JSON or None."""
    try:
        req = urllib.request.Request(url)
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read())
    except Exception:
        return None


def _load_last_state() -> dict:
    """Load last known monitor state from disk."""
    if MONITOR_STATE_FILE.exists():
        try:
            return json.loads(MONITOR_STATE_FILE.read_text())
        except Exception:
            pass
    return {}


def _save_state(state: dict):
    """Persist current monitor state."""
    CIRCUIT_DIR.mkdir(parents=True, exist_ok=True)
    try:
        MONITOR_STATE_FILE.write_text(json.dumps(state, indent=2))
    except Exception:
        pass


def _append_alert(message: str):
    """Append alert to alerts file (for background mode)."""
    CIRCUIT_DIR.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    try:
        with ALERTS_FILE.open("a") as f:
            f.write(f"[{timestamp}] {message}\n")
    except Exception:
        pass


def _format_alert(prev_stability: str, curr_stability: str,
                  events: list, current: dict) -> str:
    """Format a human-readable alert for the AI writer."""
    lines = []

    # Header
    lines.append(f"[CIRCUIT ALERT] Stability changed: {prev_stability} -> {curr_stability}")

    # Show latest event detail
    if events:
        last = events[-1]
        from_t = last.get("from", "?")
        to_t = last.get("to", "?")
        reason = last.get("reason", "?")
        lines.append(f"  Transport: {from_t} -> {to_t} ({reason})")

    # Impact assessment
    if curr_stability == "disconnected":
        lines.append("  Impact: Remote model delegation UNAVAILABLE. Local models only.")
        affected = ", ".join(REMOTE_MODELS)
        lines.append(f"  Affected: {affected}")
    elif curr_stability == "degraded":
        transport = current.get("transport", "?")
        lines.append(f"  Impact: Connected via {transport} — may be unstable.")
        lines.append("  Recommendation: Prefer local operations, avoid large file transfers.")
    elif curr_stability == "stable":
        lines.append("  Circuit recovered. Full delegation capability restored.")

    return "\n".join(lines)


def monitor(quiet: bool = False) -> int:
    """
    Main monitor function.

    Returns:
        0 — no change
        1 — stability changed (alert emitted)
        2 — circuitd unreachable
    """
    # Query events endpoint
    data = _http_get(f"{CIRCUIT_URL}/events")

    if data is None:
        # circuitd not running — check if this is a new condition
        prev = _load_last_state()
        if prev.get("circuitd_reachable", True):
            msg = "[CIRCUIT ALERT] circuitd not reachable at 127.0.0.1:7333 — circuit monitoring offline"
            if not quiet:
                print(msg, file=sys.stderr)
            _append_alert(msg)
            _save_state({
                "circuitd_reachable": False,
                "session_stability": "disconnected",
                "checked_at": datetime.now(timezone.utc).isoformat(),
            })
            return 2
        return 0

    # Extract current state
    curr_stability = data.get("session_stability", "disconnected")
    current = data.get("current", {})
    events = data.get("events", [])
    changes_count = data.get("changes_since_session", 0)

    # Load previous state
    prev = _load_last_state()
    prev_stability = prev.get("session_stability", None)
    prev_changes = prev.get("changes_since_session", 0)

    # Save current state
    _save_state({
        "circuitd_reachable": True,
        "session_stability": curr_stability,
        "connected": current.get("connected", False),
        "transport": current.get("transport", "?"),
        "changes_since_session": changes_count,
        "checked_at": datetime.now(timezone.utc).isoformat(),
    })

    # Detect change
    if prev_stability is not None and curr_stability != prev_stability:
        alert = _format_alert(prev_stability, curr_stability, events, current)
        if not quiet:
            print(alert)
        _append_alert(alert)
        return 1

    # Also detect new events even if stability label didn't change
    if changes_count > prev_changes and not quiet:
        new_events = events[-(changes_count - prev_changes):]
        for ev in new_events:
            print(f"[CIRCUIT] {ev['from']} -> {ev['to']} ({ev['reason']})")

    return 0


def status():
    """Print current circuit status (for direct invocation by AI)."""
    data = _http_get(f"{CIRCUIT_URL}/events")
    if data is None:
        print("[CIRCUIT STATUS] circuitd not reachable")
        return

    stability = data.get("session_stability", "?")
    current = data.get("current", {})
    changes = data.get("changes_since_session", 0)
    events = data.get("events", [])

    print(f"[CIRCUIT STATUS] {stability.upper()}")
    print(f"  Connected: {current.get('connected', False)}")
    print(f"  Transport: {current.get('transport', '?')}")
    print(f"  Changes this session: {changes}")

    if events:
        print(f"  Last event: {events[-1].get('from')} -> {events[-1].get('to')} ({events[-1].get('reason')})")
        print(f"  Last event at: {events[-1].get('timestamp', '?')}")


# ── A20 inbox primitives ───────────────────────────────────────────────────

def _load_watermark() -> set[str]:
    """Load the set of inbox filenames already seen by previous --check-inbox."""
    if not WATERMARK_FILE.is_file():
        return set()
    try:
        data = json.loads(WATERMARK_FILE.read_text())
        return set(data.get("seen_files", []))
    except Exception:
        return set()


def _save_watermark(seen_files: set[str]) -> None:
    """Persist the set of seen inbox files."""
    CIRCUIT_DIR.mkdir(parents=True, exist_ok=True)
    payload = {
        "seen_files": sorted(seen_files),
        "last_checked": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
    }
    WATERMARK_FILE.write_text(json.dumps(payload, indent=2))


def _list_inbox_messages() -> list[Path]:
    """List bus-handoff-*.json files in the inbox, sorted oldest first."""
    if not INBOX_DIR.is_dir():
        return []
    return sorted(
        p for p in INBOX_DIR.iterdir()
        if p.is_file() and p.name.startswith("bus-handoff-") and p.name.endswith(".json")
    )


def check_inbox() -> int:
    """Scan inbox for messages newer than the watermark. If any are found,
    write them to pending-messages.json (the rest of the pipeline reads
    that file). Returns 0 always — absence of new messages is not an error.
    No watermark advance here; --drain is what marks them seen."""
    seen = _load_watermark()
    all_msgs = _list_inbox_messages()
    new_msgs = [p for p in all_msgs if p.name not in seen]

    if not new_msgs:
        # No new messages → remove stale pending file (idempotent)
        if PENDING_FILE.is_file():
            PENDING_FILE.unlink()
        return 0

    payload = []
    for p in new_msgs:
        try:
            body = json.loads(p.read_text())
        except Exception:
            body = {"_error": "could not parse", "filename": p.name}
        payload.append({
            "filename": p.name,
            "received_at": datetime.fromtimestamp(p.stat().st_mtime,
                                                  tz=timezone.utc).isoformat(),
            "body": body,
        })
        # s40 P5 — record the bus-message event for the A23 metric. Never
        # let a metric write break inbox consumption: the counter is observability,
        # not load-bearing. Skips the corrupt-body case (no inner shape to read).
        if isinstance(body, dict) and "_error" not in body:
            try:
                from seif.observability.bus_metrics import record_bus_message
                # Inbox shape (from on_hub_message): top-level wraps the
                # producer's payload under "payload"; reach in for the envelope.
                inner = body.get("payload") if isinstance(body.get("payload"), dict) else body
                record_bus_message(inner)
            except Exception:
                pass

    CIRCUIT_DIR.mkdir(parents=True, exist_ok=True)
    PENDING_FILE.write_text(json.dumps(payload, indent=2, ensure_ascii=False))
    return 0


def drain_inbox() -> int:
    """Read pending-messages.json (written by --check-inbox), print messages
    in human-readable form to stdout (so the AI can surface them), advance
    the watermark to mark them seen, then delete pending-messages.json.
    Returns 0 always."""
    if not PENDING_FILE.is_file():
        return 0
    try:
        msgs = json.loads(PENDING_FILE.read_text())
    except Exception as e:
        # Preserve the corrupted file for inspection rather than silent unlink —
        # silent drops on parse failure hide cascading bugs (s39 P4 audit).
        ts = int(time.time())
        corrupted = PENDING_FILE.with_name(f"pending-corrupted-{ts}.json")
        try:
            PENDING_FILE.rename(corrupted)
            print(
                f"[CIRCUIT INBOX] Pending file unparseable; preserved at "
                f"{corrupted.name} for inspection. Reason: {e}",
                file=sys.stderr,
            )
        except OSError:
            # Fall back to unlink only if rename itself failed (rare)
            PENDING_FILE.unlink(missing_ok=True)
        return 0
    if not msgs:
        PENDING_FILE.unlink()
        return 0

    print(f"[CIRCUIT INBOX] {len(msgs)} message(s) drained:")
    print()
    for entry in msgs:
        fname = entry.get("filename", "?")
        received = entry.get("received_at", "?")
        body = entry.get("body", {})
        print(f"  ── {fname}  (received {received})")
        from_to = ""
        if isinstance(body, dict):
            sender = body.get("from") or body.get("sender") or body.get("origin")
            recipient = body.get("to") or body.get("recipient") or body.get("destination")
            subject = body.get("subject") or body.get("topic") or body.get("kind")
            if sender or recipient:
                from_to = f"{sender or '?'} → {recipient or '?'}"
                print(f"     {from_to}")
            if subject:
                print(f"     subject: {subject}")
            content = body.get("content") or body.get("body") or body.get("message")
            if content:
                snippet = str(content)
                if len(snippet) > 400:
                    snippet = snippet[:400] + "…"
                print(f"     {snippet}")
        else:
            print(f"     (raw): {body!r}")
    print()

    # Advance watermark
    seen = _load_watermark()
    for entry in msgs:
        fname = entry.get("filename")
        if fname:
            seen.add(fname)
    _save_watermark(seen)

    # Clear pending (single-shot drain)
    PENDING_FILE.unlink()
    return 0


def main():
    import argparse
    parser = argparse.ArgumentParser(description="SEIF Circuit Monitor")
    parser.add_argument("--status", action="store_true", help="Print full status")
    parser.add_argument("--quiet", action="store_true", help="Only write to alerts file")
    parser.add_argument("--clear-alerts", action="store_true", help="Clear alerts file")
    parser.add_argument("--check-inbox", action="store_true",
                        help="Scan ~/.seif/circuit/inbox/ for messages newer than "
                             "watermark; write pending-messages.json if any.")
    parser.add_argument("--drain", action="store_true",
                        help="Read pending-messages.json, print messages in human "
                             "form, advance watermark, delete pending file.")
    args = parser.parse_args()

    if args.clear_alerts:
        if ALERTS_FILE.exists():
            ALERTS_FILE.unlink()
            print("Alerts cleared.")
        return

    if args.check_inbox:
        sys.exit(check_inbox())

    if args.drain:
        sys.exit(drain_inbox())

    if args.status:
        status()
        return

    exit_code = monitor(quiet=args.quiet)
    sys.exit(exit_code)


if __name__ == "__main__":
    main()
