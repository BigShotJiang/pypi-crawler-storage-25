"""Session registry — sibling-session discovery for parallel seif-cli wrappers.

s42 awareness MVP, primitive #1 of 5 (per project_parallel_session_awareness
memory + P8.1 seed §7). Companion: preflight_diff.py (primitive #3).

Purpose: when multiple seif-cli wrappers run on the same workspace
(Claude Code on one machine, Copilot on another, etc.), each session
plans against `.seif/` state read at start and may mutate it without
siblings knowing. This module gives each session a way to register
its presence and discover others.

Storage: one JSON file per active session at
`<.seif>/sessions/active/<session_id>.json`. Closed sessions are
removed; sessions that crashed without unregistering are GC'd at
the next session-start (no heartbeat for >900s = stale).

No daemon — heartbeat updates only at session-start (cheap; staleness
detection is best-effort, not safety-critical).
"""

from __future__ import annotations

import calendar
import json
import os
import socket
import time
import uuid
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Iterable

STALE_AFTER_SECONDS_DEFAULT = 900  # 15 min — accommodates LLM thinking pauses


def _now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _hostname() -> str:
    try:
        return socket.gethostname()
    except OSError:
        return "unknown"


@dataclass
class SessionEntry:
    session_id: str
    wrapper: str
    host: str
    pid: int
    cwd: str
    started_at: str
    last_heartbeat: str
    repos_observed: dict[str, str]
    cycle_id: str | None = None


def _registry_dir(seif_dir: Path) -> Path:
    return seif_dir / "sessions" / "active"


def new_session_id() -> str:
    return str(uuid.uuid4())


def _validate_session_id(session_id: str) -> None:
    """Reject non-UUID session_ids before any FS write.

    Guards the registry boundary: the wrapper-side fallback (session_id="unknown")
    used to pollute active/ with non-discoverable entries until the s55 hygiene
    pass surfaced it. Keeping the check here means every caller is fail-closed,
    independent of which wrapper sent the request.
    """
    if not isinstance(session_id, str) or not session_id:
        raise ValueError(
            "session_id must be a non-empty string, got "
            f"{type(session_id).__name__}={session_id!r}"
        )
    try:
        uuid.UUID(session_id)
    except ValueError:
        raise ValueError(
            f"session_id must be a canonical UUID, got {session_id!r}"
        ) from None


def register(
    *,
    seif_dir: Path,
    session_id: str,
    wrapper: str,
    cwd: Path,
    repo_heads: dict[str, str] | None = None,
    host: str | None = None,
    pid: int | None = None,
    cycle_id: str | None = None,
) -> Path:
    """Write a fresh registry entry for this session. Idempotent — overwrites
    an existing entry with the same session_id. Raises ValueError if
    session_id is missing or not a canonical UUID.

    cycle_id binds the session to a SEIF cycle. If not provided, falls back
    to the SEIF_ACTIVE_CYCLE env var (process-state pointer set by
    --start-cycle, planned for s58 PR2). Stays None for sessions opened
    outside any cycle — backward-compatible with pre-s58 entries.
    """
    _validate_session_id(session_id)
    reg_dir = _registry_dir(seif_dir)
    reg_dir.mkdir(parents=True, exist_ok=True)

    if cycle_id is None:
        env_cycle = os.environ.get("SEIF_ACTIVE_CYCLE")
        if env_cycle:
            cycle_id = env_cycle

    entry = SessionEntry(
        session_id=session_id,
        wrapper=wrapper,
        host=host or _hostname(),
        pid=pid if pid is not None else os.getpid(),
        cwd=str(cwd),
        started_at=_now_iso(),
        last_heartbeat=_now_iso(),
        repos_observed=repo_heads or {},
        cycle_id=cycle_id,
    )

    path = reg_dir / f"{session_id}.json"
    path.write_text(json.dumps(asdict(entry), indent=2))
    return path


def heartbeat(seif_dir: Path, session_id: str) -> bool:
    """Update last_heartbeat for an existing entry. Returns False if entry
    is missing (session was unregistered or never registered). No-op if
    file is malformed; caller decides whether to re-register."""
    path = _registry_dir(seif_dir) / f"{session_id}.json"
    if not path.is_file():
        return False
    try:
        data = json.loads(path.read_text())
    except (json.JSONDecodeError, OSError):
        return False
    data["last_heartbeat"] = _now_iso()
    path.write_text(json.dumps(data, indent=2))
    return True


def unregister(seif_dir: Path, session_id: str) -> bool:
    """Remove this session's registry entry. Returns True if removed,
    False if entry didn't exist (already gone — fine)."""
    path = _registry_dir(seif_dir) / f"{session_id}.json"
    try:
        path.unlink()
        return True
    except FileNotFoundError:
        return False


def _sealed_dir(seif_dir: Path, cycle_id: str) -> Path:
    return seif_dir / "sessions" / "sealed" / cycle_id


def move_to_sealed(
    seif_dir: Path, session_id: str, cycle_id: str
) -> tuple[bool, Path | None]:
    """Move a session entry from active/ to sealed/<cycle_id>/.

    Returns ``(moved, dest_path)``:
      - ``(True, dest)``  the file was at active/ and is now at dest.
      - ``(False, dest)`` already at dest (idempotent — heal re-run is fine).
      - ``(False, None)`` neither at active/ nor at dest (nothing to do).

    Sealed/ is terminal storage: a session correctly placed there for a
    SEALED cycle resolves the class-(c) coherence violation that heal
    targets, and is intentionally NOT synced cross-host (each host owns
    its own sealed view, so a heal applied locally is not undone by a
    rsync pull from a peer that still has the file in active/).
    """
    src = _registry_dir(seif_dir) / f"{session_id}.json"
    dst_dir = _sealed_dir(seif_dir, cycle_id)
    dst = dst_dir / f"{session_id}.json"
    if dst.exists() and not src.exists():
        return False, dst
    if not src.exists():
        return False, None
    dst_dir.mkdir(parents=True, exist_ok=True)
    if dst.exists():
        # Both present — prefer the sealed copy (it is terminal); drop the
        # active straggler. Avoids os.replace which would clobber the sealed
        # body with the active one.
        src.unlink()
        return True, dst
    src.rename(dst)
    return True, dst


def _entry_age_seconds(entry: dict) -> float:
    """Seconds since last_heartbeat. Returns +inf if heartbeat is malformed
    so stale-check treats it as definitely stale."""
    hb = entry.get("last_heartbeat", "")
    try:
        struct = time.strptime(hb, "%Y-%m-%dT%H:%M:%SZ")
        # Both sides interpreted as UTC: timegm matches gmtime in _now_iso.
        return max(0.0, time.time() - calendar.timegm(struct))
    except (TypeError, ValueError):
        return float("inf")


def list_active(
    seif_dir: Path,
    stale_after_seconds: int = STALE_AFTER_SECONDS_DEFAULT,
    exclude: Iterable[str] = (),
) -> list[dict]:
    """Return current sibling entries with fresh heartbeats. Stale entries
    are filtered out but NOT deleted (gc_stale handles cleanup)."""
    reg_dir = _registry_dir(seif_dir)
    if not reg_dir.is_dir():
        return []
    excluded = set(exclude)
    out: list[dict] = []
    for f in sorted(reg_dir.iterdir()):
        if not f.is_file() or f.suffix != ".json":
            continue
        try:
            entry = json.loads(f.read_text())
        except (json.JSONDecodeError, OSError):
            continue
        if entry.get("session_id") in excluded:
            continue
        if _entry_age_seconds(entry) <= stale_after_seconds:
            out.append(entry)
    return out


def gc_stale(
    seif_dir: Path,
    stale_after_seconds: int = STALE_AFTER_SECONDS_DEFAULT,
) -> int:
    """Delete entries older than the threshold. Returns count removed.
    Called at session-start so a crashed session doesn't permanently
    pollute the registry."""
    reg_dir = _registry_dir(seif_dir)
    if not reg_dir.is_dir():
        return 0
    removed = 0
    for f in reg_dir.iterdir():
        if not f.is_file() or f.suffix != ".json":
            continue
        try:
            entry = json.loads(f.read_text())
        except (json.JSONDecodeError, OSError):
            # Malformed file — remove it; siblings can't trust unparseable state
            try:
                f.unlink()
                removed += 1
            except OSError:
                pass
            continue
        if _entry_age_seconds(entry) > stale_after_seconds:
            try:
                f.unlink()
                removed += 1
            except OSError:
                pass
    return removed
