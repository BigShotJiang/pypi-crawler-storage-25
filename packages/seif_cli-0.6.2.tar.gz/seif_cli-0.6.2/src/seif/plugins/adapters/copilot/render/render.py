#!/usr/bin/env python3
"""
Copilot adapter renderer — reuses adapters/generic/render/render.py
verbatim. Output path + degradations differ; content shape is identical.

Per CONTRACT.md, exposes `render_seed(*, seif_dir, project_dir, home,
content_kind, **kwargs) -> str`.
"""
from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

_HERE = Path(__file__).resolve().parent
_ADAPTER_DIR = _HERE.parent
_GENERIC_RENDER = (_ADAPTER_DIR.parent / "generic" / "render").resolve()

if str(_GENERIC_RENDER) not in sys.path:
    sys.path.insert(0, str(_GENERIC_RENDER))

import render as _generic  # type: ignore[import-not-found]


def render_seed(*, seif_dir: Path, project_dir: Path, home: Path,
                content_kind: str, **kwargs: Any) -> str:
    """Delegate to generic.render_seed with this adapter's directory pinned,
    so generic reads THIS manifest.json:degradations[] (Copilot's, not generic's)."""
    kwargs.setdefault("adapter_dir", _ADAPTER_DIR)
    return _generic.render_seed(
        seif_dir=seif_dir, project_dir=project_dir, home=home,
        content_kind=content_kind, **kwargs,
    )


if __name__ == "__main__":
    import argparse
    import os

    parser = argparse.ArgumentParser(description="Render Copilot adapter content")
    parser.add_argument("--content-kind", required=True,
                        choices=["full_seed", "kernel_seed", "axioms_summary",
                                 "session_contract_static", "degradation_notice"])
    parser.add_argument("--seif-dir", default="")
    parser.add_argument("--project-dir", default=os.getcwd())
    parser.add_argument("--home", default=str(Path.home()))
    args = parser.parse_args()

    print(render_seed(
        seif_dir=Path(args.seif_dir) if args.seif_dir else Path(),
        project_dir=Path(args.project_dir),
        home=Path(args.home),
        content_kind=args.content_kind,
    ))
