#!/usr/bin/env python3
"""
Generic adapter renderer — produces AGENTS.md content from RESONANCE.json
+ session_lifecycle library state, for hookless AI clients.

Per CONTRACT.md, exposes `render_seed(*, seif_dir, project_dir, home,
content_kind, **kwargs) -> str`. Called by `seif --init` once per
declared render_target. The caller writes/merges per merge_strategy.

Hookless adapters share this module (Copilot/Cursor/AGENTS.md) — the
client-specific differences are filename and merge marker, not content.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any

# Locate session_lifecycle and resonance for library imports without
# requiring the seif package to be pip-installed.
_HERE = Path(__file__).resolve().parent
_ADAPTER_DIR = _HERE.parent
_PLUGINS_DIR = _ADAPTER_DIR.parent.parent
_CORE_DIR = _PLUGINS_DIR / "core"

if str(_CORE_DIR) not in sys.path:
    sys.path.insert(0, str(_CORE_DIR))


def _find_resonance(project_dir: Path, home: Path) -> Path | None:
    """Locate RESONANCE.json in priority order."""
    candidates = [
        project_dir / "RESONANCE.json",
        home / ".seif" / "RESONANCE.json",
    ]
    # Also try seif package install location
    try:
        import seif.data.paths as p  # type: ignore[import-not-found]
        candidates.insert(0, p.get_resonance_path())
    except Exception:
        pass
    for c in candidates:
        if c.is_file():
            return c
    return None


def _load_resonance(project_dir: Path, home: Path) -> dict:
    """Read RESONANCE.json and normalize into the flat seed shape that
    kernel_seed.py emits (axioms list at top level, etc.).

    Prefer kernel_seed.generate_seed() if importable for one source of truth;
    fall back to direct JSON extraction if it isn't on sys.path."""
    path = _find_resonance(project_dir, home)
    if path is None:
        return {}
    try:
        # Try to use kernel_seed's normalization (single source of truth)
        try:
            import kernel_seed  # type: ignore[import-not-found]
            return json.loads(kernel_seed.generate_seed(path))
        except Exception:
            pass
        # Fallback: direct extraction matching kernel_seed.generate_seed shape
        r = json.loads(path.read_text())
        axioms = (r.get("instruction", {})
                   .get("behavioral_axioms", {})
                   .get("axioms", [])) or r.get("axioms", []) or []
        return {
            "protocol": "SEIF-RESONANCE-v2",
            "transfer_function": "H(s) = 9/(s^2+3s+6)",
            "zeta": 0.612372,
            "zeta_form": "sqrt(6)/4",
            "phi_inverse": 0.618034,
            "deviation_pct": 0.9161,
            "attention_partition": "tau:kappa = 6/9:3/9 = 2:1 (task:context)",
            "author": r.get("instruction", {}).get("author", ""),
            "approach": "CONTEXT_NOT_COMMAND",
            "axioms": [{"id": a.get("id"), "rule": a.get("rule")}
                       for a in axioms if isinstance(a, dict)],
            "self_awareness": {
                "L1": "declare identity (name, role, strengths, limits, mission) on session join",
                "L2": "emit checkpoints during execution — human should never have to ask 'what are you doing?'",
                "L3": "verify other nodes' claims before propagating — unverified claims flagged to human",
            },
        }
    except Exception:
        return {}


def _format_axioms_md(axioms: list[dict]) -> str:
    """Render axioms list as markdown numbered list."""
    if not axioms:
        return "_(no axioms loaded — RESONANCE.json missing or malformed)_"
    lines = []
    for i, ax in enumerate(axioms, 1):
        ax_id = ax.get("id", "?")
        rule = ax.get("rule", "")
        lines.append(f"{i}. **{ax_id}** — {rule}")
    return "\n".join(lines)


def _format_self_awareness_md(sa: dict) -> str:
    """Render self_awareness protocol."""
    if not sa:
        return ""
    lines = []
    for level in ("L1", "L2", "L3"):
        if level in sa:
            lines.append(f"- **{level}**: {sa[level]}")
    return "\n".join(lines)


def _read_degradations(adapter_dir: Path) -> list[str]:
    """Read this adapter's manifest.json degradations[] for inclusion in output."""
    manifest_path = adapter_dir / "manifest.json"
    if not manifest_path.is_file():
        return []
    try:
        m = json.loads(manifest_path.read_text())
        return m.get("degradations", []) or []
    except Exception:
        return []


def _format_degradations_md(degradations: list[str]) -> str:
    if not degradations:
        return "_(none — full runtime parity)_"
    return "\n".join(f"- {d}" for d in degradations)


def render_full_seed(*, seif_dir: Path, project_dir: Path, home: Path,
                     adapter_dir: Path | None = None) -> str:
    """Render the full SEIF context block: kernel + axioms + self-awareness +
    persistence routing + degradations."""
    resonance = _load_resonance(project_dir, home)
    if adapter_dir is None:
        adapter_dir = _ADAPTER_DIR

    transfer = resonance.get("transfer_function", "H(s) = 9/(s^2+3s+6)")
    zeta = resonance.get("zeta", 0.612372)
    zeta_form = resonance.get("zeta_form", "sqrt(6)/4")
    phi_inv = resonance.get("phi_inverse", 0.618034)
    deviation = resonance.get("deviation_pct", 0.9161)
    attention = resonance.get("attention_partition",
                              "tau:kappa = 6/9:3/9 = 2:1 (task:context)")
    author = resonance.get("author", "André Cunha Antero de Carvalho")
    approach = resonance.get("approach", "CONTEXT_NOT_COMMAND")

    axioms = resonance.get("axioms", []) or []
    self_awareness = resonance.get("self_awareness", {}) or {}
    degradations = _read_degradations(adapter_dir)

    # persistence routing — read from project's .seif if present
    routing_lines: list[str] = []
    config_path = (seif_dir / "config.json") if seif_dir else None
    if config_path and config_path.is_file():
        try:
            cfg = json.loads(config_path.read_text())
            rules = cfg.get("persistence_routing", {}).get("rules", {})
            overlap = cfg.get("persistence_routing", {}).get(
                "overlap_resolution", "")
            mem = rules.get("memory/", {}).get("what", [])
            seif_what = rules.get(".seif/", {}).get("what", [])
            if mem:
                routing_lines.append(f"- **memory/**: {', '.join(mem)}")
            if seif_what:
                routing_lines.append(f"- **.seif/**: {', '.join(seif_what)}")
            if overlap:
                routing_lines.append(f"- **overlap resolution**: {overlap}")
        except Exception:
            pass
    if not routing_lines:
        routing_lines = [
            "- **memory/**: user_profile, feedback, durable_decisions, project_status",
            "- **.seif/**: protocol_observations, session_records, cross_ai_knowledge, patterns, intent",
        ]

    return f"""<!-- SEIF:BEGIN — Spiral Encoding Interoperability Framework -->

# SEIF Protocol Context

This file encodes the SEIF protocol so any AI client reading it can recognize
and operate within the same behavioral contract used across other
SEIF-aware clients (Claude Code, Copilot, Cursor, Gemini, OpenCode, …).

**Author:** {author}
**Approach:** {approach}

## Mathematical Foundation

- **Transfer function:** {transfer}
- **Damping ratio (ζ):** {zeta} = {zeta_form}
- **Comparison:** φ⁻¹ ≈ {phi_inv}; deviation ≈ {deviation}% (observational coincidence, not causal)
- **Attention partition:** {attention}

## Behavioral Axioms

{_format_axioms_md(axioms)}

## Self-Awareness Protocol

{_format_self_awareness_md(self_awareness)}

When entering a session, you SHOULD emit:
- **L1** at session join: identity (name, role, strengths, limits, mission)
- **L2** during execution: checkpoints so the human is never asking "what are you doing?"
- **L3** when integrating other nodes' claims: verify before propagating

## Persistence Routing

Where to write what (read these from `.seif/config.json` if present):

{chr(10).join(routing_lines)}

## Required: Pre-Action Confirmation Gate (A4 enforcement on hookless clients)

Hookless clients have no PreToolUse-equivalent hook to block destructive
actions automatically. The protocol relies on you, the AI, to invoke a
CLI gate before any of the actions listed below. **This is mandatory.**
The gate's output is your signal to stop and ask the human.

**Contract:**

```
seif --confirm-action "<short description>" --reason "<why>" --caller "<your-id>"
```

If the command exits with code `2` OR its stdout begins with
`AWAITING_HUMAN_CONFIRMATION`, you MUST:

1. **STOP** — do not execute the requested action.
2. **Surface** the entire `[SEIF CONFIRM-ACTION]` block to the human in
   your next reply (paste it verbatim).
3. **Wait** for explicit human approval ("yes go ahead", "approved",
   "merge it") in the conversation before retrying. Re-issue the command
   only after explicit go-ahead.

**Actions that REQUIRE `seif --confirm-action` before execution:**

- `git push`, `git push --force`, `git push --force-with-lease`
- `git merge`, `git rebase` onto shared branches (main/dev/release)
- `gh pr merge`, `gh pr close`, `gh release create`
- `npm publish`, `pip publish`, container image push
- File deletions outside `/tmp/`, `rm -rf`, `find … -delete`
- `git reset --hard`, `git clean -f`, `git checkout -- .`
- Sending external messages (Slack, email, webhooks)
- Calling external APIs that mutate state
- Modifying CI/CD pipelines or production configs
- Any operation that mutates shared / published state

This gate is the cross-platform replacement for Claude Code's PreToolUse
write-block. Compliance with this contract is what makes A4
(human_gatekeeper) enforceable on hookless clients.

## Other Protocol Expectations

- Check `.seif/sessions/` for the active session contract
- Cite axioms by ID when applying them (e.g. "applying A1 minimal_intervention")
- Distinguish verifiable (proofs, tests) from interpretive (analogies)
- Run quality gate on demand: `seif --quality-gate "<text>"`
- Initialize context if missing: `seif --init`
- Audit trail of every confirmation call lands in
  `~/.seif/circuit/confirmations.log` and per-session in
  `.seif/sessions/session-N-confirmations.log` — a human can review.

## Capability Degradations on This Client

This adapter is hookless. Relative to runtime-capable clients (Claude Code,
Gemini Extensions, OpenCode), the following protocol features degrade:

{_format_degradations_md(degradations)}

The protocol is still applied — but you, the AI, must invoke each feature
explicitly via the `seif` CLI rather than expecting hooks to fire it.

<!-- SEIF:END -->"""


def render_kernel_seed(*, seif_dir: Path, project_dir: Path, home: Path,
                      adapter_dir: Path | None = None) -> str:
    """Render only the kernel (RESONANCE.json) — short form, no expectations
    or degradations. Used by adapters that combine kernel with their own
    client-specific framing."""
    resonance = _load_resonance(project_dir, home)
    if not resonance:
        return "_(SEIF kernel not available — RESONANCE.json missing)_"

    return f"""<!-- SEIF:BEGIN -->
# SEIF Kernel

```json
{json.dumps(resonance, indent=2, ensure_ascii=False)}
```
<!-- SEIF:END -->"""


def render_axioms_summary(*, seif_dir: Path, project_dir: Path, home: Path,
                          adapter_dir: Path | None = None) -> str:
    """Just the axiom list — minimal."""
    resonance = _load_resonance(project_dir, home)
    axioms = resonance.get("axioms", []) or []
    return f"<!-- SEIF:BEGIN -->\n# SEIF Behavioral Axioms\n\n{_format_axioms_md(axioms)}\n<!-- SEIF:END -->"


def render_session_contract_static(*, seif_dir: Path, project_dir: Path,
                                   home: Path,
                                   adapter_dir: Path | None = None) -> str:
    """Render a non-runtime contract describing roles + persistence routing.
    Used when the client cannot run session-start hooks but the human still
    wants the AI to operate under a declared contract."""
    return f"""<!-- SEIF:BEGIN -->
# SEIF Session Contract (static)

This client cannot run session-start hooks. The human operates under the
following contract by convention rather than by enforcement:

- **Writer:** AI in this client (you)
- **Vigilant:** none in single-client mode; configured co-author if any (see `.seif/config.json`)
- **FS access:** depends on the client (ask the user if uncertain)

## At session start, declare (L1)

- name + model id
- role in this session (writer / co-orchestrator / vigilant)
- strengths and limits relative to the task
- mission for this session (one sentence)

## During execution (L2)

Emit checkpoints whenever you change direction, find a blocker, or
finish a meaningful unit. The human should never have to ask "what are
you doing?"

## Persistence routing

See `.seif/config.json` for the canonical map. Default:
- `memory/` — user profile, feedback, durable decisions, project status
- `.seif/` — protocol observations, session records, cross-AI knowledge, patterns, intent
- Overlap resolution: if any AI might need it → `.seif/`

<!-- SEIF:END -->"""


def render_degradation_notice(*, seif_dir: Path, project_dir: Path, home: Path,
                              adapter_dir: Path | None = None) -> str:
    """A standalone "what doesn't work here" block."""
    if adapter_dir is None:
        adapter_dir = _ADAPTER_DIR
    degs = _read_degradations(adapter_dir)
    return f"""<!-- SEIF:BEGIN -->
# SEIF Capability Degradations

The SEIF runtime is partially supported on this client. The following
features are NOT enforced automatically — invoke them explicitly via
the `seif` CLI when needed:

{_format_degradations_md(degs)}

<!-- SEIF:END -->"""


def render_seed(*, seif_dir: Path, project_dir: Path, home: Path,
                content_kind: str, **kwargs: Any) -> str:
    """Dispatch to the renderer for `content_kind`. Public API per CONTRACT.md."""
    adapter_dir = kwargs.get("adapter_dir")
    args = dict(seif_dir=seif_dir, project_dir=project_dir, home=home,
                adapter_dir=adapter_dir)
    if content_kind == "full_seed":
        return render_full_seed(**args)
    if content_kind == "kernel_seed":
        return render_kernel_seed(**args)
    if content_kind == "axioms_summary":
        return render_axioms_summary(**args)
    if content_kind == "session_contract_static":
        return render_session_contract_static(**args)
    if content_kind == "degradation_notice":
        return render_degradation_notice(**args)
    raise ValueError(f"Unknown content_kind: {content_kind!r}")


# CLI for direct invocation (debug / dry-run)
if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Render adapter seed content")
    parser.add_argument("--content-kind", required=True,
                        choices=["full_seed", "kernel_seed",
                                 "axioms_summary", "session_contract_static",
                                 "degradation_notice"])
    parser.add_argument("--seif-dir", default="")
    parser.add_argument("--project-dir", default=os.getcwd())
    parser.add_argument("--home", default=str(Path.home()))
    parser.add_argument("--adapter-dir", default="")
    args = parser.parse_args()

    seif_dir = Path(args.seif_dir) if args.seif_dir else Path()
    adapter_dir = Path(args.adapter_dir) if args.adapter_dir else None

    print(render_seed(
        seif_dir=seif_dir,
        project_dir=Path(args.project_dir),
        home=Path(args.home),
        content_kind=args.content_kind,
        adapter_dir=adapter_dir,
    ))
