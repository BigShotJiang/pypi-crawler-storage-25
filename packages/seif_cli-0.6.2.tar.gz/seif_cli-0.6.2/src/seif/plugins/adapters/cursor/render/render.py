#!/usr/bin/env python3
"""
Cursor adapter renderer — wraps generic.render_seed and prepends the
Cursor `.mdc` YAML frontmatter (`alwaysApply: true`) so the rule is
loaded on every Cursor session in the workspace.

Per CONTRACT.md, exposes `render_seed(*, seif_dir, project_dir, home,
content_kind, **kwargs) -> str`.
"""
from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

_HERE = Path(__file__).resolve().parent
_ADAPTER_DIR = _HERE.parent
_GENERIC_RENDER = (_ADAPTER_DIR.parent / "generic" / "render").resolve()

if str(_GENERIC_RENDER) not in sys.path:
    sys.path.insert(0, str(_GENERIC_RENDER))

import render as _generic  # type: ignore[import-not-found]


_MDC_FRONTMATTER = """---
description: SEIF protocol context — behavioral axioms, persistence routing, capability degradations.
alwaysApply: true
---

"""


def render_seed(*, seif_dir: Path, project_dir: Path, home: Path,
                content_kind: str, **kwargs: Any) -> str:
    """Delegate to generic.render_seed with this adapter's manifest pinned,
    then prepend the .mdc frontmatter so Cursor recognizes the rule."""
    kwargs.setdefault("adapter_dir", _ADAPTER_DIR)
    body = _generic.render_seed(
        seif_dir=seif_dir, project_dir=project_dir, home=home,
        content_kind=content_kind, **kwargs,
    )
    return _MDC_FRONTMATTER + body


if __name__ == "__main__":
    import argparse
    import os

    parser = argparse.ArgumentParser(description="Render Cursor adapter content")
    parser.add_argument("--content-kind", required=True,
                        choices=["full_seed", "kernel_seed", "axioms_summary",
                                 "session_contract_static", "degradation_notice"])
    parser.add_argument("--seif-dir", default="")
    parser.add_argument("--project-dir", default=os.getcwd())
    parser.add_argument("--home", default=str(Path.home()))
    args = parser.parse_args()

    print(render_seed(
        seif_dir=Path(args.seif_dir) if args.seif_dir else Path(),
        project_dir=Path(args.project_dir),
        home=Path(args.home),
        content_kind=args.content_kind,
    ))
