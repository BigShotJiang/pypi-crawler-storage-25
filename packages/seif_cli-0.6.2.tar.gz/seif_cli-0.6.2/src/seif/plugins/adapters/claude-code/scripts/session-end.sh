#!/bin/bash
# SEIF SessionEnd hook (Claude Code adapter)
#
# Thin shim — CLOSURE/AUDIT/ABSORB phases live in plugins/core/session_lifecycle.py.
# Atomic mapper write-back (fcntl.flock) is preserved inside core's absorb_phase().
#
# This adapter handles only Claude-Code-side concerns:
#   - CIRCLE git auto-sync (.seif/ repo push to mini/origin)
#   - kill background circuit monitor process

set -euo pipefail

INPUT=""
if [ ! -t 0 ]; then
  INPUT=$(cat)
fi
SESSION_ID=""
if [ -n "$INPUT" ]; then
  SESSION_ID=$(echo "$INPUT" | python3 -c "import json,sys; print(json.load(sys.stdin).get('session_id','') )" 2>/dev/null || echo "")
fi
SESSION_ID="${SESSION_ID:-${SEIF_SESSION_ID:-}}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ -d "$SCRIPT_DIR/../../../core" ]; then
  CORE_DIR="$(cd "$SCRIPT_DIR/../../../core" && pwd)"
elif [ -d "$HOME/.local/share/seif/core" ]; then
  CORE_DIR="$HOME/.local/share/seif/core"
else
  CORE_DIR="$SCRIPT_DIR"
fi

LIFECYCLE="$CORE_DIR/session_lifecycle.py"
if [ -f "$LIFECYCLE" ]; then
  META_ENV="$(mktemp)"
  python3 "$LIFECYCLE" session-end \
    --cwd "$(pwd)" \
    --home "$HOME" \
    --session-id "$SESSION_ID" \
    --emit-env "$META_ENV"
  # shellcheck disable=SC1090
  [ -f "$META_ENV" ] && . "$META_ENV" && rm -f "$META_ENV"
fi

# CIRCLE — git auto-sync if .seif is a git repo
if [ -n "${SEIF_DIR:-}" ] && [ -d "$SEIF_DIR/.git" ]; then
  cd "$SEIF_DIR"
  git add -A 2>/dev/null
  git diff --cached --quiet 2>/dev/null || \
    git commit -m "session-end: auto-sync ($(date -u +"%Y-%m-%dT%H:%M:%SZ"))" --no-gpg-sign 2>/dev/null
  if git remote | grep -q "mini" 2>/dev/null; then
    git push mini main 2>/dev/null &
  fi
  if git remote | grep -q "origin" 2>/dev/null; then
    git push origin main 2>/dev/null &
  fi
fi

# Kill background circuit monitor
MONITOR_PID_FILE="$HOME/.seif/circuit/monitor.pid"
if [ -f "$MONITOR_PID_FILE" ]; then
  MONITOR_PID=$(cat "$MONITOR_PID_FILE" 2>/dev/null)
  if [ -n "$MONITOR_PID" ]; then
    kill "$MONITOR_PID" 2>/dev/null || true
  fi
  rm -f "$MONITOR_PID_FILE"
fi

exit 0
