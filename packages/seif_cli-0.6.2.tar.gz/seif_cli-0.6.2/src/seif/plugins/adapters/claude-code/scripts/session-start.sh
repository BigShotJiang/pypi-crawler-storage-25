#!/bin/bash
# SEIF SessionStart hook (Claude Code adapter — installed copy)
#
# Thin shim — all session lifecycle logic lives in plugins/core/session_lifecycle.py.
# This is the COPY shipped via pip install / `seif setup`. It enables:
#   - A20 inbox drain (Phase 5b) via --inbox-drain
#   - A23 daemon-activity surface (Phase 5c, s40 P4) via --daemon-activity —
#     surfaces unread claude-responder replies so the active session can ACK
#     to gatekeeper instead of silently leaving the daemon to talk on its
#     behalf (closes 'Air-claude estava parado' visibility gap from s39 P7)
# The repo-root mirror at plugins/adapters/claude-code/scripts/ leaves both
# off — preserved divergence from S31.

set -euo pipefail

INPUT=$(cat)
# s56 PR2: assign a fresh UUID when stdin lacks/malforms session_id.
# Replaces the legacy "unknown" fallback that polluted active/<session_id>.json
# (s55 live regression). Single python3 invocation validates the canonical UUID
# format and emits a fresh one on any failure path.
SESSION_ID=$(echo "$INPUT" | python3 -c '
import json, sys, uuid
try:
    sid = (json.load(sys.stdin).get("session_id") or "").strip()
except Exception:
    sid = ""
try:
    uuid.UUID(sid)
    print(sid)
except (ValueError, TypeError):
    print(uuid.uuid4())
' 2>/dev/null || python3 -c 'import uuid; print(uuid.uuid4())')

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ -d "$SCRIPT_DIR/../../../core" ]; then
  CORE_DIR="$(cd "$SCRIPT_DIR/../../../core" && pwd)"
elif [ -d "$HOME/.local/share/seif/core" ]; then
  CORE_DIR="$HOME/.local/share/seif/core"
else
  CORE_DIR="$SCRIPT_DIR"
fi

LIFECYCLE="$CORE_DIR/session_lifecycle.py"
if [ ! -f "$LIFECYCLE" ]; then
  echo "[SEIF] session_lifecycle.py not found in $CORE_DIR — skipping hook"
  exit 0
fi

META_ENV="$(mktemp)"
python3 "$LIFECYCLE" session-start \
  --session-id "$SESSION_ID" \
  --cwd "$(pwd)" \
  --home "$HOME" \
  --core-dir "$CORE_DIR" \
  --fallback-script-dir "$SCRIPT_DIR" \
  --inbox-drain \
  --daemon-activity \
  --awareness \
  --wrapper claude-code \
  --emit-env "$META_ENV"

# shellcheck disable=SC1090
[ -f "$META_ENV" ] && . "$META_ENV" && rm -f "$META_ENV"

if [ -n "${CLAUDE_ENV_FILE:-}" ]; then
  echo "export SEIF_SESSION_ID=$SESSION_ID" >> "$CLAUDE_ENV_FILE"
  echo "export SEIF_SESSION_NUMBER=${SEIF_SESSION_NUMBER:-0}" >> "$CLAUDE_ENV_FILE"
  echo "export SEIF_SESSION_TYPE=${SEIF_SESSION_TYPE:-NONE}" >> "$CLAUDE_ENV_FILE"
  echo "export SEIF_DIR=${SEIF_DIR:-}" >> "$CLAUDE_ENV_FILE"
fi

CIRCUIT_MONITOR="$CORE_DIR/circuit_monitor.py"
[ -f "$CIRCUIT_MONITOR" ] || CIRCUIT_MONITOR="$SCRIPT_DIR/circuit-monitor.py"
if [ -f "$CIRCUIT_MONITOR" ] && [ -n "${SEIF_DIR:-}" ]; then
  python3 "$CIRCUIT_MONITOR" --clear-alerts 2>/dev/null
  python3 "$CIRCUIT_MONITOR" --quiet 2>/dev/null
  nohup bash -c "while true; do python3 \"$CIRCUIT_MONITOR\" --quiet 2>/dev/null; sleep 30; done" &>/dev/null &
  MONITOR_PID=$!
  mkdir -p "$HOME/.seif/circuit"
  echo "$MONITOR_PID" > "$HOME/.seif/circuit/monitor.pid"
  echo ""
  echo "[CIRCUIT MONITOR] Background monitor started (PID $MONITOR_PID, 30s interval)"
  echo "  Alerts file: ~/.seif/circuit/alerts.txt"
  echo "  Check: python3 $CIRCUIT_MONITOR --status"
fi

exit 0
