"""MCP wrapper for the Phase 1 audio watermark API (Wedge A v1.0 DoD item 6).

Exposes four tools to MCP-aware clients (Claude Desktop, etc.):

- ``seif_watermark_embed`` — overlay text/sha256 payload onto a WAV
- ``seif_watermark_extract`` — recover payload from a watermarked WAV
- ``seif_fingerprint_file`` — sha256 hex of arbitrary file bytes
- ``seif_watermark_verify`` — extract + compare against expected fingerprint

This is the **pure-local provenance demo** path: no network, no transparency
log dependency, no API keys. Spec source-of-truth for the underlying watermark
encoding lives in :mod:`seif.generators.watermark`.

Optional extra: ``pip install seif-cli[mcp]``.
Run as: ``seif --mcp-watermark`` (stdio transport).
"""

from __future__ import annotations

from pathlib import Path
from typing import Any


def build_server() -> Any:
    """Return a configured FastMCP server. Imports mcp lazily.

    Raises ``ImportError`` with an actionable message if the ``mcp`` extra
    is not installed.
    """
    try:
        from mcp.server.fastmcp import FastMCP
    except ImportError as e:  # pragma: no cover - exercised manually
        raise ImportError(
            "MCP server requires the [mcp] extra. "
            "Install with: pip install 'seif-cli[mcp]'"
        ) from e

    from seif.generators.watermark import (
        WatermarkConfig,
        WatermarkError,
        embed_watermark_wav,
        extract_watermark_wav,
        file_sha256_hex,
    )

    server = FastMCP("seif-watermark")

    @server.tool()
    def seif_watermark_embed(
        input_wav: str,
        output_wav: str,
        text: str | None = None,
        fingerprint_of: str | None = None,
        repetitions: int = 3,
        symbol_duration: float = 4.0,
        amplitude: float = 0.005,
    ) -> dict:
        """Overlay an inaudible (sub-20 Hz) text payload onto a WAV carrier.

        Provide either ``text`` (literal hex/alphabet payload) or
        ``fingerprint_of`` (path to a file whose sha256 hex digest becomes
        the payload, for AI artifact provenance demos).
        """
        payload, source = _resolve_payload(text, fingerprint_of, file_sha256_hex)
        config = WatermarkConfig(
            repetitions=repetitions,
            symbol_duration=symbol_duration,
            amplitude=amplitude,
        )
        try:
            meta = embed_watermark_wav(payload, input_wav, output_wav, config)
        except WatermarkError as e:
            return {"ok": False, "error": str(e), "source": source}
        return {"ok": True, "source": source, **meta}

    @server.tool()
    def seif_watermark_extract(
        input_wav: str,
        n_symbols: int,
        repetitions: int = 3,
        symbol_duration: float = 4.0,
    ) -> dict:
        """Recover a watermark payload from a WAV. Returns the decoded text.

        ``n_symbols`` must match the symbol count used at embed time
        (sha256 hex = 64 symbols by default).
        """
        config = WatermarkConfig(
            repetitions=repetitions,
            symbol_duration=symbol_duration,
        )
        try:
            decoded = extract_watermark_wav(input_wav, n_symbols, config)
        except WatermarkError as e:
            return {"ok": False, "error": str(e)}
        return {
            "ok": True,
            "payload": decoded,
            "n_symbols": n_symbols,
            "repetitions": repetitions,
        }

    @server.tool()
    def seif_fingerprint_file(path: str) -> dict:
        """Return the lowercase sha256 hex digest of a file's raw bytes."""
        p = Path(path)
        if not p.exists() or not p.is_file():
            return {"ok": False, "error": f"not a file: {path}"}
        return {"ok": True, "path": str(p), "sha256": file_sha256_hex(p)}

    @server.tool()
    def seif_watermark_verify(
        input_wav: str,
        expected_path: str,
        n_symbols: int = 64,
        repetitions: int = 3,
        symbol_duration: float = 4.0,
    ) -> dict:
        """Extract a payload and verify it matches sha256(expected_path).

        Default ``n_symbols=64`` matches a sha256 hex digest. Returns a dict
        with ``valid: bool`` plus the extracted and expected payloads for
        diagnostics.
        """
        expected_file = Path(expected_path)
        if not expected_file.exists() or not expected_file.is_file():
            return {"ok": False, "error": f"expected_path not a file: {expected_path}"}
        expected = file_sha256_hex(expected_file)
        config = WatermarkConfig(
            repetitions=repetitions,
            symbol_duration=symbol_duration,
        )
        try:
            extracted = extract_watermark_wav(input_wav, n_symbols, config)
        except WatermarkError as e:
            return {"ok": False, "error": str(e), "expected": expected}
        return {
            "ok": True,
            "valid": extracted == expected,
            "extracted": extracted,
            "expected": expected,
            "expected_source": str(expected_file),
        }

    @server.tool()
    def seif_audio_provenance_verify(
        input_wav: str,
        envelope: dict,
        n_symbols: int = 64,
        repetitions: int = 3,
        symbol_duration: float = 4.0,
    ) -> dict:
        """Verify an audio carrier binds to a SEIF envelope.

        Extracts the watermark payload from ``input_wav`` and compares
        it to ``envelope.content_sha256`` (the canonical Wedge A
        envelope from ``provenance_sign``).

        Returns ``{ok, valid, extracted, expected_content_sha256, ...}``.
        Independent of envelope signature validity — pair with
        ``provenance_verify`` for full chain (audio → envelope → original
        artifact).
        """
        from seif.audio_provenance import verify_audio_against_envelope

        return verify_audio_against_envelope(
            input_wav,
            envelope,
            n_symbols=n_symbols,
            repetitions=repetitions,
            symbol_duration=symbol_duration,
        )

    return server


def _resolve_payload(
    text: str | None,
    fingerprint_of: str | None,
    file_sha256_hex_fn: Any,
) -> tuple[str, str]:
    if (text is None) == (fingerprint_of is None):
        raise ValueError(
            "exactly one of `text` or `fingerprint_of` must be provided"
        )
    if fingerprint_of is not None:
        return file_sha256_hex_fn(fingerprint_of), f"sha256({fingerprint_of})"
    assert text is not None
    return text, "text"


def main() -> None:
    """Entry point: build the server and run it on stdio."""
    server = build_server()
    server.run()


if __name__ == "__main__":
    main()
