"""SEIF Model Context Protocol (MCP) servers.

Optional surface — requires the ``[mcp]`` extra (``pip install seif-cli[mcp]``).
Each module exposes a ``build_server()`` factory that returns a configured
FastMCP instance, plus a ``main()`` entry point that runs it on stdio.
"""
