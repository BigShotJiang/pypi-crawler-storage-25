"""Canonical SEIF MCP server (Wedge A Pillar 3, Phases 1+2).

Exposes the canonical SEIF tool set to MCP-aware clients (Cursor, Claude
Code, Claude Desktop, etc.):

Phase 1 — local-only, no network:

- ``provenance_sign`` — sign a payload (text or file) with the workspace
  Ed25519 key, returning a canonical envelope.
- ``provenance_verify`` — verify an envelope against the supplied payload.
- ``classification_check`` — classify text as PUBLIC / INTERNAL /
  CONFIDENTIAL using the SEIF auto-classifier.

Phase 2 — network-dependent (SEIF transparency log):

- ``log_append`` — submit an attestation to a SEIF transparency log
  (``$SEIF_LOG_URL`` or ``http://localhost:8000``), with auto-tenant
  bootstrap via SEIF-Ed25519 auth. Accepts a pre-built envelope from
  ``provenance_sign`` or a raw text/file payload.
- ``log_get`` — fetch a log entry by its server-assigned ``entry_id``.

Optional extra: ``pip install seif-cli[mcp]``.
Run as: ``seif --mcp-server`` (stdio transport).

Cursor / Claude Code MCP config snippet (drop into the client's
``mcp.json`` / equivalent):

    {
      "mcpServers": {
        "seif": {
          "command": "seif",
          "args": ["--mcp-server"],
          "env": {
            "SEIF_LOG_URL": "http://localhost:8000"
          }
        }
      }
    }

End-to-end chain (sign → log → verify) — see ``log_append_impl`` docstring.
"""

from __future__ import annotations

import base64
import hashlib
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


DEFAULT_LOG_URL = "http://localhost:8000"


# Public API: tool implementations live at module level so they are
# directly unit-testable. ``build_server`` wraps them as MCP tools.


def provenance_sign_impl(
    text: str | None = None,
    path: str | None = None,
) -> dict[str, Any]:
    """Sign a payload with the workspace Ed25519 key.

    Provide exactly one of ``text`` (literal payload) or ``path`` (file).
    Returns a canonical envelope:

        {
          "ok": true,
          "content_sha256": "<hex>",
          "content_size": <bytes>,
          "source": "text" | "file: <path>",
          "signed_at": "<iso8601>",
          "signature": {
            "algorithm": "Ed25519",
            "public_key": "<base64 raw>",
            "signed_hash": "<base64>",
            "key_fingerprint": "<hex16>"
          }
        }

    Raises FileNotFoundError if no signing key exists. Use
    ``seif keygen`` (or ``seif --init``) to generate one.
    """
    payload, source = _resolve_payload(text, path)
    content_hash = hashlib.sha256(payload).hexdigest()

    sig_block = _sign_content_hash(content_hash)
    return {
        "ok": True,
        "content_sha256": content_hash,
        "content_size": len(payload),
        "source": source,
        "signed_at": sig_block["signed_at"],
        "signature": sig_block,
    }


def provenance_verify_impl(
    envelope: dict[str, Any],
    text: str | None = None,
    path: str | None = None,
) -> dict[str, Any]:
    """Verify a signed envelope against the supplied payload.

    Re-computes the content sha256, validates the Ed25519 signature in
    ``envelope["signature"]``, and reports whether they match.

    Returns ``{ok, valid, content_sha256_match, signature_valid, ...}``.
    The two boolean signals are reported separately so callers can
    distinguish "right key, wrong content" from "right content, wrong
    key / tampered signature".
    """
    if "signature" not in envelope:
        return {"ok": False, "error": "envelope_missing_signature"}
    if "content_sha256" not in envelope:
        return {"ok": False, "error": "envelope_missing_content_sha256"}

    payload, source = _resolve_payload(text, path)
    actual_hash = hashlib.sha256(payload).hexdigest()
    expected_hash = envelope["content_sha256"]

    content_sha256_match = actual_hash == expected_hash

    signature_valid = _verify_signature(
        content_hash=expected_hash,
        signature_block=envelope["signature"],
    )

    return {
        "ok": True,
        "valid": content_sha256_match and signature_valid,
        "content_sha256_match": content_sha256_match,
        "signature_valid": signature_valid,
        "expected_content_sha256": expected_hash,
        "actual_content_sha256": actual_hash,
        "signer_public_key": envelope["signature"].get("public_key"),
        "signer_key_fingerprint": envelope["signature"].get("key_fingerprint"),
        "source": source,
    }


def classification_check_impl(text: str) -> dict[str, Any]:
    """Classify text as PUBLIC / INTERNAL / CONFIDENTIAL.

    Returns ``{ok, level, escalation_needed, length, reason}``.
    ``escalation_needed`` is True when level is INTERNAL or CONFIDENTIAL —
    a hint that a tenant-scoped MCP integrator should not forward this
    payload to a third-party model without explicit operator opt-in.
    """
    from seif.context.file_extractor import _auto_classify

    if not isinstance(text, str):
        return {"ok": False, "error": "text_must_be_string"}

    level = _auto_classify(text)
    return {
        "ok": True,
        "level": level,
        "escalation_needed": level in ("INTERNAL", "CONFIDENTIAL"),
        "length": len(text),
        "reason": f"auto-classified as {level} by seif.context.file_extractor._auto_classify",
    }


def log_append_impl(
    *,
    envelope: dict[str, Any] | None = None,
    text: str | None = None,
    path: str | None = None,
    entry_type: str = "ai.artifact",
    classification_ceil: str = "INTERNAL",
    workspace_fingerprint: str | None = None,
    log_url: str | None = None,
    timeout: float = 10.0,
) -> dict[str, Any]:
    """Submit an attestation to the SEIF transparency log.

    Provide exactly one of:
    - ``envelope`` — a canonical envelope from ``provenance_sign``
      (the chained path; recommended for end-to-end provenance)
    - ``text`` — literal payload (server attests to its sha256)
    - ``path`` — file whose bytes are the payload

    Auth: SEIF-Ed25519 with the **log identity** at
    ``~/.seif/identities/default.{key,pub}`` (auto-generated on first
    use; distinct from the ``provenance_sign`` workspace key by design —
    log identity = "this host's tenant", workspace key = "this owner's
    signature on artifacts"). On first signed submit the server
    auto-bootstraps a 'personal'-plan tenant under the pubkey.

    Returns server response on success: ``{ok, entry_id, sequence,
    canonical_sha256, submitted_at, ...}``. On failure:
    ``{ok: false, error: <message>, ...optional status/detail}``.

    End-to-end chain (sign → log → verify):
        env = provenance_sign(text="ai output")
        appended = log_append(envelope=env)
        # Later, anywhere with log access:
        retrieved = log_get(entry_id=appended["entry_id"])
        check = provenance_verify(envelope=env, text="ai output")
        # `retrieved["primary_content_sha256"]` matches env["content_sha256"];
        # check["valid"] confirms the signature against the original payload.
    """
    from seif.log.client import LogClientError, LogHTTPError, submit_entry
    from seif.log.identity import ensure_identity

    # Validate args: exactly one of envelope/text/path
    sources = [s for s in (envelope, text, path) if s is not None]
    if len(sources) != 1:
        return {
            "ok": False,
            "error": "exactly_one_of_envelope_text_or_path_required",
        }

    # Resolve content_sha256
    if envelope is not None:
        content_hash = envelope.get("content_sha256")
        if not content_hash or not _is_sha256_hex(content_hash):
            return {
                "ok": False,
                "error": "envelope_missing_or_invalid_content_sha256",
            }
        source = "envelope"
    else:
        try:
            payload, source = _resolve_payload(text, path)
        except (ValueError, FileNotFoundError) as e:
            return {"ok": False, "error": str(e)}
        content_hash = hashlib.sha256(payload).hexdigest()

    if classification_ceil not in ("PUBLIC", "INTERNAL", "CONFIDENTIAL"):
        return {
            "ok": False,
            "error": "classification_ceil_must_be_PUBLIC_INTERNAL_or_CONFIDENTIAL",
        }

    log_url = log_url or os.environ.get("SEIF_LOG_URL", DEFAULT_LOG_URL)

    try:
        identity = ensure_identity()
        response = submit_entry(
            identity,
            entry_type=entry_type,
            classification_ceil=classification_ceil,
            primary_content_sha256_hex=content_hash,
            workspace_fingerprint=workspace_fingerprint,
            log_url=log_url,
            timeout=timeout,
        )
    except LogHTTPError as e:
        return {
            "ok": False,
            "error": "log_http_error",
            "status": e.status,
            "detail": e.detail,
        }
    except LogClientError as e:
        return {"ok": False, "error": "log_client_error", "detail": str(e)}

    return {
        "ok": True,
        "source": source,
        "submitted_content_sha256": content_hash,
        "log_url": log_url,
        **{k: response[k] for k in ("id", "sequence", "submitted_at",
                                     "canonical_sha256", "tenant_id")
           if k in response},
        "entry_id": response.get("id"),  # convenience alias matching log_get input
    }


def log_get_impl(
    entry_id: str,
    *,
    log_url: str | None = None,
    timeout: float = 10.0,
) -> dict[str, Any]:
    """Fetch a log entry by its server-assigned ``entry_id`` (UUID).

    Auth: same SEIF-Ed25519 identity as ``log_append``. The log enforces
    tenant-scoping — entries belonging to a different tenant return 404
    (does not leak cross-tenant existence).

    Returns ``{ok, entry: {...full server row...}}`` on success.
    """
    from seif.log.client import LogClientError, LogHTTPError, verify_entry
    from seif.log.identity import ensure_identity

    if not isinstance(entry_id, str) or not entry_id:
        return {"ok": False, "error": "entry_id_required_non_empty_string"}

    log_url = log_url or os.environ.get("SEIF_LOG_URL", DEFAULT_LOG_URL)

    try:
        identity = ensure_identity()
        entry = verify_entry(identity, entry_id, log_url=log_url, timeout=timeout)
    except LogHTTPError as e:
        return {
            "ok": False,
            "error": "log_http_error",
            "status": e.status,
            "detail": e.detail,
        }
    except LogClientError as e:
        return {"ok": False, "error": "log_client_error", "detail": str(e)}

    return {"ok": True, "log_url": log_url, "entry": entry}


def _is_sha256_hex(value: str) -> bool:
    if not isinstance(value, str) or len(value) != 64:
        return False
    try:
        int(value, 16)
        return True
    except ValueError:
        return False


# ── Internal helpers ──────────────────────────────────────────────────


def _resolve_payload(text: str | None, path: str | None) -> tuple[bytes, str]:
    if (text is None) == (path is None):
        raise ValueError("exactly one of `text` or `path` must be provided")
    if path is not None:
        p = Path(path)
        if not p.exists() or not p.is_file():
            raise FileNotFoundError(f"not a file: {path}")
        return p.read_bytes(), f"file: {p}"
    assert text is not None
    return text.encode("utf-8"), "text"


def _sign_content_hash(content_hash_hex: str) -> dict[str, str]:
    """Sign a precomputed sha256 hex digest using the workspace key.

    Mirrors the signature block shape produced by
    ``seif.core.signing.sign_module`` so verifiers can use a uniform
    structure for both .seif modules and arbitrary AI artifacts.
    """
    from cryptography.hazmat.primitives.serialization import load_pem_private_key

    from seif.core.signing import (
        _private_key_path,
        get_public_key_base64,
        get_public_key_fingerprint,
    )

    priv_path = _private_key_path()
    if not priv_path.exists():
        raise FileNotFoundError(
            "No signing key found at "
            f"{priv_path}. Run: seif keygen (or seif --init)."
        )

    private_key = load_pem_private_key(priv_path.read_bytes(), password=None)
    signature_bytes = private_key.sign(content_hash_hex.encode())

    return {
        "algorithm": "Ed25519",
        "public_key": get_public_key_base64(),
        "signed_hash": base64.b64encode(signature_bytes).decode(),
        "signed_at": datetime.now(timezone.utc).isoformat(),
        "key_fingerprint": get_public_key_fingerprint(),
    }


def _verify_signature(
    content_hash: str,
    signature_block: dict[str, Any],
) -> bool:
    from cryptography.exceptions import InvalidSignature
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

    try:
        public_key_b64 = signature_block.get("public_key")
        signed_hash_b64 = signature_block.get("signed_hash")
        if not public_key_b64 or not signed_hash_b64:
            return False
        public_key_bytes = base64.b64decode(public_key_b64)
        signature_bytes = base64.b64decode(signed_hash_b64)
        public_key = Ed25519PublicKey.from_public_bytes(public_key_bytes)
        public_key.verify(signature_bytes, content_hash.encode())
        return True
    except (InvalidSignature, ValueError, TypeError):
        return False


# ── MCP server wrapper ────────────────────────────────────────────────


def build_server() -> Any:
    """Return a configured FastMCP server. Imports ``mcp`` lazily.

    Raises ``ImportError`` with an actionable message if the ``mcp`` extra
    is not installed.
    """
    try:
        from mcp.server.fastmcp import FastMCP
    except ImportError as e:  # pragma: no cover — exercised manually
        raise ImportError(
            "MCP server requires the [mcp] extra. "
            "Install with: pip install 'seif-cli[mcp]'"
        ) from e

    server = FastMCP("seif-provenance")

    @server.tool()
    def provenance_sign(
        text: str | None = None,
        path: str | None = None,
    ) -> dict:
        """Sign a payload with the workspace Ed25519 key.

        Provide exactly one of ``text`` (literal payload) or ``path``
        (path to a file whose bytes are the payload).
        """
        try:
            return provenance_sign_impl(text=text, path=path)
        except (ValueError, FileNotFoundError) as e:
            return {"ok": False, "error": str(e)}

    @server.tool()
    def provenance_verify(
        envelope: dict,
        text: str | None = None,
        path: str | None = None,
    ) -> dict:
        """Verify a signed envelope against the supplied payload.

        Pass the envelope produced by ``provenance_sign`` plus the
        original payload (text or file path).
        """
        try:
            return provenance_verify_impl(envelope=envelope, text=text, path=path)
        except (ValueError, FileNotFoundError) as e:
            return {"ok": False, "error": str(e)}

    @server.tool()
    def classification_check(text: str) -> dict:
        """Classify text as PUBLIC / INTERNAL / CONFIDENTIAL.

        Returns ``escalation_needed=True`` when the payload should not
        cross a tenant boundary without operator opt-in.
        """
        return classification_check_impl(text)

    @server.tool()
    def log_append(
        envelope: dict | None = None,
        text: str | None = None,
        path: str | None = None,
        entry_type: str = "ai.artifact",
        classification_ceil: str = "INTERNAL",
        workspace_fingerprint: str | None = None,
        log_url: str | None = None,
    ) -> dict:
        """Submit an attestation to the SEIF transparency log.

        Provide exactly one of ``envelope`` (from ``provenance_sign``),
        ``text``, or ``path``. Returns the server-assigned ``entry_id``
        plus per-tenant ``sequence`` and ``submitted_at``.
        """
        return log_append_impl(
            envelope=envelope,
            text=text,
            path=path,
            entry_type=entry_type,
            classification_ceil=classification_ceil,
            workspace_fingerprint=workspace_fingerprint,
            log_url=log_url,
        )

    @server.tool()
    def log_get(
        entry_id: str,
        log_url: str | None = None,
    ) -> dict:
        """Fetch a log entry by its UUID ``entry_id``.

        Tenant-scoped: entries from other tenants return 404.
        """
        return log_get_impl(entry_id=entry_id, log_url=log_url)

    return server


def main() -> None:
    """Entry point: build the server and run it on stdio."""
    server = build_server()
    server.run()


if __name__ == "__main__":
    main()
