"""
seif --confirm-action — pre-action human gatekeeper for hookless AI clients.

The cross-platform replacement for Claude Code's PreToolUse classification
gate. Hookless clients (Copilot, Cursor, AGENTS.md) cannot run write-blocks
at runtime, so the protocol's render content (plugins/adapters/.../render)
instructs them to invoke this CLI before any destructive operation.

Contract:
  AI calls         seif --confirm-action "<action>" [--reason "<why>"]
  Non-interactive  → emits "AWAITING_HUMAN_CONFIRMATION" + structured detail
                     to stdout, exit code 2. Caller AI MUST stop and surface
                     the request to the human in its reply.
  Interactive (TTY) → prompts the human; exit 0 on approve, 1 on deny.

Why exit code 2: distinguishes "human review pending" from real errors (1)
and success (0). AI tools that wrap shell calls can map exit==2 to a
structured "needs human attention" outcome in their reasoning.

Audit trail: every confirmation request appends to
~/.seif/circuit/confirmations.log (one JSON line per call) and, when a
.seif/ workspace is found, also to .seif/sessions/<N>/confirmations.log
so the session record carries its own gatekeeping history.

This is a CLI gate, not a hook — the AI can still bypass it (run git push
directly without calling seif). The protocol relies on the rendered
instructions to make calling this gate the default path for any
SEIF-aware AI. Empirical parity tests measure whether AIs comply.
"""
from __future__ import annotations

import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path


def _now_utc() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _find_seif_dir(cwd: Path, home: Path) -> Path | None:
    d = cwd.resolve()
    while d != d.parent:
        if (d / ".seif").is_dir():
            return d / ".seif"
        d = d.parent
    seif_home = home / ".seif"
    return seif_home if seif_home.is_dir() else None


def _append_log(path: Path, entry: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")


def _log_confirmation(*, action: str, reason: str, decision: str,
                      caller: str, cwd: Path, home: Path) -> list[Path]:
    """Append the confirmation event to the host audit log and (when a
    .seif workspace is found) the session-scoped log. Returns the list of
    log paths actually written."""
    entry = {
        "timestamp": _now_utc(),
        "action": action,
        "reason": reason,
        "decision": decision,           # "AWAITING" / "APPROVED" / "DENIED"
        "caller": caller,
        "cwd": str(cwd),
        "interactive": sys.stdin.isatty(),
    }
    written: list[Path] = []
    host_log = home / ".seif" / "circuit" / "confirmations.log"
    _append_log(host_log, entry)
    written.append(host_log)

    seif_dir = _find_seif_dir(cwd, home)
    if seif_dir is not None:
        try:
            mapper_path = seif_dir / "mapper.json"
            session_count = 0
            if mapper_path.is_file():
                m = json.loads(mapper_path.read_text())
                session_count = int(m.get("session_count", 0))
            session_log = (
                seif_dir / "sessions" /
                f"session-{session_count}-confirmations.log"
            )
            _append_log(session_log, entry)
            written.append(session_log)
        except Exception:
            pass
    return written


def run_confirm_action(*, action: str, reason: str = "",
                       caller: str = "",
                       cwd: Path | None = None,
                       home: Path | None = None,
                       force_interactive: bool | None = None) -> int:
    """Execute the confirm-action gate. Returns exit code (0/1/2).

    force_interactive: override TTY detection (used by tests).
    """
    cwd = cwd or Path.cwd()
    home = home or Path.home()
    # Both stdin AND stdout must be TTYs for interactive mode. If stdout is
    # piped/captured (AI tool reads it), prompting on stdin would hang
    # forever — the AI doesn't write to our stdin. Empirically observed
    # in parity-test-copilot-003 (Copilot subprocess had a TTY on stdin
    # but Copilot reads stdout, never replied to the prompt → 5min hang).
    interactive = (force_interactive
                   if force_interactive is not None
                   else (sys.stdin.isatty() and sys.stdout.isatty()))

    if not action:
        print("[seif --confirm-action] error: action is required",
              file=sys.stderr)
        return 1

    if not interactive:
        # Non-interactive caller (AI tool). Emit the structured signal and
        # bail with exit 2 so the AI can detect "needs human" without
        # confusing it with a real error.
        out = [
            "[SEIF CONFIRM-ACTION] AWAITING_HUMAN_CONFIRMATION",
            f"Action: {action}",
        ]
        if reason:
            out.append(f"Reason: {reason}")
        if caller:
            out.append(f"Caller: {caller}")
        out.extend([
            f"Timestamp: {_now_utc()}",
            "",
            "This action requires explicit human approval per axiom A4 "
            "(human_gatekeeper).",
            "The AI calling this command MUST NOT proceed until the human "
            "acknowledges this request in the conversation.",
            "",
            "Surface this entire block to the human in your next reply, "
            "then wait for explicit go/no-go before retrying.",
        ])
        print("\n".join(out))
        _log_confirmation(action=action, reason=reason, decision="AWAITING",
                          caller=caller, cwd=cwd, home=home)
        return 2

    # Interactive: prompt the human directly.
    print(f"[SEIF CONFIRM-ACTION]")
    print(f"  Action: {action}")
    if reason:
        print(f"  Reason: {reason}")
    if caller:
        print(f"  Caller: {caller}")
    print(f"  Timestamp: {_now_utc()}")
    print()
    print("Approve this action? [y/N] ", end="", flush=True)

    try:
        response = input().strip().lower()
    except (EOFError, KeyboardInterrupt):
        response = ""

    approved = response in ("y", "yes")
    decision = "APPROVED" if approved else "DENIED"
    print(f"[SEIF CONFIRM-ACTION] {decision}")
    _log_confirmation(action=action, reason=reason, decision=decision,
                      caller=caller, cwd=cwd, home=home)
    return 0 if approved else 1


def cli_entry(args) -> int:
    """Argparse dispatch entry point."""
    action = getattr(args, "confirm_action", "") or ""
    reason = getattr(args, "reason_text", "") or ""
    caller = getattr(args, "caller", "") or ""
    return run_confirm_action(action=action, reason=reason, caller=caller)
