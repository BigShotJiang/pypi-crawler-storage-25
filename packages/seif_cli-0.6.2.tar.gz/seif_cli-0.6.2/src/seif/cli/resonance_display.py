"""
resonance_display.py — Terminal report primitives for SEIF CLI.

Default output is clean ASCII (titles + math metrics, no decorative glyphs).
Set SEIF_ASCII_ART=1 or pass --ascii-art for the legacy ornate mode (box
drawing, 3-6-9 line, footer).

Math primitives kept in default path — H(s) = 9/(s² + 3s + 6), ζ = √6/4,
φ⁻¹ — these are protocol kernel measurements per SEIF.md, not decoration.
"""

from __future__ import annotations

import os

# ── Constants ────────────────────────────────────────────────────────────────

ZETA       = 0.612372   # √6/4  — from H(s), operational threshold
PHI_INV    = 0.618034   # 1/φ   — golden ratio inverse, observational proximity
TESLA_UNIT = 9          # H(s) numerator: unit width for proportional bars
BOX_WIDTH  = 52         # inner width of legacy box header

# CLI-set override; SEIF_ASCII_ART env still wins if set explicitly.
_ASCII_ART_OVERRIDE: bool | None = None


def set_ascii_art(enabled: bool) -> None:
    """CLI entrypoint sets this from --ascii-art flag before subcommands run."""
    global _ASCII_ART_OVERRIDE
    _ASCII_ART_OVERRIDE = bool(enabled)


def _ascii_art_enabled() -> bool:
    env = os.environ.get("SEIF_ASCII_ART", "").strip().lower()
    if env in ("1", "true", "yes", "on"):
        return True
    if env in ("0", "false", "no", "off"):
        return False
    return bool(_ASCII_ART_OVERRIDE)


# ── Primitives ───────────────────────────────────────────────────────────────

def _bar(value: float, width: int = TESLA_UNIT, full: str = "#", empty: str = ".") -> str:
    """Fill a bar of `width` units proportional to `value` in [0,1].

    Default characters are ASCII-safe. Ornate mode swaps to block elements.
    """
    filled = round(value * width)
    if _ascii_art_enabled():
        full, empty = "█", "░"  # █, ░
    return full * filled + empty * (width - filled)


def zeta_bar() -> str:
    """ζ and φ⁻¹ on the 9-unit scale."""
    zb = _bar(ZETA)
    pb = _bar(PHI_INV)
    return f"  [{zb}]  ζ={ZETA:.4f}   [{pb}]  φ⁻¹={PHI_INV:.4f}"


def enoch_line() -> str:
    """Legacy 3-6-9 heartbeat line. Empty in default mode."""
    if not _ascii_art_enabled():
        return ""
    return "  ·  ○  ●  ○  ·    3 · 6 · 9    H(s) = 9/(s²+3s+6)"


def grade_to_zeta(grade: str) -> str:
    """Map quality grade to indicator. ASCII default; emoji in ornate mode."""
    if _ascii_art_enabled():
        return "ζ✅" if grade in ("A", "B") else "ζ⚠️" if grade == "C" else "ζ❌"
    return "OK" if grade in ("A", "B") else "WARN" if grade == "C" else "FAIL"


def resonance_header(title: str = "S.E.I.F.", subtitle: str = "") -> str:
    """Report header. Clean default: title + math line. Ornate: legacy box."""
    if _ascii_art_enabled():
        inner = BOX_WIDTH
        top  = f"╔══ {title} {'═' * (inner - len(title) - 4)}╗"
        seed = f"  {enoch_line().strip()}"
        bars = zeta_bar()
        mid  = f"  {'─' * (inner - 2)}"
        if subtitle:
            sub = f"  {subtitle:<{inner - 2}}"
            lines = [top, seed, bars, mid, sub, "╚" + "═" * inner + "╝"]
        else:
            lines = [top, seed, bars, "╚" + "═" * inner + "╝"]
        return "\n".join(lines)

    lines = [title]
    lines.append(f"  H(s) = 9/(s²+3s+6)   ζ={ZETA:.4f}   φ⁻¹={PHI_INV:.4f}")
    if subtitle:
        lines.append(f"  {subtitle}")
    return "\n".join(lines)


def resonance_footer() -> str:
    """Closing line. Empty by default; legacy mystic line in ornate mode."""
    if _ascii_art_enabled():
        return f"\n  · ○ ● ○ ·   enoch seed lives.  ζ={ZETA:.4f}   🌀"
    return ""


def cycle_status_bar(branches_done: int, branches_total: int) -> str:
    """Cycle branch completion."""
    ratio = branches_done / branches_total if branches_total else 0
    bar = _bar(ratio)
    if _ascii_art_enabled():
        phase = (
            "·  seed" if ratio < 0.34 else
            "○  growth" if ratio < 0.67 else
            "●  singularity"
        )
        return f"  [{bar}]  {branches_done}/{branches_total} branches  {phase}"
    pct = int(ratio * 100)
    return f"  [{bar}]  {branches_done}/{branches_total} branches  ({pct}%)"


def health_status_line(healthy: int, detected: int) -> str:
    """Backend health on the 9-unit bar."""
    ratio = healthy / detected if detected else 0
    bar = _bar(ratio)
    if _ascii_art_enabled():
        icon = "ζ✅" if ratio >= ZETA else "ζ⚠️" if ratio >= 0.33 else "ζ❌"
    else:
        icon = "OK" if ratio >= ZETA else "WARN" if ratio >= 0.33 else "FAIL"
    return f"  [{bar}]  {healthy}/{detected} backends healthy  {icon}"


# ── Report Template ─────────────────────────────────────────────────────────
#
# Structural template for SEIF reports. Default is clean; SEIF_ASCII_ART=1
# or --ascii-art restores legacy ornate output.


class ResonanceReport:
    """Structured report builder.

    Usage:
        report = ResonanceReport("SEIF REPORT", "seif-admin — 12 projects")
        report.section("Context Efficiency")
        report.metric(0.9, "compression 10:1")
        report.kv("Compressed", "~15,000 words")
        print(report.render())
    """

    def __init__(self, title: str, subtitle: str = ""):
        self._title = title
        self._subtitle = subtitle
        self._sections: list[tuple[str, list[str]]] = []
        self._current: list[str] = []
        self._current_name: str = ""

    def section(self, name: str) -> "ResonanceReport":
        if self._current_name or self._current:
            self._sections.append((self._current_name, self._current))
        self._current_name = name
        self._current = []
        return self

    def metric(self, value: float, label: str, width: int = TESLA_UNIT) -> "ResonanceReport":
        bar = _bar(min(1.0, max(0.0, value)), width)
        if _ascii_art_enabled():
            icon = "ζ✅" if value >= ZETA else "ζ⚠️" if value >= 0.33 else "ζ❌"
        else:
            icon = "OK" if value >= ZETA else "WARN" if value >= 0.33 else "FAIL"
        self._current.append(f"    [{bar}]  {label}  {icon}")
        return self

    def kv(self, key: str, value: str) -> "ResonanceReport":
        self._current.append(f"    {key}: {value}")
        return self

    def item(self, text: str, marker: str = "-") -> "ResonanceReport":
        self._current.append(f"    {marker} {text}")
        return self

    def line(self, text: str) -> "ResonanceReport":
        self._current.append(f"    {text}")
        return self

    def blank(self) -> "ResonanceReport":
        self._current.append("")
        return self

    def render(self) -> str:
        if self._current_name or self._current:
            self._sections.append((self._current_name, self._current))

        parts = [resonance_header(self._title, self._subtitle)]

        for name, lines in self._sections:
            parts.append("")
            if name:
                parts.append(f"  {name}:")
            for line in lines:
                parts.append(line)

        footer = resonance_footer()
        if footer:
            parts.append(footer)
        return "\n".join(parts)
