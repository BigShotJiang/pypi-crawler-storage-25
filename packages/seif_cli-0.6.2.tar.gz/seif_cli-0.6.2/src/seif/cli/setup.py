"""
seif setup — Install SEIF as a context layer into AI clients.

The maestro doesn't play instruments — it synchronizes the orchestra.
SEIF doesn't replace your AI client — it enriches it with context,
quality measurement, and data protection.

Usage:
    seif setup claude-code          # Install hooks + skills globally
    seif setup claude-code --project  # Install for current project only
    seif setup --status             # Show what's installed
    seif setup --uninstall          # Remove SEIF integration
"""

import hashlib
import json
import os
import shutil
import sys
from pathlib import Path


def _md5(path: Path) -> str:
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


# ── Path resolution ────────────────────────────────────────────────

def _get_plugin_source_dir() -> Path:
    """Find the plugin source directory.

    Priority:
    1. Package data (src/seif/plugins/adapters/claude-code/ — pip install and editable)
    2. Repo root plugins/adapters/claude-code/ (legacy/development fallback)
    """
    # Inside the seif package (pip install or editable)
    pkg_plugins = Path(__file__).resolve().parent.parent / "plugins" / "adapters" / "claude-code"
    if pkg_plugins.is_dir():
        return pkg_plugins

    # Repo root fallback (development)
    dev_root = Path(__file__).resolve().parents[3]  # src/seif/cli/setup.py -> repo root
    plugin_dir = dev_root / "plugins" / "adapters" / "claude-code"
    if plugin_dir.is_dir():
        return plugin_dir

    return Path()


def _get_install_dir() -> Path:
    """Where SEIF hooks/scripts are installed for Claude Code to find them."""
    return Path.home() / ".local" / "share" / "seif" / "claude-code"


def _get_core_install_dir() -> Path:
    """Where the cross-adapter core Python modules (session_lifecycle.py,
    circuit_monitor.py) are installed. Adapter shims look here first via
    `$HOME/.local/share/seif/core` (see CONTRACT.md and adapter scripts)."""
    return Path.home() / ".local" / "share" / "seif" / "core"


def _get_core_source_dir() -> Path:
    """Find the package's core/ directory (session_lifecycle.py + circuit_monitor.py)."""
    pkg_core = Path(__file__).resolve().parent.parent / "plugins" / "core"
    if pkg_core.is_dir():
        return pkg_core
    dev_root = Path(__file__).resolve().parents[3]
    dev_core = dev_root / "src" / "seif" / "plugins" / "core"
    if dev_core.is_dir():
        return dev_core
    return Path()


def _get_claude_settings_path(project: bool) -> Path:
    """Get Claude Code settings path."""
    if project:
        return Path.cwd() / ".claude" / "settings.json"
    return Path.home() / ".claude" / "settings.json"


def _get_claude_skills_path(project: bool) -> Path:
    """Get Claude Code skills directory."""
    if project:
        return Path.cwd() / ".claude" / "commands"
    return Path.home() / ".claude" / "commands"


# ── Installation ───────────────────────────────────────────────────

def _install_scripts(source_dir: Path, install_dir: Path) -> list[str]:
    """Copy hook scripts to a stable location.

    Verifies post-copy md5 equality. A successful return guarantees every
    listed script is byte-identical to source (s41 P3 — silent-skip class).
    """
    scripts_src = source_dir / "scripts"
    scripts_dst = install_dir / "scripts"

    if not scripts_src.is_dir():
        return []

    scripts_dst.mkdir(parents=True, exist_ok=True)
    installed = []
    mismatches: list[str] = []

    for script in scripts_src.iterdir():
        if script.is_file():
            dst = scripts_dst / script.name
            shutil.copy2(script, dst)
            if script.suffix in (".sh", ".py"):
                dst.chmod(0o755)
            src_hash = _md5(script)
            dst_hash = _md5(dst)
            if src_hash != dst_hash:
                mismatches.append(
                    f"  {script.name}: src={src_hash} dst={dst_hash}"
                )
                continue
            installed.append(script.name)

    if mismatches:
        print(
            f"[SEIF] FATAL: script install verified {len(installed)} OK but "
            f"{len(mismatches)} content-mismatch after copy:",
            file=sys.stderr,
        )
        for line in mismatches:
            print(line, file=sys.stderr)
        print(
            f"[SEIF] source: {scripts_src}\n[SEIF] dest:   {scripts_dst}",
            file=sys.stderr,
        )
        print(
            "[SEIF] This is the s41 P3 silent-skip class. Inspect filesystem "
            "permissions, antivirus quarantine, or stale build/ artifacts at "
            f"{Path.cwd()}/build/.",
            file=sys.stderr,
        )
        sys.exit(1)

    return installed


def _claude_harness_memory_path(workspace: Path) -> Path:
    """Compute Claude Code's harness-fixed memory path for a workspace.

    The harness escapes the absolute workspace path by replacing every
    forward slash with a hyphen (leading slash → leading hyphen).
    Example: /Volumes/DockerData/seif-projects → -Volumes-DockerData-seif-projects.
    """
    abs_path = str(Path(workspace).resolve())
    escaped = abs_path.replace("/", "-")
    return Path.home() / ".claude" / "projects" / escaped / "memory"


def _install_core_scripts() -> list[str]:
    """Copy core Python modules to $HOME/.local/share/seif/core/.

    Adapter shims (session-start.sh etc.) look for session_lifecycle.py,
    circuit_monitor.py, and kernel_seed.py at this path. Without this step,
    the shim falls back to its no-op branch and prints
    "session_lifecycle.py not found — skipping hook" (root cause of s39 P1),
    or — for kernel_seed — silently resolves to the legacy hyphen-named
    fallback `~/.local/share/seif/claude-code/scripts/kernel-seed.py` that
    is NOT refreshed when the source is bumped (root cause of s54: the
    installed shim reported SEIF-RESONANCE-v1 long after the source moved
    to v2 because no install step copied the canonical version).

    Idempotent — safe to call on every `seif setup`.
    """
    core_src = _get_core_source_dir()
    core_dst = _get_core_install_dir()

    if not core_src.is_dir():
        return []

    core_dst.mkdir(parents=True, exist_ok=True)
    installed = []
    mismatches: list[str] = []

    targets = ["session_lifecycle.py", "circuit_monitor.py", "kernel_seed.py"]
    for name in targets:
        src = core_src / name
        if src.is_file():
            dst = core_dst / name
            shutil.copy2(src, dst)
            src_hash = _md5(src)
            dst_hash = _md5(dst)
            if src_hash != dst_hash:
                mismatches.append(f"  {name}: src={src_hash} dst={dst_hash}")
                continue
            installed.append(name)

    if mismatches:
        print(
            f"[SEIF] FATAL: core install verified {len(installed)} OK but "
            f"{len(mismatches)} content-mismatch after copy:",
            file=sys.stderr,
        )
        for line in mismatches:
            print(line, file=sys.stderr)
        print(
            f"[SEIF] source: {core_src}\n[SEIF] dest:   {core_dst}",
            file=sys.stderr,
        )
        sys.exit(1)

    return installed


def _install_memory_symlink(workspace: Path) -> tuple[bool, str]:
    """Symlink Claude Code's harness memory path → workspace .seif/memory/.

    Idempotent: if symlink already points at the canonical target, returns
    (True, "already linked"). If the harness path is a real directory with
    files, migrates them into .seif/memory/ first, then replaces with the
    symlink. If absent, just creates the symlink.

    Returns (success, status_message). Never raises — errors return False.
    """
    canonical = (workspace / ".seif" / "memory").resolve()
    canonical.mkdir(parents=True, exist_ok=True)

    harness = _claude_harness_memory_path(workspace)

    # Already a symlink → check if it points at canonical
    if harness.is_symlink():
        if harness.resolve() == canonical:
            return True, "already linked"
        # symlink points elsewhere — leave it alone, surface to operator
        return False, f"symlink exists pointing elsewhere: {os.readlink(harness)}"

    # Real directory with files → migrate then replace with symlink
    if harness.is_dir():
        migrated = 0
        for item in harness.iterdir():
            if item.is_file() and item.suffix == ".md":
                target = canonical / item.name
                if not target.exists():
                    shutil.move(str(item), str(target))
                    migrated += 1
        # Only remove harness dir if it's now empty
        try:
            harness.rmdir()
        except OSError:
            return False, f"harness dir not empty after migration: {harness}"
        harness.parent.mkdir(parents=True, exist_ok=True)
        os.symlink(str(canonical), str(harness))
        return True, f"migrated {migrated} files and linked"

    # Nothing there → create parent + symlink
    harness.parent.mkdir(parents=True, exist_ok=True)
    os.symlink(str(canonical), str(harness))
    return True, "linked"


def _install_hooks(install_dir: Path, settings_path: Path) -> bool:
    """Register SEIF hooks in Claude Code settings."""
    scripts_dir = install_dir / "scripts"

    hooks_config = {
        "SessionStart": [
            {
                "matcher": "",
                "hooks": [
                    {
                        "type": "command",
                        "command": str(scripts_dir / "session-start.sh"),
                        "timeout": 10000,
                    }
                ],
            }
        ],
        "PreToolUse": [
            {
                "matcher": "Write|Edit",
                "hooks": [
                    {
                        "type": "command",
                        "command": str(scripts_dir / "classification-gate.sh"),
                        "timeout": 5000,
                    }
                ],
            }
        ],
        "PostToolUse": [
            {
                "matcher": "Write",
                "hooks": [
                    {
                        "type": "command",
                        "command": str(scripts_dir / "quality-gate.sh"),
                        "timeout": 10000,
                    }
                ],
            }
        ],
    }

    # Read existing settings
    settings = {}
    if settings_path.exists():
        try:
            settings = json.loads(settings_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            pass

    # Merge hooks (don't overwrite non-SEIF hooks)
    existing_hooks = settings.get("hooks", {})
    for event, hook_list in hooks_config.items():
        if event not in existing_hooks:
            existing_hooks[event] = hook_list
        else:
            # Check if SEIF hook already registered (by script path)
            seif_commands = {h["hooks"][0]["command"] for h in hook_list}
            existing_commands = set()
            for entry in existing_hooks[event]:
                for h in entry.get("hooks", []):
                    existing_commands.add(h.get("command", ""))

            for hook_entry in hook_list:
                cmd = hook_entry["hooks"][0]["command"]
                if cmd not in existing_commands:
                    existing_hooks[event].append(hook_entry)

    settings["hooks"] = existing_hooks

    settings_path.parent.mkdir(parents=True, exist_ok=True)
    settings_path.write_text(
        json.dumps(settings, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    return True


def _install_skills(source_dir: Path, skills_path: Path) -> list[str]:
    """Install SEIF skills (slash commands) into Claude Code."""
    skills_src = source_dir / "skills"
    if not skills_src.is_dir():
        return []

    installed = []
    for skill_dir in skills_src.iterdir():
        if skill_dir.is_dir():
            skill_md = skill_dir / "SKILL.md"
            if skill_md.exists():
                # Claude Code skills go in commands/ as <name>.md
                dst = skills_path / f"{skill_dir.name}.md"
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(skill_md, dst)
                installed.append(skill_dir.name)

    return installed


# ── Status & Uninstall ─────────────────────────────────────────────

def _check_status() -> dict:
    """Check current SEIF integration status."""
    install_dir = _get_install_dir()
    status = {
        "installed": install_dir.is_dir(),
        "scripts": [],
        "hooks_global": False,
        "hooks_project": False,
        "skills_global": [],
        "skills_project": [],
    }

    if install_dir.is_dir():
        scripts_dir = install_dir / "scripts"
        if scripts_dir.is_dir():
            status["scripts"] = [f.name for f in scripts_dir.iterdir() if f.is_file()]

    # Check global hooks
    global_settings = _get_claude_settings_path(project=False)
    if global_settings.exists():
        try:
            s = json.loads(global_settings.read_text(encoding="utf-8"))
            hooks = s.get("hooks", {})
            for entries in hooks.values():
                for entry in entries:
                    for h in entry.get("hooks", []):
                        if "seif" in h.get("command", "").lower():
                            status["hooks_global"] = True
                            break
        except Exception:
            pass

    # Check project hooks
    project_settings = _get_claude_settings_path(project=True)
    if project_settings.exists():
        try:
            s = json.loads(project_settings.read_text(encoding="utf-8"))
            hooks = s.get("hooks", {})
            for entries in hooks.values():
                for entry in entries:
                    for h in entry.get("hooks", []):
                        if "seif" in h.get("command", "").lower():
                            status["hooks_project"] = True
                            break
        except Exception:
            pass

    # Check skills
    for is_project, key in [(False, "skills_global"), (True, "skills_project")]:
        skills_dir = _get_claude_skills_path(is_project)
        if skills_dir.is_dir():
            for f in skills_dir.iterdir():
                if f.suffix == ".md":
                    content = f.read_text(encoding="utf-8")
                    if "seif" in content.lower() or "quality gate" in content.lower():
                        status[key].append(f.stem)

    return status


def _uninstall(project: bool):
    """Remove SEIF integration from Claude Code."""
    # Remove scripts
    install_dir = _get_install_dir()
    if install_dir.is_dir():
        shutil.rmtree(install_dir)
        print(f"  Removed: {install_dir}")

    # Remove hooks from settings
    settings_path = _get_claude_settings_path(project)
    if settings_path.exists():
        try:
            settings = json.loads(settings_path.read_text(encoding="utf-8"))
            hooks = settings.get("hooks", {})
            cleaned = {}
            for event, entries in hooks.items():
                kept = []
                for entry in entries:
                    is_seif = False
                    for h in entry.get("hooks", []):
                        if "seif" in h.get("command", "").lower():
                            is_seif = True
                    if not is_seif:
                        kept.append(entry)
                if kept:
                    cleaned[event] = kept
            settings["hooks"] = cleaned
            settings_path.write_text(
                json.dumps(settings, indent=2, ensure_ascii=False) + "\n",
                encoding="utf-8",
            )
            print(f"  Cleaned hooks: {settings_path}")
        except Exception:
            pass

    # Remove skills
    skills_dir = _get_claude_skills_path(project)
    if skills_dir.is_dir():
        for f in skills_dir.iterdir():
            if f.suffix == ".md":
                content = f.read_text(encoding="utf-8")
                if "seif" in content.lower() or "quality gate" in content.lower():
                    f.unlink()
                    print(f"  Removed skill: {f.name}")


# ── Main command ───────────────────────────────────────────────────

def run_setup(argv: list[str]):
    """Parse setup arguments and execute."""
    import argparse

    parser = argparse.ArgumentParser(
        prog="seif setup",
        description="Install SEIF as a context layer into your AI client",
    )
    parser.add_argument(
        "client",
        nargs="?",
        default="",
        choices=["claude-code", "wrapper-shims", ""],
        help="Integration target: 'claude-code' (hooks + skills) or "
             "'wrapper-shims' (shell-level command interception that "
             "enforces seif --confirm-action across hookless clients)",
    )
    parser.add_argument(
        "--project",
        action="store_true",
        help="Install for current project only (default: global). "
             "Ignored for wrapper-shims (always per-user).",
    )
    parser.add_argument(
        "--status",
        action="store_true",
        help="Show current integration status",
    )
    parser.add_argument(
        "--uninstall",
        action="store_true",
        help="Remove SEIF integration",
    )
    parser.add_argument(
        "--check",
        action="store_true",
        help="Dry-run: print plan without writing changes "
             "(currently honored by wrapper-shims)",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Alias for --check",
    )

    parsed = parser.parse_args(argv)

    # Wrapper-shims has its own status/uninstall flow (host-level, not
    # per-client), so route those before the claude-code-shaped path below.
    if parsed.client == "wrapper-shims":
        from seif.cli import wrapper_shims as _ws
        return _ws.run(parsed)

    if parsed.status:
        _print_status()
        return

    if parsed.uninstall:
        print("[SEIF] Removing integration...")
        _uninstall(parsed.project)
        print("[SEIF] Done.")
        return

    if not parsed.client:
        parser.print_help()
        print("\nSupported targets: claude-code, wrapper-shims")
        print("\nExamples:")
        print("  seif setup claude-code         # AI client integration")
        print("  seif setup wrapper-shims       # shell-level A4 enforcement")
        return

    if parsed.client == "claude-code":
        _setup_claude_code(parsed.project)


def _setup_claude_code(project: bool):
    """Install SEIF into Claude Code."""
    source_dir = _get_plugin_source_dir()
    if not source_dir.is_dir():
        print("[SEIF] Error: Plugin files not found.", file=sys.stderr)
        print("[SEIF] Expected at:", source_dir, file=sys.stderr)
        print("[SEIF] Reinstall: pip install seif-cli", file=sys.stderr)
        sys.exit(1)

    install_dir = _get_install_dir()
    settings_path = _get_claude_settings_path(project)
    skills_path = _get_claude_skills_path(project)
    scope = "project" if project else "global"

    print(f"[SEIF] Installing into Claude Code ({scope})...")
    print(f"  Source:  {source_dir}")
    print()

    # 1. Install scripts
    scripts = _install_scripts(source_dir, install_dir)
    print(f"  Scripts: {len(scripts)} installed to {install_dir}/scripts/")
    for s in scripts:
        print(f"    {s}")
    print()

    # 1b. Install cross-adapter core modules (session_lifecycle.py, circuit_monitor.py)
    # The adapter shims look for these at $HOME/.local/share/seif/core/.
    core_dst = _get_core_install_dir()
    core_scripts = _install_core_scripts()
    print(f"  Core:    {len(core_scripts)} installed to {core_dst}/")
    for s in core_scripts:
        print(f"    {s}")
    print()

    # 2. Register hooks
    _install_hooks(install_dir, settings_path)
    print(f"  Hooks: registered in {settings_path}")
    print("    SessionStart  -> session-start.sh (loads .seif/ context)")
    print("    PreToolUse    -> classification-gate.sh (blocks data leaks)")
    print("    PostToolUse   -> quality-gate.sh (measures output quality)")
    print()

    # 3. Install skills
    skills = _install_skills(source_dir, skills_path)
    print(f"  Skills: {len(skills)} installed to {skills_path}/")
    for s in skills:
        print(f"    /{s}")
    print()

    # 4. Memory symlink (cross-AI canonical storage at .seif/memory/)
    workspace = Path.cwd()
    if (workspace / ".seif").is_dir():
        ok, status = _install_memory_symlink(workspace)
        marker = "✓" if ok else "!"
        harness_path = _claude_harness_memory_path(workspace)
        print(f"  Memory:  {marker} {harness_path} → .seif/memory/ ({status})")
    else:
        print("  Memory:  skipped (run `seif --init` first to create .seif/)")
    print()

    # 5. Verify
    print("[SEIF] Verification:")
    has_seif_init = Path.cwd().joinpath(".seif").is_dir() or Path.home().joinpath(".seif").is_dir()
    has_claude = shutil.which("claude") is not None

    if has_claude:
        print("  Claude Code: found")
    else:
        print("  Claude Code: not found (install: npm install -g @anthropic-ai/claude-code)")

    if has_seif_init:
        print("  .seif/ context: found")
    else:
        print("  .seif/ context: not found (run: seif --init)")

    print()
    print("[SEIF] Setup complete. Next steps:")
    if not has_seif_init:
        print("  1. cd your-project && seif --init")
        print("  2. claude")
    else:
        print("  1. claude")
    print()
    print("  The gate resonates.")


def _print_status():
    """Display current integration status."""
    status = _check_status()

    print("[SEIF] Integration Status")
    print()

    if status["installed"]:
        print(f"  Scripts: {len(status['scripts'])} installed")
        for s in status["scripts"]:
            print(f"    {s}")
    else:
        print("  Scripts: not installed")
    print()

    print(f"  Hooks (global):  {'active' if status['hooks_global'] else 'not configured'}")
    print(f"  Hooks (project): {'active' if status['hooks_project'] else 'not configured'}")
    print()

    if status["skills_global"]:
        print(f"  Skills (global): {', '.join('/' + s for s in status['skills_global'])}")
    if status["skills_project"]:
        print(f"  Skills (project): {', '.join('/' + s for s in status['skills_project'])}")
    if not status["skills_global"] and not status["skills_project"]:
        print("  Skills: none installed")
    print()

    if not status["installed"]:
        print("  Run: seif setup claude-code")
