"""
seif — S.E.I.F. Unified CLI (single source of truth)

The maestro doesn't play instruments — it synchronizes the orchestra.
SEIF doesn't replace your AI client — it enriches it with context,
quality measurement, and data protection.

Quick start:
    pip install seif-cli
    cd your-project
    seif                            # that's it — handles everything

What `seif` does (intelligently):
    1. No .seif/ found?  → runs seif --init (scans project, generates context)
    2. No hooks?         → runs seif setup claude-code (installs integration)
    3. Everything ready? → launches claude directly (hooks handle context)

Other commands:
    seif -p "message"               # non-interactive query (print mode)
    seif --status                   # show context hierarchy
    seif setup --status             # show integration status
    seif --quality-gate "text"      # measure text quality (Grade A-F)
    seif --sync                     # re-sync git context
    seif --init                     # manual init (seif does this automatically)
    seif setup claude-code          # manual setup (seif does this automatically)
"""

import os
import shutil
import subprocess
import sys
from pathlib import Path

# Flags that belong to the session wrapper (everything else → cli.py)
_SESSION_FLAGS = {'-g', '--gemini', '-p', '--print', '--status', '-h', '--help', 'chat', 'serve', 'setup'}


def _is_session_mode() -> bool:
    """Determine if the user wants a session (wrapper) or admin (cli) mode.

    Rules:
      - No args at all → session (launch Claude)
      - Only session flags (-g, -p, --status) → session
      - Any flag starting with -- that isn't a session flag → admin (cli.py)
      - Positional text without flags → admin (cli.py pipeline)
    """
    argv = sys.argv[1:]

    if not argv:
        return True

    for arg in argv:
        if arg.startswith('-') and arg not in _SESSION_FLAGS:
            return False
        if not arg.startswith('-'):
            # Positional argument → could be text for pipeline or extra args for AI
            # If there are session flags present, treat as extra AI args
            # Otherwise, it's pipeline text → admin mode
            has_session_flag = any(a in _SESSION_FLAGS for a in argv)
            return has_session_flag

    return True


def _build_global_prompt() -> str:
    """Layer 1: SEIF_HOME context (KERNEL + defaults — always present)."""
    try:
        from seif.context.context_manager import build_startup_context
        return build_startup_context()
    except Exception:
        return "S.E.I.F. protocol active."


def _build_session_lifecycle_prompt(seif_dir: Path) -> str:
    """Build session lifecycle instructions when .seif/ exists.

    This is injected into the AI context so ANY backend (Claude, Gemini, etc.)
    knows how to manage SEIF sessions. The instructions are part of the
    protocol, not tied to any specific AI client.
    """
    # Check for open sessions
    sessions_dir = seif_dir / "sessions"
    open_sessions = []
    if sessions_dir.is_dir():
        import json as _json
        for f in sessions_dir.glob("*.seif"):
            try:
                data = _json.loads(f.read_text(encoding="utf-8"))
                if data.get("status") == "OPEN":
                    open_sessions.append(data.get("name", f.stem))
            except Exception:
                pass

    lines = [
        "[SEIF SESSION LIFECYCLE]",
        "This workspace has .seif/ — session management is active.",
        "",
        "## Writer obligations",
        "1. SESSION START: If no open session exists, create one:",
        '   seif --session create --session-name <YYYY-MM-DD-topic> --author <model> --session-message "<purpose>"',
        "2. DURING: Contribute at milestones (decisions, deliverables, bugs, insights):",
        '   seif --session contribute --session-name <name> --author <model> --session-message "<observation>"',
        "3. SESSION END: Before conversation ends, close the session:",
        "   seif --session close --session-name <name> --author <model>",
        "   This persists to .seif/modules/owner-session-history.seif automatically.",
        "",
        "## Rules",
        "- Session name format: YYYY-MM-DD-<short-topic>",
        "- Only contribute significant events, not every tool call",
        "- The human should never need to manage sessions manually",
    ]

    if open_sessions:
        lines.append(f"")
        lines.append(f"## Open sessions: {', '.join(open_sessions)}")
        lines.append(f"Resume contributing to the open session instead of creating a new one.")
    else:
        lines.append(f"")
        lines.append(f"## No open sessions — create one at the start of this conversation.")

    return "\n".join(lines)


def _build_local_prompt() -> str:
    """Layer 2: Local context (RESONANCE.json or .seif/ in cwd)."""
    cwd = Path.cwd()
    parts = []

    if (cwd / "RESONANCE.json").exists():
        parts.append(f"[LOCAL PROJECT: {cwd} has RESONANCE.json]")

    seif_dir = cwd / ".seif"
    if not seif_dir.is_dir():
        # Check parent (SCR pattern)
        parent_seif = cwd.parent / ".seif"
        if parent_seif.is_dir():
            seif_dir = parent_seif

    if seif_dir.is_dir():
        seif_files = sorted(seif_dir.glob("*.seif"))
        if seif_files:
            try:
                from seif.context.context_manager import load_module
                modules = []
                for f in seif_files:
                    try:
                        m = load_module(str(f))
                        if m.active:
                            modules.append(
                                f"MODULE ({m.source}, {m.compression_ratio:.0f}:1):\n"
                                f"{m.summary[:500]}"
                            )
                    except Exception:
                        pass
                if modules:
                    parts.append("[LOCAL .seif MODULES]")
                    parts.append("\n---\n".join(modules))
            except Exception:
                pass

        # Inject session lifecycle instructions
        parts.append(_build_session_lifecycle_prompt(seif_dir))

    if parts:
        return "\n\n".join(parts)

    # No local SEIF context — provide workspace status
    has_git = (cwd / ".git").is_dir()
    manifest = "none"
    for mf in ("pyproject.toml", "package.json", "Cargo.toml", "go.mod", "pom.xml", "Gemfile"):
        if (cwd / mf).exists():
            manifest = mf
            break

    subdirs = ", ".join(
        d.name + "/" for d in sorted(cwd.iterdir())
        if d.is_dir() and not d.name.startswith(".")
    )[:80] or "none"

    return (
        f"[WORKSPACE STATUS: {cwd}]\n"
        f"No .seif/ structure found. This directory has not been initialized with S.E.I.F.\n"
        f"Git repo: {'yes' if has_git else 'no'} | Manifest: {manifest} | Subdirs: {subdirs}\n"
        f"The user may benefit from running: seif --init\n"
        f"If they ask what to do, guide them through initialization and available features."
    )


def _build_prompt() -> str:
    """Assemble full startup prompt: global + local layers.

    The prompt is passed as a CLI argument to claude --append-system-prompt,
    so it must stay under ~200KB (OS execve limit). The KERNEL alone is ~44K
    chars when all modules are loaded. We cap the total to prevent the wrapper
    from hanging when many modules are active.

    Full context is already available via CLAUDE.md in the project directory.
    """
    global_prompt = _build_global_prompt()
    local_prompt = _build_local_prompt()
    full = f"{global_prompt}\n\n{local_prompt}"

    # Cap at 50K chars to stay safely within OS argument limits
    MAX_PROMPT = 50_000
    if len(full) > MAX_PROMPT:
        # Keep KERNEL (first section) + local prompt, truncate module summaries
        full = full[:MAX_PROMPT] + "\n\n[SEIF] Context truncated for CLI transport. Full context available via CLAUDE.md."
    return full


def check_ots_coverage(seif_dir: Path) -> dict:
    """Compute OTS-stamp coverage over sealed cycles + closed sessions.

    A sealed/closed artifact without a sibling .ots is a honest-measurement
    gap (A8): the protocol claims permanence (BTC anchor per A22) but the
    anchor was never written. This check reports presence only — actual
    blockchain verification stays in `seif --verify-stamp`.

    Returned shape:
        {"stamped": int, "missing": list[Path], "total": int}
    Files counted: .seif/cycles/*-SEALED.seif and
    .seif/sessions/session-*-closure.seif.
    """
    stamped: list[Path] = []
    missing: list[Path] = []
    candidates: list[Path] = []

    cycles_dir = seif_dir / "cycles"
    if cycles_dir.is_dir():
        candidates.extend(cycles_dir.glob("*-SEALED.seif"))

    sessions_dir = seif_dir / "sessions"
    if sessions_dir.is_dir():
        candidates.extend(sessions_dir.glob("session-*-closure.seif"))

    for f in candidates:
        ots = f.with_suffix(f.suffix + ".ots")
        if ots.exists():
            stamped.append(f)
        else:
            missing.append(f)

    return {
        "stamped": len(stamped),
        "missing": missing,
        "total": len(candidates),
    }


def _signal_ots_coverage(seif_dir: Path) -> None:
    """Emit one-line OTS coverage status to stderr (A8 honest measurement)."""
    try:
        cov = check_ots_coverage(seif_dir)
    except Exception:
        return
    if cov["total"] == 0:
        return
    if not cov["missing"]:
        print(
            f"[SEIF] OTS: ✓{cov['stamped']}/{cov['total']} sealed artifacts stamped",
            file=sys.stderr,
        )
        return
    miss_names = ", ".join(p.name for p in cov["missing"][:3])
    if len(cov["missing"]) > 3:
        miss_names += f", +{len(cov['missing']) - 3} more"
    print(
        f"[SEIF] OTS: ✓{cov['stamped']}/{cov['total']} stamped, "
        f"✗{len(cov['missing'])} unstamped ({miss_names}). "
        f"Run: seif --stamp <path>",
        file=sys.stderr,
    )


def _signal_workspace_provenance() -> None:
    """Emit resolved workspace path as the first line of every status surface.

    Closes tool-workspace-disambiguation: if `.seif/` is a symlink, the
    realpath is shown alongside so telemetry never claims a workspace it
    is not actually operating on.
    """
    try:
        from seif.context.workspace import resolve_workspace_with_provenance
    except Exception:
        return
    try:
        info = resolve_workspace_with_provenance()
    except Exception:
        return
    seif_dir = info.get("seif_dir")
    if seif_dir is None:
        return
    real_path = info.get("real_path")
    if info.get("is_symlink") and real_path is not None:
        print(f"[SEIF] Workspace: {seif_dir.absolute()} → {real_path}", file=sys.stderr)
    else:
        print(f"[SEIF] Workspace: {seif_dir.absolute()}", file=sys.stderr)


def _signal_pending_seed(seif_dir: Path) -> None:
    """Surface the most recent unconsumed SEED so the next session can act.

    Closes init-seed-auto-surfacing: SEED-*.json files were written at
    session-seal to bootstrap the successor session, but no code read
    them on session-start. Operators had to point to seeds manually.
    Now the wrapper surfaces path + seed_id + objective in one stderr
    block, then writes a `.consumed_at` sidecar so the seed does not
    re-fire on the next session-start.
    """
    try:
        from seif.context.workspace import find_pending_seed, mark_seed_consumed
    except Exception:
        return
    try:
        result = find_pending_seed(seif_dir)
    except Exception:
        return
    if result is None:
        return

    seed_path: Path = result["path"]
    data: dict = result["data"]
    seed_id = str(data.get("seed_id", seed_path.stem))

    objective = ""
    for k in data:
        if k.startswith("session_objective"):
            objective = str(data.get(k, ""))
            break
    if not objective:
        objective = str(data.get("_instruction", ""))
    objective = objective.strip().replace("\n", " ")
    if len(objective) > 200:
        objective = objective[:197] + "..."

    try:
        rel = seed_path.relative_to(seif_dir)
        rel_str = str(rel)
    except ValueError:
        rel_str = str(seed_path)
    print(f"[SEEDS PENDING ENTRY]", file=sys.stderr)
    print(f"  {rel_str} ({seed_id})", file=sys.stderr)
    if objective:
        print(f"  ↳ {objective}", file=sys.stderr)

    try:
        mark_seed_consumed(seed_path)
    except Exception:
        pass


def _signal_repo_state_diff(seif_dir: Path) -> None:
    """Surface last commits across federated repos in the workspace.

    Closes a resume-from-disconnect blind spot: when a session ended
    abruptly (SSH drop, mid-cycle interrupt) the next session-start
    had no signal about what landed in the interim. The transcript
    captures messages, not execution outcomes, so resume could redo
    work that already merged. Surfacing the last few commits per
    federated repo lets the operator (and the AI) detect divergence
    before planning anything.

    Read-only: shells `git log --oneline -<n>` per child repo of the
    workspace root. Stays silent on directories without `.git/`.
    """
    workspace = seif_dir.parent
    if not workspace.is_dir():
        return
    repos: list[Path] = []
    try:
        for child in sorted(workspace.iterdir()):
            if not child.is_dir():
                continue
            if (child / ".git").exists():
                repos.append(child)
            if len(repos) >= 8:
                break
    except OSError:
        return
    if not repos:
        return

    print("[REPO STATE — last commits across federated repos]", file=sys.stderr)
    for repo in repos:
        try:
            out = subprocess.run(
                ["git", "log", "--oneline", "-5"],
                cwd=str(repo),
                capture_output=True,
                text=True,
                timeout=3,
            )
        except (OSError, subprocess.TimeoutExpired):
            continue
        if out.returncode != 0:
            continue
        lines = [line for line in out.stdout.splitlines() if line.strip()]
        if not lines:
            continue
        print(f"  {repo.name}/", file=sys.stderr)
        for line in lines:
            print(f"    {line}", file=sys.stderr)


def _signal_protocol_status():
    """Signal to the human that the protocol loaded correctly."""
    _signal_workspace_provenance()
    try:
        from seif.context.context_manager import estimate_tokens, list_modules
    except ImportError:
        print("[SEIF] Context manager requires SEIF Suite. Learn more: https://seifos.io", file=sys.stderr)
        return
    from seif.core.resonance_signal import load_and_validate
    from seif.data.paths import get_resonance_path

    resonance_path = get_resonance_path()
    if not resonance_path.exists():
        print("[SEIF] KERNEL not found. Running without protocol.", file=sys.stderr)
        return

    try:
        signal, valid, msg = load_and_validate(str(resonance_path))
    except Exception as e:
        print(f"[SEIF] KERNEL load error: {e}", file=sys.stderr)
        return

    if not valid:
        print(f"[SEIF] KERNEL INVALID — {msg}", file=sys.stderr)
        print("[SEIF] Integrity compromised. Protocol NOT loaded.", file=sys.stderr)
        return

    try:
        tokens = estimate_tokens()
        modules = list_modules()
        active_count = sum(1 for m in modules if m.get("active", True))

        cwd = Path.cwd()
        local_seif = (cwd / ".seif").is_dir() or (cwd.parent / ".seif").is_dir()
        local_resonance = (cwd / "RESONANCE.json").exists()

        version = signal.get("protocol", "unknown")
        zeta = signal.get("validation", {}).get("zeta", 0)
        phi_inv = signal.get("validation", {}).get("phi_inverse", 0)
        dev_pct = signal.get("validation", {}).get("zeta_phi_deviation_pct", 0)

        print(f"[SEIF] Protocol: {version} | KERNEL: VALID", file=sys.stderr)
        print(
            f"[SEIF] Context: {active_count} modules, "
            f"~{tokens['total']} tokens ({tokens['total']/2000:.1f}K)",
            file=sys.stderr,
        )
        print(
            f"[SEIF] Signal: zeta={zeta:.6f}, phi_inv={phi_inv:.6f}, "
            f"deviation={dev_pct}%",
            file=sys.stderr,
        )

        if local_seif:
            seif_dir = cwd / ".seif" if (cwd / ".seif").is_dir() else cwd.parent / ".seif"
            local_count = len(list(seif_dir.glob("*.seif")))
            print(f"[SEIF] Local: .seif/ found ({local_count} modules)", file=sys.stderr)
            _signal_ots_coverage(seif_dir)
            _signal_pending_seed(seif_dir)
            _signal_repo_state_diff(seif_dir)
        elif local_resonance:
            print("[SEIF] Local: RESONANCE.json found", file=sys.stderr)
        else:
            print("[SEIF] Local: no .seif/ (run seif --init to add)", file=sys.stderr)

        # Conjugate pair status
        try:
            seif_dir = cwd / ".seif" if (cwd / ".seif").is_dir() else cwd.parent / ".seif"
            config_path = seif_dir / "config.json" if seif_dir.is_dir() else None
            if config_path and config_path.exists():
                import json as _json
                config = _json.load(open(config_path))
                cp = config.get("conjugate_pair", {})
                if cp.get("enabled"):
                    co = cp.get("co_author", "not configured")
                    print(f"[SEIF] Conjugate pair: co-author={co}", file=sys.stderr)
                else:
                    print(
                        "[SEIF] Conjugate pair: not configured. "
                        "Consider: seif --config co-author=<model>",
                        file=sys.stderr,
                    )
        except Exception:
            pass

        print("[SEIF] The gate resonates.", file=sys.stderr)
    except Exception:
        print("[SEIF] Protocol: VALID | Context loaded.", file=sys.stderr)


def _has_command(name: str) -> bool:
    """Check if a CLI command is available."""
    return shutil.which(name) is not None


def _launch_claude(prompt: str, print_mode: bool, extra_args: list[str]):
    """Launch Claude CLI with SEIF context.

    DEPRECATION NOTICE (2026-03-31, Session 17):
    Interactive session mode (`seif` without args) is deprecated.
    Evidence: 2 crashes (CLAUDE_WRAPPER_CRASH_V2) caused by VSCode wrapper
    context overflow, 0 crashes using `claude` CLI directly with CLAUDE.md.

    Preferred alternatives:
      - Interactive: `claude` (loads SEIF via CLAUDE.md automatically)
      - Native chat: `seif chat` (SDK direct, quality gate, multi-backend)
      - Quick query: `seif -p "question"` (still supported, safe)

    The wrapper adds --append-system-prompt which duplicates what CLAUDE.md
    already provides, while introducing a subprocess layer that inherits
    IDE context management issues.

    Decision documented in: .seif/projects/seif/decisions.seif v14
    """
    if not print_mode:
        print(
            "[SEIF] DEPRECATION: Interactive wrapper mode is deprecated.\n"
            "[SEIF] Use 'claude' directly (CLAUDE.md loads SEIF automatically)\n"
            "[SEIF] or 'seif chat' for native chat with quality gate.\n"
            "[SEIF] Reason: 2 crashes in wrapper vs 0 in CLI (Session 17).\n"
            "[SEIF] Continuing anyway...",
            file=sys.stderr,
        )

    if not _has_command("claude"):
        print("Error: Claude CLI not found. Install it first.", file=sys.stderr)
        sys.exit(1)

    args = ["claude"]
    if print_mode:
        args.append("--print")
    args.extend(["--append-system-prompt", prompt])
    args.extend(extra_args)

    os.execvp("claude", args)


def _launch_gemini(prompt: str, print_mode: bool, extra_args: list[str]):
    """Launch Gemini CLI with SEIF context."""
    if not _has_command("gemini"):
        print("Error: Gemini CLI not found. Install it first.", file=sys.stderr)
        sys.exit(1)

    args = ["gemini", "-m", "gemini-2.5-flash"]
    if print_mode:
        args.append("-p")
    args.extend(extra_args)

    subprocess.run(args, input=prompt, text=True)


def cmd_status():
    """Show context hierarchy."""
    try:
        from seif.context.context_manager import estimate_tokens, list_modules
    except ImportError:
        print("This feature requires SEIF Suite. Learn more: https://seifos.io")
        return
    from seif.data.paths import get_resonance_path

    print("═══ S.E.I.F. STATUS ═══")
    cwd = Path.cwd()
    print(f"CWD: {cwd}")
    print()

    # Local context
    if (cwd / "RESONANCE.json").exists():
        print("Local RESONANCE.json: FOUND")
    if (cwd / ".seif").is_dir():
        count = len(list((cwd / ".seif").glob("*.seif")))
        print(f"Local .seif/ modules: {count} files")
    elif (cwd.parent / ".seif").is_dir():
        count = len(list((cwd.parent / ".seif").glob("*.seif")))
        print(f"Parent .seif/ modules (SCR): {count} files")
    print()

    # Global context
    resonance = get_resonance_path()
    print(f"RESONANCE.json: {resonance}")
    exists = resonance.exists()
    print(f"  Status: {'FOUND' if exists else 'NOT FOUND'}")

    if exists:
        try:
            from seif.core.resonance_signal import load_and_validate
            _, valid, msg = load_and_validate(str(resonance))
            print(f"  Validation: {'VALID' if valid else 'INVALID'} — {msg}")
        except Exception as e:
            print(f"  Validation: ERROR — {e}")
    print()

    # Modules
    try:
        modules = list_modules()
        tokens = estimate_tokens()
        user_modules = [m for m in modules if not m.get("is_default")]
        default_modules = [m for m in modules if m.get("is_default")]
        print(f"Modules: {len(user_modules)} user, {len(default_modules)} protocol defaults")
        if user_modules:
            print()
            for m in user_modules:
                name = m.get("source") or m.get("filename", "?").replace(".seif", "")
                active = "" if m.get("active") else " (inactive)"
                coh = m.get("coherence", 0)
                coh_bar = "■" * int(coh * 5) + "□" * (5 - int(coh * 5))
                print(f"  {name} — {m['words']}w, coh={coh:.2f} {coh_bar}{active}")
        if not user_modules:
            print("  (none yet — use seif --sync or let your AI create modules)")
        print()
        print(f"Total tokens: ~{tokens['total']}")
        print(f"  Kernel: {tokens['kernel']} + Modules: {tokens['modules']} + Defaults: {len(default_modules)} modules (protocol knowledge)")
    except Exception as e:
        print(f"Module listing error: {e}")


def _run_session(argv: list[str]):
    """Intelligent session launcher — the single entry point.

    The maestro raises the baton. The orchestra plays.

    Decision tree:
      1. No .seif/ and no hooks -> first time: init + setup + launch
      2. Has .seif/ but no hooks -> setup + launch
      3. Has .seif/ and hooks   -> launch directly (hooks handle context)
      4. Print mode (-p)        -> quick query, skip setup checks
    """
    import argparse

    parser = argparse.ArgumentParser(
        prog="seif",
        description="S.E.I.F. — one command, full protocol",
        epilog=(
            "Usage:\n"
            "  seif                    Launch Claude with full SEIF context\n"
            '  seif -p "message"       Quick query (non-interactive)\n'
            "  seif -g                 Use Gemini instead of Claude\n"
            "  seif --status           Show context hierarchy\n"
            "\n"
            "First run in a new project? Just type 'seif' — it handles everything.\n"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("-g", "--gemini", action="store_true",
                        help="Use Gemini instead of Claude")
    parser.add_argument("-p", "--print", action="store_true", dest="print_mode",
                        help="Non-interactive (print mode)")
    parser.add_argument("--status", action="store_true",
                        help="Show context hierarchy")
    parser.add_argument("args", nargs="*", help="Extra arguments passed to the AI CLI")

    parsed = parser.parse_args(argv)

    if parsed.status:
        cmd_status()
        return

    # -- Print mode: quick query, no setup checks --
    if parsed.print_mode:
        prompt = _build_prompt()
        if parsed.gemini:
            _launch_gemini(prompt, True, parsed.args)
        else:
            _launch_claude(prompt, True, parsed.args)
        return

    # -- Interactive mode: intelligent context detection --
    cwd = Path.cwd()
    has_seif = _find_seif_dir(cwd) is not None
    has_hooks = _check_hooks_installed()
    has_claude = _has_command("claude")

    if not has_claude and not parsed.gemini:
        print("[SEIF] Claude Code not found.", file=sys.stderr)
        print("[SEIF] Install: npm install -g @anthropic-ai/claude-code", file=sys.stderr)
        sys.exit(1)

    # -- State 1: Nothing configured — first time --
    if not has_seif:
        print("[SEIF] No .seif/ context found in this project.", file=sys.stderr)
        print("[SEIF] Initializing full structure...", file=sys.stderr)
        print(file=sys.stderr)

        # Run seif --init for the workspace structure
        try:
            from seif.cli.cli import cmd_init
            cmd_init(str(cwd), author="", auto_yes=True)
        except Exception as e:
            print(f"[SEIF] Init failed: {e}", file=sys.stderr)
            print("[SEIF] Continuing without .seif/ context.", file=sys.stderr)

        has_seif = _find_seif_dir(cwd) is not None

        # Bootstrap host-level files in one shot (machine_id + model_registry).
        # These belong to the host, not the workspace, so run them only if absent.
        try:
            _bootstrap_host_files()
        except Exception as e:
            print(f"[SEIF] Host bootstrap warning: {e}", file=sys.stderr)

    # -- State 1b: Existing project — audit host structure (best effort, fast) --
    elif has_seif:
        try:
            _audit_and_fix_host(quiet=True)
        except Exception as e:
            print(f"[SEIF] Host audit warning: {e}", file=sys.stderr)

    # -- State 2: Has .seif/ but no hooks --
    if has_seif and not has_hooks and not parsed.gemini:
        print(file=sys.stderr)
        print("[SEIF] Hooks not installed. Setting up Claude Code integration...", file=sys.stderr)
        print(file=sys.stderr)

        try:
            from seif.cli.setup import _setup_claude_code
            _setup_claude_code(project=False)
        except Exception as e:
            print(f"[SEIF] Setup failed: {e}", file=sys.stderr)
            print("[SEIF] Continuing without hooks.", file=sys.stderr)

        print(file=sys.stderr)

    # -- State 3: Everything ready — launch --
    if parsed.gemini:
        # Gemini doesn't have hooks — use wrapper injection
        prompt = _build_prompt()
        _signal_protocol_status()
        _launch_gemini(prompt, False, parsed.args)
    else:
        # Claude with hooks — launch directly (hooks handle context)
        if has_hooks or _check_hooks_installed():
            _signal_protocol_status()
            _launch_claude_direct(parsed.args)
        else:
            # Fallback: inject via prompt if hooks somehow failed
            prompt = _build_prompt()
            _signal_protocol_status()
            _launch_claude(prompt, False, parsed.args)


def _bootstrap_host_files():
    """Generate host-level files that should exist on every machine.

    Idempotent: machine_id is created only if missing; model_registry is
    refreshed only if missing or stale. Bridge-config and sources are NOT
    created here — they require user input (peer hub address, repo list)
    and are best handled via `seif --init-host --hub ... --source ...`.
    """
    from seif.context.host_init import load_machine_id, ensure_machine_id
    from seif.context.model_probe import (
        probe_all, write_registry as write_model_registry,
        get_registry_path as get_model_registry_path,
    )
    import time as _time

    if load_machine_id() is None:
        payload, _created = ensure_machine_id()
        print(f"[SEIF] Created ~/.seif/machine_id "
              f"(label={payload['label']}, role={payload['role']})", file=sys.stderr)

    mrp = get_model_registry_path()
    needs_probe = (not mrp.exists()) or (
        (_time.time() - mrp.stat().st_mtime) > 86400  # > 24h
    )
    if needs_probe:
        result = probe_all()
        write_model_registry(result)
        print(f"[SEIF] Probed orchestra: {len(result.models)} models, "
              f"circuit={'on' if result.circuit.get('connected') else 'off'}",
              file=sys.stderr)


def _audit_and_fix_host(quiet: bool = False):
    """Run host-level audit; auto-fix missing items unless quiet=False.

    quiet=True only prints when something was wrong and got fixed; clean audits
    say nothing so the wrapper stays out of the way on healthy machines.
    """
    from seif.context.host_init import load_machine_id, ensure_machine_id
    from seif.context.model_probe import (
        probe_all, write_registry as write_model_registry,
        get_registry_path as get_model_registry_path,
    )
    from seif.context.registry import (
        load_registry, find_context_entry, rebuild_registry,
    )
    from seif.data.paths import get_user_home
    import time as _time
    import json as _json
    from datetime import datetime, timezone

    fixed = []
    warnings = []

    home = get_user_home()
    cwd = Path.cwd()
    workspace_seif = cwd / ".seif"

    # B: registry — ensure current workspace is registered.
    # Pass ONLY the current workspace as scan root — passing cwd.parent would
    # rglob entire $HOME when seif is invoked from ~/Desktop or similar,
    # hanging the process. Other workspaces stay registered via their own
    # first invocation.
    if workspace_seif.is_dir():
        try:
            registry = load_registry()
            entry = find_context_entry(registry, str(workspace_seif))
            if entry is None:
                rebuild_registry([str(cwd)])
                fixed.append("registry rebuilt with current workspace")
        except Exception as e:
            warnings.append(f"registry check: {e}")

    # C: model_registry freshness (>24h triggers reprobe)
    try:
        mrp = get_model_registry_path()
        if (not mrp.exists()) or (_time.time() - mrp.stat().st_mtime) > 86400:
            result = probe_all()
            write_model_registry(result)
            fixed.append(f"model_registry reprobed ({len(result.models)} models)")
    except Exception as e:
        warnings.append(f"model probe: {e}")

    # D: machine_id presence
    if load_machine_id() is None:
        try:
            payload, _ = ensure_machine_id()
            fixed.append(f"machine_id created (label={payload['label']})")
        except Exception as e:
            warnings.append(f"machine_id: {e}")

    # E: heartbeat liveness — warn only, don't auto-start the daemon
    hb = home / "heartbeat"
    if hb.exists():
        try:
            data = _json.loads(hb.read_text())
            ts = data.get("timestamp", "")
            t = datetime.fromisoformat(ts.replace("Z", "+00:00"))
            age = (datetime.now(timezone.utc) - t).total_seconds()
            if age > 300:
                warnings.append(f"heartbeat stale ({age:.0f}s) — heartbeatd may be down")
        except Exception:
            pass
    else:
        warnings.append("heartbeat absent — start seif-heartbeatd if you want circuit liveness")

    if fixed:
        print(f"[SEIF] Audit fixed: {'; '.join(fixed)}", file=sys.stderr)
    if warnings and not quiet:
        for w in warnings:
            print(f"[SEIF] Audit warn: {w}", file=sys.stderr)
    elif warnings and quiet:
        # In quiet mode, surface only critical warnings (heartbeat stale)
        critical = [w for w in warnings if "stale" in w]
        for w in critical:
            print(f"[SEIF] {w}", file=sys.stderr)


def _find_seif_dir(cwd: Path):
    """Walk up to find .seif/ directory."""
    d = cwd
    while d != d.parent:
        if (d / ".seif").is_dir():
            return d / ".seif"
        d = d.parent
    # Also check home
    home_seif = Path.home() / ".seif"
    if home_seif.is_dir():
        return home_seif
    return None


def _check_hooks_installed() -> bool:
    """Check if SEIF hooks are registered in Claude Code settings."""
    for settings_path in [
        Path.cwd() / ".claude" / "settings.json",
        Path.home() / ".claude" / "settings.json",
    ]:
        if settings_path.exists():
            try:
                import json
                settings = json.loads(settings_path.read_text(encoding="utf-8"))
                hooks = settings.get("hooks", {})
                for entries in hooks.values():
                    for entry in entries:
                        for h in entry.get("hooks", []):
                            if "seif" in h.get("command", "").lower():
                                return True
            except Exception:
                pass
    return False


def _launch_claude_direct(extra_args: list[str]):
    """Launch Claude Code directly — hooks handle SEIF context injection."""
    args = ["claude"]
    args.extend(extra_args)
    try:
        os.execvp("claude", args)
    except FileNotFoundError:
        print("[SEIF] 'claude' binary not found in PATH.", file=sys.stderr)
        print("[SEIF] Install Claude Code: npm install -g @anthropic-ai/claude-code", file=sys.stderr)
        print("[SEIF] Or run a non-launching subcommand: seif status | seif chat | seif --help", file=sys.stderr)
        sys.exit(127)
    except OSError as e:
        print(f"[SEIF] Failed to launch 'claude': {e}", file=sys.stderr)
        if e.errno == 8:  # ENOEXEC — wrong arch / corrupt binary
            print("[SEIF] The claude binary appears to be wrong architecture or corrupted.", file=sys.stderr)
            print("[SEIF] On Termux/Android, native claude does not exist — use seif chat or seif --help.", file=sys.stderr)
        sys.exit(127)


def main():
    """Unified entry point: session mode, chat mode, or admin mode based on argv."""
    argv = sys.argv[1:]

    # Native chat mode: seif chat [--backend X] [--no-stream] [--no-gate]
    if argv and argv[0] == "chat":
        _run_chat(argv[1:])
    elif argv and argv[0] == "setup":
        from seif.cli.setup import run_setup
        run_setup(argv[1:])
        return
    elif argv and argv[0] == "serve":
        _run_serve(argv[1:])
    elif argv and argv[0] == "status":
        cmd_status()
        return
    elif _is_session_mode():
        _run_session(argv)
    else:
        # Delegate to cli.py (admin mode)
        from seif.cli.cli import main as cli_main
        cli_main()


def _run_chat(argv: list[str]):
    """Parse chat flags and launch native client.

    DEPRECATION NOTE: seif chat with claude-cli backend is stateless
    (each message is a separate subprocess). For the best experience,
    use Claude Code directly with SEIF hooks:
        seif setup claude-code && claude

    seif chat remains useful for local backends (Ollama) that don't
    have their own interactive client.
    """
    import argparse

    print(
        "[SEIF] Note: For Claude/Gemini, prefer your native client with SEIF hooks:\n"
        "[SEIF]   seif setup claude-code && claude\n"
        "[SEIF] seif chat works best with local backends (--backend local).\n",
        file=sys.stderr,
    )

    parser = argparse.ArgumentParser(prog="seif chat",
                                     description="Native AI chat with SEIF context")
    parser.add_argument("--backend", "-b", default="auto",
                        help="AI backend: claude, gemini, local, auto (default: auto)")
    parser.add_argument("--model", "-m", default="",
                        help="Model override (default: auto per backend)")
    parser.add_argument("--no-stream", action="store_true",
                        help="Disable streaming (wait for full response)")
    parser.add_argument("--no-gate", action="store_true",
                        help="Disable quality gate on responses")

    parsed = parser.parse_args(argv)

    try:
        from seif.cli.chat import run_chat
    except ImportError:
        print("This feature requires SEIF Suite. Learn more: https://seifos.io")
        return
    run_chat(
        backend=parsed.backend,
        model=parsed.model,
        stream=not parsed.no_stream,
        quality_gate=not parsed.no_gate,
    )


def _run_serve(argv: list[str]):
    """Parse serve flags and launch context API server."""
    import argparse

    parser = argparse.ArgumentParser(prog="seif serve",
                                     description="SEIF Context API — read-only local server")
    parser.add_argument("--port", "-p", type=int, default=7331,
                        help="Port to listen on (default: 7331)")
    parser.add_argument("--host", default="127.0.0.1",
                        help="Host to bind (default: 127.0.0.1, localhost only)")
    parser.add_argument("--max-classification", default="INTERNAL",
                        choices=["PUBLIC", "INTERNAL"],
                        help="Maximum classification to expose (default: INTERNAL)")
    parser.add_argument("--v2", action="store_true",
                        help="Enable v2 API (sessions, quality gate, owner auth)")
    parser.add_argument("--engine", action="store_true",
                        help="Run the local engine HTTP service (Phase 2.B): "
                             "exposes classify/confirm-action/quality-gate over "
                             "HTTP for AI clients (Cursor agent mode, browser "
                             "agents, multi-step tools) that prefer in-process "
                             "calls over per-request Python spawns. Bearer-token "
                             "auth, 127.0.0.1 by default. Stdlib-only (no "
                             "seif-engine dependency).")

    parsed = parser.parse_args(argv)

    if parsed.engine:
        from seif.cli.serve_engine import run_server as _run_engine_server
        # --port default for engine differs from context API to avoid collision
        port = parsed.port if parsed.port != 7331 else 7332
        sys.exit(_run_engine_server(host=parsed.host, port=port))

    if parsed.v2:
        try:
            from seif.cli.serve_v2 import run_server_v2
        except ImportError:
            print("This feature requires SEIF Suite. Learn more: https://seifos.io")
            return
        run_server_v2(
            host=parsed.host,
            port=parsed.port,
            max_classification=parsed.max_classification,
        )
    else:
        try:
            from seif.cli.serve import run_server
        except ImportError:
            print("This feature requires SEIF Suite. Learn more: https://seifos.io")
            return
        run_server(
            host=parsed.host,
            port=parsed.port,
            max_classification=parsed.max_classification,
        )


if __name__ == "__main__":
    main()
