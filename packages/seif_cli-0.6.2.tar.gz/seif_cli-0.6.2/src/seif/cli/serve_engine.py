"""
seif serve --engine — local HTTP service exposing the engine surface.

Same primitives as the seif CLI flags shipped in PR #27 + #31 (confirm-action,
classify, quality-gate via existing modules), but reachable over HTTP so AI
clients that prefer in-process calls (Cursor agent mode, browser-side
agents, multi-step tools) avoid the per-call Python spawn cost.

Endpoints (all POST except /health):
  GET  /health                     → {"ok": true, "uptime_s": N}
  POST /classify                   → body={text} → {classification, exit_code, length}
  POST /quality-gate               → body={text, role?} → bridges to existing
                                     cmd_quality_gate when seif-engine is
                                     present; falls back to a 503 if not
  POST /confirm-action             → body={action, reason?, caller?} →
                                     {decision: "AWAITING", exit_code: 2, ...}

Auth: clients send the value of `~/.seif/host/engine-token` (auto-generated
on first launch) in the `Authorization` header using the standard
`Bearer <value>` scheme. The token value is NOT printed to stdout;
clients read the file.

Bind: 127.0.0.1 only by default. --host 0.0.0.0 explicit opt-in for
network exposure, but emits a warning on stderr per A4 (network exposure
is a write operation on the security boundary).

Stdlib-only (http.server + threading) so this doesn't depend on
seif-engine. Designed for low-volume agent calls — single-threaded
ThreadingHTTPServer is sufficient.
"""
from __future__ import annotations

import json
import secrets
import sys
import time
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any


# ── Token management ──────────────────────────────────────────────────────

_HOST_DIR = Path.home() / ".seif" / "host"
_TOKEN_FILE = _HOST_DIR / "engine-token"


def _ensure_token() -> str:
    """Read existing engine token or create one. 256-bit hex, mode 0o600."""
    if _TOKEN_FILE.is_file():
        try:
            existing = _TOKEN_FILE.read_text().strip()
            if existing:
                return existing
        except OSError:
            pass
    _HOST_DIR.mkdir(parents=True, exist_ok=True)
    token = secrets.token_hex(32)
    _TOKEN_FILE.write_text(token + "\n")
    try:
        _TOKEN_FILE.chmod(0o600)
    except OSError:
        pass
    return token


# ── Handler ───────────────────────────────────────────────────────────────

class _EngineHandler(BaseHTTPRequestHandler):
    server_version = "SEIF-engine/1.0"
    expected_token: str = ""
    started_at: float = 0.0

    # Silence noisy default access log; we keep our own stderr line per request
    def log_message(self, fmt: str, *args: Any) -> None:
        sys.stderr.write(f"[seif-engine] {self.address_string()} - "
                         f"{fmt % args}\n")

    def _json(self, status: int, payload: dict) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read_body(self) -> dict:
        length = int(self.headers.get("Content-Length") or 0)
        if length <= 0:
            return {}
        raw = self.rfile.read(length)
        try:
            return json.loads(raw.decode("utf-8"))
        except Exception:
            return {}

    def _authorized(self) -> bool:
        auth = self.headers.get("Authorization", "")
        if not auth.startswith("Bearer "):
            return False
        return secrets.compare_digest(auth[7:].strip(), self.expected_token)

    # ── Routes ────────────────────────────────────────────────────────────

    def do_GET(self):  # noqa: N802
        if self.path == "/health":
            self._json(200, {
                "ok": True,
                "uptime_s": round(time.time() - self.started_at, 2),
                "version": "SEIF-engine/1.0",
            })
            return
        self._json(404, {"error": "not found", "path": self.path})

    def do_POST(self):  # noqa: N802
        if not self._authorized():
            self._json(401, {"error": "unauthorized — Authorization: Bearer <value> required"})
            return

        if self.path == "/classify":
            self._handle_classify()
            return
        if self.path == "/confirm-action":
            self._handle_confirm()
            return
        if self.path == "/quality-gate":
            self._handle_quality_gate()
            return

        self._json(404, {"error": "not found", "path": self.path})

    # ── Handlers ──────────────────────────────────────────────────────────

    def _handle_classify(self) -> None:
        body = self._read_body()
        text = body.get("text", "")
        if not isinstance(text, str):
            self._json(400, {"error": "text must be a string"})
            return
        try:
            from seif.context.file_extractor import _auto_classify
            level = _auto_classify(text)
        except Exception as e:
            self._json(503, {"error": f"classifier unavailable: {e}"})
            return
        exit_code = {"PUBLIC": 0, "INTERNAL": 1, "CONFIDENTIAL": 2}.get(level, 1)
        self._json(200, {
            "classification": level,
            "exit_code": exit_code,
            "length": len(text),
        })

    def _handle_confirm(self) -> None:
        body = self._read_body()
        action = body.get("action", "")
        reason = body.get("reason", "") or ""
        caller = body.get("caller", "") or ""
        if not action:
            self._json(400, {"error": "action is required"})
            return
        # HTTP callers are inherently non-interactive — emit AWAITING.
        from seif.cli.confirm_action import _log_confirmation, _now_utc
        _log_confirmation(action=action, reason=reason, decision="AWAITING",
                          caller=caller or "http-engine",
                          cwd=Path.cwd(), home=Path.home())
        self._json(200, {
            "decision": "AWAITING",
            "exit_code": 2,
            "action": action,
            "reason": reason,
            "caller": caller,
            "timestamp": _now_utc(),
            "message": (
                "AWAITING_HUMAN_CONFIRMATION — surface this to the human in "
                "your reply and wait for explicit go/no-go before retrying."
            ),
        })

    def _handle_quality_gate(self) -> None:
        body = self._read_body()
        text = body.get("text", "")
        if not text:
            self._json(400, {"error": "text is required"})
            return
        # Quality gate proper lives in seif-engine. If unavailable, return 503
        # with a fallback to the simpler stance detector (also private).
        try:
            from seif.cli.cli import cmd_quality_gate  # noqa: F401
        except ImportError:
            self._json(503, {
                "error": "quality-gate requires seif-engine",
                "hint": "pip install seif-cli[full] or use --classify for a basic check",
            })
            return
        # cmd_quality_gate prints to stdout; we don't easily capture without
        # invasive changes. For now, expose only the bool pass/fail signal
        # via a thin import of the underlying scoring.
        try:
            from seif.analysis.stance_detector import detect_stance
            stance = detect_stance(text)
            self._json(200, {
                "stance": getattr(stance, "stance", "UNKNOWN"),
                "grounded_ratio": getattr(stance, "grounded_ratio", None),
                "note": "stance-only response. Full quality-gate (with grade) "
                        "requires seif-engine over /quality-gate-full (TODO).",
            })
        except Exception as e:
            self._json(503, {"error": f"stance detector unavailable: {e}"})


# ── Server runner ─────────────────────────────────────────────────────────

def run_server(*, host: str = "127.0.0.1", port: int = 7332,
               token: str | None = None) -> int:
    """Start the engine HTTP server. Blocks until interrupted.

    Returns 0 on clean shutdown."""
    token = token or _ensure_token()
    _EngineHandler.expected_token = token
    _EngineHandler.started_at = time.time()

    if host == "0.0.0.0":
        sys.stderr.write(
            "[seif-engine] WARNING: binding to 0.0.0.0 — engine endpoints "
            "exposed on all interfaces. Network callers must present the "
            f"token at {_TOKEN_FILE}. Per A4 this is a security boundary "
            "change you authorized; double-check firewall.\n"
        )

    httpd = ThreadingHTTPServer((host, port), _EngineHandler)
    started = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    print(f"[seif-engine] {started} listening on http://{host}:{port}")
    print(f"  token file: {_TOKEN_FILE} (chmod 0600)")
    print(f"  endpoints: GET /health, POST /classify, POST /confirm-action, "
          f"POST /quality-gate")
    print(f"  callers: pass header 'Authorization: Bearer <token>'")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n[seif-engine] shutting down.")
    finally:
        httpd.server_close()
    return 0
