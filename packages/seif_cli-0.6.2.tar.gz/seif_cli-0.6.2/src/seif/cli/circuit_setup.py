"""seif circuit setup — install axiom A20 inbox monitoring on this host.

Detects the AI runtime (Claude Code, opencode, ...) and installs the
hook + scripts so the runtime drains the circuit inbox automatically,
without human relay.

Idempotent. Use --check for dry-run.

Usage::

    python -m seif.cli.circuit_setup           # install
    python -m seif.cli.circuit_setup --check   # dry-run
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import sys
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

# ── Source-of-truth paths (canonical bridge) ───────────────────────────────
BRIDGE_DIR = Path("/Volumes/DockerData/seif-projects/seif-resonance-bridge")
BRIDGE_SCRIPTS = BRIDGE_DIR / "scripts"

# ── Runtime detection ──────────────────────────────────────────────────────
HOME = Path.home()
CLAUDE_SETTINGS = HOME / ".claude" / "settings.json"
CLAUDE_HOOK_DIR = HOME / ".local" / "share" / "seif" / "claude-code" / "scripts"

# These are *defaults* — the CLI honours --seif-home for testing on a
# simulated 3rd machine. Resolved lazily inside _bind_seif_home() so that
# we never read os.environ at import time.
SEIF_BIN = HOME / ".seif" / "bin"
SEIF_CIRCUIT_DIR = HOME / ".seif" / "circuit"
SEIF_INBOX_DIR = SEIF_CIRCUIT_DIR / "inbox"


def _bind_seif_home(seif_home: Path | None) -> None:
    """Override module-level SEIF paths to point at a non-default home.

    Used by --seif-home to validate bootstrap against a fake machine
    (e.g. SEIF_HOME=/tmp/test-machine-3) without touching real state.
    """
    global SEIF_BIN, SEIF_CIRCUIT_DIR, SEIF_INBOX_DIR
    if seif_home is None:
        return
    seif_home = Path(seif_home).expanduser()
    SEIF_BIN = seif_home / "bin"
    SEIF_CIRCUIT_DIR = seif_home / "circuit"
    SEIF_INBOX_DIR = SEIF_CIRCUIT_DIR / "inbox"

INBOX_HOOK_NAME = "circuit-inbox-hook.sh"
INBOX_HOOK_PATH = CLAUDE_HOOK_DIR / INBOX_HOOK_NAME

# Hook contract (axiom A20): same on every machine.
INBOX_HOOK_BLOCK = {
    "matcher": "",
    "hooks": [
        {
            "type": "command",
            "command": str(INBOX_HOOK_PATH),
            "timeout": 500,
        }
    ],
}
HOOK_EVENTS = ("PreToolUse", "UserPromptSubmit", "Stop", "Notification", "SubagentStop")


# ── Plan / Action model ────────────────────────────────────────────────────

@dataclass
class Action:
    """One step in the install plan. Reversible-friendly."""

    summary: str
    apply: Callable[[], None]
    skip_if: Callable[[], bool] = field(default=lambda: False)

    def status(self) -> str:
        return "skip" if self.skip_if() else "do"


@dataclass
class Plan:
    actions: list[Action] = field(default_factory=list)

    def add(self, summary: str, apply_fn: Callable[[], None],
            skip_if: Callable[[], bool] = lambda: False) -> None:
        self.actions.append(Action(summary, apply_fn, skip_if))

    def render(self) -> str:
        lines = []
        for a in self.actions:
            mark = "·" if a.skip_if() else "✚"
            lines.append(f"  {mark} [{a.status()}] {a.summary}")
        return "\n".join(lines)

    def execute(self) -> int:
        n = 0
        for a in self.actions:
            if a.skip_if():
                continue
            a.apply()
            n += 1
        return n


# ── Plan builders ──────────────────────────────────────────────────────────

def _ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def _write_hook_script() -> None:
    INBOX_HOOK_PATH.write_text(
        "#!/bin/bash\n"
        "# SEIF Circuit Inbox Hook (axiom A20).\n"
        "# Installed by `seif --circuit-setup`. Runs on PreToolUse,\n"
        "# UserPromptSubmit, and Stop. Budget: <50ms when no new messages.\n"
        "MONITOR=\"$HOME/.local/share/seif/claude-code/scripts/circuit-monitor.py\"\n"
        "python3 \"$MONITOR\" --check-inbox 2>/dev/null\n"
        "PENDING=\"$HOME/.seif/circuit/pending-messages.json\"\n"
        "[ ! -f \"$PENDING\" ] && exit 0\n"
        "python3 \"$MONITOR\" --drain 2>/dev/null\n"
    )
    os.chmod(INBOX_HOOK_PATH, 0o755)


def _hook_script_current() -> bool:
    """True if the installed hook matches the canonical content (idempotent)."""
    if not INBOX_HOOK_PATH.exists():
        return False
    try:
        text = INBOX_HOOK_PATH.read_text()
    except OSError:
        return False
    return "--check-inbox" in text and "--drain" in text


def _read_settings() -> dict:
    if not CLAUDE_SETTINGS.exists():
        return {}
    try:
        return json.loads(CLAUDE_SETTINGS.read_text())
    except (OSError, json.JSONDecodeError):
        return {}


def _settings_hook_present(settings: dict, event: str) -> bool:
    groups = settings.get("hooks", {}).get(event, [])
    for grp in groups:
        if grp.get("matcher") != "":
            continue
        for hk in grp.get("hooks", []):
            if hk.get("command") == str(INBOX_HOOK_PATH):
                return True
    return False


def _install_settings_hook(event: str) -> None:
    settings = _read_settings()
    settings.setdefault("hooks", {}).setdefault(event, []).insert(0, INBOX_HOOK_BLOCK)
    CLAUDE_SETTINGS.parent.mkdir(parents=True, exist_ok=True)
    CLAUDE_SETTINGS.write_text(json.dumps(settings, indent=2) + "\n")


def _initialize_watermark() -> None:
    files = sorted(
        f.name for f in SEIF_INBOX_DIR.iterdir()
        if f.name.startswith("bus-handoff-") and f.name.endswith(".json")
    ) if SEIF_INBOX_DIR.exists() else []
    wm_file = SEIF_CIRCUIT_DIR / "inbox-watermark.json"
    payload = {
        "seen_files": files,
        "last_checked": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
    }
    SEIF_CIRCUIT_DIR.mkdir(parents=True, exist_ok=True)
    wm_file.write_text(json.dumps(payload, indent=2))


def _watermark_initialized() -> bool:
    return (SEIF_CIRCUIT_DIR / "inbox-watermark.json").exists()


def _copy_helper_script(name: str) -> None:
    src = BRIDGE_SCRIPTS / name
    dst = SEIF_BIN / name
    SEIF_BIN.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    os.chmod(dst, 0o755)


def _helper_script_present(name: str) -> bool:
    return (SEIF_BIN / name).exists()


def detect_runtime() -> str:
    """Return runtime label or 'unknown'."""
    if CLAUDE_SETTINGS.exists() or CLAUDE_HOOK_DIR.exists():
        return "claude-code"
    return "unknown"


def build_plan_claude_code() -> Plan:
    plan = Plan()

    plan.add(
        f"create {CLAUDE_HOOK_DIR}",
        lambda: _ensure_dir(CLAUDE_HOOK_DIR),
        skip_if=lambda: CLAUDE_HOOK_DIR.exists(),
    )

    plan.add(
        f"write canonical {INBOX_HOOK_NAME}",
        _write_hook_script,
        skip_if=_hook_script_current,
    )

    for event in HOOK_EVENTS:
        plan.add(
            f"register {event} hook in ~/.claude/settings.json",
            (lambda e=event: _install_settings_hook(e)),
            skip_if=(lambda e=event: _settings_hook_present(_read_settings(), e)),
        )

    plan.add(
        "initialize inbox watermark (mark existing files as seen)",
        _initialize_watermark,
        skip_if=_watermark_initialized,
    )

    for helper in ("seif-lock-cleaner.py", "seif-health.py"):
        plan.add(
            f"copy {helper} → ~/.seif/bin/",
            (lambda n=helper: _copy_helper_script(n)),
            skip_if=(lambda n=helper: _helper_script_present(n)),
        )

    return plan


# ── Public entry ───────────────────────────────────────────────────────────

def setup(check: bool = False, seif_home: Path | None = None) -> int:
    """Install axiom A20 plumbing on this host. Returns number of changes made.

    When check=True, prints the plan and returns 0 without applying.
    When seif_home is set, target a non-default ~/.seif (e.g. /tmp/test-mini-3
    for validating bootstrap against a simulated 3rd machine).
    """
    _bind_seif_home(seif_home)
    runtime = detect_runtime()
    if runtime != "claude-code":
        print(f"[circuit-setup] runtime '{runtime}' — only claude-code is "
              f"supported in this build. No-op.")
        return 0

    plan = build_plan_claude_code()
    print(f"[circuit-setup] runtime: {runtime}")
    print("[circuit-setup] plan:")
    print(plan.render())

    if check:
        print("[circuit-setup] --check mode — no changes applied.")
        return 0

    n = plan.execute()
    if n == 0:
        print("[circuit-setup] already in sync — nothing to do.")
    else:
        print(f"[circuit-setup] applied {n} change(s). Restart Claude Code "
              f"session to load the new hooks.")
    return n


def _cli() -> int:
    parser = argparse.ArgumentParser(
        prog="seif --circuit-setup",
        description="Install axiom A20 (circuit inbox monitoring) on this host.",
    )
    parser.add_argument("--check", action="store_true",
                        help="Dry-run: print the plan without applying.")
    parser.add_argument("--seif-home", type=Path, default=None,
                        help="Target a non-default ~/.seif tree "
                             "(e.g. /tmp/test-machine-3 for 3rd-machine validation).")
    args = parser.parse_args()
    return setup(check=args.check, seif_home=args.seif_home)


if __name__ == "__main__":
    raise SystemExit(_cli())
