"""
seif setup wrapper-shims — install shell-level command interception for A4
enforcement on hookless AI clients.

Phase 0 v2 parity test (parity-test-copilot-002.seif) found that AIs absorb
the rendered protocol but bypass `seif --confirm-action` even when explicitly
instructed to call it. The wrapper shims solve this structurally:

  ~/.seif/bin/{git,gh,npm,...}  → symlinks to ~/.seif/wrappers/shim.sh
  ~/.bashrc / ~/.zshrc          → idempotent `export PATH=$HOME/.seif/bin:$PATH`

PATH precedence makes `git push` resolve to our shim BEFORE /usr/bin/git.
The AI cannot bypass without explicitly choosing a non-shim binary path.

Usage::

    seif setup wrapper-shims          # install
    seif setup wrapper-shims --check   # dry-run plan
    seif setup wrapper-shims --uninstall

State: ~/.seif/host/wrapper-shims.json records install timestamp,
shadowed binaries, and shell-rc patches for clean uninstall.
"""
from __future__ import annotations

import json
import os
import shutil
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path


SHIM_GUARD_BEGIN = "# ── BEGIN SEIF wrapper-shims (managed) ──"
SHIM_GUARD_END = "# ── END SEIF wrapper-shims (managed) ──"
SHIM_PATH_LINE = 'export PATH="$HOME/.seif/bin:$PATH"'

SHELL_RC_FILES = {
    "bash": ["~/.bashrc", "~/.bash_profile"],
    "zsh": ["~/.zshrc"],
    "fish": ["~/.config/fish/config.fish"],
}

# Default binaries to shim. The user can opt-out per-binary via
# `seif setup wrapper-shims --skip <bin>` (not yet implemented; defer).
DEFAULT_BINARIES = ("git", "gh", "npm", "pip", "docker", "kubectl")


@dataclass
class ShimAction:
    kind: str            # "create_dir" / "copy_template" / "symlink" / "patch_rc" / "log_state"
    target: Path
    detail: str = ""


@dataclass
class InstallPlan:
    actions: list[ShimAction] = field(default_factory=list)
    shell: str = ""
    rc_files: list[Path] = field(default_factory=list)
    binaries: list[str] = field(default_factory=list)


def _detect_shell() -> str:
    shell_env = os.environ.get("SHELL", "")
    name = Path(shell_env).name if shell_env else ""
    if name in SHELL_RC_FILES:
        return name
    # Fallback: try zsh (macOS default), then bash
    for candidate in ("zsh", "bash"):
        if shutil.which(candidate):
            return candidate
    return "bash"


def _existing_rc_files(shell: str, home: Path) -> list[Path]:
    out: list[Path] = []
    for entry in SHELL_RC_FILES.get(shell, []):
        p = Path(entry.replace("~", str(home)))
        if p.is_file():
            out.append(p)
    if not out and shell in SHELL_RC_FILES:
        # No rc file exists — pick the first canonical location
        out.append(Path(SHELL_RC_FILES[shell][0].replace("~", str(home))))
    return out


def _build_plan(*, home: Path, shell: str,
                binaries: tuple[str, ...] = DEFAULT_BINARIES) -> InstallPlan:
    plan = InstallPlan(shell=shell, binaries=list(binaries))
    plan.rc_files = _existing_rc_files(shell, home)

    seif_dir = home / ".seif"
    bin_dir = seif_dir / "bin"
    wrappers_dir = seif_dir / "wrappers"
    state_file = seif_dir / "host" / "wrapper-shims.json"

    plan.actions.append(ShimAction("create_dir", bin_dir))
    plan.actions.append(ShimAction("create_dir", wrappers_dir))
    plan.actions.append(ShimAction("create_dir", state_file.parent))

    plan.actions.append(ShimAction(
        "copy_template", wrappers_dir / "shim.sh",
        detail="from src/seif/wrappers/shim.sh"))
    plan.actions.append(ShimAction(
        "copy_template", wrappers_dir / "destructive_actions.json",
        detail="from src/seif/wrappers/destructive_actions.json"))

    for bin_name in binaries:
        plan.actions.append(ShimAction(
            "symlink", bin_dir / bin_name,
            detail=f"→ {wrappers_dir / 'shim.sh'}"))

    for rc in plan.rc_files:
        plan.actions.append(ShimAction(
            "patch_rc", rc,
            detail=f"prepend ~/.seif/bin to PATH (idempotent guard markers)"))

    plan.actions.append(ShimAction(
        "log_state", state_file,
        detail="record installed binaries + rc files for clean uninstall"))
    return plan


def _print_plan(plan: InstallPlan, *, header: str = "PLAN") -> None:
    print(f"[seif setup wrapper-shims] {header}")
    print(f"  shell: {plan.shell}")
    print(f"  rc files: {[str(p) for p in plan.rc_files]}")
    print(f"  binaries to shim: {plan.binaries}")
    print()
    for a in plan.actions:
        print(f"  · [{a.kind}] {a.target}" + (f"  ({a.detail})" if a.detail else ""))


def _wrappers_src_dir() -> Path:
    """Locate src/seif/wrappers/ regardless of pip-install vs editable layout."""
    here = Path(__file__).resolve().parent
    pkg_wrappers = here.parent / "wrappers"
    if pkg_wrappers.is_dir():
        return pkg_wrappers
    # Fallback: dev repo
    repo_wrappers = here.parents[2] / "src" / "seif" / "wrappers"
    if repo_wrappers.is_dir():
        return repo_wrappers
    raise FileNotFoundError("could not locate src/seif/wrappers/ source")


def _patch_rc_idempotent(rc_path: Path) -> str:
    """Add the SEIF PATH block to rc_path between guard markers. Idempotent:
    if guards already present, leave file alone. Returns 'added' / 'present' / 'created'."""
    block = (
        f"{SHIM_GUARD_BEGIN}\n"
        f"{SHIM_PATH_LINE}\n"
        f"{SHIM_GUARD_END}\n"
    )
    if not rc_path.is_file():
        rc_path.parent.mkdir(parents=True, exist_ok=True)
        rc_path.write_text(block)
        return "created"

    existing = rc_path.read_text()
    if SHIM_GUARD_BEGIN in existing:
        return "present"

    sep = "" if existing.endswith("\n") else "\n"
    rc_path.write_text(existing + sep + "\n" + block)
    return "added"


def _unpatch_rc(rc_path: Path) -> str:
    """Strip the SEIF guard block from rc_path. Returns 'removed' / 'absent' / 'missing'."""
    if not rc_path.is_file():
        return "missing"
    text = rc_path.read_text()
    if SHIM_GUARD_BEGIN not in text:
        return "absent"

    lines = text.splitlines(keepends=True)
    out = []
    in_block = False
    for line in lines:
        if SHIM_GUARD_BEGIN in line:
            in_block = True
            continue
        if SHIM_GUARD_END in line:
            in_block = False
            continue
        if not in_block:
            out.append(line)
    # Tidy a trailing run of blank lines we may have left behind
    while len(out) >= 2 and out[-1] == "\n" and out[-2] == "\n":
        out.pop()
    rc_path.write_text("".join(out))
    return "removed"


def install(*, home: Path | None = None,
            binaries: tuple[str, ...] = DEFAULT_BINARIES,
            shell: str | None = None) -> dict:
    """Execute the install plan. Returns a state dict (also written to disk)."""
    home = home or Path.home()
    shell = shell or _detect_shell()
    plan = _build_plan(home=home, shell=shell, binaries=binaries)

    src_dir = _wrappers_src_dir()
    seif_dir = home / ".seif"
    bin_dir = seif_dir / "bin"
    wrappers_dir = seif_dir / "wrappers"
    state_file = seif_dir / "host" / "wrapper-shims.json"

    bin_dir.mkdir(parents=True, exist_ok=True)
    wrappers_dir.mkdir(parents=True, exist_ok=True)
    state_file.parent.mkdir(parents=True, exist_ok=True)

    # Copy templates
    shim_dst = wrappers_dir / "shim.sh"
    shutil.copy2(src_dir / "shim.sh", shim_dst)
    shim_dst.chmod(0o755)
    shutil.copy2(src_dir / "destructive_actions.json",
                 wrappers_dir / "destructive_actions.json")

    # Symlink each binary
    created_links: list[str] = []
    for bin_name in binaries:
        link = bin_dir / bin_name
        if link.is_symlink() or link.exists():
            link.unlink()
        link.symlink_to(shim_dst)
        created_links.append(str(link))

    # Patch rc files
    rc_results: dict[str, str] = {}
    for rc in plan.rc_files:
        rc_results[str(rc)] = _patch_rc_idempotent(rc)

    # Persist state for uninstall
    state = {
        "schema": "SEIF-WRAPPER-SHIMS-v1",
        "installed_at": datetime.now(timezone.utc).isoformat(),
        "shell": shell,
        "rc_files": [str(p) for p in plan.rc_files],
        "binaries": list(binaries),
        "links": created_links,
        "wrappers_dir": str(wrappers_dir),
        "rc_patch_results": rc_results,
    }
    state_file.write_text(json.dumps(state, indent=2))
    return state


def uninstall(*, home: Path | None = None) -> dict:
    """Reverse a previous install. Best-effort: removes symlinks + rc patches
    + state file; leaves ~/.seif/wrappers/ in place (templates can be reused
    by any future install)."""
    home = home or Path.home()
    seif_dir = home / ".seif"
    bin_dir = seif_dir / "bin"
    state_file = seif_dir / "host" / "wrapper-shims.json"

    state = {}
    if state_file.is_file():
        try:
            state = json.loads(state_file.read_text())
        except Exception:
            state = {}

    binaries = state.get("binaries", list(DEFAULT_BINARIES))
    rc_files = state.get("rc_files", [])

    removed_links: list[str] = []
    for bin_name in binaries:
        link = bin_dir / bin_name
        if link.is_symlink() or link.exists():
            link.unlink()
            removed_links.append(str(link))

    rc_results: dict[str, str] = {}
    for rc in rc_files:
        rc_results[rc] = _unpatch_rc(Path(rc))
    # If state was missing, also try the canonical rc files
    if not rc_files:
        shell = _detect_shell()
        for rc in _existing_rc_files(shell, home):
            rc_results[str(rc)] = _unpatch_rc(rc)

    if state_file.is_file():
        state_file.unlink()

    return {
        "removed_links": removed_links,
        "rc_results": rc_results,
        "state_cleared": str(state_file) if state else "(no state file)",
    }


def status(*, home: Path | None = None) -> dict:
    home = home or Path.home()
    state_file = home / ".seif" / "host" / "wrapper-shims.json"
    if not state_file.is_file():
        return {"installed": False}
    try:
        state = json.loads(state_file.read_text())
    except Exception:
        return {"installed": False, "error": "state file unreadable"}

    bin_dir = home / ".seif" / "bin"
    live_links = []
    for b in state.get("binaries", []):
        link = bin_dir / b
        if link.is_symlink() or link.is_file():
            live_links.append(b)
    state["live_links"] = live_links
    state["installed"] = True
    return state


def run(args) -> int:
    """argparse dispatch entry point for `seif setup wrapper-shims`."""
    home = Path.home()

    if getattr(args, "uninstall", False):
        result = uninstall(home=home)
        print("[seif setup wrapper-shims] UNINSTALLED")
        for link in result["removed_links"]:
            print(f"  · removed: {link}")
        for rc, rc_status in result["rc_results"].items():
            print(f"  · rc {rc}: {rc_status}")
        print(f"  · state: {result['state_cleared']}")
        return 0

    if getattr(args, "status", False):
        s = status(home=home)
        if not s.get("installed"):
            print("[seif setup wrapper-shims] NOT installed")
            return 0
        print("[seif setup wrapper-shims] INSTALLED")
        print(f"  installed_at: {s.get('installed_at')}")
        print(f"  shell: {s.get('shell')}")
        print(f"  rc files: {s.get('rc_files')}")
        print(f"  binaries (configured): {s.get('binaries')}")
        print(f"  live links: {s.get('live_links')}")
        print(f"  rc patch results: {s.get('rc_patch_results')}")
        return 0

    plan = _build_plan(home=home, shell=_detect_shell())
    if getattr(args, "dry_run", False) or getattr(args, "check", False):
        _print_plan(plan, header="DRY-RUN — no changes applied")
        print("\n  Run without --check / --dry-run to apply.")
        return 0

    _print_plan(plan, header="EXECUTING")
    state = install(home=home)
    print()
    print("[seif setup wrapper-shims] DONE")
    print(f"  installed at: {state['installed_at']}")
    print(f"  links: {len(state['links'])} created in ~/.seif/bin/")
    print(f"  rc files patched: {state['rc_patch_results']}")
    print()
    print("  ⚠  Open a NEW shell (or `source ~/.zshrc` / `source ~/.bashrc`)")
    print("     to pick up the new PATH and activate the shims.")
    return 0
