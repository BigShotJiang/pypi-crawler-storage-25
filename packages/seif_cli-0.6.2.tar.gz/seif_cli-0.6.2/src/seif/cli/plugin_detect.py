"""
seif --plugin-detect — auto-bind detection + dry-run dispatch.

Walks plugins/adapters/<name>/manifest.json, resolves each adapter's
client_detect predicates against this host, and reports which adapters
would bind. With --apply, executes render_seed for hookless adapters
and writes output files honoring merge_strategy.

Hook-capable install (settings.json merge for Claude Code, etc.) remains
the responsibility of `seif setup <client>` — that path already exists and
this command does not duplicate it. Auto-bind here means: render the
static SEED file for hookless clients (Copilot/Cursor/AGENTS.md/...).

Usage::

    seif --plugin-detect           # dry-run: list adapters that match
    seif --plugin-detect --apply   # actually write rendered files
"""
from __future__ import annotations

import importlib.util
import json
import os
import re
import shutil
from dataclasses import dataclass, field
from pathlib import Path

from seif.cli.plugin_sync import _find_seif_repo


@dataclass
class DetectResult:
    name: str
    path: Path
    matches: bool
    matched_predicate: str = ""
    runtime_capable: bool = False
    render_targets: list[dict] = field(default_factory=list)
    written_paths: list[Path] = field(default_factory=list)
    skipped_reason: str = ""


def _expand(path: str, project: Path, home: Path) -> Path:
    """Expand $PROJECT, $HOME, ~ in adapter manifest paths."""
    s = path.replace("$PROJECT", str(project)).replace("$HOME", str(home))
    return Path(os.path.expanduser(s))


def _resolve_predicate(pred: dict, project: Path, home: Path) -> tuple[bool, str]:
    """Resolve a client_detect predicate. Returns (matched, description).
    Supports command_exists, path_exists, env_set, any_of, all_of."""
    if "command_exists" in pred:
        cmd = pred["command_exists"]
        ok = shutil.which(cmd) is not None
        return ok, f"command_exists({cmd})"
    if "path_exists" in pred:
        target = _expand(pred["path_exists"], project, home)
        ok = target.exists()
        return ok, f"path_exists({target})"
    if "env_set" in pred:
        var = pred["env_set"]
        ok = bool(os.environ.get(var))
        return ok, f"env_set({var})"
    if "any_of" in pred:
        for sub in pred["any_of"]:
            ok, desc = _resolve_predicate(sub, project, home)
            if ok:
                return True, f"any_of[{desc}]"
        return False, "any_of[no match]"
    if "all_of" in pred:
        descs = []
        for sub in pred["all_of"]:
            ok, desc = _resolve_predicate(sub, project, home)
            if not ok:
                return False, f"all_of[fail at {desc}]"
            descs.append(desc)
        return True, f"all_of[{', '.join(descs)}]"
    return False, "unknown predicate"


def _import_render(adapter_dir: Path):
    """Import the adapter's render.py (or None if not present)."""
    render_py = adapter_dir / "render" / "render.py"
    if not render_py.is_file():
        return None
    spec = importlib.util.spec_from_file_location(
        f"_seif_adapter_{adapter_dir.name}_detect_render", render_py
    )
    if spec is None or spec.loader is None:
        return None
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


_BEGIN_MARKER = "<!-- SEIF:BEGIN"
_END_MARKER = "<!-- SEIF:END"


def _merge_between_markers(existing: str, new_block: str) -> str:
    """Replace content between SEIF markers, preserving everything else.
    If no markers are present, append the block."""
    begin_re = re.compile(re.escape(_BEGIN_MARKER) + r".*?-->", re.DOTALL)
    end_re = re.compile(re.escape(_END_MARKER) + r".*?-->", re.DOTALL)

    begin_match = begin_re.search(existing)
    end_match = end_re.search(existing)
    if begin_match and end_match and end_match.start() > begin_match.start():
        prefix = existing[:begin_match.start()]
        suffix = existing[end_match.end():]
        return prefix.rstrip() + ("\n\n" if prefix.strip() else "") + new_block.strip() + "\n" + suffix.lstrip()

    # No markers — append
    sep = "\n\n" if existing.strip() else ""
    return existing.rstrip() + sep + new_block.strip() + "\n"


def _write_target(target_path: Path, content: str, merge_strategy: str) -> None:
    target_path.parent.mkdir(parents=True, exist_ok=True)
    if merge_strategy == "replace" or not target_path.exists():
        target_path.write_text(content + ("\n" if not content.endswith("\n") else ""))
        return
    existing = target_path.read_text()
    if merge_strategy == "append":
        if content.strip() in existing:
            return  # idempotent
        target_path.write_text(existing.rstrip() + "\n\n" + content + "\n")
        return
    if merge_strategy == "between_markers":
        target_path.write_text(_merge_between_markers(existing, content))
        return
    # Unknown strategy — fall back to replace
    target_path.write_text(content)


def detect_adapters(project: Path, home: Path,
                    apply: bool = False) -> list[DetectResult]:
    repo = _find_seif_repo()
    if repo is None:
        return []

    adapters_dir = repo / "plugins" / "adapters"
    if not adapters_dir.is_dir():
        adapters_dir = repo / "src" / "seif" / "plugins" / "adapters"

    seif_dir = project / ".seif" if (project / ".seif").is_dir() else home / ".seif"
    if not seif_dir.is_dir():
        seif_dir = Path()

    results: list[DetectResult] = []
    for entry in sorted(adapters_dir.iterdir()):
        if not entry.is_dir():
            continue
        manifest_path = entry / "manifest.json"
        if not manifest_path.is_file():
            continue
        try:
            manifest = json.loads(manifest_path.read_text())
        except Exception:
            continue

        detect = manifest.get("client_detect")
        matched = False
        desc = "no client_detect"
        if isinstance(detect, dict):
            matched, desc = _resolve_predicate(detect, project, home)

        caps = manifest.get("capabilities", {})
        # "runtime_capable" = ships hooks or skills (requires `seif setup`).
        # filesystem_access alone describes the client, not the adapter.
        if isinstance(caps, dict):
            runtime_capable = bool(caps.get("runtime_hooks")
                                    or caps.get("skills_commands"))
        else:
            runtime_capable = False
        targets = manifest.get("render_targets", []) or []

        result = DetectResult(
            name=manifest.get("name", entry.name),
            path=entry,
            matches=matched,
            matched_predicate=desc,
            runtime_capable=runtime_capable,
            render_targets=targets,
        )

        if matched and apply and not runtime_capable:
            # Hookless adapter that matched — render and write
            render_mod = _import_render(entry)
            if render_mod is None:
                result.skipped_reason = "no render.py present"
            else:
                for t in targets:
                    target_path = _expand(t["path"], project, home)
                    try:
                        content = render_mod.render_seed(
                            seif_dir=seif_dir,
                            project_dir=project,
                            home=home,
                            content_kind=t["content_kind"],
                            adapter_dir=entry,
                        )
                        _write_target(target_path, content,
                                      t.get("merge_strategy", "replace"))
                        result.written_paths.append(target_path)
                    except Exception as e:
                        result.skipped_reason = f"render failed: {e}"
                        break
        elif matched and runtime_capable:
            result.skipped_reason = (
                "runtime_capable adapter — use `seif setup "
                f"{manifest.get('name', entry.name)}` for hook installation"
            )

        results.append(result)
    return results


def print_detect_report(results: list[DetectResult], apply: bool) -> None:
    print("[seif --plugin-detect" + (" --apply" if apply else "") + "]")
    print()
    if not results:
        print("  no adapters found")
        return

    width = max(len(r.name) for r in results)
    matched = [r for r in results if r.matches]
    not_matched = [r for r in results if not r.matches]

    if matched:
        print(f"  Matched ({len(matched)}):")
        for r in matched:
            kind = "runtime" if r.runtime_capable else "hookless"
            print(f"    ✓ {r.name:<{width}}  [{kind}]  via {r.matched_predicate}")
            if r.runtime_capable:
                print(f"        → use `seif setup {r.name}` to install hooks")
            elif apply and r.written_paths:
                for p in r.written_paths:
                    print(f"        wrote: {p}")
            elif apply and r.skipped_reason:
                print(f"        skipped: {r.skipped_reason}")
            elif not apply and r.render_targets:
                for t in r.render_targets:
                    target = _expand(t["path"], Path.cwd(), Path.home())
                    print(f"        would render: {target} ({t['content_kind']}, "
                          f"{t['merge_strategy']})")
        print()

    if not_matched:
        print(f"  Not matched ({len(not_matched)}):")
        for r in not_matched:
            print(f"    · {r.name:<{width}}  {r.matched_predicate}")
        print()

    if not apply and any(not r.runtime_capable for r in matched):
        print("  Run with --apply to write rendered files for hookless adapters.")


def run_plugin_detect(args) -> int:
    project = Path.cwd()
    home = Path.home()
    apply = bool(getattr(args, "apply", False))
    results = detect_adapters(project, home, apply=apply)
    print_detect_report(results, apply)
    return 0
