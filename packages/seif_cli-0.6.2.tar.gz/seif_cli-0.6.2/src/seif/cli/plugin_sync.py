"""
seif --plugin-sync — adapter conformance + (eventual) deployment.

This minimal implementation provides --check mode only:
walks plugins/adapters/<name>/, validates each manifest against
manifest.schema.json, verifies the render.py module is importable
and exposes render_seed with the contract signature, and prints a
conformance report.

Ed25519 signing of manifests and the actual deployment to
~/.local/share/seif/adapters/ are deferred to a follow-up PR. The
contract (CONTRACT.md) and schema are stable; the deploy/sign layer
slots on top without breaking the data shape.

Usage::

    seif --plugin-sync --check    # validate all adapters in-tree
"""
from __future__ import annotations

import importlib.util
import inspect
import json
import sys
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class AdapterReport:
    name: str
    path: Path
    manifest_ok: bool
    schema_violations: list[str] = field(default_factory=list)
    render_ok: bool = True
    render_violations: list[str] = field(default_factory=list)
    capabilities_summary: str = ""
    degradation_count: int = 0

    @property
    def conformant(self) -> bool:
        return self.manifest_ok and self.render_ok


def _find_seif_repo() -> Path | None:
    """Locate the seif repo root by walking up from this file. Prefer the
    outermost ancestor with plugins/adapters/ so we land at the repo top
    (which has both plugins/ and src/seif/plugins/), not the inner package
    layer (which only has the package mirror)."""
    p = Path(__file__).resolve()
    candidates: list[Path] = []
    for parent in p.parents:
        if (parent / "plugins" / "adapters").is_dir():
            candidates.append(parent)
    if candidates:
        # Return the OUTERMOST (deepest in parents = highest in filesystem)
        return candidates[-1]
    # Fallback: pip-installed package — adapters live alongside cli/
    pkg = Path(__file__).resolve().parent.parent / "plugins" / "adapters"
    if pkg.is_dir():
        return pkg.parent.parent
    return None


def _load_schema(repo: Path) -> dict:
    schema_paths = [
        repo / "plugins" / "adapters" / "manifest.schema.json",
        repo / "src" / "seif" / "plugins" / "adapters" / "manifest.schema.json",
    ]
    for p in schema_paths:
        if p.is_file():
            return json.loads(p.read_text())
    return {}


def _validate_manifest_minimal(manifest: dict, schema: dict) -> list[str]:
    """Lightweight schema validation. Used as a fallback when jsonschema
    is unavailable. Checks required fields + types + capability completeness."""
    violations: list[str] = []

    # Required top-level
    for key in schema.get("required", []):
        if key not in manifest:
            violations.append(f"missing required field: {key}")

    # Capabilities completeness
    cap_schema = schema.get("properties", {}).get("capabilities", {})
    cap_required = cap_schema.get("required", [])
    caps = manifest.get("capabilities", {})
    if isinstance(caps, dict):
        for c in cap_required:
            if c not in caps:
                violations.append(f"capabilities.{c} missing")
            elif not isinstance(caps[c], bool):
                violations.append(f"capabilities.{c} not boolean")

    # render_targets schema sanity
    targets = manifest.get("render_targets", [])
    valid_kinds = {
        "kernel_seed", "axioms_summary", "session_contract_static",
        "full_seed", "degradation_notice",
    }
    valid_strategies = {"replace", "between_markers", "append"}
    valid_formats = {"markdown", "json", "yaml", "mdc", "text"}
    if isinstance(targets, list):
        for i, t in enumerate(targets):
            for k in ("path", "format", "content_kind", "merge_strategy"):
                if k not in t:
                    violations.append(f"render_targets[{i}].{k} missing")
            if t.get("content_kind") not in valid_kinds:
                violations.append(
                    f"render_targets[{i}].content_kind invalid: "
                    f"{t.get('content_kind')!r}"
                )
            if t.get("merge_strategy") not in valid_strategies:
                violations.append(
                    f"render_targets[{i}].merge_strategy invalid: "
                    f"{t.get('merge_strategy')!r}"
                )
            if t.get("format") not in valid_formats:
                violations.append(
                    f"render_targets[{i}].format invalid: "
                    f"{t.get('format')!r}"
                )

    # install_paths is required only when the adapter actually installs to
    # host paths — i.e. when it ships hooks (runtime_hooks) or skills
    # (skills_commands). filesystem_access describes the CLIENT, not the
    # adapter's deployment surface.
    if isinstance(caps, dict):
        installs_to_host = caps.get("runtime_hooks") or caps.get("skills_commands")
        if installs_to_host and "install_paths" not in manifest:
            violations.append(
                "runtime_hooks or skills_commands is true but install_paths absent"
            )
        # If any capability is false, expect render_targets OR a degradation
        # entry covering the gap.
        if not all(caps.values()):
            has_render = bool(manifest.get("render_targets"))
            has_degradations = bool(manifest.get("degradations"))
            if not has_render and not has_degradations:
                violations.append(
                    "capabilities have false entries but neither "
                    "render_targets nor degradations declared"
                )

    return violations


def _validate_render(adapter_dir: Path) -> list[str]:
    """Verify render.py (if present) is importable and exposes render_seed
    with the right signature."""
    render_py = adapter_dir / "render" / "render.py"
    if not render_py.is_file():
        return []  # No render — capability_only adapter (e.g. fully runtime)

    spec = importlib.util.spec_from_file_location(
        f"_seif_adapter_{adapter_dir.name}_render", render_py
    )
    if spec is None or spec.loader is None:
        return [f"could not load spec for {render_py}"]
    module = importlib.util.module_from_spec(spec)
    try:
        spec.loader.exec_module(module)
    except Exception as e:
        return [f"render.py import failed: {e}"]

    if not hasattr(module, "render_seed"):
        return ["render.py missing render_seed function"]

    fn = module.render_seed
    sig = inspect.signature(fn)
    required_params = {"seif_dir", "project_dir", "home", "content_kind"}
    actual = set(sig.parameters.keys())
    missing = required_params - actual
    if missing:
        return [f"render_seed signature missing params: {sorted(missing)}"]
    return []


def check_adapters(repo: Path | None = None) -> tuple[list[AdapterReport], int]:
    """Walk plugins/adapters/ and validate each adapter. Returns
    (reports, exit_code). exit_code is 0 if all conformant, 1 otherwise."""
    if repo is None:
        repo = _find_seif_repo()
    if repo is None:
        print("[plugin-sync] could not locate seif repo (no plugins/adapters/)")
        return [], 1

    schema = _load_schema(repo)
    if not schema:
        print("[plugin-sync] could not load manifest.schema.json")
        return [], 1

    adapters_dir = repo / "plugins" / "adapters"
    if not adapters_dir.is_dir():
        adapters_dir = repo / "src" / "seif" / "plugins" / "adapters"

    reports: list[AdapterReport] = []
    for entry in sorted(adapters_dir.iterdir()):
        if not entry.is_dir():
            continue
        manifest_path = entry / "manifest.json"
        if not manifest_path.is_file():
            continue

        try:
            manifest = json.loads(manifest_path.read_text())
        except Exception as e:
            reports.append(AdapterReport(
                name=entry.name, path=entry, manifest_ok=False,
                schema_violations=[f"manifest.json parse error: {e}"],
            ))
            continue

        violations = _validate_manifest_minimal(manifest, schema)

        # Try jsonschema if available — stricter validation
        try:
            import jsonschema  # type: ignore[import-not-found]
            try:
                jsonschema.validate(manifest, schema)
            except jsonschema.ValidationError as e:
                violations.append(f"jsonschema: {e.message} at "
                                  f"{'.'.join(str(p) for p in e.absolute_path)}")
        except ImportError:
            pass

        render_violations = _validate_render(entry)

        caps = manifest.get("capabilities", {})
        true_count = sum(1 for v in caps.values() if v is True)
        false_count = sum(1 for v in caps.values() if v is False)

        reports.append(AdapterReport(
            name=manifest.get("name", entry.name),
            path=entry,
            manifest_ok=not violations,
            schema_violations=violations,
            render_ok=not render_violations,
            render_violations=render_violations,
            capabilities_summary=f"{true_count} runtime, {false_count} hookless",
            degradation_count=len(manifest.get("degradations", [])),
        ))

    exit_code = 0 if all(r.conformant for r in reports) else 1
    return reports, exit_code


def print_check_report(reports: list[AdapterReport]) -> None:
    print("[seif --plugin-sync --check]")
    print()
    if not reports:
        print("  no adapters found in plugins/adapters/")
        return

    width = max(len(r.name) for r in reports)
    for r in reports:
        marker = "✓" if r.conformant else "✗"
        print(f"  {marker} {r.name:<{width}}  "
              f"[{r.capabilities_summary}, "
              f"{r.degradation_count} degradation{'s' if r.degradation_count != 1 else ''}]")
        for v in r.schema_violations:
            print(f"      manifest: {v}")
        for v in r.render_violations:
            print(f"      render:   {v}")

    print()
    ok = sum(1 for r in reports if r.conformant)
    print(f"  {ok}/{len(reports)} adapters conformant")
    if ok < len(reports):
        print("  see plugins/adapters/CONTRACT.md")


def run_plugin_sync(args) -> int:
    """Entry point for argparse dispatch."""
    if not getattr(args, "check", False):
        # Sync (deploy) mode is deferred — print a notice and exit
        print("[seif --plugin-sync] only --check is implemented in this build.")
        print("    Deploy + Ed25519 signing land in a follow-up release.")
        return 0
    reports, code = check_adapters()
    print_check_report(reports)
    return code
