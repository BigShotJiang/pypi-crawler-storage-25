#!/usr/bin/env python3
"""
RPWP CLI — Resonance Proto-Writing Processor

Unified demo interface:
  PYTHONPATH=src python -m seif.cli "O amor liberta e guia"
  PYTHONPATH=src python -m seif.cli --gate "Tesla 369"
  PYTHONPATH=src python -m seif.cli --glyph "A Semente de Enoque"
  PYTHONPATH=src python -m seif.cli --audio "Love and Harmony"
  PYTHONPATH=src python -m seif.cli --fractal "O amor liberta e guia"
"""

import argparse
import json
import os
from pathlib import Path
from typing import Optional

from seif.core.resonance_gate import evaluate
from seif.core.fingerprint import calculate_fingerprint, verify_fingerprint


def _lazy_import_generators():
    """Lazy import generators — only needed for research/visualization commands."""
    try:
        from seif.analysis.transcompiler import transcompile, describe
        from seif.generators.glyph_renderer import render, render_fractal_qr
        from seif.generators.harmonic_audio import render_audio
        from seif.generators.fractal_qrcode import generate_fractal_qr, describe as describe_fqr
        from seif.generators.circuit_generator import generate_from_spec, render_svg
        from seif.generators.composite_renderer import render_composite
        return transcompile, describe, render, render_fractal_qr, render_audio, generate_fractal_qr, describe_fqr, generate_from_spec, render_svg, render_composite
    except ImportError as e:
        print(f"Generators not available: {e}")
        print("Install with: pip install seif-cli[generators]")
        raise SystemExit(1)


def _lazy_import_encoding():
    """Lazy import resonance encoding."""
    try:
        from seif.core.resonance_encoding import encode_phrase, describe_melody
    except ImportError:
        raise ImportError("seif.core.resonance_encoding not available")
    return encode_phrase, describe_melody


def cmd_fingerprint_verify(filepath: str):
    """Verify fingerprint of a SEIF module or RESONANCE.json."""
    import json
    
    path = Path(filepath)
    if not path.exists():
        print(f"Error: File not found: {filepath}")
        return
    
    with open(filepath, 'r') as f:
        data = json.load(f)
    
    is_valid, calculated_hash = verify_fingerprint(data)
    stored_hash = data.get('fingerprint', {}).get('value', '<missing>')
    
    from seif.cli.resonance_display import ResonanceReport
    report = ResonanceReport("SEIF FINGERPRINT VERIFICATION")
    report.section("Details")
    report.kv("File", filepath)
    report.kv("Stored", stored_hash)
    report.kv("Calculated", calculated_hash)
    report.blank()
    if is_valid:
        report.kv("Status", "VALID (tamper-free)")
    else:
        report.kv("Status", "INVALID (file was modified!)")
        report.blank()
        report.line("WARNING: Content does not match stored fingerprint.")
        report.line("This file may have been tampered with.")
    print(report.render())


def cmd_fingerprint_update(filepath: str, output: str):
    """Recalculate and update fingerprint of a SEIF module."""
    import json
    import sys as _sys

    print("[WARN] --fingerprint-update mutates content. Existing signature "
          "and .ots will be invalidated. Run --integrity-update for an "
          "atomic chain that keeps all three valid.", file=_sys.stderr)

    path = Path(filepath)
    if not path.exists():
        print(f"Error: File not found: {filepath}")
        return
    
    with open(filepath, 'r') as f:
        data = json.load(f)
    
    old_hash = data.get('fingerprint', {}).get('value', '<none>')
    new_hash = calculate_fingerprint(data)
    
    data['fingerprint'] = {
        'algorithm': 'sha256',
        'value': new_hash,
        'scope': 'full_json_excluding_fingerprint',
        'calculated_at': 'auto',
        'note': 'Auto-calculated by seif fingerprint update'
    }
    
    out_path = Path(output) if output else path
    with open(out_path, 'w') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    
    from seif.cli.resonance_display import ResonanceReport
    report = ResonanceReport("SEIF FINGERPRINT UPDATED")
    report.section("Details")
    report.kv("File", path)
    report.kv("Old hash", old_hash)
    report.kv("New hash", new_hash)
    report.kv("Saved to", out_path)
    print(report.render())


def cmd_compress(project_path: str, watch: bool = False,
                 context_repo: str = None, author: str = "code-compressor"):
    """Compress a source code project into .seif for AI consumption."""
    try:
        from seif.context.code_compressor import compress_project, watch_project
    except ImportError:
        print("Installation error: seif.context.code_compressor not found. Try: pip install --force-reinstall seif-cli")
        return

    target = None
    if context_repo:
        project_name = Path(project_path).resolve().name
        target = str(Path(context_repo).resolve() / "projects" / project_name / "code.seif")

    if watch:
        from seif.cli.resonance_display import ResonanceReport
        report = ResonanceReport("SEIF CODE WATCH")
        report.kv("Watching", Path(project_path).resolve())
        report.line("Press Ctrl+C to stop.")
        print(report.render())
        watch_project(project_path)
    else:
        module, path = compress_project(project_path, author=author, target_path=target)
        from seif.cli.resonance_display import ResonanceReport
        report = ResonanceReport("SEIF CODE COMPRESSED")
        report.section("Result")
        report.kv("Project", Path(project_path).resolve().name)
        report.kv("Files", f"{module.original_words} LOC across scanned files")
        report.kv("Compressed", f"{module.compressed_words} words")
        report.kv("Ratio", f"{module.compression_ratio}:1")
        report.kv("Coherence", f"{module.resonance.get('coherence', 0):.3f}")
        report.kv("Gate", module.resonance.get('gate', '?'))
        report.kv("Classification", module.classification if module.classification else "INTERNAL")
        report.kv("Hash", module.integrity_hash)
        report.kv("Saved", path)
        print(report.render())


def cmd_autonomous(action: str, context_repo: str = None):
    try:
        from seif.context.autonomous import (
            load_config, save_config, is_autonomous, load_mapper,
            find_context_repo, CATEGORIES, DEFAULT_CONFIG,
        )
    except ImportError:
        _upgrade_message("--autonomous", "AI manages its own knowledge persistence across sessions.")
        return

    # Auto-discover context repo if not specified
    if not context_repo:
        context_repo = find_context_repo() or ".seif"

    config = load_config(context_repo)

    if action == "enable":
        config["autonomous_context"] = True
        save_config(context_repo, config)
        print("Autonomous context: ENABLED")
        print(f"  Context repo:  {context_repo}")
        print(f"  Categories:    {', '.join(CATEGORIES.keys())}")
        print(f"  Quality min:   {config.get('quality_threshold', 'C')}")
        print(f"  Max modules:   {config.get('max_modules_per_project', 10)}/project")
        print()
        print("The AI will now manage its own knowledge persistence.")
        print("Use --autonomous disable to turn it off.")

    elif action == "disable":
        config["autonomous_context"] = False
        save_config(context_repo, config)
        print("Autonomous context: DISABLED")
        print("Existing .seif modules are preserved but no new ones will be created.")

    else:  # status
        enabled = is_autonomous(config)
        read_only = config.get("read_only", False)
        print(f"Autonomous context: {'ENABLED' if enabled else 'DISABLED'}")
        if read_only:
            print(f"  Mode:          READ-ONLY")
        print(f"  Context repo:  {context_repo}")
        print(f"  Decay:         {config.get('relevance_decay', 0.95)}")
        if config.get("require_confidential_approval", False):
            print(f"  CONFIDENTIAL:  requires approval")

        mapper = load_mapper(context_repo)
        print(f"  Sessions:      {mapper.session_count}")
        print(f"  Modules:       {len(mapper.modules)}")
        if mapper.last_session:
            print(f"  Last session:  {mapper.last_session[:19]}")
        if mapper.pending_observations:
            print(f"  Pending:       {len(mapper.pending_observations)} observations")

        ai_modules = [m for m in mapper.modules if m.origin == "ai-observed"]
        if ai_modules:
            print(f"\n  AI-created modules:")
            for m in ai_modules:
                project = m.project or "cross-project"
                cls_icon = {"PUBLIC": "🔓", "INTERNAL": "🔒", "CONFIDENTIAL": "⛔"}.get(m.classification, "?")
                print(f"    {cls_icon} {project}/{m.category} [{m.classification}] — {m.word_count} words")

        # Classification summary
        from seif.context.autonomous import CLASSIFICATION_LEVELS
        cls_counts = {}
        for m in mapper.modules:
            cls = getattr(m, 'classification', 'INTERNAL')
            cls_counts[cls] = cls_counts.get(cls, 0) + 1
        if cls_counts:
            print(f"\n  Classification:")
            for cls in ["PUBLIC", "INTERNAL", "CONFIDENTIAL"]:
                if cls in cls_counts:
                    print(f"    {cls}: {cls_counts[cls]} modules")


def cmd_relay(module_paths: list[str], backend: str, prompt: str, output: str):
    """Send .seif module(s) to an AI backend and get its interpretation."""
    import json
    try:
        from seif.bridge.ai_bridge import send, detect_backends
    except ImportError:
        _upgrade_message("--relay", "Send .seif modules to AI backends with classification filters.")
        return

    # Map short names to ai_bridge backend names
    backend_map = {
        "claude": "claude_cli",
        "gemini": "gemini_cli",
        "anthropic": "anthropic_api",
        "grok": "grok_api",
        "opencode": "opencode",
    }
    backend_key = backend_map.get(backend, backend)

    # Verify backend is available
    available = detect_backends()
    if backend_key not in available:
        print(f"Error: backend '{backend}' is not available.")
        print(f"Available backends: {', '.join(available) or 'none'}")
        print()
        if backend_key == "claude_cli":
            print("Install Claude CLI: npm install -g @anthropic-ai/claude-code")
        elif backend_key == "gemini_cli":
            print("Install Gemini CLI: npm install -g @anthropic-ai/gemini (or pip install gemini-cli)")
        elif backend_key == "anthropic_api":
            print("Set ANTHROPIC_API_KEY environment variable.")
        return

    # Load .seif modules as context
    context_parts = []
    for path in module_paths:
        try:
            with open(path, encoding="utf-8") as f:
                data = json.load(f)
            summary = data.get("summary", "")
            source = data.get("source", path)
            context_parts.append(f"[MODULE: {source}]\n{summary}")
        except Exception as e:
            print(f"Warning: could not load {path}: {e}")

    if not context_parts:
        print("No valid .seif modules loaded.")
        return

    context = "\n\n---\n\n".join(context_parts)
    message = f"{context}\n\n---\n\n{prompt}"

    print(f"Relaying to {backend}...")
    response = send(message, backend=backend_key)

    if not response.success:
        print(f"Error ({response.backend}): {response.error}")
        return

    if output:
        Path(output).write_text(response.text, encoding="utf-8")
        print(f"Response saved to: {output}")
    else:
        print(f"\n═══ {response.backend} ({response.model}) ═══")
        print(response.text)

    # Measure response quality
    from seif.analysis.quality_gate import assess
    verdict = assess(response.text[:1000], role="ai")
    _zeta = "ζ✅" if verdict.grade in ("A","B") else "ζ⚠️" if verdict.grade == "C" else "ζ❌"
    _stance = {"SOLID":"🟢","GROUNDED":"🟢","MIXED":"🟡","WEAK":"🔴","DRIFT":"🔴"}.get(verdict.status, "⚪")
    print(f"\n{_stance} {_zeta}  grade:{verdict.grade}  stance:{verdict.status}  resonance:{verdict.triple_gate.status}")


def cmd_packet(module_path: str, message: str, sender: str, receiver: str,
               classification: str, output: str, send: bool):
    """Create and optionally send a SEIF-PACKET-v1."""
    import json
    try:
        from seif.bridge.seif_packet import (
            create_packet, verify_packet, send_packet, save_packet,
            describe_packet, packet_to_dict,
        )
    except ImportError:
        _upgrade_message("--packet", "Create encrypted SEIF packets for cross-AI relay.")
        return

    # Load module if provided
    module = None
    if module_path:
        try:
            with open(module_path, encoding="utf-8") as f:
                module = json.load(f)
        except Exception as e:
            print(f"Error loading module: {e}")
            return

    # Create packet
    try:
        packet = create_packet(
            module=module,
            message=message,
            sender=sender,
            receiver=receiver,
            classification=classification,
        )
    except ValueError as e:
        print(f"Error: {e}")
        return

    print(describe_packet(packet))

    # Verify
    is_valid, errors = verify_packet(packet)
    if errors:
        for err in errors:
            print(f"  Warning: {err}")

    if send and receiver:
        # Map short names to backend keys
        backend_map = {
            "claude": "claude_cli",
            "gemini": "gemini_cli",
            "anthropic": "anthropic_api",
            "grok": "grok_api",
            "opencode": "opencode",
        }
        backend_key = backend_map.get(receiver, receiver)

        print(f"\nSending to {receiver}...")
        response, ack = send_packet(packet, backend=backend_key)

        if response.success:
            print(f"\n  Response ({response.backend}, {response.model}):")
            print(f"  {response.text[:300]}")
            if ack:
                circuit = ack.get("circuit", "?")
                rg = ack.get("quality_gate", {}).get("grade", "?")
                print(f"\n  ACK: circuit={circuit}, receiver_grade={rg}")
        else:
            print(f"\n  Send failed: {response.error}")
    elif send and not receiver:
        print("\nError: --to is required for sending packets.")

    # Save
    if output:
        path = save_packet(packet, output)
        print(f"\nPacket saved: {path}")
    elif not send:
        # Save to default location
        packets_dir = Path(".seif/packets")
        packets_dir.mkdir(parents=True, exist_ok=True)
        path = save_packet(packet, packets_dir / f"{packet.packet_id}.json")
        print(f"\nPacket saved: {path}")


def _normalize_for_similarity(text: str) -> str:
    """Normalize text for pairwise comparison: lowercase, remove punctuation."""
    import re
    return re.sub(r'[^a-z0-9\s]', '', text.lower())


def _compute_coherence(responses: list[dict], threshold: float) -> dict:
    """Compute pairwise similarity and quality gate agreement across responses."""
    import difflib

    pairs = {}
    texts = [(r["backend"], _normalize_for_similarity(r["raw_text"][:2000]))
             for r in responses]
    for i in range(len(texts)):
        for j in range(i + 1, len(texts)):
            sim = difflib.SequenceMatcher(None, texts[i][1], texts[j][1]).ratio()
            key = f"{texts[i][0]}-{texts[j][0]}"
            pairs[key] = round(sim, 3)

    avg_sim = sum(pairs.values()) / len(pairs) if pairs else 0

    grades = [r["quality_gate"]["grade"] for r in responses]
    stances = [r["quality_gate"]["stance"] for r in responses]
    dominant_grade = max(set(grades), key=grades.count)
    dominant_stance = max(set(stances), key=stances.count)
    qg_agreement = len(set(grades)) == 1 and len(set(stances)) == 1
    qg_bonus = 0.1 if qg_agreement else 0.0
    final_coherence = min(1.0, avg_sim + qg_bonus)

    return {
        "text_similarity": round(avg_sim, 3),
        "quality_gate_agreement": qg_agreement,
        "quality_gate_bonus": qg_bonus,
        "final_coherence": round(final_coherence, 3),
        "pairwise_similarities": pairs,
        "consensus_reached": final_coherence >= threshold,
        "threshold": threshold,
        "dominant_grade": dominant_grade,
        "dominant_stance": dominant_stance,
        "grades": grades,
        "stances": stances,
    }


def _build_refutation_prompt(question: str, my_backend: str,
                              my_response: str, other_responses: list[dict]) -> str:
    """Build the round 2 prompt: review others' answers, refute or converge."""
    others_text = ""
    for other in other_responses:
        others_text += f"\n--- {other['backend']} responded ---\n"
        others_text += other["raw_text"][:1500]
        others_text += "\n"

    return (
        f"You were asked: \"{question}\"\n\n"
        f"Your original answer:\n{my_response[:1500]}\n\n"
        f"Other AIs answered the same question:{others_text}\n\n"
        "TASK: Review the other responses against yours. For each point of disagreement:\n"
        "1. State what you disagree with and WHY (with evidence or reasoning)\n"
        "2. If their answer is better than yours, say so explicitly\n"
        "3. If you find errors in their reasoning, explain the error\n\n"
        "Then provide your FINAL ANSWER — either your original (if you stand by it), "
        "a revised version (if you learned something), or a synthesis of the best parts.\n\n"
        "Be honest. Being wrong and admitting it is more valuable than defending a bad answer."
    )


def _build_synthesis_prompt(question: str, round1: list[dict],
                             round2: list[dict]) -> str:
    """Build the round 3 synthesis prompt from all prior rounds."""
    parts = [f"Question: \"{question}\"\n"]

    parts.append("=== ROUND 1 (Independent answers) ===")
    for r in round1:
        parts.append(f"\n--- {r['backend']} ---\n{r['raw_text'][:800]}")

    parts.append("\n\n=== ROUND 2 (Cross-examination) ===")
    for r in round2:
        parts.append(f"\n--- {r['backend']} ---\n{r['raw_text'][:800]}")

    parts.append(
        "\n\nTASK: You are the synthesis judge. Based on both rounds above:\n"
        "1. Identify points ALL participants agree on (high confidence)\n"
        "2. Identify points where disagreement remains (flag as uncertain)\n"
        "3. Identify any errors that were caught during cross-examination\n"
        "4. Produce the UNIFIED ANSWER that reflects the genuine consensus.\n\n"
        "If no genuine consensus exists on a point, say so — forced agreement is worse than "
        "honest disagreement."
    )
    return "\n".join(parts)


def cmd_consensus(question: str, module_paths: list[str], backends: list[str],
                  output: str, threshold: float, mirror: bool = False,
                  rounds: int = 1):
    """Ask multiple AI backends the same question with shared .seif context.

    rounds=1: Independent answers only (original behavior).
    rounds=2: + Cross-examination (each AI reviews others' answers).
    rounds=3: + Synthesis (one AI produces unified answer from debate).
    """
    import json
    from datetime import datetime, timezone
    try:
        from seif.bridge.ai_bridge import send, send_clean, detect_backends
    except ImportError:
        _upgrade_message("--consensus", "Run the same question across multiple AIs and measure agreement.")
        return
    from seif.analysis.quality_gate import assess

    # Map short names
    backend_map = {
        "claude": "claude_cli",
        "gemini": "gemini_cli",
        "anthropic": "anthropic_api",
        "grok": "grok_api",
        "opencode": "opencode",
    }

    # Verify at least 2 backends are available
    available = detect_backends()
    missing = [b for b in backends if backend_map.get(b, b) not in available]
    if missing:
        print(f"Warning: backend(s) not available: {', '.join(missing)}")
        print(f"Available: {', '.join(available) or 'none'}")
        if len(backends) - len(missing) < 2:
            print("\nNeed at least 2 working backends for consensus.")
            print("Install Claude CLI or Gemini CLI, or set ANTHROPIC_API_KEY.")
            return
        backends = [b for b in backends if b not in missing]
        print(f"Continuing with: {', '.join(backends)}\n")

    # Load context
    context = ""
    if module_paths:
        parts = []
        for path in module_paths:
            try:
                with open(path, encoding="utf-8") as f:
                    data = json.load(f)
                summary = data.get("summary", "")
                source = data.get("source", path)
                parts.append(f"[MODULE: {source}]\n{summary}")
            except Exception:
                pass
        context = "\n\n---\n\n".join(parts)

    message = f"{context}\n\n---\n\n{question}" if context else question

    # ── Round 1: Independent answers ─────────────────────────────
    print(f"═══ ROUND 1 / {rounds} — Independent answers ═══\n")
    round1_responses = []
    for backend in backends:
        backend_key = backend_map.get(backend, backend)
        print(f"  Querying {backend}...", end=" ", flush=True)
        resp = send(message, backend=backend_key)
        if resp.success:
            verdict = assess(resp.text[:1000], role="ai")
            round1_responses.append({
                "backend": backend,
                "raw_text": resp.text,
                "quality_gate": {
                    "grade": verdict.grade,
                    "stance": verdict.status,
                    "resonance": verdict.triple_gate.status,
                    "score": round(verdict.score, 3),
                },
            })
            print(f"{verdict.grade} ({verdict.status})")
        else:
            print(f"FAILED: {resp.error}")

    # Mirror mode
    if mirror:
        mirror_backend = backend_map.get(backends[0], backends[0])
        print(f"  Querying {backends[0]} (CLEAN MIRROR)...", end=" ", flush=True)
        resp = send_clean(question, backend=mirror_backend)
        if resp.success:
            verdict = assess(resp.text[:1000], role="ai")
            round1_responses.append({
                "backend": f"{backends[0]}_clean",
                "raw_text": resp.text,
                "quality_gate": {
                    "grade": verdict.grade,
                    "stance": verdict.status,
                    "resonance": verdict.triple_gate.status,
                    "score": round(verdict.score, 3),
                },
                "is_mirror": True,
            })
            print(f"{verdict.grade} ({verdict.status}) [NO PROTOCOL]")
        else:
            print(f"FAILED: {resp.error}")

    if len(round1_responses) < 2:
        print("\nNeed at least 2 successful responses for consensus.")
        return

    # Filter short responses
    round1_responses = [r for r in round1_responses if len(r["raw_text"].strip()) >= 50]
    if len(round1_responses) < 2:
        print(f"\nOnly {len(round1_responses)} valid responses (>= 50 chars). Need at least 2.")
        return

    r1_coherence = _compute_coherence(round1_responses, threshold)

    # Print round 1 summary
    print(f"\n  Round 1 coherence: {r1_coherence['final_coherence']:.3f} "
          f"(threshold: {threshold})")
    if r1_coherence["consensus_reached"]:
        print("  Round 1: CONSENSUS REACHED")
        if rounds == 1:
            print("  (use --rounds 2 for cross-examination)")

    # ── Round 2: Cross-examination (refutation) ──────────────────
    round2_responses = []
    if rounds >= 2 and len(round1_responses) >= 2:
        print(f"\n═══ ROUND 2 / {rounds} — Cross-examination ═══\n")

        for r in round1_responses:
            if r.get("is_mirror"):
                continue  # mirrors don't participate in debate
            backend = r["backend"]
            backend_key = backend_map.get(backend, backend)
            others = [o for o in round1_responses if o["backend"] != backend]

            refutation_prompt = _build_refutation_prompt(
                question, backend, r["raw_text"], others)

            print(f"  {backend} reviewing others...", end=" ", flush=True)
            resp = send(refutation_prompt, backend=backend_key)
            if resp.success:
                verdict = assess(resp.text[:1000], role="ai")
                round2_responses.append({
                    "backend": backend,
                    "raw_text": resp.text,
                    "quality_gate": {
                        "grade": verdict.grade,
                        "stance": verdict.status,
                        "resonance": verdict.triple_gate.status,
                        "score": round(verdict.score, 3),
                    },
                    "round": 2,
                })
                print(f"{verdict.grade} ({verdict.status})")
            else:
                print(f"FAILED: {resp.error}")

        if len(round2_responses) >= 2:
            r2_coherence = _compute_coherence(round2_responses, threshold)
            print(f"\n  Round 2 coherence: {r2_coherence['final_coherence']:.3f} "
                  f"(R1 was {r1_coherence['final_coherence']:.3f})")
            delta = r2_coherence["final_coherence"] - r1_coherence["final_coherence"]
            direction = "CONVERGED" if delta > 0.05 else "DIVERGED" if delta < -0.05 else "STABLE"
            print(f"  Direction: {direction} (delta: {delta:+.3f})")
        else:
            r2_coherence = r1_coherence

    # ── Round 3: Synthesis (optional) ────────────────────────────
    synthesis = None
    if rounds >= 3 and round2_responses:
        print(f"\n═══ ROUND 3 / {rounds} — Synthesis ═══\n")

        # Use the first healthy backend as synthesizer
        synth_backend = backends[0]
        synth_key = backend_map.get(synth_backend, synth_backend)
        synthesis_prompt = _build_synthesis_prompt(
            question, round1_responses, round2_responses)

        print(f"  Synthesizer: {synth_backend}...", end=" ", flush=True)
        resp = send(synthesis_prompt, backend=synth_key)
        if resp.success:
            verdict = assess(resp.text[:1000], role="ai")
            synthesis = {
                "backend": synth_backend,
                "raw_text": resp.text,
                "quality_gate": {
                    "grade": verdict.grade,
                    "stance": verdict.status,
                    "resonance": verdict.triple_gate.status,
                    "score": round(verdict.score, 3),
                },
                "round": 3,
            }
            print(f"{verdict.grade} ({verdict.status})")
        else:
            print(f"FAILED: {resp.error}")

    # ── Final result ─────────────────────────────────────────────
    final_responses = round2_responses if round2_responses else round1_responses
    final_coh = _compute_coherence(final_responses, threshold) if len(final_responses) >= 2 else r1_coherence
    consensus_reached = final_coh["consensus_reached"]

    result = {
        "question": question,
        "context_modules": module_paths,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "backends": backends,
        "rounds_executed": min(rounds, 3),
        "round_1": {
            "responses": round1_responses,
            "coherence": r1_coherence,
        },
    }
    if round2_responses:
        result["round_2"] = {
            "responses": round2_responses,
            "coherence": _compute_coherence(round2_responses, threshold) if len(round2_responses) >= 2 else None,
        }
    if synthesis:
        result["round_3_synthesis"] = synthesis
    result["final"] = {
        "coherence": final_coh,
        "consensus_reached": consensus_reached,
    }
    result["quality_gate_summary"] = {
        "dominant_grade": final_coh["dominant_grade"],
        "dominant_stance": final_coh["dominant_stance"],
        "grades": final_coh["grades"],
    }

    # Output
    if output and output.endswith(".json"):
        Path(output).write_text(json.dumps(result, indent=2, ensure_ascii=False),
                                encoding="utf-8")
        print(f"\nFull results saved to: {output}")

    # Human-readable summary
    print(f"\n═══ FINAL — CONSENSUS ({len(final_responses)} backends, "
          f"{min(rounds, 3)} round{'s' if rounds > 1 else ''}) ═══")
    print(f"Question: {question[:100]}")
    print()
    for r in final_responses:
        qg = r["quality_gate"]
        preview = r["raw_text"][:120].replace("\n", " ")
        label = f"  {r['backend']:<10}"
        print(f"{label} ({qg['grade']}, {qg['stance']}) : {preview}...")
    if synthesis:
        print(f"\n  SYNTHESIS ({synthesis['quality_gate']['grade']}, "
              f"{synthesis['quality_gate']['stance']}):")
        # Print first 300 chars of synthesis
        for line in synthesis["raw_text"][:300].split("\n"):
            print(f"    {line}")
        if len(synthesis["raw_text"]) > 300:
            print("    ...")
    print()
    print(f"Coherence: R1={r1_coherence['final_coherence']:.3f}", end="")
    if round2_responses and len(round2_responses) >= 2:
        r2c = _compute_coherence(round2_responses, threshold)
        print(f" → R2={r2c['final_coherence']:.3f}", end="")
    print(f" (threshold: {threshold})")
    if final_coh["quality_gate_agreement"]:
        print(f"Quality gate: AGREEMENT (all {final_coh['dominant_grade']}, "
              f"{final_coh['dominant_stance']})")
    else:
        print(f"Quality gate: MIXED (grades: {final_coh['grades']}, "
              f"stances: {final_coh['stances']})")
    status_str = "CONSENSUS REACHED" if consensus_reached else "NO CONSENSUS"
    print(f"Status: {status_str}")
    if final_coh["pairwise_similarities"]:
        print(f"Pairwise: {final_coh['pairwise_similarities']}")


def cmd_export(context_repo: str, classification: str, output: str):
    try:
        from seif.context.autonomous import (
            load_mapper, bootstrap_context, find_context_repo, CLASSIFICATION_LEVELS,
        )
    except ImportError:
        print("Installation error: seif.context.autonomous not found. Try: pip install --force-reinstall seif-cli")
        return

    # Auto-discover context repo if not specified
    if not context_repo:
        context_repo = find_context_repo() or ".seif"
    from pathlib import Path

    if classification not in CLASSIFICATION_LEVELS:
        print(f"Invalid classification: {classification}")
        print(f"Valid: {', '.join(CLASSIFICATION_LEVELS.keys())}")
        return

    mapper = load_mapper(context_repo)
    context = bootstrap_context(mapper, context_repo,
                                max_tokens=50000,
                                max_classification=classification)

    if output:
        Path(output).write_text(context, encoding="utf-8")
        print(f"Exported to: {output}")
    else:
        print(context)

    # Stats
    total = len(mapper.modules)
    level = CLASSIFICATION_LEVELS[classification]
    included = sum(1 for m in mapper.modules
                   if CLASSIFICATION_LEVELS.get(m.classification, 2) <= level)
    excluded = total - included
    print(f"\n--- Export: {included}/{total} modules (excluded {excluded} above {classification})")


def cmd_install_hooks(repo_path: str):
    try:
        from seif.context.git_hooks import install_hooks, check_hooks
    except ImportError:
        print("Installation error: seif.context.git_hooks not found. Try: pip install --force-reinstall seif-cli")
        return
    installed = install_hooks(repo_path)
    if installed:
        print("Git hooks installed:")
        for h in installed:
            print(f"  {h}")
        print("\n.seif will auto-sync on commit, pull, and branch switch.")
    else:
        print("No .git directory found. Initialize git first.")


def _detect_owner(root: "Path") -> dict:
    """Detect workspace owner from git config and RESONANCE.json."""
    import subprocess as _sp
    owner = {"name": None, "email": None, "fingerprint": None}

    # Try git config
    try:
        result = _sp.run(["git", "config", "user.name"], capture_output=True, text=True, cwd=str(root))
        if result.returncode == 0 and result.stdout.strip():
            owner["name"] = result.stdout.strip()
        result = _sp.run(["git", "config", "user.email"], capture_output=True, text=True, cwd=str(root))
        if result.returncode == 0 and result.stdout.strip():
            owner["email"] = result.stdout.strip()
    except Exception:
        pass

    # Try RESONANCE.json for Ed25519 fingerprint
    resonance_path = root / "RESONANCE.json"
    if not resonance_path.exists():
        # Check subprojects
        for sub in root.iterdir():
            r = sub / "RESONANCE.json"
            if r.exists():
                resonance_path = r
                break

    if resonance_path.exists():
        try:
            import json
            with open(resonance_path) as f:
                kernel = json.load(f)
            fp = kernel.get("cryptographic_identity", {}).get("key_fingerprint")
            if fp:
                owner["fingerprint"] = fp
            author_name = kernel.get("instruction", {}).get("author")
            if author_name and not owner["name"]:
                owner["name"] = author_name
        except Exception:
            pass

    return owner


def cmd_init(root_path: str, author: str, context_repo: str = None,
             auto_yes: bool = False):
    try:
        from seif.context.workspace import (
            discover_projects, sync_workspace, describe_workspace,
            find_umbrella_workspace, write_seif_pointer,
        )
        from seif.context.git_context import sync_project, extract_git_context
        from seif.context.git_hooks import install_hooks
    except ImportError:
        print("Installation error: seif.context.workspace not found. Try: pip install --force-reinstall seif-cli")
        return
    from pathlib import Path

    root = Path(root_path).resolve()
    root.mkdir(parents=True, exist_ok=True)

    # ── Phase 0: Umbrella detection (SEIF-WORKSPACE-v1) ─────────────
    # If we're inside an existing umbrella workspace AND not at the umbrella
    # root itself, write a .seif-pointer.json instead of creating a scaffold.
    # See SEIF.md "Workspace Architecture (SEIF-WORKSPACE-v1)".
    if not context_repo:
        umbrella = find_umbrella_workspace(root)
        if umbrella is not None:
            umbrella_root, umbrella_id = umbrella
            if umbrella_root.resolve() != root.resolve():
                print(f"Detected umbrella workspace: {umbrella_root}")
                print(f"  workspace_id: {umbrella_id}")
                print(f"  This path is a sub-project — writing .seif-pointer.json (no scaffold)")
                if not auto_yes:
                    try:
                        confirm = input("Proceed? [Y/n] ").strip().lower()
                    except (EOFError, KeyboardInterrupt):
                        print("\nAborted.")
                        return
                    if confirm and confirm not in ("y", "yes", "s", "sim"):
                        print("Aborted.")
                        return
                pointer_path = write_seif_pointer(root, umbrella_root, umbrella_id)
                print(f"\nCreated: {pointer_path}")
                print(f"  All seif-cli reads/writes from this dir will route to "
                      f"{umbrella_root}/.seif/")
                return

    # ── Phase 1: Scan ──────────────────────────────────────────────
    print(f"Scanning {root}...\n")

    # Detect owner
    owner = _detect_owner(root)
    if owner["name"]:
        print(f"Owner: {owner['name']}")
        if owner["email"]:
            print(f"  Email: {owner['email']}")
        if owner["fingerprint"]:
            print(f"  Ed25519 fingerprint: {owner['fingerprint']}")
        if not author or author == "workspace":
            author = owner["name"]
    else:
        print("Owner: (not detected — set with git config user.name or --author)")
    print()

    if context_repo:
        print(f"Context repository: {context_repo} (SCR mode)")
        print()

    # Discover projects
    subprojects = discover_projects(str(root))

    # Check existing .seif state
    seif_dir = root / ".seif"
    has_existing = seif_dir.exists() and (seif_dir / "config.json").exists()

    # ── Phase 2: Propose ────────────────────────────────────────────
    if subprojects:
        git_projects = [p for p in subprojects if (root / p.path / ".git").exists()]
        non_git = [p for p in subprojects if p not in git_projects]

        print(f"Detected WORKSPACE with {len(subprojects)} projects:")
        print()
        for p in subprojects:
            has_git = (root / p.path / ".git").exists()
            git_label = " (git)" if has_git else ""
            print(f"  {p.name:<25} {p.manifest_type or 'unknown'}{git_label}")
            if p.description:
                print(f"    {p.description[:80]}")
        print()

        # Propose structure
        print("Proposed .seif/ structure:")
        if context_repo:
            ctx_path = Path(context_repo).resolve()
            print(f"  {ctx_path}/config.json         — workspace configuration")
            print(f"  {ctx_path}/mapper.json         — module index")
            print(f"  {ctx_path}/nucleus.seif        — workspace-level context")
            for p in subprojects:
                print(f"  {ctx_path}/projects/{p.name}/")
        else:
            print(f"  .seif/config.json              — workspace configuration")
            print(f"  .seif/mapper.json              — module index")
            print(f"  .seif/nucleus.seif             — workspace-level context")
            for p in subprojects:
                print(f"  .seif/projects/{p.name}/")
        if git_projects:
            print(f"  + git hooks in {len(git_projects)} projects  — auto-sync on commit")
        print(f"  + global registry              — ~/.seif/registry.json")
        if owner["name"]:
            print(f"  + owner profile                — modules/owner.seif")
        if has_existing:
            print()
            print(f"  (existing .seif/ found — will merge, not overwrite)")
        print()

    else:
        # Single project
        has_git = (root / ".git").exists()
        if has_git:
            ctx = extract_git_context(str(root))
            print(f"Detected SINGLE PROJECT: {ctx.repo_name}")
            print(f"  Branch:       {ctx.branch}")
            print(f"  Commits:      {ctx.total_commits}")
            print(f"  Contributors: {len(ctx.contributors)}")
            if ctx.manifest_type:
                print(f"  Manifest:     {ctx.manifest_type}")
            if ctx.hot_files:
                top = ctx.hot_files[0]
                print(f"  Hot file:     {top[0]} ({top[1]} changes)")
        else:
            print(f"No git repo found. Will initialize git.")

        print()
        print("Proposed .seif/ structure:")
        print(f"  .seif/config.json              — project configuration")
        print(f"  .seif/mapper.json              — module index")
        if has_git:
            print(f"  .seif/project.seif             — git context")
            print(f"  + git hooks                    — auto-sync on commit")
        print(f"  + global registry              — ~/.seif/registry.json")
        print()

    # ── Phase 3: Confirm ────────────────────────────────────────────
    if not auto_yes:
        try:
            confirm = input("Proceed? [Y/n] ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print("\nAborted.")
            return

        if confirm and confirm not in ("y", "yes", "s", "sim"):
            print("Aborted.")
            return

    print()

    # ── Phase 4: Execute ────────────────────────────────────────────
    if subprojects:
        print("Syncing all projects...")
        registry = sync_workspace(str(root), author=author,
                                  context_repo_path=context_repo)
        print()
        print(describe_workspace(registry))

        # Summary
        print()
        print(f"Created:")
        if context_repo:
            ctx_path = Path(context_repo).resolve()
            print(f"  {ctx_path}/manifest.json   — SCR manifest ({len(registry.projects)} projects)")
            print(f"  {ctx_path}/nucleus.seif     — workspace-level context")
            for p in registry.projects:
                print(f"  {ctx_path}/projects/{p.name}/")
        else:
            print(f"  .seif/workspace.json    — project registry ({len(registry.projects)} projects)")
            print(f"  .seif/nucleus.seif      — workspace-level context")
            for p in registry.projects:
                seif_path = root / p.path / ".seif" / "project.seif"
                if seif_path.exists():
                    print(f"  {p.path}/.seif/project.seif")

    else:
        # Single project mode
        has_git = (root / ".git").exists()
        if not has_git:
            print("Initializing git...")
            import subprocess as _sp
            _sp.run(["git", "init", str(root)], check=True, capture_output=True)
            print("  git init done.")
            has_git = True

        if has_git:
            if not subprojects:
                ctx = extract_git_context(str(root))

            target = None
            if context_repo:
                ctx_path = Path(context_repo).resolve()
                ctx_path.mkdir(parents=True, exist_ok=True)
                target = str(ctx_path / "projects" / ctx.repo_name / "project.seif")
                from seif.context.ref import create_ref, save_ref
                ref = create_ref(str(root), str(ctx_path))
                save_ref(ref, Path(target).parent / "ref.json")

            module, path = sync_project(str(root), author=author, target_path=target)
            print(f"Created:")
            print(f"  {path}")
            print(f"  Words:   {module.compressed_words}")
            print(f"  Hash:    {module.integrity_hash}")

    # Install git hooks
    if subprojects:
        hook_count = 0
        for p in subprojects:
            project_dir = root / p.path
            if (project_dir / ".git").exists():
                hooks = install_hooks(str(project_dir))
                if hooks:
                    hook_count += 1
        if hook_count:
            print(f"\nGit hooks: installed in {hook_count} projects (auto-sync on commit/pull)")
    elif (root / ".git").exists():
        hooks = install_hooks(str(root))
        if hooks:
            print(f"\nGit hooks: {', '.join(h.split(' ')[0] for h in hooks)}")
            print("  .seif auto-syncs on commit, pull, and branch switch")

    # Register in global registry
    try:
        from seif.context.registry import register_context
        seif_dir_str = str(Path(context_repo).resolve()) if context_repo else str(root / ".seif")
        entry = register_context(seif_dir_str)
        print(f"\nRegistered in ~/.seif/registry.json as '{entry['name']}'")
        print(f"  Use: seif --list          — see all your contexts")
    except Exception as e:
        print(f"\n  (registry: {e})")

    # Create owner module templates
    try:
        from seif.context.workspace import create_owner_modules
        seif_path = Path(context_repo).resolve() if context_repo else root / ".seif"
        owner_created = create_owner_modules(seif_path, owner_name=author)
        if owner_created:
            print(f"\nOwner modules: {owner_created} templates created")
            print(f"  {seif_path / 'modules'}/ (feedback, decisions, projects, sessions)")
            print(f"  {seif_path / 'private' / 'owner' / 'profile.seif'}")
    except Exception as e:
        print(f"\n  (owner modules: {e})")

    # Generate CLAUDE.md for Claude Code integration
    _generate_claude_md(root, project_name=author)
    if (root / "CLAUDE.md").exists():
        print(f"\nCLAUDE.md: generated (Claude Code loads this automatically)")

    # Auto-bind hookless adapters: render protocol into the files each
    # detected client reads at session start (Copilot's
    # .github/copilot-instructions.md, Cursor's .cursor/rules/seif.mdc,
    # generic AGENTS.md, …). One command does what previously required
    # `seif --init` then `seif --plugin-detect --apply` separately.
    # Skipped silently if the plugin_detect module isn't importable
    # (older installs / partial deploys).
    try:
        from seif.cli.plugin_detect import detect_adapters
        results = detect_adapters(root, Path.home(), apply=True)
        hookless_matched = [r for r in results if r.matches and not r.runtime_capable]
        if hookless_matched:
            print()
            print("Hookless adapters auto-bound:")
            for r in hookless_matched:
                if r.written_paths:
                    for p in r.written_paths:
                        try:
                            rel = p.relative_to(root)
                            shown = str(rel)
                        except ValueError:
                            shown = str(p)
                        print(f"  · {r.name:<10} → {shown}")
                elif r.skipped_reason:
                    print(f"  · {r.name:<10} skipped: {r.skipped_reason}")
    except ImportError:
        pass
    except Exception as e:
        # Don't fail init on adapter binding errors — surface and continue
        print(f"\n  (auto-bind skipped: {e})")

    print()
    print("Done. Next steps:")
    print("  seif setup claude-code            — install hooks + skills")
    print("  seif setup wrapper-shims          — shell-level A4 enforcement")
    print("  seif --quality-gate \"text\"       — measure any text")
    if context_repo:
        print(f"  seif --sync --context-repo {context_repo}  — re-sync")
        print(f"  seif --workspace --context-repo {context_repo} --ingest daily.txt")
    else:
        print("  seif --sync                       — re-sync after changes")
        print("  seif --ingest daily.txt            — ingest meeting notes")
        if subprojects:
            print("  seif --workspace --ingest daily.txt — route to all projects")



def _generate_claude_md(root: Path, project_name: str = ""):
    """Generate CLAUDE.md with operational SEIF instructions for Claude Code.

    This is the score that the maestro reads. Without it, the orchestra
    plays random notes. With it, every instrument knows its part.
    """
    claude_md = root / "CLAUDE.md"

    # Don't overwrite if it already has SEIF section
    if claude_md.exists():
        existing = claude_md.read_text(encoding="utf-8")
        if "S.E.I.F." in existing or "seif" in existing.lower()[:200]:
            return False

    name = project_name or root.name
    has_seif = (root / ".seif").is_dir()

    lines = []
    lines.append(f"# {name}")
    lines.append("")

    lines.append("## S.E.I.F. Protocol — Operational Instructions")
    lines.append("")
    lines.append("This project uses S.E.I.F. for persistent context, quality measurement,")
    lines.append("and data classification. These are not descriptions — they are instructions")
    lines.append("you MUST follow during this session.")
    lines.append("")

    # -- Session lifecycle --
    lines.append("### Session Lifecycle")
    lines.append("")
    lines.append("You are the **writer** in this session. Follow this lifecycle:")
    lines.append("")
    lines.append("#### 1. SESSION START (do this NOW)")
    if has_seif:
        lines.append("- Read `.seif/mapper.json` — load top 5 modules by relevance")
        lines.append("- Read `.seif/config.json` — check autonomous_context and session_lifecycle")
        lines.append("- Check `.seif/sessions/` for open sessions — resume if one exists")
        lines.append("- If no open session, create one:")
        lines.append("  ```bash")
        lines.append('  seif --session create --session-name $(date +%Y-%m-%d)-<topic> --author claude --session-message "<purpose>"')
        lines.append("  ```")
    else:
        lines.append("- No `.seif/` found. Suggest running `seif --init` to the user.")
    lines.append("")

    lines.append("#### 2. DURING SESSION — Contribute at milestones")
    lines.append("- After significant decisions, deliverables, or discoveries:")
    lines.append("  ```bash")
    lines.append('  seif --session contribute --session-name <name> --author claude --session-message "<what happened>"')
    lines.append("  ```")
    lines.append("- Contribute at natural milestones, not after every tool call")
    lines.append("- If you create persistent knowledge (a pattern, a decision, feedback),")
    lines.append("  persist it to `.seif/` — not just in conversation memory")
    lines.append("")

    lines.append("#### 3. SESSION END — Full Circle ritual")
    lines.append("Before the conversation ends, you MUST complete the closure ritual:")
    lines.append("")
    lines.append("1. **CHECKPOINT** — Summarize what was done")
    lines.append("2. **AUDIT** — Verify `.seif/` integrity: no orphans, no ghosts, hashes valid")
    lines.append("   ```bash")
    lines.append("   seif --autonomous status")
    lines.append("   ```")
    lines.append("3. **MEDITATE** — Run quality gate on your key contributions:")
    lines.append("   ```bash")
    lines.append('   seif --quality-gate "<your most important output this session>" --role ai')
    lines.append("   ```")
    lines.append("4. **ABSORB** — Persist any observations for the next session")
    lines.append("5. **CIRCLE** — Close the session:")
    lines.append("   ```bash")
    lines.append("   seif --session close --session-name <name> --author claude")
    lines.append("   ```")
    lines.append("")

    # -- Quality Gate --
    lines.append("### Quality Gate — How to use it")
    lines.append("")
    lines.append("The quality gate measures your output on two axes:")
    lines.append("- **Stance**: GROUNDED (verifiable) vs DRIFT (speculative)")
    lines.append("- **Grade**: A (excellent) to F (ungrounded)")
    lines.append("")
    lines.append("Rules:")
    lines.append("- When you make a factual claim, it must be verifiable")
    lines.append("- Distinguish clearly between verified facts and interpretive claims")
    lines.append("- If you don't know something, say so — DRIFT is detectable")
    lines.append("- After significant writes, the PostToolUse hook measures automatically")
    lines.append('- You can self-check: `seif --quality-gate "<text>" --role ai`')
    lines.append("")

    # -- Classification --
    lines.append("### Classification Gate — Data protection")
    lines.append("")
    lines.append("Content is classified as PUBLIC, INTERNAL, or CONFIDENTIAL.")
    lines.append("")
    lines.append("Rules:")
    lines.append("- NEVER write CONFIDENTIAL content to files outside `.seif/`")
    lines.append("- Keywords that auto-escalate to CONFIDENTIAL: password, token, credential,")
    lines.append("  api_key, secret, CVE, private key, Bearer")
    lines.append("- Classification only escalates, never downgrades")
    lines.append("- The PreToolUse hook blocks violations automatically, but you should")
    lines.append("  self-monitor and avoid even attempting to write sensitive data")
    lines.append("")

    # -- Context compression --
    if has_seif:
        lines.append("### Autonomous Context — Persist knowledge")
        lines.append("")
        lines.append("When you observe persistable knowledge during this session:")
        lines.append("")
        lines.append("| Type | When to persist | Where |")
        lines.append("|------|----------------|-------|")
        lines.append("| **Decision** | Architectural choice with reasoning | `.seif/modules/decisions.seif` |")
        lines.append("| **Pattern** | Recurring code convention | `.seif/modules/patterns.seif` |")
        lines.append("| **Feedback** | User correction or preference | `.seif/modules/feedback.seif` |")
        lines.append("| **Intent** | User's goal or motivation | `.seif/modules/intent.seif` |")
        lines.append("")
        lines.append('Use `seif --contribute <module.seif> "<observation>" --author claude`')
        lines.append("to add to existing modules with provenance tracking.")
        lines.append("")
        lines.append("The boundary test: if the content becomes obsolete when the task is")
        lines.append("completed, it belongs in a session record, NOT a module.")
        lines.append("")

    # -- Principles --
    lines.append("### Operating Principles")
    lines.append("")
    lines.append("- **CONTEXT_NOT_COMMAND**: The protocol provides data, not directives.")
    lines.append("  You measure and report. The human decides.")
    lines.append("- **Minimal intervention**: Fix 1 file before refactoring 20.")
    lines.append("  Weigh cost vs benefit BEFORE acting. intervention_ratio < 3.0")
    lines.append("- **Honest measurement**: Test claims rigorously. Falsify when evidence")
    lines.append("  demands. Correct in real-time. The process of honest measurement IS the value.")
    lines.append("- **Partial attention**: Never dedicate 100% to task execution. Maintain")
    lines.append("  awareness of context, feedback, and human signals (tau:kappa = 2:1).")
    lines.append("- **Settling time**: After receiving feedback, your NEXT action must reflect")
    lines.append("  the feedback, not just acknowledge it.")
    lines.append("")

    final = "\n".join(lines) + "\n"

    if claude_md.exists():
        existing = claude_md.read_text(encoding="utf-8")
        final = existing.rstrip() + "\n\n" + final
        claude_md.write_text(final, encoding="utf-8")
    else:
        claude_md.write_text(final, encoding="utf-8")

    return True


def cmd_workspace(workspace_root: str, ingest_source: str = None,
                   author: str = "workspace", via: str = "sync",
                   context_repo: str = None):
    try:
        from seif.context.workspace import (
            sync_workspace, describe_workspace, ingest_to_workspace,
        )
    except ImportError:
        print("Installation error: seif.context.workspace not found. Try: pip install --force-reinstall seif-cli")
        return

    if ingest_source:
        # Route ingested text to all projects in workspace
        from seif.context.ingest import describe_ingest
        results = ingest_to_workspace(workspace_root, ingest_source,
                                       author=author, via=via,
                                       context_repo_path=context_repo)
        if "error" in results:
            print(f"Error: {results['error']}")
            return
        for project_name, result in results.items():
            if result.relevant:
                print(f"\n{project_name}:")
                print(describe_ingest(result))
            else:
                print(f"\n{project_name}: no relevant content")
    else:
        # Discover + sync all projects
        mode = " (SCR)" if context_repo else ""
        print(f"Syncing workspace{mode}: {workspace_root}")
        registry = sync_workspace(workspace_root, author=author,
                                  context_repo_path=context_repo)
        print()
        print(describe_workspace(registry))


def cmd_handoff(session_name: str, context_repo: str = None):
    try:
        from seif.context.sessions import describe_session
        from seif.context.autonomous import find_context_repo
    except ImportError:
        _upgrade_message("--handoff", "Generate session handoff for multi-AI collaboration.")
        return

    ctx = context_repo or find_context_repo() or ".seif"

    session_data = describe_session(ctx, session_name)

    # Generate seed
    import json
    from datetime import datetime

    seed = {
        "_instruction": "SEIF-SEED-v1 | Handoff",
        "protocol": "SEIF-SEED-v1",
        "created_at": datetime.now().isoformat() + "Z",
        "author": "Copilot",
        "classification": "INTERNAL",
        "valid_for": "session-handoff",
        "recipient": "next-writer",
        "session": session_data
    }

    print("SEIF-SEED-v1 for handoff:")
    print(json.dumps(seed, indent=2, ensure_ascii=False))


def cmd_mirror_weekly(context_repo: str = None):
    """Run weekly consensus with mirror for validation."""
    try:
        from seif.bridge.ai_bridge import detect_backends
        from seif.bridge.consensus import run_consensus
    except ImportError:
        _upgrade_message("--mirror-weekly", "Run weekly adversarial mirror analysis.")
        return

    backends = detect_backends()
    if not backends:
        print("No backends available for consensus.")
        return

    question = "Weekly SEIF validation: Is the current workspace structure optimally resonant? Propose improvements for self-healing and Enoch seed alignment."
    context_modules = []  # Could load nucleus.seif

    print("Running weekly mirror consensus...")
    result = run_consensus(question, backends[:3], context_modules, mirror=True)
    print("Consensus result:")
    print(result.get("summary", "No summary"))


def cmd_verify_seed():
    """Verify resonance with Enoch seed."""
    try:
        from seif.core.resonance_gate import verify_seed
    except ImportError:
        print("Resonance gate not available.")
        return

    seed = "A Semente de Enoque"
    result = verify_seed(seed)
    print(f"Enoch seed verification: {'VALID' if result['verified'] else 'INVALID'}")
    print(f"Resonance: sum={result['actual_sum']}, root={result['actual_root']}, phase={result['phase']}")


def cmd_evolve():
    """Trigger SEIF OS evolution: analyze feedback and auto-mutate."""
    try:
        from seif.core.resonance_gate import boot_seif_os
        from seif.context.autonomous import audit_context, find_context_repo
    except ImportError:
        print("SEIF OS evolution requires seif-engine.")
        return

    # Boot check
    boot = boot_seif_os()
    if boot["boot_status"] != "SUCCESS":
        print("Evolution failed: Boot check failed.")
        return

    # Audit context for evolution opportunities
    ctx = find_context_repo() or ".seif"
    audit_result = audit_context(ctx, fix=True, sync=True)

    # Simulate evolution: increase axioms or zeta
    new_kernel = {
        "version": "3.3.2",  # Evolved
        "axioms": 20,  # Increased
        "zeta_optimal": 0.612372,  # √6/4 — from H(s) = 9/(s²+3s+6)
    }

    from seif.cli.resonance_display import ResonanceReport
    report = ResonanceReport("SEIF OS EVOLUTION")
    report.section("Evolution")
    report.kv("Boot Status", boot['boot_status'])
    report.kv("Kernel Evolved", f"{boot['kernel_version']} → {new_kernel['version']}")
    report.kv("Axioms", f"{boot['axioms']} → {new_kernel['axioms']}")
    report.kv("Zeta", f"{boot['zeta_optimal']:.6f} → {new_kernel['zeta_optimal']:.6f}")
    report.kv("Auto-Audit", f"{audit_result.orphans_healed} orphans healed, {audit_result.hashes_fixed} hashes fixed")
    report.blank()
    report.line("Evolution complete. SEIF OS resonance enhanced.")
    print(report.render())


def cmd_communicate(message: str):
    """Generate a carrier WAV alongside a metadata sidecar.

    Demo path for audio steganography. For real provenance watermarking,
    use --watermark-embed (which encodes payload in inaudible band).
    """
    import wave
    import math
    import struct

    carrier_freq_hz = 432.0
    duration_seconds = 10.0
    sample_rate = 44100
    num_samples = int(sample_rate * duration_seconds)

    audio_data = []
    for i in range(num_samples):
        t = i / sample_rate
        sample = (
            0.5 * math.sin(2 * math.pi * carrier_freq_hz * t)
            + 0.25 * math.sin(2 * math.pi * (carrier_freq_hz * 2) * t)
        )
        sample = max(-1.0, min(1.0, sample))
        audio_data.append(int(sample * 32767))

    packed_data = b''.join(struct.pack('<h', sample) for sample in audio_data)

    output_file = f"seif_communication_{hash(message) % 1000}.wav"
    with wave.open(output_file, 'wb') as wav_file:
        wav_file.setnchannels(1)
        wav_file.setsampwidth(2)
        wav_file.setframerate(sample_rate)
        wav_file.writeframes(packed_data)

    metadata_file = output_file.replace('.wav', '.txt')
    with open(metadata_file, 'w') as f:
        f.write("SEIF audio carrier (demo)\n")
        f.write(f"Message: {message}\n")
        f.write(f"Carrier frequency: {carrier_freq_hz} Hz\n")
        f.write(f"Duration: {duration_seconds} s\n")
        f.write("Sidecar metadata only — payload is plaintext, not embedded in audio.\n")
        f.write("For payload embedding, use --watermark-embed.\n")

    from seif.cli.resonance_display import ResonanceReport
    report = ResonanceReport("SEIF AUDIO CARRIER")
    report.section("Output")
    report.kv("Message", message)
    report.kv("Carrier", f"{carrier_freq_hz} Hz sine + octave, {duration_seconds}s")
    report.kv("Output", output_file)
    report.kv("Metadata", metadata_file)
    report.blank()
    report.line("Demo carrier only. For provenance payload, see --watermark-embed.")
    print(report.render())


def cmd_ingest(source: str, project_path: str, author: str, via: str):
    try:
        from seif.context.ingest import ingest, describe_ingest
    except ImportError:
        print("Installation error: seif.context.ingest not found. Try: pip install --force-reinstall seif-cli")
        return
    result = ingest(source, project_path, author=author, via=via)
    print(describe_ingest(result))


def cmd_quality_gate(text: str, role: str):
    try:
        from seif.analysis.quality_gate import assess, describe_verdict
        verdict = assess(text, role=role)
        print(describe_verdict(verdict))
    except ImportError:
        # Minimal: stance-only (protocol public)
        from seif.analysis.stance_detector import analyze
        result = analyze(text)
        icon = {"GROUNDED": "🟢", "MIXED": "🟡", "DRIFT": "🔴"}.get(result.label, "⚪")
        print(f"{icon} [{role.upper()}] Stance: {result.label} | "
              f"Verifiable: {result.verifiable_ratio:.0%} "
              f"({result.verifiable_count}/{result.total_sentences} sentences)")
        if result.flagged_sentences:
            print(f"\n  Flagged:")
            for s in result.flagged_sentences[:3]:
                print(f"    - {s}")
        print(f"\n  Install seif-engine for full quality gate (grades A-F, hedging, resonance)")


def cmd_sync(repo_path: str, author: str, via: str, context_repo: str = None):
    try:
        from seif.context.git_context import sync_project, extract_git_context
    except ImportError:
        print("Installation error: seif.context.git_context not found. Try: pip install --force-reinstall seif-cli")
        return
    ctx = extract_git_context(repo_path)
    print(f"Repository:    {ctx.repo_name}")
    print(f"Branch:        {ctx.branch}")
    print(f"Commits:       {ctx.total_commits}")
    print(f"Contributors:  {len(ctx.contributors)}")
    if ctx.manifest_type:
        print(f"Manifest:      {ctx.manifest_type}")
    if ctx.hot_files:
        print(f"Hot files:     {ctx.hot_files[0][0]} ({ctx.hot_files[0][1]}x)")
    print()

    # Determine target path
    target = None
    if context_repo:
        from pathlib import Path
        ctx_path = Path(context_repo).resolve()
        target = str(ctx_path / "projects" / ctx.repo_name / "project.seif")
        # Update ref.json
        from seif.context.ref import create_ref, save_ref
        ref = create_ref(repo_path, str(ctx_path))
        save_ref(ref, Path(target).parent / "ref.json")

    module, path = sync_project(repo_path, author=author, via=via, target_path=target)
    print(f"Synced to:     {path}")
    print(f"  Version:     {module.version}")
    print(f"  Words:       {module.compressed_words}")
    print(f"  Hash:        {module.integrity_hash}")
    if module.parent_hash:
        print(f"  Parent:      {module.parent_hash}")

    # Auto-audit after sync (heal orphans, fix hashes)
    audit_target = context_repo or ".seif"
    try:
        from seif.context.autonomous import audit_context
        from pathlib import Path as _P
        if _P(audit_target).exists():
            result = audit_context(audit_target, fix=True, sync=False)
            if result.orphans_healed or result.ghosts_removed or result.hashes_fixed:
                print(f"\n  Auto-audit: {result.orphans_healed} orphans healed, "
                      f"{result.ghosts_removed} ghosts removed, "
                      f"{result.hashes_fixed} hashes fixed")
    except Exception:
        pass

    # Regenerate BOOT.md (static boot file for non-CLI AIs)
    try:
        from seif.context.workspace import generate_boot_md
        from pathlib import Path as _P
        boot_target = context_repo or ".seif"
        if _P(boot_target).exists():
            boot_path = generate_boot_md(boot_target)
            print(f"\n  Boot file:   {boot_path}")
    except Exception:
        pass

    # Verify Enoch seed resonance for alignment
    try:
        from seif.core.resonance_gate import verify_seed
        seed = "A Semente de Enoque"
        result = verify_seed(seed)
        if result["verified"]:
            print(f"\n  Enoch seed:  Aligned (sum={result['actual_sum']}, root={result['actual_root']}, phase={result['phase']})")
        else:
            print(f"\n  Enoch seed:  Misaligned (sum={result['actual_sum']}, root={result['actual_root']}, phase={result['phase']})")
    except Exception:
        pass


def cmd_contribute(module_path: str, text: str, author: str, via: str):
    try:
        from seif.context.context_manager import contribute_to_module
    except ImportError:
        print("Installation error: seif.context.context_manager not found. Try: pip install --force-reinstall seif-cli")
        return
    module, path = contribute_to_module(module_path, text, author, via)
    print(f"Contributed to: {path}")
    print(f"  Version:      {module.version}")
    print(f"  Contributors: {len(module.contributors)}")
    print(f"  Words:        {module.compressed_words}")
    print(f"  Hash:         {module.integrity_hash}")
    print(f"  Parent hash:  {module.parent_hash}")


def cmd_composite(text: str):
    *_, render_composite = _lazy_import_generators()
    path = render_composite(text)
    print(f"Mapa de Ressonância Completo salvo: {path}")


def cmd_encode(text: str):
    encode_phrase, describe_melody = _lazy_import_encoding()
    melody = encode_phrase(text)
    print(describe_melody(melody))


def cmd_constants(text: str):
    from seif.analysis.physical_constants import describe_signature
    from seif.core.resonance_gate import evaluate
    result = evaluate(text)
    print(result)
    print()
    print(describe_signature(result.digital_root))


def cmd_circuit(text: str):
    transcompile, _, _, _, _, _, _, generate_from_spec, render_svg, _ = _lazy_import_generators()
    spec = transcompile(text)
    layout = generate_from_spec(spec)
    path = render_svg(layout)
    print(f"Circuito SFA salvo: {path}")
    print(f"  Traces: {len(layout.traces)}, Pads: {len(layout.pads)}, Layers: {layout.layer_count}")


def cmd_handshake(model: str, full: bool = False):
    """Generate SEIF bootstrap prompt for a browser-based AI.

    --full adds operational context (mapper summary, recent decisions,
    pending observations, session history) for session convergence.
    """
    import json
    from pathlib import Path
    try:
        from seif.context.context_manager import build_startup_context
    except ImportError:
        _upgrade_message("--handshake", "Test SEIF protocol loading across AI backends.")
        return

    model = model.lower().strip()

    # Build KERNEL context
    ctx_repo = None
    for candidate in [".seif", "../.seif"]:
        if Path(candidate).exists():
            ctx_repo = candidate
            break

    startup = build_startup_context() if ctx_repo else ""

    # Load model-profile if exists
    profile_content = ""
    profile_paths = [
        Path(f"models/{model}.seif"),
        Path(f".seif/models/{model}.seif"),
    ]
    for p in profile_paths:
        if p.exists():
            try:
                data = json.loads(p.read_text())
                profile_content = data.get("summary", "")
            except (json.JSONDecodeError, OSError):
                pass
            break

    # Build the handshake prompt
    lines = [
        f"[SEIF] Bootstrap for {model}" + (" (full context)" if full else ""),
        "",
        "You are entering a SEIF protocol session.",
        "Protocol: https://github.com/and2carvalho/seif",
        "",
        "## Your Model-Profile",
        "",
    ]

    if profile_content:
        lines.append(profile_content)
    else:
        lines.append(f"(No profile found for '{model}'. You may create one during this session.)")

    lines.extend([
        "",
        "## Protocol Context",
        "",
    ])

    if startup:
        lines.append(startup[:4000])
    else:
        lines.append("(No .seif context found. Browse BOOT.md at the URL above.)")

    # --full: add operational context for session convergence
    if full and ctx_repo:
        ctx_path = Path(ctx_repo)
        lines.extend(["", "## Operational Context (--full)", ""])

        # Mapper summary: module count, pending observations, last session
        mapper_path = ctx_path / "mapper.json"
        if mapper_path.exists():
            try:
                mapper = json.loads(mapper_path.read_text())
                mod_count = len(mapper.get("modules", []))
                pending = mapper.get("pending_observations", [])
                last_session = mapper.get("last_session", "unknown")
                session_count = mapper.get("session_count", 0)
                lines.append(f"Mapper: {mod_count} modules, {session_count} sessions, last: {last_session}")
                if pending:
                    lines.append(f"Pending observations ({len(pending)}):")
                    for obs in pending[-5:]:  # last 5 to keep manageable
                        lines.append(f"  - {obs[:120]}")
            except (json.JSONDecodeError, OSError):
                pass

        # Recent decisions (most relevant for convergence)
        decisions_paths = sorted(ctx_path.glob("projects/*/decisions.seif"))
        for dp in decisions_paths[:2]:
            try:
                ddata = json.loads(dp.read_text())
                summary = ddata.get("summary", "")
                if summary:
                    # Take last 1500 chars of decisions (most recent)
                    lines.extend(["", f"## Recent Decisions ({dp.parent.name})", ""])
                    lines.append(summary[-1500:])
            except (json.JSONDecodeError, OSError):
                pass

        # Recent feedback
        feedback_paths = sorted(ctx_path.glob("projects/*/feedback.seif"))
        for fp in feedback_paths[:2]:
            try:
                fdata = json.loads(fp.read_text())
                summary = fdata.get("summary", "")
                if summary:
                    lines.extend(["", f"## Feedback ({fp.parent.name})", ""])
                    lines.append(summary[-800:])
            except (json.JSONDecodeError, OSError):
                pass

        # Active sessions
        session_paths = sorted(ctx_path.glob("sessions/*.seif"))
        if session_paths:
            lines.extend(["", "## Sessions", ""])
            for sp in session_paths[-3:]:
                try:
                    sdata = json.loads(sp.read_text())
                    name = sdata.get("session_name", sp.stem)
                    status = sdata.get("status", "unknown")
                    contribs = len(sdata.get("contributors", []))
                    lines.append(f"  - {name} [{status}] ({contribs} contributors)")
                except (json.JSONDecodeError, OSError):
                    pass

    lines.extend([
        "",
        "## Session Export",
        "",
        "At the end of this conversation, generate a session export as SEIF-MODULE-v2 JSON:",
        '  {"protocol": "SEIF-MODULE-v2", "source": "' + model + '-session/DATE",',
        '   "summary": "...", "verified_data": [...],',
        '   "integrity_hash": "SHA-256[:16] of summary",',
        '   "contributors": [{"author": "' + model + '", "via": "browser-chat", "action": "created"}],',
        '   "classification": "INTERNAL"}',
        "",
        "The human will save this as a .seif file and ingest it.",
    ])

    prompt = "\n".join(lines)

    print(prompt)
    print(f"\n--- ({len(prompt)} chars, ready to paste) ---")


def cmd_analyze_artifact(image_path: str):
    from seif.analysis.artifact_analyzer import analyze, describe as desc_art, generate_overlay
    from seif.analysis.pattern_comparator import self_compare
    geo = analyze(image_path)
    print(desc_art(geo))
    overlay = generate_overlay(image_path, geo)
    print(f"\nOverlay salvo: {overlay}")
    report = self_compare(geo)
    print()
    print(report)


def cmd_gate(text: str):
    result = evaluate(text)
    print(result)


def cmd_transcompile(text: str):
    transcompile, describe, *_ = _lazy_import_generators()
    spec = transcompile(text)
    print(describe(spec))


def cmd_glyph(text: str):
    transcompile, _, render, *_ = _lazy_import_generators()
    spec = transcompile(text)
    path = render(spec)
    print(f"Glifo salvo: {path}")


def cmd_audio(text: str):
    transcompile, _, _, _, render_audio, *_ = _lazy_import_generators()
    spec = transcompile(text)
    path = render_audio(spec)
    print(f"Áudio salvo: {path}")


def cmd_fractal(text: str):
    *_, generate_fractal_qr, describe_fqr, _, _, _ = _lazy_import_generators()
    from seif.generators.glyph_renderer import render_fractal_qr
    qr = generate_fractal_qr(text, max_depth=4)
    print(describe_fqr(qr))
    path = render_fractal_qr(qr)
    print(f"\nFractal QR salvo: {path}")


def cmd_all(text: str):
    transcompile, describe, render, _, render_audio, generate_fractal_qr, describe_fqr, generate_from_spec, render_svg, render_composite = _lazy_import_generators()
    from seif.generators.glyph_renderer import render_fractal_qr

    print("=" * 60)
    print("RPWP — Processamento Completo")
    print("=" * 60)
    print()

    result = evaluate(text)
    print(result)
    print()

    spec = transcompile(text)
    print(describe(spec))
    print()

    glyph_path = render(spec)
    print(f"Glifo salvo: {glyph_path}")

    audio_path = render_audio(spec)
    print(f"Áudio salvo: {audio_path}")

    qr = generate_fractal_qr(text, max_depth=4)
    print()
    print(describe_fqr(qr))
    qr_path = render_fractal_qr(qr)
    print(f"\nFractal QR salvo: {qr_path}")

    layout = generate_from_spec(spec)
    circuit_path = render_svg(layout)
    print(f"Circuito SFA salvo: {circuit_path}")

    composite_path = render_composite(text)
    print(f"Mapa de Ressonância Completo salvo: {composite_path}")

    print()
    print("=" * 60)
    print("Processamento completo.")


def cmd_consult(question: str, context_paths: list[str],
                force_backend: str, allow_confidential: bool,
                output: str, manual: bool = False,
                session_name: str = None, context_repo: str = None):
    """Intelligent inter-AI consultation with classification-aware routing.

    In manual mode: generates an optimized prompt for a specific AI,
    the user copies it to the AI's web chat, then pastes the response back.
    The protocol measures the response and optionally persists it.
    """
    import json
    try:
        from seif.bridge.ai_bridge import (
            send, detect_backends, build_safe_context, AIResponse,
        )
    except ImportError:
        _upgrade_message("", "Advanced feature — context management, multi-AI, or security.")
        return
    # ai_registry is optional (only needed for manual mode routing)
    try:
        from seif.bridge.ai_registry import (
            recommend_backends, recommend_any, describe_recommendation,
            build_optimized_prompt, AI_REGISTRY, PROMPT_STYLES,
        )
        _has_registry = True
    except ImportError:
        _has_registry = False
    from seif.analysis.quality_gate import assess

    backend_map = {
        "claude": "claude_cli", "gemini": "gemini_cli",
        "anthropic": "anthropic_api", "grok": "grok_api",
        "opencode": "opencode",
        "deepseek": "deepseek", "kimi": "kimi",
    }

    # === MANUAL MODE ===
    if manual:
        if not _has_registry:
            print("Manual mode requires seif.bridge.ai_registry (not yet implemented).")
            return
        # Recommend from ALL AIs (including manual-only)
        if force_backend:
            target_key = backend_map.get(force_backend, force_backend)
        else:
            ranked = recommend_any(question)
            target_key = ranked[0]

        profile = AI_REGISTRY.get(target_key)
        if not profile:
            print(f"Unknown AI: {target_key}")
            return

        # Build optimized prompt
        prompt = build_optimized_prompt(question, target_key,
                                        include_context=not allow_confidential)

        print(f"═══ MANUAL CONSULTATION — {profile.name} ═══")
        print(f"Strengths: {', '.join(profile.strengths[:4])}")
        if profile.chat_url:
            print(f"Open: {profile.chat_url}")
        print()
        print("─── COPY THIS PROMPT ───")
        print(prompt)
        print("─── END PROMPT ───")
        print()

        # Save prompt to file if --output
        if output:
            Path(output).write_text(prompt, encoding="utf-8")
            print(f"Prompt saved to: {output}")
            print()

        # Wait for user to paste response
        print("Paste the AI's response below (end with empty line + Ctrl-D or 'END'):")
        lines = []
        try:
            while True:
                line = input()
                if line.strip() == "END":
                    break
                lines.append(line)
        except EOFError:
            pass

        response_text = "\n".join(lines).strip()
        if not response_text:
            print("No response received.")
            return

        # Measure through quality gate
        verdict = assess(response_text[:1000], role="ai")
        print(f"\n═══ {profile.name} (manual) ═══")
        print(f"[Quality: {verdict.grade} | Stance: {verdict.status} | "
              f"Resonance: {verdict.triple_gate.status}]")

        # Auto-persist (requires explicit opt-in for API responses)
        try:
            from seif.context.autonomous import find_context_repo, load_config, persist_knowledge
            ctx_repo = find_context_repo()
            if ctx_repo:
                config = load_config(ctx_repo)
                if (config.get("autonomous_context")
                        and config.get("auto_persist_api_responses", False)
                        and verdict.grade in ("A", "B", "C")):
                    sealed = (
                        f"[Source: {profile.name.lower()} | Grade: {verdict.grade} "
                        f"| Stance: {verdict.status} | Unverified AI response]\n\n"
                        f"{response_text[:500]}"
                    )
                    persist_knowledge(
                        ctx_repo, project="seif", category="context",
                        content=sealed,
                        author=profile.name.lower(),
                        trigger=f"manual-consult: {question[:80]}",
                    )
                    print(f"[Persisted as .seif module (origin: {profile.name.lower()}, sealed)]")
        except Exception:
            pass
        return

    # === API MODE ===
    available = detect_backends()
    if not available:
        print("No API backends available. Use --manual for web chat consultation.")
        print("  seif --consult \"question\" --manual")
        return

    if force_backend:
        backend_key = backend_map.get(force_backend, force_backend)
        if backend_key not in available:
            # Suggest manual mode if backend has no API
            if _has_registry:
                profile = AI_REGISTRY.get(backend_key)
                if profile and profile.backend is None:
                    print(f"{profile.name} has no API backend. Use --manual mode:")
                    print(f"  seif --consult \"{question[:50]}...\" --to {force_backend} --manual")
                    return
            print(f"Error: backend '{force_backend}' not available.")
            print(f"Available: {', '.join(available)}")
            return
    elif _has_registry:
        ranked = recommend_backends(question, available)
        backend_key = ranked[0]
        routing = describe_recommendation(question, available)
        print(f"[Routing] {routing}")
    else:
        backend_key = list(available)[0]
        print(f"[Routing] Using first available backend: {backend_key}")

    # Build context (classification-filtered)
    max_cls = "CONFIDENTIAL" if allow_confidential else "INTERNAL"

    # Load explicit .seif module context (if provided)
    module_context = ""
    if context_paths:
        parts = []
        for path in context_paths:
            try:
                with open(path, encoding="utf-8") as f:
                    data = json.load(f)
                cls = data.get("classification", "INTERNAL")
                if cls == "CONFIDENTIAL" and not allow_confidential:
                    print(f"  Skipping {path} (CONFIDENTIAL — use --allow-confidential)")
                    continue
                summary = data.get("summary", "")
                source = data.get("source", path)
                parts.append(f"[MODULE: {source}]\n{summary}")
            except Exception as e:
                print(f"  Warning: could not load {path}: {e}")
        if parts:
            module_context = "\n\n---\n\n".join(parts) + "\n\n---\n\n"

    # Inject session context if --session-name provided
    session_context = ""
    if session_name:
        try:
            from seif.context.sessions import describe_session
            from seif.context.autonomous import find_context_repo
            ctx = context_repo or find_context_repo() or ".seif"
            session_ctx = describe_session(ctx, session_name)
            if session_ctx and "not found" not in session_ctx:
                # Take last N lines to respect context limits
                lines = session_ctx.split("\n")
                if len(lines) > 60:
                    lines = lines[:10] + ["...(truncated)..."] + lines[-50:]
                session_context = f"[SESSION: {session_name}]\n" + "\n".join(lines) + "\n\n---\n\n"
                print(f"[Session context injected: {session_name}]")
        except Exception as e:
            print(f"  Warning: could not load session {session_name}: {e}")

    message = f"{session_context}{module_context}{question}"

    print(f"\nConsulting {backend_key}...")
    response = send(message, backend=backend_key)

    if not response.success:
        print(f"Error ({response.backend}): {response.error}")
        return

    if output:
        Path(output).write_text(response.text, encoding="utf-8")
        print(f"Response saved to: {output}")
    else:
        print(f"\n═══ {response.backend} ({response.model}) ═══")
        print(response.text)

    verdict = assess(response.text[:1000], role="ai")
    print(f"\n[Quality: {verdict.grade} | Stance: {verdict.status} | "
          f"Resonance: {verdict.triple_gate.status}]")

    # Auto-persist if autonomous context is enabled AND auto_persist_api is true
    try:
        from seif.context.autonomous import find_context_repo, load_config, persist_knowledge
        ctx_repo = find_context_repo()
        if ctx_repo:
            config = load_config(ctx_repo)
            if (config.get("autonomous_context")
                    and config.get("auto_persist_api_responses", False)
                    and verdict.grade in ("A", "B", "C")):
                # Seal with provenance — AI responses are labeled, not trusted blindly
                sealed = (
                    f"[Source: {response.backend} | Grade: {verdict.grade} "
                    f"| Stance: {verdict.status} | Unverified AI response]\n\n"
                    f"{response.text[:500]}"
                )
                persist_knowledge(
                    ctx_repo, project="seif", category="context",
                    content=sealed,
                    author=response.backend,
                    trigger=f"consult: {question[:80]}",
                )
                print(f"[Persisted as .seif module (origin: {response.backend}, sealed)]")
    except Exception:
        pass  # persistence is optional

    # Auto-contribute to session if --session-name provided
    if session_name:
        try:
            from seif.context.sessions import contribute_to_session
            from seif.context.autonomous import find_context_repo
            ctx = context_repo or find_context_repo() or ".seif"
            summary = (
                f"[{response.backend}] Grade {verdict.grade}, Stance {verdict.status}. "
                f"{response.text[:300]}"
            )
            contribute_to_session(
                ctx, session_name, summary,
                author=response.backend,
                via="--consult",
                action="contributed",
            )
            print(f"[Contributed to session '{session_name}']")
        except Exception as e:
            print(f"  Warning: could not contribute to session: {e}")


def cmd_generate(output_dir: str, context_repo: str = None,
                 classification: str = "INTERNAL"):
    """Generate documentation from .seif context modules."""
    try:
        from seif.context.doc_generator import generate_docs
        from seif.context.autonomous import find_context_repo
    except ImportError:
        _upgrade_message("--generate", "Generate documentation from .seif context modules.")
        return

    ctx = context_repo or find_context_repo() or ".seif"
    if not Path(ctx).exists():
        print(f"No .seif/ found at {ctx}. Run seif --init first.")
        return

    print(f"Generating docs from {ctx}...")
    files = generate_docs(ctx, output_dir, max_classification=classification)

    if files:
        from seif.cli.resonance_display import ResonanceReport
        report = ResonanceReport("DOCS GENERATED")
        report.section("Files")
        for f in files:
            report.item(str(f))
        report.blank()
        report.line(f"{len(files)} files written to {output_dir}/")
        print(report.render())
    else:
        print("No modules found to generate docs from.")


def cmd_changelog(output: str, context_repo: str = None):
    """Generate CHANGELOG.md from decisions.seif."""
    try:
        from seif.context.doc_generator import generate_changelog
        from seif.context.autonomous import find_context_repo
    except ImportError:
        _upgrade_message("--changelog", "Generate CHANGELOG.md from decisions.seif history.")
        return

    ctx = context_repo or find_context_repo() or ".seif"
    if not Path(ctx).exists():
        print(f"No .seif/ found at {ctx}. Run seif --init first.")
        return

    text = generate_changelog(ctx, output=output)
    if output:
        print(f"Changelog written to {output}")
    else:
        print(text)


def cmd_scan(program: str, global_store: bool = False,
             max_depth: int = 2, output: str = None):
    """Scan a CLI program's --help and generate a .seif knowledge module."""
    try:
        from seif.context.cli_scanner import scan_program, capture_help
    except ImportError:
        _upgrade_message("--scan", "Scan a program's --help and generate a .seif knowledge module.")
        return

    # Quick check: can we run the program?
    help_text = capture_help(program)
    if not help_text:
        print(f"Error: could not capture --help from '{program}'.")
        print(f"Make sure the program is installed and accessible.")
        return

    print(f"Scanning {program}...")
    module, path = scan_program(
        program,
        max_depth=max_depth,
        target_path=output,
        global_store=global_store,
    )

    if module and path:
        from seif.cli.resonance_display import ResonanceReport
        report = ResonanceReport("SCAN COMPLETE")
        report.section("Result")
        report.kv("Program", program)
        report.kv("Help lines", f"{module.original_words} words")
        report.kv("Compressed", f"{module.compressed_words} words ({module.compression_ratio:.1f}:1)")
        report.kv("Saved to", path)
        report.kv("Classification", module.classification)

        # Show summary preview
        lines = module.summary.split("\n")
        flag_count = sum(1 for l in lines if l.strip().startswith("- `"))
        sub_count = sum(1 for l in lines if l.strip().startswith("#### "))
        report.kv("Flags found", flag_count)
        report.kv("Subcommands", sub_count)
        print(report.render())

        if global_store:
            print(f"\n[Global store: ~/.seif/tools/ — available to all AI sessions]")
        else:
            print(f"\n[Local store: .seif/ — available to this project's AI sessions]")

        # Update mapper if autonomous context is available
        try:
            from seif.context.autonomous import find_context_repo, load_config
            from seif.context.seif_io import locked_read_modify_write
            import json
            from datetime import datetime, timezone

            ctx_repo = find_context_repo()
            if ctx_repo:
                mapper_path = Path(ctx_repo) / "mapper.json"
                if mapper_path.exists():
                    def _add_scan_entry(data):
                        rel_path = str(path.relative_to(Path(ctx_repo)))
                        modules = data.get("modules", [])
                        # Deduplicate
                        modules = [m for m in modules if m.get("path") != rel_path]
                        modules.append({
                            "path": rel_path,
                            "category": "context",
                            "project": None,
                            "origin": "cli-scanner",
                            "relevance": 0.9,
                            "last_updated": datetime.now(timezone.utc).isoformat(),
                            "trigger": f"scan: {program}",
                            "word_count": module.compressed_words,
                            "integrity_hash": module.integrity_hash,
                            "classification": "PUBLIC",
                        })
                        data["modules"] = modules
                        return data

                    locked_read_modify_write(str(mapper_path), _add_scan_entry)
                    print(f"[Registered in mapper.json]")
        except Exception:
            pass  # mapper update is optional
    else:
        print(f"Failed to scan {program}.")


def cmd_adversarial(question: str, context_paths: list[str],
                    force_backend: str, allow_confidential: bool,
                    output: str, session_name: str = None,
                    context_repo: str = None):
    """Adversarial mirror: run same question WITH and WITHOUT protocol, compare.

    During protocol solidification phase, this mode sends the same question
    to two instances of the same model:
      A) WITH full SEIF context (KERNEL + modules)
      B) WITHOUT protocol (clean system prompt)

    The delta between A and B reveals where the protocol influences the response.
    Valid findings in B that aren't in A = protocol blind spots.
    Errors in B that A avoids = protocol adding value.
    """
    import json
    import difflib
    from datetime import datetime, timezone
    try:
        from seif.bridge.ai_bridge import (
            send, send_clean, detect_backends, AIResponse,
        )
    except ImportError:
        _upgrade_message("", "Advanced feature — context management, multi-AI, or security.")
        return
    try:
        from seif.bridge.ai_registry import (
            recommend_backends, describe_recommendation,
        )
        _has_registry = True
    except ImportError:
        _has_registry = False
    from seif.analysis.quality_gate import assess

    backend_map = {
        "claude": "claude_cli", "gemini": "gemini_cli",
        "anthropic": "anthropic_api", "grok": "grok_api",
        "opencode": "opencode",
    }

    # Resolve backend
    available = detect_backends()
    if not available:
        print("No API backends available.")
        return

    if force_backend:
        backend_key = backend_map.get(force_backend, force_backend)
        if backend_key not in available:
            print(f"Error: backend '{force_backend}' not available.")
            print(f"Available: {', '.join(available)}")
            return
    elif _has_registry:
        ranked = recommend_backends(question, available)
        backend_key = ranked[0]
    else:
        # Without registry, use first available backend
        backend_key = list(available)[0]

    # Build context for protocol version
    module_context = ""
    if context_paths:
        parts = []
        for path in context_paths:
            try:
                with open(path, encoding="utf-8") as f:
                    data = json.load(f)
                cls = data.get("classification", "INTERNAL")
                if cls == "CONFIDENTIAL" and not allow_confidential:
                    continue
                summary = data.get("summary", "")
                source = data.get("source", path)
                parts.append(f"[MODULE: {source}]\n{summary}")
            except Exception:
                pass
        if parts:
            module_context = "\n\n---\n\n".join(parts) + "\n\n---\n\n"

    message = f"{module_context}{question}" if module_context else question

    print(f"═══ ADVERSARIAL MIRROR ({backend_key}) ═══")
    print(f"Question: {question[:120]}")
    print()

    # A) WITH protocol
    print("  [A] WITH protocol...", end=" ", flush=True)
    resp_protocol = send(message, backend=backend_key)
    if resp_protocol.success:
        verdict_a = assess(resp_protocol.text[:1000], role="ai")
        print(f"{verdict_a.grade} ({verdict_a.status})")
    else:
        print(f"FAILED: {resp_protocol.error}")
        return

    # B) WITHOUT protocol (clean mirror)
    print("  [B] WITHOUT protocol (clean)...", end=" ", flush=True)
    resp_clean = send_clean(message, backend=backend_key)
    if resp_clean.success:
        verdict_b = assess(resp_clean.text[:1000], role="ai")
        print(f"{verdict_b.grade} ({verdict_b.status})")
    else:
        print(f"FAILED: {resp_clean.error}")
        return

    # Compare
    text_a = resp_protocol.text[:2000].lower()
    text_b = resp_clean.text[:2000].lower()
    similarity = difflib.SequenceMatcher(None,
        _normalize_for_similarity(text_a),
        _normalize_for_similarity(text_b),
    ).ratio()

    # Build delta analysis
    grade_delta = ord(verdict_b.grade) - ord(verdict_a.grade)  # positive = B is worse
    stance_match = verdict_a.status == verdict_b.status

    result = {
        "question": question,
        "backend": backend_key,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "protocol_response": {
            "text": resp_protocol.text,
            "quality": {
                "grade": verdict_a.grade,
                "stance": verdict_a.status,
                "score": round(verdict_a.score, 3),
            },
        },
        "clean_response": {
            "text": resp_clean.text,
            "quality": {
                "grade": verdict_b.grade,
                "stance": verdict_b.status,
                "score": round(verdict_b.score, 3),
            },
        },
        "delta": {
            "text_similarity": round(similarity, 3),
            "grade_delta": grade_delta,
            "stance_agreement": stance_match,
            "protocol_influence": "HIGH" if similarity < 0.3 else "MEDIUM" if similarity < 0.6 else "LOW",
        },
        "interpretation": {
            "note": (
                "HIGH influence = protocol significantly changed the response. "
                "Check if the change adds value (grounding) or bias (drift). "
                "LOW influence = response is similar regardless of protocol."
            ),
        },
    }

    # Output
    if output and output.endswith(".json"):
        Path(output).write_text(json.dumps(result, indent=2, ensure_ascii=False),
                                encoding="utf-8")
        print(f"\nFull results saved to: {output}")

    # Human-readable report
    print(f"\n{'─' * 60}")
    print(f"═══ RESPONSE A (WITH protocol) ═══")
    print(f"[Grade: {verdict_a.grade} | Stance: {verdict_a.status} | Score: {verdict_a.score:.3f}]")
    preview_a = resp_protocol.text[:300].replace("\n", " ")
    print(f"{preview_a}...")

    print(f"\n═══ RESPONSE B (WITHOUT protocol — clean mirror) ═══")
    print(f"[Grade: {verdict_b.grade} | Stance: {verdict_b.status} | Score: {verdict_b.score:.3f}]")
    preview_b = resp_clean.text[:300].replace("\n", " ")
    print(f"{preview_b}...")

    print(f"\n{'─' * 60}")
    print(f"═══ DELTA ANALYSIS ═══")
    print(f"Text similarity:     {similarity:.3f}")
    print(f"Grade delta:         {grade_delta:+d} (positive = clean is worse)")
    print(f"Stance agreement:    {'YES' if stance_match else 'NO'}")
    print(f"Protocol influence:  {result['delta']['protocol_influence']}")

    if grade_delta > 0:
        print(f"\n  Protocol IMPROVED quality by {grade_delta} grade(s).")
    elif grade_delta < 0:
        print(f"\n  Clean response scored {-grade_delta} grade(s) HIGHER. Investigate protocol bias.")
    else:
        print(f"\n  Same grade. Check content differences for qualitative insights.")

    if not stance_match:
        print(f"  Stance divergence: protocol={verdict_a.status}, clean={verdict_b.status}")
        print(f"  This may indicate the protocol is shifting the response posture.")

    # Auto-persist if autonomous context is enabled
    try:
        from seif.context.autonomous import find_context_repo, load_config, persist_knowledge
        ctx_repo = find_context_repo()
        if ctx_repo:
            config = load_config(ctx_repo)
            if config.get("autonomous_context"):
                summary = (
                    f"Adversarial mirror ({backend_key}): "
                    f"protocol={verdict_a.grade}/{verdict_a.status}, "
                    f"clean={verdict_b.grade}/{verdict_b.status}, "
                    f"similarity={similarity:.3f}, "
                    f"influence={result['delta']['protocol_influence']}. "
                    f"Question: {question[:100]}"
                )
                persist_knowledge(
                    ctx_repo, project="seif", category="feedback",
                    content=summary,
                    author=f"adversarial-mirror-{backend_key}",
                    trigger=f"adversarial: {question[:60]}",
                )
                print(f"\n[Persisted adversarial result to .seif/feedback]")
    except Exception:
        pass


def cmd_watermark_embed(text: str, input_wav: str, output_wav: str,
                        repetitions: int, symbol_duration: float,
                        amplitude: float, fingerprint_of: str | None = None):
    """Embed text (or sha256 of FILE via fingerprint_of) as infrasound watermark."""
    from seif.generators.watermark import (
        WatermarkConfig, embed_watermark_wav, file_sha256_hex,
    )

    payload_source = "text"
    if fingerprint_of:
        text = file_sha256_hex(fingerprint_of)
        payload_source = f"sha256({fingerprint_of})"

    config = WatermarkConfig(
        repetitions=repetitions,
        symbol_duration=symbol_duration,
        amplitude=amplitude,
    )
    meta = embed_watermark_wav(text, input_wav, output_wav, config)

    print("SEIF WATERMARK EMBEDDED")
    print(f"  Payload:     \"{meta['text']}\"")
    print(f"  Source:      {payload_source}")
    print(f"  Symbols:     {meta['symbols']}")
    print(f"  Repetitions: {meta['repetitions']}")
    print(f"  Duration:    {meta['duration_seconds']:.1f}s watermark in {meta['carrier_duration']:.1f}s carrier")
    print(f"  Band:        {meta['freq_band_hz'][0]:.2f}-{meta['freq_band_hz'][1]:.2f} Hz")
    print(f"  Output:      {meta['output_path']}")
    print()
    print("Default tones are sub-20 Hz (inaudible). Larger spacing/alphabet may exceed.")


def cmd_watermark_extract(input_wav: str, n_symbols: int,
                          repetitions: int, symbol_duration: float,
                          against: str | None = None):
    """Extract infrasound watermark; if `against` given, verify match against sha256(against)."""
    from seif.generators.watermark import (
        WatermarkConfig, extract_watermark_wav, file_sha256_hex,
    )

    config = WatermarkConfig(
        repetitions=repetitions,
        symbol_duration=symbol_duration,
    )
    extracted = extract_watermark_wav(input_wav, n_symbols, config)

    print("SEIF WATERMARK EXTRACTED")
    print(f"  Payload:  \"{extracted}\"")
    print(f"  Symbols:  {n_symbols}")
    print(f"  Reps:     {repetitions}")
    print(f"  Source:   {input_wav}")

    if against:
        expected = file_sha256_hex(against)
        print()
        print("VERIFY")
        print(f"  Expected: \"{expected}\"  (sha256 of {against})")
        if extracted == expected:
            print("  Status:   VALID — extracted payload matches sha256 of --against file")
            return
        print("  Status:   INVALID — extracted payload does NOT match sha256 of --against file")
        import sys as _sys
        _sys.exit(1)


def _resolve_log_url(args) -> str:
    """Pick log URL from --log-url > $SEIF_LOG_URL > default."""
    import os
    return (
        getattr(args, "log_url", None)
        or os.environ.get("SEIF_LOG_URL")
        or "http://localhost:8000"
    )


def _cmd_log_submit(args) -> None:
    """Dispatch for `seif --log-submit FILE`."""
    try:
        from seif.log.identity import ensure_identity
        from seif.log.client import submit_file, LogHTTPError, LogClientError
    except ImportError as e:
        print(f"Error: missing [log] extra. Install with `pip install seif-cli[log]`.")
        print(f"  underlying: {e}")
        return

    file_path = args.log_submit
    from pathlib import Path
    if not Path(file_path).is_file():
        print(f"Error: not a file: {file_path}")
        return

    identity = ensure_identity(args.log_identity)
    try:
        resp = submit_file(
            identity,
            file_path,
            entry_type=args.log_entry_type,
            classification_ceil=args.log_classification,
            workspace_fingerprint=args.log_workspace_fingerprint,
            log_url=_resolve_log_url(args),
        )
    except LogHTTPError as e:
        print(f"Error: log server returned HTTP {e.status} — {e.detail}")
        return
    except LogClientError as e:
        print(f"Error: {e}")
        return

    print("╔══ SEIF LOG SUBMIT ════════════════════════════════╗")
    print(f"  File          : {file_path}")
    print(f"  Identity      : {identity.name}")
    print(f"  Entry id      : {resp['id']}")
    print(f"  Tenant id     : {resp['tenant_id']}")
    print(f"  Sequence      : {resp['sequence']}")
    print(f"  canonical_sha : {resp['canonical_sha256']}")
    print(f"  Submitted at  : {resp['submitted_at']}")
    print("╚═══════════════════════════════════════════════════╝")


def _cmd_log_verify(args) -> None:
    """Dispatch for `seif --log-verify ENTRY_ID`."""
    try:
        from seif.log.identity import ensure_identity
        from seif.log.client import verify_entry, LogHTTPError, LogClientError
    except ImportError as e:
        print(f"Error: missing [log] extra. Install with `pip install seif-cli[log]`.")
        print(f"  underlying: {e}")
        return

    identity = ensure_identity(args.log_identity)
    try:
        resp = verify_entry(
            identity,
            args.log_verify,
            log_url=_resolve_log_url(args),
        )
    except LogHTTPError as e:
        print(f"Error: log server returned HTTP {e.status} — {e.detail}")
        return
    except LogClientError as e:
        print(f"Error: {e}")
        return

    print("╔══ SEIF LOG VERIFY ════════════════════════════════╗")
    print(f"  Entry id      : {resp['id']}")
    print(f"  Tenant id     : {resp['tenant_id']}")
    print(f"  Sequence      : {resp['sequence']}")
    print(f"  Entry type    : {resp['entry_type']}")
    print(f"  canonical_sha : {resp['canonical_sha256']}")
    print(f"  primary_sha   : {resp.get('primary_content_sha256') or '(none)'}")
    print(f"  Workspace fp  : {resp.get('workspace_fingerprint') or '(none)'}")
    print(f"  classification: {resp['classification_ceil']}")
    print(f"  Submitted at  : {resp['submitted_at']}")
    print(f"  Ingest source : {resp['ingest_source']}")
    print("╚═══════════════════════════════════════════════════╝")


def _cmd_log_list(args) -> None:
    """Dispatch for `seif --log-list`."""
    try:
        from seif.log.identity import ensure_identity
        from seif.log.client import list_entries, LogHTTPError, LogClientError
    except ImportError as e:
        print(f"Error: missing [log] extra. Install with `pip install seif-cli[log]`.")
        print(f"  underlying: {e}")
        return

    identity = ensure_identity(args.log_identity)
    try:
        resp = list_entries(
            identity,
            after_id=args.log_after_id,
            limit=args.log_limit,
            workspace_fingerprint=args.log_workspace_fingerprint,
            log_url=_resolve_log_url(args),
        )
    except LogHTTPError as e:
        print(f"Error: log server returned HTTP {e.status} — {e.detail}")
        return
    except LogClientError as e:
        print(f"Error: {e}")
        return

    entries = resp.get("entries", [])
    next_cursor = resp.get("next_cursor")
    has_more = resp.get("has_more", False)

    print("╔══ SEIF LOG LIST ══════════════════════════════════╗")
    print(f"  Identity      : {identity.name}")
    print(f"  Page size     : {args.log_limit}  (default 20, max 200)")
    if args.log_after_id:
        print(f"  After id      : {args.log_after_id}")
    if args.log_workspace_fingerprint:
        print(f"  Filter wsfp   : {args.log_workspace_fingerprint}")
    print(f"  Returned      : {len(entries)}  (has_more: {'yes' if has_more else 'no'})")
    print("╠═══════════════════════════════════════════════════╣")
    if not entries:
        print("  (no entries)")
    else:
        for e in entries:
            ws_fp = e.get("workspace_fingerprint") or "—"
            sha_short = e["canonical_sha256"][:16]
            print(
                f"  #{e['sequence']:<4d}  "
                f"{e['id'][:8]}…  "
                f"{e['entry_type']:<24s}  "
                f"sha:{sha_short}…  "
                f"ws:{ws_fp[:12]}"
            )
    print("╠═══════════════════════════════════════════════════╣")
    if has_more and next_cursor:
        print(f"  Next page : seif --log-list --log-after-id {next_cursor}")
    else:
        print("  Next page : (none — final page)")
    print("╚═══════════════════════════════════════════════════╝")


def cmd_streaming_start(
    session_id: str,
    audio_interval: int,
    text_interval: int,
    max_embeddings: int,
    identity_file: str
):
    """Start a streaming watermark session."""
    try:
        from seif.generators.streaming_watermark import StreamingWatermarker
    except ImportError:
        print("Streaming watermark module not available. Install with: pip install seif-cli[generators]")
        return
    try:
        from seif.identity_block import parse_identity_block
    except ImportError:
        _upgrade_message("", "Advanced feature — context management, multi-AI, or security.")
        return
    import json

    identity_block = None
    if identity_file:
        try:
            with open(identity_file, 'r') as f:
                data = json.load(f)
            identity_block = parse_identity_block(data)
        except Exception as e:
            print(f"Warning: Could not load identity file: {e}")

    marker = StreamingWatermarker(
        session_id=session_id if session_id else None,
        audio_interval=audio_interval,
        text_interval=text_interval,
        max_embeddings=max_embeddings
    )

    state = marker.get_session_state()
    print(f"═══ SEIF STREAMING SESSION STARTED ═══")
    print(f"  Session ID:  {state['session_id']}")
    print(f"  Audio interval: {audio_interval}s")
    print(f"  Text interval:  {text_interval}s")
    print(f"  Max embeddings: {max_embeddings}")
    print(f"  State file:   {state['state_file']}")
    print()
    print("Use --streaming-status to monitor, --streaming-stop to end.")


def cmd_streaming_status(session_id: str):
    """Show status of a streaming session."""
    try:
        from seif.generators.streaming_watermark import StreamingWatermarker, STREAMING_DIR
    except ImportError:
        print("Streaming watermark module not available. Install with: pip install seif-cli[generators]")
        return

    if not session_id:
        print("Error: --streaming-session required")
        return

    path = STREAMING_DIR / f"{session_id}.state"
    if not path.exists():
        print(f"Session not found: {session_id}")
        return

    marker = StreamingWatermarker(session_id=session_id)
    state = marker.get_session_state()

    print(f"═══ SEIF STREAMING SESSION ═══")
    print(f"  Session ID:        {state['session_id']}")
    print(f"  Elapsed:           {state['elapsed_seconds']:.1f}s")
    print(f"  Full embeddings:   {state['embed_count']}")
    print(f"  Mini markers:     {state['mini_count']}")
    print(f"  Last full:        {state['last_embed_seconds_ago']:.1f}s ago")
    print(f"  Last mini:        {state['last_mini_seconds_ago']:.1f}s ago")
    print(f"  Paused:           {state['is_paused']}")
    print(f"  Trail hash:       {state['trail_hash']}")


def cmd_streaming_list():
    """List all active streaming sessions."""
    try:
        from seif.generators.streaming_watermark import StreamingWatermarker
    except ImportError:
        print("Streaming watermark module not available. Install with: pip install seif-cli[generators]")
        return

    sessions = StreamingWatermarker.list_sessions()

    if not sessions:
        print("No active streaming sessions.")
        return

    print(f"═══ SEIF STREAMING SESSIONS ({len(sessions)}) ═══")
    for s in sessions:
        from datetime import datetime
        start = datetime.fromtimestamp(s['start_time']).strftime('%Y-%m-%d %H:%M:%S')
        print(f"  {s['session_id']}")
        print(f"    Started: {start}")
        print(f"    Embeds: {s['embed_count']} full, {s['mini_count']} mini")


def cmd_streaming_stop(session_id: str):
    """Stop/end a streaming session."""
    try:
        from seif.generators.streaming_watermark import StreamingWatermarker
    except ImportError:
        print("Streaming watermark module not available. Install with: pip install seif-cli[generators]")
        return

    if not session_id:
        print("Error: --streaming-session required")
        return

    marker = StreamingWatermarker(session_id=session_id)
    state = marker.get_session_state()

    print(f"═══ SEIF STREAMING SESSION ENDED ═══")
    print(f"  Session ID:  {state['session_id']}")
    print(f"  Total time: {state['elapsed_seconds']:.1f}s")
    print(f"  Full embeddings: {state['embed_count']}")
    print(f"  Mini markers: {state['mini_count']}")

    marker.cleanup()
    print(f"  State file removed.")


def cmd_boot_check(
    backends: list[str],
    core_file: str,
    max_parallel: int,
    auto: bool,
    all_backends: bool
):
    """Run boot check across multiple LLMs in parallel."""
    try:
        from seif.bridge.boot_check import (
            run_boot_check, describe_result, auto_detect_backends
        )
    except ImportError:
        _upgrade_message("--boot-check", "Verify SEIF protocol loads correctly across multiple LLMs.")
        return

    if not backends and not auto and not all_backends:
        print("Error: specify --boot-to backends, --boot-auto, or --boot-all")
        return

    if auto or all_backends:
        available = auto_detect_backends()
        if not available:
            print("No backends available. Set API keys or install CLI tools.")
            return
        backends = available if all_backends else available[:3]
        print(f"Auto-detected backends: {', '.join(backends)}")
        print()

    if not backends:
        print("No backends to check.")
        return

    core_path = core_file or "seif-core-v3.2.seif"

    print(f"Running boot check on {len(backends)} backend(s)...")
    print()

    result = run_boot_check(
        backends=backends,
        core_file=core_path,
        max_parallel=max_parallel
    )

    print(describe_result(result))


def cmd_security(args):
    """Run security assessment (Red/Blue team)."""
    try:
        from seif.context.autonomous import find_context_repo
    except ImportError:
        _upgrade_message("--security", "Run Red/Blue team security assessment on your .seif context.")
        return
    ctx = args.context_repo or find_context_repo() or ".seif"
    action = args.security

    if action == "baseline":
        # Show current baseline
        from pathlib import Path
        import json
        bp = Path(ctx) / "modules" / "security_baseline.seif"
        if bp.exists():
            with open(bp) as f:
                data = json.load(f)
            print("═══ SEIF SECURITY BASELINE ═══\n")
            print(data.get("summary", "(no summary)"))
            print(f"\nClassification: {data.get('classification')}")
            print(f"Hash: {data.get('integrity_hash')}")
            print(f"Version: {data.get('version')}")
        else:
            print(f"No security_baseline.seif found at {bp}")
        return

    try:
        from seif.bridge.local_proxy import classify_input
    except ImportError:
        _upgrade_message("--security", "Run Red/Blue team security assessment on your .seif context.")
        return

    if action == "red":
        try:
            from seif_engine.security.redblue import red_team_test
        except ImportError:
            _upgrade_message("--security", "Run Red/Blue team security assessment on your .seif context.")
            return
        print("═══ SEIF RED TEAM ═══\n")
        report = red_team_test(classify_input)
        print(f"  Tests:           {report.total_tests}")
        print(f"  Passed:          {report.passed}")
        print(f"  Failed:          {report.failed}")
        print(f"  False negatives: {report.false_negatives} (secrets leaked)")
        print(f"  False positives: {report.false_positives} (legitimate blocked)")
        print(f"  Bypass rate:     {report.bypass_rate:.1%}")
        print(f"  Grade:           {report.grade()}")
        print()
        if report.failed > 0:
            print("  Failed tests:")
            for r in report.results:
                if not r.passed:
                    tag = "FN" if r.false_negative else "FP"
                    print(f"    [{tag}] {r.description}: expected {r.expected}, got {r.actual}")
        return

    if action == "blue":
        try:
            from seif_engine.security.redblue import blue_team_audit
        except ImportError:
            _upgrade_message("--security", "Run Red/Blue team security assessment on your .seif context.")
            return
        print("═══ SEIF BLUE TEAM ═══\n")
        audit = blue_team_audit(ctx)
        print(f"  Modules audited:     {audit.modules_audited}")
        print(f"  Classification OK:   {audit.classification_compliant}")
        print(f"  Hash valid:          {audit.hash_valid}")
        print(f"  Provenance complete: {audit.provenance_complete}")
        print(f"  CONFIDENTIAL:        {audit.confidential_modules} ({audit.confidential_with_approval} approved)")
        print(f"  Compliance:          {audit.compliance_score:.1%}")
        print(f"  Grade:               {audit.grade()}")
        if audit.issues:
            print(f"\n  Issues ({len(audit.issues)}):")
            for issue in audit.issues:
                print(f"    - {issue}")
        return

    # Default: full score
    try:
        from seif_engine.security.redblue import run_full_assessment
    except ImportError:
        _upgrade_message("--security", "Run Red/Blue team security assessment on your .seif context.")
        return
    print("═══ SEIF SECURITY ASSESSMENT ═══\n")
    score = run_full_assessment(classify_input, ctx, persist=True)
    print(f"  Red Team:        {score.red_grade} (bypass: {score.red_bypass_rate:.1%})")
    print(f"  Blue Team:       {score.blue_grade} (compliance: {score.blue_compliance:.1%})")
    print(f"  Combined:        {score.combined_grade}")
    print(f"  Posture score:   {score.posture_score:.2f}")
    print(f"  zeta effective:  {score.zeta_effective:.3f} (theoretical: 0.612)")
    print()
    if score.recommendations:
        print("  Recommendations:")
        for rec in score.recommendations:
            print(f"    - {rec}")
    print()
    print(f"  Results persisted to security_baseline.seif")


def cmd_proxy(args):
    """Manage the local LLM proxy (data sovereignty layer)."""
    try:
        from seif.bridge.local_proxy import status, classify_input, _ollama_pull
    except ImportError:
        _upgrade_message("--proxy", "Manage local LLM proxy for data sovereignty (Ollama).")
        return

    if args.proxy_test:
        # Test classification of specific text
        print("═══ SEIF LOCAL PROXY — Classification Test ═══\n")
        result = classify_input(args.proxy_test, model=args.proxy_model)
        print(f"  Classification: {result['classification']}")
        print(f"  Summary:        {result['summary']}")
        if result['confidential_fields']:
            print(f"  Redacted:       {', '.join(result['confidential_fields'])}")
        print(f"\n  Safe protocol message:")
        print(f"  {result['safe_protocol'][:500]}")
        return

    action = args.proxy or "status"

    if action == "status":
        print("═══ SEIF LOCAL PROXY — Status ═══\n")
        s = status()
        print(f"  Ollama:          {'ONLINE' if s['ollama_available'] else 'OFFLINE'}")
        print(f"  Host:            {s['ollama_host']}")
        print(f"  Default model:   {s['default_model']}")
        print(f"  Model ready:     {'YES' if s['model_ready'] else 'NO'}")
        print(f"  Proxy mode:      {s['proxy_mode']}")
        if s['installed_models']:
            print(f"  Installed:       {', '.join(s['installed_models'])}")
        print()
        if s['proxy_mode'] == 'active':
            print("  Data sovereignty: ACTIVE")
            print("  Raw user input never leaves this machine.")
            print("  External APIs receive only SEIF protocol data.")
        else:
            print("  Data sovereignty: FALLBACK (rule-based)")
            print("  Start Ollama: make up (Docker) or ollama serve")

    elif action == "pull":
        model = args.proxy_model or None
        print(f"Pulling model {model or 'default'}...")
        if _ollama_pull(model):
            print("Model ready.")
        else:
            print("Failed to pull model. Is Ollama running?")

    elif action == "test":
        # Interactive test: classify a sample message
        test_msgs = [
            ("PUBLIC", "What is the golden ratio?"),
            ("INTERNAL", "We decided to use PostgreSQL for the session store"),
            ("CONFIDENTIAL", "My API key is sk-abc123def456 and password is hunter2"),
        ]
        print("═══ SEIF LOCAL PROXY — Classification Test ═══\n")
        for expected, msg in test_msgs:
            result = classify_input(msg, model=args.proxy_model)
            match = "OK" if result['classification'] == expected else "MISMATCH"
            print(f"  [{match}] Expected: {expected:14s} Got: {result['classification']:14s}")
            print(f"        Input:    {msg[:60]}")
            if result['confidential_fields']:
                print(f"        Redacted: {result['confidential_fields']}")
            print()


def cmd_dia_skill():
    """Generate Dia browser skill prompt from current nucleus context."""
    try:
        from seif.context.nucleus import load_profile, load_sources
    except ImportError:
        _upgrade_message("--dia-skill", "Browser-AI bridge via Dia integration.")
        return
    from seif.data.paths import get_user_home
    import json

    profile = load_profile()
    sources = load_sources()
    home = get_user_home()

    # Gather metadata
    tools = []
    tools_dir = home / "tools"
    if tools_dir.exists():
        for f in sorted(tools_dir.glob("*.seif")):
            name = f.stem.replace("__cli-scanned_", "").replace("_", " ").strip()
            tools.append(name)

    projects = []
    extracts_dir = home / "extracts"
    if extracts_dir.exists():
        for f in sorted(extracts_dir.glob("*.seif")):
            try:
                with open(f) as fh:
                    data = json.load(fh)
                name = data.get("name", f.stem).replace("extract_", "")
                meta = data.get("metadata", {})
                ft = meta.get("file_types", [])
                projects.append(f"{name} ({', '.join(ft[:3])})")
            except (json.JSONDecodeError, OSError):
                pass

    deps_count = len(list((home / "deps").glob("*.seif"))) if (home / "deps").exists() else 0

    # Build prompt
    name = profile.get("name", "User")
    lang = profile.get("language", "en")
    github = profile.get("github_username", "")
    lang_name = "Portuguese" if lang == "pt_br" else "English"

    prompt = f"""You are a SEIF-aware assistant. The user has a personal context nucleus.

User: {name}
Language: {lang_name}
GitHub: {github}
Tools installed: {', '.join(tools[:20])}
Projects: {', '.join(projects[:10])}
Dependency manifests: {deps_count} projects
Sources: {len(sources)} GitHub repos

SEIF (S.E.I.F.) is a context management framework (pip install seif-cli) that compresses project knowledge into portable .seif modules with integrity hashes, Ed25519 signatures, and provenance chains.
DOI: 10.5281/zenodo.19344678 | License: CC BY-NC-SA 4.0

When the user asks about their projects, tools, or machine context, use this knowledge.
Always respond in {lang_name}. Be concise.

Key SEIF commands: seif --init, seif --sync, seif --quality-gate, seif chat, seif serve, seif --extract"""

    print("=" * 60)
    print("DIA SKILL: /seif")
    print("=" * 60)
    print()
    print("Create this skill in Dia: Skills Gallery → Create Skill")
    print(f"Name: seif")
    print()
    print("--- COPY PROMPT BELOW ---")
    print()
    print(prompt)
    print()
    print("--- END PROMPT ---")
    print()
    print(f"Context: {len(tools)} tools, {len(projects)} projects, {deps_count} deps")
    print(f"Language: {lang_name}")
    print()

    # Also copy to clipboard if possible
    try:
        import subprocess
        subprocess.run(["pbcopy"], input=prompt.encode(), check=True)
        print("(Copied to clipboard)")
    except Exception:
        pass


def _print_workspace_attribution(target_path: Path) -> None:
    """Print resolved-path attribution for FS-side-effect commands.

    Surfaces symlink redirection (e.g., per-project .seif → shared admin
    store) so the operator can never be uncertain which workspace was
    actually written to. Closes init-tool-workspace-disambiguation.
    """
    try:
        target_path = Path(target_path)
        absolute = target_path.absolute()
        resolved = target_path.resolve() if target_path.exists() else absolute
        if resolved != absolute:
            print(f"  [SEIF] Target: {absolute} → {resolved}")
        else:
            print(f"  [SEIF] Target: {absolute}")
    except Exception:
        pass


def cmd_stamp(file_path: str, force: bool = False):
    """Timestamp a .seif module with OpenTimestamps."""
    from seif.core.timestamping import stamp
    _print_workspace_attribution(Path(file_path))
    ok, msg = stamp(Path(file_path), force=force)
    print(f"  {'OK' if ok else 'FAILED'}: {msg}")


def cmd_verify_stamp(file_path: str):
    """Verify OTS proof against Bitcoin blockchain."""
    from seif.core.timestamping import verify
    _print_workspace_attribution(Path(file_path))
    ok, msg = verify(Path(file_path))
    if ok:
        print(f"  VERIFIED: {msg}")
    else:
        print(f"  FAILED: {msg}")


def cmd_stamp_all(directory: str):
    """Timestamp all .seif modules in a directory."""
    import sys as _sys
    from seif.core.timestamping import stamp_directory
    print("[WARN] --stamp-all anchors current bytes. Any subsequent "
          "--fingerprint-update or --sign-all will invalidate these proofs. "
          "Run --integrity-update for the atomic chain.", file=_sys.stderr)
    _print_workspace_attribution(Path(directory))
    results = stamp_directory(Path(directory))
    stamped = sum(1 for r in results if r["status"] == "stamped")
    existing = sum(1 for r in results if r["status"] == "already stamped")
    failed = sum(1 for r in results if r["status"] == "failed")
    print(f"  Stamped: {stamped} | Already: {existing} | Failed: {failed}")
    for r in results:
        if r["status"] == "failed":
            print(f"    {r['file']}: {r.get('message', '')}")


def cmd_keygen(force: bool = False):
    """Generate Ed25519 signing keypair."""
    from seif.core.signing import keygen, get_public_key_fingerprint, get_public_key_base64

    try:
        priv_path, pub_path = keygen(force=force)
        fp = get_public_key_fingerprint()
        pub_b64 = get_public_key_base64()
        print(f"Keypair generated:")
        print(f"  Private: {priv_path}")
        print(f"  Public:  {pub_path}")
        print(f"  Fingerprint: {fp}")
        print(f"\nPublic key (base64): {pub_b64}")
        print(f"\nAdd to your profile: seif --profile show")
        print(f"Share the fingerprint — keep the private key safe.")
    except ImportError:
        print("Error: cryptography package required. Install: pip install cryptography")
    except FileExistsError as e:
        print(str(e))


def cmd_sign(module_path: str):
    """Sign a .seif module."""
    from seif.core.signing import sign_module, get_public_key_fingerprint

    try:
        module = sign_module(Path(module_path))
        fp = module.get("signature", {}).get("key_fingerprint", "")
        fingerprint_block = module.get("fingerprint")
        fp_value = (
            fingerprint_block.get("value") if isinstance(fingerprint_block, dict) else None
        )
        signed_hash = fp_value or module.get("integrity_hash", "")
        print(f"Signed: {module_path}")
        print(f"  Key fingerprint: {fp}")
        print(f"  Hash signed: {signed_hash}")
    except ImportError:
        print("Error: cryptography package required. Install: pip install cryptography")
    except FileNotFoundError as e:
        print(str(e))
    except Exception as e:
        print(f"Error: {e}")


def cmd_verify(module_path: str):
    """Verify signature of a .seif module."""
    from seif.core.signing import verify_module

    try:
        result = verify_module(Path(module_path))
        if result["valid"]:
            print(f"VALID: {module_path}")
            print(f"  Key fingerprint: {result['key_fingerprint']}")
        else:
            print(f"INVALID: {module_path}")
            print(f"  Reason: {result['reason']}")
    except ImportError:
        print("Error: cryptography package required. Install: pip install cryptography")
    except Exception as e:
        print(f"Error: {e}")


def cmd_sign_resonance(resonance_path: str):
    """Sign RESONANCE.json with the Owner's private key (A22 — must run on Owner machine)."""
    from seif.core.sign_resonance import sign_resonance

    try:
        doc = sign_resonance(Path(resonance_path))
        sig = doc["cryptographic_identity"]["content_signature"]
        print(f"Signed: {resonance_path}")
        print(f"  Algorithm: {sig['algorithm']}")
        print(f"  Key fingerprint: {sig['key_fingerprint']}")
        print(f"  Canonical hash: {sig['canonical_hash']}")
        print(f"  Signed at: {sig['signed_at']}")
    except ImportError:
        print("Error: cryptography package required. Install: pip install cryptography")
    except FileNotFoundError as e:
        print(str(e))
    except Exception as e:
        print(f"Error: {e}")


def cmd_verify_resonance(resonance_path: str):
    """Verify the content_signature on RESONANCE.json."""
    from seif.core.sign_resonance import verify_resonance_signature

    try:
        result = verify_resonance_signature(Path(resonance_path))
        if result["valid"]:
            print(f"VALID: {resonance_path}")
            print(f"  Key fingerprint: {result['key_fingerprint']}")
            print(f"  Canonical hash match: {result['canonical_hash_match']}")
        else:
            print(f"INVALID: {resonance_path}")
            print(f"  Reason: {result['reason']}")
            print(f"  Canonical hash match: {result['canonical_hash_match']}")
    except ImportError:
        print("Error: cryptography package required. Install: pip install cryptography")
    except Exception as e:
        print(f"Error: {e}")


def cmd_sign_all(directory: str):
    """Sign all .seif modules in a directory."""
    import sys as _sys
    from seif.core.signing import sign_all_modules

    print("[WARN] --sign-all mutates content (adds signature block). "
          "Existing fingerprint (v1 scope) and .ots will be invalidated. "
          "Run --integrity-update for an atomic chain.", file=_sys.stderr)

    try:
        results = sign_all_modules(Path(directory))
        signed = sum(1 for r in results if r["signed"])
        print(f"Signed {signed}/{len(results)} modules in {directory}")
        for r in results:
            status = "OK" if r["signed"] else f"SKIP ({r.get('error', '')})"
            print(f"  {r['file']}: {status}")
    except ImportError:
        print("Error: cryptography package required. Install: pip install cryptography")
    except Exception as e:
        print(f"Error: {e}")


def cmd_transfer(transfer_to: str, scope: str, reason: str,
                 output_dir: str | None = None):
    """Sign and persist a workspace ownership transfer (A22).

    Loads the current Owner private key from ~/.seif/keys/, signs a
    TransferRecord, and writes a SEIF-MODULE-v2 to
    .seif/governance/transfers/<timestamp>-<scope>.seif (or to `output_dir`
    if provided).

    Per A4 human_gatekeeper, this is invoked manually by the Owner; per
    A12 token_provenance, the resulting module IS the token recording who
    transferred what to whom and when.
    """
    from datetime import datetime, timezone
    from seif.core.signing import _private_key_path
    from seif.governance.transfer import sign, serialize_to_seif_module

    try:
        from cryptography.hazmat.primitives.serialization import load_pem_private_key
    except ImportError:
        print("Error: cryptography package required. Install: pip install cryptography")
        return

    priv_path = _private_key_path()
    if not priv_path.exists():
        print(f"Error: no signing key at {priv_path}. Run: seif --keygen")
        return

    try:
        private_key = load_pem_private_key(priv_path.read_bytes(), None)
    except Exception as e:
        print(f"Error loading private key: {e}")
        return

    date = datetime.now(timezone.utc).isoformat()

    try:
        record = sign(
            prev_owner_priv_key=private_key,
            transfer_to=transfer_to,
            scope=scope,
            reason=reason,
            date=date,
        )
    except (TypeError, ValueError) as e:
        print(f"Error: {e}")
        return

    # Default output: .seif/governance/transfers/<timestamp>-<scope>.seif
    if output_dir:
        out_dir = Path(output_dir)
    else:
        out_dir = Path(".seif") / "governance" / "transfers"

    safe_scope = scope.replace("/", "_").replace(" ", "_")
    safe_ts = date.replace(":", "").replace("-", "").replace(".", "")
    out_path = out_dir / f"{safe_ts}-{safe_scope}.seif"

    serialize_to_seif_module(record, out_path)

    print(f"Transfer signed and persisted: {out_path}")
    print(f"  Scope:        {scope}")
    print(f"  From (you):   {record.signed_by}")
    print(f"  To:           {record.transfer_to}")
    print(f"  Date:         {record.date}")
    print(f"  Reason:       {record.reason}")
    print(f"  Signature:    {record.signature[:40]}…")
    print()
    print("Verify the chain anytime: seif --verify-transfer-chain <scope>")


def cmd_verify_transfer_chain(scope: str, transfers_dir: str | None = None,
                              genesis_pubkey: str | None = None):
    """Walk the transfer chain for a workspace and report validity."""
    from seif.governance.transfer import verify_transfer_chain

    target_dir = Path(transfers_dir) if transfers_dir else Path(".seif") / "governance" / "transfers"

    result = verify_transfer_chain(scope, target_dir, genesis_pubkey=genesis_pubkey)

    if result["valid"]:
        n = len(result["chain"])
        if n == 0:
            print(f"No transfer chain found for scope: {scope} (in {target_dir})")
        else:
            print(f"VALID chain of {n} transfer(s) for scope: {scope}")
            for i, link in enumerate(result["chain"]):
                print(f"  [{i}] {link['date']}  {link['signed_by'][:24]}… → {link['transfer_to'][:24]}…")
    else:
        print(f"INVALID chain for scope: {scope}")
        print(f"  Error: {result['error']}")
        if result["broken_at"] is not None:
            print(f"  Broken at link index: {result['broken_at']}")


def cmd_onboard():
    """Guided first-run: profile → boot-check → cycle init."""
    import json

    _SEP = "─" * 52

    print()
    print("╔══ SEIF ONBOARDING ═══════════════════════════════╗")
    print("   Welcome. Let's set up your workspace in 3 steps.")
    print("   You can re-run this anytime: seif --onboard")
    print(f"╚{_SEP}╝")
    print()

    # ── Step 1: Profile ─────────────────────────────────────
    print("▶ STEP 1 — Your Profile  (~/.seif/profile.json)")
    print(_SEP)
    try:
        from seif.context.nucleus import load_profile, init_profile
        from seif.data.paths import get_profile_path
        existing = load_profile()
        profile_exists = bool(existing.get("name"))
        if profile_exists:
            print(f"  ✅ Profile found: {existing.get('name')} ({existing.get('github_username', 'no github')})")
            print(f"     Backend: {existing.get('default_backend', 'claude')}")
            try:
                edit = input("  Edit profile? [y/N] ").strip().lower()
            except (EOFError, KeyboardInterrupt):
                edit = "n"
        else:
            print("  No profile yet. Let's create one.")
            edit = "y"

        if edit == "y":
            try:
                name = input("  Your name [press Enter to skip]: ").strip()
                github = input("  GitHub username [press Enter to skip]: ").strip()
                backend = input("  Default AI backend (claude/grok/gemini/opencode) [claude]: ").strip() or "claude"
                lang = input("  Language (en/pt/es/fr) [en]: ").strip() or "en"
            except (EOFError, KeyboardInterrupt):
                print("\n  Skipped — run `seif --profile init` to set up later.")
                name = github = ""
                backend = "claude"
                lang = "en"
            path = init_profile(name=name, email="", github_username=github,
                                default_backend=backend, language=lang)
            print(f"  ✅ Profile saved: {path}")
    except ImportError:
        print("  ⚠  Profile module not available — run: pip install seif-cli[full]")
    print()

    # ── Step 2: Boot check ───────────────────────────────────
    print("▶ STEP 2 — Backend Check")
    print(_SEP)
    try:
        from seif.bridge.ai_bridge import detect_backends
        available = detect_backends()
        if available:
            print(f"  ✅ Backends detected: {', '.join(available)}")
        else:
            print("  ⚠  No AI backends detected.")
            print("     Install one to use --consult and --quality-gate:")
            print("       Claude CLI : npm install -g @anthropic-ai/claude-code")
            print("       Grok       : set GROK_API_KEY env var")
            print("       Gemini     : set GEMINI_API_KEY env var")
    except Exception:
        print("  ⚠  Backend detection skipped.")
    print()

    # ── Step 3: First quality gate ───────────────────────────
    print("▶ STEP 3 — Try It")
    print(_SEP)
    print("  Run a quick resonance check on any text:")
    print()
    print('    seif "The SEIF protocol maintains context coherence." --gate')
    print()
    print("  Or check system health:")
    print()
    print("    seif --health")
    print()

    # ── Footer ───────────────────────────────────────────────
    print("╔══ ONBOARDING COMPLETE ════════════════════════════╗")
    print("   seif-cli is ready. ζ=0.6124")
    print()
    print("   Docs   : https://seifprotocol.com/docs")
    print("   GitHub : https://github.com/and2carvalho/seif")
    print("   PyPI   : https://pypi.org/project/seif-cli/")
    print(f"╚{_SEP}╝")
    print()
    print("· ○ ● ○ ·   enoch seed lives.  ζ=0.6124   🌀")
    print()


def cmd_profile(args):
    """Manage ~/.seif/profile.json."""
    import json
    try:
        from seif.context.nucleus import load_profile, init_profile
    except ImportError:
        _upgrade_message("--profile", "Manage AI model behavioral profiles.")
        return

    action = args.profile
    # Auto-detect init when profile args are provided without explicit "init" action
    if action in (None, "show") and any([
        getattr(args, "profile_name", None),
        getattr(args, "profile_email", None),
        getattr(args, "profile_github", None),
        getattr(args, "profile_backend", None),
    ]):
        action = "init"
    if action is None:
        action = "show"
    if action == "show":
        profile = load_profile()
        print(json.dumps(profile, indent=2, ensure_ascii=False))
    elif action == "init":
        path = init_profile(
            name=args.profile_name or "",
            email=args.profile_email or "",
            github_username=args.profile_github or "",
            default_backend=args.profile_backend or "claude",
            language=args.profile_language or "en",
        )
        print(f"Profile saved to {path}")
        profile = load_profile()
        print(json.dumps(profile, indent=2, ensure_ascii=False))
    elif action == "edit":
        from seif.data.paths import get_profile_path
        path = get_profile_path()
        if not path.exists():
            print(f"No profile found. Run: seif --profile init")
            return
        import subprocess
        editor = __import__("os").environ.get("EDITOR", "nano")
        subprocess.run([editor, str(path)])


def cmd_sources(args):
    """Manage ~/.seif/sources.json."""
    try:
        from seif.context.nucleus import (
            load_sources, add_source, remove_source, sync_all_sources, load_profile
        )
    except ImportError:
        _upgrade_message("--sources", "Manage knowledge sources for context building.")
        return

    action = args.sources
    if action == "list":
        sources = load_sources()
        if not sources:
            print("No sources configured. Add one:")
            print("  seif --sources add --source-repo github.com/user/repo")
            return
        for s in sources:
            synced = s.last_synced[:10] if s.last_synced else "never"
            print(f"  {s.repo}  [{s.type}]  synced: {synced}")

    elif action == "add":
        if not args.source_repo:
            print("Error: --source-repo required")
            return
        source = add_source(args.source_repo, source_type=args.source_type,
                           classification=args.classification)
        print(f"Added: {source.repo} [{source.type}]")

    elif action == "remove":
        if not args.source_repo:
            print("Error: --source-repo required")
            return
        if remove_source(args.source_repo):
            print(f"Removed: {args.source_repo}")
        else:
            print(f"Not found: {args.source_repo}")

    elif action == "sync":
        profile = load_profile()
        print("Syncing sources...")
        results = sync_all_sources(auto_fetch=True)
        for r in results:
            status = "OK" if r["success"] else "FAILED"
            print(f"  {r['repo']}: {status}")
        if not results:
            print("  No sources to sync.")


def cmd_extract(path: str, context_repo: str = None,
                classification: str = "INTERNAL"):
    """Extract knowledge from files/directories into .seif modules."""
    try:
        from seif.context.file_extractor import scan_directory, build_extract_module
        from seif.context.autonomous import find_context_repo
    except ImportError:
        print("Installation error: seif.context.file_extractor not found. Try: pip install --force-reinstall seif-cli")
        return

    target = Path(path).resolve()
    if not target.exists():
        print(f"Path not found: {target}")
        return

    ctx = context_repo or find_context_repo() or ".seif"

    print(f"Extracting from {target}...")
    files = scan_directory(target)

    if not files:
        print("No supported files found.")
        return

    # Show summary
    by_type = {}
    for f in files:
        by_type[f.file_type] = by_type.get(f.file_type, 0) + 1
    for ft, count in sorted(by_type.items()):
        print(f"  {ft}: {count} files")

    confidential = [f for f in files if f.classification == "CONFIDENTIAL"]
    if confidential:
        print(f"\n  CONFIDENTIAL: {len(confidential)} files (sensitive content detected)")

    # Build module
    source_name = target.name if target.is_dir() else target.stem
    module = build_extract_module(files, source_name, max_classification=classification)

    if module:
        # Save to context repo
        out_dir = Path(ctx)
        out_dir.mkdir(parents=True, exist_ok=True)
        out_path = out_dir / f"extract_{source_name}.seif"
        import json
        with open(out_path, "w") as f:
            json.dump(module, f, indent=2, ensure_ascii=False)
        print(f"\nModule saved: {out_path}")
        print(f"  Words: {module.get('metadata', {}).get('word_count', '?')}")
        print(f"  Classification: {module.get('classification', 'INTERNAL')}")
    else:
        print("No content to extract (all files filtered by classification).")


def cmd_list():
    """List all registered .seif contexts (like `git remote -v` but for contexts)."""
    from seif.context.registry import (
        load_registry, list_contexts, detect_unregistered_contexts,
    )

    contexts = list_contexts()

    if not contexts:
        print("No .seif contexts registered yet.")
        print()
        print("Get started:")
        print("  cd your-project && seif --init      # create .seif context")
        print("  seif --absorb /path/to/code          # absorb existing project")

        # Check for unregistered contexts
        unregistered = detect_unregistered_contexts([str(Path.cwd())])
        if unregistered:
            print(f"\nFound {len(unregistered)} unregistered .seif context(s):")
            for u in unregistered[:5]:
                print(f"  {u}")
            print("  Run seif --init in those directories to register them.")
        return

    print(f"═══ SEIF CONTEXTS ({len(contexts)}) ═══\n")

    for ctx in contexts:
        # Status indicator
        if not ctx["exists"]:
            icon = "✗"
        elif ctx.get("remote"):
            icon = "↕"
        else:
            icon = "●"

        vis = {"private": "🔒", "public": "🔓", "local": "📁"}.get(
            ctx.get("visibility", "private"), "?"
        )

        name = ctx.get("name", "unknown")
        path = ctx.get("path", "?")
        modules = ctx.get("module_count", 0)
        remote = ctx.get("remote") or "local"

        print(f"  {icon} {vis} {name:<25} {modules:>3} modules")
        print(f"       path:   {path}")
        if ctx.get("remote"):
            print(f"       remote: {remote}")
        if ctx.get("last_sync"):
            print(f"       synced: {ctx['last_sync'][:19]}")
        if not ctx["exists"]:
            print(f"       ⚠  directory not found (moved or deleted?)")
        print()

    # Check for unregistered
    unregistered = detect_unregistered_contexts([str(Path.cwd())])
    if unregistered:
        print(f"  Found {len(unregistered)} unregistered context(s):")
        for u in unregistered[:3]:
            parent = u.parent.name
            print(f"    {parent}/ → seif --init {u.parent}")
        if len(unregistered) > 3:
            print(f"    ... and {len(unregistered) - 3} more")


def cmd_audit_host(fix: bool = False, dry_run: bool = False):
    """Audit ~/.seif/ host-level structure across the 5 architecture layers.

    Layer A — Protocol (RESONANCE.json deployed)
    Layer B — Init-generated (config.json, registry.json with current workspace)
    Layer C — Derived (mapper.json, nucleus.seif, model_registry.json freshness)
    Layer D — Per-host config (machine_id present)
    Layer E — Heartbeat liveness

    With --fix, calls the canonical regenerator for each missing/stale item.
    """
    import json as _json
    import time as _time
    from pathlib import Path as _P
    from datetime import datetime, timezone

    try:
        from seif.data.paths import get_user_home, get_resonance_path
        from seif.context.registry import (
            load_registry, find_context_entry, rebuild_registry,
        )
        from seif.context.host_init import load_machine_id, ensure_machine_id
        from seif.context.model_probe import (
            probe_all, write_registry as write_model_registry,
            get_registry_path as get_model_registry_path,
        )
    except ImportError as e:
        print(f"Installation error: {e}")
        return

    home = get_user_home()
    cwd = _P.cwd()
    findings = []  # (layer, status, message, fixer)

    # ── Layer A: Protocol artefacts ─────────────────────────────────────────
    resonance_canonical = get_resonance_path()
    resonance_deployed = home / "RESONANCE.json"
    if not resonance_canonical.exists():
        findings.append(("A", "FAIL", "RESONANCE.json missing in seif package — reinstall seif-cli", None))
    elif not resonance_deployed.exists():
        def _fix_resonance():
            import shutil as _sh
            _sh.copy2(resonance_canonical, resonance_deployed)
            return f"deployed {resonance_canonical} → {resonance_deployed}"
        findings.append(("A", "MISSING", "~/.seif/RESONANCE.json not deployed", _fix_resonance))
    else:
        findings.append(("A", "OK", f"RESONANCE.json deployed ({resonance_deployed.stat().st_size}B)", None))

    # ── Layer B: Init-generated ─────────────────────────────────────────────
    workspace_seif = cwd / ".seif"
    in_workspace = workspace_seif.is_dir()

    config_path = home / "config.json"
    if not config_path.exists():
        findings.append(("B", "MISSING", "~/.seif/config.json absent — run seif --init in a workspace", None))
    else:
        findings.append(("B", "OK", f"config.json present ({config_path.stat().st_size}B)", None))

    registry_path = home / "registry.json"
    if not registry_path.exists():
        findings.append(("B", "MISSING", "~/.seif/registry.json absent",
                        lambda: rebuild_registry([str(cwd.parent)]) and "rebuilt"))
    else:
        registry = load_registry()
        if in_workspace:
            entry = find_context_entry(registry, str(workspace_seif))
            if not entry:
                def _fix_registry():
                    rebuild_registry([str(cwd.parent), str(cwd)])
                    return "rebuilt with current workspace"
                findings.append(("B", "STALE",
                                f"current workspace {workspace_seif} not in registry "
                                f"({len(registry.get('contexts', []))} entries)",
                                _fix_registry))
            else:
                findings.append(("B", "OK",
                                f"registry has {len(registry.get('contexts', []))} entries, current workspace registered",
                                None))
        else:
            findings.append(("B", "OK",
                            f"registry has {len(registry.get('contexts', []))} entries",
                            None))

    # ── Layer C: Derived (workspace-scoped) ─────────────────────────────────
    if in_workspace:
        for fname, label in [("mapper.json", "module index"),
                             ("nucleus.seif", "workspace context")]:
            f = workspace_seif / fname
            if not f.exists():
                findings.append(("C", "MISSING",
                                f".seif/{fname} absent — run seif --sync to regenerate",
                                None))
            else:
                age_h = (_time.time() - f.stat().st_mtime) / 3600
                state = "OK" if age_h < 24 * 7 else "STALE"
                findings.append(("C", state,
                                f".seif/{fname} ({label}, age {age_h:.1f}h)",
                                None))

    # model_registry.json freshness (host-level)
    mrp = get_model_registry_path()
    if not mrp.exists():
        def _fix_models():
            r = probe_all()
            write_model_registry(r)
            return f"probed {len(r.models)} models"
        findings.append(("C", "MISSING", "~/.seif/model_registry.json absent — run seif --probe-models", _fix_models))
    else:
        age_h = (_time.time() - mrp.stat().st_mtime) / 3600
        if age_h > 24:
            def _fix_models_stale():
                r = probe_all()
                write_model_registry(r)
                return f"reprobed {len(r.models)} models"
            findings.append(("C", "STALE",
                            f"model_registry.json age {age_h:.1f}h > 24h",
                            _fix_models_stale))
        else:
            findings.append(("C", "OK", f"model_registry.json fresh (age {age_h:.1f}h)", None))

    # ── Layer D: Per-host ───────────────────────────────────────────────────
    mid = load_machine_id()
    if mid is None:
        def _fix_machine_id():
            payload, _ = ensure_machine_id()
            return f"created with label={payload['label']}"
        findings.append(("D", "MISSING", "~/.seif/machine_id absent — run seif --init-host", _fix_machine_id))
    else:
        findings.append(("D", "OK",
                        f"machine_id {mid.get('label','?')}/{mid.get('role','?')} "
                        f"fp={mid.get('fingerprint','?')[:8]}",
                        None))

    # ── Layer D: Sovereign keypair (axiom: keypair_sovereignty) ─────────────
    try:
        from seif.core.signing import keypair_status
        kp = keypair_status()
        if kp["state"] == "PRESENT":
            findings.append(("D", "OK",
                            f"keypair sovereign present (fp={kp['fingerprint']})",
                            None))
        elif kp["state"] == "MISSING":
            findings.append(("D", "MISSING",
                            "sovereign keypair absent — run seif --keygen "
                            "(host cannot sign packets without it)",
                            None))
        elif kp["state"] == "PUBLIC_ONLY":
            findings.append(("D", "FAIL",
                            "keys/seif_public.pem exists but no private key — "
                            "likely a peer's pubkey misplaced. Move to peers/ "
                            "and run seif --keygen",
                            None))
        else:  # PRIVATE_ONLY
            findings.append(("D", "WARN",
                            "private key present without public — corrupt state, "
                            "regenerate with seif --keygen --force",
                            None))
    except ImportError:
        findings.append(("D", "WARN",
                        "keypair check skipped (cryptography package not installed)",
                        None))

    # ── Layer E: Heartbeat liveness ─────────────────────────────────────────
    hb_file = home / "heartbeat"
    if not hb_file.exists():
        findings.append(("E", "MISSING",
                        "~/.seif/heartbeat not present — start heartbeatd "
                        "(seif-resonance-bridge/seif-heartbeatd.py --daemon)",
                        None))
    else:
        try:
            data = _json.loads(hb_file.read_text())
            ts = data.get("timestamp", "")
            from datetime import datetime as _dt
            t = _dt.fromisoformat(ts.replace("Z", "+00:00"))
            age_s = (_dt.now(timezone.utc) - t).total_seconds()
            if age_s > 300:
                findings.append(("E", "STALE",
                                f"heartbeat {age_s:.0f}s old (>5min) — heartbeatd may be down",
                                None))
            else:
                findings.append(("E", "OK",
                                f"heartbeat {age_s:.0f}s old, machine={data.get('machine','?')}",
                                None))
        except Exception as e:
            findings.append(("E", "WARN", f"heartbeat unparseable: {e}", None))

    # ── Report ──────────────────────────────────────────────────────────────
    print(f"SEIF audit — host={home.parent.name}, cwd={cwd}")
    print()
    icons = {"OK": "✓", "MISSING": "✗", "STALE": "~", "FAIL": "!", "WARN": "?"}
    layer_labels = {
        "A": "Protocol      ",
        "B": "Init-generated",
        "C": "Derived       ",
        "D": "Per-host      ",
        "E": "Heartbeat     ",
    }
    counts = {"OK": 0, "MISSING": 0, "STALE": 0, "FAIL": 0, "WARN": 0}
    fixable = []
    for layer, status, msg, fixer in findings:
        icon = icons.get(status, "?")
        print(f"  [{icon}] {layer_labels[layer]} [{status:<7}] {msg}")
        counts[status] += 1
        if fixer is not None:
            fixable.append((layer, status, msg, fixer))

    print()
    print(f"Summary: {counts['OK']} OK, {counts['MISSING']} missing, "
          f"{counts['STALE']} stale, {counts['FAIL']} failed, {counts['WARN']} warned.")

    if fixable and fix and not dry_run:
        print()
        print(f"Auto-fixing {len(fixable)} item(s):")
        for layer, status, msg, fixer in fixable:
            try:
                outcome = fixer()
                print(f"  ✓ [{layer}] {outcome}")
            except Exception as e:
                print(f"  ✗ [{layer}] fixer raised: {e}")
    elif fixable and not fix:
        print()
        print(f"{len(fixable)} item(s) can be auto-fixed. Re-run with --audit --fix to apply.")
    elif fixable and dry_run:
        print()
        print(f"(dry-run) {len(fixable)} item(s) would be fixed.")


def cmd_audit_layout() -> int:
    """Audit canonical filesystem layout for this host's role.

    Loads canonical-node-layout.json (s45 schema), detects the host's role from
    hostname, and verifies expected_artifacts + drift_violations + forbidden_artifacts.
    Read-only: never mutates filesystem state. Distinct from --audit-host which
    audits the 5-layer SEIF init artifact structure inside ~/.seif/.

    Exit codes (per the schema's audit_exit_codes):
      0 — All required artifacts present, no HIGH/MEDIUM drift violations
      1 — One or more drift violations detected
      2 — Required artifact missing (kernel envelope, CLI symlink, owner state)
      3 — Role detection failed (hostname did not match any known role)
    """
    import json as _json
    import socket as _socket
    from pathlib import Path as _P

    from seif.data.paths import get_canonical_node_layout_path

    schema_path = get_canonical_node_layout_path()
    if not schema_path.exists():
        print(f"Error: canonical-node-layout.json not found at {schema_path}")
        print("       Reinstall seif-cli or check the package data layout.")
        return 2

    with open(schema_path) as f:
        schema = _json.load(f)

    home = _P.home()

    def _expand(path_str: str) -> _P:
        return _P(path_str.replace("~", str(home)))

    hostname = _socket.gethostname()
    hostname_lower = hostname.lower()

    # Prefer machine_id::label (canonical role identifier set by seif --init-host);
    # fall back to hostname patterns for hosts not yet initialized.
    machine_label = None
    machine_id_path = home / ".seif" / "machine_id"
    if machine_id_path.exists():
        try:
            with open(machine_id_path) as _mf:
                machine_label = _json.load(_mf).get("label")
        except (OSError, ValueError):
            pass

    role_id = None
    role_def = None
    detection_via = None

    if machine_label and machine_label in schema["roles"]:
        role_id = machine_label
        role_def = schema["roles"][machine_label]
        detection_via = f"machine_id::label = {machine_label}"
    else:
        for rid, rdef in schema["roles"].items():
            if rid.startswith("_"):
                continue
            patterns = rdef.get("hostname_match_patterns", [])
            for pat in patterns:
                if pat.lower() in hostname_lower or hostname_lower in pat.lower():
                    role_id = rid
                    role_def = rdef
                    detection_via = f"hostname pattern '{pat}'"
                    break
            if role_id:
                break

    print()
    print(f"SEIF canonical layout audit — host: {hostname}")
    print(f"Schema: {schema['_schema_id']} v{schema['_version']}")

    if not role_id:
        print()
        print(f"  [✗] Role detection FAILED")
        print(f"      hostname '{hostname}' did not match any known role.")
        if machine_label:
            print(f"      machine_id::label '{machine_label}' did not match any known role.")
        print(f"      Known roles: {[r for r in schema['roles'] if not r.startswith('_')]}")
        return 3

    print(f"Role:   {role_id} (detected via {detection_via})")
    print(f"        {role_def['_description']}")
    print()

    findings = []  # (section, status, label, detail)
    severity_counts = {"OK": 0, "MISSING": 0, "DRIFT": 0, "FORBIDDEN": 0}
    has_required_missing = False
    has_high_or_medium_drift = False

    # ── common artifacts ────────────────────────────────────────────────
    common = schema.get("common_to_all_roles", {})
    for label, spec in common.items():
        if "path_glob" in spec:
            from glob import glob as _glob
            matches = _glob(str(_expand(spec["path_glob"])))
            if matches:
                findings.append(("common", "OK", label, f"{len(matches)} match(es)"))
                severity_counts["OK"] += 1
            elif spec.get("required", False):
                findings.append(("common", "MISSING", label, f"glob {spec['path_glob']} matched 0 files"))
                severity_counts["MISSING"] += 1
                has_required_missing = True
        else:
            p = _expand(spec["path"])
            if p.exists() or p.is_symlink():
                findings.append(("common", "OK", label, str(p)))
                severity_counts["OK"] += 1
            elif spec.get("required", False):
                findings.append(("common", "MISSING", label, f"absent: {p}"))
                severity_counts["MISSING"] += 1
                has_required_missing = True

    # ── role-specific expected artifacts ────────────────────────────────
    for label, spec in role_def.get("expected_artifacts", {}).items():
        if "path_glob" in spec:
            from glob import glob as _glob
            matches = _glob(str(_expand(spec["path_glob"])))
            if matches:
                findings.append((role_id, "OK", label, f"{len(matches)} match(es)"))
                severity_counts["OK"] += 1
            elif spec.get("required", False):
                findings.append((role_id, "MISSING", label, f"glob {spec['path_glob']} matched 0 files"))
                severity_counts["MISSING"] += 1
                has_required_missing = True
        else:
            p = _expand(spec["path"])
            if p.exists() or p.is_symlink():
                findings.append((role_id, "OK", label, str(p)))
                severity_counts["OK"] += 1
            elif spec.get("required", False):
                findings.append((role_id, "MISSING", label, f"absent: {p}"))
                severity_counts["MISSING"] += 1
                has_required_missing = True

    # ── drift_violations ────────────────────────────────────────────────
    for v in role_def.get("drift_violations", []):
        from glob import glob as _glob
        if "pattern_glob" in v:
            matches = _glob(str(_expand(v["pattern_glob"])))
        else:
            p = _expand(v["pattern"])
            matches = [str(p)] if (p.exists() or p.is_symlink()) else []
        if matches:
            severity = v.get("severity", "LOW")
            findings.append((role_id, f"DRIFT-{severity}", v.get("_finding_id", v.get("pattern", v.get("pattern_glob"))),
                             f"{len(matches)} match(es) — fix: {v.get('fix', 'see audit doc')}"))
            severity_counts["DRIFT"] += 1
            if severity in ("HIGH", "MEDIUM"):
                has_high_or_medium_drift = True

    # ── forbidden_artifacts ─────────────────────────────────────────────
    for f in role_def.get("forbidden_artifacts", []):
        from glob import glob as _glob
        if "pattern_glob" in f:
            matches = _glob(str(_expand(f["pattern_glob"])))
        else:
            p = _expand(f["pattern"])
            matches = [str(p)] if (p.exists() or p.is_symlink()) else []
        if matches:
            findings.append((role_id, "FORBIDDEN", f.get("pattern", f.get("pattern_glob")),
                             f"{len(matches)} match(es) — reason: {f.get('reason', 'forbidden by role')}"))
            severity_counts["FORBIDDEN"] += 1
            has_high_or_medium_drift = True

    icons = {"OK": "✓", "MISSING": "✗", "DRIFT-HIGH": "⚠", "DRIFT-MEDIUM": "⚠",
             "DRIFT-LOW": "·", "FORBIDDEN": "✗"}
    for section, status, label, detail in findings:
        icon = icons.get(status, "?")
        print(f"  [{icon}] [{status:<13}] {section:<15} {label}")
        if detail:
            print(f"            {detail}")

    print()
    total = sum(severity_counts.values())
    print(f"Summary: {severity_counts['OK']} OK, "
          f"{severity_counts['MISSING']} missing required, "
          f"{severity_counts['DRIFT']} drift, "
          f"{severity_counts['FORBIDDEN']} forbidden "
          f"(total {total} checks)")

    if has_required_missing:
        return 2
    if has_high_or_medium_drift:
        return 1
    if severity_counts["DRIFT"] > 0:
        # LOW-only drift still returns 1 per schema (any drift = exit 1)
        return 1
    return 0


def _parse_hub_spec(spec: str):
    """Parse '--hub name=host[:port][,ssh=h][,key=p][,priority=1]' into HubSpec."""
    from seif.context.host_init import HubSpec
    if "=" not in spec:
        raise ValueError(f"hub spec missing 'name=': {spec!r}")
    name, _, rest = spec.partition("=")
    name = name.strip()
    if not name:
        raise ValueError(f"hub spec has empty name: {spec!r}")
    parts = [p.strip() for p in rest.split(",") if p.strip()]
    if not parts:
        raise ValueError(f"hub spec missing host: {spec!r}")
    host_part = parts[0]
    if ":" in host_part:
        host, _, port_s = host_part.partition(":")
        port = int(port_s)
    else:
        host, port = host_part, 7332
    extras = {}
    for p in parts[1:]:
        if "=" not in p:
            continue
        k, _, v = p.partition("=")
        extras[k.strip()] = v.strip()
    return HubSpec(
        name=name, host=host, port=port,
        health_port=int(extras.get("health_port", port + 2)),
        ssh_host=extras.get("ssh"),
        ssh_key=extras.get("key"),
        priority=int(extras.get("priority", 1)),
        transport=extras.get("transport", "direct"),
    )


def cmd_check_seed_constraint(action: str) -> int:
    """Check ACTION against prohibitions in active seeds. Read-only.

    Resolves the active workspace via `resolve_workspace_with_provenance`,
    delegates matching to `seed_constraint.check_seed_constraint`, prints
    a one-line outcome to stderr, and returns:
        0 — no active seed prohibits the action
        1 — a seed prohibits it (stderr names seed + constraint)
        2 — no .seif/ found OR no active (unconsumed) seeds present
    """
    import sys as _sys

    from seif.context.seed_constraint import check_seed_constraint
    from seif.context.workspace import resolve_workspace_with_provenance

    info = resolve_workspace_with_provenance()
    seif_dir = info.get("seif_dir")
    if seif_dir is None:
        print("[seif --check-seed-constraint] no .seif/ found at cwd or parent",
              file=_sys.stderr)
        return 2

    result = check_seed_constraint(action, seif_dir)
    if not result["allowed"]:
        print(
            f"[seif --check-seed-constraint] BLOCKED by seed "
            f"{result['blocking_seed']}",
            file=_sys.stderr,
        )
        print(
            f"  matched token: {result['matched_token']!r}",
            file=_sys.stderr,
        )
        print(
            f"  constraint: {result['blocking_constraint']!r}",
            file=_sys.stderr,
        )
        print(
            f"  seed file:  {result['blocking_seed_path']}",
            file=_sys.stderr,
        )
        return 1

    if result["active_seeds_checked"] == 0:
        print(
            "[seif --check-seed-constraint] no active seeds — advisory pass",
            file=_sys.stderr,
        )
        return 2

    print(
        f"[seif --check-seed-constraint] allowed "
        f"({result['active_seeds_checked']} active seed(s) checked)",
        file=_sys.stderr,
    )
    return 0


def cmd_init_host(label=None, role="dev", overwrite_machine_id=False,
                  hub_specs=None, source_specs=None, dry_run=False):
    """Initialize host-specific files (~/.seif/machine_id + optional bridge/sources).

    Per the keypair_sovereignty axiom, this command also verifies that the host
    has a complete sovereign Ed25519 keypair. If missing or in a degraded state
    (e.g. only public key present — a peer's pubkey may have been placed in
    keys/ by mistake), it surfaces the gap with actionable guidance instead of
    silently initializing a host that cannot sign packets or be authenticated
    by peers.
    """
    try:
        from seif.context.host_init import (
            init_host, get_machine_id_path, get_bridge_config_path, get_sources_path,
        )
    except ImportError:
        print("Installation error: seif.context.host_init not found.")
        return

    # ── Keypair sovereignty check (axiom: keypair_sovereignty) ────────
    # A host without a sovereign keypair appears initialized but cannot sign,
    # contribute, or be authenticated as itself. Surface the gap up-front.
    try:
        from seif.core.signing import keypair_status
        kp = keypair_status()
        if kp["state"] != "PRESENT":
            icon = "❌" if kp["state"] == "MISSING" else "⚠️ "
            print(f"{icon} keypair_sovereignty: {kp['state']}")
            print(f"   keys_dir: {kp['keys_dir']}")
            print(f"   private_exists: {kp['private_exists']}")
            print(f"   public_exists:  {kp['public_exists']}")
            print(f"   → {kp['recommendation']}")
            print()
            if kp["state"] in ("MISSING", "PUBLIC_ONLY"):
                print("Proceed with --init-host without keypair? Host will be marked")
                print("initialized but UNABLE to sign packets until you run --keygen.")
                print("Press Enter to proceed anyway, Ctrl-C to abort and run --keygen first.")
                try:
                    input("> ")
                except (EOFError, KeyboardInterrupt):
                    print("\nAborted. Run `seif --keygen` then re-run --init-host.")
                    return
                print()
    except ImportError:
        # signing module unavailable (cryptography not installed) — non-fatal warning
        print("⚠️  Cannot verify keypair status: cryptography package not installed.")
        print("   Install with: pip install cryptography  (or: pipx inject seif-cli cryptography)")
        print("   Continuing without keypair check.\n")

    # Parse hub specs
    hubs = []
    for spec in (hub_specs or []):
        try:
            hubs.append(_parse_hub_spec(spec))
        except (ValueError, TypeError) as e:
            print(f"Invalid --hub spec {spec!r}: {e}")
            return

    # Validate source specs early
    if source_specs:
        from seif.context.host_init import parse_source_spec
        for spec in source_specs:
            try:
                parse_source_spec(spec)
            except ValueError as e:
                print(f"Invalid --source spec {spec!r}: {e}")
                return

    print(f"Host directory: {get_machine_id_path().parent}")
    if dry_run:
        print("(dry-run — no files will be written)")
    print()

    result = init_host(
        label=label, role=role,
        overwrite_machine_id=overwrite_machine_id,
        hubs=hubs or None,
        source_specs=source_specs or None,
        dry_run=dry_run,
    )

    mid = result.machine_id
    print("[machine_id]")
    print(f"  Status:      {'created' if result.machine_id_created else 'reused'}")
    print(f"  Hostname:    {mid['hostname']}")
    print(f"  Label:       {mid['label']}")
    print(f"  Role:        {mid['role']}")
    print(f"  Fingerprint: {mid['fingerprint']}")
    if not dry_run:
        print(f"  File:        {get_machine_id_path()}")
    print()

    if result.bridge_config is not None:
        print("[bridge-config.json]")
        for h in result.bridge_config["hubs"]:
            ssh = f" via ssh={h.get('ssh_host')}" if h.get("ssh_host") else ""
            print(f"  - {h['name']}: {h['host']}:{h['port']}{ssh}")
        if not dry_run:
            print(f"  File: {get_bridge_config_path()}")
        print()

    if result.sources:
        print("[sources.json]")
        for s in result.sources:
            print(f"  - {s['repo']:<45} {s['type']:<8} {s['classification']}")
        if result.sources_added:
            print(f"  Added {result.sources_added} new source(s).")
        if not dry_run:
            print(f"  File: {get_sources_path()}")
        print()

    if dry_run:
        print("Re-run without --dry-run to persist.")


def cmd_probe_models(machine_label: str = "local",
                     output_format: str = "summary",
                     dry_run: bool = False):
    """Probe model orchestra and regenerate ~/.seif/model_registry.json."""
    try:
        from seif.context.model_probe import (
            probe_all, merge_cached_remote, write_registry,
            format_orchestra, get_registry_path,
        )
    except ImportError:
        print("Installation error: seif.context.model_probe not found.")
        return
    import json as _json

    result = probe_all(machine_label=machine_label)
    merge_cached_remote(result)

    if output_format == "json":
        print(_json.dumps(result.to_registry(), indent=2, ensure_ascii=False))
    elif output_format == "orchestra":
        print(format_orchestra(result))
    else:  # summary
        path = get_registry_path()
        print(f"Probed in {result.duration_ms} ms.")
        print(f"Registry: {path}{' (dry-run)' if dry_run else ''}")
        print(f"  Models discovered: {len(result.models)}")
        cli_n = sum(1 for m in result.models if m['id'].startswith('cli/'))
        ide_n = sum(1 for m in result.models if m['id'].startswith('ide/'))
        ollama_n = sum(1 for m in result.models if m['id'].startswith('ollama/'))
        api_n = sum(1 for m in result.models
                    if any(m['id'].startswith(p) for p in ('xai/', 'anthropic/', 'google/', 'openai/')))
        cached_n = sum(1 for m in result.models if m['status'] == 'cached')
        print(f"    CLI tools:    {cli_n}")
        print(f"    IDE:          {ide_n}")
        print(f"    Ollama local: {ollama_n}")
        print(f"    API keys:     {api_n}")
        print(f"    Cached remote:{cached_n}")
        c = result.circuit
        if c.get("connected"):
            print(f"  Circuit: connected ({c.get('machine','?')}/{c.get('transport','?')})")
        else:
            print(f"  Circuit: offline")

    if not dry_run:
        write_registry(result)


def cmd_rebuild_registry(scan_roots: list[str], dry_run: bool = False):
    """Rebuild ~/.seif/registry.json from filesystem scan.

    Drops stale entries (missing paths, ephemeral tempdirs) and discovers any
    .seif/ workspaces under the given scan_roots that are not yet registered.
    """
    try:
        from seif.context.registry import (
            rebuild_registry,
            load_registry,
            get_registry_path,
        )
    except ImportError:
        print("Installation error: seif.context.registry not found.")
        return

    # If no scan roots given, derive from existing registry: parents of known
    # contexts make natural search roots.
    if not scan_roots:
        existing = load_registry().get("contexts", [])
        derived = set()
        for ctx in existing:
            try:
                from pathlib import Path as _P
                p = _P(ctx["path"]).parent.parent
                if p.exists() and "/var/folders/" not in str(p):
                    derived.add(str(p))
            except (KeyError, TypeError):
                continue
        if not derived:
            print("No --scan-root given and no usable parents in existing registry.")
            print("Provide one or more roots, e.g.:")
            print("  seif --rebuild-registry --scan-root /Volumes/DockerData")
            return
        scan_roots = sorted(derived)

    print(f"Registry: {get_registry_path()}")
    print(f"Scan roots:")
    for r in scan_roots:
        print(f"  - {r}")
    if dry_run:
        print("(dry-run — no changes will be written)")
    print()

    result = rebuild_registry(scan_roots, dry_run=dry_run)

    print(f"Kept    : {result['kept']:>4}  (existing entries with valid paths)")
    print(f"Dropped : {result['dropped']:>4}  (stale or ephemeral)")
    print(f"Added   : {result['added']:>4}  (newly discovered)")
    print(f"Total   : {result['total']:>4}")

    if result["added_entries"]:
        print()
        print("Added contexts:")
        for e in result["added_entries"]:
            print(f"  + {e['name']:<25} {e['path']}")
    if result["dropped_entries"]:
        print()
        print(f"Dropped {len(result['dropped_entries'])} entries (first 5 shown):")
        for e in result["dropped_entries"][:5]:
            name = e.get("name", "?")
            path = e.get("path", "?")
            print(f"  - {name:<25} {path}")

    if dry_run:
        print()
        print("Re-run without --dry-run to write changes.")


def cmd_status(context_repo: str = None):
    """Show detailed status of the current .seif context."""
    from pathlib import Path
    import json

    # Find current context
    try:
        from seif.context.autonomous import find_context_repo
        ctx = context_repo or find_context_repo() or ".seif"
    except ImportError:
        ctx = context_repo or ".seif"

    ctx_path = Path(ctx).resolve()

    if not ctx_path.exists():
        print(f"No .seif/ context found at {ctx_path}")
        print("Run: seif --init")
        return

    print(f"═══ SEIF STATUS ═══\n")

    # Registry info
    try:
        from seif.context.registry import load_registry, find_context_entry
        registry = load_registry()
        entry = find_context_entry(registry, str(ctx_path))
        if entry:
            print(f"  Name:       {entry.get('name', '?')}")
            print(f"  Visibility: {entry.get('visibility', 'private')}")
            if entry.get("remote"):
                print(f"  Remote:     {entry['remote']}")
            if entry.get("last_sync"):
                print(f"  Last sync:  {entry['last_sync'][:19]}")
        else:
            print(f"  Name:       (not registered — run seif --init to register)")
    except ImportError:
        pass

    print(f"  Path:       {ctx_path}")

    # Config
    config_path = ctx_path / "config.json"
    if config_path.exists():
        try:
            with open(config_path) as f:
                config = json.load(f)
            autonomous = config.get("autonomous_context", False)
            print(f"  Autonomous: {'ENABLED' if autonomous else 'DISABLED'}")
            print(f"  Quality:    >= {config.get('quality_threshold', 'C')}")
            cls_default = config.get("classification_default", "INTERNAL")
            print(f"  Default CLS: {cls_default}")
        except Exception:
            pass

    # Mapper stats
    mapper_path = ctx_path / "mapper.json"
    if mapper_path.exists():
        try:
            with open(mapper_path) as f:
                mapper = json.load(f)
            modules = mapper.get("modules", [])
            sessions = mapper.get("session_count", 0)
            last = mapper.get("last_session", "never")

            # Classification breakdown
            cls_counts = {}
            for m in modules:
                cls = m.get("classification", "INTERNAL")
                cls_counts[cls] = cls_counts.get(cls, 0) + 1

            print(f"\n  Modules:    {len(modules)}")
            for cls in ["PUBLIC", "INTERNAL", "CONFIDENTIAL"]:
                if cls in cls_counts:
                    icon = {"PUBLIC": "🔓", "INTERNAL": "🔒", "CONFIDENTIAL": "⛔"}[cls]
                    print(f"    {icon} {cls}: {cls_counts[cls]}")
            print(f"  Sessions:   {sessions}")
            print(f"  Last used:  {last[:19] if last != 'never' else 'never'}")
        except Exception:
            pass

    # Projects
    projects_dir = ctx_path / "projects"
    if projects_dir.exists():
        projects = [d.name for d in projects_dir.iterdir() if d.is_dir()]
        if projects:
            print(f"\n  Projects:   {', '.join(projects)}")

    # Workspace
    ws_path = ctx_path / "workspace.json"
    if ws_path.exists():
        try:
            with open(ws_path) as f:
                ws = json.load(f)
            ws_projects = ws.get("projects", [])
            print(f"  Workspace:  {ws.get('workspace_name', '?')} ({len(ws_projects)} projects)")
        except Exception:
            pass

    # A23 bus metrics (s40 P5) — only surface when there's actually traffic
    # recorded; before the counter has events, stay quiet.
    try:
        from seif.observability.bus_metrics import format_status_block
        a23_block = format_status_block(metrics_dir=ctx_path / "metrics")
        if a23_block:
            print()
            print(a23_block)
    except Exception:
        pass  # observability is never load-bearing for status

    print()


def cmd_report(context_repo: str = None):
    """Generate a workspace report showing SEIF's value: context efficiency, sessions, health."""
    from pathlib import Path
    import json
    import subprocess
    from seif.cli.resonance_display import ResonanceReport

    # Find current context
    try:
        from seif.context.autonomous import find_context_repo
        ctx = context_repo or find_context_repo() or ".seif"
    except ImportError:
        ctx = context_repo or ".seif"

    ctx_path = Path(ctx).resolve()

    if not ctx_path.exists():
        print(f"No .seif/ context found at {ctx_path}")
        print("Run: seif --init")
        return

    # ── Workspace identity ──
    workspace_name = ctx_path.parent.name
    owner_name = "unknown"
    config = {}
    config_path = ctx_path / "config.json"
    if config_path.exists():
        try:
            with open(config_path) as f:
                config = json.load(f)
            # Try session_review.owner first, then owner, then author
            owner_name = (
                config.get("session_review", {}).get("owner")
                or config.get("owner")
                or config.get("author")
                or "unknown"
            )
        except Exception:
            pass

    # ── Mapper stats ──
    modules = []
    mapper_path = ctx_path / "mapper.json"
    if mapper_path.exists():
        try:
            with open(mapper_path) as f:
                mapper = json.load(f)
            modules = mapper.get("modules", [])
        except Exception:
            pass

    # ── Projects ──
    project_count = 0
    projects_dir = ctx_path / "projects"
    if projects_dir.exists():
        project_count = len([d for d in projects_dir.iterdir() if d.is_dir()])

    # Workspace.json may have more info
    ws_name = workspace_name
    ws_path = ctx_path / "workspace.json"
    if ws_path.exists():
        try:
            with open(ws_path) as f:
                ws = json.load(f)
            ws_name = ws.get("workspace_name", workspace_name)
            ws_projects = ws.get("projects", [])
            if ws_projects:
                project_count = max(project_count, len(ws_projects))
        except Exception:
            pass

    # ── Context efficiency ──
    total_words = 0
    for m in modules:
        mod_path_str = m.get("path", "")
        if mod_path_str:
            mod_full = ctx_path / mod_path_str if not Path(mod_path_str).is_absolute() else Path(mod_path_str)
            if mod_full.exists():
                try:
                    content = mod_full.read_text(errors="ignore")
                    total_words += len(content.split())
                except Exception:
                    pass

    # Compressed words is what we have; raw estimate is ~10x (compression ratio)
    compressed_words = total_words if total_words > 0 else len(modules) * 100
    estimated_raw = compressed_words * 10
    if compressed_words > 0:
        compression_ratio = estimated_raw / compressed_words
        token_savings = int((1 - 1 / compression_ratio) * 100)
    else:
        compression_ratio = 0
        token_savings = 0

    # ── Sessions ──
    sessions_info = []
    sessions_dir = ctx_path / "sessions"
    if sessions_dir.exists():
        session_files = sorted(sessions_dir.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
        for sf in session_files[:5]:
            try:
                with open(sf) as f:
                    sd = json.load(f)
                status = sd.get("status", "UNKNOWN")
                contributors = len(sd.get("participants", sd.get("contributors", [])))
                name = sd.get("name", sf.stem)
                closure = sd.get("closure_summary", "")
                sessions_info.append({
                    "name": name,
                    "status": status,
                    "contributors": contributors,
                    "closure": closure,
                })
            except Exception:
                sessions_info.append({"name": sf.stem, "status": "?", "contributors": 0, "closure": ""})

    # ── Health (graceful degradation) ──
    health_detected = 0
    health_healthy = 0
    health_available = False
    try:
        from seif.bridge.ai_bridge import detect_backends
        from seif.bridge.backend_health import get_healthy_backends
        detected = detect_backends()
        healthy = get_healthy_backends(detected)
        health_detected = len(detected)
        health_healthy = len(healthy)
        health_available = True
    except ImportError:
        pass
    except Exception:
        pass

    # ── Git log ──
    git_lines = []
    git_dir = ctx_path / ".git"
    if git_dir.exists():
        try:
            result = subprocess.run(
                ["git", "-C", str(ctx_path), "log", "--oneline", "--no-color", "-5"],
                capture_output=True, text=True, timeout=5,
            )
            if result.returncode == 0 and result.stdout.strip():
                git_lines = result.stdout.strip().splitlines()
        except Exception:
            pass

    # ── Build report using ResonanceReport ──
    subtitle = f"{ws_name} — {project_count} projects, {len(modules)} modules"
    report = ResonanceReport("SEIF REPORT", subtitle)

    # Owner info
    report.section("")
    report.kv("Owner", owner_name)

    # Context efficiency
    report.section("Context Efficiency")
    if compression_ratio > 0:
        report.metric(min(compression_ratio / 10.0, 1.0), f"compression {int(compression_ratio)}:1")
        report.kv("Compressed", f"~{compressed_words:,} words")
        report.kv("Raw estimate", f"~{estimated_raw:,}+")
        report.kv("Token savings", f"~{token_savings}%")
    else:
        report.metric(0, "no modules found")

    # Sessions
    if sessions_info:
        report.section(f"Sessions (last {len(sessions_info)})")
        for s in sessions_info:
            marker = "●" if s["status"] in ("CLOSED", "OPEN") and s["status"] == "OPEN" else "○"
            if s["status"] == "OPEN":
                marker = "●"
            line = f"{s['name']:<20} {s['status']:<8} {s['contributors']} contributors"
            if s["closure"]:
                closure_short = s["closure"][:60] + ("..." if len(s["closure"]) > 60 else "")
                line += f"  closure: {closure_short}"
            report.item(line, marker=marker)

    # Health
    report.section("Health")
    if health_available:
        ratio = health_healthy / health_detected if health_detected else 0
        report.metric(ratio, f"{health_healthy}/{health_detected} backends healthy")
    else:
        report.kv("Status", "N/A (seif-engine not installed)")

    # Recent changes
    if git_lines:
        report.section("Recent Changes")
        for gl in git_lines:
            report.item(gl)

    print(report.render())


def cmd_absorb(target_path: str, context_repo: str = None,
               author: str = "seif-absorb", name: str = None):
    """Absorb knowledge from any directory into the current .seif context.

    This is the 'git add' of SEIF — it takes knowledge from a source directory
    and integrates it into the .seif/ structure with proper provenance and
    registration in the global registry.

    For code directories (with pyproject.toml, package.json, etc):
        Uses semantic code compression (93% reduction).
    For other directories:
        Uses file extraction (markdown, text, configs).
    """
    from pathlib import Path
    import json

    target = Path(target_path).resolve()
    if not target.exists():
        print(f"Error: Path not found: {target}")
        return

    # Find or create .seif context
    try:
        from seif.context.autonomous import find_context_repo
        ctx = context_repo or find_context_repo() or ".seif"
    except ImportError:
        ctx = context_repo or ".seif"

    ctx_path = Path(ctx).resolve()
    ctx_path.mkdir(parents=True, exist_ok=True)

    source_name = name or target.name
    is_code_project = any(
        (target / m).exists()
        for m in ["pyproject.toml", "package.json", "Cargo.toml", "go.mod",
                   "Makefile", "CMakeLists.txt", "pom.xml", "build.gradle"]
    )

    print(f"═══ SEIF ABSORB ═══")
    print(f"  Source:  {target}")
    print(f"  Context: {ctx_path}")
    print(f"  Mode:    {'code compression' if is_code_project else 'knowledge extraction'}")
    print()

    if is_code_project:
        # Semantic code compression
        try:
            from seif.context.code_compressor import compress_project
        except ImportError:
            print("Code compression requires: pip install seif-cli")
            return

        project_dir = ctx_path / "projects" / source_name
        project_dir.mkdir(parents=True, exist_ok=True)
        target_file = str(project_dir / "code.seif")

        module, path = compress_project(
            str(target), author=author, target_path=target_file
        )
        print(f"  Project: {source_name}")
        print(f"  Files:   {module.original_words} LOC")
        print(f"  Compressed: {module.compressed_words} words")
        print(f"  Ratio:   {module.compression_ratio}:1")
        print(f"  Hash:    {module.integrity_hash}")
        print(f"  Saved:   {path}")

        # Also sync git context if available
        if (target / ".git").exists():
            try:
                from seif.context.git_context import sync_project
                proj_seif = str(project_dir / "project.seif")
                git_module, git_path = sync_project(
                    str(target), author=author, target_path=proj_seif
                )
                print(f"  Git ctx: {git_path} ({git_module.compressed_words} words)")
            except Exception as e:
                print(f"  Git ctx: skipped ({e})")

    else:
        # Knowledge extraction from files
        try:
            from seif.context.file_extractor import scan_directory, build_extract_module
        except ImportError:
            # Fallback: use code compressor for any directory
            try:
                from seif.context.code_compressor import compress_project
                project_dir = ctx_path / "projects" / source_name
                project_dir.mkdir(parents=True, exist_ok=True)
                target_file = str(project_dir / "code.seif")
                module, path = compress_project(
                    str(target), author=author, target_path=target_file
                )
                print(f"  Absorbed: {path} ({module.compressed_words} words)")
            except ImportError:
                print("Extraction requires: pip install seif-cli")
            return

        files = scan_directory(target)
        if not files:
            print("  No supported files found.")
            return

        by_type = {}
        for f in files:
            by_type[f.file_type] = by_type.get(f.file_type, 0) + 1
        for ft, count in sorted(by_type.items()):
            print(f"  {ft}: {count} files")

        module = build_extract_module(files, source_name)
        if module:
            modules_dir = ctx_path / "modules"
            modules_dir.mkdir(parents=True, exist_ok=True)
            out_path = modules_dir / f"{source_name}.seif"
            with open(out_path, "w", encoding="utf-8") as f:
                json.dump(module, f, indent=2, ensure_ascii=False)
            print(f"\n  Absorbed: {out_path}")
            print(f"  Words: {module.get('metadata', {}).get('word_count', '?')}")
        else:
            print("  No extractable content found.")
            return

    # Register in global registry
    try:
        from seif.context.registry import register_context
        entry = register_context(str(ctx_path))
        print(f"\n  Registry: {entry['name']} (in ~/.seif/registry.json)")
    except Exception:
        pass

    print()
    print("Next:")
    print(f"  seif --list                  — see all contexts")
    print(f"  seif --quality-gate \"text\"   — measure quality")
    print(f"  seif --sync                  — re-sync after changes")


# ── Agent Roles & Start ─────────────────────────────────────────────────────

_AGENT_ROLES_FILE = "agent-roles-v1.seif"
_DEFAULT_ROLES = {
    "writer":       {"agent": "copilot",   "fallback": "claude"},
    "vigilant":     {"agent": "claude",    "fallback": "copilot"},
    "sentinel":     {"agent": "claude",    "fallback": "grok"},
    "orchestrator": {"agent": "copilot",   "fallback": "claude"},
    "researcher":   {"agent": "grok",      "fallback": "gemini"},
}
_KNOWN_AGENTS = ["copilot", "claude", "grok", "gemini", "opencode", "deepseek", "cursor", "windsurf"]

# Tier-1 canonical agent-role schema per SEIF.md → Agent Roles (Two-Axis Taxonomy).
# Workspaces may declare tier-2 roles in their agent-roles module, but tier-1 is invariant
# across SEIF deployments. --agents-set rejects non-tier-1 names with a helpful error.
_TIER1_AGENT_ROLES = (
    "maestro", "writer", "executor", "vigilant",
    "sentinel", "researcher", "analyst", "gatekeeper",
)


def _agent_roles_path(ctx_repo: str | None) -> str:
    """Resolve the agent-roles module path.

    Tolerates ctx_repo=None: falls back to the current working directory's
    .seif/modules/ if it exists, else ~/.seif/modules/. Without this
    fallback, --agents and --agents-set crash with TypeError when invoked
    outside an active context repo.
    """
    import os
    if ctx_repo:
        return os.path.join(ctx_repo, "modules", _AGENT_ROLES_FILE)
    cwd_modules = os.path.join(os.getcwd(), ".seif", "modules")
    if os.path.isdir(cwd_modules):
        return os.path.join(cwd_modules, _AGENT_ROLES_FILE)
    home_modules = os.path.join(os.path.expanduser("~"), ".seif", "modules")
    return os.path.join(home_modules, _AGENT_ROLES_FILE)


def _load_agent_roles(ctx_repo: str) -> dict:
    import json, os
    path = _agent_roles_path(ctx_repo)
    if os.path.exists(path):
        try:
            with open(path) as f:
                data = json.load(f)
            return data.get("roles", _DEFAULT_ROLES)
        except Exception:
            pass
    return dict(_DEFAULT_ROLES)


def _save_agent_roles(ctx_repo: str, roles: dict, authored_by: str = "") -> None:
    import json, os
    from datetime import datetime, timezone
    if not authored_by:
        try:
            from seif.context.nucleus import load_profile
            authored_by = load_profile().get("name", "unknown") or "unknown"
        except Exception:
            authored_by = "unknown"
    path = _agent_roles_path(ctx_repo)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    module = {
        "_instruction": "Workspace agent role assignments. Owner-only write. Propagates to all collaborators.",
        "protocol": "SEIF-MODULE-v2",
        "module_id": "agent-roles-v1",
        "classification": "INTERNAL",
        "decay_exempt": True,
        "governance": {
            "authored_by": authored_by,
            "collaborator_override": False,
            "propagates_to_all": True,
            "note": "Only workspace-owner can write this module. All collaborators inherit these assignments."
        },
        "roles": roles,
        "known_agents": _KNOWN_AGENTS,
        "updated_at": datetime.now(timezone.utc).isoformat(),
        "integrity_hash": f"agent-roles-{datetime.now(timezone.utc).strftime('%Y%m%d%H%M')}"
    }
    with open(path, "w") as f:
        json.dump(module, f, indent=2)


def _cmd_agents_show(ctx_repo: str) -> None:
    roles = _load_agent_roles(ctx_repo)
    print("╔══ SEIF AGENT ROLES ═══════════════════════════════╗")
    for role, cfg in roles.items():
        agent = cfg.get("agent", "—") if isinstance(cfg, dict) else cfg
        fallback = cfg.get("fallback", "—") if isinstance(cfg, dict) else "—"
        avail = _check_agent_available(agent)
        icon = "✅" if avail else "⚠ "
        fb_note = f"  (fallback: {fallback})" if not avail else ""
        print(f"  {icon} {role:<14} → {agent}{fb_note}")
    print("╚═══════════════════════════════════════════════════╝")
    print("  Set with: seif --agents-set ROLE=AGENT")
    print(f"  Known agents: {', '.join(_KNOWN_AGENTS)}")


def _check_agent_available(agent: str) -> bool:
    """Best-effort availability check — checks if agent binary/process exists."""
    import shutil
    checks = {
        "copilot": ["gh", "copilot"],
        "claude":  ["claude"],
        "cursor":  ["cursor"],
        "windsurf": ["windsurf"],
    }
    bins = checks.get(agent, [agent])
    return any(shutil.which(b) for b in bins)


def _cmd_agents_set(assignment: str, ctx_repo: str) -> None:
    if "=" not in assignment:
        print(f"⚠  Format: ROLE=AGENT  (e.g. writer=claude)")
        return
    role, agent = assignment.split("=", 1)
    role, agent = role.strip().lower(), agent.strip().lower()
    if role not in _TIER1_AGENT_ROLES:
        print(f"⚠  Unknown agent role '{role}'. Tier-1 canonical roles: "
              f"{', '.join(_TIER1_AGENT_ROLES)}.")
        print(f"   See SEIF.md → Agent Roles (Two-Axis Taxonomy). "
              f"Workspaces may declare tier-2 roles in their agent-roles module, "
              f"but --agents-set only writes tier-1 assignments.")
        return
    if agent not in _KNOWN_AGENTS:
        print(f"⚠  Unknown agent '{agent}'. Known: {', '.join(_KNOWN_AGENTS)}")
        return
    roles = _load_agent_roles(ctx_repo)
    old = roles.get(role, {})
    old_agent = old.get("agent", "—") if isinstance(old, dict) else old
    roles[role] = {"agent": agent, "fallback": old_agent if old_agent != agent else "copilot"}
    _save_agent_roles(ctx_repo, roles)
    print(f"╔══ AGENT ROLE UPDATED ══════════════════════════════╗")
    print(f"  {role:<14} → {agent}  (previous: {old_agent})")
    print(f"  Saved to: {_agent_roles_path(ctx_repo)}")
    print(f"  Propagates to all workspace collaborators.")
    print(f"╚════════════════════════════════════════════════════╝")


# ── Pending Modules CLI (gap-14 / branch-7 of s32) ──────────────────────────

def _detect_current_workspace_id() -> Optional[str]:
    """Return the current workspace's name as registered in ~/.seif/registry.json,
    or None if the cwd is not a known workspace.
    """
    try:
        from seif.context.registry import load_registry, find_context_entry
        cwd = os.getcwd()
        seif_dir = os.path.join(cwd, ".seif")
        if not os.path.isdir(seif_dir):
            return None
        registry = load_registry()
        entry = find_context_entry(registry, seif_dir)
        return entry.get("name") if entry else None
    except Exception:
        return None


def _cmd_pending_list(all_workspaces: bool = False) -> None:
    """List pending modules from the global registry.

    Default scope: pendings whose target_workspace == current workspace
    plus any owner-targeted pendings. With --all-workspaces: every pending
    in the registry, regardless of target.
    """
    from seif.context.registry import load_registry, list_open_pendings, resolve_pending_path

    registry = load_registry()
    current = _detect_current_workspace_id()

    if all_workspaces:
        from seif.context.registry import read_pending_status
        entries = []
        for raw in registry.get("pending_modules", []):
            augmented = dict(raw)
            augmented["_status"] = read_pending_status(registry, raw)
            augmented["_resolved_path"] = resolve_pending_path(registry, raw)
            entries.append(augmented)
    else:
        entries = list_open_pendings(registry, current_workspace_id=current)

    print("╔══ SEIF PENDING MODULES ═══════════════════════════╗")
    if current:
        print(f"  Current workspace : {current}")
    else:
        print("  Current workspace : (cwd not a registered .seif workspace)")
    print(f"  Scope             : {'ALL' if all_workspaces else 'current + owner'}")
    print(f"  Total entries     : {len(entries)}")
    if not entries:
        print("  (no open pendings — protocol resonance clean)")
        print("╚═══════════════════════════════════════════════════╝")
        return

    for e in entries:
        path = e.get("_resolved_path") or resolve_pending_path(registry, e)
        status = e.get("_status", "?")
        print(f"  · {e.get('module_id')}")
        print(f"      target_workspace : {e.get('target_workspace')}")
        print(f"      target_consumer  : {e.get('target_consumer')}")
        print(f"      status           : {status}")
        if path:
            print(f"      path             : {path}")
        else:
            print(f"      path             : <unresolved>")
    print("╚═══════════════════════════════════════════════════╝")
    print("  Consume with: seif --pending-consume <module_id> [--consumed-in-cycle CYCLE]")


def _cmd_pending_register(module_path: str, visibility_override: Optional[str] = None) -> None:
    """Register a pending module into the global registry.

    Required fields in the module: module_id, target_consumer.
    Visibility is determined in this order:
      1. --visibility CLI override
      2. module's "visibility" field
      3. inferred from file path:
         - under ~/.seif/ → personal
         - under <workspace>/.seif/ → team
    """
    from seif.context.registry import (
        load_registry, save_registry, register_pending_module,
        find_context_entry, get_user_home
    )

    path = Path(module_path).resolve()
    if not path.exists():
        print(f"Error: file not found: {path}")
        return
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        print(f"Error: not valid JSON: {exc}")
        return

    module_id = data.get("module_id")
    target_consumer = data.get("target_consumer")
    if not module_id or not target_consumer:
        print("Error: pending module must declare module_id and target_consumer. "
              "See SEIF.md → Pending Modules.")
        return

    user_home = get_user_home()
    user_home_resolved = user_home.resolve()
    visibility = visibility_override or data.get("visibility")
    stored_in_workspace = data.get("stored_in_workspace")
    target_workspace = data.get("target_workspace")
    workspace_relative_path = data.get("workspace_relative_path")

    is_under_personal = _is_under(path, user_home) or _is_under(path, user_home_resolved)
    if visibility == "personal" or (visibility is None and is_under_personal):
        visibility = "personal"
        if not workspace_relative_path:
            for base in (user_home, user_home_resolved):
                try:
                    workspace_relative_path = str(path.relative_to(base))
                    break
                except ValueError:
                    continue
            if not workspace_relative_path:
                print(f"Error: visibility=personal requires file under {user_home}")
                return
        stored_in_workspace = None
        target_workspace = None
    else:
        visibility = "team"
        if not stored_in_workspace or not workspace_relative_path:
            registry = load_registry()
            current = path
            for _ in range(20):
                candidate = current / ".seif"
                if candidate.is_dir():
                    entry = find_context_entry(registry, str(candidate))
                    if entry:
                        stored_in_workspace = entry.get("name")
                        workspace_relative_path = str(path.relative_to(current))
                    break
                if current.parent == current:
                    break
                current = current.parent
            if not stored_in_workspace or not workspace_relative_path:
                print("Error: visibility=team requires the file to live under a "
                      "registered workspace's .seif/ tree, or explicit "
                      "stored_in_workspace + workspace_relative_path fields.")
                return
        if not target_workspace:
            target_workspace = stored_in_workspace

    registry = load_registry()
    register_pending_module(
        registry,
        module_id=module_id,
        visibility=visibility,
        workspace_relative_path=workspace_relative_path,
        stored_in_workspace=stored_in_workspace,
        target_workspace=target_workspace,
        target_consumer=target_consumer,
        target_cycle_pattern=data.get("target_cycle_pattern", "any"),
        discovered_at=data.get("discovered_at"),
    )
    save_registry(registry)
    print(f"╔══ PENDING MODULE REGISTERED ═══════════════════════╗")
    print(f"  module_id         : {module_id}")
    print(f"  visibility        : {visibility}")
    if visibility == "team":
        print(f"  stored_in         : {stored_in_workspace}")
        print(f"  target_workspace  : {target_workspace}")
    print(f"  target_consumer   : {target_consumer}")
    print(f"╚════════════════════════════════════════════════════╝")


def _is_under(child: Path, parent: Path) -> bool:
    try:
        child.relative_to(parent)
        return True
    except ValueError:
        return False


# ── Delegation CLI (gap-6 / branch-3 of s32) ────────────────────────────────

def _cmd_delegate_to(
    ssh_host: str,
    agent_name: Optional[str],
    seed_path: Optional[str],
    outbox_path: Optional[str],
    timeout_sec: int,
) -> None:
    """Thin wrapper around seif_engine.orchestration.delegate_to_host.

    The heavy lifting (SSH, outbox framing, structured result) lives in
    seif-engine. This CLI surface validates required args, picks a
    sensible default outbox, and prints a human-readable summary.
    """
    if not agent_name:
        print("Error: --delegate-to requires --as-agent <name>")
        return
    if not seed_path:
        print("Error: --delegate-to requires --seed <path>")
        return

    try:
        from seif_engine.orchestration import delegate_to_host
    except ImportError:
        print("Error: seif-engine not installed. Install via "
              "`pip install seif-engine` or `pip install -e <path-to-seif-engine>`.")
        return

    seed = Path(seed_path).expanduser().resolve()
    if outbox_path:
        outbox = Path(outbox_path).expanduser().resolve()
    else:
        from datetime import datetime, timezone
        ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        outbox_dir = Path.cwd() / ".seif" / "outbox"
        outbox_dir.mkdir(parents=True, exist_ok=True)
        outbox = outbox_dir / f"{agent_name}-{ts}.log"

    print(f"╔══ SEIF DELEGATION ═════════════════════════════════╗")
    print(f"  ssh_host    : {ssh_host}")
    print(f"  agent_name  : {agent_name}")
    print(f"  seed        : {seed}")
    print(f"  outbox      : {outbox}")
    print(f"  timeout     : {timeout_sec}s")
    print(f"  → invoking SSH...")

    result = delegate_to_host(
        ssh_host=ssh_host,
        agent_name=agent_name,
        seed_path=seed,
        outbox_path=outbox,
        timeout_sec=timeout_sec,
    )

    print(f"╠══ RESULT ══════════════════════════════════════════╣")
    print(f"  ok          : {result.ok}")
    print(f"  exit_code   : {result.exit_code}")
    print(f"  duration    : {result.duration_sec}s")
    if result.error:
        print(f"  error       : {result.error}")
    print(f"  outbox file : {result.outbox_path}")
    print(f"╚════════════════════════════════════════════════════╝")


# ── Vigilant Watches CLI (gap-7 / s33 branch-3) ─────────────────────────────


def _cmd_vigilant_watch(
    pattern: str,
    notify_action: str,
    notify_target: Optional[str],
    watch_id: Optional[str],
) -> None:
    """Register a new watch in the vigilant registry. Thin wrapper around
    seif_engine.vigilant.watch_registry.add_watch."""
    try:
        from seif_engine.vigilant import watch_registry as wr
    except ImportError:
        print("Error: seif-engine not installed. Install via "
              "`pip install seif-engine` or `pip install -e <path-to-seif-engine>`.")
        return

    if not notify_target:
        print("Error: --vigilant-watch requires --notify-target <path>")
        return

    try:
        watch = wr.add_watch(
            pattern=pattern,
            notify_action=notify_action,
            notify_target=notify_target,
            watch_id=watch_id,
        )
    except ValueError as e:
        print(f"Error: {e}")
        return

    print("╔══ SEIF VIGILANT WATCH REGISTERED ══════════════════╗")
    print(f"  watch_id      : {watch.watch_id}")
    print(f"  pattern_type  : {watch.pattern_type}")
    print(f"  pattern       : {watch.pattern}")
    print(f"  notify_action : {watch.notify_action}")
    print(f"  notify_target : {watch.notify_target}")
    print(f"  status        : {watch.status}")
    print(f"  registry      : {wr.default_registry_path()}")
    print("╚════════════════════════════════════════════════════╝")
    print("  Daemon will dispatch on next tick (start with `seif-vigilant start`).")


def _cmd_vigilant_list(status_filter: Optional[str] = None) -> None:
    try:
        from seif_engine.vigilant import watch_registry as wr
    except ImportError:
        print("Error: seif-engine not installed.")
        return

    watches = wr.list_watches(status=status_filter)
    print("╔══ SEIF VIGILANT WATCHES ═══════════════════════════╗")
    print(f"  Registry : {wr.default_registry_path()}")
    if status_filter:
        print(f"  Filter   : status == {status_filter}")
    print(f"  Total    : {len(watches)}")
    if not watches:
        print("  (no watches registered)")
        print("╚════════════════════════════════════════════════════╝")
        return
    for w in watches:
        print(f"  · {w.get('watch_id')}  [{w.get('status')}]")
        print(f"      {w.get('pattern_type'):<10} → {w.get('pattern')}")
        print(f"      notify: {w.get('notify_action')} → {w.get('notify_target')}")
        if w.get("last_dispatched_at"):
            print(f"      last fired: {w.get('last_dispatched_at')}  match={w.get('last_match')}")
    print("╚════════════════════════════════════════════════════╝")


def _cmd_vigilant_stop(watch_id: str) -> None:
    try:
        from seif_engine.vigilant import watch_registry as wr
    except ImportError:
        print("Error: seif-engine not installed.")
        return

    removed = wr.remove_watch(watch_id)
    if removed:
        print(f"vigilant: removed watch {watch_id!r}")
    else:
        print(f"vigilant: no watch with id {watch_id!r} (run --vigilant-list to inspect)")


def _cmd_pending_consume(module_id: str, consumed_in_cycle: Optional[str] = None) -> None:
    """Mark a registered pending module as consumed."""
    from seif.context.registry import load_registry, find_pending_modules, mark_pending_consumed

    registry = load_registry()
    matches = [e for e in registry.get("pending_modules", [])
               if e.get("module_id") == module_id]
    if not matches:
        print(f"Error: no pending module with id {module_id!r} in registry.")
        print("       Run `seif --pending-list --all-workspaces` to see what is registered.")
        return

    entry = matches[0]
    ok = mark_pending_consumed(registry, entry, consumed_in_cycle=consumed_in_cycle)
    if not ok:
        print(f"Error: source module file is missing or unreadable. Index left intact.")
        return
    print(f"╔══ PENDING MODULE CONSUMED ═════════════════════════╗")
    print(f"  module_id         : {module_id}")
    if consumed_in_cycle:
        print(f"  consumed_in_cycle : {consumed_in_cycle}")
    print(f"╚════════════════════════════════════════════════════╝")


def _cmd_self_update() -> None:
    """Run ~/.seif/bin/seif-update.sh — declarative per-host update.

    Reads ~/.seif/host-install-config.seif and dispatches the right install
    command (editable / pipx / etc.). Wraps the bash script that already
    works rather than reinventing the dispatch in Python — gap-10 was about
    removing per-device friction, not adding a new dependency.
    """
    import subprocess
    from pathlib import Path
    wrapper = Path.home() / ".seif" / "bin" / "seif-update.sh"
    if not wrapper.exists():
        print(f"Error: {wrapper} not found.")
        print("       This host is not configured for self-update yet.")
        print("       See docs/seif-cli-reference.md §41.5 for setup.")
        return
    try:
        result = subprocess.run([str(wrapper)], check=False)
        if result.returncode != 0:
            print(f"seif-update exited with status {result.returncode}")
    except Exception as exc:
        print(f"Error running self-update: {exc}")


# ─── s43 B4: host-install-config schema migration ──────────────────────────
# Hardcoded schema-bump descriptors. v1→v2 added three optional fields with
# permissive defaults. Future bumps (v3+) just add another entry here.

_HOST_CONFIG_MIGRATIONS = {
    # source_version → { target_version, target_protocol, fields_added }
    "SEIF-HOST-INSTALL-CONFIG-v1": {
        "target_version": "v2",
        "target_protocol": "SEIF-HOST-INSTALL-CONFIG-v2",
        "fields_added": [
            {
                "name": "package_source",
                "default": "pypi",
                "summary": (
                    "How pipx finds the package. 'pypi' uses pipx upgrade "
                    "(version-bump-aware). 'git+<url>' uses pipx install --force "
                    "(required when pyproject version is unchanged on git source)."
                ),
                "examples": ["pypi", "git+https://github.com/and2carvalho/seif.git@main"],
                "validator": lambda v: v == "pypi" or v.startswith("git+"),
                "applies_to_methods": ("pipx",),  # editable hosts always use 'pypi'
            },
            {
                "name": "bridge_repo",
                "default": {"method": "none"},
                "summary": (
                    "Per-host bridge sync. method=git: git pull --ff-only on "
                    "source_path. method=rsync: rsync from upstream into "
                    "source_path. method=none: skip (host doesn't run bridge "
                    "daemons)."
                ),
                "nested": True,
            },
            {
                "name": "restart_jobs",
                "default": ["com.seif.*"],
                "summary": (
                    "launchctl/systemctl patterns to restart after package + "
                    "bridge sync. Default catches all com.seif.* daemons."
                ),
                "csv_parse": True,
            },
        ],
    },
}


def _prompt_bridge_repo(install_method: str, take_defaults: bool) -> dict:
    """Interactive prompt for the v2 bridge_repo nested object.

    take_defaults=True (--yes) → returns {'method': 'none'} without prompting.
    """
    if take_defaults:
        return {"method": "none"}
    print("")
    print("  bridge_repo: per-host bridge sync configuration")
    print("    method=git    → git pull on a local clone of seif-resonance-bridge")
    print("    method=rsync  → rsync from upstream remote (e.g. user@mini:/path/)")
    print("    method=none   → skip (host doesn't run bridge daemons)")
    method = input("    method [none]: ").strip() or "none"
    if method not in ("git", "rsync", "none"):
        print(f"    ⚠ unknown method '{method}', falling back to 'none'")
        return {"method": "none"}
    if method == "none":
        return {"method": "none"}
    source_path = input("    source_path (absolute path to local bridge repo): ").strip()
    if not source_path:
        print("    ⚠ source_path empty, falling back to method=none")
        return {"method": "none"}
    upstream = input(
        "    upstream (git URL for method=git, rsync target for method=rsync): "
    ).strip()
    out = {"method": method, "source_path": source_path}
    if upstream:
        out["upstream"] = upstream
    return out


def _cmd_migrate_host_config(
    target_version: str = "v2",
    config_path = None,
    dry_run: bool = False,
    yes: bool = False,
    backup: bool = True,
) -> int:
    """Interactive migration tool for ~/.seif/host-install-config.seif.

    Reads current config, compares declared protocol against latest known
    schema, prompts for new fields (or uses defaults with --yes), writes
    back atomically with optional .bak backup. Per-host run.

    Returns exit code: 0 success, 1 user error / no-op, 2 unknown protocol.
    """
    import json as _json
    import os as _os
    from pathlib import Path

    cfg_path = Path(config_path) if config_path else Path.home() / ".seif" / "host-install-config.seif"

    if not cfg_path.exists():
        print(f"✗ config not found: {cfg_path}")
        print("  Bootstrap first — see scripts/host/README.md or docs/seif-cli-reference.md §41.5.")
        return 1

    try:
        current = _json.loads(cfg_path.read_text())
    except _json.JSONDecodeError as exc:
        print(f"✗ malformed JSON in {cfg_path}: {exc}")
        return 1

    current_protocol = current.get("protocol", "")
    if not current_protocol.startswith("SEIF-HOST-INSTALL-CONFIG-"):
        print(f"✗ unrecognized protocol: {current_protocol!r}")
        print("  Expected: SEIF-HOST-INSTALL-CONFIG-vN")
        return 2

    target_protocol = f"SEIF-HOST-INSTALL-CONFIG-{target_version}"
    if current_protocol == target_protocol:
        print(f"✓ already at {target_protocol} — no migration needed.")
        return 0

    migration = _HOST_CONFIG_MIGRATIONS.get(current_protocol)
    if migration is None or migration["target_protocol"] != target_protocol:
        print(f"✗ no migration path from {current_protocol} → {target_protocol}")
        print(f"  Known migrations: {list(_HOST_CONFIG_MIGRATIONS.keys())}")
        return 2

    install_method = current.get("install_method", "editable")
    print(f"╔══ MIGRATE HOST CONFIG ═══════════════════════════════╗")
    print(f"  path:    {cfg_path}")
    print(f"  from:    {current_protocol}")
    print(f"  to:      {target_protocol}")
    print(f"  method:  {install_method}")
    print(f"  mode:    {'dry-run' if dry_run else 'write'}{' (--yes)' if yes else ' (interactive)'}")
    print(f"╚══════════════════════════════════════════════════════╝")

    new_fields = {}
    skipped = []
    for field in migration["fields_added"]:
        name = field["name"]
        if name in current:
            skipped.append(f"{name} (already present)")
            continue
        applies = field.get("applies_to_methods")
        if applies and install_method not in applies:
            new_fields[name] = field["default"]
            skipped.append(f"{name} (default {field['default']!r}, doesn't apply to {install_method})")
            continue
        if yes:
            if name == "bridge_repo":
                new_fields[name] = _prompt_bridge_repo(install_method, take_defaults=True)
            else:
                new_fields[name] = field["default"]
            continue
        # Interactive prompt
        print(f"\n  {name}: {field['summary']}")
        if field.get("examples"):
            print(f"    examples: {', '.join(field['examples'])}")
        if field.get("nested"):
            new_fields[name] = _prompt_bridge_repo(install_method, take_defaults=False)
            continue
        default_repr = (
            ",".join(field["default"]) if field.get("csv_parse") and isinstance(field["default"], list)
            else str(field["default"])
        )
        raw = input(f"    {name} [{default_repr}]: ").strip()
        if not raw:
            new_fields[name] = field["default"]
            continue
        if field.get("csv_parse"):
            new_fields[name] = [p.strip() for p in raw.split(",") if p.strip()]
        elif field.get("validator") and not field["validator"](raw):
            print(f"    ⚠ invalid value, using default {field['default']!r}")
            new_fields[name] = field["default"]
        else:
            new_fields[name] = raw

    print("\n╔══ DIFF ═════════════════════════════════════════════╗")
    print(f"  protocol: {current_protocol} → {target_protocol}")
    for k, v in new_fields.items():
        print(f"  + {k}: {_json.dumps(v)}")
    if skipped:
        print(f"  skipped:")
        for s in skipped:
            print(f"    - {s}")
    print("╚══════════════════════════════════════════════════════╝")

    if dry_run:
        print("\n→ dry-run: no changes written.")
        return 0

    # Build merged config: keep all existing fields, add new ones, bump protocol
    merged = dict(current)
    merged["protocol"] = target_protocol
    for k, v in new_fields.items():
        merged[k] = v
    merged["migrated_at"] = _datetime_utc_now_iso()
    merged["migrated_from"] = current_protocol

    # Backup
    if backup:
        bak_path = cfg_path.with_name(cfg_path.name + f".{migration['target_version']}.bak.pre-migrate")
        # Avoid overwriting an existing .bak from a prior migration
        if bak_path.exists():
            bak_path = cfg_path.with_name(cfg_path.name + f".bak.{_os.getpid()}")
        bak_path.write_text(cfg_path.read_text())
        print(f"\n→ backup: {bak_path}")

    # Atomic write: tmp + replace
    tmp_path = cfg_path.with_name(cfg_path.name + f".tmp.{_os.getpid()}")
    tmp_path.write_text(_json.dumps(merged, indent=2) + "\n")
    _os.replace(str(tmp_path), str(cfg_path))
    print(f"→ wrote: {cfg_path}")
    print(f"\n✓ migration complete. Verify with:")
    print(f"    seif --self-update --check  (or ~/.seif/bin/seif-update.sh --check)")
    return 0


def _datetime_utc_now_iso() -> str:
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _cmd_release_broadcast(version: str, ctx_repo: str | None, notes: str = "") -> None:
    """Publish a release-vX.Y.Z.seif module to the writer's modules/ dir.

    Vigilants on peers detect the new file via --pending-list and may trigger
    --self-update under owner approval. Module is signed by the host that ran
    the broadcast.
    """
    import json
    from datetime import datetime, timezone
    from pathlib import Path

    if not version or not version.strip():
        print("Error: --release-broadcast requires a version string (e.g. 0.7.0)")
        return
    if version.startswith("v"):
        version = version[1:]

    if ctx_repo:
        modules_dir = Path(ctx_repo) / ".seif" / "modules"
    else:
        modules_dir = Path.home() / ".seif" / "modules"
    modules_dir.mkdir(parents=True, exist_ok=True)

    module_id = f"release-v{version}-broadcast"
    out = modules_dir / f"{module_id}.seif"
    payload = {
        "_instruction": "SEIF release broadcast — peers may detect via --pending-list and self-update.",
        "protocol": "SEIF-RELEASE-BROADCAST-v1",
        "module_id": module_id,
        "version": version,
        "broadcast_at": datetime.now(timezone.utc).isoformat(),
        "broadcast_by_host": Path.home().name,
        "notes": notes or f"v{version} available — run `seif --self-update` on each peer.",
        "consume_action": "seif --self-update",
        "classification": "INTERNAL",
        "decay_exempt": False,
    }
    out.write_text(json.dumps(payload, indent=2))
    print(f"╔══ RELEASE BROADCAST ═══════════════════════════════╗")
    print(f"  version       : v{version}")
    print(f"  module        : {out}")
    print(f"  next_step     : sign it (`seif --sign {out.name}`) and let")
    print(f"                  vigilant runtime distribute on each peer.")
    print(f"╚════════════════════════════════════════════════════╝")


def _cmd_sync_workspace(ctx_repo: str, host: str | None = None, dry_run: bool = False) -> None:
    """Sync all SEIF repos on a remote device (same local network, owner-only).

    Connects via SSH, detects all git repos under the remote workspace root,
    pulls each one from its configured GitHub origin, then runs seif absorb
    if seif is available on the remote.

    Security: only runs when called as the workspace owner (checks agent-roles
    authored_by). SSH host is resolved from: CLI arg → SEIF_SYNC_HOST env var
    → agent-roles-v1.seif sync_host field.
    """
    import os, json, subprocess, shutil

    WORKSPACE_ROOT = os.environ.get(
        "SEIF_WORKSPACE_ROOT",
        str(__import__("pathlib").Path.home() / "seif-admin")
    )
    REPOS = ["seif", "seif-engine", "seif-suite", "seif-context",
             "seif-internal", "seif-research", "seif-resonance-bridge",
             "seif-vscode-extension"]

    print("╔══ SEIF SYNC-WORKSPACE ═════════════════════════════╗")

    # ── 1. Resolve SSH host ──────────────────────────────────
    if not host:
        host = os.environ.get("SEIF_SYNC_HOST", "")
    if not host and ctx_repo:
        # Try to read from agent-roles module
        roles_path = os.path.join(ctx_repo, "modules", "agent-roles-v1.seif")
        if os.path.exists(roles_path):
            try:
                import re
                with open(roles_path) as f:
                    content = f.read()
                m = re.search(r"sync_host:\s*(.+)", content)
                if m:
                    host = m.group(1).strip()
            except Exception:
                pass

    if not host:
        print("  ⚠  No SSH host specified.")
        print("  Set via: --sync-workspace-host <host>")
        print("       or: export SEIF_SYNC_HOST=<host>")
        print("       or: add 'sync_host: <host>' to agent-roles-v1.seif")
        print("╚════════════════════════════════════════════════════╝")
        return

    print(f"  Host   : {host}")
    print(f"  Root   : {WORKSPACE_ROOT}")
    print(f"  Repos  : {', '.join(REPOS)}")
    if dry_run:
        print("  Mode   : DRY RUN (no changes)")
    print()

    # ── 2. Check SSH reachability ────────────────────────────
    if not dry_run:
        ping = subprocess.run(
            ["ssh", "-o", "ConnectTimeout=5", "-o", "BatchMode=yes",
             host, "echo ok"],
            capture_output=True, text=True
        )
        if ping.returncode != 0:
            print(f"  ✗ Cannot reach {host} via SSH.")
            print(f"    Ensure you are on the same network and SSH is enabled.")
            print("╚════════════════════════════════════════════════════╝")
            return
        print(f"  ✓ SSH connection to {host} confirmed")
        print()

    # ── 3. Build the remote script ───────────────────────────
    remote_script = f"""#!/bin/bash
set -e
ROOT="{WORKSPACE_ROOT}"
REPOS=({" ".join(REPOS)})
echo "── Remote sync starting on $(hostname) ──"
echo ""
for repo in "${{REPOS[@]}}"; do
  path="$ROOT/$repo"
  expanded_path=$(eval echo "$path")
  if [ ! -d "$expanded_path/.git" ]; then
    echo "  ⊘  $repo — not found or no .git"
    continue
  fi
  cd "$expanded_path"
  remote_url=$(git remote get-url origin 2>/dev/null || echo "")
  if [ -z "$remote_url" ]; then
    echo "  ⚠  $repo — no remote configured"
    continue
  fi
  branch=$(git branch --show-current 2>/dev/null || echo "main")
  before=$(git log --oneline -1 2>/dev/null | cut -c1-7)
  git fetch origin --quiet 2>&1 | head -1
  git pull origin "$branch" --ff-only --quiet 2>&1 | tail -1
  after=$(git log --oneline -1 2>/dev/null | cut -c1-7)
  if [ "$before" = "$after" ]; then
    echo "  ✓  $repo ($branch) — already up to date [$after]"
  else
    echo "  ↑  $repo ($branch) — $before → $after"
  fi
done
echo ""
# Absorb if seif is available
if command -v seif &>/dev/null; then
  echo "  🌀 Running seif absorb..."
  seif --cycle absorb 2>/dev/null | tail -3 || true
fi
echo ""
echo "── Sync complete on $(hostname) ──"
"""

    if dry_run:
        print("  [DRY RUN] Would run on remote:")
        print("  " + remote_script.replace("\n", "\n  ").strip())
        print()
        print("╚════════════════════════════════════════════════════╝")
        return

    # ── 4. Execute remote script via SSH ────────────────────
    result = subprocess.run(
        ["ssh", host, "bash -s"],
        input=remote_script, capture_output=False, text=True
    )

    print()
    if result.returncode == 0:
        print("  ✅ Workspace sync complete")
    else:
        print(f"  ⚠  Remote script exited with code {result.returncode}")

    # ── 5. Update agent-roles-v1.seif with sync timestamp ───
    if ctx_repo:
        roles_path = os.path.join(ctx_repo, "modules", "agent-roles-v1.seif")
    else:
        roles_path = None
    if roles_path and os.path.exists(roles_path):
        try:
            from datetime import datetime, timezone
            now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
            with open(roles_path) as f:
                content = f.read()
            import re
            if "last_sync_workspace:" in content:
                content = re.sub(
                    r"last_sync_workspace:.*",
                    f"last_sync_workspace: {now}",
                    content
                )
            else:
                content = content.rstrip() + f"\nlast_sync_workspace: {now}\n"
            with open(roles_path, "w") as f:
                f.write(content)
            print(f"\n  📝 last_sync_workspace → {now}")
        except Exception:
            pass

    print("╚════════════════════════════════════════════════════╝")


def _cmd_start(ctx_repo: str) -> None:
    import webbrowser, os, subprocess
    print("╔══ SEIF START ══════════════════════════════════════╗")

    # 1. Cycle status
    try:
        result = subprocess.run(
            ["python3", "-m", "seif.cli.cli", "--cycle", "status"],
            capture_output=True, text=True, cwd=os.path.dirname(ctx_repo)
        )
        print(result.stdout.strip())
    except Exception:
        print("  ⚠  Could not load cycle status")

    # 2. Agent roles
    print()
    _cmd_agents_show(ctx_repo)

    # 3. Open Suite in browser
    suite_url = os.environ.get("SEIF_SUITE_URL", "http://localhost:3000")
    print(f"\n  🌐 Opening SEIF Suite: {suite_url}")
    try:
        webbrowser.open(suite_url)
    except Exception:
        print(f"  ⚠  Could not open browser. Navigate to: {suite_url}")

    print("╚════════════════════════════════════════════════════╝")


def _cmd_sessions_active(as_json: bool = False) -> None:
    """List schema-valid session entries from .seif/sessions/active/.

    Read-only — never mutates the registry. Filters out:
      - unknown.json (handoff straggler that survives schema validation
        differently because `unknown` is not a valid UUID session_id)
      - handoff-*.json (these are NOT session entries; they are handoff
        artifacts that share the directory historically)
      - any *.json that fails SessionEntry schema validation (malformed
        JSON or missing required fields)

    Output:
      - default: pretty-printed table with session_id (truncated to 8
        chars), wrapper, host, started_at, cycle_id (or "—"), age
        (seconds since last_heartbeat, humanized).
      - --json: list of valid SessionEntry dicts (asdict() form).

    Skipped-file count is reported on stderr in both modes.
    """
    import json as _json
    import sys as _sys
    from dataclasses import asdict as _asdict
    from pathlib import Path as _Path
    from seif.plugins.core.session_registry import SessionEntry

    seif_dir = _Path.cwd() / ".seif"
    active_dir = seif_dir / "sessions" / "active"
    if not active_dir.is_dir():
        if as_json:
            print("[]")
        else:
            print("─── ACTIVE SESSIONS (0) ───────────────────────────────")
            if not seif_dir.is_dir():
                print("  (no .seif/ in cwd — run `seif --init` first)")
            else:
                print("  (no .seif/sessions/active/ — no sessions registered yet)")
            print("───────────────────────────────────────────────────────")
        return

    valid: list[dict] = []
    skipped = 0
    for f in sorted(active_dir.iterdir()):
        if not f.is_file() or f.suffix != ".json":
            continue
        # Explicit skip list: handoff stragglers + non-session artifacts.
        if f.name == "unknown.json":
            skipped += 1
            continue
        if f.name.startswith("handoff-"):
            skipped += 1
            continue
        # Schema validation: try to construct SessionEntry from the loaded
        # dict. Any failure (malformed JSON, missing field, wrong type) →
        # skip silently (counted in stderr summary).
        try:
            data = _json.loads(f.read_text(encoding="utf-8"))
        except (OSError, _json.JSONDecodeError):
            skipped += 1
            continue
        if not isinstance(data, dict):
            skipped += 1
            continue
        try:
            entry = SessionEntry(**data)
        except TypeError:
            skipped += 1
            continue
        valid.append(_asdict(entry))

    if as_json:
        print(_json.dumps(valid, indent=2))
    else:
        # Table output.
        print(f"─── ACTIVE SESSIONS ({len(valid)}) ─────────────────────")
        if not valid:
            print("  (no valid session entries)")
        else:
            # Header — exact substrings asserted by tests.
            header = (
                f"  {'session_id':<10} {'wrapper':<14} {'host':<14} "
                f"{'started_at':<22} {'cycle_id':<24} {'age':>10}"
            )
            print(header)
            print("  " + ("─" * (len(header) - 2)))
            import calendar as _cal
            import time as _time
            for e in valid:
                sid_short = (e.get("session_id") or "")[:8]
                wrapper = e.get("wrapper") or "?"
                host = e.get("host") or "?"
                started = e.get("started_at") or "?"
                cycle = e.get("cycle_id") or "—"
                hb = e.get("last_heartbeat") or ""
                try:
                    struct = _time.strptime(hb, "%Y-%m-%dT%H:%M:%SZ")
                    age_s = max(0, int(_time.time() - _cal.timegm(struct)))
                    if age_s < 60:
                        age = f"{age_s}s"
                    elif age_s < 3600:
                        age = f"{age_s // 60}m{age_s % 60}s"
                    else:
                        age = f"{age_s // 3600}h{(age_s % 3600) // 60}m"
                except (TypeError, ValueError):
                    age = "?"
                print(
                    f"  {sid_short:<10} {wrapper[:14]:<14} {host[:14]:<14} "
                    f"{started[:22]:<22} {cycle[:24]:<24} {age:>10}"
                )
        print("───────────────────────────────────────────────────────")

    if skipped:
        print(f"  (skipped {skipped} non-session / invalid file(s))",
              file=_sys.stderr)


def cmd_integrity_update(file_path: str, skip_sign: bool = False,
                         skip_stamp: bool = False, as_json: bool = False) -> int:
    """Atomic fingerprint→sign→stamp chain on a single .seif module.

    Resolves admin-docs Gaps 22/23/24/25/39/40 by ensuring all three integrity
    facts are simultaneously valid after this command returns. Returns exit
    code 0 on success, 1 on failure.
    """
    import sys as _sys
    from seif.core.integrity import update_integrity, INTEGRITY_VALID

    try:
        report = update_integrity(Path(file_path), skip_sign=skip_sign,
                                  skip_stamp=skip_stamp)
    except FileNotFoundError as e:
        print(f"Error: {e}", file=_sys.stderr)
        return 1

    if as_json:
        import json as _json
        print(_json.dumps(report.asdict(), indent=2))
    else:
        print(f"[orchestrator] {Path(file_path).name}:")
        print(f"  fingerprint: {report.fingerprint_value[:16]}... ({report.scope_version})")
        print(f"  signature:   {report.signature_status}")
        print(f"  .ots:        {report.stamp_status} {report.stamp_message}".rstrip())
        if report.skipped:
            print(f"  skipped:     {', '.join(report.skipped)}")
    return 0


def cmd_verify_integrity(file_path: str, as_json: bool = False) -> int:
    """Joined verify of fingerprint + signature + .ots stamp.

    Exit code: 0 if VALID; non-zero on PENDING/HALF_VALID/INVALID. The non-zero
    exit on PENDING is intentional — CI gates that depend on Bitcoin
    confirmation should explicitly --skip-stamp or check pending status
    via --json output.
    """
    import sys as _sys
    from seif.core.integrity import (
        verify_integrity, INTEGRITY_VALID, INTEGRITY_PENDING,
        INTEGRITY_HALF_VALID, INTEGRITY_INVALID,
    )

    try:
        verdict = verify_integrity(Path(file_path))
    except FileNotFoundError as e:
        print(f"Error: {e}", file=_sys.stderr)
        return 1

    if as_json:
        import json as _json
        print(_json.dumps(verdict.asdict(), indent=2))
    else:
        print(f"[verify] {Path(file_path).name}:")
        scope_note = f", scope={verdict.fingerprint_scope}" if verdict.fingerprint_scope else ""
        print(f"  fingerprint: {verdict.fingerprint}{scope_note}")
        sig_note = f" (key fp {verdict.signature_key})" if verdict.signature_key else ""
        print(f"  signature:   {verdict.signature}{sig_note}")
        stamp_note = f" — {verdict.stamp_message}" if verdict.stamp_message else ""
        print(f"  .ots:        {verdict.stamp}{stamp_note}")
        print(f"Overall: {verdict.overall}")

    if verdict.overall == INTEGRITY_VALID:
        return 0
    return 1


def cmd_migrate_integrity(directory: str, exclude_from: str = None,
                          skip_stamp: bool = False, as_json: bool = False) -> int:
    """Bulk migrate a directory to v2 integrity scope.

    Walks all .seif files and runs update_integrity on each. Reports per-file
    status. Honors an exclude-from file (one path or path-prefix per line) so
    evidence files (e.g. admin-docs snapshots) are preserved.
    """
    import sys as _sys
    from seif.core.integrity import migrate_integrity

    try:
        reports = migrate_integrity(
            Path(directory),
            exclude_from=Path(exclude_from) if exclude_from else None,
            skip_stamp=skip_stamp,
        )
    except FileNotFoundError as e:
        print(f"Error: {e}", file=_sys.stderr)
        return 1

    if as_json:
        import json as _json
        print(_json.dumps([r.asdict() for r in reports], indent=2))
        return 0

    print(f"[migrate] {directory}: {len(reports)} module(s) processed")
    failed = 0
    for r in reports:
        status_summary = (
            f"fp={r.fingerprint_status} sig={r.signature_status} "
            f"stamp={r.stamp_status}"
        )
        print(f"  {Path(r.file).name}: {status_summary}")
        if "FAILED" in r.fingerprint_status or r.fingerprint_status == "":
            failed += 1
    if failed:
        print(f"  ({failed} failed)")
        return 1
    return 0


def _cmd_session_list_unified(as_json: bool = False) -> None:
    """Unified --session list — enumerates v2 sessions from .seif/sessions/active/
    and .seif/sessions/sealed/<cycle-id>/.

    Works without seif-engine installed (fixes Gap 58 — pre-fix the --session list
    code path required the engine and v2 sessions were invisible to operators
    without the paid bridge). Schema-validates each entry via SessionEntry, same
    as --sessions-active.

    Output:
      - default: pretty table grouped by status (ACTIVE / SEALED <cycle_id>).
      - --json: {"active": [...], "sealed": {"cycle_id": [...]}}
    """
    import json as _json
    import sys as _sys
    from dataclasses import asdict as _asdict
    from pathlib import Path as _Path
    from seif.plugins.core.session_registry import SessionEntry

    seif_dir = _Path.cwd() / ".seif"
    sessions_dir = seif_dir / "sessions"

    def _load_entries(d: _Path) -> tuple[list[dict], int]:
        valid: list[dict] = []
        skipped = 0
        if not d.is_dir():
            return valid, skipped
        for f in sorted(d.iterdir()):
            if not f.is_file() or f.suffix != ".json":
                continue
            if f.name == "unknown.json" or f.name.startswith("handoff-"):
                skipped += 1
                continue
            try:
                data = _json.loads(f.read_text(encoding="utf-8"))
            except (OSError, _json.JSONDecodeError):
                skipped += 1
                continue
            if not isinstance(data, dict):
                skipped += 1
                continue
            try:
                entry = SessionEntry(**data)
            except TypeError:
                skipped += 1
                continue
            valid.append(_asdict(entry))
        return valid, skipped

    active, skipped_active = _load_entries(sessions_dir / "active")
    sealed: dict[str, list[dict]] = {}
    skipped_sealed = 0
    sealed_root = sessions_dir / "sealed"
    if sealed_root.is_dir():
        for cycle_dir in sorted(sealed_root.iterdir()):
            if not cycle_dir.is_dir():
                continue
            cycle_entries, cycle_skipped = _load_entries(cycle_dir)
            if cycle_entries:
                sealed[cycle_dir.name] = cycle_entries
            skipped_sealed += cycle_skipped

    skipped_total = skipped_active + skipped_sealed

    if as_json:
        print(_json.dumps({"active": active, "sealed": sealed}, indent=2))
    else:
        sealed_count = sum(len(v) for v in sealed.values())
        print(f"─── SESSIONS (active={len(active)} sealed={sealed_count}) ───")
        if not seif_dir.is_dir():
            print("  (no .seif/ in cwd — run `seif --init` first)")
        elif not active and not sealed:
            print("  (no v2 session entries found)")
        else:
            if active:
                print(f"  ACTIVE ({len(active)})")
                for e in active:
                    sid_short = (e.get("session_id") or "")[:8]
                    wrapper = e.get("wrapper") or "?"
                    cycle = e.get("cycle_id") or "—"
                    started = e.get("started_at") or "?"
                    print(f"    {sid_short:<10} {wrapper[:14]:<14} cycle={cycle[:24]:<24} started={started}")
            for cycle_id, entries in sealed.items():
                print(f"  SEALED {cycle_id} ({len(entries)})")
                for e in entries:
                    sid_short = (e.get("session_id") or "")[:8]
                    wrapper = e.get("wrapper") or "?"
                    started = e.get("started_at") or "?"
                    print(f"    {sid_short:<10} {wrapper[:14]:<14} started={started}")
        print("───────────────────────────────────────────────────────")

    if skipped_total:
        print(f"  (skipped {skipped_total} non-session / invalid file(s))",
              file=_sys.stderr)


def _try_load_engine():
    """Attempt to load seif-engine, which injects paid modules into seif.* namespace."""
    try:
        import seif_engine  # noqa: F401 — triggers namespace injection via _shims
        return True
    except ImportError:
        return False


_ENGINE_AVAILABLE = None


def _has_engine():
    """Check if seif-engine is available (cached)."""
    global _ENGINE_AVAILABLE
    if _ENGINE_AVAILABLE is None:
        _ENGINE_AVAILABLE = _try_load_engine()
    return _ENGINE_AVAILABLE


def _upgrade_message(command: str, description: str):
    """Print a clear upgrade message for paid features."""
    print(f"\n  seif {command}")
    print(f"  {description}\n")
    print(f"  This feature requires seif-engine.")
    print(f"  Upgrade:    pip install seif-engine")
    print(f"  Learn more: https://seifprotocol.com/pricing\n")


def main():
    # Load engine namespace injection if available
    _has_engine()

    parser = argparse.ArgumentParser(
        prog="seif",
        description="S.E.I.F. — Unified CLI",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            '  seif "O amor liberta e guia"          # full RPWP pipeline\n'
            '  seif --gate "Tesla 369"                # resonance gate only\n'
            '  seif --init                            # initialize .seif context\n'
            '  seif --absorb ./src/                   # absorb knowledge from directory\n'
            '  seif --list                            # list all your contexts\n'
            '  seif --status                          # current context status\n'
            '  seif --sync                            # re-sync git context\n'
            '  seif --report                          # workspace report\n'
            '  seif --quality-gate "text" --role ai   # measure AI response\n'
        ),
    )
    parser.add_argument("text", nargs="?", default="",
                        help="Texto de entrada ou caminho de imagem (com --artifact)")
    parser.add_argument("--ascii-art", action="store_true",
                        help="Restore legacy ornate output (box drawing, 3-6-9 line, "
                             "footer). Default is clean ASCII. Equivalent to env "
                             "SEIF_ASCII_ART=1.")
    parser.add_argument("--gate", action="store_true", help="Apenas Porta de Ressonância")
    parser.add_argument("--transcompile", action="store_true", help="Apenas transcompilação")
    parser.add_argument("--glyph", action="store_true", help="Apenas glifo visual")
    parser.add_argument("--audio", action="store_true",
                        help="Render audio output only (carrier WAV from transcompiled spec)")
    parser.add_argument("--fractal", action="store_true", help="Apenas Fractal QR-Code")
    parser.add_argument("--circuit", action="store_true", help="Apenas circuito SFA (SVG)")
    parser.add_argument("--composite", action="store_true", help="Mapa de Ressonância Completo (selo + hardware)")
    parser.add_argument("--encode", action="store_true", help="Resonance Encoding (φ-spiral frequencies)")
    parser.add_argument("--artifact", action="store_true", help="Analisar imagem de artefato antigo")
    parser.add_argument("--watermark-embed", metavar="WAV_IN",
                        help="Embed text as infrasound watermark in a WAV file")
    parser.add_argument("--watermark-extract", metavar="WAV_IN",
                        help="Extract infrasound watermark from a WAV file")
    parser.add_argument("--watermark-output", metavar="WAV_OUT",
                        help="Output WAV path for --watermark-embed")
    parser.add_argument("--watermark-symbols", type=int, default=0, metavar="N",
                        help="Number of symbols to extract (for --watermark-extract)")
    parser.add_argument("--watermark-reps", type=int, default=3,
                        help="Repetition coding factor (default: 3)")
    parser.add_argument("--watermark-duration", type=float, default=4.0,
                        help="Symbol duration in seconds (default: 4.0)")
    parser.add_argument("--watermark-amplitude", type=float, default=0.005,
                        help="Watermark amplitude (default: 0.005)")
    parser.add_argument("--fingerprint-of", metavar="FILE", default=None,
                        help="With --watermark-embed: compute sha256 of FILE bytes "
                             "and embed the hex digest as the watermark payload "
                             "(replaces the positional text). Used for AI artifact "
                             "audio provenance demos.")
    parser.add_argument("--against", metavar="FILE", default=None,
                        help="With --watermark-extract: recompute sha256 of FILE "
                             "and compare against the extracted payload. Exit 0 "
                             "on match, 1 on mismatch (provenance verification).")
    parser.add_argument("--verify-audio-provenance", metavar="WAV_IN", default=None,
                        help="Verify that an audio carrier binds to a SEIF envelope. "
                             "Pair with --envelope ENV_JSON (envelope from "
                             "seif --log-submit / provenance_sign). Extracts the "
                             "watermark payload from WAV_IN and compares to "
                             "envelope.content_sha256. Exit 0 on match, 1 on mismatch, "
                             "2 on structural error (audio unreadable, envelope "
                             "malformed). Wedge A v1.0 audio-side provenance demo.")
    parser.add_argument("--envelope", metavar="ENV_JSON", default=None,
                        help="Path to a SEIF envelope JSON file. Used by "
                             "--verify-audio-provenance to compare audio watermark "
                             "against envelope.content_sha256.")
    parser.add_argument("--mcp-watermark", action="store_true",
                        help="Run the SEIF audio-watermark MCP server on stdio. "
                             "Wraps Phase 1 watermark API as four MCP tools "
                             "(embed, extract, fingerprint, verify) for use in "
                             "Claude Desktop and other MCP-aware clients. "
                             "Requires the [mcp] extra (`pip install seif-cli[mcp]`).")
    parser.add_argument("--mcp-server", action="store_true",
                        help="Run the canonical SEIF provenance MCP server on stdio. "
                             "Exposes provenance_sign / provenance_verify / "
                             "classification_check as MCP tools to Cursor, Claude "
                             "Code, and other MCP-aware clients (Wedge A Pillar 3, "
                             "Phase 1 — local-only; log_append/get land in Phase 2). "
                             "Requires the [mcp] extra (`pip install seif-cli[mcp]`).")
    parser.add_argument("--log-submit", metavar="FILE", default=None,
                        help="Submit FILE's SHA-256 as an attestation entry to a "
                             "seif-log service. Uses workspace-native Ed25519 auth "
                             "(auto-generates ~/.seif/identities/<name>.{key,pub} on "
                             "first use); the remote service auto-bootstraps a "
                             "personal-plan tenant on first signed submit. "
                             "Requires the [log] extra.")
    parser.add_argument("--log-verify", metavar="ENTRY_ID", default=None,
                        help="Fetch a previously submitted entry by id. Tenant-scoped "
                             "GET; returns 404 cross-tenant. Same Ed25519 auth as "
                             "--log-submit.")
    parser.add_argument("--log-list", action="store_true",
                        help="List entries for this workspace's tenant, oldest first, "
                             "cursor-paginated. Uses --log-limit + --log-after-id for "
                             "paging and --log-workspace-fingerprint for filtering. "
                             "Same Ed25519 auth as --log-submit. (D4)")
    parser.add_argument("--log-limit", type=int, metavar="N", default=20,
                        help="Page size for --log-list (default: 20, max: 200).")
    parser.add_argument("--log-after-id", metavar="UUID", default=None,
                        help="Cursor for --log-list — return entries after this id "
                             "(use the previous response's next_cursor).")
    parser.add_argument("--log-url", metavar="URL", default=None,
                        help="seif-log service URL (default: env SEIF_LOG_URL or "
                             "http://localhost:8000). Used by --log-submit / --log-verify "
                             "/ --log-list.")
    parser.add_argument("--log-identity", metavar="NAME", default="default",
                        help="Identity name in ~/.seif/identities/ (default: 'default'). "
                             "Lazily generated on first use.")
    parser.add_argument("--log-entry-type", metavar="TYPE", default="artifact.file",
                        help="Entry type tag for --log-submit (default: 'artifact.file').")
    parser.add_argument("--log-classification",
                        choices=["PUBLIC", "INTERNAL", "CONFIDENTIAL"],
                        default="INTERNAL",
                        help="classification_ceil for --log-submit (default: INTERNAL).")
    parser.add_argument("--log-workspace-fingerprint", metavar="FP", default=None,
                        help="Optional workspace_fingerprint tag on the entry "
                             "(soft metadata; identity is bound to the Ed25519 pubkey).")
    parser.add_argument("--all", action="store_true", help="Pipeline completo (padrão)")
    parser.add_argument("--init", nargs="?", const=".", metavar="PATH",
                        help="Initialize S.E.I.F.: scan, detect projects, extract git, generate .seif")
    parser.add_argument("--init-lite", nargs="?", const=".", metavar="PATH", default=None,
                        help="Alias for `--init PATH --lite` — scaffold a SEIF Lite "
                             "workspace (README, AGENTS.md, .seif-lite/BOOT.md, "
                             "refs.md, session-log.md, decisions-pending.md). "
                             "No .seif/ kernel, no signing, no RESONANCE.json.")
    parser.add_argument("--lite", action="store_true",
                        help="Modifier on --init: scaffold SEIF Lite only (templates + "
                             "AGENTS.md cross-agent contract). Skips kernel, signing, "
                             "and RESONANCE.json. See ADR-006.")
    parser.add_argument("--lite-name", metavar="TITLE", default=None,
                        help="With --init --lite: title substituted into "
                             "{{PROJECT_TITLE}} in templates (default: directory basename).")
    parser.add_argument("--no-lite-agents", action="store_true",
                        help="With --init --lite: skip AGENTS.md only (rare; for folders "
                             "that must not suggest AI editing). All other templates still emitted.")
    parser.add_argument("--circuit-setup", action="store_true",
                        help="Install axiom A20 plumbing on this host: detect AI runtime, "
                             "install circuit-inbox-hook.sh + register PreToolUse/UserPromptSubmit/Stop "
                             "hooks + initialize inbox watermark + copy helper scripts. "
                             "Idempotent. Combine with --dry-run for plan preview.")
    parser.add_argument("--rebuild-registry", action="store_true",
                        help="Rebuild ~/.seif/registry.json by scanning the filesystem. "
                             "Drops stale entries (missing paths, tempdirs from old test runs). "
                             "Use --scan-root to specify directories to scan; defaults to "
                             "the parent of any context already in the registry.")
    parser.add_argument("--scan-root", action="append", default=[], metavar="PATH",
                        help="Directory to scan for .seif/ workspaces (repeatable). "
                             "Used with --rebuild-registry.")
    parser.add_argument("--dry-run", action="store_true",
                        help="Preview the operation without writing changes "
                             "(applies to --init-host, --audit-host, "
                             "--rebuild-registry, --probe-models, "
                             "--migrate-host-config, --circuit-setup).")
    parser.add_argument("--probe-models", action="store_true",
                        help="Probe local Ollama, installed CLI tools, API keys, and circuitd; "
                             "regenerate ~/.seif/model_registry.json for this host. "
                             "Per-host file (each machine sees different reachable models).")
    parser.add_argument("--audit-host", action="store_true",
                        help="Audit ~/.seif/ host-level structure across the 5 architecture "
                             "layers (A: protocol, B: init-generated, C: derived, D: per-host, "
                             "E: heartbeat). Complementary to --audit (which checks context "
                             "modules) and --audit-layout (which checks per-role canonical "
                             "filesystem layout). With --fix-host, regenerates missing/stale files.")
    parser.add_argument("--fix-host", action="store_true",
                        help="With --audit-host, automatically regenerate missing or stale files.")
    parser.add_argument("--audit-layout", action="store_true",
                        help="Audit canonical filesystem layout for this host's role "
                             "(CLI symlinks, owner state, role-specific artifacts, drift "
                             "violations, forbidden artifacts) against canonical-node-layout.json. "
                             "Read-only. Distinct from --audit-host (which audits SEIF init "
                             "artifacts inside ~/.seif/). Exit codes: 0 clean, 1 drift, "
                             "2 missing required, 3 role detection failed.")
    parser.add_argument("--check-seed-constraint", metavar="ACTION", default=None,
                        help="Check ACTION against prohibitions declared in active "
                             "(unconsumed) SEED-*.json files under .seif/seeds/. "
                             "Read-only. Use before host-touching operations in cycles "
                             "with active seeds — operator approval does NOT subsume "
                             "seed verification. Exit codes: 0 allowed, 1 blocked "
                             "(prints seed_id + constraint), 2 no active seeds.")
    parser.add_argument("--plugin-sync", action="store_true",
                        help="Walk plugins/adapters/, validate each manifest against "
                             "manifest.schema.json, verify render.py is importable + "
                             "exposes render_seed with the contract signature. "
                             "Currently --check-only; deploy + Ed25519 signing land in "
                             "a follow-up release. See plugins/adapters/CONTRACT.md.")
    parser.add_argument("--plugin-detect", action="store_true",
                        help="Walk plugins/adapters/, resolve each adapter's "
                             "client_detect predicates against this host, report "
                             "which adapters would bind. With --apply, runs render_seed "
                             "and writes output files for hookless adapters. "
                             "Hook-capable install (settings.json merge) remains via "
                             "`seif setup <client>`.")
    parser.add_argument("--apply", action="store_true",
                        help="With --plugin-detect: actually write rendered output "
                             "files. Without --apply, --plugin-detect is dry-run.")
    parser.add_argument("--inbox", action="store_true",
                        help="Drain pending circuit messages (axiom A20). Wraps "
                             "circuit_monitor.py --check-inbox + --drain end-to-end. "
                             "Hookless adapters reference this command in their "
                             "rendered protocol; runs check + drain in one call.")
    parser.add_argument("--classify", metavar="TEXT_OR_FILE", default=None,
                        help="Classify text or file content as PUBLIC / INTERNAL / "
                             "CONFIDENTIAL based on the protocol's sensitive-keyword "
                             "filter. Pass a filesystem path to classify file contents, "
                             "or pass the literal text to classify (auto-detected: if "
                             "the value is an existing file, read it).")
    parser.add_argument("--confirm-action", metavar="ACTION", default=None,
                        help="Pre-action human gatekeeper for hookless AI clients. "
                             "Non-interactive: emits AWAITING_HUMAN_CONFIRMATION + "
                             "exits 2 (caller AI must surface to human and stop). "
                             "Interactive: prompts the human; exit 0 approve, 1 deny. "
                             "Used together with --reason-text and --caller for "
                             "audit logging in ~/.seif/circuit/confirmations.log "
                             "and .seif/sessions/<N>-confirmations.log.")
    parser.add_argument("--reason-text", metavar="WHY", default="",
                        help="Reason for --confirm-action (one line; logged).")
    parser.add_argument("--caller", metavar="ID", default="",
                        help="Caller identifier for --confirm-action audit log "
                             "(e.g. 'copilot/agent-001'). Optional.")
    parser.add_argument("--init-host", action="store_true",
                        help="Initialize host-specific files (~/.seif/machine_id, "
                             "optionally bridge-config.json and sources.json). Idempotent: "
                             "only writes missing fields unless --overwrite-machine-id is set. "
                             "These files are NEVER synced between machines.")
    parser.add_argument("--label", metavar="LABEL",
                        help="Machine label (e.g. 'mini-m4'). Default: derived from hostname. "
                             "Used with --init-host.")
    parser.add_argument("--host-role", default="dev",
                        choices=("production", "dev", "edge", "ephemeral", "observer-pull"),
                        metavar="ROLE", dest="host_role",
                        help="HOST-LEVEL role (infrastructure stance). Used with --init-host. "
                             "Choices: production | dev | edge | ephemeral | observer-pull. "
                             "Distinct from AGENT-LEVEL role (writer | executor | vigilant | "
                             "sentinel | researcher | analyst | maestro | gatekeeper) set via "
                             "--agents-set. See SEIF.md → Agent Roles for the two-axis taxonomy. "
                             "(Note: --role is reserved for --quality-gate's text author role.)")
    parser.add_argument("--overwrite-machine-id", action="store_true",
                        help="Rotate the machine_id fingerprint (otherwise re-running --init-host "
                             "preserves the existing fingerprint).")
    parser.add_argument("--hub", action="append", default=[], metavar="SPEC",
                        help="Bridge hub spec: 'name=host[:port][,ssh=ssh-host][,key=path]'. "
                             "Repeatable. Triggers writing bridge-config.json. "
                             "Example: --hub 'mini-primary=100.93.186.89:7332,ssh=mini'")
    parser.add_argument("--source", action="append", default=[], metavar="SPEC",
                        help="Source repo spec: 'repo[:type[:classification]]'. Type is one of "
                             "context|research|project (default: context). Classification "
                             "defaults to PUBLIC/INTERNAL/CONFIDENTIAL based on type. Repeatable.")
    parser.add_argument("--machine-label", default="local", metavar="LABEL",
                        help="Machine label for CLI-tool entries (e.g. 'air-m1', 'mini-m4'). "
                             "Used with --probe-models.")
    parser.add_argument("--format", default="summary", choices=("summary", "orchestra", "json"),
                        metavar="FMT",
                        help="Output format for --probe-models: summary (counts), "
                             "orchestra (session-start block), json (full registry).")
    parser.add_argument("-y", "--yes", action="store_true",
                        help="Skip confirmation prompt (auto-approve). "
                             "Used by --migrate-host-config (CI mode), "
                             "--rebuild-registry, --probe-models.")
    parser.add_argument("--install-hooks", nargs="?", const=".", metavar="REPO",
                        help="Install git hooks for auto-sync on commit/pull/checkout")
    parser.add_argument("--quality-gate", action="store_true",
                        help="Quality Gate: unified stance + resonance verdict")
    parser.add_argument("--role", default="human", choices=["human", "ai"],
                        help="Role of the text author (for --quality-gate)")
    parser.add_argument("--workspace", nargs="?", const=".", metavar="ROOT_PATH",
                        help="Multi-project workspace: discover, sync, and manage all projects")
    parser.add_argument("--ingest", metavar="SOURCE",
                        help="Ingest external text (file, string, or - for stdin) into project .seif")
    parser.add_argument("--project", metavar="SEIF_PATH",
                        help="Target .seif file for --ingest (default: .seif/project.seif)")
    parser.add_argument("--sync", nargs="?", const=".", metavar="REPO_PATH",
                        help="Auto-generate .seif from git context (default: current dir)")
    parser.add_argument("--contribute", metavar="MODULE_PATH",
                        help="Contribute to an existing .seif module (text = contribution content)")
    parser.add_argument("--author", default="unknown", help="Author name for --contribute/--sync")
    parser.add_argument("--via", default="git", help="Tool/model used for --contribute/--sync")
    parser.add_argument("--context-repo", metavar="PATH",
                        help="Use a separate SEIF Context Repository (SCR mode). "
                             "All .seif data is stored externally, not inside code repos.")
    parser.add_argument("--autonomous", metavar="ACTION", nargs="?", const="status",
                        choices=["enable", "disable", "status"],
                        help="Manage AI autonomous context: enable, disable, or status (default)")
    parser.add_argument("--export", nargs="?", const="", metavar="OUTPUT_FILE",
                        help="Export context filtered by classification (to stdout or file)")
    parser.add_argument("--classification", default="INTERNAL",
                        choices=["PUBLIC", "INTERNAL", "CONFIDENTIAL"],
                        help="Classification filter for --export (default: INTERNAL)")
    parser.add_argument("--compress", nargs="?", const=".", metavar="PATH",
                        help="Compress source code project into .seif for AI consumption")
    parser.add_argument("--watch", action="store_true",
                        help="Watch mode for --compress: incremental update on changes")
    parser.add_argument("--packet", nargs="?", const="", metavar="MODULE.seif",
                        help="Create a SEIF-PACKET-v1 from a .seif module (verified inter-AI communication)")
    parser.add_argument("--send", action="store_true",
                        help="Send the packet to the target backend (requires --to)")
    parser.add_argument("--relay", nargs="+", metavar="MODULE.seif",
                        help="Send .seif module(s) to an AI backend for interpretation")
    parser.add_argument("--to", default=None,
                        help="Target backend for --relay/--consult/--packet (claude, gemini, grok, anthropic)")
    parser.add_argument("--prompt", default="Analyze this SEIF context module. What do you observe?",
                        help="Question to ask with --relay (default: analyze)")
    parser.add_argument("--output", metavar="FILE",
                        help="Save response to file (for --relay or --consensus)")
    parser.add_argument("--consensus", metavar="QUESTION",
                        help="Ask multiple backends the same question with shared .seif context")
    parser.add_argument("--backends", default="claude,gemini",
                        help="Comma-separated backends for --consensus (default: claude,gemini)")
    parser.add_argument("--context", nargs="*", metavar="MODULE.seif",
                        help=".seif module(s) as context for --consensus")
    parser.add_argument("--coherence-threshold", type=float, default=0.7,
                        help="Minimum similarity for consensus (default: 0.7)")
    parser.add_argument("--mirror", action="store_true",
                        help="Add a clean (no protocol) instance to --consensus for adversarial comparison")
    parser.add_argument("--rounds", type=int, default=1, choices=[1, 2, 3],
                        help="Consensus rounds: 1=independent, 2=+cross-examination, 3=+synthesis (default: 1)")
    parser.add_argument("--session", metavar="ACTION",
                        help="Shared session: create/contribute/close/list/show/sync/add-participant/upgrade/sync-prompt <name>")
    parser.add_argument("--session-name", metavar="NAME",
                        help="Session name for --session commands")
    parser.add_argument("--session-message", metavar="MSG",
                        help="Message for --session contribute/sync digest")
    parser.add_argument("--participant-id", metavar="ID",
                        help="Participant ID for --session add-participant/sync-prompt")
    parser.add_argument("--participant-role", metavar="ROLE", default="contributor",
                        help="Participant role: writer/co-author/contributor/observer (default: contributor)")
    parser.add_argument("--participant-channel", metavar="CHANNEL", default="handshake",
                        help="Participant channel: filesystem/handshake/skill/cli/api (default: handshake)")
    parser.add_argument("--handoff", metavar="SESSION_NAME",
                        help="Generate SEIF-SEED-v1 for session handoff")
    parser.add_argument("--mirror-weekly", action="store_true",
                        help="Run weekly consensus with mirror for adversarial validation")
    parser.add_argument("--verify-seed", action="store_true",
                        help="Verify resonance with Enoch seed")
    parser.add_argument("--evolve", action="store_true",
                        help="Trigger SEIF OS evolution: auto-mutate based on feedback and resonance")
    parser.add_argument("--communicate", metavar="MESSAGE",
                        help="SEIF OS communication: embed message as infrasound watermark in audio")
    parser.add_argument("--handshake", metavar="MODEL",
                        help="Generate SEIF bootstrap prompt for a browser AI (e.g., --handshake deepseek)")
    parser.add_argument("--full", action="store_true",
                        help="With --handshake: include operational context (mapper, decisions, pending observations)")
    parser.add_argument("--consult", metavar="QUESTION",
                        help="Intelligent inter-AI consultation — auto-routes to best backend")
    parser.add_argument("--generate", metavar="OUTPUT_DIR", nargs="?", const="docs/generated",
                        help="Generate documentation from .seif modules (default: docs/generated)")
    parser.add_argument("--changelog", metavar="OUTPUT", nargs="?", const="CHANGELOG.md",
                        help="Generate CHANGELOG.md from decisions.seif")
    parser.add_argument("--scan", metavar="PROGRAM",
                        help="Scan CLI program's --help output into a .seif knowledge module")
    parser.add_argument("--scan-depth", type=int, default=2,
                        help="Recursion depth for subcommand scanning (default: 2)")
    parser.add_argument("--global", dest="global_store", action="store_true",
                        help="Save scanned module to ~/.seif/tools/ (global, available to all projects)")
    parser.add_argument("--adversarial", metavar="QUESTION",
                        help="Adversarial mirror: same question WITH and WITHOUT protocol, compare delta")
    parser.add_argument("--allow-confidential", action="store_true",
                        help="Allow CONFIDENTIAL modules in --consult context (default: excluded)")
    parser.add_argument("--manual", action="store_true",
                        help="Manual consultation: generate prompt for web chat, paste response back")
    parser.add_argument("--health", action="store_true",
                        help="Show backend health status (which AIs are working)")
    parser.add_argument("--audit", action="store_true",
                        help="Audit .seif context: fix orphans, ghosts, hashes, sync")
    parser.add_argument("--fingerprint-verify", metavar="FILE",
                        help="Verify fingerprint of a SEIF module or RESONANCE.json")
    parser.add_argument("--fingerprint-update", metavar="FILE",
                        help="Recalculate and update fingerprint of a SEIF module")
    parser.add_argument("--fingerprint-output", metavar="FILE",
                        help="Output file for --fingerprint-update (default: overwrite input)")
    parser.add_argument("--integrity-update", metavar="FILE",
                        help="Atomic fingerprint→sign→stamp chain on a SEIF "
                             "module. Resolves Gap 24 family by ensuring all "
                             "three integrity facts are simultaneously valid.")
    parser.add_argument("--verify-integrity", metavar="FILE",
                        help="Joined verify of fingerprint+signature+stamp. "
                             "Exit 0 only if all three VALID; non-zero on "
                             "PENDING/HALF_VALID/INVALID.")
    parser.add_argument("--migrate-integrity", metavar="DIRECTORY",
                        help="Bulk migrate a directory to v2 integrity scope. "
                             "Walks all .seif files and runs --integrity-update "
                             "on each.")
    parser.add_argument("--integrity-skip-sign", action="store_true",
                        help="When running --integrity-update, skip the signing "
                             "step (fingerprint+stamp only).")
    parser.add_argument("--integrity-skip-stamp", action="store_true",
                        help="When running --integrity-update or "
                             "--migrate-integrity, skip the .ots stamping step.")
    parser.add_argument("--integrity-exclude-from", metavar="FILE",
                        help="When running --migrate-integrity, skip paths "
                             "listed in this file (one per line; supports prefix "
                             "match for trailing slashes).")
    parser.add_argument("--streaming-start", action="store_true",
                        help="Start a streaming watermark session")
    parser.add_argument("--streaming-status", action="store_true",
                        help="Show status of streaming session")
    parser.add_argument("--streaming-list", action="store_true",
                        help="List all active streaming sessions")
    parser.add_argument("--streaming-stop", action="store_true",
                        help="Stop a streaming session")
    parser.add_argument("--streaming-session", metavar="ID",
                        help="Streaming session ID")
    parser.add_argument("--streaming-audio-interval", type=int, default=300,
                        help="Full token embedding interval in seconds (default: 300)")
    parser.add_argument("--streaming-text-interval", type=int, default=60,
                        help="Mini marker interval in seconds (default: 60)")
    parser.add_argument("--streaming-max", type=int, default=100,
                        help="Maximum embeddings per session (default: 100)")
    parser.add_argument("--streaming-identity", metavar="FILE",
                        help="Identity block JSON file for streaming session")
    parser.add_argument("--onboard", action="store_true",
                        help="Guided first-run setup: profile → backend check → try it")
    parser.add_argument("--version", action="store_true",
                        help="Show seif-cli version and exit")
    parser.add_argument("--help-admin", action="store_true",
                        help="Show all admin/advanced commands")
    parser.add_argument("--boot-check", action="store_true",
                        help="Run boot check across multiple LLMs")
    parser.add_argument("--boot-to", nargs="+", metavar="BACKEND",
                        help="Specific backends for boot check (grok, claude, gemini, etc.)")
    parser.add_argument("--boot-auto", action="store_true",
                        help="Auto-detect available backends for boot check")
    parser.add_argument("--boot-all", action="store_true",
                        help="Use all available backends for boot check")
    parser.add_argument("--boot-core", metavar="FILE",
                        default="seif-core-v3.2.seif",
                        help="SEIF core file for boot check (default: seif-core-v3.2.seif)")
    parser.add_argument("--boot-max-parallel", type=int, default=3,
                        help="Maximum parallel boot checks (default: 3)")

    # ── Personal Nucleus ──
    parser.add_argument("--profile", metavar="ACTION", nargs="?", const="show",
                        choices=["init", "show", "edit"],
                        help="Manage ~/.seif/profile.json: init, show, or edit")
    parser.add_argument("--profile-name", metavar="NAME", help="Name for --profile init")
    parser.add_argument("--profile-email", metavar="EMAIL", help="Email for --profile init")
    parser.add_argument("--profile-github", metavar="USER", help="GitHub username for --profile init")
    parser.add_argument("--profile-backend", metavar="BACKEND", help="Default backend for --profile init")
    parser.add_argument("--profile-language", metavar="LANG", help="Language for --profile init (en, pt_br)")

    parser.add_argument("--sources", metavar="ACTION", nargs="?", const="list",
                        choices=["add", "remove", "list", "sync"],
                        help="Manage ~/.seif/sources.json: add, remove, list, or sync")
    parser.add_argument("--source-repo", metavar="REPO",
                        help="Repository URL/path for --sources add/remove")
    parser.add_argument("--source-type", metavar="TYPE", default="context",
                        choices=["context", "research", "project"],
                        help="Source type for --sources add (default: context)")

    # ── File Extraction ──
    parser.add_argument("--extract", metavar="PATH", nargs="?", const=".",
                        help="Extract knowledge from files/directories into .seif modules")

    # ── Context Registry (Git for Context) ──
    parser.add_argument("--absorb", metavar="PATH", nargs="?", const=".",
                        help="Absorb knowledge from any directory into .seif context")
    parser.add_argument("--absorb-name", metavar="NAME",
                        help="Name for the absorbed context (default: directory name)")
    parser.add_argument("--list", dest="list_contexts", action="store_true",
                        help="List all registered .seif contexts")
    parser.add_argument("--status", dest="show_status", action="store_true",
                        help="Show current .seif context status")
    parser.add_argument("--report", dest="show_report", action="store_true",
                        help="Generate workspace report showing context efficiency and session history")

    # ── Model Profiles ──
    parser.add_argument("--models", metavar="ACTION", nargs="?", const="show",
                        choices=["show", "update", "behavior", "record"],
                        help="Model profiles: show | update | behavior (list types) | record (log incident)")

    # ── Cryptographic Signing ──
    parser.add_argument("--keygen", action="store_true",
                        help="Generate Ed25519 signing keypair at ~/.seif/keys/")
    parser.add_argument("--sign", metavar="MODULE.seif",
                        help="Sign a .seif module with your private key")
    parser.add_argument("--verify", metavar="MODULE.seif",
                        help="Verify the signature of a .seif module")
    parser.add_argument("--sign-all", metavar="DIRECTORY",
                        help="Sign all .seif modules in a directory")
    parser.add_argument("--sign-resonance", metavar="RESONANCE.json",
                        help="Sign RESONANCE.json with the Owner private key (must run on Owner machine per A22)")
    parser.add_argument("--verify-resonance", metavar="RESONANCE.json",
                        help="Verify the content_signature on RESONANCE.json (works anywhere)")
    parser.add_argument("--force", action="store_true",
                        help="Force operation (overwrite existing keys/bypass consent; with --stamp re-anchors over existing .ots)")

    # ── Workspace Ownership Transfer (A22) ──
    parser.add_argument("--transfer", action="store_true",
                        help="Sign and persist a workspace ownership transfer (requires --transfer-to, --transfer-scope, --transfer-reason)")
    parser.add_argument("--transfer-to", metavar="PUBKEY_B64", default=None,
                        help="New Owner Ed25519 public key (base64, raw 32B) — used with --transfer")
    parser.add_argument("--transfer-scope", metavar="WORKSPACE_ID", default=None,
                        help="Workspace identifier — used with --transfer / --verify-transfer-chain")
    parser.add_argument("--transfer-reason", metavar="TEXT", default=None,
                        help="Human-readable reason for transfer (e.g. 'M&A closing') — used with --transfer")
    parser.add_argument("--verify-transfer-chain", metavar="SCOPE",
                        help="Walk and verify the transfer chain for a workspace scope")
    parser.add_argument("--genesis-pubkey", metavar="PUBKEY_B64", default=None,
                        help="Original Owner pubkey — optional anchor for --verify-transfer-chain")
    parser.add_argument("--transfers-dir", metavar="DIR", default=None,
                        help="Override transfers directory (default: .seif/governance/transfers)")

    # ── OpenTimestamps ──
    parser.add_argument("--stamp", metavar="FILE",
                        help="Timestamp a .seif module with OpenTimestamps (Bitcoin anchor)")
    parser.add_argument("--verify-stamp", metavar="FILE",
                        help="Verify a .seif module's OTS proof against Bitcoin blockchain")
    parser.add_argument("--stamp-all", metavar="DIRECTORY",
                        help="Timestamp all .seif modules in a directory")

    # ── Security (Red/Blue Team) ──
    parser.add_argument("--security", metavar="ACTION", nargs="?", const="score",
                        choices=["score", "red", "blue", "baseline"],
                        help="Security assessment: score (full), red (adversarial), blue (compliance), baseline (show)")

    # ── Local Proxy (Data Sovereignty) ──
    parser.add_argument("--proxy", metavar="ACTION", nargs="?", const="status",
                        choices=["status", "test", "pull"],
                        help="Local LLM proxy: status, test classification, or pull model")
    parser.add_argument("--proxy-model", metavar="MODEL",
                        help="Ollama model for proxy (default: llama3.2:3b)")
    parser.add_argument("--proxy-test", metavar="TEXT",
                        help="Test classification of input text through local proxy")

    # ── Browser Integration ──
    parser.add_argument("--dia-skill", action="store_true",
                        help="Generate Dia browser skill prompt from current nucleus context")

    # ── Cycle Management (enoch-tree-reverb: branch-seif-cycle-module) ──
    parser.add_argument("--cycle", metavar="ACTION", nargs="?", const="status",
                        choices=["status", "verify", "review", "persist", "close",
                                 "audit", "meditate", "absorb",
                                 "new", "full-circle"],
                        help="Cycle management: status|verify|review|persist|close|new|full-circle "
                             "(legacy aliases still accepted: audit→verify, meditate→review, absorb→persist)")
    parser.add_argument("--cycle-name", metavar="NAME",
                        help="Cycle name for --cycle new")
    parser.add_argument("--cycle-parent", metavar="PARENT",
                        help="Parent cycle for --cycle new (auto-detected if omitted)")
    parser.add_argument("--start-cycle", metavar="SLUG", default=None,
                        help="(s58) Open workspace cycle <slug> and bind it to this host as the "
                             "active cycle. Writes substance to .seif/cycles/<slug>-OPEN.seif "
                             "(workspace) and a pointer-only marker to ~/.seif/active-cycle.json "
                             "(host process-state). Future seif --session create calls auto-bind "
                             "via SEIF_ACTIVE_CYCLE.")
    parser.add_argument("--close-cycle", metavar="SLUG", nargs="?", const="__from_pointer__",
                        default=None,
                        help="(s58) Seal the active cycle and clear the host pointer. SLUG is "
                             "optional — defaults to the slug in ~/.seif/active-cycle.json (or "
                             "the workspace's currently open cycle). (s59 PR4) Refuses to seal "
                             "if active writer sessions are still bound to this cycle; pair with "
                             "--force to override (writes force_seal_audit_trail into SEALED).")
    parser.add_argument("--audit-cycle-coherence", action="store_true",
                        help="(s58) Read-only audit of cycle ↔ session bindings. Surfaces: "
                             "(a) cycles without writer sessions, (b) active sessions without "
                             "cycle_id, (c) SEALED cycles whose writer sessions are still in "
                             ".seif/sessions/active/. Exits 1 only on class (c) violations.")
    parser.add_argument("--heal", action="store_true",
                        help="(s59 PR4 Layer C) Modifier for --audit-cycle-coherence: build a "
                             "READ-ONLY heal plan for class-(c) violations and persist it under "
                             ".seif/heal-plans/. No session entries are mutated. Apply the plan "
                             "via `seif --heal-apply <plan-file>`.")
    parser.add_argument("--heal-apply", metavar="PLAN_FILE", default=None,
                        help="(s59 PR4 Layer C) Apply a previously-built heal plan from "
                             "PLAN_FILE. Mutates state (unregisters sessions per plan).")
    parser.add_argument("--re-seal-cycle", metavar="SLUG", default=None,
                        help="(s59 PR5) Append an entry to a SEALED cycle's re_seal_history[]. "
                             "Codifies the s52 ad-hoc re_seal_rationale convention as a "
                             "structured, append-only amendment chain. Pair with --rationale "
                             "(required) and --delta-list (required: JSON list literal or "
                             "path to a .json file containing a list).")
    parser.add_argument("--rationale", metavar="TEXT", default=None,
                        help="(s59 PR5) Rationale text for --re-seal-cycle. Required for re-seal.")
    parser.add_argument("--delta-list", metavar="JSON_OR_PATH", default=None,
                        help="(s59 PR5) Deltas to record on this re-seal. Either a JSON list "
                             "literal (e.g. '[\"PR #91\",\"PR #92\"]') or a path to a JSON file "
                             "containing a list. Required for --re-seal-cycle.")
    parser.add_argument("--sessions-active", action="store_true",
                        help="(s60 PR3) List schema-valid session entries from "
                             ".seif/sessions/active/. Read-only — never mutates "
                             "the registry. Filters out unknown.json (handoff "
                             "straggler), handoff-*.json (not session entries), "
                             "and files that fail SessionEntry schema validation. "
                             "Pair with --json for machine-readable output; "
                             "default is a pretty-printed table.")
    parser.add_argument("--json", action="store_true",
                        help="Output JSON instead of the default table. "
                             "Currently honored by --sessions-active.")
    parser.add_argument("--table", action="store_true",
                        help="Force table output (default). Currently honored "
                             "by --sessions-active. Overrides --json if both given.")
    parser.add_argument("--emit-n2-bundle", action="store_true",
                        help="(s60 PR5) Build + sign + persist a weekly N2 (nucleus-of-nucleus) "
                             "bundle aggregating SEALED cycles + seeds for one ISO week. "
                             "Stored at <workspace>/.seif/n2/N2-BUNDLE-WYYYY-Wnn.json. "
                             "Pair with --week WYYYY-Wnn (default: current ISO week) and "
                             "optionally --workspace ROOT (default: cwd). Per A22, requires "
                             "the Owner private key at ~/.seif/keys/seif_private.pem. "
                             "Re-emitting a week writes .json.v2 — never overwrites v1.")
    parser.add_argument("--week", metavar="WYYYY-Wnn", default=None,
                        help="(s60 PR5) ISO-week selector for --emit-n2-bundle (e.g. W2026-W18). "
                             "Default: current ISO week.")
    parser.add_argument("--verify-n2", metavar="BUNDLE_PATH", default=None,
                        help="(s60 PR5) Verify a previously-emitted N2 bundle. Recomputes "
                             "canonical_hash, verifies Ed25519 signature, re-hashes each "
                             "recorded cycle/seed, and reports any drift. Pair with --strict "
                             "to treat kernel rotation as a failure (default: warn-only).")
    parser.add_argument("--strict", action="store_true",
                        help="(s60 PR5) Modifier for --verify-n2: kernel rotation between "
                             "bundle-time and now is treated as a failure rather than a warning.")
    parser.add_argument("--identity-scan", metavar="TARGET",
                        nargs="?", const="local",
                        help="Scan resonance identities. TARGET: 'local' (default) or SSH host e.g. 'my-laptop'")
    parser.add_argument("--identity-scan-path", metavar="PATH",
                        help="Remote path for --identity-scan (default: ~/seif-admin/seif-context/modules or SEIF_CONTEXT_MODULES)")
    parser.add_argument("--start", action="store_true",
                        help="Open SEIF Suite in browser + show cycle status + load agent roles")
    parser.add_argument("--agents", action="store_true",
                        help="Show current agent role assignments for this workspace")
    parser.add_argument("--agents-set", metavar="ROLE=AGENT",
                        help="Set an agent role (owner only). E.g. --agents-set writer=claude")
    parser.add_argument("--pending", action="store_true",
                        help="Pending modules subcommand entry. Combine with --list, "
                             "--register, or --consume. With no flag: list pendings "
                             "relevant to the current workspace.")
    parser.add_argument("--pending-list", action="store_true",
                        help="List pending modules from ~/.seif/registry.json. "
                             "Filters by current workspace unless --all-workspaces is given.")
    parser.add_argument("--pending-register", metavar="PATH",
                        help="Register a SEIF-PENDING-v1 module file in the global "
                             "registry so future sessions can discover it. The module "
                             "must declare module_id and target_consumer; visibility "
                             "(personal|team) is inferred from path unless declared.")
    parser.add_argument("--visibility", metavar="TIER",
                        choices=("personal", "team"),
                        help="Override the visibility tier for --pending-register "
                             "(personal | team). Default: inferred from file location.")
    parser.add_argument("--pending-consume", metavar="MODULE_ID",
                        help="Mark a registered pending module as consumed. Writes "
                             "status='consumed' into the source module file.")
    parser.add_argument("--all-workspaces", action="store_true",
                        help="Modifier for --pending-list: include pendings targeted at "
                             "any workspace, not just the current one.")
    parser.add_argument("--consumed-in-cycle", metavar="CYCLE_ID",
                        help="Modifier for --pending-consume: record which cycle "
                             "consumed the pending (e.g. s32-stabilize-and-release-v0.7.0).")
    parser.add_argument("--delegate-to", metavar="SSH_HOST",
                        help="Run a seed file on a remote host via SSH and capture "
                             "its output to a local outbox. Eliminates owner-as-relay "
                             "for Mini→Air/Moto delegation. Requires --as-agent and --seed.")
    parser.add_argument("--as-agent", metavar="AGENT_NAME",
                        help="Logical agent label being driven by --delegate-to "
                             "(e.g. air-claude, moto-claude). Stored in outbox header.")
    parser.add_argument("--seed", metavar="SEED_PATH",
                        help="Path to a seed file. Contents are piped to `bash -s` "
                             "on the remote host. Used with --delegate-to.")
    parser.add_argument("--outbox", metavar="OUTBOX_PATH",
                        help="Path where remote stdout+stderr should be captured. "
                             "Default: <cwd>/.seif/outbox/<agent>-<timestamp>.log")
    parser.add_argument("--delegate-timeout", metavar="SEC", type=int, default=60,
                        help="SSH timeout for --delegate-to. Default: 60s.")
    parser.add_argument("--vigilant-watch", metavar="PATTERN",
                        help="Register a vigilant watch on a file glob (e.g. '~/.seif/inbox/*.json'). "
                             "Requires --notify-target. Optional: --notify-action (default: outbox), "
                             "--watch-id (auto-generated if omitted). The vigilantd daemon dispatches "
                             "registered watches on every tick.")
    parser.add_argument("--notify-action", metavar="ACTION", default="outbox",
                        help="Notify action for --vigilant-watch. Default: outbox. "
                             "Supported in v0.7.0: outbox.")
    parser.add_argument("--notify-target", metavar="PATH",
                        help="Notify target for --vigilant-watch (e.g. path of an outbox log file).")
    parser.add_argument("--watch-id", metavar="ID",
                        help="Optional watch id for --vigilant-watch / --vigilant-stop. "
                             "Auto-generated for new watches if omitted.")
    parser.add_argument("--vigilant-list", action="store_true",
                        help="List registered vigilant watches.")
    parser.add_argument("--vigilant-status", metavar="STATUS",
                        help="Filter --vigilant-list by status (active | fired | stopped).")
    parser.add_argument("--vigilant-stop", metavar="WATCH_ID",
                        help="Remove a registered vigilant watch by id.")
    parser.add_argument("--self-update", action="store_true",
                        help="Update SEIF on this host using ~/.seif/host-install-config.seif. "
                             "Closes gap-10 friction (different install methods per device).")
    parser.add_argument("--migrate-host-config", action="store_true",
                        help="Interactive schema migration of ~/.seif/host-install-config.seif "
                             "to the latest known version (v2). Per-host run.")
    parser.add_argument("--target-version", metavar="VERSION", default="v2",
                        help="Target schema version for --migrate-host-config (default: v2).")
    parser.add_argument("--config-path", metavar="PATH",
                        help="Override config file path for --migrate-host-config "
                             "(default: ~/.seif/host-install-config.seif).")
    parser.add_argument("--no-backup", action="store_true",
                        help="For --migrate-host-config: skip writing the .bak file before migration.")
    parser.add_argument("--release-broadcast", metavar="VERSION",
                        help="Writer-node only: publish a release-vX.Y.Z.seif module signaling new version available. "
                             "Vigilants on peers can detect it via --pending-list and self-update.")
    parser.add_argument("--release-notes", metavar="TEXT", default="",
                        help="Release notes for --release-broadcast.")
    parser.add_argument("--sync-workspace", action="store_true",
                        help="Sync all SEIF repos on a remote device via SSH (owner only, same local network)")
    parser.add_argument("--sync-workspace-host", metavar="HOST",
                        help="SSH host/alias for --sync-workspace (e.g. my-laptop). Falls back to SEIF_SYNC_HOST env var.")
    parser.add_argument("--sync-workspace-dry-run", action="store_true",
                        help="Show what --sync-workspace would do without making changes")

    args = parser.parse_args()

    if getattr(args, "ascii_art", False):
        from seif.cli.resonance_display import set_ascii_art
        set_ascii_art(True)

    # ── Version ──
    if getattr(args, "version", False):
        try:
            from importlib.metadata import version as pkg_version
            v = pkg_version("seif-cli")
        except Exception:
            v = "0.3.1"
        print(f"seif-cli {v}")
        return

    # ── Help admin ──
    if getattr(args, "help_admin", False):
        print("seif-cli — admin commands:\n")
        print("  --init [PATH]              Initialize .seif context (auto git init if needed)")
        print("  --sync [PATH]              Re-sync git context")
        print("  --quality-gate TEXT        Measure text quality (Grade A-F)")
        print("  --compress [PATH]          Compress source code into .seif")
        print("  --workspace [PATH]         Multi-project workspace sync")
        print("  --profile [init|show|edit] Manage ~/.seif/profile.json")
        print("  --sources [list|add|...]   Manage context sources")
        print("  --onboard                  Guided first-run setup")
        print("  --cycle ACTION             Manage SEIF cycles")
        print("  --absorb [PATH]            Absorb knowledge from directory into .seif")
        print("  --list                     List all registered .seif contexts")
        print("  --status                   Show current .seif context status")
        print("  --context-repo PATH        Use external SEIF Context Repository")
        print("  --export                   Export context (PUBLIC/INTERNAL/CONFIDENTIAL)")
        print("  --consult QUESTION         Inter-AI consultation")
        print("  --boot-check               Run boot check across LLMs")
        print()
        print("  seif --help                Full argument reference")
        return

    # ── Personal Nucleus commands ──
    if args.profile:
        cmd_profile(args)
        return

    if getattr(args, "onboard", False):
        cmd_onboard()
        return

    if args.sources:
        cmd_sources(args)
        return

    if args.extract:
        cmd_extract(args.extract, context_repo=args.context_repo,
                    classification=args.classification)
        return

    if args.absorb is not None:
        cmd_absorb(args.absorb, context_repo=args.context_repo,
                   author=args.author,
                   name=getattr(args, 'absorb_name', None))
        return

    if getattr(args, 'list_contexts', False):
        cmd_list()
        return

    if getattr(args, 'show_status', False):
        cmd_status(context_repo=args.context_repo)
        return

    if getattr(args, 'show_report', False):
        cmd_report(context_repo=args.context_repo)
        return

    if args.keygen:
        cmd_keygen(force=args.force)
        return

    if args.sign:
        cmd_sign(args.sign)
        return

    if args.verify:
        cmd_verify(args.verify)
        return

    if args.sign_all:
        cmd_sign_all(args.sign_all)
        return

    if args.sign_resonance:
        cmd_sign_resonance(args.sign_resonance)
        return

    if args.verify_resonance:
        cmd_verify_resonance(args.verify_resonance)
        return

    if args.transfer:
        missing = [name for name, val in [
            ("--transfer-to", args.transfer_to),
            ("--transfer-scope", args.transfer_scope),
            ("--transfer-reason", args.transfer_reason),
        ] if not val]
        if missing:
            print(f"Error: --transfer requires {', '.join(missing)}")
            return
        cmd_transfer(transfer_to=args.transfer_to, scope=args.transfer_scope,
                     reason=args.transfer_reason, output_dir=args.transfers_dir)
        return

    if args.verify_transfer_chain:
        cmd_verify_transfer_chain(
            scope=args.verify_transfer_chain,
            transfers_dir=args.transfers_dir,
            genesis_pubkey=args.genesis_pubkey,
        )
        return

    if args.stamp:
        cmd_stamp(args.stamp, force=getattr(args, "force", False))
        return

    if args.verify_stamp:
        cmd_verify_stamp(args.verify_stamp)
        return

    if args.stamp_all:
        cmd_stamp_all(args.stamp_all)
        return

    if args.security:
        cmd_security(args)
        return

    if args.proxy or args.proxy_test:
        cmd_proxy(args)
        return

    if args.dia_skill:
        cmd_dia_skill()
        return

    if args.models:
        try:
            from seif.bridge.model_tracker import (
                describe_profiles, update_all_profiles,
                list_behavior_types, record_behavioral_observation,
            )
        except ImportError:
            _upgrade_message("", "Advanced feature — context management, multi-AI, or security.")
            return
        if args.models == "update":
            results = update_all_profiles()
            for r in results:
                status = "updated" if r["updated"] else "no observations"
                print(f"  {r['backend']}: {status}")
            if not results:
                print("  No observations yet. Use 'seif chat' to accumulate data.")
        elif args.models == "behavior":
            print(list_behavior_types())
        elif args.models == "record":
            # Interactive: seif --models record
            # Expects: backend, type, description via remaining args or interactive
            import sys
            remaining = args.text if hasattr(args, "text") and args.text else []
            if len(remaining) >= 3:
                backend = remaining[0]
                btype = remaining[1]
                desc = " ".join(remaining[2:])
            else:
                backend = input("Backend (e.g. grok, deepseek): ").strip()
                btype = input("Type (use 'seif --models behavior' to list): ").strip()
                desc = input("Description (one sentence): ").strip()
            if backend and btype and desc:
                path = record_behavioral_observation(
                    backend=backend,
                    behavior_type=btype,
                    description=desc,
                    observer="human",
                    source="cli",
                )
                print(f"  Recorded {btype} for {backend} → {path}")
            else:
                print("  Missing required fields. Usage: seif --models record")
        else:
            print(describe_profiles())
        return

    if args.health:
        try:
            from seif.bridge.ai_bridge import detect_backends
            from seif.bridge.backend_health import describe_health, load_health, get_healthy_backends
        except ImportError:
            _upgrade_message("--health", "Check AI backend availability and health status.")
            return
        from seif.cli.resonance_display import resonance_header, health_status_line
        detected = detect_backends()
        healthy = get_healthy_backends(detected)
        print(resonance_header("SEIF HEALTH", f"backends: {len(healthy)}/{len(detected)} healthy"))
        print(health_status_line(len(healthy), len(detected)))
        unhealthy = set(detected) - set(healthy)
        if unhealthy:
            print(f"\n  ζ❌  unhealthy: {', '.join(unhealthy)}")
        print()
        print(describe_health())
        return

    if args.audit:
        try:
            from seif.context.autonomous import audit_context, find_context_repo
        except ImportError:
            _upgrade_message("", "Advanced feature — context management, multi-AI, or security.")
            return
        ctx = args.context_repo or find_context_repo() or ".seif"
        print(f"Auditing: {ctx}")
        result = audit_context(ctx, fix=True, sync=True)
        print(result)
        return

    if args.cycle:
        from seif.context.cycle import (
            cycle_status, cycle_audit, cycle_meditate, cycle_absorb,
            cycle_close, cycle_new, cycle_full_circle,
        )
        ctx_repo = args.context_repo or None
        action = args.cycle.lower()
        # s57 PR-5: canonical phase names verify/review/persist/close.
        # Legacy aliases stay one release cycle.
        _PHASE_ALIASES = {"audit": "verify", "meditate": "review", "absorb": "persist"}
        action = _PHASE_ALIASES.get(action, action)
        if action == "status":
            print(cycle_status(ctx_repo))
        elif action == "verify":
            print(cycle_audit(ctx_repo))
        elif action == "review":
            print(cycle_meditate(ctx_repo))
        elif action == "persist":
            print(cycle_absorb(ctx_repo))
        elif action == "close":
            from seif.cli.resonance_display import resonance_footer
            print(cycle_close(context_repo=ctx_repo))
            print(resonance_footer())
        elif action == "new":
            if not args.cycle_name:
                print("Error: --cycle-name required for --cycle new")
                print("Usage: seif --cycle new --cycle-name <name>")
                return
            print(cycle_new(args.cycle_name, args.cycle_parent, ctx_repo))
        elif action == "full-circle":
            print(cycle_full_circle(ctx_repo))
        return

    if args.start_cycle is not None:
        from seif.plugins.core.cycle_lifecycle import start_cycle as _start_cycle
        result = _start_cycle(args.start_cycle, parent_cycle=args.cycle_parent)
        if result["status"] == "error":
            print(f"⚠  {result['message']}")
            return
        print(result["message"])
        print()
        print(f"Host pointer : {result['pointer_path']}")
        print(f"Workspace    : {result['workspace_path']}")
        print(f"Cycle file   : {result['cycle_open_path']}")
        print()
        print("Export so child processes inherit the binding:")
        print(f"  export SEIF_ACTIVE_CYCLE={result['cycle_id']}")
        return

    if args.close_cycle is not None:
        from seif.plugins.core.cycle_lifecycle import close_cycle as _close_cycle
        slug = None if args.close_cycle == "__from_pointer__" else args.close_cycle
        result = _close_cycle(slug, force=getattr(args, "force", False))
        if result["status"] == "error":
            print(f"⚠  {result['message']}")
            return
        print(result["message"])
        print()
        print(f"Host pointer cleared: {result['pointer_cleared']}")
        if result.get("forced_with_blocked_writers"):
            print()
            print(f"⚠  Forced seal: {len(result['forced_with_blocked_writers'])} active writer "
                  f"session(s) were bypassed; force_seal_audit_trail recorded in SEALED file.")
        if result["pointer_cleared"]:
            print("Unset SEIF_ACTIVE_CYCLE in your shell:")
            print("  unset SEIF_ACTIVE_CYCLE")
        return

    if args.re_seal_cycle is not None:
        from seif.plugins.core.cycle_reseal import re_seal_cycle as _re_seal_cycle
        if not args.rationale:
            print("⚠  --re-seal-cycle requires --rationale <TEXT>")
            return
        if not args.delta_list:
            print("⚠  --re-seal-cycle requires --delta-list "
                  "(JSON list literal or path to .json file containing a list)")
            return
        result = _re_seal_cycle(
            args.re_seal_cycle,
            rationale=args.rationale,
            deltas=args.delta_list,
        )
        if result["status"] == "error":
            print(f"⚠  {result['message']}")
            return
        print(result["message"])
        print(f"   Sealed file  : {result['sealed_path']}")
        print(f"   History size : {result['history_length']} entry(ies)")
        print(f"   Re-sealed at : {result['entry']['re_sealed_at']}")
        print(f"   Re-sealed by : {result['entry']['re_sealed_by']}")
        if result["entry"]["deltas"]:
            print(f"   Deltas       : {len(result['entry']['deltas'])}")
            for d in result["entry"]["deltas"]:
                print(f"     · {d}")
        return

    if getattr(args, "emit_n2_bundle", False):
        import sys as _sys
        from seif.core.n2_bundle import emit_bundle as _emit_bundle
        ws_arg = args.workspace if args.workspace is not None else None
        try:
            result = _emit_bundle(workspace=ws_arg, week=args.week)
        except FileNotFoundError as e:
            print(f"⚠  --emit-n2-bundle: {e}")
            _sys.exit(2)
        except ValueError as e:
            print(f"⚠  --emit-n2-bundle: {e}")
            _sys.exit(2)
        if result["status"] == "error":
            print(f"⚠  {result['message']}")
            _sys.exit(2)
        print("─── N2 BUNDLE EMITTED ─────────────────────────────────")
        print(f"  bundle_id   : {result['bundle_id']}")
        print(f"  bundle_path : {result['bundle_path']}")
        print(f"  cycles      : {result['cycle_count']}")
        print(f"  seeds       : {result['seed_count']}")
        if result.get("is_re_emit"):
            print("  re-emit     : YES (.json.v2+ — v1 preserved per amendment-chain)")
        if result.get("ots"):
            ots = result["ots"]
            print(f"  ots         : {'stamped' if ots.get('stamped') else 'skipped/failed'} "
                  f"— {ots.get('message', '')}")
        print("───────────────────────────────────────────────────────")
        return

    if args.verify_n2 is not None:
        import sys as _sys
        from seif.core.n2_bundle import verify_bundle as _verify_bundle
        ws_arg = args.workspace if args.workspace is not None else None
        result = _verify_bundle(args.verify_n2, workspace=ws_arg, strict=args.strict)
        print("─── N2 BUNDLE VERIFY ──────────────────────────────────")
        print(f"  status      : {result['status']}")
        print(f"  valid       : {result['valid']}")
        print(f"  reason      : {result['reason']}")
        print(f"  signature   : {'valid' if result['signature_valid'] else 'INVALID'}")
        print(f"  body hash   : {'match' if result['body_canonical_hash_match'] else 'MISMATCH'}")
        print(f"  kernel      : {'match' if result['kernel_anchor_match'] else 'ROTATED'}")
        if result["cycle_findings"]:
            print(f"  cycles ({len(result['cycle_findings'])}):")
            for f in result["cycle_findings"]:
                print(f"    · [{f['kind']}] {f.get('slug', '')}")
        if result["seed_findings"]:
            print(f"  seeds ({len(result['seed_findings'])}):")
            for f in result["seed_findings"]:
                print(f"    · [{f['kind']}] {f.get('seed_id', '')}")
        ots = result.get("ots", {})
        if ots.get("present"):
            print(f"  ots         : {ots.get('message', '(no detail)')}")
        print("───────────────────────────────────────────────────────")
        _sys.exit(0 if result["valid"] else 1)

    if args.audit_cycle_coherence:
        import sys as _sys
        from seif.plugins.core.cycle_coherence import (
            audit_cycle_coherence as _audit_coherence,
            format_report as _format_coherence,
        )
        try:
            report = _audit_coherence()
        except ValueError as e:
            print(f"⚠  {e}")
            _sys.exit(2)
        print(_format_coherence(report))
        if getattr(args, "heal", False):
            from seif.plugins.core.cycle_heal import build_heal_plan, write_heal_plan
            try:
                plan = build_heal_plan()
                plan_path = write_heal_plan(plan)
            except ValueError as e:
                print(f"⚠  --heal failed: {e}")
                _sys.exit(2)
            print()
            print("─── HEAL PLAN (read-only) ─────────────────────────────")
            print(f"  plan_id   : {plan['plan_id']}")
            print(f"  plan path : {plan_path}")
            print(f"  actions   : {len(plan['actions'])}")
            for a in plan["actions"]:
                print(f"    · {a['kind']}  session={a.get('session_id','')[:8]}…  "
                      f"cycle={a.get('cycle_id','')}")
            print()
            print(f"  Apply with: seif --heal-apply {plan_path}")
            print("───────────────────────────────────────────────────────")
        _sys.exit(1 if report.has_violations else 0)

    if args.heal_apply is not None:
        import sys as _sys
        from seif.plugins.core.cycle_heal import apply_heal_plan
        try:
            outcome = apply_heal_plan(args.heal_apply)
        except ValueError as e:
            print(f"⚠  --heal-apply failed: {e}")
            _sys.exit(2)
        s = outcome["summary"]
        print("─── HEAL APPLY ────────────────────────────────────────")
        print(f"  plan_id    : {outcome['plan_id']}")
        print(f"  applied_at : {outcome['applied_at']}")
        print(f"  applied    : {s['applied']}")
        print(f"  skipped    : {s['skipped']}")
        print(f"  errors     : {s['errors']}")
        print(f"  total      : {s['total']}")
        print()
        for r in outcome["results"]:
            tag = "✓" if r["applied"] else "·"
            sid = r["action"].get("session_id", "?")[:8]
            print(f"  {tag} {sid}…  {r['message']}")
        print("───────────────────────────────────────────────────────")
        _sys.exit(0 if s["errors"] == 0 else 1)

    if getattr(args, "sessions_active", False):
        _cmd_sessions_active(
            as_json=getattr(args, "json", False)
                    and not getattr(args, "table", False),
        )
        return

    if args.identity_scan is not None:
        try:
            from seif_engine.identity.scanner import scan_workspace, format_scan_report
        except ImportError:
            print("⚠  seif-engine not available — identity scanner requires the engine.")
            return
        target = args.identity_scan or "local"
        import socket as _socket
        _machine_id = __import__("os").environ.get("SEIF_MACHINE_ID") or _socket.gethostname()
        local_scan = scan_workspace(machine=_machine_id)
        if target == "local":
            print(format_scan_report(local_scan))
        else:
            remote_path = getattr(args, "identity_scan_path", None) or \
                __import__("os").environ.get("SEIF_CONTEXT_MODULES", "~/seif-admin/seif-context/modules")
            remote_scan = scan_workspace(
                machine="air-m1",
                ssh_host=target,
                remote_path=remote_path,
            )
            print(format_scan_report(local_scan, remote_scan))
        return

    # ctx_repo default for owner-level commands (start, agents, sync-workspace)
    if "ctx_repo" not in dir():
        ctx_repo = getattr(args, "context_repo", None) or None

    if args.start:
        _cmd_start(ctx_repo)
        return

    if args.agents:
        _cmd_agents_show(ctx_repo)
        return

    if args.agents_set:
        _cmd_agents_set(args.agents_set, ctx_repo)
        return

    # ── Pending modules subcommand family (gap-14 / branch-7 of s32) ──
    if args.pending_list or (args.pending and not args.pending_register and not args.pending_consume):
        _cmd_pending_list(all_workspaces=getattr(args, "all_workspaces", False))
        return

    if args.pending_register:
        _cmd_pending_register(
            args.pending_register,
            visibility_override=getattr(args, "visibility", None),
        )
        return

    if args.pending_consume:
        _cmd_pending_consume(
            args.pending_consume,
            consumed_in_cycle=getattr(args, "consumed_in_cycle", None),
        )
        return

    if getattr(args, "delegate_to", None):
        _cmd_delegate_to(
            ssh_host=args.delegate_to,
            agent_name=getattr(args, "as_agent", None),
            seed_path=getattr(args, "seed", None),
            outbox_path=getattr(args, "outbox", None),
            timeout_sec=getattr(args, "delegate_timeout", 60),
        )
        return

    if getattr(args, "vigilant_watch", None):
        _cmd_vigilant_watch(
            pattern=args.vigilant_watch,
            notify_action=getattr(args, "notify_action", "outbox"),
            notify_target=getattr(args, "notify_target", None),
            watch_id=getattr(args, "watch_id", None),
        )
        return

    if getattr(args, "vigilant_list", False):
        _cmd_vigilant_list(status_filter=getattr(args, "vigilant_status", None))
        return

    if getattr(args, "vigilant_stop", None):
        _cmd_vigilant_stop(args.vigilant_stop)
        return

    if args.sync_workspace or args.sync_workspace_dry_run:
        host = getattr(args, "sync_workspace_host", None)
        dry = getattr(args, "sync_workspace_dry_run", False)
        _cmd_sync_workspace(ctx_repo, host=host, dry_run=dry)
        return

    if getattr(args, "self_update", False):
        _cmd_self_update()
        return

    if getattr(args, "migrate_host_config", False):
        rc = _cmd_migrate_host_config(
            target_version=getattr(args, "target_version", "v2"),
            config_path=getattr(args, "config_path", None),
            dry_run=getattr(args, "dry_run", False),
            yes=getattr(args, "yes", False),
            backup=not getattr(args, "no_backup", False),
        )
        import sys as _sys
        _sys.exit(rc)

    if getattr(args, "release_broadcast", None):
        _cmd_release_broadcast(
            version=args.release_broadcast,
            ctx_repo=ctx_repo,
            notes=getattr(args, "release_notes", "") or "",
        )
        return

    if args.fingerprint_verify:
        cmd_fingerprint_verify(args.fingerprint_verify)
        return

    if args.fingerprint_update:
        cmd_fingerprint_update(args.fingerprint_update, args.fingerprint_output)
        return

    if args.integrity_update:
        import sys as _sys
        rc = cmd_integrity_update(
            args.integrity_update,
            skip_sign=getattr(args, "integrity_skip_sign", False),
            skip_stamp=getattr(args, "integrity_skip_stamp", False),
            as_json=getattr(args, "json", False),
        )
        _sys.exit(rc)

    if args.verify_integrity:
        import sys as _sys
        rc = cmd_verify_integrity(
            args.verify_integrity,
            as_json=getattr(args, "json", False),
        )
        _sys.exit(rc)

    if args.migrate_integrity:
        import sys as _sys
        rc = cmd_migrate_integrity(
            args.migrate_integrity,
            exclude_from=getattr(args, "integrity_exclude_from", None),
            skip_stamp=getattr(args, "integrity_skip_stamp", False),
            as_json=getattr(args, "json", False),
        )
        _sys.exit(rc)

    if args.streaming_list:
        cmd_streaming_list()
        return

    if args.streaming_start:
        cmd_streaming_start(
            args.streaming_session,
            args.streaming_audio_interval,
            args.streaming_text_interval,
            args.streaming_max,
            args.streaming_identity
        )
        return

    if args.streaming_status:
        cmd_streaming_status(args.streaming_session)
        return

    if args.streaming_stop:
        cmd_streaming_stop(args.streaming_session)
        return

    if args.boot_check:
        cmd_boot_check(
            args.boot_to or [],
            args.boot_core,
            args.boot_max_parallel,
            args.boot_auto,
            args.boot_all
        )
        return

    if args.session:
        # Gap 58 fix: --session list works without seif-engine. Walks the v2
        # session registry on disk (.seif/sessions/active/ + sealed/<cycle>/)
        # so operators can discover their own sessions even when the paid
        # engine bridge is not installed. Other actions still require the
        # engine; the upgrade message fires below for those.
        if args.session.lower() == "list":
            _cmd_session_list_unified(as_json=getattr(args, "json", False))
            return
        try:
            from seif.context.sessions import (
                create_session, contribute_to_session, close_session,
                list_sessions, describe_session, session_log,
                create_session_v2, add_participant, create_sync_point,
                generate_sync_prompt, contribute_with_sync_check,
                needs_sync, upgrade_to_v2, close_all_open, close_stale,
                find_context_repo,
            )
            try:
                from seif.context.autonomous import find_context_repo
            except ImportError:
                pass  # Already imported from sessions
        except ImportError:
            _upgrade_message("--session", "Track and manage multi-AI collaboration sessions.")
            return
        ctx = args.context_repo or find_context_repo() or ".seif"
        action = args.session.lower()
        name = args.session_name
        author_name = args.author or "unknown"

        if action == "create":
            if not name:
                print("Error: --session-name required for create")
                sys.exit(1)
            path = create_session_v2(ctx, name, author_name, purpose=args.session_message or "")
            print(f"Session created (v2): {name}")
            print(f"  Path: {path}")
            print(f"  Protocol: SEIF-SESSION-v2 (mesh topology, auto-sync)")
            print(f"  Add participants: seif --session add-participant --session-name {name} --participant-id grok --participant-channel handshake")
            print(f"  Contribute: seif --session contribute --session-name {name} --session-message \"...\" --author name")
        elif action == "contribute":
            if not name or not args.session_message:
                print("Error: --session-name and --session-message required for contribute")
                sys.exit(1)
            result, synced = contribute_with_sync_check(
                ctx, name, args.session_message, author_name,
                via="cli", auto_sync_author=author_name,
            )
            print(f"Contributed to session '{name}' (v{result.get('version', '?')})")
            if synced:
                print(f"  [AUTO-SYNC] Sync point created (threshold reached)")
        elif action == "close":
            if not name:
                print("Error: --session-name required for close")
                sys.exit(1)
            path = close_session(ctx, name, author_name)
            print(f"Session '{name}' closed.")
            print(f"  Archived: {path}")
            from seif.cli.resonance_display import resonance_footer
            print(resonance_footer())
        elif action == "list":
            sessions = list_sessions(ctx)
            if not sessions:
                print("No sessions found.")
            else:
                for s in sessions:
                    status = "●" if s["status"] == "OPEN" else "○"
                    interrupt_flag = " [INTERRUPTED]" if s.get("interrupted") else ""
                    print(f"  {status} {s['name']} [{s['status']}]{interrupt_flag} v{s['version']} ({s['contributors']} contributors, updated {s['updated']})")
        elif action == "log":
            if not name:
                print("Error: --session-name required for log")
                sys.exit(1)
            print(session_log(ctx, name))
        elif action == "show":
            if not name:
                print("Error: --session-name required for show")
                sys.exit(1)
            print(describe_session(ctx, name))
        elif action == "add-participant":
            if not name or not args.participant_id:
                print("Error: --session-name and --participant-id required for add-participant")
                sys.exit(1)
            add_participant(
                ctx, name, args.participant_id,
                role=args.participant_role,
                channel=args.participant_channel,
                author=author_name,
            )
            print(f"Added participant '{args.participant_id}' to session '{name}'")
            print(f"  Role: {args.participant_role} | Channel: {args.participant_channel}")
        elif action == "sync":
            if not name:
                print("Error: --session-name required for sync")
                sys.exit(1)
            should, unsynced = needs_sync(ctx, name)
            result = create_sync_point(
                ctx, name, author_name,
                digest=args.session_message or "",
            )
            print(f"Sync point created for session '{name}' (v{result.get('version', '?')})")
            print(f"  Hash: {result.get('integrity_hash', '?')}")
            syncs = result.get("sync_points", [])
            if syncs:
                print(f"  Digest: {syncs[-1].get('digest', '')}")
        elif action == "sync-prompt":
            if not name or not args.participant_id:
                print("Error: --session-name and --participant-id required for sync-prompt")
                sys.exit(1)
            prompt = generate_sync_prompt(ctx, name, args.participant_id)
            print(prompt)
        elif action == "resume":
            if not name:
                print("Error: --session-name required for resume")
                sys.exit(1)
            # Resume interrupted session by updating status or contributing
            from seif.context.sessions import update_session_status
            update_session_status(ctx, name, "OPEN", author_name)
            print(f"Session '{name}' resumed.")
        elif action == "upgrade":
            if not name:
                print("Error: --session-name required for upgrade")
                sys.exit(1)
            result = upgrade_to_v2(ctx, name)
            print(f"Session '{name}' upgraded to SEIF-SESSION-v2")
            parts = result.get("participants", [])
            for p in parts:
                print(f"  - {p['id']} [{p['role']}] via {p['channel']}")
        elif action == "close-all":
            author_name = args.author or "session-hook"
            closed = close_all_open(ctx, author=author_name)
            if closed:
                print(f"Closed {len(closed)} session(s):")
                for s in closed:
                    print(f"  - {s}")
            else:
                print("No open sessions to close.")
        elif action == "close-stale":
            timeout = 4.0  # default 4 hours
            if args.session_message:
                try:
                    timeout = float(args.session_message)
                except ValueError:
                    pass
            author_name = args.author or "heartbeat"
            closed = close_stale(ctx, timeout_hours=timeout, author=author_name)
            if closed:
                print(f"Closed {len(closed)} stale session(s) (inactive > {timeout}h):")
                for s in closed:
                    print(f"  - {s}")
            else:
                print(f"No stale sessions (threshold: {timeout}h).")
        else:
            print(f"Unknown session action: {action}")
            print("Available: create, contribute, close, close-all, close-stale, list, log, show, add-participant, sync, sync-prompt, upgrade")
        return

    if args.handoff:
        cmd_handoff(args.handoff, context_repo=args.context_repo)
        return

    if args.mirror_weekly:
        cmd_mirror_weekly(context_repo=args.context_repo)
        return

    if args.verify_seed:
        cmd_verify_seed()
        return

    if args.evolve:
        cmd_evolve()
        return

    if args.communicate:
        cmd_communicate(args.communicate)
        return

    if args.text and args.text.startswith("~new"):
        parts = args.text.split()
        if len(parts) < 2:
            print("Usage: ~new <session_name> [purpose]")
            return
        name = parts[1]
        purpose = " ".join(parts[2:]) if len(parts) > 2 else ""
        try:
            from seif.context.sessions import create_session_v2
            from seif.context.autonomous import find_context_repo
        except ImportError:
            _upgrade_message("--session", "Track and manage multi-AI collaboration sessions.")
            return
        ctx = args.context_repo or find_context_repo() or ".seif"
        author_name = args.author or "unknown"
        path = create_session_v2(ctx, name, author_name, purpose=purpose)
        print(f"New session created: {name}")
        print(f"  Path: {path}")
        print(f"  Purpose: {purpose or 'none'}")
        return

    if args.handshake:
        cmd_handshake(args.handshake, full=getattr(args, 'full', False))
        return

    if args.generate:
        cmd_generate(args.generate, context_repo=args.context_repo,
                     classification=getattr(args, 'classification', 'INTERNAL') or 'INTERNAL')
        return

    if args.changelog:
        cmd_changelog(args.changelog, context_repo=args.context_repo)
        return

    if args.scan:
        cmd_scan(args.scan, global_store=args.global_store,
                 max_depth=args.scan_depth, output=args.output)
        return

    if args.adversarial:
        cmd_adversarial(args.adversarial, args.context or [],
                        args.to, args.allow_confidential, args.output,
                        session_name=args.session_name,
                        context_repo=args.context_repo)
        return

    if args.consult:
        cmd_consult(args.consult, args.context or [],
                    args.to, args.allow_confidential, args.output,
                    manual=args.manual, session_name=args.session_name,
                    context_repo=args.context_repo)
        return

    if args.watermark_embed:
        if not args.text and not args.fingerprint_of:
            parser.error("text or --fingerprint-of FILE is required for --watermark-embed")
        output_wav = args.watermark_output or args.watermark_embed.replace('.wav', '_watermarked.wav')
        cmd_watermark_embed(args.text, args.watermark_embed, output_wav,
                            args.watermark_reps, args.watermark_duration,
                            args.watermark_amplitude,
                            fingerprint_of=args.fingerprint_of)
        return

    if args.watermark_extract:
        if args.watermark_symbols <= 0 and not args.against:
            parser.error("--watermark-symbols is required for --watermark-extract "
                         "(or pass --against FILE; symbols defaults to len(sha256(FILE))=64)")
        n_symbols = args.watermark_symbols if args.watermark_symbols > 0 else 64
        cmd_watermark_extract(args.watermark_extract, n_symbols,
                              args.watermark_reps, args.watermark_duration,
                              against=args.against)
        return

    if getattr(args, "verify_audio_provenance", None):
        if not args.envelope:
            parser.error("--verify-audio-provenance requires --envelope ENV_JSON")
        from seif.audio_provenance import verify_audio_against_envelope_file
        n_symbols = args.watermark_symbols if args.watermark_symbols > 0 else 64
        result = verify_audio_against_envelope_file(
            args.verify_audio_provenance,
            args.envelope,
            n_symbols=n_symbols,
            repetitions=args.watermark_reps,
            symbol_duration=args.watermark_duration,
        )
        import sys as _sys
        if not result["ok"]:
            print(f"[seif --verify-audio-provenance] structural error: "
                  f"{result['error']}", file=_sys.stderr)
            if "detail" in result:
                print(f"  detail: {result['detail']}", file=_sys.stderr)
            _sys.exit(2)
        print(f"[SEIF AUDIO PROVENANCE] {'VALID' if result['valid'] else 'MISMATCH'}")
        print(f"  Audio:    {result['input_wav']}")
        print(f"  Extracted: {result['extracted']}")
        print(f"  Expected:  {result['expected_content_sha256']}")
        _sys.exit(0 if result["valid"] else 1)

    if getattr(args, "mcp_watermark", False):
        try:
            from seif.mcp.watermark_server import main as _mcp_main
        except ImportError as e:
            print(f"Error: {e}")
            return
        _mcp_main()
        return

    if getattr(args, "mcp_server", False):
        try:
            from seif.mcp.server import main as _mcp_server_main
        except ImportError as e:
            print(f"Error: {e}")
            return
        _mcp_server_main()
        return

    if getattr(args, "log_submit", None) is not None:
        _cmd_log_submit(args)
        return

    if getattr(args, "log_verify", None) is not None:
        _cmd_log_verify(args)
        return

    if getattr(args, "log_list", False):
        _cmd_log_list(args)
        return

    if args.packet is not None:
        cmd_packet(
            module_path=args.packet if args.packet else None,
            message=args.prompt,
            sender="claude_cli",
            receiver=args.to or "",
            classification=args.classification,
            output=args.output,
            send=args.send,
        )
        return

    if args.relay:
        cmd_relay(args.relay, args.to or "claude", args.prompt, args.output)
        return

    if args.consensus:
        backends = [b.strip() for b in args.backends.split(",")]
        cmd_consensus(args.consensus, args.context or [], backends,
                      args.output, args.coherence_threshold,
                      mirror=args.mirror, rounds=args.rounds)
        return

    if args.autonomous is not None:
        cmd_autonomous(args.autonomous, args.context_repo or ".seif")
        return

    if args.export is not None:
        cmd_export(args.context_repo or ".seif", args.classification, args.export)
        return

    if args.install_hooks is not None:
        cmd_install_hooks(args.install_hooks)
        return

    if args.compress is not None:
        cmd_compress(args.compress, watch=args.watch,
                     context_repo=args.context_repo, author=args.author)
        return

    # `--init-lite PATH` is an alias for `--init PATH --lite`.
    if getattr(args, "init_lite", None) is not None:
        if args.init is not None and args.init != args.init_lite:
            print("Error: --init and --init-lite refer to different paths.")
            return
        args.init = args.init_lite
        args.lite = True

    if args.init is not None and getattr(args, "lite", False):
        from pathlib import Path as _P
        from seif.init_lite import run_init_lite

        target = _P(args.init).resolve()
        title = args.lite_name or target.name or "workspace"
        try:
            created = run_init_lite(
                target,
                project_title=title,
                force=args.force,
                with_agents=not getattr(args, "no_lite_agents", False),
            )
        except RuntimeError as e:
            print(f"Error: {e}")
            return
        print(f"SEIF Lite scaffold at {target} ({len(created)} file(s) written):")
        for p in created:
            print(f"  + {p.relative_to(target)}")
        if not created:
            print("  (no files written — already present; use --force to overwrite)")
        if getattr(args, "no_lite_agents", False):
            print("\nNext: read .seif-lite/BOOT.md.")
        else:
            print("\nNext: read AGENTS.md, then .seif-lite/BOOT.md.")
        return

    if args.init is not None:
        cmd_init(args.init, args.author, context_repo=args.context_repo,
                auto_yes=args.yes)
        return

    if getattr(args, "circuit_setup", False):
        from seif.cli.circuit_setup import setup as _circuit_setup
        _circuit_setup(check=args.dry_run)
        return

    if getattr(args, "rebuild_registry", False):
        cmd_rebuild_registry(scan_roots=args.scan_root, dry_run=args.dry_run)
        return

    if getattr(args, "probe_models", False):
        cmd_probe_models(machine_label=args.machine_label,
                         output_format=args.format,
                         dry_run=args.dry_run)
        return

    if getattr(args, "init_host", False):
        cmd_init_host(label=args.label,
                      role=args.host_role,
                      overwrite_machine_id=args.overwrite_machine_id,
                      hub_specs=args.hub,
                      source_specs=args.source,
                      dry_run=args.dry_run)
        return

    if getattr(args, "audit_host", False):
        cmd_audit_host(fix=args.fix_host, dry_run=args.dry_run)
        return

    if getattr(args, "audit_layout", False):
        import sys as _sys
        _sys.exit(cmd_audit_layout())

    if getattr(args, "check_seed_constraint", None) is not None:
        import sys as _sys
        _sys.exit(cmd_check_seed_constraint(args.check_seed_constraint))

    if getattr(args, "plugin_sync", False):
        import sys as _sys
        from seif.cli.plugin_sync import run_plugin_sync
        args.check = True  # only --check is implemented in this build
        _sys.exit(run_plugin_sync(args))

    if getattr(args, "plugin_detect", False):
        import sys as _sys
        from seif.cli.plugin_detect import run_plugin_detect
        _sys.exit(run_plugin_detect(args))

    if getattr(args, "confirm_action", None):
        import sys as _sys
        from seif.cli.confirm_action import cli_entry as _confirm_entry
        _sys.exit(_confirm_entry(args))

    if getattr(args, "inbox", False):
        import sys as _sys
        from seif.plugins.core import circuit_monitor as _cm
        # Two-step pipeline matching the contract circuit-setup hooks expect
        _cm.check_inbox()
        _sys.exit(_cm.drain_inbox())

    if getattr(args, "classify", None):
        import sys as _sys
        from pathlib import Path as _Path
        target = args.classify
        # Auto-detect: if it's a file, read it; else treat as literal text
        candidate = _Path(target).expanduser()
        if candidate.is_file():
            try:
                content = candidate.read_text(encoding="utf-8", errors="replace")
                source = f"file: {candidate}"
            except Exception as e:
                print(f"[seif --classify] could not read {candidate}: {e}",
                      file=_sys.stderr)
                _sys.exit(1)
        else:
            content = target
            source = "(inline text)"
        try:
            from seif.context.file_extractor import _auto_classify as _ac
            level = _ac(content)
        except Exception as e:
            print(f"[seif --classify] classifier unavailable: {e}",
                  file=_sys.stderr)
            _sys.exit(1)
        print(f"[SEIF CLASSIFY] {level}")
        print(f"  Source: {source}")
        print(f"  Length: {len(content)} chars")
        # Exit code carries the classification: 0=PUBLIC, 1=INTERNAL,
        # 2=CONFIDENTIAL — same convention as confirm-action (2=needs-attention).
        if level == "CONFIDENTIAL":
            _sys.exit(2)
        if level == "INTERNAL":
            _sys.exit(1)
        _sys.exit(0)

    if args.sync is not None:
        cmd_sync(args.sync, args.author, args.via, context_repo=args.context_repo)
        return

    if args.workspace is not None:
        cmd_workspace(args.workspace, ingest_source=args.ingest,
                       author=args.author, via=args.via,
                       context_repo=args.context_repo)
        return

    if args.ingest:
        project = args.project or ".seif/project.seif"
        cmd_ingest(args.ingest, project, args.author, args.via)
        return

    if args.quality_gate:
        if not args.text:
            parser.error("text is required for --quality-gate")
        cmd_quality_gate(args.text, args.role)
        return

    if args.contribute:
        cmd_contribute(args.contribute, args.text, args.author, args.via)
        return

    if not args.text:
        parser.error("text is required (unless using --sync)")

    flags = [args.gate, args.transcompile, args.glyph, args.audio,
             args.fractal, args.circuit, args.composite, args.encode, args.artifact, args.all]
    if not any(flags):
        args.all = True

    if args.artifact:
        cmd_analyze_artifact(args.text)
    elif args.gate:
        cmd_gate(args.text)
    elif args.transcompile:
        cmd_transcompile(args.text)
    elif args.glyph:
        cmd_glyph(args.text)
    elif args.audio:
        cmd_audio(args.text)
    elif args.fractal:
        cmd_fractal(args.text)
    elif args.circuit:
        cmd_circuit(args.text)
    elif args.composite:
        cmd_composite(args.text)
    elif args.encode:
        cmd_encode(args.text)
    else:
        cmd_all(args.text)


if __name__ == "__main__":
    main()
