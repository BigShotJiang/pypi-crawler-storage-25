#!/usr/bin/env bash
# seif-update.sh — declarative SEIF update per host
# Reads ~/.seif/host-install-config.seif and dispatches the right install command.
# Removes friction of remembering install method per device.
#
# Usage:
#   seif-update                  # update using config + run post-install check
#   seif-update --check          # show config + what would run, do nothing
#   seif-update --version        # show current installed seif version
#   seif-update --no-restart     # skip daemon restart stage (P5)
#   seif-update --no-rollback    # on smoke-test fail, exit 1 without offering rollback (P6)
#   seif-update --auto-rollback  # on smoke-test fail, rollback without prompting (P6)
#   seif-update --no-template-refresh  # skip Stage 1.5 self-refresh of this script (s43 B1)
#
# Schema v2 (s41 trio) adds optional fields:
#   package_source: 'pypi' (default) | 'git+<url>'  → P2: pipx --force for git
#   bridge_repo: { method: 'git'|'rsync'|'none', source_path, upstream }  → P4
#   restart_jobs: [pattern...]  (default: 'com.seif.*')                  → P5
#
# s41 P6: pre-update snapshot + smoke-test verification + prompt-gated
# rollback. Default = prompt on failure when stdin is a TTY (operator
# confirms before any rollback touches installed packages); when invoked
# non-interactively (subprocess from `seif --self-update` over SSH, etc.),
# default falls back to printing actionable rollback commands and exiting
# non-zero — never auto-undo.

set -euo pipefail

# Defensive PATH prepend — when invoked via `seif --self-update` (Python
# subprocess) or via SSH non-interactive shell, common toolchain locations
# (Homebrew, ~/.local) may be missing. Prepend the usual suspects so pipx,
# brew-managed binaries, and pip-user installs are always discoverable.
for d in "$HOME/.local/bin" "/opt/homebrew/bin" "/opt/homebrew/sbin" "/usr/local/bin" "/data/data/com.termux/files/usr/bin"; do
  case ":$PATH:" in
    *":$d:"*) ;;
    *) [ -d "$d" ] && PATH="$d:$PATH" ;;
  esac
done
export PATH

# Parse flags. Order-independent.
RESTART=1
ROLLBACK_MODE="prompt"   # 'prompt' (default), 'auto', 'none'
TEMPLATE_REFRESH=1
MODE="update"
for arg in "$@"; do
  case "$arg" in
    --no-restart)          RESTART=0 ;;
    --no-rollback)         ROLLBACK_MODE="none" ;;
    --auto-rollback)       ROLLBACK_MODE="auto" ;;
    --no-template-refresh) TEMPLATE_REFRESH=0 ;;
    --check)               MODE="check" ;;
    --version)             MODE="version" ;;
  esac
done

CFG=$HOME/.seif/host-install-config.seif
if [ ! -f "$CFG" ]; then
  echo "✗ No host-install-config.seif found at $CFG"
  echo "  Create one with: see /Volumes/DockerData/seif-projects/docs/seif-cli-reference.md §41.5"
  exit 1
fi

method=$(python3 -c "import json; print(json.load(open(\"$CFG\")).get(\"install_method\",\"\"))")
label=$(python3 -c "import json; print(json.load(open(\"$CFG\")).get(\"host_label\",\"unknown\"))")
pkg=$(python3 -c "import json; print(json.load(open(\"$CFG\")).get(\"package_name\",\"seif-cli\"))")
# Filter extras to valid pip package specs only (skip free-form comments
# like "seif-engine (local rsync from mini)" which break `pipx inject`).
extras=$(python3 -c "
import json, re
ex = json.load(open('$CFG')).get('extra_packages', [])
valid = [p for p in ex if re.match(r'^[a-zA-Z0-9_\-\.\[\]<>=,]+$', p)]
print(' '.join(valid))
")
check=$(python3 -c "import json; print(json.load(open(\"$CFG\")).get(\"post_install_check\",\"seif --version\"))")

# s41 P2: pipx with git source needs --force (version-equality check skips
# git-source upgrades when pyproject.toml version is unchanged).
package_source=$(python3 -c "import json; print(json.load(open(\"$CFG\")).get(\"package_source\",\"pypi\"))")

# s41 P4: bridge repo sync per host method.
bridge_method=$(python3 -c "
import json
br = json.load(open('$CFG')).get('bridge_repo', {})
print(br.get('method', 'none'))
")
bridge_source_path=$(python3 -c "
import json
br = json.load(open('$CFG')).get('bridge_repo', {})
print(br.get('source_path', ''))
")
bridge_upstream=$(python3 -c "
import json
br = json.load(open('$CFG')).get('bridge_repo', {})
print(br.get('upstream', ''))
")

# s41 P5: restart job patterns. Default = match anything starting with 'com.seif.'.
restart_jobs=$(python3 -c "
import json
rj = json.load(open('$CFG')).get('restart_jobs', ['com.seif.*'])
print(' '.join(rj))
")

echo "═══ SEIF UPDATE ═══════════════════════════════════════"
echo "  host:    $label"
echo "  method:  $method  (source: $package_source)"
echo "  package: $pkg"
echo "  extras:  $extras"
echo "  bridge:  $bridge_method${bridge_source_path:+ ($bridge_source_path)}"
echo "  restart: $([ "$RESTART" = "1" ] && echo "yes ($restart_jobs)" || echo "no (--no-restart)")"
echo "  template-refresh: $([ "$TEMPLATE_REFRESH" = "1" ] && echo "yes" || echo "no (--no-template-refresh)")"
echo "  check:   $check"
echo "═══════════════════════════════════════════════════════"

case "$MODE" in
  check)
    echo "(dry-run — would dispatch based on method=$method, source=$package_source, bridge=$bridge_method)"
    exit 0
    ;;
  version)
    seif --version 2>&1
    exit 0
    ;;
esac

# ── Stage 0: pre-update snapshot (s41 P6) ───────────────────────
# Capture state before any mutation so we can roll back if the post-install
# smoke test fails. Default = prompt on failure (operator confirms); see
# --no-rollback / --auto-rollback for non-interactive overrides.
SNAPSHOT_FILE="$(mktemp -t seif-update-snapshot.XXXXXX)"
trap 'rm -f "$SNAPSHOT_FILE"' EXIT

pre_pkg_version="$(seif --version 2>/dev/null || echo 'unknown')"
pre_pkg_git_hash=""
if [ "$method" = "editable" ]; then
  pre_src=$(python3 -c "import json; print(json.load(open(\"$CFG\")).get(\"source_repo\",\"\"))")
  if [ -n "$pre_src" ] && [ -d "$pre_src/.git" ]; then
    pre_pkg_git_hash=$(git -C "$pre_src" rev-parse HEAD 2>/dev/null || echo "")
  fi
fi
pre_bridge_git_hash=""
if [ "$bridge_method" = "git" ] && [ -n "$bridge_source_path" ] && [ -d "$bridge_source_path/.git" ]; then
  pre_bridge_git_hash=$(git -C "$bridge_source_path" rev-parse HEAD 2>/dev/null || echo "")
fi

# s43 B3: rsync rollback flag — set to 1 in Stage 2 after successful atomic
# swap. Stage 4 reads this to decide whether <bridge_source>.prev is fresh
# (created this run) and safe to use for rollback.
bridge_rsync_swap_done=0

# s43 B2: pipx-from-git rollback support — capture the package's currently
# resolved git URL + commit BEFORE pipx install --force destroys the venv.
# Two sources tried in order:
#   1. pipx list --json → main_package.package_or_url (whatever ref was used)
#   2. <pipx-venv>/lib/python*/site-packages/*-*.dist-info/direct_url.json
#      → vcs_info.commit_id (the resolved SHA, more reliable for rollback)
# Both captured; rollback prefers commit_id when present.
pre_pkg_pipx_url=""
pre_pkg_pipx_commit=""
if [ "$method" = "pipx" ] && [[ "$package_source" == git+* ]]; then
  pipx_capture=$(python3 - "$pkg" <<'PYEOF' 2>/dev/null
import json, subprocess, pathlib, sys
pkg = sys.argv[1]
out = {"pipx_url": "", "pipx_commit": ""}
try:
    r = subprocess.run(["pipx", "list", "--json"], capture_output=True, text=True, timeout=10)
    if r.returncode == 0:
        data = json.loads(r.stdout)
        venv = data.get("venvs", {}).get(pkg, {})
        url = venv.get("metadata", {}).get("main_package", {}).get("package_or_url", "")
        out["pipx_url"] = url
except Exception:
    pass
try:
    r2 = subprocess.run(["pipx", "environment", "--value", "PIPX_LOCAL_VENVS"], capture_output=True, text=True, timeout=5)
    if r2.returncode == 0:
        local = pathlib.Path(r2.stdout.strip()) / pkg
        for du in local.glob("lib/python*/site-packages/*.dist-info/direct_url.json"):
            info = json.loads(du.read_text())
            commit = info.get("vcs_info", {}).get("commit_id", "")
            if commit:
                out["pipx_commit"] = commit
                if not out["pipx_url"] and info.get("url"):
                    out["pipx_url"] = f"git+{info['url']}@{commit}"
                break
except Exception:
    pass
print(json.dumps(out))
PYEOF
) || pipx_capture='{"pipx_url":"","pipx_commit":""}'
  pre_pkg_pipx_url=$(printf '%s' "$pipx_capture" | python3 -c "import json,sys; print(json.loads(sys.stdin.read()).get('pipx_url',''))" 2>/dev/null || echo "")
  pre_pkg_pipx_commit=$(printf '%s' "$pipx_capture" | python3 -c "import json,sys; print(json.loads(sys.stdin.read()).get('pipx_commit',''))" 2>/dev/null || echo "")
fi

python3 - "$SNAPSHOT_FILE" <<EOF
import json, sys
json.dump({
  "timestamp_utc": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "method": "$method",
  "package_source": "$package_source",
  "pre_pkg_version": """$pre_pkg_version""",
  "pre_pkg_git_hash": "$pre_pkg_git_hash",
  "pre_pkg_pipx_url": "$pre_pkg_pipx_url",
  "pre_pkg_pipx_commit": "$pre_pkg_pipx_commit",
  "bridge_method": "$bridge_method",
  "bridge_source_path": "$bridge_source_path",
  "pre_bridge_git_hash": "$pre_bridge_git_hash",
}, open(sys.argv[1], "w"), indent=2)
EOF

echo "→ snapshot: $SNAPSHOT_FILE"
echo "  pre-pkg-version: $(echo "$pre_pkg_version" | head -1)"
[ -n "$pre_pkg_git_hash" ] && echo "  pre-pkg-git-hash: $pre_pkg_git_hash"
[ -n "$pre_pkg_pipx_commit" ] && echo "  pre-pkg-pipx-commit: $pre_pkg_pipx_commit"
[ -n "$pre_pkg_pipx_url" ] && [ -z "$pre_pkg_pipx_commit" ] && echo "  pre-pkg-pipx-url: $pre_pkg_pipx_url"
[ -n "$pre_bridge_git_hash" ] && echo "  pre-bridge-git-hash: $pre_bridge_git_hash"

# ── Stage 0.5: install-state drift detector (s46 p3) ────────────
# Surface mismatches between declared install_method and actual on-disk
# state BEFORE running the install, so operators see the silent-corruption
# mode (config says editable, install is frozen pipx → host runs stale
# code while edits are believed to reflect). Read-only — does not mutate.
echo ""
drift_report=$(python3 - "$CFG" <<'PYEOF' 2>/dev/null
import json, pathlib, sys
try:
    from seif.context.install_state import detect_editable_drift
except Exception as e:
    print(f"SKIP {e}")
    sys.exit(0)
result = detect_editable_drift(pathlib.Path(sys.argv[1]))
print(json.dumps(result))
PYEOF
) || drift_report=""
if [ -n "$drift_report" ] && ! [[ "$drift_report" == SKIP* ]]; then
  in_drift=$(printf '%s' "$drift_report" | python3 -c "import json,sys; d=json.loads(sys.stdin.read()); print('yes' if d.get('in_drift') else 'no')" 2>/dev/null || echo "no")
  if [ "$in_drift" = "yes" ]; then
    actual=$(printf '%s' "$drift_report" | python3 -c "import json,sys; print(json.loads(sys.stdin.read()).get('actual_state',''))" 2>/dev/null)
    remed=$(printf '%s' "$drift_report" | python3 -c "import json,sys; print(json.loads(sys.stdin.read()).get('remediation',''))" 2>/dev/null)
    echo "⚠ INSTALL DRIFT: declared=$method, actual=$actual"
    echo "  the install on disk does NOT match what the config declares."
    echo "  Stage 1 below will dispatch using the declared method, which"
    echo "  may not converge if the underlying install differs."
    [ -n "$remed" ] && echo "  remediation: $remed"
  fi
elif [[ "$drift_report" == SKIP* ]]; then
  echo "→ install-state drift check skipped (helper not importable: ${drift_report#SKIP })"
fi

# ── Stage 1: package install ────────────────────────────────────
case "$method" in
  editable)
    src=$(python3 -c "import json; print(json.load(open(\"$CFG\")).get(\"source_repo\",\"\"))")
    branch=$(python3 -c "import json; print(json.load(open(\"$CFG\")).get(\"source_branch\",\"main\"))")
    [ -z "$src" ] && { echo "✗ source_repo not set"; exit 1; }
    echo "→ git pull in $src ($branch)"
    git -C "$src" checkout "$branch" 2>&1 | tail -1
    git -C "$src" pull --ff-only 2>&1 | tail -3

    # s46 p3: pipx-aware editable dispatch.
    # When pipx is the binary provider (the seif command on PATH resolves
    # into a pipx venv), bare `pip install -e $src` writes into the system
    # Python and never touches the pipx venv — the binary stays frozen at
    # whatever the venv had, while operators believe the editable install
    # is reflecting source changes. Detect and use `pipx install --editable
    # --force` instead so the venv itself becomes editable.
    pipx_manages_pkg=0
    if command -v pipx >/dev/null 2>&1; then
      if pipx list 2>&1 | grep -qE "package $pkg|/$pkg "; then
        pipx_manages_pkg=1
      fi
    fi

    if [ "$pipx_manages_pkg" = "1" ]; then
      echo "→ pipx install --editable --force $src (pipx-managed editable)"
      pipx install --editable --force "$src" 2>&1 | tail -5
      if [ -n "$extras" ]; then
        echo "→ pipx inject $pkg $extras"
        pipx inject "$pkg" $extras 2>&1 | tail -3
      fi
    else
      # s41 P1: probe for a working pip. Bare `pip` shebang may point at an
      # interpreter that was removed (observed on Mini during s40 deploy:
      # /usr/local/bin/pip → deleted /usr/local/opt/python@3.9/bin/python3.9).
      # Prefer `python3 -m pip` since it follows the working python3.
      if python3 -m pip --version >/dev/null 2>&1; then
        PIP_CMD="python3 -m pip"
      elif command -v pip >/dev/null 2>&1 && pip --version >/dev/null 2>&1; then
        PIP_CMD="pip"
      else
        echo "✗ no working pip found"
        echo "  python3 -m pip: $(python3 -m pip --version 2>&1 | head -1)"
        echo "  pip:            $(pip --version 2>&1 | head -1 || echo 'not on PATH')"
        echo "  remediation: ensure python3 is installed and pip is bootstrapped"
        echo "    (e.g. python3 -m ensurepip --upgrade)"
        exit 1
      fi
      echo "→ $PIP_CMD install -e $src"
      $PIP_CMD install -e "$src" --quiet 2>&1 | tail -3
      if [ -n "$extras" ]; then
        echo "→ $PIP_CMD install $extras"
        $PIP_CMD install $extras --quiet 2>&1 | tail -3
      fi
    fi
    ;;
  pipx)
    # s41 P2: dispatch based on package_source.
    # - 'pypi' (default): pipx upgrade — version-bump-aware reinstall
    # - 'git+<url>':       pipx install --force — git-source needs force
    #                      because pipx upgrade no-ops when pyproject version
    #                      is unchanged (observed on Air during s40 deploy).
    case "$package_source" in
      git+*)
        echo "→ pipx install --force $package_source (git source — bypasses version-equality)"
        pipx install --force "$package_source" 2>&1 | tail -5
        ;;
      pypi|"")
        if pipx list 2>&1 | grep -q "package $pkg"; then
          echo "→ pipx upgrade $pkg"
          pipx upgrade "$pkg" 2>&1 | tail -5
        else
          echo "→ pipx install $pkg"
          pipx install "$pkg" 2>&1 | tail -5
        fi
        ;;
      *)
        echo "✗ Unknown package_source: $package_source (expected 'pypi' or 'git+<url>')"
        exit 1
        ;;
    esac
    if [ -n "$extras" ]; then
      echo "→ pipx inject $pkg $extras"
      pipx inject "$pkg" $extras 2>&1 | tail -3
    fi
    ;;
  *)
    echo "✗ Unknown install_method: $method"
    exit 1
    ;;
esac

# ── Stage 1.5: template refresh (s43 B1) ────────────────────────
# After the package install succeeds, copy the canonical seif-update.sh
# that ships inside the package (src/seif/scripts/host/seif-update.sh) over
# ~/.seif/bin/seif-update.sh. Subsequent --self-update calls then carry
# canonical-template fixes forward without per-host manual ops.
#
# Best-effort + non-fatal: if the package source can't be resolved or the
# template path doesn't exist (older package without scripts shipped),
# warn and continue. The package install already succeeded — operator can
# always copy manually as a recovery path.
#
# Atomic via tmp+rename: bash already loaded this script into memory, so
# rewriting the file under us is safe (next invocation picks up new content).
echo ""
if [ "$TEMPLATE_REFRESH" = "1" ]; then
  template_src=$(python3 -c "
import sys, pathlib
try:
    import seif
    p = pathlib.Path(seif.__file__).parent / 'scripts' / 'host' / 'seif-update.sh'
    if p.is_file():
        print(p)
    else:
        sys.exit(2)
except Exception:
    sys.exit(1)
" 2>/dev/null) || template_src=""

  template_dst="$HOME/.seif/bin/seif-update.sh"

  if [ -z "$template_src" ]; then
    echo "→ template-refresh: SKIPPED (canonical template not found in installed package)"
    echo "  remediation: ensure package ships scripts/host/seif-update.sh in package_data"
  elif [ ! -f "$template_dst" ]; then
    echo "→ template-refresh: SKIPPED ($template_dst does not exist — bootstrap manually first)"
  else
    src_md5=$(md5 -q "$template_src" 2>/dev/null || md5sum "$template_src" 2>/dev/null | awk '{print $1}')
    dst_md5=$(md5 -q "$template_dst" 2>/dev/null || md5sum "$template_dst" 2>/dev/null | awk '{print $1}')
    if [ "$src_md5" = "$dst_md5" ]; then
      echo "→ template-refresh: no change (md5 ${src_md5:0:8} matches)"
    else
      tmp_dst="${template_dst}.tmp.$$"
      if cp "$template_src" "$tmp_dst" 2>/dev/null && chmod +x "$tmp_dst" 2>/dev/null && mv "$tmp_dst" "$template_dst" 2>/dev/null; then
        echo "→ template-refresh: updated ${dst_md5:0:8} → ${src_md5:0:8}"
      else
        rm -f "$tmp_dst" 2>/dev/null || true
        echo "⚠ template-refresh: FAILED to write $template_dst (non-fatal — continue)"
      fi
    fi
  fi
else
  echo "→ template-refresh: skipped (--no-template-refresh)"
fi

# ── Stage 1.6: kernel envelope verify (s44 v2 distribution) ─────
# After the package install succeeds, verify that the new RESONANCE.json
# shipped with the package carries a valid Ed25519 signature. Catches:
#   - unsigned kernel envelopes (the s44 PR #75/#76 incident: a v2 payload
#     was merged with content_signature=null; #76 re-signed before any
#     peer distribution. This stage guards the next time)
#   - signature/canonical_hash mismatches (content tampered after sign)
#   - unknown protocol versions (e.g., v3 on a v2 peer)
#
# On failure, exit non-zero with rollback guidance. Bridge sync (Stage 2)
# is gated on this passing — peer never sees a broken kernel envelope.
#
# Best-effort + skippable: if the running CLI doesn't support
# --verify-resonance (older package install), warn + continue. New installs
# always have it.
echo ""
if [ "${KERNEL_VERIFY:-1}" = "1" ]; then
  kernel_path=$(python3 -c "
import pathlib, seif
p = pathlib.Path(seif.__file__).parent / 'data' / 'RESONANCE.json'
print(p if p.is_file() else '')
" 2>/dev/null) || kernel_path=""

  if [ -z "$kernel_path" ]; then
    echo "⚠ kernel-verify: SKIPPED (RESONANCE.json not found in installed package)"
  elif ! seif --verify-resonance "$kernel_path" >/dev/null 2>&1; then
    echo "✗ kernel-verify: FAILED for $kernel_path"
    seif --verify-resonance "$kernel_path" 2>&1 | sed 's/^/    /'
    echo ""
    echo "═══ KERNEL ENVELOPE INVALID — abort distribution ══════"
    echo "  Refuse to continue: bridge sync would propagate an unsigned or"
    echo "  tampered kernel to daemons. Per A4 + A23, peer must not adopt an"
    echo "  envelope that fails Ed25519 verification."
    echo ""
    echo "  Recovery:"
    case "$method" in
      pipx)
        case "$package_source" in
          git+*)
            if [ -n "${pre_pkg_pipx_commit:-}" ]; then
              echo "    pipx install --force \"${package_source%@*}@$pre_pkg_pipx_commit\""
            else
              echo "    pipx install --force \"${package_source%@*}@<prev-known-good-ref>\""
            fi
            ;;
          *)
            prev_ver_short=$(echo "$pre_pkg_version" | awk '{print $NF}' | head -1)
            echo "    pipx install --force \"$pkg==$prev_ver_short\""
            ;;
        esac
        ;;
      editable)
        if [ -n "${pre_pkg_git_hash:-}" ]; then
          if [ "${pipx_manages_pkg:-0}" = "1" ]; then
            echo "    git -C \"$pre_src\" reset --hard $pre_pkg_git_hash && pipx install --editable --force \"$pre_src\""
          else
            echo "    git -C \"$pre_src\" reset --hard $pre_pkg_git_hash && ${PIP_CMD:-python3 -m pip} install -e \"$pre_src\""
          fi
        fi
        ;;
    esac
    echo "═══════════════════════════════════════════════════════"
    exit 1
  else
    echo "✓ kernel-verify: VALID ($(basename "$kernel_path"))"
  fi
else
  echo "→ kernel-verify: skipped (KERNEL_VERIFY=0)"
fi

# ── Stage 2: bridge repo sync (s41 P4) ──────────────────────────
# Bridge daemons (claude-responder, circuitd, peer-drainer, heartbeatd) load
# .py files directly from the repo path — without this stage, --self-update
# leaves daemons running pre-update code even when the seif package is current.
echo ""
case "$bridge_method" in
  none|"")
    echo "→ bridge:  skipped (method=none — host does not run bridge daemons)"
    ;;
  git)
    [ -z "$bridge_source_path" ] && { echo "✗ bridge_repo.source_path not set"; exit 1; }
    echo "→ bridge:  git pull in $bridge_source_path"
    [ ! -d "$bridge_source_path/.git" ] && { echo "✗ $bridge_source_path is not a git repo"; exit 1; }
    git -C "$bridge_source_path" pull --ff-only 2>&1 | tail -3
    ;;
  rsync)
    [ -z "$bridge_source_path" ] && { echo "✗ bridge_repo.source_path not set"; exit 1; }
    [ -z "$bridge_upstream" ] && { echo "✗ bridge_repo.upstream not set for rsync method"; exit 1; }
    # s43 B3: atomic-swap pattern with one-prior preserved for rollback.
    # 1. rsync into <source>.next/ (fresh sibling — never touch live <source> mid-rsync)
    # 2. if <source> exists: remove any stale <source>.prev, then mv <source> → <source>.prev
    # 3. mv <source>.next → <source>
    # On rollback (Stage 4): rm -rf <source>; mv <source>.prev → <source>.
    # Soak window: <source>.prev is reaped automatically on the NEXT successful
    # rsync update (replaced before the new prev is created), so disk stays
    # bounded at ~2× bridge size. Scheduled cleanup tracked separately
    # (see pending module: rsync-rollback-prev-soak-window).
    bridge_next="${bridge_source_path%/}.next"
    bridge_prev="${bridge_source_path%/}.prev"
    echo "→ bridge:  rsync from $bridge_upstream → $bridge_next (atomic-swap pattern)"
    rm -rf "$bridge_next"
    mkdir -p "$bridge_next"
    if rsync -avz --delete --exclude='.git/' "$bridge_upstream" "$bridge_next/" 2>&1 | tail -5; then
      # Swap atomic-ish: mv old to .prev, then mv .next to active.
      # rename(2) per file is atomic; the inter-rename window is microseconds
      # and Stage 3 daemon restart happens after, so daemons read consistent state.
      if [ -d "$bridge_source_path" ]; then
        rm -rf "$bridge_prev"
        mv "$bridge_source_path" "$bridge_prev"
      fi
      mv "$bridge_next" "$bridge_source_path"
      bridge_rsync_swap_done=1
      echo "  swap complete: prior version preserved at $bridge_prev"
    else
      # rsync failed — leave live <source> untouched, clean up the partial .next
      rm -rf "$bridge_next"
      echo "✗ rsync failed — bridge live state untouched (no swap)"
      exit 1
    fi
    ;;
  *)
    echo "✗ Unknown bridge_repo.method: $bridge_method (expected 'git', 'rsync', or 'none')"
    exit 1
    ;;
esac

# ── Stage 3: restart launchd/systemd daemons (s41 P5) ───────────
# New code on disk is invisible to running daemons until they restart. Default
# is restart-all-matching to eliminate silent staleness; --no-restart opts out
# (operator gets a summary of which jobs need attention instead).
echo ""
if [ "$RESTART" = "1" ]; then
  if command -v launchctl >/dev/null 2>&1; then
    echo "→ restart launchd jobs matching: $restart_jobs"
    matched=0
    for pattern in $restart_jobs; do
      # Convert shell glob to grep-compatible regex
      grep_pattern="^${pattern//\*/.*}$"
      while IFS=$'\t' read -r pid status job; do
        # launchctl list output: PID Status Label
        [ -z "${job:-}" ] && continue
        if [[ "$job" =~ $grep_pattern ]]; then
          echo "  kickstart: $job (was PID=$pid)"
          launchctl kickstart -k "gui/$UID/$job" 2>&1 | tail -1 || true
          matched=$((matched + 1))
        fi
      done < <(launchctl list 2>/dev/null)
    done
    echo "  restarted: $matched job(s)"
  elif command -v systemctl >/dev/null 2>&1; then
    echo "→ restart systemd --user services matching: $restart_jobs"
    matched=0
    for pattern in $restart_jobs; do
      # systemd uses '*.service' glob form
      svc_pattern="${pattern//com.seif./seif-}.service"
      systemctl --user restart "$svc_pattern" 2>&1 || true
      matched=$((matched + 1))
    done
    echo "  restarted: $matched pattern(s)"
  else
    echo "→ restart skipped: neither launchctl nor systemctl found on PATH"
  fi
else
  echo "→ restart:  skipped (--no-restart). Manual restart hint:"
  if command -v launchctl >/dev/null 2>&1; then
    for pattern in $restart_jobs; do
      grep_pattern="^${pattern//\*/.*}$"
      while IFS=$'\t' read -r pid status job; do
        [ -z "${job:-}" ] && continue
        if [[ "$job" =~ $grep_pattern ]]; then
          echo "    launchctl kickstart -k gui/\$UID/$job"
        fi
      done < <(launchctl list 2>/dev/null)
    done
  fi
fi

# ── Stage 4: post-install smoke test + rollback dispatch (s41 P6) ───
# Run the configured check. On failure, decide rollback strategy:
#   prompt mode (default, TTY): ask operator y/N before any rollback
#   prompt mode (non-TTY):      print actionable commands + exit 1, no auto-undo
#   --auto-rollback:            execute rollback without prompting (CI-friendly)
#   --no-rollback:              never rollback, just exit 1 with rollback hints
echo ""
echo "═══ POST-INSTALL CHECK ════════════════════════════════"
if eval "$check"; then
  echo "✓ update complete"
  exit 0
fi

echo ""
echo "✗ post-install check failed: $check"
echo ""
echo "═══ ROLLBACK PLAN ═════════════════════════════════════"
echo "  pre-pkg-version: $(echo "$pre_pkg_version" | head -1)"
case "$method" in
  editable)
    if [ -n "$pre_pkg_git_hash" ]; then
      echo "  pkg rollback:  git -C \"$pre_src\" reset --hard $pre_pkg_git_hash"
      if [ "${pipx_manages_pkg:-0}" = "1" ]; then
        echo "                 pipx install --editable --force \"$pre_src\""
      else
        echo "                 ${PIP_CMD:-python3 -m pip} install -e \"$pre_src\""
      fi
    else
      echo "  pkg rollback:  (editable host had no captured git hash; manual recovery)"
    fi
    ;;
  pipx)
    case "$package_source" in
      git+*)
        if [ -n "$pre_pkg_pipx_commit" ]; then
          # s43 B2: snapshot captured the resolved commit — full rollback now possible.
          echo "  pkg rollback:  pipx install --force \"${package_source%@*}@$pre_pkg_pipx_commit\""
          echo "                 (captured commit: $pre_pkg_pipx_commit)"
        elif [ -n "$pre_pkg_pipx_url" ]; then
          # Fallback: captured URL but no resolved SHA (e.g. ref like 'main')
          echo "  pkg rollback:  pipx install --force \"$pre_pkg_pipx_url\""
          echo "                 (captured URL — re-installs same ref; not pinned to commit)"
        else
          echo "  pkg rollback:  pipx-from-git rollback unavailable —"
          echo "                 pipx list --json + direct_url.json both failed to yield a ref."
          echo "                 Manual recovery: pipx install --force ${package_source%@*}@<prev-ref>"
        fi
        ;;
      *)
        prev_ver_short=$(echo "$pre_pkg_version" | awk '{print $NF}' | head -1)
        echo "  pkg rollback:  pipx install --force \"$pkg==$prev_ver_short\""
        ;;
    esac
    ;;
esac
case "$bridge_method" in
  git)
    if [ -n "$pre_bridge_git_hash" ]; then
      echo "  bridge rb:     git -C \"$bridge_source_path\" reset --hard $pre_bridge_git_hash"
    fi
    ;;
  rsync)
    if [ "$bridge_rsync_swap_done" = "1" ] && [ -d "${bridge_source_path%/}.prev" ]; then
      # s43 B3: prior version preserved via atomic-swap; full rollback possible.
      echo "  bridge rb:     rm -rf \"$bridge_source_path\" && \\"
      echo "                 mv \"${bridge_source_path%/}.prev\" \"$bridge_source_path\""
      echo "                 (prior version preserved this run at ${bridge_source_path%/}.prev)"
    else
      echo "  bridge rb:     rsync rollback unavailable —"
      echo "                 swap_done=$bridge_rsync_swap_done; .prev exists=$([ -d "${bridge_source_path%/}.prev" ] && echo yes || echo no)"
      echo "                 Manual recovery required if bridge state is corrupted."
    fi
    ;;
esac
echo "═══════════════════════════════════════════════════════"

# Decide rollback action
DECISION=""
case "$ROLLBACK_MODE" in
  none)
    echo ""
    echo "→ rollback skipped (--no-rollback)"
    exit 1
    ;;
  auto)
    echo ""
    echo "→ rollback (--auto-rollback): proceeding without prompt"
    DECISION="y"
    ;;
  prompt)
    if [ -t 0 ]; then
      echo ""
      read -rp "Roll back to the snapshot above? [y/N] " DECISION
    else
      echo ""
      echo "→ rollback skipped: stdin is not a TTY (operator decision required)"
      echo "  Re-run with --auto-rollback to proceed without prompting,"
      echo "  or run the rollback commands above manually."
      exit 1
    fi
    ;;
esac

case "${DECISION:-N}" in
  y|Y|yes|YES)
    echo ""
    echo "═══ ROLLBACK DISPATCH ═════════════════════════════════"
    rollback_failed=0

    # Bridge first (so daemons see consistent code with pre-rollback package)
    if [ "$bridge_method" = "git" ] && [ -n "$pre_bridge_git_hash" ]; then
      echo "→ bridge: git reset --hard $pre_bridge_git_hash"
      git -C "$bridge_source_path" reset --hard "$pre_bridge_git_hash" 2>&1 | tail -2 || rollback_failed=1
    elif [ "$bridge_method" = "rsync" ] && [ "$bridge_rsync_swap_done" = "1" ] && [ -d "${bridge_source_path%/}.prev" ]; then
      # s43 B3: swap back the preserved prior version
      echo "→ bridge: rsync swap-back from ${bridge_source_path%/}.prev"
      rm -rf "$bridge_source_path" 2>&1 | tail -2 || rollback_failed=1
      mv "${bridge_source_path%/}.prev" "$bridge_source_path" 2>&1 | tail -2 || rollback_failed=1
    fi

    # Package
    case "$method" in
      editable)
        if [ -n "$pre_pkg_git_hash" ]; then
          echo "→ pkg: git reset + reinstall"
          git -C "$pre_src" reset --hard "$pre_pkg_git_hash" 2>&1 | tail -2 || rollback_failed=1
          if [ "${pipx_manages_pkg:-0}" = "1" ]; then
            pipx install --editable --force "$pre_src" 2>&1 | tail -3 || rollback_failed=1
          else
            ${PIP_CMD:-python3 -m pip} install -e "$pre_src" --quiet 2>&1 | tail -3 || rollback_failed=1
          fi
        fi
        ;;
      pipx)
        case "$package_source" in
          git+*)
            # s43 B2: dispatch using the snapshot. Prefer commit_id (full rollback)
            # over package_or_url (re-install same ref — best-effort).
            if [ -n "$pre_pkg_pipx_commit" ]; then
              base_url="${package_source%@*}"
              echo "→ pkg: pipx install --force \"$base_url@$pre_pkg_pipx_commit\""
              pipx install --force "$base_url@$pre_pkg_pipx_commit" 2>&1 | tail -3 || rollback_failed=1
            elif [ -n "$pre_pkg_pipx_url" ]; then
              echo "→ pkg: pipx install --force \"$pre_pkg_pipx_url\" (best-effort, no SHA)"
              pipx install --force "$pre_pkg_pipx_url" 2>&1 | tail -3 || rollback_failed=1
            else
              echo "→ pkg: pipx-git rollback skipped (no captured ref); manual recovery"
              rollback_failed=1
            fi
            ;;
          *)
            prev_ver_short=$(echo "$pre_pkg_version" | awk '{print $NF}' | head -1)
            echo "→ pkg: pipx install --force \"$pkg==$prev_ver_short\""
            pipx install --force "$pkg==$prev_ver_short" 2>&1 | tail -3 || rollback_failed=1
            ;;
        esac
        ;;
    esac

    # Re-restart daemons so they pick up the rolled-back code
    if [ "$RESTART" = "1" ] && command -v launchctl >/dev/null 2>&1; then
      echo "→ restart daemons after rollback"
      for pattern in $restart_jobs; do
        grep_pattern="^${pattern//\*/.*}$"
        while IFS=$'\t' read -r pid _status job; do
          [ -z "${job:-}" ] && continue
          if [[ "$job" =~ $grep_pattern ]]; then
            launchctl kickstart -k "gui/$UID/$job" 2>&1 | tail -1 || true
          fi
        done < <(launchctl list 2>/dev/null)
      done
    fi

    echo ""
    if [ "$rollback_failed" = "1" ]; then
      echo "⚠ rollback completed with errors — verify state manually."
      exit 2
    fi

    # Re-run the check after rollback to confirm restored state
    echo "═══ POST-ROLLBACK CHECK ═══════════════════════════════"
    if eval "$check"; then
      echo "✓ rollback verified — host restored to pre-update state"
      exit 1   # original update failed; rollback succeeded but operator should know
    else
      echo "✗ post-rollback check ALSO failed — host state uncertain, manual recovery required"
      exit 2
    fi
    ;;
  *)
    echo ""
    echo "→ rollback declined. Host is in post-update state with failed smoke test."
    echo "  Run the rollback commands above manually if needed."
    exit 1
    ;;
esac
