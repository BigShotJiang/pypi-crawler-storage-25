# Host-level scripts

These scripts live at `~/.seif/bin/` on each host (per-host, not federated).
This directory is the **canonical template** — copy from here when bootstrapping
a new device or syncing existing ones.

## seif-update.sh

Declarative SEIF updater. Reads `~/.seif/host-install-config.seif` and
dispatches the right install command (editable / pipx / etc.) so the owner
doesn't have to remember the install method per device.

Invoked by `seif --self-update` (CLI wrapper added in s34, gap-10).

### Install on a new host

```bash
mkdir -p ~/.seif/bin
# From a fresh clone (paths relative to seif/ repo root):
cp src/seif/scripts/host/seif-update.sh ~/.seif/bin/seif-update.sh
chmod +x ~/.seif/bin/seif-update.sh
```

Plus a `~/.seif/host-install-config.seif` for that host (see
`docs/seif-cli-reference.md §41.5`).

### Why per-host AND in the package

The script must live at `~/.seif/bin/seif-update.sh` so it can run BEFORE
pipx upgrade — including on systems where the seif-cli install is broken.
But it ALSO ships in the package (under `seif/scripts/host/`) so that
`seif --self-update` can refresh `~/.seif/bin/seif-update.sh` itself from
the canonical template after each successful update — closing the
"operator must manually copy after every script change" gap (s43 B1).

## Schema v2 (s41 P2+P4+P5 trio)

`host-install-config.seif` schema bumped from `SEIF-HOST-INSTALL-CONFIG-v1`
to `SEIF-HOST-INSTALL-CONFIG-v2`. Three new optional fields, with defaults
that preserve v1 behavior (permissive — unbumped configs still work).

| Field | Default | Purpose |
|---|---|---|
| `package_source` | `"pypi"` | When `"git+<url>"`, pipx dispatch uses `install --force` (bypasses version-equality check that no-ops git-source upgrades). |
| `bridge_repo` | `{ method: "none" }` | Per-host bridge sync. Methods: `git` (`git pull --ff-only`), `rsync` (`rsync -avz` from upstream), `none` (skip). |
| `restart_jobs` | `["com.seif.*"]` | Glob patterns matched against `launchctl list` (macOS) / `systemctl --user` (Linux). Default `--restart` enabled; `--no-restart` opts out. |

See `host-install-config.sample.seif` in this directory for a fully populated
example with inline `_underscored` documentation per field.

### Migrating an existing host to v2

```bash
# 1. Refresh seif-update.sh from canonical template
#    (one-time manual; subsequent runs use Stage 1.5 self-refresh)
cp src/seif/scripts/host/seif-update.sh ~/.seif/bin/seif-update.sh
chmod +x ~/.seif/bin/seif-update.sh

# 2. Edit ~/.seif/host-install-config.seif: bump protocol + add fields
#    For an editable host (e.g. Mini), source-of-truth is local git:
#      "package_source": "pypi"  (still 'pypi' for editable — pip install -e $src is the path)
#      "bridge_repo": { "method": "git", "source_path": "/path/to/seif-resonance-bridge", "upstream": "https://..." }
#    For a pipx-from-git host (e.g. Air):
#      "package_source": "git+https://github.com/and2carvalho/seif.git@main"
#      "bridge_repo": { "method": "rsync", "source_path": "/local/bridge", "upstream": "user@mini:/path/to/bridge/" }

# 3. Dry-run to verify parsing
seif --self-update --check

# 4. Run a real update (will also restart launchd jobs unless --no-restart)
seif --self-update
```

### Operator notes

- **Bridge sync is critical.** Daemons (claude-responder, circuitd, peer-drainer, heartbeatd) load `.py` directly from `bridge_repo.source_path`. Without the bridge_repo stage, `--self-update` reports success while daemons still run pre-update code.
- **Restart default-on.** Silent staleness is exactly the s40 deploy regression class. Use `--no-restart` only if you know you'll restart manually (e.g. graceful conversation drain first).
- **Signing deferred.** Mandatory cryptographic signing of `host-install-config.seif` is a separate s42 candidate. Schema v2 is permissive — unsigned configs work, but `seif --sign-resonance` does not yet support this protocol.

## Smoke test + rollback (s41 P6)

After all install/sync/restart stages succeed, `seif-update.sh` runs the
configured `post_install_check`. If the check fails, it offers a rollback
to the pre-update snapshot rather than silently exiting non-zero.

| Flag | Behavior on smoke-test failure |
|---|---|
| (default, TTY)     | Prompts `Roll back? [y/N]`. Operator confirms before any rollback touches installed packages. |
| (default, non-TTY) | Prints rollback commands + exits 1. Never auto-undoes. Use when invoked from SSH subprocess / `seif --self-update`. |
| `--auto-rollback`  | Rolls back without prompting. CI-friendly. |
| `--no-rollback`    | Exits 1 with rollback hints, no rollback dispatched. Use when you want to inspect the failed-install state. |

### What's recoverable

- **Editable hosts:** `git -C $source_repo reset --hard <pre-hash>` + `pip install -e $source_repo`. Full rollback.
- **pipx-from-pypi hosts:** `pipx install --force <pkg>==<prev-version>`. Full rollback.
- **pipx-from-git hosts:** Best-effort. Prior commit is not captured before `pipx install --force` because the venv was destroyed. Operator must know the prior tag/commit. The error message prints the form of the recovery command.
- **Bridge git method:** `git -C $bridge_source_path reset --hard <pre-hash>`. Full rollback.
- **Bridge rsync method:** Not recoverable. The pre-update remote state was not snapshotted locally. The error message warns and skips.
- **Daemons:** Re-kickstarted after package + bridge are reverted, so they pick up the rolled-back code.

### After rollback

The post-install check runs again on the restored state:
- **Pass:** exit code 1 (original update failed but host is restored to a known-good state).
- **Fail:** exit code 2 (post-rollback check ALSO failed — host state uncertain, manual recovery required). This indicates the pre-update state was already broken; the rollback restored it but the check no longer matches expected behavior.

## rsync-soak-inspect.sh (s43 B3 soak window)

s43 B3 introduced atomic-swap rsync (PR #67) with a 3-day soak window for validation. This script inspects an rsync bridge host's state and recommends a decision.

```bash
~/.seif/bin/rsync-soak-inspect.sh
# (or directly from the package source on this branch:
#  bash src/seif/scripts/host/rsync-soak-inspect.sh)
```

What it checks:
- Leftover `<bridge>.next/` directories (should be zero — Stage 2 cleans them)
- Size + age of `<bridge>.prev/` (one expected, replaced each successful update)
- rsync rollback invocations in `~/.seif/bus_metrics.json` and daemon logs
- Sanity check that `.prev` mtime is older than live bridge mtime (correct swap order)

Exit codes:
- `0` — clean, recommend status `LANDED` (drop the soak-window pending item)
- `1` — issues found, recommend status `HARDEN` (file follow-up)
- `2` — host not configured for rsync bridge (skip)

Run on each rsync bridge host (Air-style); editable hosts (Mini) skip with exit 2.
