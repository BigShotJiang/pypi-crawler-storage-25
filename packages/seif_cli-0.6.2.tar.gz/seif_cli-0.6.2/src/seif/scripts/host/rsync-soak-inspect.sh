#!/usr/bin/env bash
# rsync-soak-inspect.sh — soak-window validation for s43 B3 atomic-swap.
#
# Run on each rsync bridge host (Air-style) after a few successful
# --self-update cycles. Inspects the .prev/.next siblings + any rollback
# signals to inform the decision_due=2026-05-04 entry in
# .seif/modules/pending-2026-05-01-post-s42-deferred.seif::rsync-rollback-prev-soak-window.
#
# Reads ~/.seif/host-install-config.seif for the bridge_repo path.
# Pure inspection: never modifies state. Print-only.
#
# Exit codes:
#   0 — clean (recommend status: LANDED)
#   1 — issues found (recommend status: HARDEN — review output before acting)
#   2 — host not configured for rsync bridge (skip)

set -euo pipefail

CFG=$HOME/.seif/host-install-config.seif
if [ ! -f "$CFG" ]; then
  echo "✗ no host-install-config.seif at $CFG"
  exit 2
fi

bridge_method=$(python3 -c "
import json
br = json.load(open('$CFG')).get('bridge_repo', {})
print(br.get('method', 'none'))
")
bridge_source_path=$(python3 -c "
import json
br = json.load(open('$CFG')).get('bridge_repo', {})
print(br.get('source_path', ''))
")
host_label=$(python3 -c "import json; print(json.load(open('$CFG')).get('host_label','unknown'))")

if [ "$bridge_method" != "rsync" ]; then
  echo "→ host=$host_label bridge_method=$bridge_method (not rsync — soak inspection N/A)"
  exit 2
fi

if [ -z "$bridge_source_path" ]; then
  echo "✗ bridge_repo.source_path empty for host=$host_label — config broken"
  exit 1
fi

next_path="${bridge_source_path%/}.next"
prev_path="${bridge_source_path%/}.prev"

echo "═══ RSYNC SOAK INSPECTION ═════════════════════════════"
echo "  host:        $host_label"
echo "  bridge:      $bridge_source_path"
echo "  prev:        $prev_path"
echo "  next:        $next_path"
echo "═══════════════════════════════════════════════════════"

issues=0

# (1) Leftover .next/ — should never exist between updates
if [ -e "$next_path" ]; then
  echo ""
  echo "⚠ ISSUE: $next_path exists between updates"
  echo "  Stage 2 should rm -rf .next at start AND after successful swap."
  echo "  Possible causes: interrupted update, signal kill mid-swap."
  if [ -d "$next_path" ]; then
    echo "  size:    $(du -sh "$next_path" 2>/dev/null | awk '{print $1}')"
    echo "  mtime:   $(stat -f '%Sm' -t '%Y-%m-%dT%H:%M:%S' "$next_path" 2>/dev/null || stat -c '%y' "$next_path" 2>/dev/null | cut -d. -f1)"
  fi
  issues=$((issues + 1))
else
  echo ""
  echo "✓ .next: absent (expected between updates)"
fi

# (2) .prev/ — exactly one expected, replaced each successful update
if [ -d "$prev_path" ]; then
  prev_size=$(du -sh "$prev_path" 2>/dev/null | awk '{print $1}')
  prev_mtime=$(stat -f '%Sm' -t '%Y-%m-%dT%H:%M:%S' "$prev_path" 2>/dev/null || stat -c '%y' "$prev_path" 2>/dev/null | cut -d. -f1)
  prev_age_days=$(python3 -c "
import os, time
try:
    age_s = time.time() - os.path.getmtime('$prev_path')
    print(f'{age_s/86400:.1f}')
except Exception:
    print('?')
")
  echo ""
  echo "✓ .prev: present (expected after at least one update)"
  echo "  size:    $prev_size"
  echo "  mtime:   $prev_mtime ($prev_age_days days ago)"
  # Sanity check: live bridge should be newer than .prev (swap order)
  if [ -d "$bridge_source_path" ]; then
    live_mtime_epoch=$(stat -f '%m' "$bridge_source_path" 2>/dev/null || stat -c '%Y' "$bridge_source_path" 2>/dev/null)
    prev_mtime_epoch=$(stat -f '%m' "$prev_path" 2>/dev/null || stat -c '%Y' "$prev_path" 2>/dev/null)
    if [ -n "$live_mtime_epoch" ] && [ -n "$prev_mtime_epoch" ] && [ "$prev_mtime_epoch" -gt "$live_mtime_epoch" ]; then
      echo ""
      echo "⚠ ISSUE: .prev mtime is NEWER than live bridge — swap order may be broken"
      issues=$((issues + 1))
    fi
  fi
else
  echo ""
  echo "○ .prev: absent (no rsync update has run yet, OR host hasn't synced since B3 deployed)"
  echo "  Not an issue — just a signal that the soak window had no rsync cycles to validate."
fi

# (3) rsync rollback invocations — best-effort signal scrape
echo ""
echo "── rollback signals ───"
bus_metrics_path="${HOME}/.seif/bus_metrics.json"
rollback_count=0
if [ -f "$bus_metrics_path" ]; then
  rollback_count=$(python3 -c "
import json
try:
    m = json.load(open('$bus_metrics_path'))
    # Counters live under various nested keys depending on bridge version.
    n = 0
    for k, v in (m.items() if isinstance(m, dict) else []):
        kl = k.lower()
        if 'rollback' in kl and ('rsync' in kl or 'bridge' in kl):
            try: n += int(v) if not isinstance(v, dict) else sum(int(x) for x in v.values() if isinstance(x,(int,str)) and str(x).isdigit())
            except Exception: pass
    print(n)
except Exception:
    print(0)
" 2>/dev/null || echo 0)
  echo "  bus_metrics.json: $rollback_count rsync-related rollback counter hits"
else
  echo "  bus_metrics.json: not present (file: $bus_metrics_path)"
fi

# Daemon log scan — best effort
log_hits=0
for log_dir in "$HOME/.seif/logs" "/tmp/seif-resonance-bridge-logs"; do
  if [ -d "$log_dir" ]; then
    n=$(grep -lE "rsync.*rollback|rollback.*rsync" "$log_dir"/*.log 2>/dev/null | wc -l | tr -d ' ')
    if [ "$n" -gt 0 ]; then
      log_hits=$((log_hits + n))
      echo "  $log_dir: $n log file(s) mention rsync rollback"
    fi
  fi
done
[ "$log_hits" = "0" ] && echo "  daemon logs: no rsync rollback mentions found"

# (4) Summary + decision recommendation
echo ""
echo "═══ DECISION RECOMMENDATION ═══════════════════════════"
total_signals=$((issues + rollback_count + log_hits))
if [ "$issues" = "0" ] && [ "$rollback_count" = "0" ] && [ "$log_hits" = "0" ]; then
  echo "  ✓ CLEAN — recommend status: LANDED"
  echo "    Update pending module: rsync-rollback-prev-soak-window → status: LANDED"
  echo "    No rsync rollbacks fired during soak window; .prev/.next siblings clean."
  exit 0
elif [ "$issues" -gt "0" ]; then
  echo "  ⚠ ISSUES FOUND — recommend status: HARDEN"
  echo "    $issues structural issue(s) above. Review output, file follow-up cycle."
  exit 1
else
  echo "  [!] ROLLBACKS OBSERVED — recommend status: VALIDATED"
  echo "    rsync rollback fired $((rollback_count + log_hits)) time(s) during soak."
  echo "    The mechanism is exercised, not dormant. Inspect outcomes before LANDED."
  exit 1
fi
