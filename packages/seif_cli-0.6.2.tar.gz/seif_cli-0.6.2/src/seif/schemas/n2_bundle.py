"""SEIF-N2-BUNDLE-v1 schema definitions and minimal validator.

s60 PR5 (rank 3) — owner-decided per SEED-s60 q3=aggregate weekly bundles.
N2 = nucleus-of-nucleus signing tier. A weekly bundle aggregates SEALED
cycles + seeds for one ISO week and carries one Ed25519 signature plus
optional OTS sibling proof — proof-of-author over the bundle, not over
each individual artifact.

This module is intentionally minimal: a `validate_bundle()` predicate that
checks shape (no jsonschema dep). Heavy lifting lives in
``seif.core.n2_bundle``.
"""

from __future__ import annotations

from typing import Any, Iterable

N2_BUNDLE_PROTOCOL = "SEIF-N2-BUNDLE-v1"

REQUIRED_TOP_LEVEL = (
    "protocol",
    "bundle_id",
    "iso_week",
    "issued_at",
    "issued_by",
    "kernel_anchor",
    "cycles",
    "seeds",
)

REQUIRED_ISO_WEEK_FIELDS = ("year", "week", "starts_at", "ends_at")

REQUIRED_KERNEL_ANCHOR_FIELDS = ("canonical_hash", "key_fingerprint")

REQUIRED_CYCLE_ENTRY_FIELDS = (
    "slug",
    "cycle_id",
    "sealed_at",
    "sealed_path",
    "sha256",
    "re_seal_history_length",
    "ots_present",
)

REQUIRED_SEED_ENTRY_FIELDS = (
    "seed_id",
    "issued_at",
    "path",
    "sha256",
    "ots_present",
)


def _is_str(v: Any) -> bool:
    return isinstance(v, str) and bool(v)


def _missing(d: dict, fields: Iterable[str]) -> list[str]:
    return [f for f in fields if f not in d]


def validate_bundle(doc: Any) -> tuple[bool, str]:
    """Return (ok, reason). Shape-only — does NOT verify signature/hash."""
    if not isinstance(doc, dict):
        return False, f"bundle must be a JSON object, got {type(doc).__name__}"
    if doc.get("protocol") != N2_BUNDLE_PROTOCOL:
        return False, f"protocol must be {N2_BUNDLE_PROTOCOL!r}; got {doc.get('protocol')!r}"

    miss = _missing(doc, REQUIRED_TOP_LEVEL)
    if miss:
        return False, f"missing top-level fields: {miss}"

    iso = doc["iso_week"]
    if not isinstance(iso, dict):
        return False, "iso_week must be an object"
    miss = _missing(iso, REQUIRED_ISO_WEEK_FIELDS)
    if miss:
        return False, f"iso_week missing fields: {miss}"

    ka = doc["kernel_anchor"]
    if not isinstance(ka, dict):
        return False, "kernel_anchor must be an object"
    miss = _missing(ka, REQUIRED_KERNEL_ANCHOR_FIELDS)
    if miss:
        return False, f"kernel_anchor missing fields: {miss}"

    if not isinstance(doc["cycles"], list):
        return False, "cycles must be a list"
    for i, c in enumerate(doc["cycles"]):
        if not isinstance(c, dict):
            return False, f"cycles[{i}] must be an object"
        miss = _missing(c, REQUIRED_CYCLE_ENTRY_FIELDS)
        if miss:
            return False, f"cycles[{i}] missing fields: {miss}"

    if not isinstance(doc["seeds"], list):
        return False, "seeds must be a list"
    for i, s in enumerate(doc["seeds"]):
        if not isinstance(s, dict):
            return False, f"seeds[{i}] must be an object"
        miss = _missing(s, REQUIRED_SEED_ENTRY_FIELDS)
        if miss:
            return False, f"seeds[{i}] missing fields: {miss}"

    return True, "ok"
