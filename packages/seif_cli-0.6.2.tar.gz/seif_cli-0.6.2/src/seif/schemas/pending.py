"""SEIF-PENDING schema definitions and version-compat helpers.

gap-14 Piece A — additive v2 with read-back-compat. Owner-decided at
s51 (Q1=v2 aditivo, Q2=opt-in --consume-pendings, Q3=defer cross-host
to gap-14b).

v1: stored_in_workspace + workspace_relative_path + target_consumer
    + target_workspace fields are OPTIONAL (added at s49 retroactively
    on canonical pendings).

v2: same fields are MANDATORY. Routing fields enable cross-workspace
    discovery without owner-relay. Absolute paths forbidden in v2;
    runtime resolution joins registry workspace root with
    workspace_relative_path.
"""

from __future__ import annotations

from typing import Any

PENDING_V1 = "SEIF-PENDING-v1"
PENDING_V2 = "SEIF-PENDING-v2"

PENDING_ACCEPTED_PROTOCOLS = frozenset({PENDING_V1, PENDING_V2})

V2_REQUIRED_ROUTING_FIELDS = (
    "discovered_in_workspace",
    "target_workspace",
    "target_consumer",
    "stored_in_workspace",
    "workspace_relative_path",
)

V2_VALID_TARGET_CONSUMERS = frozenset({"owner", "next_cycle", "vigilant"})


def is_pending_module(data: Any) -> bool:
    """True iff `data` is a parsed pending module of any accepted version."""
    return (
        isinstance(data, dict)
        and data.get("protocol") in PENDING_ACCEPTED_PROTOCOLS
    )


def migrate_pending_v1_to_v2(
    data: dict,
    *,
    cwd_workspace: str,
) -> dict:
    """Upgrade a v1 dict to v2 in place semantics (returns new dict).

    Defaults missing routing fields to single-workspace pattern:
    discovered_in == target == stored_in == cwd_workspace. Absolute
    paths in `workspace_relative_path` are rejected (v2 invariant).
    """
    if data.get("protocol") == PENDING_V2:
        return dict(data)
    if data.get("protocol") != PENDING_V1:
        raise ValueError(
            f"migrate: expected {PENDING_V1}, got {data.get('protocol')!r}"
        )

    out = dict(data)
    out["protocol"] = PENDING_V2
    out.setdefault("discovered_in_workspace", cwd_workspace)
    out.setdefault("target_workspace", out["discovered_in_workspace"])
    out.setdefault("stored_in_workspace", out["discovered_in_workspace"])
    out.setdefault("target_consumer", "next_cycle")

    rel = out.get("workspace_relative_path", "")
    if rel.startswith("/"):
        raise ValueError(
            f"v2 forbids absolute paths in workspace_relative_path: {rel!r}"
        )

    return out
