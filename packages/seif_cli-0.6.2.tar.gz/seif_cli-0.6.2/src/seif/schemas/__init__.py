"""SEIF schema constants and validators.

Centralizes protocol identifier strings, schema-version compatibility
maps, and migration helpers so consumers (loaders, validators, CLI)
do not duplicate hardcoded protocol strings.
"""

from seif.schemas.pending import (
    PENDING_V1,
    PENDING_V2,
    PENDING_ACCEPTED_PROTOCOLS,
    is_pending_module,
    migrate_pending_v1_to_v2,
)
from seif.schemas.n2_bundle import (
    N2_BUNDLE_PROTOCOL,
    validate_bundle as validate_n2_bundle,
)

__all__ = [
    "PENDING_V1",
    "PENDING_V2",
    "PENDING_ACCEPTED_PROTOCOLS",
    "is_pending_module",
    "migrate_pending_v1_to_v2",
    "N2_BUNDLE_PROTOCOL",
    "validate_n2_bundle",
]
