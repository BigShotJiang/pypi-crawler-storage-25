"""SEIF Lite scaffolding (`seif --init --lite`).

Writes a minimal, provenance-aware folder layout for non-code-first
collaboration: README, AGENTS, .seif-lite/{BOOT,refs}, session-log,
decisions-pending. No `.seif/` kernel, no signing, no `RESONANCE.json`.

Spec: `seif-product/30-technical/08-init-lite-implementation-draft.md`
ADR-006 (ACCEPTED 2026-05-09).
"""

from __future__ import annotations

from datetime import date
from importlib import resources
from pathlib import Path


LITE_FILES: dict[str, str] = {
    "README.md": "README.md",
    "AGENTS.md": "AGENTS.md",
    "BOOT.md": ".seif-lite/BOOT.md",
    "refs.md": ".seif-lite/refs.md",
    "session_log.md": "session-log.md",
    "decisions_pending.md": "decisions-pending.md",
}


def run_init_lite(
    target: Path,
    *,
    project_title: str,
    init_date: str | None = None,
    force: bool = False,
    with_agents: bool = True,
) -> list[Path]:
    """Scaffold a SEIF Lite layout under ``target``.

    Returns the list of files created (existing files are skipped unless
    ``force`` is set, and re-emitted files are listed). Raises if the
    target already contains a full ``.seif/`` workspace, since Lite is not
    meant to live alongside the full kernel.
    """
    target = Path(target).resolve()
    target.mkdir(parents=True, exist_ok=True)
    init_date = init_date or date.today().isoformat()
    created: list[Path] = []
    pkg = resources.files("seif.data.init_lite")

    if (target / ".seif").exists() and not force:
        raise RuntimeError(
            "Directory already contains .seif/ — refusing --init --lite. "
            "Use full `seif --init` or remove/rename `.seif` (human decision)."
        )

    (target / ".seif-lite").mkdir(parents=True, exist_ok=True)

    for pkg_name, rel in LITE_FILES.items():
        if pkg_name == "AGENTS.md" and not with_agents:
            continue
        dest = target / rel
        text = (pkg / pkg_name).read_text(encoding="utf-8")
        text = text.replace("{{PROJECT_TITLE}}", project_title)
        text = text.replace("{{INIT_DATE}}", init_date)
        if dest.exists() and not force:
            continue
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(text, encoding="utf-8")
        created.append(dest)

    return created
