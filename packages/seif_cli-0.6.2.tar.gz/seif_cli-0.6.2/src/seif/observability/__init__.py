"""seif.observability — runtime metrics for kernel-axiom enforcement.

Currently exposes:
  - bus_metrics: A23 verifiable_provenance counter + alert (s40 P5)
"""
