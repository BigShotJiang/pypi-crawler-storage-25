"""A23 bus-metrics counter (s40 P5).

A23 verifiable_provenance was promoted to kernel + Ed25519-signed in s39.
P1/P2/P3 carry the envelope through producer → transport → consumer.
P5 is observability: an explicit counter at the consumer boundary so an
operator can see whether headless invocations are dominating bus traffic
(which contradicts A23's intent — every artifact should declare provenance,
and `context_loaded=false` traffic should be the exception, not the norm).

Persistence: `.seif/metrics/a23.json` written via cas_write_json (CAS to
survive concurrent writers — bridge daemon and session-start hook may
both increment in parallel). Events older than the rolling window are
trimmed on each write to keep the file bounded.

Alert rule: ratio of `context_loaded=false` events to total events over
the rolling window exceeds the threshold. Owner-confirmed default at
s40 session-start gate: 20% over 24h.

Surface:
  - record_bus_message(payload, source_kind, *, metrics_dir=None) — increment
  - read_metrics(metrics_dir=None) → dict — load current state
  - compute_a23_alert(metrics, *, threshold=0.20, window_hours=24) — alert state
  - format_status_block(metrics_dir=None) → str | None — block for `seif --status`

Consumer wiring lives outside this module (circuit_monitor.py for seif's
inbox poller; seif-claude-responder for the bridge). This module is pure:
no global state, no imports from consumers, fully unit-testable.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

try:
    from seif.context.seif_io import cas_write_json
except ImportError:  # pragma: no cover — standalone import path
    cas_write_json = None  # type: ignore[assignment]


SCHEMA = "A23-METRICS-v1"
DEFAULT_WINDOW_HOURS = 24
DEFAULT_THRESHOLD = 0.20  # owner decision (s40 session-start gate)
DEFAULT_METRICS_REL = ".seif/metrics/a23.json"
EVENT_CAP = 5000  # hard upper bound — protects against pathological growth


# ── Source-kind classification (mirror of bridge's provenance.classify_source) ─

DEFAULT_INTERNAL_LABELS: frozenset[str] = frozenset({"mini-m4", "air-m1"})


def classify_source_kind(
    payload: Any,
    *,
    internal_node_labels: frozenset[str] | set[str] | None = None,
) -> str:
    """Match the bridge-side classifier so labels are consistent across consumers.

    Internal: issued_by.node, `from`, or `sender` matches a known internal label.
    External: anything else (or non-dict payload).
    """
    if not isinstance(payload, dict):
        return "external"
    internal = internal_node_labels or DEFAULT_INTERNAL_LABELS
    issued_by = payload.get("issued_by")
    candidates: list[str] = []
    if isinstance(issued_by, dict):
        node = issued_by.get("node")
        if isinstance(node, str):
            candidates.append(node)
    for k in ("from", "sender"):
        v = payload.get(k)
        if isinstance(v, str):
            candidates.append(v)
    for c in candidates:
        if c in internal:
            return "internal"
    return "external"


def extract_context_loaded(payload: Any) -> bool | None:
    """Read issued_by.context_loaded if present and bool-typed.

    Returns True/False from the envelope, or None if absent/malformed (in
    which case the caller must decide how to label — record_bus_message
    treats None as False because the producer didn't declare).
    """
    if not isinstance(payload, dict):
        return None
    issued_by = payload.get("issued_by")
    if not isinstance(issued_by, dict):
        return None
    v = issued_by.get("context_loaded")
    return v if isinstance(v, bool) else None


# ── Persistence ────────────────────────────────────────────────────────────

def _now_utc() -> datetime:
    return datetime.now(timezone.utc)


def _resolve_metrics_path(metrics_dir: Path | None) -> Path:
    if metrics_dir is None:
        return Path.cwd() / DEFAULT_METRICS_REL
    p = Path(metrics_dir)
    if p.suffix == ".json":
        return p
    return p / "a23.json"


def _empty_metrics() -> dict:
    return {
        "schema": SCHEMA,
        "events": [],
        "counters": {
            "total": 0,
            "by_source": {"internal": 0, "external": 0},
            "by_context_loaded": {"true": 0, "false": 0},
        },
    }


def _trim_events(events: list[dict], *, window_hours: int) -> list[dict]:
    """Drop events older than the window, capped at EVENT_CAP entries."""
    cutoff = _now_utc() - timedelta(hours=window_hours)
    cutoff_iso = cutoff.isoformat()
    fresh = [e for e in events if isinstance(e.get("ts"), str) and e["ts"] >= cutoff_iso]
    if len(fresh) > EVENT_CAP:
        fresh = fresh[-EVENT_CAP:]
    return fresh


def _recompute_counters(events: list[dict]) -> dict:
    counters = {
        "total": len(events),
        "by_source": {"internal": 0, "external": 0},
        "by_context_loaded": {"true": 0, "false": 0},
    }
    for e in events:
        src = e.get("source")
        if src in counters["by_source"]:
            counters["by_source"][src] += 1
        ctx = e.get("context_loaded")
        if ctx is True:
            counters["by_context_loaded"]["true"] += 1
        elif ctx is False:
            counters["by_context_loaded"]["false"] += 1
    return counters


def read_metrics(metrics_dir: Path | None = None) -> dict:
    """Load current metrics (or return an empty skeleton if absent/corrupt)."""
    p = _resolve_metrics_path(metrics_dir)
    if not p.is_file():
        return _empty_metrics()
    try:
        d = json.loads(p.read_text())
    except Exception:
        return _empty_metrics()
    if not isinstance(d, dict) or d.get("schema") != SCHEMA:
        return _empty_metrics()
    if not isinstance(d.get("events"), list):
        d["events"] = []
    if not isinstance(d.get("counters"), dict):
        d["counters"] = _recompute_counters(d["events"])
    return d


def _atomic_or_simple_write(path: Path, data: dict) -> None:
    """Write metrics atomically. Prefer cas_write_json when available so
    concurrent writers (bridge daemon + session-start hook) can't corrupt
    the file. Falls back to tmp+rename when cas helper is unavailable
    (e.g. the seif package is not on the importer's path)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    if cas_write_json is not None:
        try:
            cas_write_json(path, data)
            return
        except Exception:
            pass
    tmp = path.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(data, indent=2))
    tmp.replace(path)


def record_bus_message(
    payload: Any,
    *,
    source_kind: str | None = None,
    metrics_dir: Path | None = None,
    window_hours: int = DEFAULT_WINDOW_HOURS,
    now: datetime | None = None,
) -> dict:
    """Increment the A23 counter for one bus message processed.

    Returns the updated metrics dict. `now` is for tests; default = utcnow.
    `source_kind` overrides classification when the caller already classified
    (bridge consumer pre-classifies via provenance.classify_source).
    """
    payload_dict = payload if isinstance(payload, dict) else {}
    if source_kind is None:
        source_kind = classify_source_kind(payload_dict)
    if source_kind not in ("internal", "external"):
        source_kind = "external"  # safety
    ctx_loaded = extract_context_loaded(payload_dict)
    # Producer-declared bool stays bool; absent/malformed → False (the producer
    # didn't declare, which is exactly the regression A23 is meant to catch).
    ctx_label = bool(ctx_loaded) if ctx_loaded is not None else False

    p = _resolve_metrics_path(metrics_dir)
    metrics = read_metrics(metrics_dir)
    ts = (now or _now_utc()).isoformat()
    metrics["events"].append({
        "ts": ts,
        "source": source_kind,
        "context_loaded": ctx_label,
    })
    metrics["events"] = _trim_events(metrics["events"], window_hours=window_hours)
    metrics["counters"] = _recompute_counters(metrics["events"])
    _atomic_or_simple_write(p, metrics)
    return metrics


# ── Alert / surface ────────────────────────────────────────────────────────

@dataclass(frozen=True)
class A23Alert:
    """Computed alert state for a metrics snapshot."""
    threshold: float
    window_hours: int
    total: int
    headless: int
    ratio: float
    breached: bool
    by_source: dict[str, int]


def compute_a23_alert(
    metrics: dict,
    *,
    threshold: float = DEFAULT_THRESHOLD,
    window_hours: int = DEFAULT_WINDOW_HOURS,
    now: datetime | None = None,
) -> A23Alert:
    """Compute the headless-ratio alert for a metrics snapshot."""
    cutoff = (now or _now_utc()) - timedelta(hours=window_hours)
    cutoff_iso = cutoff.isoformat()
    events = metrics.get("events", []) if isinstance(metrics, dict) else []
    in_window = [e for e in events if isinstance(e.get("ts"), str) and e["ts"] >= cutoff_iso]
    total = len(in_window)
    headless = sum(1 for e in in_window if e.get("context_loaded") is False)
    ratio = (headless / total) if total > 0 else 0.0
    breached = total > 0 and ratio > threshold
    by_source: dict[str, int] = {"internal": 0, "external": 0}
    for e in in_window:
        s = e.get("source")
        if s in by_source:
            by_source[s] += 1
    return A23Alert(
        threshold=threshold,
        window_hours=window_hours,
        total=total,
        headless=headless,
        ratio=ratio,
        breached=breached,
        by_source=by_source,
    )


def format_status_block(
    metrics_dir: Path | None = None,
    *,
    threshold: float = DEFAULT_THRESHOLD,
    window_hours: int = DEFAULT_WINDOW_HOURS,
) -> str | None:
    """Format an A23 metric block for `seif --status`. Returns None if no
    events have been recorded — keeps the status output clean before the
    counter is seeded."""
    metrics = read_metrics(metrics_dir)
    alert = compute_a23_alert(
        metrics, threshold=threshold, window_hours=window_hours
    )
    if alert.total == 0:
        return None
    lines = [
        f"  A23 bus traffic ({window_hours}h):",
        f"    Total:        {alert.total}",
        f"    By source:    internal={alert.by_source['internal']} "
        f"external={alert.by_source['external']}",
        f"    Headless ratio: {alert.ratio:.1%} "
        f"(threshold {threshold:.0%})",
    ]
    if alert.breached:
        lines.append(
            f"    ⚠ A23 ALERT: headless ratio {alert.ratio:.1%} > "
            f"{threshold:.0%} — declarative provenance is being bypassed"
        )
    return "\n".join(lines)
