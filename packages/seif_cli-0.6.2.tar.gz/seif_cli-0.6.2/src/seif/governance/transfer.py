"""
A22 workspace_transfer — Owner-present, intentional ownership handoff.

Distinct from A19 succession (Owner unreachable). The current Owner signs a
TransferRecord with their Ed25519 key. Five properties (per kernel A22 + S14i
observation 2026-04-02):

  1. Explicit intent — the act is signed, not inferred from abandonment
  2. Identified recipient — a specific new Owner pubkey, not a procedure
  3. Immediate execution permitted — no cooling period (M&A closing semantics)
  4. Forward security — old key retains VERIFY authority for historical modules,
     loses SIGN authority for new ones from t_transfer forward
  5. Provenance preserved — history intact; the chain itself proves authority change

This module provides the data structure and crypto primitives only.
CLI surface (`seif --transfer`), chain walker, and the SEIF-MODULE wrapper
ship in steps 5-7 of the S37 plan.
"""

from __future__ import annotations

import base64
import hashlib
import json
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Union


CANONICAL_FIELDS = ("transfer_to", "scope", "date", "reason", "signed_by")
MODULE_PROTOCOL = "SEIF-MODULE-v2"
MODULE_CATEGORY = "transfer"


@dataclass(frozen=True)
class TransferRecord:
    """Owner-signed handoff of a workspace from one Ed25519 identity to another.

    Fields mirror the kernel A22 schema; `signature` is populated by `sign()`
    and verified by `verify()`. All public-key fields are base64-encoded raw
    32-byte Ed25519 public keys.
    """
    transfer_to: str       # new owner public key (base64, raw 32B)
    scope: str             # workspace_id (canonical name or pubkey fingerprint)
    date: str              # ISO 8601 UTC timestamp at signing
    reason: str            # human-readable reason (M&A, donation, etc.)
    signed_by: str         # previous owner public key (base64, raw 32B)
    signature: str = ""    # base64 Ed25519 signature over canonical payload

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "TransferRecord":
        return cls(
            transfer_to=d["transfer_to"],
            scope=d["scope"],
            date=d["date"],
            reason=d["reason"],
            signed_by=d["signed_by"],
            signature=d.get("signature", ""),
        )


def _canonical_payload(record: Union[TransferRecord, dict]) -> bytes:
    """Canonical JSON of the signed fields (sorted, no whitespace)."""
    if isinstance(record, TransferRecord):
        d = record.to_dict()
    else:
        d = record
    payload = {k: d[k] for k in CANONICAL_FIELDS}
    return json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")


def _b64_to_raw_pubkey(b64: str) -> bytes:
    raw = base64.b64decode(b64)
    if len(raw) != 32:
        raise ValueError(
            f"Ed25519 public key must be 32 raw bytes; got {len(raw)} after base64 decode"
        )
    return raw


def sign(
    prev_owner_priv_key,
    transfer_to: str,
    scope: str,
    reason: str,
    date: str | None = None,
) -> TransferRecord:
    """Produce a signed TransferRecord.

    Args:
        prev_owner_priv_key: Ed25519PrivateKey instance (already loaded; we never
            handle PEM bytes or filesystem paths here — A12 token_provenance places
            key-loading at the CLI boundary).
        transfer_to: new owner public key, base64-encoded raw 32 bytes.
        scope: workspace identifier.
        reason: free-text explanation.
        date: ISO 8601 UTC timestamp; defaults to now() if omitted.

    Returns:
        TransferRecord with signature populated.
    """
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives import serialization

    if not isinstance(prev_owner_priv_key, Ed25519PrivateKey):
        raise TypeError("prev_owner_priv_key must be Ed25519PrivateKey")

    # Validate transfer_to is a well-formed Ed25519 public key
    _b64_to_raw_pubkey(transfer_to)

    # Derive signed_by from the private key (binds signature to its owner)
    pub = prev_owner_priv_key.public_key()
    pub_raw = pub.public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    signed_by = base64.b64encode(pub_raw).decode("ascii")

    if date is None:
        date = datetime.now(timezone.utc).isoformat()

    unsigned = TransferRecord(
        transfer_to=transfer_to,
        scope=scope,
        date=date,
        reason=reason,
        signed_by=signed_by,
        signature="",
    )

    sig_bytes = prev_owner_priv_key.sign(_canonical_payload(unsigned))
    signature = base64.b64encode(sig_bytes).decode("ascii")

    return TransferRecord(
        transfer_to=transfer_to,
        scope=scope,
        date=date,
        reason=reason,
        signed_by=signed_by,
        signature=signature,
    )


def verify(
    record: Union[TransferRecord, dict],
    expected_prev_owner_pubkey: str | None = None,
) -> dict:
    """Verify a TransferRecord signature.

    Args:
        record: TransferRecord or its dict form.
        expected_prev_owner_pubkey: if given, the record's signed_by must match
            this base64 key (chain-walker uses this to bind link N to link N-1's
            transfer_to). When None, signature is verified against the embedded
            signed_by pubkey only — useful for standalone verification.

    Returns:
        {"valid": bool, "reason": str}.
    """
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    from cryptography.exceptions import InvalidSignature

    if isinstance(record, TransferRecord):
        d = record.to_dict()
    else:
        d = dict(record)

    sig_b64 = d.get("signature", "")
    if not sig_b64:
        return {"valid": False, "reason": "missing signature"}

    signed_by = d.get("signed_by", "")
    if not signed_by:
        return {"valid": False, "reason": "missing signed_by"}

    if expected_prev_owner_pubkey is not None and signed_by != expected_prev_owner_pubkey:
        return {
            "valid": False,
            "reason": (
                "signed_by does not match expected previous owner "
                f"(record claims {signed_by[:16]}…, chain expects "
                f"{expected_prev_owner_pubkey[:16]}…)"
            ),
        }

    try:
        pub_raw = _b64_to_raw_pubkey(signed_by)
        public_key = Ed25519PublicKey.from_public_bytes(pub_raw)
        sig_bytes = base64.b64decode(sig_b64)
        public_key.verify(sig_bytes, _canonical_payload(d))
    except InvalidSignature:
        return {"valid": False, "reason": "INVALID — signature does not match canonical payload"}
    except ValueError as e:
        return {"valid": False, "reason": f"key error: {e}"}
    except Exception as e:
        return {"valid": False, "reason": f"verification error: {e}"}

    return {"valid": True, "reason": "signature valid"}


def _short_fp(pub_b64: str) -> str:
    """SHA-256[:16] fingerprint of a base64 raw Ed25519 public key (matches signing.py style)."""
    try:
        raw = base64.b64decode(pub_b64)
    except Exception:
        return ""
    return hashlib.sha256(raw).hexdigest()[:16]


def serialize_to_seif_module(record: TransferRecord, output_path: Union[str, Path]) -> dict:
    """Wrap a signed TransferRecord as a SEIF-MODULE-v2 and write it to disk.

    The wrapper carries the canonical SEIF module fields (protocol, category,
    summary, classification, contributors, integrity_hash, etc.) plus a
    `transfer_record` field holding the signed payload itself. Chain walkers
    read `transfer_record` from each module on disk.

    Returns the module dict that was written.
    """
    output_path = Path(output_path)

    record_dict = record.to_dict()
    summary = (
        f"A22 workspace_transfer\n\n"
        f"- Scope: {record.scope}\n"
        f"- From: {_short_fp(record.signed_by)} ({record.signed_by[:24]}…)\n"
        f"- To:   {_short_fp(record.transfer_to)} ({record.transfer_to[:24]}…)\n"
        f"- Date: {record.date}\n"
        f"- Reason: {record.reason}"
    )

    integrity_payload = json.dumps(
        record_dict, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")
    integrity_hash = hashlib.sha256(integrity_payload).hexdigest()[:24]

    module = {
        "protocol": MODULE_PROTOCOL,
        "source": "governance/transfer",
        "category": MODULE_CATEGORY,
        "summary": summary,
        "verified_data": [
            "Owner-signed Ed25519 transfer record (A22)",
            f"signed_by fingerprint: {_short_fp(record.signed_by)}",
            f"transfer_to fingerprint: {_short_fp(record.transfer_to)}",
            f"scope: {record.scope}",
        ],
        "transfer_record": record_dict,
        "integrity_hash": integrity_hash,
        "active": True,
        "version": 1,
        "classification": "INTERNAL",
        "contributors": [
            {
                "author": _short_fp(record.signed_by),
                "at": record.date,
                "via": "cli",
                "action": "signed-transfer",
            }
        ],
        "parent_hash": None,
        "updated_at": record.date,
    }

    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w") as f:
        json.dump(module, f, indent=2, ensure_ascii=False)

    return module


def _load_transfer_modules(transfers_dir: Path, scope: str) -> list[tuple[Path, dict, dict]]:
    """Read all transfer .seif modules in `transfers_dir` matching `scope`.

    Returns list of (path, module_dict, transfer_record_dict).
    Skips files that don't parse as JSON or aren't transfer modules; callers
    that need strict scanning should validate the directory upstream.
    """
    out = []
    if not transfers_dir.exists():
        return out
    for p in sorted(transfers_dir.rglob("*.seif")):
        try:
            with open(p) as f:
                module = json.load(f)
        except (json.JSONDecodeError, OSError):
            continue
        if module.get("protocol") != MODULE_PROTOCOL:
            continue
        if module.get("category") != MODULE_CATEGORY:
            continue
        record = module.get("transfer_record")
        if not isinstance(record, dict):
            continue
        if record.get("scope") != scope:
            continue
        out.append((p, module, record))
    return out


def verify_transfer_chain(
    workspace_id: str,
    transfers_dir: Union[str, Path],
    genesis_pubkey: str | None = None,
) -> dict:
    """Walk the transfer chain for `workspace_id` and verify every link.

    Validation rules per link N:
      (a) signature valid against the embedded signed_by pubkey
      (b) signed_by == previous link's transfer_to (or genesis_pubkey for N=0)
      (c) scope unchanged across the chain
      (d) date strictly later than previous link's date

    Args:
        workspace_id: scope to walk
        transfers_dir: directory containing transfer .seif modules
        genesis_pubkey: if provided, the FIRST link's signed_by must match
            this key (the original Owner). When None, the first link is
            verified only against its own embedded signed_by — useful for
            validating a chain in isolation without a known root.

    Returns:
        {"valid": bool, "chain": [transfer_record_dict, ...], "error": str | None,
         "broken_at": int | None}
    """
    transfers_dir = Path(transfers_dir)
    entries = _load_transfer_modules(transfers_dir, workspace_id)

    # Sort by date (ISO-8601 sorts lexicographically when timezones consistent)
    entries.sort(key=lambda e: e[2].get("date", ""))

    chain: list[dict] = []
    prev_record: dict | None = None

    for idx, (_path, _module, record) in enumerate(entries):
        # Rule (c) scope sanity (already filtered upstream, defensive)
        if record.get("scope") != workspace_id:
            return {
                "valid": False,
                "chain": chain,
                "error": f"scope mismatch at link {idx}",
                "broken_at": idx,
            }

        # Rule (b) chain-of-trust binding
        if idx == 0:
            expected = genesis_pubkey  # may be None
        else:
            expected = prev_record["transfer_to"]

        result = verify(record, expected_prev_owner_pubkey=expected)

        # Rule (a) signature itself
        if not result["valid"]:
            return {
                "valid": False,
                "chain": chain,
                "error": f"link {idx}: {result['reason']}",
                "broken_at": idx,
            }

        # Rule (d) strictly increasing dates
        if prev_record is not None:
            if record.get("date", "") <= prev_record.get("date", ""):
                return {
                    "valid": False,
                    "chain": chain,
                    "error": (
                        f"link {idx}: date {record.get('date')} is not strictly later "
                        f"than previous link's date {prev_record.get('date')}"
                    ),
                    "broken_at": idx,
                }

        chain.append(record)
        prev_record = record

    return {"valid": True, "chain": chain, "error": None, "broken_at": None}
