"""SEIF governance — Owner-present operations (A22 transfer; future: A19 succession code surface)."""
