import math, socket,base64,sys, hashlib, pickle, random, pygame as pyg
from typing_extensions import TypeAlias
from pygame.surface import SurfaceType
from socketio.exceptions import SocketIOError
from cryptography.fernet import Fernet

class Tuple:
    """
    Usage: \n
    var = Tuple(x, y, z=None, ...) \n
    var.x = var.n1 = var[0] = x\n
    var.y = var.n2 = var[1] = y\n
    var.z = var.n3 = var[2] = z
    """

    def __init__(self, *vArgs):
        if not all(isinstance(i, (int, float)) for i in vArgs): raise TypeError("Tuples may only contain numbers for now")
        self.argv = []
        for i,obj in enumerate(vArgs):
            self.argv.append(obj)

    @property
    def __class__(self):
        return tuple

    def __getattr__(self, attr) -> int:
        name = attr.lower()
        if name.startswith('n') and name[1:].isdigit():
            index = int(name[1:]) - 1
            if 0 <= index < len(self.argv):
                return self.argv[index]
            raise IndexError(f"Tuple index out of range")
        raise AttributeError(f"'Tuple' object has no attribute '{name}'")

    @property
    def x(self) -> int: return self.argv[0]
    @property
    def y(self) -> int: return self.argv[1]
    @property
    def z(self) -> int: return self.argv[2]
    @property
    def tuple(self) -> tuple: return tuple(self.argv)

    def str(self):
        """Returns string representation of the Tuple"""
        fullString = ""
        for arg in self.argv:
            fullString += str(arg)
            fullString += ", "
        return fullString

    def __str__(self):
        """Returns string representation of the Tuple"""
        fullString = ""
        for arg in self.argv:
            fullString += str(arg)
            fullString += ", "
        return fullString

    def __repr__(self):  # optional, for debugging
        return self.__str__()

    def __iter__(self):
        for arg in self.argv:
            yield arg

    def __len__(self):
        return len(self.argv)

    def __getitem__(self, i):
        return self.argv[i]


class connection(socket.socket):
    def __init__(self, family: socket.AddressFamily | int = -1, type: socket.SocketKind | int = -1, proto: int = -1, fileno: int | None = None):
        self.publicKey = None
        self.privateKey = _generateKey()
        self.is_host = None
        self.mixedKey = None
        self.key = None
        super().__init__(family, type, proto, fileno)
    def _fail(self, conn=None):
        if conn is not None:
            conn.close()
        else:
            super().close()
        return None
    def _recvDict(self, conn, bufsize=4096):
        """Receive and unpickle a dict from a socket. Returns None on failure."""
        try:
            data = conn.recv(bufsize)
        except:
            return None
        if data is None: return None
        try:
            result = pickle.loads(data)
        except:
            return None
        if not isinstance(result, dict): return None
        return result
    def _sendDict(self, conn, data: dict):
        conn.send(pickle.dumps(data))
    def bind(self, address, /):
        self.publicKey = _generateKey()
        self.is_host = True
        return super().bind(address)
    def accept(self):
        conn, addr = super().accept()
        client = connection(fileno=conn.fileno())
        client.is_host = False
        client.privateKey = self.privateKey
        client.publicKey = self.publicKey
        client.mixedKey = _combine(self.publicKey, self.privateKey)
        # send public key and mixed key to client
        conn.send(pickle.dumps({"publicKey": client.publicKey}))
        conn.send(pickle.dumps({"mixedKeyServer": client.mixedKey}))
        # receive client's mixed key
        realData = self._recvDict(conn)
        if realData is None: return self._fail(conn)
        if realData.get("mixedKeyClient") is None: return self._fail(conn)
        clientMixedKey = realData["mixedKeyClient"]
        client.key = Fernet(_makeFernetKey(clientMixedKey, self.privateKey))
        return client, addr
    def connect(self, address, /):
        self.is_host = False
        data = super().connect(address)
        # receive public key
        realData = self._recvDict(self)
        if realData is None: return self._fail()
        if realData.get("publicKey") is None: return self._fail()
        self.publicKey = realData["publicKey"]
        # receive server's mixed key
        realData = self._recvDict(self)
        if realData is None: return self._fail()
        if realData.get("mixedKeyServer") is None: return self._fail()
        serverMixedKey = realData["mixedKeyServer"]
        # send client's mixed key
        self.mixedKey = _combine(self.publicKey, self.privateKey)
        self._sendDict(self, {"mixedKeyClient": self.mixedKey})
        self.key = Fernet(_makeFernetKey(serverMixedKey, self.mixedKey))
        return None
    def send(self, data: TypeAlias, flags: int = 0, /):
        if isinstance(data, dict):
            data = self.key.encrypt(pickle.dumps(data))
        elif isinstance(data, str):
            data = self.key.encrypt(data.encode())
        elif isinstance(data, bytes):
            data = self.key.encrypt(data)
        else:
            raise TypeError("data must be dict, str or bytes")
        return super().send(data, flags)
    def recv(self, bufsize: int, flags: int = 0, /):
        data = super().recv(bufsize, flags)
        return self.key.decrypt(data)
def _randomStr(length=15):
    temp = ""
    for i in range(length):
        temp1 = round(random.random() * 62) + 48
        temp2 = temp1
        if 57 < temp1 < 65:
            temp2 = temp1 + 7
        elif 90 < temp1 < 97:
            temp2 = temp1 + 6
        temp += chr(temp2)
    return temp
def _combine(a: str, b: str) -> str:
    """Combine two strings into an irreversible hash string."""
    return hashlib.sha256((a + b).encode()).hexdigest()
def _makeFernetKey(a: str, b: str) -> bytes:
    """Combine two strings into a valid 32-byte Fernet key."""
    raw = hashlib.sha256((a + b).encode()).digest()  # 32 raw bytes
    return base64.urlsafe_b64encode(raw)              # Fernet needs base64
def _generateKey() -> str:
    return _combine(_randomStr(), _randomStr())


class _Outline:
    def __init__(self, outline):
        if isinstance(outline, dict):
            enabled = outline.get("enabled", False)
            thickness = outline.get("thickness", 5)
            color = outline.get("color", "black")
            rounding = outline.get("rounding", 0)
        elif isinstance(outline, tuple):
            enabled = outline[0] if len(outline) > 0 else False
            thickness = outline[1] if len(outline) > 1 else 5
            color = outline[2] if len(outline) > 2 else "black"
            rounding = outline[3] if len(outline) > 3 else 0
        else:
            raise TypeError("outline must be a dict or tuple")
        if not isinstance(enabled, bool):
            raise TypeError('outline "enabled" must exist and be a bool')
        if not isinstance(thickness, int):
            raise TypeError('outline "thickness" must exist and be an int')
        if not isinstance(color, str):
            raise TypeError('outline "color" must exist and be a str')
        if not isinstance(rounding, int):
            raise TypeError('outline "rounding" must exist and be an int')
        self.enabled = enabled
        self.thickness = thickness
        self.color = color
        self.rounding = rounding
class _TextObject:
    def __init__(self, name:str, text:str, x:int, y:int, size:int, color:str, autoPos:bool, priority:int, hit:bool=True, antiAlias:bool=True):
        self.name = name
        self.text = text
        self.category = "text"
        self.color = color
        self.size = size
        self.hit = hit
        self.priority = priority
        self.autoPos = autoPos
        self.antiAlias = antiAlias
        screen = pyg.display.get_surface()
        if autoPos and screen:
            self.x_ratio = x / screen.get_width()
            self.y_ratio = y / screen.get_height()
        else:
            self.x_ratio = None
            self.y_ratio = None
            self.x = x
            self.y = y
class _Object:
    def __init__(self, name:str, x:int, y:int, size, category:str, outline:tuple, color:str, hit:bool=True, autoPos:bool=True, priority:int=10):
        if not isinstance(outline, (dict, tuple)):
            raise TypeError("outline must be a dict or tuple.")
        if not 1 <= len(outline) <= 4:
            raise TypeError("outline must follow {'enabled':bool,'thickness':int,'color':str,'rounding': int} or (bool,int,str,int)")
        self.name = name
        self.category = category
        self.color = color
        self.hit = hit
        self.autoPos = autoPos
        self.priority = priority
        screen = pyg.display.get_surface()
        if autoPos and screen:
            self.x_ratio = x / screen.get_width()
            self.y_ratio = y / screen.get_height()
        else:
            self.x_ratio = None
            self.y_ratio = None
            self.x = x
            self.y = y
        if category == "circle":
            if isinstance(size, int):
                self.size = size
            elif isinstance(size, tuple):
                self.size = size[0]
            else:
                raise TypeError("size must be an int or tuple")
            self.radius = self.size
        else:
            if not isinstance(size, tuple): raise TypeError("size must be a tuple")
            if len(size) < 2: raise TypeError("size must have 2 values")
            self.width = size[0]
            self.height = size[1]
        try:
            self.outline: _Outline = _Outline(outline)
        except TypeError:
            self.outline: _Outline = _Outline((False,))

class Items:
    @staticmethod
    def init(size: Tuple | tuple, *args, **kwargs) -> 'Items':
        pyg.init()
        surface = pyg.display.set_mode(size, vsync=1,*args, **kwargs)
        return Items(surface)
    def __init__(self, display: SurfaceType):
        self.display = display
        self.objects: list[_Object | _TextObject] = []
        self.pixels: dict[tuple,list[_Object | _TextObject]] = {(0,0): []}
        self.render = self.render(self)
    def exist(self, name, x: int = None, y: int = None, literal: bool = False):
        if x is None or y is None:
            if isinstance(name, str):
                for thing in self.objects:
                    if thing.name == name: return True
            elif isinstance(name, _Object):
                if literal:
                    if name in self.objects: return True
                else:
                    for thing in self.objects:
                        if thing.name == name.name: return True
            else:
                raise TypeError("name must be a str or Object")
        else:
            if name is None:
                return bool(self.pixels[(x, y)])
            elif isinstance(name, str):
                for pixel in self.pixels[(x, y)]:
                    if pixel.name == name: return True
            elif isinstance(name, _Object):
                if literal:
                    if name in self.pixels[(x, y)]: return True
                else:
                    for pixel in self.pixels[(x, y)]:
                        if pixel.name == name.name and pixel.category == name.category: return True
            else:
                raise TypeError("name must be a str or Object")
        return False
    class render:
        def __init__(self,selff):
            self.parent = selff
        def text(self,name,text,x,y,size,color="black",autoPos:bool=True,priority:int=10):
            a = _TextObject(name, text, x, y, size, color, autoPos, priority)
            self.parent.objects.append(a)
            self.parent.objects = sorted(self.parent.objects, key=lambda x: x.priority)
            return a
        def box(self,name:str,x:int,y:int,width:int,height:int,color="white",outline=None):
            a=_Object(name,x,y,(width,height),"rectangle",outline,color)
            self.parent.objects.append(a)
            self.parent.objects = sorted(self.parent.objects, key=lambda x: x.priority)
            return a
        def circle(self,name:str,x:int,y:int,radius:int,color="white",outline=(True,)):
            a=_Object(name,x,y,radius,"circle",outline, color)
            self.parent.objects.append(a)
            self.parent.objects = sorted(self.parent.objects, key=lambda x: x.priority)
            return a

    def draw(self):
        sw = self.display.get_width()
        sh = self.display.get_height()
        def getPos(item):
            if item.x_ratio is not None:
                return item.x_ratio * sw, item.y_ratio * sh
            return item.x, item.y
        for item in self.objects:
            x, y = getPos(item)
            if item.category == "text":
                itemFont = pyg.font.Font(item.name, item.size)
                itemSurface = itemFont.render(item.text, item.antiAlias, item.color)
                self.display.blit(itemSurface, (x, y))
            elif item.category == "rectangle":
                pyg.draw.rect(self.display, item.color, (x, y, item.width, item.height))
                if item.outline.enabled:
                    pyg.draw.rect(self.display, item.outline.color, (x, y, item.width, item.height),item.outline.thickness, item.outline.rounding)
            elif item.category == "circle":
                pyg.draw.circle(self.display, item.color, (x, y), item.radius)
                if item.outline.enabled:
                    pyg.draw.circle(self.display, item.outline.color, (x, y), item.radius, item.outline.thickness)
    def flip(self):
        self.draw()
        pyg.display.flip()
    def update(self,items):
        if isinstance(items, SurfaceType):
            self.display = items
        elif isinstance(items, tuple):
            if all(isinstance(item,(_Object,_TextObject)) for item in items):
                for item in items:
                    if item in self.objects: continue
                    self.objects.append(item)
                    self.objects = sorted(self.objects, key=lambda x: x.priority)
            else:
                raise TypeError("argument must be a tuple full of Objects or TextObjects")
        else:
            raise TypeError("argument must be a tuple or a surfaceType")