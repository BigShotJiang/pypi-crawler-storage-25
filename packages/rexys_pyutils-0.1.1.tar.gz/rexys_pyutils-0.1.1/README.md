hello!  
check [my wiki](https://www.github.com/rexy4444/wiki/wiki/pyutils)