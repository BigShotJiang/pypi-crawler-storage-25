"""WebOQL API module"""
