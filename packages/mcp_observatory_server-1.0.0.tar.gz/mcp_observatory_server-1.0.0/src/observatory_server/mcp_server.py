from __future__ import annotations

from fastmcp import FastMCP

from observatory_server.adapters.llm import LLMAdapter, LLMConfig
from observatory_server.adapters.prom import PromAdapter, PromConfig
from observatory_server.core.context import ObservatoryContext
from observatory_server.core.models import (
    AbandonmentSignal,
    FleetHealth,
    FleetHealthExplanation,
    ServerComparison,
    TimeSeries,
)
from observatory_server.tools.compare_servers import NEEDS as COMPARE_NEEDS
from observatory_server.tools.compare_servers import compare_servers as _compare_servers
from observatory_server.tools.detect_tool_abandonment import NEEDS as DETECT_ABANDONMENT_NEEDS
from observatory_server.tools.detect_tool_abandonment import (
    detect_tool_abandonment as _detect_tool_abandonment,
)
from observatory_server.tools.explain_fleet_health import NEEDS as EXPLAIN_FLEET_NEEDS
from observatory_server.tools.explain_fleet_health import (
    explain_fleet_health as _explain_fleet_health,
)
from observatory_server.tools.get_fleet_health import NEEDS as GET_FLEET_NEEDS
from observatory_server.tools.get_fleet_health import get_fleet_health as _get_fleet_health
from observatory_server.tools.get_tool_call_rate import NEEDS as GET_RATE_NEEDS
from observatory_server.tools.get_tool_call_rate import get_tool_call_rate as _get_tool_call_rate
from observatory_server.tools.get_tool_error_rate import NEEDS as GET_ERROR_RATE_NEEDS
from observatory_server.tools.get_tool_error_rate import get_tool_error_rate as _get_tool_error_rate
from observatory_server.tools.get_tool_latency_p99 import NEEDS as GET_LATENCY_NEEDS
from observatory_server.tools.get_tool_latency_p99 import (
    get_tool_latency_p99 as _get_tool_latency_p99,
)
from observatory_server.tools.list_mcp_servers import NEEDS as LIST_SERVERS_NEEDS
from observatory_server.tools.list_mcp_servers import list_mcp_servers as _list_mcp_servers
from observatory_server.tools.verify_services import NEEDS as VERIFY_SERVICES_NEEDS
from observatory_server.tools.verify_services import ServiceVerification
from observatory_server.tools.verify_services import verify_services as _verify_services

_DEFAULT_PROM_URL = "http://localhost:9090"


def _build_ctx() -> ObservatoryContext:
    prom = PromAdapter(PromConfig(base_url=_DEFAULT_PROM_URL))
    llm = LLMAdapter(LLMConfig.from_sources())
    return ObservatoryContext(prom=prom, llm=llm)


def build_server() -> FastMCP:
    server = FastMCP("mcp-observatory-server")

    @server.tool(name="list_mcp_servers")
    async def list_mcp_servers_tool(window: str = "24h") -> list[str]:
        """Return sorted unique MCP server service names seen in Prometheus over the given window."""
        ctx = _build_ctx().guard(needs=LIST_SERVERS_NEEDS)
        return await _list_mcp_servers(ctx, window=window)

    @server.tool(name="get_tool_call_rate")
    async def get_tool_call_rate_tool(
        service: str,
        tool: str | None = None,
        window: str = "1h",
    ) -> TimeSeries:
        """Return call-rate TimeSeries for an MCP server (optionally filtered by tool)."""
        ctx = _build_ctx().guard(needs=GET_RATE_NEEDS)
        return await _get_tool_call_rate(ctx, service=service, tool=tool, window=window)

    @server.tool(name="get_tool_error_rate")
    async def get_tool_error_rate_tool(
        service: str,
        tool: str | None = None,
        window: str = "1h",
    ) -> TimeSeries:
        """Return error-rate TimeSeries (ratio of error calls to total) for an MCP service."""
        ctx = _build_ctx().guard(needs=GET_ERROR_RATE_NEEDS)
        return await _get_tool_error_rate(ctx, service=service, tool=tool, window=window)

    @server.tool(name="get_tool_latency_p99")
    async def get_tool_latency_p99_tool(
        service: str,
        tool: str | None = None,
        window: str = "1h",
    ) -> TimeSeries:
        """Return p99 latency TimeSeries (seconds) for an MCP service via histogram_quantile."""
        ctx = _build_ctx().guard(needs=GET_LATENCY_NEEDS)
        return await _get_tool_latency_p99(ctx, service=service, tool=tool, window=window)

    @server.tool(name="compare_servers")
    async def compare_servers_tool(
        service_a: str,
        service_b: str,
        window: str = "1h",
    ) -> ServerComparison:
        """Compare two MCP services by tool count, error rate, and p99 latency."""
        ctx = _build_ctx().guard(needs=COMPARE_NEEDS)
        return await _compare_servers(ctx, service_a=service_a, service_b=service_b, window=window)

    @server.tool(name="detect_tool_abandonment")
    async def detect_tool_abandonment_tool(
        service: str | None = None,
        tool: str | None = None,
        drop_pct: float = 80.0,
        baseline_min_rate: float = 0.1,
        error_rate_floor: float = 0.01,
    ) -> list[AbandonmentSignal]:
        """Detect tools that agents may have silently stopped using."""
        ctx = _build_ctx().guard(needs=DETECT_ABANDONMENT_NEEDS)
        return await _detect_tool_abandonment(
            ctx,
            service=service,
            tool=tool,
            drop_pct=drop_pct,
            baseline_min_rate=baseline_min_rate,
            error_rate_floor=error_rate_floor,
        )

    @server.tool(name="get_fleet_health")
    async def get_fleet_health_tool(window: str = "24h") -> FleetHealth:
        """Aggregate fleet-wide health: per-server tool counts, error rates, and p99 latency."""
        ctx = _build_ctx().guard(needs=GET_FLEET_NEEDS)
        return await _get_fleet_health(ctx, window=window)

    @server.tool(name="explain_fleet_health")
    async def explain_fleet_health_tool() -> FleetHealthExplanation:
        """Synthesise a fleet-wide health narrative using LLM (with deterministic fallback)."""
        ctx = _build_ctx().guard(needs=EXPLAIN_FLEET_NEEDS)
        return await _explain_fleet_health(ctx)

    @server.tool(name="verify_services")
    async def verify_services_tool(
        expected: list[str],
        window: str = "24h",
    ) -> ServiceVerification:
        """Check which expected MCP service names are visible in Prometheus metrics."""
        ctx = _build_ctx().guard(needs=VERIFY_SERVICES_NEEDS)
        return await _verify_services(ctx, expected=expected, window=window)

    return server


def run_stdio() -> None:
    build_server().run()
