from __future__ import annotations

from datetime import UTC, datetime

from observatory_server.core.context import GuardedContext
from observatory_server.core.models import Capability, TimeSeries
from observatory_server.core.tracing import tracer
from observatory_server.tools._util import _parse_window

NEEDS = frozenset({Capability.PROM})


async def get_tool_error_rate(
    ctx: GuardedContext,
    service: str,
    tool: str | None = None,
    window: str = "1h",
) -> TimeSeries:
    """Return error-rate TimeSeries (ratio of error calls to total) for a service over window."""
    with tracer().start_as_current_span("tool.get_tool_error_rate") as span:
        span.set_attribute("tool.name", "get_tool_error_rate")
        span.set_attribute("service", service)
        span.set_attribute("window", window)
        delta = _parse_window(window)
        end = datetime.now(UTC)
        start = end - delta
        step = max(15.0, delta.total_seconds() / 300)
        tool_clause = f',tool="{tool}"' if tool else ""
        promql = (
            f'sum(rate(mcp_tool_calls_total{{service="{service}",outcome="error"{tool_clause}}}[5m])) '
            f'/ sum(rate(mcp_tool_calls_total{{service="{service}"{tool_clause}}}[5m]))'
        )
        data = await ctx.prom.query_range(promql, start.timestamp(), end.timestamp(), step)
        samples: list[tuple[datetime, float]] = []
        for series in data.get("result") or []:
            for ts, raw in series.get("values", []):
                try:
                    samples.append((datetime.fromtimestamp(float(ts), UTC), float(raw)))
                except (TypeError, ValueError):
                    continue
        return TimeSeries(promql=promql, start=start, end=end, step_s=step, samples=samples)
