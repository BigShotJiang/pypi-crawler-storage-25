from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, Field

from md_generator.codeflow.core.run_config import ScanConfig


class AnalyzeOptions(BaseModel):
    formats: str | None = Field(default=None, description="Comma-separated: md,html,mermaid,json")
    depth: int = 5
    languages: str = "mixed"
    entry: str | None = None
    include: str | None = None
    exclude: str | None = None
    business_rules: bool | None = Field(default=None, description="If set, enable/disable business rule MD")
    business_rules_sql: bool | None = Field(default=None, description="If true, scan *.sql for triggers")
    business_rules_combined: bool | None = Field(default=None, description="If set, control entry.combined.md")
    entry_fallback: Literal["none", "roots", "first_n"] | None = Field(
        default=None,
        description="none | roots | first_n when no detected entries",
    )
    entry_fallback_max: int | None = None
    emit_entry_per_method: bool | None = None
    emit_entry_max: int | None = None
    emit_entry_filter: str | None = None
    entries_file: str | None = Field(default=None, description="Path to file of symbol ids (workspace-relative or absolute)")
    write_scan_summary: bool | None = Field(default=None, description="If false, skip scan-summary.md")
    liferay_portlet_base_classes: str | None = Field(
        default=None,
        description="Comma-separated extra portlet superclass simple names",
    )
    codeflow_config_path: str | None = Field(default=None, description="Path to codeflow.yaml")
    emit_flow_tree_json: bool | None = None
    verbose: bool | None = None
    emit_graph_schema: bool | None = None
    intelligence_list_cap: int | None = None
    emit_cfg: bool | None = None
    cfg_max_nodes: int | None = None
    cfg_inline_calls: bool | None = None
    cfg_call_depth: int | None = None
    cfg_max_paths: int | None = None
    cfg_path_max_depth: int | None = None
    cfg_loop_visits: int | None = None
    cfg_probability: bool | None = None
    cfg_mermaid_probabilities: bool | None = None
    cfg_runtime_trace: str | None = None
    cfg_loop_repeat_prob: float | None = None
    graph_include_structural: bool | None = None
    intelligence_transitive_callers: bool | None = None
    emit_system_graph_stats: bool | None = None
    emit_graph_sqlite: bool | None = None
    graph_sqlite_mode: Literal["full", "incremental"] | None = Field(
        default=None,
        description="full replaces graph.db; incremental upserts rows and records scans",
    )
    graph_sqlite_prune_missing: bool | None = Field(
        default=None,
        description="incremental mode: delete nodes/edges not seen in latest scan",
    )
    emit_graph_communities: bool | None = None
    emit_cluster_labels: bool | None = Field(
        default=None,
        description="Rule-based community labels in graph-communities.json and Markdown (default true)",
    )
    emit_llm_entry_sidecar: bool | None = None
    include_references: bool | None = None
    include_events: bool | None = None
    cfg_ir_go: bool | None = None
    cfg_ir_php: bool | None = None
    cfg_ir_cpp: bool | None = None
    flow_include_event_edges: bool | None = None
    flow_include_reference_edges: bool | None = None
    event_impact: bool | None = None
    cluster_mode: Literal["file_imports", "structural", "semantic", "hybrid"] | None = None
    graph_query: str | None = None
    enable_embeddings: bool | None = None
    embedding_model: str | None = None
    embedding_max_nodes: int | None = None
    embedding_k_clusters: int | None = None
    semantic_top_k: int | None = None
    semantic_search: str | None = None
    emit_html_unified: bool | None = None
    nl_query: str | None = None
    emit_runtime_insights: bool | None = None
    runtime_insight_frequency_threshold: float | None = None
    runtime_insight_hot_paths_top: int | None = None
    semantic_outlier_distance_threshold: float | None = None
    multi_repo: str | None = Field(
        default=None,
        description="Comma-separated extra repository roots to merge with workspace (first root is workspace)",
    )
    diff_base: str | None = Field(default=None, description="Git ref/SHA for PR diff (with diff_head)")
    diff_head: str | None = Field(default=None, description="Git ref/SHA for PR diff (with diff_base)")
    cross_repo_package_hints: str | None = Field(
        default=None,
        description='JSON object mapping package prefix to repo label, e.g. {"com.foo":"repo_a"}',
    )
    resolve_cross_repo: bool | None = Field(default=None, description="Resolve external:: imports across merged repos (hints JSON)")
    cross_repo_tsconfig: bool | None = Field(
        default=None,
        description="Use tsconfig/jsconfig paths per repo for @… cross-repo matching (with resolve_cross_repo)",
    )
    cross_repo_maven_hints: bool | None = Field(
        default=None,
        description="Add Maven groupId→repo hints from pom.xml (with resolve_cross_repo; explicit hints win)",
    )
    cache_enabled: bool | None = Field(default=None, description="Enable git TTL metadata and unified cache writes")
    cache_ttl_seconds: int | None = Field(default=None, description="Git clone refresh skip window in seconds (0=off)")
    cache_clear_mode: str | None = Field(
        default=None,
        description="semantic | unified | all (project cache); git/all also clears global git cache at API boundary if set",
    )
    graph_include_contains_reachability: bool | None = Field(
        default=None,
        description="Include REL_CONTAINS in dependency reachability (PR impact, Called by, Impact)",
    )
    enable_dependency_graph: bool | None = Field(default=None, description="Alias: enable structural IMPORTS/dependency merge")
    parser_mode: Literal["auto", "treesitter", "external"] | None = None
    ui_cfg_max_methods: int | None = Field(default=None, description="Max CFG Mermaid payloads embedded in unified HTML")
    ui: str | None = Field(default=None, description="Set unified to enable emit_html_unified")


def options_to_scan_config(workspace_src: Path, output_subdir: str, raw: AnalyzeOptions | None) -> ScanConfig:
    fmts = ("md", "mermaid", "json")
    if raw and raw.formats:
        fmts = tuple(x.strip().lower() for x in raw.formats.split(",") if x.strip())
    entry_list = None
    if raw and raw.entry:
        entry_list = [x.strip() for x in raw.entry.split(",") if x.strip()]
    br = True if not raw or raw.business_rules is None else raw.business_rules
    br_sql = False if not raw or raw.business_rules_sql is None else raw.business_rules_sql
    br_comb = True if not raw or raw.business_rules_combined is None else raw.business_rules_combined
    ef = "roots" if not raw or raw.entry_fallback is None else raw.entry_fallback
    efm = 20 if not raw or raw.entry_fallback_max is None else int(raw.entry_fallback_max)
    epm = False if not raw or raw.emit_entry_per_method is None else bool(raw.emit_entry_per_method)
    emx = None if not raw else raw.emit_entry_max
    efilt = None if not raw else raw.emit_entry_filter
    efpath = None
    if raw and raw.entries_file:
        efpath = Path(raw.entries_file)
        if not efpath.is_absolute():
            efpath = (workspace_src / efpath).resolve()
        else:
            efpath = efpath.resolve()
    wss = True if not raw or raw.write_scan_summary is None else bool(raw.write_scan_summary)
    lpbc: tuple[str, ...] = ()
    if raw and raw.liferay_portlet_base_classes and str(raw.liferay_portlet_base_classes).strip():
        lpbc = tuple(x.strip() for x in str(raw.liferay_portlet_base_classes).split(",") if x.strip())
    ccpath = None
    if raw and raw.codeflow_config_path and str(raw.codeflow_config_path).strip():
        p = Path(raw.codeflow_config_path.strip())
        ccpath = p if p.is_absolute() else (workspace_src / p).resolve()
    eftj = False if not raw or raw.emit_flow_tree_json is None else bool(raw.emit_flow_tree_json)
    verb = False if not raw or raw.verbose is None else bool(raw.verbose)
    egs = False if not raw or raw.emit_graph_schema is None else bool(raw.emit_graph_schema)
    ilc = 80 if not raw or raw.intelligence_list_cap is None else int(raw.intelligence_list_cap)
    ecfg = False if not raw or raw.emit_cfg is None else bool(raw.emit_cfg)
    cmn = 500 if not raw or raw.cfg_max_nodes is None else int(raw.cfg_max_nodes)
    cic = False if not raw or raw.cfg_inline_calls is None else bool(raw.cfg_inline_calls)
    ccd = 3 if not raw or raw.cfg_call_depth is None else int(raw.cfg_call_depth)
    cmpaths = 100 if not raw or raw.cfg_max_paths is None else int(raw.cfg_max_paths)
    cpmd = 1000 if not raw or raw.cfg_path_max_depth is None else int(raw.cfg_path_max_depth)
    clv = 2 if not raw or raw.cfg_loop_visits is None else int(raw.cfg_loop_visits)
    cprob = False if not raw or raw.cfg_probability is None else bool(raw.cfg_probability)
    cmmdp = False if not raw or raw.cfg_mermaid_probabilities is None else bool(raw.cfg_mermaid_probabilities)
    crt = None
    if raw and raw.cfg_runtime_trace and str(raw.cfg_runtime_trace).strip():
        crt = Path(str(raw.cfg_runtime_trace).strip())
        if not crt.is_absolute():
            crt = (workspace_src / crt).resolve()
        else:
            crt = crt.resolve()
    clrp = 0.6 if not raw or raw.cfg_loop_repeat_prob is None else float(raw.cfg_loop_repeat_prob)
    gis = False if not raw or raw.graph_include_structural is None else bool(raw.graph_include_structural)
    itc = False if not raw or raw.intelligence_transitive_callers is None else bool(raw.intelligence_transitive_callers)
    esgs = False if not raw or raw.emit_system_graph_stats is None else bool(raw.emit_system_graph_stats)
    egsql = False if not raw or raw.emit_graph_sqlite is None else bool(raw.emit_graph_sqlite)
    gsm: Literal["full", "incremental"] = (
        "full" if not raw or raw.graph_sqlite_mode is None else raw.graph_sqlite_mode  # type: ignore[assignment]
    )
    gsp = False if not raw or raw.graph_sqlite_prune_missing is None else bool(raw.graph_sqlite_prune_missing)
    gicr = (
        False
        if not raw or raw.graph_include_contains_reachability is None
        else bool(raw.graph_include_contains_reachability)
    )
    xc_ts = False if not raw or raw.cross_repo_tsconfig is None else bool(raw.cross_repo_tsconfig)
    xmvn = False if not raw or raw.cross_repo_maven_hints is None else bool(raw.cross_repo_maven_hints)
    egc = False if not raw or raw.emit_graph_communities is None else bool(raw.emit_graph_communities)
    ecl = True if not raw or raw.emit_cluster_labels is None else bool(raw.emit_cluster_labels)
    ellm = False if not raw or raw.emit_llm_entry_sidecar is None else bool(raw.emit_llm_entry_sidecar)
    iref = False if not raw or raw.include_references is None else bool(raw.include_references)
    ievt = False if not raw or raw.include_events is None else bool(raw.include_events)
    cgo = True if not raw or raw.cfg_ir_go is None else bool(raw.cfg_ir_go)
    cphp = True if not raw or raw.cfg_ir_php is None else bool(raw.cfg_ir_php)
    ccpp = True if not raw or raw.cfg_ir_cpp is None else bool(raw.cfg_ir_cpp)
    fie = False if not raw or raw.flow_include_event_edges is None else bool(raw.flow_include_event_edges)
    fir = False if not raw or raw.flow_include_reference_edges is None else bool(raw.flow_include_reference_edges)
    eimp = False if not raw or raw.event_impact is None else bool(raw.event_impact)
    cm = "file_imports" if not raw or raw.cluster_mode is None else raw.cluster_mode
    gq = None if not raw or raw.graph_query is None or not str(raw.graph_query).strip() else str(raw.graph_query).strip()
    eemb = False if not raw or raw.enable_embeddings is None else bool(raw.enable_embeddings)
    emod = "all-MiniLM-L6-v2" if not raw or raw.embedding_model is None else str(raw.embedding_model)
    emax = 5000 if not raw or raw.embedding_max_nodes is None else int(raw.embedding_max_nodes)
    ekc = 8 if not raw or raw.embedding_k_clusters is None else int(raw.embedding_k_clusters)
    stk = 10 if not raw or raw.semantic_top_k is None else int(raw.semantic_top_k)
    ssr = None if not raw or raw.semantic_search is None or not str(raw.semantic_search).strip() else str(raw.semantic_search).strip()
    ehu = False if not raw or raw.emit_html_unified is None else bool(raw.emit_html_unified)
    if raw and raw.ui and str(raw.ui).strip().lower() == "unified":
        ehu = True
    nlq = None if not raw or raw.nl_query is None or not str(raw.nl_query).strip() else str(raw.nl_query).strip()
    eri = False if not raw or raw.emit_runtime_insights is None else bool(raw.emit_runtime_insights)
    rift = 0.05 if not raw or raw.runtime_insight_frequency_threshold is None else float(raw.runtime_insight_frequency_threshold)
    riht = 5 if not raw or raw.runtime_insight_hot_paths_top is None else int(raw.runtime_insight_hot_paths_top)
    sodt = 0.7 if not raw or raw.semantic_outlier_distance_threshold is None else float(raw.semantic_outlier_distance_threshold)
    edg = False if not raw or raw.enable_dependency_graph is None else bool(raw.enable_dependency_graph)
    pm: Literal["auto", "treesitter", "external"] = (
        "auto" if not raw or raw.parser_mode is None else raw.parser_mode  # type: ignore[assignment]
    )
    uic = 25 if not raw or raw.ui_cfg_max_methods is None else int(raw.ui_cfg_max_methods)
    multi_roots: tuple[Path, ...] = ()
    if raw and raw.multi_repo and str(raw.multi_repo).strip():
        parts = [x.strip() for x in str(raw.multi_repo).split(",") if x.strip()]
        multi_roots = tuple((workspace_src / p).resolve() if not Path(p).is_absolute() else Path(p).resolve() for p in parts)
    db = None if not raw or raw.diff_base is None or not str(raw.diff_base).strip() else str(raw.diff_base).strip()
    dh = None if not raw or raw.diff_head is None or not str(raw.diff_head).strip() else str(raw.diff_head).strip()
    cr_hints: dict[str, str] | None = None
    if raw and raw.cross_repo_package_hints and str(raw.cross_repo_package_hints).strip():
        try:
            obj = json.loads(str(raw.cross_repo_package_hints).strip())
            if isinstance(obj, dict):
                cr_hints = {str(k): str(v) for k, v in obj.items()}
        except json.JSONDecodeError:
            cr_hints = None
    rcr = False if not raw or raw.resolve_cross_repo is None else bool(raw.resolve_cross_repo)
    c_en = True if not raw or raw.cache_enabled is None else bool(raw.cache_enabled)
    c_ttl = 0 if not raw or raw.cache_ttl_seconds is None else int(raw.cache_ttl_seconds)
    c_cm = None if not raw or raw.cache_clear_mode is None else str(raw.cache_clear_mode).strip() or None
    return ScanConfig(
        project_root=workspace_src,
        output_path=workspace_src.parent / output_subdir,
        formats=fmts,
        depth=(raw.depth if raw else 5),
        languages=(raw.languages if raw else "mixed"),
        entry=entry_list,
        include=raw.include if raw else None,
        exclude=raw.exclude if raw else None,
        business_rules=br,
        business_rules_sql=br_sql,
        business_rules_combined=br_comb,
        entry_fallback=ef,  # type: ignore[arg-type]
        entry_fallback_max=efm,
        emit_entry_per_method=epm,
        emit_entry_max=emx,
        emit_entry_filter=efilt,
        entries_file=efpath,
        write_scan_summary=wss,
        liferay_portlet_base_classes=lpbc,
        codeflow_config_path=ccpath,
        emit_flow_tree_json=eftj,
        verbose=verb,
        emit_graph_schema=egs,
        intelligence_list_cap=ilc,
        emit_cfg=ecfg,
        cfg_max_nodes=cmn,
        cfg_inline_calls=cic,
        cfg_call_depth=ccd,
        cfg_max_paths=cmpaths,
        cfg_path_max_depth=cpmd,
        cfg_loop_visits=clv,
        cfg_probability=cprob,
        cfg_mermaid_probabilities=cmmdp,
        cfg_runtime_trace=crt,
        cfg_loop_repeat_prob=clrp,
        graph_include_structural=gis,
        include_references=iref,
        include_events=ievt,
        cfg_ir_go=cgo,
        cfg_ir_php=cphp,
        cfg_ir_cpp=ccpp,
        flow_include_event_edges=fie,
        flow_include_reference_edges=fir,
        event_impact=eimp,
        cluster_mode=cm,  # type: ignore[arg-type]
        graph_query=gq,
        enable_embeddings=eemb,
        embedding_model=emod,
        embedding_max_nodes=emax,
        embedding_k_clusters=ekc,
        semantic_top_k=stk,
        semantic_search=ssr,
        emit_html_unified=ehu,
        nl_query=nlq,
        emit_runtime_insights=eri,
        runtime_insight_frequency_threshold=rift,
        runtime_insight_hot_paths_top=riht,
        semantic_outlier_distance_threshold=sodt,
        intelligence_transitive_callers=itc,
        emit_system_graph_stats=esgs,
        emit_graph_sqlite=egsql,
        graph_sqlite_mode=gsm,
        graph_sqlite_prune_missing=gsp,
        emit_graph_communities=egc,
        emit_cluster_labels=ecl,
        emit_llm_entry_sidecar=ellm,
        multi_repo_roots=multi_roots,
        diff_base=db,
        diff_head=dh,
        cross_repo_package_hints=cr_hints,
        resolve_cross_repo=rcr,
        cross_repo_tsconfig=xc_ts,
        cross_repo_maven_hints=xmvn,
        graph_include_contains_reachability=gicr,
        cache_enabled=c_en,
        cache_ttl_seconds=c_ttl,
        cache_clear_mode=c_cm,
        enable_dependency_graph=edg,
        parser_mode=pm,
        ui_cfg_max_methods=uic,
    )


def merge_upload_options_json(options_json: str | None) -> AnalyzeOptions | None:
    if not options_json:
        return None
    data = json.loads(options_json)
    return AnalyzeOptions.model_validate(data)


def scan_config_dump(cfg: ScanConfig) -> dict[str, Any]:
    return {
        "project_root": str(cfg.project_root),
        "output_path": str(cfg.output_path),
        "paths_override": [str(p) for p in cfg.paths_override] if cfg.paths_override else None,
        "formats": list(cfg.formats),
        "depth": cfg.depth,
        "languages": cfg.languages,
        "entry": cfg.entry,
        "include": cfg.include,
        "exclude": cfg.exclude,
        "include_internal": cfg.include_internal,
        "async_mode": cfg.async_mode,
        "jobs": cfg.jobs,
        "runtime": cfg.runtime,
        "business_rules": cfg.business_rules,
        "business_rules_sql": cfg.business_rules_sql,
        "business_rules_combined": cfg.business_rules_combined,
        "entry_fallback": cfg.entry_fallback,
        "entry_fallback_max": cfg.entry_fallback_max,
        "emit_entry_per_method": cfg.emit_entry_per_method,
        "emit_entry_max": cfg.emit_entry_max,
        "emit_entry_filter": cfg.emit_entry_filter,
        "entries_file": str(cfg.entries_file) if cfg.entries_file else None,
        "write_scan_summary": cfg.write_scan_summary,
        "liferay_portlet_base_classes": list(cfg.liferay_portlet_base_classes),
        "codeflow_config_path": str(cfg.codeflow_config_path) if cfg.codeflow_config_path else None,
        "emit_flow_tree_json": cfg.emit_flow_tree_json,
        "verbose": cfg.verbose,
        "emit_graph_schema": cfg.emit_graph_schema,
        "intelligence_list_cap": cfg.intelligence_list_cap,
        "emit_cfg": cfg.emit_cfg,
        "cfg_max_nodes": cfg.cfg_max_nodes,
        "cfg_inline_calls": cfg.cfg_inline_calls,
        "cfg_call_depth": cfg.cfg_call_depth,
        "cfg_max_paths": cfg.cfg_max_paths,
        "cfg_path_max_depth": cfg.cfg_path_max_depth,
        "cfg_loop_visits": cfg.cfg_loop_visits,
        "cfg_probability": cfg.cfg_probability,
        "cfg_mermaid_probabilities": cfg.cfg_mermaid_probabilities,
        "cfg_runtime_trace": str(cfg.cfg_runtime_trace) if cfg.cfg_runtime_trace else None,
        "cfg_loop_repeat_prob": cfg.cfg_loop_repeat_prob,
        "graph_include_structural": cfg.graph_include_structural,
        "intelligence_transitive_callers": cfg.intelligence_transitive_callers,
        "emit_system_graph_stats": cfg.emit_system_graph_stats,
        "emit_graph_sqlite": cfg.emit_graph_sqlite,
        "graph_sqlite_mode": cfg.graph_sqlite_mode,
        "graph_sqlite_prune_missing": cfg.graph_sqlite_prune_missing,
        "emit_graph_communities": cfg.emit_graph_communities,
        "emit_cluster_labels": cfg.emit_cluster_labels,
        "emit_llm_entry_sidecar": cfg.emit_llm_entry_sidecar,
        "include_references": cfg.include_references,
        "include_events": cfg.include_events,
        "cfg_ir_go": cfg.cfg_ir_go,
        "cfg_ir_php": cfg.cfg_ir_php,
        "cfg_ir_cpp": cfg.cfg_ir_cpp,
        "flow_include_event_edges": cfg.flow_include_event_edges,
        "flow_include_reference_edges": cfg.flow_include_reference_edges,
        "event_impact": cfg.event_impact,
        "cluster_mode": cfg.cluster_mode,
        "graph_query": cfg.graph_query,
        "enable_embeddings": cfg.enable_embeddings,
        "embedding_model": cfg.embedding_model,
        "embedding_max_nodes": cfg.embedding_max_nodes,
        "embedding_k_clusters": cfg.embedding_k_clusters,
        "semantic_top_k": cfg.semantic_top_k,
        "semantic_search": cfg.semantic_search,
        "emit_html_unified": cfg.emit_html_unified,
        "nl_query": cfg.nl_query,
        "emit_runtime_insights": cfg.emit_runtime_insights,
        "runtime_insight_frequency_threshold": cfg.runtime_insight_frequency_threshold,
        "runtime_insight_hot_paths_top": cfg.runtime_insight_hot_paths_top,
        "semantic_outlier_distance_threshold": cfg.semantic_outlier_distance_threshold,
        "multi_repo_roots": [str(p) for p in cfg.multi_repo_roots],
        "diff_base": cfg.diff_base,
        "diff_head": cfg.diff_head,
        "cross_repo_package_hints": dict(cfg.cross_repo_package_hints) if cfg.cross_repo_package_hints else None,
        "resolve_cross_repo": cfg.resolve_cross_repo,
        "cross_repo_tsconfig": cfg.cross_repo_tsconfig,
        "cross_repo_maven_hints": cfg.cross_repo_maven_hints,
        "graph_include_contains_reachability": cfg.graph_include_contains_reachability,
        "cache_enabled": cfg.cache_enabled,
        "cache_ttl_seconds": cfg.cache_ttl_seconds,
        "cache_clear_mode": cfg.cache_clear_mode,
        "enable_dependency_graph": cfg.enable_dependency_graph,
        "parser_mode": cfg.parser_mode,
        "ui_cfg_max_methods": cfg.ui_cfg_max_methods,
    }


def scan_config_load(data: dict[str, Any]) -> ScanConfig:
    po = data.get("paths_override")
    return ScanConfig(
        project_root=Path(data["project_root"]),
        output_path=Path(data["output_path"]),
        paths_override=[Path(p) for p in po] if po else None,
        formats=tuple(data.get("formats") or ("md", "mermaid", "json")),
        depth=int(data.get("depth", 5)),
        languages=str(data.get("languages", "mixed")),
        entry=list(data["entry"]) if data.get("entry") else None,
        include=data.get("include"),
        exclude=data.get("exclude"),
        include_internal=bool(data.get("include_internal", True)),
        async_mode=bool(data.get("async_mode", True)),
        jobs=bool(data.get("jobs", False)),
        runtime=bool(data.get("runtime", False)),
        business_rules=bool(data.get("business_rules", True)),
        business_rules_sql=bool(data.get("business_rules_sql", False)),
        business_rules_combined=bool(data.get("business_rules_combined", True)),
        entry_fallback=data.get("entry_fallback", "roots"),  # type: ignore[arg-type]
        entry_fallback_max=int(data.get("entry_fallback_max", 20)),
        emit_entry_per_method=bool(data.get("emit_entry_per_method", False)),
        emit_entry_max=data.get("emit_entry_max"),
        emit_entry_filter=data.get("emit_entry_filter"),
        entries_file=Path(data["entries_file"]) if data.get("entries_file") else None,
        write_scan_summary=bool(data.get("write_scan_summary", True)),
        liferay_portlet_base_classes=_load_liferay_bases(data.get("liferay_portlet_base_classes")),
        codeflow_config_path=Path(data["codeflow_config_path"]) if data.get("codeflow_config_path") else None,
        emit_flow_tree_json=bool(data.get("emit_flow_tree_json", False)),
        verbose=bool(data.get("verbose", False)),
        emit_graph_schema=bool(data.get("emit_graph_schema", False)),
        intelligence_list_cap=int(data.get("intelligence_list_cap", 80)),
        emit_cfg=bool(data.get("emit_cfg", False)),
        cfg_max_nodes=int(data.get("cfg_max_nodes", 500)),
        cfg_inline_calls=bool(data.get("cfg_inline_calls", False)),
        cfg_call_depth=int(data.get("cfg_call_depth", 3)),
        cfg_max_paths=int(data.get("cfg_max_paths", 100)),
        cfg_path_max_depth=int(data.get("cfg_path_max_depth", 1000)),
        cfg_loop_visits=int(data.get("cfg_loop_visits", 2)),
        cfg_probability=bool(data.get("cfg_probability", False)),
        cfg_mermaid_probabilities=bool(data.get("cfg_mermaid_probabilities", False)),
        cfg_runtime_trace=Path(data["cfg_runtime_trace"]) if data.get("cfg_runtime_trace") else None,
        cfg_loop_repeat_prob=float(data.get("cfg_loop_repeat_prob", 0.6)),
        graph_include_structural=bool(data.get("graph_include_structural", False)),
        intelligence_transitive_callers=bool(data.get("intelligence_transitive_callers", False)),
        emit_system_graph_stats=bool(data.get("emit_system_graph_stats", False)),
        emit_graph_sqlite=bool(data.get("emit_graph_sqlite", False)),
        graph_sqlite_mode=data.get("graph_sqlite_mode", "full"),  # type: ignore[arg-type]
        graph_sqlite_prune_missing=bool(data.get("graph_sqlite_prune_missing", False)),
        emit_graph_communities=bool(data.get("emit_graph_communities", False)),
        emit_cluster_labels=bool(data.get("emit_cluster_labels", True)),
        emit_llm_entry_sidecar=bool(data.get("emit_llm_entry_sidecar", False)),
        include_references=bool(data.get("include_references", False)),
        include_events=bool(data.get("include_events", False)),
        cfg_ir_go=bool(data.get("cfg_ir_go", True)),
        cfg_ir_php=bool(data.get("cfg_ir_php", True)),
        cfg_ir_cpp=bool(data.get("cfg_ir_cpp", True)),
        flow_include_event_edges=bool(data.get("flow_include_event_edges", False)),
        flow_include_reference_edges=bool(data.get("flow_include_reference_edges", False)),
        event_impact=bool(data.get("event_impact", False)),
        cluster_mode=data.get("cluster_mode", "file_imports"),  # type: ignore[arg-type]
        graph_query=data.get("graph_query"),
        enable_embeddings=bool(data.get("enable_embeddings", False)),
        embedding_model=str(data.get("embedding_model", "all-MiniLM-L6-v2")),
        embedding_max_nodes=int(data.get("embedding_max_nodes", 5000)),
        embedding_k_clusters=int(data.get("embedding_k_clusters", 8)),
        semantic_top_k=int(data.get("semantic_top_k", 10)),
        semantic_search=data.get("semantic_search"),
        emit_html_unified=bool(data.get("emit_html_unified", False)),
        nl_query=data.get("nl_query"),
        emit_runtime_insights=bool(data.get("emit_runtime_insights", False)),
        runtime_insight_frequency_threshold=float(data.get("runtime_insight_frequency_threshold", 0.05)),
        runtime_insight_hot_paths_top=int(data.get("runtime_insight_hot_paths_top", 5)),
        semantic_outlier_distance_threshold=float(data.get("semantic_outlier_distance_threshold", 0.7)),
        multi_repo_roots=tuple(Path(p) for p in (data.get("multi_repo_roots") or [])),
        diff_base=data.get("diff_base"),
        diff_head=data.get("diff_head"),
        cross_repo_package_hints=(
            {str(k): str(v) for k, v in data["cross_repo_package_hints"].items()}
            if isinstance(data.get("cross_repo_package_hints"), dict)
            else None
        ),
        resolve_cross_repo=bool(data.get("resolve_cross_repo", False)),
        cross_repo_tsconfig=bool(data.get("cross_repo_tsconfig", False)),
        cross_repo_maven_hints=bool(data.get("cross_repo_maven_hints", False)),
        graph_include_contains_reachability=bool(data.get("graph_include_contains_reachability", False)),
        cache_enabled=bool(data.get("cache_enabled", True)),
        cache_ttl_seconds=int(data.get("cache_ttl_seconds", 0)),
        cache_clear_mode=data.get("cache_clear_mode"),
        enable_dependency_graph=bool(data.get("enable_dependency_graph", False)),
        parser_mode=data.get("parser_mode", "auto"),  # type: ignore[arg-type]
        ui_cfg_max_methods=int(data.get("ui_cfg_max_methods", 25)),
    )


def _load_liferay_bases(raw: object) -> tuple[str, ...]:
    if raw is None:
        return ()
    if isinstance(raw, list):
        return tuple(str(x).strip() for x in raw if str(x).strip())
    if isinstance(raw, str):
        return tuple(x.strip() for x in raw.split(",") if x.strip())
    return ()
