"""API-Fassade – öffentliche Einstiegspunkte für den Mediathek Manager."""

from __future__ import annotations

from collections.abc import Callable
from pathlib import Path, PurePosixPath

from .models import (
    CheckNamesRequest,
    CheckNamesResult,
    GenerateLibraryRequest,
    GenerateLibraryResult,
    MediathekEvent,
    MediathekStage,
    NameCheckIssue,
    RuntimeOptions,
    ScanLibraryRequest,
    ScanLibraryResult,
    VideoMetadata,
)


def scan_library(
    request: ScanLibraryRequest,
    runtime: RuntimeOptions | None = None,
    on_event: Callable[[MediathekEvent], None] | None = None,
) -> ScanLibraryResult:
    """Scannt ein Verzeichnis und gibt Metadaten aller gefundenen Videos zurück."""
    runtime = runtime or RuntimeOptions()
    try:
        from ..services.storage import LocalBackend
        from ..core.scanner import scan_videos
        from ..core.metadata import extract_metadata

        backend = LocalBackend(Path(request.source_path))
        video_paths = scan_videos(backend, recursive=request.recursive)

        if on_event:
            on_event(MediathekEvent(
                stage_id=MediathekStage.SCAN_COMPLETED,
                message=f"{len(video_paths)} Videodateien gefunden",
            ))

        videos: list[VideoMetadata] = []
        for i, rp in enumerate(video_paths):
            if on_event:
                on_event(MediathekEvent(
                    stage_id=MediathekStage.METADATA_READING,
                    message=f"Lese Metadaten: {PurePosixPath(rp).name}",
                    current=i + 1,
                    total=len(video_paths),
                ))
            metadata = extract_metadata(backend, rp, runtime)
            videos.append(metadata)

        return ScanLibraryResult(success=True, videos=videos)

    except Exception as e:
        return ScanLibraryResult(success=False, error_message=str(e))


def generate_library(
    request: GenerateLibraryRequest,
    runtime: RuntimeOptions | None = None,
    on_event: Callable[[MediathekEvent], None] | None = None,
) -> GenerateLibraryResult:
    """Generiert eine statische HTML-Bibliothek aus einem lokalen Videoverzeichnis.

    Erzeugt eine einzelne Bibliothek mit Root = ``source_path`` (oder
    ``output_path``, falls angegeben). Im Root-Verzeichnis liegt nur
    ``index.html``; alle weiteren HTML-Dateien, Poster und CSS liegen
    unter ``mediathek/``. Die Hierarchie wird gespiegelt.

    Metadaten werden in ``mediathek/.metadata-cache.json`` gecacht —
    beim nächsten Lauf wird ffprobe nur für geänderte/neue Videos
    aufgerufen. Der Cache überlebt Abbrüche (atomischer Write).
    """
    runtime = runtime or RuntimeOptions()
    try:
        from ..services.storage import LocalBackend
        from ..core.scanner import scan_videos, find_all_subdirectories, detect_media_sets
        from ..core.metadata import extract_metadata
        from ..core.generator import generate_html
        from ..services.metadata_cache import (
            MetadataCache, cache_file_path, compute_cache_key,
        )

        backend = LocalBackend(Path(request.source_path))

        if on_event:
            on_event(MediathekEvent(
                stage_id=MediathekStage.SCAN_STARTED,
                message=f"Scanne {request.source_path}",
            ))

        # Alle Videos rekursiv sammeln (oder nur Root bei --no-recursive)
        video_paths = scan_videos(backend, recursive=request.recursive)
        subdirectories = find_all_subdirectories(backend) if request.recursive else []

        if on_event:
            on_event(MediathekEvent(
                stage_id=MediathekStage.SCAN_COMPLETED,
                message=f"{len(video_paths)} Videos, {len(subdirectories)} Unterverzeichnisse",
            ))

        # Output-Root und Source-Root bestimmen.
        source_root = Path(request.source_path)
        if request.output_path:
            output_root = Path(request.output_path)
            output_root.mkdir(parents=True, exist_ok=True)
            # Symlink-Bridge: ``_videos → source_root``. Alle Video-/Sidecar-
            # Referenzen in den HTML-Seiten gehen über ``_videos/…``. Der
            # Symlink wird vom ``serve``-Befehl transparent aufgelöst — über
            # HTTP gibt es keinen Cross-Origin-Block wie bei ``file://``.
            videos_link = output_root / "_videos"
            videos_link.unlink(missing_ok=True)
            videos_link.symlink_to(source_root.resolve())
        else:
            output_root = source_root

        # Metadaten-Cache laden
        local_cache_path = cache_file_path(output_root)
        cache = MetadataCache.load(local_cache_path)

        # Metadaten extrahieren — Cache-Hit überspringt ffprobe
        videos: list[VideoMetadata] = []
        cache_hits = 0
        cache_misses = 0
        for i, rp in enumerate(video_paths):
            # Cache-Key berechnen (mtime/size Video + Sidecars)
            key = compute_cache_key(backend, rp)
            cached = cache.get(rp, key) if key is not None else None

            if cached is not None:
                videos.append(cached)
                cache_hits += 1
                continue

            if on_event:
                on_event(MediathekEvent(
                    stage_id=MediathekStage.METADATA_READING,
                    message=f"Lese Metadaten: {PurePosixPath(rp).name}",
                    current=i + 1,
                    total=len(video_paths),
                ))
            metadata = extract_metadata(backend, rp, runtime)
            videos.append(metadata)
            cache_misses += 1
            if key is not None:
                cache.put(rp, key, metadata)

        # Cache bereinigen (gelöschte Videos entfernen) und speichern
        cache.prune(set(video_paths))
        try:
            cache.save(local_cache_path)
        except OSError:
            pass  # Cache-Write-Fehler dürfen den Lauf nicht abbrechen

        # Medienset-Verzeichnisse erkennen (Infuse-Konvention): Ordner mit genau
        # einem Video, dessen Stem dem Ordnernamen entspricht, werden nicht als
        # Zwischen-Ordner gerendert — das Video erscheint direkt im Parent.
        media_sets = detect_media_sets(videos, subdirectories)
        if media_sets:
            subdirectories = [s for s in subdirectories if s not in media_sets]
            for sub_path, video in media_sets.items():
                parent = str(PurePosixPath(sub_path).parent)
                prefix = f"{parent}/" if parent != "." else ""
                video.display_path = f"{prefix}{video.file_name}"

        # Eingebettete Cover-Atome als Poster-Fallback extrahieren.
        _extract_embedded_covers(backend, videos, output_root, runtime, on_event)

        # HTML generieren
        if on_event:
            on_event(MediathekEvent(
                stage_id=MediathekStage.HTML_GENERATING,
                message="Generiere HTML-Seiten",
            ))
        library_title = request.title or backend.root_name
        pages_generated = generate_html(
            library_title=library_title,
            videos=videos,
            subdirectories=subdirectories,
            output_root=output_root,
            source_root=source_root if source_root != output_root else None,
            show_card_titles=request.show_card_titles,
        )

        if on_event:
            on_event(MediathekEvent(
                stage_id=MediathekStage.LIBRARY_COMPLETED,
                message=f"Bibliothek generiert: {output_root}",
            ))

        return GenerateLibraryResult(
            success=True,
            videos_processed=len(videos),
            pages_generated=pages_generated,
            output_dir=output_root,
            cache_hits=cache_hits,
            cache_misses=cache_misses,
        )

    except Exception as e:
        return GenerateLibraryResult(success=False, error_message=str(e))


def check_names(
    request: CheckNamesRequest,
    runtime: RuntimeOptions | None = None,
    on_event: Callable[[MediathekEvent], None] | None = None,
) -> CheckNamesResult:
    """Prüft Dateinamen in einer Quelle auf SMB/URL/APFS-Kompatibilität.

    Read-only-Diagnose: der Mediathek Manager benennt niemals um. Gemeldet
    werden NFD-Unicode, URL-reservierte Zeichen (``#?&+%``), Windows-
    verbotene Zeichen, Überlängen, führende/abschließende Whitespaces,
    reservierte Windows-Basenamen und Groß-/Kleinschreibungs-Kollisionen.
    """
    runtime = runtime or RuntimeOptions()
    try:
        from ..services.storage import LocalBackend
        from ..core.scanner import scan_videos, find_all_subdirectories
        from ..core.name_checker import check_paths, NameIssue

        backend = LocalBackend(Path(request.source_path))

        if on_event:
            on_event(MediathekEvent(
                stage_id=MediathekStage.SCAN_STARTED,
                message=f"Scanne {request.source_path}",
            ))

        video_paths = scan_videos(backend, recursive=request.recursive)
        subdirs = find_all_subdirectories(backend) if request.recursive else []

        all_paths: list[str] = []
        seen: set[str] = set()
        for p in list(video_paths) + list(subdirs):
            if p not in seen:
                seen.add(p)
                all_paths.append(p)

        if on_event:
            on_event(MediathekEvent(
                stage_id=MediathekStage.SCAN_COMPLETED,
                message=f"{len(all_paths)} Pfade prüfen",
            ))

        raw_issues: list[NameIssue] = check_paths(all_paths)
        issues = [
            NameCheckIssue(path=i.path, tags=list(i.tags), details=list(i.details))
            for i in raw_issues
        ]

        return CheckNamesResult(
            success=True,
            total_checked=len(all_paths),
            issues=issues,
        )

    except Exception as e:
        return CheckNamesResult(success=False, error_message=str(e))


def _extract_embedded_covers(
    backend,
    videos: list[VideoMetadata],
    output_root: Path,
    runtime: RuntimeOptions,
    on_event: Callable[[MediathekEvent], None] | None,
) -> None:
    """Extrahiert eingebettete ``attached_pic``-Atome als Poster-Fallback.

    Läuft **nur** für Videos, die:
    1. einen ``attached_pic``-Stream im Header tragen (aus ffprobe bekannt), und
    2. noch kein ``{stem}-poster.jpg``-Sidecar haben.

    **Idempotenz**: Wenn die Ziel-JPG-Datei bereits existiert und mindestens
    so jung ist wie das Quellvideo, wird die Extraktion übersprungen.

    Schlägt die Extraktion fehl (fehlender ffmpeg, Timeout), wird das Video
    weiterhin mit einer Platzhalter-Card gerendert — kein Abbruch.
    """
    candidates = [
        v for v in videos
        if v.embedded_cover_stream_index is not None and v.poster_sidecar is None
    ]
    if not candidates:
        return

    source_root: Path | None = getattr(backend, "root_path", None)
    if not isinstance(source_root, Path):
        source_root = None

    embedded_dir_rel = PurePosixPath("mediathek/embedded-poster")
    total = len(candidates)
    for i, video in enumerate(candidates, start=1):
        layout_posix = PurePosixPath(video.layout_path)
        rel_poster = embedded_dir_rel / layout_posix.with_suffix(".jpg")
        out_local = output_root / rel_poster

        # Idempotenz-Check: bereits extrahiertes Cover ist aktuell genug.
        if source_root is not None and _cached_cover_is_fresh(
            source_root / video.relative_path, out_local
        ):
            video.poster_sidecar = str(rel_poster)
            continue

        if on_event:
            on_event(MediathekEvent(
                stage_id=MediathekStage.COVER_EXTRACTING,
                message=f"Extrahiere Cover: {layout_posix.name}",
                current=i,
                total=total,
            ))

        try:
            ok = backend.extract_attached_pic(
                video.relative_path,
                int(video.embedded_cover_stream_index),
                out_local,
                runtime,
            )
        except Exception:  # noqa: BLE001 — Cover-Extraktion darf Lauf nicht killen
            ok = False

        if ok:
            video.poster_sidecar = str(rel_poster)


def _cached_cover_is_fresh(source_video: Path, cached_cover: Path) -> bool:
    """Prüft, ob ein bereits extrahiertes Cover noch gültig ist."""
    try:
        if not cached_cover.exists():
            return False
        return cached_cover.stat().st_mtime >= source_video.stat().st_mtime
    except OSError:
        return False
