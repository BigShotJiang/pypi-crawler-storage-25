"""CLI-Adapter für den Mediathek Manager."""

from pathlib import Path

import typer
from rich.console import Console

from ..api import (
    CheckNamesRequest,
    GenerateLibraryRequest,
    MediathekEvent,
    RuntimeOptions,
    ScanLibraryRequest,
    check_names,
    generate_library,
    scan_library,
)
from ..services.config_manager import load_config

app = typer.Typer(invoke_without_command=True)
stderr_console = Console(stderr=True)

config_app = typer.Typer()
app.add_typer(config_app, name="config", help="Konfiguration verwalten.")


@app.callback()
def main():
    """Mediathek Manager – Generiert statische HTML-Bibliotheken aus Videodateien."""


@app.command(name="generate")
def generate_cmd(
    source_path: str = typer.Argument(..., help="Verzeichnis mit Videodateien (lokal oder SMB-Mount)"),
    title: str | None = typer.Option(None, "--title", help="Bibliothekstitel (Fallback: Ordnername)"),
    recursive: bool = typer.Option(True, "--recursive/--no-recursive", help="Unterverzeichnisse einbeziehen"),
    show_card_titles: bool = typer.Option(
        False,
        "--show-card-titles",
        help="Zeigt den Video-Titel zusätzlich als Textzeile unter jeder "
             "Grid-Card (Default: aus, weil das Poster den Titel bereits trägt).",
    ),
    output: str | None = typer.Option(
        None,
        "--output", "-o",
        help="Separater Ausgabepfad für die HTML-Bibliothek (Default: neben den Videos).",
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Detaillierte Ausgabe auf stderr"),
):
    """Generiert eine statische HTML-Bibliothek."""
    cfg = load_config()
    runtime = RuntimeOptions(
        ffprobe_path=cfg.get("tools.ffprobe_path", "ffprobe"),
        ffmpeg_path=cfg.get("tools.ffmpeg_path", "ffmpeg"),
    )

    def on_event(event: MediathekEvent) -> None:
        label = f" [{event.current}/{event.total}]" if event.current is not None else ""
        stderr_console.print(f"  {event.message}{label}")

    request = GenerateLibraryRequest(
        source_path=source_path,
        recursive=recursive,
        title=title,
        show_card_titles=show_card_titles,
        output_path=output,
    )
    result = generate_library(
        request,
        runtime,
        on_event=on_event if verbose else _minimal_event_handler,
    )

    if not result.success:
        stderr_console.print(f"[red]Fehler:[/red] {result.error_message}")
        raise typer.Exit(code=1)

    if verbose and (result.cache_hits or result.cache_misses):
        stderr_console.print(
            f"  Cache: [bold]{result.cache_hits}[/bold] Hits, "
            f"[bold]{result.cache_misses}[/bold] Misses"
        )

    # stdout: maschinenlesbarer Pfad zum Root-Index
    if result.output_dir:
        print(result.output_dir / "index.html")
    else:
        print(f"{source_path}/index.html")


@app.command(name="scan")
def scan_cmd(
    source_path: str = typer.Argument(..., help="Verzeichnis mit Videodateien (lokal oder SMB-Mount)"),
    recursive: bool = typer.Option(True, "--recursive/--no-recursive", help="Unterverzeichnisse einbeziehen"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Detaillierte Ausgabe auf stderr"),
):
    """Scannt ein Verzeichnis und zeigt gefundene Videos mit Metadaten."""
    cfg = load_config()
    runtime = RuntimeOptions(
        ffprobe_path=cfg.get("tools.ffprobe_path", "ffprobe"),
        ffmpeg_path=cfg.get("tools.ffmpeg_path", "ffmpeg"),
    )

    def on_event(event: MediathekEvent) -> None:
        label = f" [{event.current}/{event.total}]" if event.current is not None else ""
        stderr_console.print(f"  {event.message}{label}")

    request = ScanLibraryRequest(
        source_path=source_path,
        recursive=recursive,
    )
    result = scan_library(
        request,
        runtime,
        on_event=on_event if verbose else None,
    )

    if not result.success:
        stderr_console.print(f"[red]Fehler:[/red] {result.error_message}")
        raise typer.Exit(code=1)

    stderr_console.print(f"\n[bold]{len(result.videos)} Videos gefunden[/bold]\n")

    for video in result.videos:
        stderr_console.print(f"  [bold]{video.title}[/bold]")
        if video.album:
            stderr_console.print(f"    Album: {video.album}")
        if video.genre:
            stderr_console.print(f"    Genre: {video.genre}")
        if video.tags:
            stderr_console.print(f"    Tags: {', '.join(video.tags)}")
        if video.duration_seconds:
            minutes = int(video.duration_seconds // 60)
            stderr_console.print(f"    Dauer: {minutes} Min.")
        if video.chapters:
            stderr_console.print(f"    Kapitel: {len(video.chapters)}")
        stderr_console.print()


@app.command(name="check-names")
def check_names_cmd(
    source_path: str = typer.Argument(..., help="Verzeichnis (lokal oder SMB-Mount)"),
    recursive: bool = typer.Option(True, "--recursive/--no-recursive", help="Unterverzeichnisse einbeziehen"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Detaillierte Ausgabe auf stderr"),
):
    """Prüft Dateinamen auf SMB/URL/APFS-Kompatibilität (Read-only-Diagnose).

    Meldet NFD-Unicode (macOS-Dekomposition), URL-reservierte Zeichen wie
    ``#?&+%`` (brechen ``file://``-Links), Windows-/SMB-verbotene Zeichen,
    Überlängen, führende/abschließende Whitespaces, Windows-reservierte
    Basenamen und Groß-/Kleinschreibungs-Kollisionen. Der Mediathek Manager
    verändert niemals Quelldateien — das Werkzeug liefert die Liste, die
    Umbenennung bleibt beim Nutzer (z. B. ``convmv --nfc`` für NFD→NFC).

    Exit-Code 1, wenn Auffälligkeiten gefunden wurden; sonst 0.
    """
    cfg = load_config()
    runtime = RuntimeOptions(
        ffprobe_path=cfg.get("tools.ffprobe_path", "ffprobe"),
        ffmpeg_path=cfg.get("tools.ffmpeg_path", "ffmpeg"),
    )

    def on_event(event: MediathekEvent) -> None:
        stderr_console.print(f"  {event.message}")

    request = CheckNamesRequest(
        source_path=source_path,
        recursive=recursive,
    )
    result = check_names(
        request,
        runtime,
        on_event=on_event if verbose else None,
    )

    if not result.success:
        stderr_console.print(f"[red]Fehler:[/red] {result.error_message}")
        raise typer.Exit(code=1)

    stderr_console.print(
        f"\n[bold]{result.total_checked}[/bold] Pfade geprüft — "
        f"[bold]{len(result.issues)}[/bold] Auffälligkeiten\n"
    )

    if not result.issues:
        stderr_console.print("[green]Keine Probleme gefunden.[/green]")
        return

    # Tabellarische Ausgabe auf stdout (maschinenlesbar), Details auf stderr.
    # Format: ``[TAGS] path`` mit linksbündigen Tags in fixer Breite.
    tag_col_width = 28
    for issue in result.issues:
        tag_str = " ".join(issue.tags)
        tag_cell = f"[{tag_str}]".ljust(tag_col_width)
        print(f"{tag_cell} {issue.path}")
        for detail in issue.details:
            stderr_console.print(f"    [dim]{detail}[/dim]")

    # Legende nur im Verbose-Modus — sonst nimmt sie die Sicht auf die Liste.
    if verbose:
        stderr_console.print(
            "\n[dim]Legende: "
            "NFD=dekomponierte Umlaute · "
            "URL=file://-brechende Zeichen (#?&+%) · "
            "WIN=Windows-verbotene Zeichen · "
            "LEN=Pfad >240 Zeichen · "
            "TRIM=führendes/abschließendes Leerzeichen/Punkt · "
            "RSVD=Windows-Device-Name · "
            "CASE=Groß-/Kleinschreibungs-Kollision"
            "[/dim]"
        )

    raise typer.Exit(code=1)


@config_app.command(name="list")
def config_list():
    """Zeigt alle Konfigurationseinstellungen."""
    cfg = load_config()
    for key, value in cfg.items():
        stderr_console.print(f"  {key} = {value}")


@config_app.command(name="set")
def config_set(
    key: str = typer.Argument(..., help="Konfigurationsschlüssel (z.B. tools.ffprobe_path)"),
    value: str = typer.Argument(..., help="Wert"),
):
    """Setzt einen Konfigurationswert."""
    from ..services.config_manager import set_config
    set_config(key, value)
    stderr_console.print(f"  {key} = {value}")


@config_app.command(name="get")
def config_get(
    key: str = typer.Argument(..., help="Konfigurationsschlüssel"),
):
    """Zeigt einen Konfigurationswert."""
    cfg = load_config()
    value = cfg.get(key)
    if value is None:
        stderr_console.print(f"[yellow]Nicht gesetzt:[/yellow] {key}")
        raise typer.Exit(code=1)
    print(value)


@app.command(name="serve")
def serve_cmd(
    directory: str = typer.Argument(
        ...,
        help="Verzeichnis mit der generierten Mediathek (enthält index.html und mediathek/).",
    ),
    port: int = typer.Option(8080, "--port", "-p", help="HTTP-Port"),
    host: str = typer.Option(
        "0.0.0.0",
        "--host",
        help="Bind-Adresse (0.0.0.0 = alle Interfaces, 127.0.0.1 = nur lokal).",
    ),
    no_open: bool = typer.Option(False, "--no-open", help="Browser nicht automatisch öffnen"),
):
    """Startet einen lokalen Webserver für die Mediathek.

    Löst das ``file://``-Problem: Safari blockiert bei ``file://``-URLs den
    Cross-Origin-Zugriff auf Sub-Ressourcen (Videos, Fanart) wenn Source und
    Output in unterschiedlichen Pfadbäumen liegen. Über HTTP wird der
    ``_videos``-Symlink (erstellt von ``generate --output``) transparent
    aufgelöst — alle Videos spielen ab, alle Poster laden.

    Auch ohne ``--output`` nützlich: HTTP-Serving umgeht sämtliche
    ``file://``-Probleme mit NFD-Unicode, URL-reservierten Zeichen und
    Safari-Sicherheitsrestriktionen.
    """
    import webbrowser
    from http.server import HTTPServer, SimpleHTTPRequestHandler

    root = Path(directory).resolve()
    if not (root / "index.html").exists():
        stderr_console.print(
            f"[red]Fehler:[/red] {root / 'index.html'} nicht gefunden. "
            "Bitte zuerst ``mediathek-manager generate`` ausführen."
        )
        raise typer.Exit(code=1)

    class _QuietHandler(SimpleHTTPRequestHandler):
        """Unterdrückt BrokenPipeError-Tracebacks in der Konsole.

        Safari (und andere Browser) schliessen HTTP-Verbindungen abrupt
        beim Seek im Video oder bei Navigation weg von der Seite. Das
        erzeugt einen ``BrokenPipeError`` im ``shutil.copyfileobj`` des
        stdlib-Handlers, der einen hässlichen Traceback auf stderr druckt.
        Da das Verhalten normal und harmlos ist, fangen wir es ab.
        """

        def __init__(self, *args, **kwargs):
            super().__init__(*args, directory=str(root), **kwargs)

        def handle(self):
            try:
                super().handle()
            except BrokenPipeError:
                pass

        def log_message(self, format, *args):
            # Nur Fehler loggen, nicht jeden einzelnen Request
            pass

    server = HTTPServer((host, port), _QuietHandler)

    # Für die Browser-URL und die Anzeige: bei 0.0.0.0 die lokale IP
    # anzeigen, damit der Nutzer die URL direkt aufs iPhone kopieren kann.
    if host == "0.0.0.0":
        import socket
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            local_ip = s.getsockname()[0]
            s.close()
        except OSError:
            local_ip = "127.0.0.1"
        url = f"http://127.0.0.1:{port}/"
        stderr_console.print(f"  Mediathek wird serviert: [bold]{url}[/bold]")
        stderr_console.print(f"  Im Netzwerk erreichbar:  [bold]http://{local_ip}:{port}/[/bold]")
    else:
        url = f"http://{host}:{port}/"
        stderr_console.print(f"  Mediathek wird serviert: [bold]{url}[/bold]")
    stderr_console.print(f"  Verzeichnis: {root}")
    stderr_console.print("  Ctrl+C zum Beenden\n")

    if not no_open:
        webbrowser.open(url)

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        stderr_console.print("\n  Server beendet.")
        server.server_close()


def _minimal_event_handler(event: MediathekEvent) -> None:
    """Zeigt nur Meilenstein-Events auf stderr."""
    from ..api.models import MediathekStage
    if event.stage_id in (
        MediathekStage.SCAN_COMPLETED,
        MediathekStage.LIBRARY_COMPLETED,
    ):
        stderr_console.print(f"  {event.message}")
