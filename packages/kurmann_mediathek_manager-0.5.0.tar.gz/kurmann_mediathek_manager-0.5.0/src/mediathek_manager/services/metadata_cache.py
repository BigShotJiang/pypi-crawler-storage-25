"""Metadaten-Cache: persistiert ffprobe-Ergebnisse zwischen generate-Läufen.

Der Mediathek Manager ruft ffprobe für jedes Video auf — bei grossen
Bibliotheken über SMB ist das die dominierende Laufzeit. Dieser Cache
speichert die extrahierten ``VideoMetadata`` als JSON und überspringt
die Extraktion, wenn sich weder das Video noch seine Sidecars seit dem
letzten Lauf verändert haben.

**Invalidierung** (Cache-Key):
  - ``video_mtime`` + ``video_size`` — erkennt Re-Encoding, Ersetzung
  - ``sidecar_mtimes`` für ``{stem}.yaml``, ``{stem}.nfo``,
    ``{stem}-poster.jpg``, ``{stem}-fanart.jpg`` — erkennt Sidecar-
    Änderungen unabhängig vom Video

**Atomizität**: Der Cache wird nach der Extraktionsschleife in einem
Schritt geschrieben (``tempfile`` + ``os.replace``). Bei Abbruch
bleibt die alte Datei intakt; der nächste Lauf profitiert von allen
bisherigen Einträgen.

**Löschbar**: Der Cache ist ein Hilfsmittel. Löscht man die Datei,
extrahiert der nächste Lauf alles neu — die HTML-Dateien sind das
eigentliche Archiv.
"""

from __future__ import annotations

import json
import os
import tempfile
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path, PurePosixPath
from typing import TYPE_CHECKING

from ..api.models import Chapter, VideoMetadata

if TYPE_CHECKING:
    from .storage import StorageBackend

_CACHE_VERSION = 1
_CACHE_FILENAME = "mediathek/.metadata-cache.json"

# Sidecar-Suffixe, die als Teil des Cache-Keys geprüft werden.
_SIDECAR_SUFFIXES = (".yaml", ".nfo", "-poster.jpg", "-fanart.jpg")


@dataclass
class CacheEntry:
    """Ein gecachter Metadaten-Eintrag mit zugehörigem Invalidierungs-Key."""

    video_mtime: float
    video_size: int
    sidecar_mtimes: dict[str, float | None] = field(default_factory=dict)
    metadata: dict = field(default_factory=dict)


class MetadataCache:
    """In-Memory-Repräsentation des Metadaten-Caches.

    Typischer Lifecycle::

        cache = MetadataCache.load(cache_path)       # oder load_from_text()
        for video_path in video_paths:
            key = compute_cache_key(backend, video_path)
            cached = cache.get(video_path, key)
            if cached is not None:
                videos.append(cached)
            else:
                metadata = extract_metadata(...)
                cache.put(video_path, key, metadata)
                videos.append(metadata)
        cache.prune(set(video_paths))
        cache.save(cache_path)
    """

    def __init__(self) -> None:
        self._entries: dict[str, CacheEntry] = {}

    @classmethod
    def load(cls, path: Path) -> MetadataCache:
        """Lädt den Cache von einer lokalen JSON-Datei.

        Gibt einen leeren Cache zurück bei: fehlender Datei, JSON-Parse-
        Fehler, unbekannter Version — fail-safe, nie Exception.
        """
        cache = cls()
        try:
            text = path.read_text(encoding="utf-8")
            return cls._from_json(text)
        except (OSError, ValueError, KeyError, TypeError):
            return cache

    @classmethod
    def load_from_text(cls, text: str) -> MetadataCache:
        """Lädt den Cache aus einem JSON-String (z. B. via ``backend.read_text``).

        Gleiche Fehlertoleranz wie ``load()`` — gibt bei jedem Problem
        einen leeren Cache zurück.
        """
        try:
            return cls._from_json(text)
        except (ValueError, KeyError, TypeError):
            return cls()

    @classmethod
    def _from_json(cls, text: str) -> MetadataCache:
        data = json.loads(text)
        if data.get("version") != _CACHE_VERSION:
            return cls()
        cache = cls()
        for rel_path, entry_dict in data.get("entries", {}).items():
            cache._entries[rel_path] = CacheEntry(
                video_mtime=entry_dict["video_mtime"],
                video_size=entry_dict["video_size"],
                sidecar_mtimes=entry_dict.get("sidecar_mtimes", {}),
                metadata=entry_dict.get("metadata", {}),
            )
        return cache

    def get(
        self,
        relative_path: str,
        key: CacheEntry,
    ) -> VideoMetadata | None:
        """Gibt gecachte Metadaten zurück, wenn der Key exakt matcht.

        Prüft ``video_mtime``, ``video_size`` und alle ``sidecar_mtimes``.
        Jede Abweichung → ``None`` (Cache-Miss).
        """
        entry = self._entries.get(relative_path)
        if entry is None:
            return None
        if entry.video_mtime != key.video_mtime:
            return None
        if entry.video_size != key.video_size:
            return None
        if entry.sidecar_mtimes != key.sidecar_mtimes:
            return None
        return deserialize_metadata(entry.metadata)

    def put(
        self,
        relative_path: str,
        key: CacheEntry,
        metadata: VideoMetadata,
    ) -> None:
        """Speichert Metadaten unter dem gegebenen Key."""
        self._entries[relative_path] = CacheEntry(
            video_mtime=key.video_mtime,
            video_size=key.video_size,
            sidecar_mtimes=dict(key.sidecar_mtimes),
            metadata=serialize_metadata(metadata),
        )

    def prune(self, current_paths: set[str]) -> int:
        """Entfernt Einträge, deren Pfade nicht mehr in der aktuellen
        Videoliste vorkommen (gelöschte Videos). Gibt die Anzahl
        entfernter Einträge zurück.
        """
        stale = [p for p in self._entries if p not in current_paths]
        for p in stale:
            del self._entries[p]
        return len(stale)

    def save(self, path: Path) -> None:
        """Schreibt den Cache atomar auf Disk.

        Strategie: in ein Tempfile im selben Verzeichnis schreiben,
        dann ``os.replace`` (atomar auf POSIX und NTFS). Bei Abbruch
        vor dem Replace bleibt die alte Datei intakt.
        """
        data = {
            "version": _CACHE_VERSION,
            "entries": {
                rel_path: {
                    "video_mtime": entry.video_mtime,
                    "video_size": entry.video_size,
                    "sidecar_mtimes": entry.sidecar_mtimes,
                    "metadata": entry.metadata,
                }
                for rel_path, entry in self._entries.items()
            },
        }
        path.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp_path = tempfile.mkstemp(
            dir=path.parent, suffix=".tmp", prefix=".cache-"
        )
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=None)
            os.replace(tmp_path, path)
        except BaseException:
            # Tempfile aufräumen bei jedem Fehler (inkl. KeyboardInterrupt)
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
            raise

    def to_json(self) -> str:
        """Serialisiert den Cache als JSON-String."""
        data = {
            "version": _CACHE_VERSION,
            "entries": {
                rel_path: {
                    "video_mtime": entry.video_mtime,
                    "video_size": entry.video_size,
                    "sidecar_mtimes": entry.sidecar_mtimes,
                    "metadata": entry.metadata,
                }
                for rel_path, entry in self._entries.items()
            },
        }
        return json.dumps(data, ensure_ascii=False)

    def __len__(self) -> int:
        return len(self._entries)


# ---------------------------------------------------------------------------
# Cache-Key-Berechnung
# ---------------------------------------------------------------------------


def compute_cache_key(
    backend: StorageBackend,
    relative_path: str,
) -> CacheEntry | None:
    """Berechnet den Cache-Key für ein Video anhand von mtime/size des
    Videos und aller bekannten Sidecars.

    Gibt ``None`` zurück, wenn ``backend.file_stat()`` für das Video
    selbst fehlschlägt (Datei nicht erreichbar → kein Caching möglich).
    """
    stat = backend.file_stat(relative_path)
    if stat is None:
        return None
    video_mtime, video_size = stat

    # Sidecar-mtimes sammeln
    stem = PurePosixPath(relative_path).stem
    parent = str(PurePosixPath(relative_path).parent)
    if parent == ".":
        parent = ""

    sidecar_mtimes: dict[str, float | None] = {}
    for suffix in _SIDECAR_SUFFIXES:
        sidecar_name = f"{stem}{suffix}"
        sidecar_path = f"{parent}/{sidecar_name}" if parent else sidecar_name
        sidecar_stat = backend.file_stat(sidecar_path)
        sidecar_mtimes[sidecar_path] = sidecar_stat[0] if sidecar_stat else None

    return CacheEntry(
        video_mtime=video_mtime,
        video_size=video_size,
        sidecar_mtimes=sidecar_mtimes,
    )


# ---------------------------------------------------------------------------
# VideoMetadata ↔ dict Serialisierung
# ---------------------------------------------------------------------------


def serialize_metadata(vm: VideoMetadata) -> dict:
    """Konvertiert eine ``VideoMetadata``-Instanz in ein JSON-fähiges dict."""
    return {
        "relative_path": vm.relative_path,
        "title": vm.title,
        "artist": vm.artist,
        "album": vm.album,
        "genre": vm.genre,
        "tags": vm.tags,
        "description": vm.description,
        "long_description": vm.long_description,
        "chapters": [
            {"title": ch.title, "start_seconds": ch.start_seconds}
            for ch in vm.chapters
        ],
        "content_create_date": (
            vm.content_create_date.isoformat() if vm.content_create_date else None
        ),
        "duration_seconds": vm.duration_seconds,
        "resolution": vm.resolution,
        "bitrate": vm.bitrate,
        "comment": vm.comment,
        "poster_sidecar": vm.poster_sidecar,
        "fanart_sidecar": vm.fanart_sidecar,
        "display_path": vm.display_path,
        "embedded_cover_stream_index": vm.embedded_cover_stream_index,
    }


def deserialize_metadata(d: dict) -> VideoMetadata:
    """Baut eine ``VideoMetadata``-Instanz aus einem Cache-dict."""
    date_str = d.get("content_create_date")
    content_create_date = None
    if date_str:
        try:
            content_create_date = datetime.fromisoformat(date_str)
        except (ValueError, TypeError):
            pass

    chapters = [
        Chapter(title=ch["title"], start_seconds=ch["start_seconds"])
        for ch in d.get("chapters", [])
    ]

    return VideoMetadata(
        relative_path=d["relative_path"],
        title=d.get("title", ""),
        artist=d.get("artist"),
        album=d.get("album"),
        genre=d.get("genre"),
        tags=d.get("tags", []),
        description=d.get("description"),
        long_description=d.get("long_description"),
        chapters=chapters,
        content_create_date=content_create_date,
        duration_seconds=d.get("duration_seconds"),
        resolution=d.get("resolution"),
        bitrate=d.get("bitrate"),
        comment=d.get("comment"),
        poster_sidecar=d.get("poster_sidecar"),
        fanart_sidecar=d.get("fanart_sidecar"),
        display_path=d.get("display_path"),
        embedded_cover_stream_index=d.get("embedded_cover_stream_index"),
    )


def cache_file_path(output_root: Path) -> Path:
    """Gibt den kanonischen Pfad der Cache-Datei zurück."""
    return output_root / _CACHE_FILENAME
