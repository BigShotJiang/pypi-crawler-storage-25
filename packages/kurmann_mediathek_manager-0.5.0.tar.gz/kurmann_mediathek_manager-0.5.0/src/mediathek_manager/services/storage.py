"""Dateizugriff über das lokale Dateisystem (pathlib).

Der Mediathek Manager arbeitet ausschließlich mit lokal erreichbaren Pfaden —
das schließt SMB-/NFS-/FUSE-Mounts ein, die im Finder oder via ``mount``
eingehängt sind. rclone-Remotes werden seit v0.4.0 nicht mehr unterstützt;
stattdessen empfiehlt sich ein SMB-Mount (z. B. ``/Volumes/NAS-Share``).
"""

from __future__ import annotations

import subprocess
from pathlib import Path, PurePosixPath

from ..api.models import RuntimeOptions


VIDEO_EXTENSIONS = {".m4v", ".mp4", ".mkv", ".mov", ".avi", ".webm"}


class LocalBackend:
    """Dateizugriff über das lokale Dateisystem (pathlib).

    Unterstützt jedes vom OS gemountete Volume — lokale Platten, SMB-Shares
    (``/Volumes/…``), NFS, FUSE-Mounts. Seek-fähig: ffprobe liest nur den
    Header statt die ganze Datei zu streamen.
    """

    def __init__(self, root: Path) -> None:
        self._root = Path(root)

    @property
    def root_name(self) -> str:
        return self._root.name

    @property
    def root_path(self) -> Path:
        return self._root

    def list_videos(self, recursive: bool = False) -> list[str]:
        videos: list[str] = []
        if recursive:
            for ext in VIDEO_EXTENSIONS:
                for path in self._root.rglob(f"*{ext}"):
                    try:
                        videos.append(str(path.relative_to(self._root)))
                    except (OSError, ValueError):
                        pass
        else:
            try:
                for item in self._root.iterdir():
                    try:
                        if item.is_file() and item.suffix.lower() in VIDEO_EXTENSIONS:
                            videos.append(item.name)
                    except OSError:
                        pass
            except OSError:
                pass
        return sorted(videos, key=str.lower)

    def list_subdirectories(self) -> list[str]:
        try:
            return sorted(
                [d.name for d in self._root.iterdir()
                 if d.is_dir() and not d.name.startswith(".")],
                key=str.lower,
            )
        except OSError:
            return []

    def file_exists(self, relative_path: str) -> bool:
        try:
            return (self._root / relative_path).exists()
        except OSError:
            return False

    def file_stat(self, relative_path: str) -> tuple[float, int] | None:
        try:
            st = (self._root / relative_path).stat()
            return (st.st_mtime, st.st_size)
        except OSError:
            return None

    def read_text(self, relative_path: str, encoding: str = "utf-8") -> str:
        return (self._root / relative_path).read_text(encoding=encoding)

    def run_ffprobe(self, relative_path: str, runtime: RuntimeOptions) -> str:
        file_path = self._root / relative_path
        try:
            result = subprocess.run(
                [
                    runtime.ffprobe_path,
                    "-v", "quiet",
                    "-print_format", "json",
                    "-show_format",
                    "-show_streams",
                    "-show_chapters",
                    str(file_path),
                ],
                capture_output=True,
                text=True,
                timeout=30,
            )
            return result.stdout
        except (subprocess.TimeoutExpired, FileNotFoundError):
            return ""

    def extract_attached_pic(
        self,
        relative_path: str,
        stream_index: int,
        output_local: Path,
        runtime: RuntimeOptions,
    ) -> bool:
        file_path = self._root / relative_path
        output_local.parent.mkdir(parents=True, exist_ok=True)
        try:
            result = subprocess.run(
                [
                    runtime.ffmpeg_path,
                    "-nostdin",
                    "-loglevel", "error",
                    "-y",
                    "-i", str(file_path),
                    "-map", f"0:{stream_index}",
                    "-frames:v", "1",
                    "-c", "copy",
                    str(output_local),
                ],
                capture_output=True,
                timeout=30,
            )
            return result.returncode == 0 and output_local.exists()
        except (subprocess.SubprocessError, FileNotFoundError, OSError):
            return False
