"""Configuration management for AITrendRadar."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


DEFAULT_OUTPUT_DIR = Path(__file__).resolve().parent.parent / "output"
DEFAULT_DB_PATH = str(DEFAULT_OUTPUT_DIR / "trends.db")


@dataclass
class Config:
    """Application configuration."""
    output_dir: Path = DEFAULT_OUTPUT_DIR
    db_path: str = DEFAULT_DB_PATH
    github_api_url: str = "https://api.github.com"
    hackernews_api_url: str = "https://hacker-news.firebaseio.com/v0"
    devto_api_url: str = "https://dev.to/api"
    request_timeout: int = 30
    rate_limit_delay: float = 1.0
    max_retries: int = 3
    github_token: str = ""
    max_items_per_source: int = 30
    hype_weights: dict[str, float] = field(default_factory=lambda: {
        "stars": 0.30,
        "score": 0.25,
        "comments": 0.20,
        "velocity": 0.15,
        "recency": 0.10,
    })

    @classmethod
    def from_env(cls) -> Config:
        """Load configuration from environment variables."""
        output_dir = Path(os.environ.get("TRENDRADAR_OUTPUT_DIR", str(DEFAULT_OUTPUT_DIR)))
        return cls(
            output_dir=output_dir,
            db_path=os.environ.get("TRENDRADAR_DB_PATH", str(output_dir / "trends.db")),
            github_token=os.environ.get("GITHUB_TOKEN", ""),
            request_timeout=int(os.environ.get("TRENDRADAR_TIMEOUT", "30")),
            rate_limit_delay=float(os.environ.get("TRENDRADAR_RATE_LIMIT", "1.0")),
            max_retries=int(os.environ.get("TRENDRADAR_MAX_RETRIES", "3")),
            max_items_per_source=int(os.environ.get("TRENDRADAR_MAX_ITEMS", "30")),
        )


_config: Config | None = None


def get_config() -> Config:
    """Get the global configuration, initializing from env if needed."""
    global _config
    if _config is None:
        _config = Config.from_env()
    return _config


def set_config(cfg: Config) -> None:
    """Override the global configuration."""
    global _config
    _config = cfg
