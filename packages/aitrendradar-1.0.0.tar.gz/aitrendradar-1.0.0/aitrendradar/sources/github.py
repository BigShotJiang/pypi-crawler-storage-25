"""GitHub trending repositories source."""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any

from ..models import Category, Source, TrendItem
from .base import BaseSource

logger = logging.getLogger(__name__)

# Language to category mapping
LANG_CATEGORIES: dict[str, Category] = {
    "python": Category.AI_ML,
    "typescript": Category.WEB,
    "javascript": Category.WEB,
    "rust": Category.LANGUAGES,
    "go": Category.LANGUAGES,
    "java": Category.LANGUAGES,
    "kotlin": Category.MOBILE,
    "swift": Category.MOBILE,
    "dart": Category.MOBILE,
    "c++": Category.LANGUAGES,
    "c": Category.LANGUAGES,
    "c#": Category.LANGUAGES,
    "ruby": Category.WEB,
    "php": Category.WEB,
    "scala": Category.LANGUAGES,
    "shell": Category.DEVOPS,
    "dockerfile": Category.DEVOPS,
    "jupyter notebook": Category.DATA_SCIENCE,
}

# Keyword to category mapping for repos without clear language signals
KEYWORD_CATEGORIES: dict[str, Category] = {
    "machine-learning": Category.AI_ML,
    "deep-learning": Category.AI_ML,
    "neural-network": Category.AI_ML,
    "ai": Category.AI_ML,
    "llm": Category.AI_ML,
    "gpt": Category.AI_ML,
    "transformer": Category.AI_ML,
    "nlp": Category.AI_ML,
    "computer-vision": Category.AI_ML,
    "reinforcement-learning": Category.AI_ML,
    "diffusion": Category.AI_ML,
    "react": Category.WEB,
    "vue": Category.WEB,
    "angular": Category.WEB,
    "nextjs": Category.WEB,
    "svelte": Category.WEB,
    "tailwind": Category.WEB,
    "graphql": Category.WEB,
    "frontend": Category.WEB,
    "backend": Category.WEB,
    "api": Category.WEB,
    "docker": Category.DEVOPS,
    "kubernetes": Category.DEVOPS,
    "k8s": Category.DEVOPS,
    "terraform": Category.DEVOPS,
    "ci-cd": Category.DEVOPS,
    "devops": Category.DEVOPS,
    "monitoring": Category.DEVOPS,
    "observability": Category.DEVOPS,
    "security": Category.SECURITY,
    "vulnerability": Category.SECURITY,
    "encryption": Category.SECURITY,
    "authentication": Category.SECURITY,
    "blockchain": Category.BLOCKCHAIN,
    "crypto": Category.BLOCKCHAIN,
    "smart-contract": Category.BLOCKCHAIN,
    "defi": Category.BLOCKCHAIN,
    "database": Category.DATABASES,
    "sql": Category.DATABASES,
    "postgres": Category.DATABASES,
    "mongodb": Category.DATABASES,
    "redis": Category.DATABASES,
    "android": Category.MOBILE,
    "ios": Category.MOBILE,
    "flutter": Category.MOBILE,
    "react-native": Category.MOBILE,
    "game": Category.GAMING,
    "unity": Category.GAMING,
    "unreal": Category.GAMING,
    "godot": Category.GAMING,
    "cloud": Category.CLOUD,
    "aws": Category.CLOUD,
    "azure": Category.CLOUD,
    "gcp": Category.CLOUD,
    "serverless": Category.CLOUD,
    "data-science": Category.DATA_SCIENCE,
    "analytics": Category.DATA_SCIENCE,
    "visualization": Category.DATA_SCIENCE,
}


class GitHubSource(BaseSource):
    """Fetches trending GitHub repositories via the GitHub Search API."""

    name = "github"

    def __init__(self) -> None:
        super().__init__()
        if self.config.github_token:
            self.session.headers["Authorization"] = f"token {self.config.github_token}"

    def fetch(self, since: str = "weekly", language: str = "", max_items: int | None = None) -> list[TrendItem]:
        """Fetch trending GitHub repos.

        Args:
            since: Time range - 'daily', 'weekly', 'monthly'.
            language: Filter by programming language.
            max_items: Override max items to fetch.
        """
        limit = max_items or self.config.max_items_per_source
        items: list[TrendItem] = []

        date_ranges = {
            "daily": 1,
            "weekly": 7,
            "monthly": 30,
        }
        days = date_ranges.get(since, 7)

        # Use GitHub Search API to find trending repos
        repos = self._search_trending(days=days, language=language, limit=limit)
        for repo_data in repos:
            item = self._parse_repo(repo_data)
            if item:
                items.append(item)

        logger.info("GitHub: fetched %d trending repos (since=%s)", len(items), since)
        return items

    def _search_trending(self, days: int, language: str, limit: int) -> list[dict[str, Any]]:
        """Search for recently created or pushed repos with high stars."""
        from datetime import datetime, timedelta

        since_date = (datetime.utcnow() - timedelta(days=days)).strftime("%Y-%m-%d")
        results: list[dict[str, Any]] = []

        # Strategy 1: Repos created recently, sorted by stars
        query_parts = [f"created:>{since_date}", "fork:false", "is:public"]
        if language:
            query_parts.append(f"language:{language}")
        query = " ".join(query_parts)

        data = self._make_request(
            f"{self.config.github_api_url}/search/repositories",
            params={
                "q": query,
                "sort": "stars",
                "order": "desc",
                "per_page": min(limit, 100),
            },
        )

        if data and isinstance(data, dict):
            results.extend(data.get("items", []))

        # Strategy 2: Popular repos with recent pushes (for established trending)
        if len(results) < limit:
            query2_parts = [f"pushed:>{since_date}", "stars:>100", "fork:false"]
            if language:
                query2_parts.append(f"language:{language}")
            query2 = " ".join(query2_parts)

            data2 = self._make_request(
                f"{self.config.github_api_url}/search/repositories",
                params={
                    "q": query2,
                    "sort": "stars",
                    "order": "desc",
                    "per_page": min(limit - len(results), 50),
                },
            )
            if data2 and isinstance(data2, dict):
                existing_ids = {r.get("id") for r in results}
                for repo in data2.get("items", []):
                    if repo.get("id") not in existing_ids:
                        results.append(repo)

        return results[:limit]

    def _parse_repo(self, data: dict[str, Any]) -> TrendItem | None:
        """Parse a GitHub API repo response into a TrendItem."""
        if not data:
            return None

        url = data.get("html_url", "")
        title = data.get("full_name", data.get("name", ""))
        description = self.sanitize_text(data.get("description") or "")
        language = (data.get("language") or "").lower()
        stars = data.get("stargazers_count", 0)
        forks = data.get("forks_count", 0)
        watchers = data.get("watchers_count", 0)
        open_issues = data.get("open_issues_count", 0)
        author = (data.get("owner", {}) or {}).get("login", "")
        topics = data.get("topics", [])

        created_at = None
        if data.get("created_at"):
            try:
                created_at = datetime.fromisoformat(
                    data["created_at"].replace("Z", "+00:00")
                )
            except (ValueError, AttributeError):
                pass

        category = self._categorize(language, topics, description)
        tags = self._extract_tags(topics, description, language)

        return TrendItem(
            source=Source.GITHUB,
            title=title,
            url=url,
            description=description,
            author=author,
            score=stars + forks * 2 + watchers,
            stars=stars,
            comments=forks,
            language=language,
            category=category,
            tags=tags,
            fetched_at=datetime.utcnow(),
            created_at=created_at,
            raw_data={
                "forks": forks,
                "watchers": watchers,
                "open_issues": open_issues,
                "topics": topics,
                "archived": data.get("archived", False),
            },
        )

    def _categorize(self, language: str, topics: list[str], description: str) -> Category:
        """Determine category from language, topics, and description."""
        # Check topics first (most reliable signal)
        combined = " ".join(topics).lower()
        for keyword, cat in KEYWORD_CATEGORIES.items():
            if keyword in combined:
                return cat

        # Check description
        desc_lower = (description or "").lower()
        for keyword, cat in KEYWORD_CATEGORIES.items():
            if keyword in desc_lower:
                return cat

        # Fall back to language
        if language in LANG_CATEGORIES:
            return LANG_CATEGORIES[language]

        return Category.TOOLS

    def _extract_tags(self, topics: list[str], description: str, language: str) -> list[str]:
        """Extract relevant tags."""
        tags = list(topics[:8])
        if language and language not in tags:
            tags.append(language)
        return tags[:10]
