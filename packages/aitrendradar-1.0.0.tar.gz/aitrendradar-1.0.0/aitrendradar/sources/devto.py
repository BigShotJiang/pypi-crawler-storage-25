"""DevTo article source via public API."""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any

from ..models import Category, Source, TrendItem
from .base import BaseSource

logger = logging.getLogger(__name__)

# Tag to category mapping
TAG_CATEGORIES: dict[str, Category] = {
    "machinelearning": Category.AI_ML,
    "artificialintelligence": Category.AI_ML,
    "ai": Category.AI_ML,
    "deeplearning": Category.AI_ML,
    "chatgpt": Category.AI_ML,
    "openai": Category.AI_ML,
    "llm": Category.AI_ML,
    "react": Category.WEB,
    "vue": Category.WEB,
    "angular": Category.WEB,
    "nextjs": Category.WEB,
    "svelte": Category.WEB,
    "javascript": Category.WEB,
    "typescript": Category.WEB,
    "css": Category.WEB,
    "html": Category.WEB,
    "node": Category.WEB,
    "deno": Category.WEB,
    "webdev": Category.WEB,
    "frontend": Category.WEB,
    "backend": Category.WEB,
    "android": Category.MOBILE,
    "ios": Category.MOBILE,
    "flutter": Category.MOBILE,
    "swift": Category.MOBILE,
    "kotlin": Category.MOBILE,
    "reactnative": Category.MOBILE,
    "docker": Category.DEVOPS,
    "kubernetes": Category.DEVOPS,
    "devops": Category.DEVOPS,
    "cicd": Category.DEVOPS,
    "terraform": Category.DEVOPS,
    "aws": Category.CLOUD,
    "azure": Category.CLOUD,
    "gcp": Category.CLOUD,
    "cloud": Category.CLOUD,
    "serverless": Category.CLOUD,
    "cloudflare": Category.CLOUD,
    "security": Category.SECURITY,
    "cybersecurity": Category.SECURITY,
    "privacy": Category.SECURITY,
    "database": Category.DATABASES,
    "postgres": Category.DATABASES,
    "mysql": Category.DATABASES,
    "mongodb": Category.DATABASES,
    "redis": Category.DATABASES,
    "sql": Category.DATABASES,
    "python": Category.LANGUAGES,
    "rust": Category.LANGUAGES,
    "go": Category.LANGUAGES,
    "java": Category.LANGUAGES,
    "csharp": Category.LANGUAGES,
    "blockchain": Category.BLOCKCHAIN,
    "crypto": Category.BLOCKCHAIN,
    "web3": Category.BLOCKCHAIN,
    "gamedev": Category.GAMING,
    "unity": Category.GAMING,
    "datascience": Category.DATA_SCIENCE,
    "data": Category.DATA_SCIENCE,
    "analytics": Category.DATA_SCIENCE,
    "opensource": Category.OPEN_SOURCE,
    "beginners": Category.TOOLS,
    "tutorial": Category.TOOLS,
    "productivity": Category.TOOLS,
}


class DevToSource(BaseSource):
    """Fetches trending DevTo articles."""

    name = "devto"

    def fetch(
        self,
        max_items: int | None = None,
        tag: str = "",
        top: int = 7,
    ) -> list[TrendItem]:
        """Fetch trending DevTo articles.

        Args:
            max_items: Override max items to fetch.
            tag: Filter by tag.
            top: Number of days for 'top' articles (default 7).
        """
        limit = max_items or self.config.max_items_per_source
        items: list[TrendItem] = []

        params: dict[str, Any] = {
            "per_page": min(limit, 50),
            "top": top,
        }
        if tag:
            params["tag"] = tag

        data = self._make_request(
            f"{self.config.devto_api_url}/articles",
            params=params,
        )

        if not data or not isinstance(data, list):
            logger.error("DevTo: Failed to fetch articles")
            return items

        for article in data[:limit]:
            item = self._parse_article(article)
            if item:
                items.append(item)

        logger.info("DevTo: fetched %d articles", len(items))
        return items

    def _parse_article(self, data: dict[str, Any]) -> TrendItem | None:
        """Parse a DevTo article into a TrendItem."""
        if not data:
            return None

        url = data.get("url", "")
        if not self.validate_url(url):
            return None

        title = self.sanitize_text(data.get("title", ""), max_length=300)
        if not title:
            return None

        description = self.sanitize_text(
            data.get("description") or "", max_length=500
        )
        positive_reactions = data.get("positive_reactions_count", 0)
        comments_count = data.get("comments_count", 0)
        public_reactions = data.get("public_reactions_count", 0)
        reading_time = data.get("reading_time_minutes", 0)
        author = (data.get("user", {}) or {}).get("username", "")
        tags = data.get("tag_list", [])
        cover_image = data.get("cover_image", "")

        created_at = None
        if data.get("published_at"):
            try:
                created_at = datetime.fromisoformat(
                    data["published_at"].replace("Z", "+00:00")
                )
            except (ValueError, AttributeError):
                pass

        category = self._categorize(tags, description, title)
        extracted_tags = self._extract_tags(tags)

        return TrendItem(
            source=Source.DEVTO,
            title=title,
            url=url,
            description=description,
            author=author,
            score=public_reactions + positive_reactions,
            stars=public_reactions,
            comments=comments_count,
            category=category,
            tags=extracted_tags,
            fetched_at=datetime.utcnow(),
            created_at=created_at,
            raw_data={
                "reading_time": reading_time,
                "cover_image": cover_image,
                "tag_list": tags,
                "path": data.get("path", ""),
                "canonical_url": data.get("canonical_url", ""),
            },
        )

    def _categorize(
        self, tags: list[str], description: str, title: str
    ) -> Category:
        """Determine category from tags, description, and title."""
        # Check tags first
        for tag in tags:
            tag_lower = tag.lower().replace("-", "").replace(" ", "")
            if tag_lower in TAG_CATEGORIES:
                return TAG_CATEGORIES[tag_lower]

        # Check title and description
        combined = f"{title} {description}".lower()
        for tag_key, category in TAG_CATEGORIES.items():
            if tag_key in combined.replace("-", "").replace(" ", ""):
                return category

        return Category.OTHER

    def _extract_tags(self, tags: list[str]) -> list[str]:
        """Clean up tags."""
        return [t.lower().strip() for t in tags if t.strip()][:8]
