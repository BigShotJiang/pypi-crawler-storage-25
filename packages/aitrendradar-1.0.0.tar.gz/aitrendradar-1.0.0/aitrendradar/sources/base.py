"""Base class for data sources."""

from __future__ import annotations

import logging
import time
from abc import ABC, abstractmethod
from typing import Any

import requests

from ..config import get_config
from ..models import TrendItem

logger = logging.getLogger(__name__)


class BaseSource(ABC):
    """Abstract base for trend data sources."""

    name: str = "base"

    def __init__(self) -> None:
        self.config = get_config()
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "AITrendRadar/1.0 (https://github.com/your-username/ai-trend-radar)",
            "Accept": "application/json",
        })
        self._request_count = 0

    def _make_request(
        self,
        url: str,
        params: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any] | list[Any] | None:
        """Make an HTTP GET request with rate limiting and retries."""
        cfg = self.config
        merged_headers = {**self.session.headers, **(headers or {})}

        for attempt in range(cfg.max_retries):
            try:
                # Rate limiting
                if self._request_count > 0:
                    time.sleep(cfg.rate_limit_delay)
                self._request_count += 1

                response = self.session.get(
                    url,
                    params=params,
                    headers=merged_headers,
                    timeout=cfg.request_timeout,
                )
                response.raise_for_status()

                remaining = response.headers.get("X-RateLimit-Remaining")
                if remaining and int(remaining) < 5:
                    logger.warning(
                        "%s: Rate limit approaching (%s remaining), backing off",
                        self.name, remaining,
                    )
                    time.sleep(cfg.rate_limit_delay * 3)

                return response.json()

            except requests.exceptions.HTTPError as e:
                if response.status_code == 403:
                    reset_time = response.headers.get("X-RateLimit-Reset")
                    if reset_time:
                        wait = max(int(reset_time) - int(time.time()), 10)
                        logger.warning(
                            "%s: Rate limited, waiting %ds", self.name, wait
                        )
                        time.sleep(wait)
                        continue
                    logger.error("%s: Forbidden (403) — check API token", self.name)
                    return None
                if response.status_code == 404:
                    logger.warning("%s: Resource not found: %s", self.name, url)
                    return None
                if response.status_code >= 500:
                    wait = (attempt + 1) * cfg.rate_limit_delay * 2
                    logger.warning(
                        "%s: Server error %d, retrying in %.1fs (attempt %d/%d)",
                        self.name, response.status_code, wait,
                        attempt + 1, cfg.max_retries,
                    )
                    time.sleep(wait)
                    continue
                logger.error("%s: HTTP error: %s", self.name, e)
                return None

            except requests.exceptions.Timeout:
                logger.warning(
                    "%s: Timeout on attempt %d/%d for %s",
                    self.name, attempt + 1, cfg.max_retries, url,
                )
                if attempt < cfg.max_retries - 1:
                    time.sleep(cfg.rate_limit_delay)
                continue

            except requests.exceptions.RequestException as e:
                logger.error("%s: Request failed: %s", self.name, e)
                return None

        logger.error("%s: All %d attempts failed for %s", self.name, cfg.max_retries, url)
        return None

    @abstractmethod
    def fetch(self, **kwargs: Any) -> list[TrendItem]:
        """Fetch trending items from this source."""
        ...

    def validate_url(self, url: str) -> bool:
        """Validate that a URL is well-formed."""
        return url.startswith("http://") or url.startswith("https://")

    def sanitize_text(self, text: str, max_length: int = 500) -> str:
        """Sanitize and truncate text content."""
        if not text:
            return ""
        cleaned = text.strip().replace("\x00", "")
        if len(cleaned) > max_length:
            cleaned = cleaned[:max_length - 3] + "..."
        return cleaned
