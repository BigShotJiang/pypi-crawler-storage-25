"""Hacker News source via official Firebase API."""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any

from ..models import Category, Source, TrendItem
from .base import BaseSource

logger = logging.getLogger(__name__)

# HN story title keyword -> category
HN_KEYWORD_CATEGORIES: dict[str, Category] = {
    "gpt": Category.AI_ML,
    "llm": Category.AI_ML,
    "openai": Category.AI_ML,
    "machine learning": Category.AI_ML,
    "deep learning": Category.AI_ML,
    "neural": Category.AI_ML,
    "ai ": Category.AI_ML,
    "transformer": Category.AI_ML,
    "diffusion model": Category.AI_ML,
    "language model": Category.AI_ML,
    "copilot": Category.AI_ML,
    "claude": Category.AI_ML,
    "gemini": Category.AI_ML,
    "react": Category.WEB,
    "vue": Category.WEB,
    "angular": Category.WEB,
    "next.js": Category.WEB,
    "svelte": Category.WEB,
    "node": Category.WEB,
    "deno": Category.WEB,
    "bun": Category.WEB,
    "webassembly": Category.WEB,
    "wasm": Category.WEB,
    "browser": Category.WEB,
    "css": Category.WEB,
    "html": Category.WEB,
    "typescript": Category.WEB,
    "docker": Category.DEVOPS,
    "kubernetes": Category.DEVOPS,
    "k8s": Category.DEVOPS,
    "terraform": Category.DEVOPS,
    "devops": Category.DEVOPS,
    "ci/cd": Category.DEVOPS,
    "deployment": Category.DEVOPS,
    "infrastructure": Category.DEVOPS,
    "monitoring": Category.DEVOPS,
    "security": Category.SECURITY,
    "vulnerability": Category.SECURITY,
    "cve": Category.SECURITY,
    "hack": Category.SECURITY,
    "privacy": Category.SECURITY,
    "encryption": Category.SECURITY,
    "malware": Category.SECURITY,
    "rust": Category.LANGUAGES,
    "python": Category.LANGUAGES,
    "golang": Category.LANGUAGES,
    "go ": Category.LANGUAGES,
    " java ": Category.LANGUAGES,
    "swift": Category.MOBILE,
    "android": Category.MOBILE,
    "ios ": Category.MOBILE,
    "flutter": Category.MOBILE,
    "postgres": Category.DATABASES,
    "mysql": Category.DATABASES,
    "sqlite": Category.DATABASES,
    "redis": Category.DATABASES,
    "mongodb": Category.DATABASES,
    "database": Category.DATABASES,
    "aws": Category.CLOUD,
    "azure": Category.CLOUD,
    "google cloud": Category.CLOUD,
    "serverless": Category.CLOUD,
    "cloudflare": Category.CLOUD,
    "blockchain": Category.BLOCKCHAIN,
    "crypto": Category.BLOCKCHAIN,
    "bitcoin": Category.BLOCKCHAIN,
    "ethereum": Category.BLOCKCHAIN,
    "game dev": Category.GAMING,
    "game engine": Category.GAMING,
    "data science": Category.DATA_SCIENCE,
    "visualization": Category.DATA_SCIENCE,
    "pandas": Category.DATA_SCIENCE,
    "jupyter": Category.DATA_SCIENCE,
    "open source": Category.OPEN_SOURCE,
    "github": Category.OPEN_SOURCE,
}


class HackerNewsSource(BaseSource):
    """Fetches trending stories from Hacker News."""

    name = "hackernews"

    def fetch(self, max_items: int | None = None, story_type: str = "top") -> list[TrendItem]:
        """Fetch trending HN stories.

        Args:
            max_items: Override max items to fetch.
            story_type: 'top', 'new', 'best', or 'show'.
        """
        limit = max_items or self.config.max_items_per_source
        items: list[TrendItem] = []

        # Get story IDs
        endpoint = f"{story_type}stories"
        data = self._make_request(f"{self.config.hackernews_api_url}/{endpoint}.json")
        if not data or not isinstance(data, list):
            logger.error("HN: Failed to fetch %s story IDs", story_type)
            return items

        story_ids = data[:limit]

        # Fetch each story
        for story_id in story_ids:
            story = self._make_request(
                f"{self.config.hackernews_api_url}/item/{story_id}.json"
            )
            if story and isinstance(story, dict):
                item = self._parse_story(story)
                if item:
                    items.append(item)

            if len(items) >= limit:
                break

        logger.info("HN: fetched %d stories (type=%s)", len(items), story_type)
        return items

    def _parse_story(self, data: dict[str, Any]) -> TrendItem | None:
        """Parse an HN story into a TrendItem."""
        story_type = data.get("type", "")
        if story_type != "story":
            return None

        story_id = data.get("id")
        if not story_id:
            return None

        url = data.get("url", "")
        if not url:
            # Self-post (Ask HN, etc.)
            url = f"https://news.ycombinator.com/item?id={story_id}"

        if not self.validate_url(url):
            return None

        title = self.sanitize_text(data.get("title", ""), max_length=300)
        if not title:
            return None

        score = data.get("score", 0)
        descendants = data.get("descendants", 0)
        by = data.get("by", "")

        created_at = None
        if data.get("time"):
            try:
                created_at = datetime.utcfromtimestamp(data["time"])
            except (ValueError, OSError):
                pass

        category = self._categorize(title)
        tags = self._extract_tags(title)

        return TrendItem(
            source=Source.HACKERNEWS,
            title=title,
            url=url,
            description="",
            author=by,
            score=score,
            stars=0,
            comments=descendants,
            category=category,
            tags=tags,
            fetched_at=datetime.utcnow(),
            created_at=created_at,
            raw_data={
                "hn_id": story_id,
                "type": story_type,
                "kids": data.get("kids", []),
            },
        )

    def _categorize(self, title: str) -> Category:
        """Categorize based on title keywords."""
        title_lower = f" {title.lower()} "  # pad for word boundary matching
        best_match_len = 0
        best_category = Category.OTHER

        for keyword, category in HN_KEYWORD_CATEGORIES.items():
            if keyword in title_lower:
                # Prefer longer/more specific matches
                if len(keyword) > best_match_len:
                    best_match_len = len(keyword)
                    best_category = category

        return best_category

    def _extract_tags(self, title: str) -> list[str]:
        """Extract tags from title."""
        tags = []
        title_lower = title.lower()

        tag_keywords = [
            "ai", "llm", "gpt", "rust", "python", "typescript", "react",
            "docker", "kubernetes", "security", "database", "cloud",
            "open source", "linux", "web", "mobile",
        ]
        for kw in tag_keywords:
            if kw in title_lower:
                tags.append(kw)

        return tags[:5]
