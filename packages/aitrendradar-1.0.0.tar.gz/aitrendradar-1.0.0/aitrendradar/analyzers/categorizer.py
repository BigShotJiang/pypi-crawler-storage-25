"""Categorizer for refining trend item categories."""

from __future__ import annotations

import logging
from collections import Counter
from typing import Any

from ..models import Category, Source, TrendItem

logger = logging.getLogger(__name__)


class Categorizer:
    """Refines and validates categories on trend items."""

    def __init__(self) -> None:
        # Map category enum to display names
        self.display_names: dict[Category, str] = {
            Category.AI_ML: "AI / Machine Learning",
            Category.WEB: "Web Development",
            Category.MOBILE: "Mobile",
            Category.DEVOPS: "DevOps / Infrastructure",
            Category.SECURITY: "Security",
            Category.DATABASES: "Databases",
            Category.LANGUAGES: "Languages",
            Category.TOOLS: "Developer Tools",
            Category.OPEN_SOURCE: "Open Source",
            Category.CLOUD: "Cloud",
            Category.BLOCKCHAIN: "Blockchain / Web3",
            Category.GAMING: "Game Development",
            Category.DATA_SCIENCE: "Data Science",
            Category.OTHER: "Other",
        }

    def refine(self, items: list[TrendItem]) -> list[TrendItem]:
        """Refine categories by cross-referencing across items.

        If similar items from different sources share a category,
        use that signal to strengthen categorization.
        """
        # Build a mapping of normalized titles to their categories
        title_category_map: dict[str, list[Category]] = {}
        for item in items:
            key = self._normalize_title(item.title)
            if key not in title_category_map:
                title_category_map[key] = []
            title_category_map[key].append(item.category)

        # For items that might be cross-posted, use the majority category
        for item in items:
            key = self._normalize_title(item.title)
            categories = title_category_map.get(key, [])
            if len(categories) > 1:
                # Use most common category across sources
                counter = Counter(categories)
                best_category = counter.most_common(1)[0][0]
                if best_category != Category.OTHER and item.category == Category.OTHER:
                    item.category = best_category

        return items

    def get_display_name(self, category: Category) -> str:
        """Get human-readable display name for a category."""
        return self.display_names.get(category, category.value)

    def get_category_summary(self, items: list[TrendItem]) -> list[tuple[str, str, int]]:
        """Get summary of categories with display names and counts.

        Returns list of (category_key, display_name, count) sorted by count desc.
        """
        counter = Counter(item.category for item in items)
        result = []
        for category, count in counter.most_common():
            result.append((
                category.value,
                self.get_display_name(category),
                count,
            ))
        return result

    @staticmethod
    def _normalize_title(title: str) -> str:
        """Normalize a title for cross-referencing."""
        return (
            title.lower()
            .strip()
            .replace(" ", "")
            .replace("-", "")
            .replace("_", "")
            .replace(".", "")
            [:50]
        )
