"""Hype score calculation for trend items."""

from __future__ import annotations

import logging
import math
from datetime import datetime, timedelta
from typing import Any

from ..config import get_config
from ..models import Source, TrendItem

logger = logging.getLogger(__name__)

# Source-specific multipliers for engagement normalization
SOURCE_MULTIPLIERS: dict[Source, dict[str, float]] = {
    Source.GITHUB: {
        "stars_weight": 1.0,
        "forks_weight": 1.5,
        "watchers_weight": 0.5,
    },
    Source.HACKERNEWS: {
        "score_weight": 1.0,
        "comments_weight": 2.0,
    },
    Source.DEVTO: {
        "reactions_weight": 1.0,
        "comments_weight": 3.0,
    },
}

# Maximum expected values for normalization (approximate ceilings)
MAX_STARS = 100_000
MAX_HN_SCORE = 3_000
MAX_DEVTO_REACTIONS = 5_000
MAX_COMMENTS = 500
MAX_VELOCITY = 100.0


class HypeScorer:
    """Calculates hype scores for trend items based on multiple signals."""

    def __init__(self) -> None:
        self.config = get_config()
        self.weights = self.config.hype_weights

    def score(self, item: TrendItem) -> float:
        """Calculate hype score for a single item.

        The hype score is a weighted combination of:
        - Stars/reactions (normalized)
        - Base score (upvotes, etc.)
        - Comments/engagement
        - Velocity (growth rate)
        - Recency (how new it is)

        Returns a float between 0 and 100.
        """
        signals = self._calculate_signals(item)
        raw_score = (
            self.weights["stars"] * signals["stars"]
            + self.weights["score"] * signals["score"]
            + self.weights["comments"] * signals["comments"]
            + self.weights["velocity"] * signals["velocity"]
            + self.weights["recency"] * signals["recency"]
        )
        # Scale to 0-100
        hype = min(max(raw_score * 100, 0), 100)
        return round(hype, 2)

    def score_items(self, items: list[TrendItem]) -> list[TrendItem]:
        """Calculate and assign hype scores to a list of items."""
        for item in items:
            item.hype_score = self.score(item)
        # Sort by hype score descending
        items.sort(key=lambda x: x.hype_score, reverse=True)
        return items

    def _calculate_signals(self, item: TrendItem) -> dict[str, float]:
        """Calculate individual signal components, each normalized 0-1."""
        if item.source == Source.GITHUB:
            return self._github_signals(item)
        elif item.source == Source.HACKERNEWS:
            return self._hn_signals(item)
        elif item.source == Source.DEVTO:
            return self._devto_signals(item)
        return {"stars": 0, "score": 0, "comments": 0, "velocity": 0, "recency": 0.5}

    def _github_signals(self, item: TrendItem) -> dict[str, float]:
        """GitHub-specific signal calculation."""
        stars = self._normalize(item.stars, MAX_STARS)
        score = self._normalize(item.score, MAX_STARS)
        comments = self._normalize(item.comments, MAX_COMMENTS)
        velocity = self._normalize(item.velocity, MAX_VELOCITY)
        recency = self._recency_signal(item)

        return {
            "stars": stars,
            "score": score,
            "comments": comments,
            "velocity": velocity,
            "recency": recency,
        }

    def _hn_signals(self, item: TrendItem) -> dict[str, float]:
        """Hacker News-specific signal calculation."""
        stars = self._normalize(item.score, MAX_HN_SCORE)
        score = self._normalize(item.score, MAX_HN_SCORE)
        comments = self._normalize(item.comments, MAX_COMMENTS)
        velocity = self._normalize(item.velocity, MAX_VELOCITY)
        recency = self._recency_signal(item)

        return {
            "stars": stars,
            "score": score,
            "comments": comments,
            "velocity": velocity,
            "recency": recency,
        }

    def _devto_signals(self, item: TrendItem) -> dict[str, float]:
        """DevTo-specific signal calculation."""
        stars = self._normalize(item.stars, MAX_DEVTO_REACTIONS)
        score = self._normalize(item.score, MAX_DEVTO_REACTIONS)
        comments = self._normalize(item.comments, MAX_COMMENTS)
        velocity = self._normalize(item.velocity, MAX_VELOCITY)
        recency = self._recency_signal(item)

        return {
            "stars": stars,
            "score": score,
            "comments": comments,
            "velocity": velocity,
            "recency": recency,
        }

    def _recency_signal(self, item: TrendItem) -> float:
        """Calculate recency signal (0-1). More recent = higher value.

        Scale: 1.0 if <1h old, decays to 0.1 over 7 days.
        """
        if not item.created_at:
            return 0.3  # Unknown age gets moderate recency

        age_hours = (datetime.utcnow() - item.created_at.replace(tzinfo=None)).total_seconds() / 3600
        if age_hours <= 0:
            return 1.0
        if age_hours <= 1:
            return 1.0
        if age_hours >= 168:  # 7 days
            return 0.1
        # Exponential decay
        return max(0.1, math.exp(-age_hours / 48))

    @staticmethod
    def _normalize(value: float, max_value: float) -> float:
        """Normalize a value to 0-1 range using log scaling."""
        if value <= 0:
            return 0.0
        if max_value <= 0:
            return 0.0
        # Use log scale for better distribution at high values
        return min(1.0, math.log1p(value) / math.log1p(max_value))
