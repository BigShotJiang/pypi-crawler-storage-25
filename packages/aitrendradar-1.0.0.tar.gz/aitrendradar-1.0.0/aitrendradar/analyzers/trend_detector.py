"""Emerging trend detection based on velocity and novelty signals."""

from __future__ import annotations

import logging
from collections import Counter
from datetime import datetime, timedelta
from typing import Any

from ..database import TrendDatabase
from ..models import Category, Source, TrendItem

logger = logging.getLogger(__name__)

# Thresholds for emerging trend detection
VELOCITY_THRESHOLD = 15.0       # Minimum velocity score to be "fast-growing"
NEW_ITEM_AGE_HOURS = 48         # Items younger than this are "new"
MIN_ENGAGEMENT_RATIO = 0.3      # Comments-to-score ratio suggesting active discussion
CATEGORY_SURGE_THRESHOLD = 2.5  # Category must be 2.5x its usual share to be "surging"


class TrendDetector:
    """Detects emerging trends before they peak."""

    def __init__(self, db: TrendDatabase | None = None) -> None:
        self.db = db or TrendDatabase()

    def detect_emerging(self, items: list[TrendItem]) -> list[TrendItem]:
        """Flag items that show emerging trend signals.

        An item is flagged as emerging if it satisfies ANY of:
        1. High velocity (rapidly growing)
        2. New + high engagement ratio (lots of discussion relative to score)
        3. Category surge (its category is spiking in representation)
        """
        if not items:
            return []

        category_counts = Counter(item.category for item in items)
        total_items = len(items)
        category_ratios = {
            cat: count / total_items for cat, count in category_counts.items()
        }

        # Get baseline category distribution from historical data
        baseline = self._get_baseline_distribution()

        emerging = []
        for item in items:
            signals = []

            # Signal 1: High velocity
            if item.velocity >= VELOCITY_THRESHOLD:
                signals.append("high_velocity")

            # Signal 2: New + high engagement
            if item.created_at:
                age_hours = (
                    datetime.utcnow() - item.created_at.replace(tzinfo=None)
                ).total_seconds() / 3600
                if age_hours <= NEW_ITEM_AGE_HOURS:
                    if item.score > 0:
                        engagement_ratio = item.comments / max(item.score, 1)
                        if engagement_ratio >= MIN_ENGAGEMENT_RATIO and item.score > 10:
                            signals.append("new_high_engagement")
                    if item.hype_score > 30 and age_hours <= 6:
                        signals.append("fast_trending")

            # Signal 3: Category surge
            if baseline and item.category in category_ratios:
                baseline_ratio = baseline.get(item.category.value, 0.01)
                current_ratio = category_ratios[item.category]
                if current_ratio >= baseline_ratio * CATEGORY_SURGE_THRESHOLD:
                    signals.append("category_surge")

            if signals:
                item.is_emerging = True
                item.raw_data["emerging_signals"] = signals
                emerging.append(item)

        logger.info(
            "TrendDetector: flagged %d/%d items as emerging",
            len(emerging), len(items),
        )
        return emerging

    def calculate_velocity(self, items: list[TrendItem]) -> list[TrendItem]:
        """Calculate velocity for items by comparing with stored data.

        Velocity = (current_score - previous_score) / time_delta_hours.
        Items not in the database get estimated velocity based on age and score.
        """
        for item in items:
            prev = self.db.get_previous_score(item.uid)
            if prev:
                current_total = item.score + item.stars + item.comments
                prev_total = prev["score"] + prev["stars"] + prev["comments"]
                # Estimate time delta (assume ~1 hour between fetches)
                delta = max(current_total - prev_total, 0)
                item.velocity = min(delta, 100.0)
            else:
                # Estimate velocity from score and age
                item.velocity = self._estimate_velocity(item)

        return items

    def _estimate_velocity(self, item: TrendItem) -> float:
        """Estimate velocity for a new item based on engagement and age."""
        if not item.created_at:
            return 0.0

        age_hours = (
            datetime.utcnow() - item.created_at.replace(tzinfo=None)
        ).total_seconds() / 3600
        if age_hours <= 0:
            age_hours = 0.5

        total_engagement = item.score + item.stars + item.comments
        return min(total_engagement / age_hours, 100.0)

    def _get_baseline_distribution(self) -> dict[str, float]:
        """Get historical category distribution from the database."""
        try:
            counts = self.db.get_category_counts(days=30)
            total = sum(cnt for _, cnt in counts)
            if total == 0:
                return {}
            return {cat: cnt / total for cat, cnt in counts}
        except Exception:
            return {}
