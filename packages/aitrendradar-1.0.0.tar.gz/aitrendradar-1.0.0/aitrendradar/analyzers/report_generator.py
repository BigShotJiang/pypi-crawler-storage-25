"""Report generation orchestrator."""

from __future__ import annotations

import logging
from datetime import datetime, timedelta
from typing import Any

from ..database import TrendDatabase
from ..models import Category, TrendItem, TrendReport
from .categorizer import Categorizer
from .hype_scorer import HypeScorer
from .trend_detector import TrendDetector

logger = logging.getLogger(__name__)


class ReportGenerator:
    """Orchestrates analysis and report generation."""

    def __init__(self, db: TrendDatabase | None = None) -> None:
        self.db = db or TrendDatabase()
        self.scorer = HypeScorer()
        self.detector = TrendDetector(self.db)
        self.categorizer = Categorizer()

    def generate_report(
        self,
        items: list[TrendItem],
        period: str = "weekly",
    ) -> TrendReport:
        """Generate a full trend report from raw items.

        Steps:
        1. Store items in database
        2. Calculate velocities
        3. Score items
        4. Detect emerging trends
        5. Refine categories
        6. Build summary text
        """
        if not items:
            return TrendReport(
                title="AITrendRadar Report",
                period=period,
                summary="No items collected this period.",
            )

        # Step 1: Persist
        new, updated = self.db.insert_items(items)
        logger.info("Database: %d new, %d updated", new, updated)

        # Step 2: Velocity
        items = self.detector.calculate_velocity(items)

        # Step 3: Score
        items = self.scorer.score_items(items)

        # Step 4: Detect emerging
        emerging = self.detector.detect_emerging(items)

        # Step 5: Refine categories
        items = self.categorizer.refine(items)

        # Update database with scores and emerging flags
        for item in items:
            self.db.insert_item(item)

        # Step 6: Build report
        category_summary = self.categorizer.get_category_summary(items)
        top_categories = [(cat, count) for cat, _, count in category_summary[:10]]
        summary_text = self._generate_summary(items, emerging, category_summary)

        return TrendReport(
            title=self._report_title(period),
            period=period,
            items=items,
            top_categories=top_categories,
            emerging_trends=emerging,
            summary=summary_text,
        )

    def _report_title(self, period: str) -> str:
        """Generate a descriptive report title."""
        now = datetime.utcnow()
        period_labels = {
            "daily": now.strftime("%Y-%m-%d"),
            "weekly": f"Week of {now.strftime('%b %d, %Y')}",
            "monthly": now.strftime("%B %Y"),
        }
        label = period_labels.get(period, now.strftime("%Y-%m-%d"))
        return f"AITrendRadar Report - {label}"

    def _generate_summary(
        self,
        items: list[TrendItem],
        emerging: list[TrendItem],
        category_summary: list[tuple[str, str, int]],
    ) -> str:
        """Generate a human-readable summary paragraph."""
        lines = []

        total = len(items)
        sources = set(item.source.value for item in items)
        lines.append(
            f"Analyzed {total} trending items from "
            f"{', '.join(sorted(sources))}."
        )

        if category_summary:
            top_cat = category_summary[0]
            lines.append(
                f"The dominant category is **{top_cat[1]}** with "
                f"{top_cat[2]} items."
            )

        if emerging:
            top_emerging = emerging[0] if emerging else None
            if top_emerging:
                lines.append(
                    f"Detected {len(emerging)} emerging trends, "
                    f"led by '{top_emerging.title}' "
                    f"(hype: {top_emerging.hype_score:.1f})."
                )

        # Mention top item
        if items:
            top = items[0]
            lines.append(
                f"Top item: '{top.title}' with a hype score of "
                f"{top.hype_score:.1f}."
            )

        return " ".join(lines)
