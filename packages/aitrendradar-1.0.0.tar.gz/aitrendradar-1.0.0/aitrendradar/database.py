"""SQLite database for persisting trend data over time."""

from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Generator

from .config import get_config
from .models import Category, Source, TrendItem


class TrendDatabase:
    """SQLite-backed storage for trend items."""

    def __init__(self, db_path: str | None = None) -> None:
        self.db_path = db_path or get_config().db_path
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        self._init_schema()

    @contextmanager
    def _connection(self) -> Generator[sqlite3.Connection, None, None]:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def _init_schema(self) -> None:
        with self._connection() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS trend_items (
                    uid TEXT PRIMARY KEY,
                    source TEXT NOT NULL,
                    title TEXT NOT NULL,
                    url TEXT NOT NULL UNIQUE,
                    description TEXT DEFAULT '',
                    author TEXT DEFAULT '',
                    score INTEGER DEFAULT 0,
                    stars INTEGER DEFAULT 0,
                    comments INTEGER DEFAULT 0,
                    language TEXT DEFAULT '',
                    category TEXT DEFAULT 'other',
                    hype_score REAL DEFAULT 0.0,
                    velocity REAL DEFAULT 0.0,
                    is_emerging INTEGER DEFAULT 0,
                    tags TEXT DEFAULT '[]',
                    fetched_at TEXT NOT NULL,
                    created_at TEXT,
                    raw_data TEXT DEFAULT '{}'
                )
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_trend_source
                ON trend_items(source)
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_trend_category
                ON trend_items(category)
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_trend_hype
                ON trend_items(hype_score DESC)
            """)
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_trend_fetched
                ON trend_items(fetched_at DESC)
            """)

    def insert_item(self, item: TrendItem) -> bool:
        """Insert or update a trend item. Returns True if new, False if updated."""
        with self._connection() as conn:
            existing = conn.execute(
                "SELECT uid, score, stars, comments FROM trend_items WHERE uid = ?",
                (item.uid,),
            ).fetchone()

            tags_json = json.dumps(item.tags)
            raw_json = json.dumps(item.raw_data, default=str)

            if existing:
                conn.execute("""
                    UPDATE trend_items SET
                        score = ?, stars = ?, comments = ?,
                        hype_score = ?, velocity = ?, is_emerging = ?,
                        fetched_at = ?, description = ?, tags = ?, raw_data = ?
                    WHERE uid = ?
                """, (
                    item.score, item.stars, item.comments,
                    item.hype_score, item.velocity, int(item.is_emerging),
                    item.fetched_at.isoformat(), item.description, tags_json, raw_json,
                    item.uid,
                ))
                return False
            else:
                conn.execute("""
                    INSERT INTO trend_items (
                        uid, source, title, url, description, author,
                        score, stars, comments, language, category,
                        hype_score, velocity, is_emerging, tags,
                        fetched_at, created_at, raw_data
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    item.uid, item.source.value, item.title, item.url,
                    item.description, item.author, item.score, item.stars,
                    item.comments, item.language, item.category.value,
                    item.hype_score, item.velocity, int(item.is_emerging),
                    tags_json, item.fetched_at.isoformat(),
                    item.created_at.isoformat() if item.created_at else None,
                    raw_json,
                ))
                return True

    def insert_items(self, items: list[TrendItem]) -> tuple[int, int]:
        """Bulk insert items. Returns (new_count, updated_count)."""
        new_count = 0
        update_count = 0
        for item in items:
            if self.insert_item(item):
                new_count += 1
            else:
                update_count += 1
        return new_count, update_count

    def get_items(
        self,
        source: Source | None = None,
        category: Category | None = None,
        days: int | None = None,
        limit: int = 50,
        min_hype: float = 0.0,
    ) -> list[TrendItem]:
        """Query trend items with optional filters."""
        conditions: list[str] = []
        params: list[Any] = []

        if source:
            conditions.append("source = ?")
            params.append(source.value)
        if category:
            conditions.append("category = ?")
            params.append(category.value)
        if days is not None:
            cutoff = (datetime.utcnow() - timedelta(days=days)).isoformat()
            conditions.append("fetched_at >= ?")
            params.append(cutoff)
        if min_hype > 0:
            conditions.append("hype_score >= ?")
            params.append(min_hype)

        where = " AND ".join(conditions) if conditions else "1=1"
        params.append(limit)

        with self._connection() as conn:
            rows = conn.execute(
                f"SELECT * FROM trend_items WHERE {where} ORDER BY hype_score DESC LIMIT ?",
                params,
            ).fetchall()

        items = []
        for row in rows:
            items.append(self._row_to_item(row))
        return items

    def get_previous_score(self, uid: str) -> dict[str, int] | None:
        """Get previous score data for velocity calculation."""
        with self._connection() as conn:
            row = conn.execute(
                "SELECT score, stars, comments FROM trend_items WHERE uid = ?",
                (uid,),
            ).fetchone()
            if row:
                return {"score": row["score"], "stars": row["stars"], "comments": row["comments"]}
        return None

    def get_category_counts(self, days: int = 7) -> list[tuple[str, int]]:
        """Get item counts by category for the last N days."""
        cutoff = (datetime.utcnow() - timedelta(days=days)).isoformat()
        with self._connection() as conn:
            rows = conn.execute(
                "SELECT category, COUNT(*) as cnt FROM trend_items "
                "WHERE fetched_at >= ? GROUP BY category ORDER BY cnt DESC",
                (cutoff,),
            ).fetchall()
        return [(row["category"], row["cnt"]) for row in rows]

    def get_trending_emerging(self, limit: int = 10) -> list[TrendItem]:
        """Get items flagged as emerging trends."""
        with self._connection() as conn:
            rows = conn.execute(
                "SELECT * FROM trend_items WHERE is_emerging = 1 "
                "ORDER BY velocity DESC, hype_score DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [self._row_to_item(row) for row in rows]

    def get_stats(self) -> dict[str, Any]:
        """Get database statistics."""
        with self._connection() as conn:
            total = conn.execute("SELECT COUNT(*) as cnt FROM trend_items").fetchone()["cnt"]
            by_source = conn.execute(
                "SELECT source, COUNT(*) as cnt FROM trend_items GROUP BY source"
            ).fetchall()
            latest = conn.execute(
                "SELECT MAX(fetched_at) as latest FROM trend_items"
            ).fetchone()["latest"]
            emerging = conn.execute(
                "SELECT COUNT(*) as cnt FROM trend_items WHERE is_emerging = 1"
            ).fetchone()["cnt"]

        return {
            "total_items": total,
            "by_source": {row["source"]: row["cnt"] for row in by_source},
            "latest_fetch": latest,
            "emerging_count": emerging,
        }

    def cleanup_old(self, days: int = 90) -> int:
        """Remove items older than N days. Returns deleted count."""
        cutoff = (datetime.utcnow() - timedelta(days=days)).isoformat()
        with self._connection() as conn:
            cursor = conn.execute(
                "DELETE FROM trend_items WHERE fetched_at < ?", (cutoff,)
            )
            return cursor.rowcount

    def _row_to_item(self, row: sqlite3.Row) -> TrendItem:
        """Convert a database row to a TrendItem."""
        return TrendItem(
            source=Source(row["source"]),
            title=row["title"],
            url=row["url"],
            description=row["description"] or "",
            author=row["author"] or "",
            score=row["score"],
            stars=row["stars"],
            comments=row["comments"],
            language=row["language"] or "",
            category=Category(row["category"]),
            hype_score=row["hype_score"],
            velocity=row["velocity"],
            is_emerging=bool(row["is_emerging"]),
            tags=json.loads(row["tags"]) if row["tags"] else [],
            fetched_at=datetime.fromisoformat(row["fetched_at"]),
            created_at=datetime.fromisoformat(row["created_at"]) if row["created_at"] else None,
            raw_data=json.loads(row["raw_data"]) if row["raw_data"] else {},
        )
