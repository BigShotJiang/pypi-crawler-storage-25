"""
AITrendRadar - AI-powered trend radar for tech.

Tracks GitHub trending repos, Hacker News, and DevTo articles,
then generates curated reports with hype scores and trend detection.
"""

__version__ = "1.0.0"
__author__ = "AITrendRadar Contributors"
