"""Web dashboard package."""
