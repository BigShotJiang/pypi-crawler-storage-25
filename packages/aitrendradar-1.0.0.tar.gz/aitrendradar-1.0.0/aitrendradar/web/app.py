"""Flask web dashboard for AITrendRadar."""

from __future__ import annotations

import json
from datetime import datetime
from typing import Any

from flask import Flask, jsonify, render_template_string, request

from ..config import get_config
from ..database import TrendDatabase
from ..analyzers.categorizer import Categorizer
from ..analyzers.report_generator import ReportGenerator
from ..sources.github import GitHubSource
from ..sources.hackernews import HackerNewsSource
from ..sources.devto import DevToSource


DASHBOARD_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AITrendRadar Dashboard</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            background: #0d1117;
            color: #c9d1d9;
        }
        nav {
            background: #161b22;
            border-bottom: 1px solid #30363d;
            padding: 12px 24px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        nav h1 { color: #58a6ff; font-size: 20px; }
        nav a {
            color: #8b949e;
            text-decoration: none;
            margin-left: 20px;
            font-size: 14px;
        }
        nav a:hover { color: #58a6ff; }
        .container { max-width: 1200px; margin: 0 auto; padding: 24px; }
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
            margin-bottom: 24px;
        }
        .stat-card {
            background: #161b22;
            border: 1px solid #30363d;
            border-radius: 8px;
            padding: 20px;
            text-align: center;
        }
        .stat-card .value { font-size: 32px; font-weight: 700; color: #58a6ff; }
        .stat-card .label { color: #8b949e; font-size: 13px; margin-top: 4px; }
        .actions {
            background: #161b22;
            border: 1px solid #30363d;
            border-radius: 8px;
            padding: 16px;
            margin-bottom: 24px;
            display: flex;
            gap: 12px;
            align-items: center;
            flex-wrap: wrap;
        }
        .btn {
            padding: 8px 16px;
            border: 1px solid #30363d;
            border-radius: 6px;
            background: #21262d;
            color: #c9d1d9;
            cursor: pointer;
            font-size: 14px;
            text-decoration: none;
        }
        .btn:hover { background: #30363d; }
        .btn-primary { background: #238636; border-color: #238636; color: #fff; }
        .btn-primary:hover { background: #2ea043; }
        .filter-group { display: flex; gap: 8px; align-items: center; }
        .filter-group select, .filter-group input {
            padding: 6px 12px;
            border: 1px solid #30363d;
            border-radius: 6px;
            background: #0d1117;
            color: #c9d1d9;
            font-size: 14px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th {
            text-align: left;
            padding: 12px 16px;
            border-bottom: 1px solid #30363d;
            color: #8b949e;
            font-size: 12px;
            text-transform: uppercase;
        }
        td {
            padding: 12px 16px;
            border-bottom: 1px solid #21262d;
            font-size: 14px;
        }
        tr:hover { background: #161b22; }
        .source-badge {
            padding: 2px 8px;
            border-radius: 10px;
            font-size: 11px;
            font-weight: 600;
        }
        .badge-github { background: #238636; color: #fff; }
        .badge-hackernews { background: #f0652f; color: #fff; }
        .badge-devto { background: #3b49df; color: #fff; }
        .hype-bar {
            width: 80px;
            height: 6px;
            background: #21262d;
            border-radius: 3px;
            display: inline-block;
            vertical-align: middle;
        }
        .hype-fill {
            height: 100%;
            border-radius: 3px;
        }
        .emerging-tag {
            background: #8957e5;
            color: #fff;
            padding: 1px 6px;
            border-radius: 8px;
            font-size: 10px;
            font-weight: 600;
        }
        .empty { text-align: center; padding: 60px; color: #484f58; }
        .flash {
            background: #238636;
            color: #fff;
            padding: 12px 20px;
            border-radius: 6px;
            margin-bottom: 16px;
        }
    </style>
</head>
<body>
    <nav>
        <h1>&#x1F4E1; AITrendRadar</h1>
        <div>
            <a href="/">Dashboard</a>
            <a href="/api/items">API</a>
            <a href="/api/stats">Stats</a>
        </div>
    </nav>

    <div class="container">
        {% if message %}
        <div class="flash">{{ message }}</div>
        {% endif %}

        <div class="stats">
            <div class="stat-card">
                <div class="value">{{ stats.total_items }}</div>
                <div class="label">Total Items</div>
            </div>
            <div class="stat-card">
                <div class="value">{{ stats.emerging_count }}</div>
                <div class="label">Emerging Trends</div>
            </div>
            <div class="stat-card">
                <div class="value">{{ stats.by_source.get('github', 0) }}</div>
                <div class="label">GitHub</div>
            </div>
            <div class="stat-card">
                <div class="value">{{ stats.by_source.get('hackernews', 0) }}</div>
                <div class="label">Hacker News</div>
            </div>
            <div class="stat-card">
                <div class="value">{{ stats.by_source.get('devto', 0) }}</div>
                <div class="label">DevTo</div>
            </div>
        </div>

        <div class="actions">
            <form method="POST" action="/scan" style="display:flex;gap:12px;align-items:center;flex-wrap:wrap">
                <button type="submit" class="btn btn-primary">Scan Now</button>
                <div class="filter-group">
                    <label style="color:#8b949e;font-size:13px">Source:</label>
                    <select name="source">
                        <option value="all">All</option>
                        <option value="github">GitHub</option>
                        <option value="hackernews">Hacker News</option>
                        <option value="devto">DevTo</option>
                    </select>
                </div>
            </form>
            <div style="flex:1"></div>
            <form method="GET" style="display:flex;gap:8px;align-items:center">
                <select name="source">
                    <option value="">All Sources</option>
                    <option value="github" {% if filter_source == 'github' %}selected{% endif %}>GitHub</option>
                    <option value="hackernews" {% if filter_source == 'hackernews' %}selected{% endif %}>HN</option>
                    <option value="devto" {% if filter_source == 'devto' %}selected{% endif %}>DevTo</option>
                </select>
                <select name="category">
                    <option value="">All Categories</option>
                    {% for cat in categories %}
                    <option value="{{ cat }}" {% if filter_category == cat %}selected{% endif %}>{{ cat }}</option>
                    {% endfor %}
                </select>
                <select name="days">
                    <option value="1" {% if filter_days == 1 %}selected{% endif %}>Today</option>
                    <option value="7" {% if filter_days == 7 %}selected{% endif %}>This Week</option>
                    <option value="30" {% if filter_days == 30 %}selected{% endif %}>This Month</option>
                    <option value="90" {% if filter_days == 90 %}selected{% endif %}>Last 90 Days</option>
                </select>
                <button type="submit" class="btn">Filter</button>
            </form>
        </div>

        {% if items %}
        <table>
            <thead>
                <tr>
                    <th>Source</th>
                    <th>Title</th>
                    <th>Category</th>
                    <th>Hype</th>
                    <th>Score</th>
                    <th>Stars</th>
                    <th>Comments</th>
                </tr>
            </thead>
            <tbody>
                {% for item in items %}
                <tr>
                    <td>
                        <span class="source-badge badge-{{ item.source.value }}">
                            {{ item.source.value | upper }}
                        </span>
                    </td>
                    <td>
                        <a href="{{ item.url }}" style="color:#58a6ff;text-decoration:none">
                            {{ item.title[:60] }}{% if item.title|length > 60 %}...{% endif %}
                        </a>
                        {% if item.is_emerging %}
                        <span class="emerging-tag">EMERGING</span>
                        {% endif %}
                    </td>
                    <td style="color:#8b949e">{{ item.category.value }}</td>
                    <td>
                        {{ "%.1f" | format(item.hype_score) }}
                        <div class="hype-bar">
                            <div class="hype-fill" style="width:{{ item.hype_score }}%;background:{% if item.hype_score >= 50 %}#3fb950{% elif item.hype_score >= 25 %}#d29922{% else %}#484f58{% endif %}"></div>
                        </div>
                    </td>
                    <td>{{ item.score }}</td>
                    <td>{{ item.stars }}</td>
                    <td>{{ item.comments }}</td>
                </tr>
                {% endfor %}
            </tbody>
        </table>
        {% else %}
        <div class="empty">
            <p>No items found. Click "Scan Now" to fetch trending data.</p>
        </div>
        {% endif %}
    </div>
</body>
</html>"""


def create_app() -> Flask:
    """Create and configure the Flask app."""
    app = Flask(__name__)
    app.config["SECRET_KEY"] = "aitrendradar-dashboard-key-change-in-production"

    db = TrendDatabase()
    categorizer = Categorizer()

    @app.route("/")
    def index():
        source = request.args.get("source", "")
        category = request.args.get("category", "")
        days_str = request.args.get("days", "7")
        try:
            days = int(days_str)
        except ValueError:
            days = 7

        from ..models import Source, Category
        src = Source(source) if source else None
        cat = Category(category) if category else None

        items = db.get_items(source=src, category=cat, days=days, limit=100)
        stats = db.get_stats()

        all_categories = sorted(set(
            row["category"]
            for row in db.get_category_counts(days=90)
        ) if hasattr(db.get_category_counts(days=90), '__iter__') else [])

        try:
            cat_rows = db.get_category_counts(days=90)
            all_categories = sorted(row[0] for row in cat_rows)
        except Exception:
            all_categories = [c.value for c in Category]

        return render_template_string(
            DASHBOARD_HTML,
            items=items,
            stats=stats,
            categories=all_categories,
            filter_source=source,
            filter_category=category,
            filter_days=days,
            message="",
        )

    @app.route("/scan", methods=["POST"])
    def scan():
        source = request.form.get("source", "all")
        items = []

        try:
            if source in ("all", "github"):
                items.extend(GitHubSource().fetch(max_items=20))
            if source in ("all", "hackernews"):
                items.extend(HackerNewsSource().fetch(max_items=20))
            if source in ("all", "devto"):
                items.extend(DevToSource().fetch(max_items=20))
        except Exception as e:
            return render_template_string(
                DASHBOARD_HTML,
                items=[],
                stats=db.get_stats(),
                categories=[],
                filter_source="",
                filter_category="",
                filter_days=7,
                message=f"Error fetching: {e}",
            )

        if items:
            gen = ReportGenerator(db)
            gen.generate_report(items, period="weekly")

        stats = db.get_stats()
        return render_template_string(
            DASHBOARD_HTML,
            items=db.get_items(limit=100),
            stats=stats,
            categories=[],
            filter_source="",
            filter_category="",
            filter_days=7,
            message=f"Scanned {len(items)} items successfully!",
        )

    @app.route("/api/items")
    def api_items():
        source = request.args.get("source", "")
        category = request.args.get("category", "")
        days_str = request.args.get("days", "7")
        limit_str = request.args.get("limit", "50")

        from ..models import Source, Category
        try:
            days = int(days_str)
            limit = int(limit_str)
        except ValueError:
            return jsonify({"error": "Invalid days or limit parameter"}), 400

        src = Source(source) if source else None
        cat = Category(category) if category else None

        items = db.get_items(source=src, category=cat, days=days, limit=limit)
        return jsonify({
            "items": [item.to_dict() for item in items],
            "count": len(items),
        })

    @app.route("/api/stats")
    def api_stats():
        return jsonify(db.get_stats())

    return app
