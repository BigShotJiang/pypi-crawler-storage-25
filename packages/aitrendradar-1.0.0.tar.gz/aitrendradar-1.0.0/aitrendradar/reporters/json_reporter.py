"""JSON report output."""

from __future__ import annotations

import json
import logging
from pathlib import Path

from ..models import TrendReport

logger = logging.getLogger(__name__)


class JsonReporter:
    """Generates JSON report files."""

    def __init__(self, output_dir: Path | str | None = None) -> None:
        from ..config import get_config
        self.output_dir = Path(output_dir) if output_dir else get_config().output_dir
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def generate(self, report: TrendReport) -> Path:
        """Generate a JSON report file."""
        data = report.to_dict()
        content = json.dumps(data, indent=2, ensure_ascii=False, default=str)

        filename = f"trend-report-{report.generated_at.strftime('%Y%m%d-%H%M%S')}.json"
        filepath = self.output_dir / filename
        filepath.write_text(content, encoding="utf-8")
        logger.info("JSON report saved to %s", filepath)
        return filepath

    def save_items(self, items: list, filename: str = "latest-items.json") -> Path:
        """Save raw items as JSON."""
        data = [item.to_dict() for item in items]
        content = json.dumps(data, indent=2, ensure_ascii=False, default=str)
        filepath = self.output_dir / filename
        filepath.write_text(content, encoding="utf-8")
        return filepath
