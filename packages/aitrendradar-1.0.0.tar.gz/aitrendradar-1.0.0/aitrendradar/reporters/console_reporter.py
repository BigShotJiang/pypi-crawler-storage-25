"""Rich terminal console dashboard."""

from __future__ import annotations

import logging
from typing import Any

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.columns import Columns
from rich.text import Text
from rich.layout import Layout
from rich.align import Align
from rich.rule import Rule

from ..analyzers.categorizer import Categorizer
from ..models import Source, TrendReport

logger = logging.getLogger(__name__)

SOURCE_STYLES = {
    Source.GITHUB: "bold green",
    Source.HACKERNEWS: "bold bright_red",
    Source.DEVTO: "bold blue",
}

SOURCE_LABELS = {
    Source.GITHUB: "GitHub",
    Source.HACKERNEWS: "HN",
    Source.DEVTO: "DevTo",
}

CATEGORY_COLORS = {
    "ai-ml": "bright_magenta",
    "web": "bright_blue",
    "mobile": "bright_cyan",
    "devops": "bright_yellow",
    "security": "bright_red",
    "databases": "bright_green",
    "languages": "yellow",
    "tools": "white",
    "open-source": "green",
    "cloud": "cyan",
    "blockchain": "magenta",
    "gaming": "bright_white",
    "data-science": "blue",
    "other": "dim",
}


class ConsoleReporter:
    """Displays trend reports as a rich terminal dashboard."""

    def __init__(self) -> None:
        self.console = Console()
        self.categorizer = Categorizer()

    def display(self, report: TrendReport) -> None:
        """Display the full trend dashboard in the terminal."""
        self.console.clear()
        self._display_header(report)
        self._display_summary(report)
        self._display_categories(report)
        self._display_emerging(report)
        self._display_items_table(report)
        self._display_footer(report)

    def display_items(self, items: list, title: str = "Trending Items") -> None:
        """Display a simple table of items."""
        self.console.print()
        self.console.rule(f"[bold]{title}[/bold]")

        table = Table(
            show_header=True,
            header_style="bold bright_white",
            border_style="dim",
            pad_edge=False,
        )
        table.add_column("#", style="dim", width=4, justify="right")
        table.add_column("Source", width=8)
        table.add_column("Title", min_width=40, max_width=60, no_wrap=False)
        table.add_column("Category", width=14)
        table.add_column("Hype", width=8, justify="right")
        table.add_column("Score", width=8, justify="right")

        for i, item in enumerate(items, 1):
            source_label = SOURCE_LABELS.get(item.source, item.source.value)
            source_style = SOURCE_STYLES.get(item.source, "white")
            cat_color = CATEGORY_COLORS.get(item.category.value, "white")

            hype_str = f"{item.hype_score:.1f}"
            hype_style = "green" if item.hype_score >= 50 else ("yellow" if item.hype_score >= 25 else "dim")

            table.add_row(
                str(i),
                f"[{source_style}]{source_label}[/{source_style}]",
                item.title[:58] + ("..." if len(item.title) > 58 else ""),
                f"[{cat_color}]{item.category.value}[/{cat_color}]",
                f"[{hype_style}]{hype_str}[/{hype_style}]",
                f"{item.score:,}",
            )

        self.console.print(table)

    def _display_header(self, report: TrendReport) -> None:
        """Display the report header banner."""
        header = Text()
        header.append("AITrendRadar", style="bold bright_blue")
        header.append(" - ", style="dim")
        header.append(report.title, style="bold white")
        header.append("\n")
        header.append(
            f"  {report.generated_at.strftime('%Y-%m-%d %H:%M UTC')}  |  "
            f"Period: {report.period}  |  "
            f"Items: {report.total_items}",
            style="dim",
        )

        self.console.print()
        self.console.print(Panel(header, border_style="bright_blue", padding=(1, 2)))

    def _display_summary(self, report: TrendReport) -> None:
        """Display the report summary."""
        if report.summary:
            self.console.print()
            self.console.print(Panel(
                report.summary,
                title="[bold]Summary[/bold]",
                border_style="dim",
                padding=(0, 2),
            ))

    def _display_categories(self, report: TrendReport) -> None:
        """Display category breakdown."""
        if not report.top_categories:
            return

        self.console.print()
        self.console.rule("[bold]Top Categories[/bold]")

        table = Table(
            show_header=True,
            header_style="bold bright_white",
            border_style="dim",
            pad_edge=False,
        )
        table.add_column("Category", min_width=25)
        table.add_column("Count", width=8, justify="right")
        table.add_column("Bar", min_width=30)

        max_count = max(c for _, c in report.top_categories) if report.top_categories else 1

        for cat_key, count in report.top_categories:
            cat_color = CATEGORY_COLORS.get(cat_key, "white")
            display = self._get_cat_display(report, cat_key)
            bar_len = int((count / max_count) * 30) if max_count > 0 else 0
            bar = "\u2588" * bar_len

            table.add_row(
                f"[{cat_color}]{display}[/{cat_color}]",
                str(count),
                f"[{cat_color}]{bar}[/{cat_color}]",
            )

        self.console.print(table)

    def _display_emerging(self, report: TrendReport) -> None:
        """Display emerging trends section."""
        if not report.emerging_trends:
            return

        self.console.print()
        self.console.rule("[bold bright_magenta]Emerging Trends[/bold bright_magenta]")

        for i, item in enumerate(report.emerging_trends[:8], 1):
            source_label = SOURCE_LABELS.get(item.source, item.source.value)
            source_style = SOURCE_STYLES.get(item.source, "white")

            self.console.print(
                f"  [bold bright_magenta]{i}.[/bold bright_magenta] "
                f"[{source_style}][{source_label}][/{source_style}] "
                f"[bold][link={item.url}]{item.title}[/link][/bold] "
                f"[dim](hype: {item.hype_score:.1f}, velocity: {item.velocity:.1f})[/dim]"
            )

    def _display_items_table(self, report: TrendReport) -> None:
        """Display the main items table."""
        self.console.print()
        self.console.rule("[bold]All Trending Items[/bold]")

        table = Table(
            show_header=True,
            header_style="bold bright_white",
            border_style="dim",
            pad_edge=False,
            show_lines=False,
        )
        table.add_column("#", style="dim", width=4, justify="right")
        table.add_column("Source", width=8)
        table.add_column("Title", min_width=40, max_width=55, no_wrap=False)
        table.add_column("Category", width=14)
        table.add_column("Hype", width=8, justify="right")
        table.add_column("Stars", width=8, justify="right")
        table.add_column("Cmts", width=6, justify="right")

        display_items = report.items[:40]
        for i, item in enumerate(display_items, 1):
            source_label = SOURCE_LABELS.get(item.source, item.source.value)
            source_style = SOURCE_STYLES.get(item.source, "white")
            cat_color = CATEGORY_COLORS.get(item.category.value, "white")

            hype_str = f"{item.hype_score:.1f}"
            hype_style = "green" if item.hype_score >= 50 else ("yellow" if item.hype_score >= 25 else "dim")

            title_display = item.title[:53] + ("..." if len(item.title) > 53 else "")
            if item.is_emerging:
                title_display += " [bright_magenta]*[/bright_magenta]"

            table.add_row(
                str(i),
                f"[{source_style}]{source_label}[/{source_style}]",
                title_display,
                f"[{cat_color}]{item.category.value}[/{cat_color}]",
                f"[{hype_style}]{hype_str}[/{hype_style}]",
                f"{item.stars:,}" if item.stars else "-",
                str(item.comments) if item.comments else "-",
            )

        self.console.print(table)

        if len(report.items) > 40:
            self.console.print(
                f"  [dim]... and {len(report.items) - 40} more items[/dim]"
            )

    def _display_footer(self, report: TrendReport) -> None:
        """Display footer."""
        self.console.print()
        self.console.rule(style="dim")
        self.console.print(
            Align.center(
                "[dim]Generated by [bright_blue]AITrendRadar[/bright_blue] "
                "- AI-Powered Trend Radar[/dim]"
            )
        )
        self.console.print()

    def _get_cat_display(self, report: TrendReport, cat_key: str) -> str:
        """Get display name for a category."""
        for item in report.items:
            if item.category.value == cat_key:
                return self.categorizer.get_display_name(item.category)
        return cat_key
