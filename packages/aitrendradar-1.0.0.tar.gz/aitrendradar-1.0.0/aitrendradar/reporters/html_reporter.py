"""HTML newsletter report output."""

from __future__ import annotations

import logging
from datetime import datetime
from pathlib import Path
from typing import Any

from jinja2 import Environment, BaseLoader

from ..analyzers.categorizer import Categorizer
from ..models import Source, TrendReport

logger = logging.getLogger(__name__)

HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ report.title }}</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #0d1117;
            color: #c9d1d9;
            line-height: 1.6;
            padding: 20px;
        }
        .container { max-width: 900px; margin: 0 auto; }
        .header {
            background: linear-gradient(135deg, #1a1b2e 0%, #16213e 50%, #0f3460 100%);
            border: 1px solid #30363d;
            border-radius: 12px;
            padding: 40px;
            margin-bottom: 30px;
            text-align: center;
        }
        .header h1 {
            color: #58a6ff;
            font-size: 28px;
            margin-bottom: 8px;
        }
        .header .subtitle { color: #8b949e; font-size: 14px; }
        .header .meta {
            margin-top: 16px;
            display: flex;
            justify-content: center;
            gap: 24px;
            flex-wrap: wrap;
        }
        .header .meta span {
            color: #8b949e;
            font-size: 13px;
        }
        .summary {
            background: #161b22;
            border: 1px solid #30363d;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 24px;
        }
        .summary h2 { color: #58a6ff; margin-bottom: 12px; font-size: 18px; }
        .summary p { color: #c9d1d9; }
        .section { margin-bottom: 30px; }
        .section h2 {
            color: #e6edf3;
            font-size: 20px;
            margin-bottom: 16px;
            padding-bottom: 8px;
            border-bottom: 1px solid #30363d;
        }
        .emerging-banner {
            background: linear-gradient(90deg, #1a1b2e, #1f1320);
            border: 1px solid #8957e5;
            border-radius: 8px;
            padding: 16px;
            margin-bottom: 8px;
        }
        .emerging-banner .badge {
            display: inline-block;
            background: #8957e5;
            color: #fff;
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 600;
            margin-bottom: 6px;
        }
        .item {
            background: #161b22;
            border: 1px solid #30363d;
            border-radius: 8px;
            padding: 16px;
            margin-bottom: 12px;
            transition: border-color 0.2s;
        }
        .item:hover { border-color: #58a6ff; }
        .item-title {
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 6px;
        }
        .item-title a {
            color: #58a6ff;
            text-decoration: none;
        }
        .item-title a:hover { text-decoration: underline; }
        .item-meta {
            display: flex;
            gap: 16px;
            flex-wrap: wrap;
            font-size: 13px;
            color: #8b949e;
            margin-bottom: 8px;
        }
        .item-meta .source-badge {
            padding: 1px 8px;
            border-radius: 10px;
            font-size: 11px;
            font-weight: 600;
        }
        .source-github { background: #238636; color: #fff; }
        .source-hackernews { background: #f0652f; color: #fff; }
        .source-devto { background: #3b49df; color: #fff; }
        .item-desc {
            color: #8b949e;
            font-size: 14px;
            margin-top: 8px;
        }
        .tags { margin-top: 8px; }
        .tag {
            display: inline-block;
            background: #21262d;
            color: #8b949e;
            padding: 2px 10px;
            border-radius: 12px;
            font-size: 12px;
            margin: 2px 4px 2px 0;
        }
        .hype-bar {
            height: 4px;
            background: #21262d;
            border-radius: 2px;
            margin-top: 10px;
            overflow: hidden;
        }
        .hype-fill {
            height: 100%;
            border-radius: 2px;
            transition: width 0.5s;
        }
        .hype-high { background: linear-gradient(90deg, #238636, #3fb950); }
        .hype-mid { background: linear-gradient(90deg, #d29922, #e3b341); }
        .hype-low { background: linear-gradient(90deg, #30363d, #484f58); }
        .categories {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
            gap: 12px;
            margin-bottom: 24px;
        }
        .cat-card {
            background: #161b22;
            border: 1px solid #30363d;
            border-radius: 8px;
            padding: 14px;
            text-align: center;
        }
        .cat-card .count {
            font-size: 24px;
            font-weight: 700;
            color: #58a6ff;
        }
        .cat-card .name {
            font-size: 12px;
            color: #8b949e;
            margin-top: 4px;
        }
        .footer {
            text-align: center;
            padding: 30px;
            color: #484f58;
            font-size: 13px;
        }
        .footer a { color: #58a6ff; text-decoration: none; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>&#x1F4E1; {{ report.title }}</h1>
            <div class="subtitle">AI-Powered Trend Radar</div>
            <div class="meta">
                <span>&#x1F4C5; {{ report.generated_at.strftime('%B %d, %Y') }}</span>
                <span>&#x23F1; {{ report.period.title() }} Report</span>
                <span>&#x1F4CA; {{ report.total_items }} items analyzed</span>
            </div>
        </div>

        {% if report.summary %}
        <div class="summary">
            <h2>Summary</h2>
            <p>{{ report.summary }}</p>
        </div>
        {% endif %}

        {% if report.top_categories %}
        <div class="section">
            <h2>Top Categories</h2>
            <div class="categories">
                {% for cat_key, count in report.top_categories %}
                <div class="cat-card">
                    <div class="count">{{ count }}</div>
                    <div class="name">{{ cat_key }}</div>
                </div>
                {% endfor %}
            </div>
        </div>
        {% endif %}

        {% if report.emerging_trends %}
        <div class="section">
            <h2>Emerging Trends</h2>
            {% for item in report.emerging_trends[:10] %}
            <div class="emerging-banner">
                <div class="badge">EMERGING</div>
                <div class="item-title">
                    <a href="{{ item.url }}">{{ item.title }}</a>
                </div>
                <div class="item-meta">
                    <span>Hype: {{ "%.1f" | format(item.hype_score) }}</span>
                    <span>Velocity: {{ "%.1f" | format(item.velocity) }}</span>
                    {% if item.score %}<span>Score: {{ item.score | int }}</span>{% endif %}
                </div>
            </div>
            {% endfor %}
        </div>
        {% endif %}

        <div class="section">
            <h2>All Trending Items</h2>
            {% for item in report.items[:30] %}
            <div class="item">
                <div class="item-title">
                    <a href="{{ item.url }}">{{ item.title }}</a>
                </div>
                <div class="item-meta">
                    <span class="source-badge source-{{ item.source.value }}">
                        {{ item.source.value | upper }}
                    </span>
                    {% if item.stars %}<span>&#x2B50; {{ item.stars | int | format_number }}</span>{% endif %}
                    {% if item.score %}<span>&#x1F44D; {{ item.score | int }}</span>{% endif %}
                    {% if item.comments %}<span>&#x1F4AC; {{ item.comments | int }}</span>{% endif %}
                    <span>{{ item.category.value }}</span>
                    <span>Hype: {{ "%.1f" | format(item.hype_score) }}</span>
                </div>
                {% if item.description %}
                <div class="item-desc">{{ item.description[:200] }}</div>
                {% endif %}
                {% if item.tags %}
                <div class="tags">
                    {% for tag in item.tags[:6] %}
                    <span class="tag">{{ tag }}</span>
                    {% endfor %}
                </div>
                {% endif %}
                <div class="hype-bar">
                    <div class="hype-fill {{ 'hype-high' if item.hype_score >= 50 else ('hype-mid' if item.hype_score >= 25 else 'hype-low') }}"
                         style="width: {{ item.hype_score }}%"></div>
                </div>
            </div>
            {% endfor %}
        </div>

        <div class="footer">
            <p>Generated by <a href="https://github.com/your-username/ai-trend-radar">AITrendRadar</a></p>
            <p>{{ report.generated_at.strftime('%Y-%m-%d %H:%M UTC') }}</p>
        </div>
    </div>
</body>
</html>"""


class HtmlReporter:
    """Generates HTML newsletter reports."""

    def __init__(self, output_dir: Path | str | None = None) -> None:
        from ..config import get_config
        self.output_dir = Path(output_dir) if output_dir else get_config().output_dir
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.categorizer = Categorizer()

    def generate(self, report: TrendReport) -> Path:
        """Generate an HTML report file."""
        env = Environment(loader=BaseLoader(), autoescape=True)
        env.filters["format_number"] = lambda v: f"{v:,}"
        template = env.from_string(HTML_TEMPLATE)

        html = template.render(
            report=report,
            categorizer=self.categorizer,
        )

        filename = f"trend-report-{report.generated_at.strftime('%Y%m%d-%H%M%S')}.html"
        filepath = self.output_dir / filename
        filepath.write_text(html, encoding="utf-8")
        logger.info("HTML report saved to %s", filepath)
        return filepath
