"""Data models for trend items."""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any


class Source(str, Enum):
    """Data source for a trend item."""
    GITHUB = "github"
    HACKERNEWS = "hackernews"
    DEVTO = "devto"


class Category(str, Enum):
    """Trend category."""
    AI_ML = "ai-ml"
    WEB = "web"
    MOBILE = "mobile"
    DEVOPS = "devops"
    SECURITY = "security"
    DATABASES = "databases"
    LANGUAGES = "languages"
    TOOLS = "tools"
    OPEN_SOURCE = "open-source"
    CLOUD = "cloud"
    BLOCKCHAIN = "blockchain"
    GAMING = "gaming"
    DATA_SCIENCE = "data-science"
    OTHER = "other"


@dataclass
class TrendItem:
    """A single trend item from any source."""
    source: Source
    title: str
    url: str
    description: str = ""
    author: str = ""
    score: int = 0
    stars: int = 0
    comments: int = 0
    language: str = ""
    category: Category = Category.OTHER
    hype_score: float = 0.0
    velocity: float = 0.0
    is_emerging: bool = False
    tags: list[str] = field(default_factory=list)
    fetched_at: datetime = field(default_factory=datetime.utcnow)
    created_at: datetime | None = None
    raw_data: dict[str, Any] = field(default_factory=dict)

    @property
    def uid(self) -> str:
        """Unique identifier for this trend item based on source + url."""
        raw = f"{self.source.value}:{self.url}"
        return hashlib.sha256(raw.encode()).hexdigest()[:16]

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "uid": self.uid,
            "source": self.source.value,
            "title": self.title,
            "url": self.url,
            "description": self.description,
            "author": self.author,
            "score": self.score,
            "stars": self.stars,
            "comments": self.comments,
            "language": self.language,
            "category": self.category.value,
            "hype_score": round(self.hype_score, 2),
            "velocity": round(self.velocity, 2),
            "is_emerging": self.is_emerging,
            "tags": self.tags,
            "fetched_at": self.fetched_at.isoformat() if self.fetched_at else None,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TrendItem:
        """Create from dictionary."""
        data["source"] = Source(data["source"])
        data["category"] = Category(data.get("category", "other"))
        if isinstance(data.get("fetched_at"), str):
            data["fetched_at"] = datetime.fromisoformat(data["fetched_at"])
        if isinstance(data.get("created_at"), str):
            data["created_at"] = datetime.fromisoformat(data["created_at"])
        data.pop("uid", None)
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


@dataclass
class TrendReport:
    """A generated trend report."""
    title: str
    period: str
    generated_at: datetime = field(default_factory=datetime.utcnow)
    items: list[TrendItem] = field(default_factory=list)
    top_categories: list[tuple[str, int]] = field(default_factory=list)
    emerging_trends: list[TrendItem] = field(default_factory=list)
    summary: str = ""

    @property
    def total_items(self) -> int:
        return len(self.items)

    def to_dict(self) -> dict[str, Any]:
        return {
            "title": self.title,
            "period": self.period,
            "generated_at": self.generated_at.isoformat(),
            "total_items": self.total_items,
            "items": [item.to_dict() for item in self.items],
            "top_categories": self.top_categories,
            "emerging_trends": [item.to_dict() for item in self.emerging_trends],
            "summary": self.summary,
        }
