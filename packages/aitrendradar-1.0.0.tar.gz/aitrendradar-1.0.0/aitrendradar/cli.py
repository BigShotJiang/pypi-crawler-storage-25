"""CLI interface for AITrendRadar using Click."""

from __future__ import annotations

import logging
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

import click
from rich.logging import RichHandler

from . import __version__
from .config import Config, get_config, set_config
from .database import TrendDatabase
from .analyzers.report_generator import ReportGenerator
from .reporters.console_reporter import ConsoleReporter
from .reporters.markdown_reporter import MarkdownReporter
from .reporters.json_reporter import JsonReporter
from .reporters.html_reporter import HtmlReporter
from .sources.github import GitHubSource
from .sources.hackernews import HackerNewsSource
from .sources.devto import DevToSource

logger = logging.getLogger(__name__)


def setup_logging(verbose: bool = False) -> None:
    """Configure logging with Rich handler."""
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(message)s",
        datefmt="[%X]",
        handlers=[RichHandler(
            rich_tracebacks=True,
            show_path=False,
            markup=True,
        )],
    )


@click.group()
@click.version_option(version=__version__, prog_name="AITrendRadar")
@click.option("-v", "--verbose", is_flag=True, help="Enable verbose logging")
@click.option("-o", "--output-dir", type=click.Path(), help="Output directory")
@click.option("--db-path", type=click.Path(), help="Database file path")
def main(verbose: bool, output_dir: str | None, db_path: str | None) -> None:
    """AITrendRadar - AI-powered trend radar for tech.

    Never miss the next big thing in tech.
    """
    setup_logging(verbose)

    cfg = Config.from_env()
    if output_dir:
        cfg.output_dir = Path(output_dir)
        cfg.db_path = str(cfg.output_dir / "trends.db")
    if db_path:
        cfg.db_path = db_path
    set_config(cfg)


@main.command()
@click.option(
    "--sources", "-s",
    multiple=True,
    type=click.Choice(["github", "hackernews", "devto", "all"]),
    default=["all"],
    help="Data sources to fetch from",
)
@click.option(
    "--period", "-p",
    type=click.Choice(["daily", "weekly", "monthly"]),
    default="weekly",
    help="Report period",
)
@click.option(
    "--format", "-f", "fmt",
    multiple=True,
    type=click.Choice(["console", "markdown", "json", "html", "all"]),
    default=["console"],
    help="Output format(s)",
)
@click.option("--max-items", type=int, default=30, help="Max items per source")
@click.option("--no-fetch", is_flag=True, help="Use cached data only")
def scan(
    sources: tuple[str, ...],
    period: str,
    fmt: tuple[str, ...],
    max_items: int,
    no_fetch: bool,
) -> None:
    """Fetch trending data and generate a report."""
    from rich.console import Console
    console = Console()

    console.print(f"\n[bold bright_blue]AITrendRadar v{__version__}[/bold bright_blue]")
    console.print(f"[dim]Scanning for trends ({period})...[/dim]\n")

    # Resolve sources
    if "all" in sources:
        active_sources = ["github", "hackernews", "devto"]
    else:
        active_sources = list(sources)

    # Fetch items
    items = []
    if not no_fetch:
        items = _fetch_all(active_sources, period, max_items, console)
    else:
        # Load from database
        db = TrendDatabase()
        items = db.get_items(limit=max_items * len(active_sources))
        if not items:
            console.print("[yellow]No cached data found. Run without --no-fetch first.[/yellow]")
            return

    if not items:
        console.print("[red]No items collected. Check your network connection.[/red]")
        return

    console.print(f"\n[green]Collected {len(items)} items total.[/green]")

    # Generate report
    report_gen = ReportGenerator()
    report = report_gen.generate_report(items, period=period)

    # Output in requested formats
    if "all" in fmt:
        output_formats = ["console", "markdown", "json", "html"]
    else:
        output_formats = list(fmt)

    for f in output_formats:
        if f == "console":
            reporter = ConsoleReporter()
            reporter.display(report)
        elif f == "markdown":
            reporter = MarkdownReporter()
            path = reporter.generate(report)
            console.print(f"[green]Markdown report:[/green] {path}")
        elif f == "json":
            reporter = JsonReporter()
            path = reporter.generate(report)
            console.print(f"[green]JSON report:[/green] {path}")
        elif f == "html":
            reporter = HtmlReporter()
            path = reporter.generate(report)
            console.print(f"[green]HTML report:[/green] {path}")


@main.command()
@click.option("--days", type=int, default=7, help="Show items from last N days")
@click.option(
    "--source", "-s",
    type=click.Choice(["github", "hackernews", "devto"]),
    default=None,
    help="Filter by source",
)
@click.option("--category", type=str, default=None, help="Filter by category")
@click.option("--limit", type=int, default=20, help="Max items to show")
def show(days: int, source: str | None, category: str | None, limit: int) -> None:
    """Show cached trend data from the database."""
    from .models import Source, Category

    db = TrendDatabase()
    src = Source(source) if source else None
    cat = None
    if category:
        try:
            cat = Category(category)
        except ValueError:
            click.echo(f"Invalid category: {category}")
            return

    items = db.get_items(source=src, category=cat, days=days, limit=limit)

    if not items:
        click.echo("No items found. Run 'trendradar scan' first.")
        return

    reporter = ConsoleReporter()
    reporter.display_items(items, title=f"Trending Items (last {days} days)")


@main.command()
def stats() -> None:
    """Show database statistics."""
    from rich.console import Console
    from rich.table import Table

    console = Console()
    db = TrendDatabase()
    data = db.get_stats()

    console.print("\n[bold bright_blue]AITrendRadar Statistics[/bold bright_blue]\n")

    table = Table(show_header=False, border_style="dim")
    table.add_column("Metric", style="bold")
    table.add_column("Value")

    table.add_row("Total items", str(data["total_items"]))
    table.add_row("Emerging trends", str(data["emerging_count"]))
    table.add_row("Latest fetch", data["latest_fetch"] or "Never")

    for source, count in data["by_source"].items():
        table.add_row(f"  {source}", str(count))

    console.print(table)
    console.print()


@main.command()
@click.option("--days", type=int, default=90, help="Remove items older than N days")
def cleanup(days: int) -> None:
    """Remove old data from the database."""
    db = TrendDatabase()
    deleted = db.cleanup_old(days)
    click.echo(f"Removed {deleted} items older than {days} days.")


@main.command()
@click.option("--host", default="127.0.0.1", help="Host to bind to")
@click.option("--port", type=int, default=5000, help="Port to bind to")
@click.option("--debug", is_flag=True, help="Enable debug mode")
def web(host: str, port: int, debug: bool) -> None:
    """Launch the web dashboard."""
    try:
        from .web.app import create_app
    except ImportError:
        click.echo("Flask is required for the web dashboard. Install with: pip install flask")
        return

    app = create_app()
    click.echo(f"Starting web dashboard at http://{host}:{port}")
    app.run(host=host, port=port, debug=debug)


@main.command()
def sources_info() -> None:
    """Show information about available data sources."""
    from rich.console import Console
    from rich.table import Table

    console = Console()
    console.print("\n[bold bright_blue]Available Data Sources[/bold bright_blue]\n")

    table = Table(show_header=True, header_style="bold")
    table.add_column("Source")
    table.add_column("API")
    table.add_column("Rate Limit")
    table.add_column("Data")

    table.add_row(
        "GitHub",
        "api.github.com",
        "60/hr (unauth), 5000/hr (token)",
        "Repos, stars, forks, topics",
    )
    table.add_row(
        "Hacker News",
        "firebase.io",
        "None (be nice)",
        "Stories, score, comments",
    )
    table.add_row(
        "DevTo",
        "dev.to/api",
        "None (be nice)",
        "Articles, reactions, tags",
    )

    console.print(table)
    console.print()


def _fetch_all(
    sources: list[str],
    period: str,
    max_items: int,
    console: Any,
) -> list:
    """Fetch from all specified sources."""
    items = []

    for source_name in sources:
        console.print(f"  [dim]Fetching from [bold]{source_name}[/bold]...[/dim]")
        try:
            if source_name == "github":
                source = GitHubSource()
                items.extend(source.fetch(since=period, max_items=max_items))
            elif source_name == "hackernews":
                source = HackerNewsSource()
                items.extend(source.fetch(max_items=max_items))
            elif source_name == "devto":
                source = DevToSource()
                top_days = {"daily": 1, "weekly": 7, "monthly": 30}.get(period, 7)
                items.extend(source.fetch(max_items=max_items, top=top_days))
        except Exception as e:
            logger.error("Failed to fetch from %s: %s", source_name, e)
            console.print(f"    [red]Error: {e}[/red]")

    return items


if __name__ == "__main__":
    main()
