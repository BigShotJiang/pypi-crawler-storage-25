"""Pytest configuration and shared fixtures."""

from __future__ import annotations

import os
import tempfile
from datetime import datetime
from pathlib import Path
from typing import Any

import pytest

from aitrendradar.config import Config, set_config
from aitrendradar.database import TrendDatabase
from aitrendradar.models import Category, Source, TrendItem


@pytest.fixture
def temp_dir(tmp_path: Path) -> Path:
    """Provide a temporary directory for test output."""
    return tmp_path


@pytest.fixture
def test_config(temp_dir: Path) -> Config:
    """Provide a test configuration with temp paths."""
    cfg = Config(
        output_dir=temp_dir,
        db_path=str(temp_dir / "test_trends.db"),
        request_timeout=5,
        rate_limit_delay=0,
        max_retries=1,
        github_token="",
        max_items_per_source=10,
    )
    set_config(cfg)
    return cfg


@pytest.fixture
def test_db(test_config: Config) -> TrendDatabase:
    """Provide a test database."""
    return TrendDatabase(test_config.db_path)


@pytest.fixture
def sample_github_items() -> list[TrendItem]:
    """Provide sample GitHub trend items."""
    items = []
    for i in range(5):
        items.append(TrendItem(
            source=Source.GITHUB,
            title=f"test-org/awesome-repo-{i}",
            url=f"https://github.com/test-org/awesome-repo-{i}",
            description=f"An awesome test repository #{i}",
            author=f"author-{i}",
            score=1000 + i * 200,
            stars=500 + i * 100,
            comments=50 + i * 10,
            language="python",
            category=Category.AI_ML,
            tags=["machine-learning", "python", "ai"],
            fetched_at=datetime.utcnow(),
            created_at=datetime.utcnow(),
            raw_data={"forks": 100 + i * 20, "watchers": 50 + i * 10},
        ))
    return items


@pytest.fixture
def sample_hn_items() -> list[TrendItem]:
    """Provide sample Hacker News items."""
    items = []
    for i in range(5):
        items.append(TrendItem(
            source=Source.HACKERNEWS,
            title=f"Show HN: Cool new framework {i}",
            url=f"https://example.com/framework-{i}",
            description="",
            author=f"user-{i}",
            score=300 + i * 50,
            stars=0,
            comments=80 + i * 15,
            category=Category.WEB,
            tags=["web", "framework"],
            fetched_at=datetime.utcnow(),
            created_at=datetime.utcnow(),
            raw_data={"hn_id": 10000 + i},
        ))
    return items


@pytest.fixture
def sample_devto_items() -> list[TrendItem]:
    """Provide sample DevTo items."""
    items = []
    for i in range(5):
        items.append(TrendItem(
            source=Source.DEVTO,
            title=f"Understanding Rust Ownership Part {i}",
            url=f"https://dev.to/testuser/rust-ownership-{i}",
            description=f"Deep dive into Rust ownership model - part {i}",
            author=f"testuser-{i}",
            score=200 + i * 30,
            stars=150 + i * 20,
            comments=30 + i * 5,
            category=Category.LANGUAGES,
            tags=["rust", "programming", "tutorial"],
            fetched_at=datetime.utcnow(),
            created_at=datetime.utcnow(),
            raw_data={"reading_time": 10 + i},
        ))
    return items


@pytest.fixture
def all_sample_items(
    sample_github_items: list[TrendItem],
    sample_hn_items: list[TrendItem],
    sample_devto_items: list[TrendItem],
) -> list[TrendItem]:
    """Provide combined sample items from all sources."""
    return sample_github_items + sample_hn_items + sample_devto_items
