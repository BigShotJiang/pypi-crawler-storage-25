"""Tests for the database module."""

from datetime import datetime, timedelta

from aitrendradar.models import Category, Source, TrendItem
from aitrendradar.database import TrendDatabase


class TestTrendDatabase:
    def test_init_creates_db(self, test_config):
        db = TrendDatabase(test_config.db_path)
        assert db.db_path == test_config.db_path

    def test_insert_item(self, test_db, sample_github_items):
        item = sample_github_items[0]
        result = test_db.insert_item(item)
        assert result is True  # New item

    def test_insert_duplicate_updates(self, test_db, sample_github_items):
        item = sample_github_items[0]
        test_db.insert_item(item)

        # Modify and re-insert
        item.score = 9999
        result = test_db.insert_item(item)
        assert result is False  # Updated, not new

    def test_insert_items_bulk(self, test_db, sample_github_items):
        new, updated = test_db.insert_items(sample_github_items)
        assert new == 5
        assert updated == 0

    def test_get_items_all(self, test_db, sample_github_items):
        test_db.insert_items(sample_github_items)
        items = test_db.get_items()
        assert len(items) == 5

    def test_get_items_by_source(self, test_db, all_sample_items):
        test_db.insert_items(all_sample_items)

        github_items = test_db.get_items(source=Source.GITHUB)
        assert all(i.source == Source.GITHUB for i in github_items)
        assert len(github_items) == 5

    def test_get_items_by_category(self, test_db, all_sample_items):
        test_db.insert_items(all_sample_items)

        ai_items = test_db.get_items(category=Category.AI_ML)
        assert all(i.category == Category.AI_ML for i in ai_items)

    def test_get_items_with_limit(self, test_db, sample_github_items):
        test_db.insert_items(sample_github_items)
        items = test_db.get_items(limit=3)
        assert len(items) == 3

    def test_get_items_by_days(self, test_db, sample_github_items):
        test_db.insert_items(sample_github_items)
        items = test_db.get_items(days=1)
        assert len(items) == 5  # All items are recent

    def test_get_items_min_hype(self, test_db, sample_github_items):
        for item in sample_github_items:
            item.hype_score = 50.0
        test_db.insert_items(sample_github_items)

        items = test_db.get_items(min_hype=30.0)
        assert all(i.hype_score >= 30.0 for i in items)

    def test_get_previous_score(self, test_db, sample_github_items):
        item = sample_github_items[0]
        test_db.insert_item(item)

        prev = test_db.get_previous_score(item.uid)
        assert prev is not None
        assert prev["score"] == item.score
        assert prev["stars"] == item.stars

    def test_get_previous_score_nonexistent(self, test_db):
        prev = test_db.get_previous_score("nonexistent")
        assert prev is None

    def test_get_category_counts(self, test_db, all_sample_items):
        test_db.insert_items(all_sample_items)
        counts = test_db.get_category_counts(days=7)
        assert len(counts) > 0
        # Should have at least ai-ml and web categories
        categories = [c for c, _ in counts]
        assert "ai-ml" in categories
        assert "web" in categories

    def test_get_trending_emerging(self, test_db, sample_github_items):
        for item in sample_github_items[:2]:
            item.is_emerging = True
            item.velocity = 50.0
        test_db.insert_items(sample_github_items)

        emerging = test_db.get_trending_emerging()
        assert len(emerging) == 2
        assert all(e.is_emerging for e in emerging)

    def test_get_stats(self, test_db, all_sample_items):
        test_db.insert_items(all_sample_items)
        stats = test_db.get_stats()

        assert stats["total_items"] == 15
        assert "github" in stats["by_source"]
        assert "hackernews" in stats["by_source"]
        assert "devto" in stats["by_source"]
        assert stats["latest_fetch"] is not None

    def test_cleanup_old(self, test_db, sample_github_items):
        test_db.insert_items(sample_github_items)

        # Insert an old item manually
        old_item = TrendItem(
            source=Source.GITHUB,
            title="old/repo",
            url="https://github.com/old/repo",
            fetched_at=datetime(2020, 1, 1),
        )
        test_db.insert_item(old_item)

        deleted = test_db.cleanup_old(days=90)
        assert deleted == 1

        # Recent items should still exist
        items = test_db.get_items()
        assert len(items) == 5

    def test_items_ordered_by_hype(self, test_db, sample_github_items):
        for i, item in enumerate(sample_github_items):
            item.hype_score = (4 - i) * 20.0  # Descending
        test_db.insert_items(sample_github_items)

        items = test_db.get_items()
        scores = [i.hype_score for i in items]
        assert scores == sorted(scores, reverse=True)
