"""Tests for data sources."""

from datetime import datetime
from unittest.mock import MagicMock, patch

from aitrendradar.models import Category, Source, TrendItem
from aitrendradar.sources.github import GitHubSource
from aitrendradar.sources.hackernews import HackerNewsSource
from aitrendradar.sources.devto import DevToSource
from aitrendradar.sources.base import BaseSource


class TestBaseSource:
    def test_validate_url_valid(self, test_config):
        source = GitHubSource()
        assert source.validate_url("https://example.com")
        assert source.validate_url("http://example.com/path")

    def test_validate_url_invalid(self, test_config):
        source = GitHubSource()
        assert not source.validate_url("ftp://example.com")
        assert not source.validate_url("not-a-url")
        assert not source.validate_url("")

    def test_sanitize_text_normal(self, test_config):
        source = GitHubSource()
        assert source.sanitize_text("Hello World") == "Hello World"

    def test_sanitize_text_empty(self, test_config):
        source = GitHubSource()
        assert source.sanitize_text("") == ""

    def test_sanitize_text_truncation(self, test_config):
        source = GitHubSource()
        long_text = "x" * 600
        result = source.sanitize_text(long_text, max_length=100)
        assert len(result) == 100
        assert result.endswith("...")

    def test_sanitize_text_null_bytes(self, test_config):
        source = GitHubSource()
        result = source.sanitize_text("hello\x00world")
        assert "\x00" not in result


class TestGitHubSource:
    def _mock_repo_response(self):
        return {
            "items": [
                {
                    "id": 1,
                    "full_name": "test-org/ai-framework",
                    "name": "ai-framework",
                    "html_url": "https://github.com/test-org/ai-framework",
                    "description": "An AI framework for building LLM apps",
                    "language": "Python",
                    "stargazers_count": 5000,
                    "forks_count": 500,
                    "watchers_count": 200,
                    "open_issues_count": 50,
                    "owner": {"login": "test-org"},
                    "topics": ["ai", "llm", "machine-learning"],
                    "created_at": "2024-01-15T12:00:00Z",
                    "archived": False,
                },
                {
                    "id": 2,
                    "full_name": "test-org/react-toolkit",
                    "name": "react-toolkit",
                    "html_url": "https://github.com/test-org/react-toolkit",
                    "description": "React component library",
                    "language": "TypeScript",
                    "stargazers_count": 3000,
                    "forks_count": 300,
                    "watchers_count": 100,
                    "open_issues_count": 20,
                    "owner": {"login": "test-org"},
                    "topics": ["react", "frontend", "ui"],
                    "created_at": "2024-01-14T10:00:00Z",
                    "archived": False,
                },
            ]
        }

    @patch.object(GitHubSource, "_make_request")
    def test_fetch_returns_items(self, mock_request, test_config):
        mock_request.return_value = self._mock_repo_response()
        source = GitHubSource()
        items = source.fetch(max_items=10)

        assert len(items) >= 1
        assert all(isinstance(i, TrendItem) for i in items)
        assert all(i.source == Source.GITHUB for i in items)

    @patch.object(GitHubSource, "_make_request")
    def test_fetch_categorizes_ai(self, mock_request, test_config):
        mock_request.return_value = self._mock_repo_response()
        source = GitHubSource()
        items = source.fetch(max_items=10)

        ai_items = [i for i in items if "ai" in i.title.lower() or i.category == Category.AI_ML]
        assert len(ai_items) >= 1

    @patch.object(GitHubSource, "_make_request")
    def test_fetch_categorizes_web(self, mock_request, test_config):
        mock_request.return_value = self._mock_repo_response()
        source = GitHubSource()
        items = source.fetch(max_items=10)

        web_items = [i for i in items if i.category == Category.WEB]
        assert len(web_items) >= 1

    @patch.object(GitHubSource, "_make_request")
    def test_fetch_handles_empty_response(self, mock_request, test_config):
        mock_request.return_value = None
        source = GitHubSource()
        items = source.fetch(max_items=10)
        assert items == []

    @patch.object(GitHubSource, "_make_request")
    def test_parse_repo_extracts_tags(self, mock_request, test_config):
        mock_request.return_value = self._mock_repo_response()
        source = GitHubSource()
        items = source.fetch(max_items=10)

        assert any("ai" in item.tags or "machine-learning" in item.tags for item in items)


class TestHackerNewsSource:
    def _mock_story_ids(self):
        return [100001, 100002, 100003]

    def _mock_story(self, story_id, title="Test Story", score=100, descendants=50):
        return {
            "id": story_id,
            "type": "story",
            "title": title,
            "url": f"https://example.com/story/{story_id}",
            "by": f"user-{story_id}",
            "score": score,
            "descendants": descendants,
            "time": 1705312800,
            "kids": [200001, 200002],
        }

    @patch.object(HackerNewsSource, "_make_request")
    def test_fetch_returns_items(self, mock_request, test_config):
        mock_request.side_effect = [
            self._mock_story_ids(),
            self._mock_story(100001, "New AI framework released"),
            self._mock_story(100002, "Docker 2.0 launched"),
            self._mock_story(100003, "Rust reaches 1.0"),
        ]
        source = HackerNewsSource()
        items = source.fetch(max_items=3)

        assert len(items) == 3
        assert all(i.source == Source.HACKERNEWS for i in items)

    @patch.object(HackerNewsSource, "_make_request")
    def test_fetch_categorizes_by_title(self, mock_request, test_config):
        mock_request.side_effect = [
            self._mock_story_ids(),
            self._mock_story(100001, "New GPT model breaks records"),
            self._mock_story(100002, "Docker Kubernetes deployment guide"),
            self._mock_story(100003, "Critical security vulnerability found"),
        ]
        source = HackerNewsSource()
        items = source.fetch(max_items=3)

        categories = [i.category for i in items]
        assert Category.AI_ML in categories
        assert Category.DEVOPS in categories
        assert Category.SECURITY in categories

    @patch.object(HackerNewsSource, "_make_request")
    def test_fetch_handles_no_url_self_post(self, mock_request, test_config):
        story_no_url = {
            "id": 100004,
            "type": "story",
            "title": "Ask HN: Best practices for code review?",
            "url": "",
            "by": "asker",
            "score": 50,
            "descendants": 100,
            "time": 1705312800,
        }
        mock_request.side_effect = [
            [100004],
            story_no_url,
        ]
        source = HackerNewsSource()
        items = source.fetch(max_items=1)

        assert len(items) == 1
        assert "news.ycombinator.com" in items[0].url

    @patch.object(HackerNewsSource, "_make_request")
    def test_fetch_handles_empty_ids(self, mock_request, test_config):
        mock_request.return_value = None
        source = HackerNewsSource()
        items = source.fetch(max_items=5)
        assert items == []


class TestDevToSource:
    def _mock_articles(self):
        return [
            {
                "id": 1,
                "title": "Understanding React Server Components",
                "url": "https://dev.to/testuser/react-server-components",
                "description": "A deep dive into RSC",
                "positive_reactions_count": 150,
                "comments_count": 30,
                "public_reactions_count": 180,
                "reading_time_minutes": 12,
                "user": {"username": "testuser"},
                "tag_list": ["react", "javascript", "webdev"],
                "cover_image": "https://example.com/cover.jpg",
                "published_at": "2024-01-15T10:00:00Z",
                "path": "/testuser/react-server-components",
                "canonical_url": "https://dev.to/testuser/react-server-components",
            },
            {
                "id": 2,
                "title": "Getting Started with Machine Learning in Python",
                "url": "https://dev.to/testuser/ml-python",
                "description": "Beginner guide to ML",
                "positive_reactions_count": 200,
                "comments_count": 45,
                "public_reactions_count": 250,
                "reading_time_minutes": 15,
                "user": {"username": "mlauthor"},
                "tag_list": ["python", "machinelearning", "ai"],
                "cover_image": "",
                "published_at": "2024-01-14T08:00:00Z",
                "path": "/testuser/ml-python",
                "canonical_url": "https://dev.to/testuser/ml-python",
            },
        ]

    @patch.object(DevToSource, "_make_request")
    def test_fetch_returns_items(self, mock_request, test_config):
        mock_request.return_value = self._mock_articles()
        source = DevToSource()
        items = source.fetch(max_items=10)

        assert len(items) == 2
        assert all(i.source == Source.DEVTO for i in items)

    @patch.object(DevToSource, "_make_request")
    def test_fetch_categorizes_by_tags(self, mock_request, test_config):
        mock_request.return_value = self._mock_articles()
        source = DevToSource()
        items = source.fetch(max_items=10)

        categories = [i.category for i in items]
        # First article: tags ["react", "javascript", "webdev"] -> WEB
        # Second article: tags ["python", "machinelearning", "ai"] -> LANGUAGES (python checked first)
        assert Category.WEB in categories or Category.LANGUAGES in categories

    @patch.object(DevToSource, "_make_request")
    def test_fetch_extracts_tags(self, mock_request, test_config):
        mock_request.return_value = self._mock_articles()
        source = DevToSource()
        items = source.fetch(max_items=10)

        assert any("react" in item.tags for item in items)
        assert any("python" in item.tags for item in items)

    @patch.object(DevToSource, "_make_request")
    def test_fetch_handles_empty_response(self, mock_request, test_config):
        mock_request.return_value = None
        source = DevToSource()
        items = source.fetch(max_items=10)
        assert items == []

    @patch.object(DevToSource, "_make_request")
    def test_fetch_with_tag_filter(self, mock_request, test_config):
        mock_request.return_value = self._mock_articles()
        source = DevToSource()
        items = source.fetch(max_items=10, tag="python")
        mock_request.assert_called_once()
        call_args = mock_request.call_args
        assert "tag" in call_args[1].get("params", {}) or call_args[0][1]
