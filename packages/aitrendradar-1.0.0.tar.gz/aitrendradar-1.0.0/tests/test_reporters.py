"""Tests for reporter modules."""

import json
from datetime import datetime
from pathlib import Path

from aitrendradar.models import Category, Source, TrendItem, TrendReport
from aitrendradar.reporters.json_reporter import JsonReporter
from aitrendradar.reporters.markdown_reporter import MarkdownReporter
from aitrendradar.reporters.html_reporter import HtmlReporter
from aitrendradar.reporters.console_reporter import ConsoleReporter


def _make_report(items=None, emerging=None):
    """Create a test report."""
    if items is None:
        items = [
            TrendItem(
                source=Source.GITHUB,
                title="test/awesome-ai",
                url="https://github.com/test/awesome-ai",
                description="An awesome AI library",
                stars=5000,
                score=6000,
                comments=200,
                category=Category.AI_ML,
                hype_score=75.5,
                velocity=30.0,
                is_emerging=True,
                tags=["ai", "python", "llm"],
                author="testdev",
                language="python",
                fetched_at=datetime.utcnow(),
                created_at=datetime.utcnow(),
            ),
            TrendItem(
                source=Source.HACKERNEWS,
                title="Show HN: New web framework",
                url="https://example.com/framework",
                description="A blazingly fast web framework",
                score=500,
                comments=150,
                category=Category.WEB,
                hype_score=45.2,
                tags=["web", "javascript"],
                author="hnuser",
                fetched_at=datetime.utcnow(),
                created_at=datetime.utcnow(),
            ),
        ]
    return TrendReport(
        title="Test Report",
        period="weekly",
        items=items,
        emerging_trends=emerging or items[:1],
        top_categories=[("ai-ml", 1), ("web", 1)],
        summary="Test summary with 2 items.",
    )


class TestJsonReporter:
    def test_generate_creates_file(self, temp_dir):
        reporter = JsonReporter(output_dir=temp_dir)
        report = _make_report()
        path = reporter.generate(report)

        assert path.exists()
        assert path.suffix == ".json"

    def test_generate_valid_json(self, temp_dir):
        reporter = JsonReporter(output_dir=temp_dir)
        report = _make_report()
        path = reporter.generate(report)

        content = path.read_text(encoding="utf-8")
        data = json.loads(content)
        assert "items" in data
        assert data["total_items"] == 2
        assert data["title"] == "Test Report"

    def test_save_items(self, temp_dir):
        reporter = JsonReporter(output_dir=temp_dir)
        items = [
            TrendItem(source=Source.GITHUB, title="test", url="https://example.com"),
        ]
        path = reporter.save_items(items, "test-items.json")
        assert path.exists()

        data = json.loads(path.read_text(encoding="utf-8"))
        assert len(data) == 1


class TestMarkdownReporter:
    def test_generate_creates_file(self, temp_dir):
        reporter = MarkdownReporter(output_dir=temp_dir)
        report = _make_report()
        path = reporter.generate(report)

        assert path.exists()
        assert path.suffix == ".md"

    def test_generate_contains_sections(self, temp_dir):
        reporter = MarkdownReporter(output_dir=temp_dir)
        report = _make_report()
        path = reporter.generate(report)

        content = path.read_text(encoding="utf-8")
        assert "# " in content
        assert "## Summary" in content
        assert "## Emerging Trends" in content
        assert "## Top Categories" in content
        assert "AITrendRadar" in content

    def test_generate_contains_item_titles(self, temp_dir):
        reporter = MarkdownReporter(output_dir=temp_dir)
        report = _make_report()
        path = reporter.generate(report)

        content = path.read_text(encoding="utf-8")
        assert "awesome-ai" in content
        assert "web framework" in content

    def test_generate_empty_report(self, temp_dir):
        reporter = MarkdownReporter(output_dir=temp_dir)
        report = TrendReport(title="Empty", period="daily")
        path = reporter.generate(report)
        assert path.exists()


class TestHtmlReporter:
    def test_generate_creates_file(self, temp_dir):
        reporter = HtmlReporter(output_dir=temp_dir)
        report = _make_report()
        path = reporter.generate(report)

        assert path.exists()
        assert path.suffix == ".html"

    def test_generate_valid_html(self, temp_dir):
        reporter = HtmlReporter(output_dir=temp_dir)
        report = _make_report()
        path = reporter.generate(report)

        content = path.read_text(encoding="utf-8")
        assert "<!DOCTYPE html>" in content
        assert "</html>" in content
        assert "AITrendRadar" in content

    def test_generate_contains_items(self, temp_dir):
        reporter = HtmlReporter(output_dir=temp_dir)
        report = _make_report()
        path = reporter.generate(report)

        content = path.read_text(encoding="utf-8")
        assert "awesome-ai" in content
        assert "web framework" in content

    def test_generate_contains_emerging_section(self, temp_dir):
        reporter = HtmlReporter(output_dir=temp_dir)
        report = _make_report()
        path = reporter.generate(report)

        content = path.read_text(encoding="utf-8")
        assert "Emerging" in content

    def test_generate_empty_report(self, temp_dir):
        reporter = HtmlReporter(output_dir=temp_dir)
        report = TrendReport(title="Empty", period="daily")
        path = reporter.generate(report)
        assert path.exists()


class TestConsoleReporter:
    def test_display_does_not_crash(self, capsys):
        reporter = ConsoleReporter()
        report = _make_report()
        # Should not raise
        reporter.display(report)

    def test_display_items_does_not_crash(self, capsys):
        reporter = ConsoleReporter()
        items = [
            TrendItem(source=Source.GITHUB, title="test", url="https://example.com",
                      category=Category.AI_ML, hype_score=50.0, score=100),
        ]
        reporter.display_items(items, title="Test Items")
