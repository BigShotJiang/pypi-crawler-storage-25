"""Tests for analyzers: hype scorer, trend detector, categorizer."""

from datetime import datetime, timedelta

from aitrendradar.models import Category, Source, TrendItem
from aitrendradar.analyzers.hype_scorer import HypeScorer
from aitrendradar.analyzers.trend_detector import TrendDetector
from aitrendradar.analyzers.categorizer import Categorizer
from aitrendradar.analyzers.report_generator import ReportGenerator
from aitrendradar.database import TrendDatabase


class TestHypeScorer:
    def test_score_returns_float(self, test_config):
        scorer = HypeScorer()
        item = TrendItem(
            source=Source.GITHUB,
            title="test/repo",
            url="https://github.com/test/repo",
            stars=1000,
            score=1200,
            comments=100,
        )
        score = scorer.score(item)
        assert isinstance(score, float)
        assert 0 <= score <= 100

    def test_high_stars_get_higher_score(self, test_config):
        scorer = HypeScorer()
        low_item = TrendItem(
            source=Source.GITHUB, title="low", url="https://example.com/low",
            stars=10, score=10, comments=1,
        )
        high_item = TrendItem(
            source=Source.GITHUB, title="high", url="https://example.com/high",
            stars=50000, score=60000, comments=500,
        )
        low_score = scorer.score(low_item)
        high_score = scorer.score(high_item)
        assert high_score > low_score

    def test_score_items_sorts_by_hype(self, test_config):
        scorer = HypeScorer()
        items = [
            TrendItem(source=Source.GITHUB, title="low", url="https://example.com/1",
                      stars=10, score=10),
            TrendItem(source=Source.GITHUB, title="high", url="https://example.com/2",
                      stars=50000, score=60000),
            TrendItem(source=Source.GITHUB, title="mid", url="https://example.com/3",
                      stars=1000, score=1200),
        ]
        scored = scorer.score_items(items)
        scores = [i.hype_score for i in scored]
        assert scores == sorted(scores, reverse=True)

    def test_score_zero_item(self, test_config):
        scorer = HypeScorer()
        item = TrendItem(
            source=Source.GITHUB, title="zero", url="https://example.com/0",
            stars=0, score=0, comments=0,
        )
        score = scorer.score(item)
        assert score >= 0

    def test_recency_signal_recent(self, test_config):
        scorer = HypeScorer()
        item = TrendItem(
            source=Source.GITHUB, title="recent", url="https://example.com/recent",
            created_at=datetime.utcnow(),
        )
        score = scorer.score(item)
        # Recent items should get a recency boost
        assert score > 0

    def test_score_hackernews_item(self, test_config):
        scorer = HypeScorer()
        item = TrendItem(
            source=Source.HACKERNEWS, title="HN Story", url="https://example.com/hn",
            score=500, comments=200,
        )
        score = scorer.score(item)
        assert 0 <= score <= 100

    def test_score_devto_item(self, test_config):
        scorer = HypeScorer()
        item = TrendItem(
            source=Source.DEVTO, title="DevTo Article", url="https://dev.to/test/article",
            stars=300, score=350, comments=50,
        )
        score = scorer.score(item)
        assert 0 <= score <= 100


class TestTrendDetector:
    def test_detect_emerging_with_high_velocity(self, test_db, sample_github_items):
        for item in sample_github_items:
            item.velocity = 50.0
            item.hype_score = 60.0

        detector = TrendDetector(test_db)
        emerging = detector.detect_emerging(sample_github_items)
        assert len(emerging) >= 1
        assert all(e.is_emerging for e in emerging)

    def test_detect_emerging_empty_list(self, test_db):
        detector = TrendDetector(test_db)
        emerging = detector.detect_emerging([])
        assert emerging == []

    def test_detect_emerging_no_signals(self, test_db, sample_github_items):
        for item in sample_github_items:
            item.velocity = 0.0
            item.hype_score = 1.0
            item.created_at = datetime(2020, 1, 1)

        detector = TrendDetector(test_db)
        emerging = detector.detect_emerging(sample_github_items)
        # Without signals, most items should not be flagged
        assert len(emerging) < len(sample_github_items)

    def test_calculate_velocity_new_items(self, test_db, sample_github_items):
        detector = TrendDetector(test_db)
        items = detector.calculate_velocity(sample_github_items)
        for item in items:
            assert item.velocity >= 0

    def test_calculate_velocity_with_previous(self, test_db, sample_github_items):
        # Insert items first
        test_db.insert_items(sample_github_items)

        # Now "re-fetch" with higher scores
        updated_items = []
        for item in sample_github_items:
            updated = TrendItem(
                source=item.source,
                title=item.title,
                url=item.url,
                score=item.score + 500,
                stars=item.stars + 200,
                comments=item.comments + 50,
                fetched_at=datetime.utcnow(),
            )
            updated_items.append(updated)

        detector = TrendDetector(test_db)
        items = detector.calculate_velocity(updated_items)
        # Items with previous data should have velocity > 0
        assert any(i.velocity > 0 for i in items)


class TestCategorizer:
    def test_refine_does_not_crash(self, all_sample_items):
        categorizer = Categorizer()
        result = categorizer.refine(all_sample_items)
        assert len(result) == len(all_sample_items)

    def test_get_display_name(self):
        categorizer = Categorizer()
        assert categorizer.get_display_name(Category.AI_ML) == "AI / Machine Learning"
        assert categorizer.get_display_name(Category.WEB) == "Web Development"
        assert categorizer.get_display_name(Category.OTHER) == "Other"

    def test_get_category_summary(self, all_sample_items):
        categorizer = Categorizer()
        summary = categorizer.get_category_summary(all_sample_items)
        assert len(summary) > 0
        # Each entry: (key, display_name, count)
        for key, name, count in summary:
            assert isinstance(key, str)
            assert isinstance(name, str)
            assert isinstance(count, int)
            assert count > 0

    def test_get_category_summary_sorted(self, all_sample_items):
        categorizer = Categorizer()
        summary = categorizer.get_category_summary(all_sample_items)
        counts = [c for _, _, c in summary]
        assert counts == sorted(counts, reverse=True)

    def test_refine_cross_source_same_topic(self):
        items = [
            TrendItem(
                source=Source.GITHUB,
                title="openai-gpt5",
                url="https://github.com/openai/gpt-5",
                category=Category.AI_ML,
            ),
            TrendItem(
                source=Source.HACKERNEWS,
                title="openai-gpt5",
                url="https://example.com/gpt5-news",
                category=Category.OTHER,
            ),
        ]
        categorizer = Categorizer()
        result = categorizer.refine(items)
        # The HN item should get refined to AI_ML based on the GitHub item
        hn_items = [i for i in result if i.source == Source.HACKERNEWS]
        assert hn_items[0].category == Category.AI_ML


class TestReportGenerator:
    def test_generate_report_empty(self, test_db):
        gen = ReportGenerator(test_db)
        report = gen.generate_report([], period="weekly")
        assert report.total_items == 0
        assert "No items" in report.summary

    def test_generate_report_with_items(self, test_db, all_sample_items):
        gen = ReportGenerator(test_db)
        report = gen.generate_report(all_sample_items, period="weekly")

        assert report.total_items > 0
        assert len(report.items) > 0
        assert report.period == "weekly"
        assert report.summary != ""

    def test_generate_report_assigns_hype_scores(self, test_db, all_sample_items):
        gen = ReportGenerator(test_db)
        report = gen.generate_report(all_sample_items, period="weekly")

        for item in report.items:
            assert item.hype_score > 0 or item.hype_score == 0.0
            assert 0 <= item.hype_score <= 100

    def test_generate_report_detects_emerging(self, test_db, sample_github_items):
        # Give items high velocity to trigger emerging detection
        for item in sample_github_items:
            item.velocity = 50.0
            item.created_at = datetime.utcnow()
            item.score = 1000
            item.comments = 500

        gen = ReportGenerator(test_db)
        report = gen.generate_report(sample_github_items, period="weekly")

        # At least some should be detected as emerging
        # (depends on thresholds and baseline)
        assert isinstance(report.emerging_trends, list)

    def test_generate_report_has_top_categories(self, test_db, all_sample_items):
        gen = ReportGenerator(test_db)
        report = gen.generate_report(all_sample_items, period="weekly")

        assert len(report.top_categories) > 0

    def test_report_title_daily(self, test_db):
        gen = ReportGenerator(test_db)
        report = gen.generate_report([], period="daily")
        assert "AITrendRadar" in report.title

    def test_report_title_weekly(self, test_db):
        gen = ReportGenerator(test_db)
        report = gen.generate_report([], period="weekly")
        assert "AITrendRadar" in report.title
