"""Tests for CLI interface."""

from click.testing import CliRunner

from aitrendradar.cli import main


class TestCLI:
    def test_version(self):
        runner = CliRunner()
        result = runner.invoke(main, ["--version"])
        assert result.exit_code == 0
        assert "AITrendRadar" in result.output

    def test_help(self):
        runner = CliRunner()
        result = runner.invoke(main, ["--help"])
        assert result.exit_code == 0
        assert "scan" in result.output
        assert "show" in result.output
        assert "stats" in result.output

    def test_scan_help(self):
        runner = CliRunner()
        result = runner.invoke(main, ["scan", "--help"])
        assert result.exit_code == 0
        assert "--sources" in result.output
        assert "--period" in result.output
        assert "--format" in result.output

    def test_show_help(self):
        runner = CliRunner()
        result = runner.invoke(main, ["show", "--help"])
        assert result.exit_code == 0
        assert "--days" in result.output
        assert "--source" in result.output

    def test_stats_no_data(self, test_config):
        runner = CliRunner()
        result = runner.invoke(main, ["stats"])
        assert result.exit_code == 0

    def test_sources_info(self):
        runner = CliRunner()
        result = runner.invoke(main, ["sources-info"])
        assert result.exit_code == 0
        assert "GitHub" in result.output
        assert "Hacker News" in result.output
        assert "DevTo" in result.output

    def test_cleanup_help(self):
        runner = CliRunner()
        result = runner.invoke(main, ["cleanup", "--help"])
        assert result.exit_code == 0
        assert "--days" in result.output

    def test_web_help(self):
        runner = CliRunner()
        result = runner.invoke(main, ["web", "--help"])
        assert result.exit_code == 0
        assert "--host" in result.output
        assert "--port" in result.output
