"""Tests for data models."""

from datetime import datetime

from aitrendradar.models import Category, Source, TrendItem, TrendReport


class TestSource:
    def test_source_values(self):
        assert Source.GITHUB.value == "github"
        assert Source.HACKERNEWS.value == "hackernews"
        assert Source.DEVTO.value == "devto"

    def test_source_from_string(self):
        assert Source("github") == Source.GITHUB
        assert Source("hackernews") == Source.HACKERNEWS


class TestCategory:
    def test_category_values(self):
        assert Category.AI_ML.value == "ai-ml"
        assert Category.WEB.value == "web"
        assert Category.OTHER.value == "other"

    def test_all_categories_exist(self):
        expected = [
            "ai-ml", "web", "mobile", "devops", "security", "databases",
            "languages", "tools", "open-source", "cloud", "blockchain",
            "gaming", "data-science", "other",
        ]
        actual = [c.value for c in Category]
        for exp in expected:
            assert exp in actual, f"Missing category: {exp}"


class TestTrendItem:
    def test_uid_generation(self):
        item = TrendItem(
            source=Source.GITHUB,
            title="test/repo",
            url="https://github.com/test/repo",
        )
        assert len(item.uid) == 16
        assert isinstance(item.uid, str)

    def test_uid_deterministic(self):
        item1 = TrendItem(source=Source.GITHUB, title="test", url="https://example.com/a")
        item2 = TrendItem(source=Source.GITHUB, title="test", url="https://example.com/a")
        assert item1.uid == item2.uid

    def test_uid_different_urls(self):
        item1 = TrendItem(source=Source.GITHUB, title="test", url="https://example.com/a")
        item2 = TrendItem(source=Source.GITHUB, title="test", url="https://example.com/b")
        assert item1.uid != item2.uid

    def test_to_dict(self):
        item = TrendItem(
            source=Source.GITHUB,
            title="test/repo",
            url="https://github.com/test/repo",
            description="A test repo",
            score=100,
            stars=50,
            comments=25,
            category=Category.AI_ML,
            tags=["python", "ai"],
            fetched_at=datetime(2024, 1, 15, 12, 0, 0),
        )
        d = item.to_dict()

        assert d["source"] == "github"
        assert d["title"] == "test/repo"
        assert d["url"] == "https://github.com/test/repo"
        assert d["score"] == 100
        assert d["stars"] == 50
        assert d["comments"] == 25
        assert d["category"] == "ai-ml"
        assert d["tags"] == ["python", "ai"]
        assert d["fetched_at"] == "2024-01-15T12:00:00"

    def test_from_dict(self):
        data = {
            "source": "github",
            "title": "test/repo",
            "url": "https://github.com/test/repo",
            "description": "A test repo",
            "score": 100,
            "stars": 50,
            "comments": 25,
            "category": "ai-ml",
            "tags": ["python", "ai"],
            "fetched_at": "2024-01-15T12:00:00",
        }
        item = TrendItem.from_dict(data)

        assert item.source == Source.GITHUB
        assert item.title == "test/repo"
        assert item.category == Category.AI_ML
        assert item.score == 100
        assert item.tags == ["python", "ai"]

    def test_round_trip(self):
        item = TrendItem(
            source=Source.HACKERNEWS,
            title="Test story",
            url="https://example.com/story",
            score=500,
            category=Category.WEB,
        )
        d = item.to_dict()
        restored = TrendItem.from_dict(d)

        assert restored.source == item.source
        assert restored.title == item.title
        assert restored.url == item.url
        assert restored.score == item.score
        assert restored.category == item.category

    def test_default_values(self):
        item = TrendItem(
            source=Source.GITHUB,
            title="test",
            url="https://example.com",
        )
        assert item.description == ""
        assert item.score == 0
        assert item.stars == 0
        assert item.comments == 0
        assert item.language == ""
        assert item.category == Category.OTHER
        assert item.hype_score == 0.0
        assert item.is_emerging is False
        assert item.tags == []


class TestTrendReport:
    def test_total_items(self):
        items = [
            TrendItem(source=Source.GITHUB, title=f"item-{i}", url=f"https://example.com/{i}")
            for i in range(5)
        ]
        report = TrendReport(title="Test Report", period="weekly", items=items)
        assert report.total_items == 5

    def test_empty_report(self):
        report = TrendReport(title="Empty Report", period="daily")
        assert report.total_items == 0
        assert report.items == []
        assert report.emerging_trends == []

    def test_to_dict(self):
        items = [
            TrendItem(source=Source.GITHUB, title="item", url="https://example.com"),
        ]
        report = TrendReport(
            title="Test",
            period="weekly",
            items=items,
            summary="Test summary",
        )
        d = report.to_dict()
        assert d["title"] == "Test"
        assert d["total_items"] == 1
        assert d["summary"] == "Test summary"
        assert len(d["items"]) == 1
