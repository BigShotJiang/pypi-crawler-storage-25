# copilot-memory

Portable human-AI collaboration memory system with MCP server and knowledge graphs.

> **Disclaimer:** This project is for research and experimentation.

## 📚 Contents

- [📝 Overview](#-overview)
- [🚀 Get Started](#-get-started)
- [� Copilot Integration](#-copilot-integration)
- [📦 Architecture](#-architecture)
- [� Memory Architecture](#-memory-architecture)
- [�🧪 Testing](#-testing)
- [📖 Documentation](#-documentation)
- [🤝 Author](#-author)
- [📄 License](#-license)

## 📝 Overview

copilot-memory externalizes the collaboration knowledge between a human developer and an AI agent into structured, version-controlled, graphifiable markdown files.

| Item | Description |
|------|-------------|
| **Concept** | [copilot-memory-concept.md](../copilot-memory-concept.md) |
| **Memory files** | `memories/` — conventions, workflow, communication, tools, anti-patterns |
| **MCP server** | 9 tools: recall, remember, record_mistake, consolidate, list_topics, get_memory, health_report, briefing, dashboard |
| **Knowledge graph** | graphify over `memories/` for community detection and health metrics |

### What You Will Learn

- Dual-memory architecture: principles (semantic) + anti-patterns (episodic)
- Per-entry scoring with confidence, source, and verification metadata
- YAML frontmatter for progressive disclosure and cheap navigation
- Write-time constitution enforcement (forbidden content, size limits)
- Knowledge graph health metrics for memory quality assessment

| Category | Package | Version |
|----------|---------|---------|
| Runtime | Python | ≥ 3.12 |
| MCP (optional) | mcp | ≥ 1.27.0 |
| Graphs (optional) | graphifyy[mcp] | ≥ 0.4.23 |
| Search | ddgs | ≥ 9.14.0 |

## 🚀 Get Started

### Prerequisites

- Python ≥ 3.12
- [`uv`](https://docs.astral.sh/uv/) — `brew install uv` or `curl -LsSf https://astral.sh/uv/install.sh | sh`

### Install from source (development)

```bash
cd copilot-memory
uv venv && source .venv/bin/activate
uv add --dev -r requirements_dev.txt
uv pip install -e .
uv sync
```

### Install from PyPI (when published)

```bash
# Base package (core library, no deps)
pip install aidiary

# With MCP server support
pip install 'aidiary[mcp]'

# With graph rebuild tools
pip install 'aidiary[graphs]'

# Everything
pip install 'aidiary[mcp,graphs]'
```

### Run the MCP server

```bash
# Default — looks for memories/ relative to package
memory-server

# Custom memories directory
memory-server /path/to/memories

# Or as a Python module
python -m aidiary.server /path/to/memories
```

### Building the knowledge graphs

```bash
source .venv/bin/activate

# Rebuild all graphs (auto-detects stale caches)
rebuild-graphs

# Code graph only (AST, no LLM, instant)
rebuild-graphs --code-only

# Build from existing semantic cache (after /graphify extraction)
rebuild-graphs --build-only

# Clear caches and report what needs LLM extraction
rebuild-graphs --fresh
```

Graph config is in `graphify.toml` (TOML format, parsed with stdlib `tomllib`):

```toml
project = "copilot-memory"

[graphs.code]
input = "src/"
output = "graphify-out-code/"
method = "ast"

[graphs.docs]
input = "docs/"
output = "graphify-out-doc/"
method = "semantic"

[graphs.mem]
input = "memories/"
output = "graphify-out-mem/"
method = "semantic"

# Optional: override auto-generated community labels
# [graphs.mem.labels]
# 0 = "Planning Discipline"
# 1 = "Memory Research Agenda"
```

#### TOML Structure Reference

| Key | Required | Type | Description |
|-----|----------|------|-------------|
| `project` | No | string | Project name shown in CLI output. Defaults to directory name. |
| `[graphs.<name>]` | Yes | section | One section per graph. `<name>` is a free-form identifier (e.g. `code`, `docs`, `mem`, `fe`). |
| `input` | Yes | string | Input directory relative to project root. |
| `output` | Yes | string | Output directory relative to project root. Created automatically if missing. |
| `method` | Yes | `"ast"` or `"semantic"` | `ast` — tree-sitter AST extraction (code files, no LLM, instant). `semantic` — LLM-based concept extraction (docs/memories, requires cached `.graphify_semantic.json`). |
| `[graphs.<name>.labels]` | No | int → string map | Override community labels from Leiden clustering. Keys are community IDs (integers), values are human-readable names. If omitted, communities are auto-labeled from their highest-degree node. Labels are cosmetic — they appear in `GRAPH_REPORT.md`, `graph.html`, and MCP tools but don't affect clustering. Stale after re-clustering; remove or update when community assignments change. |

Programmatic API:

```python
from aidiary.graphs import load_config, rebuild_graph, rebuild_all
from pathlib import Path

config = load_config(Path("graphify.toml"))
result = rebuild_graph("code", config["graphs"]["code"], project_root=Path("."))
```

> **Requires `graphifyy[mcp]>=0.4.23`.** If not installed, a clear `ImportError` is raised with install instructions.

> **⚠️ Semantic graphs (docs, mem) require LLM extraction.** The `rebuild-graphs` CLI cannot run LLM extraction — it can only build from cache. When semantic caches are stale, the CLI reports exactly which commands to run. **Copy and paste** the following commands into **Copilot Chat** (not a terminal):
> ```
> /graphify docs --update
> /graphify memories --update
> ```
> After extraction completes, run `rebuild-graphs --build-only` in the terminal to finish the build. Code graphs (AST) need no LLM and rebuild fully automatically.

> **After rebuilding graphs, restart MCP servers.** The graphify MCP server loads `graph.json` once at startup. Use `./restart-mcps.sh` at the workspace root, or Cmd+Shift+P → "MCP: Restart All Servers" in VS Code.

## 🔌 Copilot Integration

### 1. Register the MCP server

Add to your `.vscode/mcp.json`:

```json
{
  "servers": {
    "copilot-memory": {
      "type": "stdio",
      "command": "python",
      "args": ["-m", "aidiary.server", "${workspaceFolder}/copilot-memory/memories"]
    }
  }
}
```

Or if installed globally via pip:

```json
{
  "servers": {
    "copilot-memory": {
      "type": "stdio",
      "command": "memory-server",
      "args": ["${workspaceFolder}/memories"]
    }
  }
}
```

### 2. Add memory consultation to your instructions

In your `.github/copilot-instructions.md`, add a **Recall** step to the Decision-Making Workflow:

```markdown
### Decision-Making Workflow

1. **Recall** — query the `copilot-memory` MCP server (`recall` tool) with relevant keywords.
   Check if a previous decision, convention, or anti-pattern already covers this situation.
2. **Rethink** — brainstorm alternatives. Cross-reference against recalled memories.
3. **Present options** — lay out viable alternatives with pros and cons.
4. **Recommend** — state your recommendation and why.
```

### 3. Seed your memory files

Create `memories/` with at least these files:

```
memories/
├── conventions.md     # How you want things done (deps, style, workflow)
├── anti-patterns.md   # Mistakes to avoid (episodic, append-only)
└── tools.md           # Package managers, commands, tooling
```

Each file uses YAML frontmatter + H2 sections with metadata:

```markdown
---
description: "Your project conventions and workflow rules"
priority: high
tags: [conventions, workflow]
entry_count: 1
last_updated: 2026-04-17
---
# Conventions

## Always pin transitive deps in requirements.txt
- confidence: high
- source: correction
- verified_count: 2
- last_verified: 2026-04-17

We pin transitive deps because unpinned pre-releases broke httpx_sse.
The requirements.txt files are the single source of truth for all version pins.
```

### 4. Available MCP tools

| Tool | Purpose |
|------|---------|
| `recall` | Keyword search across all memory files |
| `remember` | Write a new entry (validated by constitution) |
| `record_mistake` | Record an anti-pattern with correction link |
| `consolidate` | Detect overlaps, contradictions, oversized entries |
| `list_topics` | List all files and their entry headings |
| `get_memory` | Read a specific file's full content |
| `health_report` | Confidence distribution, staleness, topic balance |
| `briefing` | Session-start summary: top conventions, recent anti-patterns, health warnings |
| `dashboard` | Generate a memory health dashboard as self-contained HTML |

## 📦 Architecture

### Module layout

```
src/aidiary/
├── server.py          # MCP protocol — tool defs, handler dict, serve()
├── store.py           # Markdown I/O — parse, load, append, frontmatter cache
├── search.py          # Recall engine — keyword matching, scoring
├── scoring.py         # Health metrics — staleness, confidence distribution
├── consolidate.py     # Overlap detection — self-critique, merge suggestions
├── constitution.py    # Policy rules — validate writes, enforce limits
├── briefing.py        # Session-start briefing — top conventions, recent mistakes, health warnings
├── dashboard.py       # Memory health dashboard — single-file HTML generator
└── smoke_test.py      # Reusable 16-check test suite
```

### Memory file layout

```
memories/
├── conventions.md      # Dependency pinning, docs-first, roadmap-first
├── workflow.md         # Decision-making, graph consultation, refactoring safety
├── communication.md    # Brevity, showing plans, using tables
├── tools.md            # uv, MCP patterns, graphify, ddgs
├── project-setup.md    # Workspace structure, author conventions
├── anti-patterns.md    # Episodic mistake buffer with correction links
└── research-agenda.md  # Open questions for investigation
```

### Dependency graph (acyclic)

```
server.py
  ├── store.py         (read/write memories)
  ├── search.py        (keyword recall)
  ├── scoring.py       (health metrics)
  ├── consolidate.py   (overlap + self-critique)
  ├── constitution.py  (write-time validation)
  ├── briefing.py      (session-start summary)
  └── dashboard.py     (HTML health dashboard)
```

### Design decisions

- **Handler dict dispatch** — new tools = one dict entry + one function (from opskit pattern)
- **Cached store** — parses files once, write-through invalidation on append
- **YAML frontmatter** — enables progressive disclosure without full parsing
- **Constitution enforcement** — rejects absolute paths, API keys, oversized entries at write time
- **Self-critique** — consolidation flags confidence/evidence mismatches (Self-Refine pattern)
- **Dual memory** — semantic principles (consolidate & generalize) + episodic anti-patterns (preserve specifics)

➡️ [Modularization concept](docs/mcp-modularization-concept.md)
➡️ [Research survey](docs/memory-system-research.md)
➡️ [Original concept](../copilot-memory-concept.md)

## 🧪 Testing

### Smoke test (all modules)

```bash
cd copilot-memory && source .venv/bin/activate
python -m aidiary.smoke_test memories/
```

Runs 21 checks: frontmatter loading, section parsing, cache, heading_exists, duplicate heading guard, keyword search, health report, confidence mismatch (+ corrections exemption), consolidation (overlap + stale + merges), constitution validation (valid/invalid/filename), cache invalidation, session briefing (general + scoped), dashboard (generation + summary cards + timeline). Exits 0 on success.

### MCP protocol test

```bash
echo '{"jsonrpc":"2.0","id":1,"method":"tools/list"}' | python -m aidiary.server memories/
```

## 📖 Documentation

| Doc | Description |
|-----|-------------|
| [ResearchStatus.md](ResearchStatus.md) | **Current stage assessment** — where this self-learning memory system stands |
| [ProjectRoadmap.md](ProjectRoadmap.md) | 18 roadmap items with priority matrix |
| [ResearchReferences.md](ResearchReferences.md) | Papers and blogs with adoption/deferral notes |
| [docs/memory-system-research.md](docs/memory-system-research.md) | Full literature survey (10 papers) |
| [docs/mcp-modularization-concept.md](docs/mcp-modularization-concept.md) | Modular architecture design |
| [docs/memory-migration-concept.md](docs/memory-migration-concept.md) | Migration from built-in agent memory to copilot-memory (Option B) |
| [docs/session-briefing-concept.md](docs/session-briefing-concept.md) | Session-start briefing tool design |
| [docs/memory-health-dashboard-concept.md](docs/memory-health-dashboard-concept.md) | Memory health dashboard design |

## 🧠 Memory Architecture

copilot-memory replaces VS Code Copilot's built-in agent memory as the **single source of truth** for collaboration knowledge. The built-in memory retains only a slim pointer that reminds the agent to use copilot-memory at session start.

### Why copilot-memory over built-in memory

| Capability | Built-in `/memories/` | copilot-memory MCP |
|---|---|---|
| Confidence scoring | No | Yes (high/medium/low per entry) |
| Staleness detection | No | Yes (last_verified, verified_count) |
| Source tracking | No | Yes (correction/observation/conversation/research) |
| Anti-pattern separation | No | Yes (dedicated file with correction links) |
| Health reports | No | Yes (`health_report` tool) |
| Consolidation | No | Yes (`consolidate` tool) |
| Keyword search | No | Yes (`recall` tool) |
| Version-controlled | No | Yes (git-tracked, reviewable) |
| Graphifiable | No | Yes (graphify-memory MCP) |
| Auto-loaded into context | **Yes** (first 200 lines) | No (requires `recall`) |

### How the two systems connect

```
┌─────────────────────────────────────────────────────────┐
│  VS Code built-in memory (/memories/lessons.md)         │
│  ┌─────────────────────────────────────────────────────┐│
│  │ "All knowledge lives in copilot-memory MCP.         ││
│  │  Use recall at session start."                      ││
│  │  [slim pointer — auto-loaded every session]         ││
│  └─────────────────────────────────────────────────────┘│
│                         │ triggers                      │
│                         ▼                               │
│  ┌─────────────────────────────────────────────────────┐│
│  │ copilot-memory MCP server                           ││
│  │  recall → remember → record_mistake → consolidate   ││
│  │  list_topics → get_memory → health_report → briefing││
│  │  dashboard                                          ││
│  │  [9 tools, 52 entries, 7 files]                     ││
│  └─────────────────────────────────────────────────────┘│
│                         │ graphified by                 │
│                         ▼                               │
│  ┌─────────────────────────────────────────────────────┐│
│  │ gf-mem-mem + gf-mem-doc                            ││
│  │  + gf-mem-code                                    ││
│  │                                                     ││
│  │  [mem: 50n/33e] [doc: 44n/56e] [code: 104n/193e]   ││
│  └─────────────────────────────────────────────────────┘│
└─────────────────────────────────────────────────────────┘
```

### Write discipline: MCP tools only

**Never directly edit files in `memories/`.** All writes must go through MCP tools (`remember`, `record_mistake`). Direct edits (file editing, terminal commands) bypass three safeguards:

1. **Constitution enforcement** — rejects forbidden content (absolute paths, API keys) and oversized entries
2. **Frontmatter maintenance** — keeps `entry_count` and `last_updated` in sync automatically
3. **Store cache invalidation** — ensures subsequent reads reflect the latest state

Direct edits are only allowed in `docs/`, `src/`, and `scripts/` — concept docs and code are regular files. Only `memories/` is protected.

### Migration (Option B)

On 2026-04-17, all structured knowledge was migrated from built-in memory to copilot-memory:
- 7 entries already existed (richer versions with metadata) — skipped
- 5 unique entries migrated to their correct topic files
- Built-in memory replaced with a 10-line pointer
- 10 migration-specific tests verified correctness

See [memory-migration-concept.md](docs/memory-migration-concept.md) for the full decision record.

## 🤝 Author

**Yingding Wang**

## 📄 License

See [LICENSE](../LICENSE) for details. © 2026 Yingding Wang
