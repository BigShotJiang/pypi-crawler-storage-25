"""Memory Health Dashboard — single-file HTML generator.

Exports:
    generate_dashboard — produce a self-contained HTML dashboard from memory data

Consumers:
    server.py (dashboard tool), CLI (python -m aidiary.dashboard)
"""
from __future__ import annotations

import html
import sys
from datetime import date, timedelta
from pathlib import Path

from .consolidate import find_contradictions
from .scoring import find_stale, find_unverified, confidence_mismatch

STALE_DAYS = 30


def generate_dashboard(
    memories: dict[str, list[dict]],
    frontmatter: dict[str, dict],
) -> str:
    """Generate a complete HTML dashboard from memory data."""
    total = sum(len(secs) for secs in memories.values())
    stale = find_stale(memories)
    unverified = find_unverified(memories)
    mismatches = _find_mismatches(memories)
    contradictions = find_contradictions(memories)
    conf_dist = _confidence_dist(memories)
    src_dist = _source_dist(memories)

    summary_html = _summary_cards(total, len(memories), conf_dist, stale, mismatches, contradictions)
    charts_html = _distribution_charts(memories, conf_dist, src_dist)
    table_html = _entry_table(memories, stale)
    timeline_html = _timeline(memories)
    today = date.today().isoformat()

    return _HTML_TEMPLATE.format(
        date=today,
        total=total,
        summary=summary_html,
        charts=charts_html,
        table=table_html,
        timeline=timeline_html,
    )


# ── Internal helpers ─────────────────────────────────────────────────


def _find_mismatches(memories: dict[str, list[dict]]) -> list[str]:
    results = []
    for sections in memories.values():
        for s in sections:
            w = confidence_mismatch(s)
            if w:
                results.append(w)
    return results


def _confidence_dist(memories: dict[str, list[dict]]) -> dict[str, int]:
    dist: dict[str, int] = {"high": 0, "medium": 0, "low": 0}
    for sections in memories.values():
        for s in sections:
            c = s["metadata"].get("confidence", "medium")
            dist[c] = dist.get(c, 0) + 1
    return dist


def _source_dist(memories: dict[str, list[dict]]) -> dict[str, int]:
    dist: dict[str, int] = {}
    for sections in memories.values():
        for s in sections:
            src = s["metadata"].get("source", "unknown")
            dist[src] = dist.get(src, 0) + 1
    return dict(sorted(dist.items(), key=lambda x: -x[1]))


def _summary_cards(
    total: int,
    file_count: int,
    conf_dist: dict[str, int],
    stale: list,
    mismatches: list[str],
    contradictions: list | None = None,
) -> str:
    h, m, lo = conf_dist.get("high", 0), conf_dist.get("medium", 0), conf_dist.get("low", 0)
    stale_cls = "card-warn" if stale else "card-ok"
    mm_cls = "card-warn" if mismatches else "card-ok"
    ct_count = len(contradictions) if contradictions else 0
    ct_cls = "card-warn" if ct_count else "card-ok"
    return f"""
    <div class="cards">
      <div class="card"><div class="card-value">{total}</div><div class="card-label">entries in {file_count} files</div></div>
      <div class="card"><div class="card-value">{h}/{m}/{lo}</div><div class="card-label">high / med / low</div></div>
      <div class="card {stale_cls}"><div class="card-value">{len(stale)}</div><div class="card-label">stale (&gt;{STALE_DAYS}d)</div></div>
      <div class="card {mm_cls}"><div class="card-value">{len(mismatches)}</div><div class="card-label">mismatches</div></div>
      <div class="card {ct_cls}"><div class="card-value">{ct_count}</div><div class="card-label">contradictions</div></div>
    </div>"""


def _bar(label: str, value: int, max_value: int, color: str) -> str:
    pct = (value / max_value * 100) if max_value else 0
    esc = html.escape(label)
    return f'<div class="bar-row"><span class="bar-label">{esc}</span><div class="bar" style="width:{pct:.0f}%;background:{color}"></div><span class="bar-val">{value}</span></div>'


def _distribution_charts(
    memories: dict[str, list[dict]],
    conf_dist: dict[str, int],
    src_dist: dict[str, int],
) -> str:
    # Topic balance
    topic_max = max((len(s) for s in memories.values()), default=1)
    topic_bars = "\n".join(
        _bar(name, len(secs), topic_max, "#5b8def")
        for name, secs in sorted(memories.items(), key=lambda x: -len(x[1]))
    )
    # Confidence
    c_max = max(conf_dist.values(), default=1)
    conf_colors = {"high": "#2ecc71", "medium": "#f39c12", "low": "#e74c3c"}
    conf_bars = "\n".join(
        _bar(k, v, c_max, conf_colors.get(k, "#999"))
        for k, v in conf_dist.items()
    )
    # Source
    s_max = max(src_dist.values(), default=1)
    src_bars = "\n".join(
        _bar(k, v, s_max, "#8e44ad") for k, v in src_dist.items()
    )
    return f"""
    <div class="charts">
      <div class="chart-box"><h3>Topic Balance</h3>{topic_bars}</div>
      <div class="chart-box"><h3>Confidence</h3>{conf_bars}</div>
      <div class="chart-box"><h3>Source</h3>{src_bars}</div>
    </div>"""


def _conf_badge(conf: str) -> str:
    colors = {"high": "#2ecc71", "medium": "#f39c12", "low": "#e74c3c"}
    c = colors.get(conf, "#999")
    return f'<span class="badge" style="background:{c}">{html.escape(conf)}</span>'


def _entry_table(memories: dict[str, list[dict]], stale: list) -> str:
    stale_set = {(f, h) for f, h in stale}
    rows: list[str] = []
    for filename, sections in sorted(memories.items()):
        for s in sections:
            heading = html.escape(s["heading"])
            meta = s["metadata"]
            conf = meta.get("confidence", "?")
            src = meta.get("source", "?")
            vc = meta.get("verified_count", "0")
            lv = meta.get("last_verified", "—")
            is_stale = (filename, s["heading"]) in stale_set
            stale_flag = ' <span class="stale-flag">⚠️</span>' if is_stale else ""
            reflection_flag = ' <span class="badge" style="background:#9b59b6">reflection</span>' if filename == "reflections" else ""
            derived = meta.get("derived_from", "")
            derived_attr = f' title="Derived from: {html.escape(derived)}"' if derived else ""
            body_esc = html.escape(s["body"][:500])
            rows.append(
                f'<tr class="entry-row" onclick="toggleBody(this)"{derived_attr}>'
                f"<td>{heading}{stale_flag}{reflection_flag}</td>"
                f"<td>{html.escape(filename)}</td>"
                f"<td>{_conf_badge(conf)}</td>"
                f"<td>{html.escape(src)}</td>"
                f"<td>{vc}</td>"
                f"<td>{html.escape(lv)}</td>"
                f"</tr>"
                f'<tr class="entry-body" style="display:none"><td colspan="6"><pre>{body_esc}</pre></td></tr>'
            )
    return f"""
    <div class="table-wrap">
      <table>
        <thead><tr>
          <th onclick="sortTable(0)">Heading ⇅</th>
          <th onclick="sortTable(1)">File ⇅</th>
          <th onclick="sortTable(2)">Confidence ⇅</th>
          <th onclick="sortTable(3)">Source ⇅</th>
          <th onclick="sortTable(4)">Verified ⇅</th>
          <th onclick="sortTable(5)">Last Verified ⇅</th>
        </tr></thead>
        <tbody>{"".join(rows)}</tbody>
      </table>
    </div>"""


def _timeline(memories: dict[str, list[dict]]) -> str:
    events: list[tuple[str, str]] = []
    ap = memories.get("anti-patterns", [])
    for s in ap:
        d = s["metadata"].get("date", "")
        if d:
            events.append((d, s["heading"]))
    events.sort()
    if not events:
        return "<p>No anti-patterns with dates recorded.</p>"
    dots = ""
    for d, h in events:
        esc = html.escape(h)
        dots += f'<div class="tl-dot" title="{html.escape(d)}: {esc}"><div class="tl-label">{esc[:25]}</div><div class="tl-date">{html.escape(d)}</div></div>'
    return f'<div class="timeline">{dots}</div>'


# ── HTML template ────────────────────────────────────────────────────

_HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Memory Health Dashboard</title>
<style>
:root {{
  --bg: #f5f6fa; --fg: #2c3e50; --card-bg: #fff; --border: #dfe6e9;
  --table-hover: #f0f3ff; --pre-bg: #f8f9fa;
}}
@media (prefers-color-scheme: dark) {{
  :root {{
    --bg: #1e1e2e; --fg: #cdd6f4; --card-bg: #313244; --border: #45475a;
    --table-hover: #45475a; --pre-bg: #313244;
  }}
}}
* {{ box-sizing: border-box; margin: 0; padding: 0; }}
body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  background: var(--bg); color: var(--fg); padding: 1.5rem; max-width: 1200px; margin: 0 auto; }}
h1 {{ margin-bottom: 0.3rem; }}
.subtitle {{ color: #7f8c8d; margin-bottom: 1.5rem; font-size: 0.9rem; }}
.cards {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 1rem; margin-bottom: 1.5rem; }}
.card {{ background: var(--card-bg); border: 1px solid var(--border); border-radius: 8px; padding: 1rem; text-align: center; }}
.card-value {{ font-size: 1.8rem; font-weight: 700; }}
.card-label {{ font-size: 0.8rem; color: #7f8c8d; margin-top: 0.3rem; }}
.card-warn {{ border-color: #e74c3c; }}
.card-ok {{ border-color: #2ecc71; }}
.charts {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1rem; margin-bottom: 1.5rem; }}
.chart-box {{ background: var(--card-bg); border: 1px solid var(--border); border-radius: 8px; padding: 1rem; }}
.chart-box h3 {{ font-size: 0.9rem; margin-bottom: 0.8rem; }}
.bar-row {{ display: flex; align-items: center; margin-bottom: 0.4rem; }}
.bar-label {{ width: 100px; font-size: 0.8rem; text-overflow: ellipsis; overflow: hidden; white-space: nowrap; }}
.bar {{ height: 18px; border-radius: 3px; min-width: 4px; transition: width 0.3s; }}
.bar-val {{ margin-left: 0.5rem; font-size: 0.8rem; font-weight: 600; }}
.table-wrap {{ background: var(--card-bg); border: 1px solid var(--border); border-radius: 8px; overflow-x: auto; margin-bottom: 1.5rem; }}
table {{ width: 100%; border-collapse: collapse; font-size: 0.85rem; }}
th {{ cursor: pointer; background: var(--bg); padding: 0.6rem 0.8rem; text-align: left; border-bottom: 2px solid var(--border); user-select: none; }}
td {{ padding: 0.5rem 0.8rem; border-bottom: 1px solid var(--border); }}
.entry-row:hover {{ background: var(--table-hover); cursor: pointer; }}
.entry-body pre {{ white-space: pre-wrap; word-break: break-word; font-size: 0.8rem;
  background: var(--pre-bg); padding: 0.8rem; border-radius: 4px; max-height: 300px; overflow-y: auto; }}
.badge {{ display: inline-block; padding: 2px 8px; border-radius: 10px; color: #fff; font-size: 0.75rem; font-weight: 600; }}
.stale-flag {{ font-size: 0.9rem; }}
.timeline {{ display: flex; align-items: flex-end; gap: 0; padding: 1rem 0; overflow-x: auto;
  border-bottom: 2px solid var(--border); position: relative; }}
.tl-dot {{ flex: 1; min-width: 80px; text-align: center; position: relative; padding-bottom: 1.2rem; cursor: default; }}
.tl-dot::after {{ content: ''; position: absolute; bottom: 0; left: 50%; transform: translateX(-50%);
  width: 12px; height: 12px; border-radius: 50%; background: #e74c3c; }}
.tl-label {{ font-size: 0.7rem; word-break: break-word; }}
.tl-date {{ font-size: 0.65rem; color: #7f8c8d; }}
h2 {{ margin: 1.5rem 0 0.8rem; font-size: 1.1rem; }}
</style>
</head>
<body>
<h1>Memory Health Dashboard</h1>
<div class="subtitle">Generated {date} &middot; {total} entries</div>

{summary}

<h2>Distributions</h2>
{charts}

<h2>All Entries</h2>
{table}

<h2>Anti-Pattern Timeline</h2>
{timeline}

<script>
function toggleBody(row) {{
  const body = row.nextElementSibling;
  body.style.display = body.style.display === 'none' ? '' : 'none';
}}
function sortTable(col) {{
  const table = document.querySelector('table');
  const tbody = table.querySelector('tbody');
  const pairs = [];
  const rows = tbody.querySelectorAll('tr.entry-row');
  rows.forEach(r => {{
    pairs.push([r, r.nextElementSibling]);
  }});
  const dir = table.dataset.sortCol == col && table.dataset.sortDir === 'asc' ? 'desc' : 'asc';
  table.dataset.sortCol = col;
  table.dataset.sortDir = dir;
  pairs.sort((a, b) => {{
    const ta = a[0].children[col].textContent.trim().toLowerCase();
    const tb = b[0].children[col].textContent.trim().toLowerCase();
    const na = parseFloat(ta), nb = parseFloat(tb);
    let cmp = 0;
    if (!isNaN(na) && !isNaN(nb)) cmp = na - nb;
    else cmp = ta.localeCompare(tb);
    return dir === 'asc' ? cmp : -cmp;
  }});
  pairs.forEach(([r, b]) => {{ tbody.appendChild(r); tbody.appendChild(b); }});
}}
</script>
</body>
</html>"""


# ── CLI entry point ──────────────────────────────────────────────────

def main() -> None:
    """Generate dashboard HTML from CLI."""
    from .store import MemoryStore

    memories_dir = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parent.parent.parent / "memories"
    store = MemoryStore(memories_dir)
    memories = store.load_all()
    fm = store.load_frontmatter_only()
    html_content = generate_dashboard(memories, fm)
    out = memories_dir.parent / "memory-health.html"
    out.write_text(html_content, encoding="utf-8")
    print(f"Dashboard written to {out}")


if __name__ == "__main__":
    main()
