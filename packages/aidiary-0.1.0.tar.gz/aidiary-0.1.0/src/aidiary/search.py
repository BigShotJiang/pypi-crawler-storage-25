"""Recall engine — keyword search over memory entries.

Exports:
    search_memories  — keyword-ranked search across all memory files

Consumers:
    server.py (recall tool)
"""
from __future__ import annotations


def search_memories(query: str, memories: dict[str, list[dict]],
                    *, scope: str | None = None) -> list[dict]:
    """Search all memories by keyword.  Returns matching sections ranked by score.

    When *scope* is given (``"universal"`` or ``"project"``), only entries
    with that scope are returned.  Anti-pattern entries (``source: correction``)
    are always included regardless of scope filter.
    """
    terms = [t.lower() for t in query.split() if len(t) > 1]
    if not terms:
        return []
    results: list[dict] = []
    for filename, sections in memories.items():
        for section in sections:
            # Scope filter — anti-patterns always pass
            if scope is not None:
                entry_scope = section["metadata"].get("scope", "project")
                is_anti_pattern = section["metadata"].get("source") == "correction" and filename == "anti-patterns"
                if entry_scope != scope and not is_anti_pattern:
                    continue
            text = (section["heading"] + " " + section["body"]).lower()
            score = sum(1 for t in terms if t in text)
            if score > 0:
                results.append({
                    "file": filename,
                    "heading": section["heading"],
                    "score": score,
                    "confidence": section["metadata"].get("confidence", "unknown"),
                    "scope": section["metadata"].get("scope", "project"),
                    "body": section["body"][:500],
                })
    return sorted(results, key=lambda r: r["score"], reverse=True)
