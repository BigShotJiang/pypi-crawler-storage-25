"""Scoring and health metrics for memory entries.

Exports:
    health_report      — compute confidence/source/staleness stats
    find_stale         — entries with null or old last_verified
    find_unverified    — entries with verified_count == 0

Consumers:
    server.py (health_report tool), consolidate.py (self-critique)
"""
from __future__ import annotations

from datetime import date, timedelta


STALE_DAYS = 30  # entries older than this are flagged


def health_report(memories: dict[str, list[dict]]) -> str:
    """Compute memory health metrics.  Returns formatted markdown."""
    if not memories:
        return "No memories found."

    total = sum(len(secs) for secs in memories.values())
    confidence_dist: dict[str, int] = {"high": 0, "medium": 0, "low": 0, "unknown": 0}
    source_dist: dict[str, int] = {}
    stale = find_stale(memories)
    unverified = find_unverified(memories)

    for sections in memories.values():
        for s in sections:
            conf = s["metadata"].get("confidence", "unknown")
            confidence_dist[conf] = confidence_dist.get(conf, 0) + 1
            src = s["metadata"].get("source", "unknown")
            source_dist[src] = source_dist.get(src, 0) + 1

    lines = [
        f"# Memory Health Report\n",
        f"**Total entries:** {total} across {len(memories)} files\n",
        "## Confidence Distribution",
        *[f"- {k}: {v}" for k, v in sorted(confidence_dist.items())],
        "",
        "## Source Distribution",
        *[f"- {k}: {v}" for k, v in sorted(source_dist.items())],
        "",
        "## Topic Balance",
        *[f"- {fname}.md: {len(secs)} entries" for fname, secs in memories.items()],
    ]

    if stale:
        lines.extend(["", "## Stale Entries (never verified)",
                       *[f"- {h} ({f}.md)" for f, h in stale]])
    if unverified:
        lines.extend(["", "## Unverified Entries (count=0)",
                       *[f"- {h} ({f}.md)" for f, h in unverified]])

    # Contradiction detection (lazy import to avoid circular dep)
    from .consolidate import find_contradictions
    contradictions = find_contradictions(memories)
    if contradictions:
        lines.extend(["", "## Potential Contradictions"])
        for f1, h1, f2, h2, kws in contradictions:
            lines.append(
                f"- ⚠️ '{h1}' ({f1}.md) ↔ '{h2}' ({f2}.md) "
                f"— conflicting on: {', '.join(kws)}"
            )

    return "\n".join(lines)


def find_stale(memories: dict[str, list[dict]]) -> list[tuple[str, str]]:
    """Return (filename, heading) pairs for entries with null or old last_verified."""
    results: list[tuple[str, str]] = []
    cutoff = str(date.today() - timedelta(days=STALE_DAYS))
    for filename, sections in memories.items():
        for s in sections:
            lv = s["metadata"].get("last_verified", "null")
            if lv == "null" or lv < cutoff:
                results.append((filename, s["heading"]))
    return results


def find_unverified(memories: dict[str, list[dict]]) -> list[tuple[str, str]]:
    """Return (filename, heading) pairs for entries with verified_count == 0."""
    results: list[tuple[str, str]] = []
    for filename, sections in memories.items():
        for s in sections:
            vc = int(s["metadata"].get("verified_count", "0"))
            if vc == 0:
                results.append((filename, s["heading"]))
    return results


def find_promotable(memories: dict[str, list[dict]]) -> list[tuple[str, str]]:
    """Return (filename, heading) pairs eligible for confidence promotion.

    An entry is promotable when verified_count >= 3 and confidence is not 'high'.
    """
    results: list[tuple[str, str]] = []
    for filename, sections in memories.items():
        for s in sections:
            vc = int(s["metadata"].get("verified_count", "0"))
            conf = s["metadata"].get("confidence", "unknown")
            if vc >= 3 and conf != "high":
                results.append((filename, s["heading"]))
    return results


def confidence_mismatch(section: dict) -> str | None:
    """Check if confidence doesn't match evidence.  Returns warning or None."""
    conf = section["metadata"].get("confidence", "unknown")
    vc = int(section["metadata"].get("verified_count", "0"))
    src = section["metadata"].get("source", "unknown")
    # Corrections legitimately start at high confidence without verification
    if src == "correction" and vc == 0:
        return None
    if conf == "high" and vc == 0:
        return f"'{section['heading']}' — confidence=high but verified_count=0"
    if conf == "low" and vc >= 3:
        return f"'{section['heading']}' — confidence=low but verified_count={vc}, consider promoting"
    return None
