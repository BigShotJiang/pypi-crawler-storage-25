"""Session-end reflection — summarize what changed during this session.

Exports:
    session_reflect  — generate a session-end reflection report

Consumers:
    server.py (reflect tool)
"""
from __future__ import annotations

from datetime import date

from .consolidate import consolidate
from .staging import list_staged, _recommend


def _entries_today(memories: dict[str, list[dict]]) -> list[dict]:
    """Return entries recorded today (last_verified == today, verified_count == 1)."""
    today = str(date.today())
    results: list[dict] = []
    for filename, sections in memories.items():
        for s in sections:
            lv = s["metadata"].get("last_verified", "")
            vc = int(s["metadata"].get("verified_count", "0"))
            if lv == today and vc == 1:
                results.append({
                    "heading": s["heading"],
                    "file": filename,
                    "source": s["metadata"].get("source", "unknown"),
                })
    return results


def _verified_today(memories: dict[str, list[dict]]) -> list[dict]:
    """Return entries re-verified today (last_verified == today, verified_count > 1)."""
    today = str(date.today())
    results: list[dict] = []
    for filename, sections in memories.items():
        for s in sections:
            lv = s["metadata"].get("last_verified", "")
            vc = int(s["metadata"].get("verified_count", "0"))
            if lv == today and vc > 1:
                results.append({
                    "heading": s["heading"],
                    "file": filename,
                    "verified_count": vc,
                })
    return results


def _anti_patterns_today(memories: dict[str, list[dict]]) -> list[dict]:
    """Return anti-patterns recorded today."""
    today = str(date.today())
    results: list[dict] = []
    for s in memories.get("anti-patterns", []):
        entry_date = s["metadata"].get("date", "")
        if entry_date == today:
            results.append({
                "heading": s["heading"],
                "body": s["body"],
            })
    return results


def session_reflect(
    memories: dict[str, list[dict]],
    frontmatter: dict[str, dict],
    store=None,
) -> str:
    """Generate a session-end reflection report from memory state.

    Args:
        memories: Full parsed memories from store.load_all().
        frontmatter: Frontmatter dicts from store.load_frontmatter_only().
        store: Optional MemoryStore for staged entry integration.

    Returns compact markdown (< 500 words target).
    """
    today = str(date.today())
    lines: list[str] = [f"# Session Reflection — {today}", ""]

    # 1. Entries recorded today
    recorded = _entries_today(memories)
    lines.append("## Entries Recorded Today")
    if recorded:
        for e in recorded:
            lines.append(f"- **{e['heading']}** ({e['file']}.md) — {e['source']}")
    else:
        lines.append("- None")
    lines.append("")

    # 2. Entries verified today
    verified = _verified_today(memories)
    lines.append("## Entries Verified Today")
    if verified:
        for e in verified:
            lines.append(
                f"- **{e['heading']}** ({e['file']}.md) "
                f"— verified_count: {e['verified_count']}"
            )
    else:
        lines.append("- None")
    lines.append("")

    # 3. Anti-patterns from today
    anti_patterns = _anti_patterns_today(memories)
    lines.append("## Anti-Patterns from Today")
    if anti_patterns:
        for e in anti_patterns:
            # Extract lesson line from body
            lesson = ""
            for body_line in e["body"].splitlines():
                if body_line.startswith("Lesson:"):
                    lesson = body_line
                    break
            lines.append(f"- **{e['heading']}**")
            if lesson:
                lines.append(f"  → {lesson}")
    else:
        lines.append("- None")
    lines.append("")

    # 4. Consolidation suggestions (reuse existing engine)
    consolidation = consolidate(memories)
    lines.append("## Consolidation Suggestions")
    if "looks healthy" in consolidation.lower():
        lines.append("- None — memory is healthy")
    else:
        # Extract just the count summary, not full details
        suggestion_lines = [
            l for l in consolidation.splitlines() if l.startswith("- ")
        ]
        count = len(suggestion_lines)
        # Group by type
        overlaps = sum(1 for l in suggestion_lines if "overlap" in l.lower())
        mismatches = sum(1 for l in suggestion_lines if "mismatch" in l.lower())
        stale = sum(1 for l in suggestion_lines if "stale" in l.lower())
        merges = sum(1 for l in suggestion_lines if "merge" in l.lower())
        promotable = sum(1 for l in suggestion_lines if "promote" in l.lower())
        parts: list[str] = []
        if overlaps:
            parts.append(f"{overlaps} potential overlaps")
        if mismatches:
            parts.append(f"{mismatches} confidence mismatches")
        if stale:
            parts.append(f"{stale} stale entries")
        if merges:
            parts.append(f"{merges} merge candidates")
        if promotable:
            parts.append(f"{promotable} promotable entries")
        if parts:
            lines.append(f"- {', '.join(parts)}")
        else:
            lines.append(f"- {count} suggestions (run `consolidate` for details)")
    lines.append("")

    # 4b. Staged entries awaiting review (R3)
    if store is not None:
        staged = list_staged(store=store)
        if staged:
            lines.append(f"## Staged for Review ({len(staged)} entries)")
            for e in staged:
                rec = _recommend(e)
                ann = e.get("annotations", "")
                lines.append(f"### {e['heading']} → {e['proposed_file']}.md")
                lines.append(f"> {e['body']}")
                lines.append(f"- Annotations: {ann}")
                lines.append(f"- Recommendation: **{rec}**")
                lines.append("")
            lines.append('Quick actions: "promote all recommended" or review individually.')
            lines.append("")

    # 5. Session stats
    total = sum(len(secs) for secs in memories.values())
    recorded_count = len(recorded)
    verified_count = len(verified)
    ap_count = len(anti_patterns)

    lines.append("## Session Stats")
    lines.append(
        f"- Entries recorded: {recorded_count}, "
        f"verified: {verified_count}, "
        f"anti-patterns: {ap_count}"
    )
    lines.append(f"- Total entries: {total} across {len(memories)} files")

    # Files updated today
    updated_files = [
        name for name, fm in frontmatter.items()
        if fm.get("last_updated") == today
    ]
    if updated_files:
        lines.append(f"- Files touched: {', '.join(sorted(updated_files))}")

    return "\n".join(lines)
