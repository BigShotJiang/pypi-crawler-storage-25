"""TOML config loader for graphify.toml files."""
from __future__ import annotations

import tomllib
from pathlib import Path


def load_config(config_path: Path) -> dict:
    """Load and validate a graphify.toml config file.

    Returns a dict with keys: project (str), graphs (dict of graph configs).
    Each graph config has: input, output, method, and optional labels.
    """
    if not config_path.exists():
        raise FileNotFoundError(
            f"Config not found: {config_path}\n"
            "Create a graphify.toml — see aidiary README for format."
        )
    with open(config_path, "rb") as f:
        config = tomllib.load(f)
    if "graphs" not in config:
        raise ValueError(f"{config_path}: missing [graphs] section")
    for name, graph in config["graphs"].items():
        for key in ("input", "output", "method"):
            if key not in graph:
                raise ValueError(f"{config_path}: graphs.{name} missing '{key}'")
        if graph["method"] not in ("ast", "semantic"):
            raise ValueError(
                f"{config_path}: graphs.{name}.method must be 'ast' or 'semantic', "
                f"got '{graph['method']}'"
            )
    return config
