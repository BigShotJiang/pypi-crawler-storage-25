"""Graph build utilities for aidiary — unified rebuild pipeline.

Wraps graphify's pure-Python pipeline (detect → extract → build → cluster →
analyze → report → export) behind a config-driven API.

Requires: pip install 'aidiary[graphs]'

Public API:
    load_config     — Load and validate a graphify.toml config file.
    rebuild_graph   — Rebuild a single named graph (AST or semantic).
    rebuild_all     — Rebuild all graphs defined in a config.
"""
from __future__ import annotations

from .config import load_config
from .pipeline import rebuild_all, rebuild_graph

__all__ = ["load_config", "rebuild_all", "rebuild_graph"]
