"""CLI entry point for rebuild-graphs command."""
from __future__ import annotations

import argparse
import sys
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="rebuild-graphs",
        description="Rebuild knowledge graphs from graphify.toml config.",
    )
    parser.add_argument(
        "--config", type=Path, default=Path("graphify.toml"),
        help="Path to graphify.toml (default: ./graphify.toml)",
    )
    parser.add_argument(
        "--code-only", action="store_true",
        help="Rebuild only AST (code) graphs, skip semantic graphs.",
    )
    parser.add_argument(
        "--build-only", action="store_true",
        help="Build from existing semantic cache only (skip freshness check).",
    )
    parser.add_argument(
        "--fresh", action="store_true",
        help="Clear caches and report what needs LLM extraction.",
    )
    args = parser.parse_args()

    from .config import load_config
    from .pipeline import rebuild_all

    try:
        config = load_config(args.config)
    except (FileNotFoundError, ValueError) as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)

    project_root = args.config.resolve().parent
    results = rebuild_all(
        config, project_root,
        code_only=args.code_only,
        fresh=args.fresh,
        build_only=args.build_only,
    )

    # Exit with error if any graph failed
    if any(r["status"] == "error" for r in results.values()):
        sys.exit(1)


if __name__ == "__main__":
    main()
