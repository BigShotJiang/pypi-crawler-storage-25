"""Unified graph rebuild pipeline — AST and semantic.

All graphify imports are lazy. If graphify is not installed, a clear
ImportError is raised at call time with install instructions.
"""
from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path


def _require_graphify() -> None:
    """Raise clear error if graphify is not installed."""
    try:
        import graphify  # noqa: F401
    except ImportError:
        raise ImportError(
            "graphifyy is required for graph utilities.\n"
            "Install with: pip install 'aidiary[graphs]'\n"
            "Or:           uv add --dev 'graphifyy[mcp]>=0.4.23'"
        ) from None


def _corpus_hash(input_dir: Path) -> str:
    """SHA256 of sorted (filename, file-content-hash) pairs."""
    entries = []
    for f in sorted(input_dir.glob("*.md")):
        h = hashlib.sha256(f.read_bytes()).hexdigest()
        entries.append(f"{f.name}:{h}")
    return hashlib.sha256("\n".join(entries).encode()).hexdigest()


def _build_and_export(
    extraction: dict,
    output_dir: Path,
    detection: dict,
    labels_override: dict[int, str],
    source_label: str,
) -> dict:
    """Build graph, cluster, analyze, report, export. Returns summary dict."""
    from graphify.analyze import god_nodes, suggest_questions, surprising_connections
    from graphify.build import build_from_json
    from graphify.cluster import cluster, score_all
    from graphify.export import to_html, to_json
    from graphify.report import generate

    G = build_from_json(extraction)
    communities = cluster(G)
    cohesion = score_all(G, communities)
    gods = god_nodes(G)
    surprises = surprising_connections(G, communities)

    # Auto-label communities, with optional overrides
    labels: dict[int, str] = {}
    for cid, members in communities.items():
        if cid in labels_override:
            labels[cid] = labels_override[cid]
        else:
            top = []
            for nid in members[:3]:
                if nid in G.nodes:
                    top.append(G.nodes[nid].get("label", nid))
            labels[cid] = top[0] if top else f"Community {cid}"

    questions = suggest_questions(G, communities, labels)

    analysis = {
        "communities": {str(k): v for k, v in communities.items()},
        "cohesion": {str(k): v for k, v in cohesion.items()},
        "gods": gods,
        "surprises": surprises,
        "questions": questions,
    }
    (output_dir / ".graphify_analysis.json").write_text(json.dumps(analysis, indent=2))

    tokens = {
        "input": extraction.get("input_tokens", 0),
        "output": extraction.get("output_tokens", 0),
    }
    report = generate(
        G, communities, cohesion, labels, gods, surprises,
        detection, tokens, source_label, suggested_questions=questions,
    )
    (output_dir / "GRAPH_REPORT.md").write_text(report)
    to_json(G, communities, str(output_dir / "graph.json"))
    (output_dir / ".graphify_labels.json").write_text(
        json.dumps({str(k): v for k, v in labels.items()})
    )

    if G.number_of_nodes() <= 5000:
        to_html(G, communities, str(output_dir / "graph.html"), community_labels=labels)

    return {
        "nodes": G.number_of_nodes(),
        "edges": G.number_of_edges(),
        "communities": len(communities),
    }


def rebuild_graph(
    name: str,
    graph_config: dict,
    project_root: Path,
    *,
    fresh: bool = False,
    build_only: bool = False,
) -> dict:
    """Rebuild a single graph. Returns a result dict with status and stats.

    Args:
        name: Graph name (e.g. "code", "docs", "mem").
        graph_config: Dict with keys: input, output, method, and optional labels.
        project_root: Root directory of the subproject.
        fresh: If True, clear cache and report what needs extraction.
        build_only: If True, skip detection and build from cache only.

    Returns:
        Dict with "status" ("success" | "needs_extraction" | "skipped" | "error")
        and optional "nodes", "edges", "communities" on success.
    """
    _require_graphify()

    method = graph_config["method"]
    input_dir = project_root / graph_config["input"]
    output_dir = project_root / graph_config["output"]
    labels_override = {int(k): v for k, v in graph_config.get("labels", {}).items()}

    output_dir.mkdir(exist_ok=True)
    t0 = time.monotonic()

    if method == "ast":
        return _rebuild_ast(name, input_dir, output_dir, labels_override)
    elif method == "semantic":
        return _rebuild_semantic(
            name, input_dir, output_dir, labels_override,
            fresh=fresh, build_only=build_only,
        )
    else:
        return {"status": "error", "message": f"Unknown method: {method}"}


def _rebuild_ast(
    name: str,
    input_dir: Path,
    output_dir: Path,
    labels_override: dict[int, str],
) -> dict:
    """Rebuild an AST-based (code) graph."""
    from graphify.detect import detect
    from graphify.extract import extract

    t0 = time.monotonic()

    detection = detect(input_dir)
    (output_dir / ".graphify_detect.json").write_text(json.dumps(detection, indent=2))
    code_files = detection["files"].get("code", [])

    if not code_files:
        print(f"  {name}: no code files found — skipping.")
        return {"status": "skipped", "message": "No code files found"}

    extraction = extract([Path(f) for f in code_files])
    (output_dir / ".graphify_extract.json").write_text(json.dumps(extraction, indent=2))

    stats = _build_and_export(
        extraction, output_dir, detection, labels_override, input_dir.name,
    )
    elapsed = time.monotonic() - t0
    print(f"  {name}: ✅ {stats['nodes']} nodes, {stats['edges']} edges, "
          f"{stats['communities']} communities ({elapsed:.1f}s)")
    return {"status": "success", **stats}


def _rebuild_semantic(
    name: str,
    input_dir: Path,
    output_dir: Path,
    labels_override: dict[int, str],
    *,
    fresh: bool = False,
    build_only: bool = False,
) -> dict:
    """Rebuild a semantic (doc/mem) graph from cache."""
    from graphify.detect import detect

    semantic_path = output_dir / ".graphify_semantic.json"
    hash_path = output_dir / ".graphify_corpus_hash"

    # --fresh: clear cache and report
    if fresh:
        if hash_path.exists():
            hash_path.unlink()
        print(f"  {name}: cache cleared. Run: /graphify {input_dir.name} --update")
        return {"status": "needs_extraction"}

    # Check cache exists
    if not semantic_path.exists():
        print(f"  {name}: ⚠️  no cache. Run: /graphify {input_dir.name}")
        return {"status": "needs_extraction"}

    # Check cache freshness (skip if --build-only)
    if not build_only:
        detection = detect(input_dir)
        (output_dir / ".graphify_detect.json").write_text(json.dumps(detection, indent=2))

        current_hash = _corpus_hash(input_dir)
        if hash_path.exists():
            cached_hash = hash_path.read_text().strip()
            if cached_hash != current_hash:
                print(f"  {name}: ⚠️  files changed. Run: /graphify {input_dir.name} --update")
                return {"status": "needs_extraction"}
    else:
        # Provide minimal detection dict for report generation
        detection = {"files": {}, "total_words": 0, "total_files": 0}

    # Build from cache
    t0 = time.monotonic()
    semantic = json.loads(semantic_path.read_text())
    extraction = {
        "nodes": semantic.get("nodes", []),
        "edges": semantic.get("edges", []),
        "hyperedges": semantic.get("hyperedges", []),
        "input_tokens": semantic.get("input_tokens", 0),
        "output_tokens": semantic.get("output_tokens", 0),
    }
    (output_dir / ".graphify_extract.json").write_text(json.dumps(extraction, indent=2))

    stats = _build_and_export(
        extraction, output_dir, detection, labels_override, input_dir.name,
    )

    # Save corpus hash
    if not build_only:
        hash_path.write_text(_corpus_hash(input_dir))

    elapsed = time.monotonic() - t0
    source = "from cache" if not build_only else "from fresh cache"
    print(f"  {name}: ✅ {stats['nodes']} nodes, {stats['edges']} edges, "
          f"{stats['communities']} communities ({source}, {elapsed:.1f}s)")
    return {"status": "success", **stats}


def rebuild_all(
    config: dict,
    project_root: Path,
    *,
    code_only: bool = False,
    fresh: bool = False,
    build_only: bool = False,
) -> dict[str, dict]:
    """Rebuild all graphs defined in config. Returns dict of name → result."""
    project = config.get("project", project_root.name)
    print(f"\n=== {project} ===")

    results = {}
    for name, graph_config in config["graphs"].items():
        if code_only and graph_config["method"] != "ast":
            continue
        results[name] = rebuild_graph(
            name, graph_config, project_root,
            fresh=fresh, build_only=build_only,
        )

    # Summary
    total = len(results)
    success = sum(1 for r in results.values() if r["status"] == "success")
    needs = sum(1 for r in results.values() if r["status"] == "needs_extraction")

    print()
    if needs > 0:
        print(f"Summary: {success}/{total} graphs rebuilt, {needs} need LLM extraction")
        print("After extraction, re-run: rebuild-graphs --build-only")
    else:
        print(f"Summary: {success}/{total} graphs rebuilt. All up to date.")

    return results
