"""Memory staging — propose-and-queue entries for human review before promotion.

Exports:
    stage          — stage a proposed entry with automated quality checks
    review_staged  — promote, reject, or list staged entries
    list_staged    — return all currently staged entries

Consumers:
    server.py (stage + review_staged tools), reflect.py (R3 integration)
"""
from __future__ import annotations

import re
from datetime import date

from .constitution import validate_entry, validate_filename
from .consolidate import find_contradictions
from .search import search_memories
from .store import MemoryStore, format_section, format_frontmatter, parse_frontmatter, parse_sections


# ── Constants ────────────────────────────────────────────────────────────

STAGING_FILENAME = "staging"
OVERLAP_LIMIT = 3  # max overlaps to report per staged entry


# ── Stage ────────────────────────────────────────────────────────────────

def stage(
    heading: str,
    body: str,
    proposed_file: str,
    metadata: dict,
    *,
    store: MemoryStore,
    memories: dict[str, list[dict]],
) -> dict:
    """Stage an entry for human review with automated quality checks.

    Returns a dict with staging result and annotations.
    """
    annotations: list[str] = []
    today = str(date.today())

    # 1. Constitution validation
    fname_errors = validate_filename(proposed_file)
    if fname_errors:
        return {"status": "rejected", "reason": fname_errors}

    entry_errors = validate_entry(heading, body, metadata)
    if entry_errors:
        return {"status": "rejected", "reason": entry_errors}
    annotations.append("constitution: pass")

    # 2. Duplicate/overlap check via recall
    query_terms = heading
    results = search_memories(query_terms, memories)
    overlaps = [r for r in results if r["score"] >= 1][:OVERLAP_LIMIT]
    if overlaps:
        overlap_desc = ", ".join(
            f'"{r["heading"]}" ({r["file"]}.md)'
            for r in overlaps
        )
        annotations.append(f"{len(overlaps)} overlap(s): {overlap_desc}")
    else:
        annotations.append("0 overlaps")

    # 3. Contradiction check — add proposed entry temporarily
    temp_entry = {
        "heading": heading,
        "body": body,
        "metadata": metadata,
    }
    augmented = dict(memories)
    augmented_file = augmented.get(proposed_file, []) + [temp_entry]
    augmented[proposed_file] = augmented_file
    contradictions = find_contradictions(augmented)
    # Filter to only contradictions involving our new entry
    relevant = [
        c for c in contradictions
        if heading.lower() in c[1].lower() or heading.lower() in c[3].lower()
    ]
    if relevant:
        annotations.append(f"{len(relevant)} contradiction(s)")
    else:
        annotations.append("0 contradictions")

    # 4. Write to staging.md
    staging_meta = dict(metadata)
    staging_meta["staged_date"] = today
    staging_meta["proposed_file"] = proposed_file
    staging_meta["annotations"] = "; ".join(annotations)

    filepath = store._dir / f"{STAGING_FILENAME}.md"
    section_text = format_section(heading, body, staging_meta)

    if filepath.exists():
        content = filepath.read_text(encoding="utf-8")
        fm, rest = parse_frontmatter(content)
        if fm:
            fm["entry_count"] = fm.get("entry_count", 0) + 1
            fm["last_updated"] = today
            content = format_frontmatter(fm) + "\n" + rest
        if not content.endswith("\n"):
            content += "\n"
        content += "\n" + section_text + "\n"
    else:
        fm = {
            "description": "Staged entries awaiting human review",
            "entry_count": 1,
            "last_updated": today,
        }
        content = format_frontmatter(fm) + "\n# Staging\n\n" + section_text + "\n"

    filepath.write_text(content, encoding="utf-8")
    store._invalidate()

    return {
        "status": "staged",
        "heading": heading,
        "proposed_file": proposed_file,
        "annotations": annotations,
        "has_overlaps": len(overlaps) > 0,
        "has_contradictions": len(relevant) > 0,
    }


# ── Review ───────────────────────────────────────────────────────────────

def list_staged(*, store: MemoryStore) -> list[dict]:
    """Return all currently staged entries with their annotations."""
    filepath = store._dir / f"{STAGING_FILENAME}.md"
    if not filepath.exists():
        return []
    content = filepath.read_text(encoding="utf-8")
    _fm, body = parse_frontmatter(content)
    sections = parse_sections(body)
    results = []
    for s in sections:
        results.append({
            "heading": s["heading"],
            "body": s["body"],
            "proposed_file": s["metadata"].get("proposed_file", "unknown"),
            "annotations": s["metadata"].get("annotations", ""),
            "staged_date": s["metadata"].get("staged_date", ""),
            "confidence": s["metadata"].get("confidence", "medium"),
            "source": s["metadata"].get("source", "observation"),
            "scope": s["metadata"].get("scope", "project"),
            "metadata": s["metadata"],
        })
    return results


def _recommend(entry: dict) -> str:
    """Compute a recommendation for a staged entry based on annotations."""
    ann = entry.get("annotations", "")
    if "0 overlaps" in ann and "0 contradictions" in ann and "constitution: pass" in ann:
        return "PROMOTE"
    if "contradiction" in ann.lower():
        return "REVIEW"
    if "overlap" in ann.lower() and "0 overlaps" not in ann:
        return "REVIEW"
    return "PROMOTE"


def review_staged(
    heading: str | None,
    action: str,
    *,
    store: MemoryStore,
) -> dict:
    """Promote, reject, or list staged entries.

    Args:
        heading: Entry heading (required for promote/reject, ignored for list).
        action: One of 'promote', 'reject', 'list'.
        store: MemoryStore instance.

    Returns:
        dict with keys:
        - action="list":    {"action": "list", "entries": [{"heading", "body", "proposed_file", "annotations", "recommendation", ...}]}
        - action="promote": {"action": "promote", "heading": str, "target": str}
        - action="reject":  {"action": "reject", "heading": str}
        - error:            {"action": action, "error": str}
    """
    if action == "list":
        entries = list_staged(store=store)
        enriched = []
        for e in entries:
            e["recommendation"] = _recommend(e)
            enriched.append(e)
        return {"action": "list", "entries": enriched}

    if not heading:
        return {"action": action, "error": "heading is required for promote/reject actions."}

    # Find the staged entry
    entries = list_staged(store=store)
    match = None
    for e in entries:
        if e["heading"].strip().lower() == heading.strip().lower():
            match = e
            break
    if not match:
        return {"action": action, "error": f"'{heading}' not found in staging."}

    if action == "promote":
        # Write to target file via store.append
        target = match["proposed_file"]
        meta = {
            "confidence": match.get("confidence", "medium"),
            "source": match.get("source", "observation"),
            "scope": match.get("scope", "project"),
            "verified_count": "1",
            "last_verified": str(date.today()),
        }
        store.append(target, match["heading"], match["body"], meta, upsert=True)
        # Remove from staging
        _remove_from_staging(heading, store=store)
        return {"action": "promote", "heading": heading, "target": target}

    elif action == "reject":
        _remove_from_staging(heading, store=store)
        return {"action": "reject", "heading": heading}

    else:
        return {"action": action, "error": f"unknown action '{action}'. Use promote, reject, or list."}


def _remove_from_staging(heading: str, *, store: MemoryStore) -> None:
    """Remove a section from staging.md and update frontmatter."""
    filepath = store._dir / f"{STAGING_FILENAME}.md"
    if not filepath.exists():
        return

    content = filepath.read_text(encoding="utf-8")
    fm, rest = parse_frontmatter(content)
    sections = parse_sections(rest)

    needle = heading.strip().lower()
    sections = [s for s in sections if s["heading"].strip().lower() != needle]

    if fm:
        fm["entry_count"] = len(sections)
        fm["last_updated"] = str(date.today())

    parts = [format_frontmatter(fm)] if fm else []
    title_match = re.match(r"^(#\s+.+\n?)", rest)
    if title_match:
        parts.append(title_match.group(1).rstrip())
    for sec in sections:
        parts.append("")
        parts.append(format_section(sec["heading"], sec["body"], sec["metadata"]))
    filepath.write_text("\n".join(parts) + "\n", encoding="utf-8")
    store._invalidate()
