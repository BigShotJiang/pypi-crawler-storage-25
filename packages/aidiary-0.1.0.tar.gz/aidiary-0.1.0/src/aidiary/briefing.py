"""Session-start memory briefing — compact summary for agent orientation.

Exports:
    briefing  — generate a session-start briefing from memory state

Consumers:
    server.py (briefing tool)
"""
from __future__ import annotations

from datetime import date, timedelta

from .consolidate import find_contradictions
from .scoring import find_stale, find_unverified, confidence_mismatch
from .search import search_memories


# ── Configurable knobs ───────────────────────────────────────────────────

TOP_CONVENTIONS_LIMIT = 5
ANTI_PATTERN_DAYS = 7
ANTI_PATTERN_LIMIT = 5
HEALTH_WARNING_LIMIT = 3
MAX_WORDS_PER_ENTRY = 30


def _truncate(text: str, max_words: int = MAX_WORDS_PER_ENTRY) -> str:
    """Truncate text to max_words."""
    words = text.split()
    if len(words) <= max_words:
        return text
    return " ".join(words[:max_words]) + "…"


def _top_entries(
    memories: dict[str, list[dict]],
    confidence: str = "high",
    limit: int = TOP_CONVENTIONS_LIMIT,
) -> list[dict]:
    """Select top entries by verified_count with the given confidence level."""
    candidates: list[dict] = []
    for filename, sections in memories.items():
        if filename == "anti-patterns":
            continue  # anti-patterns are handled separately
        for s in sections:
            if s["metadata"].get("confidence") == confidence:
                vc = int(s["metadata"].get("verified_count", "0"))
                candidates.append({
                    "heading": s["heading"],
                    "file": filename,
                    "verified_count": vc,
                    "body": s["body"],
                })
    candidates.sort(key=lambda c: c["verified_count"], reverse=True)
    return candidates[:limit]


def _recent_anti_patterns(
    memories: dict[str, list[dict]],
    days: int = ANTI_PATTERN_DAYS,
) -> list[dict]:
    """Select anti-patterns from the last N days."""
    cutoff = str(date.today() - timedelta(days=days))
    results: list[dict] = []
    for s in memories.get("anti-patterns", []):
        entry_date = s["metadata"].get("date", "")
        if entry_date >= cutoff:
            results.append({
                "heading": s["heading"],
                "date": entry_date,
                "body": s["body"],
            })
    return results[:ANTI_PATTERN_LIMIT]


def _health_summary(
    *,
    total_entries: int,
    total_files: int,
    n_stale: int,
    n_mismatches: int,
    n_contradictions: int,
) -> list[str]:
    """Return a structured ## Memory Health section for agent orientation."""
    if n_stale >= 5 or n_mismatches >= 3 or n_contradictions >= 3:
        status = "\U0001f534 action required"
    elif n_stale or n_mismatches or n_contradictions:
        status = "\u26a0\ufe0f needs attention"
    else:
        status = "\u2705 healthy"
    return [
        "## Memory Health",
        f"- Status: {status}",
        f"- {total_entries} entries, {total_files} files, "
        f"{n_stale} stale, {n_mismatches} mismatches, "
        f"{n_contradictions} contradictions",
    ]


def briefing(
    memories: dict[str, list[dict]],
    frontmatter: dict[str, dict],
    context: str | None = None,
) -> str:
    """Generate a session-start briefing from memory state.

    Args:
        memories: Full parsed memories from store.load_all().
        frontmatter: Frontmatter dicts from store.load_frontmatter_only().
        context: Optional topic to focus the briefing on.

    Returns:
        Compact markdown briefing (< 500 tokens target).
    """
    # If context provided, filter memories to relevant entries first
    if context:
        relevant_headings = {
            r["heading"]
            for r in search_memories(context, memories)
        }
        filtered: dict[str, list[dict]] = {}
        for fname, sections in memories.items():
            filtered_secs = [
                s for s in sections if s["heading"] in relevant_headings
            ]
            if filtered_secs:
                filtered[fname] = filtered_secs
        working_memories = filtered if filtered else memories
    else:
        working_memories = memories

    lines: list[str] = ["# Session Briefing", ""]

    # 0. Reflections (highest-order knowledge, shown first if any exist)
    reflections = working_memories.get("reflections", [])
    if reflections:
        lines.append("## Reflections (synthesized principles)")
        for s in reflections[:3]:
            summary = _truncate(s["body"])
            derived = s["metadata"].get("derived_from", "")
            derived_note = f" [from: {derived}]" if derived else ""
            lines.append(f"- **{s['heading']}**{derived_note}")
            lines.append(f"  → {summary}")
        lines.append("")

    # 1. Top conventions
    top = _top_entries(working_memories)
    if top:
        lines.append("## Top Conventions (high-confidence)")
        for entry in top:
            summary = _truncate(entry["body"])
            lines.append(
                f"- **{entry['heading']}** ({entry['file']}.md) "
                f"— verified {entry['verified_count']}×"
            )
        lines.append("")

    # 2. Recent anti-patterns
    recent = _recent_anti_patterns(working_memories)
    if recent:
        lines.append("## Recent Anti-Patterns (last 7 days)")
        for entry in recent:
            summary = _truncate(entry["body"])
            lines.append(f"- **{entry['heading']}** — {entry['date']}")
            lines.append(f"  → {summary}")
        lines.append("")

    # 3. Health warnings
    stale = find_stale(memories)  # always check full corpus
    mismatches: list[str] = []
    for sections in memories.values():
        for s in sections:
            warning = confidence_mismatch(s)
            if warning:
                mismatches.append(warning)

    warnings: list[str] = []
    if stale:
        warnings.append(
            f"{len(stale)} stale entries (never verified or >30 days): "
            + ", ".join(h for _, h in stale[:HEALTH_WARNING_LIMIT])
        )
    if mismatches:
        warnings.append(
            f"{len(mismatches)} confidence mismatches: "
            + ", ".join(mismatches[:HEALTH_WARNING_LIMIT])
        )
    contradictions = find_contradictions(memories)
    if contradictions:
        warnings.append(
            f"{len(contradictions)} potential contradictions detected"
        )

    if warnings:
        lines.append("## Health Warnings")
        for w in warnings[:HEALTH_WARNING_LIMIT]:
            lines.append(f"- {w}")
        lines.append("")

    # 4. Memory Health (structured summary for agent decision-making)
    lines.extend(_health_summary(
        total_entries=sum(len(secs) for secs in memories.values()),
        total_files=len(memories),
        n_stale=len(stale),
        n_mismatches=len(mismatches),
        n_contradictions=len(contradictions),
    ))
    lines.append("")

    # 5. Quick stats
    total = sum(len(secs) for secs in memories.values())
    conf_dist: dict[str, int] = {}
    for sections in memories.values():
        for s in sections:
            conf = s["metadata"].get("confidence", "unknown")
            conf_dist[conf] = conf_dist.get(conf, 0) + 1

    lines.append("## Quick Stats")
    lines.append(f"- {total} entries across {len(memories)} files")
    conf_parts = [f"{v} {k}" for k, v in sorted(conf_dist.items())]
    lines.append(f"- Confidence: {', '.join(conf_parts)}")

    # Find most recent last_updated from frontmatter
    dates = [fm.get("last_updated", "") for fm in frontmatter.values()]
    latest = max(dates) if dates else "unknown"
    lines.append(f"- Last updated: {latest}")

    return "\n".join(lines)
