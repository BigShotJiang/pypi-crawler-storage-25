"""Memory store — markdown I/O with caching and YAML frontmatter support.

Exports:
    MemoryStore  — cached read/write interface for memory files

Consumers:
    server.py, search.py, scoring.py, consolidate.py
"""
from __future__ import annotations

import re
from datetime import date
from pathlib import Path


class DuplicateHeadingError(ValueError):
    """Raised when an entry with the same heading already exists in a file."""


# Metadata keys recognised inside ## sections
_META_KEYS = frozenset({
    "confidence", "source", "scope", "verified_count",
    "last_verified", "supersedes", "corrected_by", "date",
    "archived_from", "archived_date", "derived_from",
    "staged_date", "proposed_file", "annotations",
})


# ── Parsing ──────────────────────────────────────────────────────────────

def parse_frontmatter(text: str) -> tuple[dict, str]:
    """Split YAML frontmatter from body.  Returns (frontmatter_dict, rest)."""
    if not text.startswith("---"):
        return {}, text
    end = text.find("\n---", 3)
    if end == -1:
        return {}, text
    fm_block = text[4:end]  # skip leading "---\n"
    rest = text[end + 4:]   # skip closing "---\n"
    fm: dict = {}
    for line in fm_block.splitlines():
        m = re.match(r'^(\w[\w_]*):\s*(.+)$', line)
        if m:
            key, val = m.group(1), m.group(2).strip()
            # Parse simple YAML values
            if val.startswith("[") and val.endswith("]"):
                fm[key] = [v.strip().strip('"').strip("'") for v in val[1:-1].split(",")]
            elif val.isdigit():
                fm[key] = int(val)
            elif val in ("true", "false"):
                fm[key] = val == "true"
            else:
                fm[key] = val.strip('"').strip("'")
    return fm, rest


def parse_sections(text: str) -> list[dict]:
    """Parse a markdown file (after frontmatter) into sections with metadata."""
    sections: list[dict] = []
    current: dict | None = None
    body_lines: list[str] = []

    for line in text.splitlines():
        if line.startswith("## "):
            if current is not None:
                current["body"] = "\n".join(body_lines).strip()
                sections.append(current)
            current = {"heading": line[3:].strip(), "metadata": {}, "body": ""}
            body_lines = []
        elif current is not None:
            m = re.match(r"^- (\w+):\s*(.+)$", line)
            if m and m.group(1) in _META_KEYS:
                current["metadata"][m.group(1)] = m.group(2).strip()
            else:
                body_lines.append(line)
    if current is not None:
        current["body"] = "\n".join(body_lines).strip()
        sections.append(current)
    return sections


def format_section(heading: str, body: str, metadata: dict) -> str:
    """Format a section as markdown for writing to file."""
    lines = [f"## {heading}"]
    for key in ("confidence", "source", "scope", "verified_count", "last_verified",
                "date", "supersedes", "corrected_by",
                "archived_from", "archived_date", "derived_from",
                "staged_date", "proposed_file", "annotations"):
        if key in metadata:
            lines.append(f"- {key}: {metadata[key]}")
    lines.append("")
    lines.append(body)
    return "\n".join(lines)


def format_frontmatter(fm: dict) -> str:
    """Serialize a frontmatter dict back to YAML block."""
    if not fm:
        return ""
    lines = ["---"]
    for key, val in fm.items():
        if isinstance(val, list):
            lines.append(f"{key}: [{', '.join(val)}]")
        elif isinstance(val, bool):
            lines.append(f"{key}: {'true' if val else 'false'}")
        else:
            lines.append(f"{key}: {val}")
    lines.append("---")
    return "\n".join(lines)


# ── MemoryStore ──────────────────────────────────────────────────────────

class MemoryStore:
    """Cached read/write interface for markdown memory files.

    Caches parsed data in memory.  Any write invalidates the cache so the
    next read re-parses from disk.
    """

    def __init__(self, memories_dir: Path) -> None:
        self._dir = memories_dir
        self._cache: dict[str, list[dict]] | None = None
        self._fm_cache: dict[str, dict] | None = None

    # ── Reads ──

    def load_all(self) -> dict[str, list[dict]]:
        """Load all memory files → {stem: [section_dicts]}."""
        if self._cache is not None:
            return self._cache
        result: dict[str, list[dict]] = {}
        if not self._dir.is_dir():
            return result
        for f in sorted(self._dir.glob("*.md")):
            if f.name.startswith("CONSTITUTION"):
                continue  # policy doc, not a memory file
            text = f.read_text(encoding="utf-8")
            _fm, body = parse_frontmatter(text)
            result[f.stem] = parse_sections(body)
        self._cache = result
        return result

    def load_frontmatter_only(self) -> dict[str, dict]:
        """Load only YAML frontmatter from each file (cheap progressive disclosure)."""
        if self._fm_cache is not None:
            return self._fm_cache
        result: dict[str, dict] = {}
        if not self._dir.is_dir():
            return result
        for f in sorted(self._dir.glob("*.md")):
            if f.name.startswith("CONSTITUTION"):
                continue
            text = f.read_text(encoding="utf-8")
            fm, _ = parse_frontmatter(text)
            result[f.stem] = fm
        self._fm_cache = result
        return result

    def load_file(self, filename: str) -> str | None:
        """Read raw content of a single memory file.  Returns None if not found."""
        filepath = self._dir / f"{filename}.md"
        if not filepath.exists():
            return None
        return filepath.read_text(encoding="utf-8")

    def heading_exists(self, filename: str, heading: str) -> bool:
        """Check if a section with this heading (case-insensitive) already exists."""
        sections = self.load_all().get(filename, [])
        needle = heading.strip().lower()
        return any(s["heading"].strip().lower() == needle for s in sections)

    # ── Helpers ──

    def _safe_write(self, filepath: Path, content: str) -> None:
        """Write content to file, creating parent directories if needed."""
        filepath.parent.mkdir(parents=True, exist_ok=True)
        filepath.write_text(content, encoding="utf-8")

    # ── Writes ──

    def append(self, filename: str, heading: str, body: str, metadata: dict,
               *, upsert: bool = False) -> str:
        """Append a new section to a memory file.  Creates the file if needed.

        When *upsert* is True and the heading already exists, the existing
        entry is replaced in-place (body + metadata updated, verified_count
        incremented).  Returns ``"created"`` or ``"updated"``.

        Raises DuplicateHeadingError when the heading exists and *upsert*
        is False.
        """
        if self.heading_exists(filename, heading):
            if not upsert:
                raise DuplicateHeadingError(
                    f"Entry '{heading}' already exists in {filename}.md — "
                    "use a different heading or update the existing entry."
                )
            return self.replace_section(filename, heading, body, metadata)
        filepath = self._dir / f"{filename}.md"
        section_text = format_section(heading, body, metadata)
        if filepath.exists():
            content = filepath.read_text(encoding="utf-8")
            # Update frontmatter entry_count
            fm, rest = parse_frontmatter(content)
            if fm:
                fm["entry_count"] = fm.get("entry_count", 0) + 1
                fm["last_updated"] = str(date.today())
                content = format_frontmatter(fm) + "\n" + rest
            if not content.endswith("\n"):
                content += "\n"
            content += "\n" + section_text + "\n"
        else:
            title = filename.replace("-", " ").title()
            content = f"# {title}\n\n{section_text}\n"
        self._safe_write(filepath, content)
        self._invalidate()
        return "created"

    def replace_section(self, filename: str, heading: str, body: str,
                        metadata: dict) -> str:
        """Replace an existing section's body and metadata in-place.

        The heading match is case-insensitive.  ``verified_count`` is
        incremented and ``last_verified`` set to today.  Returns
        ``"updated"`` on success.

        Raises ``KeyError`` if the heading is not found.
        """
        filepath = self._dir / f"{filename}.md"
        if not filepath.exists():
            raise KeyError(f"File not found: {filename}.md")

        content = filepath.read_text(encoding="utf-8")
        fm, rest = parse_frontmatter(content)
        sections = parse_sections(rest)

        needle = heading.strip().lower()
        found = False
        for sec in sections:
            if sec["heading"].strip().lower() == needle:
                # Bump verified_count
                old_vc = int(sec["metadata"].get("verified_count", "0"))
                metadata["verified_count"] = str(old_vc + 1)
                metadata["last_verified"] = str(date.today())
                sec["body"] = body
                sec["metadata"] = metadata
                found = True
                break

        if not found:
            raise KeyError(
                f"Entry '{heading}' not found in {filename}.md"
            )

        # Re-assemble file
        if fm:
            fm["last_updated"] = str(date.today())
        parts = [format_frontmatter(fm)] if fm else []
        # Preserve the H1 title line from the original body
        title_match = re.match(r"^(#\s+.+\n?)", rest)
        if title_match:
            parts.append(title_match.group(1).rstrip())
        for sec in sections:
            parts.append("")
            parts.append(format_section(sec["heading"], sec["body"], sec["metadata"]))
        self._safe_write(filepath, "\n".join(parts) + "\n")
        self._invalidate()
        return "updated"

    # ── Lifecycle (archive / restore) ──

    def _remove_section(self, filename: str, heading: str) -> dict:
        """Remove a section from a file, rewrite the file, return the removed section."""
        filepath = self._dir / f"{filename}.md"
        if not filepath.exists():
            raise KeyError(f"File not found: {filename}.md")

        content = filepath.read_text(encoding="utf-8")
        fm, rest = parse_frontmatter(content)
        sections = parse_sections(rest)

        needle = heading.strip().lower()
        found_idx = None
        for i, sec in enumerate(sections):
            if sec["heading"].strip().lower() == needle:
                found_idx = i
                break

        if found_idx is None:
            raise KeyError(f"Entry '{heading}' not found in {filename}.md")

        removed = sections.pop(found_idx)
        if fm:
            fm["entry_count"] = max(0, fm.get("entry_count", 1) - 1)
            fm["last_updated"] = str(date.today())

        parts = [format_frontmatter(fm)] if fm else []
        title_match = re.match(r"^(#\s+.+\n?)", rest)
        if title_match:
            parts.append(title_match.group(1).rstrip())
        for sec in sections:
            parts.append("")
            parts.append(format_section(sec["heading"], sec["body"], sec["metadata"]))
        self._safe_write(filepath, "\n".join(parts) + "\n")
        self._invalidate()
        return removed

    def archive_section(self, filename: str, heading: str) -> str:
        """Move a section from *filename* to archive.md.

        Adds ``archived_from`` and ``archived_date`` metadata.
        Returns a confirmation message.
        """
        removed = self._remove_section(filename, heading)
        archived_meta = dict(removed["metadata"])
        archived_meta["archived_from"] = filename
        archived_meta["archived_date"] = str(date.today())
        self.append("archive", removed["heading"], removed["body"], archived_meta)
        return f"Archived '{heading}' from {filename}.md"

    def restore_section(self, heading: str) -> str:
        """Restore a section from archive.md back to its original file.

        Reads ``archived_from`` metadata to determine the target.  Removes
        archive-specific metadata before restoring.
        """
        removed = self._remove_section("archive", heading)
        target_file = removed["metadata"].get("archived_from")
        if not target_file:
            raise KeyError(
                f"Entry '{heading}' has no archived_from metadata — "
                "cannot determine target file"
            )
        # Validate target to prevent path traversal via crafted metadata
        from aidiary.constitution import validate_filename
        violations = validate_filename(target_file)
        if violations:
            raise ValueError(
                f"Invalid restore target '{target_file}': {violations[0]}"
            )
        restored_meta = dict(removed["metadata"])
        restored_meta.pop("archived_from", None)
        restored_meta.pop("archived_date", None)
        restored_meta["last_verified"] = str(date.today())
        self.append(target_file, removed["heading"], removed["body"], restored_meta)
        return f"Restored '{heading}' to {target_file}.md"

    def _invalidate(self) -> None:
        """Clear all caches — next read re-parses from disk."""
        self._cache = None
        self._fm_cache = None
