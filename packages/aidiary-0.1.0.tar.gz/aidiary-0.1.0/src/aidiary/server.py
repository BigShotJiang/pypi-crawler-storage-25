"""Copilot Memory MCP server — structured read/write/search over collaboration memory.

Provides 7 tools for managing human-AI collaboration knowledge stored as
markdown files in memories/.

Usage:
    python -m aidiary.server [MEMORIES_DIR]

    MEMORIES_DIR defaults to ../memories/ relative to this file's package root.

Register in .vscode/mcp.json for automatic agent access.

Architecture (roadmap #17):
    server.py      — MCP protocol, tool definitions, handler dispatch (this file)
    store.py       — Markdown I/O with caching and frontmatter
    search.py      — Keyword recall engine
    scoring.py     — Health metrics and staleness detection
    consolidate.py — Overlap detection and self-critique
    constitution.py — Write-time validation and policy rules
"""
from __future__ import annotations

import os
import re
import sys
from datetime import date
from pathlib import Path
from typing import Callable


import argparse


def _resolve_memories_dir(cli_path: str | None = None) -> Path:
    """Resolve the memories directory.

    Priority: CLI arg > env var > current working directory ./memories
    """
    if cli_path:
        return Path(cli_path).resolve()
    env = os.environ.get("COPILOT_MEMORY_DIR")
    if env:
        return Path(env).resolve()
    return Path.cwd() / "memories"


def _resolve_output_dir(cli_path: str | None = None) -> Path:
    """Resolve the output directory for dashboard and generated files.

    Priority: CLI arg > env var > current working directory ./output

    The output directory is kept separate from memories/ because
    graphify uses memories/ as input for semantic graph generation.
    Foreign files (HTML, JSON) in memories/ would pollute the graph.
    """
    if cli_path:
        return Path(cli_path).resolve()
    env = os.environ.get("COPILOT_MEMORY_OUTPUT_DIR")
    if env:
        return Path(env).resolve()
    return Path.cwd() / "output"


def serve(memories_path: str | None = None, output_path: str | None = None) -> None:
    """Start the MCP server over stdio.

    Args:
        memories_path: Path to the memories directory.  Falls back to
            ``COPILOT_MEMORY_DIR`` env var, then ``./memories`` in cwd.
        output_path: Path to the output directory for dashboard and
            generated files.  Falls back to ``COPILOT_MEMORY_OUTPUT_DIR``
            env var, then ``./output`` in cwd.
    """
    try:
        from mcp.server import Server
        from mcp.server.stdio import stdio_server
        from mcp import types
    except ImportError as e:
        raise ImportError(
            "mcp not installed. Run: pip install 'mcp>=1.27.0'"
        ) from e

    from .store import MemoryStore, DuplicateHeadingError
    from .search import search_memories
    from .scoring import health_report
    from .consolidate import consolidate
    from .constitution import validate_entry, validate_filename, CONSTITUTION, PROTECTED_FILENAMES, validate_reflection
    from .briefing import briefing
    from .reflect import session_reflect
    from .dashboard import generate_dashboard
    from .transfer import transfer_report as _transfer_report, export_universal as _export_universal
    from .staging import stage as _stage, review_staged as _review_staged, list_staged as _list_staged

    memories_dir = _resolve_memories_dir(memories_path)
    output_dir = _resolve_output_dir(output_path)
    output_dir.mkdir(parents=True, exist_ok=True)
    store = MemoryStore(memories_dir)
    server = Server("copilot-memory")

    # ── Tool definitions ─────────────────────────────────────────────

    TOOLS = [
        types.Tool(
            name="recall",
            description="Search memories by keyword/topic. Returns matching entries ranked by relevance.",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Keywords or topic to search for",
                    },
                },
                "required": ["query"],
            },
        ),
        types.Tool(
            name="remember",
            description="Write a new memory entry to a specific file and section.",
            inputSchema={
                "type": "object",
                "properties": {
                    "file": {
                        "type": "string",
                        "description": "Memory file name (without .md): conventions, workflow, communication, tools, project-setup, research-agenda",
                    },
                    "heading": {
                        "type": "string",
                        "description": "Section heading for the new entry",
                    },
                    "body": {
                        "type": "string",
                        "description": "Content of the memory entry",
                    },
                    "confidence": {
                        "type": "string",
                        "enum": ["high", "medium", "low"],
                        "description": "Confidence level",
                    },
                    "source": {
                        "type": "string",
                        "enum": ["correction", "observation", "conversation", "research"],
                        "description": "Origin of this memory",
                    },
                    "scope": {
                        "type": "string",
                        "enum": ["universal", "project"],
                        "description": "Transfer scope: universal (transfers to any project) or project (workspace-specific). Defaults to project.",
                    },
                    "derived_from": {
                        "type": "string",
                        "description": "Source entries this reflection was derived from (required for reflections.md). Format: '\"Heading\" (file.md), \"Heading2\" (file2.md)'",
                    },
                },
                "required": ["file", "heading", "body", "confidence", "source"],
            },
        ),
        types.Tool(
            name="record_mistake",
            description="Record an anti-pattern with context on what went wrong and the correction.",
            inputSchema={
                "type": "object",
                "properties": {
                    "heading": {
                        "type": "string",
                        "description": "Short description of the mistake",
                    },
                    "what_happened": {
                        "type": "string",
                        "description": "What actually happened",
                    },
                    "why_wrong": {
                        "type": "string",
                        "description": "Why it was wrong",
                    },
                    "lesson": {
                        "type": "string",
                        "description": "What to do instead",
                    },
                    "corrected_by": {
                        "type": "string",
                        "description": "Reference to the principle this violates (e.g. 'conventions.md#Single source of truth')",
                    },
                },
                "required": ["heading", "what_happened", "why_wrong", "lesson"],
            },
        ),
        types.Tool(
            name="consolidate",
            description="Analyze memories for overlaps, contradictions, and staleness. Returns suggestions.",
            inputSchema={"type": "object", "properties": {}},
        ),
        types.Tool(
            name="list_topics",
            description="List all memory files and their section headings.",
            inputSchema={"type": "object", "properties": {}},
        ),
        types.Tool(
            name="get_memory",
            description="Get the full content of a specific memory file.",
            inputSchema={
                "type": "object",
                "properties": {
                    "file": {
                        "type": "string",
                        "description": "Memory file name (without .md)",
                    },
                },
                "required": ["file"],
            },
        ),
        types.Tool(
            name="health_report",
            description="Compute memory health metrics: orphan entries, staleness, confidence distribution, topic balance.",
            inputSchema={"type": "object", "properties": {}},
        ),
        types.Tool(
            name="briefing",
            description="Session-start memory briefing. Returns top conventions, recent anti-patterns, health warnings, and quick stats. Call at the start of every conversation.",
            inputSchema={
                "type": "object",
                "properties": {
                    "context": {
                        "type": "string",
                        "description": "Optional topic to focus the briefing on (e.g., 'dependency management')",
                    },
                },
            },
        ),
        types.Tool(
            name="dashboard",
            description="Generate a memory health dashboard as a self-contained HTML file. Returns the file path.",
            inputSchema={"type": "object", "properties": {}},
        ),
        types.Tool(
            name="update",
            description="Update an existing memory entry's body in-place. Bumps verified_count and last_verified.",
            inputSchema={
                "type": "object",
                "properties": {
                    "file": {
                        "type": "string",
                        "description": "Memory file name (without .md)",
                    },
                    "heading": {
                        "type": "string",
                        "description": "Exact heading of the entry to update (case-insensitive match)",
                    },
                    "body": {
                        "type": "string",
                        "description": "New content for the entry",
                    },
                    "confidence": {
                        "type": "string",
                        "enum": ["high", "medium", "low"],
                        "description": "Updated confidence level (optional, keeps existing if omitted)",
                    },
                },
                "required": ["file", "heading", "body"],
            },
        ),
        types.Tool(
            name="archive",
            description="Archive a stale or deprecated memory entry. Moves it from its current file to archive.md.",
            inputSchema={
                "type": "object",
                "properties": {
                    "file": {
                        "type": "string",
                        "description": "Source memory file name (without .md)",
                    },
                    "heading": {
                        "type": "string",
                        "description": "Exact heading of the entry to archive (case-insensitive match)",
                    },
                },
                "required": ["file", "heading"],
            },
        ),
        types.Tool(
            name="restore",
            description="Restore an archived memory entry back to its original file.",
            inputSchema={
                "type": "object",
                "properties": {
                    "heading": {
                        "type": "string",
                        "description": "Exact heading of the archived entry to restore (case-insensitive match)",
                    },
                },
                "required": ["heading"],
            },
        ),
        types.Tool(
            name="reflect",
            description=(
                "Session-end reflection — summarize what was recorded, verified, "
                "and corrected during this session. Call before ending a conversation."
            ),
            inputSchema={
                "type": "object",
                "properties": {},
            },
        ),
        types.Tool(
            name="transfer_report",
            description=(
                "Show which memories would transfer to a new project. "
                "Breaks down entries by scope (universal vs project-specific). "
                "Anti-patterns always transfer."
            ),
            inputSchema={
                "type": "object",
                "properties": {},
            },
        ),
        types.Tool(
            name="export_universal",
            description=(
                "Export all transferable memories as a JSON manifest. "
                "Includes scope=universal entries and all anti-patterns. "
                "Use this to carry memories to a new workspace."
            ),
            inputSchema={
                "type": "object",
                "properties": {},
            },
        ),
        types.Tool(
            name="stage",
            description=(
                "Stage a proposed memory entry for human review. "
                "Runs quality checks (constitution, overlap, contradiction) "
                "and writes to staging.md. Use this after corrections or discoveries "
                "instead of remember. Human reviews via review_staged."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "heading": {"type": "string", "description": "Entry heading"},
                    "body": {"type": "string", "description": "Entry content"},
                    "proposed_file": {"type": "string", "description": "Target memory file (without .md)"},
                    "confidence": {"type": "string", "enum": ["high", "medium", "low"]},
                    "source": {"type": "string", "enum": ["correction", "observation", "conversation", "research"]},
                    "scope": {"type": "string", "enum": ["universal", "project"], "description": "Transfer scope"},
                },
                "required": ["heading", "body", "proposed_file", "confidence", "source"],
            },
        ),
        types.Tool(
            name="review_staged",
            description=(
                "Review staged memory entries. Actions: "
                "'list' shows all staged entries with recommendations, "
                "'promote' moves an entry to its target file, "
                "'reject' removes an entry from staging."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "action": {"type": "string", "enum": ["list", "promote", "reject"]},
                    "heading": {"type": "string", "description": "Entry heading (required for promote/reject)"},
                },
                "required": ["action"],
            },
        ),
    ]

    # ── Handlers ─────────────────────────────────────────────────────

    def _handle_recall(arguments: dict) -> str:
        query = arguments["query"]
        memories = store.load_all()
        results = search_memories(query, memories)
        if not results:
            return f"No memories matching '{query}'."
        lines = [f"Found {len(results)} matching entries:\n"]
        for r in results[:10]:
            lines.append(
                f"**{r['heading']}** ({r['file']}.md) "
                f"[confidence={r['confidence']}, score={r['score']}]\n"
                f"{r['body']}\n"
            )
        return "\n".join(lines)

    def _handle_remember(arguments: dict) -> str:
        filename = arguments["file"]
        # Block protected files
        if filename in PROTECTED_FILENAMES:
            return f"Cannot write to '{filename}.md' — use the archive/restore tools instead."
        # Validate filename
        fname_errors = validate_filename(filename)
        if fname_errors:
            return "Validation failed:\n" + "\n".join(f"- {e}" for e in fname_errors)
        # Validate entry content
        metadata = {
            "confidence": arguments["confidence"],
            "source": arguments["source"],
            "verified_count": "1",
            "last_verified": str(date.today()),
        }
        if arguments.get("scope"):
            metadata["scope"] = arguments["scope"]
        if arguments.get("derived_from"):
            metadata["derived_from"] = arguments["derived_from"]
        entry_errors = validate_entry(arguments["heading"], arguments["body"], metadata)
        entry_errors.extend(validate_reflection(metadata, filename))
        if entry_errors:
            return "Validation failed:\n" + "\n".join(f"- {e}" for e in entry_errors)
        try:
            action = store.append(
                filename, arguments["heading"], arguments["body"], metadata,
                upsert=True,
            )
        except DuplicateHeadingError as e:
            return f"Duplicate rejected: {e}"
        verb = "Updated" if action == "updated" else "Remembered"
        return f"{verb} '{arguments['heading']}' in {filename}.md"

    def _handle_record_mistake(arguments: dict) -> str:
        body = (
            f"What happened: {arguments['what_happened']}\n\n"
            f"Why it was wrong: {arguments['why_wrong']}\n\n"
            f"Lesson: {arguments['lesson']}"
        )
        metadata: dict[str, str] = {
            "date": str(date.today()),
            "confidence": "high",
            "source": "correction",
            "supersedes": "null",
        }
        if arguments.get("corrected_by"):
            metadata["corrected_by"] = f'"{arguments["corrected_by"]}"'
        # Validate entry content
        entry_errors = validate_entry(arguments["heading"], body, metadata)
        if entry_errors:
            return "Validation failed:\n" + "\n".join(f"- {e}" for e in entry_errors)
        try:
            store.append("anti-patterns", arguments["heading"], body, metadata)
        except DuplicateHeadingError as e:
            return f"Duplicate rejected: {e}"
        return f"Recorded anti-pattern: '{arguments['heading']}'"

    def _handle_consolidate(arguments: dict) -> str:
        memories = store.load_all()
        return consolidate(memories)

    def _handle_list_topics(arguments: dict) -> str:
        memories = store.load_all()
        if not memories:
            return "No memory files found."
        lines: list[str] = []
        for filename, sections in memories.items():
            lines.append(f"**{filename}.md** ({len(sections)} entries)")
            for s in sections:
                conf = s["metadata"].get("confidence", "?")
                lines.append(f"  - {s['heading']} [{conf}]")
        return "\n".join(lines)

    def _handle_get_memory(arguments: dict) -> str:
        filename = arguments["file"]
        fname_errors = validate_filename(filename)
        if fname_errors:
            return fname_errors[0]
        content = store.load_file(filename)
        if content is None:
            return f"Memory file not found: {filename}.md"
        return content

    def _handle_health_report(arguments: dict) -> str:
        memories = store.load_all()
        return health_report(memories)

    def _handle_briefing(arguments: dict) -> str:
        memories = store.load_all()
        fm = store.load_frontmatter_only()
        context = arguments.get("context")
        result = briefing(memories, fm, context)
        # Auto-regenerate dashboard at session start
        html = generate_dashboard(memories, fm)
        (output_dir / "memory-health.html").write_text(html, encoding="utf-8")
        return result

    def _handle_dashboard(arguments: dict) -> str:
        memories = store.load_all()
        fm = store.load_frontmatter_only()
        html_content = generate_dashboard(memories, fm)
        out = output_dir / "memory-health.html"
        out.write_text(html_content, encoding="utf-8")
        return f"Dashboard written to {out}"

    def _handle_update(arguments: dict) -> str:
        filename = arguments["file"]
        # Block protected files
        if filename in PROTECTED_FILENAMES:
            return f"Cannot write to '{filename}.md' — use the archive/restore tools instead."
        fname_errors = validate_filename(filename)
        if fname_errors:
            return "Validation failed:\n" + "\n".join(f"- {e}" for e in fname_errors)
        heading = arguments["heading"]
        body = arguments["body"]
        # Build metadata — read existing section to carry over fields
        sections = store.load_all().get(filename, [])
        needle = heading.strip().lower()
        existing_meta: dict[str, str] = {}
        for sec in sections:
            if sec["heading"].strip().lower() == needle:
                existing_meta = dict(sec["metadata"])
                break
        # Override confidence if provided, otherwise keep existing
        if arguments.get("confidence"):
            existing_meta["confidence"] = arguments["confidence"]
        # Validate entry content
        entry_errors = validate_entry(heading, body, existing_meta)
        if entry_errors:
            return "Validation failed:\n" + "\n".join(f"- {e}" for e in entry_errors)
        try:
            store.replace_section(filename, heading, body, existing_meta)
        except KeyError as e:
            return str(e)
        return f"Updated '{heading}' in {filename}.md"

    def _handle_archive(arguments: dict) -> str:
        filename = arguments["file"]
        fname_errors = validate_filename(filename)
        if fname_errors:
            return "Validation failed:\n" + "\n".join(f"- {e}" for e in fname_errors)
        if filename in PROTECTED_FILENAMES:
            return f"Cannot archive from '{filename}.md'."
        heading = arguments["heading"]
        try:
            return store.archive_section(filename, heading)
        except KeyError as e:
            return str(e)

    def _handle_restore(arguments: dict) -> str:
        heading = arguments["heading"]
        try:
            return store.restore_section(heading)
        except KeyError as e:
            return str(e)

    def _handle_reflect(arguments: dict) -> str:
        memories = store.load_all()
        frontmatter = store.load_frontmatter_only()
        result = session_reflect(memories, frontmatter, store=store)
        # Auto-regenerate dashboard at session end
        html = generate_dashboard(memories, frontmatter)
        (output_dir / "memory-health.html").write_text(html, encoding="utf-8")
        return result

    def _handle_transfer_report(arguments: dict) -> str:
        memories = store.load_all()
        return _transfer_report(memories)

    def _handle_export_universal(arguments: dict) -> str:
        memories = store.load_all()
        return _export_universal(memories)

    def _handle_stage(arguments: dict) -> str:
        memories = store.load_all()
        heading = arguments["heading"]
        body = arguments["body"]
        proposed_file = arguments["proposed_file"]
        metadata = {
            "confidence": arguments.get("confidence", "medium"),
            "source": arguments.get("source", "observation"),
            "scope": arguments.get("scope", "project"),
        }
        result = _stage(
            heading, body, proposed_file, metadata,
            store=store, memories=memories,
        )
        if result["status"] == "rejected":
            reasons = result.get("reason", [])
            return "Staging rejected:\n" + "\n".join(f"- {r}" for r in reasons)
        ann = "; ".join(result["annotations"])
        return (
            f"Staged '{heading}' for review → {proposed_file}.md\n"
            f"Annotations: {ann}"
        )

    def _handle_review_staged(arguments: dict) -> str:
        action = arguments["action"]
        heading = arguments.get("heading")
        result = _review_staged(heading, action, store=store)

        if "error" in result:
            return f"Error: {result['error']}"

        if result["action"] == "list":
            entries = result["entries"]
            if not entries:
                return "No staged entries."
            lines = [f"## Staged Entries ({len(entries)})", ""]
            for e in entries:
                lines.append(f"### {e['heading']} → {e['proposed_file']}.md")
                lines.append(f"> {e['body']}")
                lines.append(f"- Annotations: {e['annotations']}")
                lines.append(f"- Recommendation: **{e['recommendation']}**")
                lines.append("")
            return "\n".join(lines)

        if result["action"] == "promote":
            return f"Promoted '{result['heading']}' to {result['target']}.md"

        if result["action"] == "reject":
            return f"Rejected '{result['heading']}' — removed from staging."

        return f"Unknown action result: {result}"

    # ── Handler dispatch dict ────────────────────────────────────────

    _HANDLERS: dict[str, Callable[[dict], str]] = {
        "recall": _handle_recall,
        "remember": _handle_remember,
        "record_mistake": _handle_record_mistake,
        "consolidate": _handle_consolidate,
        "list_topics": _handle_list_topics,
        "get_memory": _handle_get_memory,
        "health_report": _handle_health_report,
        "briefing": _handle_briefing,
        "dashboard": _handle_dashboard,
        "update": _handle_update,
        "archive": _handle_archive,
        "restore": _handle_restore,
        "reflect": _handle_reflect,
        "transfer_report": _handle_transfer_report,
        "export_universal": _handle_export_universal,
        "stage": _handle_stage,
        "review_staged": _handle_review_staged,
    }

    # ── MCP protocol ─────────────────────────────────────────────────

    @server.list_tools()
    async def list_tools() -> list[types.Tool]:
        return TOOLS

    @server.call_tool()
    async def call_tool(name: str, arguments: dict) -> list[types.TextContent]:
        handler = _HANDLERS.get(name)
        if handler is None:
            result = f"Unknown tool: {name}"
        else:
            try:
                result = handler(arguments)
            except Exception as exc:
                result = f"Error: {exc}"
        return [types.TextContent(type="text", text=result)]

    import asyncio

    async def _run() -> None:
        async with stdio_server() as (read, write):
            await server.run(read, write, server.create_initialization_options())

    asyncio.run(_run())


def main() -> None:
    """Entry point for the memory-server console script."""
    parser = argparse.ArgumentParser(
        prog="memory-server",
        description="Start the aidiary MCP memory server.",
    )
    parser.add_argument(
        "--memories", "-m",
        help="Path to the memories directory (default: ./memories or $COPILOT_MEMORY_DIR)",
    )
    parser.add_argument(
        "--output", "-o",
        help="Path to the output directory for dashboard HTML (default: ./output or $COPILOT_MEMORY_OUTPUT_DIR)",
    )
    args = parser.parse_args()
    serve(memories_path=args.memories, output_path=args.output)


if __name__ == "__main__":
    main()
