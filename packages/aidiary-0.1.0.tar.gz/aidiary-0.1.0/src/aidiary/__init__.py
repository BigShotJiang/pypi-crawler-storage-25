"""aidiary — portable memory system for AI coding assistants."""

from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("aidiary")
except PackageNotFoundError:
    __version__ = "0.1.0"  # fallback for editable installs
