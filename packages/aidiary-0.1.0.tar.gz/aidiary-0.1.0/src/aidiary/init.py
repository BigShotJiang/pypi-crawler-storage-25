"""Scaffold a new aidiary project with starter memory files and output directory.

Usage:
    aidiary-init [TARGET_DIR]

    TARGET_DIR defaults to the current working directory.

Creates:
    TARGET_DIR/memories/   — starter memory files with frontmatter
    TARGET_DIR/output/     — empty output directory for dashboard HTML
"""
from __future__ import annotations

import argparse
import sys
from datetime import date
from pathlib import Path

# Starter files: (filename, description, tags)
_STARTER_FILES: list[tuple[str, str, list[str]]] = [
    ("conventions", "Coding standards, patterns, and project conventions", ["standards", "patterns"]),
    ("workflow", "Development process rules and decision-making", ["process", "decisions"]),
    ("anti-patterns", "Episodic mistake buffer — specific incidents with correction links", ["mistakes", "corrections"]),
    ("tools", "Tool usage notes, CLI commands, and environment setup", ["tools", "cli", "setup"]),
    ("project-setup", "Project-specific configuration and structure notes", ["config", "structure"]),
]


def _make_starter(filename: str, description: str, tags: list[str]) -> str:
    """Generate a starter memory file with frontmatter."""
    today = str(date.today())
    tag_str = ", ".join(tags)
    title = filename.replace("-", " ").title()
    return (
        f"---\n"
        f"description: {description}\n"
        f"priority: high\n"
        f"tags: [{tag_str}]\n"
        f"entry_count: 0\n"
        f"last_updated: {today}\n"
        f"---\n"
        f"# {title}\n"
    )


def init_project(target: Path) -> list[str]:
    """Create memories/ and output/ directories with starter files.

    Returns a list of created paths (relative to target) for reporting.
    """
    created: list[str] = []

    memories_dir = target / "memories"
    output_dir = target / "output"

    memories_dir.mkdir(parents=True, exist_ok=True)
    output_dir.mkdir(parents=True, exist_ok=True)
    created.append("memories/")
    created.append("output/")

    for filename, description, tags in _STARTER_FILES:
        filepath = memories_dir / f"{filename}.md"
        if filepath.exists():
            continue  # never overwrite existing files
        filepath.write_text(_make_starter(filename, description, tags), encoding="utf-8")
        created.append(f"memories/{filename}.md")

    return created


def main() -> None:
    """Entry point for the aidiary-init console script."""
    parser = argparse.ArgumentParser(
        prog="aidiary-init",
        description="Scaffold a new aidiary project with starter memory files.",
    )
    parser.add_argument(
        "target",
        nargs="?",
        default=".",
        help="Target directory (default: current directory)",
    )
    args = parser.parse_args()
    target = Path(args.target).resolve()

    created = init_project(target)

    if not created:
        print(f"Nothing to create — {target} already set up.")
        sys.exit(0)

    print(f"Initialized aidiary project in {target}/")
    for path in created:
        print(f"  + {path}")
    print()
    print("Next steps:")
    print(f"  memory-server --memories {target / 'memories'} --output {target / 'output'}")


if __name__ == "__main__":
    main()
