"""Cross-project transfer — export universal memories for use in other workspaces.

Exports:
    transfer_report    — summary of what would transfer (counts, file breakdown)
    export_universal   — JSON manifest of all transferable entries

Consumers:
    server.py (transfer_report and export_universal MCP tools)
"""
from __future__ import annotations

import json
from datetime import date


def transfer_report(memories: dict[str, list[dict]]) -> str:
    """Generate a markdown summary of transferable vs project-specific entries."""
    universal: list[dict] = []
    project: list[dict] = []
    anti_patterns: list[dict] = []

    for filename, sections in memories.items():
        for sec in sections:
            meta = sec["metadata"]
            is_ap = meta.get("source") == "correction" and filename == "anti-patterns"
            scope = meta.get("scope", "project")

            if is_ap:
                anti_patterns.append({"file": filename, **sec})
            elif scope == "universal":
                universal.append({"file": filename, **sec})
            else:
                project.append({"file": filename, **sec})

    # Per-file breakdown
    file_counts: dict[str, dict[str, int]] = {}
    for filename, sections in memories.items():
        u = p = 0
        for sec in sections:
            is_ap = sec["metadata"].get("source") == "correction" and filename == "anti-patterns"
            scope = sec["metadata"].get("scope", "project")
            if is_ap or scope == "universal":
                u += 1
            else:
                p += 1
        file_counts[filename] = {"universal": u, "project": p}

    total_transfer = len(universal) + len(anti_patterns)
    total_all = total_transfer + len(project)

    lines = [
        "# Transfer Report",
        "",
        f"**Total entries:** {total_all}",
        f"**Would transfer:** {total_transfer} "
        f"({len(universal)} universal + {len(anti_patterns)} anti-patterns)",
        f"**Would skip:** {len(project)} project-specific",
        "",
        "## Per-File Breakdown",
        "",
        "| File | Universal | Project | Transfer % |",
        "|------|-----------|---------|------------|",
    ]
    for fname, counts in sorted(file_counts.items()):
        total = counts["universal"] + counts["project"]
        pct = round(100 * counts["universal"] / total) if total else 0
        lines.append(
            f"| {fname}.md | {counts['universal']} | {counts['project']} | {pct}% |"
        )

    lines.extend([
        "",
        "## Universal Entries",
        "",
    ])
    for entry in universal:
        lines.append(f"- **{entry['heading']}** ({entry['file']}.md)")
    for entry in anti_patterns:
        lines.append(f"- **{entry['heading']}** ({entry['file']}.md) [anti-pattern]")

    if project:
        lines.extend([
            "",
            "## Project-Specific (would skip)",
            "",
        ])
        for entry in project:
            lines.append(f"- {entry['heading']} ({entry['file']}.md)")

    return "\n".join(lines)


def export_universal(memories: dict[str, list[dict]]) -> str:
    """Return a JSON manifest of all entries that should transfer to a new project.

    Includes all ``scope: universal`` entries plus all anti-pattern entries
    (regardless of scope).  The manifest is a JSON array of objects with
    keys: ``file``, ``heading``, ``body``, ``metadata``.
    """
    entries: list[dict] = []

    for filename, sections in memories.items():
        for sec in sections:
            meta = sec["metadata"]
            is_ap = meta.get("source") == "correction" and filename == "anti-patterns"
            scope = meta.get("scope", "project")

            if scope == "universal" or is_ap:
                entries.append({
                    "file": filename,
                    "heading": sec["heading"],
                    "body": sec["body"],
                    "metadata": meta,
                })

    manifest = {
        "exported": str(date.today()),
        "entry_count": len(entries),
        "entries": entries,
    }
    return json.dumps(manifest, indent=2, ensure_ascii=False)
