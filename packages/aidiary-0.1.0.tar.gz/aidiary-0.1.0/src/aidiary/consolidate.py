"""Consolidation engine — overlap detection, contradiction detection, self-critique,
merge suggestions.

Exports:
    consolidate            — analyze memories and return actionable suggestions
    find_contradictions    — detect entries with opposing directives on shared concepts

Consumers:
    server.py (consolidate tool), briefing.py (health warnings), dashboard.py (summary cards)
"""
from __future__ import annotations

from .scoring import confidence_mismatch, find_stale, find_promotable

# Stop words excluded from heading overlap detection
_STOP_WORDS = frozenset({
    "the", "a", "an", "in", "to", "for", "and", "or", "of",
    "is", "it", "on", "at", "by", "with", "from", "as", "not",
    "that", "this", "be", "are", "was", "were", "been", "has",
    "have", "had", "do", "does", "did", "will", "can", "could",
    "should", "would", "may", "might", "use", "using", "used",
    # Common structural/functional words that aren't concept-bearing
    "after", "before", "into", "every", "each", "all", "any",
    "also", "just", "only", "when", "where", "how", "what",
    "which", "who", "but", "then", "than", "both", "either",
    "neither", "yet", "still", "about", "over", "under",
    "between", "through", "during", "while", "since",
    "add", "adding", "added", "run", "running", "test",
    "make", "get", "set", "put", "see", "new", "old",
    "first", "last", "next", "like", "its", "your", "our",
})

MAX_ENTRY_WORDS = 200  # entries longer than this are flagged
MERGE_THRESHOLD = 4    # minimum shared body keywords to suggest merge
CONTRADICTION_OVERLAP = 4  # minimum shared keywords to check for contradictions
CONTRADICTION_MIN_CONFLICTS = 2  # minimum conflicting keywords to flag a pair

# Negation markers that flip the meaning of nearby concept words
_NEGATION_MARKERS = frozenset({
    "never", "not", "no", "don't", "avoid", "forbidden",
    "stop", "cannot", "shouldn't", "mustn't", "won't",
    "doesn't", "didn't", "prohibit", "prevent", "ban",
})

_NEGATION_WINDOW = 5  # words before a keyword to scan for negation


def consolidate(memories: dict[str, list[dict]]) -> str:
    """Analyze memories for overlaps, contradictions, and quality issues."""
    suggestions: list[str] = []

    suggestions.extend(_find_overlaps(memories))
    suggestions.extend(_format_contradictions(memories))
    suggestions.extend(_find_unverified(memories))
    suggestions.extend(_self_critique(memories))
    suggestions.extend(_find_stale(memories))
    suggestions.extend(_find_promotable(memories))
    suggestions.extend(_suggest_merges(memories))
    suggestions.extend(_find_oversized(memories))
    suggestions.extend(_suggest_reflections(memories))

    if not suggestions:
        return "Memory looks healthy — no overlaps, quality issues, or stale entries detected."
    return "Consolidation suggestions:\n\n" + "\n".join(f"- {s}" for s in suggestions)


def _find_overlaps(memories: dict[str, list[dict]]) -> list[str]:
    """Find entries with similar headings (≥2 shared non-stop words)."""
    results: list[str] = []
    all_entries: list[tuple[str, str]] = []
    for filename, sections in memories.items():
        for s in sections:
            all_entries.append((filename, s["heading"]))

    for i, (f1, h1) in enumerate(all_entries):
        for f2, h2 in all_entries[i + 1:]:
            words1 = set(h1.lower().split()) - _STOP_WORDS
            words2 = set(h2.lower().split()) - _STOP_WORDS
            overlap = words1 & words2
            if len(overlap) >= 2:
                results.append(
                    f"Potential overlap: '{h1}' ({f1}.md) ↔ '{h2}' ({f2}.md) "
                    f"[shared: {', '.join(sorted(overlap))}]"
                )
    return results


def _find_unverified(memories: dict[str, list[dict]]) -> list[str]:
    """Find entries with low confidence and zero verification."""
    results: list[str] = []
    for filename, sections in memories.items():
        for s in sections:
            vc = int(s["metadata"].get("verified_count", "0"))
            conf = s["metadata"].get("confidence", "low")
            if vc == 0 and conf == "low":
                results.append(
                    f"Unverified: '{s['heading']}' ({filename}.md) "
                    f"— low confidence, never verified"
                )
    return results


def _self_critique(memories: dict[str, list[dict]]) -> list[str]:
    """Flag confidence/evidence mismatches (Self-Refine pattern)."""
    results: list[str] = []
    for sections in memories.values():
        for s in sections:
            warning = confidence_mismatch(s)
            if warning:
                results.append(f"Confidence mismatch: {warning}")
    return results


def _find_stale(memories: dict[str, list[dict]]) -> list[str]:
    """Flag entries with last_verified older than 30 days or never verified."""
    stale = find_stale(memories)
    return [
        f"Stale: '{heading}' ({filename}.md) — not verified in 30+ days"
        for filename, heading in stale
    ]


def _find_promotable(memories: dict[str, list[dict]]) -> list[str]:
    """Suggest entries eligible for confidence promotion."""
    promotable = find_promotable(memories)
    return [
        f"Promote: '{heading}' ({filename}.md) — verified ≥3 times but not high confidence"
        for filename, heading in promotable
    ]


import re

_PUNCT_RE = re.compile(r'[^\w\-]')  # strip everything except word chars and hyphens


def _body_keywords(body: str) -> set[str]:
    """Extract meaningful keywords from an entry body."""
    words = set(_PUNCT_RE.sub(' ', body.lower()).split()) - _STOP_WORDS
    return {w for w in words if len(w) > 3}


def _suggest_merges(memories: dict[str, list[dict]]) -> list[str]:
    """Suggest merges for entries in the same file with high body similarity."""
    results: list[str] = []
    for filename, sections in memories.items():
        if len(sections) < 2:
            continue
        kw_cache = [(s, _body_keywords(s["body"])) for s in sections]
        for i, (s1, kw1) in enumerate(kw_cache):
            for s2, kw2 in kw_cache[i + 1:]:
                if not kw1 or not kw2:
                    continue
                shared = kw1 & kw2
                # Use Jaccard similarity: shared / union
                union = kw1 | kw2
                similarity = len(shared) / len(union) if union else 0
                if len(shared) >= MERGE_THRESHOLD and similarity >= 0.3:
                    top = sorted(shared)[:5]
                    results.append(
                        f"Merge candidate: '{s1['heading']}' ↔ '{s2['heading']}' "
                        f"({filename}.md) — {len(shared)} shared keywords "
                        f"[{', '.join(top)}]"
                    )
    return results


def _find_oversized(memories: dict[str, list[dict]]) -> list[str]:
    """Flag entries exceeding the recommended word limit."""
    results: list[str] = []
    for filename, sections in memories.items():
        for s in sections:
            word_count = len(s["body"].split())
            if word_count > MAX_ENTRY_WORDS:
                results.append(
                    f"Oversized: '{s['heading']}' ({filename}.md) "
                    f"— {word_count} words (max {MAX_ENTRY_WORDS})"
                )
    return results


# ── Reflection suggestions ───────────────────────────────────────────

MIN_CROSS_FILE_MERGES = 3  # minimum cross-file merge candidates to suggest a reflection


def _suggest_reflections(memories: dict[str, list[dict]]) -> list[str]:
    """Suggest creating a reflection when ≥3 merge candidates span multiple files."""
    # Build cross-file merge clusters
    all_entries: list[tuple[str, dict, set[str]]] = []
    for filename, sections in memories.items():
        if filename == "reflections":
            continue  # don't suggest reflections from reflections
        for s in sections:
            kw = _body_keywords(s["body"])
            if kw:
                all_entries.append((filename, s, kw))

    # Find groups of entries sharing significant keywords across files
    clusters: dict[str, list[tuple[str, str]]] = {}  # concept_key → [(file, heading)]
    for i, (f1, s1, kw1) in enumerate(all_entries):
        for f2, s2, kw2 in all_entries[i + 1:]:
            if f1 == f2:
                continue  # only cross-file pairs
            shared = kw1 & kw2
            if len(shared) < MERGE_THRESHOLD:
                continue
            concept = ", ".join(sorted(shared)[:3])
            if concept not in clusters:
                clusters[concept] = []
            for pair in [(f1, s1["heading"]), (f2, s2["heading"])]:
                if pair not in clusters[concept]:
                    clusters[concept].append(pair)

    results: list[str] = []
    for concept, entries in clusters.items():
        if len(entries) >= MIN_CROSS_FILE_MERGES:
            entry_refs = ", ".join(
                f"'{h}' ({f}.md)" for f, h in entries[:5]
            )
            results.append(
                f"🔮 Reflection candidate: {len(entries)} entries across files "
                f"share concept [{concept}] — consider synthesizing into "
                f"reflections.md. Entries: {entry_refs}"
            )
    return results


# ── Contradiction detection ──────────────────────────────────────────


def _is_negated(keyword: str, body_words: list[str]) -> bool:
    """Check if *keyword* appears near a negation marker in *body_words*."""
    kw_lower = keyword.lower()
    for idx, w in enumerate(body_words):
        if w == kw_lower:
            window_start = max(0, idx - _NEGATION_WINDOW)
            window = body_words[window_start:idx]
            if any(m in window for m in _NEGATION_MARKERS):
                return True
    return False


def _corrected_by_heading(section: dict) -> str | None:
    """Extract the heading from a corrected_by metadata value.

    Format: '"Heading text" (file.md)' or just '"Heading text"'.
    Returns the heading text (without quotes) or None.
    """
    raw = section["metadata"].get("corrected_by", "")
    if not raw or raw == "null":
        return None
    raw = raw.strip()
    if raw.startswith('"') and '"' in raw[1:]:
        return raw[1:raw.index('"', 1)]
    return None


def _is_corrected_by_pair(s1: dict, s2: dict) -> bool:
    """Return True if one entry's corrected_by references the other's heading."""
    cb1 = _corrected_by_heading(s1)
    cb2 = _corrected_by_heading(s2)
    h1_lower = s1["heading"].lower()
    h2_lower = s2["heading"].lower()
    if cb1 and cb1.lower() == h2_lower:
        return True
    if cb2 and cb2.lower() == h1_lower:
        return True
    return False


def find_contradictions(
    memories: dict[str, list[dict]],
) -> list[tuple[str, str, str, str, list[str]]]:
    """Detect entries with opposing polarity on shared concepts.

    Returns list of (file1, heading1, file2, heading2, conflicting_keywords).
    """
    results: list[tuple[str, str, str, str, list[str]]] = []
    all_entries: list[tuple[str, dict, set[str], list[str]]] = []

    for filename, sections in memories.items():
        for s in sections:
            # Skip anti-pattern entries — they inherently use negation language
            if s["metadata"].get("source") == "correction":
                continue
            kw = _body_keywords(s["body"])
            words = _PUNCT_RE.sub(' ', s["body"].lower()).split()
            all_entries.append((filename, s, kw, words))

    for i, (f1, s1, kw1, words1) in enumerate(all_entries):
        for f2, s2, kw2, words2 in all_entries[i + 1:]:
            shared = kw1 & kw2
            if len(shared) < CONTRADICTION_OVERLAP:
                continue
            if _is_corrected_by_pair(s1, s2):
                continue
            conflicting: list[str] = []
            for kw in sorted(shared):
                neg1 = _is_negated(kw, words1)
                neg2 = _is_negated(kw, words2)
                if neg1 != neg2:
                    conflicting.append(kw)
            if len(conflicting) >= CONTRADICTION_MIN_CONFLICTS:
                results.append((f1, s1["heading"], f2, s2["heading"], conflicting))

    return results


def _format_contradictions(memories: dict[str, list[dict]]) -> list[str]:
    """Format contradiction findings for consolidate() output."""
    pairs = find_contradictions(memories)
    return [
        f"⚠️ Potential contradiction: '{h1}' ({f1}.md) ↔ '{h2}' ({f2}.md) "
        f"— conflicting polarity on: {', '.join(kws)}"
        for f1, h1, f2, h2, kws in pairs
    ]
