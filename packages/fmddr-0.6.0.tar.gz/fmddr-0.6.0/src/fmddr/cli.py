"""Typer entry point. Thin shell — every command delegates to query/* modules."""
from __future__ import annotations

import pathlib
import sys
from typing import Optional

import typer

from . import db as dbmod
from .format.output import envelope, pick_default_format, render
from .query import cf as q_cf
from .query import fields as q_fields
from .query import graph as q_graph
from .query import impact as q_impact
from .query import layouts as q_layouts
from .query import resolvers
from .query import scripts as q_scripts
from .query import search as q_search
from .query import tables as q_tables

from . import __version__

app = typer.Typer(no_args_is_help=True, add_completion=False, help="Query a FileMaker DDR.")


def _version_callback(value: bool) -> None:
    if value:
        typer.echo(f"fmddr {__version__}")
        raise typer.Exit()


@app.callback()
def _root(
    version: Optional[bool] = typer.Option(
        None, "--version", callback=_version_callback, is_eager=True,
        help="Show version and exit.",
    ),
) -> None:
    """fmddr — query a FileMaker DDR."""
file_app = typer.Typer(help="Source files (multi-file DDRs).")
table_app = typer.Typer(help="Tables and fields.")
field_app = typer.Typer(help="Field-level queries.")
script_app = typer.Typer(help="Scripts and steps.")
step_app = typer.Typer(help="Per-step queries.")
layout_app = typer.Typer(help="Layouts.")
cf_app = typer.Typer(help="Custom functions.")
graph_app = typer.Typer(help="Relationship graph and TO paths.")

app.add_typer(file_app, name="file")
app.add_typer(table_app, name="table")
app.add_typer(field_app, name="field")
app.add_typer(script_app, name="script")
app.add_typer(step_app, name="step")
app.add_typer(layout_app, name="layout")
app.add_typer(cf_app, name="cf")
app.add_typer(graph_app, name="graph")


# ----------------------------------------------------------------------
# Shared options
# ----------------------------------------------------------------------

OUTPUT_CHOICES = ("json", "jsonl", "table", "markdown", "csv", "tsv")


def _pretty_xml(xml: str) -> str:
    import xml.etree.ElementTree as ET

    trimmed = xml.lstrip()
    decl = ""
    if trimmed.startswith("<?xml"):
        end = trimmed.find("?>")
        if end != -1:
            decl = trimmed[: end + 2] + "\n"
            trimmed = trimmed[end + 2 :].lstrip()
    try:
        root = ET.fromstring(trimmed)
    except ET.ParseError:
        return xml
    ET.indent(root, space="  ")
    body = ET.tostring(root, encoding="unicode")
    return decl + body + ("\n" if not body.endswith("\n") else "")


def _format_opt(value: str | None) -> str:
    if value is None:
        return pick_default_format()
    if value not in OUTPUT_CHOICES:
        raise typer.BadParameter(f"--output must be one of {OUTPUT_CHOICES}")
    return value


def _meta_source(conn) -> str:
    """Return the source provenance of an index ('ddr' / 'snippets' / 'unknown')."""
    row = conn.execute("SELECT value FROM meta WHERE key = 'source'").fetchone()
    if row and row[0]:
        return row[0]
    return "unknown"


def _meta_partial(conn) -> bool:
    row = conn.execute("SELECT value FROM meta WHERE key = 'partial'").fetchone()
    return bool(row and row[0] == "true")


# ----------------------------------------------------------------------
# Errors → exit codes (per plan: 1 not found, 2 ambiguous, 64 bad usage, 70 internal)
# ----------------------------------------------------------------------

def _handle_resolve(fn, *args, **kwargs):
    try:
        return fn(*args, **kwargs)
    except resolvers.NotFound as e:
        typer.echo(f"error: {e}", err=True)
        raise typer.Exit(code=1)
    except resolvers.Ambiguous as e:
        typer.echo(f"ambiguous: {e}", err=True)
        for c in e.candidates:
            typer.echo(f"  {c}", err=True)
        raise typer.Exit(code=2)


# ----------------------------------------------------------------------
# Top-level: split / index / stats / open
# ----------------------------------------------------------------------

@app.command()
def split(
    ddr: pathlib.Path = typer.Argument(..., exists=True, readable=True, dir_okay=False),
    out: pathlib.Path = typer.Option(pathlib.Path("./xmls-split"), "--out"),
    quiet: bool = typer.Option(False, "--quiet"),
    script_format: str = typer.Option(
        "xml",
        "--script-format",
        help=(
            "Format for scripts in the output tree: 'xml' (default, full DDR fidelity, "
            "round-trippable via `copy`) or 'text' (lossy plain-text view, .txt files, "
            "read-only — useful for debugging script logic)."
        ),
    ),
) -> None:
    """Explode a DDR XML into a per-object file tree (port of pipeline.py)."""
    from .parser.split import split as do_split
    if script_format not in ("xml", "text"):
        typer.echo(f"error: --script-format must be 'xml' or 'text', got {script_format!r}", err=True)
        raise typer.Exit(code=64)
    do_split(ddr, out, quiet=quiet, script_format=script_format)


@app.command(name="split-savexml")
def split_savexml_cmd(
    src: pathlib.Path = typer.Argument(
        ..., exists=True, readable=True, dir_okay=False, resolve_path=True,
    ),
    out: pathlib.Path = typer.Option(pathlib.Path("./xmls-split"), "--out"),
    quiet: bool = typer.Option(False, "--quiet"),
    script_format: str = typer.Option(
        "xml",
        "--script-format",
        help=(
            "Format for scripts in the output tree: 'xml' (default) or "
            "'text' (lossy plain-text view, .txt files, read-only)."
        ),
    ),
    from_ddr: Optional[pathlib.Path] = typer.Option(
        None,
        "--from-ddr",
        exists=True, readable=True, file_okay=False, dir_okay=True,
        help=(
            "Path to a previously-run `fmddr split` output directory. "
            "Restores script and layout folder structure from that tree's "
            "_metrics.json (matched by name) and copies DDR-only catalog "
            "files (accounts, themes, privileges, etc.) into catalogs/."
        ),
    ),
) -> None:
    """Explode an FMSaveAsXML (whole-file clone) export into a per-object file tree.

    Produces the same folder structure as `split` (tables/, layouts/, scripts/,
    catalogs/). Pass --from-ddr to restore script/layout folders from a prior
    DDR split and preserve DDR-only catalog files (accounts, themes, etc.).
    """
    from .parser.split_savexml import split_savexml as do_split_savexml
    if script_format not in ("xml", "text"):
        typer.echo(f"error: --script-format must be 'xml' or 'text', got {script_format!r}", err=True)
        raise typer.Exit(code=64)
    do_split_savexml(src, out, quiet=quiet, script_format=script_format, from_ddr=from_ddr)


@app.command()
def index(
    ddr: pathlib.Path = typer.Argument(..., exists=True, readable=True, dir_okay=False),
    out: Optional[pathlib.Path] = typer.Option(None, "--out"),
    keep_xml: bool = typer.Option(False, "--keep-xml/--no-keep-xml"),
    quiet: bool = typer.Option(False, "--quiet"),
) -> None:
    """Build the SQLite query index from a DDR XML.

    Auto-detects FMPReport type:
    - type="Report" → ingest one file (the common case).
    - type="Summary" → ingest every linked file into a single index.
    """
    from .index.build import build_index, build_index_from_summary
    from .parser.stream import load_utf8
    import xml.etree.ElementTree as ET

    if out is None:
        out = pathlib.Path.cwd() / f"{ddr.stem}.fmddr.db"

    # Cheap type sniff: parse the first ~4KB to find FMPReport's `type` attr.
    head = load_utf8(ddr)[:4096]
    try:
        # Parse just enough to read the root attrs.
        root_attrs: dict[str, str] = {}
        for ev, el in ET.iterparse(__import__("io").BytesIO(head), events=("start",)):
            if el.tag == "FMPReport":
                root_attrs = dict(el.attrib)
                break
    except ET.ParseError:
        root_attrs = {}
    is_summary = (root_attrs.get("type") or "").lower() == "summary"

    if is_summary:
        build_index_from_summary(ddr, out, keep_xml=keep_xml, quiet=quiet)
    else:
        build_index(ddr, out, keep_xml=keep_xml, quiet=quiet)
    if not quiet:
        typer.echo(f"Index written to {out}")


@app.command(name="index-savexml")
def index_savexml_cmd(
    src: pathlib.Path = typer.Argument(
        ..., exists=True, readable=True, dir_okay=False, resolve_path=True,
    ),
    out: Optional[pathlib.Path] = typer.Option(None, "--out"),
    keep_xml: bool = typer.Option(False, "--keep-xml/--no-keep-xml"),
    quiet: bool = typer.Option(False, "--quiet"),
) -> None:
    """Build an index from an FMSaveAsXML (whole-file clone) export.

    FMSaveAsXML is the format produced by FileMaker's "Save a Copy as XML"
    tooling — a single UTF-16 XML document representing one .fmp12 file in
    its entirety. Distinct from a DDR (`<FMPReport>`).

    Output is a regular `.fmddr.db` with `meta.source = "savexml"`.
    Snapshot and diff work identically to DDR-built indexes; cross-source
    diffs emit a brief note about expected per-format edge-count differences.
    """
    from .index.savexml import build_index_from_savexml

    if out is None:
        out = pathlib.Path.cwd() / f"{src.stem}.fmddr.db"
    build_index_from_savexml(src, out, keep_xml=keep_xml, quiet=quiet)
    if not quiet:
        typer.echo(f"Index written to {out}")


@app.command()
def stats(
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    """Show counts and metadata recorded in the index."""
    fmt = _format_opt(output)
    db_path = dbmod.find_db(db)
    conn = dbmod.connect(db_path)
    m = dbmod.meta(conn)
    counts = {k.removeprefix("counts."): int(v) for k, v in m.items() if k.startswith("counts.")}
    result = {
        "db_path": str(db_path),
        "schema_version": m.get("schema_version"),
        "fm_file_name": m.get("fm_file_name"),
        "fm_version": m.get("fm_version"),
        "indexed_at": m.get("indexed_at"),
        "source_utf8_bytes": int(m.get("source_utf8_bytes", "0")),
        "counts": counts,
    }
    render(envelope(kind="stats", ddr=dbmod.ddr_envelope(conn), result=result), fmt)


@file_app.command("list")
def file_list_cmd(
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    """List the FileMaker files ingested into this index, with per-file counts."""
    fmt = _format_opt(output)
    conn = dbmod.connect(dbmod.find_db(db))
    rows = [dict(r) for r in conn.execute(
        "SELECT f.id, f.name, f.path, f.link, f.fm_version, f.bytes, f.indexed_at, "
        "       (SELECT COUNT(*) FROM base_table WHERE file_id = f.id) AS base_tables, "
        "       (SELECT COUNT(*) FROM field WHERE file_id = f.id)      AS fields, "
        "       (SELECT COUNT(*) FROM script WHERE file_id = f.id)     AS scripts, "
        "       (SELECT COUNT(*) FROM layout WHERE file_id = f.id)     AS layouts, "
        "       (SELECT COUNT(*) FROM table_occurrence WHERE file_id = f.id) AS tos, "
        "       (SELECT COUNT(*) FROM relationship WHERE file_id = f.id)     AS relationships, "
        "       (SELECT COUNT(*) FROM custom_function WHERE file_id = f.id)  AS custom_functions, "
        "       (SELECT COUNT(*) FROM value_list WHERE file_id = f.id)       AS value_lists "
        "FROM file f ORDER BY f.id"
    )]
    render(envelope(kind="file.list", ddr=dbmod.ddr_envelope(conn), result=rows), fmt)


@app.command("open")
def open_shell(
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
) -> None:
    """Launch an interactive sqlite3 shell against the index."""
    import os
    db_path = dbmod.find_db(db)
    os.execvp("sqlite3", ["sqlite3", str(db_path)])


# ----------------------------------------------------------------------
# snapshot / diff
# ----------------------------------------------------------------------

@app.command()
def snapshot(
    label: str = typer.Argument(..., help="Snapshot label (used as the file stem)."),
    out: pathlib.Path = typer.Option(
        pathlib.Path("./snapshots"), "--out", help="Output directory."
    ),
    db: Optional[pathlib.Path] = typer.Option(None, "--db", help="Source index DB."),
    force: bool = typer.Option(False, "--force", help="Overwrite an existing snapshot."),
    quiet: bool = typer.Option(False, "--quiet"),
) -> None:
    """Copy the current index DB into a labeled snapshot file.

    The copy gets `snapshot_label` and `snapshot_taken_at` stamped into its
    `meta` table so the label travels with the file.
    """
    from .snapshot import take_snapshot
    db_path = dbmod.find_db(db)
    try:
        dest = take_snapshot(db_path, label, out, force=force)
    except FileExistsError as e:
        typer.echo(f"error: {e}", err=True)
        raise typer.Exit(code=1)
    except (ValueError, FileNotFoundError) as e:
        typer.echo(f"error: {e}", err=True)
        raise typer.Exit(code=64)
    if not quiet:
        typer.echo(f"Snapshot written to {dest}")


def _snapshot_envelope(conn, path: pathlib.Path) -> dict:
    m = dbmod.meta(conn)
    return {
        "path": str(path),
        "ddr_path": m.get("ddr_path"),
        "ddr_sha256": m.get("ddr_sha256"),
        "indexed_at": m.get("indexed_at"),
        "snapshot_label": m.get("snapshot_label"),
        "snapshot_taken_at": m.get("snapshot_taken_at"),
        "fm_file_name": m.get("fm_file_name"),
    }


@app.command(name="diff")
def diff_cmd(
    old: pathlib.Path = typer.Argument(..., exists=True, dir_okay=False, readable=True),
    new: pathlib.Path = typer.Argument(..., exists=True, dir_okay=False, readable=True),
    format_: str = typer.Option(
        "json", "--format", "-f", help="Output format: json | md | text."
    ),
    impact: bool = typer.Option(
        True, "--impact/--no-impact",
        help="Include blast-radius rollup per change (default on).",
    ),
    rename_detect: bool = typer.Option(
        True, "--rename-detect/--no-rename-detect",
        help="Pair removed+added entries with identical content as renames.",
    ),
) -> None:
    """Compare two .fmddr.db snapshots and emit structured changes.

    Exit codes: 0 = no changes, 1 = changes detected, 2 = error, 64 = bad usage.
    """
    from .diff import compute_diff
    from .diff.render import render as render_diff

    if format_ not in ("json", "md", "text"):
        typer.echo(f"error: --format must be json|md|text, got {format_!r}", err=True)
        raise typer.Exit(code=64)
    try:
        old_conn = dbmod.connect(old)
        new_conn = dbmod.connect(new)
        old_source = _meta_source(old_conn)
        new_source = _meta_source(new_conn)
        if old_source != new_source:
            # Both DDR and SaveAsXML indexes populate the same edge tables
            # via the same resolver pipeline (Phase A + B), so cross-source
            # diff is supported. Note the asymmetry up front so users can
            # interpret minor noise that comes from format differences
            # (SaveAsXML's per-step coverage is more permissive than DDR's
            # DDRInfo rollups, dynamic refs are unresolvable in both).
            typer.echo(
                f"note: diffing a {old_source!r} index against a "
                f"{new_source!r} index — small edge-count differences are "
                f"expected even for the same FM solution.",
                err=True,
            )
        payload = compute_diff(
            old_conn, new_conn,
            detect_renames=rename_detect,
            include_impact=impact,
        )
    except FileNotFoundError as e:
        typer.echo(f"error: {e}", err=True)
        raise typer.Exit(code=2)
    render_diff(
        payload, format_,
        old_meta=_snapshot_envelope(old_conn, old),
        new_meta=_snapshot_envelope(new_conn, new),
    )
    raise typer.Exit(code=0 if payload["summary"]["total_changes"] == 0 else 1)


# ----------------------------------------------------------------------
# table list / show / fields
# ----------------------------------------------------------------------

@table_app.command("list")
def table_list(
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    fmt = _format_opt(output)
    conn = dbmod.connect(dbmod.find_db(db))
    rows = q_tables.list_tables(conn)
    render(envelope(kind="table.list", ddr=dbmod.ddr_envelope(conn), result=rows), fmt)


@table_app.command("show")
def table_show(
    name_or_id: str = typer.Argument(...),
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    fmt = _format_opt(output)
    conn = dbmod.connect(dbmod.find_db(db))
    t = _handle_resolve(resolvers.resolve_table, conn, name_or_id)
    detail = q_tables.get_table(conn, t["id"])
    render(
        envelope(
            kind="table.show",
            ddr=dbmod.ddr_envelope(conn),
            query={"table": t},
            result=detail,
        ),
        fmt,
    )


@table_app.command("fields")
def table_fields_cmd(
    name_or_id: str = typer.Argument(...),
    field_type: Optional[str] = typer.Option(None, "--type"),
    unstored: bool = typer.Option(False, "--unstored"),
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    fmt = _format_opt(output)
    conn = dbmod.connect(dbmod.find_db(db))
    t = _handle_resolve(resolvers.resolve_table, conn, name_or_id)
    rows = q_tables.table_fields(conn, t["id"], field_type=field_type, only_unstored=unstored)
    render(
        envelope(
            kind="table.fields",
            ddr=dbmod.ddr_envelope(conn),
            query={"table": t, "type": field_type, "unstored": unstored},
            result=rows,
        ),
        fmt,
    )


# ----------------------------------------------------------------------
# field show
# ----------------------------------------------------------------------

@field_app.command("show")
def field_show(
    token: str = typer.Argument(..., help='"Table::Field" or numeric id'),
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    fmt = _format_opt(output)
    conn = dbmod.connect(dbmod.find_db(db))
    f = _handle_resolve(resolvers.resolve_field, conn, token)
    render(
        envelope(
            kind="field.show",
            ddr=dbmod.ddr_envelope(conn),
            query={"token": token},
            result=f,
        ),
        fmt,
    )


# ----------------------------------------------------------------------
# field references / on-layouts / script-refs / field-refs / where
# ----------------------------------------------------------------------

@field_app.command("references")
def field_references_cmd(
    token: str = typer.Argument(...),
    kind: Optional[str] = typer.Option(None, "--kind"),
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    """All references to a field (every owner_kind), denormalized."""
    fmt = _format_opt(output)
    conn = dbmod.connect(dbmod.find_db(db))
    f = _handle_resolve(resolvers.resolve_field, conn, token)
    rows = q_fields.field_references(conn, f["id"], kind=kind)
    render(
        envelope(
            kind="field.references",
            ddr=dbmod.ddr_envelope(conn),
            query={"field": {"id": f["id"], "name": f["name"], "table": f["table_name"]},
                   "kind": kind},
            result=rows,
        ),
        fmt,
    )


@field_app.command("script-refs")
def field_script_refs_cmd(
    token: str = typer.Argument(...),
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    """One row per (script, step) that names this field."""
    fmt = _format_opt(output)
    conn = dbmod.connect(dbmod.find_db(db))
    f = _handle_resolve(resolvers.resolve_field, conn, token)
    rows = q_fields.field_script_refs(conn, f["id"])
    render(
        envelope(
            kind="field.script-refs",
            ddr=dbmod.ddr_envelope(conn),
            query={"field": {"id": f["id"], "name": f["name"], "table": f["table_name"]}},
            result=rows,
        ),
        fmt,
    )


@field_app.command("on-layouts")
def field_on_layouts_cmd(
    token: str = typer.Argument(...),
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    """Distinct layouts that show this field via any object."""
    fmt = _format_opt(output)
    conn = dbmod.connect(dbmod.find_db(db))
    f = _handle_resolve(resolvers.resolve_field, conn, token)
    rows = q_fields.field_on_layouts(conn, f["id"])
    render(
        envelope(
            kind="field.on-layouts",
            ddr=dbmod.ddr_envelope(conn),
            query={"field": {"id": f["id"], "name": f["name"], "table": f["table_name"]}},
            result=rows,
        ),
        fmt,
    )


@field_app.command("field-refs")
def field_field_refs_cmd(
    token: str = typer.Argument(...),
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    """Other fields whose calc/AutoEnter/Validation names this field."""
    fmt = _format_opt(output)
    conn = dbmod.connect(dbmod.find_db(db))
    f = _handle_resolve(resolvers.resolve_field, conn, token)
    rows = q_fields.field_field_refs(conn, f["id"])
    render(
        envelope(
            kind="field.field-refs",
            ddr=dbmod.ddr_envelope(conn),
            query={"field": {"id": f["id"], "name": f["name"], "table": f["table_name"]}},
            result=rows,
        ),
        fmt,
    )


@field_app.command("where")
def field_where_cmd(
    token: str = typer.Argument(...),
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    """Counts by owner_kind — superset summary."""
    fmt = _format_opt(output)
    conn = dbmod.connect(dbmod.find_db(db))
    f = _handle_resolve(resolvers.resolve_field, conn, token)
    rows = q_fields.field_where(conn, f["id"])
    render(
        envelope(
            kind="field.where",
            ddr=dbmod.ddr_envelope(conn),
            query={"field": {"id": f["id"], "name": f["name"], "table": f["table_name"]}},
            result=rows,
        ),
        fmt,
    )


# ----------------------------------------------------------------------
# script list / show / steps

@script_app.command("list")
def script_list_cmd(
    folder: Optional[str] = typer.Option(None, "--folder"),
    name: Optional[str] = typer.Option(None, "--name"),
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    fmt = _format_opt(output)
    conn = dbmod.connect(dbmod.find_db(db))
    rows = q_scripts.list_scripts(conn, folder=folder, name_substring=name)
    render(
        envelope(
            kind="script.list",
            ddr=dbmod.ddr_envelope(conn),
            query={"folder": folder, "name": name},
            result=rows,
        ),
        fmt,
    )


@script_app.command("show")
def script_show(
    token: str = typer.Argument(...),
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    fmt = _format_opt(output)
    conn = dbmod.connect(dbmod.find_db(db))
    s = _handle_resolve(resolvers.resolve_script, conn, token)
    step_count = conn.execute(
        "SELECT COUNT(*) FROM script_step WHERE script_id = ?", (s["id"],)
    ).fetchone()[0]
    s["step_count"] = step_count
    render(
        envelope(
            kind="script.show",
            ddr=dbmod.ddr_envelope(conn),
            query={"token": token},
            result=s,
        ),
        fmt,
    )


@script_app.command("steps")
def script_steps_cmd(
    token: str = typer.Argument(...),
    type_: Optional[str] = typer.Option(None, "--type"),
    has: Optional[str] = typer.Option(
        None, "--has",
        help="Filter on derived flags: execute_sql|evaluate|get_script_parameter|get_script_result",
    ),
    no_disabled: bool = typer.Option(False, "--no-disabled"),
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    fmt = _format_opt(output)
    conn = dbmod.connect(dbmod.find_db(db))
    s = _handle_resolve(resolvers.resolve_script, conn, token)
    try:
        rows = q_scripts.script_steps(
            conn, s["id"], step_type=type_, has_flag=has, include_disabled=not no_disabled,
        )
    except ValueError as e:
        typer.echo(f"error: {e}", err=True)
        raise typer.Exit(code=64)
    render(
        envelope(
            kind="script.steps",
            ddr=dbmod.ddr_envelope(conn),
            query={"script": s, "type": type_, "has": has},
            result=rows,
        ),
        fmt,
    )


@script_app.command("elements")
def script_elements_cmd(
    token: str = typer.Argument(...),
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    """All elements (fields, scripts, layouts, CFs) referenced anywhere in the script."""
    fmt = _format_opt(output)
    conn = dbmod.connect(dbmod.find_db(db))
    s = _handle_resolve(resolvers.resolve_script, conn, token)
    rows = q_scripts.script_elements(conn, s["id"])
    render(envelope(kind="script.elements", ddr=dbmod.ddr_envelope(conn),
                    query={"script": s}, result=rows), fmt)


@script_app.command("calcs")
def script_calcs_cmd(
    token: str = typer.Argument(...),
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    """Every step text in the script."""
    fmt = _format_opt(output)
    conn = dbmod.connect(dbmod.find_db(db))
    s = _handle_resolve(resolvers.resolve_script, conn, token)
    rows = q_scripts.script_calcs(conn, s["id"])
    render(envelope(kind="script.calcs", ddr=dbmod.ddr_envelope(conn),
                    query={"script": s}, result=rows), fmt)


@script_app.command("calls")
def script_calls_cmd(
    token: str = typer.Argument(...),
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    """Scripts called by this script (Perform Script steps)."""
    fmt = _format_opt(output)
    conn = dbmod.connect(dbmod.find_db(db))
    s = _handle_resolve(resolvers.resolve_script, conn, token)
    rows = q_scripts.script_calls(conn, s["id"])
    render(
        envelope(kind="script.calls", ddr=dbmod.ddr_envelope(conn),
                 query={"script": s}, result=rows),
        fmt,
    )


@script_app.command("called-by")
def script_called_by_cmd(
    token: str = typer.Argument(...),
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    """Everything that calls this script."""
    fmt = _format_opt(output)
    conn = dbmod.connect(dbmod.find_db(db))
    s = _handle_resolve(resolvers.resolve_script, conn, token)
    rows = q_scripts.script_called_by(conn, s["id"])
    render(
        envelope(kind="script.called-by", ddr=dbmod.ddr_envelope(conn),
                 query={"script": s}, result=rows),
        fmt,
    )


@script_app.command("mermaid")
def script_mermaid_cmd(
    token: str = typer.Argument(...),
    depth: int = typer.Option(5, "--depth", "-d"),
    direction: str = typer.Option("down", "--direction", help="down | up | both"),
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
) -> None:
    """Mermaid flowchart of the call chain around a script."""
    conn = dbmod.connect(dbmod.find_db(db))
    s = _handle_resolve(resolvers.resolve_script, conn, token)
    diagram = q_scripts.script_chain_mermaid(
        conn, s["id"], max_depth=depth, direction=direction
    )
    typer.echo(diagram)


@script_app.command("fields")
def script_fields_cmd(
    token: str = typer.Argument(...),
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    """Distinct fields this script touches across all its steps."""
    fmt = _format_opt(output)
    conn = dbmod.connect(dbmod.find_db(db))
    s = _handle_resolve(resolvers.resolve_script, conn, token)
    rows = q_scripts.script_fields(conn, s["id"])
    render(
        envelope(kind="script.fields", ddr=dbmod.ddr_envelope(conn),
                 query={"script": s}, result=rows),
        fmt,
    )


# ----------------------------------------------------------------------
# cf list / show / called-by
# ----------------------------------------------------------------------

@cf_app.command("list")
def cf_list_cmd(
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    fmt = _format_opt(output)
    conn = dbmod.connect(dbmod.find_db(db))
    rows = q_cf.list_cfs(conn)
    render(envelope(kind="cf.list", ddr=dbmod.ddr_envelope(conn), result=rows), fmt)


@cf_app.command("show")
def cf_show_cmd(
    token: str = typer.Argument(...),
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    fmt = _format_opt(output)
    conn = dbmod.connect(dbmod.find_db(db))
    try:
        cf = q_cf.resolve(conn, token)
    except q_cf.NotFound as e:
        typer.echo(f"error: {e}", err=True)
        raise typer.Exit(code=1)
    render(envelope(kind="cf.show", ddr=dbmod.ddr_envelope(conn),
                    query={"token": token}, result=cf), fmt)


@cf_app.command("calls")
def cf_calls_cmd(
    token: str = typer.Argument(...),
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    """Other custom functions this CF calls."""
    fmt = _format_opt(output)
    conn = dbmod.connect(dbmod.find_db(db))
    try:
        cf = q_cf.resolve(conn, token)
    except q_cf.NotFound as e:
        typer.echo(f"error: {e}", err=True); raise typer.Exit(code=1)
    rows = q_cf.cf_calls(conn, cf["id"])
    render(envelope(kind="cf.calls", ddr=dbmod.ddr_envelope(conn),
                    query={"cf": {"id": cf["id"], "name": cf["name"]}}, result=rows), fmt)


@cf_app.command("fields")
def cf_fields_cmd(
    token: str = typer.Argument(...),
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    """Fields referenced inside this CF body."""
    fmt = _format_opt(output)
    conn = dbmod.connect(dbmod.find_db(db))
    try:
        cf = q_cf.resolve(conn, token)
    except q_cf.NotFound as e:
        typer.echo(f"error: {e}", err=True); raise typer.Exit(code=1)
    rows = q_cf.cf_fields(conn, cf["id"])
    render(envelope(kind="cf.fields", ddr=dbmod.ddr_envelope(conn),
                    query={"cf": {"id": cf["id"], "name": cf["name"]}}, result=rows), fmt)


@cf_app.command("called-by")
def cf_called_by_cmd(
    token: str = typer.Argument(...),
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    """Everything that uses this custom function (the DateRange→Portal drill)."""
    fmt = _format_opt(output)
    conn = dbmod.connect(dbmod.find_db(db))
    try:
        cf = q_cf.resolve(conn, token)
    except q_cf.NotFound as e:
        typer.echo(f"error: {e}", err=True)
        raise typer.Exit(code=1)
    rows = q_cf.cf_called_by(conn, cf["id"])
    render(envelope(kind="cf.called-by", ddr=dbmod.ddr_envelope(conn),
                    query={"cf": {"id": cf["id"], "name": cf["name"]}}, result=rows), fmt)


@app.command("risky-steps")
def risky_steps_cmd(
    has: str = typer.Option("execute_sql", "--has"),
    limit: Optional[int] = typer.Option(None, "--limit"),
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    """Steps with risky derived calc-content flags (execute_sql, evaluate, …)."""
    fmt = _format_opt(output)
    conn = dbmod.connect(dbmod.find_db(db))
    try:
        rows = q_scripts.risky_steps(conn, has_flag=has, limit=limit)
    except ValueError as e:
        typer.echo(f"error: {e}", err=True)
        raise typer.Exit(code=64)
    render(
        envelope(
            kind="risky-steps",
            ddr=dbmod.ddr_envelope(conn),
            query={"has": has, "limit": limit},
            result=rows,
        ),
        fmt,
    )


@app.command("globals-solution")
def globals_solution_cmd(
    only_never_cleared: bool = typer.Option(False, "--only-never-cleared", "-n",
                                            help="Show only vars with zero clear_script_count."),
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    """Solution-wide $$global lifecycle: set vs cleared counts per variable."""
    fmt = _format_opt(output)
    conn = dbmod.connect(dbmod.find_db(db))
    rows = q_scripts.globals_solution_wide(conn)
    if only_never_cleared:
        rows = [r for r in rows if r["clear_script_count"] == 0]
    render(
        envelope(kind="globals-solution", ddr=dbmod.ddr_envelope(conn),
                 query={"only_never_cleared": only_never_cleared}, result=rows),
        fmt,
    )


@script_app.command("globals-callee")
def globals_callee_cmd(
    token: str = typer.Argument(...),
    depth: int = typer.Option(10, "--depth", "-d"),
    uncleared_only: bool = typer.Option(False, "--uncleared-only", "-u",
                                        help="Show only vars with no clear in callee tree."),
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    """$$globals set by a script and whether they're cleared in its callee tree."""
    fmt = _format_opt(output)
    conn = dbmod.connect(dbmod.find_db(db))
    s = _handle_resolve(resolvers.resolve_script, conn, token)
    rows = q_scripts.globals_callee_uncleared(conn, s["id"], max_depth=depth)
    if uncleared_only:
        rows = [r for r in rows if not r["cleared"]]
    render(
        envelope(kind="script.globals-callee", ddr=dbmod.ddr_envelope(conn),
                 query={"script": s, "depth": depth}, result=rows),
        fmt,
    )


@app.command("globals-uncleared")
def globals_uncleared_cmd(
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    """Scripts that set a $$global variable without clearing it in the same script."""
    fmt = _format_opt(output)
    conn = dbmod.connect(dbmod.find_db(db))
    rows = q_scripts.globals_set_not_cleared(conn)
    render(
        envelope(
            kind="globals-uncleared",
            ddr=dbmod.ddr_envelope(conn),
            query={},
            result=rows,
        ),
        fmt,
    )
    if rows:
        raise typer.Exit(code=1)


# ----------------------------------------------------------------------
# layout list / show
# ----------------------------------------------------------------------

@layout_app.command("list")
def layout_list_cmd(
    folder: Optional[str] = typer.Option(None, "--folder"),
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    fmt = _format_opt(output)
    conn = dbmod.connect(dbmod.find_db(db))
    rows = q_layouts.list_layouts(conn, folder=folder)
    render(
        envelope(
            kind="layout.list",
            ddr=dbmod.ddr_envelope(conn),
            query={"folder": folder},
            result=rows,
        ),
        fmt,
    )


@layout_app.command("show")
def layout_show(
    token: str = typer.Argument(...),
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    fmt = _format_opt(output)
    conn = dbmod.connect(dbmod.find_db(db))
    layout = _handle_resolve(resolvers.resolve_layout, conn, token)
    render(
        envelope(
            kind="layout.show",
            ddr=dbmod.ddr_envelope(conn),
            query={"token": token},
            result=layout,
        ),
        fmt,
    )


@layout_app.command("objects")
def layout_objects_cmd(
    token: str = typer.Argument(...),
    object_type: Optional[str] = typer.Option(None, "--type"),
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    fmt = _format_opt(output)
    conn = dbmod.connect(dbmod.find_db(db))
    ly = _handle_resolve(resolvers.resolve_layout, conn, token)
    rows = q_layouts.layout_objects(conn, ly["id"], object_type=object_type)
    render(envelope(kind="layout.objects", ddr=dbmod.ddr_envelope(conn),
                    query={"layout": ly, "type": object_type}, result=rows), fmt)


@layout_app.command("fields")
def layout_fields_cmd(
    token: str = typer.Argument(...),
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    fmt = _format_opt(output)
    conn = dbmod.connect(dbmod.find_db(db))
    ly = _handle_resolve(resolvers.resolve_layout, conn, token)
    rows = q_layouts.layout_fields(conn, ly["id"])
    render(envelope(kind="layout.fields", ddr=dbmod.ddr_envelope(conn),
                    query={"layout": ly}, result=rows), fmt)


@layout_app.command("scripts")
def layout_scripts_cmd(
    token: str = typer.Argument(...),
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    fmt = _format_opt(output)
    conn = dbmod.connect(dbmod.find_db(db))
    ly = _handle_resolve(resolvers.resolve_layout, conn, token)
    rows = q_layouts.layout_scripts(conn, ly["id"])
    render(envelope(kind="layout.scripts", ddr=dbmod.ddr_envelope(conn),
                    query={"layout": ly}, result=rows), fmt)


# ----------------------------------------------------------------------
# graph relationships / tos / predicates / path
# ----------------------------------------------------------------------

@graph_app.command("relationships")
def graph_relationships_cmd(
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    fmt = _format_opt(output)
    conn = dbmod.connect(dbmod.find_db(db))
    rows = q_graph.list_relationships(conn)
    render(envelope(kind="graph.relationships", ddr=dbmod.ddr_envelope(conn),
                    result=rows), fmt)


@graph_app.command("tos")
def graph_tos_cmd(
    base_table: Optional[str] = typer.Option(None, "--base-table"),
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    fmt = _format_opt(output)
    conn = dbmod.connect(dbmod.find_db(db))
    bt_id: int | None = None
    if base_table is not None:
        t = _handle_resolve(resolvers.resolve_table, conn, base_table)
        bt_id = t["id"]
    rows = q_graph.list_tos(conn, base_table_id=bt_id)
    render(envelope(kind="graph.tos", ddr=dbmod.ddr_envelope(conn),
                    query={"base_table": base_table}, result=rows), fmt)


@graph_app.command("predicates")
def graph_predicates_cmd(
    relationship_id: int = typer.Argument(..., help="Relationship id"),
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    fmt = _format_opt(output)
    conn = dbmod.connect(dbmod.find_db(db))
    rows = q_graph.predicates_for(conn, relationship_id)
    render(envelope(kind="graph.predicates", ddr=dbmod.ddr_envelope(conn),
                    query={"relationship_id": relationship_id}, result=rows), fmt)


@graph_app.command("path")
def graph_path_cmd(
    from_to: str = typer.Argument(..., help="Source TO name or id"),
    to_to: str = typer.Argument(..., help="Target TO name or id"),
    max_hops: int = typer.Option(6, "--max-hops"),
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    """Shortest TO→TO path through relationships."""
    fmt = _format_opt(output)
    conn = dbmod.connect(dbmod.find_db(db))

    def _to_id(token: str) -> int:
        t = token.strip().lstrip("#")
        if t.isdigit():
            return int(t)
        row = conn.execute("SELECT id FROM table_occurrence WHERE name = ?", (token,)).fetchone()
        if row is None:
            typer.echo(f"error: unknown TO {token!r}", err=True)
            raise typer.Exit(code=1)
        return row[0]

    a, b = _to_id(from_to), _to_id(to_to)
    path = q_graph.to_path(conn, a, b, max_hops=max_hops)
    render(envelope(kind="graph.path", ddr=dbmod.ddr_envelope(conn),
                    query={"from": from_to, "to": to_to, "max_hops": max_hops},
                    result=path or []), fmt)


@graph_app.command("erd")
def graph_erd_cmd(
    table: Optional[str] = typer.Option(
        None, "--table", "-t",
        help="Focus on one base table and its direct neighbours.",
    ),
    all_fields: bool = typer.Option(
        False, "--all-fields",
        help="Include all fields, not just PKs and FKs.",
    ),
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
) -> None:
    """Mermaid erDiagram of base tables and their relationships.

    By default shows only PK/FK fields. Use --all-fields to include every
    field. Use --table to scope to one table and its direct neighbours.
    """
    conn = dbmod.connect(dbmod.find_db(db))
    try:
        diagram = q_graph.erd_mermaid(conn, focus_table=table, all_fields=all_fields)
    except ValueError as exc:
        typer.echo(f"error: {exc}", err=True)
        raise typer.Exit(code=1)
    typer.echo(diagram)


# ----------------------------------------------------------------------
# script chain (recursive call graph) — alias from the plan: graph chain too
# ----------------------------------------------------------------------

@script_app.command("chain")
def script_chain_cmd(
    token: str = typer.Argument(...),
    depth: int = typer.Option(3, "--depth"),
    chain_format: str = typer.Option("json", "--format",
                                     help="json|mermaid|dot"),
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    """Outgoing call chain. --format mermaid|dot writes the diagram to stdout."""
    fmt = _format_opt(output)
    conn = dbmod.connect(dbmod.find_db(db))
    s = _handle_resolve(resolvers.resolve_script, conn, token)
    edges = q_impact.script_chain(conn, s["id"], depth=depth)
    if chain_format == "mermaid":
        sys.stdout.write(q_impact.chain_to_mermaid(edges))
        return
    if chain_format == "dot":
        sys.stdout.write(q_impact.chain_to_dot(edges))
        return
    render(envelope(kind="script.chain", ddr=dbmod.ddr_envelope(conn),
                    query={"script": s, "depth": depth}, result=edges), fmt)


# ----------------------------------------------------------------------
# script grep
# ----------------------------------------------------------------------

@script_app.command("grep")
def script_grep_cmd(
    token: str = typer.Argument(...),
    pattern: str = typer.Argument(...),
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    """Regex search step text within a script."""
    fmt = _format_opt(output)
    conn = dbmod.connect(dbmod.find_db(db))
    s = _handle_resolve(resolvers.resolve_script, conn, token)
    rows = q_search.script_grep(conn, s["id"], pattern)
    render(envelope(kind="script.grep", ddr=dbmod.ddr_envelope(conn),
                    query={"script": s, "pattern": pattern}, result=rows), fmt)


# ----------------------------------------------------------------------
# top-level: impact / unused / orphans / search
# ----------------------------------------------------------------------

def _parse_step_token(token: str) -> tuple[str, int]:
    """Accept "Script Name:line" or "ScriptName:42"."""
    if ":" not in token:
        raise typer.BadParameter("Step token must be 'Script:line', e.g. 'Add Customer:1'")
    head, tail = token.rsplit(":", 1)
    if not tail.isdigit():
        raise typer.BadParameter(f"Expected an integer step index after ':', got {tail!r}")
    return head, int(tail)


@step_app.command("show")
def step_show_cmd(
    token: str = typer.Argument(..., help='"Script Name:step_index" — e.g. "Add Customer:1"'),
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    """Show full step detail (FMP step id, has_* flags, var name, step text)."""
    fmt = _format_opt(output)
    conn = dbmod.connect(dbmod.find_db(db))
    script_token, idx = _parse_step_token(token)
    s = _handle_resolve(resolvers.resolve_script, conn, script_token)
    row = q_scripts.step_show(conn, s["id"], idx)
    if row is None:
        typer.echo(f"error: no step at {script_token!r}:{idx}", err=True)
        raise typer.Exit(code=1)
    render(envelope(kind="step.show", ddr=dbmod.ddr_envelope(conn),
                    query={"script": s, "step_index": idx}, result=row), fmt)


@step_app.command("refs")
def step_refs_cmd(
    token: str = typer.Argument(...),
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    """Everything this single step references (fields, scripts, layouts, CFs)."""
    fmt = _format_opt(output)
    conn = dbmod.connect(dbmod.find_db(db))
    script_token, idx = _parse_step_token(token)
    s = _handle_resolve(resolvers.resolve_script, conn, script_token)
    result = q_scripts.step_refs(conn, s["id"], idx)
    render(envelope(kind="step.refs", ddr=dbmod.ddr_envelope(conn),
                    query={"script": s, "step_index": idx}, result=result), fmt)


@app.command("cleanup-candidates")
def cleanup_candidates_cmd(
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    """Names matching debt patterns (BACKUP, COPY, OLD, TEMP, …) — refactor candidates."""
    fmt = _format_opt(output)
    conn = dbmod.connect(dbmod.find_db(db))
    result = q_scripts.cleanup_candidates(conn)
    render(envelope(kind="cleanup-candidates", ddr=dbmod.ddr_envelope(conn),
                    result=result), fmt)


@app.command("impact")
def impact_cmd(
    kind: str = typer.Argument(..., help="field|script"),
    token: str = typer.Argument(...),
    depth: int = typer.Option(3, "--depth"),
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    """Transitive what-breaks-if-removed for a field or script."""
    fmt = _format_opt(output)
    conn = dbmod.connect(dbmod.find_db(db))
    if kind == "field":
        f = _handle_resolve(resolvers.resolve_field, conn, token)
        result = q_impact.impact_field(conn, f["id"])
        render(envelope(kind="impact.field", ddr=dbmod.ddr_envelope(conn),
                        query={"field": {"id": f["id"], "name": f["name"],
                                          "table": f["table_name"]}},
                        result=result), fmt)
    elif kind == "script":
        s = _handle_resolve(resolvers.resolve_script, conn, token)
        result = q_impact.impact_script(conn, s["id"], depth=depth)
        render(envelope(kind="impact.script", ddr=dbmod.ddr_envelope(conn),
                        query={"script": s, "depth": depth}, result=result), fmt)
    else:
        typer.echo(f"error: unknown impact kind {kind!r} (use 'field' or 'script')",
                   err=True)
        raise typer.Exit(code=64)


@app.command("unused")
def unused_cmd(
    kind: str = typer.Option(..., "--kind",
                              help="field|script|layout|custom_function|value_list|table_occurrence"),
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    """Objects with no inbound references."""
    fmt = _format_opt(output)
    conn = dbmod.connect(dbmod.find_db(db))
    try:
        rows = q_impact.unused(conn, kind)
    except ValueError as e:
        typer.echo(f"error: {e}", err=True)
        raise typer.Exit(code=64)
    render(envelope(kind=f"unused.{kind}", ddr=dbmod.ddr_envelope(conn),
                    query={"kind": kind}, result=rows), fmt)


@app.command("orphans")
def orphans_cmd(
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    """Refs whose target rows don't exist (FM allows broken references)."""
    fmt = _format_opt(output)
    conn = dbmod.connect(dbmod.find_db(db))
    if _meta_partial(conn):
        # A partial index has unresolved calc-derived edges, so orphan
        # detection over-reports. Warn but still run — the result is
        # advisory rather than authoritative.
        typer.echo(
            "warning: index is partial — calc-derived refs may not be fully "
            "resolved, so orphan detection may include false positives.",
            err=True,
        )
    result = q_impact.orphans(conn)
    render(envelope(kind="orphans", ddr=dbmod.ddr_envelope(conn), result=result), fmt)


@app.command("search")
def search_cmd(
    query: str = typer.Argument(..., help='FTS5 query, e.g. "Customer*" or "Get Script Result"'),
    kind: Optional[str] = typer.Option(None, "--kind"),
    limit: int = typer.Option(50, "--limit"),
    db: Optional[pathlib.Path] = typer.Option(None, "--db"),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    """FTS-backed name search across tables, fields, scripts, layouts, CFs, value lists, TOs."""
    fmt = _format_opt(output)
    conn = dbmod.connect(dbmod.find_db(db))
    rows = q_search.search_names(conn, query, kind=kind, limit=limit)
    render(envelope(kind="search", ddr=dbmod.ddr_envelope(conn),
                    query={"query": query, "kind": kind, "limit": limit},
                    result=rows), fmt)


# ----------------------------------------------------------------------
# Clipboard: copy / paste / validate / clipboard formats
# ----------------------------------------------------------------------

clipboard_app = typer.Typer(help="Inspect the FileMaker clipboard.")
app.add_typer(clipboard_app, name="clipboard")


@app.command("copy")
def copy_cmd(
    path: pathlib.Path = typer.Argument(..., exists=True, readable=True, dir_okay=False,
                                         help="A per-object XML file from `fmddr split` output."),
    element_type: Optional[str] = typer.Option(
        None, "--type",
        help="Override the FM element type (Script|Table|CustomFunction|...). Default: detect from DDR root.",
    ),
    steps: Optional[str] = typer.Option(
        None, "--steps",
        help='Copy script steps as a ScriptStep snippet (paste into an open script). 1-based, matches `fmddr step show`. Examples: "all", "5", "5-12", "5,8,11", "5-12,15".',
    ),
    snippet: bool = typer.Option(
        False, "--snippet",
        help="Treat the input file as a raw <fmxmlsnippet> (e.g. an edited `fmddr paste` payload) and push it to the clipboard verbatim. Skips split-tree guards and DDR transform.",
    ),
    notify: bool = typer.Option(
        True, "--notify/--no-notify",
        help="On success, show a desktop notification (macOS). Suppressed for JSON output.",
    ),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    """Read a split-tree XML file, transform to <fmxmlsnippet>, push to clipboard.

    macOS only in v1. Hard-blocks on schema violations; surfaces warnings in the envelope.
    With `--steps`, copies just those <Step> elements as a ScriptStep snippet.
    """
    from .clipboard import (
        FileMakerClipboardError,
        detect_fm_type_from_xml,
        notify as _notify,
        resolve_write_element_type,
        set_fm_xml,
    )
    from .edit.guards import run_guards
    from .transform.ddr_to_snippet import (
        extract_steps_as_snippet,
        parse_step_spec,
        transform_file_xml,
    )

    fmt = _format_opt(output)
    xml_text = path.read_text(encoding="utf-8")

    if snippet and steps is not None:
        typer.echo(
            "error [UNSUPPORTED_ELEMENT_TYPE]: --snippet and --steps are mutually exclusive.",
            err=True,
        )
        raise typer.Exit(code=64)

    if snippet:
        try:
            detected = detect_fm_type_from_xml(xml_text)
            fm_type = resolve_write_element_type(detected=detected, requested=element_type)
            set_fm_xml(xml_text, fm_type)
        except FileMakerClipboardError as e:
            typer.echo(f"error [{e.code}]: {e}", err=True)
            raise typer.Exit(code=70)
        result = {
            "ok": True,
            "path": str(path),
            "fm_type": fm_type,
            "ddr_root": None,
            "warnings": [],
            "message": f"Clipboard set for {fm_type}. Switch to FileMaker and paste.",
        }
        if notify and fmt not in ("json", "jsonl"):
            _notify(
                "fmddr: copied to clipboard",
                "Switch to FileMaker and paste.",
                subtitle=f"{path.stem} ({fm_type})",
            )
        render(envelope(kind="copy", ddr={}, result=result), fmt)
        return

    if steps is not None and element_type and element_type != "ScriptStep":
        typer.echo(
            f'error [UNSUPPORTED_ELEMENT_TYPE]: --steps forces type=ScriptStep; got --type={element_type}.',
            err=True,
        )
        raise typer.Exit(code=70)

    report = run_guards(path, xml_text)
    if not report.ok:
        render(envelope(kind="copy", ddr={}, result={"ok": False, **report.to_dict()}), fmt)
        raise typer.Exit(code=64)

    try:
        if steps is not None:
            indices = None if steps.strip().lower() == "all" else parse_step_spec(steps)
            transformed = extract_steps_as_snippet(xml_text, indices)
            fm_type = "ScriptStep"
        else:
            transformed = transform_file_xml(xml_text)
            fm_type = resolve_write_element_type(
                detected=transformed["fm_type"], requested=element_type
            )
        set_fm_xml(transformed["snippet_xml"], fm_type)
    except FileMakerClipboardError as e:
        typer.echo(f"error [{e.code}]: {e}", err=True)
        raise typer.Exit(code=70)

    result = {
        "ok": True,
        "path": str(path),
        "fm_type": fm_type,
        "ddr_root": transformed["ddr_root"],
        "warnings": report.warnings + transformed["warnings"],
        "message": f"Clipboard set for {fm_type}. Switch to FileMaker and paste.",
    }
    if steps is not None:
        result["selected_indices"] = transformed["selected_indices"]
        result["step_count"] = transformed["step_count"]
        result["message"] = (
            f'Clipboard set for ScriptStep ({len(transformed["selected_indices"])} '
            f'of {transformed["step_count"]} steps). Switch to FileMaker and paste.'
        )
    if notify and fmt not in ("json", "jsonl"):
        root_name = report.root_name or path.stem
        if steps is not None:
            n_sel = len(transformed["selected_indices"])
            total = transformed["step_count"]
            subtitle = f"{root_name} — {n_sel} of {total} steps"
        else:
            subtitle = f"{root_name} ({fm_type})"
        _notify("fmddr: copied to clipboard", "Switch to FileMaker and paste.", subtitle=subtitle)
    render(envelope(kind="copy", ddr={}, result=result), fmt)


@app.command("paste")
def paste_cmd(
    element_type: Optional[str] = typer.Option(
        None, "--type",
        help="Read a specific FM element type. Default: first FM format found on the clipboard.",
    ),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    """Read FileMaker clipboard XML and print it as <fmxmlsnippet>."""
    from .clipboard import (
        FileMakerClipboardError,
        detect_fm_type_from_xml,
        get_first_fm_xml,
        get_fm_xml,
        list_fm_formats,
    )

    fmt = _format_opt(output)
    try:
        clip = get_fm_xml(element_type) if element_type else get_first_fm_xml()
    except FileMakerClipboardError as e:
        typer.echo(f"error [{e.code}]: {e}", err=True)
        raise typer.Exit(code=1)

    result = {
        "requested_element_type": element_type,
        "detected_element_type": detect_fm_type_from_xml(clip["xml"]),
        "format": clip["format"],
        "xml": _pretty_xml(clip["xml"]),
        "available_formats": list_fm_formats(),
    }
    render(envelope(kind="paste", ddr={}, result=result), fmt)


@app.command("validate")
def validate_cmd(
    path: pathlib.Path = typer.Argument(..., exists=True, readable=True, dir_okay=False),
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    """Run pre-clipboard guards on a split-tree XML file. No clipboard side effects.

    Exits 0 if clean (warnings ok), 1 if there are hard errors.
    """
    from .edit.guards import run_guards

    fmt = _format_opt(output)
    xml_text = path.read_text(encoding="utf-8")
    report = run_guards(path, xml_text)
    render(envelope(kind="validate", ddr={}, result={"path": str(path), **report.to_dict()}), fmt)
    if not report.ok:
        raise typer.Exit(code=1)


@clipboard_app.command("formats")
def clipboard_formats(
    output: Optional[str] = typer.Option(None, "-o", "--output"),
) -> None:
    """List FileMaker-recognized clipboard formats currently present."""
    from .clipboard import FileMakerClipboardError, list_fm_formats

    fmt = _format_opt(output)
    try:
        formats = list_fm_formats()
    except FileMakerClipboardError as e:
        typer.echo(f"error [{e.code}]: {e}", err=True)
        raise typer.Exit(code=1)
    render(envelope(kind="clipboard.formats", ddr={}, result=formats), fmt)


def main() -> int:  # pragma: no cover - thin wrapper
    try:
        app()
    except SystemExit as e:
        return int(e.code) if isinstance(e.code, int) else 0
    return 0


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
