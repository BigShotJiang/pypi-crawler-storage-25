"""Explode a FileMaker DDR into a per-object XML tree.

Direct port of the existing `pipeline.py` proof-of-concept, repackaged as a
library function. Output mirrors FileMaker's folder hierarchy:

    <out>/
      _header.xml             FMPReport + File attributes
      _metrics.json           machine-readable structural metrics
      tables/<slug>.xml
      layouts/<folder.../>/<slug>.xml
      scripts/<folder.../>/<slug>.xml
      catalogs/<name>.xml     non-exploded whole-document catalogs

The `index` build subsumes this for queries, but `split` stays as a first-class
output: file-per-object XML is grep-able, diff-able, and survives `git blame`,
which the SQLite index cannot offer.
"""
from __future__ import annotations

import io
import json
import pathlib
import re
import shutil
import time
import xml.etree.ElementTree as ET
from collections import defaultdict

from .stream import load_utf8

WHOLE_CATALOGS = {
    "RelationshipGraph": "relationship-graph.xml",
    "ValueListCatalog": "value-lists.xml",
    "CustomFunctionCatalog": "custom-functions.xml",
    "ThemeCatalog": "theme-catalog.xml",
    "PrivilegesCatalog": "privileges.xml",
    "AccountCatalog": "accounts.xml",
    "ExternalDataSourcesCatalog": "external-data-sources.xml",
    "CustomMenuCatalog": "custom-menus.xml",
    "Options": "options.xml",
}

DEBT_RE = re.compile(
    r"\bBACKUP\b|\bCOPY\b|\bDEPRECATED\b|\bDELETE\b|\bORIG\b|\bOLD\b|"
    r"\bTEST\b|\bOBS\b|\bv1\b|\bDRAFT\b|\bTEMP\b|\bb4\b|\bUNUSED\b|\bREMOVE\b",
    re.IGNORECASE,
)

XML_DECL = '<?xml version="1.0" encoding="UTF-8"?>\n'


def slugify(name: str) -> str:
    s = name.strip().lower()
    s = re.sub(r"[^a-z0-9]+", "-", s).strip("-")
    return s or "unnamed"


class _SlugTracker:
    """Per-folder filename uniqueness tracker — survives one split() call."""

    def __init__(self) -> None:
        self._used: dict[pathlib.Path, set[str]] = defaultdict(set)

    def unique(self, folder: pathlib.Path, slug: str, ext: str = ".xml") -> str:
        used = self._used[folder]
        candidate = f"{slug}{ext}"
        n = 2
        while candidate in used:
            candidate = f"{slug}-{n}{ext}"
            n += 1
        used.add(candidate)
        return candidate


def _write_element(path: pathlib.Path, elem: ET.Element) -> int:
    path.parent.mkdir(parents=True, exist_ok=True)
    body = ET.tostring(elem, encoding="unicode")
    data = (XML_DECL + body + "\n").encode("utf-8")
    path.write_bytes(data)
    return len(data)


# Step names that change indentation in a script body. FileMaker's StepText
# already includes parameters/options for each step, so the text view is just
# StepText lines stitched together with control-flow indentation.
_SCRIPT_INDENT_OPEN = {"If", "Loop"}
_SCRIPT_INDENT_CLOSE = {"End If", "End Loop"}
_SCRIPT_INDENT_MID = {"Else", "Else If"}


def _script_to_text(script: ET.Element) -> str:
    """Render a <Script> element as plain text using each step's <StepText>.

    Read-only debugging view: lossy compared to the XML (no DisplayCalculation
    chunks, no resolved Field/Script id refs), but easier for an agent or human
    to scan when they just need to follow the logic.
    """
    name = script.get("name", "")
    sid = script.get("id", "")
    lines: list[str] = [f"# {name} (id={sid})", ""]

    depth = 0
    indent_unit = "    "
    for step in script.findall("./StepList/Step"):
        step_name = step.get("name", "")
        enabled = step.get("enable", "True") != "False"
        text_el = step.find("StepText")
        text = (text_el.text or "").strip() if text_el is not None else step_name

        # Closing tokens dedent before printing; mid tokens print one level out
        # but don't change the running depth.
        line_depth = depth
        if step_name in _SCRIPT_INDENT_CLOSE:
            depth = max(0, depth - 1)
            line_depth = depth
        elif step_name in _SCRIPT_INDENT_MID:
            line_depth = max(0, depth - 1)

        prefix = indent_unit * line_depth
        if not enabled:
            prefix += "// "
        lines.append(prefix + text)

        if step_name in _SCRIPT_INDENT_OPEN:
            depth += 1

    return "\n".join(lines) + "\n"


def _write_script_text(path: pathlib.Path, elem: ET.Element) -> int:
    path.parent.mkdir(parents=True, exist_ok=True)
    data = _script_to_text(elem).encode("utf-8")
    path.write_bytes(data)
    return len(data)


def _stream_split(
    data: bytes,
    out: pathlib.Path,
    slugger: _SlugTracker,
    script_format: str = "xml",
) -> dict:
    stream = io.BytesIO(data)
    parser = ET.iterparse(stream, events=("start", "end"))

    tag_stack: list[str] = []
    folder_stack: list[str] = []  # Group names while inside Script/Layout catalog

    in_script_cat = in_layout_cat = in_basetable_cat = False

    fmp_report_attrs: dict[str, str] = {}
    file_attrs: dict[str, str] = {}
    header_written = False

    table_records: list[dict] = []
    layout_records: list[dict] = []
    script_records: list[dict] = []
    catalog_records: list[dict] = []
    script_folders = 0
    layout_folders = 0

    for event, elem in parser:
        tag = elem.tag

        if event == "start":
            tag_stack.append(tag)
            if tag == "FMPReport" and not fmp_report_attrs:
                fmp_report_attrs = dict(elem.attrib)
            elif tag == "File" and not file_attrs:
                file_attrs = dict(elem.attrib)
            if tag == "ScriptCatalog":
                in_script_cat = True
            elif tag == "LayoutCatalog":
                in_layout_cat = True
            elif tag == "BaseTableCatalog":
                in_basetable_cat = True
            elif tag == "Group":
                if in_script_cat:
                    script_folders += 1
                    folder_stack.append(slugify(elem.get("name", "unnamed")))
                elif in_layout_cat:
                    layout_folders += 1
                    folder_stack.append(slugify(elem.get("name", "unnamed")))
            continue

        # event == "end"
        parent = tag_stack[-2] if len(tag_stack) >= 2 else None

        if tag == "BaseTable" and parent == "BaseTableCatalog" and in_basetable_cat:
            name = elem.get("name", "")
            slug = slugify(name)
            fname = slugger.unique(out / "tables", slug)
            size = _write_element(out / "tables" / fname, elem)
            fields = elem.findall("./FieldCatalog/Field")
            table_records.append(
                {
                    "id": int(elem.get("id", "0")),
                    "name": name,
                    "records": int(elem.get("records", "0")),
                    "fields": len(fields),
                    "calc_fields": sum(1 for f in fields if f.get("fieldType") == "Calculated"),
                    "unstored_calc": sum(
                        1
                        for f in fields
                        if f.get("fieldType") == "Calculated"
                        and (
                            f.find("Storage") is not None
                            and f.find("Storage").get("storeCalculationResults") == "False"
                        )
                    ),
                    "summary_fields": sum(1 for f in fields if f.get("fieldType") == "Summary"),
                    "bytes": size,
                    "file": fname,
                }
            )
            elem.clear()

        elif tag == "Layout" and in_layout_cat and parent in ("LayoutCatalog", "Group"):
            name = elem.get("name", "")
            slug = slugify(name)
            folder = out / "layouts" / pathlib.Path(*folder_stack)
            fname = slugger.unique(folder, slug)
            size = _write_element(folder / fname, elem)
            layout_records.append(
                {
                    "id": int(elem.get("id", "0")),
                    "name": name,
                    "folder": "/".join(folder_stack),
                    "bytes": size,
                    "file": str(pathlib.Path(*folder_stack) / fname),
                }
            )
            elem.clear()

        elif tag == "Script" and in_script_cat and parent in ("ScriptCatalog", "Group"):
            name = elem.get("name", "")
            slug = slugify(name)
            folder = out / "scripts" / pathlib.Path(*folder_stack)
            if script_format == "text":
                fname = slugger.unique(folder, slug, ext=".txt")
                size = _write_script_text(folder / fname, elem)
            else:
                fname = slugger.unique(folder, slug)
                size = _write_element(folder / fname, elem)
            script_records.append(
                {
                    "id": int(elem.get("id", "0")),
                    "name": name,
                    "folder": "/".join(folder_stack),
                    "bytes": size,
                    "file": str(pathlib.Path(*folder_stack) / fname),
                }
            )
            elem.clear()

        elif tag in WHOLE_CATALOGS and parent == "File":
            fname = WHOLE_CATALOGS[tag]
            size = _write_element(out / "catalogs" / fname, elem)
            catalog_records.append({"tag": tag, "file": fname, "bytes": size})
            elem.clear()

        elif tag in ("BaseTableCatalog", "LayoutCatalog", "ScriptCatalog") and parent == "File":
            if tag == "BaseTableCatalog":
                in_basetable_cat = False
            elif tag == "LayoutCatalog":
                in_layout_cat = False
            elif tag == "ScriptCatalog":
                in_script_cat = False
            elem.clear()

        elif tag == "Group" and (in_script_cat or in_layout_cat):
            if folder_stack:
                folder_stack.pop()

        tag_stack.pop()

        if not header_written and fmp_report_attrs and file_attrs:
            root = ET.Element("FMPReport", fmp_report_attrs)
            file_el = ET.SubElement(root, "File", file_attrs)
            file_el.text = (
                "\n  <!-- catalogs split into ./catalogs/, ./tables/, "
                "./layouts/, ./scripts/ -->\n"
            )
            (out / "_header.xml").write_bytes(
                (XML_DECL + ET.tostring(root, encoding="unicode") + "\n").encode("utf-8")
            )
            header_written = True

    return {
        "tables": table_records,
        "layouts": layout_records,
        "scripts": script_records,
        "catalogs": catalog_records,
        "script_folders": script_folders,
        "layout_folders": layout_folders,
    }


def _section_sizes(data: bytes) -> dict[str, int]:
    sections = [
        "BaseTableCatalog", "RelationshipGraph", "ScriptCatalog", "LayoutCatalog",
        "ValueListCatalog", "CustomFunctionCatalog", "ThemeCatalog",
        "PrivilegesCatalog", "AccountCatalog", "ExternalDataSourcesCatalog",
        "CustomMenuCatalog", "Options",
    ]
    out: dict[str, int] = {}
    for s in sections:
        i = data.find(f"<{s}".encode())
        j = data.find(f"</{s}>".encode())
        out[s] = (j - i + len(f"</{s}>".encode())) if (i >= 0 and j > i) else 0
    return out


def _graph_stats(data: bytes) -> dict[str, int]:
    cs = data.find(b"<RelationshipGraph")
    ce = data.find(b"</RelationshipGraph>") + len(b"</RelationshipGraph>")
    if cs < 0 or ce <= cs:
        return {
            "table_occurrences": 0, "relationships": 0, "join_predicates": 0,
            "file_references": 0, "odbc_data_sources": 0,
        }
    sub = data[cs:ce]
    return {
        "table_occurrences": len(re.findall(rb"<Table\b[^>]*\bid=", sub)),
        "relationships": len(re.findall(rb"<Relationship\b[^>]*\bid=", sub)),
        "join_predicates": len(re.findall(rb"<JoinPredicate\b", sub)),
        "file_references": len(re.findall(rb"<FileReference\b", sub)),
        "odbc_data_sources": len(re.findall(rb"<OdbcDataSource\b", sub)),
    }


def _count_in_catalog(data: bytes, catalog_tag: str, child_tag: str) -> int:
    cs = data.find(f"<{catalog_tag}".encode())
    ce = data.find(f"</{catalog_tag}>".encode())
    if cs < 0 or ce <= cs:
        return 0
    return len(re.findall(rb"<" + child_tag.encode() + rb"\b[^>]*\bid=", data[cs:ce]))


def split(
    src: pathlib.Path,
    out: pathlib.Path,
    *,
    quiet: bool = False,
    script_format: str = "xml",
) -> dict:
    """Decode `src`, explode it into `out`, write `_metrics.json`, return metrics dict.

    A clean rebuild — `out` is wiped first so deletions in the source DDR
    propagate.

    `script_format="text"` writes scripts as plain `.txt` files (one StepText
    line per step, indented by control flow) instead of XML. Lossy and
    read-only — it cannot be round-tripped back into the DDR or used by `copy`.
    """
    if script_format not in ("xml", "text"):
        raise ValueError(f"script_format must be 'xml' or 'text', got {script_format!r}")
    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True)

    if not quiet:
        print(f"Reading {src.name} ({src.stat().st_size/1e6:.1f} MB)...", flush=True)
    t0 = time.time()
    data = load_utf8(src)
    if not quiet:
        print(f"  decoded to {len(data)/1e6:.1f} MB UTF-8 in {time.time()-t0:.1f}s", flush=True)

    t0 = time.time()
    summary = _stream_split(data, out, _SlugTracker(), script_format=script_format)
    if not quiet:
        print(f"  split in {time.time()-t0:.1f}s", flush=True)
        print(
            f"    tables: {len(summary['tables'])}  "
            f"layouts: {len(summary['layouts'])} ({summary['layout_folders']} folders)  "
            f"scripts: {len(summary['scripts'])} ({summary['script_folders']} folders)  "
            f"catalogs: {len(summary['catalogs'])}",
            flush=True,
        )

    sec = _section_sizes(data)
    graph = _graph_stats(data)
    other_counts = {
        "value_lists": _count_in_catalog(data, "ValueListCatalog", "ValueList"),
        "custom_functions": _count_in_catalog(data, "CustomFunctionCatalog", "CustomFunction"),
        "themes": _count_in_catalog(data, "ThemeCatalog", "Theme"),
        "custom_menus": _count_in_catalog(data, "CustomMenuCatalog", "CustomMenu"),
        "privilege_sets": _count_in_catalog(data, "PrivilegesCatalog", "PrivilegeSet"),
        "accounts": _count_in_catalog(data, "AccountCatalog", "Account"),
    }

    flagged_layouts = sorted(
        (
            {"id": r["id"], "name": r["name"], "bytes": r["bytes"], "folder": r["folder"]}
            for r in summary["layouts"]
            if DEBT_RE.search(r["name"])
        ),
        key=lambda x: -x["bytes"],
    )
    flagged_scripts = sorted(
        (
            {"id": r["id"], "name": r["name"], "bytes": r["bytes"], "folder": r["folder"]}
            for r in summary["scripts"]
            if DEBT_RE.search(r["name"])
        ),
        key=lambda x: -x["bytes"],
    )

    metrics = {
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "source_utf16_bytes": src.stat().st_size,
        "source_utf8_bytes": len(data),
        "section_bytes_utf8": sec,
        "counts": {
            "tables": len(summary["tables"]),
            "layouts": len(summary["layouts"]),
            "scripts": len(summary["scripts"]),
            "layout_folders": summary["layout_folders"],
            "script_folders": summary["script_folders"],
            **graph,
            **other_counts,
            "fields_total": sum(t["fields"] for t in summary["tables"]),
            "calc_fields_total": sum(t["calc_fields"] for t in summary["tables"]),
            "unstored_calc_total": sum(t["unstored_calc"] for t in summary["tables"]),
            "records_total": sum(t["records"] for t in summary["tables"]),
        },
        "tables": summary["tables"],
        "scripts": summary["scripts"],
        "layouts": summary["layouts"],
        "scripts_total_bytes": sum(r["bytes"] for r in summary["scripts"]),
        "layouts_total_bytes": sum(r["bytes"] for r in summary["layouts"]),
        "catalog_files": summary["catalogs"],
        "cleanup_candidates": {
            "layouts": flagged_layouts,
            "scripts": flagged_scripts,
            "layouts_total_bytes": sum(r["bytes"] for r in flagged_layouts),
            "scripts_total_bytes": sum(r["bytes"] for r in flagged_scripts),
        },
    }
    (out / "_metrics.json").write_text(json.dumps(metrics, indent=2))
    return metrics
