"""Explode an FMSaveAsXML (whole-file clone) export into a per-object file tree.

Output mirrors the DDR split tree as closely as possible:

    <out>/
      _header.xml             FMSaveAsXML root attributes
      _metrics.json           machine-readable structural metrics
      tables/<slug>.xml       BaseTable + merged FieldCatalog (ObjectList of Fields)
      layouts/<slug>.xml      Layout (already a complete element in LayoutCatalog)
      scripts/<slug>.xml      Script header + merged ObjectList of steps
      catalogs/<name>.xml     whole-document catalogs (TOs, rels, VLs, etc.)

FMSaveAsXML splits tables from their fields and scripts from their steps into
separate sibling sections (FieldsForTables, StepsForScripts). This parser does
a single streaming pass, collecting lightweight header elements (BaseTable attrs,
Script attrs) in memory, then merges them with their content when the content
section arrives.

Differences from DDR split output:
- No script folder hierarchy (FMSaveAsXML ScriptCatalog has no Group elements).
  Pass `from_ddr` to restore folder structure from a prior DDR split.
- No layout folder hierarchy (same reason; also restored via `from_ddr`).
- BaseTable records count is 0 (not included in FMSaveAsXML).
- Whole catalogs differ: TableOccurrenceCatalog, RelationshipCatalog, etc.
  replace RelationshipGraph, ThemeCatalog, etc.
  DDR-only catalogs (accounts, themes, privileges, etc.) are preserved when
  `from_ddr` is supplied.
"""
from __future__ import annotations

import io
import json
import pathlib
import re
import shutil
import time
import xml.etree.ElementTree as ET

from .split import DEBT_RE, XML_DECL, _SlugTracker, _write_element, slugify
from .stream import load_utf8

# Control-byte cleaner (matches the one in index/savexml.py).
_CTRL_BYTES = re.compile(rb"[\x00-\x08\x0B\x0C\x0E-\x1F]")

# Whole-document catalogs written verbatim to catalogs/.
SAVEXML_WHOLE_CATALOGS: dict[str, str] = {
    "TableOccurrenceCatalog": "table-occurrences.xml",
    "RelationshipCatalog":    "relationship-catalog.xml",
    "ValueListCatalog":       "value-lists.xml",
    "CustomFunctionsCatalog": "custom-functions.xml",
    "CalcsForCustomFunctions":"custom-function-calcs.xml",
    "CustomMenuCatalog":      "custom-menus.xml",
    "OptionsForValueLists":   "value-list-options.xml",
}

# The filenames SaveAsXML produces — used to identify DDR-only catalogs to preserve.
_SAVEXML_CATALOG_FILES = frozenset(SAVEXML_WHOLE_CATALOGS.values())

_INDENT_OPEN  = {"If", "Loop"}
_INDENT_CLOSE = {"End If", "End Loop"}
_INDENT_MID   = {"Else", "Else If"}


def _script_to_text(header: ET.Element, obj_list: ET.Element | None) -> str:
    """Render a SaveAsXML script as plain-text for human/agent reading.

    Uses the step `name` attribute for step type and pulls the first
    <Calculation><Text> body as the expression (condition for If, value
    for Set Field, etc.). Indents by control-flow depth.
    """
    name = header.get("name", "")
    sid = header.get("id", "")
    lines: list[str] = [f"# {name} (id={sid})", ""]

    if obj_list is None:
        return "\n".join(lines) + "\n"

    depth = 0
    indent = "    "
    for step in obj_list.findall("Step"):
        step_name = step.get("name", "")
        enabled = step.get("enable", "True") != "False"

        calc_text = ""
        for calc_el in step.iter("Calculation"):
            text_el = calc_el.find("Text")
            if text_el is not None and text_el.text:
                calc_text = text_el.text.strip()
                break

        display = f"{step_name} [ {calc_text} ]" if calc_text else step_name

        line_depth = depth
        if step_name in _INDENT_CLOSE:
            depth = max(0, depth - 1)
            line_depth = depth
        elif step_name in _INDENT_MID:
            line_depth = max(0, depth - 1)

        prefix = indent * line_depth + ("// " if not enabled else "")
        lines.append(prefix + display)

        if step_name in _INDENT_OPEN:
            depth += 1

    return "\n".join(lines) + "\n"


def _write_script_text(path: pathlib.Path, header: ET.Element, obj_list: ET.Element | None) -> int:
    path.parent.mkdir(parents=True, exist_ok=True)
    data = _script_to_text(header, obj_list).encode("utf-8")
    path.write_bytes(data)
    return len(data)


def _walk_split_dir(base: pathlib.Path, root_tag: str) -> dict[str, str]:
    """Walk a DDR split subdirectory and return name→folder for every XML file.

    Reads only the root element of each file (fast — one iterparse start event).
    `folder` is the path from `base` to the file's parent, e.g. "admin/users".
    Root-level files get an empty-string folder.
    """
    result: dict[str, str] = {}
    if not base.is_dir():
        return result
    for xml_file in base.rglob("*.xml"):
        rel_parent = xml_file.parent.relative_to(base)
        folder = "" if str(rel_parent) == "." else str(rel_parent)
        try:
            for _ev, el in ET.iterparse(str(xml_file), events=("start",)):
                name = el.get("name", "")
                if name:
                    result[name] = folder
                break
        except ET.ParseError:
            pass
    return result


def _load_ddr_maps(ddr_split: pathlib.Path) -> tuple[dict[str, str], dict[str, str]]:
    """Build name→folder maps from a DDR split tree.

    Tries _metrics.json first (fast; available in fmddr 0.5.0+ DDR splits).
    Falls back to walking the scripts/ and layouts/ directories directly for
    splits produced by older versions that didn't include those lists.

    Returns (script_folder_map, layout_folder_map) — keyed by object name,
    valued by folder path string (e.g. "admin" or "admin/users"). Root-level
    objects are omitted so the default fallback (root) is used for them.
    """
    metrics_path = ddr_split / "_metrics.json"
    if metrics_path.exists():
        try:
            metrics = json.loads(metrics_path.read_text())
            if "scripts" in metrics and "layouts" in metrics:
                script_map = {
                    r["name"]: r["folder"]
                    for r in metrics["scripts"]
                    if r.get("folder")
                }
                layout_map = {
                    r["name"]: r["folder"]
                    for r in metrics["layouts"]
                    if r.get("folder")
                }
                return script_map, layout_map
        except (json.JSONDecodeError, OSError):
            pass

    # Fallback: walk file tree (older DDR splits without scripts/layouts lists).
    return (
        _walk_split_dir(ddr_split / "scripts", "Script"),
        _walk_split_dir(ddr_split / "layouts", "Layout"),
    )


def _copy_ddr_only_catalogs(
    ddr_split: pathlib.Path,
    out: pathlib.Path,
) -> list[dict]:
    """Copy catalog files from ddr_split/catalogs/ that SaveAsXML doesn't produce.

    Anything not in _SAVEXML_CATALOG_FILES is considered DDR-only (accounts,
    themes, privileges, external data sources, options, relationship graph, etc.)
    and copied verbatim so the output tree stays complete.
    """
    ddr_catalogs = ddr_split / "catalogs"
    if not ddr_catalogs.is_dir():
        return []
    out_catalogs = out / "catalogs"
    out_catalogs.mkdir(parents=True, exist_ok=True)
    copied: list[dict] = []
    for src_file in sorted(ddr_catalogs.iterdir()):
        if src_file.suffix == ".xml" and src_file.name not in _SAVEXML_CATALOG_FILES:
            dest = out_catalogs / src_file.name
            shutil.copy2(src_file, dest)
            copied.append({
                "tag":    "ddr",
                "file":   src_file.name,
                "bytes":  dest.stat().st_size,
                "source": "ddr",
            })
    return copied


def _stream_split(
    data: bytes,
    out: pathlib.Path,
    slugger: _SlugTracker,
    script_format: str = "xml",
    script_folder_map: dict[str, str] | None = None,
    layout_folder_map: dict[str, str] | None = None,
) -> dict:
    """Single streaming pass over UTF-8 SaveAsXML bytes → file tree under `out`."""
    sfmap = script_folder_map or {}
    lfmap = layout_folder_map or {}

    stream = io.BytesIO(data)
    parser = ET.iterparse(stream, events=("start", "end"))

    tag_stack: list[str] = []

    # Section flags
    in_struct_add      = False
    in_basetable_cat   = False
    in_fields_for_tbl  = False
    in_field_catalog   = False
    current_fc_bt_id: int | None = None
    in_script_cat      = False
    in_steps_for_scr   = False
    in_steps_script    = False
    current_steps_sid: int | None = None
    in_layout_cat      = False

    fm_root_attrs: dict[str, str] = {}
    header_written = False

    # In-memory header caches (tiny: attrs-only elements).
    bt_by_id: dict[int, ET.Element]     = {}
    script_by_id: dict[int, ET.Element] = {}

    table_records:   list[dict] = []
    layout_records:  list[dict] = []
    script_records:  list[dict] = []
    catalog_records: list[dict] = []

    for ev, elem in parser:
        tag = elem.tag

        if ev == "start":
            tag_stack.append(tag)
            if tag == "FMSaveAsXML" and not fm_root_attrs:
                fm_root_attrs = dict(elem.attrib)
            elif tag == "AddAction":
                in_struct_add = True
            elif in_struct_add:
                if tag == "BaseTableCatalog":
                    in_basetable_cat = True
                elif tag == "FieldsForTables":
                    in_fields_for_tbl = True
                elif tag == "FieldCatalog" and in_fields_for_tbl:
                    in_field_catalog = True
                    current_fc_bt_id = None
                elif tag == "ScriptCatalog":
                    in_script_cat = True
                elif tag == "StepsForScripts":
                    in_steps_for_scr = True
                elif tag == "Script" and in_steps_for_scr:
                    in_steps_script = True
                    current_steps_sid = None
                elif tag == "LayoutCatalog":
                    in_layout_cat = True
            continue

        # ── end events ──────────────────────────────────────────────────────
        parent = tag_stack[-2] if len(tag_stack) >= 2 else None

        # ── BaseTables (header only; fields come later in FieldsForTables) ──
        if tag == "BaseTable" and in_basetable_cat:
            raw = elem.get("id")
            if raw and raw.isdigit():
                bt_by_id[int(raw)] = elem  # hold ref; do NOT clear

        elif tag == "BaseTableCatalog" and in_basetable_cat:
            in_basetable_cat = False
            elem.clear()

        # ── FieldCatalog: merge with BaseTable header and write ──────────────
        elif tag == "BaseTableReference" and in_field_catalog and current_fc_bt_id is None:
            raw = elem.get("id")
            if raw and raw.isdigit():
                current_fc_bt_id = int(raw)

        elif tag == "FieldCatalog" and in_field_catalog:
            if current_fc_bt_id is not None:
                header = bt_by_id.pop(current_fc_bt_id, None)
                if header is not None:
                    merged = ET.Element("BaseTable", header.attrib)
                    merged.append(elem)
                    name  = header.get("name", "")
                    slug  = slugify(name)
                    fname = slugger.unique(out / "tables", slug)
                    size  = _write_element(out / "tables" / fname, merged)
                    fields = elem.findall("ObjectList/Field")
                    table_records.append({
                        "id":            int(header.get("id", "0")),
                        "name":          name,
                        "records":       0,
                        "fields":        len(fields),
                        "calc_fields":   sum(
                            1 for f in fields if f.get("fieldtype") == "Calculated"
                        ),
                        "unstored_calc": sum(
                            1 for f in fields
                            if f.get("fieldtype") == "Calculated"
                            and f.find("Storage") is not None
                            and (f.find("Storage") or ET.Element("_")).get(
                                "storeCalculationResults"
                            ) == "False"
                        ),
                        "summary_fields": sum(
                            1 for f in fields if f.get("fieldtype") == "Summary"
                        ),
                        "bytes": size,
                        "file":  fname,
                    })
            in_field_catalog = False
            current_fc_bt_id = None
            elem.clear()

        elif tag == "FieldsForTables" and in_fields_for_tbl:
            in_fields_for_tbl = False
            elem.clear()

        # ── Script headers (names/ids only; steps come later) ────────────────
        elif tag == "Script" and in_script_cat and not in_steps_for_scr:
            raw = elem.get("id")
            if raw and raw.isdigit():
                script_by_id[int(raw)] = elem  # hold ref; do NOT clear

        elif tag == "ScriptCatalog" and in_script_cat:
            in_script_cat = False
            elem.clear()

        # ── StepsForScripts: merge with Script header and write ──────────────
        elif tag == "ScriptReference" and in_steps_script and current_steps_sid is None:
            raw = elem.get("id")
            if raw and raw.isdigit():
                current_steps_sid = int(raw)

        elif tag == "Script" and in_steps_script:
            if current_steps_sid is not None:
                header = script_by_id.pop(current_steps_sid, None)
                if header is not None:
                    name     = header.get("name", "")
                    slug     = slugify(name)
                    ddr_folder = sfmap.get(name, "")
                    folder   = out / "scripts" / ddr_folder if ddr_folder else out / "scripts"
                    obj_list = elem.find("ObjectList")
                    if script_format == "text":
                        fname = slugger.unique(folder, slug, ext=".txt")
                        size  = _write_script_text(folder / fname, header, obj_list)
                    else:
                        merged = ET.Element("Script", header.attrib)
                        if obj_list is not None:
                            merged.append(obj_list)
                        fname = slugger.unique(folder, slug)
                        size  = _write_element(folder / fname, merged)
                    script_records.append({
                        "id":     int(header.get("id", "0")),
                        "name":   name,
                        "folder": ddr_folder,
                        "bytes":  size,
                        "file":   str(pathlib.Path(ddr_folder) / fname),
                    })
            in_steps_script   = False
            current_steps_sid = None
            elem.clear()

        elif tag == "StepsForScripts" and in_steps_for_scr:
            in_steps_for_scr = False
            # Flush scripts that had no matching entry in StepsForScripts.
            for raw_id, hdr in list(script_by_id.items()):
                name       = hdr.get("name", "")
                slug       = slugify(name)
                ddr_folder = sfmap.get(name, "")
                folder     = out / "scripts" / ddr_folder if ddr_folder else out / "scripts"
                if script_format == "text":
                    fname = slugger.unique(folder, slug, ext=".txt")
                    size  = _write_script_text(folder / fname, hdr, None)
                else:
                    fname = slugger.unique(folder, slug)
                    size  = _write_element(folder / fname, hdr)
                script_records.append({
                    "id":     int(hdr.get("id", "0")),
                    "name":   name,
                    "folder": ddr_folder,
                    "bytes":  size,
                    "file":   str(pathlib.Path(ddr_folder) / fname),
                })
            script_by_id.clear()
            elem.clear()

        # ── Layouts (complete inline in LayoutCatalog) ───────────────────────
        elif tag == "Layout" and in_layout_cat:
            name       = elem.get("name", "")
            slug       = slugify(name)
            ddr_folder = lfmap.get(name, "")
            folder     = out / "layouts" / ddr_folder if ddr_folder else out / "layouts"
            fname      = slugger.unique(folder, slug)
            size       = _write_element(folder / fname, elem)
            layout_records.append({
                "id":     int(elem.get("id", "0")),
                "name":   name,
                "folder": ddr_folder,
                "bytes":  size,
                "file":   str(pathlib.Path(ddr_folder) / fname),
            })
            elem.clear()

        elif tag == "LayoutCatalog" and in_layout_cat:
            in_layout_cat = False
            elem.clear()

        # ── Whole catalogs (direct children of AddAction) ────────────────────
        elif tag in SAVEXML_WHOLE_CATALOGS and parent == "AddAction":
            fname = SAVEXML_WHOLE_CATALOGS[tag]
            size  = _write_element(out / "catalogs" / fname, elem)
            catalog_records.append({"tag": tag, "file": fname, "bytes": size})
            elem.clear()

        elif tag == "AddAction" and in_struct_add:
            in_struct_add = False
            # Flush any BaseTables that somehow had no FieldCatalog.
            for raw_id, hdr in list(bt_by_id.items()):
                name  = hdr.get("name", "")
                slug  = slugify(name)
                fname = slugger.unique(out / "tables", slug)
                size  = _write_element(out / "tables" / fname, hdr)
                table_records.append({
                    "id": int(hdr.get("id", "0")), "name": name, "records": 0,
                    "fields": 0, "calc_fields": 0, "unstored_calc": 0,
                    "summary_fields": 0, "bytes": size, "file": fname,
                })
            bt_by_id.clear()
            elem.clear()

        # ── Header: write as soon as we have root attrs ──────────────────────
        if not header_written and fm_root_attrs:
            root = ET.Element("FMSaveAsXML", fm_root_attrs)
            root.text = (
                "\n  <!-- catalogs split into ./catalogs/, ./tables/, "
                "./layouts/, ./scripts/ -->\n"
            )
            (out / "_header.xml").write_bytes(
                (XML_DECL + ET.tostring(root, encoding="unicode") + "\n").encode("utf-8")
            )
            header_written = True

        tag_stack.pop()

    return {
        "tables":         table_records,
        "layouts":        layout_records,
        "scripts":        script_records,
        "catalogs":       catalog_records,
        "script_folders": len({r["folder"] for r in script_records if r["folder"]}),
        "layout_folders": len({r["folder"] for r in layout_records if r["folder"]}),
    }


def _count_in_section(data: bytes, section_tag: str, child_tag: str) -> int:
    cs = data.find(f"<{section_tag}".encode())
    ce = data.find(f"</{section_tag}>".encode())
    if cs < 0 or ce <= cs:
        return 0
    return len(re.findall(rb"<" + child_tag.encode() + rb"\b[^>]*\bid=", data[cs:ce]))


def _section_sizes(data: bytes) -> dict[str, int]:
    sections = [
        "BaseTableCatalog", "FieldsForTables", "ScriptCatalog", "StepsForScripts",
        "LayoutCatalog", "TableOccurrenceCatalog", "RelationshipCatalog",
        "ValueListCatalog", "CustomFunctionsCatalog", "CustomMenuCatalog",
    ]
    out: dict[str, int] = {}
    for s in sections:
        i = data.find(f"<{s}".encode())
        j = data.find(f"</{s}>".encode())
        out[s] = (j - i + len(f"</{s}>".encode())) if (i >= 0 and j > i) else 0
    return out


def split_savexml(
    src: pathlib.Path,
    out: pathlib.Path,
    *,
    quiet: bool = False,
    script_format: str = "xml",
    from_ddr: pathlib.Path | None = None,
) -> dict:
    """Decode `src` (FMSaveAsXML), explode it into `out`, write `_metrics.json`.

    `out` is wiped first so deletions propagate cleanly on re-run.
    `script_format` is 'xml' (default) or 'text' (lossy, read-only).
    `from_ddr` is the path to a previously-run DDR split tree. When supplied:
      - Script/layout folder structure is restored from that tree's _metrics.json
        (matched by name; unmatched objects land at the root level).
      - DDR-only catalog files (accounts, themes, privileges, external data
        sources, relationship graph, options) are copied verbatim from that
        tree into the new output's catalogs/ directory.
    """
    if script_format not in ("xml", "text"):
        raise ValueError(f"script_format must be 'xml' or 'text', got {script_format!r}")

    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True)

    script_folder_map: dict[str, str] = {}
    layout_folder_map: dict[str, str] = {}
    if from_ddr is not None:
        script_folder_map, layout_folder_map = _load_ddr_maps(from_ddr)
        if not quiet:
            n_sf = len(script_folder_map)
            n_lf = len(layout_folder_map)
            print(
                f"  DDR folder map loaded: {n_sf} script folder entries, "
                f"{n_lf} layout folder entries",
                flush=True,
            )

    if not quiet:
        print(f"Reading {src.name} ({src.stat().st_size / 1e6:.1f} MB)...", flush=True)
    t0 = time.time()
    raw  = load_utf8(src)
    data = _CTRL_BYTES.sub(b"", raw)
    if not quiet:
        print(
            f"  decoded + cleaned to {len(data) / 1e6:.1f} MB UTF-8 "
            f"in {time.time() - t0:.1f}s",
            flush=True,
        )

    t0 = time.time()
    summary = _stream_split(
        data, out, _SlugTracker(),
        script_format=script_format,
        script_folder_map=script_folder_map,
        layout_folder_map=layout_folder_map,
    )
    if not quiet:
        print(f"  split in {time.time() - t0:.1f}s", flush=True)
        print(
            f"    tables: {len(summary['tables'])}  "
            f"layouts: {len(summary['layouts'])} ({summary['layout_folders']} folders)  "
            f"scripts: {len(summary['scripts'])} ({summary['script_folders']} folders)  "
            f"catalogs: {len(summary['catalogs'])}",
            flush=True,
        )

    # Copy DDR-only catalog files (accounts, themes, privileges, etc.).
    ddr_catalog_records: list[dict] = []
    if from_ddr is not None:
        ddr_catalog_records = _copy_ddr_only_catalogs(from_ddr, out)
        if not quiet and ddr_catalog_records:
            names = ", ".join(r["file"] for r in ddr_catalog_records)
            print(f"  preserved {len(ddr_catalog_records)} DDR-only catalog(s): {names}", flush=True)

    sec = _section_sizes(data)
    other_counts = {
        "table_occurrences": _count_in_section(data, "TableOccurrenceCatalog", "TableOccurrence"),
        "relationships":     _count_in_section(data, "RelationshipCatalog",    "Relationship"),
        "value_lists":       _count_in_section(data, "ValueListCatalog",       "ValueList"),
        "custom_functions":  _count_in_section(data, "CustomFunctionsCatalog", "CustomFunction"),
        "custom_menus":      _count_in_section(data, "CustomMenuCatalog",      "CustomMenu"),
    }

    flagged_layouts = sorted(
        (
            {"id": r["id"], "name": r["name"], "bytes": r["bytes"], "folder": r["folder"]}
            for r in summary["layouts"]
            if DEBT_RE.search(r["name"])
        ),
        key=lambda x: -x["bytes"],
    )
    flagged_scripts = sorted(
        (
            {"id": r["id"], "name": r["name"], "bytes": r["bytes"], "folder": r["folder"]}
            for r in summary["scripts"]
            if DEBT_RE.search(r["name"])
        ),
        key=lambda x: -x["bytes"],
    )

    all_catalog_files = summary["catalogs"] + ddr_catalog_records
    metrics = {
        "generated_at":       time.strftime("%Y-%m-%dT%H:%M:%S"),
        "source_format":      "savexml",
        "ddr_ref":            str(from_ddr) if from_ddr else None,
        "source_utf16_bytes": src.stat().st_size,
        "source_utf8_bytes":  len(data),
        "section_bytes_utf8": sec,
        "counts": {
            "tables":          len(summary["tables"]),
            "layouts":         len(summary["layouts"]),
            "scripts":         len(summary["scripts"]),
            "layout_folders":  summary["layout_folders"],
            "script_folders":  summary["script_folders"],
            **other_counts,
            "fields_total":        sum(t["fields"]       for t in summary["tables"]),
            "calc_fields_total":   sum(t["calc_fields"]  for t in summary["tables"]),
            "unstored_calc_total": sum(t["unstored_calc"] for t in summary["tables"]),
        },
        "tables":               summary["tables"],
        "scripts_total_bytes":  sum(r["bytes"] for r in summary["scripts"]),
        "layouts_total_bytes":  sum(r["bytes"] for r in summary["layouts"]),
        "catalog_files":        all_catalog_files,
        "cleanup_candidates": {
            "layouts":             flagged_layouts,
            "scripts":             flagged_scripts,
            "layouts_total_bytes": sum(r["bytes"] for r in flagged_layouts),
            "scripts_total_bytes": sum(r["bytes"] for r in flagged_scripts),
        },
    }
    (out / "_metrics.json").write_text(json.dumps(metrics, indent=2))
    return metrics
