"""Relationship graph queries — TOs, relationships, predicates, paths."""
from __future__ import annotations

import re
import sqlite3
from collections import defaultdict, deque


def list_tos(
    conn: sqlite3.Connection, *, base_table_id: int | None = None
) -> list[dict]:
    sql = (
        "SELECT toc.id, toc.name, toc.color, "
        "       toc.base_table_id, bt.name AS base_table_name "
        "FROM table_occurrence toc "
        "LEFT JOIN base_table bt ON bt.id = toc.base_table_id"
    )
    args: list = []
    if base_table_id is not None:
        sql += " WHERE toc.base_table_id = ?"
        args.append(base_table_id)
    sql += " ORDER BY toc.name"
    return [dict(r) for r in conn.execute(sql, args).fetchall()]


def list_relationships(conn: sqlite3.Connection) -> list[dict]:
    rows = conn.execute(
        "SELECT r.id, "
        "       lt.name AS left_to, rt.name AS right_to, "
        "       (SELECT COUNT(*) FROM join_predicate jp WHERE jp.relationship_id=r.id) AS predicate_count "
        "FROM relationship r "
        "JOIN table_occurrence lt ON lt.id = r.left_to_id "
        "JOIN table_occurrence rt ON rt.id = r.right_to_id "
        "ORDER BY lt.name, rt.name"
    ).fetchall()
    return [dict(r) for r in rows]


def predicates_for(conn: sqlite3.Connection, relationship_id: int) -> list[dict]:
    rows = conn.execute(
        "SELECT jp.operator, "
        "       lf.name AS left_field, lbt.name AS left_table, "
        "       rf.name AS right_field, rbt.name AS right_table "
        "FROM join_predicate jp "
        "LEFT JOIN field lf ON lf.id = jp.left_field_id "
        "LEFT JOIN base_table lbt ON lbt.id = lf.base_table_id "
        "LEFT JOIN field rf ON rf.id = jp.right_field_id "
        "LEFT JOIN base_table rbt ON rbt.id = rf.base_table_id "
        "WHERE jp.relationship_id = ?",
        (relationship_id,),
    ).fetchall()
    return [dict(r) for r in rows]


def to_path(
    conn: sqlite3.Connection, from_to_id: int, to_to_id: int, *, max_hops: int = 6
) -> list[dict] | None:
    """Shortest TO→TO path through relationships. Undirected. Returns the
    list of TO ids/names along the path, or None if unreachable.
    """
    adj: dict[int, set[int]] = defaultdict(set)
    for left, right in conn.execute("SELECT left_to_id, right_to_id FROM relationship"):
        adj[left].add(right)
        adj[right].add(left)
    if from_to_id not in adj and from_to_id != to_to_id:
        return None
    seen = {from_to_id}
    parent: dict[int, int] = {}
    q = deque([(from_to_id, 0)])
    while q:
        cur, d = q.popleft()
        if cur == to_to_id:
            # reconstruct
            path = [cur]
            while path[-1] in parent:
                path.append(parent[path[-1]])
            path.reverse()
            names = {
                r[0]: r[1]
                for r in conn.execute(
                    "SELECT id,name FROM table_occurrence WHERE id IN ("
                    + ",".join("?" for _ in path) + ")",
                    tuple(path),
                )
            }
            return [{"id": tid, "name": names.get(tid)} for tid in path]
        if d >= max_hops:
            continue
        for n in adj[cur]:
            if n not in seen:
                seen.add(n)
                parent[n] = cur
                q.append((n, d + 1))
    return None


# ---------------------------------------------------------------------------
# ERD — base-table level Mermaid erDiagram
# ---------------------------------------------------------------------------

def _mermaid_safe(name: str) -> str:
    """Return a Mermaid-safe identifier (alphanumeric + underscore only)."""
    return re.sub(r"[^A-Za-z0-9_]", "_", name)


_FM_TYPE_MAP = {
    "Text": "string",
    "Number": "number",
    "Date": "date",
    "Time": "time",
    "Timestamp": "datetime",
    "Container": "blob",
    "Calculation": "calc",
    "Summary": "summary",
}


def erd_mermaid(
    conn: sqlite3.Connection,
    *,
    focus_table: str | None = None,
    all_fields: bool = False,
) -> str:
    """Return a Mermaid erDiagram string.

    By default shows only PK/FK fields (fields referenced in join predicates,
    plus fields whose names match common PK patterns). Pass all_fields=True
    for every field. If focus_table is given, restrict to that base table and
    its direct neighbours (one hop through relationships).
    """
    # Resolve focus base table if requested
    focus_bt_id: int | None = None
    if focus_table is not None:
        row = conn.execute(
            "SELECT id FROM base_table WHERE name = ? COLLATE NOCASE", (focus_table,)
        ).fetchone()
        if row is None:
            raise ValueError(f"Base table {focus_table!r} not found")
        focus_bt_id = row[0]

    # All base tables (filtered to focus neighbourhood if requested)
    if focus_bt_id is None:
        bt_rows = conn.execute("SELECT id, name FROM base_table ORDER BY name").fetchall()
    else:
        bt_rows = conn.execute(
            """
            SELECT DISTINCT bt.id, bt.name FROM base_table bt
            WHERE bt.id = ?
            UNION
            SELECT DISTINCT bt.id, bt.name FROM base_table bt
            JOIN table_occurrence toc ON toc.base_table_id = bt.id
            JOIN relationship r ON r.left_to_id = toc.id OR r.right_to_id = toc.id
            JOIN table_occurrence toc2 ON (
                toc2.id = CASE WHEN r.left_to_id = toc.id THEN r.right_to_id
                               ELSE r.left_to_id END
            )
            WHERE toc2.base_table_id = ?
            ORDER BY bt.name
            """,
            (focus_bt_id, focus_bt_id),
        ).fetchall()

    bt_ids = {r[0] for r in bt_rows}
    bt_name: dict[int, str] = {r[0]: r[1] for r in bt_rows}

    # Fields involved in join predicates (FK fields)
    fk_field_ids: set[int] = set()
    for fid in conn.execute(
        "SELECT DISTINCT left_field_id FROM join_predicate WHERE left_field_id IS NOT NULL"
    ).fetchall():
        fk_field_ids.add(fid[0])
    for fid in conn.execute(
        "SELECT DISTINCT right_field_id FROM join_predicate WHERE right_field_id IS NOT NULL"
    ).fetchall():
        fk_field_ids.add(fid[0])

    pk_pattern = re.compile(r"(?i)(^id$|_id$|__pk__|_pk$|__uid__|_uid$)")

    fields_sql = (
        "SELECT id, base_table_id, name, data_type, field_type "
        "FROM field WHERE base_table_id IN ("
        + ",".join("?" for _ in bt_ids)
        + ") ORDER BY base_table_id, name"
    )
    field_rows = conn.execute(fields_sql, list(bt_ids)).fetchall()

    fields_by_bt: dict[int, list[tuple]] = defaultdict(list)
    for fid, bt_id, fname, dtype, ftype in field_rows:
        if all_fields:
            fields_by_bt[bt_id].append((fid, fname, dtype, ftype))
        elif fid in fk_field_ids or pk_pattern.search(fname):
            fields_by_bt[bt_id].append((fid, fname, dtype, ftype))

    # Relationships — collapse TO pairs to base-table pairs, deduplicate
    rel_rows = conn.execute(
        """
        SELECT r.id,
               lt.base_table_id AS left_bt,
               rt.base_table_id AS right_bt,
               r.allow_create_right,
               r.allow_delete_right,
               r.allow_create_left,
               r.allow_delete_left
        FROM relationship r
        JOIN table_occurrence lt ON lt.id = r.left_to_id
        JOIN table_occurrence rt ON rt.id = r.right_to_id
        WHERE lt.base_table_id IN ({ids}) AND rt.base_table_id IN ({ids})
        """.format(ids=",".join("?" for _ in bt_ids)),
        list(bt_ids) * 2,
    ).fetchall()

    BTPair = tuple  # (min_id, max_id)
    pair_predicates: dict[tuple, list[str]] = defaultdict(list)
    pair_flags: dict[tuple, dict] = {}

    for rid, left_bt, right_bt, ac_r, ad_r, ac_l, ad_l in rel_rows:
        if left_bt is None or right_bt is None:
            continue
        if left_bt == right_bt:
            continue  # self-join — skip for clarity
        canonical = (min(left_bt, right_bt), max(left_bt, right_bt))
        if canonical not in pair_flags:
            pair_flags[canonical] = {
                "left_bt": left_bt, "right_bt": right_bt,
                "allow_create_right": ac_r, "allow_delete_right": ad_r,
                "allow_create_left": ac_l, "allow_delete_left": ad_l,
            }
        preds = conn.execute(
            "SELECT lf.name, rf.name FROM join_predicate jp "
            "LEFT JOIN field lf ON lf.id = jp.left_field_id "
            "LEFT JOIN field rf ON rf.id = jp.right_field_id "
            "WHERE jp.relationship_id = ?",
            (rid,),
        ).fetchall()
        for lname, rname in preds:
            if lname and rname and lname != rname:
                pair_predicates[canonical].append(f"{lname}={rname}")
            elif lname:
                pair_predicates[canonical].append(lname)

    # Build Mermaid output
    lines: list[str] = ["erDiagram"]

    for bt_id, name in sorted(bt_name.items(), key=lambda x: x[1]):
        safe = _mermaid_safe(name)
        flist = fields_by_bt.get(bt_id, [])
        lines.append(f"    {safe} {{")
        for _fid, fname, dtype, _ftype in flist:
            mtype = _FM_TYPE_MAP.get(dtype, dtype.lower() if dtype else "text")
            safe_fname = _mermaid_safe(fname)
            if pk_pattern.search(fname):
                lines.append(f"        {mtype} {safe_fname} PK")
            elif _fid in fk_field_ids:
                lines.append(f"        {mtype} {safe_fname} FK")
            else:
                lines.append(f"        {mtype} {safe_fname}")
        lines.append("    }")

    seen_pairs: set[tuple] = set()
    for canonical, flags in pair_flags.items():
        if canonical in seen_pairs:
            continue
        seen_pairs.add(canonical)

        left_bt = flags["left_bt"]
        right_bt = flags["right_bt"]
        left_name = _mermaid_safe(bt_name[left_bt])
        right_name = _mermaid_safe(bt_name[right_bt])

        left_card = "o{" if flags.get("allow_create_right") else "||"
        right_card = "}o" if flags.get("allow_create_left") else "||"

        preds = pair_predicates.get(canonical, [])
        unique_preds = list(dict.fromkeys(preds))
        label = ", ".join(unique_preds[:3])
        if len(unique_preds) > 3:
            label += f" +{len(unique_preds) - 3}"
        if not label:
            label = "relates"

        lines.append(f'    {left_name} {left_card}--{right_card} {right_name} : "{label}"')

    return "\n".join(lines)
