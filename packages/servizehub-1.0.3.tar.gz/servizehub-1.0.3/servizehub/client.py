# servizehub/client.py
import httpx
from datetime import datetime


class VendorClient:
    def __init__(self, api_key: str):
        if not api_key:
            raise ValueError("API key is required")

        self.api_key = api_key
        self.base_url = "https://servizehubuserdev.notasco.in"
        self.headers = {
            "Content-Type": "application/json",
            "servizhub-api-key": self.api_key,
        }

    # Validate date format YYYY-MM-DD
    def _is_valid_date(self, date: str) -> bool:
        try:
            datetime.strptime(date, "%Y-%m-%d")
            return True
        except ValueError:
            return False

    async def send_booking(self, date: str, service_type: str, status: str):
        # local validation returns
        if not date or not service_type or not status:
            return "All booking details are required"

        if not self._is_valid_date(date):
            return "Invalid date format, expected YYYY-MM-DD"

        valid_statuses = ["available", "unavailable"]
        if status not in valid_statuses:
            return "Invalid status value"

        url = f"{self.base_url}/external/capture-availability"

        try:
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    url,
                    json={
                        "date": date,
                        "serviceType": service_type,
                        "status": status,
                    },
                    headers=self.headers,
                )

            try:
                data = response.json()
            except Exception:
                data = {"message": "Invalid response from server"}

            return {
                "statusCode": response.status_code,
                "data": data,
            }

        except Exception as e:
            return str(e)

    async def send_multiple_bookings(self, bookings: list):
        if not isinstance(bookings, list) or not bookings:
            return "Bookings array is required"

        failed_bookings = []
        successful_bookings = []

        for booking in bookings:
            result = await self.send_booking(
                booking.get("date"),
                booking.get("serviceType"),
                booking.get("status"),
            )

            # local validation / network errors
            if isinstance(result, str):
                failed_bookings.append({
                    **booking,
                    "error": result
                })
                continue

            # API failed response
            if (
                "statusCode" not in result
                or result["statusCode"] >= 400
            ):
                failed_bookings.append({
                    **booking,
                    "error": result
                })
            else:
                successful_bookings.append(result)

        return {
            "message": (
                "All bookings sent successfully"
                if not failed_bookings
                else "Some bookings failed"
            ),
            "successfulBookings": successful_bookings,
            "failedBookings": failed_bookings,
        }