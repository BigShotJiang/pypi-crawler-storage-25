"""``sirb deploy`` — bring up either a node or a whole gateway.

Two subcommands, two very different lifecycles:

    sirb deploy node        # run a node-agent on this machine (wraps install.sh)
    sirb deploy gateway     # bootstrap a brand-new Sirb gateway on Fly.io

`node` is what most people want — turn a laptop or workstation into a
contributor in one command. It's a thin wrapper around the canonical
landing/install.sh: same flags, same end state, but invoked through the
CLI you already have configured.

`gateway` is for someone standing up their *own* Sirb network (a
fork, a private deployment, a stage env). It generates the Fly secrets,
creates the app + Postgres, deploys, runs migrations, and mints a
bootstrap admin key — all the runbook §2 steps in one command. Requires
flyctl on PATH and an authenticated session.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

import httpx
import typer
from rich import print as rprint
from rich.console import Console
from rich.prompt import Confirm

from sirb_cli.config import env_override_or_config
from sirb_cli.update_check import print_cli_update_advisory_if_outdated

app = typer.Typer(
    invoke_without_command=False,
    no_args_is_help=True,
    help="Deploy a node on this machine, or a brand-new gateway on Fly.io.",
)

console = Console()

# Default image references for `sirb deploy node` and `sirb deploy gateway`.
#
# We track `:latest` rather than a pinned version. The publish workflows
# (.github/workflows/publish-{node,gateway}-image.yml) rebuild `:latest` on
# every push to main, so users always pull the current state of the network's
# canonical build. Operators who want reproducible deploys can pin to a
# specific tag via `--image ghcr.io/ammarwa/sirb-<service>:vX.Y.Z`.
DEFAULT_NODE_IMAGE = "ghcr.io/ammarwa/sirb-node:latest"
DEFAULT_GATEWAY_IMAGE = "ghcr.io/ammarwa/sirb-gateway:latest"


# ─────────────────────────── node ──────────────────────────────────


@app.command("node")
def node(
    # `--gateway` is the Sirb gateway URL. Was `--backend/-b` in <=0.2.x;
    # renamed in 0.3.0 because `--backend` is now the model-runner choice
    # (ollama vs llama-cpp), and the old name was a constant source of
    # "Sirb backend? OpenAI-compat backend? llama backend?" confusion.
    gateway: str | None = typer.Option(
        None, "--gateway", "-g",
        help="Sirb gateway URL. Defaults to your `sirb login` base_url, which itself defaults to https://api.sirb.run.",
    ),
    # NEW in 0.3.0 — required, no default. Picks the inference runner the
    # container will use. `mock` is a test-stack-only backend and is NOT
    # exposed here on purpose: previously the deploy default was mock,
    # which silently echoed prompts back to clients when operators
    # advertised real model ids like `hf.co/...` or `gemma4:e4b`.
    model_backend: str = typer.Option(
        ..., "--backend", "-b",
        case_sensitive=False,
        help=(
            "Inference backend the node will run. Required (no default).\n\n"
            "  ollama     — proxy to a host-local Ollama daemon. Each --models "
            "entry must be a tag you've already `ollama pull`-ed. Easiest path "
            "for serving multiple real models. Defaults to "
            "http://host.docker.internal:11434; override with --ollama-url.\n"
            "  llama-cpp  — load a GGUF file directly via llama-cpp-python. "
            "One model per container. Requires --llama-model-path."
        ),
    ),
    ollama_url: str = typer.Option(
        "http://host.docker.internal:11434", "--ollama-url",
        help=(
            "URL of the Ollama daemon the container will proxy to. The default "
            "(`host.docker.internal`) reaches the host from inside Docker "
            "Desktop on macOS/Windows. On Linux bare-metal use "
            "`http://172.17.0.1:11434` (default docker bridge) or run Ollama "
            "in a sibling container. Ignored when --backend != ollama."
        ),
    ),
    llama_model_path: str | None = typer.Option(
        None, "--llama-model-path",
        help=(
            "Path to a GGUF file on the host. Required when --backend=llama-cpp. "
            "Mounted into the container at the same path. Ignored otherwise."
        ),
    ),
    signing_secret: str | None = typer.Option(
        None, "--signing-secret", "-s",
        envvar="SIRB_SIGNING_SECRET",
        help=(
            "Legacy HMAC admission secret for self-hosted gateways that don't "
            "accept Bearer auth on /nodes/register. api.sirb.run accepts your "
            "--api-key directly, so most users don't need this. Generate one "
            "with `sirb signing-secret new` only if you're standing up your "
            "own gateway."
        ),
    ),
    api_key: str | None = typer.Option(
        None, "--api-key", "-k",
        help="Reuse an existing API key instead of minting one. Defaults to your `sirb login` key.",
    ),
    wallet: str | None = typer.Option(
        None, "--wallet", "-w",
        help=(
            "0x-prefixed wallet for on-chain rewards. Optional: when omitted, the installer "
            "generates an off-chain identifier (works for testnet, can't claim chain rewards). "
            "To use a real Ethereum wallet, pass its address here. To mint an off-chain "
            "wallet without running the installer, see `sirb wallet new`."
        ),
    ),
    models: str | None = typer.Option(
        None, "--models", "-m",
        help=(
            "Comma-separated model ids this node will advertise. With "
            "--backend=ollama, each entry must already be `ollama pull`-ed "
            "(e.g. `gemma2:2b,qwen2.5:0.5b`, or `hf.co/<repo>:<quant>` for "
            "Hugging Face GGUFs). With --backend=llama-cpp, one model id "
            "matching the file at --llama-model-path."
        ),
    ),
    no_sharding: bool = typer.Option(
        False, "--no-sharding/--allow-sharding",
        help=(
            "Sharded-model fan-out (MoE / pipeline / tensor parallel). "
            "Default is OPTED-IN: every node joins the sharding pool unless "
            "you pass --no-sharding to explicitly opt out. Opting out means "
            "you only serve single-node-topology models and earn correspondingly less."
        ),
    ),
    name: str = typer.Option(
        "sirb-node", "--name", "-n",
        help="Docker container name (default: sirb-node).",
    ),
    image: str = typer.Option(
        DEFAULT_NODE_IMAGE, "--image", "-i",
        envvar="SIRB_NODE_IMAGE",
        help=(
            f"Node-agent image to run. Default: {DEFAULT_NODE_IMAGE} — "
            "tracks the latest build from main. Override with a specific "
            "tag (e.g. ghcr.io/ammarwa/sirb-node:v0.2.0) for a reproducible deploy."
        ),
    ),
    # Resource budget — left as `None` means "let install.sh auto-detect
    # from this host". Set any of them to declare a cap explicitly.
    cpu_cores: int | None = typer.Option(
        None, "--cpu-cores",
        help="Cap container to N CPU cores (Docker --cpus). Omitted = no cap, container can use every host core.",
    ),
    ram_gb: int | None = typer.Option(
        None, "--ram-gb",
        help="Cap container memory to N GB (Docker --memory + --memory-swap). Omitted = no cap.",
    ),
    gpu_count: int | None = typer.Option(
        None, "--gpu-count",
        help=(
            "How many NVIDIA GPUs to expose. "
            "Omitted (default) = `--gpus all` if nvidia-smi finds any, otherwise CPU-only. "
            "0 = force CPU-only even on a GPU host. "
            "N > 0 = `--gpus count=N` (requires NVIDIA container runtime)."
        ),
    ),
    gpu_percent: int | None = typer.Option(
        None, "--gpu-percent",
        help="1-100, fraction of GPU compute Sirb may use. Advisory unless NVIDIA MPS is configured on the host.",
    ),
    vram_gb: float | None = typer.Option(
        None, "--vram-gb",
        help="VRAM advertised in the registration claim. Auto-detected from nvidia-smi when --gpu-count is omitted.",
    ),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip the confirmation prompt."),
) -> None:
    """Run a node-agent on this machine.

    Required flags:
      --backend / -b   ollama or llama-cpp (no default — see below)
      --models / -m    comma-separated model ids the node will advertise

    Optional:
      --signing-secret   omit for key-only setup (no node registered)
      --wallet           omit; uses the wallet bound to your API key
      --gateway / -g     defaults to your `sirb login` base_url
    """
    cfg = env_override_or_config()
    backend_url = (gateway or cfg.base_url).rstrip("/")
    used_api_key = api_key or cfg.api_key

    # Validate --backend choice. typer doesn't expose Choice for plain str
    # options so we check manually. The set is intentionally small —
    # "mock" is omitted (test-stack-only; see deploy_node.run for why).
    model_backend = model_backend.lower()
    if model_backend not in ("ollama", "llama-cpp"):
        rprint(
            f"[red]Invalid --backend: {model_backend!r}[/red]\n"
            "Pick one:\n"
            "  --backend ollama     (recommended; multi-model via a host-local Ollama daemon)\n"
            "  --backend llama-cpp  (one GGUF model, loaded in-process)"
        )
        raise typer.Exit(code=2)

    # Backend-specific preflight. We want to fail BEFORE pulling the
    # image or starting the tunnel so the operator's not staring at a
    # half-deployed container when they realize they forgot a flag.
    if model_backend == "llama-cpp":
        if not llama_model_path:
            rprint("[red]--backend=llama-cpp requires --llama-model-path /path/to/model.gguf[/red]")
            raise typer.Exit(code=2)
        if not Path(llama_model_path).is_file():
            rprint(f"[red]--llama-model-path does not exist or is not a file: {llama_model_path}[/red]")
            raise typer.Exit(code=2)
    elif model_backend == "ollama":
        if not models:
            rprint(
                "[red]--backend=ollama requires --models <id>[,...][/red] — each "
                "entry is the Ollama tag the container will proxy to."
            )
            raise typer.Exit(code=2)
        # Note: the actual ollama-pulled-tags probe is deferred until
        # immediately before the confirm prompt — otherwise the warning
        # scrolls off above 20+ lines of deploy preview and operators
        # on small terminals miss it.

    if not used_api_key:
        rprint("[red]No API key available.[/red] Run `sirb login` first, or pass `--api-key`.")
        raise typer.Exit(code=1)

    # Pre-flight: only docker is required for the native-Python path.
    if not shutil.which("docker"):
        rprint("[red]docker not found.[/red] "
               "Install Docker Desktop (Windows/macOS) or docker-engine (Linux) and retry.")
        raise typer.Exit(code=1)

    rprint("[bold]This will:[/bold]")
    rprint(f"  • register against [cyan]{backend_url}[/cyan]")
    rprint(f"  • run the [cyan]{model_backend}[/cyan] inference backend")
    if signing_secret:
        rprint("  • register the node using the provided [cyan]signing secret[/cyan] (HMAC, legacy path)")
    else:
        rprint("  • register the node using your [cyan]API key[/cyan] (Bearer auth — default for api.sirb.run)")
    if no_sharding:
        rprint("  • [yellow]opt OUT[/yellow] of sharded-model fan-out (passing --no-sharding)")
    else:
        rprint("  • participate in sharded-model fan-out (default)")
    rprint(f"  • pull [cyan]{image}[/cyan]")
    # Resource budget. By default (no caps), the container is launched
    # with no --cpus / --memory limit AND --gpus all when NVIDIA GPUs
    # are detected. Each operator-set cap both limits the container
    # and becomes the registration claim. The deploy_node module does
    # the actual host probe; the preview is just informational.
    budget = []
    if cpu_cores is not None:   budget.append(f"{cpu_cores} CPU cores (--cpus)")
    if ram_gb is not None:      budget.append(f"{ram_gb} GB RAM (--memory)")
    if gpu_count is not None:   budget.append(f"{gpu_count} GPU(s) (--gpus count={gpu_count})")
    if vram_gb is not None:     budget.append(f"{vram_gb} GB VRAM claimed")
    if gpu_percent is not None: budget.append(f"{gpu_percent}% GPU compute claimed")
    if budget:
        rprint(f"  • cap container to [cyan]{' · '.join(budget)}[/cyan]")
    else:
        rprint("  • [dim]use all available host resources (no --cpus/--memory cap; --gpus all if NVIDIA GPUs found)[/dim]")
    rprint("  • start a Cloudflare Tunnel")
    rprint("  • write state to [cyan]~/.sirb/[/cyan]")
    rprint()

    # Ollama tag-check goes here (just above the confirm) so any
    # missing-tag warning is the LAST thing the operator sees before
    # [y/N]. Earlier we tried it pre-preview and operators on 80×24
    # terminals scrolled past it.
    if model_backend == "ollama" and models:
        _maybe_warn_ollama(ollama_url, models)

    if not yes and not Confirm.ask("Proceed?", default=True):
        rprint("[dim]aborted[/dim]")
        raise typer.Exit(code=1)

    # ── Native Python deploy. No bash, no install.sh, no shell. ────────
    # Works on Linux, macOS, Windows native, WSL — any OS Python runs
    # on. The whole install workflow lives in `sirb_cli.deploy_node`.
    from sirb_cli import deploy_node
    try:
        deploy_node.run(
            backend_url=backend_url,
            api_key=used_api_key,
            image=image,
            name=name,
            wallet=wallet,
            signing_secret=signing_secret,
            models=models,
            allow_sharding=(not no_sharding),
            model_backend=model_backend,
            ollama_url=ollama_url,
            llama_model_path=llama_model_path,
            cpu_cores=cpu_cores,
            ram_gb=ram_gb,
            gpu_count=gpu_count,
            gpu_percent=gpu_percent,
            vram_gb=vram_gb,
        )
    except typer.Exit:
        # _fatal() and other ordered exits already printed a clear
        # red message; just propagate the exit code.
        raise
    except KeyboardInterrupt:
        rprint("\n[yellow]aborted by user (Ctrl-C)[/yellow]")
        raise typer.Exit(code=130)
    except Exception as e:
        # Last-resort catch. We surface the full traceback to stderr
        # rather than silently summarizing — otherwise the operator
        # sees only "Deploy failed: KeyError: 'foo'" with no clue
        # which step (wallet / tunnel / docker / heartbeat) was active.
        import traceback
        rprint(f"\n[red]Deploy failed:[/red] {type(e).__name__}: {e}")
        rprint("[dim]Traceback follows; please include it in any bug report.[/dim]")
        traceback.print_exc()
        raise typer.Exit(code=1)
    print_cli_update_advisory_if_outdated()
    raise typer.Exit(code=0)


# ─────────────────────────── gateway ───────────────────────────────


@app.command("gateway")
def gateway(
    app_name: str = typer.Option(..., "--app-name", "-a",
                                 help="Fly app name (must be globally unique). e.g. sirb-acme."),
    region: str = typer.Option("iad", "--region", "-r",
                               help="Fly region (default: iad / Ashburn). See `fly platform regions`."),
    domain: str | None = typer.Option(None, "--domain", "-d",
                                      help="Custom domain to attach (optional, e.g. api.example.com)."),
    cors_origin: str | None = typer.Option(None, "--cors-origin",
                                           help="Origin to allow in CORS (e.g. https://your-frontend.com)."),
    image: str = typer.Option(
        DEFAULT_GATEWAY_IMAGE, "--image",
        envvar="SIRB_GATEWAY_IMAGE",
        help=(
            f"Gateway image to deploy. Default: {DEFAULT_GATEWAY_IMAGE} — "
            "tracks the latest build from main. Override with a specific "
            "tag (e.g. :v0.2.0) for a reproducible deploy, or pass --build "
            "to build from a local checkout."
        ),
    ),
    build_from_source: bool = typer.Option(
        False, "--build",
        help=(
            "Build the gateway from the local backend/ Dockerfile instead of "
            "pulling a pre-built image from GHCR. Requires the Sirb repo "
            "cloned alongside, and a slower deploy. Use this for forks you've "
            "modified that aren't yet published as an image."
        ),
    ),
    print_only: bool = typer.Option(False, "--print", help="Print the script without running it."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip the confirmation prompt."),
) -> None:
    """Bootstrap a brand-new Sirb gateway on Fly.io.

    Generates a deterministic deploy script that:
      1. creates the Fly app + Postgres add-on
      2. sets a freshly-generated signing secret + CORS + signup flags
      3. deploys the backend image
      4. runs Alembic migrations
      5. mints the first admin key and prints it (save it!)

    Requires `flyctl` on PATH and an authenticated session
    (`fly auth login`). Operates on the repo at the current working
    directory (must contain `backend/`).
    """
    # Default path: pull the pinned image from GHCR — no checkout required.
    # `--build` flips to local source build, which DOES need the repo.
    backend_dir: str | None = None
    pin_image: str | None = None
    if build_from_source:
        repo_root = _find_repo_root()
        backend_path = repo_root / "backend"
        if not (backend_path / "fly.toml").exists():
            rprint(f"[red]No backend/fly.toml found under {repo_root}.[/red]")
            rprint("--build requires the Sirb repo cloned (git clone https://github.com/ammarwa/SIRB).")
            rprint("Drop --build to deploy the pinned GHCR image instead — no checkout needed.")
            raise typer.Exit(code=1)
        backend_dir = str(backend_path)
    else:
        pin_image = image

    if not print_only:
        if not shutil.which("fly") and not shutil.which("flyctl"):
            rprint("[red]flyctl not found.[/red] Install from https://fly.io/docs/flyctl/install/ then retry.")
            raise typer.Exit(code=1)

    script = _build_gateway_script(
        app_name=app_name,
        region=region,
        domain=domain,
        cors_origin=cors_origin or (f"https://{domain}" if domain else "https://sirb.run"),
        backend_dir=backend_dir,
        image=pin_image,
    )

    rprint("[bold]Gateway deploy script[/bold]")
    rprint("[dim]" + ("─" * 60) + "[/dim]")
    console.print(script, highlight=False)
    rprint("[dim]" + ("─" * 60) + "[/dim]")

    if print_only:
        rprint("[dim]--print: script printed only, not executed[/dim]")
        return

    rprint(f"\n[bold]This will create:[/bold]")
    rprint(f"  • Fly app:      [cyan]{app_name}[/cyan] in [cyan]{region}[/cyan]")
    rprint(f"  • Fly Postgres: [cyan]{app_name}-pg[/cyan] (small tier)")
    rprint(f"  • Secrets:      SIRB_SIGNING_SECRET, SIRB_CORS_ALLOW_ORIGINS, SIRB_PUBLIC_SIGNUP_ENABLED")
    if pin_image:
        rprint(f"  • Gateway:      [cyan]{pin_image}[/cyan] (pinned image from GHCR)")
    else:
        rprint(f"  • Gateway:      built from local [cyan]backend/[/cyan] (--build)")
    if domain:
        rprint(f"  • Cert:         {domain}")
    rprint(f"  • Admin key:    minted at the end (printed once, save it)")
    rprint()
    if not yes and not Confirm.ask("Run this script now?", default=False):
        rprint("[dim]aborted — re-run with --print to copy the script, or --yes to skip the prompt[/dim]")
        raise typer.Exit(code=1)

    with tempfile.NamedTemporaryFile(mode="w", suffix=".sh", delete=False) as fh:
        fh.write(script)
        script_path = fh.name
    os.chmod(script_path, 0o700)

    proc = subprocess.run(["bash", script_path])
    if proc.returncode == 0:
        print_cli_update_advisory_if_outdated()
    raise typer.Exit(code=proc.returncode)


def _build_gateway_script(*, app_name: str, region: str, domain: str | None,
                          cors_origin: str, backend_dir: str | None,
                          image: str | None) -> str:
    """The deploy script body. Generated rather than templated to keep
    everything one file and self-contained — operators can read what
    runs against their Fly account before saying yes.

    `backend_dir` is the local repo's backend/ folder for source-build
    deploys; `image` is a GHCR reference for image-pin deploys. Exactly
    one is set."""
    domain_step = ""
    if domain:
        domain_step = f"""
# 7. (optional) attach the custom hostname; you'll need to add the
#    DNS records the cert request prints.
fly certs add -a "$APP" {_shell_quote(domain)}
fly secrets set -a "$APP" SIRB_PUBLIC_BASE_URL={_shell_quote("https://" + domain)}
"""

    if image:
        # Image-pin path. No local backend/ needed. We still call `fly deploy`
        # so that machines pull the pinned tag — `--image` overrides any
        # build:dockerfile= in fly.toml for this run.
        deploy_step = f"""# 4. Deploy the pinned gateway image from GHCR
fly deploy -a "$APP" --image {_shell_quote(image)}"""
    else:
        deploy_step = f"""# 4. Deploy from the backend directory of the Sirb repo
cd {_shell_quote(backend_dir or "backend")}
fly deploy -a "$APP\""""

    return f"""#!/usr/bin/env bash
set -euo pipefail
APP={_shell_quote(app_name)}
REGION={_shell_quote(region)}
SIGNING_SECRET="$(openssl rand -hex 32)"
echo "Generated signing secret (save it!): $SIGNING_SECRET"
echo

# 1. Create the Fly app
fly apps create "$APP" --org personal || true

# 2. Provision Postgres + attach (sets DATABASE_URL automatically)
fly postgres create --name "${{APP}}-pg" --region "$REGION" --vm-size shared-cpu-1x --initial-cluster-size 1 || true
fly postgres attach "${{APP}}-pg" --app "$APP" || true

# 3. Required secrets
fly secrets set -a "$APP" \\
  SIRB_SIGNING_SECRET="$SIGNING_SECRET" \\
  SIRB_CORS_ALLOW_ORIGINS={_shell_quote('["' + cors_origin + '"]')} \\
  SIRB_PUBLIC_SIGNUP_ENABLED=true \\
  SIRB_RATE_LIMIT_ENABLED=true

{deploy_step}

# 5. Run Alembic migrations against the freshly-attached Postgres
fly ssh console -a "$APP" -C "alembic upgrade head"

# 6. Bootstrap the first admin key — printed once, save it
echo
echo "Bootstrapping the first admin key:"
fly ssh console -a "$APP" -C "python -m app.scripts.admin_key create --admin --name ops"
{domain_step}
echo
echo "Done. Gateway live at https://${{APP}}.fly.dev/"
echo "Save the SIGNING_SECRET and the admin key printed above — they're not stored anywhere else."
"""


# ─────────────────────────── helpers ───────────────────────────────


def _find_repo_root() -> Path:
    """Walk up from cwd looking for backend/fly.toml. Falls back to cwd."""
    cur = Path.cwd().resolve()
    for parent in (cur, *cur.parents):
        if (parent / "backend" / "fly.toml").exists():
            return parent
    return cur


def _shell_quote(s: str) -> str:
    """Cheap shell-quote so the generated script handles spaces / special
    chars in the cors origin / app name without subtle bash injection.
    Stdlib's shlex.quote would do this but we avoid the import."""
    if not s or any(c in s for c in " \"'`$&|;<>()[]{}*?"):
        return "'" + s.replace("'", "'\"'\"'") + "'"
    return s


def _maybe_warn_ollama(ollama_url: str, models_csv: str) -> None:
    """Best-effort: check Ollama is reachable from the CLI and list the
    tags it's pulled. If we can reach it and an advertised model is
    missing, print a yellow warning. We never *fail* here because the
    container resolves `host.docker.internal` differently than the CLI
    process does, so an unreachable URL from this side doesn't prove
    the container can't reach it either."""
    # Operators usually pass either the host-side URL (what the CLI
    # sees) or the default container-side URL (`host.docker.internal`).
    # When they pass the container-side URL we can't probe from here.
    probe_url = ollama_url.replace(
        "host.docker.internal", "localhost"
    ).replace("172.17.0.1", "localhost")
    try:
        r = httpx.get(f"{probe_url.rstrip('/')}/api/tags", timeout=2.0)
        if r.status_code != 200:
            return
        installed = {m.get("name", "") for m in (r.json().get("models") or [])}
    except (httpx.HTTPError, ValueError):
        # Couldn't reach it from here. Container may still be able to
        # — leave the operator alone.
        return

    advertised = [m.strip() for m in models_csv.split(",") if m.strip()]
    missing = [m for m in advertised if m not in installed]
    if missing:
        rprint(
            f"[yellow][warn][/yellow] Ollama at {probe_url} is reachable but "
            f"hasn't pulled these tags: [yellow]{', '.join(missing)}[/yellow]"
        )
        rprint(
            "        Inference for these will 500 until you `ollama pull` them. "
            "Continuing — pass --yes / -y to suppress this banner once "
            "you've pulled them."
        )
