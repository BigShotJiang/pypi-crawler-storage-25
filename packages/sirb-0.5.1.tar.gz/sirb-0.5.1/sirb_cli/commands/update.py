"""``sirb update`` — upgrade Sirb components on this machine.

Three things you can update independently, since they ship on different
release cadences:

  sirb update cli       — `pip install --upgrade sirb`
  sirb update node      — `docker pull` the latest image + restart the
                          local sirb-node container against it.
  sirb update gateway   — operators only: `fly deploy --image` against the
                          latest published gateway image.

`sirb update` (bare) checks-but-doesn't-do: shows the version drift for
each component and tells you what to run. Same advisory the per-deploy
hook prints, just on demand.
"""

from __future__ import annotations

import shutil
import subprocess
import sys

import typer
from rich import print as rprint

from sirb_cli.update_check import (
    DEFAULT_NODE_IMAGE_REF,
    check_cli_update,
    check_node_image_age,
    latest_pypi_version,
)


app = typer.Typer(
    name="update",
    invoke_without_command=True,
    no_args_is_help=False,
    help="Check + apply updates for sirb CLI, node-agent, and gateway.",
)


@app.callback()
def _status(ctx: typer.Context) -> None:
    """Bare `sirb update` prints a status report. Subcommands apply the change."""
    if ctx.invoked_subcommand is not None:
        return
    _print_status()


def _print_status() -> None:
    cli_update = check_cli_update()
    if cli_update:
        installed, latest = cli_update
        rprint(f"[yellow]●[/yellow] CLI:     installed [yellow]{installed}[/yellow] · "
               f"latest [green]{latest}[/green] — run [cyan]sirb update cli[/cyan]")
    else:
        # Show the installed version regardless so the user has a quick
        # reference; matches what `sirb status` shows.
        try:
            from sirb_cli import __version__ as v
            rprint(f"[green]●[/green] CLI:     [green]{v}[/green] (latest)")
        except Exception:
            rprint("[dim]●[/dim] CLI:     version unknown")

    age = check_node_image_age()
    if age is not None:
        rprint(f"[yellow]●[/yellow] node:    local image is [yellow]{age}d[/yellow] old — "
               f"run [cyan]sirb update node[/cyan]")
    elif shutil.which("docker"):
        rprint("[green]●[/green] node:    no stale container detected")
    else:
        rprint("[dim]●[/dim] node:    docker not on PATH; skipping")

    rprint("[dim]●[/dim] gateway: run [cyan]sirb update gateway[/cyan] on the operator host "
           "to redeploy against the latest published image (operators only)")


# ─── sirb update cli ──────────────────────────────────────────────


@app.command("cli", help="Upgrade the sirb CLI via pip (in-place upgrade of this Python's site-packages).")
def update_cli(
    pre: bool = typer.Option(False, "--pre",
                              help="Allow pre-release versions when resolving --upgrade."),
    yes: bool = typer.Option(False, "--yes", "-y",
                              help="Skip the confirmation prompt."),
) -> None:
    """Equivalent to `pip install --upgrade sirb`, but resolves the same
    Python interpreter sirb is currently running under — so a system
    pip / pipx / venv split can't accidentally upgrade the wrong copy."""
    latest = latest_pypi_version() or "unknown"
    rprint(f"[bold]This will:[/bold]")
    rprint(f"  • run [cyan]{sys.executable} -m pip install --upgrade sirb[/cyan]")
    rprint(f"  • upgrade to PyPI's latest ([green]{latest}[/green])")
    if not yes:
        if not typer.confirm("Proceed?", default=True):
            rprint("[dim]aborted[/dim]")
            raise typer.Exit(code=1)

    cmd = [sys.executable, "-m", "pip", "install", "--upgrade"]
    if pre:
        cmd.append("--pre")
    cmd.append("sirb")
    rprint(f"\n[dim]$ {' '.join(cmd)}[/dim]\n")
    proc = subprocess.run(cmd)
    raise typer.Exit(code=proc.returncode)


# ─── sirb update node ─────────────────────────────────────────────


@app.command("node", help="Pull the latest node-agent image and restart the local container.")
def update_node(
    name: str = typer.Option("sirb-node", "--name", "-n",
                              help="Docker container name (default: sirb-node)."),
    image: str = typer.Option(DEFAULT_NODE_IMAGE_REF, "--image", "-i",
                               envvar="SIRB_NODE_IMAGE",
                               help=f"Image to pull (default: {DEFAULT_NODE_IMAGE_REF})."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip the confirmation prompt."),
) -> None:
    """Pulls the image, stops the running container, and recreates it
    with the same env vars + ports. This is the simple "just take the
    new code" path; for a fresh install (different signing secret, new
    wallet, etc.) re-run `sirb deploy node`."""
    if not shutil.which("docker"):
        rprint("[red]docker not on PATH.[/red] Install Docker and retry.")
        raise typer.Exit(code=1)

    # Inspect the running container so we can recreate it with the same
    # config. If there's no container by that name, advise `sirb deploy
    # node` instead — there's nothing to update.
    inspect = subprocess.run(
        ["docker", "container", "inspect", name],
        capture_output=True, text=True,
    )
    if inspect.returncode != 0:
        rprint(f"[yellow]No running container named [bold]{name}[/bold].[/yellow]")
        rprint("Use [cyan]sirb deploy node[/cyan] to set one up from scratch, "
               "or pass [cyan]--name <existing>[/cyan] if it's named differently.")
        raise typer.Exit(code=1)

    rprint(f"[bold]This will:[/bold]")
    rprint(f"  • pull [cyan]{image}[/cyan]")
    rprint(f"  • stop and remove the [cyan]{name}[/cyan] container")
    rprint(f"  • recreate it from the new image with the same env / ports / restart policy")
    rprint(f"  • [dim](does not change your signing secret, wallet, or API key)[/dim]")
    if not yes:
        if not typer.confirm("Proceed?", default=True):
            rprint("[dim]aborted[/dim]")
            raise typer.Exit(code=1)

    # Pull the new image. Fail loudly if it doesn't exist.
    rprint(f"\n[dim]$ docker pull {image}[/dim]")
    pull = subprocess.run(["docker", "pull", image])
    if pull.returncode != 0:
        rprint(f"[red]docker pull failed.[/red] "
               f"Check the image ref or your network reachability to ghcr.io.")
        raise typer.Exit(code=pull.returncode)

    # Reuse the running container's config (env, ports, restart policy)
    # so we don't lose the wallet / signing secret / tunnel URL. We pass
    # the new image explicitly to `docker run`.
    import json
    spec = json.loads(inspect.stdout)[0]
    env_vars = spec.get("Config", {}).get("Env") or []
    port_bindings = spec.get("HostConfig", {}).get("PortBindings") or {}
    restart_policy = spec.get("HostConfig", {}).get("RestartPolicy", {}).get("Name") or "unless-stopped"

    rprint(f"[dim]$ docker rm -f {name}[/dim]")
    removed = subprocess.run(["docker", "rm", "-f", name], capture_output=True, text=True)
    if removed.returncode != 0:
        # Surface what stopped us instead of barreling on to docker run,
        # which would then 409 with "container name already in use" and
        # hide the real reason (permissions, daemon hiccup, paused
        # container, etc.).
        rprint(f"[red]docker rm -f failed:[/red] {removed.stderr.strip() or '(no stderr)'}")
        rprint("[dim]The old container is still in place — your node hasn't been touched.[/dim]")
        raise typer.Exit(code=removed.returncode)

    run = ["docker", "run", "-d", "--name", name, "--restart", restart_policy]
    for e in env_vars:
        run += ["-e", e]
    for container_port, host_specs in port_bindings.items():
        for host_spec in host_specs:
            run += ["-p", f"{host_spec.get('HostPort','')}:{container_port.split('/')[0]}"]
    run.append(image)

    rprint(f"[dim]$ docker run -d --name {name} {image} (with prior env + ports)[/dim]")
    started = subprocess.run(run, capture_output=True, text=True)
    if started.returncode != 0:
        # At this point the OLD container has already been removed — the
        # node IS offline. Print the recovery hint so the user can get
        # back online manually with the spec we captured, instead of
        # losing the wallet / signing secret / tunnel URL.
        rprint(f"[red]docker run failed:[/red] {started.stderr.strip() or '(no stderr)'}")
        rprint()
        rprint("[bold red]Your old container has already been removed — the node is offline.[/bold red]")
        rprint("To restore on the OLD image:")
        rprint(f"  [dim]$[/dim] [cyan]docker run -d --name {name} --restart {restart_policy} \\")
        rprint("    " + " ".join(f"-e '{e}'" for e in env_vars[:3]) + " … " + image)
        rprint("(Full env block has " + str(len(env_vars)) + " entries — captured in /tmp before pull. "
               "Re-run `sirb deploy node` if needed.)")
        raise typer.Exit(code=started.returncode)

    rprint(f"\n[green]Updated.[/green] [cyan]{name}[/cyan] is now running [cyan]{image}[/cyan].")
    rprint("Tail logs with: [dim]docker logs -f " + name + "[/dim]")


# ─── sirb update gateway ──────────────────────────────────────────


@app.command("gateway", help="(operator) Redeploy a Fly.io gateway against the latest published image.")
def update_gateway(
    app_name: str = typer.Option(..., "--app-name", "-a",
                                  help="Fly app name (e.g. sirb-api)."),
    image: str = typer.Option("ghcr.io/ammarwa/sirb-gateway:latest", "--image",
                               envvar="SIRB_GATEWAY_IMAGE",
                               help="Image to deploy. Default: ghcr.io/ammarwa/sirb-gateway:latest."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip the confirmation prompt."),
) -> None:
    """Wraps `fly deploy --image <ref>` so an operator doesn't have to
    keep that incantation in their head. Runs alembic migrations on the
    new container at first request automatically (entrypoint handles it
    when SIRB_DATABASE_URL is set)."""
    if not shutil.which("fly") and not shutil.which("flyctl"):
        rprint("[red]flyctl not on PATH.[/red] Install from https://fly.io/docs/flyctl/install/")
        raise typer.Exit(code=1)

    rprint(f"[bold]This will:[/bold]")
    rprint(f"  • run [cyan]fly deploy -a {app_name} --image {image}[/cyan]")
    rprint(f"  • [dim]alembic migrations run automatically on container boot[/dim]")
    if not yes:
        if not typer.confirm("Proceed?", default=False):
            rprint("[dim]aborted[/dim]")
            raise typer.Exit(code=1)

    cmd = ["fly", "deploy", "-a", app_name, "--image", image]
    rprint(f"\n[dim]$ {' '.join(cmd)}[/dim]\n")
    proc = subprocess.run(cmd)
    raise typer.Exit(code=proc.returncode)
