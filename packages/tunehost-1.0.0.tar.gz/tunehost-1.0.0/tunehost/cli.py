import asyncio
import websockets
import requests
import json
import argparse

async def run(port, token):
    url = f"wss://tunehost.mboahost.biz/ws?token={token}"
    while True:
        try:
            async with websockets.connect(url) as ws:
                print("Connected to TuneHost")
                while True:
                    data = json.loads(await ws.recv())
                    r = requests.request(
                        data["method"],
                        f"http://localhost:{port}/{data['path']}"
                    )
                    await ws.send(json.dumps({
                        "status": r.status_code,
                        "body": r.text
                    }))
        except Exception as e:
            print("Reconnecting...", e)
            await asyncio.sleep(2)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", default=5000, type=int)
    parser.add_argument("--token", required=True)
    args = parser.parse_args()
    asyncio.run(run(args.port, args.token))
