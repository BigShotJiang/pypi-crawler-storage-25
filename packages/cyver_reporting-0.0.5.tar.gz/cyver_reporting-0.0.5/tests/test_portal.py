"""
Tests for PentesterPortal / ClientPortal skeleton, CyverAuthMethodError,
and the portal_unstable decorator (R16).
"""

import warnings
import pytest
from unittest.mock import MagicMock, patch

from CyverReporting import (
    ClientPortal,
    ClientSession,
    CyverAuthError,
    CyverAuthMethodError,
    CyverPortalInstabilityWarning,
    CyverSession,
    PentesterPortal,
    PentesterSession,
    portal_unstable,
)
import CyverReporting.Exceptions as ExceptionsPkg
from tests.conftest import (
    FAKE_ACCESS_TOKEN, FAKE_REFRESH_TOKEN, FAKE_UUID, PORTAL,
    make_api_response,
)


# ---------------------------------------------------------------------------
# CyverAuthMethodError — exception hierarchy and import paths
# ---------------------------------------------------------------------------

class TestCyverAuthMethodError:

    def test_subclass_of_cyver_auth_error(self):
        assert issubclass(CyverAuthMethodError, CyverAuthError)

    def test_importable_from_top_level(self):
        # Intentional double-import: must be reachable both ways.
        from CyverReporting import CyverAuthMethodError as E1
        from CyverReporting.Exceptions import CyverAuthMethodError as E2
        assert E1 is E2 is CyverAuthMethodError

    def test_is_exported_from_exceptions_package(self):
        assert "CyverAuthMethodError" in ExceptionsPkg.__all__

    def test_reason_attribute_surfaces_on_raised_instance(self):
        with pytest.raises(CyverAuthMethodError) as exc_info:
            raise CyverAuthMethodError("nope", reason="api_key_not_supported")
        assert exc_info.value.reason == "api_key_not_supported"

    def test_caught_by_broad_cyver_auth_error_handler(self):
        """Broad ``except CyverAuthError`` handlers keep catching this."""
        try:
            raise CyverAuthMethodError("nope", reason="api_key_not_supported")
        except CyverAuthError as e:
            assert isinstance(e, CyverAuthMethodError)


# ---------------------------------------------------------------------------
# PentesterPortal / ClientPortal — construction-time auth guard
# ---------------------------------------------------------------------------

class TestPortalConstructionAuthGuard:
    """
    The portal API rejects static API keys; attempting to construct a
    portal class with ``api_key=...`` must raise at construction, not
    later at call time.
    """

    def _no_probe(self):
        # Construction with an api_key normally triggers a portal probe
        # (network call).  Patch it out so these tests stay offline.
        return patch.object(CyverSession, "_probe_portal")

    def _no_apikey_cache(self):
        return patch.object(
            CyverSession, "_fetch_apikey_cache",
            return_value={"portal": None},
        )

    def _no_apikey_cache_save(self):
        return patch.object(CyverSession, "_save_apikey_cache", return_value=True)

    def test_pentester_portal_rejects_api_key(self):
        with self._no_probe(), self._no_apikey_cache(), self._no_apikey_cache_save():
            with pytest.raises(CyverAuthMethodError) as exc_info:
                PentesterPortal(portal=PORTAL, api_key="sk-test")
        assert exc_info.value.reason == "api_key_not_supported"

    def test_client_portal_rejects_api_key(self):
        with self._no_probe(), self._no_apikey_cache(), self._no_apikey_cache_save():
            with pytest.raises(CyverAuthMethodError) as exc_info:
                ClientPortal(portal=PORTAL, api_key="sk-test")
        assert exc_info.value.reason == "api_key_not_supported"

    def test_pentester_portal_constructs_cleanly_without_api_key(self):
        # No api_key → password-auth mode, constructor passes without error.
        portal = PentesterPortal()
        assert portal._api_key is None

    def test_client_portal_constructs_cleanly_without_api_key(self):
        portal = ClientPortal()
        assert portal._api_key is None

    def test_pentester_portal_is_pentester_session_instance(self):
        p = PentesterPortal()
        assert isinstance(p, PentesterSession)
        assert isinstance(p, CyverSession)

    def test_client_portal_is_client_session_instance(self):
        c = ClientPortal()
        assert isinstance(c, ClientSession)
        assert isinstance(c, CyverSession)

    def test_error_raised_at_construction_not_on_method_call(self):
        """Guard fires in __init__ — never later.  If it fired at call
        time, constructing would succeed and only dispatch would fail."""
        with self._no_probe(), self._no_apikey_cache(), self._no_apikey_cache_save():
            raised_at = []
            try:
                PentesterPortal(portal=PORTAL, api_key="sk-test")
                raised_at.append("not_raised")
            except CyverAuthMethodError:
                raised_at.append("construction")
        assert raised_at == ["construction"]


# ---------------------------------------------------------------------------
# PentesterPortal / ClientPortal — inherited V2.2 surface dispatches
# ---------------------------------------------------------------------------

class TestPortalInheritedSurface:
    """
    Every method on PentesterSession / ClientSession must continue to
    work unchanged when invoked on a portal subclass instance.
    """

    def _authenticated_pentester_portal(self):
        p = PentesterPortal()
        p.portal        = PORTAL
        p.access_token  = FAKE_ACCESS_TOKEN
        p.refresh_token = FAKE_REFRESH_TOKEN
        p.user_id       = FAKE_UUID
        p._send_api_request = MagicMock()
        return p

    def _authenticated_client_portal(self):
        c = ClientPortal()
        c.portal        = PORTAL
        c.access_token  = FAKE_ACCESS_TOKEN
        c.refresh_token = FAKE_REFRESH_TOKEN
        c.user_id       = FAKE_UUID
        c._send_api_request = MagicMock()
        return c

    # --- PentesterPortal inherits PentesterSession surface ---

    def test_pentester_portal_get_clients_dispatches(self):
        p = self._authenticated_pentester_portal()
        p._send_api_request.return_value = {"items": [], "totalCount": 0}
        p.get_clients()
        assert p._send_api_request.call_args[0][0] == "GET"
        assert "/clients" in p._send_api_request.call_args[0][1]

    def test_pentester_portal_get_project_by_id_dispatches(self):
        p = self._authenticated_pentester_portal()
        p._send_api_request.return_value = {"id": FAKE_UUID, "name": "X"}
        p.get_project_by_id(FAKE_UUID)
        assert p._send_api_request.call_args[0][0] == "GET"
        assert FAKE_UUID in p._send_api_request.call_args[0][1]

    def test_pentester_portal_has_upload_file_to_project(self):
        """Regression: R24 method reachable through PentesterPortal too."""
        assert hasattr(PentesterPortal, "upload_file_to_project")

    # --- ClientPortal inherits ClientSession surface ---

    def test_client_portal_get_projects_dispatches(self):
        c = self._authenticated_client_portal()
        c._send_api_request.return_value = {"items": [], "totalCount": 0}
        c.get_projects()
        assert c._send_api_request.call_args[0][0] == "GET"

    def test_client_portal_get_project_by_id_dispatches(self):
        c = self._authenticated_client_portal()
        c._send_api_request.return_value = {"id": FAKE_UUID, "name": "X"}
        c.get_project_by_id(FAKE_UUID)
        assert c._send_api_request.call_args[0][0] == "GET"

    def test_client_portal_skeleton_adds_no_public_methods_of_its_own(self):
        """R16 skeleton: ``ClientPortal`` is still a pure skeleton."""
        client_only = set(vars(ClientPortal)) - set(vars(ClientSession))
        # Allow __init__ (which calls the auth-mode guard) but nothing else.
        assert client_only <= {"__init__", "__doc__", "__module__"}

    def test_pentester_portal_only_admits_known_portal_methods(self):
        """``PentesterPortal`` admits portal methods one at a time under the
        admission protocol in :doc:`docs/portal.md`. Update this allow-list
        when admitting each new method so the suite documents the surface
        and trips on unintentional additions."""
        pentester_only = set(vars(PentesterPortal)) - set(vars(PentesterSession))
        admitted_portal_methods = {
            "get_project_images_files",
            "get_all_project_images_files",
            "delete_project_file",
            "get_project_files",
            "get_all_project_files",
            "update_project_file",
            "get_finding_libraries",
            "get_all_finding_libraries",
            "create_finding_library",
            "delete_finding_library",
            "get_finding_templates",
            "get_all_finding_templates",
        }
        framework = {"__init__", "__doc__", "__module__"}
        assert pentester_only <= framework | admitted_portal_methods


# ---------------------------------------------------------------------------
# portal_unstable decorator — warn-once-per-method semantics
# ---------------------------------------------------------------------------

class TestPortalUnstableDecorator:

    def test_emits_warning_on_first_call(self):
        @portal_unstable
        def some_portal_method():
            return "ok"

        with warnings.catch_warnings(record=True) as captured:
            warnings.simplefilter("always")
            assert some_portal_method() == "ok"

        assert len(captured) == 1
        assert issubclass(captured[0].category, CyverPortalInstabilityWarning)
        assert "some_portal_method" in str(captured[0].message)
        assert "undocumented portal surface" in str(captured[0].message)

    def test_silent_on_second_and_subsequent_calls(self):
        @portal_unstable
        def once():
            return 42

        with warnings.catch_warnings(record=True) as captured:
            warnings.simplefilter("always")
            once()  # warn
            once()  # silent
            once()  # silent

        assert len(captured) == 1

    def test_two_decorated_functions_warn_independently(self):
        @portal_unstable
        def alpha():
            return "a"

        @portal_unstable
        def bravo():
            return "b"

        with warnings.catch_warnings(record=True) as captured:
            warnings.simplefilter("always")
            alpha()  # warn
            bravo()  # warn
            alpha()  # silent
            bravo()  # silent

        assert len(captured) == 2
        messages = [str(w.message) for w in captured]
        assert any("alpha" in m for m in messages)
        assert any("bravo" in m for m in messages)

    def test_decorated_function_preserves_return_value_and_args(self):
        @portal_unstable
        def echo(a, b=10):
            return a + b

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            assert echo(1) == 11
            assert echo(1, b=20) == 21
            assert echo(3, 4) == 7

    def test_decorated_function_preserves_name_and_doc(self):
        @portal_unstable
        def documented():
            """A doc string."""
            return None
        assert documented.__name__ == "documented"
        assert documented.__doc__  == "A doc string."

    def test_warning_class_is_user_warning_subclass(self):
        assert issubclass(CyverPortalInstabilityWarning, UserWarning)
        assert issubclass(CyverPortalInstabilityWarning, Warning)

    def test_warning_is_filterable_via_standard_warnings_module(self):
        @portal_unstable
        def silenced():
            return "ok"

        with warnings.catch_warnings(record=True) as captured:
            warnings.simplefilter("ignore", CyverPortalInstabilityWarning)
            silenced()

        assert len(captured) == 0

    def test_stacklevel_points_at_caller_not_decorator(self):
        """`stacklevel=2` in the decorator means the warning surfaces with
        the caller's location, not the wrapper's — helpful for users who
        want to trace which of their call sites is using portal surface."""
        @portal_unstable
        def pivot():
            return None

        with warnings.catch_warnings(record=True) as captured:
            warnings.simplefilter("always")
            pivot()  # this file / this line is what the warning should point at.

        assert len(captured) == 1
        # The warning's filename should be this test file, not WarningHandlers.py.
        assert captured[0].filename.endswith("test_portal.py")


# ---------------------------------------------------------------------------
# Integration: CyverPortalInstabilityWarning is re-exported at the top level
# ---------------------------------------------------------------------------

class TestPortalUnstableExports:

    def test_top_level_exports(self):
        import CyverReporting
        assert "PentesterPortal" in CyverReporting.__all__
        assert "ClientPortal" in CyverReporting.__all__
        assert "CyverAuthMethodError" in CyverReporting.__all__
        assert "CyverPortalInstabilityWarning" in CyverReporting.__all__
        assert "portal_unstable" in CyverReporting.__all__
