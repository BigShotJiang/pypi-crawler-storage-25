#!/usr/bin/env python3

import re
from re import IGNORECASE

_re_uuid = re.compile(
    r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$",
    IGNORECASE,
)
"""Matches a well-formed UUID in ``xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx`` form (case-insensitive)."""

_re_email = re.compile(
    r'^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$'
)
"""Minimal RFC 5321-inspired pattern: ``local-part @ domain . tld`` (tld ≥ 2 chars)."""

_re_datetime = re.compile(
    r'^\d{4}-(?:0[1-9]|1[0-2])-(?:0[1-9]|[12]\d|3[01])'
    r'T(?:[01]\d|2[0-3]):[0-5]\d:[0-5]\d'
    r'(?:\.\d+)?Z$'
)
"""Matches ``YYYY-MM-DDTHH:MM:SS[.fractional]Z`` (UTC, Zulu suffix required)."""

_re_date = re.compile(
    r'^\d{4}-(?:0[1-9]|1[0-2])-(?:0[1-9]|[12]\d|3[01])$'
)
"""Matches ``YYYY-MM-DD`` (calendar date, no time component)."""

_re_cve = re.compile(
    r'^CVE-[0-9]{4}-[0-9]{4,19}$'
)
"""Matches a CVE identifier per the official MITRE specification.

Format: ``CVE-YYYY-NNNNN`` where YYYY is a 4-digit year and the sequence
number is between 4 and 19 digits (the extended syntax introduced in 2014
allows more than 4 digits for high-volume years).

Examples: ``CVE-1999-0001``, ``CVE-2014-0160``, ``CVE-2024-30145``.

Reference: https://cve.mitre.org/cve/identifiers/syntaxchange.html
"""

_re_cwe = re.compile(
    r'^CWE-[1-9][0-9]{0,4}$'
)
"""Matches a CWE identifier per the MITRE Common Weakness Enumeration format.

Format: ``CWE-N`` where N is 1–5 digits with no leading zeros (IDs start
at 1; the current list reaches the low thousands).

Examples: ``CWE-20``, ``CWE-134``, ``CWE-1215``.

Reference: https://cwe.mitre.org/
"""

_re_mitre_tactic = re.compile(
    r'^TA[0-9]{4}$'
)
"""Matches a MITRE ATT&CK tactic identifier.

Format: ``TA`` followed by exactly 4 digits.  Current Enterprise tactics
span ``TA0001``–``TA0043`` (non-contiguous); the format is validated
without restricting to currently defined IDs to remain future-proof.

Examples: ``TA0001``, ``TA0004``, ``TA0043``.

Reference: https://attack.mitre.org/tactics/enterprise/
"""

_re_mitre_technique = re.compile(
    r'^T[0-9]{4}(?:\.[0-9]{3})?$'
)
"""Matches a MITRE ATT&CK technique or sub-technique identifier.

Format: ``T`` followed by exactly 4 digits, with an optional sub-technique
suffix of ``.`` and exactly 3 digits.  Current Enterprise techniques span
from ``T1001`` upwards; sub-techniques use a three-digit suffix (``001``–``999``).

Examples: ``T1040``, ``T1003``, ``T1003.003``, ``T1574.001``.

Reference: https://attack.mitre.org/techniques/enterprise/
"""

_re_mitre_mitigation = re.compile(
    r'^M[0-9]{4}$'
)
"""Matches a MITRE ATT&CK mitigation identifier.

Format: ``M`` followed by exactly 4 digits.  Current Enterprise mitigations
span ``M1015``–``M1060`` (non-contiguous); the format is validated without
restricting to currently defined IDs to remain future-proof.

Examples: ``M1015``, ``M1018``, ``M1056``.

Reference: https://attack.mitre.org/mitigations/enterprise/
"""

_re_cvss40_vector = re.compile(
    r'^CVSS:4\.0(/[A-Za-z]+:[A-Za-z0-9]+)+$'
)
"""Structural pattern for CVSS v4.0 vector strings.

Matches the ``CVSS:4.0/`` prefix followed by one or more ``Metric:Value``
groups separated by ``/``.  This pattern performs structural validation only;
use :func:`_validate_cvss40_vector` for full base-metric presence and value
checking.

Example: ``CVSS:4.0/AV:N/AC:L/AT:N/PR:N/UI:N/VC:H/VI:H/VA:H/SC:N/SI:N/SA:N``.

Reference: https://www.first.org/cvss/v4.0/specification-document
"""

_re_cvss31_vector = re.compile(
    r'^CVSS:3\.1(/[A-Za-z]+:[A-Za-z0-9]+)+$'
)
"""Structural pattern for CVSS v3.1 vector strings.

Matches the ``CVSS:3.1/`` prefix followed by one or more ``Metric:Value``
groups separated by ``/``.  This pattern performs structural validation only;
use :func:`_validate_cvss31_vector` for full base-metric presence and value
checking.

Example: ``CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H``.

Reference: https://www.first.org/cvss/v3.1/specification-document
"""

_re_cvss30_vector = re.compile(
    r'^CVSS:3\.0(/[A-Za-z]+:[A-Za-z0-9]+)+$'
)
"""Structural pattern for CVSS v3.0 vector strings.

Matches the ``CVSS:3.0/`` prefix followed by one or more ``Metric:Value``
groups separated by ``/``.  This pattern performs structural validation only;
use :func:`_validate_cvss30_vector` for full base-metric presence and value
checking.

Example: ``CVSS:3.0/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H``.

Reference: https://www.first.org/cvss/v3.0/specification-document
"""

_re_cvss20_vector = re.compile(
    r'^(?!CVSS:)[A-Za-z]+:[A-Za-z0-9]+(?:/[A-Za-z]+:[A-Za-z0-9]+)*$'
)
"""Structural pattern for CVSS v2.0 vector strings (parentheses pre-stripped).

Accepts the bare ``Metric:Value`` string with no version prefix.  The
negative lookahead ``(?!CVSS:)`` prevents a CVSS 3.x/4.x string accidentally
passed to the v2.0 validator from matching.  Outer parentheses must be
stripped before matching; use :func:`_validate_cvss20_vector` which handles
this automatically.

Example: ``AV:N/AC:L/Au:N/C:P/I:P/A:P``.

Reference: https://www.first.org/cvss/v2.0/guide
"""

_re_url = re.compile(
    r'^https?://'
    r'(?:'
    r'(?:[A-Z0-9](?:[A-Z0-9\-]{0,61}[A-Z0-9])?\.)+[A-Z]{2,}\.?'
    r'|localhost'
    r'|\d{1,3}(?:\.\d{1,3}){3}'
    r')'
    r'(?::\d{2,5})?'
    r'(?:[/?#]\S*)?$',
    IGNORECASE,
)
"""Matches an HTTP or HTTPS URL.

Validates the ``http://`` or ``https://`` scheme; a hostname (domain name,
``localhost``, or dotted-decimal IPv4); an optional port; and an optional
path, query string, or fragment.

Examples: ``https://example.com``, ``http://localhost:8080/path?q=1``,
``https://192.168.1.1/api/v1``.
"""

_re_ipv4 = re.compile(
    r'^(?:(?:25[0-5]|2[0-4]\d|1\d{2}|[1-9]\d|\d)\.){3}'
    r'(?:25[0-5]|2[0-4]\d|1\d{2}|[1-9]\d|\d)$'
)
"""Matches a dotted-decimal IPv4 address.

Each octet must be in the range 0–255 with no leading zeros.

Examples: ``192.168.1.1``, ``10.0.0.0``, ``255.255.255.255``, ``0.0.0.0``.
"""

_re_ipv6 = re.compile(
    r'^('
    r'([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}'           # full: 8 groups
    r'|([0-9a-fA-F]{1,4}:){1,7}:'                         # trailing :: compression
    r'|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}'        # one compressed group on right
    r'|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}'
    r'|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}'
    r'|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}'
    r'|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}'
    r'|[0-9a-fA-F]{1,4}:(:[0-9a-fA-F]{1,4}){1,6}'
    r'|:(:[0-9a-fA-F]{1,4}){1,7}'                         # leading :: compression
    r'|::'                                                  # all-zeros / loopback (::)
    r')$',
    IGNORECASE,
)
"""Matches a compressed or full-form IPv6 address (no embedded IPv4 notation).

Pure IPv6 only — does not handle IPv4-mapped addresses such as ``::ffff:192.0.2.1``.
Validation is structural; use :func:`_validate_ip` which delegates to
:func:`ipaddress.ip_address` for authoritative checking.

Examples: ``2001:db8::1``, ``::1``, ``fe80::1``, ``::``,
``2001:0db8:0000:0000:0000:0000:0000:0001``.
"""
