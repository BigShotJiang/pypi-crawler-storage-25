#!/usr/bin/env python3

from __future__ import annotations

from ..Exceptions import CyverDataValidationError
from ..Utils import (
    _finding_status,
    _validate_uuid,
    _validate_cve,
    _validate_cwe,
    _validate_mitre_tactic,
    _validate_mitre_technique,
    _validate_mitre_mitigation,
    _validate_finding_type,
    _validate_finding_status,
    _validate_finding_severity,
    _validate_finding_compliance_status,
    _validate_cvss_score,
    _validate_cvss40_vector,
    _validate_cvss31_vector,
    _validate_cvss30_vector,
    _validate_cvss20_vector,
    _validate_url,
    _fd_optional_str,
    _fd_optional_int,
    _fd_optional_bool,
    _fd_optional_uuid,
    _fd_uuid_list,
    _fd_nested_list,
)
from .CyverFindingEvidence import CyverFindingEvidence
from .CyverFindingCustomField import CyverFindingCustomField


class CyverFinding:
    """
        Data-builder for the ``/api/v2.2/pentester/findings`` API endpoints.

        Encapsulates and validates the request body for both the
        ``POST /api/v2.2/pentester/findings`` (create) and
        ``PUT /api/v2.2/pentester/findings/:id`` (update) operations.

        ``name`` is the only universally required field and must be provided
        at construction time.  ``id`` is additionally required for PUT requests
        and is populated automatically by :meth:`from_dict` when the object is
        constructed from an API response.  All other fields are optional.

        **Enum-validated integer fields** (accept only codes defined in their
        respective static alias class):

        * ``type`` — :class:`~CyverReporting._finding_type` bit-flags
          (any non-zero combination of 1, 2, 4, 8, 16)
        * ``status`` — :class:`~CyverReporting._finding_status` (1–14)
        * ``severity`` — :class:`~CyverReporting._finding_severity` (0–4)
        * ``complianceStatus`` — :class:`~CyverReporting._finding_compliance_status`
          (0–1)

        **CVSS fields** — all four vector strings are validated for structural
        correctness and required base-metric presence:

        * ``cvss40Vector`` — ``CVSS:4.0/`` prefix, 11 required base metrics
        * ``cvss31Vector`` — ``CVSS:3.1/`` prefix, 8 required base metrics
        * ``cvss30Vector`` — ``CVSS:3.0/`` prefix, 8 required base metrics
        * ``cvss20Vector`` — no prefix (parentheses optional), 6 required
          base metrics

        All setter methods return ``self`` for fluent chaining::

            finding = (
                CyverFinding("SQL Injection in Login Form")
                .set_severity(_finding_severity.high)
                .set_status(_finding_status.draft)
                .set_type(_finding_type.vulnerability)
                .set_cvss31_vector("CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H")
                .set_cvss31_score(9.8)
                .add_cwe("CWE-89")
                .add_cve("CVE-2024-12345")
                .add_asset_id("xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx")
            )

            payload = finding.to_dict()

        Args:
            name (str): The finding's display name. Must be a non-empty string.

        Raises:
            CyverDataValidationError: If ``name`` is not a non-empty ``str``.
    """

    def __init__(self, name: str) -> None:
        if not isinstance(name, str) or not name:
            raise CyverDataValidationError(
                "'name' must be a non-empty string.",
                field="name",
                reason="invalid_type" if not isinstance(name, str) else "missing_required",
            )
        # Server-assigned identity
        self._id: str | None = None
        # Required
        self._name: str = name
        # Plain string fields
        self._code: str | None = None
        self._description: str | None = None
        self._compliance_comment: str | None = None
        self._impact_description: str | None = None
        self._likelihood_description: str | None = None
        self._recommendation: str | None = None
        self._background_information: str | None = None
        # Enum-validated integer fields
        self._type: int | None = None
        self._status: int | None = None
        self._severity: int | None = None
        self._compliance_status: int | None = None
        # Plain integer fields (no defined enum)
        self._impact: int | None = None
        self._likelihood: int | None = None
        # CVSS sub-object fields
        self._cvss40_vector: str | None = None
        self._cvss40_score: float | int | None = None
        self._cvss31_vector: str | None = None
        self._cvss31_score: float | int | None = None
        self._cvss30_vector: str | None = None
        self._cvss30_score: float | int | None = None
        self._cvss20_vector: str | None = None
        self._cvss20_score: float | int | None = None
        # UUID reference fields
        self._project_task_id: str | None = None
        self._reviewer_id: str | None = None
        # List fields — identifiers
        self._cwe_list: list[str] = []
        self._cve_list: list[str] = []
        self._mitre_attack_tactics_list: list[str] = []
        self._mitre_attack_techniques_list: list[str] = []
        self._mitre_attack_mitigations_list: list[str] = []
        self._vulnerability_type_list: list[str] = []
        self._asset_id_list: list[str] = []
        self._label_id_list: list[str] = []
        self._project_control_id_list: list[str] = []
        # List fields — structured
        self._external_url_list: list[dict] = []
        self._finding_evidence_list: list[CyverFindingEvidence] = []
        self._custom_fields: list[CyverFindingCustomField] = []

        self._exploit_id_list: list[str] = []

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def id(self) -> str | None:
        """The server-assigned UUID of this finding, populated by
        :meth:`from_dict` when the object is constructed from an API response.
        ``None`` for objects created locally before dispatch."""
        return self._id

    @property
    def name(self) -> str:
        """The finding's display name."""
        return self._name

    # ------------------------------------------------------------------
    # Setters — name
    # ------------------------------------------------------------------

    def set_name(self, value: str) -> CyverFinding:
        """
            Update the finding's display name.

            Args:
                value (str): New non-empty display name.

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a non-empty ``str``.
        """
        if not isinstance(value, str) or not value:
            raise CyverDataValidationError(
                "'name' must be a non-empty string.",
                field="name",
                reason="invalid_type" if not isinstance(value, str) else "missing_required",
            )
        self._name = value
        return self

    # ------------------------------------------------------------------
    # Setters — plain string fields
    # ------------------------------------------------------------------

    def set_code(self, value: str) -> CyverFinding:
        """
            Set the finding's internal code reference.

            Args:
                value (str): Code string.

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'code' must be a string, got {type(value).__name__}.",
                field="code",
                reason="invalid_type",
            )
        self._code = value
        return self

    def set_description(self, value: str) -> CyverFinding:
        """
            Set the finding's description.

            Args:
                value (str): Free-text description.

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'description' must be a string, got {type(value).__name__}.",
                field="description",
                reason="invalid_type",
            )
        self._description = value
        return self

    def set_compliance_comment(self, value: str) -> CyverFinding:
        """
            Set the compliance comment.

            Args:
                value (str): Free-text compliance comment.

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'complianceComment' must be a string, got {type(value).__name__}.",
                field="complianceComment",
                reason="invalid_type",
            )
        self._compliance_comment = value
        return self

    def set_impact_description(self, value: str) -> CyverFinding:
        """
            Set the impact description.

            Args:
                value (str): Free-text impact description.

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'impactDescription' must be a string, got {type(value).__name__}.",
                field="impactDescription",
                reason="invalid_type",
            )
        self._impact_description = value
        return self

    def set_likelihood_description(self, value: str) -> CyverFinding:
        """
            Set the likelihood description.

            Args:
                value (str): Free-text likelihood description.

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'likelihoodDescription' must be a string, got {type(value).__name__}.",
                field="likelihoodDescription",
                reason="invalid_type",
            )
        self._likelihood_description = value
        return self

    def set_recommendation(self, value: str) -> CyverFinding:
        """
            Set the remediation recommendation.

            Args:
                value (str): Free-text recommendation.

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'recommendation' must be a string, got {type(value).__name__}.",
                field="recommendation",
                reason="invalid_type",
            )
        self._recommendation = value
        return self

    def set_background_information(self, value: str) -> CyverFinding:
        """
            Set the background information.

            Args:
                value (str): Free-text background information.

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'backgroundInformation' must be a string, got {type(value).__name__}.",
                field="backgroundInformation",
                reason="invalid_type",
            )
        self._background_information = value
        return self

    # ------------------------------------------------------------------
    # Setters — enum-validated integer fields
    # ------------------------------------------------------------------

    def set_type(self, value: int) -> CyverFinding:
        """
            Set the finding type.

            The value must be a non-zero combination of the bit-flags defined
            in :class:`~CyverReporting._finding_type` (any integer from 1 to
            31 with no bits set outside the defined mask).  Multiple types may
            be combined using bitwise OR, e.g.
            ``_finding_type.vulnerability | _finding_type.observation`` (= 5).

            Args:
                value (int): A :class:`~CyverReporting._finding_type` flag or
                    a bitwise OR combination of flags.

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a valid flag
                    combination.
        """
        _validate_finding_type(value, "type")
        self._type = value
        return self

    def set_status(self, value: int) -> CyverFinding:
        """
            Set the finding status.

            The value must be a valid :class:`~CyverReporting._finding_status`
            code (1–14).

            Args:
                value (int): A :class:`~CyverReporting._finding_status`
                    constant (e.g. ``_finding_status.draft`` or ``1``).

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a valid status
                    code.
        """
        _validate_finding_status(value, "status")
        self._status = value
        return self

    def set_severity(self, value: int) -> CyverFinding:
        """
            Set the finding severity.

            The value must be a valid :class:`~CyverReporting._finding_severity`
            code (0–4: Info / Low / Medium / High / Critical).

            Args:
                value (int): A :class:`~CyverReporting._finding_severity`
                    constant (e.g. ``_finding_severity.high`` or ``3``).

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a valid severity
                    code.
        """
        _validate_finding_severity(value, "severity")
        self._severity = value
        return self

    def set_compliance_status(self, value: int) -> CyverFinding:
        """
            Set the finding compliance status.

            The value must be a valid
            :class:`~CyverReporting._finding_compliance_status` code
            (``0`` = Pass, ``1`` = Fail).

            Args:
                value (int): A
                    :class:`~CyverReporting._finding_compliance_status`
                    constant.

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a valid
                    compliance status code.
        """
        _validate_finding_compliance_status(value, "complianceStatus")
        self._compliance_status = value
        return self

    # ------------------------------------------------------------------
    # Setters — plain integer fields
    # ------------------------------------------------------------------

    def set_impact(self, value: int) -> CyverFinding:
        """
            Set the impact rating.

            Args:
                value (int): Integer impact rating as expected by the API.

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not an ``int``
                    (or is a ``bool``).
        """
        if isinstance(value, bool) or not isinstance(value, int):
            raise CyverDataValidationError(
                f"'impact' must be an int, got {type(value).__name__}.",
                field="impact",
                reason="invalid_type",
            )
        self._impact = value
        return self

    def set_likelihood(self, value: int) -> CyverFinding:
        """
            Set the likelihood rating.

            Args:
                value (int): Integer likelihood rating as expected by the API.

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not an ``int``
                    (or is a ``bool``).
        """
        if isinstance(value, bool) or not isinstance(value, int):
            raise CyverDataValidationError(
                f"'likelihood' must be an int, got {type(value).__name__}.",
                field="likelihood",
                reason="invalid_type",
            )
        self._likelihood = value
        return self

    # ------------------------------------------------------------------
    # Setters — CVSS fields
    # ------------------------------------------------------------------

    def set_cvss40_vector(self, value: str) -> CyverFinding:
        """
            Set the CVSS v4.0 vector string.

            The vector must begin with ``CVSS:4.0/`` and contain all eleven
            required base metrics (``AV``, ``AC``, ``AT``, ``PR``, ``UI``,
            ``VC``, ``VI``, ``VA``, ``SC``, ``SI``, ``SA``) with valid values.
            Optional supplemental and environmental metrics are permitted.

            Args:
                value (str): A valid CVSS 4.0 vector string.

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` fails structural or
                    base-metric validation.
        """
        _validate_cvss40_vector(value, "cvss40Vector")
        self._cvss40_vector = value
        return self

    def set_cvss40_score(self, value: float | int) -> CyverFinding:
        """
            Set the CVSS v4.0 score.

            Args:
                value (float | int): Score in the range 0.0–10.0.

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not numeric or is
                    outside 0.0–10.0.
        """
        _validate_cvss_score(value, "cvss40Score")
        self._cvss40_score = value
        return self

    def set_cvss31_vector(self, value: str) -> CyverFinding:
        """
            Set the CVSS v3.1 vector string.

            The vector must begin with ``CVSS:3.1/`` and contain all eight
            required base metrics (``AV``, ``AC``, ``PR``, ``UI``, ``S``,
            ``C``, ``I``, ``A``) with valid values.

            Args:
                value (str): A valid CVSS 3.1 vector string.

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` fails structural or
                    base-metric validation.
        """
        _validate_cvss31_vector(value, "cvss31Vector")
        self._cvss31_vector = value
        return self

    def set_cvss31_score(self, value: float | int) -> CyverFinding:
        """
            Set the CVSS v3.1 score.

            Args:
                value (float | int): Score in the range 0.0–10.0.

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not numeric or is
                    outside 0.0–10.0.
        """
        _validate_cvss_score(value, "cvss31Score")
        self._cvss31_score = value
        return self

    def set_cvss30_vector(self, value: str) -> CyverFinding:
        """
            Set the CVSS v3.0 vector string.

            The vector must begin with ``CVSS:3.0/`` and contain all eight
            required base metrics with valid values.

            Args:
                value (str): A valid CVSS 3.0 vector string.

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` fails structural or
                    base-metric validation.
        """
        _validate_cvss30_vector(value, "cvss30Vector")
        self._cvss30_vector = value
        return self

    def set_cvss30_score(self, value: float | int) -> CyverFinding:
        """
            Set the CVSS v3.0 score.

            Args:
                value (float | int): Score in the range 0.0–10.0.

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not numeric or is
                    outside 0.0–10.0.
        """
        _validate_cvss_score(value, "cvss30Score")
        self._cvss30_score = value
        return self

    def set_cvss20_vector(self, value: str) -> CyverFinding:
        """
            Set the CVSS v2.0 vector string.

            CVSS 2.0 vectors carry no version prefix.  Both the bare form
            (``AV:N/AC:L/Au:N/C:P/I:P/A:P``) and the parenthesised form
            (``(AV:N/AC:L/Au:N/C:P/I:P/A:P)``) are accepted.  All six
            required base metrics (``AV``, ``AC``, ``Au``, ``C``, ``I``,
            ``A``) must be present with valid values.

            Args:
                value (str): A valid CVSS 2.0 vector string.

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` fails structural or
                    base-metric validation.
        """
        _validate_cvss20_vector(value, "cvss20Vector")
        self._cvss20_vector = value
        return self

    def set_cvss20_score(self, value: float | int) -> CyverFinding:
        """
            Set the CVSS v2.0 score.

            Args:
                value (float | int): Score in the range 0.0–10.0.

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not numeric or is
                    outside 0.0–10.0.
        """
        _validate_cvss_score(value, "cvss20Score")
        self._cvss20_score = value
        return self

    # ------------------------------------------------------------------
    # Setters — UUID reference fields
    # ------------------------------------------------------------------

    def set_project_task_id(self, value: str) -> CyverFinding:
        """
            Set the project task UUID this finding belongs to.

            Args:
                value (str): A well-formed UUID string.

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a valid UUID
                    string.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'projectTaskId' must be a string, got {type(value).__name__}.",
                field="projectTaskId",
                reason="invalid_type",
            )
        _validate_uuid(value, "projectTaskId")
        self._project_task_id = value
        return self

    def set_reviewer_id(self, value: str) -> CyverFinding:
        """
            Set the reviewer UUID for this finding.

            Args:
                value (str): A well-formed UUID string.

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a valid UUID
                    string.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"'reviewerId' must be a string, got {type(value).__name__}.",
                field="reviewerId",
                reason="invalid_type",
            )
        _validate_uuid(value, "reviewerId")
        self._reviewer_id = value
        return self

    # ------------------------------------------------------------------
    # Setters — CWE list
    # ------------------------------------------------------------------

    def add_cwe(self, value: str) -> CyverFinding:
        """
            Append a CWE identifier to the CWE list.

            Args:
                value (str): A well-formed CWE identifier (e.g. ``"CWE-79"``).

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a valid CWE
                    identifier.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"Each 'cweList' entry must be a string, got {type(value).__name__}.",
                field="cweList",
                reason="invalid_type",
            )
        _validate_cwe(value, "cweList")
        self._cwe_list.append(value)
        return self

    def set_cwe_list(self, value: list[str]) -> CyverFinding:
        """
            Replace the CWE list with the provided list of CWE identifiers.

            Args:
                value (list[str]): A list of valid CWE identifier strings.

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``list`` or
                    any element is not a valid CWE identifier.
        """
        if not isinstance(value, list):
            raise CyverDataValidationError(
                f"'cweList' must be a list, got {type(value).__name__}.",
                field="cweList",
                reason="invalid_type",
            )
        for i, item in enumerate(value):
            if not isinstance(item, str):
                raise CyverDataValidationError(
                    f"'cweList[{i}]' must be a string, got {type(item).__name__}.",
                    field="cweList",
                    reason="invalid_type",
                )
            _validate_cwe(item, f"cweList[{i}]")
        self._cwe_list = list(value)
        return self

    # ------------------------------------------------------------------
    # Setters — CVE list
    # ------------------------------------------------------------------

    def add_cve(self, value: str) -> CyverFinding:
        """
            Append a CVE identifier to the CVE list.

            Args:
                value (str): A well-formed CVE identifier (e.g.
                    ``"CVE-2024-12345"``).

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a valid CVE
                    identifier.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"Each 'cveList' entry must be a string, got {type(value).__name__}.",
                field="cveList",
                reason="invalid_type",
            )
        _validate_cve(value, "cveList")
        self._cve_list.append(value)
        return self

    def set_cve_list(self, value: list[str]) -> CyverFinding:
        """
            Replace the CVE list with the provided list of CVE identifiers.

            Args:
                value (list[str]): A list of valid CVE identifier strings.

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``list`` or
                    any element is not a valid CVE identifier.
        """
        if not isinstance(value, list):
            raise CyverDataValidationError(
                f"'cveList' must be a list, got {type(value).__name__}.",
                field="cveList",
                reason="invalid_type",
            )
        for i, item in enumerate(value):
            if not isinstance(item, str):
                raise CyverDataValidationError(
                    f"'cveList[{i}]' must be a string, got {type(item).__name__}.",
                    field="cveList",
                    reason="invalid_type",
                )
            _validate_cve(item, f"cveList[{i}]")
        self._cve_list = list(value)
        return self

    # ------------------------------------------------------------------
    # Setters — MITRE ATT&CK lists
    # ------------------------------------------------------------------

    def add_mitre_attack_tactic(self, value: str) -> CyverFinding:
        """
            Append a MITRE ATT&CK tactic identifier to the tactics list.

            Args:
                value (str): A well-formed tactic identifier (e.g. ``"TA0001"``).

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a valid tactic
                    identifier.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"Each 'mitreAttackTacticsList' entry must be a string, "
                f"got {type(value).__name__}.",
                field="mitreAttackTacticsList",
                reason="invalid_type",
            )
        _validate_mitre_tactic(value, "mitreAttackTacticsList")
        self._mitre_attack_tactics_list.append(value)
        return self

    def set_mitre_attack_tactics_list(self, value: list[str]) -> CyverFinding:
        """
            Replace the MITRE ATT&CK tactics list.

            Args:
                value (list[str]): A list of valid tactic identifier strings.

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``list`` or
                    any element is not a valid tactic identifier.
        """
        if not isinstance(value, list):
            raise CyverDataValidationError(
                f"'mitreAttackTacticsList' must be a list, got {type(value).__name__}.",
                field="mitreAttackTacticsList",
                reason="invalid_type",
            )
        for i, item in enumerate(value):
            if not isinstance(item, str):
                raise CyverDataValidationError(
                    f"'mitreAttackTacticsList[{i}]' must be a string, "
                    f"got {type(item).__name__}.",
                    field="mitreAttackTacticsList",
                    reason="invalid_type",
                )
            _validate_mitre_tactic(item, f"mitreAttackTacticsList[{i}]")
        self._mitre_attack_tactics_list = list(value)
        return self

    def add_mitre_attack_technique(self, value: str) -> CyverFinding:
        """
            Append a MITRE ATT&CK technique identifier to the techniques list.

            Args:
                value (str): A well-formed technique or sub-technique identifier
                    (e.g. ``"T1040"`` or ``"T1003.003"``).

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a valid technique
                    identifier.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"Each 'mitreAttackTechniquesList' entry must be a string, "
                f"got {type(value).__name__}.",
                field="mitreAttackTechniquesList",
                reason="invalid_type",
            )
        _validate_mitre_technique(value, "mitreAttackTechniquesList")
        self._mitre_attack_techniques_list.append(value)
        return self

    def set_mitre_attack_techniques_list(self, value: list[str]) -> CyverFinding:
        """
            Replace the MITRE ATT&CK techniques list.

            Args:
                value (list[str]): A list of valid technique identifier strings.

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``list`` or
                    any element is not a valid technique identifier.
        """
        if not isinstance(value, list):
            raise CyverDataValidationError(
                f"'mitreAttackTechniquesList' must be a list, "
                f"got {type(value).__name__}.",
                field="mitreAttackTechniquesList",
                reason="invalid_type",
            )
        for i, item in enumerate(value):
            if not isinstance(item, str):
                raise CyverDataValidationError(
                    f"'mitreAttackTechniquesList[{i}]' must be a string, "
                    f"got {type(item).__name__}.",
                    field="mitreAttackTechniquesList",
                    reason="invalid_type",
                )
            _validate_mitre_technique(item, f"mitreAttackTechniquesList[{i}]")
        self._mitre_attack_techniques_list = list(value)
        return self

    def add_mitre_attack_mitigation(self, value: str) -> CyverFinding:
        """
            Append a MITRE ATT&CK mitigation identifier to the mitigations list.

            Args:
                value (str): A well-formed mitigation identifier (e.g.
                    ``"M1015"``).

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a valid mitigation
                    identifier.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"Each 'mitreAttackMitigationsList' entry must be a string, "
                f"got {type(value).__name__}.",
                field="mitreAttackMitigationsList",
                reason="invalid_type",
            )
        _validate_mitre_mitigation(value, "mitreAttackMitigationsList")
        self._mitre_attack_mitigations_list.append(value)
        return self

    def set_mitre_attack_mitigations_list(self, value: list[str]) -> CyverFinding:
        """
            Replace the MITRE ATT&CK mitigations list.

            Args:
                value (list[str]): A list of valid mitigation identifier strings.

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``list`` or
                    any element is not a valid mitigation identifier.
        """
        if not isinstance(value, list):
            raise CyverDataValidationError(
                f"'mitreAttackMitigationsList' must be a list, "
                f"got {type(value).__name__}.",
                field="mitreAttackMitigationsList",
                reason="invalid_type",
            )
        for i, item in enumerate(value):
            if not isinstance(item, str):
                raise CyverDataValidationError(
                    f"'mitreAttackMitigationsList[{i}]' must be a string, "
                    f"got {type(item).__name__}.",
                    field="mitreAttackMitigationsList",
                    reason="invalid_type",
                )
            _validate_mitre_mitigation(item, f"mitreAttackMitigationsList[{i}]")
        self._mitre_attack_mitigations_list = list(value)
        return self

    # ------------------------------------------------------------------
    # Setters — vulnerability type list
    # ------------------------------------------------------------------

    def add_vulnerability_type(self, value: str) -> CyverFinding:
        """
            Append a vulnerability type string to the list.

            Args:
                value (str): Vulnerability type label.

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``str``.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"Each 'vulnerabilityTypeList' entry must be a string, "
                f"got {type(value).__name__}.",
                field="vulnerabilityTypeList",
                reason="invalid_type",
            )
        self._vulnerability_type_list.append(value)
        return self

    def set_vulnerability_type_list(self, value: list[str]) -> CyverFinding:
        """
            Replace the vulnerability type list.

            Args:
                value (list[str]): A list of vulnerability type strings.

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``list`` or
                    any element is not a ``str``.
        """
        if not isinstance(value, list):
            raise CyverDataValidationError(
                f"'vulnerabilityTypeList' must be a list, got {type(value).__name__}.",
                field="vulnerabilityTypeList",
                reason="invalid_type",
            )
        for i, item in enumerate(value):
            if not isinstance(item, str):
                raise CyverDataValidationError(
                    f"'vulnerabilityTypeList[{i}]' must be a string, "
                    f"got {type(item).__name__}.",
                    field="vulnerabilityTypeList",
                    reason="invalid_type",
                )
        self._vulnerability_type_list = list(value)
        return self

    # ------------------------------------------------------------------
    # Setters — external URL list
    # ------------------------------------------------------------------

    def add_external_url(self, title: str, link: str) -> CyverFinding:
        """
            Append an external reference URL to the list.

            Args:
                title (str): Display title for the link.
                link (str): A valid HTTP or HTTPS URL.

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``title`` is not a ``str``, or
                    ``link`` is not a valid HTTP/HTTPS URL.
        """
        if not isinstance(title, str):
            raise CyverDataValidationError(
                f"'externalUrlList[].title' must be a string, "
                f"got {type(title).__name__}.",
                field="externalUrlList",
                reason="invalid_type",
            )
        if not isinstance(link, str):
            raise CyverDataValidationError(
                f"'externalUrlList[].link' must be a string, "
                f"got {type(link).__name__}.",
                field="externalUrlList",
                reason="invalid_type",
            )
        _validate_url(link, "externalUrlList[].link")
        self._external_url_list.append({"title": title, "link": link})
        return self

    def set_external_url_list(self, value: list[dict]) -> CyverFinding:
        """
            Replace the external URL list.

            Each entry must be a ``dict`` with a ``"title"`` key (``str``) and
            a ``"link"`` key containing a valid HTTP/HTTPS URL string.

            Args:
                value (list[dict]): A list of ``{"title": str, "link": url}``
                    dicts.

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``list``, or
                    any entry is not a ``dict`` with valid ``title`` and
                    ``link`` fields.
        """
        if not isinstance(value, list):
            raise CyverDataValidationError(
                f"'externalUrlList' must be a list, got {type(value).__name__}.",
                field="externalUrlList",
                reason="invalid_type",
            )
        validated: list[dict] = []
        for i, entry in enumerate(value):
            if not isinstance(entry, dict):
                raise CyverDataValidationError(
                    f"'externalUrlList[{i}]' must be a dict, "
                    f"got {type(entry).__name__}.",
                    field="externalUrlList",
                    reason="invalid_type",
                )
            title = entry.get("title")
            link = entry.get("link")
            if not isinstance(title, str):
                raise CyverDataValidationError(
                    f"'externalUrlList[{i}].title' must be a string, "
                    f"got {type(title).__name__}.",
                    field="externalUrlList",
                    reason="invalid_type",
                )
            if not isinstance(link, str):
                raise CyverDataValidationError(
                    f"'externalUrlList[{i}].link' must be a string, "
                    f"got {type(link).__name__}.",
                    field="externalUrlList",
                    reason="invalid_type",
                )
            _validate_url(link, f"externalUrlList[{i}].link")
            validated.append({"title": title, "link": link})
        self._external_url_list = validated
        return self

    # ------------------------------------------------------------------
    # Setters — UUID list fields
    # ------------------------------------------------------------------

    def add_asset_id(self, value: str) -> CyverFinding:
        """
            Append an asset UUID to the asset ID list.

            Args:
                value (str): A well-formed UUID string.

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a valid UUID.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"Each 'assetIdList' entry must be a string, "
                f"got {type(value).__name__}.",
                field="assetIdList",
                reason="invalid_type",
            )
        _validate_uuid(value, "assetIdList")
        self._asset_id_list.append(value)
        return self

    def set_asset_id_list(self, value: list[str]) -> CyverFinding:
        """
            Replace the asset ID list.

            Args:
                value (list[str]): A list of well-formed UUID strings.

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``list`` or
                    any element is not a valid UUID.
        """
        if not isinstance(value, list):
            raise CyverDataValidationError(
                f"'assetIdList' must be a list, got {type(value).__name__}.",
                field="assetIdList",
                reason="invalid_type",
            )
        for i, item in enumerate(value):
            if not isinstance(item, str):
                raise CyverDataValidationError(
                    f"'assetIdList[{i}]' must be a string, got {type(item).__name__}.",
                    field="assetIdList",
                    reason="invalid_type",
                )
            _validate_uuid(item, f"assetIdList[{i}]")
        self._asset_id_list = list(value)
        return self

    def add_label_id(self, value: str) -> CyverFinding:
        """
            Append a label UUID to the label ID list.

            Args:
                value (str): A well-formed UUID string.

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a valid UUID.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"Each 'labelIdList' entry must be a string, "
                f"got {type(value).__name__}.",
                field="labelIdList",
                reason="invalid_type",
            )
        _validate_uuid(value, "labelIdList")
        self._label_id_list.append(value)
        return self

    def set_label_id_list(self, value: list[str]) -> CyverFinding:
        """
            Replace the label ID list.

            Args:
                value (list[str]): A list of well-formed UUID strings.

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``list`` or
                    any element is not a valid UUID.
        """
        if not isinstance(value, list):
            raise CyverDataValidationError(
                f"'labelIdList' must be a list, got {type(value).__name__}.",
                field="labelIdList",
                reason="invalid_type",
            )
        for i, item in enumerate(value):
            if not isinstance(item, str):
                raise CyverDataValidationError(
                    f"'labelIdList[{i}]' must be a string, got {type(item).__name__}.",
                    field="labelIdList",
                    reason="invalid_type",
                )
            _validate_uuid(item, f"labelIdList[{i}]")
        self._label_id_list = list(value)
        return self

    def add_project_control_id(self, value: str) -> CyverFinding:
        """
            Append a project control UUID to the project control ID list.

            Args:
                value (str): A well-formed UUID string.

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a valid UUID.
        """
        if not isinstance(value, str):
            raise CyverDataValidationError(
                f"Each 'projectControlIdList' entry must be a string, "
                f"got {type(value).__name__}.",
                field="projectControlIdList",
                reason="invalid_type",
            )
        _validate_uuid(value, "projectControlIdList")
        self._project_control_id_list.append(value)
        return self

    def set_project_control_id_list(self, value: list[str]) -> CyverFinding:
        """
            Replace the project control ID list.

            Args:
                value (list[str]): A list of well-formed UUID strings.

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``list`` or
                    any element is not a valid UUID.
        """
        if not isinstance(value, list):
            raise CyverDataValidationError(
                f"'projectControlIdList' must be a list, got {type(value).__name__}.",
                field="projectControlIdList",
                reason="invalid_type",
            )
        for i, item in enumerate(value):
            if not isinstance(item, str):
                raise CyverDataValidationError(
                    f"'projectControlIdList[{i}]' must be a string, "
                    f"got {type(item).__name__}.",
                    field="projectControlIdList",
                    reason="invalid_type",
                )
            _validate_uuid(item, f"projectControlIdList[{i}]")
        self._project_control_id_list = list(value)
        return self

    # ------------------------------------------------------------------
    # Setters — nested object list fields
    # ------------------------------------------------------------------

    def add_finding_evidence(self, value: CyverFindingEvidence) -> CyverFinding:
        """
            Append a :class:`CyverFindingEvidence` entry to the evidence list.

            Args:
                value (CyverFindingEvidence): A populated evidence object.

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a
                    :class:`CyverFindingEvidence` instance.
        """
        if not isinstance(value, CyverFindingEvidence):
            raise CyverDataValidationError(
                f"Each 'findingEvidenceList' entry must be a CyverFindingEvidence "
                f"instance, got {type(value).__name__}.",
                field="findingEvidenceList",
                reason="invalid_type",
            )
        self._finding_evidence_list.append(value)
        return self

    def set_finding_evidence_list(
        self, value: list[CyverFindingEvidence]
    ) -> CyverFinding:
        """
            Replace the finding evidence list.

            Args:
                value (list[CyverFindingEvidence]): A list of
                    :class:`CyverFindingEvidence` instances.

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``list`` or
                    any element is not a :class:`CyverFindingEvidence` instance.
        """
        if not isinstance(value, list):
            raise CyverDataValidationError(
                f"'findingEvidenceList' must be a list, got {type(value).__name__}.",
                field="findingEvidenceList",
                reason="invalid_type",
            )
        for i, item in enumerate(value):
            if not isinstance(item, CyverFindingEvidence):
                raise CyverDataValidationError(
                    f"'findingEvidenceList[{i}]' must be a CyverFindingEvidence "
                    f"instance, got {type(item).__name__}.",
                    field="findingEvidenceList",
                    reason="invalid_type",
                )
        self._finding_evidence_list = list(value)
        return self

    def add_custom_field(self, value: CyverFindingCustomField) -> CyverFinding:
        """
            Append a :class:`CyverFindingCustomField` entry to the custom
            fields list.

            Args:
                value (CyverFindingCustomField): A populated custom field
                    object.

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a
                    :class:`CyverFindingCustomField` instance.
        """
        if not isinstance(value, CyverFindingCustomField):
            raise CyverDataValidationError(
                f"Each 'customFields' entry must be a CyverFindingCustomField "
                f"instance, got {type(value).__name__}.",
                field="customFields",
                reason="invalid_type",
            )
        self._custom_fields.append(value)
        return self

    def set_custom_fields(
        self, value: list[CyverFindingCustomField]
    ) -> CyverFinding:
        """
            Replace the custom fields list.

            Args:
                value (list[CyverFindingCustomField]): A list of
                    :class:`CyverFindingCustomField` instances.

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If ``value`` is not a ``list`` or
                    any element is not a :class:`CyverFindingCustomField`
                    instance.
        """
        if not isinstance(value, list):
            raise CyverDataValidationError(
                f"'customFields' must be a list, got {type(value).__name__}.",
                field="customFields",
                reason="invalid_type",
            )
        for i, item in enumerate(value):
            if not isinstance(item, CyverFindingCustomField):
                raise CyverDataValidationError(
                    f"'customFields[{i}]' must be a CyverFindingCustomField "
                    f"instance, got {type(item).__name__}.",
                    field="customFields",
                    reason="invalid_type",
                )
        self._custom_fields = list(value)
        return self

    # ------------------------------------------------------------------
    # Exploit IDs (added with the get_finding_templates admission round)
    # ------------------------------------------------------------------

    @property
    def exploit_id_list(self) -> list[str]:
        """The list of exploit reference UUIDs associated with this finding.

        Populated from the ``exploitIds`` key in finding-template responses.
        Read-only at the property level — mutate via :meth:`add_exploit_id`
        / :meth:`set_exploit_id_list`.
        """
        return list(self._exploit_id_list)

    def add_exploit_id(self, value: str) -> CyverFinding:
        """
            Append an exploit reference UUID to the finding's exploit list.

            Args:
                value (str): A valid UUID string.

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If *value* is not a valid UUID.
        """
        _validate_uuid(value, "exploitIds")
        self._exploit_id_list.append(value)
        return self

    def set_exploit_id_list(self, value: list[str]) -> CyverFinding:
        """
            Replace the entire exploit-id list.

            Each element is UUID-validated.  Passing an empty list clears
            the list.

            Args:
                value (list[str]): A list of valid UUID strings.

            Returns:
                CyverFinding: This instance, for fluent chaining.

            Raises:
                CyverDataValidationError: If *value* is not a list, or any
                    element is not a valid UUID.
        """
        if not isinstance(value, list):
            raise CyverDataValidationError(
                f"'exploitIds' must be a list, got {type(value).__name__}.",
                field="exploitIds",
                reason="invalid_type",
            )
        for entry in value:
            _validate_uuid(entry, "exploitIds")
        self._exploit_id_list = list(value)
        return self

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------

    def validate_for_post(self) -> None:
        """
            Validate that all fields required for a POST (create) request are
            present.

            Currently only checks that ``name`` is set (it is always set at
            construction time, but can be updated via :meth:`set_name`).

            Raises:
                CyverDataValidationError: If ``name`` is empty.
        """
        if not self._name:
            raise CyverDataValidationError(
                "'name' is required for POST requests and must not be empty.",
                field="name",
                reason="missing_required",
            )

    def validate_for_put(self) -> None:
        """
            Validate that all fields required for a PUT (update) request are
            present.

            In addition to the POST requirement, ``id`` must also be set.
            ``id`` is populated automatically by :meth:`from_dict` when the
            object is constructed from an API response.

            Raises:
                CyverDataValidationError: If ``name`` is empty, or ``id`` is
                    not set.
        """
        self.validate_for_post()
        if self._id is None:
            raise CyverDataValidationError(
                "'id' is required for PUT requests. Construct this object via "
                "from_dict() from an API response, or retrieve it with "
                "get_finding_by_id().",
                field="id",
                reason="missing_required",
            )

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        """
            Serialise the finding data to a dictionary ready for the Cyver API.

            Only fields that have been explicitly set are included in the
            output.  ``name`` is always present.  The ``cvss`` nested object
            is included only when at least one CVSS field has been set.

            Returns:
                dict: Finding payload with camelCase API keys.
        """
        result: dict = {"name": self._name}

        if self._code is not None:
            result["code"] = self._code
        if self._description is not None:
            result["description"] = self._description
        if self._type is not None:
            result["type"] = self._type
        if self._status is not None:
            result["status"] = self._status
        if self._severity is not None:
            result["severity"] = self._severity
        if self._compliance_status is not None:
            result["complianceStatus"] = self._compliance_status
        if self._compliance_comment is not None:
            result["complianceComment"] = self._compliance_comment
        if self._impact is not None:
            result["impact"] = self._impact
        if self._impact_description is not None:
            result["impactDescription"] = self._impact_description
        if self._likelihood is not None:
            result["likelihood"] = self._likelihood
        if self._likelihood_description is not None:
            result["likelihoodDescription"] = self._likelihood_description
        if self._recommendation is not None:
            result["recommendation"] = self._recommendation
        if self._background_information is not None:
            result["backgroundInformation"] = self._background_information

        # CVSS nested object — only included when at least one field is set
        cvss: dict = {}
        if self._cvss40_vector is not None:
            cvss["cvss40Vector"] = self._cvss40_vector
        if self._cvss40_score is not None:
            cvss["cvss40Score"] = self._cvss40_score
        if self._cvss31_vector is not None:
            cvss["cvss31Vector"] = self._cvss31_vector
        if self._cvss31_score is not None:
            cvss["cvss31Score"] = self._cvss31_score
        if self._cvss30_vector is not None:
            cvss["cvss30Vector"] = self._cvss30_vector
        if self._cvss30_score is not None:
            cvss["cvss30Score"] = self._cvss30_score
        if self._cvss20_vector is not None:
            cvss["cvss20Vector"] = self._cvss20_vector
        if self._cvss20_score is not None:
            cvss["cvss20Score"] = self._cvss20_score
        if cvss:
            result["cvss"] = cvss

        if self._project_task_id is not None:
            result["projectTaskId"] = self._project_task_id
        if self._reviewer_id is not None:
            result["reviewerId"] = self._reviewer_id
        if self._cwe_list:
            result["cweList"] = list(self._cwe_list)
        if self._cve_list:
            result["cveList"] = list(self._cve_list)
        if self._mitre_attack_tactics_list:
            result["mitreAttackTacticsList"] = list(self._mitre_attack_tactics_list)
        if self._mitre_attack_techniques_list:
            result["mitreAttackTechniquesList"] = list(
                self._mitre_attack_techniques_list
            )
        if self._mitre_attack_mitigations_list:
            result["mitreAttackMitigationsList"] = list(
                self._mitre_attack_mitigations_list
            )
        if self._vulnerability_type_list:
            result["vulnerabilityTypeList"] = list(self._vulnerability_type_list)
        if self._external_url_list:
            result["externalUrlList"] = [
                dict(entry) for entry in self._external_url_list
            ]
        if self._asset_id_list:
            result["assetIdList"] = list(self._asset_id_list)
        if self._label_id_list:
            result["labelIdList"] = list(self._label_id_list)
        if self._project_control_id_list:
            result["projectControlIdList"] = list(self._project_control_id_list)
        if self._finding_evidence_list:
            result["findingEvidenceList"] = [
                ev.to_dict() for ev in self._finding_evidence_list
            ]
        if self._custom_fields:
            result["customFields"] = [
                cf.to_dict() for cf in self._custom_fields
            ]
        if self._exploit_id_list:
            result["exploitIds"] = list(self._exploit_id_list)

        return result

    # ------------------------------------------------------------------
    # Deserialisation
    # ------------------------------------------------------------------

    @classmethod
    def from_dict(cls, data: dict, *, as_template: bool = False) -> CyverFinding:
        """
            Construct a ``CyverFinding`` from an API response dictionary.

            All recognised fields are mapped to their corresponding private
            attributes directly (bypassing setters) so that values already
            validated by the server are not re-validated on ingestion.

            ``findingEvidenceList`` entries are deserialised as
            :class:`CyverFindingEvidence` objects; ``customFields`` entries
            are deserialised as :class:`CyverFindingCustomField` objects.

            **Shape-tolerance.**  The Cyver API uses two slightly different
            wire shapes for findings:

            * **Project findings** (returned by
              ``PentesterSession.get_findings`` etc.) use camelCase keys
              with a nested ``cvss`` sub-object and ``*List`` suffixes
              (``cweList``, ``mitreAttackTacticsList``, …).
            * **Finding templates** (returned by
              ``PentesterPortal.get_finding_templates``) use camelCase keys
              with **flat top-level CVSS fields** carrying a server-side
              typo (``cvsS40Vector`` — note the capital S) and *finding-*
              prefixed list keys (``findingCWEs``, ``findingMitreAttackTactics``,
              …).  Templates also carry a ``criticality`` integer in place
              of ``severity``, an ``externalUrl`` (singular) list, a
              ``vulnerabilityTypes`` (singular) list, and a
              ``controlTemplatesIds`` list (folded into
              ``_project_control_id_list``).  ``labels`` arrives as a CSV
              string rather than a list of UUIDs.

            ``from_dict`` reads each of these alternative key shapes
            transparently, falling back from the project-finding form to
            the template form when the former is absent.  Callers do not
            need to know which shape the server returned.

            **Template mode (``as_template=True``).**  Set when hydrating
            a *finding template* response that the caller intends to use
            as the seed for ``create_finding`` (i.e. *fetch template →
            modify → create new project finding from it*).  In template
            mode:

            * The ``guid`` / ``id`` field in the response is **ignored**;
              the resulting instance has ``id is None`` so the server
              assigns a new UUID at creation time.
            * The ``status`` field in the response is **ignored** and
              ``_status`` is set to :attr:`_finding_status.draft` (= 1)
              so the new finding is created in Draft state.

            Args:
                data (dict): A finding dict as returned by the Cyver API.
                as_template (bool, keyword-only): When ``True``, treat
                    *data* as a finding-template response and apply the
                    template-mode behaviour described above.  Defaults to
                    ``False`` (project-finding mode), which is the
                    historical behaviour.

            Returns:
                CyverFinding: A fully populated instance.  In project-finding
                    mode, ``id`` is set to the server-assigned UUID when
                    present in *data*; in template mode, ``id`` is ``None``
                    and ``status`` is forced to Draft.
        """
        obj = cls(data["name"])
        if as_template:
            # Template mode: discard the template's guid + status entirely.
            # The resulting CyverFinding is ready to be POSTed via
            # create_finding — server assigns a fresh id, and the new
            # project finding starts in Draft state.
            obj._id     = None
            obj._status = _finding_status.draft
        else:
            obj._id     = data.get("id")
            obj._status = _fd_optional_int(data, "status")
        obj._code = _fd_optional_str(data, "code")
        obj._description = _fd_optional_str(data, "description")
        obj._type = _fd_optional_int(data, "type")
        # Template responses carry `criticality` in place of `severity`;
        # both share the same integer value space, so we fold them into
        # the existing _severity slot.  Project findings carry `severity`
        # and never carry `criticality`, so the fallback only fires for
        # template responses.
        obj._severity = _fd_optional_int(data, "severity")
        if obj._severity is None:
            obj._severity = _fd_optional_int(data, "criticality")
        obj._compliance_status = _fd_optional_int(data, "complianceStatus")
        obj._compliance_comment = _fd_optional_str(data, "complianceComment")
        obj._impact = _fd_optional_int(data, "impact")
        obj._impact_description = _fd_optional_str(data, "impactDescription")
        obj._likelihood = _fd_optional_int(data, "likelihood")
        obj._likelihood_description = _fd_optional_str(data, "likelihoodDescription")
        obj._recommendation = _fd_optional_str(data, "recommendation")
        obj._background_information = _fd_optional_str(data, "backgroundInformation")

        # CVSS — try the nested project-finding shape first; fall back to
        # the flat template shape (with the server-side `cvsS` typo).
        cvss = data.get("cvss") or {}
        obj._cvss40_vector = cvss.get("cvss40Vector") or data.get("cvsS40Vector")
        obj._cvss40_score  = cvss.get("cvss40Score")  if cvss.get("cvss40Score")  is not None else data.get("cvsS40Score")
        obj._cvss31_vector = cvss.get("cvss31Vector") or data.get("cvsS31Vector")
        obj._cvss31_score  = cvss.get("cvss31Score")  if cvss.get("cvss31Score")  is not None else data.get("cvsS31Score")
        obj._cvss30_vector = cvss.get("cvss30Vector") or data.get("cvsS30Vector")
        obj._cvss30_score  = cvss.get("cvss30Score")  if cvss.get("cvss30Score")  is not None else data.get("cvsS30Score")
        obj._cvss20_vector = cvss.get("cvss20Vector") or data.get("cvsS20Vector")
        obj._cvss20_score  = cvss.get("cvss20Score")  if cvss.get("cvss20Score")  is not None else data.get("cvsS20Score")

        obj._project_task_id = _fd_optional_uuid(data, "projectTaskId")
        obj._reviewer_id = _fd_optional_uuid(data, "reviewerId")

        # Lists with dual key shapes: project-finding uses *List suffixes,
        # template uses finding* prefixes.
        obj._cwe_list = list(data.get("cweList") or data.get("findingCWEs") or [])
        obj._cve_list = list(data.get("cveList") or data.get("findingCVEs") or [])
        obj._mitre_attack_tactics_list = list(
            data.get("mitreAttackTacticsList") or data.get("findingMitreAttackTactics") or []
        )
        obj._mitre_attack_techniques_list = list(
            data.get("mitreAttackTechniquesList") or data.get("findingMitreAttackTechniques") or []
        )
        obj._mitre_attack_mitigations_list = list(
            data.get("mitreAttackMitigationsList") or data.get("findingMitreAttackMitigations") or []
        )
        obj._vulnerability_type_list = list(
            data.get("vulnerabilityTypeList") or data.get("vulnerabilityTypes") or []
        )
        obj._external_url_list = list(
            data.get("externalUrlList") or data.get("externalUrl") or []
        )
        obj._asset_id_list = _fd_uuid_list(data, "assetIdList")

        # Labels: project-finding shape is `labelIdList` (list of UUIDs);
        # template shape is `labels` as a comma-separated string.  Parse
        # the string into a list, stripping whitespace and dropping empty
        # tokens.  No UUID validation here because the template's CSV may
        # carry freeform tag names rather than UUIDs.
        if "labelIdList" in data and data["labelIdList"]:
            obj._label_id_list = _fd_uuid_list(data, "labelIdList")
        elif isinstance(data.get("labels"), str) and data["labels"]:
            obj._label_id_list = [
                token.strip() for token in data["labels"].split(",") if token.strip()
            ]
        else:
            obj._label_id_list = []

        # Project control IDs: fold template's `controlTemplatesIds` into
        # the same slot as project-finding's `projectControlIdList`.  The
        # two are semantically distinct (controls a *template* references
        # vs. project-controls a *finding* satisfies), but folded here per
        # the "fit templates into existing CyverFinding" direction.
        if "projectControlIdList" in data and data["projectControlIdList"]:
            obj._project_control_id_list = _fd_uuid_list(data, "projectControlIdList")
        elif data.get("controlTemplatesIds"):
            obj._project_control_id_list = _fd_uuid_list(data, "controlTemplatesIds")
        else:
            obj._project_control_id_list = []

        obj._finding_evidence_list = _fd_nested_list(
            data, "findingEvidenceList", CyverFindingEvidence
        )
        obj._custom_fields = _fd_nested_list(
            data, "customFields", CyverFindingCustomField
        )

        # Exploit references — template-only on the wire, but stored on
        # CyverFinding so they round-trip cleanly through to_dict.
        obj._exploit_id_list = list(data.get("exploitIds") or [])

        return obj

    def __repr__(self) -> str:
        set_fields = ["name"]
        for attr, key in [
            (self._code, "code"),
            (self._type, "type"),
            (self._status, "status"),
            (self._severity, "severity"),
            (self._compliance_status, "complianceStatus"),
            (self._impact, "impact"),
            (self._likelihood, "likelihood"),
            (self._cvss40_vector, "cvss40Vector"),
            (self._cvss31_vector, "cvss31Vector"),
            (self._cvss30_vector, "cvss30Vector"),
            (self._cvss20_vector, "cvss20Vector"),
            (self._project_task_id, "projectTaskId"),
            (self._reviewer_id, "reviewerId"),
        ]:
            if attr is not None:
                set_fields.append(key)
        for lst, key in [
            (self._cwe_list, "cweList"),
            (self._cve_list, "cveList"),
            (self._mitre_attack_tactics_list, "mitreAttackTacticsList"),
            (self._mitre_attack_techniques_list, "mitreAttackTechniquesList"),
            (self._mitre_attack_mitigations_list, "mitreAttackMitigationsList"),
            (self._vulnerability_type_list, "vulnerabilityTypeList"),
            (self._external_url_list, "externalUrlList"),
            (self._asset_id_list, "assetIdList"),
            (self._label_id_list, "labelIdList"),
            (self._project_control_id_list, "projectControlIdList"),
            (self._finding_evidence_list, "findingEvidenceList"),
            (self._custom_fields, "customFields"),
        ]:
            if lst:
                set_fields.append(f"{key}[{len(lst)}]")
        prefix = f"id={self._id!r}, " if self._id else ""
        return f"CyverFinding({prefix}name={self._name!r}, fields={set_fields})"
