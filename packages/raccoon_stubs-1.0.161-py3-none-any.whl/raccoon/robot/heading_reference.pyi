from __future__ import annotations
import math as math
import raccoon.robot.service
from raccoon.robot.service import RobotService
__all__: list[str] = ['HeadingReferenceService', 'RobotService', 'math']
class HeadingReferenceService(raccoon.robot.service.RobotService):
    """
    Stores an absolute IMU heading reference and computes turns relative to it.
    
    Use ``robot.get_service(HeadingReferenceService)`` to access.
    """
    def __init__(self, robot: GenericRobot) -> None:
        ...
    def compute_turn(self, target_deg: float, force_direction: str | None = None) -> float:
        """
        Compute the signed relative turn angle to reach *target_deg* from reference.
        
        Args:
            target_deg: Desired heading in degrees relative to the reference.
            force_direction: ``"left"`` to force CCW, ``"right"`` to force CW,
                or ``None`` (default) for shortest path.
        
        Returns:
            Signed angle in degrees (positive = CCW / left, negative = CW / right).
            Normalized to [-180, 180] for shortest path, or adjusted to the
            forced direction.
        
        Raises:
            RuntimeError: If no reference has been marked yet.
        """
    def mark(self, origin_offset_deg: float = 0.0, positive_direction: str = 'left') -> None:
        """
        Capture the current absolute IMU heading as the reference.
        
        Args:
            origin_offset_deg: Offset in degrees added to the captured heading.
                Use this to define a consistent origin regardless of the robot's
                physical starting rotation.  For example, if the robot is placed
                at 30° to the board edge but you want 0° to mean "along the
                board edge", pass ``origin_offset_deg=-30``.
            positive_direction: Which physical direction corresponds to positive
                angles.  ``"left"`` (default) means CCW is positive, matching the
                standard mathematical convention.  ``"right"`` flips the sign so
                CW is positive.
        """
    def target_absolute_rad(self, target_deg: float) -> float:
        """
        Convert a relative target (degrees from reference) to absolute IMU radians.
        
        Used by motion controllers that want to *hold* an absolute heading
        rather than *turn* to it — they need the raw absolute target
        without [-180, 180] normalisation, since the chassis controller
        carries continuous heading state across consecutive commands.
        
        Raises:
            RuntimeError: If no reference has been marked yet.
        """
    @property
    def reference_deg(self) -> float | None:
        """
        The stored reference in degrees, or None if not set.
        """
def _normalize_angle(angle: float) -> float:
    """
    Normalize angle to [-pi, pi].
    """
