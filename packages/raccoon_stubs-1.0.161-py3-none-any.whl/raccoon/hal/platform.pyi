"""
Hardware health-check API
"""
from __future__ import annotations
import typing
__all__: list[str] = ['Component', 'ComponentStatus', 'IMU', 'MOTORS', 'Platform', 'ProbeFailedError', 'ProbeOptions', 'ProbeResult', 'STM32_BRIDGE']
class Component:
    """
    Members:
    
      STM32_BRIDGE
    
      IMU
    
      MOTORS
    """
    IMU: typing.ClassVar[Component]  # value = <Component.IMU: 1>
    MOTORS: typing.ClassVar[Component]  # value = <Component.MOTORS: 2>
    STM32_BRIDGE: typing.ClassVar[Component]  # value = <Component.STM32_BRIDGE: 0>
    __members__: typing.ClassVar[dict[str, Component]]  # value = {'STM32_BRIDGE': <Component.STM32_BRIDGE: 0>, 'IMU': <Component.IMU: 1>, 'MOTORS': <Component.MOTORS: 2>}
    def __eq__(self, other: typing.Any) -> bool:
        ...
    def __getstate__(self) -> int:
        ...
    def __hash__(self) -> int:
        ...
    def __index__(self) -> int:
        ...
    def __init__(self, value: int) -> None:
        ...
    def __int__(self) -> int:
        ...
    def __ne__(self, other: typing.Any) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def __setstate__(self, state: int) -> None:
        ...
    def __str__(self) -> str:
        ...
    @property
    def name(self) -> str:
        ...
    @property
    def value(self) -> int:
        ...
class ComponentStatus:
    def __repr__(self) -> str:
        ...
    @property
    def component(self) -> Component:
        ...
    @property
    def detail(self) -> str:
        ...
    @property
    def ok(self) -> bool:
        ...
class Platform:
    @staticmethod
    def clear_mock_probe_failures() -> None:
        ...
    @staticmethod
    def probe(options: ProbeOptions = ...) -> ProbeResult:
        ...
    @staticmethod
    def require_healthy(options: ProbeOptions = ...) -> None:
        ...
    @staticmethod
    def set_mock_probe_failure(component: Component, fail: bool) -> None:
        ...
class ProbeFailedError(RuntimeError):
    pass
class ProbeOptions:
    imu_timeout_ms: int
    motor_timeout_ms: int
    require_imu: bool
    require_motors: bool
    require_stm32: bool
    stm32_timeout_ms: int
    def __init__(self) -> None:
        ...
class ProbeResult:
    def __bool__(self) -> bool:
        ...
    def __repr__(self) -> str:
        ...
    def failed_components(self) -> list[ComponentStatus]:
        ...
    def summary(self) -> str:
        ...
    @property
    def components(self) -> list[ComponentStatus]:
        ...
    @property
    def ok(self) -> bool:
        ...
IMU: Component  # value = <Component.IMU: 1>
MOTORS: Component  # value = <Component.MOTORS: 2>
STM32_BRIDGE: Component  # value = <Component.STM32_BRIDGE: 0>
