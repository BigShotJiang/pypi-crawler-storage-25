"""
Merge pass — collapse adjacent same-type segments.

Two segments are merge-eligible if they share kind/axis/direction, both have
known endpoints, and neither has a stop condition.  ``SideAction`` and
deferred-placeholder (``None``) entries act as merge barriers.
"""
from __future__ import annotations
from dataclasses import replace
from raccoon.step.motion.path.ir import Segment
import typing
__all__: list[str] = ['MergePass', 'PathNode', 'Segment', 'can_merge', 'merge_two', 'replace', 'run_merge']
class MergePass:
    """
    Compiler pass that runs the merge transform.
    """
    name: typing.ClassVar[str] = 'merge'
    def run(self, nodes: list[PathNode | None]) -> list[PathNode | None]:
        ...
def can_merge(a: Segment, b: Segment) -> bool:
    """
    Return True if two adjacent known-endpoint segments can be merged.
    """
def merge_two(a: Segment, b: Segment) -> Segment:
    """
    Merge two compatible segments. Precondition: ``can_merge(a, b)``.
    """
def run_merge(nodes: list[PathNode | None]) -> list[PathNode | None]:
    """
    Collapse adjacent same-type/same-direction segments with no conditions.
    """
PathNode: typing._UnionGenericAlias  # value = typing.Union[raccoon.step.motion.path.ir.Segment, raccoon.step.motion.path.ir.SideAction]
