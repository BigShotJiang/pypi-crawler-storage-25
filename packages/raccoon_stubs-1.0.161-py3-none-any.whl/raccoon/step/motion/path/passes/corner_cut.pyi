"""
Corner-cut pass — replace ``linear + turn + linear`` with ``linear + arc + linear``.

Cuts ``cut_m`` from each straight leg at a known-angle corner and inserts a
circular arc of radius ``R = cut_m / tan(|θ| / 2)``.  Only triples with known
endpoints, no conditions, and matching axis/direction on the linears are
eligible.  ``SideAction`` and deferred-placeholder (``None``) entries act as
barriers.
"""
from __future__ import annotations
from dataclasses import replace
import logging as logging
import math as math
from raccoon.motion import LinearAxis
from raccoon.step.motion.path.ir import Segment
import typing
__all__: list[str] = ['CornerCutPass', 'LinearAxis', 'PathNode', 'Segment', 'logging', 'math', 'replace', 'run_corner_cut', 'try_corner_arc']
class CornerCutPass:
    """
    Compiler pass that replaces straight-turn-straight corners with arcs.
    """
    name: typing.ClassVar[str] = 'corner_cut'
    def __init__(self, cut_m: float):
        ...
    def run(self, nodes: list[PathNode | None]) -> list[PathNode | None]:
        ...
def run_corner_cut(nodes: list[PathNode | None], cut_m: float) -> list[PathNode | None]:
    """
    Replace ``linear+turn+linear`` triples with ``linear+arc+linear``.
    """
def try_corner_arc(lin1: Segment, turn: Segment, lin2: Segment, cut_m: float) -> tuple[Segment, Segment, Segment] | None:
    """
    Return ``(new_lin1, arc, new_lin2)`` for a corner cut, or ``None``.
    
    Geometry: cutting ``cut_m`` from each leg at the corner requires an arc of
    radius ``R = cut_m / tan(|θ| / 2)``.  Both linears must be the same axis
    and direction and have enough distance to accommodate the cut.
    """
PathNode: typing._UnionGenericAlias  # value = typing.Union[raccoon.step.motion.path.ir.Segment, raccoon.step.motion.path.ir.SideAction]
_log: logging.Logger  # value = <Logger raccoon.step.motion.path.passes.corner_cut (INFO)>
