"""
Spline-conversion pass — translate a linear/turn sequence into a SplinePath.

Unlike merge / corner-cut (pure node-list transforms), this pass *replaces*
the entire path with a single spline-driven step.  It is therefore a
"terminal" transform — typically the last entry in a pipeline that opts in
to spline mode.
"""
from __future__ import annotations
import math as math
from raccoon.motion import LinearAxis
from raccoon.step.motion.path.ir import Segment
from raccoon.step.motion.path.ir import SideAction
import typing
__all__: list[str] = ['LinearAxis', 'PathNode', 'Segment', 'SideAction', 'build_spline_step', 'math', 'segments_to_spline_waypoints']
def build_spline_step(nodes: list[PathNode | None]) -> 'SplinePath':
    """
    Build a SplinePath from a fully-splinifiable node list.
    
    Raises ``ValueError`` for any node that cannot be represented as a
    waypoint: deferred placeholders, side actions, arc segments, condition-
    based segments, or segments with unknown endpoints.  A minimum of 2
    linear segments is required so the spline has at least 2 explicit
    waypoints.
    """
def segments_to_spline_waypoints(segments: list[Segment]) -> list[tuple[float, float]]:
    """
    Compute ``(forward_cm, left_cm)`` waypoints from a linear/turn sequence.
    
    Turns update the running heading but do not produce waypoints; each
    linear segment appends its endpoint.  The robot's start position
    ``(0, 0)`` is *not* included — it is the implicit origin for ``spline()``.
    
    Coordinate system: +forward is the robot's initial heading, +left is
    90° CCW of that (same convention as ``spline()`` waypoints).
    """
PathNode: typing._UnionGenericAlias  # value = typing.Union[raccoon.step.motion.path.ir.Segment, raccoon.step.motion.path.ir.SideAction]
