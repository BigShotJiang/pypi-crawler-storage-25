"""
Intermediate representation for the motion path pipeline.

Compiler passes operate on ``list[PathNode]``:

- ``Segment``    — one motion primitive (linear / turn / arc / follow_line / spline).
- ``SideAction`` — a non-motion step pinned to a transition point.
- ``None``       — placeholder for a deferred step resolved at runtime.

These types are intentionally pure data — they hold no robot reference and
no runtime state.  Anything stateful (current motion, world tracker) lives
in the executor / middleware layer.
"""
from __future__ import annotations
import dataclasses
from dataclasses import dataclass
from dataclasses import field
from raccoon.motion import LinearAxis
import typing
__all__: list[str] = ['Correction', 'LinearAxis', 'PathNode', 'SENTINEL_DISTANCE_M', 'Segment', 'SideAction', 'dataclass', 'field']
class Correction:
    """
    World-frame parameter adjustment for the next segment.
    
    Produced by middleware (e.g. ``WorldCorrectionMiddleware``) and consumed
    by the motion factory when constructing the next segment's controller.
    """
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'distance_adjust_m': Field(name='distance_adjust_m',type='float',default=0.0,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'heading_target_rad': Field(name='heading_target_rad',type='Optional[float]',default=None,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'angle_adjust_rad': Field(name='angle_adjust_rad',type='float',default=0.0,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('distance_adjust_m', 'heading_target_rad', 'angle_adjust_rad')
    angle_adjust_rad: typing.ClassVar[float] = 0.0
    distance_adjust_m: typing.ClassVar[float] = 0.0
    heading_target_rad = None
    def __eq__(self, other):
        ...
    def __init__(self, distance_adjust_m: float = 0.0, heading_target_rad: float | None = None, angle_adjust_rad: float = 0.0) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class Segment:
    """
    One motion primitive extracted from a Step into the pipeline IR.
    
    Field semantics depend on ``kind``:
    
    - ``"linear"``      — ``axis``, ``sign``, ``distance_m``, ``speed_scale``,
                          optional ``heading_deg`` and ``condition``.
    - ``"turn"``        — ``sign``, ``angle_rad``, ``speed_scale``,
                          optional ``condition``.
    - ``"arc"``         — ``radius_m``, ``arc_angle_rad``, ``speed_scale``,
                          ``lateral``.
    - ``"follow_line"`` — same shape as ``"linear"`` plus ``opaque_step``
                          (the original LineFollow step). Adapter delegates
                          lifecycle to the step's ``on_start``/``on_update``.
    - ``"spline"``      — ``opaque_step`` (the SplinePath step). No warm-start.
    """
    _SENTINEL_DISTANCE_M: typing.ClassVar[float] = 100.0
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'kind': Field(name='kind',type='str',default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'axis': Field(name='axis',type='Optional[LinearAxis]',default=None,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'sign': Field(name='sign',type='float',default=1.0,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'distance_m': Field(name='distance_m',type='Optional[float]',default=None,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'speed_scale': Field(name='speed_scale',type='float',default=1.0,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'heading_deg': Field(name='heading_deg',type='Optional[float]',default=None,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'angle_rad': Field(name='angle_rad',type='Optional[float]',default=None,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'radius_m': Field(name='radius_m',type='Optional[float]',default=None,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'arc_angle_rad': Field(name='arc_angle_rad',type='Optional[float]',default=None,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'lateral': Field(name='lateral',type='bool',default=False,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'condition': Field(name='condition',type="Optional['StopCondition']",default=None,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'has_known_endpoint': Field(name='has_known_endpoint',type='bool',default=True,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'opaque_step': Field(name='opaque_step',type="Optional['Step']",default=None,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=False,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('kind', 'axis', 'sign', 'distance_m', 'speed_scale', 'heading_deg', 'angle_rad', 'radius_m', 'arc_angle_rad', 'lateral', 'condition', 'has_known_endpoint', 'opaque_step')
    angle_rad = None
    arc_angle_rad = None
    axis = None
    condition = None
    distance_m = None
    has_known_endpoint: typing.ClassVar[bool] = True
    heading_deg = None
    lateral: typing.ClassVar[bool] = False
    opaque_step = None
    radius_m = None
    sign: typing.ClassVar[float] = 1.0
    speed_scale: typing.ClassVar[float] = 1.0
    def __eq__(self, other):
        ...
    def __init__(self, kind: str, axis: LinearAxis | None = None, sign: float = 1.0, distance_m: float | None = None, speed_scale: float = 1.0, heading_deg: float | None = None, angle_rad: float | None = None, radius_m: float | None = None, arc_angle_rad: float | None = None, lateral: bool = False, condition: 'StopCondition' | None = None, has_known_endpoint: bool = True, opaque_step: 'Step' | None = None) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class SideAction:
    """
    A non-motion step pinned to a transition point in the path.
    
    ``is_background=True``  → fired as an asyncio task and not awaited inline.
    ``is_background=False`` → awaited inline before the next segment starts.
    """
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'step': Field(name='step',type="'Step'",default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'is_background': Field(name='is_background',type='bool',default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('step', 'is_background')
    def __eq__(self, other):
        ...
    def __init__(self, step: 'Step', is_background: bool) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
PathNode: typing._UnionGenericAlias  # value = typing.Union[raccoon.step.motion.path.ir.Segment, raccoon.step.motion.path.ir.SideAction]
SENTINEL_DISTANCE_M: float = 100.0
