"""
World-frame error correction middleware.

Tracks the difference between the geometrically-expected pose (where the
robot *should* be after each segment, based on segment parameters) and the
actually-measured pose (from odometry + absolute heading), and produces
``Correction`` hints that the motion factory consumes when constructing the
next motion.

The tracker has to deal with one quirk: cold-start transitions reset the
odometry counter to 0.  Position is therefore accumulated across resets in
``_accumulated_x/y`` rather than read directly from ``odometry.get_pose()``.
Heading uses ``getAbsoluteHeading()`` which is reset-immune.
"""
from __future__ import annotations
import logging as logging
import math as math
from raccoon.motion import LinearAxis
from raccoon.step.motion.path.ir import Correction
from raccoon.step.motion.path.ir import Segment
import typing
__all__: list[str] = ['Correction', 'LinearAxis', 'Segment', 'WorldCorrectionMiddleware', 'WorldPoseTracker', 'logging', 'math', 'wrap_angle']
class WorldCorrectionMiddleware:
    """
    Closes the world-frame error loop across segment transitions.
    
    Maintains an internal ``WorldPoseTracker`` initialized at path start,
    advances it after each completed segment, and emits a ``Correction``
    hint before each non-first segment so the motion factory can offset
    the next motion's distance/heading/angle parameters.
    """
    def __init__(self) -> None:
        ...
    def on_cold_start(self, seg: Segment, robot: 'GenericRobot') -> None:
        ...
    def on_path_end(self, robot: 'GenericRobot') -> None:
        ...
    def on_path_start(self, robot: 'GenericRobot') -> None:
        ...
    def on_segment_end(self, seg: Segment, robot: 'GenericRobot') -> None:
        ...
    def on_segment_start(self, seg: Segment, is_first: bool, robot: 'GenericRobot') -> Correction | None:
        ...
    @property
    def tracker(self) -> WorldPoseTracker | None:
        """
        Expose the underlying tracker for diagnostics/inspection.
        """
class WorldPoseTracker:
    """
    Track expected vs actual world-frame pose across segment transitions.
    
    Position is tracked by accumulating ``getPose().position`` snapshots
    across odometry resets (cold starts).  Heading uses
    ``getAbsoluteHeading()`` which is reset-immune.
    """
    MAX_DISTANCE_CORRECTION_M: typing.ClassVar[float] = 0.03
    MAX_HEADING_CORRECTION_RAD: typing.ClassVar[float] = 0.087
    MAX_TURN_CORRECTION_RAD: typing.ClassVar[float] = 0.087
    def __init__(self, start_heading: float) -> None:
        ...
    def advance_expected(self, seg: Segment) -> None:
        """
        Project expected pose forward by the completed segment's geometry.
        """
    def compute_correction(self, robot: 'GenericRobot', next_seg: Segment) -> Correction:
        """
        Compute parameter adjustments for the next segment.
        """
    def get_actual_heading(self, robot: 'GenericRobot') -> float:
        """
        Get actual absolute heading.
        """
    def get_actual_xy(self, robot: 'GenericRobot') -> tuple[float, float]:
        """
        Get actual world-frame position (accumulated across resets).
        """
    def reset_expected_to_actual(self, robot: 'GenericRobot') -> None:
        """
        Set expected = actual (when we can't predict the endpoint).
        """
    def snapshot_before_cold_start(self, robot: 'GenericRobot') -> None:
        """
        Accumulate world position before an odometry reset (cold start).
        """
def wrap_angle(a: float) -> float:
    """
    Wrap angle to ``[-pi, pi]``.
    """
_log: logging.Logger  # value = <Logger raccoon.step.motion.path.middleware.world_correction (INFO)>
