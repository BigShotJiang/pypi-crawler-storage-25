"""
Motion path compilation pipeline.

The pipeline turns a tree of Step objects into an executable plan through a
sequence of compiler passes (lowering, merge, corner-cut, spline, ...) and
runs it via PathExecutor with optional segment middlewares (world-frame
correction, telemetry, ...).

Public API:
    Segment, SideAction, PathNode, Correction   — IR types
    CompilerPass, CompiledPlan, PathCompiler    — compilation
    PathExecutor                                 — runtime
    PathMiddleware, WorldCorrectionMiddleware   — middleware protocol + builtin
    create_motion                                — motion factory
"""
from __future__ import annotations
from raccoon.step.motion.path.compiler import CompiledPlan
from raccoon.step.motion.path.compiler import CompilerPass
from raccoon.step.motion.path.compiler import PathCompiler
from raccoon.step.motion.path.executor import PathExecutor
from raccoon.step.motion.path.ir import Correction
from raccoon.step.motion.path.ir import Segment
from raccoon.step.motion.path.ir import SideAction
from raccoon.step.motion.path.middleware import PathMiddleware
from raccoon.step.motion.path.middleware.world_correction import WorldCorrectionMiddleware
from raccoon.step.motion.path.middleware.world_correction import WorldPoseTracker
from raccoon.step.motion.path.motion_factory import LineFollowAdapter
from raccoon.step.motion.path.motion_factory import SplineAdapter
from raccoon.step.motion.path.motion_factory import create_motion
import typing
from . import compiler
from . import executor
from . import ir
from . import middleware
from . import motion_factory
from . import passes
__all__: list = ['Segment', 'SideAction', 'PathNode', 'Correction', 'SENTINEL_DISTANCE_M', 'CompilerPass', 'CompiledPlan', 'PathCompiler', 'PathExecutor', 'create_motion', 'LineFollowAdapter', 'SplineAdapter', 'OVERSHOOT_M', 'OVERSHOOT_RAD', 'PathMiddleware', 'WorldCorrectionMiddleware', 'WorldPoseTracker']
OVERSHOOT_M: float = 1.0
OVERSHOOT_RAD: float = 3.0
PathNode: typing._UnionGenericAlias  # value = typing.Union[raccoon.step.motion.path.ir.Segment, raccoon.step.motion.path.ir.SideAction]
SENTINEL_DISTANCE_M: float = 100.0
