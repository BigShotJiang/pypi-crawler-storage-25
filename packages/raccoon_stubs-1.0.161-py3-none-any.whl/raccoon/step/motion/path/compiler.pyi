"""
PathCompiler — turns a list of Steps into a CompiledPlan.

The compiler is a thin orchestrator: it lowers the input Step tree into the
IR via the lowering pass, then runs each subsequent CompilerPass in sequence
on the resulting node list.  The result is a ``CompiledPlan`` that the
``PathExecutor`` knows how to run.
"""
from __future__ import annotations
import dataclasses
from dataclasses import dataclass
from dataclasses import field
from raccoon.step.motion.path.passes.lowering import flatten_steps
import typing
from typing import Protocol
from typing import runtime_checkable
__all__: list[str] = ['CompiledPlan', 'CompilerPass', 'PathCompiler', 'PathNode', 'Protocol', 'dataclass', 'field', 'flatten_steps', 'runtime_checkable']
class CompiledPlan:
    """
    Result of compiling a Step tree.
    
    ``nodes``        — the path IR after all passes ran.
    ``deferred``     — ``(index, Defer)`` pairs for runtime resolution.
    ``spline_step``  — when the spline-conversion pass terminated the
                       pipeline by replacing the path with a single
                       SplinePath, that step lives here.  Otherwise
                       ``None`` and the executor walks ``nodes`` normally.
    ``passes_applied`` — names of passes that ran, for diagnostics.
    """
    __dataclass_fields__: typing.ClassVar[dict]  # value = {'nodes': Field(name='nodes',type='list[Optional[PathNode]]',default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'deferred': Field(name='deferred',type="list[tuple[int, 'Defer']]",default=<dataclasses._MISSING_TYPE object>,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'spline_step': Field(name='spline_step',type="Optional['Step']",default=None,default_factory=<dataclasses._MISSING_TYPE object>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD), 'passes_applied': Field(name='passes_applied',type='list[str]',default=<dataclasses._MISSING_TYPE object>,default_factory=<class 'list'>,init=True,repr=True,hash=None,compare=True,metadata=mappingproxy({}),kw_only=False,_field_type=_FIELD)}
    __dataclass_params__: typing.ClassVar[dataclasses._DataclassParams]  # value = _DataclassParams(init=True,repr=True,eq=True,order=False,unsafe_hash=False,frozen=False,match_args=True,kw_only=False,slots=False,weakref_slot=False)
    __hash__: typing.ClassVar[None] = None
    __match_args__: typing.ClassVar[tuple] = ('nodes', 'deferred', 'spline_step', 'passes_applied')
    spline_step = None
    def __eq__(self, other):
        ...
    def __init__(self, nodes: list[PathNode | None], deferred: list[tuple[int, 'Defer']], spline_step: 'Step' | None = None, passes_applied: list[str] = ...) -> None:
        ...
    def __replace__(self, **changes):
        ...
    def __repr__(self):
        ...
class CompilerPass(typing.Protocol):
    """
    Pure transform on the path IR.
    
    A pass takes a node list and returns a (possibly different) node list.
    Passes must preserve the "deferred placeholder" (``None``) entries so
    the executor can resolve them at runtime.
    """
    __abstractmethods__: typing.ClassVar[frozenset]  # value = frozenset()
    __non_callable_proto_members__: typing.ClassVar[set] = {'name'}
    __parameters__: typing.ClassVar[tuple] = tuple()
    __protocol_attrs__: typing.ClassVar[set] = {'run', 'name'}
    _abc_impl: typing.ClassVar[_abc._abc_data]  # value = <_abc._abc_data object>
    _is_protocol: typing.ClassVar[bool] = True
    _is_runtime_protocol: typing.ClassVar[bool] = True
    @classmethod
    def __subclasshook__(cls, other):
        ...
    def __init__(self, *args, **kwargs):
        ...
    def run(self, nodes: list[PathNode | None]) -> list[PathNode | None]:
        ...
class PathCompiler:
    """
    Orchestrates the compiler pipeline.
    
    Lowering is always run first (it produces the IR from the Step tree).
    The remaining passes are applied in the order given.
    
    Example:
        >>> from raccoon.step.motion.path.passes import MergePass, CornerCutPass
        >>> compiler = PathCompiler([MergePass(), CornerCutPass(0.05)])
        >>> plan = compiler.compile([drive(50), turn(90), drive(30)])
    """
    def __init__(self, passes: list[CompilerPass] | None = None) -> None:
        ...
    def compile(self, steps: list) -> CompiledPlan:
        """
        Lower ``steps`` to IR and run all configured passes.
        """
PathNode: typing._UnionGenericAlias  # value = typing.Union[raccoon.step.motion.path.ir.Segment, raccoon.step.motion.path.ir.SideAction]
