"""
First-run wizard for Claw Code initialization.
Detects Ollama, RAM, pulls model, writes config.
"""

from __future__ import annotations

import logging
import sys
from pathlib import Path

from .config import load_config
from .services.ollama_adapter import OllamaAdapter
from .services.ollama_setup import (
    check_ollama_installed,
    ensure_config_exists,
    pull_model,
    validate_setup,
    print_validation_report,
)
from .model_detection import get_available_models, detect_best_model


logger = logging.getLogger(__name__)


def print_banner():
    """Print welcome banner"""
    print("\n" + "=" * 70)
    print(" 🚀 Welcome to Claw Code - Local Claude Alternative")
    print("=" * 70)
    print("\nThis wizard will help you get started in under 3 minutes.\n")


def step_1_check_ollama():
    """Step 1: Verify Ollama installation"""
    print("📋 Step 1: Checking Ollama installation...")
    
    if check_ollama_installed():
        print("✓ Ollama CLI found\n")
        return True
    else:
        print("✗ Ollama not installed")
        print("\n→ Download from: https://ollama.ai")
        print("→ Then run: claw-code init\n")
        return False


def step_2_detect_system():
    """Step 2: Detect system VRAM"""
    print("📋 Step 2: Detecting system resources...")
    
    vram_gb = OllamaAdapter.get_available_vram_gb()
    print(f"✓ Detected: {vram_gb:.1f}GB VRAM\n")
    
    return vram_gb


def step_3_recommend_model(vram_gb: float):
    """Step 3: Recommend model tier"""
    print("📋 Step 3: Recommending model for your system...")
    
    from .services.ollama_adapter import MODEL_TIERS
    
    for tier in MODEL_TIERS:
        if tier.vram_min_gb <= vram_gb <= tier.vram_max_gb:
            print(f"✓ Recommended: {tier.name}")
            print(f"  VRAM: {tier.vram_required_gb}GB | Speed: {tier.tokens_per_sec_estimate} tok/s")
            print(f"  Use: {tier.use_case}\n")
            return tier.name
    
    # Fallback
    print("✓ Using conservative tier: phi4-mini\n")
    return "phi4-mini"


def step_4_check_models():
    """Step 4: Check if model is already available"""
    print("📋 Step 4: Checking for available models...")
    
    try:
        available = get_available_models()
        if available:
            print(f"✓ Found {len(available)} model(s) installed:")
            for model in available:
                print(f"  - {model}")
            print()
            return available
        else:
            print("⚠ No models installed yet\n")
            return None
    except Exception as e:
        logger.warning(f"Could not list models: {e}")
        return None


def step_5_pull_model(recommended_model: str, available_models: list[str] | None):
    """Step 5: Pull model if needed"""
    print("📋 Step 5: Model setup...")
    
    # Check if recommended is already available (handles :latest suffix)
    if available_models and any(recommended_model in m for m in available_models):
        print(f"✓ {recommended_model} already installed\n")
        return recommended_model
    
    print(f"→ Need to download {recommended_model} (~6GB)")
    print("→ This might take a few minutes...\n")
    
    response = input("Pull now? (y/n): ").strip().lower()
    
    if response == "y":
        print()
        if pull_model(recommended_model):
            print(f"\n✓ {recommended_model} ready\n")
            return recommended_model
        else:
            print(f"\n✗ Failed to pull {recommended_model}")
            print("→ Try manually: ollama pull " + recommended_model)
            return None
    else:
        print(f"\nℹ To pull manually: ollama pull {recommended_model}\n")
        return None


def step_6_start_ollama():
    """Step 6: Instruct to start Ollama if not running"""
    print("📋 Step 6: Checking if Ollama is running...")
    
    try:
        OllamaAdapter()
        print("✓ Ollama server is running\n")
        return True
    except RuntimeError:
        print("⚠ Ollama server not running")
        print("\n→ In another terminal, run: ollama serve\n")
        return False


def step_7_create_config():
    """Step 7: Create configuration file"""
    print("📋 Step 7: Creating configuration...")
    
    config_path = ensure_config_exists()
    print(f"✓ Config created: {config_path}\n")
    
    return config_path


def step_8_validate():
    """Step 8: Validate complete setup"""
    print("📋 Step 8: Validating setup...")
    
    report = validate_setup()
    
    if report["ollama_running"] and report["model_available"]:
        print(f"✓ Everything ready! Model: {report['model_available']}\n")
        return True
    else:
        if not report["ollama_running"]:
            print("⚠ Ollama server not detected (start with: ollama serve)")
        if not report["model_available"]:
            print("⚠ No model detected (pull with: ollama pull qwen2.5-coder:7b)")
        print()
        return False


def print_next_steps():
    """Print what to do next"""
    print("=" * 70)
    print(" 🎉 Setup Complete!")
    print("=" * 70 + "\n")
    
    print("Next steps:\n")
    print("1. Make sure Ollama is running (in another terminal):")
    print("   ollama serve\n")
    
    print("2. Start Claw Code interactive REPL:")
    print("   claw-code\n")
    
    print("3. Try some commands:")
    print("   > write a Python quicksort")
    print("   > explain this function")
    print("   > help\n")
    
    print("Commands:")
    print("  /clear       — Clear conversation history")
    print("  /exit        — Exit the REPL")
    print("  /session     — Show session info")
    print("  /help        — Show help\n")


def run_init_wizard() -> bool:
    """Run the complete initialization wizard with smart skipping"""
    from .services.ollama_setup import check_ollama_installed
    
    # Check if already fully set up
    try:
        available = get_available_models()
        if available and len(available) > 0:
            # At least one model is already installed
            print("✓ Ollama and model already installed. Skipping wizard.\n")
            return True
    except Exception:
        pass
    
    print_banner()
    
    # Step 1: Check Ollama installation
    if not check_ollama_installed():
        print("📋 Step 1: Checking Ollama installation...")
        print("✗ Ollama not installed")
        print("\n→ Download from: https://ollama.ai")
        print("→ Then run: claw-code init\n")
        return False
    else:
        print("📋 Step 1: Ollama found ✓\n")
    
    # Step 2: Detect system
    vram_gb = step_2_detect_system()
    
    # Step 3: Recommend model
    recommended = step_3_recommend_model(vram_gb)
    
    # Step 4: Check available models
    available = step_4_check_models()
    
    # Step 5: Check if Ollama is running (before pull, so server is available)
    ollama_running = step_6_start_ollama()
    
    # Step 6: Pull model if needed
    model = step_5_pull_model(recommended, available)
    
    # Step 7: Create config and write model name
    config_path = step_7_create_config()
    if model:
        from .config import write_model_to_config
        write_model_to_config(model)
    
    # Step 8: Validate
    ready = step_8_validate()
    
    # Next steps
    print_next_steps()
    
    if not ollama_running:
        print("⚠ Please start Ollama (ollama serve) in another terminal,")
        print("  then run: claw-code\n")
    elif not model:
        print("⚠ Please pull a model manually, then run: claw-code\n")
    else:
        print("✓ Ready to go! Run: claw-code\n")
    
    return ready


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    success = run_init_wizard()
    sys.exit(0 if success else 1)
