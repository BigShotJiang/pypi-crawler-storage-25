"""
Configuration loading for Claw Code.
Supports both .claude.json and environment variables.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class ClaudeConfig:
    """Configuration for Claw Code runtime"""
    provider: str  # "ollama" or "anthropic"
    ollama_base_url: str
    model: str
    max_tokens: int
    temperature: float
    auto_detect_vram: bool


def load_config() -> ClaudeConfig:
    """Load configuration from ~/.claude.json or create defaults"""
    config_path = Path.home() / ".claude.json"

    # Default config for Ollama
    defaults = {
        "provider": "ollama",
        "ollama_base_url": "http://localhost:11434",
        "model": "auto-detect",
        "max_tokens": 2048,
        "temperature": 0.7,
        "auto_detect_vram": True,
    }

    # Try to load from file
    if config_path.exists():
        try:
            with open(config_path) as f:
                file_config = json.load(f)
            # Only extract fields that ClaudeConfig expects
            allowed_fields = {"provider", "ollama_base_url", "model", "max_tokens", "temperature", "auto_detect_vram"}
            filtered_config = {k: v for k, v in file_config.items() if k in allowed_fields}
            defaults.update(filtered_config)
            logger.info(f"Loaded config from {config_path}")
        except (json.JSONDecodeError, IOError) as e:
            logger.warning(f"Failed to load config from {config_path}: {e}, using defaults")
    
    return ClaudeConfig(**defaults)


def write_model_to_config(model: str) -> None:
    """Write the selected model name to ~/.claude.json"""
    config_path = Path.home() / ".claude.json"
    
    try:
        # Load existing config
        if config_path.exists():
            with open(config_path) as f:
                config = json.load(f)
        else:
            config = {
                "provider": "ollama",
                "ollama_base_url": "http://localhost:11434",
                "max_tokens": 2048,
                "temperature": 0.7,
                "auto_detect_vram": True,
            }
        
        # Update model
        config["model"] = model
        
        # Write back
        with open(config_path, "w") as f:
            json.dump(config, f, indent=2)
        
        logger.info(f"Updated config with model: {model}")
    except Exception as e:
        logger.warning(f"Failed to write model to config: {e}")

    return ClaudeConfig(
        provider=defaults.get("provider", "ollama"),
        ollama_base_url=defaults.get("ollama_base_url", "http://localhost:11434"),
        model=defaults.get("model", "auto-detect"),
        max_tokens=defaults.get("max_tokens", 2048),
        temperature=defaults.get("temperature", 0.7),
        auto_detect_vram=defaults.get("auto_detect_vram", True),
    )
