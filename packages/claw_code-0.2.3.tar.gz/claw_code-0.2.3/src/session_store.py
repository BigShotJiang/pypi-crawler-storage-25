from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path


@dataclass(frozen=True)
class StoredSession:
    session_id: str
    messages: tuple[str, ...]
    input_tokens: int
    output_tokens: int


# Default to ~/.claw-code/sessions
DEFAULT_SESSION_DIR = Path.home() / ".claw-code" / "sessions"


def save_session(session: StoredSession, directory: Path | None = None) -> Path:
    target_dir = directory or DEFAULT_SESSION_DIR
    target_dir.mkdir(parents=True, exist_ok=True)
    
    # Save session with timestamp
    timestamp = datetime.now().isoformat()
    metadata = {
        **asdict(session),
        "saved_at": timestamp,
        "message_count": len(session.messages),
    }
    
    path = target_dir / f'{session.session_id}.json'
    path.write_text(json.dumps(metadata, indent=2))
    return path


def load_session(session_id: str, directory: Path | None = None) -> StoredSession:
    target_dir = directory or DEFAULT_SESSION_DIR
    data = json.loads((target_dir / f'{session_id}.json').read_text())
    return StoredSession(
        session_id=data['session_id'],
        messages=tuple(data['messages']),
        input_tokens=data['input_tokens'],
        output_tokens=data['output_tokens'],
    )


def list_sessions(directory: Path | None = None) -> list[tuple[str, dict]]:
    """List all available sessions with metadata"""
    target_dir = directory or DEFAULT_SESSION_DIR
    
    if not target_dir.exists():
        return []
    
    sessions = []
    for session_file in sorted(target_dir.glob("*.json"), reverse=True):
        try:
            data = json.loads(session_file.read_text())
            session_id = data["session_id"]
            metadata = {
                "messages": len(data.get("messages", [])),
                "input_tokens": data.get("input_tokens", 0),
                "output_tokens": data.get("output_tokens", 0),
                "saved_at": data.get("saved_at", "unknown"),
            }
            sessions.append((session_id, metadata))
        except Exception:
            continue
    
    return sessions


def get_last_session(directory: Path | None = None) -> str | None:
    """Get the most recent session ID"""
    sessions = list_sessions(directory)
    if sessions:
        return sessions[0][0]  # First item is most recent
    return None
