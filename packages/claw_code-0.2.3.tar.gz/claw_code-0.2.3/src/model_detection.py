"""
Ollama model detection and management.
Dynamically discovers available models and selects best tier.
"""

from __future__ import annotations

import json
import logging
import subprocess
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class OllamaModel:
    """Ollama model information"""
    name: str
    size_gb: float
    parameter_count: int  # e.g., 7 for 7B model


def get_available_models() -> list[str]:
    """
    Call `ollama list` to get available models.
    Returns list of model names or empty list if Ollama not running.
    """
    try:
        result = subprocess.run(
            ["ollama", "list"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode != 0:
            logger.warning("ollama list failed, Ollama may not be running")
            return []

        # Parse output (format: NAME DIGEST SIZE MODIFIED)
        models = []
        for line in result.stdout.split("\n")[1:]:  # Skip header
            if line.strip():
                parts = line.split()
                if parts:
                    models.append(parts[0])
        return models
    except (FileNotFoundError, subprocess.TimeoutExpired, Exception) as e:
        logger.warning(f"Failed to get available models: {e}")
        return []


def select_best_model(available_models: list[str]) -> str | None:
    """
    Select the best model from available options.
    Prefers: qwen2.5-coder:7b > qwen2.5-coder:14b > phi4-mini > others
    """
    if not available_models:
        return None

    preferences = [
        "qwen2.5-coder:7b",
        "qwen2.5-coder:14b",
        "phi4-mini",
        "neural-chat",
        "mistral",
    ]

    # Check preferences in order
    for pref in preferences:
        if pref in available_models:
            logger.info(f"Selected model: {pref}")
            return pref

    # Fallback to first available
    selected = available_models[0]
    logger.info(f"No preferred model found, using: {selected}")
    return selected


def detect_best_model(auto_detect: bool = True) -> str:
    """
    Detect the best available model.
    If auto_detect is True, queries Ollama for available models.
    Falls back to qwen2.5-coder:7b if needed.
    """
    if not auto_detect:
        return "qwen2.5-coder:7b"

    available = get_available_models()
    if not available:
        logger.warning("No models detected, defaulting to qwen2.5-coder:7b")
        return "qwen2.5-coder:7b"

    best = select_best_model(available)
    return best or "qwen2.5-coder:7b"
