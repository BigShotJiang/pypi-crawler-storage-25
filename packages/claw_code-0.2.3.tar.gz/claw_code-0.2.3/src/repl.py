"""
Claw-Code Interactive REPL
Full-featured terminal UI using prompt_toolkit + rich.

Features:
  - ASCII claw banner on startup
  - Claw icon in prompt
  - Animated live token streaming
  - Syntax-highlighted code blocks in output
  - Status bar with session info (model, turns, tokens)
  - Tab completion for slash commands
  - /help, /clear, /exit, /session, /resume, /model commands
"""

from __future__ import annotations

import time
import sys
import os
from datetime import datetime
from typing import Optional

# ── prompt_toolkit ────────────────────────────────────────────
from prompt_toolkit import PromptSession
from prompt_toolkit.completion import WordCompleter
from prompt_toolkit.formatted_text import HTML
from prompt_toolkit.styles import Style
from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.filters import is_done

# ── rich ──────────────────────────────────────────────────────
from rich.console import Console
from rich.syntax import Syntax
from rich.markdown import Markdown
from rich.live import Live
from rich.text import Text
from rich.panel import Panel
from rich.table import Table
from rich import box
from rich.theme import Theme

# ── internal imports (graceful fallbacks for standalone testing) ──
try:
    from src.query_engine import QueryEnginePort, QueryEngineConfig
    from src.config import load_config
    from src.session_store import save_session, load_session, list_sessions, get_last_session
    FULL_MODE = True
except ImportError:
    FULL_MODE = False


# ─────────────────────────────────────────────
# Theme & console
# ─────────────────────────────────────────────

CLAW_THEME = Theme({
    "banner.claw":    "bold bright_cyan",
    "banner.title":   "bold white",
    "banner.sub":     "dim white",
    "prompt.icon":    "bold cyan",
    "prompt.text":    "bold white",
    "status.key":     "dim cyan",
    "status.value":   "white",
    "status.sep":     "dim white",
    "cmd.name":       "bold cyan",
    "cmd.desc":       "dim white",
    "error":          "bold red",
    "success":        "bold green",
    "warning":        "bold yellow",
    "info":           "dim cyan",
    "token.stream":   "bright_white",
    "heading":        "bold bright_cyan",
})

import sys
import io
# For Windows, use safe output
if sys.platform == "win32":
    console = Console(theme=CLAW_THEME, highlight=False, soft_wrap=True)
else:
    console = Console(theme=CLAW_THEME, highlight=False)


# ─────────────────────────────────────────────
# ASCII claw banner
# ─────────────────────────────────────────────

BANNER_TEXT = r"""
  ██████╗██╗      █████╗ ██╗    ██╗      ██████╗ ██████╗ ██████╗ ███████╗
 ██╔════╝██║     ██╔══██╗██║    ██║     ██╔════╝██╔═══██╗██╔══██╗██╔════╝
 ██║     ██║     ███████║██║ █╗ ██║     ██║     ██║   ██║██║  ██║█████╗
 ██║     ██║     ██╔══██║██║███╗██║     ██║     ██║   ██║██║  ██║██╔══╝
 ╚██████╗███████╗██║  ██║╚███╔███╔╝     ╚██████╗╚██████╔╝██████╔╝███████╗
  ╚═════╝╚══════╝╚═╝  ╚═╝ ╚══╝╚══╝       ╚═════╝ ╚═════╝ ╚═════╝ ╚══════╝
"""


def print_banner(model: str = "qwen2.5-coder:7b", version: str = "0.2.0") -> None:
    """Print the startup banner with claw branding."""
    try:
        console.print()

        # Main title art
        console.print(BANNER_TEXT, style="bold cyan", end="")

        # Tagline row
        console.print(
            "  *  Free · Local · Zero API costs · Powered by Ollama\n",
            style="dim white"
        )

        # Info row
        info = Table.grid(padding=(0, 2))
        info.add_column(style="dim cyan")
        info.add_column(style="white")
        info.add_column(style="dim cyan")
        info.add_column(style="white")
        info.add_column(style="dim cyan")
        info.add_column(style="white")
        info.add_row(
            "model", model,
            "version", version,
            "provider", "ollama (local)",
        )
        console.print("  ", info)
        console.print()

        # Hint line
        console.print(
            "  Type [bold cyan]/help[/bold cyan] for commands  "
            "[dim]·[/dim]  [bold cyan]/exit[/bold cyan] to quit  "
        "[dim]·[/dim]  Start typing to chat\n",
        highlight=False,
    )
    except UnicodeEncodeError:
        # Fallback for Windows console encoding issues
        print()
        print("=" * 60)
        print(f"CLAW-CODE v{version}")
        print("=" * 60)
        print(f"  Model: {model}")
        print(f"  Provider: ollama (local)")
        print()
        print("Type /help for commands, /exit to quit, or start typing to chat")
        print("=" * 60)
        print()
    except Exception:
        # Silent fallback - just print empty lines
        print()
        print(f"  Model: {model} | Type /help for commands, /exit to quit")
        print()


# ─────────────────────────────────────────────
# Slash command registry
# ─────────────────────────────────────────────

SLASH_COMMANDS = {
    "/help":    "Show available commands",
    "/clear":   "Clear the screen",
    "/exit":    "Exit Claw-Code (prompts to save session)",
    "/session": "Show current session info (turns, tokens, model)",
    "/resume":  "List and resume a previous session",
    "/model":   "Show current model and hardware info",
    "/save":    "Manually save current session",
}


def print_help() -> None:
    table = Table(
        box=box.SIMPLE,
        show_header=True,
        header_style="bold cyan",
        border_style="dim white",
        pad_edge=False,
    )
    table.add_column("Command", style="bold cyan", width=12)
    table.add_column("Description", style="dim white")

    for cmd, desc in SLASH_COMMANDS.items():
        table.add_row(cmd, desc)

    console.print(
        Panel(table, title="[bold white]Claw-Code Commands[/bold white]",
              border_style="cyan", padding=(0, 1))
    )


# ─────────────────────────────────────────────
# Status bar builder
# ─────────────────────────────────────────────

def make_status_bar(
    model: str,
    turns: int,
    input_tokens: int,
    output_tokens: int,
    session_id: Optional[str] = None,
) -> HTML:
    """
    Returns a prompt_toolkit HTML fragment used as the bottom toolbar.
    Shows: model · turns · tokens · session id (truncated)
    """
    sid = (session_id[:8] + "…") if session_id else "new"
    return HTML(
        f"<style bg='#0d1117' fg='#58a6ff'> ⚙ {model} </style>"
        f"<style bg='#0d1117' fg='#8b949e'> │ </style>"
        f"<style bg='#0d1117' fg='#58a6ff'> turns: {turns} </style>"
        f"<style bg='#0d1117' fg='#8b949e'> │ </style>"
        f"<style bg='#0d1117' fg='#58a6ff'> ↑{input_tokens} ↓{output_tokens} tok </style>"
        f"<style bg='#0d1117' fg='#8b949e'> │ </style>"
        f"<style bg='#0d1117' fg='#3fb950'> session: {sid} </style>"
        f"<style bg='#0d1117' fg='#8b949e'> </style>"
    )


# ─────────────────────────────────────────────
# Output renderer  (streaming + syntax highlight)
# ─────────────────────────────────────────────

def render_response(text: str) -> None:
    """
    Render a completed response with rich Markdown + syntax highlighting.
    Code blocks are auto-detected and syntax highlighted.
    """
    if not text.strip():
        return

    # Split on fenced code blocks and render each part
    import re
    parts = re.split(r"(```[\w]*\n[\s\S]*?```)", text)

    for part in parts:
        if part.startswith("```"):
            # Extract language and code
            lines = part.strip().split("\n")
            lang_line = lines[0].replace("```", "").strip() or "python"
            code = "\n".join(lines[1:]).rstrip("`").strip()
            syntax = Syntax(
                code,
                lang_line,
                theme="monokai",
                line_numbers=False,
                word_wrap=True,
                background_color="default",
            )
            console.print(
                Panel(syntax,
                      border_style="dim cyan",
                      padding=(0, 1),
                      expand=False)
            )
        else:
            if part.strip():
                # Render as Markdown (handles bold, lists, headers, inline code)
                try:
                    md = Markdown(part.strip(), code_theme="monokai")
                    console.print(md)
                except Exception:
                    console.print(part.strip())

    console.print()


def stream_response(token_generator) -> str:
    """
    Stream tokens live to the terminal using rich Live.
    Returns the full assembled response string.
    """
    full_text = ""
    current_line = Text(style="bright_white")

    with Live(current_line, console=console, refresh_per_second=30,
              transient=True) as live:
        for token in token_generator:
            full_text += token
            current_line = Text(full_text, style="bright_white")
            live.update(current_line)

    # After streaming completes, render the final formatted version
    render_response(full_text)
    return full_text


def print_thinking() -> None:
    """Show a brief 'thinking' indicator."""
    console.print("  [dim cyan]⋯  thinking[/dim cyan]")


# ─────────────────────────────────────────────
# Session info display
# ─────────────────────────────────────────────

def print_session_info(state: "ReplState") -> None:
    table = Table(box=box.SIMPLE, show_header=False, pad_edge=False)
    table.add_column(style="dim cyan", width=18)
    table.add_column(style="white")

    table.add_row("session id",    state.session_id or "not saved yet")
    table.add_row("model",         state.model)
    table.add_row("turns",         str(state.turns))
    table.add_row("input tokens",  str(state.input_tokens))
    table.add_row("output tokens", str(state.output_tokens))
    table.add_row("started",       state.started_at.strftime("%H:%M:%S"))

    console.print(
        Panel(table, title="[bold white]Session Info[/bold white]",
              border_style="cyan", padding=(0, 1))
    )


# ─────────────────────────────────────────────
# REPL state
# ─────────────────────────────────────────────

class ReplState:
    """Holds all mutable state for the REPL session."""

    def __init__(self, model: str = "qwen2.5-coder:7b"):
        self.model        = model
        self.turns        = 0
        self.input_tokens = 0
        self.output_tokens= 0
        self.session_id: Optional[str] = None
        self.started_at   = datetime.now()
        self.engine       = None   # QueryEnginePort, set after init

    def tick(self, input_tok: int = 0, output_tok: int = 0) -> None:
        self.turns        += 1
        self.input_tokens += input_tok
        self.output_tokens+= output_tok


# ─────────────────────────────────────────────
# Slash command handlers
# ─────────────────────────────────────────────

def handle_slash(cmd: str, state: ReplState, session: PromptSession) -> bool:
    """
    Handle a slash command. Returns True to continue, False to exit.
    """
    parts = cmd.strip().split(maxsplit=1)
    verb  = parts[0].lower()

    if verb == "/help":
        print_help()

    elif verb == "/clear":
        os.system("cls" if os.name == "nt" else "clear")
        print_banner(state.model)

    elif verb == "/session":
        print_session_info(state)

    elif verb == "/model":
        table = Table(box=box.SIMPLE, show_header=False, pad_edge=False)
        table.add_column(style="dim cyan", width=18)
        table.add_column(style="white")
        table.add_row("active model",  state.model)
        table.add_row("provider",      "ollama (local)")
        table.add_row("endpoint",      "http://localhost:11434")
        console.print(
            Panel(table, title="[bold white]Model Info[/bold white]",
                  border_style="cyan", padding=(0, 1))
        )

    elif verb == "/save":
        if FULL_MODE and state.engine:
            try:
                sid = save_session(state.engine.messages,
                                   state.input_tokens,
                                   state.output_tokens)
                state.session_id = sid
                console.print(f"  [green]+[/green] Session saved: [cyan]{sid[:8]}...[/cyan]")
            except Exception as e:
                console.print(f"  [red]✗[/red] Could not save: {e}")
        else:
            console.print("  [dim]No active session to save.[/dim]")

    elif verb == "/resume":
        if not FULL_MODE:
            console.print("  [dim]Session resume not available in standalone mode.[/dim]")
            return True
        try:
            sessions = list_sessions()
            if not sessions:
                console.print("  [dim]No saved sessions found.[/dim]")
                return True
            table = Table(box=box.SIMPLE, show_header=True,
                          header_style="bold cyan", pad_edge=False)
            table.add_column("#",         style="dim white", width=3)
            table.add_column("Session ID",style="cyan",      width=12)
            table.add_column("Saved",     style="white",     width=20)
            table.add_column("Messages",  style="dim white", width=8)
            for i, s in enumerate(sessions[:8], 1):
                table.add_row(
                    str(i),
                    s.get("session_id", "?")[:8] + "…",
                    s.get("saved_at", "?")[:19],
                    str(s.get("message_count", "?")),
                )
            console.print(table)
            console.print("  [dim]Use: /resume <session-id>[/dim]")
        except Exception as e:
            console.print(f"  [red]✗[/red] {e}")

    elif verb == "/exit":
        return _handle_exit(state)

    else:
        console.print(f"  [red]Unknown command:[/red] {verb}  "
                      f"[dim](try /help)[/dim]")

    return True   # continue


def _handle_exit(state: ReplState) -> bool:
    """Ask to save, then exit. Returns False to break the REPL loop."""
    if state.turns > 0 and FULL_MODE and state.engine:
        console.print()
        try:
            answer = console.input(
                "  [dim]Save session before exiting? [y/N][/dim] "
            ).strip().lower()
        except (EOFError, KeyboardInterrupt):
            answer = "n"

        if answer == "y":
            try:
                sid = save_session(state.engine.messages,
                                   state.input_tokens,
                                   state.output_tokens)
                state.session_id = sid
                console.print(f"  [green]+[/green] Saved as [cyan]{sid[:8]}...[/cyan]")
            except Exception as e:
                console.print(f"  [red]✗[/red] Could not save: {e}")

    console.print("\n  [dim cyan]👋  Goodbye from Claw-Code[/dim cyan]\n")
    return False   # signal exit


# ─────────────────────────────────────────────
# Core REPL loop
# ─────────────────────────────────────────────

def run_repl(
    initial_model: Optional[str] = None,
    resume_session_id: Optional[str] = None,
) -> None:
    """
    Entry point for the interactive REPL.
    Call this from main.py when no subcommand is given.
    """

    # ── Determine model ──────────────────────────────────────
    model = initial_model or "qwen2.5-coder:7b"
    if FULL_MODE:
        try:
            cfg = load_config()
            model = cfg.model if cfg.model != "auto-detect" else model
        except Exception:
            pass

    state = ReplState(model=model)

    # ── Resume session if requested ──────────────────────────
    if resume_session_id and FULL_MODE:
        try:
            session_data = load_session(resume_session_id)
            state.session_id   = resume_session_id
            state.input_tokens = session_data.get("input_tokens", 0)
            state.output_tokens= session_data.get("output_tokens", 0)
            console.print(f"  [green]+[/green] Resumed session [cyan]{resume_session_id[:8]}...[/cyan]")
        except Exception as e:
            console.print(f"  [yellow]![/yellow] Could not resume session: {e}")

    # ── Init query engine ─────────────────────────────────────
    if FULL_MODE:
        try:
            state.engine = QueryEnginePort.from_workspace()
            model = state.engine.model or model
            state.model = model
        except Exception as e:
            console.print(f"  [yellow]![/yellow] Engine init failed: {e}")
            console.print("  [dim]Running in demo mode — responses will be echoed.[/dim]\n")

    # ── Print banner ──────────────────────────────────────────
    print_banner(model=state.model)

    # ── prompt_toolkit setup ──────────────────────────────────
    completer = WordCompleter(
        list(SLASH_COMMANDS.keys()),
        match_middle=False,
        sentence=True,
    )

    pt_style = Style.from_dict({
        "prompt":        "bold ansicyan",
        "bottom-toolbar":"bg:#0d1117 #58a6ff",
    })

    def get_toolbar():
        return make_status_bar(
            model=state.model,
            turns=state.turns,
            input_tokens=state.input_tokens,
            output_tokens=state.output_tokens,
            session_id=state.session_id,
        )

    pt_session: PromptSession = PromptSession(
        completer=completer,
        style=pt_style,
        bottom_toolbar=get_toolbar,
        refresh_interval=1.0,
        mouse_support=False,
    )

    # ── Main loop ─────────────────────────────────────────────
    while True:
        try:
            # Build the prompt string: * claw >
            user_input = pt_session.prompt(
                HTML("<ansibrightcyan><b>* claw</b></ansibrightcyan>"
                     "<ansiwhite><b> > </b></ansiwhite>"),
            ).strip()

        except KeyboardInterrupt:
            console.print("\n  [dim](Ctrl+C — type /exit to quit)[/dim]")
            continue
        except EOFError:
            _handle_exit(state)
            break

        if not user_input:
            continue

        # ── Slash commands ────────────────────────────────────
        if user_input.startswith("/"):
            should_continue = handle_slash(user_input, state, pt_session)
            if not should_continue:
                break
            continue

        # ── LLM call ─────────────────────────────────────────
        console.print()

        if FULL_MODE and state.engine:
            try:
                # Attempt streaming first
                if hasattr(state.engine, "stream_submit_message"):
                    gen = state.engine.stream_submit_message(user_input)
                    full = stream_response(gen)
                else:
                    print_thinking()
                    result = state.engine.submit_message(user_input)
                    full = result.get("response", str(result))
                    render_response(full)

                # Update token counts from engine if available
                usage = getattr(state.engine, "last_usage", None)
                in_tok  = getattr(usage, "input_tokens",  50) if usage else 50
                out_tok = getattr(usage, "output_tokens", len(full.split())) if usage else len(full.split())
                state.tick(in_tok, out_tok)

            except Exception as e:
                console.print(f"  [red]✗  Error:[/red] {e}\n")

        else:
            # ── Demo / standalone mode ────────────────────────
            # Simulates streaming for UI testing without a real engine
            print_thinking()
            time.sleep(0.4)

            demo_response = (
                f"*(demo mode)* You said: **{user_input}**\n\n"
                "Here is a sample code block:\n\n"
                "```python\n"
                "def hello():\n"
                "    print('Hello from Claw-Code!')\n"
                "```\n\n"
                "Connect Ollama to get real responses."
            )

            # Simulate token-by-token streaming
            words = demo_response.split(" ")
            def fake_stream():
                for w in words:
                    time.sleep(0.04)
                    yield w + " "

            full = stream_response(fake_stream())
            state.tick(len(user_input.split()), len(words))


# ─────────────────────────────────────────────
# Standalone entry (python repl.py)
# ─────────────────────────────────────────────

if __name__ == "__main__":
    run_repl()
