"""
Ollama integration adapter for local LLM execution without API costs.
Implements auto-detection of hardware and model selection.
"""

from __future__ import annotations

import json
import logging
import subprocess
from dataclasses import dataclass
from typing import Generator

try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False

import requests


logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class ModelTier:
    """Model selection tier based on available VRAM"""
    name: str
    vram_required_gb: float
    vram_min_gb: float
    vram_max_gb: float
    tokens_per_sec_estimate: str
    use_case: str


# Model registry by tier
MODEL_TIERS = [
    ModelTier(
        name="phi4-mini",
        vram_required_gb=3.0,
        vram_min_gb=0,
        vram_max_gb=8,
        tokens_per_sec_estimate="15-20",
        use_case="Low-end machines (M1 MacBook Air, entry laptops)"
    ),
    ModelTier(
        name="qwen2.5-coder:7b",
        vram_required_gb=6.0,
        vram_min_gb=8,
        vram_max_gb=12,
        tokens_per_sec_estimate="25-40",
        use_case="Primary recommendation (autocomplete, refactors, tests)"
    ),
    ModelTier(
        name="qwen2.5-coder:14b",
        vram_required_gb=10.0,
        vram_min_gb=10,
        vram_max_gb=float('inf'),
        tokens_per_sec_estimate="10-20",
        use_case="Power tier (complex logic, debugging, algorithms)"
    ),
]


class OllamaAdapter:
    """Adapter for local Ollama-based LLM execution"""

    def __init__(
        self,
        base_url: str = "http://localhost:11434",
        model: str | None = None,
        auto_detect: bool = True,
        timeout: int = 120,
    ):
        """
        Initialize Ollama adapter.

        Args:
            base_url: Ollama server URL (default: localhost:11434)
            model: Model name override. If None and auto_detect=True, will select based on VRAM
            auto_detect: Whether to auto-detect model based on available VRAM
            timeout: Request timeout in seconds
        """
        self.base_url = base_url
        self.timeout = timeout
        self.model = model or (self.recommend_model() if auto_detect else "qwen2.5-coder:7b")
        self._verify_connection()

    @staticmethod
    def get_available_vram_gb() -> float:
        """Get available GPU VRAM in gigabytes, with GPU detection fallback chain"""
        # Try NVIDIA GPU via nvidia-smi
        try:
            result = subprocess.run(
                ["nvidia-smi", "--query-gpu=memory.total", "--format=csv,noheader,nounits"],
                capture_output=True, text=True, timeout=5, check=True
            )
            if result.stdout.strip():
                vram_mib = float(result.stdout.strip().split('\n')[0])
                vram_gb = vram_mib / 1024
                logger.info(f"Detected {vram_gb:.1f}GB NVIDIA GPU VRAM")
                return vram_gb
        except (FileNotFoundError, subprocess.TimeoutExpired, ValueError):
            pass

        # Try Apple Silicon / macOS via system_profiler
        try:
            result = subprocess.run(
                ["system_profiler", "SPHardwareDataType"],
                capture_output=True, text=True, timeout=5, check=True
            )
            for line in result.stdout.split('\n'):
                if 'Memory:' in line:
                    # Parse "Memory: 16 GB" format
                    parts = line.split(':')
                    if len(parts) > 1:
                        mem_str = parts[1].strip().split()[0]
                        vram_gb = float(mem_str)
                        logger.info(f"Detected {vram_gb:.1f}GB Apple Silicon unified memory")
                        return vram_gb
        except (FileNotFoundError, subprocess.TimeoutExpired, ValueError):
            pass

        # Try AMD GPU via rocm-smi
        try:
            result = subprocess.run(
                ["rocm-smi", "--showmeminfo", "vram", "--csv"],
                capture_output=True, text=True, timeout=5, check=True
            )
            if result.stdout.strip():
                lines = result.stdout.strip().split('\n')
                if len(lines) > 1:
                    try:
                        vram_mb = float(lines[1].split(',')[0].strip())
                        vram_gb = vram_mb / 1024
                        logger.info(f"Detected {vram_gb:.1f}GB AMD GPU VRAM")
                        return vram_gb
                    except (IndexError, ValueError):
                        pass
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass

        # Fallback: 50% of system RAM (GPU rarely gets full RAM allocation)
        if PSUTIL_AVAILABLE:
            try:
                system_ram = psutil.virtual_memory().total / (1024 ** 3)
                fallback_vram = system_ram * 0.5
                logger.info(f"No GPU detected; using 50% of RAM: {fallback_vram:.1f}GB")
                return fallback_vram
            except Exception as e:
                logger.warning(f"Failed to detect system RAM: {e}; assuming 8GB")
                return 8.0

        logger.warning("Could not detect VRAM; assuming 8GB")
        return 8.0

    @classmethod
    def recommend_model(cls) -> str:
        """Auto-detect VRAM and recommend optimal model tier"""
        vram_gb = cls.get_available_vram_gb()
        logger.info(f"Detected {vram_gb:.1f}GB VRAM; recommending model tier...")

        for tier in MODEL_TIERS:
            if tier.vram_min_gb <= vram_gb <= tier.vram_max_gb:
                logger.info(f"Selected {tier.name} for {vram_gb:.1f}GB VRAM")
                logger.info(f"  Use case: {tier.use_case}")
                logger.info(f"  Est. speed: {tier.tokens_per_sec_estimate} tokens/sec")
                return tier.name

        # Fallback to most conservative
        logger.warning(f"VRAM {vram_gb:.1f}GB outside known ranges; using phi4-mini (conservative)")
        return "phi4-mini"

    @staticmethod
    def print_model_roadmap() -> None:
        """Print model selection roadmap for user reference"""
        print("\n" + "=" * 65)
        print("  Ollama Model Selection Roadmap")
        print("=" * 65 + "\n")

        vram_gb = OllamaAdapter.get_available_vram_gb()
        print(f"Your system: {vram_gb:.1f}GB VRAM\n")

        for tier in MODEL_TIERS:
            marker = " ⭐ RECOMMENDED" if tier.vram_min_gb <= vram_gb <= tier.vram_max_gb else ""
            print(f"[{tier.vram_min_gb:.0f}-{tier.vram_max_gb:.1f}GB] {tier.name}{marker}")
            print(f"  VRAM: {tier.vram_required_gb}GB | Speed: {tier.tokens_per_sec_estimate} tok/s")
            print(f"  {tier.use_case}\n")

        print("=" * 65 + "\n")

    def _verify_connection(self) -> None:
        """Verify Ollama server is reachable"""
        try:
            response = requests.get(f"{self.base_url}/api/tags", timeout=5)
            response.raise_for_status()
            logger.info(f"✓ Connected to Ollama at {self.base_url}")
        except requests.RequestException as e:
            logger.error(f"✗ Cannot connect to Ollama at {self.base_url}: {e}")
            raise RuntimeError(
                f"Ollama server not reachable at {self.base_url}\n"
                f"Start it with: ollama serve"
            )

    def generate(self, prompt: str) -> str:
        """
        Generate response from prompt (non-streaming).

        Args:
            prompt: Input prompt

        Returns:
            Generated response text
        """
        try:
            response = requests.post(
                f"{self.base_url}/api/generate",
                json={
                    "model": self.model,
                    "prompt": prompt,
                    "stream": False,
                },
                timeout=self.timeout,
            )
            response.raise_for_status()
            return response.json()["response"]
        except requests.RequestException as e:
            logger.error(f"Generation failed: {e}")
            raise

    def stream_generate(self, prompt: str) -> Generator[str, None, None]:
        """
        Stream-based generation (yields tokens as they arrive).

        Args:
            prompt: Input prompt

        Yields:
            Token strings as they are generated
        """
        try:
            response = requests.post(
                f"{self.base_url}/api/generate",
                json={
                    "model": self.model,
                    "prompt": prompt,
                    "stream": True,
                },
                stream=True,
                timeout=self.timeout,
            )
            response.raise_for_status()

            for line in response.iter_lines():
                if line:
                    try:
                        chunk = json.loads(line)
                        token = chunk.get("response", "")
                        if token:
                            yield token
                    except json.JSONDecodeError:
                        logger.warning(f"Failed to parse chunk: {line}")
                        continue

        except requests.RequestException as e:
            logger.error(f"Stream generation failed: {e}")
            raise

    def formats_supported(self) -> dict:
        """Get supported formats from Ollama server"""
        try:
            response = requests.get(f"{self.base_url}/api/tags", timeout=5)
            response.raise_for_status()
            return response.json()
        except requests.RequestException as e:
            logger.error(f"Failed to fetch formats: {e}")
            return {}


def create_ollama_adapter(
    base_url: str = "http://localhost:11434",
    model: str | None = None,
    auto_detect: bool = True,
) -> OllamaAdapter:
    """Factory function for creating OllamaAdapter instances"""
    return OllamaAdapter(
        base_url=base_url,
        model=model,
        auto_detect=auto_detect,
    )


if __name__ == "__main__":
    # CLI for testing/demo
    import sys

    logging.basicConfig(level=logging.INFO)

    if len(sys.argv) > 1 and sys.argv[1] == "roadmap":
        OllamaAdapter.print_model_roadmap()
    else:
        # Test connection
        print("Testing Ollama adapter...")
        adapter = OllamaAdapter()
        print(f"Model: {adapter.model}")
        print(f"Base URL: {adapter.base_url}")
        print("✓ Connection verified")
