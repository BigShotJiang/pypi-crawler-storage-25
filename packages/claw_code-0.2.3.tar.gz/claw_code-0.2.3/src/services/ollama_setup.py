"""
Ollama setup and configuration for Claw Code.
Handles auto-detection, model pulling, and configuration generation.
"""

from __future__ import annotations

import json
import logging
import subprocess
import sys
import time
from pathlib import Path

from .ollama_adapter import OllamaAdapter, MODEL_TIERS


logger = logging.getLogger(__name__)


def ensure_config_exists() -> Path:
    """Ensure .claude.json exists with Ollama defaults"""
    config_path = Path.home() / ".claude.json"

    if config_path.exists():
        logger.info(f"Config already exists at {config_path}")
        return config_path

    # Create default config
    config = {
        "provider": "ollama",
        "ollama_base_url": "http://localhost:11434",
        "model": "auto-detect",
        "auto_detect_vram": True,
        "use_api_key": False,
        "quantization": "Q4_K_M",
        "max_tokens": 2048,
        "temperature": 0.7,
    }

    config_path.write_text(json.dumps(config, indent=2))
    logger.info(f"Created config at {config_path}")
    return config_path


def check_ollama_installed() -> bool:
    """Check if Ollama CLI is installed"""
    try:
        subprocess.run(["ollama", "--version"], check=True, capture_output=True)
        return True
    except (subprocess.CalledProcessError, FileNotFoundError):
        return False


def pull_model(model: str) -> bool:
    """Pull the specified model using Ollama CLI with auto-start of ollama serve"""
    if not check_ollama_installed():
        logger.error("Ollama CLI not found. Install from https://ollama.ai")
        return False

    try:
        # Try to ensure ollama serve is running in background
        try:
            logger.info("Starting ollama serve in background...")
            subprocess.Popen(
                ["ollama", "serve"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True if sys.platform != "win32" else False
            )
            time.sleep(2)  # Give it a moment to start
        except Exception as e:
            logger.warning(f"Could not auto-start ollama serve: {e}")
        
        logger.info(f"Pulling {model}...")
        # Don't capture output so Ollama's progress bar displays to user
        subprocess.run(["ollama", "pull", model], check=True, text=True)
        logger.info(f"✓ Successfully pulled {model}")
        return True
    except subprocess.CalledProcessError as e:
        logger.error(f"Failed to pull {model}: {e}")
        return False


def recommend_and_setup() -> str | None:
    """
    Recommend a model tier and offer to pull it.
    Returns the selected model name or None if setup was skipped.
    """
    print("\n" + "=" * 70)
    print("  Claw Code + Ollama Setup")
    print("=" * 70 + "\n")

    # Show roadmap
    OllamaAdapter.print_model_roadmap()

    recommended = OllamaAdapter.recommend_model()
    print(f"✓ Recommended model: {recommended}\n")

    # Check if Ollama is installed
    if not check_ollama_installed():
        print("⚠ Ollama CLI not installed. Visit https://ollama.ai to install.\n")
        return None

    # Offer to pull
    response = input(f"Pull {recommended} now? (y/n): ").strip().lower()
    if response == "y":
        if pull_model(recommended):
            print(f"\n✓ Setup complete! Start Ollama with: ollama serve")
            return recommended
        else:
            print("\n✗ Failed to pull model")
            return None
    else:
        print(f"\nTo manually pull, run: ollama pull {recommended}")
        return None


def validate_setup() -> dict:
    """
    Validate that Ollama setup is working.
    Returns validation report.
    """
    report = {
        "ollama_installed": check_ollama_installed(),
        "ollama_running": False,
        "model_available": None,
        "config_exists": False,
    }

    # Check config
    config_path = Path.home() / ".claude.json"
    report["config_exists"] = config_path.exists()

    # Try to connect
    try:
        adapter = OllamaAdapter()
        report["ollama_running"] = True
        report["model_available"] = adapter.model
    except RuntimeError:
        report["ollama_running"] = False

    return report


def print_validation_report(report: dict) -> None:
    """Pretty-print validation report"""
    print("\n" + "=" * 50)
    print("  Setup Validation Report")
    print("=" * 50 + "\n")

    checks = [
        ("Ollama installed", report["ollama_installed"]),
        ("Ollama running", report["ollama_running"]),
        ("Config exists", report["config_exists"]),
    ]

    for check_name, passed in checks:
        symbol = "✓" if passed else "✗"
        print(f"{symbol} {check_name}")

    if report["model_available"]:
        print(f"✓ Model ready: {report['model_available']}")

    print("\n" + "=" * 50 + "\n")

    # Recommendations
    if not report["ollama_installed"]:
        print("→ Install Ollama: https://ollama.ai")
    elif not report["ollama_running"]:
        print("→ Start Ollama with: ollama serve")
    elif not report["model_available"]:
        print("→ Pull a model: ollama pull qwen2.5-coder:7b")

    print()


def interactive_setup() -> None:
    """Run interactive setup flow"""
    print("\n🚀 Welcome to Claw Code (Local Ollama Edition)\n")

    # Step 1: Show roadmap and recommend
    recommended = recommend_and_setup()

    # Step 2: Create config
    ensure_config_exists()

    # Step 3: Validate
    report = validate_setup()
    print_validation_report(report)

    # Final status
    if report["ollama_running"] and report["model_available"]:
        print("✓ All systems ready! Start using Claw Code:\n")
        print("  python -m src turn-loop \"Your prompt here\"\n")
    elif report["ollama_installed"]:
        print("⚠ Setup not complete. Run: ollama serve\n")
    else:
        print("⚠ Install Ollama from https://ollama.ai and try again.\n")


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "validate":
        report = validate_setup()
        print_validation_report(report)
    else:
        interactive_setup()
