#!/usr/bin/env python
"""
Setup configuration for claw-code package.
Uses pyproject.toml for primary configuration.
"""

from setuptools import setup, find_packages

setup(
    name="claw-code",
    packages=find_packages(),
    entry_points={
        "console_scripts": [
            "claw-code=src.main:cli_entry",
        ],
    },
)
