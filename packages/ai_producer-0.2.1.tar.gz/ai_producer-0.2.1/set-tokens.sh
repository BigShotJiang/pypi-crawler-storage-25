cat >> ~/.pypirc <<'EOF'                                                                                                                   
  [distutils]                                                                                                                                
    index-servers = pypi testpypi
  [pypi]                                                                                                                                     
    username = __token__                                                                                                                   
    password = pypi-AgEIcHlwaS5vcmcCJGQ1NzMxMTgzLTdhOWUtNGZhZi04NDc2LTZlNjMzMWE3NTZlNQACKlszLCI0OWVlMWI2OC00ODAyLTQ5OTgtODU5Ni0zMzc5MWQ5MWY1MjQiXQAABiAnB2T5SZdX5Tvf7uAdEHG40NWw3GIc3UFIAv0m1UHrqg
  [testpypi]                                                                                                                                 
    repository = https://test.pypi.org/legacy/
    username = __token__                                                                                                                     
    password = pypi-AgENdGVzdC5weXBpLm9yZwIkMTNiOTU5MTMtNDRmMy00Y2ZmLWIwNjktZDU4OTBiNzY2ZmY5AAIqWzMsIjllNTdhYWZjLWEzNWItNDgyOS1hNDJlLWEwZmQ5MDNjYWNmMCJdAAAGIFFBpHqYjnX89H4ZL_nfL0h_INPLjXiqI8WF6i5PmfXC                                                                                        
  EOF                                                                                                                                        
  chmod 600 ~/.pypirc