"""Producer configuration loaded from ``producer.yaml``.

The config is the single declarative surface for a project: which roles
exist, their daily caps and toolsets, where the kill switch lives, what
ntfy.sh topic to push to, etc.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import yaml


@dataclass
class RoleConfig:
    """One specialist agent's configuration."""

    name: str
    daily_cap_usd: float
    allowed_tools: list[str] = field(default_factory=list)
    dispatch_reservation_usd: float = 0.10
    prompt: str | None = None  # path relative to project_root, or None for SDK default


@dataclass
class BudgetConfig:
    project_ceiling_usd: float
    soft_cap_ratio: float = 0.8


@dataclass
class NotificationsConfig:
    ntfy_topic: str = ""
    subject_prefix: str = "Producer"


@dataclass
class AuthConfig:
    """Auth and config-isolation mode for ``ClaudeAgentInvoker``.

    ``mode``:
        - ``auto`` (default): detect at startup. API_KEY → isolated;
          ``.credentials.json`` exists → isolated; else inherit (warn logged).
        - ``isolated``: force ``CLAUDE_CONFIG_DIR`` override. Errors if no
          API_KEY and no ``.credentials.json`` (the existing behavior).
        - ``inherit``: no ``CLAUDE_CONFIG_DIR`` override. Subprocess inherits
          the user's ``~/.claude``. Required for OAuth/Keychain auth.
    """

    mode: str = "auto"


_VALID_AUTH_MODES = {"auto", "isolated", "inherit"}


@dataclass
class ProducerConfig:
    project_name: str
    project_root: Path
    kill_switch: Path
    poll_interval_seconds: float
    idle_threshold_polls: int
    notifications: NotificationsConfig
    budget: BudgetConfig
    roles: dict[str, RoleConfig]
    ledger_db: Path
    escalations_dir: Path
    reports_dir: Path
    auth: AuthConfig = field(default_factory=AuthConfig)

    def role_caps_dict(self) -> dict[str, dict[str, float]]:
        """Shape expected by :class:`producer.budget.BudgetTracker`."""
        return {
            name: {"daily_cap_usd": role.daily_cap_usd}
            for name, role in self.roles.items()
        }


def load_config(path: Path | str) -> ProducerConfig:
    """Parse a ``producer.yaml`` and return a :class:`ProducerConfig`.

    Path fields are resolved relative to ``project_root`` (which is itself
    resolved relative to the YAML file's parent if given as a relative
    path). Missing optional fields fall back to documented defaults.
    """
    cfg_path = Path(path).resolve()
    data = yaml.safe_load(cfg_path.read_text(encoding="utf-8"))

    raw_root = data.get("project_root", ".")
    project_root = Path(raw_root)
    if not project_root.is_absolute():
        project_root = (cfg_path.parent / project_root).resolve()
    else:
        project_root = project_root.resolve()

    roles: dict[str, RoleConfig] = {}
    for name, raw in data.get("budget", {}).get("agents", {}).items():
        roles[name] = RoleConfig(
            name=name,
            daily_cap_usd=float(raw["daily_cap_usd"]),
            allowed_tools=list(raw.get("allowed_tools", [])),
            dispatch_reservation_usd=float(raw.get("dispatch_reservation_usd", 0.10)),
            prompt=raw.get("prompt"),
        )

    notifications = NotificationsConfig(
        ntfy_topic=data.get("notifications", {}).get("ntfy_topic", ""),
        subject_prefix=data.get("notifications", {}).get("subject_prefix", "Producer"),
    )
    budget = BudgetConfig(
        project_ceiling_usd=float(data["budget"]["project_ceiling_usd"]),
        soft_cap_ratio=float(data["budget"].get("soft_cap_ratio", 0.8)),
    )
    auth_data = data.get("auth", {}) or {}
    auth_mode = auth_data.get("mode", "auto")
    if auth_mode not in _VALID_AUTH_MODES:
        raise ValueError(
            f"auth.mode must be one of {sorted(_VALID_AUTH_MODES)}; got {auth_mode!r}"
        )
    auth = AuthConfig(mode=auth_mode)

    return ProducerConfig(
        project_name=data["project_name"],
        project_root=project_root,
        kill_switch=project_root / data.get("kill_switch", "agent-state/kill_switch"),
        poll_interval_seconds=float(data.get("poll_interval_seconds", 10)),
        idle_threshold_polls=int(data.get("idle_threshold_polls", 12)),
        notifications=notifications,
        budget=budget,
        roles=roles,
        ledger_db=project_root / data.get("ledger_db", "agent-state/ledger.db"),
        escalations_dir=project_root / data.get("escalations_dir", "agent-state/escalations"),
        reports_dir=project_root / data.get("reports_dir", "agent-state"),
        auth=auth,
    )
