"""``producer pricing update`` worker.

Drives a one-shot Claude Agent SDK call with WebFetch to read the official
Anthropic pricing page and emits a fresh ``pricing.json``. Validates the
response shape and rate plausibility before any filesystem write.
"""

from __future__ import annotations

import json
import logging
import os
import textwrap
from pathlib import Path
from typing import Any, Awaitable, Callable

from producer.pricing import PRICING_PATH

logger = logging.getLogger("producer.pricing_updater")

#: Module-level so tests can monkeypatch.
TARGET_PATH: Path = PRICING_PATH

REQUIRED_TOP_KEYS = {"last_updated", "source_url", "currency", "models"}
REQUIRED_RATE_KEYS = {
    "input_per_mtok_usd",
    "output_per_mtok_usd",
    "cache_creation_per_mtok_usd",
    "cache_read_per_mtok_usd",
}
MAX_PLAUSIBLE_RATE_USD_PER_MTOK = 1000.0


class PricingUpdateError(RuntimeError):
    """Update aborted — bad response, validation failure, or write error."""


_PROMPT = textwrap.dedent("""\
    Fetch this URL: {url}

    Read the per-model pricing table on that page and return ONLY a JSON object
    matching this exact schema (no markdown, no prose, no code fences):

    {{
      "last_updated": "<today YYYY-MM-DD>",
      "source_url": "{url}",
      "currency": "USD",
      "models": {{
        "<model-id>": {{
          "input_per_mtok_usd": <number>,
          "output_per_mtok_usd": <number>,
          "cache_creation_per_mtok_usd": <number>,
          "cache_read_per_mtok_usd": <number>
        }}
      }}
    }}

    Use these model IDs exactly as Anthropic publishes them. Include rates for
    Opus, Sonnet, and Haiku families (latest version of each). Omit models
    for which a rate is not published.
""")


def _default_runner_factory(cwd: Path) -> Callable[..., Awaitable[Any]]:
    """Return an async callable that runs a single Claude Agent SDK query."""
    from producer.invoker import ClaudeAgentInvoker

    invoker = ClaudeAgentInvoker(cwd=cwd)

    async def runner(*, prompt: str, **kwargs: Any) -> Any:
        return await invoker.invoke(
            agent_role="producer",
            prompt=prompt,
            allowed_tools=["WebFetch"],
            max_turns=4,
        )

    return runner


def _validate(payload: dict[str, Any]) -> None:
    missing = REQUIRED_TOP_KEYS - payload.keys()
    if missing:
        raise PricingUpdateError(f"response missing required top-level keys: {missing}")
    if not isinstance(payload["models"], dict) or not payload["models"]:
        raise PricingUpdateError("response.models must be a non-empty object")
    for model, rates in payload["models"].items():
        if not isinstance(rates, dict):
            raise PricingUpdateError(f"rates for {model!r} must be an object")
        missing_rate = REQUIRED_RATE_KEYS - rates.keys()
        if missing_rate:
            raise PricingUpdateError(
                f"model {model!r} missing rate keys: {missing_rate}"
            )
        for k in REQUIRED_RATE_KEYS:
            v = rates[k]
            if not isinstance(v, (int, float)) or v < 0:
                raise PricingUpdateError(
                    f"model {model!r} rate {k} must be a non-negative number"
                )
            if v > MAX_PLAUSIBLE_RATE_USD_PER_MTOK:
                raise PricingUpdateError(
                    f"model {model!r} rate {k}={v} fails sanity bound "
                    f"(>{MAX_PLAUSIBLE_RATE_USD_PER_MTOK})"
                )


def _diff(old: dict[str, Any], new: dict[str, Any]) -> dict[str, Any]:
    """Return a per-model rate-change summary for printing."""
    changes: dict[str, Any] = {}
    old_models = (old or {}).get("models", {}) or {}
    new_models = new.get("models", {}) or {}
    for model in sorted(set(old_models) | set(new_models)):
        old_rates = old_models.get(model, {})
        new_rates = new_models.get(model, {})
        per_model: dict[str, tuple[float | None, float | None]] = {}
        for k in REQUIRED_RATE_KEYS:
            ov = old_rates.get(k)
            nv = new_rates.get(k)
            if ov != nv:
                per_model[k] = (ov, nv)
        if per_model or model not in old_models or model not in new_models:
            changes[model] = per_model
    return changes


async def update_pricing(
    *,
    dry_run: bool = False,
    runner: Callable[..., Awaitable[Any]] | None = None,
    cwd: Path | None = None,
) -> dict[str, Any]:
    """Fetch live pricing, validate, atomically write ``pricing.json``.

    Returns the diff dict produced by :func:`_diff` so the CLI can print it.
    Raises :class:`PricingUpdateError` on any validation failure; the
    existing file is not modified in that case.
    """
    cwd = cwd or Path.cwd()

    try:
        old = json.loads(TARGET_PATH.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError):
        old = {}

    source_url = (old.get("source_url")
                  or "https://docs.anthropic.com/en/docs/about-claude/pricing")
    prompt = _PROMPT.format(url=source_url)

    runner = runner or _default_runner_factory(cwd)
    result = await runner(prompt=prompt)
    text = getattr(result, "text", "") or ""
    try:
        payload = json.loads(text)
    except json.JSONDecodeError as exc:
        raise PricingUpdateError(
            f"runner returned non-JSON output: {exc}"
        ) from exc

    _validate(payload)
    diff = _diff(old, payload)

    if dry_run:
        logger.info("dry-run: would write %s", TARGET_PATH)
        return diff

    tmp = TARGET_PATH.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    os.replace(tmp, TARGET_PATH)
    logger.info("wrote %s", TARGET_PATH)
    return diff
