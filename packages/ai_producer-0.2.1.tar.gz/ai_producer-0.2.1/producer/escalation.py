"""Human-attention notifications and escalation file rendering.

Two sinks for any "human, look at this" event:

1. **File marker** at ``<reports_dir>/needs-attention.md`` — appended to,
   never overwritten. Always written, even if ntfy fails.
2. **ntfy.sh push** to ``<ntfy_topic>`` if configured. Best-effort; failures
   are logged at warning level but never propagate.

Per-task escalations write a separate markdown file under ``escalations_dir``
with full context (description, payload, recommended action).
"""

from __future__ import annotations

import json
import logging
import textwrap
import urllib.request
from email.header import Header
from pathlib import Path
from typing import Any

from producer.ledger import utc_iso_now

logger = logging.getLogger("producer.escalation")


def _ascii_safe_header(value: str) -> str:
    """Return an HTTP-header-safe version of *value*.

    urllib serialises headers as latin-1; ntfy.sh decodes RFC 2047
    encoded-words. Non-ASCII input (em-dashes, smart quotes, etc.) is
    encoded; pure ASCII passes through unchanged.
    """
    try:
        value.encode("ascii")
    except UnicodeEncodeError:
        return Header(value, "utf-8").encode()
    return value


def notify_human(
    *,
    marker_path: Path,
    ntfy_topic: str,
    subject_prefix: str,
    subject: str,
    body: str,
    priority: str = "default",
    tags: str = "robot",
) -> None:
    """Write a file marker + optionally push via ntfy.sh. Never raises."""
    try:
        marker_path.parent.mkdir(parents=True, exist_ok=True)
        with marker_path.open("a", encoding="utf-8") as f:
            f.write(f"\n## {utc_iso_now()} — {subject}\n\n{body}\n")
    except OSError as exc:
        logger.warning("Could not write attention marker: %s", exc)

    if ntfy_topic:
        try:
            req = urllib.request.Request(
                f"https://ntfy.sh/{ntfy_topic}",
                data=body.encode("utf-8"),
                headers={
                    "Title": _ascii_safe_header(f"{subject_prefix} — {subject}"),
                    "Priority": priority,
                    "Tags": tags,
                },
            )
            urllib.request.urlopen(req, timeout=5)
            logger.info("ntfy.sh notification sent: %s", subject)
        except Exception as exc:  # noqa: BLE001 — never let notification kill the loop
            logger.warning("ntfy.sh notification failed: %s", exc)


def render_escalation(*, task: Any, reason: str) -> str:
    """Render the per-task escalation markdown file."""
    return textwrap.dedent(
        f"""\
        # Escalation: {task.title}

        **Task ID:** `{task.id}`
        **Agent:** {task.agent_owner}
        **Sprint:** {task.sprint_id or '(none)'}
        **Reason:** {reason}
        **Time:** {utc_iso_now()}

        ## Description

        {task.description}

        ## Payload

        ```json
        {json.dumps(task.payload, indent=2)}
        ```

        ## Recommended action

        Review the failure context, decide whether to:
          1. Retry with adjusted payload (set status back to `pending`).
          2. Kill the task (set status to `killed`).
          3. Re-route to a different agent (edit `agent_owner`, set `pending`).
        """
    )
