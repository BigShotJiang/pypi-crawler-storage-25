"""Pricing table loader, cost computation, and staleness check.

The pricing data lives in ``producer/pricing.json`` (bundled in the wheel via
hatch force-include, same pattern as ``schema.sql``). Refresh it with
``producer pricing update``.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

logger = logging.getLogger("producer.pricing")

#: Threshold beyond which the pricing table is considered stale.
STALENESS_DAYS = 90

#: Path to the bundled pricing data. Module-level so tests can monkeypatch.
PRICING_PATH = Path(__file__).parent / "pricing.json"


class PricingError(RuntimeError):
    """Raised when the pricing table is missing, malformed, or unusable."""


_cache: tuple[float, dict[str, Any]] | None = None  # (mtime, parsed-json)


def _cache_clear() -> None:
    """Reset the in-memory cache. Used by tests after monkeypatching PRICING_PATH."""
    global _cache
    _cache = None


def load_pricing() -> dict[str, Any]:
    """Read and parse ``pricing.json``.

    Caches by file mtime so repeated calls don't re-parse. Raises
    :class:`PricingError` on missing file or invalid JSON.
    """
    global _cache
    path = PRICING_PATH
    if not path.exists():
        raise PricingError(f"pricing.json missing at {path}")
    mtime = path.stat().st_mtime
    if _cache is not None and _cache[0] == mtime:
        return _cache[1]
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise PricingError(f"pricing.json is malformed: {exc}") from exc
    _cache = (mtime, data)
    return data


def compute_cost(model: str, usage: dict[str, int]) -> float:
    """Compute USD cost from token counts × per-MTok rates.

    Args:
        model: Model identifier (e.g. ``"claude-opus-4-7"``).
        usage: Dict with any subset of these keys; missing keys are treated
            as 0:
            ``input_tokens``, ``output_tokens``,
            ``cache_creation_input_tokens``, ``cache_read_input_tokens``.

    Returns:
        Cost in USD. Returns 0.0 (and logs a warning) when ``model`` has no
        entry in the table — the dispatch loop must not break just because
        a brand-new model was used before the table was refreshed.
    """
    rates = load_pricing()["models"].get(model)
    if rates is None:
        logger.warning(
            "no pricing entry for model=%s; computed_cost=0 — run "
            "`producer pricing update`",
            model,
        )
        return 0.0
    input_tokens = usage.get("input_tokens", 0)
    output_tokens = usage.get("output_tokens", 0)
    cache_creation = usage.get("cache_creation_input_tokens", 0)
    cache_read = usage.get("cache_read_input_tokens", 0)
    return (
        input_tokens * rates["input_per_mtok_usd"]
        + output_tokens * rates["output_per_mtok_usd"]
        + cache_creation * rates["cache_creation_per_mtok_usd"]
        + cache_read * rates["cache_read_per_mtok_usd"]
    ) / 1_000_000


def is_stale(now: datetime | None = None) -> tuple[bool, int]:
    """Return ``(is_stale, age_days)``.

    ``age_days`` is the integer number of UTC days between the table's
    ``last_updated`` and ``now`` (defaults to current UTC time).

    Raises :class:`PricingError` if ``last_updated`` is missing or not a
    valid ``YYYY-MM-DD`` string.
    """
    data = load_pricing()
    try:
        last = datetime.strptime(data["last_updated"], "%Y-%m-%d").replace(
            tzinfo=timezone.utc
        )
    except (KeyError, ValueError) as exc:
        raise PricingError(
            f"pricing.json has invalid last_updated: {exc}"
        ) from exc
    now = now or datetime.now(timezone.utc)
    age_days = (now - last).days
    return age_days > STALENESS_DAYS, age_days
