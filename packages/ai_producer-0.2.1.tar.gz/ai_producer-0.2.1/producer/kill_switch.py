"""File-based kill switch.

A file containing ``1`` means armed; missing-file or content ``0`` means
disarmed. Every agent's poll loop should call :meth:`is_armed` and exit
cleanly if so.
"""

from __future__ import annotations

import logging
from pathlib import Path

from producer.ledger import utc_iso_now

logger = logging.getLogger("producer.kill_switch")


class KillSwitchWatcher:
    def __init__(self, path: Path | str) -> None:
        self.path = Path(path).resolve()

    def is_armed(self) -> bool:
        try:
            content = self.path.read_text(encoding="utf-8").strip()
        except FileNotFoundError:
            return False
        except OSError as exc:
            logger.warning("kill-switch read failed: %s — treating as disarmed", exc)
            return False
        return content == "1"

    def arm(self, reason: str) -> None:
        """Flip the switch. Records the reason as a sibling file."""
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text("1\n", encoding="utf-8")
        marker = self.path.with_suffix(".reason")
        marker.write_text(f"{utc_iso_now()}: {reason}\n", encoding="utf-8")

    def disarm(self) -> None:
        if self.path.exists():
            self.path.write_text("0\n", encoding="utf-8")
