"""SQLite-WAL ledger primitives.

Owns:
    * ``LedgerClient``  — connection management, schema init, task lifecycle.
    * ``Task``          — typed row from the ``tasks`` table.
    * ``AuditLogger``   — convenience facade over ``append_audit``.

Cross-process safety comes from WAL + ``BEGIN IMMEDIATE`` plus the
optimistic-lock ``WHERE status=...`` predicate on each claim.
"""

from __future__ import annotations

import contextlib
import hashlib
import json
import logging
import sqlite3
import threading
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator

logger = logging.getLogger("producer.ledger")


#: Genesis prev_hash for the audit chain (64 zero hex chars).
AUDIT_GENESIS_PREV_HASH: str = "0" * 64

#: Bundled schema path — packaged with the wheel via hatch force-include.
_SCHEMA_PATH = Path(__file__).parent / "schema.sql"


def utc_iso_now() -> str:
    """ISO-8601 UTC timestamp with second precision and trailing Z."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def utc_today() -> str:
    """YYYY-MM-DD UTC."""
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")


def new_id(prefix: str = "01HYK") -> str:
    """Return a 26-char ULID-shaped id.

    Stays stdlib-only (uuid4 hex, not real ULID). Sorts roughly by insertion
    time within a process; uniqueness is what matters for primary keys.
    """
    raw = uuid.uuid4().hex.upper()
    return (prefix + raw)[:26]


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------


class LedgerError(RuntimeError):
    """Any unrecoverable interaction with the ledger."""


class TaskClaimRace(LedgerError):
    """Another poller claimed this task before we could update it."""


# ---------------------------------------------------------------------------
# Task row
# ---------------------------------------------------------------------------


@dataclass
class Task:
    """Row from the ``tasks`` table."""

    id: str
    agent_owner: str
    status: str
    title: str
    description: str
    parent_task_id: str | None
    dependencies: list[str]
    payload: dict[str, Any]
    output_refs: list[str]
    priority: int
    sprint_id: str | None
    created_at: str
    started_at: str | None
    finished_at: str | None
    retry_count: int
    escalation_reason: str | None
    cost_usd: float
    actual_cost_usd: float | None
    config_isolation: str | None

    @classmethod
    def from_row(cls, row: sqlite3.Row) -> "Task":
        return cls(
            id=row["id"],
            agent_owner=row["agent_owner"],
            status=row["status"],
            title=row["title"],
            description=row["description"],
            parent_task_id=row["parent_task_id"],
            dependencies=json.loads(row["dependencies"] or "[]"),
            payload=json.loads(row["payload"] or "{}"),
            output_refs=json.loads(row["output_refs"] or "[]"),
            priority=row["priority"],
            sprint_id=row["sprint_id"],
            created_at=row["created_at"],
            started_at=row["started_at"],
            finished_at=row["finished_at"],
            retry_count=row["retry_count"],
            escalation_reason=row["escalation_reason"],
            cost_usd=row["cost_usd"],
            actual_cost_usd=row["actual_cost_usd"],
            config_isolation=row["config_isolation"],
        )


# ---------------------------------------------------------------------------
# Ledger client
# ---------------------------------------------------------------------------


class LedgerClient:
    """Thin wrapper over the SQLite ledger.

    One ``LedgerClient`` per process. Internally guards a single ``Connection``
    with a re-entrant lock so concurrent threads in the same agent don't
    interleave transactions. Cross-process safety comes from WAL + ``BEGIN
    IMMEDIATE`` plus the optimistic-lock ``WHERE status=...`` predicate on
    each claim.
    """

    def __init__(self, db_path: Path | str) -> None:
        self.db_path = Path(db_path).resolve()
        self._lock = threading.RLock()
        self._conn: sqlite3.Connection | None = None
        self._ensure_schema()
        self._apply_migrations()

    # -- connection management ----------------------------------------------

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(
            self.db_path,
            timeout=30.0,
            isolation_level=None,  # we manage transactions explicitly
            check_same_thread=False,
        )
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode = WAL;")
        conn.execute("PRAGMA synchronous = NORMAL;")
        conn.execute("PRAGMA foreign_keys = ON;")
        conn.execute("PRAGMA busy_timeout = 5000;")
        return conn

    @property
    def conn(self) -> sqlite3.Connection:
        if self._conn is None:
            self._conn = self._connect()
        return self._conn

    @contextlib.contextmanager
    def transaction(self, immediate: bool = True) -> Iterator[sqlite3.Connection]:
        """Wrap a write block in a transaction.

        ``immediate=True`` (default) acquires the write lock at BEGIN time so
        two pollers can't both think they have it and clobber each other on
        commit. Read-only blocks can pass ``immediate=False``.
        """
        with self._lock:
            self.conn.execute("BEGIN IMMEDIATE" if immediate else "BEGIN")
            try:
                yield self.conn
            except Exception:
                self.conn.execute("ROLLBACK")
                raise
            else:
                self.conn.execute("COMMIT")

    def close(self) -> None:
        with self._lock:
            if self._conn is not None:
                self._conn.close()
                self._conn = None

    # -- schema -------------------------------------------------------------

    def _apply_migrations(self) -> None:
        """Idempotent ALTER TABLEs to bring older ledgers forward.

        SQLite cannot add NOT NULL columns to existing tables without a
        default, so additive migrations live here rather than in schema.sql.
        """
        with self._lock:
            cols = {
                row["name"]
                for row in self.conn.execute("PRAGMA table_info(tasks)")
            }
            if "actual_cost_usd" not in cols:
                self.conn.execute("ALTER TABLE tasks ADD COLUMN actual_cost_usd REAL")
            if "config_isolation" not in cols:
                self.conn.execute("ALTER TABLE tasks ADD COLUMN config_isolation TEXT")

    def _ensure_schema(self) -> None:
        if not self.db_path.parent.exists():
            self.db_path.parent.mkdir(parents=True, exist_ok=True)
        if not _SCHEMA_PATH.exists():
            raise LedgerError(f"schema.sql missing at {_SCHEMA_PATH}")
        with self._lock:
            self.conn.executescript(_SCHEMA_PATH.read_text(encoding="utf-8"))

    # -- task lifecycle -----------------------------------------------------

    def list_ready_tasks(
        self,
        agent_owner: str | None = None,
        limit: int = 50,
    ) -> list[Task]:
        """Return tasks whose dependencies are all in 'done' state."""
        sql = (
            "SELECT * FROM tasks WHERE status = 'pending'"
            + (" AND agent_owner = ?" if agent_owner else "")
            + " ORDER BY priority ASC, created_at ASC LIMIT ?"
        )
        params: tuple[Any, ...] = (
            (agent_owner, limit) if agent_owner else (limit,)
        )
        with self._lock:
            rows = self.conn.execute(sql, params).fetchall()
        ready: list[Task] = []
        for row in rows:
            task = Task.from_row(row)
            if self._dependencies_satisfied(task):
                ready.append(task)
        return ready

    def _dependencies_satisfied(self, task: Task) -> bool:
        if not task.dependencies:
            return True
        placeholders = ",".join("?" * len(task.dependencies))
        sql = f"SELECT id, status FROM tasks WHERE id IN ({placeholders})"
        with self._lock:
            rows = self.conn.execute(sql, tuple(task.dependencies)).fetchall()
        statuses = {r["id"]: r["status"] for r in rows}
        return all(statuses.get(dep_id) == "done" for dep_id in task.dependencies)

    def claim_task(self, task_id: str, agent_owner: str) -> Task:
        """Move a pending task to in_progress for ``agent_owner``.

        Raises :class:`TaskClaimRace` if another poller got there first.
        """
        now = utc_iso_now()
        with self.transaction():
            cur = self.conn.execute(
                "UPDATE tasks SET status='in_progress', agent_owner=?, started_at=? "
                "WHERE id=? AND status='pending'",
                (agent_owner, now, task_id),
            )
            if cur.rowcount == 0:
                raise TaskClaimRace(f"task {task_id} no longer pending")
            row = self.conn.execute(
                "SELECT * FROM tasks WHERE id=?", (task_id,)
            ).fetchone()
        return Task.from_row(row)

    def complete_task(
        self,
        task_id: str,
        *,
        output_refs: list[str] | None = None,
        cost_usd: float = 0.0,
        actual_cost_usd: float | None = None,
        config_isolation: str | None = None,
    ) -> None:
        """Mark a task done and record per-task cost.

        ``cost_usd`` is the computed cost (always populated by the dispatcher).
        ``actual_cost_usd`` is the SDK-reported cost — None under subscription
        auth where Anthropic does not surface a per-call dollar figure.
        ``config_isolation`` is the config isolation mode used by the invoker.
        """
        with self.transaction():
            self.conn.execute(
                "UPDATE tasks SET status='done', finished_at=?, output_refs=?, "
                "cost_usd=?, actual_cost_usd=?, config_isolation=? "
                "WHERE id=? AND status='in_progress'",
                (
                    utc_iso_now(),
                    json.dumps(output_refs or []),
                    cost_usd,
                    actual_cost_usd,
                    config_isolation,
                    task_id,
                ),
            )

    def fail_task(self, task_id: str, error_summary: str) -> int:
        """Mark a task failed; bump retry_count; return the new retry_count."""
        with self.transaction():
            self.conn.execute(
                "UPDATE tasks SET status='failed', finished_at=?, "
                "escalation_reason=?, retry_count = retry_count + 1 "
                "WHERE id=?",
                (utc_iso_now(), error_summary, task_id),
            )
            row = self.conn.execute(
                "SELECT retry_count FROM tasks WHERE id=?", (task_id,)
            ).fetchone()
        return int(row["retry_count"]) if row else 0

    def requeue_task(self, task_id: str) -> None:
        """Reset a failed task back to pending for another attempt."""
        with self.transaction():
            self.conn.execute(
                "UPDATE tasks SET status='pending', started_at=NULL, finished_at=NULL "
                "WHERE id=? AND status='failed'",
                (task_id,),
            )

    def escalate_task(self, task_id: str, reason: str) -> None:
        with self.transaction():
            self.conn.execute(
                "UPDATE tasks SET status='escalated', finished_at=?, "
                "escalation_reason=? WHERE id=?",
                (utc_iso_now(), reason, task_id),
            )

    def kill_task(self, task_id: str, reason: str) -> None:
        with self.transaction():
            self.conn.execute(
                "UPDATE tasks SET status='killed', finished_at=?, "
                "escalation_reason=? WHERE id=?",
                (utc_iso_now(), reason, task_id),
            )

    # -- decisions / assets / inserts --------------------------------------

    def record_decision(
        self,
        *,
        task_id: str | None,
        agent_owner: str,
        kind: str,
        decision_text: str,
        rationale: str,
        artifact: str | None = None,
    ) -> str:
        decision_id = new_id("01HYKD")
        with self.transaction():
            self.conn.execute(
                "INSERT INTO decisions (id, task_id, agent_owner, kind, "
                "decision_text, rationale, artifact, made_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    decision_id,
                    task_id,
                    agent_owner,
                    kind,
                    decision_text,
                    rationale,
                    artifact,
                    utc_iso_now(),
                ),
            )
        return decision_id

    def record_asset(
        self,
        *,
        asset_type: str,
        path: str,
        agent_id: str,
        cost_usd: float,
        wall_clock_seconds: float,
        prompt: str | None = None,
        seed: str | None = None,
        api: str | None = None,
        model: str | None = None,
        model_version: str | None = None,
        retry_count: int = 0,
        critic_verdicts: list[dict[str, Any]] | None = None,
        sha256: str | None = None,
        task_id: str | None = None,
        disposition: str = "shipped",
    ) -> str:
        asset_id = new_id("01HYKA")
        with self.transaction():
            self.conn.execute(
                "INSERT INTO asset_registry "
                "(id, asset_type, path, prompt, seed, api, model, model_version, "
                " retry_count, critic_verdicts, cost_usd, wall_clock_seconds, "
                " agent_id, task_id, sha256, timestamp, disposition) "
                "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (
                    asset_id,
                    asset_type,
                    path,
                    prompt,
                    seed,
                    api,
                    model,
                    model_version,
                    retry_count,
                    json.dumps(critic_verdicts or []),
                    cost_usd,
                    wall_clock_seconds,
                    agent_id,
                    task_id,
                    sha256,
                    utc_iso_now(),
                    disposition,
                ),
            )
        return asset_id

    def insert_task(
        self,
        *,
        agent_owner: str,
        title: str,
        description: str,
        dependencies: list[str] | None = None,
        payload: dict[str, Any] | None = None,
        priority: int = 3,
        sprint_id: str | None = None,
        parent_task_id: str | None = None,
        task_id: str | None = None,
    ) -> str:
        task_id = task_id or new_id("01HYKT")
        with self.transaction():
            self.conn.execute(
                "INSERT INTO tasks (id, agent_owner, status, title, description, "
                "parent_task_id, dependencies, payload, priority, sprint_id, "
                "created_at) VALUES (?, ?, 'pending', ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    task_id,
                    agent_owner,
                    title,
                    description,
                    parent_task_id,
                    json.dumps(dependencies or []),
                    json.dumps(payload or {}),
                    priority,
                    sprint_id,
                    utc_iso_now(),
                ),
            )
        return task_id

    def get_task(self, task_id: str) -> Task | None:
        with self._lock:
            row = self.conn.execute(
                "SELECT * FROM tasks WHERE id=?", (task_id,)
            ).fetchone()
        return Task.from_row(row) if row else None

    # -- budget -------------------------------------------------------------

    def update_budget(
        self,
        agent_owner: str,
        delta_usd: float,
        *,
        hard_cap_usd: float,
        soft_cap_ratio: float,
    ) -> tuple[float, float, float]:
        """Increment today's spent_usd for ``agent_owner``.

        Returns ``(spent, soft_cap, hard_cap)`` after the update. Inserts the
        row with the supplied caps if today's row is missing. Caps are passed
        in (not looked up from a global) so the ledger stays role-config
        agnostic.
        """
        today = utc_today()
        soft_cap = hard_cap_usd * soft_cap_ratio
        with self.transaction():
            self.conn.execute(
                "INSERT INTO budget (agent_owner, date, spent_usd, hard_cap_usd, soft_cap_usd) "
                "VALUES (?, ?, 0, ?, ?) "
                "ON CONFLICT(agent_owner, date) DO NOTHING",
                (agent_owner, today, hard_cap_usd, soft_cap),
            )
            self.conn.execute(
                "UPDATE budget SET spent_usd = spent_usd + ? "
                "WHERE agent_owner=? AND date=?",
                (delta_usd, agent_owner, today),
            )
            row = self.conn.execute(
                "SELECT spent_usd, soft_cap_usd, hard_cap_usd FROM budget "
                "WHERE agent_owner=? AND date=?",
                (agent_owner, today),
            ).fetchone()
        return (row["spent_usd"], row["soft_cap_usd"], row["hard_cap_usd"])

    def total_spend_today(self) -> float:
        today = utc_today()
        with self._lock:
            row = self.conn.execute(
                "SELECT COALESCE(SUM(spent_usd),0) AS t FROM budget WHERE date=?",
                (today,),
            ).fetchone()
        return float(row["t"])

    def budget_state(
        self,
        agent_owner: str,
        *,
        hard_cap_usd: float,
        soft_cap_ratio: float,
    ) -> tuple[float, float, float]:
        """Return current ``(spent, soft_cap, hard_cap)`` for today."""
        today = utc_today()
        soft_cap = hard_cap_usd * soft_cap_ratio
        with self.transaction():
            self.conn.execute(
                "INSERT INTO budget (agent_owner, date, spent_usd, hard_cap_usd, soft_cap_usd) "
                "VALUES (?, ?, 0, ?, ?) "
                "ON CONFLICT(agent_owner, date) DO NOTHING",
                (agent_owner, today, hard_cap_usd, soft_cap),
            )
            row = self.conn.execute(
                "SELECT spent_usd, soft_cap_usd, hard_cap_usd FROM budget "
                "WHERE agent_owner=? AND date=?",
                (agent_owner, today),
            ).fetchone()
        return (row["spent_usd"], row["soft_cap_usd"], row["hard_cap_usd"])

    # -- audit chain --------------------------------------------------------

    def latest_audit_hash(self) -> str:
        with self._lock:
            row = self.conn.execute(
                "SELECT row_hash FROM audit_log ORDER BY id DESC LIMIT 1"
            ).fetchone()
        return row["row_hash"] if row else AUDIT_GENESIS_PREV_HASH

    def append_audit(
        self,
        *,
        agent_owner: str,
        action: str,
        detail: dict[str, Any],
        cost_usd: float = 0.0,
        task_id: str | None = None,
    ) -> str:
        """Append an audit row with proper hash chaining. Returns the row_hash.

        The chain: ``row_hash = sha256(prev_hash | agent | task_id | action |
        detail_json | cost | ts)``. Genesis ``prev_hash`` is 64 zeros.
        """
        ts = utc_iso_now()
        detail_json = json.dumps(detail, sort_keys=True, ensure_ascii=False)
        with self.transaction():
            prev_row = self.conn.execute(
                "SELECT row_hash FROM audit_log ORDER BY id DESC LIMIT 1"
            ).fetchone()
            prev_hash = prev_row["row_hash"] if prev_row else AUDIT_GENESIS_PREV_HASH
            payload = "|".join(
                [
                    prev_hash,
                    agent_owner,
                    task_id or "",
                    action,
                    detail_json,
                    f"{cost_usd:.6f}",
                    ts,
                ]
            )
            row_hash = hashlib.sha256(payload.encode("utf-8")).hexdigest()
            self.conn.execute(
                "INSERT INTO audit_log "
                "(agent_owner, task_id, action, detail, cost_usd, timestamp, "
                " prev_hash, row_hash) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    agent_owner,
                    task_id,
                    action,
                    detail_json,
                    cost_usd,
                    ts,
                    prev_hash,
                    row_hash,
                ),
            )
        return row_hash

    # -- seed loading -------------------------------------------------------

    def seed_from_json(self, json_path: Path) -> int:
        """Bulk-insert seed tasks. Idempotent on (id) collisions."""
        data = json.loads(json_path.read_text(encoding="utf-8"))
        inserted = 0
        with self.transaction():
            for raw in data:
                cur = self.conn.execute(
                    "INSERT OR IGNORE INTO tasks "
                    "(id, agent_owner, status, title, description, parent_task_id, "
                    " dependencies, payload, priority, sprint_id, created_at) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (
                        raw["id"],
                        raw["agent_owner"],
                        raw.get("status", "pending"),
                        raw["title"],
                        raw["description"],
                        raw.get("parent_task_id"),
                        json.dumps(raw.get("dependencies", [])),
                        json.dumps(raw.get("payload", {})),
                        raw.get("priority", 3),
                        raw.get("sprint_id"),
                        raw["created_at"],
                    ),
                )
                if cur.rowcount:
                    inserted += 1
        return inserted


# ---------------------------------------------------------------------------
# Audit logger facade
# ---------------------------------------------------------------------------


class AuditLogger:
    """Convenience facade for callers that want a logger-shaped object.

    Identical contract to :meth:`LedgerClient.append_audit`; provided so an
    agent can stash a single ``AuditLogger`` on ``self`` rather than passing
    the ledger around for every event.
    """

    def __init__(self, ledger: LedgerClient, agent_owner: str) -> None:
        self.ledger = ledger
        self.agent_owner = agent_owner

    def event(
        self,
        action: str,
        detail: dict[str, Any] | None = None,
        *,
        task_id: str | None = None,
        cost_usd: float = 0.0,
    ) -> str:
        return self.ledger.append_audit(
            agent_owner=self.agent_owner,
            action=action,
            detail=detail or {},
            cost_usd=cost_usd,
            task_id=task_id,
        )
