"""Onboarding wizard + bootstrap-chat handoff for ``producer init``.

Pure functions live here so the interactive ``cmd_init`` flow stays small
and testable. The actual ``os.execvp`` call lives in ``cli.py``; everything
that builds *what* gets exec'd is here.
"""

from __future__ import annotations

import secrets
import shutil
import string
import sys
from pathlib import Path
from typing import Mapping


_TEMPLATES_DIR = Path(__file__).resolve().parent.parent / "templates"

_BOOTSTRAP_POINTER = (
    "You are bootstrapping a new ai-producer project. "
    "Read ONBOARDING.md in the current directory before doing anything else, "
    "then start the conversation with the user."
)


def preflight_claude_on_path() -> bool:
    """Return True if the ``claude`` CLI is resolvable on PATH."""
    return shutil.which("claude") is not None


def build_claude_argv(_project_root: str) -> list[str]:
    """Build the argv passed to ``os.execvp`` for the bootstrap chat.

    ``_project_root`` is currently informational — the user's terminal is
    already cd'd into the project — but is accepted so callers don't have
    to depend on cwd for argv construction. Reserved for future use (e.g. ``--add-dir``).
    """
    return [
        "claude",
        "--append-system-prompt",
        _BOOTSTRAP_POINTER,
        "--permission-mode",
        "acceptEdits",
    ]


def render_onboarding_md(project_name: str, project_root: str) -> str:
    """Render the bootstrap brief from the template.

    The output is what gets written to ``<project_root>/ONBOARDING.md`` and
    read by the bootstrap-chat agent at handoff.
    """
    template_path = _TEMPLATES_DIR / "onboarding.md.template"
    body = template_path.read_text(encoding="utf-8")
    return string.Template(body).substitute(
        project_name=project_name,
        project_root=project_root,
    )


def default_settings(target_root: Path) -> dict[str, str]:
    """Derive sensible defaults from the target directory.

    ``project_name`` comes from the basename. ``ntfy_topic`` includes a short
    random suffix so two users with the same project name don't collide on
    ntfy.sh by accident.
    """
    name = target_root.name or "my-project"
    suffix = secrets.token_hex(4)  # 8 hex chars
    return {
        "project_name": name,
        "ntfy_topic": f"{name}-{suffix}",
        "subject_prefix": name,
    }


def prompt_for_settings(
    *,
    defaults: Mapping[str, str],
    is_tty: bool | None = None,
) -> dict[str, str]:
    """Interactively collect settings, falling back to defaults on bare Enter.

    When ``is_tty`` is False (CI / pytest / piped stdin), returns defaults
    verbatim without ever calling ``input()``. Pass ``is_tty=None`` to detect
    automatically via ``sys.stdin.isatty()``.
    """
    if is_tty is None:
        is_tty = sys.stdin.isatty()
    if not is_tty:
        return dict(defaults)

    out: dict[str, str] = {}
    for key, label in (
        ("project_name", "Project name"),
        ("ntfy_topic", "ntfy.sh topic"),
        ("subject_prefix", "Notification subject prefix"),
    ):
        d = defaults[key]
        answer = input(f"{label} [{d}]: ").strip()
        out[key] = answer if answer else d
    return out
