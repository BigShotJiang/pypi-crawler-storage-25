"""Producer — the meta-coordinator agent.

Polls the ledger for ready tasks, dispatches each to its specialist agent
via the injected invoker, enforces per-agent budgets, watches the kill
switch, retries up to 3× then escalates, writes daily morning reports,
and notifies a human when the queue stalls or budgets near alarm.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import signal
import textwrap
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from producer.budget import BudgetExceeded, BudgetTracker
from producer.config import ProducerConfig
from producer.escalation import notify_human, render_escalation
from producer.invoker import ClaudeAgentInvoker, InvocationResult
from producer.kill_switch import KillSwitchWatcher
from producer.ledger import (
    AuditLogger,
    LedgerClient,
    Task,
    TaskClaimRace,
    utc_iso_now,
    utc_today,
)
from producer.morning_report import render_morning_report
from producer import pricing

logger = logging.getLogger("producer.dispatch")


# Policy constants — kept in code (not config) until burn-rate data shows
# they should be tunable per-project.
MAX_RETRIES_PER_TASK = 3
AGENT_FAILURE_BURST_THRESHOLD = 5
AGENT_FAILURE_BURST_WINDOW_MINUTES = 10
MORNING_REPORT_INTERVAL_SECONDS = 6 * 60 * 60
PRODUCER_FALLBACK_RESERVATION_USD = 0.05


@dataclass
class _ShutdownState:
    requested: bool = False


class Producer:
    """The meta-coordinator agent.

    Args:
        config: Loaded :class:`ProducerConfig`.
        ledger: Connected ledger.
        invoker: SDK invoker (real or fake — useful for tests/smoke).
        kill_switch: File-watcher.
    """

    def __init__(
        self,
        *,
        config: ProducerConfig,
        ledger: LedgerClient,
        invoker: ClaudeAgentInvoker | Any,
        kill_switch: KillSwitchWatcher,
    ) -> None:
        self.config = config
        self.ledger = ledger
        self.invoker = invoker
        self.kill_switch = kill_switch
        self.audit = AuditLogger(ledger, agent_owner="producer")
        self.budget = BudgetTracker(
            ledger,
            role_caps=config.role_caps_dict(),
            project_ceiling_usd=config.budget.project_ceiling_usd,
            soft_cap_ratio=config.budget.soft_cap_ratio,
        )
        self._shutdown = _ShutdownState()
        self._last_report_at: float = 0.0
        self._recent_failures: list[tuple[str, datetime]] = []
        self._idle_polls = 0
        self._idle_notified = False

    # -- shutdown plumbing --------------------------------------------------

    def request_shutdown(self, signum: int | None = None, _frame: Any = None) -> None:
        if signum is not None:
            logger.info("Received signal %s — flushing and exiting.", signum)
        self._shutdown.requested = True

    def install_signal_handlers(self) -> None:
        for sig in (signal.SIGTERM, signal.SIGINT):
            try:
                signal.signal(sig, self.request_shutdown)
            except (ValueError, OSError):  # not main thread, e.g. tests
                pass

    # -- main loops ---------------------------------------------------------

    async def run(self) -> None:
        """Long-running poll loop."""
        self.install_signal_handlers()
        self.audit.event(
            "producer_boot",
            {"poll_interval_s": self.config.poll_interval_seconds},
        )
        self._check_pricing_staleness()
        self._log_startup_banner()
        logger.info(
            "Producer online; poll interval %.1fs", self.config.poll_interval_seconds
        )
        while not self._shutdown.requested:
            try:
                n_dispatched = await self._tick()
            except Exception:
                logger.exception("Producer tick crashed; continuing after backoff")
                await asyncio.sleep(min(self.config.poll_interval_seconds * 2, 60))
                continue
            self._track_idle(n_dispatched)
            await asyncio.sleep(self.config.poll_interval_seconds)
        await self._flush_pending_writes()
        self.audit.event("producer_shutdown", {})
        logger.info("Producer shut down cleanly.")

    async def run_once(self) -> int:
        """Drain currently-ready tasks once and return number dispatched."""
        self.audit.event("producer_boot_once", {})
        self._check_pricing_staleness()
        self._log_startup_banner()
        dispatched = await self._tick()
        await self._flush_pending_writes()
        return dispatched

    async def _tick(self) -> int:
        if self.kill_switch.is_armed():
            logger.warning("Kill switch armed — refusing to dispatch.")
            self.audit.event("kill_switch_observed", {"action": "halt_intake"})
            return 0
        await self._maybe_emit_morning_report()

        ready_tasks = self.ledger.list_ready_tasks(limit=50)
        if not ready_tasks:
            logger.debug("No ready tasks this cycle.")
            return 0

        dispatched = 0
        for task in ready_tasks:
            if self._shutdown.requested:
                break
            if self.kill_switch.is_armed():
                break
            try:
                await self.dispatch_task(task)
                dispatched += 1
            except BudgetExceeded as exc:
                logger.warning(
                    "Budget block on %s (%s): %s", task.id, task.agent_owner, exc
                )
                self.handle_escalation(task, f"budget breached pre-dispatch: {exc}")
            except TaskClaimRace:
                logger.debug("Task %s claimed by another poller; skipping.", task.id)
            except Exception as exc:
                logger.exception("Dispatch of %s failed", task.id)
                self.handle_failure(task, str(exc))
        return dispatched

    # -- dispatch -----------------------------------------------------------

    async def dispatch_task(self, task: Task) -> None:
        """Route a ready task to its specialist agent."""
        if self.kill_switch.is_armed():
            logger.warning("Kill switch armed mid-dispatch; aborting %s", task.id)
            return

        target = task.agent_owner
        target_role = self.config.roles.get(target)
        if target_role is None:
            self.handle_escalation(task, f"unknown agent_owner / role not configured: {target}")
            return

        target_reservation = target_role.dispatch_reservation_usd
        producer_role = self.config.roles.get("producer")
        producer_reservation = (
            producer_role.dispatch_reservation_usd
            if producer_role is not None
            else PRODUCER_FALLBACK_RESERVATION_USD
        )
        if producer_role is None:
            logger.warning(
                "No 'producer' role in config; using fallback reservation $%.2f",
                PRODUCER_FALLBACK_RESERVATION_USD,
            )

        if not self.budget.can_spend("producer", producer_reservation):
            raise BudgetExceeded("Producer cap would breach on dispatch reservation")
        if not self.budget.can_spend(target, target_reservation):
            raise BudgetExceeded(
                f"{target} cap would breach on reservation ${target_reservation:.2f}"
            )

        claimed = self.ledger.claim_task(task.id, agent_owner=target)
        self.audit.event(
            "dispatch",
            {
                "task_id": task.id,
                "title": task.title,
                "agent_owner": target,
                "reservation_usd": target_reservation,
            },
            task_id=task.id,
        )
        self.ledger.record_decision(
            task_id=task.id,
            agent_owner="producer",
            kind="dispatch",
            decision_text=f"Routed task '{task.title}' to {target}",
            rationale=f"agent_owner={target}; deps satisfied; reservation=${target_reservation:.2f}",
        )

        try:
            self.budget.record_spend(
                "producer", producer_reservation, task_id=task.id, api="claude"
            )
        except BudgetExceeded as exc:
            logger.error("Producer cap breached: %s", exc)
            self.handle_escalation(claimed, f"producer cap breached: {exc}")
            return

        prompt = self._build_specialist_prompt(claimed)
        system_prompt = self._load_system_prompt(target)
        try:
            result = await self.invoker.invoke(
                agent_role=target,
                prompt=prompt,
                system_prompt=system_prompt,
                allowed_tools=target_role.allowed_tools,
                max_turns=16,
            )
        except Exception as exc:
            self.handle_failure(claimed, f"invocation error: {exc}")
            return

        try:
            self.budget.record_spend(
                target,
                max(result.cost_usd, 0.0),
                task_id=claimed.id,
                api="claude_agent_sdk",
            )
        except BudgetExceeded as exc:
            logger.error("%s cap breached after dispatch: %s", target, exc)
            self.audit.event(
                "budget_breach",
                {"agent": target, "task_id": claimed.id, "error": str(exc)},
                task_id=claimed.id,
            )
            self.handle_escalation(claimed, f"{target} cap breached: {exc}")
            return

        self.handle_completion(claimed, result)

    def _build_specialist_prompt(self, task: Task) -> str:
        payload_json = json.dumps(task.payload, indent=2)
        return textwrap.dedent(
            f"""\
            You are the {task.agent_owner.title()} agent for {self.config.project_name}.

            Task ID: {task.id}
            Title: {task.title}
            Sprint: {task.sprint_id or '(none)'}

            Description:
            {task.description}

            Payload:
            {payload_json}

            Operating contract:
            * Use ONLY the tools your role is granted (see your system prompt).
            * Record any decisions you make as a row in the ledger via the
              producer.LedgerClient.record_decision API.
            * Register every shippable artifact via record_asset.
            * On uncertainty above your authority, write a clear hand-off
              task for the relevant agent rather than reaching across.
            * Stop after producing the deliverable; the Producer will
              transition the task on completion.
            """
        )

    def _load_system_prompt(self, agent_role: str) -> str | None:
        role = self.config.roles.get(agent_role)
        if role is None or role.prompt is None:
            return None
        path = self.config.project_root / role.prompt
        if not path.exists():
            raise FileNotFoundError(
                f"System prompt for role '{agent_role}' missing at {path}"
            )
        return path.read_text(encoding="utf-8")

    # -- completion / failure / escalation ---------------------------------

    def handle_completion(self, task: Task, result: InvocationResult) -> None:
        """Mark the task done, persist per-task cost, and audit the result."""
        output_refs = self._extract_output_refs(result)
        self.ledger.complete_task(
            task.id,
            output_refs=output_refs,
            cost_usd=result.computed_cost_usd,
            actual_cost_usd=result.actual_cost_usd,
            config_isolation=result.config_isolation,
        )
        self.audit.event(
            "task_completed",
            {
                "task_id": task.id,
                "agent_owner": task.agent_owner,
                "computed_cost_usd": result.computed_cost_usd,
                "actual_cost_usd": result.actual_cost_usd,
                "auth_mode": result.auth_mode,
                "config_isolation": result.config_isolation,
                "output_refs": output_refs,
                "tool_calls": [tc.get("name") for tc in result.tool_calls],
            },
            task_id=task.id,
            cost_usd=result.computed_cost_usd,
        )
        logger.info(
            "Task %s done (%s, computed=$%.4f, actual=%s)",
            task.id,
            task.agent_owner,
            result.computed_cost_usd,
            f"${result.actual_cost_usd:.4f}" if result.actual_cost_usd is not None else "n/a",
        )

    def handle_failure(self, task: Task, error: str) -> None:
        retry_count = self.ledger.fail_task(task.id, error)
        self.audit.event(
            "task_failed",
            {
                "task_id": task.id,
                "agent_owner": task.agent_owner,
                "error": error,
                "retry_count": retry_count,
            },
            task_id=task.id,
        )
        self._record_recent_failure(task.agent_owner)
        if retry_count >= MAX_RETRIES_PER_TASK:
            self.handle_escalation(
                task,
                f"failed {retry_count}× (max {MAX_RETRIES_PER_TASK}); last error: {error}",
            )
            return
        self.ledger.requeue_task(task.id)
        logger.warning(
            "Re-queued %s (retry %d/%d): %s",
            task.id,
            retry_count,
            MAX_RETRIES_PER_TASK,
            error,
        )
        self._check_failure_burst(task.agent_owner)

    def handle_escalation(self, task: Task, reason: str) -> None:
        self.config.escalations_dir.mkdir(parents=True, exist_ok=True)
        path = self.config.escalations_dir / f"{task.id}.md"
        path.write_text(render_escalation(task=task, reason=reason), encoding="utf-8")
        self.ledger.escalate_task(task.id, reason)
        self.ledger.record_decision(
            task_id=task.id,
            agent_owner="producer",
            kind="escalate",
            decision_text=f"Escalated '{task.title}' to human",
            rationale=reason,
            artifact=str(path),
        )
        self.audit.event(
            "escalation",
            {
                "task_id": task.id,
                "agent_owner": task.agent_owner,
                "reason": reason,
                "path": str(path),
            },
            task_id=task.id,
        )
        logger.warning("Escalated %s: %s", task.id, reason)

    def _record_recent_failure(self, agent: str) -> None:
        now = datetime.now(timezone.utc)
        self._recent_failures.append((agent, now))
        cutoff_seconds = AGENT_FAILURE_BURST_WINDOW_MINUTES * 60
        self._recent_failures = [
            (a, ts)
            for (a, ts) in self._recent_failures
            if (now - ts).total_seconds() <= cutoff_seconds
        ]

    def _check_failure_burst(self, agent: str) -> None:
        recent = [a for (a, _ts) in self._recent_failures if a == agent]
        if len(recent) >= AGENT_FAILURE_BURST_THRESHOLD:
            reason = (
                f"{agent} failed {len(recent)}× in "
                f"{AGENT_FAILURE_BURST_WINDOW_MINUTES} min — kill switch armed"
            )
            self.kill_switch.arm(reason)
            self.audit.event("kill_switch_armed_by_producer", {"reason": reason})
            logger.error(reason)

    def _extract_output_refs(self, result: InvocationResult) -> list[str]:
        refs: list[str] = []
        for call in result.tool_calls:
            name = call.get("name", "")
            args = call.get("input", {}) or {}
            if name in {"Write", "Edit"} and "file_path" in args:
                refs.append(str(args["file_path"]))
        return refs

    # -- pricing staleness check -------------------------------------------

    def _check_pricing_staleness(self) -> None:
        """One-shot at startup: warn if the pricing table is older than threshold."""
        try:
            stale, age_days = pricing.is_stale()
        except Exception:
            logger.exception("pricing staleness check failed; skipping")
            return
        if not stale:
            return
        msg = (
            f"pricing table is {age_days} days old (>{pricing.STALENESS_DAYS}). "
            f"Run: producer pricing update"
        )
        logger.warning(msg)
        marker = self.config.reports_dir / "needs-attention.md"
        marker.parent.mkdir(parents=True, exist_ok=True)
        with marker.open("a", encoding="utf-8") as f:
            f.write(f"- {msg}\n")
        self.audit.event("pricing_stale", {"age_days": age_days})

    def _log_startup_banner(self) -> None:
        """One-line banner showing auth + isolation mode."""
        auth_mode = getattr(self.invoker, "auth_mode", "unknown")
        isolation = getattr(self.invoker, "config_isolation", "unknown")
        suffix = ""
        if isolation == "inherit":
            suffix = " (host ~/.claude inherited; bypassPermissions)"
        logger.info("auth=%s, isolation=%s%s", auth_mode, isolation, suffix)

    # -- idle detection -----------------------------------------------------

    def _track_idle(self, n_dispatched: int) -> None:
        """Notify human if the Producer's been idle for ``idle_threshold_polls``
        consecutive ticks. Reset and reverse-notify when work resumes."""
        if n_dispatched == 0:
            self._idle_polls += 1
            threshold = self.config.idle_threshold_polls
            if self._idle_polls >= threshold and not self._idle_notified:
                idle_seconds = int(threshold * self.config.poll_interval_seconds)
                self._notify(
                    subject="Team idle",
                    body=(
                        f"Producer has had {threshold} consecutive empty polls "
                        f"(~{idle_seconds}s). Queue is empty. Likely either tasks "
                        f"completed silently without self-seeding followups, or "
                        f"specialist agents need new work filed. Check the ledger "
                        f"for status counts and the latest morning-report-*.md."
                    ),
                    priority="default",
                    tags="hourglass",
                )
                self._idle_notified = True
        else:
            if self._idle_notified:
                self._notify(
                    subject="Team back online",
                    body=f"Producer dispatched {n_dispatched} task(s) — work flowing again.",
                    priority="min",
                    tags="white_check_mark",
                )
            self._idle_polls = 0
            self._idle_notified = False

    def _notify(
        self,
        *,
        subject: str,
        body: str,
        priority: str = "default",
        tags: str = "robot",
    ) -> None:
        marker_path = self.config.reports_dir / "needs-attention.md"
        notify_human(
            marker_path=marker_path,
            ntfy_topic=self.config.notifications.ntfy_topic,
            subject_prefix=self.config.notifications.subject_prefix,
            subject=subject,
            body=body,
            priority=priority,
            tags=tags,
        )
        self.audit.event(
            "notify_human",
            {
                "subject": subject,
                "via": "ntfy+file" if self.config.notifications.ntfy_topic else "file",
            },
        )

    # -- morning report -----------------------------------------------------

    async def _maybe_emit_morning_report(self) -> None:
        now = asyncio.get_event_loop().time()
        if now - self._last_report_at < MORNING_REPORT_INTERVAL_SECONDS:
            return
        try:
            self.write_morning_report()
            self._last_report_at = now
        except Exception:
            logger.exception("Morning-report generation failed")

    def write_morning_report(self, *, target_date: str | None = None) -> Path:
        """Compose and write today's morning report.

        Returns the absolute path to the written file. Idempotent — overwrites
        an existing report for the same day.
        """
        target_date = target_date or utc_today()
        path = self.config.reports_dir / f"morning-report-{target_date.replace('-', '')}.md"
        path.parent.mkdir(parents=True, exist_ok=True)
        soft_total = sum(role.daily_cap_usd for role in self.config.roles.values())
        body = render_morning_report(
            ledger=self.ledger,
            project_name=self.config.project_name,
            target_date=target_date,
            soft_total_usd=soft_total,
            hard_total_usd=self.config.budget.project_ceiling_usd,
            kill_switch_armed=self.kill_switch.is_armed(),
            max_retries_per_task=MAX_RETRIES_PER_TASK,
        )
        path.write_text(body, encoding="utf-8")
        self.audit.event("morning_report", {"path": str(path), "date": target_date})
        logger.info("Wrote morning report -> %s", path)
        return path

    # -- shutdown -----------------------------------------------------------

    async def _flush_pending_writes(self) -> None:
        try:
            self.ledger.close()
        except Exception:
            logger.exception("Ledger close failed during shutdown")
