"""Per-agent and total daily $ cap enforcement.

The contract:

* :meth:`BudgetTracker.can_spend` is a non-mutating read; agents call it
  before issuing a paid API call to decide whether to proceed.
* :meth:`BudgetTracker.record_spend` is the post-call accounting; it raises
  :class:`BudgetExceeded` *after* updating the ledger if the new total
  crossed a hard cap.

The pattern: pre-flight ``can_spend(agent, reservation)`` reserves worst-case
cost before authorizing the dispatch. Then ``record_spend(agent, actual)``
records the measured cost.
"""

from __future__ import annotations

from typing import Any

from producer.ledger import LedgerClient


class BudgetExceeded(RuntimeError):
    """A spend would breach the per-agent or total daily cap."""


class BudgetTracker:
    """Per-agent and total daily $ cap enforcement.

    Args:
        ledger: The ledger client.
        role_caps: ``{role_name: {"daily_cap_usd": float, ...}}``. Only the
            ``daily_cap_usd`` key is required; other fields are ignored here
            so the same dict shape can be shared with role-config consumers.
        project_ceiling_usd: Hard cap on total project spend per UTC day,
            summed across all agents.
        soft_cap_ratio: Per-agent soft warning threshold, as a fraction of
            ``daily_cap_usd``. Default 0.8.
    """

    def __init__(
        self,
        ledger: LedgerClient,
        *,
        role_caps: dict[str, dict[str, Any]],
        project_ceiling_usd: float,
        soft_cap_ratio: float = 0.8,
    ) -> None:
        self.ledger = ledger
        self.role_caps = role_caps
        self.project_ceiling_usd = project_ceiling_usd
        self.soft_cap_ratio = soft_cap_ratio

    def _hard_cap(self, agent_owner: str) -> float:
        cfg = self.role_caps.get(agent_owner)
        if cfg is None:
            return 0.0
        return float(cfg.get("daily_cap_usd", 0.0))

    def can_spend(self, agent_owner: str, usd: float) -> bool:
        """Pre-dispatch reservation check. Non-mutating except for inserting
        today's budget row if missing (which the ledger does idempotently).
        """
        if usd < 0:
            raise ValueError("usd must be non-negative")
        hard = self._hard_cap(agent_owner)
        spent, _soft, _hard = self.ledger.budget_state(
            agent_owner,
            hard_cap_usd=hard,
            soft_cap_ratio=self.soft_cap_ratio,
        )
        if spent + usd > hard:
            return False
        if self.ledger.total_spend_today() + usd > self.project_ceiling_usd:
            return False
        return True

    def soft_warn(self, agent_owner: str) -> bool:
        hard = self._hard_cap(agent_owner)
        spent, soft, hard = self.ledger.budget_state(
            agent_owner,
            hard_cap_usd=hard,
            soft_cap_ratio=self.soft_cap_ratio,
        )
        return spent >= soft and spent < hard

    def record_spend(
        self,
        agent_owner: str,
        usd: float,
        *,
        task_id: str | None = None,
        api: str = "unknown",
    ) -> tuple[float, float, float]:
        """Record actual spend and audit it; raise if hard cap breached."""
        hard = self._hard_cap(agent_owner)
        spent, soft, hard = self.ledger.update_budget(
            agent_owner,
            usd,
            hard_cap_usd=hard,
            soft_cap_ratio=self.soft_cap_ratio,
        )
        self.ledger.append_audit(
            agent_owner=agent_owner,
            action="cost",
            detail={"api": api, "delta_usd": usd, "spent_usd": spent},
            cost_usd=usd,
            task_id=task_id,
        )
        if spent > hard:
            raise BudgetExceeded(
                f"{agent_owner} hard cap ${hard:.2f} breached: spent ${spent:.2f}"
            )
        return (spent, soft, hard)
