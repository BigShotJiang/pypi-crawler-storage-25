"""Daily summary report rendered by the Producer."""

from __future__ import annotations

from collections import Counter

from producer.ledger import LedgerClient, utc_iso_now
from producer import pricing


def render_morning_report(
    *,
    ledger: LedgerClient,
    project_name: str,
    target_date: str,
    soft_total_usd: float,
    hard_total_usd: float,
    kill_switch_armed: bool,
    max_retries_per_task: int = 3,
) -> str:
    """Compose the morning report markdown for ``target_date``.

    Args:
        ledger: Connected ledger to query.
        project_name: Header text — ``"<project_name> — Morning Report ..."``.
        target_date: ``YYYY-MM-DD`` UTC date the report covers.
        soft_total_usd: Sum of per-agent daily caps; used as the alarm
            threshold in the spend section + anomalies.
        hard_total_usd: Project ceiling; the kill threshold for total spend.
        kill_switch_armed: Surfaced in the Anomalies section.
        max_retries_per_task: Used for the failed-task threshold query.
    """
    with ledger._lock:  # noqa: SLF001 — internal read is intentional
        shipped = ledger.conn.execute(
            "SELECT id, title, agent_owner, finished_at, cost_usd FROM tasks "
            "WHERE status='done' AND finished_at LIKE ? "
            "ORDER BY finished_at DESC LIMIT 50",
            (f"{target_date}%",),
        ).fetchall()
        escalated = ledger.conn.execute(
            "SELECT id, title, agent_owner, escalation_reason FROM tasks "
            "WHERE status='escalated' "
            "ORDER BY finished_at DESC LIMIT 25"
        ).fetchall()
        failed = ledger.conn.execute(
            "SELECT id, title, agent_owner, retry_count, escalation_reason FROM tasks "
            "WHERE status='failed' AND retry_count >= ? "
            "ORDER BY finished_at DESC LIMIT 10",
            (max_retries_per_task,),
        ).fetchall()
        budgets = ledger.conn.execute(
            "SELECT agent_owner, spent_usd, hard_cap_usd, soft_cap_usd "
            "FROM budget WHERE date=? ORDER BY spent_usd DESC",
            (target_date,),
        ).fetchall()
        assets_today = ledger.conn.execute(
            "SELECT asset_type, COUNT(*) AS n, COALESCE(SUM(cost_usd),0) AS spend "
            "FROM asset_registry WHERE timestamp LIKE ? GROUP BY asset_type",
            (f"{target_date}%",),
        ).fetchall()
        drift_rows = ledger.conn.execute(
            "SELECT agent_owner, "
            "       SUM(cost_usd)        AS sum_computed, "
            "       SUM(actual_cost_usd) AS sum_actual "
            "FROM tasks "
            "WHERE finished_at LIKE ? "
            "  AND status='done' "
            "  AND actual_cost_usd IS NOT NULL "
            "GROUP BY agent_owner "
            "HAVING sum_computed IS NOT NULL AND sum_actual IS NOT NULL "
            "ORDER BY agent_owner",
            (f"{target_date}%",),
        ).fetchall()
        stuck_in_progress = ledger.conn.execute(
            "SELECT COUNT(*) AS n FROM tasks WHERE status='in_progress'"
        ).fetchone()["n"]
        failed_pending = ledger.conn.execute(
            "SELECT COUNT(*) AS n FROM tasks WHERE status='failed'"
        ).fetchone()["n"]

    total_spent = sum(b["spent_usd"] for b in budgets)
    total_today = ledger.total_spend_today()
    ship_count_by_agent = Counter(r["agent_owner"] for r in shipped)

    lines: list[str] = []
    lines.append(f"# {project_name} — Morning Report {target_date}")
    try:
        stale, age_days = pricing.is_stale()
    except Exception:  # pricing missing/corrupt — don't break the report
        stale, age_days = False, 0
    if stale:
        lines.append("")
        lines.append(
            f"> ⚠️ pricing table is {age_days} days old. "
            f"Run: `producer pricing update`"
        )
    lines.append("")
    lines.append(f"## Shipped overnight ({len(shipped)} tasks)")
    if not shipped:
        lines.append("_No tasks completed in the last 24h._")
    else:
        for row in list(shipped)[:10]:
            lines.append(
                f"- **{row['title']}** — {row['agent_owner']} "
                f"(${row['cost_usd']:.2f}). `{row['id']}`"
            )
        if len(shipped) > 10:
            lines.append(f"- _(+{len(shipped) - 10} more — see ledger)_")
        by_agent = ", ".join(
            f"{k}={v}" for k, v in ship_count_by_agent.most_common()
        )
        lines.append("")
        lines.append(f"By agent: {by_agent}")
    lines.append("")
    lines.append("## Awaiting your sign-off")
    if not escalated:
        lines.append("_No escalations._")
    else:
        for row in escalated:
            lines.append(
                f"- **[{row['agent_owner']}] {row['title']}** — "
                f"{row['escalation_reason']} `{row['id']}`"
            )
    lines.append("")
    if failed:
        lines.append("## Hard-failed (retries exhausted, awaiting human triage)")
        for row in failed:
            lines.append(
                f"- **[{row['agent_owner']}] {row['title']}** — "
                f"retry {row['retry_count']}/{max_retries_per_task}: "
                f"{row['escalation_reason']} `{row['id']}`"
            )
        lines.append("")
    lines.append("## Spend")
    lines.append(
        f"- Today: **${total_spent:.2f}** / "
        f"${soft_total_usd:.2f} alarm / ${hard_total_usd:.2f} kill ceiling"
    )
    for row in budgets:
        agent = row["agent_owner"]
        spent = row["spent_usd"]
        hard = row["hard_cap_usd"]
        pct = (spent / hard * 100.0) if hard > 0 else 0.0
        marker = ""
        if spent >= hard:
            marker = " **[CAP HIT]**"
        elif spent >= row["soft_cap_usd"]:
            marker = " _(soft cap)_"
        lines.append(f"  - {agent}: ${spent:.2f} / ${hard:.2f} ({pct:.0f}%){marker}")
    lines.append("")
    lines.append("## Assets registered today")
    if not assets_today:
        lines.append("_None._")
    else:
        for row in assets_today:
            lines.append(
                f"- {row['asset_type']}: {row['n']} pieces / ${row['spend']:.2f}"
            )
    lines.append("")
    if drift_rows:
        lines.append("## Pricing drift (computed vs actual, API-mode tasks)")
        for row in drift_rows:
            agent = row["agent_owner"]
            computed = row["sum_computed"] or 0.0
            actual = row["sum_actual"] or 0.0
            delta_pct = (
                ((computed - actual) / actual * 100.0) if actual > 0 else 0.0
            )
            lines.append(
                f"- {agent}: computed=${computed:.4f}, actual=${actual:.4f} "
                f"(Δ {delta_pct:+.1f}%)"
            )
        lines.append("")
    lines.append("## Anomalies")
    anomalies: list[str] = []
    if kill_switch_armed:
        anomalies.append("**Kill switch is currently ARMED.** Investigate before resume.")
    if stuck_in_progress > 0:
        anomalies.append(f"{stuck_in_progress} task(s) still in_progress at report time.")
    if failed_pending > 0:
        anomalies.append(f"{failed_pending} task(s) currently in failed state pending retry.")
    if soft_total_usd > 0 and total_today >= soft_total_usd * 0.8:
        anomalies.append(
            f"Total project spend at ${total_today:.2f} — "
            f"{total_today / soft_total_usd:.0%} of soft alarm."
        )
    if not anomalies:
        lines.append("_None detected this cycle._")
    else:
        for line in anomalies:
            lines.append(f"- {line}")
    lines.append("")
    lines.append("---")
    lines.append(f"_Generated by Producer at {utc_iso_now()}._")
    return "\n".join(lines) + "\n"
