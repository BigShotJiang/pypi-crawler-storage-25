"""ai-producer — agentic orchestration via SQLite-WAL ledger + Claude Agent SDK."""

from producer.budget import BudgetExceeded, BudgetTracker
from producer.config import (
    AuthConfig,
    BudgetConfig,
    NotificationsConfig,
    ProducerConfig,
    RoleConfig,
    load_config,
)
from producer.dispatch import Producer
from producer.invoker import ClaudeAgentInvoker, InvocationResult
from producer.kill_switch import KillSwitchWatcher
from producer.ledger import (
    AUDIT_GENESIS_PREV_HASH,
    AuditLogger,
    LedgerClient,
    LedgerError,
    Task,
    TaskClaimRace,
    new_id,
    utc_iso_now,
    utc_today,
)

__all__ = [
    "AUDIT_GENESIS_PREV_HASH",
    "AuditLogger",
    "AuthConfig",
    "BudgetConfig",
    "BudgetExceeded",
    "BudgetTracker",
    "ClaudeAgentInvoker",
    "InvocationResult",
    "KillSwitchWatcher",
    "LedgerClient",
    "LedgerError",
    "NotificationsConfig",
    "Producer",
    "ProducerConfig",
    "RoleConfig",
    "Task",
    "TaskClaimRace",
    "load_config",
    "new_id",
    "utc_iso_now",
    "utc_today",
]
