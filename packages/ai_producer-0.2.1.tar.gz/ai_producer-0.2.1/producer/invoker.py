"""Wrapper over ``claude_agent_sdk.query`` for one-shot agent dispatch.

Load-bearing details preserved from the source extraction:

1. **CLAUDE_CONFIG_DIR isolation.** The bundled ``claude`` CLI inherits the
   user's ``~/.claude`` config by default — plugins, MCP servers, hooks,
   skills. None of those belong in autonomous agent sessions (they slow
   dispatch and cause spurious hangs when a hook errors mid-task). We point
   the subprocess at a project-local config dir.
2. **No-productive-output detection.** The SDK raises
   ``"Command failed with exit code 1"`` whenever the bundled subprocess
   exits non-zero — including the benign case where a ``ResultMessage`` with
   ``is_error=True`` (e.g. ``error_max_turns``) was already streamed. We
   capture the exception, but if neither text nor tool-calls were produced,
   we re-raise so the dispatcher's retry logic fires (instead of silently
   absorbing a no-op result).
3. **``permission_mode='acceptEdits'``** auto-approves Edit/Write/Bash
   without interactive prompts, required for headless subprocess operation.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal

from producer import pricing

logger = logging.getLogger("producer.invoker")


_VALID_ISOLATION_MODES = ("auto", "isolated", "inherit")


def _resolve_isolation_mode(
    *,
    config_value: str,
    env_override: str | None,
    has_api_key: bool,
    credentials_path: Path,
) -> Literal["isolated", "inherit"]:
    """Resolve the effective config_isolation. Pure function.

    Priority: env_override > config_value > auto-detect.
    Logs WARN when auto-detect picks 'inherit' (isolation silently dropped).
    """
    effective = env_override if env_override is not None else config_value
    if effective not in _VALID_ISOLATION_MODES:
        source = "PRODUCER_AUTH_MODE" if env_override is not None else "auth.mode"
        raise ValueError(
            f"{source} must be one of {list(_VALID_ISOLATION_MODES)}; got {effective!r}"
        )

    if effective in ("isolated", "inherit"):
        return effective  # type: ignore[return-value]

    # auto
    if has_api_key or credentials_path.exists():
        return "isolated"
    logger.warning(
        "isolation disabled (auto): no ANTHROPIC_API_KEY and no %s — "
        "falling back to inherit mode (host ~/.claude will be used). "
        "Set auth.mode in producer.yaml to silence this warning.",
        credentials_path,
    )
    return "inherit"


@dataclass
class InvocationResult:
    """Flat shape for what an agent call returned.

    ``cost_usd`` is an alias for ``computed_cost_usd`` retained so existing
    callers (dispatcher, tests) keep working unchanged. New code should read
    ``computed_cost_usd`` (always populated) and ``actual_cost_usd`` (None
    under subscription auth) explicitly.
    """

    text: str
    cost_usd: float                       # alias of computed_cost_usd
    computed_cost_usd: float = 0.0
    actual_cost_usd: float | None = None
    usage: dict[str, int] = field(default_factory=dict)
    auth_mode: Literal["api", "subscription"] = "api"
    config_isolation: Literal["isolated", "inherit"] = "isolated"
    tool_calls: list[dict[str, Any]] = field(default_factory=list)
    raw_messages: list[Any] = field(default_factory=list)
    sdk_error: str | None = None

    def __post_init__(self) -> None:
        # `cost_usd` is the documented alias of `computed_cost_usd`. If a
        # caller passed only one, mirror it into the other so downstream
        # code can read either field consistently.
        if self.computed_cost_usd == 0.0 and self.cost_usd != 0.0:
            self.computed_cost_usd = self.cost_usd
        elif self.cost_usd == 0.0 and self.computed_cost_usd != 0.0:
            self.cost_usd = self.computed_cost_usd


class ClaudeAgentInvoker:
    """One-shot Claude Agent SDK invoker.

    Args:
        cwd: Working directory for the dispatched agent. Required.
        api_key: Anthropic API key. Falls back to ``ANTHROPIC_API_KEY`` env.
            Raises if neither is set (only in isolated mode).
        config_dir: Per-project ``CLAUDE_CONFIG_DIR``. Defaults to
            ``<cwd>/agent-state/.claude``. The directory is created if
            missing and exported into ``os.environ`` so the subprocess
            inherits it. ``None`` in inherit mode.
        permission_mode: SDK permission mode. Defaults to ``acceptEdits``
            in isolated mode or ``bypassPermissions`` in inherit mode.
            Explicit value wins over the auto-pick.
        auth_config: AuthConfig instance (or any object with a ``mode``
            attr) used to derive config_isolation before env-var override.
    """

    config_dir: Path | None  # None in inherit mode

    def __init__(
        self,
        *,
        cwd: Path | str,
        api_key: str | None = None,
        config_dir: Path | str | None = None,
        permission_mode: str | None = None,  # None = auto-pick from mode
        auth_config: Any = None,             # AuthConfig | None — late import
    ) -> None:
        self.cwd = Path(cwd).resolve()

        # Resolve config_isolation BEFORE touching any env vars or filesystem.
        config_value = "auto"
        if auth_config is not None:
            config_value = getattr(auth_config, "mode", "auto")
        env_override = os.environ.get("PRODUCER_AUTH_MODE")
        creds_path = Path.home() / ".claude" / ".credentials.json"
        has_api_key = bool(api_key or os.environ.get("ANTHROPIC_API_KEY"))
        self.config_isolation = _resolve_isolation_mode(
            config_value=config_value,
            env_override=env_override,
            has_api_key=has_api_key,
            credentials_path=creds_path,
        )

        # auth_mode is independent: API_KEY presence determines it.
        resolved_key = api_key or os.environ.get("ANTHROPIC_API_KEY")
        if resolved_key:
            self.auth_mode = "api"
            self.api_key = resolved_key
            os.environ.setdefault("ANTHROPIC_API_KEY", resolved_key)
        else:
            self.auth_mode = "subscription"
            self.api_key = None

        # Config dir handling depends on isolation mode.
        if self.config_isolation == "isolated":
            self.config_dir = (
                Path(config_dir).resolve()
                if config_dir is not None
                else (self.cwd / "agent-state" / ".claude").resolve()
            )
            self.config_dir.mkdir(parents=True, exist_ok=True)
            os.environ["CLAUDE_CONFIG_DIR"] = str(self.config_dir)
            if self.auth_mode == "subscription":
                self._setup_subscription_auth()
        else:  # inherit
            self.config_dir = None
            # Remove any stale CLAUDE_CONFIG_DIR so the subprocess inherits
            # the host ~/.claude.
            os.environ.pop("CLAUDE_CONFIG_DIR", None)
            os.environ.setdefault("GIT_TERMINAL_PROMPT", "0")

        # permission_mode: explicit value wins; otherwise pick from mode.
        if permission_mode is not None:
            self.permission_mode = permission_mode
        elif self.config_isolation == "inherit":
            self.permission_mode = "bypassPermissions"
        else:
            self.permission_mode = "acceptEdits"

    def _setup_subscription_auth(self) -> None:
        """Symlink ~/.claude/.credentials.json into the isolated config dir.

        Selective by design: we do NOT bring along plugins, hooks, or skills.
        Those caused the spurious dispatch hangs that motivated isolation in
        the first place.
        """
        src = Path.home() / ".claude" / ".credentials.json"
        if not src.exists():
            raise RuntimeError(
                f"no API key set and no local Claude Code credentials at {src}:\n"
                "  • set ANTHROPIC_API_KEY (any environment), or\n"
                "  • run `claude login` to create the credentials file (legacy auth), or\n"
                "  • set auth.mode: inherit in producer.yaml — or PRODUCER_AUTH_MODE=inherit\n"
                "    — to use Claude Code's host config (OAuth/Keychain auth)"
            )
        dst = self.config_dir / ".credentials.json"
        if dst.is_symlink() and dst.resolve() == src.resolve():
            return  # idempotent — already correct
        if dst.exists() or dst.is_symlink():
            dst.unlink()
        dst.symlink_to(src)

    async def invoke(
        self,
        agent_role: str,
        prompt: str,
        *,
        system_prompt: str | None = None,
        max_turns: int = 16,
        allowed_tools: list[str] | None = None,
        model: str | None = None,
    ) -> InvocationResult:
        """Run a Claude Agent SDK query and return a flat result.

        ``agent_role`` is recorded by callers in audit logs but not validated
        here — role allowlists live in the dispatcher's config.
        """
        # Imported lazily so the module stays importable without the SDK
        # installed (helpful for tests that mock the SDK at import time).
        from claude_agent_sdk import (  # type: ignore[import-not-found]
            AssistantMessage,
            ClaudeAgentOptions,
            TextBlock,
            query,
        )

        options_kwargs: dict[str, Any] = dict(
            system_prompt=system_prompt,
            max_turns=max_turns,
            allowed_tools=allowed_tools or [],
            cwd=str(self.cwd),
        )
        if model is not None:
            options_kwargs["model"] = model
        # permission_mode is a newer ClaudeAgentOptions field; older SDK
        # releases may not accept it.
        try:
            options = ClaudeAgentOptions(
                permission_mode=self.permission_mode, **options_kwargs
            )
        except TypeError:
            options = ClaudeAgentOptions(**options_kwargs)

        text_chunks: list[str] = []
        tool_calls: list[dict[str, Any]] = []
        raw: list[Any] = []
        actual_cost_usd: float | None = None
        usage: dict[str, int] = {}
        sdk_error: Exception | None = None
        try:
            async for message in query(prompt=prompt, options=options):
                raw.append(message)
                if isinstance(message, AssistantMessage):
                    for block in getattr(message, "content", []):
                        if isinstance(block, TextBlock):
                            text_chunks.append(block.text)
                        elif getattr(block, "type", None) == "tool_use":
                            tool_calls.append(
                                {
                                    "name": getattr(block, "name", ""),
                                    "input": getattr(block, "input", {}),
                                }
                            )
                # The SDK surfaces total_cost_usd on result-bearing messages;
                # field name has churned over releases so look in a few places.
                for attr in ("total_cost_usd", "usage_cost_usd", "cost_usd"):
                    value = getattr(message, attr, None)
                    if value is not None:
                        actual_cost_usd = float(value)
                        break

                # Token counts. Try the canonical .usage dict first; fall back
                # to top-level attributes (shape varies by SDK release).
                msg_usage = getattr(message, "usage", None)
                if isinstance(msg_usage, dict):
                    for k in (
                        "input_tokens", "output_tokens",
                        "cache_creation_input_tokens", "cache_read_input_tokens",
                    ):
                        if k in msg_usage and msg_usage[k] is not None:
                            usage[k] = int(msg_usage[k])
                else:
                    for k in (
                        "input_tokens", "output_tokens",
                        "cache_creation_input_tokens", "cache_read_input_tokens",
                    ):
                        v = getattr(message, k, None)
                        if v is not None:
                            usage[k] = int(v)
        except Exception as exc:
            # Capture and inspect — the dispatcher decides retry/escalation.
            sdk_error = exc

        # Compute cost from tokens. ``model`` may be None (caller didn't pass one);
        # in that case we fall through to a 0-cost computed result and log.
        computed_cost_usd = (
            pricing.compute_cost(model, usage) if model and usage else 0.0
        )
        if not usage:
            logger.warning(
                "no usage data in SDK response; computed_cost_usd=0 "
                "(role=%s, model=%s)",
                agent_role, model,
            )

        result = InvocationResult(
            text="\n".join(text_chunks),
            cost_usd=computed_cost_usd,            # alias
            computed_cost_usd=computed_cost_usd,
            actual_cost_usd=actual_cost_usd,
            usage=usage,
            auth_mode=self.auth_mode,
            config_isolation=self.config_isolation,
            tool_calls=tool_calls,
            raw_messages=raw,
        )
        if sdk_error is not None:
            result.sdk_error = str(sdk_error)
            # "Productive" means actual agent work — text or tool calls.
            # System messages (init, hook_started, rate-limit) populate
            # raw_messages but don't count. When the SDK exits ~1s with
            # exit-1 (transient API hiccup) we'd get init/hook system
            # messages but no work; the old `not raw` check absorbed that
            # silently. Now we raise, and the dispatcher's retry-3-times-
            # then-escalate loop kicks in.
            productive = bool(text_chunks) or bool(tool_calls)
            if not productive:
                raise sdk_error
        return result
