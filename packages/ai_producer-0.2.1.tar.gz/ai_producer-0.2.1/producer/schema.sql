-- ============================================================================
-- ai-producer — SQLite Ledger Schema (v1)
-- ============================================================================
-- Idempotent: safe to run multiple times via `CREATE ... IF NOT EXISTS`.
--
-- The ledger is the message bus, state store, and audit trail for an
-- arbitrary number of cooperating agents. WAL mode plus BEGIN IMMEDIATE for
-- any task-claiming write makes concurrent claims race-safe.
--
-- Style notes:
--  * Timestamps are TEXT, ISO-8601 UTC (e.g. "2026-05-04T13:45:00Z").
--  * ULID-shaped TEXT primary keys (the runtime issues them — SQLite stores
--    strings, doesn't validate ULID-ness).
--  * `audit_log` is append-only and chained via row hashes — *never* UPDATE
--    or DELETE rows in this table.
-- ============================================================================

PRAGMA journal_mode      = WAL;
PRAGMA synchronous       = NORMAL;   -- WAL+NORMAL is the recommended throughput knob.
PRAGMA foreign_keys      = ON;
PRAGMA busy_timeout      = 5000;     -- 5s; agents poll on 10s cadence so contention is bounded.
PRAGMA temp_store        = MEMORY;
PRAGMA mmap_size         = 268435456; -- 256 MiB; ledger never approaches this.

-- ----------------------------------------------------------------------------
-- tasks — the queue and the bus
-- ----------------------------------------------------------------------------
-- Lifecycle:
--   pending ─► in_progress ─► done
--                 ├─► failed (retried up to N)
--                 ├─► escalated (awaiting human; producer or specialist gives up)
--                 └─► killed (kill switch armed mid-flight, or producer cancels)
--
-- Cost columns:
--   cost_usd          — computed from tokens × pricing.json (always populated).
--   actual_cost_usd   — SDK-reported cost (NULL under subscription auth).
--                       Added by _apply_migrations(), not by this CREATE TABLE.
--
-- Config isolation:
--   config_isolation  — 'isolated' (default; CLAUDE_CONFIG_DIR pinned to
--                       <cwd>/agent-state/.claude) or 'inherit' (host ~/.claude
--                       used; required for OAuth/Keychain auth). NULL for rows
--                       written before the migration. Added by _apply_migrations().
--
-- Producer claims via:
--   BEGIN IMMEDIATE;
--   UPDATE tasks SET status='in_progress', started_at=?, ...
--    WHERE id=? AND status='pending';
--   COMMIT;
-- The WHERE-on-old-status is the optimistic lock; if two pollers race,
-- exactly one row's UPDATE matches.
CREATE TABLE IF NOT EXISTS tasks (
    id                  TEXT    PRIMARY KEY,
    agent_owner         TEXT    NOT NULL,
    status              TEXT    NOT NULL CHECK (status IN (
                            'pending', 'in_progress', 'done', 'failed', 'escalated', 'killed'
                        )),
    title               TEXT    NOT NULL,
    description         TEXT    NOT NULL,
    parent_task_id      TEXT    REFERENCES tasks(id) ON DELETE SET NULL,
    dependencies        TEXT    DEFAULT '[]',    -- JSON array of task ids this row waits on
    payload             TEXT    DEFAULT '{}',    -- JSON: free-form per-task
    output_refs         TEXT    DEFAULT '[]',    -- JSON array of paths/asset ids touched
    priority            INTEGER NOT NULL DEFAULT 3,  -- 0 (urgent) .. 5 (someday)
    sprint_id           TEXT,
    created_at          TEXT    NOT NULL,
    started_at          TEXT,
    finished_at         TEXT,
    retry_count         INTEGER NOT NULL DEFAULT 0,
    escalation_reason   TEXT,
    cost_usd            REAL    NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_tasks_status                ON tasks(status);
CREATE INDEX IF NOT EXISTS idx_tasks_agent_owner           ON tasks(agent_owner);
CREATE INDEX IF NOT EXISTS idx_tasks_agent_status_priority ON tasks(agent_owner, status, priority, created_at);
CREATE INDEX IF NOT EXISTS idx_tasks_sprint                ON tasks(sprint_id);

-- ----------------------------------------------------------------------------
-- decisions — the "why" log (decision provenance)
-- ----------------------------------------------------------------------------
-- High-value reasoning: what the agent chose, what it considered, why.
-- Cheaper to read than reconstructing from audit_log. Writes are infrequent.
CREATE TABLE IF NOT EXISTS decisions (
    id              TEXT    PRIMARY KEY,
    task_id         TEXT    REFERENCES tasks(id) ON DELETE SET NULL,
    agent_owner     TEXT    NOT NULL,
    kind            TEXT    NOT NULL,
    decision_text   TEXT    NOT NULL,
    rationale       TEXT    NOT NULL,
    artifact        TEXT,
    made_at         TEXT    NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_decisions_task_id ON decisions(task_id);
CREATE INDEX IF NOT EXISTS idx_decisions_agent   ON decisions(agent_owner);

-- ----------------------------------------------------------------------------
-- asset_registry — every shippable artifact, with provenance and disposition
-- ----------------------------------------------------------------------------
-- Every artifact materialized by an agent gets a row here. `critic_verdicts`
-- holds any QC verdict JSON; `disposition` is the terminal state.
CREATE TABLE IF NOT EXISTS asset_registry (
    id                  TEXT    PRIMARY KEY,
    asset_type          TEXT    NOT NULL CHECK (asset_type IN ('art', 'audio', 'content', 'other')),
    path                TEXT    NOT NULL UNIQUE,
    prompt              TEXT,
    seed                TEXT,
    api                 TEXT,
    model               TEXT,
    model_version       TEXT,
    retry_count         INTEGER NOT NULL DEFAULT 0,
    critic_verdicts     TEXT    DEFAULT '[]',
    cost_usd            REAL    NOT NULL DEFAULT 0,
    wall_clock_seconds  REAL    NOT NULL DEFAULT 0,
    agent_id            TEXT    NOT NULL,
    task_id             TEXT    REFERENCES tasks(id) ON DELETE SET NULL,
    sha256              TEXT,
    timestamp           TEXT    NOT NULL,
    disposition         TEXT    NOT NULL DEFAULT 'shipped' CHECK (disposition IN (
                            'shipped', 'escalated', 'killed', 'pending_qa'
                        ))
);
CREATE INDEX IF NOT EXISTS idx_asset_type        ON asset_registry(asset_type);
CREATE INDEX IF NOT EXISTS idx_asset_agent       ON asset_registry(agent_id);
CREATE INDEX IF NOT EXISTS idx_asset_disposition ON asset_registry(disposition);
CREATE INDEX IF NOT EXISTS idx_asset_timestamp   ON asset_registry(timestamp);

-- ----------------------------------------------------------------------------
-- budget — daily $ spend per agent with soft and hard caps
-- ----------------------------------------------------------------------------
-- One row per (agent_owner, date). Caps are denormalized onto the row so a
-- historical query "what was X's cap on date D" is correct even if caps
-- change mid-project. Updated under BEGIN IMMEDIATE by BudgetTracker.
CREATE TABLE IF NOT EXISTS budget (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_owner     TEXT    NOT NULL,
    date            TEXT    NOT NULL,        -- YYYY-MM-DD UTC
    spent_usd       REAL    NOT NULL DEFAULT 0,
    hard_cap_usd    REAL    NOT NULL,
    soft_cap_usd    REAL    NOT NULL,
    UNIQUE (agent_owner, date)
);
CREATE INDEX IF NOT EXISTS idx_budget_date  ON budget(date);
CREATE INDEX IF NOT EXISTS idx_budget_agent ON budget(agent_owner);

-- ----------------------------------------------------------------------------
-- audit_log — append-only, row-hash-chained
-- ----------------------------------------------------------------------------
-- Every tool call, file write, state transition, dollar spent. `prev_hash` is
-- the SHA-256 of the previous row's `row_hash`; `row_hash` is the SHA-256 of
-- (prev_hash || agent_owner || task_id || action || detail || cost || ts).
-- Tampering anywhere in the chain breaks every later hash.
--
-- Write path lives in producer.ledger.LedgerClient.append_audit — hashes are
-- computed there, not via SQL trigger.
CREATE TABLE IF NOT EXISTS audit_log (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_owner     TEXT    NOT NULL,
    task_id         TEXT,
    action          TEXT    NOT NULL,
    detail          TEXT    NOT NULL,
    cost_usd        REAL    NOT NULL DEFAULT 0,
    timestamp       TEXT    NOT NULL,
    prev_hash       TEXT    NOT NULL,
    row_hash        TEXT    NOT NULL UNIQUE
);
CREATE INDEX IF NOT EXISTS idx_audit_agent_ts ON audit_log(agent_owner, timestamp);
CREATE INDEX IF NOT EXISTS idx_audit_task     ON audit_log(task_id);
CREATE INDEX IF NOT EXISTS idx_audit_action   ON audit_log(action);

-- ----------------------------------------------------------------------------
-- prompts — deduped prompt corpus
-- ----------------------------------------------------------------------------
-- Deduping prompts and storing only their hash on each audit row keeps audit
-- table small while preserving full reproducibility.
CREATE TABLE IF NOT EXISTS prompts (
    hash            TEXT    PRIMARY KEY,
    system_prompt   TEXT,
    user_prompt     TEXT,
    tools_json      TEXT,
    first_seen      TEXT    NOT NULL
);
