# ai-producer

Reusable agentic-orchestration library: a long-running Producer polls a SQLite-WAL
ledger and dispatches tasks to specialist agents via the Claude Agent SDK.
See README.md for full architecture, configuration schema, and operating notes.

## Commands

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"      # editable install + pytest/pytest-asyncio
pytest -v                    # full suite (93 tests)
pytest tests/test_ledger.py  # single module
producer init                # scaffold producer.yaml + agents/ + agent-state/
producer run --once          # drain queue and exit (omit --once for long-lived loop)
```

Requires Python 3.11+. The Claude Agent SDK invokes the bundled `claude` CLI subprocess.

## Layout

- `producer/` — library source. CLI entry: `producer.cli:main` (`producer` script).
  - `ledger.py` — SQLite-WAL `LedgerClient`, `AuditLogger`, row-hash audit chain.
  - `dispatch.py` — `Producer` poll loop, retry/escalate, idle detection.
  - `invoker.py` — `ClaudeAgentInvoker` wraps `claude_agent_sdk.query`.
  - `budget.py`, `kill_switch.py`, `config.py`, `escalation.py`, `morning_report.py`.
  - `schema.sql` — force-included in the wheel via `[tool.hatch...force-include]`.
- `templates/` — copied by `producer init` (producer.yaml.example, agent prompt skeleton).
- `tests/` — pytest with `asyncio_mode = "auto"`; `test_smoke_echo_agent.py` is end-to-end with a stub agent.
- `agent-state/` — gitignored runtime state (ledger.db, kill_switch, escalations, reports).

## Non-obvious invariants

- **`LedgerClient.insert_task` is the keystone.** Specialist agents file their own
  downstream tasks. Without that, the queue stalls and the Producer goes idle. Any
  change to dispatch flow must preserve this.
- **`CLAUDE_CONFIG_DIR` isolation (isolated mode only).** In `isolated`
  mode (the default), dispatched subprocesses point at `<cwd>/agent-state/.claude`
  to keep the user's `~/.claude` plugins/hooks/skills out of headless runs.
  In `inherit` mode (opt-in via `auth.mode: inherit` or auto-detected when
  the user is on OAuth/Keychain auth), the override is dropped and the host
  config is inherited; `permission_mode='bypassPermissions'` and
  `GIT_TERMINAL_PROMPT=0` prevent the prompt-driven hangs that motivated
  isolation. See `docs/superpowers/specs/2026-05-06-auth-inherit-mode-design.md`.
- **No-productive-output detection**: SDK raises `"Command failed with exit code 1"`
  even on benign `is_error=True` ResultMessages. The invoker re-raises only when
  neither text nor tool-calls were produced, so dispatch retry fires correctly.
- **`permission_mode='acceptEdits'`** is required for headless dispatch — don't
  change without understanding that interactive prompts will hang the subprocess.
- **Audit chain is single-writer.** Row-hash chaining via `BEGIN IMMEDIATE` is fine
  under ~1k tasks/hr; beyond that it bottlenecks (documented limitation).
- **Optimistic-lock task claim** lets multiple agents poll safely; do not replace
  with naive `SELECT ... LIMIT 1` without preserving the claim semantics.
- **Special role name**: only `producer` is special (used for dispatch reservation).
  Missing it triggers a $0.05 fallback warning.
- **Auto-armed kill switch**: 5 failures by one agent within 10 min trips it.
- **Auth fallback has two modes.** `isolated` mode symlinks ONLY
  `~/.claude/.credentials.json` (the legacy subscription path) into the
  isolated `CLAUDE_CONFIG_DIR`. `inherit` mode skips the symlink and lets
  the subprocess use the host `~/.claude` directly — required for OAuth
  auth (no on-disk credentials file). Auto-detect picks `inherit` when
  neither API key nor `.credentials.json` is present, with a WARN log.
- **Cost has two columns.** `tasks.cost_usd` is the *computed* cost
  (tokens × `producer/pricing.json`) — always populated. `tasks.actual_cost_usd`
  is the SDK-reported cost — `NULL` under subscription auth. Budget
  enforcement uses `cost_usd`. The morning report's "Pricing drift"
  section compares the two.
- **Pricing table can drift.** `producer pricing update` refreshes
  `producer/pricing.json` from docs.anthropic.com. `producer run` warns
  if it's >90 days old. New models without an entry log a warning and
  cost as $0 — they don't break dispatch.

## Public API

Re-exports live in `producer/__init__.py`. Keep `__all__` in sync when adding
public symbols; the README "Public API" section lists the contract.
