# Interactive onboarding for `producer init`

**Date:** 2026-05-06
**Status:** Approved (design)
**Author:** dmccluney + Claude

## Background

`producer init` today is non-interactive: it copies `templates/producer.yaml.example`
verbatim (with `CHANGEME` placeholders), generates per-role prompt skeletons, runs
`schema_init` on the ledger, and drops `seed_tasks.example.json`. The user is then
on their own to:

- Edit `producer.yaml` to set their `project_name`, pick an `ntfy_topic`, adjust
  budgets, etc.
- Decide which specialist roles their project actually needs.
- Write the system prompt for each role from the bare skeleton template.
- File initial tasks so the queue has something to drain.

The middle two steps — picking roles and writing their prompts — are the parts
where users will spend the most time and where producer's design space is widest.
Defaults like `producer + code + qa` only fit conventional software projects;
real users of this library will want roles like `game-mechanics + content-author
+ playtester` for a gamified assessment app, or `copy-editor + marketer +
fact-checker` for a writing-challenge pipeline.

## Goals

1. Make `producer init` walk a new user from "git-cloned the repo" to "I can run
   `producer run` against my actual project" without requiring them to read the
   whole README first.
2. Keep the boring config (project name, ntfy topic, API key check) cheap and
   programmatic — yes/no and free-text prompts, no LLM calls.
3. Use a Claude session itself to handle the *creative* part of onboarding —
   discovering what the user is building and collaboratively writing the
   role list and per-role system prompts.
4. Preserve scriptable / non-interactive behavior for CI and automation.

## Non-goals

- An open-ended general-purpose copilot ("ask me anything about producer"). Once
  the project is configured the user can spin up their own `claude` session.
- A long-lived wizard that tracks state across multiple `producer init`
  invocations. Onboarding is a one-shot handoff; re-running `producer init`
  starts over (gated by `--force`).
- Fully automating role design. The chat is collaborative — the user makes the
  judgment calls, the agent drafts and edits.
- Visual / TUI components beyond plain stdin prompts.

## Design

The flow has two distinct phases:

```
producer init
   │
   ├── Phase 1 — programmatic wizard (Python, plain input())
   │      • Pre-flight checks (claude on PATH, target dir state)
   │      • Collect: project name, ntfy topic, subject prefix
   │      • Optional: warn if ANTHROPIC_API_KEY unset
   │      • Render producer.yaml + scaffold + ledger init
   │      • Render ONBOARDING.md
   │
   └── Phase 2 — TTY handoff to `claude` CLI
          os.execvp("claude", [..., "--append-system-prompt", "...",
                              "--permission-mode", "acceptEdits"])
          → User now talks to Claude Code directly
          → Claude reads ONBOARDING.md, runs the discovery → role design →
            optional task seeding flow
          → User exits with /exit or Ctrl-D when satisfied
          → Shell prompt returns; `producer run` is ready to go
```

### Phase 1: Programmatic wizard

`producer init` becomes mildly interactive. Prompts use plain `input()` (no
extra deps); defaults are pre-filled and accepted with bare Enter.

| Prompt | Default | Goes into |
|--------|---------|-----------|
| Project name | basename of target dir | `project_name` |
| ntfy.sh topic | `<project>-<random8>` | `notifications.ntfy_topic` |
| Subject prefix | project name | `notifications.subject_prefix` |

After collection:

- `ANTHROPIC_API_KEY` env check — if unset, print a one-liner pointing at
  `claude /login` or env-var setup. **Don't block** — the chat itself will
  surface the failure clearly enough, and some valid setups don't use the env
  var.
- Existing scaffolding logic runs: write `producer.yaml`, generate per-role
  prompt skeletons, init ledger, drop `seed_tasks.example.json`.
- Render `ONBOARDING.md` (see Phase 2) into the project root.

`producer.yaml` is written with the existing template defaults — `producer`,
`code`, `qa` roles with sensible budgets. If the user `/exit`s the chat
immediately after handoff, they still have a working setup; the chat is purely
value-add.

**New flags:**

- `--non-interactive` — skip prompts, use defaults for everything (CI behavior;
  matches today's behavior).
- `--no-chat` — finish Phase 1 only, skip the `execvp` handoff. Useful when
  scripting setup or when the user wants to start `claude` themselves.

### Phase 2: TTY handoff

After Phase 1 succeeds, `producer init` prints a one-line "Handing off to Claude
to design your agents..." and calls `os.execvp("claude", [...])`. The Python
process is replaced; the user's terminal is now talking to Claude Code directly.

Argv construction (factored into `onboarding.build_claude_argv()` for testing):

```
claude
  --append-system-prompt "<short pointer — see below>"
  --permission-mode acceptEdits
```

The append-system-prompt content is a short pointer, not the whole brief:

> You are bootstrapping a new claude-producer project. Read `ONBOARDING.md`
> in the current directory before doing anything else, then start the
> conversation with the user.

The substantive instructions live in `ONBOARDING.md` so they are inspectable,
editable, and re-runnable (the user can run `claude` in the project root any
time to re-engage the bootstrap flow).

`--permission-mode acceptEdits` lets the agent write to `producer.yaml` and the
role prompt files without re-prompting on every edit. Tool prompts for shell
commands (e.g. `producer task add`) still happen normally.

### `ONBOARDING.md` contents

This is the bootstrap agent's job description. It is checked into the project
(not gitignored) so the user can see and edit it.

Structure:

1. **What producer is** (3–4 sentences). Long-running poller, SQLite-WAL ledger,
   dispatches to specialist agents via the Claude Agent SDK. Enough context that
   the agent understands the model it is helping configure.

2. **What you are editing** — explicit file map:
   - `producer.yaml` — role list under `budget.agents`, per-role budgets,
     `allowed_tools`, prompt path.
   - `agents/<role>/system_prompt.md` — per-role system prompt (currently a
     skeleton).
   - `seed_tasks.json` — optional initial tasks (write here, *not* the
     `.example.json` file).

   Tells the agent these are the only files in scope so it does not go
   wandering through the codebase.

3. **Conversation goal** — three-phase flexible script:
   - **Discovery.** "Ask the user what they're building and what kind of work
     they would want delegated to specialist agents. Don't assume software —
     could be writing, research, ops, content production. Listen first."
   - **Role design.** "Propose 2–4 specialist roles tailored to their project.
     The default skeleton has `producer + code + qa` — keep, modify, or replace
     as appropriate. Edit `producer.yaml`'s `budget.agents` map and write each
     `agents/<role>/system_prompt.md`. Walk through them one at a time so the
     user stays engaged."
   - **Seeding (optional).** "Offer to draft a few seed tasks they could file.
     If yes, write them to `seed_tasks.json` and tell them how to load them
     (`producer task add` for one-offs, or a small batch script)."

4. **Conventions to follow** — must-knows pulled from `CLAUDE.md`:
   - Every specialist agent must file its own downstream tasks via
     `LedgerClient.insert_task` (the keystone — without it, the queue stalls).
     Role prompts should make this responsibility explicit.
   - The `producer` role is special (used for dispatch reservation); don't
     remove it.
   - `allowed_tools` per role should be minimal — only what that specialist
     needs.
   - Per-role `daily_cap_usd` and `dispatch_reservation_usd` should reflect how
     expensive a single dispatch of that role is.

5. **Done signal** — "When the user is satisfied, summarize what you built
   together (role list + one-line per role) and remind them they can run
   `producer run` for the long-lived loop or `producer run --once` for a
   single drained pass. Then end the conversation; the user will `/exit` when
   ready."

## Error handling

**Pre-flight (before any user prompt):**

- `claude` binary not on `PATH` → exit nonzero, print install instructions
  ("Install Claude Code from https://claude.com/claude-code, then re-run").
  Don't scaffold a half-broken project.
- Target dir already contains `producer.yaml` and `--force` not given → exit 2
  with the existing message. Preserves current behavior.

**Mid-wizard:**

- `Ctrl-C` during prompts → bare `KeyboardInterrupt` propagates, exits cleanly
  with no partial files written (Phase 1 prompts come *before* any file writes).
- Scaffolding fails partway (disk full, permission denied) → leave whatever
  files were written. The user can inspect the partial state and re-run with
  `--force`. Don't attempt clean-up; partial state is informative.
- `execvp("claude", ...)` itself fails (e.g. `claude` was on `PATH` at preflight
  but disappeared) → catch the `OSError`, print the error message plus
  "Scaffolding succeeded. Run `claude` in this directory to start the bootstrap
  chat." Exit 0 — Phase 1's work is durable.

**Inside the chat (out of producer's hands):**

- Agent gets confused or makes a bad edit → user can `/exit`, re-run `claude`
  in the project root, and the agent re-reads `ONBOARDING.md` for a fresh
  start. Or the user edits files by hand.
- Network / API errors during the chat → standard Claude Code error surface;
  not producer's responsibility.

## Testing strategy

The TTY handoff itself is not directly unit-testable (`os.execvp` replaces the
process), so the design factors out the testable parts.

| What | How |
|------|-----|
| Wizard prompt parsing | Monkeypatch `builtins.input`, assert resulting yaml contents |
| `producer.yaml` rendering | Pure-function — render → load with existing `load_config` → assert fields |
| `ONBOARDING.md` rendering | Pure-function — assert it contains expected section headings + project name substituted |
| `build_claude_argv()` | Unit test — assert `--append-system-prompt` and `--permission-mode acceptEdits` present, project root passed correctly |
| Pre-flight checks | Mock `shutil.which("claude")` to simulate missing binary, assert exit code + message |
| `--non-interactive` end-to-end | New test mirroring the existing init test, asserts no prompts issued |
| `--no-chat` end-to-end | New test, asserts scaffolding succeeds and `execvp` is *not* called (mocked) |
| TTY handoff itself | Not tested — single-line `os.execvp` wrapper, exercised manually |

The smoke test (`test_smoke_echo_agent.py`) does not need updating; it uses
`--non-interactive`-style direct construction and won't go through the wizard.

## Implementation surface

| File | Change |
|------|--------|
| `producer/cli.py` | Split `cmd_init` into pre-flight → wizard → scaffolding → handoff. Add `--non-interactive` and `--no-chat` flags. |
| `producer/onboarding.py` | **New.** Pure functions: `prompt_for_settings(defaults)`, `render_onboarding_md(cfg)`, `build_claude_argv(cfg)`, `preflight_check_claude_on_path()`. Keeps `cli.py` thin and the logic testable. |
| `templates/onboarding.md.template` | **New.** The brief from §"`ONBOARDING.md` contents", with `{project_name}`, `{project_root}` placeholders. |
| `templates/producer.yaml.example` | Add `{project_name}`, `{ntfy_topic}`, `{subject_prefix}` placeholders the wizard substitutes. Keeps the file usable as a non-templated example by giving the placeholders sensible literal defaults. |
| `tests/test_init_wizard.py` | **New.** Covers prompt parsing, yaml/onboarding rendering, argv construction, preflight checks, `--no-chat`, `--non-interactive`. |
| `README.md` | Small update to the "Quickstart" section reflecting the new flow. |

No changes to: `dispatch.py`, `invoker.py`, `ledger.py`, `budget.py`,
`escalation.py`, `morning_report.py`, `kill_switch.py`, `config.py`, `schema.sql`.

## Success criteria

- A new user runs `producer init` against a fresh directory, answers three
  prompts, and is dropped into a Claude Code chat that knows the project layout.
- The chat produces a customized `producer.yaml` and one filled-in
  `agents/<role>/system_prompt.md` per role they wanted.
- The user runs `producer run --once` after exiting the chat and the loop
  successfully drains any seeded tasks (or idles cleanly if no tasks were
  seeded).
- Existing tests still pass; new tests cover the wizard and the argv
  construction.
- A second test project (e.g. a writing-challenge pipeline with non-software
  roles) can also be bootstrapped through the same flow without the agent
  defaulting to software-engineering assumptions.

## Open questions

None at design time. Refinements that may surface during implementation:

- Whether `prompt_for_settings()` should accept an optional `--ntfy-topic`
  override flag for users who already have a topic in mind. Cheap to add later
  if asked for.
- Whether to ship a small set of *example* `ONBOARDING.md` variants for common
  project shapes (software / writing / research), or keep one general-purpose
  brief. Start with one; revisit if the agent struggles to adapt.
