# Subscription Auth Fallback + Token-Based Cost Tracking

**Date:** 2026-05-06
**Status:** Design approved; ready for implementation plan.

## Problem

`claude-producer` today requires `ANTHROPIC_API_KEY`. Two consequences:

1. **No subscription path.** Developers running locally with a Claude Code Pro/Max
   subscription cannot use those credits — they must provision a separate API
   key, which conflates personal and project billing.
2. **Cost tracking is auth-coupled.** The budget tracker and morning report use
   the SDK-reported `total_cost_usd`. Under subscription auth that field is
   null/zero, which would gut the per-agent daily caps that are core to this
   project's design.

We want both: support local subscription auth, and continue tracking cost in
both modes — so a deployed environment switching between auth modes preserves
historical cost continuity.

## Goals

- Use local Claude Code credentials when no `ANTHROPIC_API_KEY` is set, while
  preserving the existing `CLAUDE_CONFIG_DIR` isolation that keeps
  user-installed plugins/hooks/skills out of dispatched sessions.
- Always populate a "computed cost" derived from token counts × a published
  pricing table — works identically under API and subscription auth.
- Under API auth, also record the SDK-reported actual cost, so drift between
  the published pricing table and Anthropic's billing is visible.
- Provide a CLI command to refresh the pricing table from
  `docs.anthropic.com/pricing`, with staleness detection at producer startup.

## Non-goals

- Per-project pricing overrides (e.g. enterprise rates). Easy to add later
  on top of the bundled-default approach if a use case appears.
- Pricing for non-Anthropic providers. The SDK is Anthropic-specific.
- Auto-refreshing pricing during `producer run` (network calls in the loop are
  out of scope; warn-and-let-the-user-fix is the chosen behavior).

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│ ClaudeAgentInvoker.__init__                                     │
│  ├─ has ANTHROPIC_API_KEY?  yes → existing isolated-config path │
│  └─                          no → _setup_subscription_auth():   │
│                                   symlink ~/.claude/<creds> →   │
│                                   self.config_dir/<creds>       │
└─────────────────────────────────────────────────────────────────┘
            │
            ▼
┌─────────────────────────────────────────────────────────────────┐
│ ClaudeAgentInvoker.invoke                                       │
│  ├─ collect token usage from SDK messages                       │
│  ├─ compute_cost(model, usage) via producer/pricing.py          │
│  ├─ read SDK total_cost_usd if present (API mode)               │
│  └─ return InvocationResult(                                    │
│       computed_cost_usd=...,  # always populated                │
│       actual_cost_usd=...,    # None under subscription         │
│       usage={input, output, cache_creation, cache_read},        │
│       auth_mode="api" | "subscription", ... )                   │
└─────────────────────────────────────────────────────────────────┘
            │
            ▼
┌─────────────────────────────────────────────────────────────────┐
│ Dispatcher records both → ledger.tasks                          │
│   cost_usd          (existing column, now = computed_cost_usd)  │
│   actual_cost_usd   (new nullable column)                       │
│ Budget tracker enforces against cost_usd (computed) — unchanged │
└─────────────────────────────────────────────────────────────────┘
```

**New components**

- `producer/pricing.py` — loader, `compute_cost(model, usage)`, `is_stale()`,
  `STALENESS_DAYS = 90` constant.
- `producer/pricing.json` — bundled in the wheel via the existing
  `[tool.hatch.build.targets.wheel.force-include]` mechanism (same pattern
  `schema.sql` already uses).
- `producer/pricing_updater.py` — `update_pricing(runner=...)` that drives a
  Claude SDK `WebFetch` query, validates output, atomically writes the file.
- `producer pricing update [--dry-run]` — CLI subcommand wiring.

**Existing components touched**

- `invoker.py` — auth detection, token usage extraction, dual-cost return.
- `dispatch.py` — record `actual_cost_usd` alongside `cost_usd`.
- `ledger.py` — `_apply_migrations()` adds the new column on existing ledgers.
- `morning_report.py` — staleness banner; drift section under API auth.
- `cli.py` — `pricing` subcommand parser branch.
- `schema.sql` — adds `actual_cost_usd REAL` to `tasks` (header comment notes
  `cost_usd` semantics: "computed from tokens × pricing table").

## Component details

### Auth fallback (selective symlink)

In `ClaudeAgentInvoker.__init__`, replace the unconditional `RuntimeError` with
a two-branch detection:

```python
if api_key set:
    self.auth_mode = "api"
    # existing path: env var, isolated config_dir
else:
    src = Path.home() / ".claude" / ".credentials.json"
    if not src.exists():
        raise RuntimeError(
            "no API key set and no local Claude Code credentials at "
            "~/.claude/.credentials.json — set ANTHROPIC_API_KEY or run "
            "`claude login`"
        )
    self.auth_mode = "subscription"
    dst = self.config_dir / ".credentials.json"
    if dst.is_symlink() and dst.resolve() == src.resolve():
        pass  # idempotent: already correct
    else:
        dst.unlink(missing_ok=True)
        dst.symlink_to(src)
    # Do NOT symlink anything else from ~/.claude — no skills, no plugins,
    # no hooks. Isolation is preserved.
```

The subprocess inherits `CLAUDE_CONFIG_DIR=<isolated>`, finds the credentials
symlink, authenticates via subscription, and sees no other config artifacts.

`auth_mode` is stored on the invoker and surfaced into `InvocationResult` for
the audit log.

### Cost computation

```python
# producer/pricing.py
STALENESS_DAYS = 90
PRICING_PATH = Path(__file__).parent / "pricing.json"

def load_pricing() -> dict:
    """Reads pricing.json. Caches at module level. Re-read on file mtime change."""

def is_stale(now: datetime | None = None) -> tuple[bool, int]:
    """Returns (is_stale, age_days). Age computed against last_updated field."""

def compute_cost(model: str, usage: dict[str, int]) -> float:
    """Compute USD cost from per-token counts × per-MTok rates.

    usage keys (canonical, matching Anthropic SDK):
      input_tokens, output_tokens,
      cache_creation_input_tokens, cache_read_input_tokens

    Missing model -> log warning, return 0.0. Does not raise.
    """
    rates = load_pricing()["models"].get(model)
    if rates is None:
        logger.warning("no pricing entry for model=%s; computed_cost=0", model)
        return 0.0
    return (
        usage.get("input_tokens", 0) * rates["input_per_mtok_usd"]
        + usage.get("output_tokens", 0) * rates["output_per_mtok_usd"]
        + usage.get("cache_creation_input_tokens", 0)
            * rates["cache_creation_per_mtok_usd"]
        + usage.get("cache_read_input_tokens", 0)
            * rates["cache_read_per_mtok_usd"]
    ) / 1_000_000
```

**Token extraction in `invoker.py`** uses the same defensive lookup pattern the
existing `total_cost_usd` extraction uses (try a few attribute names, fall
back to a `.usage` dict). When extraction fails entirely, log warning, treat
as zero, do not raise.

### `InvocationResult` shape

```python
@dataclass
class InvocationResult:
    text: str
    cost_usd: float                      # = computed_cost_usd (back-compat alias)
    computed_cost_usd: float             # always populated
    actual_cost_usd: float | None        # None under subscription
    usage: dict[str, int]                # the four token counts
    auth_mode: Literal["api", "subscription"]
    tool_calls: list[dict[str, Any]] = field(default_factory=list)
    raw_messages: list[Any] = field(default_factory=list)
    sdk_error: str | None = None
```

`cost_usd` stays as an alias of `computed_cost_usd` to avoid breaking
existing internal callers (dispatcher, tests). Document the alias semantics
inline.

### Schema migration

Existing ledgers must not break on upgrade. `LedgerClient.__init__` already
applies `schema.sql` on first creation; we add a `_apply_migrations()` helper
called after schema application that runs:

```sql
PRAGMA table_info(tasks);
-- if 'actual_cost_usd' not in returned columns:
ALTER TABLE tasks ADD COLUMN actual_cost_usd REAL;
```

Wrapped in a transaction; idempotent. `cost_usd` keeps its column name (avoids
breaking external Datasette/sqlite3 consumers); its semantic shifts to
"computed from tokens × pricing table" — documented in CLAUDE.md and a header
comment in `schema.sql`.

### Pricing table (`producer/pricing.json`)

```json
{
  "last_updated": "2026-05-06",
  "source_url": "https://docs.anthropic.com/en/docs/about-claude/pricing",
  "currency": "USD",
  "models": {
    "claude-opus-4-7": {
      "input_per_mtok_usd": 15.0,
      "output_per_mtok_usd": 75.0,
      "cache_creation_per_mtok_usd": 18.75,
      "cache_read_per_mtok_usd": 1.50
    },
    "claude-sonnet-4-6": { /* ... */ },
    "claude-haiku-4-5": { /* ... */ }
  }
}
```

Ship pre-populated with current rates for Opus 4.7 / Sonnet 4.6 / Haiku 4.5
verified against the Anthropic pricing page on the day of implementation.
The updater verifies and refreshes on demand.

`last_updated` lives at the top level so the staleness check reads one field.

### Updater (`producer pricing update`)

```python
# producer/pricing_updater.py
async def update_pricing(*, dry_run: bool = False, runner=None) -> dict:
    """Fetch current pricing from docs.anthropic.com and write pricing.json.

    runner: callable matching ClaudeAgentInvoker.invoke signature. Defaults
    to a real invoker; tests override with a stub.

    Returns the diff (per-model rate changes) for the CLI to print.
    """
```

Flow:

1. Load current `pricing.json` for diff context (`source_url` is the fetch
   target).
2. Construct a `ClaudeAgentInvoker` (eats own dogfood — same auth logic,
   isolated config dir, `allowed_tools=["WebFetch"]`).
3. Send a tightly-bounded prompt: "Fetch `<source_url>`. Return only a JSON
   object matching this schema {…}. No prose." The schema is pinned in the
   prompt so the model has no room to invent fields.
4. Parse the response. Validate:
   - Top-level keys present (`last_updated`, `source_url`, `currency`,
     `models`).
   - Each model has all four `*_per_mtok_usd` fields, each is a positive
     float < 10000 (sanity bound — catches obvious LLM hallucinations).
   - At least one model present.
5. **Diff against current**: print the per-model rate changes
   (e.g. `claude-opus-4-7 input: 15.00 → 15.00 (unchanged)`,
   `claude-sonnet-4-6 output: 15.00 → 18.00 (+20%)`).
6. **Atomic write**: write to `pricing.json.tmp`, then `os.replace()` to
   `pricing.json`. `--dry-run` skips the write and exits 0.
7. Reservation cost: dispatch reservation comes out of the `producer` role's
   daily cap (one ~$0.05 call per refresh — negligible).

### Staleness detection

In `Producer.__init__` (or `Producer.run`'s startup phase):

```python
stale, age_days = pricing.is_stale()
if stale:
    msg = (
        f"pricing table is {age_days} days old (>{STALENESS_DAYS}). "
        f"Run: producer pricing update"
    )
    logger.warning(msg)
    needs_attention_path.write_text(...)   # adds to needs-attention.md
```

Checked once at startup. Not re-checked every poll — the table doesn't get
fresher mid-run.

`morning_report.py` reads the same `is_stale()` result and adds:

- A staleness banner at the top of the report when stale.
- A "Pricing drift" section showing per-agent `Σ computed_cost_usd` vs
  `Σ actual_cost_usd` and the % delta. Aggregation filters
  `WHERE actual_cost_usd IS NOT NULL` so subscription-mode tasks (which have
  no actual cost) don't pollute the drift signal. If no rows match (all-
  subscription environment), the section is omitted entirely.

## Error handling

| Failure | Behavior |
|---|---|
| No API key + no `~/.claude/.credentials.json` | `RuntimeError` at invoker construction with clear message pointing at both fixes. |
| Symlink target file goes away mid-run | SDK auth fails; existing dispatch retry/escalate path handles. |
| SDK doesn't surface usage data on a message | Log warning, treat usage as zeros, `computed_cost_usd = 0`, do not raise. Dispatch continues. |
| Model not in `pricing.json` | Log warning, `computed_cost_usd = 0`. Surface in morning report so the user notices. |
| `pricing.json` missing or corrupt | `LedgerError`-style clear failure at startup. The bundled wheel always includes a default; deletion is a user action with a clear cause. |
| Updater receives malformed JSON from the model | Validation raises, no write occurs, exit non-zero with a useful diagnostic. |
| Updater rates fail sanity bound | Validation raises (catches obvious hallucinations like a $1500/Mtok rate). |
| `--dry-run` | Always succeeds without filesystem mutation, prints the diff. |

## Testing

| Test | What it covers |
|---|---|
| `test_pricing.py::test_compute_cost_known_model` | Table-driven: known model + known usage → exact float |
| `test_pricing.py::test_compute_cost_missing_model_returns_zero_and_warns` | Loud warning, no exception, returns 0.0 |
| `test_pricing.py::test_is_stale_under_threshold` / `_over_threshold` | Date arithmetic at boundary |
| `test_pricing.py::test_load_handles_corrupt_json` | Clear error; doesn't crash dispatch loop |
| `test_invoker.py::test_subscription_auth_symlinks_credentials` | Mock `~/.claude/.credentials.json`, assert symlink in config_dir, idempotent on re-run |
| `test_invoker.py::test_subscription_auth_fails_when_no_creds_and_no_key` | Clear `RuntimeError` |
| `test_invoker.py::test_extracts_usage_and_computes_cost` | Mock SDK messages with usage; assert `computed_cost_usd` populated, `actual_cost_usd` populated under API mode, None under subscription |
| `test_ledger.py::test_migration_adds_actual_cost_column_to_existing_ledger` | Open ledger created from older schema, assert column added, existing rows have NULL |
| `test_dispatch.py::test_records_both_cost_fields` | End-to-end dispatch, assert ledger has both populated correctly per auth mode |
| `test_morning_report.py::test_shows_drift_section` | API-mode tasks with computed ≠ actual → drift line per agent |
| `test_morning_report.py::test_shows_staleness_banner_when_pricing_stale` | Mock `is_stale()` returning `(True, 95)`; assert banner present |
| `test_pricing_updater.py::test_validates_schema` | Mocked SDK returning malformed JSON → raises clearly, doesn't write |
| `test_pricing_updater.py::test_dry_run_does_not_write` | --dry-run leaves file untouched |
| `test_pricing_updater.py::test_atomic_write` | Mocked SDK → tmpfile created and renamed; on failure, original untouched |
| `test_cli.py::test_pricing_update_subcommand_wired` | Argparse routing test |

No live network in tests. `update_pricing` accepts a `runner` callable that
defaults to `ClaudeAgentInvoker.invoke` and is overridden in tests — same
dependency-injection seam already used in `test_smoke_echo_agent.py`.

## Documentation updates

- `README.md` — new "Subscription auth" subsection under "Operating"; note
  the dual-cost columns under "Public API" and "Limitations".
- `CLAUDE.md` — under "Non-obvious invariants", add the auth-fallback
  symlink rule and the `cost_usd = computed_cost_usd` alias.
- `pyproject.toml` — extend the existing `[tool.hatch.build.targets.wheel.force-include]`
  to include `producer/pricing.json`.

## Open items deferred

- **Per-project pricing overrides** (enterprise rates). Add a layered
  default-vs-override lookup in `pricing.load_pricing()` if a use case appears.
- **Auto-refresh during run.** Currently warn-and-fix only. If pricing-update
  noise becomes a chore, add a `pricing.auto_update_on_stale: true` config
  knob — but only after we see the user pattern.
- **Bundled Claude Code skill** for the updater (the `B` option in the
  brainstorming Q4). Not in scope; easy to add later if discoverability
  becomes a need.
