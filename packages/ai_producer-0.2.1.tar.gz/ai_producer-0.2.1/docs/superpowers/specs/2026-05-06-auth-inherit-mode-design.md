# Auth Inherit Mode — Design Spec

**Date:** 2026-05-06
**Status:** Approved, ready for implementation
**Goal:** Add an opt-in `inherit` mode to `ClaudeAgentInvoker` so users authed to Claude Code via OAuth (macOS Keychain) can run claude-producer without setting `ANTHROPIC_API_KEY`.

---

## Problem

`PR #1` (subscription-auth fallback) only handles the legacy `~/.claude/.credentials.json` file. Modern Claude Code installs auth users via OAuth; tokens live in the macOS Keychain, not on disk. For these users, `ClaudeAgentInvoker.__init__` raises:

```
RuntimeError: no API key set and no local Claude Code credentials at
~/.claude/.credentials.json — set ANTHROPIC_API_KEY or run `claude login`
```

The original `CLAUDE_CONFIG_DIR` isolation (hide `~/.claude/plugins/hooks/skills`) is the reason we can't simply read the host config — but the same isolation prevents the OAuth flow from working at all.

## Solution

Add a second dimension orthogonal to `auth_mode`:

| Term | Values | Meaning |
|---|---|---|
| `auth_mode` (existing) | `api` / `subscription` | API_KEY env var present or not |
| `config_isolation` (new) | `isolated` / `inherit` | Override `CLAUDE_CONFIG_DIR`, or let CLI use host |

Resolution priority (highest wins):

```
PRODUCER_AUTH_MODE env var         # per-run override
  → producer.yaml `auth.mode`      # project default
    → auto-detect:
        ANTHROPIC_API_KEY set?       → isolated  (api auth)
        ~/.claude/.credentials.json? → isolated  (legacy subscription)
        else                          → inherit  + WARN log
```

Allowed `auth.mode` values: `auto` (default), `isolated`, `inherit`. Unknown values reject at config load.

## Behavior matrix

| Mode | `CLAUDE_CONFIG_DIR` env | `permission_mode` | Extra env |
|---|---|---|---|
| `isolated` | `<cwd>/agent-state/.claude` (today) | `acceptEdits` | — |
| `inherit` | unset / removed | `bypassPermissions` | `GIT_TERMINAL_PROMPT=0` |

The wider `bypassPermissions` is bundled with `inherit` because the host `~/.claude` plugins/hooks/skills will be loaded — `acceptEdits` would still hang on any plugin that prompts for input that isn't an Edit/Write/Bash. The Quest Agent project (`capt-pancakes/agent-team`) uses this pattern in production.

## Architecture

### Mode resolution (single call site)

```python
# producer/invoker.py
def _resolve_isolation_mode(
    *,
    config_value: Literal["auto", "isolated", "inherit"],
    env_override: str | None,
    has_api_key: bool,
    credentials_path: Path,
) -> Literal["isolated", "inherit"]:
    """Pure function. Returns the effective config_isolation.

    Priority: env_override > config_value > auto-detect.
    Logs a WARN when auto-detect picks 'inherit' so the operator knows
    isolation was dropped without explicit consent.
    """
```

Called from `ClaudeAgentInvoker.__init__`. Returns `"isolated"` or `"inherit"`. Stored as `self.config_isolation`. Drives all branching.

### `ClaudeAgentInvoker` changes

- New `auth_config: AuthConfig | None = None` parameter (callers without a config get the auto-detect default).
- Init now reads `PRODUCER_AUTH_MODE` env once, calls `_resolve_isolation_mode`.
- `_setup_subscription_auth` only runs in isolated mode.
- `CLAUDE_CONFIG_DIR` env var is set (isolated) or *removed* if previously set (inherit). Side-effect-free across modes.
- `permission_mode` constructor default changes from `"acceptEdits"` to `None` (sentinel "auto-pick from mode"). Resolution: callers passing an explicit `permission_mode=` always win; otherwise inherit → `bypassPermissions`, isolated → `acceptEdits`. Old callers (none currently) passing `permission_mode='acceptEdits'` explicitly keep their value even in inherit mode (escape hatch for anyone who wants to override).
- `invoke()` adds `GIT_TERMINAL_PROMPT=0` to the subprocess env when in inherit. In isolated, no change.
- `InvocationResult` gains `config_isolation: Literal["isolated", "inherit"]`.

### Config

```python
# producer/config.py
@dataclass
class AuthConfig:
    mode: Literal["auto", "isolated", "inherit"] = "auto"

@dataclass
class ProducerConfig:
    # ... existing fields ...
    auth: AuthConfig = field(default_factory=AuthConfig)
```

`load_config` parses an optional top-level `auth:` block:

```yaml
auth:
  mode: auto      # or 'isolated' or 'inherit'
```

Absent → `AuthConfig()` (mode=auto). Invalid value raises `ValueError` with allowed values listed.

### Ledger

Migration adds `config_isolation TEXT` column to `tasks` (nullable, idempotent — same pattern as `actual_cost_usd` in PR #1). `complete_task` accepts and persists it. `Task` dataclass gains the field.

### Dispatch

`Producer.run()` and `run_once()` log a one-line banner at startup:

```
auth=subscription, isolation=inherit (host ~/.claude inherited; bypassPermissions)
```

`handle_completion` reads `result.config_isolation`, passes it to `complete_task` (kw-only `config_isolation=...`), and includes it in the audit-event payload as `"config_isolation"` (same string key, alongside the existing `auth_mode`, `computed_cost_usd`, `actual_cost_usd` keys).

### Updated error message

The existing `RuntimeError` in `_setup_subscription_auth` now lists the inherit option:

```
no API key set and no local Claude Code credentials at <path>:
  • set ANTHROPIC_API_KEY (any environment), or
  • run `claude login` to create the credentials file (legacy auth), or
  • set auth.mode: inherit in producer.yaml — or PRODUCER_AUTH_MODE=inherit
    — to use Claude Code's host config (OAuth/Keychain auth)
```

Only fires when the user *explicitly* requested `isolated` and has no creds. In auto mode, we silently fall through to inherit.

## Edge cases

| auth.mode | API_KEY | `.credentials.json` | Result | `auth_mode` | `config_isolation` |
|---|---|---|---|---|---|
| auto | set | any | OK | api | isolated |
| auto | unset | exists | OK (today's symlink) | subscription | isolated |
| auto | unset | missing | OK (NEW; warn logged) | subscription | inherit |
| isolated | set | any | OK | api | isolated |
| isolated | unset | exists | OK | subscription | isolated |
| isolated | unset | missing | RuntimeError (improved msg) | — | — |
| inherit | set | any | OK | api | inherit |
| inherit | unset | any | OK | subscription | inherit |

API_KEY precedence at the Claude SDK level is unchanged — the SDK uses the env var if present. `config_isolation` only governs the config-dir handling.

## Residual risk

Inherit mode loads the host `~/.claude` plugins/hooks/skills. `bypassPermissions + GIT_TERMINAL_PROMPT=0` prevents prompt-driven hangs (Quest Agent runs this pattern in production without issue). Anything that crashes or loops *without* prompting (a buggy SkillEnter hook, for example) is the user's problem — surfaced through the existing no-productive-output detection and the dispatcher's retry/escalation path.

This risk is documented in the README and the warn-log message.

## Test plan

| Layer | File | Tests |
|---|---|---|
| Mode resolution | `tests/test_invoker.py` | All 6 priority branches: env-var > yaml > auto over (api/legacy/none); invalid env-var raises |
| Options assembly | `tests/test_invoker.py` | In inherit: no `CLAUDE_CONFIG_DIR` set; `permission_mode='bypassPermissions'`; subprocess env contains `GIT_TERMINAL_PROMPT=0` |
| Config parsing | `tests/test_config.py` | yaml round-trips `auth.mode: inherit`; `nonsense` rejected; absent block defaults to `auto` |
| Audit + persistence | `tests/test_dispatch.py`, `tests/test_ledger.py` | `config_isolation` reaches the row + audit; migration idempotent across two `LedgerClient` constructions |
| Smoke (stub) | `tests/test_smoke_echo_agent.py` | Parametrize over `[isolated, inherit]`. Both produce a completed task. Inherit branch asserts subprocess env *did not* receive `CLAUDE_CONFIG_DIR` |
| End-to-end (OAuth) | manual | `producer pricing update --dry-run` on user's OAuth Mac — listed in PR Test Plan |

CI cannot reasonably test the OAuth/Keychain path. Manual verification on the user's machine is the documented gate.

## Migration & rollout

- SQLite migration: `ALTER TABLE tasks ADD COLUMN config_isolation TEXT` if missing. Idempotent. Pre-existing rows stay NULL; queries that reference the column use `IS NOT NULL` guards (existing pattern from `actual_cost_usd`).
- Default `auth.mode: auto` means existing setups (which all set `ANTHROPIC_API_KEY` or have `.credentials.json`) keep getting `isolated`. **No behavior change for anyone except users currently hitting the RuntimeError.**
- Version bump: `0.1.0` → `0.2.0`. New feature, backward-compatible. Tag `v0.2.0` after merge.
- README "Subscription auth" section gains an "Inherit mode" subsection.
- CLAUDE.md invariant amended: the "do not inherit `~/.claude`" rule applies to *isolated mode*; inherit mode trades isolation for OAuth compatibility (opt-in or auto-detected with a warning).

## Public API impact

- `ClaudeAgentInvoker.__init__` adds optional `auth_config` parameter — additive, no breaks.
- `InvocationResult` gains `config_isolation` field — additive.
- `producer/__init__.py` re-exports `AuthConfig`. Update `__all__` accordingly.

## Deferred / out of scope

- **Keychain reads.** We don't try to extract OAuth tokens out of the macOS Keychain and write them to a synthetic `.credentials.json`. Quest Agent demonstrates that letting the CLI resolve its own auth is sufficient. If the OAuth format changes upstream we'd be chasing it; the inherit pattern is stable.
- **Per-task `config_isolation` overrides.** A task could in principle request a different isolation mode than the producer-wide default. Not requested, no use case in evidence.
- **Config-isolation tracking in the morning report.** Audit logs are sufficient for forensics; the daily report doesn't need per-mode badges.
