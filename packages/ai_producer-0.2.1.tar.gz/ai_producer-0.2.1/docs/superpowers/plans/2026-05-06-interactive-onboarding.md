# Interactive `producer init` Onboarding — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make `producer init` collect the boring config programmatically, scaffold the project, then `os.execvp` into a fresh `claude` CLI session preloaded with `ONBOARDING.md` so the user collaboratively designs their specialist roles + system prompts.

**Architecture:** Two-phase flow inside `cmd_init`. Phase 1 — pure-Python wizard (plain `input()`, auto-skipped when stdin is not a TTY) collects `project_name`, `ntfy_topic`, `subject_prefix`, then renders `producer.yaml` from a `string.Template`-based template, scaffolds prompt skeletons + ledger, writes `ONBOARDING.md`. Phase 2 — `os.execvp("claude", ...)` hands the TTY to Claude Code with `--append-system-prompt` pointing at `ONBOARDING.md` and `--permission-mode acceptEdits`. All testable logic lives in a new `producer/onboarding.py`; the `execvp` itself is a one-line wrapper.

**Tech Stack:** Python 3.11+, `string.Template` for substitution (matches existing `agent_prompt_template.md` usage), `shutil.which` for binary preflight, `pytest` + `monkeypatch` for tests.

**Spec:** `docs/superpowers/specs/2026-05-06-interactive-onboarding-design.md`

---

## File Structure

**New files:**

| Path | Responsibility |
|------|----------------|
| `producer/onboarding.py` | Pure-function building blocks: `preflight_claude_on_path()`, `build_claude_argv()`, `render_onboarding_md()`, `prompt_for_settings()`, `default_settings()`. |
| `templates/onboarding.md.template` | The bootstrap brief Claude Code reads at handoff. `string.Template` placeholders for project name + root. |
| `tests/test_onboarding.py` | Unit tests for the pure functions in `producer/onboarding.py`. |
| `tests/test_init_wizard.py` | Integration tests for the new wizard + handoff path through `cmd_init`. |

**Modified files:**

| Path | Change |
|------|--------|
| `producer/cli.py` | Refactor `cmd_init` into preflight → wizard → scaffold → handoff. Add `--non-interactive` and `--no-chat` flags. |
| `templates/producer.yaml.example` | Replace literal `my-project` / `my-project-CHANGEME-...` with `$project_name`, `$ntfy_topic`, `$subject_prefix` placeholders. |
| `tests/test_cli.py` | Update `test_init_renders_prompt_with_role_substitution` to assert against the basename-derived project name. Other tests pass unchanged because pytest stdin is not a TTY → wizard auto-skips. |
| `README.md` | Update Quickstart section to reflect the new init flow. |

**Untouched:** `producer/{dispatch,invoker,ledger,budget,escalation,morning_report,kill_switch,config}.py`, `producer/schema.sql`, all other tests.

---

## Task 1: Preflight check — `claude` on PATH

**Files:**
- Create: `producer/onboarding.py`
- Test: `tests/test_onboarding.py`

- [ ] **Step 1: Write the failing test**

Create `tests/test_onboarding.py`:

```python
"""Tests for producer.onboarding — pure functions backing the init wizard."""

from __future__ import annotations

import pytest

from producer import onboarding


def test_preflight_claude_on_path_true_when_present(monkeypatch):
    monkeypatch.setattr("shutil.which", lambda name: "/usr/local/bin/claude" if name == "claude" else None)
    assert onboarding.preflight_claude_on_path() is True


def test_preflight_claude_on_path_false_when_missing(monkeypatch):
    monkeypatch.setattr("shutil.which", lambda name: None)
    assert onboarding.preflight_claude_on_path() is False
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/test_onboarding.py -v`
Expected: FAIL with `ModuleNotFoundError: No module named 'producer.onboarding'`

- [ ] **Step 3: Write minimal implementation**

Create `producer/onboarding.py`:

```python
"""Onboarding wizard + bootstrap-chat handoff for ``producer init``.

Pure functions live here so the interactive ``cmd_init`` flow stays small
and testable. The actual ``os.execvp`` call lives in ``cli.py``; everything
that builds *what* gets exec'd is here.
"""

from __future__ import annotations

import shutil


def preflight_claude_on_path() -> bool:
    """Return True if the ``claude`` CLI is resolvable on PATH."""
    return shutil.which("claude") is not None
```

- [ ] **Step 4: Run test to verify it passes**

Run: `pytest tests/test_onboarding.py -v`
Expected: PASS (2 passed)

- [ ] **Step 5: Commit**

```bash
git add producer/onboarding.py tests/test_onboarding.py
git commit -m "onboarding: preflight check for claude CLI on PATH"
```

---

## Task 2: Build `claude` argv

**Files:**
- Modify: `producer/onboarding.py`
- Test: `tests/test_onboarding.py`

- [ ] **Step 1: Write the failing tests**

Append to `tests/test_onboarding.py`:

```python
def test_build_claude_argv_includes_append_system_prompt():
    argv = onboarding.build_claude_argv(project_root="/tmp/myproj")
    # Must start with the binary name (execvp uses argv[0] as program name).
    assert argv[0] == "claude"
    # System-prompt pointer is present.
    assert "--append-system-prompt" in argv
    idx = argv.index("--append-system-prompt")
    pointer = argv[idx + 1]
    assert "ONBOARDING.md" in pointer


def test_build_claude_argv_uses_accept_edits_permission_mode():
    argv = onboarding.build_claude_argv(project_root="/tmp/myproj")
    assert "--permission-mode" in argv
    idx = argv.index("--permission-mode")
    assert argv[idx + 1] == "acceptEdits"


def test_build_claude_argv_is_stable():
    """Argv shape should not change between two calls with the same input."""
    a = onboarding.build_claude_argv(project_root="/tmp/myproj")
    b = onboarding.build_claude_argv(project_root="/tmp/myproj")
    assert a == b
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `pytest tests/test_onboarding.py -v`
Expected: FAIL with `AttributeError: module 'producer.onboarding' has no attribute 'build_claude_argv'`

- [ ] **Step 3: Implement `build_claude_argv`**

Append to `producer/onboarding.py`:

```python
_BOOTSTRAP_POINTER = (
    "You are bootstrapping a new claude-producer project. "
    "Read ONBOARDING.md in the current directory before doing anything else, "
    "then start the conversation with the user."
)


def build_claude_argv(project_root: str) -> list[str]:
    """Build the argv passed to ``os.execvp`` for the bootstrap chat.

    ``project_root`` is currently informational — the user's terminal is
    already cd'd into the project — but is accepted so callers don't have
    to depend on cwd for argv construction.
    """
    del project_root  # reserved for future use (e.g. --add-dir).
    return [
        "claude",
        "--append-system-prompt",
        _BOOTSTRAP_POINTER,
        "--permission-mode",
        "acceptEdits",
    ]
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `pytest tests/test_onboarding.py -v`
Expected: PASS (5 passed total)

- [ ] **Step 5: Commit**

```bash
git add producer/onboarding.py tests/test_onboarding.py
git commit -m "onboarding: build_claude_argv for TTY handoff"
```

---

## Task 3: Onboarding brief template

**Files:**
- Create: `templates/onboarding.md.template`

This task creates the static asset; rendering is wired up in Task 4. No test here — the renderer test in Task 4 asserts the rendered output, which validates the template indirectly.

- [ ] **Step 1: Create the template**

Create `templates/onboarding.md.template`:

```markdown
# Bootstrap chat for $project_name

You are helping the user finish setting up their **claude-producer** project. The user just ran `producer init` and was handed off to this Claude Code session. Your job is to collaboratively design their specialist agents.

## What is claude-producer?

`claude-producer` is a long-running Producer that polls a SQLite-WAL ledger and dispatches tasks to specialist agents via the Claude Agent SDK. Each agent has its own system prompt, budget cap, and allowed tools. Agents file *their own* downstream tasks back into the ledger after producing output, which is what keeps the queue self-replenishing — without that, the loop goes idle.

The user has a working scaffold already (`producer.yaml`, `agent-state/ledger.db`, three default role prompts). Your job is to make it *theirs*.

## Files in scope

You may freely read and edit these (and only these — don't go wandering):

- `$project_root/producer.yaml` — role list under `budget.agents`, per-role `daily_cap_usd`, `dispatch_reservation_usd`, `allowed_tools`, and `prompt` path. This is the source of truth.
- `$project_root/agents/<role>/system_prompt.md` — per-role system prompt. Currently a skeleton with placeholder sections (Mission, Hard rules, Output discipline, Ledger discipline, Queue self-replenishment, Stop condition).
- `$project_root/seed_tasks.json` — optional initial tasks to file (write here, NOT to `seed_tasks.example.json`).

## Conversation goal — three phases

Move through these flexibly; don't read this back to the user as a script.

### 1. Discovery

Open with something like *"So — what are we building together?"* Listen first. Ask what kind of work they'd want to delegate to specialist agents and what the boundary between agents looks like for their project.

**Don't assume software.** This could be a writing pipeline (copy editor + marketer + fact-checker), a research workflow, an ops automation, a content production line, or a gamified app build (game-mechanics + content-author + playtester). The default scaffold has `producer + code + qa` but those are placeholders; replace them when they don't fit.

### 2. Role design

Once you understand the project, propose 2–4 specialist roles. Walk through them one at a time so the user stays engaged — don't dump a wall of YAML on them.

For each role:
- Update `$project_root/producer.yaml` under `budget.agents` (set `daily_cap_usd`, `dispatch_reservation_usd`, `allowed_tools`, `prompt`).
- Write the matching `agents/<role>/system_prompt.md` by filling in the skeleton's sections with role-specific content.

### 3. Seeding (optional)

Offer to draft 2–3 seed tasks they could file to give the loop something to chew on immediately. If yes, write them to `$project_root/seed_tasks.json` (JSON list of objects with `agent`, `title`, `description`, optional `priority` and `payload`). Tell them they can load these via `producer task add` per row, or via a small script.

If they'd rather seed by hand, that's fine — skip this phase.

## Conventions you must follow

- **Every specialist agent must file its own downstream tasks via `LedgerClient.insert_task`.** This is the keystone — without it, the queue stalls and the Producer goes idle. The skeleton's "Queue self-replenishment" section already explains this; keep that section in every prompt you write.
- **The `producer` role is special** (used for dispatch reservation). Don't remove it; you can rename it only if the user is sure.
- **`allowed_tools` should be minimal per role** — only what that specialist actually needs (e.g., a copy-editor probably doesn't need `Bash`, a researcher probably doesn't need `Edit`).
- **`daily_cap_usd` and `dispatch_reservation_usd` should reflect dispatch cost.** A role that runs many cheap tasks needs a higher daily cap; a role that runs a few expensive ones needs a higher dispatch reservation.

## Done signal

When the user says they're satisfied, summarize what you built together — one line per role plus a count of seed tasks if any — and remind them they can run `producer run` for the long-lived loop or `producer run --once` to drain a single pass. Then end the conversation; the user will exit when ready.
```

- [ ] **Step 2: Commit**

```bash
git add templates/onboarding.md.template
git commit -m "onboarding: bootstrap-chat brief template"
```

---

## Task 4: Render `ONBOARDING.md` from template

**Files:**
- Modify: `producer/onboarding.py`
- Test: `tests/test_onboarding.py`

- [ ] **Step 1: Write the failing tests**

Append to `tests/test_onboarding.py`:

```python
def test_render_onboarding_md_substitutes_placeholders():
    body = onboarding.render_onboarding_md(
        project_name="my-cool-thing",
        project_root="/tmp/cool",
    )
    assert "Bootstrap chat for my-cool-thing" in body
    assert "/tmp/cool/producer.yaml" in body
    # Placeholders should not leak through.
    assert "$project_name" not in body
    assert "$project_root" not in body


def test_render_onboarding_md_contains_required_sections():
    body = onboarding.render_onboarding_md(
        project_name="x", project_root="/tmp/x"
    )
    # The agent-facing brief must include these load-bearing sections.
    for needle in (
        "What is claude-producer",
        "Files in scope",
        "Discovery",
        "Role design",
        "Seeding",
        "Conventions you must follow",
        "Done signal",
        "LedgerClient.insert_task",
    ):
        assert needle in body, f"missing: {needle}"
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `pytest tests/test_onboarding.py -v`
Expected: FAIL with `AttributeError: ... 'render_onboarding_md'`

- [ ] **Step 3: Implement `render_onboarding_md`**

Add to top of `producer/onboarding.py` (after imports):

```python
import string
from pathlib import Path

_TEMPLATES_DIR = Path(__file__).resolve().parent.parent / "templates"
```

Append after `build_claude_argv`:

```python
def render_onboarding_md(project_name: str, project_root: str) -> str:
    """Render the bootstrap brief from the template.

    The output is what gets written to ``<project_root>/ONBOARDING.md`` and
    read by the bootstrap-chat agent at handoff.
    """
    template_path = _TEMPLATES_DIR / "onboarding.md.template"
    body = template_path.read_text(encoding="utf-8")
    return string.Template(body).substitute(
        project_name=project_name,
        project_root=project_root,
    )
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `pytest tests/test_onboarding.py -v`
Expected: PASS (7 passed total)

- [ ] **Step 5: Commit**

```bash
git add producer/onboarding.py tests/test_onboarding.py
git commit -m "onboarding: render ONBOARDING.md from template"
```

---

## Task 5: Templatize `producer.yaml.example`

**Files:**
- Modify: `templates/producer.yaml.example`
- Modify: `producer/cli.py` (the `cmd_init` yaml-copy step)
- Modify: `tests/test_cli.py` (one assertion to update)

The current `cmd_init` does `shutil.copy2(src_yaml, cfg_dst)` then `load_config(cfg_dst)`. We're switching the source to a `string.Template` and substituting before write so the wizard can plug values in.

- [ ] **Step 1: Replace literals with placeholders in `templates/producer.yaml.example`**

Edit `templates/producer.yaml.example`. Change exactly these three lines:

```yaml
project_name: my-project
```
becomes:
```yaml
project_name: $project_name
```

```yaml
  ntfy_topic: my-project-CHANGEME-pick-something-unguessable
```
becomes:
```yaml
  ntfy_topic: $ntfy_topic
```

```yaml
  subject_prefix: MyProject
```
becomes:
```yaml
  subject_prefix: $subject_prefix
```

Leave every other line of the file unchanged.

- [ ] **Step 2: Update `cmd_init` to substitute instead of copy**

Open `producer/cli.py`. Locate `cmd_init` (lines 43–100). Find this block:

```python
    src_yaml = _TEMPLATES_DIR / "producer.yaml.example"
    src_prompt = _TEMPLATES_DIR / "agent_prompt_template.md"
    src_seed = _TEMPLATES_DIR / "seed_tasks.example.json"
    if not src_yaml.exists() or not src_prompt.exists():
        print(f"templates dir missing files at {_TEMPLATES_DIR}")
        return 1

    shutil.copy2(src_yaml, cfg_dst)
    cfg = load_config(cfg_dst)
```

Replace with:

```python
    src_yaml = _TEMPLATES_DIR / "producer.yaml.example"
    src_prompt = _TEMPLATES_DIR / "agent_prompt_template.md"
    src_seed = _TEMPLATES_DIR / "seed_tasks.example.json"
    if not src_yaml.exists() or not src_prompt.exists():
        print(f"templates dir missing files at {_TEMPLATES_DIR}")
        return 1

    project_name = target_root.name or "my-project"
    yaml_body = string.Template(src_yaml.read_text(encoding="utf-8")).substitute(
        project_name=project_name,
        ntfy_topic=f"{project_name}-CHANGEME-pick-something-unguessable",
        subject_prefix=project_name,
    )
    cfg_dst.write_text(yaml_body, encoding="utf-8")
    cfg = load_config(cfg_dst)
```

(Wizard substitution comes in Task 7 — for now we preserve today's behavior with derived defaults.)

- [ ] **Step 3: Update `test_init_renders_prompt_with_role_substitution`**

Open `tests/test_cli.py`. Find:

```python
def test_init_renders_prompt_with_role_substitution(tmp_path):
    main(["init", "--dir", str(tmp_path)])
    prompt = (tmp_path / "agents" / "code" / "system_prompt.md").read_text()
    assert "Code Agent" in prompt
    assert "my-project" in prompt  # project_name from template
```

Replace with:

```python
def test_init_renders_prompt_with_role_substitution(tmp_path):
    main(["init", "--dir", str(tmp_path)])
    prompt = (tmp_path / "agents" / "code" / "system_prompt.md").read_text()
    assert "Code Agent" in prompt
    # project_name now derives from the target dir basename.
    assert tmp_path.name in prompt
```

- [ ] **Step 4: Run the full test suite to verify nothing else broke**

Run: `pytest -v`
Expected: PASS (all 93 existing tests + 7 new onboarding tests = 100 passed). If any test fails because it asserts the literal `"my-project"`, update the assertion to use `tmp_path.name` (the basename) the same way as in Step 3. Do not skip a failure; track it down.

- [ ] **Step 5: Commit**

```bash
git add templates/producer.yaml.example producer/cli.py tests/test_cli.py
git commit -m "init: templatize producer.yaml.example, derive project_name from dir"
```

---

## Task 6: Settings prompts (with non-TTY auto-skip)

**Files:**
- Modify: `producer/onboarding.py`
- Test: `tests/test_onboarding.py`

- [ ] **Step 1: Write the failing tests**

Append to `tests/test_onboarding.py`:

```python
import io
from pathlib import Path


def test_default_settings_derives_from_dir():
    s = onboarding.default_settings(target_root=Path("/tmp/my-cool-project"))
    assert s["project_name"] == "my-cool-project"
    # ntfy topic includes project name and a short random suffix.
    assert s["ntfy_topic"].startswith("my-cool-project-")
    assert len(s["ntfy_topic"]) > len("my-cool-project-")
    assert s["subject_prefix"] == "my-cool-project"


def test_default_settings_handles_dot_dir():
    """``producer init --dir .`` resolves to cwd; basename should still work."""
    s = onboarding.default_settings(target_root=Path("/tmp/foo"))
    assert s["project_name"] == "foo"


def test_prompt_for_settings_uses_input_when_tty(monkeypatch):
    answers = iter(["my-app", "my-app-topic-abc123", "MyApp"])
    monkeypatch.setattr("builtins.input", lambda prompt="": next(answers))
    s = onboarding.prompt_for_settings(
        defaults={"project_name": "foo", "ntfy_topic": "foo-x", "subject_prefix": "foo"},
        is_tty=True,
    )
    assert s == {
        "project_name": "my-app",
        "ntfy_topic": "my-app-topic-abc123",
        "subject_prefix": "MyApp",
    }


def test_prompt_for_settings_accepts_blank_to_use_default(monkeypatch):
    answers = iter(["", "", ""])
    monkeypatch.setattr("builtins.input", lambda prompt="": next(answers))
    defaults = {"project_name": "foo", "ntfy_topic": "foo-x", "subject_prefix": "foo"}
    s = onboarding.prompt_for_settings(defaults=defaults, is_tty=True)
    assert s == defaults


def test_prompt_for_settings_skips_when_not_tty(monkeypatch):
    """Non-TTY (pytest, CI) must never call input() — defaults straight through."""
    def boom(*_a, **_kw):
        raise AssertionError("input() called when stdin is not a TTY")
    monkeypatch.setattr("builtins.input", boom)
    defaults = {"project_name": "foo", "ntfy_topic": "foo-x", "subject_prefix": "foo"}
    s = onboarding.prompt_for_settings(defaults=defaults, is_tty=False)
    assert s == defaults
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `pytest tests/test_onboarding.py -v`
Expected: FAIL with `AttributeError: ... 'default_settings'` (and the prompt test).

- [ ] **Step 3: Implement `default_settings` and `prompt_for_settings`**

Add to imports at top of `producer/onboarding.py`:

```python
import secrets
import sys
from pathlib import Path
from typing import Mapping
```

Append:

```python
def default_settings(target_root: Path) -> dict[str, str]:
    """Derive sensible defaults from the target directory.

    ``project_name`` comes from the basename. ``ntfy_topic`` includes a short
    random suffix so two users with the same project name don't collide on
    ntfy.sh by accident.
    """
    name = target_root.name or "my-project"
    suffix = secrets.token_hex(4)  # 8 hex chars
    return {
        "project_name": name,
        "ntfy_topic": f"{name}-{suffix}",
        "subject_prefix": name,
    }


def prompt_for_settings(
    *,
    defaults: Mapping[str, str],
    is_tty: bool | None = None,
) -> dict[str, str]:
    """Interactively collect settings, falling back to defaults on bare Enter.

    When ``is_tty`` is False (CI / pytest / piped stdin), returns defaults
    verbatim without ever calling ``input()``. Pass ``is_tty=None`` to detect
    automatically via ``sys.stdin.isatty()``.
    """
    if is_tty is None:
        is_tty = sys.stdin.isatty()
    if not is_tty:
        return dict(defaults)

    out: dict[str, str] = {}
    for key, label in (
        ("project_name", "Project name"),
        ("ntfy_topic", "ntfy.sh topic"),
        ("subject_prefix", "Notification subject prefix"),
    ):
        d = defaults[key]
        answer = input(f"{label} [{d}]: ").strip()
        out[key] = answer if answer else d
    return out
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `pytest tests/test_onboarding.py -v`
Expected: PASS (12 passed total in this file)

- [ ] **Step 5: Commit**

```bash
git add producer/onboarding.py tests/test_onboarding.py
git commit -m "onboarding: settings prompts with non-TTY auto-skip"
```

---

## Task 7: Wire wizard into `cmd_init` (no handoff yet)

**Files:**
- Modify: `producer/cli.py`
- Test: `tests/test_init_wizard.py`

This task adds the `--non-interactive` and `--no-chat` flags and routes settings through `prompt_for_settings`. The actual `os.execvp` handoff is deferred to Task 8 — for now, `--no-chat` is the default behavior so existing tests stay green.

- [ ] **Step 1: Write the failing tests**

Create `tests/test_init_wizard.py`:

```python
"""Tests for the interactive wizard layer in ``producer init``.

Plain integration tests through ``cli.main(...)``. We don't exercise the
``os.execvp`` handoff itself here — that's a one-line wrapper covered by
mocking in Task 8's tests.
"""

from __future__ import annotations

import yaml

from producer.cli import main


def test_init_non_interactive_uses_basename_for_project_name(tmp_path):
    target = tmp_path / "writing-app"
    target.mkdir()
    rc = main(["init", "--dir", str(target), "--non-interactive", "--no-chat"])
    assert rc == 0
    cfg = yaml.safe_load((target / "producer.yaml").read_text())
    assert cfg["project_name"] == "writing-app"
    assert cfg["notifications"]["ntfy_topic"].startswith("writing-app-")
    # No CHANGEME sentinel left behind.
    assert "CHANGEME" not in (target / "producer.yaml").read_text()


def test_init_writes_onboarding_md(tmp_path):
    target = tmp_path / "writing-app"
    target.mkdir()
    rc = main(["init", "--dir", str(target), "--non-interactive", "--no-chat"])
    assert rc == 0
    onboarding_md = target / "ONBOARDING.md"
    assert onboarding_md.exists()
    body = onboarding_md.read_text()
    assert "Bootstrap chat for writing-app" in body
    assert "LedgerClient.insert_task" in body


def test_init_interactive_prompts_use_input(tmp_path, monkeypatch):
    """Simulate an interactive TTY with three answers."""
    answers = iter(["custom-name", "custom-topic-xyz", "Custom"])
    monkeypatch.setattr("builtins.input", lambda prompt="": next(answers))
    monkeypatch.setattr("sys.stdin.isatty", lambda: True)

    target = tmp_path / "writing-app"
    target.mkdir()
    rc = main(["init", "--dir", str(target), "--no-chat"])
    assert rc == 0
    cfg = yaml.safe_load((target / "producer.yaml").read_text())
    assert cfg["project_name"] == "custom-name"
    assert cfg["notifications"]["ntfy_topic"] == "custom-topic-xyz"
    assert cfg["notifications"]["subject_prefix"] == "Custom"
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `pytest tests/test_init_wizard.py -v`
Expected: FAIL — the `--non-interactive` and `--no-chat` flags don't exist yet, so argparse errors with `unrecognized arguments`.

- [ ] **Step 3: Add the flags to the argparse wiring**

Open `producer/cli.py`. Find `_build_parser` and locate the `p_init` block:

```python
    p_init = sub.add_parser("init", help="Scaffold producer.yaml + agents/ + agent-state/.")
    p_init.add_argument("--dir", default=".", help="Target directory (default: current).")
    p_init.add_argument("--force", action="store_true", help="Overwrite existing files.")
    p_init.set_defaults(fn=cmd_init)
```

Replace with:

```python
    p_init = sub.add_parser("init", help="Scaffold producer.yaml + agents/ + agent-state/.")
    p_init.add_argument("--dir", default=".", help="Target directory (default: current).")
    p_init.add_argument("--force", action="store_true", help="Overwrite existing files.")
    p_init.add_argument(
        "--non-interactive",
        action="store_true",
        help="Skip prompts; use defaults derived from --dir.",
    )
    p_init.add_argument(
        "--no-chat",
        action="store_true",
        help="Skip the post-scaffold handoff to the `claude` CLI bootstrap chat.",
    )
    p_init.set_defaults(fn=cmd_init)
```

- [ ] **Step 4: Refactor `cmd_init` to use the wizard**

Open `producer/cli.py`. Add this import near the top with the others:

```python
from producer import onboarding
```

Replace the entire `cmd_init` function (currently lines 43–100) with:

```python
def cmd_init(args: argparse.Namespace) -> int:
    target_root = Path(args.dir or ".").resolve()
    target_root.mkdir(parents=True, exist_ok=True)

    cfg_dst = target_root / "producer.yaml"
    if cfg_dst.exists() and not args.force:
        print(f"refusing to overwrite {cfg_dst} (use --force)")
        return 2

    src_yaml = _TEMPLATES_DIR / "producer.yaml.example"
    src_prompt = _TEMPLATES_DIR / "agent_prompt_template.md"
    src_seed = _TEMPLATES_DIR / "seed_tasks.example.json"
    if not src_yaml.exists() or not src_prompt.exists():
        print(f"templates dir missing files at {_TEMPLATES_DIR}")
        return 1

    # ---- Phase 1a: collect settings (interactive or default-only) ----
    defaults = onboarding.default_settings(target_root)
    if args.non_interactive:
        settings = dict(defaults)
    else:
        settings = onboarding.prompt_for_settings(defaults=defaults)

    # ---- Phase 1b: scaffold producer.yaml + role prompts + ledger ----
    yaml_body = string.Template(
        src_yaml.read_text(encoding="utf-8")
    ).substitute(**settings)
    cfg_dst.write_text(yaml_body, encoding="utf-8")
    cfg = load_config(cfg_dst)

    for role_name, role in cfg.roles.items():
        if role.prompt is None:
            continue
        prompt_path = cfg.project_root / role.prompt
        if prompt_path.exists() and not args.force:
            continue
        prompt_path.parent.mkdir(parents=True, exist_ok=True)
        body = string.Template(
            src_prompt.read_text(encoding="utf-8")
        ).safe_substitute(
            role=role_name,
            role_title=role_name.title(),
            project_name=cfg.project_name,
            project_root=str(cfg.project_root),
        )
        prompt_path.write_text(body, encoding="utf-8")

    cfg.ledger_db.parent.mkdir(parents=True, exist_ok=True)
    ledger = LedgerClient(db_path=cfg.ledger_db)
    ledger.append_audit(
        agent_owner="producer",
        action="schema_init",
        detail={"schema_version": 1},
    )
    ledger.close()

    seed_dst = cfg.project_root / "seed_tasks.example.json"
    if not seed_dst.exists() or args.force:
        shutil.copy2(src_seed, seed_dst)

    # ---- Phase 1c: write the bootstrap brief ----
    onboarding_md = cfg.project_root / "ONBOARDING.md"
    onboarding_md.write_text(
        onboarding.render_onboarding_md(
            project_name=cfg.project_name,
            project_root=str(cfg.project_root),
        ),
        encoding="utf-8",
    )

    print(f"initialized at {cfg.project_root}")
    print(f"  config:    {cfg_dst}")
    print(f"  ledger:    {cfg.ledger_db}")
    print(f"  prompts:   {cfg.project_root / 'agents'}/")
    print(f"  seed ex:   {seed_dst}")
    print(f"  onboard:   {onboarding_md}")

    # ---- Phase 2: handoff (deferred to Task 8) ----
    if args.no_chat:
        return 0
    return 0  # TEMPORARY — Task 8 replaces this with execvp handoff.
```

- [ ] **Step 5: Run new + full test suite to verify**

Run: `pytest tests/test_init_wizard.py -v`
Expected: PASS (3 passed)

Run: `pytest -v`
Expected: PASS (all tests). If `test_init_creates_scaffold` or similar fails because of the new `ONBOARDING.md` write, it shouldn't — those tests don't assert absence of files. If something does break, fix it (likely a missing-file expectation that needs updating).

- [ ] **Step 6: Commit**

```bash
git add producer/cli.py tests/test_init_wizard.py
git commit -m "init: wizard layer with --non-interactive and --no-chat flags"
```

---

## Task 8: TTY handoff via `os.execvp`

**Files:**
- Modify: `producer/cli.py`
- Test: `tests/test_init_wizard.py`

- [ ] **Step 1: Write the failing tests**

Append to `tests/test_init_wizard.py`:

```python
def test_init_skips_handoff_when_no_chat(tmp_path, monkeypatch):
    """--no-chat must not call execvp at all."""
    calls = []
    monkeypatch.setattr("os.execvp", lambda f, a: calls.append((f, a)))
    target = tmp_path / "p"
    target.mkdir()
    rc = main(["init", "--dir", str(target), "--non-interactive", "--no-chat"])
    assert rc == 0
    assert calls == []


def test_init_skips_handoff_when_claude_missing(tmp_path, monkeypatch, capsys):
    """If claude is not on PATH, scaffold but skip handoff with a friendly message."""
    monkeypatch.setattr("shutil.which", lambda name: None)
    calls = []
    monkeypatch.setattr("os.execvp", lambda f, a: calls.append((f, a)))
    target = tmp_path / "p"
    target.mkdir()
    rc = main(["init", "--dir", str(target), "--non-interactive"])
    assert rc == 0
    assert calls == []  # never attempted execvp
    out = capsys.readouterr().out
    assert "claude" in out.lower()  # message mentions the missing binary


def test_init_calls_execvp_when_claude_present(tmp_path, monkeypatch):
    """Happy path: claude on PATH + interactive run + no --no-chat → execvp fires."""
    monkeypatch.setattr("shutil.which", lambda name: "/usr/local/bin/claude")
    calls = []
    monkeypatch.setattr("os.execvp", lambda f, a: calls.append((f, a)))
    target = tmp_path / "p"
    target.mkdir()
    rc = main(["init", "--dir", str(target), "--non-interactive"])
    assert rc == 0
    assert len(calls) == 1
    file_arg, argv = calls[0]
    assert file_arg == "claude"
    assert argv[0] == "claude"
    assert "--append-system-prompt" in argv
    assert "--permission-mode" in argv


def test_init_handles_execvp_failure_gracefully(tmp_path, monkeypatch, capsys):
    """OSError from execvp: print friendly message, return 0 (scaffold work is durable)."""
    monkeypatch.setattr("shutil.which", lambda name: "/usr/local/bin/claude")

    def boom(_f, _a):
        raise OSError("[Errno 2] No such file or directory: 'claude'")
    monkeypatch.setattr("os.execvp", boom)

    target = tmp_path / "p"
    target.mkdir()
    rc = main(["init", "--dir", str(target), "--non-interactive"])
    assert rc == 0
    out = capsys.readouterr().out
    assert "scaffolding succeeded" in out.lower() or "run `claude`" in out.lower()
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `pytest tests/test_init_wizard.py -v`
Expected: FAIL — the new handoff path doesn't exist yet, so `test_init_calls_execvp_when_claude_present` fails (no execvp call).

- [ ] **Step 3: Implement the handoff**

Open `producer/cli.py`. Add an import near the top:

```python
import os
```

(If it's already imported, skip.)

Find the end of `cmd_init` (the `# ---- Phase 2: handoff ...` block). Replace:

```python
    # ---- Phase 2: handoff (deferred to Task 8) ----
    if args.no_chat:
        return 0
    return 0  # TEMPORARY — Task 8 replaces this with execvp handoff.
```

with:

```python
    # ---- Phase 2: handoff to claude CLI ----
    if args.no_chat:
        return 0

    if not onboarding.preflight_claude_on_path():
        print(
            "Note: `claude` CLI not found on PATH; skipping bootstrap chat. "
            "Install Claude Code and run `claude` in this directory to "
            "start the bootstrap chat (it will pick up ONBOARDING.md)."
        )
        return 0

    argv = onboarding.build_claude_argv(project_root=str(cfg.project_root))
    print(f"Handing off to claude in {cfg.project_root}…")
    try:
        os.execvp(argv[0], argv)
    except OSError as exc:
        print(f"Failed to launch claude: {exc}")
        print(
            "Scaffolding succeeded. Run `claude` in this directory to start "
            "the bootstrap chat."
        )
        return 0

    return 0  # unreachable on successful execvp
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `pytest tests/test_init_wizard.py -v`
Expected: PASS (7 passed in this file)

Run: `pytest -v`
Expected: PASS (all tests). The existing `test_init_*` cases in `tests/test_cli.py` don't pass `--no-chat` — they will reach the handoff branch and either skip cleanly (claude missing) or attempt execvp. **Important:** `os.execvp` would actually replace the test process. Verify this doesn't happen in the tests that don't mock `execvp`.

If existing `tests/test_cli.py` tests fail because they unexpectedly trigger execvp, the fix is: make those tests pass `--no-chat` explicitly. Update each `main(["init", "--dir", str(tmp_path)])` to `main(["init", "--dir", str(tmp_path), "--no-chat"])`. Do this for every existing test in `test_cli.py` that calls `main(["init", ...])` without `--no-chat` — there are roughly 8 of them.

- [ ] **Step 5: Commit**

```bash
git add producer/cli.py tests/test_init_wizard.py tests/test_cli.py
git commit -m "init: TTY handoff to claude CLI bootstrap chat"
```

---

## Task 9: README quickstart update

**Files:**
- Modify: `README.md`

- [ ] **Step 1: Locate and update the Quickstart section**

Open `README.md`. Find the section that documents `producer init` (search for `producer init`). Update it so the quickstart reads roughly:

```markdown
## Quickstart

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"
producer init                  # interactive: collects project name + ntfy topic,
                               # then hands off to a Claude Code session that
                               # walks you through designing your specialist agents
producer run --once            # drain the queue once
producer run                   # long-lived loop (Ctrl-C to stop)
```

`producer init` flags:

- `--dir <path>` — target directory (default: current)
- `--force` — overwrite existing files
- `--non-interactive` — skip the wizard; derive defaults from `--dir`
- `--no-chat` — finish scaffolding only; skip the bootstrap-chat handoff

After `producer init` exits, your project has:

- `producer.yaml` — config (role list, budgets, ntfy topic)
- `agents/<role>/system_prompt.md` — per-role prompt skeletons (filled in via the bootstrap chat)
- `agent-state/ledger.db` — initialized SQLite ledger
- `seed_tasks.example.json` — example seed-tasks file
- `ONBOARDING.md` — the bootstrap-chat brief (re-run `claude` here any time to re-engage)
```

If the existing README has a different structure, adapt the wording but keep the same set of facts: new flags, new `ONBOARDING.md` artifact, `claude` CLI required for the chat phase.

- [ ] **Step 2: Run the full suite one final time**

Run: `pytest -v`
Expected: PASS (all tests)

- [ ] **Step 3: Commit**

```bash
git add README.md
git commit -m "docs: README quickstart for new init wizard + bootstrap chat"
```

---

## Self-Review

**Spec coverage:** every section of the spec maps to a task —
- §"Phase 1: Programmatic wizard" → Tasks 5, 6, 7
- §"Phase 2: TTY handoff" → Tasks 2, 8
- §"`ONBOARDING.md` contents" → Tasks 3, 4
- §"Error handling" → Task 8 steps 1+3 (preflight skip, execvp OSError)
- §"Testing strategy" → tests in every task; the "not tested" item (raw execvp) is replaced with an `os.execvp` mock at the boundary
- §"Implementation surface" → file map at top of plan matches spec's table 1:1
- §"Success criteria" → exercised by Tasks 7+8 integration tests + Task 9 README

**Placeholder scan:** plan grepped for "TBD", "TODO", "implement later", "appropriate error handling", "similar to" — none present. Every code step has actual code; every test step has actual assertions; every commit step has the commit command.

**Type consistency:** `prompt_for_settings`, `default_settings`, `render_onboarding_md`, `build_claude_argv`, `preflight_claude_on_path` keep the same signatures across Tasks 1, 2, 4, 6 (definition) and Task 7 (use). `settings` dict keys are the same triple — `project_name`, `ntfy_topic`, `subject_prefix` — wherever they appear.

**Notable simplifying decisions:**
- The spec mentioned `prompt_for_settings(defaults)` but didn't specify TTY auto-detection. I added `is_tty` parameter so existing tests don't break and CI works without flags. This is a strict superset of what the spec asked for.
- The spec said placeholders "keep the file usable as a non-templated example by giving the placeholders sensible literal defaults" — that's contradictory (a file can't both have `$placeholder` and be valid YAML). The plan resolves by templatizing; the rendered `producer.yaml` after init *is* the example users will refer to. Trade-off: the source `.example` file no longer round-trips through `load_config` directly, but it was never loaded that way in production (init always copies first).
