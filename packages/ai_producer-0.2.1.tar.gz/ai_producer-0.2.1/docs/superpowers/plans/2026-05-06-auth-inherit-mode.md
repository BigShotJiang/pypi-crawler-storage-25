# Auth Inherit Mode Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use `superpowers:subagent-driven-development` (recommended) or `superpowers:executing-plans` to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add an opt-in `inherit` mode to `ClaudeAgentInvoker` so users authed via Claude Code OAuth (macOS Keychain) can run claude-producer without setting `ANTHROPIC_API_KEY`. Auto-detect when neither API key nor `~/.claude/.credentials.json` exists, with `producer.yaml` and env-var overrides.

**Architecture:** Two orthogonal dimensions: `auth_mode` (`api`/`subscription`, existing) and `config_isolation` (`isolated`/`inherit`, new). Inherit mode skips the `CLAUDE_CONFIG_DIR` override, uses `permission_mode='bypassPermissions'`, and sets `GIT_TERMINAL_PROMPT=0`. Resolution priority: `PRODUCER_AUTH_MODE` env > `auth.mode` yaml > auto-detect.

**Tech Stack:** Python 3.11+, `claude_agent_sdk`, SQLite-WAL ledger, pytest with `asyncio_mode='auto'`.

**Spec:** `docs/superpowers/specs/2026-05-06-auth-inherit-mode-design.md`

---

## Task 1: AuthConfig dataclass + yaml parsing

**Files:**
- Modify: `producer/config.py`
- Test: `tests/test_config.py` (create — does not exist yet)

- [ ] **Step 1: Write the failing test**

Create `tests/test_config.py`:

```python
"""Tests for producer.config — focused on the new AuthConfig parsing."""
from __future__ import annotations

import pytest
import yaml

from producer.config import AuthConfig, load_config


def _minimal_yaml(extra: dict | None = None) -> dict:
    """Smallest yaml that load_config will accept."""
    base = {
        "project_name": "Test",
        "project_root": ".",
        "budget": {"project_ceiling_usd": 1.0, "agents": {}},
    }
    if extra:
        base.update(extra)
    return base


def test_auth_config_defaults_to_auto_when_block_absent(tmp_path):
    cfg_path = tmp_path / "producer.yaml"
    cfg_path.write_text(yaml.safe_dump(_minimal_yaml()), encoding="utf-8")
    cfg = load_config(cfg_path)
    assert cfg.auth.mode == "auto"


def test_auth_config_parses_explicit_mode(tmp_path):
    for mode in ("auto", "isolated", "inherit"):
        cfg_path = tmp_path / "producer.yaml"
        cfg_path.write_text(
            yaml.safe_dump(_minimal_yaml({"auth": {"mode": mode}})),
            encoding="utf-8",
        )
        cfg = load_config(cfg_path)
        assert cfg.auth.mode == mode, f"failed for mode={mode}"


def test_auth_config_rejects_unknown_mode(tmp_path):
    cfg_path = tmp_path / "producer.yaml"
    cfg_path.write_text(
        yaml.safe_dump(_minimal_yaml({"auth": {"mode": "nonsense"}})),
        encoding="utf-8",
    )
    with pytest.raises(ValueError, match="auth.mode"):
        load_config(cfg_path)


def test_auth_config_dataclass_default():
    """AuthConfig() with no args → mode=auto."""
    assert AuthConfig().mode == "auto"
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/test_config.py -v`
Expected: 4 failures with `ImportError` on `AuthConfig` (or `AttributeError` on `cfg.auth`).

- [ ] **Step 3: Implement `AuthConfig`**

In `producer/config.py`, add after the existing `NotificationsConfig` dataclass:

```python
@dataclass
class AuthConfig:
    """Auth and config-isolation mode for ``ClaudeAgentInvoker``.

    ``mode``:
        - ``auto`` (default): detect at startup. API_KEY → isolated;
          ``.credentials.json`` exists → isolated; else inherit (warn logged).
        - ``isolated``: force ``CLAUDE_CONFIG_DIR`` override. Errors if no
          API_KEY and no ``.credentials.json`` (the existing behavior).
        - ``inherit``: no ``CLAUDE_CONFIG_DIR`` override. Subprocess inherits
          the user's ``~/.claude``. Required for OAuth/Keychain auth.
    """

    mode: str = "auto"


_VALID_AUTH_MODES = {"auto", "isolated", "inherit"}
```

Add `auth: AuthConfig` field to `ProducerConfig`:

```python
@dataclass
class ProducerConfig:
    project_name: str
    # ... existing fields ...
    reports_dir: Path
    auth: AuthConfig = field(default_factory=AuthConfig)
```

Update `load_config` — after parsing `notifications`, add:

```python
    auth_data = data.get("auth", {}) or {}
    auth_mode = auth_data.get("mode", "auto")
    if auth_mode not in _VALID_AUTH_MODES:
        raise ValueError(
            f"auth.mode must be one of {sorted(_VALID_AUTH_MODES)}; got {auth_mode!r}"
        )
    auth = AuthConfig(mode=auth_mode)
```

And include `auth=auth` in the returned `ProducerConfig(...)`.

- [ ] **Step 4: Run test to verify it passes**

Run: `pytest tests/test_config.py -v`
Expected: 4 passing.

- [ ] **Step 5: Commit**

```bash
git add producer/config.py tests/test_config.py
git commit -m "feat(config): AuthConfig dataclass + auth.mode yaml parsing"
```

---

## Task 2: `_resolve_isolation_mode` pure function

**Files:**
- Modify: `producer/invoker.py`
- Modify: `tests/test_invoker.py`

- [ ] **Step 1: Write the failing tests**

Add to `tests/test_invoker.py`:

```python
from pathlib import Path
import pytest
from producer.invoker import _resolve_isolation_mode


class TestResolveIsolationMode:
    """Pure function: priority is env_override > config_value > auto-detect."""

    def test_env_override_inherit_beats_config(self, tmp_path):
        result = _resolve_isolation_mode(
            config_value="isolated",
            env_override="inherit",
            has_api_key=True,
            credentials_path=tmp_path / "no.json",
        )
        assert result == "inherit"

    def test_env_override_isolated_beats_config(self, tmp_path):
        result = _resolve_isolation_mode(
            config_value="inherit",
            env_override="isolated",
            has_api_key=False,
            credentials_path=tmp_path / "no.json",
        )
        assert result == "isolated"

    def test_invalid_env_override_raises(self, tmp_path):
        with pytest.raises(ValueError, match="PRODUCER_AUTH_MODE"):
            _resolve_isolation_mode(
                config_value="auto",
                env_override="nonsense",
                has_api_key=True,
                credentials_path=tmp_path / "no.json",
            )

    def test_explicit_config_inherit_used_when_no_env(self, tmp_path):
        result = _resolve_isolation_mode(
            config_value="inherit",
            env_override=None,
            has_api_key=True,
            credentials_path=tmp_path / "no.json",
        )
        assert result == "inherit"

    def test_explicit_config_isolated_used_when_no_env(self, tmp_path):
        result = _resolve_isolation_mode(
            config_value="isolated",
            env_override=None,
            has_api_key=False,
            credentials_path=tmp_path / "no.json",
        )
        assert result == "isolated"

    def test_auto_picks_isolated_when_api_key_present(self, tmp_path):
        result = _resolve_isolation_mode(
            config_value="auto",
            env_override=None,
            has_api_key=True,
            credentials_path=tmp_path / "no.json",
        )
        assert result == "isolated"

    def test_auto_picks_isolated_when_credentials_file_exists(self, tmp_path):
        creds = tmp_path / ".credentials.json"
        creds.write_text("{}")
        result = _resolve_isolation_mode(
            config_value="auto",
            env_override=None,
            has_api_key=False,
            credentials_path=creds,
        )
        assert result == "isolated"

    def test_auto_picks_inherit_when_neither_present(self, tmp_path, caplog):
        import logging
        caplog.set_level(logging.WARNING, logger="producer.invoker")
        result = _resolve_isolation_mode(
            config_value="auto",
            env_override=None,
            has_api_key=False,
            credentials_path=tmp_path / "no.json",
        )
        assert result == "inherit"
        assert any(
            "inherit" in record.message and "isolation disabled" in record.message
            for record in caplog.records
        ), "expected a WARN log explaining the auto fallback"
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/test_invoker.py::TestResolveIsolationMode -v`
Expected: 8 failures with `ImportError: cannot import name '_resolve_isolation_mode'`.

- [ ] **Step 3: Implement the function**

Add to `producer/invoker.py`, after the `logger = logging.getLogger(...)` line and before the `InvocationResult` dataclass:

```python
_VALID_ISOLATION_MODES = ("auto", "isolated", "inherit")


def _resolve_isolation_mode(
    *,
    config_value: str,
    env_override: str | None,
    has_api_key: bool,
    credentials_path: Path,
) -> Literal["isolated", "inherit"]:
    """Resolve the effective config_isolation. Pure function.

    Priority: env_override > config_value > auto-detect.
    Logs WARN when auto-detect picks 'inherit' (isolation silently dropped).
    """
    effective = env_override if env_override is not None else config_value
    if effective not in _VALID_ISOLATION_MODES:
        source = "PRODUCER_AUTH_MODE" if env_override is not None else "auth.mode"
        raise ValueError(
            f"{source} must be one of {list(_VALID_ISOLATION_MODES)}; got {effective!r}"
        )

    if effective in ("isolated", "inherit"):
        return effective  # type: ignore[return-value]

    # auto
    if has_api_key or credentials_path.exists():
        return "isolated"
    logger.warning(
        "isolation disabled (auto): no ANTHROPIC_API_KEY and no %s — "
        "falling back to inherit mode (host ~/.claude will be used). "
        "Set auth.mode in producer.yaml to silence this warning.",
        credentials_path,
    )
    return "inherit"
```

- [ ] **Step 4: Run test to verify it passes**

Run: `pytest tests/test_invoker.py::TestResolveIsolationMode -v`
Expected: 8 passing.

- [ ] **Step 5: Commit**

```bash
git add producer/invoker.py tests/test_invoker.py
git commit -m "feat(invoker): _resolve_isolation_mode — env > yaml > auto-detect"
```

---

## Task 3: ClaudeAgentInvoker integration — config_isolation field

**Files:**
- Modify: `producer/invoker.py`
- Modify: `tests/test_invoker.py`

- [ ] **Step 1: Write the failing tests**

Add to `tests/test_invoker.py`:

```python
class TestInvokerIsolatedMode:
    """In isolated mode, today's behavior is preserved."""

    def test_isolated_mode_sets_config_dir_env(self, tmp_path, monkeypatch):
        from producer.invoker import ClaudeAgentInvoker
        monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")
        monkeypatch.delenv("PRODUCER_AUTH_MODE", raising=False)
        inv = ClaudeAgentInvoker(cwd=tmp_path)
        assert inv.config_isolation == "isolated"
        assert os.environ.get("CLAUDE_CONFIG_DIR") == str(inv.config_dir)
        assert inv.permission_mode == "acceptEdits"

    def test_isolated_mode_uses_acceptedits_permission(self, tmp_path, monkeypatch):
        from producer.invoker import ClaudeAgentInvoker
        monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")
        monkeypatch.delenv("PRODUCER_AUTH_MODE", raising=False)
        inv = ClaudeAgentInvoker(cwd=tmp_path)
        assert inv.permission_mode == "acceptEdits"


class TestInvokerInheritMode:
    """Inherit mode skips the symlink and the config dir override."""

    def test_inherit_mode_does_not_set_config_dir(self, tmp_path, monkeypatch):
        from producer.invoker import ClaudeAgentInvoker
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
        monkeypatch.setenv("PRODUCER_AUTH_MODE", "inherit")
        # Even if a stale CLAUDE_CONFIG_DIR is set, inherit mode unsets it.
        monkeypatch.setenv("CLAUDE_CONFIG_DIR", "/some/stale/path")
        inv = ClaudeAgentInvoker(cwd=tmp_path)
        assert inv.config_isolation == "inherit"
        assert "CLAUDE_CONFIG_DIR" not in os.environ
        assert inv.permission_mode == "bypassPermissions"
        assert inv.auth_mode == "subscription"  # no API key

    def test_inherit_mode_with_api_key_keeps_api_auth(self, tmp_path, monkeypatch):
        from producer.invoker import ClaudeAgentInvoker
        monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")
        monkeypatch.setenv("PRODUCER_AUTH_MODE", "inherit")
        inv = ClaudeAgentInvoker(cwd=tmp_path)
        assert inv.config_isolation == "inherit"
        assert inv.auth_mode == "api"

    def test_inherit_mode_skips_symlink_setup(self, tmp_path, monkeypatch):
        """Even with no .credentials.json, inherit mode must not raise."""
        from producer.invoker import ClaudeAgentInvoker
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
        monkeypatch.setenv("PRODUCER_AUTH_MODE", "inherit")
        # Point at a fake home with no credentials file.
        fake_home = tmp_path / "fake_home"
        fake_home.mkdir()
        monkeypatch.setattr("pathlib.Path.home", lambda: fake_home)
        inv = ClaudeAgentInvoker(cwd=tmp_path)  # must not raise
        assert inv.config_isolation == "inherit"

    def test_explicit_isolated_with_no_creds_still_raises(self, tmp_path, monkeypatch):
        """Improved error message lists all 3 options."""
        from producer.invoker import ClaudeAgentInvoker
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
        monkeypatch.setenv("PRODUCER_AUTH_MODE", "isolated")
        fake_home = tmp_path / "fake_home"
        fake_home.mkdir()
        monkeypatch.setattr("pathlib.Path.home", lambda: fake_home)
        with pytest.raises(RuntimeError) as exc_info:
            ClaudeAgentInvoker(cwd=tmp_path)
        msg = str(exc_info.value)
        assert "ANTHROPIC_API_KEY" in msg
        assert "auth.mode: inherit" in msg
        assert "PRODUCER_AUTH_MODE=inherit" in msg
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `pytest tests/test_invoker.py::TestInvokerIsolatedMode tests/test_invoker.py::TestInvokerInheritMode -v`
Expected: failures — `inv.config_isolation` doesn't exist yet, etc.

- [ ] **Step 3: Modify `ClaudeAgentInvoker.__init__`**

In `producer/invoker.py`, replace the entire `__init__` method body with:

```python
    def __init__(
        self,
        *,
        cwd: Path | str,
        api_key: str | None = None,
        config_dir: Path | str | None = None,
        permission_mode: str | None = None,  # None = auto-pick from mode
        auth_config: Any = None,             # AuthConfig | None — late import
    ) -> None:
        self.cwd = Path(cwd).resolve()

        # Resolve config_isolation BEFORE touching any env vars or filesystem.
        config_value = "auto"
        if auth_config is not None:
            config_value = getattr(auth_config, "mode", "auto")
        env_override = os.environ.get("PRODUCER_AUTH_MODE")
        creds_path = Path.home() / ".claude" / ".credentials.json"
        has_api_key = bool(api_key or os.environ.get("ANTHROPIC_API_KEY"))
        self.config_isolation = _resolve_isolation_mode(
            config_value=config_value,
            env_override=env_override,
            has_api_key=has_api_key,
            credentials_path=creds_path,
        )

        # auth_mode is independent: API_KEY presence determines it.
        resolved_key = api_key or os.environ.get("ANTHROPIC_API_KEY")
        if resolved_key:
            self.auth_mode = "api"
            self.api_key = resolved_key
            os.environ.setdefault("ANTHROPIC_API_KEY", resolved_key)
        else:
            self.auth_mode = "subscription"
            self.api_key = None

        # Config dir handling depends on isolation mode.
        if self.config_isolation == "isolated":
            self.config_dir = (
                Path(config_dir).resolve()
                if config_dir is not None
                else (self.cwd / "agent-state" / ".claude").resolve()
            )
            self.config_dir.mkdir(parents=True, exist_ok=True)
            os.environ["CLAUDE_CONFIG_DIR"] = str(self.config_dir)
            if self.auth_mode == "subscription":
                self._setup_subscription_auth()
        else:  # inherit
            self.config_dir = None
            # Remove any stale CLAUDE_CONFIG_DIR so the subprocess inherits
            # the host ~/.claude.
            os.environ.pop("CLAUDE_CONFIG_DIR", None)

        # permission_mode: explicit value wins; otherwise pick from mode.
        if permission_mode is not None:
            self.permission_mode = permission_mode
        elif self.config_isolation == "inherit":
            self.permission_mode = "bypassPermissions"
        else:
            self.permission_mode = "acceptEdits"
```

Update the `_setup_subscription_auth` error message to the 3-option version (covered in Task 7 — for now keep the existing message; tests for the new message are in Task 7).

Also update the type annotation on the existing `self.config_dir` reference: it can now be `None`, so update the docstring/typing as needed (the `__init__` body already does this via the new branching).

- [ ] **Step 4: Run tests to verify they pass**

Run: `pytest tests/test_invoker.py::TestInvokerIsolatedMode tests/test_invoker.py::TestInvokerInheritMode -v`
Expected: 4 of 5 passing. The `test_explicit_isolated_with_no_creds_still_raises` test requires the new 3-option error message — it's expected to fail now. That test will pass after Task 7.

- [ ] **Step 5: Run the full suite to confirm no regressions**

Run: `pytest -q`
Expected: 1 failure (`test_explicit_isolated_with_no_creds_still_raises` from Task 7), all 149 prior tests passing, plus the 8 from Task 2.

- [ ] **Step 6: Commit**

```bash
git add producer/invoker.py tests/test_invoker.py
git commit -m "feat(invoker): config_isolation field; inherit skips CLAUDE_CONFIG_DIR override"
```

---

## Task 4: invoke() — GIT_TERMINAL_PROMPT in inherit mode

**Files:**
- Modify: `producer/invoker.py`
- Modify: `tests/test_invoker.py`

- [ ] **Step 1: Write the failing test**

Add to `tests/test_invoker.py`:

```python
class TestInheritEnvSetup:
    """Inherit mode sets GIT_TERMINAL_PROMPT=0 to prevent git prompts."""

    def test_inherit_mode_sets_git_terminal_prompt(self, tmp_path, monkeypatch):
        from producer.invoker import ClaudeAgentInvoker
        monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")
        monkeypatch.setenv("PRODUCER_AUTH_MODE", "inherit")
        monkeypatch.delenv("GIT_TERMINAL_PROMPT", raising=False)
        ClaudeAgentInvoker(cwd=tmp_path)
        assert os.environ.get("GIT_TERMINAL_PROMPT") == "0"

    def test_isolated_mode_does_not_touch_git_terminal_prompt(self, tmp_path, monkeypatch):
        from producer.invoker import ClaudeAgentInvoker
        monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")
        monkeypatch.delenv("PRODUCER_AUTH_MODE", raising=False)
        monkeypatch.delenv("GIT_TERMINAL_PROMPT", raising=False)
        ClaudeAgentInvoker(cwd=tmp_path)
        assert "GIT_TERMINAL_PROMPT" not in os.environ
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/test_invoker.py::TestInheritEnvSetup -v`
Expected: 1 failure (the inherit test); the isolated test passes vacuously.

- [ ] **Step 3: Implement**

In `producer/invoker.py`, in `__init__`, inside the `else: # inherit` block, after `os.environ.pop("CLAUDE_CONFIG_DIR", None)`, add:

```python
            os.environ.setdefault("GIT_TERMINAL_PROMPT", "0")
```

- [ ] **Step 4: Run test to verify it passes**

Run: `pytest tests/test_invoker.py::TestInheritEnvSetup -v`
Expected: 2 passing.

- [ ] **Step 5: Commit**

```bash
git add producer/invoker.py tests/test_invoker.py
git commit -m "feat(invoker): inherit mode sets GIT_TERMINAL_PROMPT=0"
```

---

## Task 5: InvocationResult.config_isolation field

**Files:**
- Modify: `producer/invoker.py`
- Modify: `tests/test_invoker.py`

- [ ] **Step 1: Write the failing test**

Add to `tests/test_invoker.py`:

```python
class TestInvocationResultIsolation:
    """InvocationResult carries config_isolation for downstream auditing."""

    def test_default_is_isolated(self):
        from producer.invoker import InvocationResult
        result = InvocationResult(text="hi", cost_usd=0.0)
        assert result.config_isolation == "isolated"

    def test_inherit_value_round_trips(self):
        from producer.invoker import InvocationResult
        result = InvocationResult(
            text="hi", cost_usd=0.0, config_isolation="inherit"
        )
        assert result.config_isolation == "inherit"
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/test_invoker.py::TestInvocationResultIsolation -v`
Expected: 2 failures (`config_isolation` not a field).

- [ ] **Step 3: Implement**

In `producer/invoker.py`, modify the `InvocationResult` dataclass:

```python
@dataclass
class InvocationResult:
    """..."""
    text: str
    cost_usd: float
    computed_cost_usd: float = 0.0
    actual_cost_usd: float | None = None
    usage: dict[str, int] = field(default_factory=dict)
    auth_mode: Literal["api", "subscription"] = "api"
    config_isolation: Literal["isolated", "inherit"] = "isolated"  # NEW
    tool_calls: list[dict[str, Any]] = field(default_factory=list)
    raw_messages: list[Any] = field(default_factory=list)
    sdk_error: str | None = None
```

In the `invoke()` method, when constructing the final `InvocationResult`, add the field:

```python
        result = InvocationResult(
            text="\n".join(text_chunks),
            cost_usd=computed_cost_usd,
            computed_cost_usd=computed_cost_usd,
            actual_cost_usd=actual_cost_usd,
            usage=usage,
            auth_mode=self.auth_mode,
            config_isolation=self.config_isolation,  # NEW
            tool_calls=tool_calls,
            raw_messages=raw,
        )
```

- [ ] **Step 4: Run test to verify it passes**

Run: `pytest tests/test_invoker.py::TestInvocationResultIsolation -v`
Expected: 2 passing.

- [ ] **Step 5: Run full suite**

Run: `pytest -q`
Expected: same set of passing tests as before; no new regressions.

- [ ] **Step 6: Commit**

```bash
git add producer/invoker.py tests/test_invoker.py
git commit -m "feat(invoker): InvocationResult.config_isolation propagates the mode"
```

---

## Task 6: Ledger migration + Task field + complete_task

**Files:**
- Modify: `producer/ledger.py`
- Modify: `tests/test_ledger.py`

- [ ] **Step 1: Write the failing tests**

Add to `tests/test_ledger.py`:

```python
class TestConfigIsolationColumn:
    def test_migration_adds_column(self, tmp_path):
        from producer.ledger import LedgerClient
        db = tmp_path / "ledger.db"
        ledger = LedgerClient(db_path=db)
        cols = {
            row["name"]
            for row in ledger.conn.execute("PRAGMA table_info(tasks)")
        }
        assert "config_isolation" in cols
        ledger.close()

    def test_migration_idempotent_across_constructions(self, tmp_path):
        from producer.ledger import LedgerClient
        db = tmp_path / "ledger.db"
        LedgerClient(db_path=db).close()
        # Second construction should be a no-op, not fail.
        ledger = LedgerClient(db_path=db)
        cols = {
            row["name"]
            for row in ledger.conn.execute("PRAGMA table_info(tasks)")
        }
        assert "config_isolation" in cols
        ledger.close()

    def test_complete_task_persists_config_isolation(self, tmp_path):
        from producer.ledger import LedgerClient
        db = tmp_path / "ledger.db"
        ledger = LedgerClient(db_path=db)
        tid = ledger.insert_task(
            agent_owner="echo", title="t", description="d"
        )
        ledger.claim_task(tid, agent_owner="echo")
        ledger.complete_task(
            tid,
            cost_usd=0.001,
            actual_cost_usd=None,
            config_isolation="inherit",
        )
        task = ledger.get_task(tid)
        assert task.config_isolation == "inherit"
        ledger.close()

    def test_legacy_rows_have_null_config_isolation(self, tmp_path):
        from producer.ledger import LedgerClient
        db = tmp_path / "ledger.db"
        ledger = LedgerClient(db_path=db)
        tid = ledger.insert_task(
            agent_owner="echo", title="t", description="d"
        )
        # Don't complete it — config_isolation is on the row but NULL.
        task = ledger.get_task(tid)
        assert task.config_isolation is None
        ledger.close()
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `pytest tests/test_ledger.py::TestConfigIsolationColumn -v`
Expected: 4 failures (column not present, `Task.config_isolation` doesn't exist).

- [ ] **Step 3: Add the migration**

In `producer/ledger.py`, in `_apply_migrations`, after the `actual_cost_usd` block, add:

```python
            if "config_isolation" not in cols:
                self.conn.execute(
                    "ALTER TABLE tasks ADD COLUMN config_isolation TEXT"
                )
```

- [ ] **Step 4: Add the field to `Task` dataclass**

In `producer/ledger.py`, add to `Task`:

```python
@dataclass
class Task:
    # ... existing fields ...
    cost_usd: float
    actual_cost_usd: float | None
    config_isolation: str | None  # NEW: 'isolated' | 'inherit' | None for legacy rows
```

Update `Task.from_row`:

```python
            actual_cost_usd=row["actual_cost_usd"],
            config_isolation=row["config_isolation"],  # NEW
```

- [ ] **Step 5: Update `complete_task` signature + SQL**

```python
    def complete_task(
        self,
        task_id: str,
        *,
        output_refs: list[str] | None = None,
        cost_usd: float = 0.0,
        actual_cost_usd: float | None = None,
        config_isolation: str | None = None,  # NEW
    ) -> None:
        with self.transaction():
            self.conn.execute(
                "UPDATE tasks SET status='done', finished_at=?, output_refs=?, "
                "cost_usd=?, actual_cost_usd=?, config_isolation=? "
                "WHERE id=? AND status='in_progress'",
                (
                    utc_iso_now(),
                    json.dumps(output_refs or []),
                    cost_usd,
                    actual_cost_usd,
                    config_isolation,
                    task_id,
                ),
            )
```

- [ ] **Step 6: Run tests to verify they pass**

Run: `pytest tests/test_ledger.py::TestConfigIsolationColumn -v`
Expected: 4 passing.

- [ ] **Step 7: Run full suite**

Run: `pytest -q`
Expected: same passing set as before; no regressions in any existing ledger or smoke tests.

- [ ] **Step 8: Commit**

```bash
git add producer/ledger.py tests/test_ledger.py
git commit -m "feat(ledger): config_isolation column + Task field + complete_task kw"
```

---

## Task 7: Updated error message in `_setup_subscription_auth`

**Files:**
- Modify: `producer/invoker.py`

- [ ] **Step 1: Run the previously-failing test from Task 3**

Run: `pytest tests/test_invoker.py::TestInvokerInheritMode::test_explicit_isolated_with_no_creds_still_raises -v`
Expected: failure — current message lacks `auth.mode: inherit` and `PRODUCER_AUTH_MODE=inherit` strings.

- [ ] **Step 2: Update the error message**

In `producer/invoker.py`, in `_setup_subscription_auth`, replace the `RuntimeError(...)` block:

```python
        if not src.exists():
            raise RuntimeError(
                f"no API key set and no local Claude Code credentials at {src}:\n"
                "  • set ANTHROPIC_API_KEY (any environment), or\n"
                "  • run `claude login` to create the credentials file (legacy auth), or\n"
                "  • set auth.mode: inherit in producer.yaml — or PRODUCER_AUTH_MODE=inherit\n"
                "    — to use Claude Code's host config (OAuth/Keychain auth)"
            )
```

- [ ] **Step 3: Run the test to confirm pass**

Run: `pytest tests/test_invoker.py::TestInvokerInheritMode::test_explicit_isolated_with_no_creds_still_raises -v`
Expected: passing.

- [ ] **Step 4: Run full suite**

Run: `pytest -q`
Expected: all tests pass.

- [ ] **Step 5: Commit**

```bash
git add producer/invoker.py
git commit -m "feat(invoker): error message lists inherit-mode escape hatch"
```

---

## Task 8: Dispatch startup banner

**Files:**
- Modify: `producer/dispatch.py`
- Modify: `tests/test_dispatch.py`

- [ ] **Step 1: Write the failing test**

Add to `tests/test_dispatch.py`:

```python
class TestStartupBanner:
    """Producer logs a one-line banner showing auth+isolation mode at boot."""

    async def test_run_once_logs_banner(self, tmp_path, caplog):
        import logging
        from producer import (
            KillSwitchWatcher, LedgerClient, Producer, load_config,
        )
        # Reuse the smoke-test echo project builder for minimal config.
        from tests.test_smoke_echo_agent import _build_echo_project, StubEchoInvoker

        cfg_path = _build_echo_project(tmp_path)
        cfg = load_config(cfg_path)
        ledger = LedgerClient(db_path=cfg.ledger_db)
        invoker = StubEchoInvoker()
        # Simulate a real invoker's mode reporting via duck-typed attrs.
        invoker.auth_mode = "subscription"
        invoker.config_isolation = "inherit"

        producer = Producer(
            config=cfg, ledger=ledger, invoker=invoker,
            kill_switch=KillSwitchWatcher(path=cfg.kill_switch),
        )

        caplog.set_level(logging.INFO, logger="producer.dispatch")
        await producer.run_once()
        ledger.close()

        banner_lines = [
            r.message for r in caplog.records
            if "auth=" in r.message and "isolation=" in r.message
        ]
        assert len(banner_lines) >= 1, "expected a startup banner"
        assert "auth=subscription" in banner_lines[0]
        assert "isolation=inherit" in banner_lines[0]
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/test_dispatch.py::TestStartupBanner -v`
Expected: failure — no banner logged.

- [ ] **Step 3: Implement the banner**

In `producer/dispatch.py`, add a private method to `Producer`:

```python
    def _log_startup_banner(self) -> None:
        """One-line banner showing auth + isolation mode."""
        auth_mode = getattr(self.invoker, "auth_mode", "unknown")
        isolation = getattr(self.invoker, "config_isolation", "unknown")
        suffix = ""
        if isolation == "inherit":
            suffix = " (host ~/.claude inherited; bypassPermissions)"
        logger.info("auth=%s, isolation=%s%s", auth_mode, isolation, suffix)
```

Call it from both `run` and `run_once`. In `run`, after `self._check_pricing_staleness()`:

```python
        self._log_startup_banner()
```

In `run_once`, after `self._check_pricing_staleness()`:

```python
        self._log_startup_banner()
```

- [ ] **Step 4: Run test to verify it passes**

Run: `pytest tests/test_dispatch.py::TestStartupBanner -v`
Expected: passing.

- [ ] **Step 5: Run full suite**

Run: `pytest -q`
Expected: all tests pass.

- [ ] **Step 6: Commit**

```bash
git add producer/dispatch.py tests/test_dispatch.py
git commit -m "feat(dispatch): startup banner — auth=… isolation=…"
```

---

## Task 9: handle_completion passes config_isolation through

**Files:**
- Modify: `producer/dispatch.py`
- Modify: `tests/test_dispatch.py`

- [ ] **Step 1: Write the failing test**

Add to `tests/test_dispatch.py`:

```python
class TestCompletionConfigIsolation:
    """handle_completion persists config_isolation and writes it to audit."""

    async def test_config_isolation_in_audit_event(self, tmp_path):
        import json
        from producer import (
            InvocationResult, KillSwitchWatcher, LedgerClient, Producer, load_config,
        )
        from tests.test_smoke_echo_agent import _build_echo_project

        cfg_path = _build_echo_project(tmp_path)
        cfg = load_config(cfg_path)
        ledger = LedgerClient(db_path=cfg.ledger_db)

        class CapturingInvoker:
            auth_mode = "subscription"
            config_isolation = "inherit"
            calls: list = []

            async def invoke(self, agent_role, prompt, **kwargs):
                self.calls.append((agent_role, prompt))
                return InvocationResult(
                    text="ok",
                    cost_usd=0.001,
                    computed_cost_usd=0.001,
                    auth_mode="subscription",
                    config_isolation="inherit",
                )

        ledger.insert_task(agent_owner="echo", title="t", description="d")
        producer = Producer(
            config=cfg, ledger=ledger, invoker=CapturingInvoker(),
            kill_switch=KillSwitchWatcher(path=cfg.kill_switch),
        )
        await producer.run_once()

        rows = list(ledger.conn.execute(
            "SELECT detail FROM audit_log WHERE action='task_completed'"
        ))
        assert len(rows) == 1
        payload = json.loads(rows[0]["detail"])
        assert payload["config_isolation"] == "inherit"

        # Also assert it landed on the task row.
        done = ledger.conn.execute(
            "SELECT config_isolation FROM tasks WHERE status='done'"
        ).fetchone()
        assert done["config_isolation"] == "inherit"

        ledger.close()
```

- [ ] **Step 2: Run test to verify it fails**

Run: `pytest tests/test_dispatch.py::TestCompletionConfigIsolation -v`
Expected: failure — `config_isolation` missing from audit payload and task row.

- [ ] **Step 3: Implement**

In `producer/dispatch.py`, modify `handle_completion`:

```python
    def handle_completion(self, task: Task, result: InvocationResult) -> None:
        """Mark the task done, persist per-task cost, and audit the result."""
        output_refs = self._extract_output_refs(result)
        self.ledger.complete_task(
            task.id,
            output_refs=output_refs,
            cost_usd=result.computed_cost_usd,
            actual_cost_usd=result.actual_cost_usd,
            config_isolation=result.config_isolation,  # NEW
        )
        self.audit.event(
            "task_completed",
            {
                "task_id": task.id,
                "agent_owner": task.agent_owner,
                "computed_cost_usd": result.computed_cost_usd,
                "actual_cost_usd": result.actual_cost_usd,
                "auth_mode": result.auth_mode,
                "config_isolation": result.config_isolation,  # NEW
                "output_refs": output_refs,
                "tool_calls": [tc.get("name") for tc in result.tool_calls],
            },
            task_id=task.id,
            cost_usd=result.computed_cost_usd,
        )
        # ... existing logger.info ...
```

- [ ] **Step 4: Run test to verify it passes**

Run: `pytest tests/test_dispatch.py::TestCompletionConfigIsolation -v`
Expected: passing.

- [ ] **Step 5: Run full suite**

Run: `pytest -q`
Expected: all tests pass.

- [ ] **Step 6: Commit**

```bash
git add producer/dispatch.py tests/test_dispatch.py
git commit -m "feat(dispatch): persist config_isolation on task row + audit event"
```

---

## Task 10: ClaudeAgentInvoker accepts AuthConfig + dispatch wires it through

**Files:**
- Modify: `producer/dispatch.py` (look for where the invoker is constructed in production code path)
- Modify: `producer/cli.py` (where Producer is wired up via load_config)
- Verify: no test changes needed — covered by Task 3 tests through the `auth_config` parameter

- [ ] **Step 1: Update `producer/cli.py:159`**

The current line reads:

```python
    invoker = ClaudeAgentInvoker(cwd=cfg.project_root)
```

Change it to:

```python
    invoker = ClaudeAgentInvoker(cwd=cfg.project_root, auth_config=cfg.auth)
```

- [ ] **Step 2: Verify `producer/pricing_updater.py:68` is correct as-is**

The pricing updater constructs an invoker without a `cfg` available:

```python
    invoker = ClaudeAgentInvoker(cwd=cwd)
```

Leave this untouched — it defaults to `auth_config=None`, which means `auto` mode (detect at startup). That's the right behavior for a one-off `producer pricing update` command.

- [ ] **Step 3: Add a test that load_config → ClaudeAgentInvoker propagates the mode**

Add to `tests/test_invoker.py`:

```python
class TestAuthConfigPropagation:
    def test_auth_config_inherit_propagates(self, tmp_path, monkeypatch):
        from producer.config import AuthConfig
        from producer.invoker import ClaudeAgentInvoker
        monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")
        monkeypatch.delenv("PRODUCER_AUTH_MODE", raising=False)
        inv = ClaudeAgentInvoker(
            cwd=tmp_path, auth_config=AuthConfig(mode="inherit")
        )
        assert inv.config_isolation == "inherit"

    def test_env_var_overrides_auth_config(self, tmp_path, monkeypatch):
        from producer.config import AuthConfig
        from producer.invoker import ClaudeAgentInvoker
        monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")
        monkeypatch.setenv("PRODUCER_AUTH_MODE", "isolated")
        inv = ClaudeAgentInvoker(
            cwd=tmp_path, auth_config=AuthConfig(mode="inherit")
        )
        assert inv.config_isolation == "isolated"
```

- [ ] **Step 4: Run tests**

Run: `pytest tests/test_invoker.py::TestAuthConfigPropagation -v`
Expected: 2 passing.

- [ ] **Step 5: Run full suite**

Run: `pytest -q`
Expected: all tests pass.

- [ ] **Step 6: Commit**

```bash
git add producer/cli.py tests/test_invoker.py
git commit -m "feat(cli): wire cfg.auth → ClaudeAgentInvoker(auth_config=…)"
```

---

## Task 11: Docs, templates, public API re-exports, version bump

**Files:**
- Modify: `producer/__init__.py`
- Modify: `producer/schema.sql`
- Modify: `templates/producer.yaml.example`
- Modify: `README.md`
- Modify: `CLAUDE.md`
- Modify: `pyproject.toml`

- [ ] **Step 1: Re-export `AuthConfig` and bump version**

In `producer/__init__.py`, add `AuthConfig` to imports and `__all__`:

```python
from producer.config import (
    AuthConfig,
    BudgetConfig,
    NotificationsConfig,
    ProducerConfig,
    RoleConfig,
    load_config,
)

__all__ = [
    # ... existing entries ...
    "AuthConfig",
    # ... rest ...
]
```

In `pyproject.toml`, bump `version = "0.2.0"`.

- [ ] **Step 2: Update schema.sql header**

In `producer/schema.sql`, in the documentation header block, add a bullet:

```
-- config_isolation TEXT — 'isolated' (default; CLAUDE_CONFIG_DIR pinned to
--   <cwd>/agent-state/.claude) or 'inherit' (host ~/.claude used; required
--   for OAuth/Keychain auth). NULL for rows written before the migration.
```

- [ ] **Step 3: Update producer.yaml.example template**

In `templates/producer.yaml.example`, add a commented `auth:` block — pick a sensible location (near `notifications:` is fine):

```yaml
# Auth + config-isolation mode for the dispatched Claude agent.
#
# auto      : (default) detect at startup. ANTHROPIC_API_KEY → isolated;
#             ~/.claude/.credentials.json → isolated; else inherit + WARN.
# isolated  : force CLAUDE_CONFIG_DIR override. Errors with no creds.
# inherit   : skip override; subprocess inherits host ~/.claude. Required
#             for OAuth/Keychain auth (the default Claude Code login flow
#             on macOS). Plugins/hooks/skills load — bypassPermissions
#             is set automatically.
#
# PRODUCER_AUTH_MODE env var overrides this for one-off runs.
auth:
  mode: auto
```

- [ ] **Step 4: Update README**

In `README.md`, find the "Subscription auth" subsection (added in PR #1). Add a new "Inherit mode" subsection after it:

```markdown
#### Inherit mode (OAuth / Keychain auth)

If you authed Claude Code via `claude login` on a recent macOS install, your
credentials live in the Keychain — not in `~/.claude/.credentials.json`. The
isolated subscription-auth fallback can't see them. Use **inherit mode**:

```yaml
auth:
  mode: inherit   # or set PRODUCER_AUTH_MODE=inherit
```

In inherit mode the dispatched agent inherits your host `~/.claude` config
directly. Plugins, hooks, and skills you have installed will load. To prevent
prompt-driven hangs, claude-producer automatically uses `bypassPermissions`
and sets `GIT_TERMINAL_PROMPT=0`.

If you leave `auth.mode: auto` (the default), claude-producer detects this
case and falls back to inherit mode automatically with a warning.
```

- [ ] **Step 5: Update CLAUDE.md**

In `CLAUDE.md`, find the "CLAUDE_CONFIG_DIR isolation" invariant. Amend it to:

```
- **`CLAUDE_CONFIG_DIR` isolation (isolated mode only).** In `isolated`
  mode (the default), dispatched subprocesses point at `<cwd>/agent-state/.claude`
  to keep the user's `~/.claude` plugins/hooks/skills out of headless runs.
  In `inherit` mode (opt-in via `auth.mode: inherit` or auto-detected when
  the user is on OAuth/Keychain auth), the override is dropped and the host
  config is inherited; `permission_mode='bypassPermissions'` and
  `GIT_TERMINAL_PROMPT=0` prevent the prompt-driven hangs that motivated
  isolation. See `docs/superpowers/specs/2026-05-06-auth-inherit-mode-design.md`.
```

Find the "Auth fallback is selective" invariant and update it:

```
- **Auth fallback has two modes.** `isolated` mode symlinks ONLY
  `~/.claude/.credentials.json` (the legacy subscription path) into the
  isolated `CLAUDE_CONFIG_DIR`. `inherit` mode skips the symlink and lets
  the subprocess use the host `~/.claude` directly — required for OAuth
  auth (no on-disk credentials file). Auto-detect picks `inherit` when
  neither API key nor `.credentials.json` is present, with a WARN log.
```

- [ ] **Step 6: Run full suite**

Run: `pytest -q`
Expected: all tests pass.

- [ ] **Step 7: Commit**

```bash
git add producer/__init__.py producer/schema.sql templates/producer.yaml.example \
  README.md CLAUDE.md pyproject.toml
git commit -m "docs: inherit mode + 0.2.0 version bump"
```

---

## Final review checklist

After all 11 tasks land:

- [ ] **Run the full suite once more.** `pytest -q` — expect 149 baseline + ~24 new tests passing.
- [ ] **Verify version bump.** `grep version pyproject.toml` shows `0.2.0`.
- [ ] **Verify public API export.** `python -c "from producer import AuthConfig; print(AuthConfig)"` works.
- [ ] **Check that the spec is satisfied by skimming back through `docs/superpowers/specs/2026-05-06-auth-inherit-mode-design.md`** and confirming each "behavior matrix" / "edge cases" row is covered by a test.

If all pass, dispatch a final code-reviewer subagent over the diff vs `main`. Then use `superpowers:finishing-a-development-branch` to complete the work.
