# Subscription Auth + Token-Based Cost Tracking — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Allow the Producer to use a local Claude Code subscription when no `ANTHROPIC_API_KEY` is set, and track cost in both modes by computing it from token counts × a maintainable pricing table.

**Architecture:** A new `producer/pricing` module owns rate data (`pricing.json`) and a `compute_cost(model, usage) → float` helper. The invoker detects auth mode (API vs subscription), extracts token usage from SDK messages, and returns both `computed_cost_usd` (always) and `actual_cost_usd` (None under subscription). The dispatcher writes both to a new `tasks.actual_cost_usd` column (alongside the existing — but currently un-written — `tasks.cost_usd`). A `producer pricing update` CLI subcommand refreshes the table; `producer run` startup warns when it's >90 days stale.

**Tech Stack:** Python 3.11+, `claude-agent-sdk`, SQLite (WAL), `pytest` + `pytest-asyncio`, `pyyaml`, `httpx`. No new dependencies.

**Spec:** `docs/superpowers/specs/2026-05-06-subscription-auth-and-cost-tracking-design.md`

---

## File map

| File | Status | Responsibility |
|---|---|---|
| `producer/pricing.py` | **Create** | `load_pricing`, `compute_cost`, `is_stale`, `STALENESS_DAYS` |
| `producer/pricing.json` | **Create** | Bundled rate table; `last_updated`, `source_url`, `models` |
| `producer/pricing_updater.py` | **Create** | `async update_pricing(*, dry_run, runner)` — fetch + validate + atomic write |
| `producer/invoker.py` | **Modify** | Auth detection, token extraction, dual-cost result |
| `producer/dispatch.py` | **Modify** | Write both costs into `tasks` row; staleness check at startup |
| `producer/ledger.py` | **Modify** | `_apply_migrations` adds `actual_cost_usd`; `complete_task` writes per-task cost; `Task` dataclass gains `actual_cost_usd` |
| `producer/morning_report.py` | **Modify** | Staleness banner + drift section |
| `producer/cli.py` | **Modify** | `pricing update [--dry-run]` subcommand |
| `producer/schema.sql` | **Modify** | Header comment about `cost_usd` semantics |
| `pyproject.toml` | **Modify** | Force-include `producer/pricing.json` in wheel |
| `tests/test_pricing.py` | **Create** | Unit tests for the pricing module |
| `tests/test_pricing_updater.py` | **Create** | Updater validation, dry-run, atomic write |
| `tests/test_invoker.py` | **Modify** | Auth fallback + token extraction tests |
| `tests/test_ledger.py` | **Modify** | Migration test + per-task cost write |
| `tests/test_dispatch.py` | **Modify** | Dual-cost recording end-to-end |
| `tests/test_morning_report.py` | **Modify** | Drift section + staleness banner |
| `tests/test_cli.py` | **Modify** | Argparse routing for `pricing update` |
| `README.md` | **Modify** | New "Subscription auth" subsection |
| `CLAUDE.md` | **Modify** | Auth-fallback symlink invariant |

---

## Pre-flight

Before starting Task 1, run the full suite once and record the baseline pass count. Every task ends with the suite green.

```bash
pytest -v 2>&1 | tail -5
```
Expected: all tests pass (currently 93). If any fail, stop and fix before proceeding.

---

## Task 1: Pricing data file (`pricing.json`)

**Files:**
- Create: `producer/pricing.json`

**Background:** Anthropic publishes per-model rates at `https://docs.anthropic.com/en/docs/about-claude/pricing`. The seed values below are the best-known rates as of late-2025/early-2026 for the Claude 4.x family. **Before committing**, open the live pricing page and verify each rate. If any differ, edit the JSON to match the live page and update `last_updated` to today's date.

- [ ] **Step 1: Create the file**

```bash
cat > producer/pricing.json <<'EOF'
{
  "last_updated": "2026-05-06",
  "source_url": "https://docs.anthropic.com/en/docs/about-claude/pricing",
  "currency": "USD",
  "models": {
    "claude-opus-4-7": {
      "input_per_mtok_usd": 15.00,
      "output_per_mtok_usd": 75.00,
      "cache_creation_per_mtok_usd": 18.75,
      "cache_read_per_mtok_usd": 1.50
    },
    "claude-sonnet-4-6": {
      "input_per_mtok_usd": 3.00,
      "output_per_mtok_usd": 15.00,
      "cache_creation_per_mtok_usd": 3.75,
      "cache_read_per_mtok_usd": 0.30
    },
    "claude-haiku-4-5": {
      "input_per_mtok_usd": 1.00,
      "output_per_mtok_usd": 5.00,
      "cache_creation_per_mtok_usd": 1.25,
      "cache_read_per_mtok_usd": 0.10
    }
  }
}
EOF
```

- [ ] **Step 2: Verify rates against the live pricing page**

Open `https://docs.anthropic.com/en/docs/about-claude/pricing` in a browser. For each of the three models above, confirm:
- input rate
- output rate
- cache creation rate (sometimes labeled "prompt caching writes" or "cache write")
- cache read rate (sometimes labeled "prompt caching reads" or "cache hit")

If any value differs, edit `producer/pricing.json` and set `last_updated` to today's UTC date in `YYYY-MM-DD` form.

- [ ] **Step 3: Validate JSON parses**

```bash
python3 -c "import json, pathlib; json.loads(pathlib.Path('producer/pricing.json').read_text()); print('ok')"
```
Expected: `ok`.

- [ ] **Step 4: Commit**

```bash
git add producer/pricing.json
git commit -m "feat(pricing): bundle initial pricing.json with current Claude 4.x rates"
```

---

## Task 2: Pricing module (`producer/pricing.py`)

**Files:**
- Create: `producer/pricing.py`
- Test: `tests/test_pricing.py`

- [ ] **Step 1: Write the failing tests**

Create `tests/test_pricing.py`:

```python
"""Tests for producer.pricing."""

from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

from producer import pricing


def test_load_pricing_returns_dict_with_expected_keys():
    data = pricing.load_pricing()
    assert "last_updated" in data
    assert "source_url" in data
    assert "currency" in data
    assert "models" in data
    assert isinstance(data["models"], dict)
    assert len(data["models"]) >= 1


def test_compute_cost_known_model_input_only():
    # 1M input tokens of opus at $15/Mtok = $15
    cost = pricing.compute_cost(
        "claude-opus-4-7",
        {"input_tokens": 1_000_000, "output_tokens": 0,
         "cache_creation_input_tokens": 0, "cache_read_input_tokens": 0},
    )
    assert cost == pytest.approx(15.00, abs=1e-6)


def test_compute_cost_known_model_all_token_types():
    # Use simple 1k of each so the math is checkable by hand
    cost = pricing.compute_cost(
        "claude-opus-4-7",
        {
            "input_tokens": 1000,
            "output_tokens": 1000,
            "cache_creation_input_tokens": 1000,
            "cache_read_input_tokens": 1000,
        },
    )
    # 1000/1e6 × ($15 + $75 + $18.75 + $1.50) = 0.110.25 × 0.001 = 0.11025
    assert cost == pytest.approx(0.11025, abs=1e-6)


def test_compute_cost_missing_model_returns_zero_and_warns(caplog):
    with caplog.at_level("WARNING"):
        cost = pricing.compute_cost(
            "claude-fake-99",
            {"input_tokens": 1_000_000, "output_tokens": 0,
             "cache_creation_input_tokens": 0, "cache_read_input_tokens": 0},
        )
    assert cost == 0.0
    assert any("no pricing entry" in rec.message for rec in caplog.records)


def test_compute_cost_handles_missing_token_keys():
    # If usage dict only has a subset of keys, missing ones are treated as 0
    cost = pricing.compute_cost("claude-opus-4-7", {"input_tokens": 1_000_000})
    assert cost == pytest.approx(15.00, abs=1e-6)


def test_is_stale_under_threshold(monkeypatch, tmp_path):
    pricing_file = tmp_path / "pricing.json"
    pricing_file.write_text(json.dumps({
        "last_updated": "2026-04-01",
        "source_url": "x",
        "currency": "USD",
        "models": {},
    }))
    monkeypatch.setattr(pricing, "PRICING_PATH", pricing_file)
    pricing._cache_clear()
    now = datetime(2026, 5, 1, tzinfo=timezone.utc)  # 30 days later
    stale, age = pricing.is_stale(now=now)
    assert stale is False
    assert age == 30


def test_is_stale_over_threshold(monkeypatch, tmp_path):
    pricing_file = tmp_path / "pricing.json"
    pricing_file.write_text(json.dumps({
        "last_updated": "2026-01-01",
        "source_url": "x",
        "currency": "USD",
        "models": {},
    }))
    monkeypatch.setattr(pricing, "PRICING_PATH", pricing_file)
    pricing._cache_clear()
    now = datetime(2026, 5, 1, tzinfo=timezone.utc)  # 120 days later
    stale, age = pricing.is_stale(now=now)
    assert stale is True
    assert age == 120


def test_load_handles_corrupt_json(monkeypatch, tmp_path):
    pricing_file = tmp_path / "pricing.json"
    pricing_file.write_text("{not valid json")
    monkeypatch.setattr(pricing, "PRICING_PATH", pricing_file)
    pricing._cache_clear()
    with pytest.raises(pricing.PricingError):
        pricing.load_pricing()
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
pytest tests/test_pricing.py -v
```
Expected: FAIL with `ImportError: cannot import name 'pricing'` or similar.

- [ ] **Step 3: Implement the module**

Create `producer/pricing.py`:

```python
"""Pricing table loader, cost computation, and staleness check.

The pricing data lives in ``producer/pricing.json`` (bundled in the wheel via
hatch force-include, same pattern as ``schema.sql``). Refresh it with
``producer pricing update``.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

logger = logging.getLogger("producer.pricing")

#: Threshold beyond which the pricing table is considered stale.
STALENESS_DAYS = 90

#: Path to the bundled pricing data. Module-level so tests can monkeypatch.
PRICING_PATH = Path(__file__).parent / "pricing.json"


class PricingError(RuntimeError):
    """Raised when the pricing table is missing, malformed, or unusable."""


_cache: tuple[float, dict[str, Any]] | None = None  # (mtime, parsed-json)


def _cache_clear() -> None:
    """Reset the in-memory cache. Used by tests after monkeypatching PRICING_PATH."""
    global _cache
    _cache = None


def load_pricing() -> dict[str, Any]:
    """Read and parse ``pricing.json``.

    Caches by file mtime so repeated calls don't re-parse. Raises
    :class:`PricingError` on missing file or invalid JSON.
    """
    global _cache
    path = PRICING_PATH
    if not path.exists():
        raise PricingError(f"pricing.json missing at {path}")
    mtime = path.stat().st_mtime
    if _cache is not None and _cache[0] == mtime:
        return _cache[1]
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise PricingError(f"pricing.json is malformed: {exc}") from exc
    _cache = (mtime, data)
    return data


def compute_cost(model: str, usage: dict[str, int]) -> float:
    """Compute USD cost from token counts × per-MTok rates.

    Args:
        model: Model identifier (e.g. ``"claude-opus-4-7"``).
        usage: Dict with any subset of these keys; missing keys are treated
            as 0:
            ``input_tokens``, ``output_tokens``,
            ``cache_creation_input_tokens``, ``cache_read_input_tokens``.

    Returns:
        Cost in USD. Returns 0.0 (and logs a warning) when ``model`` has no
        entry in the table — the dispatch loop must not break just because
        a brand-new model was used before the table was refreshed.
    """
    rates = load_pricing()["models"].get(model)
    if rates is None:
        logger.warning(
            "no pricing entry for model=%s; computed_cost=0 — run "
            "`producer pricing update`",
            model,
        )
        return 0.0
    input_tokens = usage.get("input_tokens", 0)
    output_tokens = usage.get("output_tokens", 0)
    cache_creation = usage.get("cache_creation_input_tokens", 0)
    cache_read = usage.get("cache_read_input_tokens", 0)
    return (
        input_tokens * rates["input_per_mtok_usd"]
        + output_tokens * rates["output_per_mtok_usd"]
        + cache_creation * rates["cache_creation_per_mtok_usd"]
        + cache_read * rates["cache_read_per_mtok_usd"]
    ) / 1_000_000


def is_stale(now: datetime | None = None) -> tuple[bool, int]:
    """Return ``(is_stale, age_days)``.

    ``age_days`` is the integer number of UTC days between the table's
    ``last_updated`` and ``now`` (defaults to current UTC time).
    """
    data = load_pricing()
    last = datetime.strptime(data["last_updated"], "%Y-%m-%d").replace(
        tzinfo=timezone.utc
    )
    now = now or datetime.now(timezone.utc)
    age_days = (now - last).days
    return age_days > STALENESS_DAYS, age_days
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
pytest tests/test_pricing.py -v
```
Expected: all PASS.

- [ ] **Step 5: Commit**

```bash
git add producer/pricing.py tests/test_pricing.py
git commit -m "feat(pricing): add pricing.py — load/compute_cost/is_stale"
```

---

## Task 3: Bundle `pricing.json` in the wheel

**Files:**
- Modify: `pyproject.toml`

- [ ] **Step 1: Inspect the current force-include block**

```bash
grep -A2 'force-include' pyproject.toml
```
Expected output:

```
[tool.hatch.build.targets.wheel.force-include]
"producer/schema.sql" = "producer/schema.sql"
```

- [ ] **Step 2: Add the pricing.json line**

Edit `pyproject.toml` to extend the block to:

```toml
[tool.hatch.build.targets.wheel.force-include]
"producer/schema.sql" = "producer/schema.sql"
"producer/pricing.json" = "producer/pricing.json"
```

- [ ] **Step 3: Verify a wheel build includes it**

```bash
pip install build >/dev/null 2>&1 || true
python -m build --wheel --outdir /tmp/wheelcheck . 2>&1 | tail -3
unzip -l /tmp/wheelcheck/claude_producer-0.1.0-py3-none-any.whl | grep -E '(schema\.sql|pricing\.json)'
```
Expected: both `producer/schema.sql` and `producer/pricing.json` listed.

- [ ] **Step 4: Commit**

```bash
git add pyproject.toml
git commit -m "build: include pricing.json in the wheel via hatch force-include"
```

---

## Task 4: Schema migration + Task dataclass update

**Files:**
- Modify: `producer/ledger.py`
- Modify: `producer/schema.sql` (header comment only — column added at runtime via migration, not in CREATE TABLE)
- Test: `tests/test_ledger.py`

**Background:** SQLite `ALTER TABLE` cannot add a `NOT NULL` column without a default to an existing table. We add `actual_cost_usd` as nullable. We also fix a latent bug: `tasks.cost_usd` is currently never written by `complete_task` — only the `budget` and `audit_log` tables receive cost data, so `morning_report` reads `$0.00` for every shipped task. As part of this work, `complete_task` will accept and write a `cost_usd` argument (and the new `actual_cost_usd`).

- [ ] **Step 1: Write the failing migration test**

Append to `tests/test_ledger.py` (do not delete existing tests):

```python
def test_migration_adds_actual_cost_usd_column_to_existing_ledger(tmp_path):
    """An older ledger without actual_cost_usd gets the column added on open."""
    import sqlite3
    db = tmp_path / "old.db"
    # Build a minimal "old" tasks table missing the new column
    conn = sqlite3.connect(db)
    conn.executescript("""
        CREATE TABLE tasks (
            id TEXT PRIMARY KEY,
            agent_owner TEXT NOT NULL,
            status TEXT NOT NULL,
            title TEXT NOT NULL,
            description TEXT NOT NULL,
            parent_task_id TEXT,
            dependencies TEXT DEFAULT '[]',
            payload TEXT DEFAULT '{}',
            output_refs TEXT DEFAULT '[]',
            priority INTEGER NOT NULL DEFAULT 3,
            sprint_id TEXT,
            created_at TEXT NOT NULL,
            started_at TEXT,
            finished_at TEXT,
            retry_count INTEGER NOT NULL DEFAULT 0,
            escalation_reason TEXT,
            cost_usd REAL NOT NULL DEFAULT 0
        );
        INSERT INTO tasks (id, agent_owner, status, title, description, created_at)
        VALUES ('T1', 'code', 'done', 'old task', 'desc', '2026-01-01T00:00:00Z');
    """)
    conn.commit()
    conn.close()

    # Opening via LedgerClient must run the full schema + migrations
    from producer.ledger import LedgerClient
    client = LedgerClient(db_path=db)
    cols = {row["name"] for row in client.conn.execute("PRAGMA table_info(tasks)")}
    assert "actual_cost_usd" in cols
    # Existing row keeps its data and the new column is NULL
    row = client.conn.execute("SELECT actual_cost_usd FROM tasks WHERE id='T1'").fetchone()
    assert row["actual_cost_usd"] is None
    client.close()


def test_migration_is_idempotent(tmp_path):
    """Re-opening a migrated ledger does not fail."""
    from producer.ledger import LedgerClient
    db = tmp_path / "mig.db"
    LedgerClient(db_path=db).close()
    LedgerClient(db_path=db).close()  # second open — must not raise


def test_complete_task_writes_cost_columns(tmp_path):
    """complete_task accepts cost_usd + actual_cost_usd and persists both."""
    from producer.ledger import LedgerClient
    client = LedgerClient(db_path=tmp_path / "c.db")
    tid = client.insert_task(agent_owner="code", title="t", description="d")
    client.claim_task(tid, agent_owner="code")
    client.complete_task(tid, output_refs=[], cost_usd=0.42, actual_cost_usd=0.40)
    row = client.conn.execute(
        "SELECT cost_usd, actual_cost_usd FROM tasks WHERE id=?", (tid,)
    ).fetchone()
    assert row["cost_usd"] == pytest.approx(0.42)
    assert row["actual_cost_usd"] == pytest.approx(0.40)
    client.close()


def test_complete_task_actual_cost_can_be_none(tmp_path):
    """Subscription mode: actual_cost_usd is None and persists as NULL."""
    from producer.ledger import LedgerClient
    client = LedgerClient(db_path=tmp_path / "c2.db")
    tid = client.insert_task(agent_owner="code", title="t", description="d")
    client.claim_task(tid, agent_owner="code")
    client.complete_task(tid, output_refs=[], cost_usd=0.42, actual_cost_usd=None)
    row = client.conn.execute(
        "SELECT cost_usd, actual_cost_usd FROM tasks WHERE id=?", (tid,)
    ).fetchone()
    assert row["cost_usd"] == pytest.approx(0.42)
    assert row["actual_cost_usd"] is None
    client.close()
```

Make sure `import pytest` is already at the top of the file; if not, add it.

- [ ] **Step 2: Run tests to verify they fail**

```bash
pytest tests/test_ledger.py -v -k "migration or complete_task_writes or actual_cost_can_be_none"
```
Expected: FAIL on missing column / missing argument.

- [ ] **Step 3: Implement the migration**

Modify `producer/ledger.py`. After `_ensure_schema` (around line 188), add:

```python
    def _apply_migrations(self) -> None:
        """Idempotent ALTER TABLEs to bring older ledgers forward.

        SQLite cannot add NOT NULL columns to existing tables without a
        default, so additive migrations live here rather than in schema.sql.
        """
        with self._lock:
            cols = {
                row["name"]
                for row in self.conn.execute("PRAGMA table_info(tasks)")
            }
            if "actual_cost_usd" not in cols:
                self.conn.execute("ALTER TABLE tasks ADD COLUMN actual_cost_usd REAL")
```

Then change `__init__` to call it:

```python
    def __init__(self, db_path: Path | str) -> None:
        self.db_path = Path(db_path).resolve()
        self._lock = threading.RLock()
        self._conn: sqlite3.Connection | None = None
        self._ensure_schema()
        self._apply_migrations()
```

- [ ] **Step 4: Update `complete_task` to accept and write costs**

Replace the existing `complete_task` method body in `producer/ledger.py` with:

```python
    def complete_task(
        self,
        task_id: str,
        *,
        output_refs: list[str] | None = None,
        cost_usd: float = 0.0,
        actual_cost_usd: float | None = None,
    ) -> None:
        """Mark a task done and record per-task cost.

        ``cost_usd`` is the computed cost (always populated by the dispatcher).
        ``actual_cost_usd`` is the SDK-reported cost — None under subscription
        auth where Anthropic does not surface a per-call dollar figure.
        """
        with self.transaction():
            self.conn.execute(
                "UPDATE tasks SET status='done', finished_at=?, output_refs=?, "
                "cost_usd=?, actual_cost_usd=? "
                "WHERE id=? AND status='in_progress'",
                (
                    utc_iso_now(),
                    json.dumps(output_refs or []),
                    cost_usd,
                    actual_cost_usd,
                    task_id,
                ),
            )
```

- [ ] **Step 5: Update the `Task` dataclass to expose `actual_cost_usd`**

In `producer/ledger.py`, edit the `Task` dataclass (around line 74) to add the new field (after `cost_usd`):

```python
    cost_usd: float
    actual_cost_usd: float | None
```

And update `Task.from_row` (around line 96) to set it:

```python
            cost_usd=row["cost_usd"],
            actual_cost_usd=row["actual_cost_usd"],
        )
```

- [ ] **Step 6: Run the tests**

```bash
pytest tests/test_ledger.py -v
```
Expected: all PASS, including the new tests and all pre-existing tests.

- [ ] **Step 7: Update `schema.sql` header comment about `cost_usd` semantics**

In `producer/schema.sql`, edit the comment block immediately above `CREATE TABLE IF NOT EXISTS tasks` (around line 26) to add a paragraph at the end of the existing block:

```sql
-- ----------------------------------------------------------------------------
-- tasks — the queue and the bus
-- ----------------------------------------------------------------------------
-- Lifecycle:
--   pending ─► in_progress ─► done
--                 ├─► failed (retried up to N)
--                 ├─► escalated (awaiting human; producer or specialist gives up)
--                 └─► killed (kill switch armed mid-flight, or producer cancels)
--
-- Cost columns:
--   cost_usd          — computed from tokens × pricing.json (always populated).
--   actual_cost_usd   — SDK-reported cost (NULL under subscription auth).
--                       Added by _apply_migrations(), not by this CREATE TABLE.
--
-- Producer claims via:
--   ...
```

- [ ] **Step 8: Commit**

```bash
git add producer/ledger.py producer/schema.sql tests/test_ledger.py
git commit -m "feat(ledger): add actual_cost_usd via migration; complete_task writes per-task cost"
```

---

## Task 5: `InvocationResult` shape + invoker auth fallback

**Files:**
- Modify: `producer/invoker.py`
- Test: `tests/test_invoker.py`

- [ ] **Step 1: Write the failing tests**

Append to `tests/test_invoker.py`:

```python
def test_invoker_subscription_auth_symlinks_credentials(tmp_path, monkeypatch):
    """No API key + creds at ~/.claude/.credentials.json → symlink into config_dir."""
    from producer.invoker import ClaudeAgentInvoker
    fake_home = tmp_path / "home"
    (fake_home / ".claude").mkdir(parents=True)
    creds = fake_home / ".claude" / ".credentials.json"
    creds.write_text('{"oauth": "fake"}')
    monkeypatch.setenv("HOME", str(fake_home))
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    monkeypatch.setattr("pathlib.Path.home", lambda: fake_home)

    cwd = tmp_path / "proj"
    cwd.mkdir()
    inv = ClaudeAgentInvoker(cwd=cwd)
    assert inv.auth_mode == "subscription"
    dst = inv.config_dir / ".credentials.json"
    assert dst.is_symlink()
    assert dst.resolve() == creds.resolve()


def test_invoker_subscription_auth_idempotent(tmp_path, monkeypatch):
    """Re-construction with the symlink already present does not error."""
    from producer.invoker import ClaudeAgentInvoker
    fake_home = tmp_path / "home"
    (fake_home / ".claude").mkdir(parents=True)
    creds = fake_home / ".claude" / ".credentials.json"
    creds.write_text('{"oauth": "fake"}')
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    monkeypatch.setattr("pathlib.Path.home", lambda: fake_home)

    cwd = tmp_path / "proj"
    cwd.mkdir()
    ClaudeAgentInvoker(cwd=cwd)
    inv = ClaudeAgentInvoker(cwd=cwd)
    dst = inv.config_dir / ".credentials.json"
    assert dst.is_symlink()
    assert dst.resolve() == creds.resolve()


def test_invoker_fails_when_no_key_and_no_creds(tmp_path, monkeypatch):
    from producer.invoker import ClaudeAgentInvoker
    fake_home = tmp_path / "home"
    fake_home.mkdir()
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    monkeypatch.setattr("pathlib.Path.home", lambda: fake_home)

    cwd = tmp_path / "proj"
    cwd.mkdir()
    with pytest.raises(RuntimeError, match="no API key"):
        ClaudeAgentInvoker(cwd=cwd)


def test_invoker_api_mode_when_key_set(tmp_path, monkeypatch):
    from producer.invoker import ClaudeAgentInvoker
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-test")
    cwd = tmp_path / "proj"
    cwd.mkdir()
    inv = ClaudeAgentInvoker(cwd=cwd)
    assert inv.auth_mode == "api"
    assert not (inv.config_dir / ".credentials.json").exists()
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
pytest tests/test_invoker.py -v -k "subscription_auth or no_key_and_no_creds or api_mode"
```
Expected: FAIL with `AttributeError: ClaudeAgentInvoker has no attribute 'auth_mode'` or similar.

- [ ] **Step 3: Update `InvocationResult`**

In `producer/invoker.py`, replace the `InvocationResult` dataclass with:

```python
from typing import Literal


@dataclass
class InvocationResult:
    """Flat shape for what an agent call returned.

    ``cost_usd`` is an alias for ``computed_cost_usd`` retained so existing
    callers (dispatcher, tests) keep working unchanged. New code should read
    ``computed_cost_usd`` (always populated) and ``actual_cost_usd`` (None
    under subscription auth) explicitly.
    """

    text: str
    cost_usd: float                       # alias of computed_cost_usd
    computed_cost_usd: float = 0.0
    actual_cost_usd: float | None = None
    usage: dict[str, int] = field(default_factory=dict)
    auth_mode: Literal["api", "subscription"] = "api"
    tool_calls: list[dict[str, Any]] = field(default_factory=list)
    raw_messages: list[Any] = field(default_factory=list)
    sdk_error: str | None = None
```

- [ ] **Step 4: Update `__init__` with auth detection + selective symlink**

Replace `ClaudeAgentInvoker.__init__` body with:

```python
    def __init__(
        self,
        *,
        cwd: Path | str,
        api_key: str | None = None,
        config_dir: Path | str | None = None,
        permission_mode: str = "acceptEdits",
    ) -> None:
        self.cwd = Path(cwd).resolve()
        self.config_dir = (
            Path(config_dir).resolve()
            if config_dir is not None
            else (self.cwd / "agent-state" / ".claude").resolve()
        )
        self.config_dir.mkdir(parents=True, exist_ok=True)
        os.environ["CLAUDE_CONFIG_DIR"] = str(self.config_dir)

        resolved_key = api_key or os.environ.get("ANTHROPIC_API_KEY")
        if resolved_key:
            self.auth_mode = "api"
            self.api_key = resolved_key
            os.environ.setdefault("ANTHROPIC_API_KEY", resolved_key)
        else:
            self.auth_mode = "subscription"
            self.api_key = None
            self._setup_subscription_auth()

        self.permission_mode = permission_mode

    def _setup_subscription_auth(self) -> None:
        """Symlink ~/.claude/.credentials.json into the isolated config dir.

        Selective by design: we do NOT bring along plugins, hooks, or skills.
        Those caused the spurious dispatch hangs that motivated isolation in
        the first place.
        """
        src = Path.home() / ".claude" / ".credentials.json"
        if not src.exists():
            raise RuntimeError(
                "no API key set and no local Claude Code credentials at "
                f"{src} — set ANTHROPIC_API_KEY or run `claude login`"
            )
        dst = self.config_dir / ".credentials.json"
        if dst.is_symlink() and dst.resolve() == src.resolve():
            return  # idempotent — already correct
        if dst.exists() or dst.is_symlink():
            dst.unlink()
        dst.symlink_to(src)
```

- [ ] **Step 5: Run tests**

```bash
pytest tests/test_invoker.py -v
```
Expected: all PASS, including pre-existing tests. (If pre-existing tests assumed `RuntimeError` on missing key with no `~/.claude` setup, they should still pass because those tests presumably set the env var themselves; if any need updating, fix them by setting `ANTHROPIC_API_KEY` in the test setup or asserting the new error message.)

- [ ] **Step 6: Commit**

```bash
git add producer/invoker.py tests/test_invoker.py
git commit -m "feat(invoker): subscription-auth fallback via selective credential symlink"
```

---

## Task 6: Token extraction + cost computation in invoker

**Files:**
- Modify: `producer/invoker.py`
- Test: `tests/test_invoker.py`

- [ ] **Step 1: Write the failing tests**

Append to `tests/test_invoker.py`:

```python
@pytest.mark.asyncio
async def test_invoker_extracts_usage_and_computes_cost_api_mode(tmp_path, monkeypatch):
    """Under API auth, both computed_cost_usd and actual_cost_usd are populated."""
    from producer.invoker import ClaudeAgentInvoker

    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-test")

    # Stub claude_agent_sdk: feed messages with a usage dict and total_cost_usd
    class _AssistantMessage:
        def __init__(self, content):
            self.content = content
    class _TextBlock:
        def __init__(self, text):
            self.text = text
    class _ResultMessage:
        def __init__(self, usage, total_cost_usd):
            self.usage = usage
            self.total_cost_usd = total_cost_usd

    async def fake_query(prompt, options):
        yield _AssistantMessage(content=[_TextBlock("hello")])
        yield _ResultMessage(
            usage={
                "input_tokens": 1_000_000,
                "output_tokens": 0,
                "cache_creation_input_tokens": 0,
                "cache_read_input_tokens": 0,
            },
            total_cost_usd=14.95,
        )

    import sys
    fake_sdk = type(sys)("claude_agent_sdk")
    fake_sdk.AssistantMessage = _AssistantMessage
    fake_sdk.TextBlock = _TextBlock
    fake_sdk.ClaudeAgentOptions = lambda **kw: type("Opts", (), kw)()
    fake_sdk.query = fake_query
    monkeypatch.setitem(sys.modules, "claude_agent_sdk", fake_sdk)

    inv = ClaudeAgentInvoker(cwd=tmp_path)
    result = await inv.invoke(
        agent_role="code", prompt="x", model="claude-opus-4-7"
    )
    assert result.usage["input_tokens"] == 1_000_000
    assert result.computed_cost_usd == pytest.approx(15.00, abs=1e-6)
    assert result.actual_cost_usd == pytest.approx(14.95, abs=1e-6)
    assert result.cost_usd == result.computed_cost_usd  # alias
    assert result.auth_mode == "api"


@pytest.mark.asyncio
async def test_invoker_subscription_mode_actual_cost_is_none(tmp_path, monkeypatch):
    """Under subscription, total_cost_usd is null/0 → actual_cost_usd is None."""
    from producer.invoker import ClaudeAgentInvoker

    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    fake_home = tmp_path / "home"
    (fake_home / ".claude").mkdir(parents=True)
    (fake_home / ".claude" / ".credentials.json").write_text('{"oauth": "x"}')
    monkeypatch.setattr("pathlib.Path.home", lambda: fake_home)

    class _AssistantMessage:
        def __init__(self, content):
            self.content = content
    class _TextBlock:
        def __init__(self, text):
            self.text = text
    class _ResultMessage:
        def __init__(self, usage):
            self.usage = usage
            # No total_cost_usd field — simulating subscription auth

    async def fake_query(prompt, options):
        yield _AssistantMessage(content=[_TextBlock("hi")])
        yield _ResultMessage(usage={
            "input_tokens": 1_000_000, "output_tokens": 0,
            "cache_creation_input_tokens": 0, "cache_read_input_tokens": 0,
        })

    import sys
    fake_sdk = type(sys)("claude_agent_sdk")
    fake_sdk.AssistantMessage = _AssistantMessage
    fake_sdk.TextBlock = _TextBlock
    fake_sdk.ClaudeAgentOptions = lambda **kw: type("Opts", (), kw)()
    fake_sdk.query = fake_query
    monkeypatch.setitem(sys.modules, "claude_agent_sdk", fake_sdk)

    cwd = tmp_path / "proj"
    cwd.mkdir()
    inv = ClaudeAgentInvoker(cwd=cwd)
    result = await inv.invoke(
        agent_role="code", prompt="x", model="claude-opus-4-7"
    )
    assert result.computed_cost_usd == pytest.approx(15.00, abs=1e-6)
    assert result.actual_cost_usd is None
    assert result.auth_mode == "subscription"
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
pytest tests/test_invoker.py -v -k "extracts_usage or subscription_mode_actual_cost"
```
Expected: FAIL — `result.usage` empty / `computed_cost_usd` is 0.

- [ ] **Step 3: Implement extraction + computation in `invoke`**

In `producer/invoker.py`, modify the `invoke` method. Add an import at the top of the file:

```python
from producer import pricing
```

Inside `invoke`, replace the existing `cost_usd = 0.0` line with:

```python
        actual_cost_usd: float | None = None
        usage: dict[str, int] = {}
```

Inside the `async for message in query(...)` loop, after the existing
`AssistantMessage` block, replace the existing cost-extraction loop with:

```python
                # The SDK surfaces total_cost_usd on result-bearing messages;
                # field name has churned over releases so look in a few places.
                for attr in ("total_cost_usd", "usage_cost_usd", "cost_usd"):
                    value = getattr(message, attr, None)
                    if value is not None:
                        actual_cost_usd = float(value)
                        break

                # Token counts. Try the canonical .usage dict first; fall back
                # to top-level attributes (shape varies by SDK release).
                msg_usage = getattr(message, "usage", None)
                if isinstance(msg_usage, dict):
                    for k in (
                        "input_tokens", "output_tokens",
                        "cache_creation_input_tokens", "cache_read_input_tokens",
                    ):
                        if k in msg_usage and msg_usage[k] is not None:
                            usage[k] = int(msg_usage[k])
                else:
                    for k in (
                        "input_tokens", "output_tokens",
                        "cache_creation_input_tokens", "cache_read_input_tokens",
                    ):
                        v = getattr(message, k, None)
                        if v is not None:
                            usage[k] = int(v)
```

Compute the model name (the SDK options pass it through; we know it because we passed it in) and compute the cost. Inside `invoke`, after the `try/except` around the message loop completes, add:

```python
        # Compute cost from tokens. ``model`` may be None (caller didn't pass one);
        # in that case we fall through to a 0-cost computed result and log.
        computed_cost_usd = (
            pricing.compute_cost(model, usage) if model and usage else 0.0
        )
        if not usage:
            logger.warning(
                "no usage data in SDK response; computed_cost_usd=0 "
                "(role=%s, model=%s)",
                agent_role, model,
            )
```

Then update the `InvocationResult(...)` construction:

```python
        result = InvocationResult(
            text="\n".join(text_chunks),
            cost_usd=computed_cost_usd,            # alias
            computed_cost_usd=computed_cost_usd,
            actual_cost_usd=actual_cost_usd,
            usage=usage,
            auth_mode=self.auth_mode,
            tool_calls=tool_calls,
            raw_messages=raw,
        )
```

(The old `cost_usd = 0.0` initialization and the old extraction block are replaced above. The post-loop "productive output" check at the bottom of `invoke` is unchanged — it still keys off `text_chunks` and `tool_calls`, not the cost variable.)

- [ ] **Step 4: Run tests**

```bash
pytest tests/test_invoker.py -v
```
Expected: all PASS, including the two new tests and pre-existing ones.

- [ ] **Step 5: Commit**

```bash
git add producer/invoker.py tests/test_invoker.py
git commit -m "feat(invoker): extract token usage and compute cost from pricing table"
```

---

## Task 7: Dispatcher writes both costs to the tasks row

**Files:**
- Modify: `producer/dispatch.py`
- Test: `tests/test_dispatch.py`

- [ ] **Step 1: Write the failing test**

Append to `tests/test_dispatch.py` (use the existing fixtures and stub-invoker pattern; if the file uses a `FakeInvoker`-like class, extend it). Add this test:

```python
@pytest.mark.asyncio
async def test_dispatch_records_both_cost_fields_to_tasks_row(
    producer_setup, fake_invoker_factory
):
    """After successful dispatch, tasks.cost_usd and actual_cost_usd are populated."""
    cfg, ledger, kill_switch = producer_setup
    invoker = fake_invoker_factory(
        result_kwargs={
            "computed_cost_usd": 0.42,
            "actual_cost_usd": 0.40,
            "auth_mode": "api",
        }
    )
    from producer.dispatch import Producer
    producer = Producer(config=cfg, ledger=ledger, invoker=invoker, kill_switch=kill_switch)

    tid = ledger.insert_task(agent_owner="code", title="t", description="d")
    await producer.run_once()

    row = ledger.conn.execute(
        "SELECT cost_usd, actual_cost_usd, status FROM tasks WHERE id=?", (tid,)
    ).fetchone()
    assert row["status"] == "done"
    assert row["cost_usd"] == pytest.approx(0.42)
    assert row["actual_cost_usd"] == pytest.approx(0.40)


@pytest.mark.asyncio
async def test_dispatch_records_null_actual_under_subscription(
    producer_setup, fake_invoker_factory
):
    cfg, ledger, kill_switch = producer_setup
    invoker = fake_invoker_factory(
        result_kwargs={
            "computed_cost_usd": 0.42,
            "actual_cost_usd": None,
            "auth_mode": "subscription",
        }
    )
    from producer.dispatch import Producer
    producer = Producer(config=cfg, ledger=ledger, invoker=invoker, kill_switch=kill_switch)

    tid = ledger.insert_task(agent_owner="code", title="t", description="d")
    await producer.run_once()

    row = ledger.conn.execute(
        "SELECT cost_usd, actual_cost_usd FROM tasks WHERE id=?", (tid,)
    ).fetchone()
    assert row["cost_usd"] == pytest.approx(0.42)
    assert row["actual_cost_usd"] is None
```

If `fake_invoker_factory` doesn't exist in the project's test fixtures, look at how the existing `test_dispatch.py` constructs its fake invoker — the canonical pattern should already produce an `InvocationResult`. Update that helper to thread `computed_cost_usd`/`actual_cost_usd`/`auth_mode` through to the returned `InvocationResult`.

- [ ] **Step 2: Run tests to verify they fail**

```bash
pytest tests/test_dispatch.py -v -k "records_both_cost_fields or records_null_actual"
```
Expected: FAIL — `actual_cost_usd` not persisted.

- [ ] **Step 3: Update `handle_completion` in `dispatch.py`**

In `producer/dispatch.py`, replace `handle_completion` body (around line 304) with:

```python
    def handle_completion(self, task: Task, result: InvocationResult) -> None:
        """Mark the task done, persist per-task cost, and audit the result."""
        output_refs = self._extract_output_refs(result)
        self.ledger.complete_task(
            task.id,
            output_refs=output_refs,
            cost_usd=result.computed_cost_usd,
            actual_cost_usd=result.actual_cost_usd,
        )
        self.audit.event(
            "task_completed",
            {
                "task_id": task.id,
                "agent_owner": task.agent_owner,
                "computed_cost_usd": result.computed_cost_usd,
                "actual_cost_usd": result.actual_cost_usd,
                "auth_mode": result.auth_mode,
                "output_refs": output_refs,
                "tool_calls": [tc.get("name") for tc in result.tool_calls],
            },
            task_id=task.id,
            cost_usd=result.computed_cost_usd,
        )
        logger.info(
            "Task %s done (%s, computed=$%.4f, actual=%s)",
            task.id,
            task.agent_owner,
            result.computed_cost_usd,
            f"${result.actual_cost_usd:.4f}" if result.actual_cost_usd is not None else "n/a",
        )
```

- [ ] **Step 4: Run tests**

```bash
pytest tests/test_dispatch.py -v
```
Expected: all PASS.

- [ ] **Step 5: Commit**

```bash
git add producer/dispatch.py tests/test_dispatch.py
git commit -m "feat(dispatch): persist computed + actual cost on the task row"
```

---

## Task 8: Morning report — drift section

**Files:**
- Modify: `producer/morning_report.py`
- Test: `tests/test_morning_report.py`

- [ ] **Step 1: Write the failing test**

Append to `tests/test_morning_report.py`:

```python
def test_morning_report_drift_section_shown_for_api_mode_tasks(tmp_path):
    """Tasks with non-null actual_cost_usd produce a drift line per agent."""
    from producer.ledger import LedgerClient
    from producer.morning_report import render_morning_report

    db = tmp_path / "ml.db"
    ledger = LedgerClient(db_path=db)
    today = "2026-05-06"
    # Two API-mode tasks for 'code' (computed=$1.00, actual=$0.90 → drift -10%)
    for tid in ("T1", "T2"):
        ledger.conn.execute(
            "INSERT INTO tasks (id, agent_owner, status, title, description, "
            "created_at, finished_at, cost_usd, actual_cost_usd) "
            "VALUES (?, 'code', 'done', 't', 'd', ?, ?, 0.50, 0.45)",
            (tid, f"{today}T01:00:00Z", f"{today}T01:00:00Z"),
        )
    # One subscription-mode task — should be excluded from drift
    ledger.conn.execute(
        "INSERT INTO tasks (id, agent_owner, status, title, description, "
        "created_at, finished_at, cost_usd, actual_cost_usd) "
        "VALUES ('T3', 'qa', 'done', 't', 'd', ?, ?, 0.50, NULL)",
        (f"{today}T01:00:00Z", f"{today}T01:00:00Z"),
    )

    body = render_morning_report(
        ledger=ledger,
        project_name="X",
        target_date=today,
        soft_total_usd=10.0,
        hard_total_usd=20.0,
        kill_switch_armed=False,
    )
    assert "Pricing drift" in body
    assert "code" in body
    # qa is subscription-only — should not appear under drift
    drift_section = body.split("## Pricing drift")[1].split("\n## ")[0]
    assert "qa" not in drift_section


def test_morning_report_drift_section_omitted_when_all_subscription(tmp_path):
    """All-subscription environment → no drift section at all."""
    from producer.ledger import LedgerClient
    from producer.morning_report import render_morning_report

    db = tmp_path / "ml.db"
    ledger = LedgerClient(db_path=db)
    today = "2026-05-06"
    ledger.conn.execute(
        "INSERT INTO tasks (id, agent_owner, status, title, description, "
        "created_at, finished_at, cost_usd, actual_cost_usd) "
        "VALUES ('T1', 'code', 'done', 't', 'd', ?, ?, 0.50, NULL)",
        (f"{today}T01:00:00Z", f"{today}T01:00:00Z"),
    )

    body = render_morning_report(
        ledger=ledger,
        project_name="X",
        target_date=today,
        soft_total_usd=10.0,
        hard_total_usd=20.0,
        kill_switch_armed=False,
    )
    assert "Pricing drift" not in body
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
pytest tests/test_morning_report.py -v -k "drift"
```
Expected: FAIL — section not present.

- [ ] **Step 3: Implement the section**

In `producer/morning_report.py`, add a query inside the `with ledger._lock:` block (alongside the other queries, after `assets_today`):

```python
        drift_rows = ledger.conn.execute(
            "SELECT agent_owner, "
            "       SUM(cost_usd)        AS sum_computed, "
            "       SUM(actual_cost_usd) AS sum_actual "
            "FROM tasks "
            "WHERE finished_at LIKE ? "
            "  AND status='done' "
            "  AND actual_cost_usd IS NOT NULL "
            "GROUP BY agent_owner "
            "HAVING sum_computed IS NOT NULL AND sum_actual IS NOT NULL "
            "ORDER BY agent_owner",
            (f"{target_date}%",),
        ).fetchall()
```

Then, after the "Assets registered today" block but before "Anomalies" (around line 134), insert:

```python
    if drift_rows:
        lines.append("## Pricing drift (computed vs actual, API-mode tasks)")
        for row in drift_rows:
            agent = row["agent_owner"]
            computed = row["sum_computed"] or 0.0
            actual = row["sum_actual"] or 0.0
            delta_pct = (
                ((computed - actual) / actual * 100.0) if actual > 0 else 0.0
            )
            lines.append(
                f"- {agent}: computed=${computed:.4f}, actual=${actual:.4f} "
                f"(Δ {delta_pct:+.1f}%)"
            )
        lines.append("")
```

- [ ] **Step 4: Run tests**

```bash
pytest tests/test_morning_report.py -v
```
Expected: all PASS.

- [ ] **Step 5: Commit**

```bash
git add producer/morning_report.py tests/test_morning_report.py
git commit -m "feat(report): drift section comparing computed vs SDK-reported cost"
```

---

## Task 9: Morning report — staleness banner

**Files:**
- Modify: `producer/morning_report.py`
- Test: `tests/test_morning_report.py`

- [ ] **Step 1: Write the failing test**

Append to `tests/test_morning_report.py`:

```python
def test_morning_report_staleness_banner(tmp_path, monkeypatch):
    """When pricing.is_stale() returns (True, n), a banner appears at the top."""
    from producer.ledger import LedgerClient
    from producer.morning_report import render_morning_report
    from producer import pricing

    monkeypatch.setattr(pricing, "is_stale", lambda now=None: (True, 95))

    ledger = LedgerClient(db_path=tmp_path / "s.db")
    body = render_morning_report(
        ledger=ledger,
        project_name="X",
        target_date="2026-05-06",
        soft_total_usd=10.0,
        hard_total_usd=20.0,
        kill_switch_armed=False,
    )
    assert "pricing table is 95 days old" in body
    assert "producer pricing update" in body


def test_morning_report_no_staleness_banner_when_fresh(tmp_path, monkeypatch):
    from producer.ledger import LedgerClient
    from producer.morning_report import render_morning_report
    from producer import pricing

    monkeypatch.setattr(pricing, "is_stale", lambda now=None: (False, 5))

    ledger = LedgerClient(db_path=tmp_path / "s.db")
    body = render_morning_report(
        ledger=ledger,
        project_name="X",
        target_date="2026-05-06",
        soft_total_usd=10.0,
        hard_total_usd=20.0,
        kill_switch_armed=False,
    )
    assert "pricing table is" not in body
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
pytest tests/test_morning_report.py -v -k "staleness"
```
Expected: FAIL — banner missing.

- [ ] **Step 3: Implement the banner**

In `producer/morning_report.py`, add an import at the top:

```python
from producer import pricing
```

Right after the `lines.append(f"# {project_name} — Morning Report {target_date}")` line, insert:

```python
    try:
        stale, age_days = pricing.is_stale()
    except Exception:  # pricing missing/corrupt — don't break the report
        stale, age_days = False, 0
    if stale:
        lines.append("")
        lines.append(
            f"> ⚠️ pricing table is {age_days} days old. "
            f"Run: `producer pricing update`"
        )
```

- [ ] **Step 4: Run tests**

```bash
pytest tests/test_morning_report.py -v
```
Expected: all PASS.

- [ ] **Step 5: Commit**

```bash
git add producer/morning_report.py tests/test_morning_report.py
git commit -m "feat(report): staleness banner when pricing table is >90 days old"
```

---

## Task 10: Producer startup staleness check

**Files:**
- Modify: `producer/dispatch.py`
- Test: `tests/test_dispatch.py`

- [ ] **Step 1: Write the failing test**

Append to `tests/test_dispatch.py`:

```python
@pytest.mark.asyncio
async def test_producer_writes_needs_attention_when_pricing_stale(
    producer_setup, fake_invoker_factory, monkeypatch
):
    """At startup, stale pricing → needs-attention.md gets a clear note."""
    from producer import pricing
    from producer.dispatch import Producer

    monkeypatch.setattr(pricing, "is_stale", lambda now=None: (True, 95))

    cfg, ledger, kill_switch = producer_setup
    invoker = fake_invoker_factory()
    producer = Producer(
        config=cfg, ledger=ledger, invoker=invoker, kill_switch=kill_switch
    )
    await producer.run_once()

    needs = (cfg.reports_dir / "needs-attention.md").read_text(encoding="utf-8")
    assert "pricing table is 95 days old" in needs
    assert "producer pricing update" in needs


@pytest.mark.asyncio
async def test_producer_no_needs_attention_when_pricing_fresh(
    producer_setup, fake_invoker_factory, monkeypatch
):
    from producer import pricing
    from producer.dispatch import Producer

    monkeypatch.setattr(pricing, "is_stale", lambda now=None: (False, 5))

    cfg, ledger, kill_switch = producer_setup
    invoker = fake_invoker_factory()
    producer = Producer(
        config=cfg, ledger=ledger, invoker=invoker, kill_switch=kill_switch
    )
    await producer.run_once()

    needs = cfg.reports_dir / "needs-attention.md"
    if needs.exists():
        # File may exist from idle detection in fixture; just check no pricing line
        assert "pricing table" not in needs.read_text(encoding="utf-8")
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
pytest tests/test_dispatch.py -v -k "pricing_stale or pricing_fresh"
```
Expected: FAIL — needs-attention.md missing or no pricing line.

- [ ] **Step 3: Implement the check**

In `producer/dispatch.py`, add an import at the top:

```python
from producer import pricing
```

Add a helper method on `Producer` (place it near `_track_idle` since both write to needs-attention.md):

```python
    def _check_pricing_staleness(self) -> None:
        """One-shot at startup: warn if the pricing table is older than threshold."""
        try:
            stale, age_days = pricing.is_stale()
        except Exception:
            logger.exception("pricing staleness check failed; skipping")
            return
        if not stale:
            return
        msg = (
            f"pricing table is {age_days} days old (>{pricing.STALENESS_DAYS}). "
            f"Run: producer pricing update"
        )
        logger.warning(msg)
        marker = self.config.reports_dir / "needs-attention.md"
        marker.parent.mkdir(parents=True, exist_ok=True)
        with marker.open("a", encoding="utf-8") as f:
            f.write(f"- {msg}\n")
        self.audit.event("pricing_stale", {"age_days": age_days})
```

Then call it from both `run` and `run_once` at the top of the method (right after the `audit.event("producer_boot...")` call):

```python
    async def run(self) -> None:
        self.install_signal_handlers()
        self.audit.event("producer_boot", {"poll_interval_s": self.config.poll_interval_seconds})
        self._check_pricing_staleness()
        # ... existing body ...
```

```python
    async def run_once(self) -> int:
        self.audit.event("producer_boot_once", {})
        self._check_pricing_staleness()
        dispatched = await self._tick()
        await self._flush_pending_writes()
        return dispatched
```

- [ ] **Step 4: Run tests**

```bash
pytest tests/test_dispatch.py -v
```
Expected: all PASS.

- [ ] **Step 5: Commit**

```bash
git add producer/dispatch.py tests/test_dispatch.py
git commit -m "feat(producer): warn to needs-attention.md when pricing table is stale"
```

---

## Task 11: Pricing updater module

**Files:**
- Create: `producer/pricing_updater.py`
- Test: `tests/test_pricing_updater.py`

- [ ] **Step 1: Write the failing tests**

Create `tests/test_pricing_updater.py`:

```python
"""Tests for producer.pricing_updater."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import AsyncMock

import pytest

from producer import pricing_updater


def _good_payload() -> dict:
    return {
        "last_updated": "2026-05-06",
        "source_url": "https://docs.anthropic.com/en/docs/about-claude/pricing",
        "currency": "USD",
        "models": {
            "claude-opus-4-7": {
                "input_per_mtok_usd": 15.0,
                "output_per_mtok_usd": 75.0,
                "cache_creation_per_mtok_usd": 18.75,
                "cache_read_per_mtok_usd": 1.50,
            },
        },
    }


@pytest.mark.asyncio
async def test_updater_writes_atomically_on_valid_response(tmp_path, monkeypatch):
    target = tmp_path / "pricing.json"
    target.write_text(json.dumps({"last_updated": "2026-01-01", "models": {}}))
    monkeypatch.setattr(pricing_updater, "TARGET_PATH", target)

    async def fake_runner(*, prompt, **_):
        return type("R", (), {"text": json.dumps(_good_payload())})()

    diff = await pricing_updater.update_pricing(runner=fake_runner)
    written = json.loads(target.read_text())
    assert written["last_updated"] == "2026-05-06"
    assert "claude-opus-4-7" in written["models"]
    assert isinstance(diff, dict)


@pytest.mark.asyncio
async def test_updater_dry_run_does_not_write(tmp_path, monkeypatch):
    target = tmp_path / "pricing.json"
    original = {"last_updated": "2026-01-01", "models": {}}
    target.write_text(json.dumps(original))
    monkeypatch.setattr(pricing_updater, "TARGET_PATH", target)

    async def fake_runner(*, prompt, **_):
        return type("R", (), {"text": json.dumps(_good_payload())})()

    await pricing_updater.update_pricing(runner=fake_runner, dry_run=True)
    assert json.loads(target.read_text()) == original


@pytest.mark.asyncio
async def test_updater_rejects_malformed_json(tmp_path, monkeypatch):
    target = tmp_path / "pricing.json"
    original = {"last_updated": "2026-01-01", "models": {}}
    target.write_text(json.dumps(original))
    monkeypatch.setattr(pricing_updater, "TARGET_PATH", target)

    async def fake_runner(*, prompt, **_):
        return type("R", (), {"text": "{not valid"})()

    with pytest.raises(pricing_updater.PricingUpdateError):
        await pricing_updater.update_pricing(runner=fake_runner)
    # Original untouched
    assert json.loads(target.read_text()) == original


@pytest.mark.asyncio
async def test_updater_rejects_missing_top_level_keys(tmp_path, monkeypatch):
    target = tmp_path / "pricing.json"
    target.write_text(json.dumps({"last_updated": "2026-01-01", "models": {}}))
    monkeypatch.setattr(pricing_updater, "TARGET_PATH", target)

    bad = {"last_updated": "2026-05-06", "models": {}}  # missing source_url, currency

    async def fake_runner(*, prompt, **_):
        return type("R", (), {"text": json.dumps(bad)})()

    with pytest.raises(pricing_updater.PricingUpdateError, match="missing"):
        await pricing_updater.update_pricing(runner=fake_runner)


@pytest.mark.asyncio
async def test_updater_rejects_implausible_rates(tmp_path, monkeypatch):
    target = tmp_path / "pricing.json"
    target.write_text(json.dumps({"last_updated": "2026-01-01", "models": {}}))
    monkeypatch.setattr(pricing_updater, "TARGET_PATH", target)

    bad = _good_payload()
    bad["models"]["claude-opus-4-7"]["input_per_mtok_usd"] = 99999.0  # implausible

    async def fake_runner(*, prompt, **_):
        return type("R", (), {"text": json.dumps(bad)})()

    with pytest.raises(pricing_updater.PricingUpdateError, match="sanity"):
        await pricing_updater.update_pricing(runner=fake_runner)
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
pytest tests/test_pricing_updater.py -v
```
Expected: FAIL — module doesn't exist.

- [ ] **Step 3: Implement the updater**

Create `producer/pricing_updater.py`:

```python
"""``producer pricing update`` worker.

Drives a one-shot Claude Agent SDK call with WebFetch to read the official
Anthropic pricing page and emits a fresh ``pricing.json``. Validates the
response shape and rate plausibility before any filesystem write.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import textwrap
from pathlib import Path
from typing import Any, Awaitable, Callable, Protocol

from producer.pricing import PRICING_PATH

logger = logging.getLogger("producer.pricing_updater")

#: Module-level so tests can monkeypatch.
TARGET_PATH: Path = PRICING_PATH

REQUIRED_TOP_KEYS = {"last_updated", "source_url", "currency", "models"}
REQUIRED_RATE_KEYS = {
    "input_per_mtok_usd",
    "output_per_mtok_usd",
    "cache_creation_per_mtok_usd",
    "cache_read_per_mtok_usd",
}
MAX_PLAUSIBLE_RATE_USD_PER_MTOK = 1000.0


class PricingUpdateError(RuntimeError):
    """Update aborted — bad response, validation failure, or write error."""


class _Runner(Protocol):
    """Callable shape compatible with ClaudeAgentInvoker.invoke."""

    async def __call__(self, *, prompt: str, **kwargs: Any) -> Any: ...


_PROMPT = textwrap.dedent("""\
    Fetch this URL: {url}

    Read the per-model pricing table on that page and return ONLY a JSON object
    matching this exact schema (no markdown, no prose, no code fences):

    {{
      "last_updated": "<today YYYY-MM-DD>",
      "source_url": "{url}",
      "currency": "USD",
      "models": {{
        "<model-id>": {{
          "input_per_mtok_usd": <number>,
          "output_per_mtok_usd": <number>,
          "cache_creation_per_mtok_usd": <number>,
          "cache_read_per_mtok_usd": <number>
        }}
      }}
    }}

    Use these model IDs exactly as Anthropic publishes them. Include rates for
    Opus, Sonnet, and Haiku families (latest version of each). Use null only
    if a rate is not published for a given model.
""")


def _default_runner_factory(cwd: Path) -> Callable[..., Awaitable[Any]]:
    """Return an async callable that runs a single Claude Agent SDK query."""
    from producer.invoker import ClaudeAgentInvoker

    invoker = ClaudeAgentInvoker(cwd=cwd)

    async def runner(*, prompt: str, **kwargs: Any) -> Any:
        return await invoker.invoke(
            agent_role="producer",
            prompt=prompt,
            allowed_tools=["WebFetch"],
            max_turns=4,
        )

    return runner


def _validate(payload: dict[str, Any]) -> None:
    missing = REQUIRED_TOP_KEYS - payload.keys()
    if missing:
        raise PricingUpdateError(f"response missing required top-level keys: {missing}")
    if not isinstance(payload["models"], dict) or not payload["models"]:
        raise PricingUpdateError("response.models must be a non-empty object")
    for model, rates in payload["models"].items():
        if not isinstance(rates, dict):
            raise PricingUpdateError(f"rates for {model!r} must be an object")
        missing_rate = REQUIRED_RATE_KEYS - rates.keys()
        if missing_rate:
            raise PricingUpdateError(
                f"model {model!r} missing rate keys: {missing_rate}"
            )
        for k in REQUIRED_RATE_KEYS:
            v = rates[k]
            if not isinstance(v, (int, float)) or v < 0:
                raise PricingUpdateError(
                    f"model {model!r} rate {k} must be a non-negative number"
                )
            if v > MAX_PLAUSIBLE_RATE_USD_PER_MTOK:
                raise PricingUpdateError(
                    f"model {model!r} rate {k}={v} fails sanity bound "
                    f"(>{MAX_PLAUSIBLE_RATE_USD_PER_MTOK})"
                )


def _diff(old: dict[str, Any], new: dict[str, Any]) -> dict[str, Any]:
    """Return a per-model rate-change summary for printing."""
    changes: dict[str, Any] = {}
    old_models = (old or {}).get("models", {}) or {}
    new_models = new.get("models", {}) or {}
    for model in sorted(set(old_models) | set(new_models)):
        old_rates = old_models.get(model, {})
        new_rates = new_models.get(model, {})
        per_model: dict[str, tuple[float | None, float | None]] = {}
        for k in REQUIRED_RATE_KEYS:
            ov = old_rates.get(k)
            nv = new_rates.get(k)
            if ov != nv:
                per_model[k] = (ov, nv)
        if per_model or model not in old_models or model not in new_models:
            changes[model] = per_model
    return changes


async def update_pricing(
    *,
    dry_run: bool = False,
    runner: Callable[..., Awaitable[Any]] | None = None,
    cwd: Path | None = None,
) -> dict[str, Any]:
    """Fetch live pricing, validate, atomically write ``pricing.json``.

    Returns the diff dict produced by :func:`_diff` so the CLI can print it.
    Raises :class:`PricingUpdateError` on any validation failure; the
    existing file is not modified in that case.
    """
    cwd = cwd or Path.cwd()

    # Load current for diff (best-effort — empty dict if absent or unreadable)
    try:
        old = json.loads(TARGET_PATH.read_text(encoding="utf-8"))
    except (FileNotFoundError, json.JSONDecodeError):
        old = {}

    source_url = (old.get("source_url")
                  or "https://docs.anthropic.com/en/docs/about-claude/pricing")
    prompt = _PROMPT.format(url=source_url)

    runner = runner or _default_runner_factory(cwd)
    result = await runner(prompt=prompt)
    text = getattr(result, "text", "") or ""
    try:
        payload = json.loads(text)
    except json.JSONDecodeError as exc:
        raise PricingUpdateError(
            f"runner returned non-JSON output: {exc}"
        ) from exc

    _validate(payload)
    diff = _diff(old, payload)

    if dry_run:
        logger.info("dry-run: would write %s", TARGET_PATH)
        return diff

    tmp = TARGET_PATH.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    os.replace(tmp, TARGET_PATH)
    logger.info("wrote %s", TARGET_PATH)
    return diff
```

- [ ] **Step 4: Run tests**

```bash
pytest tests/test_pricing_updater.py -v
```
Expected: all PASS.

- [ ] **Step 5: Commit**

```bash
git add producer/pricing_updater.py tests/test_pricing_updater.py
git commit -m "feat(pricing): updater — WebFetch + validation + atomic write"
```

---

## Task 12: Wire `producer pricing update` CLI subcommand

**Files:**
- Modify: `producer/cli.py`
- Test: `tests/test_cli.py`

- [ ] **Step 1: Write the failing test**

Append to `tests/test_cli.py`:

```python
def test_pricing_update_subcommand_wired(monkeypatch, capsys):
    """`producer pricing update --dry-run` invokes the updater and prints diff."""
    from producer import cli, pricing_updater

    captured = {"called": False}

    async def fake_update(*, dry_run, runner=None, cwd=None):
        captured["called"] = True
        captured["dry_run"] = dry_run
        return {"claude-opus-4-7": {"input_per_mtok_usd": (15.0, 16.0)}}

    monkeypatch.setattr(pricing_updater, "update_pricing", fake_update)

    rc = cli.main(["pricing", "update", "--dry-run"])
    out = capsys.readouterr().out
    assert rc == 0
    assert captured["called"] is True
    assert captured["dry_run"] is True
    assert "claude-opus-4-7" in out
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
pytest tests/test_cli.py -v -k "pricing_update_subcommand"
```
Expected: FAIL — argparse rejects `pricing` subcommand.

- [ ] **Step 3: Wire the subcommand**

In `producer/cli.py`:

a) Add a handler near the other `cmd_*` functions (e.g. after `cmd_resume`):

```python
def cmd_pricing_update(args: argparse.Namespace) -> int:
    from producer import pricing_updater

    async def _run():
        return await pricing_updater.update_pricing(dry_run=args.dry_run)

    diff = asyncio.run(_run())
    if not diff:
        print("No rate changes.")
        return 0
    for model, changes in diff.items():
        if not changes:
            continue
        print(f"{model}:")
        for k, (old, new) in changes.items():
            old_s = "<absent>" if old is None else f"{old:.4f}"
            new_s = "<absent>" if new is None else f"{new:.4f}"
            print(f"  {k}: {old_s} → {new_s}")
    if args.dry_run:
        print("(dry run — no file written)")
    return 0
```

b) In `_build_parser`, after the `p_resume` block, add:

```python
    p_pricing = sub.add_parser("pricing", help="Pricing-table maintenance.")
    pricing_sub = p_pricing.add_subparsers(dest="pricing_command", required=True)

    p_update = pricing_sub.add_parser(
        "update", help="Refresh pricing.json from docs.anthropic.com."
    )
    p_update.add_argument(
        "--dry-run", action="store_true",
        help="Validate and diff, but don't write the file.",
    )
    p_update.set_defaults(fn=cmd_pricing_update)
```

- [ ] **Step 4: Run tests**

```bash
pytest tests/test_cli.py -v
```
Expected: all PASS.

- [ ] **Step 5: Smoke-check the CLI help**

```bash
python -m producer.cli pricing --help
python -m producer.cli pricing update --help
```
Expected: both print sensible usage text and exit 0.

- [ ] **Step 6: Commit**

```bash
git add producer/cli.py tests/test_cli.py
git commit -m "feat(cli): producer pricing update [--dry-run]"
```

---

## Task 13: Documentation updates

**Files:**
- Modify: `README.md`
- Modify: `CLAUDE.md`

- [ ] **Step 1: Add a "Subscription auth" subsection to `README.md`**

In `README.md`, under the existing `## Operating` section, append a new subsection between `### Idle detection` and `## Writing an agent prompt`:

```markdown
### Subscription auth

`claude-producer` accepts two auth modes:

- **API auth (default).** Set `ANTHROPIC_API_KEY` (or put it in `.env`).
  The SDK reports actual per-call cost; the dispatcher records it in
  `tasks.actual_cost_usd` alongside a `tasks.cost_usd` value computed from
  token counts × the bundled `producer/pricing.json`.
- **Subscription auth (fallback).** With no `ANTHROPIC_API_KEY` and a local
  Claude Code install (`~/.claude/.credentials.json` present), the invoker
  symlinks just the credentials file into its isolated `CLAUDE_CONFIG_DIR`
  — plugins, hooks, and skills are *not* inherited. Anthropic does not
  surface a per-call dollar figure under subscription auth, so
  `tasks.actual_cost_usd` is `NULL`; `tasks.cost_usd` (computed) is still
  populated for budget enforcement and reporting.

The pricing table in `producer/pricing.json` is bundled with the package.
Refresh it when Anthropic adjusts rates:

```bash
producer pricing update             # fetch, validate, write
producer pricing update --dry-run   # preview the diff
```

`producer run` warns once at startup if the table is more than 90 days old
(via `agent-state/needs-attention.md` and the morning report banner).
```

- [ ] **Step 2: Update `CLAUDE.md` non-obvious invariants**

In `CLAUDE.md`, in the "Non-obvious invariants" section, add three bullets after the existing `**Auto-armed kill switch**` line:

```markdown
- **Auth fallback is selective.** When `ANTHROPIC_API_KEY` is unset, the
  invoker symlinks ONLY `~/.claude/.credentials.json` into the isolated
  `CLAUDE_CONFIG_DIR`. Do not extend this to symlink anything else from
  `~/.claude` — plugins/hooks/skills cause hangs in headless dispatch
  (the original isolation rationale).
- **Cost has two columns.** `tasks.cost_usd` is the *computed* cost
  (tokens × `producer/pricing.json`) — always populated. `tasks.actual_cost_usd`
  is the SDK-reported cost — `NULL` under subscription auth. Budget
  enforcement uses `cost_usd`. The morning report's "Pricing drift"
  section compares the two.
- **Pricing table can drift.** `producer pricing update` refreshes
  `producer/pricing.json` from docs.anthropic.com. `producer run` warns
  if it's >90 days old. New models without an entry log a warning and
  cost as $0 — they don't break dispatch.
```

- [ ] **Step 3: Run the suite to confirm nothing regressed**

```bash
pytest -v 2>&1 | tail -5
```
Expected: all tests pass.

- [ ] **Step 4: Commit**

```bash
git add README.md CLAUDE.md
git commit -m "docs: subscription auth + dual-cost tracking + pricing maintenance"
```

---

## Final verification

- [ ] **Run the full suite once more**

```bash
pytest -v
```
Expected: all tests pass; the count is the original baseline + the new tests added across Tasks 2/4/5/6/7/8/9/10/11/12.

- [ ] **Sanity-check the CLI surface**

```bash
producer --help
producer pricing --help
producer pricing update --dry-run   # only if you have creds; otherwise skip
```

- [ ] **Confirm the wheel ships pricing.json**

```bash
python -m build --wheel --outdir /tmp/wheelcheck . 2>&1 | tail -3
unzip -l /tmp/wheelcheck/claude_producer-0.1.0-py3-none-any.whl | grep pricing.json
```
Expected: `producer/pricing.json` is listed.

---

## Notes for the implementer

- **Pricing rates in Task 1 are seed values, not gospel.** Verify against the
  live Anthropic pricing page before committing.
- **The `tests/test_dispatch.py` fixture (`producer_setup`, `fake_invoker_factory`)
  may need extending** to support the new `InvocationResult` fields. Look at
  the existing fixture in `tests/conftest.py` and `tests/test_dispatch.py`
  and extend the helper with the new fields.
- **`Task.from_row` will start raising `KeyError: 'actual_cost_usd'`** on
  ledgers built before the migration runs. The migration runs at
  `LedgerClient.__init__`, so any code path that constructs a `Task` from a
  query result on a `LedgerClient`-managed connection is safe. Direct sqlite3
  connections to old DBs will break — that's by design.
- **The `producer pricing update` command uses the same invoker as dispatch**
  — meaning it shares the auth detection, isolated config dir, and
  per-project budget reservation. If the producer role's daily cap is small,
  the ~$0.05 reservation could in theory deny a refresh; in practice the cap
  is sized for the whole day's polling and a single refresh is rounding
  error.
