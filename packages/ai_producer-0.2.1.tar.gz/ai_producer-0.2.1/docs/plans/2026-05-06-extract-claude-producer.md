# claude-producer — Extraction Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.
>
> **Note for this project:** the user prefers **phase-level sign-off** rather than per-task subagent dispatch. Execute one phase at a time, run that phase's tests green, then pause and ask the user before moving on.

**Goal:** Extract a reusable, pip-installable agentic-orchestration library (`claude-producer`) from Bastzee's `tools/agent_runtime.py` + `tools/producer.py` + `agent-state/schema.sql`, parametrized for any project.

**Architecture:** SQLite-WAL ledger as the message bus. A long-running `producer` process polls for `pending` tasks whose dependencies are satisfied, dispatches them to specialist agents via the Claude Agent SDK with per-agent toolsets/budgets, retries failures up to 3×, escalates beyond that to file markers + ntfy.sh push, watches a kill-switch file, and writes a 6-hourly morning report. Domain-agnostic: roles, caps, toolsets, prompts come from `producer.yaml`.

**Tech Stack:** Python 3.11+, stdlib `sqlite3`, `claude-agent-sdk`, `pyyaml`, `python-dotenv`, `httpx` (already a transitive of the SDK), `pytest` + `pytest-asyncio` for tests.

**Source repo (read-only reference):** `/Users/donmccluney/source/GitHub/Bastzee`
**Target repo (new):** `/Users/donmccluney/source/GitHub/claude-producer`
**License:** MIT

---

## File Structure (the whole tree we're building)

```
claude-producer/
├── pyproject.toml                      # hatchling build, console_scripts entry
├── LICENSE                             # MIT
├── .gitignore                          # __pycache__, *.egg-info, .pytest_cache, .venv, agent-state/
├── README.md                           # written in phase (f), AFTER smoke test
├── docs/
│   └── plans/
│       └── 2026-05-06-extract-claude-producer.md   # this file
├── producer/
│   ├── __init__.py                     # re-exports the public API
│   ├── ledger.py                       # LedgerClient, Task, AuditLogger, helpers
│   ├── budget.py                       # BudgetTracker, BudgetExceeded
│   ├── kill_switch.py                  # KillSwitchWatcher
│   ├── invoker.py                      # ClaudeAgentInvoker, InvocationResult
│   ├── escalation.py                   # notify_human + escalation file render
│   ├── morning_report.py               # render_morning_report()
│   ├── config.py                       # ProducerConfig dataclass + load_config()
│   ├── dispatch.py                     # Producer class (main loop)
│   ├── cli.py                          # `producer` entry point
│   └── schema.sql                      # bundled schema, no Bastzee samples
├── templates/
│   ├── producer.yaml.example
│   ├── agent_prompt_template.md
│   └── seed_tasks.example.json
└── tests/
    ├── conftest.py                     # tmp ledger, mock invoker fixtures
    ├── test_ledger.py                  # CRUD + audit row-hash chain
    ├── test_budget.py                  # pre-dispatch reservation + cap enforcement
    ├── test_kill_switch.py             # arm/disarm/read
    ├── test_invoker.py                 # no-productive-output ⇒ raises
    ├── test_dispatch.py                # claim/race/handle_failure/handle_escalation
    ├── test_idle_detection.py          # _track_idle counter + reset
    ├── test_morning_report.py          # report renders without crashing
    ├── test_config.py                  # YAML loader + defaults
    └── test_smoke_echo_agent.py        # phase (e) end-to-end with stub invoker
```

**Files-that-change-together principle:** ledger primitives stay in `ledger.py` (Task dataclass + LedgerClient + AuditLogger live and breathe together). Budget gets its own file because it has its own exception class and sits in front of dispatch, not inside the ledger. Kill-switch is a 30-line file because the contract is small and the test surface is tiny. Notification helpers live in `escalation.py` because both file-marker writing and ntfy push trigger from the same human-attention semantic.

---

## Public API (the import contract Bastzee will eventually consume)

```python
from producer import (
    LedgerClient, Task, AuditLogger,
    BudgetTracker, BudgetExceeded,
    KillSwitchWatcher,
    ClaudeAgentInvoker, InvocationResult,
    ProducerConfig, load_config,
    Producer,
)
```

**Function-signature compatibility with Bastzee:** keep the names and parameters identical so Bastzee can later `pip install claude-producer` and delete its `tools/agent_runtime.py` + `tools/producer.py`. The only acceptable signature change is removing the `repo_root()` global — replaced by `config.project_root`.

---

## Load-bearing details (preserve verbatim, do not "simplify")

1. **`CLAUDE_CONFIG_DIR` isolation** in `ClaudeAgentInvoker.__init__`: defaults to `<project_root>/agent-state/.claude`, exported into `os.environ`. Without this, the bundled `claude` CLI loads the host user's MCP servers / hooks / plugins / skills and either hangs or fails silently.
2. **No-productive-output detection** at the end of `ClaudeAgentInvoker.invoke()`: `productive = bool(text_chunks) or bool(tool_calls)`; if not productive AND `sdk_error is not None`, raise the SDK error so the retry loop fires. System messages (init, hook_started, rate-limit) populate `raw_messages` but DON'T count as productive.
3. **`permission_mode='acceptEdits'`** default — required for headless Write/Edit/Bash without interactive prompts.
4. **Pre-dispatch budget reservation** — `BudgetTracker.can_spend(target, reservation)` is checked BEFORE `claim_task`. If False, raise `BudgetExceeded` and escalate without spending.
5. **SQLite WAL mode + `BEGIN IMMEDIATE`** — `_connect()` sets `PRAGMA journal_mode=WAL`, `synchronous=NORMAL`, `foreign_keys=ON`, `busy_timeout=5000`. Every write transaction uses `BEGIN IMMEDIATE` so two pollers can't both think they have the write lock.
6. **Audit row-hash chain** — `payload = "|".join([prev_hash, agent_owner, task_id or "", action, detail_json, f"{cost_usd:.6f}", ts])`; `row_hash = sha256(payload)`. Genesis `prev_hash = "0" * 64`. NEVER UPDATE/DELETE `audit_log` rows.
7. **Idle counter** — N consecutive empty polls (default 12 = ~2 min at 10s) triggers ntfy + `needs-attention.md` marker; reset+reverse-notify when work resumes.
8. **Optimistic-lock claim** — `UPDATE tasks SET status='in_progress' WHERE id=? AND status='pending'`; `cur.rowcount==0` means another poller won; raise `TaskClaimRace`.
9. **Agent-owned downstream filing** — agent prompt template MUST include a `LedgerClient.insert_task` example so completed agents queue their successors. This is the keystone of "fully agentic, not HITM."
10. **`max_turns=16`** default (Bastzee bumped from 8). Substantive work commonly needs 10-15 tool calls (read multiple docs, write files, run Bash for ledger updates).

---

## Bastzee-specific behaviors that get parametrized (or stripped)

| Bastzee | Becomes |
|---|---|
| `AGENT_ROSTER` (8 hard-coded names) | `config.roles` dict from `producer.yaml` |
| `DAILY_HARD_CAPS_USD` per role | `config.budget.agents[role].daily_cap_usd` |
| `DAILY_TOTAL_HARD_USD = 200.0` | `config.budget.project_ceiling_usd` |
| `DISPATCH_RESERVATIONS_USD` per role | `config.budget.agents[role].dispatch_reservation_usd` (default $0.10) |
| `ROLE_TOOLSETS` | `config.roles[role].allowed_tools` |
| `ROLE_FALLBACK_PROMPTS` | dropped — if `prompt_path` doesn't exist, dispatch fails loud (better than silently shipping a 2-line stub) |
| `repo_root()` + `BASTZEE_REPO_ROOT` env | `config.project_root` (cwd by default; overridable via `--config` path or `PRODUCER_PROJECT_ROOT`) |
| Logger `bastzee.*` | Logger `producer.*` |
| `NTFY_SUBJECT_PREFIX = "Bastzee"` | `config.notifications.subject_prefix` |
| Morning-report header "Bastzee — Morning Report" | `f"{config.project_name} — Morning Report"` |
| `EthicsLint` (Llama-Guard) | **dropped** — not in extraction scope; Bastzee's Narrative-agent gate, not generic |
| Schema's bottom-of-file Bastzee sample INSERTs | stripped from `producer/schema.sql` |
| `asset_registry.asset_type CHECK ('art','audio','content','other')` | kept as-is (game-biased but harmless for non-game projects) |
| Bash snippets in agent prompts hardcoding `/Users/donmccluney/...` | template uses `{project_root}` placeholder |
| `import os` missing in producer.py | **fix in extraction** (latent bug in Bastzee `_notify_human`) |

---

## Testing strategy

- **Unit tests** use a real SQLite database in `tmp_path`. We don't mock the ledger — the schema is small and SQLite is fast.
- **Invoker test** uses a mock `claude_agent_sdk.query` (monkeypatched) that yields a controlled message stream and optionally raises. The test imports the module under test, then patches the SDK at module-level before calling `invoke`.
- **Dispatch tests** inject a fake invoker (a class with the same `async def invoke(...)` shape) so we don't need the real SDK at test time.
- **Idle test** uses `Producer.run_once` semantics + manual `_track_idle` calls to verify the counter math.
- **Audit-chain test** mutates one row in the middle of the chain and verifies a re-hash check detects the break.
- **Smoke test (phase e)** spins up a real `Producer` with a stub invoker that returns a canned `InvocationResult`, seeds two tasks, runs `run_once()`, and asserts both moved to `done`.

`pytest-asyncio` runs `async def` tests; the `asyncio_mode = "auto"` config goes in `pyproject.toml`.

---

## Phases & sign-off cadence

- Plan approved → execute phase **(a)** → tests green → **STOP, ask sign-off**
- Sign-off received → execute phase **(b)** → tests green → **STOP**
- ... and so on through (f).

Per user instructions: don't commit until each phase signs off. Each phase ends in a single commit at sign-off time.

---

# Phase (a) — Skeleton + schema + ledger + budget + tests

**Files created:**
- `pyproject.toml`
- `LICENSE`
- `.gitignore`
- `producer/__init__.py`
- `producer/schema.sql`
- `producer/ledger.py`
- `producer/budget.py`
- `producer/kill_switch.py`
- `tests/conftest.py`
- `tests/test_ledger.py`
- `tests/test_budget.py`
- `tests/test_kill_switch.py`

### Task A1: Repo skeleton + pyproject

**Files:**
- Create: `pyproject.toml`, `LICENSE`, `.gitignore`

- [ ] **Step 1:** Write `pyproject.toml`:

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "claude-producer"
version = "0.1.0"
description = "Reusable agentic-orchestration library: SQLite-WAL ledger + Claude Agent SDK dispatcher with per-agent budgets and kill switch."
readme = "README.md"
requires-python = ">=3.11"
license = "MIT"
authors = [{ name = "capt-pancakes" }]
dependencies = [
    "claude-agent-sdk>=0.1.0",
    "pyyaml>=6.0",
    "python-dotenv>=1.0",
    "httpx>=0.27",
]

[project.optional-dependencies]
dev = [
    "pytest>=8.0",
    "pytest-asyncio>=0.23",
]

[project.scripts]
producer = "producer.cli:main"

[tool.hatch.build.targets.wheel]
packages = ["producer"]

[tool.hatch.build.targets.wheel.force-include]
"producer/schema.sql" = "producer/schema.sql"

[tool.pytest.ini_options]
asyncio_mode = "auto"
testpaths = ["tests"]
```

- [ ] **Step 2:** Write standard MIT `LICENSE` with copyright `2026 capt-pancakes`.

- [ ] **Step 3:** Write `.gitignore`:

```
__pycache__/
*.py[cod]
*.egg-info/
.pytest_cache/
.venv/
.env
dist/
build/
agent-state/
.DS_Store
```

- [ ] **Step 4:** Verify project layout with `ls -la` and confirm files exist.

### Task A2: Schema (stripped of Bastzee samples)

**Files:**
- Create: `producer/schema.sql`

- [ ] **Step 1:** Copy `agent-state/schema.sql` from Bastzee verbatim, then strip the bottom-of-file `INSERT OR IGNORE INTO budget`, `INSERT OR IGNORE INTO asset_registry`, and `INSERT OR IGNORE INTO audit_log` blocks. The PRAGMAs and all `CREATE TABLE`/`CREATE INDEX` statements stay.

- [ ] **Step 2:** Update the header comment from "Bastzee Agentic Build System" to "claude-producer — SQLite Ledger Schema (v1)" and remove cross-references to `docs/planning/06-agentic-pipeline.md` (replace with a one-line "see README §Ledger schema").

- [ ] **Step 3:** Verify the file ends after the last `CREATE INDEX ... ON audit_log(action);` (no Bastzee samples below).

### Task A3: Ledger — connection + transaction discipline (TDD)

**Files:**
- Create: `producer/ledger.py`, `tests/conftest.py`, `tests/test_ledger.py`

- [ ] **Step 1: Write the failing test** (`tests/conftest.py`):

```python
import pytest
from pathlib import Path
from producer.ledger import LedgerClient

@pytest.fixture
def ledger(tmp_path: Path) -> LedgerClient:
    db = tmp_path / "ledger.db"
    client = LedgerClient(db_path=db)
    yield client
    client.close()
```

`tests/test_ledger.py`:

```python
def test_ledger_initializes_with_wal(ledger):
    mode = ledger.conn.execute("PRAGMA journal_mode").fetchone()[0]
    assert mode.lower() == "wal"

def test_ledger_creates_tasks_table(ledger):
    rows = ledger.conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name='tasks'"
    ).fetchall()
    assert len(rows) == 1
```

- [ ] **Step 2:** Run `pytest tests/test_ledger.py -v` → FAIL (no module).

- [ ] **Step 3:** Implement minimal `producer/ledger.py`. Lift from Bastzee `tools/agent_runtime.py` lines 217–292 (`LedgerClient.__init__`, `_connect`, `conn`, `transaction`, `close`, `_ensure_schema`). Replace `repo_root() / REL_LEDGER_DB` and `repo_root() / REL_SCHEMA_SQL` with: schema loaded from `Path(__file__).parent / "schema.sql"`; db path mandatory in constructor (no `repo_root()` fallback). Keep the `threading.RLock`, the WAL pragmas, the `BEGIN IMMEDIATE` transaction context manager, exactly as-is.

- [ ] **Step 4:** Run tests → PASS.

### Task A4: Ledger — Task dataclass + insert/get (TDD)

- [ ] **Step 1: Write tests** in `tests/test_ledger.py`:

```python
def test_insert_and_get_task(ledger):
    tid = ledger.insert_task(
        agent_owner="echo",
        title="hello",
        description="say hi",
        priority=2,
    )
    task = ledger.get_task(tid)
    assert task is not None
    assert task.agent_owner == "echo"
    assert task.title == "hello"
    assert task.status == "pending"
    assert task.priority == 2
    assert task.dependencies == []
    assert task.payload == {}

def test_get_missing_task_returns_none(ledger):
    assert ledger.get_task("nope") is None
```

- [ ] **Step 2:** Run → FAIL (`insert_task` not defined).

- [ ] **Step 3:** Lift `Task` dataclass + `Task.from_row` (lines 172–214) and `insert_task`, `get_task` (lines 488–527) verbatim from Bastzee. Lift `new_id`, `utc_iso_now`, `utc_today` (lines 136–156). Constants needed: `AUDIT_GENESIS_PREV_HASH`. **Drop** Bastzee's `AGENT_ROSTER`, `DAILY_HARD_CAPS_USD`, `SOFT_CAP_RATIO`, `DAILY_TOTAL_*`, `LLAMA_GUARD_*`, `DEFAULT_CLAUDE_MODEL`, `REL_*` path constants, `repo_root()` — all parametrized in later phases.

- [ ] **Step 4:** Run → PASS.

### Task A5: Ledger — task lifecycle (claim/complete/fail/requeue/escalate/kill) (TDD)

- [ ] **Step 1: Tests:**

```python
import pytest
from producer.ledger import TaskClaimRace

def test_claim_pending_task(ledger):
    tid = ledger.insert_task(agent_owner="echo", title="t", description="d")
    task = ledger.claim_task(tid, agent_owner="echo")
    assert task.status == "in_progress"
    assert task.started_at is not None

def test_double_claim_raises_race(ledger):
    tid = ledger.insert_task(agent_owner="echo", title="t", description="d")
    ledger.claim_task(tid, agent_owner="echo")
    with pytest.raises(TaskClaimRace):
        ledger.claim_task(tid, agent_owner="echo")

def test_complete_task(ledger):
    tid = ledger.insert_task(agent_owner="echo", title="t", description="d")
    ledger.claim_task(tid, agent_owner="echo")
    ledger.complete_task(tid, output_refs=["a/b.txt"])
    assert ledger.get_task(tid).status == "done"
    assert ledger.get_task(tid).output_refs == ["a/b.txt"]

def test_fail_increments_retry_and_requeue_resets(ledger):
    tid = ledger.insert_task(agent_owner="echo", title="t", description="d")
    ledger.claim_task(tid, agent_owner="echo")
    n = ledger.fail_task(tid, "boom")
    assert n == 1
    ledger.requeue_task(tid)
    assert ledger.get_task(tid).status == "pending"

def test_escalate_task(ledger):
    tid = ledger.insert_task(agent_owner="echo", title="t", description="d")
    ledger.escalate_task(tid, "human-only")
    t = ledger.get_task(tid)
    assert t.status == "escalated"
    assert t.escalation_reason == "human-only"
```

- [ ] **Step 2:** Run → FAIL.

- [ ] **Step 3:** Lift `claim_task`, `complete_task`, `fail_task`, `requeue_task`, `escalate_task`, `kill_task`, `_dependencies_satisfied`, `list_ready_tasks`, `LedgerError`, `TaskClaimRace` from Bastzee `agent_runtime.py:294–407`. No signature changes.

- [ ] **Step 4:** Run → PASS.

### Task A6: Ledger — list_ready_tasks with dependency satisfaction (TDD)

- [ ] **Step 1: Tests:**

```python
def test_ready_skips_unsatisfied_deps(ledger):
    a = ledger.insert_task(agent_owner="echo", title="a", description="")
    b = ledger.insert_task(agent_owner="echo", title="b", description="", dependencies=[a])
    ready = [t.id for t in ledger.list_ready_tasks()]
    assert a in ready
    assert b not in ready
    ledger.claim_task(a, "echo")
    ledger.complete_task(a)
    ready_now = [t.id for t in ledger.list_ready_tasks()]
    assert b in ready_now

def test_ready_filters_by_owner(ledger):
    ledger.insert_task(agent_owner="echo", title="x", description="")
    ledger.insert_task(agent_owner="other", title="y", description="")
    ready = ledger.list_ready_tasks(agent_owner="echo")
    assert all(t.agent_owner == "echo" for t in ready)
```

- [ ] **Step 2:** Run → PASS (already implemented in A5).

### Task A7: Ledger — record_decision + record_asset (TDD)

- [ ] **Step 1: Tests:**

```python
def test_record_decision(ledger):
    tid = ledger.insert_task(agent_owner="echo", title="t", description="d")
    did = ledger.record_decision(
        task_id=tid, agent_owner="echo", kind="dispatch",
        decision_text="ok", rationale="because",
    )
    assert did
    row = ledger.conn.execute("SELECT * FROM decisions WHERE id=?", (did,)).fetchone()
    assert row["decision_text"] == "ok"

def test_record_asset(ledger):
    aid = ledger.record_asset(
        asset_type="other", path="/x.png", agent_id="echo",
        cost_usd=0.01, wall_clock_seconds=1.0,
    )
    assert aid
    row = ledger.conn.execute("SELECT * FROM asset_registry WHERE id=?", (aid,)).fetchone()
    assert row["path"] == "/x.png"
```

- [ ] **Step 2:** Lift `record_decision` (lines 410–437) and `record_asset` (lines 439–486) verbatim. Run → PASS.

### Task A8: Ledger — audit chain integrity (TDD, load-bearing)

- [ ] **Step 1: Tests:**

```python
import hashlib
from producer.ledger import AUDIT_GENESIS_PREV_HASH

def test_first_audit_chains_from_genesis(ledger):
    h = ledger.append_audit(agent_owner="echo", action="boot", detail={})
    assert h
    row = ledger.conn.execute(
        "SELECT prev_hash, row_hash FROM audit_log ORDER BY id LIMIT 1"
    ).fetchone()
    assert row["prev_hash"] == AUDIT_GENESIS_PREV_HASH

def test_audit_chain_links(ledger):
    h1 = ledger.append_audit(agent_owner="echo", action="a", detail={})
    h2 = ledger.append_audit(agent_owner="echo", action="b", detail={})
    rows = list(ledger.conn.execute(
        "SELECT prev_hash, row_hash FROM audit_log ORDER BY id"
    ))
    assert rows[1]["prev_hash"] == rows[0]["row_hash"]
    assert h2 == rows[1]["row_hash"]

def test_mutating_a_row_breaks_recompute(ledger):
    ledger.append_audit(agent_owner="echo", action="a", detail={"k": 1})
    ledger.append_audit(agent_owner="echo", action="b", detail={})
    ledger.append_audit(agent_owner="echo", action="c", detail={})
    # tamper: change detail of row 2
    ledger.conn.execute(
        "UPDATE audit_log SET detail=? WHERE id=2", ('{"k":999}',)
    )
    ledger.conn.execute("COMMIT")  # raw write, no transaction wrapper
    # walk the chain — recompute and compare
    rows = list(ledger.conn.execute(
        "SELECT id, agent_owner, task_id, action, detail, cost_usd, timestamp, "
        "prev_hash, row_hash FROM audit_log ORDER BY id"
    ))
    broken = []
    for r in rows:
        payload = "|".join([
            r["prev_hash"], r["agent_owner"], r["task_id"] or "",
            r["action"], r["detail"], f"{r['cost_usd']:.6f}", r["timestamp"],
        ])
        if hashlib.sha256(payload.encode()).hexdigest() != r["row_hash"]:
            broken.append(r["id"])
    assert 2 in broken  # tampered row's stored hash no longer matches its content
```

- [ ] **Step 2:** Lift `append_audit` (lines 599–650), `latest_audit_hash` (lines 592–597), `AUDIT_GENESIS_PREV_HASH` constant. Also lift the `AuditLogger` facade (lines 1087–1113). Run → PASS.

### Task A9: Ledger — budget rows (raw, no tracker yet) (TDD)

- [ ] **Step 1: Tests:**

```python
def test_update_budget_creates_row(ledger):
    spent, soft, hard = ledger.update_budget("echo", 0.5, hard_cap_usd=10.0, soft_cap_ratio=0.8)
    assert spent == 0.5
    assert hard == 10.0
    assert soft == 8.0

def test_update_budget_accumulates(ledger):
    ledger.update_budget("echo", 0.5, hard_cap_usd=10.0, soft_cap_ratio=0.8)
    spent, _, _ = ledger.update_budget("echo", 0.25, hard_cap_usd=10.0, soft_cap_ratio=0.8)
    assert abs(spent - 0.75) < 1e-9

def test_total_spend_today(ledger):
    ledger.update_budget("a", 1.0, hard_cap_usd=10.0, soft_cap_ratio=0.8)
    ledger.update_budget("b", 2.0, hard_cap_usd=10.0, soft_cap_ratio=0.8)
    assert ledger.total_spend_today() == 3.0
```

- [ ] **Step 2:** Lift `update_budget`, `total_spend_today`, `budget_state` from Bastzee (lines 531–588). **Signature change**: caps are now passed in (no `DAILY_HARD_CAPS_USD` lookup). New signatures:

```python
def update_budget(self, agent_owner: str, delta_usd: float, *,
                  hard_cap_usd: float, soft_cap_ratio: float) -> tuple[float, float, float]:
    ...

def budget_state(self, agent_owner: str, *,
                 hard_cap_usd: float, soft_cap_ratio: float) -> tuple[float, float, float]:
    ...
```

The `BudgetTracker` (next task) is what holds the per-role caps and passes them in. This keeps `LedgerClient` agnostic of role config.

- [ ] **Step 3:** Run → PASS.

### Task A10: Budget tracker — pre-dispatch reservation (TDD, load-bearing)

**Files:**
- Create: `producer/budget.py`, `tests/test_budget.py`

- [ ] **Step 1: Tests:**

```python
import pytest
from producer.budget import BudgetTracker, BudgetExceeded

CAPS = {"echo": {"daily_cap_usd": 10.0}, "other": {"daily_cap_usd": 5.0}}
PROJECT_CEILING = 50.0
SOFT_RATIO = 0.8

def make_tracker(ledger):
    return BudgetTracker(ledger, role_caps=CAPS, project_ceiling_usd=PROJECT_CEILING,
                         soft_cap_ratio=SOFT_RATIO)

def test_can_spend_within_cap(ledger):
    t = make_tracker(ledger)
    assert t.can_spend("echo", 1.0) is True

def test_can_spend_blocks_at_per_agent_hard_cap(ledger):
    t = make_tracker(ledger)
    t.record_spend("echo", 9.5)
    assert t.can_spend("echo", 1.0) is False  # 9.5+1.0 > 10.0

def test_can_spend_blocks_at_project_ceiling(ledger):
    t = make_tracker(ledger)
    # spread spending across agents to hit project ceiling, not per-agent
    for agent in ["echo", "other"]:
        t.record_spend(agent, CAPS[agent]["daily_cap_usd"])
    # total = 15.0, ceiling = 50.0, so room
    # bump ceiling check: assert near-ceiling refusal
    t2 = BudgetTracker(ledger, role_caps=CAPS, project_ceiling_usd=15.5,
                       soft_cap_ratio=SOFT_RATIO)
    assert t2.can_spend("echo", 1.0) is False  # would exceed 15.5

def test_record_spend_raises_when_hard_cap_breached(ledger):
    t = make_tracker(ledger)
    t.record_spend("echo", 9.5)
    with pytest.raises(BudgetExceeded):
        t.record_spend("echo", 1.0)  # 9.5+1.0=10.5 > 10.0

def test_pre_dispatch_reservation_pattern(ledger):
    """The contract: can_spend is a pre-flight check. After it passes,
    the caller invokes the API; record_spend records actuals AFTER."""
    t = make_tracker(ledger)
    # before: pre-dispatch check
    assert t.can_spend("echo", 0.5) is True
    # ... pretend invoke ran ...
    # after: actual cost recorded
    spent, soft, hard = t.record_spend("echo", 0.42)
    assert spent == pytest.approx(0.42)
    assert hard == 10.0
```

- [ ] **Step 2:** Run → FAIL.

- [ ] **Step 3:** Implement `producer/budget.py` lifted from Bastzee `agent_runtime.py:727–781`. Signature changes:

```python
class BudgetTracker:
    def __init__(self, ledger: LedgerClient, *,
                 role_caps: dict[str, dict],
                 project_ceiling_usd: float,
                 soft_cap_ratio: float = 0.8) -> None:
        ...

    def can_spend(self, agent_owner: str, usd: float) -> bool:
        # uses self.role_caps[agent_owner]["daily_cap_usd"] and self.project_ceiling_usd
        ...

    def record_spend(self, agent_owner: str, usd: float, *,
                     task_id: str | None = None,
                     api: str = "unknown") -> tuple[float, float, float]:
        ...

    def soft_warn(self, agent_owner: str) -> bool:
        ...
```

`BudgetExceeded` lives here. Audit-log integration (`ledger.append_audit` after `update_budget`) is preserved.

- [ ] **Step 4:** Run → PASS.

### Task A11: Kill-switch (TDD)

**Files:**
- Create: `producer/kill_switch.py`, `tests/test_kill_switch.py`

- [ ] **Step 1: Tests:**

```python
from producer.kill_switch import KillSwitchWatcher

def test_disarmed_when_missing(tmp_path):
    k = KillSwitchWatcher(path=tmp_path / "kill_switch")
    assert k.is_armed() is False

def test_arm_then_disarm(tmp_path):
    k = KillSwitchWatcher(path=tmp_path / "kill_switch")
    k.arm("test reason")
    assert k.is_armed() is True
    assert (tmp_path / "kill_switch.reason").exists()
    k.disarm()
    assert k.is_armed() is False

def test_zero_content_is_disarmed(tmp_path):
    p = tmp_path / "kill_switch"
    p.write_text("0\n")
    k = KillSwitchWatcher(path=p)
    assert k.is_armed() is False
```

- [ ] **Step 2:** Lift verbatim from Bastzee `agent_runtime.py:689–719`. Drop the `repo_root()` default — `path` is now required. Run → PASS.

### Task A12: Phase (a) commit gate

- [ ] **Step 1:** Run full suite: `pytest -v`. Expect all passing.
- [ ] **Step 2:** Verify `producer/__init__.py` re-exports: `LedgerClient`, `Task`, `AuditLogger`, `BudgetTracker`, `BudgetExceeded`, `KillSwitchWatcher`, `TaskClaimRace`, `LedgerError`, `AUDIT_GENESIS_PREV_HASH`.
- [ ] **Step 3:** **STOP. Ask user for sign-off before committing or proceeding to phase (b).**

---

# Phase (b) — Invoker (CLAUDE_CONFIG_DIR isolation + no-output detection)

**Files created:**
- `producer/invoker.py`
- `tests/test_invoker.py`

### Task B1: InvocationResult dataclass (TDD)

- [ ] **Step 1: Test:**

```python
from producer.invoker import InvocationResult

def test_invocation_result_defaults():
    r = InvocationResult(text="hi", cost_usd=0.01)
    assert r.text == "hi"
    assert r.cost_usd == 0.01
    assert r.tool_calls == []
    assert r.raw_messages == []
    assert r.sdk_error is None
```

- [ ] **Step 2:** Lift `InvocationResult` from Bastzee `agent_runtime.py:927–934`. Run → PASS.

### Task B2: Invoker — CLAUDE_CONFIG_DIR isolation (TDD, load-bearing)

- [ ] **Step 1: Test:**

```python
import os
from pathlib import Path
from producer.invoker import ClaudeAgentInvoker

def test_invoker_sets_claude_config_dir(monkeypatch, tmp_path):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")
    target = tmp_path / "isolated-claude"
    inv = ClaudeAgentInvoker(cwd=tmp_path, config_dir=target)
    assert os.environ["CLAUDE_CONFIG_DIR"] == str(target.resolve())
    assert target.exists()

def test_invoker_default_config_dir_under_cwd(monkeypatch, tmp_path):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")
    inv = ClaudeAgentInvoker(cwd=tmp_path)
    expected = (tmp_path / "agent-state" / ".claude").resolve()
    assert os.environ["CLAUDE_CONFIG_DIR"] == str(expected)

def test_invoker_requires_api_key(monkeypatch, tmp_path):
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    import pytest
    with pytest.raises(RuntimeError, match="ANTHROPIC_API_KEY"):
        ClaudeAgentInvoker(cwd=tmp_path)
```

- [ ] **Step 2:** Run → FAIL.

- [ ] **Step 3:** Implement `producer/invoker.py`. Lift `ClaudeAgentInvoker.__init__` from Bastzee `agent_runtime.py:951–982` verbatim — preserve the os.environ sets, the `mkdir(parents=True, exist_ok=True)`, the `permission_mode` default. **Drop** `default_model = DEFAULT_CLAUDE_MODEL`; pass model in via `invoke()` (Bastzee already does this — `model: str | None = None`). **Drop** `cwd or repo_root()` fallback; `cwd` is required.

- [ ] **Step 4:** Run → PASS.

### Task B3: Invoker — no-productive-output detection (TDD, load-bearing)

- [ ] **Step 1: Test** (full mock of `claude_agent_sdk`):

```python
import pytest
from unittest.mock import MagicMock
from producer.invoker import ClaudeAgentInvoker

@pytest.fixture
def patch_sdk(monkeypatch):
    """Returns a helper that installs a fake claude_agent_sdk module."""
    fake_sdk = MagicMock()

    class FakeAssistantMessage:
        def __init__(self, content):
            self.content = content

    class FakeTextBlock:
        def __init__(self, text):
            self.text = text

    class FakeOptions:
        def __init__(self, **kwargs):
            self.kwargs = kwargs

    fake_sdk.AssistantMessage = FakeAssistantMessage
    fake_sdk.TextBlock = FakeTextBlock
    fake_sdk.ClaudeAgentOptions = FakeOptions

    def install(query_fn):
        fake_sdk.query = query_fn
        monkeypatch.setitem(__import__('sys').modules, "claude_agent_sdk", fake_sdk)
        return fake_sdk

    return install


async def test_invoke_raises_when_sdk_errors_with_no_productive_output(
    monkeypatch, tmp_path, patch_sdk
):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")

    async def empty_then_raise(prompt, options):
        # Yield nothing productive, then SDK exits with error
        if False:
            yield  # make it an async generator
        raise RuntimeError("Command failed with exit code 1")

    patch_sdk(empty_then_raise)

    inv = ClaudeAgentInvoker(cwd=tmp_path)
    with pytest.raises(RuntimeError, match="exit code 1"):
        await inv.invoke(agent_role="echo", prompt="hi", allowed_tools=[])


async def test_invoke_absorbs_sdk_error_when_text_was_produced(
    monkeypatch, tmp_path, patch_sdk
):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")

    fake_sdk_ref = {}

    async def text_then_raise(prompt, options):
        fake_sdk_mod = fake_sdk_ref["mod"]
        yield fake_sdk_mod.AssistantMessage(
            content=[fake_sdk_mod.TextBlock(text="hello")]
        )
        raise RuntimeError("Command failed with exit code 1")

    fake_sdk_ref["mod"] = patch_sdk(text_then_raise)

    inv = ClaudeAgentInvoker(cwd=tmp_path)
    result = await inv.invoke(agent_role="echo", prompt="hi", allowed_tools=[])
    assert result.text == "hello"
    assert result.sdk_error is not None
    assert "exit code 1" in result.sdk_error


async def test_invoke_normal_path(monkeypatch, tmp_path, patch_sdk):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")

    fake_sdk_ref = {}

    async def normal(prompt, options):
        m = fake_sdk_ref["mod"]
        msg = m.AssistantMessage(content=[m.TextBlock(text="ok")])
        msg.total_cost_usd = 0.05
        yield msg

    fake_sdk_ref["mod"] = patch_sdk(normal)

    inv = ClaudeAgentInvoker(cwd=tmp_path)
    result = await inv.invoke(agent_role="echo", prompt="hi", allowed_tools=[])
    assert result.text == "ok"
    assert result.cost_usd == 0.05
    assert result.sdk_error is None
```

- [ ] **Step 2:** Run → FAIL (only InvocationResult exists).

- [ ] **Step 3:** Implement `ClaudeAgentInvoker.invoke()` — lift from Bastzee `agent_runtime.py:984–1079` verbatim. Critical bits to preserve:
  - The `try: ... except Exception as exc: sdk_error = exc` around the `async for` loop.
  - The cost-extraction tries `total_cost_usd`, `usage_cost_usd`, `cost_usd` attrs.
  - The `productive = bool(text_chunks) or bool(tool_calls)` check.
  - `if sdk_error is not None: result.sdk_error = str(sdk_error); if not productive: raise sdk_error`.
  - The `try: options = ClaudeAgentOptions(permission_mode=..., **kwargs); except TypeError: options = ClaudeAgentOptions(**kwargs)` SDK-version compat fallback.
  - **Drop** `if agent_role not in AGENT_ROSTER: raise` — role validation now happens at config-load time, not here. Agent role is a free string for the invoker.

- [ ] **Step 4:** Run → all PASS.

### Task B4: Phase (b) commit gate

- [ ] **Step 1:** Run `pytest -v`. All green.
- [ ] **Step 2:** Update `producer/__init__.py` to re-export `ClaudeAgentInvoker`, `InvocationResult`.
- [ ] **Step 3:** **STOP. Ask user for sign-off before commit + phase (c).**

---

# Phase (c) — Dispatch loop + idle + ntfy + escalation + morning report

**Files created:**
- `producer/escalation.py`
- `producer/morning_report.py`
- `producer/config.py`
- `producer/dispatch.py`
- `tests/test_config.py`
- `tests/test_dispatch.py`
- `tests/test_idle_detection.py`
- `tests/test_morning_report.py`

### Task C1: Config — load `producer.yaml` (TDD)

- [ ] **Step 1: Tests** in `tests/test_config.py`:

```python
import yaml
from pathlib import Path
from producer.config import ProducerConfig, load_config

def test_load_minimal_config(tmp_path):
    cfg_path = tmp_path / "producer.yaml"
    cfg_path.write_text(yaml.safe_dump({
        "project_name": "demo",
        "project_root": str(tmp_path),
        "kill_switch": "agent-state/kill_switch",
        "poll_interval_seconds": 5,
        "idle_threshold_polls": 6,
        "notifications": {"ntfy_topic": "demo-topic", "subject_prefix": "Demo"},
        "budget": {
            "project_ceiling_usd": 100,
            "soft_cap_ratio": 0.8,
            "agents": {
                "echo": {
                    "daily_cap_usd": 5.0,
                    "dispatch_reservation_usd": 0.05,
                    "allowed_tools": ["Read", "Bash"],
                    "prompt": "agents/echo/system_prompt.md",
                }
            },
        },
    }))
    cfg = load_config(cfg_path)
    assert cfg.project_name == "demo"
    assert cfg.poll_interval_seconds == 5
    assert cfg.idle_threshold_polls == 6
    assert "echo" in cfg.roles
    assert cfg.roles["echo"].daily_cap_usd == 5.0
    assert cfg.roles["echo"].allowed_tools == ["Read", "Bash"]
    assert cfg.budget.project_ceiling_usd == 100
```

- [ ] **Step 2:** Run → FAIL.

- [ ] **Step 3:** Implement `producer/config.py`:

```python
from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
import yaml

@dataclass
class RoleConfig:
    name: str
    daily_cap_usd: float
    allowed_tools: list[str] = field(default_factory=list)
    dispatch_reservation_usd: float = 0.10
    prompt: str | None = None  # path relative to project_root

@dataclass
class BudgetConfig:
    project_ceiling_usd: float
    soft_cap_ratio: float = 0.8

@dataclass
class NotificationsConfig:
    ntfy_topic: str = ""
    subject_prefix: str = "Producer"

@dataclass
class ProducerConfig:
    project_name: str
    project_root: Path
    kill_switch: Path
    poll_interval_seconds: float
    idle_threshold_polls: int
    notifications: NotificationsConfig
    budget: BudgetConfig
    roles: dict[str, RoleConfig]
    ledger_db: Path  # default project_root/agent-state/ledger.db
    escalations_dir: Path
    reports_dir: Path

def load_config(path: Path) -> ProducerConfig:
    data = yaml.safe_load(Path(path).read_text())
    project_root = Path(data["project_root"]).resolve()
    roles = {
        name: RoleConfig(name=name, **{k: v for k, v in r.items() if k != "name"})
        for name, r in data.get("budget", {}).get("agents", {}).items()
    }
    notifications = NotificationsConfig(**data.get("notifications", {}))
    budget = BudgetConfig(
        project_ceiling_usd=data["budget"]["project_ceiling_usd"],
        soft_cap_ratio=data["budget"].get("soft_cap_ratio", 0.8),
    )
    return ProducerConfig(
        project_name=data["project_name"],
        project_root=project_root,
        kill_switch=project_root / data.get("kill_switch", "agent-state/kill_switch"),
        poll_interval_seconds=float(data.get("poll_interval_seconds", 10)),
        idle_threshold_polls=int(data.get("idle_threshold_polls", 12)),
        notifications=notifications,
        budget=budget,
        roles=roles,
        ledger_db=project_root / data.get("ledger_db", "agent-state/ledger.db"),
        escalations_dir=project_root / data.get("escalations_dir", "agent-state/escalations"),
        reports_dir=project_root / data.get("reports_dir", "agent-state"),
    )
```

- [ ] **Step 4:** Run → PASS.

### Task C2: Escalation — file marker + ntfy push (TDD)

- [ ] **Step 1: Tests** in `tests/test_dispatch.py`:

```python
from producer.escalation import notify_human, render_escalation
from producer.ledger import LedgerClient

def test_notify_human_writes_marker(tmp_path, monkeypatch):
    monkeypatch.delenv("NTFY_TOPIC", raising=False)
    marker = tmp_path / "needs-attention.md"
    notify_human(
        marker_path=marker,
        ntfy_topic="",
        subject_prefix="Demo",
        subject="Idle",
        body="nothing happening",
    )
    text = marker.read_text()
    assert "Idle" in text
    assert "nothing happening" in text

def test_render_escalation_includes_payload():
    # build a Task fixture via insert_task in a real ledger
    ...  # see test_dispatch.py for full version
```

- [ ] **Step 2:** Implement `producer/escalation.py`:

```python
from __future__ import annotations
from datetime import datetime, timezone
from pathlib import Path
import json, logging, textwrap, urllib.request

logger = logging.getLogger("producer.escalation")

def utc_iso_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

def notify_human(*, marker_path: Path, ntfy_topic: str, subject_prefix: str,
                 subject: str, body: str, priority: str = "default",
                 tags: str = "robot") -> None:
    """File-marker always, ntfy.sh if topic is set. Never raises."""
    try:
        marker_path.parent.mkdir(parents=True, exist_ok=True)
        with marker_path.open("a", encoding="utf-8") as f:
            f.write(f"\n## {utc_iso_now()} — {subject}\n\n{body}\n")
    except OSError as exc:
        logger.warning("Could not write attention marker: %s", exc)
    if ntfy_topic:
        try:
            req = urllib.request.Request(
                f"https://ntfy.sh/{ntfy_topic}",
                data=body.encode("utf-8"),
                headers={
                    "Title": f"{subject_prefix} — {subject}",
                    "Priority": priority,
                    "Tags": tags,
                },
            )
            urllib.request.urlopen(req, timeout=5)
        except Exception as exc:  # noqa: BLE001
            logger.warning("ntfy.sh notification failed: %s", exc)

def render_escalation(*, task, reason: str) -> str:
    return textwrap.dedent(f"""\
        # Escalation: {task.title}

        **Task ID:** `{task.id}`
        **Agent:** {task.agent_owner}
        **Reason:** {reason}
        **Time:** {utc_iso_now()}

        ## Description

        {task.description}

        ## Payload

        ```json
        {json.dumps(task.payload, indent=2)}
        ```

        ## Recommended action

        Review the failure context, decide whether to:
          1. Retry with adjusted payload (set status back to `pending`).
          2. Kill the task (set status to `killed`).
          3. Re-route to a different agent (edit `agent_owner`, set `pending`).
        """)
```

- [ ] **Step 3:** Run → PASS.

### Task C3: Morning report (TDD)

- [ ] **Step 1: Test:**

```python
from producer.morning_report import render_morning_report
from producer.ledger import LedgerClient

def test_morning_report_renders_with_zero_data(ledger):
    text = render_morning_report(
        ledger=ledger,
        project_name="Demo",
        target_date="2026-05-06",
        soft_total_usd=10.0,
        hard_total_usd=50.0,
        kill_switch_armed=False,
    )
    assert "Demo — Morning Report" in text
    assert "Shipped overnight" in text
    assert "Spend" in text
```

- [ ] **Step 2:** Lift `_render_morning_report` and `_collect_anomalies` from Bastzee `producer.py:643–794` into a free function `render_morning_report(*, ledger, project_name, target_date, soft_total_usd, hard_total_usd, kill_switch_armed) -> str`. Drop the bastzee header. Keep all SQL.

- [ ] **Step 3:** Run → PASS.

### Task C4: Dispatch — Producer class skeleton + tick (TDD with mock invoker)

- [ ] **Step 1: Test:**

```python
import pytest
from dataclasses import dataclass
from producer.dispatch import Producer
from producer.ledger import LedgerClient
from producer.budget import BudgetTracker
from producer.kill_switch import KillSwitchWatcher
from producer.invoker import InvocationResult
from producer.config import ProducerConfig, RoleConfig, BudgetConfig, NotificationsConfig

class FakeInvoker:
    def __init__(self, result):
        self._result = result
        self.calls = []
    async def invoke(self, *, agent_role, prompt, system_prompt=None,
                     allowed_tools=None, max_turns=16, model=None):
        self.calls.append((agent_role, prompt))
        return self._result

def make_config(tmp_path):
    return ProducerConfig(
        project_name="demo",
        project_root=tmp_path,
        kill_switch=tmp_path / "kill_switch",
        poll_interval_seconds=0.01,
        idle_threshold_polls=3,
        notifications=NotificationsConfig(ntfy_topic="", subject_prefix="Demo"),
        budget=BudgetConfig(project_ceiling_usd=100.0, soft_cap_ratio=0.8),
        roles={
            "echo": RoleConfig(name="echo", daily_cap_usd=5.0,
                               dispatch_reservation_usd=0.05,
                               allowed_tools=["Read", "Write"]),
            "producer": RoleConfig(name="producer", daily_cap_usd=2.0,
                                   dispatch_reservation_usd=0.01),
        },
        ledger_db=tmp_path / "ledger.db",
        escalations_dir=tmp_path / "escalations",
        reports_dir=tmp_path / "reports",
    )

async def test_dispatch_completes_a_task(tmp_path):
    cfg = make_config(tmp_path)
    ledger = LedgerClient(db_path=cfg.ledger_db)
    invoker = FakeInvoker(InvocationResult(text="done", cost_usd=0.02))
    producer = Producer(config=cfg, ledger=ledger, invoker=invoker,
                        kill_switch=KillSwitchWatcher(path=cfg.kill_switch))
    tid = ledger.insert_task(agent_owner="echo", title="t", description="d")
    n = await producer.run_once()
    assert n == 1
    task = ledger.get_task(tid)
    assert task.status == "done"
    assert invoker.calls[0][0] == "echo"
```

- [ ] **Step 2:** Implement `producer/dispatch.py`. Lift `Producer` from Bastzee `producer.py:157–807`. Major rewrites:
  - `__init__` takes `config: ProducerConfig`, `ledger`, `invoker`, `kill_switch` — all injected. No env-var reading inside.
  - `BudgetTracker` is built from `config.budget` + `config.roles`.
  - `_load_system_prompt`: reads `config.project_root / config.roles[role].prompt` if set; raises if missing (no fallback stub strings).
  - `_build_specialist_prompt`: keep template but drop "for Bastzee" — use `f"You are the {role.title()} agent for {config.project_name}"`.
  - `dispatch_task`: dispatch reservation comes from `config.roles[target].dispatch_reservation_usd`; producer reservation from `config.roles["producer"].dispatch_reservation_usd` (default $0.01 if no producer role declared — log a warning).
  - `_track_idle`: use `config.idle_threshold_polls`.
  - `_notify_human`: delegates to `producer.escalation.notify_human` with paths from config.
  - `handle_escalation`: writes to `config.escalations_dir / f"{task.id}.md"`.
  - `write_morning_report`: delegates to `producer.morning_report.render_morning_report`.
  - **Constants kept**: `MAX_RETRIES_PER_TASK=3`, `AGENT_FAILURE_BURST_THRESHOLD=5`, `AGENT_FAILURE_BURST_WINDOW_MINUTES=10`, `MORNING_REPORT_INTERVAL_SECONDS=21600`. These are policy, not config (yet).
  - **Fix the `os` import bug** from Bastzee.
  - Drop `install_signal_handlers` from `run_once` path (still wired in `run`).

- [ ] **Step 3:** Run → PASS.

### Task C5: Dispatch — failure retry + escalation (TDD)

- [ ] **Step 1: Tests:**

```python
async def test_failure_retries_then_escalates(tmp_path, monkeypatch):
    monkeypatch.delenv("NTFY_TOPIC", raising=False)

    class BadInvoker:
        async def invoke(self, **kwargs):
            raise RuntimeError("boom")

    cfg = make_config(tmp_path)
    ledger = LedgerClient(db_path=cfg.ledger_db)
    producer = Producer(config=cfg, ledger=ledger, invoker=BadInvoker(),
                        kill_switch=KillSwitchWatcher(path=cfg.kill_switch))
    tid = ledger.insert_task(agent_owner="echo", title="t", description="d")
    # First three attempts requeue.
    for _ in range(3):
        await producer.run_once()
    task = ledger.get_task(tid)
    assert task.status == "escalated"
    # Escalation file exists.
    assert (cfg.escalations_dir / f"{tid}.md").exists()
```

- [ ] **Step 2:** Verify retry/escalation lifted code works. Run → PASS.

### Task C6: Dispatch — idle detection (TDD, load-bearing)

- [ ] **Step 1: Tests** in `tests/test_idle_detection.py`:

```python
async def test_idle_counter_increments(tmp_path):
    cfg = make_config(tmp_path)  # idle_threshold_polls=3
    ledger = LedgerClient(db_path=cfg.ledger_db)
    producer = Producer(config=cfg, ledger=ledger, invoker=FakeInvoker(...),
                        kill_switch=KillSwitchWatcher(path=cfg.kill_switch))
    assert producer._idle_polls == 0
    producer._track_idle(0)
    assert producer._idle_polls == 1
    producer._track_idle(0)
    assert producer._idle_polls == 2

async def test_idle_threshold_writes_marker(tmp_path):
    cfg = make_config(tmp_path)  # idle_threshold_polls=3
    ledger = LedgerClient(db_path=cfg.ledger_db)
    producer = Producer(config=cfg, ledger=ledger, invoker=FakeInvoker(...),
                        kill_switch=KillSwitchWatcher(path=cfg.kill_switch))
    for _ in range(3):
        producer._track_idle(0)
    marker = tmp_path / "agent-state" / "needs-attention.md"
    assert marker.exists()
    assert "Team idle" in marker.read_text()

async def test_idle_resets_on_dispatch(tmp_path):
    cfg = make_config(tmp_path)
    ledger = LedgerClient(db_path=cfg.ledger_db)
    producer = Producer(config=cfg, ledger=ledger, invoker=FakeInvoker(...),
                        kill_switch=KillSwitchWatcher(path=cfg.kill_switch))
    producer._idle_polls = 5
    producer._track_idle(2)
    assert producer._idle_polls == 0
```

- [ ] **Step 2:** Run → PASS (already implemented in C4).

### Task C7: Phase (c) commit gate

- [ ] **Step 1:** Run `pytest -v`. All green.
- [ ] **Step 2:** Update `producer/__init__.py` re-exports: `Producer`, `ProducerConfig`, `RoleConfig`, `BudgetConfig`, `NotificationsConfig`, `load_config`.
- [ ] **Step 3:** **STOP. Ask user for sign-off.**

---

# Phase (d) — CLI + scaffolding (no README yet)

**Files created:**
- `producer/cli.py`
- `templates/producer.yaml.example`
- `templates/agent_prompt_template.md`
- `templates/seed_tasks.example.json`

### Task D1: Templates

- [ ] **Step 1:** Write `templates/producer.yaml.example`:

```yaml
project_name: my-project
project_root: .
kill_switch: agent-state/kill_switch
ledger_db: agent-state/ledger.db
escalations_dir: agent-state/escalations
reports_dir: agent-state
poll_interval_seconds: 10
idle_threshold_polls: 12

notifications:
  ntfy_topic: my-project-CHANGEME-pick-something-unguessable
  subject_prefix: MyProject

budget:
  project_ceiling_usd: 200
  soft_cap_ratio: 0.8
  agents:
    producer:
      daily_cap_usd: 5
      dispatch_reservation_usd: 0.05
      allowed_tools: [Read, Glob, Grep, Bash]
      prompt: agents/producer/system_prompt.md
    code:
      daily_cap_usd: 20
      dispatch_reservation_usd: 0.20
      allowed_tools: [Read, Edit, Write, Glob, Grep, Bash]
      prompt: agents/code/system_prompt.md
    qa:
      daily_cap_usd: 8
      dispatch_reservation_usd: 0.40
      allowed_tools: [Read, Glob, Grep, Bash]
      prompt: agents/qa/system_prompt.md
```

- [ ] **Step 2:** Write `templates/agent_prompt_template.md` — based on Bastzee's designer/code prompts but stripped of project specifics. Sections: Mission / Read first / Locked principles / What you must produce / Ledger discipline / Queue self-replenishment (with `LedgerClient.insert_task` example showing the keystone) / Stop condition. Include placeholders `{project_name}`, `{role}`, `{project_root}`.

The Bash example in "Queue self-replenishment" must read:

```bash
cd {project_root} && python -c "
from producer import LedgerClient
l = LedgerClient(db_path='{project_root}/agent-state/ledger.db')
l.insert_task(
    agent_owner='qa',
    title='Validate <feature>',
    description='Per <spec>, run a focused pass on <feature>.',
    payload={'feature': '<id>'},
    priority=4,
)
l.close()
"
```

- [ ] **Step 3:** Write `templates/seed_tasks.example.json`:

```json
[
  {
    "id": "01HYK0SEED00000000000HELLO",
    "agent_owner": "code",
    "title": "Bootstrap example task",
    "description": "Replace this with your real day-1 backlog. See README §Seeding.",
    "priority": 3,
    "created_at": "2026-05-06T00:00:00Z"
  }
]
```

### Task D2: CLI — argparse skeleton + `init` command

- [ ] **Step 1: Test:**

```python
def test_cli_init_creates_scaffold(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    from producer.cli import main
    rc = main(["init"])
    assert rc == 0
    assert (tmp_path / "producer.yaml").exists()
    assert (tmp_path / "agent-state" / "ledger.db").exists()
    assert (tmp_path / "agents" / "code" / "system_prompt.md").exists()
```

- [ ] **Step 2:** Implement `producer/cli.py`:
  - `producer init [--force]` — copies `templates/producer.yaml.example` → `./producer.yaml`, copies `agent_prompt_template.md` to `agents/{role}/system_prompt.md` for each role in the example yaml, creates `agent-state/`, runs `LedgerClient(db_path=...)._ensure_schema()`. Refuses to overwrite without `--force`.
  - `producer run [--config PATH] [--once] [--debug]`
  - `producer report [--config PATH] [--date YYYY-MM-DD]`
  - `producer task add --agent X --title Y --description Z [--priority N] [--config PATH]`
  - `producer task list [--status pending] [--config PATH]`
  - `producer kill [reason] [--config PATH]`
  - `producer resume [--config PATH]`

Default `--config ./producer.yaml`. Use `argparse` subparsers.

- [ ] **Step 3:** Run → PASS.

### Task D3: CLI — `run`, `report`, `task add`, `task list`, `kill`, `resume`

- [ ] **Step 1:** Test each subcommand with a small test that drives it through `main([...])` and asserts ledger state.

- [ ] **Step 2:** Wire up by importing the appropriate primitive (`Producer`, `LedgerClient`, `KillSwitchWatcher`) and translating CLI args to method calls.

- [ ] **Step 3:** Run all tests → PASS.

### Task D4: Phase (d) commit gate

- [ ] **STOP. Ask user for sign-off.**

---

# Phase (e) — End-to-end smoke test with toy "echo agent"

**Files created:**
- `tests/test_smoke_echo_agent.py`
- `tests/fixtures/echo_project/...` (an in-tree mini-project the smoke test bootstraps)

### Task E1: Echo agent fixture

- [ ] **Step 1:** Create `tests/fixtures/echo_project/producer.yaml`, `agents/echo/system_prompt.md`, `seed_tasks.json` declaring a single task `agent_owner=echo, title="say hello"`.

The echo agent's prompt says: "When dispatched, immediately call the LedgerClient and record_decision('echoed back: ' + task title), then stop."

- [ ] **Step 2:** Build a `StubEchoInvoker` in the test file that simulates this — it reads the task description from the prompt, returns an `InvocationResult` with text "echoed: {title}" and a fake cost of $0.001, and pretends to have called `record_decision` (we don't actually need it to since `complete_task` is what matters for status).

### Task E2: Smoke test (TDD, defines done)

- [ ] **Step 1: Test:**

```python
async def test_echo_smoke(tmp_path, monkeypatch):
    """Full path: load config, seed task, run_once, verify done + audit chain."""
    # 1. copy fixture into tmp_path
    # 2. monkeypatch ANTHROPIC_API_KEY
    # 3. cfg = load_config(tmp_path / "producer.yaml")
    # 4. ledger = LedgerClient(db_path=cfg.ledger_db); ensure schema
    # 5. seed task
    # 6. invoker = StubEchoInvoker(...)
    # 7. producer = Producer(...)
    # 8. n = await producer.run_once()
    # 9. assert n == 1
    # 10. assert task is done
    # 11. assert at least one audit row chains from genesis
    # 12. assert budget row reflects 0.001 spend
    # 13. assert decisions row recorded by Producer's dispatch
```

- [ ] **Step 2:** Run → PASS. If anything in phases (a)-(d) is broken, surfaces here.

### Task E3: Phase (e) commit gate

- [ ] **STOP. Ask user for sign-off.**

---

# Phase (f) — README

**Files created:**
- `README.md`

### Task F1: Write the README

Now that the smoke test passes, write a focused README:
- 1-paragraph hook.
- Install (`pip install claude-producer`).
- Quickstart: `producer init` → edit `producer.yaml` → `producer run`.
- Mental model: ledger as bus, agents as system-prompt files, `insert_task` as the keystone.
- Configuration reference: full `producer.yaml` schema with comments.
- Operating: kill switch, ntfy, escalations, morning reports.
- Writing an agent prompt: Mission / Read-first / Hard rules / Ledger discipline / Queue self-replenishment / Stop.
- Limitations: not designed for >1k tasks/hour without sharding the audit table.
- License + acknowledgments (Bastzee as the source).

### Task F2: Final commit gate

- [ ] **STOP. Ask user for sign-off on the whole extraction. If approved, propose the first commit:**

```
git init && git add -A && git commit -m "Initial extraction from Bastzee tools/agent_runtime.py + tools/producer.py"
```

(One squashed commit at the end, OR per-phase commits — user's call.)

---

## Self-review against the spec

- ✅ Read-first list (4 files): incorporated into "Load-bearing details" + "Bastzee-specific" sections.
- ✅ Target-shape file tree: matches user's spec exactly (ledger.py / invoker.py / budget.py / kill_switch.py / escalation.py / morning_report.py / config.py / dispatch.py / cli.py + templates + tests).
- ✅ All 8 load-bearing details called out and tested:
  1. CLAUDE_CONFIG_DIR isolation → B2
  2. No-productive-output → B3
  3. permission_mode='acceptEdits' → B2 (default in __init__)
  4. Pre-dispatch budget reservation → A10 + C4
  5. SQLite WAL → A3
  6. Idle counter → C6
  7. Audit row-hash chain → A8
  8. Agent-owned downstream filing → D1 template
- ✅ Bastzee-specific items all in the parametrize table.
- ✅ Required tests all present: test_ledger, test_budget, test_invoker (no-output covered), test_idle_detection, test_morning_report, plus audit-chain integrity in test_ledger.
- ✅ CLI commands: init, run, report, task add, task list, kill, resume — all in D2/D3.
- ✅ "Don't write README first" — README is phase (f), AFTER the smoke test.
- ✅ "Don't add features the source doesn't have" — no web UI, no dashboard, no multi-tenancy.
- ✅ "Don't change function signatures gratuitously" — `LedgerClient.update_budget` and `budget_state` are the only ones whose signatures change (caps moved out into kwargs). Documented + justified.
- ✅ "Don't break SQLite WAL / row-hash / SDK isolation" — A3, A8, B2/B3 all defend these.
- ✅ "Don't commit until I sign off" — phase commit gates at A12 / B4 / C7 / D4 / E3 / F2.
- ✅ Python 3.11+, type hints throughout, docstrings on public APIs only.
