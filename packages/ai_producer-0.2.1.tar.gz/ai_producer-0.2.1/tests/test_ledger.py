"""Tests for producer.ledger — connection, task lifecycle, audit chain."""

from __future__ import annotations

import hashlib

import pytest

from producer.ledger import AUDIT_GENESIS_PREV_HASH, TaskClaimRace


# ---------------------------------------------------------------------------
# Connection / schema
# ---------------------------------------------------------------------------


def test_ledger_initializes_with_wal(ledger):
    mode = ledger.conn.execute("PRAGMA journal_mode").fetchone()[0]
    assert mode.lower() == "wal"


def test_ledger_creates_all_tables(ledger):
    expected = {"tasks", "decisions", "asset_registry", "budget", "audit_log", "prompts"}
    rows = ledger.conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table'"
    ).fetchall()
    names = {r["name"] for r in rows}
    assert expected.issubset(names), f"missing tables: {expected - names}"


# ---------------------------------------------------------------------------
# insert / get
# ---------------------------------------------------------------------------


def test_insert_and_get_task(ledger):
    tid = ledger.insert_task(
        agent_owner="echo",
        title="hello",
        description="say hi",
        priority=2,
    )
    task = ledger.get_task(tid)
    assert task is not None
    assert task.agent_owner == "echo"
    assert task.title == "hello"
    assert task.status == "pending"
    assert task.priority == 2
    assert task.dependencies == []
    assert task.payload == {}


def test_get_missing_task_returns_none(ledger):
    assert ledger.get_task("nope") is None


def test_insert_with_payload_and_dependencies(ledger):
    a = ledger.insert_task(agent_owner="echo", title="a", description="")
    b = ledger.insert_task(
        agent_owner="echo",
        title="b",
        description="",
        dependencies=[a],
        payload={"k": "v"},
    )
    task = ledger.get_task(b)
    assert task.dependencies == [a]
    assert task.payload == {"k": "v"}


# ---------------------------------------------------------------------------
# Lifecycle: claim/complete/fail/requeue/escalate/kill
# ---------------------------------------------------------------------------


def test_claim_pending_task(ledger):
    tid = ledger.insert_task(agent_owner="echo", title="t", description="d")
    task = ledger.claim_task(tid, agent_owner="echo")
    assert task.status == "in_progress"
    assert task.started_at is not None


def test_double_claim_raises_race(ledger):
    tid = ledger.insert_task(agent_owner="echo", title="t", description="d")
    ledger.claim_task(tid, agent_owner="echo")
    with pytest.raises(TaskClaimRace):
        ledger.claim_task(tid, agent_owner="echo")


def test_complete_task(ledger):
    tid = ledger.insert_task(agent_owner="echo", title="t", description="d")
    ledger.claim_task(tid, agent_owner="echo")
    ledger.complete_task(tid, output_refs=["a/b.txt"])
    task = ledger.get_task(tid)
    assert task.status == "done"
    assert task.output_refs == ["a/b.txt"]


def test_fail_increments_retry_and_requeue_resets(ledger):
    tid = ledger.insert_task(agent_owner="echo", title="t", description="d")
    ledger.claim_task(tid, agent_owner="echo")
    n = ledger.fail_task(tid, "boom")
    assert n == 1
    assert ledger.get_task(tid).status == "failed"
    ledger.requeue_task(tid)
    assert ledger.get_task(tid).status == "pending"


def test_escalate_task(ledger):
    tid = ledger.insert_task(agent_owner="echo", title="t", description="d")
    ledger.escalate_task(tid, "human-only")
    t = ledger.get_task(tid)
    assert t.status == "escalated"
    assert t.escalation_reason == "human-only"


def test_kill_task(ledger):
    tid = ledger.insert_task(agent_owner="echo", title="t", description="d")
    ledger.kill_task(tid, "halted")
    t = ledger.get_task(tid)
    assert t.status == "killed"
    assert t.escalation_reason == "halted"


# ---------------------------------------------------------------------------
# list_ready_tasks
# ---------------------------------------------------------------------------


def test_ready_skips_unsatisfied_deps(ledger):
    a = ledger.insert_task(agent_owner="echo", title="a", description="")
    b = ledger.insert_task(
        agent_owner="echo", title="b", description="", dependencies=[a]
    )
    ready = [t.id for t in ledger.list_ready_tasks()]
    assert a in ready
    assert b not in ready
    ledger.claim_task(a, "echo")
    ledger.complete_task(a)
    ready_now = [t.id for t in ledger.list_ready_tasks()]
    assert b in ready_now


def test_ready_filters_by_owner(ledger):
    ledger.insert_task(agent_owner="echo", title="x", description="")
    ledger.insert_task(agent_owner="other", title="y", description="")
    ready = ledger.list_ready_tasks(agent_owner="echo")
    assert all(t.agent_owner == "echo" for t in ready)
    assert len(ready) == 1


def test_ready_orders_by_priority(ledger):
    low = ledger.insert_task(
        agent_owner="echo", title="low", description="", priority=5
    )
    high = ledger.insert_task(
        agent_owner="echo", title="high", description="", priority=0
    )
    ready_ids = [t.id for t in ledger.list_ready_tasks()]
    assert ready_ids.index(high) < ready_ids.index(low)


# ---------------------------------------------------------------------------
# decisions / assets
# ---------------------------------------------------------------------------


def test_record_decision(ledger):
    tid = ledger.insert_task(agent_owner="echo", title="t", description="d")
    did = ledger.record_decision(
        task_id=tid,
        agent_owner="echo",
        kind="dispatch",
        decision_text="ok",
        rationale="because",
    )
    assert did
    row = ledger.conn.execute(
        "SELECT * FROM decisions WHERE id=?", (did,)
    ).fetchone()
    assert row["decision_text"] == "ok"
    assert row["rationale"] == "because"


def test_record_asset(ledger):
    aid = ledger.record_asset(
        asset_type="other",
        path="/x.png",
        agent_id="echo",
        cost_usd=0.01,
        wall_clock_seconds=1.0,
    )
    assert aid
    row = ledger.conn.execute(
        "SELECT * FROM asset_registry WHERE id=?", (aid,)
    ).fetchone()
    assert row["path"] == "/x.png"
    assert row["disposition"] == "shipped"


# ---------------------------------------------------------------------------
# Audit chain (load-bearing)
# ---------------------------------------------------------------------------


def test_first_audit_chains_from_genesis(ledger):
    h = ledger.append_audit(agent_owner="echo", action="boot", detail={})
    assert h
    row = ledger.conn.execute(
        "SELECT prev_hash, row_hash FROM audit_log ORDER BY id LIMIT 1"
    ).fetchone()
    assert row["prev_hash"] == AUDIT_GENESIS_PREV_HASH
    assert row["row_hash"] == h


def test_audit_chain_links(ledger):
    h1 = ledger.append_audit(agent_owner="echo", action="a", detail={})
    h2 = ledger.append_audit(agent_owner="echo", action="b", detail={})
    rows = list(
        ledger.conn.execute(
            "SELECT prev_hash, row_hash FROM audit_log ORDER BY id"
        )
    )
    assert rows[1]["prev_hash"] == rows[0]["row_hash"]
    assert h2 == rows[1]["row_hash"]
    assert h1 != h2


def test_latest_audit_hash_returns_genesis_when_empty(ledger):
    assert ledger.latest_audit_hash() == AUDIT_GENESIS_PREV_HASH


def test_latest_audit_hash_after_appends(ledger):
    ledger.append_audit(agent_owner="echo", action="a", detail={})
    h2 = ledger.append_audit(agent_owner="echo", action="b", detail={})
    assert ledger.latest_audit_hash() == h2


def test_mutating_a_row_breaks_recompute(ledger):
    """Tamper with a row's detail and verify recompute detects the break."""
    ledger.append_audit(agent_owner="echo", action="a", detail={"k": 1})
    ledger.append_audit(agent_owner="echo", action="b", detail={})
    ledger.append_audit(agent_owner="echo", action="c", detail={})

    # Tamper: change detail of row 2 outside of normal API.
    # Use raw connection write since LedgerClient deliberately doesn't expose
    # an UPDATE on audit_log.
    ledger.conn.execute("BEGIN IMMEDIATE")
    ledger.conn.execute(
        "UPDATE audit_log SET detail=? WHERE id=2", ('{"k": 999}',)
    )
    ledger.conn.execute("COMMIT")

    rows = list(
        ledger.conn.execute(
            "SELECT id, agent_owner, task_id, action, detail, cost_usd, "
            "timestamp, prev_hash, row_hash FROM audit_log ORDER BY id"
        )
    )
    broken: list[int] = []
    for r in rows:
        payload = "|".join(
            [
                r["prev_hash"],
                r["agent_owner"],
                r["task_id"] or "",
                r["action"],
                r["detail"],
                f"{r['cost_usd']:.6f}",
                r["timestamp"],
            ]
        )
        if hashlib.sha256(payload.encode("utf-8")).hexdigest() != r["row_hash"]:
            broken.append(r["id"])
    # Tampered row's stored row_hash no longer matches its content.
    assert 2 in broken


# ---------------------------------------------------------------------------
# Budget rows (raw — tracker tests live in test_budget.py)
# ---------------------------------------------------------------------------


def test_update_budget_creates_row(ledger):
    spent, soft, hard = ledger.update_budget(
        "echo", 0.5, hard_cap_usd=10.0, soft_cap_ratio=0.8
    )
    assert spent == 0.5
    assert hard == 10.0
    assert soft == 8.0


def test_update_budget_accumulates(ledger):
    ledger.update_budget("echo", 0.5, hard_cap_usd=10.0, soft_cap_ratio=0.8)
    spent, _, _ = ledger.update_budget(
        "echo", 0.25, hard_cap_usd=10.0, soft_cap_ratio=0.8
    )
    assert spent == pytest.approx(0.75)


def test_total_spend_today(ledger):
    ledger.update_budget("a", 1.0, hard_cap_usd=10.0, soft_cap_ratio=0.8)
    ledger.update_budget("b", 2.0, hard_cap_usd=10.0, soft_cap_ratio=0.8)
    assert ledger.total_spend_today() == pytest.approx(3.0)


def test_budget_state_creates_row_with_caps(ledger):
    spent, soft, hard = ledger.budget_state(
        "fresh", hard_cap_usd=4.0, soft_cap_ratio=0.5
    )
    assert spent == 0
    assert hard == 4.0
    assert soft == 2.0


# ---------------------------------------------------------------------------
# AuditLogger facade
# ---------------------------------------------------------------------------


def test_audit_logger_facade(ledger):
    from producer.ledger import AuditLogger

    al = AuditLogger(ledger, agent_owner="echo")
    h = al.event("hello", {"x": 1})
    assert h
    row = ledger.conn.execute(
        "SELECT agent_owner, action FROM audit_log WHERE row_hash=?", (h,)
    ).fetchone()
    assert row["agent_owner"] == "echo"
    assert row["action"] == "hello"


def test_migration_adds_actual_cost_usd_column_to_existing_ledger(tmp_path):
    """An older ledger without actual_cost_usd gets the column added on open."""
    import sqlite3
    db = tmp_path / "old.db"
    # Build a minimal "old" tasks table missing the new column
    conn = sqlite3.connect(db)
    conn.executescript("""
        CREATE TABLE tasks (
            id TEXT PRIMARY KEY,
            agent_owner TEXT NOT NULL,
            status TEXT NOT NULL,
            title TEXT NOT NULL,
            description TEXT NOT NULL,
            parent_task_id TEXT,
            dependencies TEXT DEFAULT '[]',
            payload TEXT DEFAULT '{}',
            output_refs TEXT DEFAULT '[]',
            priority INTEGER NOT NULL DEFAULT 3,
            sprint_id TEXT,
            created_at TEXT NOT NULL,
            started_at TEXT,
            finished_at TEXT,
            retry_count INTEGER NOT NULL DEFAULT 0,
            escalation_reason TEXT,
            cost_usd REAL NOT NULL DEFAULT 0
        );
        INSERT INTO tasks (id, agent_owner, status, title, description, created_at)
        VALUES ('T1', 'code', 'done', 'old task', 'desc', '2026-01-01T00:00:00Z');
    """)
    conn.commit()
    conn.close()

    from producer.ledger import LedgerClient
    client = LedgerClient(db_path=db)
    cols = {row["name"] for row in client.conn.execute("PRAGMA table_info(tasks)")}
    assert "actual_cost_usd" in cols
    row = client.conn.execute("SELECT actual_cost_usd FROM tasks WHERE id='T1'").fetchone()
    assert row["actual_cost_usd"] is None
    client.close()


def test_migration_is_idempotent(tmp_path):
    """Re-opening a migrated ledger does not fail."""
    from producer.ledger import LedgerClient
    db = tmp_path / "mig.db"
    LedgerClient(db_path=db).close()
    LedgerClient(db_path=db).close()  # second open — must not raise


def test_complete_task_writes_cost_columns(tmp_path):
    """complete_task accepts cost_usd + actual_cost_usd and persists both."""
    from producer.ledger import LedgerClient
    client = LedgerClient(db_path=tmp_path / "c.db")
    tid = client.insert_task(agent_owner="code", title="t", description="d")
    client.claim_task(tid, agent_owner="code")
    client.complete_task(tid, output_refs=[], cost_usd=0.42, actual_cost_usd=0.40)
    row = client.conn.execute(
        "SELECT cost_usd, actual_cost_usd FROM tasks WHERE id=?", (tid,)
    ).fetchone()
    assert row["cost_usd"] == pytest.approx(0.42)
    assert row["actual_cost_usd"] == pytest.approx(0.40)
    client.close()


def test_complete_task_actual_cost_can_be_none(tmp_path):
    """Subscription mode: actual_cost_usd is None and persists as NULL."""
    from producer.ledger import LedgerClient
    client = LedgerClient(db_path=tmp_path / "c2.db")
    tid = client.insert_task(agent_owner="code", title="t", description="d")
    client.claim_task(tid, agent_owner="code")
    client.complete_task(tid, output_refs=[], cost_usd=0.42, actual_cost_usd=None)
    row = client.conn.execute(
        "SELECT cost_usd, actual_cost_usd FROM tasks WHERE id=?", (tid,)
    ).fetchone()
    assert row["cost_usd"] == pytest.approx(0.42)
    assert row["actual_cost_usd"] is None
    client.close()


class TestConfigIsolationColumn:
    """Test config_isolation column addition and Task dataclass integration."""

    def test_migration_adds_config_isolation_column(self, tmp_path):
        """_apply_migrations adds config_isolation TEXT column."""
        from producer.ledger import LedgerClient
        client = LedgerClient(db_path=tmp_path / "mig.db")
        cols = {row["name"] for row in client.conn.execute("PRAGMA table_info(tasks)")}
        assert "config_isolation" in cols
        client.close()

    def test_config_isolation_defaults_to_none(self, tmp_path):
        """New tasks have config_isolation=None (NULL in SQLite)."""
        from producer.ledger import LedgerClient
        client = LedgerClient(db_path=tmp_path / "iso1.db")
        tid = client.insert_task(agent_owner="code", title="t", description="d")
        row = client.conn.execute(
            "SELECT config_isolation FROM tasks WHERE id=?", (tid,)
        ).fetchone()
        assert row["config_isolation"] is None
        client.close()

    def test_task_dataclass_includes_config_isolation(self, tmp_path):
        """Task.from_row parses config_isolation field."""
        from producer.ledger import LedgerClient
        client = LedgerClient(db_path=tmp_path / "iso2.db")
        tid = client.insert_task(agent_owner="code", title="t", description="d")
        task = client.get_task(tid)
        assert hasattr(task, "config_isolation")
        assert task.config_isolation is None
        client.close()

    def test_complete_task_persists_config_isolation(self, tmp_path):
        """complete_task accepts config_isolation and persists it."""
        from producer.ledger import LedgerClient
        client = LedgerClient(db_path=tmp_path / "iso3.db")
        tid = client.insert_task(agent_owner="code", title="t", description="d")
        client.claim_task(tid, agent_owner="code")
        client.complete_task(tid, output_refs=[], config_isolation="isolated_mode")
        row = client.conn.execute(
            "SELECT config_isolation FROM tasks WHERE id=?", (tid,)
        ).fetchone()
        assert row["config_isolation"] == "isolated_mode"
        client.close()
