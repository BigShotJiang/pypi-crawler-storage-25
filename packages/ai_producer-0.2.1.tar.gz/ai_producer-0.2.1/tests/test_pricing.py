"""Tests for producer.pricing."""

from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

from producer import pricing


def test_load_pricing_returns_dict_with_expected_keys():
    data = pricing.load_pricing()
    assert "last_updated" in data
    assert "source_url" in data
    assert "currency" in data
    assert "models" in data
    assert isinstance(data["models"], dict)
    assert len(data["models"]) >= 1


def test_compute_cost_known_model_input_only():
    # 1M input tokens of opus at $5/Mtok = $5
    cost = pricing.compute_cost(
        "claude-opus-4-7",
        {"input_tokens": 1_000_000, "output_tokens": 0,
         "cache_creation_input_tokens": 0, "cache_read_input_tokens": 0},
    )
    assert cost == pytest.approx(5.00, abs=1e-6)


def test_compute_cost_known_model_all_token_types():
    # 1000 of each: 1000/1e6 × ($5 + $25 + $6.25 + $0.50) = 0.001 × 36.75 = 0.03675
    cost = pricing.compute_cost(
        "claude-opus-4-7",
        {
            "input_tokens": 1000,
            "output_tokens": 1000,
            "cache_creation_input_tokens": 1000,
            "cache_read_input_tokens": 1000,
        },
    )
    assert cost == pytest.approx(0.03675, abs=1e-6)


def test_compute_cost_missing_model_returns_zero_and_warns(caplog):
    with caplog.at_level("WARNING"):
        cost = pricing.compute_cost(
            "claude-fake-99",
            {"input_tokens": 1_000_000, "output_tokens": 0,
             "cache_creation_input_tokens": 0, "cache_read_input_tokens": 0},
        )
    assert cost == 0.0
    assert any("no pricing entry" in rec.message for rec in caplog.records)


def test_compute_cost_handles_missing_token_keys():
    # If usage dict only has a subset of keys, missing ones are treated as 0
    cost = pricing.compute_cost("claude-opus-4-7", {"input_tokens": 1_000_000})
    assert cost == pytest.approx(5.00, abs=1e-6)


def test_is_stale_under_threshold(monkeypatch, tmp_path):
    pricing_file = tmp_path / "pricing.json"
    pricing_file.write_text(json.dumps({
        "last_updated": "2026-04-01",
        "source_url": "x",
        "currency": "USD",
        "models": {},
    }))
    monkeypatch.setattr(pricing, "PRICING_PATH", pricing_file)
    pricing._cache_clear()
    now = datetime(2026, 5, 1, tzinfo=timezone.utc)  # 30 days later
    stale, age = pricing.is_stale(now=now)
    assert stale is False
    assert age == 30


def test_is_stale_over_threshold(monkeypatch, tmp_path):
    pricing_file = tmp_path / "pricing.json"
    pricing_file.write_text(json.dumps({
        "last_updated": "2026-01-01",
        "source_url": "x",
        "currency": "USD",
        "models": {},
    }))
    monkeypatch.setattr(pricing, "PRICING_PATH", pricing_file)
    pricing._cache_clear()
    now = datetime(2026, 5, 1, tzinfo=timezone.utc)  # 120 days later
    stale, age = pricing.is_stale(now=now)
    assert stale is True
    assert age == 120


def test_load_handles_corrupt_json(monkeypatch, tmp_path):
    pricing_file = tmp_path / "pricing.json"
    pricing_file.write_text("{not valid json")
    monkeypatch.setattr(pricing, "PRICING_PATH", pricing_file)
    pricing._cache_clear()
    with pytest.raises(pricing.PricingError):
        pricing.load_pricing()


def test_is_stale_raises_pricing_error_when_last_updated_missing(monkeypatch, tmp_path):
    pricing_file = tmp_path / "pricing.json"
    pricing_file.write_text(json.dumps({
        "source_url": "x",
        "currency": "USD",
        "models": {},
    }))
    monkeypatch.setattr(pricing, "PRICING_PATH", pricing_file)
    pricing._cache_clear()
    with pytest.raises(pricing.PricingError, match="last_updated"):
        pricing.is_stale()


def test_is_stale_raises_pricing_error_when_last_updated_malformed(monkeypatch, tmp_path):
    pricing_file = tmp_path / "pricing.json"
    pricing_file.write_text(json.dumps({
        "last_updated": "not-a-date",
        "source_url": "x",
        "currency": "USD",
        "models": {},
    }))
    monkeypatch.setattr(pricing, "PRICING_PATH", pricing_file)
    pricing._cache_clear()
    with pytest.raises(pricing.PricingError, match="last_updated"):
        pricing.is_stale()
