"""End-to-end smoke test: a toy "echo agent" runs through the full Producer
flow with a stubbed SDK invoker.

This is the integration check for phases (a)-(d). If anything in the
extraction is broken — config loading, ledger schema, audit-chain hashing,
budget reservation, dispatch routing, system-prompt resolution, completion
recording — it surfaces here, not in a single unit test.

The only stub is :class:`StubEchoInvoker`, which stands in for the real
Claude Agent SDK. Everything else (yaml loader, ledger, budget, prompt
file resolution, decision/asset/audit writes, kill-switch wiring) is real.
"""

from __future__ import annotations

import hashlib

import pytest
import yaml

from producer import (
    AUDIT_GENESIS_PREV_HASH,
    InvocationResult,
    KillSwitchWatcher,
    LedgerClient,
    Producer,
    load_config,
)


class StubEchoInvoker:
    """Test double for ClaudeAgentInvoker.

    Captures every dispatch call so the test can assert that the right
    role, system_prompt, and allowed_tools were passed through. Returns a
    canned :class:`InvocationResult` simulating the echo agent's output.
    """

    def __init__(self):
        self.calls: list[dict] = []

    async def invoke(
        self,
        agent_role: str,
        prompt: str,
        *,
        system_prompt: str | None = None,
        max_turns: int = 16,
        allowed_tools: list[str] | None = None,
        model: str | None = None,
    ) -> InvocationResult:
        self.calls.append(
            {
                "role": agent_role,
                "prompt": prompt,
                "system_prompt": system_prompt,
                "allowed_tools": list(allowed_tools or []),
                "max_turns": max_turns,
            }
        )
        return InvocationResult(
            text=f"echoed: {prompt.splitlines()[0] if prompt else 'nothing'}",
            cost_usd=0.001,
        )


def _build_echo_project(tmp_path):
    """Write the minimal project tree the smoke test runs against."""
    cfg_yaml = {
        "project_name": "Echo Demo",
        "project_root": ".",
        "kill_switch": "agent-state/kill_switch",
        "ledger_db": "agent-state/ledger.db",
        "escalations_dir": "agent-state/escalations",
        "reports_dir": "agent-state",
        "poll_interval_seconds": 0.01,
        "idle_threshold_polls": 3,
        "notifications": {"ntfy_topic": "", "subject_prefix": "Echo"},
        "budget": {
            "project_ceiling_usd": 10.0,
            "soft_cap_ratio": 0.8,
            "agents": {
                "producer": {
                    "daily_cap_usd": 1.0,
                    "dispatch_reservation_usd": 0.01,
                    "allowed_tools": ["Read"],
                    "prompt": "agents/producer/system_prompt.md",
                },
                "echo": {
                    "daily_cap_usd": 1.0,
                    "dispatch_reservation_usd": 0.05,
                    "allowed_tools": ["Read", "Write"],
                    "prompt": "agents/echo/system_prompt.md",
                },
            },
        },
    }
    cfg_path = tmp_path / "producer.yaml"
    cfg_path.write_text(yaml.safe_dump(cfg_yaml), encoding="utf-8")

    (tmp_path / "agents" / "echo").mkdir(parents=True)
    (tmp_path / "agents" / "echo" / "system_prompt.md").write_text(
        "# Echo Agent — Echo Demo\n\n"
        "When dispatched, echo back the task title and stop.",
        encoding="utf-8",
    )
    (tmp_path / "agents" / "producer").mkdir(parents=True)
    (tmp_path / "agents" / "producer" / "system_prompt.md").write_text(
        "# Producer Agent — Echo Demo\n\nDispatch tasks to specialists.",
        encoding="utf-8",
    )
    return cfg_path


async def test_echo_smoke_end_to_end(tmp_path):
    """Full path: load config, seed task, run_once, verify everything."""
    cfg_path = _build_echo_project(tmp_path)

    cfg = load_config(cfg_path)
    assert cfg.project_name == "Echo Demo"
    assert "echo" in cfg.roles
    assert cfg.roles["echo"].allowed_tools == ["Read", "Write"]

    ledger = LedgerClient(db_path=cfg.ledger_db)
    tid = ledger.insert_task(
        agent_owner="echo",
        title="say hello",
        description="Echo back the words 'hello world'.",
    )

    invoker = StubEchoInvoker()
    producer = Producer(
        config=cfg,
        ledger=ledger,
        invoker=invoker,
        kill_switch=KillSwitchWatcher(path=cfg.kill_switch),
    )

    n = await producer.run_once()
    assert n == 1, "run_once should have dispatched the seeded echo task"

    # ---- Task lifecycle -----------------------------------------------
    task = ledger.get_task(tid)
    assert task.status == "done"
    assert task.started_at is not None
    assert task.finished_at is not None

    # ---- Invoker received the right dispatch --------------------------
    assert len(invoker.calls) == 1
    call = invoker.calls[0]
    assert call["role"] == "echo"
    assert "Echo Agent" in (call["system_prompt"] or "")
    assert call["allowed_tools"] == ["Read", "Write"]
    assert call["max_turns"] == 16
    assert "say hello" in call["prompt"]
    # Project name flows into the dispatch prompt
    assert "Echo Demo" in call["prompt"]

    # ---- Producer recorded a dispatch decision ------------------------
    decisions = ledger.conn.execute(
        "SELECT kind, agent_owner, decision_text FROM decisions WHERE kind='dispatch'"
    ).fetchall()
    assert len(decisions) == 1
    assert decisions[0]["agent_owner"] == "producer"

    # ---- Budget recorded for both Producer and target -----------------
    spent_echo, _, _ = ledger.budget_state(
        "echo", hard_cap_usd=1.0, soft_cap_ratio=0.8
    )
    assert spent_echo == pytest.approx(0.001)

    spent_producer, _, _ = ledger.budget_state(
        "producer", hard_cap_usd=1.0, soft_cap_ratio=0.8
    )
    assert spent_producer == pytest.approx(0.01)

    # ---- task_completed event audited --------------------------------
    completed = ledger.conn.execute(
        "SELECT detail FROM audit_log WHERE action='task_completed'"
    ).fetchall()
    assert len(completed) == 1

    # ---- Audit chain integrity (genesis + walk-the-chain) ------------
    rows = list(
        ledger.conn.execute(
            "SELECT id, agent_owner, task_id, action, detail, cost_usd, "
            "timestamp, prev_hash, row_hash FROM audit_log ORDER BY id"
        )
    )
    assert len(rows) >= 4  # boot_once, dispatch, cost, task_completed (at minimum)
    assert rows[0]["prev_hash"] == AUDIT_GENESIS_PREV_HASH
    for i in range(1, len(rows)):
        assert rows[i]["prev_hash"] == rows[i - 1]["row_hash"], (
            f"chain broken between rows {i-1} and {i}"
        )
    for r in rows:
        payload = "|".join(
            [
                r["prev_hash"],
                r["agent_owner"],
                r["task_id"] or "",
                r["action"],
                r["detail"],
                f"{r['cost_usd']:.6f}",
                r["timestamp"],
            ]
        )
        assert hashlib.sha256(payload.encode("utf-8")).hexdigest() == r["row_hash"], (
            f"hash mismatch on row {r['id']}"
        )

    ledger.close()


async def test_echo_smoke_self_replenishes_via_insert_task(tmp_path):
    """Variation: simulate the agent filing a downstream task during its
    invocation. After completion, run_once again — the followup dispatches.
    Validates the keystone "agents own their downstream filing" pattern."""
    cfg_path = _build_echo_project(tmp_path)
    cfg = load_config(cfg_path)
    ledger = LedgerClient(db_path=cfg.ledger_db)

    class SelfReplenishingInvoker:
        """Stub that, on first call, inserts a follow-on task in the ledger
        the way a real specialist agent would via LedgerClient.insert_task."""

        def __init__(self, ledger: LedgerClient):
            self.ledger = ledger
            self.calls = 0

        async def invoke(self, agent_role, prompt, **kwargs):
            self.calls += 1
            if self.calls == 1:
                # Simulate the agent filing its own downstream task.
                self.ledger.insert_task(
                    agent_owner="echo",
                    title="follow-up",
                    description="downstream task filed by upstream agent",
                )
            return InvocationResult(text=f"call {self.calls}", cost_usd=0.001)

    ledger.insert_task(agent_owner="echo", title="seed", description="kickoff")
    invoker = SelfReplenishingInvoker(ledger)
    producer = Producer(
        config=cfg,
        ledger=ledger,
        invoker=invoker,
        kill_switch=KillSwitchWatcher(path=cfg.kill_switch),
    )

    # First pass: dispatches seed, which files a follow-up.
    n1 = await producer.run_once()
    assert n1 == 1
    pending = ledger.conn.execute(
        "SELECT COUNT(*) AS n FROM tasks WHERE status='pending'"
    ).fetchone()
    assert pending["n"] == 1, "follow-up should be queued and pending"

    # Second pass: dispatches the follow-up.
    n2 = await producer.run_once()
    assert n2 == 1

    done_count = ledger.conn.execute(
        "SELECT COUNT(*) AS n FROM tasks WHERE status='done'"
    ).fetchone()
    assert done_count["n"] == 2, "both seed and follow-up should be done"
    assert invoker.calls == 2

    ledger.close()
