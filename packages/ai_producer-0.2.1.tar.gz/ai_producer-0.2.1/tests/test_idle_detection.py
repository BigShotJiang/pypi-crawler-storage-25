"""Tests for Producer idle detection (load-bearing).

Verifies:
* Counter increments on empty polls.
* Reaching threshold writes the file marker and audits.
* Counter resets on a productive poll, with a "back online" notification.
"""

from __future__ import annotations

from producer.dispatch import Producer
from producer.kill_switch import KillSwitchWatcher
from producer.ledger import LedgerClient
from tests.conftest import FakeInvoker, make_test_config


def _make_producer(tmp_path, *, idle_threshold_polls=3):
    cfg = make_test_config(tmp_path, idle_threshold_polls=idle_threshold_polls)
    ledger = LedgerClient(db_path=cfg.ledger_db)
    return Producer(
        config=cfg,
        ledger=ledger,
        invoker=FakeInvoker(),
        kill_switch=KillSwitchWatcher(path=cfg.kill_switch),
    ), cfg, ledger


def test_idle_counter_increments(tmp_path):
    producer, _, _ = _make_producer(tmp_path)
    assert producer._idle_polls == 0
    producer._track_idle(0)
    assert producer._idle_polls == 1
    producer._track_idle(0)
    assert producer._idle_polls == 2


def test_idle_threshold_writes_marker(tmp_path):
    producer, cfg, _ = _make_producer(tmp_path, idle_threshold_polls=3)
    for _ in range(3):
        producer._track_idle(0)
    marker = cfg.reports_dir / "needs-attention.md"
    assert marker.exists()
    text = marker.read_text()
    assert "Team idle" in text


def test_idle_notifies_only_once(tmp_path):
    """Crossing the threshold many times shouldn't append the marker each tick."""
    producer, cfg, _ = _make_producer(tmp_path, idle_threshold_polls=3)
    for _ in range(10):  # well past threshold
        producer._track_idle(0)
    marker = cfg.reports_dir / "needs-attention.md"
    text = marker.read_text()
    assert text.count("Team idle") == 1


def test_idle_resets_on_dispatch(tmp_path):
    producer, _, _ = _make_producer(tmp_path)
    producer._idle_polls = 5
    producer._idle_notified = True
    producer._track_idle(2)
    assert producer._idle_polls == 0
    assert producer._idle_notified is False


def test_idle_back_online_notifies_after_idle(tmp_path):
    producer, cfg, _ = _make_producer(tmp_path, idle_threshold_polls=3)
    for _ in range(3):
        producer._track_idle(0)  # write idle marker
    producer._track_idle(2)  # back online → second marker
    text = (cfg.reports_dir / "needs-attention.md").read_text()
    assert "Team idle" in text
    assert "Team back online" in text


def test_idle_does_not_notify_below_threshold(tmp_path):
    producer, cfg, _ = _make_producer(tmp_path, idle_threshold_polls=12)
    for _ in range(5):
        producer._track_idle(0)
    marker = cfg.reports_dir / "needs-attention.md"
    assert not marker.exists()
