"""Tests for producer.escalation."""

from __future__ import annotations

import logging
import urllib.request
from pathlib import Path

import pytest

from producer import escalation


def test_notify_human_handles_non_ascii_in_title(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """Title header must survive transport even when it contains non-ASCII.

    Repro for the production bug: the rendered title is
    ``f"{subject_prefix} — {subject}"`` which always contains an em-dash
    (U+2014). urllib encodes headers as latin-1 and would raise
    UnicodeEncodeError, which the previous implementation only caught and
    logged — so the push never went out.
    """
    captured: dict[str, object] = {}

    def fake_urlopen(req: urllib.request.Request, timeout: float = 0):
        for name, value in req.header_items():
            value.encode("latin-1")
        captured["headers"] = dict(req.header_items())
        captured["body"] = req.data

        class _Resp:
            def read(self) -> bytes:
                return b""

            def __enter__(self):
                return self

            def __exit__(self, *_):
                return False

        return _Resp()

    monkeypatch.setattr(urllib.request, "urlopen", fake_urlopen)

    with caplog.at_level(logging.WARNING, logger="producer.escalation"):
        escalation.notify_human(
            marker_path=tmp_path / "needs-attention.md",
            ntfy_topic="demo-topic",
            subject_prefix="Producer",
            subject="agent escalation",
            body="something needs attention — please look",
        )

    assert "ntfy.sh notification failed" not in caplog.text
    assert "headers" in captured, "urlopen should have been called"
    assert captured["body"] == "something needs attention — please look".encode("utf-8")


def test_notify_human_handles_non_ascii_in_subject(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, caplog: pytest.LogCaptureFixture
) -> None:
    """User-supplied subject text may contain unicode (e.g. quotes, dashes)."""
    sent: list[urllib.request.Request] = []

    def fake_urlopen(req: urllib.request.Request, timeout: float = 0):
        for _, value in req.header_items():
            value.encode("latin-1")
        sent.append(req)

        class _Resp:
            def __enter__(self):
                return self

            def __exit__(self, *_):
                return False

        return _Resp()

    monkeypatch.setattr(urllib.request, "urlopen", fake_urlopen)

    with caplog.at_level(logging.WARNING, logger="producer.escalation"):
        escalation.notify_human(
            marker_path=tmp_path / "needs-attention.md",
            ntfy_topic="demo-topic",
            subject_prefix="Producer",
            subject="agent “echo” needs help — retry exhausted",
            body="body text",
        )

    assert "ntfy.sh notification failed" not in caplog.text
    assert sent, "urlopen should have been called"


def test_notify_human_writes_marker_even_when_ntfy_disabled(tmp_path: Path) -> None:
    marker = tmp_path / "needs-attention.md"
    escalation.notify_human(
        marker_path=marker,
        ntfy_topic="",
        subject_prefix="Producer",
        subject="something",
        body="hello",
    )
    text = marker.read_text(encoding="utf-8")
    assert "something" in text
    assert "hello" in text
