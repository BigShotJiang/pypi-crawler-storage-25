"""Tests for producer.config — YAML loader + path resolution."""

from __future__ import annotations

import pytest
import yaml

from producer.config import AuthConfig, load_config


def _write_yaml(path, data):
    path.write_text(yaml.safe_dump(data), encoding="utf-8")


def test_load_minimal_config(tmp_path):
    cfg_path = tmp_path / "producer.yaml"
    _write_yaml(
        cfg_path,
        {
            "project_name": "demo",
            "project_root": str(tmp_path),
            "kill_switch": "agent-state/kill_switch",
            "poll_interval_seconds": 5,
            "idle_threshold_polls": 6,
            "notifications": {"ntfy_topic": "demo-topic", "subject_prefix": "Demo"},
            "budget": {
                "project_ceiling_usd": 100,
                "soft_cap_ratio": 0.8,
                "agents": {
                    "echo": {
                        "daily_cap_usd": 5.0,
                        "dispatch_reservation_usd": 0.05,
                        "allowed_tools": ["Read", "Bash"],
                        "prompt": "agents/echo/system_prompt.md",
                    }
                },
            },
        },
    )
    cfg = load_config(cfg_path)
    assert cfg.project_name == "demo"
    assert cfg.poll_interval_seconds == 5
    assert cfg.idle_threshold_polls == 6
    assert cfg.notifications.ntfy_topic == "demo-topic"
    assert cfg.notifications.subject_prefix == "Demo"
    assert "echo" in cfg.roles
    assert cfg.roles["echo"].daily_cap_usd == 5.0
    assert cfg.roles["echo"].allowed_tools == ["Read", "Bash"]
    assert cfg.roles["echo"].prompt == "agents/echo/system_prompt.md"
    assert cfg.roles["echo"].dispatch_reservation_usd == 0.05
    assert cfg.budget.project_ceiling_usd == 100
    assert cfg.budget.soft_cap_ratio == 0.8


def test_load_config_resolves_relative_project_root(tmp_path):
    """project_root='.' should resolve relative to the YAML file's parent."""
    cfg_path = tmp_path / "producer.yaml"
    _write_yaml(
        cfg_path,
        {
            "project_name": "demo",
            "project_root": ".",
            "budget": {"project_ceiling_usd": 50, "agents": {}},
        },
    )
    cfg = load_config(cfg_path)
    assert cfg.project_root == tmp_path.resolve()
    assert cfg.kill_switch == (tmp_path / "agent-state" / "kill_switch").resolve()


def test_load_config_defaults(tmp_path):
    cfg_path = tmp_path / "producer.yaml"
    _write_yaml(
        cfg_path,
        {
            "project_name": "demo",
            "project_root": str(tmp_path),
            "budget": {"project_ceiling_usd": 50, "agents": {}},
        },
    )
    cfg = load_config(cfg_path)
    assert cfg.poll_interval_seconds == 10
    assert cfg.idle_threshold_polls == 12
    assert cfg.budget.soft_cap_ratio == 0.8
    assert cfg.notifications.ntfy_topic == ""
    assert cfg.notifications.subject_prefix == "Producer"


def test_role_caps_dict_shape(tmp_path):
    cfg_path = tmp_path / "producer.yaml"
    _write_yaml(
        cfg_path,
        {
            "project_name": "demo",
            "project_root": str(tmp_path),
            "budget": {
                "project_ceiling_usd": 50,
                "agents": {
                    "code": {"daily_cap_usd": 20, "allowed_tools": []},
                    "qa": {"daily_cap_usd": 8},
                },
            },
        },
    )
    cfg = load_config(cfg_path)
    caps = cfg.role_caps_dict()
    assert caps == {"code": {"daily_cap_usd": 20.0}, "qa": {"daily_cap_usd": 8.0}}


def _minimal_yaml(extra: dict | None = None) -> dict:
    """Smallest yaml that load_config will accept."""
    base = {
        "project_name": "Test",
        "project_root": ".",
        "budget": {"project_ceiling_usd": 1.0, "agents": {}},
    }
    if extra:
        base.update(extra)
    return base


def test_auth_config_defaults_to_auto_when_block_absent(tmp_path):
    cfg_path = tmp_path / "producer.yaml"
    cfg_path.write_text(yaml.safe_dump(_minimal_yaml()), encoding="utf-8")
    cfg = load_config(cfg_path)
    assert cfg.auth.mode == "auto"


def test_auth_config_parses_explicit_mode(tmp_path):
    for mode in ("auto", "isolated", "inherit"):
        cfg_path = tmp_path / "producer.yaml"
        cfg_path.write_text(
            yaml.safe_dump(_minimal_yaml({"auth": {"mode": mode}})),
            encoding="utf-8",
        )
        cfg = load_config(cfg_path)
        assert cfg.auth.mode == mode, f"failed for mode={mode}"


def test_auth_config_rejects_unknown_mode(tmp_path):
    cfg_path = tmp_path / "producer.yaml"
    cfg_path.write_text(
        yaml.safe_dump(_minimal_yaml({"auth": {"mode": "nonsense"}})),
        encoding="utf-8",
    )
    with pytest.raises(ValueError, match="auth.mode"):
        load_config(cfg_path)


def test_auth_config_dataclass_default():
    """AuthConfig() with no args → mode=auto."""
    assert AuthConfig().mode == "auto"
