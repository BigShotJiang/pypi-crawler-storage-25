"""Tests for producer.budget — pre-dispatch reservation + cap enforcement."""

from __future__ import annotations

import pytest

from producer.budget import BudgetExceeded, BudgetTracker

CAPS = {
    "echo": {"daily_cap_usd": 10.0},
    "other": {"daily_cap_usd": 5.0},
}
PROJECT_CEILING = 50.0
SOFT_RATIO = 0.8


def make_tracker(ledger, *, ceiling: float = PROJECT_CEILING):
    return BudgetTracker(
        ledger,
        role_caps=CAPS,
        project_ceiling_usd=ceiling,
        soft_cap_ratio=SOFT_RATIO,
    )


def test_can_spend_within_cap(ledger):
    t = make_tracker(ledger)
    assert t.can_spend("echo", 1.0) is True


def test_can_spend_blocks_at_per_agent_hard_cap(ledger):
    t = make_tracker(ledger)
    t.record_spend("echo", 9.5)
    assert t.can_spend("echo", 1.0) is False  # 9.5 + 1.0 > 10.0


def test_can_spend_at_exact_cap_is_allowed(ledger):
    t = make_tracker(ledger)
    t.record_spend("echo", 5.0)
    # 5.0 + 5.0 = 10.0, which equals hard cap (not over)
    assert t.can_spend("echo", 5.0) is True


def test_can_spend_blocks_at_project_ceiling(ledger):
    # Tight ceiling so we hit it before any per-agent cap.
    t = make_tracker(ledger, ceiling=2.0)
    t.record_spend("echo", 1.5)
    assert t.can_spend("echo", 1.0) is False  # 1.5 + 1.0 = 2.5 > 2.0
    assert t.can_spend("echo", 0.5) is True  # 1.5 + 0.5 = 2.0 == 2.0 OK


def test_record_spend_raises_when_hard_cap_breached(ledger):
    t = make_tracker(ledger)
    t.record_spend("echo", 9.5)
    with pytest.raises(BudgetExceeded):
        t.record_spend("echo", 1.0)  # 9.5 + 1.0 = 10.5 > 10.0


def test_pre_dispatch_reservation_pattern(ledger):
    """Pre-flight check then post-call accounting — the load-bearing
    Producer dispatch pattern."""
    t = make_tracker(ledger)
    # before: pre-dispatch check
    assert t.can_spend("echo", 0.5) is True
    # ... pretend the API call ran ...
    # after: actual cost recorded
    spent, soft, hard = t.record_spend("echo", 0.42)
    assert spent == pytest.approx(0.42)
    assert hard == 10.0
    assert soft == 8.0


def test_can_spend_negative_raises(ledger):
    t = make_tracker(ledger)
    with pytest.raises(ValueError):
        t.can_spend("echo", -0.01)


def test_unknown_agent_has_zero_cap(ledger):
    """Unknown agents have no allowance (defensive default)."""
    t = make_tracker(ledger)
    assert t.can_spend("unknown_agent", 0.01) is False


def test_soft_warn(ledger):
    t = make_tracker(ledger)
    assert t.soft_warn("echo") is False
    # Soft cap is 8.0 (10 * 0.8). Spend 8.5: between soft and hard.
    t.record_spend("echo", 8.5)
    assert t.soft_warn("echo") is True


def test_record_spend_audits(ledger):
    t = make_tracker(ledger)
    t.record_spend("echo", 0.05, task_id="t1", api="claude")
    rows = ledger.conn.execute(
        "SELECT agent_owner, action, detail, cost_usd "
        "FROM audit_log WHERE action='cost' ORDER BY id"
    ).fetchall()
    assert len(rows) == 1
    assert rows[0]["agent_owner"] == "echo"
    assert rows[0]["cost_usd"] == pytest.approx(0.05)
