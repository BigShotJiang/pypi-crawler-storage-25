"""Tests for producer.cli — init + task add/list + kill/resume + report.

The `run` command isn't unit-tested here because it requires a real SDK
(or extensive mocking); the smoke test in phase (e) exercises run_once
end-to-end with a stub invoker.
"""

from __future__ import annotations

from producer.cli import main


def test_init_creates_scaffold(tmp_path):
    rc = main(["init", "--dir", str(tmp_path), "--no-chat"])
    assert rc == 0
    assert (tmp_path / "producer.yaml").exists()
    assert (tmp_path / "agent-state" / "ledger.db").exists()
    assert (tmp_path / "agents" / "producer" / "system_prompt.md").exists()
    assert (tmp_path / "agents" / "code" / "system_prompt.md").exists()
    assert (tmp_path / "agents" / "qa" / "system_prompt.md").exists()
    # seed example dropped at project_root
    assert (tmp_path / "seed_tasks.example.json").exists()


def test_init_refuses_to_overwrite(tmp_path):
    rc = main(["init", "--dir", str(tmp_path), "--no-chat"])
    assert rc == 0
    rc2 = main(["init", "--dir", str(tmp_path), "--no-chat"])
    assert rc2 == 2  # refuses without --force


def test_init_force_overwrites(tmp_path):
    rc = main(["init", "--dir", str(tmp_path), "--no-chat"])
    assert rc == 0
    rc2 = main(["init", "--dir", str(tmp_path), "--force", "--no-chat"])
    assert rc2 == 0


def test_init_renders_prompt_with_role_substitution(tmp_path):
    main(["init", "--dir", str(tmp_path), "--no-chat"])
    prompt = (tmp_path / "agents" / "code" / "system_prompt.md").read_text()
    assert "Code Agent" in prompt
    # project_name now derives from the target dir basename.
    assert tmp_path.name in prompt


def test_init_yaml_has_basename_project_name(tmp_path):
    main(["init", "--dir", str(tmp_path), "--no-chat"])
    yaml_text = (tmp_path / "producer.yaml").read_text()
    assert f"project_name: {tmp_path.name}" in yaml_text
    # Placeholders must not survive substitution.
    assert "$project_name" not in yaml_text
    assert "$ntfy_topic" not in yaml_text
    assert "$subject_prefix" not in yaml_text


def test_task_add_and_list(tmp_path, capsys):
    main(["init", "--dir", str(tmp_path), "--no-chat"])
    capsys.readouterr()  # drain init output
    cfg_path = str(tmp_path / "producer.yaml")
    rc = main(
        [
            "--config",
            cfg_path,
            "task",
            "add",
            "--agent",
            "code",
            "--title",
            "build something",
            "--description",
            "do the thing",
            "--priority",
            "2",
        ]
    )
    assert rc == 0
    tid = capsys.readouterr().out.strip()
    assert tid

    rc = main(["--config", cfg_path, "task", "list"])
    assert rc == 0
    out = capsys.readouterr().out
    assert tid in out
    assert "build something" in out
    assert "[code]" in out


def test_task_list_empty(tmp_path, capsys):
    main(["init", "--dir", str(tmp_path), "--no-chat"])
    capsys.readouterr()  # drain init output
    rc = main(["--config", str(tmp_path / "producer.yaml"), "task", "list"])
    assert rc == 0
    assert "(no tasks with status=pending)" in capsys.readouterr().out


def test_task_add_with_payload_and_deps(tmp_path, capsys):
    main(["init", "--dir", str(tmp_path), "--no-chat"])
    capsys.readouterr()  # drain init output
    cfg_path = str(tmp_path / "producer.yaml")
    rc = main(
        [
            "--config",
            cfg_path,
            "task",
            "add",
            "--agent",
            "code",
            "--title",
            "t1",
            "--description",
            "first",
        ]
    )
    assert rc == 0
    parent = capsys.readouterr().out.strip()
    rc = main(
        [
            "--config",
            cfg_path,
            "task",
            "add",
            "--agent",
            "code",
            "--title",
            "t2",
            "--description",
            "second",
            "--dependencies",
            parent,
            "--payload",
            '{"k":"v"}',
        ]
    )
    assert rc == 0


def test_kill_and_resume(tmp_path):
    main(["init", "--dir", str(tmp_path), "--no-chat"])
    cfg_path = str(tmp_path / "producer.yaml")
    rc = main(["--config", cfg_path, "kill", "test reason"])
    assert rc == 0
    ks_path = tmp_path / "agent-state" / "kill_switch"
    assert ks_path.read_text().strip() == "1"
    rc = main(["--config", cfg_path, "resume"])
    assert rc == 0
    assert ks_path.read_text().strip() == "0"


def test_report_writes_file(tmp_path, capsys):
    main(["init", "--dir", str(tmp_path), "--no-chat"])
    capsys.readouterr()  # drain init output
    cfg_path = str(tmp_path / "producer.yaml")
    rc = main(["--config", cfg_path, "report", "--date", "2026-05-06"])
    assert rc == 0
    out = capsys.readouterr().out.strip()
    expected = tmp_path / "agent-state" / "morning-report-20260506.md"
    assert str(expected) == out
    assert expected.exists()
    assert "Morning Report 2026-05-06" in expected.read_text()


def test_pricing_update_subcommand_wired(monkeypatch, capsys):
    """`producer pricing update --dry-run` invokes the updater and prints diff."""
    from producer import cli, pricing_updater

    captured = {"called": False}

    async def fake_update(*, dry_run, runner=None, cwd=None):
        captured["called"] = True
        captured["dry_run"] = dry_run
        return {"claude-opus-4-7": {"input_per_mtok_usd": (15.0, 16.0)}}

    monkeypatch.setattr(pricing_updater, "update_pricing", fake_update)

    rc = cli.main(["pricing", "update", "--dry-run"])
    out = capsys.readouterr().out
    assert rc == 0
    assert captured["called"] is True
    assert captured["dry_run"] is True
    assert "claude-opus-4-7" in out
