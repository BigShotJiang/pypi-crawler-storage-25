"""Tests for producer.dispatch — Producer class core flow.

Covers: dispatch happy path, retry-then-escalate, kill-switch halt,
unknown-role escalation, and budget pre-check refusal.
"""

from __future__ import annotations

import pytest

from producer.dispatch import MAX_RETRIES_PER_TASK, Producer
from producer.invoker import InvocationResult
from producer.kill_switch import KillSwitchWatcher
from producer.ledger import LedgerClient
from tests.conftest import FailingInvoker, FakeInvoker, make_test_config


def _make_producer(tmp_path, *, invoker=None, **cfg_overrides):
    cfg = make_test_config(tmp_path, **cfg_overrides)
    ledger = LedgerClient(db_path=cfg.ledger_db)
    inv = invoker or FakeInvoker()
    producer = Producer(
        config=cfg,
        ledger=ledger,
        invoker=inv,
        kill_switch=KillSwitchWatcher(path=cfg.kill_switch),
    )
    return producer, cfg, ledger, inv


# ---------------------------------------------------------------------------
# Happy path
# ---------------------------------------------------------------------------


async def test_dispatch_completes_a_task(tmp_path):
    invoker = FakeInvoker(InvocationResult(text="done", cost_usd=0.02))
    producer, cfg, ledger, inv = _make_producer(tmp_path, invoker=invoker)
    tid = ledger.insert_task(agent_owner="echo", title="t", description="d")
    n = await producer.run_once()
    assert n == 1
    task = ledger.get_task(tid)
    assert task.status == "done"
    assert inv.calls[0][0] == "echo"
    # Producer's own reservation cost recorded
    spent_producer, _, _ = ledger.budget_state(
        "producer", hard_cap_usd=2.0, soft_cap_ratio=0.8
    )
    assert spent_producer > 0
    # Echo's actual cost recorded
    spent_echo, _, _ = ledger.budget_state(
        "echo", hard_cap_usd=5.0, soft_cap_ratio=0.8
    )
    assert spent_echo == pytest.approx(0.02)


async def test_dispatch_records_decision_row(tmp_path):
    producer, cfg, ledger, _ = _make_producer(tmp_path)
    ledger.insert_task(agent_owner="echo", title="t", description="d")
    await producer.run_once()
    rows = ledger.conn.execute(
        "SELECT kind, agent_owner FROM decisions WHERE kind='dispatch'"
    ).fetchall()
    assert len(rows) == 1
    assert rows[0]["agent_owner"] == "producer"


async def test_run_once_returns_zero_when_queue_empty(tmp_path):
    producer, *_ = _make_producer(tmp_path)
    n = await producer.run_once()
    assert n == 0


# ---------------------------------------------------------------------------
# Failure / retry / escalation
# ---------------------------------------------------------------------------


async def test_failure_retries_then_escalates(tmp_path, monkeypatch):
    monkeypatch.delenv("NTFY_TOPIC", raising=False)
    producer, cfg, ledger, inv = _make_producer(tmp_path, invoker=FailingInvoker())
    tid = ledger.insert_task(agent_owner="echo", title="t", description="d")

    for _ in range(MAX_RETRIES_PER_TASK):
        await producer.run_once()

    task = ledger.get_task(tid)
    assert task.status == "escalated"
    assert (cfg.escalations_dir / f"{tid}.md").exists()
    body = (cfg.escalations_dir / f"{tid}.md").read_text()
    assert "Escalation:" in body
    assert task.id in body


async def test_failure_audit_records(tmp_path):
    producer, cfg, ledger, inv = _make_producer(tmp_path, invoker=FailingInvoker())
    ledger.insert_task(agent_owner="echo", title="t", description="d")
    await producer.run_once()
    rows = ledger.conn.execute(
        "SELECT action FROM audit_log WHERE action='task_failed'"
    ).fetchall()
    assert len(rows) == 1


# ---------------------------------------------------------------------------
# Kill switch
# ---------------------------------------------------------------------------


async def test_kill_switch_halts_dispatch(tmp_path):
    producer, cfg, ledger, _ = _make_producer(tmp_path)
    producer.kill_switch.arm("test")
    ledger.insert_task(agent_owner="echo", title="t", description="d")
    n = await producer.run_once()
    assert n == 0
    rows = ledger.conn.execute(
        "SELECT action FROM audit_log WHERE action='kill_switch_observed'"
    ).fetchall()
    assert len(rows) >= 1


# ---------------------------------------------------------------------------
# Unknown role
# ---------------------------------------------------------------------------


async def test_unknown_role_escalates(tmp_path):
    producer, cfg, ledger, _ = _make_producer(tmp_path)
    tid = ledger.insert_task(agent_owner="ghost", title="t", description="d")
    await producer.run_once()
    task = ledger.get_task(tid)
    assert task.status == "escalated"
    assert "unknown" in (task.escalation_reason or "")


# ---------------------------------------------------------------------------
# Pre-dispatch budget reservation (load-bearing)
# ---------------------------------------------------------------------------


async def test_budget_breach_pre_dispatch_escalates_without_invoking(tmp_path):
    """Crank the project ceiling so low that the very first reservation
    can't fit. Verify the task escalates and the invoker is never called."""
    producer, cfg, ledger, inv = _make_producer(
        tmp_path,
        invoker=FakeInvoker(),
        project_ceiling_usd=0.0001,  # smaller than producer reservation 0.01
    )
    tid = ledger.insert_task(agent_owner="echo", title="t", description="d")
    await producer.run_once()
    task = ledger.get_task(tid)
    assert task.status == "escalated"
    assert "budget" in (task.escalation_reason or "").lower()
    assert inv.calls == []  # invoker never reached


# ---------------------------------------------------------------------------
# System-prompt loading
# ---------------------------------------------------------------------------


async def test_dispatch_loads_system_prompt_when_configured(tmp_path):
    producer, cfg, ledger, inv = _make_producer(tmp_path)
    # configure a prompt path and create the file
    cfg.roles["echo"].prompt = "agents/echo/sp.md"
    sp_path = cfg.project_root / "agents" / "echo" / "sp.md"
    sp_path.parent.mkdir(parents=True, exist_ok=True)
    sp_path.write_text("# Echo system prompt\nYou echo back.")
    ledger.insert_task(agent_owner="echo", title="t", description="d")
    await producer.run_once()
    # The system prompt is consumed by the invoker — the test invoker doesn't
    # capture it, but the lack of FileNotFoundError means it was loaded.
    task = ledger.conn.execute("SELECT status FROM tasks LIMIT 1").fetchone()
    assert task["status"] == "done"


async def test_dispatch_raises_when_configured_prompt_missing(tmp_path):
    """Configured prompt path that doesn't exist should fail dispatch loud
    (then go through normal failure handling: requeue + audit)."""
    producer, cfg, ledger, inv = _make_producer(tmp_path)
    cfg.roles["echo"].prompt = "agents/echo/missing.md"
    tid = ledger.insert_task(agent_owner="echo", title="t", description="d")
    # First run: invoker raises FileNotFoundError before invoking. Producer
    # converts that to a fail (retry).
    await producer.run_once()
    task = ledger.get_task(tid)
    # After 1 failure: requeued back to pending, retry_count=1.
    assert task.retry_count == 1


# ---------------------------------------------------------------------------
# Output ref extraction
# ---------------------------------------------------------------------------


async def test_dispatch_extracts_write_paths_as_output_refs(tmp_path):
    invoker = FakeInvoker(
        InvocationResult(
            text="done",
            cost_usd=0.01,
            tool_calls=[
                {"name": "Write", "input": {"file_path": "/proj/file.txt"}},
                {"name": "Read", "input": {"file_path": "/proj/other.txt"}},  # not a write
                {"name": "Edit", "input": {"file_path": "/proj/edited.txt"}},
            ],
        )
    )
    producer, cfg, ledger, _ = _make_producer(tmp_path, invoker=invoker)
    tid = ledger.insert_task(agent_owner="echo", title="t", description="d")
    await producer.run_once()
    task = ledger.get_task(tid)
    assert "/proj/file.txt" in task.output_refs
    assert "/proj/edited.txt" in task.output_refs
    assert "/proj/other.txt" not in task.output_refs


# ---------------------------------------------------------------------------
# Cost persistence (Task 7)
# ---------------------------------------------------------------------------


async def test_dispatch_persists_both_costs_api_mode(tmp_path):
    """API mode: both computed_cost_usd and actual_cost_usd are persisted."""
    result = InvocationResult(
        text="done",
        cost_usd=0.03,
        computed_cost_usd=0.03,
        actual_cost_usd=0.025,
        auth_mode="api",
    )
    invoker = FakeInvoker(result)
    producer, cfg, ledger, _ = _make_producer(tmp_path, invoker=invoker)
    tid = ledger.insert_task(agent_owner="echo", title="t", description="d")
    await producer.run_once()
    task = ledger.get_task(tid)
    assert task.status == "done"
    assert task.cost_usd == pytest.approx(result.computed_cost_usd)
    assert task.actual_cost_usd == pytest.approx(result.actual_cost_usd)


async def test_dispatch_persists_cost_subscription_mode_actual_is_null(tmp_path):
    """Subscription mode: computed_cost_usd is persisted; actual_cost_usd is NULL."""
    result = InvocationResult(
        text="done",
        cost_usd=0.02,
        computed_cost_usd=0.02,
        actual_cost_usd=None,
        auth_mode="subscription",
    )
    invoker = FakeInvoker(result)
    producer, cfg, ledger, _ = _make_producer(tmp_path, invoker=invoker)
    tid = ledger.insert_task(agent_owner="echo", title="t", description="d")
    await producer.run_once()
    task = ledger.get_task(tid)
    assert task.status == "done"
    assert task.cost_usd == pytest.approx(result.computed_cost_usd)
    assert task.actual_cost_usd is None


# ---------------------------------------------------------------------------
# Pricing staleness check (Task 10)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_producer_writes_needs_attention_when_pricing_stale(
    tmp_path, monkeypatch
):
    """At startup, stale pricing → needs-attention.md gets a clear note."""
    from producer import pricing

    monkeypatch.setattr(pricing, "is_stale", lambda now=None: (True, 95))

    producer, cfg, ledger, inv = _make_producer(tmp_path)
    await producer.run_once()

    needs = (cfg.reports_dir / "needs-attention.md").read_text(encoding="utf-8")
    assert "pricing table is 95 days old" in needs
    assert "producer pricing update" in needs


@pytest.mark.asyncio
async def test_producer_no_needs_attention_when_pricing_fresh(
    tmp_path, monkeypatch
):
    from producer import pricing

    monkeypatch.setattr(pricing, "is_stale", lambda now=None: (False, 5))

    producer, cfg, ledger, inv = _make_producer(tmp_path)
    await producer.run_once()

    needs = cfg.reports_dir / "needs-attention.md"
    if needs.exists():
        assert "pricing table" not in needs.read_text(encoding="utf-8")


# ---------------------------------------------------------------------------
# Startup banner (Task 8)
# ---------------------------------------------------------------------------


class TestStartupBanner:
    """Producer logs a one-line banner showing auth+isolation mode at boot."""

    async def test_run_once_logs_banner(self, tmp_path, caplog):
        import logging
        from producer import (
            KillSwitchWatcher, LedgerClient, Producer, load_config,
        )
        # Reuse the smoke-test echo project builder for minimal config.
        from tests.test_smoke_echo_agent import _build_echo_project, StubEchoInvoker

        cfg_path = _build_echo_project(tmp_path)
        cfg = load_config(cfg_path)
        ledger = LedgerClient(db_path=cfg.ledger_db)
        invoker = StubEchoInvoker()
        # Simulate a real invoker's mode reporting via duck-typed attrs.
        invoker.auth_mode = "subscription"
        invoker.config_isolation = "inherit"

        producer = Producer(
            config=cfg, ledger=ledger, invoker=invoker,
            kill_switch=KillSwitchWatcher(path=cfg.kill_switch),
        )

        caplog.set_level(logging.INFO, logger="producer.dispatch")
        await producer.run_once()
        ledger.close()

        banner_lines = [
            r.message for r in caplog.records
            if "auth=" in r.message and "isolation=" in r.message
        ]
        assert len(banner_lines) >= 1, "expected a startup banner"
        assert "auth=subscription" in banner_lines[0]
        assert "isolation=inherit" in banner_lines[0]


class TestCompletionConfigIsolation:
    """handle_completion persists config_isolation and writes it to audit."""

    async def test_config_isolation_in_audit_event(self, tmp_path):
        import json
        from producer import (
            InvocationResult, KillSwitchWatcher, LedgerClient, Producer, load_config,
        )
        from tests.test_smoke_echo_agent import _build_echo_project

        cfg_path = _build_echo_project(tmp_path)
        cfg = load_config(cfg_path)
        ledger = LedgerClient(db_path=cfg.ledger_db)

        class CapturingInvoker:
            auth_mode = "subscription"
            config_isolation = "inherit"
            calls: list = []

            async def invoke(self, agent_role, prompt, **kwargs):
                self.calls.append((agent_role, prompt))
                return InvocationResult(
                    text="ok",
                    cost_usd=0.001,
                    computed_cost_usd=0.001,
                    auth_mode="subscription",
                    config_isolation="inherit",
                )

        ledger.insert_task(agent_owner="echo", title="t", description="d")
        producer = Producer(
            config=cfg, ledger=ledger, invoker=CapturingInvoker(),
            kill_switch=KillSwitchWatcher(path=cfg.kill_switch),
        )
        await producer.run_once()

        rows = list(ledger.conn.execute(
            "SELECT detail FROM audit_log WHERE action='task_completed'"
        ))
        assert len(rows) == 1
        payload = json.loads(rows[0]["detail"])
        assert payload["config_isolation"] == "inherit"

        # Also assert it landed on the task row.
        done = ledger.conn.execute(
            "SELECT config_isolation FROM tasks WHERE status='done'"
        ).fetchone()
        assert done["config_isolation"] == "inherit"

        ledger.close()
