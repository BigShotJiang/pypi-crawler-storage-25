"""Tests for producer.onboarding — pure functions backing the init wizard."""

from __future__ import annotations

from pathlib import Path

from producer import onboarding


def test_preflight_claude_on_path_true_when_present(monkeypatch):
    monkeypatch.setattr("shutil.which", lambda name: "/usr/local/bin/claude" if name == "claude" else None)
    assert onboarding.preflight_claude_on_path() is True


def test_preflight_claude_on_path_false_when_missing(monkeypatch):
    monkeypatch.setattr("shutil.which", lambda name: None)
    assert onboarding.preflight_claude_on_path() is False


def test_build_claude_argv_includes_append_system_prompt():
    argv = onboarding.build_claude_argv(_project_root="/tmp/myproj")
    # Must start with the binary name (execvp uses argv[0] as program name).
    assert argv[0] == "claude"
    # System-prompt pointer is present.
    assert "--append-system-prompt" in argv
    idx = argv.index("--append-system-prompt")
    pointer = argv[idx + 1]
    assert "ONBOARDING.md" in pointer


def test_build_claude_argv_uses_accept_edits_permission_mode():
    argv = onboarding.build_claude_argv(_project_root="/tmp/myproj")
    assert "--permission-mode" in argv
    idx = argv.index("--permission-mode")
    assert argv[idx + 1] == "acceptEdits"


def test_build_claude_argv_ignores_project_root():
    """The ``_project_root`` parameter is reserved but currently unused — argv must not depend on it."""
    a = onboarding.build_claude_argv(_project_root="/tmp/a")
    b = onboarding.build_claude_argv(_project_root="/tmp/b")
    assert a == b


def test_render_onboarding_md_substitutes_placeholders():
    body = onboarding.render_onboarding_md(
        project_name="my-cool-thing",
        project_root="/tmp/cool",
    )
    assert "Bootstrap chat for my-cool-thing" in body
    assert "/tmp/cool/producer.yaml" in body
    # Placeholders should not leak through.
    assert "$project_name" not in body
    assert "$project_root" not in body


def test_render_onboarding_md_contains_required_sections():
    body = onboarding.render_onboarding_md(
        project_name="x", project_root="/tmp/x"
    )
    # The agent-facing brief must include these load-bearing sections.
    for needle in (
        "What is ai-producer",
        "Files in scope",
        "Discovery",
        "Role design",
        "Seeding",
        "Conventions you must follow",
        "Done signal",
        "LedgerClient.insert_task",
    ):
        assert needle in body, f"missing: {needle}"


def test_default_settings_derives_from_dir():
    s = onboarding.default_settings(target_root=Path("/tmp/my-cool-project"))
    assert s["project_name"] == "my-cool-project"
    # ntfy topic includes project name and a short random suffix.
    assert s["ntfy_topic"].startswith("my-cool-project-")
    assert len(s["ntfy_topic"]) > len("my-cool-project-")
    assert s["subject_prefix"] == "my-cool-project"


def test_default_settings_handles_dot_dir():
    """Unresolved ``Path('.')`` has empty .name; fallback to 'my-project'."""
    s = onboarding.default_settings(target_root=Path("."))
    assert s["project_name"] == "my-project"
    assert s["ntfy_topic"].startswith("my-project-")
    assert s["subject_prefix"] == "my-project"


def test_prompt_for_settings_uses_input_when_tty(monkeypatch):
    answers = iter(["my-app", "my-app-topic-abc123", "MyApp"])
    monkeypatch.setattr("builtins.input", lambda prompt="": next(answers))
    s = onboarding.prompt_for_settings(
        defaults={"project_name": "foo", "ntfy_topic": "foo-x", "subject_prefix": "foo"},
        is_tty=True,
    )
    assert s == {
        "project_name": "my-app",
        "ntfy_topic": "my-app-topic-abc123",
        "subject_prefix": "MyApp",
    }


def test_prompt_for_settings_accepts_blank_to_use_default(monkeypatch):
    answers = iter(["", "", ""])
    monkeypatch.setattr("builtins.input", lambda prompt="": next(answers))
    defaults = {"project_name": "foo", "ntfy_topic": "foo-x", "subject_prefix": "foo"}
    s = onboarding.prompt_for_settings(defaults=defaults, is_tty=True)
    assert s == defaults


def test_prompt_for_settings_skips_when_not_tty(monkeypatch):
    """Non-TTY (pytest, CI) must never call input() — defaults straight through."""
    def boom(*_a, **_kw):
        raise AssertionError("input() called when stdin is not a TTY")
    monkeypatch.setattr("builtins.input", boom)
    defaults = {"project_name": "foo", "ntfy_topic": "foo-x", "subject_prefix": "foo"}
    s = onboarding.prompt_for_settings(defaults=defaults, is_tty=False)
    assert s == defaults


def test_prompt_for_settings_auto_detects_non_tty(monkeypatch):
    """is_tty=None in a pytest run (non-TTY) must not call input()."""
    def boom(*_a, **_kw):
        raise AssertionError("input() called when stdin is not a TTY")
    monkeypatch.setattr("builtins.input", boom)
    defaults = {"project_name": "foo", "ntfy_topic": "foo-x", "subject_prefix": "foo"}
    s = onboarding.prompt_for_settings(defaults=defaults)  # is_tty omitted
    assert s == defaults
