"""Tests for the interactive wizard layer in ``producer init``.

Plain integration tests through ``cli.main(...)``. We don't exercise the
``os.execvp`` handoff itself here — that's a one-line wrapper covered by
mocking in Task 8's tests.
"""

from __future__ import annotations

import yaml

from producer.cli import main


class _FakeTTY:
    """Minimal stand-in for ``sys.stdin`` whose ``isatty()`` returns True."""

    def isatty(self) -> bool:
        return True


def test_init_non_interactive_uses_basename_for_project_name(tmp_path):
    target = tmp_path / "writing-app"
    target.mkdir()
    rc = main(["init", "--dir", str(target), "--non-interactive", "--no-chat"])
    assert rc == 0
    cfg = yaml.safe_load((target / "producer.yaml").read_text())
    assert cfg["project_name"] == "writing-app"
    assert cfg["notifications"]["ntfy_topic"].startswith("writing-app-")
    # No CHANGEME sentinel left behind.
    assert "CHANGEME" not in (target / "producer.yaml").read_text()


def test_init_writes_onboarding_md(tmp_path):
    target = tmp_path / "writing-app"
    target.mkdir()
    rc = main(["init", "--dir", str(target), "--non-interactive", "--no-chat"])
    assert rc == 0
    onboarding_md = target / "ONBOARDING.md"
    assert onboarding_md.exists()
    body = onboarding_md.read_text()
    assert "Bootstrap chat for writing-app" in body
    assert "LedgerClient.insert_task" in body


def test_init_interactive_prompts_use_input(tmp_path, monkeypatch):
    """Simulate an interactive TTY with three answers."""
    answers = iter(["custom-name", "custom-topic-xyz", "Custom"])
    monkeypatch.setattr("builtins.input", lambda prompt="": next(answers))
    monkeypatch.setattr("sys.stdin", _FakeTTY())

    target = tmp_path / "writing-app"
    target.mkdir()
    rc = main(["init", "--dir", str(target), "--no-chat"])
    assert rc == 0
    cfg = yaml.safe_load((target / "producer.yaml").read_text())
    assert cfg["project_name"] == "custom-name"
    assert cfg["notifications"]["ntfy_topic"] == "custom-topic-xyz"
    assert cfg["notifications"]["subject_prefix"] == "Custom"


def test_init_skips_handoff_when_no_chat(tmp_path, monkeypatch):
    """--no-chat must not call execvp at all."""
    calls = []
    monkeypatch.setattr("os.execvp", lambda f, a: calls.append((f, a)))
    target = tmp_path / "p"
    target.mkdir()
    rc = main(["init", "--dir", str(target), "--non-interactive", "--no-chat"])
    assert rc == 0
    assert calls == []


def test_init_skips_handoff_when_claude_missing(tmp_path, monkeypatch, capsys):
    """If claude is not on PATH, scaffold but skip handoff with a friendly message."""
    monkeypatch.setattr("shutil.which", lambda name: None)
    calls = []
    monkeypatch.setattr("os.execvp", lambda f, a: calls.append((f, a)))
    target = tmp_path / "p"
    target.mkdir()
    rc = main(["init", "--dir", str(target), "--non-interactive"])
    assert rc == 0
    assert calls == []  # never attempted execvp
    out = capsys.readouterr().out
    assert "claude" in out.lower()  # message mentions the missing binary


def test_init_calls_execvp_when_claude_present(tmp_path, monkeypatch):
    """Happy path: claude on PATH + interactive run + no --no-chat → execvp fires."""
    monkeypatch.setattr("shutil.which", lambda name: "/usr/local/bin/claude")
    calls = []
    monkeypatch.setattr("os.execvp", lambda f, a: calls.append((f, a)))
    target = tmp_path / "p"
    target.mkdir()
    rc = main(["init", "--dir", str(target), "--non-interactive"])
    assert rc == 0
    assert len(calls) == 1
    file_arg, argv = calls[0]
    assert file_arg == "claude"
    assert argv[0] == "claude"
    assert "--append-system-prompt" in argv
    assert "--permission-mode" in argv


def test_init_handles_execvp_failure_gracefully(tmp_path, monkeypatch, capsys):
    """OSError from execvp: print friendly message, return 0 (scaffold work is durable)."""
    monkeypatch.setattr("shutil.which", lambda name: "/usr/local/bin/claude")

    def boom(_f, _a):
        raise OSError("[Errno 2] No such file or directory: 'claude'")
    monkeypatch.setattr("os.execvp", boom)

    target = tmp_path / "p"
    target.mkdir()
    rc = main(["init", "--dir", str(target), "--non-interactive"])
    assert rc == 0
    out = capsys.readouterr().out
    assert "scaffolding succeeded" in out.lower() or "run `claude`" in out.lower()
