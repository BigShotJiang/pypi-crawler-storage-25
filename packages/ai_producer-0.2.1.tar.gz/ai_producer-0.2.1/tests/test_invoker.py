"""Tests for producer.invoker — CLAUDE_CONFIG_DIR isolation + no-output detection.

The no-productive-output behavior is the load-bearing piece: when the SDK
exits non-zero without streaming any text or tool calls, ``invoke`` MUST
re-raise so the dispatcher's retry loop fires.
"""

from __future__ import annotations

import os
import sys
import types
from pathlib import Path

import pytest

from producer.invoker import ClaudeAgentInvoker, InvocationResult, _resolve_isolation_mode


# ---------------------------------------------------------------------------
# _resolve_isolation_mode — pure function
# ---------------------------------------------------------------------------


class TestResolveIsolationMode:
    """Pure function: priority is env_override > config_value > auto-detect."""

    def test_env_override_inherit_beats_config(self, tmp_path):
        result = _resolve_isolation_mode(
            config_value="isolated",
            env_override="inherit",
            has_api_key=True,
            credentials_path=tmp_path / "no.json",
        )
        assert result == "inherit"

    def test_env_override_isolated_beats_config(self, tmp_path):
        result = _resolve_isolation_mode(
            config_value="inherit",
            env_override="isolated",
            has_api_key=False,
            credentials_path=tmp_path / "no.json",
        )
        assert result == "isolated"

    def test_invalid_env_override_raises(self, tmp_path):
        with pytest.raises(ValueError, match="PRODUCER_AUTH_MODE"):
            _resolve_isolation_mode(
                config_value="auto",
                env_override="nonsense",
                has_api_key=True,
                credentials_path=tmp_path / "no.json",
            )

    def test_explicit_config_inherit_used_when_no_env(self, tmp_path):
        result = _resolve_isolation_mode(
            config_value="inherit",
            env_override=None,
            has_api_key=True,
            credentials_path=tmp_path / "no.json",
        )
        assert result == "inherit"

    def test_explicit_config_isolated_used_when_no_env(self, tmp_path):
        result = _resolve_isolation_mode(
            config_value="isolated",
            env_override=None,
            has_api_key=False,
            credentials_path=tmp_path / "no.json",
        )
        assert result == "isolated"

    def test_auto_picks_isolated_when_api_key_present(self, tmp_path):
        result = _resolve_isolation_mode(
            config_value="auto",
            env_override=None,
            has_api_key=True,
            credentials_path=tmp_path / "no.json",
        )
        assert result == "isolated"

    def test_auto_picks_isolated_when_credentials_file_exists(self, tmp_path):
        creds = tmp_path / ".credentials.json"
        creds.write_text("{}")
        result = _resolve_isolation_mode(
            config_value="auto",
            env_override=None,
            has_api_key=False,
            credentials_path=creds,
        )
        assert result == "isolated"

    def test_auto_picks_inherit_when_neither_present(self, tmp_path, caplog):
        import logging
        caplog.set_level(logging.WARNING, logger="producer.invoker")
        result = _resolve_isolation_mode(
            config_value="auto",
            env_override=None,
            has_api_key=False,
            credentials_path=tmp_path / "no.json",
        )
        assert result == "inherit"
        assert any(
            "inherit" in record.message and "isolation disabled" in record.message
            for record in caplog.records
        ), "expected a WARN log explaining the auto fallback"


# ---------------------------------------------------------------------------
# InvocationResult shape
# ---------------------------------------------------------------------------


def test_invocation_result_defaults():
    r = InvocationResult(text="hi", cost_usd=0.01)
    assert r.text == "hi"
    assert r.cost_usd == 0.01
    assert r.tool_calls == []
    assert r.raw_messages == []
    assert r.sdk_error is None


def test_invocation_result_cost_alias_syncs_both_directions():
    """`cost_usd` and `computed_cost_usd` mirror each other when only one is set."""
    from producer.invoker import InvocationResult
    r1 = InvocationResult(text="x", cost_usd=0.5)
    assert r1.computed_cost_usd == 0.5
    r2 = InvocationResult(text="y", cost_usd=0.0, computed_cost_usd=0.7)
    assert r2.cost_usd == 0.7
    # Both explicitly provided — both honored, no overwrite
    r3 = InvocationResult(text="z", cost_usd=0.3, computed_cost_usd=0.4)
    assert r3.cost_usd == 0.3
    assert r3.computed_cost_usd == 0.4


# ---------------------------------------------------------------------------
# CLAUDE_CONFIG_DIR isolation (load-bearing)
# ---------------------------------------------------------------------------


def test_invoker_sets_claude_config_dir(monkeypatch, tmp_path):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")
    target = tmp_path / "isolated-claude"
    ClaudeAgentInvoker(cwd=tmp_path, config_dir=target)
    assert os.environ["CLAUDE_CONFIG_DIR"] == str(target.resolve())
    assert target.exists()


def test_invoker_default_config_dir_under_cwd(monkeypatch, tmp_path):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")
    ClaudeAgentInvoker(cwd=tmp_path)
    expected = (tmp_path / "agent-state" / ".claude").resolve()
    assert os.environ["CLAUDE_CONFIG_DIR"] == str(expected)
    assert expected.exists()


def test_invoker_requires_api_key(monkeypatch, tmp_path):
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    monkeypatch.setenv("PRODUCER_AUTH_MODE", "isolated")
    fake_home = tmp_path / "home"
    fake_home.mkdir()
    monkeypatch.setattr("pathlib.Path.home", lambda: fake_home)
    with pytest.raises(RuntimeError, match="ANTHROPIC_API_KEY"):
        ClaudeAgentInvoker(cwd=tmp_path)


def test_invoker_accepts_explicit_api_key(monkeypatch, tmp_path):
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    inv = ClaudeAgentInvoker(cwd=tmp_path, api_key="explicit-key")
    assert inv.api_key == "explicit-key"


def test_invoker_default_permission_mode(monkeypatch, tmp_path):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")
    inv = ClaudeAgentInvoker(cwd=tmp_path)
    assert inv.permission_mode == "acceptEdits"


# ---------------------------------------------------------------------------
# ClaudeAgentInvoker: isolated vs inherit mode integration
# ---------------------------------------------------------------------------


class TestInvokerIsolatedMode:
    """In isolated mode, today's behavior is preserved."""

    def test_isolated_mode_sets_config_dir_env(self, tmp_path, monkeypatch):
        from producer.invoker import ClaudeAgentInvoker
        monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")
        monkeypatch.delenv("PRODUCER_AUTH_MODE", raising=False)
        inv = ClaudeAgentInvoker(cwd=tmp_path)
        assert inv.config_isolation == "isolated"
        assert os.environ.get("CLAUDE_CONFIG_DIR") == str(inv.config_dir)
        assert inv.permission_mode == "acceptEdits"

    def test_isolated_mode_uses_acceptedits_permission(self, tmp_path, monkeypatch):
        from producer.invoker import ClaudeAgentInvoker
        monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")
        monkeypatch.delenv("PRODUCER_AUTH_MODE", raising=False)
        inv = ClaudeAgentInvoker(cwd=tmp_path)
        assert inv.permission_mode == "acceptEdits"


class TestInvokerInheritMode:
    """Inherit mode skips the symlink and the config dir override."""

    def test_inherit_mode_does_not_set_config_dir(self, tmp_path, monkeypatch):
        from producer.invoker import ClaudeAgentInvoker
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
        monkeypatch.setenv("PRODUCER_AUTH_MODE", "inherit")
        # Even if a stale CLAUDE_CONFIG_DIR is set, inherit mode unsets it.
        monkeypatch.setenv("CLAUDE_CONFIG_DIR", "/some/stale/path")
        inv = ClaudeAgentInvoker(cwd=tmp_path)
        assert inv.config_isolation == "inherit"
        assert "CLAUDE_CONFIG_DIR" not in os.environ
        assert inv.permission_mode == "bypassPermissions"
        assert inv.auth_mode == "subscription"  # no API key

    def test_inherit_mode_with_api_key_keeps_api_auth(self, tmp_path, monkeypatch):
        from producer.invoker import ClaudeAgentInvoker
        monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")
        monkeypatch.setenv("PRODUCER_AUTH_MODE", "inherit")
        inv = ClaudeAgentInvoker(cwd=tmp_path)
        assert inv.config_isolation == "inherit"
        assert inv.auth_mode == "api"

    def test_inherit_mode_skips_symlink_setup(self, tmp_path, monkeypatch):
        """Even with no .credentials.json, inherit mode must not raise."""
        from producer.invoker import ClaudeAgentInvoker
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
        monkeypatch.setenv("PRODUCER_AUTH_MODE", "inherit")
        # Point at a fake home with no credentials file.
        fake_home = tmp_path / "fake_home"
        fake_home.mkdir()
        monkeypatch.setattr("pathlib.Path.home", lambda: fake_home)
        inv = ClaudeAgentInvoker(cwd=tmp_path)  # must not raise
        assert inv.config_isolation == "inherit"

    def test_explicit_isolated_with_no_creds_still_raises(self, tmp_path, monkeypatch):
        """Improved error message lists all 3 options."""
        from producer.invoker import ClaudeAgentInvoker
        monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
        monkeypatch.setenv("PRODUCER_AUTH_MODE", "isolated")
        fake_home = tmp_path / "fake_home"
        fake_home.mkdir()
        monkeypatch.setattr("pathlib.Path.home", lambda: fake_home)
        with pytest.raises(RuntimeError) as exc_info:
            ClaudeAgentInvoker(cwd=tmp_path)
        msg = str(exc_info.value)
        assert "ANTHROPIC_API_KEY" in msg
        assert "auth.mode: inherit" in msg
        assert "PRODUCER_AUTH_MODE=inherit" in msg


# ---------------------------------------------------------------------------
# Fake SDK fixtures for invoke() tests
# ---------------------------------------------------------------------------


class _FakeAssistantMessage:
    def __init__(self, content):
        self.content = content


class _FakeTextBlock:
    def __init__(self, text: str):
        self.text = text


class _FakeToolUseBlock:
    type = "tool_use"

    def __init__(self, name: str, input: dict):
        self.name = name
        self.input = input


class _FakeOptions:
    def __init__(self, **kwargs):
        self.kwargs = kwargs


def _install_fake_sdk(monkeypatch, query_fn):
    """Install a fake ``claude_agent_sdk`` module with the given query coroutine.

    Returns the fake module so tests can reference its message classes.
    """
    fake = types.ModuleType("claude_agent_sdk")
    fake.AssistantMessage = _FakeAssistantMessage
    fake.TextBlock = _FakeTextBlock
    fake.ClaudeAgentOptions = _FakeOptions
    fake.query = query_fn
    monkeypatch.setitem(sys.modules, "claude_agent_sdk", fake)
    return fake


# ---------------------------------------------------------------------------
# invoke() — no productive output ⇒ raise (load-bearing)
# ---------------------------------------------------------------------------


async def test_invoke_raises_when_sdk_errors_with_no_productive_output(
    monkeypatch, tmp_path
):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")

    async def empty_then_raise(prompt, options):
        if False:  # make this an async generator
            yield
        raise RuntimeError("Command failed with exit code 1")

    _install_fake_sdk(monkeypatch, empty_then_raise)

    inv = ClaudeAgentInvoker(cwd=tmp_path)
    with pytest.raises(RuntimeError, match="exit code 1"):
        await inv.invoke(agent_role="echo", prompt="hi", allowed_tools=[])


async def test_invoke_raises_when_only_system_messages_streamed(
    monkeypatch, tmp_path
):
    """System messages (non-AssistantMessage) populate raw_messages but
    don't count as productive output."""
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")

    async def system_then_raise(prompt, options):
        yield types.SimpleNamespace(type="system", subtype="init")
        yield types.SimpleNamespace(type="system", subtype="hook_started")
        raise RuntimeError("Command failed with exit code 1")

    _install_fake_sdk(monkeypatch, system_then_raise)

    inv = ClaudeAgentInvoker(cwd=tmp_path)
    with pytest.raises(RuntimeError, match="exit code 1"):
        await inv.invoke(agent_role="echo", prompt="hi", allowed_tools=[])


# ---------------------------------------------------------------------------
# invoke() — productive output absorbs the SDK error
# ---------------------------------------------------------------------------


async def test_invoke_absorbs_sdk_error_when_text_was_produced(
    monkeypatch, tmp_path
):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")

    async def text_then_raise(prompt, options):
        yield _FakeAssistantMessage(content=[_FakeTextBlock(text="hello")])
        raise RuntimeError("Command failed with exit code 1")

    _install_fake_sdk(monkeypatch, text_then_raise)

    inv = ClaudeAgentInvoker(cwd=tmp_path)
    result = await inv.invoke(agent_role="echo", prompt="hi", allowed_tools=[])
    assert result.text == "hello"
    assert result.sdk_error is not None
    assert "exit code 1" in result.sdk_error


async def test_invoke_absorbs_sdk_error_when_tool_call_was_made(
    monkeypatch, tmp_path
):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")

    async def tool_then_raise(prompt, options):
        yield _FakeAssistantMessage(
            content=[_FakeToolUseBlock(name="Bash", input={"cmd": "ls"})]
        )
        raise RuntimeError("Command failed with exit code 1")

    _install_fake_sdk(monkeypatch, tool_then_raise)

    inv = ClaudeAgentInvoker(cwd=tmp_path)
    result = await inv.invoke(agent_role="echo", prompt="hi", allowed_tools=["Bash"])
    assert result.tool_calls == [{"name": "Bash", "input": {"cmd": "ls"}}]
    assert result.sdk_error is not None


# ---------------------------------------------------------------------------
# invoke() — normal happy path
# ---------------------------------------------------------------------------


async def test_invoke_normal_path(monkeypatch, tmp_path):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")

    async def normal(prompt, options):
        msg = _FakeAssistantMessage(content=[_FakeTextBlock(text="ok")])
        msg.total_cost_usd = 0.05
        yield msg

    _install_fake_sdk(monkeypatch, normal)

    inv = ClaudeAgentInvoker(cwd=tmp_path)
    result = await inv.invoke(agent_role="echo", prompt="hi", allowed_tools=[])
    assert result.text == "ok"
    assert result.actual_cost_usd == pytest.approx(0.05)
    assert result.sdk_error is None


async def test_invoke_text_chunks_joined_with_newlines(monkeypatch, tmp_path):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")

    async def two_messages(prompt, options):
        yield _FakeAssistantMessage(content=[_FakeTextBlock(text="line one")])
        yield _FakeAssistantMessage(content=[_FakeTextBlock(text="line two")])

    _install_fake_sdk(monkeypatch, two_messages)

    inv = ClaudeAgentInvoker(cwd=tmp_path)
    result = await inv.invoke(agent_role="echo", prompt="hi", allowed_tools=[])
    assert result.text == "line one\nline two"


async def test_invoke_extracts_cost_from_alternate_attrs(monkeypatch, tmp_path):
    """The SDK's cost-bearing field has churned across releases. invoke
    tries total_cost_usd, usage_cost_usd, cost_usd in order."""
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")

    async def alt_cost(prompt, options):
        msg = _FakeAssistantMessage(content=[_FakeTextBlock(text="x")])
        # No total_cost_usd; only usage_cost_usd
        msg.usage_cost_usd = 0.123
        yield msg

    _install_fake_sdk(monkeypatch, alt_cost)

    inv = ClaudeAgentInvoker(cwd=tmp_path)
    result = await inv.invoke(agent_role="echo", prompt="hi", allowed_tools=[])
    assert result.actual_cost_usd == pytest.approx(0.123)


async def test_invoke_passes_options_through(monkeypatch, tmp_path):
    """Verify options propagation: cwd, allowed_tools, max_turns, system_prompt."""
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")
    captured: dict = {}

    async def capture_options(prompt, options):
        captured["prompt"] = prompt
        captured["options"] = options
        if False:
            yield
        raise RuntimeError("Command failed with exit code 1")

    _install_fake_sdk(monkeypatch, capture_options)

    inv = ClaudeAgentInvoker(cwd=tmp_path)
    with pytest.raises(RuntimeError):
        await inv.invoke(
            agent_role="echo",
            prompt="task description",
            system_prompt="you are echo",
            allowed_tools=["Read", "Bash"],
            max_turns=20,
        )
    assert captured["prompt"] == "task description"
    opts = captured["options"]
    assert opts.kwargs["allowed_tools"] == ["Read", "Bash"]
    assert opts.kwargs["max_turns"] == 20
    assert opts.kwargs["system_prompt"] == "you are echo"
    assert opts.kwargs["cwd"] == str(tmp_path.resolve())
    # permission_mode should be set when the fake accepts it
    assert opts.kwargs.get("permission_mode") == "acceptEdits"


async def test_invoke_falls_back_when_options_rejects_permission_mode(
    monkeypatch, tmp_path
):
    """Older SDKs don't accept permission_mode — invoker should retry without it."""
    monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")

    class StrictOptions:
        """Rejects permission_mode kwarg, like an older SDK release."""

        def __init__(self, **kwargs):
            if "permission_mode" in kwargs:
                raise TypeError("unexpected keyword argument 'permission_mode'")
            self.kwargs = kwargs

    async def normal(prompt, options):
        msg = _FakeAssistantMessage(content=[_FakeTextBlock(text="ok")])
        yield msg

    fake = _install_fake_sdk(monkeypatch, normal)
    fake.ClaudeAgentOptions = StrictOptions

    inv = ClaudeAgentInvoker(cwd=tmp_path)
    result = await inv.invoke(agent_role="echo", prompt="hi", allowed_tools=[])
    assert result.text == "ok"


# ---------------------------------------------------------------------------
# Auth fallback: subscription via credentials symlink
# ---------------------------------------------------------------------------


def test_invoker_subscription_auth_symlinks_credentials(tmp_path, monkeypatch):
    """No API key + creds at ~/.claude/.credentials.json → symlink into config_dir."""
    from producer.invoker import ClaudeAgentInvoker
    fake_home = tmp_path / "home"
    (fake_home / ".claude").mkdir(parents=True)
    creds = fake_home / ".claude" / ".credentials.json"
    creds.write_text('{"oauth": "fake"}')
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    monkeypatch.setattr("pathlib.Path.home", lambda: fake_home)

    cwd = tmp_path / "proj"
    cwd.mkdir()
    inv = ClaudeAgentInvoker(cwd=cwd)
    assert inv.auth_mode == "subscription"
    dst = inv.config_dir / ".credentials.json"
    assert dst.is_symlink()
    assert dst.resolve() == creds.resolve()


def test_invoker_subscription_auth_idempotent(tmp_path, monkeypatch):
    """Re-construction with the symlink already present does not error."""
    from producer.invoker import ClaudeAgentInvoker
    fake_home = tmp_path / "home"
    (fake_home / ".claude").mkdir(parents=True)
    creds = fake_home / ".claude" / ".credentials.json"
    creds.write_text('{"oauth": "fake"}')
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    monkeypatch.setattr("pathlib.Path.home", lambda: fake_home)

    cwd = tmp_path / "proj"
    cwd.mkdir()
    ClaudeAgentInvoker(cwd=cwd)
    inv = ClaudeAgentInvoker(cwd=cwd)
    dst = inv.config_dir / ".credentials.json"
    assert dst.is_symlink()
    assert dst.resolve() == creds.resolve()


def test_invoker_fails_when_no_key_and_no_creds(tmp_path, monkeypatch):
    from producer.invoker import ClaudeAgentInvoker
    fake_home = tmp_path / "home"
    fake_home.mkdir()
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    monkeypatch.setenv("PRODUCER_AUTH_MODE", "isolated")
    monkeypatch.setattr("pathlib.Path.home", lambda: fake_home)

    cwd = tmp_path / "proj"
    cwd.mkdir()
    with pytest.raises(RuntimeError, match="no API key"):
        ClaudeAgentInvoker(cwd=cwd)


def test_invoker_api_mode_when_key_set(tmp_path, monkeypatch):
    from producer.invoker import ClaudeAgentInvoker
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-test")
    cwd = tmp_path / "proj"
    cwd.mkdir()
    inv = ClaudeAgentInvoker(cwd=cwd)
    assert inv.auth_mode == "api"
    assert not (inv.config_dir / ".credentials.json").exists()


@pytest.mark.asyncio
async def test_invoker_extracts_usage_and_computes_cost_api_mode(tmp_path, monkeypatch):
    """Under API auth, both computed_cost_usd and actual_cost_usd are populated."""
    from producer.invoker import ClaudeAgentInvoker

    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-test")

    class _AssistantMessage:
        def __init__(self, content):
            self.content = content
    class _TextBlock:
        def __init__(self, text):
            self.text = text
    class _ResultMessage:
        def __init__(self, usage, total_cost_usd):
            self.usage = usage
            self.total_cost_usd = total_cost_usd

    async def fake_query(prompt, options):
        yield _AssistantMessage(content=[_TextBlock("hello")])
        yield _ResultMessage(
            usage={
                "input_tokens": 1_000_000,
                "output_tokens": 0,
                "cache_creation_input_tokens": 0,
                "cache_read_input_tokens": 0,
            },
            total_cost_usd=4.95,
        )

    import sys
    fake_sdk = type(sys)("claude_agent_sdk")
    fake_sdk.AssistantMessage = _AssistantMessage
    fake_sdk.TextBlock = _TextBlock
    fake_sdk.ClaudeAgentOptions = lambda **kw: type("Opts", (), kw)()
    fake_sdk.query = fake_query
    monkeypatch.setitem(sys.modules, "claude_agent_sdk", fake_sdk)

    inv = ClaudeAgentInvoker(cwd=tmp_path)
    result = await inv.invoke(
        agent_role="code", prompt="x", model="claude-opus-4-7"
    )
    assert result.usage["input_tokens"] == 1_000_000
    # opus 4.7 input rate is $5/Mtok per pricing.json; 1M tokens = $5
    assert result.computed_cost_usd == pytest.approx(5.00, abs=1e-6)
    assert result.actual_cost_usd == pytest.approx(4.95, abs=1e-6)
    assert result.cost_usd == result.computed_cost_usd  # alias
    assert result.auth_mode == "api"


@pytest.mark.asyncio
async def test_invoker_subscription_mode_actual_cost_is_none(tmp_path, monkeypatch):
    """Under subscription, no total_cost_usd → actual_cost_usd is None."""
    from producer.invoker import ClaudeAgentInvoker

    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    fake_home = tmp_path / "home"
    (fake_home / ".claude").mkdir(parents=True)
    (fake_home / ".claude" / ".credentials.json").write_text('{"oauth": "x"}')
    monkeypatch.setattr("pathlib.Path.home", lambda: fake_home)

    class _AssistantMessage:
        def __init__(self, content):
            self.content = content
    class _TextBlock:
        def __init__(self, text):
            self.text = text
    class _ResultMessage:
        def __init__(self, usage):
            self.usage = usage

    async def fake_query(prompt, options):
        yield _AssistantMessage(content=[_TextBlock("hi")])
        yield _ResultMessage(usage={
            "input_tokens": 1_000_000, "output_tokens": 0,
            "cache_creation_input_tokens": 0, "cache_read_input_tokens": 0,
        })

    import sys
    fake_sdk = type(sys)("claude_agent_sdk")
    fake_sdk.AssistantMessage = _AssistantMessage
    fake_sdk.TextBlock = _TextBlock
    fake_sdk.ClaudeAgentOptions = lambda **kw: type("Opts", (), kw)()
    fake_sdk.query = fake_query
    monkeypatch.setitem(sys.modules, "claude_agent_sdk", fake_sdk)

    cwd = tmp_path / "proj"
    cwd.mkdir()
    inv = ClaudeAgentInvoker(cwd=cwd)
    result = await inv.invoke(
        agent_role="code", prompt="x", model="claude-opus-4-7"
    )
    assert result.computed_cost_usd == pytest.approx(5.00, abs=1e-6)
    assert result.actual_cost_usd is None
    assert result.auth_mode == "subscription"


# ---------------------------------------------------------------------------
# GIT_TERMINAL_PROMPT in inherit mode
# ---------------------------------------------------------------------------


class TestInvocationResultIsolation:
    """InvocationResult carries config_isolation for downstream auditing."""

    def test_default_is_isolated(self):
        from producer.invoker import InvocationResult
        result = InvocationResult(text="hi", cost_usd=0.0)
        assert result.config_isolation == "isolated"

    def test_inherit_value_round_trips(self):
        from producer.invoker import InvocationResult
        result = InvocationResult(
            text="hi", cost_usd=0.0, config_isolation="inherit"
        )
        assert result.config_isolation == "inherit"


class TestInheritEnvSetup:
    """Inherit mode sets GIT_TERMINAL_PROMPT=0 to prevent git prompts."""

    def test_inherit_mode_sets_git_terminal_prompt(self, tmp_path, monkeypatch):
        from producer.invoker import ClaudeAgentInvoker
        monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")
        monkeypatch.setenv("PRODUCER_AUTH_MODE", "inherit")
        monkeypatch.delenv("GIT_TERMINAL_PROMPT", raising=False)
        ClaudeAgentInvoker(cwd=tmp_path)
        assert os.environ.get("GIT_TERMINAL_PROMPT") == "0"

    def test_isolated_mode_does_not_touch_git_terminal_prompt(self, tmp_path, monkeypatch):
        from producer.invoker import ClaudeAgentInvoker
        monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")
        monkeypatch.delenv("PRODUCER_AUTH_MODE", raising=False)
        monkeypatch.delenv("GIT_TERMINAL_PROMPT", raising=False)
        ClaudeAgentInvoker(cwd=tmp_path)
        assert "GIT_TERMINAL_PROMPT" not in os.environ


# ---------------------------------------------------------------------------
# AuthConfig propagation (Task 10)
# ---------------------------------------------------------------------------


class TestAuthConfigPropagation:
    def test_auth_config_inherit_propagates(self, tmp_path, monkeypatch):
        from producer.config import AuthConfig
        from producer.invoker import ClaudeAgentInvoker
        monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")
        monkeypatch.delenv("PRODUCER_AUTH_MODE", raising=False)
        inv = ClaudeAgentInvoker(
            cwd=tmp_path, auth_config=AuthConfig(mode="inherit")
        )
        assert inv.config_isolation == "inherit"

    def test_env_var_overrides_auth_config(self, tmp_path, monkeypatch):
        from producer.config import AuthConfig
        from producer.invoker import ClaudeAgentInvoker
        monkeypatch.setenv("ANTHROPIC_API_KEY", "test-key")
        monkeypatch.setenv("PRODUCER_AUTH_MODE", "isolated")
        inv = ClaudeAgentInvoker(
            cwd=tmp_path, auth_config=AuthConfig(mode="inherit")
        )
        assert inv.config_isolation == "isolated"
