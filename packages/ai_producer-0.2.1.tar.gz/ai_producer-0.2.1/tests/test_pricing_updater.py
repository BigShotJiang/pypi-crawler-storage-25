"""Tests for producer.pricing_updater."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from producer import pricing_updater


def _good_payload() -> dict:
    return {
        "last_updated": "2026-05-06",
        "source_url": "https://docs.anthropic.com/en/docs/about-claude/pricing",
        "currency": "USD",
        "models": {
            "claude-opus-4-7": {
                "input_per_mtok_usd": 5.0,
                "output_per_mtok_usd": 25.0,
                "cache_creation_per_mtok_usd": 6.25,
                "cache_read_per_mtok_usd": 0.50,
            },
        },
    }


@pytest.mark.asyncio
async def test_updater_writes_atomically_on_valid_response(tmp_path, monkeypatch):
    target = tmp_path / "pricing.json"
    target.write_text(json.dumps({"last_updated": "2026-01-01", "models": {}}))
    monkeypatch.setattr(pricing_updater, "TARGET_PATH", target)

    async def fake_runner(*, prompt, **_):
        return type("R", (), {"text": json.dumps(_good_payload())})()

    diff = await pricing_updater.update_pricing(runner=fake_runner)
    written = json.loads(target.read_text())
    assert written["last_updated"] == "2026-05-06"
    assert "claude-opus-4-7" in written["models"]
    assert isinstance(diff, dict)


@pytest.mark.asyncio
async def test_updater_dry_run_does_not_write(tmp_path, monkeypatch):
    target = tmp_path / "pricing.json"
    original = {"last_updated": "2026-01-01", "models": {}}
    target.write_text(json.dumps(original))
    monkeypatch.setattr(pricing_updater, "TARGET_PATH", target)

    async def fake_runner(*, prompt, **_):
        return type("R", (), {"text": json.dumps(_good_payload())})()

    await pricing_updater.update_pricing(runner=fake_runner, dry_run=True)
    assert json.loads(target.read_text()) == original


@pytest.mark.asyncio
async def test_updater_rejects_malformed_json(tmp_path, monkeypatch):
    target = tmp_path / "pricing.json"
    original = {"last_updated": "2026-01-01", "models": {}}
    target.write_text(json.dumps(original))
    monkeypatch.setattr(pricing_updater, "TARGET_PATH", target)

    async def fake_runner(*, prompt, **_):
        return type("R", (), {"text": "{not valid"})()

    with pytest.raises(pricing_updater.PricingUpdateError):
        await pricing_updater.update_pricing(runner=fake_runner)
    assert json.loads(target.read_text()) == original


@pytest.mark.asyncio
async def test_updater_rejects_missing_top_level_keys(tmp_path, monkeypatch):
    target = tmp_path / "pricing.json"
    target.write_text(json.dumps({"last_updated": "2026-01-01", "models": {}}))
    monkeypatch.setattr(pricing_updater, "TARGET_PATH", target)

    bad = {"last_updated": "2026-05-06", "models": {}}  # missing source_url, currency

    async def fake_runner(*, prompt, **_):
        return type("R", (), {"text": json.dumps(bad)})()

    with pytest.raises(pricing_updater.PricingUpdateError, match="missing"):
        await pricing_updater.update_pricing(runner=fake_runner)


@pytest.mark.asyncio
async def test_updater_rejects_implausible_rates(tmp_path, monkeypatch):
    target = tmp_path / "pricing.json"
    target.write_text(json.dumps({"last_updated": "2026-01-01", "models": {}}))
    monkeypatch.setattr(pricing_updater, "TARGET_PATH", target)

    bad = _good_payload()
    bad["models"]["claude-opus-4-7"]["input_per_mtok_usd"] = 99999.0  # implausible

    async def fake_runner(*, prompt, **_):
        return type("R", (), {"text": json.dumps(bad)})()

    with pytest.raises(pricing_updater.PricingUpdateError, match="sanity"):
        await pricing_updater.update_pricing(runner=fake_runner)
