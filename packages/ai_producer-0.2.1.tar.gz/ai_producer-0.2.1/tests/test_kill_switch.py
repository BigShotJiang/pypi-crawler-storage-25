"""Tests for producer.kill_switch."""

from __future__ import annotations

from producer.kill_switch import KillSwitchWatcher


def test_disarmed_when_missing(tmp_path):
    k = KillSwitchWatcher(path=tmp_path / "kill_switch")
    assert k.is_armed() is False


def test_arm_then_disarm(tmp_path):
    k = KillSwitchWatcher(path=tmp_path / "kill_switch")
    k.arm("test reason")
    assert k.is_armed() is True
    reason_file = (tmp_path / "kill_switch").with_suffix(".reason")
    assert reason_file.exists()
    assert "test reason" in reason_file.read_text()
    k.disarm()
    assert k.is_armed() is False


def test_zero_content_is_disarmed(tmp_path):
    p = tmp_path / "kill_switch"
    p.write_text("0\n")
    k = KillSwitchWatcher(path=p)
    assert k.is_armed() is False


def test_arm_creates_parent_dir(tmp_path):
    nested = tmp_path / "a" / "b" / "kill_switch"
    k = KillSwitchWatcher(path=nested)
    k.arm("nested test")
    assert k.is_armed() is True
