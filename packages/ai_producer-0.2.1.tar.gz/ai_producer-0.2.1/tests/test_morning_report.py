"""Tests for producer.morning_report — report rendering."""

from __future__ import annotations

from producer.morning_report import render_morning_report


def test_renders_with_empty_ledger(ledger):
    text = render_morning_report(
        ledger=ledger,
        project_name="Demo",
        target_date="2026-05-06",
        soft_total_usd=10.0,
        hard_total_usd=50.0,
        kill_switch_armed=False,
    )
    assert "Demo — Morning Report 2026-05-06" in text
    assert "Shipped overnight (0 tasks)" in text
    assert "_No escalations._" in text
    assert "_None detected this cycle._" in text


def test_renders_kill_switch_anomaly(ledger):
    text = render_morning_report(
        ledger=ledger,
        project_name="Demo",
        target_date="2026-05-06",
        soft_total_usd=10.0,
        hard_total_usd=50.0,
        kill_switch_armed=True,
    )
    assert "Kill switch is currently ARMED" in text


def test_renders_shipped_tasks(ledger):
    """Shipped tasks ordered by finished_at appear in the report."""
    today = "2026-05-06"
    ledger.conn.execute(
        "INSERT INTO tasks (id, agent_owner, status, title, description, "
        "created_at, finished_at, cost_usd) VALUES "
        "('t1', 'echo', 'done', 'Did the thing', '...', ?, ?, 0.05)",
        (today + "T00:00:00Z", today + "T01:00:00Z"),
    )
    text = render_morning_report(
        ledger=ledger,
        project_name="Demo",
        target_date=today,
        soft_total_usd=10.0,
        hard_total_usd=50.0,
        kill_switch_armed=False,
    )
    assert "Did the thing" in text
    assert "Shipped overnight (1 tasks)" in text


def test_renders_escalations_section(ledger):
    ledger.conn.execute(
        "INSERT INTO tasks (id, agent_owner, status, title, description, "
        "created_at, escalation_reason) VALUES "
        "('e1', 'echo', 'escalated', 'Stuck', '...', '2026-05-06T00:00:00Z', "
        "'cap breached')"
    )
    text = render_morning_report(
        ledger=ledger,
        project_name="Demo",
        target_date="2026-05-06",
        soft_total_usd=10.0,
        hard_total_usd=50.0,
        kill_switch_armed=False,
    )
    assert "Stuck" in text
    assert "cap breached" in text


def test_renders_budgets_with_cap_marker(ledger):
    """Per-agent rows show a [CAP HIT] marker when over hard cap."""
    today = "2026-05-06"
    # spent > hard
    ledger.conn.execute(
        "INSERT INTO budget (agent_owner, date, spent_usd, hard_cap_usd, soft_cap_usd) "
        "VALUES ('echo', ?, 12.0, 10.0, 8.0)",
        (today,),
    )
    text = render_morning_report(
        ledger=ledger,
        project_name="Demo",
        target_date=today,
        soft_total_usd=10.0,
        hard_total_usd=50.0,
        kill_switch_armed=False,
    )
    assert "[CAP HIT]" in text


def test_renders_soft_cap_marker(ledger):
    today = "2026-05-06"
    ledger.conn.execute(
        "INSERT INTO budget (agent_owner, date, spent_usd, hard_cap_usd, soft_cap_usd) "
        "VALUES ('echo', ?, 8.5, 10.0, 8.0)",
        (today,),
    )
    text = render_morning_report(
        ledger=ledger,
        project_name="Demo",
        target_date=today,
        soft_total_usd=10.0,
        hard_total_usd=50.0,
        kill_switch_armed=False,
    )
    assert "(soft cap)" in text


def test_morning_report_drift_section_shown_for_api_mode_tasks(ledger):
    """Tasks with non-null actual_cost_usd produce a drift line per agent."""
    today = "2026-05-06"
    # Two API-mode tasks for 'code' (computed=$0.50, actual=$0.45 → drift -10%)
    for tid in ("T1", "T2"):
        ledger.conn.execute(
            "INSERT INTO tasks (id, agent_owner, status, title, description, "
            "created_at, finished_at, cost_usd, actual_cost_usd) "
            "VALUES (?, 'code', 'done', 't', 'd', ?, ?, 0.50, 0.45)",
            (tid, f"{today}T01:00:00Z", f"{today}T01:00:00Z"),
        )
    # One subscription-mode task — should be excluded from drift
    ledger.conn.execute(
        "INSERT INTO tasks (id, agent_owner, status, title, description, "
        "created_at, finished_at, cost_usd, actual_cost_usd) "
        "VALUES ('T3', 'qa', 'done', 't', 'd', ?, ?, 0.50, NULL)",
        (f"{today}T01:00:00Z", f"{today}T01:00:00Z"),
    )

    body = render_morning_report(
        ledger=ledger,
        project_name="X",
        target_date=today,
        soft_total_usd=10.0,
        hard_total_usd=20.0,
        kill_switch_armed=False,
    )
    assert "Pricing drift" in body
    assert "code" in body
    # qa is subscription-only — should not appear under drift
    drift_section = body.split("## Pricing drift")[1].split("\n## ")[0]
    assert "qa" not in drift_section


def test_morning_report_drift_section_omitted_when_all_subscription(ledger):
    """All-subscription environment → no drift section at all."""
    today = "2026-05-06"
    ledger.conn.execute(
        "INSERT INTO tasks (id, agent_owner, status, title, description, "
        "created_at, finished_at, cost_usd, actual_cost_usd) "
        "VALUES ('T1', 'code', 'done', 't', 'd', ?, ?, 0.50, NULL)",
        (f"{today}T01:00:00Z", f"{today}T01:00:00Z"),
    )

    body = render_morning_report(
        ledger=ledger,
        project_name="X",
        target_date=today,
        soft_total_usd=10.0,
        hard_total_usd=20.0,
        kill_switch_armed=False,
    )
    assert "Pricing drift" not in body


def test_morning_report_staleness_banner(tmp_path, monkeypatch):
    """When pricing.is_stale() returns (True, n), a banner appears at the top."""
    from producer.ledger import LedgerClient
    from producer.morning_report import render_morning_report
    from producer import pricing

    monkeypatch.setattr(pricing, "is_stale", lambda now=None: (True, 95))

    ledger = LedgerClient(db_path=tmp_path / "s.db")
    body = render_morning_report(
        ledger=ledger,
        project_name="X",
        target_date="2026-05-06",
        soft_total_usd=10.0,
        hard_total_usd=20.0,
        kill_switch_armed=False,
    )
    assert "pricing table is 95 days old" in body
    assert "producer pricing update" in body


def test_morning_report_no_staleness_banner_when_fresh(tmp_path, monkeypatch):
    from producer.ledger import LedgerClient
    from producer.morning_report import render_morning_report
    from producer import pricing

    monkeypatch.setattr(pricing, "is_stale", lambda now=None: (False, 5))

    ledger = LedgerClient(db_path=tmp_path / "s.db")
    body = render_morning_report(
        ledger=ledger,
        project_name="X",
        target_date="2026-05-06",
        soft_total_usd=10.0,
        hard_total_usd=20.0,
        kill_switch_armed=False,
    )
    assert "pricing table is" not in body
