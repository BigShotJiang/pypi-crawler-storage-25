from pathlib import Path

import pytest

from producer.config import (
    BudgetConfig,
    NotificationsConfig,
    ProducerConfig,
    RoleConfig,
)
from producer.invoker import InvocationResult
from producer.ledger import LedgerClient


@pytest.fixture
def ledger(tmp_path: Path):
    db = tmp_path / "ledger.db"
    client = LedgerClient(db_path=db)
    yield client
    client.close()


def make_test_config(
    tmp_path: Path,
    *,
    idle_threshold_polls: int = 12,
    poll_interval_seconds: float = 0.01,
    project_ceiling_usd: float = 100.0,
    ntfy_topic: str = "",
) -> ProducerConfig:
    """Build a minimal ProducerConfig backed by a tmp_path tree."""
    return ProducerConfig(
        project_name="demo",
        project_root=tmp_path,
        kill_switch=tmp_path / "kill_switch",
        poll_interval_seconds=poll_interval_seconds,
        idle_threshold_polls=idle_threshold_polls,
        notifications=NotificationsConfig(ntfy_topic=ntfy_topic, subject_prefix="Demo"),
        budget=BudgetConfig(project_ceiling_usd=project_ceiling_usd, soft_cap_ratio=0.8),
        roles={
            "echo": RoleConfig(
                name="echo",
                daily_cap_usd=5.0,
                dispatch_reservation_usd=0.05,
                allowed_tools=["Read", "Write"],
            ),
            "producer": RoleConfig(
                name="producer",
                daily_cap_usd=2.0,
                dispatch_reservation_usd=0.01,
            ),
        },
        ledger_db=tmp_path / "ledger.db",
        escalations_dir=tmp_path / "agent-state" / "escalations",
        reports_dir=tmp_path / "agent-state",
    )


class FakeInvoker:
    """Test double for ClaudeAgentInvoker. Returns a canned InvocationResult."""

    def __init__(self, result: InvocationResult | None = None):
        self._result = result or InvocationResult(text="ok", cost_usd=0.001)
        self.calls: list[tuple[str, str]] = []

    async def invoke(
        self,
        agent_role: str,
        prompt: str,
        *,
        system_prompt: str | None = None,
        max_turns: int = 16,
        allowed_tools: list[str] | None = None,
        model: str | None = None,
    ) -> InvocationResult:
        self.calls.append((agent_role, prompt))
        return self._result


class FailingInvoker:
    """Always raises — used for retry/escalation tests."""

    def __init__(self, error: str = "boom"):
        self.error = error
        self.calls = 0

    async def invoke(self, *args, **kwargs):
        self.calls += 1
        raise RuntimeError(self.error)
