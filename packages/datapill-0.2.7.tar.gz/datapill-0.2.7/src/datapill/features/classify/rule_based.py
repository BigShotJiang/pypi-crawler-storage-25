import re
from typing import Optional
import polars as pl

from .schema import SemanticType, ColumnClassification, ProfileSignals

_CERTAIN_CONFIDENCE = 1.0

_DTYPE_CERTAIN: list[tuple[tuple, SemanticType, str]] = [
    ((pl.Boolean,), SemanticType.BOOLEAN, "dtype Boolean"),
    ((pl.Date, pl.Datetime, pl.Time, pl.Duration), SemanticType.DATETIME, "dtype is temporal"),
    ((pl.Float32, pl.Float64), SemanticType.NUMERICAL_CONTINUOUS, "dtype Float"),
]

_NAME_CERTAIN: list[tuple[re.Pattern, SemanticType, str]] = [
    (re.compile(r"\b(uuid|guid)\b", re.I),                    SemanticType.IDENTIFIER,       "name: uuid/guid"),
    (re.compile(r"\b(email|e_mail)\b", re.I),                 SemanticType.TEXT_STRUCTURED,  "name: email"),
    (re.compile(r"\b(phone|tel|mobile|cellphone)\b", re.I),   SemanticType.TEXT_STRUCTURED,  "name: phone"),
    (re.compile(r"\b(url|href)\b", re.I),                     SemanticType.TEXT_STRUCTURED,  "name: url/href"),
    (re.compile(r"\b(lat|latitude)\b", re.I),                 SemanticType.GEOSPATIAL,       "name: latitude"),
    (re.compile(r"\b(lon|lng|longitude)\b", re.I),            SemanticType.GEOSPATIAL,       "name: longitude"),
    (re.compile(r"\b(embedding|embed|vector|vec)\b", re.I),   SemanticType.EMBEDDING,        "name: embedding/vector"),
    (re.compile(r"(^|_)(at|date|datetime|timestamp)$", re.I), SemanticType.DATETIME,         "name: _at/_date/_datetime/_timestamp suffix"),
    (re.compile(r"^(is|has|can|was|did|should|will)_", re.I), SemanticType.BOOLEAN,          "name: boolean prefix"),
]

_PATTERN_TO_SEMANTIC: dict[str, SemanticType] = {
    "email":    SemanticType.TEXT_STRUCTURED,
    "url":      SemanticType.TEXT_STRUCTURED,
    "phone_vn": SemanticType.TEXT_STRUCTURED,
    "uuid":     SemanticType.IDENTIFIER,
    "date_iso": SemanticType.DATETIME,
}

_LOW_CARDINALITY_THRESHOLD = 20
_IDENTIFIER_UNIQUE_THRESHOLD = 0.95


def _classify_certain(col_name: str, dtype: pl.DataType) -> Optional[ColumnClassification]:
    for dtypes, semantic_type, reasoning in _DTYPE_CERTAIN:
        if dtype in dtypes:
            return ColumnClassification(
                name=col_name,
                semantic_type=semantic_type,
                confidence=_CERTAIN_CONFIDENCE,
                reasoning=f"certain: {reasoning}",
                source="rule_based",
            )

    for pattern, semantic_type, reasoning in _NAME_CERTAIN:
        if pattern.search(col_name):
            return ColumnClassification(
                name=col_name,
                semantic_type=semantic_type,
                confidence=_CERTAIN_CONFIDENCE,
                reasoning=f"certain: {reasoning}",
                source="rule_based",
            )

    return None


def _apply_profile_signals(
    result: ColumnClassification,
    signals: ProfileSignals,
) -> ColumnClassification:
    if result.confidence >= _CERTAIN_CONFIDENCE:
        notes: list[str] = []
        if signals.null_pct > 0.3:
            notes.append(f"profile: high null rate ({signals.null_pct:.0%})")
        if not notes:
            return result
        return ColumnClassification(
            name=result.name,
            semantic_type=result.semantic_type,
            confidence=result.confidence,
            reasoning="; ".join([result.reasoning] + notes),
            source=result.source,
            overridden=result.overridden,
        )

    semantic_type = result.semantic_type
    confidence = result.confidence
    reasoning_parts = [result.reasoning]

    if signals.pattern_names:
        for pattern_name in signals.pattern_names:
            mapped = _PATTERN_TO_SEMANTIC.get(pattern_name)
            if mapped is not None:
                if semantic_type != mapped:
                    semantic_type = mapped
                    confidence = max(confidence, 0.75)
                    reasoning_parts.append(f"profile: {pattern_name} pattern in ≥50% of values")
                else:
                    confidence = min(confidence + 0.05, 0.95)
                    reasoning_parts.append(f"profile: {pattern_name} pattern confirmed")
                break

    if signals.is_unique and signals.distinct_count > 100:
        if semantic_type not in (SemanticType.IDENTIFIER, SemanticType.TEXT_STRUCTURED, SemanticType.DATETIME):
            semantic_type = SemanticType.IDENTIFIER
            confidence = max(confidence, 0.70)
            reasoning_parts.append("profile: all values unique with high cardinality")
        elif semantic_type == SemanticType.IDENTIFIER:
            confidence = min(confidence + 0.08, 0.95)
            reasoning_parts.append("profile: uniqueness confirms identifier")

    elif (
        signals.distinct_pct >= _IDENTIFIER_UNIQUE_THRESHOLD
        and not signals.is_unique
        and signals.distinct_count > 100
        and semantic_type == SemanticType.IDENTIFIER
    ):
        confidence = min(confidence + 0.05, 0.95)
        reasoning_parts.append(f"profile: near-unique ({signals.distinct_pct:.0%} distinct)")

    if (
        signals.top_value_count is not None
        and signals.top_value_count <= _LOW_CARDINALITY_THRESHOLD
        and semantic_type not in (SemanticType.BOOLEAN, SemanticType.IDENTIFIER, SemanticType.DATETIME)
        and not signals.is_unique
    ):
        if semantic_type not in (SemanticType.CATEGORICAL_NOMINAL, SemanticType.CATEGORICAL_ORDINAL):
            semantic_type = SemanticType.CATEGORICAL_NOMINAL
            confidence = max(confidence, 0.65)
            reasoning_parts.append(f"profile: low cardinality ({signals.top_value_count} distinct values)")
        else:
            confidence = min(confidence + 0.05, 0.95)
            reasoning_parts.append(f"profile: low cardinality ({signals.top_value_count} distinct values) confirms categorical")

    if (
        signals.skewness is not None
        and abs(signals.skewness) > 3
        and semantic_type in (SemanticType.NUMERICAL_DISCRETE, SemanticType.NUMERICAL_CONTINUOUS)
    ):
        if semantic_type != SemanticType.NUMERICAL_CONTINUOUS:
            semantic_type = SemanticType.NUMERICAL_CONTINUOUS
            confidence = max(confidence, 0.65)
            reasoning_parts.append(f"profile: high skewness ({signals.skewness:.2f}) suggests continuous")
        else:
            reasoning_parts.append(f"profile: high skewness ({signals.skewness:.2f})")

    if signals.null_pct > 0.3:
        reasoning_parts.append(f"profile: high null rate ({signals.null_pct:.0%})")

    return ColumnClassification(
        name=result.name,
        semantic_type=semantic_type,
        confidence=confidence,
        reasoning="; ".join(reasoning_parts),
        source=result.source,
        overridden=result.overridden,
    )


def classify_column_rule_based(
    col_name: str,
    dtype: pl.DataType,
    series: pl.Series,
    profile_signals: Optional[ProfileSignals] = None,
) -> Optional[ColumnClassification]:
    result = _classify_certain(col_name, dtype)

    if result is None:
        return None

    if profile_signals is not None:
        return _apply_profile_signals(result, profile_signals)

    return result