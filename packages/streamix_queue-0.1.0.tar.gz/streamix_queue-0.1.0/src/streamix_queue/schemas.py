from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Mapping
import json
import uuid


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass(slots=True)
class MessageTimestamps:
    created_at: str
    updated_at: str

    @classmethod
    def now(cls) -> "MessageTimestamps":
        current = utc_now_iso()
        return cls(created_at=current, updated_at=current)

    def touch(self) -> None:
        self.updated_at = utc_now_iso()


@dataclass(slots=True)
class StreamMessage:
    id: str
    event: str
    data: dict[str, Any]
    retries: int
    timestamps: MessageTimestamps

    @classmethod
    def new(cls, event: str, data: dict[str, Any], retries: int = 0) -> "StreamMessage":
        if not event:
            raise ValueError("event must be a non-empty string")
        if not isinstance(data, dict):
            raise TypeError("data must be a dictionary")
        return cls(
            id=str(uuid.uuid4()),
            event=event,
            data=data,
            retries=retries,
            timestamps=MessageTimestamps.now(),
        )

    def with_retry(self, retries: int) -> "StreamMessage":
        copied = StreamMessage(
            id=self.id,
            event=self.event,
            data=dict(self.data),
            retries=retries,
            timestamps=MessageTimestamps(
                created_at=self.timestamps.created_at,
                updated_at=self.timestamps.updated_at,
            ),
        )
        copied.timestamps.touch()
        return copied

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "event": self.event,
            "data": self.data,
            "retries": self.retries,
            "timestamps": {
                "created_at": self.timestamps.created_at,
                "updated_at": self.timestamps.updated_at,
            },
        }

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> "StreamMessage":
        required = {"id", "event", "data", "retries", "timestamps"}
        missing = required.difference(payload.keys())
        if missing:
            raise ValueError(f"message payload missing keys: {sorted(missing)}")

        timestamps_raw = payload["timestamps"]
        if not isinstance(timestamps_raw, Mapping):
            raise TypeError("timestamps must be an object")

        created_at = timestamps_raw.get("created_at")
        updated_at = timestamps_raw.get("updated_at")
        if not isinstance(created_at, str) or not isinstance(updated_at, str):
            raise TypeError("timestamps.created_at and timestamps.updated_at must be strings")

        data = payload["data"]
        if not isinstance(data, dict):
            raise TypeError("data must be an object")

        retries = int(payload["retries"])
        event = payload["event"]
        identifier = payload["id"]
        if not isinstance(event, str) or not event:
            raise TypeError("event must be a non-empty string")
        if not isinstance(identifier, str) or not identifier:
            raise TypeError("id must be a non-empty string")

        return cls(
            id=identifier,
            event=event,
            data=data,
            retries=retries,
            timestamps=MessageTimestamps(created_at=created_at, updated_at=updated_at),
        )

    def to_stream_fields(self) -> dict[str, str]:
        return {
            "message": json.dumps(self.to_dict(), separators=(",", ":"), ensure_ascii=False),
        }

    @classmethod
    def from_stream_fields(cls, fields: Mapping[str, Any]) -> "StreamMessage":
        raw_payload = fields.get("message")
        if raw_payload is None:
            raise ValueError("stream message missing 'message' field")
        if isinstance(raw_payload, bytes):
            raw_payload = raw_payload.decode("utf-8")
        payload = json.loads(raw_payload)
        if not isinstance(payload, Mapping):
            raise TypeError("message field must contain a JSON object")
        return cls.from_dict(payload)
