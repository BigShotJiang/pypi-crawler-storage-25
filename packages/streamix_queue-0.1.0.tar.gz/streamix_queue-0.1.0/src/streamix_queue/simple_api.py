from __future__ import annotations

import os
import socket
from typing import Any, Callable

from .consumer import ConsumerEngine
from .producer import Producer
from .schemas import StreamMessage
from .transport import RedisStreamTransport


def publish(
    event: str,
    data: dict[str, Any],
    *,
    redis_url: str = "redis://localhost:6379/0",
    stream: str = "app.events",
    group: str = "app.workers",
) -> StreamMessage:
    """Publish an event to the stream."""
    transport = RedisStreamTransport(
        redis_url=redis_url,
        stream_name=stream,
        group_name=group,
    )
    producer = Producer(transport)
    return producer.publish(event, data)


def consume(
    event: str,
    handler: Callable[..., Any],
    *,
    redis_url: str = "redis://localhost:6379/0",
    stream: str = "app.events",
    group: str = "app.workers",
    consumer: str | None = None,
    retry_limit: int = 3,
    batch_size: int = 10,
    block_ms: int = 5000,
    claim_idle_ms: int = 60000,
) -> None:
    """Start a consumer that listens for events and calls the handler.
    
    Args:
        event: Event name to listen for
        handler: Callable that accepts (data) or (data, message)
        redis_url: Redis connection URL
        stream: Stream name
        group: Consumer group name
        consumer: Consumer instance name (auto-generated if None)
        retry_limit: Max retries before sending to DLQ
        batch_size: Number of messages to process per batch
        block_ms: Blocking timeout for XREADGROUP
        claim_idle_ms: Idle time threshold for stale message reclaim
    """
    transport = RedisStreamTransport(
        redis_url=redis_url,
        stream_name=stream,
        group_name=group,
    )
    consumer_name = consumer or _default_consumer_name()
    engine = ConsumerEngine(
        transport=transport,
        target_event=event,
        handler=handler,
        consumer_name=consumer_name,
        retry_limit=retry_limit,
        batch_size=batch_size,
        block_ms=block_ms,
        claim_idle_ms=claim_idle_ms,
    )
    engine.run_forever()


def _default_consumer_name() -> str:
    return f"{socket.gethostname()}-{os.getpid()}"
