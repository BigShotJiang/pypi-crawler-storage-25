from __future__ import annotations

import logging
from typing import Any

from redis import Redis
from redis.exceptions import ResponseError

from .schemas import StreamMessage

logger = logging.getLogger(__name__)


class RedisStreamTransport:
    def __init__(
        self,
        redis_url: str,
        stream_name: str,
        group_name: str,
        dead_letter_stream: str | None = None,
        redis_client: Redis | None = None,
    ) -> None:
        self.redis_url = redis_url
        self.stream_name = stream_name
        self.group_name = group_name
        self.dead_letter_stream = dead_letter_stream or f"{stream_name}:failed"
        self.client = redis_client or Redis.from_url(redis_url, decode_responses=True)
        self._group_ready = False

    def ensure_group(self) -> None:
        if self._group_ready:
            return
        try:
            self.client.xgroup_create(
                name=self.stream_name,
                groupname=self.group_name,
                id="$",
                mkstream=True,
            )
            logger.info(
                "Created stream/group",
                extra={"stream": self.stream_name, "group": self.group_name},
            )
        except ResponseError as exc:
            if "BUSYGROUP" not in str(exc):
                raise
        self._group_ready = True

    def publish(self, message: StreamMessage) -> str:
        return self.client.xadd(self.stream_name, message.to_stream_fields())

    def read_group(
        self,
        consumer_name: str,
        count: int = 10,
        block_ms: int = 5000,
    ) -> list[tuple[str, StreamMessage]]:
        self.ensure_group()
        response = self.client.xreadgroup(
            groupname=self.group_name,
            consumername=consumer_name,
            streams={self.stream_name: ">"},
            count=count,
            block=block_ms,
        )
        return self._parse_stream_response(response)

    def claim_stale_messages(
        self,
        consumer_name: str,
        min_idle_time_ms: int,
        count: int = 10,
    ) -> list[tuple[str, StreamMessage]]:
        self.ensure_group()
        result = self.client.xautoclaim(
            name=self.stream_name,
            groupname=self.group_name,
            consumername=consumer_name,
            min_idle_time=min_idle_time_ms,
            start_id="0-0",
            count=count,
        )

        claimed_entries: list[tuple[str, dict[str, Any]]]
        if isinstance(result, (list, tuple)) and len(result) >= 2:
            claimed_entries = result[1]
        else:
            claimed_entries = []
        return [(entry_id, StreamMessage.from_stream_fields(fields)) for entry_id, fields in claimed_entries]

    def ack(self, stream_entry_id: str) -> int:
        return self.client.xack(self.stream_name, self.group_name, stream_entry_id)

    def publish_dead_letter(
        self,
        message: StreamMessage,
        error: str,
        source_stream_id: str,
    ) -> str:
        failed_message = StreamMessage.new(
            event=message.event,
            data={
                "original_id": message.id,
                "original_event": message.event,
                "original_data": message.data,
                "source_stream_id": source_stream_id,
                "retries": message.retries,
                "error": error,
            },
            retries=message.retries,
        )
        return self.client.xadd(self.dead_letter_stream, failed_message.to_stream_fields())

    @staticmethod
    def _parse_stream_response(response: Any) -> list[tuple[str, StreamMessage]]:
        parsed: list[tuple[str, StreamMessage]] = []
        if not response:
            return parsed

        for _, entries in response:
            for entry_id, fields in entries:
                parsed.append((entry_id, StreamMessage.from_stream_fields(fields)))
        return parsed
