"""Streamix Queue version."""

__version__ = "0.1.0"
__author__ = "Streamix Contributors"
__license__ = "MIT"
