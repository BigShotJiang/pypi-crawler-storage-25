from __future__ import annotations

from typing import Any

from .schemas import StreamMessage
from .transport import RedisStreamTransport


class Producer:
    def __init__(self, transport: RedisStreamTransport) -> None:
        self.transport = transport

    def publish(self, event: str, data: dict[str, Any]) -> StreamMessage:
        message = StreamMessage.new(event=event, data=data)
        self.transport.publish(message)
        return message
