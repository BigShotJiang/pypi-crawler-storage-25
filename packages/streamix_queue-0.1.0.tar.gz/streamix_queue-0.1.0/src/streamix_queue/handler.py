from __future__ import annotations

import inspect
import logging
from typing import Any, Callable

from .schemas import StreamMessage

logger = logging.getLogger(__name__)


class HandlerExecutor:
    @staticmethod
    def execute(handler: Callable[..., Any], message: StreamMessage) -> Any:
        signature = inspect.signature(handler)
        if len(signature.parameters) <= 1:
            return handler(message.data)
        return handler(message.data, message)
