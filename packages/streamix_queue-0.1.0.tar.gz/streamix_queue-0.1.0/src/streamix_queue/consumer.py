from __future__ import annotations

import logging
from typing import Any, Callable

from .handler import HandlerExecutor
from .schemas import StreamMessage
from .transport import RedisStreamTransport

logger = logging.getLogger(__name__)


class ConsumerEngine:
    def __init__(
        self,
        transport: RedisStreamTransport,
        target_event: str,
        handler: Callable[..., Any],
        consumer_name: str,
        retry_limit: int = 3,
        batch_size: int = 10,
        block_ms: int = 5000,
        claim_idle_ms: int = 60000,
    ) -> None:
        self.transport = transport
        self.target_event = target_event
        self.handler = handler
        self.consumer_name = consumer_name
        self.retry_limit = retry_limit
        self.batch_size = batch_size
        self.block_ms = block_ms
        self.claim_idle_ms = claim_idle_ms

    def run_forever(self) -> None:
        self.transport.ensure_group()
        logger.info(
            "Consumer started",
            extra={
                "event": self.target_event,
                "stream": self.transport.stream_name,
                "group": self.transport.group_name,
                "consumer": self.consumer_name,
                "retry_limit": self.retry_limit,
            },
        )

        while True:
            self.consume_once()

    def consume_once(self) -> int:
        claimed = self.transport.claim_stale_messages(
            consumer_name=self.consumer_name,
            min_idle_time_ms=self.claim_idle_ms,
            count=self.batch_size,
        )
        fresh = self.transport.read_group(
            consumer_name=self.consumer_name,
            count=self.batch_size,
            block_ms=self.block_ms,
        )

        count = 0
        for stream_entry_id, message in claimed + fresh:
            self._handle_message(stream_entry_id, message)
            count += 1
        return count

    def _handle_message(self, stream_entry_id: str, message: StreamMessage) -> None:
        if message.event != self.target_event:
            self.transport.ack(stream_entry_id)
            return

        try:
            HandlerExecutor.execute(self.handler, message)
            self.transport.ack(stream_entry_id)
            logger.info(
                "Message processed",
                extra={
                    "message_id": message.id,
                    "event": message.event,
                    "stream_entry": stream_entry_id,
                },
            )
        except Exception as exc:
            self._handle_failure(stream_entry_id, message, exc)

    def _handle_failure(self, stream_entry_id: str, message: StreamMessage, exc: Exception) -> None:
        next_retry = message.retries + 1
        if next_retry > self.retry_limit:
            logger.exception(
                "Message permanently failed",
                extra={
                    "message_id": message.id,
                    "event": message.event,
                    "stream_entry": stream_entry_id,
                    "retry_limit": self.retry_limit,
                },
            )
            self.transport.publish_dead_letter(message, error=str(exc), source_stream_id=stream_entry_id)
            self.transport.ack(stream_entry_id)
            return

        retried_message = message.with_retry(next_retry)
        self.transport.publish(retried_message)
        self.transport.ack(stream_entry_id)
        logger.warning(
            "Handler failed; requeued message",
            extra={
                "message_id": message.id,
                "event": message.event,
                "stream_entry": stream_entry_id,
                "retries": next_retry,
            },
        )
