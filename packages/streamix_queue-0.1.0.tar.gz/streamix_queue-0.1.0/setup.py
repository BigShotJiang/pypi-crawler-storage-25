#!/usr/bin/env python
"""Setup for streamix-queue package."""

from setuptools import setup

setup()
