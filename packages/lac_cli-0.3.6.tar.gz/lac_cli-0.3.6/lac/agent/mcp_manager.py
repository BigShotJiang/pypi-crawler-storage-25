"""
lac/agent/mcp_manager.py
MCP (Model Context Protocol) client manager
"""

import asyncio
import os
from typing import Dict, List, Optional, Any
from rich.console import Console

console = Console()

try:
    from mcp import ClientSession, StdioServerParameters
    from mcp.client.stdio import stdio_client
    from mcp.client.sse import sse_client
    MCP_AVAILABLE = True
except ImportError:
    MCP_AVAILABLE = False


class MCPManager:
    def __init__(self):
        self.servers: Dict[str, Dict[str, Any]] = {}
        self.tools: Dict[str, Dict[str, Any]] = {}
        self.sessions: Dict[str, ClientSession] = {}
        self.contexts: Dict[str, Any] = {}
        
    async def startup(self, mcp_servers: List[Dict[str, Any]]) -> List[str]:
        """Connect to all MCP servers and discover tools."""
        if not MCP_AVAILABLE:
            console.print("[yellow]⚠ MCP SDK not installed. Run: pip install mcp[/yellow]")
            return []
        
        connected = []
        
        for server_config in mcp_servers:
            name = server_config.get("name", "unknown")
            server_type = server_config.get("type", "stdio")
            
            try:
                # Add timeout for each individual server connection (15 seconds for npx downloads)
                if server_type == "stdio":
                    await asyncio.wait_for(self._connect_stdio(name, server_config), timeout=15.0)
                elif server_type == "sse":
                    await asyncio.wait_for(self._connect_sse(name, server_config), timeout=15.0)
                else:
                    console.print(f"[yellow]⚠ Unknown MCP server type '{server_type}' for {name}[/yellow]")
                    continue
                
                # Discover tools (with timeout)
                session = self.sessions[name]
                tools_response = await asyncio.wait_for(session.list_tools(), timeout=5.0)
                
                tool_count = 0
                for tool in tools_response.tools:
                    tool_name = tool.name
                    
                    # Handle name collisions
                    if tool_name in self.tools:
                        console.print(f"[yellow]⚠ Tool name collision: '{tool_name}' - prefixing with server name[/yellow]")
                        tool_name = f"{name}__{tool_name}"
                    
                    self.tools[tool_name] = {
                        "server_name": name,
                        "session": session,
                        "schema": {
                            "name": tool.name,
                            "description": tool.description or "",
                            "inputSchema": tool.inputSchema
                        }
                    }
                    tool_count += 1
                
                self.servers[name] = {
                    "config": server_config,
                    "status": "connected",
                    "tool_count": tool_count
                }
                connected.append(f"{name} ({tool_count} tools)")
                
            except asyncio.TimeoutError:
                self.servers[name] = {
                    "config": server_config,
                    "status": "failed",
                    "error": "Connection timeout (15s)"
                }
            except Exception as e:
                # Log the full error for debugging
                import traceback
                error_detail = f"{str(e)[:100]}"
                console.print(f"[dim]MCP {name} error: {error_detail}[/dim]")
                self.servers[name] = {
                    "config": server_config,
                    "status": "failed",
                    "error": error_detail
                }
        
        return connected
        
        return connected
    
    async def _connect_stdio(self, name: str, config: Dict[str, Any]):
        """Connect to stdio MCP server."""
        command = config.get("command")
        args = config.get("args", [])
        env = config.get("env", {})
        
        if not command:
            raise ValueError(f"Missing 'command' for stdio server {name}")
        
        # Merge environment variables
        server_env = os.environ.copy()
        server_env.update(env)
        
        # Suppress server output to prevent terminal pollution
        import subprocess
        server_env["PYTHONUNBUFFERED"] = "1"
        
        params = StdioServerParameters(
            command=command,
            args=args,
            env=server_env
        )
        
        # Create context manager and store it
        ctx = stdio_client(params)
        self.contexts[name] = ctx
        
        # Enter context and initialize
        read, write = await ctx.__aenter__()
        session = ClientSession(read, write)
        await session.initialize()
        
        self.sessions[name] = session
    
    async def _connect_sse(self, name: str, config: Dict[str, Any]):
        """Connect to SSE MCP server."""
        url = config.get("url")
        headers = config.get("headers", {})
        
        if not url:
            raise ValueError(f"Missing 'url' for sse server {name}")
        
        # The MCP SDK's sse_client expects the base URL, not the /sse endpoint
        # It will automatically append /sse if needed
        # Remove /sse suffix if present
        if url.endswith("/sse"):
            base_url = url[:-4]
        else:
            base_url = url
        
        try:
            # Create context manager and store it
            ctx = sse_client(base_url, headers=headers)
            self.contexts[name] = ctx
            
            # Enter context and initialize
            read, write = await ctx.__aenter__()
            session = ClientSession(read, write)
            
            # Initialize with timeout
            await asyncio.wait_for(session.initialize(), timeout=3.0)
            
            self.sessions[name] = session
        except asyncio.TimeoutError:
            raise TimeoutError(f"Initialization timeout for {name}")
        except Exception as e:
            # Clean up context if initialization failed
            if name in self.contexts:
                try:
                    await self.contexts[name].__aexit__(None, None, None)
                except:
                    pass
                del self.contexts[name]
            raise Exception(f"Failed to initialize: {str(e)}")
    
    async def call_tool(self, tool_name: str, arguments: Dict[str, Any]) -> str:
        """Call an MCP tool and return the result."""
        if tool_name not in self.tools:
            return f"[ERROR] MCP tool '{tool_name}' not found"
        
        tool_info = self.tools[tool_name]
        session = tool_info["session"]
        original_name = tool_info["schema"]["name"]
        
        try:
            result = await session.call_tool(original_name, arguments)
            
            # Extract text from result content
            if hasattr(result, 'content') and result.content:
                if isinstance(result.content, list) and len(result.content) > 0:
                    first_content = result.content[0]
                    if hasattr(first_content, 'text'):
                        return first_content.text
                    return str(first_content)
                return str(result.content)
            
            return str(result)
            
        except Exception as e:
            return f"[ERROR] MCP tool call failed: {e}"
    
    async def shutdown(self):
        """Close all MCP server connections."""
        for name, ctx in self.contexts.items():
            try:
                await ctx.__aexit__(None, None, None)
            except Exception as e:
                console.print(f"[dim]⚠ Error closing MCP server {name}: {e}[/dim]")
        
        self.sessions.clear()
        self.contexts.clear()
        self.tools.clear()
        self.servers.clear()
    
    def get_tool_schemas_claude(self) -> List[Dict[str, Any]]:
        """Get MCP tools in Claude API format."""
        schemas = []
        for tool_name, tool_info in self.tools.items():
            schema = tool_info["schema"]
            schemas.append({
                "name": tool_name,
                "description": schema["description"],
                "input_schema": schema["inputSchema"]
            })
        return schemas
    
    def get_tool_schemas_openai(self) -> List[Dict[str, Any]]:
        """Get MCP tools in OpenAI API format."""
        schemas = []
        for tool_name, tool_info in self.tools.items():
            schema = tool_info["schema"]
            schemas.append({
                "type": "function",
                "function": {
                    "name": tool_name,
                    "description": schema["description"],
                    "parameters": schema["inputSchema"]
                }
            })
        return schemas
    
    def list_servers(self) -> List[Dict[str, Any]]:
        """List all configured servers with their status."""
        return [
            {
                "name": name,
                "status": info["status"],
                "tool_count": info.get("tool_count", 0),
                "error": info.get("error")
            }
            for name, info in self.servers.items()
        ]
    
    def is_mcp_tool(self, tool_name: str) -> bool:
        """Check if a tool name belongs to an MCP server."""
        return tool_name in self.tools
