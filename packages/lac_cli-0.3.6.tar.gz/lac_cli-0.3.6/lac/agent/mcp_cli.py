"""
lac/agent/mcp_cli.py
CLI commands for managing MCP servers
"""

import sys
from rich.console import Console
from lac.config import get_config, save_config

console = Console()


def add_server():
    """Interactive wizard to add a new MCP server."""
    console.print("\n[bold cyan]Add MCP Server[/bold cyan]\n")
    
    try:
        # Get server name
        name = input("Server name: ").strip()
        if not name:
            console.print("[yellow]Server name is required[/yellow]")
            return
        
        # Get server type
        console.print("\nServer type:")
        console.print("  1. stdio (local process)")
        console.print("  2. sse (remote HTTP)")
        type_choice = input("Select [1-2]: ").strip()
        
        if type_choice == "1":
            server_type = "stdio"
            
            # Get command
            command = input("\nCommand (e.g., 'npx', 'node', 'python'): ").strip()
            if not command:
                console.print("[yellow]Command is required[/yellow]")
                return
            
            # Get args
            console.print("\nArguments (one per line, empty line to finish):")
            args = []
            while True:
                arg = input("  ").strip()
                if not arg:
                    break
                args.append(arg)
            
            # Get environment variables
            console.print("\nEnvironment variables (KEY=VALUE, one per line, empty line to finish):")
            env = {}
            while True:
                env_line = input("  ").strip()
                if not env_line:
                    break
                if "=" in env_line:
                    key, value = env_line.split("=", 1)
                    env[key.strip()] = value.strip()
            
            server_config = {
                "name": name,
                "type": server_type,
                "command": command,
                "args": args,
                "env": env
            }
            
        elif type_choice == "2":
            server_type = "sse"
            
            # Get URL
            url = input("\nServer URL (e.g., 'http://localhost:8000/sse'): ").strip()
            if not url:
                console.print("[yellow]URL is required[/yellow]")
                return
            
            # Get headers
            console.print("\nHeaders (KEY=VALUE, one per line, empty line to finish):")
            headers = {}
            while True:
                header_line = input("  ").strip()
                if not header_line:
                    break
                if "=" in header_line:
                    key, value = header_line.split("=", 1)
                    headers[key.strip()] = value.strip()
            
            server_config = {
                "name": name,
                "type": server_type,
                "url": url,
                "headers": headers
            }
        else:
            console.print("[yellow]Invalid choice[/yellow]")
            return
        
        # Save to config
        config = get_config()
        if "mcp_servers" not in config:
            config["mcp_servers"] = []
        
        # Check for duplicate names
        for existing in config["mcp_servers"]:
            if existing.get("name") == name:
                console.print(f"[yellow]Server '{name}' already exists[/yellow]")
                return
        
        config["mcp_servers"].append(server_config)
        save_config(config)
        
        console.print(f"\n[green]✓ MCP server '{name}' added successfully[/green]")
        console.print("[dim]Restart the agent to connect to this server[/dim]\n")
        
    except (KeyboardInterrupt, EOFError):
        console.print("\n[dim]Cancelled[/dim]\n")


def list_servers():
    """List all configured MCP servers."""
    config = get_config()
    servers = config.get("mcp_servers", [])
    
    if not servers:
        console.print("\n[yellow]No MCP servers configured[/yellow]")
        console.print("[dim]Use 'lac mcp add' to add a server[/dim]\n")
        return
    
    console.print("\n[bold]Configured MCP Servers:[/bold]\n")
    for i, server in enumerate(servers, 1):
        name = server.get("name", "unknown")
        server_type = server.get("type", "unknown")
        console.print(f"  [cyan]{i}.[/cyan] {name} ({server_type})")
        
        if server_type == "stdio":
            command = server.get("command", "")
            args = server.get("args", [])
            console.print(f"      Command: {command} {' '.join(args)}")
        elif server_type == "sse":
            url = server.get("url", "")
            console.print(f"      URL: {url}")
    
    console.print()


def remove_server():
    """Remove an MCP server from config."""
    config = get_config()
    servers = config.get("mcp_servers", [])
    
    if not servers:
        console.print("\n[yellow]No MCP servers configured[/yellow]\n")
        return
    
    console.print("\n[bold]Configured MCP Servers:[/bold]\n")
    for i, server in enumerate(servers, 1):
        name = server.get("name", "unknown")
        server_type = server.get("type", "unknown")
        console.print(f"  [cyan]{i}.[/cyan] {name} ({server_type})")
    
    try:
        choice = input(f"\nSelect server to remove [1-{len(servers)}] or Enter to cancel: ").strip()
        if not choice:
            console.print("[dim]Cancelled[/dim]\n")
            return
        
        idx = int(choice) - 1
        if 0 <= idx < len(servers):
            removed = servers.pop(idx)
            config["mcp_servers"] = servers
            save_config(config)
            console.print(f"\n[green]✓ Removed MCP server '{removed.get('name')}'[/green]\n")
        else:
            console.print("[yellow]Invalid selection[/yellow]\n")
    
    except (ValueError, KeyboardInterrupt, EOFError):
        console.print("\n[dim]Cancelled[/dim]\n")


def main(args=None):
    """Main entry point for lac mcp commands."""
    # If called from argparse with args object
    if args and hasattr(args, 'mcp_action'):
        action = args.mcp_action
    # If called directly from command line
    elif len(sys.argv) >= 2:
        action = sys.argv[1].lower()
    else:
        action = None
    
    if not action:
        console.print("\n[bold]MCP Server Management[/bold]\n")
        console.print("Commands:")
        console.print("  lac mcp add     - Add a new MCP server")
        console.print("  lac mcp list    - List configured servers")
        console.print("  lac mcp remove  - Remove a server\n")
        return
    
    if action == "add":
        add_server()
    elif action == "list":
        list_servers()
    elif action == "remove":
        remove_server()
    else:
        console.print(f"[yellow]Unknown command: {action}[/yellow]")
        console.print("[dim]Use: lac mcp [add|list|remove][/dim]\n")


if __name__ == "__main__":
    main()
