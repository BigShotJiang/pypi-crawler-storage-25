"""
lac/formula_cli.py
──────────────────
CLI interface for managing coding formulas.

Commands:
  lac formula list
  lac formula add
  lac formula use <name>
  lac formula off
  lac formula show <name>
  lac formula edit <name>
  lac formula delete <name>
"""

import sys
from rich.console import Console
from rich.table import Table
from lac.agent import formula_manager

console = Console()


def cmd_list():
    """List all formulas, marking the active one."""
    formulas = formula_manager.list_formulas()
    
    if not formulas:
        console.print("[yellow]No formulas defined yet.[/yellow]")
        console.print("[dim]Create one with:[/dim] lac formula add\n")
        return
    
    table = Table(show_header=True, header_style="bold cyan")
    table.add_column("", width=2)
    table.add_column("Name", style="cyan")
    table.add_column("Description", style="dim")
    table.add_column("Rules", justify="right", style="dim")
    
    for formula in formulas:
        mark = "✓" if formula["is_active"] else ""
        name = formula["name"]
        desc = formula.get("description", "")
        rule_count = len(formula.get("rules", []))
        table.add_row(mark, name, desc, str(rule_count))
    
    console.print()
    console.print(table)
    console.print()


def cmd_add():
    """Interactive wizard to add a new formula."""
    console.print("\n[bold cyan]Create a new formula[/bold cyan]\n")
    
    try:
        name = input("Formula name: ").strip()
        if not name:
            console.print("[red]Error: Name is required[/red]\n")
            return
        
        # Check if formula already exists
        existing = formula_manager.get_formula(name)
        if existing:
            console.print(f"[yellow]Formula '{name}' already exists.[/yellow]")
            overwrite = input("Overwrite? [y/N] ").strip().lower()
            if overwrite not in ("y", "yes"):
                console.print("[dim]Cancelled.[/dim]\n")
                return
        
        description = input("Description: ").strip()
        
        console.print("\n[dim]Enter rules (one per line, empty line to finish):[/dim]")
        rules = []
        while True:
            rule = input(f"  {len(rules) + 1}. ").strip()
            if not rule:
                break
            rules.append(rule)
        
        if not rules:
            console.print("[red]Error: At least one rule is required[/red]\n")
            return
        
        formula_manager.save_formula(name, description, rules)
        console.print(f"\n[green]✓ Formula '{name}' saved with {len(rules)} rules[/green]")
        
        # Ask if they want to activate it
        activate = input("Activate this formula now? [Y/n] ").strip().lower()
        if activate in ("", "y", "yes"):
            formula_manager.set_active_formula(name)
            console.print(f"[green]✓ Formula '{name}' activated[/green]\n")
        else:
            console.print()
    
    except (KeyboardInterrupt, EOFError):
        console.print("\n[dim]Cancelled.[/dim]\n")


def cmd_use(name: str):
    """Set a formula as active."""
    if not name:
        console.print("[red]Error: Formula name is required[/red]")
        console.print("[dim]Usage:[/dim] lac formula use <name>\n")
        return
    
    if formula_manager.set_active_formula(name):
        console.print(f"[green]✓ Formula '{name}' activated[/green]\n")
    else:
        console.print(f"[red]Error: Formula '{name}' not found[/red]")
        console.print("[dim]List formulas with:[/dim] lac formula list\n")


def cmd_off():
    """Deactivate the current formula."""
    active = formula_manager.get_active_formula_name()
    if not active:
        console.print("[yellow]No formula is currently active[/yellow]\n")
        return
    
    formula_manager.deactivate_formula()
    console.print(f"[green]✓ Formula '{active}' deactivated[/green]\n")


def cmd_show(name: str):
    """Show all rules for a formula."""
    if not name:
        console.print("[red]Error: Formula name is required[/red]")
        console.print("[dim]Usage:[/dim] lac formula show <name>\n")
        return
    
    formula = formula_manager.get_formula(name)
    if not formula:
        console.print(f"[red]Error: Formula '{name}' not found[/red]")
        console.print("[dim]List formulas with:[/dim] lac formula list\n")
        return
    
    console.print(f"\n[bold cyan]{formula['name']}[/bold cyan]")
    if formula.get("description"):
        console.print(f"[dim]{formula['description']}[/dim]")
    console.print()
    
    rules = formula.get("rules", [])
    if rules:
        console.print("[bold]Rules:[/bold]")
        for i, rule in enumerate(rules, 1):
            console.print(f"  {i}. {rule}")
    else:
        console.print("[dim]No rules defined[/dim]")
    
    console.print()


def cmd_edit(name: str):
    """Edit an existing formula."""
    if not name:
        console.print("[red]Error: Formula name is required[/red]")
        console.print("[dim]Usage:[/dim] lac formula edit <name>\n")
        return
    
    formula = formula_manager.get_formula(name)
    if not formula:
        console.print(f"[red]Error: Formula '{name}' not found[/red]")
        console.print("[dim]List formulas with:[/dim] lac formula list\n")
        return
    
    console.print(f"\n[bold cyan]Editing formula: {name}[/bold cyan]\n")
    
    try:
        # Show current description
        current_desc = formula.get("description", "")
        console.print(f"[dim]Current description:[/dim] {current_desc}")
        description = input("New description (or Enter to keep): ").strip()
        if not description:
            description = current_desc
        
        # Show current rules
        current_rules = formula.get("rules", [])
        console.print(f"\n[dim]Current rules ({len(current_rules)}):[/dim]")
        for i, rule in enumerate(current_rules, 1):
            console.print(f"  {i}. {rule}")
        
        console.print("\n[dim]Enter new rules (one per line, empty line to finish):[/dim]")
        rules = []
        while True:
            rule = input(f"  {len(rules) + 1}. ").strip()
            if not rule:
                break
            rules.append(rule)
        
        if not rules:
            console.print("[red]Error: At least one rule is required[/red]\n")
            return
        
        formula_manager.save_formula(name, description, rules)
        console.print(f"\n[green]✓ Formula '{name}' updated with {len(rules)} rules[/green]\n")
    
    except (KeyboardInterrupt, EOFError):
        console.print("\n[dim]Cancelled.[/dim]\n")


def cmd_delete(name: str):
    """Delete a formula."""
    if not name:
        console.print("[red]Error: Formula name is required[/red]")
        console.print("[dim]Usage:[/dim] lac formula delete <name>\n")
        return
    
    formula = formula_manager.get_formula(name)
    if not formula:
        console.print(f"[red]Error: Formula '{name}' not found[/red]")
        console.print("[dim]List formulas with:[/dim] lac formula list\n")
        return
    
    # Show formula details
    console.print(f"\n[bold]Formula: {name}[/bold]")
    if formula.get("description"):
        console.print(f"[dim]{formula['description']}[/dim]")
    console.print(f"[dim]Rules: {len(formula.get('rules', []))}[/dim]\n")
    
    try:
        confirm = input("Delete this formula? [y/N] ").strip().lower()
        if confirm not in ("y", "yes"):
            console.print("[dim]Cancelled.[/dim]\n")
            return
        
        formula_manager.delete_formula(name)
        console.print(f"[green]✓ Formula '{name}' deleted[/green]\n")
    
    except (KeyboardInterrupt, EOFError):
        console.print("\n[dim]Cancelled.[/dim]\n")


def main(args):
    """Main entry point for formula CLI."""
    if not args.formula_action:
        # No action specified, show help
        console.print("\n[bold cyan]lac formula[/bold cyan] - Manage coding formulas\n")
        console.print("[bold]Commands:[/bold]")
        console.print("  [cyan]list[/cyan]              List all formulas")
        console.print("  [cyan]add[/cyan]               Create a new formula")
        console.print("  [cyan]use[/cyan] <name>        Activate a formula")
        console.print("  [cyan]off[/cyan]               Deactivate current formula")
        console.print("  [cyan]show[/cyan] <name>       Show formula details")
        console.print("  [cyan]edit[/cyan] <name>       Edit a formula")
        console.print("  [cyan]delete[/cyan] <name>     Delete a formula\n")
        return
    
    action = args.formula_action
    
    if action == "list":
        cmd_list()
    elif action == "add":
        cmd_add()
    elif action == "use":
        cmd_use(args.formula_name)
    elif action == "off":
        cmd_off()
    elif action == "show":
        cmd_show(args.formula_name)
    elif action == "edit":
        cmd_edit(args.formula_name)
    elif action == "delete":
        cmd_delete(args.formula_name)
    else:
        console.print(f"[red]Unknown action: {action}[/red]")
        console.print("[dim]Run 'lac formula' to see available commands[/dim]\n")
