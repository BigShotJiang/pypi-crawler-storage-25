"""
lac/agent/watch.py
Watch mode - browser monitoring with voice recognition
"""

import asyncio
import time
import json
import sys
import subprocess
from datetime import datetime
from rich.console import Console

console = Console()

timeline = []
start_time = None
stop_event = asyncio.Event()

SKIP_EXTENSIONS = (".png", ".jpg", ".jpeg", ".gif", ".svg", ".ico",
                   ".woff", ".woff2", ".ttf", ".eot", ".mp4", ".webp")


def check_playwright_installed():
    """Check if playwright is installed."""
    try:
        import playwright
        return True
    except ImportError:
        return False


def install_playwright():
    """Install playwright and chromium browser."""
    console.print("\n[yellow]⚠ Watch mode requires playwright[/yellow]")
    
    try:
        answer = input("Install now? [y/n]: ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        console.print("[dim]Cancelled[/dim]")
        return False
    
    if answer != "y":
        console.print("[dim]Cancelled[/dim]")
        return False
    
    console.print("\n[dim]Installing playwright...[/dim]")
    
    try:
        # Install playwright package
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", "playwright"],
            capture_output=True,
            text=True
        )
        
        if result.returncode != 0:
            console.print(f"[red]✗ Failed to install playwright[/red]")
            console.print(f"[dim]{result.stderr}[/dim]")
            return False
        
        console.print("[green]✓ playwright installed[/green]")
        
        # Install browser binaries
        console.print("[dim]Installing browser binaries...[/dim]")
        result = subprocess.run(
            [sys.executable, "-m", "playwright", "install", "chromium"],
            capture_output=True,
            text=True
        )
        
        if result.returncode != 0:
            console.print(f"[red]✗ Failed to install chromium[/red]")
            console.print(f"[dim]{result.stderr}[/dim]")
            return False
        
        console.print("[green]✓ Chromium installed[/green]")
        console.print("\n[cyan]Please restart lac agent to use /watch[/cyan]")
        console.print("[dim](exit and run 'lac agent' again)[/dim]\n")
        
        return True
        
    except Exception as e:
        console.print(f"[red]✗ Installation failed: {e}[/red]")
        return False


def push_event(event):
    """Add event to timeline."""
    t = round(time.time() - start_time, 2)
    entry = {"t": t, "type": event.get("type"), "value": event.get("value")}
    timeline.append(entry)
    
    colors = {
        "VOICE":         "\033[95m",
        "CLICK":         "\033[94m",
        "NAV":           "\033[92m",
        "INPUT":         "\033[93m",
        "NETWORK":       "\033[96m",
        "NETWORK_ERR":   "\033[91m",
        "CONSOLE_ERROR": "\033[91m",
        "SEND":          "\033[92m",
    }
    reset = "\033[0m"
    color = colors.get(entry["type"], "")
    ts = datetime.now().strftime("%H:%M:%S")
    print(f"{color}[{ts}] +{entry['t']}s  {entry['type']:<15} {entry['value']}{reset}")


def on_send_to_ai(data=None):
    """Triggered when user clicks Send to AI button."""
    push_event({"type": "SEND", "value": "user triggered send to AI"})
    stop_event.set()


INJECT_SCRIPT = r"""
(function() {

    function injectPanel() {
        // bail if already injected
        if (document.getElementById('__lac_watch__')) return;

        const panel = document.createElement('div');
        panel.id = '__lac_watch__';
        panel.style.cssText = `
            position: fixed;
            bottom: 24px;
            right: 24px;
            z-index: 2147483647;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            display: flex;
            flex-direction: column;
            align-items: flex-end;
            gap: 8px;
            cursor: move;
        `;
        
        // Make panel draggable
        let isDragging = false;
        let offsetX = 0, offsetY = 0;
        
        panel.onmousedown = (e) => {
            if (e.target.tagName === 'BUTTON') return;
            isDragging = true;
            offsetX = e.clientX - panel.offsetLeft;
            offsetY = e.clientY - panel.offsetTop;
            panel.style.cursor = 'grabbing';
        };
        
        document.onmousemove = (e) => {
            if (!isDragging) return;
            e.preventDefault();
            let x = e.clientX - offsetX;
            let y = e.clientY - offsetY;
            
            // Keep within viewport
            x = Math.max(0, Math.min(x, window.innerWidth - panel.offsetWidth));
            y = Math.max(0, Math.min(y, window.innerHeight - panel.offsetHeight));
            
            panel.style.left = x + 'px';
            panel.style.top = y + 'px';
            panel.style.right = 'auto';
            panel.style.bottom = 'auto';
        };
        
        document.onmouseup = () => {
            if (isDragging) {
                isDragging = false;
                panel.style.cursor = 'move';
            }
        };

        const badge = document.createElement('div');
        badge.style.cssText = `
            background: #18181b;
            color: #a1a1aa;
            font-size: 11px;
            padding: 4px 10px;
            border-radius: 20px;
            letter-spacing: 0.02em;
            display: flex;
            align-items: center;
            gap: 6px;
        `;

        const micDot = document.createElement('span');
        micDot.style.cssText = `
            width: 7px; height: 7px;
            border-radius: 50%;
            background: #52525b;
            display: inline-block;
            transition: background 0.2s;
        `;

        const badgeText = document.createElement('span');
        badgeText.textContent = '0 events';

        badge.appendChild(micDot);
        badge.appendChild(badgeText);

        const btn = document.createElement('button');
        btn.style.cssText = `
            background: #18181b;
            color: #fff;
            border: 1px solid #3f3f46;
            border-radius: 10px;
            padding: 10px 18px;
            font-size: 13px;
            font-weight: 500;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 8px;
            letter-spacing: 0.01em;
            transition: background 0.15s, border-color 0.15s;
            box-shadow: 0 2px 12px rgba(0,0,0,0.3);
        `;
        btn.innerHTML = `
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="22" y1="2" x2="11" y2="13"></line>
                <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
            </svg>
            Send to AI
        `;
        btn.onmouseenter = () => { btn.style.background = '#27272a'; btn.style.borderColor = '#71717a'; };
        btn.onmouseleave = () => { btn.style.background = '#18181b'; btn.style.borderColor = '#3f3f46'; };
        btn.onclick = () => {
            btn.innerHTML = 'Sending...';
            btn.style.opacity = '0.6';
            btn.style.pointerEvents = 'none';
            window.sendToAI();
        };

        panel.appendChild(badge);
        panel.appendChild(btn);
        document.body.appendChild(panel);

        // patch pushEvent to update counter
        let count = 0;
        const orig = window.pushEvent;
        window.pushEvent = function(e) {
            count++;
            badgeText.textContent = count + ' event' + (count === 1 ? '' : 's');
            return orig(e);
        };

        // wire mic dot
        if ('webkitSpeechRecognition' in window) {
            const recognition = new webkitSpeechRecognition();
            recognition.continuous = true;
            recognition.interimResults = false;
            recognition.lang = 'en-US';
            let blocked = false;

            recognition.onstart = () => { micDot.style.background = '#22c55e'; };
            recognition.onresult = (e) => {
                const t = e.results[e.results.length - 1][0].transcript.trim();
                if (t) window.pushEvent({ type: 'VOICE', value: t });
            };
            recognition.onerror = (e) => {
                micDot.style.background = '#ef4444';
                if (e.error === 'not-allowed') blocked = true;
                else if (e.error !== 'no-speech')
                    window.pushEvent({ type: 'VOICE', value: '[mic error: ' + e.error + ']' });
            };
            recognition.onend = () => {
                micDot.style.background = '#52525b';
                if (!blocked) try { recognition.start(); } catch(e) {}
            };
            recognition.start();
        }
    }

    // wait for body — init script fires before DOM is ready
    if (document.body) {
        injectPanel();
    } else {
        document.addEventListener('DOMContentLoaded', injectPanel);
    }

    // ─── clicks ───────────────────────────────────────────────────────────
    document.addEventListener('click', (e) => {
        if (e.target.closest('#__lac_watch__')) return;
        const el = e.target;
        let label = el.tagName.toLowerCase();
        if (el.id)        label += '#' + el.id;
        if (el.className) label += '.' + el.className.toString().trim().replace(/\s+/g, '.');
        const text = el.innerText?.trim().slice(0, 60);
        if (text) label += ' "' + text + '"';
        window.pushEvent({ type: 'CLICK', value: label });
    }, true);

    // ─── inputs ───────────────────────────────────────────────────────────
    document.addEventListener('input', (e) => {
        const el = e.target;
        const field = el.name || el.id || el.placeholder || el.type || 'input';
        window.pushEvent({ type: 'INPUT', value: field + ' = "' + el.value.slice(0, 80) + '"' });
    }, true);

    // ─── SPA nav ──────────────────────────────────────────────────────────
    const _pushState = history.pushState.bind(history);
    history.pushState = function(...args) {
        _pushState(...args);
        window.pushEvent({ type: 'NAV', value: location.href });
    };
    window.addEventListener('popstate', () => {
        window.pushEvent({ type: 'NAV', value: location.href });
    });

})();
"""


async def run_watch(url: str = None):
    """Launch watch mode with browser monitoring."""
    global start_time, stop_event, timeline
    
    # Check if playwright is installed
    if not check_playwright_installed():
        installed = install_playwright()
        if not installed:
            return "Watch mode cancelled - playwright not installed"
        return "Playwright installed successfully. Please restart the agent to use /watch"
    
    # Import playwright (only after checking it's installed)
    try:
        from playwright.async_api import async_playwright
    except ImportError:
        return "Playwright not available. Please restart the agent after installation."
    
    # Reset state
    timeline = []
    stop_event = asyncio.Event()
    
    # Get URL from user if not provided
    if not url:
        console.print("\n[cyan]Watch Mode[/cyan]")
        try:
            url = input("URL or file path (default: http://localhost:3000): ").strip()
        except (EOFError, KeyboardInterrupt):
            return "Watch mode cancelled"
        
        if not url:
            url = "http://localhost:3000"
    
    # Check if it's a local file path
    http_server = None
    original_dir = None
    if not url.startswith("http"):
        from pathlib import Path
        import os
        
        # Check if it's a file path
        file_path = Path(url)
        if file_path.exists() and file_path.is_file():
            # Start a local HTTP server
            import http.server
            import socketserver
            import threading
            
            # Get the directory and filename
            serve_dir = file_path.parent.resolve()
            filename = file_path.name
            
            # Find an available port
            port = 8765
            for attempt_port in range(8765, 8800):
                try:
                    handler = http.server.SimpleHTTPRequestHandler
                    socketserver.TCPServer.allow_reuse_address = True
                    http_server = socketserver.TCPServer(("", attempt_port), handler)
                    port = attempt_port
                    break
                except OSError:
                    continue
            
            if not http_server:
                return "Could not find available port for local server"
            
            # Change to the file's directory
            original_dir = os.getcwd()
            os.chdir(serve_dir)
            
            # Start server in background thread
            def serve():
                http_server.serve_forever()
            
            server_thread = threading.Thread(target=serve, daemon=True)
            server_thread.start()
            
            url = f"http://localhost:{port}/{filename}"
            console.print(f"[dim]Started local server at http://localhost:{port}[/dim]")
        else:
            # Not a file, treat as domain
            url = "https://" + url
    
    console.print("\n[green]Starting watch mode...[/green]")
    console.print("[dim]Speak into your mic, browse around, click 'Send to AI' when done[/dim]\n")
    
    browser = None
    try:
        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=False, channel="chrome")
            context = await browser.new_context()
            await context.grant_permissions(["microphone"])
            await context.expose_function("pushEvent", push_event)
            await context.expose_function("sendToAI", on_send_to_ai)
            await context.add_init_script(INJECT_SCRIPT)
            
            page = await context.new_page()
            
            # Network monitoring
            async def on_request(request):
                if any(request.url.split("?")[0].endswith(ext) for ext in SKIP_EXTENSIONS):
                    return
                if request.resource_type == "document":
                    return
                if request.resource_type in ("xhr", "fetch", "websocket", "other"):
                    # Capture request body and headers
                    request_info = f"→ {request.method} {request.url.split('?')[0]}"
                    
                    # Add request headers (filter sensitive ones)
                    headers = dict(request.headers)
                    filtered_headers = {k: v for k, v in headers.items() if k.lower() not in ['authorization', 'cookie', 'set-cookie']}
                    if filtered_headers:
                        request_info += f" | Headers: {json.dumps(filtered_headers, ensure_ascii=False)[:300]}"
                    
                    # Add request body if present
                    try:
                        if request.post_data:
                            body = request.post_data
                            if len(body) > 500:
                                body = body[:500] + "..."
                            request_info += f" | Body: {body}"
                    except Exception:
                        pass
                    
                    push_event({"type": "NETWORK", "value": request_info})
            
            async def on_response(response):
                if any(response.url.split("?")[0].endswith(ext) for ext in SKIP_EXTENSIONS):
                    return
                if response.request.resource_type == "document":
                    return
                if response.request.resource_type in ("xhr", "fetch", "websocket", "other"):
                    status = response.status
                    event_type = "NETWORK_ERR" if status >= 400 else "NETWORK"
                    
                    response_info = f"← {response.request.method} {response.url.split('?')[0]} {status}"
                    
                    # Add response headers (filter sensitive ones)
                    headers = dict(response.headers)
                    filtered_headers = {k: v for k, v in headers.items() if k.lower() not in ['authorization', 'set-cookie', 'cookie']}
                    if filtered_headers:
                        response_info += f" | Headers: {json.dumps(filtered_headers, ensure_ascii=False)[:300]}"
                    
                    # Try to capture JSON response body
                    try:
                        body = await response.body()
                        text = body.decode('utf-8', errors='ignore')
                        # Check if it's JSON
                        if text and (text.strip().startswith('{') or text.strip().startswith('[')):
                            # Truncate if too long
                            if len(text) > 500:
                                response_info += f" | Body: {text[:500]}..."
                            else:
                                response_info += f" | Body: {text}"
                    except Exception:
                        pass
                    
                    push_event({"type": event_type, "value": response_info})
            
            page.on("request", on_request)
            page.on("response", on_response)
            
            # Console monitoring
            def on_console(msg):
                if msg.type == "error":
                    if '__lac_watch__' not in msg.text:
                        push_event({"type": "CONSOLE_ERROR", "value": msg.text[:120]})
            
            page.on("console", on_console)
            page.on("pageerror", lambda err: push_event({"type": "CONSOLE_ERROR", "value": f"Uncaught: {str(err)[:120]}"}))
            
            # Navigation monitoring
            last_nav_base = ""
            async def on_nav(frame):
                nonlocal last_nav_base
                if frame == page.main_frame:
                    base = frame.url.split("#")[0]
                    if base != last_nav_base:
                        last_nav_base = base
                        push_event({"type": "NAV", "value": frame.url})
            
            page.on("framenavigated", on_nav)
            
            start_time = time.time()
            await page.goto(url)
            console.print(f"[green]✓ Attached to {url}[/green]")
            console.print("[dim]Floating button bottom-right — click 'Send to AI' when done[/dim]\n")
            
            try:
                await asyncio.wait_for(stop_event.wait(), timeout=3600)
            except (asyncio.TimeoutError, asyncio.CancelledError, KeyboardInterrupt):
                pass
            
            # Properly close browser before exiting context
            if browser:
                await context.close()
                await browser.close()
                browser = None
        
        duration = round(time.time() - start_time, 1)
        console.print(f"\n[green]{'─'*60}[/green]")
        console.print(f"[green]Session ended — {duration}s — {len(timeline)} events[/green]")
        console.print(f"[green]{'─'*60}[/green]\n")
        
        # Stop local server if we started one
        if http_server:
            http_server.shutdown()
            if original_dir:
                os.chdir(original_dir)
        
        # Format timeline for AI
        summary = f"Watch session: {duration}s, {len(timeline)} events\n\n"
        summary += "Timeline:\n"
        for event in timeline:
            # Keep full value for AI analysis (already truncated during capture)
            summary += f"  +{event['t']}s  {event['type']:<15} {event['value']}\n"
        
        return summary
        
    except Exception as e:
        # Clean up browser if still open
        if browser:
            try:
                await browser.close()
            except Exception:
                pass
        
        # Stop local server if we started one
        if http_server:
            http_server.shutdown()
            if original_dir:
                os.chdir(original_dir)
        return f"Watch mode error: {str(e)}"
