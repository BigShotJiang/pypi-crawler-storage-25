"""
lac/agent/main.py
Entry point for LacAgent
"""

import os
import httpx
from rich.console import Console
from rich.panel import Panel
from lac.agent.agent import Agent

console = Console()

CURRENT_VERSION = "0.3.5"


def check_for_updates():
    """Check for updates from lacai.io server."""
    try:
        response = httpx.get("https://lacai.io/version.json", timeout=2.0)
        if response.status_code == 200:
            data = response.json()
            latest = data.get("latest", "")
            changelog = data.get("changelog", "")
            
            if latest and latest > CURRENT_VERSION:
                console.print()
                console.print(Panel(
                    f"[bold yellow]Update Available: v{latest}[/bold yellow]\n"
                    f"[dim]You have: v{CURRENT_VERSION}[/dim]\n\n"
                    f"{changelog}\n\n"
                    f"[cyan]Run:[/cyan] pip install --upgrade lac-cli",
                    border_style="yellow",
                    padding=(1, 2)
                ))
                console.print()
    except Exception:
        pass  # Silently fail if can't check


def launch():
    """Launch LacAgent"""
    check_for_updates()
    
    try:
        cwd = os.getcwd()
        agent = Agent(cwd)
        agent.run()
    except ModuleNotFoundError as e:
        if "anthropic" in str(e):
            console.print("\n[red]✗ Anthropic library not installed[/red]")
            console.print("[dim]Install with:[/dim] pip install anthropic\n")
        elif "openai" in str(e):
            console.print("\n[red]✗ OpenAI library not installed[/red]")
            console.print("[dim]Install with:[/dim] pip install openai\n")
        else:
            console.print(f"\n[red]✗ Missing dependency: {e}[/red]\n")
    except RuntimeError as e:
        console.print(f"\n[red]Error: {e}[/red]\n")
    except KeyboardInterrupt:
        console.print("\n[bold cyan]bye 👋[/bold cyan]\n")
    except Exception as e:
        console.print(f"\n[red]Unexpected error: {e}[/red]\n")
