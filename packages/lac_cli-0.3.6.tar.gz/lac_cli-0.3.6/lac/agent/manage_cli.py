"""
lac/agent/manage_cli.py
───────────────────────
CLI interface for manage mode (token management).

Commands:
  lac manage on/off
  lac manage status
  lac manage strategy <trim|warn|compact>
  lac manage reset
  lac manage config
"""

import sys
from rich.console import Console
from lac import config

console = Console()


def cmd_on():
    """Enable manage mode."""
    cfg = config.load_config()
    
    if "manage_mode" not in cfg:
        cfg["manage_mode"] = {
            "enabled": True,
            "strategy": "trim",
            "warn_at": 0.75,
            "hard_limit": 0.90,
            "keep_last": 6,
            "show_cost": True
        }
    else:
        cfg["manage_mode"]["enabled"] = True
    
    config.save_config(cfg)
    console.print("[green]✓ Manage mode enabled[/green]")
    console.print(f"[dim]Strategy: {cfg['manage_mode']['strategy']}[/dim]\n")


def cmd_off():
    """Disable manage mode."""
    cfg = config.load_config()
    
    if "manage_mode" in cfg:
        cfg["manage_mode"]["enabled"] = False
        config.save_config(cfg)
    
    console.print("[yellow]Manage mode disabled[/yellow]\n")


def cmd_status():
    """Show current manage mode status."""
    cfg = config.load_config()
    manage_cfg = cfg.get("manage_mode", {})
    
    if not manage_cfg.get("enabled", False):
        console.print("[yellow]Manage mode: OFF[/yellow]\n")
        return
    
    console.print("[green]Manage mode: ON[/green]")
    console.print(f"  Strategy: [cyan]{manage_cfg.get('strategy', 'trim')}[/cyan]")
    console.print(f"  Warn at: [yellow]{int(manage_cfg.get('warn_at', 0.75) * 100)}%[/yellow]")
    console.print(f"  Hard limit: [red]{int(manage_cfg.get('hard_limit', 0.90) * 100)}%[/red]")
    console.print(f"  Keep last: [cyan]{manage_cfg.get('keep_last', 6)}[/cyan] exchanges")
    console.print(f"  Show cost: [cyan]{manage_cfg.get('show_cost', True)}[/cyan]\n")


def cmd_strategy(strategy: str):
    """Set strategy."""
    if strategy not in ["trim", "warn", "compact"]:
        console.print("[red]Error: Strategy must be 'trim', 'warn', or 'compact'[/red]\n")
        return
    
    cfg = config.load_config()
    
    if "manage_mode" not in cfg:
        cfg["manage_mode"] = {
            "enabled": True,
            "strategy": strategy,
            "warn_at": 0.75,
            "hard_limit": 0.90,
            "keep_last": 6,
            "show_cost": True
        }
    else:
        cfg["manage_mode"]["strategy"] = strategy
    
    config.save_config(cfg)
    console.print(f"[green]✓ Strategy set to '{strategy}'[/green]\n")


def cmd_reset():
    """Reset session cost (note: only works during active session)."""
    console.print("[yellow]Session cost will be reset on next agent start[/yellow]")
    console.print("[dim]Note: This only affects the display, not the config[/dim]\n")


def cmd_config():
    """Interactive configuration wizard."""
    console.print("\n[bold cyan]Manage Mode Configuration[/bold cyan]\n")
    
    cfg = config.load_config()
    current = cfg.get("manage_mode", {
        "enabled": False,
        "strategy": "trim",
        "warn_at": 0.75,
        "hard_limit": 0.90,
        "keep_last": 6,
        "show_cost": True
    })
    
    try:
        # Strategy
        console.print("[bold]Strategy:[/bold]")
        console.print("  [cyan]1.[/cyan] trim - Remove old messages, keep last N")
        console.print("  [cyan]2.[/cyan] warn - Show warnings only, AI adjusts behavior")
        console.print("  [cyan]3.[/cyan] compact - AI summarizes old messages\n")
        
        strategy_choice = input(f"Select strategy [1-3] (current: {current['strategy']}): ").strip()
        if strategy_choice == "1":
            strategy = "trim"
        elif strategy_choice == "2":
            strategy = "warn"
        elif strategy_choice == "3":
            strategy = "compact"
        else:
            strategy = current["strategy"]
        
        # Warn threshold
        warn_input = input(f"\nWarn at what % of context? (current: {int(current['warn_at'] * 100)}): ").strip()
        warn_at = float(warn_input) / 100 if warn_input else current["warn_at"]
        
        # Hard limit
        limit_input = input(f"Hard limit at what %? (current: {int(current['hard_limit'] * 100)}): ").strip()
        hard_limit = float(limit_input) / 100 if limit_input else current["hard_limit"]
        
        # Keep last
        keep_input = input(f"\nKeep last N exchanges? (current: {current['keep_last']}): ").strip()
        keep_last = int(keep_input) if keep_input else current["keep_last"]
        
        # Show cost
        cost_input = input(f"Show cost in status bar? [Y/n] (current: {current['show_cost']}): ").strip().lower()
        if cost_input == "n":
            show_cost = False
        elif cost_input == "y":
            show_cost = True
        else:
            show_cost = current["show_cost"]
        
        # Save
        cfg["manage_mode"] = {
            "enabled": True,
            "strategy": strategy,
            "warn_at": warn_at,
            "hard_limit": hard_limit,
            "keep_last": keep_last,
            "show_cost": show_cost
        }
        
        config.save_config(cfg)
        console.print("\n[green]✓ Configuration saved[/green]")
        console.print(f"[dim]Strategy: {strategy}, Warn: {int(warn_at*100)}%, Limit: {int(hard_limit*100)}%[/dim]\n")
    
    except (KeyboardInterrupt, EOFError):
        console.print("\n[dim]Cancelled[/dim]\n")
    except ValueError:
        console.print("\n[red]Invalid input[/red]\n")


def main(args):
    """Main entry point for manage CLI."""
    if not args.manage_action:
        # No action specified, show help
        console.print("\n[bold cyan]lac manage[/bold cyan] - Token management\n")
        console.print("[bold]Commands:[/bold]")
        console.print("  [cyan]on[/cyan]                 Enable manage mode")
        console.print("  [cyan]off[/cyan]                Disable manage mode")
        console.print("  [cyan]status[/cyan]             Show current status")
        console.print("  [cyan]strategy[/cyan] <name>    Set strategy (trim/warn/compact)")
        console.print("  [cyan]reset[/cyan]              Reset session cost counter")
        console.print("  [cyan]config[/cyan]             Interactive configuration\n")
        return
    
    action = args.manage_action
    
    if action == "on":
        cmd_on()
    elif action == "off":
        cmd_off()
    elif action == "status":
        cmd_status()
    elif action == "strategy":
        if not args.manage_value:
            console.print("[red]Error: Strategy name required[/red]")
            console.print("[dim]Usage:[/dim] lac manage strategy <trim|warn|compact>\n")
        else:
            cmd_strategy(args.manage_value)
    elif action == "reset":
        cmd_reset()
    elif action == "config":
        cmd_config()
    else:
        console.print(f"[red]Unknown action: {action}[/red]")
        console.print("[dim]Run 'lac manage' to see available commands[/dim]\n")
