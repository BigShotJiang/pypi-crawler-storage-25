"""
lac/agent/token_manager.py
───────────────────────────
Token management system for the agent.

Features:
- Track token usage from native SDK responses
- Display status bar with usage and cost
- Strategies: trim, warn, compact
- Pre-count tokens before sending
- Cost tracking per session
"""

import tiktoken
from typing import Optional, Tuple
from rich.console import Console

console = Console()

MODEL_LIMITS = {
    # Claude models
    "claude-3-5-sonnet-20241022": 200000,
    "claude-3-5-sonnet": 200000,
    "claude-3-opus": 200000,
    "claude-3-sonnet": 200000,
    "claude-3-haiku": 200000,
    "claude-sonnet-4-20250514": 200000,
    "claude-sonnet-4": 200000,
    "claude-sonnet-4-5": 200000,
    "claude-haiku-4-5-20251001": 200000,
    "claude-haiku-4": 200000,
    "claude-3-5-haiku": 200000,
    "claude-sonnet-4-6": 1000000,  # 1M context
    "claude-opus-4-6": 1000000,    # 1M context
    "claude-opus-4-7": 1000000,    # 1M context

    # OpenAI models
    "gpt-4o": 128000,
    "gpt-4o-mini": 128000,
    "gpt-4-turbo": 128000,
    "gpt-4": 8192,
    "gpt-3.5-turbo": 16385,
    "o1": 200000,
    "o1-mini": 128000,

    # Default fallback
    "default": 200000
}

MODEL_COSTS = {
    # Claude models (per 1M tokens, converted to per 1K)
    "claude-3-5-sonnet-20241022": {"input": 0.003, "output": 0.015},
    "claude-3-5-sonnet": {"input": 0.003, "output": 0.015},
    "claude-3-opus": {"input": 0.015, "output": 0.075},
    "claude-3-sonnet": {"input": 0.003, "output": 0.015},
    "claude-3-haiku": {"input": 0.00025, "output": 0.00125},
    "claude-sonnet-4-20250514": {"input": 0.003, "output": 0.015},
    "claude-sonnet-4": {"input": 0.003, "output": 0.015},
    "claude-sonnet-4-5": {"input": 0.003, "output": 0.015},
    "claude-haiku-4-5-20251001": {"input": 0.001, "output": 0.005},  # fixed: was 0.00025
    "claude-haiku-4": {"input": 0.001, "output": 0.005},
    "claude-3-5-haiku": {"input": 0.001, "output": 0.005},
    "claude-sonnet-4-6": {"input": 0.003, "output": 0.015},
    "claude-opus-4-6": {"input": 0.005, "output": 0.025},
    "claude-opus-4-7": {"input": 0.005, "output": 0.025},

    # OpenAI models (per 1M tokens, converted to per 1K)
    "gpt-4o": {"input": 0.0025, "output": 0.01},
    "gpt-4o-mini": {"input": 0.00015, "output": 0.0006},
    "gpt-4-turbo": {"input": 0.01, "output": 0.03},
    "gpt-4": {"input": 0.03, "output": 0.06},
    "gpt-3.5-turbo": {"input": 0.0005, "output": 0.0015},
    "o1": {"input": 0.015, "output": 0.06},
    "o1-mini": {"input": 0.003, "output": 0.012},

    # Default fallback
    "default": {"input": 0.001, "output": 0.003}
}
class TokenManager:
    def __init__(self, model: str, config: dict):
        self.model = model
        self.provider = config.get("provider", "claude")
        self.warn_at = config.get("warn_at", 0.75)
        self.hard_limit = config.get("hard_limit", 0.90)
        self.keep_last = config.get("keep_last", 6)
        self.show_cost = config.get("show_cost", True)
        
        # Get model limit
        self.model_limit = self._get_model_limit(model)
        
        # Session tracking
        self.current_tokens = 0
        self.session_cost = 0.0
        self.last_input_tokens = 0
        self.last_output_tokens = 0
        
        # Tiktoken encoder for pre-counting
        self.encoder = self._get_encoder(model)
    
    def _get_model_limit(self, model: str) -> int:
        """Get context limit for model."""
        # Try exact match
        if model in MODEL_LIMITS:
            return MODEL_LIMITS[model]
        
        # Try partial match
        for key in MODEL_LIMITS:
            if key in model.lower():
                return MODEL_LIMITS[key]
        
        # Default
        return MODEL_LIMITS["default"]
    
    def _get_encoder(self, model: str):
        """Get tiktoken encoder for model."""
        try:
            # Try to get model-specific encoder
            if "gpt" in model.lower() or "o1" in model.lower():
                return tiktoken.encoding_for_model("gpt-4")
            else:
                # Claude uses cl100k_base (same as GPT-4)
                return tiktoken.get_encoding("cl100k_base")
        except Exception:
            # Fallback
            return tiktoken.get_encoding("cl100k_base")
    
    def update_from_response(self, response, provider: str) -> dict:
        """
        Extract token usage from native SDK response.
        
        Args:
            response: Anthropic or OpenAI response object
            provider: "claude" or "openai"/"custom"
        
        Returns:
            dict with tokens, limit, percent, status, cost_this_call
        """
        if provider == "claude":
            # Anthropic response
            input_tokens = response.usage.input_tokens
            output_tokens = response.usage.output_tokens
            total_tokens = input_tokens + output_tokens
        else:
            # OpenAI/Custom response
            input_tokens = response.usage.prompt_tokens
            output_tokens = response.usage.completion_tokens
            total_tokens = input_tokens + output_tokens
        
        self.current_tokens = total_tokens
        self.last_input_tokens = input_tokens
        self.last_output_tokens = output_tokens
        
        # Calculate cost
        cost = self._calculate_cost(input_tokens, output_tokens)
        self.session_cost += cost
        
        # Calculate percentage
        pct = total_tokens / self.model_limit
        
        # Determine status
        if pct < self.warn_at:
            status = "ok"
        elif pct < self.hard_limit:
            status = "warn"
        else:
            status = "critical"
        
        return {
            "tokens": total_tokens,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "limit": self.model_limit,
            "percent": pct,
            "status": status,
            "cost_this_call": cost,
            "remaining": self.model_limit - total_tokens
        }
    
    def _calculate_cost(self, input_tokens: int, output_tokens: int) -> float:
        """Calculate cost for this call."""
        # Get pricing for model
        pricing = MODEL_COSTS.get(self.model, MODEL_COSTS["default"])
        
        # Calculate (prices are per 1K tokens)
        input_cost = (input_tokens / 1000) * pricing["input"]
        output_cost = (output_tokens / 1000) * pricing["output"]
        
        return input_cost + output_cost
    
    def count_messages(self, messages: list) -> int:
        """Count tokens in message list using tiktoken."""
        total = 0
        
        for msg in messages:
            # Count role
            total += len(self.encoder.encode(msg.get("role", "")))
            
            # Count content
            content = msg.get("content", "")
            if isinstance(content, str):
                total += len(self.encoder.encode(content))
            elif isinstance(content, list):
                # Handle tool results (list of dicts)
                for item in content:
                    if isinstance(item, dict):
                        total += len(self.encoder.encode(str(item)))
        
        # Add overhead for message formatting
        total += len(messages) * 4
        
        return total
    
    def get_token_budget_prompt(self) -> str:
        """
        Generate token budget awareness prompt for AI.
        Returns empty string if tokens are fine, warning if approaching limit.
        """
        if self.current_tokens == 0:
            return ""
        
        pct = self.current_tokens / self.model_limit
        remaining = self.model_limit - self.current_tokens
        
        if pct >= self.hard_limit:
            # Critical - be extremely concise
            return f"""
🔴 TOKEN BUDGET CRITICAL: {remaining:,} tokens remaining ({pct:.0%} used)
- Be EXTREMELY concise
- Use minimal explanations
- Prioritize code over descriptions
- Use abbreviations where clear
- Skip verbose output
"""
        elif pct >= self.warn_at:
            # Warning - be efficient
            return f"""
⚠ TOKEN BUDGET WARNING: {remaining:,} tokens remaining ({pct:.0%} used)
- Be concise and efficient
- Avoid verbose explanations
- Use file patches instead of full rewrites
- Focus on essential information only
"""
        
        return ""
    
    def format_status_bar(self) -> str:
        """Return visual status bar."""
        if self.current_tokens == 0:
            return ""
        
        pct = self.current_tokens / self.model_limit
        filled = int(pct * 20)
        bar = "█" * filled + "░" * (20 - filled)
        
        # Color based on status
        if pct >= self.hard_limit:
            color = "red"
        elif pct >= self.warn_at:
            color = "yellow"
        else:
            color = "green"
        
        tokens_k = self.current_tokens // 1000
        limit_k = self.model_limit // 1000
        
        cost_str = f"  ${self.session_cost:.4f}" if self.show_cost else ""
        
        return f"[{color}][{bar}] {tokens_k}k/{limit_k}k tokens{cost_str}[/{color}]"
    
    def trim_history(self, messages: list) -> Tuple[list, int]:
        """
        Trim history to keep system + last N exchanges.
        Returns (trimmed_messages, tokens_saved)
        """
        system_msgs = [m for m in messages if m.get("role") == "system"]
        non_system = [m for m in messages if m.get("role") != "system"]
        
        # Keep last keep_last * 2 messages (user + assistant pairs)
        keep_count = self.keep_last * 2
        
        if len(non_system) <= keep_count:
            return messages, 0
        
        # Calculate tokens before
        tokens_before = self.count_messages(messages)
        
        # Trim
        trimmed = system_msgs + non_system[-keep_count:]
        
        # Calculate tokens after
        tokens_after = self.count_messages(trimmed)
        tokens_saved = tokens_before - tokens_after
        
        return trimmed, tokens_saved
    
    def needs_compaction(self, messages: list) -> bool:
        """Check if messages need compaction."""
        token_count = self.count_messages(messages)
        threshold = int(self.model_limit * self.hard_limit)
        return token_count >= threshold
    
    def prepare_for_compaction(self, messages: list) -> Tuple[list, list, list]:
        """
        Split messages into: system, middle (to compact), recent (to keep).
        
        Returns:
            (system_msgs, middle_msgs, recent_msgs)
        """
        system_msgs = [m for m in messages if m.get("role") == "system"]
        non_system = [m for m in messages if m.get("role") != "system"]
        
        # Keep last keep_last * 2 messages
        keep_count = self.keep_last * 2
        
        if len(non_system) <= keep_count:
            # Nothing to compact
            return system_msgs, [], non_system
        
        recent_msgs = non_system[-keep_count:]
        middle_msgs = non_system[:-keep_count]
        
        return system_msgs, middle_msgs, recent_msgs
    
    def reset_session_cost(self):
        """Reset session cost counter."""
        self.session_cost = 0.0
