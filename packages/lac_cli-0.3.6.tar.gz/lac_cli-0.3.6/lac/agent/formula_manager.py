"""
lac/formula_manager.py
──────────────────────
Manages user-defined coding formulas (custom rules injected into AI system prompts).

Storage: ~/.lac/formulas.json
Schema:
{
  "active": "formula-name" | null,
  "formulas": [
    {
      "name": "formula-name",
      "description": "Brief description",
      "rules": ["rule 1", "rule 2", ...]
    }
  ]
}
"""

import json
from pathlib import Path
from typing import Optional

FORMULAS_FILE = Path.home() / ".lac" / "formulas.json"


def _ensure_formulas_file():
    """Create formulas.json if it doesn't exist."""
    FORMULAS_FILE.parent.mkdir(parents=True, exist_ok=True)
    if not FORMULAS_FILE.exists():
        FORMULAS_FILE.write_text(json.dumps({"active": None, "formulas": []}, indent=2))


def _load_formulas() -> dict:
    """Load formulas from disk."""
    _ensure_formulas_file()
    try:
        return json.loads(FORMULAS_FILE.read_text())
    except (json.JSONDecodeError, FileNotFoundError):
        return {"active": None, "formulas": []}


def _save_formulas(data: dict):
    """Save formulas to disk."""
    _ensure_formulas_file()
    FORMULAS_FILE.write_text(json.dumps(data, indent=2))


def get_active_formula_prompt() -> Optional[str]:
    """
    Get the formatted prompt for the active formula.
    Returns None if no formula is active.
    
    Format:
    CODING FORMULA: <name>
    <description>
    
    Rules:
    - <rule 1>
    - <rule 2>
    ...
    """
    data = _load_formulas()
    active_name = data.get("active")
    
    if not active_name:
        return None
    
    formula = next((f for f in data.get("formulas", []) if f["name"] == active_name), None)
    if not formula:
        return None
    
    rules = formula.get("rules", [])
    if not rules:
        return None
    
    prompt_lines = [
        f"CODING FORMULA: {formula['name']}",
        formula.get("description", ""),
        "",
        "Rules:",
    ]
    
    for rule in rules:
        prompt_lines.append(f"- {rule}")
    
    return "\n".join(prompt_lines)


def list_formulas() -> list[dict]:
    """Get all formulas with active status."""
    data = _load_formulas()
    active_name = data.get("active")
    formulas = data.get("formulas", [])
    
    return [
        {
            **formula,
            "is_active": formula["name"] == active_name
        }
        for formula in formulas
    ]


def get_formula(name: str) -> Optional[dict]:
    """Get a specific formula by name."""
    data = _load_formulas()
    return next((f for f in data.get("formulas", []) if f["name"] == name), None)


def save_formula(name: str, description: str, rules: list[str]):
    """Create or update a formula."""
    data = _load_formulas()
    formulas = data.get("formulas", [])
    
    # Remove existing formula with same name
    formulas = [f for f in formulas if f["name"] != name]
    
    # Add new formula
    formulas.append({
        "name": name,
        "description": description,
        "rules": rules
    })
    
    data["formulas"] = formulas
    _save_formulas(data)


def delete_formula(name: str) -> bool:
    """Delete a formula. Returns True if deleted, False if not found."""
    data = _load_formulas()
    formulas = data.get("formulas", [])
    
    # Check if formula exists
    if not any(f["name"] == name for f in formulas):
        return False
    
    # Deactivate if it's the active formula
    if data.get("active") == name:
        data["active"] = None
    
    # Remove formula
    data["formulas"] = [f for f in formulas if f["name"] != name]
    _save_formulas(data)
    return True


def set_active_formula(name: str) -> bool:
    """Set a formula as active. Returns True if successful, False if not found."""
    data = _load_formulas()
    formulas = data.get("formulas", [])
    
    # Check if formula exists
    if not any(f["name"] == name for f in formulas):
        return False
    
    data["active"] = name
    _save_formulas(data)
    return True


def deactivate_formula():
    """Deactivate the current formula."""
    data = _load_formulas()
    data["active"] = None
    _save_formulas(data)


def get_active_formula_name() -> Optional[str]:
    """Get the name of the active formula, or None."""
    data = _load_formulas()
    return data.get("active")
