"""
lac/agent/multi_agent.py
Multi-agent parallel execution with project manager
"""

import json
import threading
from typing import Callable
from rich.console import Console, Group
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.prompt import Prompt
from rich.panel import Panel
from rich.layout import Layout
from rich.live import Live
from rich.text import Text

console = Console()

# Import thread-local storage from agent module
from lac.agent.agent import _thread_local


# ─── Agent Runner (one per thread, fully isolated) ────────────────────────────

class AgentRunner:
    """
    Self-contained per-agent executor. Never touches parent state outside the lock.
    """

    def __init__(self, spec: dict, parent_agent, lock: threading.Lock):
        self.spec = spec
        self.parent = parent_agent
        self.lock = lock          # Shared lock — serialises ALL parent state mutations
        self.messages = []
        self.output = ""
        self.status = "idle"      # idle | running | submitted | approved | rejected
        self.attempts = 0
        self._user_prompt = ""
        self._codebase_context = ""
        self.log_lines = []       # Scrollable log for this agent

    def build_system_message(self, user_prompt: str, codebase_context: str) -> str:
        return (
            f"You are {self.spec['name']}, a specialized agent.\n"
            f"Your focus: {self.spec['focus']}\n\n"
            f"Original user request: {user_prompt}\n"
            f"{codebase_context}\n\n"
            "Work independently using the tools available. "
            "When done, summarize exactly what you accomplished."
        )

    def run(self, user_prompt: str, codebase_context: str, max_iterations: int = 20):
        self._user_prompt = user_prompt
        self._codebase_context = codebase_context
        self.status = "running"
        self.attempts += 1
        self.messages = [
            {"role": "user", "content": self.build_system_message(user_prompt, codebase_context)}
        ]
        self.output = self._run_tool_loop(max_iterations)
        self.status = "submitted"

    def retry(self, feedback: str, max_iterations: int = 20):
        """
        Rebuild a clean 3-message history:
          user  → original system prompt
          assistant → previous output   (gives the model context on what it tried)
          user  → PM feedback + revision request

        This guarantees no orphaned tool_use / tool_result IDs reach the API.
        """
        self.attempts += 1
        self.status = "running"

        previous_output = self.output or "I attempted the task but produced no output."
        self.messages = [
            {
                "role": "user",
                "content": self.build_system_message(self._user_prompt, self._codebase_context),
            },
            {
                "role": "assistant",
                "content": previous_output,
            },
            {
                "role": "user",
                "content": (
                    f"Project Manager feedback: {feedback}\n\n"
                    "Please revise your work based on this feedback."
                ),
            },
        ]
        self.output = self._run_tool_loop(max_iterations)
        self.status = "submitted"

    def _run_tool_loop(self, max_iterations: int) -> str:
        """
        Run the tool-use loop.  The ENTIRE save → call → execute → restore cycle
        is held under self.lock so no two threads corrupt parent.messages at once.
        File I/O inside _execute_tools_* is fast enough that serialisation here
        is not a meaningful bottleneck compared to API round-trips.
        """
        import copy

        _thread_local.suppress_spinner = True
        full_output = ""
        tool_calls = None  # ensure defined even if loop doesn't run

        try:
            for iteration in range(max_iterations):
                with self.lock:
                    original_messages = self.parent.messages
                    original_token_manager = self.parent.token_manager

                    # Give the parent our isolated message history
                    self.parent.messages = copy.deepcopy(self.messages)
                    self.parent.token_manager = None   # disable token tracking for sub-agents

                    try:
                        self.log_lines.append(f"[dim]Iteration {iteration + 1}[/dim]")
                        text, tool_calls, stop_reason = self.parent._send_with_fallback()
                        if text:
                            full_output += text + "\n"
                            self.log_lines.append(f"[green]Response:[/green] {text[:80]}..." if len(text) > 80 else f"[green]Response:[/green] {text}")

                        if tool_calls:
                            provider_name = self.parent.provider_chain[0][0]
                            for tc in tool_calls:
                                tool_name = tc.get("name") or tc.get("function", {}).get("name", "unknown")
                                self.log_lines.append(f"[cyan]Tool:[/cyan] {tool_name}")
                            
                            if provider_name == "claude":
                                self.parent._execute_tools_anthropic(tool_calls)
                            else:
                                self.parent._execute_tools_openai(text, tool_calls)

                        # Snapshot the updated (fully-paired) message history
                        self.messages = copy.deepcopy(self.parent.messages)

                    finally:
                        # Always restore parent — even if _send or _execute throws
                        self.parent.messages = original_messages
                        self.parent.token_manager = original_token_manager

                # Break *outside* the lock so we release it before checking
                if not tool_calls:
                    self.log_lines.append("[green]✓ Complete[/green]")
                    break

        finally:
            _thread_local.suppress_spinner = False

        return full_output.strip()


# ─── Project Manager ──────────────────────────────────────────────────────────

class ProjectManager:
    def __init__(self, parent_agent, lock: threading.Lock):
        self.parent = parent_agent
        self.lock = lock

    def _call(self, messages: list) -> str:
        """Thread-safe single-turn call using isolated messages."""
        import copy

        _thread_local.suppress_spinner = True
        with self.lock:
            original_messages = self.parent.messages
            self.parent.messages = messages
            try:
                text, _, _ = self.parent._send_with_fallback()
                return text or ""
            finally:
                self.parent.messages = original_messages
                _thread_local.suppress_spinner = False

    def review(self, agent: AgentRunner, user_prompt: str) -> tuple[bool, str]:
        prompt = (
            f"You are the Project Manager reviewing an agent's work.\n\n"
            f"Original request: {user_prompt}\n"
            f"Agent: {agent.spec['name']} — Focus: {agent.spec['focus']}\n\n"
            f"Agent output:\n{agent.output}\n\n"
            "Does the output fully address the agent's focus and the original request?\n\n"
            'Respond with ONLY valid JSON: {"approved": true/false, "feedback": "..."}'
        )
        text = self._call([{"role": "user", "content": prompt}])
        try:
            result = json.loads(_strip_json(text))
            return result.get("approved", False), result.get("feedback", "")
        except json.JSONDecodeError:
            return True, "Auto-approved (PM parse error)"

    def synthesize(self, agents: list[AgentRunner], user_prompt: str) -> str:
        approved = [a for a in agents if a.status == "approved"]
        outputs = "\n\n".join(
            f"**{a.spec['name']}** ({a.spec['focus']}):\n{a.output}"
            for a in approved
        )
        prompt = (
            f"You are the Project Manager. All agents have finished.\n\n"
            f"Original request: {user_prompt}\n\n"
            f"Agent outputs:\n{outputs}\n\n"
            "Provide a clear, concise final summary of what was accomplished."
        )
        return self._call([{"role": "user", "content": prompt}]).strip()


# ─── Multi-Agent Session ──────────────────────────────────────────────────────

class MultiAgentSession:
    """
    Orchestrates parallel agents + project manager.
    """

    def __init__(self, parent_agent):
        self.parent = parent_agent
        self.lock = threading.Lock()            # single lock shared by all runners + PM
        self.pm = ProjectManager(parent_agent, self.lock)
        self.undo_group: list = []
        self.progress = None

    # ── Agent Suggestion ──────────────────────────────────────────────────────

    def suggest_agents(self, user_prompt: str) -> list[dict]:
        prompt = (
            f"Given this user request, suggest 2-4 specialized agents to handle it in parallel.\n\n"
            f"User request: {user_prompt}\n\n"
            "You MUST respond with ONLY valid JSON in this exact format (no other text):\n"
            '{"agents": [{"id": 1, "name": "...", "role": "...", "focus": "..."}]}\n\n'
            "CRITICAL: Return ONLY the JSON object, no explanations, no markdown, no other text."
        )

        _thread_local.suppress_spinner = True
        with self.lock:
            original_messages = self.parent.messages
            self.parent.messages = [{"role": "user", "content": prompt}]
            try:
                text, _, _ = self.parent._send_with_fallback()
            finally:
                self.parent.messages = original_messages
                _thread_local.suppress_spinner = False

        try:
            text = _strip_json(text or "")
            if not text:
                console.print("[red]AI returned empty response for agent suggestions[/red]")
                return []
            data = json.loads(text)
            agents = data.get("agents", [])
            if not agents:
                console.print("[red]No agents found in AI response[/red]")
            return agents
        except json.JSONDecodeError as e:
            console.print(f"[red]Failed to parse agent suggestions: {e}[/red]")
            console.print(f"[dim]AI response was: {(text or '')[:300]}...[/dim]")
            return []

    # ── Interactive Edit ──────────────────────────────────────────────────────

    def edit_agents_interactive(self, agents: list[dict]) -> list[dict] | None:
        while True:
            self._print_agents_table(agents)
            console.print("[cyan]1.[/cyan] Run  [cyan]2.[/cyan] Edit  "
                          "[cyan]3.[/cyan] Add  [cyan]4.[/cyan] Remove  [cyan]5.[/cyan] Cancel\n")
            choice = Prompt.ask("Select option", choices=["1","2","3","4","5"], default="1")

            if choice == "1":
                return agents

            elif choice == "2":
                aid = Prompt.ask("Agent ID to edit")
                agent = next((a for a in agents if str(a["id"]) == aid), None)
                if not agent:
                    console.print(f"[red]Agent {aid} not found[/red]\n"); continue
                agent["name"]  = Prompt.ask("Name",  default=agent["name"])
                agent["role"]  = Prompt.ask("Role",  default=agent["role"])
                agent["focus"] = Prompt.ask("Focus", default=agent["focus"])
                console.print("[green]✓ Updated[/green]\n")

            elif choice == "3":
                new_id = max(a["id"] for a in agents) + 1
                agents.append({
                    "id":    new_id,
                    "name":  Prompt.ask("Name"),
                    "role":  Prompt.ask("Role"),
                    "focus": Prompt.ask("Focus"),
                })
                console.print(f"[green]✓ Added agent {new_id}[/green]\n")

            elif choice == "4":
                if len(agents) <= 1:
                    console.print("[yellow]Need at least 1 agent[/yellow]\n"); continue
                aid = Prompt.ask("Agent ID to remove")
                agents = [a for a in agents if str(a["id"]) != aid]
                console.print(f"[green]✓ Removed[/green]\n")

            elif choice == "5":
                return None

    # ── Main Entry ────────────────────────────────────────────────────────────

    def run_parallel(self, agents: list[dict], user_prompt: str) -> str | None:
        codebase_context = self._scan_codebase(user_prompt)

        # Pass the shared lock to every runner
        runners = [AgentRunner(spec, self.parent, self.lock) for spec in agents]

        console.print(f"\n[bold cyan]Running {len(runners)} agents in parallel...[/bold cyan]\n")

        approved_count = [0]
        total = len(runners)

        layout = Layout()
        layout.split_column(*[Layout(name=f"agent_{r.spec['id']}", size=8) for r in runners])

        def make_display():
            panels = []
            for r in runners:
                status_color = {"idle": "dim", "running": "cyan", "submitted": "yellow", 
                               "approved": "green", "rejected": "red"}.get(r.status, "white")
                
                log_text = "\n".join(r.log_lines[-4:]) if r.log_lines else "[dim]Waiting...[/dim]"
                
                # Create badge-style title
                status_icon = {"idle": "○", "running": "●", "submitted": "◐", 
                              "approved": "✓", "rejected": "✗"}.get(r.status, "○")
                title_text = f" {status_icon} {r.spec['name']} "
                
                panels.append(
                    Panel(
                        log_text,
                        title=f"[{status_color}]{title_text}[/{status_color}]",
                        title_align="left",
                        border_style=status_color,
                        height=5,
                    )
                )
            return Group(*panels)

        live = Live(make_display(), console=console, refresh_per_second=4)
        live.start()

        try:

            def run_one(runner: AgentRunner):
                undo_before = len(self.parent.tools.undo_stack._stack)

                try:
                    runner.run(user_prompt, codebase_context)
                    live.update(make_display())

                    with self.lock:
                        new_entries = self.parent.tools.undo_stack._stack[undo_before:]
                        self.undo_group.extend(new_entries)

                    MAX_RETRIES = 3
                    while runner.attempts <= MAX_RETRIES:
                        runner.log_lines.append("[dim]PM reviewing...[/dim]")
                        live.update(make_display())
                        
                        approved, feedback = self.pm.review(runner, user_prompt)

                        if approved:
                            runner.status = "approved"
                            runner.log_lines.append("[green]✓ PM Approved[/green]")
                            with self.lock:
                                approved_count[0] += 1
                            live.update(make_display())
                            return

                        if runner.attempts >= MAX_RETRIES:
                            break

                        runner.log_lines.append(f"[yellow]PM Feedback: {feedback[:50]}...[/yellow]")
                        live.update(make_display())
                        runner.retry(feedback)
                        live.update(make_display())

                    runner.status = "rejected"
                    runner.log_lines.append("[red]✗ PM Rejected[/red]")
                    live.update(make_display())

                except Exception as e:
                    runner.status = "rejected"
                    runner.log_lines.append(f"[red]Error: {str(e)[:50]}[/red]")
                    live.update(make_display())

            threads = [
                threading.Thread(target=run_one, args=(r,), daemon=True) for r in runners
            ]
            for t in threads:
                t.start()
            for t in threads:
                t.join(timeout=180)
        
        finally:
            live.stop()

        approved = [r for r in runners if r.status == "approved"]
        console.print(f"\n[bold]Results:[/bold] {len(approved)}/{total} agents approved\n")

        if not approved:
            console.print("[red]No agents approved. Session failed.[/red]\n")
            return None

        console.print("[dim]Project Manager synthesizing...[/dim]")
        return self.pm.synthesize(runners, user_prompt)

    # ── Undo ──────────────────────────────────────────────────────────────────

    def get_undo_group(self) -> list:
        return self.undo_group

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _scan_codebase(self, user_prompt: str) -> str:
        code_keywords = ["code", "file", "function", "class", "implement",
                         "fix", "bug", "feature", "refactor", "test"]
        if not any(kw in user_prompt.lower() for kw in code_keywords):
            return ""
        console.print("[dim]Scanning codebase...[/dim]", end="\r")
        file_list = self.parent.tools.list_files(".", max_results=50)
        console.print(" " * 50, end="\r")
        return f"\nProject structure:\n{file_list}\n"

    def _print_agents_table(self, agents: list[dict]):
        console.print()
        table = Table(show_header=True, header_style="bold magenta")
        table.add_column("ID", style="dim", width=4)
        table.add_column("Name", style="cyan")
        table.add_column("Role", style="green")
        table.add_column("Focus", style="yellow")
        for a in agents:
            table.add_row(str(a["id"]), a["name"], a["role"], a["focus"])
        console.print(table)
        console.print()


# ─── Util ─────────────────────────────────────────────────────────────────────

def _strip_json(text: str) -> str:
    """Strip markdown fences and find JSON object in text."""
    text = text.strip()
    if "```json" in text:
        text = text.split("```json")[1].split("```")[0].strip()
    elif "```" in text:
        text = text.split("```")[1].split("```")[0].strip()
    if not text.startswith("{"):
        start, end = text.find("{"), text.rfind("}")
        if start != -1 and end != -1:
            text = text[start:end+1]
    return text