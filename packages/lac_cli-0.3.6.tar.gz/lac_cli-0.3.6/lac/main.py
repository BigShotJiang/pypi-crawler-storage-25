"""
lac/main.py
───────────
Entry point for the `lac` CLI command.

Flow:
  1. First run → launch setup wizard
  2. Auto-start lac-server in background if not already running
  3. Connect to lac-server via WebSocket
  4. Launch the interactive shell
"""

import asyncio
import subprocess
import sys
import time
import argparse
import httpx
from rich.console import Console
from rich import print as rprint
from rich.panel import Panel

from lac import config, wizard

console = Console()

_server_process = None

CURRENT_VERSION = "0.3.5"


def check_for_updates():
    """Check for updates from lacai.io server."""
    try:
        response = httpx.get("https://lacai.io/version.json", timeout=2.0)
        if response.status_code == 200:
            data = response.json()
            latest = data.get("latest", "")
            changelog = data.get("changelog", "")
            
            if latest and latest > CURRENT_VERSION:
                console.print()
                console.print(Panel(
                    f"[bold yellow]Update Available: v{latest}[/bold yellow]\n"
                    f"[dim]You have: v{CURRENT_VERSION}[/dim]\n\n"
                    f"{changelog}\n\n"
                    f"[cyan]Run:[/cyan] pip install --upgrade lac-cli",
                    border_style="yellow",
                    padding=(1, 2)
                ))
                console.print()
    except Exception:
        pass  # Silently fail if can't check


def _port_open(host: str, port: int) -> bool:
    import socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.5)
        return s.connect_ex((host, port)) == 0


def _ensure_server():
    """Start lac-server in background if not already running.
    Returns: 'already_running' | 'started' | 'failed'
    """
    global _server_process
    host, port = "127.0.0.1", 8765

    if _port_open(host, port):
        return "already_running"

    try:
        _server_process = subprocess.Popen(
            [sys.executable, "-m", "uvicorn", "server.main:app",
             "--host", "0.0.0.0", "--port", str(port), "--log-level", "error"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except Exception:
        return "failed"

    # wait up to 5s for the port to open
    for _ in range(10):
        time.sleep(0.5)
        if _server_process.poll() is not None:
            return "failed"  # process exited early
        if _port_open(host, port):
            return "started"

    # timed out — kill it and fall back to offline
    _server_process.terminate()
    return "failed"


def _stop_server():
    if _server_process and _server_process.poll() is None:
        _server_process.terminate()


async def _start(offline: bool = False, debounce: int = 150):
    """Main async entry — connect to server then run shell."""
    from lac.ws_client import LacClient
    from lac.shell import run_shell

    client = None

    if not offline:
        status = _ensure_server()
        if status == "started":
            console.print("[dim]started lac-server in background[/dim]")
        elif status == "failed":
            console.print("[yellow]⚠ could not start lac-server — running in offline mode[/yellow]")

        if status != "failed":
            server_url = config.get("server", "ws://localhost:8765")
            console.print(f"[dim]connecting to {server_url}...[/dim]", end="\r")
            client = LacClient()
            try:
                await client.connect()
                console.print("[green]✓ connected to lac-server[/green]          ")
            except ConnectionError as e:
                console.print(
                    f"[yellow]⚠ could not connect to server — running in offline mode[/yellow]\n"
                    f"[dim]  {e}[/dim]\n"
                )
                client = None

    try:
        await run_shell(client, debounce_ms=debounce)
    finally:
        if client:
            await client.disconnect()
        _stop_server()


def main():
    """
    CLI entry point registered in pyproject.toml as `lac`.
    """
    parser = argparse.ArgumentParser(
        prog="lac",
        description="lac-cli — AI-powered terminal shell with multiple tools",
    )
    parser.add_argument(
        "--version",
        action="version",
        version="lac-cli 0.3.5",
    )
    subparsers = parser.add_subparsers(dest="command")
    
    # Shell subcommand
    shell_parser = subparsers.add_parser("shell", help="launch AI-powered terminal shell")
    shell_parser.add_argument("--setup", action="store_true", help="re-run the setup wizard")
    shell_parser.add_argument("--offline", action="store_true", help="run without connecting to lac-server")
    shell_parser.add_argument("--debounce", type=int, default=150, metavar="MS", help="autocomplete debounce delay in milliseconds (default: 150)")
    
    # Mind subcommand
    subparsers.add_parser("mind", help="launch LacMind multi-model debate UI")
    
    # Agent subcommand
    subparsers.add_parser("agent", help="launch AI coding assistant with project memory")
    
    # GenDoc subcommand
    gendoc_parser = subparsers.add_parser("gendoc", help="generate API documentation from codebase")
    gendoc_parser.add_argument("path", type=str, help="Path to your project directory")
    gendoc_parser.add_argument("--prompt", type=str, help="Custom instructions for documentation generation")
    gendoc_parser.add_argument("--integrate", action="store_true", help="Add documentation route to your MVC framework")
    gendoc_parser.add_argument("--output", type=str, default="api-docs.html", help="Output file path (default: api-docs.html)")
    
    # Formula subcommand
    formula_parser = subparsers.add_parser("formula", help="manage coding formulas (custom AI rules)")
    formula_parser.add_argument("formula_action", nargs="?", choices=["list", "add", "use", "off", "show", "edit", "delete"], help="Formula action")
    formula_parser.add_argument("formula_name", nargs="?", help="Formula name (for use/show/edit/delete)")
    
    # Manage subcommand
    manage_parser = subparsers.add_parser("manage", help="token management for agent")
    manage_parser.add_argument("manage_action", nargs="?", choices=["on", "off", "status", "strategy", "reset", "config"], help="Manage action")
    manage_parser.add_argument("manage_value", nargs="?", help="Value for strategy command")
    
    # MCP subcommand
    mcp_parser = subparsers.add_parser("mcp", help="manage MCP (Model Context Protocol) servers")
    mcp_parser.add_argument("mcp_action", nargs="?", choices=["add", "list", "remove"], help="MCP action")
    
    args = parser.parse_args()

    # If no command specified, show menu
    if not args.command:
        show_menu()
        return

    # ── Shell ─────────────────────────────────────────────────────────────────
    if args.command == "shell":
        # Check if shell dependencies are installed
        try:
            import websockets
        except ImportError:
            import platform
            is_windows = platform.system() == "Windows"
            console.print("[red]✗ Shell dependencies not installed[/red]")
            if is_windows:
                console.print("[dim]Install with:[/dim] pip install lac-cli[shell]\n")
            else:
                console.print("[dim]Install with:[/dim] pip3 install 'lac-cli[shell]'\n")
            sys.exit(1)
        
        # First run or forced setup
        if args.setup or not config.config_exists():
            wizard.run()
        
        # Launch shell
        try:
            asyncio.run(_start(offline=args.offline, debounce=args.debounce))
        except KeyboardInterrupt:
            console.print("\n[bold cyan]bye 👋[/bold cyan]")
            sys.exit(0)
        return

    # ── LacMind ───────────────────────────────────────────────────────────────
    if args.command == "mind":
        try:
            from lac.mind.main import launch
            launch()
        except ImportError:
            import platform
            is_windows = platform.system() == "Windows"
            console.print("[red]✗ LacMind dependencies not installed[/red]")
            if is_windows:
                console.print("[dim]Install with:[/dim] pip install lac-cli[mind]\n")
            else:
                console.print("[dim]Install with:[/dim] pip3 install 'lac-cli[mind]'\n")
            sys.exit(1)
        return
    
    # ── LacAgent ──────────────────────────────────────────────────────────────
    if args.command == "agent":
        try:
            from lac.agent.main import launch
            launch()
        except ImportError:
            import platform
            is_windows = platform.system() == "Windows"
            console.print("[red]✗ LacAgent dependencies not installed[/red]")
            if is_windows:
                console.print("[dim]Install with:[/dim] pip install lac-cli[agent]\n")
            else:
                console.print("[dim]Install with:[/dim] pip3 install 'lac-cli[agent]'\n")
            sys.exit(1)
        return
    
    # ── lac gendoc ────────────────────────────────────────────────────────────
    if args.command == "gendoc":
        from lac.gendoc.main import launch
        launch(args)
        return
    
    # ── lac formula ───────────────────────────────────────────────────────────
    if args.command == "formula":
        from lac.agent.formula_cli import main as formula_main
        formula_main(args)
        return
    
    # ── lac manage ────────────────────────────────────────────────────────────
    if args.command == "manage":
        from lac.agent.manage_cli import main as manage_main
        manage_main(args)
        return
    
    # ── lac mcp ───────────────────────────────────────────────────────────────
    if args.command == "mcp":
        from lac.agent.mcp_cli import main as mcp_main
        mcp_main(args)
        return


def show_menu():
    """Display interactive menu for tool selection."""
    check_for_updates()
    
    console.print("\n[bold cyan]  ██╗      █████╗  ██████╗[/bold cyan]")
    console.print("[bold cyan]  ██║     ██╔══██╗██╔════╝[/bold cyan]")
    console.print("[bold cyan]  ██║     ███████║██║[/bold cyan]")
    console.print("[bold cyan]  ██║     ██╔══██║██║[/bold cyan]")
    console.print("[bold cyan]  ███████╗██║  ██║╚██████╗[/bold cyan]")
    console.print("[bold cyan]  ╚══════╝╚═╝  ╚═╝ ╚═════╝[/bold cyan]  [white]CLI[/white] [dim]v0.3.5[/dim]\n")
    
    console.print("[bold]Available Tools:[/bold]\n")
    console.print("  [cyan]1.[/cyan] [bold]Shell[/bold]    - AI-powered terminal with autocomplete")
    console.print("  [cyan]2.[/cyan] [bold]Mind[/bold]     - Multi-model debate engine")
    console.print("  [cyan]3.[/cyan] [bold]GenDoc[/bold]   - API documentation generator")
    console.print("  [cyan]4.[/cyan] [bold]Agent[/bold]    - AI coding assistant with project memory")
    console.print("  [cyan]5.[/cyan] [bold]Formula[/bold]  - Manage coding formulas")
    console.print("  [cyan]6.[/cyan] [bold]Settings[/bold] - Configure AI provider and model\n")
    
    try:
        choice = input("Select a tool [1-6] or press Enter for Shell: ").strip()
    except (KeyboardInterrupt, EOFError):
        console.print("\n[bold cyan]bye 👋[/bold cyan]")
        sys.exit(0)
    
    # Handle exit command
    if choice.lower() in ["exit", "quit", "bye"]:
        console.print("\n[bold cyan]bye 👋[/bold cyan]")
        sys.exit(0)
    
    if choice == "2":
        try:
            from lac.mind.main import launch
            launch()
        except ImportError:
            import platform
            is_windows = platform.system() == "Windows"
            console.print("\n[red]✗ LacMind dependencies not installed[/red]")
            if is_windows:
                console.print("[dim]Install with:[/dim] pip install lac-cli[mind]\n")
            else:
                console.print("[dim]Install with:[/dim] pip3 install 'lac-cli[mind]'\n")
            return
    elif choice == "3":
        console.print()
        try:
            path = input("Enter project path: ").strip()
        except (KeyboardInterrupt, EOFError):
            console.print("\n[bold cyan]bye 👋[/bold cyan]")
            sys.exit(0)
        
        if not path:
            console.print("[red]Error: Path is required[/red]")
            console.print("[dim]Usage:[/dim] lac gendoc <path>\n")
            return
        
        # Create args object for gendoc
        class Args:
            def __init__(self, path):
                self.path = path
                self.prompt = None
                self.integrate = False
                self.output = "api-docs.html"
        
        from lac.gendoc.main import launch
        launch(Args(path))
    elif choice == "4":
        try:
            from lac.agent.main import launch
            launch()
        except ImportError:
            import platform
            is_windows = platform.system() == "Windows"
            console.print("\n[red]✗ LacAgent dependencies not installed[/red]")
            if is_windows:
                console.print("[dim]Install with:[/dim] pip install lac-cli[agent]\n")
            else:
                console.print("[dim]Install with:[/dim] pip3 install 'lac-cli[agent]'\n")
            return
    elif choice == "5":
        # Formula management
        from lac.agent.formula_cli import main as formula_main
        
        console.print("\n[bold cyan]Formula Management[/bold cyan]\n")
        console.print("[bold]Commands:[/bold]")
        console.print("  [cyan]1.[/cyan] List all formulas")
        console.print("  [cyan]2.[/cyan] Create new formula")
        console.print("  [cyan]3.[/cyan] Activate a formula")
        console.print("  [cyan]4.[/cyan] Deactivate current formula")
        console.print("  [cyan]5.[/cyan] Show formula details")
        console.print("  [cyan]6.[/cyan] Edit a formula")
        console.print("  [cyan]7.[/cyan] Delete a formula\n")
        
        try:
            action = input("Select action [1-7] or Enter to go back: ").strip()
        except (KeyboardInterrupt, EOFError):
            console.print("\n[dim]Returning to menu...[/dim]\n")
            import time
            time.sleep(1)
            show_menu()
            return
        
        if not action:
            show_menu()
            return
        
        class Args:
            formula_action = None
            formula_name = None
        
        args = Args()
        
        if action == "1":
            args.formula_action = "list"
        elif action == "2":
            args.formula_action = "add"
        elif action == "3":
            # Show list of formulas to activate
            from lac.agent import formula_manager
            formulas = formula_manager.list_formulas()
            if not formulas:
                console.print("\n[yellow]No formulas available. Create one first.[/yellow]")
            else:
                console.print("\n[bold]Available formulas:[/bold]")
                for i, f in enumerate(formulas, 1):
                    status = " [cyan](active)[/cyan]" if f["is_active"] else ""
                    console.print(f"  [cyan]{i}.[/cyan] {f['name']}{status}")
                try:
                    choice = input("\nSelect formula [1-{}]: ".format(len(formulas))).strip()
                    if choice.isdigit() and 1 <= int(choice) <= len(formulas):
                        args.formula_action = "use"
                        args.formula_name = formulas[int(choice) - 1]["name"]
                except (KeyboardInterrupt, EOFError, ValueError):
                    pass
        elif action == "4":
            args.formula_action = "off"
        elif action == "5":
            # Show list of formulas to view
            from lac.agent import formula_manager
            formulas = formula_manager.list_formulas()
            if not formulas:
                console.print("\n[yellow]No formulas available.[/yellow]")
            else:
                console.print("\n[bold]Available formulas:[/bold]")
                for i, f in enumerate(formulas, 1):
                    console.print(f"  [cyan]{i}.[/cyan] {f['name']}")
                try:
                    choice = input("\nSelect formula [1-{}]: ".format(len(formulas))).strip()
                    if choice.isdigit() and 1 <= int(choice) <= len(formulas):
                        args.formula_action = "show"
                        args.formula_name = formulas[int(choice) - 1]["name"]
                except (KeyboardInterrupt, EOFError, ValueError):
                    pass
        elif action == "6":
            # Show list of formulas to edit
            from lac.agent import formula_manager
            formulas = formula_manager.list_formulas()
            if not formulas:
                console.print("\n[yellow]No formulas available.[/yellow]")
            else:
                console.print("\n[bold]Available formulas:[/bold]")
                for i, f in enumerate(formulas, 1):
                    console.print(f"  [cyan]{i}.[/cyan] {f['name']}")
                try:
                    choice = input("\nSelect formula [1-{}]: ".format(len(formulas))).strip()
                    if choice.isdigit() and 1 <= int(choice) <= len(formulas):
                        args.formula_action = "edit"
                        args.formula_name = formulas[int(choice) - 1]["name"]
                except (KeyboardInterrupt, EOFError, ValueError):
                    pass
        elif action == "7":
            # Show list of formulas to delete
            from lac.agent import formula_manager
            formulas = formula_manager.list_formulas()
            if not formulas:
                console.print("\n[yellow]No formulas available.[/yellow]")
            else:
                console.print("\n[bold]Available formulas:[/bold]")
                for i, f in enumerate(formulas, 1):
                    console.print(f"  [cyan]{i}.[/cyan] {f['name']}")
                try:
                    choice = input("\nSelect formula [1-{}]: ".format(len(formulas))).strip()
                    if choice.isdigit() and 1 <= int(choice) <= len(formulas):
                        args.formula_action = "delete"
                        args.formula_name = formulas[int(choice) - 1]["name"]
                except (KeyboardInterrupt, EOFError, ValueError):
                    pass
        
        if args.formula_action:
            formula_main(args)
        
        # Return to menu after formula action
        console.print("\n[dim]Press Enter to return to menu...[/dim]")
        try:
            input()
        except (KeyboardInterrupt, EOFError):
            pass
        show_menu()
    elif choice == "6":
        # Settings - re-run wizard
        wizard.run()
        console.print("\n[green]✓ Settings updated[/green]")
        console.print("[dim]Returning to menu...[/dim]\n")
        import time
        time.sleep(1)
        show_menu()  # Return to menu
    else:
        # Default to shell (choice == "1" or Enter)
        # Check if shell dependencies are installed
        try:
            import websockets
        except ImportError:
            import platform
            is_windows = platform.system() == "Windows"
            console.print("\n[red]✗ Shell dependencies not installed[/red]")
            if is_windows:
                console.print("[dim]Install with:[/dim] pip install lac-cli[shell]\n")
            else:
                console.print("[dim]Install with:[/dim] pip3 install 'lac-cli[shell]'\n")
            return
        
        if not config.config_exists():
            wizard.run()
        try:
            asyncio.run(_start(offline=False, debounce=150))
        except KeyboardInterrupt:
            console.print("\n[bold cyan]bye 👋[/bold cyan]")
            sys.exit(0)


if __name__ == "__main__":
    main()
