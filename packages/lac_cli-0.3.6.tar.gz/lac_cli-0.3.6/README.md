<img src="https://raw.githubusercontent.com/iammcoding/lac-cli/main/lacicon.png" width="120" />

# lac-cli

lac-cli is a terminal toolkit from [lacai.io](https://lacai.io) that brings AI into your command line. You get an AI shell, a coding assistant with memory, a debate engine, and an API doc generator.

**What's new in v0.3.6:** Added Multi Agent Mode (`/multi`) where the agent splits complex tasks across specialized agents that work in parallel, each with live progress tracking and grouped undo.

## Install

**Quick install (Unix/Linux/macOS):**
```bash
curl -fsSL https://lacai.io/install.sh | bash
```

**Quick install (Windows PowerShell):**
```powershell
iwr -useb https://lacai.io/install.ps1 | iex
```

**Manual install (all platforms):**
```bash
# Unix/Linux/macOS
pip3 install 'lac-cli[all]'
pip3 install anthropic

# Windows
pip install lac-cli[all]
pip install anthropic
```

**Optional components:**
```bash
pip install lac-cli[agent]  # Just the coding assistant
pip install lac-cli[shell]  # Shell with autocomplete server
pip install lac-cli[mind]   # Multi-model debate engine
pip install lac-cli[all]    # Everything
```

**AI Provider Libraries** (install based on your choice):
```bash
pip install anthropic  # For Claude
pip install openai     # For OpenAI/GPT
# Ollama requires no additional install
```

## Getting Started

Run `lac` to see the menu of available tools:

```bash
lac
```

You'll see:
```
lac-cli v0.3.3

Available Tools:

  1. Shell    - AI-powered terminal with autocomplete
  2. Mind     - Multi-model debate engine
  3. GenDoc   - API documentation generator
  4. Agent    - AI coding assistant with project memory
  5. Settings - Configure AI provider and model

Select a tool [1-5] or press Enter for Shell:
```

Or use direct commands:

```bash
lac shell          # Launch AI terminal shell
lac mind           # Launch multi-model debate
lac gendoc <path>  # Generate API docs
lac agent          # Launch AI coding assistant
```

### LacAgent AI Coding Assistant

Launch the AI coding assistant with project memory:

```bash
lac agent
```

LacAgent can:
- Read, write, and edit files
- Run shell commands with safety checks
- Test APIs with HTTP requests
- Watch files for changes
- Generate API docs
- Remember your project context
- Undo/redo changes with diffs
- Connect to MCP servers (GitHub, databases, web search)
- Monitor browser sessions with voice recognition (`/watch`)

**Commands you can use:**
```bash
/undo              # Revert last file edit with diff preview
/redo              # Reapply undone edit
/history           # Show all file edits this session
/diff <file>       # Inspect file contents with line numbers
/gendoc [path]     # Generate API documentation
/plan              # Enable PlanMode (approve plans before execution)
/noplan            # Disable PlanMode (execute immediately)
/tasks             # Show current task list
/cleartasks        # Clear all tasks
/formula list|use|off  # Manage coding formulas
/manage on|off|status  # Token management
/mcp               # List connected MCP servers
/watch [url]       # Launch browser monitoring with voice recognition
/multi             # Enable multi agent mode for parallel execution
```

**Example Usage:**
```
[You] create a FastAPI app with user authentication
[Agent] → Creates files, installs dependencies, sets up routes

[You] run the server
[Agent] → Starts uvicorn in background, provides log file location

[You] /multi analyze my codebase for issues
[Agent] → Suggests 4 specialized agents
        → You approve or edit the agent list
        → Agents run in parallel with live logs
        → Project Manager reviews and synthesizes results

[You] /watch http://localhost:8000
[Agent] → Opens Chrome, monitors your testing session
        → You speak, click, type, test endpoints
        → Click "Send to AI" when done
        → Analyzes the full timeline and suggests fixes

[You] /undo
[Agent] → Reverts last file change with diff preview
```

### Terminal Shell

Launch the AI-powered shell:

```bash
lac shell
```

The first time you run it, a setup wizard will walk you through picking your AI provider and entering your API key.

To redo the setup:

```bash
lac shell --setup
```

To run without an internet connection:

```bash
lac shell --offline
```

To adjust autocomplete speed (default 150ms):

```bash
lac shell --debounce 50   # faster
lac shell --debounce 300  # slower
```

### LacMind Multi-Model Debate

Launch the web-based debate interface for complex queries:

```bash
lac mind
```

LacMind runs multiple AI models in a debate format where they challenge and refine each other's ideas, then vote on the best response. Perfect for research, code generation, and complex problem-solving.

### GenDoc API Documentation

Generate beautiful API documentation from your codebase:

```bash
lac gendoc /path/to/project
```

GenDoc scans your project, detects the framework, and uses AI to analyze your routes and controllers to generate comprehensive API documentation. Supports Laravel, Django, FastAPI, Flask, Express, and Rails.

Optional flags:

```bash
lac gendoc /path/to/project --prompt "Focus on authentication endpoints"
lac gendoc /path/to/project --integrate  # Add /docs route to your framework
lac gendoc /path/to/project --output custom.html
```

### MCP (Model Context Protocol) Integration

Connect your agent to external MCP servers for extended capabilities:

```bash
lac mcp add    # Add a new MCP server
lac mcp list   # List configured servers
lac agent      # Start agent with MCP tools
```

**Popular MCP Servers:**
- **GitHub** - Create issues, PRs, search code
- **PostgreSQL** - Query databases, inspect schemas
- **Filesystem** - Safe file access to specific directories
- **Brave Search** - Web search capabilities
- **Google Drive** - Access Drive files
- **Slack** - Send messages, manage channels

**Example Usage:**
```
[You] create a GitHub issue about the bug we found

[Agent]
  ⏺ github__create_issue(...)
  ✓ Issue #42 created

Created issue #42 in your repository!
```

MCP servers are automatically connected when the agent starts. See `MCP_QUICKSTART.md` for setup guide.

### Formula System

Create custom coding rules that get injected into the AI's instructions.

```bash
lac formula add    # Create a new formula
lac formula list   # See all formulas
lac formula use    # Activate one
lac formula off    # Turn it off
```

You can also use `/formula` inside the agent.

### Token Management

Control how much context the AI uses. Helps manage costs and keeps conversations focused.

```bash
lac manage on       # Turn on token tracking
lac manage status   # See current usage
lac manage off      # Turn it off
```

Three modes:
- **trim** keeps only recent messages
- **warn** just shows warnings
- **compact** has AI summarize old messages

Use `/manage` inside the agent to check status.

## How It Works

### Main Menu

When you run `lac` without arguments, you get an interactive menu to choose between:
- **Shell** - AI-powered terminal with real-time autocomplete
- **Mind** - Multi-model debate for complex queries
- **GenDoc** - API documentation generator
- **Agent** - AI coding assistant with project memory
- **Settings** - Configure AI provider and model

You can also use direct commands like `lac shell`, `lac mind`, `lac gendoc <path>`, or `lac agent`.

### LacAgent Coding Assistant

LacAgent runs in your project folder and can access files and run commands.

**What it does:**
- File stuff: read, write, patch files (no full rewrites)
- Glob patterns: find files like `**/*.py` or `src/**`
- Commands: runs shell commands, detects long ones and backgrounds them
- API testing: makes HTTP requests
- File watching: monitors files for changes
- Docs: generates API documentation
- Memory: remembers your project across sessions
- Undo/redo: full edit history with diffs
- PlanMode: shows you what it'll do before doing it (on by default)
- Tasks: tracks multi step work
- Questions: can ask you stuff when it needs to
- MCP: connects to external servers for more tools
- Multi Agent: splits complex work across specialized agents running in parallel

**Smart stuff:**
- Runs things like `npm start` in background automatically
- Saves logs to `~/.lac/logs/`
- Paste multiple lines no problem
- Type `/` to see all commands
- Security checks on dangerous commands

**How editing works:**
1. Reads the file first
2. Makes surgical edits with patch_file
3. Snapshots before every change
4. You can /undo anytime

### Terminal Shell

When you run `lac shell`, it starts a server in the background. You don't need to do anything.

As you type, it shows ghost text suggestions. Press Tab to use them. Type plain English like "show all files bigger than 100mb" and it converts it to the actual command, then asks if you want to run it.

The shell remembers your recent commands and their output, so suggestions get smarter as you use it.

### LacMind Debate Engine

LacMind makes multiple AI models debate each other:

1. Models discuss and challenge ideas
2. They vote on who had the best reasoning
3. Winner gives the final answer

Models are anonymous (Model A, B, C) so they can't be biased. You pick how long debates run and which models join.

### GenDoc Documentation Generator

GenDoc makes API docs automatically:

1. Scans your project and finds your framework
2. Sends route/controller files to lacai.io for analysis
3. Creates interactive HTML docs
4. Can add a `/docs` route to your app

First time you run it, you'll need an API key from [lacai.io/dashboard/keys](https://lacai.io/dashboard/keys). The docs include endpoints, parameters, examples, and you can export to Swagger or Postman.

## Supported Providers

| Provider | Notes |
|----------|-------|
| `claude` | Anthropic API |
| `openai` | OpenAI API |
| `ollama` | Local models, no API key needed |
| `custom` | Any OpenAI compatible endpoint |

## Commands

### Main Menu

| Command | What it does |
|---------|--------------|
| `lac` | Show interactive menu |
| `lac shell` | Launch AI terminal shell |
| `lac mind` | Launch LacMind debate UI |
| `lac gendoc <path>` | Generate API documentation |
| `lac agent` | Launch AI coding assistant |
| `lac mcp add` | Add MCP server interactively |
| `lac mcp list` | List configured MCP servers |
| `lac mcp remove` | Remove an MCP server |

### LacAgent

| Command | What it does |
|---------|--------------|
| `lac agent` | Launch AI coding assistant |
| `/undo` | Revert last file edit with diff |
| `/redo` | Reapply undone edit |
| `/history` | Show all file edits this session |
| `/diff <file>` | Inspect file with line numbers |
| `/gendoc [path]` | Generate API documentation |
| `/plan` | Enable PlanMode |
| `/noplan` | Disable PlanMode |
| `/tasks` | Show current task list |
| `/cleartasks` | Clear all tasks |
| `/formula list\|use\|off` | Manage coding formulas |
| `/manage on\|off\|status` | Token management |
| `/mcp` | List connected MCP servers |
| `/watch [url]` | Launch browser monitoring with voice |
| `/multi` | Enable multi agent mode |
| `Ctrl+C` | Interrupt agent execution |
| `exit` | Quit the agent |

### Terminal Shell

| Command | What it does |
|---------|--------------|
| `lac shell` | Launch the AI shell |
| `lac shell --setup` | Re-run setup wizard |
| `lac shell --offline` | Run without server |
| `lac shell --debounce MS` | Set autocomplete delay |
| `exit` | Quit the shell |
| `logout` | Delete your config and start fresh |
| `clear` | Clear the screen and session history |
| `cd <path>` | Change directory |

### LacMind

| Command | What it does |
|---------|--------------|
| `lac mind` | Launch LacMind web interface |
| Settings page | Add/edit/delete AI models |
| Duration selector | Set debate time (30s - 5min) |
| Stop button | End debate early |
| Export | Save conversations to PDF |

### GenDoc

| Command | What it does |
|---------|--------------|
| `lac gendoc <path>` | Generate API docs from project |
| `--prompt "text"` | Custom instructions for AI analysis |
| `--integrate` | Add /docs route to framework |
| `--output file.html` | Custom output filename |
| Export buttons | Download as Swagger or Postman |

## Config

Your config is saved at `~/.lac/config.json` after setup. You can edit it directly if needed.

```json
{
  "provider": "claude",
  "api_key": "sk-...",
  "model": "claude-haiku-4-5-20251001",
  "base_url": "https://api.anthropic.com",
  "server": "ws://localhost:8765"
}
```

## Features

### LacAgent Coding Assistant

File stuff:
- Read, write, patch files (exact string matching)
- Glob patterns like `**/*.py`, `*.js`, `src/**`
- Undo/redo with full history and diffs

Commands:
- Run shell commands with safety checks
- Auto backgrounds long commands (flutter run, npm start)
- Logs saved to `~/.lac/logs/`

Browser Monitoring:
- `/watch` opens Chrome with voice recognition
- Captures clicks, inputs, navigation, network requests
- Sends full timeline for debugging
- Lazy installs playwright when first used

Multi Agent Mode:
- `/multi` splits complex tasks across specialized agents
- Agents work in parallel with isolated contexts
- Live progress panels show each agent's activity
- Project Manager reviews work and synthesizes results
- Grouped undo reverts all changes from the session
- Edit or customize agent list before execution

Other:
- HTTP requests for API testing
- File watching for changes
- API doc generation
- Project memory (remembers context)
- PlanMode (approve before execution)
- Task tracking with status icons
- Ask questions when needed
- Multi line paste support
- Slash command autocomplete
- Ctrl+C to stop anytime
- Security validation
- MCP server integration

### Terminal Shell

- Ghost text autocomplete as you type
- Plain English to command conversion
- Session history tracking for better suggestions
- Adjustable autocomplete speed
- Works with Claude, OpenAI, Ollama, or custom endpoints
- Offline mode with history fallback
- Auto starts server in background
- Logout clears everything

### LacMind

- Multiple models debate sequentially
- Anonymous voting for best reasoning
- Real-time streaming
- Chat history saved
- Add/edit/delete models
- Set debate duration
- Stop early if consensus reached
- Export to PDF
- Dark theme UI

### GenDoc

- Auto detects framework (Laravel, Django, FastAPI, Flask, Express, Rails)
- AI analyzes endpoints
- Interactive HTML docs with search
- Resizable sidebar with filtering
- Try It feature to test endpoints
- Export to Swagger or Postman
- Optional `/docs` route integration
- Custom prompts for analysis
- Separate API key system
- Credit based usage

## About

lac-cli is from [lacai.io](https://lacai.io). Made for developers who work in the terminal.

## License

MIT
