"""Generic tests for polar grid operators, applied to multiple backends.

.. codeauthor:: David Zwicker <david.zwicker@ds.mpg.de>
"""

import numpy as np
import pytest

from pde import CartesianGrid, PolarSymGrid, ScalarField, Tensor2Field, VectorField

ALL_BACKENDS = ["numba", "jax", "torch-cpu", "torch-mps", "torch-cuda"]


@pytest.mark.parametrize("backend", ALL_BACKENDS, indirect=True)
def test_findiff_polar(backend):
    """Test operator for a simple polar grid."""
    grid = PolarSymGrid(1.5, 3)
    _, _, r2 = grid.axes_coords[0]
    assert grid.discretization == (0.5,)
    s = ScalarField(grid, [1, 2, 4])
    v = VectorField(grid, [[1, 2, 4], [0] * 3])

    # test gradient
    grad = s.gradient(bc={"r-": "derivative", "r+": "value"}, backend=backend)
    np.testing.assert_allclose(grad.data[0, :], [1, 3, -6])
    grad = s.gradient(bc="derivative", backend=backend)
    np.testing.assert_allclose(grad.data[0, :], [1, 3, 2])
    grad = s.gradient(bc="derivative", method="forward", backend=backend)
    np.testing.assert_allclose(grad.data[0, :], [2, 4, 0])
    grad = s.gradient(bc="derivative", method="backward", backend=backend)
    np.testing.assert_allclose(grad.data[0, :], [0, 2, 4])

    # test divergence
    div = v.divergence(bc={"r-": "derivative", "r+": "value"}, backend=backend)
    np.testing.assert_allclose(div.data, [5, 17 / 3, -6 + 4 / r2])
    div = v.divergence(bc="derivative", backend=backend)
    np.testing.assert_allclose(div.data, [5, 17 / 3, 2 + 4 / r2])


@pytest.mark.parametrize("backend", ALL_BACKENDS, indirect=True)
def test_conservative_laplace_polar(backend, rng):
    """Test and compare the two implementation of the laplace operator."""
    grid = PolarSymGrid(1.5, 8)
    f = ScalarField.random_uniform(grid, rng=rng)

    res = f.laplace("auto_periodic_neumann", backend=backend)
    np.testing.assert_allclose(res.integral, 0, atol=1e-5)


@pytest.mark.parametrize("backend", ALL_BACKENDS, indirect=True)
@pytest.mark.parametrize(
    ("op_name", "field"),
    [
        ("laplace", ScalarField),
        ("divergence", VectorField),
        ("gradient", ScalarField),
    ],
)
def test_small_annulus_polar(backend, op_name, field, rng):
    """Test whether a small annulus gives the same result as a sphere."""
    grids = [
        PolarSymGrid((0, 1), 8),
        PolarSymGrid((1e-8, 1), 8),
        PolarSymGrid((0.1, 1), 8),
    ]

    f = field.random_uniform(grids[0], rng=rng)

    res = [
        field(g, data=f.data).apply_operator(
            op_name, "auto_periodic_neumann", backend=backend
        )
        for g in grids
    ]

    np.testing.assert_almost_equal(res[0].data, res[1].data, decimal=5)
    assert np.linalg.norm(res[0].data - res[2].data) > 1e-3


@pytest.mark.parametrize("backend", ALL_BACKENDS, indirect=True)
def test_small_annulus_polar_tensor(backend, rng):
    """Test whether a small annulus gives the same result for tensor divergence."""
    grids = [
        PolarSymGrid((0, 1), 8),
        PolarSymGrid((1e-8, 1), 8),
        PolarSymGrid((0.1, 1), 8),
    ]

    f = Tensor2Field.random_uniform(grids[0], rng=rng)

    res = [
        Tensor2Field(g, data=f.data).apply_operator(
            "tensor_divergence", "auto_periodic_neumann", backend=backend
        )
        for g in grids
    ]

    np.testing.assert_almost_equal(res[0].data, res[1].data, decimal=5)
    assert np.linalg.norm(res[0].data - res[2].data) > 1e-3


@pytest.mark.parametrize("backend", ALL_BACKENDS, indirect=True)
def test_grid_laplace_polar(backend):
    """Test the polar implementation of the laplace operator."""
    grid_sph = PolarSymGrid(7, 8)
    grid_cart = CartesianGrid([[-5, 5], [-5, 5]], [12, 11])

    a_1d = ScalarField.from_expression(grid_sph, "cos(r)")
    a_2d = a_1d.interpolate_to_grid(grid_cart)

    b_2d = a_2d.laplace("auto_periodic_neumann", backend=backend)
    b_1d = a_1d.laplace("auto_periodic_neumann", backend=backend)
    b_1d_2 = b_1d.interpolate_to_grid(grid_cart)

    i = slice(1, -1)  # do not compare boundary points
    np.testing.assert_allclose(b_1d_2.data[i, i], b_2d.data[i, i], rtol=0.2, atol=0.2)


@pytest.mark.parametrize("backend", ALL_BACKENDS, indirect=True)
@pytest.mark.parametrize("r_inner", [0, 2 * np.pi])
def test_gradient_squared_polar(backend, r_inner):
    """Compare gradient squared operator."""
    grid = PolarSymGrid((r_inner, 4 * np.pi), 32)
    field = ScalarField.from_expression(grid, "cos(r)")
    s1 = field.gradient("auto_periodic_neumann", backend=backend).to_scalar(
        "squared_sum"
    )
    s2 = field.gradient_squared("auto_periodic_neumann", central=True, backend=backend)
    np.testing.assert_allclose(s1.data, s2.data, rtol=0.1, atol=0.1)
    s3 = field.gradient_squared("auto_periodic_neumann", central=False, backend=backend)
    np.testing.assert_allclose(s1.data, s3.data, rtol=0.1, atol=0.1)
    assert not np.array_equal(s2.data, s3.data)


@pytest.mark.parametrize("backend", ALL_BACKENDS, indirect=True)
def test_grid_div_grad_polar(backend):
    """Compare div grad to laplacian for polar grids."""
    grid = PolarSymGrid(2 * np.pi, 16)
    field = ScalarField.from_expression(grid, "cos(r)")

    a = field.laplace("derivative", backend=backend)
    b = field.gradient("derivative", backend=backend).divergence(
        "value", backend=backend
    )
    res = ScalarField.from_expression(grid, "-sin(r) / r - cos(r)")

    # do not test the radial boundary points
    np.testing.assert_allclose(a.data[1:-1], res.data[1:-1], rtol=0.1, atol=0.1)
    np.testing.assert_allclose(b.data[1:-1], res.data[1:-1], rtol=0.1, atol=0.1)


@pytest.mark.parametrize("backend", ALL_BACKENDS, indirect=True)
def test_examples_scalar_polar(backend):
    """Compare derivatives of scalar fields for polar grids."""
    grid = PolarSymGrid(1, 32)
    sf = ScalarField.from_expression(grid, "r**3")

    # gradient
    res = sf.gradient(
        {"r-": {"derivative": 0}, "r+": {"derivative": 3}}, backend=backend
    )
    expect = VectorField.from_expression(grid, ["3 * r**2", 0])
    np.testing.assert_allclose(res.data, expect.data, rtol=0.1, atol=0.1)

    # gradient squared
    expect = ScalarField.from_expression(grid, "9 * r**4")
    for c in [True, False]:
        res = sf.gradient_squared(
            {"r-": {"derivative": 0}, "r+": {"derivative": 3}},
            central=c,
            backend=backend,
        )
        np.testing.assert_allclose(res.data, expect.data, rtol=0.1, atol=0.1)

    # laplace
    res = sf.laplace(
        {"r-": {"derivative": 0}, "r+": {"derivative": 3}}, backend=backend
    )
    expect = ScalarField.from_expression(grid, "9 * r")
    np.testing.assert_allclose(res.data, expect.data, rtol=0.1, atol=0.1)


@pytest.mark.parametrize("backend", ALL_BACKENDS, indirect=True)
def test_examples_vector_polar(backend):
    """Compare divergence of vector fields for polar grids."""
    grid = PolarSymGrid(1, 32)
    vf = VectorField.from_expression(grid, ["r**3", "r**2"])

    # divergence
    res = vf.divergence({"r-": {"derivative": 0}, "r+": {"value": 1}}, backend=backend)
    expect = ScalarField.from_expression(grid, "4 * r**2")
    np.testing.assert_allclose(res.data, expect.data, rtol=0.1, atol=0.1)


@pytest.mark.parametrize("backend", ALL_BACKENDS, indirect=True)
def test_examples_vector_gradient_polar(backend):
    """Compare gradient of vector fields for polar grids."""
    grid = PolarSymGrid(1, 32)
    vf = VectorField.from_expression(grid, ["r**3", "r**2"])

    # vector gradient
    res = vf.gradient(
        {"r-": {"derivative": 0}, "r+": {"value": [1, 1]}}, backend=backend
    )
    expr = [["3 * r**2", "-r"], ["2 * r", "r**2"]]
    expect = Tensor2Field.from_expression(grid, expr)
    np.testing.assert_allclose(res.data, expect.data, rtol=0.1, atol=0.1)


@pytest.mark.parametrize("backend", ALL_BACKENDS, indirect=True)
def test_examples_tensor_polar(backend):
    """Compare derivatives of tensorial fields for polar grids."""
    grid = PolarSymGrid(1, 32)
    tf = Tensor2Field.from_expression(grid, [["r**3"] * 2] * 2)

    # tensor divergence
    res = tf.divergence(
        {"r-": {"derivative": 0}, "r+": {"normal_value": [1, 1]}}, backend=backend
    )
    expect = VectorField.from_expression(grid, ["3 * r**2", "5 * r**2"])
    np.testing.assert_allclose(res.data, expect.data, rtol=0.1, atol=0.1)

    res = tf.divergence(
        {"r-": {"derivative": 0}, "r+": {"value": np.ones((2, 2))}}, backend=backend
    )
    expect = VectorField.from_expression(grid, ["3 * r**2", "5 * r**2"])
    np.testing.assert_allclose(res.data, expect.data, rtol=0.1, atol=0.1)
