"""Defines a solver using :mod:`scipy.integrate`

.. codeauthor:: David Zwicker <david.zwicker@ds.mpg.de>
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from .base import SolverBase

if TYPE_CHECKING:
    from ..backends.base import BackendBase
    from ..pdes.base import PDEBase
    from ..tools.typing import NumericArray, StepperType, TField


class ScipySolverError(RuntimeError): ...


class ScipySolver(SolverBase):
    """PDE solver using :func:`scipy.integrate.solve_ivp`.

    This class is a thin wrapper around :func:`scipy.integrate.solve_ivp`. In
    particular, it supports all the methods implemented by this function and exposes its
    arguments, so details can be controlled.
    """

    name = "scipy"

    def __init__(self, pde: PDEBase, *, backend: str | BackendBase = "auto", **kwargs):
        r"""
        Args:
            pde (:class:`~pde.pdes.base.PDEBase`):
                The partial differential equation that should be solved
            backend (str):
                The backend used for numerical operations
            **kwargs:
                All extra arguments are forwarded to :func:`scipy.integrate.solve_ivp`.
        """
        super().__init__(pde, backend=backend)
        self.solver_params = kwargs

    def make_stepper(self, state: TField, dt: float | None = None) -> StepperType:
        """Create the executable stepping function produced by this solver.

        Args:
            state (:class:`~pde.fields.FieldBase`):
                An example for the state from which the grid and other information can
                be extracted.
            dt (float):
                Initial time step for the simulation. If `None`, the solver will choose
                a suitable initial value.

        Returns:
            Function that can be called to advance the `state` from time
            `t_start` to time `t_end`.
        """
        from scipy import integrate

        if self.pde.is_sde:
            msg = "Deterministic SciPy solver does not support stochastic equations"
            raise RuntimeError(msg)

        shape = state.data.shape
        self.info["dt"] = dt
        self.info["steps"] = 0
        self.info["stochastic"] = False

        # obtain function for evaluating the right hand side
        self._select_backend(state)
        rhs = self.backend.make_pde_rhs(self.pde, state)

        def rhs_helper(t: float, state_flat: NumericArray) -> NumericArray:
            """Helper function to provide the correct call convention."""
            state_native = self.backend.numpy_to_native(state_flat.reshape(shape))
            rhs_native = rhs(state_native, t)
            rhs_value = self.backend.native_to_numpy(rhs_native)
            y = np.broadcast_to(rhs_value, shape).flat
            if np.any(np.isnan(y)):
                # this check is necessary, since solve_ivp does not deal correctly with
                # NaN, which might result in odd error messages or even a stalled
                # program
                msg = "Encountered Not-A-Number (NaN) in evolution"
                raise RuntimeError(msg)
            return y  # type: ignore

        def stepper(state: TField, t_start: float, t_end: float) -> float:
            """Use scipy.integrate.odeint to advance `state` from `t_start` to
            `t_end`"""
            if dt is not None:
                self.solver_params["first_step"] = min(t_end - t_start, dt)

            # run the scipy integrator
            sol = integrate.solve_ivp(
                rhs_helper,
                t_span=(t_start, t_end),
                y0=np.ravel(state.data),
                t_eval=[t_end],  # only store necessary data of the final time point
                **self.solver_params,
            )

            # check whether the integrator was successful
            if not sol.success:
                raise ScipySolverError(sol.message)

            # store information about this step
            self.info["steps"] += sol.nfev
            state.data[:] = sol.y.reshape(shape)
            return sol.t[0]  # type: ignore

        if dt:
            self._logger.info(
                "Initialize stepping function for %s with dt=%g",
                self.__class__.__name__,
                dt,
            )
        else:
            self._logger.info(
                "Initialize stepping function for %s", self.__class__.__name__
            )
        return stepper  # type: ignore
