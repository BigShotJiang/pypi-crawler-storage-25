# Aggregation

::: swift.aggregation
