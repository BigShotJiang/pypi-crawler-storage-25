# -*- coding: utf8 -*-
# Copyright (c) 2017-2025 Tencent. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import warnings

from tencentcloud.common.abstract_model import AbstractModel


class Address(AbstractModel):
    r"""

    """

    def __init__(self):
        r"""
        :param _Country: Nationality.
        :type Country: str
        :param _PostalCode: Post code.
        :type PostalCode: str
        :param _Subdivision: Subregion.
        :type Subdivision: str
        :param _City: City.
        :type City: str
        :param _FormattedAddress: Complete address.
        :type FormattedAddress: str
        :param _LineOne: The first line of address.
        :type LineOne: str
        :param _LineTwo: The second line of address.
        :type LineTwo: str
        :param _LineThree: The third line of address.
        :type LineThree: str
        :param _LineFour: The fourth line of address.
        :type LineFour: str
        :param _LineFive: The fifth line of address.
        :type LineFive: str
        """
        self._Country = None
        self._PostalCode = None
        self._Subdivision = None
        self._City = None
        self._FormattedAddress = None
        self._LineOne = None
        self._LineTwo = None
        self._LineThree = None
        self._LineFour = None
        self._LineFive = None

    @property
    def Country(self):
        r"""Nationality.
        :rtype: str
        """
        return self._Country

    @Country.setter
    def Country(self, Country):
        self._Country = Country

    @property
    def PostalCode(self):
        r"""Post code.
        :rtype: str
        """
        return self._PostalCode

    @PostalCode.setter
    def PostalCode(self, PostalCode):
        self._PostalCode = PostalCode

    @property
    def Subdivision(self):
        r"""Subregion.
        :rtype: str
        """
        return self._Subdivision

    @Subdivision.setter
    def Subdivision(self, Subdivision):
        self._Subdivision = Subdivision

    @property
    def City(self):
        r"""City.
        :rtype: str
        """
        return self._City

    @City.setter
    def City(self, City):
        self._City = City

    @property
    def FormattedAddress(self):
        r"""Complete address.
        :rtype: str
        """
        return self._FormattedAddress

    @FormattedAddress.setter
    def FormattedAddress(self, FormattedAddress):
        self._FormattedAddress = FormattedAddress

    @property
    def LineOne(self):
        r"""The first line of address.
        :rtype: str
        """
        return self._LineOne

    @LineOne.setter
    def LineOne(self, LineOne):
        self._LineOne = LineOne

    @property
    def LineTwo(self):
        r"""The second line of address.
        :rtype: str
        """
        return self._LineTwo

    @LineTwo.setter
    def LineTwo(self, LineTwo):
        self._LineTwo = LineTwo

    @property
    def LineThree(self):
        r"""The third line of address.
        :rtype: str
        """
        return self._LineThree

    @LineThree.setter
    def LineThree(self, LineThree):
        self._LineThree = LineThree

    @property
    def LineFour(self):
        r"""The fourth line of address.
        :rtype: str
        """
        return self._LineFour

    @LineFour.setter
    def LineFour(self, LineFour):
        self._LineFour = LineFour

    @property
    def LineFive(self):
        r"""The fifth line of address.
        :rtype: str
        """
        return self._LineFive

    @LineFive.setter
    def LineFive(self, LineFive):
        self._LineFive = LineFive


    def _deserialize(self, params):
        self._Country = params.get("Country")
        self._PostalCode = params.get("PostalCode")
        self._Subdivision = params.get("Subdivision")
        self._City = params.get("City")
        self._FormattedAddress = params.get("FormattedAddress")
        self._LineOne = params.get("LineOne")
        self._LineTwo = params.get("LineTwo")
        self._LineThree = params.get("LineThree")
        self._LineFour = params.get("LineFour")
        self._LineFive = params.get("LineFive")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ApplyLivenessTokenRequest(AbstractModel):
    r"""ApplyLivenessToken request structure.

    """

    def __init__(self):
        r"""
        :param _SecureLevel: Enumerated value. Valid values: `1`, `2`, `3`, and `4`.
Their meanings are as follows:
1 - silent
2 - blinking
3 - light
4 - blinking + light (default)
        :type SecureLevel: str
        """
        self._SecureLevel = None

    @property
    def SecureLevel(self):
        r"""Enumerated value. Valid values: `1`, `2`, `3`, and `4`.
Their meanings are as follows:
1 - silent
2 - blinking
3 - light
4 - blinking + light (default)
        :rtype: str
        """
        return self._SecureLevel

    @SecureLevel.setter
    def SecureLevel(self, SecureLevel):
        self._SecureLevel = SecureLevel


    def _deserialize(self, params):
        self._SecureLevel = params.get("SecureLevel")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ApplyLivenessTokenResponse(AbstractModel):
    r"""ApplyLivenessToken response structure.

    """

    def __init__(self):
        r"""
        :param _SdkToken: The token used to identify an SDK-based verification process. It is valid for 10 minutes and can be used to get the verification result after the process is completed.
        :type SdkToken: str
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._SdkToken = None
        self._RequestId = None

    @property
    def SdkToken(self):
        r"""The token used to identify an SDK-based verification process. It is valid for 10 minutes and can be used to get the verification result after the process is completed.
        :rtype: str
        """
        return self._SdkToken

    @SdkToken.setter
    def SdkToken(self, SdkToken):
        self._SdkToken = SdkToken

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._SdkToken = params.get("SdkToken")
        self._RequestId = params.get("RequestId")


class ApplySdkVerificationTokenRequest(AbstractModel):
    r"""ApplySdkVerificationToken request structure.

    """

    def __init__(self):
        r"""
        :param _CheckMode: The verification mode. Valid values:
1: OCR + liveness detection + face comparison
2: Liveness detection + face comparison
3: Liveness detection
Default value: 1
        :type CheckMode: int
        :param _SecurityLevel: The security level of the verification. Valid values:
1: Video-based liveness detection
2: Motion-based liveness detection
3: Reflection-based liveness detection
4: Motion- and reflection-based liveness detection
Default value: 4
        :type SecurityLevel: int
        :param _IdCardType: Specifies the identity document type used for authentication. valid values:.  

HK (default): hong kong (china) identity card.
2. ML: malaysian identity card.
Indonesian identity card.
4. PhilippinesVoteID: specifies the voter card in the philippines.
5. PhilippinesDrivingLicense: specifies the driving license in philippines.
6. PhilippinesTinID: specifies the philippines tin id.
7. PhilippinesSSSID: specifies the SSSID in the philippines.
8. philippines UMID: specifies the philippines UMID.
9. MLIDPassport: specifies the passport for hong kong (china), macao (china), and taiwan (china) as well as overseas passports.
ThailandIDCard: specifies the thai identity card.
Mainland id card.
12. SingaporeIDCard: specifies the Singapore id card.
13. HMTPermit: specifies the hong kong, macau and taiwan travel permit.
        :type IdCardType: str
        :param _CompareImage: The Base64-encoded value of the photo to compare, which is required only when `CheckMode` is set to `2`.
        :type CompareImage: str
        :param _NeedVerifyIdCard: Whether ID card authentication is required. If not, only document OCR will be performed. Currently, authentication is available only when the value of `IdCardType` is `HK`.
        :type NeedVerifyIdCard: bool
        :param _DisableChangeOcrResult: Whether to forbid the modification of the OCR result by users. Default value: `false` (modification allowed). (Currently, this parameter is not applied.)
        :type DisableChangeOcrResult: bool
        :param _DisableCheckOcrWarnings: Whether to disable the OCR warnings. Default value: `false` (not disable), where OCR warnings are enabled and the OCR result will not be returned if there is a warning.
This feature applies only to Hong Kong (China) identity cards, Malaysian identity cards, and passports.
        :type DisableCheckOcrWarnings: bool
        :param _SelectedWarningCodes: Customize which alarm codes to block. If left blank, all alarm codes will be blocked by default.
Optional alarm codes are: -9101 (occlusion or incomplete border), -9102 (photocopying), -9103 (screen capture by camera), -9104 (image editing/PS modification), -9107 (glare/reflection), -9108 (blurriness), -9901 (other alarms).
        :type SelectedWarningCodes: list of int
        :param _Extra: A passthrough field, which is returned together with the verification result and can contain up to 1,024 bits.
        :type Extra: str
        :param _SdkVersion: BASIC: Basic version (Default).
ENHANCE: Enhance version, enable additional output of device risk level field.
PRO: Pro version, enable additional output of attack type fields.
PLUS: Plus version, enable additional output of device risk level and attack type fields.
Please contact us to access enhance version & plus version.	
        :type SdkVersion: str
        :param _ActionList: This interface is used to control th action sequences.
Action types are as follows:
"blink"
"mouth"
"nod"
"shake"
You can choose 1-2 actions out of the four.
Single action example: "blink"
Multiple action example: "blink,mouth"
The default value is blink. The different action types passed in this parameter take effect only when the SecurityLevel is 2 or 4; otherwise, the interface reports an error.
        :type ActionList: str
        :param _AllowExpiredDocument: Whether expired identity documents are permitted to proceed to the liveness detection process. This parameter only takes effect when the document type is Hong Kong Identity Card (HKID).
true (default value): Expired HKID is allowed to enter the liveness process.
false : Expired HKID is rejected and cannot enter the liveness process.
        :type AllowExpiredDocument: bool
        :param _SkipResultPage: 
        :type SkipResultPage: bool
        :param _CardOcrDisplayFields: 
        :type CardOcrDisplayFields: list of str
        """
        self._CheckMode = None
        self._SecurityLevel = None
        self._IdCardType = None
        self._CompareImage = None
        self._NeedVerifyIdCard = None
        self._DisableChangeOcrResult = None
        self._DisableCheckOcrWarnings = None
        self._SelectedWarningCodes = None
        self._Extra = None
        self._SdkVersion = None
        self._ActionList = None
        self._AllowExpiredDocument = None
        self._SkipResultPage = None
        self._CardOcrDisplayFields = None

    @property
    def CheckMode(self):
        r"""The verification mode. Valid values:
1: OCR + liveness detection + face comparison
2: Liveness detection + face comparison
3: Liveness detection
Default value: 1
        :rtype: int
        """
        return self._CheckMode

    @CheckMode.setter
    def CheckMode(self, CheckMode):
        self._CheckMode = CheckMode

    @property
    def SecurityLevel(self):
        r"""The security level of the verification. Valid values:
1: Video-based liveness detection
2: Motion-based liveness detection
3: Reflection-based liveness detection
4: Motion- and reflection-based liveness detection
Default value: 4
        :rtype: int
        """
        return self._SecurityLevel

    @SecurityLevel.setter
    def SecurityLevel(self, SecurityLevel):
        self._SecurityLevel = SecurityLevel

    @property
    def IdCardType(self):
        r"""Specifies the identity document type used for authentication. valid values:.  

HK (default): hong kong (china) identity card.
2. ML: malaysian identity card.
Indonesian identity card.
4. PhilippinesVoteID: specifies the voter card in the philippines.
5. PhilippinesDrivingLicense: specifies the driving license in philippines.
6. PhilippinesTinID: specifies the philippines tin id.
7. PhilippinesSSSID: specifies the SSSID in the philippines.
8. philippines UMID: specifies the philippines UMID.
9. MLIDPassport: specifies the passport for hong kong (china), macao (china), and taiwan (china) as well as overseas passports.
ThailandIDCard: specifies the thai identity card.
Mainland id card.
12. SingaporeIDCard: specifies the Singapore id card.
13. HMTPermit: specifies the hong kong, macau and taiwan travel permit.
        :rtype: str
        """
        return self._IdCardType

    @IdCardType.setter
    def IdCardType(self, IdCardType):
        self._IdCardType = IdCardType

    @property
    def CompareImage(self):
        r"""The Base64-encoded value of the photo to compare, which is required only when `CheckMode` is set to `2`.
        :rtype: str
        """
        return self._CompareImage

    @CompareImage.setter
    def CompareImage(self, CompareImage):
        self._CompareImage = CompareImage

    @property
    def NeedVerifyIdCard(self):
        warnings.warn("parameter `NeedVerifyIdCard` is deprecated", DeprecationWarning) 

        r"""Whether ID card authentication is required. If not, only document OCR will be performed. Currently, authentication is available only when the value of `IdCardType` is `HK`.
        :rtype: bool
        """
        return self._NeedVerifyIdCard

    @NeedVerifyIdCard.setter
    def NeedVerifyIdCard(self, NeedVerifyIdCard):
        warnings.warn("parameter `NeedVerifyIdCard` is deprecated", DeprecationWarning) 

        self._NeedVerifyIdCard = NeedVerifyIdCard

    @property
    def DisableChangeOcrResult(self):
        r"""Whether to forbid the modification of the OCR result by users. Default value: `false` (modification allowed). (Currently, this parameter is not applied.)
        :rtype: bool
        """
        return self._DisableChangeOcrResult

    @DisableChangeOcrResult.setter
    def DisableChangeOcrResult(self, DisableChangeOcrResult):
        self._DisableChangeOcrResult = DisableChangeOcrResult

    @property
    def DisableCheckOcrWarnings(self):
        r"""Whether to disable the OCR warnings. Default value: `false` (not disable), where OCR warnings are enabled and the OCR result will not be returned if there is a warning.
This feature applies only to Hong Kong (China) identity cards, Malaysian identity cards, and passports.
        :rtype: bool
        """
        return self._DisableCheckOcrWarnings

    @DisableCheckOcrWarnings.setter
    def DisableCheckOcrWarnings(self, DisableCheckOcrWarnings):
        self._DisableCheckOcrWarnings = DisableCheckOcrWarnings

    @property
    def SelectedWarningCodes(self):
        r"""Customize which alarm codes to block. If left blank, all alarm codes will be blocked by default.
Optional alarm codes are: -9101 (occlusion or incomplete border), -9102 (photocopying), -9103 (screen capture by camera), -9104 (image editing/PS modification), -9107 (glare/reflection), -9108 (blurriness), -9901 (other alarms).
        :rtype: list of int
        """
        return self._SelectedWarningCodes

    @SelectedWarningCodes.setter
    def SelectedWarningCodes(self, SelectedWarningCodes):
        self._SelectedWarningCodes = SelectedWarningCodes

    @property
    def Extra(self):
        r"""A passthrough field, which is returned together with the verification result and can contain up to 1,024 bits.
        :rtype: str
        """
        return self._Extra

    @Extra.setter
    def Extra(self, Extra):
        self._Extra = Extra

    @property
    def SdkVersion(self):
        r"""BASIC: Basic version (Default).
ENHANCE: Enhance version, enable additional output of device risk level field.
PRO: Pro version, enable additional output of attack type fields.
PLUS: Plus version, enable additional output of device risk level and attack type fields.
Please contact us to access enhance version & plus version.	
        :rtype: str
        """
        return self._SdkVersion

    @SdkVersion.setter
    def SdkVersion(self, SdkVersion):
        self._SdkVersion = SdkVersion

    @property
    def ActionList(self):
        r"""This interface is used to control th action sequences.
Action types are as follows:
"blink"
"mouth"
"nod"
"shake"
You can choose 1-2 actions out of the four.
Single action example: "blink"
Multiple action example: "blink,mouth"
The default value is blink. The different action types passed in this parameter take effect only when the SecurityLevel is 2 or 4; otherwise, the interface reports an error.
        :rtype: str
        """
        return self._ActionList

    @ActionList.setter
    def ActionList(self, ActionList):
        self._ActionList = ActionList

    @property
    def AllowExpiredDocument(self):
        r"""Whether expired identity documents are permitted to proceed to the liveness detection process. This parameter only takes effect when the document type is Hong Kong Identity Card (HKID).
true (default value): Expired HKID is allowed to enter the liveness process.
false : Expired HKID is rejected and cannot enter the liveness process.
        :rtype: bool
        """
        return self._AllowExpiredDocument

    @AllowExpiredDocument.setter
    def AllowExpiredDocument(self, AllowExpiredDocument):
        self._AllowExpiredDocument = AllowExpiredDocument

    @property
    def SkipResultPage(self):
        r"""
        :rtype: bool
        """
        return self._SkipResultPage

    @SkipResultPage.setter
    def SkipResultPage(self, SkipResultPage):
        self._SkipResultPage = SkipResultPage

    @property
    def CardOcrDisplayFields(self):
        r"""
        :rtype: list of str
        """
        return self._CardOcrDisplayFields

    @CardOcrDisplayFields.setter
    def CardOcrDisplayFields(self, CardOcrDisplayFields):
        self._CardOcrDisplayFields = CardOcrDisplayFields


    def _deserialize(self, params):
        self._CheckMode = params.get("CheckMode")
        self._SecurityLevel = params.get("SecurityLevel")
        self._IdCardType = params.get("IdCardType")
        self._CompareImage = params.get("CompareImage")
        self._NeedVerifyIdCard = params.get("NeedVerifyIdCard")
        self._DisableChangeOcrResult = params.get("DisableChangeOcrResult")
        self._DisableCheckOcrWarnings = params.get("DisableCheckOcrWarnings")
        self._SelectedWarningCodes = params.get("SelectedWarningCodes")
        self._Extra = params.get("Extra")
        self._SdkVersion = params.get("SdkVersion")
        self._ActionList = params.get("ActionList")
        self._AllowExpiredDocument = params.get("AllowExpiredDocument")
        self._SkipResultPage = params.get("SkipResultPage")
        self._CardOcrDisplayFields = params.get("CardOcrDisplayFields")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ApplySdkVerificationTokenResponse(AbstractModel):
    r"""ApplySdkVerificationToken response structure.

    """

    def __init__(self):
        r"""
        :param _SdkToken: A token that identifies an SDK verification process. the validity time is 10 minutes. after the process is complete, the token can be used to retrieve the verification result.
        :type SdkToken: str
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._SdkToken = None
        self._RequestId = None

    @property
    def SdkToken(self):
        r"""A token that identifies an SDK verification process. the validity time is 10 minutes. after the process is complete, the token can be used to retrieve the verification result.
        :rtype: str
        """
        return self._SdkToken

    @SdkToken.setter
    def SdkToken(self, SdkToken):
        self._SdkToken = SdkToken

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._SdkToken = params.get("SdkToken")
        self._RequestId = params.get("RequestId")


class ApplyWebVerificationBizTokenIntlRequest(AbstractModel):
    r"""ApplyWebVerificationBizTokenIntl request structure.

    """

    def __init__(self):
        r"""
        :param _RedirectURL: Web callback URL to redirect to after the verification is completed, including the protocol, hostname, and path. 
After the verification process is completed, the BizToken of this process will be spliced to the callback URL in the format of https://www.tencentcloud.com/products/faceid?token={BizToken} before redirect.
Example: https://www.tencentcloud.com/products/faceid.
        :type RedirectURL: str
        :param _CompareImageBase64: The Base64-encoded string (max 8 MB in size) of the photo to be compared.The Data URI scheme header needs to be removed from the encoded string
Example: xhBQAAACBjSFJNAAB6****AAAASUVORK5CYII=
        :type CompareImageBase64: str
        :param _Extra: The passthrough parameter of the business, max 1,000 characters, which will be returned in GetWebVerificationResultIntl.
        :type Extra: str
        :param _RuleId: The business process ID generated by the console.
        :type RuleId: str
        :param _Config: The parameter control the page configuration.
Example: {"AutoSkip": true,"CheckMode": 1,"IdCardType": "HKIDCard"}
        :type Config: :class:`tencentcloud.faceid.v20180301.models.WebVerificationConfigIntl`
        """
        self._RedirectURL = None
        self._CompareImageBase64 = None
        self._Extra = None
        self._RuleId = None
        self._Config = None

    @property
    def RedirectURL(self):
        r"""Web callback URL to redirect to after the verification is completed, including the protocol, hostname, and path. 
After the verification process is completed, the BizToken of this process will be spliced to the callback URL in the format of https://www.tencentcloud.com/products/faceid?token={BizToken} before redirect.
Example: https://www.tencentcloud.com/products/faceid.
        :rtype: str
        """
        return self._RedirectURL

    @RedirectURL.setter
    def RedirectURL(self, RedirectURL):
        self._RedirectURL = RedirectURL

    @property
    def CompareImageBase64(self):
        r"""The Base64-encoded string (max 8 MB in size) of the photo to be compared.The Data URI scheme header needs to be removed from the encoded string
Example: xhBQAAACBjSFJNAAB6****AAAASUVORK5CYII=
        :rtype: str
        """
        return self._CompareImageBase64

    @CompareImageBase64.setter
    def CompareImageBase64(self, CompareImageBase64):
        self._CompareImageBase64 = CompareImageBase64

    @property
    def Extra(self):
        r"""The passthrough parameter of the business, max 1,000 characters, which will be returned in GetWebVerificationResultIntl.
        :rtype: str
        """
        return self._Extra

    @Extra.setter
    def Extra(self, Extra):
        self._Extra = Extra

    @property
    def RuleId(self):
        r"""The business process ID generated by the console.
        :rtype: str
        """
        return self._RuleId

    @RuleId.setter
    def RuleId(self, RuleId):
        self._RuleId = RuleId

    @property
    def Config(self):
        r"""The parameter control the page configuration.
Example: {"AutoSkip": true,"CheckMode": 1,"IdCardType": "HKIDCard"}
        :rtype: :class:`tencentcloud.faceid.v20180301.models.WebVerificationConfigIntl`
        """
        return self._Config

    @Config.setter
    def Config(self, Config):
        self._Config = Config


    def _deserialize(self, params):
        self._RedirectURL = params.get("RedirectURL")
        self._CompareImageBase64 = params.get("CompareImageBase64")
        self._Extra = params.get("Extra")
        self._RuleId = params.get("RuleId")
        if params.get("Config") is not None:
            self._Config = WebVerificationConfigIntl()
            self._Config._deserialize(params.get("Config"))
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ApplyWebVerificationBizTokenIntlResponse(AbstractModel):
    r"""ApplyWebVerificationBizTokenIntl response structure.

    """

    def __init__(self):
        r"""
        :param _VerificationUrl: The token identifying this web-based verification process, valid for 7,200s after issuance. It is required for getting the result after the verification process is completed.
Example: https://intl.faceid.qq.com/reflect/?token=81EEF678-28EE-4759-A82E-6CBBBE6BC442
        :type VerificationUrl: str
        :param _BizToken: A token that identifies a Web verification process, with a validity time of 10 minutes. after the process is complete, the token can be used to obtain the verification result.
        :type BizToken: str
        :param _VerificationURL: The verification URL to be opened with a browser to start the verification process.
Example: https://intl.faceid.qq.com/reflect/?token=81EEF678-28EE-4759-A82E-6CBBBE6BC442
        :type VerificationURL: str
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._VerificationUrl = None
        self._BizToken = None
        self._VerificationURL = None
        self._RequestId = None

    @property
    def VerificationUrl(self):
        warnings.warn("parameter `VerificationUrl` is deprecated", DeprecationWarning) 

        r"""The token identifying this web-based verification process, valid for 7,200s after issuance. It is required for getting the result after the verification process is completed.
Example: https://intl.faceid.qq.com/reflect/?token=81EEF678-28EE-4759-A82E-6CBBBE6BC442
        :rtype: str
        """
        return self._VerificationUrl

    @VerificationUrl.setter
    def VerificationUrl(self, VerificationUrl):
        warnings.warn("parameter `VerificationUrl` is deprecated", DeprecationWarning) 

        self._VerificationUrl = VerificationUrl

    @property
    def BizToken(self):
        r"""A token that identifies a Web verification process, with a validity time of 10 minutes. after the process is complete, the token can be used to obtain the verification result.
        :rtype: str
        """
        return self._BizToken

    @BizToken.setter
    def BizToken(self, BizToken):
        self._BizToken = BizToken

    @property
    def VerificationURL(self):
        r"""The verification URL to be opened with a browser to start the verification process.
Example: https://intl.faceid.qq.com/reflect/?token=81EEF678-28EE-4759-A82E-6CBBBE6BC442
        :rtype: str
        """
        return self._VerificationURL

    @VerificationURL.setter
    def VerificationURL(self, VerificationURL):
        self._VerificationURL = VerificationURL

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._VerificationUrl = params.get("VerificationUrl")
        self._BizToken = params.get("BizToken")
        self._VerificationURL = params.get("VerificationURL")
        self._RequestId = params.get("RequestId")


class AttackRiskDetail(AbstractModel):
    r"""Suspected attack detail

    """

    def __init__(self):
        r"""
        :param _Type: Suspected attack trace types
SuspectedSpoofingAttack: Suspected spoofing attack
SuspectedSynthesisImage: Suspected synthesis image
SuspectedSynthesisVideo: Suspected synthesis video
SuspectedeAnomalyAttack: Suspected anomaly attack
SuspectedAdversarialAttack: Suspected adversarial attack 
SuspectedBlackIndustry: Suspected batch generation attack
SuspectedWatermark: Suspected watermark
        :type Type: str
        """
        self._Type = None

    @property
    def Type(self):
        r"""Suspected attack trace types
SuspectedSpoofingAttack: Suspected spoofing attack
SuspectedSynthesisImage: Suspected synthesis image
SuspectedSynthesisVideo: Suspected synthesis video
SuspectedeAnomalyAttack: Suspected anomaly attack
SuspectedAdversarialAttack: Suspected adversarial attack 
SuspectedBlackIndustry: Suspected batch generation attack
SuspectedWatermark: Suspected watermark
        :rtype: str
        """
        return self._Type

    @Type.setter
    def Type(self, Type):
        self._Type = Type


    def _deserialize(self, params):
        self._Type = params.get("Type")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class BangladeshIDCard(AbstractModel):
    r"""Bangladesh ID card

    """

    def __init__(self):
        r"""
        :param _LastName: Last name.
Note: This field may return null, indicating that no valid values can be obtained.
        :type LastName: str
        :param _FirstName: First name.
Note: This field may return null, indicating that no valid values can be obtained.
        :type FirstName: str
        :param _LicenseNumber: License number.
Note: This field may return null, indicating that no valid values can be obtained.
        :type LicenseNumber: str
        :param _Age: Age.
Note: This field may return null, indicating that no valid values can be obtained.
        :type Age: str
        :param _Birthday: Birthday.
Note: This field may return null, indicating that no valid values can be obtained.
        :type Birthday: str
        :param _IssuedCountry: Issued country.
Note: This field may return null, indicating that no valid values can be obtained.
        :type IssuedCountry: str
        """
        self._LastName = None
        self._FirstName = None
        self._LicenseNumber = None
        self._Age = None
        self._Birthday = None
        self._IssuedCountry = None

    @property
    def LastName(self):
        r"""Last name.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._LastName

    @LastName.setter
    def LastName(self, LastName):
        self._LastName = LastName

    @property
    def FirstName(self):
        r"""First name.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._FirstName

    @FirstName.setter
    def FirstName(self, FirstName):
        self._FirstName = FirstName

    @property
    def LicenseNumber(self):
        r"""License number.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._LicenseNumber

    @LicenseNumber.setter
    def LicenseNumber(self, LicenseNumber):
        self._LicenseNumber = LicenseNumber

    @property
    def Age(self):
        r"""Age.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Age

    @Age.setter
    def Age(self, Age):
        self._Age = Age

    @property
    def Birthday(self):
        r"""Birthday.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Birthday

    @Birthday.setter
    def Birthday(self, Birthday):
        self._Birthday = Birthday

    @property
    def IssuedCountry(self):
        r"""Issued country.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._IssuedCountry

    @IssuedCountry.setter
    def IssuedCountry(self, IssuedCountry):
        self._IssuedCountry = IssuedCountry


    def _deserialize(self, params):
        self._LastName = params.get("LastName")
        self._FirstName = params.get("FirstName")
        self._LicenseNumber = params.get("LicenseNumber")
        self._Age = params.get("Age")
        self._Birthday = params.get("Birthday")
        self._IssuedCountry = params.get("IssuedCountry")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class BankCard2EVerificationRequest(AbstractModel):
    r"""BankCard2EVerification request structure.

    """

    def __init__(self):
        r"""
        :param _Name: Name
        :type Name: str
        :param _BankCard: Bank card.
        :type BankCard: str
        :param _Encryption: Sensitive data encryption info.
- Users with encryption requirements for incoming information (name, bank card number) can use this parameter. For details, please click the left-side link.
        :type Encryption: :class:`tencentcloud.faceid.v20180301.models.Encryption`
        """
        self._Name = None
        self._BankCard = None
        self._Encryption = None

    @property
    def Name(self):
        r"""Name
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def BankCard(self):
        r"""Bank card.
        :rtype: str
        """
        return self._BankCard

    @BankCard.setter
    def BankCard(self, BankCard):
        self._BankCard = BankCard

    @property
    def Encryption(self):
        r"""Sensitive data encryption info.
- Users with encryption requirements for incoming information (name, bank card number) can use this parameter. For details, please click the left-side link.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.Encryption`
        """
        return self._Encryption

    @Encryption.setter
    def Encryption(self, Encryption):
        self._Encryption = Encryption


    def _deserialize(self, params):
        self._Name = params.get("Name")
        self._BankCard = params.get("BankCard")
        if params.get("Encryption") is not None:
            self._Encryption = Encryption()
            self._Encryption._deserialize(params.get("Encryption"))
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class BankCard2EVerificationResponse(AbstractModel):
    r"""BankCard2EVerification response structure.

    """

    def __init__(self):
        r"""
        :param _Result: Verification result code.
-Billing result code:
'0': 'Authentication passed'.
'-1': 'Authentication failed'.
'-4': 'Cardholder information is incorrect'.
'-5': 'Cardless payment not enabled'.
'-6': 'Card confiscated'.
'-7': 'Invalid card number'.
'-8': 'No corresponding issuing bank for this card'.
'-9': 'The card is uninitialized or a Sleep Card'.
'-10': 'Cheat card, card confiscation'.
'-11': 'Reported lost'.
'-12': 'The card has expired'.
'-13': 'Restricted card'.
'-14': 'Number of password errors exceeds the limit'.
'-15': 'Issuer does not support this transaction'.
'-18': 'Card status exception or card number error'.

-Non-billing Result Code:
'-2': 'Name verification failed'.
'-3': 'Incorrect bank card number format'.
'-16': 'Verification Center Service busy'.
'-17': 'Verification attempts exceeded. Please retry the next day.'

        :type Result: str
        :param _Description: Business result description.
        :type Description: str
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._Result = None
        self._Description = None
        self._RequestId = None

    @property
    def Result(self):
        r"""Verification result code.
-Billing result code:
'0': 'Authentication passed'.
'-1': 'Authentication failed'.
'-4': 'Cardholder information is incorrect'.
'-5': 'Cardless payment not enabled'.
'-6': 'Card confiscated'.
'-7': 'Invalid card number'.
'-8': 'No corresponding issuing bank for this card'.
'-9': 'The card is uninitialized or a Sleep Card'.
'-10': 'Cheat card, card confiscation'.
'-11': 'Reported lost'.
'-12': 'The card has expired'.
'-13': 'Restricted card'.
'-14': 'Number of password errors exceeds the limit'.
'-15': 'Issuer does not support this transaction'.
'-18': 'Card status exception or card number error'.

-Non-billing Result Code:
'-2': 'Name verification failed'.
'-3': 'Incorrect bank card number format'.
'-16': 'Verification Center Service busy'.
'-17': 'Verification attempts exceeded. Please retry the next day.'

        :rtype: str
        """
        return self._Result

    @Result.setter
    def Result(self, Result):
        self._Result = Result

    @property
    def Description(self):
        r"""Business result description.
        :rtype: str
        """
        return self._Description

    @Description.setter
    def Description(self, Description):
        self._Description = Description

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._Result = params.get("Result")
        self._Description = params.get("Description")
        self._RequestId = params.get("RequestId")


class BankCard4EVerificationRequest(AbstractModel):
    r"""BankCard4EVerification request structure.

    """

    def __init__(self):
        r"""
        :param _Name: Name
        :type Name: str
        :param _BankCard: Bank card.
        :type BankCard: str
        :param _Phone: Mobile number.
        :type Phone: str
        :param _IdCard: ID number for account opening.
-The document type must match the Type parameter, for example: input the ID card number for an identity card.
        :type IdCard: str
        :param _CertType: Document type.
-Please confirm this document is the document type used when opening an account. Document information not used for account opening is not supported for verification.
-Currently defaults to 0: ID card. Other document types are not currently supported.
        :type CertType: int
        :param _Encryption: Sensitive data encryption info.
-Users with encryption requirements for incoming information (name, identity card number, mobile number, bank card number) can use this parameter. For details, please click the left-side link.
        :type Encryption: :class:`tencentcloud.faceid.v20180301.models.Encryption`
        """
        self._Name = None
        self._BankCard = None
        self._Phone = None
        self._IdCard = None
        self._CertType = None
        self._Encryption = None

    @property
    def Name(self):
        r"""Name
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def BankCard(self):
        r"""Bank card.
        :rtype: str
        """
        return self._BankCard

    @BankCard.setter
    def BankCard(self, BankCard):
        self._BankCard = BankCard

    @property
    def Phone(self):
        r"""Mobile number.
        :rtype: str
        """
        return self._Phone

    @Phone.setter
    def Phone(self, Phone):
        self._Phone = Phone

    @property
    def IdCard(self):
        r"""ID number for account opening.
-The document type must match the Type parameter, for example: input the ID card number for an identity card.
        :rtype: str
        """
        return self._IdCard

    @IdCard.setter
    def IdCard(self, IdCard):
        self._IdCard = IdCard

    @property
    def CertType(self):
        r"""Document type.
-Please confirm this document is the document type used when opening an account. Document information not used for account opening is not supported for verification.
-Currently defaults to 0: ID card. Other document types are not currently supported.
        :rtype: int
        """
        return self._CertType

    @CertType.setter
    def CertType(self, CertType):
        self._CertType = CertType

    @property
    def Encryption(self):
        r"""Sensitive data encryption info.
-Users with encryption requirements for incoming information (name, identity card number, mobile number, bank card number) can use this parameter. For details, please click the left-side link.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.Encryption`
        """
        return self._Encryption

    @Encryption.setter
    def Encryption(self, Encryption):
        self._Encryption = Encryption


    def _deserialize(self, params):
        self._Name = params.get("Name")
        self._BankCard = params.get("BankCard")
        self._Phone = params.get("Phone")
        self._IdCard = params.get("IdCard")
        self._CertType = params.get("CertType")
        if params.get("Encryption") is not None:
            self._Encryption = Encryption()
            self._Encryption._deserialize(params.get("Encryption"))
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class BankCard4EVerificationResponse(AbstractModel):
    r"""BankCard4EVerification response structure.

    """

    def __init__(self):
        r"""
        :param _Result: Verification result code.
-Result code for charges
'0': 'Authentication passed'.
'-1': 'Authentication failed'.
'-6': 'Cardholder information is incorrect'.
'-7': 'Cardless payment not enabled'.
'-8': 'Card confiscated'.
'-9': 'Invalid card number'.
'-10': 'No corresponding issuing bank for this card'.
'-11': 'The card is uninitialized or a Sleep Card'.
'-12': 'Cheat card, card confiscation'.
'-13': 'Reported lost'.
'-14': 'The card has expired.'
'-15': 'Restricted card'.
'-16': 'Exceeded the number of password errors'.
'-17': 'Issuer does not support this transaction'.
'-21': 'Card status exception or card number error'.

-Result code with no charge
'-2': 'Name verification failed'.
'-3': 'Identity number error'.
'-4': 'Incorrect bank card number format'.
'-5': 'Invalid phone number'.
'-18': 'Verification Center Service busy'.
'-19': 'Exceeded maximum verification attempts. Please retry the next day.'
'-20': 'The ID number is not currently supported for verification. Currently only support second-generation resident identity card.'
        :type Result: str
        :param _Description: Business result description.
        :type Description: str
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._Result = None
        self._Description = None
        self._RequestId = None

    @property
    def Result(self):
        r"""Verification result code.
-Result code for charges
'0': 'Authentication passed'.
'-1': 'Authentication failed'.
'-6': 'Cardholder information is incorrect'.
'-7': 'Cardless payment not enabled'.
'-8': 'Card confiscated'.
'-9': 'Invalid card number'.
'-10': 'No corresponding issuing bank for this card'.
'-11': 'The card is uninitialized or a Sleep Card'.
'-12': 'Cheat card, card confiscation'.
'-13': 'Reported lost'.
'-14': 'The card has expired.'
'-15': 'Restricted card'.
'-16': 'Exceeded the number of password errors'.
'-17': 'Issuer does not support this transaction'.
'-21': 'Card status exception or card number error'.

-Result code with no charge
'-2': 'Name verification failed'.
'-3': 'Identity number error'.
'-4': 'Incorrect bank card number format'.
'-5': 'Invalid phone number'.
'-18': 'Verification Center Service busy'.
'-19': 'Exceeded maximum verification attempts. Please retry the next day.'
'-20': 'The ID number is not currently supported for verification. Currently only support second-generation resident identity card.'
        :rtype: str
        """
        return self._Result

    @Result.setter
    def Result(self, Result):
        self._Result = Result

    @property
    def Description(self):
        r"""Business result description.
        :rtype: str
        """
        return self._Description

    @Description.setter
    def Description(self, Description):
        self._Description = Description

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._Result = params.get("Result")
        self._Description = params.get("Description")
        self._RequestId = params.get("RequestId")


class BankCardVerificationRequest(AbstractModel):
    r"""BankCardVerification request structure.

    """

    def __init__(self):
        r"""
        :param _IdCard: ID number for account opening.
-The document type must match the Type parameter, for example: input the ID card number for an identity card.
        :type IdCard: str
        :param _Name: Name
        :type Name: str
        :param _BankCard: Bank card.
        :type BankCard: str
        :param _CertType: Document type.
-Please confirm this document is the document type used when opening an account. Document information not used for account opening is not supported for verification.
-Currently default: 0 ID card. Other document types are not currently supported.
        :type CertType: int
        :param _Encryption: Sensitive data encryption info.
-Users with encryption requirements for incoming information (name, identity card number, bank card number) can use this parameter. For details, please click the left-side link.
        :type Encryption: :class:`tencentcloud.faceid.v20180301.models.Encryption`
        """
        self._IdCard = None
        self._Name = None
        self._BankCard = None
        self._CertType = None
        self._Encryption = None

    @property
    def IdCard(self):
        r"""ID number for account opening.
-The document type must match the Type parameter, for example: input the ID card number for an identity card.
        :rtype: str
        """
        return self._IdCard

    @IdCard.setter
    def IdCard(self, IdCard):
        self._IdCard = IdCard

    @property
    def Name(self):
        r"""Name
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def BankCard(self):
        r"""Bank card.
        :rtype: str
        """
        return self._BankCard

    @BankCard.setter
    def BankCard(self, BankCard):
        self._BankCard = BankCard

    @property
    def CertType(self):
        r"""Document type.
-Please confirm this document is the document type used when opening an account. Document information not used for account opening is not supported for verification.
-Currently default: 0 ID card. Other document types are not currently supported.
        :rtype: int
        """
        return self._CertType

    @CertType.setter
    def CertType(self, CertType):
        self._CertType = CertType

    @property
    def Encryption(self):
        r"""Sensitive data encryption info.
-Users with encryption requirements for incoming information (name, identity card number, bank card number) can use this parameter. For details, please click the left-side link.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.Encryption`
        """
        return self._Encryption

    @Encryption.setter
    def Encryption(self, Encryption):
        self._Encryption = Encryption


    def _deserialize(self, params):
        self._IdCard = params.get("IdCard")
        self._Name = params.get("Name")
        self._BankCard = params.get("BankCard")
        self._CertType = params.get("CertType")
        if params.get("Encryption") is not None:
            self._Encryption = Encryption()
            self._Encryption._deserialize(params.get("Encryption"))
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class BankCardVerificationResponse(AbstractModel):
    r"""BankCardVerification response structure.

    """

    def __init__(self):
        r"""
        :param _Result: Verification result code.
-Result code for charges
'0': 'Authentication passed'.
'-1': 'Authentication failed'.
'-5': 'Cardholder information is incorrect'.
'-6': 'Cardless payment not enabled'.
'-7': 'Card confiscated'.
'-8': 'Invalid card number'.
'-9': 'No corresponding issuing bank for this card'.
'-10': 'The card is uninitialized or a Sleep Card'.
'-11': 'Cheat card, card retention'.
'-12': 'Reported lost'.
'-13': 'The card has expired.'
'-14': 'Restricted card'.
'-15': 'Exceeded the number of password errors.'
'-16': 'Issuer does not support this transaction'.
'-20': 'Card status exception or card number error'.

-Result code with no charge
'-2': 'Name verification failed'.
'-3': 'Identity number error'.
'-4': 'Incorrect bank card number format'.
'-17': 'Verification Center Service busy'.
'-18': 'Exceeded verification attempts. Please retry the next day.'
'-19': 'The ID number is not currently supported for verification. Currently only support second-generation resident identity card.'	
        :type Result: str
        :param _Description: Business result description.
        :type Description: str
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._Result = None
        self._Description = None
        self._RequestId = None

    @property
    def Result(self):
        r"""Verification result code.
-Result code for charges
'0': 'Authentication passed'.
'-1': 'Authentication failed'.
'-5': 'Cardholder information is incorrect'.
'-6': 'Cardless payment not enabled'.
'-7': 'Card confiscated'.
'-8': 'Invalid card number'.
'-9': 'No corresponding issuing bank for this card'.
'-10': 'The card is uninitialized or a Sleep Card'.
'-11': 'Cheat card, card retention'.
'-12': 'Reported lost'.
'-13': 'The card has expired.'
'-14': 'Restricted card'.
'-15': 'Exceeded the number of password errors.'
'-16': 'Issuer does not support this transaction'.
'-20': 'Card status exception or card number error'.

-Result code with no charge
'-2': 'Name verification failed'.
'-3': 'Identity number error'.
'-4': 'Incorrect bank card number format'.
'-17': 'Verification Center Service busy'.
'-18': 'Exceeded verification attempts. Please retry the next day.'
'-19': 'The ID number is not currently supported for verification. Currently only support second-generation resident identity card.'	
        :rtype: str
        """
        return self._Result

    @Result.setter
    def Result(self, Result):
        self._Result = Result

    @property
    def Description(self):
        r"""Business result description.
        :rtype: str
        """
        return self._Description

    @Description.setter
    def Description(self, Description):
        self._Description = Description

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._Result = params.get("Result")
        self._Description = params.get("Description")
        self._RequestId = params.get("RequestId")


class CardInfo(AbstractModel):
    r"""License OCR result

    """

    def __init__(self):
        r"""
        :param _HKIDCard: Hong Kong ID (China) Card
Note: This field may return null, indicating that no valid values can be obtained.
        :type HKIDCard: :class:`tencentcloud.faceid.v20180301.models.HKIDCard`
        :param _MLIDCard: Malaysia ID Card
Note: This field may return null, indicating that no valid values can be obtained.
        :type MLIDCard: :class:`tencentcloud.faceid.v20180301.models.MLIDCard`
        :param _PhilippinesVoteID: Philippines VoteID Card
Note: This field may return null, indicating that no valid values can be obtained.
        :type PhilippinesVoteID: :class:`tencentcloud.faceid.v20180301.models.PhilippinesVoteID`
        :param _IndonesiaIDCard: Indonesia ID Card
Note: This field may return null, indicating that no valid values can be obtained.
        :type IndonesiaIDCard: :class:`tencentcloud.faceid.v20180301.models.IndonesiaIDCard`
        :param _PhilippinesDrivingLicense: Philippines Driving License
Note: This field may return null, indicating that no valid values can be obtained.
        :type PhilippinesDrivingLicense: :class:`tencentcloud.faceid.v20180301.models.PhilippinesDrivingLicense`
        :param _PhilippinesTinID: Philippines TinID
Note: This field may return null, indicating that no valid values can be obtained.
        :type PhilippinesTinID: :class:`tencentcloud.faceid.v20180301.models.PhilippinesTinID`
        :param _PhilippinesSSSID: Philippines SSSID
Note: This field may return null, indicating that no valid values can be obtained.
        :type PhilippinesSSSID: :class:`tencentcloud.faceid.v20180301.models.PhilippinesSSSID`
        :param _PhilippinesUMID: Philippines UMID
Note: This field may return null, indicating that no valid values can be obtained.
        :type PhilippinesUMID: :class:`tencentcloud.faceid.v20180301.models.PhilippinesUMID`
        :param _InternationalIDPassport: ID Cards of Hong Kong (China), Macao (China) and Taiwan (China), and International Passport
Note: This field may return null, indicating that no valid values can be obtained.
        :type InternationalIDPassport: :class:`tencentcloud.faceid.v20180301.models.InternationalIDPassport`
        :param _GeneralCard: General license information
Note: This field may return null, indicating that no valid values can be obtained.
        :type GeneralCard: :class:`tencentcloud.faceid.v20180301.models.GeneralCard`
        :param _IndonesiaDrivingLicense: Indonesia Driving License
Note: This field may return null, indicating that no valid values can be obtained.
        :type IndonesiaDrivingLicense: :class:`tencentcloud.faceid.v20180301.models.IndonesiaDrivingLicense`
        :param _ThailandIDCard: Thailand ID Card
Note: This field may return null, indicating that no valid values can be obtained.
        :type ThailandIDCard: :class:`tencentcloud.faceid.v20180301.models.ThailandIDCard`
        :param _SingaporeIDCard: Singapore ID Card
Note: This field may return null, indicating that no valid values can be obtained.
        :type SingaporeIDCard: :class:`tencentcloud.faceid.v20180301.models.SingaporeIDCard`
        :param _MacaoIDCard: Macao (China) ID Card
Note: This field may return null, indicating that no valid values can be obtained.
        :type MacaoIDCard: :class:`tencentcloud.faceid.v20180301.models.MacaoIDCard`
        :param _TaiWanIDCard: TaiWan (China) ID Card
Note: This field may return null, indicating that no valid values can be obtained.
        :type TaiWanIDCard: :class:`tencentcloud.faceid.v20180301.models.TaiWanIDCard`
        :param _JapanIDCard: Japan ID Card
Note: This field may return null, indicating that no valid values can be obtained.
        :type JapanIDCard: :class:`tencentcloud.faceid.v20180301.models.JapanIDCard`
        :param _BangladeshIDCard: Bangladesh ID Card
Note: This field may return null, indicating that no valid values can be obtained.
        :type BangladeshIDCard: :class:`tencentcloud.faceid.v20180301.models.BangladeshIDCard`
        :param _NigeriaIDCard: Nigeria ID Card
Note: This field may return null, indicating that no valid values can be obtained.
        :type NigeriaIDCard: :class:`tencentcloud.faceid.v20180301.models.NigeriaIDCard`
        :param _NigeriaDrivingLicense: Nigeria driving license
Note: This field may return null, indicating that no valid values can be obtained.
        :type NigeriaDrivingLicense: :class:`tencentcloud.faceid.v20180301.models.NigeriaDrivingLicense`
        :param _PakistanIDCard: Pakistan ID Card
Note: This field may return null, indicating that no valid values can be obtained.
        :type PakistanIDCard: :class:`tencentcloud.faceid.v20180301.models.PakistanIDCard`
        :param _PakistanDrivingLicense: Pakistan driving license
Note: This field may return null, indicating that no valid values can be obtained.
        :type PakistanDrivingLicense: :class:`tencentcloud.faceid.v20180301.models.PakistanDrivingLicense`
        """
        self._HKIDCard = None
        self._MLIDCard = None
        self._PhilippinesVoteID = None
        self._IndonesiaIDCard = None
        self._PhilippinesDrivingLicense = None
        self._PhilippinesTinID = None
        self._PhilippinesSSSID = None
        self._PhilippinesUMID = None
        self._InternationalIDPassport = None
        self._GeneralCard = None
        self._IndonesiaDrivingLicense = None
        self._ThailandIDCard = None
        self._SingaporeIDCard = None
        self._MacaoIDCard = None
        self._TaiWanIDCard = None
        self._JapanIDCard = None
        self._BangladeshIDCard = None
        self._NigeriaIDCard = None
        self._NigeriaDrivingLicense = None
        self._PakistanIDCard = None
        self._PakistanDrivingLicense = None

    @property
    def HKIDCard(self):
        r"""Hong Kong ID (China) Card
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.HKIDCard`
        """
        return self._HKIDCard

    @HKIDCard.setter
    def HKIDCard(self, HKIDCard):
        self._HKIDCard = HKIDCard

    @property
    def MLIDCard(self):
        r"""Malaysia ID Card
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.MLIDCard`
        """
        return self._MLIDCard

    @MLIDCard.setter
    def MLIDCard(self, MLIDCard):
        self._MLIDCard = MLIDCard

    @property
    def PhilippinesVoteID(self):
        r"""Philippines VoteID Card
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.PhilippinesVoteID`
        """
        return self._PhilippinesVoteID

    @PhilippinesVoteID.setter
    def PhilippinesVoteID(self, PhilippinesVoteID):
        self._PhilippinesVoteID = PhilippinesVoteID

    @property
    def IndonesiaIDCard(self):
        r"""Indonesia ID Card
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.IndonesiaIDCard`
        """
        return self._IndonesiaIDCard

    @IndonesiaIDCard.setter
    def IndonesiaIDCard(self, IndonesiaIDCard):
        self._IndonesiaIDCard = IndonesiaIDCard

    @property
    def PhilippinesDrivingLicense(self):
        r"""Philippines Driving License
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.PhilippinesDrivingLicense`
        """
        return self._PhilippinesDrivingLicense

    @PhilippinesDrivingLicense.setter
    def PhilippinesDrivingLicense(self, PhilippinesDrivingLicense):
        self._PhilippinesDrivingLicense = PhilippinesDrivingLicense

    @property
    def PhilippinesTinID(self):
        r"""Philippines TinID
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.PhilippinesTinID`
        """
        return self._PhilippinesTinID

    @PhilippinesTinID.setter
    def PhilippinesTinID(self, PhilippinesTinID):
        self._PhilippinesTinID = PhilippinesTinID

    @property
    def PhilippinesSSSID(self):
        r"""Philippines SSSID
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.PhilippinesSSSID`
        """
        return self._PhilippinesSSSID

    @PhilippinesSSSID.setter
    def PhilippinesSSSID(self, PhilippinesSSSID):
        self._PhilippinesSSSID = PhilippinesSSSID

    @property
    def PhilippinesUMID(self):
        r"""Philippines UMID
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.PhilippinesUMID`
        """
        return self._PhilippinesUMID

    @PhilippinesUMID.setter
    def PhilippinesUMID(self, PhilippinesUMID):
        self._PhilippinesUMID = PhilippinesUMID

    @property
    def InternationalIDPassport(self):
        r"""ID Cards of Hong Kong (China), Macao (China) and Taiwan (China), and International Passport
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.InternationalIDPassport`
        """
        return self._InternationalIDPassport

    @InternationalIDPassport.setter
    def InternationalIDPassport(self, InternationalIDPassport):
        self._InternationalIDPassport = InternationalIDPassport

    @property
    def GeneralCard(self):
        r"""General license information
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.GeneralCard`
        """
        return self._GeneralCard

    @GeneralCard.setter
    def GeneralCard(self, GeneralCard):
        self._GeneralCard = GeneralCard

    @property
    def IndonesiaDrivingLicense(self):
        r"""Indonesia Driving License
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.IndonesiaDrivingLicense`
        """
        return self._IndonesiaDrivingLicense

    @IndonesiaDrivingLicense.setter
    def IndonesiaDrivingLicense(self, IndonesiaDrivingLicense):
        self._IndonesiaDrivingLicense = IndonesiaDrivingLicense

    @property
    def ThailandIDCard(self):
        r"""Thailand ID Card
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.ThailandIDCard`
        """
        return self._ThailandIDCard

    @ThailandIDCard.setter
    def ThailandIDCard(self, ThailandIDCard):
        self._ThailandIDCard = ThailandIDCard

    @property
    def SingaporeIDCard(self):
        r"""Singapore ID Card
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.SingaporeIDCard`
        """
        return self._SingaporeIDCard

    @SingaporeIDCard.setter
    def SingaporeIDCard(self, SingaporeIDCard):
        self._SingaporeIDCard = SingaporeIDCard

    @property
    def MacaoIDCard(self):
        r"""Macao (China) ID Card
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.MacaoIDCard`
        """
        return self._MacaoIDCard

    @MacaoIDCard.setter
    def MacaoIDCard(self, MacaoIDCard):
        self._MacaoIDCard = MacaoIDCard

    @property
    def TaiWanIDCard(self):
        r"""TaiWan (China) ID Card
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.TaiWanIDCard`
        """
        return self._TaiWanIDCard

    @TaiWanIDCard.setter
    def TaiWanIDCard(self, TaiWanIDCard):
        self._TaiWanIDCard = TaiWanIDCard

    @property
    def JapanIDCard(self):
        r"""Japan ID Card
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.JapanIDCard`
        """
        return self._JapanIDCard

    @JapanIDCard.setter
    def JapanIDCard(self, JapanIDCard):
        self._JapanIDCard = JapanIDCard

    @property
    def BangladeshIDCard(self):
        r"""Bangladesh ID Card
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.BangladeshIDCard`
        """
        return self._BangladeshIDCard

    @BangladeshIDCard.setter
    def BangladeshIDCard(self, BangladeshIDCard):
        self._BangladeshIDCard = BangladeshIDCard

    @property
    def NigeriaIDCard(self):
        r"""Nigeria ID Card
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.NigeriaIDCard`
        """
        return self._NigeriaIDCard

    @NigeriaIDCard.setter
    def NigeriaIDCard(self, NigeriaIDCard):
        self._NigeriaIDCard = NigeriaIDCard

    @property
    def NigeriaDrivingLicense(self):
        r"""Nigeria driving license
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.NigeriaDrivingLicense`
        """
        return self._NigeriaDrivingLicense

    @NigeriaDrivingLicense.setter
    def NigeriaDrivingLicense(self, NigeriaDrivingLicense):
        self._NigeriaDrivingLicense = NigeriaDrivingLicense

    @property
    def PakistanIDCard(self):
        r"""Pakistan ID Card
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.PakistanIDCard`
        """
        return self._PakistanIDCard

    @PakistanIDCard.setter
    def PakistanIDCard(self, PakistanIDCard):
        self._PakistanIDCard = PakistanIDCard

    @property
    def PakistanDrivingLicense(self):
        r"""Pakistan driving license
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.PakistanDrivingLicense`
        """
        return self._PakistanDrivingLicense

    @PakistanDrivingLicense.setter
    def PakistanDrivingLicense(self, PakistanDrivingLicense):
        self._PakistanDrivingLicense = PakistanDrivingLicense


    def _deserialize(self, params):
        if params.get("HKIDCard") is not None:
            self._HKIDCard = HKIDCard()
            self._HKIDCard._deserialize(params.get("HKIDCard"))
        if params.get("MLIDCard") is not None:
            self._MLIDCard = MLIDCard()
            self._MLIDCard._deserialize(params.get("MLIDCard"))
        if params.get("PhilippinesVoteID") is not None:
            self._PhilippinesVoteID = PhilippinesVoteID()
            self._PhilippinesVoteID._deserialize(params.get("PhilippinesVoteID"))
        if params.get("IndonesiaIDCard") is not None:
            self._IndonesiaIDCard = IndonesiaIDCard()
            self._IndonesiaIDCard._deserialize(params.get("IndonesiaIDCard"))
        if params.get("PhilippinesDrivingLicense") is not None:
            self._PhilippinesDrivingLicense = PhilippinesDrivingLicense()
            self._PhilippinesDrivingLicense._deserialize(params.get("PhilippinesDrivingLicense"))
        if params.get("PhilippinesTinID") is not None:
            self._PhilippinesTinID = PhilippinesTinID()
            self._PhilippinesTinID._deserialize(params.get("PhilippinesTinID"))
        if params.get("PhilippinesSSSID") is not None:
            self._PhilippinesSSSID = PhilippinesSSSID()
            self._PhilippinesSSSID._deserialize(params.get("PhilippinesSSSID"))
        if params.get("PhilippinesUMID") is not None:
            self._PhilippinesUMID = PhilippinesUMID()
            self._PhilippinesUMID._deserialize(params.get("PhilippinesUMID"))
        if params.get("InternationalIDPassport") is not None:
            self._InternationalIDPassport = InternationalIDPassport()
            self._InternationalIDPassport._deserialize(params.get("InternationalIDPassport"))
        if params.get("GeneralCard") is not None:
            self._GeneralCard = GeneralCard()
            self._GeneralCard._deserialize(params.get("GeneralCard"))
        if params.get("IndonesiaDrivingLicense") is not None:
            self._IndonesiaDrivingLicense = IndonesiaDrivingLicense()
            self._IndonesiaDrivingLicense._deserialize(params.get("IndonesiaDrivingLicense"))
        if params.get("ThailandIDCard") is not None:
            self._ThailandIDCard = ThailandIDCard()
            self._ThailandIDCard._deserialize(params.get("ThailandIDCard"))
        if params.get("SingaporeIDCard") is not None:
            self._SingaporeIDCard = SingaporeIDCard()
            self._SingaporeIDCard._deserialize(params.get("SingaporeIDCard"))
        if params.get("MacaoIDCard") is not None:
            self._MacaoIDCard = MacaoIDCard()
            self._MacaoIDCard._deserialize(params.get("MacaoIDCard"))
        if params.get("TaiWanIDCard") is not None:
            self._TaiWanIDCard = TaiWanIDCard()
            self._TaiWanIDCard._deserialize(params.get("TaiWanIDCard"))
        if params.get("JapanIDCard") is not None:
            self._JapanIDCard = JapanIDCard()
            self._JapanIDCard._deserialize(params.get("JapanIDCard"))
        if params.get("BangladeshIDCard") is not None:
            self._BangladeshIDCard = BangladeshIDCard()
            self._BangladeshIDCard._deserialize(params.get("BangladeshIDCard"))
        if params.get("NigeriaIDCard") is not None:
            self._NigeriaIDCard = NigeriaIDCard()
            self._NigeriaIDCard._deserialize(params.get("NigeriaIDCard"))
        if params.get("NigeriaDrivingLicense") is not None:
            self._NigeriaDrivingLicense = NigeriaDrivingLicense()
            self._NigeriaDrivingLicense._deserialize(params.get("NigeriaDrivingLicense"))
        if params.get("PakistanIDCard") is not None:
            self._PakistanIDCard = PakistanIDCard()
            self._PakistanIDCard._deserialize(params.get("PakistanIDCard"))
        if params.get("PakistanDrivingLicense") is not None:
            self._PakistanDrivingLicense = PakistanDrivingLicense()
            self._PakistanDrivingLicense._deserialize(params.get("PakistanDrivingLicense"))
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class CardVerifyResult(AbstractModel):
    r"""The OCR result of a user's identity document during the eKYC verification process.

    """

    def __init__(self):
        r"""
        :param _IsPass: Whether the authentication or OCR process is successful.
        :type IsPass: bool
        :param _IsEdit: Whether the user modified the card recognition result
        :type IsEdit: bool
        :param _CardVideo: The download URL of the video used for identity document verification, which is valid for 10 minutes. This parameter is returned only if video-based identity document verification is enabled.
Note: This field may return null, indicating that no valid value can be obtained.
        :type CardVideo: :class:`tencentcloud.faceid.v20180301.models.FileInfo`
        :param _CardImage: The download URL of the identity document image, which is valid for 10 minutes.
Note: This field may return null, indicating that no valid value can be obtained.
        :type CardImage: :class:`tencentcloud.faceid.v20180301.models.FileInfo`
        :param _CardInfoOcrJson: The OCR result (in JSON) of the identity document image. If verification or OCR fails, this parameter is left empty. The URL is valid for 10 minutes.
(1) Hong Kong (China) identity card
When the value of `IdCardType` is `HK`:
- CnName (string): Name in Chinese.
- EnName (string): Name in English.
- TelexCode (string): The code corresponding to the name in Chinese.
- Sex (string): Gender. Valid values: `M` (male) and `F` (female).
- Birthday (string): Date of birth.
- Permanent (int): Whether it is a permanent residence identity card. Valid values: `0` (non-permanent), `1` (permanent), and `-1` (unknown).
- IdNum (string): Identity card number.
- Symbol (string): The ID symbol below the date of birth, such as "***AZ".
- FirstIssueDate (string): Month and year of first registration.
- CurrentIssueDate (string): The date of latest issuance.

(2) Malaysian identity card
When the value of `IdCardType` is `ML`:
- Sex (string): Gender. Valid values: `LELAKI` (male) and `PEREMPUAN` (female).
- Birthday (string): Date of birth.
- ID (string): Identity card number.
- Name (string): Name.
- Address (string): Address.
- Type (string): Identity document type.

(3) Philippine identity document
When the value of `IdCardType` is `PhilippinesVoteID`:
- Birthday (string): Date of birth.
- Address (string): Address.
- LastName (string): Last name.
- FirstName (string): First name.
- VIN (string): Voter's identification number (VIN).
- CivilStatus (string): Civil status.
- Citizenship (string): Citizenship.
- PrecinctNo (string): Precinct.

When the value of `IdCardType` is `PhilippinesDrivingLicense`:
- Sex (string): Gender.
- Birthday (string): Date of birth.
- Name (string): Name.
- Address (string): Address.
- LastName (string): Last name.
- FirstName (string): First name.
- MiddleName (string): Middle name.
- Nationality (string): Nationality.
- LicenseNo (string): License number.
- ExpiresDate (string): Expiration date.
- AgencyCode (string): Agency code.

When the value of `IdCardType` is `PhilippinesTinID`:
- LicenseNumber (string): Tax identification number (TIN).
- FullName (string): Full name.
- Address (string): Address.
- Birthday (string): Date of birth.
- IssueDate (string): Issue date.

When the value of `IdCardType` is `PhilippinesSSSID`:
- LicenseNumber (string): Common reference number (CRN).
- FullName (string): Full name.
- Birthday (string): Date of birth.

When the value of `IdCardType` is `PhilippinesUMID`:
- Surname (string): Surname.
- MiddleName (string):Middle name.
- GivenName (string): Given name.
- Sex (string): Gender.
- Birthday (string): Date of birth.
- Address (string): Address.
- CRN (string): Common reference number (CRN).

(4) Indonesian identity card
When the value of `IdCardType` is `IndonesiaIDCard`:
- NIK (string): Single Identity Number.
- Nama (string): Full name.
- TempatTglLahir (string): Place and date of birth.
- JenisKelamin (string): Gender.
- GolDarah (string): Blood type.
- Alamat (string): Address.
- RTRW (string): Street.
- KelDesa (string): Village.
- Kecamatan (string): Region.
- Agama (string): Religion.
- StatusPerkawinan (string): Marital status.
- Perkerjaan (string): Occupation.
- KewargaNegaraan (string): Nationality.
- BerlakuHingga (string): Expiry date.
- IssuedDate (string): Issue date.

(5) A passport issued in Hong Kong (China) /Macao (China) /Taiwan (China) or other countries/regions
When the value of `IdCardType` is `MLIDPassport`:
- FullName (string): Full name.
- Surname (string): Surname.
- GivenName (string): Given name.
- Birthday (string): Date of birth.
- Sex (string): Gender. Valid values: `F` (female) and `M` (male).
- DateOfExpiration (string): Expiration date.
- IssuingCountry (string): Issuing country.
- NationalityCode (string): Country/region code.
Note: This field may return null, indicating that no valid values can be obtained.
        :type CardInfoOcrJson: :class:`tencentcloud.faceid.v20180301.models.FileInfo`
        :param _RequestId: The request ID of a single process.
        :type RequestId: str
        :param _CardInfo: The recognition results of ID card
        :type CardInfo: :class:`tencentcloud.faceid.v20180301.models.CardInfo`
        :param _NormalCardInfo: License OCR result
        :type NormalCardInfo: :class:`tencentcloud.faceid.v20180301.models.NormalCardInfo`
        :param _WarnCardInfos: Card warning information
-9101 Alarm for covered certificate,
-9102 Alarm for photocopied certificate,
-9103 Alarm for photographed certificate,
-9107 Alarm for reflective certificate,
-9108 Alarm for blurry image,
-9109 This capability is not enabled.
        :type WarnCardInfos: list of int
        :param _EditDetails: Details of the OCR modifications for this EKYC card, when the user manually modifies the card recognition results (IsEdit=true), EditDetails will return the modified fields. When IsEdit=false, EditDetails is empty.
        :type EditDetails: list of EditDetail
        """
        self._IsPass = None
        self._IsEdit = None
        self._CardVideo = None
        self._CardImage = None
        self._CardInfoOcrJson = None
        self._RequestId = None
        self._CardInfo = None
        self._NormalCardInfo = None
        self._WarnCardInfos = None
        self._EditDetails = None

    @property
    def IsPass(self):
        r"""Whether the authentication or OCR process is successful.
        :rtype: bool
        """
        return self._IsPass

    @IsPass.setter
    def IsPass(self, IsPass):
        self._IsPass = IsPass

    @property
    def IsEdit(self):
        r"""Whether the user modified the card recognition result
        :rtype: bool
        """
        return self._IsEdit

    @IsEdit.setter
    def IsEdit(self, IsEdit):
        self._IsEdit = IsEdit

    @property
    def CardVideo(self):
        r"""The download URL of the video used for identity document verification, which is valid for 10 minutes. This parameter is returned only if video-based identity document verification is enabled.
Note: This field may return null, indicating that no valid value can be obtained.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.FileInfo`
        """
        return self._CardVideo

    @CardVideo.setter
    def CardVideo(self, CardVideo):
        self._CardVideo = CardVideo

    @property
    def CardImage(self):
        r"""The download URL of the identity document image, which is valid for 10 minutes.
Note: This field may return null, indicating that no valid value can be obtained.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.FileInfo`
        """
        return self._CardImage

    @CardImage.setter
    def CardImage(self, CardImage):
        self._CardImage = CardImage

    @property
    def CardInfoOcrJson(self):
        r"""The OCR result (in JSON) of the identity document image. If verification or OCR fails, this parameter is left empty. The URL is valid for 10 minutes.
(1) Hong Kong (China) identity card
When the value of `IdCardType` is `HK`:
- CnName (string): Name in Chinese.
- EnName (string): Name in English.
- TelexCode (string): The code corresponding to the name in Chinese.
- Sex (string): Gender. Valid values: `M` (male) and `F` (female).
- Birthday (string): Date of birth.
- Permanent (int): Whether it is a permanent residence identity card. Valid values: `0` (non-permanent), `1` (permanent), and `-1` (unknown).
- IdNum (string): Identity card number.
- Symbol (string): The ID symbol below the date of birth, such as "***AZ".
- FirstIssueDate (string): Month and year of first registration.
- CurrentIssueDate (string): The date of latest issuance.

(2) Malaysian identity card
When the value of `IdCardType` is `ML`:
- Sex (string): Gender. Valid values: `LELAKI` (male) and `PEREMPUAN` (female).
- Birthday (string): Date of birth.
- ID (string): Identity card number.
- Name (string): Name.
- Address (string): Address.
- Type (string): Identity document type.

(3) Philippine identity document
When the value of `IdCardType` is `PhilippinesVoteID`:
- Birthday (string): Date of birth.
- Address (string): Address.
- LastName (string): Last name.
- FirstName (string): First name.
- VIN (string): Voter's identification number (VIN).
- CivilStatus (string): Civil status.
- Citizenship (string): Citizenship.
- PrecinctNo (string): Precinct.

When the value of `IdCardType` is `PhilippinesDrivingLicense`:
- Sex (string): Gender.
- Birthday (string): Date of birth.
- Name (string): Name.
- Address (string): Address.
- LastName (string): Last name.
- FirstName (string): First name.
- MiddleName (string): Middle name.
- Nationality (string): Nationality.
- LicenseNo (string): License number.
- ExpiresDate (string): Expiration date.
- AgencyCode (string): Agency code.

When the value of `IdCardType` is `PhilippinesTinID`:
- LicenseNumber (string): Tax identification number (TIN).
- FullName (string): Full name.
- Address (string): Address.
- Birthday (string): Date of birth.
- IssueDate (string): Issue date.

When the value of `IdCardType` is `PhilippinesSSSID`:
- LicenseNumber (string): Common reference number (CRN).
- FullName (string): Full name.
- Birthday (string): Date of birth.

When the value of `IdCardType` is `PhilippinesUMID`:
- Surname (string): Surname.
- MiddleName (string):Middle name.
- GivenName (string): Given name.
- Sex (string): Gender.
- Birthday (string): Date of birth.
- Address (string): Address.
- CRN (string): Common reference number (CRN).

(4) Indonesian identity card
When the value of `IdCardType` is `IndonesiaIDCard`:
- NIK (string): Single Identity Number.
- Nama (string): Full name.
- TempatTglLahir (string): Place and date of birth.
- JenisKelamin (string): Gender.
- GolDarah (string): Blood type.
- Alamat (string): Address.
- RTRW (string): Street.
- KelDesa (string): Village.
- Kecamatan (string): Region.
- Agama (string): Religion.
- StatusPerkawinan (string): Marital status.
- Perkerjaan (string): Occupation.
- KewargaNegaraan (string): Nationality.
- BerlakuHingga (string): Expiry date.
- IssuedDate (string): Issue date.

(5) A passport issued in Hong Kong (China) /Macao (China) /Taiwan (China) or other countries/regions
When the value of `IdCardType` is `MLIDPassport`:
- FullName (string): Full name.
- Surname (string): Surname.
- GivenName (string): Given name.
- Birthday (string): Date of birth.
- Sex (string): Gender. Valid values: `F` (female) and `M` (male).
- DateOfExpiration (string): Expiration date.
- IssuingCountry (string): Issuing country.
- NationalityCode (string): Country/region code.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.FileInfo`
        """
        return self._CardInfoOcrJson

    @CardInfoOcrJson.setter
    def CardInfoOcrJson(self, CardInfoOcrJson):
        self._CardInfoOcrJson = CardInfoOcrJson

    @property
    def RequestId(self):
        r"""The request ID of a single process.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId

    @property
    def CardInfo(self):
        warnings.warn("parameter `CardInfo` is deprecated", DeprecationWarning) 

        r"""The recognition results of ID card
        :rtype: :class:`tencentcloud.faceid.v20180301.models.CardInfo`
        """
        return self._CardInfo

    @CardInfo.setter
    def CardInfo(self, CardInfo):
        warnings.warn("parameter `CardInfo` is deprecated", DeprecationWarning) 

        self._CardInfo = CardInfo

    @property
    def NormalCardInfo(self):
        r"""License OCR result
        :rtype: :class:`tencentcloud.faceid.v20180301.models.NormalCardInfo`
        """
        return self._NormalCardInfo

    @NormalCardInfo.setter
    def NormalCardInfo(self, NormalCardInfo):
        self._NormalCardInfo = NormalCardInfo

    @property
    def WarnCardInfos(self):
        r"""Card warning information
-9101 Alarm for covered certificate,
-9102 Alarm for photocopied certificate,
-9103 Alarm for photographed certificate,
-9107 Alarm for reflective certificate,
-9108 Alarm for blurry image,
-9109 This capability is not enabled.
        :rtype: list of int
        """
        return self._WarnCardInfos

    @WarnCardInfos.setter
    def WarnCardInfos(self, WarnCardInfos):
        self._WarnCardInfos = WarnCardInfos

    @property
    def EditDetails(self):
        r"""Details of the OCR modifications for this EKYC card, when the user manually modifies the card recognition results (IsEdit=true), EditDetails will return the modified fields. When IsEdit=false, EditDetails is empty.
        :rtype: list of EditDetail
        """
        return self._EditDetails

    @EditDetails.setter
    def EditDetails(self, EditDetails):
        self._EditDetails = EditDetails


    def _deserialize(self, params):
        self._IsPass = params.get("IsPass")
        self._IsEdit = params.get("IsEdit")
        if params.get("CardVideo") is not None:
            self._CardVideo = FileInfo()
            self._CardVideo._deserialize(params.get("CardVideo"))
        if params.get("CardImage") is not None:
            self._CardImage = FileInfo()
            self._CardImage._deserialize(params.get("CardImage"))
        if params.get("CardInfoOcrJson") is not None:
            self._CardInfoOcrJson = FileInfo()
            self._CardInfoOcrJson._deserialize(params.get("CardInfoOcrJson"))
        self._RequestId = params.get("RequestId")
        if params.get("CardInfo") is not None:
            self._CardInfo = CardInfo()
            self._CardInfo._deserialize(params.get("CardInfo"))
        if params.get("NormalCardInfo") is not None:
            self._NormalCardInfo = NormalCardInfo()
            self._NormalCardInfo._deserialize(params.get("NormalCardInfo"))
        self._WarnCardInfos = params.get("WarnCardInfos")
        if params.get("EditDetails") is not None:
            self._EditDetails = []
            for item in params.get("EditDetails"):
                obj = EditDetail()
                obj._deserialize(item)
                self._EditDetails.append(obj)
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class CheckBankCardInformationRequest(AbstractModel):
    r"""CheckBankCardInformation request structure.

    """

    def __init__(self):
        r"""
        :param _BankCard: Bank card number.
        :type BankCard: str
        :param _Encryption: Sensitive data encryption info.
-Users with encryption requirements for incoming information (bank card number) can use this parameter. For details, please click the left-side link.
        :type Encryption: :class:`tencentcloud.faceid.v20180301.models.Encryption`
        """
        self._BankCard = None
        self._Encryption = None

    @property
    def BankCard(self):
        r"""Bank card number.
        :rtype: str
        """
        return self._BankCard

    @BankCard.setter
    def BankCard(self, BankCard):
        self._BankCard = BankCard

    @property
    def Encryption(self):
        r"""Sensitive data encryption info.
-Users with encryption requirements for incoming information (bank card number) can use this parameter. For details, please click the left-side link.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.Encryption`
        """
        return self._Encryption

    @Encryption.setter
    def Encryption(self, Encryption):
        self._Encryption = Encryption


    def _deserialize(self, params):
        self._BankCard = params.get("BankCard")
        if params.get("Encryption") is not None:
            self._Encryption = Encryption()
            self._Encryption._deserialize(params.get("Encryption"))
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class CheckBankCardInformationResponse(AbstractModel):
    r"""CheckBankCardInformation response structure.

    """

    def __init__(self):
        r"""
        :param _Result: Verification result code. Billing is as follows.
-Result code for charges
Query succeeded
-1: Not found
-5: Invalid card number

-Result code with no charge
-Verification Center Service is busy.
-3: Bank card not found.
-4: Authentication attempts exceeded the daily limit. Retry the next day.
-6: This bank card type is not currently supported

        :type Result: str
        :param _Description: Business result description.
        :type Description: str
        :param _AccountBank: Account opening bank.
        :type AccountBank: str
        :param _AccountType: Card type.
-Value range:
1: Debit card.
2: Credit card.
3: Prepaid card.
4: Credit card
        :type AccountType: int
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._Result = None
        self._Description = None
        self._AccountBank = None
        self._AccountType = None
        self._RequestId = None

    @property
    def Result(self):
        r"""Verification result code. Billing is as follows.
-Result code for charges
Query succeeded
-1: Not found
-5: Invalid card number

-Result code with no charge
-Verification Center Service is busy.
-3: Bank card not found.
-4: Authentication attempts exceeded the daily limit. Retry the next day.
-6: This bank card type is not currently supported

        :rtype: str
        """
        return self._Result

    @Result.setter
    def Result(self, Result):
        self._Result = Result

    @property
    def Description(self):
        r"""Business result description.
        :rtype: str
        """
        return self._Description

    @Description.setter
    def Description(self, Description):
        self._Description = Description

    @property
    def AccountBank(self):
        r"""Account opening bank.
        :rtype: str
        """
        return self._AccountBank

    @AccountBank.setter
    def AccountBank(self, AccountBank):
        self._AccountBank = AccountBank

    @property
    def AccountType(self):
        r"""Card type.
-Value range:
1: Debit card.
2: Credit card.
3: Prepaid card.
4: Credit card
        :rtype: int
        """
        return self._AccountType

    @AccountType.setter
    def AccountType(self, AccountType):
        self._AccountType = AccountType

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._Result = params.get("Result")
        self._Description = params.get("Description")
        self._AccountBank = params.get("AccountBank")
        self._AccountType = params.get("AccountType")
        self._RequestId = params.get("RequestId")


class CheckIdCardInformationRequest(AbstractModel):
    r"""CheckIdCardInformation request structure.

    """

    def __init__(self):
        r"""
        :param _ImageBase64: <p>Base64 value of the ID card portrait side.</p><ul><li>Supported image formats: PNG, JPG, JPEG. GIF format is not currently supported.</li><li>Supported image size: the downloaded image should be no more than 7M after Base64 encoding.</li><li>Please use the standard Base64 encoding method (with = padding). Refer to RFC4648 for coding specification.</li><li>Either ImageBase64 or ImageUrl must be provided. If both are provided, proceed to use parameters according to the priority of ImageUrl > ImageBase64.</li></ul>
        :type ImageBase64: str
        :param _ImageUrl: <p>Url address of the ID card portrait side</p><ul><li>Supported image formats: PNG, JPG, JPEG. GIF format is not currently supported.</li><li>Supported image size: The downloaded image after Base64 encoding is no more than 3M. Image download time is no more than 3 seconds.</li><li>Images stored in Tencent Cloud's Url can guarantee higher download speed and stability. It is recommended to store images in Tencent Cloud.</li><li>Speed and stability of non-Tencent Cloud Storage URLs may be impacted to a certain extent.</li></ul>
        :type ImageUrl: str
        :param _Config: <p>Configuration.</p><ul><li><p>All the following optional fields are bool type, default false.<br>CopyWarn, alarm for photocopy.<br>BorderCheckWarn, border and frame block alarm.<br>ReshootWarn, alarm for rephotographing.<br>DetectPsWarn, PS detection alarm (suspected PS traces).<br>TempIdWarn, temporary ID card alarm.<br>Quality, image Quality alarm (evaluates blurriness).</p></li><li><p>SDK configuration method for reference:<br>Config = Json.stringify({"CopyWarn":true,"ReshootWarn":true}).</p></li><li><p>API 3.0 Explorer setting method for reference:<br>Config = {"CopyWarn":true,"ReshootWarn":true}.</p></li></ul>
        :type Config: str
        :param _IsEncrypt: <p>Whether required to encrypt sensitive information in the response.</p><ul><li>Default false.</li><li>Sensitive information includes Response.IdNum and Response.Name.</li></ul>
        :type IsEncrypt: bool
        :param _IsEncryptResponse: <p>Whether required to encrypt the response body.</p>
        :type IsEncryptResponse: bool
        :param _Encryption: <p>Whether required to encrypt sensitive information in the response, need to be specified encryption algorithm Algorithm, initial vector for CBC encryption, and encrypted symmetric key.</p>
        :type Encryption: :class:`tencentcloud.faceid.v20180301.models.Encryption`
        """
        self._ImageBase64 = None
        self._ImageUrl = None
        self._Config = None
        self._IsEncrypt = None
        self._IsEncryptResponse = None
        self._Encryption = None

    @property
    def ImageBase64(self):
        r"""<p>Base64 value of the ID card portrait side.</p><ul><li>Supported image formats: PNG, JPG, JPEG. GIF format is not currently supported.</li><li>Supported image size: the downloaded image should be no more than 7M after Base64 encoding.</li><li>Please use the standard Base64 encoding method (with = padding). Refer to RFC4648 for coding specification.</li><li>Either ImageBase64 or ImageUrl must be provided. If both are provided, proceed to use parameters according to the priority of ImageUrl > ImageBase64.</li></ul>
        :rtype: str
        """
        return self._ImageBase64

    @ImageBase64.setter
    def ImageBase64(self, ImageBase64):
        self._ImageBase64 = ImageBase64

    @property
    def ImageUrl(self):
        r"""<p>Url address of the ID card portrait side</p><ul><li>Supported image formats: PNG, JPG, JPEG. GIF format is not currently supported.</li><li>Supported image size: The downloaded image after Base64 encoding is no more than 3M. Image download time is no more than 3 seconds.</li><li>Images stored in Tencent Cloud's Url can guarantee higher download speed and stability. It is recommended to store images in Tencent Cloud.</li><li>Speed and stability of non-Tencent Cloud Storage URLs may be impacted to a certain extent.</li></ul>
        :rtype: str
        """
        return self._ImageUrl

    @ImageUrl.setter
    def ImageUrl(self, ImageUrl):
        self._ImageUrl = ImageUrl

    @property
    def Config(self):
        r"""<p>Configuration.</p><ul><li><p>All the following optional fields are bool type, default false.<br>CopyWarn, alarm for photocopy.<br>BorderCheckWarn, border and frame block alarm.<br>ReshootWarn, alarm for rephotographing.<br>DetectPsWarn, PS detection alarm (suspected PS traces).<br>TempIdWarn, temporary ID card alarm.<br>Quality, image Quality alarm (evaluates blurriness).</p></li><li><p>SDK configuration method for reference:<br>Config = Json.stringify({"CopyWarn":true,"ReshootWarn":true}).</p></li><li><p>API 3.0 Explorer setting method for reference:<br>Config = {"CopyWarn":true,"ReshootWarn":true}.</p></li></ul>
        :rtype: str
        """
        return self._Config

    @Config.setter
    def Config(self, Config):
        self._Config = Config

    @property
    def IsEncrypt(self):
        r"""<p>Whether required to encrypt sensitive information in the response.</p><ul><li>Default false.</li><li>Sensitive information includes Response.IdNum and Response.Name.</li></ul>
        :rtype: bool
        """
        return self._IsEncrypt

    @IsEncrypt.setter
    def IsEncrypt(self, IsEncrypt):
        self._IsEncrypt = IsEncrypt

    @property
    def IsEncryptResponse(self):
        r"""<p>Whether required to encrypt the response body.</p>
        :rtype: bool
        """
        return self._IsEncryptResponse

    @IsEncryptResponse.setter
    def IsEncryptResponse(self, IsEncryptResponse):
        self._IsEncryptResponse = IsEncryptResponse

    @property
    def Encryption(self):
        r"""<p>Whether required to encrypt sensitive information in the response, need to be specified encryption algorithm Algorithm, initial vector for CBC encryption, and encrypted symmetric key.</p>
        :rtype: :class:`tencentcloud.faceid.v20180301.models.Encryption`
        """
        return self._Encryption

    @Encryption.setter
    def Encryption(self, Encryption):
        self._Encryption = Encryption


    def _deserialize(self, params):
        self._ImageBase64 = params.get("ImageBase64")
        self._ImageUrl = params.get("ImageUrl")
        self._Config = params.get("Config")
        self._IsEncrypt = params.get("IsEncrypt")
        self._IsEncryptResponse = params.get("IsEncryptResponse")
        if params.get("Encryption") is not None:
            self._Encryption = Encryption()
            self._Encryption._deserialize(params.get("Encryption"))
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class CheckIdCardInformationResponse(AbstractModel):
    r"""CheckIdCardInformation response structure.

    """

    def __init__(self):
        r"""
        :param _Sim: <p>Similarity. - Value ranges from 0.00 to 100.00. - Recommend threshold at least 70 to judge as same person, self-adjust based on specific scenario (pass rate for threshold 70 is 0.01%).</p>
        :type Sim: float
        :param _Result: <p>Business error code.</p><ul><li>Success case returns Success.</li><li>For error conditions, refer to the FailedOperation part in the error code list below.</li></ul>
        :type Result: str
        :param _Description: <p>Business result description.</p>
        :type Description: str
        :param _Name: <p>Name.</p>
        :type Name: str
        :param _Sex: <p>Gender.</p>
        :type Sex: str
        :param _Nation: <p>Ethnicity.</p>
        :type Nation: str
        :param _Birth: <p>Date of birth.</p>
        :type Birth: str
        :param _Address: <p>Address.</p>
        :type Address: str
        :param _IdNum: <p>Identity card number.</p>
        :type IdNum: str
        :param _Portrait: <p>The base64 encoding of the ID card portrait photo. If the image cropping fails, it will compare with the entire ID card and return null.</p>
        :type Portrait: str
        :param _Warnings: <p>Alarm information.</p><ul><li><p>When alarm information is configured in Config, portrait comparison will be disabled, Result returns an error (FailedOperation.OcrWarningOccurred) with this alarm information.</p></li><li><p>Code list of alarm codes and definition:<br>&#39;-9101&#39;: Incomplete ID card border alarm.<br>&#39;-9102&#39;: ID card copy alarm.<br>&#39;-9103&#39;: ID card photocopy alarm.<br>&#39;-9105&#39;: ID card frame occlusion alarm.<br>&#39;-9104&#39;: Temporary ID card alarm.<br>&#39;-9106&#39;: ID card PS alarm (suspected PS traces).<br>&#39;-8001&#39;: Warn about blurry images.</p></li><li><p>Multiple codes are separated by "|", such as "-9101|-9106|-9104".</p></li></ul>
        :type Warnings: str
        :param _Quality: <p>Image quality score.</p><ul><li>This parameter is significant only when warn about blurry images is configured in the request Config.</li><li>Value ranges from 0 to 100. The current default threshold is 50. A score lower than 50 triggers blurry image warnings.</li></ul>
        :type Quality: float
        :param _Encryption: <p>Sensitive data encryption info.</p>
Note: This field may return null, indicating that no valid values can be obtained.
        :type Encryption: :class:`tencentcloud.faceid.v20180301.models.Encryption`
        :param _EncryptedBody: <p>Encrypted data.</p>
        :type EncryptedBody: str
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._Sim = None
        self._Result = None
        self._Description = None
        self._Name = None
        self._Sex = None
        self._Nation = None
        self._Birth = None
        self._Address = None
        self._IdNum = None
        self._Portrait = None
        self._Warnings = None
        self._Quality = None
        self._Encryption = None
        self._EncryptedBody = None
        self._RequestId = None

    @property
    def Sim(self):
        r"""<p>Similarity. - Value ranges from 0.00 to 100.00. - Recommend threshold at least 70 to judge as same person, self-adjust based on specific scenario (pass rate for threshold 70 is 0.01%).</p>
        :rtype: float
        """
        return self._Sim

    @Sim.setter
    def Sim(self, Sim):
        self._Sim = Sim

    @property
    def Result(self):
        r"""<p>Business error code.</p><ul><li>Success case returns Success.</li><li>For error conditions, refer to the FailedOperation part in the error code list below.</li></ul>
        :rtype: str
        """
        return self._Result

    @Result.setter
    def Result(self, Result):
        self._Result = Result

    @property
    def Description(self):
        r"""<p>Business result description.</p>
        :rtype: str
        """
        return self._Description

    @Description.setter
    def Description(self, Description):
        self._Description = Description

    @property
    def Name(self):
        r"""<p>Name.</p>
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def Sex(self):
        r"""<p>Gender.</p>
        :rtype: str
        """
        return self._Sex

    @Sex.setter
    def Sex(self, Sex):
        self._Sex = Sex

    @property
    def Nation(self):
        r"""<p>Ethnicity.</p>
        :rtype: str
        """
        return self._Nation

    @Nation.setter
    def Nation(self, Nation):
        self._Nation = Nation

    @property
    def Birth(self):
        r"""<p>Date of birth.</p>
        :rtype: str
        """
        return self._Birth

    @Birth.setter
    def Birth(self, Birth):
        self._Birth = Birth

    @property
    def Address(self):
        r"""<p>Address.</p>
        :rtype: str
        """
        return self._Address

    @Address.setter
    def Address(self, Address):
        self._Address = Address

    @property
    def IdNum(self):
        r"""<p>Identity card number.</p>
        :rtype: str
        """
        return self._IdNum

    @IdNum.setter
    def IdNum(self, IdNum):
        self._IdNum = IdNum

    @property
    def Portrait(self):
        r"""<p>The base64 encoding of the ID card portrait photo. If the image cropping fails, it will compare with the entire ID card and return null.</p>
        :rtype: str
        """
        return self._Portrait

    @Portrait.setter
    def Portrait(self, Portrait):
        self._Portrait = Portrait

    @property
    def Warnings(self):
        r"""<p>Alarm information.</p><ul><li><p>When alarm information is configured in Config, portrait comparison will be disabled, Result returns an error (FailedOperation.OcrWarningOccurred) with this alarm information.</p></li><li><p>Code list of alarm codes and definition:<br>&#39;-9101&#39;: Incomplete ID card border alarm.<br>&#39;-9102&#39;: ID card copy alarm.<br>&#39;-9103&#39;: ID card photocopy alarm.<br>&#39;-9105&#39;: ID card frame occlusion alarm.<br>&#39;-9104&#39;: Temporary ID card alarm.<br>&#39;-9106&#39;: ID card PS alarm (suspected PS traces).<br>&#39;-8001&#39;: Warn about blurry images.</p></li><li><p>Multiple codes are separated by "|", such as "-9101|-9106|-9104".</p></li></ul>
        :rtype: str
        """
        return self._Warnings

    @Warnings.setter
    def Warnings(self, Warnings):
        self._Warnings = Warnings

    @property
    def Quality(self):
        r"""<p>Image quality score.</p><ul><li>This parameter is significant only when warn about blurry images is configured in the request Config.</li><li>Value ranges from 0 to 100. The current default threshold is 50. A score lower than 50 triggers blurry image warnings.</li></ul>
        :rtype: float
        """
        return self._Quality

    @Quality.setter
    def Quality(self, Quality):
        self._Quality = Quality

    @property
    def Encryption(self):
        r"""<p>Sensitive data encryption info.</p>
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.Encryption`
        """
        return self._Encryption

    @Encryption.setter
    def Encryption(self, Encryption):
        self._Encryption = Encryption

    @property
    def EncryptedBody(self):
        r"""<p>Encrypted data.</p>
        :rtype: str
        """
        return self._EncryptedBody

    @EncryptedBody.setter
    def EncryptedBody(self, EncryptedBody):
        self._EncryptedBody = EncryptedBody

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._Sim = params.get("Sim")
        self._Result = params.get("Result")
        self._Description = params.get("Description")
        self._Name = params.get("Name")
        self._Sex = params.get("Sex")
        self._Nation = params.get("Nation")
        self._Birth = params.get("Birth")
        self._Address = params.get("Address")
        self._IdNum = params.get("IdNum")
        self._Portrait = params.get("Portrait")
        self._Warnings = params.get("Warnings")
        self._Quality = params.get("Quality")
        if params.get("Encryption") is not None:
            self._Encryption = Encryption()
            self._Encryption._deserialize(params.get("Encryption"))
        self._EncryptedBody = params.get("EncryptedBody")
        self._RequestId = params.get("RequestId")


class CheckIdNameDateRequest(AbstractModel):
    r"""CheckIdNameDate request structure.

    """

    def __init__(self):
        r"""
        :param _Name: Name
        :type Name: str
        :param _IdCard: Identity card number.
        :type IdCard: str
        :param _ValidityBegin: ID card validity start time.
-Format: YYYYMMDD, for example: 20210701.
        :type ValidityBegin: str
        :param _ValidityEnd: ID card expiration time.
Format: YYYYMMDD, use "00000000" for long-term, for example: 20210701.
        :type ValidityEnd: str
        :param _Encryption: Sensitive data encryption info.
-Users with encryption requirements for incoming information (name, identity card number) can use this parameter. For details, please click the left-side link.
        :type Encryption: :class:`tencentcloud.faceid.v20180301.models.Encryption`
        """
        self._Name = None
        self._IdCard = None
        self._ValidityBegin = None
        self._ValidityEnd = None
        self._Encryption = None

    @property
    def Name(self):
        r"""Name
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def IdCard(self):
        r"""Identity card number.
        :rtype: str
        """
        return self._IdCard

    @IdCard.setter
    def IdCard(self, IdCard):
        self._IdCard = IdCard

    @property
    def ValidityBegin(self):
        r"""ID card validity start time.
-Format: YYYYMMDD, for example: 20210701.
        :rtype: str
        """
        return self._ValidityBegin

    @ValidityBegin.setter
    def ValidityBegin(self, ValidityBegin):
        self._ValidityBegin = ValidityBegin

    @property
    def ValidityEnd(self):
        r"""ID card expiration time.
Format: YYYYMMDD, use "00000000" for long-term, for example: 20210701.
        :rtype: str
        """
        return self._ValidityEnd

    @ValidityEnd.setter
    def ValidityEnd(self, ValidityEnd):
        self._ValidityEnd = ValidityEnd

    @property
    def Encryption(self):
        r"""Sensitive data encryption info.
-Users with encryption requirements for incoming information (name, identity card number) can use this parameter. For details, please click the left-side link.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.Encryption`
        """
        return self._Encryption

    @Encryption.setter
    def Encryption(self, Encryption):
        self._Encryption = Encryption


    def _deserialize(self, params):
        self._Name = params.get("Name")
        self._IdCard = params.get("IdCard")
        self._ValidityBegin = params.get("ValidityBegin")
        self._ValidityEnd = params.get("ValidityEnd")
        if params.get("Encryption") is not None:
            self._Encryption = Encryption()
            self._Encryption._deserialize(params.get("Encryption"))
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class CheckIdNameDateResponse(AbstractModel):
    r"""CheckIdNameDate response structure.

    """

    def __init__(self):
        r"""
        :param _Result: Verification result code. Billing is as follows.

-Result code for charges
Same.
-1: Inconsistent.

-Result code with no charge
-2: Invalid ID number (incorrect length or check digit).
-3: Invalid name (incorrect length or format).
-4: Invalid validity period (incorrect length, format, etc.).
-5: Invalid identity information.
-6: Document library service exception.
-7: No ID card record found in the document library.
-8: Authentication attempts exceeded the daily limit. Retry the next day.
        :type Result: str
        :param _Description: Business result description.
        :type Description: str
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._Result = None
        self._Description = None
        self._RequestId = None

    @property
    def Result(self):
        r"""Verification result code. Billing is as follows.

-Result code for charges
Same.
-1: Inconsistent.

-Result code with no charge
-2: Invalid ID number (incorrect length or check digit).
-3: Invalid name (incorrect length or format).
-4: Invalid validity period (incorrect length, format, etc.).
-5: Invalid identity information.
-6: Document library service exception.
-7: No ID card record found in the document library.
-8: Authentication attempts exceeded the daily limit. Retry the next day.
        :rtype: str
        """
        return self._Result

    @Result.setter
    def Result(self, Result):
        self._Result = Result

    @property
    def Description(self):
        r"""Business result description.
        :rtype: str
        """
        return self._Description

    @Description.setter
    def Description(self, Description):
        self._Description = Description

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._Result = params.get("Result")
        self._Description = params.get("Description")
        self._RequestId = params.get("RequestId")


class CompareFaceLivenessRequest(AbstractModel):
    r"""CompareFaceLiveness request structure.

    """

    def __init__(self):
        r"""
        :param _ImageBase64: Base64 string of the image for face comparison.
- The size of the Base64-encoded image data can be up to 3 MB. JPG and PNG formats are supported.
- Please use the standard Base64 encoding method (with = padding). Refer to RFC4648 for the encoding specification.
        :type ImageBase64: str
        :param _VideoBase64: Base64 string of the video for liveness detection.
- The size of the Base64-encoded video data can be up to 8 MB. MP4, AVI, and FLV formats are supported.
-Use standard Base64 encoding (with = padding), following RFC4648.
        :type VideoBase64: str
        :param _LivenessType: Liveness detection type.
-Values:
ACTION is action mode.
SILENT is silent mode.
-Choose one of the two modes to pass in.
        :type LivenessType: str
        :param _ValidateData: Control the action sequence. Action types include: 1 (open mouth), 2 (blink), 3 (nod), 4 (shake head). Supports one or two actions.
-Required when the LivenessType parameter is set to ACTION.
-Single action example: "1".
-Multiple actions parameter passing example: "4,2".
-When the LivenessType parameter is set to SILENT, leave it blank.
        :type ValidateData: str
        """
        self._ImageBase64 = None
        self._VideoBase64 = None
        self._LivenessType = None
        self._ValidateData = None

    @property
    def ImageBase64(self):
        r"""Base64 string of the image for face comparison.
- The size of the Base64-encoded image data can be up to 3 MB. JPG and PNG formats are supported.
- Please use the standard Base64 encoding method (with = padding). Refer to RFC4648 for the encoding specification.
        :rtype: str
        """
        return self._ImageBase64

    @ImageBase64.setter
    def ImageBase64(self, ImageBase64):
        self._ImageBase64 = ImageBase64

    @property
    def VideoBase64(self):
        r"""Base64 string of the video for liveness detection.
- The size of the Base64-encoded video data can be up to 8 MB. MP4, AVI, and FLV formats are supported.
-Use standard Base64 encoding (with = padding), following RFC4648.
        :rtype: str
        """
        return self._VideoBase64

    @VideoBase64.setter
    def VideoBase64(self, VideoBase64):
        self._VideoBase64 = VideoBase64

    @property
    def LivenessType(self):
        r"""Liveness detection type.
-Values:
ACTION is action mode.
SILENT is silent mode.
-Choose one of the two modes to pass in.
        :rtype: str
        """
        return self._LivenessType

    @LivenessType.setter
    def LivenessType(self, LivenessType):
        self._LivenessType = LivenessType

    @property
    def ValidateData(self):
        r"""Control the action sequence. Action types include: 1 (open mouth), 2 (blink), 3 (nod), 4 (shake head). Supports one or two actions.
-Required when the LivenessType parameter is set to ACTION.
-Single action example: "1".
-Multiple actions parameter passing example: "4,2".
-When the LivenessType parameter is set to SILENT, leave it blank.
        :rtype: str
        """
        return self._ValidateData

    @ValidateData.setter
    def ValidateData(self, ValidateData):
        self._ValidateData = ValidateData


    def _deserialize(self, params):
        self._ImageBase64 = params.get("ImageBase64")
        self._VideoBase64 = params.get("VideoBase64")
        self._LivenessType = params.get("LivenessType")
        self._ValidateData = params.get("ValidateData")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class CompareFaceLivenessResponse(AbstractModel):
    r"""CompareFaceLiveness response structure.

    """

    def __init__(self):
        r"""
        :param _Result: Business Error Codes.
-When the return value is "Success", it indicates that liveness detection and face comparison passed. Determined to be the same person.
-When the return value is "FailedOperation.CompareLowSimilarity", it indicates that liveness detection passed, but face comparison similarity is below 70. Determined not to be the same person.
-For other error cases, please refer to [Liveness Face Comparison (API only) Error Codes](https://www.tencentcloud.com/zh/document/product/1061/55390?lang=zh&pg=#97df7537-87fe-4266-87e9-02c816d41ee2)
        :type Result: str
        :param _Description: The service result description
        :type Description: str
        :param _Sim: This value indicates the similarity of face comparison. Value range: 0.00-100.00.
- The false acceptance rate for a threshold of 70 is 0.1%, and for a threshold of 80, it is 0.01%.
- This value is valid when the Result parameter is "Success" or "FailedOperation.CompareLowSimilarity".
        :type Sim: float
        :param _BestFrameBase64: The best screenshot photo from the video after verification, encoded in BASE64, in jpg format.
The optimal screenshot of the video after verification is the value encoded by BASE64, jpg format. 
Note: This field may return "null", indicating that no valid value can be obtained. 
Example values: "/9j/4AAQSk... (total length:142036)s97n//2Q=="
        :type BestFrameBase64: str
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._Result = None
        self._Description = None
        self._Sim = None
        self._BestFrameBase64 = None
        self._RequestId = None

    @property
    def Result(self):
        r"""Business Error Codes.
-When the return value is "Success", it indicates that liveness detection and face comparison passed. Determined to be the same person.
-When the return value is "FailedOperation.CompareLowSimilarity", it indicates that liveness detection passed, but face comparison similarity is below 70. Determined not to be the same person.
-For other error cases, please refer to [Liveness Face Comparison (API only) Error Codes](https://www.tencentcloud.com/zh/document/product/1061/55390?lang=zh&pg=#97df7537-87fe-4266-87e9-02c816d41ee2)
        :rtype: str
        """
        return self._Result

    @Result.setter
    def Result(self, Result):
        self._Result = Result

    @property
    def Description(self):
        r"""The service result description
        :rtype: str
        """
        return self._Description

    @Description.setter
    def Description(self, Description):
        self._Description = Description

    @property
    def Sim(self):
        r"""This value indicates the similarity of face comparison. Value range: 0.00-100.00.
- The false acceptance rate for a threshold of 70 is 0.1%, and for a threshold of 80, it is 0.01%.
- This value is valid when the Result parameter is "Success" or "FailedOperation.CompareLowSimilarity".
        :rtype: float
        """
        return self._Sim

    @Sim.setter
    def Sim(self, Sim):
        self._Sim = Sim

    @property
    def BestFrameBase64(self):
        r"""The best screenshot photo from the video after verification, encoded in BASE64, in jpg format.
The optimal screenshot of the video after verification is the value encoded by BASE64, jpg format. 
Note: This field may return "null", indicating that no valid value can be obtained. 
Example values: "/9j/4AAQSk... (total length:142036)s97n//2Q=="
        :rtype: str
        """
        return self._BestFrameBase64

    @BestFrameBase64.setter
    def BestFrameBase64(self, BestFrameBase64):
        self._BestFrameBase64 = BestFrameBase64

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._Result = params.get("Result")
        self._Description = params.get("Description")
        self._Sim = params.get("Sim")
        self._BestFrameBase64 = params.get("BestFrameBase64")
        self._RequestId = params.get("RequestId")


class CompareResult(AbstractModel):
    r"""The description of a single comparison result.

    """

    def __init__(self):
        r"""
        :param _ErrorCode: The final verification result code.
0: Succeeded.
1001: Failed to call the liveness engine.
1002: Suspected spoofed recording.
1004: Face detection failed.
1005: Liveness detection failed.
1201: Lighting is too dark or overexposed.
2004: The image passed in is too large or too small.
2012: Multiple faces detected.
2013: No face was detected, or the face detected was incomplete.
2014: The image resolution is too low or the quality does not meet the requirements.
2015: Face comparison failed.
2016: The similarity did not reach the standard passing threshold.
2017: Facial occlusion detected.
        :type ErrorCode: str
        :param _ErrorMsg: The description of the final verification result.
        :type ErrorMsg: str
        :param _LiveData: The liveness algorithm package generated during this SDK-based liveness detection.
        :type LiveData: :class:`tencentcloud.faceid.v20180301.models.FileInfo`
        :param _LiveVideo: The download URL of the video used for verification, which contains specific color reflection effects, is valid for 10 minutes.
        :type LiveVideo: :class:`tencentcloud.faceid.v20180301.models.FileInfo`
        :param _ActionVideo: Records the specific action performed by the user, used for AI Face Shield analysis.
        :type ActionVideo: :class:`tencentcloud.faceid.v20180301.models.FileInfo`
        :param _LiveErrorCode: The liveness detection result code.
0: Success.
1001: Failed to call the liveness detection engine.
1002: Suspected spoofed recording.
1004: Face detection failed.
1005: Liveness detection failed.
1201: Lighting is too dark or overexposed.

        :type LiveErrorCode: str
        :param _LiveErrorMsg: The description of the liveness detection result.
        :type LiveErrorMsg: str
        :param _BestFrame: The download URL of the face screenshot during verification, which is valid for 10 minutes.
Note: This field may return null, indicating that no valid value can be obtained.
        :type BestFrame: :class:`tencentcloud.faceid.v20180301.models.FileInfo`
        :param _ProfileImage: The download URL of the profile photo screenshot from the identity document, which is valid for 10 minutes.
        :type ProfileImage: :class:`tencentcloud.faceid.v20180301.models.FileInfo`
        :param _CompareErrorCode: The face comparison result code.
0: Success.
2004: The image passed in is too large or too small.
2012: Multiple faces detected.
2013: No face was detected, or the face detected was incomplete.
2014: The image resolution is too low or the quality does not meet the requirements.
2015: Face comparison failed.
2016: The similarity did not reach the standard passing threshold.
2017: Facial occlusion detected.
Note: This field may return null, indicating that no valid value can be obtained.
        :type CompareErrorCode: str
        :param _CompareErrorMsg: The description of the face comparison result.
Note: This field may return null, indicating that no valid values can be obtained.
        :type CompareErrorMsg: str
        :param _Sim: The similarity score of face comparison.
Note: This field may return null, indicating that no valid values can be obtained.
        :type Sim: float
        :param _IsNeedCharge: This parameter is disused.
        :type IsNeedCharge: bool
        :param _CardInfoInputJson: The identity document photo info edited by the user. Currently, this parameter is not applied.
Note: This field may return null, indicating that no valid values can be obtained.
        :type CardInfoInputJson: :class:`tencentcloud.faceid.v20180301.models.FileInfo`
        :param _RequestId: The request ID of this verification process.
        :type RequestId: str
        :param _LivenessInfoTag: Describes the detailed reason for the current liveness detection failure. Output only when SdkVersion is PLUS. Details are as follows:
01 - User kept eyes closed throughout the process.
02 - User failed to complete the specified action.
03 - Suspected photo replay attack.
04 - Suspected synthetic image.
05 - Suspected synthetic video.
06 - Suspected synthetic action.
07 - Suspected fraud template.
08 - Suspected watermark existence.
09 - Light verification failed.
10 - Face verification failed.
11 - Poor face quality.
12 - Unqualified collection quality.
13 - Suspected adversarial sample attack.
        :type LivenessInfoTag: list of str
        """
        self._ErrorCode = None
        self._ErrorMsg = None
        self._LiveData = None
        self._LiveVideo = None
        self._ActionVideo = None
        self._LiveErrorCode = None
        self._LiveErrorMsg = None
        self._BestFrame = None
        self._ProfileImage = None
        self._CompareErrorCode = None
        self._CompareErrorMsg = None
        self._Sim = None
        self._IsNeedCharge = None
        self._CardInfoInputJson = None
        self._RequestId = None
        self._LivenessInfoTag = None

    @property
    def ErrorCode(self):
        r"""The final verification result code.
0: Succeeded.
1001: Failed to call the liveness engine.
1002: Suspected spoofed recording.
1004: Face detection failed.
1005: Liveness detection failed.
1201: Lighting is too dark or overexposed.
2004: The image passed in is too large or too small.
2012: Multiple faces detected.
2013: No face was detected, or the face detected was incomplete.
2014: The image resolution is too low or the quality does not meet the requirements.
2015: Face comparison failed.
2016: The similarity did not reach the standard passing threshold.
2017: Facial occlusion detected.
        :rtype: str
        """
        return self._ErrorCode

    @ErrorCode.setter
    def ErrorCode(self, ErrorCode):
        self._ErrorCode = ErrorCode

    @property
    def ErrorMsg(self):
        r"""The description of the final verification result.
        :rtype: str
        """
        return self._ErrorMsg

    @ErrorMsg.setter
    def ErrorMsg(self, ErrorMsg):
        self._ErrorMsg = ErrorMsg

    @property
    def LiveData(self):
        r"""The liveness algorithm package generated during this SDK-based liveness detection.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.FileInfo`
        """
        return self._LiveData

    @LiveData.setter
    def LiveData(self, LiveData):
        self._LiveData = LiveData

    @property
    def LiveVideo(self):
        r"""The download URL of the video used for verification, which contains specific color reflection effects, is valid for 10 minutes.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.FileInfo`
        """
        return self._LiveVideo

    @LiveVideo.setter
    def LiveVideo(self, LiveVideo):
        self._LiveVideo = LiveVideo

    @property
    def ActionVideo(self):
        r"""Records the specific action performed by the user, used for AI Face Shield analysis.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.FileInfo`
        """
        return self._ActionVideo

    @ActionVideo.setter
    def ActionVideo(self, ActionVideo):
        self._ActionVideo = ActionVideo

    @property
    def LiveErrorCode(self):
        r"""The liveness detection result code.
0: Success.
1001: Failed to call the liveness detection engine.
1002: Suspected spoofed recording.
1004: Face detection failed.
1005: Liveness detection failed.
1201: Lighting is too dark or overexposed.

        :rtype: str
        """
        return self._LiveErrorCode

    @LiveErrorCode.setter
    def LiveErrorCode(self, LiveErrorCode):
        self._LiveErrorCode = LiveErrorCode

    @property
    def LiveErrorMsg(self):
        r"""The description of the liveness detection result.
        :rtype: str
        """
        return self._LiveErrorMsg

    @LiveErrorMsg.setter
    def LiveErrorMsg(self, LiveErrorMsg):
        self._LiveErrorMsg = LiveErrorMsg

    @property
    def BestFrame(self):
        r"""The download URL of the face screenshot during verification, which is valid for 10 minutes.
Note: This field may return null, indicating that no valid value can be obtained.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.FileInfo`
        """
        return self._BestFrame

    @BestFrame.setter
    def BestFrame(self, BestFrame):
        self._BestFrame = BestFrame

    @property
    def ProfileImage(self):
        r"""The download URL of the profile photo screenshot from the identity document, which is valid for 10 minutes.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.FileInfo`
        """
        return self._ProfileImage

    @ProfileImage.setter
    def ProfileImage(self, ProfileImage):
        self._ProfileImage = ProfileImage

    @property
    def CompareErrorCode(self):
        r"""The face comparison result code.
0: Success.
2004: The image passed in is too large or too small.
2012: Multiple faces detected.
2013: No face was detected, or the face detected was incomplete.
2014: The image resolution is too low or the quality does not meet the requirements.
2015: Face comparison failed.
2016: The similarity did not reach the standard passing threshold.
2017: Facial occlusion detected.
Note: This field may return null, indicating that no valid value can be obtained.
        :rtype: str
        """
        return self._CompareErrorCode

    @CompareErrorCode.setter
    def CompareErrorCode(self, CompareErrorCode):
        self._CompareErrorCode = CompareErrorCode

    @property
    def CompareErrorMsg(self):
        r"""The description of the face comparison result.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._CompareErrorMsg

    @CompareErrorMsg.setter
    def CompareErrorMsg(self, CompareErrorMsg):
        self._CompareErrorMsg = CompareErrorMsg

    @property
    def Sim(self):
        r"""The similarity score of face comparison.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: float
        """
        return self._Sim

    @Sim.setter
    def Sim(self, Sim):
        self._Sim = Sim

    @property
    def IsNeedCharge(self):
        r"""This parameter is disused.
        :rtype: bool
        """
        return self._IsNeedCharge

    @IsNeedCharge.setter
    def IsNeedCharge(self, IsNeedCharge):
        self._IsNeedCharge = IsNeedCharge

    @property
    def CardInfoInputJson(self):
        r"""The identity document photo info edited by the user. Currently, this parameter is not applied.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.FileInfo`
        """
        return self._CardInfoInputJson

    @CardInfoInputJson.setter
    def CardInfoInputJson(self, CardInfoInputJson):
        self._CardInfoInputJson = CardInfoInputJson

    @property
    def RequestId(self):
        r"""The request ID of this verification process.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId

    @property
    def LivenessInfoTag(self):
        r"""Describes the detailed reason for the current liveness detection failure. Output only when SdkVersion is PLUS. Details are as follows:
01 - User kept eyes closed throughout the process.
02 - User failed to complete the specified action.
03 - Suspected photo replay attack.
04 - Suspected synthetic image.
05 - Suspected synthetic video.
06 - Suspected synthetic action.
07 - Suspected fraud template.
08 - Suspected watermark existence.
09 - Light verification failed.
10 - Face verification failed.
11 - Poor face quality.
12 - Unqualified collection quality.
13 - Suspected adversarial sample attack.
        :rtype: list of str
        """
        return self._LivenessInfoTag

    @LivenessInfoTag.setter
    def LivenessInfoTag(self, LivenessInfoTag):
        self._LivenessInfoTag = LivenessInfoTag


    def _deserialize(self, params):
        self._ErrorCode = params.get("ErrorCode")
        self._ErrorMsg = params.get("ErrorMsg")
        if params.get("LiveData") is not None:
            self._LiveData = FileInfo()
            self._LiveData._deserialize(params.get("LiveData"))
        if params.get("LiveVideo") is not None:
            self._LiveVideo = FileInfo()
            self._LiveVideo._deserialize(params.get("LiveVideo"))
        if params.get("ActionVideo") is not None:
            self._ActionVideo = FileInfo()
            self._ActionVideo._deserialize(params.get("ActionVideo"))
        self._LiveErrorCode = params.get("LiveErrorCode")
        self._LiveErrorMsg = params.get("LiveErrorMsg")
        if params.get("BestFrame") is not None:
            self._BestFrame = FileInfo()
            self._BestFrame._deserialize(params.get("BestFrame"))
        if params.get("ProfileImage") is not None:
            self._ProfileImage = FileInfo()
            self._ProfileImage._deserialize(params.get("ProfileImage"))
        self._CompareErrorCode = params.get("CompareErrorCode")
        self._CompareErrorMsg = params.get("CompareErrorMsg")
        self._Sim = params.get("Sim")
        self._IsNeedCharge = params.get("IsNeedCharge")
        if params.get("CardInfoInputJson") is not None:
            self._CardInfoInputJson = FileInfo()
            self._CardInfoInputJson._deserialize(params.get("CardInfoInputJson"))
        self._RequestId = params.get("RequestId")
        self._LivenessInfoTag = params.get("LivenessInfoTag")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class CreateUploadUrlRequest(AbstractModel):
    r"""CreateUploadUrl request structure.

    """

    def __init__(self):
        r"""
        :param _TargetAction: Target API
        :type TargetAction: str
        """
        self._TargetAction = None

    @property
    def TargetAction(self):
        r"""Target API
        :rtype: str
        """
        return self._TargetAction

    @TargetAction.setter
    def TargetAction(self, TargetAction):
        self._TargetAction = TargetAction


    def _deserialize(self, params):
        self._TargetAction = params.get("TargetAction")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class CreateUploadUrlResponse(AbstractModel):
    r"""CreateUploadUrl response structure.

    """

    def __init__(self):
        r"""
        :param _UploadUrl: The URL for uploading contents with the `HTTP PUT` method.
        :type UploadUrl: str
        :param _ResourceUrl: The resource URL obtained after this upload is completed and to be passed in where it is required later.
        :type ResourceUrl: str
        :param _ExpiredTimestamp: The point in time when the upload/download link expires, which is a 10-bit Unix timestamp.
        :type ExpiredTimestamp: int
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._UploadUrl = None
        self._ResourceUrl = None
        self._ExpiredTimestamp = None
        self._RequestId = None

    @property
    def UploadUrl(self):
        r"""The URL for uploading contents with the `HTTP PUT` method.
        :rtype: str
        """
        return self._UploadUrl

    @UploadUrl.setter
    def UploadUrl(self, UploadUrl):
        self._UploadUrl = UploadUrl

    @property
    def ResourceUrl(self):
        r"""The resource URL obtained after this upload is completed and to be passed in where it is required later.
        :rtype: str
        """
        return self._ResourceUrl

    @ResourceUrl.setter
    def ResourceUrl(self, ResourceUrl):
        self._ResourceUrl = ResourceUrl

    @property
    def ExpiredTimestamp(self):
        r"""The point in time when the upload/download link expires, which is a 10-bit Unix timestamp.
        :rtype: int
        """
        return self._ExpiredTimestamp

    @ExpiredTimestamp.setter
    def ExpiredTimestamp(self, ExpiredTimestamp):
        self._ExpiredTimestamp = ExpiredTimestamp

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._UploadUrl = params.get("UploadUrl")
        self._ResourceUrl = params.get("ResourceUrl")
        self._ExpiredTimestamp = params.get("ExpiredTimestamp")
        self._RequestId = params.get("RequestId")


class DetectAIFakeFacesRequest(AbstractModel):
    r"""DetectAIFakeFaces request structure.

    """

    def __init__(self):
        r"""
        :param _FaceInput: Enter the image or video with a face to be detected, in base64 encoding. Base64 value of the image: The overall image resolution is recommended to be 480x640, and the face size is 100X100 or larger; The image data size after Base64 encoding does not exceed 3M, and only supports jpg and png formats. Please use standard Base64 encoding (use = for padding). Refer to RFC4648 for encoding specifications. Base64 value of the video: The size after Base64 encoding does not exceed 8M, and supports mp4, avi, and flv formats. Please use standard Base64 encoding (use = for padding). Refer to RFC4648 for encoding specifications. The maximum supported video length is 20s, and the recommended length is 2 to 5s. The recommended video resolution is 480x640, and the frame rate is between 25fps and 30fps.
        :type FaceInput: str
        :param _FaceInputType: The type of input is 1- The input type is a picture 2- The input type is a video Others - Return error code InvalidParameter
        :type FaceInputType: int
        :param _Encryption: Whether the request information needs to be fully encrypted; Supported encryption algorithms: AES-256-CBC, SM4-GCM; Users with encryption requirements can use this parameter, for details, please click the link on the left.
        :type Encryption: :class:`tencentcloud.faceid.v20180301.models.Encryption`
        :param _EncryptedBody: Encrypted ciphertext; The data format before encryption is as follows:{"FaceInput":"AAAAA","FaceInputType":1}
        :type EncryptedBody: str
        """
        self._FaceInput = None
        self._FaceInputType = None
        self._Encryption = None
        self._EncryptedBody = None

    @property
    def FaceInput(self):
        r"""Enter the image or video with a face to be detected, in base64 encoding. Base64 value of the image: The overall image resolution is recommended to be 480x640, and the face size is 100X100 or larger; The image data size after Base64 encoding does not exceed 3M, and only supports jpg and png formats. Please use standard Base64 encoding (use = for padding). Refer to RFC4648 for encoding specifications. Base64 value of the video: The size after Base64 encoding does not exceed 8M, and supports mp4, avi, and flv formats. Please use standard Base64 encoding (use = for padding). Refer to RFC4648 for encoding specifications. The maximum supported video length is 20s, and the recommended length is 2 to 5s. The recommended video resolution is 480x640, and the frame rate is between 25fps and 30fps.
        :rtype: str
        """
        return self._FaceInput

    @FaceInput.setter
    def FaceInput(self, FaceInput):
        self._FaceInput = FaceInput

    @property
    def FaceInputType(self):
        r"""The type of input is 1- The input type is a picture 2- The input type is a video Others - Return error code InvalidParameter
        :rtype: int
        """
        return self._FaceInputType

    @FaceInputType.setter
    def FaceInputType(self, FaceInputType):
        self._FaceInputType = FaceInputType

    @property
    def Encryption(self):
        r"""Whether the request information needs to be fully encrypted; Supported encryption algorithms: AES-256-CBC, SM4-GCM; Users with encryption requirements can use this parameter, for details, please click the link on the left.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.Encryption`
        """
        return self._Encryption

    @Encryption.setter
    def Encryption(self, Encryption):
        self._Encryption = Encryption

    @property
    def EncryptedBody(self):
        r"""Encrypted ciphertext; The data format before encryption is as follows:{"FaceInput":"AAAAA","FaceInputType":1}
        :rtype: str
        """
        return self._EncryptedBody

    @EncryptedBody.setter
    def EncryptedBody(self, EncryptedBody):
        self._EncryptedBody = EncryptedBody


    def _deserialize(self, params):
        self._FaceInput = params.get("FaceInput")
        self._FaceInputType = params.get("FaceInputType")
        if params.get("Encryption") is not None:
            self._Encryption = Encryption()
            self._Encryption._deserialize(params.get("Encryption"))
        self._EncryptedBody = params.get("EncryptedBody")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DetectAIFakeFacesResponse(AbstractModel):
    r"""DetectAIFakeFaces response structure.

    """

    def __init__(self):
        r"""
        :param _AttackRiskLevel: Whether the detected image is an attack: Low: No attack risk Mid: Moderately suspected attack High: Highly suspected attack
        :type AttackRiskLevel: str
        :param _AttackRiskDetailList: A list of suspected attack traces detected. Note: When no attack traces are detected, an empty array is returned. This parameter is only used as a reference for result judgment. In actual applications, it is still recommended to use the result of AttackRiskLevel.
        :type AttackRiskDetailList: list of AttackRiskDetail
        :param _ExtraInfo: Additional Information
        :type ExtraInfo: :class:`tencentcloud.faceid.v20180301.models.ExtraInfo`
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._AttackRiskLevel = None
        self._AttackRiskDetailList = None
        self._ExtraInfo = None
        self._RequestId = None

    @property
    def AttackRiskLevel(self):
        r"""Whether the detected image is an attack: Low: No attack risk Mid: Moderately suspected attack High: Highly suspected attack
        :rtype: str
        """
        return self._AttackRiskLevel

    @AttackRiskLevel.setter
    def AttackRiskLevel(self, AttackRiskLevel):
        self._AttackRiskLevel = AttackRiskLevel

    @property
    def AttackRiskDetailList(self):
        r"""A list of suspected attack traces detected. Note: When no attack traces are detected, an empty array is returned. This parameter is only used as a reference for result judgment. In actual applications, it is still recommended to use the result of AttackRiskLevel.
        :rtype: list of AttackRiskDetail
        """
        return self._AttackRiskDetailList

    @AttackRiskDetailList.setter
    def AttackRiskDetailList(self, AttackRiskDetailList):
        self._AttackRiskDetailList = AttackRiskDetailList

    @property
    def ExtraInfo(self):
        r"""Additional Information
        :rtype: :class:`tencentcloud.faceid.v20180301.models.ExtraInfo`
        """
        return self._ExtraInfo

    @ExtraInfo.setter
    def ExtraInfo(self, ExtraInfo):
        self._ExtraInfo = ExtraInfo

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._AttackRiskLevel = params.get("AttackRiskLevel")
        if params.get("AttackRiskDetailList") is not None:
            self._AttackRiskDetailList = []
            for item in params.get("AttackRiskDetailList"):
                obj = AttackRiskDetail()
                obj._deserialize(item)
                self._AttackRiskDetailList.append(obj)
        if params.get("ExtraInfo") is not None:
            self._ExtraInfo = ExtraInfo()
            self._ExtraInfo._deserialize(params.get("ExtraInfo"))
        self._RequestId = params.get("RequestId")


class DetectReflectLivenessAndCompareRequest(AbstractModel):
    r"""DetectReflectLivenessAndCompare request structure.

    """

    def __init__(self):
        r"""
        :param _LiveDataUrl: URL of the liveness detection data package generated by the SDK
        :type LiveDataUrl: str
        :param _LiveDataMd5: MD5 hash value (32-bit) of the liveness detection data package generated by the SDK, which is used to verify the LiveData consistency.
        :type LiveDataMd5: str
        :param _ImageUrl: URL of the target image for comparison
        :type ImageUrl: str
        :param _ImageMd5: MD5 hash value (32-bit) of the target image for comparison, which is used to verify the `Image` consistency.
        :type ImageMd5: str
        """
        self._LiveDataUrl = None
        self._LiveDataMd5 = None
        self._ImageUrl = None
        self._ImageMd5 = None

    @property
    def LiveDataUrl(self):
        r"""URL of the liveness detection data package generated by the SDK
        :rtype: str
        """
        return self._LiveDataUrl

    @LiveDataUrl.setter
    def LiveDataUrl(self, LiveDataUrl):
        self._LiveDataUrl = LiveDataUrl

    @property
    def LiveDataMd5(self):
        r"""MD5 hash value (32-bit) of the liveness detection data package generated by the SDK, which is used to verify the LiveData consistency.
        :rtype: str
        """
        return self._LiveDataMd5

    @LiveDataMd5.setter
    def LiveDataMd5(self, LiveDataMd5):
        self._LiveDataMd5 = LiveDataMd5

    @property
    def ImageUrl(self):
        r"""URL of the target image for comparison
        :rtype: str
        """
        return self._ImageUrl

    @ImageUrl.setter
    def ImageUrl(self, ImageUrl):
        self._ImageUrl = ImageUrl

    @property
    def ImageMd5(self):
        r"""MD5 hash value (32-bit) of the target image for comparison, which is used to verify the `Image` consistency.
        :rtype: str
        """
        return self._ImageMd5

    @ImageMd5.setter
    def ImageMd5(self, ImageMd5):
        self._ImageMd5 = ImageMd5


    def _deserialize(self, params):
        self._LiveDataUrl = params.get("LiveDataUrl")
        self._LiveDataMd5 = params.get("LiveDataMd5")
        self._ImageUrl = params.get("ImageUrl")
        self._ImageMd5 = params.get("ImageMd5")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class DetectReflectLivenessAndCompareResponse(AbstractModel):
    r"""DetectReflectLivenessAndCompare response structure.

    """

    def __init__(self):
        r"""
        :param _BestFrameUrl: Temporary URL of the best screenshot (.jpg) of the video after successful verification. Both the screenshot and the URL are valid for two hours only, so you need to download the screenshot within this period.
        :type BestFrameUrl: str
        :param _BestFrameMd5: MD5 hash value (32-bit) of the best screenshot of the video after successful verification, which is used to verify the `BestFrame` consistency.
        :type BestFrameMd5: str
        :param _Result: Service error code. `Success` will be returned for success. For error information, see the `FailedOperation` section in the error code list below.
        :type Result: str
        :param _Description: Service result description
        :type Description: str
        :param _Sim: Similarity. Value range: [0.00, 100.00]. As a recommendation, when the similarity is greater than or equal to 70, it can be determined that the two faces are of the same person. You can adjust the threshold according to your specific scenario (the FAR at the threshold of 70 is 0.1%, and FAR at the threshold of 80 is 0.01%).
        :type Sim: float
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._BestFrameUrl = None
        self._BestFrameMd5 = None
        self._Result = None
        self._Description = None
        self._Sim = None
        self._RequestId = None

    @property
    def BestFrameUrl(self):
        r"""Temporary URL of the best screenshot (.jpg) of the video after successful verification. Both the screenshot and the URL are valid for two hours only, so you need to download the screenshot within this period.
        :rtype: str
        """
        return self._BestFrameUrl

    @BestFrameUrl.setter
    def BestFrameUrl(self, BestFrameUrl):
        self._BestFrameUrl = BestFrameUrl

    @property
    def BestFrameMd5(self):
        r"""MD5 hash value (32-bit) of the best screenshot of the video after successful verification, which is used to verify the `BestFrame` consistency.
        :rtype: str
        """
        return self._BestFrameMd5

    @BestFrameMd5.setter
    def BestFrameMd5(self, BestFrameMd5):
        self._BestFrameMd5 = BestFrameMd5

    @property
    def Result(self):
        r"""Service error code. `Success` will be returned for success. For error information, see the `FailedOperation` section in the error code list below.
        :rtype: str
        """
        return self._Result

    @Result.setter
    def Result(self, Result):
        self._Result = Result

    @property
    def Description(self):
        r"""Service result description
        :rtype: str
        """
        return self._Description

    @Description.setter
    def Description(self, Description):
        self._Description = Description

    @property
    def Sim(self):
        r"""Similarity. Value range: [0.00, 100.00]. As a recommendation, when the similarity is greater than or equal to 70, it can be determined that the two faces are of the same person. You can adjust the threshold according to your specific scenario (the FAR at the threshold of 70 is 0.1%, and FAR at the threshold of 80 is 0.01%).
        :rtype: float
        """
        return self._Sim

    @Sim.setter
    def Sim(self, Sim):
        self._Sim = Sim

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._BestFrameUrl = params.get("BestFrameUrl")
        self._BestFrameMd5 = params.get("BestFrameMd5")
        self._Result = params.get("Result")
        self._Description = params.get("Description")
        self._Sim = params.get("Sim")
        self._RequestId = params.get("RequestId")


class EditDetail(AbstractModel):
    r"""

    """

    def __init__(self):
        r"""
        :param _FieldName: Modified Field Name
        :type FieldName: str
        :param _OriginalFieldValue: Value of the field before modification, the original OCR result
        :type OriginalFieldValue: str
        :param _RevisedFieldValue: Value of the field after modification,the user's manually entered result
        :type RevisedFieldValue: str
        """
        self._FieldName = None
        self._OriginalFieldValue = None
        self._RevisedFieldValue = None

    @property
    def FieldName(self):
        r"""Modified Field Name
        :rtype: str
        """
        return self._FieldName

    @FieldName.setter
    def FieldName(self, FieldName):
        self._FieldName = FieldName

    @property
    def OriginalFieldValue(self):
        r"""Value of the field before modification, the original OCR result
        :rtype: str
        """
        return self._OriginalFieldValue

    @OriginalFieldValue.setter
    def OriginalFieldValue(self, OriginalFieldValue):
        self._OriginalFieldValue = OriginalFieldValue

    @property
    def RevisedFieldValue(self):
        r"""Value of the field after modification,the user's manually entered result
        :rtype: str
        """
        return self._RevisedFieldValue

    @RevisedFieldValue.setter
    def RevisedFieldValue(self, RevisedFieldValue):
        self._RevisedFieldValue = RevisedFieldValue


    def _deserialize(self, params):
        self._FieldName = params.get("FieldName")
        self._OriginalFieldValue = params.get("OriginalFieldValue")
        self._RevisedFieldValue = params.get("RevisedFieldValue")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class Encryption(AbstractModel):
    r"""

    """

    def __init__(self):
        r"""
        :param _EncryptList: <p>When using the encryption service, fill in the field to be encrypted. One or more encrypted fields can be auto-filled in this API.</p>
Note: This field may return null, indicating that no valid values can be obtained.
        :type EncryptList: list of str
        :param _CiphertextBlob: <p>Encrypted symmetric key. See the <a href="https://www.tencentcloud.com/document/product/1007/47180?from_cn_redirect=1">data encryption</a> document for key generation and use.</p>
Note: This field may return null, indicating that no valid values can be obtained.
        :type CiphertextBlob: str
        :param _Iv: <p>Users with encryption requirements import the initial vector for CBC encryption (custom string with a length of 16 characters).</p>
Note: This field may return null, indicating that no valid values can be obtained.
        :type Iv: str
        :param _Algorithm: <p>Encryption algorithm (supports 'AES-256-CBC', 'SM4-GCM'). Defaults to 'AES-256-CBC' if not specified.</p>
Note: This field may return null, indicating that no valid values can be obtained.
        :type Algorithm: str
        :param _TagList: <p>Message digest generated by the SM4-GCM algorithm (used when verifying message integrity)</p>
Note: This field may return null, indicating that no valid values can be obtained.
        :type TagList: list of str
        """
        self._EncryptList = None
        self._CiphertextBlob = None
        self._Iv = None
        self._Algorithm = None
        self._TagList = None

    @property
    def EncryptList(self):
        r"""<p>When using the encryption service, fill in the field to be encrypted. One or more encrypted fields can be auto-filled in this API.</p>
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: list of str
        """
        return self._EncryptList

    @EncryptList.setter
    def EncryptList(self, EncryptList):
        self._EncryptList = EncryptList

    @property
    def CiphertextBlob(self):
        r"""<p>Encrypted symmetric key. See the <a href="https://www.tencentcloud.com/document/product/1007/47180?from_cn_redirect=1">data encryption</a> document for key generation and use.</p>
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._CiphertextBlob

    @CiphertextBlob.setter
    def CiphertextBlob(self, CiphertextBlob):
        self._CiphertextBlob = CiphertextBlob

    @property
    def Iv(self):
        r"""<p>Users with encryption requirements import the initial vector for CBC encryption (custom string with a length of 16 characters).</p>
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Iv

    @Iv.setter
    def Iv(self, Iv):
        self._Iv = Iv

    @property
    def Algorithm(self):
        r"""<p>Encryption algorithm (supports 'AES-256-CBC', 'SM4-GCM'). Defaults to 'AES-256-CBC' if not specified.</p>
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Algorithm

    @Algorithm.setter
    def Algorithm(self, Algorithm):
        self._Algorithm = Algorithm

    @property
    def TagList(self):
        r"""<p>Message digest generated by the SM4-GCM algorithm (used when verifying message integrity)</p>
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: list of str
        """
        return self._TagList

    @TagList.setter
    def TagList(self, TagList):
        self._TagList = TagList


    def _deserialize(self, params):
        self._EncryptList = params.get("EncryptList")
        self._CiphertextBlob = params.get("CiphertextBlob")
        self._Iv = params.get("Iv")
        self._Algorithm = params.get("Algorithm")
        self._TagList = params.get("TagList")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ExtraInfo(AbstractModel):
    r"""

    """

    def __init__(self):
        r"""
        :param _RetrievalLivenessExtraInfo: 
        :type RetrievalLivenessExtraInfo: list of RetrievalLivenessExtraInfo
        """
        self._RetrievalLivenessExtraInfo = None

    @property
    def RetrievalLivenessExtraInfo(self):
        r"""
        :rtype: list of RetrievalLivenessExtraInfo
        """
        return self._RetrievalLivenessExtraInfo

    @RetrievalLivenessExtraInfo.setter
    def RetrievalLivenessExtraInfo(self, RetrievalLivenessExtraInfo):
        self._RetrievalLivenessExtraInfo = RetrievalLivenessExtraInfo


    def _deserialize(self, params):
        if params.get("RetrievalLivenessExtraInfo") is not None:
            self._RetrievalLivenessExtraInfo = []
            for item in params.get("RetrievalLivenessExtraInfo"):
                obj = RetrievalLivenessExtraInfo()
                obj._deserialize(item)
                self._RetrievalLivenessExtraInfo.append(obj)
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class FileInfo(AbstractModel):
    r"""The description of a file, including a download URL and the MD5 checksum and size of the file.

    """

    def __init__(self):
        r"""
        :param _Url: The URL for downloading the file
        :type Url: str
        :param _MD5: The 32-bit MD5 checksum of the file
        :type MD5: str
        :param _Size: The file size
        :type Size: int
        """
        self._Url = None
        self._MD5 = None
        self._Size = None

    @property
    def Url(self):
        r"""The URL for downloading the file
        :rtype: str
        """
        return self._Url

    @Url.setter
    def Url(self, Url):
        self._Url = Url

    @property
    def MD5(self):
        r"""The 32-bit MD5 checksum of the file
        :rtype: str
        """
        return self._MD5

    @MD5.setter
    def MD5(self, MD5):
        self._MD5 = MD5

    @property
    def Size(self):
        r"""The file size
        :rtype: int
        """
        return self._Size

    @Size.setter
    def Size(self, Size):
        self._Size = Size


    def _deserialize(self, params):
        self._Url = params.get("Url")
        self._MD5 = params.get("MD5")
        self._Size = params.get("Size")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class GeneralCard(AbstractModel):
    r"""General liscense information.

    """

    def __init__(self):
        r"""
        :param _LicenseNumber: License number
Note: This field may return null, indicating that no valid values can be obtained.
        :type LicenseNumber: str
        :param _PersonalNumber: Personal number, which is returned when it is a passport
Note: This field may return null, indicating that no valid values can be obtained.
        :type PersonalNumber: str
        :param _PassportCodeFirst: The first line of passport machine reading code
Note: This field may return null, indicating that no valid values can be obtained.
        :type PassportCodeFirst: str
        :param _PassportCodeSecond: The first line of passport machine reading code
Note: This field may return null, indicating that no valid values can be obtained.
        :type PassportCodeSecond: str
        :param _ExpirationDate: Date of expiry in the format of YYYY-MM-DD
Note: This field may return null, indicating that no valid values can be obtained.
        :type ExpirationDate: str
        :param _DueDate: Valid date in the format of YYYY-MM-DD
Note: This field may return null, indicating that no valid values can be obtained.
        :type DueDate: str
        :param _IssuedDate: Date of issue in the format of YYYY-MM-DD
Note: This field may return null, indicating that no valid values can be obtained.
        :type IssuedDate: str
        :param _IssuedAuthority: Issuing authority
Note: This field may return null, indicating that no valid values can be obtained.
        :type IssuedAuthority: str
        :param _IssuedCountry: Issuing country, which is returned following the ISO 3166 country coding specification
Note: This field may return null, indicating that no valid values can be obtained.
Example: MYS
        :type IssuedCountry: str
        :param _FullName: Full Name
Note: This field may return null, indicating that no valid values can be obtained.
        :type FullName: str
        :param _FirstName: First name
Note: This field may return null, indicating that no valid values can be obtained.
        :type FirstName: str
        :param _LastName: Last name
Note: This field may return null, indicating that no valid values can be obtained.
        :type LastName: str
        :param _Sex: Gender on the license
- M: male
- F: female
- X: other gender
Note: This field may return null, indicating that no valid values can be obtained.
Example: M
        :type Sex: str
        :param _Age: Age. 0 indicates that no valid information is obtained.
Example: 0
        :type Age: str
        :param _Birthday: Birthday
Note: This field may return null, indicating that no valid values can be obtained.
        :type Birthday: str
        :param _BirthPlace: Birth place
Note: This field may return null, indicating that no valid values can be obtained.
        :type BirthPlace: str
        :param _Nationality: Nationality, which is returned following the ISO 3166 country coding specification
Note: This field may return null, indicating that no valid values can be obtained.
Example: IND
        :type Nationality: str
        :param _RegistrationNumber: Registration number
Note: This field may return null, indicating that no valid values can be obtained.
        :type RegistrationNumber: str
        :param _Address: Address
Note: This field may return null, indicating that no valid values can be obtained.
        :type Address: :class:`tencentcloud.faceid.v20180301.models.Address`
        :param _FullNameLocal: Localized name.
        :type FullNameLocal: str
        :param _FirstNameLocal: Localization.
        :type FirstNameLocal: str
        :param _LastNameLocal: Localized surname.
        :type LastNameLocal: str
        """
        self._LicenseNumber = None
        self._PersonalNumber = None
        self._PassportCodeFirst = None
        self._PassportCodeSecond = None
        self._ExpirationDate = None
        self._DueDate = None
        self._IssuedDate = None
        self._IssuedAuthority = None
        self._IssuedCountry = None
        self._FullName = None
        self._FirstName = None
        self._LastName = None
        self._Sex = None
        self._Age = None
        self._Birthday = None
        self._BirthPlace = None
        self._Nationality = None
        self._RegistrationNumber = None
        self._Address = None
        self._FullNameLocal = None
        self._FirstNameLocal = None
        self._LastNameLocal = None

    @property
    def LicenseNumber(self):
        r"""License number
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._LicenseNumber

    @LicenseNumber.setter
    def LicenseNumber(self, LicenseNumber):
        self._LicenseNumber = LicenseNumber

    @property
    def PersonalNumber(self):
        r"""Personal number, which is returned when it is a passport
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._PersonalNumber

    @PersonalNumber.setter
    def PersonalNumber(self, PersonalNumber):
        self._PersonalNumber = PersonalNumber

    @property
    def PassportCodeFirst(self):
        r"""The first line of passport machine reading code
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._PassportCodeFirst

    @PassportCodeFirst.setter
    def PassportCodeFirst(self, PassportCodeFirst):
        self._PassportCodeFirst = PassportCodeFirst

    @property
    def PassportCodeSecond(self):
        r"""The first line of passport machine reading code
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._PassportCodeSecond

    @PassportCodeSecond.setter
    def PassportCodeSecond(self, PassportCodeSecond):
        self._PassportCodeSecond = PassportCodeSecond

    @property
    def ExpirationDate(self):
        r"""Date of expiry in the format of YYYY-MM-DD
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._ExpirationDate

    @ExpirationDate.setter
    def ExpirationDate(self, ExpirationDate):
        self._ExpirationDate = ExpirationDate

    @property
    def DueDate(self):
        r"""Valid date in the format of YYYY-MM-DD
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._DueDate

    @DueDate.setter
    def DueDate(self, DueDate):
        self._DueDate = DueDate

    @property
    def IssuedDate(self):
        r"""Date of issue in the format of YYYY-MM-DD
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._IssuedDate

    @IssuedDate.setter
    def IssuedDate(self, IssuedDate):
        self._IssuedDate = IssuedDate

    @property
    def IssuedAuthority(self):
        r"""Issuing authority
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._IssuedAuthority

    @IssuedAuthority.setter
    def IssuedAuthority(self, IssuedAuthority):
        self._IssuedAuthority = IssuedAuthority

    @property
    def IssuedCountry(self):
        r"""Issuing country, which is returned following the ISO 3166 country coding specification
Note: This field may return null, indicating that no valid values can be obtained.
Example: MYS
        :rtype: str
        """
        return self._IssuedCountry

    @IssuedCountry.setter
    def IssuedCountry(self, IssuedCountry):
        self._IssuedCountry = IssuedCountry

    @property
    def FullName(self):
        r"""Full Name
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._FullName

    @FullName.setter
    def FullName(self, FullName):
        self._FullName = FullName

    @property
    def FirstName(self):
        r"""First name
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._FirstName

    @FirstName.setter
    def FirstName(self, FirstName):
        self._FirstName = FirstName

    @property
    def LastName(self):
        r"""Last name
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._LastName

    @LastName.setter
    def LastName(self, LastName):
        self._LastName = LastName

    @property
    def Sex(self):
        r"""Gender on the license
- M: male
- F: female
- X: other gender
Note: This field may return null, indicating that no valid values can be obtained.
Example: M
        :rtype: str
        """
        return self._Sex

    @Sex.setter
    def Sex(self, Sex):
        self._Sex = Sex

    @property
    def Age(self):
        r"""Age. 0 indicates that no valid information is obtained.
Example: 0
        :rtype: str
        """
        return self._Age

    @Age.setter
    def Age(self, Age):
        self._Age = Age

    @property
    def Birthday(self):
        r"""Birthday
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Birthday

    @Birthday.setter
    def Birthday(self, Birthday):
        self._Birthday = Birthday

    @property
    def BirthPlace(self):
        r"""Birth place
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._BirthPlace

    @BirthPlace.setter
    def BirthPlace(self, BirthPlace):
        self._BirthPlace = BirthPlace

    @property
    def Nationality(self):
        r"""Nationality, which is returned following the ISO 3166 country coding specification
Note: This field may return null, indicating that no valid values can be obtained.
Example: IND
        :rtype: str
        """
        return self._Nationality

    @Nationality.setter
    def Nationality(self, Nationality):
        self._Nationality = Nationality

    @property
    def RegistrationNumber(self):
        r"""Registration number
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._RegistrationNumber

    @RegistrationNumber.setter
    def RegistrationNumber(self, RegistrationNumber):
        self._RegistrationNumber = RegistrationNumber

    @property
    def Address(self):
        r"""Address
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.Address`
        """
        return self._Address

    @Address.setter
    def Address(self, Address):
        self._Address = Address

    @property
    def FullNameLocal(self):
        r"""Localized name.
        :rtype: str
        """
        return self._FullNameLocal

    @FullNameLocal.setter
    def FullNameLocal(self, FullNameLocal):
        self._FullNameLocal = FullNameLocal

    @property
    def FirstNameLocal(self):
        r"""Localization.
        :rtype: str
        """
        return self._FirstNameLocal

    @FirstNameLocal.setter
    def FirstNameLocal(self, FirstNameLocal):
        self._FirstNameLocal = FirstNameLocal

    @property
    def LastNameLocal(self):
        r"""Localized surname.
        :rtype: str
        """
        return self._LastNameLocal

    @LastNameLocal.setter
    def LastNameLocal(self, LastNameLocal):
        self._LastNameLocal = LastNameLocal


    def _deserialize(self, params):
        self._LicenseNumber = params.get("LicenseNumber")
        self._PersonalNumber = params.get("PersonalNumber")
        self._PassportCodeFirst = params.get("PassportCodeFirst")
        self._PassportCodeSecond = params.get("PassportCodeSecond")
        self._ExpirationDate = params.get("ExpirationDate")
        self._DueDate = params.get("DueDate")
        self._IssuedDate = params.get("IssuedDate")
        self._IssuedAuthority = params.get("IssuedAuthority")
        self._IssuedCountry = params.get("IssuedCountry")
        self._FullName = params.get("FullName")
        self._FirstName = params.get("FirstName")
        self._LastName = params.get("LastName")
        self._Sex = params.get("Sex")
        self._Age = params.get("Age")
        self._Birthday = params.get("Birthday")
        self._BirthPlace = params.get("BirthPlace")
        self._Nationality = params.get("Nationality")
        self._RegistrationNumber = params.get("RegistrationNumber")
        if params.get("Address") is not None:
            self._Address = Address()
            self._Address._deserialize(params.get("Address"))
        self._FullNameLocal = params.get("FullNameLocal")
        self._FirstNameLocal = params.get("FirstNameLocal")
        self._LastNameLocal = params.get("LastNameLocal")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class GenerateReflectSequenceRequest(AbstractModel):
    r"""GenerateReflectSequence request structure.

    """

    def __init__(self):
        r"""
        :param _DeviceDataUrl: The resource URL of the data package generated by the SDK.
        :type DeviceDataUrl: str
        :param _DeviceDataMd5: The MD5 hash value of the data package generated by the SDK.
        :type DeviceDataMd5: str
        :param _SecurityLevel: 1 - silent
2 - blinking
3 - light
4 - blinking + light (default)
        :type SecurityLevel: str
        """
        self._DeviceDataUrl = None
        self._DeviceDataMd5 = None
        self._SecurityLevel = None

    @property
    def DeviceDataUrl(self):
        r"""The resource URL of the data package generated by the SDK.
        :rtype: str
        """
        return self._DeviceDataUrl

    @DeviceDataUrl.setter
    def DeviceDataUrl(self, DeviceDataUrl):
        self._DeviceDataUrl = DeviceDataUrl

    @property
    def DeviceDataMd5(self):
        r"""The MD5 hash value of the data package generated by the SDK.
        :rtype: str
        """
        return self._DeviceDataMd5

    @DeviceDataMd5.setter
    def DeviceDataMd5(self, DeviceDataMd5):
        self._DeviceDataMd5 = DeviceDataMd5

    @property
    def SecurityLevel(self):
        r"""1 - silent
2 - blinking
3 - light
4 - blinking + light (default)
        :rtype: str
        """
        return self._SecurityLevel

    @SecurityLevel.setter
    def SecurityLevel(self, SecurityLevel):
        self._SecurityLevel = SecurityLevel


    def _deserialize(self, params):
        self._DeviceDataUrl = params.get("DeviceDataUrl")
        self._DeviceDataMd5 = params.get("DeviceDataMd5")
        self._SecurityLevel = params.get("SecurityLevel")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class GenerateReflectSequenceResponse(AbstractModel):
    r"""GenerateReflectSequence response structure.

    """

    def __init__(self):
        r"""
        :param _ReflectSequenceUrl: The resource URL of the light sequence, which needs to be downloaded and passed through to the SDK to start the eKYC process.
        :type ReflectSequenceUrl: str
        :param _ReflectSequenceMd5: The MD5 hash value of the light sequence, which is used to check whether the light sequence is altered.
        :type ReflectSequenceMd5: str
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._ReflectSequenceUrl = None
        self._ReflectSequenceMd5 = None
        self._RequestId = None

    @property
    def ReflectSequenceUrl(self):
        r"""The resource URL of the light sequence, which needs to be downloaded and passed through to the SDK to start the eKYC process.
        :rtype: str
        """
        return self._ReflectSequenceUrl

    @ReflectSequenceUrl.setter
    def ReflectSequenceUrl(self, ReflectSequenceUrl):
        self._ReflectSequenceUrl = ReflectSequenceUrl

    @property
    def ReflectSequenceMd5(self):
        r"""The MD5 hash value of the light sequence, which is used to check whether the light sequence is altered.
        :rtype: str
        """
        return self._ReflectSequenceMd5

    @ReflectSequenceMd5.setter
    def ReflectSequenceMd5(self, ReflectSequenceMd5):
        self._ReflectSequenceMd5 = ReflectSequenceMd5

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._ReflectSequenceUrl = params.get("ReflectSequenceUrl")
        self._ReflectSequenceMd5 = params.get("ReflectSequenceMd5")
        self._RequestId = params.get("RequestId")


class GetFaceIdResultIntlRequest(AbstractModel):
    r"""GetFaceIdResultIntl request structure.

    """

    def __init__(self):
        r"""
        :param _SdkToken: The ID of the SDK-based selfie verification process, which is generated when the `GetFaceIdTokenIntl` API is called.	
        :type SdkToken: str
        """
        self._SdkToken = None

    @property
    def SdkToken(self):
        r"""The ID of the SDK-based selfie verification process, which is generated when the `GetFaceIdTokenIntl` API is called.	
        :rtype: str
        """
        return self._SdkToken

    @SdkToken.setter
    def SdkToken(self, SdkToken):
        self._SdkToken = SdkToken


    def _deserialize(self, params):
        self._SdkToken = params.get("SdkToken")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class GetFaceIdResultIntlResponse(AbstractModel):
    r"""GetFaceIdResultIntl response structure.

    """

    def __init__(self):
        r"""
        :param _Result: The return code of the verification result.
0: Success.
1001: Failed to call the liveness engine.
1002: Suspected spoofed recording.
1004: Face detection failed.
1005: Liveness detection failed.
1201: Lighting is too dark or overexposed.
2004: The image passed in is too large or too small.
2012: Multiple faces detected.
2013: No face was detected, or the face detected was incomplete.
2014: The image resolution is too low or the quality does not meet the requirements.
2015: Face comparison failed.
2016: The similarity did not reach the standard passing threshold.
2017: Facial occlusion detected.
-999: The verification process wasn't finished.
        :type Result: str
        :param _Description: The description of the verification result.
        :type Description: str
        :param _BestFrame: The best frame screenshot (in Base64) obtained during the verification.
        :type BestFrame: str
        :param _Video: The video file (Base64) for verification.Used for verification, contains specific color reflection effects.
        :type Video: str
        :param _ActionVideo: Records the specific action performed by the user, used for AI Face Shield analysis.
        :type ActionVideo: str
        :param _Similarity: The similarity, with a value range of 0-100. A greater value indicates higher similarity. This parameter is returned only in the `compare` (selfie verification) mode.
Note: The Similarity metric is exclusively valid for "compare" mode. In "liveness" mode, the returned Similarity value (0.0) is non-significant and should be ignored.
        :type Similarity: float
        :param _Extra: The pass-through parameter.
Note: This field may return null, indicating that no valid values can be obtained.
        :type Extra: str
        :param _DeviceInfoLevel: Describe the risk level of the device where the current request is located, with a total of 4 levels. The details are as follows:
1 - Secure
2 - Low Risk
3 - Medium Risk
4 - High Risk
Empty - Risk level not obtained.
Only returned for the Enhance and Plus version, with the default value being empty.
        :type DeviceInfoLevel: str
        :param _LivenessInfoTag: Describes the detailed reason for the current liveness detection failure. Output only when SdkVersion is PLUS or PRO. Details are as follows:
01 - User kept eyes closed throughout the process.
02 - User failed to complete the specified action.
03 - Suspected photo replay attack.
04 - Suspected synthetic image.
05 - Suspected synthetic video.
06 - Suspected synthetic action.
07 - Suspected fraud template.
08 - Suspected watermark existence.
09 - Light verification failed.
10 - Face verification failed.
11 - Poor face quality.
12 - Unqualified collection quality.
13 - Suspected adversarial sample attack.
        :type LivenessInfoTag: list of str
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._Result = None
        self._Description = None
        self._BestFrame = None
        self._Video = None
        self._ActionVideo = None
        self._Similarity = None
        self._Extra = None
        self._DeviceInfoLevel = None
        self._LivenessInfoTag = None
        self._RequestId = None

    @property
    def Result(self):
        r"""The return code of the verification result.
0: Success.
1001: Failed to call the liveness engine.
1002: Suspected spoofed recording.
1004: Face detection failed.
1005: Liveness detection failed.
1201: Lighting is too dark or overexposed.
2004: The image passed in is too large or too small.
2012: Multiple faces detected.
2013: No face was detected, or the face detected was incomplete.
2014: The image resolution is too low or the quality does not meet the requirements.
2015: Face comparison failed.
2016: The similarity did not reach the standard passing threshold.
2017: Facial occlusion detected.
-999: The verification process wasn't finished.
        :rtype: str
        """
        return self._Result

    @Result.setter
    def Result(self, Result):
        self._Result = Result

    @property
    def Description(self):
        r"""The description of the verification result.
        :rtype: str
        """
        return self._Description

    @Description.setter
    def Description(self, Description):
        self._Description = Description

    @property
    def BestFrame(self):
        r"""The best frame screenshot (in Base64) obtained during the verification.
        :rtype: str
        """
        return self._BestFrame

    @BestFrame.setter
    def BestFrame(self, BestFrame):
        self._BestFrame = BestFrame

    @property
    def Video(self):
        r"""The video file (Base64) for verification.Used for verification, contains specific color reflection effects.
        :rtype: str
        """
        return self._Video

    @Video.setter
    def Video(self, Video):
        self._Video = Video

    @property
    def ActionVideo(self):
        r"""Records the specific action performed by the user, used for AI Face Shield analysis.
        :rtype: str
        """
        return self._ActionVideo

    @ActionVideo.setter
    def ActionVideo(self, ActionVideo):
        self._ActionVideo = ActionVideo

    @property
    def Similarity(self):
        r"""The similarity, with a value range of 0-100. A greater value indicates higher similarity. This parameter is returned only in the `compare` (selfie verification) mode.
Note: The Similarity metric is exclusively valid for "compare" mode. In "liveness" mode, the returned Similarity value (0.0) is non-significant and should be ignored.
        :rtype: float
        """
        return self._Similarity

    @Similarity.setter
    def Similarity(self, Similarity):
        self._Similarity = Similarity

    @property
    def Extra(self):
        r"""The pass-through parameter.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Extra

    @Extra.setter
    def Extra(self, Extra):
        self._Extra = Extra

    @property
    def DeviceInfoLevel(self):
        r"""Describe the risk level of the device where the current request is located, with a total of 4 levels. The details are as follows:
1 - Secure
2 - Low Risk
3 - Medium Risk
4 - High Risk
Empty - Risk level not obtained.
Only returned for the Enhance and Plus version, with the default value being empty.
        :rtype: str
        """
        return self._DeviceInfoLevel

    @DeviceInfoLevel.setter
    def DeviceInfoLevel(self, DeviceInfoLevel):
        self._DeviceInfoLevel = DeviceInfoLevel

    @property
    def LivenessInfoTag(self):
        r"""Describes the detailed reason for the current liveness detection failure. Output only when SdkVersion is PLUS or PRO. Details are as follows:
01 - User kept eyes closed throughout the process.
02 - User failed to complete the specified action.
03 - Suspected photo replay attack.
04 - Suspected synthetic image.
05 - Suspected synthetic video.
06 - Suspected synthetic action.
07 - Suspected fraud template.
08 - Suspected watermark existence.
09 - Light verification failed.
10 - Face verification failed.
11 - Poor face quality.
12 - Unqualified collection quality.
13 - Suspected adversarial sample attack.
        :rtype: list of str
        """
        return self._LivenessInfoTag

    @LivenessInfoTag.setter
    def LivenessInfoTag(self, LivenessInfoTag):
        self._LivenessInfoTag = LivenessInfoTag

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._Result = params.get("Result")
        self._Description = params.get("Description")
        self._BestFrame = params.get("BestFrame")
        self._Video = params.get("Video")
        self._ActionVideo = params.get("ActionVideo")
        self._Similarity = params.get("Similarity")
        self._Extra = params.get("Extra")
        self._DeviceInfoLevel = params.get("DeviceInfoLevel")
        self._LivenessInfoTag = params.get("LivenessInfoTag")
        self._RequestId = params.get("RequestId")


class GetFaceIdTokenIntlRequest(AbstractModel):
    r"""GetFaceIdTokenIntl request structure.

    """

    def __init__(self):
        r"""
        :param _CheckMode: The detection mode. Valid values:
`liveness`: Liveness detection only.
`compare`: Selfie Verification(liveness detection and face comparison).
Default value: `liveness`.
        :type CheckMode: str
        :param _SecureLevel: The verification security level. Valid values:
`1`: Video-based liveness detection.
`2`: Motion-based liveness detection.
`3`: Reflection-based liveness detection.
`4`: Motion- and reflection-based liveness detection.
Default value: `4`.
        :type SecureLevel: str
        :param _Image: The photo (in Base64) to compare. This parameter is required when the value of `CheckMode` is `compare`.
        :type Image: str
        :param _Extra: The pass-through parameter, which can be omitted if there are no special requirements.
        :type Extra: str
        :param _ActionList: This interface is used to control th action sequences.
Action types are as follows:
"blink"
"mouth"
"nod"
"shake"
You can choose 1-2 actions out of the four.
Single action example: "blink"
Multiple action example: "blink,mouth"
The default value is blink. The different action types passed in this parameter take effect only when the SecurityLevel is 2 or 4; otherwise, the interface reports an error.
        :type ActionList: str
        :param _SdkVersion: BASIC: Basic version (Default).
ENHANCE: Enhance version, enable additional output of device risk level field.
PRO: Pro version, enable additional output of attack type fields.
PLUS: Plus version, enable additional output of device risk level and attack type fields.
Please contact us to access enhance version & plus version.	
        :type SdkVersion: str
        """
        self._CheckMode = None
        self._SecureLevel = None
        self._Image = None
        self._Extra = None
        self._ActionList = None
        self._SdkVersion = None

    @property
    def CheckMode(self):
        r"""The detection mode. Valid values:
`liveness`: Liveness detection only.
`compare`: Selfie Verification(liveness detection and face comparison).
Default value: `liveness`.
        :rtype: str
        """
        return self._CheckMode

    @CheckMode.setter
    def CheckMode(self, CheckMode):
        self._CheckMode = CheckMode

    @property
    def SecureLevel(self):
        r"""The verification security level. Valid values:
`1`: Video-based liveness detection.
`2`: Motion-based liveness detection.
`3`: Reflection-based liveness detection.
`4`: Motion- and reflection-based liveness detection.
Default value: `4`.
        :rtype: str
        """
        return self._SecureLevel

    @SecureLevel.setter
    def SecureLevel(self, SecureLevel):
        self._SecureLevel = SecureLevel

    @property
    def Image(self):
        r"""The photo (in Base64) to compare. This parameter is required when the value of `CheckMode` is `compare`.
        :rtype: str
        """
        return self._Image

    @Image.setter
    def Image(self, Image):
        self._Image = Image

    @property
    def Extra(self):
        r"""The pass-through parameter, which can be omitted if there are no special requirements.
        :rtype: str
        """
        return self._Extra

    @Extra.setter
    def Extra(self, Extra):
        self._Extra = Extra

    @property
    def ActionList(self):
        r"""This interface is used to control th action sequences.
Action types are as follows:
"blink"
"mouth"
"nod"
"shake"
You can choose 1-2 actions out of the four.
Single action example: "blink"
Multiple action example: "blink,mouth"
The default value is blink. The different action types passed in this parameter take effect only when the SecurityLevel is 2 or 4; otherwise, the interface reports an error.
        :rtype: str
        """
        return self._ActionList

    @ActionList.setter
    def ActionList(self, ActionList):
        self._ActionList = ActionList

    @property
    def SdkVersion(self):
        r"""BASIC: Basic version (Default).
ENHANCE: Enhance version, enable additional output of device risk level field.
PRO: Pro version, enable additional output of attack type fields.
PLUS: Plus version, enable additional output of device risk level and attack type fields.
Please contact us to access enhance version & plus version.	
        :rtype: str
        """
        return self._SdkVersion

    @SdkVersion.setter
    def SdkVersion(self, SdkVersion):
        self._SdkVersion = SdkVersion


    def _deserialize(self, params):
        self._CheckMode = params.get("CheckMode")
        self._SecureLevel = params.get("SecureLevel")
        self._Image = params.get("Image")
        self._Extra = params.get("Extra")
        self._ActionList = params.get("ActionList")
        self._SdkVersion = params.get("SdkVersion")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class GetFaceIdTokenIntlResponse(AbstractModel):
    r"""GetFaceIdTokenIntl response structure.

    """

    def __init__(self):
        r"""
        :param _SdkToken: The SDK token, which is used throughout the verification process and to get the verification result.
        :type SdkToken: str
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._SdkToken = None
        self._RequestId = None

    @property
    def SdkToken(self):
        r"""The SDK token, which is used throughout the verification process and to get the verification result.
        :rtype: str
        """
        return self._SdkToken

    @SdkToken.setter
    def SdkToken(self, SdkToken):
        self._SdkToken = SdkToken

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._SdkToken = params.get("SdkToken")
        self._RequestId = params.get("RequestId")


class GetLivenessResultRequest(AbstractModel):
    r"""GetLivenessResult request structure.

    """

    def __init__(self):
        r"""
        :param _SdkToken: The token used to identify an SDK-based verification process.
        :type SdkToken: str
        """
        self._SdkToken = None

    @property
    def SdkToken(self):
        r"""The token used to identify an SDK-based verification process.
        :rtype: str
        """
        return self._SdkToken

    @SdkToken.setter
    def SdkToken(self, SdkToken):
        self._SdkToken = SdkToken


    def _deserialize(self, params):
        self._SdkToken = params.get("SdkToken")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class GetLivenessResultResponse(AbstractModel):
    r"""GetLivenessResult response structure.

    """

    def __init__(self):
        r"""
        :param _Result: The final verification result.
        :type Result: str
        :param _Description: The description of the final verification result.
        :type Description: str
        :param _BestFrame: The face screenshot.
        :type BestFrame: :class:`tencentcloud.faceid.v20180301.models.FileInfo`
        :param _Video: The video for the detection.
        :type Video: :class:`tencentcloud.faceid.v20180301.models.FileInfo`
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._Result = None
        self._Description = None
        self._BestFrame = None
        self._Video = None
        self._RequestId = None

    @property
    def Result(self):
        r"""The final verification result.
        :rtype: str
        """
        return self._Result

    @Result.setter
    def Result(self, Result):
        self._Result = Result

    @property
    def Description(self):
        r"""The description of the final verification result.
        :rtype: str
        """
        return self._Description

    @Description.setter
    def Description(self, Description):
        self._Description = Description

    @property
    def BestFrame(self):
        r"""The face screenshot.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.FileInfo`
        """
        return self._BestFrame

    @BestFrame.setter
    def BestFrame(self, BestFrame):
        self._BestFrame = BestFrame

    @property
    def Video(self):
        r"""The video for the detection.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.FileInfo`
        """
        return self._Video

    @Video.setter
    def Video(self, Video):
        self._Video = Video

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._Result = params.get("Result")
        self._Description = params.get("Description")
        if params.get("BestFrame") is not None:
            self._BestFrame = FileInfo()
            self._BestFrame._deserialize(params.get("BestFrame"))
        if params.get("Video") is not None:
            self._Video = FileInfo()
            self._Video._deserialize(params.get("Video"))
        self._RequestId = params.get("RequestId")


class GetSdkVerificationResultRequest(AbstractModel):
    r"""GetSdkVerificationResult request structure.

    """

    def __init__(self):
        r"""
        :param _SdkToken: The token used to identify an SDK-based verification process. 
        :type SdkToken: str
        """
        self._SdkToken = None

    @property
    def SdkToken(self):
        r"""The token used to identify an SDK-based verification process. 
        :rtype: str
        """
        return self._SdkToken

    @SdkToken.setter
    def SdkToken(self, SdkToken):
        self._SdkToken = SdkToken


    def _deserialize(self, params):
        self._SdkToken = params.get("SdkToken")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class GetSdkVerificationResultResponse(AbstractModel):
    r"""GetSdkVerificationResult response structure.

    """

    def __init__(self):
        r"""
        :param _Result: The result code of the verification result.
        :type Result: str
        :param _Description: The verification result description.
        :type Description: str
        :param _ChargeCount: The charge count.
        :type ChargeCount: int
        :param _CardVerifyResults: The results of multiple OCR processes (in order). The result of the final process is used as the valid result.
        :type CardVerifyResults: list of CardVerifyResult
        :param _CompareResults: The results of multiple liveness detection processes (in order). The result of the final process is used as the valid result.
        :type CompareResults: list of CompareResult
        :param _Extra: Data passed through in the process of getting the token.
        :type Extra: str
        :param _DeviceInfoLevel: Describe the risk level of the device where the current request is located, with a total of 4 levels. The details are as follows:
1 - Secure
2 - Low Risk
3 - Medium Risk
4 - High Risk
Empty - Risk level not obtained.
Only returned for the Enhance and Plus version, with the default value being empty.
        :type DeviceInfoLevel: str
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._Result = None
        self._Description = None
        self._ChargeCount = None
        self._CardVerifyResults = None
        self._CompareResults = None
        self._Extra = None
        self._DeviceInfoLevel = None
        self._RequestId = None

    @property
    def Result(self):
        r"""The result code of the verification result.
        :rtype: str
        """
        return self._Result

    @Result.setter
    def Result(self, Result):
        self._Result = Result

    @property
    def Description(self):
        r"""The verification result description.
        :rtype: str
        """
        return self._Description

    @Description.setter
    def Description(self, Description):
        self._Description = Description

    @property
    def ChargeCount(self):
        r"""The charge count.
        :rtype: int
        """
        return self._ChargeCount

    @ChargeCount.setter
    def ChargeCount(self, ChargeCount):
        self._ChargeCount = ChargeCount

    @property
    def CardVerifyResults(self):
        r"""The results of multiple OCR processes (in order). The result of the final process is used as the valid result.
        :rtype: list of CardVerifyResult
        """
        return self._CardVerifyResults

    @CardVerifyResults.setter
    def CardVerifyResults(self, CardVerifyResults):
        self._CardVerifyResults = CardVerifyResults

    @property
    def CompareResults(self):
        r"""The results of multiple liveness detection processes (in order). The result of the final process is used as the valid result.
        :rtype: list of CompareResult
        """
        return self._CompareResults

    @CompareResults.setter
    def CompareResults(self, CompareResults):
        self._CompareResults = CompareResults

    @property
    def Extra(self):
        r"""Data passed through in the process of getting the token.
        :rtype: str
        """
        return self._Extra

    @Extra.setter
    def Extra(self, Extra):
        self._Extra = Extra

    @property
    def DeviceInfoLevel(self):
        r"""Describe the risk level of the device where the current request is located, with a total of 4 levels. The details are as follows:
1 - Secure
2 - Low Risk
3 - Medium Risk
4 - High Risk
Empty - Risk level not obtained.
Only returned for the Enhance and Plus version, with the default value being empty.
        :rtype: str
        """
        return self._DeviceInfoLevel

    @DeviceInfoLevel.setter
    def DeviceInfoLevel(self, DeviceInfoLevel):
        self._DeviceInfoLevel = DeviceInfoLevel

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._Result = params.get("Result")
        self._Description = params.get("Description")
        self._ChargeCount = params.get("ChargeCount")
        if params.get("CardVerifyResults") is not None:
            self._CardVerifyResults = []
            for item in params.get("CardVerifyResults"):
                obj = CardVerifyResult()
                obj._deserialize(item)
                self._CardVerifyResults.append(obj)
        if params.get("CompareResults") is not None:
            self._CompareResults = []
            for item in params.get("CompareResults"):
                obj = CompareResult()
                obj._deserialize(item)
                self._CompareResults.append(obj)
        self._Extra = params.get("Extra")
        self._DeviceInfoLevel = params.get("DeviceInfoLevel")
        self._RequestId = params.get("RequestId")


class GetWebVerificationResultIntlRequest(AbstractModel):
    r"""GetWebVerificationResultIntl request structure.

    """

    def __init__(self):
        r"""
        :param _BizToken: The token for the web-based verification, which is generated using the `ApplyWebVerificationBizTokenIntl` API.
        :type BizToken: str
        """
        self._BizToken = None

    @property
    def BizToken(self):
        r"""The token for the web-based verification, which is generated using the `ApplyWebVerificationBizTokenIntl` API.
        :rtype: str
        """
        return self._BizToken

    @BizToken.setter
    def BizToken(self, BizToken):
        self._BizToken = BizToken


    def _deserialize(self, params):
        self._BizToken = params.get("BizToken")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class GetWebVerificationResultIntlResponse(AbstractModel):
    r"""GetWebVerificationResultIntl response structure.

    """

    def __init__(self):
        r"""
        :param _ErrorCode: The final result of this verification. `0` indicates that the person is the same as that in the photo.
For other error codes, see <a href="https://www.tencentcloud.com/document/product/1061/55390?lang=en&pg=#8a960e1e-39c0-42cb-b181-b3164d77f81e">Selfie Verification (Mobile HTML5) Error Codes</a>
Note: This field may return null, indicating that no valid values can be obtained.
        :type ErrorCode: int
        :param _ErrorMsg: The description of the final verification result.
Note: This field may return null, indicating that no valid values can be obtained.
        :type ErrorMsg: str
        :param _VerificationDetailList: The detailed verification result list of this process. Retries are allowed, so a verification process may have several entries of results.
Note: This field may return null, indicating that no valid values can be obtained.
        :type VerificationDetailList: list of VerificationDetail
        :param _VideoBase64: The Base64-encoded string of the video collected from the video stream. Retries are allowed, and this field returns only the data collected in the last verification. If no video is collected, null is returned.
Note: This field may return null, indicating that no valid values can be obtained.
        :type VideoBase64: str
        :param _BestFrameBase64: The Base64-encoded string of the best face screenshot collected from the video stream. Retries are allowed, and this field returns only the data collected in the last verification. If no best face screenshot is collected, null is returned.
Note: This field may return null, indicating that no valid values can be obtained.
        :type BestFrameBase64: str
        :param _OCRResult: Card recognize result.
Note: This field may return null, indicating that no valid values can be obtained.
        :type OCRResult: list of OCRResult
        :param _Extra: The passthrough parameter of the business, max 1,000 characters, which will be returned in GetWebVerificationResultIntl.
        :type Extra: str
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._ErrorCode = None
        self._ErrorMsg = None
        self._VerificationDetailList = None
        self._VideoBase64 = None
        self._BestFrameBase64 = None
        self._OCRResult = None
        self._Extra = None
        self._RequestId = None

    @property
    def ErrorCode(self):
        r"""The final result of this verification. `0` indicates that the person is the same as that in the photo.
For other error codes, see <a href="https://www.tencentcloud.com/document/product/1061/55390?lang=en&pg=#8a960e1e-39c0-42cb-b181-b3164d77f81e">Selfie Verification (Mobile HTML5) Error Codes</a>
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: int
        """
        return self._ErrorCode

    @ErrorCode.setter
    def ErrorCode(self, ErrorCode):
        self._ErrorCode = ErrorCode

    @property
    def ErrorMsg(self):
        r"""The description of the final verification result.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._ErrorMsg

    @ErrorMsg.setter
    def ErrorMsg(self, ErrorMsg):
        self._ErrorMsg = ErrorMsg

    @property
    def VerificationDetailList(self):
        r"""The detailed verification result list of this process. Retries are allowed, so a verification process may have several entries of results.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: list of VerificationDetail
        """
        return self._VerificationDetailList

    @VerificationDetailList.setter
    def VerificationDetailList(self, VerificationDetailList):
        self._VerificationDetailList = VerificationDetailList

    @property
    def VideoBase64(self):
        r"""The Base64-encoded string of the video collected from the video stream. Retries are allowed, and this field returns only the data collected in the last verification. If no video is collected, null is returned.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._VideoBase64

    @VideoBase64.setter
    def VideoBase64(self, VideoBase64):
        self._VideoBase64 = VideoBase64

    @property
    def BestFrameBase64(self):
        r"""The Base64-encoded string of the best face screenshot collected from the video stream. Retries are allowed, and this field returns only the data collected in the last verification. If no best face screenshot is collected, null is returned.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._BestFrameBase64

    @BestFrameBase64.setter
    def BestFrameBase64(self, BestFrameBase64):
        self._BestFrameBase64 = BestFrameBase64

    @property
    def OCRResult(self):
        r"""Card recognize result.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: list of OCRResult
        """
        return self._OCRResult

    @OCRResult.setter
    def OCRResult(self, OCRResult):
        self._OCRResult = OCRResult

    @property
    def Extra(self):
        r"""The passthrough parameter of the business, max 1,000 characters, which will be returned in GetWebVerificationResultIntl.
        :rtype: str
        """
        return self._Extra

    @Extra.setter
    def Extra(self, Extra):
        self._Extra = Extra

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._ErrorCode = params.get("ErrorCode")
        self._ErrorMsg = params.get("ErrorMsg")
        if params.get("VerificationDetailList") is not None:
            self._VerificationDetailList = []
            for item in params.get("VerificationDetailList"):
                obj = VerificationDetail()
                obj._deserialize(item)
                self._VerificationDetailList.append(obj)
        self._VideoBase64 = params.get("VideoBase64")
        self._BestFrameBase64 = params.get("BestFrameBase64")
        if params.get("OCRResult") is not None:
            self._OCRResult = []
            for item in params.get("OCRResult"):
                obj = OCRResult()
                obj._deserialize(item)
                self._OCRResult.append(obj)
        self._Extra = params.get("Extra")
        self._RequestId = params.get("RequestId")


class HKIDCard(AbstractModel):
    r"""Hong Kong (China) ID card.

    """

    def __init__(self):
        r"""
        :param _CnName: Chinese name
Note: This field may return null, indicating that no valid values can be obtained.
Example:  SAN, Nan
        :type CnName: str
        :param _EnName: English name
Note: This field may return null, indicating that no valid values can be obtained.
Example: SAN, Nan
        :type EnName: str
        :param _TelexCode: Telex code correspondint to the Chinese name
Note: This field may return null, indicating that no valid values can be obtained.
        :type TelexCode: str
        :param _Sex: Gender: "Male-M" or "Female-F"
Note: This field may return null, indicating that no valid values can be obtained.
        :type Sex: str
        :param _Birthday: Birthday
Note: This field may return null, indicating that no valid values can be obtained.
Example: 01-01-2001
        :type Birthday: str
        :param _Permanent: Permanent resident ID card: 0-non-permanent; 1-permanent; -1-unknown
Note: This field may return null, indicating that no valid values can be obtained.
        :type Permanent: str
        :param _IdNum: ID card number
Note: This field may return null, indicating that no valid values can be obtained.
Example: C000000(E)
        :type IdNum: str
        :param _Symbol: Lisence symbol, which is the symbol below Birthday. Example: "***AZ"
Note: This field may return null, indicating that no valid values can be obtained.
        :type Symbol: str
        :param _FirstIssueDate: The first date of issue
Note: This field may return null, indicating that no valid values can be obtained.
        :type FirstIssueDate: str
        :param _CurrentIssueDate: The current date of issue
Note: This field may return null, indicating that no valid values can be obtained.
        :type CurrentIssueDate: str
        """
        self._CnName = None
        self._EnName = None
        self._TelexCode = None
        self._Sex = None
        self._Birthday = None
        self._Permanent = None
        self._IdNum = None
        self._Symbol = None
        self._FirstIssueDate = None
        self._CurrentIssueDate = None

    @property
    def CnName(self):
        r"""Chinese name
Note: This field may return null, indicating that no valid values can be obtained.
Example:  SAN, Nan
        :rtype: str
        """
        return self._CnName

    @CnName.setter
    def CnName(self, CnName):
        self._CnName = CnName

    @property
    def EnName(self):
        r"""English name
Note: This field may return null, indicating that no valid values can be obtained.
Example: SAN, Nan
        :rtype: str
        """
        return self._EnName

    @EnName.setter
    def EnName(self, EnName):
        self._EnName = EnName

    @property
    def TelexCode(self):
        r"""Telex code correspondint to the Chinese name
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._TelexCode

    @TelexCode.setter
    def TelexCode(self, TelexCode):
        self._TelexCode = TelexCode

    @property
    def Sex(self):
        r"""Gender: "Male-M" or "Female-F"
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Sex

    @Sex.setter
    def Sex(self, Sex):
        self._Sex = Sex

    @property
    def Birthday(self):
        r"""Birthday
Note: This field may return null, indicating that no valid values can be obtained.
Example: 01-01-2001
        :rtype: str
        """
        return self._Birthday

    @Birthday.setter
    def Birthday(self, Birthday):
        self._Birthday = Birthday

    @property
    def Permanent(self):
        r"""Permanent resident ID card: 0-non-permanent; 1-permanent; -1-unknown
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Permanent

    @Permanent.setter
    def Permanent(self, Permanent):
        self._Permanent = Permanent

    @property
    def IdNum(self):
        r"""ID card number
Note: This field may return null, indicating that no valid values can be obtained.
Example: C000000(E)
        :rtype: str
        """
        return self._IdNum

    @IdNum.setter
    def IdNum(self, IdNum):
        self._IdNum = IdNum

    @property
    def Symbol(self):
        r"""Lisence symbol, which is the symbol below Birthday. Example: "***AZ"
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Symbol

    @Symbol.setter
    def Symbol(self, Symbol):
        self._Symbol = Symbol

    @property
    def FirstIssueDate(self):
        r"""The first date of issue
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._FirstIssueDate

    @FirstIssueDate.setter
    def FirstIssueDate(self, FirstIssueDate):
        self._FirstIssueDate = FirstIssueDate

    @property
    def CurrentIssueDate(self):
        r"""The current date of issue
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._CurrentIssueDate

    @CurrentIssueDate.setter
    def CurrentIssueDate(self, CurrentIssueDate):
        self._CurrentIssueDate = CurrentIssueDate


    def _deserialize(self, params):
        self._CnName = params.get("CnName")
        self._EnName = params.get("EnName")
        self._TelexCode = params.get("TelexCode")
        self._Sex = params.get("Sex")
        self._Birthday = params.get("Birthday")
        self._Permanent = params.get("Permanent")
        self._IdNum = params.get("IdNum")
        self._Symbol = params.get("Symbol")
        self._FirstIssueDate = params.get("FirstIssueDate")
        self._CurrentIssueDate = params.get("CurrentIssueDate")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class HMTPermit(AbstractModel):
    r"""Exit/entry permit (card) for traveling to and from Hong Kong (China), Macao (China), or Taiwan (China)

    """

    def __init__(self):
        r"""
        :param _Name: Name
        :type Name: str
        :param _EnglishName: English name
        :type EnglishName: str
        :param _Number: License number
        :type Number: str
        :param _Sex: Gender
        :type Sex: str
        :param _ValidDate: Valid date
        :type ValidDate: str
        :param _IssueAuthority: Issued authority
        :type IssueAuthority: str
        :param _IssueAddress: Issued address
        :type IssueAddress: str
        :param _Birthday: Birthday
        :type Birthday: str
        """
        self._Name = None
        self._EnglishName = None
        self._Number = None
        self._Sex = None
        self._ValidDate = None
        self._IssueAuthority = None
        self._IssueAddress = None
        self._Birthday = None

    @property
    def Name(self):
        r"""Name
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def EnglishName(self):
        r"""English name
        :rtype: str
        """
        return self._EnglishName

    @EnglishName.setter
    def EnglishName(self, EnglishName):
        self._EnglishName = EnglishName

    @property
    def Number(self):
        r"""License number
        :rtype: str
        """
        return self._Number

    @Number.setter
    def Number(self, Number):
        self._Number = Number

    @property
    def Sex(self):
        r"""Gender
        :rtype: str
        """
        return self._Sex

    @Sex.setter
    def Sex(self, Sex):
        self._Sex = Sex

    @property
    def ValidDate(self):
        r"""Valid date
        :rtype: str
        """
        return self._ValidDate

    @ValidDate.setter
    def ValidDate(self, ValidDate):
        self._ValidDate = ValidDate

    @property
    def IssueAuthority(self):
        r"""Issued authority
        :rtype: str
        """
        return self._IssueAuthority

    @IssueAuthority.setter
    def IssueAuthority(self, IssueAuthority):
        self._IssueAuthority = IssueAuthority

    @property
    def IssueAddress(self):
        r"""Issued address
        :rtype: str
        """
        return self._IssueAddress

    @IssueAddress.setter
    def IssueAddress(self, IssueAddress):
        self._IssueAddress = IssueAddress

    @property
    def Birthday(self):
        r"""Birthday
        :rtype: str
        """
        return self._Birthday

    @Birthday.setter
    def Birthday(self, Birthday):
        self._Birthday = Birthday


    def _deserialize(self, params):
        self._Name = params.get("Name")
        self._EnglishName = params.get("EnglishName")
        self._Number = params.get("Number")
        self._Sex = params.get("Sex")
        self._ValidDate = params.get("ValidDate")
        self._IssueAuthority = params.get("IssueAuthority")
        self._IssueAddress = params.get("IssueAddress")
        self._Birthday = params.get("Birthday")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class IdCardOCRVerificationRequest(AbstractModel):
    r"""IdCardOCRVerification request structure.

    """

    def __init__(self):
        r"""
        :param _IdCard: Identity card number.
-Name, identity card number, ImageBase64, or ImageUrl must provide one of the three.
-If both are provided, proceed to use parameters according to the priority of name and identity card number > ImageBase64 > ImageUrl.
        :type IdCard: str
        :param _Name: Name
        :type Name: str
        :param _ImageBase64: Base64 value of the ID card portrait side.
-Supported image formats: PNG, JPG, JPEG. GIF format is not currently supported.
-Supported image size: The downloaded image after Base64 encoding is no more than 3M. Please use the standard Base64 encoding method (with = padding). Refer to RFC4648 for the coding specification.
        :type ImageBase64: str
        :param _ImageUrl: Url of the ID card portrait side.
-Supported image formats: PNG, JPG, JPEG. GIF format is not currently supported.
-Supported image size: The downloaded image is no more than 3M after Base64 encoding. Image download time is no more than 3 seconds.
-Images stored on Tencent Cloud's Url guarantee higher download speed and stability. It is advisable to store images on Tencent Cloud.
-The speed and stability of non-Tencent Cloud Storage URLs may be impacted.
        :type ImageUrl: str
        :param _Encryption: Sensitive data encryption info.
-Users with encryption requirements for incoming information (name, identity card number) can use this parameter. For details, please click the left-side link.
        :type Encryption: :class:`tencentcloud.faceid.v20180301.models.Encryption`
        """
        self._IdCard = None
        self._Name = None
        self._ImageBase64 = None
        self._ImageUrl = None
        self._Encryption = None

    @property
    def IdCard(self):
        r"""Identity card number.
-Name, identity card number, ImageBase64, or ImageUrl must provide one of the three.
-If both are provided, proceed to use parameters according to the priority of name and identity card number > ImageBase64 > ImageUrl.
        :rtype: str
        """
        return self._IdCard

    @IdCard.setter
    def IdCard(self, IdCard):
        self._IdCard = IdCard

    @property
    def Name(self):
        r"""Name
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def ImageBase64(self):
        r"""Base64 value of the ID card portrait side.
-Supported image formats: PNG, JPG, JPEG. GIF format is not currently supported.
-Supported image size: The downloaded image after Base64 encoding is no more than 3M. Please use the standard Base64 encoding method (with = padding). Refer to RFC4648 for the coding specification.
        :rtype: str
        """
        return self._ImageBase64

    @ImageBase64.setter
    def ImageBase64(self, ImageBase64):
        self._ImageBase64 = ImageBase64

    @property
    def ImageUrl(self):
        r"""Url of the ID card portrait side.
-Supported image formats: PNG, JPG, JPEG. GIF format is not currently supported.
-Supported image size: The downloaded image is no more than 3M after Base64 encoding. Image download time is no more than 3 seconds.
-Images stored on Tencent Cloud's Url guarantee higher download speed and stability. It is advisable to store images on Tencent Cloud.
-The speed and stability of non-Tencent Cloud Storage URLs may be impacted.
        :rtype: str
        """
        return self._ImageUrl

    @ImageUrl.setter
    def ImageUrl(self, ImageUrl):
        self._ImageUrl = ImageUrl

    @property
    def Encryption(self):
        r"""Sensitive data encryption info.
-Users with encryption requirements for incoming information (name, identity card number) can use this parameter. For details, please click the left-side link.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.Encryption`
        """
        return self._Encryption

    @Encryption.setter
    def Encryption(self, Encryption):
        self._Encryption = Encryption


    def _deserialize(self, params):
        self._IdCard = params.get("IdCard")
        self._Name = params.get("Name")
        self._ImageBase64 = params.get("ImageBase64")
        self._ImageUrl = params.get("ImageUrl")
        if params.get("Encryption") is not None:
            self._Encryption = Encryption()
            self._Encryption._deserialize(params.get("Encryption"))
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class IdCardOCRVerificationResponse(AbstractModel):
    r"""IdCardOCRVerification response structure.

    """

    def __init__(self):
        r"""
        :param _Result: Verification result code. Billing is as follows.
-Result code for charges
The name and identity card number match.
-Name and ID card number mismatch.
-Result code with no charge
-2: Invalid ID number (incorrect length or check digit).
-3: Invalid name (incorrect length or format).
-4: Document library service exception.
-5: No ID card record found in the document library.
-6: The authoritative comparison system is being upgraded. Try again later.
-7: Authentication attempts exceeded the daily limit.
        :type Result: str
        :param _Description: Business result description.
        :type Description: str
        :param _Name: Name to verify.
        :type Name: str
        :param _IdCard: Identity card number to verify.
        :type IdCard: str
        :param _Sex: Gender obtained by OCR.
Note: This field may return null, indicating that no valid values can be obtained.
        :type Sex: str
        :param _Nation: Ethnicity obtained by OCR.
Note: This field may return null, indicating that no valid values can be obtained.
        :type Nation: str
        :param _Birth: Birthday obtained by OCR.
Note: This field may return null, indicating that no valid values can be obtained.
        :type Birth: str
        :param _Address: Address obtained by OCR.
Note: This field may return null, indicating that no valid values can be obtained.
        :type Address: str
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._Result = None
        self._Description = None
        self._Name = None
        self._IdCard = None
        self._Sex = None
        self._Nation = None
        self._Birth = None
        self._Address = None
        self._RequestId = None

    @property
    def Result(self):
        r"""Verification result code. Billing is as follows.
-Result code for charges
The name and identity card number match.
-Name and ID card number mismatch.
-Result code with no charge
-2: Invalid ID number (incorrect length or check digit).
-3: Invalid name (incorrect length or format).
-4: Document library service exception.
-5: No ID card record found in the document library.
-6: The authoritative comparison system is being upgraded. Try again later.
-7: Authentication attempts exceeded the daily limit.
        :rtype: str
        """
        return self._Result

    @Result.setter
    def Result(self, Result):
        self._Result = Result

    @property
    def Description(self):
        r"""Business result description.
        :rtype: str
        """
        return self._Description

    @Description.setter
    def Description(self, Description):
        self._Description = Description

    @property
    def Name(self):
        r"""Name to verify.
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def IdCard(self):
        r"""Identity card number to verify.
        :rtype: str
        """
        return self._IdCard

    @IdCard.setter
    def IdCard(self, IdCard):
        self._IdCard = IdCard

    @property
    def Sex(self):
        r"""Gender obtained by OCR.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Sex

    @Sex.setter
    def Sex(self, Sex):
        self._Sex = Sex

    @property
    def Nation(self):
        r"""Ethnicity obtained by OCR.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Nation

    @Nation.setter
    def Nation(self, Nation):
        self._Nation = Nation

    @property
    def Birth(self):
        r"""Birthday obtained by OCR.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Birth

    @Birth.setter
    def Birth(self, Birth):
        self._Birth = Birth

    @property
    def Address(self):
        r"""Address obtained by OCR.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Address

    @Address.setter
    def Address(self, Address):
        self._Address = Address

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._Result = params.get("Result")
        self._Description = params.get("Description")
        self._Name = params.get("Name")
        self._IdCard = params.get("IdCard")
        self._Sex = params.get("Sex")
        self._Nation = params.get("Nation")
        self._Birth = params.get("Birth")
        self._Address = params.get("Address")
        self._RequestId = params.get("RequestId")


class IdCardVerificationRequest(AbstractModel):
    r"""IdCardVerification request structure.

    """

    def __init__(self):
        r"""
        :param _IdCard: Identity card number.
        :type IdCard: str
        :param _Name: Name
        :type Name: str
        :param _Encryption: Sensitive data encryption info.
-Users with encryption requirements for incoming information (name, identity card number) can use this parameter. For details, please click the left-side link.
        :type Encryption: :class:`tencentcloud.faceid.v20180301.models.Encryption`
        """
        self._IdCard = None
        self._Name = None
        self._Encryption = None

    @property
    def IdCard(self):
        r"""Identity card number.
        :rtype: str
        """
        return self._IdCard

    @IdCard.setter
    def IdCard(self, IdCard):
        self._IdCard = IdCard

    @property
    def Name(self):
        r"""Name
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def Encryption(self):
        r"""Sensitive data encryption info.
-Users with encryption requirements for incoming information (name, identity card number) can use this parameter. For details, please click the left-side link.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.Encryption`
        """
        return self._Encryption

    @Encryption.setter
    def Encryption(self, Encryption):
        self._Encryption = Encryption


    def _deserialize(self, params):
        self._IdCard = params.get("IdCard")
        self._Name = params.get("Name")
        if params.get("Encryption") is not None:
            self._Encryption = Encryption()
            self._Encryption._deserialize(params.get("Encryption"))
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class IdCardVerificationResponse(AbstractModel):
    r"""IdCardVerification response structure.

    """

    def __init__(self):
        r"""
        :param _Result: Verification result code. Billing is as follows.
-Result code for charges
Name and identity card number match
-Name and ID card number mismatch
No charge result code:
-2: Invalid ID number (incorrect length or check digit).
-3: Invalid name (incorrect length, format, etc.)
-4: Document library service exception
-5: No ID card record found in the document library
-6: The authoritative comparison system is being upgraded. Try again later.
-7: Authentication attempts exceeded the daily limit.
        :type Result: str
        :param _Description: Business result description.
        :type Description: str
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._Result = None
        self._Description = None
        self._RequestId = None

    @property
    def Result(self):
        r"""Verification result code. Billing is as follows.
-Result code for charges
Name and identity card number match
-Name and ID card number mismatch
No charge result code:
-2: Invalid ID number (incorrect length or check digit).
-3: Invalid name (incorrect length, format, etc.)
-4: Document library service exception
-5: No ID card record found in the document library
-6: The authoritative comparison system is being upgraded. Try again later.
-7: Authentication attempts exceeded the daily limit.
        :rtype: str
        """
        return self._Result

    @Result.setter
    def Result(self, Result):
        self._Result = Result

    @property
    def Description(self):
        r"""Business result description.
        :rtype: str
        """
        return self._Description

    @Description.setter
    def Description(self, Description):
        self._Description = Description

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._Result = params.get("Result")
        self._Description = params.get("Description")
        self._RequestId = params.get("RequestId")


class ImageRecognitionRequest(AbstractModel):
    r"""ImageRecognition request structure.

    """

    def __init__(self):
        r"""
        :param _IdCard: <p>Identity card number</p>
        :type IdCard: str
        :param _Name: <p>Name. For Chinese, please use UTF-8 encode.</p>
        :type Name: str
        :param _ImageBase64: <p>Image for face comparison, the Base64 value of the image.<br>The size of the Base64-encoded image data should be no more than 3M. Only jpg and png formats are supported.<br>Please use the standard Base64 encoding type (with = padding). Refer to RFC4648 for the coding specification.</p>
        :type ImageBase64: str
        :param _Optional: <p>This parameter is not required for this API.</p>
        :type Optional: str
        :param _Encryption: <p>Sensitive data encryption information. Users with encryption requirements for incoming information (name, identity card number) can use this parameter. For details, please click the left-side link.</p>
        :type Encryption: :class:`tencentcloud.faceid.v20180301.models.Encryption`
        """
        self._IdCard = None
        self._Name = None
        self._ImageBase64 = None
        self._Optional = None
        self._Encryption = None

    @property
    def IdCard(self):
        r"""<p>Identity card number</p>
        :rtype: str
        """
        return self._IdCard

    @IdCard.setter
    def IdCard(self, IdCard):
        self._IdCard = IdCard

    @property
    def Name(self):
        r"""<p>Name. For Chinese, please use UTF-8 encode.</p>
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def ImageBase64(self):
        r"""<p>Image for face comparison, the Base64 value of the image.<br>The size of the Base64-encoded image data should be no more than 3M. Only jpg and png formats are supported.<br>Please use the standard Base64 encoding type (with = padding). Refer to RFC4648 for the coding specification.</p>
        :rtype: str
        """
        return self._ImageBase64

    @ImageBase64.setter
    def ImageBase64(self, ImageBase64):
        self._ImageBase64 = ImageBase64

    @property
    def Optional(self):
        r"""<p>This parameter is not required for this API.</p>
        :rtype: str
        """
        return self._Optional

    @Optional.setter
    def Optional(self, Optional):
        self._Optional = Optional

    @property
    def Encryption(self):
        r"""<p>Sensitive data encryption information. Users with encryption requirements for incoming information (name, identity card number) can use this parameter. For details, please click the left-side link.</p>
        :rtype: :class:`tencentcloud.faceid.v20180301.models.Encryption`
        """
        return self._Encryption

    @Encryption.setter
    def Encryption(self, Encryption):
        self._Encryption = Encryption


    def _deserialize(self, params):
        self._IdCard = params.get("IdCard")
        self._Name = params.get("Name")
        self._ImageBase64 = params.get("ImageBase64")
        self._Optional = params.get("Optional")
        if params.get("Encryption") is not None:
            self._Encryption = Encryption()
            self._Encryption._deserialize(params.get("Encryption"))
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ImageRecognitionResponse(AbstractModel):
    r"""ImageRecognition response structure.

    """

    def __init__(self):
        r"""
        :param _Sim: <p>Similarity, value ranges from 0.00 to 100.00. Recommend judging as the same person when similarity is at least 70. Threshold can be self-adjusted based on specific scenarios (pass rate for false matches is one in a thousand at threshold 70, and one in ten thousand at threshold 80).</p>
        :type Sim: float
        :param _Result: <p>Business error code. Successfully returns Success in successful case. For error conditions, refer to the FailedOperation part in the error code list below.</p>
        :type Result: str
        :param _Description: <p>Business result description.</p>
        :type Description: str
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._Sim = None
        self._Result = None
        self._Description = None
        self._RequestId = None

    @property
    def Sim(self):
        r"""<p>Similarity, value ranges from 0.00 to 100.00. Recommend judging as the same person when similarity is at least 70. Threshold can be self-adjusted based on specific scenarios (pass rate for false matches is one in a thousand at threshold 70, and one in ten thousand at threshold 80).</p>
        :rtype: float
        """
        return self._Sim

    @Sim.setter
    def Sim(self, Sim):
        self._Sim = Sim

    @property
    def Result(self):
        r"""<p>Business error code. Successfully returns Success in successful case. For error conditions, refer to the FailedOperation part in the error code list below.</p>
        :rtype: str
        """
        return self._Result

    @Result.setter
    def Result(self, Result):
        self._Result = Result

    @property
    def Description(self):
        r"""<p>Business result description.</p>
        :rtype: str
        """
        return self._Description

    @Description.setter
    def Description(self, Description):
        self._Description = Description

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._Sim = params.get("Sim")
        self._Result = params.get("Result")
        self._Description = params.get("Description")
        self._RequestId = params.get("RequestId")


class ImageRecognitionV2Request(AbstractModel):
    r"""ImageRecognitionV2 request structure.

    """

    def __init__(self):
        r"""
        :param _IdCard: <p>Identity card number.</p>
        :type IdCard: str
        :param _Name: <p>Name.</p><ul><li>For Chinese, please use UTF-8 encode.</li></ul>
        :type Name: str
        :param _ImageBase64: <p>Image for face comparison, the Base64 value of the image.<br>The size of the Base64-encoded image data should be no more than 3M. Only jpg and png formats are supported.<br>Please use the standard Base64 encoding type (with = padding). Refer to RFC4648 for the coding specification.</p>
        :type ImageBase64: str
        :param _Optional: <p>This parameter is not required for this API.</p>
        :type Optional: str
        :param _Encryption: <p>Sensitive data encryption information.</p><ul><li>Users with encryption requirements for incoming information (name, identity card number) can use this parameter. For details, please click the left-side link.</li></ul>
        :type Encryption: :class:`tencentcloud.faceid.v20180301.models.Encryption`
        :param _Extra: <p>Customized description field.</p><ul><li>For description of invoke business info. This description field will return in the output.</li><li>Each customized description field supports [1,10] characters.</li></ul>
        :type Extra: str
        """
        self._IdCard = None
        self._Name = None
        self._ImageBase64 = None
        self._Optional = None
        self._Encryption = None
        self._Extra = None

    @property
    def IdCard(self):
        r"""<p>Identity card number.</p>
        :rtype: str
        """
        return self._IdCard

    @IdCard.setter
    def IdCard(self, IdCard):
        self._IdCard = IdCard

    @property
    def Name(self):
        r"""<p>Name.</p><ul><li>For Chinese, please use UTF-8 encode.</li></ul>
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def ImageBase64(self):
        r"""<p>Image for face comparison, the Base64 value of the image.<br>The size of the Base64-encoded image data should be no more than 3M. Only jpg and png formats are supported.<br>Please use the standard Base64 encoding type (with = padding). Refer to RFC4648 for the coding specification.</p>
        :rtype: str
        """
        return self._ImageBase64

    @ImageBase64.setter
    def ImageBase64(self, ImageBase64):
        self._ImageBase64 = ImageBase64

    @property
    def Optional(self):
        r"""<p>This parameter is not required for this API.</p>
        :rtype: str
        """
        return self._Optional

    @Optional.setter
    def Optional(self, Optional):
        self._Optional = Optional

    @property
    def Encryption(self):
        r"""<p>Sensitive data encryption information.</p><ul><li>Users with encryption requirements for incoming information (name, identity card number) can use this parameter. For details, please click the left-side link.</li></ul>
        :rtype: :class:`tencentcloud.faceid.v20180301.models.Encryption`
        """
        return self._Encryption

    @Encryption.setter
    def Encryption(self, Encryption):
        self._Encryption = Encryption

    @property
    def Extra(self):
        r"""<p>Customized description field.</p><ul><li>For description of invoke business info. This description field will return in the output.</li><li>Each customized description field supports [1,10] characters.</li></ul>
        :rtype: str
        """
        return self._Extra

    @Extra.setter
    def Extra(self, Extra):
        self._Extra = Extra


    def _deserialize(self, params):
        self._IdCard = params.get("IdCard")
        self._Name = params.get("Name")
        self._ImageBase64 = params.get("ImageBase64")
        self._Optional = params.get("Optional")
        if params.get("Encryption") is not None:
            self._Encryption = Encryption()
            self._Encryption._deserialize(params.get("Encryption"))
        self._Extra = params.get("Extra")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ImageRecognitionV2Response(AbstractModel):
    r"""ImageRecognitionV2 response structure.

    """

    def __init__(self):
        r"""
        :param _Sim: <p>Similarity. - Value ranges from 0.00 to 100.00. - Recommend at least 70 to be determined as the same person. You can self-adjust the threshold based on specific scenarios (the pass rate for false matches at threshold 70 is 0.01%).</p>
        :type Sim: float
        :param _Result: <p>Business error code.</p><ul><li>Success case returns Success.</li><li>For error conditions, refer to the FailedOperation part in the error code list below.</li></ul>
        :type Result: str
        :param _Description: <p>Business result description.</p>
        :type Description: str
        :param _Extra: <p>Custom description field in the API call.</p>
        :type Extra: str
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._Sim = None
        self._Result = None
        self._Description = None
        self._Extra = None
        self._RequestId = None

    @property
    def Sim(self):
        r"""<p>Similarity. - Value ranges from 0.00 to 100.00. - Recommend at least 70 to be determined as the same person. You can self-adjust the threshold based on specific scenarios (the pass rate for false matches at threshold 70 is 0.01%).</p>
        :rtype: float
        """
        return self._Sim

    @Sim.setter
    def Sim(self, Sim):
        self._Sim = Sim

    @property
    def Result(self):
        r"""<p>Business error code.</p><ul><li>Success case returns Success.</li><li>For error conditions, refer to the FailedOperation part in the error code list below.</li></ul>
        :rtype: str
        """
        return self._Result

    @Result.setter
    def Result(self, Result):
        self._Result = Result

    @property
    def Description(self):
        r"""<p>Business result description.</p>
        :rtype: str
        """
        return self._Description

    @Description.setter
    def Description(self, Description):
        self._Description = Description

    @property
    def Extra(self):
        r"""<p>Custom description field in the API call.</p>
        :rtype: str
        """
        return self._Extra

    @Extra.setter
    def Extra(self, Extra):
        self._Extra = Extra

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._Sim = params.get("Sim")
        self._Result = params.get("Result")
        self._Description = params.get("Description")
        self._Extra = params.get("Extra")
        self._RequestId = params.get("RequestId")


class IndonesiaDrivingLicense(AbstractModel):
    r"""Indonesia driving license.

    """

    def __init__(self):
        r"""
        :param _LastName: Last name
Note: This field may return null, indicating that no valid values can be obtained.
        :type LastName: str
        :param _FirstName: First name
Note: This field may return null, indicating that no valid values can be obtained.
        :type FirstName: str
        :param _LicenseNumber: License number
Note: This field may return null, indicating that no valid values can be obtained.
        :type LicenseNumber: str
        :param _Birthday: Birthday
Note: This field may return null, indicating that no valid values can be obtained.
        :type Birthday: str
        :param _Address: Address
Note: This field may return null, indicating that no valid values can be obtained.
        :type Address: str
        :param _ExpirationDate: Expiration date
Note: This field may return null, indicating that no valid values can be obtained.
        :type ExpirationDate: str
        :param _IssuedDate: Date of issue
Note: This field may return null, indicating that no valid values can be obtained.
        :type IssuedDate: str
        :param _IssuedCountry: Issuing country
Note: This field may return null, indicating that no valid values can be obtained.
        :type IssuedCountry: str
        """
        self._LastName = None
        self._FirstName = None
        self._LicenseNumber = None
        self._Birthday = None
        self._Address = None
        self._ExpirationDate = None
        self._IssuedDate = None
        self._IssuedCountry = None

    @property
    def LastName(self):
        r"""Last name
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._LastName

    @LastName.setter
    def LastName(self, LastName):
        self._LastName = LastName

    @property
    def FirstName(self):
        r"""First name
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._FirstName

    @FirstName.setter
    def FirstName(self, FirstName):
        self._FirstName = FirstName

    @property
    def LicenseNumber(self):
        r"""License number
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._LicenseNumber

    @LicenseNumber.setter
    def LicenseNumber(self, LicenseNumber):
        self._LicenseNumber = LicenseNumber

    @property
    def Birthday(self):
        r"""Birthday
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Birthday

    @Birthday.setter
    def Birthday(self, Birthday):
        self._Birthday = Birthday

    @property
    def Address(self):
        r"""Address
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Address

    @Address.setter
    def Address(self, Address):
        self._Address = Address

    @property
    def ExpirationDate(self):
        r"""Expiration date
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._ExpirationDate

    @ExpirationDate.setter
    def ExpirationDate(self, ExpirationDate):
        self._ExpirationDate = ExpirationDate

    @property
    def IssuedDate(self):
        r"""Date of issue
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._IssuedDate

    @IssuedDate.setter
    def IssuedDate(self, IssuedDate):
        self._IssuedDate = IssuedDate

    @property
    def IssuedCountry(self):
        r"""Issuing country
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._IssuedCountry

    @IssuedCountry.setter
    def IssuedCountry(self, IssuedCountry):
        self._IssuedCountry = IssuedCountry


    def _deserialize(self, params):
        self._LastName = params.get("LastName")
        self._FirstName = params.get("FirstName")
        self._LicenseNumber = params.get("LicenseNumber")
        self._Birthday = params.get("Birthday")
        self._Address = params.get("Address")
        self._ExpirationDate = params.get("ExpirationDate")
        self._IssuedDate = params.get("IssuedDate")
        self._IssuedCountry = params.get("IssuedCountry")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class IndonesiaIDCard(AbstractModel):
    r"""Indonesia ID card.

    """

    def __init__(self):
        r"""
        :param _NIK: License number
Note: This field may return null, indicating that no valid values can be obtained.
        :type NIK: str
        :param _Nama: Name
Note: This field may return null, indicating that no valid values can be obtained.
        :type Nama: str
        :param _TempatTglLahir: Birth place/Birthday
Note: This field may return null, indicating that no valid values can be obtained.
        :type TempatTglLahir: str
        :param _JenisKelamin: Gender
Note: This field may return null, indicating that no valid values can be obtained.
        :type JenisKelamin: str
        :param _GolDarah: Blood type
Note: This field may return null, indicating that no valid values can be obtained.
        :type GolDarah: str
        :param _Alamat: Address
Note: This field may return null, indicating that no valid values can be obtained.
        :type Alamat: str
        :param _RTRW: Street
Note: This field may return null, indicating that no valid values can be obtained.
        :type RTRW: str
        :param _KelDesa: Village
Note: This field may return null, indicating that no valid values can be obtained.
        :type KelDesa: str
        :param _Kecamatan: Region
Note: This field may return null, indicating that no valid values can be obtained.
        :type Kecamatan: str
        :param _Agama: Religious beliefs
Note: This field may return null, indicating that no valid values can be obtained.
        :type Agama: str
        :param _StatusPerkawinan: Marital status
Note: This field may return null, indicating that no valid values can be obtained.
        :type StatusPerkawinan: str
        :param _Perkerjaan: Job
Note: This field may return null, indicating that no valid values can be obtained.
        :type Perkerjaan: str
        :param _KewargaNegaraan: Nationality
Note: This field may return null, indicating that no valid values can be obtained.
        :type KewargaNegaraan: str
        :param _BerlakuHingga: ID card validity period
Note: This field may return null, indicating that no valid values can be obtained.
        :type BerlakuHingga: str
        :param _IssuedDate: Date of issue
Note: This field may return null, indicating that no valid values can be obtained.
        :type IssuedDate: str
        :param _Provinsi: Province
Note: This field may return null, indicating that no valid values can be obtained.
        :type Provinsi: str
        :param _Kota: City
Note: This field may return null, indicating that no valid values can be obtained.
        :type Kota: str
        """
        self._NIK = None
        self._Nama = None
        self._TempatTglLahir = None
        self._JenisKelamin = None
        self._GolDarah = None
        self._Alamat = None
        self._RTRW = None
        self._KelDesa = None
        self._Kecamatan = None
        self._Agama = None
        self._StatusPerkawinan = None
        self._Perkerjaan = None
        self._KewargaNegaraan = None
        self._BerlakuHingga = None
        self._IssuedDate = None
        self._Provinsi = None
        self._Kota = None

    @property
    def NIK(self):
        r"""License number
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._NIK

    @NIK.setter
    def NIK(self, NIK):
        self._NIK = NIK

    @property
    def Nama(self):
        r"""Name
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Nama

    @Nama.setter
    def Nama(self, Nama):
        self._Nama = Nama

    @property
    def TempatTglLahir(self):
        r"""Birth place/Birthday
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._TempatTglLahir

    @TempatTglLahir.setter
    def TempatTglLahir(self, TempatTglLahir):
        self._TempatTglLahir = TempatTglLahir

    @property
    def JenisKelamin(self):
        r"""Gender
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._JenisKelamin

    @JenisKelamin.setter
    def JenisKelamin(self, JenisKelamin):
        self._JenisKelamin = JenisKelamin

    @property
    def GolDarah(self):
        r"""Blood type
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._GolDarah

    @GolDarah.setter
    def GolDarah(self, GolDarah):
        self._GolDarah = GolDarah

    @property
    def Alamat(self):
        r"""Address
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Alamat

    @Alamat.setter
    def Alamat(self, Alamat):
        self._Alamat = Alamat

    @property
    def RTRW(self):
        r"""Street
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._RTRW

    @RTRW.setter
    def RTRW(self, RTRW):
        self._RTRW = RTRW

    @property
    def KelDesa(self):
        r"""Village
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._KelDesa

    @KelDesa.setter
    def KelDesa(self, KelDesa):
        self._KelDesa = KelDesa

    @property
    def Kecamatan(self):
        r"""Region
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Kecamatan

    @Kecamatan.setter
    def Kecamatan(self, Kecamatan):
        self._Kecamatan = Kecamatan

    @property
    def Agama(self):
        r"""Religious beliefs
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Agama

    @Agama.setter
    def Agama(self, Agama):
        self._Agama = Agama

    @property
    def StatusPerkawinan(self):
        r"""Marital status
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._StatusPerkawinan

    @StatusPerkawinan.setter
    def StatusPerkawinan(self, StatusPerkawinan):
        self._StatusPerkawinan = StatusPerkawinan

    @property
    def Perkerjaan(self):
        r"""Job
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Perkerjaan

    @Perkerjaan.setter
    def Perkerjaan(self, Perkerjaan):
        self._Perkerjaan = Perkerjaan

    @property
    def KewargaNegaraan(self):
        r"""Nationality
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._KewargaNegaraan

    @KewargaNegaraan.setter
    def KewargaNegaraan(self, KewargaNegaraan):
        self._KewargaNegaraan = KewargaNegaraan

    @property
    def BerlakuHingga(self):
        r"""ID card validity period
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._BerlakuHingga

    @BerlakuHingga.setter
    def BerlakuHingga(self, BerlakuHingga):
        self._BerlakuHingga = BerlakuHingga

    @property
    def IssuedDate(self):
        r"""Date of issue
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._IssuedDate

    @IssuedDate.setter
    def IssuedDate(self, IssuedDate):
        self._IssuedDate = IssuedDate

    @property
    def Provinsi(self):
        r"""Province
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Provinsi

    @Provinsi.setter
    def Provinsi(self, Provinsi):
        self._Provinsi = Provinsi

    @property
    def Kota(self):
        r"""City
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Kota

    @Kota.setter
    def Kota(self, Kota):
        self._Kota = Kota


    def _deserialize(self, params):
        self._NIK = params.get("NIK")
        self._Nama = params.get("Nama")
        self._TempatTglLahir = params.get("TempatTglLahir")
        self._JenisKelamin = params.get("JenisKelamin")
        self._GolDarah = params.get("GolDarah")
        self._Alamat = params.get("Alamat")
        self._RTRW = params.get("RTRW")
        self._KelDesa = params.get("KelDesa")
        self._Kecamatan = params.get("Kecamatan")
        self._Agama = params.get("Agama")
        self._StatusPerkawinan = params.get("StatusPerkawinan")
        self._Perkerjaan = params.get("Perkerjaan")
        self._KewargaNegaraan = params.get("KewargaNegaraan")
        self._BerlakuHingga = params.get("BerlakuHingga")
        self._IssuedDate = params.get("IssuedDate")
        self._Provinsi = params.get("Provinsi")
        self._Kota = params.get("Kota")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class InternationalIDPassport(AbstractModel):
    r"""ID cards of Hong Kong (China), Macao (China) and Taiwan (China), and international passport.

    """

    def __init__(self):
        r"""
        :param _LicenseNumber: Passport ID
Note: This field may return null, indicating that no valid values can be obtained.
        :type LicenseNumber: str
        :param _FullName: Full name
Note: This field may return null, indicating that no valid values can be obtained.
        :type FullName: str
        :param _Surname: Last name
Note: This field may return null, indicating that no valid values can be obtained.
        :type Surname: str
        :param _GivenName: First name
Note: This field may return null, indicating that no valid values can be obtained.
        :type GivenName: str
        :param _Birthday: Birthday
Note: This field may return null, indicating that no valid values can be obtained.
        :type Birthday: str
        :param _Sex: Gender (F-Female, M-Male)
Note: This field may return null, indicating that no valid values can be obtained.
        :type Sex: str
        :param _DateOfExpiration: Expiration date
Note: This field may return null, indicating that no valid values can be obtained.
        :type DateOfExpiration: str
        :param _IssuingCountry: Issuing country
Note: This field may return null, indicating that no valid values can be obtained.
        :type IssuingCountry: str
        :param _NationalityCode: Nationality code
Note: This field may return null, indicating that no valid values can be obtained.
        :type NationalityCode: str
        :param _PassportCodeFirst: The first line at the bottom, the MRZ Code sequence
Note: This field may return null, indicating that no valid values can be obtained.
        :type PassportCodeFirst: str
        :param _PassportCodeSecond: The second line at the bottom, the MRZ Code sequence
Note: This field may return null, indicating that no valid values can be obtained.
        :type PassportCodeSecond: str
        """
        self._LicenseNumber = None
        self._FullName = None
        self._Surname = None
        self._GivenName = None
        self._Birthday = None
        self._Sex = None
        self._DateOfExpiration = None
        self._IssuingCountry = None
        self._NationalityCode = None
        self._PassportCodeFirst = None
        self._PassportCodeSecond = None

    @property
    def LicenseNumber(self):
        r"""Passport ID
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._LicenseNumber

    @LicenseNumber.setter
    def LicenseNumber(self, LicenseNumber):
        self._LicenseNumber = LicenseNumber

    @property
    def FullName(self):
        r"""Full name
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._FullName

    @FullName.setter
    def FullName(self, FullName):
        self._FullName = FullName

    @property
    def Surname(self):
        r"""Last name
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Surname

    @Surname.setter
    def Surname(self, Surname):
        self._Surname = Surname

    @property
    def GivenName(self):
        r"""First name
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._GivenName

    @GivenName.setter
    def GivenName(self, GivenName):
        self._GivenName = GivenName

    @property
    def Birthday(self):
        r"""Birthday
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Birthday

    @Birthday.setter
    def Birthday(self, Birthday):
        self._Birthday = Birthday

    @property
    def Sex(self):
        r"""Gender (F-Female, M-Male)
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Sex

    @Sex.setter
    def Sex(self, Sex):
        self._Sex = Sex

    @property
    def DateOfExpiration(self):
        r"""Expiration date
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._DateOfExpiration

    @DateOfExpiration.setter
    def DateOfExpiration(self, DateOfExpiration):
        self._DateOfExpiration = DateOfExpiration

    @property
    def IssuingCountry(self):
        r"""Issuing country
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._IssuingCountry

    @IssuingCountry.setter
    def IssuingCountry(self, IssuingCountry):
        self._IssuingCountry = IssuingCountry

    @property
    def NationalityCode(self):
        r"""Nationality code
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._NationalityCode

    @NationalityCode.setter
    def NationalityCode(self, NationalityCode):
        self._NationalityCode = NationalityCode

    @property
    def PassportCodeFirst(self):
        r"""The first line at the bottom, the MRZ Code sequence
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._PassportCodeFirst

    @PassportCodeFirst.setter
    def PassportCodeFirst(self, PassportCodeFirst):
        self._PassportCodeFirst = PassportCodeFirst

    @property
    def PassportCodeSecond(self):
        r"""The second line at the bottom, the MRZ Code sequence
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._PassportCodeSecond

    @PassportCodeSecond.setter
    def PassportCodeSecond(self, PassportCodeSecond):
        self._PassportCodeSecond = PassportCodeSecond


    def _deserialize(self, params):
        self._LicenseNumber = params.get("LicenseNumber")
        self._FullName = params.get("FullName")
        self._Surname = params.get("Surname")
        self._GivenName = params.get("GivenName")
        self._Birthday = params.get("Birthday")
        self._Sex = params.get("Sex")
        self._DateOfExpiration = params.get("DateOfExpiration")
        self._IssuingCountry = params.get("IssuingCountry")
        self._NationalityCode = params.get("NationalityCode")
        self._PassportCodeFirst = params.get("PassportCodeFirst")
        self._PassportCodeSecond = params.get("PassportCodeSecond")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class JapanIDCard(AbstractModel):
    r"""Japan ID card.

    """

    def __init__(self):
        r"""
        :param _FullName: Full name
Note: This field may return null, indicating that no valid values can be obtained.
        :type FullName: str
        :param _LicenseNumber: License number
Note: This field may return null, indicating that no valid values can be obtained.
        :type LicenseNumber: str
        :param _Age: Age
Note: This field may return null, indicating that no valid values can be obtained.
        :type Age: str
        :param _Birthday: Birthday
Note: This field may return null, indicating that no valid values can be obtained.
        :type Birthday: str
        :param _ExpirationDate: Expire date
Note: This field may return null, indicating that no valid values can be obtained.
        :type ExpirationDate: str
        :param _FormattedAddress: Address
Note: This field may return null, indicating that no valid values can be obtained.
        :type FormattedAddress: str
        """
        self._FullName = None
        self._LicenseNumber = None
        self._Age = None
        self._Birthday = None
        self._ExpirationDate = None
        self._FormattedAddress = None

    @property
    def FullName(self):
        r"""Full name
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._FullName

    @FullName.setter
    def FullName(self, FullName):
        self._FullName = FullName

    @property
    def LicenseNumber(self):
        r"""License number
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._LicenseNumber

    @LicenseNumber.setter
    def LicenseNumber(self, LicenseNumber):
        self._LicenseNumber = LicenseNumber

    @property
    def Age(self):
        r"""Age
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Age

    @Age.setter
    def Age(self, Age):
        self._Age = Age

    @property
    def Birthday(self):
        r"""Birthday
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Birthday

    @Birthday.setter
    def Birthday(self, Birthday):
        self._Birthday = Birthday

    @property
    def ExpirationDate(self):
        r"""Expire date
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._ExpirationDate

    @ExpirationDate.setter
    def ExpirationDate(self, ExpirationDate):
        self._ExpirationDate = ExpirationDate

    @property
    def FormattedAddress(self):
        r"""Address
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._FormattedAddress

    @FormattedAddress.setter
    def FormattedAddress(self, FormattedAddress):
        self._FormattedAddress = FormattedAddress


    def _deserialize(self, params):
        self._FullName = params.get("FullName")
        self._LicenseNumber = params.get("LicenseNumber")
        self._Age = params.get("Age")
        self._Birthday = params.get("Birthday")
        self._ExpirationDate = params.get("ExpirationDate")
        self._FormattedAddress = params.get("FormattedAddress")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class LivenessCompareRequest(AbstractModel):
    r"""LivenessCompare request structure.

    """

    def __init__(self):
        r"""
        :param _LivenessType: Liveness detection type. Valid values: LIP/ACTION/SILENT.
LIP: numeric mode; ACTION: motion mode; SILENT: silent mode. You need to select a mode to input.
        :type LivenessType: str
        :param _ImageBase64: Base64 string of the image for face comparison.
The size of the Base64-encoded image data can be up to 3 MB. JPG and PNG formats are supported.
Please use the standard Base64 encoding scheme (with the "=" padding). For the encoding conventions, please see RFC 4648.

Either the `ImageUrl` or `ImageBase64` of the image must be provided. If both are provided, only `ImageBase64` will be used.
        :type ImageBase64: str
        :param _ImageUrl: URL of the image for face comparison. The size of the downloaded image after Base64 encoding can be up to 3 MB. JPG and PNG formats are supported.

Either the `ImageUrl` or `ImageBase64` of the image must be provided. If both are provided, only `ImageBase64` will be used.

We recommend you store the image in Tencent Cloud, as a Tencent Cloud URL can guarantee higher download speed and stability. The download speed and stability of non-Tencent Cloud URLs may be low.
        :type ImageUrl: str
        :param _ValidateData: Lip mode: set this parameter to a custom 4-digit verification code.
Action mode: set this parameter to a custom action sequence (e.g., `2,1` or `1,2`).
Silent mode: do not pass in this parameter.
        :type ValidateData: str
        :param _Optional: Optional configuration (a JSON string)
{
"BestFrameNum": 2  // Return multiple best screenshots. Value range: [2 10]
}
        :type Optional: str
        :param _VideoBase64: Base64 string of the video for liveness detection.
The size of the Base64-encoded video data can be up to 8 MB. MP4, AVI, and FLV formats are supported.
Please use the standard Base64 encoding scheme (with the "=" padding). For the encoding conventions, please see RFC 4648.

Either the `VideoUrl` or `VideoBase64` of the video must be provided. If both are provided, only `VideoBase64` will be used.
        :type VideoBase64: str
        :param _VideoUrl: URL of the video for liveness detection. The size of the downloaded video after Base64 encoding can be up to 8 MB. It takes no more than 4 seconds to download. MP4, AVI, and FLV formats are supported.

Either the `VideoUrl` or `VideoBase64` of the video must be provided. If both are provided, only `VideoBase64` will be used.

We recommend you store the video in Tencent Cloud, as a Tencent Cloud URL can guarantee higher download speed and stability. The download speed and stability of non-Tencent Cloud URLs may be low.
        :type VideoUrl: str
        """
        self._LivenessType = None
        self._ImageBase64 = None
        self._ImageUrl = None
        self._ValidateData = None
        self._Optional = None
        self._VideoBase64 = None
        self._VideoUrl = None

    @property
    def LivenessType(self):
        r"""Liveness detection type. Valid values: LIP/ACTION/SILENT.
LIP: numeric mode; ACTION: motion mode; SILENT: silent mode. You need to select a mode to input.
        :rtype: str
        """
        return self._LivenessType

    @LivenessType.setter
    def LivenessType(self, LivenessType):
        self._LivenessType = LivenessType

    @property
    def ImageBase64(self):
        r"""Base64 string of the image for face comparison.
The size of the Base64-encoded image data can be up to 3 MB. JPG and PNG formats are supported.
Please use the standard Base64 encoding scheme (with the "=" padding). For the encoding conventions, please see RFC 4648.

Either the `ImageUrl` or `ImageBase64` of the image must be provided. If both are provided, only `ImageBase64` will be used.
        :rtype: str
        """
        return self._ImageBase64

    @ImageBase64.setter
    def ImageBase64(self, ImageBase64):
        self._ImageBase64 = ImageBase64

    @property
    def ImageUrl(self):
        r"""URL of the image for face comparison. The size of the downloaded image after Base64 encoding can be up to 3 MB. JPG and PNG formats are supported.

Either the `ImageUrl` or `ImageBase64` of the image must be provided. If both are provided, only `ImageBase64` will be used.

We recommend you store the image in Tencent Cloud, as a Tencent Cloud URL can guarantee higher download speed and stability. The download speed and stability of non-Tencent Cloud URLs may be low.
        :rtype: str
        """
        return self._ImageUrl

    @ImageUrl.setter
    def ImageUrl(self, ImageUrl):
        self._ImageUrl = ImageUrl

    @property
    def ValidateData(self):
        r"""Lip mode: set this parameter to a custom 4-digit verification code.
Action mode: set this parameter to a custom action sequence (e.g., `2,1` or `1,2`).
Silent mode: do not pass in this parameter.
        :rtype: str
        """
        return self._ValidateData

    @ValidateData.setter
    def ValidateData(self, ValidateData):
        self._ValidateData = ValidateData

    @property
    def Optional(self):
        r"""Optional configuration (a JSON string)
{
"BestFrameNum": 2  // Return multiple best screenshots. Value range: [2 10]
}
        :rtype: str
        """
        return self._Optional

    @Optional.setter
    def Optional(self, Optional):
        self._Optional = Optional

    @property
    def VideoBase64(self):
        r"""Base64 string of the video for liveness detection.
The size of the Base64-encoded video data can be up to 8 MB. MP4, AVI, and FLV formats are supported.
Please use the standard Base64 encoding scheme (with the "=" padding). For the encoding conventions, please see RFC 4648.

Either the `VideoUrl` or `VideoBase64` of the video must be provided. If both are provided, only `VideoBase64` will be used.
        :rtype: str
        """
        return self._VideoBase64

    @VideoBase64.setter
    def VideoBase64(self, VideoBase64):
        self._VideoBase64 = VideoBase64

    @property
    def VideoUrl(self):
        r"""URL of the video for liveness detection. The size of the downloaded video after Base64 encoding can be up to 8 MB. It takes no more than 4 seconds to download. MP4, AVI, and FLV formats are supported.

Either the `VideoUrl` or `VideoBase64` of the video must be provided. If both are provided, only `VideoBase64` will be used.

We recommend you store the video in Tencent Cloud, as a Tencent Cloud URL can guarantee higher download speed and stability. The download speed and stability of non-Tencent Cloud URLs may be low.
        :rtype: str
        """
        return self._VideoUrl

    @VideoUrl.setter
    def VideoUrl(self, VideoUrl):
        self._VideoUrl = VideoUrl


    def _deserialize(self, params):
        self._LivenessType = params.get("LivenessType")
        self._ImageBase64 = params.get("ImageBase64")
        self._ImageUrl = params.get("ImageUrl")
        self._ValidateData = params.get("ValidateData")
        self._Optional = params.get("Optional")
        self._VideoBase64 = params.get("VideoBase64")
        self._VideoUrl = params.get("VideoUrl")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class LivenessCompareResponse(AbstractModel):
    r"""LivenessCompare response structure.

    """

    def __init__(self):
        r"""
        :param _BestFrameBase64: The best screenshot of the video after successful verification. The photo is Base64-encoded and in JPG format.
        :type BestFrameBase64: str
        :param _Sim: Similarity. Value range: [0.00, 100.00]. As a recommendation, when the similarity is greater than or equal to 70, it can be determined that the two faces are of the same person. You can adjust the threshold according to your specific scenario (the FAR at the threshold of 70 is 0.1%, and FAR at the threshold of 80 is 0.01%).
        :type Sim: float
        :param _Result: Service error code. `Success` will be returned for success. For error information, please see the `FailedOperation` section in the error code list below.
        :type Result: str
        :param _Description: Service result description.
        :type Description: str
        :param _BestFrameList: 
        :type BestFrameList: list of str
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._BestFrameBase64 = None
        self._Sim = None
        self._Result = None
        self._Description = None
        self._BestFrameList = None
        self._RequestId = None

    @property
    def BestFrameBase64(self):
        r"""The best screenshot of the video after successful verification. The photo is Base64-encoded and in JPG format.
        :rtype: str
        """
        return self._BestFrameBase64

    @BestFrameBase64.setter
    def BestFrameBase64(self, BestFrameBase64):
        self._BestFrameBase64 = BestFrameBase64

    @property
    def Sim(self):
        r"""Similarity. Value range: [0.00, 100.00]. As a recommendation, when the similarity is greater than or equal to 70, it can be determined that the two faces are of the same person. You can adjust the threshold according to your specific scenario (the FAR at the threshold of 70 is 0.1%, and FAR at the threshold of 80 is 0.01%).
        :rtype: float
        """
        return self._Sim

    @Sim.setter
    def Sim(self, Sim):
        self._Sim = Sim

    @property
    def Result(self):
        r"""Service error code. `Success` will be returned for success. For error information, please see the `FailedOperation` section in the error code list below.
        :rtype: str
        """
        return self._Result

    @Result.setter
    def Result(self, Result):
        self._Result = Result

    @property
    def Description(self):
        r"""Service result description.
        :rtype: str
        """
        return self._Description

    @Description.setter
    def Description(self, Description):
        self._Description = Description

    @property
    def BestFrameList(self):
        r"""
        :rtype: list of str
        """
        return self._BestFrameList

    @BestFrameList.setter
    def BestFrameList(self, BestFrameList):
        self._BestFrameList = BestFrameList

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._BestFrameBase64 = params.get("BestFrameBase64")
        self._Sim = params.get("Sim")
        self._Result = params.get("Result")
        self._Description = params.get("Description")
        self._BestFrameList = params.get("BestFrameList")
        self._RequestId = params.get("RequestId")


class MLIDCard(AbstractModel):
    r"""Malaysia ID card.

    """

    def __init__(self):
        r"""
        :param _Name: Full Name
Note: This field may return null, indicating that no valid values can be obtained.
        :type Name: str
        :param _ID: License number
Note: This field may return null, indicating that no valid values can be obtained.
        :type ID: str
        :param _Sex: Gender
Note: This field may return null, indicating that no valid values can be obtained.
        :type Sex: str
        :param _Address: Address
Note: This field may return null, indicating that no valid values can be obtained.
        :type Address: str
        :param _Type: Lisence type
MyKad ID card
MyPR Permanent resident ID card
MyTentera Military ID card
MyKAS Temporary ID card
POLIS Police ID card
IKAD Labor ID card
MyKid Juvenile ID card
Example: MyKad
        :type Type: str
        :param _Birthday: Birthday (Currently, this filed only supports IKAD labor ID card and MyKad ID card)
Note: This field may return null, indicating that no valid values can be obtained.
        :type Birthday: str
        """
        self._Name = None
        self._ID = None
        self._Sex = None
        self._Address = None
        self._Type = None
        self._Birthday = None

    @property
    def Name(self):
        r"""Full Name
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def ID(self):
        r"""License number
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        self._ID = ID

    @property
    def Sex(self):
        r"""Gender
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Sex

    @Sex.setter
    def Sex(self, Sex):
        self._Sex = Sex

    @property
    def Address(self):
        r"""Address
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Address

    @Address.setter
    def Address(self, Address):
        self._Address = Address

    @property
    def Type(self):
        r"""Lisence type
MyKad ID card
MyPR Permanent resident ID card
MyTentera Military ID card
MyKAS Temporary ID card
POLIS Police ID card
IKAD Labor ID card
MyKid Juvenile ID card
Example: MyKad
        :rtype: str
        """
        return self._Type

    @Type.setter
    def Type(self, Type):
        self._Type = Type

    @property
    def Birthday(self):
        r"""Birthday (Currently, this filed only supports IKAD labor ID card and MyKad ID card)
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Birthday

    @Birthday.setter
    def Birthday(self, Birthday):
        self._Birthday = Birthday


    def _deserialize(self, params):
        self._Name = params.get("Name")
        self._ID = params.get("ID")
        self._Sex = params.get("Sex")
        self._Address = params.get("Address")
        self._Type = params.get("Type")
        self._Birthday = params.get("Birthday")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class MacaoIDCard(AbstractModel):
    r"""Macao (China) IDCard

    """

    def __init__(self):
        r"""
        :param _FirstName: First name
Note: This field may return null, indicating that no valid values can be obtained.
        :type FirstName: str
        :param _LastName: Last name
Note: This field may return null, indicating that no valid values can be obtained.
        :type LastName: str
        :param _Birthday: Birthday
Note: This field may return null, indicating that no valid values can be obtained.
        :type Birthday: str
        :param _ExpirationDate: Expiration date
Note: This field may return null, indicating that no valid values can be obtained.
        :type ExpirationDate: str
        :param _LicenseNumber: License number
Note: This field may return null, indicating that no valid values can be obtained.
        :type LicenseNumber: str
        :param _Sex: Sex
Note: This field may return null, indicating that no valid values can be obtained.
        :type Sex: str
        :param _Age: Age
Note: This field may return null, indicating that no valid values can be obtained.
        :type Age: str
        :param _IssuedCountry: Issued country
Note: This field may return null, indicating that no valid values can be obtained.
        :type IssuedCountry: str
        :param _Field1: MRZ1 on card
Note: This field may return null, indicating that no valid values can be obtained. 
        :type Field1: str
        :param _Field2: MRZ2 on card
Note: This field may return null, indicating that no valid values can be obtained.
        :type Field2: str
        """
        self._FirstName = None
        self._LastName = None
        self._Birthday = None
        self._ExpirationDate = None
        self._LicenseNumber = None
        self._Sex = None
        self._Age = None
        self._IssuedCountry = None
        self._Field1 = None
        self._Field2 = None

    @property
    def FirstName(self):
        r"""First name
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._FirstName

    @FirstName.setter
    def FirstName(self, FirstName):
        self._FirstName = FirstName

    @property
    def LastName(self):
        r"""Last name
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._LastName

    @LastName.setter
    def LastName(self, LastName):
        self._LastName = LastName

    @property
    def Birthday(self):
        r"""Birthday
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Birthday

    @Birthday.setter
    def Birthday(self, Birthday):
        self._Birthday = Birthday

    @property
    def ExpirationDate(self):
        r"""Expiration date
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._ExpirationDate

    @ExpirationDate.setter
    def ExpirationDate(self, ExpirationDate):
        self._ExpirationDate = ExpirationDate

    @property
    def LicenseNumber(self):
        r"""License number
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._LicenseNumber

    @LicenseNumber.setter
    def LicenseNumber(self, LicenseNumber):
        self._LicenseNumber = LicenseNumber

    @property
    def Sex(self):
        r"""Sex
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Sex

    @Sex.setter
    def Sex(self, Sex):
        self._Sex = Sex

    @property
    def Age(self):
        r"""Age
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Age

    @Age.setter
    def Age(self, Age):
        self._Age = Age

    @property
    def IssuedCountry(self):
        r"""Issued country
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._IssuedCountry

    @IssuedCountry.setter
    def IssuedCountry(self, IssuedCountry):
        self._IssuedCountry = IssuedCountry

    @property
    def Field1(self):
        r"""MRZ1 on card
Note: This field may return null, indicating that no valid values can be obtained. 
        :rtype: str
        """
        return self._Field1

    @Field1.setter
    def Field1(self, Field1):
        self._Field1 = Field1

    @property
    def Field2(self):
        r"""MRZ2 on card
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Field2

    @Field2.setter
    def Field2(self, Field2):
        self._Field2 = Field2


    def _deserialize(self, params):
        self._FirstName = params.get("FirstName")
        self._LastName = params.get("LastName")
        self._Birthday = params.get("Birthday")
        self._ExpirationDate = params.get("ExpirationDate")
        self._LicenseNumber = params.get("LicenseNumber")
        self._Sex = params.get("Sex")
        self._Age = params.get("Age")
        self._IssuedCountry = params.get("IssuedCountry")
        self._Field1 = params.get("Field1")
        self._Field2 = params.get("Field2")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class MainlandIDCard(AbstractModel):
    r"""Mainland (China) ID Card OCR

    """

    def __init__(self):
        r"""
        :param _FullName: Chinese name
Note: This field may return null, indicating that no valid values can be obtained.

        :type FullName: str
        :param _Sex: Sex
Note: This field may return null, indicating that no valid values can be obtained.
        :type Sex: str
        :param _Nation: Nation
Note: This field may return null, indicating that no valid values can be obtained.
        :type Nation: str
        :param _Birthday: Birthday
Note: This field may return null, indicating that no valid values can be obtained.
        :type Birthday: str
        :param _Address: Address
Note: This field may return null, indicating that no valid values can be obtained.
        :type Address: str
        :param _LicenseNumber: License number
Note: This field may return null, indicating that no valid values can be obtained.

        :type LicenseNumber: str
        :param _FormattedAddress: Address
Note: This field may return null, indicating that no valid values can be obtained.
        :type FormattedAddress: str
        """
        self._FullName = None
        self._Sex = None
        self._Nation = None
        self._Birthday = None
        self._Address = None
        self._LicenseNumber = None
        self._FormattedAddress = None

    @property
    def FullName(self):
        r"""Chinese name
Note: This field may return null, indicating that no valid values can be obtained.

        :rtype: str
        """
        return self._FullName

    @FullName.setter
    def FullName(self, FullName):
        self._FullName = FullName

    @property
    def Sex(self):
        r"""Sex
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Sex

    @Sex.setter
    def Sex(self, Sex):
        self._Sex = Sex

    @property
    def Nation(self):
        r"""Nation
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Nation

    @Nation.setter
    def Nation(self, Nation):
        self._Nation = Nation

    @property
    def Birthday(self):
        r"""Birthday
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Birthday

    @Birthday.setter
    def Birthday(self, Birthday):
        self._Birthday = Birthday

    @property
    def Address(self):
        warnings.warn("parameter `Address` is deprecated", DeprecationWarning) 

        r"""Address
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Address

    @Address.setter
    def Address(self, Address):
        warnings.warn("parameter `Address` is deprecated", DeprecationWarning) 

        self._Address = Address

    @property
    def LicenseNumber(self):
        r"""License number
Note: This field may return null, indicating that no valid values can be obtained.

        :rtype: str
        """
        return self._LicenseNumber

    @LicenseNumber.setter
    def LicenseNumber(self, LicenseNumber):
        self._LicenseNumber = LicenseNumber

    @property
    def FormattedAddress(self):
        r"""Address
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._FormattedAddress

    @FormattedAddress.setter
    def FormattedAddress(self, FormattedAddress):
        self._FormattedAddress = FormattedAddress


    def _deserialize(self, params):
        self._FullName = params.get("FullName")
        self._Sex = params.get("Sex")
        self._Nation = params.get("Nation")
        self._Birthday = params.get("Birthday")
        self._Address = params.get("Address")
        self._LicenseNumber = params.get("LicenseNumber")
        self._FormattedAddress = params.get("FormattedAddress")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class MobileNetworkTimeVerificationRequest(AbstractModel):
    r"""MobileNetworkTimeVerification request structure.

    """

    def __init__(self):
        r"""
        :param _Mobile: Mobile number.
        :type Mobile: str
        :param _Encryption: Sensitive data encryption info.
-Users with encryption requirements for incoming information (mobile number) can use this parameter. For details, please click the left-side link.
        :type Encryption: :class:`tencentcloud.faceid.v20180301.models.Encryption`
        """
        self._Mobile = None
        self._Encryption = None

    @property
    def Mobile(self):
        r"""Mobile number.
        :rtype: str
        """
        return self._Mobile

    @Mobile.setter
    def Mobile(self, Mobile):
        self._Mobile = Mobile

    @property
    def Encryption(self):
        r"""Sensitive data encryption info.
-Users with encryption requirements for incoming information (mobile number) can use this parameter. For details, please click the left-side link.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.Encryption`
        """
        return self._Encryption

    @Encryption.setter
    def Encryption(self, Encryption):
        self._Encryption = Encryption


    def _deserialize(self, params):
        self._Mobile = params.get("Mobile")
        if params.get("Encryption") is not None:
            self._Encryption = Encryption()
            self._Encryption._deserialize(params.get("Encryption"))
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class MobileNetworkTimeVerificationResponse(AbstractModel):
    r"""MobileNetworkTimeVerification response structure.

    """

    def __init__(self):
        r"""
        :param _Result: Verification result code. Billing is as follows.
-Result code for charges
Success.
-2: Mobile number does not exist.
-3: The mobile number exists, but unable to query the duration.

-Result code with no charge
-Invalid phone number format.
-4: Verification Center Service is busy.
-5: Authentication attempts exceeded the daily limit. Retry the next day.
        :type Result: str
        :param _Description: Business result description.
        :type Description: str
        :param _Range: Online duration interval.
-The format is [a,b), which means the online duration is longer than a months and shorter than b months.
-If b is +, it means no upper limit.
        :type Range: str
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._Result = None
        self._Description = None
        self._Range = None
        self._RequestId = None

    @property
    def Result(self):
        r"""Verification result code. Billing is as follows.
-Result code for charges
Success.
-2: Mobile number does not exist.
-3: The mobile number exists, but unable to query the duration.

-Result code with no charge
-Invalid phone number format.
-4: Verification Center Service is busy.
-5: Authentication attempts exceeded the daily limit. Retry the next day.
        :rtype: str
        """
        return self._Result

    @Result.setter
    def Result(self, Result):
        self._Result = Result

    @property
    def Description(self):
        r"""Business result description.
        :rtype: str
        """
        return self._Description

    @Description.setter
    def Description(self, Description):
        self._Description = Description

    @property
    def Range(self):
        r"""Online duration interval.
-The format is [a,b), which means the online duration is longer than a months and shorter than b months.
-If b is +, it means no upper limit.
        :rtype: str
        """
        return self._Range

    @Range.setter
    def Range(self, Range):
        self._Range = Range

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._Result = params.get("Result")
        self._Description = params.get("Description")
        self._Range = params.get("Range")
        self._RequestId = params.get("RequestId")


class MobileStatusRequest(AbstractModel):
    r"""MobileStatus request structure.

    """

    def __init__(self):
        r"""
        :param _Mobile: Mobile number.
        :type Mobile: str
        :param _Encryption: Sensitive data encryption info.
-Users with encryption requirements for incoming information (mobile number) can use this parameter. For details, please click the left-side link.
        :type Encryption: :class:`tencentcloud.faceid.v20180301.models.Encryption`
        """
        self._Mobile = None
        self._Encryption = None

    @property
    def Mobile(self):
        r"""Mobile number.
        :rtype: str
        """
        return self._Mobile

    @Mobile.setter
    def Mobile(self, Mobile):
        self._Mobile = Mobile

    @property
    def Encryption(self):
        r"""Sensitive data encryption info.
-Users with encryption requirements for incoming information (mobile number) can use this parameter. For details, please click the left-side link.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.Encryption`
        """
        return self._Encryption

    @Encryption.setter
    def Encryption(self, Encryption):
        self._Encryption = Encryption


    def _deserialize(self, params):
        self._Mobile = params.get("Mobile")
        if params.get("Encryption") is not None:
            self._Encryption = Encryption()
            self._Encryption._deserialize(params.get("Encryption"))
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class MobileStatusResponse(AbstractModel):
    r"""MobileStatus response structure.

    """

    def __init__(self):
        r"""
        :param _Result: Verification result code. Billing is as follows.
-Result code for charges
0: Success.

-Result code with no charge
-No results found.
-2: Invalid phone number format.
-3: Verification Center Service is busy.
-4: Authentication attempts exceeded the daily limit. Retry the next day.
        :type Result: str
        :param _Description: Business result description.
        :type Description: str
        :param _StatusCode: Status code.
-Value range:
0: Normal.
1: Out of service.
2: Account cancellation.
4: Offline.
99: unknown status.
        :type StatusCode: int
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._Result = None
        self._Description = None
        self._StatusCode = None
        self._RequestId = None

    @property
    def Result(self):
        r"""Verification result code. Billing is as follows.
-Result code for charges
0: Success.

-Result code with no charge
-No results found.
-2: Invalid phone number format.
-3: Verification Center Service is busy.
-4: Authentication attempts exceeded the daily limit. Retry the next day.
        :rtype: str
        """
        return self._Result

    @Result.setter
    def Result(self, Result):
        self._Result = Result

    @property
    def Description(self):
        r"""Business result description.
        :rtype: str
        """
        return self._Description

    @Description.setter
    def Description(self, Description):
        self._Description = Description

    @property
    def StatusCode(self):
        r"""Status code.
-Value range:
0: Normal.
1: Out of service.
2: Account cancellation.
4: Offline.
99: unknown status.
        :rtype: int
        """
        return self._StatusCode

    @StatusCode.setter
    def StatusCode(self, StatusCode):
        self._StatusCode = StatusCode

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._Result = params.get("Result")
        self._Description = params.get("Description")
        self._StatusCode = params.get("StatusCode")
        self._RequestId = params.get("RequestId")


class NigeriaDrivingLicense(AbstractModel):
    r"""Nigeria driving license

    """

    def __init__(self):
        r"""
        :param _LastName: Last name.
Note: This field may return null, indicating that no valid values can be obtained.

        :type LastName: str
        :param _FirstName: First name.
Note: This field may return null, indicating that no valid values can be obtained.
        :type FirstName: str
        :param _LicenseNumber: License number.
Note: This field may return null, indicating that no valid values can be obtained.
        :type LicenseNumber: str
        :param _Age: Age.
Note: This field may return null, indicating that no valid values can be obtained.
        :type Age: str
        :param _Birthday: Birthday.
Note: This field may return null, indicating that no valid values can be obtained.
        :type Birthday: str
        :param _IssuedCountry: Issued country.
Note: This field may return null, indicating that no valid values can be obtained.
        :type IssuedCountry: str
        :param _ExpirationDate: Expiration date.
Note: This field may return null, indicating that no valid values can be obtained.
        :type ExpirationDate: str
        :param _IssuedDate: Issued date.
Note: This field may return null, indicating that no valid values can be obtained.
        :type IssuedDate: str
        :param _Sex: Gender.
Note: This field may return null, indicating that no valid values can be obtained.
        :type Sex: str
        """
        self._LastName = None
        self._FirstName = None
        self._LicenseNumber = None
        self._Age = None
        self._Birthday = None
        self._IssuedCountry = None
        self._ExpirationDate = None
        self._IssuedDate = None
        self._Sex = None

    @property
    def LastName(self):
        r"""Last name.
Note: This field may return null, indicating that no valid values can be obtained.

        :rtype: str
        """
        return self._LastName

    @LastName.setter
    def LastName(self, LastName):
        self._LastName = LastName

    @property
    def FirstName(self):
        r"""First name.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._FirstName

    @FirstName.setter
    def FirstName(self, FirstName):
        self._FirstName = FirstName

    @property
    def LicenseNumber(self):
        r"""License number.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._LicenseNumber

    @LicenseNumber.setter
    def LicenseNumber(self, LicenseNumber):
        self._LicenseNumber = LicenseNumber

    @property
    def Age(self):
        r"""Age.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Age

    @Age.setter
    def Age(self, Age):
        self._Age = Age

    @property
    def Birthday(self):
        r"""Birthday.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Birthday

    @Birthday.setter
    def Birthday(self, Birthday):
        self._Birthday = Birthday

    @property
    def IssuedCountry(self):
        r"""Issued country.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._IssuedCountry

    @IssuedCountry.setter
    def IssuedCountry(self, IssuedCountry):
        self._IssuedCountry = IssuedCountry

    @property
    def ExpirationDate(self):
        r"""Expiration date.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._ExpirationDate

    @ExpirationDate.setter
    def ExpirationDate(self, ExpirationDate):
        self._ExpirationDate = ExpirationDate

    @property
    def IssuedDate(self):
        r"""Issued date.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._IssuedDate

    @IssuedDate.setter
    def IssuedDate(self, IssuedDate):
        self._IssuedDate = IssuedDate

    @property
    def Sex(self):
        r"""Gender.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Sex

    @Sex.setter
    def Sex(self, Sex):
        self._Sex = Sex


    def _deserialize(self, params):
        self._LastName = params.get("LastName")
        self._FirstName = params.get("FirstName")
        self._LicenseNumber = params.get("LicenseNumber")
        self._Age = params.get("Age")
        self._Birthday = params.get("Birthday")
        self._IssuedCountry = params.get("IssuedCountry")
        self._ExpirationDate = params.get("ExpirationDate")
        self._IssuedDate = params.get("IssuedDate")
        self._Sex = params.get("Sex")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class NigeriaIDCard(AbstractModel):
    r"""Nigeria ID card

    """

    def __init__(self):
        r"""
        :param _LastName: Last name.
Note: This field may return null, indicating that no valid values can be obtained.
        :type LastName: str
        :param _FirstName: First name.
Note: This field may return null, indicating that no valid values can be obtained.
        :type FirstName: str
        :param _LicenseNumber: License number.
Note: This field may return null, indicating that no valid values can be obtained.
        :type LicenseNumber: str
        :param _Age: Age.
Note: This field may return null, indicating that no valid values can be obtained.
        :type Age: str
        :param _Birthday: Birthday.
Note: This field may return null, indicating that no valid values can be obtained.
        :type Birthday: str
        :param _IssuedCountry: Issued country.
Note: This field may return null, indicating that no valid values can be obtained.
        :type IssuedCountry: str
        :param _Sex: Gender.
Note: This field may return null, indicating that no valid values can be obtained.
        :type Sex: str
        """
        self._LastName = None
        self._FirstName = None
        self._LicenseNumber = None
        self._Age = None
        self._Birthday = None
        self._IssuedCountry = None
        self._Sex = None

    @property
    def LastName(self):
        r"""Last name.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._LastName

    @LastName.setter
    def LastName(self, LastName):
        self._LastName = LastName

    @property
    def FirstName(self):
        r"""First name.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._FirstName

    @FirstName.setter
    def FirstName(self, FirstName):
        self._FirstName = FirstName

    @property
    def LicenseNumber(self):
        r"""License number.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._LicenseNumber

    @LicenseNumber.setter
    def LicenseNumber(self, LicenseNumber):
        self._LicenseNumber = LicenseNumber

    @property
    def Age(self):
        r"""Age.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Age

    @Age.setter
    def Age(self, Age):
        self._Age = Age

    @property
    def Birthday(self):
        r"""Birthday.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Birthday

    @Birthday.setter
    def Birthday(self, Birthday):
        self._Birthday = Birthday

    @property
    def IssuedCountry(self):
        r"""Issued country.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._IssuedCountry

    @IssuedCountry.setter
    def IssuedCountry(self, IssuedCountry):
        self._IssuedCountry = IssuedCountry

    @property
    def Sex(self):
        r"""Gender.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Sex

    @Sex.setter
    def Sex(self, Sex):
        self._Sex = Sex


    def _deserialize(self, params):
        self._LastName = params.get("LastName")
        self._FirstName = params.get("FirstName")
        self._LicenseNumber = params.get("LicenseNumber")
        self._Age = params.get("Age")
        self._Birthday = params.get("Birthday")
        self._IssuedCountry = params.get("IssuedCountry")
        self._Sex = params.get("Sex")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class NormalCardInfo(AbstractModel):
    r"""License OCR result

    """

    def __init__(self):
        r"""
        :param _HKIDCard: Hong Kong (China) ID Card
Note: This field may return null, indicating that no valid values can be obtained.
        :type HKIDCard: :class:`tencentcloud.faceid.v20180301.models.NormalHKIDCard`
        :param _MLIDCard: Malaysia ID Card
Note: This field may return null, indicating that no valid values can be obtained.
        :type MLIDCard: :class:`tencentcloud.faceid.v20180301.models.NormalMLIDCard`
        :param _PhilippinesVoteID: Philippines VoteID Card
Note: This field may return null, indicating that no valid values can be obtained.
        :type PhilippinesVoteID: :class:`tencentcloud.faceid.v20180301.models.PhilippinesVoteID`
        :param _IndonesiaIDCard: Indonesia ID Card
Note: This field may return null, indicating that no valid values can be obtained.
        :type IndonesiaIDCard: :class:`tencentcloud.faceid.v20180301.models.NormalIndonesiaIDCard`
        :param _PhilippinesDrivingLicense: Philippines Driving License
Note: This field may return null, indicating that no valid values can be obtained.
        :type PhilippinesDrivingLicense: :class:`tencentcloud.faceid.v20180301.models.PhilippinesDrivingLicense`
        :param _PhilippinesTinID: Philippines TinID
Note: This field may return null, indicating that no valid values can be obtained.
        :type PhilippinesTinID: :class:`tencentcloud.faceid.v20180301.models.PhilippinesTinID`
        :param _PhilippinesSSSID: Philippines SSSID
Note: This field may return null, indicating that no valid values can be obtained.
        :type PhilippinesSSSID: :class:`tencentcloud.faceid.v20180301.models.PhilippinesSSSID`
        :param _PhilippinesUMID: Philippines UMID
Note: This field may return null, indicating that no valid values can be obtained.
        :type PhilippinesUMID: :class:`tencentcloud.faceid.v20180301.models.PhilippinesUMID`
        :param _InternationalIDPassport: ID Cards of Hong Kong (China), Macao (China) and Taiwan (China), and International Passport
Note: This field may return null, indicating that no valid values can be obtained.
        :type InternationalIDPassport: :class:`tencentcloud.faceid.v20180301.models.InternationalIDPassport`
        :param _GeneralCard: General license information
Note: This field may return null, indicating that no valid values can be obtained.
        :type GeneralCard: :class:`tencentcloud.faceid.v20180301.models.GeneralCard`
        :param _IndonesiaDrivingLicense: Indonesia Driving License
Note: This field may return null, indicating that no valid values can be obtained.
        :type IndonesiaDrivingLicense: :class:`tencentcloud.faceid.v20180301.models.IndonesiaDrivingLicense`
        :param _ThailandIDCard: Thailand ID Card
Note: This field may return null, indicating that no valid values can be obtained.
        :type ThailandIDCard: :class:`tencentcloud.faceid.v20180301.models.NormalThailandIDCard`
        :param _SingaporeIDCard: Singapore ID Card
Note: This field may return null, indicating that no valid values can be obtained.
        :type SingaporeIDCard: :class:`tencentcloud.faceid.v20180301.models.SingaporeIDCard`
        :param _MacaoIDCard: Macao (China) ID Card
Note: This field may return null, indicating that no valid values can be obtained.
        :type MacaoIDCard: :class:`tencentcloud.faceid.v20180301.models.MacaoIDCard`
        :param _MainlandIDCard: Mainland (China) ID Card
Note: This field may return null, indicating that no valid values can be obtained.
        :type MainlandIDCard: :class:`tencentcloud.faceid.v20180301.models.MainlandIDCard`
        :param _JapanIDCard: Japan ID Card
Note: This field may return null, indicating that no valid values can be obtained.
        :type JapanIDCard: :class:`tencentcloud.faceid.v20180301.models.JapanIDCard`
        :param _TaiWanIDCard: Taiwan (China) ID Card
Note: This field may return null, indicating that no valid values can be obtained.
        :type TaiWanIDCard: :class:`tencentcloud.faceid.v20180301.models.TaiWanIDCard`
        :param _HMTPermitCard: exit/entry permit (card) for traveling to and from Hong Kong (China), Macao (China), or Taiwan (China).
Note: This field may return null, indicating that no valid values can be obtained.
        :type HMTPermitCard: :class:`tencentcloud.faceid.v20180301.models.HMTPermit`
        """
        self._HKIDCard = None
        self._MLIDCard = None
        self._PhilippinesVoteID = None
        self._IndonesiaIDCard = None
        self._PhilippinesDrivingLicense = None
        self._PhilippinesTinID = None
        self._PhilippinesSSSID = None
        self._PhilippinesUMID = None
        self._InternationalIDPassport = None
        self._GeneralCard = None
        self._IndonesiaDrivingLicense = None
        self._ThailandIDCard = None
        self._SingaporeIDCard = None
        self._MacaoIDCard = None
        self._MainlandIDCard = None
        self._JapanIDCard = None
        self._TaiWanIDCard = None
        self._HMTPermitCard = None

    @property
    def HKIDCard(self):
        r"""Hong Kong (China) ID Card
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.NormalHKIDCard`
        """
        return self._HKIDCard

    @HKIDCard.setter
    def HKIDCard(self, HKIDCard):
        self._HKIDCard = HKIDCard

    @property
    def MLIDCard(self):
        r"""Malaysia ID Card
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.NormalMLIDCard`
        """
        return self._MLIDCard

    @MLIDCard.setter
    def MLIDCard(self, MLIDCard):
        self._MLIDCard = MLIDCard

    @property
    def PhilippinesVoteID(self):
        r"""Philippines VoteID Card
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.PhilippinesVoteID`
        """
        return self._PhilippinesVoteID

    @PhilippinesVoteID.setter
    def PhilippinesVoteID(self, PhilippinesVoteID):
        self._PhilippinesVoteID = PhilippinesVoteID

    @property
    def IndonesiaIDCard(self):
        r"""Indonesia ID Card
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.NormalIndonesiaIDCard`
        """
        return self._IndonesiaIDCard

    @IndonesiaIDCard.setter
    def IndonesiaIDCard(self, IndonesiaIDCard):
        self._IndonesiaIDCard = IndonesiaIDCard

    @property
    def PhilippinesDrivingLicense(self):
        r"""Philippines Driving License
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.PhilippinesDrivingLicense`
        """
        return self._PhilippinesDrivingLicense

    @PhilippinesDrivingLicense.setter
    def PhilippinesDrivingLicense(self, PhilippinesDrivingLicense):
        self._PhilippinesDrivingLicense = PhilippinesDrivingLicense

    @property
    def PhilippinesTinID(self):
        r"""Philippines TinID
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.PhilippinesTinID`
        """
        return self._PhilippinesTinID

    @PhilippinesTinID.setter
    def PhilippinesTinID(self, PhilippinesTinID):
        self._PhilippinesTinID = PhilippinesTinID

    @property
    def PhilippinesSSSID(self):
        r"""Philippines SSSID
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.PhilippinesSSSID`
        """
        return self._PhilippinesSSSID

    @PhilippinesSSSID.setter
    def PhilippinesSSSID(self, PhilippinesSSSID):
        self._PhilippinesSSSID = PhilippinesSSSID

    @property
    def PhilippinesUMID(self):
        r"""Philippines UMID
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.PhilippinesUMID`
        """
        return self._PhilippinesUMID

    @PhilippinesUMID.setter
    def PhilippinesUMID(self, PhilippinesUMID):
        self._PhilippinesUMID = PhilippinesUMID

    @property
    def InternationalIDPassport(self):
        r"""ID Cards of Hong Kong (China), Macao (China) and Taiwan (China), and International Passport
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.InternationalIDPassport`
        """
        return self._InternationalIDPassport

    @InternationalIDPassport.setter
    def InternationalIDPassport(self, InternationalIDPassport):
        self._InternationalIDPassport = InternationalIDPassport

    @property
    def GeneralCard(self):
        r"""General license information
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.GeneralCard`
        """
        return self._GeneralCard

    @GeneralCard.setter
    def GeneralCard(self, GeneralCard):
        self._GeneralCard = GeneralCard

    @property
    def IndonesiaDrivingLicense(self):
        r"""Indonesia Driving License
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.IndonesiaDrivingLicense`
        """
        return self._IndonesiaDrivingLicense

    @IndonesiaDrivingLicense.setter
    def IndonesiaDrivingLicense(self, IndonesiaDrivingLicense):
        self._IndonesiaDrivingLicense = IndonesiaDrivingLicense

    @property
    def ThailandIDCard(self):
        r"""Thailand ID Card
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.NormalThailandIDCard`
        """
        return self._ThailandIDCard

    @ThailandIDCard.setter
    def ThailandIDCard(self, ThailandIDCard):
        self._ThailandIDCard = ThailandIDCard

    @property
    def SingaporeIDCard(self):
        r"""Singapore ID Card
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.SingaporeIDCard`
        """
        return self._SingaporeIDCard

    @SingaporeIDCard.setter
    def SingaporeIDCard(self, SingaporeIDCard):
        self._SingaporeIDCard = SingaporeIDCard

    @property
    def MacaoIDCard(self):
        r"""Macao (China) ID Card
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.MacaoIDCard`
        """
        return self._MacaoIDCard

    @MacaoIDCard.setter
    def MacaoIDCard(self, MacaoIDCard):
        self._MacaoIDCard = MacaoIDCard

    @property
    def MainlandIDCard(self):
        r"""Mainland (China) ID Card
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.MainlandIDCard`
        """
        return self._MainlandIDCard

    @MainlandIDCard.setter
    def MainlandIDCard(self, MainlandIDCard):
        self._MainlandIDCard = MainlandIDCard

    @property
    def JapanIDCard(self):
        r"""Japan ID Card
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.JapanIDCard`
        """
        return self._JapanIDCard

    @JapanIDCard.setter
    def JapanIDCard(self, JapanIDCard):
        self._JapanIDCard = JapanIDCard

    @property
    def TaiWanIDCard(self):
        r"""Taiwan (China) ID Card
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.TaiWanIDCard`
        """
        return self._TaiWanIDCard

    @TaiWanIDCard.setter
    def TaiWanIDCard(self, TaiWanIDCard):
        self._TaiWanIDCard = TaiWanIDCard

    @property
    def HMTPermitCard(self):
        r"""exit/entry permit (card) for traveling to and from Hong Kong (China), Macao (China), or Taiwan (China).
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.HMTPermit`
        """
        return self._HMTPermitCard

    @HMTPermitCard.setter
    def HMTPermitCard(self, HMTPermitCard):
        self._HMTPermitCard = HMTPermitCard


    def _deserialize(self, params):
        if params.get("HKIDCard") is not None:
            self._HKIDCard = NormalHKIDCard()
            self._HKIDCard._deserialize(params.get("HKIDCard"))
        if params.get("MLIDCard") is not None:
            self._MLIDCard = NormalMLIDCard()
            self._MLIDCard._deserialize(params.get("MLIDCard"))
        if params.get("PhilippinesVoteID") is not None:
            self._PhilippinesVoteID = PhilippinesVoteID()
            self._PhilippinesVoteID._deserialize(params.get("PhilippinesVoteID"))
        if params.get("IndonesiaIDCard") is not None:
            self._IndonesiaIDCard = NormalIndonesiaIDCard()
            self._IndonesiaIDCard._deserialize(params.get("IndonesiaIDCard"))
        if params.get("PhilippinesDrivingLicense") is not None:
            self._PhilippinesDrivingLicense = PhilippinesDrivingLicense()
            self._PhilippinesDrivingLicense._deserialize(params.get("PhilippinesDrivingLicense"))
        if params.get("PhilippinesTinID") is not None:
            self._PhilippinesTinID = PhilippinesTinID()
            self._PhilippinesTinID._deserialize(params.get("PhilippinesTinID"))
        if params.get("PhilippinesSSSID") is not None:
            self._PhilippinesSSSID = PhilippinesSSSID()
            self._PhilippinesSSSID._deserialize(params.get("PhilippinesSSSID"))
        if params.get("PhilippinesUMID") is not None:
            self._PhilippinesUMID = PhilippinesUMID()
            self._PhilippinesUMID._deserialize(params.get("PhilippinesUMID"))
        if params.get("InternationalIDPassport") is not None:
            self._InternationalIDPassport = InternationalIDPassport()
            self._InternationalIDPassport._deserialize(params.get("InternationalIDPassport"))
        if params.get("GeneralCard") is not None:
            self._GeneralCard = GeneralCard()
            self._GeneralCard._deserialize(params.get("GeneralCard"))
        if params.get("IndonesiaDrivingLicense") is not None:
            self._IndonesiaDrivingLicense = IndonesiaDrivingLicense()
            self._IndonesiaDrivingLicense._deserialize(params.get("IndonesiaDrivingLicense"))
        if params.get("ThailandIDCard") is not None:
            self._ThailandIDCard = NormalThailandIDCard()
            self._ThailandIDCard._deserialize(params.get("ThailandIDCard"))
        if params.get("SingaporeIDCard") is not None:
            self._SingaporeIDCard = SingaporeIDCard()
            self._SingaporeIDCard._deserialize(params.get("SingaporeIDCard"))
        if params.get("MacaoIDCard") is not None:
            self._MacaoIDCard = MacaoIDCard()
            self._MacaoIDCard._deserialize(params.get("MacaoIDCard"))
        if params.get("MainlandIDCard") is not None:
            self._MainlandIDCard = MainlandIDCard()
            self._MainlandIDCard._deserialize(params.get("MainlandIDCard"))
        if params.get("JapanIDCard") is not None:
            self._JapanIDCard = JapanIDCard()
            self._JapanIDCard._deserialize(params.get("JapanIDCard"))
        if params.get("TaiWanIDCard") is not None:
            self._TaiWanIDCard = TaiWanIDCard()
            self._TaiWanIDCard._deserialize(params.get("TaiWanIDCard"))
        if params.get("HMTPermitCard") is not None:
            self._HMTPermitCard = HMTPermit()
            self._HMTPermitCard._deserialize(params.get("HMTPermitCard"))
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class NormalHKIDCard(AbstractModel):
    r"""Hong Kong (China) ID card.

    """

    def __init__(self):
        r"""
        :param _ChineseName: Chinese name
Note: This field may return null, indicating that no valid values can be obtained.

        :type ChineseName: str
        :param _FullName: English name
Note: This field may return null, indicating that no valid values can be obtained.
Example: SAN, Nan
        :type FullName: str
        :param _RegistrationNumber: Telex code correspondint to the Chinese name
Note: This field may return null, indicating that no valid values can be obtained.
        :type RegistrationNumber: str
        :param _Sex: Gender: "Male-M" or "Female-F"
Note: This field may return null, indicating that no valid values can be obtained.
        :type Sex: str
        :param _Birthday: Birthday
Note: This field may return null, indicating that no valid values can be obtained.
Example: 01-01-2001
        :type Birthday: str
        :param _Permanent: Permanent resident ID card: 0-non-permanent; 1-permanent; -1-unknown
Note: This field may return null, indicating that no valid values can be obtained.
        :type Permanent: str
        :param _LicenseNumber: ID card number
Note: This field may return null, indicating that no valid values can be obtained.
Example: C000000(E)
        :type LicenseNumber: str
        :param _Symbol: Lisence symbol, which is the symbol below Birthday. Example: "***AZ"
Note: This field may return null, indicating that no valid values can be obtained.
        :type Symbol: str
        :param _IssuedDate: The first date of issue
Note: This field may return null, indicating that no valid values can be obtained.
        :type IssuedDate: str
        :param _CurrentIssueDate: The current date of issue
Note: This field may return null, indicating that no valid values can be obtained.
        :type CurrentIssueDate: str
        :param _HKIDVersion: Hong kong identity card version.
Note: This field may return null, indicating that no valid values can be obtained.
        :type HKIDVersion: str
        """
        self._ChineseName = None
        self._FullName = None
        self._RegistrationNumber = None
        self._Sex = None
        self._Birthday = None
        self._Permanent = None
        self._LicenseNumber = None
        self._Symbol = None
        self._IssuedDate = None
        self._CurrentIssueDate = None
        self._HKIDVersion = None

    @property
    def ChineseName(self):
        r"""Chinese name
Note: This field may return null, indicating that no valid values can be obtained.

        :rtype: str
        """
        return self._ChineseName

    @ChineseName.setter
    def ChineseName(self, ChineseName):
        self._ChineseName = ChineseName

    @property
    def FullName(self):
        r"""English name
Note: This field may return null, indicating that no valid values can be obtained.
Example: SAN, Nan
        :rtype: str
        """
        return self._FullName

    @FullName.setter
    def FullName(self, FullName):
        self._FullName = FullName

    @property
    def RegistrationNumber(self):
        r"""Telex code correspondint to the Chinese name
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._RegistrationNumber

    @RegistrationNumber.setter
    def RegistrationNumber(self, RegistrationNumber):
        self._RegistrationNumber = RegistrationNumber

    @property
    def Sex(self):
        r"""Gender: "Male-M" or "Female-F"
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Sex

    @Sex.setter
    def Sex(self, Sex):
        self._Sex = Sex

    @property
    def Birthday(self):
        r"""Birthday
Note: This field may return null, indicating that no valid values can be obtained.
Example: 01-01-2001
        :rtype: str
        """
        return self._Birthday

    @Birthday.setter
    def Birthday(self, Birthday):
        self._Birthday = Birthday

    @property
    def Permanent(self):
        r"""Permanent resident ID card: 0-non-permanent; 1-permanent; -1-unknown
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Permanent

    @Permanent.setter
    def Permanent(self, Permanent):
        self._Permanent = Permanent

    @property
    def LicenseNumber(self):
        r"""ID card number
Note: This field may return null, indicating that no valid values can be obtained.
Example: C000000(E)
        :rtype: str
        """
        return self._LicenseNumber

    @LicenseNumber.setter
    def LicenseNumber(self, LicenseNumber):
        self._LicenseNumber = LicenseNumber

    @property
    def Symbol(self):
        r"""Lisence symbol, which is the symbol below Birthday. Example: "***AZ"
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Symbol

    @Symbol.setter
    def Symbol(self, Symbol):
        self._Symbol = Symbol

    @property
    def IssuedDate(self):
        r"""The first date of issue
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._IssuedDate

    @IssuedDate.setter
    def IssuedDate(self, IssuedDate):
        self._IssuedDate = IssuedDate

    @property
    def CurrentIssueDate(self):
        r"""The current date of issue
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._CurrentIssueDate

    @CurrentIssueDate.setter
    def CurrentIssueDate(self, CurrentIssueDate):
        self._CurrentIssueDate = CurrentIssueDate

    @property
    def HKIDVersion(self):
        r"""Hong kong identity card version.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._HKIDVersion

    @HKIDVersion.setter
    def HKIDVersion(self, HKIDVersion):
        self._HKIDVersion = HKIDVersion


    def _deserialize(self, params):
        self._ChineseName = params.get("ChineseName")
        self._FullName = params.get("FullName")
        self._RegistrationNumber = params.get("RegistrationNumber")
        self._Sex = params.get("Sex")
        self._Birthday = params.get("Birthday")
        self._Permanent = params.get("Permanent")
        self._LicenseNumber = params.get("LicenseNumber")
        self._Symbol = params.get("Symbol")
        self._IssuedDate = params.get("IssuedDate")
        self._CurrentIssueDate = params.get("CurrentIssueDate")
        self._HKIDVersion = params.get("HKIDVersion")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class NormalIndonesiaIDCard(AbstractModel):
    r"""Indonesia ID card.

    """

    def __init__(self):
        r"""
        :param _LicenseNumber: License number
Note: This field may return null, indicating that no valid values can be obtained.
        :type LicenseNumber: str
        :param _FullName: Name
Note: This field may return null, indicating that no valid values can be obtained.
        :type FullName: str
        :param _Birthday: Birth place/Birthday
Note: This field may return null, indicating that no valid values can be obtained.
        :type Birthday: str
        :param _Sex: Gender
Note: This field may return null, indicating that no valid values can be obtained.
        :type Sex: str
        :param _BloodType: Blood type
Note: This field may return null, indicating that no valid values can be obtained.
        :type BloodType: str
        :param _FormattedAddress: Address
Note: This field may return null, indicating that no valid values can be obtained.
        :type FormattedAddress: str
        :param _Street: Street
Note: This field may return null, indicating that no valid values can be obtained.
        :type Street: str
        :param _Village: Village
Note: This field may return null, indicating that no valid values can be obtained.
        :type Village: str
        :param _Area: Region
Note: This field may return null, indicating that no valid values can be obtained.
        :type Area: str
        :param _Religion: Religious beliefs
Note: This field may return null, indicating that no valid values can be obtained.
        :type Religion: str
        :param _MaritalStatus: Marital status
Note: This field may return null, indicating that no valid values can be obtained.
        :type MaritalStatus: str
        :param _Occupation: Job
Note: This field may return null, indicating that no valid values can be obtained.
        :type Occupation: str
        :param _Nationality: Nationality
Note: This field may return null, indicating that no valid values can be obtained.
        :type Nationality: str
        :param _DueDate: ID card validity period
Note: This field may return null, indicating that no valid values can be obtained.
        :type DueDate: str
        :param _IssuedDate: Date of issue
Note: This field may return null, indicating that no valid values can be obtained.
        :type IssuedDate: str
        :param _Province: Province
Note: This field may return null, indicating that no valid values can be obtained.
        :type Province: str
        :param _City: City
Note: This field may return null, indicating that no valid values can be obtained.
        :type City: str
        """
        self._LicenseNumber = None
        self._FullName = None
        self._Birthday = None
        self._Sex = None
        self._BloodType = None
        self._FormattedAddress = None
        self._Street = None
        self._Village = None
        self._Area = None
        self._Religion = None
        self._MaritalStatus = None
        self._Occupation = None
        self._Nationality = None
        self._DueDate = None
        self._IssuedDate = None
        self._Province = None
        self._City = None

    @property
    def LicenseNumber(self):
        r"""License number
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._LicenseNumber

    @LicenseNumber.setter
    def LicenseNumber(self, LicenseNumber):
        self._LicenseNumber = LicenseNumber

    @property
    def FullName(self):
        r"""Name
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._FullName

    @FullName.setter
    def FullName(self, FullName):
        self._FullName = FullName

    @property
    def Birthday(self):
        r"""Birth place/Birthday
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Birthday

    @Birthday.setter
    def Birthday(self, Birthday):
        self._Birthday = Birthday

    @property
    def Sex(self):
        r"""Gender
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Sex

    @Sex.setter
    def Sex(self, Sex):
        self._Sex = Sex

    @property
    def BloodType(self):
        r"""Blood type
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._BloodType

    @BloodType.setter
    def BloodType(self, BloodType):
        self._BloodType = BloodType

    @property
    def FormattedAddress(self):
        r"""Address
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._FormattedAddress

    @FormattedAddress.setter
    def FormattedAddress(self, FormattedAddress):
        self._FormattedAddress = FormattedAddress

    @property
    def Street(self):
        r"""Street
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Street

    @Street.setter
    def Street(self, Street):
        self._Street = Street

    @property
    def Village(self):
        r"""Village
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Village

    @Village.setter
    def Village(self, Village):
        self._Village = Village

    @property
    def Area(self):
        r"""Region
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Area

    @Area.setter
    def Area(self, Area):
        self._Area = Area

    @property
    def Religion(self):
        r"""Religious beliefs
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Religion

    @Religion.setter
    def Religion(self, Religion):
        self._Religion = Religion

    @property
    def MaritalStatus(self):
        r"""Marital status
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._MaritalStatus

    @MaritalStatus.setter
    def MaritalStatus(self, MaritalStatus):
        self._MaritalStatus = MaritalStatus

    @property
    def Occupation(self):
        r"""Job
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Occupation

    @Occupation.setter
    def Occupation(self, Occupation):
        self._Occupation = Occupation

    @property
    def Nationality(self):
        r"""Nationality
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Nationality

    @Nationality.setter
    def Nationality(self, Nationality):
        self._Nationality = Nationality

    @property
    def DueDate(self):
        r"""ID card validity period
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._DueDate

    @DueDate.setter
    def DueDate(self, DueDate):
        self._DueDate = DueDate

    @property
    def IssuedDate(self):
        r"""Date of issue
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._IssuedDate

    @IssuedDate.setter
    def IssuedDate(self, IssuedDate):
        self._IssuedDate = IssuedDate

    @property
    def Province(self):
        r"""Province
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Province

    @Province.setter
    def Province(self, Province):
        self._Province = Province

    @property
    def City(self):
        r"""City
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._City

    @City.setter
    def City(self, City):
        self._City = City


    def _deserialize(self, params):
        self._LicenseNumber = params.get("LicenseNumber")
        self._FullName = params.get("FullName")
        self._Birthday = params.get("Birthday")
        self._Sex = params.get("Sex")
        self._BloodType = params.get("BloodType")
        self._FormattedAddress = params.get("FormattedAddress")
        self._Street = params.get("Street")
        self._Village = params.get("Village")
        self._Area = params.get("Area")
        self._Religion = params.get("Religion")
        self._MaritalStatus = params.get("MaritalStatus")
        self._Occupation = params.get("Occupation")
        self._Nationality = params.get("Nationality")
        self._DueDate = params.get("DueDate")
        self._IssuedDate = params.get("IssuedDate")
        self._Province = params.get("Province")
        self._City = params.get("City")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class NormalMLIDCard(AbstractModel):
    r"""Malaysia ID card.

    """

    def __init__(self):
        r"""
        :param _FullName: Full Name
Note: This field may return null, indicating that no valid values can be obtained.
        :type FullName: str
        :param _LicenseNumber: License number
Note: This field may return null, indicating that no valid values can be obtained.
        :type LicenseNumber: str
        :param _Sex: Gender
Note: This field may return null, indicating that no valid values can be obtained.
        :type Sex: str
        :param _FormattedAddress: Address
Note: This field may return null, indicating that no valid values can be obtained.
        :type FormattedAddress: str
        :param _Type: Lisence type
MyKad ID card
MyPR Permanent resident ID card
MyTentera Military ID card
MyKAS Temporary ID card
POLIS Police ID card
IKAD Labor ID card
MyKid Juvenile ID card
Example: MyKad
        :type Type: str
        :param _Birthday: Birthday (Currently, this filed only supports IKAD labor ID card and MyKad ID card)
Note: This field may return null, indicating that no valid values can be obtained.
        :type Birthday: str
        """
        self._FullName = None
        self._LicenseNumber = None
        self._Sex = None
        self._FormattedAddress = None
        self._Type = None
        self._Birthday = None

    @property
    def FullName(self):
        r"""Full Name
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._FullName

    @FullName.setter
    def FullName(self, FullName):
        self._FullName = FullName

    @property
    def LicenseNumber(self):
        r"""License number
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._LicenseNumber

    @LicenseNumber.setter
    def LicenseNumber(self, LicenseNumber):
        self._LicenseNumber = LicenseNumber

    @property
    def Sex(self):
        r"""Gender
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Sex

    @Sex.setter
    def Sex(self, Sex):
        self._Sex = Sex

    @property
    def FormattedAddress(self):
        r"""Address
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._FormattedAddress

    @FormattedAddress.setter
    def FormattedAddress(self, FormattedAddress):
        self._FormattedAddress = FormattedAddress

    @property
    def Type(self):
        r"""Lisence type
MyKad ID card
MyPR Permanent resident ID card
MyTentera Military ID card
MyKAS Temporary ID card
POLIS Police ID card
IKAD Labor ID card
MyKid Juvenile ID card
Example: MyKad
        :rtype: str
        """
        return self._Type

    @Type.setter
    def Type(self, Type):
        self._Type = Type

    @property
    def Birthday(self):
        r"""Birthday (Currently, this filed only supports IKAD labor ID card and MyKad ID card)
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Birthday

    @Birthday.setter
    def Birthday(self, Birthday):
        self._Birthday = Birthday


    def _deserialize(self, params):
        self._FullName = params.get("FullName")
        self._LicenseNumber = params.get("LicenseNumber")
        self._Sex = params.get("Sex")
        self._FormattedAddress = params.get("FormattedAddress")
        self._Type = params.get("Type")
        self._Birthday = params.get("Birthday")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class NormalThailandIDCard(AbstractModel):
    r"""Thailand ID Card

    """

    def __init__(self):
        r"""
        :param _LicenseNumber: LicenseNumber
Note: This field may return null, indicating that no valid values can be obtained.
        :type LicenseNumber: str
        :param _FullName: Thailand name
Note: This field may return null, indicating that no valid values can be obtained.
        :type FullName: str
        :param _LastName: Last name
Note: This field may return null, indicating that no valid values can be obtained.
        :type LastName: str
        :param _FirstName: First name
Note: This field may return null, indicating that no valid values can be obtained.
        :type FirstName: str
        :param _Birthday: Birthday
Note: This field may return null, indicating that no valid values can be obtained.
        :type Birthday: str
        :param _FormattedAddress: Address
Note: This field may return null, indicating that no valid values can be obtained.
        :type FormattedAddress: str
        :param _ExpirationDate: Expiration date
Note: This field may return null, indicating that no valid values can be obtained.
        :type ExpirationDate: str
        :param _IssuedDate: Issued date
Note: This field may return null, indicating that no valid values can be obtained.
        :type IssuedDate: str
        :param _RegistrationNumber: Registration number 
Note: This field may return null, indicating that no valid values can be obtained.
        :type RegistrationNumber: str
        :param _Religion: Religion
Note: This field may return null, indicating that no valid values can be obtained.
        :type Religion: str
        :param _ThaiBirthday: Birthday in Thai
Note: This field may return null, indicating that no valid values can be obtained.
        :type ThaiBirthday: str
        :param _ThaiExpirationDate: Expiration date in Thai
Note: This field may return null, indicating that no valid values can be obtained.
        :type ThaiExpirationDate: str
        :param _ThaiIssueDate: Issued date in Thai
Note: This field may return null, indicating that no valid values can be obtained.
        :type ThaiIssueDate: str
        """
        self._LicenseNumber = None
        self._FullName = None
        self._LastName = None
        self._FirstName = None
        self._Birthday = None
        self._FormattedAddress = None
        self._ExpirationDate = None
        self._IssuedDate = None
        self._RegistrationNumber = None
        self._Religion = None
        self._ThaiBirthday = None
        self._ThaiExpirationDate = None
        self._ThaiIssueDate = None

    @property
    def LicenseNumber(self):
        r"""LicenseNumber
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._LicenseNumber

    @LicenseNumber.setter
    def LicenseNumber(self, LicenseNumber):
        self._LicenseNumber = LicenseNumber

    @property
    def FullName(self):
        r"""Thailand name
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._FullName

    @FullName.setter
    def FullName(self, FullName):
        self._FullName = FullName

    @property
    def LastName(self):
        r"""Last name
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._LastName

    @LastName.setter
    def LastName(self, LastName):
        self._LastName = LastName

    @property
    def FirstName(self):
        r"""First name
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._FirstName

    @FirstName.setter
    def FirstName(self, FirstName):
        self._FirstName = FirstName

    @property
    def Birthday(self):
        r"""Birthday
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Birthday

    @Birthday.setter
    def Birthday(self, Birthday):
        self._Birthday = Birthday

    @property
    def FormattedAddress(self):
        r"""Address
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._FormattedAddress

    @FormattedAddress.setter
    def FormattedAddress(self, FormattedAddress):
        self._FormattedAddress = FormattedAddress

    @property
    def ExpirationDate(self):
        r"""Expiration date
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._ExpirationDate

    @ExpirationDate.setter
    def ExpirationDate(self, ExpirationDate):
        self._ExpirationDate = ExpirationDate

    @property
    def IssuedDate(self):
        r"""Issued date
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._IssuedDate

    @IssuedDate.setter
    def IssuedDate(self, IssuedDate):
        self._IssuedDate = IssuedDate

    @property
    def RegistrationNumber(self):
        r"""Registration number 
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._RegistrationNumber

    @RegistrationNumber.setter
    def RegistrationNumber(self, RegistrationNumber):
        self._RegistrationNumber = RegistrationNumber

    @property
    def Religion(self):
        r"""Religion
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Religion

    @Religion.setter
    def Religion(self, Religion):
        self._Religion = Religion

    @property
    def ThaiBirthday(self):
        r"""Birthday in Thai
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._ThaiBirthday

    @ThaiBirthday.setter
    def ThaiBirthday(self, ThaiBirthday):
        self._ThaiBirthday = ThaiBirthday

    @property
    def ThaiExpirationDate(self):
        r"""Expiration date in Thai
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._ThaiExpirationDate

    @ThaiExpirationDate.setter
    def ThaiExpirationDate(self, ThaiExpirationDate):
        self._ThaiExpirationDate = ThaiExpirationDate

    @property
    def ThaiIssueDate(self):
        r"""Issued date in Thai
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._ThaiIssueDate

    @ThaiIssueDate.setter
    def ThaiIssueDate(self, ThaiIssueDate):
        self._ThaiIssueDate = ThaiIssueDate


    def _deserialize(self, params):
        self._LicenseNumber = params.get("LicenseNumber")
        self._FullName = params.get("FullName")
        self._LastName = params.get("LastName")
        self._FirstName = params.get("FirstName")
        self._Birthday = params.get("Birthday")
        self._FormattedAddress = params.get("FormattedAddress")
        self._ExpirationDate = params.get("ExpirationDate")
        self._IssuedDate = params.get("IssuedDate")
        self._RegistrationNumber = params.get("RegistrationNumber")
        self._Religion = params.get("Religion")
        self._ThaiBirthday = params.get("ThaiBirthday")
        self._ThaiExpirationDate = params.get("ThaiExpirationDate")
        self._ThaiIssueDate = params.get("ThaiIssueDate")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class OCRResult(AbstractModel):
    r"""The content of a single license in the license information.

    """

    def __init__(self):
        r"""
        :param _IsPass: Is the indentity verification or OCR process passed
        :type IsPass: bool
        :param _CardImageBase64: The Base64 of ID card image
Note: This field may return null, indicating that no valid values can be obtained.
        :type CardImageBase64: str
        :param _CardInfo: OCR result of the ID card.
        :type CardInfo: :class:`tencentcloud.faceid.v20180301.models.CardInfo`
        :param _NormalCardInfo: OCR result of the ID card.
        :type NormalCardInfo: :class:`tencentcloud.faceid.v20180301.models.NormalCardInfo`
        :param _RequestId: The request id
        :type RequestId: str
        :param _CardCutImageBase64: Base64 of cropped image of ID card
        :type CardCutImageBase64: str
        :param _CardBackCutImageBase64: Base64 of the cropped image on the reverse side of the ID card
        :type CardBackCutImageBase64: str
        :param _WarnCardInfos: Card Warning Information

-9101 Alarm for covered certificate,
-9102 Alarm for photocopied certificate,
-9103 Alarm for photographed certificate,
-9104 Alarm for PS certificate,
-9107 Alarm for reflective certificate,
-9108 Alarm for blurry image,
-9109 This capability is not enabled.
        :type WarnCardInfos: list of int
        """
        self._IsPass = None
        self._CardImageBase64 = None
        self._CardInfo = None
        self._NormalCardInfo = None
        self._RequestId = None
        self._CardCutImageBase64 = None
        self._CardBackCutImageBase64 = None
        self._WarnCardInfos = None

    @property
    def IsPass(self):
        r"""Is the indentity verification or OCR process passed
        :rtype: bool
        """
        return self._IsPass

    @IsPass.setter
    def IsPass(self, IsPass):
        self._IsPass = IsPass

    @property
    def CardImageBase64(self):
        r"""The Base64 of ID card image
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._CardImageBase64

    @CardImageBase64.setter
    def CardImageBase64(self, CardImageBase64):
        self._CardImageBase64 = CardImageBase64

    @property
    def CardInfo(self):
        warnings.warn("parameter `CardInfo` is deprecated", DeprecationWarning) 

        r"""OCR result of the ID card.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.CardInfo`
        """
        return self._CardInfo

    @CardInfo.setter
    def CardInfo(self, CardInfo):
        warnings.warn("parameter `CardInfo` is deprecated", DeprecationWarning) 

        self._CardInfo = CardInfo

    @property
    def NormalCardInfo(self):
        r"""OCR result of the ID card.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.NormalCardInfo`
        """
        return self._NormalCardInfo

    @NormalCardInfo.setter
    def NormalCardInfo(self, NormalCardInfo):
        self._NormalCardInfo = NormalCardInfo

    @property
    def RequestId(self):
        r"""The request id
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId

    @property
    def CardCutImageBase64(self):
        r"""Base64 of cropped image of ID card
        :rtype: str
        """
        return self._CardCutImageBase64

    @CardCutImageBase64.setter
    def CardCutImageBase64(self, CardCutImageBase64):
        self._CardCutImageBase64 = CardCutImageBase64

    @property
    def CardBackCutImageBase64(self):
        r"""Base64 of the cropped image on the reverse side of the ID card
        :rtype: str
        """
        return self._CardBackCutImageBase64

    @CardBackCutImageBase64.setter
    def CardBackCutImageBase64(self, CardBackCutImageBase64):
        self._CardBackCutImageBase64 = CardBackCutImageBase64

    @property
    def WarnCardInfos(self):
        r"""Card Warning Information

-9101 Alarm for covered certificate,
-9102 Alarm for photocopied certificate,
-9103 Alarm for photographed certificate,
-9104 Alarm for PS certificate,
-9107 Alarm for reflective certificate,
-9108 Alarm for blurry image,
-9109 This capability is not enabled.
        :rtype: list of int
        """
        return self._WarnCardInfos

    @WarnCardInfos.setter
    def WarnCardInfos(self, WarnCardInfos):
        self._WarnCardInfos = WarnCardInfos


    def _deserialize(self, params):
        self._IsPass = params.get("IsPass")
        self._CardImageBase64 = params.get("CardImageBase64")
        if params.get("CardInfo") is not None:
            self._CardInfo = CardInfo()
            self._CardInfo._deserialize(params.get("CardInfo"))
        if params.get("NormalCardInfo") is not None:
            self._NormalCardInfo = NormalCardInfo()
            self._NormalCardInfo._deserialize(params.get("NormalCardInfo"))
        self._RequestId = params.get("RequestId")
        self._CardCutImageBase64 = params.get("CardCutImageBase64")
        self._CardBackCutImageBase64 = params.get("CardBackCutImageBase64")
        self._WarnCardInfos = params.get("WarnCardInfos")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class PakistanDrivingLicense(AbstractModel):
    r"""Pakistan driving license

    """

    def __init__(self):
        r"""
        :param _LastName: Last name.
Note: This field may return null, indicating that no valid values can be obtained.
        :type LastName: str
        :param _FirstName: First name.
Note: This field may return null, indicating that no valid values can be obtained.
        :type FirstName: str
        :param _LicenseNumber: License number.
Note: This field may return null, indicating that no valid values can be obtained.
        :type LicenseNumber: str
        :param _Age: Age.
Note: This field may return null, indicating that no valid values can be obtained.
        :type Age: str
        :param _Birthday: Birthday.
Note: This field may return null, indicating that no valid values can be obtained.
        :type Birthday: str
        :param _IssuedCountry: Gender.
Note: This field may return null, indicating that no valid values can be obtained.
        :type IssuedCountry: str
        """
        self._LastName = None
        self._FirstName = None
        self._LicenseNumber = None
        self._Age = None
        self._Birthday = None
        self._IssuedCountry = None

    @property
    def LastName(self):
        r"""Last name.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._LastName

    @LastName.setter
    def LastName(self, LastName):
        self._LastName = LastName

    @property
    def FirstName(self):
        r"""First name.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._FirstName

    @FirstName.setter
    def FirstName(self, FirstName):
        self._FirstName = FirstName

    @property
    def LicenseNumber(self):
        r"""License number.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._LicenseNumber

    @LicenseNumber.setter
    def LicenseNumber(self, LicenseNumber):
        self._LicenseNumber = LicenseNumber

    @property
    def Age(self):
        r"""Age.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Age

    @Age.setter
    def Age(self, Age):
        self._Age = Age

    @property
    def Birthday(self):
        r"""Birthday.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Birthday

    @Birthday.setter
    def Birthday(self, Birthday):
        self._Birthday = Birthday

    @property
    def IssuedCountry(self):
        r"""Gender.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._IssuedCountry

    @IssuedCountry.setter
    def IssuedCountry(self, IssuedCountry):
        self._IssuedCountry = IssuedCountry


    def _deserialize(self, params):
        self._LastName = params.get("LastName")
        self._FirstName = params.get("FirstName")
        self._LicenseNumber = params.get("LicenseNumber")
        self._Age = params.get("Age")
        self._Birthday = params.get("Birthday")
        self._IssuedCountry = params.get("IssuedCountry")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class PakistanIDCard(AbstractModel):
    r"""Pakistan ID card

    """

    def __init__(self):
        r"""
        :param _LastName: Last name.
Note: This field may return null, indicating that no valid values can be obtained.
        :type LastName: str
        :param _FirstName: First name.
Note: This field may return null, indicating that no valid values can be obtained.
        :type FirstName: str
        :param _LicenseNumber: License number.
Note: This field may return null, indicating that no valid values can be obtained.
        :type LicenseNumber: str
        :param _Age: Age.
Note: This field may return null, indicating that no valid values can be obtained.
        :type Age: str
        :param _Birthday: Birthday.
Note: This field may return null, indicating that no valid values can be obtained.
        :type Birthday: str
        :param _IssuedCountry: Issued country.
Note: This field may return null, indicating that no valid values can be obtained.
        :type IssuedCountry: str
        """
        self._LastName = None
        self._FirstName = None
        self._LicenseNumber = None
        self._Age = None
        self._Birthday = None
        self._IssuedCountry = None

    @property
    def LastName(self):
        r"""Last name.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._LastName

    @LastName.setter
    def LastName(self, LastName):
        self._LastName = LastName

    @property
    def FirstName(self):
        r"""First name.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._FirstName

    @FirstName.setter
    def FirstName(self, FirstName):
        self._FirstName = FirstName

    @property
    def LicenseNumber(self):
        r"""License number.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._LicenseNumber

    @LicenseNumber.setter
    def LicenseNumber(self, LicenseNumber):
        self._LicenseNumber = LicenseNumber

    @property
    def Age(self):
        r"""Age.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Age

    @Age.setter
    def Age(self, Age):
        self._Age = Age

    @property
    def Birthday(self):
        r"""Birthday.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Birthday

    @Birthday.setter
    def Birthday(self, Birthday):
        self._Birthday = Birthday

    @property
    def IssuedCountry(self):
        r"""Issued country.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._IssuedCountry

    @IssuedCountry.setter
    def IssuedCountry(self, IssuedCountry):
        self._IssuedCountry = IssuedCountry


    def _deserialize(self, params):
        self._LastName = params.get("LastName")
        self._FirstName = params.get("FirstName")
        self._LicenseNumber = params.get("LicenseNumber")
        self._Age = params.get("Age")
        self._Birthday = params.get("Birthday")
        self._IssuedCountry = params.get("IssuedCountry")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class PhilippinesDrivingLicense(AbstractModel):
    r"""Philippines driving license

    """

    def __init__(self):
        r"""
        :param _Name: Full Name
Note: This field may return null, indicating that no valid values can be obtained.
        :type Name: str
        :param _LastName: Last name

Note: This field may return null, indicating that no valid values can be obtained.
        :type LastName: str
        :param _FirstName: First name
Note: This field may return null, indicating that no valid values can be obtained.
        :type FirstName: str
        :param _MiddleName: Middle name
Note: This field may return null, indicating that no valid values can be obtained.
        :type MiddleName: str
        :param _Nationality: Nationality
Note: This field may return null, indicating that no valid values can be obtained.
        :type Nationality: str
        :param _Sex: Gender
Note: This field may return null, indicating that no valid values can be obtained.
        :type Sex: str
        :param _Address: Address
Note: This field may return null, indicating that no valid values can be obtained.
        :type Address: str
        :param _LicenseNo: License number
Note: This field may return null, indicating that no valid values can be obtained.
        :type LicenseNo: str
        :param _ExpiresDate: Date of expiry
Note: This field may return null, indicating that no valid values can be obtained.
        :type ExpiresDate: str
        :param _AgencyCode: Agency code
Note: This field may return null, indicating that no valid values can be obtained.
        :type AgencyCode: str
        :param _Birthday: Birthday
Note: This field may return null, indicating that no valid values can be obtained.
        :type Birthday: str
        """
        self._Name = None
        self._LastName = None
        self._FirstName = None
        self._MiddleName = None
        self._Nationality = None
        self._Sex = None
        self._Address = None
        self._LicenseNo = None
        self._ExpiresDate = None
        self._AgencyCode = None
        self._Birthday = None

    @property
    def Name(self):
        r"""Full Name
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def LastName(self):
        r"""Last name

Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._LastName

    @LastName.setter
    def LastName(self, LastName):
        self._LastName = LastName

    @property
    def FirstName(self):
        r"""First name
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._FirstName

    @FirstName.setter
    def FirstName(self, FirstName):
        self._FirstName = FirstName

    @property
    def MiddleName(self):
        r"""Middle name
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._MiddleName

    @MiddleName.setter
    def MiddleName(self, MiddleName):
        self._MiddleName = MiddleName

    @property
    def Nationality(self):
        r"""Nationality
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Nationality

    @Nationality.setter
    def Nationality(self, Nationality):
        self._Nationality = Nationality

    @property
    def Sex(self):
        r"""Gender
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Sex

    @Sex.setter
    def Sex(self, Sex):
        self._Sex = Sex

    @property
    def Address(self):
        r"""Address
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Address

    @Address.setter
    def Address(self, Address):
        self._Address = Address

    @property
    def LicenseNo(self):
        r"""License number
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._LicenseNo

    @LicenseNo.setter
    def LicenseNo(self, LicenseNo):
        self._LicenseNo = LicenseNo

    @property
    def ExpiresDate(self):
        r"""Date of expiry
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._ExpiresDate

    @ExpiresDate.setter
    def ExpiresDate(self, ExpiresDate):
        self._ExpiresDate = ExpiresDate

    @property
    def AgencyCode(self):
        r"""Agency code
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._AgencyCode

    @AgencyCode.setter
    def AgencyCode(self, AgencyCode):
        self._AgencyCode = AgencyCode

    @property
    def Birthday(self):
        r"""Birthday
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Birthday

    @Birthday.setter
    def Birthday(self, Birthday):
        self._Birthday = Birthday


    def _deserialize(self, params):
        self._Name = params.get("Name")
        self._LastName = params.get("LastName")
        self._FirstName = params.get("FirstName")
        self._MiddleName = params.get("MiddleName")
        self._Nationality = params.get("Nationality")
        self._Sex = params.get("Sex")
        self._Address = params.get("Address")
        self._LicenseNo = params.get("LicenseNo")
        self._ExpiresDate = params.get("ExpiresDate")
        self._AgencyCode = params.get("AgencyCode")
        self._Birthday = params.get("Birthday")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class PhilippinesSSSID(AbstractModel):
    r"""Philippines SSSID Card

    """

    def __init__(self):
        r"""
        :param _LicenseNumber: License number
Note: This field may return null, indicating that no valid values can be obtained.
        :type LicenseNumber: str
        :param _FullName: Full name
Note: This field may return null, indicating that no valid values can be obtained.
        :type FullName: str
        :param _Birthday: Birthday
Note: This field may return null, indicating that no valid values can be obtained.
        :type Birthday: str
        """
        self._LicenseNumber = None
        self._FullName = None
        self._Birthday = None

    @property
    def LicenseNumber(self):
        r"""License number
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._LicenseNumber

    @LicenseNumber.setter
    def LicenseNumber(self, LicenseNumber):
        self._LicenseNumber = LicenseNumber

    @property
    def FullName(self):
        r"""Full name
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._FullName

    @FullName.setter
    def FullName(self, FullName):
        self._FullName = FullName

    @property
    def Birthday(self):
        r"""Birthday
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Birthday

    @Birthday.setter
    def Birthday(self, Birthday):
        self._Birthday = Birthday


    def _deserialize(self, params):
        self._LicenseNumber = params.get("LicenseNumber")
        self._FullName = params.get("FullName")
        self._Birthday = params.get("Birthday")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class PhilippinesTinID(AbstractModel):
    r"""Philippines TinID Card

    """

    def __init__(self):
        r"""
        :param _LicenseNumber: License number
Note: This field may return null, indicating that no valid values can be obtained.
        :type LicenseNumber: str
        :param _FullName: Full name
Note: This field may return null, indicating that no valid values can be obtained.
        :type FullName: str
        :param _Address: Address
Note: This field may return null, indicating that no valid values can be obtained.
        :type Address: str
        :param _Birthday: Birthday
Note: This field may return null, indicating that no valid values can be obtained.
        :type Birthday: str
        :param _IssueDate: Date of issue
Note: This field may return null, indicating that no valid values can be obtained.
        :type IssueDate: str
        """
        self._LicenseNumber = None
        self._FullName = None
        self._Address = None
        self._Birthday = None
        self._IssueDate = None

    @property
    def LicenseNumber(self):
        r"""License number
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._LicenseNumber

    @LicenseNumber.setter
    def LicenseNumber(self, LicenseNumber):
        self._LicenseNumber = LicenseNumber

    @property
    def FullName(self):
        r"""Full name
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._FullName

    @FullName.setter
    def FullName(self, FullName):
        self._FullName = FullName

    @property
    def Address(self):
        r"""Address
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Address

    @Address.setter
    def Address(self, Address):
        self._Address = Address

    @property
    def Birthday(self):
        r"""Birthday
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Birthday

    @Birthday.setter
    def Birthday(self, Birthday):
        self._Birthday = Birthday

    @property
    def IssueDate(self):
        r"""Date of issue
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._IssueDate

    @IssueDate.setter
    def IssueDate(self, IssueDate):
        self._IssueDate = IssueDate


    def _deserialize(self, params):
        self._LicenseNumber = params.get("LicenseNumber")
        self._FullName = params.get("FullName")
        self._Address = params.get("Address")
        self._Birthday = params.get("Birthday")
        self._IssueDate = params.get("IssueDate")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class PhilippinesUMID(AbstractModel):
    r"""Philippines UMID Card

    """

    def __init__(self):
        r"""
        :param _Surname: Surname
Note: This field may return null, indicating that no valid values can be obtained.
        :type Surname: str
        :param _MiddleName: Middle Name
Note: This field may return null, indicating that no valid values can be obtained.
        :type MiddleName: str
        :param _GivenName: First name
Note: This field may return null, indicating that no valid values can be obtained.
        :type GivenName: str
        :param _Sex: Gender
Note: This field may return null, indicating that no valid values can be obtained.
        :type Sex: str
        :param _Birthday: Birthday
Note: This field may return null, indicating that no valid values can be obtained.
        :type Birthday: str
        :param _Address: Address
Note: This field may return null, indicating that no valid values can be obtained.
        :type Address: str
        :param _CRN: CRN code
Note: This field may return null, indicating that no valid values can be obtained.
        :type CRN: str
        """
        self._Surname = None
        self._MiddleName = None
        self._GivenName = None
        self._Sex = None
        self._Birthday = None
        self._Address = None
        self._CRN = None

    @property
    def Surname(self):
        r"""Surname
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Surname

    @Surname.setter
    def Surname(self, Surname):
        self._Surname = Surname

    @property
    def MiddleName(self):
        r"""Middle Name
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._MiddleName

    @MiddleName.setter
    def MiddleName(self, MiddleName):
        self._MiddleName = MiddleName

    @property
    def GivenName(self):
        r"""First name
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._GivenName

    @GivenName.setter
    def GivenName(self, GivenName):
        self._GivenName = GivenName

    @property
    def Sex(self):
        r"""Gender
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Sex

    @Sex.setter
    def Sex(self, Sex):
        self._Sex = Sex

    @property
    def Birthday(self):
        r"""Birthday
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Birthday

    @Birthday.setter
    def Birthday(self, Birthday):
        self._Birthday = Birthday

    @property
    def Address(self):
        r"""Address
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Address

    @Address.setter
    def Address(self, Address):
        self._Address = Address

    @property
    def CRN(self):
        r"""CRN code
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._CRN

    @CRN.setter
    def CRN(self, CRN):
        self._CRN = CRN


    def _deserialize(self, params):
        self._Surname = params.get("Surname")
        self._MiddleName = params.get("MiddleName")
        self._GivenName = params.get("GivenName")
        self._Sex = params.get("Sex")
        self._Birthday = params.get("Birthday")
        self._Address = params.get("Address")
        self._CRN = params.get("CRN")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class PhilippinesVoteID(AbstractModel):
    r"""Philippines VoteID Card

    """

    def __init__(self):
        r"""
        :param _VIN: VIN of Philippines VoteID
Note: This field may return null, indicating that no valid values can be obtained.
        :type VIN: str
        :param _FirstName: First name
Note: This field may return null, indicating that no valid values can be obtained.
        :type FirstName: str
        :param _LastName: Last name
Note: This field may return null, indicating that no valid values can be obtained.
        :type LastName: str
        :param _Birthday: Birthday
Note: This field may return null, indicating that no valid values can be obtained.
        :type Birthday: str
        :param _CivilStatus: Civil status
Note: This field may return null, indicating that no valid values can be obtained.
        :type CivilStatus: str
        :param _Citizenship: Nationality
Note: This field may return null, indicating that no valid values can be obtained.
        :type Citizenship: str
        :param _Address: Address
Note: This field may return null, indicating that no valid values can be obtained.
        :type Address: str
        :param _PrecinctNo: Region
Note: This field may return null, indicating that no valid values can be obtained.
        :type PrecinctNo: str
        """
        self._VIN = None
        self._FirstName = None
        self._LastName = None
        self._Birthday = None
        self._CivilStatus = None
        self._Citizenship = None
        self._Address = None
        self._PrecinctNo = None

    @property
    def VIN(self):
        r"""VIN of Philippines VoteID
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._VIN

    @VIN.setter
    def VIN(self, VIN):
        self._VIN = VIN

    @property
    def FirstName(self):
        r"""First name
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._FirstName

    @FirstName.setter
    def FirstName(self, FirstName):
        self._FirstName = FirstName

    @property
    def LastName(self):
        r"""Last name
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._LastName

    @LastName.setter
    def LastName(self, LastName):
        self._LastName = LastName

    @property
    def Birthday(self):
        r"""Birthday
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Birthday

    @Birthday.setter
    def Birthday(self, Birthday):
        self._Birthday = Birthday

    @property
    def CivilStatus(self):
        r"""Civil status
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._CivilStatus

    @CivilStatus.setter
    def CivilStatus(self, CivilStatus):
        self._CivilStatus = CivilStatus

    @property
    def Citizenship(self):
        r"""Nationality
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Citizenship

    @Citizenship.setter
    def Citizenship(self, Citizenship):
        self._Citizenship = Citizenship

    @property
    def Address(self):
        r"""Address
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Address

    @Address.setter
    def Address(self, Address):
        self._Address = Address

    @property
    def PrecinctNo(self):
        r"""Region
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._PrecinctNo

    @PrecinctNo.setter
    def PrecinctNo(self, PrecinctNo):
        self._PrecinctNo = PrecinctNo


    def _deserialize(self, params):
        self._VIN = params.get("VIN")
        self._FirstName = params.get("FirstName")
        self._LastName = params.get("LastName")
        self._Birthday = params.get("Birthday")
        self._CivilStatus = params.get("CivilStatus")
        self._Citizenship = params.get("Citizenship")
        self._Address = params.get("Address")
        self._PrecinctNo = params.get("PrecinctNo")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class PhoneVerificationRequest(AbstractModel):
    r"""PhoneVerification request structure.

    """

    def __init__(self):
        r"""
        :param _IdCard: Identity card number.
        :type IdCard: str
        :param _Name: Name
        :type Name: str
        :param _Phone: Mobile number.
        :type Phone: str
        :param _CiphertextBlob: Users with encryption requirements can import the CiphertextBlob of kms. Read the <a href="https://www.tencentcloud.com/document/product/1007/47180?from_cn_redirect=1">data encryption</a> document about encrypting data.
        :type CiphertextBlob: str
        :param _EncryptList: When using the encryption service, fill in the field to be encrypted.
-This API can fill in one or more of encrypted IdCard, Name, and Phone.
        :type EncryptList: list of str
        :param _Iv: Users with encryption requirements import the initial vector for CBC encryption.
        :type Iv: str
        """
        self._IdCard = None
        self._Name = None
        self._Phone = None
        self._CiphertextBlob = None
        self._EncryptList = None
        self._Iv = None

    @property
    def IdCard(self):
        r"""Identity card number.
        :rtype: str
        """
        return self._IdCard

    @IdCard.setter
    def IdCard(self, IdCard):
        self._IdCard = IdCard

    @property
    def Name(self):
        r"""Name
        :rtype: str
        """
        return self._Name

    @Name.setter
    def Name(self, Name):
        self._Name = Name

    @property
    def Phone(self):
        r"""Mobile number.
        :rtype: str
        """
        return self._Phone

    @Phone.setter
    def Phone(self, Phone):
        self._Phone = Phone

    @property
    def CiphertextBlob(self):
        r"""Users with encryption requirements can import the CiphertextBlob of kms. Read the <a href="https://www.tencentcloud.com/document/product/1007/47180?from_cn_redirect=1">data encryption</a> document about encrypting data.
        :rtype: str
        """
        return self._CiphertextBlob

    @CiphertextBlob.setter
    def CiphertextBlob(self, CiphertextBlob):
        self._CiphertextBlob = CiphertextBlob

    @property
    def EncryptList(self):
        r"""When using the encryption service, fill in the field to be encrypted.
-This API can fill in one or more of encrypted IdCard, Name, and Phone.
        :rtype: list of str
        """
        return self._EncryptList

    @EncryptList.setter
    def EncryptList(self, EncryptList):
        self._EncryptList = EncryptList

    @property
    def Iv(self):
        r"""Users with encryption requirements import the initial vector for CBC encryption.
        :rtype: str
        """
        return self._Iv

    @Iv.setter
    def Iv(self, Iv):
        self._Iv = Iv


    def _deserialize(self, params):
        self._IdCard = params.get("IdCard")
        self._Name = params.get("Name")
        self._Phone = params.get("Phone")
        self._CiphertextBlob = params.get("CiphertextBlob")
        self._EncryptList = params.get("EncryptList")
        self._Iv = params.get("Iv")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class PhoneVerificationResponse(AbstractModel):
    r"""PhoneVerification response structure.

    """

    def __init__(self):
        r"""
        :param _Result: Verification result code.
-Fee result code
Three-element information consistency.
-4: Three-element information inconsistency.

-No charge result code
-6: Invalid phone number.
-7: Identity number error.
-8: Name verification failed.
-9: No records.
-11: The Verification Center Service is busy.
-12: Authentication attempts exceeded the daily limit. Retry the next day.
-13: The number range is unsupported for verification.
        :type Result: str
        :param _Description: Business result description.
        :type Description: str
        :param _Isp: ISP name.
-Valid values: ["", "mobile", "telecom", "cucc"]
        :type Isp: str
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._Result = None
        self._Description = None
        self._Isp = None
        self._RequestId = None

    @property
    def Result(self):
        r"""Verification result code.
-Fee result code
Three-element information consistency.
-4: Three-element information inconsistency.

-No charge result code
-6: Invalid phone number.
-7: Identity number error.
-8: Name verification failed.
-9: No records.
-11: The Verification Center Service is busy.
-12: Authentication attempts exceeded the daily limit. Retry the next day.
-13: The number range is unsupported for verification.
        :rtype: str
        """
        return self._Result

    @Result.setter
    def Result(self, Result):
        self._Result = Result

    @property
    def Description(self):
        r"""Business result description.
        :rtype: str
        """
        return self._Description

    @Description.setter
    def Description(self, Description):
        self._Description = Description

    @property
    def Isp(self):
        r"""ISP name.
-Valid values: ["", "mobile", "telecom", "cucc"]
        :rtype: str
        """
        return self._Isp

    @Isp.setter
    def Isp(self, Isp):
        self._Isp = Isp

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._Result = params.get("Result")
        self._Description = params.get("Description")
        self._Isp = params.get("Isp")
        self._RequestId = params.get("RequestId")


class RetrievalLivenessExtraInfo(AbstractModel):
    r"""

    """

    def __init__(self):
        r"""
        :param _HitGroup: 
        :type HitGroup: str
        :param _SimilarityScore: 
        :type SimilarityScore: float
        :param _HitTemplate: 
        :type HitTemplate: str
        """
        self._HitGroup = None
        self._SimilarityScore = None
        self._HitTemplate = None

    @property
    def HitGroup(self):
        r"""
        :rtype: str
        """
        return self._HitGroup

    @HitGroup.setter
    def HitGroup(self, HitGroup):
        self._HitGroup = HitGroup

    @property
    def SimilarityScore(self):
        r"""
        :rtype: float
        """
        return self._SimilarityScore

    @SimilarityScore.setter
    def SimilarityScore(self, SimilarityScore):
        self._SimilarityScore = SimilarityScore

    @property
    def HitTemplate(self):
        r"""
        :rtype: str
        """
        return self._HitTemplate

    @HitTemplate.setter
    def HitTemplate(self, HitTemplate):
        self._HitTemplate = HitTemplate


    def _deserialize(self, params):
        self._HitGroup = params.get("HitGroup")
        self._SimilarityScore = params.get("SimilarityScore")
        self._HitTemplate = params.get("HitTemplate")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class SingaporeIDCard(AbstractModel):
    r"""Singapore ID Card

    """

    def __init__(self):
        r"""
        :param _ChName: Chinese name
Note: This field may return null, indicating that no valid values can be obtained.
        :type ChName: str
        :param _ChineseName: Chinese name
Note: This field may return null, indicating that no valid values can be obtained.
        :type ChineseName: str
        :param _EnName: English name
Note: This field may return null, indicating that no valid values can be obtained.
        :type EnName: str
        :param _FullName: English name
Note: This field may return null, indicating that no valid values can be obtained.
        :type FullName: str
        :param _ID: License number
Note: This field may return null, indicating that no valid values can be obtained.
        :type ID: str
        :param _LicenseNumber: License number
Note: This field may return null, indicating that no valid values can be obtained.
        :type LicenseNumber: str
        :param _Sex: Gender
Note: This field may return null, indicating that no valid values can be obtained.
        :type Sex: str
        :param _CountryOfBirth: Country of birth
Note: This field may return null, indicating that no valid values can be obtained.
        :type CountryOfBirth: str
        :param _Nationality: Nationality
Note: This field may return null, indicating that no valid values can be obtained.
        :type Nationality: str
        :param _Birthday: Birthday
Note: This field may return null, indicating that no valid values can be obtained.
        :type Birthday: str
        :param _Address: Address (on the back)
Note: This field may return null, indicating that no valid values can be obtained.
        :type Address: str
        :param _Race: Race (on the back)
Note: This field may return null, indicating that no valid values can be obtained.
        :type Race: str
        :param _NRICCode:  NRIC number (on the back)
Note: This field may return null, indicating that no valid values can be obtained.
        :type NRICCode: str
        :param _PostCode: Post number (on the front)
Note: This field may return null, indicating that no valid values can be obtained.
        :type PostCode: str
        :param _DateOfExpiration: Date of expiry (on the back)
Note: This field may return null, indicating that no valid values can be obtained.
        :type DateOfExpiration: str
        :param _DateOfIssue: Date of issue (on the back)
Note: This field may return null, indicating that no valid values can be obtained.
        :type DateOfIssue: str
        """
        self._ChName = None
        self._ChineseName = None
        self._EnName = None
        self._FullName = None
        self._ID = None
        self._LicenseNumber = None
        self._Sex = None
        self._CountryOfBirth = None
        self._Nationality = None
        self._Birthday = None
        self._Address = None
        self._Race = None
        self._NRICCode = None
        self._PostCode = None
        self._DateOfExpiration = None
        self._DateOfIssue = None

    @property
    def ChName(self):
        warnings.warn("parameter `ChName` is deprecated", DeprecationWarning) 

        r"""Chinese name
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._ChName

    @ChName.setter
    def ChName(self, ChName):
        warnings.warn("parameter `ChName` is deprecated", DeprecationWarning) 

        self._ChName = ChName

    @property
    def ChineseName(self):
        r"""Chinese name
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._ChineseName

    @ChineseName.setter
    def ChineseName(self, ChineseName):
        self._ChineseName = ChineseName

    @property
    def EnName(self):
        warnings.warn("parameter `EnName` is deprecated", DeprecationWarning) 

        r"""English name
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._EnName

    @EnName.setter
    def EnName(self, EnName):
        warnings.warn("parameter `EnName` is deprecated", DeprecationWarning) 

        self._EnName = EnName

    @property
    def FullName(self):
        r"""English name
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._FullName

    @FullName.setter
    def FullName(self, FullName):
        self._FullName = FullName

    @property
    def ID(self):
        warnings.warn("parameter `ID` is deprecated", DeprecationWarning) 

        r"""License number
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        warnings.warn("parameter `ID` is deprecated", DeprecationWarning) 

        self._ID = ID

    @property
    def LicenseNumber(self):
        r"""License number
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._LicenseNumber

    @LicenseNumber.setter
    def LicenseNumber(self, LicenseNumber):
        self._LicenseNumber = LicenseNumber

    @property
    def Sex(self):
        r"""Gender
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Sex

    @Sex.setter
    def Sex(self, Sex):
        self._Sex = Sex

    @property
    def CountryOfBirth(self):
        warnings.warn("parameter `CountryOfBirth` is deprecated", DeprecationWarning) 

        r"""Country of birth
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._CountryOfBirth

    @CountryOfBirth.setter
    def CountryOfBirth(self, CountryOfBirth):
        warnings.warn("parameter `CountryOfBirth` is deprecated", DeprecationWarning) 

        self._CountryOfBirth = CountryOfBirth

    @property
    def Nationality(self):
        r"""Nationality
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Nationality

    @Nationality.setter
    def Nationality(self, Nationality):
        self._Nationality = Nationality

    @property
    def Birthday(self):
        r"""Birthday
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Birthday

    @Birthday.setter
    def Birthday(self, Birthday):
        self._Birthday = Birthday

    @property
    def Address(self):
        r"""Address (on the back)
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Address

    @Address.setter
    def Address(self, Address):
        self._Address = Address

    @property
    def Race(self):
        r"""Race (on the back)
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Race

    @Race.setter
    def Race(self, Race):
        self._Race = Race

    @property
    def NRICCode(self):
        r""" NRIC number (on the back)
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._NRICCode

    @NRICCode.setter
    def NRICCode(self, NRICCode):
        self._NRICCode = NRICCode

    @property
    def PostCode(self):
        r"""Post number (on the front)
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._PostCode

    @PostCode.setter
    def PostCode(self, PostCode):
        self._PostCode = PostCode

    @property
    def DateOfExpiration(self):
        r"""Date of expiry (on the back)
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._DateOfExpiration

    @DateOfExpiration.setter
    def DateOfExpiration(self, DateOfExpiration):
        self._DateOfExpiration = DateOfExpiration

    @property
    def DateOfIssue(self):
        r"""Date of issue (on the back)
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._DateOfIssue

    @DateOfIssue.setter
    def DateOfIssue(self, DateOfIssue):
        self._DateOfIssue = DateOfIssue


    def _deserialize(self, params):
        self._ChName = params.get("ChName")
        self._ChineseName = params.get("ChineseName")
        self._EnName = params.get("EnName")
        self._FullName = params.get("FullName")
        self._ID = params.get("ID")
        self._LicenseNumber = params.get("LicenseNumber")
        self._Sex = params.get("Sex")
        self._CountryOfBirth = params.get("CountryOfBirth")
        self._Nationality = params.get("Nationality")
        self._Birthday = params.get("Birthday")
        self._Address = params.get("Address")
        self._Race = params.get("Race")
        self._NRICCode = params.get("NRICCode")
        self._PostCode = params.get("PostCode")
        self._DateOfExpiration = params.get("DateOfExpiration")
        self._DateOfIssue = params.get("DateOfIssue")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class TaiWanIDCard(AbstractModel):
    r"""Taiwan (China) ID card.

    """

    def __init__(self):
        r"""
        :param _FullName: Full name
Note: This field may return null, indicating that no valid values can be obtained.
        :type FullName: str
        :param _LicenseNumber: License number
Note: This field may return null, indicating that no valid values can be obtained.
        :type LicenseNumber: str
        :param _Sex: Gender
Note: This field may return null, indicating that no valid values can be obtained.
        :type Sex: str
        :param _IssuedCountry: Issued country
Note: This field may return null, indicating that no valid values can be obtained.
        :type IssuedCountry: str
        :param _RegistrationNumber: Registration number
Note: This field may return null, indicating that no valid values can be obtained.
        :type RegistrationNumber: str
        """
        self._FullName = None
        self._LicenseNumber = None
        self._Sex = None
        self._IssuedCountry = None
        self._RegistrationNumber = None

    @property
    def FullName(self):
        r"""Full name
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._FullName

    @FullName.setter
    def FullName(self, FullName):
        self._FullName = FullName

    @property
    def LicenseNumber(self):
        r"""License number
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._LicenseNumber

    @LicenseNumber.setter
    def LicenseNumber(self, LicenseNumber):
        self._LicenseNumber = LicenseNumber

    @property
    def Sex(self):
        r"""Gender
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Sex

    @Sex.setter
    def Sex(self, Sex):
        self._Sex = Sex

    @property
    def IssuedCountry(self):
        r"""Issued country
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._IssuedCountry

    @IssuedCountry.setter
    def IssuedCountry(self, IssuedCountry):
        self._IssuedCountry = IssuedCountry

    @property
    def RegistrationNumber(self):
        r"""Registration number
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._RegistrationNumber

    @RegistrationNumber.setter
    def RegistrationNumber(self, RegistrationNumber):
        self._RegistrationNumber = RegistrationNumber


    def _deserialize(self, params):
        self._FullName = params.get("FullName")
        self._LicenseNumber = params.get("LicenseNumber")
        self._Sex = params.get("Sex")
        self._IssuedCountry = params.get("IssuedCountry")
        self._RegistrationNumber = params.get("RegistrationNumber")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class ThailandIDCard(AbstractModel):
    r"""Thailand ID Card

    """

    def __init__(self):
        r"""
        :param _LastName: Last name
Note: This field may return null, indicating that no valid values can be obtained.
        :type LastName: str
        :param _FirstName: First name
Note: This field may return null, indicating that no valid values can be obtained.
        :type FirstName: str
        :param _LicenseNumber: License number
Note: This field may return null, indicating that no valid values can be obtained.
        :type LicenseNumber: str
        :param _DateOfBirth: Birthday
Note: This field may return null, indicating that no valid values can be obtained.
        :type DateOfBirth: str
        :param _DateOfExpiry: Date of expiry
Note: This field may return null, indicating that no valid values can be obtained.
        :type DateOfExpiry: str
        :param _DateOfIssue: Date of issue
Note: This field may return null, indicating that no valid values can be obtained.
        :type DateOfIssue: str
        :param _IssuedCountry: Issuing country
Note: This field may return null, indicating that no valid values can be obtained.
        :type IssuedCountry: str
        """
        self._LastName = None
        self._FirstName = None
        self._LicenseNumber = None
        self._DateOfBirth = None
        self._DateOfExpiry = None
        self._DateOfIssue = None
        self._IssuedCountry = None

    @property
    def LastName(self):
        r"""Last name
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._LastName

    @LastName.setter
    def LastName(self, LastName):
        self._LastName = LastName

    @property
    def FirstName(self):
        r"""First name
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._FirstName

    @FirstName.setter
    def FirstName(self, FirstName):
        self._FirstName = FirstName

    @property
    def LicenseNumber(self):
        r"""License number
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._LicenseNumber

    @LicenseNumber.setter
    def LicenseNumber(self, LicenseNumber):
        self._LicenseNumber = LicenseNumber

    @property
    def DateOfBirth(self):
        r"""Birthday
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._DateOfBirth

    @DateOfBirth.setter
    def DateOfBirth(self, DateOfBirth):
        self._DateOfBirth = DateOfBirth

    @property
    def DateOfExpiry(self):
        r"""Date of expiry
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._DateOfExpiry

    @DateOfExpiry.setter
    def DateOfExpiry(self, DateOfExpiry):
        self._DateOfExpiry = DateOfExpiry

    @property
    def DateOfIssue(self):
        r"""Date of issue
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._DateOfIssue

    @DateOfIssue.setter
    def DateOfIssue(self, DateOfIssue):
        self._DateOfIssue = DateOfIssue

    @property
    def IssuedCountry(self):
        r"""Issuing country
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._IssuedCountry

    @IssuedCountry.setter
    def IssuedCountry(self, IssuedCountry):
        self._IssuedCountry = IssuedCountry


    def _deserialize(self, params):
        self._LastName = params.get("LastName")
        self._FirstName = params.get("FirstName")
        self._LicenseNumber = params.get("LicenseNumber")
        self._DateOfBirth = params.get("DateOfBirth")
        self._DateOfExpiry = params.get("DateOfExpiry")
        self._DateOfIssue = params.get("DateOfIssue")
        self._IssuedCountry = params.get("IssuedCountry")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class VerificationDetail(AbstractModel):
    r"""The details of the verification process.

    """

    def __init__(self):
        r"""
        :param _ErrorCode: The final result of this verification. `0` indicates that the person is the same as that in the photo.
Note: This field may return null, indicating that no valid values can be obtained.
        :type ErrorCode: int
        :param _ErrorMsg: The description of the final verification result.
Note: This field may return null, indicating that no valid values can be obtained.
        :type ErrorMsg: str
        :param _LivenessErrorCode: The result of this liveness detection process. `0` indicates success.
Note: This field may return null, indicating that no valid values can be obtained.
        :type LivenessErrorCode: int
        :param _LivenessErrorMsg: The result description of this liveness detection process.
Note: This field may return null, indicating that no valid values can be obtained.
        :type LivenessErrorMsg: str
        :param _CompareErrorCode: The result of this comparison process. `0` indicates that the person in the best face screenshot collected from the video stream is the same as that in the uploaded image for comparison.
Note: This field may return null, indicating that no valid values can be obtained.
        :type CompareErrorCode: int
        :param _CompareErrorMsg: The result description of this comparison process.
Note: This field may return null, indicating that no valid values can be obtained.
        :type CompareErrorMsg: str
        :param _ReqTimestamp: The timestamp (ms) of this verification process.
Note: This field may return null, indicating that no valid values can be obtained.
        :type ReqTimestamp: int
        :param _Similarity: The similarity of the best face screenshot collected from the video stream and the uploaded image for comparison in this verification process. Value range: [0.00, 100.00]. By default, the person in the screenshot is determined to be the same person in the image if the similarity is greater than or equal to 70.
Note: This field may return null, indicating that no valid values can be obtained.
        :type Similarity: float
        :param _Seq: Unique ID of this verification process.
Note: This field may return null, indicating that no valid values can be obtained.
        :type Seq: str
        """
        self._ErrorCode = None
        self._ErrorMsg = None
        self._LivenessErrorCode = None
        self._LivenessErrorMsg = None
        self._CompareErrorCode = None
        self._CompareErrorMsg = None
        self._ReqTimestamp = None
        self._Similarity = None
        self._Seq = None

    @property
    def ErrorCode(self):
        r"""The final result of this verification. `0` indicates that the person is the same as that in the photo.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: int
        """
        return self._ErrorCode

    @ErrorCode.setter
    def ErrorCode(self, ErrorCode):
        self._ErrorCode = ErrorCode

    @property
    def ErrorMsg(self):
        r"""The description of the final verification result.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._ErrorMsg

    @ErrorMsg.setter
    def ErrorMsg(self, ErrorMsg):
        self._ErrorMsg = ErrorMsg

    @property
    def LivenessErrorCode(self):
        r"""The result of this liveness detection process. `0` indicates success.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: int
        """
        return self._LivenessErrorCode

    @LivenessErrorCode.setter
    def LivenessErrorCode(self, LivenessErrorCode):
        self._LivenessErrorCode = LivenessErrorCode

    @property
    def LivenessErrorMsg(self):
        r"""The result description of this liveness detection process.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._LivenessErrorMsg

    @LivenessErrorMsg.setter
    def LivenessErrorMsg(self, LivenessErrorMsg):
        self._LivenessErrorMsg = LivenessErrorMsg

    @property
    def CompareErrorCode(self):
        r"""The result of this comparison process. `0` indicates that the person in the best face screenshot collected from the video stream is the same as that in the uploaded image for comparison.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: int
        """
        return self._CompareErrorCode

    @CompareErrorCode.setter
    def CompareErrorCode(self, CompareErrorCode):
        self._CompareErrorCode = CompareErrorCode

    @property
    def CompareErrorMsg(self):
        r"""The result description of this comparison process.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._CompareErrorMsg

    @CompareErrorMsg.setter
    def CompareErrorMsg(self, CompareErrorMsg):
        self._CompareErrorMsg = CompareErrorMsg

    @property
    def ReqTimestamp(self):
        r"""The timestamp (ms) of this verification process.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: int
        """
        return self._ReqTimestamp

    @ReqTimestamp.setter
    def ReqTimestamp(self, ReqTimestamp):
        self._ReqTimestamp = ReqTimestamp

    @property
    def Similarity(self):
        r"""The similarity of the best face screenshot collected from the video stream and the uploaded image for comparison in this verification process. Value range: [0.00, 100.00]. By default, the person in the screenshot is determined to be the same person in the image if the similarity is greater than or equal to 70.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: float
        """
        return self._Similarity

    @Similarity.setter
    def Similarity(self, Similarity):
        self._Similarity = Similarity

    @property
    def Seq(self):
        r"""Unique ID of this verification process.
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: str
        """
        return self._Seq

    @Seq.setter
    def Seq(self, Seq):
        self._Seq = Seq


    def _deserialize(self, params):
        self._ErrorCode = params.get("ErrorCode")
        self._ErrorMsg = params.get("ErrorMsg")
        self._LivenessErrorCode = params.get("LivenessErrorCode")
        self._LivenessErrorMsg = params.get("LivenessErrorMsg")
        self._CompareErrorCode = params.get("CompareErrorCode")
        self._CompareErrorMsg = params.get("CompareErrorMsg")
        self._ReqTimestamp = params.get("ReqTimestamp")
        self._Similarity = params.get("Similarity")
        self._Seq = params.get("Seq")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class VideoLivenessCompareRequest(AbstractModel):
    r"""VideoLivenessCompare request structure.

    """

    def __init__(self):
        r"""
        :param _ImageUrl: The URL of the photo for face comparison. The downloaded image after Base64 encoding can be up to 3 MB and must be in JPG or PNG.

The image must be stored in a COS bucket in the region where the FaceID service resides to ensure a higher download speed and better stability. You can generate an image URL by using `CreateUploadUrl` or purchase the COS service.
        :type ImageUrl: str
        :param _ImageMd5: The 32-bit MD5 checksum of the image for comparison
        :type ImageMd5: str
        :param _VideoUrl: The URL of the video for liveness detection. The downloaded video after Base64 encoding can be up to 8 MB and must be in MP4, AVI, or FLV. It takes no more than 4s to download the video.

The video must be stored in a COS bucket in the region where the FaceID service resides to ensure a higher download speed and better stability. You can generate a video URL by using `CreateUploadUrl` or purchase the COS service.
        :type VideoUrl: str
        :param _VideoMd5: The 32-bit MD5 checksum of the video
        :type VideoMd5: str
        :param _LivenessType: The liveness detection type. Valid values: `LIP`, `ACTION`, and `SILENT`.
`LIP`: Numeric mode; `ACTION`: Motion mode; `SILENT`: silent mode. Select one of them.
        :type LivenessType: str
        :param _ValidateData: LIP parameter: Pass in a custom 4-digit verification code.
ACTION parameter: Pass in a custom action sequence (`2,1` or `1,2`).
SILENT parameter: Null.
        :type ValidateData: str
        """
        self._ImageUrl = None
        self._ImageMd5 = None
        self._VideoUrl = None
        self._VideoMd5 = None
        self._LivenessType = None
        self._ValidateData = None

    @property
    def ImageUrl(self):
        r"""The URL of the photo for face comparison. The downloaded image after Base64 encoding can be up to 3 MB and must be in JPG or PNG.

The image must be stored in a COS bucket in the region where the FaceID service resides to ensure a higher download speed and better stability. You can generate an image URL by using `CreateUploadUrl` or purchase the COS service.
        :rtype: str
        """
        return self._ImageUrl

    @ImageUrl.setter
    def ImageUrl(self, ImageUrl):
        self._ImageUrl = ImageUrl

    @property
    def ImageMd5(self):
        r"""The 32-bit MD5 checksum of the image for comparison
        :rtype: str
        """
        return self._ImageMd5

    @ImageMd5.setter
    def ImageMd5(self, ImageMd5):
        self._ImageMd5 = ImageMd5

    @property
    def VideoUrl(self):
        r"""The URL of the video for liveness detection. The downloaded video after Base64 encoding can be up to 8 MB and must be in MP4, AVI, or FLV. It takes no more than 4s to download the video.

The video must be stored in a COS bucket in the region where the FaceID service resides to ensure a higher download speed and better stability. You can generate a video URL by using `CreateUploadUrl` or purchase the COS service.
        :rtype: str
        """
        return self._VideoUrl

    @VideoUrl.setter
    def VideoUrl(self, VideoUrl):
        self._VideoUrl = VideoUrl

    @property
    def VideoMd5(self):
        r"""The 32-bit MD5 checksum of the video
        :rtype: str
        """
        return self._VideoMd5

    @VideoMd5.setter
    def VideoMd5(self, VideoMd5):
        self._VideoMd5 = VideoMd5

    @property
    def LivenessType(self):
        r"""The liveness detection type. Valid values: `LIP`, `ACTION`, and `SILENT`.
`LIP`: Numeric mode; `ACTION`: Motion mode; `SILENT`: silent mode. Select one of them.
        :rtype: str
        """
        return self._LivenessType

    @LivenessType.setter
    def LivenessType(self, LivenessType):
        self._LivenessType = LivenessType

    @property
    def ValidateData(self):
        r"""LIP parameter: Pass in a custom 4-digit verification code.
ACTION parameter: Pass in a custom action sequence (`2,1` or `1,2`).
SILENT parameter: Null.
        :rtype: str
        """
        return self._ValidateData

    @ValidateData.setter
    def ValidateData(self, ValidateData):
        self._ValidateData = ValidateData


    def _deserialize(self, params):
        self._ImageUrl = params.get("ImageUrl")
        self._ImageMd5 = params.get("ImageMd5")
        self._VideoUrl = params.get("VideoUrl")
        self._VideoMd5 = params.get("VideoMd5")
        self._LivenessType = params.get("LivenessType")
        self._ValidateData = params.get("ValidateData")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        


class VideoLivenessCompareResponse(AbstractModel):
    r"""VideoLivenessCompare response structure.

    """

    def __init__(self):
        r"""
        :param _Sim: The similarity. Value range: [0.00, 100.00]. As a recommendation, when the similarity is greater than or equal to 70, it can be determined that the two persons are of the same person. You can adjust the threshold according to your specific scenario (the FARs at the thresholds of 70 and 80 are 0.1% and 0.01%, respectively).
        :type Sim: float
        :param _Result: The service error code. `Success` will be returned for success. For error information, see the `FailedOperation` section in the error code list below.
        :type Result: str
        :param _Description: The service result description
        :type Description: str
        :param _BestFrame: The best video screenshot after successful verification
Note: This field may return null, indicating that no valid values can be obtained.
        :type BestFrame: :class:`tencentcloud.faceid.v20180301.models.FileInfo`
        :param _RequestId: The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :type RequestId: str
        """
        self._Sim = None
        self._Result = None
        self._Description = None
        self._BestFrame = None
        self._RequestId = None

    @property
    def Sim(self):
        r"""The similarity. Value range: [0.00, 100.00]. As a recommendation, when the similarity is greater than or equal to 70, it can be determined that the two persons are of the same person. You can adjust the threshold according to your specific scenario (the FARs at the thresholds of 70 and 80 are 0.1% and 0.01%, respectively).
        :rtype: float
        """
        return self._Sim

    @Sim.setter
    def Sim(self, Sim):
        self._Sim = Sim

    @property
    def Result(self):
        r"""The service error code. `Success` will be returned for success. For error information, see the `FailedOperation` section in the error code list below.
        :rtype: str
        """
        return self._Result

    @Result.setter
    def Result(self, Result):
        self._Result = Result

    @property
    def Description(self):
        r"""The service result description
        :rtype: str
        """
        return self._Description

    @Description.setter
    def Description(self, Description):
        self._Description = Description

    @property
    def BestFrame(self):
        r"""The best video screenshot after successful verification
Note: This field may return null, indicating that no valid values can be obtained.
        :rtype: :class:`tencentcloud.faceid.v20180301.models.FileInfo`
        """
        return self._BestFrame

    @BestFrame.setter
    def BestFrame(self, BestFrame):
        self._BestFrame = BestFrame

    @property
    def RequestId(self):
        r"""The unique request ID, generated by the server, will be returned for every request (if the request fails to reach the server for other reasons, the request will not obtain a RequestId). RequestId is required for locating a problem.
        :rtype: str
        """
        return self._RequestId

    @RequestId.setter
    def RequestId(self, RequestId):
        self._RequestId = RequestId


    def _deserialize(self, params):
        self._Sim = params.get("Sim")
        self._Result = params.get("Result")
        self._Description = params.get("Description")
        if params.get("BestFrame") is not None:
            self._BestFrame = FileInfo()
            self._BestFrame._deserialize(params.get("BestFrame"))
        self._RequestId = params.get("RequestId")


class WebVerificationConfigIntl(AbstractModel):
    r"""eKYC Web related configuration

    """

    def __init__(self):
        r"""
        :param _AutoSkipStartPage: When starting verification, whether to skip the starting verification page. If true, enter the verification process directly. This configuration will not take effect if the downgrade policy is triggered. The default is false.
Example: false
        :type AutoSkipStartPage: bool
        :param _AutoSkip: When the verification passed, whether to skip the result page and automatically jump to RedirectURL. The default value is false.
Example: false
        :type AutoSkip: bool
        :param _CheckMode: Detection mode, parameter values are as follows:
1: OCR+liveness detection & face comparison;
2: Liveness detection & face comparison;
3: Liveness detection;
4: OCR;
The default value is 2.
Example: 3
        :type CheckMode: int
        :param _IDCardType: Card Type for verification. The following types are supported:
1.HKIDCard: Hong Kong (China) ID card
2.MLIDCard: Malaysia ID card
3.IndonesiaIDCard: Indonesia ID card
4.PhilippinesVoteID: Philippines Vote lD card
5.PhilippinesDrivingLicense: Philippines driving license
6.PhilippinesTinID: Philippines TinID card
7.PhilippinesSSSID: Philippines SSSID card
8.PhilippinesUMID: Philippines UMID card
9.InternationalIDPassport: ID cards of Hong Kong (China), Macao (China) and Taiwan (China), and international passport.
10.ThailandIDCard: Thailand ID card
11.SingaporeIDCard: Singapore ID card
12.MainlandIDCard: Mainland (China) ID card
Example: HKIDCard
        :type IDCardType: str
        :param _DisableCheckOcrWarnings: Whether to turn off document alarms, the default is false (the alarm detection function is turned on). When enabled, the identity authentication process will be intercepted based on the alarm status of the certificate. If you need to use the document authentication function, please contact us.
Example: false
        :type DisableCheckOcrWarnings: bool
        :param _SecurityLevel: Liveness security level, the default value is 3. The currently supported security level are as follows:
1:Silent mode;
2:Action mode;
3:Lighting mode;
4:Action+Lighting mode;
5:Action+Lighting(High security) mode. This mode offers higher security but has a lower pass rate. Please contact us before use.

Example: 4
        :type SecurityLevel: int
        :param _SkipPrivacyPolicy: Whether to skip the agreement page. When SkipPrivacyPolicy is false, the agreement page will be displayed and the privacy agreement needs to be checked; when SkipPrivacyPolicy is true, the agreement page will be skipped and the liveness process will be entered directly without checking the privacy agreement page. The default is false.
Example: false
        :type SkipPrivacyPolicy: bool
        :param _IdCardCutReturn: whether to display the cropped ID card image. When set to false, the original ID card image is displayed. When set to true, the cropped version is displayed. The default value is false. 
Example: false
        :type IdCardCutReturn: bool
        :param _ThemeColor: Front-end theme color, in the format of RGB hexadecimal color code. If the format is incorrect, the default value color will be used. The default value is "#2d72f1".
Example: #2d72f1
        :type ThemeColor: str
        :param _Language: International language, the default value is en (English). The currently supported language are as follows: 
th: Thai; 
en: English; 
zh-cn: Simplified Chinese; 
zh-tc: Tradionnal Chinese; 
id: Bahasa Indonesia.
        :type Language: str
        :param _AutoDowngrade: Automatic downgrade mode, the following parameter are supported: 
1: Downgrade to silent live mode; 
2: Disable downgrade mode. 
The default value is 1.
        :type AutoDowngrade: int
        :param _ActionList: This interface is used to control th action sequences.
The supported action types are as follows:
"blink";
"mouth";
"nod";
"shake".
You can choose 1-2 actions out of the four. Single action example: "blink". Multiple action example: "blink,mouth". The different action types passed in this parameter take effect only when the SecurityLevel is 2, 4, or 5; otherwise, the interface reports an error.
The default value is blink.
        :type ActionList: str
        :param _LivenessRetryLimit: Maximum liveness verification attempts. Valid range: [1,99].
The default value is 99.
        :type LivenessRetryLimit: int
        :param _LivenessTimeout: Specifies the liveness detection timeout period in seconds. Value range: (0,600].
The default value is 45.
        :type LivenessTimeout: int
        :param _SelectedWarningCodes: Selects OCR alarms requiring attention. When an OCR Alarm occurs, the identity verification process will be interrupted. Default value is empty, indicating all alarms are monitored. This feature requires the parameter DisableCheckOcrWarnings=false. If the Alarm is disabled, this parameter will not be effective. The supported alarm types are as follows:
-9101: Incomplete Border Alert;
-9102: Copy Document Alert;
-9103: Remediated Document Alert;
-9104: PS-altered Document Alert;
-9107: Glare Alert;
-9108: Blurriness Alert;
-9109: Alert Not Activated.
        :type SelectedWarningCodes: str
        :param _AllowExpiredDocument: Whether expired identity documents are permitted to proceed to the liveness detection process. This parameter only takes effect when the document type is Hong Kong Identity Card (HKID).
true (default value): Expired HKID is allowed to enter the liveness process.
false : Expired HKID is rejected and cannot enter the liveness process.
        :type AllowExpiredDocument: bool
        :param _Version: Service version, including Basic version (BASIC) and PLUS version (PLUS). The currently supported service version are as follows:
BASIC: Basic version.
PLUS: PLUS version.
The default value is BASIC.
        :type Version: str
        """
        self._AutoSkipStartPage = None
        self._AutoSkip = None
        self._CheckMode = None
        self._IDCardType = None
        self._DisableCheckOcrWarnings = None
        self._SecurityLevel = None
        self._SkipPrivacyPolicy = None
        self._IdCardCutReturn = None
        self._ThemeColor = None
        self._Language = None
        self._AutoDowngrade = None
        self._ActionList = None
        self._LivenessRetryLimit = None
        self._LivenessTimeout = None
        self._SelectedWarningCodes = None
        self._AllowExpiredDocument = None
        self._Version = None

    @property
    def AutoSkipStartPage(self):
        r"""When starting verification, whether to skip the starting verification page. If true, enter the verification process directly. This configuration will not take effect if the downgrade policy is triggered. The default is false.
Example: false
        :rtype: bool
        """
        return self._AutoSkipStartPage

    @AutoSkipStartPage.setter
    def AutoSkipStartPage(self, AutoSkipStartPage):
        self._AutoSkipStartPage = AutoSkipStartPage

    @property
    def AutoSkip(self):
        r"""When the verification passed, whether to skip the result page and automatically jump to RedirectURL. The default value is false.
Example: false
        :rtype: bool
        """
        return self._AutoSkip

    @AutoSkip.setter
    def AutoSkip(self, AutoSkip):
        self._AutoSkip = AutoSkip

    @property
    def CheckMode(self):
        r"""Detection mode, parameter values are as follows:
1: OCR+liveness detection & face comparison;
2: Liveness detection & face comparison;
3: Liveness detection;
4: OCR;
The default value is 2.
Example: 3
        :rtype: int
        """
        return self._CheckMode

    @CheckMode.setter
    def CheckMode(self, CheckMode):
        self._CheckMode = CheckMode

    @property
    def IDCardType(self):
        r"""Card Type for verification. The following types are supported:
1.HKIDCard: Hong Kong (China) ID card
2.MLIDCard: Malaysia ID card
3.IndonesiaIDCard: Indonesia ID card
4.PhilippinesVoteID: Philippines Vote lD card
5.PhilippinesDrivingLicense: Philippines driving license
6.PhilippinesTinID: Philippines TinID card
7.PhilippinesSSSID: Philippines SSSID card
8.PhilippinesUMID: Philippines UMID card
9.InternationalIDPassport: ID cards of Hong Kong (China), Macao (China) and Taiwan (China), and international passport.
10.ThailandIDCard: Thailand ID card
11.SingaporeIDCard: Singapore ID card
12.MainlandIDCard: Mainland (China) ID card
Example: HKIDCard
        :rtype: str
        """
        return self._IDCardType

    @IDCardType.setter
    def IDCardType(self, IDCardType):
        self._IDCardType = IDCardType

    @property
    def DisableCheckOcrWarnings(self):
        r"""Whether to turn off document alarms, the default is false (the alarm detection function is turned on). When enabled, the identity authentication process will be intercepted based on the alarm status of the certificate. If you need to use the document authentication function, please contact us.
Example: false
        :rtype: bool
        """
        return self._DisableCheckOcrWarnings

    @DisableCheckOcrWarnings.setter
    def DisableCheckOcrWarnings(self, DisableCheckOcrWarnings):
        self._DisableCheckOcrWarnings = DisableCheckOcrWarnings

    @property
    def SecurityLevel(self):
        r"""Liveness security level, the default value is 3. The currently supported security level are as follows:
1:Silent mode;
2:Action mode;
3:Lighting mode;
4:Action+Lighting mode;
5:Action+Lighting(High security) mode. This mode offers higher security but has a lower pass rate. Please contact us before use.

Example: 4
        :rtype: int
        """
        return self._SecurityLevel

    @SecurityLevel.setter
    def SecurityLevel(self, SecurityLevel):
        self._SecurityLevel = SecurityLevel

    @property
    def SkipPrivacyPolicy(self):
        r"""Whether to skip the agreement page. When SkipPrivacyPolicy is false, the agreement page will be displayed and the privacy agreement needs to be checked; when SkipPrivacyPolicy is true, the agreement page will be skipped and the liveness process will be entered directly without checking the privacy agreement page. The default is false.
Example: false
        :rtype: bool
        """
        return self._SkipPrivacyPolicy

    @SkipPrivacyPolicy.setter
    def SkipPrivacyPolicy(self, SkipPrivacyPolicy):
        self._SkipPrivacyPolicy = SkipPrivacyPolicy

    @property
    def IdCardCutReturn(self):
        r"""whether to display the cropped ID card image. When set to false, the original ID card image is displayed. When set to true, the cropped version is displayed. The default value is false. 
Example: false
        :rtype: bool
        """
        return self._IdCardCutReturn

    @IdCardCutReturn.setter
    def IdCardCutReturn(self, IdCardCutReturn):
        self._IdCardCutReturn = IdCardCutReturn

    @property
    def ThemeColor(self):
        r"""Front-end theme color, in the format of RGB hexadecimal color code. If the format is incorrect, the default value color will be used. The default value is "#2d72f1".
Example: #2d72f1
        :rtype: str
        """
        return self._ThemeColor

    @ThemeColor.setter
    def ThemeColor(self, ThemeColor):
        self._ThemeColor = ThemeColor

    @property
    def Language(self):
        r"""International language, the default value is en (English). The currently supported language are as follows: 
th: Thai; 
en: English; 
zh-cn: Simplified Chinese; 
zh-tc: Tradionnal Chinese; 
id: Bahasa Indonesia.
        :rtype: str
        """
        return self._Language

    @Language.setter
    def Language(self, Language):
        self._Language = Language

    @property
    def AutoDowngrade(self):
        r"""Automatic downgrade mode, the following parameter are supported: 
1: Downgrade to silent live mode; 
2: Disable downgrade mode. 
The default value is 1.
        :rtype: int
        """
        return self._AutoDowngrade

    @AutoDowngrade.setter
    def AutoDowngrade(self, AutoDowngrade):
        self._AutoDowngrade = AutoDowngrade

    @property
    def ActionList(self):
        r"""This interface is used to control th action sequences.
The supported action types are as follows:
"blink";
"mouth";
"nod";
"shake".
You can choose 1-2 actions out of the four. Single action example: "blink". Multiple action example: "blink,mouth". The different action types passed in this parameter take effect only when the SecurityLevel is 2, 4, or 5; otherwise, the interface reports an error.
The default value is blink.
        :rtype: str
        """
        return self._ActionList

    @ActionList.setter
    def ActionList(self, ActionList):
        self._ActionList = ActionList

    @property
    def LivenessRetryLimit(self):
        r"""Maximum liveness verification attempts. Valid range: [1,99].
The default value is 99.
        :rtype: int
        """
        return self._LivenessRetryLimit

    @LivenessRetryLimit.setter
    def LivenessRetryLimit(self, LivenessRetryLimit):
        self._LivenessRetryLimit = LivenessRetryLimit

    @property
    def LivenessTimeout(self):
        r"""Specifies the liveness detection timeout period in seconds. Value range: (0,600].
The default value is 45.
        :rtype: int
        """
        return self._LivenessTimeout

    @LivenessTimeout.setter
    def LivenessTimeout(self, LivenessTimeout):
        self._LivenessTimeout = LivenessTimeout

    @property
    def SelectedWarningCodes(self):
        r"""Selects OCR alarms requiring attention. When an OCR Alarm occurs, the identity verification process will be interrupted. Default value is empty, indicating all alarms are monitored. This feature requires the parameter DisableCheckOcrWarnings=false. If the Alarm is disabled, this parameter will not be effective. The supported alarm types are as follows:
-9101: Incomplete Border Alert;
-9102: Copy Document Alert;
-9103: Remediated Document Alert;
-9104: PS-altered Document Alert;
-9107: Glare Alert;
-9108: Blurriness Alert;
-9109: Alert Not Activated.
        :rtype: str
        """
        return self._SelectedWarningCodes

    @SelectedWarningCodes.setter
    def SelectedWarningCodes(self, SelectedWarningCodes):
        self._SelectedWarningCodes = SelectedWarningCodes

    @property
    def AllowExpiredDocument(self):
        r"""Whether expired identity documents are permitted to proceed to the liveness detection process. This parameter only takes effect when the document type is Hong Kong Identity Card (HKID).
true (default value): Expired HKID is allowed to enter the liveness process.
false : Expired HKID is rejected and cannot enter the liveness process.
        :rtype: bool
        """
        return self._AllowExpiredDocument

    @AllowExpiredDocument.setter
    def AllowExpiredDocument(self, AllowExpiredDocument):
        self._AllowExpiredDocument = AllowExpiredDocument

    @property
    def Version(self):
        r"""Service version, including Basic version (BASIC) and PLUS version (PLUS). The currently supported service version are as follows:
BASIC: Basic version.
PLUS: PLUS version.
The default value is BASIC.
        :rtype: str
        """
        return self._Version

    @Version.setter
    def Version(self, Version):
        self._Version = Version


    def _deserialize(self, params):
        self._AutoSkipStartPage = params.get("AutoSkipStartPage")
        self._AutoSkip = params.get("AutoSkip")
        self._CheckMode = params.get("CheckMode")
        self._IDCardType = params.get("IDCardType")
        self._DisableCheckOcrWarnings = params.get("DisableCheckOcrWarnings")
        self._SecurityLevel = params.get("SecurityLevel")
        self._SkipPrivacyPolicy = params.get("SkipPrivacyPolicy")
        self._IdCardCutReturn = params.get("IdCardCutReturn")
        self._ThemeColor = params.get("ThemeColor")
        self._Language = params.get("Language")
        self._AutoDowngrade = params.get("AutoDowngrade")
        self._ActionList = params.get("ActionList")
        self._LivenessRetryLimit = params.get("LivenessRetryLimit")
        self._LivenessTimeout = params.get("LivenessTimeout")
        self._SelectedWarningCodes = params.get("SelectedWarningCodes")
        self._AllowExpiredDocument = params.get("AllowExpiredDocument")
        self._Version = params.get("Version")
        memeber_set = set(params.keys())
        for name, value in vars(self).items():
            property_name = name[1:]
            if property_name in memeber_set:
                memeber_set.remove(property_name)
        if len(memeber_set) > 0:
            warnings.warn("%s fileds are useless." % ",".join(memeber_set))
        