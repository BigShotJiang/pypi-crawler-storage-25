"""Integration tests against the real Fluvius sandbox API.

These tests require valid sandbox credentials in environment variables:
- FLUVIUS_SUBSCRIPTION_KEY
- FLUVIUS_CLIENT_ID
- FLUVIUS_TENANT_ID
- FLUVIUS_SCOPE
- FLUVIUS_DATA_ACCESS_CONTRACT_NUMBER
- FLUVIUS_CLIENT_SECRET
"""

from __future__ import annotations

import os
import uuid

import pytest
from pyspark.sql import SparkSession

from fluvius_energy_api import FluviusCredentials, FluviusEnergyClient
from fluvius_energy_api.client import Environment
from fluvius_energy_api.models.enums import DataServiceType, MandateStatus

from pyspark_fluvius import register_datasources

pytestmark = pytest.mark.integration

# Test EAN for sandbox - must match pattern: 5414[4-5][0-1][0-2][0-2][0-2]000000[0-9][0-9][0-9]
TEST_EAN = "541450000000000001"


@pytest.fixture(scope="module")
def has_credentials() -> bool:
    """Check if sandbox credentials are available."""
    required_vars = [
        "FLUVIUS_SUBSCRIPTION_KEY",
        "FLUVIUS_SANDBOX_CLIENT_ID",
        "FLUVIUS_TENANT_ID",
        "FLUVIUS_SCOPE",
        "FLUVIUS_DATA_ACCESS_CONTRACT_NUMBER",
        "FLUVIUS_SANDBOX_CLIENT_SECRET",
    ]
    return all(os.environ.get(var) for var in required_vars)


@pytest.fixture(scope="module")
def sandbox_credentials() -> FluviusCredentials:
    """Create sandbox credentials using client_secret auth (not certificate)."""
    return FluviusCredentials(
        subscription_key=os.environ["FLUVIUS_SUBSCRIPTION_KEY"],
        client_id=os.environ["FLUVIUS_SANDBOX_CLIENT_ID"],
        tenant_id=os.environ["FLUVIUS_TENANT_ID"],
        scope=os.environ["FLUVIUS_SCOPE"],
        data_access_contract_number=os.environ["FLUVIUS_DATA_ACCESS_CONTRACT_NUMBER"],
        client_secret=os.environ["FLUVIUS_SANDBOX_CLIENT_SECRET"],
        # No certificate credentials - force client_secret auth for sandbox
    )


@pytest.fixture(scope="module")
def spark_options() -> dict[str, str]:
    """Return Spark options for sandbox with client_secret auth."""
    return {
        "subscription_key": os.environ["FLUVIUS_SUBSCRIPTION_KEY"],
        "client_id": os.environ["FLUVIUS_SANDBOX_CLIENT_ID"],
        "tenant_id": os.environ["FLUVIUS_TENANT_ID"],
        "scope": os.environ["FLUVIUS_SCOPE"],
        "data_access_contract_number": os.environ["FLUVIUS_DATA_ACCESS_CONTRACT_NUMBER"],
        "client_secret": os.environ["FLUVIUS_SANDBOX_CLIENT_SECRET"],
        "environment": "sandbox",
    }


@pytest.fixture(scope="module")
def mock_mandate_reference(has_credentials: bool, sandbox_credentials: FluviusCredentials) -> str | None:
    """Create a mock mandate in the sandbox and return its reference number."""
    if not has_credentials:
        return None

    reference = f"spark-fluvius-test-{uuid.uuid4().hex[:8]}"

    with FluviusEnergyClient(credentials=sandbox_credentials, environment=Environment.SANDBOX) as client:
        client.create_mock_mandate(
            reference_number=reference,
            ean=TEST_EAN,
            data_service_type=DataServiceType.VH_DAG,
            data_period_from="2024-01-01T00:00:00Z",
            data_period_to="2024-12-31T23:59:59Z",
            status=MandateStatus.APPROVED,
        )

    print(f"\nCreated mock mandate with reference: {reference}")
    return reference


@pytest.fixture(scope="module")
def spark(mock_mandate_reference: str | None) -> SparkSession:
    """Create a SparkSession for integration tests."""
    # mock_mandate_reference dependency ensures mandate is created first
    session = (
        SparkSession.builder.appName("FluviusIntegrationTests")
        .master("local[*]")
        .getOrCreate()
    )
    register_datasources()
    yield session
    session.stop()


def _apply_options(reader, options: dict[str, str]):
    """Apply options to a DataFrameReader."""
    for key, value in options.items():
        reader = reader.option(key, value)
    return reader


class TestMandatesIntegration:
    """Integration tests for mandates data source."""

    def test_read_all_mandates(
        self,
        spark: SparkSession,
        has_credentials: bool,
        mock_mandate_reference: str | None,
        spark_options: dict[str, str],
    ) -> None:
        """Test reading all mandates from sandbox."""
        if not has_credentials:
            pytest.skip("Sandbox credentials not available")

        reader = spark.read.format("fluvius.mandates")
        df = _apply_options(reader, spark_options).load()

        # Should return a DataFrame with the correct schema
        assert "reference_number" in df.columns
        assert "status" in df.columns
        assert "ean" in df.columns
        assert "energy_type" in df.columns

        # Print results for inspection
        count = df.count()
        print(f"\nFound {count} mandates")
        assert count > 0, "Expected at least one mandate (the mock we created)"
        df.show(truncate=False)

    def test_read_approved_mandates(
        self,
        spark: SparkSession,
        has_credentials: bool,
        mock_mandate_reference: str | None,
        spark_options: dict[str, str],
    ) -> None:
        """Test reading only approved mandates."""
        if not has_credentials:
            pytest.skip("Sandbox credentials not available")

        reader = spark.read.format("fluvius.mandates")
        options = {**spark_options, "status": "Approved"}
        df = _apply_options(reader, options).load()

        count = df.count()
        print(f"\nFound {count} approved mandates")
        assert count > 0, "Expected at least one approved mandate"
        df.show(truncate=False)

        # All returned mandates should have Approved status
        statuses = [row.status for row in df.collect()]
        for status in statuses:
            assert status == "Approved", f"Expected Approved but got {status}"

    def test_read_mandate_by_reference(
        self,
        spark: SparkSession,
        has_credentials: bool,
        mock_mandate_reference: str | None,
        spark_options: dict[str, str],
    ) -> None:
        """Test reading a specific mandate by reference number."""
        if not has_credentials:
            pytest.skip("Sandbox credentials not available")

        reader = spark.read.format("fluvius.mandates")
        options = {**spark_options, "reference_number": mock_mandate_reference}
        df = _apply_options(reader, options).load()

        count = df.count()
        print(f"\nFound {count} mandates with reference {mock_mandate_reference}")
        assert count == 1, f"Expected exactly 1 mandate, got {count}"

        mandate = df.first()
        assert mandate.reference_number == mock_mandate_reference
        assert mandate.ean == TEST_EAN
        assert mandate.status == "Approved"
        df.show(truncate=False)


class TestEnergyIntegration:
    """Integration tests for energy data source."""

    def test_read_energy_data(
        self,
        spark: SparkSession,
        has_credentials: bool,
        mock_mandate_reference: str | None,
        spark_options: dict[str, str],
    ) -> None:
        """Test reading energy data from sandbox."""
        if not has_credentials:
            pytest.skip("Sandbox credentials not available")

        print(f"\nUsing EAN: {TEST_EAN}, reference: {mock_mandate_reference}")

        reader = spark.read.format("fluvius.energy")
        options = {
            **spark_options,
            "ean": TEST_EAN,
            "reference_number": mock_mandate_reference,
            "period_type": "readTime",
            "granularity": "daily",
            "from_date": "2024-01-01",
            "to_date": "2024-01-10",
        }
        energy_df = _apply_options(reader, options).load()

        # Should return a DataFrame with the correct schema
        assert "ean" in energy_df.columns
        assert "energy_type" in energy_df.columns
        assert "start" in energy_df.columns
        assert "direction" in energy_df.columns
        assert "register_type" in energy_df.columns
        assert "value" in energy_df.columns

        count = energy_df.count()
        print(f"\nFound {count} energy measurements")

        if count > 0:
            energy_df.select(
                "ean",
                "energy_type",
                "start",
                "end",
                "granularity",
                "direction",
                "register_type",
                "value",
                "unit",
            ).show(truncate=False)

    def test_read_energy_with_date_range(
        self,
        spark: SparkSession,
        has_credentials: bool,
        mock_mandate_reference: str | None,
        spark_options: dict[str, str],
    ) -> None:
        """Test reading energy data with a date range filter."""
        if not has_credentials:
            pytest.skip("Sandbox credentials not available")

        reader = spark.read.format("fluvius.energy")
        options = {
            **spark_options,
            "ean": TEST_EAN,
            "reference_number": mock_mandate_reference,
            "period_type": "readTime",
            "granularity": "daily",
            "from_date": "2024-01-01",
            "to_date": "2024-01-15",
        }
        energy_df = _apply_options(reader, options).load()

        count = energy_df.count()
        print(f"\nFound {count} energy measurements for Jan 2024")

        if count > 0:
            energy_df.select(
                "ean",
                "start",
                "end",
                "direction",
                "register_type",
                "value",
            ).show(10, truncate=False)


class TestDataAnalysis:
    """Test data analysis capabilities."""

    def test_aggregate_energy_data(
        self,
        spark: SparkSession,
        has_credentials: bool,
        mock_mandate_reference: str | None,
        spark_options: dict[str, str],
    ) -> None:
        """Test aggregating energy measurements."""
        if not has_credentials:
            pytest.skip("Sandbox credentials not available")

        reader = spark.read.format("fluvius.energy")
        options = {
            **spark_options,
            "ean": TEST_EAN,
            "reference_number": mock_mandate_reference,
            "period_type": "readTime",
            "granularity": "daily",
            "from_date": "2024-01-01",
            "to_date": "2024-01-31",
        }
        energy_df = _apply_options(reader, options).load()

        count = energy_df.count()
        if count == 0:
            pytest.skip("No energy data available for this EAN")

        from pyspark.sql.functions import avg, count as spark_count, max, min, sum

        # Filter to offtake/day rows and aggregate
        offtake_day = energy_df.filter(
            (energy_df.direction == "offtake") & (energy_df.register_type == "day")
        )

        stats = offtake_day.agg(
            spark_count("*").alias("count"),
            sum("value").alias("total_day_consumption"),
            avg("value").alias("avg_day_consumption"),
            min("value").alias("min_day_consumption"),
            max("value").alias("max_day_consumption"),
        )

        print("\nEnergy consumption statistics (offtake/day):")
        stats.show(truncate=False)

        # Verify we got results
        total_count = energy_df.count()
        assert total_count > 0
