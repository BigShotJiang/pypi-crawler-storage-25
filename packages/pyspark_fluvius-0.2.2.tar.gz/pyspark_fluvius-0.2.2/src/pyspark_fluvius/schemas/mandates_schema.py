"""Spark schema for mandates data."""

from pyspark.sql.types import StringType, StructField, StructType, TimestampType

MANDATES_SCHEMA = StructType(
    [
        StructField("reference_number", StringType(), nullable=True),
        StructField("status", StringType(), nullable=True),
        StructField("ean", StringType(), nullable=True),
        StructField("energy_type", StringType(), nullable=True),
        StructField("data_period_from", TimestampType(), nullable=True),
        StructField("data_period_to", TimestampType(), nullable=True),
        StructField("data_service_type", StringType(), nullable=True),
        StructField("mandate_expiration_date", TimestampType(), nullable=True),
        StructField("renewal_status", StringType(), nullable=True),
    ]
)
