"""Spark schema for normalized energy measurement data."""

from pyspark.sql.types import (
    DoubleType,
    StringType,
    StructField,
    StructType,
    TimestampType,
)

ENERGY_SCHEMA = StructType(
    [
        StructField("ean", StringType(), nullable=False),
        StructField("energy_type", StringType(), nullable=True),
        StructField("metering_type", StringType(), nullable=False),
        StructField("source", StringType(), nullable=False),
        StructField("meter_id", StringType(), nullable=True),
        StructField("seq_number", StringType(), nullable=True),
        StructField("sub_headpoint_ean", StringType(), nullable=True),
        StructField("sub_headpoint_type", StringType(), nullable=True),
        StructField("sub_headpoint_seq_number", StringType(), nullable=True),
        StructField("vreg_id", StringType(), nullable=True),
        StructField("production_installation_type", StringType(), nullable=True),
        StructField("granularity", StringType(), nullable=False),
        StructField("start", TimestampType(), nullable=False),
        StructField("end", TimestampType(), nullable=False),
        StructField("direction", StringType(), nullable=False),
        StructField("register_type", StringType(), nullable=False),
        StructField("value", DoubleType(), nullable=True),
        StructField("unit", StringType(), nullable=True),
        StructField("validation_state", StringType(), nullable=True),
        StructField("gas_conversion_factor", StringType(), nullable=True),
    ]
)
