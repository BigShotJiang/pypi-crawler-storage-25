"""Mandates data source reader."""

from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING, Iterator

from pyspark.sql.datasource import DataSourceReader, InputPartition

from fluvius_energy_api import FluviusEnergyClient
from fluvius_energy_api.models.enums import (
    DataServiceType,
    EnergyType,
    MandateRenewalStatus,
    MandateStatus,
)

from ..converters.mandates_converter import MandateTuple, convert_mandate
from ..utils.credentials import get_credentials, get_environment

if TYPE_CHECKING:
    from pyspark.sql.types import StructType


class FluviusMandatesReader(DataSourceReader):
    """Reader for Fluvius mandates data."""

    def __init__(self, schema: StructType, options: dict[str, str]) -> None:
        """Initialize the mandates reader.

        Args:
            schema: The Spark schema for mandates.
            options: Options passed to the data source.
        """
        self._schema = schema
        self._options = options

    def partitions(self) -> list[InputPartition]:
        """Return a single partition for mandates."""
        return [InputPartition(0)]

    def read(self, partition: InputPartition) -> Iterator[MandateTuple]:
        """Read mandates from the Fluvius API.

        Args:
            partition: The partition to read (unused, single partition).

        Yields:
            Tuples representing mandate rows.
        """
        credentials = get_credentials(self._options)
        environment = get_environment(self._options)

        # Parse filter options
        reference_number = self._options.get("reference_number")
        ean = self._options.get("ean")

        # Parse data_service_types (comma-separated string)
        data_service_types_str = self._options.get("data_service_types")
        data_service_types: list[DataServiceType] | None = None
        if data_service_types_str:
            data_service_types = [
                DataServiceType(t.strip()) for t in data_service_types_str.split(",")
            ]

        # Parse energy_type
        energy_type_str = self._options.get("energy_type")
        energy_type: EnergyType | None = None
        if energy_type_str:
            energy_type = EnergyType(energy_type_str)

        # Parse status
        status_str = self._options.get("status")
        status: MandateStatus | None = None
        if status_str:
            status = MandateStatus(status_str)

        # Parse mandate_expiration_date
        mandate_expiration_date_str = self._options.get("mandate_expiration_date")
        mandate_expiration_date: datetime | None = None
        if mandate_expiration_date_str:
            mandate_expiration_date = datetime.fromisoformat(
                mandate_expiration_date_str.replace("Z", "+00:00")
            )

        # Parse renewal_status
        renewal_status_str = self._options.get("renewal_status")
        renewal_status: MandateRenewalStatus | None = None
        if renewal_status_str:
            renewal_status = MandateRenewalStatus(renewal_status_str)

        # Parse last_updated_from/to
        last_updated_from_str = self._options.get("last_updated_from")
        last_updated_from: datetime | None = None
        if last_updated_from_str:
            last_updated_from = datetime.fromisoformat(
                last_updated_from_str.replace("Z", "+00:00")
            )

        last_updated_to_str = self._options.get("last_updated_to")
        last_updated_to: datetime | None = None
        if last_updated_to_str:
            last_updated_to = datetime.fromisoformat(last_updated_to_str.replace("Z", "+00:00"))

        with FluviusEnergyClient(credentials=credentials, environment=environment) as client:
            response = client.get_mandates(
                reference_number=reference_number,
                ean=ean,
                data_service_types=data_service_types,
                energy_type=energy_type,
                status=status,
                mandate_expiration_date=mandate_expiration_date,
                renewal_status=renewal_status,
                last_updated_from=last_updated_from,
                last_updated_to=last_updated_to,
            )

            if response.data and response.data.mandates:
                for mandate in response.data.mandates:
                    yield convert_mandate(mandate)
