"""Energy data source reader."""

from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING, Iterator

from pyspark.sql.datasource import DataSourceReader, InputPartition

from fluvius_energy_api import FluviusEnergyClient
from fluvius_energy_api.exceptions import NotFoundError
from fluvius_energy_api.models.enums import PeriodType

from ..converters.energy_converter import EnergyTuple, convert_energy_response
from ..utils.credentials import get_credentials, get_environment

if TYPE_CHECKING:
    from pyspark.sql.types import StructType


class FluviusEnergyReader(DataSourceReader):
    """Reader for Fluvius energy data."""

    def __init__(self, schema: StructType, options: dict[str, str]) -> None:
        """Initialize the energy reader.

        Args:
            schema: The Spark schema for energy data.
            options: Options passed to the data source.
        """
        self._schema = schema
        self._options = options

    def partitions(self) -> list[InputPartition]:
        """Return a single partition for energy data."""
        return [InputPartition(0)]

    def read(self, partition: InputPartition) -> Iterator[EnergyTuple]:
        """Read energy data from the Fluvius API.

        Args:
            partition: The partition to read (unused, single partition).

        Yields:
            Tuples representing energy measurement rows.

        Raises:
            ValueError: If required options (ean, period_type) are missing.
        """
        # Required options
        ean = self._options.get("ean")
        if not ean:
            raise ValueError("Option 'ean' is required for fluvius.energy data source")

        period_type_str = self._options.get("period_type")
        if not period_type_str:
            raise ValueError("Option 'period_type' is required for fluvius.energy data source")

        period_type = PeriodType(period_type_str)

        # Optional filters
        reference_number = self._options.get("reference_number")
        granularity = self._options.get("granularity")
        complex_energy_types = self._options.get("complex_energy_types")

        # Parse dates
        from_date_str = self._options.get("from_date")
        from_date: datetime | None = None
        if from_date_str:
            from_date = datetime.fromisoformat(from_date_str.replace("Z", "+00:00"))

        to_date_str = self._options.get("to_date")
        to_date: datetime | None = None
        if to_date_str:
            to_date = datetime.fromisoformat(to_date_str.replace("Z", "+00:00"))

        credentials = get_credentials(self._options)
        environment = get_environment(self._options)

        with FluviusEnergyClient(credentials=credentials, environment=environment) as client:
            try:
                response = client.get_energy(
                    ean=ean,
                    period_type=period_type,
                    reference_number=reference_number,
                    granularity=granularity,
                    complex_energy_types=complex_energy_types,
                    from_date=from_date,
                    to_date=to_date,
                )
            except NotFoundError:
                return

            rows = convert_energy_response(response)
            yield from rows
