"""Fluvius Mandates data source for PySpark."""

from __future__ import annotations

from typing import TYPE_CHECKING

from pyspark.sql.datasource import DataSource, DataSourceReader
from pyspark.sql.types import StructType

from ..readers.mandates_reader import FluviusMandatesReader
from ..schemas.mandates_schema import MANDATES_SCHEMA

if TYPE_CHECKING:
    pass


class FluviusMandatesDataSource(DataSource):
    """PySpark data source for reading Fluvius mandates.

    This data source allows you to read mandates from the Fluvius Energy API
    directly into a Spark DataFrame.

    Options:
        Credential options (if not using environment variables):
            - subscription_key: Azure API Management subscription key
            - client_id: Azure AD application (client) ID
            - tenant_id: Azure AD tenant ID
            - scope: OAuth2 scope
            - data_access_contract_number: Data access contract number
            - certificate_thumbprint: Certificate thumbprint (for cert auth)
            - private_key: Private key in PEM format (for cert auth)
            - client_secret: Client secret (for secret auth)
            - credentials_prefix: Environment variable prefix (default: "FLUVIUS")

        Environment options:
            - environment: "sandbox" (default) or "production"

        Filter options:
            - reference_number: Filter by custom reference number
            - ean: Filter by GSRN EAN-code
            - data_service_types: Comma-separated list of data service types
            - energy_type: "E" (electricity) or "G" (gas)
            - status: Mandate status (Requested, Approved, Rejected, Finished)
            - mandate_expiration_date: Filter by expiration date (ISO format)
            - renewal_status: ToBeRenewed, RenewalRequested, or Expired
            - last_updated_from: Start of last updated filter (ISO format)
            - last_updated_to: End of last updated filter (ISO format)

    Example:
        ```python
        df = spark.read.format("fluvius.mandates") \\
            .option("status", "Approved") \\
            .option("energy_type", "E") \\
            .load()
        ```
    """

    @classmethod
    def name(cls) -> str:
        """Return the short name of this data source."""
        return "fluvius.mandates"

    def schema(self) -> StructType:
        """Return the schema for mandates data."""
        return MANDATES_SCHEMA

    def reader(self, schema: StructType) -> DataSourceReader:
        """Return a reader for mandates data.

        Args:
            schema: The schema to use (typically the default MANDATES_SCHEMA).

        Returns:
            A FluviusMandatesReader instance.
        """
        return FluviusMandatesReader(schema, self.options)
