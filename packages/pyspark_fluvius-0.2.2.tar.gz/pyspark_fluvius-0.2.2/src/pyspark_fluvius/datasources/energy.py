"""Fluvius Energy data source for PySpark."""

from __future__ import annotations

from typing import TYPE_CHECKING

from pyspark.sql.datasource import DataSource, DataSourceReader
from pyspark.sql.types import StructType

from ..readers.energy_reader import FluviusEnergyReader
from ..schemas.energy_schema import ENERGY_SCHEMA

if TYPE_CHECKING:
    pass


class FluviusEnergyDataSource(DataSource):
    """PySpark data source for reading Fluvius energy measurements.

    This data source allows you to read energy measurement data from the
    Fluvius Energy API directly into a Spark DataFrame.

    Required Options:
        - ean: GSRN EAN-code that identifies the installation
        - period_type: Type of period ("readTime" or "insertTime")

    Optional Options:
        Credential options (if not using environment variables):
            - subscription_key: Azure API Management subscription key
            - client_id: Azure AD application (client) ID
            - tenant_id: Azure AD tenant ID
            - scope: OAuth2 scope
            - data_access_contract_number: Data access contract number
            - certificate_thumbprint: Certificate thumbprint (for cert auth)
            - private_key: Private key in PEM format (for cert auth)
            - client_secret: Client secret (for secret auth)
            - credentials_prefix: Environment variable prefix (default: "FLUVIUS")

        Environment options:
            - environment: "sandbox" (default) or "production"

        Filter options:
            - reference_number: Custom reference number
            - granularity: Granularity filter (e.g., "daily", "hourly_quarterhourly")
            - complex_energy_types: Types of complex energy (e.g., "active,reactive")
            - from_date: Start date (ISO format, e.g., "2024-01-01")
            - to_date: End date (ISO format, e.g., "2024-01-31")

    Example:
        ```python
        df = spark.read.format("fluvius.energy") \\
            .option("ean", "541234567890123456") \\
            .option("period_type", "readTime") \\
            .option("granularity", "daily") \\
            .option("from_date", "2024-01-01") \\
            .option("to_date", "2024-01-31") \\
            .load()
        ```

    Schema (normalized, 20 columns — one row per measurement value):
        - ean: EAN code of the installation
        - energy_type: "E" (electricity) or "G" (gas)
        - metering_type: Type of metering installation
        - source: Where the measurement comes from ("headpoint", "meter", "sub_headpoint")
        - meter_id: Physical meter ID (if source is "meter")
        - seq_number: Meter or sub-headpoint sequence number
        - sub_headpoint_ean: Sub-headpoint EAN (if source is "sub_headpoint")
        - sub_headpoint_type: Type of sub-headpoint
        - sub_headpoint_seq_number: Sub-headpoint sequence number
        - vreg_id: VREG ID for production installations
        - production_installation_type: Type of production installation (e.g. "PV")
        - granularity: Measurement granularity ("daily", "hourly", "quarter_hourly")
        - start: Start time of the measurement period
        - end: End time of the measurement period
        - direction: Measurement direction ("offtake", "injection", "production", "auxiliary")
        - register_type: Register type ("total", "day", "night", "reactive", "inductive", "capacitive")
        - value: The measurement value
        - unit: Unit of measurement (e.g. "kWh", "m3", "kVArh")
        - validation_state: Validation state of the measurement
        - gas_conversion_factor: Gas conversion factor (gas only)
    """

    @classmethod
    def name(cls) -> str:
        """Return the short name of this data source."""
        return "fluvius.energy"

    def schema(self) -> StructType:
        """Return the schema for energy data."""
        return ENERGY_SCHEMA

    def reader(self, schema: StructType) -> DataSourceReader:
        """Return a reader for energy data.

        Args:
            schema: The schema to use (typically the default ENERGY_SCHEMA).

        Returns:
            A FluviusEnergyReader instance.
        """
        return FluviusEnergyReader(schema, self.options)
