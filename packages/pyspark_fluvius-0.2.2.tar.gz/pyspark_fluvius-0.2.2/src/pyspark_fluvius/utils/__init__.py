"""Utility functions for pyspark-fluvius."""

from .credentials import get_credentials

__all__ = ["get_credentials"]
