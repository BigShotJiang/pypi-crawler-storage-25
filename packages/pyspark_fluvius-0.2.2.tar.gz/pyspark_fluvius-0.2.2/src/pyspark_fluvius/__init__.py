"""PySpark custom data sources for Fluvius Energy API.

This package provides PySpark data sources for reading energy and mandate data
from the Fluvius Energy API directly into Spark DataFrames.

Example:
    ```python
    from pyspark.sql import SparkSession
    import pyspark_fluvius  # Registers data sources

    spark = SparkSession.builder.getOrCreate()

    # Read mandates
    mandates_df = spark.read.format("fluvius.mandates") \\
        .option("status", "Approved") \\
        .load()

    # Read energy data
    energy_df = spark.read.format("fluvius.energy") \\
        .option("ean", "541234567890123456") \\
        .option("period_type", "readTime") \\
        .option("granularity", "daily") \\
        .option("from_date", "2024-01-01") \\
        .option("to_date", "2024-01-31") \\
        .load()
    ```
"""

from __future__ import annotations

import os

# Avoid fork() DeprecationWarning from PySpark daemon on Python 3.13+
os.environ.setdefault("PYSPARK_PIN_THREAD", "true")
# The daemon runs from a zip file so module-targeted filters don't match;
# suppress all DeprecationWarning in child processes via PYTHONWARNINGS.
_pw = os.environ.get("PYTHONWARNINGS", "")
_fork_filter = "ignore::DeprecationWarning"
if _fork_filter not in _pw:
    os.environ["PYTHONWARNINGS"] = f"{_pw},{_fork_filter}" if _pw else _fork_filter

from .datasources import FluviusEnergyDataSource, FluviusMandatesDataSource
from .schemas import ENERGY_SCHEMA, MANDATES_SCHEMA

__version__ = "0.1.0"
__all__ = [
    "FluviusEnergyDataSource",
    "FluviusMandatesDataSource",
    "ENERGY_SCHEMA",
    "MANDATES_SCHEMA",
    "register_datasources",
]


def register_datasources() -> None:
    """Register Fluvius data sources with the active SparkSession.

    This function registers both fluvius.energy and fluvius.mandates data sources
    with the current SparkSession. Call this after creating your SparkSession.

    Example:
        ```python
        from pyspark.sql import SparkSession
        from pyspark_fluvius import register_datasources

        spark = SparkSession.builder.getOrCreate()
        register_datasources()

        df = spark.read.format("fluvius.mandates").load()
        ```
    """
    from pyspark.sql import SparkSession

    spark = SparkSession.getActiveSession()
    if spark is None:
        raise RuntimeError(
            "No active SparkSession found. "
            "Create a SparkSession before calling register_datasources()."
        )

    spark.dataSource.register(FluviusEnergyDataSource)
    spark.dataSource.register(FluviusMandatesDataSource)
