#!/usr/bin/env python3
"""Sandbox usage example for pyspark-fluvius.

This example demonstrates how to use the Fluvius data sources
to read energy and mandate data into Spark DataFrames using the sandbox environment.

Sandbox uses client secret authentication (simpler than certificate-based).

Required environment variables:
    # Common credentials
    export FLUVIUS_SUBSCRIPTION_KEY="your-subscription-key"
    export FLUVIUS_TENANT_ID="your-tenant-id"
    export FLUVIUS_SCOPE="api://your-scope/.default"
    export FLUVIUS_DATA_ACCESS_CONTRACT_NUMBER="your-contract-number"

    # Sandbox-specific (uses client_secret instead of certificate)
    export FLUVIUS_SANDBOX_CLIENT_ID="your-sandbox-client-id"
    export FLUVIUS_SANDBOX_CLIENT_SECRET="your-sandbox-client-secret"
"""

import os
import uuid

from pyspark.sql import SparkSession

from pyspark_fluvius import register_datasources

# Sandbox test EAN - must match pattern: 5414[4-5][0-1][0-2][0-2][0-2]000000[0-9][0-9][0-9]
TEST_EAN = "541450000000000001"


def get_sandbox_options() -> dict[str, str]:
    """Get Spark options for sandbox environment."""
    return {
        "subscription_key": os.environ["FLUVIUS_SUBSCRIPTION_KEY"],
        "client_id": os.environ["FLUVIUS_SANDBOX_CLIENT_ID"],
        "tenant_id": os.environ["FLUVIUS_TENANT_ID"],
        "scope": os.environ["FLUVIUS_SCOPE"],
        "data_access_contract_number": os.environ["FLUVIUS_DATA_ACCESS_CONTRACT_NUMBER"],
        "client_secret": os.environ["FLUVIUS_SANDBOX_CLIENT_SECRET"],
        "environment": "sandbox",
    }


def apply_options(reader, options: dict[str, str]):
    """Apply options to a DataFrameReader."""
    for key, value in options.items():
        reader = reader.option(key, value)
    return reader


def create_mock_mandate(reference: str) -> None:
    """Create a mock mandate in the sandbox for testing."""
    from fluvius_energy_api import FluviusCredentials, FluviusEnergyClient
    from fluvius_energy_api.client import Environment
    from fluvius_energy_api.models.enums import DataServiceType, MandateStatus

    credentials = FluviusCredentials(
        subscription_key=os.environ["FLUVIUS_SUBSCRIPTION_KEY"],
        client_id=os.environ["FLUVIUS_SANDBOX_CLIENT_ID"],
        tenant_id=os.environ["FLUVIUS_TENANT_ID"],
        scope=os.environ["FLUVIUS_SCOPE"],
        data_access_contract_number=os.environ["FLUVIUS_DATA_ACCESS_CONTRACT_NUMBER"],
        client_secret=os.environ["FLUVIUS_SANDBOX_CLIENT_SECRET"],
    )

    with FluviusEnergyClient(credentials=credentials, environment=Environment.SANDBOX) as client:
        client.create_mock_mandate(
            reference_number=reference,
            ean=TEST_EAN,
            data_service_type=DataServiceType.VH_DAG,
            data_period_from="2024-01-01T00:00:00Z",
            data_period_to="2026-12-31T23:59:59Z",
            status=MandateStatus.APPROVED,
        )
    print(f"Created mock mandate with reference: {reference}")


def main() -> None:
    """Run the sandbox example."""
    print("=" * 60)
    print("PySpark Fluvius - Sandbox Example")
    print("=" * 60)

    # Create a unique reference for our mock mandate
    reference = f"spark-example-{uuid.uuid4().hex[:8]}"

    # Create a mock mandate first (required for sandbox)
    print("\n1. Creating mock mandate...")
    create_mock_mandate(reference)

    # Create SparkSession
    spark = SparkSession.builder.appName("FluviusSandboxExample").master("local[*]").getOrCreate()
    spark.sparkContext.setLogLevel("WARN")

    # Register the Fluvius data sources
    register_datasources()

    options = get_sandbox_options()

    # Example 1: Read all mandates
    print("\n" + "=" * 60)
    print("2. Reading all mandates...")
    print("=" * 60)

    mandates_df = apply_options(spark.read.format("fluvius.mandates"), options).load()

    print(f"Found {mandates_df.count()} mandates")
    mandates_df.select(
        "reference_number",
        "ean",
        "status",
        "energy_type",
        "data_service_type",
    ).show(truncate=False)

    # Example 2: Read only approved mandates
    print("=" * 60)
    print("3. Reading approved mandates...")
    print("=" * 60)

    approved_df = apply_options(
        spark.read.format("fluvius.mandates"), {**options, "status": "Approved"}
    ).load()

    print(f"Found {approved_df.count()} approved mandates")
    approved_df.show(truncate=False)

    # Example 3: Read energy data for our test EAN
    print("=" * 60)
    print("4. Reading energy data...")
    print("=" * 60)

    energy_options = {
        **options,
        "ean": TEST_EAN,
        "reference_number": reference,
        "period_type": "readTime",
        "granularity": "daily",
        "from_date": "2024-01-01",
        "to_date": "2024-01-10",
    }

    energy_df = apply_options(spark.read.format("fluvius.energy"), energy_options).load()

    print(f"Found {energy_df.count()} energy measurements")

    energy_df.show(truncate=False)

    # Example 4: Show reactive energy (if available)
    print("=" * 60)
    print("5. Showing reactive energy measurements...")
    print("=" * 60)

    energy_df.filter(
        energy_df.register_type.isin("reactive", "inductive", "capacitive")
    ).select(
        "ean",
        "start",
        "direction",
        "register_type",
        "value",
        "unit",
    ).show(truncate=False)

    # Example 5: Analyze energy consumption
    print("=" * 60)
    print("6. Analyzing energy consumption...")
    print("=" * 60)

    if energy_df.count() > 0:
        from pyspark.sql.functions import avg, count, max, min, sum

        # Filter to offtake/day and aggregate
        offtake_day = energy_df.filter(
            (energy_df.direction == "offtake") & (energy_df.register_type == "day")
        )
        stats = offtake_day.agg(
            count("*").alias("measurements"),
            sum("value").alias("total_day_consumption"),
            avg("value").alias("avg_day_consumption"),
            min("value").alias("min_day_consumption"),
            max("value").alias("max_day_consumption"),
        )
        stats.show(truncate=False)

    print("=" * 60)
    print("Sandbox example complete!")
    print("=" * 60)

    spark.stop()


if __name__ == "__main__":
    main()
