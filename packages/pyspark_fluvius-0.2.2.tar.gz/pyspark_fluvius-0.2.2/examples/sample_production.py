#!/usr/bin/env python3
"""Production usage example for pyspark-fluvius.

This example demonstrates how to use the Fluvius data sources
to read energy and mandate data into Spark DataFrames using production credentials.

Production uses certificate-based authentication (more secure than client_secret).

Required environment variables:
    # Common credentials
    export FLUVIUS_SUBSCRIPTION_KEY="your-subscription-key"
    export FLUVIUS_CLIENT_ID="your-client-id"
    export FLUVIUS_TENANT_ID="your-tenant-id"
    export FLUVIUS_SCOPE="api://your-scope/.default"
    export FLUVIUS_DATA_ACCESS_CONTRACT_NUMBER="your-contract-number"

    # Production-specific (uses certificate instead of client_secret)
    export FLUVIUS_CERTIFICATE_THUMBPRINT="your-certificate-thumbprint"
    export FLUVIUS_PRIVATE_KEY_PATH="/path/to/your/private_key.pem"
    # OR
    export FLUVIUS_PRIVATE_KEY="-----BEGIN PRIVATE KEY-----\n..."
"""

import os

from pyspark.sql import SparkSession

from pyspark_fluvius import register_datasources


def get_production_options() -> dict[str, str]:
    """Get Spark options for production environment."""
    options = {
        "subscription_key": os.environ["FLUVIUS_SUBSCRIPTION_KEY"],
        "client_id": os.environ["FLUVIUS_CLIENT_ID"],
        "tenant_id": os.environ["FLUVIUS_TENANT_ID"],
        "scope": os.environ["FLUVIUS_SCOPE"],
        "data_access_contract_number": os.environ["FLUVIUS_DATA_ACCESS_CONTRACT_NUMBER"],
        "certificate_thumbprint": os.environ["FLUVIUS_CERTIFICATE_THUMBPRINT"],
        "environment": "production",
    }

    # Support both direct key and file path
    if "FLUVIUS_PRIVATE_KEY" in os.environ:
        options["private_key"] = os.environ["FLUVIUS_PRIVATE_KEY"]
    elif "FLUVIUS_PRIVATE_KEY_PATH" in os.environ:
        with open(os.environ["FLUVIUS_PRIVATE_KEY_PATH"]) as f:
            options["private_key"] = f.read()
    else:
        raise ValueError("Either FLUVIUS_PRIVATE_KEY or FLUVIUS_PRIVATE_KEY_PATH must be set")

    return options


def apply_options(reader, options: dict[str, str]):
    """Apply options to a DataFrameReader."""
    for key, value in options.items():
        reader = reader.option(key, value)
    return reader


def main() -> None:
    """Run the production example."""
    print("=" * 60)
    print("PySpark Fluvius - Production Example")
    print("=" * 60)

    # Create SparkSession
    spark = SparkSession.builder.appName("FluviusProductionExample").master("local[*]").getOrCreate()
    spark.sparkContext.setLogLevel("WARN")

    # Register the Fluvius data sources
    register_datasources()

    options = get_production_options()

    # Example 1: Read all mandates
    print("\n" + "=" * 60)
    print("1. Reading all mandates...")
    print("=" * 60)

    mandates_df = apply_options(spark.read.format("fluvius.mandates"), options).load()

    print(f"Found {mandates_df.count()} mandates")
    mandates_df.select(
        "reference_number",
        "ean",
        "status",
        "energy_type",
        "data_service_type",
    ).show(truncate=False)

    # Example 2: Read only approved mandates
    print("=" * 60)
    print("2. Reading approved mandates...")
    print("=" * 60)

    approved_df = apply_options(
        spark.read.format("fluvius.mandates"), {**options, "status": "Approved"}
    ).load()

    print(f"Found {approved_df.count()} approved mandates")
    approved_df.show(truncate=False)

    # Example 3: Read energy data for a specific EAN
    # Note: You need a valid EAN and reference_number from an approved mandate
    print("=" * 60)
    print("3. Reading energy data...")
    print("=" * 60)

    # Try mandates until we find one that returns energy data.
    # Prefer VH_kwartier_uur mandates (support quarter-hourly), then fall back to others.
    approved_mandates = approved_df.collect()
    sorted_mandates = sorted(
        approved_mandates,
        key=lambda m: m["data_service_type"] != "VH_kwartier_uur",
    )

    energy_df = None
    mandate = None
    for m in sorted_mandates:
        ean = m["ean"]
        reference = m["reference_number"]
        energy_options = {
            **options,
            "ean": ean,
            "reference_number": reference,
            "period_type": "readTime",
            "granularity": "daily",
            "from_date": "2024-01-01",
            "to_date": "2024-01-31",
        }
        try:
            df = apply_options(spark.read.format("fluvius.energy"), energy_options).load()
            if df.count() > 0:
                energy_df = df
                mandate = m
                break
        except Exception:
            continue

    if energy_df is None or mandate is None:
        print("No mandates returned energy data — skipping energy examples")
    else:
        ean = mandate["ean"]
        reference = mandate["reference_number"]
        data_service_type = mandate["data_service_type"]
        print(f"Using EAN: {ean}, Reference: {reference}, Type: {data_service_type}")

        print(f"Found {energy_df.count()} energy measurements")
        energy_df.show(truncate=False)

        # Example 4: Show injection values (if solar panels present)
        print("=" * 60)
        print("4. Showing injection measurements (solar/production)...")
        print("=" * 60)

        energy_df.filter(energy_df.direction == "injection").select(
            "ean",
            "start",
            "direction",
            "register_type",
            "value",
            "unit",
        ).show(truncate=False)

        # Example 5: Analyze energy consumption
        print("=" * 60)
        print("5. Analyzing energy consumption...")
        print("=" * 60)

        from pyspark.sql.functions import avg, count, max, min, sum

        energy_df.groupBy("direction", "register_type").agg(
            count("*").alias("measurements"),
            sum("value").alias("total"),
            avg("value").alias("avg"),
            min("value").alias("min"),
            max("value").alias("max"),
        ).orderBy("direction", "register_type").show(truncate=False)

        # Example 6: Quarter-hourly/hourly granularity (if mandate supports it)
        print("=" * 60)
        print("6. Reading quarter-hourly/hourly energy data...")
        print("=" * 60)

        if data_service_type in ("VH_kwartier_uur", "VH_onbepaald"):
            try:
                hourly_options = {
                    **options,
                    "ean": ean,
                    "reference_number": reference,
                    "period_type": "readTime",
                    "granularity": "hourly_quarterhourly",
                    "from_date": "2024-01-01",
                    "to_date": "2024-01-02",
                }

                hourly_df = apply_options(spark.read.format("fluvius.energy"), hourly_options).load()

                print(f"Found {hourly_df.count()} quarter-hourly/hourly measurements")
                hourly_df.show(10, truncate=False)
            except Exception as e:
                print(f"Quarter-hourly data not available: {e}")
        else:
            print(f"Mandate data_service_type is '{data_service_type}' - only supports daily granularity")
            print("To read quarter-hourly/hourly data, use a mandate with VH_kwartier_uur or VH_onbepaald")

    print("=" * 60)
    print("Production example complete!")
    print("=" * 60)

    spark.stop()


if __name__ == "__main__":
    main()
