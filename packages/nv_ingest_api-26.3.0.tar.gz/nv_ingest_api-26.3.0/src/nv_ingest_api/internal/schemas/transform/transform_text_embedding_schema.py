# SPDX-FileCopyrightText: Copyright (c) 2024, NVIDIA CORPORATION & AFFILIATES.
# All rights reserved.
# SPDX-License-Identifier: Apache-2.0


import logging

from pydantic import ConfigDict, BaseModel, Field, model_validator, field_validator

from typing import Optional

from nv_ingest_api.util.logging.configuration import LogLevel

logger = logging.getLogger(__name__)


class TextEmbeddingSchema(BaseModel):
    api_key: str = Field(default="", repr=False)
    batch_size: int = Field(default=4)
    embedding_model: str = Field(default="nvidia/llama-nemotron-embed-1b-v2")
    # When null/empty, callers may choose to run a local embedding backend instead of a remote endpoint.
    # Keep the historical default so existing configs continue to work unchanged.
    embedding_nim_endpoint: Optional[str] = Field(default="http://embedding:8000/v1")
    encoding_format: str = Field(default="float")
    httpx_log_level: LogLevel = Field(default=LogLevel.WARNING)
    input_type: str = Field(default="passage")
    raise_on_failure: bool = Field(default=False)
    truncate: str = Field(default="END")
    embed_text_elements: bool = Field(default=True)
    embed_structured_elements: bool = Field(default=True)
    embed_image_elements: bool = Field(default=True)
    embed_audio_elements: bool = Field(default=True)
    text_elements_modality: str = Field(default="text")
    image_elements_modality: str = Field(default="text")
    image_elements_aggregate_page_content: bool = Field(default=False)
    structured_elements_modality: str = Field(default="text")
    audio_elements_modality: str = Field(default="text")
    custom_content_field: Optional[str] = None
    result_target_field: Optional[str] = None
    dimensions: Optional[int] = None

    model_config = ConfigDict(extra="forbid")

    @field_validator("api_key", mode="before")
    @classmethod
    def _coerce_api_key_none(cls, v):
        return "" if v is None else v

    @field_validator("embedding_nim_endpoint", mode="before")
    @classmethod
    def _coerce_empty_endpoint_to_none(cls, v):
        if v is None:
            return None
        if isinstance(v, str) and not v.strip():
            return None
        return v

    @model_validator(mode="before")
    @classmethod
    def _coerce_none_to_empty(cls, values):
        """Convert api_key=None to empty string so validation passes when key is omitted."""
        if isinstance(values, dict) and values.get("api_key") is None:
            values["api_key"] = ""
        return values
