from ._native import add, gday_from_rust, goodbye_from_rust

__version__ = "0.2.0rc2"


def get_sdk_version() -> str:
    return __version__


__all__ = [
    "__version__",
    "add",
    "get_sdk_version",
    "gday_from_rust",
    "goodbye_from_rust",
]
