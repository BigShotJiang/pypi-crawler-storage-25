# Private Only Python SDK

Python package wrapping the repository's Rust core library with PyO3.

```python
from private_only_sdk import add, get_sdk_version, gday_from_rust, goodbye_from_rust

gday_from_rust("SDK")
goodbye_from_rust("SDK")
add(2, 3)
get_sdk_version()
```
