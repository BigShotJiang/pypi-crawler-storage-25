# Changelog

## [0.2.0](https://github.com/loomb-oai/test-private-only-repo/compare/rust-core-v0.1.0...rust-core-v0.2.0) (2026-05-19)


### Features

* add private-only release sample ([bc8e9ec](https://github.com/loomb-oai/test-private-only-repo/commit/bc8e9ecccc93f5580715dbca5482a0b5fdb4a7ec))
* wire crates.io publishing sample ([4749471](https://github.com/loomb-oai/test-private-only-repo/commit/474947115aecdb46989571e264864131b1f0af12))
* wire crates.io publishing sample ([51dd10e](https://github.com/loomb-oai/test-private-only-repo/commit/51dd10e9d272b9c4c0256045c27fb5ec98ff4059))
