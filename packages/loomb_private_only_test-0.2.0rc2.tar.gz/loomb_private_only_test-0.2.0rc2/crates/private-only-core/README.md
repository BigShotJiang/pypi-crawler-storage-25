# Private-Only Release Sample

This repository demonstrates the single-repo version of the SDK release flow:

- release planning and GitHub Releases happen in this private repo
- there is no public mirror repository
- the Python package wraps a small Rust library through PyO3
- the release workflow consumes `loomb-oai/sdk-release-action@main`
- publishing targets PyPI from this repository with Trusted Publishing
- publishing targets crates.io from this repository with Cargo and a
  `CARGO_REGISTRY_TOKEN` secret

Repository shape:

- `crates/private-only-core`
  - Rust business logic
- `packages/python-sdk`
  - PyO3 extension module and Python package
- `.github/workflows/release-bot.yml`
  - shared release entrypoint

Example Python use:

```python
from private_only_sdk import get_sdk_version, gday_from_rust, goodbye_from_rust

gday_from_rust("Codex")
goodbye_from_rust("Codex")
get_sdk_version()
```

Release shape:

- `.github/sdk-release.yml` declares `releases.github.target: source`
- scheduled jobs dispatch `publish-nightly` and `cut-rc`
- manual dispatch can run `publish-alpha`, `publish-nightly`, `cut-rc`, or
  `publish-prod`
- the release job creates the GitHub Release in this repo, then the PyPI publish
  job uploads the Python distributions
- the reusable action handles crates.io internally with Cargo's
  dry-run-then-publish flow, adding `--allow-dirty` because channel versions are
  stamped into the checked-out manifest during the publish job

Counter: 3
