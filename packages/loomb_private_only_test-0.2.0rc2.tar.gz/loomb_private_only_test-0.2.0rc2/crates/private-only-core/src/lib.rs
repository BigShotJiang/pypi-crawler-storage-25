pub fn gday_from_rust(name: Option<&str>) -> String {
    match name {
        Some(name) if !name.trim().is_empty() => format!("G'day, {name}, from Rust."),
        _ => "G'day from Rust.".to_string(),
    }
}

pub fn goodbye_from_rust(name: Option<&str>) -> String {
    match name {
        Some(name) if !name.trim().is_empty() => format!("Hooroo, {name}, from Rust."),
        _ => "Hooroo from Rust.".to_string(),
    }
}

pub fn add(left: i64, right: i64) -> i64 {
    left + right
}

#[cfg(test)]
mod tests {
    use super::{add, gday_from_rust, goodbye_from_rust};

    #[test]
    fn greets_named_callers() {
        assert_eq!(gday_from_rust(Some("SDK")), "G'day, SDK, from Rust.");
    }

    #[test]
    fn farewells_named_callers() {
        assert_eq!(goodbye_from_rust(Some("SDK")), "Hooroo, SDK, from Rust.");
    }

    #[test]
    fn adds_numbers() {
        assert_eq!(add(2, 3), 5);
    }
}
