use pyo3::prelude::*;

#[pyfunction(signature = (name=None))]
fn gday_from_rust(name: Option<&str>) -> String {
    private_only_core::gday_from_rust(name)
}

#[pyfunction(signature = (name=None))]
fn goodbye_from_rust(name: Option<&str>) -> String {
    private_only_core::goodbye_from_rust(name)
}

#[pyfunction]
fn add(left: i64, right: i64) -> i64 {
    private_only_core::add(left, right)
}

#[pymodule]
fn _native(module: &Bound<'_, PyModule>) -> PyResult<()> {
    module.add_function(wrap_pyfunction!(gday_from_rust, module)?)?;
    module.add_function(wrap_pyfunction!(goodbye_from_rust, module)?)?;
    module.add_function(wrap_pyfunction!(add, module)?)?;
    Ok(())
}
