# Changelog

## [0.2.0](https://github.com/loomb-oai/test-private-only-repo/compare/python-sdk-v0.1.0...python-sdk-v0.2.0) (2026-05-19)


### Features

* add private-only release sample ([bc8e9ec](https://github.com/loomb-oai/test-private-only-repo/commit/bc8e9ecccc93f5580715dbca5482a0b5fdb4a7ec))
