"""Byte-for-byte HMAC parity test against py_clob_client.

This test only runs if py_clob_client is installed. It verifies that
Horizon's HMAC signing produces IDENTICAL bytes to py_clob_client for
the same inputs across every endpoint Polymarket exposes.

If this test fails, it means Horizon would be rejected by the
Polymarket server with 401 Unauthorized — exactly the bug a tester
reported in v0.7.x.
"""
from __future__ import annotations

import base64
import hashlib
import hmac as pyhmac

import pytest

py_clob = pytest.importorskip("py_clob_client.signing.hmac")
build_hmac_signature = py_clob.build_hmac_signature


# Replicates Horizon's sign_hmac in src/exchanges/polymarket.rs
def _horizon_sign_hmac(timestamp: str, method: str, path: str, body: str, secret: str) -> str:
    # Strip query string before signing (matches auth_headers in Horizon)
    sign_path = path.split("?")[0] if "?" in path else path
    message = f"{timestamp}{method}{sign_path}{body}"

    # Try standard base64 first, then URL-safe (matches Horizon decode chain)
    try:
        secret_bytes = base64.b64decode(secret)
    except Exception:
        try:
            secret_bytes = base64.urlsafe_b64decode(secret)
        except Exception:
            secret_bytes = base64.urlsafe_b64decode(secret + "==")

    mac = pyhmac.new(secret_bytes, message.encode("utf-8"), hashlib.sha256)
    return base64.urlsafe_b64encode(mac.digest()).decode()


# Use a fixed timestamp so signatures are reproducible
TIMESTAMP = "1700000000"
SECRET = base64.urlsafe_b64encode(b"x" * 32).decode()


@pytest.mark.parametrize(
    "method,path,body,description",
    [
        ("POST", "/order", '{"order":{"salt":12345}}', "submit_order"),
        ("DELETE", "/order", '{"orderID":"abc123"}', "cancel_order"),
        ("DELETE", "/cancel-all", "", "cancel_all (empty body)"),
        ("GET", "/data/trades", "", "poll_fills"),
        ("GET", "/balance-allowance", "", "get_balance_allowance"),
        ("GET", "/order-scoring", "", "check_order_scoring"),
    ],
)
def test_hmac_matches_py_clob_client(method, path, body, description):
    """Horizon's HMAC bytes must match py_clob_client byte-for-byte."""
    pyclob_sig = build_hmac_signature(SECRET, TIMESTAMP, method, path, body or None)
    horizon_sig = _horizon_sign_hmac(TIMESTAMP, method, path, body, SECRET)
    assert pyclob_sig == horizon_sig, (
        f"{description}: signature mismatch\n"
        f"  py_clob_client: {pyclob_sig}\n"
        f"  horizon:        {horizon_sig}"
    )


def test_hmac_path_strips_query_string():
    """The HMAC must sign /balance-allowance, NOT /balance-allowance?asset_type=..."""
    sig_with_query = _horizon_sign_hmac(
        TIMESTAMP, "GET", "/balance-allowance?asset_type=COLLATERAL&signature_type=2",
        "", SECRET
    )
    sig_without_query = _horizon_sign_hmac(
        TIMESTAMP, "GET", "/balance-allowance", "", SECRET
    )
    # The Horizon helper above strips the query, so both should be equal
    assert sig_with_query == sig_without_query, (
        "Horizon must strip query string before signing — matches py_clob_client"
    )
    # And both should match what py_clob_client produces for the bare path
    expected = build_hmac_signature(SECRET, TIMESTAMP, "GET", "/balance-allowance", None)
    assert sig_without_query == expected
