"""Self-Impact Model — The Hive knows its own market footprint.

Calibrates market impact from own historical fills, gates orders where
impact exceeds alpha, and nets opposing agent orders internally to
achieve zero-impact crossing.
"""

from __future__ import annotations

import math
import threading
import time
from collections import defaultdict, deque
from dataclasses import dataclass
from typing import Any


@dataclass
class _FillRecord:
    """Record of a fill for impact calibration."""
    market_id: str
    side: str       # "buy" or "sell"
    size: float
    price: float
    decision_price: float  # Price when decision was made
    timestamp: float
    volume_24h: float = 0.0


@dataclass
class ImpactDecomposition:
    """Decomposed implementation shortfall."""
    spread_cost: float = 0.0
    temporary_impact: float = 0.0
    permanent_impact: float = 0.0
    timing_risk: float = 0.0
    total_shortfall: float = 0.0


@dataclass
class _PendingOrder:
    """Pending order for internal crossing."""
    agent_id: str
    market_id: str
    side: str
    size: float
    price: float
    timestamp: float


class SelfImpactModel:
    """The Hive's model of its own market footprint.

    1. Calibrates impact regression: IS = α + β·√(V/ADV) + γ·σ·T
    2. Gates orders where estimated impact > estimated alpha * margin
    3. Nets opposing agent orders internally (zero-impact crossing)
    """

    def __init__(self, impact_gate_margin: float = 0.5,
                 internal_crossing: bool = True):
        self._lock = threading.Lock()
        self._gate_margin = impact_gate_margin
        self._crossing_enabled = internal_crossing

        # Calibration data
        self._fills: deque[_FillRecord] = deque(maxlen=10_000)

        # Regression coefficients: IS = alpha + beta * sqrt(V/ADV) + gamma * sigma * T
        self._alpha = 0.0005   # Base spread cost (default 5 bps)
        self._beta = 0.10      # Participation impact
        self._gamma = 0.001    # Timing risk

        # Per-market ADV (average daily volume) estimates
        self._adv: dict[str, float] = defaultdict(lambda: 1_000_000.0)
        self._vol: dict[str, float] = defaultdict(lambda: 0.02)

        # Internal crossing queue
        self._pending_buys: dict[str, list[_PendingOrder]] = defaultdict(list)
        self._pending_sells: dict[str, list[_PendingOrder]] = defaultdict(list)

        # Stats
        self._orders_gated = 0
        self._orders_passed = 0
        self._internal_crosses = 0
        self._volume_crossed = 0.0

    # -----------------------------------------------------------------------
    # Fill Recording & Calibration
    # -----------------------------------------------------------------------

    def record_fill(self, market_id: str, side: str, size: float,
                    fill_price: float, decision_price: float,
                    volume_24h: float = 0.0) -> None:
        """Record a fill for impact model calibration."""
        rec = _FillRecord(
            market_id=market_id, side=side, size=size,
            price=fill_price, decision_price=decision_price,
            timestamp=time.time(), volume_24h=volume_24h,
        )
        with self._lock:
            self._fills.append(rec)
            if volume_24h > 0:
                self._adv[market_id] = volume_24h

    def calibrate(self, min_fills: int = 50) -> dict[str, float]:
        """Fit impact regression from own historical fills.

        Implementation Shortfall = Decision Price - Fill Price
        IS = alpha + beta * sqrt(V/ADV) + gamma * sigma * T

        Uses OLS regression on fill history.
        """
        with self._lock:
            fills = list(self._fills)

        if len(fills) < min_fills:
            return {"calibrated": False, "fills": len(fills),
                    "alpha": self._alpha, "beta": self._beta,
                    "gamma": self._gamma}

        # Compute features and targets
        xs: list[list[float]] = []  # [sqrt(V/ADV), sigma]
        ys: list[float] = []        # IS in bps

        for f in fills:
            adv = max(f.volume_24h, self._adv.get(f.market_id, 1_000_000.0))
            participation = math.sqrt(f.size / max(adv, 1.0))
            sigma = self._vol.get(f.market_id, 0.02)

            is_bps = abs(f.price - f.decision_price) / max(f.decision_price, 1e-8)
            xs.append([participation, sigma])
            ys.append(is_bps)

        # OLS: [alpha, beta, gamma] = (X'X)^-1 X'y
        n = len(xs)
        if n < 3:
            return {"calibrated": False}

        # Add intercept column
        X = [[1.0, x[0], x[1]] for x in xs]

        # X'X
        k = 3
        XtX = [[0.0] * k for _ in range(k)]
        Xty = [0.0] * k
        for i in range(n):
            for j in range(k):
                Xty[j] += X[i][j] * ys[i]
                for m in range(k):
                    XtX[j][m] += X[i][j] * X[i][m]

        # Solve via Cramer's rule for 3x3
        coeffs = self._solve_3x3(XtX, Xty)
        if coeffs is not None:
            with self._lock:
                self._alpha = max(0, coeffs[0])
                self._beta = max(0, coeffs[1])
                self._gamma = max(0, coeffs[2])

        return {
            "calibrated": True,
            "fills": n,
            "alpha": self._alpha,
            "beta": self._beta,
            "gamma": self._gamma,
        }

    @staticmethod
    def _solve_3x3(A: list[list[float]], b: list[float]) -> list[float] | None:
        """Solve 3x3 linear system via Cramer's rule."""
        def det3(m: list[list[float]]) -> float:
            return (m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1])
                    - m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0])
                    + m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0]))

        d = det3(A)
        if abs(d) < 1e-12:
            return None

        result = []
        for col in range(3):
            M = [row[:] for row in A]
            for row in range(3):
                M[row][col] = b[row]
            result.append(det3(M) / d)
        return result

    # -----------------------------------------------------------------------
    # Impact Estimation & Order Gating
    # -----------------------------------------------------------------------

    def predict_impact(self, market_id: str, size: float) -> float:
        """Predict implementation shortfall for a proposed order.

        Returns estimated cost as a fraction of notional.
        """
        adv = self._adv.get(market_id, 1_000_000.0)
        sigma = self._vol.get(market_id, 0.02)
        participation = math.sqrt(size / max(adv, 1.0))
        return self._alpha + self._beta * participation + self._gamma * sigma

    def gate_order(self, market_id: str, size: float,
                   estimated_alpha: float) -> tuple[bool, str]:
        """Gate order: reject if estimated impact > alpha * margin.

        Returns (allowed, reason).
        """
        impact = self.predict_impact(market_id, size)
        threshold = estimated_alpha * self._gate_margin

        if impact >= threshold:
            with self._lock:
                self._orders_gated += 1
            return False, (f"impact {impact:.4f} >= alpha*margin "
                           f"{threshold:.4f} (alpha={estimated_alpha:.4f})")
        else:
            with self._lock:
                self._orders_passed += 1
            return True, "ok"

    def update_market_data(self, market_id: str, adv: float = 0.0,
                           volatility: float = 0.0) -> None:
        """Update market ADV and volatility estimates."""
        with self._lock:
            if adv > 0:
                self._adv[market_id] = adv
            if volatility > 0:
                self._vol[market_id] = volatility

    # -----------------------------------------------------------------------
    # Internal Crossing
    # -----------------------------------------------------------------------

    def submit_for_crossing(self, agent_id: str, market_id: str,
                            side: str, size: float,
                            price: float) -> float:
        """Submit an order for potential internal crossing.

        Returns the RESIDUAL size that should be sent to the exchange.
        If fully crossed internally, returns 0.
        """
        if not self._crossing_enabled:
            return size

        with self._lock:
            pending = _PendingOrder(
                agent_id=agent_id, market_id=market_id,
                side=side, size=size, price=price,
                timestamp=time.time(),
            )

            if side == "buy":
                opposite = self._pending_sells.get(market_id, [])
            else:
                opposite = self._pending_buys.get(market_id, [])

            if not opposite:
                # No counterparty — queue this order
                if side == "buy":
                    self._pending_buys[market_id].append(pending)
                else:
                    self._pending_sells[market_id].append(pending)
                return size

            # Cross with the oldest opposite order
            match = opposite[0]
            cross_size = min(size, match.size)
            (price + match.price) / 2.0  # Mid-price crossing

            # Update matched order
            match.size -= cross_size
            if match.size <= 1e-10:
                opposite.pop(0)

            self._internal_crosses += 1
            self._volume_crossed += cross_size

            # Return residual
            residual = size - cross_size
            if residual > 1e-10:
                if side == "buy":
                    self._pending_buys[market_id].append(_PendingOrder(
                        agent_id=agent_id, market_id=market_id,
                        side=side, size=residual, price=price,
                        timestamp=time.time(),
                    ))
                else:
                    self._pending_sells[market_id].append(_PendingOrder(
                        agent_id=agent_id, market_id=market_id,
                        side=side, size=residual, price=price,
                        timestamp=time.time(),
                    ))

            return residual

    def flush_stale(self, max_age_seconds: float = 5.0) -> None:
        """Remove stale pending orders that weren't crossed."""
        now = time.time()
        with self._lock:
            for market_id in list(self._pending_buys.keys()):
                self._pending_buys[market_id] = [
                    p for p in self._pending_buys[market_id]
                    if now - p.timestamp < max_age_seconds
                ]
            for market_id in list(self._pending_sells.keys()):
                self._pending_sells[market_id] = [
                    p for p in self._pending_sells[market_id]
                    if now - p.timestamp < max_age_seconds
                ]

    # -----------------------------------------------------------------------
    # Impact Attribution
    # -----------------------------------------------------------------------

    def impact_attribution(self) -> dict[str, float]:
        """Decompose total realized impact across all fills."""
        with self._lock:
            fills = list(self._fills)

        if not fills:
            return {"total_shortfall": 0.0, "spread_cost": 0.0,
                    "temporary_impact": 0.0, "fills": 0}

        total_spread = 0.0
        total_impact = 0.0
        total_is = 0.0

        for f in fills:
            is_bps = abs(f.price - f.decision_price) / max(f.decision_price, 1e-8)
            total_is += is_bps
            total_spread += self._alpha  # Spread component
            total_impact += is_bps - self._alpha  # Impact component

        n = len(fills)
        return {
            "fills": n,
            "avg_shortfall_bps": round(total_is / n * 10000, 2),
            "avg_spread_bps": round(total_spread / n * 10000, 2),
            "avg_impact_bps": round(total_impact / n * 10000, 2),
            "internal_crosses": self._internal_crosses,
            "volume_crossed": round(self._volume_crossed, 2),
            "orders_gated": self._orders_gated,
            "orders_passed": self._orders_passed,
            "gate_rate": round(self._orders_gated /
                               max(1, self._orders_gated + self._orders_passed), 4),
        }

    def status(self) -> dict[str, Any]:
        """Current self-impact model status."""
        return {
            "coefficients": {
                "alpha": round(self._alpha, 6),
                "beta": round(self._beta, 6),
                "gamma": round(self._gamma, 6),
            },
            "fills_recorded": len(self._fills),
            "markets_tracked": len(self._adv),
            "internal_crossing_enabled": self._crossing_enabled,
            "gate_margin": self._gate_margin,
            **self.impact_attribution(),
        }
