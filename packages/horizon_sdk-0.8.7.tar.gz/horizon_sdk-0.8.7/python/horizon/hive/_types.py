"""The Hive — Types, enums, and configuration.

Enums and data types are compiled Rust (proprietary, opaque binary).
HiveConfig and orchestration-only types remain in Python.
"""

from __future__ import annotations

import time
import uuid
from dataclasses import dataclass, field
from typing import Any

# ---------------------------------------------------------------------------
# Compiled Rust types (proprietary — IP protected in binary)
# ---------------------------------------------------------------------------
from horizon._horizon import (  # noqa: F401
    AutonomyMode,
    AgentLifecycle,
    SpawnSource,
    PheromoneChannel,
    Severity,
    StrategyArchetype,
    DecisionType,
    HiveEventType,
    ChannelConfig,
    MarketPheromones,
    StrategyGenome,
    HiveAgent,
    CriticalityReport,
    ConsensusView,
    InternalMarket,
    ImprintAction,
    Incident,
    SwarmStatus,
    ExecutionSlice,
    ExecutionPlan,
    CausalEdge,
    CausalGraph,
)

# ---------------------------------------------------------------------------
# Python-only configuration (not IP-sensitive)
# ---------------------------------------------------------------------------

@dataclass
class HiveConfig:
    """Top-level Hive configuration."""
    # Server
    host: str = "0.0.0.0"
    port: int = 8780
    auth_token: str | None = None  # Required for remote connections

    # Swarm limits
    max_agents: int = 50
    total_capital: float = 100_000.0
    max_capital_per_agent_pct: float = 0.15
    max_drawdown_pct: float = 0.20

    # Evolution
    population_size: int = 100
    generations_per_cycle: int = 10
    island_count: int = 5
    migration_interval: int = 50
    migration_fraction: float = 0.05
    gp_max_depth: int = 8
    gp_tournament_size: int = 5
    gp_crossover_rate: float = 0.7
    gp_mutation_rate: float = 0.2

    # Pheromone
    pheromone_tick_interval: float = 1.0

    # Autonomy
    initial_mode: AutonomyMode = AutonomyMode.Observe
    graduation_cooldown_days: int = 7

    # Imprint
    imprint_enabled: bool = True
    imprint_min_actions: int = 100
    imprint_train_interval_hours: float = 24.0

    # Selection pressure
    fitness_gamma: float = 1.5
    diversity_tax_threshold: float = 0.7
    age_cull_days: int = 30
    min_sharpe_paper: float = 1.0
    min_sharpe_shadow: float = 1.2

    # Criticality
    criticality_check_interval: float = 60.0
    avalanche_reserve_pct: float = 0.15
    avalanche_deploy_threshold: float = 0.30

    # PBT
    pbt_interval_hours: float = 24.0
    pbt_exploit_fraction: float = 0.2
    pbt_explore_magnitude: float = 0.2

    # Dream state
    dream_enabled: bool = True
    dream_generations: int = 10_000

    # Consensus
    consensus_prediction_market_enabled: bool = True

    # Self-impact
    impact_gate_margin: float = 0.5
    internal_crossing_enabled: bool = True

    # Metamorphic execution
    metamorphic_enabled: bool = True
    metamorphic_size_jitter: float = 0.15
    metamorphic_aggression_skew: tuple[float, float] = (2.0, 5.0)

    # Persistence
    db_path: str = "hive.db"

    # LLM (for ReACT agent, used by existing swarm)
    api_key: str = ""
    api_base: str = "https://openrouter.ai/api/v1"
    hive_model: str = "anthropic/claude-sonnet-4-6"
    agent_model: str = "openai/gpt-5.4-mini"

    def __post_init__(self) -> None:
        """Coerce string values to enums for convenience."""
        if isinstance(self.initial_mode, str):
            try:
                self.initial_mode = AutonomyMode(self.initial_mode)
            except Exception:
                pass  # Rust enum may not support string coercion


# ---------------------------------------------------------------------------
# Python-only types (not IP-sensitive, kept for orchestration)
# ---------------------------------------------------------------------------

@dataclass
class DecayForecast:
    """Alpha decay prediction for a strategy."""
    agent_id: str
    half_life_days: float
    lambda_decay: float
    crowding_indicators: dict[str, float] = field(default_factory=dict)
    bocpd_change_prob: float = 0.0
    recommended_action: str = "monitor"  # monitor, reduce, rotate, kill
    confidence: float = 0.0
    timestamp: float = field(default_factory=time.time)


@dataclass
class HiveDecision:
    """Auditable Hive decision record (Python-only, uses Rust enums)."""
    decision_id: str = field(default_factory=lambda: uuid.uuid4().hex[:16])
    timestamp: float = field(default_factory=time.time)
    decision_type: str = "spawn_agent"
    action_taken: str = ""
    reasoning: str = ""
    confidence: float = 0.0
    regime: str = ""
    pheromone_snapshot: dict[str, Any] = field(default_factory=dict)
    knowledge_context: list[str] = field(default_factory=list)
    criticality_state: dict[str, float] = field(default_factory=dict)
    autonomy_mode: str = "observe"
    user_approved: bool | None = None
    outcome: str | None = None
    outcome_timestamp: float | None = None
    was_correct: bool | None = None

    def to_dict(self) -> dict[str, Any]:
        am = self.autonomy_mode
        dt = self.decision_type
        return {
            "decision_id": self.decision_id,
            "timestamp": self.timestamp,
            "decision_type": dt.value if hasattr(dt, "value") else str(dt),
            "action_taken": self.action_taken,
            "reasoning": self.reasoning,
            "confidence": self.confidence,
            "regime": self.regime,
            "autonomy_mode": am.value if hasattr(am, "value") else str(am),
            "user_approved": self.user_approved,
            "outcome": self.outcome,
            "was_correct": self.was_correct,
        }
