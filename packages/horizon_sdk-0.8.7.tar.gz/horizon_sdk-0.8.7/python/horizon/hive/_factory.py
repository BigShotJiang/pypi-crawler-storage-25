"""Agent Factory — Creates HiveAgents from 6 sources.

Evolution, templates, clones, user pipelines, imprint models, and
opportunistic spawning from KnowledgeGraph discoveries.
"""

from __future__ import annotations

import copy
import logging
import random
import threading
from typing import Any, TYPE_CHECKING

from horizon.hive._types import (
    HiveAgent, HiveConfig, StrategyGenome, SpawnSource,
    StrategyArchetype, AgentLifecycle,
)

if TYPE_CHECKING:
    from horizon.hive._map_elites import MAPElitesArchive
    from horizon.hive._imprint import ImprintSystem

logger = logging.getLogger("horizon.hive.factory")


# ---------------------------------------------------------------------------
# Template Definitions
# ---------------------------------------------------------------------------

TEMPLATE_CONFIGS: dict[StrategyArchetype, dict[str, Any]] = {
    StrategyArchetype.MOMENTUM: {
        "hyperparams": {
            "signal_threshold": 0.5, "position_size_mult": 1.0,
            "stop_loss_pct": 0.05, "take_profit_pct": 0.15,
            "rebalance_interval": 3600.0, "max_position_pct": 0.10,
            "decay_halflife": 7200.0, "regime_sensitivity": 1.0,
            "crowding_threshold": 0.6,
        },
        "holding_period": 3600.0 * 24,
        "directional_bias": 0.7,
        "volatility_pref": 0.3,
        "pipeline_config": {"strategy": "momentum", "signals": ["ema_cross", "hurst"]},
    },
    StrategyArchetype.MEAN_REVERSION: {
        "hyperparams": {
            "signal_threshold": 1.5, "position_size_mult": 0.8,
            "stop_loss_pct": 0.03, "take_profit_pct": 0.08,
            "rebalance_interval": 1800.0, "max_position_pct": 0.08,
            "decay_halflife": 3600.0, "regime_sensitivity": 1.2,
            "crowding_threshold": 0.5,
        },
        "holding_period": 3600.0 * 4,
        "directional_bias": -0.5,
        "volatility_pref": 0.4,
        "pipeline_config": {"strategy": "mean_reversion", "signals": ["zscore", "half_life"]},
    },
    StrategyArchetype.MARKET_MAKER: {
        "hyperparams": {
            "signal_threshold": 0.1, "position_size_mult": 1.5,
            "stop_loss_pct": 0.02, "take_profit_pct": 0.04,
            "rebalance_interval": 60.0, "max_position_pct": 0.15,
            "spread_mult": 2.0, "decay_halflife": 600.0,
            "regime_sensitivity": 0.5, "crowding_threshold": 0.7,
        },
        "holding_period": 300.0,
        "directional_bias": 0.0,
        "volatility_pref": 0.2,
        "pipeline_config": {"strategy": "market_maker", "signals": ["vpin", "lob_imbalance"]},
    },
    StrategyArchetype.ARBITRAGE: {
        "hyperparams": {
            "signal_threshold": 0.01, "position_size_mult": 2.0,
            "stop_loss_pct": 0.01, "take_profit_pct": 0.02,
            "rebalance_interval": 30.0, "max_position_pct": 0.20,
            "decay_halflife": 300.0, "crowding_threshold": 0.8,
        },
        "holding_period": 60.0,
        "directional_bias": 0.0,
        "volatility_pref": 0.1,
        "pipeline_config": {"strategy": "arbitrage", "signals": ["spread", "basis"]},
    },
    StrategyArchetype.VOLATILITY: {
        "hyperparams": {
            "signal_threshold": 0.3, "position_size_mult": 0.7,
            "stop_loss_pct": 0.08, "take_profit_pct": 0.20,
            "rebalance_interval": 7200.0, "max_position_pct": 0.08,
            "decay_halflife": 14400.0, "regime_sensitivity": 1.5,
        },
        "holding_period": 3600.0 * 48,
        "directional_bias": 0.0,
        "volatility_pref": 0.9,
        "pipeline_config": {"strategy": "volatility", "signals": ["iv_rv_spread", "vol_surface"]},
    },
    StrategyArchetype.EVENT_DRIVEN: {
        "hyperparams": {
            "signal_threshold": 0.7, "position_size_mult": 1.2,
            "stop_loss_pct": 0.04, "take_profit_pct": 0.12,
            "rebalance_interval": 3600.0, "max_position_pct": 0.10,
            "decay_halflife": 10800.0, "regime_sensitivity": 0.8,
        },
        "holding_period": 3600.0 * 12,
        "directional_bias": 0.3,
        "volatility_pref": 0.6,
        "pipeline_config": {"strategy": "event_driven", "signals": ["triple_barrier", "cusum"]},
    },
    StrategyArchetype.MACRO: {
        "hyperparams": {
            "signal_threshold": 0.4, "position_size_mult": 0.6,
            "stop_loss_pct": 0.10, "take_profit_pct": 0.30,
            "rebalance_interval": 86400.0, "max_position_pct": 0.12,
            "decay_halflife": 86400.0, "regime_sensitivity": 2.0,
        },
        "holding_period": 3600.0 * 24 * 7,
        "directional_bias": 0.5,
        "volatility_pref": 0.5,
        "pipeline_config": {"strategy": "macro", "signals": ["regime", "entropy_pool"]},
    },
    StrategyArchetype.COPY: {
        "hyperparams": {
            "signal_threshold": 0.0, "position_size_mult": 0.5,
            "stop_loss_pct": 0.05, "max_position_pct": 0.10,
        },
        "holding_period": 3600.0 * 24,
        "directional_bias": 0.0,
        "volatility_pref": 0.5,
        "pipeline_config": {"strategy": "copy", "signals": ["whale_follow"]},
    },
    StrategyArchetype.LIQUIDATION: {
        "hyperparams": {
            "signal_threshold": 0.0, "position_size_mult": 1.0,
            "stop_loss_pct": 0.0, "max_position_pct": 1.0,
        },
        "holding_period": 3600.0,
        "directional_bias": 0.0,
        "volatility_pref": 0.0,
        "pipeline_config": {"strategy": "liquidation", "signals": ["almgren_chriss"]},
    },
}


class AgentFactory:
    """Creates HiveAgents from 6 sources.

    1. evolution  — From GP/NEAT evolutionary engine output
    2. template   — From pre-built strategy archetype
    3. clone      — From successful agent (optionally mutated)
    4. user       — From user-supplied pipeline configuration
    5. imprint    — From user behavioral model
    6. opportunistic — Auto-spawned for KG discoveries
    """

    def __init__(self, config: HiveConfig):
        self._config = config
        self._lock = threading.Lock()
        self._agents_spawned = 0
        self._rng = random.Random()

    # -----------------------------------------------------------------------
    # Spawn Methods
    # -----------------------------------------------------------------------

    def spawn_from_evolution(self, genome: StrategyGenome,
                             markets: list[str] | None = None) -> HiveAgent:
        """Create agent from evolutionary engine output."""
        agent = self._create_base(genome)
        agent.genome.source = SpawnSource.EVOLUTION
        if markets:
            agent.markets = list(markets)
        agent.hyperparams = dict(genome.hyperparams)
        logger.info("Spawned evolution agent %s (gen %d, fitness %.4f)",
                     agent.agent_id, genome.generation, genome.fitness)
        return agent

    def spawn_from_template(self, archetype: StrategyArchetype,
                             markets: list[str],
                             capital: float = 0.0) -> HiveAgent:
        """Create agent from pre-built strategy template."""
        tmpl = TEMPLATE_CONFIGS.get(archetype, {})
        genome = StrategyGenome(
            source=SpawnSource.TEMPLATE,
            archetype=archetype,
            hyperparams=dict(tmpl.get("hyperparams", {})),
            holding_period=tmpl.get("holding_period", 3600.0),
            directional_bias=tmpl.get("directional_bias", 0.0),
            volatility_pref=tmpl.get("volatility_pref", 0.5),
            target_markets=list(markets),
            pipeline_config=dict(tmpl.get("pipeline_config", {})),
        )

        agent = self._create_base(genome)
        agent.markets = list(markets)
        agent.capital = capital
        agent.hyperparams = dict(genome.hyperparams)
        logger.info("Spawned template agent %s (%s) for %s",
                     agent.agent_id, archetype.value, markets)
        return agent

    def spawn_from_clone(self, parent: HiveAgent,
                          mutate: bool = True,
                          mutation_magnitude: float = 0.2) -> HiveAgent:
        """Clone a successful agent, optionally mutating parameters."""
        genome = StrategyGenome(
            source=SpawnSource.CLONE,
            archetype=parent.genome.archetype,
            generation=parent.genome.generation + 1,
            lineage=parent.genome.lineage + [parent.agent_id],
            hyperparams=dict(parent.hyperparams),
            holding_period=parent.genome.holding_period,
            directional_bias=parent.genome.directional_bias,
            volatility_pref=parent.genome.volatility_pref,
            asset_focus=parent.genome.asset_focus,
            target_markets=list(parent.markets),
            pipeline_config=dict(parent.genome.pipeline_config),
        )

        if mutate:
            for key, value in genome.hyperparams.items():
                if isinstance(value, (int, float)):
                    perturbation = self._rng.uniform(
                        1 - mutation_magnitude,
                        1 + mutation_magnitude,
                    )
                    genome.hyperparams[key] = value * perturbation

        agent = self._create_base(genome)
        agent.markets = list(parent.markets)
        agent.hyperparams = dict(genome.hyperparams)
        logger.info("Spawned clone agent %s from parent %s (mutate=%s)",
                     agent.agent_id, parent.agent_id, mutate)
        return agent

    def spawn_from_user(self, pipeline_config: dict[str, Any],
                         markets: list[str],
                         capital: float = 0.0) -> HiveAgent:
        """Create agent from user-supplied pipeline configuration."""
        genome = StrategyGenome(
            source=SpawnSource.USER,
            target_markets=list(markets),
            pipeline_config=dict(pipeline_config),
        )

        agent = self._create_base(genome)
        agent.markets = list(markets)
        agent.capital = capital
        logger.info("Spawned user agent %s for %s", agent.agent_id, markets)
        return agent

    def spawn_from_imprint(self, imprint: "ImprintSystem",
                            markets: list[str],
                            capital: float = 0.0) -> HiveAgent:
        """Create agent that mimics the user's trading style."""
        # Get user profile to configure genome
        profile = imprint.user_profile()
        prefs = profile.get("inferred_preferences", {})

        genome = StrategyGenome(
            source=SpawnSource.IMPRINT,
            hyperparams={
                "signal_threshold": max(0.1, prefs.get("opportunity_score", 0.5)),
                "position_size_mult": 1.0,
                "stop_loss_pct": 0.05,
                "take_profit_pct": 0.15,
                "regime_sensitivity": abs(prefs.get("regime_trending", 0.5)),
                "crowding_threshold": 0.6,
            },
            target_markets=list(markets),
            pipeline_config={"strategy": "imprint", "profile": profile},
        )

        agent = self._create_base(genome)
        agent.markets = list(markets)
        agent.capital = capital
        logger.info("Spawned imprint agent %s (mimics user style)", agent.agent_id)
        return agent

    def spawn_opportunistic(self, market_id: str, opportunity_confidence: float,
                             archive: "MAPElitesArchive | None" = None,
                             capital: float = 0.0) -> HiveAgent:
        """Auto-spawn agent for a KnowledgeGraph-discovered opportunity."""
        genome: StrategyGenome | None = None

        # Try MAP-Elites archive first
        if archive is not None:
            candidates = archive.get_all()
            # Pick genome that matches the market's asset class
            for g in sorted(candidates, key=lambda x: x.fitness, reverse=True):
                if market_id in g.target_markets or not g.target_markets:
                    genome = copy.deepcopy(g)
                    break

        if genome is None:
            # Fallback: use event-driven template
            genome = StrategyGenome(
                source=SpawnSource.OPPORTUNISTIC,
                archetype=StrategyArchetype.EVENT_DRIVEN,
                hyperparams=dict(TEMPLATE_CONFIGS[StrategyArchetype.EVENT_DRIVEN]["hyperparams"]),
                target_markets=[market_id],
            )
        else:
            genome.source = SpawnSource.OPPORTUNISTIC
            genome.target_markets = [market_id]

        agent = self._create_base(genome)
        agent.markets = [market_id]
        agent.capital = capital
        logger.info("Spawned opportunistic agent %s for %s (conf=%.2f)",
                     agent.agent_id, market_id, opportunity_confidence)
        return agent

    # -----------------------------------------------------------------------
    # Helpers
    # -----------------------------------------------------------------------

    def _create_base(self, genome: StrategyGenome) -> HiveAgent:
        """Create base agent with fresh ID and SPAWNED lifecycle."""
        with self._lock:
            self._agents_spawned += 1
        return HiveAgent(
            genome=genome,
            lifecycle=AgentLifecycle.SPAWNED,
        )

    @property
    def agents_spawned(self) -> int:
        return self._agents_spawned

    def available_templates(self) -> list[str]:
        """List available strategy archetypes."""
        return [a.value for a in StrategyArchetype]

    def template_config(self, archetype: str) -> dict[str, Any]:
        """Get configuration for a template archetype."""
        try:
            at = StrategyArchetype(archetype)
            return dict(TEMPLATE_CONFIGS.get(at, {}))
        except ValueError:
            return {}
