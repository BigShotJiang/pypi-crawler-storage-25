"""Swarm Coordinator — Fleet management, selection pressure, capital allocation.

The top-level manager of the agent fleet. Handles lifecycle, risk budgets,
fitness-based capital allocation, selection pressure, and diversity maintenance.
"""

from __future__ import annotations

import logging
import threading
import time
from typing import Any, TYPE_CHECKING

from horizon.hive._types import (
    HiveAgent, HiveConfig, AgentLifecycle, StrategyGenome,
    SwarmStatus, HiveDecision, DecisionType, AutonomyMode,
)

if TYPE_CHECKING:
    from horizon.hive._pheromone import PheromoneField
    from horizon.hive._reputation import ReputationSystem
    from horizon.hive._autonomy import AutonomyController
    from horizon.hive._factory import AgentFactory
    from horizon.hive._kill_chain import KillChain
    from horizon.hive._db import HiveDB

logger = logging.getLogger("horizon.hive.coordinator")


class SwarmCoordinator:
    """Manages the agent fleet lifecycle.

    Core loop (tick):
    1. Collect agent metrics
    2. Update pheromone field
    3. Run selection pressure (kill underperformers)
    4. Process nursery (promote ready agents)
    5. Check opportunity spawning
    6. Enforce risk budget
    7. Rebalance capital
    """

    def __init__(self, config: HiveConfig,
                 factory: "AgentFactory | None" = None,
                 pheromone: "PheromoneField | None" = None,
                 reputation: "ReputationSystem | None" = None,
                 autonomy: "AutonomyController | None" = None,
                 kill_chain: "KillChain | None" = None,
                 db: "HiveDB | None" = None):
        self._config = config
        self._factory = factory
        self._pheromone = pheromone
        self._reputation = reputation
        self._autonomy = autonomy
        self._kill_chain = kill_chain
        self._db = db
        self._lock = threading.Lock()

        # Fleet
        self._agents: dict[str, HiveAgent] = {}
        self._graveyard: list[StrategyGenome] = []
        self._nursery: list[HiveAgent] = []

        # Resource budgets
        self._total_capital = config.total_capital
        self._reserve_capital = config.total_capital * config.avalanche_reserve_pct
        self._allocatable_capital = self._total_capital - self._reserve_capital

        # Metrics
        self._tick_count = 0
        self._last_rebalance = 0.0

    # -----------------------------------------------------------------------
    # Agent Management
    # -----------------------------------------------------------------------

    def add_agent(self, agent: HiveAgent) -> None:
        """Add an agent to the swarm."""
        with self._lock:
            self._agents[agent.agent_id] = agent
        logger.info("Agent %s added to swarm (lifecycle=%s)",
                     agent.agent_id, agent.lifecycle.value)

    def remove_agent(self, agent_id: str, reason: str = "") -> HiveAgent | None:
        """Remove an agent from the swarm. Archive genome."""
        with self._lock:
            agent = self._agents.pop(agent_id, None)
        if agent is None:
            return None

        agent.lifecycle = AgentLifecycle.TERMINATED
        agent.promotion_history.append({
            "to": "terminated", "reason": reason,
            "timestamp": time.time(),
        })

        # Archive genome
        with self._lock:
            self._graveyard.append(agent.genome)
            if len(self._graveyard) > 1000:
                self._graveyard = self._graveyard[-500:]

        if self._db is not None:
            try:
                self._db.archive_genome(agent.genome)
            except Exception:
                pass

        logger.info("Agent %s terminated: %s", agent_id, reason)
        return agent

    def get_agent(self, agent_id: str) -> HiveAgent | None:
        return self._agents.get(agent_id)

    def all_agents(self) -> list[HiveAgent]:
        with self._lock:
            return list(self._agents.values())

    def active_agents(self) -> list[HiveAgent]:
        """Agents that are in PAPER, SHADOW, or LIVE lifecycle."""
        active_states = {AgentLifecycle.PAPER, AgentLifecycle.SHADOW, AgentLifecycle.LIVE}
        return [a for a in self._agents.values() if a.lifecycle in active_states]

    # -----------------------------------------------------------------------
    # Main Tick Loop
    # -----------------------------------------------------------------------

    def tick(self) -> dict[str, Any]:
        """Main oversight loop — called every cycle.

        Returns dict of actions taken.
        """
        self._tick_count += 1
        actions: dict[str, Any] = {"tick": self._tick_count, "actions": []}

        # 1. Collect metrics from all agents
        self._collect_agent_metrics()

        # 2. Update pheromone field
        if self._pheromone is not None:
            self._update_pheromone_field()

        # 3. Selection pressure — kill underperformers
        killed = self._run_selection_pressure()
        if killed:
            actions["actions"].append({"type": "killed", "agents": killed})

        # 4. Process nursery — promote ready agents
        promoted = self._process_nursery()
        if promoted:
            actions["actions"].append({"type": "promoted", "agents": promoted})

        # 5. Enforce risk budget
        self._enforce_risk_budget()

        # 6. Rebalance capital (every 60 ticks)
        if self._tick_count % 60 == 0:
            rebalanced = self._rebalance_capital()
            if rebalanced:
                actions["actions"].append({"type": "rebalanced", "count": len(rebalanced)})

        return actions

    # -----------------------------------------------------------------------
    # Tick Sub-Operations
    # -----------------------------------------------------------------------

    def _collect_agent_metrics(self) -> None:
        """Update agent fitness scores from performance data."""
        for agent in self._agents.values():
            # Composite fitness
            sharpe_component = agent.sharpe * 1.0
            dd_penalty = max(0, agent.max_drawdown - 0.15) * 5.0
            trade_bonus = min(agent.num_trades, 200) / 200 * 0.2

            # Diversity tax: penalize agents correlated with swarm
            diversity_tax = 0.0

            # Reputation weight
            rep_weight = 1.0
            if self._reputation is not None:
                score, _ = self._reputation.get(agent.agent_id)
                rep_weight = max(0.5, score * 2)

            agent.fitness = (sharpe_component - dd_penalty + trade_bonus
                             - diversity_tax) * rep_weight

    def _update_pheromone_field(self) -> None:
        """Have agents deposit pheromone based on their observations."""
        if self._pheromone is None:
            return

        # Build agent-market mapping for crowding
        agent_markets: dict[str, list[str]] = {
            a.agent_id: a.markets for a in self.active_agents()
        }

        # Compute average fitness for deposit weighting
        active = self.active_agents()
        avg_fitness = sum(a.fitness for a in active) / max(len(active), 1)

        # Each active agent deposits based on its state
        for agent in active:
            for market_id in agent.markets:
                if agent.pnl > 0:
                    from horizon.hive._types import PheromoneChannel
                    self._pheromone.deposit(
                        market_id, PheromoneChannel.OPPORTUNITY,
                        amount=min(1.0, agent.pnl / max(agent.capital, 1.0)),
                        agent_fitness=agent.fitness,
                        avg_fitness=avg_fitness,
                    )

        # Tick the pheromone field (evaporate, diffuse, update crowding)
        self._pheromone.tick(
            dt=self._config.pheromone_tick_interval,
            neighbors={},  # Populated by external KG integration
            agent_markets=agent_markets,
            max_per_market=max(1, self._config.max_agents // 5),
        )

    def _run_selection_pressure(self) -> list[str]:
        """Kill underperforming agents. Returns list of killed agent IDs."""
        killed: list[str] = []
        agents = self.active_agents()
        if len(agents) < 3:
            return killed

        for agent in agents:
            # Age-based culling
            if (agent.age_days() > self._config.age_cull_days and
                    agent.sharpe < self._config.min_sharpe_paper):
                result = self.remove_agent(
                    agent.agent_id,
                    f"age_cull: {agent.age_days():.0f}d, sharpe={agent.sharpe:.2f}",
                )
                if result:
                    killed.append(agent.agent_id)
                continue

            # Drawdown kill
            if agent.max_drawdown > self._config.max_drawdown_pct:
                result = self.remove_agent(
                    agent.agent_id,
                    f"drawdown_kill: dd={agent.max_drawdown:.2%}",
                )
                if result:
                    killed.append(agent.agent_id)

        return killed

    def _process_nursery(self) -> list[str]:
        """Promote agents through lifecycle stages. Returns promoted agent IDs."""
        promoted: list[str] = []

        for agent in list(self._agents.values()):
            if agent.lifecycle == AgentLifecycle.SPAWNED:
                # Auto-advance to INITIALIZING → PAPER
                agent.lifecycle = AgentLifecycle.PAPER
                agent.promotion_history.append({
                    "to": "paper", "timestamp": time.time(),
                })
                promoted.append(agent.agent_id)

            elif agent.lifecycle == AgentLifecycle.PAPER:
                # Check promotion criteria
                if (agent.age_days() >= 14 and
                        agent.num_trades >= 50 and
                        agent.sharpe >= self._config.min_sharpe_paper):
                    agent.lifecycle = AgentLifecycle.SHADOW
                    agent.promotion_history.append({
                        "to": "shadow", "timestamp": time.time(),
                        "sharpe": agent.sharpe, "trades": agent.num_trades,
                    })
                    promoted.append(agent.agent_id)

            elif agent.lifecycle == AgentLifecycle.SHADOW:
                if (agent.age_days() >= 21 and  # 14 paper + 7 shadow
                        agent.sharpe >= self._config.min_sharpe_shadow):
                    agent.lifecycle = AgentLifecycle.LIVE
                    agent.promotion_history.append({
                        "to": "live", "timestamp": time.time(),
                        "sharpe": agent.sharpe,
                    })
                    promoted.append(agent.agent_id)

        return promoted

    def _enforce_risk_budget(self) -> None:
        """Enforce aggregate risk limits across all agents."""
        total_notional = sum(a.capital for a in self.active_agents())
        if total_notional > self._allocatable_capital:
            # Scale down all agents proportionally
            scale = self._allocatable_capital / max(total_notional, 1.0)
            for agent in self.active_agents():
                agent.capital *= scale

    def _rebalance_capital(self) -> list[str]:
        """Reallocate capital using fitness-weighted scheme.

        capital_i = allocatable * (fitness_i^gamma / sum(fitness_j^gamma))
        """
        agents = self.active_agents()
        if not agents:
            return []

        gamma = self._config.fitness_gamma

        # Shift fitness to positive (min 0.01)
        fitnesses = [max(0.01, a.fitness) for a in agents]
        powered = [f ** gamma for f in fitnesses]
        total_powered = sum(powered)

        rebalanced: list[str] = []
        max_per_agent = self._allocatable_capital * self._config.max_capital_per_agent_pct

        for agent, p in zip(agents, powered):
            target = self._allocatable_capital * (p / total_powered)
            target = min(target, max_per_agent)

            if abs(target - agent.capital) > agent.capital * 0.05:
                agent.capital = target
                rebalanced.append(agent.agent_id)

        self._last_rebalance = time.time()
        return rebalanced

    # -----------------------------------------------------------------------
    # Agent Operations
    # -----------------------------------------------------------------------

    def kill_agent(self, agent_id: str, reason: str) -> bool:
        """Terminate an agent."""
        agent = self.remove_agent(agent_id, reason)
        if agent is None:
            return False

        # Record decision
        if self._db is not None:
            decision = HiveDecision(
                decision_type=DecisionType.KILL_AGENT,
                action_taken=f"Killed agent {agent_id}",
                reasoning=reason,
                confidence=1.0,
                autonomy_mode=self._autonomy.mode if self._autonomy else AutonomyMode.OBSERVE,
            )
            try:
                self._db.record_decision(decision)
            except Exception:
                pass

        return True

    def pause_agent(self, agent_id: str, reason: str = "") -> bool:
        """Temporarily suspend an agent."""
        agent = self._agents.get(agent_id)
        if agent is None:
            return False
        agent.lifecycle = AgentLifecycle.PAUSED
        agent.promotion_history.append({
            "to": "paused", "reason": reason, "timestamp": time.time(),
        })
        return True

    def resume_agent(self, agent_id: str) -> bool:
        """Resume a paused agent."""
        agent = self._agents.get(agent_id)
        if agent is None or agent.lifecycle != AgentLifecycle.PAUSED:
            return False
        # Restore to previous lifecycle (from promotion history)
        prev = "paper"
        for entry in reversed(agent.promotion_history):
            if entry.get("to") not in ("paused", "terminated"):
                prev = entry["to"]
                break
        agent.lifecycle = AgentLifecycle(prev)
        agent.promotion_history.append({
            "to": prev, "timestamp": time.time(),
        })
        return True

    def scale_agent(self, agent_id: str, new_capital: float) -> bool:
        """Adjust an agent's capital allocation."""
        agent = self._agents.get(agent_id)
        if agent is None:
            return False
        max_cap = self._allocatable_capital * self._config.max_capital_per_agent_pct
        agent.capital = min(new_capital, max_cap)
        return True

    # -----------------------------------------------------------------------
    # Reserve Management
    # -----------------------------------------------------------------------

    def deploy_reserves(self, amount: float) -> float:
        """Deploy avalanche reserves. Returns actual amount deployed."""
        deployed = min(amount, self._reserve_capital)
        self._reserve_capital -= deployed
        self._allocatable_capital += deployed
        logger.info("Deployed %.2f from avalanche reserves (remaining: %.2f)",
                     deployed, self._reserve_capital)
        return deployed

    def replenish_reserves(self, amount: float) -> None:
        """Replenish avalanche reserves from profits."""
        target = self._total_capital * self._config.avalanche_reserve_pct
        needed = target - self._reserve_capital
        replenish = min(amount, max(0, needed))
        self._reserve_capital += replenish
        self._allocatable_capital -= replenish

    # -----------------------------------------------------------------------
    # Status
    # -----------------------------------------------------------------------

    def swarm_status(self) -> SwarmStatus:
        """Aggregate swarm status snapshot."""
        agents = list(self._agents.values())
        active = [a for a in agents if a.lifecycle in
                  {AgentLifecycle.PAPER, AgentLifecycle.SHADOW, AgentLifecycle.LIVE}]

        total_pnl = sum(a.pnl for a in active)
        sharpes = [a.sharpe for a in active if a.sharpe != 0]
        avg_sharpe = sum(sharpes) / max(len(sharpes), 1)
        max_dd = max((a.max_drawdown for a in active), default=0.0)

        return SwarmStatus(
            total_agents=len(agents),
            active_agents=len(active),
            paper_agents=sum(1 for a in agents if a.lifecycle == AgentLifecycle.PAPER),
            shadow_agents=sum(1 for a in agents if a.lifecycle == AgentLifecycle.SHADOW),
            live_agents=sum(1 for a in agents if a.lifecycle == AgentLifecycle.LIVE),
            total_capital=self._total_capital,
            allocated_capital=sum(a.capital for a in active),
            reserve_capital=self._reserve_capital,
            total_pnl=total_pnl,
            aggregate_sharpe=avg_sharpe,
            aggregate_drawdown=max_dd,
            autonomy_mode=self._autonomy.mode if self._autonomy else AutonomyMode.OBSERVE,
        )

    def agent_ranking(self) -> list[dict[str, Any]]:
        """Agents ranked by fitness."""
        agents = sorted(self.active_agents(), key=lambda a: a.fitness, reverse=True)
        return [a.to_dict() for a in agents]

    @property
    def agent_count(self) -> int:
        return len(self._agents)

    @property
    def can_spawn(self) -> bool:
        return len(self._agents) < self._config.max_agents
