"""Kill Chain — Automated incident response when things go wrong.

When circuit breakers trip, the Hive doesn't just halt — it runs
automated forensics: contain, preserve, diagnose, remediate, report, learn.
"""

from __future__ import annotations

import logging
import threading
import time
from collections import deque
from typing import Any, Callable, TYPE_CHECKING

from horizon.hive._types import HiveConfig, Incident, Severity

if TYPE_CHECKING:
    from horizon.hive._db import HiveDB

logger = logging.getLogger("horizon.hive.kill_chain")


SEVERITY_DESCRIPTIONS = {
    Severity.SEV1_CRITICAL: "Fund-level kill switch. All agents halted. Forensics immediate.",
    Severity.SEV2_HIGH: "Cluster-level halt. Affected agents paused. Root cause analysis.",
    Severity.SEV3_MEDIUM: "Agent-level pause. Investigation queued.",
    Severity.SEV4_LOW: "Warning logged. Monitoring escalated.",
}


class KillChain:
    """Automated incident response chain.

    Response flow:
    1. CONTAIN:  Halt affected agents, cancel pending orders
    2. PRESERVE: Snapshot all state (positions, pheromones, KG, events)
    3. DIAGNOSE: Investigate root cause (timeline, causal chain)
    4. REMEDIATE: Kill offending agent, reclaim capital, blacklist genome
    5. REPORT:   Generate incident report for audit trail
    6. LEARN:    Feed failure into evolutionary engine (future immunity)
    """

    def __init__(self, config: HiveConfig, db: "HiveDB | None" = None):
        self._config = config
        self._db = db
        self._lock = threading.Lock()

        # Active incidents
        self._incidents: dict[str, Incident] = {}
        self._incident_history: deque[Incident] = deque(maxlen=500)

        # Callbacks for each response phase
        self._contain_fn: Callable[[Incident], None] | None = None
        self._preserve_fn: Callable[[Incident], dict] | None = None
        self._diagnose_fn: Callable[[Incident], str] | None = None
        self._remediate_fn: Callable[[Incident], None] | None = None
        self._learn_fn: Callable[[Incident], None] | None = None

        # Blacklisted genomes (failed strategies)
        self._blacklisted_genomes: set[str] = set()

    # -----------------------------------------------------------------------
    # Callback Registration
    # -----------------------------------------------------------------------

    def on_contain(self, fn: Callable[[Incident], None]) -> None:
        self._contain_fn = fn

    def on_preserve(self, fn: Callable[[Incident], dict]) -> None:
        self._preserve_fn = fn

    def on_diagnose(self, fn: Callable[[Incident], str]) -> None:
        self._diagnose_fn = fn

    def on_remediate(self, fn: Callable[[Incident], None]) -> None:
        self._remediate_fn = fn

    def on_learn(self, fn: Callable[[Incident], None]) -> None:
        self._learn_fn = fn

    # -----------------------------------------------------------------------
    # Incident Detection & Response
    # -----------------------------------------------------------------------

    def trigger(self, severity: Severity, trigger: str,
                affected_agents: list[str] | None = None,
                pnl_impact: float = 0.0) -> Incident:
        """Trigger the kill chain for a detected incident."""
        incident = Incident(
            severity=severity,
            trigger=trigger,
            affected_agents=affected_agents or [],
            pnl_impact=pnl_impact,
        )
        incident.timeline.append({
            "phase": "detected",
            "timestamp": time.time(),
            "detail": f"Incident detected: {trigger}",
        })

        with self._lock:
            self._incidents[incident.incident_id] = incident

        logger.warning(
            "INCIDENT %s [SEV%d]: %s | agents=%s | pnl_impact=%.4f",
            incident.incident_id, severity.value, trigger,
            affected_agents, pnl_impact,
        )

        # Execute response chain
        self._execute_response(incident)

        return incident

    def _execute_response(self, incident: Incident) -> None:
        """Execute the full response chain."""
        # 1. CONTAIN
        self._phase_contain(incident)

        # 2. PRESERVE
        self._phase_preserve(incident)

        # 3. DIAGNOSE
        self._phase_diagnose(incident)

        # 4. REMEDIATE (only for SEV1/SEV2)
        if incident.severity <= Severity.SEV2_HIGH:
            self._phase_remediate(incident)

        # 5. REPORT
        self._phase_report(incident)

        # 6. LEARN
        self._phase_learn(incident)

    def _phase_contain(self, incident: Incident) -> None:
        """Phase 1: Contain the damage."""
        incident.state = "contained"
        incident.timeline.append({
            "phase": "contain",
            "timestamp": time.time(),
            "detail": f"Halting {len(incident.affected_agents)} agents",
        })

        if self._contain_fn is not None:
            try:
                self._contain_fn(incident)
            except Exception as e:
                logger.error("Contain phase failed: %s", e)
                incident.timeline.append({
                    "phase": "contain",
                    "timestamp": time.time(),
                    "detail": f"ERROR: {e}",
                })

    def _phase_preserve(self, incident: Incident) -> None:
        """Phase 2: Snapshot all state for forensics."""
        incident.timeline.append({
            "phase": "preserve",
            "timestamp": time.time(),
            "detail": "State snapshot captured",
        })

        if self._preserve_fn is not None:
            try:
                snapshot = self._preserve_fn(incident)
                incident.timeline.append({
                    "phase": "preserve",
                    "timestamp": time.time(),
                    "detail": f"Snapshot keys: {list(snapshot.keys())}",
                })
            except Exception as e:
                logger.error("Preserve phase failed: %s", e)

    def _phase_diagnose(self, incident: Incident) -> None:
        """Phase 3: Root cause analysis."""
        incident.state = "diagnosed"

        if self._diagnose_fn is not None:
            try:
                root_cause = self._diagnose_fn(incident)
                incident.root_cause = root_cause
                incident.timeline.append({
                    "phase": "diagnose",
                    "timestamp": time.time(),
                    "detail": f"Root cause: {root_cause}",
                })
            except Exception as e:
                logger.error("Diagnose phase failed: %s", e)
                incident.root_cause = f"diagnosis_failed: {e}"
        else:
            incident.root_cause = "automated_diagnosis_unavailable"

        incident.timeline.append({
            "phase": "diagnose",
            "timestamp": time.time(),
            "detail": f"Root cause: {incident.root_cause}",
        })

    def _phase_remediate(self, incident: Incident) -> None:
        """Phase 4: Fix the problem."""
        incident.state = "remediated"
        incident.timeline.append({
            "phase": "remediate",
            "timestamp": time.time(),
            "detail": "Executing remediation",
        })

        if self._remediate_fn is not None:
            try:
                self._remediate_fn(incident)
            except Exception as e:
                logger.error("Remediate phase failed: %s", e)

    def _phase_report(self, incident: Incident) -> None:
        """Phase 5: Generate incident report."""
        incident.state = "resolved"
        incident.resolved_at = time.time()
        incident.timeline.append({
            "phase": "report",
            "timestamp": time.time(),
            "detail": "Incident report generated",
        })

        # Persist to DB
        if self._db is not None:
            try:
                self._db.record_incident(incident)
            except Exception:
                pass

        # Move to history
        with self._lock:
            self._incident_history.append(incident)
            self._incidents.pop(incident.incident_id, None)

    def _phase_learn(self, incident: Incident) -> None:
        """Phase 6: Feed failure into evolutionary engine for immunity."""
        incident.timeline.append({
            "phase": "learn",
            "timestamp": time.time(),
            "detail": "Failure scenario recorded for evolution",
        })

        if self._learn_fn is not None:
            try:
                self._learn_fn(incident)
            except Exception as e:
                logger.error("Learn phase failed: %s", e)

    # -----------------------------------------------------------------------
    # Genome Blacklisting
    # -----------------------------------------------------------------------

    def blacklist_genome(self, genome_id: str) -> None:
        """Blacklist a genome so it can never be deployed again."""
        with self._lock:
            self._blacklisted_genomes.add(genome_id)
        logger.info("Genome blacklisted: %s", genome_id)

    def is_blacklisted(self, genome_id: str) -> bool:
        return genome_id in self._blacklisted_genomes

    # -----------------------------------------------------------------------
    # Queries
    # -----------------------------------------------------------------------

    def active_incidents(self) -> list[Incident]:
        """Get all active (unresolved) incidents."""
        with self._lock:
            return list(self._incidents.values())

    def incident_history(self, severity: Severity | None = None,
                         limit: int = 50) -> list[Incident]:
        """Get resolved incidents, optionally filtered by severity."""
        with self._lock:
            history = list(self._incident_history)
        if severity is not None:
            history = [i for i in history if i.severity == severity]
        return history[-limit:]

    def get_incident(self, incident_id: str) -> Incident | None:
        """Get a specific incident (active or historical)."""
        with self._lock:
            if incident_id in self._incidents:
                return self._incidents[incident_id]
            for i in self._incident_history:
                if i.incident_id == incident_id:
                    return i
        return None

    def critical_count(self, days: int = 90) -> int:
        """Count critical incidents in the last N days."""
        cutoff = time.time() - days * 86400
        with self._lock:
            return sum(
                1 for i in self._incident_history
                if i.severity <= Severity.SEV2_HIGH and i.created_at >= cutoff
            )

    # -----------------------------------------------------------------------
    # Status
    # -----------------------------------------------------------------------

    def status(self) -> dict[str, Any]:
        """Current kill chain status."""
        with self._lock:
            active = list(self._incidents.values())
            total_history = len(self._incident_history)

        return {
            "active_incidents": len(active),
            "active_details": [
                {"id": i.incident_id, "severity": i.severity.value,
                 "trigger": i.trigger, "state": i.state}
                for i in active
            ],
            "total_resolved": total_history,
            "blacklisted_genomes": len(self._blacklisted_genomes),
            "critical_90d": self.critical_count(90),
            "callbacks_registered": {
                "contain": self._contain_fn is not None,
                "preserve": self._preserve_fn is not None,
                "diagnose": self._diagnose_fn is not None,
                "remediate": self._remediate_fn is not None,
                "learn": self._learn_fn is not None,
            },
        }
