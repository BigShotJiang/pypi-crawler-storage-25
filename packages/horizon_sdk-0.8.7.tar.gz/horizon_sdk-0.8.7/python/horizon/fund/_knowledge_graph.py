"""SQLite-based knowledge graph for market intelligence."""

from __future__ import annotations

import collections
import hashlib
import hmac as _hmac_mod
import json
import logging
import os
import sqlite3
import threading
import time

logger = logging.getLogger("horizon.fund.knowledge_graph")

ENTITY_TYPES = {"market", "event", "category", "exchange", "asset", "person", "organization"}
REL_TYPES = {"correlated_with", "caused_by", "part_of", "hedges", "competes_with", "related_to", "influences", "depends_on"}
FACT_TYPES = {"observation", "signal", "outcome", "correlation", "price_move", "settlement", "edge_detected", "regime_change"}


class KnowledgeGraph:
    """SQLite-based knowledge graph for market intelligence."""

    _HMAC_KEY = b"horizon_kg_v1"

    _SCHEMA = """
    CREATE TABLE IF NOT EXISTS entities (
        entity_id TEXT PRIMARY KEY,
        entity_type TEXT NOT NULL,
        name TEXT NOT NULL,
        properties_json TEXT DEFAULT '{}',
        created_at REAL NOT NULL,
        updated_at REAL NOT NULL,
        hmac TEXT NOT NULL DEFAULT ''
    );
    CREATE INDEX IF NOT EXISTS idx_entity_type ON entities(entity_type);
    CREATE INDEX IF NOT EXISTS idx_entity_name ON entities(name);

    CREATE TABLE IF NOT EXISTS relationships (
        rel_id INTEGER PRIMARY KEY AUTOINCREMENT,
        source_id TEXT NOT NULL,
        target_id TEXT NOT NULL,
        rel_type TEXT NOT NULL,
        weight REAL DEFAULT 1.0,
        properties_json TEXT DEFAULT '{}',
        valid_from REAL NOT NULL,
        valid_to REAL,
        created_at REAL NOT NULL,
        hmac TEXT NOT NULL DEFAULT '',
        FOREIGN KEY (source_id) REFERENCES entities(entity_id),
        FOREIGN KEY (target_id) REFERENCES entities(entity_id),
        UNIQUE(source_id, target_id, rel_type, valid_from)
    );
    CREATE INDEX IF NOT EXISTS idx_rel_source ON relationships(source_id);
    CREATE INDEX IF NOT EXISTS idx_rel_target ON relationships(target_id);
    CREATE INDEX IF NOT EXISTS idx_rel_type ON relationships(rel_type);
    CREATE INDEX IF NOT EXISTS idx_rel_valid ON relationships(valid_to);

    CREATE TABLE IF NOT EXISTS facts (
        fact_id INTEGER PRIMARY KEY AUTOINCREMENT,
        entity_id TEXT NOT NULL,
        fact_type TEXT NOT NULL,
        content TEXT NOT NULL,
        confidence REAL DEFAULT 0.5,
        source TEXT DEFAULT '',
        metadata_json TEXT DEFAULT '{}',
        timestamp REAL NOT NULL,
        expires_at REAL,
        hmac TEXT NOT NULL DEFAULT '',
        FOREIGN KEY (entity_id) REFERENCES entities(entity_id)
    );
    CREATE INDEX IF NOT EXISTS idx_fact_entity ON facts(entity_id);
    CREATE INDEX IF NOT EXISTS idx_fact_type ON facts(fact_type);
    CREATE INDEX IF NOT EXISTS idx_fact_ts ON facts(timestamp);
    CREATE INDEX IF NOT EXISTS idx_fact_source ON facts(source);
    """

    def __init__(self, db_path: str | None = None) -> None:
        self._db_path = db_path or os.path.join(
            os.path.expanduser("~"), ".horizon", "knowledge_graph.db"
        )
        db_dir = os.path.dirname(self._db_path)
        if db_dir:
            os.makedirs(db_dir, exist_ok=True)
        self._lock = threading.Lock()
        self._conn = sqlite3.connect(self._db_path, check_same_thread=False)
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA foreign_keys=ON")
        self._conn.executescript(self._SCHEMA)
        self._conn.commit()
        if db_dir:
            try:
                os.chmod(self._db_path, 0o600)
            except OSError:
                pass

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _compute_hmac(self, *parts: str) -> str:
        """HMAC-SHA256 for integrity."""
        msg = "|".join(parts)
        return _hmac_mod.new(self._HMAC_KEY, msg.encode(), hashlib.sha256).hexdigest()

    @staticmethod
    def _escape_like(pattern: str) -> str:
        """Escape special LIKE characters."""
        return pattern.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")

    def _entity_row_to_dict(self, row: tuple) -> dict:
        """Convert entity row to dict."""
        return {
            "entity_id": row[0],
            "entity_type": row[1],
            "name": row[2],
            "properties": json.loads(row[3]) if row[3] else {},
            "created_at": row[4],
            "updated_at": row[5],
        }

    def _rel_row_to_dict(self, row: tuple) -> dict:
        """Convert relationship row to dict."""
        return {
            "rel_id": row[0],
            "source_id": row[1],
            "target_id": row[2],
            "rel_type": row[3],
            "weight": row[4],
            "properties": json.loads(row[5]) if row[5] else {},
            "valid_from": row[6],
            "valid_to": row[7],
            "created_at": row[8],
        }

    def _fact_row_to_dict(self, row: tuple) -> dict:
        """Convert fact row to dict."""
        return {
            "fact_id": row[0],
            "entity_id": row[1],
            "fact_type": row[2],
            "content": row[3],
            "confidence": row[4],
            "source": row[5],
            "metadata": json.loads(row[6]) if row[6] else {},
            "timestamp": row[7],
            "expires_at": row[8],
        }

    # ------------------------------------------------------------------
    # Entity CRUD
    # ------------------------------------------------------------------

    def add_entity(self, entity_id: str, entity_type: str, name: str,
                   properties: dict | None = None) -> dict:
        """Add or update an entity. Returns entity dict."""
        if entity_type not in ENTITY_TYPES:
            raise ValueError(f"Invalid entity_type '{entity_type}', must be one of {sorted(ENTITY_TYPES)}")
        now = time.time()
        props_json = json.dumps(properties or {})
        hmac_val = self._compute_hmac(entity_id, entity_type, name)
        with self._lock:
            try:
                self._conn.execute(
                    """INSERT INTO entities
                       (entity_id, entity_type, name, properties_json, created_at, updated_at, hmac)
                       VALUES (?, ?, ?, ?, ?, ?, ?)
                       ON CONFLICT(entity_id) DO UPDATE SET
                           entity_type = excluded.entity_type,
                           name = excluded.name,
                           properties_json = excluded.properties_json,
                           updated_at = excluded.updated_at,
                           hmac = excluded.hmac""",
                    (entity_id, entity_type, name, props_json, now, now, hmac_val),
                )
                self._conn.commit()
            except Exception:
                logger.exception("Failed to add entity %s", entity_id)
                raise
        return {
            "entity_id": entity_id,
            "entity_type": entity_type,
            "name": name,
            "properties": properties or {},
            "created_at": now,
            "updated_at": now,
        }

    def get_entity(self, entity_id: str) -> dict | None:
        """Get entity by ID."""
        with self._lock:
            row = self._conn.execute(
                "SELECT entity_id, entity_type, name, properties_json, created_at, updated_at, hmac "
                "FROM entities WHERE entity_id = ?",
                (entity_id,),
            ).fetchone()
        if row is None:
            return None
        # Verify HMAC
        stored_hmac = row[6]
        if stored_hmac:
            expected = self._compute_hmac(row[0], row[1], row[2])
            if expected != stored_hmac:
                logger.warning("HMAC mismatch for entity %s - possible tampering", entity_id)
        return self._entity_row_to_dict(row)

    def find_entities(self, entity_type: str | None = None,
                      name_pattern: str | None = None,
                      limit: int = 100) -> list[dict]:
        """Search entities by type and/or name pattern (LIKE)."""
        limit = min(max(limit, 1), 10000)
        conditions: list[str] = []
        params: list[object] = []
        if entity_type is not None:
            conditions.append("entity_type = ?")
            params.append(entity_type)
        if name_pattern is not None:
            escaped = self._escape_like(name_pattern)
            conditions.append("name LIKE ? ESCAPE '\\'")
            params.append(f"%{escaped}%")
        where = (" WHERE " + " AND ".join(conditions)) if conditions else ""
        query = (
            "SELECT entity_id, entity_type, name, properties_json, created_at, updated_at, hmac "
            "FROM entities" + where + " ORDER BY updated_at DESC LIMIT ?"
        )
        params.append(limit)
        with self._lock:
            rows = self._conn.execute(query, params).fetchall()
        return [self._entity_row_to_dict(r) for r in rows]

    def remove_entity(self, entity_id: str) -> bool:
        """Remove entity and its relationships and facts."""
        with self._lock:
            try:
                row = self._conn.execute(
                    "SELECT 1 FROM entities WHERE entity_id = ?", (entity_id,)
                ).fetchone()
                if row is None:
                    return False
                self._conn.execute(
                    "DELETE FROM facts WHERE entity_id = ?", (entity_id,)
                )
                self._conn.execute(
                    "DELETE FROM relationships WHERE source_id = ? OR target_id = ?",
                    (entity_id, entity_id),
                )
                self._conn.execute(
                    "DELETE FROM entities WHERE entity_id = ?", (entity_id,)
                )
                self._conn.commit()
                return True
            except Exception:
                logger.exception("Failed to remove entity %s", entity_id)
                return False

    # ------------------------------------------------------------------
    # Relationship Management
    # ------------------------------------------------------------------

    def add_relationship(self, source_id: str, target_id: str, rel_type: str,
                         weight: float = 1.0, properties: dict | None = None,
                         valid_from: float | None = None,
                         valid_to: float | None = None) -> dict:
        """Add a directed relationship. Returns relationship dict."""
        if rel_type not in REL_TYPES:
            raise ValueError(f"Invalid rel_type '{rel_type}', must be one of {sorted(REL_TYPES)}")
        # Validate both entities exist
        with self._lock:
            src = self._conn.execute(
                "SELECT 1 FROM entities WHERE entity_id = ?", (source_id,)
            ).fetchone()
            tgt = self._conn.execute(
                "SELECT 1 FROM entities WHERE entity_id = ?", (target_id,)
            ).fetchone()
        if src is None:
            raise ValueError(f"Source entity '{source_id}' does not exist")
        if tgt is None:
            raise ValueError(f"Target entity '{target_id}' does not exist")

        now = time.time()
        vf = valid_from if valid_from is not None else now
        props_json = json.dumps(properties or {})
        hmac_val = self._compute_hmac(source_id, target_id, rel_type, f"{weight:.8f}")
        with self._lock:
            try:
                cursor = self._conn.execute(
                    """INSERT INTO relationships
                       (source_id, target_id, rel_type, weight, properties_json,
                        valid_from, valid_to, created_at, hmac)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (source_id, target_id, rel_type, weight, props_json,
                     vf, valid_to, now, hmac_val),
                )
                self._conn.commit()
                rel_id = cursor.lastrowid or 0
            except sqlite3.IntegrityError:
                logger.warning(
                    "Duplicate relationship %s->%s (%s) at valid_from=%.3f",
                    source_id, target_id, rel_type, vf,
                )
                raise
        return {
            "rel_id": rel_id,
            "source_id": source_id,
            "target_id": target_id,
            "rel_type": rel_type,
            "weight": weight,
            "properties": properties or {},
            "valid_from": vf,
            "valid_to": valid_to,
            "created_at": now,
        }

    def get_relationships(self, entity_id: str, direction: str = "both",
                          rel_type: str | None = None,
                          active_only: bool = True,
                          limit: int = 100) -> list[dict]:
        """Get relationships for an entity. direction: 'outgoing', 'incoming', 'both'."""
        limit = min(max(limit, 1), 10000)
        now = time.time()
        conditions: list[str] = []
        params: list[object] = []

        if direction == "outgoing":
            conditions.append("source_id = ?")
            params.append(entity_id)
        elif direction == "incoming":
            conditions.append("target_id = ?")
            params.append(entity_id)
        else:  # both
            conditions.append("(source_id = ? OR target_id = ?)")
            params.extend([entity_id, entity_id])

        if rel_type is not None:
            conditions.append("rel_type = ?")
            params.append(rel_type)

        if active_only:
            conditions.append("(valid_to IS NULL OR valid_to > ?)")
            params.append(now)

        where = " WHERE " + " AND ".join(conditions)
        query = (
            "SELECT rel_id, source_id, target_id, rel_type, weight, properties_json, "
            "valid_from, valid_to, created_at, hmac FROM relationships" + where +
            " ORDER BY weight DESC LIMIT ?"
        )
        params.append(limit)
        with self._lock:
            rows = self._conn.execute(query, params).fetchall()
        return [self._rel_row_to_dict(r) for r in rows]

    def expire_relationship(self, rel_id: int) -> bool:
        """Set valid_to = now on a relationship."""
        now = time.time()
        with self._lock:
            try:
                cursor = self._conn.execute(
                    "UPDATE relationships SET valid_to = ? WHERE rel_id = ? AND (valid_to IS NULL OR valid_to > ?)",
                    (now, rel_id, now),
                )
                self._conn.commit()
                return cursor.rowcount > 0
            except Exception:
                logger.exception("Failed to expire relationship %d", rel_id)
                return False

    # ------------------------------------------------------------------
    # Fact Management
    # ------------------------------------------------------------------

    def record_fact(self, entity_id: str, fact_type: str, content: str,
                    confidence: float = 0.5, source: str = "",
                    metadata: dict | None = None,
                    expires_at: float | None = None) -> dict:
        """Record a fact about an entity. Returns fact dict."""
        if fact_type not in FACT_TYPES:
            raise ValueError(f"Invalid fact_type '{fact_type}', must be one of {sorted(FACT_TYPES)}")
        # Validate entity exists
        with self._lock:
            row = self._conn.execute(
                "SELECT 1 FROM entities WHERE entity_id = ?", (entity_id,)
            ).fetchone()
        if row is None:
            raise ValueError(f"Entity '{entity_id}' does not exist")

        confidence = max(0.0, min(1.0, confidence))
        now = time.time()
        meta_json = json.dumps(metadata or {})
        hmac_val = self._compute_hmac(entity_id, fact_type, content, f"{confidence:.8f}")
        with self._lock:
            try:
                cursor = self._conn.execute(
                    """INSERT INTO facts
                       (entity_id, fact_type, content, confidence, source,
                        metadata_json, timestamp, expires_at, hmac)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (entity_id, fact_type, content, confidence, source,
                     meta_json, now, expires_at, hmac_val),
                )
                self._conn.commit()
                fact_id = cursor.lastrowid or 0
            except Exception:
                logger.exception("Failed to record fact for entity %s", entity_id)
                raise
        return {
            "fact_id": fact_id,
            "entity_id": entity_id,
            "fact_type": fact_type,
            "content": content,
            "confidence": confidence,
            "source": source,
            "metadata": metadata or {},
            "timestamp": now,
            "expires_at": expires_at,
        }

    def get_facts(self, entity_id: str | None = None,
                  fact_type: str | None = None,
                  source: str | None = None,
                  min_confidence: float = 0.0,
                  since: float | None = None,
                  active_only: bool = True,
                  limit: int = 100) -> list[dict]:
        """Query facts with filtering. active_only excludes expired facts."""
        limit = min(max(limit, 1), 10000)
        now = time.time()
        conditions: list[str] = []
        params: list[object] = []

        if entity_id is not None:
            conditions.append("entity_id = ?")
            params.append(entity_id)
        if fact_type is not None:
            conditions.append("fact_type = ?")
            params.append(fact_type)
        if source is not None:
            conditions.append("source = ?")
            params.append(source)
        if min_confidence > 0.0:
            conditions.append("confidence >= ?")
            params.append(min_confidence)
        if since is not None:
            conditions.append("timestamp >= ?")
            params.append(since)
        if active_only:
            conditions.append("(expires_at IS NULL OR expires_at > ?)")
            params.append(now)

        where = (" WHERE " + " AND ".join(conditions)) if conditions else ""
        query = (
            "SELECT fact_id, entity_id, fact_type, content, confidence, source, "
            "metadata_json, timestamp, expires_at, hmac FROM facts" + where +
            " ORDER BY timestamp DESC LIMIT ?"
        )
        params.append(limit)
        with self._lock:
            rows = self._conn.execute(query, params).fetchall()
        return [self._fact_row_to_dict(r) for r in rows]

    # ------------------------------------------------------------------
    # Graph Queries
    # ------------------------------------------------------------------

    def neighbors(self, entity_id: str, depth: int = 1,
                  rel_types: list[str] | None = None,
                  active_only: bool = True) -> dict:
        """BFS traversal up to depth. Returns {entity_id: {entity, relationships, depth}}."""
        depth = min(max(depth, 1), 3)
        time.time()
        visited: dict[str, dict] = {}
        queue: collections.deque[tuple[str, int]] = collections.deque()
        queue.append((entity_id, 0))

        while queue:
            current_id, current_depth = queue.popleft()
            if current_id in visited:
                continue

            entity = self.get_entity(current_id)
            if entity is None:
                continue

            rels = self.get_relationships(
                current_id, direction="both", active_only=active_only, limit=200
            )
            if rel_types is not None:
                rels = [r for r in rels if r["rel_type"] in rel_types]

            visited[current_id] = {
                "entity": entity,
                "relationships": rels,
                "depth": current_depth,
            }

            if current_depth < depth:
                for rel in rels:
                    neighbor_id = (
                        rel["target_id"] if rel["source_id"] == current_id
                        else rel["source_id"]
                    )
                    if neighbor_id not in visited:
                        queue.append((neighbor_id, current_depth + 1))

        return visited

    def find_path(self, source_id: str, target_id: str,
                  max_depth: int = 4) -> list[dict] | None:
        """Find shortest path between two entities. Returns list of relationship dicts or None."""
        max_depth = min(max(max_depth, 1), 5)
        if source_id == target_id:
            return []

        visited: set[str] = {source_id}
        # Each queue entry: (current_entity_id, path_of_relationships)
        queue: collections.deque[tuple[str, list[dict]]] = collections.deque()
        queue.append((source_id, []))

        while queue:
            current_id, path = queue.popleft()
            if len(path) >= max_depth:
                continue

            rels = self.get_relationships(
                current_id, direction="both", active_only=True, limit=200
            )

            for rel in rels:
                neighbor_id = (
                    rel["target_id"] if rel["source_id"] == current_id
                    else rel["source_id"]
                )
                if neighbor_id in visited:
                    continue

                new_path = path + [rel]
                if neighbor_id == target_id:
                    return new_path

                visited.add(neighbor_id)
                queue.append((neighbor_id, new_path))

        return None

    def correlated_markets(self, market_id: str,
                           min_weight: float = 0.5) -> list[dict]:
        """Find markets correlated with given market. Returns sorted by weight desc."""
        now = time.time()
        with self._lock:
            rows = self._conn.execute(
                """SELECT r.rel_id, r.source_id, r.target_id, r.rel_type, r.weight,
                          r.properties_json, r.valid_from, r.valid_to, r.created_at, r.hmac
                   FROM relationships r
                   WHERE r.rel_type = 'correlated_with'
                     AND r.weight >= ?
                     AND (r.valid_to IS NULL OR r.valid_to > ?)
                     AND (r.source_id = ? OR r.target_id = ?)
                   ORDER BY r.weight DESC
                   LIMIT 200""",
                (min_weight, now, market_id, market_id),
            ).fetchall()

        results = []
        for row in rows:
            rel = self._rel_row_to_dict(row)
            other_id = rel["target_id"] if rel["source_id"] == market_id else rel["source_id"]
            entity = self.get_entity(other_id)
            if entity is not None:
                results.append({
                    "entity": entity,
                    "relationship": rel,
                    "weight": rel["weight"],
                })
        results.sort(key=lambda x: x["weight"], reverse=True)
        return results

    def event_opportunities(self, event_entity_id: str) -> list[dict]:
        """Find market opportunities linked to an event entity."""
        now = time.time()
        with self._lock:
            rows = self._conn.execute(
                """SELECT r.rel_id, r.source_id, r.target_id, r.rel_type, r.weight,
                          r.properties_json, r.valid_from, r.valid_to, r.created_at, r.hmac
                   FROM relationships r
                   WHERE (r.source_id = ? OR r.target_id = ?)
                     AND r.rel_type IN ('part_of', 'related_to', 'influences')
                     AND (r.valid_to IS NULL OR r.valid_to > ?)
                   ORDER BY r.weight DESC
                   LIMIT 200""",
                (event_entity_id, event_entity_id, now),
            ).fetchall()

        results = []
        for row in rows:
            rel = self._rel_row_to_dict(row)
            other_id = (
                rel["target_id"] if rel["source_id"] == event_entity_id
                else rel["source_id"]
            )
            entity = self.get_entity(other_id)
            if entity is None or entity["entity_type"] != "market":
                continue
            facts = self.get_facts(entity_id=other_id, active_only=True, limit=10)
            results.append({
                "entity": entity,
                "relationship": rel,
                "recent_facts": facts,
            })
        return results

    # ------------------------------------------------------------------
    # Intelligence Extraction
    # ------------------------------------------------------------------

    def market_context(self, market_id: str) -> dict:
        """Build rich context for a market: entity, relationships, facts, correlated markets."""
        entity = self.get_entity(market_id)
        if entity is None:
            return {"error": f"Market entity '{market_id}' not found"}

        neighborhood = self.neighbors(market_id, depth=2)
        facts = self.get_facts(entity_id=market_id, active_only=True, limit=50)
        correlated = self.correlated_markets(market_id, min_weight=0.3)

        return {
            "entity": entity,
            "neighborhood": {
                eid: {"entity": v["entity"], "depth": v["depth"], "relationship_count": len(v["relationships"])}
                for eid, v in neighborhood.items()
            },
            "facts": facts,
            "correlated_markets": correlated,
            "neighbor_count": len(neighborhood) - 1,  # Exclude self
            "fact_count": len(facts),
        }

    def detect_cross_correlations(self, min_weight: float = 0.3) -> list[dict]:
        """Find all active cross-market correlation clusters."""
        now = time.time()
        with self._lock:
            rows = self._conn.execute(
                """SELECT rel_id, source_id, target_id, rel_type, weight,
                          properties_json, valid_from, valid_to, created_at, hmac
                   FROM relationships
                   WHERE rel_type = 'correlated_with'
                     AND weight >= ?
                     AND (valid_to IS NULL OR valid_to > ?)
                   ORDER BY weight DESC
                   LIMIT 10000""",
                (min_weight, now),
            ).fetchall()

        # Build adjacency for connected components
        adj: dict[str, set[str]] = {}
        edges: list[dict] = []
        for row in rows:
            rel = self._rel_row_to_dict(row)
            edges.append(rel)
            src, tgt = rel["source_id"], rel["target_id"]
            adj.setdefault(src, set()).add(tgt)
            adj.setdefault(tgt, set()).add(src)

        # Find connected components via BFS
        visited: set[str] = set()
        clusters: list[dict] = []

        for node in adj:
            if node in visited:
                continue
            component: list[str] = []
            bfs_queue: collections.deque[str] = collections.deque([node])
            while bfs_queue:
                current = bfs_queue.popleft()
                if current in visited:
                    continue
                visited.add(current)
                component.append(current)
                for neighbor in adj.get(current, set()):
                    if neighbor not in visited:
                        bfs_queue.append(neighbor)

            component_set = set(component)
            cluster_edges = [
                e for e in edges
                if e["source_id"] in component_set and e["target_id"] in component_set
            ]
            weights = [e["weight"] for e in cluster_edges]
            avg_weight = sum(weights) / len(weights) if weights else 0.0

            # Resolve entity names
            entities = []
            for eid in component:
                ent = self.get_entity(eid)
                if ent is not None:
                    entities.append(ent)

            clusters.append({
                "entity_ids": component,
                "entities": entities,
                "edges": cluster_edges,
                "size": len(component),
                "avg_weight": avg_weight,
            })

        clusters.sort(key=lambda c: c["size"], reverse=True)
        return clusters

    def surface_opportunities(self, fact_types: list[str] | None = None,
                              min_confidence: float = 0.6,
                              lookback_hours: float = 24.0) -> list[dict]:
        """Surface recent high-confidence facts as opportunities."""
        since = time.time() - (lookback_hours * 3600.0)
        now = time.time()

        conditions = [
            "f.confidence >= ?",
            "f.timestamp >= ?",
            "(f.expires_at IS NULL OR f.expires_at > ?)",
        ]
        params: list[object] = [min_confidence, since, now]

        if fact_types:
            placeholders = ", ".join("?" for _ in fact_types)
            conditions.append("f.fact_type IN (" + placeholders + ")")
            params.extend(fact_types)

        where = " WHERE " + " AND ".join(conditions)
        query = (
            "SELECT f.fact_id, f.entity_id, f.fact_type, f.content, f.confidence, "
            "f.source, f.metadata_json, f.timestamp, f.expires_at, f.hmac, "
            "e.entity_id, e.entity_type, e.name, e.properties_json, e.created_at, e.updated_at "
            "FROM facts f JOIN entities e ON f.entity_id = e.entity_id" + where +
            " ORDER BY f.confidence DESC, f.timestamp DESC LIMIT 500"
        )
        with self._lock:
            rows = self._conn.execute(query, params).fetchall()

        results = []
        for row in rows:
            fact = self._fact_row_to_dict(row[:10])
            entity = self._entity_row_to_dict(row[10:16])
            results.append({
                "fact": fact,
                "entity": entity,
            })
        return results

    # ------------------------------------------------------------------
    # Maintenance
    # ------------------------------------------------------------------

    def prune(self, max_age_days: float = 90.0,
              min_confidence: float = 0.1) -> int:
        """Remove expired facts and old low-confidence data. Returns count removed."""
        now = time.time()
        cutoff = now - (max_age_days * 86400.0)
        total_removed = 0
        with self._lock:
            try:
                # Remove expired facts
                cursor = self._conn.execute(
                    "DELETE FROM facts WHERE expires_at IS NOT NULL AND expires_at <= ?",
                    (now,),
                )
                total_removed += cursor.rowcount

                # Remove old low-confidence facts
                cursor = self._conn.execute(
                    "DELETE FROM facts WHERE timestamp < ? AND confidence < ?",
                    (cutoff, min_confidence),
                )
                total_removed += cursor.rowcount

                # Remove expired relationships
                cursor = self._conn.execute(
                    "DELETE FROM relationships WHERE valid_to IS NOT NULL AND valid_to <= ?",
                    (cutoff,),
                )
                total_removed += cursor.rowcount

                self._conn.commit()
            except Exception:
                logger.exception("Failed during prune")
                return 0
        logger.info("Pruned %d records (cutoff=%.0f days, min_conf=%.2f)", total_removed, max_age_days, min_confidence)
        return total_removed

    def stats(self) -> dict:
        """Return graph statistics: entity counts by type, relationship counts by type, fact counts."""
        with self._lock:
            entity_rows = self._conn.execute(
                "SELECT entity_type, COUNT(*) FROM entities GROUP BY entity_type"
            ).fetchall()
            rel_rows = self._conn.execute(
                "SELECT rel_type, COUNT(*) FROM relationships GROUP BY rel_type"
            ).fetchall()
            fact_rows = self._conn.execute(
                "SELECT fact_type, COUNT(*) FROM facts GROUP BY fact_type"
            ).fetchall()
            totals = self._conn.execute(
                "SELECT "
                "(SELECT COUNT(*) FROM entities), "
                "(SELECT COUNT(*) FROM relationships), "
                "(SELECT COUNT(*) FROM facts)"
            ).fetchone()

        return {
            "entities_by_type": {r[0]: r[1] for r in entity_rows},
            "relationships_by_type": {r[0]: r[1] for r in rel_rows},
            "facts_by_type": {r[0]: r[1] for r in fact_rows},
            "total_entities": totals[0] if totals else 0,
            "total_relationships": totals[1] if totals else 0,
            "total_facts": totals[2] if totals else 0,
        }

    def export_subgraph(self, entity_ids: list[str]) -> dict:
        """Export a subgraph around given entities as JSON-serializable dict."""
        set(entity_ids)
        entities = []
        for eid in entity_ids:
            entity = self.get_entity(eid)
            if entity is not None:
                entities.append(entity)

        # Get relationships between these entities
        if not entity_ids:
            return {"entities": [], "relationships": [], "facts": []}

        placeholders = ", ".join("?" for _ in entity_ids)
        with self._lock:
            rel_rows = self._conn.execute(
                "SELECT rel_id, source_id, target_id, rel_type, weight, properties_json, "
                "valid_from, valid_to, created_at, hmac FROM relationships "
                "WHERE source_id IN (" + placeholders + ") AND target_id IN (" + placeholders + ")",
                entity_ids + entity_ids,
            ).fetchall()
            fact_rows = self._conn.execute(
                "SELECT fact_id, entity_id, fact_type, content, confidence, source, "
                "metadata_json, timestamp, expires_at, hmac FROM facts "
                "WHERE entity_id IN (" + placeholders + ") ORDER BY timestamp DESC LIMIT 10000",
                entity_ids,
            ).fetchall()

        relationships = [self._rel_row_to_dict(r) for r in rel_rows]
        facts = [self._fact_row_to_dict(r) for r in fact_rows]

        return {
            "entities": entities,
            "relationships": relationships,
            "facts": facts,
        }

    def close(self) -> None:
        """Close DB connection."""
        with self._lock:
            self._conn.close()
