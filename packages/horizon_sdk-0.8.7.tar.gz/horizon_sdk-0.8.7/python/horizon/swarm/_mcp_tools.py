"""Tool server wrapping tools.py + swarm-specific tools.

Exposes existing Horizon tools bound to per-agent Engine instances,
plus swarm orchestration tools and anti-overfitting gate implementations.
"""

from __future__ import annotations

import inspect
import logging
import math
import threading
import time
import typing
from typing import Any, Callable

from horizon import tools
from horizon._horizon import Engine

from ._types import (
    AgentPhase,
    Proposal,
    SwarmEvent,
    SwarmEventType,
)

logger = logging.getLogger("horizon.swarm.mcp_tools")

# --------------------------------------------------------------------------- #
# Engine injection for tools.py functions
# --------------------------------------------------------------------------- #
# tools.py functions call get_engine() which returns a module-level singleton.
# In the swarm, each agent has its own Engine. We inject it by temporarily
# swapping tools._engine before each call. A lock prevents concurrent swaps
# when multiple agents run tool calls from different asyncio tasks.

_engine_swap_lock = threading.Lock()


def _call_with_engine(fn: Callable, engine: Engine, args: dict[str, Any]) -> Any:
    """Call a tools.py function with a specific Engine instance."""
    with _engine_swap_lock:
        prev = tools._engine
        tools._engine = engine
        try:
            return fn(**args)
        finally:
            tools._engine = prev


# --------------------------------------------------------------------------- #
# Type mapping for auto-wrapping
# --------------------------------------------------------------------------- #

_TYPE_MAP: dict[type, str] = {
    str: "string",
    int: "integer",
    float: "number",
    bool: "boolean",
    list: "array",
    dict: "object",
}


def _python_type_to_json_schema(tp: Any) -> dict[str, Any]:
    """Convert a Python type hint to a JSON Schema fragment."""
    origin = getattr(tp, "__origin__", None)
    if origin is list:
        args = getattr(tp, "__args__", None)
        if args:
            return {"type": "array", "items": _python_type_to_json_schema(args[0])}
        return {"type": "array", "items": {"type": "string"}}
    if origin is dict:
        return {"type": "object"}
    if tp in _TYPE_MAP:
        return {"type": _TYPE_MAP[tp]}
    return {"type": "string"}


def _build_tool_schema(fn: Callable) -> dict[str, Any]:
    """Introspect a function and build a JSON Schema for its parameters."""
    sig = inspect.signature(fn)
    hints = typing.get_type_hints(fn)
    properties: dict[str, Any] = {}
    required: list[str] = []

    for name, param in sig.parameters.items():
        if name in ("self", "cls"):
            continue
        tp = hints.get(name, str)
        # Unwrap Optional
        origin = getattr(tp, "__origin__", None)
        if origin is typing.Union:
            args = tp.__args__
            tp = args[0] if len(args) == 2 and type(None) in args else tp
        schema = _python_type_to_json_schema(tp)
        if param.default is inspect.Parameter.empty:
            required.append(name)
        else:
            schema["default"] = param.default
        properties[name] = schema

    return {
        "type": "object",
        "properties": properties,
        "required": required,
    }


# --------------------------------------------------------------------------- #
# Tools.py auto-wrapper
# --------------------------------------------------------------------------- #

# Functions in tools.py that should NOT be auto-wrapped
_SKIP_FUNCTIONS = {
    "get_engine",
    "reset_engine",
    # Internal helpers
    "_status_to_dict",
    "_order_to_dict",
    "_position_to_dict",
    "_fill_to_dict",
    "_feed_to_dict",
    "_contingent_to_dict",
    "_validate_url",
    "_market_to_dict",
}


def _get_wrappable_tools() -> list[tuple[str, Callable]]:
    """Get all public functions from tools.py that should be wrapped."""
    result = []
    for name in dir(tools):
        if name.startswith("_") or name in _SKIP_FUNCTIONS:
            continue
        obj = getattr(tools, name)
        if callable(obj) and not isinstance(obj, type):
            result.append((name, obj))
    return result


def _make_tool_def(name: str, fn: Callable) -> dict[str, Any]:
    """Create a tool definition from a tools.py function."""
    return {
        "name": name,
        "description": (fn.__doc__ or name).split("\n")[0].strip(),
        "input_schema": _build_tool_schema(fn),
    }


def _to_openai_tool(td: dict[str, Any]) -> dict[str, Any]:
    """Convert tool definition to OpenAI function-calling format."""
    return {
        "type": "function",
        "function": {
            "name": td["name"],
            "description": td.get("description", td["name"]),
            "parameters": td.get("input_schema", {"type": "object", "properties": {}}),
        },
    }


class AgentToolServer:
    """Tool server for a single swarm agent.

    Wraps all tools.py functions (bound to the agent's Engine) plus
    swarm-specific tools for phase transitions, proposals, and knowledge sharing.
    """

    def __init__(
        self,
        agent_id: str,
        engine: Engine,
        event_bus: Any,
        knowledge_graph: Any,
        proposal_queue: Any,
        directive_queue: Any,
    ) -> None:
        self.agent_id = agent_id
        self._engine = engine
        self._event_bus = event_bus
        self._kg = knowledge_graph
        self._proposal_queue = proposal_queue
        self._directive_queue = directive_queue
        self._phase = AgentPhase.IDLE

        # Build tool definitions
        self._tool_defs: dict[str, dict[str, Any]] = {}
        self._tool_fns: dict[str, Callable] = {}
        self._register_tools()

    def _register_tools(self) -> None:
        """Register all tools (auto-wrapped from tools.py + swarm-specific)."""
        for name, fn in _get_wrappable_tools():
            self._tool_defs[name] = _make_tool_def(name, fn)
            self._tool_fns[name] = fn
        self._register_swarm_tools()

    def _register_swarm_tools(self) -> None:
        """Register swarm-specific tools."""
        swarm_tools = [
            {
                "name": "transition_phase",
                "description": "Move to next workflow phase",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "new_phase": {"type": "string", "enum": [p.value for p in AgentPhase]},
                        "reason": {"type": "string"},
                    },
                    "required": ["new_phase", "reason"],
                },
            },
            {
                "name": "submit_proposal",
                "description": "Submit strategy proposal to Hive for approval",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "hypothesis": {"type": "string"},
                        "market_id": {"type": "string"},
                        "side": {"type": "string"},
                        "edge_estimate": {"type": "number"},
                        "kelly_fraction": {"type": "number"},
                        "requested_capital": {"type": "number"},
                        "backtest_results": {"type": "object"},
                        "robustness_results": {"type": "object"},
                        "reasoning": {"type": "string"},
                        "anti_overfitting_proof": {"type": "object"},
                    },
                    "required": [
                        "hypothesis", "market_id", "side", "edge_estimate",
                        "kelly_fraction", "requested_capital", "backtest_results",
                        "robustness_results", "reasoning", "anti_overfitting_proof",
                    ],
                },
            },
            {
                "name": "share_insight",
                "description": "Share a discovery with all agents via knowledge graph",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "entity": {"type": "string"},
                        "entity_type": {"type": "string", "default": "market"},
                        "fact": {"type": "string"},
                        "confidence": {"type": "number"},
                    },
                    "required": ["entity", "fact", "confidence"],
                },
            },
            {
                "name": "get_hive_directives",
                "description": "Check for new directives from the Hive",
                "input_schema": {"type": "object", "properties": {}},
            },
            {
                "name": "report_status",
                "description": "Report current status to Hive",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "phase": {"type": "string"},
                        "summary": {"type": "string"},
                    },
                    "required": ["phase", "summary"],
                },
            },
            {
                "name": "query_knowledge",
                "description": "Query the shared knowledge graph for market intelligence",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "entity_type": {"type": "string"},
                        "name_pattern": {"type": "string"},
                        "limit": {"type": "integer", "default": 20},
                    },
                },
            },
            # Anti-overfitting gate tools
            {
                "name": "run_deflated_sharpe",
                "description": "Compute deflated Sharpe ratio for multiple testing correction (Harvey et al. 2016)",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "observed_sharpe": {"type": "number"},
                        "n_strategies_tested": {"type": "integer"},
                        "n_observations": {"type": "integer"},
                        "sharpe_std": {"type": "number", "default": 1.0},
                    },
                    "required": ["observed_sharpe", "n_strategies_tested", "n_observations"],
                },
            },
            {
                "name": "run_walk_forward",
                "description": "Run walk-forward out-of-sample validation",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "returns": {"type": "array", "items": {"type": "number"}},
                        "n_splits": {"type": "integer", "default": 5},
                    },
                    "required": ["returns"],
                },
            },
            {
                "name": "run_cpcv_pbo",
                "description": "Run CPCV with probability of backtest overfitting",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "returns": {"type": "array", "items": {"type": "number"}},
                        "n_groups": {"type": "integer", "default": 6},
                    },
                    "required": ["returns"],
                },
            },
            {
                "name": "run_bootstrap_robustness",
                "description": "Bootstrap Monte Carlo stress test",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "returns": {"type": "array", "items": {"type": "number"}},
                        "n_samples": {"type": "integer", "default": 1000},
                    },
                    "required": ["returns"],
                },
            },
            {
                "name": "run_structural_validation",
                "description": "Validate strategy has economic rationale and multi-regime viability",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "hypothesis": {"type": "string"},
                        "regime_results": {"type": "object"},
                        "capacity_usd": {"type": "number"},
                        "requested_capital": {"type": "number"},
                    },
                    "required": ["hypothesis", "regime_results"],
                },
            },
        ]
        for td in swarm_tools:
            self._tool_defs[td["name"]] = td

    @property
    def tool_definitions(self) -> list[dict[str, Any]]:
        """Return all tool definitions in MCP/Anthropic format."""
        return list(self._tool_defs.values())

    @property
    def openai_tool_definitions(self) -> list[dict[str, Any]]:
        """Return all tool definitions in OpenAI function-calling format."""
        return [_to_openai_tool(td) for td in self._tool_defs.values()]

    async def call_tool(self, name: str, args: dict[str, Any]) -> dict[str, Any]:
        """Execute a tool call and return the result."""
        # Swarm-specific tools
        if name == "transition_phase":
            return self._handle_transition_phase(args)
        if name == "submit_proposal":
            return self._handle_submit_proposal(args)
        if name == "share_insight":
            return self._handle_share_insight(args)
        if name == "get_hive_directives":
            return self._handle_get_directives(args)
        if name == "report_status":
            return self._handle_report_status(args)
        if name == "query_knowledge":
            return self._handle_query_knowledge(args)
        # Anti-overfitting gates
        if name == "run_deflated_sharpe":
            return self._handle_deflated_sharpe(args)
        if name == "run_walk_forward":
            return self._handle_walk_forward(args)
        if name == "run_cpcv_pbo":
            return self._handle_cpcv_pbo(args)
        if name == "run_bootstrap_robustness":
            return self._handle_bootstrap_robustness(args)
        if name == "run_structural_validation":
            return self._handle_structural_validation(args)

        # Auto-wrapped tools.py function — inject per-agent engine
        fn = self._tool_fns.get(name)
        if fn is None:
            return {"error": f"Unknown tool: {name}"}

        try:
            result = _call_with_engine(fn, self._engine, args)
            # Publish trading events
            if name == "submit_order":
                self._event_bus.publish_sync("agents", SwarmEvent(
                    type=SwarmEventType.ORDER_SUBMITTED,
                    source=self.agent_id,
                    data={"tool": name, "args": args, "result": result},
                    timestamp=time.time(),
                ))
            return {"result": result}
        except Exception as e:
            logger.debug("Tool %s error for %s: %s", name, self.agent_id, e)
            return {"error": str(e)}

    # ----------------------------------------------------------------------- #
    # Swarm tool handlers
    # ----------------------------------------------------------------------- #

    def _handle_transition_phase(self, args: dict[str, Any]) -> dict[str, Any]:
        new_phase = AgentPhase(args["new_phase"])
        old_phase = self._phase
        self._phase = new_phase
        self._event_bus.publish_sync("agents", SwarmEvent(
            type=SwarmEventType.AGENT_PHASE_CHANGED,
            source=self.agent_id,
            data={"old_phase": old_phase.value, "new_phase": new_phase.value, "reason": args["reason"]},
            timestamp=time.time(),
        ))
        return {"status": "ok", "old_phase": old_phase.value, "new_phase": new_phase.value}

    def _handle_submit_proposal(self, args: dict[str, Any]) -> dict[str, Any]:
        proposal_id = f"prop_{self.agent_id}_{int(time.time())}"
        proposal = Proposal(
            proposal_id=proposal_id,
            agent_id=self.agent_id,
            hypothesis=args["hypothesis"],
            market_id=args["market_id"],
            side=args["side"],
            edge_estimate=args["edge_estimate"],
            kelly_fraction=args["kelly_fraction"],
            requested_capital=args["requested_capital"],
            backtest_results=args["backtest_results"],
            robustness_results=args["robustness_results"],
            reasoning=args["reasoning"],
            anti_overfitting_proof=args["anti_overfitting_proof"],
            timestamp=time.time(),
        )
        self._proposal_queue.append(proposal)
        self._event_bus.publish_sync("hive", SwarmEvent(
            type=SwarmEventType.PROPOSAL_SUBMITTED,
            source=self.agent_id,
            data={"proposal_id": proposal_id, "market_id": args["market_id"], "side": args["side"]},
            timestamp=time.time(),
        ))
        return {"status": "submitted", "proposal_id": proposal_id}

    def _handle_share_insight(self, args: dict[str, Any]) -> dict[str, Any]:
        entity = args["entity"]
        entity_type = args.get("entity_type", "market")
        fact = args["fact"]
        confidence = args["confidence"]

        if self._kg is not None:
            if self._kg.get_entity(entity) is None:
                self._kg.add_entity(entity, entity_type, entity)
            self._kg.add_fact(
                entity_id=entity,
                fact_type="observation",
                content=fact,
                confidence=confidence,
                source=self.agent_id,
            )

        self._event_bus.publish_sync("knowledge", SwarmEvent(
            type=SwarmEventType.KNOWLEDGE_SHARED,
            source=self.agent_id,
            data={"entity": entity, "fact": fact, "confidence": confidence},
            timestamp=time.time(),
        ))
        return {"status": "shared", "entity": entity}

    def _handle_get_directives(self, _args: dict[str, Any]) -> dict[str, Any]:
        directives = []
        while self._directive_queue:
            directives.append(self._directive_queue.pop(0))
        return {"directives": directives}

    def _handle_report_status(self, args: dict[str, Any]) -> dict[str, Any]:
        self._event_bus.publish_sync("agents", SwarmEvent(
            type=SwarmEventType.HEARTBEAT,
            source=self.agent_id,
            data={"phase": args["phase"], "summary": args["summary"]},
            timestamp=time.time(),
        ))
        return {"status": "reported"}

    def _handle_query_knowledge(self, args: dict[str, Any]) -> dict[str, Any]:
        if self._kg is None:
            return {"entities": [], "facts": []}
        entities = self._kg.find_entities(
            entity_type=args.get("entity_type"),
            name_pattern=args.get("name_pattern"),
            limit=args.get("limit", 20),
        )
        return {"entities": entities}

    # ----------------------------------------------------------------------- #
    # Anti-overfitting gate implementations
    # ----------------------------------------------------------------------- #

    def _handle_deflated_sharpe(self, args: dict[str, Any]) -> dict[str, Any]:
        """Deflated Sharpe Ratio — Harvey et al. 2016 correction for multiple testing."""
        sr = args["observed_sharpe"]
        n_strats = args["n_strategies_tested"]
        n_obs = args["n_observations"]
        sr_std = args.get("sharpe_std", 1.0)

        if n_strats < 1 or n_obs < 2:
            return {"error": "Invalid parameters: n_strategies_tested >= 1, n_observations >= 2"}

        # Expected max Sharpe under null (Euler-Mascheroni approximation)
        gamma = 0.5772156649
        e_max_sr = sr_std * (
            (1.0 - gamma) * _norm_ppf(1.0 - 1.0 / n_strats)
            + gamma * _norm_ppf(1.0 - 1.0 / (n_strats * math.e))
        )

        # Deflated Sharpe test statistic
        sr_se = math.sqrt((1.0 + 0.5 * sr**2) / n_obs)
        z = (sr - e_max_sr) / sr_se if sr_se > 1e-10 else 0.0
        p_value = 1.0 - _norm_cdf(z)
        passed = p_value < 0.05

        return {
            "gate": "deflated_sharpe",
            "passed": passed,
            "observed_sharpe": sr,
            "expected_max_sharpe": round(e_max_sr, 4),
            "p_value": round(p_value, 6),
            "threshold": 0.05,
        }

    def _handle_walk_forward(self, args: dict[str, Any]) -> dict[str, Any]:
        """Walk-forward OOS validation with rolling train/test splits."""
        returns = args["returns"]
        n_splits = args.get("n_splits", 5)

        if len(returns) < n_splits * 10:
            return {"error": f"Insufficient data: need >= {n_splits * 10} returns, got {len(returns)}"}

        chunk = len(returns) // n_splits
        oos_sharpes = []
        is_sharpes = []

        for i in range(n_splits):
            test_start = i * chunk
            test_end = test_start + chunk
            train = returns[:test_start] + returns[test_end:]
            test = returns[test_start:test_end]
            if not train or not test:
                continue
            is_sharpes.append(_sharpe(train))
            oos_sharpes.append(_sharpe(test))

        avg_oos = sum(oos_sharpes) / len(oos_sharpes) if oos_sharpes else 0.0
        avg_is = sum(is_sharpes) / len(is_sharpes) if is_sharpes else 0.0
        ratio = avg_oos / avg_is if abs(avg_is) > 1e-10 else 0.0
        passed = avg_oos > 0.5 and ratio > 0.5

        return {
            "gate": "walk_forward",
            "passed": passed,
            "avg_oos_sharpe": round(avg_oos, 4),
            "avg_is_sharpe": round(avg_is, 4),
            "oos_is_ratio": round(ratio, 4),
            "n_splits": n_splits,
            "thresholds": {"min_oos_sharpe": 0.5, "min_oos_is_ratio": 0.5},
        }

    def _handle_cpcv_pbo(self, args: dict[str, Any]) -> dict[str, Any]:
        """Combinatorial Purged Cross-Validation with Probability of Backtest Overfitting."""
        returns = args["returns"]
        n_groups = args.get("n_groups", 6)

        if len(returns) < n_groups * 5:
            return {"error": f"Insufficient data: need >= {n_groups * 5} returns, got {len(returns)}"}

        chunk = len(returns) // n_groups
        groups = [returns[i * chunk:(i + 1) * chunk] for i in range(n_groups)]

        oos_performances = []
        for hold_out in range(n_groups):
            train = []
            for i, g in enumerate(groups):
                if i != hold_out:
                    train.extend(g)
            test = groups[hold_out]
            oos_performances.append(_sharpe(test))

        n_negative = sum(1 for s in oos_performances if s <= 0)
        pbo = n_negative / len(oos_performances) if oos_performances else 1.0
        passed = pbo < 0.30

        return {
            "gate": "cpcv_pbo",
            "passed": passed,
            "pbo": round(pbo, 4),
            "threshold": 0.30,
            "n_groups": n_groups,
            "oos_sharpes": [round(s, 4) for s in oos_performances],
        }

    def _handle_bootstrap_robustness(self, args: dict[str, Any]) -> dict[str, Any]:
        """Bootstrap Monte Carlo stress test."""
        import random
        import statistics

        returns = args["returns"]
        n_samples = args.get("n_samples", 1000)

        if len(returns) < 20:
            return {"error": f"Insufficient data: need >= 20 returns, got {len(returns)}"}

        # Bootstrap Sharpe distribution
        boot_sharpes = []
        for _ in range(n_samples):
            sample = random.choices(returns, k=len(returns))
            boot_sharpes.append(_sharpe(sample))

        p_positive = sum(1 for s in boot_sharpes if s > 0) / n_samples
        sharpe_5th = sorted(boot_sharpes)[int(0.05 * n_samples)]

        # Monte Carlo timing permutation
        mc_count = min(n_samples, 500)
        mc_profits = 0
        for _ in range(mc_count):
            shuffled = returns.copy()
            random.shuffle(shuffled)
            if sum(shuffled) > 0:
                mc_profits += 1
        mc_pct = mc_profits / mc_count

        # Stress test: 2x volatility scenario
        mean = statistics.mean(returns)
        stressed = [r + (r - mean) for r in returns]  # double deviations
        max_dd = _max_drawdown(stressed)
        normal_max_dd = _max_drawdown(returns)
        stress_ratio = max_dd / normal_max_dd if normal_max_dd > 1e-10 else float("inf")

        passed = p_positive > 0.95 and mc_pct > 0.80 and stress_ratio < 2.0

        return {
            "gate": "bootstrap_robustness",
            "passed": passed,
            "p_sharpe_positive": round(p_positive, 4),
            "sharpe_5th_percentile": round(sharpe_5th, 4),
            "mc_profitable_pct": round(mc_pct, 4),
            "stress_max_dd_ratio": round(min(stress_ratio, 999.0), 4),
            "thresholds": {
                "min_p_positive": 0.95,
                "min_mc_profitable": 0.80,
                "max_stress_dd_ratio": 2.0,
            },
        }

    def _handle_structural_validation(self, args: dict[str, Any]) -> dict[str, Any]:
        """Validate strategy has economic rationale and multi-regime viability."""
        hypothesis = args["hypothesis"]
        regime_results = args["regime_results"]
        capacity = args.get("capacity_usd", float("inf"))
        requested = args.get("requested_capital", 0.0)

        has_hypothesis = len(hypothesis.strip()) > 20
        n_regimes = len(regime_results)
        multi_regime = n_regimes >= 2
        regime_profitable = all(
            regime_results.get(r, {}).get("sharpe", 0) > 0
            for r in regime_results
        ) if regime_results else False
        has_capacity = capacity >= requested if requested > 0 else True
        passed = has_hypothesis and multi_regime and regime_profitable and has_capacity

        return {
            "gate": "structural_validation",
            "passed": passed,
            "has_hypothesis": has_hypothesis,
            "multi_regime": multi_regime,
            "n_regimes": n_regimes,
            "all_regimes_profitable": regime_profitable,
            "has_capacity": has_capacity,
        }


class HiveToolServer:
    """Tool server for the Hive orchestrator.

    Provides tools for spawning/killing agents, reviewing proposals,
    allocating capital, and querying swarm state.
    """

    def __init__(self, hive: Any) -> None:
        self._hive = hive

    @property
    def openai_tool_definitions(self) -> list[dict[str, Any]]:
        return [_to_openai_tool(td) for td in self.tool_definitions]

    @property
    def tool_definitions(self) -> list[dict[str, Any]]:
        return [
            {
                "name": "spawn_agent",
                "description": "Spawn a new agent workflow (empty mission = free-roaming)",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "mission": {"type": "string", "default": ""},
                    },
                },
            },
            {
                "name": "kill_agent",
                "description": "Terminate an agent",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "agent_id": {"type": "string"},
                        "reason": {"type": "string"},
                    },
                    "required": ["agent_id", "reason"],
                },
            },
            {
                "name": "redirect_agent",
                "description": "Send a directive to change an agent's focus",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "agent_id": {"type": "string"},
                        "directive": {"type": "string"},
                    },
                    "required": ["agent_id", "directive"],
                },
            },
            {
                "name": "allocate_capital",
                "description": "Set capital allocation for an agent",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "agent_id": {"type": "string"},
                        "amount": {"type": "number"},
                    },
                    "required": ["agent_id", "amount"],
                },
            },
            {
                "name": "review_proposal",
                "description": "Accept/reject a pending proposal from an agent",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "proposal_id": {"type": "string"},
                        "verdict": {"type": "string", "enum": ["approved", "rejected", "revise", "deferred"]},
                        "reasoning": {"type": "string"},
                    },
                    "required": ["proposal_id", "verdict", "reasoning"],
                },
            },
            {
                "name": "get_swarm_status",
                "description": "Get status of all agents and portfolio",
                "input_schema": {"type": "object", "properties": {}},
            },
            {
                "name": "get_agent_details",
                "description": "Get detailed info on a specific agent",
                "input_schema": {
                    "type": "object",
                    "properties": {"agent_id": {"type": "string"}},
                    "required": ["agent_id"],
                },
            },
            {
                "name": "broadcast_insight",
                "description": "Share insight with all agents",
                "input_schema": {
                    "type": "object",
                    "properties": {"message": {"type": "string"}},
                    "required": ["message"],
                },
            },
            {
                "name": "get_portfolio_risk",
                "description": "Get portfolio-level risk metrics",
                "input_schema": {"type": "object", "properties": {}},
            },
        ]

    async def call_tool(self, name: str, args: dict[str, Any]) -> dict[str, Any]:
        """Execute a Hive tool call."""
        try:
            if name == "spawn_agent":
                agent_id = await self._hive.spawn_agent(mission=args.get("mission", ""))
                return {"agent_id": agent_id, "status": "spawned"}
            if name == "kill_agent":
                await self._hive.kill_agent(args["agent_id"], args["reason"])
                return {"status": "killed", "agent_id": args["agent_id"]}
            if name == "redirect_agent":
                self._hive.redirect_agent(args["agent_id"], args["directive"])
                return {"status": "redirected", "agent_id": args["agent_id"]}
            if name == "allocate_capital":
                self._hive.allocate_capital(args["agent_id"], args["amount"])
                return {"status": "allocated", "agent_id": args["agent_id"], "amount": args["amount"]}
            if name == "review_proposal":
                return self._hive.review_proposal(
                    args["proposal_id"], args["verdict"], args["reasoning"]
                )
            if name == "get_swarm_status":
                return self._hive.get_swarm_status()
            if name == "get_agent_details":
                return self._hive.get_agent_details(args["agent_id"])
            if name == "broadcast_insight":
                self._hive.broadcast_insight(args["message"])
                return {"status": "broadcast"}
            if name == "get_portfolio_risk":
                return self._hive.get_portfolio_risk()
            return {"error": f"Unknown tool: {name}"}
        except Exception as e:
            return {"error": str(e)}


# --------------------------------------------------------------------------- #
# Statistical helpers (no external deps)
# --------------------------------------------------------------------------- #

def _sharpe(returns: list[float], risk_free: float = 0.0) -> float:
    """Annualized Sharpe ratio from a list of returns."""
    if len(returns) < 2:
        return 0.0
    import statistics
    mean = statistics.mean(returns) - risk_free
    std = statistics.stdev(returns)
    if std < 1e-10:
        return 0.0
    return mean / std * math.sqrt(252)


def _max_drawdown(returns: list[float]) -> float:
    """Max drawdown from a returns series."""
    running = 0.0
    peak = 0.0
    max_dd = 0.0
    for r in returns:
        running += r
        peak = max(peak, running)
        dd = (peak - running) / peak if peak > 1e-10 else 0.0
        max_dd = max(max_dd, dd)
    return max_dd


def _norm_cdf(x: float) -> float:
    """Standard normal CDF (Abramowitz & Stegun)."""
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def _norm_ppf(p: float) -> float:
    """Approximate inverse normal CDF (Beasley-Springer-Moro)."""
    if p <= 0:
        return -10.0
    if p >= 1:
        return 10.0
    if p == 0.5:
        return 0.0
    if 0.08 < p < 0.92:
        r = p - 0.5
        r2 = r * r
        return r * (2.515517 + 0.802853 * r2) / (1.0 + 0.010328 * r2 + 0.001308 * r2 * r2)
    if p < 0.5:
        r = math.sqrt(-2.0 * math.log(p))
    else:
        r = math.sqrt(-2.0 * math.log(1.0 - p))
    result = r - (2.515517 + 0.802853 * r + 0.010328 * r * r) / (
        1.0 + 1.432788 * r + 0.189269 * r * r + 0.001308 * r * r * r
    )
    return result if p > 0.5 else -result
