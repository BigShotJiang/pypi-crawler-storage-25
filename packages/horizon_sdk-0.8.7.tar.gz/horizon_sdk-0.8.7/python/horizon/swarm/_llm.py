"""Horizon LLM client — wraps any OpenAI-compatible provider.

Single abstraction used by both Hive and Agent. Handles retry,
cost tracking, streaming, and response normalization. Callers never
import or touch the OpenAI SDK directly.
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from typing import Any, Callable

logger = logging.getLogger("horizon.swarm.llm")

try:
    from openai import AsyncOpenAI as _AsyncOpenAI
except ImportError:
    _AsyncOpenAI = None  # type: ignore[assignment,misc]

# Retry defaults
_MAX_RETRIES = 3
_RETRY_BACKOFF_S = [1.0, 3.0, 10.0]
_RETRYABLE_CODES = ("429", "500", "502", "503", "timeout")

# $/M-token pricing tiers (conservative estimates)
_PRICING: list[tuple[list[str], float, float]] = [
    # (model substrings, input $/M, output $/M)
    (["opus", "gpt-4o", "gpt-4-turbo"], 15.0, 75.0),
    (["sonnet", "gpt-4", "gpt-5"], 3.0, 15.0),
    (["haiku", "mini", "flash"], 0.3, 1.2),
]
_DEFAULT_INPUT_RATE = 1.0
_DEFAULT_OUTPUT_RATE = 4.0


# --------------------------------------------------------------------------- #
# Response types
# --------------------------------------------------------------------------- #

@dataclass
class ToolCall:
    """A single tool call from the LLM."""

    id: str
    name: str
    arguments: str


@dataclass
class LLMResponse:
    """Normalized response from any OpenAI-compatible provider."""

    content: str | None
    tool_calls: list[ToolCall]
    finish_reason: str
    input_tokens: int
    output_tokens: int
    cost_usd: float

    def to_message(self) -> dict[str, Any]:
        """Build the assistant message dict for the conversation history."""
        msg: dict[str, Any] = {"role": "assistant", "content": self.content or ""}
        if self.tool_calls:
            msg["tool_calls"] = [
                {
                    "id": tc.id,
                    "type": "function",
                    "function": {"name": tc.name, "arguments": tc.arguments},
                }
                for tc in self.tool_calls
            ]
        return msg


# --------------------------------------------------------------------------- #
# Client
# --------------------------------------------------------------------------- #

class LLMClient:
    """Async LLM client with retry, cost tracking, and response normalization.

    Works with any OpenAI-compatible API (OpenRouter, Azure, local, etc.).

    Usage::

        llm = LLMClient(api_key="sk-or-...", model="anthropic/claude-sonnet-4-6")

        # Non-streaming (Hive oversight, simple calls)
        resp = await llm.complete(messages, tools=tool_defs)

        # Streaming (Agent cycles, real-time output)
        resp = await llm.stream(messages, tools=tool_defs, on_delta=handle_chunk)
    """

    def __init__(
        self,
        api_key: str,
        model: str,
        api_base: str = "https://openrouter.ai/api/v1",
        max_retries: int = _MAX_RETRIES,
        max_tokens: int = 4096,
    ) -> None:
        if _AsyncOpenAI is None:
            raise ImportError("Install openai: pip install 'openai>=1.30'")

        self._client = _AsyncOpenAI(api_key=api_key, base_url=api_base)
        self.model = model
        self._max_retries = max_retries
        self._max_tokens = max_tokens

        # Resolve pricing for this model once
        self._input_rate, self._output_rate = self._resolve_pricing(model)

        # Cumulative stats
        self.total_cost_usd: float = 0.0
        self.total_input_tokens: int = 0
        self.total_output_tokens: int = 0
        self.total_requests: int = 0

    # ----------------------------------------------------------------------- #
    # Public API
    # ----------------------------------------------------------------------- #

    async def complete(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        *,
        max_tokens: int | None = None,
    ) -> LLMResponse | None:
        """Non-streaming completion with automatic retry and cost tracking.

        Returns ``None`` if all retries are exhausted or a non-retryable
        error occurs.
        """
        for attempt in range(self._max_retries):
            try:
                raw = await self._client.chat.completions.create(
                    model=self.model,
                    max_tokens=max_tokens or self._max_tokens,
                    messages=messages,
                    tools=tools if tools else None,
                )
                self.total_requests += 1
                return self._normalize(raw)
            except Exception as e:
                if not self._should_retry(e, attempt):
                    return None
                await asyncio.sleep(self._backoff(attempt))
        return None

    async def stream(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        *,
        max_tokens: int | None = None,
        on_delta: Callable[[str], None] | None = None,
    ) -> LLMResponse | None:
        """Streaming completion with per-chunk callbacks.

        Calls ``on_delta(text)`` for each content chunk as it arrives.
        Returns the final ``LLMResponse`` when the stream completes.
        Falls back to ``complete()`` if the provider doesn't support streaming.
        """
        for attempt in range(self._max_retries):
            try:
                resp = await self._do_stream(
                    messages, tools,
                    max_tokens=max_tokens or self._max_tokens,
                    on_delta=on_delta,
                )
                self.total_requests += 1
                return resp
            except Exception as e:
                if not self._should_retry(e, attempt):
                    return None
                await asyncio.sleep(self._backoff(attempt))
        return None

    # ----------------------------------------------------------------------- #
    # Internals
    # ----------------------------------------------------------------------- #

    async def _do_stream(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None,
        max_tokens: int,
        on_delta: Callable[[str], None] | None,
    ) -> LLMResponse:
        """Execute a streaming call, invoking on_delta per chunk."""
        async with self._client.chat.completions.stream(
            model=self.model,
            max_tokens=max_tokens,
            messages=messages,
            tools=tools if tools else None,
        ) as s:
            async for event in s:
                if on_delta is not None and event.type == "content.delta":
                    on_delta(event.delta)
            raw = s.get_final_completion()

        return self._normalize(raw)

    def _normalize(self, raw: Any) -> LLMResponse:
        """Convert a raw SDK response into an LLMResponse."""
        choice = raw.choices[0]
        msg = choice.message

        tool_calls: list[ToolCall] = []
        if msg.tool_calls:
            tool_calls = [
                ToolCall(id=tc.id, name=tc.function.name, arguments=tc.function.arguments)
                for tc in msg.tool_calls
            ]

        # Token counts and cost
        usage = getattr(raw, "usage", None)
        input_tokens = getattr(usage, "prompt_tokens", 0) or 0 if usage else 0
        output_tokens = getattr(usage, "completion_tokens", 0) or 0 if usage else 0
        cost = (input_tokens * self._input_rate + output_tokens * self._output_rate) / 1_000_000

        self.total_input_tokens += input_tokens
        self.total_output_tokens += output_tokens
        self.total_cost_usd += cost

        return LLMResponse(
            content=msg.content,
            tool_calls=tool_calls,
            finish_reason=choice.finish_reason or "stop",
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cost_usd=cost,
        )

    def _should_retry(self, error: Exception, attempt: int) -> bool:
        """Decide if the error is retryable and we have attempts left."""
        err_str = str(error)
        is_retryable = any(code in err_str for code in _RETRYABLE_CODES)
        if not is_retryable or attempt >= self._max_retries - 1:
            logger.error(
                "LLM call failed [%s] (attempt %d/%d): %s",
                self.model, attempt + 1, self._max_retries, error,
            )
            return False
        logger.warning(
            "LLM call retrying [%s] in %.0fs (attempt %d/%d): %s",
            self.model, self._backoff(attempt),
            attempt + 1, self._max_retries, error,
        )
        return True

    @staticmethod
    def _backoff(attempt: int) -> float:
        return _RETRY_BACKOFF_S[min(attempt, len(_RETRY_BACKOFF_S) - 1)]

    @staticmethod
    def _resolve_pricing(model: str) -> tuple[float, float]:
        """Match model name to pricing tier."""
        model_lower = model.lower()
        for substrings, input_rate, output_rate in _PRICING:
            if any(s in model_lower for s in substrings):
                return input_rate, output_rate
        return _DEFAULT_INPUT_RATE, _DEFAULT_OUTPUT_RATE
