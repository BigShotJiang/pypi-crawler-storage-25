"""Minimal live test: buy 1 YES share on Polymarket.

Works with both EOA and Gnosis Safe wallets.

Usage:
    python examples/polymarket_safe_test.py <market_slug> [price]

Examples:
    python examples/polymarket_safe_test.py will-trump-win-2028 0.10
    python examples/polymarket_safe_test.py will-trump-win-2028       # defaults to $0.01
"""

import os
import sys

import horizon as hz

# ── Credentials ──────────────────────────────────────────────────────────────
# Fill these in directly, or leave empty to read from env vars.

PRIVATE_KEY = ""          # e.g. "0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80"
API_KEY = ""              # CLOB API key
API_SECRET = ""           # CLOB API secret (base64-encoded)
API_PASSPHRASE = ""       # CLOB API passphrase

# ── Gnosis Safe (leave empty for standard EOA) ──────────────────────────────
FUNDER = ""               # e.g. "0x1234567890abcdef1234567890abcdef12345678"
SIGNATURE_TYPE = 0        # 0 = EOA, 1 = Proxy, 2 = Gnosis Safe

# ─────────────────────────────────────────────────────────────────────────────


def main():
    if len(sys.argv) < 2:
        print("Usage: python examples/polymarket_safe_test.py <market_slug> [price]")
        print("  price defaults to $0.01 (a penny, unlikely to fill)")
        sys.exit(1)

    market_slug = sys.argv[1]
    price = float(sys.argv[2]) if len(sys.argv) > 2 else 0.01

    exch = hz.Polymarket(
        private_key=PRIVATE_KEY or os.environ.get("POLYMARKET_PRIVATE_KEY"),
        api_key=API_KEY or os.environ.get("POLYMARKET_API_KEY"),
        api_secret=API_SECRET or os.environ.get("POLYMARKET_API_SECRET"),
        api_passphrase=API_PASSPHRASE or os.environ.get("POLYMARKET_API_PASSPHRASE"),
        funder=FUNDER or os.environ.get("POLYMARKET_FUNDER"),
        signature_type=SIGNATURE_TYPE or int(os.environ.get("POLYMARKET_SIGNATURE_TYPE", "0")),
    )

    sig_label = {0: "EOA", 1: "Proxy", 2: "Gnosis Safe"}.get(exch.signature_type, "?")
    print(f"=== Polymarket Live Test ===")
    print(f"Market:         {market_slug}")
    print(f"Price:          ${price}")
    print(f"Size:           1 share")
    print(f"Signature type: {exch.signature_type} ({sig_label})")
    print(f"Funder:         {exch.funder or '(none - direct EOA)'}")
    print()

    # Auto-derive API creds if only private key is set
    if exch.private_key and not exch.api_key:
        print("Deriving API credentials from CLOB...")
        exch.derive_api_credentials()
        print("Done.\n")

    # Create engine in live mode
    engine = hz.Engine(
        risk_config=hz.Risk(
            max_position=10,
            max_portfolio=100,
            max_order_size=5,
        ),
        exchange_type="polymarket",
        exchange_key=exch.api_key,
        exchange_secret=exch.api_secret,
        exchange_passphrase=exch.api_passphrase,
        clob_url=exch.clob_url,
        private_key=exch.private_key,
        funder=exch.funder,
        signature_type=exch.signature_type,
    )

    print(f"Engine created: {engine.exchange_name()}")

    # Check balance (works for both EOA and Safe)
    try:
        balance, allowance = engine.get_balance_allowance()
        print(f"USDC balance:   ${balance:.2f}")
        print(f"Allowance:      ${allowance:.2f}")
    except Exception as e:
        print(f"Balance check:  {e}")
    print()

    # Sync positions
    count = engine.sync_positions()
    print(f"Synced positions: {count}")

    # Place a limit buy for 1 YES share
    req = hz.OrderRequest(
        market_id=market_slug,
        side=hz.Side.Yes,
        order_side=hz.OrderSide.Buy,
        size=1.0,
        price=price,
    )

    print(f"\nSubmitting: BUY 1 YES @ ${price}...")
    try:
        order_id = engine.submit_order(req)
        print(f"Order placed! ID: {order_id}")

        # Cancel it right away (this is just a test)
        print("Canceling order...")
        engine.cancel(order_id)
        print("Canceled. Test complete!")
    except Exception as e:
        print(f"Order failed: {e}")
        print("\nIf you see 'invalid signature', check your funder address and signature_type.")


if __name__ == "__main__":
    main()
