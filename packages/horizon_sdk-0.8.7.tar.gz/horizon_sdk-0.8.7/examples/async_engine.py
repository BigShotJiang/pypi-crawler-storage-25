"""Using Horizon Engine with asyncio (non-blocking).

hz.run() is a blocking event loop for pipeline-based strategies.
For async architectures, use Engine directly — it's a standalone object
that doesn't require hz.run().

engine.submit_order() blocks for ~80ms (Rust HTTP round-trip).
Wrap in asyncio.to_thread() to avoid blocking your event loop.
"""

import asyncio
import horizon as hz

# ── Credentials ──────────────────────────────────────────────────────────────

PRIVATE_KEY = ""
API_KEY = ""
API_SECRET = ""
API_PASSPHRASE = ""

# Gnosis Safe (leave empty for EOA)
FUNDER = ""
SIGNATURE_TYPE = 0  # 0 = EOA, 2 = Gnosis Safe

# ─────────────────────────────────────────────────────────────────────────────


def make_engine() -> hz.Engine:
    """Create a live Polymarket engine (call once at startup)."""
    return hz.Engine(
        risk_config=hz.Risk(
            max_position=100,
            max_portfolio=1000,
            max_order_size=50,
        ),
        exchange_type="polymarket",
        exchange_key=API_KEY,
        exchange_secret=API_SECRET,
        exchange_passphrase=API_PASSPHRASE,
        private_key=PRIVATE_KEY,
        funder=FUNDER or None,
        signature_type=SIGNATURE_TYPE,
    )


async def submit(engine: hz.Engine, req: hz.OrderRequest) -> str:
    """Submit an order without blocking the event loop."""
    return await asyncio.to_thread(engine.submit_order, req)


async def cancel(engine: hz.Engine, order_id: str) -> None:
    """Cancel an order without blocking the event loop."""
    await asyncio.to_thread(engine.cancel, order_id)


async def cancel_all(engine: hz.Engine) -> int:
    """Cancel all orders without blocking the event loop."""
    return await asyncio.to_thread(engine.cancel_all)


async def get_balance(engine: hz.Engine) -> tuple[float, float]:
    """Get USDC balance and allowance without blocking."""
    return await asyncio.to_thread(engine.get_balance_allowance)


async def main():
    engine = make_engine()

    # Check balance
    balance, allowance = await get_balance(engine)
    print(f"Balance: ${balance:.2f}, Allowance: ${allowance:.2f}")

    # Submit an order
    req = hz.OrderRequest(
        market_id="will-trump-win-2028",
        side=hz.Side.Yes,
        order_side=hz.OrderSide.Buy,
        size=1.0,
        price=0.01,
    )

    order_id = await submit(engine, req)
    print(f"Order placed: {order_id}")

    # Cancel it
    await cancel(engine, order_id)
    print("Canceled.")

    # You can fire multiple orders concurrently:
    # results = await asyncio.gather(
    #     submit(engine, req1),
    #     submit(engine, req2),
    #     submit(engine, req3),
    # )


if __name__ == "__main__":
    asyncio.run(main())
