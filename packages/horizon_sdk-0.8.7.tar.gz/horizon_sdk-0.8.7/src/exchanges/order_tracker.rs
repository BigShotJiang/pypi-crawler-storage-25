//! Shared order tracking for exchange clients.
//!
//! Encapsulates the `open_orders: HashMap<String, Vec<String>>` pattern with
//! eviction cap logic that is duplicated across all exchange implementations.

use std::collections::HashMap;
use tracing::warn;

/// Maximum total order IDs tracked before hard-cap eviction.
const DEFAULT_CAP: usize = 10_000;

/// Tracks open order IDs per market with bounded growth.
///
/// Used by exchange clients to support `cancel_for_market` and to clean up
/// filled orders. Encapsulates the insert/remove/eviction pattern that was
/// previously duplicated across 8+ exchange files.
pub struct OrderTracker {
    /// market_id -> list of open order IDs
    orders: HashMap<String, Vec<String>>,
    /// Name of the exchange (for log messages).
    exchange_name: &'static str,
    /// Maximum total order IDs before hard-cap eviction.
    cap: usize,
}

impl OrderTracker {
    /// Create a new OrderTracker for the given exchange.
    pub fn new(exchange_name: &'static str) -> Self {
        Self {
            orders: HashMap::new(),
            exchange_name,
            cap: DEFAULT_CAP,
        }
    }

    /// Insert an order ID for a market. Applies eviction if over cap.
    pub fn insert(&mut self, market_id: &str, order_id: &str) {
        self.orders
            .entry(market_id.to_string())
            .or_default()
            .push(order_id.to_string());
        // Evict empty market entries to bound growth
        self.orders.retain(|_, ids| !ids.is_empty());
        // Hard cap: if tracking > cap order IDs total, clear stale entries
        let total: usize = self.orders.values().map(|v| v.len()).sum();
        if total > self.cap {
            warn!(
                "{}: open_orders tracking exceeds {}k, clearing stale entries",
                self.exchange_name,
                self.cap / 1000
            );
            self.orders.clear();
            self.orders
                .entry(market_id.to_string())
                .or_default()
                .push(order_id.to_string());
        }
    }

    /// Remove an order ID from all markets (e.g., after cancel).
    pub fn remove(&mut self, order_id: &str) {
        for ids in self.orders.values_mut() {
            ids.retain(|oid| oid != order_id);
        }
    }

    /// Remove specific order IDs from a market (e.g., after cancel_for_market).
    pub fn remove_from_market(&mut self, market_id: &str, canceled_ids: &[String]) {
        if let Some(ids) = self.orders.get_mut(market_id) {
            ids.retain(|oid| !canceled_ids.contains(oid));
            if ids.is_empty() {
                self.orders.remove(market_id);
            }
        }
    }

    /// Remove filled order IDs from tracking (searches all markets).
    pub fn remove_filled(&mut self, filled_order_ids: &[&str]) {
        for ids in self.orders.values_mut() {
            ids.retain(|oid| !filled_order_ids.contains(&oid.as_str()));
        }
        self.orders.retain(|_, ids| !ids.is_empty());
    }

    /// Get all order IDs for a market.
    pub fn get_market_orders(&self, market_id: &str) -> Vec<String> {
        self.orders.get(market_id).cloned().unwrap_or_default()
    }

    /// Get all tracked market IDs.
    pub fn markets(&self) -> Vec<String> {
        self.orders.keys().cloned().collect()
    }

    /// Get all tracked order IDs across all markets, flattened.
    pub fn all_orders(&self) -> Vec<String> {
        self.orders.values().flatten().cloned().collect()
    }

    /// Clear all tracked orders.
    pub fn clear(&mut self) {
        self.orders.clear();
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_insert_and_get() {
        let mut tracker = OrderTracker::new("test");
        tracker.insert("market1", "order1");
        tracker.insert("market1", "order2");
        tracker.insert("market2", "order3");

        assert_eq!(tracker.get_market_orders("market1"), vec!["order1", "order2"]);
        assert_eq!(tracker.get_market_orders("market2"), vec!["order3"]);
        assert!(tracker.get_market_orders("market3").is_empty());
    }

    #[test]
    fn test_remove() {
        let mut tracker = OrderTracker::new("test");
        tracker.insert("market1", "order1");
        tracker.insert("market1", "order2");
        tracker.remove("order1");

        assert_eq!(tracker.get_market_orders("market1"), vec!["order2"]);
    }

    #[test]
    fn test_remove_from_market() {
        let mut tracker = OrderTracker::new("test");
        tracker.insert("market1", "order1");
        tracker.insert("market1", "order2");
        tracker.insert("market1", "order3");

        let canceled = vec!["order1".to_string(), "order3".to_string()];
        tracker.remove_from_market("market1", &canceled);

        assert_eq!(tracker.get_market_orders("market1"), vec!["order2"]);
    }

    #[test]
    fn test_remove_filled() {
        let mut tracker = OrderTracker::new("test");
        tracker.insert("market1", "order1");
        tracker.insert("market2", "order2");
        tracker.remove_filled(&["order1", "order2"]);

        assert!(tracker.get_market_orders("market1").is_empty());
        assert!(tracker.get_market_orders("market2").is_empty());
    }

    #[test]
    fn test_clear() {
        let mut tracker = OrderTracker::new("test");
        tracker.insert("market1", "order1");
        tracker.insert("market2", "order2");
        tracker.clear();

        assert!(tracker.get_market_orders("market1").is_empty());
        assert!(tracker.get_market_orders("market2").is_empty());
    }
}
