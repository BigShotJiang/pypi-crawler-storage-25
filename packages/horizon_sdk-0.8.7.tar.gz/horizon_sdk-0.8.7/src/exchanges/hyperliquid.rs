//! Hyperliquid exchange client (perpetuals + spot).
//!
//! Implements the Exchange trait for Hyperliquid's L1 chain.
//! Uses EIP-712 wallet signing for all write operations.
//! Only two REST endpoints: POST /info (reads), POST /exchange (writes).
//! Assets are identified by integer indices, resolved via metadata.
//! Prices/sizes are sent as strings with specific formatting.
//! Market orders are implemented as aggressive limit IOC with 5% slippage.

use crate::error::HorizonError;
use crate::exchanges::crypto_utils::{
    derive_address, keccak256, parse_private_key, sign_digest, u64_to_u256,
};
use crate::exchanges::fill_dedup::FillDedup;
use crate::exchanges::order_tracker::OrderTracker;
use crate::exchanges::Exchange;
use crate::types::{Fill, OrderRequest, OrderSide, Position, Side};
use k256::ecdsa::SigningKey;
use std::collections::HashMap;
use std::sync::{Arc, Mutex};
use std::time::{SystemTime, UNIX_EPOCH};
use tracing::{debug, error, info, warn};

const MAINNET_URL: &str = "https://api.hyperliquid.xyz";
const TESTNET_URL: &str = "https://api.hyperliquid-testnet.xyz";

/// EIP-712 chain ID for Hyperliquid.
const HL_CHAIN_ID: u64 = 1337;

/// Maximum slippage for market orders (5%).
const MARKET_ORDER_SLIPPAGE: f64 = 0.05;

// Crypto helpers imported from crate::exchanges::crypto_utils

/// Convert f64 to Hyperliquid wire format string.
/// Always formats with 8 decimal places, then strips trailing zeros.
/// Matches the official Python SDK's `float_to_wire`.
fn float_to_wire(v: f64) -> String {
    let formatted = format!("{:.8}", v);
    let result = if formatted.contains('.') {
        let trimmed = formatted.trim_end_matches('0').trim_end_matches('.');
        trimmed.to_string()
    } else {
        formatted
    };
    // Normalize -0 to 0
    if result == "-0" {
        "0".to_string()
    } else {
        result
    }
}

/// Parse an ISO 8601 timestamp string to Unix milliseconds.
fn parse_timestamp_ms(s: &str) -> f64 {
    // Try numeric (already ms)
    if let Ok(v) = s.parse::<f64>() {
        // If > 1e12, it's already ms
        if v > 1e12 {
            return v;
        }
        return v * 1000.0;
    }
    0.0
}

// -- EIP-712 for Hyperliquid --------------------------------------------------

/// Compute Hyperliquid's EIP-712 domain separator.
///
/// Domain: {name: "Exchange", version: "1", chainId: 1337, verifyingContract: 0x0...0}
fn hl_domain_separator() -> [u8; 32] {
    let type_hash = keccak256(
        b"EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)",
    );
    let name_hash = keccak256(b"Exchange");
    let version_hash = keccak256(b"1");
    let chain_id = u64_to_u256(HL_CHAIN_ID);
    let contract = [0u8; 32]; // verifyingContract = address(0)

    let mut buf = Vec::with_capacity(5 * 32);
    buf.extend_from_slice(&type_hash);
    buf.extend_from_slice(&name_hash);
    buf.extend_from_slice(&version_hash);
    buf.extend_from_slice(&chain_id);
    buf.extend_from_slice(&contract);

    keccak256(&buf)
}

/// Agent type hash: keccak256("Agent(string source,bytes32 connectionId)")
/// Note: source is EIP-712 type "string", NOT "address".
fn agent_type_hash() -> [u8; 32] {
    keccak256(b"Agent(string source,bytes32 connectionId)")
}

/// Build the connection_id from an action hash, nonce, and optional vault address.
///
/// Hyperliquid signing flow:
/// 1. Serialize action as msgpack → bytes
/// 2. Append nonce as 8-byte BE
/// 3. Append vault flag: 0x00 (no vault) or 0x01 + 20-byte address
/// 4. keccak256(bytes) → connection_id
fn build_connection_id(
    action_hash: &[u8],
    nonce: u64,
    vault_address: Option<&[u8; 20]>,
) -> [u8; 32] {
    let mut bytes = Vec::with_capacity(action_hash.len() + 8 + 21);
    bytes.extend_from_slice(action_hash);
    bytes.extend_from_slice(&nonce.to_be_bytes());
    match vault_address {
        Some(addr) => {
            bytes.push(0x01);
            bytes.extend_from_slice(addr);
        }
        None => {
            bytes.push(0x00);
        }
    }
    keccak256(&bytes)
}

/// Sign an action using Hyperliquid's EIP-712 scheme.
///
/// Returns hex-encoded signature with {"r": "0x...", "s": "0x...", "v": N} format.
fn sign_action(
    key: &SigningKey,
    action_bytes: &[u8],
    nonce: u64,
    vault_address: Option<&[u8; 20]>,
    is_mainnet: bool,
) -> Result<serde_json::Value, HorizonError> {
    let connection_id = build_connection_id(action_bytes, nonce, vault_address);

    // source = "a" (mainnet) or "b" (testnet).
    // EIP-712 encodes string fields as keccak256(bytes), so:
    //   encode("a") = keccak256(b"a"), encode("b") = keccak256(b"b")
    let source_encoded = if is_mainnet {
        keccak256(b"a")
    } else {
        keccak256(b"b")
    };

    // hashStruct(Agent) = keccak256(type_hash || encode(source) || connectionId)
    let type_hash = agent_type_hash();
    let mut struct_buf = Vec::with_capacity(3 * 32);
    struct_buf.extend_from_slice(&type_hash);
    struct_buf.extend_from_slice(&source_encoded);
    struct_buf.extend_from_slice(&connection_id);
    let struct_hash = keccak256(&struct_buf);

    // EIP-712 final digest: keccak256("\x19\x01" || domainSeparator || structHash)
    let domain_sep = hl_domain_separator();
    let mut final_buf = Vec::with_capacity(2 + 32 + 32);
    final_buf.push(0x19);
    final_buf.push(0x01);
    final_buf.extend_from_slice(&domain_sep);
    final_buf.extend_from_slice(&struct_hash);
    let digest = keccak256(&final_buf);

    let sig_bytes = sign_digest(key, &digest)?;

    // Split into r, s, v
    let r = format!("0x{}", hex::encode(&sig_bytes[0..32]));
    let s = format!("0x{}", hex::encode(&sig_bytes[32..64]));
    let v = sig_bytes[64] as u64;

    Ok(serde_json::json!({
        "r": r,
        "s": s,
        "v": v
    }))
}

// -- HyperliquidExchange ------------------------------------------------------

pub struct HyperliquidExchange {
    api_url: String,
    client: reqwest::Client,
    runtime: Arc<tokio::runtime::Runtime>,
    signing_key: SigningKey,
    wallet_address: [u8; 20],
    is_mainnet: bool,
    /// coin symbol -> asset index
    coin_to_index: Mutex<HashMap<String, u32>>,
    /// asset index -> coin symbol
    index_to_coin: Mutex<HashMap<u32, String>>,
    fills: Mutex<Vec<Fill>>,
    next_fill_id: Mutex<u64>,
    /// order_id -> market_id for cancel routing
    order_market: Mutex<HashMap<String, String>>,
    /// Tracks open order IDs per market (shared OrderTracker).
    open_orders: Mutex<OrderTracker>,
    /// Deduplicates fill IDs with FIFO eviction (shared FillDedup).
    fill_dedup: Mutex<FillDedup>,
    /// Maximum fill timestamp seen so far (for filtering already-processed fills).
    last_fill_ts: Mutex<f64>,
    /// Optional vault address for sub-account trading.
    vault_address: Option<[u8; 20]>,
    /// Whether metadata has been loaded.
    meta_loaded: Mutex<bool>,
}

impl HyperliquidExchange {
    pub fn new(
        private_key: String,
        testnet: bool,
        api_url: Option<String>,
        vault_address: Option<String>,
        runtime: Arc<tokio::runtime::Runtime>,
    ) -> Result<Self, HorizonError> {
        let signing_key = parse_private_key(&private_key)?;
        let wallet_address = derive_address(&signing_key);

        let is_mainnet = !testnet;
        let default_url = if testnet { TESTNET_URL } else { MAINNET_URL };
        let api_url = api_url.unwrap_or_else(|| default_url.to_string());

        let vault_addr = match vault_address {
            Some(ref va) if !va.is_empty() => {
                let clean = va.strip_prefix("0x").unwrap_or(va);
                let bytes = hex::decode(clean).map_err(|e| {
                    HorizonError::Exchange(format!(
                        "hyperliquid: invalid vault address hex: {}",
                        e
                    ))
                })?;
                if bytes.len() != 20 {
                    return Err(HorizonError::Exchange(format!(
                        "hyperliquid: vault address must be 20 bytes, got {}",
                        bytes.len()
                    )));
                }
                let mut addr = [0u8; 20];
                addr.copy_from_slice(&bytes);
                Some(addr)
            }
            _ => None,
        };

        info!(
            address = %format!("0x{}", hex::encode(wallet_address)),
            mainnet = is_mainnet,
            url = %api_url,
            "hyperliquid: loaded signing key"
        );

        Ok(Self {
            api_url,
            client: reqwest::Client::builder()
                .timeout(std::time::Duration::from_secs(10))
                .connect_timeout(std::time::Duration::from_secs(5))
                .build()
                .unwrap_or_else(|_| reqwest::Client::new()),
            runtime,
            signing_key,
            wallet_address,
            is_mainnet,
            coin_to_index: Mutex::new(HashMap::new()),
            index_to_coin: Mutex::new(HashMap::new()),
            fills: Mutex::new(Vec::new()),
            next_fill_id: Mutex::new(1),
            order_market: Mutex::new(HashMap::new()),
            open_orders: Mutex::new(OrderTracker::new("hyperliquid")),
            fill_dedup: Mutex::new(FillDedup::new()),
            last_fill_ts: Mutex::new(0.0),
            vault_address: vault_addr,
            meta_loaded: Mutex::new(false),
        })
    }

    /// POST /info helper.
    async fn info_request(
        &self,
        body: serde_json::Value,
    ) -> Result<serde_json::Value, HorizonError> {
        let url = format!("{}/info", self.api_url);
        let resp = self
            .client
            .post(&url)
            .json(&body)
            .send()
            .await
            .map_err(|e| HorizonError::Exchange(format!("hyperliquid info request failed: {}", e)))?;

        if !resp.status().is_success() {
            let status = resp.status();
            let text = resp.text().await.unwrap_or_default();
            return Err(HorizonError::Exchange(format!(
                "hyperliquid info request failed ({}): {}",
                status, text
            )));
        }

        resp.json().await.map_err(|e| {
            HorizonError::Exchange(format!("hyperliquid info parse error: {}", e))
        })
    }

    /// POST /exchange helper with EIP-712 signed action.
    async fn exchange_request(
        &self,
        action: serde_json::Value,
        nonce: u64,
    ) -> Result<serde_json::Value, HorizonError> {
        let url = format!("{}/exchange", self.api_url);

        // Serialize the action to msgpack for signing
        let action_bytes = rmp_serde::to_vec(&action).map_err(|e| {
            HorizonError::Exchange(format!("hyperliquid: msgpack serialize failed: {}", e))
        })?;

        let signature = sign_action(
            &self.signing_key,
            &action_bytes,
            nonce,
            self.vault_address.as_ref(),
            self.is_mainnet,
        )?;

        let mut body = serde_json::json!({
            "action": action,
            "nonce": nonce,
            "signature": signature,
        });

        // Add vaultAddress if trading via a vault
        if let Some(ref va) = self.vault_address {
            body["vaultAddress"] = serde_json::Value::String(format!("0x{}", hex::encode(va)));
        }

        let resp = self
            .client
            .post(&url)
            .json(&body)
            .send()
            .await
            .map_err(|e| {
                HorizonError::Exchange(format!("hyperliquid exchange request failed: {}", e))
            })?;

        if !resp.status().is_success() {
            let status = resp.status();
            let text = resp.text().await.unwrap_or_default();
            return Err(HorizonError::Exchange(format!(
                "hyperliquid exchange request failed ({}): {}",
                status, text
            )));
        }

        resp.json().await.map_err(|e| {
            HorizonError::Exchange(format!("hyperliquid exchange parse error: {}", e))
        })
    }

    /// Load perp + spot metadata to build coin↔index maps.
    async fn load_metadata_async(&self) -> Result<(), HorizonError> {
        {
            let loaded = self.meta_loaded.lock().unwrap_or_else(|e| e.into_inner());
            if *loaded {
                return Ok(());
            }
        }

        // Perp metadata
        let perp_meta = self
            .info_request(serde_json::json!({"type": "meta"}))
            .await?;

        if let Some(universe) = perp_meta.get("universe").and_then(|v| v.as_array()) {
            let mut c2i = self.coin_to_index.lock().unwrap_or_else(|e| e.into_inner());
            let mut i2c = self.index_to_coin.lock().unwrap_or_else(|e| e.into_inner());
            for (idx, asset) in universe.iter().enumerate() {
                if let Some(name) = asset.get("name").and_then(|v| v.as_str()) {
                    let index = idx as u32;
                    c2i.insert(name.to_string(), index);
                    i2c.insert(index, name.to_string());
                }
            }
            info!(count = universe.len(), "hyperliquid: loaded perp metadata");
        }

        // Spot metadata
        match self
            .info_request(serde_json::json!({"type": "spotMeta"}))
            .await
        {
            Ok(spot_meta) => {
                if let Some(universe) = spot_meta.get("universe").and_then(|v| v.as_array()) {
                    let mut c2i =
                        self.coin_to_index.lock().unwrap_or_else(|e| e.into_inner());
                    let mut i2c =
                        self.index_to_coin.lock().unwrap_or_else(|e| e.into_inner());
                    for asset in universe {
                        if let (Some(name), Some(index)) = (
                            asset.get("name").and_then(|v| v.as_str()),
                            asset.get("index").and_then(|v| v.as_u64()),
                        ) {
                            // CRITICAL: Spot assets are offset by 10000 in
                            // Hyperliquid's asset ID space (perp 0..N, spot
                            // 10000+N). Without the offset, spot index 0
                            // collides with perp BTC and the wrong market is
                            // hit. Matches hyperliquid-python-sdk:
                            // info.py: asset = spot_info["index"] + 10000
                            let idx = (index as u32) + 10000;
                            c2i.insert(name.to_string(), idx);
                            i2c.insert(idx, name.to_string());
                        }
                    }
                    info!(
                        count = universe.len(),
                        "hyperliquid: loaded spot metadata"
                    );
                }
            }
            Err(e) => {
                debug!(error = %e, "hyperliquid: spot metadata not available (perps-only mode)");
            }
        }

        *self.meta_loaded.lock().unwrap_or_else(|e| e.into_inner()) = true;
        Ok(())
    }

    /// Resolve a coin symbol to its asset index.
    fn resolve_coin(&self, coin: &str) -> Result<u32, HorizonError> {
        let map = self.coin_to_index.lock().unwrap_or_else(|e| e.into_inner());
        map.get(coin).copied().ok_or_else(|| {
            HorizonError::Exchange(format!(
                "hyperliquid: unknown coin '{}'. Call load_metadata or check symbol.",
                coin
            ))
        })
    }

    /// Get current nonce (timestamp in ms).
    fn current_nonce() -> u64 {
        SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_millis() as u64
    }

    /// Fetch mid prices for all assets.
    async fn fetch_all_mids(&self) -> Result<HashMap<String, f64>, HorizonError> {
        let resp = self
            .info_request(serde_json::json!({"type": "allMids"}))
            .await?;

        let mut mids = HashMap::new();
        if let Some(obj) = resp.as_object() {
            for (key, val) in obj {
                if let Some(price_str) = val.as_str() {
                    if let Ok(price) = price_str.parse::<f64>() {
                        if price.is_finite() && price > 0.0 {
                            mids.insert(key.clone(), price);
                        }
                    }
                }
            }
        }
        Ok(mids)
    }

    /// Submit an order to Hyperliquid.
    async fn submit_order_async(&self, req: &OrderRequest) -> Result<String, HorizonError> {
        self.load_metadata_async().await?;

        if req.size <= 0.0 || !req.size.is_finite() {
            return Err(HorizonError::Exchange(format!(
                "hyperliquid: invalid size: {}",
                req.size
            )));
        }
        if req.price <= 0.0 || !req.price.is_finite() {
            return Err(HorizonError::Exchange(format!(
                "hyperliquid: invalid price: {}",
                req.price
            )));
        }

        let coin = &req.market_id;
        let _asset_index = self.resolve_coin(coin)?;

        let is_buy = req.order_side == OrderSide::Buy;
        let is_market_order = req.order_type == crate::types::OrderType::Market;

        // For market orders: fetch mid and place aggressive limit IOC
        let (limit_price, tif) = if is_market_order {
            let mids = self.fetch_all_mids().await?;
            let mid = mids.get(coin).copied().ok_or_else(|| {
                HorizonError::Exchange(format!(
                    "hyperliquid: no mid price for '{}' (market order)",
                    coin
                ))
            })?;
            let slipped = if is_buy {
                mid * (1.0 + MARKET_ORDER_SLIPPAGE)
            } else {
                mid * (1.0 - MARKET_ORDER_SLIPPAGE)
            };
            (slipped, "Ioc")
        } else {
            // Check TimeInForce to set appropriately
            let tif = match req.time_in_force {
                crate::types::TimeInForce::FAK => "Ioc",
                _ => "Gtc",
            };
            (req.price, tif)
        };

        let nonce = Self::current_nonce();

        // Cloid format: 0x + 32 hex chars = 16 random bytes (NOT a dashed UUID).
        // py SDK Cloid validator: requires 0x prefix + exactly 32 hex chars.
        // A dashed UUID would be rejected by the server.
        let cloid_bytes: [u8; 16] = uuid::Uuid::new_v4().into_bytes();
        let cloid = format!("0x{}", hex::encode(cloid_bytes));

        let order_type_wire = serde_json::json!({"limit": {"tif": tif}});

        // NOTE: field order matters for msgpack hashing on the server side.
        // Python SDK order: a, b, p, s, r, t, c. With serde_json's preserve_order
        // feature enabled in Cargo.toml, this insertion order is preserved.
        // reduce_only is not yet exposed on OrderRequest. Always false for now.
        // TODO: add reduce_only field to OrderRequest for perp position mgmt.
        let order_wire = serde_json::json!({
            "a": _asset_index,
            "b": is_buy,
            "p": float_to_wire(limit_price),
            "s": float_to_wire(req.size),
            "r": false,
            "t": order_type_wire,
            "c": cloid,
        });

        let action = serde_json::json!({
            "type": "order",
            "orders": [order_wire],
            "grouping": "na",
        });

        debug!(
            coin = %coin,
            side = if is_buy { "buy" } else { "sell" },
            price = %float_to_wire(limit_price),
            size = %float_to_wire(req.size),
            tif = tif,
            "hyperliquid: submitting order"
        );

        let resp = self.exchange_request(action, nonce).await?;

        // Parse response: {"status": "ok", "response": {"type": "order", "data": {"statuses": [...]}}}
        // Top-level status only catches request-level failures. Per-order
        // failures are reported INSIDE statuses[0].error even when the
        // top-level status is "ok".
        let status = resp
            .get("status")
            .and_then(|v| v.as_str())
            .unwrap_or("");

        if status != "ok" {
            let err_msg = resp
                .get("response")
                .and_then(|v| v.as_str())
                .map(|s| s.to_string())
                .unwrap_or_else(|| serde_json::to_string(&resp).unwrap_or_default());
            return Err(HorizonError::Exchange(format!(
                "hyperliquid: order rejected (top-level): {}",
                err_msg
            )));
        }

        // Per-order error inside statuses[0].error (rejected for tick size,
        // insufficient margin, post-only cross, etc).
        let status0 = resp.pointer("/response/data/statuses/0");
        if let Some(status0_val) = status0 {
            if let Some(err) = status0_val.get("error").and_then(|v| v.as_str()) {
                return Err(HorizonError::Exchange(format!(
                    "hyperliquid: order rejected: {}",
                    err
                )));
            }
        }

        // Extract oid from response.data.statuses[0]. Do NOT fall back to
        // cloid — if no oid was returned, the order didn't land and we
        // should not pretend to track it.
        let order_id = resp
            .pointer("/response/data/statuses/0/resting/oid")
            .or_else(|| resp.pointer("/response/data/statuses/0/filled/oid"))
            .and_then(|v| v.as_u64())
            .map(|v| v.to_string())
            .ok_or_else(|| {
                HorizonError::Exchange(format!(
                    "hyperliquid: order accepted but no oid in response: {}",
                    resp
                ))
            })?;

        info!(order_id = %order_id, "hyperliquid: order accepted");
        Ok(order_id)
    }

    /// Cancel an order by oid (numeric) or cloid (0x-prefixed hex).
    ///
    /// Hyperliquid has TWO distinct cancel action types:
    ///   - "cancel" with `{a, o}` format for numeric order IDs
    ///   - "cancelByCloid" with `{asset, cloid}` format for client-supplied IDs
    /// Sending a string cloid through the "cancel" action would be a type
    /// error and rejected by the server.
    async fn cancel_order_async(&self, order_id: &str, coin: &str) -> Result<(), HorizonError> {
        self.load_metadata_async().await?;

        let asset_index = self.resolve_coin(coin)?;
        let nonce = Self::current_nonce();

        // Detect cloid format: 0x + 32 hex chars
        let is_cloid = order_id.starts_with("0x")
            && order_id.len() == 34
            && order_id[2..].chars().all(|c| c.is_ascii_hexdigit());

        let action = if is_cloid {
            // cancelByCloid action: note the field names are "asset" and "cloid",
            // NOT "a" and "o" as in the regular cancel action.
            serde_json::json!({
                "type": "cancelByCloid",
                "cancels": [{
                    "asset": asset_index,
                    "cloid": order_id,
                }],
            })
        } else {
            // Standard cancel: oid must be parseable as u64
            let oid = order_id.parse::<u64>().map_err(|_| {
                HorizonError::Exchange(format!(
                    "hyperliquid: order_id '{}' is neither a valid oid (u64) nor a cloid (0x+32hex)",
                    order_id
                ))
            })?;
            serde_json::json!({
                "type": "cancel",
                "cancels": [{
                    "a": asset_index,
                    "o": oid,
                }],
            })
        };

        let resp = self.exchange_request(action, nonce).await?;

        let status = resp
            .get("status")
            .and_then(|v| v.as_str())
            .unwrap_or("");

        if status != "ok" {
            // Log but don't fail — order may already be filled
            debug!(
                order_id = %order_id,
                response = %resp,
                "hyperliquid: cancel may have failed (order possibly already filled)"
            );
        } else {
            debug!(order_id = %order_id, "hyperliquid: order canceled");
        }

        Ok(())
    }

    /// Cancel all tracked orders.
    async fn cancel_all_async(&self) -> Result<usize, HorizonError> {
        let orders: Vec<(String, String)> = {
            let map = self
                .order_market
                .lock()
                .unwrap_or_else(|e| e.into_inner());
            map.iter()
                .map(|(oid, mid)| (oid.clone(), mid.clone()))
                .collect()
        };

        if orders.is_empty() {
            return Ok(0);
        }

        let mut canceled = 0;
        for (oid, coin) in &orders {
            match self.cancel_order_async(oid, coin).await {
                Ok(()) => canceled += 1,
                Err(e) => {
                    debug!(
                        order_id = %oid,
                        error = %e,
                        "hyperliquid: cancel_all: individual cancel failed"
                    );
                }
            }
        }

        info!(count = canceled, "hyperliquid: canceled all orders");
        Ok(canceled)
    }

    /// Poll for user fills.
    async fn poll_fills_async(&self) -> Result<Vec<Fill>, HorizonError> {
        let last_ts = *self
            .last_fill_ts
            .lock()
            .unwrap_or_else(|e| e.into_inner());

        // Use startTime = last_ts (ms) to get only new fills
        let start_time = if last_ts > 0.0 {
            last_ts as u64
        } else {
            // First poll: look back 1 hour
            let now = SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .unwrap_or_default()
                .as_millis() as u64;
            now.saturating_sub(3_600_000)
        };

        let user_addr = format!("0x{}", hex::encode(self.wallet_address));

        let resp = self
            .info_request(serde_json::json!({
                "type": "userFillsByTime",
                "user": user_addr,
                "startTime": start_time,
            }))
            .await?;

        let mut new_fills = Vec::new();
        let mut max_ts = last_ts;

        let fills_arr = resp.as_array();

        if let Some(arr) = fills_arr {
            let mut next_id = self
                .next_fill_id
                .lock()
                .unwrap_or_else(|e| e.into_inner());

            for fill_json in arr {
                let fill_id_raw = fill_json
                    .get("tid")
                    .and_then(|v| v.as_u64())
                    .map(|v| v.to_string())
                    .or_else(|| {
                        fill_json
                            .get("tid")
                            .and_then(|v| v.as_str())
                            .map(|s| s.to_string())
                    })
                    .unwrap_or_else(|| {
                        let id = format!("hl_fill_{}", *next_id);
                        *next_id += 1;
                        id
                    });

                // Dedup via shared FillDedup
                {
                    let mut dedup = self
                        .fill_dedup
                        .lock()
                        .unwrap_or_else(|e| e.into_inner());
                    if !dedup.check_and_insert(&fill_id_raw) {
                        continue;
                    }
                }

                let coin = fill_json
                    .get("coin")
                    .and_then(|v| v.as_str())
                    .unwrap_or("")
                    .to_string();

                let price = fill_json
                    .get("px")
                    .and_then(|v| v.as_str().and_then(|s| s.parse::<f64>().ok()))
                    .unwrap_or(0.0);

                let size = fill_json
                    .get("sz")
                    .and_then(|v| v.as_str().and_then(|s| s.parse::<f64>().ok()))
                    .unwrap_or(0.0);

                let side_str = fill_json
                    .get("side")
                    .and_then(|v| v.as_str())
                    .unwrap_or("B");

                let order_side = if side_str == "B" {
                    OrderSide::Buy
                } else {
                    OrderSide::Sell
                };

                let fee = fill_json
                    .get("fee")
                    .and_then(|v| v.as_str().and_then(|s| s.parse::<f64>().ok()))
                    .unwrap_or(0.0);

                let ts = fill_json
                    .get("time")
                    .and_then(|v| v.as_u64())
                    .map(|v| v as f64)
                    .or_else(|| {
                        fill_json
                            .get("time")
                            .and_then(|v| v.as_str())
                            .map(|s| parse_timestamp_ms(s))
                    })
                    .unwrap_or(0.0);

                let oid = fill_json
                    .get("oid")
                    .and_then(|v| v.as_u64())
                    .map(|v| v.to_string())
                    .or_else(|| {
                        fill_json
                            .get("oid")
                            .and_then(|v| v.as_str())
                            .map(|s| s.to_string())
                    })
                    .unwrap_or_default();

                // Hyperliquid fills carry a "crossed" bool: true = our order
                // crossed the book (we were the taker), false = our resting
                // order was hit (we were the maker). The "liquidation" field
                // is unrelated (it indicates whether the fill came from a
                // liquidation event). Default to taker (false) when missing,
                // which is the safer fee assumption.
                let is_maker = !fill_json
                    .get("crossed")
                    .and_then(|v| v.as_bool())
                    .unwrap_or(true);

                // Validate
                if size <= 0.0 || !size.is_finite() {
                    continue;
                }
                if !price.is_finite() || price <= 0.0 {
                    continue;
                }

                if ts > max_ts {
                    max_ts = ts;
                }

                new_fills.push(Fill {
                    fill_id: fill_id_raw,
                    order_id: oid,
                    market_id: coin,
                    side: Side::Long,
                    order_side,
                    price,
                    size,
                    fee: fee.abs(),
                    timestamp: ts / 1000.0, // Convert ms to seconds
                    token_id: None,
                    exchange: "hyperliquid".to_string(),
                    is_maker,
                    multiplier: 1.0,
                });
            }
        }

        // Update max fill timestamp
        if max_ts > last_ts {
            if let Ok(mut ts_guard) = self.last_fill_ts.lock() {
                *ts_guard = max_ts;
            }
        }

        if !new_fills.is_empty() {
            info!(count = new_fills.len(), "hyperliquid: polled new fills");
        }

        Ok(new_fills)
    }

    /// Fetch open positions from Hyperliquid.
    async fn fetch_positions_async(&self) -> Result<Vec<Position>, HorizonError> {
        let user_addr = format!("0x{}", hex::encode(self.wallet_address));

        let resp = self
            .info_request(serde_json::json!({
                "type": "clearinghouseState",
                "user": user_addr,
            }))
            .await?;

        let mut positions = Vec::new();

        if let Some(asset_positions) = resp
            .get("assetPositions")
            .and_then(|v| v.as_array())
        {
            for pos in asset_positions {
                let position = pos.get("position").unwrap_or(pos);

                let coin = position
                    .get("coin")
                    .and_then(|v| v.as_str())
                    .unwrap_or("")
                    .to_string();

                let szi = position
                    .get("szi")
                    .and_then(|v| v.as_str().and_then(|s| s.parse::<f64>().ok()))
                    .unwrap_or(0.0);

                let entry_px = position
                    .get("entryPx")
                    .and_then(|v| v.as_str().and_then(|s| s.parse::<f64>().ok()))
                    .unwrap_or(0.0);

                let unrealized_pnl = position
                    .get("unrealizedPnl")
                    .and_then(|v| v.as_str().and_then(|s| s.parse::<f64>().ok()))
                    .unwrap_or(0.0);

                if szi.abs() > 1e-10 && szi.is_finite() {
                    // Hyperliquid perps support short positions (szi < 0).
                    // Horizon's Side enum is {Yes, No, Long} — there is no
                    // Short variant. We encode shorts as negative size so
                    // downstream code can detect them via `position.size < 0`,
                    // and we keep side=Long so risk checks still treat the
                    // position as cross-asset (vs prediction market Yes/No).
                    if szi < 0.0 {
                        warn!(
                            coin = %coin,
                            size = szi,
                            "hyperliquid: short position represented as negative size on Side::Long"
                        );
                    }
                    positions.push(Position {
                        market_id: coin,
                        side: Side::Long,
                        size: szi, // signed: negative = short
                        avg_entry_price: entry_px,
                        realized_pnl: 0.0,
                        unrealized_pnl,
                        token_id: None,
                        exchange: "hyperliquid".to_string(),
                        multiplier: 1.0,
                    });
                }
            }
        }

        if !positions.is_empty() {
            info!(
                count = positions.len(),
                "hyperliquid: fetched positions for reconciliation"
            );
        }

        Ok(positions)
    }
}

impl Exchange for HyperliquidExchange {
    fn submit_order(&self, req: &OrderRequest) -> Result<String, HorizonError> {
        let req_clone = req.clone();
        let order_id = self
            .runtime
            .block_on(self.submit_order_async(&req_clone))?;

        // Track order_id per market via shared OrderTracker
        if let Ok(mut tracker) = self.open_orders.lock() {
            tracker.insert(&req.market_id, &order_id);
        }

        // Track order -> market for cancel routing
        if let Ok(mut map) = self.order_market.lock() {
            map.insert(order_id.clone(), req.market_id.clone());
            if map.len() > super::MAX_DEDUP_ENTRIES {
                warn!("hyperliquid: order_market tracking exceeds 10k, clearing stale entries");
                map.clear();
                map.insert(order_id.clone(), req.market_id.clone());
            }
        }

        Ok(order_id)
    }

    fn cancel_order(&self, order_id: &str) -> Result<(), HorizonError> {
        let coin = {
            let map = self
                .order_market
                .lock()
                .unwrap_or_else(|e| e.into_inner());
            map.get(order_id).cloned().unwrap_or_default()
        };

        if coin.is_empty() {
            return Err(HorizonError::Exchange(format!(
                "hyperliquid: unknown order_id '{}' (no market mapping)",
                order_id
            )));
        }

        self.runtime
            .block_on(self.cancel_order_async(order_id, &coin))?;

        // Remove from tracking
        if let Ok(mut tracker) = self.open_orders.lock() {
            tracker.remove(order_id);
        }
        if let Ok(mut map) = self.order_market.lock() {
            map.remove(order_id);
        }

        Ok(())
    }

    fn cancel_all(&self) -> Result<usize, HorizonError> {
        let count = self.runtime.block_on(self.cancel_all_async())?;

        if let Ok(mut tracker) = self.open_orders.lock() {
            tracker.clear();
        }
        if let Ok(mut map) = self.order_market.lock() {
            map.clear();
        }

        Ok(count)
    }

    fn cancel_for_market(&self, market_id: &str) -> Result<usize, HorizonError> {
        let order_ids: Vec<String> = {
            let tracker = self
                .open_orders
                .lock()
                .unwrap_or_else(|e| e.into_inner());
            tracker.get_market_orders(market_id)
        };

        if order_ids.is_empty() {
            return Ok(0);
        }

        let mut successfully_canceled = Vec::new();
        for oid in &order_ids {
            match self
                .runtime
                .block_on(self.cancel_order_async(oid, market_id))
            {
                Ok(()) => successfully_canceled.push(oid.clone()),
                Err(e) => {
                    debug!(
                        order_id = %oid,
                        error = %e,
                        "hyperliquid: cancel_for_market: order cancel failed"
                    );
                }
            }
        }

        // Only remove successfully canceled IDs from tracking
        if let Ok(mut tracker) = self.open_orders.lock() {
            tracker.remove_from_market(market_id, &successfully_canceled);
        }
        // Clean up order_market
        if let Ok(mut map) = self.order_market.lock() {
            for oid in &successfully_canceled {
                map.remove(oid);
            }
        }

        let canceled = successfully_canceled.len();
        info!(
            market_id = %market_id,
            canceled = canceled,
            total = order_ids.len(),
            "hyperliquid: canceled orders for market"
        );
        Ok(canceled)
    }

    fn drain_fills(&self) -> Vec<Fill> {
        match self.runtime.block_on(self.poll_fills_async()) {
            Ok(new_fills) => {
                if !new_fills.is_empty() {
                    // Remove filled order IDs from open_orders tracking
                    if let Ok(mut tracker) = self.open_orders.lock() {
                        let filled_ids: Vec<&str> =
                            new_fills.iter().map(|f| f.order_id.as_str()).collect();
                        tracker.remove_filled(&filled_ids);
                    }

                    if let Ok(mut fills) = self.fills.lock() {
                        fills.extend(new_fills);
                    }
                }
            }
            Err(e) => {
                warn!(error = %e, "hyperliquid: fill polling error");
            }
        }

        match self.fills.lock() {
            Ok(mut fills) => std::mem::take(&mut *fills),
            Err(_) => {
                error!("hyperliquid: fills lock poisoned");
                Vec::new()
            }
        }
    }

    fn name(&self) -> &str {
        "hyperliquid"
    }

    fn fetch_positions(&self) -> Result<Vec<Position>, HorizonError> {
        self.runtime.block_on(self.fetch_positions_async())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_msgpack_preserves_field_order() {
        // CRITICAL test: msgpack key order matters for the connection_id hash.
        // py SDK packs Python dicts in INSERTION order. Horizon must do the
        // same. With serde_json/preserve_order enabled in Cargo.toml, the
        // Value::Object insertion order should be respected through to msgpack.
        let action = serde_json::json!({
            "type": "order",
            "orders": [{
                "a": 4,
                "b": true,
                "p": "1670.1",
                "s": "0.0147",
                "r": false,
                "t": {"limit": {"tif": "Ioc"}},
            }],
            "grouping": "na",
        });
        let bytes = rmp_serde::to_vec(&action).unwrap();
        // msgpack format: 0x83 = fixmap of size 3
        assert_eq!(bytes[0], 0x83, "expected fixmap of 3 entries");
        // Next byte is the first key length+marker. "type" = 4 chars,
        // so we expect 0xa4 (fixstr len=4) followed by "type" bytes.
        // If preserve_order is broken, we'd see 0xa8 (fixstr len=8) for "grouping".
        assert_eq!(bytes[1], 0xa4, "expected first key to start with 0xa4 (str len=4 = 'type'). \
                                     If this is 0xa8 then preserve_order is NOT working and \
                                     msgpack will alphabetize keys, breaking Hyperliquid signing.");
        let first_key = std::str::from_utf8(&bytes[2..6]).unwrap();
        assert_eq!(first_key, "type", "first key must be 'type' to match Python SDK");
    }

    #[test]
    fn test_float_to_wire_zero() {
        assert_eq!(float_to_wire(0.0), "0");
    }

    #[test]
    fn test_float_to_wire_negative_zero() {
        assert_eq!(float_to_wire(-0.0), "0");
    }

    #[test]
    fn test_float_to_wire_integer() {
        assert_eq!(float_to_wire(100.0), "100");
        assert_eq!(float_to_wire(12345.0), "12345");
    }

    #[test]
    fn test_float_to_wire_decimals() {
        assert_eq!(float_to_wire(0.001), "0.001");
        assert_eq!(float_to_wire(1.5), "1.5");
    }

    #[test]
    fn test_float_to_wire_precision() {
        // 8 decimal places, trailing zeros stripped
        let result = float_to_wire(123.456789);
        assert_eq!(result, "123.456789");
    }

    #[test]
    fn test_float_to_wire_trailing_zeros() {
        assert_eq!(float_to_wire(1.10000000), "1.1");
        assert_eq!(float_to_wire(0.00100000), "0.001");
    }

    #[test]
    fn test_float_to_wire_large() {
        assert_eq!(float_to_wire(50000.0), "50000");
    }

    // Crypto helper tests (parse_private_key, derive_address) now live in crypto_utils::tests

    #[test]
    fn test_domain_separator_deterministic() {
        let ds1 = hl_domain_separator();
        let ds2 = hl_domain_separator();
        assert_eq!(ds1, ds2);
    }

    #[test]
    fn test_connection_id_no_vault() {
        let action_bytes = b"test";
        let nonce = 1234u64;
        let cid = build_connection_id(action_bytes, nonce, None);
        // Should be deterministic
        let cid2 = build_connection_id(action_bytes, nonce, None);
        assert_eq!(cid, cid2);
    }

    #[test]
    fn test_connection_id_with_vault() {
        let action_bytes = b"test";
        let nonce = 1234u64;
        let vault = [0xabu8; 20];
        let cid_vault = build_connection_id(action_bytes, nonce, Some(&vault));
        let cid_no_vault = build_connection_id(action_bytes, nonce, None);
        assert_ne!(cid_vault, cid_no_vault);
    }
}
