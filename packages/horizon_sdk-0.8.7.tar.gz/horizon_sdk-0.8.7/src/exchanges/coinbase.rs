//! Coinbase Advanced Trade REST exchange client.
//!
//! Implements the Exchange trait for Coinbase's Advanced Trade API.
//! Uses ES256 JWT bearer authentication (the modern Cloud Developer Platform
//! key format). Each request signs an ES256 JWT with claims:
//!   - sub: key id
//!   - iss: "cdp"
//!   - nbf: current time
//!   - exp: nbf + 120s
//!   - uri: "{METHOD} api.coinbase.com{path}" (no scheme, no body)
//! plus header `kid` (key id) and `nonce` (random hex).
//!
//! The legacy HMAC-SHA256 + CB-ACCESS-KEY/SIGN/TIMESTAMP scheme was for
//! Coinbase Exchange (Pro), a different product. Advanced Trade requires
//! ES256 JWT and rejects HMAC. See:
//! https://docs.cdp.coinbase.com/advanced-trade/docs/auth

use crate::error::HorizonError;
use crate::exchanges::fill_dedup::FillDedup;
use crate::exchanges::order_tracker::OrderTracker;
use crate::exchanges::Exchange;
use crate::types::{Fill, OrderRequest, OrderSide, OrderType, Position, Side, TimeInForce};
use base64::Engine as _;
use p256::ecdsa::{signature::Signer, Signature as P256Signature, SigningKey as P256SigningKey};
use p256::pkcs8::DecodePrivateKey;
use std::sync::{Arc, Mutex};
use std::time::{SystemTime, UNIX_EPOCH};
use tracing::{debug, error, info, warn};
use zeroize::Zeroizing;

const API_URL: &str = "https://api.coinbase.com/api/v3/brokerage";
/// Host portion of the URI claim in the JWT (no scheme).
const JWT_HOST: &str = "api.coinbase.com";

/// Parse an ISO 8601 timestamp string (e.g., "2024-01-15T10:30:00Z") to Unix epoch f64.
/// Falls back to direct f64 parse (for numeric timestamps), then to 0.0 on failure.
fn parse_iso_timestamp(s: &str) -> f64 {
    // Try numeric first
    if let Ok(v) = s.parse::<f64>() {
        return v;
    }
    let s = s.trim();
    let s = if s.ends_with('Z') {
        &s[..s.len() - 1]
    } else if s.len() > 6 {
        // Check for +HH:MM or -HH:MM suffix
        let tail = &s[s.len() - 6..];
        if (tail.starts_with('+') || tail.starts_with('-'))
            && tail.as_bytes()[3] == b':'
        {
            &s[..s.len() - 6]
        } else {
            s
        }
    } else {
        s
    };

    let (date_part, time_part) = match s.split_once('T') {
        Some(parts) => parts,
        None => return 0.0,
    };
    let mut date_iter = date_part.split('-');
    let year: i64 = match date_iter.next().and_then(|v| v.parse().ok()) {
        Some(v) => v,
        None => return 0.0,
    };
    let month: i64 = match date_iter.next().and_then(|v| v.parse().ok()) {
        Some(v) => v,
        None => return 0.0,
    };
    let day: i64 = match date_iter.next().and_then(|v| v.parse().ok()) {
        Some(v) => v,
        None => return 0.0,
    };

    let (time_whole, frac) = if let Some((w, f)) = time_part.split_once('.') {
        let frac_secs: f64 = format!("0.{}", f).parse().unwrap_or(0.0);
        (w, frac_secs)
    } else {
        (time_part, 0.0)
    };

    let mut time_iter = time_whole.split(':');
    let hour: i64 = time_iter.next().and_then(|v| v.parse().ok()).unwrap_or(0);
    let min: i64 = time_iter.next().and_then(|v| v.parse().ok()).unwrap_or(0);
    let sec: i64 = time_iter.next().and_then(|v| v.parse().ok()).unwrap_or(0);

    if month < 1 || month > 12 || day < 1 || day > 31 {
        return 0.0;
    }
    if hour > 23 || min > 59 || sec > 59 {
        return 0.0;
    }

    let is_leap = |y: i64| (y % 4 == 0 && y % 100 != 0) || y % 400 == 0;
    let mut days: i64 = 0;
    for y in 1970..year {
        days += if is_leap(y) { 366 } else { 365 };
    }
    let month_days = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    for m in 1..month {
        days += month_days[m as usize];
        if m == 2 && is_leap(year) {
            days += 1;
        }
    }
    days += day - 1;

    let total_secs = days * 86400 + hour * 3600 + min * 60 + sec;
    total_secs as f64 + frac
}

/// Validate that a URL path parameter contains only safe characters.
fn validate_url_param(param: &str, name: &str) -> Result<(), HorizonError> {
    if param.is_empty() {
        return Err(HorizonError::Exchange(format!(
            "coinbase: {} is empty",
            name
        )));
    }
    if !param
        .bytes()
        .all(|b| b.is_ascii_alphanumeric() || b == b'-' || b == b'_')
    {
        return Err(HorizonError::Exchange(format!(
            "coinbase: invalid characters in {}",
            name
        )));
    }
    Ok(())
}

/// URL-encode a query parameter value to prevent injection.
/// Only allows alphanumeric, '-', '_', '.', '~' through unencoded (RFC 3986 unreserved).
/// Everything else is percent-encoded.
fn url_encode_query_value(value: &str) -> String {
    let mut encoded = String::with_capacity(value.len());
    for byte in value.bytes() {
        match byte {
            b'A'..=b'Z' | b'a'..=b'z' | b'0'..=b'9' | b'-' | b'_' | b'.' | b'~' => {
                encoded.push(byte as char);
            }
            _ => {
                encoded.push_str(&format!("%{:02X}", byte));
            }
        }
    }
    encoded
}

pub struct CoinbaseExchange {
    api_url: String,
    api_key: Zeroizing<String>,
    api_secret: Zeroizing<String>,
    client: reqwest::Client,
    runtime: Arc<tokio::runtime::Runtime>,
    fills: Mutex<Vec<Fill>>,
    next_fill_id: Mutex<u64>,
    last_fill_cursor: Mutex<Option<String>>,
    /// Tracks open order IDs per market (shared OrderTracker).
    open_orders: Mutex<OrderTracker>,
    /// Deduplicates fill IDs with FIFO eviction (shared FillDedup).
    fill_dedup: Mutex<FillDedup>,
}

impl CoinbaseExchange {
    pub fn new(
        api_key: String,
        api_secret: String,
        api_url: Option<String>,
        runtime: Arc<tokio::runtime::Runtime>,
    ) -> Self {
        Self {
            api_url: api_url.unwrap_or_else(|| API_URL.to_string()),
            api_key: Zeroizing::new(api_key),
            api_secret: Zeroizing::new(api_secret),
            client: reqwest::Client::builder()
                .timeout(std::time::Duration::from_secs(10))
                .connect_timeout(std::time::Duration::from_secs(5))
                .build()
                .unwrap_or_else(|_| reqwest::Client::new()),
            runtime,
            fills: Mutex::new(Vec::new()),
            next_fill_id: Mutex::new(1),
            last_fill_cursor: Mutex::new(None),
            open_orders: Mutex::new(OrderTracker::new("coinbase")),
            fill_dedup: Mutex::new(FillDedup::new()),
        }
    }

    /// Build an ES256 JWT for the given HTTP method + path.
    ///
    /// Matches coinbase-advanced-py's `jwt_generator.build_rest_jwt`:
    /// - URI claim: "{METHOD} api.coinbase.com{path}"  (no scheme)
    /// - Claims: sub=key_id, iss="cdp", nbf=now, exp=now+120
    /// - Header: kid=key_id, nonce=random hex (CUSTOM HEADER FIELD)
    /// - Algorithm: ES256 (ECDSA P-256 SHA-256)
    ///
    /// `api_secret` MUST be a PEM-encoded EC P-256 private key:
    ///   -----BEGIN EC PRIVATE KEY-----
    ///   ...
    ///   -----END EC PRIVATE KEY-----
    ///
    /// We build the JWT manually because the `jsonwebtoken` crate doesn't
    /// support custom JWT header fields (it only supports the JWS standard
    /// fields), and Coinbase requires a custom `nonce` header per request.
    fn build_jwt(&self, method: &str, path: &str) -> Result<String, HorizonError> {
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map(|d| d.as_secs())
            .unwrap_or(0);

        // Build header JSON with custom nonce field.
        // Field order matches coinbase-advanced-py for byte-stable output.
        let nonce_bytes: [u8; 16] = rand::random();
        let header_json = serde_json::json!({
            "typ": "JWT",
            "alg": "ES256",
            "kid": &*self.api_key,
            "nonce": hex::encode(nonce_bytes),
        });

        let claims_json = serde_json::json!({
            "sub": &*self.api_key,
            "iss": "cdp",
            "nbf": now,
            "exp": now + 120,
            "uri": format!("{} {}{}", method, JWT_HOST, path),
        });

        let header_b64 = base64::engine::general_purpose::URL_SAFE_NO_PAD
            .encode(serde_json::to_vec(&header_json).map_err(|e| {
                HorizonError::Exchange(format!("coinbase: JWT header serialize failed: {}", e))
            })?);
        let claims_b64 = base64::engine::general_purpose::URL_SAFE_NO_PAD
            .encode(serde_json::to_vec(&claims_json).map_err(|e| {
                HorizonError::Exchange(format!("coinbase: JWT claims serialize failed: {}", e))
            })?);
        let signing_input = format!("{}.{}", header_b64, claims_b64);

        // Parse PEM EC P-256 private key. Coinbase keys are in PKCS#8 format
        // (BEGIN PRIVATE KEY) by default; some are in SEC1 EC format
        // (BEGIN EC PRIVATE KEY).
        let key = P256SigningKey::from_pkcs8_pem(&self.api_secret).map_err(|e| {
            HorizonError::Exchange(format!(
                "coinbase: failed to parse EC P-256 PEM private key — Coinbase Advanced \
                 Trade requires an ES256 P-256 key from cloud.coinbase.com/access/api, \
                 NOT a legacy HMAC secret: {}",
                e
            ))
        })?;

        // Sign and encode signature as P1363 (r||s, 64 bytes), which is the
        // JWS-required format. p256's Signer<Signature> output IS already
        // in fixed-size r||s format.
        let signature: P256Signature = key.sign(signing_input.as_bytes());
        let sig_bytes = signature.to_bytes();
        let sig_b64 = base64::engine::general_purpose::URL_SAFE_NO_PAD.encode(sig_bytes);

        Ok(format!("{}.{}", signing_input, sig_b64))
    }

    /// Add Coinbase Bearer JWT auth header to a request builder.
    fn auth_headers(
        &self,
        builder: reqwest::RequestBuilder,
        method: &str,
        path: &str,
        _body: &str, // unused — JWT doesn't sign the body
    ) -> Result<reqwest::RequestBuilder, HorizonError> {
        let jwt = self.build_jwt(method, path)?;
        Ok(builder
            .header("Authorization", format!("Bearer {}", jwt))
            .header("Content-Type", "application/json"))
    }

    /// Submit order to Coinbase with retry on 429.
    async fn submit_order_async(&self, req: &OrderRequest) -> Result<String, HorizonError> {
        let path = "/api/v3/brokerage/orders";
        let url = format!("{}/orders", self.api_url);

        if req.size <= 0.0 || req.size.is_nan() || req.size.is_infinite() {
            return Err(HorizonError::Exchange(format!(
                "invalid size for Coinbase: {}",
                req.size
            )));
        }

        // Market orders don't need a valid price; limit orders do
        let is_market = matches!(req.order_type, OrderType::Market);
        if !is_market && (req.price <= 0.0 || req.price.is_nan() || req.price.is_infinite()) {
            return Err(HorizonError::Exchange(format!(
                "invalid price for Coinbase limit order: {}",
                req.price
            )));
        }

        let side_str = match req.order_side {
            OrderSide::Buy => "BUY",
            OrderSide::Sell => "SELL",
        };

        let client_order_id = uuid::Uuid::new_v4().to_string();

        // Build order_configuration based on order_type and time_in_force.
        // Coinbase Advanced Trade uses separate config keys:
        //   market_market_ioc  — market order (IOC semantics)
        //   limit_limit_gtc    — limit GTC
        //   limit_limit_fok    — limit FOK
        //   limit_limit_gtd    — limit GTD (not used here)
        // FAK (IOC) for limit orders uses limit_limit_gtc with post_only=false
        // since Coinbase doesn't have a dedicated IOC limit config; we approximate
        // by using the GTC config (exchange will fill what it can immediately).
        let order_configuration = if is_market {
            // Market orders use base_size for buy, quote_size for sell in Coinbase,
            // but base_size works for both directions in practice.
            serde_json::json!({
                "market_market_ioc": {
                    "base_size": format!("{}", req.size),
                }
            })
        } else {
            match req.time_in_force {
                TimeInForce::FOK => {
                    serde_json::json!({
                        "limit_limit_fok": {
                            "base_size": format!("{}", req.size),
                            "limit_price": format!("{:.2}", req.price),
                        }
                    })
                }
                // GTC, GTD, and FAK (IOC approximation) all use limit_limit_gtc.
                // Coinbase doesn't have a native IOC limit; GTC is the closest
                // (the engine's cancel-before-requote handles the rest).
                _ => {
                    serde_json::json!({
                        "limit_limit_gtc": {
                            "base_size": format!("{}", req.size),
                            "limit_price": format!("{:.2}", req.price),
                        }
                    })
                }
            }
        };

        let body = serde_json::json!({
            "client_order_id": client_order_id,
            "product_id": req.market_id,
            "side": side_str,
            "order_configuration": order_configuration,
        });

        let body_str = body.to_string();

        debug!(
            product_id = %req.market_id,
            side = side_str,
            price = req.price,
            size = req.size,
            "coinbase: submitting order"
        );

        let mut backoff_ms: u64 = 1000;

        for attempt in 0..5u32 {
            let builder = self.client.post(&url).body(body_str.clone());
            let resp = self
                .auth_headers(builder, "POST", path, &body_str)?
                .send()
                .await
                .map_err(|e| HorizonError::Exchange(format!("coinbase order failed for {}: {}", req.market_id, e)))?;

            let status_code = resp.status().as_u16();

            if status_code == 429 && attempt < 4 {
                warn!(
                    attempt = attempt + 1,
                    backoff_ms = backoff_ms,
                    "coinbase: rate limited (429), retrying"
                );
                tokio::time::sleep(tokio::time::Duration::from_millis(backoff_ms)).await;
                backoff_ms = (backoff_ms * 2).min(30_000);
                continue;
            }

            if status_code == 403 {
                let resp_body = resp.text().await.unwrap_or_default();
                return Err(HorizonError::Exchange(format!(
                    "coinbase: forbidden (403) -- check API key permissions: {}",
                    resp_body
                )));
            }

            if !resp.status().is_success() {
                let status = resp.status();
                let resp_body = resp.text().await.unwrap_or_default();
                error!(status = %status, body = %resp_body, "coinbase: order rejected");
                return Err(HorizonError::Exchange(format!(
                    "coinbase order rejected ({}): {}",
                    status, resp_body
                )));
            }

            let json: serde_json::Value = resp
                .json()
                .await
                .map_err(|e| HorizonError::Exchange(format!("coinbase parse error: {}", e)))?;

            // Coinbase returns {"success": true, "order_id": "...", ...}
            let order_id = json
                .get("order_id")
                .and_then(|v| v.as_str())
                .filter(|s| !s.is_empty())
                .or_else(|| {
                    json.get("success_response")
                        .and_then(|r| r.get("order_id"))
                        .and_then(|v| v.as_str())
                        .filter(|s| !s.is_empty())
                })
                .map(|s| s.to_string())
                .ok_or_else(|| {
                    HorizonError::Exchange(format!(
                        "coinbase: response missing order_id: {}",
                        json
                    ))
                })?;

            info!(order_id = %order_id, "coinbase: order accepted");
            return Ok(order_id);
        }

        Err(HorizonError::Exchange(format!(
            "coinbase: retry attempts exhausted for {}",
            req.market_id
        )))
    }

    /// Cancel order on Coinbase via batch cancel endpoint.
    async fn cancel_order_async(&self, order_id: &str) -> Result<(), HorizonError> {
        validate_url_param(order_id, "order_id")?;
        let path = "/api/v3/brokerage/orders/batch_cancel";
        let url = format!("{}/orders/batch_cancel", self.api_url);

        let body = serde_json::json!({
            "order_ids": [order_id]
        });
        let body_str = body.to_string();

        let builder = self.client.post(&url).body(body_str.clone());
        let resp = self
            .auth_headers(builder, "POST", path, &body_str)?
            .send()
            .await
            .map_err(|e| HorizonError::Exchange(format!("coinbase cancel failed for order {}: {}", order_id, e)))?;

        if !resp.status().is_success() {
            let status = resp.status();
            let resp_body = resp.text().await.unwrap_or_default();
            // Treat 404 / not-found as already canceled/filled
            if status.as_u16() == 404 {
                debug!(order_id = %order_id, "coinbase: order not found (may be filled)");
                return Ok(());
            }
            return Err(HorizonError::Exchange(format!(
                "coinbase cancel failed ({}): {}",
                status, resp_body
            )));
        }

        debug!(order_id = %order_id, "coinbase: order canceled");
        Ok(())
    }

    /// Cancel all orders on Coinbase.
    /// Lists open orders first, then batch-cancels them.
    async fn cancel_all_async(&self) -> Result<usize, HorizonError> {
        // First, list all open orders
        // Endpoint is /orders/historical/batch — without /batch the URL
        // either 404s or is interpreted as an order_id lookup (which would
        // make cancel_all silently no-op).
        let list_path = "/api/v3/brokerage/orders/historical/batch?order_status=OPEN&limit=100";
        let list_url = format!(
            "{}/orders/historical/batch?order_status=OPEN&limit=100",
            self.api_url
        );

        let builder = self.client.get(&list_url);
        let resp = self
            .auth_headers(builder, "GET", list_path, "")?
            .send()
            .await
            .map_err(|e| {
                HorizonError::Exchange(format!("coinbase cancel-all list failed: {}", e))
            })?;

        if !resp.status().is_success() {
            let status = resp.status();
            let body = resp.text().await.unwrap_or_default();
            return Err(HorizonError::Exchange(format!(
                "coinbase cancel-all list failed ({}): {}",
                status, body
            )));
        }

        let json: serde_json::Value = resp.json().await.unwrap_or_else(|e| {
            warn!(error = %e, "coinbase: cancel-all response parse failed");
            serde_json::Value::Null
        });
        let order_ids: Vec<String> = json
            .get("orders")
            .and_then(|v| v.as_array())
            .map(|arr| {
                arr.iter()
                    .filter_map(|o| o.get("order_id").and_then(|v| v.as_str()).map(String::from))
                    .collect()
            })
            .unwrap_or_default();

        if order_ids.is_empty() {
            info!("coinbase: no open orders to cancel");
            return Ok(0);
        }

        // Batch cancel all collected order IDs
        let cancel_path = "/api/v3/brokerage/orders/batch_cancel";
        let cancel_url = format!("{}/orders/batch_cancel", self.api_url);
        let cancel_body = serde_json::json!({ "order_ids": order_ids });
        let cancel_body_str = cancel_body.to_string();

        let builder = self.client.post(&cancel_url).body(cancel_body_str.clone());
        let resp = self
            .auth_headers(builder, "POST", cancel_path, &cancel_body_str)?
            .send()
            .await
            .map_err(|e| {
                HorizonError::Exchange(format!("coinbase cancel-all batch failed: {}", e))
            })?;

        if !resp.status().is_success() {
            let status = resp.status();
            let body = resp.text().await.unwrap_or_default();
            return Err(HorizonError::Exchange(format!(
                "coinbase cancel-all batch failed ({}): {}",
                status, body
            )));
        }

        let count = order_ids.len();
        info!(count = count, "coinbase: canceled all orders");
        Ok(count)
    }

    /// Poll for fills from Coinbase.
    async fn poll_fills_async(&self) -> Result<Vec<Fill>, HorizonError> {
        let mut path =
            "/api/v3/brokerage/orders/historical/fills?limit=100".to_string();
        let mut url = format!(
            "{}/orders/historical/fills?limit=100",
            self.api_url
        );

        // Add cursor for incremental polling (URL-encoded to prevent injection)
        if let Ok(cursor) = self.last_fill_cursor.lock() {
            if let Some(ref c) = *cursor {
                let encoded = url_encode_query_value(c);
                path = format!("{}&cursor={}", path, encoded);
                url = format!("{}&cursor={}", url, encoded);
            }
        }

        let builder = self.client.get(&url);
        let resp = self
            .auth_headers(builder, "GET", &path, "")?
            .send()
            .await
            .map_err(|e| HorizonError::Exchange(format!("coinbase: fill poll failed: {}", e)))?;

        if !resp.status().is_success() {
            let status = resp.status();
            debug!(status = %status, "coinbase: fill poll returned non-200");
            return Ok(Vec::new());
        }

        let json: serde_json::Value = resp.json().await.map_err(|e| {
            HorizonError::Exchange(format!("coinbase: fill parse error: {}", e))
        })?;

        // Update cursor for next poll
        if let Some(cursor) = json.get("cursor").and_then(|v| v.as_str()) {
            if !cursor.is_empty() {
                if let Ok(mut last_cursor) = self.last_fill_cursor.lock() {
                    *last_cursor = Some(cursor.to_string());
                }
            }
        }

        let mut new_fills = Vec::new();

        if let Some(fills_arr) = json.get("fills").and_then(|v| v.as_array()) {
            let mut next_id = self.next_fill_id.lock().unwrap_or_else(|e| e.into_inner());

            for fill_json in fills_arr {
                let trade_id = fill_json
                    .get("trade_id")
                    .and_then(|v| v.as_str())
                    .unwrap_or("")
                    .to_string();

                let order_id = fill_json
                    .get("order_id")
                    .and_then(|v| v.as_str())
                    .unwrap_or("")
                    .to_string();

                let product_id = fill_json
                    .get("product_id")
                    .and_then(|v| v.as_str())
                    .unwrap_or("")
                    .to_string();

                let size = fill_json
                    .get("size")
                    .and_then(|v| {
                        v.as_str()
                            .and_then(|s| s.parse::<f64>().ok())
                            .or_else(|| v.as_f64())
                    })
                    .unwrap_or(0.0);

                let price = fill_json
                    .get("price")
                    .and_then(|v| {
                        v.as_str()
                            .and_then(|s| s.parse::<f64>().ok())
                            .or_else(|| v.as_f64())
                    })
                    .unwrap_or(0.0);

                let commission = fill_json
                    .get("commission")
                    .and_then(|v| {
                        v.as_str()
                            .and_then(|s| s.parse::<f64>().ok())
                            .or_else(|| v.as_f64())
                    })
                    .unwrap_or(0.0);

                let side_str = fill_json
                    .get("side")
                    .and_then(|v| v.as_str())
                    .unwrap_or("BUY");

                let order_side = if side_str.eq_ignore_ascii_case("BUY") {
                    OrderSide::Buy
                } else {
                    OrderSide::Sell
                };

                let ts = fill_json
                    .get("trade_time")
                    .and_then(|v| v.as_str())
                    .map(parse_iso_timestamp)
                    .unwrap_or(0.0);

                // Reject NaN/Inf
                if !price.is_finite() || !size.is_finite() || price <= 0.0 || size <= 0.0 {
                    continue;
                }

                let fill_id = if trade_id.is_empty() {
                    let id = format!("coinbase_fill_{}", *next_id);
                    *next_id += 1;
                    id
                } else {
                    trade_id.clone()
                };

                // Dedup via shared FillDedup
                {
                    let mut dedup = self.fill_dedup.lock().unwrap_or_else(|e| e.into_inner());
                    if !dedup.check_and_insert(&fill_id) {
                        continue;
                    }
                }

                new_fills.push(Fill {
                    fill_id,
                    order_id,
                    market_id: product_id,
                    side: Side::Long, // Long side for non-prediction instruments
                    order_side,
                    price,
                    size,
                    fee: commission,
                    timestamp: ts,
                    token_id: None,
                    exchange: "coinbase".to_string(),
                    is_maker: false,
                    multiplier: 1.0,
                });
            }
        }

        if !new_fills.is_empty() {
            info!(count = new_fills.len(), "coinbase: polled new fills");
        }

        Ok(new_fills)
    }

    /// Fetch positions from Coinbase accounts for reconciliation.
    async fn fetch_positions_async(&self) -> Result<Vec<Position>, HorizonError> {
        let path = "/api/v3/brokerage/accounts";
        let url = format!("{}/accounts", self.api_url);

        let builder = self.client.get(&url);
        let resp = self
            .auth_headers(builder, "GET", path, "")?
            .send()
            .await
            .map_err(|e| {
                HorizonError::Exchange(format!("coinbase: account fetch failed: {}", e))
            })?;

        if !resp.status().is_success() {
            let status = resp.status();
            debug!(status = %status, "coinbase: account fetch returned non-200");
            return Ok(Vec::new());
        }

        let json: serde_json::Value = resp.json().await.map_err(|e| {
            HorizonError::Exchange(format!("coinbase: account parse error: {}", e))
        })?;

        let mut positions = Vec::new();

        if let Some(accounts) = json.get("accounts").and_then(|v| v.as_array()) {
            for acct in accounts {
                let currency = acct
                    .get("currency")
                    .and_then(|v| v.as_str())
                    .unwrap_or("")
                    .to_string();

                let available = acct
                    .get("available_balance")
                    .and_then(|b| b.get("value"))
                    .and_then(|v| {
                        v.as_str()
                            .and_then(|s| s.parse::<f64>().ok())
                            .or_else(|| v.as_f64())
                    })
                    .unwrap_or(0.0);

                let hold = acct
                    .get("hold")
                    .and_then(|b| b.get("value"))
                    .and_then(|v| {
                        v.as_str()
                            .and_then(|s| s.parse::<f64>().ok())
                            .or_else(|| v.as_f64())
                    })
                    .unwrap_or(0.0);

                let total = available + hold;

                if total.abs() > 0.0 && currency != "USD" {
                    positions.push(Position {
                        market_id: currency,
                        side: Side::Long, // Long side for non-prediction instruments
                        size: total,
                        avg_entry_price: 0.0, // Coinbase accounts don't expose cost basis
                        realized_pnl: 0.0,
                        unrealized_pnl: 0.0,
                        token_id: None,
                        exchange: "coinbase".to_string(),
                        multiplier: 1.0,
                    });
                }
            }
        }

        if !positions.is_empty() {
            info!(
                count = positions.len(),
                "coinbase: fetched positions for reconciliation"
            );
        }

        Ok(positions)
    }
}

impl Exchange for CoinbaseExchange {
    fn submit_order(&self, req: &OrderRequest) -> Result<String, HorizonError> {
        let req_clone = req.clone();
        let order_id = self
            .runtime
            .block_on(self.submit_order_async(&req_clone))?;

        // Track order_id per market via shared OrderTracker
        if let Ok(mut tracker) = self.open_orders.lock() {
            tracker.insert(&req.market_id, &order_id);
        }

        Ok(order_id)
    }

    fn cancel_order(&self, order_id: &str) -> Result<(), HorizonError> {
        let id = order_id.to_string();
        self.runtime.block_on(self.cancel_order_async(&id))?;

        // Remove from open_orders tracking
        if let Ok(mut tracker) = self.open_orders.lock() {
            tracker.remove(order_id);
        }

        Ok(())
    }

    fn cancel_all(&self) -> Result<usize, HorizonError> {
        let count = self.runtime.block_on(self.cancel_all_async())?;

        // Clear all tracked orders
        if let Ok(mut tracker) = self.open_orders.lock() {
            tracker.clear();
        }

        Ok(count)
    }

    fn cancel_for_market(&self, market_id: &str) -> Result<usize, HorizonError> {
        let order_ids: Vec<String> = {
            let tracker = self.open_orders.lock().unwrap_or_else(|e| e.into_inner());
            tracker.get_market_orders(market_id)
        };

        if order_ids.is_empty() {
            return Ok(0);
        }

        let mut successfully_canceled = Vec::new();
        for oid in &order_ids {
            match self.runtime.block_on(self.cancel_order_async(oid)) {
                Ok(()) => successfully_canceled.push(oid.clone()),
                Err(e) => {
                    debug!(
                        order_id = %oid,
                        error = %e,
                        "coinbase: cancel_for_market: order cancel failed (may already be filled)"
                    );
                }
            }
        }

        // Only remove successfully canceled IDs from tracking
        if let Ok(mut tracker) = self.open_orders.lock() {
            tracker.remove_from_market(market_id, &successfully_canceled);
        }

        let canceled = successfully_canceled.len();
        info!(
            market_id = %market_id,
            canceled = canceled,
            total = order_ids.len(),
            "coinbase: canceled orders for market"
        );
        Ok(canceled)
    }

    fn drain_fills(&self) -> Vec<Fill> {
        // Poll for new fills from the API
        match self.runtime.block_on(self.poll_fills_async()) {
            Ok(new_fills) => {
                if !new_fills.is_empty() {
                    // Remove filled order IDs from open_orders tracking
                    if let Ok(mut tracker) = self.open_orders.lock() {
                        let filled_ids: Vec<&str> =
                            new_fills.iter().map(|f| f.order_id.as_str()).collect();
                        tracker.remove_filled(&filled_ids);
                    }

                    if let Ok(mut fills) = self.fills.lock() {
                        fills.extend(new_fills);
                    }
                }
            }
            Err(e) => {
                warn!(error = %e, "coinbase: fill polling error");
            }
        }

        match self.fills.lock() {
            Ok(mut fills) => std::mem::take(&mut *fills),
            Err(_) => {
                error!("coinbase: fills lock poisoned");
                Vec::new()
            }
        }
    }

    fn name(&self) -> &str {
        "coinbase"
    }

    fn fetch_positions(&self) -> Result<Vec<Position>, HorizonError> {
        self.runtime.block_on(self.fetch_positions_async())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_validate_url_param_valid() {
        assert!(validate_url_param("abc-123_def", "test").is_ok());
    }

    #[test]
    fn test_validate_url_param_empty() {
        assert!(validate_url_param("", "test").is_err());
    }

    #[test]
    fn test_validate_url_param_special_chars() {
        assert!(validate_url_param("abc/../etc", "test").is_err());
        assert!(validate_url_param("abc def", "test").is_err());
    }

    #[test]
    fn test_validate_url_param_alphanumeric() {
        assert!(validate_url_param("BTC-USD", "test").is_ok());
        assert!(validate_url_param("order_12345", "test").is_ok());
    }

    #[test]
    fn test_validate_url_param_slashes() {
        assert!(validate_url_param("path/to/thing", "test").is_err());
    }

    #[test]
    fn test_url_encode_query_value_safe_chars() {
        assert_eq!(url_encode_query_value("abc-123_def.txt~v2"), "abc-123_def.txt~v2");
    }

    #[test]
    fn test_url_encode_query_value_special_chars() {
        assert_eq!(url_encode_query_value("a&b=c"), "a%26b%3Dc");
        assert_eq!(url_encode_query_value("foo bar"), "foo%20bar");
    }

    #[test]
    fn test_url_encode_query_value_injection_attempt() {
        // Attempt to inject extra query params
        assert_eq!(
            url_encode_query_value("val&admin=true"),
            "val%26admin%3Dtrue"
        );
        // Attempt to break out of query string
        assert_eq!(
            url_encode_query_value("val#fragment"),
            "val%23fragment"
        );
    }

    #[test]
    fn test_url_encode_query_value_empty() {
        assert_eq!(url_encode_query_value(""), "");
    }

    #[test]
    fn test_parse_iso_timestamp_basic() {
        // 2024-01-01T00:00:00Z => 1704067200
        let ts = parse_iso_timestamp("2024-01-01T00:00:00Z");
        assert!((ts - 1704067200.0).abs() < 1.0);
    }

    #[test]
    fn test_parse_iso_timestamp_with_time() {
        // 2024-01-15T10:30:00Z
        let ts = parse_iso_timestamp("2024-01-15T10:30:00Z");
        assert!(ts > 1704067200.0); // after 2024-01-01
        // 2024-01-15 = 14 days after 2024-01-01
        // 1704067200 + 14*86400 + 10*3600 + 30*60 = 1705312200
        assert!((ts - 1705312200.0).abs() < 1.0);
    }

    #[test]
    fn test_parse_iso_timestamp_with_fractional() {
        let ts = parse_iso_timestamp("2024-01-15T12:30:45.123Z");
        assert!(ts > 1704067200.0);
        // Should include fractional seconds
        let frac = ts - ts.floor();
        assert!((frac - 0.123).abs() < 0.001);
    }

    #[test]
    fn test_parse_iso_timestamp_numeric_fallback() {
        let ts = parse_iso_timestamp("1704067200.5");
        assert!((ts - 1704067200.5).abs() < 0.001);
    }

    #[test]
    fn test_parse_iso_timestamp_invalid() {
        assert_eq!(parse_iso_timestamp("not-a-date"), 0.0);
        assert_eq!(parse_iso_timestamp(""), 0.0);
    }

    #[test]
    fn test_parse_iso_timestamp_with_offset() {
        // Should strip timezone offset and treat as UTC
        let ts = parse_iso_timestamp("2024-01-01T00:00:00+00:00");
        assert!((ts - 1704067200.0).abs() < 1.0);
    }
}
