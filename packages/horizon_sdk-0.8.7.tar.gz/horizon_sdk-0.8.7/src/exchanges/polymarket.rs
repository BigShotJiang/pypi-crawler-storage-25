//! Polymarket CLOB exchange client.
//!
//! Implements the Exchange trait for Polymarket's Central Limit Order Book.
//! Uses API key authentication (HMAC-SHA256) for order management.
//! Uses EIP-712 typed data signing for on-chain order placement.
//! Includes fill polling to track executed trades.

use crate::error::HorizonError;
use crate::exchanges::crypto_utils::{
    address_to_u256, decimal_str_to_u256, derive_address, keccak256, parse_private_key,
    sign_digest, u128_to_u256, u64_to_u256,
};
use crate::exchanges::fill_dedup::FillDedup;
use crate::exchanges::order_tracker::OrderTracker;
use crate::exchanges::Exchange;
use crate::types::{Fill, OrderRequest, OrderSide, Side};
use hmac::{Hmac, Mac};
use k256::ecdsa::SigningKey;
use sha2::Sha256;
use std::collections::HashMap;
use std::sync::{Arc, Mutex};
use std::time::{SystemTime, UNIX_EPOCH};
use tracing::{debug, error, info, warn};
use zeroize::Zeroizing;

type HmacSha256 = Hmac<Sha256>;

const DEFAULT_CLOB_URL: &str = "https://clob.polymarket.com";

/// Polymarket CTF Exchange contract address on Polygon (chainId=137).
const CTF_EXCHANGE: &str = "4bFb41d5B3570DeFd03C39a9A4D8dE6Bd8B8982E";

/// Neg Risk CTF Exchange contract address on Polygon.
const NEG_RISK_CTF_EXCHANGE: &str = "C5d563A36AE78145C45a50134d48A1215220f80a";

/// USDC / Conditional Token decimals on Polygon (6 decimals = 1e6).
const DECIMALS: f64 = 1_000_000.0;

/// EIP-712 domain separator components.
const DOMAIN_NAME: &str = "Polymarket CTF Exchange";
const DOMAIN_VERSION: &str = "1";
const CHAIN_ID: u64 = 137;

pub struct PolymarketExchange {
    api_key: Zeroizing<String>,
    api_secret: Zeroizing<String>,
    api_passphrase: Zeroizing<String>,
    clob_url: String,
    client: reqwest::Client,
    runtime: Arc<tokio::runtime::Runtime>,
    fills: Mutex<Vec<Fill>>,
    next_fill_id: Mutex<u64>,
    /// Tracks the last fill timestamp we've seen, for incremental polling.
    last_fill_ts: Mutex<f64>,
    /// EIP-712 signing key (from private_key hex).
    signing_key: Option<SigningKey>,
    /// Ethereum address derived from the signing key (20 bytes, the EOA signer).
    signer_address: [u8; 20],
    /// Gnosis Safe / contract wallet address that holds funds (the "maker" for signature_type >= 1).
    /// When None, signer_address is used as maker (standard EOA mode).
    funder_address: Option<[u8; 20]>,
    /// EIP-712 signature type: 0 = EOA, 1 = POLY_PROXY, 2 = POLY_GNOSIS_SAFE.
    signature_type: u8,
    /// Tracks open order IDs per market (shared OrderTracker).
    open_orders: Mutex<OrderTracker>,
    /// Tracks order_id -> Side for correct fill side resolution.
    /// Uses FIFO eviction at MAX_DEDUP_ENTRIES via order_sides_order.
    order_sides: Mutex<HashMap<String, Side>>,
    /// Insertion order of order_sides entries, for FIFO eviction.
    order_sides_order: Mutex<std::collections::VecDeque<String>>,
    /// Tracks token_id (asset_id) -> Side mapping. This is the fallback when
    /// order_sides lookup misses (e.g., after eviction or restart). Token IDs
    /// are stable per outcome (YES token != NO token).
    /// FIFO eviction at MAX_DEDUP_ENTRIES via token_sides_order.
    token_sides: Mutex<HashMap<String, Side>>,
    /// Insertion order of token_sides entries, for FIFO eviction.
    token_sides_order: Mutex<std::collections::VecDeque<String>>,
    /// Precomputed EIP-712 domain separators (avoids 5 keccak256 hashes per order).
    domain_sep_ctf: [u8; 32],
    domain_sep_neg_risk: [u8; 32],
    /// Deduplicates fill IDs with FIFO eviction (shared FillDedup).
    fill_dedup: Mutex<FillDedup>,
}

// Crypto helpers (keccak256, u64_to_u256, u128_to_u256, etc.) imported from crypto_utils.
// EIP-712 domain_separator uses crypto_utils::eip712_domain_separator with Polymarket constants.
use crate::exchanges::crypto_utils::eip712_domain_separator;

/// Compute the Polymarket EIP-712 domain separator for a contract address.
fn domain_separator(contract_addr: &[u8; 20]) -> [u8; 32] {
    eip712_domain_separator(DOMAIN_NAME, DOMAIN_VERSION, CHAIN_ID, contract_addr)
}

/// Order type hash for the CTF Exchange Order struct.
///
///   keccak256("Order(uint256 salt,address maker,address signer,address taker,
///     uint256 tokenId,uint256 makerAmount,uint256 takerAmount,
///     uint256 expiration,uint256 nonce,uint256 feeRateBps,
///     uint8 side,uint8 signatureType)")
///
/// Cached via LazyLock so the keccak256 only runs once per process.
static ORDER_TYPE_HASH: std::sync::LazyLock<[u8; 32]> = std::sync::LazyLock::new(|| {
    keccak256(
        b"Order(uint256 salt,address maker,address signer,address taker,uint256 tokenId,uint256 makerAmount,uint256 takerAmount,uint256 expiration,uint256 nonce,uint256 feeRateBps,uint8 side,uint8 signatureType)",
    )
});

fn order_type_hash() -> [u8; 32] {
    *ORDER_TYPE_HASH
}

/// Struct representing a Polymarket CTF Exchange order for EIP-712 signing.
struct CtfOrder {
    /// Salt as u64 to match py_clob_client (round(random() * now)) and to fit
    /// in JSON number range (serde_json doesn't support u128 numbers).
    salt: u64,
    maker: [u8; 20],
    signer: [u8; 20],
    taker: [u8; 20], // 0x0 for public orders
    token_id: [u8; 32],
    maker_amount: [u8; 32],
    taker_amount: [u8; 32],
    expiration: u64,
    nonce: u64,
    fee_rate_bps: u64,
    side: u8,            // 0 = BUY, 1 = SELL
    signature_type: u8,  // 0 = EOA
}

impl CtfOrder {
    /// Compute hashStruct(order).
    fn struct_hash(&self) -> [u8; 32] {
        let type_hash = order_type_hash();
        // 12 fields × 32 bytes each + type_hash
        let mut buf = Vec::with_capacity(13 * 32);
        buf.extend_from_slice(&type_hash);
        buf.extend_from_slice(&u64_to_u256(self.salt));
        buf.extend_from_slice(&address_to_u256(&self.maker));
        buf.extend_from_slice(&address_to_u256(&self.signer));
        buf.extend_from_slice(&address_to_u256(&self.taker));
        buf.extend_from_slice(&self.token_id);
        buf.extend_from_slice(&self.maker_amount);
        buf.extend_from_slice(&self.taker_amount);
        buf.extend_from_slice(&u64_to_u256(self.expiration));
        buf.extend_from_slice(&u64_to_u256(self.nonce));
        buf.extend_from_slice(&u64_to_u256(self.fee_rate_bps));
        buf.extend_from_slice(&u64_to_u256(self.side as u64));
        buf.extend_from_slice(&u64_to_u256(self.signature_type as u64));
        keccak256(&buf)
    }

    /// Compute the full EIP-712 digest: keccak256("\x19\x01" || domainSeparator || structHash).
    fn eip712_digest(&self, domain_sep: &[u8; 32]) -> [u8; 32] {
        let struct_hash = self.struct_hash();
        let mut buf = Vec::with_capacity(2 + 32 + 32);
        buf.push(0x19);
        buf.push(0x01);
        buf.extend_from_slice(domain_sep);
        buf.extend_from_slice(&struct_hash);
        keccak256(&buf)
    }
}

// sign_digest imported from crypto_utils

// -- PolymarketExchange -------------------------------------------------------

impl PolymarketExchange {
    pub fn new(
        api_key: String,
        api_secret: String,
        api_passphrase: String,
        private_key: Option<String>,
        clob_url: Option<String>,
        runtime: Arc<tokio::runtime::Runtime>,
        funder: Option<String>,
        signature_type: u8,
    ) -> Result<Self, HorizonError> {
        // Validate signature_type
        if signature_type > 2 {
            return Err(HorizonError::Exchange(format!(
                "polymarket: invalid signature_type {}. Must be 0 (EOA), 1 (POLY_PROXY), or 2 (POLY_GNOSIS_SAFE)",
                signature_type
            )));
        }

        let (signing_key, signer_address) = match private_key {
            Some(ref pk) if !pk.is_empty() => {
                match parse_private_key(pk) {
                    Ok(sk) => {
                        let addr = derive_address(&sk);
                        info!(
                            address = %format!("0x{}", hex::encode(addr)),
                            "polymarket: loaded signing key"
                        );
                        (Some(sk), addr)
                    }
                    Err(e) => {
                        // Hard fail when the user EXPLICITLY provided a key but it's
                        // bad. Silent degraded mode would let them construct an
                        // engine that can't sign, then fail at first submit_order
                        // — confusing UX. Better to fail loudly here.
                        return Err(HorizonError::Exchange(format!(
                            "polymarket: invalid private key: {}", e
                        )));
                    }
                }
            }
            _ => {
                debug!("polymarket: no private key provided, order signing disabled");
                (None, [0u8; 20])
            }
        };

        // Parse funder address (Gnosis Safe / proxy wallet address)
        let funder_address = match funder {
            Some(ref f) if !f.is_empty() => {
                let hex_str = f.strip_prefix("0x").unwrap_or(f);
                let bytes = hex::decode(hex_str).map_err(|e| {
                    HorizonError::Exchange(format!("polymarket: invalid funder address hex: {}", e))
                })?;
                if bytes.len() != 20 {
                    return Err(HorizonError::Exchange(format!(
                        "polymarket: funder address must be 20 bytes, got {}",
                        bytes.len()
                    )));
                }
                let mut addr = [0u8; 20];
                addr.copy_from_slice(&bytes);
                info!(
                    funder = %format!("0x{}", hex::encode(addr)),
                    signature_type = signature_type,
                    "polymarket: using contract wallet (funder) as maker"
                );
                Some(addr)
            }
            _ => None,
        };

        // Validate: signature_type > 0 requires a funder address
        if signature_type > 0 && funder_address.is_none() {
            return Err(HorizonError::Exchange(format!(
                "polymarket: signature_type={} requires a funder address (the contract wallet that holds funds)",
                signature_type
            )));
        }

        // Precompute domain separators at construction time (avoids 5 keccak256 per order)
        let ctf_bytes = hex::decode(CTF_EXCHANGE).map_err(|e| {
            HorizonError::Exchange(format!("polymarket: invalid CTF_EXCHANGE hex: {}", e))
        })?;
        let mut ctf_addr = [0u8; 20];
        ctf_addr.copy_from_slice(&ctf_bytes);
        let domain_sep_ctf = domain_separator(&ctf_addr);

        let neg_bytes = hex::decode(NEG_RISK_CTF_EXCHANGE).map_err(|e| {
            HorizonError::Exchange(format!("polymarket: invalid NEG_RISK_CTF_EXCHANGE hex: {}", e))
        })?;
        let mut neg_addr = [0u8; 20];
        neg_addr.copy_from_slice(&neg_bytes);
        let domain_sep_neg_risk = domain_separator(&neg_addr);

        Ok(Self {
            api_key: Zeroizing::new(api_key),
            api_secret: Zeroizing::new(api_secret),
            api_passphrase: Zeroizing::new(api_passphrase),
            clob_url: clob_url.unwrap_or_else(|| DEFAULT_CLOB_URL.to_string()),
            client: reqwest::Client::builder()
                // Polymarket's CLOB has been observed taking 15-30s during peak load.
                // A timeout that's too short causes phantom orders: client gives up
                // but the order actually landed on the book. EIP-712 orders cannot
                // be safely retried (each retry has a fresh salt). 30s gives the
                // server enough room to return a real response.
                .timeout(std::time::Duration::from_secs(30))
                .connect_timeout(std::time::Duration::from_secs(10))
                // Disable redirects on POST/DELETE — HMAC signature is computed
                // for the original path; following a redirect drops headers and
                // breaks auth. Better to fail loudly than silently re-route.
                .redirect(reqwest::redirect::Policy::none())
                .build()
                .unwrap_or_else(|_| reqwest::Client::new()),
            runtime,
            fills: Mutex::new(Vec::new()),
            next_fill_id: Mutex::new(1),
            last_fill_ts: Mutex::new(0.0),
            signing_key,
            signer_address,
            funder_address,
            signature_type,
            open_orders: Mutex::new(OrderTracker::new("polymarket")),
            order_sides: Mutex::new(HashMap::new()),
            order_sides_order: Mutex::new(std::collections::VecDeque::new()),
            token_sides: Mutex::new(HashMap::new()),
            token_sides_order: Mutex::new(std::collections::VecDeque::new()),
            fill_dedup: Mutex::new(FillDedup::new()),
            domain_sep_ctf,
            domain_sep_neg_risk,
        })
    }

    /// Generate HMAC-SHA256 signature for Polymarket API auth.
    fn sign_hmac(
        &self,
        timestamp: &str,
        method: &str,
        path: &str,
        body: &str,
    ) -> Result<String, HorizonError> {
        let message = format!("{}{}{}{}", timestamp, method, path, body);
        // py_clob_client returns URL-safe base64 (with - and _ chars).
        // Try standard base64 first, then URL-safe, to accept both formats.
        let secret_bytes = base64::Engine::decode(
            &base64::engine::general_purpose::STANDARD,
            &*self.api_secret,
        )
        .or_else(|_| {
            base64::Engine::decode(
                &base64::engine::general_purpose::URL_SAFE,
                &*self.api_secret,
            )
        })
        .or_else(|_| {
            // Also try without padding (some clients strip trailing '=')
            base64::Engine::decode(
                &base64::engine::general_purpose::URL_SAFE_NO_PAD,
                &*self.api_secret,
            )
        })
        .map_err(|_| {
            HorizonError::Exchange(
                "polymarket: invalid api_secret (not valid base64 or URL-safe base64)".to_string(),
            )
        })?;

        let mut mac = HmacSha256::new_from_slice(&secret_bytes).map_err(|e| {
            HorizonError::Exchange(format!("polymarket: HMAC key error: {}", e))
        })?;
        hmac::Mac::update(&mut mac, message.as_bytes());
        let result = mac.finalize();
        // py_clob_client uses urlsafe_b64encode for the signature output (with padding).
        // URL_SAFE = same as standard but with - and _ instead of + and /.
        Ok(base64::Engine::encode(
            &base64::engine::general_purpose::URL_SAFE,
            result.into_bytes(),
        ))
    }

    /// Build authenticated headers for a request.
    ///
    /// The HMAC signature is computed over the path WITHOUT query parameters,
    /// matching py_clob_client behavior. The full path (with query string) can
    /// still be passed in — this method strips it before signing.
    fn auth_headers(
        &self,
        method: &str,
        path: &str,
        body: &str,
    ) -> Result<Vec<(String, String)>, HorizonError> {
        let timestamp = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_secs()
            .to_string();

        // Strip query string before signing (py_clob_client signs only the path)
        let sign_path = match path.find('?') {
            Some(idx) => &path[..idx],
            None => path,
        };

        let signature = self.sign_hmac(&timestamp, method, sign_path, body)?;

        let mut headers = vec![
            ("POLY-API-KEY".to_string(), (*self.api_key).clone()),
            ("POLY-SIGNATURE".to_string(), signature),
            ("POLY-TIMESTAMP".to_string(), timestamp),
            ("POLY-PASSPHRASE".to_string(), (*self.api_passphrase).clone()),
        ];

        // py_clob_client also sends POLY_ADDRESS with the signer's wallet address
        // on every L2 request. Some endpoints may require it.
        if self.signing_key.is_some() {
            let addr_hex = format!("0x{}", hex::encode(self.signer_address));
            headers.push(("POLY-ADDRESS".to_string(), addr_hex));
        }

        Ok(headers)
    }

    /// Convert OrderSide to Polymarket API string.
    fn poly_side_str(order_side: OrderSide) -> &'static str {
        match order_side {
            OrderSide::Buy => "BUY",
            OrderSide::Sell => "SELL",
        }
    }

    /// Convert OrderSide to on-chain uint8 (BUY=0, SELL=1).
    fn poly_side_u8(order_side: OrderSide) -> u8 {
        match order_side {
            OrderSide::Buy => 0,
            OrderSide::Sell => 1,
        }
    }

    /// Map TimeInForce to Polymarket string.
    fn poly_tif(tif: crate::types::TimeInForce) -> &'static str {
        match tif {
            crate::types::TimeInForce::GTC => "GTC",
            crate::types::TimeInForce::GTD => "GTD",
            crate::types::TimeInForce::FOK => "FOK",
            crate::types::TimeInForce::FAK => "FAK",
        }
    }

    /// Determine Polymarket orderType based on OrderType and TimeInForce.
    /// Market orders use FOK (Polymarket's fill-or-kill = immediate execution).
    fn poly_order_type(req: &OrderRequest) -> &'static str {
        match req.order_type {
            crate::types::OrderType::Market => "FOK",
            crate::types::OrderType::Limit => Self::poly_tif(req.time_in_force),
        }
    }

    /// Build a signed order body for the CLOB API.
    ///
    /// Returns the JSON body with the EIP-712 signed order.
    fn build_signed_order(
        &self,
        req: &OrderRequest,
        neg_risk: bool,
    ) -> Result<serde_json::Value, HorizonError> {
        let signing_key = self.signing_key.as_ref().ok_or_else(|| {
            HorizonError::Exchange(
                "polymarket: cannot submit signed orders without a private key".into(),
            )
        })?;

        if !req.price.is_finite() || !req.size.is_finite() {
            return Err(HorizonError::Exchange(
                "polymarket: price and size must be finite".into(),
            ));
        }

        if req.price <= 0.0 || req.size <= 0.0 {
            return Err(HorizonError::Order(
                "polymarket: price and size must be positive".into(),
            ));
        }

        // Generate a cryptographically random salt as u64.
        // Mask to i63 max so it fits in any signed int64 (Go's encoding/json
        // decodes JSON numbers into int64 by default, which would overflow on
        // u64 values with the high bit set). py_clob_client salt range is much
        // smaller (round(random() * now) ≈ 2^31), so 63 bits is far more entropy.
        let uuid_bytes = *uuid::Uuid::new_v4().as_bytes();
        let salt: u64 = u64::from_be_bytes([
            uuid_bytes[0], uuid_bytes[1], uuid_bytes[2], uuid_bytes[3],
            uuid_bytes[4], uuid_bytes[5], uuid_bytes[6], uuid_bytes[7],
        ]) & 0x7FFF_FFFF_FFFF_FFFF;

        // Use token_id if set, otherwise fall back to market_id
        let token_id_str = req.token_id.as_deref().unwrap_or(&req.market_id);
        let token_id_u256 = decimal_str_to_u256(token_id_str)?;

        // Calculate amounts in 6 decimal places.
        // BUY: maker gives USDC (price * size), taker gives CT (size)
        // SELL: maker gives CT (size), taker gives USDC (price * size)
        //
        // KNOWN DIFFERENCE FROM py_clob_client (audit-tracked, M5):
        // py_clob_client uses a cascade: round_normal(price) → round_down(size)
        // → multiply → round_up at amount+4 decimals → round_down at amount
        // decimals → multiply by 10^6. We use a single .round() (half-to-even).
        // For round prices/sizes (1¢ ticks, integer sizes) the results are
        // identical. For sub-cent or fractional sizes the integer amounts may
        // differ by 1 unit (= $0.000001 USDC). The Polymarket server appears
        // to accept both — confirmed by working live submissions — but
        // strategies should round price to tick size and size to whole shares
        // before submitting if they want byte-for-byte parity with py_clob_client.
        let price_amount_f64 = req.price * req.size * DECIMALS;
        if !price_amount_f64.is_finite() || price_amount_f64 < 0.0 || price_amount_f64 > u128::MAX as f64 {
            return Err(HorizonError::Validation("Order price*size amount overflow".into()));
        }
        let size_amount_f64 = req.size * DECIMALS;
        if !size_amount_f64.is_finite() || size_amount_f64 < 0.0 || size_amount_f64 > u128::MAX as f64 {
            return Err(HorizonError::Validation("Order size amount overflow".into()));
        }
        let raw_price_amount = price_amount_f64.round() as u128;
        let raw_size_amount = size_amount_f64.round() as u128;

        let (maker_amount, taker_amount) = match req.order_side {
            OrderSide::Buy => (u128_to_u256(raw_price_amount), u128_to_u256(raw_size_amount)),
            OrderSide::Sell => (u128_to_u256(raw_size_amount), u128_to_u256(raw_price_amount)),
        };

        // For signature_type > 0 (proxy/gnosis safe), maker = funder (contract wallet),
        // signer = EOA. For type 0, maker = signer = EOA.
        let maker_addr = self.funder_address.unwrap_or(self.signer_address);

        let order = CtfOrder {
            salt,
            maker: maker_addr,
            signer: self.signer_address,
            taker: [0u8; 20],
            token_id: token_id_u256,
            maker_amount,
            taker_amount,
            expiration: 0,
            nonce: 0,
            fee_rate_bps: 0,
            side: Self::poly_side_u8(req.order_side),
            signature_type: self.signature_type,
        };

        // Use precomputed domain separator based on neg_risk
        let domain_sep = if neg_risk {
            &self.domain_sep_neg_risk
        } else {
            &self.domain_sep_ctf
        };
        let digest = order.eip712_digest(domain_sep);
        let signature = sign_digest(signing_key, &digest)?;
        let sig_hex = format!("0x{}", hex::encode(&signature));

        let maker_hex = format!("0x{}", hex::encode(maker_addr));
        let signer_hex = format!("0x{}", hex::encode(self.signer_address));

        // JSON body amounts must match the signed EIP-712 struct (side-dependent)
        let (json_maker_amount, json_taker_amount) = match req.order_side {
            OrderSide::Buy => (raw_price_amount, raw_size_amount),
            OrderSide::Sell => (raw_size_amount, raw_price_amount),
        };

        // Build CLOB API order body matching py_clob_client byte-for-byte:
        // - Field order matches SignedOrder.dict() (order.py:142-156, 168-181)
        // - salt and signatureType are JSON numbers (not stringified)
        // - tokenId is lowercase 'd' (NOT tokenID)
        // - All uint256s except salt are stringified
        // - owner is the API key UUID (NOT the wallet address) -- utilities.py:62 + client.py:631
        // - postOnly always sent (defaults to false)
        let body = serde_json::json!({
            "order": {
                "salt": salt,
                "maker": maker_hex,
                "signer": signer_hex,
                "taker": "0x0000000000000000000000000000000000000000",
                "tokenId": token_id_str,
                "makerAmount": json_maker_amount.to_string(),
                "takerAmount": json_taker_amount.to_string(),
                "expiration": "0",
                "nonce": "0",
                "feeRateBps": "0",
                "side": Self::poly_side_str(req.order_side),
                "signatureType": self.signature_type,
                "signature": sig_hex,
            },
            "owner": (*self.api_key).clone(),
            "orderType": Self::poly_order_type(req),
            "postOnly": req.post_only,
        });

        Ok(body)
    }

    /// Submit order to Polymarket CLOB with exponential backoff on 429.
    async fn submit_order_async(&self, req: &OrderRequest) -> Result<String, HorizonError> {
        let path = "/order";

        let body = self.build_signed_order(req, req.neg_risk)?;
        // Serialize ONCE to bytes. Both the HMAC signature and the wire request
        // must use the EXACT same bytes — any re-serialization between signing
        // and sending could produce different bytes (different field order,
        // different number formatting, whitespace) and break the signature.
        let body_bytes = serde_json::to_vec(&body).map_err(|e| {
            HorizonError::Exchange(format!("polymarket: order body serialization failed: {}", e))
        })?;
        let body_str = std::str::from_utf8(&body_bytes).map_err(|e| {
            HorizonError::Exchange(format!("polymarket: order body utf8 error: {}", e))
        })?;
        let url = format!("{}{}", self.clob_url, path);

        debug!(
            market = %req.market_id,
            side = ?req.order_side,
            price = req.price,
            size = req.size,
            signed = self.signing_key.is_some(),
            "polymarket: submitting order"
        );

        let mut backoff_ms: u64 = 1000;
        const MAX_RETRIES: u32 = 4;

        for attempt in 0..=MAX_RETRIES {
            let headers = self.auth_headers("POST", path, body_str)?;
            // Use raw body bytes (not .json()) to ensure HMAC bytes match wire bytes.
            let mut request = self.client.post(&url)
                .header("Content-Type", "application/json")
                .body(body_bytes.clone());
            for (key, value) in &headers {
                request = request.header(key, value);
            }

            let resp = request
                .send()
                .await
                .map_err(|e| HorizonError::Exchange(format!("polymarket request failed for market {}: {}", req.market_id, e)))?;

            // Retry on rate limit (429) and transient gateway errors (502/503/504).
            // Note: do NOT retry on 500/501 — those are likely "request was processed
            // but server errored after" which would risk duplicate orders. Only retry
            // statuses where the server explicitly says "didn't process, try again."
            let status_code = resp.status().as_u16();
            let is_retryable = status_code == 429
                || status_code == 502
                || status_code == 503
                || status_code == 504;
            if is_retryable && attempt < MAX_RETRIES {
                warn!(
                    status = status_code,
                    attempt = attempt + 1,
                    backoff_ms = backoff_ms,
                    "polymarket: transient error, retrying"
                );
                tokio::time::sleep(tokio::time::Duration::from_millis(backoff_ms)).await;
                backoff_ms = (backoff_ms * 2).min(30_000);
                continue;
            }

            if !resp.status().is_success() {
                let status = resp.status();
                let body_text = resp.text().await.unwrap_or_default();
                let truncated = super::truncate_utf8(&body_text, 500);
                error!(
                    status = %status,
                    body = %truncated,
                    "polymarket: order rejected"
                );
                return Err(HorizonError::Exchange(format!(
                    "polymarket order rejected ({}): {}",
                    status, truncated
                )));
            }

            // Critical: 200 status + JSON parse failure means the server may
            // have ACCEPTED our signed order but returned a non-JSON body
            // (HTML error page, empty body, etc). The order may now be live
            // on the book and we don't know its ID. Log everything we can so
            // the user can manually reconcile.
            let content_type = resp
                .headers()
                .get("content-type")
                .and_then(|v| v.to_str().ok())
                .unwrap_or("(missing)")
                .to_string();
            let body_text = resp.text().await.unwrap_or_default();
            let json: serde_json::Value = match serde_json::from_str(&body_text) {
                Ok(j) => j,
                Err(e) => {
                    let truncated = super::truncate_utf8(&body_text, 500);
                    error!(
                        error = %e,
                        content_type = %content_type,
                        body = %truncated,
                        "polymarket: 200 OK but JSON parse failed — POSSIBLE PHANTOM ORDER. \
                         The server may have accepted our signed order but returned a non-JSON \
                         response. Manually verify on polymarket.com that your order is not on \
                         the book before retrying."
                    );
                    return Err(HorizonError::Exchange(format!(
                        "polymarket: 200 OK but unparseable response (possible phantom order, \
                         check polymarket.com manually): {}: {}",
                        e, truncated
                    )));
                }
            };

            // Handle 200 OK with logical failure: {"success": false, "errorMsg": "..."}
            // The Polymarket Go server returns 200 even when the order is logically
            // rejected (e.g., insufficient balance, invalid tick size). Surface the
            // real error message instead of falling through to "missing order ID".
            // Accept both bool false and string "false" for defensive parsing.
            let success_is_false = json
                .get("success")
                .and_then(|v| {
                    v.as_bool()
                        .map(|b| !b)
                        .or_else(|| v.as_str().map(|s| s.eq_ignore_ascii_case("false")))
                })
                .unwrap_or(false);
            if success_is_false {
                let err_msg = json
                    .get("errorMsg")
                    .or_else(|| json.get("error"))
                    .and_then(|v| v.as_str())
                    .unwrap_or("unknown error");
                return Err(HorizonError::Exchange(format!(
                    "polymarket order rejected: {}",
                    err_msg
                )));
            }

            let order_id = json
                .get("orderID")
                .or_else(|| json.get("orderId"))
                .or_else(|| json.get("id"))
                .and_then(|v| v.as_str())
                .filter(|s| !s.is_empty())
                .map(|s| s.to_string())
                .ok_or_else(|| {
                    HorizonError::Exchange(format!(
                        "polymarket: response missing order ID: {}",
                        json
                    ))
                })?;

            if attempt > 0 {
                info!(order_id = %order_id, attempts = attempt + 1, "polymarket: order accepted (after retry)");
            } else {
                info!(order_id = %order_id, "polymarket: order accepted");
            }
            return Ok(order_id);
        }

        Err(HorizonError::Exchange(format!("polymarket: rate limit retries exhausted for market {}", req.market_id)))
    }

    /// Cancel order on Polymarket.
    async fn cancel_order_async(&self, order_id: &str) -> Result<(), HorizonError> {
        let path = "/order";
        let body = serde_json::json!({
            "orderID": order_id,
        });
        let body_str = body.to_string();

        let headers = self.auth_headers("DELETE", path, &body_str)?;
        let url = format!("{}{}", self.clob_url, path);

        let mut request = self.client.delete(&url).json(&body);
        for (key, value) in &headers {
            request = request.header(key, value);
        }

        let resp = request
            .send()
            .await
            .map_err(|e| HorizonError::Exchange(format!("polymarket cancel failed for order {}: {}", order_id, e)))?;

        if !resp.status().is_success() {
            let status = resp.status();
            let body = resp.text().await.unwrap_or_default();
            let truncated = super::truncate_utf8(&body, 500);
            warn!(
                order_id = %order_id,
                status = %status,
                "polymarket: cancel failed"
            );
            return Err(HorizonError::Exchange(format!(
                "polymarket cancel rejected ({}): {}",
                status, truncated
            )));
        }

        debug!(order_id = %order_id, "polymarket: order canceled");
        Ok(())
    }

    /// Cancel all orders on Polymarket.
    ///
    /// py_clob_client sends NO body on DELETE /cancel-all (client.py:711).
    /// HMAC must be computed over an empty body string for the signature to match.
    async fn cancel_all_async(&self) -> Result<usize, HorizonError> {
        let path = "/cancel-all";

        // HMAC over empty body, matching py_clob_client
        let headers = self.auth_headers("DELETE", path, "")?;
        let url = format!("{}{}", self.clob_url, path);

        // Send DELETE with no body at all (not even {})
        let mut request = self.client.delete(&url);
        for (key, value) in &headers {
            request = request.header(key, value);
        }

        let resp = request
            .send()
            .await
            .map_err(|e| HorizonError::Exchange(format!("polymarket cancel-all failed: {}", e)))?;

        if !resp.status().is_success() {
            let status = resp.status();
            let body = resp.text().await.unwrap_or_default();
            let truncated = super::truncate_utf8(&body, 500);
            return Err(HorizonError::Exchange(format!(
                "polymarket cancel-all failed ({}): {}",
                status, truncated
            )));
        }

        let json: serde_json::Value = resp.json().await.unwrap_or_else(|e| {
            warn!(error = %e, "polymarket: cancel-all response parse failed");
            serde_json::Value::Null
        });
        let count = json
            .get("canceled")
            .and_then(|v| v.as_u64())
            .unwrap_or(0);

        info!(count = count, "polymarket: canceled all orders");
        Ok(count as usize)
    }

    /// Poll for recent trades/fills from Polymarket.
    ///
    /// Uses GET /data/trades (matches py_clob_client endpoints.py:14).
    /// Cursor pagination starts at "MA==" and terminates when next_cursor == "LTE=".
    /// Response shape: {"limit", "next_cursor", "count", "data": Trade[]}
    /// Trade fields: id, taker_order_id, asset_id, side, size, price, fee_rate_bps,
    ///   match_time (string), match_time_nano, status, owner, etc.
    async fn poll_fills_async(&self) -> Result<Vec<Fill>, HorizonError> {
        const TRADES_PATH: &str = "/data/trades";
        const START_CURSOR: &str = "MA==";
        const END_CURSOR: &str = "LTE=";

        let last_ts = {
            let ts = self.last_fill_ts.lock().unwrap_or_else(|e| e.into_inner());
            *ts
        };

        let mut new_fills = Vec::new();
        let mut max_ts = last_ts;
        let mut next_cursor = START_CURSOR.to_string();
        let mut pages = 0u32;
        const MAX_PAGES: u32 = 50; // safety cap

        loop {
            if pages >= MAX_PAGES {
                warn!(pages = pages, "polymarket: hit max pagination cap on /data/trades");
                break;
            }
            pages += 1;

            // HMAC signs the path WITHOUT query params (auth_headers strips them)
            // Build URL with cursor and optional after= filter for incremental polling.
            // Polymarket /data/trades after= takes integer Unix seconds. We subtract 1
            // second of overlap to handle the edge case where multiple trades share
            // the same second — fill_dedup catches the duplicates.
            let mut url = format!("{}{}?next_cursor={}", self.clob_url, TRADES_PATH, next_cursor);
            if last_ts > 0.0 {
                let after_ts = (last_ts as u64).saturating_sub(1);
                url.push_str(&format!("&after={}", after_ts));
            }

            let headers = self.auth_headers("GET", TRADES_PATH, "")?;
            let mut request = self.client.get(&url);
            for (key, value) in &headers {
                request = request.header(key, value);
            }

            // On any error mid-pagination, return the fills accumulated so far
            // (instead of Err which would lose them — we've already inserted
            // their dedup keys into fill_dedup, so a retry would skip them).
            let resp = match request.send().await {
                Ok(r) => r,
                Err(e) => {
                    warn!(
                        error = %e,
                        page = pages,
                        accumulated = new_fills.len(),
                        "polymarket: fill poll network error mid-pagination, returning partial"
                    );
                    return Ok(new_fills);
                }
            };

            if !resp.status().is_success() {
                let status = resp.status();
                debug!(status = %status, "polymarket: fill poll returned non-200");
                return Ok(new_fills);
            }

            let json: serde_json::Value = match resp.json().await {
                Ok(j) => j,
                Err(e) => {
                    warn!(
                        error = %e,
                        page = pages,
                        accumulated = new_fills.len(),
                        "polymarket: fill poll parse error mid-pagination, returning partial"
                    );
                    return Ok(new_fills);
                }
            };

            // Real /data/trades response: {"limit", "next_cursor", "count", "data": [...]}
            // Tolerate older shapes (top-level array, "trades" key) for backwards compat.
            let trades_arr = json
                .get("data")
                .and_then(|v| v.as_array())
                .or_else(|| json.get("trades").and_then(|v| v.as_array()))
                .or_else(|| json.as_array());

            let trades = match trades_arr {
                Some(t) => t,
                None => {
                    debug!("polymarket: /data/trades response had no data array");
                    return Ok(new_fills);
                }
            };

            // Note: next_fill_id is no longer held across the trade loop.
            // Each trade that needs a synthetic fill_id locks it briefly
            // (see fill_id construction below) — this avoids holding the
            // mutex while also acquiring fill_dedup, order_sides, and
            // token_sides, which would establish a deep lock-order chain.

            for trade in trades {
                // match_time is a STRING in seconds-since-epoch (Polymarket spec)
                let ts = trade
                    .get("match_time")
                    .or_else(|| trade.get("matchTime"))
                    .or_else(|| trade.get("timestamp"))
                    .and_then(|v| v.as_str().and_then(|s| s.parse::<f64>().ok())
                        .or_else(|| v.as_f64()))
                    .unwrap_or(0.0);

                if ts < last_ts {
                    continue;
                }

                // Real field is "id"; "tradeID" was wrong/legacy
                let trade_id = trade
                    .get("id")
                    .or_else(|| trade.get("tradeID"))
                    .and_then(|v| v.as_str())
                    .unwrap_or("");

                // Compute dedup key but DON'T insert yet — we want to insert
                // ONLY after the fill has been fully processed and pushed.
                // Otherwise validation failures (NaN, missing fields) would
                // mark the trade as seen but never return it, losing it forever.
                // For trades without an id, fall back to (ts, asset_id) which
                // is deterministic across process restarts (unlike a
                // monotonic counter that resets).
                let dedup_key = if trade_id.is_empty() {
                    let asset_for_key = trade
                        .get("asset_id")
                        .or_else(|| trade.get("asset"))
                        .and_then(|v| v.as_str())
                        .unwrap_or("");
                    format!("{}_{}", ts, asset_for_key)
                } else {
                    trade_id.to_string()
                };

                // Read-only dedup check: skip if already processed in a prior poll
                {
                    let dedup = self.fill_dedup.lock().unwrap_or_else(|e| e.into_inner());
                    if dedup.contains(&dedup_key) {
                        continue;
                    }
                }

                if ts > max_ts {
                    max_ts = ts;
                }

                // Determine which order in the trade was OURS. Polymarket trades
                // include both taker_order_id and maker_orders[]. trader_side tells
                // us which side WE were:
                //   - "TAKER" → our order is taker_order_id
                //   - "MAKER" → our order is in maker_orders[].order_id
                // We need this for accurate side (Yes/No) resolution from order_sides.
                let trader_side = trade
                    .get("trader_side")
                    .and_then(|v| v.as_str())
                    .unwrap_or("");
                let is_maker = trader_side.eq_ignore_ascii_case("MAKER");

                let our_order_id: String = if is_maker {
                    // We were maker — find our order IDs in maker_orders array.
                    // If multiple of our orders match in the same trade (rare —
                    // happens when several limits at the same price get hit), we
                    // currently attribute the entire fill to the first match and
                    // warn loudly so the user can investigate. Proper splitting
                    // would require matched_amount per maker_order which the API
                    // does provide but we'd need real data to verify the format.
                    let matches: Vec<String> = trade
                        .get("maker_orders")
                        .and_then(|v| v.as_array())
                        .map(|arr| {
                            let sides = self.order_sides.lock().unwrap_or_else(|e| e.into_inner());
                            arr.iter()
                                .filter_map(|mo| {
                                    let oid = mo.get("order_id").and_then(|v| v.as_str())?;
                                    if sides.contains_key(oid) {
                                        Some(oid.to_string())
                                    } else {
                                        None
                                    }
                                })
                                .collect()
                        })
                        .unwrap_or_default();
                    if matches.len() > 1 {
                        warn!(
                            trade_id = %trade_id,
                            num_matches = matches.len(),
                            "polymarket: trade matched multiple of our maker orders; \
                             attributing fill to first match (sub-fill split not implemented)"
                        );
                    }
                    if matches.is_empty() {
                        // Fallback: maker_orders array exists but none match our
                        // tracked sides (eviction or restart). Try the FIRST
                        // maker_order's id anyway — may not be ours but at least
                        // gives downstream a chance to match by other means.
                        let fallback_id = trade
                            .get("maker_orders")
                            .and_then(|v| v.as_array())
                            .and_then(|arr| arr.first())
                            .and_then(|mo| mo.get("order_id"))
                            .and_then(|v| v.as_str())
                            .unwrap_or("")
                            .to_string();
                        if !fallback_id.is_empty() {
                            warn!(
                                trade_id = %trade_id,
                                fallback_id = %fallback_id,
                                "polymarket: maker fill but no maker_order matched our tracking; using first maker_order id"
                            );
                        }
                        fallback_id
                    } else {
                        matches.into_iter().next().unwrap_or_default()
                    }
                } else {
                    // We were taker — order ID is taker_order_id
                    trade
                        .get("taker_order_id")
                        .or_else(|| trade.get("orderID"))
                        .and_then(|v| v.as_str())
                        .unwrap_or("")
                        .to_string()
                };

                let order_id = our_order_id;

                // CLOB /data/trades uses "asset_id"; data-api uses "asset"; legacy: tokenID
                let market_id = trade
                    .get("asset_id")
                    .or_else(|| trade.get("asset"))
                    .or_else(|| trade.get("tokenID"))
                    .and_then(|v| v.as_str())
                    .unwrap_or("")
                    .to_string();

                let price = trade
                    .get("price")
                    .and_then(|v| v.as_f64().or_else(|| v.as_str().and_then(|s| s.parse().ok())))
                    .unwrap_or(0.0);

                let size = trade
                    .get("size")
                    .and_then(|v| v.as_f64().or_else(|| v.as_str().and_then(|s| s.parse().ok())))
                    .unwrap_or(0.0);

                // Real field is "fee_rate_bps" (bps rate, NOT absolute fee).
                // Compute absolute fee = price * size * fee_rate_bps / 10000
                let fee_rate_bps = trade
                    .get("fee_rate_bps")
                    .and_then(|v| v.as_f64().or_else(|| v.as_str().and_then(|s| s.parse().ok())))
                    .or_else(|| trade.get("fee").and_then(|v| v.as_f64()))
                    .unwrap_or(0.0);
                let fee = if fee_rate_bps > 0.0 {
                    price * size * fee_rate_bps / 10000.0
                } else {
                    0.0
                };

                // Skip fills with non-finite or zero price/size/fee
                if !price.is_finite() || !size.is_finite() || !fee.is_finite() {
                    warn!(
                        fill_id = %trade_id,
                        price = %price,
                        size = %size,
                        fee = %fee,
                        "polymarket: skipping fill with non-finite value"
                    );
                    continue;
                }
                if size <= 0.0 || price <= 0.0 {
                    debug!(
                        fill_id = %trade_id,
                        price = %price,
                        size = %size,
                        "polymarket: skipping fill with zero/negative price or size"
                    );
                    continue;
                }
                // Reject fills without an asset_id — they would be pushed with
                // market_id="" which breaks position attribution downstream.
                if market_id.is_empty() {
                    warn!(
                        fill_id = %trade_id,
                        "polymarket: skipping fill with missing asset_id"
                    );
                    continue;
                }

                let side_str = trade.get("side").and_then(|v| v.as_str()).unwrap_or("BUY");
                let order_side = if side_str.eq_ignore_ascii_case("BUY") {
                    OrderSide::Buy
                } else {
                    OrderSide::Sell
                };

                let fill_id = if trade_id.is_empty() {
                    // Brief scoped lock — released immediately so other code
                    // paths (none currently, but defensive) can acquire next_fill_id.
                    let id = {
                        let mut next_id = self.next_fill_id.lock().unwrap_or_else(|e| e.into_inner());
                        let id = format!("poly_fill_{}", *next_id);
                        *next_id += 1;
                        id
                    };
                    id
                } else {
                    trade_id.to_string()
                };

                // Resolve side using the most reliable source available:
                //   1. trade.outcome field (server-provided, always correct)
                //   2. order_sides[order_id] (our tracking by order ID)
                //   3. token_sides[asset_id] (our tracking by token ID — survives
                //      order_sides eviction and restart from DB-replayed orders)
                //   4. default to Side::Yes with a loud warning
                let side = {
                    let outcome_str = trade.get("outcome").and_then(|v| v.as_str());
                    if let Some(o) = outcome_str {
                        if o.eq_ignore_ascii_case("no") {
                            Side::No
                        } else {
                            Side::Yes
                        }
                    } else {
                        // Try order_sides first (most specific)
                        let from_order = {
                            let sides = self.order_sides.lock().unwrap_or_else(|e| e.into_inner());
                            sides.get(&order_id).copied()
                        };
                        if let Some(s) = from_order {
                            s
                        } else {
                            // Fall back to token_sides (asset_id → side mapping)
                            let from_token = if !market_id.is_empty() {
                                let tokens = self.token_sides.lock().unwrap_or_else(|e| e.into_inner());
                                tokens.get(&market_id).copied()
                            } else {
                                None
                            };
                            match from_token {
                                Some(s) => s,
                                None => {
                                    warn!(
                                        order_id = %order_id,
                                        asset_id = %market_id,
                                        trader_side = %trader_side,
                                        "polymarket: could not resolve fill side from order_sides or token_sides, defaulting to Yes"
                                    );
                                    Side::Yes
                                }
                            }
                        }
                    }
                };

                new_fills.push(Fill {
                    fill_id,
                    order_id,
                    market_id: market_id.clone(),
                    side,
                    order_side,
                    price,
                    size,
                    fee,
                    timestamp: ts,
                    token_id: if market_id.is_empty() { None } else { Some(market_id) },
                    exchange: "polymarket".to_string(),
                    is_maker,
                    multiplier: 1.0,
                });

                // Only commit to dedup AFTER the fill is successfully built and pushed.
                // This way, validation failures (NaN, missing field) don't poison
                // the dedup set with trades that were never returned to the caller.
                {
                    let mut dedup = self.fill_dedup.lock().unwrap_or_else(|e| e.into_inner());
                    dedup.check_and_insert(&dedup_key);
                }
            }

            // Check pagination cursor
            let cursor = json
                .get("next_cursor")
                .and_then(|v| v.as_str())
                .unwrap_or("");

            if cursor.is_empty() || cursor == END_CURSOR {
                break;
            }
            next_cursor = cursor.to_string();
        }

        if max_ts > last_ts {
            if let Ok(mut ts) = self.last_fill_ts.lock() {
                *ts = max_ts;
            }
        }

        if !new_fills.is_empty() {
            info!(count = new_fills.len(), pages = pages, "polymarket: polled new fills");
        }

        Ok(new_fills)
    }

    /// Fetch positions from Polymarket for reconciliation.
    ///
    /// Polymarket positions are NOT on the CLOB host. They live on
    /// data-api.polymarket.com which is unauthenticated and takes a `user`
    /// query parameter (the wallet address that holds the positions).
    ///
    /// For Gnosis Safe accounts, `user` is the Safe (funder) address. For EOA
    /// accounts, `user` is the signer address. py_clob_client does NOT wrap
    /// this endpoint at all — it's documented at docs.polymarket.com.
    ///
    /// Real response field names: asset, conditionId, size, avgPrice, outcome,
    /// outcomeIndex, negativeRisk, curPrice, cashPnl, realizedPnl, proxyWallet.
    async fn fetch_positions_async(&self) -> Result<Vec<crate::types::Position>, HorizonError> {
        // The "user" address for the lookup. For Gnosis Safe, use the funder
        // (Safe address). For EOA, use the signer address. If neither, we can't
        // fetch positions.
        let user_addr = self.funder_address.unwrap_or(self.signer_address);
        if user_addr == [0u8; 20] {
            debug!("polymarket: no wallet address available, skipping position fetch");
            return Ok(Vec::new());
        }
        let user_hex = format!("0x{}", hex::encode(user_addr));

        // data-api.polymarket.com is the canonical positions host (per docs).
        let url = format!(
            "https://data-api.polymarket.com/positions?user={}&sizeThreshold=0",
            user_hex
        );

        let resp = self.client.get(&url).send().await.map_err(|e| {
            HorizonError::Exchange(format!("polymarket: position fetch failed: {}", e))
        })?;

        if !resp.status().is_success() {
            let status = resp.status();
            debug!(status = %status, url = %url, "polymarket: position fetch returned non-200");
            return Ok(Vec::new());
        }

        let json: serde_json::Value = resp.json().await.map_err(|e| {
            HorizonError::Exchange(format!("polymarket: position parse error: {}", e))
        })?;

        let mut positions = Vec::new();
        let arr = json
            .as_array()
            .or_else(|| json.get("positions").and_then(|v| v.as_array()));

        if let Some(arr) = arr {
            for p in arr {
                // Real field is "asset" (the token ID), NOT "asset_id"
                let asset_id = p
                    .get("asset")
                    .or_else(|| p.get("asset_id"))
                    .and_then(|v| v.as_str())
                    .unwrap_or("");

                let size = p
                    .get("size")
                    .and_then(|v| v.as_f64().or_else(|| v.as_str().and_then(|s| s.parse().ok())))
                    .unwrap_or(0.0);

                let avg_price = p
                    .get("avgPrice")
                    .or_else(|| p.get("avg_price"))
                    .and_then(|v| v.as_f64().or_else(|| v.as_str().and_then(|s| s.parse().ok())))
                    .unwrap_or(0.0);

                let realized_pnl = p
                    .get("realizedPnl")
                    .or_else(|| p.get("realized_pnl"))
                    .and_then(|v| v.as_f64().or_else(|| v.as_str().and_then(|s| s.parse().ok())))
                    .unwrap_or(0.0);

                let unrealized_pnl = p
                    .get("cashPnl")
                    .or_else(|| p.get("unrealized_pnl"))
                    .and_then(|v| v.as_f64().or_else(|| v.as_str().and_then(|s| s.parse().ok())))
                    .unwrap_or(0.0);

                if size.abs() > 0.0 && !asset_id.is_empty() {
                    // Determine YES vs NO from outcome (NOT side — that field doesn't exist).
                    // Real field is "outcome": "Yes" or "No"
                    let outcome_str = p
                        .get("outcome")
                        .and_then(|v| v.as_str())
                        .unwrap_or("");
                    let side = if outcome_str.eq_ignore_ascii_case("no") {
                        Side::No
                    } else {
                        if !outcome_str.is_empty() && !outcome_str.eq_ignore_ascii_case("yes") {
                            warn!(
                                outcome = %outcome_str,
                                "polymarket: unknown position outcome, defaulting to YES"
                            );
                        }
                        Side::Yes
                    };
                    positions.push(crate::types::Position {
                        market_id: asset_id.to_string(),
                        side,
                        size,
                        avg_entry_price: avg_price,
                        realized_pnl,
                        unrealized_pnl,
                        token_id: Some(asset_id.to_string()),
                        exchange: "polymarket".to_string(),
                        multiplier: 1.0,
                    });
                }
            }
        }

        if !positions.is_empty() {
            info!(
                count = positions.len(),
                user = %user_hex,
                "polymarket: fetched positions for reconciliation"
            );
        }

        Ok(positions)
    }

    /// Check if an order qualifies for liquidity rewards (blocking).
    pub fn check_order_scoring(&self, order_id: &str) -> Result<bool, HorizonError> {
        self.runtime.block_on(self.check_order_scoring_async(order_id))
    }

    /// Check if an order qualifies for liquidity rewards.
    ///
    /// GET /order-scoring?order_id={order_id} (authenticated)
    async fn check_order_scoring_async(
        &self,
        order_id: &str,
    ) -> Result<bool, HorizonError> {
        let encoded_id: String = url::form_urlencoded::Serializer::new(String::new())
            .append_pair("order_id", order_id)
            .finish();
        let path = format!("/order-scoring?{}", encoded_id);
        let headers = self.auth_headers("GET", &path, "")?;

        let url = format!("{}{}", self.clob_url, path);
        let mut req = self.client.get(&url);
        for (key, value) in &headers {
            req = req.header(key, value);
        }

        let resp = req
            .send()
            .await
            .map_err(|e| HorizonError::Exchange(format!("polymarket: order-scoring request failed: {}", e)))?;

        if !resp.status().is_success() {
            let status = resp.status();
            let body_text = resp.text().await.unwrap_or_default();
            let truncated = super::truncate_utf8(&body_text, 500);
            return Err(HorizonError::Exchange(format!(
                "polymarket: order-scoring HTTP {}: {}",
                status, truncated
            )));
        }

        let body: serde_json::Value = resp
            .json()
            .await
            .map_err(|e| HorizonError::Exchange(format!("polymarket: order-scoring JSON parse failed: {}", e)))?;

        // API returns {"scoring": true/false} or similar boolean indicator
        let scoring = body
            .get("scoring")
            .and_then(|v| v.as_bool())
            .or_else(|| body.get("is_scoring").and_then(|v| v.as_bool()))
            .unwrap_or(false);

        Ok(scoring)
    }

    /// Check USDC balance and token allowance for the connected wallet (blocking).
    ///
    /// Returns (balance, allowance) as f64 in human-readable USDC (6 decimals divided out).
    /// For Gnosis Safe accounts, this passes signature_type as a query parameter so the
    /// CLOB server resolves the correct on-chain address.
    pub fn get_balance_allowance(&self) -> Result<(f64, f64), HorizonError> {
        self.runtime.block_on(self.get_balance_allowance_async(None))
    }

    /// Check the conditional token (YES/NO position) balance and allowance.
    ///
    /// `token_id` is the numeric token identifier (same as used in OrderRequest).
    /// Returns (balance, allowance) in human-readable units.
    pub fn get_token_balance_allowance(&self, token_id: &str) -> Result<(f64, f64), HorizonError> {
        self.runtime.block_on(self.get_balance_allowance_async(Some(token_id)))
    }

    /// GET /balance-allowance?asset_type={COLLATERAL|CONDITIONAL}&signature_type=N&token_id=X
    async fn get_balance_allowance_async(
        &self,
        token_id: Option<&str>,
    ) -> Result<(f64, f64), HorizonError> {
        // CONDITIONAL requires token_id; COLLATERAL is the default USDC balance.
        // URL-encode all query params via form_urlencoded to defend against
        // malformed token_ids that contain special characters.
        let query: String = match token_id {
            Some(tid) => url::form_urlencoded::Serializer::new(String::new())
                .append_pair("asset_type", "CONDITIONAL")
                .append_pair("signature_type", &self.signature_type.to_string())
                .append_pair("token_id", tid)
                .finish(),
            None => url::form_urlencoded::Serializer::new(String::new())
                .append_pair("asset_type", "COLLATERAL")
                .append_pair("signature_type", &self.signature_type.to_string())
                .finish(),
        };
        let path = format!("/balance-allowance?{}", query);
        let headers = self.auth_headers("GET", &path, "")?;
        let url = format!("{}{}", self.clob_url, path);

        let mut req = self.client.get(&url);
        for (key, value) in &headers {
            req = req.header(key, value);
        }

        let resp = req.send().await.map_err(|e| {
            HorizonError::Exchange(format!("polymarket: balance-allowance request failed: {}", e))
        })?;

        if !resp.status().is_success() {
            let status = resp.status();
            let body_text = resp.text().await.unwrap_or_default();
            let truncated = super::truncate_utf8(&body_text, 500);
            return Err(HorizonError::Exchange(format!(
                "polymarket: balance-allowance HTTP {}: {}",
                status, truncated
            )));
        }

        let body: serde_json::Value = resp.json().await.map_err(|e| {
            HorizonError::Exchange(format!("polymarket: balance-allowance JSON parse failed: {}", e))
        })?;

        let balance = body
            .get("balance")
            .and_then(|v| v.as_f64().or_else(|| v.as_str().and_then(|s| s.parse().ok())))
            .unwrap_or(0.0);
        let allowance = body
            .get("allowance")
            .and_then(|v| v.as_f64().or_else(|| v.as_str().and_then(|s| s.parse().ok())))
            .unwrap_or(0.0);

        // Values are in raw units (6 decimals), convert to human-readable
        let decimals = 1_000_000.0;
        Ok((balance / decimals, allowance / decimals))
    }
}

// parse_private_key imported from crypto_utils

impl Exchange for PolymarketExchange {
    fn submit_order(&self, req: &OrderRequest) -> Result<String, HorizonError> {
        // KNOWN LIMITATION (H1, audit-tracked): there is a TOCTOU race window
        // between the HTTP submit and the open_orders insert below. A concurrent
        // cancel_market() called from another Python thread will not see this
        // order until after the insert completes. Single-threaded hz.run() is
        // safe — strategies serialize cancel→submit per cycle. Multi-threaded
        // use of the same Engine requires external synchronization.
        let req_clone = req.clone();
        let order_id = self.runtime.block_on(self.submit_order_async(&req_clone))?;

        // Track order_id per market via shared OrderTracker
        if let Ok(mut tracker) = self.open_orders.lock() {
            tracker.insert(&req.market_id, &order_id);
        }
        // Track order_id -> side for fill side resolution
        if let Ok(mut map) = self.order_sides.lock() {
            // FIFO eviction: remove oldest entries when over cap
            // (was: hard clear of all entries — wiped legitimate side mappings)
            if let Ok(mut order) = self.order_sides_order.lock() {
                // If key already present, don't double-track (shouldn't happen but defensive)
                if map.insert(order_id.clone(), req.side).is_none() {
                    order.push_back(order_id.clone());
                }
                while order.len() > super::MAX_DEDUP_ENTRIES {
                    if let Some(oldest) = order.pop_front() {
                        map.remove(&oldest);
                    } else {
                        break;
                    }
                }
            } else {
                // Lock contention: still insert without tracking order
                map.insert(order_id.clone(), req.side);
            }
        }
        // Also track token_id → side. Token IDs are stable per outcome
        // (YES token != NO token), so this gives us a robust fallback when
        // order_sides eviction or restart wipes the order_id mapping.
        // Uses FIFO eviction so the map can't grow forever for strategies
        // that scan many markets.
        if let Some(token_id) = req.token_id.as_deref() {
            if let Ok(mut tokens) = self.token_sides.lock() {
                if let Ok(mut order) = self.token_sides_order.lock() {
                    if tokens.insert(token_id.to_string(), req.side).is_none() {
                        order.push_back(token_id.to_string());
                    }
                    while order.len() > super::MAX_DEDUP_ENTRIES {
                        if let Some(oldest) = order.pop_front() {
                            tokens.remove(&oldest);
                        } else {
                            break;
                        }
                    }
                } else {
                    tokens.insert(token_id.to_string(), req.side);
                }
            }
        }

        Ok(order_id)
    }

    fn cancel_order(&self, order_id: &str) -> Result<(), HorizonError> {
        let id = order_id.to_string();
        self.runtime.block_on(self.cancel_order_async(&id))?;

        // Remove from open_orders tracking
        if let Ok(mut tracker) = self.open_orders.lock() {
            tracker.remove(order_id);
        }
        // Clean up order_sides for canceled order
        if let Ok(mut sides) = self.order_sides.lock() {
            sides.remove(order_id);
        }
        if let Ok(mut order) = self.order_sides_order.lock() {
            order.retain(|id| id != order_id);
        }

        Ok(())
    }

    fn cancel_all(&self) -> Result<usize, HorizonError> {
        let count = self.runtime.block_on(self.cancel_all_async())?;

        // Clear all tracked orders
        if let Ok(mut tracker) = self.open_orders.lock() {
            tracker.clear();
        }
        // Clear all order_sides tracking
        if let Ok(mut sides) = self.order_sides.lock() {
            sides.clear();
        }
        if let Ok(mut order) = self.order_sides_order.lock() {
            order.clear();
        }

        Ok(count)
    }

    fn cancel_for_market(&self, market_id: &str) -> Result<usize, HorizonError> {
        let order_ids: Vec<String> = {
            let tracker = self.open_orders.lock().unwrap_or_else(|e| e.into_inner());
            tracker.get_market_orders(market_id)
        };

        if order_ids.is_empty() {
            return Ok(0);
        }

        let mut successfully_canceled = Vec::new();
        for oid in &order_ids {
            match self.runtime.block_on(self.cancel_order_async(oid)) {
                Ok(()) => successfully_canceled.push(oid.clone()),
                Err(e) => {
                    debug!(order_id = %oid, error = %e, "polymarket: cancel_for_market: order cancel failed (may already be filled)");
                }
            }
        }

        // Only remove successfully canceled IDs from tracking
        if let Ok(mut tracker) = self.open_orders.lock() {
            tracker.remove_from_market(market_id, &successfully_canceled);
        }

        let canceled = successfully_canceled.len();
        info!(market_id = %market_id, canceled = canceled, total = order_ids.len(), "polymarket: canceled orders for market");
        Ok(canceled)
    }

    fn drain_fills(&self) -> Vec<Fill> {
        match self.runtime.block_on(self.poll_fills_async()) {
            Ok(new_fills) => {
                if !new_fills.is_empty() {
                    // Remove filled order IDs from open_orders tracking
                    if let Ok(mut tracker) = self.open_orders.lock() {
                        let filled_ids: Vec<&str> =
                            new_fills.iter().map(|f| f.order_id.as_str()).collect();
                        tracker.remove_filled(&filled_ids);
                    }
                    // Clean up order_sides for filled orders
                    if let Ok(mut sides) = self.order_sides.lock() {
                        for fill in &new_fills {
                            sides.remove(&fill.order_id);
                        }
                    }
                    if let Ok(mut order) = self.order_sides_order.lock() {
                        let filled_set: std::collections::HashSet<&str> =
                            new_fills.iter().map(|f| f.order_id.as_str()).collect();
                        order.retain(|id| !filled_set.contains(id.as_str()));
                    }
                    if let Ok(mut fills) = self.fills.lock() {
                        fills.extend(new_fills);
                    }
                }
            }
            Err(e) => {
                warn!(error = %e, "polymarket: fill polling error");
            }
        }

        match self.fills.lock() {
            Ok(mut fills) => std::mem::take(&mut *fills),
            Err(_) => {
                error!("polymarket: fills lock poisoned");
                Vec::new()
            }
        }
    }

    fn name(&self) -> &str {
        "polymarket"
    }

    fn fetch_positions(&self) -> Result<Vec<crate::types::Position>, HorizonError> {
        self.runtime.block_on(self.fetch_positions_async())
    }
}

// -- Tests --------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;
    use k256::ecdsa::{RecoveryId, Signature, VerifyingKey};

    #[test]
    fn test_keccak256() {
        let hash = keccak256(b"hello");
        assert_eq!(
            hex::encode(hash),
            "1c8aff950685c2ed4bc3174f3472287b56d9517b9c948127319a09a7a36deac8"
        );
    }

    #[test]
    fn test_u64_to_u256() {
        let result = u64_to_u256(137);
        assert_eq!(result[31], 137);
        assert!(result[..31].iter().all(|&b| b == 0));
    }

    #[test]
    fn test_decimal_str_to_u256_small() {
        let result = decimal_str_to_u256("1000000").unwrap();
        let expected = u128_to_u256(1_000_000);
        assert_eq!(result, expected);
    }

    #[test]
    fn test_address_to_u256() {
        let mut addr = [0u8; 20];
        addr[19] = 0x42;
        let result = address_to_u256(&addr);
        assert_eq!(result[31], 0x42);
        assert!(result[..31].iter().all(|&b| b == 0));
    }

    #[test]
    fn test_derive_address() {
        // Known test vector: private key 1 -> known address
        let key_bytes = hex::decode(
            "0000000000000000000000000000000000000000000000000000000000000001",
        )
        .unwrap();
        let sk = SigningKey::from_bytes((&key_bytes[..]).into()).unwrap();
        let addr = derive_address(&sk);
        let addr_hex = hex::encode(addr);
        // Private key 1 -> 0x7E5F4552091A69125d5DfCb7b8C2659029395Bdf
        assert_eq!(addr_hex, "7e5f4552091a69125d5dfcb7b8c2659029395bdf");
    }

    #[test]
    fn test_domain_separator_deterministic() {
        let contract_bytes = hex::decode(CTF_EXCHANGE).unwrap();
        let mut contract_addr = [0u8; 20];
        contract_addr.copy_from_slice(&contract_bytes);

        let ds1 = domain_separator(&contract_addr);
        let ds2 = domain_separator(&contract_addr);
        assert_eq!(ds1, ds2);
        // Must not be all zeros
        assert!(ds1.iter().any(|&b| b != 0));
    }

    #[test]
    fn test_order_struct_hash_deterministic() {
        let order = CtfOrder {
            salt: 12345,
            maker: [0x42; 20],
            signer: [0x42; 20],
            taker: [0u8; 20],
            token_id: decimal_str_to_u256("100").unwrap(),
            maker_amount: u128_to_u256(500_000),
            taker_amount: u128_to_u256(1_000_000),
            expiration: 0,
            nonce: 0,
            fee_rate_bps: 0,
            side: 0,
            signature_type: 0,
        };

        let h1 = order.struct_hash();
        let h2 = order.struct_hash();
        assert_eq!(h1, h2);
        assert!(h1.iter().any(|&b| b != 0));
    }

    #[test]
    fn test_sign_digest_produces_65_bytes() {
        let key_bytes = hex::decode(
            "0000000000000000000000000000000000000000000000000000000000000001",
        )
        .unwrap();
        let sk = SigningKey::from_bytes((&key_bytes[..]).into()).unwrap();
        let digest = keccak256(b"test message");
        let sig = sign_digest(&sk, &digest).unwrap();
        assert_eq!(sig.len(), 65);
        // v should be 27 or 28
        assert!(sig[64] == 27 || sig[64] == 28);
    }

    #[test]
    fn test_parse_private_key_with_prefix() {
        let sk = parse_private_key(
            "0x0000000000000000000000000000000000000000000000000000000000000001",
        );
        assert!(sk.is_ok());
    }

    #[test]
    fn test_parse_private_key_without_prefix() {
        let sk = parse_private_key(
            "0000000000000000000000000000000000000000000000000000000000000001",
        );
        assert!(sk.is_ok());
    }

    #[test]
    fn test_parse_private_key_invalid() {
        let sk = parse_private_key("not_hex");
        assert!(sk.is_err());
    }

    #[test]
    fn test_eip712_full_sign_round_trip() {
        // Test that we can build, hash, and sign an order end-to-end
        let key_bytes = hex::decode(
            "ac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80",
        )
        .unwrap();
        let sk = SigningKey::from_bytes((&key_bytes[..]).into()).unwrap();
        let addr = derive_address(&sk);

        let order = CtfOrder {
            salt: 1,
            maker: addr,
            signer: addr,
            taker: [0u8; 20],
            token_id: decimal_str_to_u256(
                "52114319501245915516055106046884209969926127482827954674443846427813813222426",
            )
            .unwrap(),
            maker_amount: u128_to_u256(50_000_000), // 50 USDC
            taker_amount: u128_to_u256(100_000_000), // 100 CT
            expiration: 0,
            nonce: 0,
            fee_rate_bps: 0,
            side: 0,
            signature_type: 0,
        };

        let contract_bytes = hex::decode(CTF_EXCHANGE).unwrap();
        let mut contract_addr = [0u8; 20];
        contract_addr.copy_from_slice(&contract_bytes);

        let domain_sep = domain_separator(&contract_addr);
        let digest = order.eip712_digest(&domain_sep);
        let sig = sign_digest(&sk, &digest).unwrap();

        assert_eq!(sig.len(), 65);
        assert!(sig[64] == 27 || sig[64] == 28);

        // Verify we can recover the correct signer
        let recovery_id = RecoveryId::try_from(sig[64] - 27).unwrap();
        let signature = Signature::from_bytes((&sig[..64]).into()).unwrap();
        let recovered_vk =
            VerifyingKey::recover_from_prehash(&digest, &signature, recovery_id).unwrap();

        // Derive address from recovered verifying key
        let recovered_pubkey = recovered_vk.to_encoded_point(false);
        let recovered_hash = keccak256(&recovered_pubkey.as_bytes()[1..]);
        let mut recovered_addr = [0u8; 20];
        recovered_addr.copy_from_slice(&recovered_hash[12..32]);

        // The recovered address must match the maker address
        assert_eq!(recovered_addr, addr);
    }

    #[test]
    fn test_struct_hash_differs_with_signature_type_2() {
        // An order with signature_type=2 must produce a different struct hash
        // than the same order with signature_type=0, because signatureType
        // is part of the EIP-712 struct hash.
        let funder_addr = [0xAA; 20]; // Gnosis Safe address
        let signer_addr = [0x42; 20]; // EOA address

        let order_eoa = CtfOrder {
            salt: 12345,
            maker: signer_addr,
            signer: signer_addr,
            taker: [0u8; 20],
            token_id: decimal_str_to_u256("100").unwrap(),
            maker_amount: u128_to_u256(500_000),
            taker_amount: u128_to_u256(1_000_000),
            expiration: 0,
            nonce: 0,
            fee_rate_bps: 0,
            side: 0,
            signature_type: 0, // EOA
        };

        let order_gnosis = CtfOrder {
            salt: 12345,
            maker: funder_addr, // funder is maker for type 2
            signer: signer_addr,
            taker: [0u8; 20],
            token_id: decimal_str_to_u256("100").unwrap(),
            maker_amount: u128_to_u256(500_000),
            taker_amount: u128_to_u256(1_000_000),
            expiration: 0,
            nonce: 0,
            fee_rate_bps: 0,
            side: 0,
            signature_type: 2, // POLY_GNOSIS_SAFE
        };

        let hash_eoa = order_eoa.struct_hash();
        let hash_gnosis = order_gnosis.struct_hash();

        // Must differ due to different maker and signatureType
        assert_ne!(hash_eoa, hash_gnosis);
        // Both must be non-zero
        assert!(hash_eoa.iter().any(|&b| b != 0));
        assert!(hash_gnosis.iter().any(|&b| b != 0));
    }

    #[test]
    fn test_eip712_sign_round_trip_gnosis_safe() {
        // Test that signing with signature_type=2 still recovers the signer (EOA),
        // even though the maker field is the Gnosis Safe address.
        let key_bytes = hex::decode(
            "ac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80",
        )
        .unwrap();
        let sk = SigningKey::from_bytes((&key_bytes[..]).into()).unwrap();
        let signer_addr = derive_address(&sk);
        let funder_addr = [0xBB; 20]; // Gnosis Safe proxy address

        let order = CtfOrder {
            salt: 42,
            maker: funder_addr,       // Gnosis Safe holds funds
            signer: signer_addr,      // EOA signs the order
            taker: [0u8; 20],
            token_id: decimal_str_to_u256(
                "52114319501245915516055106046884209969926127482827954674443846427813813222426",
            )
            .unwrap(),
            maker_amount: u128_to_u256(50_000_000),
            taker_amount: u128_to_u256(100_000_000),
            expiration: 0,
            nonce: 0,
            fee_rate_bps: 0,
            side: 0,
            signature_type: 2, // POLY_GNOSIS_SAFE
        };

        let contract_bytes = hex::decode(CTF_EXCHANGE).unwrap();
        let mut contract_addr = [0u8; 20];
        contract_addr.copy_from_slice(&contract_bytes);

        let domain_sep = domain_separator(&contract_addr);
        let digest = order.eip712_digest(&domain_sep);
        let sig = sign_digest(&sk, &digest).unwrap();

        assert_eq!(sig.len(), 65);
        assert!(sig[64] == 27 || sig[64] == 28);

        // Recover the signer from the signature
        let recovery_id = RecoveryId::try_from(sig[64] - 27).unwrap();
        let signature = Signature::from_bytes((&sig[..64]).into()).unwrap();
        let recovered_vk =
            VerifyingKey::recover_from_prehash(&digest, &signature, recovery_id).unwrap();
        let recovered_pubkey = recovered_vk.to_encoded_point(false);
        let recovered_hash = keccak256(&recovered_pubkey.as_bytes()[1..]);
        let mut recovered_addr = [0u8; 20];
        recovered_addr.copy_from_slice(&recovered_hash[12..32]);

        // Must recover the SIGNER address (EOA), not the maker/funder
        assert_eq!(recovered_addr, signer_addr);
        assert_ne!(recovered_addr, funder_addr);
    }

    #[test]
    fn test_hmac_output_is_url_safe_base64() {
        // py_clob_client uses urlsafe_b64encode for the signature output.
        // Verify Horizon emits URL-safe base64 (no '+' or '/' chars).
        use base64::Engine as _;

        let rt = Arc::new(
            tokio::runtime::Builder::new_multi_thread()
                .worker_threads(1)
                .enable_all()
                .build()
                .unwrap(),
        );

        let secret_bytes = b"some-secret-key-32-bytes-long!!!";
        let secret_b64 = base64::engine::general_purpose::STANDARD.encode(secret_bytes);

        let exch = PolymarketExchange::new(
            "test-key".to_string(),
            secret_b64,
            "test-pass".to_string(),
            None,
            None,
            rt,
            None,
            0,
        )
        .unwrap();

        // Try many timestamp/path combinations to find a signature that
        // would contain '+' or '/' in standard base64
        let mut found_url_safe_chars = false;
        for ts in 1700000000..1700000100 {
            let sig = exch.sign_hmac(
                &ts.to_string(),
                "GET",
                "/some-path",
                "",
            ).unwrap();
            // URL-safe base64 must not contain '+' or '/'
            assert!(!sig.contains('+'), "signature contains '+': {}", sig);
            assert!(!sig.contains('/'), "signature contains '/': {}", sig);
            // If signature contains '-' or '_', confirms URL-safe encoding active
            if sig.contains('-') || sig.contains('_') {
                found_url_safe_chars = true;
            }
        }
        // Statistically, we should find at least one URL-safe-specific char
        // across 100 trials (probability of all 100 being purely alphanumeric
        // is extremely low).
        assert!(found_url_safe_chars,
            "Expected to find at least one '-' or '_' in 100 sample signatures");
    }

    #[test]
    fn test_poly_address_header_included_when_signing_key_set() {
        use base64::Engine as _;
        let rt = Arc::new(
            tokio::runtime::Builder::new_multi_thread()
                .worker_threads(1)
                .enable_all()
                .build()
                .unwrap(),
        );

        let secret_b64 = base64::engine::general_purpose::STANDARD.encode(b"test-secret");

        // With private key
        let exch_with_key = PolymarketExchange::new(
            "k".to_string(),
            secret_b64.clone(),
            "p".to_string(),
            Some("0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80".to_string()),
            None,
            rt.clone(),
            None,
            0,
        )
        .unwrap();
        let headers = exch_with_key.auth_headers("GET", "/test", "").unwrap();
        let has_address = headers.iter().any(|(k, _)| k == "POLY-ADDRESS");
        assert!(has_address, "POLY-ADDRESS should be present when signing key is set");

        // Without private key
        let exch_no_key = PolymarketExchange::new(
            "k".to_string(),
            secret_b64,
            "p".to_string(),
            None,
            None,
            rt,
            None,
            0,
        )
        .unwrap();
        let headers2 = exch_no_key.auth_headers("GET", "/test", "").unwrap();
        let has_address2 = headers2.iter().any(|(k, _)| k == "POLY-ADDRESS");
        assert!(!has_address2, "POLY-ADDRESS should be absent when no signing key");
    }

    #[test]
    fn test_hmac_signs_path_without_query_string() {
        // py_clob_client signs only the path (not query params).
        // Verify that two paths producing different query strings but the same
        // base path produce the SAME HMAC signature.
        use base64::Engine as _;

        let rt = Arc::new(
            tokio::runtime::Builder::new_multi_thread()
                .worker_threads(1)
                .enable_all()
                .build()
                .unwrap(),
        );

        // Use a real base64-encoded secret
        let secret_bytes = b"test-secret-key-32-bytes-long!!!";
        let secret_b64 = base64::engine::general_purpose::STANDARD.encode(secret_bytes);

        let exch = PolymarketExchange::new(
            "test-key".to_string(),
            secret_b64,
            "test-pass".to_string(),
            None,
            None,
            rt,
            None,
            0,
        )
        .unwrap();

        // Sign the bare path
        let h_bare = exch.auth_headers("GET", "/balance-allowance", "").unwrap();
        // Sign the same path with query string
        let h_query = exch
            .auth_headers("GET", "/balance-allowance?asset_type=COLLATERAL&signature_type=2", "")
            .unwrap();

        // Find the signature header in each (POLY-SIGNATURE)
        let sig_bare = h_bare.iter().find(|(k, _)| k == "POLY-SIGNATURE").unwrap().1.clone();
        let sig_query = h_query.iter().find(|(k, _)| k == "POLY-SIGNATURE").unwrap().1.clone();

        // Note: timestamps will differ if a second elapses between calls,
        // but the signatures should follow the same path-stripping logic.
        // We can't compare them directly because of timestamp drift, but we
        // can verify the path-stripping by signing twice with the same timestamp.
        let ts = "1700000000";
        let sig_a = exch.sign_hmac(ts, "GET", "/balance-allowance", "").unwrap();
        let sig_b = exch.sign_hmac(ts, "GET", "/balance-allowance", "").unwrap();
        assert_eq!(sig_a, sig_b, "deterministic signing");

        // The fix: auth_headers strips query params before passing to sign_hmac.
        // Verify by manually constructing the message both ways.
        let msg_with_query = format!("{}{}{}{}", ts, "GET",
            "/balance-allowance?asset_type=COLLATERAL", "");
        let msg_without_query = format!("{}{}{}{}", ts, "GET", "/balance-allowance", "");
        assert_ne!(msg_with_query, msg_without_query,
            "messages must differ when query string is included");
    }

    fn make_test_exchange() -> PolymarketExchange {
        use base64::Engine as _;
        let rt = Arc::new(
            tokio::runtime::Builder::new_multi_thread()
                .worker_threads(1)
                .enable_all()
                .build()
                .unwrap(),
        );
        let secret_b64 = base64::engine::general_purpose::STANDARD.encode(b"test-secret");
        PolymarketExchange::new(
            "test-key".to_string(),
            secret_b64,
            "test-pass".to_string(),
            Some("0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80".to_string()),
            None,
            rt,
            None,
            0,
        )
        .unwrap()
    }

    #[test]
    fn test_salt_fits_in_i63() {
        // Verify our salt mask never produces a value with the high bit set
        // (which would overflow Go's int64 JSON parser).
        let exch = make_test_exchange();
        for _ in 0..1000 {
            let req = OrderRequest {
                market_id: "test".to_string(),
                side: Side::Yes,
                order_side: OrderSide::Buy,
                size: 1.0,
                price: 0.5,
                order_type: crate::types::OrderType::Limit,
                time_in_force: crate::types::TimeInForce::GTC,
                post_only: true,
                token_id: Some("12345".to_string()),
                neg_risk: false,
            };
            let body = exch.build_signed_order(&req, false).unwrap();
            let salt = body.get("order").and_then(|o| o.get("salt")).and_then(|v| v.as_u64()).unwrap();
            assert!(salt <= 0x7FFF_FFFF_FFFF_FFFF, "salt {} exceeds i63 max", salt);
        }
    }

    #[test]
    fn test_order_body_uses_correct_field_names() {
        // Verify the JSON body matches py_clob_client field names exactly:
        // - tokenId (lowercase d)
        // - signatureType (number, not string)
        // - salt (number, not string)
        // - postOnly (always present)
        // - owner (api_key, not address)
        let exch = make_test_exchange();
        let req = OrderRequest {
            market_id: "test".to_string(),
            side: Side::Yes,
            order_side: OrderSide::Buy,
            size: 1.0,
            price: 0.5,
            order_type: crate::types::OrderType::Limit,
            time_in_force: crate::types::TimeInForce::GTC,
            post_only: true,
            token_id: Some("12345".to_string()),
            neg_risk: false,
        };
        let body = exch.build_signed_order(&req, false).unwrap();
        let order = body.get("order").unwrap();

        // Field naming
        assert!(order.get("tokenId").is_some(), "must use tokenId (lowercase d)");
        assert!(order.get("tokenID").is_none(), "must NOT use tokenID");

        // Numeric types
        assert!(order.get("salt").unwrap().is_u64(), "salt must be JSON number");
        assert!(order.get("signatureType").unwrap().is_u64(), "signatureType must be JSON number");

        // String types
        assert!(order.get("makerAmount").unwrap().is_string(), "makerAmount must be string");
        assert!(order.get("takerAmount").unwrap().is_string(), "takerAmount must be string");
        assert!(order.get("expiration").unwrap().is_string(), "expiration must be string");
        assert!(order.get("nonce").unwrap().is_string(), "nonce must be string");
        assert!(order.get("feeRateBps").unwrap().is_string(), "feeRateBps must be string");

        // Outer envelope
        assert_eq!(body.get("owner").unwrap().as_str().unwrap(), "test-key", "owner must be api_key");
        assert!(body.get("postOnly").is_some(), "postOnly must always be present");
        assert_eq!(body.get("postOnly").unwrap().as_bool().unwrap(), true, "post_only=true should be respected");

        // Side string
        assert_eq!(order.get("side").unwrap().as_str().unwrap(), "BUY");
    }

    #[test]
    fn test_post_only_false_respected() {
        let exch = make_test_exchange();
        let req = OrderRequest {
            market_id: "test".to_string(),
            side: Side::Yes,
            order_side: OrderSide::Buy,
            size: 1.0,
            price: 0.5,
            order_type: crate::types::OrderType::Limit,
            time_in_force: crate::types::TimeInForce::GTC,
            post_only: false,  // Explicitly false
            token_id: Some("12345".to_string()),
            neg_risk: false,
        };
        let body = exch.build_signed_order(&req, false).unwrap();
        assert_eq!(body.get("postOnly").unwrap().as_bool().unwrap(), false,
            "post_only=false must be respected on the wire");
    }

    #[test]
    fn test_json_field_order_preserved() {
        // serde_json/preserve_order must be enabled, so the JSON output respects
        // the order we set in the json! macro. Verify by checking that the
        // serialized bytes have "order" before "owner" before "orderType".
        let exch = make_test_exchange();
        let req = OrderRequest {
            market_id: "test".to_string(),
            side: Side::Yes,
            order_side: OrderSide::Buy,
            size: 1.0,
            price: 0.5,
            order_type: crate::types::OrderType::Limit,
            time_in_force: crate::types::TimeInForce::GTC,
            post_only: true,
            token_id: Some("12345".to_string()),
            neg_risk: false,
        };
        let body = exch.build_signed_order(&req, false).unwrap();
        let s = serde_json::to_string(&body).unwrap();
        let order_pos = s.find(r#""order""#).unwrap();
        let owner_pos = s.find(r#""owner""#).unwrap();
        let order_type_pos = s.find(r#""orderType""#).unwrap();
        let post_only_pos = s.find(r#""postOnly""#).unwrap();
        assert!(order_pos < owner_pos, "order must come before owner");
        assert!(owner_pos < order_type_pos, "owner must come before orderType");
        assert!(order_type_pos < post_only_pos, "orderType must come before postOnly");
    }

    #[test]
    fn test_serialize_to_vec_matches_to_string() {
        // Defensive: serde_json::to_vec and to_string must produce identical bytes
        // for the same Value. This is what makes "serialize once, sign and send
        // the same bytes" safe.
        let v = serde_json::json!({
            "order": {
                "salt": 12345_u64,
                "maker": "0xabc",
                "tokenId": "999",
            },
            "owner": "k",
            "orderType": "GTC",
            "postOnly": true,
        });
        let s1 = v.to_string();
        let s2 = String::from_utf8(serde_json::to_vec(&v).unwrap()).unwrap();
        assert_eq!(s1, s2, "to_string and to_vec must produce identical bytes");
    }

    #[test]
    fn test_token_sides_tracked_on_submit() {
        // Verify that submitting an order populates the token_sides map for
        // future fill resolution fallback.
        let exch = make_test_exchange();
        // Manually exercise the tracking logic (we can't actually submit without network)
        let token_id = "12345678901234567890";
        if let Ok(mut tokens) = exch.token_sides.lock() {
            tokens.insert(token_id.to_string(), Side::No);
        }
        let stored = exch.token_sides.lock().unwrap().get(token_id).copied();
        assert_eq!(stored, Some(Side::No));
    }

    #[test]
    fn test_order_type_hash_is_cached() {
        // LazyLock should return the same hash on every call without recomputing
        let h1 = order_type_hash();
        let h2 = order_type_hash();
        let h3 = order_type_hash();
        assert_eq!(h1, h2);
        assert_eq!(h2, h3);
        // Sanity: it's not all zeros
        assert!(h1.iter().any(|&b| b != 0));
    }
}
