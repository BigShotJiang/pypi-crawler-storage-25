//! Kalshi REST exchange client.
//!
//! Implements the Exchange trait for Kalshi's trading API. Uses the modern
//! RSA-PSS API key authentication scheme (the legacy email/password login
//! was retired in 2024). Each request is signed with the user's RSA private
//! key and verified by Kalshi against their stored public key.
//!
//! Auth headers per request:
//!   - KALSHI-ACCESS-KEY:       the API key UUID (`key_id`)
//!   - KALSHI-ACCESS-TIMESTAMP: current Unix milliseconds as a string
//!   - KALSHI-ACCESS-SIGNATURE: base64(RSA-PSS-SHA256(priv_key, ts+method+path))
//!
//! See https://docs.kalshi.com/getting_started/api_keys for the official spec.

use crate::error::HorizonError;
use crate::exchanges::fill_dedup::FillDedup;
use crate::exchanges::order_tracker::OrderTracker;
use crate::exchanges::Exchange;
use crate::types::{Fill, OrderRequest, OrderSide, Side};
use base64::Engine as _;
use rsa::pkcs1::DecodeRsaPrivateKey;
use rsa::pkcs8::DecodePrivateKey;
use rsa::pss::SigningKey as PssSigningKey;
use rsa::sha2::Sha256 as RsaSha256;
use rsa::signature::{RandomizedSigner, SignatureEncoding};
use rsa::RsaPrivateKey;
use std::sync::{Arc, Mutex, RwLock};
use std::time::{SystemTime, UNIX_EPOCH};
use tracing::{debug, error, info, warn};
use zeroize::Zeroizing;

/// Modern Kalshi host. The old `trading-api.kalshi.com` was retired in 2024.
const DEFAULT_API_URL: &str = "https://api.elections.kalshi.com/trade-api/v2";

/// Validate that a URL path parameter contains only safe characters.
/// Prevents path injection via order IDs, tickers, etc.
fn validate_url_param(param: &str, name: &str) -> Result<(), HorizonError> {
    if param.is_empty() {
        return Err(HorizonError::Exchange(format!("kalshi: {} is empty", name)));
    }
    if !param
        .bytes()
        .all(|b| b.is_ascii_alphanumeric() || b == b'-' || b == b'_')
    {
        return Err(HorizonError::Exchange(format!(
            "kalshi: invalid characters in {}",
            name
        )));
    }
    Ok(())
}

/// Parse a simple ISO 8601 timestamp to Unix seconds.
/// Handles formats like "2024-01-15T12:00:00Z" and "2024-01-15T12:00:00.123Z".
fn parse_iso8601_to_unix(s: &str) -> Option<f64> {
    // Expected: YYYY-MM-DDTHH:MM:SS[.fff]Z
    let s = s.trim_end_matches('Z');
    let (date_part, time_part) = s.split_once('T')?;
    let mut date_iter = date_part.split('-');
    let year: i64 = date_iter.next()?.parse().ok()?;
    let month: i64 = date_iter.next()?.parse().ok()?;
    let day: i64 = date_iter.next()?.parse().ok()?;

    let (time_whole, frac) = if let Some((w, f)) = time_part.split_once('.') {
        let frac_secs: f64 = format!("0.{}", f).parse().unwrap_or(0.0);
        (w, frac_secs)
    } else {
        (time_part, 0.0)
    };

    let mut time_iter = time_whole.split(':');
    let hour: i64 = time_iter.next()?.parse().ok()?;
    let min: i64 = time_iter.next()?.parse().ok()?;
    let sec: i64 = time_iter.next()?.parse().ok()?;

    // Validate date/time ranges to prevent panics
    if month < 1 || month > 12 || day < 1 || day > 31 {
        return None;
    }
    if hour < 0 || hour > 23 || min < 0 || min > 59 || sec < 0 || sec > 59 {
        return None;
    }

    // Per-month day validation
    let max_days = match month {
        1 | 3 | 5 | 7 | 8 | 10 | 12 => 31,
        4 | 6 | 9 | 11 => 30,
        2 => if is_leap(year) { 29 } else { 28 },
        _ => return None,
    };
    if day > max_days {
        return None;
    }

    // Days from year 1970 to the given date (simplified, no leap second handling)
    let mut days: i64 = 0;
    for y in 1970..year {
        days += if is_leap(y) { 366 } else { 365 };
    }
    let month_days = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    for m in 1..month {
        days += month_days[m as usize];
        if m == 2 && is_leap(year) {
            days += 1;
        }
    }
    days += day - 1;

    let total_secs = days * 86400 + hour * 3600 + min * 60 + sec;
    Some(total_secs as f64 + frac)
}

fn is_leap(y: i64) -> bool {
    (y % 4 == 0 && y % 100 != 0) || y % 400 == 0
}

pub struct KalshiExchange {
    api_url: String,
    /// API key UUID (Kalshi's `key_id`). Sent in KALSHI-ACCESS-KEY header.
    key_id: Option<Zeroizing<String>>,
    /// RSA private key for signing requests (parsed from PEM).
    /// None means auth is unavailable and authenticated calls will error.
    rsa_key: Option<Arc<RsaPrivateKey>>,
    /// Legacy fields kept for API backward compatibility but no longer used.
    /// The email/password endpoint was retired by Kalshi in 2024.
    _legacy_email: Option<Zeroizing<String>>,
    _legacy_password: Option<Zeroizing<String>>,
    /// Auth token storage retained for compat with older code paths but unused.
    _auth_token: RwLock<Option<Zeroizing<String>>>,
    client: reqwest::Client,
    runtime: Arc<tokio::runtime::Runtime>,
    fills: Mutex<Vec<Fill>>,
    next_fill_id: Mutex<u64>,
    /// Cursor for incremental fill polling.
    last_fill_cursor: Mutex<Option<String>>,
    /// Tracks open order IDs per market (shared OrderTracker).
    open_orders: Mutex<OrderTracker>,
    /// Deduplicates fill IDs with FIFO eviction (shared FillDedup).
    fill_dedup: Mutex<FillDedup>,
}

impl KalshiExchange {
    /// Construct a Kalshi exchange client.
    ///
    /// For modern (working) auth, pass `api_key` (the key_id UUID) and
    /// `password` (the RSA private key in PEM format). The old email-based
    /// auth flow was retired by Kalshi in 2024 and the legacy `email`
    /// parameter is no longer functional.
    pub fn new(
        email: Option<String>,
        password: Option<String>,
        api_key: Option<String>,
        api_url: Option<String>,
        runtime: Arc<tokio::runtime::Runtime>,
    ) -> Self {
        // Try to parse `password` as a PEM-encoded RSA private key.
        // We piggyback on the existing `password` field so the Python
        // dataclass doesn't need a brand-new field. PKCS#8 (BEGIN PRIVATE KEY)
        // is preferred; PKCS#1 (BEGIN RSA PRIVATE KEY) is also accepted.
        let rsa_key: Option<Arc<RsaPrivateKey>> = password.as_deref().and_then(|pem| {
            if pem.contains("BEGIN") && pem.contains("PRIVATE KEY") {
                let parsed = RsaPrivateKey::from_pkcs8_pem(pem)
                    .or_else(|_| RsaPrivateKey::from_pkcs1_pem(pem));
                match parsed {
                    Ok(k) => {
                        info!("kalshi: loaded RSA private key for API key auth");
                        Some(Arc::new(k))
                    }
                    Err(e) => {
                        warn!(error = %e, "kalshi: failed to parse private_key as PEM, RSA auth disabled");
                        None
                    }
                }
            } else {
                // Not a PEM — treat as legacy password (broken, but stored for compat)
                None
            }
        });

        Self {
            api_url: api_url.unwrap_or_else(|| DEFAULT_API_URL.to_string()),
            key_id: api_key.map(Zeroizing::new),
            rsa_key,
            _legacy_email: email.map(Zeroizing::new),
            _legacy_password: password.map(Zeroizing::new),
            _auth_token: RwLock::new(None),
            client: reqwest::Client::builder()
                .timeout(std::time::Duration::from_secs(30))
                .connect_timeout(std::time::Duration::from_secs(10))
                .build()
                .unwrap_or_else(|_| reqwest::Client::new()),
            runtime,
            fills: Mutex::new(Vec::new()),
            next_fill_id: Mutex::new(1),
            last_fill_cursor: Mutex::new(None),
            open_orders: Mutex::new(OrderTracker::new("kalshi")),
            fill_dedup: Mutex::new(FillDedup::new()),
        }
    }

    /// Build Kalshi RSA-PSS-SHA256 auth headers for a request.
    ///
    /// Sign message format: `{timestamp_ms}{METHOD}{path_without_query}`.
    /// Returns the three KALSHI-ACCESS-* headers plus Content-Type.
    fn auth_headers(&self, method: &str, path: &str) -> Result<Vec<(String, String)>, HorizonError> {
        let key_id = self.key_id.as_ref().ok_or_else(|| {
            HorizonError::Exchange("kalshi: api_key (key_id) required for authenticated requests".into())
        })?;
        let rsa_key = self.rsa_key.as_ref().ok_or_else(|| {
            HorizonError::Exchange(
                "kalshi: RSA private key required. Pass the PEM-encoded private key as the \
                 `password` parameter (Kalshi switched to RSA-PSS API keys in 2024 — the old \
                 email/password login no longer exists)."
                    .into(),
            )
        })?;

        // Strip any query string before signing — match Polymarket/py_clob_client pattern
        let sign_path = match path.find('?') {
            Some(idx) => &path[..idx],
            None => path,
        };

        let timestamp_ms = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map(|d| d.as_millis() as u64)
            .unwrap_or(0)
            .to_string();

        let message = format!("{}{}{}", timestamp_ms, method, sign_path);

        // RSA-PSS-SHA256 sign
        let signing_key = PssSigningKey::<RsaSha256>::new(rsa_key.as_ref().clone());
        let mut rng = rand::thread_rng();
        let signature = signing_key.sign_with_rng(&mut rng, message.as_bytes());
        let sig_b64 = base64::engine::general_purpose::STANDARD.encode(signature.to_bytes());

        Ok(vec![
            ("KALSHI-ACCESS-KEY".to_string(), (**key_id).clone()),
            ("KALSHI-ACCESS-TIMESTAMP".to_string(), timestamp_ms),
            ("KALSHI-ACCESS-SIGNATURE".to_string(), sig_b64),
            ("Content-Type".to_string(), "application/json".to_string()),
        ])
    }

    /// Apply RSA-PSS auth headers to a reqwest builder.
    /// Replaces the legacy `bearer_auth(token)` pattern.
    fn apply_auth(
        &self,
        mut builder: reqwest::RequestBuilder,
        method: &str,
        path: &str,
    ) -> Result<reqwest::RequestBuilder, HorizonError> {
        let headers = self.auth_headers(method, path)?;
        for (k, v) in headers {
            builder = builder.header(k, v);
        }
        Ok(builder)
    }

    /// LEGACY (DEAD): /login was retired in 2024. Always errors now.
    #[allow(dead_code)]
    async fn login(&self) -> Result<String, HorizonError> {
        Err(HorizonError::Exchange(
            "kalshi: legacy email/password login is no longer supported by Kalshi. \
             Use RSA-PSS API key auth (pass key_id as `api_key` and PEM private key \
             as `password`)."
                .into(),
        ))
    }

    /// LEGACY: returns an empty token to satisfy old call sites that haven't
    /// been migrated. Real auth happens via apply_auth() per-request.
    #[allow(dead_code)]
    async fn get_token(&self) -> Result<String, HorizonError> {
        Ok(String::new())
    }

    /// LEGACY no-op: there's no cached token in the new RSA-PSS scheme.
    #[allow(dead_code)]
    fn clear_token(&self) {
        if let Ok(mut guard) = self._auth_token.write() {
            *guard = None;
        }
    }

    /// Convert Side + OrderSide to Kalshi action and side strings.
    ///
    /// Kalshi uses:
    /// - "action": "buy" or "sell"
    /// - "side": "yes" or "no"
    ///
    /// Mapping:
    /// - Buy Yes  → action=buy,  side=yes
    /// - Sell Yes → action=sell, side=yes
    /// - Buy No   → action=buy,  side=no
    /// - Sell No  → action=sell, side=no
    fn kalshi_action(order_side: OrderSide) -> &'static str {
        match order_side {
            OrderSide::Buy => "buy",
            OrderSide::Sell => "sell",
        }
    }

    fn kalshi_side(side: Side) -> &'static str {
        match side {
            Side::Yes => "yes",
            Side::No => "no",
            Side::Long => "yes", // Kalshi only supports Yes/No; default Long to Yes
        }
    }

    /// Map OrderType to Kalshi type string.
    fn kalshi_order_type(order_type: crate::types::OrderType) -> &'static str {
        match order_type {
            crate::types::OrderType::Market => "market",
            crate::types::OrderType::Limit => "limit",
        }
    }

    /// Map TimeInForce to Kalshi time_in_force string.
    /// For market orders, always returns "fill_or_kill".
    fn kalshi_tif(order_type: crate::types::OrderType, tif: crate::types::TimeInForce) -> &'static str {
        if order_type == crate::types::OrderType::Market {
            return "fill_or_kill";
        }
        match tif {
            crate::types::TimeInForce::GTC => "good_till_canceled",
            crate::types::TimeInForce::FOK => "fill_or_kill",
            crate::types::TimeInForce::FAK => "immediate_or_cancel",
            crate::types::TimeInForce::GTD => {
                tracing::warn!("kalshi: GTD time-in-force not supported, downgrading to GTC");
                "good_till_canceled"
            }
        }
    }

    /// Submit order to Kalshi, with automatic retry on 401 and 429.
    async fn submit_order_async(&self, req: &OrderRequest) -> Result<String, HorizonError> {
        let url = format!("{}/portfolio/orders", self.api_url);
        let path = "/trade-api/v2/portfolio/orders";
        // Validate price bounds before conversion to avoid undefined f64→i64 casts
        if req.order_type != crate::types::OrderType::Market
            && (req.price < 0.01 || req.price > 0.99 || req.price.is_nan())
        {
            return Err(HorizonError::Exchange(format!(
                "invalid price for Kalshi: {}", req.price
            )));
        }
        if req.size <= 0.0 || req.size.is_nan() {
            return Err(HorizonError::Exchange(format!(
                "invalid size for Kalshi: {}", req.size
            )));
        }
        let count = req.size.round() as i64;
        if count < 1 {
            return Err(HorizonError::Exchange(format!(
                "kalshi: order size {} rounds to {} contracts (minimum 1)",
                req.size, count
            )));
        }
        let tif_str = Self::kalshi_tif(req.order_type, req.time_in_force);
        let is_market = req.order_type == crate::types::OrderType::Market;
        // Kalshi's modern API uses fixed-point dollar STRINGS for prices, not
        // integer cents. e.g. "0.5600" not 56. The legacy yes_price/no_price
        // integer-cents fields still exist but are deprecated.
        let price_dollars = format!("{:.4}", req.price);

        // Note: the modern CreateOrderRequest schema does NOT have a "type"
        // field. Market vs limit is inferred from whether a price is supplied
        // and from buy_max_cost. We don't send "type" anymore.
        let body = match req.side {
            Side::Yes | Side::Long => {
                let mut obj = serde_json::json!({
                    "ticker": req.market_id,
                    "action": Self::kalshi_action(req.order_side),
                    "side": "yes",
                    "count": count,
                    "time_in_force": tif_str,
                });
                if !is_market {
                    obj["yes_price_dollars"] = serde_json::Value::String(price_dollars.clone());
                }
                obj
            }
            Side::No => {
                let mut obj = serde_json::json!({
                    "ticker": req.market_id,
                    "action": Self::kalshi_action(req.order_side),
                    "side": "no",
                    "count": count,
                    "time_in_force": tif_str,
                });
                if !is_market {
                    obj["no_price_dollars"] = serde_json::Value::String(price_dollars.clone());
                }
                obj
            }
        };

        debug!(
            market = %req.market_id,
            action = Self::kalshi_action(req.order_side),
            side = Self::kalshi_side(req.side),
            price_dollars = %price_dollars,
            count = count,
            "kalshi: submitting order"
        );

        let mut backoff_ms: u64 = 1000;

        for attempt in 0..5u32 {
            let req_builder = self.client.post(&url).json(&body);
            let req_builder = self.apply_auth(req_builder, "POST", path)?;

            let resp = req_builder
                .send()
                .await
                .map_err(|e| HorizonError::Exchange(format!("kalshi order failed for market {}: {}", req.market_id, e)))?;

            let status_code = resp.status().as_u16();

            if status_code == 429 && attempt < 4 {
                warn!(attempt = attempt + 1, backoff_ms = backoff_ms, "kalshi: rate limited (429), retrying");
                tokio::time::sleep(tokio::time::Duration::from_millis(backoff_ms)).await;
                backoff_ms = (backoff_ms * 2).min(30_000);
                continue;
            }

            if !resp.status().is_success() {
                let status = resp.status();
                let body_text = resp.text().await.unwrap_or_default();
                error!(status = %status, body = %body_text, "kalshi: order rejected");
                return Err(HorizonError::Exchange(format!(
                    "kalshi order rejected ({}): {}",
                    status, body_text
                )));
            }

            let json: serde_json::Value = resp
                .json()
                .await
                .map_err(|e| HorizonError::Exchange(format!("kalshi parse error: {}", e)))?;

            let order_id = json
                .get("order")
                .and_then(|o| o.get("order_id"))
                .and_then(|v| v.as_str())
                .filter(|s| !s.is_empty())
                .map(|s| s.to_string())
                .ok_or_else(|| {
                    HorizonError::Exchange(format!(
                        "kalshi: response missing order_id: {}",
                        json
                    ))
                })?;

            info!(order_id = %order_id, "kalshi: order accepted");
            return Ok(order_id);
        }

        Err(HorizonError::Exchange(format!("kalshi: retry attempts exhausted for market {}", req.market_id)))
    }

    /// Cancel a single order on Kalshi.
    async fn cancel_order_async(&self, order_id: &str) -> Result<(), HorizonError> {
        validate_url_param(order_id, "order_id")?;
        let url = format!("{}/portfolio/orders/{}", self.api_url, order_id);
        let path = format!("/trade-api/v2/portfolio/orders/{}", order_id);

        let req_builder = self.client.delete(&url);
        let req_builder = self.apply_auth(req_builder, "DELETE", &path)?;

        let resp = req_builder
            .send()
            .await
            .map_err(|e| HorizonError::Exchange(format!("kalshi cancel failed for order {}: {}", order_id, e)))?;

        if !resp.status().is_success() {
            let status = resp.status();
            let body = resp.text().await.unwrap_or_default();
            return Err(HorizonError::Exchange(format!(
                "kalshi cancel failed ({}): {}",
                status, body
            )));
        }

        debug!(order_id = %order_id, "kalshi: order canceled");
        Ok(())
    }

    /// Cancel all open orders by looping through tracked IDs.
    /// Kalshi has no DELETE /portfolio/orders collection endpoint — the
    /// only options are per-order cancel or DELETE /portfolio/orders/batched
    /// (max 20 IDs per call, more complex). We loop the local tracker.
    async fn cancel_all_async(&self) -> Result<usize, HorizonError> {
        let order_ids: Vec<String> = {
            let tracker = self.open_orders.lock().unwrap_or_else(|e| e.into_inner());
            tracker.all_orders()
        };

        if order_ids.is_empty() {
            return Ok(0);
        }

        let mut canceled = 0;
        for oid in &order_ids {
            match self.cancel_order_async(oid).await {
                Ok(()) => canceled += 1,
                Err(e) => {
                    debug!(order_id = %oid, error = %e, "kalshi: cancel-all: order cancel failed (may already be filled)");
                }
            }
        }

        info!(canceled = canceled, total = order_ids.len(), "kalshi: cancel_all complete");
        Ok(canceled)
    }

    /// Poll for recent fills from Kalshi.
    async fn poll_fills_async(&self) -> Result<Vec<Fill>, HorizonError> {
        // Skip if no auth configured
        if self.rsa_key.is_none() || self.key_id.is_none() {
            debug!("kalshi: skipping fill poll (no auth configured)");
            return Ok(Vec::new());
        }

        let path_base = "/trade-api/v2/portfolio/fills";
        let mut url = format!("{}/portfolio/fills", self.api_url);

        // Add cursor for incremental polling (URL-encoded to prevent injection)
        if let Ok(cursor) = self.last_fill_cursor.lock() {
            if let Some(ref c) = *cursor {
                let encoded: String =
                    url::form_urlencoded::Serializer::new(String::new())
                        .append_pair("cursor", c)
                        .finish();
                url = format!("{}?{}", url, encoded);
            }
        }

        let req_builder = self.client.get(&url);
        let req_builder = self.apply_auth(req_builder, "GET", path_base)?;

        let resp = req_builder
            .send()
            .await
            .map_err(|e| {
                HorizonError::Exchange(format!("kalshi: fill poll failed: {}", e))
            })?;

        if !resp.status().is_success() {
            let status = resp.status();
            debug!(status = %status, "kalshi: fill poll returned non-200");
            return Ok(Vec::new());
        }

        let json: serde_json::Value = resp.json().await.map_err(|e| {
            HorizonError::Exchange(format!("kalshi: fill parse error: {}", e))
        })?;

        // Update cursor for next poll
        if let Some(cursor) = json.get("cursor").and_then(|v| v.as_str()) {
            if !cursor.is_empty() {
                if let Ok(mut guard) = self.last_fill_cursor.lock() {
                    *guard = Some(cursor.to_string());
                }
            }
        }

        let mut new_fills = Vec::new();

        // Kalshi /portfolio/fills response: {"fills": [...], "cursor": "..."}
        let fills_arr = json.get("fills").and_then(|v| v.as_array());

        if let Some(fills_arr) = fills_arr {
            let mut next_id = self.next_fill_id.lock().unwrap_or_else(|e| e.into_inner());

            for fill_json in fills_arr {
                let fill_id_str = fill_json
                    .get("fill_id")
                    .or_else(|| fill_json.get("id"))
                    .and_then(|v| v.as_str())
                    .unwrap_or("");

                let order_id = fill_json
                    .get("order_id")
                    .and_then(|v| v.as_str())
                    .unwrap_or("")
                    .to_string();

                let ticker = fill_json
                    .get("ticker")
                    .and_then(|v| v.as_str())
                    .unwrap_or("")
                    .to_string();

                // Kalshi modern API uses fixed-point dollar STRINGS.
                // count_fp is a string like "10.00", legacy `count` is an int.
                // Helper to parse a numeric-or-string field as f64.
                let parse_num = |val: Option<&serde_json::Value>| -> f64 {
                    val.and_then(|v| {
                        v.as_f64()
                            .or_else(|| v.as_i64().map(|i| i as f64))
                            .or_else(|| v.as_str().and_then(|s| s.parse::<f64>().ok()))
                    })
                    .unwrap_or(0.0)
                };

                let count = parse_num(fill_json.get("count_fp"))
                    .max(parse_num(fill_json.get("count")));

                let action = fill_json.get("action").and_then(|v| v.as_str()).unwrap_or("buy");
                let side_str = fill_json.get("side").and_then(|v| v.as_str()).unwrap_or("yes");

                let order_side = if action.eq_ignore_ascii_case("buy") {
                    OrderSide::Buy
                } else {
                    OrderSide::Sell
                };

                let side = if side_str.eq_ignore_ascii_case("yes") {
                    Side::Yes
                } else {
                    Side::No
                };

                // Modern Kalshi API: yes_price_dollars / no_price_dollars are
                // fixed-point dollar STRINGS like "0.5600". The legacy
                // yes_price/no_price integer-cents fields may also exist.
                let price = if side == Side::No {
                    let dollars = parse_num(fill_json.get("no_price_dollars"));
                    if dollars > 0.0 {
                        dollars
                    } else {
                        parse_num(fill_json.get("no_price").or_else(|| fill_json.get("price"))) / 100.0
                    }
                } else {
                    let dollars = parse_num(fill_json.get("yes_price_dollars"));
                    if dollars > 0.0 {
                        dollars
                    } else {
                        parse_num(fill_json.get("yes_price").or_else(|| fill_json.get("price"))) / 100.0
                    }
                };

                let ts = fill_json
                    .get("created_time")
                    .or_else(|| fill_json.get("ts"))
                    .and_then(|v| {
                        v.as_f64().or_else(|| v.as_str().and_then(|s| {
                            s.parse::<f64>().ok().or_else(|| parse_iso8601_to_unix(s))
                        }))
                    })
                    .unwrap_or(0.0);

                let fill_id = if fill_id_str.is_empty() {
                    let id = format!("kalshi_fill_{}", *next_id);
                    *next_id += 1;
                    id
                } else {
                    fill_id_str.to_string()
                };

                // Dedup via shared FillDedup
                {
                    let mut dedup = self.fill_dedup.lock().unwrap_or_else(|e| e.into_inner());
                    if !dedup.check_and_insert(&fill_id) {
                        continue;
                    }
                }

                // Modern: fee_cost is FixedPointDollars string. Legacy: fee in cents.
                let fee = {
                    let dollars = parse_num(fill_json.get("fee_cost"));
                    if dollars > 0.0 {
                        dollars
                    } else {
                        parse_num(fill_json.get("fee").or_else(|| fill_json.get("taker_fee"))) / 100.0
                    }
                };

                let is_maker = !fill_json
                    .get("is_taker")
                    .and_then(|v| v.as_bool())
                    .unwrap_or(true);

                new_fills.push(Fill {
                    fill_id,
                    order_id,
                    market_id: ticker,
                    side,
                    order_side,
                    price,
                    size: count,
                    fee,
                    timestamp: ts,
                    token_id: None,
                    exchange: "kalshi".to_string(),
                    is_maker,
                    multiplier: 1.0,
                });
            }
        }

        if !new_fills.is_empty() {
            info!(count = new_fills.len(), "kalshi: polled new fills");
        }

        Ok(new_fills)
    }

    /// Fetch positions from Kalshi for reconciliation.
    async fn fetch_positions_async(&self) -> Result<Vec<crate::types::Position>, HorizonError> {
        if self.rsa_key.is_none() || self.key_id.is_none() {
            debug!("kalshi: skipping position fetch (no auth configured)");
            return Ok(Vec::new());
        }

        let url = format!("{}/portfolio/positions", self.api_url);
        let path = "/trade-api/v2/portfolio/positions";

        let req_builder = self.client.get(&url);
        let req_builder = self.apply_auth(req_builder, "GET", path)?;

        let resp = req_builder
            .send()
            .await
            .map_err(|e| HorizonError::Exchange(format!("kalshi: position fetch failed: {}", e)))?;

        if !resp.status().is_success() {
            let status = resp.status();
            debug!(status = %status, "kalshi: position fetch returned non-200");
            return Ok(Vec::new());
        }

        let json: serde_json::Value = resp.json().await.map_err(|e| {
            HorizonError::Exchange(format!("kalshi: position parse error: {}", e))
        })?;

        // Helper for the modern fixed-point string fields
        let parse_num = |val: Option<&serde_json::Value>| -> f64 {
            val.and_then(|v| {
                v.as_f64()
                    .or_else(|| v.as_i64().map(|i| i as f64))
                    .or_else(|| v.as_str().and_then(|s| s.parse::<f64>().ok()))
            })
            .unwrap_or(0.0)
        };

        let mut positions = Vec::new();
        let arr = json
            .get("market_positions")
            .or_else(|| json.get("positions"))
            .and_then(|v| v.as_array());

        if let Some(arr) = arr {
            for p in arr {
                let ticker = p.get("ticker").and_then(|v| v.as_str()).unwrap_or("");
                // Modern: position_fp is a SIGNED fixed-point string. Negative
                // means NO contracts, positive means YES. Legacy `position`
                // integer is also accepted.
                let position_fp = parse_num(p.get("position_fp"));
                let position = if position_fp != 0.0 {
                    position_fp
                } else {
                    parse_num(p.get("position"))
                };

                if position.abs() > 0.0 && !ticker.is_empty() {
                    // Side is derived from the SIGN of position_fp.
                    let side = if position < 0.0 {
                        crate::types::Side::No
                    } else {
                        crate::types::Side::Yes
                    };

                    // Kalshi doesn't directly report avg entry price. We can
                    // approximate it from total_traded_dollars / |position|.
                    let total_traded = parse_num(p.get("total_traded_dollars"));
                    let avg_entry_price = if position.abs() > 0.0 && total_traded > 0.0 {
                        total_traded / position.abs()
                    } else {
                        0.0
                    };
                    let realized_pnl = parse_num(p.get("realized_pnl_dollars"));
                    let market_exposure = parse_num(p.get("market_exposure_dollars"));

                    positions.push(crate::types::Position {
                        market_id: ticker.to_string(),
                        side,
                        size: position.abs(),
                        avg_entry_price,
                        realized_pnl,
                        unrealized_pnl: market_exposure - (position.abs() * avg_entry_price),
                        token_id: None,
                        exchange: "kalshi".to_string(),
                        multiplier: 1.0,
                    });
                }
            }
        }

        if !positions.is_empty() {
            info!(count = positions.len(), "kalshi: fetched positions for reconciliation");
        }

        Ok(positions)
    }
}

impl Exchange for KalshiExchange {
    fn submit_order(&self, req: &OrderRequest) -> Result<String, HorizonError> {
        let req_clone = req.clone();
        let order_id = self.runtime.block_on(self.submit_order_async(&req_clone))?;

        // Track order_id per market via shared OrderTracker
        if let Ok(mut tracker) = self.open_orders.lock() {
            tracker.insert(&req.market_id, &order_id);
        }

        Ok(order_id)
    }

    fn cancel_order(&self, order_id: &str) -> Result<(), HorizonError> {
        let id = order_id.to_string();
        self.runtime.block_on(self.cancel_order_async(&id))?;

        // Remove from open_orders tracking
        if let Ok(mut tracker) = self.open_orders.lock() {
            tracker.remove(order_id);
        }

        Ok(())
    }

    fn cancel_all(&self) -> Result<usize, HorizonError> {
        let count = self.runtime.block_on(self.cancel_all_async())?;

        // Clear all tracked orders
        if let Ok(mut tracker) = self.open_orders.lock() {
            tracker.clear();
        }

        Ok(count)
    }

    fn cancel_for_market(&self, market_id: &str) -> Result<usize, HorizonError> {
        let order_ids: Vec<String> = {
            let tracker = self.open_orders.lock().unwrap_or_else(|e| e.into_inner());
            tracker.get_market_orders(market_id)
        };

        if order_ids.is_empty() {
            return Ok(0);
        }

        let mut successfully_canceled = Vec::new();
        for oid in &order_ids {
            match self.runtime.block_on(self.cancel_order_async(oid)) {
                Ok(()) => successfully_canceled.push(oid.clone()),
                Err(e) => {
                    debug!(order_id = %oid, error = %e, "kalshi: cancel_for_market: order cancel failed (may already be filled)");
                }
            }
        }

        // Only remove successfully canceled IDs from tracking
        if let Ok(mut tracker) = self.open_orders.lock() {
            tracker.remove_from_market(market_id, &successfully_canceled);
        }

        let canceled = successfully_canceled.len();
        info!(market_id = %market_id, canceled = canceled, total = order_ids.len(), "kalshi: canceled orders for market");
        Ok(canceled)
    }

    fn drain_fills(&self) -> Vec<Fill> {
        // Poll for new fills from the API
        match self.runtime.block_on(self.poll_fills_async()) {
            Ok(new_fills) => {
                if !new_fills.is_empty() {
                    // Remove filled order IDs from open_orders tracking
                    if let Ok(mut tracker) = self.open_orders.lock() {
                        let filled_ids: Vec<&str> =
                            new_fills.iter().map(|f| f.order_id.as_str()).collect();
                        tracker.remove_filled(&filled_ids);
                    }

                    if let Ok(mut fills) = self.fills.lock() {
                        fills.extend(new_fills);
                    }
                }
            }
            Err(e) => {
                warn!(error = %e, "kalshi: fill polling error");
            }
        }

        // Return accumulated fills
        match self.fills.lock() {
            Ok(mut fills) => std::mem::take(&mut *fills),
            Err(_) => {
                error!("kalshi: fills lock poisoned");
                Vec::new()
            }
        }
    }

    fn name(&self) -> &str {
        "kalshi"
    }

    fn fetch_positions(&self) -> Result<Vec<crate::types::Position>, HorizonError> {
        self.runtime.block_on(self.fetch_positions_async())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_parse_iso8601_basic() {
        // 2024-01-01T00:00:00Z should be 1704067200
        let ts = parse_iso8601_to_unix("2024-01-01T00:00:00Z").unwrap();
        assert!((ts - 1704067200.0).abs() < 1.0);
    }

    #[test]
    fn test_parse_iso8601_with_fractional() {
        let ts = parse_iso8601_to_unix("2024-01-15T12:30:45.123Z").unwrap();
        // Should be Jan 15 2024 12:30:45.123 UTC
        assert!(ts > 1705300000.0);
        // Verify fractional part
        let frac = ts - ts.floor();
        assert!((frac - 0.123).abs() < 0.01);
    }

    #[test]
    fn test_parse_iso8601_invalid() {
        assert!(parse_iso8601_to_unix("not-a-date").is_none());
        assert!(parse_iso8601_to_unix("").is_none());
    }

    #[test]
    fn test_parse_iso8601_out_of_range() {
        // Month > 12
        assert!(parse_iso8601_to_unix("2024-13-01T00:00:00Z").is_none());
        // Month = 0
        assert!(parse_iso8601_to_unix("2024-00-01T00:00:00Z").is_none());
        // Day = 0
        assert!(parse_iso8601_to_unix("2024-01-00T00:00:00Z").is_none());
        // Day > 31
        assert!(parse_iso8601_to_unix("2024-01-32T00:00:00Z").is_none());
        // Hour > 23
        assert!(parse_iso8601_to_unix("2024-01-01T25:00:00Z").is_none());
    }

    #[test]
    fn test_is_leap() {
        assert!(is_leap(2024));
        assert!(!is_leap(2023));
        assert!(is_leap(2000));
        assert!(!is_leap(1900));
    }

    #[test]
    fn test_parse_iso8601_feb31() {
        assert!(parse_iso8601_to_unix("2024-02-31T00:00:00Z").is_none());
        assert!(parse_iso8601_to_unix("2024-02-30T00:00:00Z").is_none());
        assert!(parse_iso8601_to_unix("2024-02-29T00:00:00Z").is_some()); // leap year
        assert!(parse_iso8601_to_unix("2023-02-29T00:00:00Z").is_none()); // non-leap
    }
}
