from __future__ import annotations

import os
import sys
import traceback

from .core.config_manager import ConfigManager
from .core.serial_manager import SerialManager
from .core.theme_manager import ThemeManager
from .core.translations import set_language
from .paths import APP_NAME, APP_VERSION, resource_path, user_config_path, user_log_path
from .ui.main_window import MainWindow


def main() -> None:
    crash_log = user_log_path("boardypy_fatal.log")

    def _log_unhandled(exc_type, exc, tb) -> None:
        try:
            with open(crash_log, "a", encoding="utf-8") as fh:
                fh.write("\n=== Unhandled exception ===\n")
                fh.write("".join(traceback.format_exception(exc_type, exc, tb)))
        except OSError:
            pass
        sys.__excepthook__(exc_type, exc, tb)

    sys.excepthook = _log_unhandled

    from PyQt5.QtCore import Qt
    from PyQt5.QtGui import QIcon
    from PyQt5.QtWidgets import QApplication

    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
    QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps, True)

    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setApplicationVersion(APP_VERSION)
    app.setOrganizationName(APP_NAME)

    icon_path = resource_path("icon.png")
    if icon_path:
        app.setWindowIcon(QIcon(icon_path))

    config = ConfigManager(os.fspath(user_config_path()))
    set_language(config.get("language", "ru"))

    theme = ThemeManager()
    serial = SerialManager()

    window = MainWindow(config, theme, serial)
    window.show()

    sys.exit(app.exec_())
