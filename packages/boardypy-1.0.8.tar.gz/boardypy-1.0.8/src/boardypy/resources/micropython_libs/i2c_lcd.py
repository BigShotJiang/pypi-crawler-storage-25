# I2C LCD driver for MicroPython
# Supports HD44780-based LCD 1602 and 2004 via PCF8574 I2C adapter
# Requires: lcd_api.py
#
# ESP8266 wiring:
#   SDA -> D2 (GPIO4)
#   SCL -> D1 (GPIO5)
#   Common I2C address: 0x27 or 0x3F

import utime
from lcd_api import LcdApi

# PCF8574 pin assignments
MASK_RS  = 0x01
MASK_RW  = 0x02
MASK_E   = 0x04
SHIFT_BACKLIGHT = 3
SHIFT_DATA      = 4


class I2cLcd(LcdApi):
    """Driver for LCD 1602/2004 connected via PCF8574 I2C adapter."""

    def __init__(self, i2c, i2c_addr, num_lines, num_columns):
        self.i2c = i2c
        self.i2c_addr = i2c_addr
        self.i2c.writeto(self.i2c_addr, bytes([0]))
        utime.sleep_ms(20)
        # Put LCD into 4-bit mode
        self.hal_write_init_nibble(0x30)
        utime.sleep_ms(5)
        self.hal_write_init_nibble(0x30)
        utime.sleep_ms(1)
        self.hal_write_init_nibble(0x30)
        utime.sleep_ms(1)
        self.hal_write_init_nibble(0x20)  # 4-bit mode
        utime.sleep_ms(1)
        LcdApi.__init__(self, num_lines, num_columns)
        cmd = 0x20
        if num_lines > 1:
            cmd |= 0x08  # 2-line flag
        self.hal_write_command(cmd)

    def hal_write_init_nibble(self, nibble):
        byte = ((nibble >> 4) & 0x0F) << SHIFT_DATA
        self.i2c.writeto(self.i2c_addr, bytes([byte | MASK_E]))
        self.i2c.writeto(self.i2c_addr, bytes([byte]))

    def hal_backlight_on(self):
        self.i2c.writeto(self.i2c_addr, bytes([1 << SHIFT_BACKLIGHT]))

    def hal_backlight_off(self):
        self.i2c.writeto(self.i2c_addr, bytes([0]))

    def hal_write_command(self, cmd):
        byte = self.backlight << SHIFT_BACKLIGHT
        hi_nibble = (cmd >> 4) & 0x0F
        lo_nibble = cmd & 0x0F
        # Write high nibble
        self.i2c.writeto(self.i2c_addr, bytes([byte | (hi_nibble << SHIFT_DATA) | MASK_E]))
        self.i2c.writeto(self.i2c_addr, bytes([byte | (hi_nibble << SHIFT_DATA)]))
        # Write low nibble
        self.i2c.writeto(self.i2c_addr, bytes([byte | (lo_nibble << SHIFT_DATA) | MASK_E]))
        self.i2c.writeto(self.i2c_addr, bytes([byte | (lo_nibble << SHIFT_DATA)]))
        if cmd <= 3:
            utime.sleep_ms(5)

    def hal_write_data(self, data):
        byte = self.backlight << SHIFT_BACKLIGHT
        hi_nibble = (data >> 4) & 0x0F
        lo_nibble = data & 0x0F
        # Write high nibble
        self.i2c.writeto(self.i2c_addr, bytes([byte | (hi_nibble << SHIFT_DATA) | MASK_RS | MASK_E]))
        self.i2c.writeto(self.i2c_addr, bytes([byte | (hi_nibble << SHIFT_DATA) | MASK_RS]))
        # Write low nibble
        self.i2c.writeto(self.i2c_addr, bytes([byte | (lo_nibble << SHIFT_DATA) | MASK_RS | MASK_E]))
        self.i2c.writeto(self.i2c_addr, bytes([byte | (lo_nibble << SHIFT_DATA) | MASK_RS]))
