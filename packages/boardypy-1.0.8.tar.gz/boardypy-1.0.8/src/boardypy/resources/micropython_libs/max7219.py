# max7219.py — MicroPython driver for MAX7219 8x8 LED matrix / 7-segment display
# SPI: DIN->D7(GPIO13) CLK->D5(GPIO14) CS->D8(GPIO15)  VCC->5V  GND->GND
# Supports daisy-chaining multiple modules (num parameter).

from machine import Pin, SPI
import utime

_REG_NOOP        = 0x0
_REG_DIGIT       = [0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8]
_REG_DECODEMODE  = 0x9
_REG_INTENSITY   = 0xA
_REG_SCANLIMIT   = 0xB
_REG_SHUTDOWN    = 0xC
_REG_DISPLAYTEST = 0xF

# Basic 5x7 font (only printable ASCII stored, index = char - 32)
_FONT = {
    ' ': 0b00000000,
    '0': 0b01111110, '1': 0b00110000, '2': 0b01101101, '3': 0b01111001,
    '4': 0b00110011, '5': 0b01011011, '6': 0b01011111, '7': 0b01110000,
    '8': 0b01111111, '9': 0b01111011,
    'A': 0b01110111, 'B': 0b00011111, 'C': 0b01001110, 'D': 0b00111101,
    'E': 0b01001111, 'F': 0b01000111,
}


class Matrix8x8:
    """Driver for MAX7219 8×8 LED matrix display (or chain of them).

    Usage:
        spi = SPI(1, baudrate=10_000_000)
        cs  = Pin(15, Pin.OUT)
        m   = Matrix8x8(spi, cs, num=1)
        m.brightness(5)
        m.fill(0); m.show()
        m.pixel(3, 3, 1); m.show()
    """

    def __init__(self, spi: SPI, cs: Pin, num: int = 1):
        self._spi = spi
        self._cs  = cs
        self._num = num
        self._buf = [[0] * 8 for _ in range(num)]
        cs.init(Pin.OUT, value=1)
        self._write_all(_REG_SHUTDOWN,    0)     # shutdown
        self._write_all(_REG_DISPLAYTEST, 0)
        self._write_all(_REG_SCANLIMIT,   7)
        self._write_all(_REG_DECODEMODE,  0)
        self._write_all(_REG_SHUTDOWN,    1)     # wake up
        self.brightness(3)
        self.fill(0)
        self.show()

    # ---- Low-level ----
    def _write(self, device: int, reg: int, data: int) -> None:
        """Write to a specific device in the chain."""
        payload = bytearray(2 * self._num)
        payload[device * 2]     = reg
        payload[device * 2 + 1] = data
        self._cs(0)
        self._spi.write(payload)
        self._cs(1)

    def _write_all(self, reg: int, data: int) -> None:
        payload = bytearray(2 * self._num)
        for i in range(self._num):
            payload[i * 2]     = reg
            payload[i * 2 + 1] = data
        self._cs(0)
        self._spi.write(payload)
        self._cs(1)

    # ---- Public API ----
    def brightness(self, value: int, device: int = None) -> None:
        """Set brightness 0–15 (all or specific device)."""
        value = max(0, min(15, value))
        if device is None:
            self._write_all(_REG_INTENSITY, value)
        else:
            self._write(device, _REG_INTENSITY, value)

    def fill(self, value: int, device: int = None) -> None:
        """Fill buffer: 0 = off, 1 = all on."""
        v = 0xFF if value else 0x00
        if device is None:
            for d in range(self._num):
                for r in range(8):
                    self._buf[d][r] = v
        else:
            for r in range(8):
                self._buf[device][r] = v

    def pixel(self, x: int, y: int, value: int, device: int = 0) -> None:
        """Set pixel (x=col 0–7, y=row 0–7)."""
        if value:
            self._buf[device][y] |= (1 << (7 - x))
        else:
            self._buf[device][y] &= ~(1 << (7 - x))

    def show(self) -> None:
        """Push buffer to display."""
        for row in range(8):
            payload = bytearray(2 * self._num)
            for d in range(self._num):
                payload[d * 2]     = _REG_DIGIT[row]
                payload[d * 2 + 1] = self._buf[d][row]
            self._cs(0)
            self._spi.write(payload)
            self._cs(1)

    def text(self, string: str, x: int = 0, y: int = 0,
             device: int = 0) -> None:
        """Write text using built-in font (7-segment style, row y)."""
        for i, ch in enumerate(string):
            seg = _FONT.get(ch.upper(), 0)
            col = x + i
            if 0 <= col < 8:
                self._buf[device][y] = seg   # simplified: one char per row


# ---------------------------------------------------------------------------
# Quick example:
# ---------------------------------------------------------------------------
if __name__ == '__main__':
    spi = SPI(1, baudrate=10_000_000)
    cs  = Pin(15, Pin.OUT)
    m   = Matrix8x8(spi, cs, num=1)
    m.brightness(5)

    # Knight-rider scan
    for _ in range(3):
        for col in range(8):
            m.fill(0)
            for row in range(8):
                m.pixel(col, row, 1)
            m.show()
            utime.sleep_ms(80)
