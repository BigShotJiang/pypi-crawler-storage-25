# wifi_helper.py — MicroPython Wi-Fi convenience helpers for ESP8266
# Built on top of the built-in 'network' module.

import network
import utime


def connect(ssid: str, password: str, timeout: int = 15) -> str:
    """Connect to Wi-Fi access point (STA mode).

    Args:
        ssid:     Network name
        password: Network password
        timeout:  Max seconds to wait (default 15)

    Returns:
        IP address string if connected, None if failed.

    Example:
        from wifi_helper import connect
        ip = connect('MyRouter', 'mypassword')
        if ip:
            print('Connected! IP:', ip)
        else:
            print('Failed to connect')
    """
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)

    if wlan.isconnected():
        return wlan.ifconfig()[0]

    wlan.connect(ssid, password)
    start = utime.time()
    while not wlan.isconnected():
        if utime.time() - start >= timeout:
            return None
        utime.sleep_ms(200)

    return wlan.ifconfig()[0]


def disconnect() -> None:
    """Disconnect from Wi-Fi and disable STA interface."""
    wlan = network.WLAN(network.STA_IF)
    wlan.disconnect()
    wlan.active(False)


def status() -> dict:
    """Return dict with current Wi-Fi connection info.

    Returns:
        {
            'connected': bool,
            'ssid': str,
            'ip': str,
            'subnet': str,
            'gateway': str,
            'dns': str,
            'rssi': int   # signal strength dBm
        }

    Example:
        from wifi_helper import status
        s = status()
        print('IP:', s['ip'], '  Signal:', s['rssi'], 'dBm')
    """
    wlan = network.WLAN(network.STA_IF)
    connected = wlan.isconnected()
    if connected:
        ip, subnet, gw, dns = wlan.ifconfig()
        try:
            rssi = wlan.status('rssi')
        except Exception:
            rssi = 0
        try:
            ssid = wlan.config('essid')
            if isinstance(ssid, bytes):
                ssid = ssid.decode('utf-8', 'ignore')
        except Exception:
            ssid = ''
    else:
        ip = subnet = gw = dns = ssid = ''
        rssi = 0
    return {
        'connected': connected,
        'ssid':    ssid,
        'ip':      ip,
        'subnet':  subnet,
        'gateway': gw,
        'dns':     dns,
        'rssi':    rssi,
    }


def create_ap(ssid: str, password: str = '', channel: int = 6) -> str:
    """Create a Wi-Fi access point (AP mode).

    Args:
        ssid:     Access point name (visible to devices)
        password: Password (min 8 chars). Empty string = open network.
        channel:  Wi-Fi channel 1–13 (default 6)

    Returns:
        AP IP address (usually '192.168.4.1')

    Example:
        from wifi_helper import create_ap
        ip = create_ap('ESP8266-AP', 'password123')
        print('AP started, connect to it and open:', ip)
    """
    ap = network.WLAN(network.AP_IF)
    ap.active(True)
    if password:
        ap.config(essid=ssid, password=password,
                  authmode=network.AUTH_WPA_WPA2_PSK,
                  channel=channel)
    else:
        ap.config(essid=ssid, authmode=network.AUTH_OPEN, channel=channel)
    # Wait for AP to start
    timeout = 5
    start = utime.time()
    while not ap.active():
        if utime.time() - start >= timeout:
            break
        utime.sleep_ms(100)
    return ap.ifconfig()[0]


def stop_ap() -> None:
    """Disable AP mode."""
    ap = network.WLAN(network.AP_IF)
    ap.active(False)


def scan() -> list:
    """Scan for nearby Wi-Fi networks.

    Returns list of tuples: (ssid, bssid, channel, rssi, authmode, hidden)

    Example:
        from wifi_helper import scan
        for net in scan():
            ssid = net[0].decode('utf-8', 'ignore')
            rssi = net[3]
            print(ssid, rssi, 'dBm')
    """
    wlan = network.WLAN(network.STA_IF)
    was_active = wlan.active()
    wlan.active(True)
    try:
        networks = wlan.scan()
    finally:
        if not was_active:
            wlan.active(False)
    # Sort by signal strength (strongest first)
    return sorted(networks, key=lambda n: -n[3])


# ---------------------------------------------------------------------------
# Quick example — connect and do HTTP GET (no SSL):
# ---------------------------------------------------------------------------
if __name__ == '__main__':
    import urequests

    ip = connect('YOUR_SSID', 'YOUR_PASSWORD')
    if not ip:
        print('Connection failed!')
    else:
        print('IP:', ip)
        s = status()
        print('Signal:', s['rssi'], 'dBm')

        # Simple HTTP GET
        try:
            r = urequests.get('http://api.ipify.org')
            print('Public IP:', r.text)
            r.close()
        except Exception as e:
            print('HTTP error:', e)
