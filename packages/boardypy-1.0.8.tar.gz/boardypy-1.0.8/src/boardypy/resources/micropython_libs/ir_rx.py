# ir_rx.py — MicroPython NEC IR remote control decoder
# Receiver: VS1838B, TSOP4838, TSOP2238 etc.
# ESP8266: OUT -> D5(GPIO14) or D6(GPIO12)  VCC->3.3V  GND->GND
#
# The NEC protocol:
#   - 9ms lead burst + 4.5ms space
#   - Each bit: 562us burst + 562us(0) or 1687us(1) space
#   - 32 bits: 8-bit addr, 8-bit ~addr, 8-bit cmd, 8-bit ~cmd
#   - Repeat code: 9ms burst + 2.25ms space + 562us burst

from machine import Pin
import utime
import micropython


class NECIR:
    """Non-blocking NEC IR receiver using Pin IRQ.

    Usage:
        from machine import Pin
        from ir_rx import NECIR

        def on_ir(data, addr, ctrl):
            print(f'CMD: {data:#04x}  ADDR: {addr:#04x}')

        ir = NECIR(Pin(14, Pin.IN), on_ir)
        # Press buttons on remote — callback fires for each key press

    Callback args:
        data (int) — command byte (0-255)
        addr (int) — device address byte (0-255)
        ctrl (int) — 1 if valid, 0 if invalid checksum
    """

    # Timing constants (µs)
    _LEAD_MIN  = 8000
    _LEAD_MAX  = 10000
    _SPACE_MIN = 3500
    _SPACE_MAX = 5500
    _REPEAT    = 2000
    _ONE_MIN   = 1500
    _ZERO_MAX  = 800

    def __init__(self, pin: Pin, callback):
        self._pin     = pin
        self._cb      = callback
        self._reset()
        pin.irq(trigger=Pin.IRQ_FALLING | Pin.IRQ_RISING,
                handler=self._irq)

    def _reset(self):
        self._bits   = []
        self._last   = 0
        self._state  = 0   # 0=idle, 1=lead-high, 2=lead-low, 3=data

    def _irq(self, pin):
        now = utime.ticks_us()
        dur = utime.ticks_diff(now, self._last)
        self._last = now

        if self._state == 0:
            # Falling edge = start of lead burst
            self._state = 1
            return

        if self._state == 1:
            # Rising edge = end of lead burst
            if self._LEAD_MIN <= dur <= self._LEAD_MAX:
                self._state = 2
            else:
                self._reset()
            return

        if self._state == 2:
            # Falling edge after lead
            if self._SPACE_MIN <= dur <= self._SPACE_MAX:
                self._state = 3
                self._bits  = []
            elif dur >= self._REPEAT:
                # Repeat code — ignore silently
                self._reset()
            else:
                self._reset()
            return

        if self._state == 3:
            if len(self._bits) % 2 == 0:
                # Even = end of space or start of burst (falling edge)
                # Record space duration to classify bit
                if len(self._bits) > 0:
                    if dur >= self._ONE_MIN:
                        self._bits[-1] = 1
                    elif dur <= self._ZERO_MAX:
                        self._bits[-1] = 0
                    else:
                        self._reset(); return
                self._bits.append(None)  # placeholder for next bit
            else:
                # Rising edge = end of burst — 562µs nominal, just pass
                pass

            if len(self._bits) >= 32:
                self._decode()

    def _decode(self):
        try:
            bits = self._bits[:32]
            addr  = sum(bits[i]     << i for i in range(8))
            naddr = sum(bits[i + 8] << i for i in range(8))
            cmd   = sum(bits[i + 16] << i for i in range(8))
            ncmd  = sum(bits[i + 24] << i for i in range(8))
            valid = 1 if (addr ^ naddr == 0xFF) and (cmd ^ ncmd == 0xFF) else 0
            micropython.schedule(self._fire, (cmd, addr, valid))
        except Exception:
            pass
        finally:
            self._reset()

    def _fire(self, args):
        try:
            self._cb(*args)
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Quick example:
# ---------------------------------------------------------------------------
if __name__ == '__main__':
    from machine import Pin

    def on_button(data, addr, valid):
        if valid:
            print(f'Button code: {data:#04x} ({data})  Device: {addr:#04x}')
        else:
            print(f'Bad checksum — data:{data:#04x} addr:{addr:#04x}')

    print('Point remote at receiver and press buttons...')
    ir = NECIR(Pin(14, Pin.IN), on_button)

    import utime
    while True:
        utime.sleep(1)
