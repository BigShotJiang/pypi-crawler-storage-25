# ads1115.py — MicroPython driver for ADS1115 16-bit I2C ADC
# I2C: SDA->D2(GPIO4)  SCL->D1(GPIO5)  VCC->3.3V  GND->GND
# ADDR pin: GND=0x48, VCC=0x49, SDA=0x4A, SCL=0x4B
#
# Why use instead of built-in ESP8266 ADC (A0)?
#   - A0 only 0-1V, 10-bit. ADS1115 is 0-4.096V, 16-bit, 4 channels.

from machine import I2C

# Register addresses
_REG_CONV   = 0x00
_REG_CONFIG = 0x01

# OS (operational status / single-shot conversion)
_OS_SINGLE  = 0x8000

# Gain (PGA — programmable gain amplifier)
_GAIN = {
    '2/3': 0x0000,   # ±6.144 V  (4.096 V max on ADS1115)
    1:     0x0200,   # ±4.096 V
    2:     0x0400,   # ±2.048 V  (default)
    4:     0x0600,   # ±1.024 V
    8:     0x0800,   # ±0.512 V
    16:    0x0A00,   # ±0.256 V
}
_GAIN_VOLTAGE = {
    '2/3': 6.144, 1: 4.096, 2: 2.048, 4: 1.024, 8: 0.512, 16: 0.256
}

# Data rate (samples per second)
_DR_128SPS = 0x0080  # default

# Comparator disabled
_COMP_QU_DISABLE = 0x0003

# Mode: single-shot
_MODE_SINGLE = 0x0100

# Mux: single-ended channels
_MUX_SINGLE = [0x4000, 0x5000, 0x6000, 0x7000]


class ADS1115:
    """16-bit 4-channel ADC over I2C.

    Usage:
        from machine import I2C, Pin
        from ads1115 import ADS1115
        i2c = I2C(sda=Pin(4), scl=Pin(5))
        adc = ADS1115(i2c)
        adc.set_gain(1)              # ±4.096 V
        raw   = adc.read(0)          # channel A0
        volts = adc.read_voltage(0)
        print(volts, 'V')
    """

    def __init__(self, i2c: I2C, address: int = 0x48):
        self._i2c    = i2c
        self._addr   = address
        self._gain   = 1          # ±4.096 V
        self._dr     = _DR_128SPS

    def set_gain(self, gain) -> None:
        """Set PGA gain. Values: '2/3', 1, 2, 4, 8, 16."""
        if gain not in _GAIN:
            raise ValueError("Invalid gain. Use: '2/3',1,2,4,8,16")
        self._gain = gain

    def read(self, channel: int = 0) -> int:
        """Read raw ADC value (-32768 … 32767) from channel 0–3."""
        if not 0 <= channel <= 3:
            raise ValueError("Channel must be 0-3")
        config = (
            _OS_SINGLE          |
            _MUX_SINGLE[channel] |
            _GAIN[self._gain]   |
            _MODE_SINGLE        |
            self._dr            |
            _COMP_QU_DISABLE
        )
        # Write config
        self._i2c.writeto_mem(
            self._addr, _REG_CONFIG,
            bytes([(config >> 8) & 0xFF, config & 0xFF])
        )
        # Wait for conversion (single-shot ~8 ms at 128 SPS)
        import utime
        utime.sleep_ms(10)
        # Check OS bit
        for _ in range(20):
            raw = self._i2c.readfrom_mem(self._addr, _REG_CONFIG, 2)
            if raw[0] & 0x80:
                break
            utime.sleep_ms(2)
        # Read conversion result
        data = self._i2c.readfrom_mem(self._addr, _REG_CONV, 2)
        value = (data[0] << 8) | data[1]
        if value > 32767:
            value -= 65536
        return value

    def read_voltage(self, channel: int = 0) -> float:
        """Read voltage in volts. Depends on set_gain()."""
        raw = self.read(channel)
        fsr = _GAIN_VOLTAGE[self._gain]
        return round(raw * fsr / 32767.0, 4)


# ---------------------------------------------------------------------------
# Quick example:
# ---------------------------------------------------------------------------
if __name__ == '__main__':
    from machine import I2C, Pin
    import utime

    i2c = I2C(sda=Pin(4), scl=Pin(5))
    adc = ADS1115(i2c)
    adc.set_gain(1)   # ±4.096 V

    while True:
        for ch in range(4):
            v = adc.read_voltage(ch)
            print(f'A{ch}: {v:.3f} V', end='  ')
        print()
        utime.sleep(1)
