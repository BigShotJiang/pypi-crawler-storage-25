# HX711 24-bit ADC driver for load cells (scales)
# MicroPython port for ESP8266 / ESP32
#
# ESP8266 wiring:
#   DT  (data)  -> any free GPIO, e.g. D2 (GPIO4)
#   SCK (clock) -> any free GPIO, e.g. D1 (GPIO5)
#   VCC -> 3.3V or 5V (module dependent)
#   GND -> GND

from machine import Pin
import utime


class HX711:
    """Driver for HX711 24-bit ADC for load cells."""

    CHAN_A_GAIN_128 = const(1)
    CHAN_A_GAIN_64  = const(3)
    CHAN_B_GAIN_32  = const(2)

    def __init__(self, d_out, pd_sck, gain=CHAN_A_GAIN_128):
        self._dout = Pin(d_out, Pin.IN)
        self._sck  = Pin(pd_sck, Pin.OUT)
        self._sck.value(0)
        self._offset = 0
        self._scale  = 1.0
        self._gain_pulses = gain
        self.read()  # initial read to set gain

    def _is_ready(self):
        return self._dout.value() == 0

    def _read_raw(self):
        while not self._is_ready():
            utime.sleep_ms(1)
        data = 0
        for _ in range(24):
            self._sck.value(1)
            utime.sleep_us(1)
            data = (data << 1) | self._dout.value()
            self._sck.value(0)
            utime.sleep_us(1)
        # Extra pulses to set gain for next reading
        for _ in range(self._gain_pulses):
            self._sck.value(1)
            utime.sleep_us(1)
            self._sck.value(0)
            utime.sleep_us(1)
        # Sign extend from 24-bit
        if data & 0x800000:
            data -= 0x1000000
        return data

    def read(self):
        """Return raw ADC value."""
        return self._read_raw()

    def tare(self, times=10):
        """Set zero point by averaging {times} readings."""
        total = sum(self._read_raw() for _ in range(times))
        self._offset = total // times

    def set_scale(self, scale):
        """Set calibration scale factor (grams per ADC unit, approx)."""
        self._scale = scale

    def get_value(self, times=3):
        """Return offset-corrected average of {times} readings."""
        total = sum(self._read_raw() for _ in range(times))
        return (total // times) - self._offset

    def get_weight(self, times=3):
        """Return weight in configured units (divide by scale)."""
        return self.get_value(times) / self._scale

    def power_down(self):
        self._sck.value(0)
        self._sck.value(1)
        utime.sleep_us(100)

    def power_up(self):
        self._sck.value(0)
        utime.sleep_ms(1)
