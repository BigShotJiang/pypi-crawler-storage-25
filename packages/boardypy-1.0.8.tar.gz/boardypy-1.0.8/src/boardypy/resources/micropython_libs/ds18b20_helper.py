# ds18b20_helper.py — MicroPython helper for DS18B20 (1-Wire temperature sensor)
# Requires: onewire, ds18x20 (built-in MicroPython modules)
# ESP8266: DATA -> any GPIO, e.g. D3 (GPIO0). Pull-up 4.7 kOhm required!

from machine import Pin
import onewire
import ds18x20
import utime


def scan_sensors(pin_num: int):
    """Scan 1-Wire bus and return list of ROM addresses."""
    ow = onewire.OneWire(Pin(pin_num))
    ds = ds18x20.DS18X20(ow)
    roms = ds.scan()
    return ds, roms


def read_all(pin_num: int) -> list:
    """Read temperature from all DS18B20 sensors on the bus.
    Returns list of (rom_hex, temperature_celsius) tuples.

    Example:
        results = read_all(0)  # D3 = GPIO0
        for rom_hex, temp in results:
            print(rom_hex, temp, 'C')
    """
    ds, roms = scan_sensors(pin_num)
    if not roms:
        return []
    ds.convert_temp()
    utime.sleep_ms(750)        # wait for conversion
    result = []
    for rom in roms:
        try:
            temp = ds.read_temp(rom)
            rom_hex = ''.join('{:02X}'.format(b) for b in rom)
            result.append((rom_hex, round(temp, 2)))
        except onewire.OneWireError:
            pass
    return result


def read_single(pin_num: int) -> float:
    """Read temperature from the first DS18B20 on the bus.
    Returns temperature in Celsius, or None if not found.

    Example:
        temp = read_single(0)   # D3 = GPIO0
        if temp is not None:
            print(temp, 'C')
    """
    ds, roms = scan_sensors(pin_num)
    if not roms:
        return None
    ds.convert_temp()
    utime.sleep_ms(750)
    try:
        return round(ds.read_temp(roms[0]), 2)
    except onewire.OneWireError:
        return None


# ---------------------------------------------------------------------------
# Quick example (run directly on device):
# ---------------------------------------------------------------------------
if __name__ == '__main__':
    import utime
    PIN = 0   # D3 = GPIO0

    print('Scanning for DS18B20 sensors on GPIO', PIN)
    ds, roms = scan_sensors(PIN)
    print('Found', len(roms), 'sensor(s)')

    while True:
        ds.convert_temp()
        utime.sleep_ms(750)
        for rom in roms:
            try:
                t = ds.read_temp(rom)
                name = ''.join('{:02X}'.format(b) for b in rom)
                print(name, '->', round(t, 2), 'C')
            except onewire.OneWireError as e:
                print('Error:', e)
        print('---')
        utime.sleep(2)
