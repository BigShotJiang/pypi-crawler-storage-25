# MicroPython ST7735 TFT display HAL
import machine
import time
from st7735 import ST7735


class TFT(ST7735):
    
    def __init__(self, width, height, spi, dc, cs, rst, bl=None):
        """
        SPI      - SPI Bus (CLK/MOSI/MISO)
        DC       - RS/DC data/command flag
        CS       - Chip Select, enable communication
        RST/RES  - Reset
        BL/Lite  - Backlight control
        """

        # self.tab = tab
        self.spi = spi
        self.dc  = dc
        self.cs  = cs
        self.rst = rst
        self.bl  = bl
        self.windowLocData = bytearray(4)

        # ST7735 init
        super().__init__(width, height)

    # ST7735 HAL
    def init(self):
        self.margin_row = 0
        self.margin_col = 0
        self.reset()
        # self.clear()
        # self.power(True)

    def reset(self):
        """
        Hard reset the display.
        """
        self.dc.value(0)
        self.rst.value(1)
        time.sleep_ms(500)
        self.rst.value(0)
        time.sleep_ms(500)
        self.rst.value(1)
        time.sleep_ms(500)

    def backlight(self, state=None):
        """
        Get or set the backlight status if the pin is available.
        """
        if self.bl is None:
            return None
        else:
            if state is None:
                return self.backlight_on
            self.bl.value(1 if state else 0)
            self.backlight_on = state


    def write_pixels(self, count, color):
        """
        Write pixels to the display.

        count - total number of pixels
        color - 16-bit RGB value
        """
        self.dc.value(1)
        self.cs.value(0)
        for _ in range(count):
            self.spi.write(color)
        self.cs.value(1)

    def write_cmd(self, cmd):
        """
        Display command write implementation using SPI.
        """
        self.dc.value(0)
        self.cs.value(0)
        self.spi.write(bytearray([cmd]))
        self.cs.value(1)

    def write_data(self, data):
        """
        Display data write implementation using SPI.
        """
        self.dc.value(1)
        self.cs.value(0)
        self.spi.write(data)
        self.cs.value(1)

    def draw_bmp(self, x, y, filename):
        f=open(filename, 'rb')
        if f.read(2) == b'BM':  #header
            dummy = f.read(8) #file size(4), creator bytes(4)
            offset = int.from_bytes(f.read(4), 'little')
            hdrsize = int.from_bytes(f.read(4), 'little')
            width = int.from_bytes(f.read(4), 'little')
            height = int.from_bytes(f.read(4), 'little')
            if int.from_bytes(f.read(2), 'little') == 1: #planes must be 1
                depth = int.from_bytes(f.read(2), 'little')
                if depth == 24 and int.from_bytes(f.read(4), 'little') == 0:#compress method == uncompressed
                    dww = self.width
                    dwh = self.height
                    if width < self.width:
                        dww = width
                    if height < self.height:
                        dwh = height
                        
                    self._set_window(x,y,x+dww - 1,y+dwh - 1)
                    rowsize = (width * 3 + 3) & ~3
                    if height < 0:
                        height = -height
                        flip = False
                    else:
                        flip = True
                    w, h = width, height
                    if w > self.width: w = self.width
                    if h > self.height: h = self.height
                    
                    for row in range(h):
                        if flip:
                            pos = offset + (height - 1 - row) * rowsize
                        else:
                            pos = offset + row * rowsize
                        if f.tell() != pos:
                            dummy = f.seek(pos)
                        for col in range(w):
                            bgr = f.read(3)
                            colr = ((bgr[2] & 0xF8) << 8) | ((bgr[1] & 0xFC) << 3) | (bgr[0] >> 3)#tft.rgbcolor(bgr[2], bgr[1], bgr[0])
                            self.write_data(bytearray([colr >> 8, colr]))
        f.close()


class TFT_GREEN(TFT):

    def __init__(self, width, height, spi, dc, cs, rst, bl=None, rotate=0):
        if rotate==90 or rotate==270:
            height, width = width, height
        self.rotate = rotate
        super().__init__(width, height, spi, dc, cs, rst, bl)


    def initr(self, MADCTL=0x00):
        '''Initialize a red tab version.'''
        self.reset()

        self.write_cmd(TFT.CMD_SWRESET)              #Software reset.
        time.sleep_us(150)
        self.write_cmd(TFT.CMD_SLPOUT)               #out of sleep mode.
        time.sleep_us(500)

        data3 = bytearray([0x01, 0x2C, 0x2D])       #fastest refresh, 6 lines front, 3 lines back.
        self.write_cmd(TFT.CMD_FRMCTR1)              #Frame rate control.
        self.write_data(data3)

        self.write_cmd(TFT.CMD_FRMCTR2)              #Frame rate control.
        self.write_data(data3)

        data6 = bytearray([0x01, 0x2c, 0x2d, 0x01, 0x2c, 0x2d])
        self.write_cmd(TFT.CMD_FRMCTR3)              #Frame rate control.
        self.write_data(data6)
        time.sleep_us(10)

        data1 = bytearray(1)
        self.write_cmd(TFT.CMD_INVCTR)               #Display inversion control
        data1[0] = 0x07                             #Line inversion.
        self.write_data(data1)

        self.write_cmd(TFT.CMD_PWCTR1)               #Power control
        data3[0] = 0xA2
        data3[1] = 0x02
        data3[2] = 0x84
        self.write_data(data3)

        self.write_cmd(TFT.CMD_PWCTR2)               #Power control
        data1[0] = 0xC5   #VGH = 14.7V, VGL = -7.35V
        self.write_data(data1)

        data2 = bytearray(2)
        self.write_cmd(TFT.CMD_PWCTR3)               #Power control
        data2[0] = 0x0A   #Opamp current small
        data2[1] = 0x00   #Boost frequency
        self.write_data(data2)

        self.write_cmd(TFT.CMD_PWCTR4)               #Power control
        data2[0] = 0x8A   #Opamp current small
        data2[1] = 0x2A   #Boost frequency
        self.write_data(data2)

        self.write_cmd(TFT.CMD_PWCTR5)               #Power control
        data2[0] = 0x8A   #Opamp current small
        data2[1] = 0xEE   #Boost frequency
        self.write_data(data2)

        self.write_cmd(TFT.CMD_VMCTR1)               #Power control
        data1[0] = 0x0E
        self.write_data(data1)

        self.write_cmd(TFT.CMD_INVOFF)

        self.write_cmd(TFT.CMD_MADCTL)               #Power control
        data1[0] = MADCTL
        self.write_data(data1)

        self.write_cmd(TFT.CMD_COLMOD)
        data1[0] = 0x05
        self.write_data(data1)

        self.write_cmd(TFT.CMD_CASET)                #Column address set.
        self.windowLocData[0] = 0x00
        self.windowLocData[1] = 0x00
        self.windowLocData[2] = 0x00
        self.windowLocData[3] = self.width - 1
        self.write_data(self.windowLocData)

        self.write_cmd(TFT.CMD_RASET)                #Row address set.
        self.windowLocData[3] = self.height - 1
        self.write_data(self.windowLocData)

        dataGMCTRP = bytearray([0x0f, 0x1a, 0x0f, 0x18, 0x2f, 0x28, 0x20, 0x22, 0x1f,
                                0x1b, 0x23, 0x37, 0x00, 0x07, 0x02, 0x10])
        self.write_cmd(TFT.CMD_GMCTRP1)
        self.write_data(dataGMCTRP)

        dataGMCTRN = bytearray([0x0f, 0x1b, 0x0f, 0x17, 0x33, 0x2c, 0x29, 0x2e, 0x30,
                                0x30, 0x39, 0x3f, 0x00, 0x07, 0x03, 0x10])
        self.write_cmd(TFT.CMD_GMCTRN1)
        self.write_data(dataGMCTRN)
        time.sleep_us(10)

        self.write_cmd(TFT.CMD_DISPON)
        time.sleep_us(100)

        self.write_cmd(TFT.CMD_NORON)                #Normal display on.
        time.sleep_us(10)

        self.cs.value(1)
