# NeoPixel (WS2812) helper for MicroPython
# NOTE: MicroPython already has a built-in 'neopixel' module!
# This file just shows ready-to-use examples and helper functions.
#
# ESP8266 wiring:
#   DIN (data in) -> D4 (GPIO2) recommended, or GPIO 0, 4, 5, 12, 13, 14, 15
#   VCC -> 5V (for the strip); logic level works with 3.3V data line
#   GND -> GND (common with ESP8266 GND!)
#
# Built-in usage (no extra library needed):
#   from machine import Pin
#   from neopixel import NeoPixel
#   np = NeoPixel(Pin(2), 8)  # Pin(2) = D4, 8 pixels
#   np[0] = (255, 0, 0)       # red
#   np[1] = (0, 255, 0)       # green
#   np[2] = (0, 0, 255)       # blue
#   np.write()

from machine import Pin
from neopixel import NeoPixel
import utime


def rainbow_cycle(np, wait_ms=20):
    """Display a rainbow cycle across all pixels."""
    n = len(np)
    for j in range(255):
        for i in range(n):
            rc_index = (i * 256 // n + j) & 255
            np[i] = _wheel(rc_index)
        np.write()
        utime.sleep_ms(wait_ms)


def color_wipe(np, color, wait_ms=50):
    """Fill pixels one by one with a color."""
    for i in range(len(np)):
        np[i] = color
        np.write()
        utime.sleep_ms(wait_ms)


def clear(np):
    """Turn off all pixels."""
    for i in range(len(np)):
        np[i] = (0, 0, 0)
    np.write()


def _wheel(pos):
    """Generate rainbow colors across 0–255 positions."""
    if pos < 85:
        return (pos * 3, 255 - pos * 3, 0)
    elif pos < 170:
        pos -= 85
        return (255 - pos * 3, 0, pos * 3)
    else:
        pos -= 170
        return (0, pos * 3, 255 - pos * 3)
