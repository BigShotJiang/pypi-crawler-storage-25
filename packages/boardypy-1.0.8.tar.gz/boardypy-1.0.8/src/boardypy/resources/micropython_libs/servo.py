# Servo motor driver for MicroPython (ESP8266/ESP32)
# Controls standard hobby servos (SG90, MG90S, etc.) via PWM
#
# ESP8266 important note:
#   Supported PWM GPIOs: 0, 2, 4, 5, 12, 13, 14, 15
#   GPIO16 does NOT support PWM!
#
# Wiring:
#   Orange/Yellow (signal) -> GPIO pin (e.g. D1 = GPIO5)
#   Red   (VCC)  -> 3.3V or external 5V (better for servo)
#   Brown (GND)  -> GND

from machine import Pin, PWM
import utime


class Servo:
    """Simple servo motor controller using PWM."""

    MIN_DUTY = 40     # ~0.5 ms pulse  (0 degrees)
    MAX_DUTY = 115    # ~2.5 ms pulse  (180 degrees)

    def __init__(self, pin, freq=50):
        """
        pin  : machine.Pin object or GPIO number
        freq : PWM frequency in Hz (50 Hz is standard for servos)
        """
        if isinstance(pin, int):
            pin = Pin(pin, Pin.OUT)
        self._pwm = PWM(pin, freq=freq, duty=0)
        self._angle = None

    def write_angle(self, angle):
        """Move servo to angle (0–180 degrees)."""
        angle = max(0, min(180, angle))
        duty = int(self.MIN_DUTY + (self.MAX_DUTY - self.MIN_DUTY) * angle / 180)
        self._pwm.duty(duty)
        self._angle = angle

    def read_angle(self):
        """Return last set angle (None if not set yet)."""
        return self._angle

    def detach(self):
        """Stop PWM signal (servo free to move)."""
        self._pwm.duty(0)

    def deinit(self):
        """Release PWM resource."""
        self._pwm.deinit()
