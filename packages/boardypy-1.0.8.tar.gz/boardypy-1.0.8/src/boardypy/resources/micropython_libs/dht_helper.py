# DHT11 / DHT22 helper for MicroPython
# NOTE: MicroPython already has a built-in 'dht' module!
# This file shows ready-to-use examples and adds convenience functions.
#
# ESP8266 wiring:
#   DATA -> any digital GPIO, e.g. D2 (GPIO4)
#   VCC  -> 3.3V or 5V
#   GND  -> GND
#   (Add a 10kΩ pull-up resistor between DATA and VCC for reliable operation)
#
# Built-in usage (no extra library needed):
#   from machine import Pin
#   import dht
#   d = dht.DHT11(Pin(4))   # or dht.DHT22(Pin(4))
#   d.measure()
#   print(d.temperature())  # °C
#   print(d.humidity())     # %

from machine import Pin
import dht
import utime


def read_dht11(gpio_num):
    """Read DHT11 and return (temperature_C, humidity_pct) or (None, None) on error."""
    try:
        sensor = dht.DHT11(Pin(gpio_num))
        sensor.measure()
        return sensor.temperature(), sensor.humidity()
    except Exception:
        return None, None


def read_dht22(gpio_num):
    """Read DHT22 and return (temperature_C, humidity_pct) or (None, None) on error."""
    try:
        sensor = dht.DHT22(Pin(gpio_num))
        sensor.measure()
        return sensor.temperature(), sensor.humidity()
    except Exception:
        return None, None


def heat_index(temp_c, humidity):
    """
    Calculate the heat index (perceived temperature) in Celsius.
    Equation is an approximation valid for temp > 27°C and humidity > 40%.
    """
    T = temp_c
    R = humidity
    hi = (-8.78469475556 +
          1.61139411 * T +
          2.3385248 * R +
          -0.14611605 * T * R +
          -0.012308094 * T ** 2 +
          -0.016424828 * R ** 2 +
          0.002211732 * T ** 2 * R +
          0.00072546 * T * R ** 2 +
          -0.000003582 * T ** 2 * R ** 2)
    return round(hi, 1)
