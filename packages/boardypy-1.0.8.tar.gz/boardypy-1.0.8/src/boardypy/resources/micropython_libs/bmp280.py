# BMP280 pressure and temperature sensor driver for MicroPython
# Supports I2C interface (address 0x76 or 0x77)
#
# ESP8266 wiring:
#   SDA -> D2 (GPIO4)
#   SCL -> D1 (GPIO5)
#   VCC -> 3.3V  (NOT 5V!)
#   GND -> GND

from machine import I2C
import ustruct

BMP280_I2C_ADDR_LOW  = 0x76
BMP280_I2C_ADDR_HIGH = 0x77


class BMP280:
    """BMP280 temperature and pressure sensor."""

    def __init__(self, i2c, addr=BMP280_I2C_ADDR_LOW):
        self.i2c   = i2c
        self.addr  = addr
        self._load_calibration()
        # config: normal mode, oversampling x2, standby 62.5 ms
        self.i2c.writeto_mem(self.addr, 0xF4, bytes([0x57]))
        self.i2c.writeto_mem(self.addr, 0xF5, bytes([0x90]))

    def _load_calibration(self):
        raw = self.i2c.readfrom_mem(self.addr, 0x88, 24)
        vals = ustruct.unpack('<HhHhhhhhhhhhh'[:12], raw)  # noqa
        (self._T1, self._T2, self._T3,
         self._P1, self._P2, self._P3, self._P4,
         self._P5, self._P6, self._P7, self._P8, self._P9) = (
            vals[0], vals[1], vals[2],
            vals[3], vals[4], vals[5], vals[6],
            vals[7], vals[8], vals[9], vals[10], vals[11]
        )
        # Reload properly
        d = self.i2c.readfrom_mem(self.addr, 0x88, 24)
        self._T1 = ustruct.unpack_from('<H', d, 0)[0]
        self._T2 = ustruct.unpack_from('<h', d, 2)[0]
        self._T3 = ustruct.unpack_from('<h', d, 4)[0]
        self._P1 = ustruct.unpack_from('<H', d, 6)[0]
        self._P2 = ustruct.unpack_from('<h', d, 8)[0]
        self._P3 = ustruct.unpack_from('<h', d, 10)[0]
        self._P4 = ustruct.unpack_from('<h', d, 12)[0]
        self._P5 = ustruct.unpack_from('<h', d, 14)[0]
        self._P6 = ustruct.unpack_from('<h', d, 16)[0]
        self._P7 = ustruct.unpack_from('<h', d, 18)[0]
        self._P8 = ustruct.unpack_from('<h', d, 20)[0]
        self._P9 = ustruct.unpack_from('<h', d, 22)[0]

    def _read_raw(self):
        d = self.i2c.readfrom_mem(self.addr, 0xF7, 6)
        raw_p = (d[0] << 12) | (d[1] << 4) | (d[2] >> 4)
        raw_t = (d[3] << 12) | (d[4] << 4) | (d[5] >> 4)
        return raw_p, raw_t

    def _compensate_temp(self, raw_t):
        v1 = (raw_t / 16384.0 - self._T1 / 1024.0) * self._T2
        v2 = ((raw_t / 131072.0 - self._T1 / 8192.0) ** 2) * self._T3
        t_fine = v1 + v2
        return t_fine / 5120.0, t_fine

    def _compensate_pressure(self, raw_p, t_fine):
        v1 = t_fine / 2.0 - 64000.0
        v2 = v1 * v1 * self._P6 / 32768.0
        v2 += v1 * self._P5 * 2.0
        v2 = v2 / 4.0 + self._P4 * 65536.0
        v1 = (self._P3 * v1 * v1 / 524288.0 + self._P2 * v1) / 524288.0
        v1 = (1.0 + v1 / 32768.0) * self._P1
        if v1 == 0.0:
            return 0.0
        p = 1048576.0 - raw_p
        p = (p - v2 / 4096.0) * 6250.0 / v1
        v1 = self._P9 * p * p / 2147483648.0
        v2 = p * self._P8 / 32768.0
        p += (v1 + v2 + self._P7) / 16.0
        return p

    @property
    def temperature(self):
        """Temperature in degrees Celsius."""
        raw_p, raw_t = self._read_raw()
        temp, _ = self._compensate_temp(raw_t)
        return round(temp, 2)

    @property
    def pressure(self):
        """Pressure in hPa (hectopascals)."""
        raw_p, raw_t = self._read_raw()
        _, t_fine = self._compensate_temp(raw_t)
        press = self._compensate_pressure(raw_p, t_fine)
        return round(press / 100.0, 2)

    @property
    def altitude(self, sea_level_hpa=1013.25):
        """Altitude in metres above sea level (approximate)."""
        p = self.pressure
        return round(44330.0 * (1.0 - (p / sea_level_hpa) ** (1 / 5.255)), 1)
