# stepper.py — MicroPython driver for 28BYJ-48 stepper motor via ULN2003 board
# ESP8266: IN1->D1(GPIO5) IN2->D2(GPIO4) IN3->D3(GPIO0) IN4->D4(GPIO2)
# VCC -> 5V EXTERNAL (motor needs ~240mA, do NOT power from ESP8266 3.3V)
# GND common between ULN2003 board and ESP8266

from machine import Pin
import utime

# Half-step sequence for 28BYJ-48 (8 steps per electrical cycle)
# Gives 4096 steps per full revolution (gear ratio ~1:64, 64*64=4096)
_HALFSTEP = [
    [1, 0, 0, 0],
    [1, 1, 0, 0],
    [0, 1, 0, 0],
    [0, 1, 1, 0],
    [0, 0, 1, 0],
    [0, 0, 1, 1],
    [0, 0, 0, 1],
    [1, 0, 0, 1],
]

# Full-step sequence (4 steps, less torque but faster)
_FULLSTEP = [
    [1, 0, 0, 0],
    [0, 1, 0, 0],
    [0, 0, 1, 0],
    [0, 0, 0, 1],
]

STEPS_PER_REV = 4096   # half-step mode


class Stepper:
    """Driver for 28BYJ-48 stepper motor via ULN2003.

    Usage:
        from stepper import Stepper
        m = Stepper(5, 4, 0, 2)   # IN1, IN2, IN3, IN4 GPIO numbers

        m.step(2048)              # half revolution clockwise
        m.step(-2048)             # half revolution counter-clockwise
        m.angle(360)              # 1 full revolution
        m.angle(-90)              # 90 degrees backward
        m.off()                   # de-energise coils (save power)
    """

    def __init__(self, in1: int, in2: int, in3: int, in4: int,
                 delay_ms: int = 2, half_step: bool = True):
        """
        Args:
            in1..in4: GPIO pin numbers for ULN2003 inputs
            delay_ms: delay between steps (lower = faster but may skip)
            half_step: True = 4096 steps/rev, False = 2048 steps/rev
        """
        self._pins = [
            Pin(in1, Pin.OUT),
            Pin(in2, Pin.OUT),
            Pin(in3, Pin.OUT),
            Pin(in4, Pin.OUT),
        ]
        self._delay   = delay_ms
        self._seq     = _HALFSTEP if half_step else _FULLSTEP
        self._seq_len = len(self._seq)
        self._pos     = 0   # current step index in sequence
        self.off()

    def _set(self, step_idx: int) -> None:
        """Apply coil pattern for given step index."""
        pattern = self._seq[step_idx % self._seq_len]
        for pin, val in zip(self._pins, pattern):
            pin.value(val)

    def step(self, steps: int) -> None:
        """Move by given number of steps. Negative = reverse."""
        direction = 1 if steps >= 0 else -1
        for _ in range(abs(steps)):
            self._pos = (self._pos + direction) % self._seq_len
            self._set(self._pos)
            utime.sleep_ms(self._delay)

    def angle(self, degrees: float) -> None:
        """Rotate by angle in degrees. Negative = reverse."""
        steps = int(STEPS_PER_REV * degrees / 360.0)
        self.step(steps)

    def off(self) -> None:
        """De-energise all coils (motor becomes free, saves power)."""
        for pin in self._pins:
            pin.value(0)

    def set_speed(self, delay_ms: int) -> None:
        """Change step delay in ms (2=fast, 10=slow/more torque)."""
        self._delay = max(1, delay_ms)


# ---------------------------------------------------------------------------
# Quick example:
# ---------------------------------------------------------------------------
if __name__ == '__main__':
    m = Stepper(5, 4, 0, 2)   # D1, D2, D3, D4

    print('Rotating 360 degrees clockwise...')
    m.angle(360)
    utime.sleep(1)

    print('Rotating 360 degrees counter-clockwise...')
    m.angle(-360)
    utime.sleep(1)

    print('Done. De-energising coils.')
    m.off()
