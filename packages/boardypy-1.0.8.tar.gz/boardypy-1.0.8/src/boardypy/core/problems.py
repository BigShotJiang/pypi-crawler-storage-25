from __future__ import annotations

import ast
import re
from dataclasses import dataclass

from .translations import tr


@dataclass(frozen=True)
class CodeProblem:
    severity: str
    line: int
    column: int
    message: str
    code: str
    fix_kind: str = ""
    detail: str = ""


_COMPOUND_LINE_RE = re.compile(
    r"^\s*(async\s+def|def|class|if|elif|else|for|while|try|except|finally|with)\b"
)


def analyze_code(code: str) -> list[CodeProblem]:
    warnings: list[CodeProblem] = []
    if not code.strip():
        return warnings

    lines = code.splitlines()
    for tab_line in _leading_tab_lines(lines):
        warnings.append(
            CodeProblem(
                severity="warning",
                line=tab_line,
                column=1,
                message=tr("problem_tabs"),
                code="tabs_in_indent",
                fix_kind="tabs_to_spaces",
                detail=tr("problem_tabs_detail"),
            )
        )

    for trailing_line in _trailing_space_lines(lines):
        warnings.append(
            CodeProblem(
                severity="warning",
                line=trailing_line,
                column=max(1, len(lines[trailing_line - 1].rstrip(" \t")) + 1),
                message=tr("problem_trailing_ws"),
                code="trailing_whitespace",
                fix_kind="trim_trailing_whitespace",
                detail=tr("problem_trailing_ws_detail"),
            )
        )

    return _syntax_problems(code) + warnings


def _syntax_problems(code: str) -> list[CodeProblem]:
    problems: list[CodeProblem] = []
    working = code
    seen: set[tuple[int, int, str, str]] = set()
    for _ in range(24):
        try:
            ast.parse(working)
            break
        except SyntaxError as exc:
            line = max(1, exc.lineno or 1)
            column = max(1, exc.offset or 1)
            fix_kind = _syntax_fix_kind(working, exc)
            if fix_kind == "add_missing_closer":
                display_line = _missing_closer_fix_line(working, line)
                if display_line:
                    line = display_line
                    column = _line_end_column(working, display_line)
            key = (line, column, exc.msg or "", fix_kind)
            if key in seen:
                break
            seen.add(key)
            problems.append(
                CodeProblem(
                    severity="error",
                    line=line,
                    column=column,
                    message=tr("problem_syntax", msg=exc.msg),
                    code="syntax_error",
                    fix_kind=fix_kind,
                    detail=_fix_detail(fix_kind) or tr("problem_manual_detail"),
                ),
            )
            if not fix_kind:
                break
            fixed_once, _change = _apply_one_syntax_fix(working, exc, fix_kind)
            if fixed_once == working:
                break
            working = fixed_once
    return problems


def _line_end_column(code: str, line_number: int) -> int:
    lines = code.splitlines()
    if line_number < 1 or line_number > len(lines):
        return 1
    return len(lines[line_number - 1].rstrip(" \t")) + 1


def _apply_one_syntax_fix(code: str, exc: SyntaxError, kind: str) -> tuple[str, str]:
    if kind == "add_missing_colon":
        return _add_missing_colon(code, exc.lineno or 1), tr("problem_fix_missing_colon")
    if kind == "wrap_print":
        return _wrap_print_call(code, exc.lineno or 1), tr("problem_fix_print_call")
    if kind == "add_missing_closer":
        return _add_missing_closer(code, exc.lineno or 1), tr("problem_fix_missing_closer")
    if kind == "tabs_to_spaces":
        return _expand_leading_tabs(code), tr("problem_fix_tabs")
    return code, ""


def _leading_tab_lines(lines: list[str]) -> list[int]:
    result: list[int] = []
    for idx, line in enumerate(lines, start=1):
        leading = line[: len(line) - len(line.lstrip(" \t"))]
        if "\t" in leading:
            result.append(idx)
    return result


def _trailing_space_lines(lines: list[str]) -> list[int]:
    return [
        idx
        for idx, line in enumerate(lines, start=1)
        if line.rstrip(" \t") != line
    ]


def _first_leading_tab_line(lines: list[str]) -> int:
    values = _leading_tab_lines(lines)
    return values[0] if values else 0


def _first_trailing_space_line(lines: list[str]) -> int:
    values = _trailing_space_lines(lines)
    return values[0] if values else 0


def apply_safe_fixes(code: str) -> tuple[str, list[str]]:
    fixed = code
    changes: list[str] = []

    if _first_leading_tab_line(fixed.splitlines()):
        fixed = _expand_leading_tabs(fixed)
        changes.append(tr("problem_fix_tabs"))

    if _first_trailing_space_line(fixed.splitlines()):
        fixed = _trim_trailing_whitespace(fixed)
        changes.append(tr("problem_fix_trailing_ws"))

    for _ in range(24):
        try:
            ast.parse(fixed)
            break
        except SyntaxError as exc:
            kind = _syntax_fix_kind(fixed, exc)
            if not kind:
                break
            new_fixed, change = _apply_one_syntax_fix(fixed, exc, kind)

            if new_fixed == fixed:
                break
            fixed = new_fixed
            if change not in changes:
                changes.append(change)

    return fixed, changes


def _syntax_fix_kind(code: str, exc: SyntaxError) -> str:
    msg = (exc.msg or "").lower()
    if "inconsistent use of tabs" in msg or "unindent does not match" in msg:
        return "tabs_to_spaces"
    if "missing parentheses in call to 'print'" in msg and _line_can_wrap_print(code, exc.lineno or 1):
        return "wrap_print"
    if "expected ':'" in msg and _line_can_receive_colon(code, exc.lineno or 1):
        return "add_missing_colon"
    if (
        ("was never closed" in msg or "invalid syntax" in msg)
        and _missing_closer_fix_line(code, exc.lineno or 1)
    ):
        return "add_missing_closer"
    return ""


def _fix_detail(fix_kind: str) -> str:
    if fix_kind == "tabs_to_spaces":
        return tr("problem_tabs_detail")
    if fix_kind == "add_missing_colon":
        return tr("problem_missing_colon_detail")
    if fix_kind == "wrap_print":
        return tr("problem_print_call_detail")
    if fix_kind == "add_missing_closer":
        return tr("problem_missing_closer_detail")
    return ""


def _line_can_receive_colon(code: str, line_number: int) -> bool:
    lines = code.splitlines()
    if line_number < 1 or line_number > len(lines):
        return False
    line = lines[line_number - 1].rstrip(" \t")
    if not line or line.endswith(":") or "#" in line:
        return False
    return bool(_COMPOUND_LINE_RE.match(line))


def _line_can_wrap_print(code: str, line_number: int) -> bool:
    lines = code.splitlines()
    if line_number < 1 or line_number > len(lines):
        return False
    body, _comment = _split_inline_comment(lines[line_number - 1])
    stripped = body.strip()
    if not stripped.startswith("print ") or stripped.startswith("print ("):
        return False
    expr = stripped[len("print ") :].strip()
    return bool(expr) and not expr.startswith(">>")


def _expand_leading_tabs(code: str) -> str:
    fixed_lines: list[str] = []
    for line in code.splitlines(keepends=True):
        newline = ""
        body = line
        if line.endswith("\r\n"):
            body, newline = line[:-2], "\r\n"
        elif line.endswith("\n"):
            body, newline = line[:-1], "\n"
        leading_len = len(body) - len(body.lstrip(" \t"))
        leading = body[:leading_len].expandtabs(4)
        fixed_lines.append(leading + body[leading_len:] + newline)
    return "".join(fixed_lines)


def _trim_trailing_whitespace(code: str) -> str:
    fixed_lines: list[str] = []
    for line in code.splitlines(keepends=True):
        newline = ""
        body = line
        if line.endswith("\r\n"):
            body, newline = line[:-2], "\r\n"
        elif line.endswith("\n"):
            body, newline = line[:-1], "\n"
        fixed_lines.append(body.rstrip(" \t") + newline)
    return "".join(fixed_lines)


def _add_missing_colon(code: str, line_number: int) -> str:
    lines = code.splitlines(keepends=True)
    if line_number < 1 or line_number > len(lines):
        return code

    line = lines[line_number - 1]
    newline = ""
    body = line
    if line.endswith("\r\n"):
        body, newline = line[:-2], "\r\n"
    elif line.endswith("\n"):
        body, newline = line[:-1], "\n"
    if not _line_can_receive_colon(code, line_number):
        return code

    lines[line_number - 1] = body.rstrip(" \t") + ":" + newline
    return "".join(lines)


def _wrap_print_call(code: str, line_number: int) -> str:
    lines = code.splitlines(keepends=True)
    if line_number < 1 or line_number > len(lines):
        return code

    body, newline = _strip_newline(lines[line_number - 1])
    code_part, comment = _split_inline_comment(body)
    stripped = code_part.strip()
    if not _line_can_wrap_print(code, line_number):
        return code

    leading_len = len(code_part) - len(code_part.lstrip(" \t"))
    leading = code_part[:leading_len]
    expr = stripped[len("print ") :].strip()
    suffix = ("  " + comment) if comment else ""
    lines[line_number - 1] = f"{leading}print({expr}){suffix}{newline}"
    return "".join(lines)


def _add_missing_closer(code: str, line_number: int) -> str:
    target_line = _missing_closer_fix_line(code, line_number)
    closers = _missing_closers_for_line(code, target_line)
    if not closers:
        return code

    lines = code.splitlines(keepends=True)
    if target_line < 1 or target_line > len(lines):
        return code

    body, newline = _strip_newline(lines[target_line - 1])
    code_part, comment = _split_inline_comment(body)
    suffix = ("  " + comment) if comment else ""
    lines[target_line - 1] = code_part.rstrip(" \t") + closers + suffix + newline
    return "".join(lines)


def _missing_closer_fix_line(code: str, line_number: int) -> int:
    lines = code.splitlines()
    if not lines:
        return 0
    start = max(1, line_number - 8)
    stop = min(line_number, len(lines))
    for candidate in range(start, stop + 1):
        if _line_has_obvious_missing_closer(code, candidate):
            return candidate

    candidates = [line_number]
    for idx in range(min(line_number - 1, len(lines)), 0, -1):
        if lines[idx - 1].strip():
            candidates.append(idx)
            break
    for candidate in candidates:
        if _missing_closers_for_line(code, candidate):
            return candidate
    return 0


def _line_has_obvious_missing_closer(code: str, line_number: int) -> bool:
    lines = code.splitlines()
    if line_number < 1 or line_number > len(lines):
        return False
    if not _missing_closers_for_line(code, line_number):
        return False

    line = lines[line_number - 1]
    stripped = line.strip()
    if not stripped or stripped.endswith((",", "\\")):
        return False

    current_indent = _indent_columns(line)
    for next_line in lines[line_number:]:
        if not next_line.strip():
            return True
        return _indent_columns(next_line) <= current_indent
    return True


def _indent_columns(line: str) -> int:
    count = 0
    for char in line:
        if char == " ":
            count += 1
        elif char == "\t":
            count += 4
        else:
            break
    return count


def _missing_closers_for_line(code: str, line_number: int) -> str:
    lines = code.splitlines()
    if line_number < 1 or line_number > len(lines):
        return ""
    code_part, _comment = _split_inline_comment(lines[line_number - 1])
    stack: list[str] = []
    pairs = {"(": ")", "[": "]", "{": "}"}
    closers = {")": "(", "]": "[", "}": "{"}
    quote = ""
    escape = False
    idx = 0
    while idx < len(code_part):
        ch = code_part[idx]
        if quote:
            if escape:
                escape = False
            elif ch == "\\":
                escape = True
            elif ch == quote:
                quote = ""
            idx += 1
            continue
        if ch in ("'", '"'):
            quote = ch
        elif ch in pairs:
            stack.append(ch)
        elif ch in closers:
            if not stack or stack[-1] != closers[ch]:
                return ""
            stack.pop()
        idx += 1
    if quote or not stack or len(stack) > 3:
        return ""
    return "".join(pairs[ch] for ch in reversed(stack))


def _strip_newline(line: str) -> tuple[str, str]:
    if line.endswith("\r\n"):
        return line[:-2], "\r\n"
    if line.endswith("\n"):
        return line[:-1], "\n"
    return line, ""


def _split_inline_comment(line: str) -> tuple[str, str]:
    quote = ""
    escape = False
    for idx, ch in enumerate(line):
        if quote:
            if escape:
                escape = False
            elif ch == "\\":
                escape = True
            elif ch == quote:
                quote = ""
            continue
        if ch in ("'", '"'):
            quote = ch
        elif ch == "#":
            return line[:idx].rstrip(" \t"), line[idx:]
    return line, ""
