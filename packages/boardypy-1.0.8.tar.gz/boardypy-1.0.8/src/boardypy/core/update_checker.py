from __future__ import annotations

import json
import re
import urllib.request

from PyQt5.QtCore import QThread, pyqtSignal


def _version_tuple(value: str) -> tuple[int, ...]:
    parts = re.findall(r"\d+", value or "")
    if not parts:
        return (0,)
    return tuple(int(part) for part in parts)


def is_newer_version(remote: str, current: str) -> bool:
    remote_parts = _version_tuple(remote)
    current_parts = _version_tuple(current)
    max_len = max(len(remote_parts), len(current_parts))
    remote_parts += (0,) * (max_len - len(remote_parts))
    current_parts += (0,) * (max_len - len(current_parts))
    return remote_parts > current_parts


class UpdateCheckThread(QThread):
    update_available = pyqtSignal(dict)
    no_update = pyqtSignal()
    check_failed = pyqtSignal(str)

    def __init__(self, current_version: str, feed_url: str, parent=None) -> None:
        super().__init__(parent)
        self._current_version = current_version
        self._feed_url = feed_url.strip()

    def run(self) -> None:
        if not self._feed_url:
            self.no_update.emit()
            return

        request = urllib.request.Request(
            self._feed_url,
            headers={"User-Agent": "BoardyPy-UpdateChecker/1.0"},
        )

        try:
            with urllib.request.urlopen(request, timeout=3) as response:
                raw = response.read().decode("utf-8")
            payload = json.loads(raw)
            remote_version = str(payload.get("version", "")).strip()
            if not remote_version:
                raise ValueError("Missing 'version' in update feed")
            if is_newer_version(remote_version, self._current_version):
                payload["version"] = remote_version
                self.update_available.emit(payload)
                return
            self.no_update.emit()
        except Exception as exc:
            self.check_failed.emit(str(exc))
