from __future__ import annotations

import os
import sys
import subprocess
import tempfile
from typing import Optional

from PyQt5.QtCore import QThread, pyqtSignal, QProcess


class LocalPythonRunner(QThread):
    """Run a Python script in a subprocess, streaming stdout/stderr back."""

    output_received = pyqtSignal(str)
    error_received = pyqtSignal(str)
    finished_with_code = pyqtSignal(int)

    def __init__(
        self,
        code: str,
        python_path: Optional[str] = None,
        filepath: Optional[str] = None,
    ) -> None:
        super().__init__()
        self._code = code
        self._python = python_path or self._find_python()
        self._filepath = filepath  # If set, run this file directly
        self._process: Optional[subprocess.Popen] = None
        self._stopped = False
        self._tmp_file: Optional[str] = None  # temp file path if we created one

    @staticmethod
    def _find_python() -> str:
        """Find a real Python interpreter (not the frozen .exe)."""
        # If not frozen — sys.executable is fine
        if not getattr(sys, 'frozen', False):
            return sys.executable
        # Frozen .exe — search for system Python
        import shutil
        for name in ("python3", "python"):
            found = shutil.which(name)
            if found:
                return found
        # Fallback: common Windows paths
        for ver in ("313", "312", "311", "310", "39"):
            for base in (
                os.path.expandvars(rf"%LOCALAPPDATA%\Programs\Python\Python{ver}"),
                rf"C:\Python{ver}",
            ):
                exe = os.path.join(base, "python.exe")
                if os.path.isfile(exe):
                    return exe
        # Last resort
        return "python"

    def run(self) -> None:
        try:
            # Determine what to run and working directory
            if self._filepath and os.path.isfile(self._filepath):
                # Run the actual saved file — __file__ is set, imports work
                run_path = self._filepath
                workdir = os.path.dirname(self._filepath) or None
                cmd = [self._python, "-u", run_path]
            else:
                # No file — write code to a temp file so __file__ and cwd work
                tmp = tempfile.NamedTemporaryFile(
                    mode="w", suffix=".py", delete=False, encoding="utf-8"
                )
                tmp.write(self._code)
                tmp.flush()
                tmp.close()
                self._tmp_file = tmp.name
                run_path = tmp.name
                workdir = None
                cmd = [self._python, "-u", run_path]

            self._process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                stdin=subprocess.PIPE,
                text=True,
                bufsize=1,
                cwd=workdir,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
            )

            for line in self._process.stdout:
                if self._stopped:
                    break
                self.output_received.emit(line)

            self._process.wait()
            rc = self._process.returncode if self._process.returncode is not None else -1
            self.finished_with_code.emit(rc)

        except Exception as exc:
            self.error_received.emit(str(exc))
            self.finished_with_code.emit(-1)
        finally:
            # Clean up temp file if we created one
            if self._tmp_file:
                try:
                    os.unlink(self._tmp_file)
                except Exception:
                    pass
                self._tmp_file = None

    def stop(self) -> None:
        self._stopped = True
        if self._process and self._process.poll() is None:
            try:
                self._process.terminate()
                self._process.wait(timeout=2)
            except Exception:
                try:
                    self._process.kill()
                except Exception:
                    pass

    def send_input(self, text: str) -> None:
        if self._process and self._process.poll() is None and self._process.stdin:
            try:
                self._process.stdin.write(text)
                self._process.stdin.flush()
            except Exception:
                pass
