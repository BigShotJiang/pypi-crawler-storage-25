"""Interact with MicroPython file-system over raw REPL."""
from __future__ import annotations

import time
import serial
from typing import Optional, TYPE_CHECKING
from PyQt5.QtCore import QThread, pyqtSignal, QMutex, QMutexLocker

if TYPE_CHECKING:
    from .serial_manager import SerialManager


# ---------------------------------------------------------------------------
# Blocking helper that talks directly to the serial port via raw-REPL
# ---------------------------------------------------------------------------

class DeviceFS:
    """
    Low-level helper.  Every public method **blocks**, so always call
    from a worker thread, never the GUI thread.
    """

    ENTER_RAW  = b"\x01"
    EXIT_RAW   = b"\x02"
    CTRL_C     = b"\x03"
    CTRL_D     = b"\x04"
    RAW_OK     = b"OK"
    TERMINATOR = b"\x04>"
    WRITE_CHUNK_BYTES = 256

    def __init__(self, ser: serial.Serial, timeout: float = 8.0) -> None:
        self._ser = ser
        self._timeout = timeout

    # ------------------------------------------------------------------

    def _enter_raw(self) -> None:
        # Interrupt any running program
        self._ser.write(self.CTRL_C)
        time.sleep(0.15)
        self._ser.write(self.CTRL_C)
        time.sleep(0.2)
        self._ser.reset_input_buffer()

        # Try entering raw REPL up to 3 times
        for _attempt in range(3):
            self._ser.write(self.ENTER_RAW)
            deadline = time.monotonic() + 2.0
            buf = b""
            while time.monotonic() < deadline:
                if self._ser.in_waiting:
                    buf += self._ser.read(self._ser.in_waiting)
                if b"raw REPL" in buf or (b">" in buf and b">>>" not in buf):
                    self._ser.reset_input_buffer()
                    return
                time.sleep(0.05)
            # Retry: interrupt and try again
            self._ser.write(self.CTRL_C)
            time.sleep(0.2)
            self._ser.reset_input_buffer()
        # Last resort — just proceed
        self._ser.reset_input_buffer()

    def _exit_raw(self) -> None:
        self._ser.write(self.EXIT_RAW)
        time.sleep(0.1)
        self._ser.reset_input_buffer()

    def _exec_raw_in_session(self, code: str) -> tuple[str, str]:
        """Execute code while already inside raw REPL. Returns (stdout, stderr)."""
        # Send code in small chunks to avoid overflow
        encoded = code.encode("utf-8")
        chunk = 128
        for i in range(0, len(encoded), chunk):
            self._ser.write(encoded[i:i+chunk])
            time.sleep(0.02)

        # CTRL-D = execute
        self._ser.write(self.CTRL_D)

        # Read until OK marker
        buf = b""
        deadline = time.monotonic() + self._timeout
        while time.monotonic() < deadline:
            if self._ser.in_waiting:
                buf += self._ser.read(self._ser.in_waiting)
            if self.RAW_OK in buf:
                idx = buf.index(self.RAW_OK)
                buf = buf[idx + len(self.RAW_OK):]
                break
            time.sleep(0.02)

        # Read stdout\x04stderr\x04>
        deadline = time.monotonic() + self._timeout
        while time.monotonic() < deadline:
            if self._ser.in_waiting:
                buf += self._ser.read(self._ser.in_waiting)
            if self.TERMINATOR in buf:
                break
            time.sleep(0.02)

        # Parse: stdout \x04 stderr \x04 >
        raw = buf.split(b"\x04>")[0] if b"\x04>" in buf else buf
        parts = raw.split(b"\x04", 1)
        stdout = parts[0].decode("utf-8", errors="replace").strip()
        stderr = parts[1].decode("utf-8", errors="replace").strip() if len(parts) > 1 else ""
        return stdout, stderr

    def _exec_raw(self, code: str) -> tuple[str, str]:
        """Execute *code* in raw REPL.  Returns (stdout, stderr)."""
        self._enter_raw()
        try:
            return self._exec_raw_in_session(code)
        finally:
            self._exit_raw()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def listdir(self, path: str = "/") -> list[dict]:
        """Return list of {name, type, size}."""
        # Use tab-separated output — no json dependency on device
        code = (
            "import os\n"
            f"_p={path!r}\n"
            "try:\n"
            "    _ls=os.listdir(_p)\n"
            "except OSError:\n"
            "    _ls=[]\n"
            "for _n in _ls:\n"
            "    _fp=_p.rstrip('/')+'/'+_n\n"
            "    try:\n"
            "        _s=os.stat(_fp)\n"
            "        _t='dir' if _s[0]&0x4000 else 'file'\n"
            "        print(_n+'\\t'+_t+'\\t'+str(_s[6]))\n"
            "    except OSError:\n"
            "        print(_n+'\\tfile\\t0')\n"
        )
        stdout, stderr = self._exec_raw(code)
        if stderr:
            raise RuntimeError(stderr)
        result = []
        for line in stdout.splitlines():
            parts = line.split("\t")
            if len(parts) >= 3:
                result.append({
                    "name": parts[0],
                    "type": parts[1],
                    "size": int(parts[2]) if parts[2].isdigit() else 0,
                })
        return result

    def read_file(self, path: str) -> bytes:
        """Read entire file from device."""
        code = (
            "import sys\n"
            "try:\n"
            "    from ubinascii import hexlify\n"
            "except:\n"
            "    from binascii import hexlify\n"
            f"with open({path!r},'rb') as _f:\n"
            "    while True:\n"
            "        _c=_f.read(256)\n"
            "        if not _c: break\n"
            "        sys.stdout.write(hexlify(_c).decode())\n"
        )
        stdout, stderr = self._exec_raw(code)
        if stderr:
            raise RuntimeError(stderr)
        try:
            return bytes.fromhex(stdout)
        except ValueError:
            raise RuntimeError(f"Bad hex response ({len(stdout)} chars)")

    def write_file(self, path: str, data: bytes) -> None:
        """Write data to path on device using chunked writes optimized for ESP8266."""
        error: Exception | None = None
        try:
            self._enter_raw()
            init_code = (
                "import gc\n"
                "try:\n"
                "    from ubinascii import unhexlify\n"
                "except:\n"
                "    from binascii import unhexlify\n"
                "gc.collect()\n"
                f"_f=open({path!r},'wb')\n"
                "print('OK')\n"
            )
            _, stderr = self._exec_raw_in_session(init_code)
            if stderr:
                raise RuntimeError(stderr)

            for index, i in enumerate(range(0, len(data), self.WRITE_CHUNK_BYTES), start=1):
                part = data[i:i + self.WRITE_CHUNK_BYTES].hex()
                chunk_code = [f"_f.write(unhexlify('{part}'))"]
                if index % 8 == 0:
                    chunk_code.append("gc.collect()")
                chunk_code.append("print('OK')")
                _, stderr = self._exec_raw_in_session("\n".join(chunk_code) + "\n")
                if stderr:
                    raise RuntimeError(stderr)
            _, stderr = self._exec_raw_in_session(
                "_f.close()\n"
                "del _f\n"
                "gc.collect()\n"
                "print('OK')\n"
            )
            if stderr:
                raise RuntimeError(stderr)
        except Exception as exc:
            error = exc
        finally:
            self._exit_raw()

        if error is not None:
            try:
                self.remove_if_exists(path)
            except Exception:
                pass
            raise error

    def mkdir(self, path: str) -> None:
        code = f"import os\nos.mkdir({path!r})\nprint('OK')\n"
        _, stderr = self._exec_raw(code)
        if stderr:
            raise RuntimeError(stderr)

    def mkdir_if_missing(self, path: str) -> None:
        code = (
            "import os\n"
            "try:\n"
            f"    os.mkdir({path!r})\n"
            "except OSError:\n"
            "    pass\n"
            "print('OK')\n"
        )
        _, stderr = self._exec_raw(code)
        if stderr:
            raise RuntimeError(stderr)

    def remove(self, path: str) -> None:
        code = (
            "import os\n"
            "try:\n"
            f"    os.remove({path!r})\n"
            "except:\n"
            f"    os.rmdir({path!r})\n"
            "print('OK')\n"
        )
        _, stderr = self._exec_raw(code)
        if stderr:
            raise RuntimeError(stderr)

    def remove_if_exists(self, path: str) -> None:
        code = (
            "import os\n"
            "try:\n"
            f"    os.remove({path!r})\n"
            "except OSError:\n"
            "    pass\n"
            "print('OK')\n"
        )
        _, stderr = self._exec_raw(code)
        if stderr:
            raise RuntimeError(stderr)


# ---------------------------------------------------------------------------
# Worker thread — pauses serial reader around each operation
# ---------------------------------------------------------------------------

class DeviceFSWorker(QThread):
    listing_ready    = pyqtSignal(str, list)
    file_downloaded  = pyqtSignal(str, bytes)
    file_uploaded    = pyqtSignal(str)
    dir_created      = pyqtSignal(str)
    item_removed     = pyqtSignal(str)
    error_occurred   = pyqtSignal(str)
    busy_changed     = pyqtSignal(bool)

    def __init__(self) -> None:
        super().__init__()
        self._serial_mgr: Optional["SerialManager"] = None
        self._queue: list[tuple] = []
        self._mutex = QMutex()
        self._running = True

    def set_serial_manager(self, mgr: "SerialManager | None") -> None:
        with QMutexLocker(self._mutex):
            self._serial_mgr = mgr

    def request_list(self, path: str = "/") -> None:
        with QMutexLocker(self._mutex):
            self._queue.append(("list", path))

    def request_download(self, remote_path: str) -> None:
        with QMutexLocker(self._mutex):
            self._queue.append(("download", remote_path))

    def request_upload(self, remote_path: str, data: bytes) -> None:
        with QMutexLocker(self._mutex):
            self._queue.append(("upload", remote_path, data))

    def request_replace_upload(self, remote_path: str, data: bytes) -> None:
        with QMutexLocker(self._mutex):
            self._queue.append(("replace_upload", remote_path, data))

    def request_replace_library_upload(self, remote_path: str, data: bytes) -> None:
        with QMutexLocker(self._mutex):
            self._queue.append(("replace_library_upload", remote_path, data))

    def request_mkdir(self, remote_path: str) -> None:
        with QMutexLocker(self._mutex):
            self._queue.append(("mkdir", remote_path))

    def request_mkdir_if_missing(self, remote_path: str) -> None:
        with QMutexLocker(self._mutex):
            self._queue.append(("mkdir_if_missing", remote_path))

    def request_remove(self, remote_path: str) -> None:
        with QMutexLocker(self._mutex):
            self._queue.append(("remove", remote_path))

    def stop(self) -> None:
        self._running = False

    def run(self) -> None:
        while self._running:
            job = None
            with QMutexLocker(self._mutex):
                if self._queue:
                    job = self._queue.pop(0)
                mgr = self._serial_mgr

            if job is None or mgr is None:
                self.msleep(100)
                continue

            raw_ser = mgr.raw_serial
            if raw_ser is None or not raw_ser.is_open:
                self.msleep(100)
                continue

            self.busy_changed.emit(True)
            # Pause reader so we own the serial port exclusively
            mgr.pause_reader()
            try:
                fs = DeviceFS(raw_ser)
                kind = job[0]
                if kind == "list":
                    entries = fs.listdir(job[1])
                    self.listing_ready.emit(job[1], entries)
                elif kind == "download":
                    data = fs.read_file(job[1])
                    self.file_downloaded.emit(job[1], data)
                elif kind == "upload":
                    fs.write_file(job[1], job[2])
                    self.file_uploaded.emit(job[1])
                elif kind == "replace_upload":
                    fs.remove_if_exists(job[1])
                    fs.write_file(job[1], job[2])
                    self.file_uploaded.emit(job[1])
                elif kind == "replace_library_upload":
                    remote_path = job[1]
                    base, ext = remote_path.rsplit(".", 1) if "." in remote_path else (remote_path, "")
                    fs.remove_if_exists(remote_path)
                    if ext in ("py", "mpy"):
                        other_ext = "mpy" if ext == "py" else "py"
                        fs.remove_if_exists(f"{base}.{other_ext}")
                    fs.write_file(remote_path, job[2])
                    self.file_uploaded.emit(remote_path)
                elif kind == "mkdir":
                    fs.mkdir(job[1])
                    self.dir_created.emit(job[1])
                elif kind == "mkdir_if_missing":
                    fs.mkdir_if_missing(job[1])
                    self.dir_created.emit(job[1])
                elif kind == "remove":
                    fs.remove(job[1])
                    self.item_removed.emit(job[1])
            except Exception as exc:
                self.error_occurred.emit(str(exc))
            finally:
                # Resume reader
                mgr.resume_reader()
                self.busy_changed.emit(False)
