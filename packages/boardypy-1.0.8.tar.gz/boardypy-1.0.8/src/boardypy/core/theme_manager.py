from __future__ import annotations

import sys
from PyQt5.QtWidgets import QApplication
from PyQt5.QtGui import QPalette, QColor

# ---------------------------------------------------------------------------
# Palette-based detection for "System" theme
# ---------------------------------------------------------------------------

def _is_system_dark() -> bool:
    """Return True when the OS / desktop is using a dark colour scheme."""
    app = QApplication.instance()
    if app is None:
        return False
    palette = app.palette()
    window_color: QColor = palette.color(QPalette.Window)
    # If the window background luminance is below ~0.5 → dark
    return window_color.lightness() < 128


# ---------------------------------------------------------------------------
# Stylesheets
# ---------------------------------------------------------------------------

_LIGHT_QSS = """
QMainWindow, QDialog {
    background-color: #e8e8ec;
    color: #1e1e1e;
}
QMenuBar {
    background-color: #dddde1;
    color: #1e1e1e;
    border-bottom: 1px solid #b8b8bc;
}
QMenuBar::item:selected {
    background-color: #c8c8cc;
}
QMenu {
    background-color: #f0f0f3;
    color: #1e1e1e;
    border: 1px solid #b8b8bc;
    padding: 4px 0px;
}
QMenu::item {
    padding: 6px 30px 6px 20px;
    min-width: 180px;
}
QMenu::item:selected {
    background-color: #0078d4;
    color: #ffffff;
}
QMenu::separator {
    height: 1px;
    background-color: #b8b8bc;
    margin: 4px 10px;
}
QTabWidget::pane {
    border: 1px solid #b8b8bc;
    background-color: #f0f0f3;
}
QTabBar::tab {
    background-color: #d4d4d8;
    color: #1e1e1e;
    padding: 5px 12px;
    border: 1px solid transparent;
    border-bottom: none;
    margin-right: 2px;
}
QTabBar::tab:selected {
    background-color: #f0f0f3;
    border-bottom: 1px solid #f0f0f3;
}
QTabBar::tab:hover {
    background-color: #c8c8cc;
}
QPlainTextEdit, QTextEdit {
    background-color: #f5f5f7;
    color: #1e1e1e;
    selection-background-color: #add6ff;
    selection-color: #1e1e1e;
    border: none;
}
QLineEdit {
    background-color: #f0f0f3;
    color: #1e1e1e;
    border: 1px solid #b8b8bc;
    padding: 3px;
}
QDockWidget {
    titlebar-close-icon: url(none);
    color: #1e1e1e;
}
QDockWidget::title {
    background-color: #d4d4d8;
    padding: 4px;
    border-bottom: 1px solid #b8b8bc;
}
QTreeView {
    background-color: #ebebef;
    color: #1e1e1e;
    border: none;
}
QTreeView::item:selected {
    background-color: #0078d4;
    color: #ffffff;
}
QTreeView::item:hover {
    background-color: #d0e0f0;
}
QScrollBar:vertical {
    background-color: #e8e8ec;
    width: 12px;
}
QScrollBar::handle:vertical {
    background-color: #b0b0b4;
    min-height: 20px;
    border-radius: 6px;
}
QScrollBar::handle:vertical:hover {
    background-color: #909094;
}
QScrollBar:horizontal {
    background-color: #e8e8ec;
    height: 12px;
}
QScrollBar::handle:horizontal {
    background-color: #b0b0b4;
    min-width: 20px;
    border-radius: 6px;
}
QScrollBar::add-line, QScrollBar::sub-line {
    width: 0px;
    height: 0px;
}
QPushButton {
    background-color: #d4d4d8;
    color: #1e1e1e;
    border: 1px solid #b0b0b4;
    padding: 4px 10px;
    border-radius: 3px;
}
QPushButton:hover {
    background-color: #c0c0c4;
}
QPushButton:pressed {
    background-color: #a8a8ac;
}
QStatusBar {
    background-color: #0078d4;
    color: #ffffff;
    border-top: 1px solid #005a9e;
}
QToolBar {
    background-color: #dddde1;
    border-bottom: 1px solid #b8b8bc;
    spacing: 3px;
}
QComboBox {
    background-color: #f0f0f3;
    color: #1e1e1e;
    border: 1px solid #b8b8bc;
    padding: 3px;
}
QLabel {
    color: #1e1e1e;
}
"""

_DARK_QSS = """
QMainWindow, QDialog {
    background-color: #1e1e1e;
    color: #d4d4d4;
}
QMenuBar {
    background-color: #2d2d2d;
    color: #d4d4d4;
    border-bottom: 1px solid #3c3c3c;
}
QMenuBar::item:selected {
    background-color: #3c3c3c;
}
QMenu {
    background-color: #252526;
    color: #d4d4d4;
    border: 1px solid #3c3c3c;
    padding: 4px 0px;
}
QMenu::item {
    padding: 6px 30px 6px 20px;
    min-width: 180px;
}
QMenu::item:selected {
    background-color: #094771;
    color: #ffffff;
}
QMenu::separator {
    height: 1px;
    background-color: #3c3c3c;
    margin: 4px 10px;
}
QTabWidget::pane {
    border: 1px solid #3c3c3c;
    background-color: #1e1e1e;
}
QTabBar::tab {
    background-color: #2d2d2d;
    color: #d4d4d4;
    padding: 5px 12px;
    border: 1px solid transparent;
    border-bottom: none;
    margin-right: 2px;
}
QTabBar::tab:selected {
    background-color: #1e1e1e;
    color: #ffffff;
    border-bottom: 1px solid #1e1e1e;
}
QTabBar::tab:hover {
    background-color: #3c3c3c;
}
QPlainTextEdit, QTextEdit {
    background-color: #1e1e1e;
    color: #d4d4d4;
    selection-background-color: #264f78;
    selection-color: #d4d4d4;
    border: none;
}
QLineEdit {
    background-color: #3c3c3c;
    color: #d4d4d4;
    border: 1px solid #555555;
    padding: 3px;
}
QDockWidget {
    titlebar-close-icon: url(none);
    color: #d4d4d4;
}
QDockWidget::title {
    background-color: #2d2d2d;
    padding: 4px;
    border-bottom: 1px solid #3c3c3c;
}
QTreeView {
    background-color: #252526;
    color: #d4d4d4;
    border: none;
}
QTreeView::item:selected {
    background-color: #094771;
    color: #ffffff;
}
QTreeView::item:hover {
    background-color: #2a2d2e;
}
QScrollBar:vertical {
    background-color: #1e1e1e;
    width: 12px;
}
QScrollBar::handle:vertical {
    background-color: #424242;
    min-height: 20px;
    border-radius: 6px;
}
QScrollBar::handle:vertical:hover {
    background-color: #686868;
}
QScrollBar:horizontal {
    background-color: #1e1e1e;
    height: 12px;
}
QScrollBar::handle:horizontal {
    background-color: #424242;
    min-width: 20px;
    border-radius: 6px;
}
QScrollBar::add-line, QScrollBar::sub-line {
    width: 0px;
    height: 0px;
}
QPushButton {
    background-color: #3c3c3c;
    color: #d4d4d4;
    border: 1px solid #555555;
    padding: 4px 10px;
    border-radius: 3px;
}
QPushButton:hover {
    background-color: #4c4c4c;
}
QPushButton:pressed {
    background-color: #2c2c2c;
}
QStatusBar {
    background-color: #007acc;
    color: #ffffff;
    border-top: 1px solid #005a9e;
}
QToolBar {
    background-color: #2d2d2d;
    border-bottom: 1px solid #3c3c3c;
    spacing: 3px;
}
QComboBox {
    background-color: #3c3c3c;
    color: #d4d4d4;
    border: 1px solid #555555;
    padding: 3px;
}
QLabel {
    color: #d4d4d4;
}
"""


# ---------------------------------------------------------------------------
# Monokai theme
# ---------------------------------------------------------------------------

_MONOKAI_QSS = """
QMainWindow, QDialog {
    background-color: #272822;
    color: #f8f8f2;
}
QMenuBar {
    background-color: #3e3d32;
    color: #f8f8f2;
    border-bottom: 1px solid #49483e;
}
QMenuBar::item:selected {
    background-color: #49483e;
}
QMenu {
    background-color: #272822;
    color: #f8f8f2;
    border: 1px solid #49483e;
    padding: 4px 0px;
}
QMenu::item {
    padding: 6px 30px 6px 20px;
    min-width: 180px;
}
QMenu::item:selected {
    background-color: #49483e;
    color: #f8f8f2;
}
QMenu::separator {
    height: 1px;
    background-color: #49483e;
    margin: 4px 10px;
}
QTabWidget::pane {
    border: 1px solid #49483e;
    background-color: #272822;
}
QTabBar::tab {
    background-color: #3e3d32;
    color: #a6a28c;
    padding: 5px 12px;
    border: 1px solid transparent;
    border-bottom: none;
    margin-right: 2px;
}
QTabBar::tab:selected {
    background-color: #272822;
    color: #f8f8f2;
    border-bottom: 1px solid #272822;
}
QTabBar::tab:hover {
    background-color: #49483e;
}
QPlainTextEdit, QTextEdit {
    background-color: #272822;
    color: #f8f8f2;
    selection-background-color: #49483e;
    selection-color: #f8f8f2;
    border: none;
}
QLineEdit {
    background-color: #3e3d32;
    color: #f8f8f2;
    border: 1px solid #49483e;
    padding: 3px;
}
QDockWidget {
    titlebar-close-icon: url(none);
    color: #f8f8f2;
}
QDockWidget::title {
    background-color: #3e3d32;
    padding: 4px;
    border-bottom: 1px solid #49483e;
}
QTreeView {
    background-color: #272822;
    color: #f8f8f2;
    border: none;
}
QTreeView::item:selected {
    background-color: #49483e;
    color: #a6e22e;
}
QTreeView::item:hover {
    background-color: #3e3d32;
}
QScrollBar:vertical {
    background-color: #272822;
    width: 12px;
}
QScrollBar::handle:vertical {
    background-color: #49483e;
    min-height: 20px;
    border-radius: 6px;
}
QScrollBar::handle:vertical:hover {
    background-color: #75715e;
}
QScrollBar:horizontal {
    background-color: #272822;
    height: 12px;
}
QScrollBar::handle:horizontal {
    background-color: #49483e;
    min-width: 20px;
    border-radius: 6px;
}
QScrollBar::add-line, QScrollBar::sub-line {
    width: 0px;
    height: 0px;
}
QPushButton {
    background-color: #3e3d32;
    color: #f8f8f2;
    border: 1px solid #49483e;
    padding: 4px 10px;
    border-radius: 3px;
}
QPushButton:hover {
    background-color: #49483e;
}
QPushButton:pressed {
    background-color: #272822;
}
QStatusBar {
    background-color: #a6e22e;
    color: #272822;
    border-top: 1px solid #75715e;
}
QToolBar {
    background-color: #3e3d32;
    border-bottom: 1px solid #49483e;
    spacing: 3px;
}
QComboBox {
    background-color: #3e3d32;
    color: #f8f8f2;
    border: 1px solid #49483e;
    padding: 3px;
}
QLabel {
    color: #f8f8f2;
}
"""

# ---------------------------------------------------------------------------
# Nord theme
# ---------------------------------------------------------------------------

_NORD_QSS = """
QMainWindow, QDialog {
    background-color: #2e3440;
    color: #d8dee9;
}
QMenuBar {
    background-color: #3b4252;
    color: #d8dee9;
    border-bottom: 1px solid #434c5e;
}
QMenuBar::item:selected {
    background-color: #434c5e;
}
QMenu {
    background-color: #3b4252;
    color: #d8dee9;
    border: 1px solid #434c5e;
    padding: 4px 0px;
}
QMenu::item {
    padding: 6px 30px 6px 20px;
    min-width: 180px;
}
QMenu::item:selected {
    background-color: #5e81ac;
    color: #eceff4;
}
QMenu::separator {
    height: 1px;
    background-color: #434c5e;
    margin: 4px 10px;
}
QTabWidget::pane {
    border: 1px solid #434c5e;
    background-color: #2e3440;
}
QTabBar::tab {
    background-color: #3b4252;
    color: #d8dee9;
    padding: 5px 12px;
    border: 1px solid transparent;
    border-bottom: none;
    margin-right: 2px;
}
QTabBar::tab:selected {
    background-color: #2e3440;
    color: #eceff4;
    border-bottom: 1px solid #2e3440;
}
QTabBar::tab:hover {
    background-color: #434c5e;
}
QPlainTextEdit, QTextEdit {
    background-color: #2e3440;
    color: #d8dee9;
    selection-background-color: #434c5e;
    selection-color: #eceff4;
    border: none;
}
QLineEdit {
    background-color: #3b4252;
    color: #d8dee9;
    border: 1px solid #434c5e;
    padding: 3px;
}
QDockWidget {
    titlebar-close-icon: url(none);
    color: #d8dee9;
}
QDockWidget::title {
    background-color: #3b4252;
    padding: 4px;
    border-bottom: 1px solid #434c5e;
}
QTreeView {
    background-color: #2e3440;
    color: #d8dee9;
    border: none;
}
QTreeView::item:selected {
    background-color: #5e81ac;
    color: #eceff4;
}
QTreeView::item:hover {
    background-color: #3b4252;
}
QScrollBar:vertical {
    background-color: #2e3440;
    width: 12px;
}
QScrollBar::handle:vertical {
    background-color: #4c566a;
    min-height: 20px;
    border-radius: 6px;
}
QScrollBar::handle:vertical:hover {
    background-color: #5e81ac;
}
QScrollBar:horizontal {
    background-color: #2e3440;
    height: 12px;
}
QScrollBar::handle:horizontal {
    background-color: #4c566a;
    min-width: 20px;
    border-radius: 6px;
}
QScrollBar::add-line, QScrollBar::sub-line {
    width: 0px;
    height: 0px;
}
QPushButton {
    background-color: #3b4252;
    color: #d8dee9;
    border: 1px solid #434c5e;
    padding: 4px 10px;
    border-radius: 3px;
}
QPushButton:hover {
    background-color: #434c5e;
}
QPushButton:pressed {
    background-color: #2e3440;
}
QStatusBar {
    background-color: #5e81ac;
    color: #eceff4;
    border-top: 1px solid #4c566a;
}
QToolBar {
    background-color: #3b4252;
    border-bottom: 1px solid #434c5e;
    spacing: 3px;
}
QComboBox {
    background-color: #3b4252;
    color: #d8dee9;
    border: 1px solid #434c5e;
    padding: 3px;
}
QLabel {
    color: #d8dee9;
}
"""


_THEME_MAP = {
    "Light": (_LIGHT_QSS, False),
    "Dark": (_DARK_QSS, True),
    "Monokai": (_MONOKAI_QSS, True),
    "Nord": (_NORD_QSS, True),
}


class ThemeManager:
    THEMES = ("Light", "Dark", "Monokai", "Nord", "System")

    def __init__(self) -> None:
        self._current: str = "System"

    # ------------------------------------------------------------------
    def apply(self, theme_name: str) -> None:
        app = QApplication.instance()
        if app is None:
            return
        self._current = theme_name

        if theme_name == "System":
            qss = _DARK_QSS if _is_system_dark() else _LIGHT_QSS
        else:
            qss = _THEME_MAP.get(theme_name, (_LIGHT_QSS, False))[0]
        app.setStyleSheet(qss)

    @property
    def current(self) -> str:
        return self._current

    def is_dark(self) -> bool:
        if self._current == "System":
            return _is_system_dark()
        entry = _THEME_MAP.get(self._current)
        return entry[1] if entry else False
