from __future__ import annotations

import codecs
import serial
import serial.tools.list_ports
from typing import Optional, List

from PyQt5.QtCore import QObject, QThread, pyqtSignal, QMutex, QMutexLocker, QTimer


# ---------------------------------------------------------------------------
# Serial reader thread — non-blocking, thread-safe
# ---------------------------------------------------------------------------

class _SerialReaderThread(QThread):
    data_received = pyqtSignal(str)
    error_occurred = pyqtSignal(str)

    def __init__(self, port: serial.Serial) -> None:
        super().__init__()
        self._port = port
        self._running = True
        # Incremental UTF-8 decoder: buffers incomplete multi-byte sequences
        # between reads so that Cyrillic (2-byte) characters arriving across
        # two serial reads are decoded correctly.
        self._decoder = codecs.getincrementaldecoder("utf-8")("replace")

    def stop(self) -> None:
        self._running = False

    def run(self) -> None:
        while self._running:
            try:
                if not self._port.is_open:
                    self.msleep(50)
                    continue
                n = self._port.in_waiting
                raw = self._port.read(n if n > 0 else 1)
                if raw:
                    text = self._decoder.decode(raw, False)
                    if text:
                        self.data_received.emit(text)
            except serial.SerialException as exc:
                self.error_occurred.emit(str(exc))
                self._running = False
                break
            except (OSError, TypeError):
                self._running = False
                break
            except Exception as exc:
                self.error_occurred.emit(f"Unexpected error: {exc}")
                self._running = False
                break


# ---------------------------------------------------------------------------
# Public Serial Manager  (QObject so signals work cross-thread)
# ---------------------------------------------------------------------------

class SerialManager(QObject):
    # ---- Public signals (thread-safe, auto queued to receiver thread) ----
    data_received = pyqtSignal(str)
    error_occurred = pyqtSignal(str)
    connected = pyqtSignal()
    disconnected = pyqtSignal()

    def __init__(self, parent: QObject | None = None) -> None:
        super().__init__(parent)
        self._serial: Optional[serial.Serial] = None
        self._reader: Optional[_SerialReaderThread] = None
        self._mutex = QMutex()

    # ------------------------------------------------------------------
    # Port discovery
    # ------------------------------------------------------------------

    @staticmethod
    def list_ports() -> List[str]:
        ports = serial.tools.list_ports.comports()
        return [p.device for p in sorted(ports, key=lambda x: x.device)]

    @staticmethod
    def auto_detect_port() -> Optional[str]:
        """Return the most likely MicroPython/ESP device port.

        Preference order:
        1. Port whose description / manufacturer matches a known USB-serial chip
           (CH340, CP210x, CP2102, CP2104, CH9102, FTDI, …)
        2. Linux USB port by device name: /dev/ttyUSB* or /dev/ttyACM*
           (these are always USB adapters; /dev/ttyS* is a hardware UART like COM1)
        3. None — caller falls back to saved/first available port.
        """
        _KNOWN_CHIPS = (
            "ch340", "ch341", "ch9102",
            "cp210", "cp2102", "cp2104",
            "ftdi", "ft232",
            "usb serial", "usb-serial", "usb uart",
            "arduino",
        )
        # Port name prefixes that are always USB on Linux/macOS
        _USB_PREFIXES = ("/dev/ttyUSB", "/dev/ttyACM", "/dev/cu.usbserial", "/dev/cu.usbmodem")

        candidates = sorted(serial.tools.list_ports.comports(), key=lambda x: x.device)

        # Pass 1: chip description match (works on all platforms)
        for p in candidates:
            desc = (p.description or "").lower()
            mfg  = (p.manufacturer or "").lower()
            if any(kw in desc or kw in mfg for kw in _KNOWN_CHIPS):
                return p.device

        # Pass 2: Linux/macOS — prefer ttyUSB / ttyACM over ttyS*
        for p in candidates:
            if any(p.device.startswith(prefix) for prefix in _USB_PREFIXES):
                return p.device

        return None

    # ------------------------------------------------------------------
    # Connect / Disconnect
    # ------------------------------------------------------------------

    def connect_device(self, port: str, baud_rate: int = 115200) -> None:
        with QMutexLocker(self._mutex):
            if self._serial and self._serial.is_open:
                raise RuntimeError("Already connected. Disconnect first.")
            try:
                self._serial = serial.Serial(
                    port=port,
                    baudrate=baud_rate,
                    timeout=0.05,
                    write_timeout=2,
                )
            except (serial.SerialException, OSError, PermissionError) as exc:
                self._serial = None
                raise RuntimeError(str(exc)) from exc

            self._start_reader()

        self.connected.emit()

    def disconnect_device(self) -> None:
        with QMutexLocker(self._mutex):
            reader = self._reader
            self._reader = None
            ser = self._serial
            self._serial = None

        if reader is not None:
            reader.stop()
            if QThread.currentThread() is not reader:
                reader.wait(3000)

        if ser is not None and ser.is_open:
            try:
                ser.close()
            except Exception:
                pass

        self.disconnected.emit()

    def _start_reader(self) -> None:
        """Create and start a new reader thread (must hold mutex or be safe)."""
        self._reader = _SerialReaderThread(self._serial)
        self._reader.data_received.connect(self._relay_data)
        self._reader.error_occurred.connect(self._on_reader_error)
        self._reader.start()

    def _relay_data(self, text: str) -> None:
        """Re-emit data from reader thread through our own signal."""
        self.data_received.emit(text)

    def _on_reader_error(self, msg: str) -> None:
        self.error_occurred.emit(msg)
        QTimer.singleShot(0, self._safe_disconnect)

    def _safe_disconnect(self) -> None:
        self.disconnect_device()

    # ------------------------------------------------------------------
    # Data sending
    # ------------------------------------------------------------------

    def send(self, data: str) -> None:
        with QMutexLocker(self._mutex):
            if not self._serial or not self._serial.is_open:
                raise RuntimeError("Not connected to any device.")
            try:
                self._serial.write(data.encode("utf-8"))
                self._serial.flush()
            except serial.SerialException as exc:
                raise RuntimeError(str(exc)) from exc

    def send_ctrl_c(self) -> None:
        with QMutexLocker(self._mutex):
            if self._serial and self._serial.is_open:
                try:
                    self._serial.write(b"\x03")
                    self._serial.flush()
                except serial.SerialException:
                    pass

    def send_ctrl_d(self) -> None:
        with QMutexLocker(self._mutex):
            if self._serial and self._serial.is_open:
                try:
                    self._serial.write(b"\x04")
                    self._serial.flush()
                except serial.SerialException:
                    pass

    # ------------------------------------------------------------------
    # Reader pause / resume  (needed for DeviceFS raw-REPL access)
    # ------------------------------------------------------------------

    def pause_reader(self) -> None:
        with QMutexLocker(self._mutex):
            reader = self._reader
            self._reader = None
        if reader is not None:
            reader.stop()
            if QThread.currentThread() is not reader:
                reader.wait(3000)

    def resume_reader(self) -> None:
        with QMutexLocker(self._mutex):
            if self._serial and self._serial.is_open and self._reader is None:
                self._serial.reset_input_buffer()
                self._start_reader()

    @property
    def raw_serial(self) -> serial.Serial | None:
        return self._serial

    # ------------------------------------------------------------------
    # State
    # ------------------------------------------------------------------

    @property
    def is_connected(self) -> bool:
        return self._serial is not None and self._serial.is_open

    @property
    def current_port(self) -> str:
        if self._serial:
            return self._serial.port or ""
        return ""
