﻿from __future__ import annotations

import json
import os
import time
import traceback
from typing import Optional
from urllib.parse import quote_plus

from PyQt5.QtCore import Qt, QSize, QTimer, QUrl, pyqtSlot
from PyQt5.QtGui import (
    QDesktopServices, QIcon, QCloseEvent, QKeySequence, QResizeEvent
)
from PyQt5.QtWidgets import (
    QMainWindow, QMenuBar, QMenu, QStatusBar, QAction,
    QMessageBox, QInputDialog, QFileDialog, QLabel,
    QDialog, QVBoxLayout, QHBoxLayout, QPushButton, QComboBox,
    QToolBar, QWidget, QSizePolicy, QLineEdit, QTextBrowser
)

from ..core.config_manager import ConfigManager
from ..core.device_fs import DeviceFSWorker
from ..core.local_runner import LocalPythonRunner
from ..core.problems import CodeProblem, analyze_code, apply_safe_fixes
from ..core.serial_manager import SerialManager
from ..core.theme_manager import ThemeManager
from ..core.translations import get_language, set_language, tr
from ..core.update_checker import UpdateCheckThread
from ..paths import resource_path, user_log_path
from ..self_update import clear_update_status, launch_self_update, read_update_status
from .console import ConsoleDock
from .device_explorer import DeviceExplorerDock
from .editor import EditorWidget
from .file_explorer import FileExplorerDock
from .lib_manager import LibraryManagerDialog
from .problems import ProblemsDock


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_WEB_SEARCH_BASE_URL = "https://ya.ru/search/?clid=14916563&text="

def _find_icon() -> Optional[QIcon]:
    icon_path = resource_path("icon.png")
    return QIcon(icon_path) if icon_path else None


def _find_resource(*parts: str) -> str:
    return resource_path(*parts)


# ---------------------------------------------------------------------------
# About dialog
# ---------------------------------------------------------------------------

class AboutDialog(QDialog):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle(tr("about_title"))
        self.setMinimumWidth(380)
        layout = QVBoxLayout(self)
        layout.setSpacing(10)
        layout.setContentsMargins(16, 16, 16, 16)

        title = QLabel("<h2>BoardyPy</h2>")
        title.setAlignment(Qt.AlignLeft)

        desc = QLabel(tr("about_description"))
        desc.setAlignment(Qt.AlignLeft)
        desc.setWordWrap(True)

        creator = QLabel(tr("about_creator"))
        creator.setAlignment(Qt.AlignLeft)
        creator.setWordWrap(True)

        support = QLabel(
            '<a href="https://t.me/Timon2306" style="color:#0088cc;">'
            '💬 ' + tr("about_support") + '</a>'
        )
        support.setAlignment(Qt.AlignLeft)
        support.setOpenExternalLinks(True)
        support.setCursor(Qt.PointingHandCursor)

        btn_ok = QPushButton("OK")
        btn_ok.setFixedWidth(80)
        btn_ok.clicked.connect(self.accept)

        btn_patchnotes = QPushButton("📋 " + tr("about_patchnotes_btn"))
        btn_patchnotes.setFixedWidth(160)
        btn_patchnotes.clicked.connect(self._show_patchnotes)

        layout.addWidget(title)
        layout.addWidget(desc)
        layout.addSpacing(4)
        layout.addWidget(creator)
        layout.addWidget(support)
        layout.addSpacing(8)

        btn_row = QHBoxLayout()
        btn_row.addWidget(btn_patchnotes)
        btn_row.addStretch()
        btn_row.addWidget(btn_ok)
        layout.addLayout(btn_row)

    # ---- patch-notes popup ----
    def _show_patchnotes(self) -> None:
        dlg = QDialog(self)
        dlg.setWindowTitle(tr("about_patchnotes_title"))
        dlg.resize(460, 380)
        dlg.setMinimumSize(360, 260)
        vbox = QVBoxLayout(dlg)
        vbox.setContentsMargins(12, 12, 12, 12)
        vbox.setSpacing(8)

        notes = QTextBrowser()
        notes.setOpenExternalLinks(True)
        notes.setHtml(tr("about_patchnotes"))
        notes.setFrameShape(QTextBrowser.NoFrame)
        notes.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        notes.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        vbox.addWidget(notes)

        btn = QPushButton("OK")
        btn.setFixedWidth(80)
        btn.clicked.connect(dlg.accept)
        vbox.addWidget(btn, alignment=Qt.AlignRight)
        dlg.exec_()


# ---------------------------------------------------------------------------
# Port Dialog
# ---------------------------------------------------------------------------

class PortSelectDialog(QDialog):
    def __init__(self, ports: list[str], current: str, parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle(tr("port_dialog_title"))
        self.setMinimumWidth(300)
        layout = QVBoxLayout(self)
        layout.setSpacing(10)

        row = QHBoxLayout()
        label = QLabel(tr("port_label"))
        self._combo = QComboBox()
        self._combo.addItems(ports if ports else [tr("port_no_ports")])
        if current in ports:
            self._combo.setCurrentText(current)

        row.addWidget(label)
        row.addWidget(self._combo)

        btn_row = QHBoxLayout()
        btn_ok = QPushButton(tr("port_btn_connect"))
        btn_cancel = QPushButton(tr("port_btn_cancel"))
        btn_ok.clicked.connect(self.accept)
        btn_cancel.clicked.connect(self.reject)
        btn_row.addWidget(btn_ok)
        btn_row.addWidget(btn_cancel)

        layout.addLayout(row)
        layout.addLayout(btn_row)

    @property
    def selected_port(self) -> str:
        return self._combo.currentText()


# ---------------------------------------------------------------------------
# Main Window
# ---------------------------------------------------------------------------

class MainWindow(QMainWindow):
    def __init__(
        self,
        config: ConfigManager,
        theme: ThemeManager,
        serial: SerialManager,
    ) -> None:
        super().__init__()
        self._config = config
        self._theme = theme
        self._serial = serial
        self._selected_port: str = config.get("last_port", "")
        self._baud_rate: int = config.get("baud_rate", 115200)
        self._local_runner: LocalPythonRunner | None = None
        self._serial_buf: str = ""
        self._in_error_block: bool = False
        self._last_error_text: str = ""
        self._toolbar_compact = False
        self._run_transition_active = False
        self._device_run_scheduled = False
        self._session_dirty = False
        self._update_checker: UpdateCheckThread | None = None
        self._recent_update_failure_version: str = ""
        self._search_line: QLineEdit | None = None
        self._self_update_started = False
        self._current_problems: list[CodeProblem] = []
        self._problem_timer = QTimer(self)
        self._problem_timer.setSingleShot(True)
        self._problem_timer.setInterval(650)
        self._problem_timer.timeout.connect(self._check_current_problems)
        self._session_timer = QTimer(self)
        self._session_timer.setSingleShot(True)
        self._session_timer.setInterval(1200)
        self._session_timer.timeout.connect(self._flush_session_snapshot)

        self._device_worker = DeviceFSWorker()
        self._device_worker.start()

        self.setWindowTitle(tr("app_title"))
        self.setMinimumSize(600, 400)
        icon = _find_icon()
        if icon:
            self.setWindowIcon(icon)

        self._build_central_widget()
        self._build_docks()
        self._build_menu()
        self._build_toolbar()
        self._build_status_bar()
        self._connect_signals()

        self._theme.apply(config.get("theme", "System"))
        self._editor.apply_theme(self._theme.is_dark())
        self._console_dock.apply_theme(self._theme.is_dark())
        self._explorer_dock.apply_theme(self._theme.is_dark())
        self._device_explorer_dock.apply_theme(self._theme.is_dark())
        self._problems_dock.apply_theme(self._theme.is_dark())
        self._update_toolbar_mode(force=True)

        self._auto_save_timer = QTimer(self)
        self._auto_save_timer.setInterval(30_000)
        self._auto_save_timer.timeout.connect(self._auto_save)
        if config.get("auto_save", False):
            self._auto_save_timer.start()

        geom = config.get("window_geometry")
        if geom:
            try:
                from PyQt5.QtCore import QByteArray
                self.restoreGeometry(QByteArray.fromHex(geom.encode()))
            except Exception:
                self._apply_default_geometry()
        else:
            self._apply_default_geometry()
        self._restore_session_snapshot()
        QTimer.singleShot(350, self._check_current_problems)
        QTimer.singleShot(120, self._show_self_update_result)
        self._update_toolbar_mode(force=True)
        QTimer.singleShot(250, self._attempt_auto_connect)
        QTimer.singleShot(1600, self._start_update_check)

    def _apply_default_geometry(self) -> None:
        from PyQt5.QtWidgets import QApplication
        from PyQt5.QtCore import QRect
        screen = QApplication.primaryScreen()
        if screen:
            rect = screen.availableGeometry()
            w = int(rect.width() * 0.85)
            h = int(rect.height() * 0.85)
            x = (rect.width() - w) // 2
            y = (rect.height() - h) // 2
            self.setGeometry(x, y, w, h)
        else:
            self.resize(1280, 800)

    # ------------------------------------------------------------------
    # Build UI
    # ------------------------------------------------------------------

    def _build_central_widget(self) -> None:
        self._editor = EditorWidget(self._config, self._theme)
        self.setCentralWidget(self._editor)

    def _build_docks(self) -> None:
        # Console — bottom
        self._console_dock = ConsoleDock(self)
        self.addDockWidget(Qt.BottomDockWidgetArea, self._console_dock)
        self._console_dock.setMinimumHeight(80)

        # Problems — bottom tab next to console
        self._problems_dock = ProblemsDock(self)
        self.addDockWidget(Qt.BottomDockWidgetArea, self._problems_dock)
        self.tabifyDockWidget(self._console_dock, self._problems_dock)
        self._console_dock.raise_()

        # File explorer — left top
        self._explorer_dock = FileExplorerDock(self)
        self.addDockWidget(Qt.LeftDockWidgetArea, self._explorer_dock)
        self._explorer_dock.setMinimumWidth(120)

        # Device explorer — left bottom (split vertically)
        self._device_explorer_dock = DeviceExplorerDock(self)
        self._device_explorer_dock.set_worker(self._device_worker)
        self.addDockWidget(Qt.LeftDockWidgetArea, self._device_explorer_dock)
        self._device_explorer_dock.setMinimumWidth(120)
        self.splitDockWidget(self._explorer_dock, self._device_explorer_dock, Qt.Vertical)

        last_dir = self._config.get("last_directory", "")
        if last_dir and os.path.isdir(last_dir):
            self._explorer_dock.set_root(last_dir)

    def _build_menu(self) -> None:
        mb = self.menuBar()

        # ---------------- File ----------------
        file_menu = mb.addMenu(tr("menu_file"))

        act_new = QAction(tr("action_new"), self)
        act_new.setShortcut(QKeySequence.New)
        act_new.triggered.connect(self._editor.new_tab)

        act_open = QAction(tr("action_open"), self)
        act_open.setShortcut(QKeySequence.Open)
        act_open.triggered.connect(self._open_file)

        act_save = QAction(tr("action_save"), self)
        act_save.setShortcut(QKeySequence.Save)
        act_save.triggered.connect(self._editor.save_current)

        act_save_as = QAction(tr("action_save_as"), self)
        act_save_as.setShortcut(QKeySequence("Ctrl+Shift+S"))
        act_save_as.triggered.connect(self._editor.save_current_as)

        act_close_tab = QAction(tr("action_close_tab"), self)
        act_close_tab.setShortcut(QKeySequence("Ctrl+W"))
        act_close_tab.triggered.connect(
            lambda: self._editor.close_tab(self._editor.currentIndex())
        )

        act_exit = QAction(tr("action_exit"), self)
        act_exit.setShortcut(QKeySequence("Alt+F4"))
        act_exit.triggered.connect(self.close)

        file_menu.addAction(act_new)
        file_menu.addAction(act_open)
        file_menu.addSeparator()
        file_menu.addAction(act_save)
        file_menu.addAction(act_save_as)
        file_menu.addSeparator()
        file_menu.addAction(act_close_tab)
        file_menu.addSeparator()
        file_menu.addAction(act_exit)

        # ---------------- Edit ----------------
        edit_menu = mb.addMenu(tr("menu_edit"))

        act_undo = QAction(tr("action_undo"), self)
        act_undo.setShortcut(QKeySequence.Undo)
        act_undo.triggered.connect(
            lambda: self._editor.current_editor() and self._editor.current_editor().undo()
        )

        act_redo = QAction(tr("action_redo"), self)
        act_redo.setShortcut(QKeySequence.Redo)
        act_redo.triggered.connect(
            lambda: self._editor.current_editor() and self._editor.current_editor().redo()
        )

        act_cut = QAction(tr("action_cut"), self)
        act_cut.setShortcut(QKeySequence.Cut)
        act_cut.triggered.connect(
            lambda: self._editor.current_editor() and self._editor.current_editor().cut()
        )

        act_copy = QAction(tr("action_copy"), self)
        act_copy.setShortcut(QKeySequence.Copy)
        act_copy.triggered.connect(
            lambda: self._editor.current_editor() and self._editor.current_editor().copy()
        )

        act_paste = QAction(tr("action_paste"), self)
        act_paste.setShortcut(QKeySequence.Paste)
        act_paste.triggered.connect(
            lambda: self._editor.current_editor() and self._editor.current_editor().paste()
        )

        act_select_all = QAction(tr("action_select_all"), self)
        act_select_all.setShortcut(QKeySequence.SelectAll)
        act_select_all.triggered.connect(
            lambda: self._editor.current_editor() and self._editor.current_editor().selectAll()
        )

        act_find = QAction(tr("action_find"), self)
        act_find.setShortcut(QKeySequence.Find)
        act_find.triggered.connect(self._editor.show_find_bar)

        edit_menu.addAction(act_undo)
        edit_menu.addAction(act_redo)
        edit_menu.addSeparator()
        edit_menu.addAction(act_cut)
        edit_menu.addAction(act_copy)
        edit_menu.addAction(act_paste)
        edit_menu.addSeparator()
        edit_menu.addAction(act_select_all)
        edit_menu.addSeparator()
        edit_menu.addAction(act_find)

        # ---------------- View ----------------
        view_menu = mb.addMenu(tr("menu_view"))

        act_toggle_console = QAction(tr("action_toggle_console"), self)
        act_toggle_console.setShortcut(QKeySequence("Ctrl+`"))
        act_toggle_console.triggered.connect(self._toggle_console)

        act_toggle_explorer = QAction(tr("action_toggle_explorer"), self)
        act_toggle_explorer.setShortcut(QKeySequence("Ctrl+Shift+E"))
        act_toggle_explorer.triggered.connect(self._toggle_explorer)

        act_zoom_in = QAction(tr("action_zoom_in"), self)
        act_zoom_in.setShortcut(QKeySequence("Ctrl+="))
        act_zoom_in.triggered.connect(self._editor.zoom_in)

        act_zoom_out = QAction(tr("action_zoom_out"), self)
        act_zoom_out.setShortcut(QKeySequence("Ctrl+-"))
        act_zoom_out.triggered.connect(self._editor.zoom_out)

        act_reset_zoom = QAction(tr("action_reset_zoom"), self)
        act_reset_zoom.setShortcut(QKeySequence("Ctrl+0"))
        act_reset_zoom.triggered.connect(self._editor.reset_zoom)

        view_menu.addAction(act_toggle_console)
        view_menu.addAction(act_toggle_explorer)

        act_toggle_devexp = QAction(tr("action_toggle_devexp"), self)
        act_toggle_devexp.triggered.connect(self._toggle_device_explorer)
        view_menu.addAction(act_toggle_devexp)

        act_toggle_problems = QAction(tr("action_toggle_problems"), self)
        act_toggle_problems.setShortcut(QKeySequence("Ctrl+Shift+M"))
        act_toggle_problems.triggered.connect(self._toggle_problems)
        view_menu.addAction(act_toggle_problems)

        view_menu.addSeparator()
        view_menu.addAction(act_zoom_in)
        view_menu.addAction(act_zoom_out)
        view_menu.addAction(act_reset_zoom)

        # ---------------- Device ----------------
        device_menu = mb.addMenu(tr("menu_device"))

        act_select_port = QAction(tr("action_select_port"), self)
        act_select_port.triggered.connect(self._select_port)

        act_refresh_ports = QAction(tr("action_refresh_ports"), self)
        act_refresh_ports.triggered.connect(self._refresh_ports)

        act_connect = QAction(tr("action_connect"), self)
        act_connect.setShortcut(QKeySequence("Ctrl+Shift+C"))
        act_connect.triggered.connect(self._connect_device)

        act_disconnect = QAction(tr("action_disconnect"), self)
        act_disconnect.setShortcut(QKeySequence("Ctrl+Shift+D"))
        act_disconnect.triggered.connect(self._disconnect_device)

        device_menu.addAction(act_select_port)
        device_menu.addAction(act_refresh_ports)
        device_menu.addSeparator()
        device_menu.addAction(act_connect)
        device_menu.addAction(act_disconnect)

        # ---------------- Run ----------------
        run_menu = mb.addMenu(tr("menu_run"))

        act_run = QAction(tr("action_run_script"), self)
        act_run.setShortcut(QKeySequence("F5"))
        act_run.triggered.connect(self._run_smart)

        act_stop = QAction(tr("action_stop_execution"), self)
        act_stop.setShortcut(QKeySequence("F6"))
        act_stop.triggered.connect(self._stop_execution)

        act_restart = QAction(tr("action_restart"), self)
        act_restart.setShortcut(QKeySequence("Ctrl+Shift+F5"))
        act_restart.triggered.connect(self._restart_script)

        run_menu.addAction(act_run)
        run_menu.addAction(act_stop)
        run_menu.addSeparator()
        run_menu.addAction(act_restart)

        # ---------------- Settings ----------------
        settings_menu = mb.addMenu(tr("menu_settings"))

        theme_menu = settings_menu.addMenu(tr("menu_theme"))
        for t_name in ThemeManager.THEMES:
            act_theme = QAction(t_name, self)
            act_theme.triggered.connect(
                lambda checked, name=t_name: self._change_theme(name)
            )
            theme_menu.addAction(act_theme)

        act_font_size = QAction(tr("action_font_size"), self)
        act_font_size.triggered.connect(self._change_font_size)

        act_auto_save = QAction(tr("action_auto_save"), self)
        act_auto_save.setCheckable(True)
        act_auto_save.setChecked(self._config.get("auto_save", False))
        act_auto_save.toggled.connect(self._toggle_auto_save)

        # Language submenu
        lang_menu = settings_menu.addMenu(tr("menu_language"))
        act_lang_ru = QAction(tr("lang_russian"), self)
        act_lang_ru.triggered.connect(lambda: self._change_language("ru"))
        act_lang_en = QAction(tr("lang_english"), self)
        act_lang_en.triggered.connect(lambda: self._change_language("en"))
        lang_menu.addAction(act_lang_ru)
        lang_menu.addAction(act_lang_en)

        settings_menu.addAction(act_font_size)
        settings_menu.addAction(act_auto_save)

        act_syntax = QAction(tr("action_syntax_highlight"), self)
        act_syntax.setCheckable(True)
        act_syntax.setChecked(self._config.get("syntax_highlight", True))
        act_syntax.toggled.connect(self._toggle_syntax_highlight)
        settings_menu.addAction(act_syntax)

        act_error_check = QAction(tr("action_error_checking"), self)
        act_error_check.setCheckable(True)
        act_error_check.setChecked(self._config.get("error_checking", True))
        act_error_check.toggled.connect(self._toggle_error_checking)
        settings_menu.addAction(act_error_check)

        # ---------------- Tools ----------------
        tools_menu = mb.addMenu(tr("menu_tools"))
        act_web_search = QAction(tr("action_web_search"), self)
        act_web_search.setShortcut(QKeySequence("Ctrl+K"))
        act_web_search.triggered.connect(self._focus_web_search)
        act_libraries = QAction(tr("tb_libraries"), self)
        act_libraries.setShortcut(QKeySequence("Ctrl+Shift+L"))
        act_libraries.triggered.connect(self._show_lib_manager)
        act_fix_problems = QAction(tr("action_fix_safe_problems"), self)
        act_fix_problems.triggered.connect(self._fix_safe_problems)
        tools_menu.addAction(act_web_search)
        tools_menu.addSeparator()
        tools_menu.addAction(act_fix_problems)
        tools_menu.addSeparator()
        tools_menu.addAction(act_libraries)

        # ---------------- Help ----------------
        help_menu = mb.addMenu(tr("menu_help"))
        act_about = QAction(tr("action_about"), self)
        act_about.triggered.connect(self._show_about)
        help_menu.addAction(act_about)

    def _build_status_bar(self) -> None:
        sb = self.statusBar()
        self._status_label = QLabel(tr("ready"))
        self._port_label = QLabel(tr("no_device_connected"))
        sb.addWidget(self._status_label, 1)
        sb.addPermanentWidget(self._port_label)

    # ------------------------------------------------------------------
    # Toolbar
    # ------------------------------------------------------------------

    def _build_toolbar(self) -> None:
        tb = QToolBar("MainToolbar")
        tb.setObjectName("MainToolbar")
        tb.setMovable(False)
        tb.setFloatable(False)
        tb.setContentsMargins(4, 3, 4, 3)
        self.addToolBar(tb)
        self._toolbar = tb
        self._tb_buttons: list[tuple[QPushButton, str]] = []
        self._rebuild_toolbar_buttons()

    def _rebuild_toolbar_buttons(self) -> None:
        tb = self._toolbar
        search_text = self._search_line.text() if self._search_line is not None else ""
        for act in list(tb.actions()):
            tb.removeAction(act)
        self._tb_buttons.clear()
        self._search_line = None

        dark = self._theme.is_dark()

        tb.setStyleSheet(
            "QToolBar { spacing: 2px; padding: 2px 4px; }"
            "QToolBar::separator { width: 1px; background: "
            + ("#555;" if dark else "#b0b0b4;") +
            " margin: 4px 6px; }"
        )

        def _tb_btn(
            icon: str,
            tooltip: str,
            callback,
            accent: str = "",
            text: str = "",
            compact_text: str = "",
            icon_file: str = "",
            icon_file_dark: str = "",
            icon_px: int = 18,
        ) -> QPushButton:
            if self._toolbar_compact:
                label = compact_text or icon or text
            elif icon and text:
                label = f"{icon} {text}"
            else:
                label = text or icon
            if icon_file:
                label = "" if self._toolbar_compact else text
            btn = QPushButton(label)
            btn.setToolTip(tooltip)
            btn.setCursor(Qt.PointingHandCursor)
            btn.setFixedHeight(30)
            btn.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Fixed)
            btn.setMinimumWidth(40 if self._toolbar_compact and icon_file else 34 if self._toolbar_compact else 0)
            btn.setStyleSheet(self._tb_btn_style(accent, dark))
            if icon_file:
                icon_name = icon_file_dark if dark and icon_file_dark else icon_file
                icon_path = _find_resource("toolbar_icons", icon_name)
                if icon_path:
                    btn.setIcon(QIcon(icon_path))
                    btn.setIconSize(QSize(icon_px, icon_px))
            btn.clicked.connect(callback)
            self._tb_buttons.append((btn, accent))
            return btn

        # ---- File group ----
        tb.addWidget(_tb_btn("", tr("tb_new"), self._editor.new_tab,
                             text=tr("tb_new"), icon_file="new_file_light.png", icon_px=18))
        tb.addWidget(_tb_btn("", tr("tb_open"), self._open_file,
                             text=tr("tb_open"), icon_file="open_file_light.png", icon_px=18))
        tb.addWidget(_tb_btn("", tr("tb_save"), self._editor.save_current,
                             text=tr("tb_save"), icon_file="save_file_light.png", icon_px=18))

        tb.addSeparator()

        # ---- Run group ----
        tb.addWidget(_tb_btn("", tr("tb_run"), self._run_smart,
                             accent="green", text=tr("tb_run"), icon_file="play.png", icon_px=20))
        tb.addWidget(_tb_btn("", tr("tb_restart"), self._restart_script,
                             accent="orange", text=tr("tb_restart"), icon_file="restart.png", icon_px=20))
        tb.addWidget(_tb_btn("", tr("tb_stop"), self._stop_execution,
                             accent="red", text=tr("tb_stop"), icon_file="stop.png", icon_px=20))

        tb.addSeparator()

        # ---- Device group ----
        tb.addWidget(_tb_btn("", tr("tb_connect"), self._connect_device,
                             accent="cyan", text=tr("tb_connect"),
                             icon_file="connect_dark.png", icon_file_dark="connect_dark.png", icon_px=20))
        tb.addWidget(_tb_btn("", tr("tb_disconnect"), self._disconnect_device,
                             accent="red", text=tr("tb_disconnect"),
                             icon_file="disconnect_dark.png", icon_file_dark="disconnect_dark.png", icon_px=20))

        tb.addSeparator()

        spacer = QWidget()
        spacer.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        tb.addWidget(spacer)

        search_line = QLineEdit()
        search_line.setPlaceholderText(tr("web_search_placeholder"))
        search_line.setToolTip(tr("web_search_tooltip"))
        search_line.setClearButtonEnabled(True)
        search_line.setFixedHeight(30)
        search_line.setMinimumWidth(170 if self._toolbar_compact else 230)
        search_line.setMaximumWidth(220 if self._toolbar_compact else 320)
        search_line.setStyleSheet(self._toolbar_search_style(dark))
        search_line.setText(search_text)
        search_line.returnPressed.connect(self._open_web_search)
        tb.addWidget(search_line)
        self._search_line = search_line

        search_button = QPushButton(tr("web_search_button"))
        search_button.setToolTip(tr("web_search_tooltip"))
        search_button.setCursor(Qt.PointingHandCursor)
        search_button.setFixedHeight(30)
        search_button.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
        search_button.setStyleSheet(self._tb_btn_style("cyan", dark))
        search_button.clicked.connect(self._open_web_search)
        tb.addWidget(search_button)

    @staticmethod
    def _tb_btn_style(accent: str, dark: bool) -> str:
        """Return stylesheet for a toolbar button based on accent and theme."""
        styles = {
            "green": {
                True:  ("#4ade80", "#4ade80", "#1a1a1a", "#22c55e"),
                False: ("#16a34a", "#16a34a", "#ffffff", "#15803d"),
            },
            "red": {
                True:  ("#f87171", "#f87171", "#1a1a1a", "#ef4444"),
                False: ("#dc2626", "#dc2626", "#ffffff", "#b91c1c"),
            },
            "orange": {
                True:  ("#fb923c", "#fb923c", "#1a1a1a", "#f97316"),
                False: ("#ea580c", "#ea580c", "#ffffff", "#c2410c"),
            },
            "cyan": {
                True:  ("#22d3ee", "#22d3ee", "#1a1a1a", "#06b6d4"),
                False: ("#0891b2", "#0891b2", "#ffffff", "#0e7490"),
            },
        }
        if accent in styles:
            fg, border, hover_fg, pressed_bg = styles[accent][dark]
            return (
                f"QPushButton {{ background: transparent; color: {fg}; "
                f"font-size: 13px; font-weight: bold; border: 1px solid {border}; "
                f"border-radius: 4px; padding: 2px 10px; }}"
                f"QPushButton:hover {{ background: {border}; color: {hover_fg}; }}"
                f"QPushButton:pressed {{ background: {pressed_bg}; color: {hover_fg}; }}"
            )
        # Neutral (file buttons)
        if dark:
            return (
                "QPushButton { background: transparent; color: #d4d4d4; "
                "font-size: 13px; border: 1px solid #555; "
                "border-radius: 4px; padding: 2px 10px; }"
                "QPushButton:hover { background: #444; color: #fff; }"
                "QPushButton:pressed { background: #333; }"
            )
        else:
            return (
                "QPushButton { background: transparent; color: #3c3c3c; "
                "font-size: 13px; border: 1px solid #a0a0a4; "
                "border-radius: 4px; padding: 2px 10px; }"
                "QPushButton:hover { background: #c0c0c4; color: #1e1e1e; }"
                "QPushButton:pressed { background: #a8a8ac; }"
            )

    @staticmethod
    def _toolbar_search_style(dark: bool) -> str:
        if dark:
            return (
                "QLineEdit { background: #1f1f1f; color: #f2f2f2; "
                "border: 1px solid #555; border-radius: 4px; padding: 4px 10px; "
                "selection-background-color: #0e7490; }"
                "QLineEdit:focus { border: 1px solid #22d3ee; }"
            )
        return (
            "QLineEdit { background: #ffffff; color: #222222; "
            "border: 1px solid #a0a0a4; border-radius: 4px; padding: 4px 10px; "
            "selection-background-color: #9bdcf5; }"
            "QLineEdit:focus { border: 1px solid #0891b2; }"
        )

    def _update_toolbar_mode(self, force: bool = False) -> None:
        compact = self.width() < 940
        if force or compact != self._toolbar_compact:
            self._toolbar_compact = compact
            self._rebuild_toolbar_buttons()

    def _focus_web_search(self) -> None:
        if self._search_line is None:
            return
        self._search_line.setFocus(Qt.ShortcutFocusReason)
        self._search_line.selectAll()

    def _open_web_search(self) -> None:
        if self._search_line is None:
            return
        query = self._search_line.text().strip()
        if not query:
            self._status_label.setText(tr("web_search_empty"))
            self._focus_web_search()
            return

        url = QUrl(_WEB_SEARCH_BASE_URL + quote_plus(query))
        if QDesktopServices.openUrl(url):
            self._status_label.setText(tr("web_search_opened"))
            self._search_line.selectAll()
        else:
            self._status_label.setText(tr("web_search_failed"))
            self._console_dock.append_error(tr("web_search_failed"))

    def _open_web_search_from_editor(self, text: str) -> None:
        if self._search_line is None:
            return
        query = " ".join(text.split())
        self._search_line.setText(query)
        self._open_web_search()

    # ------------------------------------------------------------------
    # Signal connections
    # ------------------------------------------------------------------

    def _connect_signals(self) -> None:
        # File explorer → open in editor
        self._explorer_dock.file_double_clicked.connect(self._editor.open_file)
        self._explorer_dock.file_double_clicked.connect(self._update_last_dir)
        # File explorer → upload to device
        self._explorer_dock.upload_to_device_requested.connect(self._upload_local_to_device)

        # Console → send command to device
        self._console_dock.command_submitted.connect(self._send_command)

        # Problems → fix and navigate
        self._problems_dock.fix_safe_requested.connect(self._fix_safe_problems)
        self._problems_dock.problem_activated.connect(self._editor.go_to_line)

        # Device explorer → open file in editor
        self._device_explorer_dock.file_open_requested.connect(self._open_device_file_in_editor)

        # Editor → save device file back
        self._editor.device_file_save_requested.connect(self._save_device_file)
        self._editor.state_changed.connect(self._schedule_session_snapshot)
        self._editor.state_changed.connect(self._schedule_problem_check)
        self._editor.web_search_requested.connect(self._open_web_search_from_editor)

        # Serial manager signals → console output (queued cross-thread)
        self._serial.data_received.connect(self._process_serial_data)
        self._serial.error_occurred.connect(self._process_serial_error)
        self._serial.connected.connect(self._handle_connected)
        self._serial.disconnected.connect(self._handle_disconnected)

    # ------------------------------------------------------------------
    # File actions
    # ------------------------------------------------------------------

    def _open_file(self) -> None:
        start_dir = self._config.get("last_directory", "")
        path, _ = QFileDialog.getOpenFileName(
            self, tr("editor_open_file"), start_dir,
            tr("editor_py_filter")
        )
        if path:
            self._config.set("last_directory", os.path.dirname(path))
            self._editor.open_file(path)

    def _update_last_dir(self, path: str) -> None:
        self._config.set("last_directory", os.path.dirname(path))

    # ------------------------------------------------------------------
    # Problems / safe fixes
    # ------------------------------------------------------------------

    def _schedule_problem_check(self) -> None:
        if not self._config.get("error_checking", True):
            return
        if hasattr(self, "_problem_timer"):
            self._problem_timer.start()

    def _check_current_problems(self, show_panel: bool = False) -> int:
        if not self._config.get("error_checking", True):
            self._clear_problems()
            return 0
        code = self._editor.current_content()
        problems = analyze_code(code)
        self._current_problems = problems
        self._problems_dock.set_problems(problems)
        self._update_problem_status(problems)
        self._editor.set_problem_lines(
            [problem.line for problem in problems if problem.severity == "error"]
        )
        if show_panel:
            self._show_problems_panel()
        return sum(1 for problem in problems if problem.severity == "error")

    def _clear_problems(self) -> None:
        self._current_problems = []
        self._problems_dock.set_problems([])
        self._editor.set_problem_lines([])

    def _update_problem_status(self, problems: list[CodeProblem]) -> None:
        errors = sum(1 for problem in problems if problem.severity == "error")
        warnings = sum(1 for problem in problems if problem.severity == "warning")
        self._problems_dock.set_problem_counts(errors, warnings)

    def _fix_safe_problems(self) -> None:
        code = self._editor.current_content()
        fixed, changes = apply_safe_fixes(code)
        if not changes or fixed == code:
            self._check_current_problems(show_panel=True)
            self._status_label.setText(tr("problems_fix_none"))
            return
        self._editor.replace_current_content(fixed)
        self._check_current_problems(show_panel=True)
        self._status_label.setText(
            tr("problems_fix_done", fixes=", ".join(changes))
        )

    # ------------------------------------------------------------------
    # View actions
    # ------------------------------------------------------------------

    def _toggle_console(self) -> None:
        self._console_dock.setVisible(not self._console_dock.isVisible())

    def _toggle_explorer(self) -> None:
        self._explorer_dock.setVisible(not self._explorer_dock.isVisible())

    def _toggle_device_explorer(self) -> None:
        self._device_explorer_dock.setVisible(not self._device_explorer_dock.isVisible())
        if self._device_explorer_dock.isVisible():
            self._device_explorer_dock.raise_()

    def _toggle_problems(self) -> None:
        self._problems_dock.setVisible(not self._problems_dock.isVisible())
        if self._problems_dock.isVisible():
            self._problems_dock.raise_()

    def _show_problems_panel(self) -> None:
        self._problems_dock.setVisible(True)
        self._problems_dock.raise_()

    # ------------------------------------------------------------------
    # Device actions
    # ------------------------------------------------------------------

    def _select_port(self) -> None:
        ports = SerialManager.list_ports()
        dlg = PortSelectDialog(ports, self._selected_port, self)
        if dlg.exec_() == QDialog.Accepted:
            self._selected_port = dlg.selected_port
            self._config.set("last_port", self._selected_port)
            self._port_label.setText(tr("status_port", port=self._selected_port))
            self._console_dock.append_info(tr("status_selected_port", port=self._selected_port))

    def _refresh_ports(self) -> None:
        ports = SerialManager.list_ports()
        if ports:
            msg = tr("status_available_ports", ports=", ".join(ports))
        else:
            msg = tr("status_no_ports")
        self._console_dock.append_info(msg)
        self._status_label.setText(msg)

    def _connect_device(self, silent: bool = False) -> bool:
        if self._serial.is_connected:
            self._console_dock.append_info(tr("status_already_connected"))
            return True

        ports = SerialManager.list_ports()
        if not ports:
            if not silent:
                QMessageBox.warning(self, tr("err_no_ports_title"), tr("err_no_ports_msg"))
            return False

        # Always prefer a known USB-serial device (CH340, CP210x, FTDI, …).
        # This runs every time so COM1 / stale saved ports are never chosen over
        # a real controller. Falls back to saved port (if valid) or first port.
        candidate = SerialManager.auto_detect_port()
        if candidate and candidate in ports:
            self._selected_port = candidate
        elif self._selected_port not in ports:
            self._selected_port = ports[0]
        self._config.set("last_port", self._selected_port)
        self._port_label.setText(tr("status_port", port=self._selected_port))
        self._console_dock.append_info(tr("status_selected_port", port=self._selected_port))

        try:
            self._serial.connect_device(self._selected_port, self._baud_rate)
        except (RuntimeError, Exception) as exc:
            if not silent:
                QMessageBox.critical(self, tr("err_connection_title"), str(exc))
                self._console_dock.append_error(tr("err_connection_failed", err=exc))
            return False
        return True

    def _attempt_auto_connect(self) -> None:
        if self._serial.is_connected:
            return
        connected = self._connect_device(silent=True)
        if connected:
            self._console_dock.append_info(tr("update_auto_connected"))

    def _start_update_check(self) -> None:
        if not self._config.get("check_updates_on_start", True):
            return
        feed_url = str(self._config.get("update_feed_url", "")).strip()
        if not feed_url:
            return
        if self._update_checker and self._update_checker.isRunning():
            return
        from PyQt5.QtWidgets import QApplication
        current_version = QApplication.instance().applicationVersion() or "0.0.0"
        checker = UpdateCheckThread(current_version, feed_url, self)
        checker.update_available.connect(self._handle_update_available)
        checker.finished.connect(self._finish_update_check)
        self._update_checker = checker
        checker.start()

    def _finish_update_check(self) -> None:
        checker = self.sender()
        if checker is self._update_checker:
            self._update_checker = None
        if checker is not None:
            checker.deleteLater()

    def _handle_update_available(self, payload: dict) -> None:
        version = str(payload.get("version", "")).strip()
        if not version:
            return
        if version == self._recent_update_failure_version:
            return
        ignored_version = str(self._config.get("ignored_update_version", "")).strip()
        if ignored_version == version:
            return

        lang = get_language()
        notes = payload.get(f"notes_{lang}") or payload.get("notes") or ""
        if isinstance(notes, list):
            notes_text = "\n".join(f"• {item}" for item in notes if str(item).strip())
        else:
            notes_text = str(notes).strip()

        msg = QMessageBox(self)
        msg.setIcon(QMessageBox.Information)
        msg.setWindowTitle(tr("update_available_title"))
        msg.setText(tr("update_available_text", version=version))
        info_blocks: list[str] = []
        if notes_text:
            info_blocks.append(tr("update_available_notes", notes=notes_text))
        info_blocks.append(tr("update_auto_hint"))
        msg.setInformativeText("\n\n".join(part for part in info_blocks if part.strip()))

        btn_update = msg.addButton(tr("update_download"), QMessageBox.AcceptRole)
        btn_later = msg.addButton(tr("update_later"), QMessageBox.RejectRole)
        btn_ignore = msg.addButton(tr("update_ignore"), QMessageBox.DestructiveRole)
        msg.setDefaultButton(btn_update)

        msg.exec_()
        clicked = msg.clickedButton()
        if clicked is btn_update:
            self._start_self_update(version)
        elif clicked is btn_ignore:
            self._config.set("ignored_update_version", version)

    def _start_self_update(self, version: str) -> None:
        if self._self_update_started:
            return
        try:
            launch_self_update(target_version=version)
        except Exception as exc:
            QMessageBox.warning(
                self,
                tr("update_failed_title"),
                tr("update_start_failed", err=exc),
            )
            return

        self._self_update_started = True
        self._console_dock.append_info(tr("update_installing"))
        self._status_label.setText(tr("update_installing_short"))
        from PyQt5.QtWidgets import QApplication
        app = QApplication.instance()
        if app is not None:
            app.quit()

    def _show_self_update_result(self) -> None:
        payload = read_update_status()
        if not payload:
            return
        clear_update_status()
        if payload.get("ok"):
            return

        self._recent_update_failure_version = str(payload.get("target_version", "")).strip()
        stdout_text = str(payload.get("stdout", "")).strip()
        stderr_text = str(payload.get("stderr", "")).strip()
        details = stderr_text or stdout_text

        msg = QMessageBox(self)
        msg.setIcon(QMessageBox.Warning)
        msg.setWindowTitle(tr("update_failed_title"))
        msg.setText(tr("update_failed_text"))
        msg.setInformativeText(tr("update_failed_hint"))
        if details:
            msg.setDetailedText(details)
        msg.exec_()

    def _disconnect_device(self) -> None:
        if not self._serial.is_connected:
            self._console_dock.append_info(tr("status_not_connected"))
            return
        self._serial.disconnect_device()

    # ------------------------------------------------------------------
    # Run actions
    # ------------------------------------------------------------------

    def _run_smart(self) -> None:
        if self._run_transition_active or self._device_run_scheduled:
            self._console_dock.append_info("Run is already in progress.")
            return
        error_count = self._check_current_problems(show_panel=False)
        if error_count:
            self._show_problems_panel()
            self._status_label.setText(tr("problems_run_blocked", count=error_count))
            return
        try:
            if self._serial.is_connected:
                self._run_on_device()
            else:
                self._run_local()
        except Exception as exc:
            self._log_runtime_error("run_smart", exc)
            self._console_dock.append_error(tr("err_run", err=exc))
            self._status_label.setText(tr("ready"))

    def _run_on_device(self) -> None:
        code = self._editor.current_content()
        if not code.strip():
            self._console_dock.append_info(tr("run_nothing"))
            return
        try:
            # Ctrl+C — прерываем текущий скрипт (если что-то работает)
            self._run_transition_active = True
            self._device_run_scheduled = True
            self._serial.send_ctrl_c()
            # Небольшая задержка, затем отправляем код напрямую в paste mode
            # НЕ делаем Ctrl+D (soft reboot), иначе main.py на устройстве запустится!
            QTimer.singleShot(300, lambda: self._send_script_raw(code))
        except RuntimeError as exc:
            self._run_transition_active = False
            self._device_run_scheduled = False
            self._console_dock.append_error(tr("err_run", err=exc))
        except Exception as exc:
            self._run_transition_active = False
            self._device_run_scheduled = False
            self._log_runtime_error("run_on_device", exc)
            self._console_dock.append_error(tr("err_run", err=exc))

    def _run_local(self) -> None:
        if self._local_runner and self._local_runner.isRunning():
            self._console_dock.append_info("Local run is already active.")
            return
        self._stop_local_runner()

        code = self._editor.current_content()
        if not code.strip():
            self._console_dock.append_info(tr("run_local_nothing"))
            return

        self._console_dock.append_info(tr("run_local_started"))
        self._status_label.setText(tr("status_running_local"))

        try:
            filepath = self._editor.current_file_path()
            runner = LocalPythonRunner(code, filepath=filepath)
            runner.output_received.connect(self._on_local_output)
            runner.error_received.connect(self._on_local_error)
            runner.finished_with_code.connect(self._on_local_finished)
            self._local_runner = runner
            runner.start()
        except Exception as exc:
            self._log_runtime_error("run_local", exc)
            self._console_dock.append_error(tr("run_local_error", err=exc))
            self._status_label.setText(tr("ready"))

    def _send_script_raw(self, code: str) -> None:
        try:
            self._serial.send("\x05")
            time.sleep(0.1)
            chunk_size = 256
            for i in range(0, len(code), chunk_size):
                self._serial.send(code[i : i + chunk_size])
                time.sleep(0.02)
            self._serial.send("\x04")
            self._console_dock.append_info(tr("run_script_sent"))
        except RuntimeError as exc:
            self._console_dock.append_error(tr("err_send", err=exc))
        except Exception as exc:
            self._log_runtime_error("send_script_raw", exc)
            self._console_dock.append_error(tr("err_send", err=exc))
        finally:
            self._run_transition_active = False
            self._device_run_scheduled = False

    def _stop_execution(self) -> None:
        if self._run_transition_active:
            self._console_dock.append_info("Please wait for the current action.")
            return
        stopped = False
        if self._local_runner and self._local_runner.isRunning():
            self._stop_local_runner()
            self._console_dock.append_info(tr("run_local_stopped"))
            stopped = True
        if self._serial.is_connected:
            try:
                self._serial.send_ctrl_c()
                self._console_dock.append_info(tr("run_stopped"))
                stopped = True
            except RuntimeError as exc:
                self._console_dock.append_error(tr("err_stop", err=exc))
            except Exception as exc:
                self._log_runtime_error("stop_execution", exc)
                self._console_dock.append_error(tr("err_stop", err=exc))
        if not stopped:
            self._status_label.setText(tr("ready"))

    def _restart_script(self) -> None:
        """Stop current execution and run again."""
        self._console_dock.append_info(tr("run_restarting"))
        self._stop_execution()
        QTimer.singleShot(300, self._run_smart)

    def _stop_local_runner(self) -> None:
        if self._local_runner is not None:
            self._local_runner.stop()
            self._local_runner.wait(3000)
            self._local_runner = None

    # -- local runner callbacks --

    def _on_local_output(self, text: str) -> None:
        self._console_dock.append_text(text)

    def _on_local_error(self, text: str) -> None:
        self._console_dock.append_error(tr("run_local_error", err=text))

    def _on_local_finished(self, code: int) -> None:
        self._console_dock.append_info(tr("run_local_finished", code=code))
        self._status_label.setText(tr("ready"))
        self._local_runner = None

    # ------------------------------------------------------------------
    # Settings actions
    # ------------------------------------------------------------------

    def _change_theme(self, name: str) -> None:
        self._config.set("theme", name)
        self._theme.apply(name)
        dark = self._theme.is_dark()
        self._editor.apply_theme(dark)
        self._console_dock.apply_theme(dark)
        self._explorer_dock.apply_theme(dark)
        self._device_explorer_dock.apply_theme(dark)
        self._problems_dock.apply_theme(dark)
        self._update_toolbar_mode(force=True)

    def _change_language(self, lang: str) -> None:
        if lang == get_language():
            return
        self._config.set("language", lang)
        set_language(lang)
        self._rebuild_ui_texts()

    def _rebuild_ui_texts(self) -> None:
        """Re-create menu bar, toolbar, dock titles and status bar for the new language."""
        # Window title
        self.setWindowTitle(tr("app_title"))

        # Rebuild menu bar (clear old, build new)
        self.menuBar().clear()
        self._build_menu()

        # Rebuild toolbar
        self._update_toolbar_mode(force=True)

        # Dock titles
        self._console_dock.setWindowTitle(tr("console_title"))
        self._explorer_dock.setWindowTitle(tr("explorer_title"))
        self._device_explorer_dock.setWindowTitle(tr("devexp_title"))
        self._problems_dock.retranslate()

        # Status bar labels
        self._status_label.setText(tr("ready"))
        self._update_problem_status(self._current_problems)
        if self._serial.is_connected:
            port = self._serial.current_port
            self._port_label.setText(tr("status_connected", port=port, baud=self._baud_rate))
        else:
            self._port_label.setText(tr("no_device_connected"))
        self._check_current_problems()

    def _change_font_size(self) -> None:
        current = self._config.get("font_size", 13)
        size, ok = QInputDialog.getInt(
            self, tr("font_size_title"), tr("font_size_prompt"),
            current, 6, 36, 1
        )
        if ok:
            self._config.set("font_size", size)
            self._editor.apply_font_size(size)

    def _toggle_auto_save(self, enabled: bool) -> None:
        self._config.set("auto_save", enabled)
        if enabled:
            self._auto_save_timer.start()
        else:
            self._auto_save_timer.stop()

    def _toggle_syntax_highlight(self, enabled: bool) -> None:
        self._config.set("syntax_highlight", enabled)
        self._editor.set_syntax_highlight(enabled)

    def _toggle_error_checking(self, enabled: bool) -> None:
        self._config.set("error_checking", enabled)
        if enabled:
            self._check_current_problems()
            self._status_label.setText(tr("problems_checking_enabled"))
            return
        if hasattr(self, "_problem_timer"):
            self._problem_timer.stop()
        self._clear_problems()
        self._status_label.setText(tr("problems_checking_disabled"))

    def _auto_save(self) -> None:
        self._editor.save_current()
        self._schedule_session_snapshot()

    def _session_file_path(self) -> str:
        return self._config.resolve_path(self._config.get("session_file", "boardypy_session.json"))

    def _crash_log_path(self) -> str:
        return os.fspath(user_log_path("boardypy_runtime_error.log"))

    def _schedule_session_snapshot(self) -> None:
        self._session_dirty = True
        if not hasattr(self, "_session_timer"):
            return
        self._session_timer.start()

    def _flush_session_snapshot(self) -> None:
        if not self._session_dirty:
            return
        snapshot = self._editor.serialize_session()
        payload = {
            "saved_at": int(time.time()),
            "snapshot": snapshot,
        }
        try:
            with open(self._session_file_path(), "w", encoding="utf-8") as fh:
                json.dump(payload, fh, indent=2, ensure_ascii=False)
            self._config.set("last_session_snapshot_at", payload["saved_at"])
            self._config.set("has_crash_recovery", True)
            self._session_dirty = False
        except OSError:
            pass

    def _restore_session_snapshot(self) -> None:
        if not self._config.get("restore_unsaved_on_start", True):
            return
        path = self._session_file_path()
        if not os.path.isfile(path):
            return
        try:
            with open(path, "r", encoding="utf-8") as fh:
                payload = json.load(fh)
        except (OSError, json.JSONDecodeError):
            return
        snapshot = payload.get("snapshot") or {}
        if self._editor.restore_session(snapshot):
            self._console_dock.append_info("Session restored.")

    def _log_runtime_error(self, action: str, exc: Exception) -> None:
        try:
            with open(self._crash_log_path(), "a", encoding="utf-8") as fh:
                fh.write(f"\n[{time.strftime('%Y-%m-%d %H:%M:%S')}] {action}\n")
                fh.write("".join(traceback.format_exception(type(exc), exc, exc.__traceback__)))
        except OSError:
            pass

    # ------------------------------------------------------------------
    # Serial callbacks — these slots run in the MAIN thread thanks to
    # Qt’s queued signal/slot mechanism (SerialManager is a QObject).
    # ------------------------------------------------------------------

    @pyqtSlot(str)
    def _process_serial_data(self, text: str) -> None:
        """Buffer serial data and process line-by-line for correct error coloring."""
        self._serial_buf += text
        # Process all complete lines
        while '\n' in self._serial_buf:
            line, self._serial_buf = self._serial_buf.split('\n', 1)
            self._process_serial_line(line + '\n')
        # Flush if the buffer ends with a standalone prompt (no trailing newline)
        stripped = self._serial_buf.strip()
        if stripped in ('>>>', '...', '... '):
            self._process_serial_line(self._serial_buf)
            self._serial_buf = ""

    def _process_serial_line(self, line: str) -> None:
        """Decide color for one line; maintain _in_error_block state."""
        _ERROR_KW = ('Traceback', 'Error', 'Exception', 'KeyboardInterrupt')
        _PROMPT = ('>>>', '...')

        line_stripped = line.strip()

        # Skip empty lines and bare prompts — keep console clean
        if not line_stripped:
            return
        if line_stripped in _PROMPT or line_stripped == '>>> ' or line_stripped == '... ':
            # Reaching a REPL prompt means we left the error block
            if self._in_error_block:
                self._in_error_block = False
                self._show_error_hint(self._last_error_text)
                self._last_error_text = ""
            return  # don't print bare prompts

        # Any error keyword starts (or continues) an error block
        if any(kw in line for kw in _ERROR_KW):
            self._in_error_block = True

        if self._in_error_block:
            self._console_dock.append_error(line)
            self._last_error_text += line
        else:
            self._console_dock.append_text(line)

    # ------------------------------------------------------------------
    # Error hints
    # ------------------------------------------------------------------

    _ERROR_HINTS = [
        # (keyword in error text, hint message)
        ("EADDRINUSE",
         "Порт уже занят. Нажмите F5 ещё раз — устройство перезагрузится и порт освободится."),
        ("ENOMEM", "Недостаточно памяти. Попробуйте упростить код или разбить на модули."),
        ("MemoryError", "Не хватает RAM. Уменьшите размер буферов, строк или используйте gc.collect()."),
        ("SyntaxError",
         "Синтаксическая ошибка. Проверьте правильность скобок, отступов и двоеточий."),
        ("IndentationError",
         "Неправильный отступ. Используйте 4 пробела и не смешивайте табы с пробелами."),
        ("NameError",
         "Переменная или функция не найдена. Проверьте имя — возможно, опечатка или не импортирован модуль."),
        ("ImportError",
         "Модуль не найден. Убедитесь, что модуль есть на устройстве (lib/) или это встроенный модуль MicroPython."),
        ("ModuleNotFoundError",
         "Модуль не найден. Загрузите .py файл модуля в папку /lib на устройстве."),
        ("AttributeError",
         "Атрибут не найден. Проверьте название метода/свойства — возможно, в MicroPython оно отличается от CPython."),
        ("TypeError",
         "Неправильный тип данных. Проверьте аргументы функции — возможно, передаёте строку вместо числа."),
        ("ValueError",
         "Неправильное значение. Проверьте передаваемые данные — формат, диапазон, кодировку."),
        ("OSError",
         "Ошибка ОС/железа. Проверьте подключение периферии (пины, I2C, SPI) и параметры."),
        ("KeyError",
         "Ключ не найден в словаре. Используйте dict.get(key, default) для безопасного доступа."),
        ("IndexError",
         "Индекс за пределами списка. Проверьте длину массива через len()."),
        ("ZeroDivisionError",
         "Деление на ноль. Добавьте проверку: if x != 0 перед делением."),
        ("RuntimeError",
         "Ошибка выполнения. Проверьте состояние устройства — возможно, нужна перезагрузка (F5)."),
        ("KeyboardInterrupt",
         "Выполнение прервано пользователем (Ctrl+C / Stop)."),
        ("ECONNRESET",
         "Соединение сброшено. Клиент отключился — это нормально для HTTP сервера."),
        ("ECONNABORTED",
         "Соединение прервано. Добавьте try/except вокруг cl.send() и cl.close()."),
        ("ETIMEDOUT",
         "Таймаут подключения. Проверьте Wi-Fi сигнал и доступность сервера."),
        ("Pin",
         "Проверьте номер пина — не все GPIO доступны. Для ESP8266: 0,2,4,5,12,13,14,15."),
    ]

    def _show_error_hint(self, error_text: str) -> None:
        """Show a green hint based on the accumulated error text."""
        if not error_text:
            return
        for keyword, hint in self._ERROR_HINTS:
            if keyword in error_text:
                self._console_dock.append_hint(hint)
                return
        # Fallback generic hint
        self._console_dock.append_hint(
            "Проверьте код и попробуйте снова. Если ошибка повторяется — перезагрузите устройство (F5)."
        )

    @pyqtSlot(str)
    def _process_serial_error(self, msg: str) -> None:
        self._console_dock.append_error(tr("err_serial", err=msg))
        self._port_label.setText(tr("status_disconnected_err"))

    @pyqtSlot()
    def _handle_connected(self) -> None:
        port = self._serial.current_port
        if port:
            self._selected_port = port
            self._config.set("last_port", port)
        self._port_label.setText(tr("status_connected", port=port, baud=self._baud_rate))
        self._status_label.setText(tr("status_connected_to", port=port))
        self._console_dock.append_info(tr("status_connected_baud", port=port, baud=self._baud_rate))
        self._console_dock.set_input_enabled(True)
        # Give device explorer access to serial manager
        self._device_worker.set_serial_manager(self._serial)
        self._device_explorer_dock.set_connected(True)

    @pyqtSlot()
    def _handle_disconnected(self) -> None:
        self._port_label.setText(tr("status_disconnected"))
        self._status_label.setText(tr("status_disconnected"))
        self._console_dock.append_info(tr("status_device_disconnected"))
        # Reset serial state
        self._serial_buf = ""
        self._in_error_block = False
        self._last_error_text = ""
        # Disconnect device explorer
        self._device_worker.set_serial_manager(None)
        self._device_explorer_dock.set_connected(False)

    # ------------------------------------------------------------------
    # Console command send
    # ------------------------------------------------------------------

    def _send_command(self, command: str) -> None:
        """Route console input to local runner or serial device."""
        # If local script is running, feed it stdin
        if self._local_runner and self._local_runner.isRunning():
            self._local_runner.send_input(command)
            return
        # If device connected, send to serial
        if self._serial.is_connected:
            try:
                self._serial.send(command)
            except RuntimeError as exc:
                self._console_dock.append_error(tr("err_send", err=exc))
            return
        # Nothing running — run as local one-liner
        self._console_dock.append_text(">>> " + command)
        self._local_runner = LocalPythonRunner(command.strip())
        self._local_runner.output_received.connect(self._on_local_output)
        self._local_runner.error_received.connect(self._on_local_error)
        self._local_runner.finished_with_code.connect(self._on_local_finished)
        self._local_runner.start()

    # ------------------------------------------------------------------
    # Device file open / save
    # ------------------------------------------------------------------

    def _open_device_file_in_editor(self, remote_path: str, data: bytes) -> None:
        """Open a file from device in the editor for editing."""
        self._editor.open_device_file(remote_path, data)
        self._console_dock.append_info(tr("devexp_file_opened", name=remote_path))

    def _save_device_file(self, remote_path: str, data: bytes) -> None:
        """Save edited device file back to the device."""
        if not self._serial.is_connected:
            self._console_dock.append_info(tr("devexp_not_connected"))
            return
        self._device_worker.request_upload(remote_path, data)
        name = remote_path.rsplit("/", 1)[-1]
        self._console_dock.append_info(tr("devexp_uploading", name=name))

    # ------------------------------------------------------------------
    # Library manager
    # ------------------------------------------------------------------

    def _show_lib_manager(self) -> None:
        """Open the Library Manager dialog."""
        dlg = LibraryManagerDialog(
            device_connected=self._serial.is_connected,
            parent=self,
        )
        dlg.install_requested.connect(self._upload_lib_to_device)
        dlg.open_file_requested.connect(self._editor.open_file)
        dlg.exec_()

    def _upload_lib_to_device(self, remote_path: str, data: bytes) -> None:
        """Upload a library file to /lib/ on the device."""
        if not self._serial.is_connected:
            self._console_dock.append_info(tr("devexp_not_connected"))
            return
        # Ensure /lib/ directory exists (silently ignore if already there)
        self._device_worker.request_mkdir_if_missing("/lib")
        self._device_worker.request_replace_library_upload(remote_path, data)
        name = remote_path.rsplit("/", 1)[-1]
        self._console_dock.append_info(tr("devexp_uploading", name=name))

    # ------------------------------------------------------------------
    # PC explorer → device upload
    # ------------------------------------------------------------------

    def _upload_local_to_device(self, local_path: str) -> None:
        """Upload a local file to the current device directory."""
        if not self._serial.is_connected:
            self._console_dock.append_info(tr("devexp_not_connected"))
            return
        try:
            with open(local_path, "rb") as f:
                data = f.read()
        except Exception as exc:
            self._console_dock.append_error(str(exc))
            return
        name = os.path.basename(local_path)
        cur = self._device_explorer_dock._current_path.rstrip("/")
        remote = cur + "/" + name
        self._device_worker.request_replace_upload(remote, data)
        self._console_dock.append_info(tr("devexp_uploading", name=name))

    # ------------------------------------------------------------------
    # Help
    # ------------------------------------------------------------------

    def _show_about(self) -> None:
        AboutDialog(self).exec_()

    def resizeEvent(self, event: QResizeEvent) -> None:
        super().resizeEvent(event)
        self._update_toolbar_mode()

    # ------------------------------------------------------------------
    # Close
    # ------------------------------------------------------------------

    def closeEvent(self, event: QCloseEvent) -> None:
        geom_hex = self.saveGeometry().toHex().data().decode()
        self._config.set("window_geometry", geom_hex)
        self._flush_session_snapshot()
        if self._update_checker and self._update_checker.isRunning():
            self._update_checker.wait(500)
        if self._serial.is_connected:
            self._serial.disconnect_device()
        self._stop_local_runner()
        self._device_worker.stop()
        self._device_worker.wait(2000)
        event.accept()

