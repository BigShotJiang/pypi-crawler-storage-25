from __future__ import annotations

from PyQt5.QtCore import Qt, pyqtSignal, QRect, QSize, QTimer
from PyQt5.QtGui import QFont, QColor, QTextCursor, QTextCharFormat, QKeyEvent, QPainter, QPaintEvent, QResizeEvent
from PyQt5.QtWidgets import (
    QDockWidget, QWidget, QVBoxLayout, QHBoxLayout,
    QPlainTextEdit, QLineEdit, QPushButton, QLabel,
    QSizePolicy
)

from ..core.translations import tr


# ---- Line number area for console ----

class _ConsoleLineNumberArea(QWidget):
    def __init__(self, editor: "_ConsoleOutput") -> None:
        super().__init__(editor)
        self._editor = editor

    def sizeHint(self) -> QSize:
        return QSize(self._editor.line_number_area_width(), 0)

    def paintEvent(self, event: QPaintEvent) -> None:
        self._editor.line_number_area_paint(event)


class _ConsoleOutput(QPlainTextEdit):
    """QPlainTextEdit with line numbers and smart auto-scroll."""

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setReadOnly(True)
        self.setLineWrapMode(QPlainTextEdit.NoWrap)
        self.setMaximumBlockCount(10_000)

        self._line_area = _ConsoleLineNumberArea(self)
        self._line_offset = 0          # сколько строк было удалено из-за лимита
        self._prev_block_count = 1     # предыдущий blockCount для детекта удалений
        self.blockCountChanged.connect(self._on_block_count_changed)
        self.updateRequest.connect(self._update_line_area)
        self._update_line_area_width()

        # Smart auto-scroll: track whether user is at the bottom
        self._auto_scroll = True
        self.verticalScrollBar().valueChanged.connect(self._on_scroll)
        self.verticalScrollBar().rangeChanged.connect(self._on_range_changed)

    # ---- line numbers ----

    def _total_lines(self) -> int:
        """Total ever-appended lines (offset + current blocks)."""
        return self._line_offset + self.blockCount()

    def line_number_area_width(self) -> int:
        digits = max(1, len(str(self._total_lines())))
        return 8 + self.fontMetrics().horizontalAdvance("9") * digits

    def _on_block_count_changed(self, new_count: int) -> None:
        # Если blockCount уменьшился — Qt удалил старые строки сверху
        if new_count < self._prev_block_count:
            removed = self._prev_block_count - new_count
            self._line_offset += removed
        self._prev_block_count = new_count
        self._update_line_area_width()

    def _update_line_area_width(self) -> None:
        self.setViewportMargins(self.line_number_area_width(), 0, 0, 0)

    def _update_line_area(self, rect, dy) -> None:
        if dy:
            self._line_area.scroll(0, dy)
        else:
            self._line_area.update(0, rect.y(), self._line_area.width(), rect.height())
        if rect.contains(self.viewport().rect()):
            self._update_line_area_width()

    def resizeEvent(self, event: QResizeEvent) -> None:
        super().resizeEvent(event)
        cr = self.contentsRect()
        self._line_area.setGeometry(QRect(cr.left(), cr.top(), self.line_number_area_width(), cr.height()))

    def line_number_area_paint(self, event: QPaintEvent) -> None:
        painter = QPainter(self._line_area)
        painter.fillRect(event.rect(), QColor("#2d2d2d") if self._is_dark() else QColor("#e8e8e8"))
        block = self.firstVisibleBlock()
        block_number = block.blockNumber()
        top = int(self.blockBoundingGeometry(block).translated(self.contentOffset()).top())
        bottom = top + int(self.blockBoundingRect(block).height())
        fg = QColor("#858585") if self._is_dark() else QColor("#999999")
        painter.setPen(fg)
        while block.isValid() and top <= event.rect().bottom():
            if block.isVisible() and bottom >= event.rect().top():
                # Учитываем удалённые строки в смещении
                display_num = self._line_offset + block_number + 1
                painter.drawText(
                    0, top, self._line_area.width() - 4, bottom - top,
                    Qt.AlignRight | Qt.AlignVCenter, str(display_num)
                )
            block = block.next()
            top = bottom
            bottom = top + int(self.blockBoundingRect(block).height())
            block_number += 1
        painter.end()

    def _is_dark(self) -> bool:
        bg = self.palette().color(self.backgroundRole())
        return bg.lightness() < 128

    # ---- smart auto-scroll ----

    def _on_scroll(self, value: int) -> None:
        sb = self.verticalScrollBar()
        # Consider "at bottom" if within 5 lines of the end
        self._auto_scroll = (value >= sb.maximum() - 5 * self.fontMetrics().height())

    def _on_range_changed(self, _min: int, _max: int) -> None:
        if self._auto_scroll:
            self.verticalScrollBar().setValue(self.verticalScrollBar().maximum())

    def smart_append(self, text: str) -> None:
        """Append text, auto-scrolling only if user was at the bottom."""
        cursor = self.textCursor()
        cursor.movePosition(QTextCursor.End)
        if self.document().characterCount() > 1:
            self.setTextCursor(cursor)
            self.insertPlainText("\n" + text)
        else:
            self.setTextCursor(cursor)
            self.insertPlainText(text)
        # _on_range_changed handles scrolling


class ConsoleDock(QDockWidget):
    command_submitted = pyqtSignal(str)

    def __init__(self, parent=None) -> None:
        super().__init__(tr("console_title"), parent)
        self.setObjectName("ConsoleDock")
        self.setAllowedAreas(
            Qt.BottomDockWidgetArea
            | Qt.TopDockWidgetArea
        )
        self.setFeatures(
            QDockWidget.DockWidgetMovable
            | QDockWidget.DockWidgetClosable
            | QDockWidget.DockWidgetFloatable
        )
        self._build_ui()
        self._history: list[str] = []
        self._history_idx: int = -1
        self._dark = True  # track current theme for text colors

        # Output buffer: list of (text, color, italic)
        # Flushed to the widget every 50ms — prevents GUI freeze on rapid output
        self._buf: list[tuple[str, str, bool]] = []
        self._flush_timer = QTimer(self)
        self._flush_timer.setInterval(50)
        self._flush_timer.timeout.connect(self._flush_buf)
        self._flush_timer.start()

    # ------------------------------------------------------------------
    def _build_ui(self) -> None:
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(3)

        # Output area
        self._output = _ConsoleOutput()
        self._output.setSizePolicy(
            QSizePolicy.Expanding, QSizePolicy.Expanding
        )

        font = QFont("Consolas")
        font.setPointSize(12)
        font.setFixedPitch(True)
        self._output.setFont(font)

        # Bottom input row
        input_layout = QHBoxLayout()
        input_layout.setSpacing(4)

        self._prompt_label = QLabel(">>>")
        self._prompt_label.setFont(font)
        self._prompt_label.setSizePolicy(
            QSizePolicy.Fixed, QSizePolicy.Fixed
        )

        self._input = _HistoryLineEdit()
        self._input.setFont(font)
        self._input.setPlaceholderText(tr("console_local_placeholder"))
        self._input.returnPressed.connect(self._on_submit)

        btn_clear = QPushButton(tr("console_clear"))
        btn_clear.clicked.connect(self.clear_output)

        input_layout.addWidget(self._prompt_label)
        input_layout.addWidget(self._input)
        input_layout.addWidget(btn_clear)

        layout.addWidget(self._output)
        layout.addLayout(input_layout)

        self.setWidget(container)

    # ------------------------------------------------------------------
    @staticmethod
    def _clean_device_text(text: str) -> str:
        """Strip MicroPython raw/paste-mode control chars and junk lines."""
        # Remove control characters \x01-\x05 (raw REPL / paste mode markers)
        for ch in ('\x01', '\x02', '\x03', '\x04', '\x05'):
            text = text.replace(ch, '')
        # Remove paste mode header lines and collapse blank runs
        lines = text.split('\n')
        cleaned: list[str] = []
        for line in lines:
            stripped = line.strip()
            if stripped.startswith('=== '):
                continue
            if stripped.startswith('paste mode;'):
                continue
            # Skip solo prompts — they are visual noise
            if stripped in ('>>>', '...', '>>> ', '... '):
                continue
            # Collapse multiple blank lines into max one
            if not stripped and cleaned and not cleaned[-1].strip():
                continue
            cleaned.append(line)
        result = '\n'.join(cleaned).strip('\n')
        return result

    def _append_colored(self, text: str, color: str, italic: bool = False) -> None:
        """Add item to buffer — flushed to widget every 50ms."""
        text = text.rstrip("\n\r")
        if not text:
            return
        self._buf.append((text, color, italic))

    def _flush_buf(self) -> None:
        """Flush buffer to widget in one batch — called by timer."""
        if not self._buf:
            return
        items, self._buf = self._buf, []

        out = self._output
        cursor = out.textCursor()
        cursor.movePosition(QTextCursor.End)
        cursor.beginEditBlock()

        has_content = out.document().characterCount() > 1
        for text, color, italic in items:
            fmt = QTextCharFormat()
            fmt.setForeground(QColor(color))
            if italic:
                fmt.setFontItalic(True)
            if has_content:
                cursor.insertText("\n", fmt)
            cursor.insertText(text, fmt)
            has_content = True

        cursor.endEditBlock()
        out.setTextCursor(cursor)

    def append_text(self, text: str) -> None:
        """Append text to the console output (control chars stripped)."""
        cleaned = self._clean_device_text(text)
        if not cleaned:
            return
        color = "#e0e0e0" if self._dark else "#1a1a1a"
        self._append_colored(cleaned, color)

    def append_info(self, text: str) -> None:
        """Append an informational (italic) message."""
        self._append_colored(text, "#888888", italic=True)

    def append_error(self, text: str) -> None:
        """Append an error message in red."""
        self._append_colored(text, "#f44747")

    def append_hint(self, text: str) -> None:
        """Append a green hint/suggestion."""
        self._append_colored(text, "#4ec9b0")

    def clear_output(self) -> None:
        self._buf.clear()
        self._output._line_offset = 0
        self._output._prev_block_count = 1
        self._output.clear()

    def set_input_enabled(self, enabled: bool) -> None:
        """Update prompt hint; input line stays always enabled."""
        status = tr("console_device_connected") if enabled else tr("console_device_disconnected")
        self._prompt_label.setToolTip(status)

    # ------------------------------------------------------------------
    # Input handling
    # ------------------------------------------------------------------

    def _on_submit(self) -> None:
        text = self._input.text()
        if not text.strip():
            return
        self._history.insert(0, text)
        self._history_idx = -1
        self._input.clear()
        self.command_submitted.emit(text + "\r\n")

    # ------------------------------------------------------------------
    # Theme
    # ------------------------------------------------------------------

    def apply_theme(self, dark: bool) -> None:
        self._dark = dark
        if dark:
            bg, fg, border = "#1e1e1e", "#d4d4d4", "#3c3c3c"
        else:
            bg, fg, border = "#ffffff", "#1e1e1e", "#c0c0c0"

        style = f"""
            QPlainTextEdit {{
                background-color: {bg};
                color: {fg};
                border: 1px solid {border};
            }}
            QLineEdit {{
                background-color: {bg};
                color: {fg};
                border: 1px solid {border};
                padding: 2px;
            }}
            QLabel {{
                color: {fg};
            }}
        """
        self.widget().setStyleSheet(style)

        # Recolor existing user-text blocks so they stay readable
        self._recolor_user_text(dark)

    def _recolor_user_text(self, dark: bool) -> None:
        """Walk all blocks and swap user-text foreground for the new theme."""
        old_color = QColor("#1a1a1a") if dark else QColor("#e0e0e0")
        new_color = QColor("#e0e0e0") if dark else QColor("#1a1a1a")
        doc = self._output.document()
        cursor = QTextCursor(doc)
        cursor.beginEditBlock()
        block = doc.begin()
        while block.isValid():
            it = block.begin()
            while not it.atEnd():
                frag = it.fragment()
                if frag.isValid():
                    fmt = frag.charFormat()
                    fg = fmt.foreground().color()
                    if fg == old_color:
                        fmt.setForeground(new_color)
                        c = QTextCursor(doc)
                        c.setPosition(frag.position())
                        c.setPosition(frag.position() + frag.length(), QTextCursor.KeepAnchor)
                        c.setCharFormat(fmt)
                it += 1
            block = block.next()
        cursor.endEditBlock()


class _HistoryLineEdit(QLineEdit):
    """QLineEdit that supports up/down arrow history navigation."""

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._history: list[str] = []
        self._history_idx: int = -1

    def set_history(self, history: list[str]) -> None:
        self._history = history

    def keyPressEvent(self, event: QKeyEvent) -> None:
        if event.key() == Qt.Key_Up:
            if self._history and self._history_idx < len(self._history) - 1:
                self._history_idx += 1
                self.setText(self._history[self._history_idx])
            return
        if event.key() == Qt.Key_Down:
            if self._history_idx > 0:
                self._history_idx -= 1
                self.setText(self._history[self._history_idx])
            elif self._history_idx == 0:
                self._history_idx = -1
                self.clear()
            return
        super().keyPressEvent(event)
