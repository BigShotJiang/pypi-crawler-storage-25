from __future__ import annotations

import os

from PyQt5.QtCore import Qt, QDir, QSize, pyqtSignal, QModelIndex
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import (
    QDockWidget, QWidget, QVBoxLayout, QHBoxLayout,
    QTreeView, QPushButton, QLabel, QFileDialog,
    QSizePolicy, QAbstractItemView, QMenu, QFileSystemModel, QFileIconProvider,
)

from ..core.translations import tr
from ..paths import resource_path


class ExplorerIconProvider(QFileIconProvider):
    def __init__(self) -> None:
        super().__init__()
        self._folder = QIcon(resource_path("file_icons", "folder_light.png"))

    def icon(self, info):
        if getattr(info, "isDir", None) and info.isDir() and not self._folder.isNull():
            return self._folder
        return super().icon(info)


class FileExplorerDock(QDockWidget):
    file_double_clicked = pyqtSignal(str)
    upload_to_device_requested = pyqtSignal(str)  # local file path

    def __init__(self, parent=None) -> None:
        super().__init__(tr("explorer_title"), parent)
        self.setObjectName("FileExplorerDock")
        self.setAllowedAreas(
            Qt.LeftDockWidgetArea
            | Qt.RightDockWidgetArea
        )
        self.setFeatures(
            QDockWidget.DockWidgetMovable
        )
        self._build_ui()
        self._set_root(QDir.homePath())

    # ------------------------------------------------------------------
    def _build_ui(self) -> None:
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.setContentsMargins(2, 4, 2, 4)
        layout.setSpacing(3)

        # Toolbar row
        top_row = QHBoxLayout()
        top_row.setSpacing(4)

        self._path_label = QLabel()
        self._path_label.setWordWrap(False)
        self._path_label.setSizePolicy(
            QSizePolicy.Expanding, QSizePolicy.Fixed
        )
        self._path_label.setStyleSheet("font-size: 11px;")

        btn_open_folder = QPushButton("Открыть")
        btn_open_folder.setFixedSize(78, 24)
        btn_open_folder.setToolTip(tr("explorer_open_folder"))
        btn_open_folder.clicked.connect(self._browse_folder)

        btn_home = QPushButton("Домой")
        btn_home.setFixedSize(68, 24)
        btn_home.setToolTip(tr("explorer_go_home"))
        btn_home.clicked.connect(lambda: self._set_root(QDir.homePath()))

        top_row.addWidget(self._path_label)
        top_row.addWidget(btn_home)
        top_row.addWidget(btn_open_folder)

        # Tree view
        self._model = QFileSystemModel()
        self._model.setIconProvider(ExplorerIconProvider())
        # Show ALL files (no name filter)
        self._model.setNameFilterDisables(False)
        self._model.setFilter(
            QDir.AllDirs | QDir.Files | QDir.NoDotAndDotDot
        )

        self._tree = QTreeView()
        self._tree.setModel(self._model)
        self._tree.setIconSize(QSize(18, 18))
        self._tree.setAnimated(True)
        self._tree.setIndentation(16)
        self._tree.setSortingEnabled(True)
        self._tree.sortByColumn(0, Qt.AscendingOrder)
        self._tree.setSelectionMode(QAbstractItemView.SingleSelection)

        # Hide all columns except name
        for col in range(1, self._model.columnCount()):
            self._tree.hideColumn(col)

        self._tree.header().hide()
        self._tree.doubleClicked.connect(self._on_double_click)
        self._tree.setContextMenuPolicy(Qt.CustomContextMenu)
        self._tree.customContextMenuRequested.connect(self._tree_context_menu)

        layout.addLayout(top_row)
        layout.addWidget(self._tree)
        self.setWidget(container)

    # ------------------------------------------------------------------
    def _set_root(self, path: str) -> None:
        if not os.path.isdir(path):
            return
        self._root_path = path
        root_idx = self._model.setRootPath(path)
        self._tree.setRootIndex(root_idx)
        # Shorten the label
        short = path if len(path) <= 30 else "…" + path[-28:]
        self._path_label.setText(short)
        self._path_label.setToolTip(path)

    def _browse_folder(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, tr("explorer_select_folder"))
        if folder:
            self._set_root(folder)

    def set_root(self, path: str) -> None:
        self._set_root(path)

    # ------------------------------------------------------------------
    def _tree_context_menu(self, pos) -> None:
        index = self._tree.indexAt(pos)
        if not index.isValid():
            return
        path = self._model.filePath(index)
        if not os.path.isfile(path):
            return
        menu = QMenu(self)
        act_upload = menu.addAction(tr("explorer_upload_to_device"))
        act_upload.triggered.connect(lambda: self.upload_to_device_requested.emit(path))
        menu.exec_(self._tree.viewport().mapToGlobal(pos))

    # ------------------------------------------------------------------
    def _on_double_click(self, index: QModelIndex) -> None:
        path = self._model.filePath(index)
        if os.path.isfile(path):
            self.file_double_clicked.emit(path)

    # ------------------------------------------------------------------
    def apply_theme(self, dark: bool) -> None:
        if dark:
            bg, fg, sel = "#252526", "#d4d4d4", "#094771"
        else:
            bg, fg, sel = "#f8f8f8", "#1e1e1e", "#cce5ff"

        self._tree.setStyleSheet(f"""
            QTreeView {{
                background-color: {bg};
                color: {fg};
                border: none;
            }}
            QTreeView::item:selected {{
                background-color: {sel};
                color: {"#ffffff" if dark else "#1e1e1e"};
            }}
            QTreeView::item:hover {{
                background-color: {"#2a2d2e" if dark else "#e8f0fe"};
            }}
        """)
