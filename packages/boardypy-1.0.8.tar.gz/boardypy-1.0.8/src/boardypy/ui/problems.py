from __future__ import annotations

from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtGui import QBrush, QColor
from PyQt5.QtWidgets import (
    QAbstractItemView,
    QDockWidget,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
    QWidget,
)

from ..core.problems import CodeProblem
from ..core.translations import tr


class ProblemsDock(QDockWidget):
    problem_activated = pyqtSignal(int, int)
    fix_safe_requested = pyqtSignal()

    def __init__(self, parent=None) -> None:
        super().__init__(tr("problems_title"), parent)
        self.setObjectName("ProblemsDock")
        self.setToolTip(tr("problems_title_tooltip"))
        self.setAllowedAreas(Qt.BottomDockWidgetArea | Qt.TopDockWidgetArea)
        self.setFeatures(
            QDockWidget.DockWidgetMovable
            | QDockWidget.DockWidgetClosable
            | QDockWidget.DockWidgetFloatable
        )
        self._problems: list[CodeProblem] = []
        self._errors = 0
        self._warnings = 0
        self._build_ui()

    def _build_ui(self) -> None:
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(4)

        top_row = QHBoxLayout()
        top_row.setSpacing(6)

        self._summary = QLabel(tr("problems_summary_ok"))

        self._btn_fix = QPushButton(tr("problems_fix_safe"))
        self._btn_fix.clicked.connect(self.fix_safe_requested.emit)

        top_row.addWidget(self._summary)
        top_row.addStretch()
        top_row.addWidget(self._btn_fix)

        self._tree = QTreeWidget()
        self._tree.setHeaderLabels(
            [
                tr("problems_col_severity"),
                tr("problems_col_line"),
                tr("problems_col_message"),
                tr("problems_col_fix"),
            ]
        )
        self._tree.setSelectionBehavior(QAbstractItemView.SelectRows)
        self._tree.setSelectionMode(QAbstractItemView.SingleSelection)
        self._tree.itemDoubleClicked.connect(self._on_item_double_clicked)
        self._tree.header().setStretchLastSection(True)

        layout.addLayout(top_row)
        layout.addWidget(self._tree)
        self.setWidget(container)
        self.set_problems([])

    def set_problems(self, problems: list[CodeProblem]) -> None:
        self._problems = list(problems)
        self._tree.clear()

        errors = sum(1 for item in problems if item.severity == "error")
        warnings = sum(1 for item in problems if item.severity == "warning")
        self.set_problem_counts(errors, warnings)
        if errors or warnings:
            self._summary.setText(
                tr("problems_summary_counts", errors=errors, warnings=warnings)
            )
        else:
            self._summary.setText(tr("problems_summary_ok"))

        for problem in problems:
            item = QTreeWidgetItem(
                [
                    self._severity_label(problem.severity),
                    str(problem.line),
                    problem.message,
                    tr("problems_fix_available") if problem.fix_kind else "",
                ]
            )
            item.setData(0, Qt.UserRole, (problem.line, problem.column))
            item.setData(0, Qt.UserRole + 1, problem.detail or problem.message)
            if problem.severity == "error":
                item.setForeground(0, QBrush(QColor("#f44747")))
            self._tree.addTopLevelItem(item)

        self._btn_fix.setEnabled(any(item.fix_kind for item in problems))
        self._tree.resizeColumnToContents(0)
        self._tree.resizeColumnToContents(1)
        self._tree.resizeColumnToContents(3)

    def retranslate(self) -> None:
        self.set_problem_counts(self._errors, self._warnings)
        self.setToolTip(tr("problems_title_tooltip"))
        self._btn_fix.setText(tr("problems_fix_safe"))
        self._tree.setHeaderLabels(
            [
                tr("problems_col_severity"),
                tr("problems_col_line"),
                tr("problems_col_message"),
                tr("problems_col_fix"),
            ]
        )
        self.set_problems(self._problems)

    def set_problem_counts(self, errors: int, warnings: int) -> None:
        self._errors = max(0, errors)
        self._warnings = max(0, warnings)
        total = self._errors + self._warnings
        if total:
            self.setWindowTitle(tr("problems_tab_count", count=total))
        else:
            self.setWindowTitle(tr("problems_title"))

    def apply_theme(self, dark: bool) -> None:
        if dark:
            bg, fg, border = "#1e1e1e", "#d4d4d4", "#3c3c3c"
            btn_bg, btn_hover = "#2d2d30", "#3a3a3d"
            sel = "#094771"
        else:
            bg, fg, border = "#ffffff", "#1e1e1e", "#c0c0c0"
            btn_bg, btn_hover = "#f3f3f3", "#e4e4e4"
            sel = "#cce5ff"
        self.widget().setStyleSheet(
            f"""
            QLabel {{
                color: {fg};
            }}
            QTreeWidget {{
                background-color: {bg};
                color: {fg};
                border: 1px solid {border};
            }}
            QTreeWidget::item:selected {{
                background-color: {sel};
                color: {"#ffffff" if dark else "#1e1e1e"};
            }}
            QHeaderView::section {{
                background-color: {btn_bg};
                color: {fg};
                border: 1px solid {border};
                padding: 3px;
            }}
            QPushButton {{
                background-color: transparent;
                color: {fg};
                border: none;
                border-radius: 4px;
                padding: 3px 8px;
            }}
            QPushButton:hover {{
                background-color: {btn_hover};
            }}
            QPushButton:disabled {{
                color: {"#777777" if dark else "#999999"};
            }}
            """
        )

    def _on_item_double_clicked(self, item: QTreeWidgetItem, _column: int) -> None:
        data = item.data(0, Qt.UserRole)
        if not data:
            return
        line, column = data
        self.problem_activated.emit(int(line), int(column))

    @staticmethod
    def _severity_label(severity: str) -> str:
        if severity == "error":
            return tr("problems_error")
        if severity == "warning":
            return tr("problems_warning")
        return tr("problems_info")
