"""Dock widget: device file explorer for a connected MicroPython board."""
from __future__ import annotations

import os
from typing import Optional

from PyQt5.QtCore import Qt, QSize, pyqtSignal
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import (
    QAbstractItemView,
    QDockWidget,
    QFileDialog,
    QHeaderView,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QMenu,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QSizePolicy,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
    QWidget,
)

from ..core.device_fs import DeviceFSWorker
from ..core.translations import tr
from ..paths import resource_path


class DeviceExplorerDock(QDockWidget):
    file_downloaded = pyqtSignal(str, bytes)
    file_open_requested = pyqtSignal(str, bytes)

    def __init__(self, parent=None) -> None:
        super().__init__(tr("devexp_title"), parent)
        self.setObjectName("DeviceExplorerDock")
        self.setAllowedAreas(Qt.LeftDockWidgetArea | Qt.RightDockWidgetArea)
        self.setFeatures(
            QDockWidget.DockWidgetMovable
            | QDockWidget.DockWidgetClosable
            | QDockWidget.DockWidgetFloatable
        )

        self._current_path = "/"
        self._worker: Optional[DeviceFSWorker] = None
        self._connected = False
        self._pending_open: str | None = None
        self._folder_icon = QIcon(resource_path("file_icons", "folder_light.png"))

        self._build_title_bar()
        self._build_ui()

    def _build_title_bar(self) -> None:
        title_bar = QWidget()
        title_bar.setObjectName("DeviceExplorerTitleBar")
        title_layout = QHBoxLayout(title_bar)
        title_layout.setContentsMargins(6, 2, 6, 2)
        title_layout.setSpacing(6)

        self._btn_back = QPushButton("←")
        self._btn_back.setToolTip(tr("devexp_go_up"))
        self._btn_back.setFixedSize(24, 20)
        self._btn_back.clicked.connect(self._go_up)

        self._title_label = QLabel(tr("devexp_title"))
        self._title_label.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

        title_layout.addWidget(self._btn_back)
        title_layout.addWidget(self._title_label)
        title_layout.addStretch()
        self.setTitleBarWidget(title_bar)

    def _build_ui(self) -> None:
        container = QWidget()
        layout = QVBoxLayout(container)
        layout.setContentsMargins(2, 0, 2, 4)
        layout.setSpacing(2)

        self._path_label = QLabel("/")
        self._path_label.setStyleSheet("font-size: 11px;")
        self._path_label.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

        self._tree = QTreeWidget()
        self._tree.setHeaderLabels(
            [tr("devexp_col_name"), tr("devexp_col_size"), tr("devexp_col_type")]
        )
        self._tree.setIconSize(QSize(18, 18))
        self._tree.setSelectionMode(QAbstractItemView.SingleSelection)
        self._tree.setIndentation(12)
        self._tree.setContextMenuPolicy(Qt.CustomContextMenu)
        self._tree.customContextMenuRequested.connect(self._context_menu)
        self._tree.itemDoubleClicked.connect(self._on_double_click)

        header = self._tree.header()
        header.setStretchLastSection(False)
        header.setSectionResizeMode(0, QHeaderView.Stretch)
        header.setSectionResizeMode(1, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(2, QHeaderView.ResizeToContents)

        self._progress = QProgressBar()
        self._progress.setRange(0, 0)
        self._progress.setFixedHeight(16)
        self._progress.hide()

        self._status = QLabel(tr("devexp_not_connected"))
        self._status.setStyleSheet("font-size: 11px; color: #888;")

        layout.addWidget(self._path_label)
        layout.addWidget(self._tree)
        layout.addWidget(self._progress)
        layout.addWidget(self._status)
        self.setWidget(container)

    def set_worker(self, worker: DeviceFSWorker) -> None:
        self._worker = worker
        worker.listing_ready.connect(self._on_listing)
        worker.file_downloaded.connect(self._on_downloaded)
        worker.file_uploaded.connect(self._on_uploaded)
        worker.dir_created.connect(self._on_dir_created)
        worker.item_removed.connect(self._on_item_removed)
        worker.error_occurred.connect(self._on_error)
        worker.busy_changed.connect(self._on_busy)

    def set_connected(self, connected: bool) -> None:
        self._connected = connected
        self._sync_nav_buttons()
        if connected:
            self._status.setText(tr("devexp_connected"))
            self._refresh()
            return
        self._status.setText(tr("devexp_not_connected"))
        self._tree.clear()
        self._current_path = "/"
        self._path_label.setText("/")

    def _refresh(self) -> None:
        if not self._connected or not self._worker:
            self._status.setText(tr("devexp_not_connected"))
            self._sync_nav_buttons()
            return
        self._sync_nav_buttons()
        self._worker.request_list(self._current_path)

    def _go_up(self) -> None:
        if self._current_path == "/":
            return
        parts = self._current_path.rstrip("/").rsplit("/", 1)
        self._current_path = parts[0] if parts[0] else "/"
        self._path_label.setText(self._current_path)
        self._sync_nav_buttons()
        self._refresh()

    def _upload_file(self) -> None:
        if not self._connected or not self._worker:
            return
        path, _ = QFileDialog.getOpenFileName(self, tr("devexp_upload_title"))
        if not path:
            return
        try:
            with open(path, "rb") as fh:
                data = fh.read()
        except Exception as exc:
            QMessageBox.warning(self, tr("editor_error"), str(exc))
            return
        name = os.path.basename(path)
        remote = self._current_path.rstrip("/") + "/" + name
        self._worker.request_upload(remote, data)
        self._status.setText(tr("devexp_uploading", name=name))

    def _create_dir(self) -> None:
        if not self._connected or not self._worker:
            return
        name, ok = QInputDialog.getText(
            self,
            tr("devexp_mkdir_title"),
            tr("devexp_mkdir_prompt"),
        )
        if not ok or not name.strip():
            return
        remote = self._current_path.rstrip("/") + "/" + name.strip()
        self._worker.request_mkdir(remote)

    def _download_item(self) -> None:
        item = self._tree.currentItem()
        if not item or not self._worker:
            return
        item_type = item.text(2)
        name = item.data(0, Qt.UserRole)
        if not name or item_type == "dir":
            return
        remote = self._current_path.rstrip("/") + "/" + name
        self._worker.request_download(remote)
        self._status.setText(tr("devexp_downloading", name=name))

    def _delete_item(self) -> None:
        item = self._tree.currentItem()
        if not item or not self._worker:
            return
        name = item.data(0, Qt.UserRole)
        if not name:
            return
        remote = self._current_path.rstrip("/") + "/" + name
        answer = QMessageBox.question(
            self,
            tr("devexp_delete_title"),
            tr("devexp_delete_confirm", name=name),
            QMessageBox.Yes | QMessageBox.No,
        )
        if answer == QMessageBox.Yes:
            self._worker.request_remove(remote)

    def _on_listing(self, path: str, entries: list) -> None:
        self._tree.clear()
        self._current_path = path
        self._path_label.setText(path)
        self._sync_nav_buttons()

        dirs = sorted(
            [entry for entry in entries if entry["type"] == "dir"],
            key=lambda entry: entry["name"].lower(),
        )
        files = sorted(
            [entry for entry in entries if entry["type"] == "file"],
            key=lambda entry: entry["name"].lower(),
        )

        for entry in dirs + files:
            item = QTreeWidgetItem()
            item.setText(0, entry["name"])
            item.setData(0, Qt.UserRole, entry["name"])
            item.setText(1, "" if entry["type"] == "dir" else self._fmt_size(entry["size"]))
            item.setText(2, entry["type"])
            if entry["type"] == "dir" and not self._folder_icon.isNull():
                item.setIcon(0, self._folder_icon)
            self._tree.addTopLevelItem(item)

        self._status.setText(tr("devexp_items_count", count=len(entries)))

    def _on_downloaded(self, remote_path: str, data: bytes) -> None:
        name = remote_path.rsplit("/", 1)[-1]
        if self._pending_open == remote_path:
            self._pending_open = None
            self.file_open_requested.emit(remote_path, data)
            self._status.setText(tr("devexp_downloaded", name=name))
            return

        save_path, _ = QFileDialog.getSaveFileName(self, tr("devexp_save_as"), name)
        if save_path:
            try:
                with open(save_path, "wb") as fh:
                    fh.write(data)
                self._status.setText(tr("devexp_downloaded", name=name))
            except Exception as exc:
                QMessageBox.warning(self, tr("editor_error"), str(exc))

        self.file_downloaded.emit(remote_path, data)

    def _on_uploaded(self, remote_path: str) -> None:
        name = remote_path.rsplit("/", 1)[-1]
        self._status.setText(tr("devexp_uploaded", name=name))
        self._refresh()

    def _on_dir_created(self, remote_path: str) -> None:
        self._status.setText(tr("devexp_dir_created"))
        self._refresh()

    def _on_item_removed(self, remote_path: str) -> None:
        self._status.setText(tr("devexp_deleted"))
        self._refresh()

    def _on_error(self, msg: str) -> None:
        self._status.setText("Error: " + msg[:80])
        self._status.setToolTip(msg)

    def _on_busy(self, busy: bool) -> None:
        self._progress.setVisible(busy)

    def _context_menu(self, pos) -> None:
        if not self._connected or not self._worker:
            return

        menu = QMenu(self)
        item = self._tree.itemAt(pos)

        if item:
            item_type = item.text(2)
            if item_type == "file":
                act_download = menu.addAction(tr("devexp_download"))
                act_download.triggered.connect(self._download_item)
            act_delete = menu.addAction(tr("devexp_delete"))
            act_delete.triggered.connect(self._delete_item)
            menu.addSeparator()

        act_upload = menu.addAction(tr("devexp_upload"))
        act_upload.triggered.connect(self._upload_file)
        act_mkdir = menu.addAction(tr("devexp_mkdir"))
        act_mkdir.triggered.connect(self._create_dir)
        menu.addSeparator()
        act_refresh = menu.addAction(tr("devexp_refresh"))
        act_refresh.triggered.connect(self._refresh)
        if self._current_path != "/":
            act_up = menu.addAction(tr("devexp_go_up"))
            act_up.triggered.connect(self._go_up)

        menu.exec_(self._tree.viewport().mapToGlobal(pos))

    def _on_double_click(self, item: QTreeWidgetItem, col: int) -> None:
        item_type = item.text(2)
        name = item.data(0, Qt.UserRole)
        if item_type == "dir":
            self._current_path = self._current_path.rstrip("/") + "/" + name
            self._path_label.setText(self._current_path)
            self._sync_nav_buttons()
            self._refresh()
            return
        if item_type == "file" and self._worker:
            remote = self._current_path.rstrip("/") + "/" + name
            self._pending_open = remote
            self._worker.request_download(remote)
            self._status.setText(tr("devexp_downloading", name=name))

    def apply_theme(self, dark: bool) -> None:
        if dark:
            bg, fg, sel = "#252526", "#d4d4d4", "#094771"
            btn_bg = "#323234"
            btn_hover = "#3f3f46"
            btn_border = "#57575c"
            dock_btn_bg = "#3a3a3d"
            dock_btn_hover = "#4b4b50"
        else:
            bg, fg, sel = "#f8f8f8", "#1e1e1e", "#cce5ff"
            btn_bg = "#f3f3f3"
            btn_hover = "#e4e4e4"
            btn_border = "#c8c8c8"
            dock_btn_bg = "#ececec"
            dock_btn_hover = "#dcdcdc"

        self._tree.setStyleSheet(
            f"""
            QTreeWidget {{
                background-color: {bg};
                color: {fg};
                border: none;
            }}
            QTreeWidget::item:selected {{
                background-color: {sel};
                color: {"#ffffff" if dark else "#1e1e1e"};
            }}
            QTreeWidget::item:hover {{
                background-color: {"#2a2d2e" if dark else "#e8f0fe"};
            }}
            QHeaderView::section {{
                background-color: {"#2d2d2d" if dark else "#e0e0e0"};
                color: {fg};
                border: 1px solid {"#3c3c3c" if dark else "#c0c0c0"};
                padding: 3px;
            }}
            """
        )
        self.widget().setStyleSheet(
            f"""
            QPushButton {{
                background-color: {btn_bg};
                color: {fg};
                border: 1px solid {btn_border};
                border-radius: 4px;
                padding: 2px 6px;
            }}
            QPushButton:hover {{
                background-color: {btn_hover};
            }}
            QPushButton:disabled {{
                color: {"#777777" if dark else "#999999"};
            }}
            """
        )
        self.setStyleSheet(
            f"""
            #DeviceExplorerTitleBar {{
                background: {"#2d2d30" if dark else "#e9e9e9"};
                border-bottom: 1px solid {btn_border};
            }}
            #DeviceExplorerTitleBar QLabel {{
                color: {fg};
                font-weight: 600;
            }}
            #DeviceExplorerTitleBar QPushButton {{
                background: {dock_btn_bg};
                color: {fg};
                border: 1px solid {btn_border};
                border-radius: 4px;
                padding: 0;
            }}
            #DeviceExplorerTitleBar QPushButton:hover {{
                background: {dock_btn_hover};
            }}
            """
        )
        self._sync_nav_buttons()

    def _sync_nav_buttons(self) -> None:
        connected = self._connected and self._worker is not None
        self._btn_back.setEnabled(connected and self._current_path != "/")

    @staticmethod
    def _fmt_size(size: int) -> str:
        if size < 1024:
            return f"{size} B"
        if size < 1024 * 1024:
            return f"{size / 1024:.1f} KB"
        return f"{size / (1024 * 1024):.1f} MB"
