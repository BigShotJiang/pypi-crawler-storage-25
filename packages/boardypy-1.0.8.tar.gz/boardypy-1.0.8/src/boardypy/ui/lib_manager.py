﻿"""
Library Manager — browse and upload bundled MicroPython libraries to a device.
"""
from __future__ import annotations

import os
from typing import Optional

from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QTreeWidget, QTreeWidgetItem,
    QPushButton, QLabel, QTextEdit, QSplitter, QMessageBox, QWidget,
)

from ..core.translations import tr
from ..paths import package_root


# ---------------------------------------------------------------------------
# Library catalogue
# ---------------------------------------------------------------------------

# Each entry: (display_name, filename, category, description_ru, description_en)
_LIBS: list[tuple[str, str, str, str, str]] = [
    # ═══════════════════ ДИСПЛЕИ / DISPLAYS ═══════════════════
    (
        "SSD1306 OLED",
        "ssd1306.py",
        "Дисплеи / Displays",
        "━━━ OLED-дисплей 0.96\", 128×64 или 128×32 пикселей (SSD1306) ━━━\n\n"
        "Подключение по I2C (ESP8266):\n"
        "  SDA -> D2 (GPIO4)   SCL -> D1 (GPIO5)\n"
        "  VCC -> 3.3V         GND -> GND\n"
        "  I2C адрес: обычно 0x3C (реже 0x3D)\n\n"
        "Встроенные методы:\n"
        "  fill(0/1)          — очистить / заполнить\n"
        "  text('str', x, y)  — вывести текст (шрифт 8×8)\n"
        "  pixel(x, y, c)     — точка\n"
        "  hline/vline/rect   — линии и прямоугольники\n"
        "  show()             — обновить экран (без него ничего не видно!)\n\n"
        "Пример:\n"
        "  from machine import I2C, Pin\n"
        "  from ssd1306 import SSD1306_I2C\n"
        "  i2c = I2C(sda=Pin(4), scl=Pin(5))\n"
        "  oled = SSD1306_I2C(128, 64, i2c)\n"
        "  oled.fill(0)\n"
        "  oled.text('BoardyPy', 0, 0)\n"
        "  oled.text('v1.0.5', 0, 16)\n"
        "  oled.show()",
        "━━━ OLED display 0.96\", 128×64 or 128×32 pixels (SSD1306) ━━━\n\n"
        "I2C wiring (ESP8266):\n"
        "  SDA -> D2 (GPIO4)   SCL -> D1 (GPIO5)\n"
        "  VCC -> 3.3V         GND -> GND\n"
        "  I2C address: typically 0x3C (rarely 0x3D)\n\n"
        "Built-in methods:\n"
        "  fill(0/1)          — clear / fill\n"
        "  text('str', x, y)  — print text (8×8 font)\n"
        "  pixel(x, y, c)     — draw point\n"
        "  hline/vline/rect   — lines and rectangles\n"
        "  show()             — push buffer to display (required!)\n\n"
        "Example:\n"
        "  from machine import I2C, Pin\n"
        "  from ssd1306 import SSD1306_I2C\n"
        "  i2c = I2C(sda=Pin(4), scl=Pin(5))\n"
        "  oled = SSD1306_I2C(128, 64, i2c)\n"
        "  oled.fill(0)\n"
        "  oled.text('BoardyPy', 0, 0)\n"
        "  oled.text('v1.0.5', 0, 16)\n"
        "  oled.show()",
    ),
    (
        "LCD API (base)",
        "lcd_api.py",
        "Дисплеи / Displays",
        "━━━ Базовый класс HD44780 для символьных LCD (1602, 2004) ━━━\n\n"
        "! Загружай на устройство ВМЕСТЕ с i2c_lcd.py !\n\n"
        "Это абстрактный базовый класс — сам по себе не используется.\n"
        "Нужен как зависимость для i2c_lcd.py.\n\n"
        "Методы (доступны через I2cLcd):\n"
        "  clear()             — очистить дисплей\n"
        "  move_to(col, row)   — переместить курсор\n"
        "  putstr('...')       — вывести строку\n"
        "  putchar('.')        — вывести символ\n"
        "  backlight_on/off()  — управление подсветкой\n"
        "  show/hide_cursor()  — показать/скрыть курсор\n"
        "  custom_char(n, [...]) — загрузить кастомный символ",
        "━━━ HD44780 base class for character LCDs (1602, 2004) ━━━\n\n"
        "! Upload to device TOGETHER with i2c_lcd.py !\n\n"
        "This is an abstract base class — not used standalone.\n"
        "Required as a dependency by i2c_lcd.py.\n\n"
        "Methods (accessible via I2cLcd):\n"
        "  clear()             — clear display\n"
        "  move_to(col, row)   — move cursor\n"
        "  putstr('...')       — print string\n"
        "  putchar('.')        — print character\n"
        "  backlight_on/off()  — control backlight\n"
        "  show/hide_cursor()  — show/hide cursor\n"
        "  custom_char(n, [...]) — load custom character",
    ),
    (
        "I2C LCD 1602/2004",
        "i2c_lcd.py",
        "Дисплеи / Displays",
        "━━━ Символьный LCD 1602 / 2004 через I2C-переходник PCF8574 ━━━\n\n"
        "! Загружай на устройство ВМЕСТЕ с lcd_api.py !\n\n"
        "Подключение (ESP8266):\n"
        "  SDA -> D2 (GPIO4)   SCL -> D1 (GPIO5)\n"
        "  VCC -> 5V (лучше)   GND -> GND\n"
        "  I2C адрес: 0x27 или 0x3F (зависит от модуля)\n\n"
        "LCD 1602 = 16 символов × 2 строки\n"
        "LCD 2004 = 20 символов × 4 строки\n\n"
        "Пример:\n"
        "  from machine import I2C, Pin\n"
        "  from i2c_lcd import I2cLcd\n"
        "  i2c = I2C(sda=Pin(4), scl=Pin(5), freq=400000)\n"
        "  lcd = I2cLcd(i2c, 0x27, 2, 16)  # addr, rows, cols\n"
        "  lcd.putstr('BoardyPy v1.0')\n"
        "  lcd.move_to(0, 1)               # строка 2\n"
        "  lcd.putstr('Hello ESP8266!')",
        "━━━ Character LCD 1602 / 2004 via I2C adapter PCF8574 ━━━\n\n"
        "! Upload to device TOGETHER with lcd_api.py !\n\n"
        "Wiring (ESP8266):\n"
        "  SDA -> D2 (GPIO4)   SCL -> D1 (GPIO5)\n"
        "  VCC -> 5V (preferred) GND -> GND\n"
        "  I2C address: 0x27 or 0x3F (depends on module)\n\n"
        "LCD 1602 = 16 chars × 2 rows\n"
        "LCD 2004 = 20 chars × 4 rows\n\n"
        "Example:\n"
        "  from machine import I2C, Pin\n"
        "  from i2c_lcd import I2cLcd\n"
        "  i2c = I2C(sda=Pin(4), scl=Pin(5), freq=400000)\n"
        "  lcd = I2cLcd(i2c, 0x27, 2, 16)  # addr, rows, cols\n"
        "  lcd.putstr('BoardyPy v1.0')\n"
        "  lcd.move_to(0, 1)               # row 2\n"
        "  lcd.putstr('Hello ESP8266!')",
    ),
    (
        "MAX7219 (матрица / 7-сег.)",
        "max7219.py",
        "Дисплеи / Displays",
        "━━━ MAX7219 — 8×8 LED-матрица или 7-сегментный индикатор (SPI) ━━━\n\n"
        "Подключение (ESP8266):\n"
        "  DIN  -> D7 (GPIO13, MOSI)   CLK -> D5 (GPIO14, SCK)\n"
        "  CS   -> D8 (GPIO15)         VCC -> 5V   GND -> GND\n\n"
        "Особенности:\n"
        "  • Поддерживает каскадирование (несколько модулей цепочкой)\n"
        "  • Регулируемая яркость 0–15\n"
        "  • Экономит GPIO — всего 3 пина управляют матрицей 8×8\n\n"
        "Пример (матрица):\n"
        "  from machine import SPI, Pin\n"
        "  from max7219 import Matrix8x8\n"
        "  spi = SPI(1, baudrate=10000000)\n"
        "  cs  = Pin(15, Pin.OUT)\n"
        "  m   = Matrix8x8(spi, cs, num=1)\n"
        "  m.brightness(5)\n"
        "  m.fill(0);  m.show()\n"
        "  m.pixel(3, 3, 1); m.show()  # центральная точка\n"
        "  m.text('Hi', 0, 0); m.show()",
        "━━━ MAX7219 — 8×8 LED matrix or 7-segment display (SPI) ━━━\n\n"
        "Wiring (ESP8266):\n"
        "  DIN  -> D7 (GPIO13, MOSI)   CLK -> D5 (GPIO14, SCK)\n"
        "  CS   -> D8 (GPIO15)         VCC -> 5V   GND -> GND\n\n"
        "Features:\n"
        "  • Supports daisy-chaining (multiple modules)\n"
        "  • Adjustable brightness 0–15\n"
        "  • Saves GPIO — only 3 pins control an 8×8 matrix\n\n"
        "Example (matrix):\n"
        "  from machine import SPI, Pin\n"
        "  from max7219 import Matrix8x8\n"
        "  spi = SPI(1, baudrate=10000000)\n"
        "  cs  = Pin(15, Pin.OUT)\n"
        "  m   = Matrix8x8(spi, cs, num=1)\n"
        "  m.brightness(5)\n"
        "  m.fill(0);  m.show()\n"
        "  m.pixel(3, 3, 1); m.show()\n"
        "  m.text('Hi', 0, 0); m.show()",
    ),
    # ═══════════════════ СЕНСОРЫ / SENSORS ════════════════════
    (
        "DHT11 / DHT22 (температура/влажность)",
        "dht_helper.py",
        "Сенсоры / Sensors",
        "━━━ Датчики температуры и влажности DHT11 / DHT22 ━━━\n\n"
        "Встроенный модуль dht уже есть в MicroPython!\n\n"
        "Подключение (ESP8266):\n"
        "  DATA -> любой GPIO, например D2 (GPIO4)\n"
        "  VCC  -> 3.3V или 5V   GND -> GND\n"
        "  Резистор 10 кОм между DATA и VCC (рекомендуется!)\n\n"
        "Сравнение:\n"
        "  DHT11 — температура ±2 °C, влажность ±5%, 1 раз/с, дешевле\n"
        "  DHT22 — температура ±0.5 °C, влажность ±2%, 1 раз/2 с, точнее\n\n"
        "Использование (встроенный модуль, доп. файл не нужен):\n"
        "  from machine import Pin\n"
        "  import dht\n"
        "  d = dht.DHT11(Pin(4))   # или DHT22\n"
        "  d.measure()\n"
        "  print(d.temperature())  # °C\n"
        "  print(d.humidity())     # %\n\n"
        "Файл dht_helper.py — дополнительные функции:\n"
        "  from dht_helper import read_dht11, heat_index\n"
        "  temp, hum = read_dht11(4)          # безопасное чтение\n"
        "  print(heat_index(temp, hum))  # ощущаемая температура",
        "━━━ Temperature & humidity sensors DHT11 / DHT22 ━━━\n\n"
        "The dht module is already built into MicroPython!\n\n"
        "Wiring (ESP8266):\n"
        "  DATA -> any GPIO, e.g. D2 (GPIO4)\n"
        "  VCC  -> 3.3V or 5V   GND -> GND\n"
        "  10 kΩ pull-up between DATA and VCC (recommended!)\n\n"
        "Comparison:\n"
        "  DHT11 — temperature ±2 °C, humidity ±5%, once/s, cheaper\n"
        "  DHT22 — temperature ±0.5 °C, humidity ±2%, once/2 s, precise\n\n"
        "Usage (built-in module, no extra file needed):\n"
        "  from machine import Pin\n"
        "  import dht\n"
        "  d = dht.DHT11(Pin(4))   # or DHT22\n"
        "  d.measure()\n"
        "  print(d.temperature())  # °C\n"
        "  print(d.humidity())     # %\n\n"
        "dht_helper.py — extra helpers:\n"
        "  from dht_helper import read_dht11, heat_index\n"
        "  temp, hum = read_dht11(4)          # safe read\n"
        "  print(heat_index(temp, hum))  # feels-like temperature",
    ),
    (
        "DS18B20 (1-Wire, температура)",
        "ds18b20_helper.py",
        "Сенсоры / Sensors",
        "━━━ Датчик температуры DS18B20 (Dallas, 1-Wire) ━━━\n\n"
        "Модули onewire и ds18x20 встроены в MicroPython!\n\n"
        "Подключение (ESP8266):\n"
        "  DATA -> любой GPIO, например D3 (GPIO0)\n"
        "  VCC  -> 3.3V   GND -> GND\n"
        "  Резистор 4.7 кОм между DATA и VCC (ОБЯЗАТЕЛЬНО!)\n\n"
        "Особенности:\n"
        "  • До 10 датчиков на один провод одновременно\n"
        "  • Диапазон: −55 °C … +125 °C, точность ±0.5 °C\n"
        "  • Водонепроницаемый зонд (в металлической трубке)\n"
        "  • Время измерения ~750 мс (ждать обязательно!)\n\n"
        "Использование (встроенные модули, доп. файл не нужен):\n"
        "  from machine import Pin\n"
        "  import onewire, ds18x20, utime\n"
        "  ow   = onewire.OneWire(Pin(0))\n"
        "  ds   = ds18x20.DS18X20(ow)\n"
        "  roms = ds.scan()             # найти датчики\n"
        "  ds.convert_temp()            # запустить измерение\n"
        "  utime.sleep_ms(750)          # ждём готовности\n"
        "  for rom in roms:\n"
        "      print(ds.read_temp(rom)) # °C",
        "━━━ DS18B20 temperature sensor (Dallas, 1-Wire) ━━━\n\n"
        "The onewire and ds18x20 modules are built into MicroPython!\n\n"
        "Wiring (ESP8266):\n"
        "  DATA -> any GPIO, e.g. D3 (GPIO0)\n"
        "  VCC  -> 3.3V   GND -> GND\n"
        "  4.7 kΩ pull-up between DATA and VCC (REQUIRED!)\n\n"
        "Features:\n"
        "  • Up to 10 sensors on a single wire\n"
        "  • Range: −55 °C … +125 °C, accuracy ±0.5 °C\n"
        "  • Waterproof stainless steel probe variant\n"
        "  • Conversion time ~750 ms (must wait!)\n\n"
        "Usage (built-in modules, no extra file needed):\n"
        "  from machine import Pin\n"
        "  import onewire, ds18x20, utime\n"
        "  ow   = onewire.OneWire(Pin(0))\n"
        "  ds   = ds18x20.DS18X20(ow)\n"
        "  roms = ds.scan()\n"
        "  ds.convert_temp()\n"
        "  utime.sleep_ms(750)\n"
        "  for rom in roms:\n"
        "      print(ds.read_temp(rom)) # °C",
    ),
    (
        "BMP280 (давление, температура)",
        "bmp280.py",
        "Сенсоры / Sensors",
        "━━━ BMP280 — датчик атмосферного давления и температуры (I2C) ━━━\n\n"
        "Подключение (ESP8266):\n"
        "  SDA -> D2 (GPIO4)   SCL -> D1 (GPIO5)\n"
        "  VCC -> 3.3V (ТОЛЬКО 3.3V!)   GND -> GND\n"
        "  I2C адрес: 0x76 (SDO→GND) или 0x77 (SDO→VCC)\n\n"
        "Что измеряет:\n"
        "  • Температура: −40…+85 °C, точность ±1 °C\n"
        "  • Давление: 300…1100 hPa, точность ±1 hPa\n"
        "  • Высота над уровнем моря (рассчитывается из давления)\n\n"
        "Пример:\n"
        "  from machine import I2C, Pin\n"
        "  from bmp280 import BMP280\n"
        "  i2c    = I2C(sda=Pin(4), scl=Pin(5))\n"
        "  sensor = BMP280(i2c)\n"
        "  print('Темп:',    sensor.temperature, '°C')\n"
        "  print('Давление:', sensor.pressure,   'hPa')\n"
        "  print('Высота:',   sensor.altitude,   'м')",
        "━━━ BMP280 — atmospheric pressure and temperature sensor (I2C) ━━━\n\n"
        "Wiring (ESP8266):\n"
        "  SDA -> D2 (GPIO4)   SCL -> D1 (GPIO5)\n"
        "  VCC -> 3.3V ONLY!   GND -> GND\n"
        "  I2C address: 0x76 (SDO→GND) or 0x77 (SDO→VCC)\n\n"
        "What it measures:\n"
        "  • Temperature: −40…+85 °C, accuracy ±1 °C\n"
        "  • Pressure: 300…1100 hPa, accuracy ±1 hPa\n"
        "  • Altitude above sea level (calculated from pressure)\n\n"
        "Example:\n"
        "  from machine import I2C, Pin\n"
        "  from bmp280 import BMP280\n"
        "  i2c    = I2C(sda=Pin(4), scl=Pin(5))\n"
        "  sensor = BMP280(i2c)\n"
        "  print('Temp:',     sensor.temperature, '°C')\n"
        "  print('Pressure:', sensor.pressure,    'hPa')\n"
        "  print('Altitude:', sensor.altitude,    'm')",
    ),
    (
        "HX711 (весы/тензодатчик)",
        "hx711.py",
        "Сенсоры / Sensors",
        "━━━ HX711 — 24-битный АЦП для тензодатчиков (весы) ━━━\n\n"
        "Подключение (ESP8266):\n"
        "  DT  (данные) -> любой GPIO, например D2 (GPIO4)\n"
        "  SCK (такт)   -> любой GPIO, например D1 (GPIO5)\n"
        "  VCC -> 3.3V или 5V   GND -> GND\n\n"
        "Особенности:\n"
        "  • 24-битный АЦП — очень высокая точность\n"
        "  • Канал A (усиление 128 или 64), канал B (усиление 32)\n"
        "  • Для работы нужна калибровка под конкретные весы\n\n"
        "Пример:\n"
        "  from hx711 import HX711\n"
        "  hx = HX711(d_out=4, pd_sck=5)\n"
        "  print('Обнуление...')\n"
        "  hx.tare()                    # обнулить (убрать тару)\n"
        "  hx.set_scale(420)            # коэфф. калибровки\n"
        "  while True:\n"
        "      w = hx.get_weight(5)     # среднее из 5 измерений\n"
        "      print(round(w, 1), 'г')",
        "━━━ HX711 — 24-bit ADC for load cells (scales) ━━━\n\n"
        "Wiring (ESP8266):\n"
        "  DT  (data)  -> any GPIO, e.g. D2 (GPIO4)\n"
        "  SCK (clock) -> any GPIO, e.g. D1 (GPIO5)\n"
        "  VCC -> 3.3V or 5V   GND -> GND\n\n"
        "Features:\n"
        "  • 24-bit ADC — very high precision\n"
        "  • Channel A (gain 128 or 64), channel B (gain 32)\n"
        "  • Requires calibration for your specific load cell\n\n"
        "Example:\n"
        "  from hx711 import HX711\n"
        "  hx = HX711(d_out=4, pd_sck=5)\n"
        "  print('Zeroing...')\n"
        "  hx.tare()                    # zero the scale\n"
        "  hx.set_scale(420)            # calibration factor\n"
        "  while True:\n"
        "      w = hx.get_weight(5)     # average of 5 readings\n"
        "      print(round(w, 1), 'g')",
    ),
    (
        "ADS1115 (16-бит АЦП, 4 канала)",
        "ads1115.py",
        "Сенсоры / Sensors",
        "━━━ ADS1115 — 16-битный 4-канальный АЦП via I2C ━━━\n\n"
        "Зачем нужен: ESP8266 имеет только 1 ADC пин (A0, 0–1 В).\n"
        "ADS1115 добавляет 4 точных аналоговых входа до 4.096 В.\n\n"
        "Подключение (ESP8266):\n"
        "  SDA -> D2 (GPIO4)   SCL -> D1 (GPIO5)\n"
        "  VCC -> 3.3V         GND -> GND\n"
        "  ADDR -> GND (адрес 0x48) или VCC (0x49)\n\n"
        "Усиление (set_gain):\n"
        "  2/3 → ±6.144 В,  1 → ±4.096 В,  2 → ±2.048 В\n"
        "  4 → ±1.024 В,   8 → ±0.512 В,  16 → ±0.256 В\n\n"
        "Пример:\n"
        "  from machine import I2C, Pin\n"
        "  from ads1115 import ADS1115\n"
        "  i2c = I2C(sda=Pin(4), scl=Pin(5))\n"
        "  adc = ADS1115(i2c, address=0x48)\n"
        "  adc.set_gain(1)              # ±4.096 В\n"
        "  raw   = adc.read(0)          # канал A0\n"
        "  volts = raw * 4.096 / 32767\n"
        "  print(round(volts, 3), 'V')",
        "━━━ ADS1115 — 16-bit 4-channel ADC via I2C ━━━\n\n"
        "Why use it: ESP8266 has only 1 ADC pin (A0, 0–1 V).\n"
        "ADS1115 adds 4 precise analog inputs up to 4.096 V.\n\n"
        "Wiring (ESP8266):\n"
        "  SDA -> D2 (GPIO4)   SCL -> D1 (GPIO5)\n"
        "  VCC -> 3.3V         GND -> GND\n"
        "  ADDR -> GND (address 0x48) or VCC (0x49)\n\n"
        "Gain (set_gain):\n"
        "  2/3 → ±6.144 V,  1 → ±4.096 V,  2 → ±2.048 V\n"
        "  4 → ±1.024 V,   8 → ±0.512 V,  16 → ±0.256 V\n\n"
        "Example:\n"
        "  from machine import I2C, Pin\n"
        "  from ads1115 import ADS1115\n"
        "  i2c = I2C(sda=Pin(4), scl=Pin(5))\n"
        "  adc = ADS1115(i2c, address=0x48)\n"
        "  adc.set_gain(1)              # ±4.096 V\n"
        "  raw   = adc.read(0)          # channel A0\n"
        "  volts = raw * 4.096 / 32767\n"
        "  print(round(volts, 3), 'V')",
    ),
    # ══════════════════ СВЯЗЬ / COMMUNICATION ══════════════════
    (
        "MFRC522 (RFID карты)",
        "mfrc522.py",
        "Связь / Communication",
        "━━━ MFRC522 — RFID-ридер карт и брелоков Mifare (SPI) ━━━\n\n"
        "Подключение (ESP8266):\n"
        "  SCK  -> D5 (GPIO14)   MOSI -> D7 (GPIO13)\n"
        "  MISO -> D6 (GPIO12)   CS   -> D8 (GPIO15)\n"
        "  RST  -> D1 (GPIO5)    VCC  -> 3.3V   GND -> GND\n\n"
        "Что умеет:\n"
        "  • Читать UID карты/брелока\n"
        "  • Аутентифицироваться и читать/записывать блоки данных\n"
        "  • Стандарт ISO/IEC 14443A, частота 13.56 МГц\n\n"
        "Пример (чтение UID):\n"
        "  from mfrc522 import MFRC522\n"
        "  reader = MFRC522(sck=14, mosi=13, miso=12, cs=15, rst=5)\n"
        "  print('Поднеси карту...')\n"
        "  while True:\n"
        "      stat, _ = reader.request(reader.REQIDL)\n"
        "      if stat == reader.OK:\n"
        "          stat, uid = reader.anticoll()\n"
        "          if stat == reader.OK:\n"
        "              print('UID:', [hex(b) for b in uid[:4]])",
        "━━━ MFRC522 — RFID reader for Mifare cards and tags (SPI) ━━━\n\n"
        "Wiring (ESP8266):\n"
        "  SCK  -> D5 (GPIO14)   MOSI -> D7 (GPIO13)\n"
        "  MISO -> D6 (GPIO12)   CS   -> D8 (GPIO15)\n"
        "  RST  -> D1 (GPIO5)    VCC  -> 3.3V   GND -> GND\n\n"
        "Capabilities:\n"
        "  • Read card/tag UID\n"
        "  • Authenticate and read/write data blocks\n"
        "  • ISO/IEC 14443A standard, 13.56 MHz\n\n"
        "Example (read UID):\n"
        "  from mfrc522 import MFRC522\n"
        "  reader = MFRC522(sck=14, mosi=13, miso=12, cs=15, rst=5)\n"
        "  print('Hold card near reader...')\n"
        "  while True:\n"
        "      stat, _ = reader.request(reader.REQIDL)\n"
        "      if stat == reader.OK:\n"
        "          stat, uid = reader.anticoll()\n"
        "          if stat == reader.OK:\n"
        "              print('UID:', [hex(b) for b in uid[:4]])",
    ),
    (
        "IR-приёмник NEC (пульт ДУ)",
        "ir_rx.py",
        "Связь / Communication",
        "━━━ Декодер ИК-пульта ДУ, протокол NEC (VS1838B, TSOP4838) ━━━\n\n"
        "Поддерживает большинство TV-пультов (протокол NEC).\n\n"
        "Подключение (ESP8266):\n"
        "  OUT  -> D5 (GPIO14) или D6 (GPIO12)\n"
        "  VCC  -> 3.3V   GND -> GND\n\n"
        "Как определить свои коды кнопок:\n"
        "  1. Загрузи ir_rx.py на устройство\n"
        "  2. Запусти пример ниже\n"
        "  3. Нажимай кнопки пульта и запоминай коды (data)\n\n"
        "Пример:\n"
        "  from machine import Pin\n"
        "  from ir_rx import NECIR\n\n"
        "  def on_ir(data, addr, ctrl):\n"
        "      print(f'Код: {data:#04x}  Устройство: {addr:#04x}')\n\n"
        "  ir = NECIR(Pin(14, Pin.IN), on_ir)\n"
        "  # Нажимай кнопки — коды появятся в консоли",
        "━━━ IR remote control decoder, NEC protocol (VS1838B, TSOP4838) ━━━\n\n"
        "Supports most TV remotes (NEC protocol).\n\n"
        "Wiring (ESP8266):\n"
        "  OUT  -> D5 (GPIO14) or D6 (GPIO12)\n"
        "  VCC  -> 3.3V   GND -> GND\n\n"
        "How to find your button codes:\n"
        "  1. Upload ir_rx.py to the device\n"
        "  2. Run the example below\n"
        "  3. Press buttons and note the codes (data)\n\n"
        "Example:\n"
        "  from machine import Pin\n"
        "  from ir_rx import NECIR\n\n"
        "  def on_ir(data, addr, ctrl):\n"
        "      print(f'Code: {data:#04x}  Device: {addr:#04x}')\n\n"
        "  ir = NECIR(Pin(14, Pin.IN), on_ir)\n"
        "  # Press buttons — codes appear in console",
    ),
    (
        "Wi-Fi хелпер",
        "wifi_helper.py",
        "Связь / Communication",
        "━━━ Быстрое подключение ESP8266 к Wi-Fi ━━━\n\n"
        "Встроенный модуль network уже есть в MicroPython!\n\n"
        "Базовое подключение (без файла):\n"
        "  import network\n"
        "  wlan = network.WLAN(network.STA_IF)\n"
        "  wlan.active(True)\n"
        "  wlan.connect('MySSID', 'MyPassword')\n"
        "  while not wlan.isconnected(): pass\n"
        "  print('IP:', wlan.ifconfig()[0])\n\n"
        "Файл wifi_helper.py — удобные обёртки:\n"
        "  from wifi_helper import connect, create_ap, scan\n\n"
        "  # Клиент (STA) — подключиться к роутеру\n"
        "  ip = connect('MySSID', 'password', timeout=15)\n"
        "  if ip: print('Подключено! IP:', ip)\n"
        "  else:  print('Не удалось подключиться')\n\n"
        "  # Точка доступа (AP) — создать свою сеть\n"
        "  create_ap('ESP8266-AP', 'password123')\n\n"
        "  # Сканировать сети вокруг\n"
        "  for net in scan():\n"
        "      ssid = net[0].decode()\n"
        "      rssi = net[3]       # дБм, чем ближе к 0, тем сильнее\n"
        "      print(ssid, rssi, 'dBm')",
        "━━━ Quick Wi-Fi connection for ESP8266 ━━━\n\n"
        "The network module is already built into MicroPython!\n\n"
        "Basic connection (no file needed):\n"
        "  import network\n"
        "  wlan = network.WLAN(network.STA_IF)\n"
        "  wlan.active(True)\n"
        "  wlan.connect('MySSID', 'MyPassword')\n"
        "  while not wlan.isconnected(): pass\n"
        "  print('IP:', wlan.ifconfig()[0])\n\n"
        "wifi_helper.py — convenience wrappers:\n"
        "  from wifi_helper import connect, create_ap, scan\n\n"
        "  # Client (STA) — connect to router\n"
        "  ip = connect('MySSID', 'password', timeout=15)\n"
        "  if ip: print('Connected! IP:', ip)\n"
        "  else:  print('Connection failed')\n\n"
        "  # Access point (AP) — create own network\n"
        "  create_ap('ESP8266-AP', 'password123')\n\n"
        "  # Scan for nearby networks\n"
        "  for net in scan():\n"
        "      ssid = net[0].decode()\n"
        "      rssi = net[3]       # dBm, closer to 0 = stronger\n"
        "      print(ssid, rssi, 'dBm')",
    ),
    # ══════════════════ ПРИВОДЫ / ACTUATORS ═══════════════════
    (
        "Servo (сервопривод SG90/MG90S)",
        "servo.py",
        "Приводы / Actuators",
        "━━━ Сервопривод SG90/MG90S через PWM ━━━\n\n"
        "PWM GPIO на ESP8266: 0, 2, 4, 5, 12, 13, 14, 15\n"
        "GPIO16 НЕ поддерживает PWM!\n\n"
        "Подключение:\n"
        "  Оранжевый (сигнал) -> D1 (GPIO5) или другой PWM GPIO\n"
        "  Красный (VCC)      -> 5V (внешнее питание лучше)\n"
        "  Коричневый (GND)   -> GND (общий с ESP8266)\n\n"
        "Параметры:\n"
        "  Частота PWM: 50 Гц (стандарт для сервоприводов)\n"
        "  Угол: 0–180 градусов\n"
        "  SG90: миниатюрный, до 180°, момент ~1.8 кг/см\n"
        "  MG90S: металлические шестерни, надёжнее\n\n"
        "Пример:\n"
        "  from machine import Pin\n"
        "  from servo import Servo\n"
        "  s = Servo(Pin(5))\n"
        "  s.write_angle(0)     # минимум\n"
        "  s.write_angle(90)    # середина (нейтраль)\n"
        "  s.write_angle(180)   # максимум\n"
        "  s.detach()           # снять сигнал (сервo свободно)",
        "━━━ SG90/MG90S servo motor via PWM ━━━\n\n"
        "PWM GPIO on ESP8266: 0, 2, 4, 5, 12, 13, 14, 15\n"
        "GPIO16 does NOT support PWM!\n\n"
        "Wiring:\n"
        "  Orange (signal) -> D1 (GPIO5) or other PWM GPIO\n"
        "  Red    (VCC)    -> 5V (external supply preferred)\n"
        "  Brown  (GND)    -> GND (common with ESP8266)\n\n"
        "Parameters:\n"
        "  PWM frequency: 50 Hz (standard for servos)\n"
        "  Angle: 0–180 degrees\n"
        "  SG90: compact, up to 180°, torque ~1.8 kg/cm\n"
        "  MG90S: metal gears, more durable\n\n"
        "Example:\n"
        "  from machine import Pin\n"
        "  from servo import Servo\n"
        "  s = Servo(Pin(5))\n"
        "  s.write_angle(0)     # minimum\n"
        "  s.write_angle(90)    # centre (neutral)\n"
        "  s.write_angle(180)   # maximum\n"
        "  s.detach()           # release signal",
    ),
    (
        "NeoPixel WS2812 (RGB лента)",
        "neopixel_helper.py",
        "Приводы / Actuators",
        "━━━ WS2812 / WS2812B RGB и RGBW LED лента ━━━\n\n"
        "Встроенный модуль neopixel уже есть в MicroPython!\n\n"
        "Подключение (ESP8266):\n"
        "  DIN  -> D4 (GPIO2) рекомендуется\n"
        "  VCC  -> 5V (полоска / лента!)   GND -> GND (общий)\n"
        "  ВАЖНО: данные работают на 3.3В, но питание ленты 5В\n\n"
        "Базовое использование (встроенный модуль):\n"
        "  from machine import Pin\n"
        "  from neopixel import NeoPixel\n"
        "  np = NeoPixel(Pin(2), 8)  # 8 светодиодов\n"
        "  np[0] = (255, 0,   0)     # красный\n"
        "  np[1] = (0,   255, 0)     # зелёный\n"
        "  np[2] = (0,   0,   255)   # синий\n"
        "  np[3] = (255, 255, 255)   # белый\n"
        "  np.write()                # применить!\n\n"
        "Файл neopixel_helper.py — эффекты:\n"
        "  from neopixel_helper import rainbow_cycle, color_wipe, clear\n"
        "  color_wipe(np, (255, 0, 0))  # заполнить красным\n"
        "  rainbow_cycle(np)            # радуга\n"
        "  clear(np)                    # выключить всё",
        "━━━ WS2812 / WS2812B RGB and RGBW LED strip ━━━\n\n"
        "The neopixel module is already built into MicroPython!\n\n"
        "Wiring (ESP8266):\n"
        "  DIN  -> D4 (GPIO2) recommended\n"
        "  VCC  -> 5V (strip!)   GND -> GND (common)\n"
        "  NOTE: data signal is 3.3V, strip power is 5V\n\n"
        "Basic usage (built-in module):\n"
        "  from machine import Pin\n"
        "  from neopixel import NeoPixel\n"
        "  np = NeoPixel(Pin(2), 8)  # 8 LEDs\n"
        "  np[0] = (255, 0,   0)     # red\n"
        "  np[1] = (0,   255, 0)     # green\n"
        "  np[2] = (0,   0,   255)   # blue\n"
        "  np[3] = (255, 255, 255)   # white\n"
        "  np.write()                # apply!\n\n"
        "neopixel_helper.py — effects:\n"
        "  from neopixel_helper import rainbow_cycle, color_wipe, clear\n"
        "  color_wipe(np, (255, 0, 0))  # fill with red\n"
        "  rainbow_cycle(np)            # rainbow\n"
        "  clear(np)                    # turn off all",
    ),
    (
        "Шаговый мотор 28BYJ-48 (ULN2003)",
        "stepper.py",
        "Приводы / Actuators",
        "━━━ Шаговый мотор 28BYJ-48 через драйвер ULN2003 ━━━\n\n"
        "Самый распространённый шаговый мотор в Arduino-наборах.\n\n"
        "Подключение (ESP8266):\n"
        "  IN1 -> D1 (GPIO5)    IN2 -> D2 (GPIO4)\n"
        "  IN3 -> D3 (GPIO0)    IN4 -> D4 (GPIO2)\n"
        "  VCC -> 5V (внешний!) GND -> GND (общий с ESP8266)\n\n"
        "ВАЖНО: Питай мотор от отдельного 5V, не от ESP8266!\n"
        "ESP8266 не может обеспечить достаточный ток.\n\n"
        "Характеристики:\n"
        "  • 4096 шагов на 1 полный оборот (полушаговый режим)\n"
        "  • Передаточное число: 1:64\n"
        "  • Момент: достаточно для лёгких механизмов\n\n"
        "Пример:\n"
        "  from stepper import Stepper\n"
        "  m = Stepper(5, 4, 0, 2)    # IN1..IN4\n"
        "  m.step(2048)               # пол-оборота вправо\n"
        "  m.step(-2048)              # пол-оборота влево\n"
        "  m.angle(360)               # 1 полный оборот\n"
        "  m.off()                    # отключить обмотки",
        "━━━ 28BYJ-48 stepper motor via ULN2003 driver ━━━\n\n"
        "The most common stepper motor in Arduino starter kits.\n\n"
        "Wiring (ESP8266):\n"
        "  IN1 -> D1 (GPIO5)    IN2 -> D2 (GPIO4)\n"
        "  IN3 -> D3 (GPIO0)    IN4 -> D4 (GPIO2)\n"
        "  VCC -> 5V (external!) GND -> GND (common)\n\n"
        "IMPORTANT: Power the motor from external 5V!\n"
        "ESP8266 cannot supply enough current.\n\n"
        "Specs:\n"
        "  • 4096 steps per full revolution (half-step mode)\n"
        "  • Gear ratio: 1:64\n"
        "  • Suitable for lightweight mechanisms\n\n"
        "Example:\n"
        "  from stepper import Stepper\n"
        "  m = Stepper(5, 4, 0, 2)    # IN1..IN4\n"
        "  m.step(2048)               # half turn clockwise\n"
        "  m.step(-2048)              # half turn counter-CW\n"
        "  m.angle(360)               # 1 full revolution\n"
        "  m.off()                    # de-energise coils",
    ),
    (
        "ESP8266 I2C LCD",
        "esp8266_i2c_lcd.py",
        "Дисплеи / Displays",
        "━━━ LCD 1602/2004 для ESP8266 через I2C ━━━\n\n"
        "Библиотека для символьных LCD по I2C.\n"
        "Обычно используется вместе с lcd_api.py.\n\n"
        "Подключение:\n"
        "  SDA -> D2 (GPIO4)\n"
        "  SCL -> D1 (GPIO5)\n"
        "  VCC -> 5V   GND -> GND\n\n"
        "Импорт:\n"
        "  from esp8266_i2c_lcd import I2cLcd",
        "━━━ ESP8266 I2C LCD 1602/2004 driver ━━━\n\n"
        "Character LCD library for ESP8266 over I2C.\n"
        "Usually used together with lcd_api.py.\n\n"
        "Wiring:\n"
        "  SDA -> D2 (GPIO4)\n"
        "  SCL -> D1 (GPIO5)\n"
        "  VCC -> 5V   GND -> GND\n\n"
        "Import:\n"
        "  from esp8266_i2c_lcd import I2cLcd",
    ),
    (
        "Font",
        "font.py",
        "Дисплеи / Displays",
        "━━━ Шрифт для TFT/ST7735 ━━━\n\n"
        "Модуль шрифта для вывода текста на TFT-дисплеи.\n"
        "Обычно нужен вместе с tft.py и st7735.py.\n\n"
        "Можно установить как .py или .mpy.",
        "━━━ Font module for TFT/ST7735 ━━━\n\n"
        "Font module used for text rendering on TFT displays.\n"
        "Usually used together with tft.py and st7735.py.\n\n"
        "Can be installed as either .py or .mpy.",
    ),
    (
        "ST7735",
        "st7735.py",
        "Дисплеи / Displays",
        "━━━ Драйвер цветного TFT-дисплея ST7735 ━━━\n\n"
        "Драйвер для SPI TFT-экрана.\n"
        "Часто используется вместе с tft.py и font.py.\n\n"
        "Можно установить как .py или .mpy.",
        "━━━ ST7735 color TFT display driver ━━━\n\n"
        "Driver for SPI TFT displays.\n"
        "Often used together with tft.py and font.py.\n\n"
        "Can be installed as either .py or .mpy.",
    ),
    (
        "TFT Core",
        "tft.py",
        "Дисплеи / Displays",
        "━━━ Базовый модуль TFT-графики ━━━\n\n"
        "Библиотека для работы с TFT-дисплеями и графикой.\n"
        "Обычно используется вместе с st7735.py и font.py.\n\n"
        "Можно установить как .py или .mpy.",
        "━━━ Core TFT graphics module ━━━\n\n"
        "Library for TFT display graphics.\n"
        "Usually used together with st7735.py and font.py.\n\n"
        "Can be installed as either .py or .mpy.",
    ),
]


def _libs_basedir() -> str:
    return os.path.join(os.fspath(package_root()), "resources", "micropython_libs")


def _library_variants(filename: str) -> dict[str, str]:
    """Return available .py/.mpy variants for a library."""
    stem, _ = os.path.splitext(filename)
    basedir = _libs_basedir()
    variants: dict[str, str] = {}
    for ext in (".py", ".mpy"):
        path = os.path.join(basedir, stem + ext)
        if os.path.isfile(path):
            variants[ext.lstrip(".")] = path
    return variants


def _format_status(path: Optional[str]) -> str:
    """Return a localized size label for a format."""
    if not path:
        return "?"
    try:
        size = os.path.getsize(path)
    except OSError:
        return "?"
    return tr("libmgr_format_size", size=size)


# ---------------------------------------------------------------------------
# Dialog
# ---------------------------------------------------------------------------

class LibraryManagerDialog(QDialog):
    install_requested = pyqtSignal(str, bytes)      # (remote_path, data)
    open_file_requested = pyqtSignal(str)            # local path → open in editor

    def __init__(self, device_connected: bool = False, parent=None) -> None:
        super().__init__(parent)
        self._device_connected = device_connected
        self.setWindowTitle(tr("libmgr_title"))
        self.setMinimumSize(700, 480)
        self._build_ui()
        self._populate()

    # ------------------------------------------------------------------
    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(8)

        header = QLabel(tr("libmgr_header"))
        header.setWordWrap(True)
        header.setStyleSheet("font-size: 13px;")
        layout.addWidget(header)

        splitter = QSplitter(Qt.Horizontal)

        # Left — tree
        self._tree = QTreeWidget()
        self._tree.setHeaderHidden(True)
        self._tree.setMinimumWidth(260)
        self._tree.itemSelectionChanged.connect(self._on_select)
        splitter.addWidget(self._tree)

        # Right — description
        right = QWidget()
        right_layout = QVBoxLayout(right)
        right_layout.setContentsMargins(4, 0, 0, 0)

        self._desc = QTextEdit()
        self._desc.setReadOnly(True)
        self._desc.setFontFamily("Consolas, Courier New, monospace")
        right_layout.addWidget(self._desc)

        btn_row = QHBoxLayout()
        self._btn_view = QPushButton(tr("libmgr_view"))
        self._btn_view.setEnabled(False)
        self._btn_view.clicked.connect(self._view_file)

        self._btn_install = QPushButton(tr("libmgr_install_device"))
        self._btn_install.setEnabled(False)
        self._btn_install.setToolTip(tr("libmgr_install_tip"))
        self._btn_install.clicked.connect(self._install_to_device)

        btn_close = QPushButton(tr("port_btn_cancel"))
        btn_close.clicked.connect(self.accept)

        btn_row.addWidget(self._btn_view)
        btn_row.addWidget(self._btn_install)
        btn_row.addStretch()
        btn_row.addWidget(btn_close)
        right_layout.addLayout(btn_row)

        splitter.addWidget(right)
        splitter.setSizes([260, 430])
        layout.addWidget(splitter)

    # ------------------------------------------------------------------
    def _populate(self) -> None:
        categories: dict[str, QTreeWidgetItem] = {}
        for name, filename, category, desc_ru, desc_en in _LIBS:
            if category not in categories:
                cat_item = QTreeWidgetItem([category])
                cat_item.setFlags(Qt.ItemIsEnabled)
                font = cat_item.font(0)
                font.setBold(True)
                cat_item.setFont(0, font)
                self._tree.addTopLevelItem(cat_item)
                categories[category] = cat_item
            lib_item = QTreeWidgetItem([name])
            lib_item.setData(0, Qt.UserRole, (filename, desc_ru, desc_en))
            categories[category].addChild(lib_item)
        self._tree.expandAll()

    # ------------------------------------------------------------------
    def _on_select(self) -> None:
        items = self._tree.selectedItems()
        if not items:
            self._desc.clear()
            self._btn_view.setEnabled(False)
            self._btn_install.setEnabled(False)
            return
        item = items[0]
        data = item.data(0, Qt.UserRole)
        if data is None:
            self._desc.clear()
            self._btn_view.setEnabled(False)
            self._btn_install.setEnabled(False)
            return
        filename, desc_ru, desc_en = data
        from ..core.translations import get_language
        desc = desc_ru if get_language() == "ru" else desc_en
        variants = _library_variants(filename)
        formats = ", ".join(f".{fmt}" for fmt in variants) or "—"
        self._desc.setPlainText(
            f"📄 {filename}\n{tr('libmgr_formats_line', formats=formats)}\n\n{desc}"
        )
        lib_path = os.path.join(_libs_basedir(), filename)
        exists = os.path.isfile(lib_path)
        self._btn_view.setEnabled(exists)
        self._btn_install.setEnabled(bool(variants) and self._device_connected)

    # ------------------------------------------------------------------
    def _view_file(self) -> None:
        items = self._tree.selectedItems()
        if not items:
            return
        data = items[0].data(0, Qt.UserRole)
        if data is None:
            return
        filename, _, _ = data
        lib_path = os.path.join(_libs_basedir(), filename)
        if os.path.isfile(lib_path):
            self.open_file_requested.emit(lib_path)

    def _install_to_device(self) -> None:
        items = self._tree.selectedItems()
        if not items:
            return
        item = items[0]
        data = item.data(0, Qt.UserRole)
        if data is None:
            return
        display_name = item.text(0)
        filename, _, _ = data
        stem, _ = os.path.splitext(filename)
        py_path = os.path.join(_libs_basedir(), stem + ".py")
        mpy_path = os.path.join(_libs_basedir(), stem + ".mpy")

        chooser = QMessageBox(self)
        chooser.setWindowTitle(tr("libmgr_format_title"))
        chooser.setIcon(QMessageBox.Question)
        chooser.setText(tr("libmgr_format_msg", name=display_name))
        chooser.setInformativeText(
            tr(
                "libmgr_format_hint",
                py_status=_format_status(py_path if os.path.isfile(py_path) else None),
                mpy_status=_format_status(mpy_path if os.path.isfile(mpy_path) else None),
            )
        )
        btn_py = chooser.addButton(tr("libmgr_format_py"), QMessageBox.AcceptRole)
        btn_mpy = chooser.addButton(tr("libmgr_format_mpy"), QMessageBox.AcceptRole)
        btn_cancel = chooser.addButton(tr("port_btn_cancel"), QMessageBox.RejectRole)

        preferred_format = os.path.splitext(filename)[1].lstrip(".")
        default_button = btn_py if preferred_format == "py" else btn_mpy
        chooser.setDefaultButton(default_button)
        chooser.setEscapeButton(btn_cancel)
        chooser.exec_()

        chosen_button = chooser.clickedButton()
        if chosen_button is btn_py:
            lib_path = py_path
        elif chosen_button is btn_mpy:
            lib_path = mpy_path
        else:
            return

        if not os.path.isfile(lib_path):
            QMessageBox.warning(self, tr("editor_error"),
                                f"File not found: {lib_path}")
            return
        try:
            with open(lib_path, "rb") as f:
                data_bytes = f.read()
        except OSError as exc:
            QMessageBox.critical(self, tr("editor_error"), str(exc))
            return
        install_name = os.path.basename(lib_path)
        # Upload to /lib/<filename> on device
        remote = "/lib/" + install_name
        self.install_requested.emit(remote, data_bytes)
        QMessageBox.information(
            self,
            tr("libmgr_install_ok_title"),
            tr("libmgr_install_ok_msg", name=install_name, path=remote),
        )
