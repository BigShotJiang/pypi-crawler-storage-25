from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any

from .paths import user_data_path, user_log_path

_STATUS_PATH = user_data_path("self_update_status.json")
_LOG_PATH = user_log_path("self_update.log")

_CHILD_CODE = r"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time

pid = int(sys.argv[1])
python_exe = sys.argv[2]
package_name = sys.argv[3]
module_name = sys.argv[4]
status_path = sys.argv[5]
log_path = sys.argv[6]
target_version = sys.argv[7]
install_target = package_name if not target_version else package_name + "==" + target_version


def _pid_exists(value: int) -> bool:
    if value <= 0:
        return False
    try:
        os.kill(value, 0)
    except PermissionError:
        return True
    except OSError:
        return False
    return True


def _popen_kwargs() -> dict[str, object]:
    options: dict[str, object] = {"close_fds": True}
    if os.name == "nt":
        flags = 0
        flags |= getattr(subprocess, "DETACHED_PROCESS", 0)
        flags |= getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
        flags |= getattr(subprocess, "CREATE_NO_WINDOW", 0)
        if flags:
            options["creationflags"] = flags
    else:
        options["start_new_session"] = True
    return options


def _write_result(payload: dict[str, object]) -> None:
    status_dir = os.path.dirname(status_path)
    if status_dir:
        os.makedirs(status_dir, exist_ok=True)
    with open(status_path, "w", encoding="utf-8") as fh:
        json.dump(payload, fh, indent=2, ensure_ascii=False)


def _append_log(title: str, stdout_text: str, stderr_text: str) -> None:
    log_dir = os.path.dirname(log_path)
    if log_dir:
        os.makedirs(log_dir, exist_ok=True)
    with open(log_path, "a", encoding="utf-8") as fh:
        fh.write("\n=== " + title + " ===\n")
        if target_version:
            fh.write("Target version: " + target_version + "\n")
        fh.write("Command: " + python_exe + " -m pip install --upgrade " + install_target + "\n")
        if stdout_text.strip():
            fh.write("\n[stdout]\n" + stdout_text + "\n")
        if stderr_text.strip():
            fh.write("\n[stderr]\n" + stderr_text + "\n")


for _ in range(240):
    if not _pid_exists(pid):
        break
    time.sleep(0.5)

command = [
    python_exe,
    "-m",
    "pip",
    "install",
    "--upgrade",
    "--disable-pip-version-check",
    "--no-input",
    install_target,
]

completed = subprocess.run(
    command,
    capture_output=True,
    text=True,
    encoding="utf-8",
    errors="replace",
)

stdout_tail = completed.stdout[-4000:]
stderr_tail = completed.stderr[-4000:]
payload = {
    "ok": completed.returncode == 0,
    "returncode": completed.returncode,
    "target_version": target_version,
    "stdout": stdout_tail,
    "stderr": stderr_tail,
}
_write_result(payload)
_append_log("self-update", stdout_tail, stderr_tail)

subprocess.Popen([python_exe, "-m", module_name], **_popen_kwargs())
"""


def update_status_path() -> Path:
    return _STATUS_PATH


def update_log_path() -> Path:
    return _LOG_PATH


def read_update_status() -> dict[str, Any] | None:
    if not _STATUS_PATH.is_file():
        return None
    try:
        with open(_STATUS_PATH, "r", encoding="utf-8") as fh:
            data = json.load(fh)
    except (OSError, json.JSONDecodeError):
        return None
    return data if isinstance(data, dict) else None


def clear_update_status() -> None:
    try:
        _STATUS_PATH.unlink()
    except FileNotFoundError:
        pass
    except OSError:
        pass


def launch_self_update(
    package_name: str = "boardypy",
    module_name: str = "boardypy",
    target_version: str = "",
) -> None:
    clear_update_status()
    args = [
        sys.executable,
        "-c",
        _CHILD_CODE,
        str(os.getpid()),
        sys.executable,
        package_name,
        module_name,
        os.fspath(_STATUS_PATH),
        os.fspath(_LOG_PATH),
        target_version,
    ]

    kwargs: dict[str, Any] = {"close_fds": True}
    if os.name == "nt":
        flags = 0
        flags |= getattr(subprocess, "DETACHED_PROCESS", 0)
        flags |= getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
        flags |= getattr(subprocess, "CREATE_NO_WINDOW", 0)
        if flags:
            kwargs["creationflags"] = flags
    else:
        kwargs["start_new_session"] = True

    subprocess.Popen(args, **kwargs)
