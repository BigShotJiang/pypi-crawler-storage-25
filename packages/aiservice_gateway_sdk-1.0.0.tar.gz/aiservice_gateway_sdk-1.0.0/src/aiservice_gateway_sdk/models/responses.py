from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from datetime import datetime


class UsageInfo(BaseModel):
    prompt_tokens: int = Field(default=0, description="提示词token数")
    completion_tokens: int = Field(default=0, description="生成token数")
    total_tokens: int = Field(default=0, description="总token数")


class TextGenerateResponse(BaseModel):
    text: str = Field(..., description="生成的文本")
    model: str = Field(..., description="使用的模型")
    usage: UsageInfo = Field(default_factory=UsageInfo, description="token使用量")
    finish_reason: Optional[str] = Field(default=None, description="结束原因")
    request_id: Optional[str] = Field(default=None, description="请求ID")
    provider: str = Field(default="unknown", description="服务商")


class ImageUrl(BaseModel):
    url: str = Field(..., description="图像URL")
    revised_prompt: Optional[str] = Field(default=None, description="修订后的提示词")


class ImageGenerateResponse(BaseModel):
    image_urls: List[ImageUrl] = Field(..., description="生成的图像URL列表")
    model: str = Field(..., description="使用的模型")
    request_id: Optional[str] = Field(default=None, description="请求ID")
    provider: str = Field(default="unknown", description="服务商")


class SpeechRecognizeResponse(BaseModel):
    text: str = Field(..., description="识别的文本")
    language: Optional[str] = Field(default=None, description="检测到的语言")
    duration: Optional[float] = Field(default=None, description="音频时长(秒)")
    model: str = Field(..., description="使用的模型")
    request_id: Optional[str] = Field(default=None, description="请求ID")
    provider: str = Field(default="unknown", description="服务商")


class SpeechSynthesizeResponse(BaseModel):
    audio: bytes = Field(..., description="合成的音频数据")
    model: str = Field(..., description="使用的模型")
    duration: Optional[float] = Field(default=None, description="音频时长(秒)")
    request_id: Optional[str] = Field(default=None, description="请求ID")
    provider: str = Field(default="unknown", description="服务商")


class ModelInfo(BaseModel):
    id: str = Field(..., description="模型ID")
    name: str = Field(..., description="模型名称")
    provider: str = Field(..., description="所属厂商")
    capabilities: List[str] = Field(default_factory=list, description="支持的能力: text/image/audio")


class ModelListResponse(BaseModel):
    models: List[ModelInfo] = Field(..., description="模型列表")
    provider: str = Field(default="unknown", description="服务商")


class ErrorResponse(BaseModel):
    error: str = Field(..., description="错误信息")
    code: Optional[str] = Field(default=None, description="错误代码")
    request_id: Optional[str] = Field(default=None, description="请求ID")
    provider: str = Field(default="unknown", description="服务商")
