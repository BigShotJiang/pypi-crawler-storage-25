from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field


class TextGenerateRequest(BaseModel):
    prompt: str = Field(..., description="输入提示词")
    model: str = Field(default="Qwen/Qwen2.5-7B-Instruct", description="模型名称")
    max_tokens: int = Field(default=1000, ge=1, le=4096, description="最大生成token数")
    temperature: float = Field(default=0.7, ge=0.0, le=2.0, description="采样温度")
    top_p: float = Field(default=0.9, ge=0.0, le=1.0, description="核采样概率")
    stream: bool = Field(default=False, description="是否使用流式输出")
    stop: Optional[List[str]] = Field(default=None, description="停止词列表")
    extra: Dict[str, Any] = Field(default_factory=dict, description="额外参数")


class ImageGenerateRequest(BaseModel):
    prompt: str = Field(..., description="图像描述")
    model: str = Field(default="dall-e-3", description="模型名称")
    size: str = Field(default="1024x1024", description="图像尺寸")
    n: int = Field(default=1, ge=1, le=10, description="生成数量")
    quality: str = Field(default="standard", description="图像质量: standard/hd")
    style: str = Field(default="vivid", description="图像风格: vivid/natural")
    extra: Dict[str, Any] = Field(default_factory=dict, description="额外参数")


class SpeechRecognizeRequest(BaseModel):
    audio: bytes = Field(..., description="音频数据")
    model: str = Field(default="whisper-1", description="模型名称")
    language: Optional[str] = Field(default=None, description="音频语言")
    prompt: Optional[str] = Field(default=None, description="可选提示词")
    response_format: str = Field(default="json", description="响应格式")
    temperature: float = Field(default=0.0, ge=0.0, le=1.0, description="采样温度")
    extra: Dict[str, Any] = Field(default_factory=dict, description="额外参数")


class SpeechSynthesizeRequest(BaseModel):
    text: str = Field(..., description="要合成的文本")
    model: str = Field(default="tts-1", description="模型名称")
    voice: str = Field(default="alloy", description="音色")
    response_format: str = Field(default="mp3", description="音频格式")
    speed: float = Field(default=1.0, ge=0.25, le=4.0, description="播放速度")
    extra: Dict[str, Any] = Field(default_factory=dict, description="额外参数")
