import time
from typing import Dict, Any, Optional
import requests
from ..config import APIConfig
from ..exceptions import (
    APIError,
    AuthenticationError,
    RateLimitError,
    InvalidRequestError,
    NetworkError,
    TimeoutError,
)
from ..models.requests import TextGenerateRequest
from ..models.responses import TextGenerateResponse, UsageInfo


class SiliconProvider:
    """硅基流动AI服务提供商"""

    DEFAULT_MODELS = {
        "text": "Qwen/Qwen2.5-7B-Instruct",
        "image": "dall-e-3",
        "speech_recognize": "whisper-1",
        "speech_synthesize": "tts-1",
    }

    SUPPORTED_TEXT_MODELS = [
        "Qwen/Qwen2.5-7B-Instruct",
        "Qwen/Qwen2.5-14B-Instruct",
        "Qwen/Qwen2.5-72B-Instruct",
        "Pro/Qwen/Qwen2.5-7B-Instruct",
        "Pro/Qwen/Qwen2.5-14B-Instruct",
        "deepseek-ai/DeepSeek-V2.5",
        "THUDM/GLM-4-9B-Chat",
    ]

    def __init__(self, config: APIConfig):
        self.config = config
        self.base_url = config.base_url.rstrip("/")
        self.api_key = config.api_key
        self.timeout = config.timeout
        self.max_retries = config.max_retries
        self.retry_delay = config.retry_delay

    @property
    def provider_name(self) -> str:
        return "silicon"

    def _make_request(
        self,
        method: str,
        endpoint: str,
        data: Dict[str, Any] = None,
        files: Dict[str, Any] = None,
    ) -> Dict[str, Any]:
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

        for attempt in range(self.max_retries):
            try:
                response = requests.request(
                    method=method,
                    url=url,
                    json=data,
                    files=files,
                    headers=headers if not files else {"Authorization": f"Bearer {self.api_key}"},
                    timeout=self.timeout,
                )

                if response.status_code == 200:
                    return response.json()
                elif response.status_code == 401:
                    raise AuthenticationError("Invalid API key")
                elif response.status_code == 429:
                    raise RateLimitError("Rate limit exceeded")
                elif response.status_code == 400:
                    error_data = response.json() if response.content else {}
                    raise InvalidRequestError(
                        error_data.get("message", "Invalid request"),
                        validation_errors=error_data,
                    )
                else:
                    raise APIError(
                        f"API request failed: {response.text}",
                        status_code=response.status_code,
                        response=response.json() if response.content else None,
                    )

            except requests.exceptions.Timeout:
                if attempt < self.max_retries - 1:
                    time.sleep(self.retry_delay)
                    continue
                raise TimeoutError(f"Request to {url} timed out")
            except requests.exceptions.RequestException as e:
                if attempt < self.max_retries - 1:
                    time.sleep(self.retry_delay)
                    continue
                raise NetworkError(f"Network request failed: {str(e)}")

        raise APIError("Max retries exceeded")

    def text_generate(self, request: TextGenerateRequest) -> TextGenerateResponse:
        endpoint = "/chat/completions"

        payload = {
            "model": request.model or self.DEFAULT_MODELS["text"],
            "messages": [{"role": "user", "content": request.prompt}],
            "max_tokens": request.max_tokens,
            "temperature": request.temperature,
            "top_p": request.top_p,
            "stream": request.stream,
        }

        if request.stop:
            payload["stop"] = request.stop

        payload.update(request.extra)

        response_data = self._make_request("POST", endpoint, data=payload)

        choices = response_data.get("choices", [])
        text = ""
        finish_reason = None

        if choices:
            choice = choices[0]
            message = choice.get("message", {})
            text = message.get("content", "")
            finish_reason = choice.get("finish_reason")

        usage_data = response_data.get("usage", {})
        usage = UsageInfo(
            prompt_tokens=usage_data.get("prompt_tokens", 0),
            completion_tokens=usage_data.get("completion_tokens", 0),
            total_tokens=usage_data.get("total_tokens", 0),
        )

        return TextGenerateResponse(
            text=text,
            model=response_data.get("model", request.model),
            usage=usage,
            finish_reason=finish_reason,
            request_id=response_data.get("id"),
            provider=self.provider_name,
        )

    def image_generate(self, request) -> "ImageGenerateResponse":
        from ..models.responses import ImageGenerateResponse, ImageUrl

        endpoint = "/images/generations"

        payload = {
            "model": request.model or self.DEFAULT_MODELS["image"],
            "prompt": request.prompt,
            "size": request.size,
            "n": request.n,
        }

        if hasattr(request, "quality"):
            payload["quality"] = request.quality
        if hasattr(request, "style"):
            payload["style"] = request.style

        payload.update(request.extra)

        response_data = self._make_request("POST", endpoint, data=payload)

        image_urls = []
        for item in response_data.get("data", []):
            image_urls.append(
                ImageUrl(
                    url=item.get("url", ""),
                    revised_prompt=item.get("revised_prompt"),
                )
            )

        return ImageGenerateResponse(
            image_urls=image_urls,
            model=response_data.get("model", request.model),
            request_id=response_data.get("id"),
            provider=self.provider_name,
        )

    def speech_recognize(self, request) -> "SpeechRecognizeResponse":
        from ..models.responses import SpeechRecognizeResponse

        endpoint = "/audio/transcriptions"

        files = {"file": ("audio.wav", request.audio, "audio/wav")}
        data = {"model": request.model or self.DEFAULT_MODELS["speech_recognize"]}

        if request.language:
            data["language"] = request.language
        if request.prompt:
            data["prompt"] = request.prompt
        if request.response_format:
            data["response_format"] = request.response_format
        if request.temperature:
            data["temperature"] = request.temperature

        headers = {"Authorization": f"Bearer {self.api_key}"}

        try:
            response = requests.post(
                f"{self.base_url}/{endpoint.lstrip('/')}",
                files=files,
                data=data,
                headers=headers,
                timeout=self.timeout,
            )
        except requests.exceptions.RequestException as e:
            raise NetworkError(f"Speech recognition request failed: {str(e)}")

        if response.status_code != 200:
            raise APIError(
                f"Speech recognition failed: {response.text}",
                status_code=response.status_code,
            )

        result = response.json()

        return SpeechRecognizeResponse(
            text=result.get("text", ""),
            language=result.get("language"),
            duration=result.get("duration"),
            model=request.model,
            request_id=response.headers.get("x-request-id"),
            provider=self.provider_name,
        )

    def speech_synthesize(self, request) -> "SpeechSynthesizeResponse":
        from ..models.responses import SpeechSynthesizeResponse

        endpoint = "/audio/speech"

        payload = {
            "model": request.model or self.DEFAULT_MODELS["speech_synthesize"],
            "input": request.text,
            "voice": request.voice,
            "response_format": request.response_format,
            "speed": request.speed,
        }

        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

        try:
            response = requests.post(
                f"{self.base_url}/{endpoint.lstrip('/')}",
                json=payload,
                headers=headers,
                timeout=self.timeout,
            )
        except requests.exceptions.RequestException as e:
            raise NetworkError(f"Speech synthesis request failed: {str(e)}")

        if response.status_code != 200:
            raise APIError(
                f"Speech synthesis failed: {response.text}",
                status_code=response.status_code,
            )

        return SpeechSynthesizeResponse(
            audio=response.content,
            model=request.model,
            duration=None,
            request_id=response.headers.get("x-request-id"),
            provider=self.provider_name,
        )

    def get_supported_models(self) -> list:
        return self.SUPPORTED_TEXT_MODELS
