from abc import ABC, abstractmethod
from typing import Dict, Any, Optional
from ..config import APIConfig
from ..models.requests import (
    TextGenerateRequest,
    ImageGenerateRequest,
    SpeechRecognizeRequest,
    SpeechSynthesizeRequest,
)
from ..models.responses import (
    TextGenerateResponse,
    ImageGenerateResponse,
    SpeechRecognizeResponse,
    SpeechSynthesizeResponse,
    ModelListResponse,
)


class BaseProvider(ABC):
    """AI服务厂商抽象基类"""

    def __init__(self, config: APIConfig):
        self.config = config

    @property
    @abstractmethod
    def provider_name(self) -> str:
        """厂商名称"""
        pass

    @abstractmethod
    def text_generate(self, request: TextGenerateRequest) -> TextGenerateResponse:
        """文本生成"""
        pass

    @abstractmethod
    def image_generate(self, request: ImageGenerateRequest) -> ImageGenerateResponse:
        """图像生成"""
        pass

    @abstractmethod
    def speech_recognize(self, request: SpeechRecognizeRequest) -> SpeechRecognizeResponse:
        """语音识别"""
        pass

    @abstractmethod
    def speech_synthesize(self, request: SpeechSynthesizeRequest) -> SpeechSynthesizeResponse:
        """语音合成"""
        pass

    def get_model_list(self) -> ModelListResponse:
        """获取支持的模型列表（可选实现）"""
        raise NotImplementedError(f"{self.provider_name} does not support model listing")

    def health_check(self) -> bool:
        """健康检查（可选实现）"""
        raise NotImplementedError(f"{self.provider_name} does not support health check")
