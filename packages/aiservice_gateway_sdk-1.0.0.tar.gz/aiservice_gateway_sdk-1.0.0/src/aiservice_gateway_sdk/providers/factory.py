from typing import Dict, Type
from ..config import APIConfig, Config
from ..exceptions import ProviderNotFoundError
from .base import BaseProvider
from .silicon import SiliconProvider


class AIProviderFactory:
    """AI服务厂商工厂类"""

    _providers: Dict[str, Type[BaseProvider]] = {
        "silicon": SiliconProvider,
    }

    @classmethod
    def register_provider(cls, name: str, provider_class: Type[BaseProvider]) -> None:
        cls._providers[name] = provider_class

    @classmethod
    def create(cls, config: Config) -> BaseProvider:
        provider_name = config.provider.lower()

        if provider_name not in cls._providers:
            raise ProviderNotFoundError(provider_name)

        provider_config = config.to_provider_config()
        return cls._providers[provider_name](provider_config)

    @classmethod
    def get_supported_providers(cls) -> list:
        return list(cls._providers.keys())
