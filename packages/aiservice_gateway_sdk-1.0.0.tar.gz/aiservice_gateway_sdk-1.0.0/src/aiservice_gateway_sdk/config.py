import os
from typing import Optional, Dict, Any
from pydantic import BaseModel, Field


class APIConfig(BaseModel):
    base_url: str = Field(default="https://api.siliconflow.cn/v1", description="API基础URL")
    api_key: str = Field(default="", description="API密钥")
    timeout: int = Field(default=30, description="请求超时时间（秒）")
    max_retries: int = Field(default=3, description="最大重试次数")
    retry_delay: float = Field(default=1.0, description="重试延迟（秒）")


class SiliconConfig(APIConfig):
    base_url: str = "https://api.siliconflow.cn/v1"


class OpenAIConfig(APIConfig):
    base_url: str = "https://api.openai.com/v1"


class Config(BaseModel):
    provider: str = Field(default="silicon", description="AI服务厂商: silicon, openai")
    api_key: Optional[str] = Field(default=None, description="API密钥")
    base_url: Optional[str] = Field(default=None, description="自定义API基础URL")
    timeout: int = Field(default=30, description="请求超时时间（秒）")
    max_retries: int = Field(default=3, description="最大重试次数")
    retry_delay: float = Field(default=1.0, description="重试延迟（秒）")
    extra: Dict[str, Any] = Field(default_factory=dict, description="额外参数")

    @classmethod
    def from_env(cls, provider: str = "silicon") -> "Config":
        env_key_map = {
            "silicon": "SILICON_API_KEY",
            "openai": "OPENAI_API_KEY",
        }
        api_key = os.environ.get(env_key_map.get(provider, "API_KEY"), "")
        return cls(provider=provider, api_key=api_key)

    def to_provider_config(self) -> APIConfig:
        if self.provider == "silicon":
            base_url = self.base_url or "https://api.siliconflow.cn/v1"
        elif self.provider == "openai":
            base_url = self.base_url or "https://api.openai.com/v1"
        else:
            base_url = self.base_url or ""

        return APIConfig(
            base_url=base_url,
            api_key=self.api_key or "",
            timeout=self.timeout,
            max_retries=self.max_retries,
            retry_delay=self.retry_delay,
        )


class ProviderConfig(BaseModel):
    silicon: SiliconConfig = Field(default_factory=SiliconConfig)
    openai: OpenAIConfig = Field(default_factory=OpenAIConfig)
