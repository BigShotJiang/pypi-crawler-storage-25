from typing import Any, Dict, Optional
import hashlib
import hmac
import time


def generate_signature(secret: str, message: str) -> str:
    return hmac.new(
        secret.encode("utf-8"),
        message.encode("utf-8"),
        hashlib.sha256
    ).hexdigest()


def generate_request_id() -> str:
    return f"{int(time.time() * 1000)}-{hashlib.uuid4().hex[:8]}"


def merge_dicts(*dicts: Dict[str, Any]) -> Dict[str, Any]:
    result = {}
    for d in dicts:
        if d:
            result.update(d)
    return result


def validate_api_key(api_key: str) -> bool:
    if not api_key:
        return False
    if len(api_key) < 10:
        return False
    return True
