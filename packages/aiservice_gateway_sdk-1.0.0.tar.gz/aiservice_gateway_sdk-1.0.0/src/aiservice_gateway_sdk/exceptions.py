class AIServiceGatewayError(Exception):
    """AI服务网关基础异常类"""

    def __init__(self, message: str, code: str = None, details: dict = None):
        self.message = message
        self.code = code
        self.details = details or {}
        super().__init__(self.message)


class APIError(AIServiceGatewayError):
    """API调用错误"""

    def __init__(self, message: str, status_code: int = None, response: dict = None):
        self.status_code = status_code
        self.response = response
        super().__init__(message, code="API_ERROR", details={"status_code": status_code, "response": response})


class AuthenticationError(APIError):
    """认证失败错误"""

    def __init__(self, message: str = "认证失败，请检查API Key是否正确"):
        super().__init__(message, status_code=401)
        self.code = "AUTHENTICATION_ERROR"


class RateLimitError(APIError):
    """请求频率超限错误"""

    def __init__(self, message: str = "请求频率超限，请稍后重试"):
        super().__init__(message, status_code=429)
        self.code = "RATE_LIMIT_ERROR"


class InvalidRequestError(AIServiceGatewayError):
    """无效请求错误"""

    def __init__(self, message: str, validation_errors: dict = None):
        super().__init__(message, code="INVALID_REQUEST", details={"validation_errors": validation_errors})


class ProviderNotFoundError(AIServiceGatewayError):
    """AI厂商未找到错误"""

    def __init__(self, provider: str):
        message = f"未支持的AI厂商: {provider}"
        super().__init__(message, code="PROVIDER_NOT_FOUND")
        self.provider = provider


class ModelNotFoundError(AIServiceGatewayError):
    """模型未找到错误"""

    def __init__(self, model: str, provider: str = None):
        message = f"未支持的模型: {model}"
        if provider:
            message = f"厂商 {provider} 未支持模型: {model}"
        super().__init__(message, code="MODEL_NOT_FOUND")
        self.model = model
        self.provider = provider


class NetworkError(AIServiceGatewayError):
    """网络错误"""

    def __init__(self, message: str = "网络请求失败，请检查网络连接"):
        super().__init__(message, code="NETWORK_ERROR")


class TimeoutError(AIServiceGatewayError):
    """请求超时错误"""

    def __init__(self, message: str = "请求超时，请稍后重试"):
        super().__init__(message, code="TIMEOUT_ERROR")


class CircuitBreakerError(AIServiceGatewayError):
    """熔断器触发错误"""

    def __init__(self, provider: str):
        message = f"服务商 {provider} 暂时不可用，熔断器已触发"
        super().__init__(message, code="CIRCUIT_BREAKER_ERROR")
        self.provider = provider
