import io
import json
from typing import Optional, Union
from .config import Config
from .exceptions import InvalidRequestError
from .providers.factory import AIProviderFactory
from .models.requests import (
    TextGenerateRequest,
    ImageGenerateRequest,
    SpeechRecognizeRequest,
    SpeechSynthesizeRequest,
)
from .models.responses import (
    TextGenerateResponse,
    ImageGenerateResponse,
    SpeechRecognizeResponse,
    SpeechSynthesizeResponse,
    ModelListResponse,
)


class AIServiceGatewayClient:
    """
    AI服务网关统一客户端

    使用示例:
        client = AIServiceGatewayClient(
            provider="silicon",
            api_key="your-api-key"
        )

        # 文本生成
        result = client.text.generate("你好，介绍下你自己")

        # 图像生成
        result = client.image.generate("一只可爱的橘猫")
    """

    def __init__(
        self,
        provider: str = "silicon",
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: int = 30,
        max_retries: int = 3,
        **kwargs,
    ):
        self.config = Config(
            provider=provider,
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
            extra=kwargs,
        )
        self._provider = AIProviderFactory.create(self.config)

        self._text = TextService(self._provider)
        self._image = ImageService(self._provider)
        self._audio = AudioService(self._provider)

    @property
    def text(self) -> "TextService":
        return self._text

    @property
    def image(self) -> "ImageService":
        return self._image

    @property
    def audio(self) -> "AudioService":
        return self._audio

    @property
    def provider_name(self) -> str:
        return self._provider.provider_name

    def health_check(self) -> bool:
        return self._provider.health_check()

    def get_supported_models(self) -> list:
        if hasattr(self._provider, "get_supported_models"):
            return self._provider.get_supported_models()
        return []


class TextService:
    """文本生成服务"""

    def __init__(self, provider):
        self._provider = provider

    def generate(
        self,
        prompt: str,
        model: str = "Qwen/Qwen2.5-7B-Instruct",
        max_tokens: int = 1000,
        temperature: float = 0.7,
        top_p: float = 0.9,
        stream: bool = False,
        stop: Optional[list] = None,
        **kwargs,
    ) -> TextGenerateResponse:
        request = TextGenerateRequest(
            prompt=prompt,
            model=model,
            max_tokens=max_tokens,
            temperature=temperature,
            top_p=top_p,
            stream=stream,
            stop=stop,
            extra=kwargs,
        )
        return self._provider.text_generate(request)


class ImageService:
    """图像生成服务"""

    def __init__(self, provider):
        self._provider = provider

    def generate(
        self,
        prompt: str,
        model: str = "dall-e-3",
        size: str = "1024x1024",
        n: int = 1,
        quality: str = "standard",
        style: str = "vivid",
        **kwargs,
    ) -> ImageGenerateResponse:
        request = ImageGenerateRequest(
            prompt=prompt,
            model=model,
            size=size,
            n=n,
            quality=quality,
            style=style,
            extra=kwargs,
        )
        return self._provider.image_generate(request)


class AudioService:
    """语音服务（识别和合成）"""

    def __init__(self, provider):
        self._provider = provider

    def recognize(
        self,
        audio: bytes,
        model: str = "whisper-1",
        language: Optional[str] = None,
        prompt: Optional[str] = None,
        **kwargs,
    ) -> SpeechRecognizeResponse:
        request = SpeechRecognizeRequest(
            audio=audio,
            model=model,
            language=language,
            prompt=prompt,
            extra=kwargs,
        )
        return self._provider.speech_recognize(request)

    def synthesize(
        self,
        text: str,
        model: str = "tts-1",
        voice: str = "alloy",
        response_format: str = "mp3",
        speed: float = 1.0,
        **kwargs,
    ) -> SpeechSynthesizeResponse:
        request = SpeechSynthesizeRequest(
            text=text,
            model=model,
            voice=voice,
            response_format=response_format,
            speed=speed,
            extra=kwargs,
        )
        return self._provider.speech_synthesize(request)
