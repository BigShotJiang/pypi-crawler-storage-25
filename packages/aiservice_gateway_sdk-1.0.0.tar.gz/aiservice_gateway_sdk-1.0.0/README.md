# AI Service Gateway SDK

统一的 AI 服务网关 SDK，支持硅基流动、OpenAI 等多种 AI 厂商，一次接入，随处使用。

## 特性

- 🚀 **简单易用** - 统一的客户端接口，几行代码即可接入
- 🔌 **插件化架构** - 支持多种 AI 厂商，可轻松扩展
- 🛡️ **完善错误处理** - 清晰的异常体系，易于调试
- 📦 **类型提示完整** - 完整的 Type Hints 支持 IDE 自动补全
- 🔄 **自动重试** - 内置请求重试机制，提高稳定性

## 支持的 AI 厂商

| 厂商 | 文本生成 | 图像生成 | 语音识别 | 语音合成 |
|------|:--------:|:--------:|:--------:|:--------:|
| 硅基流动 | ✅ | ✅ | ✅ | ✅ |
| OpenAI | 🚧 | 🚧 | 🚧 | 🚧 |

## 安装

```bash
pip install aiservice-gateway-sdk
```

## 快速开始

### 文本生成

```python
from aiservice_gateway_sdk import AIServiceGatewayClient

# 初始化客户端
client = AIServiceGatewayClient(
    provider="silicon",           # AI服务厂商
    api_key="your-api-key"        # 你的API Key
)

# 文本生成
result = client.text.generate(
    prompt="你好，请介绍一下你自己",
    model="Qwen/Qwen2.5-7B-Instruct",
    max_tokens=1000,
    temperature=0.7
)

print(result.text)
print(f"使用模型: {result.model}")
print(f"消耗Token: {result.usage.total_tokens}")
```

### 图像生成

```python
# 图像生成
result = client.image.generate(
    prompt="一只可爱的橘猫在阳光下打盹",
    model="dall-e-3",
    size="1024x1024",
    n=1
)

for img in result.image_urls:
    print(f"图像URL: {img.url}")
```

### 语音识别

```python
# 读取音频文件
with open("audio.wav", "rb") as f:
    audio_data = f.read()

# 语音识别
result = client.audio.recognize(
    audio=audio_data,
    model="whisper-1",
    language="zh"
)

print(f"识别结果: {result.text}")
```

### 语音合成

```python
# 语音合成
result = client.audio.synthesize(
    text="你好，欢迎使用AI服务网关SDK",
    model="tts-1",
    voice="alloy"
)

# 保存音频文件
with open("output.mp3", "wb") as f:
    f.write(result.audio)
```

## 配置选项

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| provider | str | "silicon" | AI 服务厂商 |
| api_key | str | None | API 密钥 |
| base_url | str | None | 自定义 API 地址 |
| timeout | int | 30 | 请求超时时间（秒） |
| max_retries | int | 3 | 最大重试次数 |

## 错误处理

```python
from aiservice_gateway_sdk import (
    AIServiceGatewayClient,
    AuthenticationError,
    RateLimitError,
    APIError,
)

client = AIServiceGatewayClient(
    provider="silicon",
    api_key="your-api-key"
)

try:
    result = client.text.generate("你好")
except AuthenticationError:
    print("认证失败，请检查API Key")
except RateLimitError:
    print("请求频率超限，请稍后重试")
except APIError as e:
    print(f"API错误: {e.message}")
```

## 支持的模型

### 硅基流动

**文本生成模型:**
- `Qwen/Qwen2.5-7B-Instruct`
- `Qwen/Qwen2.5-14B-Instruct`
- `Qwen/Qwen2.5-72B-Instruct`
- `deepseek-ai/DeepSeek-V2.5`
- `THUDM/GLM-4-9B-Chat`

**图像生成模型:**
- `dall-e-3`

**语音识别模型:**
- `whisper-1`

**语音合成模型:**
- `tts-1`

## 从源码安装

```bash
git clone https://github.com/your-repo/aiservice-gateway-sdk.git
cd aiservice-gateway-sdk
pip install -e .
```

## 开发

```bash
# 克隆项目
git clone https://github.com/your-repo/aiservice-gateway-sdk.git

# 创建虚拟环境
python -m venv venv
source venv/bin/activate  # Linux/Mac
# 或
.\venv\Scripts\activate  # Windows

# 安装开发依赖
pip install -e ".[dev]"

# 运行测试
pytest tests/

# 代码格式化
black src/
isort src/
```

## 发布到 PyPI

```bash
# 构建包
python -m build

# 上传到 PyPI
twine upload dist/*
```

## License

MIT License - 详见 [LICENSE](LICENSE) 文件
