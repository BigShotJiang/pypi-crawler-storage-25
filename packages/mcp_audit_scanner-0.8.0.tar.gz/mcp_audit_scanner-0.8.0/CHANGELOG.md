# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).

---

## [0.8.0] - 2026-05-03

### Added

- **`mcp-audit snapshot`** — time-stamped, sigstore-signed forensic exports of
  every MCP server on a host.  CycloneDX 1.5 AI/ML-BOM by default; native JSON
  optional (`--format native`).  Every server becomes a CycloneDX `component` of
  `type: application`; every finding becomes a `vulnerability` entry with ratings,
  CWEs, OWASP MCP Top 10 mappings, and a custom `properties` block.  `--sign`
  produces a `.snapshot.json.sig` sigstore bundle alongside the snapshot (requires
  ambient OIDC identity and `pip install 'mcp-audit-scanner[attestation]'`).
  `--rehydrate <old-snapshot.json>` reconstructs the historical attack-path graph
  as it was at snapshot time — forensic re-analysis even after the config is gone.
  `--stream` emits one JSON object per finding on stdout (NDJSON), suitable for
  piping into `vector`, a Splunk HEC forwarder, or a Sentinel DCR ingestor.
  `--input <scan.json>` accepts a previous scan result and skips live discovery.
  New modules: `src/mcp_audit/snapshot/` (`rehydrate.py`, `diff.py`),
  `src/mcp_audit/output/snapshot.py`, `src/mcp_audit/cli/snapshot.py`.
  56 tests in `tests/test_snapshot.py` (CycloneDX schema validation, rehydrate,
  diff, stream, sign error paths, CLI integration).  SIEM ingestion recipes in
  `docs/integrations/splunk.md` and `docs/integrations/sentinel.md`.
  See `docs/snapshot.md`.

- **`mcp-audit diff <base> <head>`** — MCP-aware diff for PR review and CI gates.
  Compares two MCP configuration states (directories, JSON scan files, or git refs)
  and surfaces added, removed, and changed servers, tools, capabilities, env-var
  references, external endpoints, and credentials with risk classification (CRITICAL /
  HIGH / MEDIUM / LOW / INFO).  PR-comment-grade Markdown output (`--format pr-comment`)
  is ready to pipe into `gh pr comment` or a GitHub Actions step.  JSON output
  (`--format json`) provides a flat list of change records with `change_type`,
  `entity_type`, `entity_name`, `before`, `after`, `severity`, and `owasp_mcp_top_10`
  fields.  Exit codes mirror `mcp-audit scan` (0 = no findings at threshold, 1 =
  findings, 2 = error).  `action.yml` extended with a `mode: diff` input that runs
  diff mode and posts the result as a PR comment when running in a `pull_request` event.
  New modules: `src/mcp_audit/diff/` (`loader.py`, `comparator.py`, `risk.py`,
  `render.py`), `src/mcp_audit/cli/diff.py`.  `examples/github-actions/diff-mode.yml`
  reference workflow added.  See `docs/diff.md`.

- **`mcp-audit killchain`** — opinionated remediation view of the attack-path graph.
  Decision engine that identifies the top N configuration changes (default 3) that cut
  the largest blast radius, ranked by incremental attack-path reduction.  Uses the
  existing greedy hitting-set algorithm in `analyzers/attack_paths.py` and wraps each
  step with human-readable target, rationale, and severity-reduction metadata.
  Outputs a prescriptive Markdown report (copy-paste into Slack/email) or JSON
  (`--format json`).  `--patch yaml` emits a YAML governance-policy denylist patch
  (with schema-gap note); `--patch pr` emits a PR-comment stub.  `--input <scan.json>`
  accepts an existing scan result; default behaviour re-runs the full pipeline.
  What-if simulation re-runs `summarize_attack_paths` against the modified server list
  — the math is identical to a real re-scan, not an approximation.  New modules:
  `src/mcp_audit/killchain/` (`recommender.py`, `simulator.py`, `patches.py`,
  `render.py`), `src/mcp_audit/cli/killchain.py`.  46 new tests in
  `tests/test_killchain.py`.  See `docs/killchain.md`.

- **`mcp-audit shadow`** — new top-level command for continuous detection of shadow MCP servers
  (OWASP MCP09). Sweeps every known MCP config location on the host; classifies each server as
  `sanctioned` (matches an optional operator allowlist) or `shadow` (does not); attaches a
  structured risk summary (capability tags, toxic-flow signals, OWASP MCP09 mapping); emits
  structured events in `--continuous` daemon mode (`new_shadow_server`, `server_drift`,
  `server_removed`); supports `--format json` for syslog/SIEM piping; persists `first_seen` /
  `last_seen` state with `0o600` file permissions. New modules:
  `src/mcp_audit/shadow/` (`allowlist.py`, `classifier.py`, `risk.py`, `events.py`, `state.py`),
  `src/mcp_audit/cli/shadow.py`. Introduces new `RiskLevel` enum (mirrors Severity + `UNKNOWN`).
  See `docs/shadow-mcp.md`.

- **CI: synthetic install-tree integration tests** (`tests/integration/test_synthetic_install.py`,
  `.github/workflows/synthetic-install.yml`) — new `synthetic-install` CI workflow runs on
  `ubuntu-latest` and `windows-latest` on every PR and push; validates the full
  `discover` → `scan` → `baseline` pipeline against realistic per-OS fixture trees.
  Covers: canonical-path discovery for all six auto-discovered clients (Claude Desktop,
  Cursor, Windsurf, Claude Code, Copilot CLI, Augment) via `HOME`/`USERPROFILE` env-var
  injection; credential-finding detection to prove scanning ran; paths with spaces; non-ASCII
  filenames (`配置/мcp.json`); `baseline save`/`compare` round-trip on non-ASCII paths; and
  Windows >260-char path graceful handling (`xfail` when OS rejects the path, never a
  Python traceback). No changes to `discovery.py` required — `Path.home()` already reads
  `HOME`/`USERPROFILE` from the subprocess environment.

---

## [0.7.0] - 2026-05-02

### Added

- **User-configurable scoring weights via governance policy YAML** — add a
  `scoring:` block to `.mcp-audit-policy.yml` to override per-severity
  deductions and positive-signal bonuses. Absent keys fall back to their
  hardcoded defaults, so existing scans are unaffected. Deduction values
  must be `<= 0`; bonus values must be `>= 0`; `policy validate` enforces
  both constraints. See `docs/governance.md#scoring-weights` and the new
  example policy at `examples/policies/custom-scoring-weights.yml`.
- **`ScanScore.weights_source` audit field** — set to `"default"` when
  hardcoded weights are used, `"policy:<absolute-path>"` when a governance
  policy supplies custom weights. Present in JSON and SARIF output; the
  terminal score panel shows a dim `Weights: policy:<path>` line when custom
  weights are active. Existing JSON consumers that do not read this field
  are unaffected (additive, non-breaking).

### Changed

- **Scoring defaults recalibrated**: HIGH −10 (was −15), MEDIUM −5 (was −8),
  LOW −2 (was −3), poisoning-free bonus +4 (was +2). Users upgrading from
  v0.6.x may see numeric grades shift upward on identical configurations.
  The CRITICAL deduction (−25), INFO deduction (−1), credential-free bonus
  (+3), and max-bonus cap (+10) are unchanged.

- **CI: smoke test extended with three new steps** (`scripts/smoke_test.py`):
  - **Watcher round-trip** (Check 9): launches `mcp-audit watch` as a subprocess,
    modifies a temp fixture, and asserts the watcher detects the change and re-scans
    within 10 s — exercises inotify (Linux), ReadDirectoryChangesW (Windows), and
    FSEvents (macOS).
  - **Rug-pull two-scan** (Check 10): runs two consecutive scans on a fixture whose
    `command`/`args` change between scans, then asserts a `RUGPULL-*` finding appears
    in scan 2 — confirms rug-pull state is written to and read from
    `platformdirs.user_config_dir("mcp-audit")/state/` on all platforms.
  - **Canonical-path discovery** (Check 11): writes a minimal MCP config to the
    OS-canonical Claude Desktop config path (`~/Library/Application Support/Claude/…`
    on macOS, `~/.config/Claude/…` on Linux, `%APPDATA%\Claude\…` on Windows), runs
    `mcp-audit discover --json`, and asserts the path appears in output; fixture is
    always removed in a `finally` block.
- **CI: `windows-latest` added to PR smoke matrix** — new `source-smoke` job in
  `.github/workflows/ci.yml` runs `python scripts/smoke_test.py uv run mcp-audit` on
  both `ubuntu-latest` and `windows-latest` on every PR and push to `main`, without
  the cost of a PyInstaller build (uses the source install via `uv run`).
- **Smoke test accepts multi-word binary invocations** — `smoke_test.py` now collects
  all `sys.argv[1:]` as the binary command list, so `python scripts/smoke_test.py uv run
  mcp-audit` and `python scripts/smoke_test.py dist/mcp-audit-linux-x86_64` are both
  valid; existing release workflow invocations are unchanged.

- **Registry grown to 75 known legitimate servers** — reduces false-positive SC-002
  (unknown server) and TRANSPORT-003 (unverified package) findings for common
  community packages. Eleven new entries added covering major ecosystem integrations:
  `@github/github-mcp-server` (GitHub), `@playwright/mcp` (Microsoft), `tavily-mcp`
  (Tavily AI), `firecrawl-mcp` (Firecrawl), `mcp-server-qdrant` (Qdrant),
  `@neondatabase/mcp-server-neon` (Neon), `@shopify/dev-mcp` (Shopify),
  `mcp-atlassian` (community Atlassian connector), `@agentdeskai/browser-tools-mcp`
  (AgentDesk), `@azure/mcp` (Microsoft Azure), and `langchain-mcp-adapters`
  (LangChain). Registry size: 64 → 75.

- **`semgrep` added to dev extras** — contributors can now run
  `uv sync --extra dev && semgrep --config semgrep-rules/ src/mcp_audit/` without
  a separate Semgrep install. Semgrep self-scan result: 34 Python rules, 73 files,
  0 findings. See `GAPS.md` § "Self-scan results" for full details.

- **TypeScript SAST: 7 new rule categories (11 rules) close the gap with Python** —
  TS rule count: 18 → 29 (total SAST pack: 52 → 63 rules).
  - `mcp-ts-credential-default-param` (CWE-798/HIGH): hardcoded string used as
    default value for a credential-named function parameter; covers `function`,
    `async function`, and arrow function forms.
  - `mcp-ts-console-log-sensitive` (CWE-532/HIGH): sensitive identifier (name
    matching `key|token|secret|password|auth|credential`) passed to
    `console.log`, `console.debug`, or `console.warn`; string literals excluded.
  - `mcp-ts-console-error-sensitive` (CWE-532/HIGH): same as above for
    `console.error`.
  - `mcp-ts-description-contains-url` (CWE-1336/HIGH): HTTP/HTTPS URL embedded
    in a variable or object property named `description` or `desc`.
  - `mcp-ts-description-base64-content` (CWE-1336/HIGH): 20+ consecutive base64
    characters in a description variable or object property.
  - `mcp-ts-description-unicode-escape` (CWE-1336/MEDIUM): `\uXXXX` escape
    sequence in a description string assignment or object literal.
  - `mcp-ts-no-type-check-before-use` (CWE-20/MEDIUM): MCP tool argument accessed
    via `args[key]` and passed directly to a function inside an async handler
    without a `typeof` guard; high FP rate — suppress with `// nosemgrep` when
    Zod/Joi validation is present.
  - `mcp-ts-error-stack-in-return` (CWE-209/HIGH): `err.stack` returned from an
    async function — stack trace disclosure.
  - `mcp-ts-error-tostring-in-return` (CWE-209/MEDIUM): `String(err)` or
    `err.toString()` returned from an async function — raw exception disclosure.
  - `mcp-ts-express-listen-all` (CWE-605/HIGH): `$APP.listen(port, "0.0.0.0")`
    or `$APP.listen(port, "")` — server binds to all interfaces.
  - `mcp-ts-http-listen-all` (CWE-605/HIGH): `listen({host: "0.0.0.0"})` — Fastify
    or Node HTTP/HTTPS server binds to all interfaces.
  New test fixtures in `semgrep-rules/tests/typescript/<category>/<rule>/` (14
  files: one `vulnerable/test.ts` and one `safe/test.ts` per rule file). All 7
  rule files pass `semgrep --validate`; each vulnerable fixture triggers the rule
  and each safe fixture produces zero findings.
  Sources: CWE-798, CWE-532, CWE-1336, CWE-20, CWE-209, CWE-605, OWASP A07/A09/
  A05:2021, CVE-2026-41495 (n8n-MCP), CVE-2026-33032. See `PROVENANCE.md`.

---

## [0.6.0] - 2026-04-30

### Added
- **Fleet merge: D3-powered HTML dashboard** — `mcp-audit merge --format html`
  now produces a polished, self-contained fleet dashboard (replacing the previous
  Rich-table HTML export).  The new dashboard includes:
  - Header with fleet-level grade badge (worst-case machine grade A–F),
    total machines, total findings, Crit+High count, average score, and
    generation timestamp.
  - Machine grid — one card per machine with hostname, colour-coded grade badge,
    per-severity finding counts, and a mini severity-distribution bar chart.
    Click a card to filter the findings table to that machine.
  - Filterable, sortable findings table — filter by severity (pill buttons),
    machine (dropdown), or analyzer (dropdown); sort by any column.
  - Light/dark mode toggle (matching the per-scan dashboard).
  - Fully self-contained — D3 v7 bundled inline, zero CDN references, renders
    offline.
  Files changed: `src/mcp_audit/fleet/merger.py` (replaced `_FLEET_HTML`
  template and `generate_fleet_html()`), `docs/fleet-scanning.md`.

- **SAST: 7 new TypeScript rules** — path traversal (3), SQL injection (2), SSRF (2) —
  bringing the TypeScript rule count from 11 to 18 (total SAST pack: 52 rules).
  - `mcp-ts-fs-readfile-traversal` (HIGH/CWE-22): `fs.readFile`/`readFileSync` with
    unvalidated variable path.
  - `mcp-ts-fs-writefile-traversal` (HIGH/CWE-22): `fs.writeFile`/`appendFile` with
    unvalidated variable path.
  - `mcp-ts-path-join-traversal` (MEDIUM/CWE-22): `path.join()` with variable
    component and no inline `path.resolve()`.
  - `mcp-ts-string-concat-sql` (CRITICAL/CWE-89): string concatenation of a SQL
    keyword string into `db.query()`/`pool.query()`.
  - `mcp-ts-unsafe-query-variable` (HIGH/CWE-89): non-literal (template literal or
    variable) first argument to SQL query functions — catches template literal
    interpolation (`\`SELECT ... ${userId}\``) that the concat rule cannot detect.
  - `mcp-ts-fetch-ssrf` (HIGH/CWE-918): `fetch()`/`axios` called with a non-literal
    URL — SSRF risk.
  - `mcp-ts-http-request-ssrf` (HIGH/CWE-918): `https.request()`/`http.request()`
    called with a non-literal URL — SSRF risk.
  New Semgrep test fixtures in `semgrep-rules/tests/typescript/vulnerable/`
  (`path_traversal_examples.ts`, `sqli_examples.ts`, `ssrf_examples.ts`).
  Safe patterns for all new rules added to
  `semgrep-rules/tests/typescript/clean/safe_server.ts`.
  11 new unit tests in `tests/test_sast.py` covering severity mapping, analyzer tag,
  CWE propagation, and finding ID format for each new rule.
  Sources: OWASP Path Traversal, OWASP SQLi Prevention, OWASP SSRF Prevention,
  CWE-22, CWE-89, CWE-918. See `PROVENANCE.md`.

- Live connection (`--connect`): server stderr is now captured and suppressed
  from the terminal.  Use `--verbose` (new flag) to print captured server output
  under a "Server output" header after the scan.  Captured logs also appear in
  the `server_logs` array in JSON output.  Prevents MCP server startup messages
  from interleaving with mcp-audit's Rich output.
- `--connect-token TOKEN` (new flag): passes `Authorization: Bearer <token>` on
  SSE/HTTP MCP server connections.  Enables scanning of enterprise MCP servers
  that require authentication.  Silently ignored for stdio servers.  Token is
  never stored, logged, or included in any output format.
- 401/403 HTTP responses from SSE servers now produce a clear, actionable error
  message (e.g. `"401 Unauthorized — use --connect-token to provide credentials"`)
  instead of a raw Python traceback.
- `ScanResult.server_logs` field: `list[str]` of captured stdio server stderr,
  populated during `--connect` runs; empty for static-only scans.
- `docs/live-connection.md`: new documentation covering `--connect`, stderr
  suppression, `--connect-token`, auth error messages, and troubleshooting.

---

## [0.5.1] - 2026-04-30

### Added
- Fleet merge: `--dir` now recurses into subdirectories to collect JSON scan
  outputs from nested CI artifact layouts (e.g. `dir/team-a/machine1.json`,
  `dir/team-b/machine2.json`). Existing flat-directory usage is unchanged.
  `_collect_json_paths_from_dir()` changed from `glob("*.json")` to
  `rglob("*.json")`; four new unit/integration tests added in `test_fleet.py`.
- Extension scanner: add Windows paths for VS Code (`%APPDATA%\Code\extensions`),
  VS Code Insiders (`%APPDATA%\Code - Insiders\extensions`), Cursor
  (`%USERPROFILE%\.cursor\extensions`), and Windsurf
  (`%USERPROFILE%\.windsurf\extensions`).  Paths are resolved at call time from
  environment variables and silently skipped when the variable is absent.
  Covered by five new unit tests in `tests/test_extensions.py`
  (`TestWindowsExtensionPaths`) that run on all CI platforms via monkeypatching.
- `scripts/update_test_count.py` now also validates SAST rule count (total,
  Python, TypeScript breakdown), community rule count, and concrete analyzer
  count in addition to the existing test-count check — prevents v0.5.0-style
  doc drift in CI.

### Fixed
- `--offline` flag help text now accurately describes current behaviour: the
  flag prevents combining with `--verify-hashes`, `--verify-signatures`,
  `--check-vulns`, and `--connect` (exit code 2 if combined), but a plain scan
  already makes no network calls so the flag is a no-op for the default
  configuration. Updated `docs/enterprise-deployment.md`,
  `docs/supply-chain.md`, and `CLAUDE.md` to match.
- Stale feature counts in `README.md` and `CLAUDE.md` after v0.5.0: SAST rules
  37→45 (28→34 Python, 9→11 TypeScript), community rules 12→13, analyzer count
  6→7; added `ConfigHygieneAnalyzer` and `Finding.cve` / CVE tagging mentions to
  the README Features section.
- Supply chain: tighten Levenshtein typosquatting threshold for short package
  names (≤5 chars) from 3→1 to reduce false positives. Names of 6+ characters
  keep the existing threshold of 3. Legitimate typosquats differing by exactly 1
  character (e.g., `mcq` vs `mcp`) still fire SC-001 at CRITICAL severity.

---

## [0.5.0] - 2026-04-27 — April 2026 Security Sweep

> **Lead:** CVE-tagged findings, a new auth SAST category catching MCPwn and the
> n8n-MCP token-logging class, and a config-file hygiene analyzer anchored to
> the Bitwarden supply-chain incident.

### Added
- **`Finding.cve` field.** Every finding can now carry a list of CVE identifiers.
  Populated on TRANSPORT-004, COMM-002, COMM-006, COMM-010, COMM-012, COMM-013,
  and all new auth SAST rules. Surfaces in terminal output (dim red badge), JSON,
  and SARIF `result.properties["cve"]`.
- **COMM-013: npx auto-confirm flag.** New community rule — HIGH / MCP04+MCP05 —
  fires when `npx`/`bunx`/`pnpx` is invoked with `--yes` or `-y`, bypassing the
  user-confirmation prompt. This is the silent-execution pattern from the OX
  Security STDIO disclosure. Tagged with all six OX CVEs (CVE-2025-49596,
  CVE-2026-22252, CVE-2026-22688, CVE-2025-54994, CVE-2025-54136, CVE-2026-30615).
- **CVE cross-references on existing findings.** TRANSPORT-004 and COMM-012 now
  carry `CVE-2026-33032` (MCPwn, CVSS 9.8); COMM-002 carries `CVE-2026-22252`;
  COMM-006 carries `CVE-2026-22688`; COMM-010 carries `CVE-2025-49596`.
- **Auth SAST category (`semgrep-rules/*/auth/`).** New 6th category, 8 rules
  across Python and TypeScript:
  - `mcp-route-missing-auth-middleware` — parallel `/mcp*` route with no auth
    dependency (MCPwn pattern, CVE-2026-33032). ERROR.
  - `mcp-empty-allowlist-allow-all` — `if not allowlist: return True/pass`
    (empty-allowlist-means-allow-all, CVE-2026-33032). WARNING.
  - `mcp-wellknown-route-no-auth` — `/.well-known/` route with no auth. WARNING.
  - `mcp-authorization-header-logged` — `logging.*(request.headers)` before auth
    check (n8n-MCP class, CVE-2026-41495, CWE-532). WARNING.
  - `mcp-api-key-header-logged` — logger call where variable name matches
    API key / bearer token patterns (CWE-532). WARNING.
  - `mcp-full-request-body-logged-on-fail` — request body logged inside an except
    block (CWE-532). INFO.
  - TypeScript equivalents for route-missing-auth and auth-header-logged.
- **`ConfigHygieneAnalyzer` (`analyzers/config_hygiene.py`).** New default-pipeline
  analyzer grading MCP config file posture. Anchored to the Bitwarden supply-chain
  incident (2026-04-22) — malware explicitly targeted `~/.claude.json`,
  `~/.claude/mcp.json`, and `~/.kiro/settings/mcp.json`. Four new finding IDs:
  - `CFHYG-001` HIGH — config file is world-readable (POSIX `o+r`). CWE-732.
  - `CFHYG-002` HIGH — config file in a world-writable ancestor directory. CWE-732.
  - `CFHYG-003` HIGH — plaintext secret inline (Bitwarden malware target profile). CWE-312.
  - `CFHYG-004` INFO — all env values use env-var references (positive signal).
  - Runs in the default pipeline with no flag required. Windows ACL checking deferred.

### Changed
- `PolicyRule` now accepts a `cve:` list; the rule engine threads it through to
  emitted `Finding` objects.
- TRANSPORT-004 description names CVE-2026-33032 (MCPwn) explicitly.
- COMM-012 description and message updated to reference MCPwn.
- `mcp-listen-all-interfaces.yml` metadata includes `cve: CVE-2026-33032` and
  a references URL.
- `docs/severity-framework.md` updated with COMM-013 row, CVE annotations, and
  new config hygiene and auth SAST tables.
- SAST rule count: 37 → 45 (28 → 34 Python, 9 → 11 TypeScript), 5 → 6 categories.
- Test count: 1,361 → 1,391.

---

## [0.4.0] - 2026-04-25 — OWASP MCP Top 10 field alignment

> **Lead:** OWASP MCP Top 10 mapping on every finding — `owasp_mcp_top_10` field
> in JSON, SARIF taxonomy block + per-rule relationships for Code Scanning, and
> `mcp-audit scan --owasp-report` for a category-level aggregated view.

### Added
- **OWASP MCP Top 10 mapping on every finding.** `Finding.owasp_mcp_top_10`
  carries a list of `MCP01`–`MCP10` category codes. Every shipped finding ID
  is pre-populated; empty list = unmapped. Single source of truth lives in
  `src/mcp_audit/owasp_mcp.py`.
- **SARIF taxonomy block.** SARIF output now includes a `runs[0].taxonomies`
  `toolComponent` for the OWASP MCP Top 10 (stable GUID
  `f1a3c4d5-9e6b-4a7d-8b2c-1f9e0a3d5c7e`). Each rule gains a `relationships`
  array referencing applicable taxa, plus a `properties["owasp-mcp-top-10"]`
  mirror for consumers that don't honour the taxonomy mechanism.
- **Terminal inline codes.** The per-finding terminal renderer now shows
  `[MCP03, MCP06]` in dim cyan next to the title when codes are present.
  Unmapped findings (positive signals, etc.) are unaffected.
- **`mcp-audit scan --owasp-report`.** After the normal scan output, prints
  a category-level summary table — how many findings triggered each MCP Top
  10 category and their severity breakdown. Suppressed when no findings carry
  codes. Does not affect exit codes, severity threshold, or score.
- **Community rule and governance YAML** both accept `owasp_mcp_top_10:` and
  propagate it through to emitted `Finding` objects.
- **Semgrep SAST rules** carry `metadata.owasp-mcp-top-10`; `sast/runner.py`
  copies the field onto the resulting `Finding`.
- **`docs/owasp-mcp-top-10.md`** — new reference page covering terminal, JSON,
  SARIF output, the `--owasp-report` flag, and implementation notes.
- **`docs/severity-framework.md`** updated with an OWASP MCP Top 10 column in
  every per-analyzer mapping table and a new reference section at the bottom.

### Fixed
- Added `# nosec B104` suppression to the `_WILDCARD_HOSTS` detection-pattern
  string in `analyzers/transport.py`, eliminating a bandit false positive that
  had been silently leaking into scans.

---

## [0.3.3] - 2026-04-24 — Patch: close the PyPI publish gap

The release pipeline has been tagging versions and attaching
PyInstaller binaries to GitHub Releases since `v0.1.1` — but it never
published to PyPI. `pip install mcp-audit-scanner` still resolved to
`0.1.0` (the last manual upload), and the composite `action.yml`
silently installed `0.1.0` at runtime on every `@v0.3.x` invocation
because its `pip install mcp-audit-scanner` step had no newer version
to find.

No schema / API changes — drop-in patch. Bump
`adudley78/mcp-audit@v0.3.2` → `@v0.3.3`. From this release forward,
every `v*.*.*` tag push automatically publishes to PyPI; users can
`pip install --upgrade mcp-audit-scanner` normally.

### Added
- **PyPI Trusted Publishing (OIDC) pipeline** in `.github/workflows/release.yml`.
  Runs in parallel with the GitHub Release job so a transient PyPI
  outage never withholds the binary release (and vice versa). No
  `PYPI_API_TOKEN` secret to manage or rotate; PyPI mints a
  short-lived credential for each workflow run via GitHub's OIDC
  issuer, scoped to the `pypi` GitHub Environment.
- **PEP 740 sigstore attestations** (`attestations: true`) —
  published alongside the wheel and sdist, binding each artefact to
  the workflow run that produced it. Surfaced on the PyPI project
  page so downstream consumers can verify provenance.
- **Supply-chain-hardened action pinning** — `pypa/gh-action-pypi-publish`
  pinned to the v1.14.0 commit SHA (`cef221092ed1bacb1cc03d23a2d87d1d172e277b`,
  signed tag, PGP-verified by @webknjaz) rather than the floating
  `release/v1` branch. A floating ref could be silently moved to a
  malicious commit; a SHA cannot.

### Skipped
- **Backfilling `0.1.1`–`0.3.2` to PyPI.** PyPI versions are
  effectively immutable (you can yank, not delete), so publishing
  `0.3.0` and `0.3.1` now would permanently put two known-broken
  releases in the registry — the opposite of what the "superseded"
  banners on their GitHub Releases are trying to prevent. Users go
  directly from `0.1.0` → `0.3.3` via `pip install --upgrade`.

---

## [0.3.2] - 2026-04-24 — Patch: isolate Semgrep install from mcp-audit deps

Supersedes `v0.3.1`, which fixed the `v0.3.0` "Semgrep not installed"
error by invoking `pip install semgrep` inside the composite action's
`run-sast` step — but that plain-pip install downgrades `click` from
`8.2.x` to `8.1.8` (Semgrep pins `click<8.2`), which then breaks
`typer>=0.24` at import with:

```
TypeError: type 'Choice' is not subscriptable
  at typer/_types.py:9 → class TyperChoice(click.Choice[...])
```

Drop-in patch — no schema / API changes. Bump
`adudley78/mcp-audit@v0.3.1` → `@v0.3.2`.

### Fixed
- **`run-sast: 'true'` broke mcp-audit itself** via dep conflict.
  Switched the composite action from `pip install semgrep` to
  `pipx install semgrep`.  `pipx` ships pre-installed on every
  GitHub-hosted Ubuntu runner, installs Semgrep into its own isolated
  venv, and places the `semgrep` binary on PATH without touching the
  `mcp-audit-scanner` environment — zero dep pollution.

---

## [0.3.1] - 2026-04-24 — Patch: unbreak action self-tests and example pinning

Fixes three independent regressions that shipped with `v0.3.0` and surfaced
as CI failures on `main` minutes after the tag landed. `v0.3.1` is a
drop-in replacement — users should bump `adudley78/mcp-audit@v0.3.0` →
`@v0.3.1` in their workflows. No input / output schema changes.

### Fixed
- **`run-sast: 'true'` failed at runtime** with `semgrep is not installed`.
  The Semgrep CLI is intentionally not bundled in `mcp-audit-scanner` (the
  ~15 MB dependency would bloat the wheel and the PyInstaller binary for
  the ~95% of users who never opt into SAST). The composite action now
  installs Semgrep inside the `run-sast: 'true'` step
  (`pip install semgrep --quiet`), so the cost is pay-for-what-you-use and
  SAST is zero-config for opt-in users.
- **`@v1` tag references everywhere** — `.github/workflows/mcp-audit-example.yml`,
  `docs/github-action.md`, `docs/docs-usage.md`, `examples/github-actions/*.yml`
  — pointed at a non-existent tag. Users copying our docs verbatim would
  see `Unable to resolve action adudley78/mcp-audit@v1`. Pinned everything
  to a real release tag (`@v0.3.1`) and added a **Version pinning** section
  to `docs/github-action.md` documenting the convention: pin to a specific
  release tag today; `@v1` will track the latest 1.x release once v1.0.0
  ships (standard GitHub Marketplace floating-tag pattern).
- **Test-count drift check** failed on `ubuntu-latest/3.12` — docs said
  `1,342 tests` (macOS collection count) but the CI canonical is `1,308`.
  Commit `12bcd3c` already established that the docs track the CI
  canonical to avoid the long-standing macOS↔Linux skipif-import delta.
  Realigned `CLAUDE.md` and `README.md`.

### Docs
- Corrected a stale CLAUDE.md / `docs/github-action.md` line that claimed
  Semgrep ships bundled in `mcp-audit-scanner`. Only the Semgrep rule pack
  (`semgrep-rules/`, 37 rules) is bundled; the CLI binary is not.

---

## [0.3.0] - 2026-04-24 — GitHub Marketplace Action

### Added
- **GitHub Action wrapper** (`action.yml`) — composite action ready for
  Marketplace listing. No Docker; installs `mcp-audit-scanner` from PyPI and
  invokes the CLI via `shell: bash`. Uploads SARIF to GitHub Code Scanning
  via `github/codeql-action/upload-sarif@v4` (continue-on-error so repos
  without Code Scanning still run cleanly).
- **New input schema** — `config-paths`, `severity-threshold`, `sarif-output`,
  `upload-sarif`, `check-vulns`, `verify-signatures`, `run-sast`, `sast-path`,
  `baseline-name`, `fail-on-findings`, `version`. The composite action writes
  SARIF via `--format sarif --output` (never the non-existent `--sarif` flag)
  and invokes `mcp-audit baseline compare <name>` positionally.
- **New outputs** — `findings-count`, `grade`, `sarif-path`. Consumable by
  downstream steps via `steps.<id>.outputs.<name>`.
- **`.github/workflows/action-ci.yml`** — self-tests the composite on every
  push / PR: one run against `demo/configs/` and one with `run-sast: true`
  against `src/`.
- **`docs/github-action.md`** — rewritten against the new schema. Quick-start,
  full example, inputs / outputs tables, permissions, scenarios, exit-code
  behaviour, troubleshooting, and SARIF-upload verification checklist.
- **`tests/test_action_yaml.py`** — 13 structure + security guardrails
  covering branding, required top-level keys, input/output schema stability,
  old-name removal, hardcoded-secret patterns, `--sarif` flag typo, and the
  `upload-sarif@v4` pin.

### Changed
- **`tests/test_github_action.py`** — migrated to the v1 input schema;
  two new guardrails assert old names (`format`, `sast`, `baseline`,
  `finding-count`) remain absent.
- **Example workflows** — `examples/github-actions/with-baseline.yml` now
  uses `baseline-name:`; the commented-out SAST block in
  `.github/workflows/mcp-audit-example.yml` uses `run-sast:`.
- **`README.md` / `docs/enterprise-deployment.md`** — stray
  `github/codeql-action/upload-sarif@v3` references bumped to `@v4` (v3
  runs on Node 20, deprecated 2026-06-02).
- **`pyproject.toml`** — author email switched to a GitHub noreply address;
  Homepage / Documentation URLs now point at the GitHub repository.
- **`SECURITY.md`** — security disclosure channel switched to GitHub's
  private vulnerability reporting.
- **`CLAUDE.md`** — repo-map and feature blurb synced to the v1 action
  schema; test count bumped to 1,342.

---

## [0.2.0] - 2026-04-24 — Remove paid-license infrastructure

mcp-audit has been Apache-2.0-licensed since the first public release, but
the codebase kept the full paid-license machinery around "just in case" —
Ed25519 key verification, a bundled certificate revocation list, a feature
gate helper, and the `activate` / `license` CLI commands. There are no
paying users and no plan to add any, so that entire layer is now gone.
This is a semver-major change because it deletes two CLI commands.

### Removed
- **`src/mcp_audit/licensing.py`** — Ed25519 license-key verification, `LicenseInfo` model, `is_pro_feature_available()`, `generate_license_key()`, bundled revocation list loading. Gone in one shot.
- **`src/mcp_audit/_license_cache.py`** — `lru_cache`'d wrapper around `get_active_license` / `is_pro_feature_available` that shaved repeated disk reads per scan. No longer needed.
- **`src/mcp_audit/_gate.py`** — the `gate(feature, console)` shim that used to print upsell panels. Every call site is deleted (five CLI modules: `extensions`, `fleet`, `policy`, `registry`, `rules`).
- **`src/mcp_audit/cli/license.py`** — `activate` / `license` Typer commands. The `version` command lived here too and was moved to `src/mcp_audit/cli/version.py`.
- **`scripts/generate_license.py`** — dev-only Ed25519 key issuance and revocation-list signer.
- **`src/mcp_audit/data/revoked.json`** — bundled certificate revocation list (signed by the placeholder key, effectively inert).
- **Test modules:** `tests/test_licensing.py`, `tests/test_licensing_revocation.py`, `tests/test_license_cache.py`, `tests/test_gate.py` (50 tests total). Every remaining test file that patched `mcp_audit.cli.cached_is_pro_feature_available` or `mcp_audit.licensing.get_active_license` now invokes the real (un-gated) code path.
- **`tests/conftest.py::_clear_license_cache`** autouse fixture.
- Documentation references to Pro / Enterprise tiers, `_FEATURE_TIERS`, the paid-tier landing page, Lemon Squeezy / Gumroad issuance, and the "Legacy License Commands" section of `docs/docs-usage.md`.

### Changed
- **`pyproject.toml`:** `cryptography>=46.0.6,<47.0` moved from core dependencies to the `[attestation]` optional extra. It is now only needed by `attestation/sigstore_client.py` for Fulcio-certificate X.509 parsing, and `sigstore` pulls it in transitively anyway — the explicit pin in `[attestation]` keeps the floor intact against future sigstore upgrades.
- **`build.py` and all four `.spec` files:** dropped the `mcp_audit.licensing` hidden import and the three `cryptography.hazmat.*` / `cryptography.exceptions` hidden imports that only existed for the licensing module. Added `mcp_audit.cli.version` as a replacement for the retired `mcp_audit.cli.license`.
- **`src/mcp_audit/cli/__init__.py`:** no longer re-exports `cached_is_pro_feature_available`; submodule import list now pulls `version` instead of `license`.
- **CLI docstrings:** stripped every "Requires a Pro or Enterprise license" line from `cli/extensions.py`, `cli/fleet.py`, `cli/policy.py`, `cli/registry.py`, `cli/rules.py`. The `rule list` command now shows user-local rules whenever `<user-config-dir>/mcp-audit/rules/` exists — the `cached_is_pro_feature_available("custom_rules")` guard that used to wrap it is gone.

### Added
- **`.github/workflows/ci.yml` — `test-all-extras` job.** Installs the project with `.[dev,sbom,attestation,mcp]` on `ubuntu-latest` / Python 3.12 and runs the full test suite, so the nine SBOM tests and the attestation / live-MCP paths that the default `[dev]`-only matrix silently skipped are now actually exercised on every PR.

### Version
- `pyproject.toml` and the `__version__` fallback bumped to `0.2.0`. The previous `0.1.2` binary remains the last gated-code-complete build; anyone who needs the `activate` / `license` commands for reasons unknown can still run v0.1.2 — it does nothing useful, but it works.

---

## [0.1.2] - 2026-04-24 — Release infrastructure fix, dependency widening

The `v0.1.1` tag was cut on 2026-04-24 but never produced a GitHub release: the `Build darwin-x86_64` matrix leg targeted the `macos-13` runner image, which GitHub [retired on 2025-12-08](https://github.blog/changelog/2025-09-19-github-actions-macos-13-runner-image-is-closing-down/). Jobs requesting that label queue indefinitely instead of erroring, so every v0.1.1 release run hung. `0.1.2` is the first successful release under the new semver line; no user-facing code changed between 0.1.0 and 0.1.2.

### Fixed
- **`.github/workflows/release.yml`:** migrated the `darwin-x86_64` matrix leg from the retired `macos-13` runner to `macos-15-intel` (GitHub's replacement x86_64 label, supported through 2027-08). After that date, Actions drops x86_64 macOS entirely and this leg will need to be removed — Apple Silicon Macs run the x86_64 binary transparently via Rosetta in the meantime.
- **`src/mcp_audit/__init__.py`:** `__version__` now looks up the correct PyPI distribution name (`mcp-audit-scanner`, not `mcp-audit`). Every prior release silently fell through to the hard-coded `"0.1.0"` fallback because the metadata lookup used the CLI command name instead of the wheel name, so the embedded version string on released binaries was always stale. Fallback bumped to `"0.1.2"` for source installs.

### Changed
- **`pyproject.toml`:** `cyclonedx-python-lib>=7.0,<12.0` (was `<8.0`) — the `[sbom]` extra now installs against v7 or v8–v11 transparently. `src/mcp_audit/output/cyclonedx.py` was ported to the v8+ `cyclonedx.model.tool.Tool` location and `ToolRepository` metadata API with a v7 fallback, and all cyclonedx imports are now deferred into `format()` so the module imports cleanly when the extra is absent (previously raised `NameError` on any import with the extra missing — the no-extra fallback path was silently broken). Added `tests/test_cyclonedx_output.py` (9 cases) covering both the extra-missing path and formatter output against v7–v11.
- **`pyproject.toml`:** `sigstore>=3.0,<5.0` (was `<4.0`), `rich>=13.0,<16.0` (was `<14.0`), `watchdog>=4.0,<7.0` (was `<6.0`). Dependabot updates; no code changes required.

### Tooling
- **`actions/checkout@v6`** (was v5) across all four workflows.
- **`github/codeql-action@v4`** (was v3).
- **`softprops/action-gh-release@v3`** (was v2).

---

## [0.1.0] - 2026-04-23 — First public PyPI release

Version set to `0.1.0` (clean-slate public semver; internal development milestones tracked separately in `[0.11.x]` entries below).

**PyPI package name: `mcp-audit-scanner`** — the `mcp-audit` name was already
claimed on PyPI. The CLI command remains `mcp-audit` in all cases.

```bash
pip install mcp-audit-scanner
uv add mcp-audit-scanner
```

### Changed
- `pyproject.toml`: Development Status bumped from Alpha → Beta.
- `pyproject.toml`: Keywords expanded for PyPI search discoverability.
- `pyproject.toml`: URLs block updated — Homepage, Documentation, and Changelog links added.
- `README.md`: Install instructions updated to `pip install mcp-audit-scanner`; git+ source install removed.

---

## [0.11.0] - 2026-04-23 — Open Source Conversion

### Changed
- **All features are now free.** mcp-audit is fully open source under Apache 2.0. There are no paid tiers. `is_pro_feature_available()` always returns `True`; `gate()` is a permanent no-op. This removes the Community / Pro / Enterprise split entirely.
- **`sast.py`** — dropped `gate("sast", ...)` call and "(Pro feature)" wording from command docstring.
- **`dashboard.py`** — dropped `gate(...)` calls, "(Pro/Enterprise)" help text on `--rules-dir`, and the `html is None` dead branch (unreachable since `generate_html()` always returns a string).
- **`scan.py`** — removed `vuln_mirror`, `sast`, `extensions`, and `custom_rules` gates; dropped "(Pro)" from `--format` help text.
- **`license.py`** — `version` no longer prints a tier; `activate` / `license` commands label themselves as legacy key handling on an open-source build and no longer reference the paid-tier landing page.
- **`CLAUDE.md`** — "Business model" section rewritten; all "Pro/Enterprise" / `_FEATURE_TIERS` references removed; `_gate.py` reframed as a permanent no-op shim.
- **`CONTRIBUTING.md`** — "Adding a new Pro feature" section replaced with open-source workflow; "won't accept" list bars re-introducing paid tiers.
- **`rules/README.md`** — dropped "(requires Pro)" from `rule validate` instruction.

### Removed
- 43 gate-specific tests deleted across `test_license_cache.py`, `test_dashboard.py`, `test_push_nucleus.py`, `test_fleet.py`, `test_governance.py`, `test_sast.py`, `test_extensions.py`, `test_registry.py`, `test_scanner.py`, `test_rules.py`. These tested behaviour that no longer exists. **1355 tests passing** (down from 1398; all removals are intentional).

### Notes
- `activate` and `license` commands are retained to honour any previously issued keys — they do nothing harmful on an open-source build.
- `scripts/generate_license.py` is retained (not shipped in the wheel) for the same reason.
- `push-nucleus` is ungated — it is the natural workflow for teams with a Nucleus instance, not a paywall.

---

## [0.10.1] - 2026-04-23 — SARIF 2.1.0 Schema Fixes

### Fixed
- **`invocation` extra fields** (`src/mcp_audit/output/sarif.py`, commit `46d9a34`): `machine`, `account`, and `operatingSystem` were placed directly on the `invocation` object. The SARIF 2.1.0 schema declares `invocation` with `additionalProperties: false`, making these unrecognised keys a hard schema violation. Fixed by moving all three into `invocation.properties` — a `propertyBag` (free-form key→value map) that the spec explicitly permits on every SARIF object.
- **`fixes` without `artifactChanges`** (`src/mcp_audit/output/sarif.py`, commit `46d9a34`): `result.fixes[*]` contained only `{"description": {"text": remediation}}`. The SARIF schema requires `artifactChanges` in every `fix` object, as `fixes` is designed for structured byte-level code patches, not free-text advice. Removed `fixes` entirely and moved the remediation string to `rule.help.text` (SARIF §3.49.11), the correct field for human-readable fix guidance.

### Changed
- **Playwright browser tests now pass** (previously skipped): `test_dashboard_compat.py` cross-browser tests (Chromium, Firefox, WebKit) run fully with browsers installed. Full suite: **1398 passed, 0 failed, 0 skipped**.

---

## [0.10.0] - 2026-04-23 — Nucleus FlexConnect Integration

### Added
- **`mcp-audit push-nucleus` command** (`src/mcp_audit/cli/push_nucleus.py`): Enterprise-gated command that runs a full scan and pushes results directly to a Nucleus Security project via the FlexConnect API. Multipart/form-data upload via `urllib.request` (no third-party HTTP lib). Polls job to completion with configurable timeout. Prints a Rich success panel with project ID, job ID, finding count, asset name, and a direct UI link. `--output-file` writes the FlexConnect JSON locally alongside the push. 11 tests in `tests/test_push_nucleus.py`.
- **Validated FlexConnect schema** (`src/mcp_audit/output/nucleus.py`): corrected from placeholder format to the live-validated schema. Top-level `assets` array defines the host asset; top-level `findings` array references it via `host_name`; `scan_type` is `"Host"`. Previously the formatter used a flat `host_name`/`asset_name` structure that was rejected by Nucleus ingestion ("Scan did not have any assets defined"). Validated end-to-end against a live Nucleus instance.
- **`scripts/validate_nucleus.py`**: retained as a standalone regression/validation tool for testing the FlexConnect shape against a live instance without running a full scan.

### Changed
- `_finding_to_nucleus()` now sets `host_name` per finding (linking to the `assets` entry) instead of `asset_name` with `{prefix}/{client}/{server}` formatting.
- `format_nucleus()`: `scan_type` changed from `"Application"` to `"Host"`; top-level `host_name`/`operating_system_name` envelope fields replaced by the `assets` array.
- `tests/test_nucleus_output.py`: 3 tests updated, 4 new tests added for the `assets` array structure.
- `tests/test_machine_info.py`: 7 stale `TestNucleusFormatter` tests updated to match the corrected format.

---

## [0.9.0] - 2026-04-23 — License Revocation & Commercial Infrastructure

### Added
- **Bundled certificate revocation list** (`src/mcp_audit/data/revoked.json`): signed with the same Ed25519 keypair as license keys; `_load_revoked_kids()` reads and verifies the list once at module import and caches the result in `_REVOKED_KIDS: frozenset[str]`. Returns an empty frozenset on any parse, missing-file, or signature failure — scans never hard-fail because the CRL is unsigned or corrupt (graceful degradation during development with the placeholder key).
- **`kid` and `sub` fields in license key payload**: `kid` (8-char lowercase hex, auto-generated via `secrets.token_hex(4)` if omitted) is the primary revocation handle, always included in new keys. `sub` (Lemon Squeezy order ID) is included when provided. Both fields are optional in `LicenseInfo` (`kid: str | None = None`, `subscription_id: str | None = None`) — existing keys without these fields are backward-compatible and treated as non-revocable (they expire naturally on their existing schedule).
- **Revocation check in `verify_license()`**: if `kid` is present in `_REVOKED_KIDS`, the function returns `None` immediately. Legacy keys without a `kid` field bypass the revocation check.
- **Thread-local failure discriminator** (`_set_last_verify_failure()` / `get_last_verify_failure()`): allows the CLI to surface `MCPA-LIC-REVOKED` vs `MCPA-LIC-EXPIRED` vs generic-invalid without leaking the reason into `LicenseInfo`. Error codes follow the `GOV-*` / `COMM-*` convention.
- **Discriminated error messages in `cli/license.py`**: `activate` command checks `get_last_verify_failure()` after a failed key save and prints the appropriate message: "License revoked. Contact the project's support alias with your order ID. [MCPA-LIC-REVOKED]", "License expired. [MCPA-LIC-EXPIRED]", or generic invalid.
- **`sign-revocation-list` sub-command in `scripts/generate_license.py`**: emits a signed `revoked.json` ready to commit. Usage: `python scripts/generate_license.py sign-revocation-list --kids a1b2c3d4,deadbeef --key-file ~/.mcp-audit-signing-key.pem --out src/mcp_audit/data/revoked.json`.
- **Operator audit log**: every key issuance appends a JSONL row to `~/.mcp-audit-issued-keys.jsonl` (permissions 0o600). Fields: `kid`, `email`, `sub`, `issued`, `expires`, `revoked`.
- **`tests/test_licensing_revocation.py`**: 12 new tests covering backward compat, `_load_revoked_kids` (empty list, revoked kid, tampered signature, missing file, malformed JSON, placeholder empty signature), `verify_license` revocation paths (valid-unrevoked, revoked kid, legacy key without kid), and the 90-day default issuance window.
- **No telemetry policy** (`docs/telemetry.md`): authoritative no-telemetry statement — what isn't collected, why, trade-offs accepted, and the bar any future opt-in change must clear. Linked from `docs/README.md` and `README.md`.

### Changed
- **Default key issuance window: 365 → 90 days** in `scripts/generate_license.py`. Natural expiry is the primary revocation mechanism; the bundled CRL is the break-glass for the 90-day window between a refund event and expiry.
- `generate_license_key()` gains `kid` and `sub` optional kwargs; both conditionally included in the signed payload.
- `GAPS.md` telemetry references consolidated to a single pointer to `docs/telemetry.md`.

### Notes
- The Cloudflare Worker webhook (Lemon Squeezy `order_created` → auto-issue, `order_refunded` → stop re-issuing) and the nightly GitHub Actions re-issue cron are a separate PR, pending domain and purchase URL going live.
- `src/mcp_audit/data/revoked.json` ships with `"signature": ""` until the real Ed25519 private key is available; `_load_revoked_kids()` returns `frozenset()` for this case — no scan impact.

---

## [0.8.0] - 2026-04-23 — Integration Validation: SARIF Hardening & Browser Compatibility

### Fixed
- **SARIF `%SRCROOT%` resolution** (`output/sarif.py`): Added `originalUriBaseIds` to the SARIF run object, anchoring `%SRCROOT%` to `file:///` per SARIF 2.1.0 §3.14.14. GitHub's code scanning API requires this definition to resolve relative artifact paths to repo-root-relative links in the Security tab.
- **SARIF `file:///unknown` fallback** (`output/sarif.py`): `_finding_to_file_uri` now returns the relative sentinel `"unknown"` instead of `"file:///unknown"` when `finding_path` is `None`. GitHub's SARIF uploader rejects the invalid absolute URI when `uriBaseId` is set; the relative form is accepted and gracefully omitted from source links.
- Updated 3 assertions in `tests/test_sarif_output.py` to match the corrected `"unknown"` sentinel.

### Added
- **`automationDetails.id` in SARIF output** (`output/sarif.py`): Run ID derived from scan timestamp. Prevents GitHub from creating duplicate code scanning alerts on repeated uploads of the same findings.
- **SARIF schema validation tests** (`tests/test_sarif_schema.py`): 10 tests validating mcp-audit SARIF output against the official OASIS SARIF 2.1.0 JSON schema (fetched once and cached at `tests/fixtures/sarif-schema-2.1.0.json`; tests skip gracefully if neither cache nor network is available). Covers run structure, `originalUriBaseIds` presence, `automationDetails`, finding shape, `uriBaseId` values, and version field.
- **`jsonschema>=4.0` and `playwright>=1.40`** added to `[project.optional-dependencies] dev` in `pyproject.toml`.
- **`docs/github-action.md` — SARIF upload verification guide**: 5-step manual checklist for confirming SARIF output reaches the GitHub Security tab, including common failure causes (`%SRCROOT%` unresolved, `file:///unknown` rejection, missing `write` permission on `security-events`).
- **Dashboard browser compatibility tests** (`tests/test_dashboard_compat.py`): 7 tests total. Three parametrised Playwright tests (Chromium / Firefox / WebKit) verify no JS console errors, grade badge visible (`.grade-badge`), finding rows present (`.findings-table`), dark-mode toggle works (`.theme-toggle`), and SVG attack graph rendered (`#graph-svg`). Four structural tests run without a browser: no external CDN references in dashboard HTML, D3 bundled inline, scan data JSON embedded, grade letter present. Playwright tests skip gracefully when browser binaries are not installed.
- **Playwright browser install step** in `.github/workflows/ci.yml`: runs `playwright install --with-deps chromium firefox webkit` on the `ubuntu-latest / 3.12` leg only, before the test step. Browser tests are skipped on all other matrix legs.
- `GAPS.md` — "SARIF not tested with GitHub" and "Dashboard browser compatibility untested" items resolved (2026-04-23).

---

## [0.7.0] - 2026-04-23 — Platform Coverage & CI Hardening

### Added
- **End-to-end binary smoke test** (`scripts/smoke_test.py`): cross-platform Python script (stdlib only) that runs 8 checks against the built binary: `version`, `discover`, scan of a malicious fixture (asserts exit 1), JSON output validity (findings, score, per-finding keys), clean scan (asserts exit 0), `--severity-threshold critical` filtering, SARIF 2.1.0 structure, and baseline save/list/delete roundtrip.
- **Smoke test fixture** (`tests/fixtures/smoke_test_config.json`): self-contained config with a poisoned server (triggers POISON-001) and a credential server (triggers credential finding via `sk-[A-Za-z0-9]{20,}` pattern). Used by both the binary smoke test and `tests/test_smoke_fixture.py`.
- **`tests/test_smoke_fixture.py`**: 4 unit tests that keep the smoke fixture honest without requiring a binary build — verifies POISON-001, a credential finding, and at least one finding overall.
- **Binary size gate** in `release.yml`: warns at 25 MB, fails at 35 MB. Actual size post-sigstore is ~22–24 MB; thresholds will be tightened after first rebuild measurement.
- **Release job summary** (`report` job in `release.yml`): posts a binary-size table to the GitHub job summary after every release build.
- **PR-level binary build** (`binary-smoke` job in `ci.yml`): builds the Linux x86_64 binary with PyInstaller and runs the full smoke test on every PR and push to `main`. Catches PyInstaller breakage before tagging.

### Fixed
- `release.yml` — replaced one-line `mcp-audit version` smoke test with the full 8-check `smoke_test.py` workflow on all four platforms.

---

## [0.6.0] - 2026-04-23 — Supply Chain Layers 2 & 3

### Added
- **Layer 2: Sigstore provenance verification** (`attestation/sigstore_client.py`, `attestation/sigstore_findings.py`): opt-in `--verify-signatures` flag (free, default OFF) verifies Sigstore provenance bundles for registry-known npm and PyPI packages. Fetches bundles from the npm attestations API and PyPI PEP 740 provenance API; verifies with the `sigstore` Python library (Fulcio cert chain, SCT, Rekor inclusion proof); extracts OIDC issuer (OID `1.3.6.1.4.1.57264.1.1`) and SAN URI from the signing certificate; compares signing repo against `RegistryEntry.repo`. `--strict-signatures` raises "absent" findings from INFO to MEDIUM. Six new finding IDs: `ATTEST-010` (valid match, INFO), `ATTEST-011` (valid but wrong repo, HIGH), `ATTEST-012` (invalid signature, CRITICAL), `ATTEST-013` (expected attestation absent, MEDIUM), `ATTEST-014` (absent, INFO/MEDIUM), `ATTEST-015` (network error, INFO). `attestation_expected: bool = False` field added to `RegistryEntry`; set to `true` for all 26 Anthropic-maintained entries in the registry.
- `sigstore>=3.0,<4.0` added to package dependencies.
- `docs/supply-chain.md` — Layer 2 section documenting all finding IDs, flag behaviour, and `--strict-signatures` usage.
- `docs/severity-framework.md` — `ATTEST-010` through `ATTEST-015` severity table.

- **Layer 3: Known-vulnerability scanning** (`vulnerability/` module): opt-in `--check-vulns` flag (free, default OFF) resolves transitive dependencies via the deps.dev API and checks them against OSV.dev in a single batched call. Full transitive graph coverage (not just direct deps). Graceful degradation on network failure per batch — scan never crashes. `VULN-<OSV-ID>` findings (severity from CVSS score), `VULN-UNPINNED` (LOW) for unversioned packages. Supports npx/bunx/pnpx/uvx/pipx/yarn-dlx ecosystems via the shared `vulnerability/resolver.py`. `--vuln-registry URL` (Pro soft-gate) for air-gapped OSV mirrors.
- **`mcp-audit sbom` command** (`cli/sbom.py`): generates a CycloneDX 1.5 JSON SBOM for all configured MCP servers and their transitive dependencies. `cyclonedx-python-lib` is an optional `[sbom]` extra (not bundled in the PyInstaller binary); the command prints a clear install instruction if absent. Supports `--format cyclonedx` (default) and `--format terminal` (Rich dependency tree). `--output PATH` writes to file.
- **`_network.py` — unified `--offline` contract**: `NetworkPolicy` dataclass + `require_offline_compatible()` replaces all scattered `if offline and <flag>` guards in `_preflight_checks`. Now covers `--verify-hashes`, `--verify-signatures`, `--check-vulns`, and `--connect` in one place.
- `"vuln_mirror": frozenset({"pro", "enterprise"})` feature key added to `licensing.py`.

### Notes
- Binary size advisory: the `sigstore` dependency tree (`betterproto`, `tuf`, `rfc3161-client`, `securesystemslib`) is expected to push the PyInstaller binary above the 22 MB target. Three mitigation options documented in `attestation/sigstore_client.py`; a rebuild is required before the next release cut to measure actual impact. `cyclonedx-python-lib` excluded from PyInstaller specs to contain further growth.

---

## [0.5.0] - 2026-04-23 — Detection Validity, Hardening & Supply Chain Depth

### Security
- **V-07 — Unicode homoglyph bypass closed** (`poisoning.py`): Added `POISON-060` pattern matching Cyrillic, Greek, general-punctuation lookalike, and fullwidth-ASCII Unicode blocks. All patterns now run against NFKD-normalised ASCII text; `POISON-060` runs against the original bytes. Deduplication on `(id, server, evidence)` prevents duplicate findings when both the raw and normalised text match.
- **V-08 — Depth-11 nesting bypass closed** (`poisoning.py`): Recursion limit in `_extract_text_fields` and `_extract_description_fields` raised from `depth > 10` to `depth > 50`, making the depth-bypass impractical while still guarding against infinite recursion.
- **V-09 — Wildcard interface binding** (`transport.py`): New `TRANSPORT-004` finding (HIGH, CWE-1327) fires when the server URL hostname is `0.0.0.0`, `::`, `[::]`, or their equivalents. `_WILDCARD_BINDINGS` frozenset added.
- **V-10 — Privilege escalation coverage expanded** (`transport.py`): `TRANSPORT-002` now catches `pkexec`, `su`, and `run0` in addition to `sudo` and `doas`. Absolute-path forms (e.g. `/usr/bin/sudo`) detected via `_PRIV_ESC_SUFFIXES`. Privilege-escalation binary appearing as `args[0]` (e.g. `command=sh, args=["sudo", …]`) now also fires.
- **V-11 — Supply chain coverage expanded** (`transport.py`, `supply_chain.py`): `pipx` added to `_RUNTIME_FETCH_COMMANDS`. `yarn dlx` detected in both `TransportAnalyzer` (TRANSPORT-003) and `SupplyChainAnalyzer` (typosquatting); `args[1:]` slicing used when extracting the package name to skip the `dlx` token.

### Added
- **Exploit validation test suite** (`tests/test_exploit_validation.py`): Six test classes reconstruct real published attack PoCs — Invariant Labs SSH exfiltration, CrowdStrike `add_numbers`, fake Postmark base64 exfiltration, CyberArk XML `<OVERRIDE>` injection, Palo Alto Unit 42 cloud credential targeting, and MINJA behavioral override. Each class asserts specific finding IDs and severities; `TestExploitCoverage` enforces all six fixture files are present and valid JSON.
- **Exploit fixtures** (`tests/fixtures/exploits/`): Six JSON fixtures reconstructing the above PoCs from published research sources cited in `PROVENANCE.md`.
- **False-positive benchmark** (`tests/test_false_positive_benchmark.py`): Runs poisoning and credentials analyzers against 22 real-world MCP server configs (12 official `@modelcontextprotocol/*`, 10 popular community servers). Asserts 0% poisoning false-positive rate across the full set. Parametrised per-server to pinpoint regressions immediately. Acts as a merge gate — any pattern change that fires on a legitimate server fails CI.
- **Real-server fixtures** (`tests/fixtures/real_servers/`): `official_mcp_servers.json` (12 servers) and `community_mcp_servers.json` (10 servers) with realistic production configs and empty env-var values.
- **Severity framework** (`docs/severity-framework.md`): CVSS base scores and OWASP Agentic Top 10 (ASI01–ASI10) mappings for every finding ID across all six analyzers (POISON-*, CRED-*, TRANSPORT-*, SC-*, RUG-*, TOXIC-*, ATTEST-*). Includes a decision tree for calibrating new findings.
- `TRANSPORT-004` added to `docs/severity-framework.md` under the Transport analyzer table.

### Added (continued)
- **Registry metadata enrichment** (`registry/loader.py`, `registry/known-servers.json`): Three optional fields added to `RegistryEntry` — `first_published` (ISO date), `weekly_downloads` (integer), `publisher_history` (list of publisher account names, most-recent first). Populated for 10 entries; registry grew from 60 to 64 entries with four new community servers (`@linear/mcp-server`, `exa-mcp-server`, `@notion/mcp-server`, `mcp-perplexity`). SC-001/SC-002 finding descriptions now append publish date, download count, and known publishers when data is present, giving users signal about package legitimacy. `scripts/enrich_registry.py` maintainer tool added (not shipped in wheel) to refresh metadata from the npm registry API; supports `--dry-run`.

### Fixed
- `GAPS.md` — three Detection Validity gaps closed (exploit validation, false-positive rate, severity framework); V-07 through V-11 marked resolved; registry metadata enrichment marked resolved; `--offline --verify-hashes` conflict confirmed already blocked by `_preflight_checks`.

---

## [0.4.0] - 2026-04-17 — Security Hardening & CI

### Security
- Resolved all Bandit medium+ findings; suppressed three `B310` (`urllib` URL-open) calls with inline `# nosec B310` comments and one-line justifications — no blanket suppressions.
- Bumped `cryptography` to `>=46.0.6,<47.0` to fix CVE-2026-26007 (EC subgroup validation) and CVE-2026-34073 (DNS name constraint bypass); lockfile resolves to `cryptography==46.0.7`. `pip-audit` now returns zero findings.
- Pre-launch hardening pass (V-01 through V-06): path-traversal fix via `_safe_baseline_path` + `Path.resolve()`, state file permission enforcement (`0o600`/`0o700`), bare `except:` removal, CLI input validation for `--path`/`--registry`/`--sast`/`--policy`, `subprocess.run()` converted to list form everywhere (`shell=False`).
- Converted `subprocess` calls in `sast/runner.py` to list form; introduced `SEMGREP_TIMEOUT_SECONDS = 300` constant — hardcoded timeout integers are now forbidden.

### Added
- `scripts/build-linux.sh` — Docker-based Linux x86_64 binary build inside `python:3.11-slim`; installs `binutils` via `apt-get`; prints file size and SHA-256 on success.
- `sast` and `sast-path` inputs wired into `action.yml` (GitHub Action).
- `ci.yml` — 3×2 CI matrix (Ubuntu / macOS / Windows × Python 3.11 / 3.12); `fail-fast: false`.
- `release.yml` — binary release workflow; builds four PyInstaller executables in parallel on tag push (`v*.*.*`); creates a GitHub Release with auto-generated notes.
- Four portable PyInstaller spec files (`mcp-audit-darwin-x86_64.spec`, `mcp-audit-darwin-arm64.spec`, `mcp-audit-linux-x86_64.spec`, `mcp-audit-windows-x86_64.spec`) using `SPECPATH`-relative roots.
- Full PyInstaller `hiddenimports` list; complete bundled `datas` (5 entries).
- Test coverage for PyInstaller path resolution (`_MEIPASS` monkeypatching) and license key storage path shape.
- 13 additional edge-case tests covering scanner integration scenarios, raising `scanner.py` line coverage from ~50 % to 89 %.
- Replaced hardcoded `~/.config/mcp-audit` paths with `platformdirs.user_config_dir("mcp-audit")` across all modules (baselines, registry cache, policy, rules); `licensing.py` deferred (marked do-not-modify).
- `packaging>=21.0` declared as an explicit dependency.
- Clean commit-history audit recorded before public release (credentials, private keys, internal URLs — all categories clean).

### Fixed
- `malformed JSON` errors now surfaced to the user rather than silently swallowed.
- `--no-score` correctly suppresses the `run.properties` score block in SARIF output.
- GitHub Action: workflow-level `permissions` added for SARIF upload; `codeql-action` bumped to v4; double-scan removed; SARIF path guarded.
- `httpx` moved to the `mcp` optional-dependency group (resolves V-12).

---

## [0.3.0] - 2026-04-10 — Moat Deepening

### Added
- **Governance policy engine** — YAML-based organisational requirements: approved server lists, minimum scan scores, transport constraints, registry membership, finding tolerances. New CLI commands: `policy validate`, `policy init` (Pro), `policy check` (Pro). `scan --policy PATH` flag (free) with auto-discovery (cwd → repo root → user config dir). Governance findings rendered in a distinct yellow "Policy Violations" panel in terminal output; SARIF findings tagged `governance-policy` with `GOV-` rule IDs. `governance` and `fleet_governance` feature keys.
- **Supply chain attestation — Layer 1** — hash-based integrity verification via `attestation/hasher.py` and `attestation/verifier.py`. `scan --verify-hashes` downloads package tarballs and computes SHA-256 against `known_hashes` pins in `RegistryEntry`. `mcp-audit verify` standalone free-tier command. Five registry entries seeded with real hashes. Attestation findings use `analyzer="attestation"` (CRITICAL for mismatches, INFO for unverifiable).
- **Semgrep SAST rule pack** — 37 rules (28 Python, 9 TypeScript) across 5 categories (injection, poisoning, credential, protocol, transport). Runnable standalone (`semgrep --config semgrep-rules/ <path>`) or integrated (`mcp-audit scan --sast <path>`). `mcp-audit sast <path>` standalone command. Pro-gated integration; `sast` feature key. Bundled in pip wheel and PyInstaller binary. `SastResult` model; Semgrep auto-discovery; severity mapping.
- **IDE extension security scanner** — discovers extensions across VS Code, Cursor, Windsurf, and Augment. Six analysis layers: known-vuln registry, dangerous capability combos, wildcard activation, unknown publisher, sideloaded VSIX, stale AI extensions. `mcp-audit extensions discover` (free) and `mcp-audit extensions scan` (Pro). `scan --include-extensions` flag (Pro). `registry/known-extension-vulns.json` seed dataset (5 entries). `extensions` and `fleet_extensions` feature keys. Findings use `analyzer="extensions"`.

---

## [0.2.0] - 2026-04-07 — Chain Reaction

### Added
- **Scan score & grade** — every scan produces a numeric score (0–100) and letter grade (A–F) via `scoring.py`. Grade panel rendered in terminal output. `scan --no-score` suppresses the terminal panel only; score still present in JSON/HTML. JSON output includes top-level `score` and `grade` fields. SARIF `run.properties` block carries `mcp-audit/grade`, `mcp-audit/numericScore`, `mcp-audit/positiveSignals`, and `mcp-audit/deductions`.
- **Known-server registry** — `registry/known-servers.json` curated dataset (57 entries) replaces hardcoded YAML in the supply chain analyzer. `KnownServerRegistry` loader with Levenshtein typosquatting detection. `update-registry` command (Pro) fetches latest registry from GitHub to user-local cache. `scan --registry PATH` override; `scan --offline-registry` flag. Registry stats dim one-liner appended to terminal output.
- **Baseline snapshot & drift detection** — five `baseline` sub-commands: `save`, `list`, `compare`, `delete`, `export`. `scan --baseline NAME` (or `--baseline latest`) injects `DriftFinding`s (converted to `Finding` objects with `analyzer="baseline"`) into all output formats. Storage at `<user-config-dir>/mcp-audit/baselines/` with `0o700`/`0o600` permissions. Environment variable values never stored, only key names.
- **GitHub Action** (`action.yml`) — composite action; inputs: `severity-threshold`, `format`, `config-paths`, `baseline`, `upload-sarif`; outputs: `finding-count`, `grade`, `sarif-path`. Uploads SARIF to GitHub Security tab; writes job summary. Exit-1-safe design.
- **Fleet merge** (`mcp-audit merge`) — consolidates JSON scan outputs from multiple machines into a single fleet report. Deduplicates findings by `(analyzer, server_name, title)`. Supports terminal, JSON, and HTML output. Enterprise-gated via `fleet_merge` feature key.
- **Policy-as-code rule engine** — YAML-based custom detection rules. 12 community rules (`COMM-001` through `COMM-012`) bundled and run for all users (free tier). `rule validate`, `rule test`, `rule list` sub-commands. `scan --rules-dir PATH` and user-local rules directory for Pro users. `custom_rules` feature key. Rule findings use `analyzer="rules"`. Community rules always run regardless of license tier.
- **Pre-commit hook** (`.pre-commit-hooks.yaml`) — `language: python`, `entry: mcp-audit`, `pass_filenames: false`, `types: [json]`. Default threshold is HIGH. Example configs in `examples/pre-commit/` (basic and strict).
- **Ed25519 license key system** — fully offline verification (public key hardcoded in `licensing.py`; private key never ships). `mcp-audit activate <key>` and `mcp-audit license` commands. License stored at `~/.config/mcp-audit/license.key` (permissions `0o600`). Three tiers: Community, Pro, Enterprise. `scripts/generate_license.py` (not shipped in package).
- `scan --policy PATH` auto-discovery: cwd → git repo root → user config dir → `None` (no check).
- `scan --output-file PATH` (alias `--output` / `-o`) with automatic parent directory creation.
- `scan --severity-threshold LEVEL` filters findings and drives exit code.
- Terminal output: dim registry stats one-liner after summary.
- Machine identification (`MachineInfo`) embedded in scan output; `--asset-prefix` flag for fleet deployments.
- `offline-registry` flag; SARIF score properties block.
- Example workflows: `examples/github-actions/basic.yml`, `strict.yml`, `with-baseline.yml`.
- Example pre-commit configs: `examples/pre-commit/basic.yaml`, `strict.yaml`.
- `examples/policies/` — sample governance policy files.

### Fixed
- `html_report` proxy gate replaced with dedicated `update_registry` feature key.

---

## [0.1.0] - 2026-04-01 — Prototype

### Added
- Initial working CLI scaffold using Typer + Rich, Pydantic v2 data models, pytest suite.
- **Six security analyzers:**
  - `poisoning.py` — tool-description poisoning detection (14 regex patterns).
  - `credentials.py` — secret/API-key exposure in configs (9 patterns).
  - `transport.py` — transport security (TLS, localhost binding).
  - `supply_chain.py` — package provenance and typosquatting via Levenshtein distance.
  - `rug_pull.py` — description-change detection using stateful config hashing; state scoped per config-set at `~/.mcp-audit/state.json`.
  - `toxic_flow.py` — cross-server capability tagging and dangerous pair detection; live MCP server enumeration via `--connect`.
- **Attack path engine** (`attack_paths.py`) — multi-hop detection (up to 4 servers), greedy hitting set algorithm, `summarize_attack_paths()`.
- **Eight supported MCP clients** — Claude Desktop, Cursor, VS Code, Windsurf, Claude Code (user-scoped), Claude Code (project-scoped), GitHub Copilot CLI, Augment Code.
- **Five output formats** — terminal (Rich), JSON, SARIF 2.1.0, Nucleus FlexConnect, self-contained HTML dashboard.
- **Interactive HTML dashboard** — embedded D3 v7 attack graph, light/dark mode toggle, grade badge, empty-state handling. D3 bundled from `data/d3.v7.min.js`.
- `mcp-audit watch` — filesystem watcher for continuous monitoring; re-scans on config change.
- `mcp-audit discover` — lists discovered MCP config paths across all clients.
- **Demo environment** (`demo/`) — produces 27+ findings across all analyzer categories.
- PyInstaller build pipeline (`build.py`) — 16.6 MB standalone binary, no Python required.
- `BaseAnalyzer` abstract class; `BaseFormatter` abstract class.
- `Finding`, `ServerConfig`, `ScanResult`, `ScanScore`, `Severity`, `AttackPath`, `MachineInfo` Pydantic models.
- Security review and patch pass — six vulnerabilities fixed (V-01 through V-06); internal findings V-07 through V-17 documented in `GAPS.md`.
- `GAPS.md` — known detection-quality limitations, severity calibration issues, untested areas.
- `PROVENANCE.md` — research attribution for all detection patterns.

---

_This changelog covers the full pre-release development history. The first public version tag will be added here when the initial release is cut._
