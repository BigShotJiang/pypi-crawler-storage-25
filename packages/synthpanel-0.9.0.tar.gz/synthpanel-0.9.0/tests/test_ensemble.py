"""Tests for multi-model ensemble: per-persona model routing (sp-blend)."""

from __future__ import annotations

import threading
from typing import Any
from unittest.mock import MagicMock

import pytest

from synth_panel.cli.commands import assign_models_to_personas, parse_models_spec
from synth_panel.cli.parser import build_parser
from synth_panel.cost import ZERO_USAGE
from synth_panel.llm.models import (
    CompletionResponse,
    StopReason,
    TextBlock,
)
from synth_panel.llm.models import (
    TokenUsage as LLMTokenUsage,
)
from synth_panel.orchestrator import PanelistResult, run_panel_parallel

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_text_response(text: str = "Hello!", usage: LLMTokenUsage | None = None) -> CompletionResponse:
    return CompletionResponse(
        id="resp-1",
        model="claude-sonnet",
        content=[TextBlock(text=text)],
        stop_reason=StopReason.END_TURN,
        usage=usage or LLMTokenUsage(input_tokens=10, output_tokens=5),
    )


def _simple_system_prompt(persona: dict[str, Any]) -> str:
    return f"You are {persona.get('name', 'Anonymous')}."


def _simple_question_prompt(question: dict[str, Any]) -> str:
    if isinstance(question, dict):
        return question.get("text", str(question))
    return str(question)


def _make_mock_client(responses: list[CompletionResponse] | None = None) -> MagicMock:
    client = MagicMock()
    if responses:
        lock = threading.Lock()
        resp_list = list(responses)

        def thread_safe_send(request):
            with lock:
                if resp_list:
                    return resp_list.pop(0)
            return _make_text_response("fallback")

        client.send = MagicMock(side_effect=thread_safe_send)
    else:
        client.send = MagicMock(return_value=_make_text_response())
    return client


# ---------------------------------------------------------------------------
# Tests: parse_models_spec
# ---------------------------------------------------------------------------


class TestParseModelsSpec:
    def test_basic_two_models(self):
        result = parse_models_spec("haiku:0.5,gemini-2.5-flash:0.5")
        assert result == [("haiku", 0.5), ("gemini-2.5-flash", 0.5)]

    def test_single_model(self):
        result = parse_models_spec("haiku:1.0")
        assert result == [("haiku", 1.0)]

    def test_three_models_unequal_weights(self):
        result = parse_models_spec("haiku:0.5,sonnet:0.3,gemini:0.2")
        assert len(result) == 3
        assert result[0] == ("haiku", 0.5)
        assert result[1] == ("sonnet", 0.3)
        assert result[2] == ("gemini", 0.2)

    def test_whitespace_tolerance(self):
        result = parse_models_spec(" haiku : 0.5 , gemini : 0.5 ")
        assert result == [("haiku", 0.5), ("gemini", 0.5)]

    def test_ensemble_no_weights(self):
        """Model names without weights are treated as ensemble spec."""
        result = parse_models_spec("haiku,sonnet")
        assert result == [("haiku", 1.0), ("sonnet", 1.0)]

    def test_ensemble_single_model(self):
        result = parse_models_spec("haiku")
        assert result == [("haiku", 1.0)]

    def test_ensemble_three_models(self):
        result = parse_models_spec("haiku,sonnet,gemini")
        assert result == [("haiku", 1.0), ("sonnet", 1.0), ("gemini", 1.0)]

    def test_mixed_raises(self):
        """Mixing weighted and unweighted entries raises."""
        with pytest.raises(ValueError, match="expected 'model:weight'"):
            parse_models_spec("haiku,sonnet:0.5")

    def test_invalid_weight_raises(self):
        with pytest.raises(ValueError, match="must be a number"):
            parse_models_spec("haiku:abc")

    def test_zero_weight_raises(self):
        with pytest.raises(ValueError, match="must be positive"):
            parse_models_spec("haiku:0")

    def test_negative_weight_raises(self):
        with pytest.raises(ValueError, match="must be positive"):
            parse_models_spec("haiku:-1")

    def test_empty_spec_raises(self):
        with pytest.raises(ValueError, match="Empty --models spec"):
            parse_models_spec("")

    def test_empty_model_name_raises(self):
        with pytest.raises(ValueError, match="Empty model name"):
            parse_models_spec(":0.5")


# ---------------------------------------------------------------------------
# Tests: assign_models_to_personas
# ---------------------------------------------------------------------------


class TestAssignModelsToPersonas:
    def test_even_split_two_models(self):
        personas = [{"name": f"P{i}"} for i in range(10)]
        spec = [("haiku", 0.5), ("gemini", 0.5)]
        result = assign_models_to_personas(personas, spec, "sonnet")
        haiku_count = sum(1 for v in result.values() if v == "haiku")
        gemini_count = sum(1 for v in result.values() if v == "gemini")
        assert haiku_count == 5
        assert gemini_count == 5

    def test_uneven_split(self):
        personas = [{"name": f"P{i}"} for i in range(10)]
        spec = [("haiku", 0.7), ("gemini", 0.3)]
        result = assign_models_to_personas(personas, spec, "sonnet")
        haiku_count = sum(1 for v in result.values() if v == "haiku")
        gemini_count = sum(1 for v in result.values() if v == "gemini")
        assert haiku_count == 7
        assert gemini_count == 3

    def test_yaml_override_takes_precedence(self):
        personas = [
            {"name": "Alice", "model": "opus"},
            {"name": "Bob"},
            {"name": "Charlie"},
        ]
        spec = [("haiku", 0.5), ("gemini", 0.5)]
        result = assign_models_to_personas(personas, spec, "sonnet")
        assert result["Alice"] == "opus"
        # Bob and Charlie get weighted assignment
        assert result["Bob"] in ("haiku", "gemini")
        assert result["Charlie"] in ("haiku", "gemini")

    def test_all_yaml_overrides(self):
        personas = [
            {"name": "Alice", "model": "opus"},
            {"name": "Bob", "model": "haiku"},
        ]
        spec = [("gemini", 1.0)]
        result = assign_models_to_personas(personas, spec, "sonnet")
        assert result["Alice"] == "opus"
        assert result["Bob"] == "haiku"

    def test_single_persona(self):
        personas = [{"name": "Solo"}]
        spec = [("haiku", 0.5), ("gemini", 0.5)]
        result = assign_models_to_personas(personas, spec, "sonnet")
        assert len(result) == 1
        assert result["Solo"] in ("haiku", "gemini")

    def test_all_assigned_to_single_model(self):
        personas = [{"name": f"P{i}"} for i in range(5)]
        spec = [("haiku", 1.0)]
        result = assign_models_to_personas(personas, spec, "sonnet")
        assert all(v == "haiku" for v in result.values())


# ---------------------------------------------------------------------------
# Tests: CLI parser --models
# ---------------------------------------------------------------------------


class TestParserModelsFlag:
    def test_models_flag_parsed(self):
        parser = build_parser()
        args = parser.parse_args(
            ["panel", "run", "--personas", "p.yaml", "--instrument", "i.yaml", "--models", "haiku:0.5,gemini:0.5"]
        )
        assert args.models == "haiku:0.5,gemini:0.5"

    def test_models_default_none(self):
        parser = build_parser()
        args = parser.parse_args(["panel", "run", "--personas", "p.yaml", "--instrument", "i.yaml"])
        assert args.models is None


# ---------------------------------------------------------------------------
# Tests: orchestrator per-persona model routing
# ---------------------------------------------------------------------------


class TestOrchestratorPersonaModels:
    def test_persona_models_routing(self):
        """Each panelist result records its assigned model."""
        client = _make_mock_client()
        personas = [
            {"name": "Alice"},
            {"name": "Bob"},
        ]
        questions = [{"text": "Hello?"}]
        persona_models = {"Alice": "haiku", "Bob": "gemini"}

        results, _reg, _sess = run_panel_parallel(
            client=client,
            personas=personas,
            questions=questions,
            model="sonnet",
            system_prompt_fn=_simple_system_prompt,
            question_prompt_fn=_simple_question_prompt,
            persona_models=persona_models,
        )

        result_map = {r.persona_name: r for r in results}
        assert result_map["Alice"].model == "haiku"
        assert result_map["Bob"].model == "gemini"

    def test_default_model_when_no_persona_models(self):
        """Without persona_models, all panelists use the global model."""
        client = _make_mock_client()
        personas = [{"name": "Alice"}, {"name": "Bob"}]
        questions = [{"text": "Hello?"}]

        results, _reg, _sess = run_panel_parallel(
            client=client,
            personas=personas,
            questions=questions,
            model="sonnet",
            system_prompt_fn=_simple_system_prompt,
            question_prompt_fn=_simple_question_prompt,
        )

        for r in results:
            assert r.model == "sonnet"

    def test_partial_persona_models(self):
        """Personas not in persona_models dict fall back to global model."""
        client = _make_mock_client()
        personas = [{"name": "Alice"}, {"name": "Bob"}]
        questions = [{"text": "Hello?"}]
        persona_models = {"Alice": "haiku"}

        results, _reg, _sess = run_panel_parallel(
            client=client,
            personas=personas,
            questions=questions,
            model="sonnet",
            system_prompt_fn=_simple_system_prompt,
            question_prompt_fn=_simple_question_prompt,
            persona_models=persona_models,
        )

        result_map = {r.persona_name: r for r in results}
        assert result_map["Alice"].model == "haiku"
        assert result_map["Bob"].model == "sonnet"


# ---------------------------------------------------------------------------
# Tests: PanelistResult model field
# ---------------------------------------------------------------------------


class TestPanelistResultModel:
    def test_model_field_default_none(self):
        pr = PanelistResult(persona_name="Test", responses=[], usage=ZERO_USAGE)
        assert pr.model is None

    def test_model_field_set(self):
        pr = PanelistResult(persona_name="Test", responses=[], usage=ZERO_USAGE, model="haiku")
        assert pr.model == "haiku"


# ---------------------------------------------------------------------------
# Tests: is_ensemble_spec
# ---------------------------------------------------------------------------


class TestIsEnsembleSpec:
    def test_ensemble_spec(self):
        from synth_panel.cli.commands import is_ensemble_spec

        assert is_ensemble_spec("haiku,sonnet") is True
        assert is_ensemble_spec("haiku") is True

    def test_weighted_spec(self):
        from synth_panel.cli.commands import is_ensemble_spec

        assert is_ensemble_spec("haiku:0.5,sonnet:0.5") is False

    def test_mixed_spec(self):
        from synth_panel.cli.commands import is_ensemble_spec

        assert is_ensemble_spec("haiku,sonnet:0.5") is False


# ---------------------------------------------------------------------------
# Tests: ensemble_run (multi-model runner loop)
# ---------------------------------------------------------------------------


class TestEnsembleRun:
    """Test ensemble_run: sequential N panel runs with per-model cost aggregation."""

    def _mock_run_parallel(self, **kwargs):
        """Side effect for mocked run_panel_parallel."""
        from synth_panel.cost import TokenUsage as CostTokenUsage

        model = kwargs["model"]
        personas = kwargs["personas"]
        results = [
            PanelistResult(
                persona_name=p["name"],
                responses=[{"question": "Q1", "response": f"answer from {model}", "error": False}],
                usage=CostTokenUsage(input_tokens=100, output_tokens=50),
                model=model,
            )
            for p in personas
        ]
        sessions = {p["name"]: MagicMock() for p in personas}
        return results, MagicMock(), sessions

    def test_runs_once_per_model(self):
        """ensemble_run should call run_panel_parallel once per model."""
        from unittest.mock import patch as _patch

        from synth_panel.ensemble import ensemble_run as _ensemble_run

        personas = [{"name": "Alice"}, {"name": "Bob"}]
        questions = [{"text": "Q1"}]
        models = ["haiku", "sonnet"]
        client = MagicMock()

        with _patch("synth_panel.ensemble.run_panel_parallel") as mock_rpp:
            mock_rpp.side_effect = lambda **kw: self._mock_run_parallel(**kw)
            _ensemble_run(personas, questions, models, client)

        assert mock_rpp.call_count == 2
        assert mock_rpp.call_args_list[0][1]["model"] == "haiku"
        assert mock_rpp.call_args_list[1][1]["model"] == "sonnet"

    def test_per_model_results_stored_separately(self):
        from unittest.mock import patch as _patch

        from synth_panel.ensemble import EnsembleResult as _ER
        from synth_panel.ensemble import ensemble_run as _ensemble_run

        personas = [{"name": "Alice"}]
        questions = [{"text": "Q1"}]
        models = ["haiku", "sonnet"]
        client = MagicMock()

        with _patch("synth_panel.ensemble.run_panel_parallel") as mock_rpp:
            mock_rpp.side_effect = lambda **kw: self._mock_run_parallel(**kw)
            result = _ensemble_run(personas, questions, models, client)

        assert isinstance(result, _ER)
        assert len(result.model_results) == 2
        assert result.model_results[0].model == "haiku"
        assert result.model_results[1].model == "sonnet"

    def test_per_model_cost_breakdown(self):
        from unittest.mock import patch as _patch

        from synth_panel.ensemble import ensemble_run as _ensemble_run

        personas = [{"name": "Alice"}, {"name": "Bob"}]
        questions = [{"text": "Q1"}]
        models = ["haiku", "sonnet"]
        client = MagicMock()

        with _patch("synth_panel.ensemble.run_panel_parallel") as mock_rpp:
            mock_rpp.side_effect = lambda **kw: self._mock_run_parallel(**kw)
            result = _ensemble_run(personas, questions, models, client)

        assert "haiku" in result.per_model_cost
        assert "sonnet" in result.per_model_cost
        assert result.per_model_cost["haiku"].startswith("$")
        assert result.per_model_cost["sonnet"].startswith("$")

    def test_total_cost_aggregated(self):
        from unittest.mock import patch as _patch

        from synth_panel.ensemble import ensemble_run as _ensemble_run

        personas = [{"name": "Alice"}]
        questions = [{"text": "Q1"}]
        models = ["haiku", "sonnet"]
        client = MagicMock()

        with _patch("synth_panel.ensemble.run_panel_parallel") as mock_rpp:
            mock_rpp.side_effect = lambda **kw: self._mock_run_parallel(**kw)
            result = _ensemble_run(personas, questions, models, client)

        assert result.total_cost.total_cost > 0
        model_costs_sum = sum(mr.cost.total_cost for mr in result.model_results)
        assert abs(result.total_cost.total_cost - model_costs_sum) < 1e-10

    def test_total_usage_aggregated(self):
        from unittest.mock import patch as _patch

        from synth_panel.ensemble import ensemble_run as _ensemble_run

        personas = [{"name": "Alice"}]
        questions = [{"text": "Q1"}]
        models = ["haiku", "sonnet"]
        client = MagicMock()

        with _patch("synth_panel.ensemble.run_panel_parallel") as mock_rpp:
            mock_rpp.side_effect = lambda **kw: self._mock_run_parallel(**kw)
            result = _ensemble_run(personas, questions, models, client)

        # Each model: 100 input + 50 output per persona, 1 persona, 2 models
        assert result.total_usage.input_tokens == 200
        assert result.total_usage.output_tokens == 100

    def test_empty_models_raises(self):
        from synth_panel.ensemble import ensemble_run as _ensemble_run

        with pytest.raises(ValueError, match="models list must not be empty"):
            _ensemble_run([], [], [], MagicMock())

    def test_panelist_results_tagged_with_model(self):
        from unittest.mock import patch as _patch

        from synth_panel.ensemble import ensemble_run as _ensemble_run

        personas = [{"name": "Alice"}, {"name": "Bob"}]
        questions = [{"text": "Q1"}]
        models = ["haiku", "sonnet"]
        client = MagicMock()

        with _patch("synth_panel.ensemble.run_panel_parallel") as mock_rpp:
            mock_rpp.side_effect = lambda **kw: self._mock_run_parallel(**kw)
            result = _ensemble_run(personas, questions, models, client)

        for mr in result.model_results:
            for pr in mr.panelist_results:
                assert pr.model == mr.model

    def test_metadata_counts(self):
        from unittest.mock import patch as _patch

        from synth_panel.ensemble import ensemble_run as _ensemble_run

        personas = [{"name": "Alice"}, {"name": "Bob"}, {"name": "Carol"}]
        questions = [{"text": "Q1"}, {"text": "Q2"}]
        models = ["haiku"]
        client = MagicMock()

        with _patch("synth_panel.ensemble.run_panel_parallel") as mock_rpp:
            mock_rpp.side_effect = lambda **kw: self._mock_run_parallel(**kw)
            result = _ensemble_run(personas, questions, models, client)

        assert result.persona_count == 3
        assert result.question_count == 2
        assert result.models == ["haiku"]


# ---------------------------------------------------------------------------
# Tests: CLI parser --models ensemble format
# ---------------------------------------------------------------------------


class TestParserEnsembleModels:
    def test_models_ensemble_flag_parsed(self):
        parser = build_parser()
        args = parser.parse_args(
            ["panel", "run", "--personas", "p.yaml", "--instrument", "i.yaml", "--models", "haiku,sonnet"]
        )
        assert args.models == "haiku,sonnet"


# ---------------------------------------------------------------------------
# Tests: blend_distributions
# ---------------------------------------------------------------------------


class TestBlendDistributions:
    """Tests for the blend_distributions function."""

    def _make_ensemble_result(
        self,
        models: list[str],
        model_responses: dict[str, list[list[dict]]],
    ):
        """Build an EnsembleResult from per-model response dicts.

        model_responses maps model -> list of panelist response lists.
        Each panelist response list is a list of response dicts.
        """
        from synth_panel.cost import CostEstimate, TokenUsage
        from synth_panel.ensemble import EnsembleResult, ModelRunResult

        model_results = []
        total_usage = ZERO_USAGE
        for m in models:
            panelist_results = []
            for i, responses in enumerate(model_responses[m]):
                pr = PanelistResult(
                    persona_name=f"P{i}",
                    responses=responses,
                    usage=TokenUsage(input_tokens=10, output_tokens=5),
                    model=m,
                )
                panelist_results.append(pr)

            mr = ModelRunResult(
                model=m,
                panelist_results=panelist_results,
                usage=TokenUsage(input_tokens=20, output_tokens=10),
                cost=CostEstimate(input_cost=0.001, output_cost=0.001),
                sessions={},
            )
            model_results.append(mr)
            total_usage = total_usage + mr.usage

        return EnsembleResult(
            model_results=model_results,
            models=models,
            total_usage=total_usage,
            total_cost=CostEstimate(input_cost=0.002, output_cost=0.002),
            per_model_cost={m: "$0.00" for m in models},
            per_model_usage={m: {"input_tokens": 20, "output_tokens": 10} for m in models},
            persona_count=len(model_responses[models[0]]),
            question_count=len(model_responses[models[0]][0]) if model_responses[models[0]] else 0,
        )

    def test_equal_weights_two_models_unanimous(self):
        """When both models agree, blended distribution has 100% for one option."""
        from synth_panel.ensemble import blend_distributions

        # Both models, both panelists say "A"
        ensemble = self._make_ensemble_result(
            models=["haiku", "gemini"],
            model_responses={
                "haiku": [
                    [{"question": "Pick one", "response": "A"}],
                    [{"question": "Pick one", "response": "A"}],
                ],
                "gemini": [
                    [{"question": "Pick one", "response": "A"}],
                    [{"question": "Pick one", "response": "A"}],
                ],
            },
        )

        result = blend_distributions(ensemble)
        assert len(result.questions) == 1
        assert result.questions[0].distribution["A"] == pytest.approx(1.0)
        assert result.weights["haiku"] == pytest.approx(0.5)
        assert result.weights["gemini"] == pytest.approx(0.5)

    def test_equal_weights_models_disagree(self):
        """When models fully disagree, each option gets 50%."""
        from synth_panel.ensemble import blend_distributions

        ensemble = self._make_ensemble_result(
            models=["haiku", "gemini"],
            model_responses={
                "haiku": [
                    [{"question": "Pick one", "response": "A"}],
                ],
                "gemini": [
                    [{"question": "Pick one", "response": "B"}],
                ],
            },
        )

        result = blend_distributions(ensemble)
        dist = result.questions[0].distribution
        assert dist["A"] == pytest.approx(0.5)
        assert dist["B"] == pytest.approx(0.5)

    def test_custom_weights(self):
        """Custom weights bias toward the heavier model."""
        from synth_panel.ensemble import blend_distributions

        ensemble = self._make_ensemble_result(
            models=["haiku", "gemini"],
            model_responses={
                "haiku": [
                    [{"question": "Pick one", "response": "A"}],
                ],
                "gemini": [
                    [{"question": "Pick one", "response": "B"}],
                ],
            },
        )

        result = blend_distributions(ensemble, weights={"haiku": 0.8, "gemini": 0.2})
        dist = result.questions[0].distribution
        assert dist["A"] == pytest.approx(0.8)
        assert dist["B"] == pytest.approx(0.2)
        assert result.weights["haiku"] == pytest.approx(0.8)
        assert result.weights["gemini"] == pytest.approx(0.2)

    def test_multiple_questions(self):
        """Blending works across multiple questions."""
        from synth_panel.ensemble import blend_distributions

        ensemble = self._make_ensemble_result(
            models=["haiku", "gemini"],
            model_responses={
                "haiku": [
                    [
                        {"question": "Q1", "response": "A"},
                        {"question": "Q2", "response": "X"},
                    ],
                ],
                "gemini": [
                    [
                        {"question": "Q1", "response": "B"},
                        {"question": "Q2", "response": "X"},
                    ],
                ],
            },
        )

        result = blend_distributions(ensemble)
        assert len(result.questions) == 2
        # Q1: split between A and B
        assert result.questions[0].distribution["A"] == pytest.approx(0.5)
        assert result.questions[0].distribution["B"] == pytest.approx(0.5)
        # Q2: unanimous X
        assert result.questions[1].distribution["X"] == pytest.approx(1.0)

    def test_intra_model_distribution(self):
        """Multiple panelists within a model create a proper distribution."""
        from synth_panel.ensemble import blend_distributions

        # haiku: 2 say A, 1 says B -> haiku dist: A=2/3, B=1/3
        # gemini: all say B -> gemini dist: B=1.0
        # equal weights: A = 0.5*2/3 + 0.5*0 = 1/3, B = 0.5*1/3 + 0.5*1 = 2/3
        ensemble = self._make_ensemble_result(
            models=["haiku", "gemini"],
            model_responses={
                "haiku": [
                    [{"question": "Q1", "response": "A"}],
                    [{"question": "Q1", "response": "A"}],
                    [{"question": "Q1", "response": "B"}],
                ],
                "gemini": [
                    [{"question": "Q1", "response": "B"}],
                    [{"question": "Q1", "response": "B"}],
                    [{"question": "Q1", "response": "B"}],
                ],
            },
        )

        result = blend_distributions(ensemble)
        dist = result.questions[0].distribution
        assert dist["A"] == pytest.approx(1 / 3, abs=1e-9)
        assert dist["B"] == pytest.approx(2 / 3, abs=1e-9)

    def test_three_models(self):
        """Blending works with three models."""
        from synth_panel.ensemble import blend_distributions

        ensemble = self._make_ensemble_result(
            models=["haiku", "gemini", "gpt"],
            model_responses={
                "haiku": [[{"question": "Q1", "response": "A"}]],
                "gemini": [[{"question": "Q1", "response": "B"}]],
                "gpt": [[{"question": "Q1", "response": "C"}]],
            },
        )

        result = blend_distributions(ensemble)
        dist = result.questions[0].distribution
        assert dist["A"] == pytest.approx(1 / 3, abs=1e-9)
        assert dist["B"] == pytest.approx(1 / 3, abs=1e-9)
        assert dist["C"] == pytest.approx(1 / 3, abs=1e-9)

    def test_per_model_distributions_preserved(self):
        """per_model field on BlendedQuestion shows each model's raw distribution."""
        from synth_panel.ensemble import blend_distributions

        ensemble = self._make_ensemble_result(
            models=["haiku", "gemini"],
            model_responses={
                "haiku": [[{"question": "Q1", "response": "A"}]],
                "gemini": [[{"question": "Q1", "response": "B"}]],
            },
        )

        result = blend_distributions(ensemble)
        bq = result.questions[0]
        assert bq.per_model["haiku"] == {"A": 1.0}
        assert bq.per_model["gemini"] == {"B": 1.0}

    def test_error_responses_excluded(self):
        """Responses flagged as errors are excluded from distributions."""
        from synth_panel.ensemble import blend_distributions

        ensemble = self._make_ensemble_result(
            models=["haiku", "gemini"],
            model_responses={
                "haiku": [
                    [{"question": "Q1", "response": "A"}],
                    [{"question": "Q1", "response": "[error: timeout]", "error": True}],
                ],
                "gemini": [
                    [{"question": "Q1", "response": "B"}],
                ],
            },
        )

        result = blend_distributions(ensemble)
        dist = result.questions[0].distribution
        # haiku: only 1 valid response (A=1.0), gemini: B=1.0
        assert dist["A"] == pytest.approx(0.5)
        assert dist["B"] == pytest.approx(0.5)

    def test_empty_ensemble_raises(self):
        """Empty model_results raises ValueError."""
        from synth_panel.ensemble import EnsembleResult, blend_distributions

        empty = EnsembleResult(
            model_results=[],
            models=[],
            total_usage=ZERO_USAGE,
            total_cost=__import__("synth_panel.cost", fromlist=["CostEstimate"]).CostEstimate(),
            per_model_cost={},
            per_model_usage={},
            persona_count=0,
            question_count=0,
        )
        with pytest.raises(ValueError, match="no model results"):
            blend_distributions(empty)

    def test_structured_response_extraction(self):
        """Structured (dict) responses are handled correctly."""
        from synth_panel.ensemble import blend_distributions

        ensemble = self._make_ensemble_result(
            models=["haiku", "gemini"],
            model_responses={
                "haiku": [
                    [{"question": "Q1", "response": {"answer": "Strongly Agree"}}],
                ],
                "gemini": [
                    [{"question": "Q1", "response": {"answer": "Disagree"}}],
                ],
            },
        )

        result = blend_distributions(ensemble)
        dist = result.questions[0].distribution
        assert "Strongly Agree" in dist
        assert "Disagree" in dist
        assert dist["Strongly Agree"] == pytest.approx(0.5)
        assert dist["Disagree"] == pytest.approx(0.5)


# ---------------------------------------------------------------------------
# Tests: CLI parser --blend flag
# ---------------------------------------------------------------------------


class TestParserBlendFlag:
    def test_blend_flag_parsed(self):
        parser = build_parser()
        args = parser.parse_args(
            [
                "panel",
                "run",
                "--personas",
                "p.yaml",
                "--instrument",
                "i.yaml",
                "--models",
                "haiku:0.5,gemini:0.5",
                "--blend",
            ]
        )
        assert args.blend is True

    def test_blend_default_false(self):
        parser = build_parser()
        args = parser.parse_args(["panel", "run", "--personas", "p.yaml", "--instrument", "i.yaml"])
        assert args.blend is False


# ---------------------------------------------------------------------------
# Tests: _match_to_option
# ---------------------------------------------------------------------------


class TestMatchToOption:
    """Tests for the _match_to_option helper."""

    def test_exact_match_case_insensitive(self):
        from synth_panel.ensemble import _match_to_option

        assert _match_to_option("Fully remote", ["Fully remote", "Hybrid 3 days"]) == "Fully remote"
        assert _match_to_option("fully remote", ["Fully remote", "Hybrid 3 days"]) == "Fully remote"
        assert _match_to_option("FULLY REMOTE", ["Fully remote", "Hybrid 3 days"]) == "Fully remote"

    def test_option_contained_in_response(self):
        from synth_panel.ensemble import _match_to_option

        options = ["Fully remote", "Hybrid 3 days", "In office"]
        assert _match_to_option("I'd definitely prefer fully remote work", options) == "Fully remote"
        assert _match_to_option("I think hybrid 3 days is best for me", options) == "Hybrid 3 days"

    def test_longest_match_wins(self):
        from synth_panel.ensemble import _match_to_option

        options = ["remote", "Fully remote"]
        assert _match_to_option("I want fully remote work", options) == "Fully remote"

    def test_response_contained_in_option(self):
        from synth_panel.ensemble import _match_to_option

        options = ["Fully remote work schedule", "Hybrid 3 days per week"]
        assert _match_to_option("hybrid 3 days", options) == "Hybrid 3 days per week"

    def test_no_match_returns_original(self):
        from synth_panel.ensemble import _match_to_option

        options = ["Fully remote", "Hybrid 3 days"]
        assert _match_to_option("Something else entirely", options) == "Something else entirely"

    def test_empty_options_returns_original(self):
        from synth_panel.ensemble import _match_to_option

        assert _match_to_option("anything", []) == "anything"


# ---------------------------------------------------------------------------
# Tests: blend_distributions with options
# ---------------------------------------------------------------------------


class TestBlendDistributionsWithOptions(TestBlendDistributions):
    """Tests for blend_distributions when questions define options."""

    def test_options_normalize_responses(self):
        """Responses are matched to defined options before aggregation."""
        from synth_panel.ensemble import blend_distributions

        ensemble = self._make_ensemble_result(
            models=["haiku", "gemini"],
            model_responses={
                "haiku": [
                    [{"question": "Work preference?", "response": "I prefer fully remote work"}],
                    [{"question": "Work preference?", "response": "Hybrid 3 days sounds good"}],
                ],
                "gemini": [
                    [{"question": "Work preference?", "response": "fully remote for me"}],
                    [{"question": "Work preference?", "response": "I'd choose in office"}],
                ],
            },
        )
        questions = [
            {"text": "Work preference?", "options": ["Fully remote", "Hybrid 3 days", "In office"]},
        ]

        result = blend_distributions(ensemble, questions=questions)
        dist = result.questions[0].distribution
        # haiku: Fully remote=0.5, Hybrid 3 days=0.5
        # gemini: Fully remote=0.5, In office=0.5
        # blended (equal weight): Fully remote=0.5, Hybrid 3 days=0.25, In office=0.25
        assert "Fully remote" in dist
        assert "Hybrid 3 days" in dist
        assert "In office" in dist
        assert dist["Fully remote"] == pytest.approx(0.5)
        assert dist["Hybrid 3 days"] == pytest.approx(0.25)
        assert dist["In office"] == pytest.approx(0.25)

    def test_structured_response_with_options(self):
        """Structured responses (pick_one) are matched to defined options."""
        from synth_panel.ensemble import blend_distributions

        ensemble = self._make_ensemble_result(
            models=["haiku", "gemini"],
            model_responses={
                "haiku": [
                    [{"question": "Q1", "response": {"choice": "fully remote", "reasoning": "I like it"}}],
                ],
                "gemini": [
                    [{"question": "Q1", "response": {"choice": "Hybrid 3 days", "reasoning": "balance"}}],
                ],
            },
        )
        questions = [
            {"text": "Q1", "options": ["Fully remote", "Hybrid 3 days", "In office"]},
        ]

        result = blend_distributions(ensemble, questions=questions)
        dist = result.questions[0].distribution
        assert "Fully remote" in dist
        assert "Hybrid 3 days" in dist
        assert dist["Fully remote"] == pytest.approx(0.5)
        assert dist["Hybrid 3 days"] == pytest.approx(0.5)

    def test_no_options_preserves_behavior(self):
        """Questions without options keep raw response values."""
        from synth_panel.ensemble import blend_distributions

        ensemble = self._make_ensemble_result(
            models=["haiku", "gemini"],
            model_responses={
                "haiku": [[{"question": "Q1", "response": "A long answer"}]],
                "gemini": [[{"question": "Q1", "response": "B long answer"}]],
            },
        )
        questions = [{"text": "Q1"}]  # no options

        result = blend_distributions(ensemble, questions=questions)
        dist = result.questions[0].distribution
        assert "A long answer" in dist
        assert "B long answer" in dist

    def test_questions_none_preserves_behavior(self):
        """When questions is None, behavior is unchanged."""
        from synth_panel.ensemble import blend_distributions

        ensemble = self._make_ensemble_result(
            models=["haiku", "gemini"],
            model_responses={
                "haiku": [[{"question": "Q1", "response": "A"}]],
                "gemini": [[{"question": "Q1", "response": "B"}]],
            },
        )

        result = blend_distributions(ensemble, questions=None)
        dist = result.questions[0].distribution
        assert dist["A"] == pytest.approx(0.5)
        assert dist["B"] == pytest.approx(0.5)

    def test_mixed_questions_some_with_options(self):
        """Only questions with options get matching; others pass through."""
        from synth_panel.ensemble import blend_distributions

        ensemble = self._make_ensemble_result(
            models=["haiku"],
            model_responses={
                "haiku": [
                    [
                        {"question": "Q1", "response": "I like fully remote"},
                        {"question": "Q2", "response": "Free-form answer here"},
                    ],
                ],
            },
        )
        questions = [
            {"text": "Q1", "options": ["Fully remote", "Hybrid", "In office"]},
            {"text": "Q2"},  # no options
        ]

        result = blend_distributions(ensemble, questions=questions)
        assert result.questions[0].distribution == {"Fully remote": pytest.approx(1.0)}
        assert result.questions[1].distribution == {"Free-form answer here": pytest.approx(1.0)}

    def test_unmatched_response_passes_through(self):
        """Responses that don't match any option are kept as-is."""
        from synth_panel.ensemble import blend_distributions

        ensemble = self._make_ensemble_result(
            models=["haiku"],
            model_responses={
                "haiku": [
                    [{"question": "Q1", "response": "Something completely different"}],
                    [{"question": "Q1", "response": "Fully remote"}],
                ],
            },
        )
        questions = [
            {"text": "Q1", "options": ["Fully remote", "Hybrid"]},
        ]

        result = blend_distributions(ensemble, questions=questions)
        dist = result.questions[0].distribution
        assert "Fully remote" in dist
        assert "Something completely different" in dist
