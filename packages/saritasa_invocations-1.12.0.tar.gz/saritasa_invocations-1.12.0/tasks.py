import os

import invoke

import invocations
import saritasa_invocations

ns = invoke.Collection(
    invocations.ci,
    invocations.docs,
    invocations.project,
    saritasa_invocations.alembic,
    saritasa_invocations.celery,
    saritasa_invocations.django,
    saritasa_invocations.docker,
    saritasa_invocations.fastapi,
    saritasa_invocations.git,
    saritasa_invocations.github_actions,
    saritasa_invocations.open_api,
    saritasa_invocations.pre_commit,
    saritasa_invocations.python,
    saritasa_invocations.system,
    saritasa_invocations.db_k8s,
    saritasa_invocations.db,
    saritasa_invocations.k8s,
    saritasa_invocations.cruft,
    saritasa_invocations.poetry,
    saritasa_invocations.pip,
    saritasa_invocations.mypy,
    saritasa_invocations.pytest,
    saritasa_invocations.secrets,
)

# Configurations for run command
ns.configure(
    {
        "run": {
            "pty": os.environ.get("INVOKE_PTY", "true").lower() == "true",
            "echo": True,
        },
        "saritasa_invocations": saritasa_invocations.Config(
            project_name="saritasa-invocations",
        ),
    },
)
