"""Queue subsystem: message format, adapter protocol, registry, built-in adapters."""
