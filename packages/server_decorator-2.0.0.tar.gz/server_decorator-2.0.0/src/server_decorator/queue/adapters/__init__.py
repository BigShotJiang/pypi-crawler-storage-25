"""Built-in queue adapters."""
