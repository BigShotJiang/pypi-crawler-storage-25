"""Contract version this package targets. Mirrors contracts/VERSION."""

CONTRACT_VERSION = "1.0.0"
