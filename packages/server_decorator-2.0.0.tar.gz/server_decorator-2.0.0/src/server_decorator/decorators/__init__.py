"""Decorators subsystem."""
