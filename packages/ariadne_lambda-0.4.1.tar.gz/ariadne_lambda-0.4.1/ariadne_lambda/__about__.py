__version__ = "0.4.1"  # Set by CI from git describe.
