print("This is file py10.py")
