print("This is file py6.py")
