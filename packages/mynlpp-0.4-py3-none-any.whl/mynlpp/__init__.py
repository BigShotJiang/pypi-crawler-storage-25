# __init__.py

# Import the content of each py file
from .py1 import *
from .py2 import *
from .py3 import *
from .py4 import *
from .py5 import *
from .py6 import *
from .py7 import *
from .py8 import *
from .py9 import *
from .py10 import *

# Optional: You can define what gets exposed when the package is imported.
__all__ = [
    "py1",
    "py2",
    "py3",
    "py4",
    "py5",
    "py6",
    "py7",
    "py8",
    "py9",
    "py10"
]