def main() -> None:
    print("Hello from richardzhi-mcp-demo!")
