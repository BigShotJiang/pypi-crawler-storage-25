"""GCS-backed global token bucket for HuggingFace API calls.

HF accounts are rate-limited at 1000 requests per 5-minute window, account-
wide. With 6+ cloud agents + workstation issuing uploads in parallel the
ceiling is hit constantly. This module shares a single token counter across
all agents via a small GCS object updated with generation-match atomic CAS.

Usage from wisent's hf_writers:
    from wisent_compute.providers.local.hf_rate import wait_for_hf_token
    wait_for_hf_token()  # blocks until 1 token available; then proceed
    api.upload_file(...)

Refill: 200 tokens/min (= 1000/5min). Burst capacity: 1000 tokens.
"""
from __future__ import annotations

import json
import os
import random
import time
from typing import Optional

_BUCKET_ENV = "WC_BUCKET"
_DEFAULT_BUCKET = "wisent-compute"
_RATE_OBJECT = "hf_rate/tokens.json"
_MAX_TOKENS = 1000
_REFILL_PER_SECOND = 200.0 / 60.0  # 200 tokens/min
_POLL_BACKOFF_BASE = 0.5
_POLL_BACKOFF_MAX = 30.0


def _get_bucket():
    try:
        from google.cloud import storage as _gcs
    except Exception:
        return None
    bucket_name = os.environ.get(_BUCKET_ENV, _DEFAULT_BUCKET)
    try:
        return _gcs.Client().bucket(bucket_name)
    except Exception:
        return None


def _now() -> float:
    return time.time()


def _read_state(bucket):
    blob = bucket.blob(_RATE_OBJECT)
    if not blob.exists():
        # Initialize with a full bucket. Race-safe: if two agents init at the
        # same moment, both write a {tokens=MAX, refilled_at=now} record;
        # whichever lands second is fine — it's still correct.
        return None, {"tokens": _MAX_TOKENS, "refilled_at": _now()}
    blob.reload()
    raw = blob.download_as_text()
    return blob.generation, json.loads(raw)


def _refill(state: dict) -> dict:
    now = _now()
    elapsed = max(0.0, now - float(state.get("refilled_at", now)))
    tokens = float(state.get("tokens", 0))
    tokens = min(_MAX_TOKENS, tokens + elapsed * _REFILL_PER_SECOND)
    return {"tokens": tokens, "refilled_at": now}


def wait_for_hf_token(n: int = 1, timeout: Optional[float] = 600.0) -> None:
    """Block until n tokens are available + atomically deducted.

    Falls through immediately (no-op) if GCS is unreachable so we never
    hard-block the caller on infra failure — the worst case is "rate-
    limit acquisition was best-effort", which is the pre-this-module
    behavior.
    """
    bucket = _get_bucket()
    if bucket is None:
        return
    deadline = None if timeout is None else _now() + timeout
    attempt = 0
    while True:
        try:
            generation, state = _read_state(bucket)
            state = _refill(state)
            if state["tokens"] >= n:
                state["tokens"] -= n
                blob = bucket.blob(_RATE_OBJECT)
                kw = {"if_generation_match": generation} if generation else {"if_generation_match": 0}
                blob.upload_from_string(json.dumps(state), **kw)
                return
            # Not enough tokens — sleep until at least n become available.
            deficit = n - state["tokens"]
            wait = deficit / _REFILL_PER_SECOND
            wait = min(_POLL_BACKOFF_MAX, max(_POLL_BACKOFF_BASE, wait))
            wait += random.uniform(0, _POLL_BACKOFF_BASE)
        except Exception:
            attempt += 1
            wait = min(_POLL_BACKOFF_MAX, _POLL_BACKOFF_BASE * (2 ** min(attempt, 5)))
            wait += random.uniform(0, _POLL_BACKOFF_BASE)
        if deadline is not None and _now() >= deadline:
            return  # timeout — best-effort, let the caller hit HF; if 429,
                    # it'll retry on next iteration anyway
        time.sleep(wait)
