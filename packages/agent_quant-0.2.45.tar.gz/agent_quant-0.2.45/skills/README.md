# Skills 目录说明

## 统一入口

**所有Skill统一使用 `agent-quant` 作为入口**，不要创建其他skill目录。

## 目录结构

```
skills/
├── README.md              # 本文档
├── agent-quant/           # 统一Skill入口
│   ├── SKILL.md           # 股票数据管理与回测Skill文档
│   └── start.sh           # 启动脚本
└── backtest/              # 【废弃】准备删除，不要更新
    └── SKILL.md
```

## 功能范围

`agent-quant` Skill 包含以下功能：
1. **数据管理**
   - `update` - 从QMT更新数据到本地数据库
   - `query` - 查询本地数据库已有数据
2. **因子分析**
   - `factor --list` - 列出可用因子
   - `factor --info` - 查看因子详情

3. **策略回测**
   - `backtest` - 策略回测（支持多引擎）
4. **引擎管理**
   - `engines` - 查看可用回测引擎

## 注意事项

- 所有新功能都添加到 `agent-quant/SKILL.md`
- `backtest/` 目录准备废弃删除，不要更新
- CLI命令统一通过 `python -m agentquant.cli` 调用
