# Publishing agentquant to PyPI

This guide explains how to publish `agentquant` to PyPI so users can install it via `pip install agentquant`.

## Prerequisites

1. **PyPI Account**: Create an account at [pypi.org](https://pypi.org)
2. **API Token**: Generate an API token at [pypi.org/manage/account/token](https://pypi.org/manage/account/token)
3. **Configure Credentials**: Store your API token

### Configure PyPI Credentials

**Option 1: Environment Variables (Recommended)**
```bash
# Windows
set TWINE_USERNAME=__token__
set TWINE_PASSWORD=pypi-your-api-token-here

# Linux/Mac
export TWINE_USERNAME=__token__
export TWINE_PASSWORD=pypi-your-api-token-here
```

**Option 2: .pypirc File**
Create `~/.pypirc` (Linux/Mac) or `%USERPROFILE%\.pypirc` (Windows):
```ini
[pypi]
username = __token__
password = pypi-your-api-token-here

[testpypi]
username = __token__
password = pypi-your-test-token-here
```

## Publishing Steps

### 1. Test Build (Recommended First Step)

```bash
# Build package without uploading
python publish_to_pypi.py --build
```

This creates:
- `dist/agentquant-0.1.0-py3-none-any.whl`
- `dist/agentquant-0.1.0.tar.gz`

### 2. Test on TestPyPI

```bash
# Upload to TestPyPI first
python publish_to_pypi.py --test
```

Test installation:
```bash
pip install --index-url https://test.pypi.org/simple/ agentquant
```

### 3. Publish to PyPI

```bash
# Upload to production PyPI
python publish_to_pypi.py
```

## Manual Publishing (Alternative)

If you prefer manual steps:

```bash
# 1. Install build tools
pip install build twine

# 2. Clean old builds
rm -rf build dist *.egg-info

# 3. Build package
python -m build

# 4. Check package
twine check dist/*

# 5. Upload to TestPyPI (optional)
twine upload --repository testpypi dist/*

# 6. Upload to PyPI
twine upload dist/*
```

## Version Management

Before publishing, update the version in `agentquant/__init__.py`:

```python
__version__ = "0.1.1"  # Increment version
```

PyPI doesn't allow re-uploading the same version, so you must increment the version number for each release.

## Post-Publication

After successful upload, users can install:

```bash
# Install from PyPI
pip install agentquant

# Install with all dependencies
pip install agentquant[dev]      # With dev tools
pip install agentquant[docs]     # With documentation tools
```

## Troubleshooting

### Error: "File already exists"
Version already published. Increment version in `__init__.py`.

### Error: "Invalid or non-existent authentication"
Check your API token and credentials configuration.

### Error: "Metadata validation failed"
Run `twine check dist/*` to see detailed errors.

### Package not found after upload
PyPI may take a few minutes to index. Wait 5-10 minutes and try again.

## GitHub Actions (Optional)

For automated publishing on git tags, add `.github/workflows/publish.yml`:

```yaml
name: Publish to PyPI

on:
  push:
    tags:
      - 'v*'

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v3
    - name: Set up Python
      uses: actions/setup-python@v4
      with:
        python-version: '3.10'
    - name: Install dependencies
      run: |
        python -m pip install --upgrade pip
        pip install build twine
    - name: Build and publish
      env:
        TWINE_USERNAME: __token__
        TWINE_PASSWORD: ${{ secrets.PYPI_API_TOKEN }}
      run: |
        python -m build
        twine upload dist/*
```

Add `PYPI_API_TOKEN` to your GitHub repository secrets.
