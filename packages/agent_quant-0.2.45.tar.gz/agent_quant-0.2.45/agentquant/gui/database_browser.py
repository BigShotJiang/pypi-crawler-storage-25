"""
数据库浏览器 - 多功能菜单，查看各个表的数据
"""
from .qt_compat import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTableWidget, QTableWidgetItem, QComboBox, QLineEdit,
    QSplitter, QGroupBox, QMessageBox, QHeaderView, QMenu,
    QTreeWidget, QTreeWidgetItem, QTabWidget, QFrame,
    QAbstractItemView, QProgressDialog,
    Qt, QThread, Signal, QTimer, QColor, QBrush, QFont
)
from datetime import date, datetime, timedelta
import pandas as pd
import logging

logger = logging.getLogger(__name__)


class DataLoadThread(QThread):
    """数据加载线程"""
    data_loaded = Signal(object, str)  # data, table_name
    error_occurred = Signal(str)
    
    def __init__(self, db_client, table_name, query=None, limit=1000):
        super().__init__()
        self.db_client = db_client
        self.table_name = table_name
        self.query = query
        self.limit = limit
        
    def run(self):
        try:
            if self.query:
                df = self.db_client.query(self.query)
            else:
                df = self.db_client.query(f"SELECT * FROM {self.table_name} LIMIT {self.limit}")
            self.data_loaded.emit(df, self.table_name)
        except Exception as e:
            self.error_occurred.emit(str(e))


class TableListWidget(QTreeWidget):
    """数据库表列表树形控件"""
    
    table_selected = Signal(str, str)  # table_name, category
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setHeaderLabel("数据库表")
        self.setMaximumWidth(300)
        self.itemClicked.connect(self.on_item_clicked)
        
        # 定义表分类
        self.categories = {
            "股票基础数据": [
                "stocks", "stock_info", "industries", "concepts"
            ],
            "行情数据": [
                "market_data_daily", "market_data_minute", 
                "realtime_quotes", "index_data"
            ],
            "财务数据": [
                "financial_reports", "balance_sheet", "income_statement",
                "cash_flow", "financial_indicators"
            ],
            "因子数据": [
                "factors", "factor_values", "factor_calculation_log"
            ],
            "策略数据": [
                "strategies", "strategy_backtest_results", "strategy_parameters"
            ],
            "系统数据": [
                "data_update_log", "system_config", "user_settings"
            ]
        }
        
        self._init_tree()
        
    def _init_tree(self):
        """初始化树形结构"""
        for category, tables in self.categories.items():
            category_item = QTreeWidgetItem(self)
            category_item.setText(0, category)
            category_item.setExpanded(True)
            
            for table in tables:
                table_item = QTreeWidgetItem(category_item)
                table_item.setText(0, table)
                table_item.setData(0, Qt.UserRole, table)
                
    def on_item_clicked(self, item, column):
        """处理点击事件"""
        table_name = item.data(0, Qt.UserRole)
        if table_name:
            parent = item.parent()
            category = parent.text(0) if parent else "其他"
            self.table_selected.emit(table_name, category)
            
    def refresh_table_counts(self, db_client):
        """刷新各表的记录数"""
        try:
            root = self.invisibleRootItem()
            for i in range(root.childCount()):
                category_item = root.child(i)
                for j in range(category_item.childCount()):
                    table_item = category_item.child(j)
                    table_name = table_item.data(0, Qt.UserRole)
                    if table_name:
                        try:
                            result = db_client.query(f"SELECT COUNT(*) as count FROM {table_name}")
                            count = result['count'].iloc[0] if not result.empty else 0
                            table_item.setText(0, f"{table_name} ({count})")
                        except:
                            table_item.setText(0, f"{table_name} (-)")
        except Exception as e:
            logger.error(f"刷新表记录数失败: {e}")


class DataTableWidget(QWidget):
    """数据表格展示控件"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.current_df = None
        self.current_table = None
        self.init_ui()
        
    def init_ui(self):
        layout = QVBoxLayout(self)
        
        # 工具栏
        toolbar = QHBoxLayout()
        
        self.lbl_table_name = QLabel("请选择表")
        self.lbl_table_name.setFont(QFont("Microsoft YaHei", 12, QFont.Bold))
        toolbar.addWidget(self.lbl_table_name)
        
        toolbar.addStretch()
        
        # 搜索框
        toolbar.addWidget(QLabel("搜索:"))
        self.txt_search = QLineEdit()
        self.txt_search.setPlaceholderText("输入关键词搜索...")
        self.txt_search.setMaximumWidth(200)
        self.txt_search.returnPressed.connect(self.search_data)
        toolbar.addWidget(self.txt_search)
        
        # 刷新按钮
        btn_refresh = QPushButton("刷新")
        btn_refresh.clicked.connect(self.refresh_data)
        toolbar.addWidget(btn_refresh)
        
        # 导出按钮
        btn_export = QPushButton("导出CSV")
        btn_export.clicked.connect(self.export_csv)
        toolbar.addWidget(btn_export)
        
        layout.addLayout(toolbar)
        
        # 数据表格
        self.table = QTableWidget()
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.show_context_menu)
        layout.addWidget(self.table)
        
        # 状态栏
        self.lbl_status = QLabel("就绪")
        layout.addWidget(self.lbl_status)
        
    def load_data(self, df: pd.DataFrame, table_name: str):
        """加载数据到表格"""
        self.current_df = df
        self.current_table = table_name
        
        self.lbl_table_name.setText(f"表: {table_name}")
        
        if df is None or df.empty:
            self.table.setRowCount(0)
            self.table.setColumnCount(0)
            self.lbl_status.setText("无数据")
            return
            
        # 设置表格
        self.table.setRowCount(len(df))
        self.table.setColumnCount(len(df.columns))
        self.table.setHorizontalHeaderLabels(df.columns)
        
        # 填充数据
        for i, row in df.iterrows():
            for j, col in enumerate(df.columns):
                value = row[col]
                # 格式化值
                if isinstance(value, (datetime, date)):
                    value = value.strftime('%Y-%m-%d')
                elif isinstance(value, float):
                    value = f"{value:.4f}"
                
                item = QTableWidgetItem(str(value))
                
                # 数值列右对齐
                if isinstance(row[col], (int, float)):
                    item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                    
                self.table.setItem(i, j, item)
                
        # 调整列宽
        self.table.resizeColumnsToContents()
        
        # 更新状态
        self.lbl_status.setText(f"共 {len(df)} 行, {len(df.columns)} 列")
        
    def search_data(self):
        """搜索数据"""
        if self.current_df is None:
            return
            
        keyword = self.txt_search.text().strip()
        if not keyword:
            self.load_data(self.current_df, self.current_table)
            return
            
        # 过滤数据
        mask = self.current_df.astype(str).apply(
            lambda x: x.str.contains(keyword, case=False, na=False)
        ).any(axis=1)
        filtered_df = self.current_df[mask]
        
        self.load_data(filtered_df, f"{self.current_table} (搜索: {keyword})")
        
    def refresh_data(self):
        """刷新数据"""
        # 通知父组件刷新
        parent = self.parent()
        while parent:
            if hasattr(parent, 'load_table_data'):
                parent.load_table_data(self.current_table)
                break
            parent = parent.parent()
            
    def export_csv(self):
        """导出CSV"""
        if self.current_df is None or self.current_df.empty:
            QMessageBox.warning(self, "警告", "没有数据可导出")
            return
            
        from PyQt5.QtWidgets import QFileDialog
        filename, _ = QFileDialog.getSaveFileName(
            self, "导出CSV", f"{self.current_table}.csv", "CSV文件 (*.csv)"
        )
        
        if filename:
            try:
                self.current_df.to_csv(filename, index=False, encoding='utf-8-sig')
                QMessageBox.information(self, "成功", f"数据已导出到:\n{filename}")
            except Exception as e:
                QMessageBox.critical(self, "错误", f"导出失败:\n{e}")
                
    def show_context_menu(self, position):
        """显示右键菜单"""
        menu = QMenu(self)
        
        action_copy = menu.addAction("复制")
        action_copy.triggered.connect(self.copy_selection)
        
        menu.exec_(self.table.viewport().mapToGlobal(position))
        
    def copy_selection(self):
        """复制选中内容"""
        selected = self.table.selectedRanges()
        if not selected:
            return
            
        text = []
        for range_ in selected:
            for row in range(range_.topRow(), range_.bottomRow() + 1):
                row_text = []
                for col in range(range_.leftColumn(), range_.rightColumn() + 1):
                    item = self.table.item(row, col)
                    row_text.append(item.text() if item else "")
                text.append('\t'.join(row_text))
                
        from PyQt5.QtWidgets import QApplication
        QApplication.clipboard().setText('\n'.join(text))


class DatabaseBrowserWindow(QWidget):
    """数据库浏览器主窗口"""
    
    def __init__(self, db_client=None):
        super().__init__()
        self.db_client = db_client
        self.current_thread = None
        self.setWindowTitle("AgentQuant - 数据库浏览器")
        self.setGeometry(100, 100, 1400, 900)
        self.init_ui()
        
        # 定时刷新表记录数
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh_table_counts)
        self.timer.start(30000)  # 30秒刷新一次
        
    def init_ui(self):
        layout = QHBoxLayout(self)
        
        # 分割器
        splitter = QSplitter(Qt.Horizontal)
        
        # 左侧：表列表
        self.table_list = TableListWidget()
        self.table_list.table_selected.connect(self.on_table_selected)
        splitter.addWidget(self.table_list)
        
        # 右侧：数据展示
        self.data_widget = DataTableWidget()
        splitter.addWidget(self.data_widget)
        
        splitter.setSizes([300, 1100])
        layout.addWidget(splitter)
        
        # 加载表记录数
        if self.db_client:
            QTimer.singleShot(100, self.refresh_table_counts)
            
    def on_table_selected(self, table_name: str, category: str):
        """处理表选择事件"""
        self.load_table_data(table_name)
        
    def load_table_data(self, table_name: str):
        """加载表数据"""
        if not self.db_client:
            QMessageBox.warning(self, "错误", "数据库客户端未初始化")
            return
            
        # 停止之前的线程
        if self.current_thread and self.current_thread.isRunning():
            self.current_thread.terminate()
            
        # 显示加载提示
        self.data_widget.lbl_status.setText(f"正在加载 {table_name}...")
        
        # 启动加载线程
        self.current_thread = DataLoadThread(self.db_client, table_name)
        self.current_thread.data_loaded.connect(self.on_data_loaded)
        self.current_thread.error_occurred.connect(self.on_load_error)
        self.current_thread.start()
        
    def on_data_loaded(self, df, table_name):
        """数据加载完成"""
        self.data_widget.load_data(df, table_name)
        
    def on_load_error(self, error_msg):
        """数据加载错误"""
        self.data_widget.lbl_status.setText(f"加载失败: {error_msg}")
        QMessageBox.warning(self, "加载失败", f"无法加载数据:\n{error_msg}")
        
    def refresh_table_counts(self):
        """刷新表记录数"""
        if self.db_client:
            self.table_list.refresh_table_counts(self.db_client)
            
    def closeEvent(self, event):
        """关闭事件"""
        if self.current_thread and self.current_thread.isRunning():
            self.current_thread.terminate()
        event.accept()
