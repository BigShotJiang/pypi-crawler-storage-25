"""
主窗口 - 按业务功能划分的菜单系统
"""
import sys
import os
from .qt_compat import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QMessageBox, QAction, QToolBar, 
    QStatusBar, QApplication, Qt, QThread, Signal, QTimer, 
    QFont, QIcon, QMenu
)
from datetime import datetime
import logging

from agentquant.database.storage.db_client import DBClient
from .database_browser import DatabaseBrowserWindow
from .functional_pages import (
    MarketDataPage, StockInfoPage, FactorPage,
    StrategyPage, BacktestPage, TradePage, SystemPage, TaskPage
)
from .stock_viewer import StockViewerPage

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class DatabaseStatusThread(QThread):
    """数据库状态监控线程"""
    status_updated = Signal(bool, str)
    
    def __init__(self, db_client):
        super().__init__()
        self.db_client = db_client
        self.running = True
        
    def run(self):
        while self.running:
            try:
                self.db_client.query("SELECT 1")
                self.status_updated.emit(True, "数据库已连接")
            except:
                self.status_updated.emit(False, "数据库未连接")
            
            for _ in range(50):
                if not self.running:
                    break
                self.msleep(100)
    
    def stop(self):
        self.running = False


class MainWindow(QMainWindow):
    """主窗口 - 按业务功能组织"""
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle("AgentQuant - 量化投资数据管理系统")
        self.setGeometry(100, 100, 1600, 1000)
        
        self.db_client = None
        self.db_status_thread = None
        self.current_page = None
        
        self.init_ui()
        self.init_menu()
        self.init_toolbar()
        self.init_statusbar()
        
        QTimer.singleShot(100, self.connect_database)
        
    def init_ui(self):
        """初始化UI"""
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        self.main_layout = QVBoxLayout(central_widget)
        self.main_layout.setContentsMargins(0, 0, 0, 0)
        
        # 页面容器
        self.page_container = QWidget()
        self.page_layout = QVBoxLayout(self.page_container)
        self.page_layout.setContentsMargins(0, 0, 0, 0)
        
        # 默认显示欢迎页
        self.show_welcome_page()
        
        self.main_layout.addWidget(self.page_container)
        
    def show_welcome_page(self):
        """显示欢迎页面"""
        welcome_widget = QWidget()
        layout = QVBoxLayout(welcome_widget)
        
        # 欢迎信息
        welcome = QLabel("欢迎使用 AgentQuant 量化投资数据管理系统")
        welcome.setFont(QFont("Microsoft YaHei", 20, QFont.Bold))
        welcome.setAlignment(Qt.AlignCenter)
        layout.addWidget(welcome)
        
        # 功能介绍
        info_text = """
        <h2>系统功能模块</h2>
        <table cellpadding="10">
        <tr><td><b>📈 股票行情</b></td><td>按股票展示行情数据，左侧列表选择股票，右侧查看K线详情</td></tr>
        <tr><td><b>🔢 因子数据</b></td><td>查看和管理各类量化因子及其计算结果</td></tr>
        <tr><td><b>🎯 策略管理</b></td><td>查看策略定义、信号生成、策略配置</td></tr>
        <tr><td><b>📉 回测分析</b></td><td>查看回测任务、净值曲线、交易记录、持仓情况</td></tr>
        <tr><td><b>💰 交易管理</b></td><td>查看模拟交易、实盘交易的订单和持仓</td></tr>
        <tr><td><b>⚙️ 系统管理</b></td><td>数据更新日志、系统配置、公告信息</td></tr>
        </table>
        """
        info = QLabel(info_text)
        info.setAlignment(Qt.AlignCenter)
        info.setTextFormat(Qt.RichText)
        layout.addWidget(info)
        
        self.switch_page(welcome_widget)
        
    def switch_page(self, page_widget):
        """切换页面"""
        # 清除当前页面
        while self.page_layout.count():
            item = self.page_layout.takeAt(0)
            if item.widget():
                item.widget().hide()
        
        # 添加新页面
        self.page_layout.addWidget(page_widget)
        page_widget.show()
        self.current_page = page_widget
        
    def init_menu(self):
        """初始化菜单栏 - 按业务功能划分"""
        menubar = self.menuBar()
        
        # ========== 文件菜单 ==========
        file_menu = menubar.addMenu('文件(&F)')
        
        exit_action = QAction('退出(&X)', self)
        exit_action.setShortcut('Ctrl+Q')
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)
        
        # ========== 股票行情菜单 ==========
        market_menu = menubar.addMenu('股票行情(&M)')
        
        stock_viewer_action = QAction('股票行情(&S)', self)
        stock_viewer_action.triggered.connect(self.show_stock_viewer_page)
        market_menu.addAction(stock_viewer_action)
        
        # ========== 因子数据菜单 ==========
        factor_menu = menubar.addMenu('因子数据(&F)')
        
        factor_list_action = QAction('因子列表(&L)', self)
        factor_list_action.triggered.connect(lambda: self.show_factor_page('list'))
        factor_menu.addAction(factor_list_action)
        
        factor_values_action = QAction('因子值(&V)', self)
        factor_values_action.triggered.connect(lambda: self.show_factor_page('values'))
        factor_menu.addAction(factor_values_action)
        
        # ========== 策略管理菜单 ==========
        strategy_menu = menubar.addMenu('策略管理(&T)')
        
        strategy_list_action = QAction('策略列表(&L)', self)
        strategy_list_action.triggered.connect(lambda: self.show_strategy_page('list'))
        strategy_menu.addAction(strategy_list_action)
        
        signals_action = QAction('策略信号(&S)', self)
        signals_action.triggered.connect(lambda: self.show_strategy_page('signals'))
        strategy_menu.addAction(signals_action)
        
        # ========== 回测分析菜单 ==========
        backtest_menu = menubar.addMenu('回测分析(&B)')
        
        backtest_tasks_action = QAction('回测任务(&T)', self)
        backtest_tasks_action.triggered.connect(lambda: self.show_backtest_page('tasks'))
        backtest_menu.addAction(backtest_tasks_action)
        
        backtest_nav_action = QAction('净值曲线(&N)', self)
        backtest_nav_action.triggered.connect(lambda: self.show_backtest_page('nav'))
        backtest_menu.addAction(backtest_nav_action)
        
        backtest_trades_action = QAction('交易记录(&R)', self)
        backtest_trades_action.triggered.connect(lambda: self.show_backtest_page('trades'))
        backtest_menu.addAction(backtest_trades_action)
        
        backtest_positions_action = QAction('持仓记录(&P)', self)
        backtest_positions_action.triggered.connect(lambda: self.show_backtest_page('positions'))
        backtest_menu.addAction(backtest_positions_action)
        
        # ========== 任务管理菜单 ==========
        task_menu = menubar.addMenu('任务管理(&K)')
        
        task_list_action = QAction('任务列表(&L)', self)
        task_list_action.triggered.connect(lambda: self.show_task_page('list'))
        task_menu.addAction(task_list_action)
        
        # ========== 交易管理菜单 ==========
        trade_menu = menubar.addMenu('交易管理(&R)')
        
        paper_orders_action = QAction('模拟交易订单(&P)', self)
        paper_orders_action.triggered.connect(lambda: self.show_trade_page('paper_orders'))
        trade_menu.addAction(paper_orders_action)
        
        paper_positions_action = QAction('模拟交易持仓(&O)', self)
        paper_positions_action.triggered.connect(lambda: self.show_trade_page('paper_positions'))
        trade_menu.addAction(paper_positions_action)
        
        live_orders_action = QAction('实盘订单(&L)', self)
        live_orders_action.triggered.connect(lambda: self.show_trade_page('live_orders'))
        trade_menu.addAction(live_orders_action)
        
        # ========== 系统管理菜单 ==========
        system_menu = menubar.addMenu('系统管理(&Y)')
        
        data_log_action = QAction('数据更新日志(&D)', self)
        data_log_action.triggered.connect(lambda: self.show_system_page('data_log'))
        system_menu.addAction(data_log_action)
        
        announcements_action = QAction('公告信息(&A)', self)
        announcements_action.triggered.connect(lambda: self.show_system_page('announcements'))
        system_menu.addAction(announcements_action)
        
        config_action = QAction('系统配置(&C)', self)
        config_action.triggered.connect(lambda: self.show_system_page('config'))
        system_menu.addAction(config_action)
        
        system_menu.addSeparator()
        
        raw_tables_action = QAction('原始数据表(&R)', self)
        raw_tables_action.triggered.connect(self.open_database_browser)
        system_menu.addAction(raw_tables_action)
        
        # ========== 帮助菜单 ==========
        help_menu = menubar.addMenu('帮助(&H)')
        
        about_action = QAction('关于(&A)', self)
        about_action.triggered.connect(self.show_about)
        help_menu.addAction(about_action)
        
    def init_toolbar(self):
        """初始化工具栏"""
        toolbar = QToolBar()
        self.addToolBar(toolbar)
        
        # 快速访问按钮
        toolbar.addWidget(QLabel("快速访问: "))
        
        btn_stock_viewer = QPushButton('股票行情')
        btn_stock_viewer.clicked.connect(self.show_stock_viewer_page)
        toolbar.addWidget(btn_stock_viewer)
        
        btn_factor = QPushButton('因子数据')
        btn_factor.clicked.connect(lambda: self.show_factor_page('list'))
        toolbar.addWidget(btn_factor)
        
        btn_strategy = QPushButton('策略管理')
        btn_strategy.clicked.connect(lambda: self.show_strategy_page('list'))
        toolbar.addWidget(btn_strategy)
        
        btn_backtest = QPushButton('回测分析')
        btn_backtest.clicked.connect(lambda: self.show_backtest_page('tasks'))
        toolbar.addWidget(btn_backtest)
        
        btn_task = QPushButton('任务管理')
        btn_task.clicked.connect(lambda: self.show_task_page('list'))
        toolbar.addWidget(btn_task)
        
        toolbar.addSeparator()
        
        btn_home = QPushButton('首页')
        btn_home.clicked.connect(self.show_welcome_page)
        toolbar.addWidget(btn_home)
        
    def init_statusbar(self):
        """初始化状态栏"""
        self.statusbar = QStatusBar()
        self.setStatusBar(self.statusbar)
        self.statusbar.showMessage("就绪")
        
    def connect_database(self):
        """连接数据库"""
        try:
            self.db_client = DBClient()
            self.statusbar.showMessage("数据库已连接")
            
            # 启动状态监控线程
            self.db_status_thread = DatabaseStatusThread(self.db_client)
            self.db_status_thread.status_updated.connect(self.on_db_status_updated)
            self.db_status_thread.start()
            
        except Exception as e:
            self.statusbar.showMessage(f"数据库连接失败: {e}")
            QMessageBox.warning(self, "连接失败", f"无法连接到数据库: {e}\n\n请确保数据库服务已启动。")
            
    def on_db_status_updated(self, connected, message):
        """数据库状态更新"""
        if connected:
            self.statusbar.showMessage(f"数据库已连接 | {datetime.now().strftime('%H:%M:%S')}")
        else:
            self.statusbar.showMessage(f"数据库未连接 | {datetime.now().strftime('%H:%M:%S')}")
            
    # ========== 页面切换方法 ==========
    
    def show_market_page(self, sub_page='daily'):
        """显示行情数据页面"""
        if not self.db_client:
            QMessageBox.warning(self, "未连接", "请先连接数据库")
            return
        page = MarketDataPage(self.db_client, sub_page)
        self.switch_page(page)
        
    def show_stock_page(self, sub_page='list'):
        """显示股票信息页面"""
        if not self.db_client:
            QMessageBox.warning(self, "未连接", "请先连接数据库")
            return
        page = StockInfoPage(self.db_client, sub_page)
        self.switch_page(page)
        
    def show_stock_viewer_page(self):
        """显示股票浏览器页面"""
        if not self.db_client:
            QMessageBox.warning(self, "未连接", "请先连接数据库")
            return
        page = StockViewerPage(self.db_client)
        self.switch_page(page)
        
    def show_factor_page(self, sub_page='list'):
        """显示因子数据页面"""
        if not self.db_client:
            QMessageBox.warning(self, "未连接", "请先连接数据库")
            return
        page = FactorPage(self.db_client, sub_page)
        self.switch_page(page)
        
    def show_strategy_page(self, sub_page='list'):
        """显示策略管理页面"""
        if not self.db_client:
            QMessageBox.warning(self, "未连接", "请先连接数据库")
            return
        page = StrategyPage(self.db_client, sub_page)
        self.switch_page(page)
        
    def show_backtest_page(self, sub_page='tasks'):
        """显示回测分析页面"""
        if not self.db_client:
            QMessageBox.warning(self, "未连接", "请先连接数据库")
            return
        page = BacktestPage(self.db_client, sub_page)
        self.switch_page(page)
        
    def show_trade_page(self, sub_page='paper_orders'):
        """显示交易管理页面"""
        if not self.db_client:
            QMessageBox.warning(self, "未连接", "请先连接数据库")
            return
        page = TradePage(self.db_client, sub_page)
        self.switch_page(page)
        
    def show_system_page(self, sub_page='data_log'):
        """显示系统管理页面"""
        if not self.db_client:
            QMessageBox.warning(self, "未连接", "请先连接数据库")
            return
        page = SystemPage(self.db_client, sub_page)
        self.switch_page(page)
        
    def show_task_page(self, sub_page='list'):
        """显示任务管理页面"""
        if not self.db_client:
            QMessageBox.warning(self, "未连接", "请先连接数据库")
            return
        page = TaskPage(self.db_client, sub_page)
        self.switch_page(page)
        
    def open_database_browser(self):
        """打开原始数据库浏览器"""
        if not self.db_client:
            QMessageBox.warning(self, "未连接", "请先连接数据库")
            return
            
        browser = DatabaseBrowserWindow(self.db_client)
        browser.setWindowModality(Qt.NonModal)
        browser.show()
        
    def show_about(self):
        """显示关于对话框"""
        QMessageBox.about(self, "关于", 
            "AgentQuant 量化投资数据管理系统\n\n"
            "版本: 0.2.44\n"
            "用于量化投资数据管理和分析"
        )
        
    def closeEvent(self, event):
        """关闭事件"""
        if self.db_status_thread:
            self.db_status_thread.stop()
            self.db_status_thread.wait()
        
        event.accept()
