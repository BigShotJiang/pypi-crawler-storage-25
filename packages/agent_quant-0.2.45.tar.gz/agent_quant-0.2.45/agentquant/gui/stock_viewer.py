"""
股票行情 - 整合股票列表和行情数据
类似股票软件的展示方式：左侧股票列表，右侧详情（含K线）
"""
from .qt_compat import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTableWidget, QTableWidgetItem, QLineEdit, QSplitter,
    QGroupBox, QMessageBox, QHeaderView, QTabWidget,
    QAbstractItemView, QDateEdit, QComboBox, QScrollBar,
    Qt, QThread, Signal, QFont, QGridLayout, QFrame,
    QStackedWidget, QTreeWidget, QTreeWidgetItem, QTextEdit
)
from datetime import date, datetime, timedelta
import pandas as pd
import logging

# Matplotlib for K-line chart
import matplotlib
matplotlib.use('Qt5Agg')
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import matplotlib.dates as mdates
import matplotlib.pyplot as plt

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

logger = logging.getLogger(__name__)


class MplCanvas(FigureCanvas):
    """Matplotlib画布"""
    def __init__(self, parent=None, width=10, height=6, dpi=100):
        self.fig = Figure(figsize=(width, height), dpi=dpi)
        self.axes = self.fig.add_subplot(111)
        super().__init__(self.fig)
        self.setParent(parent)


class StockDataLoadThread(QThread):
    """股票数据加载线程"""
    data_loaded = Signal(object, str)
    error_occurred = Signal(str)
    
    def __init__(self, db_client, query, title=""):
        super().__init__()  # 调用父类QThread的初始化方法
        self.db_client = db_client  # 保存数据库客户端
        self.query = query  # 保存查询语句
        self.title = title  # 保存标题
        
    def run(self):
        try:
            df = self.db_client.query(self.query)
            self.data_loaded.emit(df, self.title)
        except Exception as e:
            self.error_occurred.emit(str(e))


class StockListWidget(QWidget):
    """股票列表组件"""
    stock_selected = Signal(str, str)  # 发送股票代码和名称
    
    def __init__(self, db_client):
        super().__init__()
        self.db_client = db_client
        self.current_thread = None
        self.init_ui()
        self.load_stock_list()
        
    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(2, 2, 2, 2)
        layout.setSpacing(2)
        
        # 搜索和市场筛选放在同一行
        filter_layout = QHBoxLayout()
        filter_layout.setSpacing(3)
        
        filter_layout.addWidget(QLabel("搜索:"))
        self.txt_search = QLineEdit()
        self.txt_search.setPlaceholderText("代码/名称")
        self.txt_search.setMaximumWidth(80)
        self.txt_search.textChanged.connect(self.filter_stocks)
        filter_layout.addWidget(self.txt_search)
        
        self.cmb_market = QComboBox()
        self.cmb_market.addItems(["全部", "深圳", "上海", "北京"])
        self.cmb_market.setMaximumWidth(60)
        self.cmb_market.currentTextChanged.connect(self.filter_stocks)
        filter_layout.addWidget(self.cmb_market)
        
        filter_layout.addStretch()
        layout.addLayout(filter_layout)
        
        # 股票列表表格
        self.table = QTableWidget()
        self.table.setColumnCount(3)
        self.table.setHorizontalHeaderLabels(["代码", "名称", "市场"])
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setAlternatingRowColors(True)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.setColumnWidth(0, 90)
        self.table.setColumnWidth(1, 100)
        self.table.setColumnWidth(2, 60)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)  # 禁止编辑
        self.table.itemClicked.connect(self.on_stock_clicked)
        layout.addWidget(self.table)
        
        # 状态标签
        self.lbl_status = QLabel("加载中...")
        layout.addWidget(self.lbl_status)
        
    def load_stock_list(self):
        """加载股票列表"""
        # 从行情数据表中获取所有股票代码
        query = """
            SELECT DISTINCT 
                code,
                CASE 
                    WHEN code LIKE '%.SZ' THEN '深圳'
                    WHEN code LIKE '%.SH' THEN '上海'
                    WHEN code LIKE '%.BJ' THEN '北京'
                    ELSE '其他'
                END as market
            FROM market_data_daily
            ORDER BY code
        """
        
        if self.current_thread and self.current_thread.isRunning():
            self.current_thread.terminate()
            
        self.current_thread = StockDataLoadThread(self.db_client, query, "股票列表")
        self.current_thread.data_loaded.connect(self.on_data_loaded)
        self.current_thread.error_occurred.connect(self.on_error)
        self.current_thread.start()
        
    def on_data_loaded(self, df, title):
        """数据加载完成"""
        self.all_stocks = df
        self.update_table(df)
        self.lbl_status.setText(f"共 {len(df)} 只股票")
        
    def on_error(self, error_msg):
        """加载错误"""
        self.lbl_status.setText(f"加载失败: {error_msg}")
        
    def update_table(self, df):
        """更新表格"""
        self.table.setRowCount(len(df))
        
        for i, row in df.iterrows():
            # 代码
            item_code = QTableWidgetItem(row['code'])
            item_code.setData(Qt.UserRole, row['code'])  # 存储代码
            self.table.setItem(i, 0, item_code)
            
            # 名称（从代码推断或使用代码作为名称）
            name = self.get_stock_name(row['code'])
            self.table.setItem(i, 1, QTableWidgetItem(name))
            
            # 市场
            self.table.setItem(i, 2, QTableWidgetItem(row['market']))
            
    def get_stock_name(self, code):
        """获取股票名称（简化版，实际应从stocks表查询）"""
        # 这里可以从数据库查询，暂时用代码作为名称
        name_map = {
            '000001.SZ': '平安银行',
            '000002.SZ': '万科A',
            '600000.SH': '浦发银行',
        }
        return name_map.get(code, code)
        
    def filter_stocks(self):
        """筛选股票"""
        if not hasattr(self, 'all_stocks') or self.all_stocks is None:
            return
            
        keyword = self.txt_search.text().strip().lower()
        market = self.cmb_market.currentText()
        
        df = self.all_stocks.copy()
        
        # 关键词筛选
        if keyword:
            mask = df['code'].str.lower().str.contains(keyword, na=False)
            df = df[mask]
            
        # 市场筛选
        if market != "全部":
            df = df[df['market'] == market]
            
        self.update_table(df)
        self.lbl_status.setText(f"显示 {len(df)} 只 / 共 {len(self.all_stocks)} 只")
        
    def on_stock_clicked(self, item):
        """股票被点击"""
        row = item.row()
        code = self.table.item(row, 0).text()
        name = self.table.item(row, 1).text()
        self.stock_selected.emit(code, name)


class StockDetailWidget(QWidget):
    """股票详情组件"""
    
    def __init__(self, db_client):
        super().__init__()
        self.db_client = db_client
        self.current_code = None
        self.current_thread = None
        self.init_ui()
        
    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(3, 3, 3, 3)
        layout.setSpacing(3)
        
        # 标题区域
        self.title_frame = QFrame()
        self.title_frame.setStyleSheet("background-color: #f5f5f5; border: 1px solid #ddd;")
        title_layout = QHBoxLayout(self.title_frame)
        title_layout.setContentsMargins(5, 3, 5, 3)
        
        self.lbl_code = QLabel("请选择股票")
        self.lbl_code.setFont(QFont("Microsoft YaHei", 12, QFont.Bold))
        title_layout.addWidget(self.lbl_code)
        
        self.lbl_name = QLabel("")
        self.lbl_name.setFont(QFont("Microsoft YaHei", 10))
        title_layout.addWidget(self.lbl_name)
        
        title_layout.addStretch()
        
        # 最新价格显示
        self.lbl_price = QLabel("--")
        self.lbl_price.setFont(QFont("Microsoft YaHei", 18, QFont.Bold))
        self.lbl_price.setStyleSheet("color: #333;")
        title_layout.addWidget(self.lbl_price)
        
        self.lbl_change = QLabel("--")
        self.lbl_change.setFont(QFont("Microsoft YaHei", 10))
        title_layout.addWidget(self.lbl_change)
        
        layout.addWidget(self.title_frame)
        
        # 日期筛选
        filter_layout = QHBoxLayout()
        filter_layout.addWidget(QLabel("开始日期:"))
        self.date_start = QDateEdit()
        self.date_start.setCalendarPopup(True)
        self.date_start.setDate(date.today() - timedelta(days=365*5))  # 默认近5年
        filter_layout.addWidget(self.date_start)
        
        filter_layout.addWidget(QLabel("结束日期:"))
        self.date_end = QDateEdit()
        self.date_end.setCalendarPopup(True)
        self.date_end.setDate(date.today())
        filter_layout.addWidget(self.date_end)
        
        self.btn_refresh = QPushButton("刷新K线")
        self.btn_refresh.clicked.connect(self.load_kline_data)
        filter_layout.addWidget(self.btn_refresh)
        
        filter_layout.addStretch()
        layout.addLayout(filter_layout)
        
        # 标签页
        self.tabs = QTabWidget()
        
        # K线数据页 - 包含图表和表格
        kline_widget = QWidget()
        kline_layout = QVBoxLayout(kline_widget)
        
        # 图表控制按钮
        chart_control_layout = QHBoxLayout()
        
        # 缩放按钮
        self.btn_zoom_out = QPushButton("🔍- 缩小")
        self.btn_zoom_out.setToolTip("显示更多数据")
        self.btn_zoom_out.clicked.connect(self.zoom_out_kline)
        chart_control_layout.addWidget(self.btn_zoom_out)
        
        self.btn_zoom_in = QPushButton("🔍+ 放大")
        self.btn_zoom_in.setToolTip("显示更少数据")
        self.btn_zoom_in.clicked.connect(self.zoom_in_kline)
        chart_control_layout.addWidget(self.btn_zoom_in)
        
        chart_control_layout.addSpacing(20)
        
        # 滚动控制
        self.btn_scroll_left = QPushButton("◀ 向左滚动")
        self.btn_scroll_left.setToolTip("查看更早的数据")
        self.btn_scroll_left.clicked.connect(self.scroll_kline_left)
        chart_control_layout.addWidget(self.btn_scroll_left)
        
        # 滚动条
        self.scrollbar_kline = QScrollBar(Qt.Horizontal)
        self.scrollbar_kline.setToolTip("拖动查看不同时间段")
        self.scrollbar_kline.valueChanged.connect(self.on_scrollbar_changed)
        chart_control_layout.addWidget(self.scrollbar_kline, stretch=1)
        
        self.btn_scroll_right = QPushButton("向右滚动 ▶")
        self.btn_scroll_right.setToolTip("查看更新的数据")
        self.btn_scroll_right.clicked.connect(self.scroll_kline_right)
        chart_control_layout.addWidget(self.btn_scroll_right)
        
        chart_control_layout.addSpacing(20)
        
        # 范围标签
        self.lbl_chart_range = QLabel("显示60条")
        self.lbl_chart_range.setAlignment(Qt.AlignCenter)
        self.lbl_chart_range.setMinimumWidth(120)
        chart_control_layout.addWidget(self.lbl_chart_range)
        
        kline_layout.addLayout(chart_control_layout)
        
        # K线图
        self.kline_canvas = MplCanvas(self, width=10, height=4, dpi=100)
        kline_layout.addWidget(self.kline_canvas)
        
        # 数据表格
        self.kline_table = QTableWidget()
        self.kline_table.setColumnCount(7)
        self.kline_table.setHorizontalHeaderLabels([
            "日期", "开盘", "最高", "最低", "收盘", "成交量", "成交额"
        ])
        self.kline_table.setAlternatingRowColors(True)
        self.kline_table.horizontalHeader().setStretchLastSection(True)
        self.kline_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.kline_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.kline_table.verticalHeader().setVisible(False)
        self.kline_table.setMaximumHeight(200)  # 限制表格高度
        kline_layout.addWidget(self.kline_table)
        
        self.tabs.addTab(kline_widget, "K线数据")
        
        # 分时数据页（预留）
        self.minute_widget = QLabel("分时图功能开发中...")
        self.minute_widget.setAlignment(Qt.AlignCenter)
        self.tabs.addTab(self.minute_widget, "分时图")
        
        # 技术指标页（预留）
        self.tech_widget = QLabel("技术指标功能开发中...")
        self.tech_widget.setAlignment(Qt.AlignCenter)
        self.tabs.addTab(self.tech_widget, "技术指标")
        
        layout.addWidget(self.tabs)
        
        # 状态标签
        self.lbl_status = QLabel("请选择股票查看详情")
        layout.addWidget(self.lbl_status)
        
    def show_stock(self, code, name):
        """显示股票详情"""
        self.current_code = code
        self.lbl_code.setText(code)
        self.lbl_name.setText(name)
        self.load_kline_data()
        
    def load_kline_data(self):
        """加载K线数据"""
        # 调试信息
        with open('gui_debug.log', 'a', encoding='utf-8') as f:
            f.write(f"\n=== load_kline_data called ===\n")
            f.write(f"current_code: {self.current_code}\n")
        
        if not self.current_code:
            return
            
        start_date = self.date_start.date().toString("yyyy-MM-dd")
        end_date = self.date_end.date().toString("yyyy-MM-dd")
        
        query = f"""
            SELECT 
                trade_date,
                open,
                high,
                low,
                close,
                volume,
                amount
            FROM market_data_daily
            WHERE code = '{self.current_code}'
            AND trade_date >= '{start_date}' AND trade_date <= '{end_date}'
            ORDER BY trade_date DESC
            LIMIT 500
        """
        
        if self.current_thread and self.current_thread.isRunning():
            self.current_thread.terminate()
            
        self.lbl_status.setText("加载K线数据...")
        self.current_thread = StockDataLoadThread(self.db_client, query, "K线数据")
        self.current_thread.data_loaded.connect(self.on_kline_loaded)
        self.current_thread.error_occurred.connect(self.on_error)
        self.current_thread.start()
        
    def on_kline_loaded(self, df, title):
        """K线数据加载完成"""
        try:
            if df is None or df.empty:
                self.kline_table.setRowCount(0)
                self.lbl_status.setText("无K线数据")
                self.lbl_price.setText("--")
                self.lbl_change.setText("--")
                return
                
            # 更新最新价格显示
            latest = df.iloc[0]
            self.lbl_price.setText(f"{latest['close']:.2f}")
            
            # 计算最新价格的涨跌幅（与第二行比较）
            if len(df) > 1:
                change_pct = (latest['close'] - df.iloc[1]['close']) / df.iloc[1]['close'] * 100
                change_text = f"{change_pct:+.2f}%"
                if change_pct > 0:
                    self.lbl_change.setStyleSheet("color: red;")
                elif change_pct < 0:
                    self.lbl_change.setStyleSheet("color: green;")
                else:
                    self.lbl_change.setStyleSheet("color: #333;")
                self.lbl_change.setText(change_text)
            else:
                self.lbl_change.setText("--")
            
            # 绘制K线图
            self._plot_kline(df)
            
            # 更新K线表格（只显示最近20条）
            display_df = df.head(20)
            self.kline_table.setRowCount(len(display_df))
            
            for i in range(len(display_df)):
                row = display_df.iloc[i]
                
                # 日期
                date_str = row['trade_date']
                if isinstance(date_str, (datetime, date)):
                    date_str = date_str.strftime('%Y-%m-%d')
                self.kline_table.setItem(i, 0, QTableWidgetItem(str(date_str)))
                
                # 价格数据
                for col, key in enumerate(['open', 'high', 'low', 'close'], 1):
                    val = row[key]
                    item = QTableWidgetItem(f"{val:.2f}")
                    item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                    self.kline_table.setItem(i, col, item)
                    
                # 成交量
                vol = row['volume']
                vol_text = f"{vol/10000:.2f}万" if vol >= 10000 else f"{vol:.0f}"
                item = QTableWidgetItem(vol_text)
                item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                self.kline_table.setItem(i, 5, item)
                
                # 成交额
                amt = row['amount']
                amt_text = f"{amt/100000000:.2f}亿" if amt >= 100000000 else f"{amt/10000:.2f}万"
                item = QTableWidgetItem(amt_text)
                item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                self.kline_table.setItem(i, 6, item)
                    
            self.kline_table.resizeColumnsToContents()
            self.lbl_status.setText(f"共 {len(df)} 条K线数据（显示最近20条）")
            
        except Exception as e:
            self.lbl_status.setText(f"显示错误: {str(e)}")
    
    def _plot_kline(self, df):
        """绘制K线图 - 显示最近60条数据，支持左右滑动"""
        # 保存完整数据
        self.kline_df = df.copy()
        self.kline_total = len(df)
        
        # 默认显示最近60条
        self.kline_display_count = min(60, self.kline_total)
        self.kline_offset = 0  # 偏移量，0表示从最新数据开始
        
        # 初始化滚动条
        self._update_scrollbar()
        
        self._update_kline_view()
    
    def _update_scrollbar(self):
        """更新滚动条范围"""
        if not hasattr(self, 'scrollbar_kline'):
            return
        
        # 计算最大偏移量
        max_offset = max(0, self.kline_total - self.kline_display_count)
        
        # 设置滚动条范围（反向：0表示最新数据）
        self.scrollbar_kline.setRange(0, max_offset)
        self.scrollbar_kline.setValue(self.kline_offset)
        self.scrollbar_kline.setPageStep(self.kline_display_count // 5)
        self.scrollbar_kline.setSingleStep(1)
    
    def _update_kline_view(self):
        """更新K线图显示"""
        if not hasattr(self, 'kline_df') or self.kline_df is None:
            return
        
        df = self.kline_df
        
        # 计算显示范围
        end_idx = self.kline_total - self.kline_offset
        start_idx = max(0, end_idx - self.kline_display_count)
        display_df = df.iloc[start_idx:end_idx].copy()
        
        # 清空画布
        self.kline_canvas.axes.clear()
        
        # 转换日期
        display_df['trade_date'] = pd.to_datetime(display_df['trade_date'])
        
        # 绘制蜡烛图
        width = 0.8
        width2 = 0.15
        
        for i, row in display_df.iterrows():
            date = row['trade_date']
            open_price = row['open']
            high = row['high']
            low = row['low']
            close = row['close']
            
            if close >= open_price:
                color = '#ff4444'  # 上涨 - 红色
                self.kline_canvas.axes.bar(date, close - open_price, width, bottom=open_price, color=color, edgecolor='red')
                self.kline_canvas.axes.bar(date, high - close, width2, bottom=close, color=color)
                self.kline_canvas.axes.bar(date, low - open_price, width2, bottom=open_price, color=color)
            else:
                color = '#00aa00'  # 下跌 - 绿色
                self.kline_canvas.axes.bar(date, open_price - close, width, bottom=close, color=color, edgecolor='green')
                self.kline_canvas.axes.bar(date, high - open_price, width2, bottom=open_price, color=color)
                self.kline_canvas.axes.bar(date, low - close, width2, bottom=close, color=color)
        
        # 设置标题和格式
        start_date = display_df['trade_date'].iloc[0].strftime('%Y-%m-%d')
        end_date = display_df['trade_date'].iloc[-1].strftime('%Y-%m-%d')
        self.kline_canvas.axes.set_title(f"{self.current_code} K-Line ({start_date} ~ {end_date})", fontsize=11)
        self.kline_canvas.axes.set_ylabel("Price", fontsize=10)
        
        # 旋转x轴标签
        self.kline_canvas.axes.xaxis.set_major_formatter(mdates.DateFormatter('%m-%d'))
        self.kline_canvas.axes.xaxis.set_major_locator(mdates.DayLocator(interval=max(1, len(display_df)//6)))
        
        # 添加网格
        self.kline_canvas.axes.grid(True, alpha=0.3)
        
        # 调整布局
        self.kline_canvas.fig.tight_layout()
        
        self.kline_canvas.draw()
        
        # 更新范围标签
        if hasattr(self, 'lbl_chart_range'):
            showing = f"显示 {start_idx+1}~{end_idx} 条 (共{self.kline_total}条)"
            self.lbl_chart_range.setText(showing)
    
    def on_scrollbar_changed(self, value):
        """滚动条值改变"""
        if not hasattr(self, 'kline_offset'):
            return
        self.kline_offset = value
        self._update_kline_view()
    
    def scroll_kline_left(self):
        """向左滚动（查看更早的数据）- 每次滚动5条"""
        if not hasattr(self, 'kline_offset'):
            return
        max_offset = self.kline_total - self.kline_display_count
        if self.kline_offset < max_offset:
            self.kline_offset = min(max_offset, self.kline_offset + 5)
            self.scrollbar_kline.setValue(self.kline_offset)
            self._update_kline_view()
    
    def scroll_kline_right(self):
        """向右滚动（查看更新的数据）- 每次滚动5条"""
        if not hasattr(self, 'kline_offset'):
            return
        if self.kline_offset > 0:
            self.kline_offset = max(0, self.kline_offset - 5)
            self.scrollbar_kline.setValue(self.kline_offset)
            self._update_kline_view()
    
    def zoom_in_kline(self):
        """放大 - 显示更少数据"""
        if not hasattr(self, 'kline_display_count'):
            return
        # 最少显示20条
        if self.kline_display_count > 20:
            self.kline_display_count = max(20, self.kline_display_count - 20)
            self._update_scrollbar()
            self._update_kline_view()
    
    def zoom_out_kline(self):
        """缩小 - 显示更多数据"""
        if not hasattr(self, 'kline_display_count'):
            return
        # 最多显示200条或全部
        max_count = min(200, self.kline_total)
        if self.kline_display_count < max_count:
            self.kline_display_count = min(max_count, self.kline_display_count + 20)
            self._update_scrollbar()
            self._update_kline_view()
        
    def on_error(self, error_msg):
        """加载错误"""
        self.lbl_status.setText(f"加载失败: {error_msg}")


class StockViewerPage(QWidget):
    """股票行情页面 - 整合股票列表和详情"""
    
    def __init__(self, db_client):
        super().__init__()
        self.db_client = db_client
        self.init_ui()
        
    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        # 分割器
        splitter = QSplitter(Qt.Horizontal)
        
        # 左侧股票列表
        self.stock_list = StockListWidget(self.db_client)
        self.stock_list.setMinimumWidth(250)
        self.stock_list.setMaximumWidth(350)
        self.stock_list.stock_selected.connect(self.on_stock_selected)
        splitter.addWidget(self.stock_list)
        
        # 右侧股票详情
        self.stock_detail = StockDetailWidget(self.db_client)
        splitter.addWidget(self.stock_detail)
        
        # 设置分割比例
        splitter.setSizes([300, 700])
        
        layout.addWidget(splitter)
        
    def on_stock_selected(self, code, name):
        """股票被选中"""
        self.stock_detail.show_stock(code, name)
