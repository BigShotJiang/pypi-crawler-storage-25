"""
功能页面 - 按业务功能划分的各个页面
"""
from .qt_compat import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTableWidget, QTableWidgetItem, QComboBox, QLineEdit,
    QSplitter, QGroupBox, QMessageBox, QHeaderView, QMenu,
    QTreeWidget, QTreeWidgetItem, QTabWidget, QFrame,
    QAbstractItemView, QProgressDialog, QDateEdit, QSpinBox,
    Qt, QThread, Signal, QTimer, QColor, QBrush, QFont,
    QGridLayout, QFormLayout, QStackedWidget, QTextEdit, QDialog
)
from datetime import date, datetime, timedelta
import pandas as pd
import pandas as pd
import logging

# 导入 backtest_api 获取因子和策略数据
from ..api.backtest_api import BacktestToolAPI

logger = logging.getLogger(__name__)


class DataLoadThread(QThread):
    """数据加载线程"""
    data_loaded = Signal(object, str)
    error_occurred = Signal(str)
    
    def __init__(self, db_client, query, title=""):
        super().__init__()
        self.db_client = db_client
        self.query = query
        self.title = title
        
    def run(self):
        try:
            df = self.db_client.query(self.query)
            self.data_loaded.emit(df, self.title)
        except Exception as e:
            self.error_occurred.emit(str(e))


class BaseDataPage(QWidget):
    """基础数据页面"""
    
    def __init__(self, db_client, title="数据页面"):
        super().__init__()
        self.db_client = db_client
        self.title = title
        self.current_thread = None
        self.init_ui()
        
    def init_ui(self):
        layout = QVBoxLayout(self)
        
        # 标题
        title_label = QLabel(self.title)
        title_label.setFont(QFont("Microsoft YaHei", 14, QFont.Bold))
        title_label.setStyleSheet("padding: 10px; background-color: #f0f0f0;")
        layout.addWidget(title_label)
        
        # 工具栏
        toolbar = QHBoxLayout()
        
        self.lbl_status = QLabel("就绪")
        toolbar.addWidget(self.lbl_status)
        
        toolbar.addStretch()
        
        # 搜索框
        toolbar.addWidget(QLabel("搜索:"))
        self.txt_search = QLineEdit()
        self.txt_search.setPlaceholderText("输入关键词搜索...")
        self.txt_search.setMaximumWidth(200)
        self.txt_search.returnPressed.connect(self.search_data)
        toolbar.addWidget(self.txt_search)
        
        # 刷新按钮
        btn_refresh = QPushButton("刷新")
        btn_refresh.clicked.connect(self.refresh_data)
        toolbar.addWidget(btn_refresh)
        
        # 导出按钮
        btn_export = QPushButton("导出CSV")
        btn_export.clicked.connect(self.export_csv)
        toolbar.addWidget(btn_export)
        
        layout.addLayout(toolbar)
        
        # 数据表格
        self.table = QTableWidget()
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        layout.addWidget(self.table)
        
    def load_data(self, query, title=""):
        """加载数据"""
        if self.current_thread and self.current_thread.isRunning():
            self.current_thread.terminate()
            
        self.lbl_status.setText("正在加载...")
        
        self.current_thread = DataLoadThread(self.db_client, query, title)
        self.current_thread.data_loaded.connect(self.on_data_loaded)
        self.current_thread.error_occurred.connect(self.on_load_error)
        self.current_thread.start()
        
    def on_data_loaded(self, df, title):
        """数据加载完成"""
        self.current_df = df
        
        if df is None or df.empty:
            self.table.setRowCount(0)
            self.table.setColumnCount(0)
            self.lbl_status.setText("无数据")
            return
            
        self.table.setRowCount(len(df))
        self.table.setColumnCount(len(df.columns))
        self.table.setHorizontalHeaderLabels(df.columns)
        
        for i, row in df.iterrows():
            for j, col in enumerate(df.columns):
                value = row[col]
                if isinstance(value, (datetime, date)):
                    value = value.strftime('%Y-%m-%d')
                elif isinstance(value, float):
                    value = f"{value:.4f}"
                
                item = QTableWidgetItem(str(value))
                if isinstance(row[col], (int, float)):
                    item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                self.table.setItem(i, j, item)
                
        self.table.resizeColumnsToContents()
        self.lbl_status.setText(f"共 {len(df)} 行, {len(df.columns)} 列")
        
    def on_load_error(self, error_msg):
        """加载错误"""
        self.lbl_status.setText(f"加载失败: {error_msg}")
        QMessageBox.warning(self, "加载失败", f"无法加载数据:\n{error_msg}")
        
    def search_data(self):
        """搜索数据"""
        if not hasattr(self, 'current_df') or self.current_df is None:
            return
            
        keyword = self.txt_search.text().strip()
        if not keyword:
            return
            
        mask = self.current_df.astype(str).apply(
            lambda x: x.str.contains(keyword, case=False, na=False)
        ).any(axis=1)
        filtered_df = self.current_df[mask]
        
        self.on_data_loaded(filtered_df, f"搜索结果: {keyword}")
        
    def refresh_data(self):
        """刷新数据 - 子类实现"""
        pass
        
    def export_csv(self):
        """导出CSV"""
        if not hasattr(self, 'current_df') or self.current_df is None or self.current_df.empty:
            QMessageBox.warning(self, "警告", "没有数据可导出")
            return
            
        from .qt_compat import QFileDialog
        filename, _ = QFileDialog.getSaveFileName(
            self, "导出CSV", f"data_export.csv", "CSV文件 (*.csv)"
        )
        
        if filename:
            try:
                self.current_df.to_csv(filename, index=False, encoding='utf-8-sig')
                QMessageBox.information(self, "成功", f"数据已导出到:\n{filename}")
            except Exception as e:
                QMessageBox.critical(self, "错误", f"导出失败:\n{e}")


class MarketDataPage(BaseDataPage):
    """行情数据页面"""
    
    def __init__(self, db_client, sub_page='daily'):
        self.sub_page = sub_page
        titles = {
            'daily': '日线行情数据',
            'minute': '分钟线行情数据',
            'realtime': '实时行情数据'
        }
        super().__init__(db_client, titles.get(sub_page, '行情数据'))
        self.init_filter_ui()
        self.refresh_data()
        
    def init_filter_ui(self):
        """初始化筛选UI"""
        # 在工具栏前添加筛选区域
        filter_layout = QHBoxLayout()
        
        filter_layout.addWidget(QLabel("股票代码:"))
        self.txt_stock_code = QLineEdit()
        self.txt_stock_code.setMaximumWidth(120)
        self.txt_stock_code.setPlaceholderText("如: 000001.SZ")
        filter_layout.addWidget(self.txt_stock_code)
        
        filter_layout.addWidget(QLabel("开始日期:"))
        self.date_start = QDateEdit()
        self.date_start.setCalendarPopup(True)
        self.date_start.setDate(date.today() - timedelta(days=30))
        filter_layout.addWidget(self.date_start)
        
        filter_layout.addWidget(QLabel("结束日期:"))
        self.date_end = QDateEdit()
        self.date_end.setCalendarPopup(True)
        self.date_end.setDate(date.today())
        filter_layout.addWidget(self.date_end)
        
        btn_query = QPushButton("查询")
        btn_query.clicked.connect(self.refresh_data)
        filter_layout.addWidget(btn_query)
        
        filter_layout.addStretch()
        
        # 插入到布局中
        self.layout().insertLayout(2, filter_layout)
        
    def refresh_data(self):
        """刷新数据"""
        stock_code = self.txt_stock_code.text().strip()
        start_date = self.date_start.date().toString("yyyy-MM-dd")
        end_date = self.date_end.date().toString("yyyy-MM-dd")
        
        if self.sub_page == 'daily':
            table = "market_data_daily"
        elif self.sub_page == 'minute':
            table = "market_data_minute"
        else:
            table = "market_data_realtime"
            
        if stock_code:
            query = f"""
                SELECT * FROM {table} 
                WHERE code = '{stock_code}' 
                AND trade_date BETWEEN '{start_date}' AND '{end_date}'
                ORDER BY trade_date DESC
                LIMIT 1000
            """
        else:
            query = f"""
                SELECT * FROM {table} 
                WHERE trade_date BETWEEN '{start_date}' AND '{end_date}'
                ORDER BY trade_date DESC
                LIMIT 100
            """
            
        self.load_data(query, self.title)


class StockInfoPage(BaseDataPage):
    """股票信息页面"""
    
    def __init__(self, db_client, sub_page='list'):
        self.sub_page = sub_page
        titles = {
            'list': '股票列表',
            'industry': '行业分类',
            'concept': '概念板块'
        }
        super().__init__(db_client, titles.get(sub_page, '股票信息'))
        self.refresh_data()
        
    def refresh_data(self):
        """刷新数据"""
        if self.sub_page == 'list':
            query = "SELECT * FROM stocks ORDER BY code LIMIT 500"
        elif self.sub_page == 'industry':
            query = """
                SELECT industry, COUNT(*) as stock_count 
                FROM stocks 
                WHERE industry IS NOT NULL 
                GROUP BY industry 
                ORDER BY stock_count DESC
            """
        else:
            query = "SELECT * FROM stocks WHERE concept IS NOT NULL LIMIT 500"
            
        self.load_data(query, self.title)


class FactorPage(QWidget):
    """因子数据页面 - 左中右三栏布局"""
    
    def __init__(self, db_client, sub_page='list'):
        super().__init__()
        self.db_client = db_client
        self.sub_page = sub_page
        self.current_factor = None
        self.init_ui()
        self.load_factors()
    
    def init_ui(self):
        layout = QVBoxLayout(self)
        
        # 标题
        title = QLabel('因子管理')
        title.setFont(QFont("Microsoft YaHei", 12, QFont.Bold))
        title.setStyleSheet("padding: 5px; background-color: #f0f0f0;")
        title.setMaximumHeight(30)
        layout.addWidget(title)
        
        # 三栏分栏
        splitter = QSplitter(Qt.Horizontal)
        
        # 左侧：因子列表
        left_widget = QWidget()
        left_layout = QVBoxLayout(left_widget)
        
        # 列表工具栏
        list_toolbar = QHBoxLayout()
        self.lbl_status = QLabel("就绪")
        list_toolbar.addWidget(self.lbl_status)
        list_toolbar.addStretch()
        
        btn_refresh = QPushButton("刷新")
        btn_refresh.clicked.connect(self.load_factors)
        list_toolbar.addWidget(btn_refresh)
        
        left_layout.addLayout(list_toolbar)
        
        # 因子列表表格
        self.table = QTableWidget()
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.itemClicked.connect(self.on_factor_selected)
        left_layout.addWidget(self.table)
        
        splitter.addWidget(left_widget)
        
        # 中间：操作面板 + 代码编辑
        mid_widget = QWidget()
        mid_layout = QVBoxLayout(mid_widget)
        
        # 因子信息
        self.lbl_factor_info = QLabel("请选择因子")
        self.lbl_factor_info.setFont(QFont("Microsoft YaHei", 11, QFont.Bold))
        mid_layout.addWidget(self.lbl_factor_info)
        
        # 操作面板（参数 + 按钮）
        op_group = QGroupBox("操作面板")
        op_layout = QVBoxLayout()
        
        # 参数输入
        param_layout = QGridLayout()
        
        param_layout.addWidget(QLabel("股票代码:"), 0, 0)
        self.param_code = QLineEdit()
        self.param_code.setPlaceholderText("如: 000001.SZ")
        param_layout.addWidget(self.param_code, 0, 1)
        
        param_layout.addWidget(QLabel("开始日期:"), 0, 2)
        self.param_start = QDateEdit()
        self.param_start.setCalendarPopup(True)
        self.param_start.setDate(date.today() - timedelta(days=365))
        param_layout.addWidget(self.param_start, 0, 3)
        
        param_layout.addWidget(QLabel("结束日期:"), 1, 0)
        self.param_end = QDateEdit()
        self.param_end.setCalendarPopup(True)
        self.param_end.setDate(date.today())
        param_layout.addWidget(self.param_end, 1, 1)
        
        param_layout.addWidget(QLabel("窗口期:"), 1, 2)
        self.param_window = QSpinBox()
        self.param_window.setRange(1, 252)
        self.param_window.setValue(20)
        param_layout.addWidget(self.param_window, 1, 3)
        
        op_layout.addLayout(param_layout)
        
        # 操作按钮
        btn_layout = QHBoxLayout()
        btn_save = QPushButton("保存代码")
        btn_save.clicked.connect(self.save_factor_code)
        btn_layout.addWidget(btn_save)
        
        btn_run = QPushButton("运行计算")
        btn_run.clicked.connect(self.run_factor)
        btn_layout.addWidget(btn_run)
        
        btn_layout.addStretch()
        op_layout.addLayout(btn_layout)
        
        op_group.setLayout(op_layout)
        mid_layout.addWidget(op_group)
        
        # 代码编辑器
        mid_layout.addWidget(QLabel("因子代码:"))
        self.code_editor = QTextEdit()
        self.code_editor.setFont(QFont("Consolas", 10))
        self.code_editor.setStyleSheet("""
            QTextEdit {
                background-color: #1e1e1e;
                color: #d4d4d4;
                border: 1px solid #3c3c3c;
            }
        """)
        mid_layout.addWidget(self.code_editor)
        
        splitter.addWidget(mid_widget)
        
        # 右侧：运行日志和结果
        right_widget = QWidget()
        right_layout = QVBoxLayout(right_widget)
        
        # 日志区域
        right_layout.addWidget(QLabel("运行日志:"))
        self.log_text = QTextEdit()
        self.log_text.setFont(QFont("Consolas", 9))
        self.log_text.setReadOnly(True)
        self.log_text.setStyleSheet("""
            QTextEdit {
                background-color: #1e1e1e;
                color: #d4d4d4;
                border: 1px solid #3c3c3c;
            }
        """)
        right_layout.addWidget(self.log_text)
        
        # 清空日志按钮
        btn_clear = QPushButton("清空日志")
        btn_clear.clicked.connect(self.clear_log)
        right_layout.addWidget(btn_clear)
        
        splitter.addWidget(right_widget)
        splitter.setSizes([250, 500, 250])
        
        layout.addWidget(splitter)
    
    def load_factors(self):
        """加载因子列表"""
        try:
            api = BacktestToolAPI()
            factors = api.get_available_factors()
            
            self.table.setRowCount(len(factors))
            self.table.setColumnCount(4)
            self.table.setHorizontalHeaderLabels(['代码', '名称', '分类', '类型'])
            
            for i, f in enumerate(factors):
                self.table.setItem(i, 0, QTableWidgetItem(f['code']))
                self.table.setItem(i, 1, QTableWidgetItem(f['name']))
                self.table.setItem(i, 2, QTableWidgetItem(f.get('category', '')))
                self.table.setItem(i, 3, QTableWidgetItem(f.get('type', '')))
            
            self.table.resizeColumnsToContents()
            self.lbl_status.setText(f"共 {len(factors)} 个因子")
        except Exception as e:
            logger.error(f"加载因子列表失败: {e}")
            self.lbl_status.setText(f"加载失败: {e}")
    
    def on_factor_selected(self, item):
        """选中因子"""
        row = item.row()
        factor_code = self.table.item(row, 0).text()
        factor_name = self.table.item(row, 1).text()
        
        self.current_factor = {
            'code': factor_code,
            'name': factor_name
        }
        
        self.lbl_factor_info.setText(f"因子: {factor_code} ({factor_name})")
        self.load_factor_code(factor_code, factor_name)
    
    def load_factor_code(self, factor_code, factor_name):
        """加载因子代码模板"""
        template = f'''from agentquant.factor.jqfactor_base import JQFactor, FactorMeta
import pandas as pd
import numpy as np

class {factor_code}Factor(JQFactor):
    """
    {factor_name}
    """
    
    meta = FactorMeta(
        code='{factor_code}',
        name='{factor_name}',
        category='技术指标',
        type='价格',
        params={{
            'window': 20,  # 计算窗口
        }}
    )
    
    def calculate(self, prices, window=20):
        """
        计算因子值
        
        Args:
            prices: 价格序列 (DataFrame with 'close' column)
            window: 计算窗口，默认20
            
        Returns:
            Series: 因子值
        """
        return prices['close'].rolling(window=window).mean()
'''
        self.code_editor.setText(template)
    
    def save_factor_code(self):
        """保存因子代码"""
        if not self.current_factor:
            QMessageBox.warning(self, "警告", "请先选择一个因子")
            return
        
        code = self.code_editor.toPlainText()
        # TODO: 保存到文件或数据库
        QMessageBox.information(self, "保存成功", 
            f"因子 {self.current_factor['code']} 代码已保存")
    
    def run_factor(self):
        """运行因子计算 - 使用 BacktestToolAPI (集成任务系统)"""
        if not self.current_factor:
            QMessageBox.warning(self, "警告", "请先选择一个因子")
            return
        
        code = self.param_code.text().strip()
        if not code:
            QMessageBox.warning(self, "警告", "请输入股票代码")
            return
        
        start_date = self.param_start.date().toString("yyyy-MM-dd")
        end_date = self.param_end.date().toString("yyyy-MM-dd")
        window = self.param_window.value()
        
        # 输出到日志
        self.log_text.append(f"[{datetime.now().strftime('%H:%M:%S')}] 开始运行因子 {self.current_factor['code']}...")
        self.log_text.append(f"  股票代码: {code}")
        self.log_text.append(f"  时间范围: {start_date} 至 {end_date}")
        self.log_text.append(f"  窗口期: {window}")
        self.log_text.append("  正在调用API计算...")
        
        try:
            # 使用 BacktestToolAPI 计算因子（自动创建任务记录）
            api = BacktestToolAPI()
            
            if not api.ping():
                self.log_text.append("  [错误] 数据库连接失败")
                self.log_text.append(f"[{datetime.now().strftime('%H:%M:%S')}] 因子计算失败")
                self.log_text.append("-" * 50)
                return
            
            factor_params = {'window': window}
            result = api.calculate_factor_values(
                factor_code=self.current_factor['code'],
                codes=[code],
                factor_params=factor_params
            )
            
            if not result.get('success', False):
                self.log_text.append(f"  [错误] {result.get('message', '计算失败')}")
                self.log_text.append(f"[{datetime.now().strftime('%H:%M:%S')}] 因子计算失败")
                self.log_text.append("-" * 50)
                return
            
            # 获取任务ID并显示
            task_id = result.get('task_id')
            if task_id:
                self.log_text.append(f"  ✓ 任务创建成功: {task_id}")
            
            self.log_text.append(f"  API调用成功，共 {result.get('count', 0)} 条结果")
            
            # 显示结果
            self.log_text.append("")
            self.log_text.append("=" * 60)
            self.log_text.append(f"因子计算结果: {result.get('factor_code')}")
            self.log_text.append("=" * 60)
            
            data = result.get('data', [])
            if data:
                self.log_text.append(f"{'代码':<12} {'日期':<12} {'收盘价':>10} {'因子值':>12}")
                self.log_text.append("-" * 60)
                
                for item in data:
                    self.log_text.append(
                        f"{item['code']:<12} {item['date']:<12} {item['close']:>10.2f} {item['factor']:>12.4f}"
                    )
            else:
                self.log_text.append("  无数据")
            
            self.log_text.append("-" * 60)
            
            # 显示统计信息
            stats = result.get('stats', {})
            if stats:
                self.log_text.append("")
                self.log_text.append("统计信息:")
                for code, stat in stats.items():
                    self.log_text.append(f"  股票: {code}")
                    self.log_text.append(f"    数据条数: {stat.get('count', 0)}")
                    self.log_text.append(f"    均值: {stat.get('mean', 0):.4f}")
                    self.log_text.append(f"    标准差: {stat.get('std', 0):.4f}")
                    self.log_text.append(f"    最小值: {stat.get('min', 0):.4f}")
                    self.log_text.append(f"    最大值: {stat.get('max', 0):.4f}")
                    self.log_text.append(f"    最新值: {stat.get('latest', 0):.4f}")
            
            # 显示任务信息
            if task_id:
                self.log_text.append("")
                self.log_text.append("📋 任务记录信息:")
                self.log_text.append(f"  任务ID: {task_id}")
                self.log_text.append(f"  完整结果已保存到任务系统")
                self.log_text.append(f"  使用CLI查看详情: python -m agentquant.cli task get {task_id}")
                self.log_text.append(f"  获取摘要(给Agent): python -m agentquant.cli task get {task_id} --summary")
            
            self.log_text.append("=" * 60)
            self.log_text.append(f"[{datetime.now().strftime('%H:%M:%S')}] 因子计算完成")
            
        except Exception as e:
            self.log_text.append(f"  [错误] {str(e)}")
            self.log_text.append(f"[{datetime.now().strftime('%H:%M:%S')}] 因子计算失败")
        
        self.log_text.append("-" * 50)
    
    def clear_log(self):
        """清空日志"""
        self.log_text.clear()


class StrategyPage(QWidget):
    """策略管理页面 - 左中右三栏布局"""
    
    def __init__(self, db_client, sub_page='list'):
        super().__init__()
        self.db_client = db_client
        self.sub_page = sub_page
        self.current_strategy = None
        self.init_ui()
        self.load_strategies()
    
    def init_ui(self):
        layout = QVBoxLayout(self)
        
        # 标题
        title = QLabel('策略管理')
        title.setFont(QFont("Microsoft YaHei", 12, QFont.Bold))
        title.setStyleSheet("padding: 5px; background-color: #f0f0f0;")
        title.setMaximumHeight(30)
        layout.addWidget(title)
        
        # 三栏分栏
        splitter = QSplitter(Qt.Horizontal)
        
        # 左侧：策略列表
        left_widget = QWidget()
        left_layout = QVBoxLayout(left_widget)
        
        # 列表工具栏
        list_toolbar = QHBoxLayout()
        self.lbl_status = QLabel("就绪")
        list_toolbar.addWidget(self.lbl_status)
        list_toolbar.addStretch()
        
        btn_refresh = QPushButton("刷新")
        btn_refresh.clicked.connect(self.load_strategies)
        list_toolbar.addWidget(btn_refresh)
        
        left_layout.addLayout(list_toolbar)
        
        # 策略列表表格
        self.table = QTableWidget()
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.itemClicked.connect(self.on_strategy_selected)
        left_layout.addWidget(self.table)
        
        splitter.addWidget(left_widget)
        
        # 中间：操作面板 + 代码编辑
        mid_widget = QWidget()
        mid_layout = QVBoxLayout(mid_widget)
        
        # 策略信息
        self.lbl_strategy_info = QLabel("请选择策略")
        self.lbl_strategy_info.setFont(QFont("Microsoft YaHei", 11, QFont.Bold))
        mid_layout.addWidget(self.lbl_strategy_info)
        
        # 操作面板（参数 + 按钮）
        op_group = QGroupBox("操作面板")
        op_layout = QVBoxLayout()
        
        # 参数输入
        param_layout = QGridLayout()
        
        param_layout.addWidget(QLabel("股票池:"), 0, 0)
        self.param_codes = QLineEdit()
        self.param_codes.setPlaceholderText("如: 000001.SZ,000002.SZ")
        param_layout.addWidget(self.param_codes, 0, 1, 1, 3)
        
        param_layout.addWidget(QLabel("开始日期:"), 1, 0)
        self.param_start = QDateEdit()
        self.param_start.setCalendarPopup(True)
        self.param_start.setDate(date.today() - timedelta(days=365))
        param_layout.addWidget(self.param_start, 1, 1)
        
        param_layout.addWidget(QLabel("结束日期:"), 1, 2)
        self.param_end = QDateEdit()
        self.param_end.setCalendarPopup(True)
        self.param_end.setDate(date.today())
        param_layout.addWidget(self.param_end, 1, 3)
        
        param_layout.addWidget(QLabel("初始资金:"), 2, 0)
        self.param_capital = QSpinBox()
        self.param_capital.setRange(10000, 100000000)
        self.param_capital.setValue(100000)
        self.param_capital.setSingleStep(10000)
        param_layout.addWidget(self.param_capital, 2, 1)
        
        param_layout.addWidget(QLabel("快线周期:"), 2, 2)
        self.param_fast = QSpinBox()
        self.param_fast.setRange(1, 60)
        self.param_fast.setValue(5)
        param_layout.addWidget(self.param_fast, 2, 3)
        
        param_layout.addWidget(QLabel("慢线周期:"), 3, 0)
        self.param_slow = QSpinBox()
        self.param_slow.setRange(5, 252)
        self.param_slow.setValue(20)
        param_layout.addWidget(self.param_slow, 3, 1)
        
        op_layout.addLayout(param_layout)
        
        # 操作按钮
        btn_layout = QHBoxLayout()
        btn_save = QPushButton("保存代码")
        btn_save.clicked.connect(self.save_strategy_code)
        btn_layout.addWidget(btn_save)
        
        btn_run = QPushButton("运行回测")
        btn_run.clicked.connect(self.run_backtest)
        btn_layout.addWidget(btn_run)
        
        btn_layout.addStretch()
        op_layout.addLayout(btn_layout)
        
        op_group.setLayout(op_layout)
        mid_layout.addWidget(op_group)
        
        # 代码编辑器
        mid_layout.addWidget(QLabel("策略代码:"))
        self.code_editor = QTextEdit()
        self.code_editor.setFont(QFont("Consolas", 10))
        self.code_editor.setStyleSheet("""
            QTextEdit {
                background-color: #1e1e1e;
                color: #d4d4d4;
                border: 1px solid #3c3c3c;
            }
        """)
        mid_layout.addWidget(self.code_editor)
        
        splitter.addWidget(mid_widget)
        
        # 右侧：运行日志和结果
        right_widget = QWidget()
        right_layout = QVBoxLayout(right_widget)
        
        # 日志区域
        right_layout.addWidget(QLabel("运行日志:"))
        self.log_text = QTextEdit()
        self.log_text.setFont(QFont("Consolas", 9))
        self.log_text.setReadOnly(True)
        self.log_text.setStyleSheet("""
            QTextEdit {
                background-color: #1e1e1e;
                color: #d4d4d4;
                border: 1px solid #3c3c3c;
            }
        """)
        right_layout.addWidget(self.log_text)
        
        # 清空日志按钮
        btn_clear = QPushButton("清空日志")
        btn_clear.clicked.connect(self.clear_log)
        right_layout.addWidget(btn_clear)
        
        splitter.addWidget(right_widget)
        splitter.setSizes([250, 500, 250])
        
        layout.addWidget(splitter)
    
    def load_strategies(self):
        """加载策略列表"""
        try:
            api = BacktestToolAPI()
            strategies = api.get_available_strategies()
            
            self.table.setRowCount(len(strategies))
            self.table.setColumnCount(3)
            self.table.setHorizontalHeaderLabels(['代码', '名称', '类型'])
            
            for i, s in enumerate(strategies):
                self.table.setItem(i, 0, QTableWidgetItem(s['code']))
                self.table.setItem(i, 1, QTableWidgetItem(s['name']))
                self.table.setItem(i, 2, QTableWidgetItem(s.get('type', '')))
            
            self.table.resizeColumnsToContents()
            self.lbl_status.setText(f"共 {len(strategies)} 个策略")
        except Exception as e:
            logger.error(f"加载策略列表失败: {e}")
            self.lbl_status.setText(f"加载失败: {e}")
    
    def on_strategy_selected(self, item):
        """选中策略"""
        row = item.row()
        strategy_code = self.table.item(row, 0).text()
        strategy_name = self.table.item(row, 1).text()
        
        self.current_strategy = {
            'code': strategy_code,
            'name': strategy_name
        }
        
        self.lbl_strategy_info.setText(f"策略: {strategy_code} ({strategy_name})")
        self.load_strategy_code(strategy_code, strategy_name)
    
    def load_strategy_code(self, strategy_code, strategy_name):
        """加载策略代码模板"""
        template = f'''from agentquant.strategy.base import BaseStrategy
from agentquant.factor.jqfactor_base import JQFactor
import pandas as pd
import numpy as np

class {strategy_code}Strategy(BaseStrategy):
    """
    {strategy_name}
    """
    
    def __init__(self):
        super().__init__()
        self.name = "{strategy_code}"
        # 策略参数
        self.fast_period = 5   # 快线周期
        self.slow_period = 20  # 慢线周期
    
    def on_init(self, context):
        """初始化策略"""
        # 设置基准
        context.set_benchmark('000001.SZ')
        # 设置手续费
        context.set_commission(0.0003)
        # 设置滑点
        context.set_slippage(0.001)
    
    def on_bar(self, context, data):
        """每根K线执行"""
        # 获取当前持仓
        positions = context.get_positions()
        
        # 获取股票池
        stocks = context.get_stock_pool()
        
        for stock in stocks:
            # 获取历史数据
            hist = data.get_history(stock, self.slow_period + 10)
            if len(hist) < self.slow_period:
                continue
            
            # 计算均线
            fast_ma = hist['close'].rolling(self.fast_period).mean().iloc[-1]
            slow_ma = hist['close'].rolling(self.slow_period).mean().iloc[-1]
            
            current_price = data.get_price(stock)
            
            if fast_ma > slow_ma and stock not in positions:
                # 买入信号
                context.order_target_value(stock, 100000)
            elif fast_ma < slow_ma and stock in positions:
                # 卖出信号
                context.order_target_value(stock, 0)
    
    def on_order(self, context, order):
        """订单回报"""
        print(f"订单成交: {{order.code}}, 数量: {{order.volume}}")
'''
        self.code_editor.setText(template)
    
    def save_strategy_code(self):
        """保存策略代码"""
        if not self.current_strategy:
            QMessageBox.warning(self, "警告", "请先选择一个策略")
            return
        
        code = self.code_editor.toPlainText()
        # TODO: 保存到文件或数据库
        QMessageBox.information(self, "保存成功", 
            f"策略 {self.current_strategy['code']} 代码已保存")
    
    def run_backtest(self):
        """运行策略回测 - 集成任务系统"""
        if not self.current_strategy:
            QMessageBox.warning(self, "警告", "请先选择一个策略")
            return
        
        codes = self.param_codes.text().strip()
        if not codes:
            QMessageBox.warning(self, "警告", "请输入股票代码")
            return
        
        start_date = self.param_start.date().toString("yyyy-MM-dd")
        end_date = self.param_end.date().toString("yyyy-MM-dd")
        capital = self.param_capital.value()
        fast = self.param_fast.value()
        slow = self.param_slow.value()
        
        # 输出到日志
        self.log_text.append(f"[{datetime.now().strftime('%H:%M:%S')}] 开始运行策略 {self.current_strategy['code']} 回测...")
        self.log_text.append(f"  股票池: {codes}")
        self.log_text.append(f"  时间范围: {start_date} 至 {end_date}")
        self.log_text.append(f"  初始资金: {capital}")
        self.log_text.append(f"  快线周期: {fast}, 慢线周期: {slow}")
        self.log_text.append("  正在初始化回测环境...")
        
        try:
            # 使用 BacktestToolAPI 运行策略回测（自动创建任务记录）
            api = BacktestToolAPI()
            
            if not api.ping():
                self.log_text.append("  [错误] 数据库连接失败")
                self.log_text.append(f"[{datetime.now().strftime('%H:%M:%S')}] 策略回测失败")
                self.log_text.append("-" * 50)
                return
            
            strategy_params = {
                'fast_period': fast,
                'slow_period': slow
            }
            
            code_list = [c.strip() for c in codes.split(',')]
            result = api.run_strategy_backtest(
                strategy_name=self.current_strategy['code'],
                codes=code_list,
                start_date=start_date,
                end_date=end_date,
                strategy_params=strategy_params
            )
            
            if not result.get('success', False):
                self.log_text.append(f"  [错误] {result.get('message', '回测失败')}")
                self.log_text.append(f"[{datetime.now().strftime('%H:%M:%S')}] 策略回测失败")
                self.log_text.append("-" * 50)
                return
            
            # 获取任务ID并显示
            task_id = result.get('task_id')
            if task_id:
                self.log_text.append(f"  ✓ 任务创建成功: {task_id}")
            
            self.log_text.append(f"  API调用成功")
            self.log_text.append("")
            self.log_text.append("=" * 60)
            self.log_text.append(f"策略回测结果: {result.get('strategy')}")
            self.log_text.append("=" * 60)
            
            # 显示任务信息
            if task_id:
                self.log_text.append("")
                self.log_text.append("📋 任务记录信息:")
                self.log_text.append(f"  任务ID: {task_id}")
                self.log_text.append(f"  完整结果已保存到任务系统")
                self.log_text.append(f"  使用CLI查看详情: python -m agentquant.cli task get {task_id}")
                self.log_text.append(f"  获取摘要(给Agent): python -m agentquant.cli task get {task_id} --summary")
            
            self.log_text.append("=" * 60)
            self.log_text.append(f"[{datetime.now().strftime('%H:%M:%S')}] 策略回测完成")
            
        except Exception as e:
            self.log_text.append(f"  [错误] {str(e)}")
            self.log_text.append(f"[{datetime.now().strftime('%H:%M:%S')}] 策略回测失败")
        
        self.log_text.append("-" * 50)
    
    def clear_log(self):
        """清空日志"""
        self.log_text.clear()


class BacktestPage(BaseDataPage):
    """回测分析页面"""
    
    def __init__(self, db_client, sub_page='tasks'):
        self.sub_page = sub_page
        titles = {
            'tasks': '回测任务',
            'nav': '净值曲线',
            'trades': '交易记录',
            'positions': '持仓记录'
        }
        super().__init__(db_client, titles.get(sub_page, '回测分析'))
        self.init_filter_ui()
        self.refresh_data()
        
    def init_filter_ui(self):
        """初始化筛选UI"""
        filter_layout = QHBoxLayout()
        
        filter_layout.addWidget(QLabel("回测ID:"))
        self.txt_backtest_id = QLineEdit()
        self.txt_backtest_id.setMaximumWidth(150)
        filter_layout.addWidget(self.txt_backtest_id)
        
        btn_query = QPushButton("查询")
        btn_query.clicked.connect(self.refresh_data)
        filter_layout.addWidget(btn_query)
        
        filter_layout.addStretch()
        self.layout().insertLayout(2, filter_layout)
        
    def refresh_data(self):
        """刷新数据"""
        backtest_id = getattr(self, 'txt_backtest_id', None)
        backtest_id = backtest_id.text().strip() if backtest_id else ""
        
        if self.sub_page == 'tasks':
            query = "SELECT * FROM backtest_tasks ORDER BY created_at DESC LIMIT 500"
        elif self.sub_page == 'nav':
            if backtest_id:
                query = f"""
                    SELECT * FROM backtest_nav 
                    WHERE backtest_id = '{backtest_id}'
                    ORDER BY trade_date
                    LIMIT 500
                """
            else:
                query = "SELECT * FROM backtest_nav ORDER BY trade_date DESC LIMIT 100"
        elif self.sub_page == 'trades':
            if backtest_id:
                query = f"""
                    SELECT * FROM backtest_trades 
                    WHERE backtest_id = '{backtest_id}'
                    ORDER BY trade_date DESC
                    LIMIT 500
                """
            else:
                query = "SELECT * FROM backtest_trades ORDER BY trade_date DESC LIMIT 100"
        else:  # positions
            if backtest_id:
                query = f"""
                    SELECT * FROM backtest_positions 
                    WHERE backtest_id = '{backtest_id}'
                    ORDER BY trade_date DESC
                    LIMIT 500
                """
            else:
                query = "SELECT * FROM backtest_positions ORDER BY trade_date DESC LIMIT 100"
                
        self.load_data(query, self.title)


class TradePage(BaseDataPage):
    """交易管理页面"""
    
    def __init__(self, db_client, sub_page='paper_orders'):
        self.sub_page = sub_page
        titles = {
            'paper_orders': '模拟交易订单',
            'paper_positions': '模拟交易持仓',
            'live_orders': '实盘订单'
        }
        super().__init__(db_client, titles.get(sub_page, '交易管理'))
        self.init_filter_ui()
        self.refresh_data()
        
    def init_filter_ui(self):
        """初始化筛选UI"""
        filter_layout = QHBoxLayout()
        
        filter_layout.addWidget(QLabel("账户ID:"))
        self.txt_account = QLineEdit()
        self.txt_account.setMaximumWidth(150)
        filter_layout.addWidget(self.txt_account)
        
        btn_query = QPushButton("查询")
        btn_query.clicked.connect(self.refresh_data)
        filter_layout.addWidget(btn_query)
        
        filter_layout.addStretch()
        self.layout().insertLayout(2, filter_layout)
        
    def refresh_data(self):
        """刷新数据"""
        account_id = getattr(self, 'txt_account', None)
        account_id = account_id.text().strip() if account_id else ""
        
        if self.sub_page == 'paper_orders':
            table = "paper_orders"
        elif self.sub_page == 'paper_positions':
            table = "paper_positions"
        else:
            table = "live_orders"
            
        if account_id:
            query = f"""
                SELECT * FROM {table} 
                WHERE account_id = '{account_id}'
                ORDER BY created_at DESC
                LIMIT 500
            """
        else:
            query = f"SELECT * FROM {table} ORDER BY created_at DESC LIMIT 100"
            
        self.load_data(query, self.title)


class SystemPage(BaseDataPage):
    """系统管理页面"""
    
    def __init__(self, db_client, sub_page='data_log'):
        self.sub_page = sub_page
        titles = {
            'data_log': '数据更新日志',
            'announcements': '公告信息',
            'config': '系统配置'
        }
        super().__init__(db_client, titles.get(sub_page, '系统管理'))
        self.refresh_data()
        
    def refresh_data(self):
        """刷新数据"""
        if self.sub_page == 'data_log':
            query = "SELECT * FROM data_update_log ORDER BY created_at DESC LIMIT 500"
        elif self.sub_page == 'announcements':
            query = "SELECT * FROM announcements ORDER BY publish_date DESC LIMIT 500"
        else:
            query = "SELECT * FROM system_config ORDER BY config_key LIMIT 500"

        self.load_data(query, self.title)


class TaskPage(BaseDataPage):
    """任务管理页面 - 查看计算任务记录"""
    
    def __init__(self, db_client, sub_page='list'):
        self.sub_page = sub_page
        titles = {
            'list': '任务列表',
            'detail': '任务详情'
        }
        super().__init__(db_client, titles.get(sub_page, '任务管理'))
        self.init_filter_ui()
        self.refresh_data()
        
    def init_filter_ui(self):
        """初始化筛选UI"""
        filter_layout = QHBoxLayout()
        
        filter_layout.addWidget(QLabel("任务类型:"))
        self.cmb_task_type = QComboBox()
        self.cmb_task_type.addItems(['全部', 'factor_calc', 'factor_backtest', 'strategy_backtest'])
        self.cmb_task_type.currentTextChanged.connect(self.refresh_data)
        filter_layout.addWidget(self.cmb_task_type)
        
        filter_layout.addWidget(QLabel("状态:"))
        self.cmb_status = QComboBox()
        self.cmb_status.addItems(['全部', 'pending', 'running', 'completed', 'failed'])
        self.cmb_status.currentTextChanged.connect(self.refresh_data)
        filter_layout.addWidget(self.cmb_status)
        
        filter_layout.addWidget(QLabel("任务ID:"))
        self.txt_task_id = QLineEdit()
        self.txt_task_id.setPlaceholderText("输入任务ID...")
        self.txt_task_id.setMaximumWidth(200)
        filter_layout.addWidget(self.txt_task_id)
        
        btn_query = QPushButton("查询")
        btn_query.clicked.connect(self.refresh_data)
        filter_layout.addWidget(btn_query)
        
        filter_layout.addStretch()
        self.layout().insertLayout(2, filter_layout)
        
        # 设置表格为只读并添加双击事件
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.doubleClicked.connect(self.on_table_double_click)
        
    def on_table_double_click(self, index):
        """双击行查看详情"""
        row = index.row()
        task_id_item = self.table.item(row, 0)
        if not task_id_item:
            return
        
        task_id = task_id_item.text()
        
        # 获取任务详情
        try:
            from ..api.task_api import TaskManager
            task_mgr = TaskManager()
            task = task_mgr.get_task(task_id)
            
            if not task:
                QMessageBox.warning(self, "错误", f"任务不存在: {task_id}")
                return
            
            # 显示任务详情对话框
            self.show_task_detail_dialog(task)
            
        except Exception as e:
            QMessageBox.critical(self, "错误", f"获取任务详情失败: {e}")
        
    def refresh_data(self):
        """刷新任务列表"""
        task_type = self.cmb_task_type.currentText()
        status = self.cmb_status.currentText()
        task_id = self.txt_task_id.text().strip()
        
        query = "SELECT * FROM calculation_tasks WHERE 1=1"
        params = []
        
        if task_id:
            query += " AND task_id LIKE ?"
            params.append(f"%{task_id}%")
        
        if task_type != '全部':
            query += " AND task_type = ?"
            params.append(task_type)
            
        if status != '全部':
            query += " AND status = ?"
            params.append(status)
        
        query += " ORDER BY created_at DESC LIMIT 500"
        
        self.load_data(query, self.title)
    
    def show_task_detail_dialog(self, task):
        """显示任务详情对话框"""
        from .qt_compat import QDialog, QVBoxLayout, QHBoxLayout, QLabel, QTextEdit, QPushButton, QTabWidget, QWidget
        import json
        
        dialog = QDialog(self)
        dialog.setWindowTitle(f"任务详情 - {task.get('task_id', '')}")
        dialog.setMinimumSize(800, 600)
        
        layout = QVBoxLayout(dialog)
        
        # 基本信息
        info_text = f"""
<b>任务ID:</b> {task.get('task_id', '-')}
<b>任务类型:</b> {task.get('task_type', '-')}
<b>任务名称:</b> {task.get('task_name', '-')}
<b>状态:</b> {task.get('status', '-')}
<b>进度:</b> {task.get('progress', 0):.1f}%
<b>创建时间:</b> {task.get('created_at', '-')}
<b>开始时间:</b> {task.get('started_at', '-')}
<b>完成时间:</b> {task.get('completed_at', '-')}
<b>执行时长:</b> {task.get('duration_ms', '-')} ms
<b>创建者:</b> {task.get('created_by', '-')}
"""
        info_label = QLabel(info_text)
        info_label.setStyleSheet("QLabel { padding: 10px; background-color: #f5f5f5; }")
        layout.addWidget(info_label)
        
        # Tab控件
        tabs = QTabWidget()
        
        # 输入摘要Tab
        input_tab = QWidget()
        input_layout = QVBoxLayout(input_tab)
        input_text = QTextEdit()
        input_text.setReadOnly(True)
        input_text.setText(task.get('input_summary', '无'))
        input_layout.addWidget(input_text)
        tabs.addTab(input_tab, "输入摘要")
        
        # 输出摘要Tab
        output_tab = QWidget()
        output_layout = QVBoxLayout(output_tab)
        output_text = QTextEdit()
        output_text.setReadOnly(True)
        output_text.setText(task.get('output_summary', '无'))
        output_layout.addWidget(output_text)
        tabs.addTab(output_tab, "输出摘要")
        
        # 指标数据Tab
        metrics_tab = QWidget()
        metrics_layout = QVBoxLayout(metrics_tab)
        metrics_text = QTextEdit()
        metrics_text.setReadOnly(True)
        try:
            metrics = json.loads(task.get('output_metrics', '{}'))
            metrics_text.setText(json.dumps(metrics, ensure_ascii=False, indent=2))
        except:
            metrics_text.setText(task.get('output_metrics', '无'))
        metrics_layout.addWidget(metrics_text)
        tabs.addTab(metrics_tab, "指标数据")
        
        # 结果预览Tab
        preview_tab = QWidget()
        preview_layout = QVBoxLayout(preview_tab)
        preview_text = QTextEdit()
        preview_text.setReadOnly(True)
        try:
            preview = json.loads(task.get('result_preview', '[]'))
            preview_text.setText(json.dumps(preview, ensure_ascii=False, indent=2))
        except:
            preview_text.setText(task.get('result_preview', '无'))
        preview_layout.addWidget(preview_text)
        tabs.addTab(preview_tab, "结果预览")
        
        # 错误信息Tab
        if task.get('error_message'):
            error_tab = QWidget()
            error_layout = QVBoxLayout(error_tab)
            error_text = QTextEdit()
            error_text.setReadOnly(True)
            error_text.setStyleSheet("QTextEdit { color: red; }")
            error_text.setText(task.get('error_message', ''))
            error_layout.addWidget(error_text)
            tabs.addTab(error_tab, "错误信息")
        
        layout.addWidget(tabs)
        
        # 按钮
        btn_layout = QHBoxLayout()
        btn_layout.addStretch()
        
        btn_copy_id = QPushButton("复制任务ID")
        btn_copy_id.clicked.connect(lambda: self.copy_to_clipboard(task.get('task_id', '')))
        btn_layout.addWidget(btn_copy_id)
        
        btn_copy_cli = QPushButton("复制CLI命令")
        btn_copy_cli.clicked.connect(lambda: self.copy_to_clipboard(
            f"python -m agentquant.cli task get {task.get('task_id', '')} --summary"
        ))
        btn_layout.addWidget(btn_copy_cli)
        
        btn_close = QPushButton("关闭")
        btn_close.clicked.connect(dialog.close)
        btn_layout.addWidget(btn_close)
        
        layout.addLayout(btn_layout)
        
        dialog.exec_()
    
    def copy_to_clipboard(self, text):
        """复制文本到剪贴板"""
        from .qt_compat import QApplication
        clipboard = QApplication.clipboard()
        clipboard.setText(text)
        QMessageBox.information(self, "提示", "已复制到剪贴板")
