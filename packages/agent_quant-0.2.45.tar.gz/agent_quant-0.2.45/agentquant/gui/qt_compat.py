"""
Qt 兼容性模块 - 支持 PyQt5 和 PySide6
"""

try:
    # 尝试导入 PyQt5
    from PyQt5.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
        QTableWidget, QTableWidgetItem, QComboBox, QLineEdit,
        QSplitter, QGroupBox, QMessageBox, QHeaderView, QMenu,
        QTreeWidget, QTreeWidgetItem, QTabWidget, QFrame,
        QAbstractItemView, QProgressDialog, QMainWindow, QApplication,
        QStatusBar, QToolBar, QMenuBar, QDialog, QFileDialog,
        QInputDialog, QProgressBar, QTextEdit, QPlainTextEdit,
        QDateEdit, QSpinBox, QGridLayout, QFormLayout, QStackedWidget,
        QScrollBar
    )
    from PyQt5.QtGui import QAction, QKeySequence
    from PyQt5.QtCore import Qt, QThread, pyqtSignal as Signal, QTimer, QObject, QSize
    from PyQt5.QtGui import QColor, QBrush, QFont, QIcon
    QT_BACKEND = 'PyQt5'
except ImportError:
    try:
        # 尝试导入 PySide6
        from PySide6.QtWidgets import (
            QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
            QTableWidget, QTableWidgetItem, QComboBox, QLineEdit,
            QSplitter, QGroupBox, QMessageBox, QHeaderView, QMenu,
            QTreeWidget, QTreeWidgetItem, QTabWidget, QFrame,
            QAbstractItemView, QProgressDialog, QMainWindow, QApplication,
            QStatusBar, QToolBar, QMenuBar, QDialog, QFileDialog,
            QInputDialog, QProgressBar, QTextEdit, QPlainTextEdit,
            QDateEdit, QSpinBox, QGridLayout, QFormLayout, QStackedWidget,
            QScrollBar
        )
        from PySide6.QtGui import QAction, QKeySequence
        from PySide6.QtCore import Qt, QThread, Signal, QTimer, QObject, QSize
        from PySide6.QtGui import QColor, QBrush, QFont, QIcon
        QT_BACKEND = 'PySide6'
    except ImportError:
        raise ImportError(
            "无法导入 PyQt5 或 PySide6。请安装其中之一:\n"
            "  pip install PyQt5\n"
            "  或\n"
            "  pip install PySide6"
        )

__all__ = [
    # QtWidgets
    'QWidget', 'QVBoxLayout', 'QHBoxLayout', 'QLabel', 'QPushButton',
    'QTableWidget', 'QTableWidgetItem', 'QComboBox', 'QLineEdit',
    'QSplitter', 'QGroupBox', 'QMessageBox', 'QHeaderView', 'QMenu',
    'QTreeWidget', 'QTreeWidgetItem', 'QTabWidget', 'QFrame',
    'QAbstractItemView', 'QProgressDialog', 'QMainWindow', 'QApplication',
    'QStatusBar', 'QToolBar', 'QAction', 'QMenuBar', 'QDialog', 'QFileDialog',
    'QInputDialog', 'QProgressBar', 'QTextEdit', 'QPlainTextEdit',
    'QDateEdit', 'QSpinBox', 'QGridLayout', 'QFormLayout', 'QStackedWidget',
    'QScrollBar',
    # QtCore
    'Qt', 'QThread', 'Signal', 'QTimer', 'QObject', 'QSize',
    # QtGui
    'QColor', 'QBrush', 'QFont', 'QIcon', 'QKeySequence',
    # Backend
    'QT_BACKEND'
]
