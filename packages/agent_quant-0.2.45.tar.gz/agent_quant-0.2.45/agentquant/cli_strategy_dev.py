# -*- coding: utf-8 -*-
"""
策略开发 CLI 子命令
提供基于 CLI 的策略开发功能
"""

import argparse


def cmd_strategy_dev_create(args):
    """创建策略"""
    print("策略开发功能待实现")


def cmd_strategy_dev_list(args):
    """列出策略模板"""
    print("策略模板列表待实现")


def setup_strategy_dev_parser(subparsers):
    """设置 strategy-dev 子命令解析器"""
    dev_parser = subparsers.add_parser('strategy-dev', help='策略开发工具')
    dev_subparsers = dev_parser.add_subparsers(dest='dev_command', help='策略开发命令')
    
    # create 命令
    create_parser = dev_subparsers.add_parser('create', help='创建策略')
    create_parser.set_defaults(func=cmd_strategy_dev_create)
    
    # list 命令
    list_parser = dev_subparsers.add_parser('list-templates', help='列出策略模板')
    list_parser.set_defaults(func=cmd_strategy_dev_list)
