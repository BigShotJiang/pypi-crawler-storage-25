# -*- coding: utf-8 -*-
"""
Backtest API - Simplified version for CLI compatibility

集成任务管理系统，所有计算自动创建任务记录，支持Agent驱动工作流
"""

from typing import Dict, List, Optional, Any
from datetime import date, datetime
import pandas as pd

from .task_api import TaskManager

class BacktestToolAPI:
    """Simplified backtest API for CLI with task management"""
    
    def __init__(self, task_manager: Optional[TaskManager] = None):
        """
        初始化BacktestToolAPI
        
        Args:
            task_manager: 可选的任务管理器实例，如果不提供则自动创建
        """
        self.task_manager = task_manager or TaskManager()
        self._current_task_id: Optional[str] = None
    
    def _create_task(self, task_type: str, task_name: str, input_params: Dict) -> str:
        """创建任务记录"""
        task = self.task_manager.create_task(
            task_type=task_type,
            task_name=task_name,
            input_params=input_params,
            created_by='backtest_api'
        )
        self._current_task_id = task['task_id']
        return task['task_id']
    
    def _start_task(self, task_id: str):
        """标记任务开始"""
        self.task_manager.start_task(task_id)
    
    def _complete_task(self, task_id: str, result: Dict, result_df: Optional[pd.DataFrame] = None):
        """完成任务"""
        self.task_manager.complete_task(task_id, result, result_df)
    
    def _fail_task(self, task_id: str, error: str):
        """标记任务失败"""
        self.task_manager.fail_task(task_id, error)
    
    def get_current_task_id(self) -> Optional[str]:
        """获取当前任务ID"""
        return self._current_task_id
    
    def get_task_summary(self, task_id: Optional[str] = None) -> Optional[Dict]:
        """获取任务摘要（给Agent用）"""
        tid = task_id or self._current_task_id
        if tid:
            return self.task_manager.get_task_summary_for_agent(tid)
        return None
    
    def get_available_factors(self) -> List[Dict[str, Any]]:
        """Get available factors for CLI"""
        return [
            {"code": "MA5", "name": "5日均线", "category": "技术指标", "type": "价格"},
            {"code": "MA20", "name": "20日均线", "category": "技术指标", "type": "价格"},
            {"code": "RSI", "name": "RSI指标", "category": "技术指标", "type": "价格"},
            {"code": "MACD", "name": "MACD指标", "category": "技术指标", "type": "价格"},
        ]
    
    def get_factor_info(self, factor_code: str) -> Optional[Dict[str, Any]]:
        """Get factor information"""
        factors = self.get_available_factors()
        for f in factors:
            if f["code"] == factor_code:
                return f
        return None
    
    def list_factors(self) -> List[Dict[str, Any]]:
        """List available factors (alias for get_available_factors)"""
        return self.get_available_factors()
    
    def get_available_strategies(self) -> List[Dict[str, Any]]:
        """Get available strategies for CLI"""
        return [
            {"code": "DUAL_MA", "name": "双均线策略", "type": "趋势跟踪"},
            {"code": "RSI_STRATEGY", "name": "RSI策略", "type": "均值回归"},
            {"code": "MACD_STRATEGY", "name": "MACD策略", "type": "趋势跟踪"},
        ]
    
    def get_strategy_info(self, strategy_code: str) -> Optional[Dict[str, Any]]:
        """Get strategy information"""
        strategies = self.get_available_strategies()
        for s in strategies:
            if s["code"] == strategy_code:
                return s
        return None
    
    def list_strategies(self) -> List[Dict[str, Any]]:
        """List available strategies (alias for get_available_strategies)"""
        return self.get_available_strategies()
    
    def ping(self) -> bool:
        """Check if database is available"""
        try:
            from ..database.storage.db_client import DBClient
            db = DBClient()
            db.query("SELECT 1")
            return True
        except:
            return False
    
    def calculate_factor_values(self, factor_code: str, codes: List[str], 
                                calc_date: Optional[str] = None,
                                factor_params: Optional[Dict] = None,
                                limit: Optional[int] = None,
                                create_task: bool = True) -> Dict[str, Any]:
        """
        Calculate factor values for given stocks
        
        Args:
            factor_code: 因子代码
            codes: 股票代码列表
            calc_date: 计算日期
            factor_params: 因子参数
            limit: 返回结果数量限制
            create_task: 是否创建任务记录（默认True）
        
        Returns:
            包含计算结果的字典，同时会自动创建任务记录
        """
        from ..database.storage.db_client import DBClient
        import pandas as pd
        import numpy as np
        
        task_id = None
        start_time = datetime.now()
        
        try:
            # 创建任务记录
            if create_task:
                input_params = {
                    'factor_code': factor_code,
                    'codes': codes,
                    'calc_date': calc_date,
                    'factor_params': factor_params,
                    'limit': limit
                }
                task_id = self._create_task('factor_calc', f"{factor_code}_{codes[0]}", input_params)
                self._start_task(task_id)
            
            db = DBClient()
            
            # Get stock data
            code_list = "','".join(codes)
            query = f"""
                SELECT code, trade_date, close, volume 
                FROM market_data_daily 
                WHERE code IN ('{code_list}')
                ORDER BY code, trade_date
            """
            df = db.query(query)
            
            if df.empty:
                result = {
                    'success': False,
                    'message': 'No data found for the given codes',
                    'task_id': task_id
                }
                if task_id:
                    self._fail_task(task_id, 'No data found for the given codes')
                return result
            
            # Get window from params
            window = factor_params.get('window', 20) if factor_params else 20
            
            # Calculate factor values
            all_data = []
            stats = {}
            
            for code in codes:
                code_df = df[df['code'] == code].copy()
                if len(code_df) == 0:
                    continue
                
                if factor_code in ['MA5', 'MA20']:
                    code_df['factor'] = code_df['close'].rolling(window=window).mean()
                elif factor_code == 'RSI':
                    delta = code_df['close'].diff()
                    gain = (delta.where(delta > 0, 0)).rolling(window=window).mean()
                    loss = (-delta.where(delta < 0, 0)).rolling(window=window).mean()
                    rs = gain / loss
                    code_df['factor'] = 100 - (100 / (1 + rs))
                elif factor_code == 'MACD':
                    exp1 = code_df['close'].ewm(span=12, adjust=False).mean()
                    exp2 = code_df['close'].ewm(span=26, adjust=False).mean()
                    code_df['factor'] = exp1 - exp2
                else:
                    code_df['factor'] = code_df['close'].rolling(window=window).mean()
                
                # Get valid data (non-null factor values)
                valid_df = code_df.dropna(subset=['factor'])
                
                if len(valid_df) > 0:
                    # Get last N records (default 20)
                    n_records = limit if limit else 20
                    recent = valid_df.tail(n_records)
                    
                    for _, row in recent.iterrows():
                        all_data.append({
                            'code': code,
                            'date': str(row['trade_date'])[:10],
                            'close': float(row['close']),
                            'factor': float(row['factor'])
                        })
                    
                    # Calculate statistics
                    stats[code] = {
                        'mean': float(valid_df['factor'].mean()),
                        'std': float(valid_df['factor'].std()),
                        'min': float(valid_df['factor'].min()),
                        'max': float(valid_df['factor'].max()),
                        'count': len(valid_df),
                        'latest': float(valid_df['factor'].iloc[-1])
                    }
            
            # 构建结果DataFrame用于任务记录
            result_df = pd.DataFrame(all_data) if all_data else None
            
            result = {
                'success': True,
                'factor_code': factor_code,
                'count': len(all_data),
                'data': all_data,
                'stats': stats,
                'task_id': task_id
            }
            
            # 完成任务记录
            if task_id:
                self._complete_task(task_id, result, result_df)
            
            return result
            
        except Exception as e:
            error_msg = str(e)
            result = {
                'success': False,
                'message': error_msg,
                'task_id': task_id
            }
            if task_id:
                self._fail_task(task_id, error_msg)
            return result
    
    def run_factor_test(self, factor_name: str, codes: List[str],
                       start_date: str, end_date: str,
                       factor_params: Optional[Dict] = None,
                       create_task: bool = True) -> Dict[str, Any]:
        """
        Run factor backtest
        
        Args:
            factor_name: 因子名称
            codes: 股票代码列表
            start_date: 开始日期
            end_date: 结束日期
            factor_params: 因子参数
            create_task: 是否创建任务记录
        """
        task_id = None
        
        try:
            # 创建任务记录
            if create_task:
                input_params = {
                    'factor_name': factor_name,
                    'codes': codes,
                    'start_date': start_date,
                    'end_date': end_date,
                    'factor_params': factor_params
                }
                task_id = self._create_task('factor_backtest', f"{factor_name}_backtest", input_params)
                self._start_task(task_id)
            
            # TODO: 实现实际的因子回测逻辑
            result = {
                'success': True,
                'factor': factor_name,
                'codes': codes,
                'period': f'{start_date} to {end_date}',
                'message': 'Factor test completed',
                'task_id': task_id
            }
            
            if task_id:
                self._complete_task(task_id, result)
            
            return result
            
        except Exception as e:
            error_msg = str(e)
            result = {
                'success': False,
                'message': error_msg,
                'task_id': task_id
            }
            if task_id:
                self._fail_task(task_id, error_msg)
            return result
    
    def run_strategy_backtest(self, strategy_name: str, codes: List[str],
                             start_date: str, end_date: str,
                             strategy_params: Optional[Dict] = None,
                             create_task: bool = True) -> Dict[str, Any]:
        """
        Run strategy backtest
        
        Args:
            strategy_name: 策略名称
            codes: 股票代码列表
            start_date: 开始日期
            end_date: 结束日期
            strategy_params: 策略参数
            create_task: 是否创建任务记录
        """
        task_id = None
        
        try:
            # 创建任务记录
            if create_task:
                input_params = {
                    'strategy_name': strategy_name,
                    'codes': codes,
                    'start_date': start_date,
                    'end_date': end_date,
                    'strategy_params': strategy_params
                }
                task_id = self._create_task('strategy_backtest', f"{strategy_name}_backtest", input_params)
                self._start_task(task_id)
            
            # TODO: 实现实际的策略回测逻辑
            result = {
                'success': True,
                'strategy': strategy_name,
                'codes': codes,
                'period': f'{start_date} to {end_date}',
                'message': 'Strategy backtest completed',
                'task_id': task_id
            }
            
            if task_id:
                self._complete_task(task_id, result)
            
            return result
            
        except Exception as e:
            error_msg = str(e)
            result = {
                'success': False,
                'message': error_msg,
                'task_id': task_id
            }
            if task_id:
                self._fail_task(task_id, error_msg)
            return result
