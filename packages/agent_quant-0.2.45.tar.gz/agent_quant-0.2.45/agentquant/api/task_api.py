# -*- coding: utf-8 -*-
"""
计算任务管理API - 支持Agent工作流
用于管理因子计算、回测等任务的执行和历史记录
"""

from typing import Dict, List, Optional, Any
from datetime import date, datetime
import json
import uuid
import os
import pandas as pd


class TaskManager:
    """计算任务管理器"""
    
    def __init__(self, db_client=None, result_dir: str = "data/task_results"):
        """
        初始化任务管理器
        
        Args:
            db_client: 数据库客户端
            result_dir: 结果文件存储目录
        """
        self.db_client = db_client
        self.result_dir = result_dir
        
        # 确保结果目录存在
        os.makedirs(result_dir, exist_ok=True)
        
        if db_client is None:
            from ..database.storage.db_client import DBClient
            self.db_client = DBClient()
    
    def _generate_task_id(self, task_type: str) -> str:
        """生成任务ID"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        short_uuid = uuid.uuid4().hex[:6]
        return f"{task_type.upper()}_{timestamp}_{short_uuid}"
    
    def create_task(self, task_type: str, task_name: str, 
                   input_params: Dict, created_by: str = "system") -> Dict[str, Any]:
        """
        创建新任务
        
        Args:
            task_type: 任务类型 (factor_calc/factor_backtest/strategy_backtest)
            task_name: 任务名称
            input_params: 输入参数
            created_by: 创建者
            
        Returns:
            任务信息字典
        """
        task_id = self._generate_task_id(task_type)
        
        # 生成输入参数摘要
        input_summary = self._generate_input_summary(task_type, input_params)
        
        task = {
            'task_id': task_id,
            'task_type': task_type,
            'task_name': task_name,
            'input_summary': input_summary,
            'input_params': json.dumps(input_params),
            'output_summary': None,
            'output_metrics': None,
            'result_count': 0,
            'result_data_path': None,
            'result_preview': None,
            'status': 'pending',
            'progress': 0,
            'started_at': None,
            'completed_at': None,
            'duration_ms': None,
            'error_message': None,
            'parent_task_id': input_params.get('parent_task_id'),
            'child_task_ids': None,
            'tags': input_params.get('tags', []),
            'priority': input_params.get('priority', 3),
            'created_by': created_by,
            'created_at': datetime.now(),
            'updated_at': datetime.now()
        }
        
        # 保存到数据库
        self._save_task_to_db(task)
        
        return {
            'success': True,
            'task_id': task_id,
            'status': 'pending',
            'message': f'任务 {task_id} 已创建'
        }
    
    def _generate_input_summary(self, task_type: str, params: Dict) -> str:
        """生成输入参数摘要"""
        if task_type == 'factor_calc':
            factor = params.get('factor_code', 'Unknown')
            codes = params.get('codes', [])
            window = params.get('factor_params', {}).get('window', 20)
            return f"计算因子 {factor} (窗口{window}) 对 {len(codes)} 只股票"
        
        elif task_type == 'factor_backtest':
            factor = params.get('factor_name', 'Unknown')
            codes = params.get('codes', [])
            period = f"{params.get('start_date')} 至 {params.get('end_date')}"
            return f"因子 {factor} 回测: {len(codes)} 只股票, {period}"
        
        elif task_type == 'strategy_backtest':
            strategy = params.get('strategy_name', 'Unknown')
            codes = params.get('codes', [])
            capital = params.get('initial_capital', 100000)
            period = f"{params.get('start_date')} 至 {params.get('end_date')}"
            return f"策略 {strategy} 回测: {len(codes)} 只股票, 初始资金{capital}, {period}"
        
        else:
            return f"任务类型: {task_type}"
    
    def _generate_output_summary(self, task_type: str, result: Dict) -> str:
        """生成输出结果摘要"""
        if task_type == 'factor_calc':
            count = result.get('count', 0)
            factor = result.get('factor_code', 'Unknown')
            return f"因子 {factor} 计算完成，共 {count} 条结果"
        
        elif task_type == 'factor_backtest':
            total_return = result.get('total_return', 0)
            sharpe = result.get('sharpe_ratio', 0)
            return f"回测完成，总收益 {total_return:.2%}, 夏普比率 {sharpe:.2f}"
        
        elif task_type == 'strategy_backtest':
            total_return = result.get('total_return', 0)
            max_dd = result.get('max_drawdown', 0)
            return f"策略回测完成，总收益 {total_return:.2%}, 最大回撤 {max_dd:.2%}"
        
        else:
            return f"任务完成"
    
    def _execute_update(self, query: str, params: List = None):
        """执行UPDATE/INSERT/DELETE语句"""
        # 使用query方法执行（db_service支持）
        return self.db_client._call('query', query, params)
    
    def _save_task_to_db(self, task: Dict):
        """保存任务到数据库"""
        columns = []
        values = []
        
        for key, value in task.items():
            if value is not None:
                columns.append(key)
                if isinstance(value, (list, dict)):
                    values.append(json.dumps(value))
                elif isinstance(value, datetime):
                    values.append(value.strftime('%Y-%m-%d %H:%M:%S'))
                else:
                    values.append(value)
        
        placeholders = ', '.join(['?' for _ in values])
        columns_str = ', '.join(columns)
        
        query = f"INSERT INTO calculation_tasks ({columns_str}) VALUES ({placeholders})"
        self._execute_update(query, values)
    
    def start_task(self, task_id: str) -> Dict[str, Any]:
        """开始执行任务"""
        self._execute_update(
            "UPDATE calculation_tasks SET status = 'running', started_at = ?, updated_at = ? WHERE task_id = ?",
            [datetime.now().strftime('%Y-%m-%d %H:%M:%S'), datetime.now().strftime('%Y-%m-%d %H:%M:%S'), task_id]
        )
        return {'success': True, 'task_id': task_id, 'status': 'running'}
    
    def update_progress(self, task_id: str, progress: float):
        """更新任务进度"""
        self._execute_update(
            "UPDATE calculation_tasks SET progress = ?, updated_at = ? WHERE task_id = ?",
            [progress, datetime.now().strftime('%Y-%m-%d %H:%M:%S'), task_id]
        )
    
    def complete_task(self, task_id: str, result: Dict, 
                     result_df: Optional[pd.DataFrame] = None) -> Dict[str, Any]:
        """
        完成任务
        
        Args:
            task_id: 任务ID
            result: 计算结果字典
            result_df: 结果DataFrame（可选，用于保存详细数据）
        """
        # 获取任务信息
        task_info = self.get_task(task_id)
        if not task_info:
            return {'success': False, 'message': '任务不存在'}
        
        task_type = task_info.get('task_type', 'unknown')
        
        # 生成输出摘要
        output_summary = self._generate_output_summary(task_type, result)
        
        # 提取关键指标
        output_metrics = self._extract_metrics(task_type, result)
        
        # 保存详细结果
        result_path = None
        result_preview = None
        result_count = result.get('count', 0)
        
        if result_df is not None and not result_df.empty:
            # 保存结果文件（优先使用Parquet，否则使用CSV）
            try:
                result_path = os.path.join(self.result_dir, f"{task_id}.parquet")
                result_df.to_parquet(result_path)
            except Exception:
                # 如果没有pyarrow，使用CSV格式
                result_path = os.path.join(self.result_dir, f"{task_id}.csv")
                result_df.to_csv(result_path, index=False)
            
            # 生成预览（前5条）
            preview_df = result_df.head(5)
            result_preview = preview_df.to_dict('records')
        
        # 更新数据库
        completed_at = datetime.now()
        started_at = task_info.get('started_at')
        duration_ms = None
        if started_at:
            if isinstance(started_at, str):
                started_at = datetime.strptime(started_at, '%Y-%m-%d %H:%M:%S')
            duration_ms = int((completed_at - started_at).total_seconds() * 1000)
        
        self._execute_update(
            """UPDATE calculation_tasks 
               SET status = 'completed',
                   progress = 100,
                   output_summary = ?,
                   output_metrics = ?,
                   result_count = ?,
                   result_data_path = ?,
                   result_preview = ?,
                   completed_at = ?,
                   duration_ms = ?,
                   updated_at = ?
               WHERE task_id = ?""",
            [
                output_summary,
                json.dumps(output_metrics),
                result_count,
                result_path,
                json.dumps(result_preview) if result_preview else None,
                completed_at.strftime('%Y-%m-%d %H:%M:%S'),
                duration_ms,
                completed_at.strftime('%Y-%m-%d %H:%M:%S'),
                task_id
            ]
        )
        
        return {
            'success': True,
            'task_id': task_id,
            'status': 'completed',
            'summary': output_summary,
            'metrics': output_metrics
        }
    
    def _extract_metrics(self, task_type: str, result: Dict) -> Dict:
        """提取关键指标"""
        metrics = {}
        
        if task_type == 'factor_calc':
            metrics = {
                'factor_code': result.get('factor_code'),
                'count': result.get('count', 0),
                'codes_count': len(set([d.get('code') for d in result.get('data', [])]))
            }
            # 添加统计信息
            if 'stats' in result:
                metrics['stats'] = result['stats']
        
        elif task_type == 'factor_backtest':
            metrics = {
                'total_return': result.get('total_return'),
                'annual_return': result.get('annual_return'),
                'sharpe_ratio': result.get('sharpe_ratio'),
                'max_drawdown': result.get('max_drawdown')
            }
        
        elif task_type == 'strategy_backtest':
            metrics = {
                'total_return': result.get('total_return'),
                'annual_return': result.get('annual_return'),
                'sharpe_ratio': result.get('sharpe_ratio'),
                'max_drawdown': result.get('max_drawdown'),
                'win_rate': result.get('win_rate'),
                'trade_count': result.get('trade_count')
            }
        
        return metrics
    
    def fail_task(self, task_id: str, error_message: str):
        """标记任务失败"""
        self._execute_update(
            """UPDATE calculation_tasks 
               SET status = 'failed',
                   error_message = ?,
                   completed_at = ?,
                   updated_at = ?
               WHERE task_id = ?""",
            [error_message, datetime.now().strftime('%Y-%m-%d %H:%M:%S'), 
             datetime.now().strftime('%Y-%m-%d %H:%M:%S'), task_id]
        )
    
    def get_task(self, task_id: str) -> Optional[Dict]:
        """获取任务详情"""
        df = self.db_client.execute_query(
            "SELECT * FROM calculation_tasks WHERE task_id = ?",
            [task_id]
        )
        if df.empty:
            return None
        return df.iloc[0].to_dict()
    
    def list_tasks(self, task_type: Optional[str] = None, 
                  status: Optional[str] = None,
                  limit: int = 100) -> List[Dict]:
        """列出任务"""
        query = "SELECT * FROM calculation_tasks WHERE 1=1"
        params = []
        
        if task_type:
            query += " AND task_type = ?"
            params.append(task_type)
        
        if status:
            query += " AND status = ?"
            params.append(status)
        
        query += " ORDER BY created_at DESC LIMIT ?"
        params.append(limit)
        
        df = self.db_client.execute_query(query, params)
        return df.to_dict('records') if not df.empty else []
    
    def get_task_result(self, task_id: str) -> Optional[pd.DataFrame]:
        """获取任务详细结果"""
        task = self.get_task(task_id)
        if not task or not task.get('result_data_path'):
            return None
        
        result_path = task['result_data_path']
        if not os.path.exists(result_path):
            return None
        
        # 根据文件扩展名选择读取方式
        if result_path.endswith('.parquet'):
            try:
                return pd.read_parquet(result_path)
            except Exception:
                return None
        elif result_path.endswith('.csv'):
            return pd.read_csv(result_path)
        return None
    
    def get_task_summary_for_agent(self, task_id: str) -> Dict[str, Any]:
        """
        获取任务摘要（用于Agent快速理解）
        不包含详细数据，避免token爆炸
        """
        task = self.get_task(task_id)
        if not task:
            return {'success': False, 'message': '任务不存在'}
        
        # 只返回关键信息
        return {
            'success': True,
            'task_id': task_id,
            'task_type': task.get('task_type'),
            'task_name': task.get('task_name'),
            'status': task.get('status'),
            'input_summary': task.get('input_summary'),
            'output_summary': task.get('output_summary'),
            'output_metrics': json.loads(task.get('output_metrics', '{}')),
            'result_count': task.get('result_count'),
            'result_preview': json.loads(task.get('result_preview', '[]')),
            'duration_ms': task.get('duration_ms'),
            'created_at': task.get('created_at'),
            'completed_at': task.get('completed_at')
        }
    
    def link_tasks(self, parent_task_id: str, child_task_id: str):
        """链接任务（支持任务链）"""
        # 获取父任务的子任务列表
        parent = self.get_task(parent_task_id)
        if not parent:
            return
        
        child_ids = json.loads(parent.get('child_task_ids', '[]'))
        if child_task_id not in child_ids:
            child_ids.append(child_task_id)
        
        self._execute_update(
            "UPDATE calculation_tasks SET child_task_ids = ? WHERE task_id = ?",
            [json.dumps(child_ids), parent_task_id]
        )
        
        # 更新子任务的父任务ID
        self._execute_update(
            "UPDATE calculation_tasks SET parent_task_id = ? WHERE task_id = ?",
            [parent_task_id, child_task_id]
        )
