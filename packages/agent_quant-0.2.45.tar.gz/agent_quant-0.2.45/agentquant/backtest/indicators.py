# -*- coding: utf-8 -*-
"""
技术指标计�?API

提供 agentquant 原生技术指标函数：
- get_data: 万能数据获取
- get_price: 获取行情价格
- get_indicator: 获取自定义指标�?- has_position: 判断持仓
- calc_ma: 计算移动平均�?- get_history: 获取历史K线数�?- query_db: 读取本地DuckDB数据
- add_fields: 注入自定义指标字�?"""

import pandas as pd
import numpy as np
from typing import Dict, List, Optional, Union, Any
from datetime import datetime, timedelta

from ..database.api import StockAPI


def get_data(data: Dict, key: str) -> Any:
    """
    万能数据获取
    
    Args:
        data: 数据字典
        key: 键�?        
    Returns:
        对应的数据值，不存在返回安全默认�?        
    支持�?key:
        - 'date_str' / 'date': 日期字符�?"YYYY-MM-DD"
        - 'date_num': 日期数字 "YYYYMMDD"
        - 'time_str' / 'time': 时间字符�?"HH:MM:SS"
        - 'datetime_str' / 'datetime': 完整时间字符�?        - 'timestamp': Unix 时间�?        - 'cash': 可用资金
        - 'market_value': 持仓市�?        - 'total_asset': 总资�?        - 'stocks': 股票池列�?        - 'first_stock': 股票池第一只股�?        - 'positions': 完整持仓字典
    """
    # 时间相关
    if key in ['date_str', 'date']:
        current = data.get('__current_time__', {})
        return current.get('date', '')
    
    if key == 'date_num':
        current = data.get('__current_time__', {})
        date_str = current.get('date', '')
        return date_str.replace('-', '') if date_str else ''
    
    if key in ['time_str', 'time']:
        current = data.get('__current_time__', {})
        return current.get('time', '00:00:00')
    
    if key in ['datetime_str', 'datetime']:
        current = data.get('__current_time__', {})
        date = current.get('date', '')
        time = current.get('time', '00:00:00')
        return f"{date} {time}" if date else ''
    
    if key == 'timestamp':
        current = data.get('__current_time__', {})
        dt_str = current.get('datetime', '')
        if dt_str:
            try:
                dt = datetime.strptime(dt_str, '%Y-%m-%d %H:%M:%S')
                return int(dt.timestamp())
            except:
                pass
        return 0
    
    # 资金和持�?    if key == 'cash':
        portfolio = data.get('__portfolio__', {})
        return portfolio.get('cash', 0.0)
    
    if key == 'market_value':
        portfolio = data.get('__portfolio__', {})
        return portfolio.get('market_value', 0.0)
    
    if key == 'total_asset':
        portfolio = data.get('__portfolio__', {})
        return portfolio.get('total_value', 0.0)
    
    if key == 'positions':
        portfolio = data.get('__portfolio__', {})
        return portfolio.get('positions', {})
    
    # 股票�?    if key == 'stocks':
        return data.get('__stocks__', [])
    
    if key == 'first_stock':
        stocks = data.get('__stocks__', [])
        return stocks[0] if stocks else None
    
    # 直接返回
    return data.get(key)


def get_price(data: Dict, stock_code: str, field: str = 'close') -> float:
    """
    获取行情价格
    
    Args:
        data: 数据字典，包含当前bar数据
        stock_code: 股票代码
        field: 价格字段 (open/high/low/close/volume)
        
    Returns:
        价格值，失败返回0.0
    """
    try:
        # 从当前bar数据获取
        bar_data = data.get('__bar_data__', {})
        stock_data = bar_data.get(stock_code, {})
        
        if field in stock_data:
            return float(stock_data[field])
        
        return 0.0
        
    except Exception:
        return 0.0


def get_indicator(data: Dict, stock_code: str, field: str) -> float:
    """
    获取自定义指标�?    
    读取通过 add_fields 预注入的指标字段
    
    Args:
        data: 数据字典
        stock_code: 股票代码
        field: 指标字段�?        
    Returns:
        指标值，失败返回0.0
    """
    return get_price(data, stock_code, field)


def has_position(data: Dict, stock_code: str) -> bool:
    """
    判断是否持有某只股票
    
    Args:
        data: 数据字典
        stock_code: 股票代码
        
    Returns:
        是否持仓
    """
    portfolio = data.get('__portfolio__', {})
    positions = portfolio.get('positions', {})
    
    # 支持带后缀和不带后缀的代�?    if stock_code in positions:
        return positions[stock_code].get('volume', 0) > 0
    
    # 尝试去掉后缀匹配
    code_no_suffix = stock_code.split('.')[0]
    for pos_code, pos_info in positions.items():
        if pos_code.startswith(code_no_suffix) and pos_info.get('volume', 0) > 0:
            return True
    
    return False


def calc_ma(
    stock_code: str,
    period: int,
    field: str = 'close',
    fre_step: str = '1d',
    end_time: Optional[str] = None,
    fq: str = 'pre',
    data: Optional[Dict] = None
) -> float:
    """
    计算移动平均�?    
    Args:
        stock_code: 股票代码
        period: 计算周期
        field: 计算字段
        fre_step: K线周期（1d/1m/5m�?        end_time: 截止时间（不含）
        fq: 复权类型
        data: 数据字典（回测时使用�?        
    Returns:
        MA�?    """
    try:
        api = StockAPI()
        
        # 查询历史数据
        query = f"""
            SELECT {field} 
            FROM market_data_daily 
            WHERE code = ? 
        """
        params = [stock_code]
        
        if end_time:
            # 转换日期格式
            if len(end_time) == 8:  # YYYYMMDD
                end_time = f"{end_time[:4]}-{end_time[4:6]}-{end_time[6:]}"
            query += " AND trade_date < ?"
            params.append(end_time)
        
        query += f" ORDER BY trade_date DESC LIMIT {period}"
        
        df = api.db_client.execute_query(query, params)
        
        if df.empty or len(df) < period:
            return 0.0
        
        return float(df[field].mean())
        
    except Exception as e:
        return 0.0


def get_history(
    stock_code: str,
    fields: List[str],
    count: int,
    fre_step: str = '1d',
    current_time: Optional[str] = None,
    fq: str = 'pre'
) -> pd.DataFrame:
    """
    获取历史K线数�?    
    Args:
        stock_code: 股票代码
        fields: 需要的字段列表 ['open','high','low','close','volume']
        count: 获取条数
        fre_step: K线周�?        current_time: 当前时间（用于计算历史范围）
        fq: 复权类型
        
    Returns:
        DataFrame，列名为 fields
    """
    try:
        api = StockAPI()
        
        # 构建查询
        fields_str = ', '.join(fields)
        query = f"""
            SELECT trade_date, {fields_str}
            FROM market_data_daily
            WHERE code = ?
        """
        params = [stock_code]
        
        if current_time:
            # 转换日期格式
            if len(current_time) == 8:  # YYYYMMDD
                current_time = f"{current_time[:4]}-{current_time[4:6]}-{current_time[6:]}"
            query += " AND trade_date <= ?"
            params.append(current_time)
        
        query += f" ORDER BY trade_date DESC LIMIT {count}"
        
        df = api.db_client.execute_query(query, params)
        
        if df.empty:
            return pd.DataFrame(columns=fields)
        
        # 按日期正序排�?        df = df.sort_values('trade_date')
        
        return df[fields]
        
    except Exception as e:
        return pd.DataFrame(columns=fields)


def query_db(
    sql: str,
    params: Optional[List] = None,
    as_dataframe: bool = True
) -> Union[pd.DataFrame, List]:
    """
    读取本地DuckDB历史数据
    
    Args:
        sql: SQL查询语句
        params: 查询参数
        as_dataframe: 是否返回DataFrame
        
    Returns:
        DataFrame �?列表
        
    示例:
        # 查询某只股票的所有数�?        df = query_db("SELECT * FROM market_data_daily WHERE code = ?", ['000001.SZ'])
        
        # 查询多只股票
        df = query_db("""
            SELECT code, trade_date, close 
            FROM market_data_daily 
            WHERE code IN (?, ?) 
            AND trade_date >= '2024-01-01'
        """, ['000001.SZ', '000002.SZ'])
    """
    try:
        api = StockAPI()
        df = api.db_client.execute_query(sql, params or [])
        
        if as_dataframe:
            return df
        else:
            return df.to_dict('records') if not df.empty else []
        
    except Exception as e:
        if as_dataframe:
            return pd.DataFrame()
        return []


def add_fields(context: Dict, fields: List[str]) -> None:
    """
    注入自定义指标字�?    
    在回测前预计算指标，避免重复计算
    
    Args:
        context: 回测上下�?        fields: 需要预计算的指标字段列�?        
    示例:
        # 在策略初始化时预计算指标
        def initialize(context):
            # 预计�?MA5, MA10, MA20
            add_fields(context, ['MA_5', 'MA_10', 'MA_20'])
    """
    if '__extra_fields__' not in context:
        context['__extra_fields__'] = []
    
    context['__extra_fields__'].extend(fields)


# 保持向后兼容的别名（已废弃，不建议使用）
khGet = get_data
khPrice = get_price
khIndex = get_indicator
khHas = has_position
khMA = calc_ma
khHistory = get_history
khDuckDB = query_db
khAddExtraFields = add_fields
