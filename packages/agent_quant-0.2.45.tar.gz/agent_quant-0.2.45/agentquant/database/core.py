"""
数据API - 提供统一的数据获取接口
"""
from typing import List, Dict, Optional, Union, Any
from datetime import date, datetime
import pandas as pd
from abc import ABC, abstractmethod


class DataSource(ABC):
    """数据源抽象基类"""

    @abstractmethod
    def get_daily(
        self,
        code: str,
        start: Union[str, date],
        end: Union[str, date],
        fields: Optional[List[str]] = None,
        adjust: str = 'none'
    ) -> pd.DataFrame:
        """获取日线数据"""
        pass

    @abstractmethod
    def get_minute(
        self,
        code: str,
        start: Union[str, date],
        end: Union[str, date],
        period: str = '1m',
        fields: Optional[List[str]] = None
    ) -> pd.DataFrame:
        """获取分钟线数据"""
        pass

    @abstractmethod
    def get_realtime(self, codes: List[str]) -> pd.DataFrame:
        """获取实时行情"""
        pass

    @abstractmethod
    def get_stock_list(self, market: Optional[str] = None) -> pd.DataFrame:
        """获取股票列表"""
        pass


class DataAPI:
    """
    数据API类 - 已实现

    提供统一的数据获取接口，支持多种数据源

    Examples:
        >>> from agentquant import StockClaw
        >>>
        >>> # 初始化SDK
        >>> sdk = StockClaw()
        >>>
        >>> # 获取单只股票日线数据
        >>> df = sdk.data.get_daily('000001.SZ', start='20240101', end='20241231')
        >>>
        >>> # 获取多只股票数据
        >>> df = sdk.data.get_daily(['000001.SZ', '000002.SZ'], start='20240101', end='20241231')
        >>>
        >>> # 获取分钟数据
        >>> df = sdk.data.get_minute('000001.SZ', start='20240101', end='20240131', period='5m')
        >>>
        >>> # 获取实时行情
        >>> rt = sdk.data.get_realtime(['000001.SZ', '000002.SZ'])
        >>>
        >>> # 下载数据到本地
        >>> result = sdk.data.download(['000001.SZ', '000002.SZ'], start='20200101', end='20241231')
    """

    def __init__(self, config: Dict[str, Any]):
        self._config = config
        self._impl = None
        self._init_impl()

    def _init_impl(self):
        """初始化实现"""
        try:
            from .data_implement import DataAPIImpl
            self._impl = DataAPIImpl(self._config)
        except Exception as e:
            import logging
            logging.getLogger(__name__).error(f"初始化DataAPI实现失败: {e}")
            self._impl = None

    def is_connected(self) -> bool:
        """检查是否已连接数据源"""
        return self._impl is not None and self._impl.is_connected()

    # ==================== 行情数据接口 ====================

    def get_daily(
        self,
        code: Union[str, List[str]],
        start: Union[str, date],
        end: Union[str, date],
        fields: Optional[List[str]] = None,
        adjust: str = 'none'
    ) -> pd.DataFrame:
        """
        获取日线数据

        Args:
            code: 股票代码或代码列表，如 '000001.SZ' 或 ['000001.SZ', '000002.SZ']
            start: 开始日期，格式 'YYYYMMDD' 或 date 对象
            end: 结束日期，格式 'YYYYMMDD' 或 date 对象
            fields: 字段列表，如 ['open', 'high', 'low', 'close', 'volume']，None表示全部
            adjust: 复权类型，'none'|'front'|'back'|'front_ratio'|'back_ratio'

        Returns:
            DataFrame，包含日线数据

        Examples:
            >>> df = sdk.data.get_daily('000001.SZ', start='20240101', end='20241231')
            >>> df = sdk.data.get_daily(['000001.SZ', '000002.SZ'], start='20240101', end='20241231')
        """
        if self._impl is None:
            raise RuntimeError("DataAPI未正确初始化")
        return self._impl.get_daily(code, start, end, fields, adjust)

    def get_minute(
        self,
        code: Union[str, List[str]],
        start: Union[str, date],
        end: Union[str, date],
        period: str = '1m',
        fields: Optional[List[str]] = None
    ) -> pd.DataFrame:
        """
        获取分钟线数据

        Args:
            code: 股票代码或代码列表
            start: 开始日期
            end: 结束日期
            period: 周期，'1m'|'5m'|'15m'|'30m'|'60m'
            fields: 字段列表

        Returns:
            DataFrame，索引为日期时间
        """
        if self._impl is None:
            raise RuntimeError("DataAPI未正确初始化")
        return self._impl.get_minute(code, start, end, period, fields)

    def get_realtime(
        self,
        codes: List[str],
        fields: Optional[List[str]] = None
    ) -> pd.DataFrame:
        """
        获取实时行情数据

        Args:
            codes: 股票代码列表
            fields: 字段列表，如 ['price', 'volume', 'bid1', 'ask1']

        Returns:
            DataFrame，索引为股票代码
        """
        if self._impl is None:
            raise RuntimeError("DataAPI未正确初始化")
        return self._impl.get_realtime(codes, fields)

    def get_tick(
        self,
        code: str,
        date: Union[str, date]
    ) -> pd.DataFrame:
        """
        获取Tick数据（逐笔成交）

        Args:
            code: 股票代码
            date: 日期

        Returns:
            DataFrame，包含每笔成交数据
        """
        if self._impl is None:
            raise RuntimeError("DataAPI未正确初始化")
        return self._impl.get_tick(code, date)

    # ==================== 股票信息接口 ====================

    def get_stock_list(
        self,
        market: Optional[str] = None,
        industry: Optional[str] = None,
        concept: Optional[str] = None
    ) -> pd.DataFrame:
        """
        获取股票列表

        Args:
            market: 市场筛选，'SH'|'SZ'|'BJ'|None
            industry: 行业筛选
            concept: 概念筛选

        Returns:
            DataFrame，包含股票基本信息
        """
        if self._impl is None:
            raise RuntimeError("DataAPI未正确初始化")
        return self._impl.get_stock_list(market, industry, concept)

    def get_stock_info(self, code: str) -> Dict[str, Any]:
        """
        获取单只股票详细信息

        Args:
            code: 股票代码

        Returns:
            包含股票详细信息的字典
        """
        if self._impl is None:
            raise RuntimeError("DataAPI未正确初始化")
        return self._impl.get_stock_info(code)

    def get_index_components(self, index_code: str) -> List[str]:
        """
        获取指数成分股

        Args:
            index_code: 指数代码，如 '000001.SH'(上证指数), '399001.SZ'(深证成指)

        Returns:
            成分股代码列表
        """
        if self._impl is None:
            raise RuntimeError("DataAPI未正确初始化")
        return self._impl.get_index_components(index_code)

    def get_industry_list(self) -> pd.DataFrame:
        """获取行业列表"""
        if self._impl is None:
            raise RuntimeError("DataAPI未正确初始化")
        return self._impl.get_industry_list()

    def get_concept_list(self) -> pd.DataFrame:
        """获取概念板块列表"""
        if self._impl is None:
            raise RuntimeError("DataAPI未正确初始化")
        return self._impl.get_concept_list()

    # ==================== 财务数据接口 ====================

    def get_financial(
        self,
        code: str,
        report_type: str = 'quarterly',
        fields: Optional[List[str]] = None
    ) -> pd.DataFrame:
        """
        获取财务数据

        Args:
            code: 股票代码
            report_type: 报告类型，'quarterly'|'annual'
            fields: 财务字段列表

        Returns:
            DataFrame，索引为报告期
        """
        if self._impl is None:
            raise RuntimeError("DataAPI未正确初始化")
        return self._impl.get_financial(code, report_type, fields)

    def get_valuation(
        self,
        code: str,
        fields: Optional[List[str]] = None
    ) -> pd.DataFrame:
        """
        获取估值指标

        Args:
            code: 股票代码
            fields: 字段列表，如 ['pe', 'pb', 'ps', 'pcf']

        Returns:
            DataFrame，索引为日期
        """
        if self._impl is None:
            raise RuntimeError("DataAPI未正确初始化")
        return self._impl.get_valuation(code, fields)

    # ==================== 数据管理接口 ====================

    def download(
        self,
        codes: Union[str, List[str]],
        period: str = '1d',
        start: Optional[Union[str, date]] = None,
        end: Optional[Union[str, date]] = None,
        source: str = 'auto'
    ) -> Dict[str, Any]:
        """
        下载数据到本地数据库

        Args:
            codes: 股票代码或列表
            period: 数据周期
            start: 开始日期
            end: 结束日期
            source: 数据源，'auto'|'qmt'|'tushare'|'baostock'

        Returns:
            下载结果统计
        """
        if self._impl is None:
            raise RuntimeError("DataAPI未正确初始化")
        return self._impl.download(codes, period, start, end, source)

    def update_daily(
        self,
        target_date: Optional[Union[str, date]] = None,
        batch_size: int = 500,
        progress_callback=None
    ) -> Dict[str, Any]:
        """
        日更新：获取所有股票某一天的日线数据并更新到数据库

        与download()的区别：
        - download: 少量股票 × 多天数据（历史补全）
        - update_daily: 所有股票 × 一天数据（每日增量）

        Args:
            target_date: 目标日期，默认今天。支持 date 对象或 'YYYYMMDD' 字符串
            batch_size: 每批获取的股票数量，默认500
            progress_callback: 进度回调 (batch_num, total_batches, success_count, total_records)

        Returns:
            {'total': 总股票数, 'success': 成功数, 'failed': 失败数,
             'records': 记录数, 'target_date': 目标日期}

        Examples:
            >>> # 更新今天的数据
            >>> result = sdk.data.update_daily()
            >>> # 补某一天的数据
            >>> result = sdk.data.update_daily('20260414')
        """
        if self._impl is None:
            raise RuntimeError("DataAPI未正确初始化")
        return self._impl.update_daily(target_date, batch_size, progress_callback)

    def subscribe(self, codes: List[str], callback: Optional[callable] = None) -> bool:
        """
        订阅实时行情

        Args:
            codes: 股票代码列表
            callback: 数据更新回调函数

        Returns:
            订阅是否成功
        """
        if self._impl is None:
            raise RuntimeError("DataAPI未正确初始化")
        return self._impl.subscribe(codes, callback)

    def unsubscribe(self, codes: Optional[List[str]] = None) -> bool:
        """
        取消订阅

        Args:
            codes: 股票代码列表，None表示取消所有

        Returns:
            取消是否成功
        """
        if self._impl is None:
            raise RuntimeError("DataAPI未正确初始化")
        return self._impl.unsubscribe(codes)
