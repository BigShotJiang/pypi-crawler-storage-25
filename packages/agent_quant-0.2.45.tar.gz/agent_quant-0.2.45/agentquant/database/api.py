# -*- coding: utf-8 -*-
"""
股票数据API

这是对外暴露的统一接口层，Skill直接调用这层。
内部协调 data_source（获取QMT实时数据）和 database（数据库存储）两层。

使用方法:
    from agentquant.api import StockAPI
    
    api = StockAPI()
    
    # 查询数据
    df = api.get_daily('000001.SZ', date(2026, 4, 17), date(2026, 4, 17))
    
    # 更新数据（从QMT获取并保存到数据库）
    api.update_daily(['000001.SZ'], date(2026, 4, 17))
"""

from datetime import date, datetime, time, timedelta
from typing import List, Optional, Union, Tuple
import pandas as pd
import logging

from .storage.db_client import DBClient
from .source.qmt import QMTDataSource

logger = logging.getLogger(__name__)


def is_trade_day(check_date: date) -> bool:
    """
    判断是否为交易日（简化版，排除周末）
    实际应该使用交易日历
    """
    return check_date.weekday() < 5  # 0-4 是周一到周五


def get_trade_time_status(check_datetime: datetime = None) -> Tuple[bool, str]:
    """
    获取当前交易时间状态
    
    Returns:
        (can_fetch_data: bool, message: str)
        can_fetch_data: 是否可以获取当天数据
        message: 状态说明
    """
    if check_datetime is None:
        check_datetime = datetime.now()
    
    current_date = check_datetime.date()
    current_time = check_datetime.time()
    
    # 检查是否是交易日
    if not is_trade_day(current_date):
        return False, f"{current_date} 不是交易日（周末）"
    
    # 交易时段定义
    morning_start = time(9, 30)
    morning_end = time(11, 30)
    afternoon_start = time(13, 0)
    afternoon_end = time(15, 0)
    
    # 数据可获取时间（收盘后，QMT通常在18:00后才有当天数据）
    data_available_time = time(18, 0)
    
    # 判断当前时间段
    if current_time < morning_start:
        return False, f"当前时间 {current_time.strftime('%H:%M')}，股市尚未开盘（9:30开盘）"
    elif morning_start <= current_time <= morning_end:
        return False, f"当前时间 {current_time.strftime('%H:%M')}，上午交易时段中，数据未收盘"
    elif morning_end < current_time < afternoon_start:
        return False, f"当前时间 {current_time.strftime('%H:%M')}，午间休市（11:30-13:00）"
    elif afternoon_start <= current_time <= afternoon_end:
        return False, f"当前时间 {current_time.strftime('%H:%M')}，下午交易时段中，数据未收盘"
    elif afternoon_end < current_time < data_available_time:
        return False, f"当前时间 {current_time.strftime('%H:%M')}，股市已收盘但QMT数据尚未同步（通常18:00后可获取）"
    else:
        return True, f"当前时间 {current_time.strftime('%H:%M')}，QMT数据应该已同步"


def check_can_fetch_today_data(target_date: date) -> Tuple[bool, str]:
    """
    检查是否可以获取指定日期的数据
    
    Returns:
        (can_fetch: bool, reason: str)
    """
    today = date.today()
    now = datetime.now()
    
    # 如果是未来日期
    if target_date > today:
        return False, f"{target_date} 是未来的日期，无法获取数据"
    
    # 如果是今天，需要检查交易时间
    if target_date == today:
        can_fetch, message = get_trade_time_status(now)
        if not can_fetch:
            return False, f"无法获取今天({today})的数据：{message}"
        return True, "可以获取今天数据"
    
    # 如果是过去的日期
    # 检查是否是交易日
    if not is_trade_day(target_date):
        return False, f"{target_date} 不是交易日（周末或节假日）"
    
    return True, "可以获取历史数据"


class StockAPI:
    """
    股票数据API
    
    提供股票数据的查询和更新功能。
    - 查询：从本地数据库获取
    - 更新：从QMT获取实时数据并保存到数据库
    """
    
    def __init__(self, host: str = '127.0.0.1', port: int = 9528):
        """
        初始化API
        
        Args:
            host: 数据库服务器地址
            port: 数据库服务器端口
        """
        self.db_client = DBClient(host=host, port=port)
        self._qmt_source = None
        
    def ping(self) -> bool:
        """检查数据库服务器是否可用"""
        return self.db_client.ping()
    
    # ==================== 查询接口 ====================
    
    def get_all_stocks(self) -> pd.DataFrame:
        """
        获取所有股票列表
        
        Returns:
            DataFrame包含股票代码、名称等信息
        """
        return self.db_client.get_all_stocks()
    
    def get_daily(
        self,
        code: str,
        start_date: date,
        end_date: date
    ) -> pd.DataFrame:
        """
        查询单只股票日线数据
        
        Args:
            code: 股票代码，如 '000001.SZ'
            start_date: 开始日期
            end_date: 结束日期
            
        Returns:
            DataFrame包含日线数据
        """
        return self.db_client.get_market_data_daily(code, start_date, end_date)
    
    def get_daily_multi(
        self,
        codes: List[str],
        start_date: date,
        end_date: date
    ) -> pd.DataFrame:
        """
        批量查询多只股票日线数据
        
        Args:
            codes: 股票代码列表
            start_date: 开始日期
            end_date: 结束日期
            
        Returns:
            DataFrame包含所有股票的日线数据
        """
        return self.db_client.get_market_data_daily_multi(codes, start_date, end_date)
    
    def get_latest_date(self) -> Optional[date]:
        """
        获取数据库中最新交易日期
        
        Returns:
            最新日期，如果没有数据返回None
        """
        return self.db_client.get_latest_trade_date()
    
    # ==================== 更新接口 ====================
    
    def _check_trade_date(
        self,
        target_date: date,
        test_code: str = '000001.SZ'
    ) -> tuple:
        """
        检查目标日期是否有数据
        
        Args:
            target_date: 目标日期
            test_code: 用于测试的股票代码
            
        Returns:
            tuple: (has_data, actual_date)
                - has_data: 是否有数据
                - actual_date: 实际返回的日期（用于检查是否匹配）
        """
        test_data = self._qmt_source.get_market_data_batch(
            [test_code], '1d', target_date, target_date
        )
        
        if test_data.empty:
            return False, None
        
        if 'trade_date' not in test_data.columns:
            return False, None
        
        actual_date_val = test_data['trade_date'].iloc[0]
        
        # 处理可能是字符串或date对象的情况
        if isinstance(actual_date_val, str):
            from datetime import datetime
            actual_date = datetime.strptime(actual_date_val, '%Y-%m-%d').date()
        else:
            actual_date = actual_date_val
        
        # 检查日期是否匹配（考虑QMT可能返回非交易日的最近交易日数据）
        is_match = (actual_date == target_date)
        
        return is_match, actual_date
    
    def update_daily(
        self,
        codes: List[str] = None,
        target_date: date = None
    ) -> dict:
        """
        更新日线数据

        从QMT获取实时数据并保存到数据库。
        自动处理QMT日期映射：如果目标日期没有数据，会自动获取最近一个交易日的数据。
        
        Args:
            codes: 股票代码列表，默认None表示更新所有股票
            target_date: 目标日期，默认None表示今天
            
        Returns:
            dict: {
                'success': bool,      # 是否成功
                'saved_count': int,   # 保存的记录数
                'message': str,       # 消息说明
                'requested_date': str, # 请求的日期
                'actual_date': str,   # 实际更新的日期（可能与请求日期不同）
                'is_mapping': bool    # 是否发生了日期映射
            }
        """
        if target_date is None:
            target_date = date.today()
        
        requested_date_str = target_date.strftime('%Y-%m-%d')
        
        # 0. 先检查时间是否允许获取数据
        can_fetch, time_message = check_can_fetch_today_data(target_date)
        if not can_fetch:
            return {
                'success': False,
                'saved_count': 0,
                'message': time_message,
                'requested_date': requested_date_str,
                'actual_date': None,
                'date_mismatch': False
            }
            
        logger.info(f"开始更新日线数据: {len(codes) if codes else '全部'} 只股票, 日期: {target_date}")
        
        try:
            # 1. 初始化QMT数据源
            if self._qmt_source is None:
                self._qmt_source = QMTDataSource()
                
            if not self._qmt_source.is_connected():
                return {
                    'success': False,
                    'saved_count': 0,
                    'message': 'QMT未连接。请检查：1. QMT客户端是否已启动并登录；2. miniQMT模式是否已运行；3. QMT安装路径是否正确（默认在C:\\国金证券QMT交易端）',
                    'requested_date': requested_date_str,
                    'actual_date': None,
                    'date_mismatch': False
                }
            
            # 2. 确定要更新的股票列表
            if codes:
                update_codes = codes
            else:
                update_codes = self._qmt_source.get_stock_list('all')
                
            if not update_codes:
                return {
                    'success': False,
                    'saved_count': 0,
                    'message': '没有可更新的股票',
                    'requested_date': requested_date_str,
                    'actual_date': None,
                    'date_mismatch': False
                }
                
            # 3. 检查目标日期是否有数据
            test_code = update_codes[0]
            has_data, actual_date = self._check_trade_date(target_date, test_code)
            
            if actual_date is None:
                # 区分是时间原因还是QMT连接问题
                today = date.today()
                now = datetime.now()
                if target_date == today and now.time() < time(18, 0):
                    return {
                        'success': False,
                        'saved_count': 0,
                        'message': f'今天({today})的数据尚未就绪。QMT通常在18:00后才有当天完整数据，当前时间 {now.strftime("%H:%M")}',
                        'requested_date': requested_date_str,
                        'actual_date': None,
                        'date_mismatch': False
                    }
                else:
                    return {
                        'success': False,
                        'saved_count': 0,
                        'message': f'QMT无法获取 {target_date} 的数据。请检查：1. QMT客户端是否已启动并登录；2. miniQMT模式是否已运行',
                        'requested_date': requested_date_str,
                        'actual_date': None,
                    'date_mismatch': False
                }
            
            actual_date_str = actual_date.strftime('%Y-%m-%d')
            
            # 如果日期不匹配（非交易日情况）
            if not has_data:
                return {
                    'success': False,
                    'saved_count': 0,
                    'message': f'{requested_date_str} 不是交易日，QMT返回的是 {actual_date_str} 的数据',
                    'requested_date': requested_date_str,
                    'actual_date': actual_date_str,
                    'date_mismatch': True
                }
            
            # 4. 分批获取数据并保存
            batch_size = 500
            total = len(update_codes)
            total_saved = 0
            
            for i in range(0, total, batch_size):
                batch_codes = update_codes[i:i + batch_size]
                
                # 从QMT获取数据
                df = self._qmt_source.get_market_data_batch(
                    batch_codes, '1d', target_date, target_date
                )
                
                if not df.empty:
                    # 保存到数据库
                    self.db_client.save_market_data_daily(df)
                    total_saved += len(df)
                    
            return {
                'success': True,
                'saved_count': total_saved,
                'message': f'成功更新 {len(update_codes)} 只股票，共 {total_saved} 条记录',
                'requested_date': requested_date_str,
                'actual_date': actual_date_str,
                'date_mismatch': False
            }
            
        except Exception as e:
            logger.error(f"更新失败: {e}")
            return {
                'success': False,
                'saved_count': 0,
                'message': f'更新失败: {str(e)}',
                'requested_date': requested_date_str,
                'actual_date': None,
                'date_mismatch': False
            }
