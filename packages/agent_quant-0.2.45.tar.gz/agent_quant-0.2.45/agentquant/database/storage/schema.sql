-- ============================================
-- ClawQuant 量化交易系统数据库 Schema (DuckDB)
-- ============================================

-- 1. 股票基础信息表
CREATE TABLE IF NOT EXISTS stocks (
    code VARCHAR PRIMARY KEY,           -- 股票代码: 000001.SZ
    name VARCHAR,                        -- 股票名称
    market VARCHAR,                      -- 市场: SZ/SH/BJ
    industry VARCHAR,                    -- 行业
    list_date DATE,                      -- 上市日期
    status VARCHAR DEFAULT 'active',     -- 状态: active/suspended/delisted
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. 行情数据表 (日线)
CREATE TABLE IF NOT EXISTS market_data_daily (
    trade_date DATE,                     -- 交易日期
    code VARCHAR,                        -- 股票代码
    open DOUBLE,                         -- 开盘价
    high DOUBLE,                         -- 最高价
    low DOUBLE,                          -- 最低价
    close DOUBLE,                        -- 收盘价
    volume BIGINT,                       -- 成交量
    amount DOUBLE,                       -- 成交额
    turnover_rate DOUBLE,                -- 换手率
    pe_ratio DOUBLE,                     -- 市盈率
    pb_ratio DOUBLE,                     -- 市净率
    market_cap DOUBLE,                   -- 总市值
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (trade_date, code)
);

-- 3. 行情数据表 (分钟线)
CREATE TABLE IF NOT EXISTS market_data_minute (
    trade_time TIMESTAMP,                -- 交易时间
    code VARCHAR,                        -- 股票代码
    period VARCHAR,                      -- 周期: 1m/5m/15m/30m/60m
    open DOUBLE,
    high DOUBLE,
    low DOUBLE,
    close DOUBLE,
    volume BIGINT,
    amount DOUBLE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (trade_time, code, period)
);

-- 4. 实时行情快照表
CREATE TABLE IF NOT EXISTS market_data_realtime (
    code VARCHAR PRIMARY KEY,            -- 股票代码
    trade_time TIMESTAMP,                -- 时间
    price DOUBLE,                        -- 最新价
    open DOUBLE,
    high DOUBLE,
    low DOUBLE,
    pre_close DOUBLE,                    -- 昨收
    volume BIGINT,
    amount DOUBLE,
    bid1_price DOUBLE,                   -- 买一价
    bid1_volume BIGINT,
    ask1_price DOUBLE,                   -- 卖一价
    ask1_volume BIGINT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 5. 新闻消息表
CREATE TABLE IF NOT EXISTS news (
    id INTEGER PRIMARY KEY,              -- 自增ID
    code VARCHAR,                        -- 股票代码(可为空表示全市场)
    title VARCHAR,                       -- 标题
    content TEXT,                        -- 内容
    source VARCHAR,                      -- 来源
    publish_time TIMESTAMP,              -- 发布时间
    sentiment_score DOUBLE,              -- 情感得分 -1~1
    importance INTEGER DEFAULT 3,        -- 重要程度 1-5
    tags VARCHAR[],                      -- 标签数组
    is_processed BOOLEAN DEFAULT FALSE,  -- 是否已处理
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 6. 公告表
CREATE TABLE IF NOT EXISTS announcements (
    id INTEGER PRIMARY KEY,
    code VARCHAR NOT NULL,               -- 股票代码
    title VARCHAR,                       -- 标题
    content TEXT,
    announce_type VARCHAR,               -- 公告类型
    publish_date DATE,
    file_url VARCHAR,
    is_processed BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 7. 研报表
CREATE TABLE IF NOT EXISTS research_reports (
    id INTEGER PRIMARY KEY,
    code VARCHAR,
    title VARCHAR,
    author VARCHAR,                      -- 分析师
    organization VARCHAR,                -- 机构
    rating VARCHAR,                      -- 评级
    target_price DOUBLE,
    publish_date DATE,
    tags VARCHAR[],
    is_processed BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 8. 自研股票评分表
CREATE TABLE IF NOT EXISTS stock_scores (
    calc_date DATE,                      -- 计算日期
    code VARCHAR,                        -- 股票代码
    fundamental_score DOUBLE,            -- 基本面得分
    technical_score DOUBLE,              -- 技术面得分
    sentiment_score DOUBLE,              -- 情绪面得分
    capital_flow_score DOUBLE,           -- 资金流向得分
    total_score DOUBLE,                  -- 总得分
    rank_in_market INTEGER,              -- 市场排名
    tags VARCHAR[],                      -- 标签
    summary TEXT,                        -- 分析摘要
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (calc_date, code)
);

-- 9. 自研研报摘要表
CREATE TABLE IF NOT EXISTS research_summaries (
    summary_date DATE,                   -- 汇总日期
    code VARCHAR,                        -- 股票代码
    news_count INTEGER DEFAULT 0,
    positive_news_count INTEGER DEFAULT 0,
    negative_news_count INTEGER DEFAULT 0,
    report_count INTEGER DEFAULT 0,
    our_rating VARCHAR,                  -- 我们的评级
    our_score DOUBLE,                    -- 我们的评分
    key_points TEXT[],                   -- 关键点
    risk_factors TEXT[],                 -- 风险因素
    tags VARCHAR[],
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (summary_date, code)
);

-- 10. 因子定义表
CREATE TABLE IF NOT EXISTS factor_definitions (
    factor_code VARCHAR PRIMARY KEY,     -- 因子代码
    factor_name VARCHAR,                 -- 因子名称
    category VARCHAR,                    -- 分类: 估值/成长/质量/动量/波动/情绪
    description TEXT,                    -- 描述
    formula TEXT,                        -- 计算公式
    parameters VARCHAR,                  -- 参数JSON
    frequency VARCHAR DEFAULT 'daily',   -- 更新频率
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 11. 因子值表
CREATE TABLE IF NOT EXISTS factor_values (
    calc_date DATE,                      -- 计算日期
    code VARCHAR,                        -- 股票代码
    factor_code VARCHAR,                 -- 因子代码
    value DOUBLE,                        -- 因子值
    rank_value INTEGER,                  -- 排名
    percentile DOUBLE,                   -- 百分位
    zscore DOUBLE,                       -- Z分数
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (calc_date, code, factor_code)
);

-- 12. 策略定义表
CREATE TABLE IF NOT EXISTS strategy_definitions (
    strategy_code VARCHAR PRIMARY KEY,   -- 策略代码
    strategy_name VARCHAR,               -- 策略名称
    strategy_type VARCHAR,               -- 类型: 选股/择时/套利
    description TEXT,
    factor_codes VARCHAR[],              -- 使用的因子列表
    entry_conditions VARCHAR,            -- 入场条件JSON
    exit_conditions VARCHAR,             -- 出场条件JSON
    position_sizing VARCHAR,             -- 仓位管理JSON
    status VARCHAR DEFAULT 'draft',      -- 状态
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 13. 策略信号表
CREATE TABLE IF NOT EXISTS strategy_signals (
    id INTEGER PRIMARY KEY,
    strategy_code VARCHAR,               -- 策略代码
    signal_time TIMESTAMP,               -- 信号时间
    code VARCHAR,                        -- 股票代码
    signal_type VARCHAR,                 -- BUY/SELL/HOLD
    strength DOUBLE,                     -- 信号强度
    price DOUBLE,
    volume INTEGER,
    reason TEXT,
    executed BOOLEAN DEFAULT FALSE,      -- 是否已执行
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 14. 回测任务表
CREATE TABLE IF NOT EXISTS backtest_tasks (
    task_id VARCHAR PRIMARY KEY,         -- 任务ID
    task_name VARCHAR,
    strategy_code VARCHAR,               -- 策略代码
    start_date DATE,                     -- 回测开始
    end_date DATE,                       -- 回测结束
    initial_capital DOUBLE DEFAULT 1000000,
    status VARCHAR DEFAULT 'pending',    -- pending/running/completed/failed
    progress DOUBLE DEFAULT 0,           -- 进度 0-100
    total_return DOUBLE,                 -- 总收益
    annual_return DOUBLE,                -- 年化收益
    sharpe_ratio DOUBLE,                 -- 夏普比率
    max_drawdown DOUBLE,                 -- 最大回撤
    win_rate DOUBLE,                     -- 胜率
    result_path VARCHAR,                 -- 结果文件路径
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP
);

-- 15. 回测交易记录表
CREATE TABLE IF NOT EXISTS backtest_trades (
    id INTEGER PRIMARY KEY,
    task_id VARCHAR,                     -- 关联任务
    trade_date DATE,                     -- 交易日期
    code VARCHAR,                        -- 股票代码
    trade_type VARCHAR,                  -- BUY/SELL
    price DOUBLE,
    volume INTEGER,
    amount DOUBLE,
    commission DOUBLE,                   -- 手续费
    reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 16. 回测持仓表
CREATE TABLE IF NOT EXISTS backtest_positions (
    id INTEGER PRIMARY KEY,
    task_id VARCHAR,
    trade_date DATE,
    code VARCHAR,
    volume INTEGER,
    cost_price DOUBLE,
    market_value DOUBLE,
    weight DOUBLE,                       -- 仓位权重
    unrealized_pnl DOUBLE,               -- 浮动盈亏
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 17. 回测每日净值表
CREATE TABLE IF NOT EXISTS backtest_nav (
    id INTEGER PRIMARY KEY,
    task_id VARCHAR,
    trade_date DATE,
    nav DOUBLE,                          -- 单位净值
    total_value DOUBLE,                  -- 总资产
    cash DOUBLE,                         -- 现金
    market_value DOUBLE,                 -- 市值
    daily_return DOUBLE,                 -- 日收益
    drawdown DOUBLE,                     -- 回撤
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 18. 模拟盘账户表
CREATE TABLE IF NOT EXISTS paper_accounts (
    account_id VARCHAR PRIMARY KEY,
    account_name VARCHAR,
    strategy_code VARCHAR,
    initial_capital DOUBLE,
    current_capital DOUBLE,
    total_pnl DOUBLE,
    status VARCHAR DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 19. 模拟盘持仓表
CREATE TABLE IF NOT EXISTS paper_positions (
    account_id VARCHAR,
    code VARCHAR,
    volume INTEGER DEFAULT 0,
    cost_price DOUBLE,
    current_price DOUBLE,
    market_value DOUBLE,
    unrealized_pnl DOUBLE,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (account_id, code)
);

-- 20. 模拟盘订单表
CREATE TABLE IF NOT EXISTS paper_orders (
    order_id INTEGER PRIMARY KEY,
    account_id VARCHAR,
    order_time TIMESTAMP,
    code VARCHAR,
    order_type VARCHAR,                  -- MARKET/LIMIT
    trade_type VARCHAR,                  -- BUY/SELL
    price DOUBLE,
    volume INTEGER,
    filled_volume INTEGER DEFAULT 0,
    status VARCHAR,                      -- pending/filled/cancelled
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 21. 实盘账户表
CREATE TABLE IF NOT EXISTS live_accounts (
    account_id VARCHAR PRIMARY KEY,
    account_name VARCHAR,
    broker VARCHAR,                      -- 券商
    qmt_account_id VARCHAR,              -- QMT账户ID
    strategy_code VARCHAR,
    initial_capital DOUBLE,
    status VARCHAR DEFAULT 'inactive',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 22. 实盘订单表
CREATE TABLE IF NOT EXISTS live_orders (
    order_id INTEGER PRIMARY KEY,
    account_id VARCHAR,
    order_time TIMESTAMP,
    code VARCHAR,
    order_type VARCHAR,
    trade_type VARCHAR,
    price DOUBLE,
    volume INTEGER,
    filled_volume INTEGER DEFAULT 0,
    avg_fill_price DOUBLE,
    status VARCHAR,
    qmt_order_id VARCHAR,                -- QMT订单ID
    commission DOUBLE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 23. 系统配置表
CREATE TABLE IF NOT EXISTS system_config (
    config_key VARCHAR PRIMARY KEY,
    config_value TEXT,
    description TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 24. 数据更新日志表
CREATE TABLE IF NOT EXISTS data_update_log (
    id INTEGER PRIMARY KEY,
    data_type VARCHAR,                   -- market_data/news/factor
    update_date DATE,
    records_count INTEGER,
    status VARCHAR,                      -- success/failed
    message TEXT,
    duration_ms INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- 创建索引 (优化查询性能)
-- ============================================

CREATE INDEX IF NOT EXISTS idx_market_data_code ON market_data_daily(code);
CREATE INDEX IF NOT EXISTS idx_market_data_date ON market_data_daily(trade_date);
CREATE INDEX IF NOT EXISTS idx_news_code ON news(code);
CREATE INDEX IF NOT EXISTS idx_news_time ON news(publish_time);
CREATE INDEX IF NOT EXISTS idx_factor_values_date ON factor_values(calc_date);
CREATE INDEX IF NOT EXISTS idx_factor_values_code ON factor_values(code);
CREATE INDEX IF NOT EXISTS idx_signals_time ON strategy_signals(signal_time);
CREATE INDEX IF NOT EXISTS idx_signals_strategy ON strategy_signals(strategy_code);
CREATE INDEX IF NOT EXISTS idx_backtest_trades_task ON backtest_trades(task_id);
CREATE INDEX IF NOT EXISTS idx_backtest_nav_task ON backtest_nav(task_id, trade_date);

-- ============================================
-- 25. 计算任务历史记录表 (Agent工作流支持)
-- ============================================
-- 用于记录所有计算任务，支持Agent链式调用和结果传递
CREATE TABLE IF NOT EXISTS calculation_tasks (
    task_id VARCHAR PRIMARY KEY,           -- 任务ID: TASK_20250108_001
    task_type VARCHAR NOT NULL,            -- 任务类型: factor_calc/factor_backtest/strategy_backtest/portfolio_opt
    task_name VARCHAR,                     -- 任务名称
    
    -- 输入参数摘要 (JSON格式，便于Agent理解)
    input_summary TEXT,                    -- 输入参数摘要描述
    input_params JSON,                     -- 完整输入参数
    
    -- 输出结果摘要 (便于Agent快速理解，无需读取详情)
    output_summary TEXT,                   -- 结果摘要描述
    output_metrics JSON,                   -- 关键指标 (如收益率、夏普比率等)
    
    -- 详细结果存储
    result_count INTEGER DEFAULT 0,        -- 结果条数
    result_data_path VARCHAR,              -- 详细结果文件路径 (Parquet/CSV)
    result_preview JSON,                   -- 结果预览 (前N条数据)
    
    -- 任务状态
    status VARCHAR DEFAULT 'pending',      -- pending/running/completed/failed/cancelled
    progress DOUBLE DEFAULT 0,             -- 进度 0-100
    
    -- 执行信息
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    duration_ms INTEGER,                   -- 执行时长(毫秒)
    error_message TEXT,                    -- 错误信息
    
    -- Agent工作流支持
    parent_task_id VARCHAR,                -- 父任务ID (支持任务链)
    child_task_ids JSON,                   -- 子任务ID列表
    
    -- 元数据
    tags VARCHAR[],                        -- 标签
    priority INTEGER DEFAULT 3,            -- 优先级 1-5
    created_by VARCHAR DEFAULT 'system',   -- 创建者: system/agent/user
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 计算任务索引
CREATE INDEX IF NOT EXISTS idx_calc_tasks_type ON calculation_tasks(task_type);
CREATE INDEX IF NOT EXISTS idx_calc_tasks_status ON calculation_tasks(status);
CREATE INDEX IF NOT EXISTS idx_calc_tasks_parent ON calculation_tasks(parent_task_id);
CREATE INDEX IF NOT EXISTS idx_calc_tasks_created ON calculation_tasks(created_at);
