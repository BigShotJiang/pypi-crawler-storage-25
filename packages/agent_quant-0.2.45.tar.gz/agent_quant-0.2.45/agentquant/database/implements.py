"""
DataAPI 实现模块
提供具体的数据获取实�?"""
from typing import List, Dict, Optional, Union, Any, Callable
from datetime import date, datetime, timedelta
import pandas as pd
import numpy as np
import logging
import os
import sys

logger = logging.getLogger(__name__)


class QMTDataSource:
    """QMT数据源实�?""
    
    def __init__(self, qmt_path: Optional[str] = None):
        self.qmt_path = qmt_path or self._detect_qmt_path()
        self.xtdata = None
        self._connected = False
        self._connect()
        
    def _detect_qmt_path(self) -> str:
        """自动检测QMT安装路径"""
        possible_paths = [
            r"C:\国金证券QMT交易�?,
            r"C:\workspace\国金证券QMT交易�?,
            r"C:\Program Files (x86)\国金证券QMT交易�?,
            r"D:\国金证券QMT交易�?,
        ]
        
        for path in possible_paths:
            if os.path.exists(path):
                logger.info(f"检测到QMT路径: {path}")
                return path
                
        raise FileNotFoundError("未找到QMT安装路径，请手动指定")
    
    def _connect(self):
        """连接QMT"""
        try:
            os.environ['QMT_PATH'] = self.qmt_path
            sys.path.insert(0, os.path.join(self.qmt_path, 'python'))
            
            from xtquant import xtdata
            self.xtdata = xtdata
            
            data_dir = os.path.join(self.qmt_path, 'userdata_mini', 'datadir')
            if os.path.exists(data_dir):
                self.xtdata.data_dir = data_dir
                
            self._connected = True
            logger.info(f"已连接QMT，数据目�? {data_dir}")
            
        except Exception as e:
            logger.error(f"连接QMT失败: {e}")
            self._connected = False
            
    def is_connected(self) -> bool:
        return self._connected
    
    def get_stock_list(self, market: str = 'all') -> List[str]:
        """获取股票列表"""
        if not self._connected:
            return []
            
        try:
            if market == 'all':
                stocks = self.xtdata.get_stock_list_in_sector('沪深A�?)
            elif market == 'SH':
                stocks = self.xtdata.get_stock_list_in_sector('上证A�?)
            elif market == 'SZ':
                stocks = self.xtdata.get_stock_list_in_sector('深证A�?)
            else:
                stocks = self.xtdata.get_stock_list_in_sector(market)
            return list(stocks)
        except Exception as e:
            logger.error(f"获取股票列表失败: {e}")
            return []
    
    def download_history_data(self, code: str, period: str = '1d',
                              start_date: Optional[date] = None,
                              end_date: Optional[date] = None) -> bool:
        """下载历史数据"""
        if not self._connected:
            return False
            
        try:
            if start_date is None:
                start_date = date.today() - timedelta(days=365*5)
            if end_date is None:
                end_date = date.today()
                
            start_str = start_date.strftime('%Y%m%d')
            end_str = end_date.strftime('%Y%m%d')
            
            result = self.xtdata.download_history_data(
                code, period=period, start_time=start_str, end_time=end_str
            )
            return result is not None
        except Exception as e:
            logger.error(f"下载历史数据失败 {code}: {e}")
            return False
    
    def get_market_data(self, code: str, period: str = '1d',
                        start_date: Optional[date] = None,
                        end_date: Optional[date] = None) -> pd.DataFrame:
        """获取行情数据"""
        if not self._connected:
            return pd.DataFrame()
            
        try:
            if start_date is None:
                start_date = date.today() - timedelta(days=365)
            if end_date is None:
                end_date = date.today()
                
            start_str = start_date.strftime('%Y%m%d')
            end_str = end_date.strftime('%Y%m%d')
            
            # 先下载数�?            self.download_history_data(code, period, start_date, end_date)
            
            # 获取数据
            data = self.xtdata.get_market_data_ex(
                field_list=['time', 'open', 'high', 'low', 'close', 'volume', 'amount',
                           'turnoverrate', 'pe', 'pb', 'totalcapital'],
                stock_list=[code],
                period=period,
                start_time=start_str,
                end_time=end_str
            )
            
            if data and code in data:
                df = data[code].copy()
                df['code'] = code
                return df
            return pd.DataFrame()
            
        except Exception as e:
            logger.error(f"获取行情数据失败 {code}: {e}")
            return pd.DataFrame()
    
    def get_realtime_quotes(self, codes: List[str]) -> pd.DataFrame:
        """获取实时行情"""
        if not self._connected:
            return pd.DataFrame()

        try:
            quotes = self.xtdata.get_full_tick(codes)

            data = []
            for code in codes:
                if code in quotes:
                    quote = quotes[code]
                    data.append({
                        'code': code,
                        'price': quote.get('lastPrice', 0),
                        'open': quote.get('open', 0),
                        'high': quote.get('high', 0),
                        'low': quote.get('low', 0),
                        'pre_close': quote.get('lastClose', 0),
                        'volume': quote.get('volume', 0),
                        'amount': quote.get('amount', 0),
                        'bid1_price': quote.get('bid1', 0),
                        'bid1_volume': quote.get('bid1_vol', 0),
                        'ask1_price': quote.get('ask1', 0),
                        'ask1_volume': quote.get('ask1_vol', 0),
                    })

            return pd.DataFrame(data)

        except Exception as e:
            logger.error(f"获取实时行情失败: {e}")
            return pd.DataFrame()

    def get_market_data_batch(self, codes: List[str], period: str = '1d',
                              start_date: Optional[date] = None,
                              end_date: Optional[date] = None) -> pd.DataFrame:
        """
        批量获取多只股票的行情数据（一次API调用�?        
        与get_market_data不同，这里直接把多只股票传给xtdata�?        适合"所有股票只取少量天�?的场景（如日更新�?        
        Args:
            codes: 股票代码列表
            period: 数据周期
            start_date: 开始日�?            end_date: 结束日期
            
        Returns:
            合并后的DataFrame，包含所有股票数�?        """
        if not self._connected or not codes:
            return pd.DataFrame()

        try:
            if start_date is None:
                start_date = date.today()
            if end_date is None:
                end_date = date.today()

            start_str = start_date.strftime('%Y%m%d')
            end_str = end_date.strftime('%Y%m%d')

            # 批量下载
            for code in codes:
                try:
                    self.xtdata.download_history_data(
                        code, period=period,
                        start_time=start_str, end_time=end_str
                    )
                except Exception:
                    pass

            # 一次性批量获�?            data = self.xtdata.get_market_data_ex(
                field_list=['time', 'open', 'high', 'low', 'close', 'volume', 'amount',
                           'turnoverrate', 'pe', 'pb', 'totalcapital'],
                stock_list=codes,
                period=period,
                start_time=start_str,
                end_time=end_str
            )

            if not data:
                return pd.DataFrame()

            dfs = []
            for code, df in data.items():
                if df is not None and not df.empty:
                    df = df.copy()
                    df['code'] = code
                    dfs.append(df)

            if dfs:
                return pd.concat(dfs, ignore_index=True)
            return pd.DataFrame()

        except Exception as e:
            logger.error(f"批量获取行情数据失败: {e}")
            return pd.DataFrame()


class DuckDBDataSource:
    """DuckDB本地数据源实�?""
    
    def __init__(self, db_manager):
        self.db = db_manager
        
    def get_daily(self, code: Union[str, List[str]],
                  start: Union[str, date],
                  end: Union[str, date],
                  fields: Optional[List[str]] = None,
                  adjust: str = 'none') -> pd.DataFrame:
        """从DuckDB获取日线数据"""
        # 转换日期格式
        if isinstance(start, str):
            start = datetime.strptime(start, '%Y%m%d').date()
        if isinstance(end, str):
            end = datetime.strptime(end, '%Y%m%d').date()
            
        if isinstance(code, list):
            return self.db.get_market_data_daily_multi(code, start, end)
        else:
            return self.db.get_market_data_daily(code, start, end)
    
    def get_stock_list(self, market: Optional[str] = None) -> pd.DataFrame:
        """获取股票列表"""
        df = self.db.get_all_stocks()
        if market and not df.empty:
            df = df[df['market'] == market]
        return df
    
    def get_realtime(self, codes: List[str]) -> pd.DataFrame:
        """获取实时行情快照"""
        return self.db.get_realtime_quotes(codes)


class DataAPIImpl:
    """DataAPI实现�?""
    
    def __init__(self, config: Dict[str, Any]):
        self._config = config
        self._db = None
        self._qmt = None
        self._primary_source = config.get('data_source', 'auto')
        
        # 初始化数据库连接
        # db_mode: 'service'(通过db_service) | 'direct'(直连DuckDB)  | 'auto'(优先service)
        self._db_mode = config.get('db_mode', 'auto')
        self._init_db()
        
        # 初始化QMT连接
        if self._primary_source in ['auto', 'qmt']:
            self._init_qmt()
    
    def _init_db(self):
        """初始化数据库 - 通过TCP连接"""
        try:
            from database.storage.db_client import DBClient
            host = self._config.get('db_host', '127.0.0.1')
            port = self._config.get('db_port', 9528)
            client = DBClient(host=host, port=port)
            if client.ping():
                self._db = client
                self._duckdb_source = DuckDBDataSource(self._db)
                logger.info(f"已连接数据库服务: {host}:{port}")
                return
            else:
                raise ConnectionError("数据库服务无响应")
        except Exception as e:
            logger.error(f"连接数据库服务失�? {e}")
            logger.error("请确保数据库服务已启�? python -m agentquant.cli db start")
            self._db = None
            raise RuntimeError(f"无法连接数据库服�? {e}")
    
    def _init_qmt(self):
        """初始化QMT"""
        try:
            qmt_path = self._config.get('qmt_path')
            self._qmt = QMTDataSource(qmt_path)
            logger.info("QMT连接成功")
        except Exception as e:
            logger.warning(f"QMT连接失败: {e}")
            self._qmt = None
    
    def is_connected(self) -> bool:
        """检查是否已连接"""
        return self._db is not None
    
    def get_daily(self, code: Union[str, List[str]],
                  start: Union[str, date],
                  end: Union[str, date],
                  fields: Optional[List[str]] = None,
                  adjust: str = 'none') -> pd.DataFrame:
        """
        获取日线数据
        
        优先从本地DuckDB获取，如果没有则从QMT获取并缓�?        """
        # 转换日期格式
        if isinstance(start, str):
            start = datetime.strptime(start, '%Y%m%d').date()
        if isinstance(end, str):
            end = datetime.strptime(end, '%Y%m%d').date()
            
        # 先从本地数据库查�?        if self._db:
            try:
                if isinstance(code, list):
                    df = self._db.get_market_data_daily_multi(code, start, end)
                else:
                    df = self._db.get_market_data_daily(code, start, end)
                    
                if not df.empty:
                    # 字段筛�?                    if fields:
                        available_cols = ['trade_date', 'code'] + fields
                        df = df[[col for col in available_cols if col in df.columns]]
                    return df
            except Exception as e:
                logger.warning(f"从数据库获取数据失败: {e}")
        
        # 如果本地没有，从QMT获取
        if self._qmt and self._qmt.is_connected():
            logger.info(f"从QMT获取数据: {code}")
            
            if isinstance(code, list):
                dfs = []
                for c in code:
                    df = self._qmt.get_market_data(c, '1d', start, end)
                    if not df.empty:
                        dfs.append(df)
                if dfs:
                    df = pd.concat(dfs, ignore_index=True)
                else:
                    return pd.DataFrame()
            else:
                df = self._qmt.get_market_data(code, '1d', start, end)
                
            if not df.empty:
                # 标准化列�?                df = self._standardize_columns(df)
                # 保存到本地缓�?                if self._db:
                    self._db.save_market_data_daily(df)
                return df
                
        return pd.DataFrame()
    
    def get_minute(self, code: Union[str, List[str]],
                   start: Union[str, date],
                   end: Union[str, date],
                   period: str = '1m',
                   fields: Optional[List[str]] = None) -> pd.DataFrame:
        """获取分钟线数�?""
        # 分钟数据通常从QMT实时获取
        if not self._qmt or not self._qmt.is_connected():
            raise ValueError("QMT未连接，无法获取分钟数据")
            
        if isinstance(code, list):
            dfs = []
            for c in code:
                df = self._qmt.get_market_data(c, period, start, end)
                if not df.empty:
                    dfs.append(df)
            return pd.concat(dfs, ignore_index=True) if dfs else pd.DataFrame()
        else:
            return self._qmt.get_market_data(code, period, start, end)
    
    def get_realtime(self, codes: List[str],
                     fields: Optional[List[str]] = None) -> pd.DataFrame:
        """获取实时行情"""
        if self._qmt and self._qmt.is_connected():
            df = self._qmt.get_realtime_quotes(codes)
            if not df.empty and fields:
                available_cols = ['code'] + fields
                df = df[[col for col in available_cols if col in df.columns]]
            return df
        return pd.DataFrame()
    
    def get_tick(self, code: str, date: Union[str, date]) -> pd.DataFrame:
        """获取Tick数据"""
        if not self._qmt or not self._qmt.is_connected():
            raise ValueError("QMT未连接，无法获取Tick数据")
            
        if isinstance(date, str):
            date = datetime.strptime(date, '%Y%m%d').date()
            
        return self._qmt.get_market_data(code, 'tick', date, date)
    
    def get_stock_list(self, market: Optional[str] = None,
                       industry: Optional[str] = None,
                       concept: Optional[str] = None) -> pd.DataFrame:
        """获取股票列表"""
        if self._db:
            df = self._db.get_all_stocks()
            if market and not df.empty:
                df = df[df['market'] == market]
            return df
        return pd.DataFrame()
    
    def get_stock_info(self, code: str) -> Dict[str, Any]:
        """获取单只股票详细信息"""
        if self._db:
            return self._db.get_stock_info(code) or {}
        return {}
    
    def get_index_components(self, index_code: str) -> List[str]:
        """获取指数成分�?""
        if self._qmt and self._qmt.is_connected():
            try:
                stocks = self._qmt.xtdata.get_stock_list_in_sector(index_code)
                return list(stocks)
            except Exception as e:
                logger.error(f"获取指数成分股失�? {e}")
        return []
    
    def get_industry_list(self) -> pd.DataFrame:
        """获取行业列表"""
        if self._db:
            df = self._db.get_all_stocks()
            if not df.empty and 'industry' in df.columns:
                industries = df['industry'].dropna().unique()
                return pd.DataFrame({'industry': industries})
        return pd.DataFrame()
    
    def get_concept_list(self) -> pd.DataFrame:
        """获取概念板块列表"""
        # 概念板块需要从QMT或其他数据源获取
        if self._qmt and self._qmt.is_connected():
            try:
                # 获取概念板块列表
                concepts = self._qmt.xtdata.get_sector_list()
                return pd.DataFrame({'concept': concepts})
            except Exception as e:
                logger.error(f"获取概念列表失败: {e}")
        return pd.DataFrame()
    
    def download(self, codes: Union[str, List[str]],
                 period: str = '1d',
                 start: Optional[Union[str, date]] = None,
                 end: Optional[Union[str, date]] = None,
                 source: str = 'auto',
                 progress_callback: Optional[Callable[[str, int, int, int], None]] = None,
                 batch_size: int = 100,
                 batch_pause: float = 1.0) -> Dict[str, Any]:
        """
        下载数据到本地数据库
        
        Args:
            codes: 股票代码或列�?            period: 数据周期
            start: 开始日�?            end: 结束日期
            source: 数据�?            progress_callback: 进度回调函数(code, current, total, records_in_batch)
            batch_size: 每批处理的股票数
            batch_pause: 批次间暂停时间（秒）
            
        Returns:
            下载结果统计
        """
        if not self._qmt or not self._qmt.is_connected():
            return {'success': 0, 'failed': 0, 'error': 'QMT未连�?}
            
        if isinstance(codes, str):
            codes = [codes]
            
        if start is None:
            start = date.today() - timedelta(days=365*5)
        if end is None:
            end = date.today()
            
        if isinstance(start, str):
            start = datetime.strptime(start, '%Y%m%d').date()
        if isinstance(end, str):
            end = datetime.strptime(end, '%Y%m%d').date()
            
        stats = {'total': len(codes), 'success': 0, 'failed': 0, 'records': 0}
        total = len(codes)
        
        for batch_start in range(0, total, batch_size):
            batch_end = min(batch_start + batch_size, total)
            batch = codes[batch_start:batch_end]
            batch_num = batch_start // batch_size + 1
            total_batches = (total - 1) // batch_size + 1
            
            logger.info(f"处理�?{batch_num}/{total_batches} 批，�?{len(batch)} 只股�?)
            batch_records = 0
            
            for i, code in enumerate(batch):
                current = batch_start + i + 1
                try:
                    logger.debug(f"下载数据 {code} ({current}/{total})")
                    
                    df = self._qmt.get_market_data(code, period, start, end)
                    
                    if not df.empty:
                        df = self._standardize_columns(df)
                        self._db.save_market_data_daily(df)
                        stats['success'] += 1
                        stats['records'] += len(df)
                        batch_records += len(df)
                    else:
                        stats['failed'] += 1
                        
                except Exception as e:
                    logger.error(f"下载失败 {code}: {e}")
                    stats['failed'] += 1
                
                # 调用进度回调
                if progress_callback:
                    try:
                        progress_callback(code, current, total, batch_records)
                    except Exception as e:
                        logger.warning(f"进度回调出错: {e}")
            
            # 批次间暂�?            if batch_end < total and batch_pause > 0:
                logger.info(f"�?{batch_num} 批完成，暂停 {batch_pause} �?..")
                import time
                time.sleep(batch_pause)
                
        return stats

    def update_daily(self,
                     target_date: Optional[Union[str, date]] = None,
                     batch_size: int = 500,
                     save_batch_size: int = 100,
                     progress_callback: Optional[Callable[[int, int, int, int], None]] = None
                     ) -> Dict[str, Any]:
        """
        日更新：获取所有股票某一天的日线数据并更新到数据�?        
        与download()的区别：
        - download: 少量股票 × 多天数据（历史补全）
        - update_daily: 所有股�?× 一天数据（每日增量�?        
        利用xtdata批量接口，一次传几百只股票获取同一天数据，效率更高�?        数据会分批保存，避免一次性保存大量数据导致超时�?        
        Args:
            target_date: 目标日期，默认今天。支�?date 对象�?'YYYYMMDD' 字符�?            batch_size: 每批获取的股票数量（传给xtdata的stock_list长度�?            save_batch_size: 每批保存的记录数，默�?00�?            progress_callback: 进度回调 (batch_num, total_batches, batch_success, total_records)
            
        Returns:
            {'total': 总股票数, 'success': 成功�? 'failed': 失败�?
             'records': 总记录数, 'target_date': 目标日期}
        """
        if not self._qmt or not self._qmt.is_connected():
            return {'success': 0, 'failed': 0, 'error': 'QMT未连�?}
        if not self._db:
            return {'success': 0, 'failed': 0, 'error': '数据库未连接'}

        # 解析目标日期
        if target_date is None:
            target_date = date.today()
        elif isinstance(target_date, str):
            target_date = datetime.strptime(target_date, '%Y%m%d').date()

        # 从数据库获取所有股票代�?        all_stocks_df = self._db.get_all_stocks()
        if all_stocks_df.empty:
            # 数据库没有股票列表，从QMT�?            all_codes = self._qmt.get_stock_list('all')
        else:
            all_codes = all_stocks_df['code'].tolist()

        if not all_codes:
            return {'success': 0, 'failed': 0, 'error': '没有股票列表'}

        total = len(all_codes)
        total_batches = (total - 1) // batch_size + 1
        stats = {
            'total': total,
            'success': 0,
            'failed': 0,
            'records': 0,
            'target_date': str(target_date),
        }

        logger.info(f"开始日更新: {target_date}, �?{total} 只股�? �?{total_batches} �? 每批保存{save_batch_size}�?)

        for batch_idx in range(total_batches):
            batch_start = batch_idx * batch_size
            batch_end = min(batch_start + batch_size, total)
            batch_codes = all_codes[batch_start:batch_end]
            batch_num = batch_idx + 1

            try:
                # 批量获取这一批股票当天的数据
                df = self._qmt.get_market_data_batch(
                    batch_codes, '1d', target_date, target_date
                )

                if not df.empty:
                    df = self._standardize_columns(df)
                    
                    # 分批保存数据，避免一次性保存大量数�?                    total_records = len(df)
                    saved_records = 0
                    for i in range(0, total_records, save_batch_size):
                        save_batch = df.iloc[i:i+save_batch_size]
                        self._db.save_market_data_daily(save_batch)
                        saved_records += len(save_batch)
                        # 短暂暂停，避免数据库过载
                        if i + save_batch_size < total_records:
                            import time
                            time.sleep(0.05)
                    
                    batch_success = df['code'].nunique()
                    batch_records = len(df)
                    stats['success'] += batch_success
                    stats['records'] += batch_records
                    stats['failed'] += len(batch_codes) - batch_success
                else:
                    stats['failed'] += len(batch_codes)
                    batch_success = 0
                    batch_records = 0

                logger.info(
                    f"�?{batch_num}/{total_batches} 批完�? "
                    f"{batch_success}/{len(batch_codes)} 只成�? {batch_records} 条记�?
                )

            except Exception as e:
                logger.error(f"�?{batch_num}/{total_batches} 批失�? {e}")
                import traceback
                traceback.print_exc()
                stats['failed'] += len(batch_codes)
                batch_success = 0

            # 进度回调
            if progress_callback:
                try:
                    progress_callback(batch_num, total_batches, stats['success'], stats['records'])
                except Exception as e:
                    logger.warning(f"进度回调出错: {e}")

        logger.info(
            f"日更新完�? {stats['success']}/{stats['total']} 只成�? "
            f"�?{stats['records']} 条记�?
        )
        return stats

    def _standardize_columns(self, df: pd.DataFrame) -> pd.DataFrame:
        """标准化列�?""
        column_mapping = {
            'time': 'trade_date',
            'Time': 'trade_date',
            'turnoverrate': 'turnover_rate',
            'pe': 'pe_ratio',
            'pb': 'pb_ratio',
            'totalcapital': 'market_cap',
        }

        df = df.rename(columns=column_mapping)

        # 确保trade_date是日期格�?        if 'trade_date' in df.columns:
            # 判断数据类型：如果是数值型（时间戳），用unit='ms'转换；否则直接转�?            if pd.api.types.is_numeric_dtype(df['trade_date']):
                # QMT返回的是毫秒时间�?                df['trade_date'] = pd.to_datetime(df['trade_date'], unit='ms').dt.date
            else:
                # 字符串或其他格式，直接转�?                df['trade_date'] = pd.to_datetime(df['trade_date']).dt.date

        # 确保数值列为float类型
        numeric_cols = ['open', 'high', 'low', 'close', 'volume', 'amount',
                       'turnover_rate', 'pe_ratio', 'pb_ratio', 'market_cap']
        for col in numeric_cols:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors='coerce')

        return df
    
    def subscribe(self, codes: List[str], callback: Optional[callable] = None) -> bool:
        """订阅实时行情"""
        # 实时订阅功能需要配合QMT的回调机�?        logger.warning("实时订阅功能暂未实现")
        return False
    
    def unsubscribe(self, codes: Optional[List[str]] = None) -> bool:
        """取消订阅"""
        return True
