# -*- coding: utf-8 -*-
"""
任务管理 CLI 子命令

提供计算任务的管理功能，支持Agent驱动的工作流：
- task create: 创建新任务
- task list: 列出所有任务
- task get: 获取任务详情
- task run: 运行因子/策略计算任务
- task result: 获取任务结果
- task chain: 创建任务链

使用方法:
    # 创建因子计算任务
    python -m agentquant.cli task create --type factor --name MA5_CALC --params '{"code":"000001.SZ","window":5}'
    
    # 列出所有任务
    python -m agentquant.cli task list --status completed --limit 10
    
    # 获取任务摘要（给Agent用）
    python -m agentquant.cli task get <task_id> --summary
    
    # 运行因子计算
    python -m agentquant.cli task run-factor --code 000001.SZ --factor MA5 --window 5
    
    # 运行策略回测
    python -m agentquant.cli task run-strategy --code 000001.SZ --strategy CROSS --start 2024-01-01 --end 2024-06-01
    
    # 获取任务结果详情
    python -m agentquant.cli task result <task_id> --preview
"""

import argparse
import json
import sys
import os
from datetime import datetime, date
from typing import Optional, List, Dict, Any
import pandas as pd

from .api.task_api import TaskManager
from .api.backtest_api import BacktestToolAPI
from .database.api import StockAPI


def format_output(data: dict) -> str:
    """格式化输出为JSON"""
    return json.dumps(data, ensure_ascii=False, indent=2)


def cmd_task_create(args):
    """创建新任务"""
    task_mgr = TaskManager()
    
    try:
        # 解析参数
        params = {}
        if args.params:
            params = json.loads(args.params)
        
        # 添加其他参数
        if args.code:
            params['code'] = args.code
        if args.start:
            params['start_date'] = args.start
        if args.end:
            params['end_date'] = args.end
        
        # 创建任务
        task = task_mgr.create_task(
            task_type=args.type,
            task_name=args.name,
            input_params=params,
            created_by=args.created_by or 'cli'
        )
        
        print(f"\n✓ 任务创建成功")
        print(f"  任务ID: {task['task_id']}")
        print(f"  任务类型: {task['task_type']}")
        print(f"  任务名称: {task['task_name']}")
        print(f"  输入摘要: {task['input_summary']}")
        print(f"  状态: {task['status']}")
        print(f"  创建时间: {task['created_at']}")
        
        # 输出JSON格式（供Agent使用）
        if args.json:
            print(f"\n{format_output(task)}")
        
        return task['task_id']
        
    except Exception as e:
        print(f"✗ 任务创建失败: {e}")
        sys.exit(1)


def cmd_task_list(args):
    """列出所有任务"""
    task_mgr = TaskManager()
    
    try:
        tasks = task_mgr.list_tasks(
            task_type=args.type,
            status=args.status,
            limit=args.limit or 50
        )
        
        if not tasks:
            print("\n没有找到任务记录")
            return
        
        print(f"\n共 {len(tasks)} 个任务:\n")
        print(f"{'任务ID':<25} {'类型':<12} {'名称':<20} {'状态':<10} {'进度':<8} {'创建时间'}")
        print("-" * 100)
        
        for task in tasks:
            task_id = task['task_id'][:22] + "..." if len(task['task_id']) > 25 else task['task_id']
            task_type = str(task.get('task_type', '-'))[:10]
            name = str(task.get('task_name', '-'))[:18]
            status = str(task.get('status', '-'))
            progress = f"{task.get('progress', 0):.0f}%"
            created_at = task.get('created_at', '-')
            if hasattr(created_at, 'strftime'):
                created = created_at.strftime('%Y-%m-%d %H:%M:%S')[:19]
            else:
                created = str(created_at)[:19]
            
            print(f"{task_id:<25} {task_type:<12} {name:<20} {status:<10} {progress:<8} {created}")
        
        print()
        
        # 输出JSON格式（供Agent使用）
        if args.json:
            print(format_output({'tasks': tasks}))
        
    except Exception as e:
        print(f"✗ 获取任务列表失败: {e}")
        sys.exit(1)


def cmd_task_get(args):
    """获取任务详情"""
    task_mgr = TaskManager()
    
    try:
        if args.summary:
            # 获取摘要（给Agent用，不包含大数据）
            task = task_mgr.get_task_summary_for_agent(args.task_id)
            print(f"\n📋 任务摘要 (适合Agent)\n")
        else:
            # 获取完整详情
            task = task_mgr.get_task(args.task_id)
            print(f"\n📋 任务详情\n")
        
        if not task:
            print(f"✗ 任务不存在: {args.task_id}")
            sys.exit(1)
        
        print(f"任务ID: {task['task_id']}")
        print(f"任务类型: {task.get('task_type', '-')}")
        print(f"任务名称: {task.get('task_name', '-')}")
        print(f"状态: {task.get('status', '-')}")
        print(f"进度: {task.get('progress', 0):.1f}%")
        print(f"创建时间: {task.get('created_at', '-')}")
        
        if task.get('started_at'):
            print(f"开始时间: {task['started_at']}")
        if task.get('completed_at'):
            print(f"完成时间: {task['completed_at']}")
        if task.get('duration_ms'):
            print(f"执行时长: {task['duration_ms']}ms")
        
        print(f"\n输入摘要:")
        print(f"  {task.get('input_summary', '-')}")
        
        if task.get('output_summary'):
            print(f"\n输出摘要:")
            print(f"  {task['output_summary']}")
        
        if task.get('output_metrics'):
            print(f"\n指标数据:")
            metrics = task['output_metrics']
            if isinstance(metrics, str):
                metrics = json.loads(metrics)
            for key, value in metrics.items():
                print(f"  {key}: {value}")
        
        if task.get('result_preview') and not args.summary:
            print(f"\n结果预览:")
            preview = task['result_preview']
            if isinstance(preview, str):
                preview = json.loads(preview)
            for i, row in enumerate(preview[:5]):
                print(f"  {row}")
            if len(preview) > 5:
                print(f"  ... 还有 {len(preview) - 5} 条")
        
        if task.get('result_count'):
            print(f"\n结果数量: {task['result_count']} 条")
        if task.get('result_data_path'):
            print(f"结果文件: {task['result_data_path']}")
        
        if task.get('agent_decision'):
            print(f"\nAgent决策: {task['agent_decision']}")
        if task.get('next_action'):
            print(f"下一步动作: {task['next_action']}")
        
        if task.get('error_message'):
            print(f"\n❌ 错误信息:")
            print(f"  {task['error_message']}")
        
        print()
        
        # 输出JSON格式（供Agent使用）
        if args.json:
            print(format_output(task))
        
    except Exception as e:
        print(f"✗ 获取任务详情失败: {e}")
        sys.exit(1)


def cmd_task_run_factor(args):
    """运行因子计算任务"""
    task_mgr = TaskManager()
    
    try:
        # 创建任务
        params = {
            'code': args.code,
            'factor': args.factor,
            'window': args.window,
            'start_date': args.start,
            'end_date': args.end
        }
        
        task = task_mgr.create_task(
            task_type='factor_calc',
            task_name=f"{args.factor}_{args.code}",
            input_params=params,
            created_by='cli'
        )
        
        task_id = task['task_id']
        print(f"\n📊 创建因子计算任务: {task_id}")
        print(f"  股票代码: {args.code}")
        print(f"  因子: {args.factor}")
        print(f"  窗口期: {args.window}")
        print(f"  时间范围: {args.start or 'auto'} 至 {args.end or 'auto'}")
        
        # 启动任务
        task_mgr.start_task(task_id)
        print(f"\n⏳ 开始计算...")
        
        # 执行计算
        api = BacktestToolAPI()
        start_time = datetime.now()
        
        result = api.calculate_factor_values(
            factor_code=args.factor,
            codes=[args.code],
            factor_params={'window': args.window},
            create_task=False  # 已经在上面创建了任务
        )
        
        duration_ms = int((datetime.now() - start_time).total_seconds() * 1000)
        
        # 完成任务 - 将数据转换为DataFrame
        import pandas as pd
        result_df = None
        if result.get('data'):
            result_df = pd.DataFrame(result.get('data'))
        
        task_mgr.complete_task(
            task_id=task_id,
            result=result,
            result_df=result_df
        )
        
        print(f"\n✓ 因子计算完成!")
        print(f"  执行时长: {duration_ms}ms")
        
        if result.get('success'):
            data = result.get('data')
            if data and len(data) > 0:
                print(f"  结果数量: {len(data)} 条")
                print(f"\n  最新结果:")
                latest = data[-1]
                print(f"    日期: {latest.get('date', '-')}")
                print(f"    收盘价: {latest.get('close', '-')}")
                print(f"    因子值: {latest.get('factor', '-')}")
            
            # 显示统计指标
            if 'stats' in result:
                print(f"\n  统计指标:")
                for code, stat in result['stats'].items():
                    print(f"    {code}:")
                    for key, value in stat.items():
                        print(f"      {key}: {value}")
        else:
            print(f"\n✗ 计算失败: {result.get('message', result.get('error', '未知错误'))}")
        
        # 输出JSON格式（供Agent使用）
        if args.json:
            # 获取摘要给Agent
            summary = task_mgr.get_task_summary_for_agent(task_id)
            print(f"\n{format_output(summary)}")
        
        return task_id
        
    except Exception as e:
        # 标记任务失败
        if 'task_id' in locals():
            task_mgr.fail_task(task_id, str(e))
        print(f"\n✗ 因子计算失败: {e}")
        sys.exit(1)


def cmd_task_run_strategy(args):
    """运行策略回测任务"""
    task_mgr = TaskManager()
    
    try:
        # 创建任务
        params = {
            'code': args.code,
            'strategy': args.strategy,
            'start_date': args.start,
            'end_date': args.end,
            'capital': args.capital
        }
        
        task = task_mgr.create_task(
            task_type='strategy_backtest',
            task_name=f"{args.strategy}_{args.code}",
            input_params=params,
            created_by='cli'
        )
        
        task_id = task['task_id']
        print(f"\n📈 创建策略回测任务: {task_id}")
        print(f"  股票代码: {args.code}")
        print(f"  策略: {args.strategy}")
        print(f"  时间范围: {args.start} 至 {args.end}")
        print(f"  初始资金: {args.capital}")
        
        # 启动任务
        task_mgr.start_task(task_id)
        print(f"\n⏳ 开始回测...")
        
        # 执行回测
        api = BacktestToolAPI()
        start_time = datetime.now()
        
        result = api.run_backtest(
            code=args.code,
            strategy_name=args.strategy,
            start_date=args.start,
            end_date=args.end,
            capital=args.capital
        )
        
        duration_ms = int((datetime.now() - start_time).total_seconds() * 1000)
        
        # 完成任务
        task_mgr.complete_task(
            task_id=task_id,
            result=result,
            result_df=result.get('trades')
        )
        
        print(f"\n✓ 策略回测完成!")
        print(f"  执行时长: {duration_ms}ms")
        
        if result.get('success'):
            # 显示收益指标
            returns = result.get('returns', {})
            print(f"\n  收益指标:")
            print(f"    总收益率: {returns.get('total_return', 0):.2%}")
            print(f"    年化收益: {returns.get('annual_return', 0):.2%}")
            print(f"    最大回撤: {returns.get('max_drawdown', 0):.2%}")
            print(f"    夏普比率: {returns.get('sharpe_ratio', 0):.2f}")
            
            trades = result.get('trades', [])
            print(f"    交易次数: {len(trades)}")
        else:
            print(f"\n✗ 回测失败: {result.get('error')}")
        
        # 输出JSON格式（供Agent使用）
        if args.json:
            summary = task_mgr.get_task_summary_for_agent(task_id)
            print(f"\n{format_output(summary)}")
        
        return task_id
        
    except Exception as e:
        if 'task_id' in locals():
            task_mgr.fail_task(task_id, str(e))
        print(f"\n✗ 策略回测失败: {e}")
        sys.exit(1)


def cmd_task_result(args):
    """获取任务结果详情"""
    task_mgr = TaskManager()
    
    try:
        # 获取完整结果
        result = task_mgr.get_task_result(args.task_id)
        
        if not result:
            print(f"✗ 任务结果不存在: {args.task_id}")
            sys.exit(1)
        
        print(f"\n📊 任务结果详情\n")
        
        # 显示结果元信息
        if 'metadata' in result:
            meta = result['metadata']
            print(f"结果元信息:")
            print(f"  任务ID: {meta.get('task_id')}")
            print(f"  生成时间: {meta.get('generated_at')}")
            print(f"  数据条数: {meta.get('row_count')}")
            print(f"  列数: {meta.get('column_count')}")
            print(f"  列名: {', '.join(meta.get('columns', []))}")
        
        # 显示数据预览
        if 'data' in result:
            data = result['data']
            print(f"\n数据预览 (前{args.limit or 10}条):")
            
            if isinstance(data, list) and data:
                for i, row in enumerate(data[:args.limit or 10]):
                    print(f"  {row}")
                if len(data) > (args.limit or 10):
                    print(f"  ... 还有 {len(data) - (args.limit or 10)} 条")
            elif isinstance(data, pd.DataFrame):
                print(data.head(args.limit or 10).to_string())
        
        # 显示统计信息
        if 'statistics' in result:
            print(f"\n统计信息:")
            for key, value in result['statistics'].items():
                print(f"  {key}: {value}")
        
        print()
        
        # 输出JSON格式（供Agent使用）
        if args.json:
            print(format_output(result))
        
    except Exception as e:
        print(f"✗ 获取任务结果失败: {e}")
        sys.exit(1)


def cmd_task_chain(args):
    """创建任务链"""
    task_mgr = TaskManager()
    
    try:
        # 解析父任务和子任务
        parent_id = args.parent
        child_ids = args.children.split(',') if args.children else []
        
        if not parent_id or not child_ids:
            print("✗ 需要指定父任务和子任务")
            sys.exit(1)
        
        # 建立任务链
        for child_id in child_ids:
            task_mgr.link_tasks(parent_id, child_id.strip())
        
        print(f"\n✓ 任务链创建成功")
        print(f"  父任务: {parent_id}")
        print(f"  子任务: {', '.join(child_ids)}")
        
    except Exception as e:
        print(f"✗ 创建任务链失败: {e}")
        sys.exit(1)


def cmd_task_delete(args):
    """删除任务"""
    task_mgr = TaskManager()
    
    try:
        # 获取任务信息（用于删除结果文件）
        task = task_mgr.get_task(args.task_id)
        
        if not task:
            print(f"✗ 任务不存在: {args.task_id}")
            sys.exit(1)
        
        # 删除结果文件
        if task.get('result_data_path') and os.path.exists(task['result_data_path']):
            os.remove(task['result_data_path'])
            print(f"  删除结果文件: {task['result_data_path']}")
        
        # 从数据库删除
        task_mgr.db_client.execute_update(
            "DELETE FROM calculation_tasks WHERE task_id = ?",
            [args.task_id]
        )
        
        print(f"\n✓ 任务删除成功: {args.task_id}")
        
    except Exception as e:
        print(f"✗ 删除任务失败: {e}")
        sys.exit(1)


def setup_task_parser(subparsers):
    """设置任务管理子命令解析器"""
    task_parser = subparsers.add_parser(
        'task',
        help='任务管理 - 创建、运行、查询计算任务',
        description='管理计算任务，支持Agent驱动的工作流',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
    # 创建任务
    python -m agentquant.cli task create --type factor --name MA5 --params '{"code":"000001.SZ"}'
    
    # 列出任务
    python -m agentquant.cli task list --status completed --limit 20
    
    # 获取任务摘要（给Agent用）
    python -m agentquant.cli task get TASK_ID --summary --json
    
    # 运行因子计算
    python -m agentquant.cli task run-factor --code 000001.SZ --factor MA5 --window 5
    
    # 运行策略回测
    python -m agentquant.cli task run-strategy --code 000001.SZ --strategy CROSS \\
        --start 2024-01-01 --end 2024-06-01 --capital 100000
    
    # 获取结果
    python -m agentquant.cli task result TASK_ID --preview
    
    # 记录Agent决策
    python -m agentquant.cli task decision TASK_ID --decision "继续执行" --next "run_strategy"
        """
    )
    
    task_subparsers = task_parser.add_subparsers(dest='task_command', help='任务子命令')
    
    # task create
    create_parser = task_subparsers.add_parser('create', help='创建新任务')
    create_parser.add_argument('--type', required=True, help='任务类型 (factor_calc, strategy_backtest, etc.)')
    create_parser.add_argument('--name', required=True, help='任务名称')
    create_parser.add_argument('--params', help='任务参数 (JSON格式)')
    create_parser.add_argument('--code', help='股票代码')
    create_parser.add_argument('--start', help='开始日期')
    create_parser.add_argument('--end', help='结束日期')
    create_parser.add_argument('--created-by', default='cli', help='创建者')
    create_parser.add_argument('--json', action='store_true', help='输出JSON格式')
    create_parser.set_defaults(func=cmd_task_create)
    
    # task list
    list_parser = task_subparsers.add_parser('list', help='列出任务')
    list_parser.add_argument('--type', help='按类型筛选')
    list_parser.add_argument('--status', help='按状态筛选 (pending, running, completed, failed)')
    list_parser.add_argument('--limit', type=int, help='限制数量')
    list_parser.add_argument('--json', action='store_true', help='输出JSON格式')
    list_parser.set_defaults(func=cmd_task_list)
    
    # task get
    get_parser = task_subparsers.add_parser('get', help='获取任务详情')
    get_parser.add_argument('task_id', help='任务ID')
    get_parser.add_argument('--summary', action='store_true', help='获取摘要（适合Agent，不含大数据）')
    get_parser.add_argument('--json', action='store_true', help='输出JSON格式')
    get_parser.set_defaults(func=cmd_task_get)
    
    # task run-factor
    run_factor_parser = task_subparsers.add_parser('run-factor', help='运行因子计算')
    run_factor_parser.add_argument('--code', required=True, help='股票代码')
    run_factor_parser.add_argument('--factor', required=True, help='因子名称')
    run_factor_parser.add_argument('--window', type=int, default=5, help='窗口期')
    run_factor_parser.add_argument('--start', help='开始日期')
    run_factor_parser.add_argument('--end', help='结束日期')
    run_factor_parser.add_argument('--json', action='store_true', help='输出JSON格式')
    run_factor_parser.set_defaults(func=cmd_task_run_factor)
    
    # task run-strategy
    run_strategy_parser = task_subparsers.add_parser('run-strategy', help='运行策略回测')
    run_strategy_parser.add_argument('--code', required=True, help='股票代码')
    run_strategy_parser.add_argument('--strategy', required=True, help='策略名称')
    run_strategy_parser.add_argument('--start', required=True, help='开始日期')
    run_strategy_parser.add_argument('--end', required=True, help='结束日期')
    run_strategy_parser.add_argument('--capital', type=float, default=100000, help='初始资金')
    run_strategy_parser.add_argument('--json', action='store_true', help='输出JSON格式')
    run_strategy_parser.set_defaults(func=cmd_task_run_strategy)
    
    # task result
    result_parser = task_subparsers.add_parser('result', help='获取任务结果')
    result_parser.add_argument('task_id', help='任务ID')
    result_parser.add_argument('--limit', type=int, default=10, help='数据条数限制')
    result_parser.add_argument('--json', action='store_true', help='输出JSON格式')
    result_parser.set_defaults(func=cmd_task_result)
    
    # task chain
    chain_parser = task_subparsers.add_parser('chain', help='创建任务链')
    chain_parser.add_argument('--parent', required=True, help='父任务ID')
    chain_parser.add_argument('--children', required=True, help='子任务ID列表（逗号分隔）')
    chain_parser.set_defaults(func=cmd_task_chain)
    
    # task delete
    delete_parser = task_subparsers.add_parser('delete', help='删除任务')
    delete_parser.add_argument('task_id', help='任务ID')
    delete_parser.set_defaults(func=cmd_task_delete)
    
    return task_parser
