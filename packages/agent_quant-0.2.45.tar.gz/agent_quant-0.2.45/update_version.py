#!/usr/bin/env python3
"""Auto increment version in pyproject.toml and __init__.py"""

import re
import sys
import os

script_dir = os.path.dirname(os.path.abspath(__file__))

# 文件路径
pyproject_path = os.path.join(script_dir, 'pyproject.toml')
init_path = os.path.join(script_dir, 'agentquant', '__init__.py')

# 检查文件是否存在
for path in [pyproject_path, init_path]:
    if not os.path.exists(path):
        print(f'Error: File not found at {path}')
        sys.exit(1)

# Read pyproject.toml
with open(pyproject_path, 'r', encoding='utf-8') as f:
    pyproject_content = f.read()

# Find and increment version in pyproject.toml
version_match = re.search(r'version = "(\d+)\.(\d+)\.(\d+)"', pyproject_content)
if version_match:
    major, minor, patch = map(int, version_match.groups())
    new_version = f'{major}.{minor}.{patch + 1}'
    old_version = f'{major}.{minor}.{patch}'
    
    # Update pyproject.toml
    pyproject_content = pyproject_content.replace(
        f'version = "{old_version}"',
        f'version = "{new_version}"'
    )
    with open(pyproject_path, 'w', encoding='utf-8') as f:
        f.write(pyproject_content)
    print(f'pyproject.toml: {old_version} -> {new_version}')
else:
    print('Version not found in pyproject.toml')
    sys.exit(1)

# Update __init__.py
with open(init_path, 'r', encoding='utf-8') as f:
    init_content = f.read()

init_content = re.sub(
    r'__version__ = "[\d.]+"',
    f'__version__ = "{new_version}"',
    init_content
)

with open(init_path, 'w', encoding='utf-8') as f:
    f.write(init_content)
print(f'__init__.py: __version__ = "{new_version}"')

print(f'\nVersion updated successfully: {old_version} -> {new_version}')
