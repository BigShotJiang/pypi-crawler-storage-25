@echo off
echo ============================================
echo  StockClaw Install Script
echo ============================================
echo.

echo [1/3] Checking Python version...
py --version
if errorlevel 1 (
    echo [ERROR] Python not found. Please install Python 3.8+
    pause
    exit /b 1
)
echo.

echo [2/3] Installing dependencies...
py -m pip install --upgrade pip setuptools wheel
py -m pip install pandas requests
if errorlevel 1 (
    echo [ERROR] Failed to install dependencies
    pause
    exit /b 1
)
echo [OK] Dependencies installed
echo.

echo [3/3] Installing agentquant package...
cd /d "%~dp0\.."
py -m pip install -e . --force-reinstall --no-deps
if errorlevel 1 (
    echo [WARNING] Package install warning (may be file lock issue), trying alternative...
    py -m pip uninstall agentquant -y
    py -m pip install -e . --no-deps
)
echo [OK] Package installed
echo.

echo ============================================
echo  Installation Complete!
echo ============================================
echo.
echo Available commands:
echo   python -m agentquant.cli --help
echo   python -m agentquant.cli query --help
echo   python -m agentquant.cli update --help
echo.
pause
