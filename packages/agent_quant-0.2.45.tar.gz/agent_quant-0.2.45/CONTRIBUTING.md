# 贡献指南

感谢您对 ClawQuant 项目的关注！我们欢迎所有形式的贡献，包括但不限于：

- 提交 Bug 报告
- 提交功能建议
- 提交代码改进
- 完善文档

## 如何贡献

### 1. 提交 Issue

如果您发现了 Bug 或者有新功能建议，请通过 GitHub Issues 提交�?

1. 检查是否已有相�?Issue
2. 如果没有，创建新�?Issue
3. 使用对应的模板填写信�?
4. 尽可能详细地描述问题或建�?

### 2. 提交代码

#### 准备工作

1. Fork 本仓库到您的 GitHub 账号
2. 克隆您的 Fork 到本�?

```bash
git clone https://github.com/YOUR_USERNAME/agentquant.git
cd agentquant
```

3. 添加 upstream 远程仓库

```bash
git remote add upstream https://github.com/clawquant/agentquant.git
```

4. 创建虚拟环境并安装依�?

```bash
python -m venv venv

# Windows
venv\Scripts\activate

# Linux/Mac
source venv/bin/activate

# 安装开发依�?
pip install -e ".[dev]"
```

#### 开发流�?

1. 创建新的分支

```bash
git checkout -b feature/your-feature-name
# 或�?
git checkout -b fix/your-bug-fix
```

2. 进行代码修改
3. 确保代码符合规范

```bash
# 代码格式�?
black agentquant/

# 类型检�?
mypy agentquant/

# 代码风格检�?
flake8 agentquant/
```

4. 运行测试

```bash
pytest
```

5. 提交更改

```bash
git add .
git commit -m "feat: 添加新功能描�?
```

提交信息规范�?
- `feat`: 新功�?
- `fix`: 修复 Bug
- `docs`: 文档更新
- `style`: 代码格式调整
- `refactor`: 代码重构
- `test`: 测试相关
- `chore`: 构建过程或辅助工具的变动

6. 推送到您的 Fork

```bash
git push origin feature/your-feature-name
```

7. 创建 Pull Request

- �?GitHub 上创�?PR
- 填写 PR 模板
- 等待代码审查

### 3. 代码规范

#### Python 代码规范

- 遵循 PEP 8 规范
- 使用 Black 进行代码格式化（行长�?100�?
- 添加必要的类型注�?
- 编写清晰的文档字符串

示例�?

```python
def calculate_factor(
    code: str,
    start_date: date,
    end_date: date,
    params: Optional[Dict[str, Any]] = None
) -> pd.DataFrame:
    """
    计算因子�?
    
    Args:
        code: 股票代码，如 "000001.SZ"
        start_date: 开始日�?
        end_date: 结束日期
        params: 因子参数，可�?
        
    Returns:
        包含因子值的 DataFrame
        
    Raises:
        ValueError: 参数无效时抛�?
    """
    pass
```

#### 文档规范

- 使用中文编写文档
- 代码注释使用中文
- API 文档需要包含参数说明和示例

### 4. 测试要求

- 新功能需要包含单元测�?
- 测试覆盖率应保持�?80% 以上
- 所有测试必须通过才能合并

```python
def test_calculate_factor():
    """测试因子计算"""
    result = calculate_factor('000001.SZ', '2024-01-01', '2024-06-01')
    assert not result.empty
    assert 'factor_value' in result.columns
```

## 开发环境设�?

### 推荐 IDE

- VS Code
- PyCharm

### VS Code 推荐插件

- Python
- Black Formatter
- Pylance
- GitLens

### 调试配置

项目已包�?VS Code 调试配置，可以直接使�?F5 启动调试�?

## 发布流程

项目维护者发布新版本流程�?

1. 更新 `CHANGELOG.md`
2. 更新版本�?
3. 创建 Git Tag
4. 推送到 PyPI

```bash
# 构建�?
python -m build

# 上传�?PyPI
python -m twine upload dist/*
```

## 社区准则

- 保持友善和尊�?
- 接受建设性的批评
- 关注对社区最有利的事�?
- 尊重不同的观点和经验

## 获取帮助

如果您在贡献过程中遇到问题：

- 查看 [文档](./docs/)
- �?[GitHub Discussions](https://github.com/clawquant/agentquant/discussions) 提问
- 发送邮件到 clawquant@example.com

## 许可�?

通过贡献代码，您同意您的贡献将在 MIT 许可证下发布�?

再次感谢您的贡献�?
