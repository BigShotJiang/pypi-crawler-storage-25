from __future__ import annotations

import asyncio
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Literal

from textual.app import App, ComposeResult
from textual.containers import Horizontal, Vertical
from textual.message import Message
from textual.screen import ModalScreen
from textual.suggester import Suggester
from textual.widgets import (
    Button,
    DataTable,
    Footer,
    Header,
    Input,
    ProgressBar,
    RichLog,
    Static,
)

from d_oss.__main__ import OSSStorer


VALID_BUCKETS = ("data", "model", "asset", "corpus", "pipeline")


class PathSuggester(Suggester):
    """Suggest local filesystem paths for upload inputs."""

    def __init__(self) -> None:
        super().__init__(use_cache=False, case_sensitive=True)

    async def get_suggestion(self, value: str) -> str | None:
        if not value:
            return None

        raw_value = value
        ends_with_separator = raw_value.endswith("/")
        expanded_path = Path(raw_value).expanduser()

        if ends_with_separator:
            search_dir = expanded_path
            partial_name = ""
            display_prefix = raw_value
        else:
            search_dir = expanded_path.parent
            partial_name = expanded_path.name
            display_prefix = raw_value[: len(raw_value) - len(partial_name)]

        if not search_dir.exists() or not search_dir.is_dir():
            return None

        try:
            candidates = sorted(search_dir.iterdir(), key=lambda path: path.name.lower())
        except OSError:
            return None

        for candidate in candidates:
            if not candidate.name.startswith(partial_name):
                continue
            suffix = "/" if candidate.is_dir() else ""
            return f"{display_prefix}{candidate.name}{suffix}"

        return None


class FileTable(DataTable):
    """DataTable that remembers mouse modifier keys for row selection."""

    last_click_shift = False
    last_click_toggle = False

    class RowClicked(Message):
        def __init__(self, row_index: int, shift: bool, toggle: bool) -> None:
            self.row_index = row_index
            self.shift = shift
            self.toggle = toggle
            super().__init__()

    async def _on_click(self, event) -> None:
        meta = event.style.meta
        if "row" not in meta or "column" not in meta:
            await super()._on_click(event)
            return
        if self.cursor_type != "row" and meta.get("out_of_bounds", False):
            await super()._on_click(event)
            return

        row_index = meta["row"]
        column_index = meta["column"]
        is_header_click = self.show_header and row_index == -1
        is_row_label_click = self.show_row_labels and column_index == -1
        if is_header_click or is_row_label_click:
            await super()._on_click(event)
            return

        self.last_click_shift = event.shift
        self.last_click_toggle = event.ctrl or event.meta
        self.move_cursor(row=row_index, animate=False)
        self.post_message(
            self.RowClicked(row_index, self.last_click_shift, self.last_click_toggle)
        )
        if hasattr(event, "stop"):
            event.stop()


class APIInfoScreen(ModalScreen[None]):
    """Show cached OSS credentials in full."""

    CSS = """
    #api-info-panel {
        width: 70;
        max-width: 90%;
        padding: 1 2;
        background: $surface;
        border: tall $primary;
    }

    #api-info-title {
        text-style: bold;
        margin-bottom: 1;
    }

    #api-info-values {
        margin-bottom: 1;
    }

    #api-info-close {
        width: 100%;
    }
    """

    def __init__(
        self,
        access_key_id: str | None,
        access_key_secret: str | None,
        message: str | None = None,
    ) -> None:
        self.access_key_id = access_key_id
        self.access_key_secret = access_key_secret
        self.message = message
        super().__init__()

    def compose(self) -> ComposeResult:
        with Vertical(id="api-info-panel"):
            yield Static("Credentials", id="api-info-title")
            if self.message is not None:
                yield Static(self.message, id="api-info-values")
            else:
                yield Static(
                    f"access_key_id: {self.access_key_id}\n"
                    f"access_key_secret: {self.access_key_secret}",
                    id="api-info-values",
                )
            yield Button("Close", id="api-info-close")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "api-info-close":
            self.dismiss()


@dataclass(frozen=True)
class BrowserEntry:
    name: str
    key: str
    kind: Literal["file", "folder"]
    size: int | None = None
    last_modified: int | None = None


def build_directory_entries(objects: list[Any], prefix: str) -> list[BrowserEntry]:
    folders: dict[str, BrowserEntry] = {}
    files: list[BrowserEntry] = []

    for obj in objects:
        key = obj.key
        if not key.startswith(prefix) or key == prefix:
            continue

        remainder = key[len(prefix) :]
        if not remainder:
            continue

        first_segment, separator, _rest = remainder.partition("/")
        if separator:
            folder_key = f"{prefix}{first_segment}/"
            folders[first_segment] = BrowserEntry(
                name=first_segment,
                key=folder_key,
                kind="folder",
            )
        else:
            files.append(
                BrowserEntry(
                    name=first_segment,
                    key=key,
                    kind="file",
                    size=getattr(obj, "size", None),
                    last_modified=getattr(obj, "last_modified", None),
                )
            )

    return sorted(folders.values(), key=lambda entry: entry.name) + sorted(
        files, key=lambda entry: entry.name
    )


class DOSSApp(App):
    CSS = """
    Screen {
        layout: vertical;
    }

    #body {
        height: 1fr;
    }

    #sidebar {
        width: 22;
        padding: 1;
        background: $surface;
    }

    #main {
        width: 1fr;
        padding: 1;
    }

    .sidebar-title {
        margin-bottom: 1;
    }

    .bucket-button {
        width: 100%;
        margin-bottom: 1;
    }

    #api-info {
        width: 100%;
        margin-top: 1;
    }

    #path-label {
        height: 1;
        margin-bottom: 1;
    }

    #file-table {
        height: 1fr;
        margin-bottom: 1;
    }

    #actions {
        height: auto;
        margin-bottom: 1;
    }

    #actions Button {
        margin-right: 1;
    }

    #inputs {
        height: auto;
        margin-bottom: 1;
    }

    #inputs Input {
        margin-bottom: 1;
    }

    #log {
        height: 8;
        border: solid $primary;
        padding: 1;
    }

    #help-text {
        height: 1;
        color: $text-muted;
    }

    #progress-label {
        height: 1;
    }
    """

    BINDINGS = [
        ("ctrl+c", "quit", "Quit"),
        ("r", "refresh", "Refresh"),
        ("backspace", "back", "Back"),
    ]

    def __init__(self, storer: OSSStorer | None = None) -> None:
        super().__init__()
        self.storer = storer or OSSStorer()
        self.current_bucket: str | None = None
        self.current_prefix = ""
        self.entries: list[BrowserEntry] = []
        self.selected_entry: BrowserEntry | None = None
        self.selected_keys: set[str] = set()
        self.last_clicked_row: int | None = None
        self.pending_delete_signature: tuple[str, ...] | None = None
        self.upload_total = 0

    def compose(self) -> ComposeResult:
        yield Header(show_clock=True)
        yield Static(
            "Exit: Ctrl+C | Refresh: r | Back: Backspace | Click rows to select | Shift+Click range if supported",
            id="help-text",
        )
        with Horizontal(id="body"):
            with Vertical(id="sidebar"):
                yield Static("Buckets", classes="sidebar-title")
                for bucket in VALID_BUCKETS:
                    yield Button(bucket, id=f"bucket-{bucket}", classes="bucket-button")
                yield Button("Credentials", id="api-info")
            with Vertical(id="main"):
                yield Static("Select a bucket", id="path-label")
                table = FileTable(id="file-table", cursor_type="row")
                table.add_columns("Name", "Type", "Size", "Modified")
                yield table
                with Horizontal(id="actions"):
                    yield Button("Back", id="back")
                    yield Button("Open", id="open")
                    yield Button("Refresh", id="refresh")
                    yield Button("Upload File", id="upload-file")
                    yield Button("Upload Folder", id="upload-folder")
                    yield Button("Download", id="download")
                    yield Button("Rename", id="rename")
                    yield Button("Delete", id="delete")
                    yield Button("Copy URL", id="copy-url")
                with Vertical(id="inputs"):
                    yield Input(
                        value="./",
                        placeholder="Download save directory or upload local path",
                        suggester=PathSuggester(),
                        id="path-input",
                    )
                    yield Input(
                        placeholder="New file or folder name for rename",
                        id="rename-input",
                    )
                yield Static("Upload progress: idle", id="progress-label")
                yield ProgressBar(total=100, id="upload-progress")
                yield RichLog(id="log", wrap=True, highlight=True, markup=True)
        yield Footer()

    def on_mount(self) -> None:
        self.title = "d-oss"
        self._show_auth_hint()
        self._log("Select a bucket to load files.")

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        button_id = event.button.id or ""
        if button_id.startswith("bucket-"):
            await self.select_bucket(button_id.removeprefix("bucket-"))
        elif button_id == "back":
            await self.go_back()
        elif button_id == "open":
            await self.open_selected_folder()
        elif button_id == "refresh":
            await self.refresh_entries()
        elif button_id == "upload-file":
            await self.upload_selected_path(is_folder=False)
        elif button_id == "upload-folder":
            await self.upload_selected_path(is_folder=True)
        elif button_id == "download":
            await self.download_selected()
        elif button_id == "rename":
            await self.rename_selected()
        elif button_id == "delete":
            await self.delete_selected()
        elif button_id == "copy-url":
            self.copy_selected_url()
        elif button_id == "api-info":
            self.show_api_info()

    async def on_file_table_row_clicked(self, event: FileTable.RowClicked) -> None:
        self.handle_row_click(
            event.row_index,
            shift=event.shift,
            toggle=event.toggle,
        )
        table = self.query_one("#file-table", FileTable)
        table.last_click_shift = False
        table.last_click_toggle = False

    def on_data_table_row_highlighted(self, event: DataTable.RowHighlighted) -> None:
        if event.cursor_row is None or event.cursor_row >= len(self.entries):
            return
        self.selected_entry = self.entries[event.cursor_row]
        self.pending_delete_signature = None

    async def select_bucket(self, bucket: str) -> None:
        self.current_bucket = bucket
        self.current_prefix = ""
        self.selected_entry = None
        self.selected_keys = set()
        self.last_clicked_row = None
        self.pending_delete_signature = None
        await self.refresh_entries()

    async def refresh_entries(self) -> None:
        if not self.current_bucket:
            self._log("Select a bucket first.")
            return
        try:
            objects = await asyncio.to_thread(
                self.storer.list_objects, self.current_bucket, self.current_prefix
            )
        except AttributeError:
            objects = []
        except Exception as exc:
            self._log(f"[red]Failed to list objects:[/red] {exc}")
            return
        self.entries = build_directory_entries(objects, self.current_prefix)
        self.selected_entry = None
        self.last_clicked_row = None
        self.selected_keys = {
            key for key in self.selected_keys if any(entry.key == key for entry in self.entries)
        }
        self.pending_delete_signature = None
        self.render_entries()

    async def open_folder(self, entry: BrowserEntry) -> None:
        self.current_prefix = entry.key
        self.selected_entry = None
        await self.refresh_entries()

    async def open_selected_folder(self) -> None:
        if not self._require_selection():
            return
        assert self.selected_entry is not None
        if self.selected_entry.kind != "folder":
            self._log("Selected entry is not a folder.")
            return
        await self.open_folder(self.selected_entry)

    async def go_back(self) -> None:
        if not self.current_prefix:
            return
        parts = self.current_prefix.rstrip("/").split("/")
        parent = "/".join(parts[:-1])
        self.current_prefix = f"{parent}/" if parent else ""
        await self.refresh_entries()

    async def upload_selected_path(self, is_folder: bool) -> None:
        if not self.current_bucket:
            self._log("Select a bucket first.")
            return
        local_path = Path(self.query_one("#path-input", Input).value).expanduser()
        destination_prefix = f"{self.current_prefix}{local_path.name}"
        try:
            self._start_upload_progress(local_path, is_folder)
            if is_folder:
                await asyncio.to_thread(
                    self.storer.upload_folder_to_prefix,
                    local_path,
                    self.current_bucket,
                    f"{destination_prefix}/",
                    False,
                    self._upload_progress_callback,
                )
                self._log(f"Uploaded folder {local_path} to {destination_prefix}/")
            else:
                await asyncio.to_thread(
                    self.storer.upload_file_to_key,
                    local_path,
                    self.current_bucket,
                    destination_prefix,
                    False,
                    self._upload_progress_callback,
                )
                self._log(f"Uploaded file {local_path} to {destination_prefix}")
        except Exception as exc:
            self._log(f"[red]Upload failed:[/red] {exc}")
            return
        self._finish_upload_progress()
        await self.refresh_entries()

    async def download_selected(self) -> None:
        if not self._require_selection():
            return
        save_dir = self.query_one("#path-input", Input).value or "./"
        assert self.current_bucket is not None
        targets = self._download_targets()
        try:
            for entry in targets:
                await asyncio.to_thread(
                    self.storer.download,
                    entry.key,
                    self.current_bucket,
                    save_dir,
                    False,
                )
        except Exception as exc:
            self._log(f"[red]Download failed:[/red] {exc}")
        else:
            self._log(f"Downloaded {len(targets)} item(s) to {save_dir}")

    async def rename_selected(self) -> None:
        if not self._require_selection():
            return
        assert self.current_bucket is not None
        assert self.selected_entry is not None
        new_name = self.query_one("#rename-input", Input).value.strip()
        if not new_name:
            self._log("Enter a new name before renaming.")
            return
        new_key = self._destination_key(new_name, self.selected_entry.kind)
        try:
            if self.selected_entry.kind == "folder":
                await asyncio.to_thread(
                    self.storer.rename_folder,
                    self.current_bucket,
                    self.selected_entry.key,
                    new_key,
                )
            else:
                await asyncio.to_thread(
                    self.storer.rename_file,
                    self.current_bucket,
                    self.selected_entry.key,
                    new_key,
                )
        except Exception as exc:
            self._log(f"[red]Rename failed:[/red] {exc}")
            return
        self._log(f"Renamed {self.selected_entry.key} to {new_key}")
        self.query_one("#rename-input", Input).value = ""
        await self.refresh_entries()

    async def delete_selected(self) -> None:
        if not self._require_selection():
            return
        assert self.current_bucket is not None
        targets = self._delete_targets()
        if not targets:
            self._log("Select a file or folder first.")
            return
        signature = tuple(entry.key for entry in targets)
        if self.pending_delete_signature != signature:
            self.pending_delete_signature = signature
            self._log(
                f"Press Delete again to confirm deleting {len(targets)} item(s)."
            )
            return
        try:
            for entry in targets:
                await asyncio.to_thread(
                    self.storer.delete,
                    entry.key,
                    self.current_bucket,
                )
        except Exception as exc:
            self._log(f"[red]Delete failed:[/red] {exc}")
            return
        self._log(f"Deleted {len(targets)} item(s)")
        self.selected_keys.clear()
        self.selected_entry = None
        self.pending_delete_signature = None
        await self.refresh_entries()

    def copy_selected_url(self) -> None:
        if not self._require_selection():
            return
        assert self.current_bucket is not None
        assert self.selected_entry is not None
        if self.selected_entry.kind == "folder":
            self._log("Folders do not have a single URL.")
            return
        endpoint = (
            "oss-cn-hangzhou.aliyuncs.com"
            if self.current_bucket == "corpus"
            else "oss-cn-beijing.aliyuncs.com"
        )
        bucket_name = self.storer.bucket_names[self.current_bucket]
        url = f"https://{bucket_name}.{endpoint}/{self.selected_entry.key}"
        self._log(url)

    def show_api_info(self) -> None:
        access_key_id = getattr(self.storer, "access_key_id", None)
        access_key_secret = getattr(self.storer, "access_key_secret", None)
        if not access_key_id or not access_key_secret:
            self.push_screen(
                APIInfoScreen(
                    access_key_id,
                    access_key_secret,
                    "No cached API credentials found.",
                )
            )
            return
        self.push_screen(APIInfoScreen(access_key_id, access_key_secret))

    def render_entries(self) -> None:
        table = self.query_one("#file-table", DataTable)
        cursor_row = table.cursor_row
        table.clear()
        for entry in self.entries:
            marker = "✅ " if entry.key in self.selected_keys else ""
            table.add_row(
                f"{marker}{entry.name}",
                entry.kind,
                self._format_size(entry.size),
                self._format_modified(entry.last_modified),
            )
        location = f"{self.current_bucket or '-'}:/{self.current_prefix}"
        self.query_one("#path-label", Static).update(location)
        if not self.entries:
            self._log(f"No files under {location}")
        elif cursor_row is not None:
            table.move_cursor(row=min(cursor_row, len(self.entries) - 1), animate=False)

    def _destination_key(self, new_name: str, kind: Literal["file", "folder"]) -> str:
        if "/" in new_name:
            key = new_name
        else:
            key = f"{self.current_prefix}{new_name}"
        if kind == "folder" and not key.endswith("/"):
            key = f"{key}/"
        return key

    def _require_selection(self) -> bool:
        if self.selected_entry is None:
            self._log("Select a file or folder first.")
            return False
        return True

    def handle_row_click(self, row_index: int, shift: bool, toggle: bool) -> None:
        if row_index is None or row_index >= len(self.entries):
            return
        entry = self.entries[row_index]
        self.selected_entry = entry
        self.pending_delete_signature = None

        if shift and self.last_clicked_row is not None:
            start, end = sorted((self.last_clicked_row, row_index))
            self.selected_keys.update(item.key for item in self.entries[start : end + 1])
            self._log(f"Selected {end - start + 1} item(s).")
        elif toggle:
            if entry.key in self.selected_keys:
                self.selected_keys.remove(entry.key)
                self._log(f"Removed from selection: {entry.key}")
            else:
                self.selected_keys.add(entry.key)
                self._log(f"Added to selection: {entry.key}")
        else:
            if entry.key in self.selected_keys:
                self.selected_keys.remove(entry.key)
                self._log(f"Removed from selection: {entry.key}")
            else:
                self.selected_keys.add(entry.key)
                self._log(f"Added to selection: {entry.key}")

        self.last_clicked_row = row_index
        self.render_entries()

    def _download_targets(self) -> list[BrowserEntry]:
        if self.selected_keys:
            return [entry for entry in self.entries if entry.key in self.selected_keys]
        assert self.selected_entry is not None
        return [self.selected_entry]

    def _delete_targets(self) -> list[BrowserEntry]:
        return self._download_targets()

    def _log(self, message: str) -> None:
        self.query_one("#log", RichLog).write(message)

    def _show_auth_hint(self) -> None:
        auth_file = getattr(self.storer, "auth_file", None)
        if auth_file is not None and not Path(auth_file).exists():
            self._log(
                "[yellow]API key is not cached yet. On first startup, enter "
                "access_key_id and access_key_secret when prompted.[/yellow]"
            )

    def _start_upload_progress(self, local_path: Path, is_folder: bool) -> None:
        if is_folder and local_path.is_dir():
            self.upload_total = sum(
                path.stat().st_size for path in local_path.rglob("*") if path.is_file()
            )
        elif local_path.is_file():
            self.upload_total = local_path.stat().st_size
        else:
            self.upload_total = 0
        progress = self.query_one("#upload-progress", ProgressBar)
        progress.update(total=max(self.upload_total, 1), progress=0)
        self.query_one("#progress-label", Static).update("Upload progress: 0%")

    def _upload_progress_callback(self, consumed_bytes, total_bytes) -> None:
        total = total_bytes or self.upload_total or 1
        consumed = min(consumed_bytes, total)
        self.call_from_thread(self._update_upload_progress, consumed, total)

    def _update_upload_progress(self, consumed_bytes: int, total_bytes: int) -> None:
        progress = self.query_one("#upload-progress", ProgressBar)
        progress.update(total=max(total_bytes, 1), progress=consumed_bytes)
        percent = int((consumed_bytes / max(total_bytes, 1)) * 100)
        self.query_one("#progress-label", Static).update(
            f"Upload progress: {percent}% "
            f"({self._format_size(consumed_bytes)} / {self._format_size(total_bytes)})"
        )

    def _finish_upload_progress(self) -> None:
        total = max(self.upload_total, 1)
        self.query_one("#upload-progress", ProgressBar).update(
            total=total,
            progress=total,
        )
        self.query_one("#progress-label", Static).update("Upload progress: complete")

    @staticmethod
    def _format_size(size: int | None) -> str:
        if size is None:
            return "-"
        if size >= 1024 * 1024:
            return f"{size / 1024 / 1024:.2f} MB"
        if size >= 1024:
            return f"{size / 1024:.2f} KB"
        return f"{size} B"

    @staticmethod
    def _format_modified(last_modified: int | None) -> str:
        if not last_modified:
            return "-"
        return datetime.fromtimestamp(last_modified).strftime("%Y-%m-%d %H:%M:%S")

    def action_refresh(self) -> None:
        self.run_worker(self.refresh_entries())

    def action_back(self) -> None:
        self.run_worker(self.go_back())
