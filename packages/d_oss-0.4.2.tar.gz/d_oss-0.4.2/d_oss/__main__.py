from typing import Literal, Optional
import os
from pathlib import Path
from datetime import datetime

import oss2
from oss2 import Bucket
from rich.console import Console
from rich.table import Table
from rich.progress import (
    Progress,
    TextColumn,
    BarColumn,
    TimeElapsedColumn,
    TimeRemainingColumn,
    TransferSpeedColumn,
)
import srsly

console = Console()


def get_dir_info(dir_path):
    """获取目录的总大小和文件数"""
    total_size = 0
    file_count = 0
    try:
        for root, dirs, files in os.walk(dir_path):
            for file in files:
                file_path = os.path.join(root, file)
                try:
                    total_size += os.path.getsize(file_path)
                    file_count += 1
                except (OSError, IOError):
                    # 跳过无法访问的文件
                    pass
    except (OSError, IOError):
        pass
    return total_size, file_count


def save_auth(auth_file: Path, access_key_id: str, access_key_secret: str):
    if not auth_file.exists():
        auth_file.parent.mkdir(parents=True, exist_ok=True)
    srsly.write_json(
        auth_file,
        {"access_key_id": access_key_id, "access_key_secret": access_key_secret},
    )


def load_auth(auth_file: Path):
    if not auth_file.exists():
        access_key_id = None
        access_key_secret = None
    else:
        auth = srsly.read_json(auth_file)
        access_key_id = auth.get("access_key_id", None)
        access_key_secret = auth.get("access_key_secret", None)
    if access_key_id is None or access_key_secret is None:
        access_key_id = console.input("access_key_id: ")
        if access_key_id == "":
            raise ValueError("access_key_id cannot be empty")
        access_key_secret = console.input("access_key_secret: ")
        if access_key_secret == "":
            raise ValueError("access_key_secret cannot be empty")
        save_auth(auth_file, access_key_id, access_key_secret)
    return access_key_id, access_key_secret


class OSSStorer:
    """阿里云oss对象存储"""

    def __init__(
        self,
        access_key_id: str | None = None,
        access_key_secret: str | None = None,
        cache_dir: str | Path = Path().home() / ".cache" / "d-oss",
    ):
        super().__init__()
        self.auth_file = Path(cache_dir) / "auth.json"
        access_key_id, access_key_secret = load_auth(self.auth_file)
        self.access_key_id = access_key_id
        self.access_key_secret = access_key_secret
        self.auth = oss2.Auth(access_key_id, access_key_secret)
        beijing_endpoint: str = "http://oss-cn-beijing.aliyuncs.com"
        hangzhou_endpoint: str = "http://oss-cn-hangzhou.aliyuncs.com"
        data_bucket: str = "deepset"
        model_bucket: str = "pretrained-model"
        asset_bucket: str = "deepasset"
        corpus_bucket: str = "deepcorpus"
        pipe_bucket: str = "spacy-pipeline"
        self.data_bucket = oss2.Bucket(
            self.auth, beijing_endpoint, bucket_name=data_bucket
        )
        self.model_bucket = oss2.Bucket(
            self.auth, beijing_endpoint, bucket_name=model_bucket
        )
        self.assets_bucket = oss2.Bucket(
            self.auth, beijing_endpoint, bucket_name=asset_bucket
        )
        self.corpus_bucket = oss2.Bucket(
            self.auth, hangzhou_endpoint, bucket_name=corpus_bucket
        )
        self.pipe_bucket = oss2.Bucket(
            self.auth, beijing_endpoint, bucket_name=pipe_bucket
        )

        self.buckets = {
            "data": self.data_bucket,
            "model": self.model_bucket,
            "asset": self.assets_bucket,
            "corpus": self.corpus_bucket,
            "pipeline": self.pipe_bucket,
        }

        # bucket名称映射，用于URL生成
        self.bucket_names = {
            "data": data_bucket,
            "model": model_bucket,
            "asset": asset_bucket,
            "corpus": corpus_bucket,
            "pipeline": pipe_bucket,
        }

        self.cache_dir = cache_dir

    def list(
        self,
        bucket: Optional[
            Literal["data", "model", "asset", "corpus", "pipeline"]
        ] = None,
    ) -> None:
        """获取bucket下的所有文件

        Args:
            bucket: 要列出的bucket名称，如果不指定则显示所有bucket的内容
        """
        # 验证bucket参数
        valid_buckets = ["data", "model", "asset", "corpus", "pipeline"]
        if bucket is not None and bucket not in valid_buckets:
            console.print(
                f"[bold red]错误：无效的bucket名称 '{bucket}'，有效选项：{', '.join(valid_buckets)}[/bold red]"
            )
            return

        if bucket is None:
            # 显示所有bucket的内容
            bucket_names = list(self.buckets.keys())

            for bucket_name in bucket_names:
                bucket_obj = self.buckets[bucket_name]

                # 获取bucket中的文件列表
                objects = list(oss2.ObjectIterator(bucket_obj))
                file_count = len(objects)

                # 显示bucket标题和文件数量
                console.print(
                    f"\n[bold cyan]📁 Bucket: {bucket_name} ({file_count} files)[/bold cyan]"
                )

                if file_count == 0:
                    console.print("  [dim](empty)[/dim]")
                    continue

                # 创建表格显示文件
                table = Table(show_header=True, header_style="bold blue")
                table.add_column("File Name", style="cyan", width=50)
                table.add_column("Size", style="green", justify="right", width=12)
                table.add_column(
                    "Last Modified", style="yellow", justify="center", width=20
                )

                for obj in objects:
                    # 格式化文件大小
                    size_mb = obj.size / 1024 / 1024 if obj.size else 0
                    size_str = (
                        f"{size_mb:.2f} MB"
                        if obj.size >= 1024 * 1024
                        else f"{obj.size or 0} B"
                    )

                    # 格式化时间
                    last_modified = (
                        datetime.fromtimestamp(obj.last_modified).strftime(
                            "%Y-%m-%d %H:%M:%S"
                        )
                        if hasattr(obj, "last_modified") and obj.last_modified
                        else "Unknown"
                    )

                    table.add_row(obj.key, size_str, last_modified)

                console.print(table)

            console.print(
                f"\n[bold green]✅ Listed contents of {len(bucket_names)} buckets[/bold green]"
            )

        else:
            # 显示单个bucket的内容
            bucket_obj = self.buckets.get(bucket)

            # 获取bucket中的文件列表
            objects = list(oss2.ObjectIterator(bucket_obj))
            file_count = len(objects)

            console.print(
                f"[bold cyan]📁 Bucket: {bucket} ({file_count} files)[/bold cyan]"
            )

            if file_count == 0:
                console.print("  [dim](empty)[/dim]")
                return

            # 创建表格显示文件
            table = Table(show_header=True, header_style="bold blue")
            table.add_column("File Name", style="cyan", width=50)
            table.add_column("Size", style="green", justify="right", width=12)
            table.add_column(
                "Last Modified", style="yellow", justify="center", width=20
            )

            for obj in objects:
                # 格式化文件大小
                size_mb = obj.size / 1024 / 1024 if obj.size else 0
                size_str = (
                    f"{size_mb:.2f} MB"
                    if obj.size >= 1024 * 1024
                    else f"{obj.size or 0} B"
                )

                # 格式化时间
                last_modified = (
                    datetime.fromtimestamp(obj.last_modified).strftime(
                        "%Y-%m-%d %H:%M:%S"
                    )
                    if hasattr(obj, "last_modified") and obj.last_modified
                    else "Unknown"
                )

                table.add_row(obj.key, size_str, last_modified)

            console.print(table)

    def url(
        self, file: str, bucket: Literal["data", "model", "asset", "corpus", "pipeline"]
    ):
        """获取文件的URL

        Args:
            file: 文件名
            bucket: bucket名称
        """
        # 验证bucket参数
        valid_buckets = ["data", "model", "asset", "corpus", "pipeline"]
        if bucket not in valid_buckets:
            console.print(
                f"[bold red]错误：无效的bucket名称 '{bucket}'，有效选项：{', '.join(valid_buckets)}[/bold red]"
            )
            return

        bucket_obj = self.buckets[bucket]

        # 检查文件是否存在
        if not bucket_obj.object_exists(file):
            console.print(
                f"[bold red]错误：文件 '{file}' 在bucket '{bucket}' 中不存在[/bold red]"
            )
            return

        # 生成文件URL
        # corpus bucket使用杭州endpoint，其他使用北京endpoint
        endpoint = (
            "oss-cn-hangzhou.aliyuncs.com"
            if bucket == "corpus"
            else "oss-cn-beijing.aliyuncs.com"
        )
        actual_bucket_name = self.bucket_names[bucket]
        file_url = f"https://{actual_bucket_name}.{endpoint}/{file}"

        # 只输出URL，不添加额外信息
        console.print(file_url)

    def _upload_file(
        self,
        file_path: Path,
        bucket_obj: oss2.Bucket,
        parent_key: str = "",
        progress=None,
        task_id=None,
        uploaded_count: int = 0,
        total_count: int = 0,
        total_size: int = 0,
        uploaded_size: int = 0,
    ) -> tuple[int, int]:
        """递归上传文件或目录内容到OSS，保持目录结构

        Returns:
            (上传成功文件数, 上传失败文件数)
        """
        success_count = 0
        fail_count = 0

        for f in os.listdir(file_path):
            abs_path = file_path / f
            # 构建OSS上的key，保留目录结构
            if parent_key:
                key = f"{parent_key}/{f}"
            else:
                key = f

            if abs_path.is_dir():
                # 递归处理子目录
                s, f = self._upload_file(
                    abs_path,
                    bucket_obj,
                    parent_key=key,
                    progress=progress,
                    task_id=task_id,
                    uploaded_count=uploaded_count,
                    total_count=total_count,
                    total_size=total_size,
                    uploaded_size=uploaded_size,
                )
                success_count += s
                fail_count += f
            else:
                # 上传单个文件
                try:
                    file_size = abs_path.stat().st_size

                    def upload_progress(consumed_bytes, total_bytes):
                        nonlocal uploaded_size
                        uploaded_size += consumed_bytes
                        if progress and task_id is not None:
                            progress.update(
                                task_id,
                                completed=uploaded_size,
                                size_info=f"{uploaded_count}/{total_count} files • {uploaded_size / 1024 / 1024:.1f}/{total_size / 1024 / 1024:.1f} MB",
                            )

                    bucket_obj.put_object_from_file(
                        key=key,
                        filename=str(abs_path),
                        progress_callback=upload_progress,
                    )
                    uploaded_count += 1
                    success_count += 1

                    if progress and task_id is not None and total_count > 0:
                        progress.update(
                            task_id,
                            uploaded_files=uploaded_count,
                            size_info=f"{uploaded_count}/{total_count} files • {uploaded_size / 1024 / 1024:.1f}/{total_size / 1024 / 1024:.1f} MB",
                        )

                except Exception as e:
                    fail_count += 1
                    console.print(f"[red]❌ Failed to upload {key}: {e}[/red]")

        return success_count, fail_count

    def upload(
        self, file: str, bucket: Literal["data", "model", "asset", "corpus", "pipeline"]
    ):
        """上传文件或者目录到bucket
        - file: 要上传的文件路径
        - bucket: 要上传到的bucket
        """
        file_path: Path = Path(file)
        if not file_path.exists():
            console.print(f"[bold red] file {file} not exists!")
            return
        bucket_obj: oss2.Bucket = self.buckets.get(bucket)

        if file_path.is_dir():
            # 目录上传：直接上传每个文件，保持目录结构
            total_size, file_count = get_dir_info(file_path)

            with Progress(
                TextColumn("[bold blue]{task.description}", justify="left"),
                BarColumn(bar_width=30),
                TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
                TextColumn("[bold green]{task.fields[size_info]}", justify="left"),
                TransferSpeedColumn(),
                TextColumn("[cyan]已用时:"),
                TimeElapsedColumn(),
                TextColumn("[yellow]剩余:"),
                TimeRemainingColumn(),
                console=console,
            ) as progress:
                task_id = progress.add_task(
                    f"☁️  uploading {file_path.name}",
                    size_info=f"0/{file_count} files • 0.0/{total_size / 1024 / 1024:.1f} MB",
                    total=total_size,
                )

                success_count, fail_count = self._upload_file(
                    file_path,
                    bucket_obj,
                    parent_key=file_path.name,
                    progress=progress,
                    task_id=task_id,
                    total_count=file_count,
                    total_size=total_size,
                )

            if fail_count == 0:
                console.print(
                    f"[bold green]✅ upload {file_path} to {bucket} succeed ({success_count} files)[/bold green]"
                )
            else:
                console.print(
                    f"[bold yellow]⚠️  uploaded {success_count} files, {fail_count} failed[/bold yellow]"
                )
        else:
            # 单个文件上传
            file_size = os.path.getsize(file_path)
            with Progress(
                TextColumn("[bold blue]{task.description}", justify="left"),
                BarColumn(bar_width=30),
                TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
                TransferSpeedColumn(),
                TextColumn("[cyan]已用时:"),
                TimeElapsedColumn(),
                TextColumn("[yellow]剩余:"),
                TimeRemainingColumn(),
                console=console,
            ) as progress:
                task = progress.add_task(
                    f"☁️  uploading {file_path.name}", total=file_size
                )

                def upload_progress(consumed_bytes, total_bytes):
                    progress.update(task, completed=consumed_bytes, total=total_bytes)

                upload_success = False
                try:
                    bucket_obj.put_object_from_file(
                        key=file_path.name,
                        filename=file_path,
                        progress_callback=upload_progress,
                    )
                    upload_success = True
                except Exception as e:
                    console.print(
                        f"[bold red]❌ upload {file_path} to {bucket} failed with error: {e}"
                    )
                except KeyboardInterrupt:
                    console.print("[yellow]⚠️  upload cancelled by user")

            if upload_success:
                console.print(f"[bold green]✅ upload {file_path} to {bucket} succeed")

    def _list_prefix(self, bucket_obj, prefix: str) -> list:
        """列出指定前缀下的所有对象"""
        objects = list(oss2.ObjectIterator(bucket_obj, prefix=prefix))
        return objects

    def list_objects(
        self,
        bucket: Literal["data", "model", "asset", "corpus", "pipeline"],
        prefix: str = "",
    ) -> list:
        """List objects in a bucket with an optional prefix."""
        return self._list_prefix(self.buckets[bucket], prefix)

    def object_exists(
        self,
        bucket: Literal["data", "model", "asset", "corpus", "pipeline"],
        key: str,
    ) -> bool:
        """Return whether an object key exists in a bucket."""
        return self.buckets[bucket].object_exists(key)

    def upload_file_to_key(
        self,
        local_path: str | Path,
        bucket: Literal["data", "model", "asset", "corpus", "pipeline"],
        key: str,
        overwrite: bool = False,
        progress_callback=None,
    ) -> None:
        """Upload one local file to an explicit OSS key."""
        local_path = Path(local_path)
        if not local_path.is_file():
            raise FileNotFoundError(f"local file does not exist: {local_path}")
        if not overwrite and self.object_exists(bucket, key):
            raise FileExistsError(f"destination already exists: {key}")
        self.buckets[bucket].put_object_from_file(
            key=key,
            filename=str(local_path),
            progress_callback=progress_callback,
        )

    def upload_folder_to_prefix(
        self,
        local_path: str | Path,
        bucket: Literal["data", "model", "asset", "corpus", "pipeline"],
        prefix: str,
        overwrite: bool = False,
        progress_callback=None,
    ) -> None:
        """Upload a local folder under an explicit OSS prefix."""
        local_path = Path(local_path)
        if not local_path.is_dir():
            raise FileNotFoundError(f"local folder does not exist: {local_path}")
        normalized_prefix = prefix if prefix.endswith("/") else f"{prefix}/"
        files = [path for path in local_path.rglob("*") if path.is_file()]
        planned_uploads = [
            (
                file_path,
                f"{normalized_prefix}{file_path.relative_to(local_path).as_posix()}",
            )
            for file_path in files
        ]
        conflicts = [
            key
            for _file_path, key in planned_uploads
            if not overwrite and self.object_exists(bucket, key)
        ]
        if conflicts:
            raise FileExistsError(f"destination already exists: {conflicts[0]}")
        uploaded_base = 0
        for file_path, key in planned_uploads:
            file_size = file_path.stat().st_size

            def file_progress(consumed_bytes, total_bytes):
                if progress_callback is not None:
                    progress_callback(uploaded_base + consumed_bytes, None)

            self.buckets[bucket].put_object_from_file(
                key=key,
                filename=str(file_path),
                progress_callback=file_progress,
            )
            uploaded_base += file_size

    def rename_file(
        self,
        bucket: Literal["data", "model", "asset", "corpus", "pipeline"],
        old_key: str,
        new_key: str,
    ) -> None:
        """Rename one object by copying it to the new key then deleting the old key."""
        if self.object_exists(bucket, new_key):
            raise FileExistsError(f"destination already exists: {new_key}")
        bucket_obj = self.buckets[bucket]
        bucket_obj.copy_object(self.bucket_names[bucket], old_key, new_key)
        bucket_obj.delete_object(old_key)

    def rename_folder(
        self,
        bucket: Literal["data", "model", "asset", "corpus", "pipeline"],
        old_prefix: str,
        new_prefix: str,
    ) -> None:
        """Rename a folder prefix by copying every object before deleting old keys."""
        old_prefix = old_prefix if old_prefix.endswith("/") else f"{old_prefix}/"
        new_prefix = new_prefix if new_prefix.endswith("/") else f"{new_prefix}/"
        objects = self.list_objects(bucket, old_prefix)
        if not objects:
            raise FileNotFoundError(f"folder prefix does not exist: {old_prefix}")

        planned_copies = [
            (obj.key, f"{new_prefix}{obj.key[len(old_prefix):]}") for obj in objects
        ]
        conflicts = [
            new_key
            for _old_key, new_key in planned_copies
            if self.object_exists(bucket, new_key)
        ]
        if conflicts:
            raise FileExistsError(f"destination already exists: {conflicts[0]}")

        bucket_obj = self.buckets[bucket]
        for old_key, new_key in planned_copies:
            bucket_obj.copy_object(self.bucket_names[bucket], old_key, new_key)
        for old_key, _new_key in planned_copies:
            bucket_obj.delete_object(old_key)

    def download(
        self,
        file: str,
        bucket: Literal["data", "model", "asset", "corpus", "pipeline"],
        save_dir: str = "./",
        force: bool = False,
    ):
        """下载文件或文件夹
        - file: 要下载的文件或文件夹路径（文件夹以 / 结尾）
        - bucket: 要下载的bucket
        - save_dir: 保存目录, 默认当前目录
        - force: 是否覆盖已存在的文件
        """
        if save_dir is None:
            save_dir = bucket
        save_dir: Path = Path(save_dir)
        if not save_dir.exists():
            save_dir.mkdir(parents=True, exist_ok=True)
        bucket_obj: Bucket = self.buckets.get(bucket)

        # 检查是文件还是文件夹（以 / 结尾视为文件夹）
        is_folder = file.endswith("/")

        if is_folder:
            # 文件夹下载
            self._download_folder(bucket_obj, file, save_dir, force)
        else:
            # 单文件下载，先检查是否匹配多个文件（前缀匹配）
            objects = self._list_prefix(bucket_obj, file)
            if len(objects) > 1:
                # 匹配多个文件，视为文件夹下载
                folder_prefix = file if file.endswith("/") else file + "/"
                self._download_folder(bucket_obj, folder_prefix, save_dir, force)
            elif len(objects) == 1:
                # 单个文件
                self._download_single(bucket_obj, objects[0].key, save_dir, force)
            else:
                console.print(
                    f"[bold red]错误：文件 '{file}' 在 bucket '{bucket}' 中不存在[/bold red]"
                )

    def _download_single(
        self, bucket_obj: Bucket, file: str, save_dir: Path, force: bool = False
    ):
        """下载单个文件"""
        file_path = save_dir / file

        if file_path.exists() and not force:
            file_size = file_path.stat().st_size
            console.print(
                f"[yellow]⚠️  File '{file}' already exists in {save_dir} ({file_size / 1024 / 1024:.1f} MB)[/yellow]"
            )
            console.print(
                "[bold cyan]💡 Tip: Use --force to overwrite existing file[/bold cyan]"
            )
            return

        try:
            console.print(
                f"[blue]🚀 Starting download of '{file}'[/blue]"
            )
            with Progress(
                TextColumn("[bold blue]{task.description}", justify="left"),
                BarColumn(bar_width=30),
                TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
                TextColumn("[bold green]{task.fields[size_info]}", justify="left"),
                TransferSpeedColumn(),
                TextColumn("[cyan]已用时:"),
                TimeElapsedColumn(),
                TextColumn("[yellow]剩余:"),
                TimeRemainingColumn(),
                console=console,
            ) as progress:
                download_task = progress.add_task(
                    f"⬇️  downloading {Path(file).name}", size_info="0.0/0.0 MB"
                )

                def download_progress(consumed_bytes, total_bytes):
                    if total_bytes > 0:
                        consumed_mb = consumed_bytes / 1024 / 1024
                        total_mb = total_bytes / 1024 / 1024
                        progress.update(
                            download_task,
                            total=total_bytes,
                            completed=consumed_bytes,
                            size_info=f"{consumed_mb:.1f}/{total_mb:.1f} MB",
                        )

                bucket_obj.get_object_to_file(
                    key=file,
                    filename=file_path,
                    progress_callback=download_progress,
                )

            console.print(f"[bold green]✅ download {file} succeed")
        except Exception as e:
            console.print(f"[bold red]❌ download {file} failed: {e}[/bold red]")
        except KeyboardInterrupt:
            console.print("[yellow]⚠️  download cancelled by user[/yellow]")
            if file_path.exists():
                file_path.unlink()

    def _download_folder(
        self, bucket_obj: Bucket, prefix: str, save_dir: Path, force: bool = False
    ):
        """下载整个文件夹（前缀下的所有文件）"""
        objects = self._list_prefix(bucket_obj, prefix)

        if not objects:
            console.print(
                f"[bold red]错误：文件夹 '{prefix}' 在 bucket 中不存在[/bold red]"
            )
            return

        total_size = sum(obj.size for obj in objects if hasattr(obj, "size"))
        total_count = len(objects)

        console.print(
            f"[blue]🚀 Starting download of folder '{prefix}' ({total_count} files, {total_size / 1024 / 1024:.1f} MB)[/blue]"
        )

        with Progress(
            TextColumn("[bold blue]{task.description}", justify="left"),
            BarColumn(bar_width=30),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TextColumn("[bold green]{task.fields[size_info]}", justify="left"),
            TransferSpeedColumn(),
            TextColumn("[cyan]已用时:"),
            TimeElapsedColumn(),
            TextColumn("[yellow]剩余:"),
            TimeRemainingColumn(),
            console=console,
        ) as progress:
            download_task = progress.add_task(
                f"⬇️  downloading {prefix}",
                size_info=f"0/{total_count} files • 0.0/{total_size / 1024 / 1024:.1f} MB",
                total=total_size,
            )

            downloaded_size = 0
            downloaded_count = 0
            failed_count = 0

            for obj in objects:
                obj_path = save_dir / obj.key
                obj_dir = obj_path.parent

                if not obj_dir.exists():
                    obj_dir.mkdir(parents=True, exist_ok=True)

                if obj_path.exists() and not force:
                    # 跳过已存在的文件
                    downloaded_size += obj.size if hasattr(obj, "size") else 0
                    downloaded_count += 1
                    progress.update(
                        download_task,
                        completed=downloaded_size,
                        size_info=f"{downloaded_count}/{total_count} files • {downloaded_size / 1024 / 1024:.1f}/{total_size / 1024 / 1024:.1f} MB",
                    )
                    continue

                try:
                    def download_progress(consumed_bytes, total_bytes):
                        nonlocal downloaded_size
                        downloaded_size += consumed_bytes
                        if progress:
                            progress.update(
                                download_task,
                                completed=downloaded_size,
                                size_info=f"{downloaded_count}/{total_count} files • {downloaded_size / 1024 / 1024:.1f}/{total_size / 1024 / 1024:.1f} MB",
                            )

                    bucket_obj.get_object_to_file(
                        key=obj.key,
                        filename=obj_path,
                        progress_callback=download_progress,
                    )
                    downloaded_count += 1

                except Exception as e:
                    failed_count += 1
                    console.print(f"[red]❌ Failed to download {obj.key}: {e}[/red]")

        if failed_count == 0:
            console.print(
                f"[bold green]✅ download {total_count} files from '{prefix}' succeed[/bold green]"
            )
        else:
            console.print(
                f"[bold yellow]⚠️  downloaded {downloaded_count} files, {failed_count} failed[/bold yellow]"
            )

    def _delete_by_prefix(
        self, bucket_obj: Bucket, prefix: str, is_folder: bool = False
    ) -> tuple[int, int, int]:
        """根据前缀删除文件

        Returns:
            (成功数, 失败数, 总大小字节数)
        """
        objects = self._list_prefix(bucket_obj, prefix)

        if not objects:
            return 0, 0, 0

        deleted_count = 0
        failed_count = 0
        total_size = 0

        for obj in objects:
            try:
                bucket_obj.delete_object(obj.key)
                deleted_count += 1
                total_size += obj.size if hasattr(obj, "size") else 0
            except Exception as e:
                failed_count += 1
                console.print(f"[red]❌ Failed to delete {obj.key}: {e}[/red]")

        return deleted_count, failed_count, total_size

    def delete(
        self,
        file: str,
        bucket: Literal["data", "model", "asset", "corpus", "pipeline"],
        fuzzy: bool = False,
    ):
        """删除文件或者目录（支持前缀匹配）

        Args:
            file: 要删除的文件名或目录前缀（以 / 结尾视为文件夹），或使用 "ALL" 删除全部
            bucket: bucket名称
            fuzzy: 是否按包含关系模糊匹配文件名

        Examples:
            # 删除单个文件
            oss delete myfile.txt model

            # 删除文件夹（以 / 结尾）
            oss delete my_folder/ model

            # 根据前缀匹配删除（不带 /，匹配所有以该前缀开头的文件）
            oss delete my_folder model

            # 删除bucket中的所有文件
            oss delete ALL model

            # 删除所有key中包含关键词的文件
            oss delete flashtalk asset --fuzzy
        """
        bucket_obj: Bucket = self.buckets.get(bucket)

        if file.upper() == "ALL":
            # 删除bucket中的所有文件
            console.print(
                f"[yellow]🗑️  Deleting all files from bucket '{bucket}'...[/yellow]"
            )
            deleted_count, failed_count, total_size = self._delete_by_prefix(
                bucket_obj, ""
            )
            if deleted_count == 0 and failed_count == 0:
                console.print(f"[blue]📂 Bucket '{bucket}' is already empty[/blue]")
            elif failed_count == 0:
                size_mb = total_size / 1024 / 1024
                console.print(
                    f"[bold green]✅ Successfully deleted {deleted_count} files ({size_mb:.1f} MB) from bucket '{bucket}'[/bold green]"
                )
            else:
                console.print(
                    f"[bold yellow]⚠️  Deleted {deleted_count} files, {failed_count} failed[/bold yellow]"
                )
            return

        if fuzzy:
            console.print(
                f"[yellow]🗑️  Deleting files containing '{file}' from bucket '{bucket}'...[/yellow]"
            )
            objects = [obj for obj in self._list_prefix(bucket_obj, "") if file in obj.key]
            if not objects:
                console.print(
                    f"[yellow]⚠️  No files found containing '{file}' in bucket '{bucket}'[/yellow]"
                )
                return

            total_size = sum(obj.size for obj in objects if hasattr(obj, "size"))
            console.print(
                f"[dim]Found {len(objects)} files to delete ({total_size / 1024 / 1024:.1f} MB)[/dim]"
            )

            deleted_count = 0
            failed_count = 0
            for obj in objects:
                try:
                    bucket_obj.delete_object(obj.key)
                    deleted_count += 1
                except Exception as e:
                    failed_count += 1
                    console.print(f"[red]❌ Failed to delete {obj.key}: {e}[/red]")

            if failed_count == 0:
                console.print(
                    f"[bold green]✅ Successfully deleted {deleted_count} files containing '{file}'[/bold green]"
                )
            else:
                console.print(
                    f"[bold yellow]⚠️  Deleted {deleted_count} files, {failed_count} failed[/bold yellow]"
                )
            return

        # 判断是文件夹还是前缀匹配
        is_folder = file.endswith("/")

        if is_folder:
            # 文件夹删除（精确前缀）
            prefix = file
        else:
            # 单文件删除优先：如果存在精确匹配的 key，不要把文件名当目录前缀处理
            objects = self._list_prefix(bucket_obj, file)
            exact_objects = [obj for obj in objects if obj.key == file]
            if exact_objects:
                obj = exact_objects[0]
                console.print(
                    f"[yellow]🗑️  Deleting file '{file}' from bucket '{bucket}'...[/yellow]"
                )
                try:
                    bucket_obj.delete_object(file)
                except Exception as e:
                    console.print(f"[red]❌ Failed to delete {file}: {e}[/red]")
                    console.print(
                        "[bold yellow]⚠️  Deleted 0 files, 1 failed[/bold yellow]"
                    )
                    return

                size = obj.size if hasattr(obj, "size") else 0
                console.print(
                    f"[bold green]✅ Successfully deleted 1 file ({size / 1024 / 1024:.1f} MB) from bucket '{bucket}'[/bold green]"
                )
                return

            # 前缀匹配删除（不以 / 结尾，自动加 / 匹配目录内容）
            prefix = file + "/"

        console.print(
            f"[yellow]🗑️  Deleting files with prefix '{prefix}' from bucket '{bucket}'...[/yellow]"
        )

        # 先列出匹配的文件，让用户知道要删什么
        objects = self._list_prefix(bucket_obj, prefix)
        if not objects:
            console.print(
                f"[yellow]⚠️  No files found with prefix '{prefix}' in bucket '{bucket}'[/yellow]"
            )
            return

        total_size = sum(obj.size for obj in objects if hasattr(obj, "size"))
        console.print(
            f"[dim]Found {len(objects)} files to delete ({total_size / 1024 / 1024:.1f} MB)[/dim]"
        )

        deleted_count, failed_count, _ = self._delete_by_prefix(bucket_obj, prefix)

        if failed_count == 0:
            console.print(
                f"[bold green]✅ Successfully deleted {deleted_count} files from prefix '{prefix}'[/bold green]"
            )
        else:
            console.print(
                f"[bold yellow]⚠️  Deleted {deleted_count} files, {failed_count} failed[/bold yellow]"
            )

    def clear(self):
        """清空本地缓存和API密钥"""
        if self.auth_file.exists():
            os.remove(self.auth_file)

    def info(self):
        """
        打印当前的auth信息
        """
        access_key_id, access_key_secret = load_auth(self.auth_file)
        console.print("[bold cyan]auth:[/bold cyan]")
        console.print(f"  access_key_id: {access_key_id}")
        console.print(f"  access_key_secret: {access_key_secret}")


def run():
    from d_oss.tui import DOSSApp

    DOSSApp().run()


if __name__ == "__main__":
    run()
