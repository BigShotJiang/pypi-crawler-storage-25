# d-oss

阿里云 OSS 对象存储交互式终端应用。

## 安装

```bash
pip install -e .
```

首次运行时会提示输入 `access_key_id` 和 `access_key_secret`，凭证会保存在 `~/.cache/d-oss/auth.json`。
如果本地还没有缓存凭证，应用启动后也会在日志区提醒需要输入 API key。

## 配置

凭证文件位于 `~/.cache/d-oss/auth.json`，可手动编辑。

## 使用方法

启动应用：

```bash
oss
```

进入应用后：

1. 点击左侧 bucket 按钮：`data`、`model`、`asset`、`corpus`、`pipeline`
2. 在右侧文件表中选择文件或文件夹
3. 使用操作按钮执行上传、下载、重命名、删除、复制 URL、刷新或返回上级目录

右侧文件表会把 OSS key 按 `/` 展示成目录结构。选中文件夹后点击 `Open` 进入目录，点击 `Back` 返回上级目录。

界面顶部会显示快捷键提示：

- `Ctrl+C`：退出应用
- `r`：刷新当前目录
- `Backspace`：返回上级目录
- `Tab`、方向键、`Enter`：切换焦点、选择行、执行按钮

## 操作说明

- **Upload File**：在路径输入框填写本地文件路径，上传到当前 bucket 和当前目录。上传时会显示进度条。
- **Upload Folder**：在路径输入框填写本地文件夹路径，上传到当前 bucket 和当前目录，并保留内部目录结构。上传时会显示整体进度条。
- **多选**：点击文件表中的条目可加入或移出多选集合。文件表名称前的 `✅` 表示已加入多选。再次点击同一条目会取消选中。部分终端支持 `Shift` + 点击从上一次点击的条目到当前条目范围选择。
- **Download**：如果有多选集合，则一次下载所有 `✅` 条目；否则下载当前选中的文件或文件夹。保存目录使用路径输入框，默认是 `./`。
- **Rename**：选中文件或文件夹，在重命名输入框填写新名称后点击 `Rename`。
- **Delete**：选中文件或文件夹后点击 `Delete`，再次点击确认删除。
- **Copy URL**：选中文件后输出可访问 URL。文件夹没有单一 URL。
- **Refresh**：重新加载当前 bucket 和目录。
- **Back**：返回上级目录。

路径输入框支持本地路径自动提示。可以输入相对路径、绝对路径或 `~` 开头的路径，例如 `./data`、`/Users/wangmengdi/Desktop`、`~/Downloads`。目录提示会以 `/` 结尾。

## Bucket 说明

| 名称 | 用途 | Endpoint |
|------|------|----------|
| `data` | 数据 | oss-cn-beijing |
| `model` | 预训练模型 | oss-cn-beijing |
| `asset` | 资源 | oss-cn-beijing |
| `corpus` | 语料 | oss-cn-hangzhou |
| `pipeline` | spaCy 管道 | oss-cn-beijing |

## 上传/下载行为说明

- **上传目录**：递归上传所有文件，保持本地目录结构（例如在当前目录上传 `my_folder` 后，OSS 路径为 `my_folder/a.txt`）
- **下载文件夹**：根据前缀匹配下载所有文件，自动重建目录结构
- **删除**：文件夹删除按 OSS 前缀删除
- **重命名**：OSS 没有原生重命名，应用会先复制到新 key，复制成功后再删除旧 key
