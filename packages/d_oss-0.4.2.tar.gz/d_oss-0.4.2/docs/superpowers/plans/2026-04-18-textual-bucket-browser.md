# Textual Bucket Browser Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [x]`) syntax for tracking.

**Goal:** Replace the command-input Textual shell with a bucket browser that supports bucket buttons, directory navigation, upload, download, rename, delete, and file URL copying.

**Architecture:** Keep OSS network operations in `OSSStorer`, add small browser-focused OSS methods there, and keep Textual UI state in `d_oss/tui.py`. Directory browsing is powered by a pure `build_directory_entries()` helper that converts flat OSS keys into directory/file rows for the current prefix.

**Tech Stack:** Python 3.10, Textual 8, Rich, oss2, pytest, uv.

---

### Task 1: Directory Entry Model

**Files:**
- Modify: `tests/test_d_oss.py`
- Create/Modify: `d_oss/tui.py`

- [x] **Step 1: Write failing tests**

Add tests for `build_directory_entries()`:

```python
from d_oss.tui import BrowserEntry, build_directory_entries

def test_build_directory_entries_groups_root_folders():
    objects = [
        SimpleNamespace(key="models/bert/base.bin", size=100, last_modified=1),
        SimpleNamespace(key="models/bert/config.json", size=20, last_modified=2),
        SimpleNamespace(key="datasets/train.json", size=30, last_modified=3),
        SimpleNamespace(key="readme.txt", size=4, last_modified=4),
    ]

    entries = build_directory_entries(objects, "")

    assert entries == [
        BrowserEntry(name="datasets", key="datasets/", kind="folder", size=None, last_modified=None),
        BrowserEntry(name="models", key="models/", kind="folder", size=None, last_modified=None),
        BrowserEntry(name="readme.txt", key="readme.txt", kind="file", size=4, last_modified=4),
    ]

def test_build_directory_entries_filters_current_prefix():
    objects = [
        SimpleNamespace(key="models/bert/base.bin", size=100, last_modified=1),
        SimpleNamespace(key="models/bert/config.json", size=20, last_modified=2),
        SimpleNamespace(key="models/readme.txt", size=4, last_modified=4),
    ]

    entries = build_directory_entries(objects, "models/")

    assert entries == [
        BrowserEntry(name="bert", key="models/bert/", kind="folder", size=None, last_modified=None),
        BrowserEntry(name="readme.txt", key="models/readme.txt", kind="file", size=4, last_modified=4),
    ]
```

- [x] **Step 2: Run red test**

Run: `uv run python -m pytest tests/test_d_oss.py::test_build_directory_entries_groups_root_folders tests/test_d_oss.py::test_build_directory_entries_filters_current_prefix -v`

Expected: FAIL because `BrowserEntry` and `build_directory_entries` are missing.

- [x] **Step 3: Implement minimal model/helper**

Create a frozen dataclass:

```python
@dataclass(frozen=True)
class BrowserEntry:
    name: str
    key: str
    kind: Literal["file", "folder"]
    size: int | None = None
    last_modified: int | None = None
```

Implement `build_directory_entries(objects, prefix)` by splitting object keys after `prefix`, deduplicating first path segments as folders, and sorting folders before files.

- [x] **Step 4: Run green test**

Run: `uv run python -m pytest tests/test_d_oss.py -v`

Expected: PASS.

### Task 2: Browser OSS Operations

**Files:**
- Modify: `tests/test_d_oss.py`
- Modify: `d_oss/__main__.py`

- [x] **Step 1: Write failing tests**

Add fake bucket methods for `object_exists`, `copy_object`, `put_object_from_file`, and `delete_object`. Test:

- `list_objects(bucket, prefix)` delegates to `oss2.ObjectIterator`
- `upload_file_to_key()` refuses destination conflicts
- `upload_file_to_key()` calls `put_object_from_file(key=dest_key, filename=local_path)`
- `rename_file()` copies then deletes
- `rename_folder()` copies every object under the prefix then deletes old keys only after all copies succeed

- [x] **Step 2: Run red tests**

Run: `uv run python -m pytest tests/test_d_oss.py -v`

Expected: FAIL because the methods do not exist.

- [x] **Step 3: Implement methods in `OSSStorer`**

Add:

```python
def list_objects(self, bucket, prefix=""): ...
def object_exists(self, bucket, key): ...
def upload_file_to_key(self, local_path, bucket, key, overwrite=False): ...
def upload_folder_to_prefix(self, local_path, bucket, prefix, overwrite=False): ...
def rename_file(self, bucket, old_key, new_key): ...
def rename_folder(self, bucket, old_prefix, new_prefix): ...
```

Use existing `self.buckets` and oss2 bucket methods. Never delete old keys until copy succeeds.

- [x] **Step 4: Run green tests**

Run: `uv run python -m pytest tests/test_d_oss.py -v`

Expected: PASS.

### Task 3: Textual Browser UI

**Files:**
- Modify: `d_oss/tui.py`
- Modify: `tests/test_d_oss.py`

- [x] **Step 1: Write failing headless mount test**

Replace the command-input mount test with a browser UI test:

```python
from textual.widgets import Button, DataTable, Input

def test_textual_app_mounts_bucket_browser():
    async def run_app():
        app = DOSSApp(storer=object())
        async with app.run_test():
            assert app.query_one("#bucket-data", Button).label == "data"
            assert app.query_one("#file-table", DataTable)
            assert app.query_one("#path-input", Input).value == "./"

    asyncio.run(run_app())
```

- [x] **Step 2: Run red test**

Run: `uv run python -m pytest tests/test_d_oss.py::test_textual_app_mounts_bucket_browser -v`

Expected: FAIL because current UI still exposes command input.

- [x] **Step 3: Implement Textual layout**

Build:

- left sidebar bucket buttons
- right path label and file `DataTable`
- action buttons: upload file, upload folder, download, rename, delete, copy URL, refresh, back
- inputs for local path, save directory, rename target
- `RichLog` output

Use helper methods to load bucket contents, render entries, select rows, and call `OSSStorer` methods through `asyncio.to_thread`.

- [x] **Step 4: Run green tests**

Run: `uv run python -m pytest tests/test_d_oss.py -v`

Expected: PASS.

### Task 4: Docs and Final Verification

**Files:**
- Modify: `README.md`

- [x] **Step 1: Update docs**

Document:

- `oss` starts the browser
- click bucket buttons
- browse folders
- upload file/folder
- download, rename, delete, copy URL

- [x] **Step 2: Run verification**

Run:

```bash
uv run python -m pytest
uv run python -m compileall d_oss
```

Expected: all tests pass and compileall exits 0.

- [x] **Step 3: Commit implementation**

Commit all implementation changes with:

```bash
git add README.md d_oss/__main__.py d_oss/tui.py pyproject.toml uv.lock tests/test_d_oss.py docs/superpowers/plans/2026-04-18-textual-bucket-browser.md
git commit -m "Build Textual bucket browser"
```
