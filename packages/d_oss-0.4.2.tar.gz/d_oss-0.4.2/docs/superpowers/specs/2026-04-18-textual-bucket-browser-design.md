# Textual Bucket Browser Design

## Goal

Turn `oss` into an interactive Textual terminal app that behaves like a small desktop file manager for Alibaba OSS buckets.

The app opens directly with `oss`. Users should not need to type subcommands for normal browsing. They can click a bucket, browse directory-like folders, select files or folders, then download, rename, delete, or copy a URL.

## Layout

Use a two-pane layout:

- Left sidebar: fixed bucket buttons for `data`, `model`, `asset`, `corpus`, and `pipeline`.
- Right pane: current bucket, current path, file/folder list, and action buttons.
- Bottom area: status and operation log.

The selected bucket stays highlighted. Clicking another bucket refreshes the right pane at that bucket root.

## Directory Model

OSS stores object keys as flat strings. The UI presents keys as folders by splitting on `/`.

Example keys:

```text
models/bert/base.bin
models/bert/config.json
datasets/train.json
```

Root view:

```text
models/
datasets/
```

Inside `models/`:

```text
bert/
```

Inside `models/bert/`:

```text
base.bin
config.json
```

The UI keeps a `current_prefix` for navigation. A Back action removes one path segment.

## Actions

When a file is selected:

- Download
- Rename
- Delete
- Copy URL

When a folder is selected:

- Download Folder
- Rename Folder
- Delete Folder

Always available in the current bucket/path:

- Upload File
- Upload Folder
- Refresh

Deletion requires confirmation before calling the existing delete behavior.

Download uses the existing download behavior. Files and folders default to saving under `./`, with a visible path input for changing the target directory.

Copy URL only applies to files. Folders do not have one canonical URL.

Upload uses the current bucket and current prefix as the default destination. Users provide a local file or folder path. File upload stores the file at `current_prefix + filename`. Folder upload stores the folder under `current_prefix + folder_name/` and preserves its nested structure.

## Rename Semantics

OSS has no native rename operation. Rename is implemented as copy-then-delete.

For a file:

1. Validate the new name.
2. Build a new key in the same parent prefix unless the user provides a path.
3. Refuse to overwrite an existing key.
4. Copy old key to new key.
5. Delete old key only after copy succeeds.
6. Refresh the current directory.

For a folder:

1. Treat the selected folder key as a prefix.
2. Build a new prefix in the same parent unless the user provides a path.
3. Refuse to continue if any destination key already exists.
4. Copy every object under the old prefix to the new prefix.
5. Delete old objects only after all copies succeed.
6. Refresh the current directory.

If any copy fails, keep the old objects in place and report the failure in the log.

## Core Code Boundaries

Keep OSS operations in `OSSStorer`. Add focused methods where the existing API is missing browser behavior:

- List objects for a bucket and prefix.
- Check whether an object exists.
- Upload a local file to a specific destination key.
- Upload a local folder under a specific destination prefix.
- Rename a file key.
- Rename a folder prefix.

Keep UI state and navigation in `d_oss/tui.py`:

- selected bucket
- current prefix
- selected entry
- operation status/log

The directory tree transformation should be a pure helper so it can be unit tested without OSS credentials or a terminal session.

## Error Handling

- Invalid bucket: show an error in the log.
- Empty bucket or folder: show an empty-state message.
- Upload path does not exist: show a clear error.
- Upload destination exists: do not overwrite by default; show a clear error.
- Delete without selection: disable action or show a clear error.
- Rename destination exists: do not overwrite; show a clear error.
- Network or OSS errors: catch exceptions, show the message in the log, and leave UI usable.

## Testing

Automated tests should cover:

- flat OSS keys converted into directory entries for the current prefix
- navigating into a folder and back to the parent prefix
- upload file maps local path to `current_prefix + filename`
- upload folder maps local files under `current_prefix + folder_name/`
- file rename maps old key to new key correctly
- folder rename copies every key under the prefix and deletes only after copy success
- destination conflicts block rename
- Textual app mounts headlessly

Existing delete behavior tests should remain in place.
