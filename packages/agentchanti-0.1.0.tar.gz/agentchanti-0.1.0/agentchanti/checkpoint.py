"""
Checkpoint & resume — saves and restores pipeline state so interrupted
runs can pick up where they left off.
"""

import json
import os

DEFAULT_CHECKPOINT_FILE = ".agentchanti_checkpoint.json"


def save_checkpoint(filepath: str, task: str, steps: list[str],
                    completed_step: int, file_memory_dict: dict[str, str],
                    step_results: dict[int, str], language: str,
                    display_state: dict | None = None,
                    dependencies: dict[int, set[int]] | None = None,
                    plan_steps: list | None = None,
                    project_context=None) -> None:
    """Persist current pipeline state to *filepath* as JSON.

    *plan_steps*, if provided, should be a list of PlanStep objects (or
    anything with a ``.to_dict()`` method).  They are serialised so that
    on resume the full structured metadata (step_type, target_files,
    exports, imports_from, command, status) is preserved.

    *project_context*, if provided, should be a ProjectContext object
    (or anything with a ``.to_dict()`` method) so that the analysis
    phase can be skipped on resume.
    """
    state = {
        "task": task,
        "steps": steps,
        "completed_step": completed_step,
        "file_memory": file_memory_dict,
        "step_results": {str(k): v for k, v in step_results.items()},
        "language": language,
    }
    if dependencies is not None:
        state["dependencies"] = {str(k): list(v) for k, v in dependencies.items()}
    if display_state is not None:
        state["display_state"] = display_state
    if plan_steps is not None:
        state["plan_steps"] = [s.to_dict() for s in plan_steps]
    if project_context is not None and hasattr(project_context, "to_dict"):
        state["project_context"] = project_context.to_dict()
    tmp = filepath + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(state, f, indent=2)
    # Atomic-ish rename (Windows: replaces if exists on Python 3.3+)
    if os.path.exists(filepath):
        os.remove(filepath)
    os.rename(tmp, filepath)


def load_checkpoint(filepath: str) -> dict | None:
    """Load checkpoint state from *filepath*.

    Returns the state dict, or ``None`` if the file is missing or invalid.

    If the checkpoint contains ``plan_steps`` (list of PlanStep dicts),
    they are left as raw dicts — the caller should reconstruct PlanStep
    objects via ``PlanStep.from_dict()``.
    """
    if not os.path.isfile(filepath):
        return None
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            state = json.load(f)
        # Validate required keys
        required = {"task", "steps", "completed_step", "file_memory",
                     "step_results", "language"}
        if not required.issubset(state.keys()):
            return None
        # Convert step_results keys back to int
        state["step_results"] = {int(k): v for k, v in state["step_results"].items()}
        return state
    except (json.JSONDecodeError, OSError, ValueError):
        return None


def clear_checkpoint(filepath: str) -> None:
    """Remove the checkpoint file after a successful run."""
    try:
        if os.path.isfile(filepath):
            os.remove(filepath)
    except OSError:
        pass
