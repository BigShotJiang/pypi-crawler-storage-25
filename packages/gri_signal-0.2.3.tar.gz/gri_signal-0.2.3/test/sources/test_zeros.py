"""Tests for zeros signal generation."""

from __future__ import annotations

import numpy as np
import pytest

from gri_signal.sources import zeros


@pytest.mark.parametrize(
    ("fs", "duration", "channels", "expected_shape"),
    [
        (1000, 0.1, 1, (100,)),
        (1000, 0.1, 2, (2, 100)),
        (10000, 0.5, 4, (4, 5000)),
    ],
)
def test_zeros_generates_correct_shape(fs, duration, channels, expected_shape):
    """Zeros generates signal with correct shape."""
    sig = zeros(fs, duration=duration, channels=channels)
    assert sig.shape == expected_shape


def test_zeros_all_zero():
    """Zeros signal contains only zeros."""
    sig = zeros(1000, duration=0.1)
    assert np.all(sig == 0)


def test_zeros_dtype_float():
    """Zeros with float dtype."""
    sig = zeros(1000, duration=0.1, dtype=float)
    assert sig.dtype == np.float64


def test_zeros_samples_parameter():
    """Zeros with samples parameter."""
    sig = zeros(1000, samples=500)
    assert sig.shape == (500,)
