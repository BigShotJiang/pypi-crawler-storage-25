"""Tests for PRN signal generation."""

from __future__ import annotations

import numpy as np
import pytest

from gri_signal.sources import prn


@pytest.mark.parametrize(
    ("fs", "duration", "expected_len"),
    [
        (1000, 0.1, 100),
        (10000, 0.5, 5000),
    ],
)
def test_prn_generates_correct_length(fs, duration, expected_len):
    """PRN generates signal with correct length."""
    sig = prn(fs, duration=duration)
    assert sig.shape == (expected_len,)
    assert sig.dtype == np.complex128


def test_prn_seed_reproducibility():
    """Same seed produces same signal."""
    sig1 = prn(1000, duration=0.1, seed=42)
    sig2 = prn(1000, duration=0.1, seed=42)
    assert np.allclose(sig1, sig2)


def test_prn_different_seeds_differ():
    """Different seeds produce different signals."""
    sig1 = prn(1000, duration=0.1, seed=42)
    sig2 = prn(1000, duration=0.1, seed=43)
    assert not np.allclose(sig1, sig2)


def test_prn_lowpass_filtering():
    """PRN with hz_high applies lowpass filter."""
    fs = 10000
    sig = prn(fs, duration=0.1, hz_high=100, seed=42)
    spectrum = np.abs(np.fft.fft(sig))
    freqs = np.fft.fftfreq(len(sig), 1 / fs)
    # High frequencies should be attenuated
    high_freq_power = np.mean(spectrum[np.abs(freqs) > 500])
    low_freq_power = np.mean(spectrum[np.abs(freqs) < 100])
    assert low_freq_power > high_freq_power * 10


def test_prn_bandpass_filtering():
    """PRN with hz_low and hz_high applies bandpass filter."""
    fs = 10000
    sig = prn(fs, duration=0.1, hz_low=100, hz_high=200, seed=42)
    assert sig.shape == (1000,)
    assert sig.dtype == np.complex128
