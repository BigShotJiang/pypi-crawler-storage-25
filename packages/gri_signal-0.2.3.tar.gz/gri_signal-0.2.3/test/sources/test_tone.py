"""Tests for tone signal generation."""

from __future__ import annotations

import numpy as np
import pytest

from gri_signal.sources import tone


@pytest.mark.parametrize(
    ("fs", "freq", "duration", "expected_len"),
    [
        (1000, 100, 0.1, 100),
        (10000, 500, 0.05, 500),
        (44100, 440, 1.0, 44100),
    ],
)
def test_tone_generates_correct_length(fs, freq, duration, expected_len):
    """Tone generates signal with correct length."""
    sig = tone(fs, freq, duration=duration)
    assert sig.shape == (expected_len,)
    assert sig.dtype == np.complex128


@pytest.mark.parametrize(
    ("fs", "freq", "f_center", "expected_baseband"),
    [
        (1000, 100, 0, 100),
        (1000, 150, 100, 50),
        (10000, 1000, 1000, 0),
    ],
)
def test_tone_frequency_content(fs, freq, f_center, expected_baseband):
    """Tone has correct frequency content after baseband conversion."""
    sig = tone(fs, freq, f_center=f_center, duration=1.0)
    spectrum = np.abs(np.fft.fft(sig))
    freqs = np.fft.fftfreq(len(sig), 1 / fs)
    peak_freq = abs(freqs[np.argmax(spectrum)])
    assert abs(peak_freq - expected_baseband) < 1.0


def test_tone_with_start_stop_windows():
    """Tone with start/stop has zeros at edges."""
    sig = tone(1000, 100, duration=0.1, start=0.02, stop=0.08)
    assert np.abs(sig[0]) < 0.1
    assert np.abs(sig[-1]) < 0.1


def test_tone_phase_offset_changes_signal():
    """Phase offset produces different signal."""
    sig1 = tone(1000, 100, duration=0.1, phase_offset=0)
    sig2 = tone(1000, 100, duration=0.1, phase_offset=np.pi / 2)
    assert not np.allclose(sig1, sig2)
