"""Tests for ULA steering vector generation."""

from __future__ import annotations

import numpy as np
import pytest

from gri_signal.sources import ula_steering


@pytest.mark.parametrize(
    "n_elements",
    [
        2,
        4,
        8,
    ],
)
def test_ula_steering_shape(n_elements):
    """Steering vector has correct shape."""
    steering = ula_steering(30.0, 0.15, 0.3, n_elements=n_elements)
    assert steering.shape == (n_elements,)
    assert steering.dtype == np.complex128


def test_ula_steering_first_element_unity():
    """First element is always phase reference (magnitude 1, phase 0)."""
    steering = ula_steering(45.0, 0.15, 0.3, n_elements=4)
    assert np.isclose(steering[0], 1.0 + 0j)


def test_ula_steering_broadside_all_unity():
    """At broadside (0 degrees), all elements have same phase."""
    steering = ula_steering(0.0, 0.15, 0.3, n_elements=4)
    assert np.allclose(steering, 1.0)


def test_ula_steering_unit_magnitude():
    """All elements have unit magnitude."""
    steering = ula_steering(30.0, 0.15, 0.3, n_elements=4)
    assert np.allclose(np.abs(steering), 1.0)


@pytest.mark.parametrize(
    "aoa_deg",
    [
        0.0,
        30.0,
        45.0,
        -30.0,
    ],
)
def test_ula_steering_different_angles(aoa_deg):
    """Steering vector works for various angles."""
    wavelength = 0.3
    d = wavelength / 2
    steering = ula_steering(aoa_deg, d, wavelength, n_elements=4)
    assert steering.shape == (4,)
    assert np.allclose(np.abs(steering), 1.0)
