"""Tests for PRI signal generation."""

from __future__ import annotations

import numpy as np
import pytest

from gri_signal.sources import pri


@pytest.mark.parametrize(
    ("fs", "freq", "pri_interval", "pulse_width", "duration", "expected_len"),
    [
        (10000, 1000, 0.01, 0.001, 0.1, 1000),
        (100000, 5000, 0.001, 0.0001, 0.01, 1000),
    ],
)
def test_pri_generates_correct_length(
    fs,
    freq,
    pri_interval,
    pulse_width,
    duration,
    expected_len,
):
    """PRI generates signal with correct length."""
    sig = pri(fs, freq, pri_interval, pulse_width, duration=duration)
    assert sig.shape == (expected_len,)
    assert sig.dtype == np.complex128


def test_pri_has_pulses_and_gaps():
    """PRI signal has non-zero pulses and zero gaps."""
    fs = 10000
    sig = pri(fs, 1000, pri_interval=0.01, pulse_width=0.002, duration=0.1)
    # Should have some zeros (gaps) and some non-zeros (pulses)
    zeros_count = np.sum(np.abs(sig) < 0.01)
    nonzeros_count = np.sum(np.abs(sig) >= 0.01)
    assert zeros_count > 0
    assert nonzeros_count > 0


def test_pri_with_f_center():
    """PRI with center frequency offset."""
    sig = pri(10000, 1500, 0.01, 0.001, f_center=1000, duration=0.1)
    assert sig.shape == (1000,)


def test_pri_phase_offset():
    """PRI with phase offset produces different signal."""
    sig1 = pri(10000, 1000, 0.01, 0.001, duration=0.1, phase_offset=0)
    sig2 = pri(10000, 1000, 0.01, 0.001, duration=0.1, phase_offset=np.pi / 2)
    assert not np.allclose(sig1, sig2)
