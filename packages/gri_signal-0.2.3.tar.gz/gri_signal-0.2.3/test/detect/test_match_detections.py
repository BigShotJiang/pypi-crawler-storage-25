"""Tests for matching detections against ground-truth labels."""

from __future__ import annotations

import numpy as np

from gri_signal.detect import match_detections


def test_match_detections_perfect() -> None:
    """Perfect detections produce 100% match rate."""
    truth = [0, 100, 200, 300]
    detected = np.array([1, 101, 199, 301])
    result = match_detections(detected, truth, 1e6, 10e-6)
    assert result.matched == 4
    assert result.false_alarms == 0
    assert result.missed == 0
    assert result.detection_rate == 1.0


def test_match_detections_with_false_alarms() -> None:
    """Extra detections count as false alarms."""
    truth = [100, 200]
    detected = np.array([50, 101, 199, 350])
    result = match_detections(detected, truth, 1e6, 10e-6)
    assert result.matched == 2
    assert result.false_alarms == 2
    assert result.missed == 0


def test_match_detections_with_misses() -> None:
    """Missing detections count as misses."""
    truth = [100, 200, 300, 400]
    detected = np.array([101, 301])
    result = match_detections(detected, truth, 1e6, 10e-6)
    assert result.matched == 2
    assert result.missed == 2
    assert result.false_alarms == 0


def test_match_detections_empty() -> None:
    """Empty inputs produce zero matches."""
    result = match_detections(np.array([], dtype=np.intp), [], 1e6, 10e-6)
    assert result.matched == 0
    assert result.detection_rate == 0.0
    assert result.mean_timing_error_s == 0.0
