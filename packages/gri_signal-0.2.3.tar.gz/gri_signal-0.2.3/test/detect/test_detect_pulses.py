"""Tests for threshold-based pulse detection."""

from __future__ import annotations

import numpy as np

from gri_signal.detect import detect_pulses


def _synth_pulse_train(
    n_samples: int,
    pulse_width: int,
    pri: int,
    amplitude: float = 1.0,
) -> np.ndarray:
    """Build a synthetic complex IQ pulse train (rectangular envelopes)."""
    iq = np.zeros(n_samples, dtype=np.complex64)
    pos = 0
    while pos + pulse_width <= n_samples:
        iq[pos : pos + pulse_width] = amplitude
        pos += pri
    return iq


def test_detect_pulses_finds_expected_count() -> None:
    """Detector finds every pulse in a clean train."""
    fs = 1e6
    pri_s = 1e-3
    pw_s = 10e-6
    duration_s = 10e-3
    iq = _synth_pulse_train(
        int(duration_s * fs),
        int(pw_s * fs),
        int(pri_s * fs),
    )
    peaks = detect_pulses(iq, fs, pri_s)
    expected = int(duration_s / pri_s)
    assert abs(len(peaks) - expected) <= 1


def test_detect_pulses_threshold_monotonic() -> None:
    """Higher threshold reduces detections; above-max admits none."""
    fs = 1e6
    iq = _synth_pulse_train(10_000, 10, 1000)
    high = detect_pulses(iq, fs, 1e-3, threshold_frac=0.8)
    low = detect_pulses(iq, fs, 1e-3, threshold_frac=0.2)
    assert len(low) >= len(high)

    none = detect_pulses(iq, fs, 1e-3, threshold_frac=1.01)
    assert len(none) == 0


def test_detect_pulses_respects_min_pri() -> None:
    """Peaks closer than pri/2 are suppressed."""
    fs = 1e6
    # Two pulses separated by pri=100 samples, min_pri=1ms=1000 samples so
    # distance threshold = 500 samples. Second pulse must be suppressed.
    iq = np.zeros(2000, dtype=np.complex64)
    iq[100:110] = 1.0
    iq[200:210] = 1.0
    peaks = detect_pulses(iq, fs, 1e-3)
    assert len(peaks) == 1


def test_detect_pulses_catches_boundary_pulses() -> None:
    """Pulses at sample 0 and at the final sample are still detected."""
    fs = 1e6
    iq = np.zeros(1000, dtype=np.complex64)
    iq[0:5] = 1.0
    iq[500:510] = 1.0
    iq[995:1000] = 1.0
    peaks = detect_pulses(iq, fs, 1e-4)
    assert len(peaks) == 3
