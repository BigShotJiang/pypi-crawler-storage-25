"""Tests for effective_duration function."""

from __future__ import annotations

import numpy as np
import pytest

from gri_signal import effective_duration


def test_effective_duration_gaussian_pulse() -> None:
    """Gaussian pulse RMS duration should be sigma/sqrt(2).

    For a Gaussian envelope exp(-t^2/(2*sigma^2)), the power is exp(-t^2/sigma^2).
    The RMS duration (sqrt of second moment) is sigma/sqrt(2).
    """
    fs = 10000
    n = 10000
    t = np.arange(n) / fs - 0.5  # Center at 0.5s

    sigma = 0.05  # 50 ms standard deviation
    pulse = np.exp(-(t**2) / (2 * sigma**2))

    dur = effective_duration(fs, pulse)

    # RMS duration of Gaussian power envelope is sigma/sqrt(2)
    expected_rms_dur = sigma / np.sqrt(2)
    assert abs(dur - expected_rms_dur) < 0.005


def test_effective_duration_wider_gaussian() -> None:
    """Wider Gaussian should have larger duration."""
    fs = 10000
    n = 20000
    t = np.arange(n) / fs - 1.0  # Center at 1.0s

    sigma_narrow = 0.05
    sigma_wide = 0.15

    pulse_narrow = np.exp(-(t**2) / (2 * sigma_narrow**2))
    pulse_wide = np.exp(-(t**2) / (2 * sigma_wide**2))

    dur_narrow = effective_duration(fs, pulse_narrow)
    dur_wide = effective_duration(fs, pulse_wide)

    # Wider pulse should have larger duration
    assert dur_wide > dur_narrow * 2


def test_effective_duration_rectangular_pulse() -> None:
    """Rectangular pulse duration should scale with pulse width."""
    fs = 10000
    n = 10000

    # Create rectangular pulses of different widths
    pulse_short = np.zeros(n)
    pulse_short[4000:4500] = 1.0  # 500 samples = 50 ms

    pulse_long = np.zeros(n)
    pulse_long[3000:5000] = 1.0  # 2000 samples = 200 ms

    dur_short = effective_duration(fs, pulse_short)
    dur_long = effective_duration(fs, pulse_long)

    # Longer pulse should have larger duration
    assert dur_long > dur_short * 2

    # RMS duration of rectangular pulse is width / sqrt(12)
    # For 50ms pulse: expected ~ 0.05 / sqrt(12) ~ 0.0144
    # But this depends on centering, so just check reasonable range
    assert 0.01 < dur_short < 0.05


def test_effective_duration_threshold_method() -> None:
    """Threshold method should give reasonable results."""
    fs = 10000
    n = 10000
    t = np.arange(n) / fs - 0.5

    sigma = 0.05
    pulse = np.exp(-(t**2) / (2 * sigma**2))

    dur_threshold = effective_duration(fs, pulse, method="threshold", threshold_db=-3.0)

    # -3dB in power means amplitude drops to 1/sqrt(2), which for Gaussian
    # envelope exp(-t^2/(2*sigma^2)) happens when t^2/(2*sigma^2) = ln(2)/2
    # So t = ±sigma * sqrt(ln(2)), giving 3dB duration = 2 * sigma * sqrt(ln(2))
    expected_3db_duration = 2 * sigma * np.sqrt(np.log(2))

    # Allow 15% tolerance due to discretization
    assert abs(dur_threshold - expected_3db_duration) / expected_3db_duration < 0.15


def test_effective_duration_complex_signal() -> None:
    """Should handle complex signals."""
    fs = 10000
    n = 10000
    t = np.arange(n) / fs - 0.5

    sigma = 0.05
    # Complex Gaussian pulse (with carrier)
    carrier_freq = 1000
    pulse = np.exp(-(t**2) / (2 * sigma**2)) * np.exp(1j * 2 * np.pi * carrier_freq * t)

    dur = effective_duration(fs, pulse)

    # Duration should be same as real Gaussian (carrier doesn't affect magnitude)
    # RMS duration is sigma/sqrt(2)
    expected_rms_dur = sigma / np.sqrt(2)
    assert abs(dur - expected_rms_dur) < 0.005


def test_effective_duration_zero_signal() -> None:
    """Zero signal should return zero duration."""
    fs = 10000
    sig = np.zeros(1000)

    dur = effective_duration(fs, sig)

    assert dur == 0.0


def test_effective_duration_invalid_method() -> None:
    """Invalid method should raise ValueError."""
    fs = 10000
    sig = np.random.default_rng(42).random(1000)

    with pytest.raises(ValueError, match="Unknown method"):
        effective_duration(fs, sig, method="invalid")


def test_effective_duration_chirp() -> None:
    """Linear chirp should have duration related to its time extent."""
    fs = 10000
    duration_s = 0.5
    n = int(duration_s * fs)
    t = np.arange(n) / fs

    # Linear FM chirp (windowed with Gaussian to have defined duration)
    sigma = 0.1
    window = np.exp(-((t - duration_s / 2) ** 2) / (2 * sigma**2))
    chirp_rate = 1000  # Hz/s
    chirp = window * np.exp(1j * np.pi * chirp_rate * t**2)

    dur = effective_duration(fs, chirp)

    # RMS duration should be close to sigma/sqrt(2) from the Gaussian window
    expected_rms_dur = sigma / np.sqrt(2)
    assert abs(dur - expected_rms_dur) < 0.01
