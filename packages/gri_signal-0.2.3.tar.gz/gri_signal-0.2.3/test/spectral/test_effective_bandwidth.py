"""Tests for effective_bandwidth function."""

from __future__ import annotations

import numpy as np
import pytest

from gri_signal import effective_bandwidth


def test_effective_bandwidth_gaussian_pulse() -> None:
    """Gaussian pulse RMS bandwidth = 1/(2*pi*sigma) * sqrt(2).

    For a Gaussian envelope exp(-t^2/(2*sigma^2)), the Fourier transform is also
    Gaussian with frequency-domain sigma_f = 1/(2*pi*sigma_t).
    The RMS bandwidth (sqrt of second moment of power spectrum) is sigma_f/sqrt(2).
    Combined: RMS_bw = 1/(2*pi*sigma_t*sqrt(2))
    """
    fs = 100000  # High sample rate for better frequency resolution
    n = 100000
    t = np.arange(n) / fs - 0.5

    sigma_t = 0.01  # 10 ms standard deviation in time
    pulse = np.exp(-(t**2) / (2 * sigma_t**2))

    bw = effective_bandwidth(fs, pulse)

    # RMS bandwidth of power spectrum: sigma_f/sqrt(2) where sigma_f = 1/(2*pi*sigma_t)
    expected_bw = 1 / (2 * np.pi * sigma_t * np.sqrt(2))

    # Allow 15% tolerance due to discretization effects
    assert abs(bw - expected_bw) / expected_bw < 0.15


def test_effective_bandwidth_narrower_gaussian() -> None:
    """Narrower (shorter) Gaussian should have larger bandwidth."""
    fs = 100000
    n = 100000
    t = np.arange(n) / fs - 0.5

    sigma_narrow = 0.005  # 5 ms - shorter pulse
    sigma_wide = 0.02  # 20 ms - longer pulse

    pulse_narrow = np.exp(-(t**2) / (2 * sigma_narrow**2))
    pulse_wide = np.exp(-(t**2) / (2 * sigma_wide**2))

    bw_narrow = effective_bandwidth(fs, pulse_narrow)
    bw_wide = effective_bandwidth(fs, pulse_wide)

    # Shorter pulse should have larger bandwidth (time-frequency uncertainty)
    assert bw_narrow > bw_wide * 2


def test_effective_bandwidth_pure_tone() -> None:
    """Pure tone RMS bandwidth is affected by its center frequency.

    For a real sinusoid at frequency f, the spectrum has peaks at ±f.
    The RMS bandwidth computed from center of mass will be dominated
    by the distance to these peaks, resulting in bw ≈ freq for real signals.
    """
    fs = 10000
    n = 100000  # Long signal for narrow bandwidth
    t = np.arange(n) / fs

    freq = 1000
    tone = np.sin(2 * np.pi * freq * t)

    bw = effective_bandwidth(fs, tone)

    # For a real sinusoid at freq, RMS bandwidth ≈ freq (distance from DC to peak)
    # This is because power is split between +freq and -freq
    assert abs(bw - freq) / freq < 0.1


def test_effective_bandwidth_threshold_method() -> None:
    """Threshold method should give reasonable results."""
    fs = 100000
    n = 100000
    t = np.arange(n) / fs - 0.5

    sigma_t = 0.01
    pulse = np.exp(-(t**2) / (2 * sigma_t**2))

    bw_threshold = effective_bandwidth(
        fs,
        pulse,
        method="threshold",
        threshold_db=-3.0,
    )

    # 3dB bandwidth: power spectrum is Gaussian with sigma_f = 1/(2*pi*sigma_t)
    # -3dB in power means |H|^2 drops to 0.5, so exp(-f^2/sigma_f^2) = 0.5
    # f = sigma_f * sqrt(ln(2)), so 3dB BW = 2 * sigma_f * sqrt(ln(2))
    sigma_f = 1 / (2 * np.pi * sigma_t)
    expected_3db_bw = 2 * sigma_f * np.sqrt(np.log(2))

    # Allow 20% tolerance
    assert abs(bw_threshold - expected_3db_bw) / expected_3db_bw < 0.25


def test_effective_bandwidth_complex_signal() -> None:
    """Complex signal with carrier: RMS bandwidth measures envelope spread.

    For a complex exponential at carrier_freq modulated by Gaussian envelope,
    the spectrum is centered at carrier_freq. The RMS bandwidth is computed
    about the spectral center of mass (central moment), so it measures the
    spread of the envelope, not distance from DC.
    """
    fs = 100000
    n = 100000
    t = np.arange(n) / fs - 0.5

    sigma_t = 0.01
    carrier_freq = 10000
    pulse = np.exp(-(t**2) / (2 * sigma_t**2)) * np.exp(
        1j * 2 * np.pi * carrier_freq * t,
    )

    bw = effective_bandwidth(fs, pulse)

    # RMS bandwidth of power spectrum: sigma_f/sqrt(2) where sigma_f = 1/(2*pi*sigma_t)
    # Same as baseband Gaussian - carrier just shifts center, doesn't change spread
    expected_bw = 1 / (2 * np.pi * sigma_t * np.sqrt(2))

    # Allow 15% tolerance due to discretization
    assert abs(bw - expected_bw) / expected_bw < 0.15


def test_effective_bandwidth_zero_signal() -> None:
    """Zero signal should return zero bandwidth."""
    fs = 10000
    sig = np.zeros(1000)

    bw = effective_bandwidth(fs, sig)

    assert bw == 0.0


def test_effective_bandwidth_invalid_method() -> None:
    """Invalid method should raise ValueError."""
    fs = 10000
    sig = np.random.default_rng(42).random(1000)

    with pytest.raises(ValueError, match="Unknown method"):
        effective_bandwidth(fs, sig, method="invalid")


def test_effective_bandwidth_chirp() -> None:
    """Linear chirp should have bandwidth related to frequency sweep."""
    fs = 10000
    duration_s = 0.5
    n = int(duration_s * fs)
    t = np.arange(n) / fs

    # Linear FM chirp sweeping 500 Hz
    bw_sweep = 500  # Hz
    chirp = np.exp(1j * np.pi * (bw_sweep / duration_s) * t**2)

    bw = effective_bandwidth(fs, chirp)

    # RMS bandwidth of linear chirp is approximately sweep_bandwidth / sqrt(12)
    # for a rectangular envelope
    expected_rms_bw = bw_sweep / np.sqrt(12)

    # Allow generous tolerance due to edge effects
    assert abs(bw - expected_rms_bw) / expected_rms_bw < 0.3


def test_effective_bandwidth_wideband_noise() -> None:
    """Wideband noise should have large bandwidth."""
    fs = 10000
    n = 10000

    rng = np.random.default_rng(42)
    noise = rng.standard_normal(n)

    bw = effective_bandwidth(fs, noise)

    # White noise RMS bandwidth is approximately fs / (2 * sqrt(3))
    # for frequency range [-fs/2, fs/2]
    expected_rms_bw = fs / (2 * np.sqrt(3))

    # Allow 20% tolerance
    assert abs(bw - expected_rms_bw) / expected_rms_bw < 0.2
