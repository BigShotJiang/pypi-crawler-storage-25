"""Tests for estimate_snr function."""

from __future__ import annotations

import numpy as np

from gri_signal import estimate_snr


def test_estimate_snr_high_snr() -> None:
    """High SNR signal should return high SNR estimate."""
    fs = 10000
    n = 10000
    t = np.arange(n) / fs
    freq = 1000

    # Pure tone (very high SNR)
    signal = np.sin(2 * np.pi * freq * t)
    snr = estimate_snr(fs, signal, signal_bw=100, signal_center=freq)

    # Should be very high (>40 dB for pure tone)
    assert snr > 40


def test_estimate_snr_with_noise() -> None:
    """SNR estimate should increase with better actual SNR."""
    fs = 10000
    n = 100000
    t = np.arange(n) / fs
    freq = 1000

    rng = np.random.default_rng(42)
    signal = np.sin(2 * np.pi * freq * t)

    # High SNR signal
    high_snr_noise = rng.normal(0, 0.01, n)
    high_snr_signal = signal + high_snr_noise

    # Low SNR signal
    low_snr_noise = rng.normal(0, 0.1, n)
    low_snr_signal = signal + low_snr_noise

    snr_high = estimate_snr(fs, high_snr_signal, signal_bw=100, signal_center=freq)
    snr_low = estimate_snr(fs, low_snr_signal, signal_bw=100, signal_center=freq)

    # Higher actual SNR should give higher estimated SNR
    assert snr_high > snr_low
    assert snr_high > 20  # Should be reasonably high
    assert snr_low < snr_high - 10  # Should be noticeably lower


def test_estimate_snr_auto_detect() -> None:
    """Auto-detection of signal bandwidth should work."""
    fs = 10000
    n = 10000
    t = np.arange(n) / fs
    freq = 1000

    signal = np.sin(2 * np.pi * freq * t)

    # Without specifying bandwidth
    snr = estimate_snr(fs, signal)

    # Should still get high SNR for pure tone
    assert snr > 30


def test_estimate_snr_complex_signal() -> None:
    """Should handle complex signals."""
    fs = 10000
    n = 10000
    t = np.arange(n) / fs
    freq = 1000

    # Complex exponential
    signal = np.exp(1j * 2 * np.pi * freq * t)
    snr = estimate_snr(fs, signal, signal_bw=100, signal_center=freq)

    # Should be very high for pure tone
    assert snr > 40


def test_estimate_snr_monotonic_with_noise_level() -> None:
    """SNR estimate should decrease monotonically as noise increases."""
    fs = 10000
    n = 50000
    t = np.arange(n) / fs
    freq = 1000

    rng = np.random.default_rng(123)
    signal = np.sin(2 * np.pi * freq * t)

    noise_levels = [0.01, 0.03, 0.1, 0.3]
    snr_estimates = []

    for noise_std in noise_levels:
        noise = rng.normal(0, noise_std, n)
        noisy = signal + noise
        snr = estimate_snr(fs, noisy, signal_bw=100, signal_center=freq)
        snr_estimates.append(snr)

    # SNR should decrease as noise increases
    for i in range(len(snr_estimates) - 1):
        assert snr_estimates[i] > snr_estimates[i + 1]


def test_estimate_snr_different_frequencies() -> None:
    """SNR estimation should work at different signal frequencies."""
    fs = 10000
    n = 10000
    t = np.arange(n) / fs

    rng = np.random.default_rng(456)
    noise = rng.normal(0, 0.05, n)

    for freq in [500, 1000, 2000, 3000]:
        signal = np.sin(2 * np.pi * freq * t)
        noisy = signal + noise
        snr = estimate_snr(fs, noisy, signal_bw=100, signal_center=freq)

        # Should get reasonable SNR at any frequency below Nyquist
        assert snr > 15
