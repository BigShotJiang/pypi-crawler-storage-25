"""Tests for estimate_tbp function."""

from __future__ import annotations

import numpy as np

from gri_signal import effective_bandwidth, effective_duration, estimate_tbp


def test_estimate_tbp_gaussian_minimum() -> None:
    """Gaussian pulse should achieve near-minimum TBP (Gabor limit)."""
    fs = 100000
    n = 100000
    t = np.arange(n) / fs - 0.5

    sigma = 0.01  # 10 ms
    pulse = np.exp(-(t**2) / (2 * sigma**2))

    tbp = estimate_tbp(fs, pulse)

    # Gabor limit is 1/(4*pi) ≈ 0.0796
    gabor_limit = 1 / (4 * np.pi)

    # Gaussian should be close to the minimum
    assert tbp < gabor_limit * 1.5  # Allow 50% above minimum
    assert tbp > gabor_limit * 0.8  # But not below (shouldn't be possible)


def test_estimate_tbp_equals_product() -> None:
    """TBP should equal duration * bandwidth."""
    fs = 10000
    n = 10000
    t = np.arange(n) / fs - 0.5

    sigma = 0.05
    pulse = np.exp(-(t**2) / (2 * sigma**2))

    tbp = estimate_tbp(fs, pulse)
    dur = effective_duration(fs, pulse)
    bw = effective_bandwidth(fs, pulse)

    # Should be exactly equal
    assert abs(tbp - dur * bw) < 1e-10


def test_estimate_tbp_chirp_large() -> None:
    """Linear chirp should have larger TBP than simple pulse."""
    fs = 10000
    duration_s = 0.5
    n = int(duration_s * fs)
    t = np.arange(n) / fs

    # Linear FM chirp with significant frequency sweep
    bw_sweep = 1000  # Hz
    chirp = np.exp(1j * np.pi * (bw_sweep / duration_s) * t**2)

    tbp = estimate_tbp(fs, chirp)

    # For rectangular envelope, RMS duration ≈ duration/sqrt(12)
    # and RMS bandwidth ≈ bw_sweep/sqrt(12)
    # So TBP ≈ duration * bw_sweep / 12 ≈ 0.5 * 1000 / 12 ≈ 41.7
    expected_tbp = duration_s * bw_sweep / 12

    # Should be in the right ballpark
    assert abs(tbp - expected_tbp) / expected_tbp < 0.3
    # And significantly larger than Gabor limit
    assert tbp > 10


def test_estimate_tbp_threshold_method() -> None:
    """Threshold method should also give valid TBP."""
    fs = 100000
    n = 100000
    t = np.arange(n) / fs - 0.5

    sigma = 0.01
    pulse = np.exp(-(t**2) / (2 * sigma**2))

    tbp_rms = estimate_tbp(fs, pulse, method="rms")
    tbp_threshold = estimate_tbp(fs, pulse, method="threshold", threshold_db=-3.0)

    # Threshold method typically gives larger TBP than RMS method
    # Both should be reasonable
    assert tbp_rms > 0
    assert tbp_threshold > 0

    # For Gaussian, 3dB TBP ≈ 0.44 (different from RMS definition)
    assert tbp_threshold > tbp_rms  # 3dB definition gives larger values


def test_estimate_tbp_increases_with_chirp_rate() -> None:
    """TBP should increase with chirp rate (bandwidth)."""
    fs = 10000
    duration_s = 0.5
    n = int(duration_s * fs)
    t = np.arange(n) / fs

    tbp_values = []
    for bw_sweep in [100, 500, 1000, 2000]:
        chirp = np.exp(1j * np.pi * (bw_sweep / duration_s) * t**2)
        tbp = estimate_tbp(fs, chirp)
        tbp_values.append(tbp)

    # TBP should increase with bandwidth
    for i in range(len(tbp_values) - 1):
        assert tbp_values[i + 1] > tbp_values[i]


def test_estimate_tbp_pure_tone() -> None:
    """Pure tone TBP is large due to long duration and spectral spread.

    For a real sinusoid, power is at ±freq, giving RMS bandwidth ≈ freq.
    Combined with long RMS duration, TBP is large.
    """
    fs = 10000
    n = 100000  # Long signal
    t = np.arange(n) / fs

    freq = 1000
    tone = np.sin(2 * np.pi * freq * t)

    tbp = estimate_tbp(fs, tone)

    # RMS duration ≈ duration/sqrt(12) for uniform envelope
    # RMS bandwidth ≈ freq for real sinusoid (distance to spectral peaks)
    # TBP should be large
    rms_duration = (n / fs) / np.sqrt(12)
    expected_tbp = rms_duration * freq

    assert abs(tbp - expected_tbp) / expected_tbp < 0.1


def test_estimate_tbp_windowed_tone() -> None:
    """Windowed real tone has TBP dominated by carrier frequency.

    For a real sinusoid at freq windowed by Gaussian, the RMS bandwidth
    is dominated by the carrier frequency (distance from DC to ±freq peaks),
    similar to the pure tone case. Duration is controlled by window.
    """
    fs = 10000
    n = 10000
    t = np.arange(n) / fs - 0.5

    freq = 1000
    sigma = 0.1
    windowed_tone = np.sin(2 * np.pi * freq * t) * np.exp(
        -(t**2) / (2 * sigma**2),
    )

    tbp = estimate_tbp(fs, windowed_tone)

    # RMS duration ≈ sigma/sqrt(2) from Gaussian window
    # RMS bandwidth ≈ freq (distance to spectral peaks at ±1000 Hz)
    expected_duration = sigma / np.sqrt(2)
    expected_tbp = expected_duration * freq

    # Should be in ballpark (some tolerance for interaction effects)
    assert abs(tbp - expected_tbp) / expected_tbp < 0.2


def test_estimate_tbp_complex_gaussian() -> None:
    """Complex Gaussian should still achieve near-minimum TBP."""
    fs = 100000
    n = 100000
    t = np.arange(n) / fs - 0.5

    sigma = 0.01
    carrier_freq = 10000
    pulse = np.exp(-(t**2) / (2 * sigma**2)) * np.exp(
        1j * 2 * np.pi * carrier_freq * t,
    )

    tbp = estimate_tbp(fs, pulse)

    # Should still be near Gabor limit
    gabor_limit = 1 / (4 * np.pi)
    assert tbp < gabor_limit * 1.5


def test_estimate_tbp_zero_signal() -> None:
    """Zero signal should return zero TBP."""
    fs = 10000
    sig = np.zeros(1000)

    tbp = estimate_tbp(fs, sig)

    assert tbp == 0.0


def test_estimate_tbp_pulse_compression_ratio() -> None:
    """TBP should approximate achievable pulse compression ratio."""
    fs = 10000
    duration_s = 0.1  # 100 ms pulse
    n = int(duration_s * fs)
    t = np.arange(n) / fs

    # Chirp with 500 Hz bandwidth
    bw_sweep = 500
    chirp = np.exp(1j * np.pi * (bw_sweep / duration_s) * t**2)

    tbp = estimate_tbp(fs, chirp)

    # For rectangular envelope:
    # RMS duration ≈ duration/sqrt(12)
    # RMS bandwidth ≈ bw_sweep/sqrt(12)
    # TBP ≈ duration * bw_sweep / 12 = 0.1 * 500 / 12 ≈ 4.17
    expected_tbp = duration_s * bw_sweep / 12

    # Verify TBP is close to expected
    assert abs(tbp - expected_tbp) / expected_tbp < 0.3
