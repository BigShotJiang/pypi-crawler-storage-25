"""Tests for thd (Total Harmonic Distortion) function."""

from __future__ import annotations

import numpy as np
import pytest

from gri_signal import thd


def test_thd_pure_tone() -> None:
    """Pure tone should have very low THD."""
    fs = 48000
    n = 48000
    t = np.arange(n) / fs
    freq = 1000

    signal = np.sin(2 * np.pi * freq * t)
    thd_db = thd(fs, signal, fundamental_freq=freq)

    # Pure tone has negligible harmonics (numerical noise only)
    assert thd_db < -60


def test_thd_with_second_harmonic() -> None:
    """THD should reflect added harmonic level."""
    fs = 48000
    n = 48000
    t = np.arange(n) / fs
    freq = 1000

    fundamental = np.sin(2 * np.pi * freq * t)

    # Add 2nd harmonic at -20 dB (10% amplitude)
    harmonic_amplitude = 0.1
    with_harmonic = fundamental + harmonic_amplitude * np.sin(2 * np.pi * 2 * freq * t)

    thd_db = thd(fs, with_harmonic, fundamental_freq=freq)

    # THD should be approximately -20 dB (10% = -20 dB)
    assert -25 < thd_db < -15


def test_thd_with_multiple_harmonics() -> None:
    """THD should increase with more harmonics."""
    fs = 48000
    n = 48000
    t = np.arange(n) / fs
    freq = 1000

    fundamental = np.sin(2 * np.pi * freq * t)

    # Just 2nd harmonic
    one_harmonic = fundamental + 0.1 * np.sin(2 * np.pi * 2 * freq * t)
    thd_one = thd(fs, one_harmonic, fundamental_freq=freq)

    # 2nd and 3rd harmonics
    two_harmonics = one_harmonic + 0.1 * np.sin(2 * np.pi * 3 * freq * t)
    thd_two = thd(fs, two_harmonics, fundamental_freq=freq)

    # More harmonics = higher THD
    assert thd_two > thd_one


def test_thd_clipped_signal() -> None:
    """Clipped signal should have high THD."""
    fs = 48000
    n = 48000
    t = np.arange(n) / fs
    freq = 1000

    pure = np.sin(2 * np.pi * freq * t)
    clipped = np.clip(pure * 2, -1, 1)

    thd_pure = thd(fs, pure, fundamental_freq=freq)
    thd_clipped = thd(fs, clipped, fundamental_freq=freq)

    # Clipping introduces odd harmonics
    assert thd_clipped > thd_pure
    assert thd_clipped > -20  # Significant distortion


def test_thd_auto_detect_fundamental() -> None:
    """THD should auto-detect fundamental frequency."""
    fs = 48000
    n = 48000
    t = np.arange(n) / fs
    freq = 1000

    signal = np.sin(2 * np.pi * freq * t) + 0.1 * np.sin(2 * np.pi * 2 * freq * t)

    # Without specifying fundamental
    thd_auto = thd(fs, signal)

    # With specifying fundamental
    thd_specified = thd(fs, signal, fundamental_freq=freq)

    # Should be similar
    assert abs(thd_auto - thd_specified) < 3


def test_thd_num_harmonics_parameter() -> None:
    """Changing num_harmonics should affect result with many harmonics."""
    fs = 48000
    n = 48000
    t = np.arange(n) / fs
    freq = 1000

    # Signal with many harmonics (square-ish wave)
    signal = np.sin(2 * np.pi * freq * t)
    for h in range(2, 8):
        signal += (0.1 / h) * np.sin(2 * np.pi * h * freq * t)

    thd_3 = thd(fs, signal, fundamental_freq=freq, num_harmonics=3)
    thd_6 = thd(fs, signal, fundamental_freq=freq, num_harmonics=6)

    # More harmonics included = higher THD
    assert thd_6 > thd_3


@pytest.mark.parametrize(
    ("harmonic_level", "expected_thd_range"),
    [
        (0.01, (-45, -35)),  # 1% = -40 dB
        (0.1, (-25, -15)),  # 10% = -20 dB
        (0.316, (-15, -5)),  # ~31.6% = -10 dB
    ],
)
def test_thd_harmonic_levels(
    harmonic_level: float,
    expected_thd_range: tuple[float, float],
) -> None:
    """THD should match expected level for known harmonic amplitude."""
    fs = 48000
    n = 48000
    t = np.arange(n) / fs
    freq = 1000

    fundamental = np.sin(2 * np.pi * freq * t)
    with_harmonic = fundamental + harmonic_level * np.sin(2 * np.pi * 2 * freq * t)

    thd_db = thd(fs, with_harmonic, fundamental_freq=freq)

    low, high = expected_thd_range
    assert low < thd_db < high
