"""Tests for estimate_noise_floor function."""

from __future__ import annotations

import numpy as np

from gri_signal import estimate_noise_floor


def test_estimate_noise_floor_pure_noise() -> None:
    """Noise floor of pure noise should match expected level."""
    fs = 10000
    n = 10000

    rng = np.random.default_rng(42)
    noise_amplitude = 0.1
    noise = rng.normal(0, noise_amplitude, n)

    floor = estimate_noise_floor(fs, noise)

    # Floor should be finite and negative (below 0 dB full scale)
    assert np.isfinite(floor)
    assert floor < 0


def test_estimate_noise_floor_with_tone() -> None:
    """Noise floor should be below signal peak."""
    fs = 10000
    n = 10000
    t = np.arange(n) / fs
    freq = 1000

    rng = np.random.default_rng(42)
    signal = np.sin(2 * np.pi * freq * t)
    noise = rng.normal(0, 0.01, n)
    noisy = signal + noise

    floor = estimate_noise_floor(fs, noisy)

    # Floor should be well below 0 dB (signal peak)
    assert floor < -30


def test_estimate_noise_floor_percentile_effect() -> None:
    """Higher percentile should give higher floor estimate."""
    fs = 10000
    n = 10000
    t = np.arange(n) / fs
    freq = 1000

    rng = np.random.default_rng(42)
    signal = np.sin(2 * np.pi * freq * t)
    noise = rng.normal(0, 0.1, n)
    noisy = signal + noise

    floor_10 = estimate_noise_floor(fs, noisy, percentile=10)
    floor_50 = estimate_noise_floor(fs, noisy, percentile=50)

    # Higher percentile includes more of spectrum, so higher estimate
    assert floor_50 > floor_10


def test_estimate_noise_floor_exclude_dc() -> None:
    """DC exclusion should affect result for signals with large DC offset."""
    fs = 10000
    n = 10000

    rng = np.random.default_rng(42)
    # Signal with large DC component relative to noise
    # Use percentile=90 to ensure DC bin is included when not excluded
    signal = 10 + rng.normal(0, 0.1, n)

    floor_with_dc = estimate_noise_floor(fs, signal, exclude_dc=False, percentile=90)
    floor_no_dc = estimate_noise_floor(fs, signal, exclude_dc=True, percentile=90)

    # With DC included at high percentile, floor should be higher
    assert floor_with_dc > floor_no_dc


def test_estimate_noise_floor_scales_with_noise() -> None:
    """Noise floor should scale with noise amplitude (10x noise = +20 dB)."""
    fs = 10000
    n = 10000

    rng = np.random.default_rng(42)

    noise_low = rng.normal(0, 0.01, n)
    noise_high = rng.normal(0, 0.1, n)

    floor_low = estimate_noise_floor(fs, noise_low, percentile=50)
    floor_high = estimate_noise_floor(fs, noise_high, percentile=50)

    # 10x amplitude = 20 dB difference (within some tolerance)
    diff = floor_high - floor_low
    assert 15 < diff < 25  # Should be ~20 dB


def test_estimate_noise_floor_monotonic_with_noise() -> None:
    """Noise floor should increase monotonically with noise level."""
    fs = 10000
    n = 10000

    rng = np.random.default_rng(42)
    noise_levels = [0.001, 0.01, 0.1, 1.0]
    floors = []

    for level in noise_levels:
        noise = rng.normal(0, level, n)
        floor = estimate_noise_floor(fs, noise, percentile=50)
        floors.append(floor)

    # Each floor should be higher than the previous
    for i in range(len(floors) - 1):
        assert floors[i] < floors[i + 1]
