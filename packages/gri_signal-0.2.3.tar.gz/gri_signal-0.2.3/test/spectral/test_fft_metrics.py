"""Tests for FFT spectral metrics functions.

Functional tests for get_psd, get_max_power, get_psd_power, and get_freq_idx.
"""

from __future__ import annotations

import numpy as np
import pytest

from gri_signal import get_freq_idx, get_max_power, get_psd, get_psd_power

# -----------------------------------------------------------------------------
# PSD computation - single channel
# -----------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("freq", "fs", "description"),
    [
        (15, 100, "15 Hz tone at 100 Hz sample rate"),
        (25, 200, "25 Hz tone at 200 Hz sample rate"),
        (50, 500, "50 Hz tone at 500 Hz sample rate"),
    ],
)
def test_psd_single_channel_real(freq: int, fs: int, description: str) -> None:
    """Verify PSD correctly identifies dominant frequency in real signal."""
    t = np.arange(0, 100, 1 / fs)
    sig = 10 * np.sin(2 * np.pi * freq * t)

    psd, freqs = get_psd(fs, sig)

    # Power at signal frequency should be positive (dB above reference)
    f_pow = get_psd_power(freq, psd, freqs)
    assert f_pow > 0, description

    # get_max_power should find correct frequency
    max_pow, max_freq = get_max_power(fs, sig)
    assert max_freq == pytest.approx(freq), description
    assert max_pow == pytest.approx(f_pow, abs=1), description


def test_psd_single_channel_complex() -> None:
    """Verify PSD correctly identifies dominant frequency in complex signal."""
    freq, fs = 15, 100
    t = np.arange(0, 100, 1 / fs)
    sig = 10 * np.exp(1j * 2 * np.pi * freq * t)

    max_pow, max_freq = get_max_power(fs, sig)

    assert max_freq == pytest.approx(freq)
    assert max_pow > 0


def test_psd_stopband_attenuation() -> None:
    """Verify frequencies outside signal have low power."""
    freq, fs = 15, 100
    t = np.arange(0, 100, 1 / fs)
    sig = 10 * np.sin(2 * np.pi * freq * t)

    psd, freqs = get_psd(fs, sig)
    signal_pow = get_psd_power(freq, psd, freqs)

    # Power at 2x and 0.5x signal frequency should be >60 dB below peak
    pow_2x = get_psd_power(freq * 2, psd, freqs)
    pow_half = get_psd_power(freq / 2, psd, freqs)
    assert pow_2x < signal_pow - 60
    assert pow_half < signal_pow - 60


# -----------------------------------------------------------------------------
# PSD computation - multi-channel
# -----------------------------------------------------------------------------


def test_psd_multi_channel() -> None:
    """Verify PSD handles multi-channel signals correctly."""
    freq1, freq2, fs = 15, 25, 100
    t = np.arange(0, 100, 1 / fs)
    sig = np.array(
        [
            10 * np.sin(2 * np.pi * freq1 * t),
            20 * np.sin(2 * np.pi * freq2 * t),
        ],
    )

    psd, freqs = get_psd(fs, sig)

    # Shape should be (channels, freq_bins)
    assert psd.shape == (2, len(freqs))
    assert freqs.ndim == 1

    # Channel 0 should have power at freq1, not freq2
    assert get_psd_power(freq1, psd[0], freqs) > 0
    assert get_psd_power(freq2, psd[0], freqs) < 0

    # Channel 1 should have power at freq2, not freq1
    assert get_psd_power(freq2, psd[1], freqs) > 0
    assert get_psd_power(freq1, psd[1], freqs) < 0


def test_psd_power_multi_channel_batch() -> None:
    """Verify get_psd_power handles multi-channel PSD input."""
    freq1, freq2, fs = 15, 25, 100
    t = np.arange(0, 100, 1 / fs)
    sig = np.array(
        [
            10 * np.sin(2 * np.pi * freq1 * t),
            20 * np.sin(2 * np.pi * freq2 * t),
        ],
    )

    psd, freqs = get_psd(fs, sig)

    # Query power at freq1 for all channels at once
    powers = get_psd_power(freq1, psd, freqs)
    assert isinstance(powers, np.ndarray)
    assert len(powers) == 2
    assert powers[0] > 0  # Channel 0 has freq1
    assert powers[1] < 0  # Channel 1 doesn't


def test_max_power_multi_channel() -> None:
    """Verify get_max_power returns per-channel results."""
    freq1, freq2, fs = 15, 25, 100
    t = np.arange(0, 100, 1 / fs)
    sig = np.array(
        [
            10 * np.sin(2 * np.pi * freq1 * t),
            20 * np.sin(2 * np.pi * freq2 * t),
        ],
    )

    result = get_max_power(fs, sig)

    assert result[0][1] == pytest.approx(freq1)
    assert result[1][1] == pytest.approx(freq2)


# -----------------------------------------------------------------------------
# Frequency index computation
# -----------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("freq", "fs", "n", "expected_idx", "description"),
    [
        (0, 30, 25, 12, "DC frequency"),
        (0, 30, 24, 12, "DC frequency even samples"),
        (2.5, 30, 24, 14, "Positive frequency"),
        (-2.5, 30, 24, 10, "Negative frequency"),
    ],
)
def test_freq_idx(
    freq: float,
    fs: int,
    n: int,
    expected_idx: int,
    description: str,
) -> None:
    """Verify frequency to bin index conversion."""
    idx = get_freq_idx(freq, fs, n)
    assert idx == expected_idx, description


def test_freq_idx_rounding() -> None:
    """Verify frequency index rounds to nearest bin."""
    # Just below bin boundary - should stay at bin 14
    assert get_freq_idx(2.5 + 1.24 / 2, 30, 24) == 14
    # Just above bin boundary - should round to bin 15
    assert get_freq_idx(2.5 + 1.26 / 2, 30, 24) == 15
