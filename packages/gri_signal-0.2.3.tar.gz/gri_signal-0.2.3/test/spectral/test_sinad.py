"""Tests for sinad function."""

from __future__ import annotations

import numpy as np
import pytest

from gri_signal import sinad


def test_sinad_pure_tone() -> None:
    """Pure tone should have very high SINAD."""
    fs = 48000
    n = 48000
    t = np.arange(n) / fs
    freq = 1000

    signal = np.sin(2 * np.pi * freq * t)
    sinad_db = sinad(fs, signal, fundamental_freq=freq)

    # Pure tone has almost no noise/distortion
    assert sinad_db > 50


def test_sinad_with_noise() -> None:
    """SINAD should decrease with added noise."""
    fs = 48000
    n = 48000
    t = np.arange(n) / fs
    freq = 1000

    rng = np.random.default_rng(42)
    signal = np.sin(2 * np.pi * freq * t)

    # High SNR
    noisy_high = signal + rng.normal(0, 0.01, n)
    sinad_high = sinad(fs, noisy_high, fundamental_freq=freq)

    # Low SNR
    noisy_low = signal + rng.normal(0, 0.1, n)
    sinad_low = sinad(fs, noisy_low, fundamental_freq=freq)

    # Higher noise = lower SINAD
    assert sinad_high > sinad_low
    assert sinad_high > 30
    assert sinad_low < 25


def test_sinad_with_harmonics() -> None:
    """SINAD should decrease with harmonic distortion."""
    fs = 48000
    n = 48000
    t = np.arange(n) / fs
    freq = 1000

    # Pure fundamental
    pure = np.sin(2 * np.pi * freq * t)
    sinad_pure = sinad(fs, pure, fundamental_freq=freq)

    # Add 2nd harmonic at -20 dB
    harmonic_level = 0.1
    with_harmonic = pure + harmonic_level * np.sin(2 * np.pi * 2 * freq * t)
    sinad_harmonic = sinad(fs, with_harmonic, fundamental_freq=freq)

    # Harmonics decrease SINAD
    assert sinad_pure > sinad_harmonic


def test_sinad_auto_detect_fundamental() -> None:
    """SINAD should auto-detect fundamental frequency."""
    fs = 48000
    n = 48000
    t = np.arange(n) / fs
    freq = 1000

    rng = np.random.default_rng(42)
    # Add small noise so SINAD is finite (pure tone gives inf)
    signal = np.sin(2 * np.pi * freq * t) + rng.normal(0, 0.01, n)

    # Without specifying fundamental
    sinad_auto = sinad(fs, signal)

    # With specifying fundamental
    sinad_specified = sinad(fs, signal, fundamental_freq=freq)

    # Should be similar
    assert abs(sinad_auto - sinad_specified) < 3


def test_sinad_clipped_signal() -> None:
    """Clipped signal should have lower SINAD due to distortion."""
    fs = 48000
    n = 48000
    t = np.arange(n) / fs
    freq = 1000

    pure = np.sin(2 * np.pi * freq * t)
    clipped = np.clip(pure * 2, -1, 1)

    sinad_pure = sinad(fs, pure, fundamental_freq=freq)
    sinad_clipped = sinad(fs, clipped, fundamental_freq=freq)

    # Clipping introduces harmonics
    assert sinad_pure > sinad_clipped


@pytest.mark.parametrize(
    "freq",
    [500, 1000, 2000, 5000],
)
def test_sinad_various_frequencies(freq: float) -> None:
    """SINAD should work at various frequencies."""
    fs = 48000
    n = 48000
    t = np.arange(n) / fs

    signal = np.sin(2 * np.pi * freq * t)
    sinad_db = sinad(fs, signal, fundamental_freq=freq)

    # Pure tone should have high SINAD at any frequency
    assert sinad_db > 50
