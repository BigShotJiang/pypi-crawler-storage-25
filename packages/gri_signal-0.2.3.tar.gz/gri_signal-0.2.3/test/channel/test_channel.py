"""Tests for channel effects."""

from __future__ import annotations

import numpy as np
import pytest

from gri_signal.channel import attenuation, awgn, delay, doppler, multipath


class TestDelay:
    """Tests for delay function."""

    @pytest.mark.parametrize(
        ("fs", "delay_time"),
        [
            (1000, 0.001),
            (10000, 0.0005),
            (44100, 0.01),
        ],
    )
    def test_delay_preserves_length(self, fs, delay_time):
        """Delay preserves signal length."""
        sig = np.exp(1j * 2 * np.pi * 100 * np.arange(1000) / fs)
        delayed = delay(sig, delay_time, fs)
        assert delayed.shape == sig.shape
        assert delayed.dtype == np.complex128

    def test_delay_shifts_signal(self):
        """Delay shifts signal in time."""
        fs = 1000
        t = np.arange(100) / fs
        sig = np.exp(1j * 2 * np.pi * 10 * t)
        delayed = delay(sig, 0.01, fs)
        # Delayed signal should differ from original
        assert not np.allclose(sig, delayed)

    def test_delay_zero_is_identity(self):
        """Zero delay returns original signal."""
        sig = np.exp(1j * 2 * np.pi * 100 * np.arange(100) / 1000)
        delayed = delay(sig, 0, 1000)
        assert np.allclose(sig, delayed)


class TestAwgn:
    """Tests for AWGN function."""

    @pytest.mark.parametrize("snr_db", [0, 10, 20, 30])
    def test_awgn_preserves_shape(self, snr_db):
        """AWGN preserves signal shape."""
        sig = np.exp(1j * 2 * np.pi * 100 * np.arange(1000) / 1000)
        noisy = awgn(sig, snr_db)
        assert noisy.shape == sig.shape

    def test_awgn_seed_reproducibility(self):
        """Same seed produces same noise."""
        sig = np.ones(100, dtype=complex)
        noisy1 = awgn(sig, 10, seed=42)
        noisy2 = awgn(sig, 10, seed=42)
        assert np.allclose(noisy1, noisy2)

    def test_awgn_adds_noise(self):
        """AWGN adds noise to signal."""
        sig = np.ones(1000, dtype=complex)
        noisy = awgn(sig, 10, seed=42)
        assert not np.allclose(sig, noisy)

    def test_awgn_higher_snr_less_noise(self):
        """Higher SNR means less noise."""
        sig = np.ones(10000, dtype=complex)
        noisy_low = awgn(sig, 0, seed=42)
        noisy_high = awgn(sig, 30, seed=42)
        noise_low = np.mean(np.abs(noisy_low - sig) ** 2)
        noise_high = np.mean(np.abs(noisy_high - sig) ** 2)
        assert noise_low > noise_high


class TestAttenuation:
    """Tests for attenuation function."""

    @pytest.mark.parametrize(
        ("db", "expected_scale"),
        [
            (0, 1.0),
            (6, 0.501),
            (20, 0.1),
            (-6, 1.995),
        ],
    )
    def test_attenuation_scales_correctly(self, db, expected_scale):
        """Attenuation scales signal correctly."""
        sig = np.ones(100)
        att = attenuation(sig, db)
        assert np.allclose(att, expected_scale, atol=0.01)

    def test_attenuation_preserves_shape(self):
        """Attenuation preserves signal shape."""
        rng = np.random.default_rng(42)
        sig = rng.standard_normal((4, 100)) + 1j * rng.standard_normal((4, 100))
        att = attenuation(sig, 10)
        assert att.shape == sig.shape


class TestDoppler:
    """Tests for Doppler frequency shift function."""

    @pytest.mark.parametrize(
        ("f_shift", "expected_freq"),
        [
            (100, 1100),  # Positive shift
            (-200, 800),  # Negative shift
            (0, 1000),  # Zero shift (identity)
        ],
    )
    def test_doppler_shifts_frequency(self, f_shift, expected_freq):
        """Doppler shifts signal frequency correctly."""
        fs = 10000
        f_sig = 1000
        n = 10000
        t = np.arange(n) / fs

        sig = np.exp(1j * 2 * np.pi * f_sig * t)
        shifted = doppler(sig, fs, f_shift)

        spectrum = np.abs(np.fft.fft(shifted))
        freqs = np.fft.fftfreq(n, 1 / fs)
        peak_freq = freqs[np.argmax(spectrum)]

        assert shifted.shape == sig.shape
        assert np.isclose(peak_freq, expected_freq, atol=fs / n)

    def test_doppler_with_rate(self):
        """Doppler with rate creates quadratic phase (chirp)."""
        fs = 10000
        n = 10000
        sig = np.ones(n, dtype=complex)

        shifted = doppler(sig, fs, 0.0, f_rate=100.0)

        # Phase should be quadratic (non-zero second derivative)
        phase = np.unwrap(np.angle(shifted))
        second_deriv = np.diff(phase, 2)
        assert np.mean(np.abs(second_deriv)) > 1e-6


class TestMultipath:
    """Tests for multipath channel function."""

    @pytest.mark.parametrize(
        ("delays", "amplitudes", "expected"),
        [
            ([0], [1.0], 1.0),  # Unity passthrough
            ([0], [0.5], 0.5),  # Attenuation
            ([0, 0], [0.5, 0.5], 1.0),  # Constructive
            ([0, 0], [1.0, -1.0], 0.0),  # Destructive
            ([0], [1j], 1j),  # Phase shift
        ],
    )
    def test_multipath_combines_paths(self, delays, amplitudes, expected):
        """Multipath combines paths correctly."""
        sig = np.ones(100, dtype=complex)
        result = multipath(sig, 1000, delays, amplitudes)
        assert result.shape == sig.shape
        assert np.allclose(result, expected, atol=1e-10)

    def test_multipath_delayed_path(self):
        """Delayed path modifies signal."""
        fs = 10000
        n = 1000
        sig = np.exp(1j * 2 * np.pi * 100 * np.arange(n) / fs)

        result = multipath(sig, fs, [0, 0.001], [1.0, 0.5])

        assert not np.allclose(sig, result)
