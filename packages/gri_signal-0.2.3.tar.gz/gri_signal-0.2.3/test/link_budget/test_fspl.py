"""Tests for free-space path loss."""

from __future__ import annotations

import pytest

from gri_signal.link_budget import fspl_db


@pytest.mark.parametrize(
    ("range_m", "freq_hz", "expected_db", "tol"),
    [
        # NEXRAD reference: 650 km at 2.85 GHz -> ~157.8 dB
        (650e3, 2.85e9, 157.8, 0.1),
        # Ground-based at 100 km, 2.85 GHz -> ~141.5 dB
        (100e3, 2.85e9, 141.5, 0.2),
        # 1 m at 1 GHz: 4*pi*1*1e9/3e8 = 41.9 -> 20*log10(41.9) = 32.4 dB
        (1.0, 1e9, 32.4, 0.2),
    ],
)
def test_fspl_db_known_values(
    range_m: float,
    freq_hz: float,
    expected_db: float,
    tol: float,
) -> None:
    """Verify FSPL against hand-computed values."""
    result = fspl_db(range_m, freq_hz)
    assert result == pytest.approx(expected_db, abs=tol)


def test_fspl_db_doubles_with_range() -> None:
    """Doubling range adds ~6 dB (inverse square law)."""
    loss1 = fspl_db(1000, 1e9)
    loss2 = fspl_db(2000, 1e9)
    assert loss2 - loss1 == pytest.approx(6.02, abs=0.01)


def test_fspl_db_doubles_with_freq() -> None:
    """Doubling frequency adds ~6 dB (aperture scaling)."""
    loss1 = fspl_db(1000, 1e9)
    loss2 = fspl_db(1000, 2e9)
    assert loss2 - loss1 == pytest.approx(6.02, abs=0.01)


@pytest.mark.parametrize("range_m", [0.0, -1.0])
def test_fspl_db_rejects_non_positive_range(range_m: float) -> None:
    """ValueError for non-positive range."""
    with pytest.raises(ValueError, match="range_m"):
        fspl_db(range_m, 1e9)


@pytest.mark.parametrize("freq_hz", [0.0, -1.0])
def test_fspl_db_rejects_non_positive_freq(freq_hz: float) -> None:
    """ValueError for non-positive frequency."""
    with pytest.raises(ValueError, match="freq_hz"):
        fspl_db(1000, freq_hz)
