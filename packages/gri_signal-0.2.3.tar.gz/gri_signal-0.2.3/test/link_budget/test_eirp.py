"""Tests for effective isotropic radiated power."""

from __future__ import annotations

import pytest

from gri_signal.link_budget import eirp_dbw


def test_eirp_reference() -> None:
    """700 kW + 10 dBi = 68.5 dBW."""
    assert eirp_dbw(700e3, 10.0) == pytest.approx(68.5, abs=0.1)


def test_eirp_rejects_non_positive_power() -> None:
    """ValueError for non-positive power."""
    with pytest.raises(ValueError, match="peak_power_w"):
        eirp_dbw(0.0, 10.0)
