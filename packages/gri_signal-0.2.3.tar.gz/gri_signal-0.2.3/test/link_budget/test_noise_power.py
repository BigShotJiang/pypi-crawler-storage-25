"""Tests for thermal noise power."""

from __future__ import annotations

import pytest

from gri_signal.link_budget import noise_power_dbw


def test_noise_power_nexrad_short_pulse() -> None:
    """T_sys=400 K, B=625 kHz -> ~-144.6 dBW."""
    assert noise_power_dbw(400.0, 625e3) == pytest.approx(-144.6, abs=0.1)


def test_noise_power_nexrad_long_pulse() -> None:
    """T_sys=400 K, B=204 kHz -> ~-149.5 dBW (~4.9 dB lower than short pulse)."""
    assert noise_power_dbw(400.0, 204e3) == pytest.approx(-149.5, abs=0.1)


def test_noise_power_scales_with_bandwidth() -> None:
    """Doubling bandwidth adds 3 dB."""
    n1 = noise_power_dbw(300.0, 1e6)
    n2 = noise_power_dbw(300.0, 2e6)
    assert n2 - n1 == pytest.approx(3.01, abs=0.01)


def test_noise_power_rejects_non_positive() -> None:
    """ValueError for non-positive inputs."""
    with pytest.raises(ValueError, match="noise_temp_k"):
        noise_power_dbw(0.0, 1e6)
    with pytest.raises(ValueError, match="bandwidth_hz"):
        noise_power_dbw(300.0, 0.0)
