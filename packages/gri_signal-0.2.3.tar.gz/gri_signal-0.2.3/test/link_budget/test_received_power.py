"""Tests for received power (direct and multipath)."""

from __future__ import annotations

import math

import pytest

from gri_signal.link_budget import (
    eirp_dbw,
    multipath_received_power_dbw,
    multipath_relative_db,
    received_power_dbw,
)


def test_received_power_nexrad_leo_reference() -> None:
    """Full NEXRAD-from-LEO scenario: P_rx = -89.8 dBW."""
    e = eirp_dbw(700e3, 10.0)
    p_rx = received_power_dbw(
        e,
        650e3,
        2.85e9,
        atmo_loss_db=0.5,
        collector_gain_dbi=0.0,
    )
    assert p_rx == pytest.approx(-89.8, abs=0.2)


def test_multipath_weaker_than_direct() -> None:
    """Multipath is always weaker (negative relative dB)."""
    rel = multipath_relative_db(650e3, 700e3, 2.85e9, 3.0)
    assert rel < 0


def test_multipath_relative_zero_reflection_loss() -> None:
    """With zero reflection loss, delta is only from path length."""
    direct = 100e3
    reflected = 110e3
    rel = multipath_relative_db(direct, reflected, 1e9, 0.0)
    expected = 20.0 * math.log10(direct / reflected)
    assert rel == pytest.approx(expected, abs=0.01)


def test_multipath_received_power_consistent() -> None:
    """Multipath received power equals direct power plus relative dB."""
    e = 68.5
    direct_range = 650e3
    reflected_total = 700e3
    freq = 2.85e9
    refl_loss = 5.0

    p_direct = received_power_dbw(e, direct_range, freq)
    p_mp = multipath_received_power_dbw(e, reflected_total, freq, refl_loss)
    rel = multipath_relative_db(direct_range, reflected_total, freq, refl_loss)

    assert p_mp - p_direct == pytest.approx(rel, abs=0.01)
