"""Tests for SNR from the link equation."""

from __future__ import annotations

import pytest

from gri_signal.link_budget import eirp_dbw, snr_db

# NEXRAD-from-LEO reference scenario
REF_PEAK_POWER_W = 700e3
REF_SIDELOBE_GAIN_DBI = 10.0
REF_FREQ_HZ = 2.85e9
REF_RANGE_M = 650e3
REF_NOISE_TEMP_K = 400.0
REF_BANDWIDTH_HZ = 625e3
REF_ATMO_LOSS_DB = 0.5


def test_snr_nexrad_leo_reference() -> None:
    """NEXRAD from LEO: expected SNR ~54.8 dB."""
    e = eirp_dbw(REF_PEAK_POWER_W, REF_SIDELOBE_GAIN_DBI)
    result = snr_db(
        e,
        REF_RANGE_M,
        REF_FREQ_HZ,
        REF_NOISE_TEMP_K,
        REF_BANDWIDTH_HZ,
        atmo_loss_db=REF_ATMO_LOSS_DB,
    )
    assert result == pytest.approx(54.8, abs=0.3)


def test_snr_with_collector_gain() -> None:
    """Adding 20 dBi collector gain adds 20 dB to SNR."""
    e = eirp_dbw(REF_PEAK_POWER_W, REF_SIDELOBE_GAIN_DBI)
    snr_omni = snr_db(
        e,
        REF_RANGE_M,
        REF_FREQ_HZ,
        REF_NOISE_TEMP_K,
        REF_BANDWIDTH_HZ,
    )
    snr_dish = snr_db(
        e,
        REF_RANGE_M,
        REF_FREQ_HZ,
        REF_NOISE_TEMP_K,
        REF_BANDWIDTH_HZ,
        collector_gain_dbi=20.0,
    )
    assert snr_dish - snr_omni == pytest.approx(20.0, abs=0.01)


def test_snr_long_pulse_higher() -> None:
    """Narrower bandwidth (long pulse) gives higher SNR."""
    e = eirp_dbw(REF_PEAK_POWER_W, REF_SIDELOBE_GAIN_DBI)
    snr_short = snr_db(e, REF_RANGE_M, REF_FREQ_HZ, REF_NOISE_TEMP_K, 625e3)
    snr_long = snr_db(e, REF_RANGE_M, REF_FREQ_HZ, REF_NOISE_TEMP_K, 204e3)
    assert snr_long > snr_short
    assert snr_long - snr_short == pytest.approx(4.9, abs=0.2)
