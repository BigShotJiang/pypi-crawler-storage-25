"""Tests for sampling functions."""

from __future__ import annotations

import numpy as np
import pytest

from gri_signal.sampling import adc


@pytest.mark.parametrize("n_bits", [8, 10, 12, 14, 16])
def test_adc_preserves_shape(n_bits):
    """ADC preserves signal shape."""
    rng = np.random.default_rng(42)
    sig = rng.standard_normal(1000) + 1j * rng.standard_normal(1000)
    quantized = adc(sig, n_bits)
    assert quantized.shape == sig.shape
    assert quantized.dtype == np.complex128


def test_adc_reduces_unique_values():
    """ADC reduces number of unique values."""
    rng = np.random.default_rng(42)
    sig = rng.standard_normal(10000) + 1j * rng.standard_normal(10000)
    quantized = adc(sig, 8)
    # Should have fewer unique values after quantization
    unique_orig = len(np.unique(sig.real))
    unique_quant = len(np.unique(quantized.real))
    assert unique_quant < unique_orig


def test_adc_more_bits_more_levels():
    """More bits means more quantization levels."""
    rng = np.random.default_rng(42)
    sig = rng.standard_normal(10000) + 1j * rng.standard_normal(10000)
    quant_8 = adc(sig, 8)
    quant_12 = adc(sig, 12)
    unique_8 = len(np.unique(quant_8.real))
    unique_12 = len(np.unique(quant_12.real))
    assert unique_12 > unique_8


def test_adc_constant_signal_unchanged():
    """Constant signal is unchanged by ADC."""
    sig = np.ones(100, dtype=complex) * (3 + 2j)
    quantized = adc(sig, 12)
    assert np.allclose(sig, quantized)
