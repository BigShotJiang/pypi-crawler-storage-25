"""Tests for normalized correlation coefficient."""

from __future__ import annotations

import numpy as np
import pytest

from gri_signal.correlation.ncc import ncc


def test_ncc_identical_signals() -> None:
    """Identical signals should give NCC ~= 1.0."""
    x = np.array([1.0, 2.0, 3.0, 4.0, 5.0])
    assert ncc(x, x) == pytest.approx(1.0, abs=1e-6)


def test_ncc_independent_noise() -> None:
    """Independent noise signals should give NCC near 0."""
    rng = np.random.default_rng(42)
    x = rng.standard_normal(1000)
    y = rng.standard_normal(1000)
    assert ncc(x, y) < 0.1


def test_ncc_delayed_copy() -> None:
    """Signal vs delayed copy should give NCC ~= 1.0."""
    rng = np.random.default_rng(99)
    x = rng.standard_normal(200)
    y = np.zeros_like(x)
    y[10:] = x[:-10]  # Delay by 10 samples
    # Energy is slightly reduced by truncation, but NCC should be high
    assert ncc(x, y) > 0.9


def test_ncc_scale_invariant() -> None:
    """NCC should be unchanged when one signal is scaled."""
    x = np.array([1.0, 2.0, 3.0, 4.0, 5.0])
    assert ncc(x, 10.0 * x) == pytest.approx(ncc(x, x), abs=1e-6)


def test_ncc_complex_signals() -> None:
    """NCC works with complex signals."""
    rng = np.random.default_rng(7)
    x = rng.standard_normal(100) + 1j * rng.standard_normal(100)
    assert ncc(x, x) == pytest.approx(1.0, abs=1e-6)
