"""Tests for quadratic interpolation function.

Functional tests verifying qint correctly finds sub-sample peak locations.
"""

from __future__ import annotations

import numpy as np
import pytest

from gri_signal import qint

# -----------------------------------------------------------------------------
# Basic quadratic interpolation
# -----------------------------------------------------------------------------


def test_qint_basic() -> None:
    """Verify quadratic interpolation with known values."""
    x = np.array([1, 2, 3])
    y = np.array([1, 2, 4])

    xm, ym, a = qint(x, y)

    assert xm == pytest.approx(0.5)
    assert ym == pytest.approx(0.875)
    assert a == pytest.approx(0.5)


def test_qint_asymmetric_peak() -> None:
    """Verify asymmetric peak locations are computed correctly."""
    x = np.array([1, 2, 3])

    # Peak shifted left - center value highest, left > right
    y_left = np.array([2, 3, 1])
    xm_left, _, _ = qint(x, y_left)
    assert xm_left < 2.0  # Peak should be left of center

    # Peak shifted right - center value highest, right > left
    y_right = np.array([1, 3, 2])
    xm_right, _, _ = qint(x, y_right)
    assert xm_right > 2.0  # Peak should be right of center


def test_qint_symmetric_parabola() -> None:
    """Verify symmetric parabola has peak exactly at center."""
    x = np.array([-1, 0, 1])
    y = np.array([0, 1, 0])  # Peak at x=0

    xm, ym, a = qint(x, y)

    assert xm == pytest.approx(0.0)
    assert ym == pytest.approx(1.0)
    assert a < 0  # Downward parabola


def test_qint_curvature_sign() -> None:
    """Verify curvature coefficient sign indicates parabola direction."""
    x = np.array([0, 1, 2])

    # Upward parabola (minimum)
    y_up = np.array([4, 1, 4])
    _, _, a_up = qint(x, y_up)
    assert a_up > 0

    # Downward parabola (maximum)
    y_down = np.array([0, 3, 0])
    _, _, a_down = qint(x, y_down)
    assert a_down < 0
