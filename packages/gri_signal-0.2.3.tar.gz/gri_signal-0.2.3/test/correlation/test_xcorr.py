"""Tests for cross-correlation function.

Functional tests verifying xcorr correctly computes MATLAB-style cross-correlation.
"""

from __future__ import annotations

import numpy as np
import pytest

from gri_signal import xcorr

# -----------------------------------------------------------------------------
# Basic cross-correlation
# -----------------------------------------------------------------------------


def test_xcorr_basic() -> None:
    """Verify cross-correlation with known values."""
    x = np.array([1, 2, 3, 4, 5, 6, 7])
    y = np.array([0, 0, 1, 2, 3, 4, 5])

    corr = xcorr(x, y, max_lags=3)

    expected = [40, 55, 70, 85, 60, 38, 20]
    assert corr.tolist() == pytest.approx(expected)


@pytest.mark.parametrize(
    ("max_lags", "expected_len", "description"),
    [
        (0, 1, "Zero lag only"),
        (2, 5, "Two lags"),
        (5, 11, "Five lags"),
    ],
)
def test_xcorr_output_length(
    max_lags: int,
    expected_len: int,
    description: str,
) -> None:
    """Verify output length matches 2*max_lags + 1."""
    x = np.array([1, 2, 3, 4, 5, 6, 7])
    y = np.array([0, 0, 1, 2, 3, 4, 5])

    corr = xcorr(x, y, max_lags=max_lags)

    assert len(corr) == expected_len, description


def test_xcorr_autocorrelation() -> None:
    """Verify autocorrelation has symmetric output with max at center."""
    x = np.array([1, 2, 3, 4, 5])

    corr = xcorr(x, x, max_lags=2)

    # Autocorrelation should be symmetric
    assert corr[0] == pytest.approx(corr[-1])
    assert corr[1] == pytest.approx(corr[-2])

    # Max should be at center (zero lag)
    center = len(corr) // 2
    assert corr[center] == max(corr)


def test_xcorr_peak_detection() -> None:
    """Verify peak is at center for aligned signals."""
    x = np.array([1, 2, 3, 4, 5])
    y = np.array([1, 2, 3, 4, 5])  # Identical signal

    corr = xcorr(x, y, max_lags=3)

    # Peak should be at center (zero lag) for identical signals
    center = len(corr) // 2
    peak_idx = np.argmax(corr)
    assert peak_idx == center


# -----------------------------------------------------------------------------
# Normalization
# -----------------------------------------------------------------------------


def test_xcorr_norm_peak_is_one() -> None:
    """Verify norm=True gives peak magnitude 1.0 without changing peak location."""
    x = np.array([1, 2, 3, 4, 5, 6, 7])
    y = np.array([0, 0, 1, 2, 3, 4, 5])

    corr_raw = xcorr(x, y, max_lags=3)
    corr_norm = xcorr(x, y, max_lags=3, norm=True)

    assert np.max(np.abs(corr_norm)) == pytest.approx(1.0)
    assert np.argmax(np.abs(corr_norm)) == np.argmax(np.abs(corr_raw))
