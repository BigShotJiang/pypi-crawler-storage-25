"""Tests for peak-to-sidelobe ratio."""

from __future__ import annotations

import numpy as np
import pytest

from gri_signal.correlation.pslr import pslr


def test_pslr_dominant_peak() -> None:
    """Single dominant peak with noise should give high PSLR."""
    x = np.zeros(100)
    x[50] = 10.0  # Main peak
    # Add small bumps to create sidelobes
    x[20] = 0.5
    x[80] = 0.3
    result = pslr(x)
    assert result is not None
    assert result > 20.0


def test_pslr_equal_peaks() -> None:
    """Two equal-height peaks should give PSLR ~= 0 dB."""
    x = np.zeros(100)
    x[30] = 5.0
    x[70] = 5.0
    result = pslr(x)
    assert result is not None
    assert result == pytest.approx(0.0, abs=0.01)


def test_pslr_fewer_than_two_maxima() -> None:
    """Monotonic or single-peak array returns None."""
    # Monotonic: no local maxima at all
    assert pslr(np.arange(10, dtype=float)) is None
    # Single peak: only one local maximum
    x = np.array([0.0, 0.0, 1.0, 0.0, 0.0])
    assert pslr(x) is None


def test_pslr_known_ratio() -> None:
    """Verify computed PSLR matches a known ratio."""
    x = np.zeros(100)
    x[30] = 10.0
    x[70] = 1.0
    result = pslr(x)
    assert result is not None
    # 20 * log10(10 / 1) = 20.0 dB
    assert result == pytest.approx(20.0, abs=0.01)


def test_pslr_complex_input() -> None:
    """PSLR works on complex arrays (uses magnitude)."""
    x = np.zeros(100, dtype=complex)
    x[30] = 10.0 + 0j
    x[70] = 0.0 + 1.0j  # magnitude 1.0
    result = pslr(x)
    assert result is not None
    assert result == pytest.approx(20.0, abs=0.01)
