"""Tests for modulation functions."""

from __future__ import annotations

import numpy as np
import pytest

from gri_signal.modulation import iq_to_passband, passband_to_iq


class TestPassbandToIq:
    """Tests for passband_to_iq conversion."""

    @pytest.mark.parametrize(
        ("fs", "f_center"),
        [
            (10000, 1000),
            (44100, 5000),
            (1e6, 100e3),
        ],
    )
    def test_passband_to_iq_preserves_length(self, fs, f_center):
        """Conversion preserves signal length."""
        t = np.arange(1000) / fs
        passband = np.cos(2 * np.pi * f_center * t)
        iq = passband_to_iq(passband, fs, f_center)
        assert iq.shape == passband.shape
        assert iq.dtype == np.complex128

    def test_passband_to_iq_centers_at_dc(self):
        """Signal at f_center becomes DC after conversion."""
        fs = 10000
        f_center = 1000
        t = np.arange(10000) / fs
        passband = np.cos(2 * np.pi * f_center * t)
        iq = passband_to_iq(passband, fs, f_center)
        # DC component should be dominant
        spectrum = np.abs(np.fft.fft(iq))
        assert np.argmax(spectrum) == 0  # Peak at DC


class TestIqToPassband:
    """Tests for iq_to_passband conversion."""

    @pytest.mark.parametrize(
        ("fs", "f_center"),
        [
            (10000, 1000),
            (44100, 5000),
        ],
    )
    def test_iq_to_passband_preserves_length(self, fs, f_center):
        """Conversion preserves signal length."""
        iq = np.ones(1000, dtype=complex)
        passband = iq_to_passband(iq, fs, f_center)
        assert passband.shape == iq.shape
        assert passband.dtype == np.float64

    def test_iq_to_passband_creates_carrier(self):
        """Constant IQ creates carrier at f_center."""
        fs = 10000
        f_center = 1000
        iq = np.ones(10000, dtype=complex)
        passband = iq_to_passband(iq, fs, f_center)
        # Should have peak at f_center
        spectrum = np.abs(np.fft.fft(passband))
        freqs = np.fft.fftfreq(len(passband), 1 / fs)
        peak_freq = abs(freqs[np.argmax(spectrum)])
        assert abs(peak_freq - f_center) < 1.0
