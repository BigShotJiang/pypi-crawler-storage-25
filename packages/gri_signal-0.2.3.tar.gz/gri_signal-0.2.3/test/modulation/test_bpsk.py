"""Tests for BPSK modulation functions."""

from __future__ import annotations

import numpy as np
import pytest

from gri_signal.modulation.bpsk import demod_bpsk, mod_bpsk


class TestModBpsk:
    """Tests for mod_bpsk function."""

    def test_output_length(self):
        """Output length is bits * samples_per_symbol."""
        bits = np.array([0, 1, 1, 0, 1, 0, 0, 1])
        fs = 10000
        symbol_rate = 1000
        samples_per_symbol = int(fs / symbol_rate)

        result = mod_bpsk(bits, fs, symbol_rate)
        assert len(result) == len(bits) * samples_per_symbol

    def test_output_is_complex(self):
        """Output is complex-valued."""
        bits = np.array([0, 1, 1, 0])
        result = mod_bpsk(bits, 10000, 1000)
        assert result.dtype == np.complex128

    def test_constellation_mapping(self):
        """Bits map to correct BPSK symbols."""
        bits = np.array([0, 1])
        result = mod_bpsk(bits, 1000, 1000)  # 1 sample per symbol

        # 0 → -1, 1 → +1
        assert np.real(result[0]) == -1
        assert np.real(result[1]) == +1

    def test_imaginary_part_zero(self):
        """BPSK symbols have zero imaginary part."""
        bits = np.array([0, 1, 0, 1, 0, 0, 1, 1])
        result = mod_bpsk(bits, 10000, 1000)

        np.testing.assert_allclose(np.imag(result), 0)

    def test_rectangular_pulse_shape(self):
        """Symbols are held constant for samples_per_symbol samples."""
        bits = np.array([0, 1])
        fs = 10000
        symbol_rate = 1000
        samples_per_symbol = int(fs / symbol_rate)

        result = mod_bpsk(bits, fs, symbol_rate)

        # First symbol (0 → -1) should be constant
        assert np.all(np.real(result[:samples_per_symbol]) == -1)
        # Second symbol (1 → +1) should be constant
        assert np.all(np.real(result[samples_per_symbol:]) == +1)

    def test_invalid_samples_per_symbol_raises(self):
        """Non-integer samples per symbol raises ValueError."""
        bits = np.array([0, 1, 1, 0])

        with pytest.raises(ValueError, match="must be an integer"):
            mod_bpsk(bits, 10000, 3000)  # 10000/3000 = 3.33...

    @pytest.mark.parametrize(
        ("fs", "symbol_rate"),
        [
            (10000, 1000),
            (44100, 4410),
            (8000, 800),
        ],
    )
    def test_various_sample_rates(self, fs, symbol_rate):
        """Works with various valid sample rate combinations."""
        bits = np.array([0, 1, 0, 1])
        result = mod_bpsk(bits, fs, symbol_rate)

        expected_len = len(bits) * int(fs / symbol_rate)
        assert len(result) == expected_len


class TestDemodBpsk:
    """Tests for demod_bpsk function."""

    def test_output_length(self):
        """Output length matches number of symbols in input."""
        bits = np.array([0, 1, 1, 0, 1, 0, 0, 1])
        fs = 10000
        symbol_rate = 1000

        signal = mod_bpsk(bits, fs, symbol_rate)
        recovered = demod_bpsk(signal, fs, symbol_rate)

        assert len(recovered) == len(bits)

    def test_output_is_int8(self):
        """Output is int8 dtype."""
        bits = np.array([0, 1, 1, 0])
        signal = mod_bpsk(bits, 10000, 1000)
        recovered = demod_bpsk(signal, 10000, 1000)

        assert recovered.dtype == np.int8

    def test_roundtrip_perfect_recovery(self):
        """Modulate then demodulate perfectly recovers bits."""
        bits = np.array([0, 1, 1, 0, 1, 0, 0, 1, 1, 1, 0, 0])
        fs = 10000
        symbol_rate = 1000

        signal = mod_bpsk(bits, fs, symbol_rate)
        recovered = demod_bpsk(signal, fs, symbol_rate)

        np.testing.assert_array_equal(recovered, bits)

    def test_roundtrip_random_bits(self):
        """Roundtrip works for random bit sequences."""
        rng = np.random.default_rng(42)
        bits = rng.integers(0, 2, size=100, dtype=np.int8)
        fs = 20000
        symbol_rate = 2000

        signal = mod_bpsk(bits, fs, symbol_rate)
        recovered = demod_bpsk(signal, fs, symbol_rate)

        np.testing.assert_array_equal(recovered, bits)

    def test_handles_noisy_signal(self):
        """Demodulation handles moderate noise."""
        rng = np.random.default_rng(42)
        bits = rng.integers(0, 2, size=100, dtype=np.int8)
        fs = 10000
        symbol_rate = 1000

        signal = mod_bpsk(bits, fs, symbol_rate)

        # Add noise (SNR ~20 dB)
        noise_re = rng.standard_normal(len(signal))
        noise_im = rng.standard_normal(len(signal))
        noise = 0.1 * (noise_re + 1j * noise_im)
        noisy_signal = signal + noise

        recovered = demod_bpsk(noisy_signal, fs, symbol_rate)

        # Should still recover most bits correctly
        bit_error_rate = np.mean(recovered != bits)
        assert bit_error_rate < 0.05  # Less than 5% errors

    def test_invalid_samples_per_symbol_raises(self):
        """Non-integer samples per symbol raises ValueError."""
        signal = np.ones(100, dtype=complex)

        with pytest.raises(ValueError, match="must be an integer"):
            demod_bpsk(signal, 10000, 3000)

    def test_demod_handles_real_input(self):
        """Demodulation works with real-valued input."""
        bits = np.array([0, 1, 1, 0, 1, 0])
        fs = 10000
        symbol_rate = 1000

        signal = mod_bpsk(bits, fs, symbol_rate)
        real_signal = np.real(signal)

        recovered = demod_bpsk(real_signal, fs, symbol_rate)
        np.testing.assert_array_equal(recovered, bits)
