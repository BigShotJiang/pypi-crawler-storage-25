"""Tests for QAM modulation functions."""

from __future__ import annotations

import numpy as np
import pytest

from gri_signal.modulation.qam import _QAM_CONSTELLATIONS, demod_qam, mod_qam


class TestModQam:
    """Tests for mod_qam function."""

    @pytest.mark.parametrize(
        ("order", "bits_per_symbol"),
        [
            (4, 2),
            (16, 4),
            (64, 6),
            (256, 8),
        ],
    )
    def test_output_length(self, order, bits_per_symbol):
        """Output length is (bits/bits_per_symbol) * samples_per_symbol."""
        n_symbols = 10
        bits = np.zeros(n_symbols * bits_per_symbol, dtype=np.int8)
        fs = 10000
        symbol_rate = 1000
        samples_per_symbol = int(fs / symbol_rate)

        result = mod_qam(bits, fs, symbol_rate, order=order)
        assert len(result) == n_symbols * samples_per_symbol

    def test_output_is_complex(self):
        """Output is complex-valued."""
        bits = np.zeros(16, dtype=np.int8)
        result = mod_qam(bits, 10000, 1000, order=16)
        assert result.dtype == np.complex128

    @pytest.mark.parametrize("order", [4, 16, 64, 256])
    def test_unit_average_power(self, order):
        """Constellation has approximately unit average power."""
        bits_per_symbol = int(np.log2(order))
        # Generate all possible symbols
        n_symbols = order
        bits = np.zeros(n_symbols * bits_per_symbol, dtype=np.int8)
        for i in range(n_symbols):
            for j in range(bits_per_symbol):
                bits[i * bits_per_symbol + bits_per_symbol - 1 - j] = (i >> j) & 1

        result = mod_qam(bits, 1000, 1000, order=order)  # 1 sample per symbol
        avg_power = np.mean(np.abs(result) ** 2)

        np.testing.assert_allclose(avg_power, 1.0, rtol=1e-10)

    def test_invalid_order_raises(self):
        """Unsupported order raises ValueError."""
        bits = np.zeros(8, dtype=np.int8)

        with pytest.raises(ValueError, match="must be one of"):
            mod_qam(bits, 10000, 1000, order=8)

        with pytest.raises(ValueError, match="must be one of"):
            mod_qam(bits, 10000, 1000, order=32)

    def test_invalid_bits_length_raises(self):
        """Bits not multiple of bits_per_symbol raises ValueError."""
        bits = np.zeros(7, dtype=np.int8)  # Not divisible by 4

        with pytest.raises(ValueError, match="must be a multiple"):
            mod_qam(bits, 10000, 1000, order=16)

    def test_invalid_samples_per_symbol_raises(self):
        """Non-integer samples per symbol raises ValueError."""
        bits = np.zeros(8, dtype=np.int8)

        with pytest.raises(ValueError, match="must be an integer"):
            mod_qam(bits, 10000, 3000, order=16)

    def test_rectangular_pulse_shape(self):
        """Symbols are held constant for samples_per_symbol samples."""
        bits = np.array([0, 0, 0, 0, 1, 1, 1, 1], dtype=np.int8)  # Two 16-QAM symbols
        fs = 10000
        symbol_rate = 1000
        samples_per_symbol = int(fs / symbol_rate)

        result = mod_qam(bits, fs, symbol_rate, order=16)

        # First symbol should be constant
        first_symbol = result[0]
        np.testing.assert_allclose(result[:samples_per_symbol], first_symbol)

        # Second symbol should be constant (and different)
        second_symbol = result[samples_per_symbol]
        np.testing.assert_allclose(result[samples_per_symbol:], second_symbol)

        # Symbols should be different
        assert first_symbol != second_symbol


class TestDemodQam:
    """Tests for demod_qam function."""

    @pytest.mark.parametrize(
        ("order", "bits_per_symbol"),
        [
            (4, 2),
            (16, 4),
            (64, 6),
            (256, 8),
        ],
    )
    def test_output_length(self, order, bits_per_symbol):
        """Output length is n_symbols * bits_per_symbol."""
        n_symbols = 10
        bits = np.zeros(n_symbols * bits_per_symbol, dtype=np.int8)
        fs = 10000
        symbol_rate = 1000

        signal = mod_qam(bits, fs, symbol_rate, order=order)
        recovered = demod_qam(signal, fs, symbol_rate, order=order)

        assert len(recovered) == len(bits)

    def test_output_is_int8(self):
        """Output is int8 dtype."""
        bits = np.zeros(16, dtype=np.int8)
        signal = mod_qam(bits, 10000, 1000, order=16)
        recovered = demod_qam(signal, 10000, 1000, order=16)

        assert recovered.dtype == np.int8

    @pytest.mark.parametrize("order", [4, 16, 64, 256])
    def test_roundtrip_perfect_recovery(self, order):
        """Modulate then demodulate perfectly recovers bits."""
        rng = np.random.default_rng(42)
        bits_per_symbol = int(np.log2(order))
        bits = rng.integers(0, 2, size=bits_per_symbol * 20, dtype=np.int8)
        fs = 10000
        symbol_rate = 1000

        signal = mod_qam(bits, fs, symbol_rate, order=order)
        recovered = demod_qam(signal, fs, symbol_rate, order=order)

        np.testing.assert_array_equal(recovered, bits)

    def test_roundtrip_all_symbols_16qam(self):
        """All 16-QAM symbols roundtrip correctly."""
        # Generate all 16 symbol patterns
        bits_per_symbol = 4
        bits = np.zeros(16 * bits_per_symbol, dtype=np.int8)
        for i in range(16):
            for j in range(bits_per_symbol):
                bits[i * bits_per_symbol + bits_per_symbol - 1 - j] = (i >> j) & 1

        fs = 10000
        symbol_rate = 1000

        signal = mod_qam(bits, fs, symbol_rate, order=16)
        recovered = demod_qam(signal, fs, symbol_rate, order=16)

        np.testing.assert_array_equal(recovered, bits)

    def test_handles_noisy_signal(self):
        """Demodulation handles moderate noise for 16-QAM."""
        rng = np.random.default_rng(42)
        bits = rng.integers(0, 2, size=80, dtype=np.int8)  # 20 symbols
        fs = 10000
        symbol_rate = 1000

        signal = mod_qam(bits, fs, symbol_rate, order=16)

        # Add noise (relatively high SNR for 16-QAM)
        noise_re = rng.standard_normal(len(signal))
        noise_im = rng.standard_normal(len(signal))
        noise = 0.05 * (noise_re + 1j * noise_im)
        noisy_signal = signal + noise

        recovered = demod_qam(noisy_signal, fs, symbol_rate, order=16)

        # Should still recover most bits correctly
        bit_error_rate = np.mean(recovered != bits)
        assert bit_error_rate < 0.05  # Less than 5% errors

    def test_invalid_order_raises(self):
        """Unsupported order raises ValueError."""
        signal = np.ones(100, dtype=complex)

        with pytest.raises(ValueError, match="must be one of"):
            demod_qam(signal, 10000, 1000, order=8)

    def test_invalid_samples_per_symbol_raises(self):
        """Non-integer samples per symbol raises ValueError."""
        signal = np.ones(100, dtype=complex)

        with pytest.raises(ValueError, match="must be an integer"):
            demod_qam(signal, 10000, 3000, order=16)


class TestGrayCoding:
    """Tests for Gray coding property."""

    @pytest.mark.parametrize("order", [4, 16, 64])
    def test_adjacent_symbols_differ_by_one_bit(self, order):
        """Adjacent constellation points differ by only one bit (Gray coding)."""
        constellation = _QAM_CONSTELLATIONS[order]

        def count_bit_diff(a: int, b: int) -> int:
            """Count differing bits between two integers."""
            return (a ^ b).bit_count()

        # For each symbol, find its nearest neighbors and check bit difference
        for i, sym_i in enumerate(constellation):
            distances = np.abs(constellation - sym_i)
            distances[i] = np.inf  # Exclude self

            # Find minimum non-zero distance (nearest neighbors)
            min_dist = np.min(distances)
            neighbors = np.where(np.isclose(distances, min_dist))[0]

            # Each neighbor should differ by exactly 1 bit
            for j in neighbors:
                diff = count_bit_diff(i, j)
                assert diff == 1, f"Symbols {i} and {j} differ by {diff} bits"
