"""Tests for QPSK modulation functions."""

from __future__ import annotations

import numpy as np
import pytest

from gri_signal.modulation.qpsk import demod_qpsk, mod_qpsk


class TestModQpsk:
    """Tests for mod_qpsk function."""

    def test_output_length(self):
        """Output length is (bits/2) * samples_per_symbol."""
        bits = np.array([0, 0, 0, 1, 1, 0, 1, 1])  # 8 bits = 4 symbols
        fs = 10000
        symbol_rate = 1000
        samples_per_symbol = int(fs / symbol_rate)

        result = mod_qpsk(bits, fs, symbol_rate)
        assert len(result) == (len(bits) // 2) * samples_per_symbol

    def test_output_is_complex(self):
        """Output is complex-valued."""
        bits = np.array([0, 0, 1, 1])
        result = mod_qpsk(bits, 10000, 1000)
        assert result.dtype == np.complex128

    def test_constellation_mapping(self):
        """Bit pairs map to correct QPSK symbols."""
        # Test each constellation point
        bits = np.array([0, 0, 0, 1, 1, 0, 1, 1])
        result = mod_qpsk(bits, 1000, 1000)  # 1 sample per symbol

        sqrt2 = np.sqrt(2)
        expected = np.array(
            [
                (-1 - 1j) / sqrt2,  # 00
                (-1 + 1j) / sqrt2,  # 01
                (1 - 1j) / sqrt2,  # 10
                (1 + 1j) / sqrt2,  # 11
            ],
        )

        np.testing.assert_allclose(result, expected)

    def test_unit_magnitude(self):
        """All QPSK symbols have unit magnitude."""
        bits = np.array([0, 0, 0, 1, 1, 0, 1, 1])
        result = mod_qpsk(bits, 1000, 1000)

        np.testing.assert_allclose(np.abs(result), 1.0)

    def test_rectangular_pulse_shape(self):
        """Symbols are held constant for samples_per_symbol samples."""
        bits = np.array([0, 0, 1, 1])  # Two symbols
        fs = 10000
        symbol_rate = 1000
        samples_per_symbol = int(fs / symbol_rate)

        result = mod_qpsk(bits, fs, symbol_rate)

        sqrt2 = np.sqrt(2)
        # First symbol (00) should be constant
        expected_first = (-1 - 1j) / sqrt2
        np.testing.assert_allclose(result[:samples_per_symbol], expected_first)

        # Second symbol (11) should be constant
        expected_second = (1 + 1j) / sqrt2
        np.testing.assert_allclose(result[samples_per_symbol:], expected_second)

    def test_odd_bits_raises(self):
        """Odd number of bits raises ValueError."""
        bits = np.array([0, 1, 1])  # 3 bits

        with pytest.raises(ValueError, match="must be even"):
            mod_qpsk(bits, 10000, 1000)

    def test_invalid_samples_per_symbol_raises(self):
        """Non-integer samples per symbol raises ValueError."""
        bits = np.array([0, 0, 1, 1])

        with pytest.raises(ValueError, match="must be an integer"):
            mod_qpsk(bits, 10000, 3000)

    @pytest.mark.parametrize(
        ("fs", "symbol_rate"),
        [
            (10000, 1000),
            (44100, 4410),
            (8000, 800),
        ],
    )
    def test_various_sample_rates(self, fs, symbol_rate):
        """Works with various valid sample rate combinations."""
        bits = np.array([0, 0, 0, 1, 1, 0, 1, 1])
        result = mod_qpsk(bits, fs, symbol_rate)

        expected_len = (len(bits) // 2) * int(fs / symbol_rate)
        assert len(result) == expected_len


class TestDemodQpsk:
    """Tests for demod_qpsk function."""

    def test_output_length(self):
        """Output length is 2 * number of symbols."""
        bits = np.array([0, 0, 0, 1, 1, 0, 1, 1])
        fs = 10000
        symbol_rate = 1000

        signal = mod_qpsk(bits, fs, symbol_rate)
        recovered = demod_qpsk(signal, fs, symbol_rate)

        assert len(recovered) == len(bits)

    def test_output_is_int8(self):
        """Output is int8 dtype."""
        bits = np.array([0, 0, 1, 1])
        signal = mod_qpsk(bits, 10000, 1000)
        recovered = demod_qpsk(signal, 10000, 1000)

        assert recovered.dtype == np.int8

    def test_roundtrip_perfect_recovery(self):
        """Modulate then demodulate perfectly recovers bits."""
        bits = np.array([0, 0, 0, 1, 1, 0, 1, 1, 0, 1, 1, 0])
        fs = 10000
        symbol_rate = 1000

        signal = mod_qpsk(bits, fs, symbol_rate)
        recovered = demod_qpsk(signal, fs, symbol_rate)

        np.testing.assert_array_equal(recovered, bits)

    def test_roundtrip_random_bits(self):
        """Roundtrip works for random bit sequences."""
        rng = np.random.default_rng(42)
        bits = rng.integers(0, 2, size=100, dtype=np.int8)
        fs = 20000
        symbol_rate = 2000

        signal = mod_qpsk(bits, fs, symbol_rate)
        recovered = demod_qpsk(signal, fs, symbol_rate)

        np.testing.assert_array_equal(recovered, bits)

    def test_handles_noisy_signal(self):
        """Demodulation handles moderate noise."""
        rng = np.random.default_rng(42)
        bits = rng.integers(0, 2, size=100, dtype=np.int8)
        fs = 10000
        symbol_rate = 1000

        signal = mod_qpsk(bits, fs, symbol_rate)

        # Add noise (SNR ~20 dB)
        noise_re = rng.standard_normal(len(signal))
        noise_im = rng.standard_normal(len(signal))
        noise = 0.1 * (noise_re + 1j * noise_im)
        noisy_signal = signal + noise

        recovered = demod_qpsk(noisy_signal, fs, symbol_rate)

        # Should still recover most bits correctly
        bit_error_rate = np.mean(recovered != bits)
        assert bit_error_rate < 0.05  # Less than 5% errors

    def test_invalid_samples_per_symbol_raises(self):
        """Non-integer samples per symbol raises ValueError."""
        signal = np.ones(100, dtype=complex)

        with pytest.raises(ValueError, match="must be an integer"):
            demod_qpsk(signal, 10000, 3000)

    def test_all_constellation_points(self):
        """All constellation points are correctly demodulated."""
        # Each constellation point twice
        bits = np.array(
            [
                0,
                0,
                0,
                0,  # Two 00 symbols
                0,
                1,
                0,
                1,  # Two 01 symbols
                1,
                0,
                1,
                0,  # Two 10 symbols
                1,
                1,
                1,
                1,  # Two 11 symbols
            ],
        )
        fs = 10000
        symbol_rate = 1000

        signal = mod_qpsk(bits, fs, symbol_rate)
        recovered = demod_qpsk(signal, fs, symbol_rate)

        np.testing.assert_array_equal(recovered, bits)
