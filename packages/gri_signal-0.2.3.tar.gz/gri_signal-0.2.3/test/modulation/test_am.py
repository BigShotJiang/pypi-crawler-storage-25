"""Tests for AM modulation functions."""

from __future__ import annotations

import numpy as np
import pytest

from gri_signal.modulation.am import demod_am, mod_am


class TestModAm:
    """Tests for mod_am function."""

    def test_output_shape_matches_input(self):
        """Output has same length as input."""
        sig = np.sin(2 * np.pi * 100 * np.arange(1000) / 10000)
        result = mod_am(sig, 10000, 1000)
        assert result.shape == sig.shape

    def test_output_is_complex(self):
        """Output is complex-valued."""
        sig = np.sin(2 * np.pi * 100 * np.arange(1000) / 10000)
        result = mod_am(sig, 10000, 1000)
        assert np.iscomplexobj(result)

    def test_carrier_frequency_present(self):
        """Carrier frequency is present in spectrum."""
        fs = 10000
        f_carrier = 1000
        sig = np.zeros(10000)  # No modulation, just carrier
        result = mod_am(sig, fs, f_carrier)

        spectrum = np.abs(np.fft.fft(result))
        freqs = np.fft.fftfreq(len(result), 1 / fs)
        peak_idx = np.argmax(spectrum)
        peak_freq = abs(freqs[peak_idx])

        assert abs(peak_freq - f_carrier) < 1.0

    def test_mod_index_affects_depth(self):
        """Higher mod_index creates larger amplitude variations."""
        fs = 10000
        t = np.arange(10000) / fs
        sig = np.sin(2 * np.pi * 100 * t)

        result_low = mod_am(sig, fs, 1000, mod_index=0.2)
        result_high = mod_am(sig, fs, 1000, mod_index=0.8)

        # Higher mod_index means larger envelope variation
        env_low = np.abs(result_low)
        env_high = np.abs(result_high)

        assert np.std(env_high) > np.std(env_low)

    @pytest.mark.parametrize("mod_index", [0.1, 0.5, 1.0])
    def test_envelope_follows_message(self, mod_index):
        """Envelope shape follows the message signal."""
        fs = 10000
        t = np.arange(10000) / fs
        sig = np.sin(2 * np.pi * 50 * t)  # Low frequency message

        result = mod_am(sig, fs, 2000, mod_index=mod_index)
        envelope = np.abs(result)

        # Envelope should be correlated with (1 + m*sig)
        expected_envelope = 1 + mod_index * sig
        correlation = np.corrcoef(envelope, expected_envelope)[0, 1]

        assert correlation > 0.99


class TestDemodAm:
    """Tests for demod_am function."""

    def test_output_shape_matches_input(self):
        """Output has same length as input."""
        fs = 10000
        t = np.arange(10000) / fs
        sig = np.sin(2 * np.pi * 100 * t)
        am_signal = mod_am(sig, fs, 1000)

        result = demod_am(am_signal, fs, 1000)
        assert result.shape == am_signal.shape

    def test_output_is_real(self):
        """Output is real-valued."""
        fs = 10000
        t = np.arange(10000) / fs
        sig = np.sin(2 * np.pi * 100 * t)
        am_signal = mod_am(sig, fs, 1000)

        result = demod_am(am_signal, fs, 1000)
        assert result.dtype == np.float64

    def test_roundtrip_recovers_shape(self):
        """Modulate then demodulate recovers message shape."""
        fs = 10000
        t = np.arange(10000) / fs
        sig = np.sin(2 * np.pi * 100 * t)

        am_signal = mod_am(sig, fs, 1000, mod_index=0.5)
        recovered = demod_am(am_signal, fs, 1000)

        # Should be highly correlated with original
        correlation = np.corrcoef(sig, recovered)[0, 1]
        assert correlation > 0.95

    def test_demod_handles_real_input(self):
        """Demodulation works with real AM signal."""
        fs = 10000
        t = np.arange(10000) / fs
        sig = np.sin(2 * np.pi * 100 * t)

        # Create real AM signal
        am_signal = mod_am(sig, fs, 1000, mod_index=0.5)
        real_am = np.real(am_signal)

        result = demod_am(real_am, fs, 1000)
        assert result.dtype == np.float64

        # Should still recover message shape
        correlation = np.corrcoef(sig, result)[0, 1]
        assert correlation > 0.9

    def test_output_normalized(self):
        """Output is approximately normalized to [-1, 1]."""
        fs = 10000
        t = np.arange(10000) / fs
        sig = np.sin(2 * np.pi * 100 * t)

        am_signal = mod_am(sig, fs, 1000, mod_index=0.5)
        recovered = demod_am(am_signal, fs, 1000)

        assert np.max(np.abs(recovered)) <= 1.01  # Allow small tolerance
