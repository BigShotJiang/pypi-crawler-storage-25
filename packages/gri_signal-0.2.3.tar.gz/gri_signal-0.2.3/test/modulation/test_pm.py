"""Tests for PM modulation functions."""

from __future__ import annotations

import numpy as np
import pytest

from gri_signal.modulation.pm import demod_pm, mod_pm


class TestModPm:
    """Tests for mod_pm function."""

    def test_output_shape_matches_input(self):
        """Output has same length as input."""
        sig = np.sin(2 * np.pi * 100 * np.arange(1000) / 10000)
        result = mod_pm(sig, 10000, 1000, phase_deviation=np.pi / 2)
        assert result.shape == sig.shape

    def test_output_is_complex(self):
        """Output is complex-valued."""
        sig = np.sin(2 * np.pi * 100 * np.arange(1000) / 10000)
        result = mod_pm(sig, 10000, 1000, phase_deviation=np.pi / 2)
        assert np.iscomplexobj(result)

    def test_constant_envelope(self):
        """PM signal has constant envelope (unit magnitude)."""
        fs = 10000
        t = np.arange(10000) / fs
        sig = np.sin(2 * np.pi * 100 * t)

        result = mod_pm(sig, fs, 1000, phase_deviation=np.pi / 2)
        envelope = np.abs(result)

        np.testing.assert_allclose(envelope, 1.0, rtol=1e-10)

    def test_zero_message_produces_carrier(self):
        """Zero message produces pure carrier frequency."""
        fs = 10000
        f_carrier = 1000
        sig = np.zeros(10000)

        result = mod_pm(sig, fs, f_carrier, phase_deviation=np.pi / 2)

        # Should be a pure tone at carrier frequency
        spectrum = np.abs(np.fft.fft(result))
        freqs = np.fft.fftfreq(len(result), 1 / fs)
        peak_idx = np.argmax(spectrum)
        peak_freq = abs(freqs[peak_idx])

        assert abs(peak_freq - f_carrier) < 1.0

    @pytest.mark.parametrize("phase_deviation", [np.pi / 4, np.pi / 2, np.pi])
    def test_phase_deviation_affects_spectrum(self, phase_deviation):
        """Different phase deviations create different spectra."""
        fs = 10000
        t = np.arange(10000) / fs
        sig = np.sin(2 * np.pi * 100 * t)

        result = mod_pm(sig, fs, 2000, phase_deviation=phase_deviation)
        spectrum = np.abs(np.fft.fft(result))

        # Spectrum should have sideband structure
        assert np.sum(spectrum > 0.1 * np.max(spectrum)) > 1

    def test_phase_follows_message(self):
        """Instantaneous phase follows the message signal."""
        fs = 10000
        phase_dev = np.pi / 2
        t = np.arange(10000) / fs
        f_carrier = 2000

        sig = np.sin(2 * np.pi * 50 * t)  # Low frequency message

        result = mod_pm(sig, fs, f_carrier, phase_deviation=phase_dev)

        # Extract phase and remove carrier
        phase = np.unwrap(np.angle(result))
        carrier_phase = 2 * np.pi * f_carrier * t
        message_phase = phase - carrier_phase

        # Message phase should be correlated with original * phase_dev
        expected_phase = phase_dev * sig
        correlation = np.corrcoef(message_phase, expected_phase)[0, 1]

        assert correlation > 0.99


class TestDemodPm:
    """Tests for demod_pm function."""

    def test_output_shape_matches_input(self):
        """Output has same length as input."""
        fs = 10000
        t = np.arange(10000) / fs
        sig = np.sin(2 * np.pi * 100 * t)
        pm_signal = mod_pm(sig, fs, 1000, phase_deviation=np.pi / 2)

        result = demod_pm(pm_signal, fs, 1000, phase_deviation=np.pi / 2)
        assert result.shape == pm_signal.shape

    def test_output_is_real(self):
        """Output is real-valued."""
        fs = 10000
        t = np.arange(10000) / fs
        sig = np.sin(2 * np.pi * 100 * t)
        pm_signal = mod_pm(sig, fs, 1000, phase_deviation=np.pi / 2)

        result = demod_pm(pm_signal, fs, 1000, phase_deviation=np.pi / 2)
        assert result.dtype == np.float64

    def test_roundtrip_recovers_signal(self):
        """Modulate then demodulate recovers message."""
        fs = 10000
        t = np.arange(10000) / fs
        sig = np.sin(2 * np.pi * 100 * t)

        pm_signal = mod_pm(sig, fs, 2000, phase_deviation=np.pi / 2)
        recovered = demod_pm(pm_signal, fs, 2000, phase_deviation=np.pi / 2)

        # Should be highly correlated with original
        correlation = np.corrcoef(sig, recovered)[0, 1]
        assert correlation > 0.99

    def test_demod_handles_real_input(self):
        """Demodulation works with real PM signal via Hilbert transform."""
        fs = 10000
        t = np.arange(10000) / fs
        sig = np.sin(2 * np.pi * 100 * t)

        pm_signal = mod_pm(sig, fs, 2000, phase_deviation=np.pi / 2)
        real_pm = np.real(pm_signal)

        result = demod_pm(real_pm, fs, 2000, phase_deviation=np.pi / 2)
        assert result.dtype == np.float64

    @pytest.mark.parametrize(
        ("f_message", "phase_deviation"),
        [
            (50, np.pi / 4),
            (100, np.pi / 2),
            (200, np.pi),
        ],
    )
    def test_recovers_different_signals(self, f_message, phase_deviation):
        """Demodulation works for different message frequencies and deviations."""
        fs = 10000
        t = np.arange(10000) / fs
        sig = np.sin(2 * np.pi * f_message * t)

        pm_signal = mod_pm(sig, fs, 2000, phase_deviation=phase_deviation)
        recovered = demod_pm(pm_signal, fs, 2000, phase_deviation=phase_deviation)

        # Check frequency content matches
        sig_spectrum = np.abs(np.fft.fft(sig))
        rec_spectrum = np.abs(np.fft.fft(recovered))
        freqs = np.fft.fftfreq(len(sig), 1 / fs)

        sig_peak_idx = np.argmax(sig_spectrum[: len(sig) // 2])
        rec_peak_idx = np.argmax(rec_spectrum[: len(recovered) // 2])

        assert abs(freqs[sig_peak_idx] - freqs[rec_peak_idx]) < 5
