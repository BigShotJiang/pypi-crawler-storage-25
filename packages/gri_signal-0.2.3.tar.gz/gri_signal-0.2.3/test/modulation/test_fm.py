"""Tests for FM modulation functions."""

from __future__ import annotations

import numpy as np
import pytest

from gri_signal.modulation.fm import demod_fm, mod_fm


class TestModFm:
    """Tests for mod_fm function."""

    def test_output_shape_matches_input(self):
        """Output has same length as input."""
        sig = np.sin(2 * np.pi * 100 * np.arange(1000) / 10000)
        result = mod_fm(sig, 10000, 1000, freq_deviation=500)
        assert result.shape == sig.shape

    def test_output_is_complex(self):
        """Output is complex-valued."""
        sig = np.sin(2 * np.pi * 100 * np.arange(1000) / 10000)
        result = mod_fm(sig, 10000, 1000, freq_deviation=500)
        assert np.iscomplexobj(result)

    def test_constant_envelope(self):
        """FM signal has constant envelope (unit magnitude)."""
        fs = 10000
        t = np.arange(10000) / fs
        sig = np.sin(2 * np.pi * 100 * t)

        result = mod_fm(sig, fs, 1000, freq_deviation=500)
        envelope = np.abs(result)

        np.testing.assert_allclose(envelope, 1.0, rtol=1e-10)

    def test_zero_message_produces_carrier(self):
        """Zero message produces pure carrier frequency."""
        fs = 10000
        f_carrier = 1000
        sig = np.zeros(10000)

        result = mod_fm(sig, fs, f_carrier, freq_deviation=500)

        # Should be a pure tone at carrier frequency
        spectrum = np.abs(np.fft.fft(result))
        freqs = np.fft.fftfreq(len(result), 1 / fs)
        peak_idx = np.argmax(spectrum)
        peak_freq = abs(freqs[peak_idx])

        assert abs(peak_freq - f_carrier) < 1.0

    @pytest.mark.parametrize("freq_deviation", [100, 500, 1000])
    def test_frequency_deviation_affects_bandwidth(self, freq_deviation):
        """Higher frequency deviation creates wider bandwidth."""
        fs = 20000
        t = np.arange(20000) / fs
        sig = np.sin(2 * np.pi * 100 * t)

        result = mod_fm(sig, fs, 5000, freq_deviation=freq_deviation)

        # Compute bandwidth (3dB bandwidth approximation)
        spectrum = np.abs(np.fft.fft(result))
        spectrum_db = 20 * np.log10(spectrum + 1e-10)
        peak_db = np.max(spectrum_db)

        # Count bins above -3dB from peak
        bandwidth_bins = np.sum(spectrum_db > peak_db - 3)

        # Higher deviation should have more bins (wider bandwidth)
        # This is a relative test
        assert bandwidth_bins > 0

    def test_instantaneous_frequency_follows_message(self):
        """Instantaneous frequency follows the message signal."""
        fs = 10000
        f_carrier = 2000
        freq_dev = 500

        # Use a simple step function for clear frequency change
        sig = np.ones(10000)
        sig[:5000] = -1  # First half at -1, second half at +1

        result = mod_fm(sig, fs, f_carrier, freq_deviation=freq_dev)

        # Compute instantaneous frequency in each half
        phase_diff_1 = np.angle(result[1:2500] * np.conj(result[:2499]))
        phase_diff_2 = np.angle(result[7501:10000] * np.conj(result[7500:9999]))

        inst_freq_1 = np.mean(phase_diff_1) * fs / (2 * np.pi)
        inst_freq_2 = np.mean(phase_diff_2) * fs / (2 * np.pi)

        # First half should be at f_carrier - freq_dev
        assert abs(inst_freq_1 - (f_carrier - freq_dev)) < 10
        # Second half should be at f_carrier + freq_dev
        assert abs(inst_freq_2 - (f_carrier + freq_dev)) < 10


class TestDemodFm:
    """Tests for demod_fm function."""

    def test_output_shape_matches_input(self):
        """Output has same length as input."""
        fs = 10000
        t = np.arange(10000) / fs
        sig = np.sin(2 * np.pi * 100 * t)
        fm_signal = mod_fm(sig, fs, 1000, freq_deviation=500)

        result = demod_fm(fm_signal, fs, 1000, freq_deviation=500)
        assert result.shape == fm_signal.shape

    def test_output_is_real(self):
        """Output is real-valued."""
        fs = 10000
        t = np.arange(10000) / fs
        sig = np.sin(2 * np.pi * 100 * t)
        fm_signal = mod_fm(sig, fs, 1000, freq_deviation=500)

        result = demod_fm(fm_signal, fs, 1000, freq_deviation=500)
        assert result.dtype == np.float64

    def test_roundtrip_recovers_signal(self):
        """Modulate then demodulate recovers message."""
        fs = 10000
        t = np.arange(10000) / fs
        sig = np.sin(2 * np.pi * 100 * t)

        fm_signal = mod_fm(sig, fs, 2000, freq_deviation=500)
        recovered = demod_fm(fm_signal, fs, 2000, freq_deviation=500)

        # Trim edges where differentiation introduces errors
        sig_trimmed = sig[100:-100]
        recovered_trimmed = recovered[100:-100]

        # Should be highly correlated with original
        correlation = np.corrcoef(sig_trimmed, recovered_trimmed)[0, 1]
        assert correlation > 0.99

    def test_demod_handles_real_input(self):
        """Demodulation works with real FM signal via Hilbert transform."""
        fs = 10000
        t = np.arange(10000) / fs
        sig = np.sin(2 * np.pi * 100 * t)

        fm_signal = mod_fm(sig, fs, 2000, freq_deviation=500)
        real_fm = np.real(fm_signal)

        result = demod_fm(real_fm, fs, 2000, freq_deviation=500)
        assert result.dtype == np.float64

    @pytest.mark.parametrize(
        ("f_message", "freq_deviation"),
        [
            (50, 200),
            (100, 500),
            (200, 1000),
        ],
    )
    def test_recovers_different_frequencies(self, f_message, freq_deviation):
        """Demodulation works for different message frequencies."""
        fs = 20000
        t = np.arange(20000) / fs
        sig = np.sin(2 * np.pi * f_message * t)

        fm_signal = mod_fm(sig, fs, 5000, freq_deviation=freq_deviation)
        recovered = demod_fm(fm_signal, fs, 5000, freq_deviation=freq_deviation)

        # Trim edges and check correlation (more robust than spectral comparison)
        sig_trimmed = sig[100:-100]
        rec_trimmed = recovered[100:-100]

        correlation = np.corrcoef(sig_trimmed, rec_trimmed)[0, 1]
        assert correlation > 0.95
