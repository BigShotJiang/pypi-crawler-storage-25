"""Tests for spatial covariance matrix computation."""

from __future__ import annotations

import numpy as np
import pytest

from gri_signal.beamforming.covariance import spatial_covariance


def test_spatial_covariance_known_result() -> None:
    """Verify against hand-computed 2x2 result."""
    sig = np.array([[1.0, 2.0, 3.0], [4.0, 5.0, 6.0]])
    cov = spatial_covariance(sig)
    # R = sig @ sig.T = [[14, 32], [32, 77]]
    expected = np.array([[14.0, 32.0], [32.0, 77.0]])
    assert np.allclose(cov, expected)


def test_spatial_covariance_hermitian() -> None:
    """Covariance matrix should be Hermitian: R == R^H."""
    rng = np.random.default_rng(42)
    sig = rng.standard_normal((3, 50)) + 1j * rng.standard_normal((3, 50))
    cov = spatial_covariance(sig)
    assert np.allclose(cov, cov.T.conj())


def test_spatial_covariance_positive_semidefinite() -> None:
    """All eigenvalues of the covariance matrix should be >= 0."""
    rng = np.random.default_rng(7)
    sig = rng.standard_normal((4, 100)) + 1j * rng.standard_normal((4, 100))
    cov = spatial_covariance(sig)
    eigenvalues = np.linalg.eigvalsh(cov)
    assert np.all(eigenvalues >= -1e-10)


def test_spatial_covariance_rejects_transposed() -> None:
    """Should raise ValueError when input looks transposed."""
    sig = np.ones((10, 3))  # More channels than samples
    with pytest.raises(ValueError, match="transposed"):
        spatial_covariance(sig)
