"""Tests for MVDR (Capon) beamformer."""

from __future__ import annotations

import numpy as np

from gri_signal.beamforming.covariance import spatial_covariance
from gri_signal.beamforming.mvdr import mvdr_beamform, mvdr_weights
from gri_signal.sources.ula_steering import ula_steering

# Common array parameters
C = 3e8
FREQ = 1e9
WAVELENGTH = C / FREQ
D = WAVELENGTH / 2
N_ELEMENTS = 4
N_SAMPLES = 500


def test_mvdr_snr_improvement() -> None:
    """Steering to signal direction should improve correlation with source."""
    rng = np.random.default_rng(42)
    true_aoa = 15.0

    a = ula_steering(true_aoa, D, WAVELENGTH, N_ELEMENTS)
    source = rng.standard_normal(N_SAMPLES) + 1j * rng.standard_normal(N_SAMPLES)
    noise = 0.5 * (
        rng.standard_normal((N_ELEMENTS, N_SAMPLES))
        + 1j * rng.standard_normal((N_ELEMENTS, N_SAMPLES))
    )
    sig = a[:, np.newaxis] * source + noise

    cov = spatial_covariance(sig)
    output = mvdr_beamform(sig, cov, a, regularization=1e-6)

    # Beamformed output should correlate with the source better than
    # any individual channel (measures effective SNR improvement)
    def _corr_with_source(x: np.ndarray) -> float:
        return float(np.abs(np.vdot(x, source)) / np.linalg.norm(x))

    bf_corr = _corr_with_source(output)
    max_ch_corr = max(_corr_with_source(sig[ch]) for ch in range(N_ELEMENTS))
    assert bf_corr > max_ch_corr


def test_mvdr_steer_away_reduces_power() -> None:
    """Steering away from the signal should give lower power than steering toward it."""
    rng = np.random.default_rng(7)
    true_aoa = 20.0

    a_true = ula_steering(true_aoa, D, WAVELENGTH, N_ELEMENTS)
    source = rng.standard_normal(N_SAMPLES) + 1j * rng.standard_normal(N_SAMPLES)
    noise = 0.1 * (
        rng.standard_normal((N_ELEMENTS, N_SAMPLES))
        + 1j * rng.standard_normal((N_ELEMENTS, N_SAMPLES))
    )
    sig = a_true[:, np.newaxis] * source + noise

    cov = spatial_covariance(sig)

    # Steer toward signal
    out_toward = mvdr_beamform(sig, cov, a_true, regularization=1e-6)
    power_toward = float(np.mean(np.abs(out_toward) ** 2))

    # Steer away (60 degrees off)
    a_away = ula_steering(true_aoa + 60.0, D, WAVELENGTH, N_ELEMENTS)
    out_away = mvdr_beamform(sig, cov, a_away, regularization=1e-6)
    power_away = float(np.mean(np.abs(out_away) ** 2))

    assert power_toward > power_away


def test_mvdr_regularization_no_error() -> None:
    """Regularization should prevent errors on ill-conditioned input."""
    # Rank-1 covariance (singular without regularization)
    a = ula_steering(0.0, D, WAVELENGTH, N_ELEMENTS)
    cov = np.outer(a, a.conj())

    # Without regularization this would fail; with it, should succeed
    w = mvdr_weights(cov, a, regularization=1e-3)
    assert w.shape == (N_ELEMENTS,)


def test_mvdr_weights_shape() -> None:
    """Weight vector shape should match n_channels."""
    rng = np.random.default_rng(99)
    sig = rng.standard_normal((N_ELEMENTS, N_SAMPLES)) + 1j * rng.standard_normal(
        (N_ELEMENTS, N_SAMPLES),
    )
    cov = spatial_covariance(sig)
    a = ula_steering(0.0, D, WAVELENGTH, N_ELEMENTS)
    w = mvdr_weights(cov, a)
    assert w.shape == (N_ELEMENTS,)
