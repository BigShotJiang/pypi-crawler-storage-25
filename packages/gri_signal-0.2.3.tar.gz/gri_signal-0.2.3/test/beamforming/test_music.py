"""Tests for MUSIC spectrum DOA estimation."""

from __future__ import annotations

import numpy as np
import pytest
from scipy.signal import argrelmax

from gri_signal.beamforming.covariance import spatial_covariance
from gri_signal.beamforming.music import music_spectrum
from gri_signal.sources.ula_steering import ula_steering

# Common array parameters
C = 3e8
FREQ = 1e9
WAVELENGTH = C / FREQ
D = WAVELENGTH / 2
N_ELEMENTS = 4
N_SAMPLES = 500


def _make_steering_matrix(angles_deg: np.ndarray) -> np.ndarray:
    """Build (n_candidates, n_elements) steering matrix for a ULA."""
    return np.array(
        [ula_steering(a, D, WAVELENGTH, N_ELEMENTS) for a in angles_deg],
    )


def test_music_single_signal() -> None:
    """Spectrum peak should be within 1 degree of true AOA."""
    rng = np.random.default_rng(42)
    true_aoa = 20.0

    # Simulate received signal: steering_vector * source + noise
    a = ula_steering(true_aoa, D, WAVELENGTH, N_ELEMENTS)
    source = rng.standard_normal(N_SAMPLES) + 1j * rng.standard_normal(N_SAMPLES)
    noise = 0.1 * (
        rng.standard_normal((N_ELEMENTS, N_SAMPLES))
        + 1j * rng.standard_normal((N_ELEMENTS, N_SAMPLES))
    )
    sig = a[:, np.newaxis] * source + noise

    cov = spatial_covariance(sig)
    scan_angles = np.arange(-90, 90, 0.5)
    sv = _make_steering_matrix(scan_angles)
    spectrum = music_spectrum(cov, n_signals=1, steering_vectors=sv)

    peak_angle = scan_angles[np.argmax(spectrum)]
    assert abs(peak_angle - true_aoa) < 1.0


def test_music_two_signals() -> None:
    """Two signals at different angles should produce two distinct peaks."""
    rng = np.random.default_rng(99)
    aoa1, aoa2 = -30.0, 25.0

    a1 = ula_steering(aoa1, D, WAVELENGTH, N_ELEMENTS)
    a2 = ula_steering(aoa2, D, WAVELENGTH, N_ELEMENTS)
    s1 = rng.standard_normal(N_SAMPLES) + 1j * rng.standard_normal(N_SAMPLES)
    s2 = rng.standard_normal(N_SAMPLES) + 1j * rng.standard_normal(N_SAMPLES)
    noise = 0.1 * (
        rng.standard_normal((N_ELEMENTS, N_SAMPLES))
        + 1j * rng.standard_normal((N_ELEMENTS, N_SAMPLES))
    )
    sig = a1[:, np.newaxis] * s1 + a2[:, np.newaxis] * s2 + noise

    cov = spatial_covariance(sig)
    scan_angles = np.arange(-90, 90, 0.5)
    sv = _make_steering_matrix(scan_angles)
    spectrum = music_spectrum(cov, n_signals=2, steering_vectors=sv)

    # Find two highest peaks
    (peak_idx,) = argrelmax(spectrum, order=5)
    peak_vals = spectrum[peak_idx]
    top2_idx = peak_idx[np.argsort(peak_vals)[-2:]]
    top2_angles = sorted(scan_angles[top2_idx])

    assert abs(top2_angles[0] - aoa1) < 2.0
    assert abs(top2_angles[1] - aoa2) < 2.0


def test_music_n_signals_too_large() -> None:
    """n_signals >= n_channels should raise ValueError."""
    cov = np.eye(4, dtype=complex)
    sv = _make_steering_matrix(np.array([0.0]))
    with pytest.raises(ValueError, match="n_signals"):
        music_spectrum(cov, n_signals=4, steering_vectors=sv)


def test_music_output_shape() -> None:
    """Spectrum length should match number of candidate steering vectors."""
    cov = np.eye(N_ELEMENTS, dtype=complex)
    scan_angles = np.arange(-90, 90, 1.0)
    sv = _make_steering_matrix(scan_angles)
    spectrum = music_spectrum(cov, n_signals=1, steering_vectors=sv)
    assert spectrum.shape == (len(scan_angles),)
