"""Tests for batch beamforming functions."""

from __future__ import annotations

import numpy as np

from gri_signal.beamforming.batch import (
    batch_adaptive_beamform,
    batch_steering_angles,
)
from gri_signal.beamforming.single import adaptive_beamform


def test_batch_adaptive_beamform_single_section() -> None:
    """Test that single-section batch matches sequential processing."""
    arr = np.array([[1, 2, 3, 4, 5], [6, 7, 8, 9, 10]], dtype=np.complex128)
    sections = arr[np.newaxis, :, :]

    batch_beamformed, batch_steering = batch_adaptive_beamform(sections)
    seq_beamformed, _ = adaptive_beamform(arr)

    assert batch_beamformed.shape == (1, 2, 5)
    assert batch_steering.shape == (1, 2, 2)

    # Results should match (up to sign differences in eigenvectors)
    for ch in range(2):
        match = np.allclose(batch_beamformed[0, ch], seq_beamformed[ch])
        match_neg = np.allclose(batch_beamformed[0, ch], -seq_beamformed[ch])
        assert match or match_neg


def test_batch_adaptive_beamform_multiple_sections() -> None:
    """Test batch adaptive beamforming with multiple sections."""
    n_sections = 10
    n_channels = 2
    n_samples = 100

    rng = np.random.default_rng(42)
    sections = rng.standard_normal(
        (n_sections, n_channels, n_samples),
    ) + 1j * rng.standard_normal((n_sections, n_channels, n_samples))

    batch_beamformed, batch_steering = batch_adaptive_beamform(sections)

    assert batch_beamformed.shape == (n_sections, n_channels, n_samples)
    assert batch_steering.shape == (n_sections, n_channels, n_channels)

    # Verify each section matches sequential
    for i in range(n_sections):
        seq_beamformed, _ = adaptive_beamform(sections[i])
        for ch in range(n_channels):
            assert np.allclose(
                batch_beamformed[i, ch],
                seq_beamformed[ch],
            ) or np.allclose(batch_beamformed[i, ch], -seq_beamformed[ch])


def test_batch_adaptive_beamform_three_channel() -> None:
    """Test batch adaptive beamforming with 3-channel input."""
    n_sections = 5
    n_channels = 3
    n_samples = 100

    rng = np.random.default_rng(42)
    sections = rng.standard_normal(
        (n_sections, n_channels, n_samples),
    ) + 1j * rng.standard_normal((n_sections, n_channels, n_samples))

    batch_beamformed, batch_steering = batch_adaptive_beamform(sections)

    assert batch_beamformed.shape == (n_sections, n_channels, n_samples)
    assert batch_steering.shape == (n_sections, n_channels, n_channels)


def test_batch_adaptive_beamform_steering_orthonormal() -> None:
    """Test that batch steering vectors are orthonormal."""
    n_sections = 10
    n_channels = 2
    n_samples = 100

    rng = np.random.default_rng(42)
    sections = rng.standard_normal(
        (n_sections, n_channels, n_samples),
    ) + 1j * rng.standard_normal((n_sections, n_channels, n_samples))

    _, batch_steering = batch_adaptive_beamform(sections)

    # Verify eigenvectors are orthonormal
    for i in range(n_sections):
        inner = batch_steering[i].T.conj() @ batch_steering[i]
        assert np.allclose(inner, np.eye(n_channels), atol=1e-10)


def test_batch_steering_angles_shape() -> None:
    """Test that steering angles have correct shape."""
    n_sections = 10
    n_channels = 2
    n_samples = 100

    rng = np.random.default_rng(42)
    sections = rng.standard_normal(
        (n_sections, n_channels, n_samples),
    ) + 1j * rng.standard_normal((n_sections, n_channels, n_samples))

    _, steering_vecs = batch_adaptive_beamform(sections)
    angles = batch_steering_angles(steering_vecs)

    assert angles.shape == (n_sections, n_channels)


def test_batch_steering_angles_valid_range() -> None:
    """Test that steering angles are in [-180, 180] degrees."""
    n_sections = 10
    n_channels = 2
    n_samples = 100

    rng = np.random.default_rng(42)
    sections = rng.standard_normal(
        (n_sections, n_channels, n_samples),
    ) + 1j * rng.standard_normal((n_sections, n_channels, n_samples))

    _, steering_vecs = batch_adaptive_beamform(sections)
    angles = batch_steering_angles(steering_vecs)

    assert np.all(angles >= -180)
    assert np.all(angles <= 180)


def test_batch_steering_angles_three_channel() -> None:
    """Test steering angles with 3-channel input."""
    n_sections = 5
    n_channels = 3
    n_samples = 100

    rng = np.random.default_rng(42)
    sections = rng.standard_normal(
        (n_sections, n_channels, n_samples),
    ) + 1j * rng.standard_normal((n_sections, n_channels, n_samples))

    _, steering_vecs = batch_adaptive_beamform(sections)
    angles = batch_steering_angles(steering_vecs)

    assert angles.shape == (n_sections, n_channels)
    assert np.all(angles >= -180)
    assert np.all(angles <= 180)
