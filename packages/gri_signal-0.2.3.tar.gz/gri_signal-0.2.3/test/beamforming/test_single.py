"""Tests for single-section beamforming functions."""

from __future__ import annotations

import numpy as np
import pytest

from gri_signal.beamforming import single
from gri_signal.beamforming.batch import batch_steering_angles


def test_adaptive_beamform() -> None:
    """Verify end-to-end adaptive beamforming."""
    arr = np.array([[1, 2, 3, 4, 5], [6, 7, 8, 9, 10]])

    result, _ = single.adaptive_beamform(arr)

    expected = np.array(
        [
            [1.289036559767100, 5.944609722057772],
            [0.729582703228744, 7.243459745118311],
            [0.170128846690388, 8.542309768178850],
            [-0.389325009847968, 9.841159791239386],
            [-0.948778866386324, 11.140009814299926],
        ],
    ).T

    # Eigenvector sign ambiguity means result may be negated
    for res_row, exp_row in zip(result, expected, strict=True):
        assert np.allclose(exp_row, res_row) or np.allclose(exp_row, -res_row)


def test_adaptive_beamform_returns_steering() -> None:
    """Verify adaptive_beamform returns normalized steering vectors."""
    arr = np.array([[1, 2, 3, 4, 5], [6, 7, 8, 9, 10]])

    _, steering = single.adaptive_beamform(arr)

    # Steering vector should have shape (channels, channels)
    assert steering.shape == (2, 2)

    # Columns should be unit vectors (eigenvectors are normalized)
    for col in range(steering.shape[1]):
        assert np.isclose(np.linalg.norm(steering[:, col]), 1.0)


def test_adaptive_beamform_rejects_transposed_input() -> None:
    """Verify adaptive_beamform raises error for transposed input."""
    # More channels than samples - likely transposed
    arr = np.array([[1, 2], [3, 4], [5, 6], [7, 8], [9, 10]])

    with pytest.raises(ValueError, match="transposed"):
        single.adaptive_beamform(arr)


def test_steering_angles_shape() -> None:
    """Verify steering_angles output shape."""
    n_channels = 2
    n_samples = 100

    rng = np.random.default_rng(42)
    sig = rng.standard_normal(
        (n_channels, n_samples),
    ) + 1j * rng.standard_normal((n_channels, n_samples))

    _, steering_vec = single.adaptive_beamform(sig)
    angles = single.steering_angles(steering_vec)

    assert angles.shape == (n_channels,)


def test_steering_angles_valid_range() -> None:
    """Verify steering angles are in [-180, 180] degrees."""
    n_channels = 2
    n_samples = 100

    rng = np.random.default_rng(42)
    sig = rng.standard_normal(
        (n_channels, n_samples),
    ) + 1j * rng.standard_normal((n_channels, n_samples))

    _, steering_vec = single.adaptive_beamform(sig)
    angles = single.steering_angles(steering_vec)

    assert np.all(angles >= -180)
    assert np.all(angles <= 180)


def test_steering_angles_matches_batch() -> None:
    """Verify single steering_angles matches batch version for one section."""
    n_channels = 2
    n_samples = 100

    rng = np.random.default_rng(42)
    sig = rng.standard_normal(
        (n_channels, n_samples),
    ) + 1j * rng.standard_normal((n_channels, n_samples))

    _, steering_vec = single.adaptive_beamform(sig)
    single_angles = single.steering_angles(steering_vec)

    # Batch version with single section
    batch_steering = steering_vec[np.newaxis, :, :]
    batch_angles = batch_steering_angles(batch_steering)

    assert np.allclose(single_angles, batch_angles[0])
