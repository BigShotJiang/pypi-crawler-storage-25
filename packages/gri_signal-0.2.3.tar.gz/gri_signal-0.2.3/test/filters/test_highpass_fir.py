"""Tests for FIR highpass filter.

Functional tests verifying highpass_fir correctly passes high frequencies
and attenuates low frequencies while preserving phase.
"""

from __future__ import annotations

import numpy as np
import pytest
from scipy.signal import chirp

from gri_signal import (
    generate_complex_signal,
    get_freq_idx,
    get_max_power,
    get_psd,
    get_psd_power,
    highpass_fir,
)

# -----------------------------------------------------------------------------
# Passband - signal passes through with minimal distortion
# -----------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("signal_type", "description"),
    [
        ("real", "Real sinusoid"),
        ("complex", "Complex exponential"),
    ],
)
def test_highpass_passband(signal_type: str, description: str) -> None:
    """Verify signal in passband passes with minimal attenuation."""
    freq, cutoff, fs = 40, 30, 100
    t = np.arange(0, 100, 1 / fs)

    if signal_type == "real":
        sig = 10 * np.sin(2 * np.pi * freq * t)
    else:
        sig = 10 * np.exp(1j * 2 * np.pi * freq * t)

    psd_orig, freqs = get_psd(fs, sig)
    pow_orig = get_psd_power(freq, psd_orig, freqs)

    filtered = highpass_fir(fs, cutoff, sig)

    # Signal frequency power preserved (within 1 dB)
    max_pow, max_freq = get_max_power(fs, filtered)
    assert max_freq == pytest.approx(freq), description
    assert max_pow == pytest.approx(pow_orig, abs=1), description


def test_highpass_phase_preservation() -> None:
    """Verify zero-phase filtering preserves signal phase."""
    freq, fs = 40, 100
    t = np.arange(0, 100, 1 / fs)

    # Multi-component signal with different phases
    sig = 10 * np.exp(1j * 2 * np.pi * freq * t)
    sig += 10 * np.exp(1j * (2 * np.pi * freq * t + np.pi / 4))
    sig += 10 * np.exp(1j * (2 * np.pi * freq * t + np.pi / 2))
    sig += 10 * np.exp(1j * (2 * np.pi * freq * t + 3 * np.pi / 4))

    angle_orig = np.unwrap(np.angle(sig))
    filtered = highpass_fir(fs, 30, sig)
    angle_filt = np.unwrap(np.angle(filtered))

    # Align phases and compare (exclude edges due to filter transients)
    angle_filt = angle_filt - (angle_filt[100] - angle_orig[100])
    assert np.allclose(angle_orig[50:-50], angle_filt[50:-50])


# -----------------------------------------------------------------------------
# Stopband - low frequencies attenuated
# -----------------------------------------------------------------------------


def test_highpass_stopband_attenuation() -> None:
    """Verify frequencies below cutoff are strongly attenuated."""
    fs, cutoff = 500, 30
    t = np.arange(0, 100, 1 / fs)
    sig = chirp(t, 10, 100, 1000)  # Sweep 10-1000 Hz

    filtered = highpass_fir(fs, cutoff, sig, taps_order=20)
    psd_orig, freqs = get_psd(fs, sig)
    psd_filt, _ = get_psd(fs, filtered)
    maxpow, _ = get_max_power(fs, sig)

    # Stopband attenuated (5-23 Hz) - should be significantly reduced
    for f in range(5, 23):
        assert get_psd_power(f, psd_orig, freqs) > maxpow - 60
        assert get_psd_power(f, psd_filt, freqs) < maxpow - 60

    # Passband preserved (37-50 Hz)
    for f in range(37, 50):
        assert get_psd_power(f, psd_orig, freqs) == pytest.approx(
            get_psd_power(f, psd_filt, freqs),
            abs=1,
        )


# -----------------------------------------------------------------------------
# Multi-channel processing
# -----------------------------------------------------------------------------


def test_highpass_multi_channel() -> None:
    """Verify filter handles multi-channel signals correctly."""
    fs = int(30e9)
    cutoff = 5e9
    _, sig = generate_complex_signal(fs, channels=2, seed=42)

    filtered = highpass_fir(fs, cutoff, sig, taps_order=20)
    assert filtered.shape == sig.shape

    psd_orig, _ = get_psd(fs, sig)
    psd_filt, _ = get_psd(fs, filtered)
    n = sig.shape[1]

    # Near DC should be attenuated
    f3_neg = get_freq_idx(-3e9, fs, n)
    f3_pos = get_freq_idx(3e9, fs, n)
    for idx in range(f3_neg, f3_pos):
        assert psd_filt[0, idx] < 0
        assert psd_filt[1, idx] < 0

    # Above cutoff should be preserved
    f6_pos = get_freq_idx(6e9, fs, n)
    f10_pos = get_freq_idx(10e9, fs, n)
    for idx in range(f6_pos, f10_pos):
        if psd_orig[0, idx] > 0:
            assert psd_filt[0, idx] == pytest.approx(psd_orig[0, idx], abs=7)
        if psd_orig[1, idx] > 0:
            assert psd_filt[1, idx] == pytest.approx(psd_orig[1, idx], abs=7)
