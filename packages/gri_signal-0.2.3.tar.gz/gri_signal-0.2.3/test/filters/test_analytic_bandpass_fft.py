"""Tests for FFT-based analytic bandpass filter.

Functional tests verifying analytic_bandpass_fft correctly passes frequencies
in the specified range (including negative frequencies) while attenuating others.
"""

from __future__ import annotations

import numpy as np
import pytest
from scipy.signal import chirp

from gri_signal import analytic_bandpass_fft, get_max_power, get_psd, get_psd_power

# -----------------------------------------------------------------------------
# Negative frequency passband
# -----------------------------------------------------------------------------


def test_analytic_negative_passband() -> None:
    """Verify passband in negative frequencies works correctly."""
    fs = 500
    t = np.arange(0, 100, 1 / fs)
    sig = chirp(t, 10, 100, 1000)  # Broadband signal

    filtered = analytic_bandpass_fft(fs, -40, -20, sig, win_size=20)
    assert filtered.shape == sig.shape

    psd_orig, freqs = get_psd(fs, sig)
    psd_filt, _ = get_psd(fs, filtered)
    maxpow, _ = get_max_power(fs, sig)

    # Below passband attenuated (negative Nyquist to -41 Hz)
    for f in range(-int(fs // 2) + 1, -41):
        assert get_psd_power(f, psd_orig, freqs) > maxpow - 60
        assert get_psd_power(f, psd_filt, freqs) < maxpow - 60

    # Passband preserved (-39 to -21 Hz)
    for f in range(-39, -21):
        assert get_psd_power(f, psd_orig, freqs) == pytest.approx(
            get_psd_power(f, psd_filt, freqs),
            abs=1,
        )

    # Above passband attenuated (-19 Hz to positive Nyquist)
    for f in range(-19, int(fs // 2) - 1):
        assert get_psd_power(f, psd_orig, freqs) > maxpow - 60
        assert get_psd_power(f, psd_filt, freqs) < maxpow - 60


# -----------------------------------------------------------------------------
# Positive frequency passband
# -----------------------------------------------------------------------------


def test_analytic_positive_passband() -> None:
    """Verify passband in positive frequencies works correctly."""
    fs = 500
    t = np.arange(0, 100, 1 / fs)
    sig = chirp(t, 10, 100, 1000)  # Broadband signal

    filtered = analytic_bandpass_fft(fs, 20, 40, sig, win_size=20)
    assert filtered.shape == sig.shape

    psd_orig, freqs = get_psd(fs, sig)
    psd_filt, _ = get_psd(fs, filtered)
    maxpow, _ = get_max_power(fs, sig)

    # Below passband attenuated (negative Nyquist to 19 Hz)
    for f in range(-int(fs // 2) + 1, 19):
        assert get_psd_power(f, psd_orig, freqs) > maxpow - 60
        assert get_psd_power(f, psd_filt, freqs) < maxpow - 60

    # Passband preserved (21 to 39 Hz)
    for f in range(21, 39):
        assert get_psd_power(f, psd_orig, freqs) == pytest.approx(
            get_psd_power(f, psd_filt, freqs),
            abs=1,
        )

    # Above passband attenuated (41 Hz to positive Nyquist)
    for f in range(41, int(fs // 2) - 1):
        assert get_psd_power(f, psd_orig, freqs) > maxpow - 60
        assert get_psd_power(f, psd_filt, freqs) < maxpow - 60


# -----------------------------------------------------------------------------
# Passband crossing zero
# -----------------------------------------------------------------------------


def test_analytic_zero_crossing_passband() -> None:
    """Verify passband crossing zero frequency works correctly."""
    fs = 500
    t = np.arange(0, 100, 1 / fs)
    sig = chirp(t, 10, 100, 1000)  # Broadband signal

    filtered = analytic_bandpass_fft(fs, -10, 20, sig, win_size=20)
    assert filtered.shape == sig.shape

    psd_orig, freqs = get_psd(fs, sig)
    psd_filt, _ = get_psd(fs, filtered)
    maxpow, _ = get_max_power(fs, sig)

    # Below passband attenuated (negative Nyquist to -21 Hz)
    for f in range(-int(fs // 2) + 1, -21):
        assert get_psd_power(f, psd_orig, freqs) > maxpow - 60
        assert get_psd_power(f, psd_filt, freqs) < maxpow - 60

    # Passband preserved (-9 to 19 Hz)
    for f in range(-9, 19):
        assert get_psd_power(f, psd_orig, freqs) == pytest.approx(
            get_psd_power(f, psd_filt, freqs),
            abs=1,
        )

    # Above passband attenuated (21 Hz to positive Nyquist)
    for f in range(21, int(fs // 2) - 1):
        assert get_psd_power(f, psd_orig, freqs) > maxpow - 60
        assert get_psd_power(f, psd_filt, freqs) < maxpow - 60
