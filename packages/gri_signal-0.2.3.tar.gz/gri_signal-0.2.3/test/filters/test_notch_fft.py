"""Tests for FFT notch (bandstop) filter.

Functional tests verifying notch_fft correctly attenuates frequencies
within the notch band and passes frequencies outside.
"""

from __future__ import annotations

import numpy as np
import pytest
from scipy.signal import chirp

from gri_signal import (
    generate_complex_signal,
    get_freq_idx,
    get_max_power,
    get_psd,
    get_psd_power,
    notch_fft,
)

# -----------------------------------------------------------------------------
# Passband - signal passes through with minimal distortion
# -----------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("signal_type", "description"),
    [
        ("real", "Real sinusoid"),
        ("complex", "Complex exponential"),
    ],
)
def test_notch_passband_below(signal_type: str, description: str) -> None:
    """Verify signal below notch passes with minimal attenuation."""
    freq, low, high, fs = 10, 20, 30, 100
    t = np.arange(0, 100, 1 / fs)

    if signal_type == "real":
        sig = 10 * np.sin(2 * np.pi * freq * t)
    else:
        sig = 10 * np.exp(1j * 2 * np.pi * freq * t)

    psd_orig, freqs = get_psd(fs, sig)
    pow_orig = get_psd_power(freq, psd_orig, freqs)

    filtered = notch_fft(fs, low, high, sig)

    # Signal frequency power preserved (within 1 dB)
    max_pow, max_freq = get_max_power(fs, filtered)
    assert max_freq == pytest.approx(freq), description
    assert max_pow == pytest.approx(pow_orig, abs=1), description


@pytest.mark.parametrize(
    ("signal_type", "description"),
    [
        ("real", "Real sinusoid"),
        ("complex", "Complex exponential"),
    ],
)
def test_notch_passband_above(signal_type: str, description: str) -> None:
    """Verify signal above notch passes with minimal attenuation."""
    freq, low, high, fs = 40, 20, 30, 100
    t = np.arange(0, 100, 1 / fs)

    if signal_type == "real":
        sig = 10 * np.sin(2 * np.pi * freq * t)
    else:
        sig = 10 * np.exp(1j * 2 * np.pi * freq * t)

    psd_orig, freqs = get_psd(fs, sig)
    pow_orig = get_psd_power(freq, psd_orig, freqs)

    filtered = notch_fft(fs, low, high, sig)

    # Signal frequency power preserved (within 1 dB)
    max_pow, max_freq = get_max_power(fs, filtered)
    assert max_freq == pytest.approx(freq), description
    assert max_pow == pytest.approx(pow_orig, abs=1), description


# -----------------------------------------------------------------------------
# Stopband - notch frequencies attenuated
# -----------------------------------------------------------------------------


def test_notch_stopband_attenuation() -> None:
    """Verify frequencies within notch are strongly attenuated."""
    fs, low, high = 500, 20, 30
    t = np.arange(0, 100, 1 / fs)
    sig = chirp(t, 10, 100, 1000)  # Sweep 10-1000 Hz

    filtered = notch_fft(fs, low, high, sig, win_size=5)
    assert filtered.shape == sig.shape

    psd_orig, freqs = get_psd(fs, sig)
    psd_filt, _ = get_psd(fs, filtered)

    # Below notch preserved (5-17 Hz)
    for f in range(5, 17):
        assert get_psd_power(f, psd_orig, freqs) == pytest.approx(
            get_psd_power(f, psd_filt, freqs),
            abs=1,
        )

    # Notch band attenuated (23-27 Hz)
    for f in range(23, 27):
        assert get_psd_power(f, psd_orig, freqs) > -1
        assert get_psd_power(f, psd_filt, freqs) < -1

    # Above notch preserved (33-50 Hz)
    for f in range(33, 50):
        assert get_psd_power(f, psd_orig, freqs) == pytest.approx(
            get_psd_power(f, psd_filt, freqs),
            abs=1,
        )


# -----------------------------------------------------------------------------
# Multi-channel processing
# -----------------------------------------------------------------------------


def test_notch_multi_channel() -> None:
    """Verify filter handles multi-channel signals correctly."""
    fs = int(30e9)
    low, high = 4e9, 6e9
    _, sig = generate_complex_signal(fs, channels=2, seed=42)

    filtered = notch_fft(fs, low, high, sig, win_size=5)
    assert filtered.shape == sig.shape

    psd_orig, _ = get_psd(fs, sig)
    psd_filt, _ = get_psd(fs, filtered)
    n = sig.shape[1]

    # Below notch preserved (1-3 GHz)
    for idx in range(get_freq_idx(1e9, fs, n), get_freq_idx(3e9, fs, n)):
        if psd_orig[0, idx] > 0:
            assert psd_filt[0, idx] == pytest.approx(psd_orig[0, idx], abs=6)
        if psd_orig[1, idx] > 0:
            assert psd_filt[1, idx] == pytest.approx(psd_orig[1, idx], abs=6)

    # Notch band attenuated (4.5-5.5 GHz)
    for idx in range(get_freq_idx(4.5e9, fs, n), get_freq_idx(5.5e9, fs, n)):
        assert psd_filt[0, idx] < 0
        assert psd_filt[1, idx] < 0

    # Above notch preserved (7-10 GHz)
    for idx in range(get_freq_idx(7e9, fs, n), get_freq_idx(10e9, fs, n)):
        if psd_orig[0, idx] > 0:
            assert psd_filt[0, idx] == pytest.approx(psd_orig[0, idx], abs=6)
        if psd_orig[1, idx] > 0:
            assert psd_filt[1, idx] == pytest.approx(psd_orig[1, idx], abs=6)
