"""Tests for FFT-based bandpass filter.

Functional tests verifying bandpass_fft correctly passes frequencies
within the passband and attenuates frequencies outside while preserving phase.
"""

from __future__ import annotations

import numpy as np
import pytest
from scipy.signal import chirp

from gri_signal import (
    bandpass_fft,
    generate_complex_signal,
    get_freq_idx,
    get_max_power,
    get_psd,
    get_psd_power,
)

# -----------------------------------------------------------------------------
# Passband - signal passes through with minimal distortion
# -----------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("signal_type", "description"),
    [
        ("real", "Real sinusoid"),
        ("complex", "Complex exponential"),
    ],
)
def test_bandpass_passband(signal_type: str, description: str) -> None:
    """Verify signal in passband passes with minimal attenuation."""
    freq, low, high, fs = 25, 20, 30, 100
    t = np.arange(0, 100, 1 / fs)

    if signal_type == "real":
        sig = 10 * np.sin(2 * np.pi * freq * t)
    else:
        sig = 10 * np.exp(1j * 2 * np.pi * freq * t)

    psd_orig, freqs = get_psd(fs, sig)
    pow_orig = get_psd_power(freq, psd_orig, freqs)

    filtered = bandpass_fft(fs, low, high, sig)

    # Signal frequency power preserved (within 1 dB)
    max_pow, max_freq = get_max_power(fs, filtered)
    assert max_freq == pytest.approx(freq), description
    assert max_pow == pytest.approx(pow_orig, abs=1), description


def test_bandpass_phase_preservation() -> None:
    """Verify FFT filtering preserves signal phase perfectly."""
    freq, fs = 25, 100
    t = np.arange(0, 100, 1 / fs)

    # Multi-component signal with different phases
    sig = 10 * np.exp(1j * 2 * np.pi * freq * t)
    sig += 10 * np.exp(1j * (2 * np.pi * freq * t + np.pi / 4))
    sig += 10 * np.exp(1j * (2 * np.pi * freq * t + np.pi / 2))
    sig += 10 * np.exp(1j * (2 * np.pi * freq * t + 3 * np.pi / 4))

    angle_orig = np.unwrap(np.angle(sig))
    filtered = bandpass_fft(fs, 20, 45, sig)
    angle_filt = np.unwrap(np.angle(filtered))

    # Align phases and compare (FFT should preserve phase exactly)
    angle_filt = angle_filt - (angle_filt[100] - angle_orig[100])
    assert np.allclose(angle_orig, angle_filt)


# -----------------------------------------------------------------------------
# Stopband - frequencies outside passband attenuated
# -----------------------------------------------------------------------------


def test_bandpass_stopband_attenuation() -> None:
    """Verify frequencies outside passband are strongly attenuated."""
    fs, low, high = 500, 20, 30
    t = np.arange(0, 100, 1 / fs)
    sig = chirp(t, 10, 100, 1000)  # Sweep 10-1000 Hz

    filtered = bandpass_fft(fs, low, high, sig, win_size=10)
    assert filtered.shape == sig.shape

    psd_orig, freqs = get_psd(fs, sig)
    psd_filt, _ = get_psd(fs, filtered)
    maxpow, _ = get_max_power(fs, sig)

    # Below passband attenuated (1-19 Hz)
    for f in range(1, 19):
        assert get_psd_power(f, psd_orig, freqs) > maxpow - 60
        assert get_psd_power(f, psd_filt, freqs) < maxpow - 60

    # Passband preserved (21-29 Hz)
    for f in range(21, 29):
        assert get_psd_power(f, psd_orig, freqs) == pytest.approx(
            get_psd_power(f, psd_filt, freqs),
            abs=1,
        )

    # Above passband attenuated (31-50 Hz)
    for f in range(31, 50):
        assert get_psd_power(f, psd_orig, freqs) > maxpow - 60
        assert get_psd_power(f, psd_filt, freqs) < maxpow - 60


# -----------------------------------------------------------------------------
# Multi-channel processing
# -----------------------------------------------------------------------------


def test_bandpass_multi_channel() -> None:
    """Verify filter handles multi-channel signals correctly."""
    fs = int(30e9)
    low, high = 3e9, 7e9
    _, sig = generate_complex_signal(fs, channels=2, seed=42)

    filtered = bandpass_fft(fs, low, high, sig, win_size=30)
    assert filtered.shape == sig.shape

    psd_orig, _ = get_psd(fs, sig)
    psd_filt, _ = get_psd(fs, filtered)
    n = sig.shape[1]

    # Below passband attenuated
    for idx in range(get_freq_idx(-8e9, fs, n)):
        assert psd_filt[0, idx] < 0
        assert psd_filt[1, idx] < 0

    # Passband preserved (negative frequencies)
    for idx in range(get_freq_idx(-6e9, fs, n), get_freq_idx(-4e9, fs, n)):
        assert psd_filt[0, idx] == pytest.approx(psd_orig[0, idx], abs=3)
        assert psd_filt[1, idx] == pytest.approx(psd_orig[1, idx], abs=3)

    # Near DC attenuated
    for idx in range(get_freq_idx(-2e9, fs, n), get_freq_idx(2e9, fs, n)):
        assert psd_filt[0, idx] < 0
        assert psd_filt[1, idx] < 0

    # Passband preserved (positive frequencies)
    for idx in range(get_freq_idx(4e9, fs, n), get_freq_idx(6e9, fs, n)):
        assert psd_filt[0, idx] == pytest.approx(psd_orig[0, idx], abs=3)
        assert psd_filt[1, idx] == pytest.approx(psd_orig[1, idx], abs=3)

    # Above passband attenuated
    for idx in range(get_freq_idx(8e9, fs, n), n):
        assert psd_filt[0, idx] < 0
        assert psd_filt[1, idx] < 0
