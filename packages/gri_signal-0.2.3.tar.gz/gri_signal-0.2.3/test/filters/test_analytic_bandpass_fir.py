"""Tests for FIR analytic bandpass filter.

Functional tests verifying analytic_bandpass_fir correctly passes frequencies
in the specified range (including negative frequencies) while attenuating others.
"""

from __future__ import annotations

import numpy as np
import pytest
from scipy.signal import chirp

from gri_signal import analytic_bandpass_fir, get_max_power, get_psd, get_psd_power

# -----------------------------------------------------------------------------
# Negative frequency passband
# -----------------------------------------------------------------------------


def test_analytic_negative_passband() -> None:
    """Verify passband in negative frequencies works correctly."""
    fs = 500
    t = np.arange(0, 100, 1 / fs)
    sig = chirp(t, 10, 100, 1000)  # Broadband signal

    filtered = analytic_bandpass_fir(fs, -40, -20, sig, taps_order=20)
    assert filtered.shape == sig.shape

    psd_orig, freqs = get_psd(fs, sig)
    psd_filt, _ = get_psd(fs, filtered)
    maxpow, _ = get_max_power(fs, sig)

    # Below passband attenuated (negative Nyquist to -42 Hz)
    for f in range(-int(fs // 2) + 1, -42):
        assert get_psd_power(f, psd_orig, freqs) > maxpow - 60
        assert get_psd_power(f, psd_filt, freqs) < 20

    # Passband preserved (-38 to -22 Hz)
    for f in range(-38, -22):
        assert get_psd_power(f, psd_orig, freqs) == pytest.approx(
            get_psd_power(f, psd_filt, freqs),
            abs=3,
        )

    # Above passband attenuated (-15 Hz to positive Nyquist)
    for f in range(-15, int(fs // 2) - 1):
        assert get_psd_power(f, psd_orig, freqs) > maxpow - 60
        assert get_psd_power(f, psd_filt, freqs) < 20


# -----------------------------------------------------------------------------
# Positive frequency passband
# -----------------------------------------------------------------------------


def test_analytic_positive_passband() -> None:
    """Verify passband in positive frequencies works correctly."""
    fs = 500
    t = np.arange(0, 100, 1 / fs)
    sig = chirp(t, 10, 100, 1000)  # Broadband signal

    filtered = analytic_bandpass_fir(fs, 20, 40, sig, taps_order=20)
    assert filtered.shape == sig.shape

    psd_orig, freqs = get_psd(fs, sig)
    psd_filt, _ = get_psd(fs, filtered)
    maxpow, _ = get_max_power(fs, sig)

    # Below passband attenuated (negative Nyquist to 17 Hz)
    for f in range(-int(fs // 2) + 1, 17):
        assert get_psd_power(f, psd_orig, freqs) > maxpow - 60
        assert get_psd_power(f, psd_filt, freqs) < 20

    # Passband preserved (22 to 38 Hz)
    for f in range(22, 38):
        assert get_psd_power(f, psd_orig, freqs) == pytest.approx(
            get_psd_power(f, psd_filt, freqs),
            abs=3,
        )

    # Above passband attenuated (42 Hz to positive Nyquist)
    for f in range(42, int(fs // 2) - 1):
        assert get_psd_power(f, psd_orig, freqs) > maxpow - 60
        assert get_psd_power(f, psd_filt, freqs) < 20


# -----------------------------------------------------------------------------
# Passband crossing zero
# -----------------------------------------------------------------------------


def test_analytic_zero_crossing_passband() -> None:
    """Verify passband crossing zero frequency works correctly."""
    fs = 500
    t = np.arange(0, 100, 1 / fs)
    sig = chirp(t, 10, 100, 1000)  # Broadband signal

    filtered = analytic_bandpass_fir(fs, -10, 20, sig, taps_order=20)
    assert filtered.shape == sig.shape

    psd_orig, freqs = get_psd(fs, sig)
    psd_filt, _ = get_psd(fs, filtered)
    maxpow, _ = get_max_power(fs, sig)

    # Below passband attenuated (negative Nyquist to -22 Hz)
    for f in range(-int(fs // 2) + 1, -22):
        assert get_psd_power(f, psd_orig, freqs) > maxpow - 60
        assert get_psd_power(f, psd_filt, freqs) < 20

    # Passband preserved (-8 to 18 Hz)
    for f in range(-8, 18):
        assert get_psd_power(f, psd_orig, freqs) == pytest.approx(
            get_psd_power(f, psd_filt, freqs),
            abs=2,
        )

    # Above passband attenuated (22 Hz to positive Nyquist)
    for f in range(22, int(fs // 2) - 1):
        assert get_psd_power(f, psd_orig, freqs) > maxpow - 60
        assert get_psd_power(f, psd_filt, freqs) < 20
