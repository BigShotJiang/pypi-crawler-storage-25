"""Tests for FIR lowpass filter.

Functional tests verifying lowpass_fir correctly passes low frequencies
and attenuates high frequencies while preserving phase.
"""

from __future__ import annotations

import numpy as np
import pytest
from scipy.signal import chirp

from gri_signal import (
    generate_complex_signal,
    get_freq_idx,
    get_max_power,
    get_psd,
    get_psd_power,
    lowpass_fir,
)

# -----------------------------------------------------------------------------
# Passband - signal passes through with minimal distortion
# -----------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("signal_type", "description"),
    [
        ("real", "Real sinusoid"),
        ("complex", "Complex exponential"),
    ],
)
def test_lowpass_passband(signal_type: str, description: str) -> None:
    """Verify signal in passband passes with minimal attenuation."""
    freq, cutoff, fs = 15, 30, 100
    t = np.arange(0, 100, 1 / fs)

    if signal_type == "real":
        sig = 10 * np.sin(2 * np.pi * freq * t)
    else:
        sig = 10 * np.exp(1j * 2 * np.pi * freq * t)

    psd_orig, freqs = get_psd(fs, sig)
    pow_orig = get_psd_power(freq, psd_orig, freqs)

    filtered = lowpass_fir(fs, cutoff, sig)

    # Signal frequency power preserved (within 1 dB)
    max_pow, max_freq = get_max_power(fs, filtered)
    assert max_freq == pytest.approx(freq), description
    assert max_pow == pytest.approx(pow_orig, abs=1), description


def test_lowpass_phase_preservation() -> None:
    """Verify FIR filtering preserves signal phase."""
    freq, fs = 15, 100
    t = np.arange(0, 100, 1 / fs)

    # Multi-component signal with different phases
    sig = 10 * np.exp(1j * 2 * np.pi * freq * t)
    sig += 10 * np.exp(1j * (2 * np.pi * freq * t + np.pi / 4))
    sig += 10 * np.exp(1j * (2 * np.pi * freq * t + np.pi / 2))
    sig += 10 * np.exp(1j * (2 * np.pi * freq * t + 3 * np.pi / 4))

    angle_orig = np.unwrap(np.angle(sig))
    filtered = lowpass_fir(fs, 45, sig)
    angle_filt = np.unwrap(np.angle(filtered))

    # Align phases and compare (exclude edges due to filter transients)
    angle_filt = angle_filt - (angle_filt[100] - angle_orig[100])
    assert np.allclose(angle_orig[20:-20], angle_filt[20:-20])


# -----------------------------------------------------------------------------
# Stopband - high frequencies attenuated
# -----------------------------------------------------------------------------


def test_lowpass_stopband_attenuation() -> None:
    """Verify frequencies above cutoff are strongly attenuated."""
    fs, cutoff = 500, 30
    t = np.arange(0, 100, 1 / fs)
    sig = chirp(t, 10, 100, 1000)  # Sweep 10-1000 Hz

    filtered = lowpass_fir(fs, cutoff, sig, taps_order=20)
    psd_orig, freqs = get_psd(fs, sig)
    psd_filt, _ = get_psd(fs, filtered)
    maxpow, _ = get_max_power(fs, sig)

    # Passband preserved (5-23 Hz)
    for f in range(5, 23):
        assert get_psd_power(f, psd_orig, freqs) == pytest.approx(
            get_psd_power(f, psd_filt, freqs),
            abs=1,
        )

    # Stopband attenuated (37-50 Hz) - >60 dB below passband
    for f in range(37, 50):
        assert get_psd_power(f, psd_orig, freqs) > maxpow - 60
        assert get_psd_power(f, psd_filt, freqs) < maxpow - 60


# -----------------------------------------------------------------------------
# Multi-channel processing
# -----------------------------------------------------------------------------


def test_lowpass_multi_channel() -> None:
    """Verify filter handles multi-channel signals correctly."""
    fs = int(30e9)
    cutoff = 7e9
    _, sig = generate_complex_signal(fs, channels=2, seed=42)

    filtered = lowpass_fir(fs, cutoff, sig, taps_order=20)
    assert filtered.shape == sig.shape

    psd_filt, _ = get_psd(fs, filtered)
    n = sig.shape[1]

    # Outside cutoff should be attenuated (negative dB)
    f8_neg = get_freq_idx(-8e9, fs, n)
    for idx in range(f8_neg):
        assert psd_filt[0, idx] < 0
        assert psd_filt[1, idx] < 0

    # High frequencies should be attenuated
    f8_pos = get_freq_idx(8e9, fs, n)
    for idx in range(f8_pos, n):
        assert psd_filt[0, idx] < 0
        assert psd_filt[1, idx] < 0
