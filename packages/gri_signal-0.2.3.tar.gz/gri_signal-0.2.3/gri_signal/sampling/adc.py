"""Simulate analog-to-digital converter (ADC) quantization."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from numpy.typing import NDArray


def adc(
    sig: NDArray[np.floating | np.complexfloating],
    n_bits: int,
) -> NDArray[np.complexfloating]:
    """Simulate an n-bit analog-to-digital converter (ADC).

    Quantizes the input signal to the specified bit depth by mapping the full
    signal range to 2^n_bits discrete quantization levels.

    Args:
        sig: Input signal to be quantized. Can be real or complex, any shape.
            For complex signals, both real and imaginary parts are quantized
            together using the same min/max range.
        n_bits: Number of bits for the ADC. Common values are 8, 10, 12, 14, 16.

    Returns:
        Quantized signal as complex array with the same shape as input.

    Examples:
        >>> # 12-bit ADC (common in SDR hardware)
        >>> sig = np.random.randn(1000) + 1j * np.random.randn(1000)
        >>> quantized = adc(sig, 12)

        >>> # 8-bit ADC
        >>> quantized_8bit = adc(sig, 8)

        >>> # Multi-channel signal
        >>> sig = np.random.randn(4, 1000) + 1j * np.random.randn(4, 1000)
        >>> quantized = adc(sig, 12)

    Notes:
        The quantization maps the signal range [min, max] to [0, 2^n_bits - 1]
        discrete levels, then maps back to the original range. This preserves
        the signal's amplitude scale while introducing quantization noise.

        Quantization noise power is approximately: (signal_range)^2 / (12 * 4^n_bits)

        For complex signals, the real and imaginary parts share the same
        quantization range, preserving their correlation.
    """
    # Ensure complex output
    sig = np.asarray(sig, dtype=np.complex128)

    # Find signal range (using complex min/max)
    min_val = np.min(sig)
    max_val = np.max(sig)
    signal_range = max_val - min_val

    # Handle constant signal (zero range)
    if signal_range == 0:
        return sig

    # Number of quantization levels
    n_levels = 2**n_bits

    # Map signal to [0, n_levels - 1]
    normalized = (sig - min_val) / signal_range
    quantized_idx = np.round(normalized * (n_levels - 1))

    # Map back to original range
    return quantized_idx / (n_levels - 1) * signal_range + min_val
