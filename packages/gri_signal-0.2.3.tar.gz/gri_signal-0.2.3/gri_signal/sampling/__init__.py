"""Sampling and digitization.

Provides functions for simulating analog-to-digital conversion,
quantization, and sampling operations.
"""

from .adc import adc

__all__ = [
    "adc",
]
