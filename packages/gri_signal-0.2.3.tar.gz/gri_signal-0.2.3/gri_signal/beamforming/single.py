"""Single-section beamforming operations.

Provides adaptive beamforming and steering angle computation for multi-channel
signal processing on individual signal sections.

For processing multiple sections at once, see the batch module.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from scipy.linalg import eigh

from .covariance import spatial_covariance

if TYPE_CHECKING:
    from numpy.typing import NDArray


def adaptive_beamform(
    sig: NDArray,
) -> tuple[NDArray, NDArray]:
    """Adaptive beamforming for multi-channel input signal.

    Performs eigendecomposition-based beamforming to separate signals by
    direction of arrival. The algorithm:

    1. Computes spatial covariance matrix: C = sig @ sig.conj().T
    2. Eigendecomposes C to get steering vectors (eigenvectors sorted by
       eigenvalue in ascending order)
    3. Projects signal onto steering vectors: beamformed = V.conj().T @ sig

    Args:
        sig: N channels to beamform, shape (n_channels, n_samples).
            Must have more samples than channels.

    Returns:
        Tuple of (beamformed_signal, steering_vectors):
            - beamformed_signal: Shape (n_channels, n_samples). Channel 0 is the
              most nulled direction (smallest eigenvalue), channel N-1 is the
              maximum power direction (largest eigenvalue).
            - steering_vectors: Shape (n_channels, n_channels). Eigenvectors as
              columns, sorted by eigenvalue ascending.

    Raises:
        ValueError: If signal has more channels than samples (likely transposed).
    """
    covariance = spatial_covariance(sig)

    # Eigendecomposition - eigh returns eigenvalues in ascending order
    _eigenvalues, steering_vecs = eigh(covariance)

    # Project signal onto steering vectors
    beamformed = steering_vecs.T.conj() @ sig

    return beamformed, steering_vecs


def steering_angles(steering_vecs: NDArray) -> NDArray:
    """Compute steering angles from steering vectors.

    For each eigenvector, computes the angle from the phase difference between
    the first and second channel elements. This provides an uncalibrated phase
    metric useful for distinguishing beam directions.

    Args:
        steering_vecs: Shape (n_channels, n_channels) from adaptive_beamform()

    Returns:
        Steering angles in degrees, shape (n_channels,), wrapped to [-180, 180].
        Each element corresponds to one eigenvector (sorted by eigenvalue ascending).
    """
    deg: NDArray = np.angle(steering_vecs[0, :] - steering_vecs[1, :], deg=True)
    return (deg + 180) % 360 - 180
