"""Spatial covariance matrix computation."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from numpy.typing import NDArray


def spatial_covariance(
    sig: NDArray,
) -> NDArray:
    """Spatial covariance matrix of a multi-channel signal.

    Computes R = sig @ sig^H, the Hermitian spatial covariance matrix.
    This is the fundamental input to eigenvalue beamforming, MUSIC,
    and MVDR.

    Args:
        sig: Multi-channel signal, shape (n_channels, n_samples).
            Must have more samples than channels.

    Returns:
        Hermitian covariance matrix, shape (n_channels, n_channels).

    Raises:
        ValueError: If signal has more channels than samples.
    """
    if sig.ndim > 1 and sig.shape[0] > sig.shape[1]:
        raise ValueError("more signals than readings ... is array transposed?")
    return sig @ sig.T.conj()
