"""Batched beamforming operations for processing multiple sections at once.

Provides vectorized beamforming using numpy broadcasting and einsum to process
all sections simultaneously. This reduces Python loop overhead and enables
better CPU cache utilization.

Supports 2 or more channels.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from numpy.typing import NDArray


def batch_adaptive_beamform(
    sections: NDArray,
) -> tuple[NDArray, NDArray]:
    """Batched adaptive beamforming for multiple sections.

    Performs eigendecomposition-based beamforming on all sections simultaneously.
    The algorithm for each section:

    1. Computes spatial covariance: C[n] = sections[n] @ sections[n].conj().T
       (vectorized via einsum: "nik,njk->nij")
    2. Batch eigendecomposes all covariance matrices (np.linalg.eigh)
    3. Projects each section onto its steering vectors:
       beamformed[n] = V[n].conj().T @ sections[n]

    Args:
        sections: IQ data of shape (n_sections, n_channels, n_samples)

    Returns:
        Tuple of (beamformed_signals, steering_vectors):
            - beamformed_signals: Shape (n_sections, n_channels, n_samples).
              Channel 0 is most nulled, channel -1 is max power.
            - steering_vectors: Shape (n_sections, n_channels, n_channels)
    """
    # Batch spatial covariance via einsum
    covariances = np.einsum("nik,njk->nij", sections, sections.conj())

    # Batch eigendecomposition - eigh returns eigenvalues in ascending order
    _eigenvalues, steering_vecs = np.linalg.eigh(covariances)

    # Batch projection: steering.conj().T @ sections for each section
    beamformed = steering_vecs.conj().transpose(0, 2, 1) @ sections

    return beamformed, steering_vecs


def batch_steering_angles(steering_vecs: NDArray) -> NDArray:
    """Compute steering angles from batched steering vectors.

    For each eigenvector, computes the angle from the phase difference between
    the first and second channel elements. This provides an uncalibrated phase
    metric useful for distinguishing beam directions.

    Args:
        steering_vecs: Shape (n_sections, n_channels, n_channels)

    Returns:
        Steering angles in degrees, shape (n_sections, n_channels), wrapped to
        [-180, 180]. Each column corresponds to one eigenvector (sorted by
        eigenvalue ascending).
    """
    deg: NDArray = np.angle(steering_vecs[:, 0, :] - steering_vecs[:, 1, :], deg=True)
    return (deg + 180) % 360 - 180
