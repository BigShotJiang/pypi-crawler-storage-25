"""Beamforming and spatial processing functions.

Provides adaptive beamforming, steering angle computation, MUSIC DOA
estimation, and MVDR beamforming for multi-channel signal processing.

Single-section functions:
    - adaptive_beamform: Complete beamforming pipeline for one section
    - steering_angles: Compute steering angles from vectors
    - spatial_covariance: Spatial covariance matrix
    - music_spectrum: MUSIC DOA pseudo-spectrum
    - mvdr_weights: MVDR weight vector
    - mvdr_beamform: MVDR beamforming with interference suppression

Batch functions (for processing multiple sections at once):
    - batch_adaptive_beamform: Vectorized beamforming for all sections
    - batch_steering_angles: Compute steering angles from vectors
"""

from .batch import (
    batch_adaptive_beamform,
    batch_steering_angles,
)
from .covariance import spatial_covariance
from .music import music_spectrum
from .mvdr import mvdr_beamform, mvdr_weights
from .single import (
    adaptive_beamform,
    steering_angles,
)

__all__ = [
    "adaptive_beamform",
    "batch_adaptive_beamform",
    "batch_steering_angles",
    "music_spectrum",
    "mvdr_beamform",
    "mvdr_weights",
    "spatial_covariance",
    "steering_angles",
]
