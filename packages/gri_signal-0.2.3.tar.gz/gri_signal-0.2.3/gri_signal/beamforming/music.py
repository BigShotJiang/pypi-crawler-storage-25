"""MUSIC (Multiple Signal Classification) DOA estimation."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from scipy.linalg import eigh

if TYPE_CHECKING:
    from numpy.typing import NDArray


def music_spectrum(
    covariance: NDArray,
    n_signals: int,
    steering_vectors: NDArray,
) -> NDArray:
    """MUSIC spatial spectrum for direction-of-arrival estimation.

    Computes the MUSIC pseudo-spectrum by projecting candidate steering
    vectors onto the noise subspace of the spatial covariance matrix.
    Peaks in the output correspond to signal directions of arrival.

    The noise subspace is the span of the (n_channels - n_signals)
    eigenvectors corresponding to the smallest eigenvalues of the
    covariance matrix.

    Args:
        covariance: Spatial covariance matrix, shape
            (n_channels, n_channels). Hermitian positive semi-definite.
            Compute with spatial_covariance().
        n_signals: Number of signals present. Must be < n_channels.
        steering_vectors: Candidate steering vectors to scan, shape
            (n_candidates, n_channels). Each row is a steering vector
            for one candidate direction.

    Returns:
        MUSIC pseudo-spectrum, shape (n_candidates,). Peaks indicate
        estimated signal directions. Values are in linear scale
        (not dB).

    Raises:
        ValueError: If n_signals >= n_channels.
    """
    n_channels = covariance.shape[0]
    if n_signals >= n_channels:
        msg = f"n_signals ({n_signals}) must be < n_channels ({n_channels})"
        raise ValueError(msg)

    # Eigendecomposition -- eigh returns eigenvalues ascending
    _eigvals, eigvecs = eigh(covariance)

    # Noise subspace: eigenvectors for the smallest eigenvalues
    n_noise = n_channels - n_signals
    u_n = eigvecs[:, :n_noise]  # (n_channels, n_noise)

    # Projection matrix: U_N @ U_N^H
    u_n_proj = u_n @ u_n.T.conj()  # (n_channels, n_channels)

    # Vectorized spectrum: 1 / |a^H @ U_N @ U_N^H @ a| for each row a
    # steering_vectors: (n_candidates, n_channels)
    temp = steering_vectors.conj() @ u_n_proj  # (n_candidates, n_channels)
    denominator = np.abs(np.sum(temp * steering_vectors, axis=1))

    return 1.0 / (denominator + 1e-10)
