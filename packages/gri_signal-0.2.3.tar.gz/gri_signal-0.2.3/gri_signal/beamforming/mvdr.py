"""MVDR (Minimum Variance Distortionless Response) beamformer."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from scipy.linalg import solve

if TYPE_CHECKING:
    from numpy.typing import NDArray


def mvdr_weights(
    covariance: NDArray,
    steering_vector: NDArray,
    regularization: float = 0.0,
) -> NDArray:
    """MVDR (Capon) beamformer weight vector.

    Computes the weight vector that minimizes output power subject
    to a distortionless constraint in the look direction:

        w = (R^-1 @ a) / (a^H @ R^-1 @ a)

    Args:
        covariance: Spatial covariance matrix, shape
            (n_channels, n_channels).
        steering_vector: Steering vector for the desired look
            direction, shape (n_channels,).
        regularization: Diagonal loading factor. Added to the
            diagonal of the covariance matrix before inversion
            for numerical stability. Default 0.0 (no loading).

    Returns:
        Weight vector, shape (n_channels,).
    """
    r = covariance
    if regularization > 0:
        r = r + regularization * np.eye(r.shape[0], dtype=r.dtype)

    r_inv_a = solve(r, steering_vector, assume_a="her")
    return r_inv_a / (steering_vector.conj() @ r_inv_a)


def mvdr_beamform(
    sig: NDArray,
    covariance: NDArray,
    steering_vector: NDArray,
    regularization: float = 0.0,
) -> NDArray:
    """Apply MVDR beamforming to multi-channel signal data.

    Computes MVDR weights and applies them to produce a single-channel
    output with interference suppressed:

        y = w^H @ X

    Args:
        sig: Multi-channel signal, shape (n_channels, n_samples).
        covariance: Spatial covariance matrix, shape
            (n_channels, n_channels).
        steering_vector: Steering vector for the desired look
            direction, shape (n_channels,).
        regularization: Diagonal loading factor. Default 0.0.

    Returns:
        Beamformed output, shape (n_samples,).
    """
    w = mvdr_weights(covariance, steering_vector, regularization)
    return w.conj() @ sig
