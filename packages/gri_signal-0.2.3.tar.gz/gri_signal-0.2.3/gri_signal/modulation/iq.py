"""IQ (in-phase/quadrature) signal conversion utilities."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from scipy.signal import hilbert

if TYPE_CHECKING:
    from numpy.typing import NDArray


def passband_to_iq(
    sig: NDArray[np.floating],
    fs: float,
    f_center: float,
) -> NDArray[np.complexfloating]:
    """Convert a real passband signal to complex baseband (IQ).

    Performs frequency translation from passband (centered at f_center) to
    baseband (centered at 0 Hz) using the analytic signal representation.

    Args:
        sig: Real-valued passband signal as a 1D array.
        fs: Sample rate in Hz.
        f_center: Center frequency in Hz to translate to baseband.

    Returns:
        Complex baseband (IQ) signal with the same length as input.

    Examples:
        >>> # Convert a 1 MHz signal sampled at 10 MHz to baseband
        >>> t = np.arange(10000) / 10e6
        >>> passband = np.cos(2 * np.pi * 1e6 * t)
        >>> iq = passband_to_iq(passband, 10e6, 1e6)

        >>> # The result is centered at DC
        >>> # A pure tone at f_center becomes a DC component in IQ

    Notes:
        The conversion process:
        1. Compute the analytic signal (real + j*Hilbert transform)
        2. Frequency shift by multiplying with exp(-j*2*pi*f_center*t)

        This is equivalent to mixing with a local oscillator and lowpass
        filtering, but implemented in the frequency domain for efficiency.
    """
    n = len(sig)
    t = np.arange(n) / fs

    # Get analytic signal (positive frequencies only)
    analytic = hilbert(sig)

    # Frequency shift to baseband
    shift = np.exp(-1j * 2 * np.pi * f_center * t)
    return np.asarray(analytic * shift, dtype=np.complex128)


def iq_to_passband(
    sig: NDArray[np.complexfloating],
    fs: float,
    f_center: float,
) -> NDArray[np.floating]:
    """Convert a complex baseband (IQ) signal to real passband.

    Performs frequency translation from baseband (centered at 0 Hz) to
    passband (centered at f_center).

    Args:
        sig: Complex baseband (IQ) signal as a 1D array.
        fs: Sample rate in Hz.
        f_center: Center frequency in Hz for the output passband signal.

    Returns:
        Real-valued passband signal with the same length as input.

    Examples:
        >>> # Create a baseband signal and upconvert to 1 MHz
        >>> iq = np.exp(1j * 2 * np.pi * 1000 * np.arange(10000) / 1e6)  # 1 kHz tone
        >>> passband = iq_to_passband(iq, 1e6, 1e6)
        >>> # Result is a 1.001 MHz real sinusoid

        >>> # Round-trip conversion
        >>> original_iq = np.exp(1j * np.pi / 4) * np.ones(1000)  # Constant phase
        >>> passband = iq_to_passband(original_iq, 10e6, 1e6)
        >>> recovered_iq = passband_to_iq(passband, 10e6, 1e6)

    Notes:
        The conversion is: passband = Re{IQ * exp(j*2*pi*f_center*t)}

        This is the standard upconversion operation used in transmitters
        to translate baseband signals to RF.
    """
    n = len(sig)
    t = np.arange(n) / fs

    # Frequency shift to passband
    shift = np.exp(1j * 2 * np.pi * f_center * t)
    passband: NDArray[np.floating] = np.real(sig * shift)

    return passband
