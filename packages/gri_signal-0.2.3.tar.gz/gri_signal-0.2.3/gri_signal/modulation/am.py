"""Amplitude modulation (AM) functions."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from scipy.signal import hilbert

if TYPE_CHECKING:
    from numpy.typing import NDArray


def mod_am(
    sig: NDArray[np.floating],
    fs: float,
    f_carrier: float,
    *,
    mod_index: float = 1.0,
) -> NDArray[np.complexfloating]:
    """Apply amplitude modulation to a baseband signal.

    Creates an AM signal by modulating a carrier with the input signal.
    The output is a complex exponential with amplitude variations.

    Args:
        sig: Real-valued baseband message signal (should be normalized to [-1, 1]).
        fs: Sample rate in Hz.
        f_carrier: Carrier frequency in Hz.
        mod_index: Modulation index (depth). 1.0 = 100% modulation.
            Values > 1 cause overmodulation. Defaults to 1.0.

    Returns:
        Complex AM signal with carrier at f_carrier.

    Examples:
        >>> # Modulate a 100 Hz tone onto a 1 kHz carrier
        >>> t = np.arange(10000) / 10000
        >>> message = np.sin(2 * np.pi * 100 * t)
        >>> am_signal = mod_am(message, 10000, 1000, mod_index=0.5)

    Notes:
        The AM signal is: s(t) = (1 + m * sig(t)) * exp(j * 2π * fc * t)

        where m is the modulation index. The envelope of the signal
        follows the shape of the input message.
    """
    sig = np.asarray(sig, dtype=np.float64)
    n = len(sig)
    t = np.arange(n) / fs

    # Generate carrier
    carrier = np.exp(1j * 2 * np.pi * f_carrier * t)

    # Apply amplitude modulation
    envelope = 1 + mod_index * sig
    return np.asarray(envelope * carrier, dtype=np.complex128)


def demod_am(
    sig: NDArray[np.floating | np.complexfloating],
    fs: float,  # noqa: ARG001
    f_carrier: float,
) -> NDArray[np.floating]:
    """Demodulate an AM signal using envelope detection.

    Recovers the baseband message from an amplitude-modulated signal
    using the Hilbert transform for envelope detection.

    Args:
        sig: AM signal (real or complex). If real, the analytic signal
            is computed internally.
        fs: Sample rate in Hz.
        f_carrier: Carrier frequency in Hz (used for reference, not filtering).

    Returns:
        Recovered baseband message signal (AC-coupled, normalized).

    Examples:
        >>> # Round-trip AM modulation/demodulation
        >>> t = np.arange(10000) / 10000
        >>> message = np.sin(2 * np.pi * 100 * t)
        >>> am_signal = mod_am(message, 10000, 1000, mod_index=0.5)
        >>> recovered = demod_am(am_signal, 10000, 1000)

    Notes:
        Envelope detection extracts |analytic_signal|, then removes the
        DC component (carrier) and normalizes. This works well for
        mod_index <= 1. Overmodulated signals may not demodulate correctly.
    """
    _ = f_carrier  # Reserved for future use (e.g., bandpass filtering)

    sig = np.asarray(sig)

    # Get envelope via analytic signal
    if np.iscomplexobj(sig):
        envelope = np.abs(sig)
    else:
        analytic = np.asarray(hilbert(sig))
        envelope = np.abs(analytic)

    # Remove DC (carrier component) and normalize
    envelope_ac = envelope - np.mean(envelope)

    # Normalize to approximately [-1, 1] range
    max_val = np.max(np.abs(envelope_ac))
    if max_val > 0:
        envelope_ac = envelope_ac / max_val

    return np.asarray(envelope_ac, dtype=np.float64)
