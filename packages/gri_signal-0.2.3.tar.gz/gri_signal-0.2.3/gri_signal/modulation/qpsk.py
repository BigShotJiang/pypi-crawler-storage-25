"""Quadrature Phase Shift Keying (QPSK) modulation functions."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from numpy.typing import NDArray

# QPSK constellation (Gray coded)
# Bit pairs map to unit circle points at 45°, 135°, 225°, 315°
# 00 → -1-1j, 01 → -1+1j, 10 → +1-1j, 11 → +1+1j (before normalization)
_QPSK_CONSTELLATION = np.array(
    [-1 - 1j, -1 + 1j, 1 - 1j, 1 + 1j],
    dtype=np.complex128,
) / np.sqrt(2)


def mod_qpsk(
    bits: NDArray[np.integer],
    fs: float,
    symbol_rate: float,
) -> NDArray[np.complexfloating]:
    """Modulate bits using Quadrature Phase Shift Keying (QPSK).

    Maps binary data to complex baseband symbols using Gray-coded QPSK:
    - 00 → (-1-1j)/√2 (225°)
    - 01 → (-1+1j)/√2 (135°)
    - 10 → (+1-1j)/√2 (315°)
    - 11 → (+1+1j)/√2 (45°)

    Args:
        bits: Array of bits (0s and 1s) to modulate. Length must be even
            (2 bits per symbol).
        fs: Sample rate in Hz.
        symbol_rate: Symbol rate in symbols per second. Two bits become
            one symbol. fs/symbol_rate must be an integer (samples per symbol).

    Returns:
        Complex baseband QPSK signal with rectangular pulse shaping.
        Length is (len(bits) // 2) * samples_per_symbol.

    Raises:
        ValueError: If len(bits) is odd.
        ValueError: If fs/symbol_rate is not an integer.

    Examples:
        >>> # Modulate 8 bits (4 symbols) at 1000 symbols/sec
        >>> bits = np.array([0, 0, 0, 1, 1, 0, 1, 1])
        >>> signal = mod_qpsk(bits, 10000, 1000)
        >>> len(signal)
        40

    Notes:
        QPSK carries 2 bits per symbol, doubling spectral efficiency vs BPSK.
        The Gray coding ensures adjacent constellation points differ by
        only 1 bit, minimizing bit errors from symbol errors.

        Use iq_to_passband() to upconvert to a carrier frequency if needed.
    """
    bits = np.asarray(bits, dtype=np.int8)

    if len(bits) % 2 != 0:
        raise ValueError(f"bits length must be even, got {len(bits)}")

    samples_per_symbol = fs / symbol_rate
    if not samples_per_symbol.is_integer():
        raise ValueError(
            f"fs/symbol_rate must be an integer, got {samples_per_symbol}",
        )
    samples_per_symbol = int(samples_per_symbol)

    # Group bits into pairs and convert to symbol indices
    # Bit pairs: [b0, b1] → index = b0 * 2 + b1
    bit_pairs = bits.reshape(-1, 2)
    symbol_indices = bit_pairs[:, 0] * 2 + bit_pairs[:, 1]

    # Map to constellation points
    symbols = _QPSK_CONSTELLATION[symbol_indices]

    # Upsample with rectangular pulse (repeat each symbol)
    return np.repeat(symbols, samples_per_symbol)


def demod_qpsk(
    sig: NDArray[np.floating | np.complexfloating],
    fs: float,
    symbol_rate: float,
) -> NDArray[np.int8]:
    """Demodulate a QPSK signal to recover bits.

    Recovers binary data from a QPSK baseband signal using hard decisions
    on the I and Q components.

    Args:
        sig: Complex baseband QPSK signal.
        fs: Sample rate in Hz.
        symbol_rate: Symbol rate in symbols per second.

    Returns:
        Array of recovered bits (0s and 1s). Length is 2 * n_symbols.

    Raises:
        ValueError: If fs/symbol_rate is not an integer.

    Examples:
        >>> # Round-trip QPSK modulation/demodulation
        >>> bits = np.array([0, 0, 0, 1, 1, 0, 1, 1])
        >>> signal = mod_qpsk(bits, 10000, 1000)
        >>> recovered = demod_qpsk(signal, 10000, 1000)
        >>> np.array_equal(bits, recovered)
        True

    Notes:
        Demodulation samples at symbol centers and makes hard decisions:
        - I component: positive → bit0=1, negative → bit0=0
        - Q component: positive → bit1=1, negative → bit1=0

        For noisy signals, consider matched filtering before demodulation.
    """
    sig = np.asarray(sig)

    samples_per_symbol = fs / symbol_rate
    if not samples_per_symbol.is_integer():
        raise ValueError(
            f"fs/symbol_rate must be an integer, got {samples_per_symbol}",
        )
    samples_per_symbol = int(samples_per_symbol)

    # Sample at symbol centers
    n_symbols = len(sig) // samples_per_symbol
    sample_indices = np.arange(n_symbols) * samples_per_symbol + samples_per_symbol // 2
    sample_indices = sample_indices.astype(int)

    # Get symbol values at sample points
    symbols = sig[sample_indices]

    # Hard decision on I and Q
    # I >= 0 → bit0 = 1, I < 0 → bit0 = 0
    # Q >= 0 → bit1 = 1, Q < 0 → bit1 = 0
    bit0 = (np.real(symbols) >= 0).astype(np.int8)
    bit1 = (np.imag(symbols) >= 0).astype(np.int8)

    # Interleave bits: [bit0_0, bit1_0, bit0_1, bit1_1, ...]
    bits = np.empty(2 * n_symbols, dtype=np.int8)
    bits[0::2] = bit0
    bits[1::2] = bit1

    return bits
