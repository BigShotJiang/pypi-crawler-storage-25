"""Binary Phase Shift Keying (BPSK) modulation functions."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from numpy.typing import NDArray


def mod_bpsk(
    bits: NDArray[np.integer],
    fs: float,
    symbol_rate: float,
) -> NDArray[np.complexfloating]:
    """Modulate bits using Binary Phase Shift Keying (BPSK).

    Maps binary data to complex baseband symbols using BPSK constellation:
    - 0 → -1 (180° phase)
    - 1 → +1 (0° phase)

    Args:
        bits: Array of bits (0s and 1s) to modulate.
        fs: Sample rate in Hz.
        symbol_rate: Symbol rate in symbols per second. Each bit becomes
            one symbol. fs/symbol_rate must be an integer (samples per symbol).

    Returns:
        Complex baseband BPSK signal with rectangular pulse shaping.
        Length is len(bits) * samples_per_symbol.

    Raises:
        ValueError: If fs/symbol_rate is not an integer.

    Examples:
        >>> # Modulate 8 bits at 1000 symbols/sec, 10 kHz sample rate
        >>> bits = np.array([0, 1, 1, 0, 1, 0, 0, 1])
        >>> signal = mod_bpsk(bits, 10000, 1000)
        >>> len(signal)
        80

    Notes:
        BPSK is the simplest PSK scheme with 1 bit per symbol.
        The output is real-valued (imaginary part is zero) but returned
        as complex for consistency with other modulation functions.

        Use iq_to_passband() to upconvert to a carrier frequency if needed.
    """
    bits = np.asarray(bits, dtype=np.int8)

    samples_per_symbol = fs / symbol_rate
    if not samples_per_symbol.is_integer():
        raise ValueError(
            f"fs/symbol_rate must be an integer, got {samples_per_symbol}",
        )
    samples_per_symbol = int(samples_per_symbol)

    # Map bits to BPSK symbols: 0 → -1, 1 → +1
    symbols = 2 * bits - 1

    # Upsample with rectangular pulse (repeat each symbol)
    signal = np.repeat(symbols, samples_per_symbol)

    return np.asarray(signal, dtype=np.complex128)


def demod_bpsk(
    sig: NDArray[np.floating | np.complexfloating],
    fs: float,
    symbol_rate: float,
) -> NDArray[np.int8]:
    """Demodulate a BPSK signal to recover bits.

    Recovers binary data from a BPSK baseband signal using hard decision
    on the real component.

    Args:
        sig: Complex baseband BPSK signal.
        fs: Sample rate in Hz.
        symbol_rate: Symbol rate in symbols per second.

    Returns:
        Array of recovered bits (0s and 1s).

    Raises:
        ValueError: If fs/symbol_rate is not an integer.

    Examples:
        >>> # Round-trip BPSK modulation/demodulation
        >>> bits = np.array([0, 1, 1, 0, 1, 0, 0, 1])
        >>> signal = mod_bpsk(bits, 10000, 1000)
        >>> recovered = demod_bpsk(signal, 10000, 1000)
        >>> np.array_equal(bits, recovered)
        True

    Notes:
        Demodulation samples at symbol centers and makes hard decisions:
        - Re{symbol} ≥ 0 → 1
        - Re{symbol} < 0 → 0

        For noisy signals, consider matched filtering before demodulation.
    """
    sig = np.asarray(sig)

    samples_per_symbol = fs / symbol_rate
    if not samples_per_symbol.is_integer():
        raise ValueError(
            f"fs/symbol_rate must be an integer, got {samples_per_symbol}",
        )
    samples_per_symbol = int(samples_per_symbol)

    # Sample at symbol centers
    n_symbols = len(sig) // samples_per_symbol
    sample_indices = np.arange(n_symbols) * samples_per_symbol + samples_per_symbol // 2
    sample_indices = sample_indices.astype(int)

    # Get symbol values at sample points
    symbols = np.real(sig[sample_indices])

    # Hard decision: positive → 1, negative → 0
    return (symbols >= 0).astype(np.int8)
