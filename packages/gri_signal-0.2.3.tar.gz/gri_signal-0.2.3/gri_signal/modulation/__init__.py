"""Modulation and baseband conversion.

Provides functions for IQ (in-phase/quadrature) signal processing and
modulation/demodulation operations.

Analog modulations:
    - AM (amplitude modulation): mod_am, demod_am
    - FM (frequency modulation): mod_fm, demod_fm
    - PM (phase modulation): mod_pm, demod_pm

Digital modulations (baseband, rectangular pulses):
    - BPSK (binary phase shift keying): mod_bpsk, demod_bpsk
    - QPSK (quadrature phase shift keying): mod_qpsk, demod_qpsk
    - QAM (quadrature amplitude modulation): mod_qam, demod_qam

IQ conversion:
    - passband_to_iq: Real passband to complex baseband
    - iq_to_passband: Complex baseband to real passband
"""

from .am import demod_am, mod_am
from .bpsk import demod_bpsk, mod_bpsk
from .fm import demod_fm, mod_fm
from .iq import iq_to_passband, passband_to_iq
from .pm import demod_pm, mod_pm
from .qam import demod_qam, mod_qam
from .qpsk import demod_qpsk, mod_qpsk

__all__ = [
    "demod_am",
    "demod_bpsk",
    "demod_fm",
    "demod_pm",
    "demod_qam",
    "demod_qpsk",
    "iq_to_passband",
    "mod_am",
    "mod_bpsk",
    "mod_fm",
    "mod_pm",
    "mod_qam",
    "mod_qpsk",
    "passband_to_iq",
]
