"""Phase modulation (PM) functions."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from scipy.signal import hilbert

if TYPE_CHECKING:
    from numpy.typing import NDArray


def mod_pm(
    sig: NDArray[np.floating],
    fs: float,
    f_carrier: float,
    *,
    phase_deviation: float,
) -> NDArray[np.complexfloating]:
    """Apply phase modulation to a baseband signal.

    Creates a PM signal where the instantaneous phase varies
    proportionally to the input message signal.

    Args:
        sig: Real-valued baseband message signal (should be normalized to [-1, 1]).
        fs: Sample rate in Hz.
        f_carrier: Carrier frequency in Hz.
        phase_deviation: Maximum phase deviation in radians. The instantaneous
            phase will vary by ±phase_deviation when the message is at ±1.

    Returns:
        Complex PM signal with carrier at f_carrier.

    Examples:
        >>> # PM modulate a 100 Hz tone with π/2 phase deviation
        >>> t = np.arange(10000) / 10000
        >>> message = np.sin(2 * np.pi * 100 * t)
        >>> pm_signal = mod_pm(message, 10000, 1000, phase_deviation=np.pi/2)

    Notes:
        The PM signal is: s(t) = exp(j * (2π*fc*t + Δφ * sig(t)))

        where Δφ is the phase deviation. Unlike FM, the phase directly
        follows the message (no integration).

        PM and FM are related: FM of sig(t) = PM of ∫sig(τ)dτ
    """
    sig = np.asarray(sig, dtype=np.float64)
    n = len(sig)
    t = np.arange(n) / fs

    # Compute instantaneous phase
    phase = 2 * np.pi * f_carrier * t + phase_deviation * sig

    pm_signal: NDArray[np.complexfloating] = np.exp(1j * phase)

    return pm_signal


def demod_pm(
    sig: NDArray[np.floating | np.complexfloating],
    fs: float,
    f_carrier: float,
    *,
    phase_deviation: float,
) -> NDArray[np.floating]:
    """Demodulate a PM signal by extracting the instantaneous phase.

    Recovers the baseband message from a phase-modulated signal
    by extracting and unwrapping the phase.

    Args:
        sig: PM signal (real or complex). Should be analytic (complex) for
            best results.
        fs: Sample rate in Hz.
        f_carrier: Carrier frequency in Hz.
        phase_deviation: Maximum phase deviation in radians (same as used
            in modulation).

    Returns:
        Recovered baseband message signal.

    Examples:
        >>> # Round-trip PM modulation/demodulation
        >>> t = np.arange(10000) / 10000
        >>> message = np.sin(2 * np.pi * 100 * t)
        >>> pm_signal = mod_pm(message, 10000, 1000, phase_deviation=np.pi/2)
        >>> recovered = demod_pm(pm_signal, 10000, 1000, phase_deviation=np.pi/2)

    Notes:
        PM demodulation extracts the instantaneous phase and removes the
        carrier component: sig(t) = (phase(t) - 2π*fc*t) / Δφ
    """
    sig = np.asarray(sig)
    n = len(sig)
    t = np.arange(n) / fs

    # Ensure complex signal
    if not np.iscomplexobj(sig):
        sig = np.asarray(hilbert(sig))

    # Extract and unwrap phase
    phase = np.unwrap(np.angle(sig))

    # Remove carrier phase component
    carrier_phase = 2 * np.pi * f_carrier * t
    message_phase = phase - carrier_phase

    # Remove any linear trend (residual carrier frequency offset)
    # Fit and subtract linear component
    coeffs = np.polyfit(t, message_phase, 1)
    message_phase = message_phase - np.polyval(coeffs, t)

    # Scale by phase deviation
    message = message_phase / phase_deviation

    return np.asarray(message, dtype=np.float64)
