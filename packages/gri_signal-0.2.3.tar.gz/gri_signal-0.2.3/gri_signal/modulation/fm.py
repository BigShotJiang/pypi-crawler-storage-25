"""Frequency modulation (FM) functions."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from scipy.signal import hilbert

if TYPE_CHECKING:
    from numpy.typing import NDArray


def mod_fm(
    sig: NDArray[np.floating],
    fs: float,
    f_carrier: float,
    *,
    freq_deviation: float,
) -> NDArray[np.complexfloating]:
    """Apply frequency modulation to a baseband signal.

    Creates an FM signal where the instantaneous frequency varies
    proportionally to the input message signal.

    Args:
        sig: Real-valued baseband message signal (should be normalized to [-1, 1]).
        fs: Sample rate in Hz.
        f_carrier: Carrier frequency in Hz.
        freq_deviation: Maximum frequency deviation in Hz. The instantaneous
            frequency will vary between (f_carrier - freq_deviation) and
            (f_carrier + freq_deviation) when the message is at its extremes.

    Returns:
        Complex FM signal with carrier at f_carrier.

    Examples:
        >>> # FM modulate a 100 Hz tone with 75 kHz deviation (broadcast FM)
        >>> t = np.arange(44100) / 44100
        >>> message = np.sin(2 * np.pi * 100 * t)
        >>> fm_signal = mod_fm(message, 44100, 10000, freq_deviation=5000)

    Notes:
        The FM signal is: s(t) = exp(j * (2π*fc*t + 2π*Δf * ∫sig(τ)dτ))

        where Δf is the frequency deviation. The instantaneous frequency is:
        f_inst(t) = fc + Δf * sig(t)

        The modulation index β = Δf / f_message determines the bandwidth.
    """
    sig = np.asarray(sig, dtype=np.float64)
    n = len(sig)
    t = np.arange(n) / fs

    # Integrate message signal for phase
    # Use cumulative sum as discrete integration (scaled by 1/fs)
    integrated_sig = np.cumsum(sig) / fs

    # Compute instantaneous phase
    phase = 2 * np.pi * f_carrier * t + 2 * np.pi * freq_deviation * integrated_sig

    fm_signal: NDArray[np.complexfloating] = np.exp(1j * phase)

    return fm_signal


def demod_fm(
    sig: NDArray[np.floating | np.complexfloating],
    fs: float,
    f_carrier: float,
    *,
    freq_deviation: float,
) -> NDArray[np.floating]:
    """Demodulate an FM signal using frequency discrimination.

    Recovers the baseband message from a frequency-modulated signal
    by computing the instantaneous frequency.

    Args:
        sig: FM signal (real or complex). Should be analytic (complex) for
            best results.
        fs: Sample rate in Hz.
        f_carrier: Carrier frequency in Hz.
        freq_deviation: Maximum frequency deviation in Hz (same as used
            in modulation).

    Returns:
        Recovered baseband message signal.

    Examples:
        >>> # Round-trip FM modulation/demodulation
        >>> t = np.arange(44100) / 44100
        >>> message = np.sin(2 * np.pi * 100 * t)
        >>> fm_signal = mod_fm(message, 44100, 10000, freq_deviation=5000)
        >>> recovered = demod_fm(fm_signal, 44100, 10000, freq_deviation=5000)

    Notes:
        FM demodulation computes the derivative of the instantaneous phase:
        f_inst(t) = (1/2π) * d(phase)/dt

        The message is then: sig(t) = (f_inst(t) - fc) / Δf
    """
    _ = f_carrier  # Reserved for future use (e.g., bandpass filtering)

    sig = np.asarray(sig)

    # Ensure complex signal
    if not np.iscomplexobj(sig):
        sig = np.asarray(hilbert(sig))

    # Compute instantaneous frequency via phase differentiation
    # Use angle of product with delayed conjugate: angle(sig[n] * conj(sig[n-1]))
    # This gives the phase difference between samples
    phase_diff = np.angle(sig[1:] * np.conj(sig[:-1]))

    # Instantaneous frequency (cycles per sample) = phase_diff / (2π)
    # Instantaneous frequency (Hz) = phase_diff * fs / (2π)
    inst_freq = phase_diff * fs / (2 * np.pi)

    # Remove carrier frequency offset and scale by deviation
    message = inst_freq / freq_deviation

    # Pad to match original length (lost one sample in differentiation)
    message = np.concatenate([[message[0]], message])

    return np.asarray(message, dtype=np.float64)
