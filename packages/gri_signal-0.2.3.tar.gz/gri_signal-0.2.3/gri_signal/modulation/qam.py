"""Quadrature Amplitude Modulation (QAM) functions."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from numpy.typing import NDArray

# Supported QAM orders
_SUPPORTED_ORDERS = {4, 16, 64, 256}


def _gray_code(n: int) -> NDArray[np.integer]:
    """Generate Gray code sequence for n bits.

    Args:
        n: Number of bits.

    Returns:
        Array of 2^n Gray-coded integers.
    """
    if n == 0:
        return np.array([0], dtype=np.int32)
    if n == 1:
        return np.array([0, 1], dtype=np.int32)

    # Recursive Gray code construction
    lower = _gray_code(n - 1)
    upper = lower[::-1] + (1 << (n - 1))
    return np.concatenate([lower, upper])


def _create_qam_constellation(order: int) -> NDArray[np.complexfloating]:
    """Create a Gray-coded square QAM constellation.

    Args:
        order: QAM order (4, 16, 64, or 256).

    Returns:
        Complex constellation points indexed by Gray-coded bit patterns.
    """
    sqrt_order = int(np.sqrt(order))
    bits_per_axis = int(np.log2(sqrt_order))

    # Generate Gray code for axis indices
    gray = _gray_code(bits_per_axis)

    # Create grid positions (-sqrt_order+1, ..., -1, 1, ..., sqrt_order-1)
    positions = np.arange(sqrt_order) * 2 - (sqrt_order - 1)

    # Build constellation with Gray coding on both axes
    constellation = np.zeros(order, dtype=np.complex128)
    for i, gi in enumerate(gray):
        for j, gj in enumerate(gray):
            # Bit index: upper bits for I, lower bits for Q
            idx = gi * sqrt_order + gj
            constellation[idx] = positions[i] + 1j * positions[j]

    # Normalize to unit average power
    avg_power = np.mean(np.abs(constellation) ** 2)
    constellation /= np.sqrt(avg_power)

    return constellation


# Pre-compute constellations for supported orders
_QAM_CONSTELLATIONS = {
    order: _create_qam_constellation(order) for order in _SUPPORTED_ORDERS
}


def mod_qam(
    bits: NDArray[np.integer],
    fs: float,
    symbol_rate: float,
    *,
    order: int = 16,
) -> NDArray[np.complexfloating]:
    """Modulate bits using Quadrature Amplitude Modulation (QAM).

    Maps binary data to complex baseband symbols using Gray-coded square QAM.
    Each symbol carries log2(order) bits.

    Args:
        bits: Array of bits (0s and 1s) to modulate. Length must be a multiple
            of log2(order).
        fs: Sample rate in Hz.
        symbol_rate: Symbol rate in symbols per second.
            fs/symbol_rate must be an integer (samples per symbol).
        order: QAM order (4, 16, 64, or 256). Defaults to 16.
            - 4-QAM (equivalent to QPSK): 2 bits/symbol
            - 16-QAM: 4 bits/symbol
            - 64-QAM: 6 bits/symbol
            - 256-QAM: 8 bits/symbol

    Returns:
        Complex baseband QAM signal with rectangular pulse shaping.
        Length is (len(bits) // bits_per_symbol) * samples_per_symbol.

    Raises:
        ValueError: If order is not 4, 16, 64, or 256.
        ValueError: If len(bits) is not a multiple of bits_per_symbol.
        ValueError: If fs/symbol_rate is not an integer.

    Examples:
        >>> # Modulate 16 bits using 16-QAM (4 symbols)
        >>> bits = np.array([0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 1, 1])
        >>> signal = mod_qam(bits, 10000, 1000, order=16)
        >>> len(signal)
        40

    Notes:
        QAM combines amplitude and phase modulation for higher spectral
        efficiency. Gray coding ensures adjacent constellation points
        differ by only 1 bit, minimizing bit errors.

        The constellation is normalized to unit average power.
        Use iq_to_passband() to upconvert to a carrier frequency if needed.
    """
    if order not in _SUPPORTED_ORDERS:
        msg = f"order must be one of {sorted(_SUPPORTED_ORDERS)}, got {order}"
        raise ValueError(msg)

    bits = np.asarray(bits, dtype=np.int8)
    bits_per_symbol = int(np.log2(order))

    if len(bits) % bits_per_symbol != 0:
        raise ValueError(
            f"bits length must be a multiple of {bits_per_symbol} for {order}-QAM, "
            f"got {len(bits)}",
        )

    samples_per_symbol = fs / symbol_rate
    if not samples_per_symbol.is_integer():
        raise ValueError(
            f"fs/symbol_rate must be an integer, got {samples_per_symbol}",
        )
    samples_per_symbol = int(samples_per_symbol)

    # Group bits and convert to symbol indices
    bit_groups = bits.reshape(-1, bits_per_symbol)
    # Convert binary groups to integers
    powers = 2 ** np.arange(bits_per_symbol)[::-1]
    symbol_indices = np.sum(bit_groups * powers, axis=1)

    # Map to constellation points
    constellation = _QAM_CONSTELLATIONS[order]
    symbols = constellation[symbol_indices]

    # Upsample with rectangular pulse
    return np.repeat(symbols, samples_per_symbol)


def demod_qam(
    sig: NDArray[np.floating | np.complexfloating],
    fs: float,
    symbol_rate: float,
    *,
    order: int = 16,
) -> NDArray[np.int8]:
    """Demodulate a QAM signal to recover bits.

    Recovers binary data from a QAM baseband signal using nearest-neighbor
    hard decision on the constellation.

    Args:
        sig: Complex baseband QAM signal.
        fs: Sample rate in Hz.
        symbol_rate: Symbol rate in symbols per second.
        order: QAM order (4, 16, 64, or 256). Must match modulation.

    Returns:
        Array of recovered bits (0s and 1s).
        Length is n_symbols * log2(order).

    Raises:
        ValueError: If order is not 4, 16, 64, or 256.
        ValueError: If fs/symbol_rate is not an integer.

    Examples:
        >>> # Round-trip QAM modulation/demodulation
        >>> bits = np.array([0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 1, 1])
        >>> signal = mod_qam(bits, 10000, 1000, order=16)
        >>> recovered = demod_qam(signal, 10000, 1000, order=16)
        >>> np.array_equal(bits, recovered)
        True

    Notes:
        Demodulation samples at symbol centers and finds the nearest
        constellation point using Euclidean distance.

        For noisy signals, consider matched filtering and equalization
        before demodulation.
    """
    if order not in _SUPPORTED_ORDERS:
        msg = f"order must be one of {sorted(_SUPPORTED_ORDERS)}, got {order}"
        raise ValueError(msg)

    sig = np.asarray(sig)
    bits_per_symbol = int(np.log2(order))

    samples_per_symbol = fs / symbol_rate
    if not samples_per_symbol.is_integer():
        raise ValueError(
            f"fs/symbol_rate must be an integer, got {samples_per_symbol}",
        )
    samples_per_symbol = int(samples_per_symbol)

    # Sample at symbol centers
    n_symbols = len(sig) // samples_per_symbol
    sample_indices = np.arange(n_symbols) * samples_per_symbol + samples_per_symbol // 2
    sample_indices = sample_indices.astype(int)

    # Get symbol values at sample points
    symbols = sig[sample_indices]

    # Find nearest constellation point for each symbol
    constellation = _QAM_CONSTELLATIONS[order]
    # Compute distances to all constellation points
    distances = np.abs(symbols[:, np.newaxis] - constellation[np.newaxis, :])
    nearest_indices = np.argmin(distances, axis=1)

    # Convert indices back to bits
    bits = np.zeros((n_symbols, bits_per_symbol), dtype=np.int8)
    for i in range(bits_per_symbol):
        bits[:, bits_per_symbol - 1 - i] = (nearest_indices >> i) & 1

    return bits.flatten()
