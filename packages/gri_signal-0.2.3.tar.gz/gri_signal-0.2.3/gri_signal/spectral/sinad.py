"""Compute SINAD (Signal-to-Noise and Distortion ratio)."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from scipy.fft import fft, fftfreq, fftshift

if TYPE_CHECKING:
    from numpy.typing import NDArray


def sinad(
    fs: float,
    sig: NDArray,
    *,
    fundamental_freq: float | None = None,
    fundamental_bw: float | None = None,
) -> float:
    """Compute SINAD (Signal-to-Noise and Distortion ratio) in dB.

    SINAD is the ratio of the total signal power (fundamental + noise + distortion)
    to the noise and distortion power alone. It measures how much the desired
    signal stands above all unwanted components.

    SINAD = 10 * log10((S + N + D) / (N + D))

    Where S is signal power, N is noise power, and D is distortion power.
    This is equivalent to: SINAD = 10 * log10(Total Power / (Total - Fundamental))

    Args:
        fs: Sampling frequency in Hz.
        sig: Input signal array (1D).
        fundamental_freq: Frequency of the fundamental tone in Hz. If None,
            automatically detects the strongest frequency component.
        fundamental_bw: Bandwidth around the fundamental to consider as signal
            in Hz. If None, uses fs/len(sig) * 10 (10 frequency bins).

    Returns:
        SINAD in dB.

    Example:
        >>> import numpy as np
        >>> from gri_signal import tone, awgn, sinad
        >>> fs = 10000
        >>> t = np.arange(10000) / fs
        >>> signal = tone(fs, 1000, 1.0, len(t))
        >>> noisy = awgn(signal, snr_db=30)
        >>> sinad_db = sinad(fs, noisy, fundamental_freq=1000)
    """
    sig = np.asarray(sig).flatten()
    n = len(sig)

    # Compute power spectrum (linear)
    spectrum = np.abs(fftshift(fft(sig))) ** 2
    freqs = fftshift(fftfreq(n, 1 / fs))
    freq_resolution = fs / n

    # Auto-detect fundamental if not specified
    if fundamental_freq is None:
        # Find peak (excluding DC for real signals)
        dc_idx = n // 2
        spectrum_no_dc = spectrum.copy()
        spectrum_no_dc[max(0, dc_idx - 2) : dc_idx + 3] = 0
        peak_idx = np.argmax(spectrum_no_dc)
        fundamental_freq = freqs[peak_idx]

    # Default bandwidth: 10 bins
    if fundamental_bw is None:
        fundamental_bw = freq_resolution * 10

    half_bw = fundamental_bw / 2

    # Create mask for fundamental frequency
    signal_mask = np.abs(freqs - fundamental_freq) <= half_bw

    # For real signals, include negative frequency mirror
    if not np.iscomplexobj(sig):
        signal_mask |= np.abs(freqs + fundamental_freq) <= half_bw

    # Calculate powers
    total_power = np.sum(spectrum)
    signal_power = np.sum(spectrum[signal_mask])
    noise_and_distortion = total_power - signal_power

    if noise_and_distortion <= 0:
        return np.inf

    # SINAD = Total / (Noise + Distortion)
    sinad_linear = total_power / noise_and_distortion

    return float(10 * np.log10(sinad_linear))
