"""Compute Total Harmonic Distortion (THD)."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from scipy.fft import fft, fftfreq, fftshift

if TYPE_CHECKING:
    from numpy.typing import NDArray


def thd(
    fs: float,
    sig: NDArray,
    *,
    fundamental_freq: float | None = None,
    num_harmonics: int = 5,
    harmonic_bw: float | None = None,
) -> float:
    """Compute Total Harmonic Distortion (THD) in dB.

    THD measures the ratio of the power in harmonic frequencies to the power
    in the fundamental frequency. Lower THD indicates a purer signal.

    THD = 10 * log10(sum(H_n^2) / H_1^2)

    Where H_1 is the fundamental and H_n are the harmonics.

    Args:
        fs: Sampling frequency in Hz.
        sig: Input signal array (1D).
        fundamental_freq: Frequency of the fundamental tone in Hz. If None,
            automatically detects the strongest frequency component.
        num_harmonics: Number of harmonics to include in THD calculation.
            Defaults to 5 (2nd through 6th harmonics).
        harmonic_bw: Bandwidth around each harmonic to sum power in Hz.
            If None, uses fs/len(sig) * 5 (5 frequency bins).

    Returns:
        THD in dB. More negative values indicate lower distortion.

    Example:
        >>> import numpy as np
        >>> from gri_signal import tone, thd
        >>> fs = 48000
        >>> n = 48000
        >>> t = np.arange(n) / fs
        >>> # Pure sine - very low THD
        >>> pure = np.sin(2 * np.pi * 1000 * t)
        >>> thd_pure = thd(fs, pure, fundamental_freq=1000)
        >>> # Clipped sine - higher THD
        >>> clipped = np.clip(pure * 2, -1, 1)
        >>> thd_clipped = thd(fs, clipped, fundamental_freq=1000)
    """
    sig = np.asarray(sig).flatten()
    n = len(sig)

    # Compute power spectrum (linear)
    spectrum = np.abs(fftshift(fft(sig))) ** 2
    freqs = fftshift(fftfreq(n, 1 / fs))
    freq_resolution = fs / n

    # Auto-detect fundamental if not specified
    if fundamental_freq is None:
        # Find peak (excluding DC)
        dc_idx = n // 2
        spectrum_no_dc = spectrum.copy()
        spectrum_no_dc[max(0, dc_idx - 2) : dc_idx + 3] = 0
        peak_idx = np.argmax(spectrum_no_dc)
        fundamental_freq = abs(freqs[peak_idx])

    # Default bandwidth: 5 bins
    if harmonic_bw is None:
        harmonic_bw = freq_resolution * 5

    half_bw = harmonic_bw / 2

    def get_power_at_freq(freq: float) -> float:
        """Sum power within bandwidth of a frequency."""
        mask = np.abs(freqs - freq) <= half_bw
        # Include negative frequency for real signals
        if not np.iscomplexobj(sig):
            mask |= np.abs(freqs + freq) <= half_bw
        return float(np.sum(spectrum[mask]))

    # Get fundamental power
    fundamental_power = get_power_at_freq(fundamental_freq)

    if fundamental_power <= 0:
        return -np.inf

    # Sum harmonic powers
    harmonic_power = 0.0
    for h in range(2, num_harmonics + 2):
        harmonic_freq = fundamental_freq * h
        # Only include harmonics below Nyquist
        if harmonic_freq < fs / 2:
            harmonic_power += get_power_at_freq(harmonic_freq)

    if harmonic_power <= 0:
        return -np.inf

    # THD = harmonics / fundamental
    thd_linear = harmonic_power / fundamental_power

    return float(10 * np.log10(thd_linear))
