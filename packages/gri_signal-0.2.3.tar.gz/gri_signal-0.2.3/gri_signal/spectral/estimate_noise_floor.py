"""Estimate the noise floor of a signal."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from scipy.fft import fft, fftshift

if TYPE_CHECKING:
    from numpy.typing import NDArray


def estimate_noise_floor(
    fs: float,
    sig: NDArray,
    *,
    percentile: float = 10.0,
    exclude_dc: bool = True,
) -> float:
    """Estimate the noise floor of a signal in dB.

    Uses a percentile-based approach on the power spectrum to estimate the
    noise floor, which is robust to the presence of signal peaks.

    Args:
        fs: Sampling frequency in Hz.
        sig: Input signal array (1D).
        percentile: Percentile of the power spectrum to use as noise floor
            estimate. Lower values are more conservative. Defaults to 10.
        exclude_dc: If True, excludes the DC component from the estimate.
            Defaults to True.

    Returns:
        Estimated noise floor in dB (relative to full scale).

    Example:
        >>> import numpy as np
        >>> from gri_signal import tone, awgn, estimate_noise_floor
        >>> fs = 10000
        >>> t = np.arange(10000) / fs
        >>> signal = tone(fs, 1000, 1.0, len(t))
        >>> noisy = awgn(signal, snr_db=20)
        >>> floor = estimate_noise_floor(fs, noisy)
    """
    _ = fs  # Available for future frequency-dependent floor estimation
    sig = np.asarray(sig).flatten()
    n = len(sig)

    # Compute power spectrum (linear)
    spectrum = np.abs(fftshift(fft(sig))) ** 2

    if exclude_dc:
        # Zero out DC bin (center of shifted spectrum)
        dc_idx = n // 2
        spectrum = spectrum.copy()
        spectrum[dc_idx] = np.nan

    # Use percentile to estimate floor (robust to signal peaks)
    floor_power = np.nanpercentile(spectrum, percentile)

    if floor_power <= 0:
        return -np.inf

    # Convert to dB
    # Normalize by N^2 to get power relative to full scale
    floor_db = 10 * np.log10(floor_power / (n * n))

    return float(floor_db)
