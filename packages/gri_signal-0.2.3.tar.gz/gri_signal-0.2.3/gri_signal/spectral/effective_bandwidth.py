"""Compute effective (RMS) bandwidth of a signal."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from scipy.fft import fft, fftfreq, fftshift

if TYPE_CHECKING:
    from numpy.typing import NDArray


def effective_bandwidth(
    fs: float,
    sig: NDArray,
    *,
    method: str = "rms",
    threshold_db: float = -3.0,
) -> float:
    """Compute the effective bandwidth of a signal.

    The effective bandwidth quantifies how "spread out" a signal is in frequency.
    This is one component of the time-bandwidth product (TBP).

    Methods:
        - "rms": Root-mean-square bandwidth (second central moment of |spectrum|^2).
          This is the standard definition used in uncertainty principle derivations.
        - "threshold": Bandwidth above a power threshold relative to peak.

    Args:
        fs: Sampling frequency in Hz.
        sig: Input signal array (1D).
        method: Bandwidth calculation method. One of "rms" or "threshold".
            Defaults to "rms".
        threshold_db: For threshold method, the dB level below peak to measure
            bandwidth. Defaults to -3.0 (half-power points, i.e., 3dB bandwidth).

    Returns:
        Effective bandwidth in Hz.

    Example:
        >>> import numpy as np
        >>> from gri_signal import effective_bandwidth
        >>> fs = 10000
        >>> # Gaussian pulse has well-defined RMS bandwidth
        >>> t = np.arange(10000) / fs - 0.5
        >>> sigma_t = 0.05  # 50 ms standard deviation in time
        >>> pulse = np.exp(-t**2 / (2 * sigma_t**2))
        >>> bw = effective_bandwidth(fs, pulse)
        >>> # RMS bandwidth should be 1/(2*pi*sigma_t)
        >>> expected_bw = 1 / (2 * np.pi * sigma_t)
        >>> abs(bw - expected_bw) / expected_bw < 0.1
        True

    Note:
        For a Gaussian pulse with time-domain standard deviation sigma_t,
        the RMS bandwidth is 1/(2*pi*sigma_t). The product of RMS duration
        and RMS bandwidth for a Gaussian equals 1/(4*pi), the theoretical
        minimum (Gabor limit).
    """
    sig = np.asarray(sig).flatten()
    n = len(sig)

    # Compute power spectrum
    spectrum = np.abs(fftshift(fft(sig))) ** 2
    freqs = fftshift(fftfreq(n, 1 / fs))

    total_power = np.sum(spectrum)

    if total_power == 0:
        return 0.0

    if method == "rms":
        # Center of mass in frequency
        f_mean = np.sum(freqs * spectrum) / total_power

        # Second central moment (variance in frequency)
        f_var = np.sum((freqs - f_mean) ** 2 * spectrum) / total_power

        # RMS bandwidth is sqrt of variance
        return float(np.sqrt(f_var))

    if method == "threshold":
        # Find bandwidth above threshold
        peak_power = np.max(spectrum)
        threshold_linear = peak_power * 10 ** (threshold_db / 10)

        above_threshold = spectrum >= threshold_linear
        if not np.any(above_threshold):
            return 0.0

        # Find the frequency extent above threshold
        indices = np.where(above_threshold)[0]
        freq_resolution = fs / n
        bandwidth = (indices[-1] - indices[0] + 1) * freq_resolution
        return float(bandwidth)

    msg = f"Unknown method: {method}. Use 'rms' or 'threshold'."
    raise ValueError(msg)
