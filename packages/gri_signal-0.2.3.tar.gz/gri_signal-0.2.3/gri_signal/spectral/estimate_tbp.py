"""Estimate time-bandwidth product (TBP) of a signal."""

from __future__ import annotations

from typing import TYPE_CHECKING

from .effective_bandwidth import effective_bandwidth
from .effective_duration import effective_duration

if TYPE_CHECKING:
    from numpy.typing import NDArray


def estimate_tbp(
    fs: float,
    sig: NDArray,
    *,
    method: str = "rms",
    threshold_db: float = -3.0,
) -> float:
    """Estimate the time-bandwidth product (TBP) of a signal.

    The time-bandwidth product is a fundamental measure of a signal's "spread"
    in the time-frequency plane. It has a theoretical lower bound from the
    uncertainty principle.

    For RMS definitions: TBP >= 1/(4*pi) ≈ 0.0796 (Gabor limit)
    For practical (-3dB) definitions: TBP >= 0.5 approximately

    Common TBP values:
        - Gaussian pulse: ~0.08 (minimum, achieves Gabor limit)
        - Rectangular pulse: ~0.89
        - Linear FM chirp: ~(chirp_rate * T^2) where T is duration
        - Pulse compression gain ≈ TBP

    Args:
        fs: Sampling frequency in Hz.
        sig: Input signal array (1D).
        method: Calculation method. One of "rms" or "threshold".
            Defaults to "rms".
        threshold_db: For threshold method, the dB level below peak.
            Defaults to -3.0 (half-power points).

    Returns:
        Time-bandwidth product (dimensionless).

    Example:
        >>> import numpy as np
        >>> from gri_signal import estimate_tbp
        >>> fs = 10000
        >>> n = 10000
        >>> t = np.arange(n) / fs
        >>> # Linear FM chirp with 1000 Hz bandwidth over 0.5 seconds
        >>> bw = 1000
        >>> duration = 0.5
        >>> chirp = np.exp(1j * np.pi * (bw / duration) * t**2)[:int(duration * fs)]
        >>> tbp = estimate_tbp(fs, chirp)
        >>> # TBP should be approximately bw * duration / 2 for linear chirp
        >>> tbp > 100  # Large TBP indicates good pulse compression potential
        True

    Note:
        A large TBP indicates:
        - High pulse compression ratio achievable
        - Good range resolution with radar/sonar
        - Signal is spread out in both time AND frequency

        A TBP near the theoretical minimum (~0.08 for RMS) indicates:
        - Signal is maximally concentrated in time-frequency plane
        - Gaussian envelope achieves this minimum
    """
    dur = effective_duration(fs, sig, method=method, threshold_db=threshold_db)
    bw = effective_bandwidth(fs, sig, method=method, threshold_db=threshold_db)

    return float(dur * bw)
