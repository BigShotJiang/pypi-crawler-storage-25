"""Get the FFT or the max power based on FFT."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from scipy.fft import fft, fftfreq, fftshift

if TYPE_CHECKING:
    from numpy.typing import NDArray


def get_max_power(fs: float, sig: NDArray) -> NDArray[np.floating]:
    """Get the maximum power and frequency from a signal via FFT.

    Power is proportional to the power spectral diagram, but note that there are
    differences in FFT PSDs between fully real and complex signals.

    Args:
        fs(float): Sampling frequency in samples per second
        sig(ndarray): Signal as a row-based array. If 1 dimensional, returns a 1x2 with
            (pow,freq), else returns an n-dimensional ((pow,freq),...)

    Returns:
        ndarray with rows of power,frequency
    """
    fft_db, fft_f = get_psd(fs, sig)
    n = len(fft_f)
    # Change view to ndim x n, but preserve original for 1D
    ndim = fft_db.ndim
    m = 1 if ndim == 1 else fft_db.shape[0]
    fft_db = fft_db.reshape((m, -1))
    answers: list[tuple[float, float]] = []
    for channel in fft_db:
        # Prefer positive frequencies if equal
        idx = np.argmax(channel[n // 2 :]) + n // 2
        idx_neg = np.argmax(channel[: n // 2])
        if channel[idx_neg] - 1e-6 > channel[idx]:
            idx = idx_neg
        answers.append((channel[idx], fft_f[idx]))
    if ndim == 1:
        return np.array(answers).reshape(-1)
    return np.array(answers)


def get_psd_power(
    f: float,
    psd: NDArray[np.floating],
    freq: NDArray[np.floating],
) -> float | NDArray[np.floating]:
    """Return the linearly interploated power of the psd at frequency f.

    Can be called with get_psd if you do not need to reuse psd like:
    get_psd_power(f, *get_psd(fs,signal))

    Args:
        f(float): Frequency in the same units as freq
        psd(ndarray): row-wise array of signals or a 1D array
        freq(ndarray): 1D array of frequency bins

    Returns:
        power at f as a float or powers at f as a 1D array if n-dimensional
    """
    # Find the nearest index above f
    idx = np.searchsorted(freq, f)
    if idx == 0 or idx == len(freq):
        raise ValueError("Frequency not contained")
    idxs_prev = idx - 1
    f1 = freq[idxs_prev]
    f2 = freq[idx]
    # Shape to 2-dimensional
    m = 1 if psd.ndim == 1 else psd.shape[0]
    psd = psd.reshape((m, -1))
    v1 = psd[:, idxs_prev]
    v2 = psd[:, idx]
    result = (f - f1) / (f2 - f1) * (v2 - v1) + v1
    if len(result) == 1:
        return float(result[0])
    return result


def get_freq_idx(f: float, fs: float, n: int) -> int:
    """Return the index closest to f in the frequency domain array.

    For finding an exact index nearest to the frequency. That frequency bin is then:
    f = (idx - n//2) * fs / n

    Args:
        f(float): The frequency in hz
        fs(float): Sampling frequency in samples per second
        n(int): Length of the signal array or PSD array
    """
    # how many bins from zero: Each bin is fs/n
    idx = round(f / (fs / n))
    # center (0) is at n//2
    return n // 2 + idx


def get_psd(
    fs: float,
    sig: NDArray,
    *,
    return_onesided: bool = False,
) -> tuple[NDArray[np.floating], NDArray[np.floating]]:
    """Get a power spectrum density array (in db) and respective frequency arrays.

    The arrays are shifted such that frequency starts on the negative side and goes to
    positive (not halved).

    Supports broadcasting such that sig could be a one dimensional array or N
    dimensional by rows, eg: size(chan,N)

    Args:
        fs(float): Sampling frequency in samples per second
        sig(ndarray): Signal as a 1 dimensional array
        return_onesided(bool,optional): Defaults False. If True, return the positive
            side only

    Returns:
        (power array (n dimensional), frequency array (1D))
    """
    # Get the magnitude and length
    if sig.ndim == 1:
        n = sig.shape[0]
        fft_p = np.abs(fftshift(fft(sig)))
    else:
        n = sig.shape[1]
        fft_p = np.abs(fftshift(fft(sig), axes=1))
    # Get the frequency
    fft_f = fftshift(fftfreq(n, 1 / fs))
    # Set a floor so there is no divide by zero
    fft_p[fft_p == 0] = 1e-15
    fft_p = 20 * np.log10(fft_p)
    if return_onesided:
        n = len(sig)
        fft_p = fft_p[n // 2 :]
        fft_f = fft_f[n // 2 :]
    return (fft_p, fft_f)
