"""Spectral analysis functions.

Provides power spectral density estimation, frequency-domain analysis utilities,
and signal quality metrics.
"""

from .effective_bandwidth import effective_bandwidth
from .effective_duration import effective_duration
from .estimate_noise_floor import estimate_noise_floor
from .estimate_snr import estimate_snr
from .estimate_tbp import estimate_tbp
from .fft_metrics import get_freq_idx, get_max_power, get_psd, get_psd_power
from .sinad import sinad
from .thd import thd

__all__ = [
    "effective_bandwidth",
    "effective_duration",
    "estimate_noise_floor",
    "estimate_snr",
    "estimate_tbp",
    "get_freq_idx",
    "get_max_power",
    "get_psd",
    "get_psd_power",
    "sinad",
    "thd",
]
