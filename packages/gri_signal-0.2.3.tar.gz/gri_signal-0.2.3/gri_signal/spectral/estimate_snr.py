"""Estimate signal-to-noise ratio from a signal."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from scipy.fft import fft, fftfreq, fftshift

if TYPE_CHECKING:
    from numpy.typing import NDArray


def estimate_snr(
    fs: float,
    sig: NDArray,
    *,
    signal_bw: float | None = None,
    signal_center: float = 0.0,
) -> float:
    """Estimate the signal-to-noise ratio of a signal in dB.

    Uses a frequency-domain approach: identifies signal power within a specified
    bandwidth around a center frequency, and estimates noise power from the
    remaining spectrum.

    For signals with unknown bandwidth, estimates the noise floor and compares
    peak signal power to that floor.

    Args:
        fs: Sampling frequency in Hz.
        sig: Input signal array (1D).
        signal_bw: Bandwidth of the signal in Hz. If None, uses peak detection
            to estimate signal region.
        signal_center: Center frequency of the signal in Hz. Defaults to 0 (baseband).

    Returns:
        Estimated SNR in dB.

    Example:
        >>> import numpy as np
        >>> from gri_signal import tone, awgn, estimate_snr
        >>> fs = 10000
        >>> t = np.arange(10000) / fs
        >>> signal = tone(fs, 1000, 1.0, len(t))  # 1 kHz tone
        >>> noisy = awgn(signal, snr_db=20)
        >>> snr = estimate_snr(fs, noisy, signal_bw=100, signal_center=1000)
    """
    sig = np.asarray(sig).flatten()
    n = len(sig)

    # Compute power spectrum (linear, not dB)
    spectrum = np.abs(fftshift(fft(sig))) ** 2
    freqs = fftshift(fftfreq(n, 1 / fs))

    if signal_bw is None:
        # Auto-detect: find peak and use 3dB bandwidth estimation
        peak_idx = np.argmax(spectrum)
        peak_power = spectrum[peak_idx]
        half_power = peak_power / 2

        # Find 3dB points around peak
        left_idx = peak_idx
        while left_idx > 0 and spectrum[left_idx] > half_power:
            left_idx -= 1
        right_idx = peak_idx
        while right_idx < n - 1 and spectrum[right_idx] > half_power:
            right_idx += 1

        signal_mask = np.zeros(n, dtype=bool)
        signal_mask[left_idx : right_idx + 1] = True
    else:
        # Use specified bandwidth
        half_bw = signal_bw / 2
        signal_mask = np.abs(freqs - signal_center) <= half_bw

        # For real signals, include negative frequency mirror
        if not np.iscomplexobj(sig):
            signal_mask |= np.abs(freqs + signal_center) <= half_bw

    # Calculate signal and noise power
    signal_power = np.sum(spectrum[signal_mask])
    noise_mask = ~signal_mask
    noise_power = np.sum(spectrum[noise_mask])

    # Scale noise to equivalent signal bandwidth for fair comparison
    noise_bins = np.sum(noise_mask)
    signal_bins = np.sum(signal_mask)

    if noise_bins == 0 or signal_bins == 0:
        return np.inf if noise_bins == 0 else -np.inf

    # Normalize noise power to signal bandwidth
    noise_power_normalized = noise_power * (signal_bins / noise_bins)

    if noise_power_normalized <= 0:
        return np.inf

    snr_linear = signal_power / noise_power_normalized
    return float(10 * np.log10(snr_linear))
