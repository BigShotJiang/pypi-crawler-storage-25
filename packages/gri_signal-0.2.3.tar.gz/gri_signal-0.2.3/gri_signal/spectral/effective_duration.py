"""Compute effective (RMS) duration of a signal."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from numpy.typing import NDArray


def effective_duration(
    fs: float,
    sig: NDArray,
    *,
    method: str = "rms",
    threshold_db: float = -3.0,
) -> float:
    """Compute the effective duration of a signal.

    The effective duration quantifies how "spread out" a signal is in time.
    This is one component of the time-bandwidth product (TBP).

    Methods:
        - "rms": Root-mean-square duration (second central moment of |signal|^2).
          This is the standard definition used in uncertainty principle derivations.
        - "threshold": Duration above a power threshold relative to peak.

    Args:
        fs: Sampling frequency in Hz.
        sig: Input signal array (1D).
        method: Duration calculation method. One of "rms" or "threshold".
            Defaults to "rms".
        threshold_db: For threshold method, the dB level below peak to measure
            duration. Defaults to -3.0 (half-power points).

    Returns:
        Effective duration in seconds.

    Example:
        >>> import numpy as np
        >>> from gri_signal import effective_duration
        >>> fs = 10000
        >>> # Gaussian pulse has well-defined RMS duration
        >>> t = np.arange(10000) / fs - 0.5
        >>> sigma = 0.05  # 50 ms standard deviation
        >>> pulse = np.exp(-t**2 / (2 * sigma**2))
        >>> dur = effective_duration(fs, pulse)
        >>> # RMS duration should be close to sigma
        >>> abs(dur - sigma) < 0.01
        True

    Note:
        For a Gaussian pulse with standard deviation sigma, the RMS duration
        equals sigma. The minimum TBP (Gabor limit) is achieved by Gaussian
        signals where TBP = 1/(4*pi) ≈ 0.08.
    """
    sig = np.asarray(sig).flatten()
    n = len(sig)
    dt = 1 / fs

    # Time array centered on signal center of mass
    t = np.arange(n) * dt

    # Power envelope
    power = np.abs(sig) ** 2
    total_power = np.sum(power)

    if total_power == 0:
        return 0.0

    if method == "rms":
        # Center of mass in time
        t_mean = np.sum(t * power) / total_power

        # Second central moment (variance in time)
        t_var = np.sum((t - t_mean) ** 2 * power) / total_power

        # RMS duration is sqrt of variance
        return float(np.sqrt(t_var))

    if method == "threshold":
        # Find duration above threshold
        peak_power = np.max(power)
        threshold_linear = peak_power * 10 ** (threshold_db / 10)

        above_threshold = power >= threshold_linear
        if not np.any(above_threshold):
            return 0.0

        # Find first and last samples above threshold
        indices = np.where(above_threshold)[0]
        duration_samples = indices[-1] - indices[0] + 1
        return float(duration_samples * dt)

    msg = f"Unknown method: {method}. Use 'rms' or 'threshold'."
    raise ValueError(msg)
