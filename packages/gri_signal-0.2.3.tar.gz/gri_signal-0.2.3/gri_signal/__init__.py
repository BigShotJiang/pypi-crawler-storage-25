"""Functional signal processing library.

Provides composable functions for signal generation, channel simulation,
modulation, sampling, filtering, spectral analysis, correlation, and
beamforming.

All functions are re-exported at the top level for convenience::

    from gri_signal import tone, delay, awgn, lowpass_butter, get_psd

Or access submodules directly::

    from gri_signal.sources import tone, prn, pri
    from gri_signal.channel import delay, awgn
    from gri_signal.filters import lowpass_butter

Signal flow follows:
    sources -> modulation -> channel -> sampling -> [filters/spectral/correlation/beamforming]
"""  # noqa: E501

from gri_signal import (
    beamforming,
    channel,
    correlation,
    detect,
    filters,
    link_budget,
    modulation,
    sampling,
    sources,
    spectral,
)
from gri_signal.beamforming import (
    adaptive_beamform,
    music_spectrum,
    mvdr_beamform,
    mvdr_weights,
    spatial_covariance,
)
from gri_signal.channel import attenuation, awgn, delay
from gri_signal.correlation import ncc, pslr, qint, xcorr
from gri_signal.detect import DetectionResult, detect_pulses, match_detections
from gri_signal.filters import (
    analytic_bandpass_butter,
    analytic_bandpass_fft,
    analytic_bandpass_fir,
    bandpass_butter,
    bandpass_fft,
    bandpass_fir,
    highpass_butter,
    highpass_fft,
    highpass_fir,
    lowpass_butter,
    lowpass_fft,
    lowpass_fir,
    notch_butter,
    notch_fft,
    notch_fir,
)
from gri_signal.link_budget import (
    eirp_dbw,
    fspl_db,
    multipath_received_power_dbw,
    multipath_relative_db,
    noise_power_dbw,
    received_power_dbw,
    snr_db,
)
from gri_signal.modulation import (
    demod_am,
    demod_bpsk,
    demod_fm,
    demod_pm,
    demod_qam,
    demod_qpsk,
    iq_to_passband,
    mod_am,
    mod_bpsk,
    mod_fm,
    mod_pm,
    mod_qam,
    mod_qpsk,
    passband_to_iq,
)
from gri_signal.sampling import adc
from gri_signal.sources import (
    generate_complex_signal,
    pri,
    prn,
    tone,
    ula_steering,
    zeros,
)
from gri_signal.spectral import (
    effective_bandwidth,
    effective_duration,
    estimate_noise_floor,
    estimate_snr,
    estimate_tbp,
    get_freq_idx,
    get_max_power,
    get_psd,
    get_psd_power,
    sinad,
    thd,
)

__all__ = [
    "DetectionResult",
    "adaptive_beamform",
    "adc",
    "analytic_bandpass_butter",
    "analytic_bandpass_fft",
    "analytic_bandpass_fir",
    "attenuation",
    "awgn",
    "bandpass_butter",
    "bandpass_fft",
    "bandpass_fir",
    "beamforming",
    "channel",
    "correlation",
    "delay",
    "demod_am",
    "demod_bpsk",
    "demod_fm",
    "demod_pm",
    "demod_qam",
    "demod_qpsk",
    "detect",
    "detect_pulses",
    "effective_bandwidth",
    "effective_duration",
    "eirp_dbw",
    "estimate_noise_floor",
    "estimate_snr",
    "estimate_tbp",
    "filters",
    "fspl_db",
    "generate_complex_signal",
    "get_freq_idx",
    "get_max_power",
    "get_psd",
    "get_psd_power",
    "highpass_butter",
    "highpass_fft",
    "highpass_fir",
    "iq_to_passband",
    "link_budget",
    "lowpass_butter",
    "lowpass_fft",
    "lowpass_fir",
    "match_detections",
    "mod_am",
    "mod_bpsk",
    "mod_fm",
    "mod_pm",
    "mod_qam",
    "mod_qpsk",
    "modulation",
    "multipath_received_power_dbw",
    "multipath_relative_db",
    "music_spectrum",
    "mvdr_beamform",
    "mvdr_weights",
    "ncc",
    "noise_power_dbw",
    "notch_butter",
    "notch_fft",
    "notch_fir",
    "passband_to_iq",
    "pri",
    "prn",
    "pslr",
    "qint",
    "received_power_dbw",
    "sampling",
    "sinad",
    "snr_db",
    "sources",
    "spatial_covariance",
    "spectral",
    "thd",
    "tone",
    "ula_steering",
    "xcorr",
    "zeros",
]
