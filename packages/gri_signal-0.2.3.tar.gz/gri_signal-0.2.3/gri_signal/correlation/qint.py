"""Quadratic intreptation of samples (like np.polyfit, but faster)."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Sequence

    from numpy.typing import NDArray


def qint(
    x3p: Sequence | NDArray,
    y3p: Sequence | NDArray,
) -> tuple[float, float, float]:
    """QINT - quadratic interpolation of three adjacent samples.

    [p,y,a] = qint(x3p,y3p)

    Returns the extremum location p, height y, and half-curvature a of a parabolic fit
    through three points.

    Parabola is given by y(x) = a*(x-p)^2+b,

    adapted from: https://ccrma.stanford.edu/~jos/sasp/Matlab_Parabolic_Peak_Interpolation.html

    Args:
        x3p(Sequence): A triple of x points
        y3p(Sequence): A triple of y points

    Returns:
        [p,y,a]: location in x, height y, and half-curvature a
    """
    p = (y3p[2] - y3p[0]) / (2 * (2 * y3p[1] - y3p[2] - y3p[0]))
    y_max = y3p[1] - 0.25 * (y3p[0] - y3p[2]) * p
    a = 0.5 * (y3p[0] - 2 * y3p[1] + y3p[2])
    dx = 0.5 * (x3p[2] - x3p[0])
    x_max = p * dx + x3p[1]

    return x_max, y_max, a
