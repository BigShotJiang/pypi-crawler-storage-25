"""Normalized correlation coefficient."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from .xcorr import xcorr

if TYPE_CHECKING:
    from numpy.typing import NDArray


def ncc(
    sig1: NDArray[np.complexfloating] | NDArray[np.floating],
    sig2: NDArray[np.complexfloating] | NDArray[np.floating],
    max_lags: int | None = None,
) -> float:
    """Normalized correlation coefficient between two signals.

    Computes the peak of the absolute cross-correlation normalized
    by the geometric mean of signal energies:

        NCC = max(|xcorr(sig1, sig2)|) / sqrt(E1 * E2)

    where E1 = sum(|sig1|^2) and E2 = sum(|sig2|^2).

    Args:
        sig1: First signal, 1D array.
        sig2: Second signal, 1D array.
        max_lags: Optional lag limit passed to xcorr.

    Returns:
        Scalar in [0, 1]. Values near 1 indicate strong correlation;
        values near 0 indicate uncorrelated signals or noise.
    """
    corr = xcorr(sig1, sig2, max_lags=max_lags)
    peak = float(np.max(np.abs(corr)))
    energy1 = float(np.sum(np.abs(sig1) ** 2))
    energy2 = float(np.sum(np.abs(sig2) ** 2))
    return peak / (np.sqrt(energy1 * energy2) + 1e-12)
