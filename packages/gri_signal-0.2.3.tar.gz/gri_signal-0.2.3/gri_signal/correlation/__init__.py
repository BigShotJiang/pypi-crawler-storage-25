"""Correlation and peak finding functions.

Provides cross-correlation, quadratic interpolation for sub-sample peak finding,
normalized correlation coefficient, and peak-to-sidelobe ratio.
"""

from .ncc import ncc
from .pslr import pslr
from .qint import qint
from .xcorr import xcorr

__all__ = [
    "ncc",
    "pslr",
    "qint",
    "xcorr",
]
