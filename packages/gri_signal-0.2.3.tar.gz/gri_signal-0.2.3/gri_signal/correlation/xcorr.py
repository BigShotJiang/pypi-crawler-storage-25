"""Equivalent of matlab xcorr with lags."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from scipy.signal import correlate

if TYPE_CHECKING:
    from numpy.typing import NDArray


def xcorr(
    sig1: NDArray[np.floating] | NDArray[np.complexfloating],
    sig2: NDArray[np.floating] | NDArray[np.complexfloating],
    max_lags: int | None = None,
    *,
    norm: bool = False,
) -> NDArray[np.floating] | NDArray[np.complexfloating]:
    """Cross correlation like matlab does it.

    Args:
        sig1: 1D signal.
        sig2: 1D signal.
        max_lags: Max lag bins (plus and minus, so 100 means return a
            correlation with 201 bins, 0 at the center).
        norm: If True, normalize output so peak magnitude is 1.0.

    Returns:
        Cross correlation at different time shifts (lags).
    """
    corr: NDArray = correlate(sig1, sig2, mode="full", method="fft")
    if max_lags is not None:
        # center is zero
        center = len(corr) // 2
        corr = corr[center - max_lags : center + max_lags + 1]
    if norm:
        peak = np.max(np.abs(corr))
        if peak > 0:
            corr = corr / peak
    return corr
