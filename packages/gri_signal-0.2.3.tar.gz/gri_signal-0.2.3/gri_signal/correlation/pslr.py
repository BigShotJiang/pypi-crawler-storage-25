"""Peak-to-sidelobe ratio."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from scipy.signal import argrelmax

if TYPE_CHECKING:
    from numpy.typing import NDArray


def pslr(
    corr: NDArray[np.floating] | NDArray[np.complexfloating],
) -> float | None:
    """Peak-to-sidelobe ratio of a correlation or spectrum.

    Finds local maxima in abs(corr), then returns the dB difference
    between the largest and second-largest peak:

        PSLR = 20 * log10(|peak1| / |peak2|)

    Works on any 1D array: cross-correlation, PSD, MUSIC spectrum,
    matched-filter output, etc.

    Args:
        corr: 1D correlation or spectral array.

    Returns:
        PSLR in dB, or None if fewer than 2 local maxima exist.
    """
    magnitude = np.abs(corr)
    (maxima_indices,) = argrelmax(magnitude, order=1)

    _min_peaks = 2
    if len(maxima_indices) < _min_peaks:
        return None

    # Sort descending by magnitude
    sorted_vals = np.sort(magnitude[maxima_indices])[::-1]
    peak1 = sorted_vals[0]
    peak2 = sorted_vals[1]

    if peak2 <= 0:
        return None

    return float(20.0 * np.log10(peak1 / peak2))
