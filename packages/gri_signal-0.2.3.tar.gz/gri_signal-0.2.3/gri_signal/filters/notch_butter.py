"""Notch (bandstop) Butterworth filter."""

from __future__ import annotations

from typing import TYPE_CHECKING

from scipy import signal

if TYPE_CHECKING:
    from numpy.typing import NDArray


def notch_butter(
    fs: float,
    hz_low: float,
    hz_high: float,
    sig: NDArray,
    *,
    order: float | None = None,
) -> NDArray:
    """Create a notch (bandstop) Butterworth filter.

    Attenuates frequencies between hz_low and hz_high while passing all others.

    Note there can a slight phase "ringing" at the very beginning and end of the
    filtered signal (around 0.01 radians) which settles out around the window width.

    Args:
        fs(float): sample frequency (samples per second)
        hz_low(float): Low edge of notch (frequencies below this pass)
        hz_high(float): High edge of notch (frequencies above this pass)
        sig(np.ndarray): row-major (nchan x n) signals or 1D signal
        order(float,optional): Filter order, higher is steeper. Default is 4.

    Returns:
        filtered signal
    """
    if hz_low <= 0 or hz_high <= 0:
        raise ValueError("Must have positive stop frequencies.")
    if hz_low >= hz_high:
        raise ValueError("hz_low must be less than hz_high.")
    # Design the filter
    order = 4 if order is None else order
    low = 2 * hz_low / fs
    high = 2 * hz_high / fs
    sos = signal.butter(order, [low, high], btype="bandstop", output="sos")

    # Don't alter the original
    sig_filt = sig.copy()
    # Make a view a 2D columnar array so we can do row-wise operations
    m = 1 if sig_filt.ndim == 1 else sig_filt.shape[0]
    sig_filt = sig_filt.reshape((m, -1))
    # Apply the filter
    for row_idx, row in enumerate(sig_filt):  # type: ignore  # noqa: PGH003
        sig_filt[row_idx] = signal.sosfiltfilt(sos, row)
    return sig_filt.reshape(sig.shape)
