"""Lowpass filter."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from scipy.fft import fft, ifft
from scipy.signal.windows import hann

if TYPE_CHECKING:
    from numpy.typing import NDArray


def lowpass_fft(
    fs: float,
    hz_cutoff: float,
    sig: NDArray,
    *,
    win_size: int | None = None,
) -> NDArray:
    """Create a lowpass FFT filter.

    Transform into power domain via FFT, apply a designed filter, then transform back.

    Args:
        fs(float): sample frequency (samples per second)
        hz_cutoff(float): High cutoff frequency
        sig(np.ndarray): row-major (nchan x n) signals or 1D signal
        win_size(int,optional): Window size for smoothing. Should be odd and positive.
            If even, 1 will be added, so window=0 will be the same as window=1. Smaller
            is steeper cutoff but will have frequency effects.

    Returns:
        filtered signal
    """
    if hz_cutoff <= 0:
        raise ValueError("Must have positive stop frequencies.")
    ### Design the FFT filter
    # Get the length
    n: int = sig.shape[0] if sig.ndim == 1 else sig.shape[1]
    # How many bins from zero: Each bin is fs/n
    # The negative index of f[1] = [0,1,2,-1] is -1, and f[1] = [0,1,2,-2,-1] is -1
    idx = round(hz_cutoff / (fs / n)) + 1
    # Build a gate of ones and zeros
    filt = np.ones(n, dtype=float)
    filt[idx:-idx] = 0
    # Apply some smoothing
    win_size = min(n // 10, 31) if win_size is None else win_size
    if win_size % 2 == 0:
        win_size += 1
    if win_size > 1:
        # Create hann smoothing window
        window = hann(win_size) / (win_size // 2)
        # pad filt to remove low frequency convolve
        filt = np.pad(filt, (win_size, win_size), mode="constant", constant_values=1)
        # Convolve and go back to original size
        filt = np.convolve(filt, window, mode="same")[win_size:-win_size]

    # Get the fft
    fft_m = np.asarray(fft(sig))
    # Apply the filter to the fft
    fft_m = fft_m * filt
    # invert the fft
    return np.asarray(ifft(fft_m))
