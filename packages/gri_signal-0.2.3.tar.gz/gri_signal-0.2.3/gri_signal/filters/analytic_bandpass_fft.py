"""Lowpass filter."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from scipy.fft import fft, ifft
from scipy.signal.windows import hann

if TYPE_CHECKING:
    from numpy.typing import NDArray


def analytic_bandpass_fft(
    fs: float,
    hz_low: float,
    hz_high: float,
    sig: NDArray,
    *,
    win_size: int | None = None,
) -> NDArray:
    """Create an analytic bandpass filter via FFT.

    The analytic bandpass passes a single band of frequencies, treating the power
    spectrum as an already shifted (to carrier or center frequency as zero) positive
    side of the power spectrum. Therefore, it can take negatives in the stop frequencies
    as long as high is greater than low.

    Transform into power domain via FFT, apply the filter, then transform back.

    Args:
        fs(float): sample frequency (samples per second)
        hz_low(float): Low cutoff frequency
        hz_high(float): High cutoff frequency
        sig(np.ndarray): row-major (nchan x n) signals or 1D signal
        win_size(int,optional): Window size for smoothing. Should be odd and positive.
            If even, 1 will be added, so window=0 will be the same as window=1. Smaller
            is steeper cutoff but will have frequency effects.

    Returns:
        filtered signal
    """
    if hz_low >= hz_high:
        raise ValueError("High stop must be greater than low stop.")
    ### Design the FFT filter
    # Get the length
    n: int = sig.shape[0] if sig.ndim == 1 else sig.shape[1]
    # The negative index of f[1] = [0,1,2,-1] is -1, and f[1] = [0,1,2,-2,-1] is -1
    idx_low = round(abs(hz_low) / (fs / n)) + 1
    if hz_low < 0:
        idx_low *= -1
    idx_high = round(abs(hz_high) / (fs / n)) + 1
    if hz_high < 0:
        idx_high *= -1
    # Build a gate of ones and zeros
    filt = np.zeros(n, dtype=float)
    pad_val = 0
    if idx_low * idx_high >= 0:
        filt[idx_low:idx_high] = 1
    else:
        filt[0:idx_high] = 1
        filt[idx_low:-1] = 1
        pad_val = 1
    # Apply some smoothing
    win_size = min(n // 10, 31) if win_size is None else win_size
    if win_size % 2 == 0:
        win_size += 1
    if win_size > 1:
        # Create hann smoothing window
        window = hann(win_size) / (win_size // 2)
        # pad filt to remove low frequency convolve
        filt = np.pad(
            filt,
            (win_size, win_size),
            mode="constant",
            constant_values=pad_val,
        )
        # Convolve and go back to original size
        filt = np.convolve(filt, window, mode="same")[win_size:-win_size]

    # Get the fft
    fft_m = np.asarray(fft(sig))
    # Apply the filter to the fft
    fft_m = fft_m * filt
    # invert the fft
    return np.asarray(ifft(fft_m))
