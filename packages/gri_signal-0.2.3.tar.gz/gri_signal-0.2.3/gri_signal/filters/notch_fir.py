"""Notch (bandstop) FIR filter."""

from __future__ import annotations

from typing import TYPE_CHECKING

from scipy import signal

if TYPE_CHECKING:
    from numpy.typing import NDArray


def notch_fir(
    fs: float,
    hz_low: float,
    hz_high: float,
    sig: NDArray,
    *,
    taps_order: float | None = None,
) -> NDArray:
    """Create a notch (bandstop) FIR filter.

    Attenuates frequencies between hz_low and hz_high while passing all others.

    Note there can a slight phase "ringing" at the very beginning and end of the
    filtered signal (around 0.005 radians) which settles out around the window width.

    Args:
        fs(float): sample frequency (samples per second)
        hz_low(float): Low edge of notch (frequencies below this pass)
        hz_high(float): High edge of notch (frequencies above this pass)
        sig(np.ndarray): row-major (nchan x n) signals or 1D signal
        taps_order(float,optional): Filter length estimate, higher is steeper. The
            numtaps argument defaults to 8*fs/hz_high+1 where "8" is the taps_order.
            Higher numbers are steeper.

    Returns:
        filtered signal
    """
    if hz_low <= 0 or hz_high <= 0:
        raise ValueError("Must have positive stop frequencies.")
    if hz_low >= hz_high:
        raise ValueError("hz_low must be less than hz_high.")
    # Design the FIR filter
    order = 8 if taps_order is None else taps_order
    numtaps = int(order * fs / hz_high)
    if numtaps % 2 == 0:
        numtaps += 1
    fir_coeffs = signal.firwin(numtaps, [hz_low, hz_high], fs=fs, pass_zero=True)  # type: ignore  # noqa: PGH003

    # Don't alter the original
    sig_filt = sig.copy()
    # Make a view a 2D columnar array so we can do row-wise operations
    m = 1 if sig_filt.ndim == 1 else sig_filt.shape[0]
    sig_filt = sig_filt.reshape((m, -1))
    # Apply the filter
    for row_idx, row in enumerate(sig_filt):  # type: ignore  # noqa: PGH003
        sig_filt[row_idx] = signal.filtfilt(fir_coeffs, 1, row)
    return sig_filt.reshape(sig.shape)
