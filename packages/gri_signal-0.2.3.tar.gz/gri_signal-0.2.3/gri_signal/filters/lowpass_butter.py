"""Lowpass filter."""

from __future__ import annotations

from typing import TYPE_CHECKING

from scipy import signal

if TYPE_CHECKING:
    from numpy.typing import NDArray


def lowpass_butter(
    fs: float,
    hz_cutoff: float,
    sig: NDArray,
    *,
    order: float | None = None,
) -> NDArray:
    """Create a lowpass Butterworth filter.

    Note there can a slight phase "ringing" at the very beginning and end of the
    filtered signal (around 0.01 radians) which settles out around the window width.

    Args:
        fs(float): sample frequency (samples per second)
        hz_cutoff(float): High cutoff frequency
        sig(np.ndarray): row-major (nchan x n) signals or 1D signal
        order(float,optional): Filter length estimate, higher is steeper.

    Returns:
        filtered signal
    """
    if hz_cutoff <= 0:
        raise ValueError("Must have positive stop frequencies.")
    # Design the filter
    order = 4 if order is None else order
    cutoff = 2 * hz_cutoff / fs
    sos = signal.butter(order, cutoff, btype="lowpass", analog=False, output="sos")

    # Don't alter the original
    sig_filt = sig.copy()
    # Make a view a 2D columnar array so we can do row-wise operations
    m = 1 if sig_filt.ndim == 1 else sig_filt.shape[0]
    sig_filt = sig_filt.reshape((m, -1))
    # Apply the filter
    for row_idx, row in enumerate(sig_filt):  # type: ignore  # noqa: PGH003
        sig_filt[row_idx] = signal.sosfiltfilt(sos, row)
    return sig_filt.reshape(sig.shape)
