"""Lowpass filter."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from .lowpass_butter import lowpass_butter

if TYPE_CHECKING:
    from numpy.typing import NDArray


def analytic_bandpass_butter(
    fs: float,
    hz_low: float,
    hz_high: float,
    sig: NDArray,
    *,
    order: float | None = None,
) -> NDArray:
    """Create a bandpass Butterworth filter.

    The analytic bandpass passes a single band of frequencies, treating the power
    spectrum as an already shifted (to carrier or center frequency as zero) positive
    side of the power spectrum. Therefore, it can take negatives in the stop frequencies
    as long as high is greater than low.

    Shift the signal to the center frequency of the bandpass, then perform a lowpass
    symmetric filter, and shift back.

    Note there can a slight phase "ringing" at the very beginning and end of the
    filtered signal (around 0.01 radians) which settles out around the window width.

    Args:
        fs(float): sample frequency (samples per second)
        hz_low(float): Low cutoff frequency
        hz_high(float): High cutoff frequency
        sig(np.ndarray): row-major (nchan x n) signals or 1D signal
        order(float,optional): Filter length estimate, higher is steeper. The
            numtaps argument defaults to 8*fs/hz_cutoff+1 where "8" is the taps_order.
            Higher numbers are steeper.

    Returns:
        filtered signal
    """
    if hz_low >= hz_high:
        raise ValueError("High stop must be greater than low stop.")
    n: int = sig.shape[0] if sig.ndim == 1 else sig.shape[1]
    f_center = (hz_high + hz_low) / 2
    f_bw = hz_high - hz_low
    t = np.arange(0, n / fs, 1 / fs, dtype=float)
    # Shift to center frequency
    sig_filt = sig * np.exp(-2j * np.pi * f_center * t)
    # Apply lowpass
    sig_filt = lowpass_butter(fs, f_bw / 2, sig_filt, order=order)
    # Shift back to original frequency
    sig_filt = sig_filt * np.exp(2j * np.pi * f_center * t)

    return sig_filt.reshape(sig.shape)
