"""Pulse detection primitives.

Threshold-based peak detection on signal envelopes and utilities
for scoring detections against ground-truth labels.
"""

from .detect_pulses import detect_pulses
from .match_detections import DetectionResult, match_detections

__all__ = ["DetectionResult", "detect_pulses", "match_detections"]
