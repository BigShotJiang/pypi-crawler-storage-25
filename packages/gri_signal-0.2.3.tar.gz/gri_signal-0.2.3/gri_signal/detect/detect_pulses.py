"""Threshold-based pulse peak detection."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import numpy as np
from scipy.signal import find_peaks

if TYPE_CHECKING:
    from numpy.typing import NDArray

_log = logging.getLogger(__name__)


def detect_pulses(
    iq: NDArray[np.complexfloating],
    sample_rate_hz: float,
    min_pri_s: float,
    *,
    threshold_frac: float = 0.4,
) -> NDArray[np.intp]:
    """Threshold-based pulse detector on IQ data.

    Finds peaks in the signal envelope that exceed a fraction of the
    maximum amplitude, with a minimum separation derived from the
    expected PRI. Boundary pulses are handled by padding the envelope
    with zeros so peaks at sample 0 or the final sample are not
    rejected by the neighbor requirement.

    Args:
        iq: Complex IQ signal, 1D array.
        sample_rate_hz: Sample rate in Hz.
        min_pri_s: Minimum expected PRI in seconds. Peaks closer than
            half this value are suppressed.
        threshold_frac: Detection threshold as fraction of max
            envelope amplitude. Default 0.4.

    Returns:
        Array of sample indices where pulse peaks were detected.
    """
    mag = np.abs(iq)
    threshold = float(np.max(mag)) * threshold_frac
    min_distance = int(min_pri_s * sample_rate_hz * 0.5)

    mag_padded = np.concatenate(([0.0], mag, [0.0]))
    peaks, _ = find_peaks(mag_padded, height=threshold, distance=min_distance)
    peaks = peaks - 1
    peaks = peaks[(peaks >= 0) & (peaks < len(mag))]

    _log.debug("Detected %d pulses (threshold=%.2f)", len(peaks), threshold_frac)
    return peaks
