"""Match detected pulse positions to ground-truth labels."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from numpy.typing import NDArray

_log = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class DetectionResult:
    """Result of pulse detection matched against ground truth.

    Attributes:
        detected_indices: Sample indices of detected pulse peaks.
        truth_starts: Sample indices of ground-truth pulse starts.
        matched: Number of detections matched to a truth pulse.
        false_alarms: Number of detections with no matching truth.
        missed: Number of truth pulses with no matching detection.
        timing_errors_s: Timing error for each matched detection in
            seconds (detected minus truth).
    """

    detected_indices: NDArray[np.intp]
    truth_starts: list[int]
    matched: int
    false_alarms: int
    missed: int
    timing_errors_s: list[float]

    @property
    def detection_rate(self) -> float:
        """Fraction of truth pulses that were detected."""
        if not self.truth_starts:
            return 0.0
        return self.matched / len(self.truth_starts)

    @property
    def mean_timing_error_s(self) -> float:
        """Mean absolute timing error in seconds, or 0 if no matches."""
        if not self.timing_errors_s:
            return 0.0
        return float(np.mean(np.abs(self.timing_errors_s)))


def match_detections(
    detected_indices: NDArray[np.intp],
    truth_starts: list[int],
    sample_rate_hz: float,
    pulse_width_s: float,
) -> DetectionResult:
    """Match detected pulse positions to ground-truth labels.

    Each detection is matched to the nearest truth pulse within a
    tolerance of 3x the pulse width in samples. Unmatched detections
    are false alarms; unmatched truth pulses are misses.

    Args:
        detected_indices: Sample indices of detected peaks.
        truth_starts: Sample indices of ground-truth pulse starts.
        sample_rate_hz: Sample rate in Hz.
        pulse_width_s: Pulse width in seconds (sets match tolerance).

    Returns:
        DetectionResult with match statistics and timing errors.
    """
    pw_samples = round(pulse_width_s * sample_rate_hz)
    tolerance = pw_samples * 3

    matched = 0
    timing_errors_s: list[float] = []
    matched_truth: set[int] = set()

    for det in detected_indices:
        diffs = [abs(int(det) - ts) for ts in truth_starts]
        if not diffs:
            continue
        nearest_idx = int(np.argmin(diffs))
        if diffs[nearest_idx] < tolerance and nearest_idx not in matched_truth:
            matched += 1
            matched_truth.add(nearest_idx)
            timing_errors_s.append(
                (int(det) - truth_starts[nearest_idx]) / sample_rate_hz,
            )

    false_alarms = len(detected_indices) - matched
    missed = len(truth_starts) - matched

    _log.debug(
        "Matched %d/%d, false_alarms=%d, missed=%d",
        matched,
        len(truth_starts),
        false_alarms,
        missed,
    )

    return DetectionResult(
        detected_indices=detected_indices,
        truth_starts=truth_starts,
        matched=matched,
        false_alarms=false_alarms,
        missed=missed,
        timing_errors_s=timing_errors_s,
    )
