"""Apply attenuation or gain to a signal."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import numpy as np
    from numpy.typing import NDArray


def attenuation(
    sig: NDArray[np.floating | np.complexfloating],
    db: float,
) -> NDArray[np.floating | np.complexfloating]:
    """Apply attenuation or gain to a signal.

    Scales a signal by a specified amount in decibels. Positive values
    attenuate (reduce amplitude), negative values amplify.

    Args:
        sig: Input signal as an array. Can be real or complex, any shape.
        db: Attenuation in decibels. Positive values reduce amplitude,
            negative values increase it.

    Returns:
        Scaled signal with the same shape and dtype as input.

    Examples:
        >>> # Attenuate by 6 dB (half amplitude)
        >>> sig = np.ones(100)
        >>> attenuated = attenuation(sig, 6.0)
        >>> np.allclose(attenuated, 0.501, atol=0.01)
        True

        >>> # Amplify by 6 dB (double amplitude)
        >>> amplified = attenuation(sig, -6.0)
        >>> np.allclose(amplified, 1.995, atol=0.01)
        True

        >>> # Free-space path loss example (40 dB)
        >>> received = attenuation(transmitted, 40.0)

    Notes:
        The scaling factor is: 10^(-dB/20)

        Common values:
        - 6 dB ≈ 0.5x amplitude (half)
        - 20 dB ≈ 0.1x amplitude (tenth)
        - 40 dB ≈ 0.01x amplitude (hundredth)
    """
    scale = 10 ** (-db / 20)
    return sig * scale
