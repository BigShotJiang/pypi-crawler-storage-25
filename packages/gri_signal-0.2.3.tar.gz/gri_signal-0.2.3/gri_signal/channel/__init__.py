"""Channel effects.

Provides functions for simulating signal propagation effects including
time delays, noise, attenuation, Doppler shift, and multipath.
"""

from .attenuation import attenuation
from .awgn import awgn
from .delay import delay
from .doppler import doppler
from .multipath import multipath

__all__ = [
    "attenuation",
    "awgn",
    "delay",
    "doppler",
    "multipath",
]
