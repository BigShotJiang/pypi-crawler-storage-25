"""Apply Doppler frequency shift to a signal."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from numpy.typing import NDArray


def doppler(
    sig: NDArray[np.floating | np.complexfloating],
    fs: float,
    f_shift: float,
    *,
    f_rate: float = 0.0,
) -> NDArray[np.complexfloating]:
    """Apply Doppler frequency shift to a signal.

    Simulates the frequency shift caused by relative motion between transmitter
    and receiver. Supports both constant Doppler shift and linear Doppler rate
    (frequency drift) for accelerating platforms.

    Args:
        sig: Input signal as a 1D array. Can be real or complex.
        fs: Sample rate in Hz.
        f_shift: Initial frequency shift in Hz. Positive values shift frequency
            up (approaching source), negative values shift down (receding source).
        f_rate: Rate of change of frequency shift in Hz/s (Doppler rate).
            Models acceleration. Defaults to 0 (constant velocity).

    Returns:
        Frequency-shifted signal as a complex array with the same length as input.

    Examples:
        >>> # Constant Doppler shift of 100 Hz (approaching target)
        >>> t = np.arange(10000) / 1e6
        >>> sig = np.exp(1j * 2 * np.pi * 1000 * t)  # 1 kHz tone
        >>> shifted = doppler(sig, 1e6, 100.0)
        >>> # Result is a 1.1 kHz tone

        >>> # Doppler with linear drift (accelerating platform)
        >>> # Initial shift 100 Hz, increasing at 10 Hz/s
        >>> shifted = doppler(sig, 1e6, 100.0, f_rate=10.0)

        >>> # Receding target (negative shift)
        >>> shifted = doppler(sig, 1e6, -50.0)

    Notes:
        The Doppler shift is applied by multiplying with a complex exponential:
        - Constant: exp(j * 2π * f_shift * t)
        - With rate: exp(j * 2π * (f_shift * t + 0.5 * f_rate * t²))

        For a target with radial velocity v, the Doppler shift is:
        f_doppler = f_carrier * (v / c)

        where c is the speed of light (~3e8 m/s).
    """
    sig = np.asarray(sig, dtype=np.complex128)
    n = len(sig)
    t = np.arange(n) / fs

    # Phase accumulation: φ(t) = 2π * (f_shift * t + 0.5 * f_rate * t²)
    # Instantaneous frequency: f(t) = f_shift + f_rate * t
    phase = 2 * np.pi * (f_shift * t + 0.5 * f_rate * t**2)

    return sig * np.exp(1j * phase)
