"""Add additive white Gaussian noise (AWGN) to a signal."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from numpy.typing import NDArray


def awgn(
    sig: NDArray[np.floating | np.complexfloating],
    snr_db: float,
    *,
    seed: int | None = None,
) -> NDArray[np.complexfloating]:
    """Add additive white Gaussian noise (AWGN) to a signal.

    Adds complex Gaussian noise to achieve the specified signal-to-noise ratio.
    The noise power is calculated relative to the signal power.

    Args:
        sig: Input signal as a 1D or 2D array. Can be real or complex.
            For 2D arrays, shape should be (channels, samples).
        snr_db: Desired signal-to-noise ratio in decibels. Higher values
            mean less noise relative to signal.
        seed: Random seed for reproducibility.

    Returns:
        Signal with added noise as a complex array with the same shape as input.

    Examples:
        >>> # Add 10 dB SNR noise to a tone
        >>> t = np.linspace(0, 1, 1000)
        >>> sig = np.exp(1j * 2 * np.pi * 100 * t)
        >>> noisy = awgn(sig, 10.0)

        >>> # Reproducible noise
        >>> noisy1 = awgn(sig, 10.0, seed=42)
        >>> noisy2 = awgn(sig, 10.0, seed=42)
        >>> np.allclose(noisy1, noisy2)
        True

        >>> # Multi-channel signal
        >>> sig = np.random.randn(4, 1000) + 1j * np.random.randn(4, 1000)
        >>> noisy = awgn(sig, 20.0)

    Notes:
        SNR is defined as: SNR_dB = 10 * log10(signal_power / noise_power)

        For complex signals, noise is added independently to real and imaginary
        parts with equal variance, such that the total noise power matches the
        target SNR.
    """
    rng = np.random.default_rng(seed)

    # Ensure complex output
    sig = np.asarray(sig, dtype=np.complex128)

    # Calculate signal power
    signal_power = np.mean(np.abs(sig) ** 2)

    # Calculate required noise power from SNR
    # SNR_dB = 10 * log10(Ps / Pn) => Pn = Ps / 10^(SNR_dB/10)
    noise_power = signal_power / (10 ** (snr_db / 10))

    # Generate complex noise with correct power
    # For complex noise: total_power = var_real + var_imag = 2 * var_component
    # So var_component = noise_power / 2
    noise_std = np.sqrt(noise_power / 2)

    noise = noise_std * (
        rng.standard_normal(sig.shape) + 1j * rng.standard_normal(sig.shape)
    )

    return sig + noise
