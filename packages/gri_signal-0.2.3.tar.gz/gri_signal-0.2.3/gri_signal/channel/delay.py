"""Apply time delay to a signal using FFT phase shift."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from scipy.fft import fft, ifft

if TYPE_CHECKING:
    from numpy.typing import NDArray


def delay(
    sig: NDArray[np.floating | np.complexfloating],
    delay_time: float,
    fs: float,
) -> NDArray[np.complexfloating]:
    """Apply a time delay to a signal using the Fourier shift theorem.

    Delays a signal by applying a linear phase ramp in the frequency domain.
    This method provides sub-sample precision delay, making it suitable for
    simulating propagation delays in multipath scenarios.

    Args:
        sig: Input signal as a 1D array. Can be real or complex.
        delay_time: Delay time in seconds. Positive values delay the signal
            forward in time (shift right). Negative values advance it.
        fs: Sample rate in Hz.

    Returns:
        Delayed signal as a complex array with the same length as input.
        Use np.real() to extract the real part if the input was real-valued.

    Examples:
        >>> # Delay a 440 Hz tone by 100ms
        >>> t = np.linspace(0, 1, 44100)
        >>> sig = np.sin(2 * np.pi * 440 * t)
        >>> delayed = delay(sig, 0.1, 44100)
        >>> delayed_real = np.real(delayed)

        >>> # Sub-sample delay (0.5 samples at 1000 Hz sample rate)
        >>> sig = np.exp(1j * 2 * np.pi * 100 * np.arange(1000) / 1000)
        >>> delayed = delay(sig, 0.5e-3, 1000)

    Notes:
        The delay is implemented via the Fourier shift theorem:
        A time delay τ corresponds to multiplying the spectrum by exp(-j2πfτ).
        This is exact for bandlimited signals and provides smooth interpolation
        for fractional sample delays.
    """
    n = len(sig)
    frequencies = np.arange(n) * (fs / n)

    # Phase shift corresponding to time delay
    phase_shift = np.exp(-1j * 2 * np.pi * frequencies * delay_time)

    # Apply delay in frequency domain
    spectrum = fft(sig)
    spectrum_delayed = spectrum * phase_shift
    delayed_signal: NDArray[np.complexfloating] = np.asarray(ifft(spectrum_delayed))

    return delayed_signal
