"""Simulate multipath propagation channel."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from scipy.fft import fft, ifft

if TYPE_CHECKING:
    from numpy.typing import NDArray


def multipath(
    sig: NDArray[np.floating | np.complexfloating],
    fs: float,
    delays: NDArray[np.floating] | list[float],
    amplitudes: NDArray[np.floating | np.complexfloating] | list[float | complex],
) -> NDArray[np.complexfloating]:
    """Simulate multipath propagation using a tapped delay line model.

    Combines multiple delayed and attenuated copies of the input signal to model
    reflections from surfaces, buildings, terrain, or ionospheric layers. Each
    path is characterized by its delay and complex amplitude.

    Args:
        sig: Input signal as a 1D array. Can be real or complex.
        fs: Sample rate in Hz.
        delays: Array of path delays in seconds. The first path is typically
            the line-of-sight (LOS) with delay=0. Must have same length as
            amplitudes.
        amplitudes: Array of complex path amplitudes. Magnitude represents
            attenuation, phase represents phase shift from reflection.
            Must have same length as delays.

    Returns:
        Combined multipath signal as a complex array with the same length as input.

    Examples:
        >>> # Two-path model: LOS + single reflection
        >>> sig = np.exp(1j * 2 * np.pi * 1000 * np.arange(10000) / 1e6)
        >>> delays = [0, 1e-6]  # LOS and 1 microsecond delayed reflection
        >>> amplitudes = [1.0, 0.5 * np.exp(1j * np.pi)]  # Half power, 180° phase
        >>> received = multipath(sig, 1e6, delays, amplitudes)

        >>> # Urban multipath: LOS + 3 reflections
        >>> delays = [0, 0.5e-6, 1.2e-6, 2.0e-6]
        >>> amplitudes = [1.0, 0.3, 0.2, 0.1]  # Decreasing amplitude
        >>> received = multipath(sig, fs, delays, amplitudes)

        >>> # Ionospheric multipath (long delays)
        >>> delays = [0, 2e-3, 5e-3]  # Millisecond-scale delays
        >>> amplitudes = [1.0, 0.7, 0.3]
        >>> received = multipath(sig, fs, delays, amplitudes)

    Notes:
        The output is computed as:
        y(t) = Σ_k a_k * x(t - τ_k)

        where a_k and τ_k are the amplitude and delay of the k-th path.

        Delays are implemented using FFT-based phase shifting for sub-sample
        precision. This is exact for bandlimited signals.

        For realistic channel modeling, combine with:
        - `doppler()` for moving reflectors
        - `awgn()` for thermal noise
        - Time-varying amplitudes for fading
    """
    sig = np.asarray(sig, dtype=np.complex128)
    delays = np.asarray(delays)
    amplitudes = np.asarray(amplitudes, dtype=np.complex128)

    if len(delays) != len(amplitudes):
        msg = (
            f"delays and amplitudes must have same length, "
            f"got {len(delays)} and {len(amplitudes)}"
        )
        raise ValueError(msg)

    if len(delays) == 0:
        msg = "must specify at least one path"
        raise ValueError(msg)

    n = len(sig)
    frequencies = np.arange(n) * (fs / n)

    # Transform input signal once
    spectrum = fft(sig)

    # Accumulate contributions from each path
    output_spectrum = np.zeros(n, dtype=np.complex128)

    for delay_time, amplitude in zip(delays, amplitudes, strict=True):
        # Phase shift for this delay
        phase_shift = np.exp(-1j * 2 * np.pi * frequencies * delay_time)
        output_spectrum += amplitude * spectrum * phase_shift

    result: NDArray[np.complexfloating] = np.asarray(ifft(output_spectrum))
    return result
