"""Free-space path loss."""

from __future__ import annotations

import math

# Speed of light (m/s), exact per SI definition.
C = 299_792_458.0


def fspl_db(range_m: float, freq_hz: float) -> float:
    """Free-space path loss in dB.

    FSPL = 20 * log10(4 * pi * R * f / c)

    This is the inverse-square spreading loss plus the frequency-dependent
    effective aperture of an isotropic antenna.

    Args:
        range_m: Slant range in meters. Must be positive.
        freq_hz: Carrier frequency in Hz. Must be positive.

    Returns:
        Path loss in dB (positive value = loss).

    Raises:
        ValueError: If range_m or freq_hz is not positive.
    """
    if range_m <= 0:
        raise ValueError("range_m must be positive")
    if freq_hz <= 0:
        raise ValueError("freq_hz must be positive")
    return 20.0 * math.log10(4.0 * math.pi * range_m * freq_hz / C)
