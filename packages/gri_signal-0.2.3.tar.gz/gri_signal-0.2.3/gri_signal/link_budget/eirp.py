"""Effective isotropic radiated power."""

from __future__ import annotations

import math


def eirp_dbw(peak_power_w: float, antenna_gain_dbi: float) -> float:
    """Effective isotropic radiated power in dBW.

    EIRP = 10 * log10(P_tx) + G_tx

    Args:
        peak_power_w: Transmitter peak power in watts. Must be positive.
        antenna_gain_dbi: Transmit antenna gain in dBi.

    Returns:
        EIRP in dBW.

    Raises:
        ValueError: If peak_power_w is not positive.
    """
    if peak_power_w <= 0:
        raise ValueError("peak_power_w must be positive")
    return 10.0 * math.log10(peak_power_w) + antenna_gain_dbi
