"""Signal-to-noise ratio from the link equation."""

from __future__ import annotations

from gri_signal.link_budget.noise_power import noise_power_dbw
from gri_signal.link_budget.received_power import received_power_dbw


def snr_db(  # noqa: PLR0913
    eirp_dbw: float,
    range_m: float,
    freq_hz: float,
    noise_temp_k: float,
    bandwidth_hz: float,
    *,
    atmo_loss_db: float = 0.0,
    collector_gain_dbi: float = 0.0,
) -> float:
    """Single-pulse signal-to-noise ratio in dB.

    SNR = P_rx - N

    where P_rx is the received power (from the link equation) and N is
    the thermal noise power (from kTB).

    Args:
        eirp_dbw: Effective isotropic radiated power in dBW.
        range_m: Slant range in meters.
        freq_hz: Carrier frequency in Hz.
        noise_temp_k: System noise temperature in Kelvin.
        bandwidth_hz: Receiver noise bandwidth in Hz.
        atmo_loss_db: One-way atmospheric loss in dB. Default 0.
        collector_gain_dbi: Collector antenna gain in dBi. Default 0.

    Returns:
        SNR in dB.
    """
    p_rx = received_power_dbw(
        eirp_dbw,
        range_m,
        freq_hz,
        atmo_loss_db=atmo_loss_db,
        collector_gain_dbi=collector_gain_dbi,
    )
    n = noise_power_dbw(noise_temp_k, bandwidth_hz)
    return p_rx - n
