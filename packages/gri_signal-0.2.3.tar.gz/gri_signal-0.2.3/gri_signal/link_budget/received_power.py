"""Received signal power (direct path and multipath)."""

from __future__ import annotations

from gri_signal.link_budget.fspl import fspl_db


def received_power_dbw(
    eirp_dbw: float,
    range_m: float,
    freq_hz: float,
    *,
    atmo_loss_db: float = 0.0,
    collector_gain_dbi: float = 0.0,
) -> float:
    """Received power at the collector input in dBW.

    P_rx = EIRP - FSPL(R, f) - L_atmo + G_rx

    Args:
        eirp_dbw: Effective isotropic radiated power in dBW.
        range_m: Slant range in meters.
        freq_hz: Carrier frequency in Hz.
        atmo_loss_db: One-way atmospheric loss in dB (positive = loss).
            Default 0 (no atmospheric loss).
        collector_gain_dbi: Collector antenna gain in dBi. Default 0
            (omnidirectional).

    Returns:
        Received power in dBW.
    """
    return eirp_dbw - fspl_db(range_m, freq_hz) - atmo_loss_db + collector_gain_dbi


def multipath_received_power_dbw(  # noqa: PLR0913
    eirp_dbw: float,
    total_path_m: float,
    freq_hz: float,
    reflection_loss_db: float,
    *,
    atmo_loss_db: float = 0.0,
    collector_gain_dbi: float = 0.0,
) -> float:
    """Received power for a single-bounce multipath path in dBW.

    P_rx_mp = EIRP - FSPL(R1 + R2, f) - L_refl - L_atmo + G_rx

    The total path length (R1 + R2) governs the free-space spreading
    loss. The reflection loss is an additional term from the Fresnel
    coefficient at the ground bounce point.

    Args:
        eirp_dbw: Effective isotropic radiated power in dBW.
        total_path_m: Total reflected path length (R1 + R2) in meters.
        freq_hz: Carrier frequency in Hz.
        reflection_loss_db: Reflection loss at the bounce point in dB
            (positive = loss). From the Fresnel coefficient:
            L_refl = -10 * log10(|Gamma|^2).
        atmo_loss_db: One-way atmospheric loss in dB. Default 0.
        collector_gain_dbi: Collector antenna gain in dBi. Default 0.

    Returns:
        Received multipath power in dBW.
    """
    return (
        eirp_dbw
        - fspl_db(total_path_m, freq_hz)
        - reflection_loss_db
        - atmo_loss_db
        + collector_gain_dbi
    )


def multipath_relative_db(
    direct_range_m: float,
    total_path_m: float,
    freq_hz: float,
    reflection_loss_db: float,
) -> float:
    """Multipath tap amplitude relative to the direct path in dB.

    Returns the power difference between a reflected path and the direct
    path. This is the value needed for tapped-delay-line amplitude ratios
    (e.g., gri-sigsim Channel.with_multipath()).

    Args:
        direct_range_m: Direct path range in meters.
        total_path_m: Total reflected path length (R1 + R2) in meters.
        freq_hz: Carrier frequency in Hz.
        reflection_loss_db: Reflection loss at the bounce point in dB.

    Returns:
        Relative power in dB (always negative: multipath is weaker
        than direct path).
    """
    fspl_direct = fspl_db(direct_range_m, freq_hz)
    fspl_reflected = fspl_db(total_path_m, freq_hz)
    return fspl_direct - fspl_reflected - reflection_loss_db
