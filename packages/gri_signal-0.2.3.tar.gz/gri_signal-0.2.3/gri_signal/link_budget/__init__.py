"""Link budget primitives.

Provides functions for computing free-space path loss, thermal noise
power, EIRP, received signal power, and signal-to-noise ratio from
the standard link equation. Includes multipath variants for reflected
paths.
"""

from .eirp import eirp_dbw
from .fspl import C, fspl_db
from .noise_power import K_BOLTZMANN, K_BOLTZMANN_DB, noise_power_dbw
from .received_power import (
    multipath_received_power_dbw,
    multipath_relative_db,
    received_power_dbw,
)
from .snr import snr_db

__all__ = [
    "K_BOLTZMANN",
    "K_BOLTZMANN_DB",
    "C",
    "eirp_dbw",
    "fspl_db",
    "multipath_received_power_dbw",
    "multipath_relative_db",
    "noise_power_dbw",
    "received_power_dbw",
    "snr_db",
]
