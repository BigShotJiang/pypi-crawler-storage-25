"""Thermal noise power."""

from __future__ import annotations

import math

# Boltzmann constant (J/K).
K_BOLTZMANN = 1.380649e-23

# 10 * log10(k) pre-computed for noise power in dBW.
K_BOLTZMANN_DB = 10.0 * math.log10(K_BOLTZMANN)  # -228.599..


def noise_power_dbw(noise_temp_k: float, bandwidth_hz: float) -> float:
    """Thermal noise power in dBW.

    N = k * T_sys * B

    Args:
        noise_temp_k: System noise temperature in Kelvin. Must be positive.
        bandwidth_hz: Receiver noise bandwidth in Hz. Must be positive.

    Returns:
        Noise power in dBW.

    Raises:
        ValueError: If noise_temp_k or bandwidth_hz is not positive.
    """
    if noise_temp_k <= 0:
        raise ValueError("noise_temp_k must be positive")
    if bandwidth_hz <= 0:
        raise ValueError("bandwidth_hz must be positive")
    return (
        K_BOLTZMANN_DB
        + 10.0 * math.log10(noise_temp_k)
        + 10.0 * math.log10(bandwidth_hz)
    )
