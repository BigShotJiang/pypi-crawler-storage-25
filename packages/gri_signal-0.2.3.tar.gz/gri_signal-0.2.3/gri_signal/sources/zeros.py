"""Generate a zero-filled signal array."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from numpy.typing import NDArray


def zeros(
    fs: float,
    *,
    channels: int = 1,
    samples: int | None = None,
    duration: float | None = None,
    dtype: type = complex,
) -> NDArray:
    """Generate a zero-filled signal array.

    Creates a zero-filled array suitable for signal initialization or as a
    base for additive signal construction.

    Args:
        fs: Sampling frequency in samples per second. Used to convert duration
            to samples if duration is provided.
        channels: Number of channels (rows). Defaults to 1.
        samples: Signal length in samples. Provide either samples or duration.
        duration: Signal length in seconds. Provide either samples or duration.
        dtype: Data type for the array. Defaults to complex.

    Returns:
        Zero-filled array of shape (channels, samples) if channels > 1,
        or (samples,) if channels == 1.

    Raises:
        ValueError: If neither samples nor duration is provided.

    Examples:
        >>> sig = zeros(1000, duration=1.0)  # 1 second, single channel
        >>> sig = zeros(1000, samples=500, channels=4)  # 4 channels, 500 samples
        >>> sig = zeros(1000, duration=0.1, dtype=float)  # Real-valued
    """
    if samples is None:
        if duration is None:
            raise ValueError("samples or duration required")
        samples = int(np.round(fs * duration))

    if channels == 1:
        return np.zeros(samples, dtype=dtype)
    return np.zeros((channels, samples), dtype=dtype)
