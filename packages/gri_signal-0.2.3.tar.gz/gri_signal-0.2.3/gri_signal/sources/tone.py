"""Generate a complex tone signal."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from scipy.signal.windows import hann

if TYPE_CHECKING:
    from numpy.typing import NDArray


def tone(  # noqa: PLR0913
    fs: float,
    freq: float,
    *,
    start: float = 0,
    stop: float = -1,
    f_center: float = 0,
    phase_offset: float = 0,
    samples: int | None = None,
    duration: float | None = None,
) -> NDArray[np.complexfloating]:
    """Generate a complex tone signal.

    Creates a complex exponential tone at the specified frequency, optionally
    windowed to start/stop at specific times with Hann smoothing at edges.

    Args:
        fs: Sampling frequency in samples per second.
        freq: Tone frequency in Hz. If f_center is provided, this is the
            absolute frequency and the output will be at (freq - f_center).
        start: Start time of the tone in seconds. Samples before this are zero.
            Defaults to 0.
        stop: Stop time of the tone in seconds. Samples after this are zero.
            Defaults to -1 (full length).
        f_center: Center frequency in Hz for baseband conversion. The output
            tone will be at (freq - f_center). Defaults to 0.
        phase_offset: Initial phase offset in radians. Defaults to 0.
        samples: Signal length in samples. Provide either samples or duration.
        duration: Signal length in seconds. Provide either samples or duration.

    Returns:
        Complex tone signal of shape (samples,).

    Raises:
        ValueError: If neither samples nor duration is provided.
        ValueError: If start > duration.

    Examples:
        >>> sig = tone(1000, 100, duration=1.0)  # 1 second, 100 Hz tone
        >>> sig = tone(1000, 100, samples=1000)  # 1000 samples, 100 Hz tone
        >>> sig = tone(1000, 915e6, f_center=915e6, duration=0.001)  # Baseband
    """
    if samples is None:
        if duration is None:
            raise ValueError("samples or duration required")
        samples = int(np.round(fs * duration))
    if duration is None:
        duration = samples / fs

    if start > duration:
        raise ValueError("No tone: start is after sample duration ends")

    # Generate continuous tone across entire duration
    t = np.linspace(0, duration, samples)
    sig: NDArray[np.complexfloating] = np.exp(1j * 2 * np.pi * (freq - f_center) * t)
    if phase_offset != 0:
        sig = sig * np.exp(1j * phase_offset)

    # Mask the start and stop if needed
    start_idx = int(np.round(start * fs))
    if start_idx > 0:
        sig[0:start_idx] = 0
    if stop > duration:
        stop = -1
    stop_idx = int(np.round(stop * fs)) if stop > start else samples
    stop_idx = min(samples, stop_idx)
    if stop_idx < samples:
        sig[stop_idx:samples] = 0

    # Apply Hann smoothing to avoid sharp transitions
    if start_idx > 0 or stop_idx < samples:
        win_size = max(3, int(fs / freq / 2))
        sig = _hann_smooth(sig, win_size=win_size)

    return sig


def _hann_smooth(
    sig: NDArray[np.complexfloating],
    *,
    win_size: int | None = None,
    pad_val: float = 0,
) -> NDArray[np.complexfloating]:
    """Smooth a signal using Hann window convolution.

    Args:
        sig: 1D signal to smooth.
        win_size: Window size for smoothing. Should be odd and positive.
        pad_val: Value to pad edges with.

    Returns:
        Smoothed signal.
    """
    n = len(sig)
    win_size = min(n // 10, 31) if win_size is None else win_size
    if win_size % 2 == 0:
        win_size += 1
    if win_size > 1:
        window = hann(win_size) / (win_size // 2)
        sig = np.pad(
            sig,
            (win_size, win_size),
            mode="constant",
            constant_values=pad_val,
        )
        sig = np.convolve(sig, window, mode="same")[win_size:-win_size]
    return sig
