"""Generate a complex signal.

Mostly used for testing out anything that needs an interesting signal.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from numpy.typing import NDArray


def generate_complex_signal(
    sample_rate: int = 1000,
    channels: int = 1,
    duration: float | None = None,
    noise_level: float = 0.05,
    seed: int | None = None,
) -> tuple[NDArray[np.floating], NDArray[np.complexfloating]]:
    """Generate a complex signal.

    This signal combines aspects between 10 and 400Hz:
    - Multiple pure tones at different frequencies
    - Frequency-modulated (chirp) components
    - Amplitude-modulated components
    - Phase modulation
    - Some noise for realism

    Args:
        sample_rate(int,optional): Sampling rate in Hz
        channels(int,optional): Returned as rows of the signal array
        duration(float,optional): Signal duration in seconds
        noise_level(float,optional): Noise level (0-1)
        seed(int,optional): Seed for random number generator

    Returns:
        t(np.ndarray): Time vector
        complex_signal(np.ndarray): Complex signal
    """
    if duration is None:
        duration = 10000 / sample_rate
    # Time vector
    t = np.linspace(0, duration, int(sample_rate * duration), endpoint=False)
    rng = np.random.default_rng(seed)

    signals: list[NDArray[np.complexfloating]] = [
        _gen_signal(t, rng, duration, sample_rate, noise_level) for _ in range(channels)
    ]
    complex_signal = np.vstack(signals)

    return t, complex_signal


def _gen_signal(
    t: NDArray[np.floating],
    rng: np.random.Generator,
    duration: float,
    sample_rate: int,
    noise_level: float,
) -> NDArray[np.complexfloating]:
    # Initialize signal
    complex_signal = np.zeros(len(t), dtype=complex)

    # Component 1: Pure tones at specific frequencies
    frequencies = 10 + 340 * rng.random(4)
    amplitudes = 0.3 + 0.7 * rng.random(4)

    for freq, amp in zip(frequencies, amplitudes, strict=False):
        complex_signal += amp * np.exp(1j * 2 * np.pi * freq * t)

    # Component 2: Frequency modulated (chirp) signal
    f_start, f_end = 50 + 50 * rng.random(), 250 + 100 * rng.random()
    chirp_rate = (f_end - f_start) / duration
    instantaneous_phase = 2 * np.pi * (f_start * t + 0.5 * chirp_rate * t**2)
    complex_signal += 0.6 * np.exp(1j * instantaneous_phase)

    # Component 3: Amplitude modulated signal
    carrier_freq = 200 + 100 * rng.random()
    mod_freq = 10 + 10 * rng.random()
    mod_depth = 0.2 + 0.8 * rng.random()
    envelope = 1 + mod_depth * np.cos(2 * np.pi * mod_freq * t)
    complex_signal += 0.4 * envelope * np.exp(1j * 2 * np.pi * carrier_freq * t)

    # Component 4: Phase modulated signal
    carrier_freq = 100 + 100 * rng.random()
    mod_freq = 20 + 10 * rng.random()
    mod_index = 1 + 2 * rng.random()  # Modulation index
    phase_mod = mod_index * np.sin(2 * np.pi * mod_freq * t)
    complex_signal += 0.5 * np.exp(1j * (2 * np.pi * carrier_freq * t + phase_mod))

    # Component 5: Decaying oscillation (damped sinusoid)
    decay_freq = 300 + 100 * rng.random()
    decay_rate = 2 + 4 * rng.random()
    decay_envelope = np.exp(-decay_rate * t)
    complex_signal += 0.8 * decay_envelope * np.exp(1j * 2 * np.pi * decay_freq * t)

    # Component 6: Burst/packet signal
    burst_freq = 100 + 100 * rng.random()
    burst_duration = (0.1 + 0.5 * rng.random()) * duration
    burst_start = (duration - burst_duration) * rng.random()
    burst_window = np.hamming(int(sample_rate * burst_duration))
    # burst_window = np.where(
    #     (t >= burst_start) & (t <= burst_start + burst_duration),
    #     np.hamming(int(sample_rate * burst_duration)),
    #     0,
    # )
    # Pad or trim burst_window to match t length
    if len(burst_window) != len(t):
        burst_window = np.zeros_like(t)
        start_idx = int(burst_start * sample_rate)
        end_idx = min(start_idx + int(burst_duration * sample_rate), len(t))
        window_len = end_idx - start_idx
        burst_window[start_idx:end_idx] = np.hamming(window_len)

    complex_signal += 0.7 * burst_window * np.exp(1j * 2 * np.pi * burst_freq * t)

    # Add some noise for realism using Generator
    noise_real = rng.normal(0, noise_level, len(t))
    noise_imag = rng.normal(0, noise_level, len(t))
    complex_signal += noise_real + 1j * noise_imag

    return complex_signal
