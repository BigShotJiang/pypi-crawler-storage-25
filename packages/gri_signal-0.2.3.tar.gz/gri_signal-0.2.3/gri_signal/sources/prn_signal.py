"""Generate a pseudorandom noise (PRN) signal."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from gri_signal.filters import bandpass_fft, lowpass_fft

if TYPE_CHECKING:
    from numpy.typing import NDArray


def prn(  # noqa: PLR0913
    fs: float,
    *,
    samples: int | None = None,
    duration: float | None = None,
    hz_low: float | None = None,
    hz_high: float | None = None,
    seed: int | None = None,
) -> NDArray[np.complexfloating]:
    """Generate a complex pseudorandom noise (PRN) signal.

    Creates complex white Gaussian noise, optionally bandlimited via FFT filtering.

    Args:
        fs: Sampling frequency in samples per second.
        samples: Signal length in samples. Provide either samples or duration.
        duration: Signal length in seconds. Provide either samples or duration.
        hz_low: Low cutoff frequency for bandpass filtering. If None and hz_high
            is provided, a lowpass filter is applied instead.
        hz_high: High cutoff frequency for bandpass or lowpass filtering.
            If None, no filtering is applied (white noise).
        seed: Random seed for reproducibility.

    Returns:
        Complex PRN signal of shape (samples,).

    Raises:
        ValueError: If neither samples nor duration is provided.

    Examples:
        >>> sig = prn(1000, duration=1.0)  # 1 second white noise
        >>> sig = prn(1000, samples=1000, hz_high=100)  # Lowpass filtered
        >>> sig = prn(1000, duration=1.0, hz_low=50, hz_high=150)  # Bandpass
        >>> sig = prn(1000, duration=1.0, seed=42)  # Reproducible
    """
    rng = np.random.default_rng(seed)

    if samples is None:
        if duration is None:
            raise ValueError("samples or duration required")
        samples = int(np.round(fs * duration))

    # Generate complex white Gaussian noise
    sig: NDArray[np.complexfloating] = rng.standard_normal(
        samples,
    ) + 1j * rng.standard_normal(samples)

    # Apply optional filtering
    if hz_high is not None:
        if hz_low is not None:
            return bandpass_fft(fs, hz_low, hz_high, sig)
        return lowpass_fft(fs, hz_high, sig)

    return sig
