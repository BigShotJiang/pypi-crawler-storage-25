"""Generate a pulsed signal with constant pulse repetition interval (PRI)."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from scipy.signal.windows import hann

if TYPE_CHECKING:
    from numpy.typing import NDArray


def pri(  # noqa: PLR0913
    fs: float,
    freq: float,
    pri_interval: float,
    pulse_width: float,
    *,
    start: float = 0,
    stop: float = -1,
    f_center: float = 0,
    phase_offset: float = 0,
    samples: int | None = None,
    duration: float | None = None,
) -> NDArray[np.complexfloating]:
    """Generate a pulsed signal with constant pulse repetition interval (PRI).

    Creates a pulsed waveform where each pulse is a complex tone at the specified
    frequency, with configurable repetition interval and pulse width.

    Args:
        fs: Sampling frequency in samples per second.
        freq: Center frequency of the pulse tone in Hz. If f_center is provided,
            the output will be at (freq - f_center).
        pri_interval: Pulse Repetition Interval in seconds (time between pulse starts).
        pulse_width: Width of each pulse in seconds. Must be less than pri_interval.
        start: Start time of the first pulse in seconds. Defaults to 0.
        stop: Stop time of the signal in seconds. Defaults to -1 (full length).
        f_center: Center frequency in Hz for baseband conversion. Defaults to 0.
        phase_offset: Phase offset applied to pulses in radians. Defaults to 0.
        samples: Signal length in samples. Provide either samples or duration.
        duration: Signal length in seconds. Provide either samples or duration.

    Returns:
        Complex pulsed signal of shape (samples,).

    Raises:
        ValueError: If neither samples nor duration is provided.
        ValueError: If pulse_width >= pri_interval (pulses would overlap).
        ValueError: If start > duration.

    Examples:
        >>> # 1ms PRI, 100us pulses, 10kHz tone
        >>> sig = pri(100e3, 10e3, pri_interval=1e-3, pulse_width=1e-4, duration=0.01)
        >>> # Radar-like signal with baseband conversion
        >>> sig = pri(1e6, 915e6, 1e-3, 1e-4, f_center=915e6, duration=0.1)
    """
    if samples is None:
        if duration is None:
            raise ValueError("samples or duration required")
        samples = int(np.round(fs * duration))
    if duration is None:
        duration = samples / fs

    if pulse_width >= pri_interval:
        raise ValueError(
            "pulse_width must be less than pri_interval to avoid overlapping pulses",
        )
    if start > duration:
        raise ValueError("No pulses: start is after sample duration ends")

    # Generate continuous tone across entire duration
    t = np.linspace(0, duration, samples)
    sig: NDArray[np.complexfloating] = np.exp(1j * 2 * np.pi * (freq - f_center) * t)

    # Apply phase offset to entire signal
    if phase_offset != 0:
        sig = sig * np.exp(1j * phase_offset)

    # Create zero mask (default to all zeros / no pulses)
    mask = np.zeros(samples, dtype=bool)

    # Set mask to True for each pulse window
    pulse_start_idx = int(np.round(start * fs))
    pulse_idx_length = int(np.round(pulse_width * fs))
    pri_idx_length = int(np.round(pri_interval * fs))

    while pulse_start_idx < samples:
        pulse_stop_idx = min(samples, pulse_start_idx + pulse_idx_length)
        mask[pulse_start_idx:pulse_stop_idx] = True
        pulse_start_idx += pri_idx_length

    # Zero out any samples past stop time
    if stop > duration:
        stop = -1
    stop_idx = int(np.round(stop * fs)) if stop > start else samples
    stop_idx = min(samples, stop_idx)
    if stop_idx < samples:
        sig[stop_idx:samples] = 0

    # Apply zero mask to suppress non-pulse regions
    sig[~mask] = 0

    # Apply Hann smoothing to avoid sharp transitions
    win_size = max(3, int(fs / freq / 2))
    return _hann_smooth(sig, win_size=win_size)


def _hann_smooth(
    sig: NDArray[np.complexfloating],
    *,
    win_size: int | None = None,
    pad_val: float = 0,
) -> NDArray[np.complexfloating]:
    """Smooth a signal using Hann window convolution.

    Args:
        sig: 1D signal to smooth.
        win_size: Window size for smoothing. Should be odd and positive.
        pad_val: Value to pad edges with.

    Returns:
        Smoothed signal.
    """
    n = len(sig)
    win_size = min(n // 10, 31) if win_size is None else win_size
    if win_size % 2 == 0:
        win_size += 1
    if win_size > 1:
        window = hann(win_size) / (win_size // 2)
        sig = np.pad(
            sig,
            (win_size, win_size),
            mode="constant",
            constant_values=pad_val,
        )
        sig = np.convolve(sig, window, mode="same")[win_size:-win_size]
    return sig
