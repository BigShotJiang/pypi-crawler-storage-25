"""Generate steering vectors for uniform linear arrays (ULA)."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from numpy.typing import NDArray


def ula_steering(
    aoa_deg: float,
    d: float,
    wavelength: float,
    n_elements: int = 2,
) -> NDArray[np.complexfloating]:
    """Generate steering vector for a uniform linear array (ULA).

    Computes the theoretical steering vector for a signal arriving at a
    given angle to a uniform linear array. This represents the relative
    phase shifts across antenna elements due to path length differences.

    Args:
        aoa_deg: Angle of arrival in degrees, measured from broadside
            (perpendicular to array axis). 0° = broadside, ±90° = endfire.
        d: Antenna element spacing in meters.
        wavelength: Signal wavelength in meters. For frequency f (Hz) and
            speed of light c, wavelength = c / f.
        n_elements: Number of antenna elements. Defaults to 2.

    Returns:
        Complex steering vector of shape (n_elements,).
        The first element is always the phase reference (phase = 0).

    Examples:
        >>> # Two-element array, half-wavelength spacing, signal from 30°
        >>> wavelength = 0.3  # 1 GHz signal
        >>> d = wavelength / 2  # Half-wavelength spacing
        >>> steering = ula_steering(30.0, d, wavelength, n_elements=2)

        >>> # Four-element array for 915 MHz
        >>> c = 3e8  # Speed of light
        >>> f = 915e6  # Frequency
        >>> wavelength = c / f
        >>> d = 0.5 * wavelength
        >>> steering = ula_steering(45.0, d, wavelength, n_elements=4)

        >>> # Create multi-channel received signal from a source at 30°
        >>> # array_signal = steering[:, np.newaxis] * source_signal

    Notes:
        The phase progression across elements is:
            phase[k] = 2π * k * d / λ * sin(θ)

        where k is the element index (0, 1, ..., n_elements-1), d is spacing,
        λ is wavelength, and θ is the angle of arrival.

        Common spacing choices:
        - d = λ/2: Half-wavelength spacing (avoids grating lobes for |θ| < 90°)
        - d = λ/4: Quarter-wavelength spacing (wider beam, no grating lobes)
    """
    element_indices = np.arange(n_elements)
    phase = 2 * np.pi * element_indices * d / wavelength * np.sin(np.radians(aoa_deg))
    return np.exp(1j * phase)
