"""Tests for cklib.execution — hash chains, attestation, verification."""
import os
import shutil
import tempfile

from cklib.execution import (
    hash_data,
    hash_step,
    build_execution_proof,
    verify_chain,
    seal_execution,
)


def test_hash_data_dict():
    h = hash_data({"key": "value"})
    assert len(h) == 64
    # Deterministic
    assert h == hash_data({"key": "value"})


def test_hash_data_sorted_keys():
    # Order shouldn't matter
    assert hash_data({"b": 2, "a": 1}) == hash_data({"a": 1, "b": 2})


def test_hash_step_chains():
    prev = hash_data({"query": "test"})

    step0 = hash_step(
        step_index=0,
        service_url="https://echo-alpha.ontosys.io/action/echo",
        input_data={"query": "test"},
        output_data={"result": "alpha"},
        previous_chain_hash=prev,
        status_code=200,
        latency_ms=50,
    )

    assert step0.input_hash == hash_data({"query": "test"})
    assert step0.output_hash == hash_data({"result": "alpha"})
    assert step0.chain_hash != prev  # chain moved forward
    assert len(step0.chain_hash) == 64

    step1 = hash_step(
        step_index=1,
        service_url="https://echo-beta.ontosys.io/action/echo",
        input_data={"result": "alpha"},
        output_data={"result": "beta"},
        previous_chain_hash=step0.chain_hash,
        status_code=200,
        latency_ms=60,
    )

    assert step1.chain_hash != step0.chain_hash


def test_build_and_verify_proof():
    prev = hash_data({"query": "hello"})

    step0 = hash_step(0, "https://a.com", {"query": "hello"}, {"out": "a"}, prev)
    step1 = hash_step(1, "https://b.com", {"out": "a"}, {"out": "b"}, step0.chain_hash)

    proof = build_execution_proof(
        exec_id="exec-test-001",
        route_id="route-test",
        kernel_urn="ckp://Kernel#Test:v1.0",
        network="base-sepolia",
        steps=[step0, step1],
    )

    assert proof.execution_hash == step1.chain_hash
    assert verify_chain(proof)


def test_tampered_chain_fails():
    prev = hash_data({"q": "x"})

    step0 = hash_step(0, "https://a.com", {"q": "x"}, {"r": "y"}, prev)
    step1 = hash_step(1, "https://b.com", {"r": "y"}, {"r": "z"}, step0.chain_hash)

    proof = build_execution_proof(
        exec_id="exec-tamper",
        route_id="route-tamper",
        kernel_urn="ckp://Kernel#Test:v1.0",
        network="base-sepolia",
        steps=[step0, step1],
    )

    # Tamper with step1's output hash
    proof.steps[1].output_hash = "0" * 64
    assert not verify_chain(proof)


def test_empty_proof_verifies():
    proof = build_execution_proof(
        exec_id="exec-empty",
        route_id="route-empty",
        kernel_urn="ckp://Kernel#Test:v1.0",
        network="base-sepolia",
        steps=[],
    )
    assert verify_chain(proof)


def test_seal_execution():
    tmp = tempfile.mkdtemp()
    ck_dir = os.path.join(tmp, "TestKernel")
    os.makedirs(os.path.join(ck_dir, "storage", "instances"), exist_ok=True)

    prev = hash_data({"input": "test"})
    step0 = hash_step(0, "https://a.com", {"input": "test"}, {"output": "done"}, prev)

    proof = build_execution_proof(
        exec_id="exec-seal-test",
        route_id="route-seal",
        kernel_urn="ckp://Kernel#Test:v1.0",
        network="base-sepolia",
        steps=[step0],
        settle_tx="0xabc123",
    )

    result = seal_execution(ck_dir, proof)

    assert result["instance_id"] == "exec-seal-test"
    assert result["proof_outcome"] == "PASS"
    assert len(result["data_hash"]) == 64
    assert os.path.isfile(os.path.join(result["instance_path"], "data.json"))
    assert os.path.isfile(os.path.join(result["instance_path"], "proof.json"))
    assert os.path.isfile(os.path.join(result["instance_path"], "ledger.json"))

    shutil.rmtree(tmp)
