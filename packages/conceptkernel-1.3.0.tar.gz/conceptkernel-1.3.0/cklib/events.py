"""Event system — @on decorator for action handlers, emit for typed events.

Usage:
    from cklib import on, emit

    class MyKernel(KernelProcessor):
        @on("task.create")
        def create_task(self, data):
            task = ...
            return emit("TaskCreated", task_id=task.id)
"""
from datetime import datetime, timezone


def on(action_name):
    """Decorator: register a method as handler for an action.

    Usage:
        @on("task.create")
        def create_task(self, data):
            ...
    """
    def decorator(func):
        func._on_action = action_name
        return func
    return decorator


def emit(event_type, **kwargs):
    """Create a typed event dict for emission.

    Returns a dict ready to be published to event.{kernel} topic.
    Future: validate against ontology.yaml type definitions.

    Usage:
        return emit("TaskCreated", task_id="T011", target_kernel="CK.Lib")
    """
    return {
        "status": "ok",
        "event_type": event_type,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        **kwargs,
    }
