"""EntityManager — shared in-memory entity store with code-based lookup.

Extracted from VoiceScreen (_sessions) and CS.Voting (_rooms) patterns.
Both use: dict store + reverse code index + status tracking + 4-char codes.

Usage:
    from cklib.entities import EntityManager

    rooms = EntityManager(prefix="room")
    room_id, room = rooms.create(owner="alice", name="Quick Vote")
    room_id, room = rooms.get_by_code("AB12")
    rooms.update_status(room_id, "closed")
"""
import time
import uuid
from datetime import datetime, timezone


def generate_code(length=4):
    """Generate a random uppercase hex code (4 chars by default)."""
    return uuid.uuid4().hex[:length].upper()


def generate_entity_id(prefix, code):
    """Generate a timestamped entity ID: {prefix}-{epoch}-{code}."""
    return f"{prefix}-{int(time.time())}-{code.lower()}"


class EntityManager:
    """In-memory entity store with code-based lookup.

    Entities are dicts with at least: code, status, created_at.
    Additional fields come from create() kwargs.
    """

    def __init__(self, prefix="entity"):
        self.prefix = prefix
        self._store = {}        # entity_id → entity dict
        self._by_code = {}      # CODE → entity_id

    def create(self, **fields):
        """Create a new entity. Returns (entity_id, entity_dict).

        Always generates: code, status='active', created_at.
        Extra fields are merged in.
        """
        code = generate_code()
        entity_id = generate_entity_id(self.prefix, code)
        entity = {
            "code": code,
            "status": "active",
            "created_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            **fields,
        }
        self._store[entity_id] = entity
        self._by_code[code] = entity_id
        return entity_id, entity

    def get(self, entity_id):
        """Get entity by ID. Returns entity dict or None."""
        return self._store.get(entity_id)

    def get_by_code(self, code):
        """Look up entity by code. Returns (entity_id, entity_dict) or (None, None)."""
        code = code.upper()
        entity_id = self._by_code.get(code)
        if entity_id and entity_id in self._store:
            return entity_id, self._store[entity_id]
        return None, None

    def resolve_or_404(self, code):
        """Look up entity by code, raise FastAPI 404 if not found."""
        from fastapi import HTTPException
        entity_id, entity = self.get_by_code(code)
        if not entity_id:
            raise HTTPException(404, f"No {self.prefix} for code {code}")
        return entity_id, entity

    def update_status(self, entity_id, status):
        """Update an entity's status field."""
        entity = self._store.get(entity_id)
        if entity:
            entity["status"] = status
        return entity

    def list_active(self):
        """Return list of (entity_id, entity) where status == 'active'."""
        return [
            (eid, e) for eid, e in self._store.items()
            if e.get("status") == "active"
        ]

    def list_all(self):
        """Return all (entity_id, entity) pairs."""
        return list(self._store.items())
