"""Concurrency control for kernel processing.

Extracted from LOCAL.ClaudeCode pattern — file-based capacity management
using instance manifests and PID liveness checks.

Usage:
    from cklib.capacity import check_capacity, acquire, release

    ok, message, active, maximum = check_capacity(ck_dir)
    if ok:
        if acquire(ck_dir):
            try:
                # ... do work ...
            finally:
                release(ck_dir)
"""
import json
import os
import signal
import time

import yaml


# ---------------------------------------------------------------------------
# 1. get_max_concurrent — read limit from conceptkernel.yaml
# ---------------------------------------------------------------------------

def get_max_concurrent(ck_dir):
    """Read qualities.max_concurrent_agents from conceptkernel.yaml.

    Returns the configured maximum, or 3 if the field is not declared.
    """
    yaml_path = os.path.join(ck_dir, "conceptkernel.yaml")
    try:
        with open(yaml_path) as f:
            identity = yaml.safe_load(f)
        value = (identity or {}).get("qualities", {}).get("max_concurrent_agents")
        if value is not None:
            return int(value)
    except (OSError, IOError, yaml.YAMLError, ValueError, TypeError):
        pass
    return 3


# ---------------------------------------------------------------------------
# 2. count_active — scan instance manifests + PID liveness
# ---------------------------------------------------------------------------

def _is_pid_alive(pid):
    """Check whether a process with the given PID is still running.

    Uses os.kill(pid, 0) which sends no signal but raises OSError when
    the process does not exist (or is not owned by this user on some OSes).
    """
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    except (ValueError, TypeError):
        return False
    return True


def _update_manifest_status(manifest_path, new_status):
    """Atomically update the status field in a manifest.json."""
    try:
        with open(manifest_path) as f:
            manifest = json.load(f)
        manifest["status"] = new_status
        # Write to temp then rename for atomicity
        tmp_path = manifest_path + ".tmp"
        with open(tmp_path, "w") as f:
            json.dump(manifest, f, indent=2)
        os.replace(tmp_path, manifest_path)
    except (OSError, IOError, json.JSONDecodeError):
        pass


def count_active(ck_dir):
    """Count running instances by scanning storage/instances/.

    For each instance directory containing a manifest.json with
    status "running", check PID liveness if the manifest has a pid field.
    If the process is dead, update the manifest status to "failed".

    Returns the number of genuinely active (running) instances.
    Gracefully returns 0 if the instances directory does not exist.
    """
    instances_dir = os.path.join(ck_dir, "storage", "instances")
    if not os.path.isdir(instances_dir):
        return 0

    active = 0
    try:
        entries = os.listdir(instances_dir)
    except OSError:
        return 0

    for entry in entries:
        manifest_path = os.path.join(instances_dir, entry, "manifest.json")
        if not os.path.isfile(manifest_path):
            continue

        try:
            with open(manifest_path) as f:
                manifest = json.load(f)
        except (OSError, IOError, json.JSONDecodeError):
            continue

        status = manifest.get("status")
        if status != "running":
            continue

        # PID liveness check
        pid = manifest.get("pid")
        if pid is not None:
            try:
                pid = int(pid)
            except (ValueError, TypeError):
                pid = None

        if pid is not None and not _is_pid_alive(pid):
            # Process is dead — mark as failed
            _update_manifest_status(manifest_path, "failed")
            continue

        active += 1

    return active


# ---------------------------------------------------------------------------
# 3. check_capacity — high-level capacity check
# ---------------------------------------------------------------------------

def check_capacity(ck_dir):
    """Check whether the kernel has capacity for another concurrent agent.

    Returns:
        tuple: (ok, message, active, max_concurrent)
            ok      — True if active < max_concurrent
            message — human-readable status string
            active  — current count of running instances
            max_concurrent — configured (or default) limit
    """
    max_concurrent = get_max_concurrent(ck_dir)
    active = count_active(ck_dir)
    ok = active < max_concurrent

    if ok:
        message = "capacity available: %d/%d slots in use" % (active, max_concurrent)
    else:
        message = "at capacity: %d/%d slots in use" % (active, max_concurrent)

    return (ok, message, active, max_concurrent)


# ---------------------------------------------------------------------------
# 4. acquire — file-based lock at storage/lock
# ---------------------------------------------------------------------------

def acquire(ck_dir):
    """Acquire an exclusive file-based lock at storage/lock.

    Writes the current PID to the lock file. If a lock file already exists
    and the PID within it belongs to a live process, returns False.
    If the lock file exists but the PID is dead, the stale lock is replaced.

    Returns True if the lock was acquired, False otherwise.
    """
    storage_dir = os.path.join(ck_dir, "storage")
    os.makedirs(storage_dir, exist_ok=True)
    lock_path = os.path.join(storage_dir, "lock")

    my_pid = os.getpid()

    # Check for existing lock
    if os.path.isfile(lock_path):
        try:
            with open(lock_path) as f:
                content = f.read().strip()
            existing_pid = int(content)
            if _is_pid_alive(existing_pid):
                # Lock held by a live process
                return False
            # Stale lock — fall through to replace it
        except (OSError, IOError, ValueError):
            # Corrupt or unreadable lock file — safe to replace
            pass

    # Write our PID using atomic temp+rename
    tmp_path = lock_path + ".%d.tmp" % my_pid
    try:
        with open(tmp_path, "w") as f:
            f.write(str(my_pid))
        os.replace(tmp_path, lock_path)
    except OSError:
        # Clean up temp if replace failed
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        return False

    # Verify we actually hold the lock (guard against race with another process)
    try:
        with open(lock_path) as f:
            written_pid = int(f.read().strip())
        if written_pid != my_pid:
            return False
    except (OSError, IOError, ValueError):
        return False

    return True


# ---------------------------------------------------------------------------
# 5. release — remove lock file
# ---------------------------------------------------------------------------

def release(ck_dir):
    """Release the file-based lock at storage/lock.

    Only removes the lock if it is held by the current process (matching PID).
    Returns True if the lock was released, False if it was not held by us.
    """
    lock_path = os.path.join(ck_dir, "storage", "lock")
    my_pid = os.getpid()

    if not os.path.isfile(lock_path):
        return False

    try:
        with open(lock_path) as f:
            content = f.read().strip()
        existing_pid = int(content)
    except (OSError, IOError, ValueError):
        # Can't read lock — remove it defensively
        try:
            os.unlink(lock_path)
        except OSError:
            pass
        return False

    if existing_pid != my_pid:
        return False

    try:
        os.unlink(lock_path)
    except OSError:
        return False

    return True
