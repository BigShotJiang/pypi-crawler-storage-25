"""
nats_kernel.py — shared NATS kernel loop for Concept Kernels.

Not a standalone CK — a library that any CK's processor.py imports to become
a NATS listener following the CK processing cycle:

    Receive → Validate → Process (primary tool) → Create Instance → Publish Result → Notify

Usage:
    from nats_kernel import NatsKernelLoop

    def handle_message(msg):
        return {"status": "ok", "echo": msg}

    loop = NatsKernelLoop(CK_DIR, handle_message)
    asyncio.run(loop.run())
"""
import asyncio
import json
import os
import time
import uuid

import yaml
import nats


class NatsKernelLoop:
    """NATS listener that implements the CK processing cycle."""

    # nats:// — native TCP (server processors in cluster)
    # wss://  — WebSocket (Python CLI from local machine, needs aiohttp)
    # Set NATS_URL env var to override
    DEFAULT_ENDPOINT = "nats://localhost:4222"

    def __init__(self, ck_dir, handler_fn):
        self.ck_dir = os.path.abspath(ck_dir)
        self.handler_fn = handler_fn
        self.instance_dir = os.path.join(self.ck_dir, "storage", "instances")

        # NATS endpoint: env var > .ckproject > default
        self.endpoint = os.environ.get("NATS_URL", self.DEFAULT_ENDPOINT)

        # Load identity from conceptkernel.yaml
        ck_yaml_path = os.path.join(self.ck_dir, "conceptkernel.yaml")
        with open(ck_yaml_path) as f:
            self.ck = yaml.safe_load(f)

        meta = self.ck["metadata"]
        spec = self.ck["spec"]
        nats_cfg = spec.get("nats", {})

        self.kernel_name = meta["name"]
        self.kernel_urn = meta["urn"]
        self.input_topic = nats_cfg.get("input_topic", f"input.{self.kernel_name}")
        self.result_topic = nats_cfg.get("result_topic", f"result.{self.kernel_name}")
        self.event_topic = nats_cfg.get("event_topic", f"event.{self.kernel_name}")

        self.nc = None

    async def run(self):
        """Connect to NATS and listen on input topic."""
        print(f"[nats]  connecting to {self.endpoint}...")
        self.nc = await nats.connect(self.endpoint)
        print(f"[nats]  connected as {self.kernel_urn}")
        print(f"[sub]   {self.input_topic}")
        print(f"[ready] Listening on {self.input_topic}...")
        print()

        sub = await self.nc.subscribe(self.input_topic)

        try:
            async for msg in sub.messages:
                await self._handle(msg)
        except asyncio.CancelledError:
            pass
        finally:
            await self.nc.drain()

    async def _handle(self, msg):
        """Process a single incoming message through the CK cycle."""
        ts = int(time.time())

        # Parse headers from NATS-level headers
        headers = {}
        if msg.headers:
            for key in ("Trace-Id", "Nats-Msg-Id", "X-Kernel-ID", "X-User-ID", "X-Anonymous"):
                val = msg.headers.get(key)
                if val:
                    headers[key] = val

        trace_id = headers.get("Trace-Id", f"tx-{uuid.uuid4().hex[:6]}")
        sender_kernel = headers.get("X-Kernel-ID", "unknown")
        user_id = headers.get("X-User-ID", "anonymous")

        # Parse body (pure data — no control attributes)
        try:
            body = json.loads(msg.data.decode()) if msg.data else {}
        except (json.JSONDecodeError, UnicodeDecodeError):
            body = {"raw": msg.data.decode("utf-8", errors="replace")}

        print(f"[rx]    {trace_id} {msg.subject} {json.dumps(body, separators=(',', ':'))}")

        # Process via primary tool (handler_fn)
        # Pass nc + trace_id for streaming. Supports both sync and async handlers.
        try:
            import inspect
            try:
                raw = self.handler_fn(body, nc=self.nc, trace_id=trace_id)
            except TypeError:
                raw = self.handler_fn(body)

            # If handler returned a coroutine, await it
            if inspect.isawaitable(raw):
                result = await raw
            else:
                result = raw
            status = "ok"
        except Exception as e:
            result = {"error": str(e)}
            status = "error"

        # Create instance record
        instance_id = f"i-{trace_id}-{ts}"
        instance_path = os.path.join(self.instance_dir, instance_id)
        os.makedirs(instance_path, exist_ok=True)

        record = {
            "instance_id": instance_id,
            "kernel_urn": self.kernel_urn,
            "trace_id": trace_id,
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(ts)),
            "input": {
                "subject": msg.subject,
                "headers": headers,
                "body": body,
            },
            "output": result,
            "status": status,
            "sender": sender_kernel,
            "user_id": user_id,
        }

        record_path = os.path.join(instance_path, "message.json")
        with open(record_path, "w") as f:
            json.dump(record, f, indent=2)

        # Publish result
        result_envelope = {
            "trace_id": trace_id,
            "kernel_urn": self.kernel_urn,
            "timestamp": record["timestamp"],
            "status": status,
            "data": result,
        }

        result_headers = {
            "Trace-Id": trace_id,
            "X-Kernel-ID": self.kernel_urn,
            "Nats-Msg-Id": str(uuid.uuid4()),
        }

        await self.nc.publish(
            self.result_topic,
            json.dumps(result_envelope).encode(),
            headers=result_headers,
        )
        print(f"[tx]    {trace_id} {self.result_topic}")

        # Publish event notification
        event = {
            "type": "instance_created",
            "instance_id": instance_id,
            "trace_id": trace_id,
            "kernel_urn": self.kernel_urn,
            "timestamp": record["timestamp"],
        }

        await self.nc.publish(
            self.event_topic,
            json.dumps(event).encode(),
            headers={"Trace-Id": trace_id, "X-Kernel-ID": self.kernel_urn},
        )
