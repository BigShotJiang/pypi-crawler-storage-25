"""Instance management — create, seal, ledger, proof.

Platform operations — the LLM never calls these directly.

Usage:
    from cklib.instance import create_instance, seal_instance, append_ledger

    instance = create_instance(ck_dir, instance_type="task", metadata={...})
    append_ledger(instance.path, "pending", "in_progress", "Task started")
    seal_instance(instance.path, output={...})
"""
import hashlib
import json
import os
import time
from datetime import datetime, timezone


def create_instance(ck_dir, instance_type="task", instance_id=None, metadata=None):
    """Create an instance directory in storage/instances/.

    Returns dict with instance_id and path.
    """
    ts = int(time.time())
    if instance_id is None:
        instance_id = "i-%s-%d" % (instance_type, ts)

    instances_dir = os.path.join(ck_dir, "storage", "instances")
    os.makedirs(instances_dir, exist_ok=True)

    instance_dir = os.path.join(instances_dir, instance_id)
    os.makedirs(instance_dir, exist_ok=True)
    os.makedirs(os.path.join(instance_dir, "conversation"), exist_ok=True)
    os.makedirs(os.path.join(instance_dir, "proof"), exist_ok=True)

    # Write manifest with PROV-O fields (v3.4)
    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    ts_ms = int(time.time() * 1000)

    # Derive kernel name from ck_dir for PROV-O attribution
    ck_yaml = os.path.join(ck_dir, "conceptkernel.yaml")
    kernel_urn = ""
    if os.path.isfile(ck_yaml):
        try:
            import yaml
            with open(ck_yaml) as f:
                ck_data = yaml.safe_load(f)
            kernel_urn = ck_data.get("metadata", {}).get("urn", "")
        except Exception:
            pass

    action_urn = "ckp://Action#%s/%s-%d" % (
        os.path.basename(ck_dir), instance_type, ts_ms)

    manifest = {
        "instance_id": instance_id,
        "instance_type": instance_type,
        "created_at": now,
        "status": "pending",
        # PROV-O (v3.4 §7.1.2)
        "prov:wasGeneratedBy": action_urn,
        "prov:wasAttributedTo": kernel_urn,
        "prov:generatedAtTime": now,
    }
    if metadata:
        manifest.update(metadata)

    _write_json(os.path.join(instance_dir, "manifest.json"), manifest)

    # Init ledger
    _write_json(os.path.join(instance_dir, "ledger.json"), {
        "transitions": [],
        "current_status": "pending",
    })

    return {"instance_id": instance_id, "path": instance_dir, "manifest": manifest}


def seal_instance(instance_dir, output=None):
    """Seal an instance — write data.json (write-once).

    After sealing, the instance is immutable.
    """
    data_path = os.path.join(instance_dir, "data.json")
    if os.path.exists(data_path):
        return {"status": "error", "message": "instance already sealed"}

    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    data = {
        "sealed_at": now,
        "output": output or {},
    }

    _write_json(data_path, data)

    # Update manifest
    manifest_path = os.path.join(instance_dir, "manifest.json")
    if os.path.exists(manifest_path):
        with open(manifest_path) as f:
            manifest = json.load(f)
        manifest["status"] = "completed"
        manifest["sealed_at"] = now
        _write_json(manifest_path, manifest)

    # Generate proof hash (legacy — kept for backwards compatibility)
    content = json.dumps(data, sort_keys=True)
    proof_hash = hashlib.sha256(content.encode()).hexdigest()
    _write_json(os.path.join(instance_dir, "proof", "proof-%s.json" % now[:10]), {
        "hash": proof_hash,
        "algorithm": "sha256",
        "sealed_at": now,
        "data_size": len(content),
    })

    # --- Full proof.json at instance root (v3.4 §7.1.2) ---

    # Compute file-level hashes
    data_hash = _compute_file_hash(data_path)

    manifest_hash = ""
    manifest_exists = os.path.exists(manifest_path)
    if manifest_exists:
        manifest_hash = _compute_file_hash(manifest_path)

    # Resolve kernel URN from conceptkernel.yaml (walk up to ck_dir)
    kernel_urn = ""
    # instance_dir is <ck_dir>/storage/instances/<instance_id>
    ck_dir_candidate = os.path.normpath(
        os.path.join(instance_dir, os.pardir, os.pardir, os.pardir))
    ck_yaml = os.path.join(ck_dir_candidate, "conceptkernel.yaml")
    if os.path.isfile(ck_yaml):
        try:
            import yaml
            with open(ck_yaml) as f:
                ck_data = yaml.safe_load(f)
            kernel_urn = ck_data.get("metadata", {}).get("urn", "")
        except Exception:
            pass

    # Extract instance_id from directory name
    instance_id = os.path.basename(instance_dir)
    ts_suffix = int(time.time())

    # Build validation checks
    checks = [
        {
            "check_name": "data_sealed",
            "check_type": "INTEGRITY",
            "expected": "data.json written",
            "actual": "data.json written",
            "passed": True,
        },
        {
            "check_name": "manifest_present",
            "check_type": "STRUCTURE",
            "expected": "manifest.json exists",
            "actual": "manifest.json exists" if manifest_exists else "manifest.json missing",
            "passed": manifest_exists,
        },
        {
            "check_name": "data_hash",
            "check_type": "INTEGRITY",
            "expected": "SHA-256 computed",
            "actual": data_hash,
            "passed": True,
        },
    ]

    outcome = "PASS" if all(c["passed"] for c in checks) else "FAIL"

    proof_doc = {
        "proof_id": "proof-%s-%d" % (instance_id, ts_suffix),
        "instance_id": instance_id,
        "data_hash": data_hash,
        "manifest_hash": manifest_hash,
        "checked_at": now,
        "checked_by_kernel": kernel_urn,
        "svid": "unavailable",
        "checks": checks,
        "outcome": outcome,
    }

    _write_json(os.path.join(instance_dir, "proof.json"), proof_doc)

    return {
        "status": "ok",
        "sealed_at": now,
        "proof_hash": proof_hash,
        "data_hash": data_hash,
        "manifest_hash": manifest_hash,
        "proof_outcome": outcome,
    }


def append_ledger(instance_dir, from_status, to_status, note=""):
    """Append a state transition to the ledger."""
    ledger_path = os.path.join(instance_dir, "ledger.json")

    if os.path.exists(ledger_path):
        with open(ledger_path) as f:
            ledger = json.load(f)
    else:
        ledger = {"transitions": [], "current_status": from_status}

    ledger["transitions"].append({
        "from": from_status,
        "to": to_status,
        "note": note,
        "timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
    })
    ledger["current_status"] = to_status

    _write_json(ledger_path, ledger)
    return ledger


def append_conversation(instance_dir, entry_type, data):
    """Append to conversation record (platform operation)."""
    entry = {
        "type": entry_type,
        "timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "data": data,
    }
    conv_path = os.path.join(instance_dir, "conversation", "session.jsonl")
    with open(conv_path, "a") as f:
        f.write(json.dumps(entry) + "\n")
    return entry


def _compute_file_hash(filepath):
    """Return SHA-256 hex digest of a file's contents."""
    h = hashlib.sha256()
    with open(filepath, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def _write_json(path, data):
    with open(path, "w") as f:
        json.dump(data, f, indent=2)
