"""Schema integration — load ontology.yaml, validate instances.

Parses LinkML-format YAML directly (no linkml-runtime dependency).
Provides validation of instance data against class definitions.

Usage:
    from cklib.schema import load_schema, validate_instance, has_schema

    if has_schema(ck_dir):
        schema = load_schema(ck_dir)
        class_name = get_instance_class(schema)
        errors = validate_instance(schema, class_name, instance_data)
        # → [] if valid, [{"field": "...", "error": "..."}] if not
"""
import os

import yaml


# Range types we know how to validate (LinkML built-in types).
_RANGE_VALIDATORS = {
    "string": lambda v: isinstance(v, str),
    "integer": lambda v: isinstance(v, int) and not isinstance(v, bool),
    "float": lambda v: isinstance(v, (int, float)) and not isinstance(v, bool),
    "double": lambda v: isinstance(v, (int, float)) and not isinstance(v, bool),
    "boolean": lambda v: isinstance(v, bool),
    "date": lambda v: isinstance(v, str) and _is_date(v),
    "datetime": lambda v: isinstance(v, str) and _is_datetime(v),
    "uri": lambda v: isinstance(v, str),
    "uriorcurie": lambda v: isinstance(v, str),
}


def _is_date(value):
    """Check if string looks like a date (YYYY-MM-DD)."""
    try:
        parts = value.split("-")
        if len(parts) != 3:
            return False
        int(parts[0])
        int(parts[1])
        int(parts[2])
        return True
    except (ValueError, AttributeError):
        return False


def _is_datetime(value):
    """Check if string looks like an ISO datetime."""
    # Accept anything with a 'T' separating date and time, or ending in 'Z'.
    if not isinstance(value, str):
        return False
    if "T" in value or value.endswith("Z"):
        return True
    # Also accept plain date strings as datetime.
    return _is_date(value)


def has_schema(ck_dir):
    """Return True if ontology.yaml exists and has non-empty classes.

    Args:
        ck_dir: Path to the Concept Kernel directory.

    Returns:
        True if a usable schema is present, False otherwise.
    """
    ontology_path = os.path.join(ck_dir, "ontology.yaml")
    if not os.path.isfile(ontology_path):
        return False

    try:
        with open(ontology_path) as f:
            data = yaml.safe_load(f)
    except Exception:
        return False

    if not isinstance(data, dict):
        return False

    classes = data.get("classes")
    if not classes or not isinstance(classes, dict):
        return False

    return True


def load_schema(ck_dir):
    """Load ontology.yaml and return parsed schema dict.

    The returned dict has the structure::

        {
            "id": "https://example.org/ontology/v1",
            "name": "MyKernel",
            "prefixes": {...},
            "classes": {
                "MyOutput": {
                    "is_a": "ckp:SealedInstance",
                    "description": "...",
                    "attributes": {
                        "field_name": {"range": "string", "required": True},
                        ...
                    },
                },
                ...
            },
            "enums": {
                "MyEnum": {
                    "permissible_values": ["ValueA", "ValueB"],
                },
                ...
            },
            "instance_mutability": "sealed",
        }

    Args:
        ck_dir: Path to the Concept Kernel directory.

    Returns:
        Parsed schema dict, or empty dict if ontology.yaml is missing/invalid.
    """
    ontology_path = os.path.join(ck_dir, "ontology.yaml")
    if not os.path.isfile(ontology_path):
        return {}

    try:
        with open(ontology_path) as f:
            raw = yaml.safe_load(f)
    except Exception:
        return {}

    if not isinstance(raw, dict):
        return {}

    schema = {
        "id": raw.get("id", ""),
        "name": raw.get("name", ""),
        "prefixes": raw.get("prefixes") or {},
        "classes": {},
        "enums": {},
        "instance_mutability": raw.get("instance_mutability", ""),
    }

    # Parse classes
    raw_classes = raw.get("classes")
    if isinstance(raw_classes, dict):
        for cls_name, cls_def in raw_classes.items():
            if not isinstance(cls_def, dict):
                cls_def = {}
            parsed_cls = {
                "is_a": cls_def.get("is_a", ""),
                "description": cls_def.get("description", ""),
                "attributes": {},
            }
            raw_attrs = cls_def.get("attributes")
            if isinstance(raw_attrs, dict):
                for attr_name, attr_def in raw_attrs.items():
                    if not isinstance(attr_def, dict):
                        attr_def = {}
                    parsed_cls["attributes"][attr_name] = {
                        "range": attr_def.get("range", "string"),
                        "required": bool(attr_def.get("required", False)),
                        "description": attr_def.get("description", ""),
                        "multivalued": bool(attr_def.get("multivalued", False)),
                    }
            schema["classes"][cls_name] = parsed_cls

    # Parse enums
    raw_enums = raw.get("enums")
    if isinstance(raw_enums, dict):
        for enum_name, enum_def in raw_enums.items():
            if not isinstance(enum_def, dict):
                enum_def = {}
            pv = enum_def.get("permissible_values")
            if isinstance(pv, dict):
                values = list(pv.keys())
            elif isinstance(pv, list):
                values = list(pv)
            else:
                values = []
            schema["enums"][enum_name] = {
                "permissible_values": values,
            }

    return schema


def get_instance_class(schema):
    """Return the primary output class name from the schema.

    Heuristic: the first class with ``is_a: ckp:SealedInstance``.
    Falls back to the first class in the schema.

    Args:
        schema: Schema dict as returned by :func:`load_schema`.

    Returns:
        Class name string, or empty string if no classes defined.
    """
    classes = schema.get("classes", {})
    if not classes:
        return ""

    # Prefer class that inherits from ckp:SealedInstance.
    for cls_name, cls_def in classes.items():
        is_a = cls_def.get("is_a", "")
        if is_a == "ckp:SealedInstance":
            return cls_name

    # Fallback: first class.
    return next(iter(classes))


def validate_instance(schema, class_name, data):
    """Validate a data dict against a class definition from the schema.

    Checks:
    - Required fields are present and non-None.
    - Range types match (string, integer, float, boolean, datetime, date).
    - Enum values are among permissible_values if the range names an enum.
    - Multivalued fields must be lists.

    Args:
        schema: Schema dict as returned by :func:`load_schema`.
        class_name: Name of the class to validate against.
        data: Dict of field values to validate.

    Returns:
        List of error dicts. Each has ``"field"`` and ``"error"`` keys.
        Empty list means valid.
    """
    errors = []

    classes = schema.get("classes", {})
    if class_name not in classes:
        errors.append({
            "field": "_class",
            "error": "unknown class: %s" % class_name,
        })
        return errors

    cls_def = classes[class_name]
    attributes = cls_def.get("attributes", {})
    enums = schema.get("enums", {})

    if not isinstance(data, dict):
        errors.append({
            "field": "_data",
            "error": "data must be a dict, got %s" % type(data).__name__,
        })
        return errors

    # Check required fields.
    for attr_name, attr_def in attributes.items():
        if attr_def.get("required"):
            if attr_name not in data or data[attr_name] is None:
                errors.append({
                    "field": attr_name,
                    "error": "required field missing",
                })

    # Check each provided field.
    for attr_name, attr_def in attributes.items():
        if attr_name not in data or data[attr_name] is None:
            continue

        value = data[attr_name]
        is_multivalued = attr_def.get("multivalued", False)
        range_type = attr_def.get("range", "string")

        # Multivalued: value must be a list, validate each element.
        if is_multivalued:
            if not isinstance(value, list):
                errors.append({
                    "field": attr_name,
                    "error": "expected list for multivalued field, got %s" % type(value).__name__,
                })
                continue
            values_to_check = value
        else:
            values_to_check = [value]

        # Determine if range refers to an enum.
        if range_type in enums:
            permitted = enums[range_type].get("permissible_values", [])
            for v in values_to_check:
                if v not in permitted:
                    errors.append({
                        "field": attr_name,
                        "error": "value %r not in enum %s (permitted: %s)" % (
                            v, range_type, ", ".join(str(p) for p in permitted)),
                    })
        elif range_type in _RANGE_VALIDATORS:
            validator = _RANGE_VALIDATORS[range_type]
            for v in values_to_check:
                if not validator(v):
                    errors.append({
                        "field": attr_name,
                        "error": "expected %s, got %s" % (range_type, type(v).__name__),
                    })
        # If range_type is not a known type or enum, skip validation
        # (it might be a class reference or a custom type).

    return errors
