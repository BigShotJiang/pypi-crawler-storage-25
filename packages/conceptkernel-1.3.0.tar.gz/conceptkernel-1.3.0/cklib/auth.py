"""Shared auth — JWKS + X-Token for CK HTTP endpoints.

Loads Keycloak JWKS once at startup. Supports dual auth:
- X-Token header or ?token= query param (for API clients like Claude voice)
- Authorization: Bearer <jwt> (for browser/Keycloak-authenticated users)

Usage:
    from cklib.auth import CKAuth

    auth = CKAuth(api_token="my-secret")
    await auth.load_jwks()
    claims = auth.authenticate(request)
"""
import os

import httpx
import jwt as pyjwt

KEYCLOAK_BASE = "https://id.tech.games"
KEYCLOAK_REALM = "techgames"
JWKS_URL = f"{KEYCLOAK_BASE}/realms/{KEYCLOAK_REALM}/protocol/openid-connect/certs"


class CKAuth:
    """Dual auth: static API token + Keycloak JWT."""

    def __init__(self, api_token=None):
        self.api_token = api_token or os.environ.get("CK_API_TOKEN")
        self._jwks_keys = None

    async def load_jwks(self):
        """Fetch JWKS from Keycloak once at startup."""
        try:
            async with httpx.AsyncClient(verify=True, timeout=15) as client:
                resp = await client.get(JWKS_URL)
                resp.raise_for_status()
                data = resp.json()
            self._jwks_keys = {k["kid"]: k for k in data.get("keys", [])}
            return len(self._jwks_keys)
        except Exception as e:
            print(f"[auth]  JWKS load failed: {e}")
            self._jwks_keys = {}
            return 0

    @property
    def jwks_loaded(self):
        return self._jwks_keys is not None and len(self._jwks_keys) > 0

    def authenticate(self, request) -> dict:
        """Authenticate request. Returns claims dict or raises HTTPException."""
        from fastapi import HTTPException

        # Check X-Token first (API client path)
        x_token = (request.headers.get("X-Token")
                   or request.query_params.get("token"))
        if x_token:
            if not self.api_token:
                raise HTTPException(401, "API token not configured")
            if x_token != self.api_token:
                raise HTTPException(401, "Invalid API token")
            return {"preferred_username": "api-client", "sub": "api-client"}

        # Fall back to JWT
        auth_header = request.headers.get("Authorization", "")
        if not auth_header.startswith("Bearer "):
            raise HTTPException(401, "Missing X-Token or Bearer token")

        token = auth_header[7:]
        return self._verify_jwt(token)

    def _verify_jwt(self, token: str) -> dict:
        from fastapi import HTTPException

        if not self._jwks_keys:
            raise HTTPException(401, "JWKS not loaded")

        try:
            header = pyjwt.get_unverified_header(token)
        except pyjwt.DecodeError:
            raise HTTPException(401, "Invalid token")

        kid = header.get("kid")
        if kid not in self._jwks_keys:
            raise HTTPException(401, "Unknown key ID")

        jwk_data = self._jwks_keys[kid]
        alg = header.get("alg", jwk_data.get("alg", "RS256"))
        public_key = pyjwt.algorithms.RSAAlgorithm.from_jwk(jwk_data)

        try:
            return pyjwt.decode(
                token, public_key, algorithms=[alg],
                options={"verify_aud": False},
            )
        except pyjwt.ExpiredSignatureError:
            raise HTTPException(401, "Token expired")
        except pyjwt.InvalidTokenError as e:
            raise HTTPException(401, f"Invalid token: {e}")
