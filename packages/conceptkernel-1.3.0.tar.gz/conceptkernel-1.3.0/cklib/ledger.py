"""Kernel-wide action ledger — append-only JSONL action log.

Extracted from LOCAL.ClaudeCode's ``log_action()`` pattern
(ref-tg-cli/concepts/LOCAL.ClaudeCode/tool/processor.py lines 79-134).

Each kernel invocation writes one JSONL entry to a daily file under
``storage/ledger/actions-{YYYY-MM-DD}.jsonl``.  Files are never rewritten —
entries are always appended.

Usage:
    from cklib.ledger import log_action, read_ledger

    log_action(
        ck_dir="concepts/MyKernel",
        action_name="task.create",
        status="completed",
        task_id="T001",
        goal_id="G001",
        detail={"items": 3},
    )

    entries = read_ledger("concepts/MyKernel", limit=20)
"""

import json
import os
import threading
import time as _time
from datetime import datetime, timezone
from glob import glob

import yaml

__all__ = ["log_action", "read_ledger"]

# ---------------------------------------------------------------------------
# Internal: resolve kernel identity from conceptkernel.yaml
# ---------------------------------------------------------------------------

# File-level lock — one per process, protects the open-write-flush sequence.
_write_lock = threading.Lock()


def _resolve_kernel(ck_dir: str) -> tuple[str, str, str]:
    """Return (kernel_name, kernel_urn, kernel_version) from conceptkernel.yaml.

    Falls back to the directory basename if the YAML is absent or malformed.
    """
    ck_yaml = os.path.join(ck_dir, "conceptkernel.yaml")
    if os.path.isfile(ck_yaml):
        try:
            with open(ck_yaml) as f:
                data = yaml.safe_load(f)
            meta = data.get("metadata", {})
            name = meta.get("name", os.path.basename(os.path.abspath(ck_dir)))
            urn = meta.get("urn", "")
            version = meta.get("version", "v1.0")
            if not urn:
                urn = "ckp://Kernel#%s:%s" % (name, version)
            return name, urn, version
        except Exception:
            pass

    # Fallback
    name = os.path.basename(os.path.abspath(ck_dir))
    return name, "ckp://Kernel#%s:v1.0" % name, "v1.0"


# ---------------------------------------------------------------------------
# log_action — append one JSONL entry
# ---------------------------------------------------------------------------

def log_action(
    ck_dir: str,
    action_name: str,
    *,
    status: str = "started",
    target_kernel: str = "",
    task_id: str = "",
    goal_id: str = "",
    instance_id: str = "",
    persona: str = "",
    detail: dict | None = None,
) -> dict:
    """Append one action entry to the daily ledger file.

    Args:
        ck_dir:         Root directory of the Concept Kernel.
        action_name:    Dotted action name (e.g. ``task.create``).
        status:         One of ``started``, ``completed``, ``failed``,
                        ``timeout``, ``error``.
        target_kernel:  Optional target kernel name for cross-kernel actions.
        task_id:        Optional task identifier (``T001``).
        goal_id:        Optional goal identifier (``G001``).
        instance_id:    Optional instance identifier.
        persona:        Optional persona label.
        detail:         Optional dict of extra payload.

    Returns:
        The entry dict that was written.
    """
    kernel_name, kernel_urn, _version = _resolve_kernel(ck_dir)

    now = datetime.now(timezone.utc)
    ts_iso = now.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
    ts_ms = int(now.timestamp() * 1000)
    date_str = now.strftime("%Y-%m-%d")

    # Build Action URN: ckp://Action#{KernelName}/{action}-{ts_ms}
    action_urn = "ckp://Action#%s/%s-%d" % (kernel_name, action_name, ts_ms)

    entry: dict = {
        "action_urn": action_urn,
        "action": action_name,
        "target_kernel": target_kernel,
        "task_id": task_id,
        "goal_id": goal_id,
        "instance_id": instance_id,
        "persona": persona,
        "status": status,
        "timestamp": ts_iso,
        "timestamp_ms": ts_ms,
        "prov:wasAssociatedWith": kernel_urn,
    }

    # Conditional PROV-O fields
    if task_id:
        entry["prov:wasStartedBy"] = "ckp://Task#%s" % task_id
    if goal_id:
        entry["prov:wasInfluencedBy"] = "ckp://Goal#%s" % goal_id

    # Optional detail payload
    if detail is not None:
        entry["detail"] = detail

    # Ensure ledger directory exists
    ledger_dir = os.path.join(ck_dir, "storage", "ledger")
    os.makedirs(ledger_dir, exist_ok=True)

    ledger_file = os.path.join(ledger_dir, "actions-%s.jsonl" % date_str)
    line = json.dumps(entry, separators=(",", ":")) + "\n"

    # Thread-safe append — hold lock across open+write+flush
    with _write_lock:
        with open(ledger_file, "a") as f:
            f.write(line)
            f.flush()
            os.fsync(f.fileno())

    return entry


# ---------------------------------------------------------------------------
# read_ledger — read recent entries across daily files
# ---------------------------------------------------------------------------

def read_ledger(ck_dir: str, limit: int = 50) -> list[dict]:
    """Read recent ledger entries in reverse chronological order.

    Scans daily ``actions-*.jsonl`` files in ``storage/ledger/``, starting
    from the most recent file and working backwards.  Stops once *limit*
    entries have been collected.

    Args:
        ck_dir: Root directory of the Concept Kernel.
        limit:  Maximum number of entries to return.  Pass ``0`` for
                unlimited (reads every file).

    Returns:
        List of entry dicts, newest first.
    """
    ledger_dir = os.path.join(ck_dir, "storage", "ledger")
    if not os.path.isdir(ledger_dir):
        return []

    # Collect daily files and sort descending by filename (date)
    pattern = os.path.join(ledger_dir, "actions-*.jsonl")
    files = sorted(glob(pattern), reverse=True)

    entries: list[dict] = []
    for fpath in files:
        if limit > 0 and len(entries) >= limit:
            break

        file_entries = _read_jsonl_file(fpath)
        # Reverse so newest entries in this file come first
        file_entries.reverse()

        if limit > 0:
            remaining = limit - len(entries)
            entries.extend(file_entries[:remaining])
        else:
            entries.extend(file_entries)

    return entries


def _read_jsonl_file(path: str) -> list[dict]:
    """Read all valid JSON lines from a file.

    Silently skips blank or malformed lines.
    """
    entries = []
    try:
        with open(path) as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    entries.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
    except OSError:
        pass
    return entries
