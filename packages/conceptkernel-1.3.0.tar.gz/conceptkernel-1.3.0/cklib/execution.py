"""Execution proofs — hash chains, per-step attestation, sealed instances.

Records cryptographic proof that a multi-step execution happened as claimed.
Each step's input and output are SHA-256 hashed and chained to the previous
step, so tampering with any step breaks the chain from that point forward.

Usage:
    from cklib.execution import hash_step, build_execution_proof, seal_execution, verify_chain

    steps = []
    prev = hash_data(request_body)

    for i, service in enumerate(route_steps):
        attestation = hash_step(
            step_index=i,
            service_url=service["url"],
            input_data=current_input,
            output_data=service_response,
            previous_chain_hash=prev,
            status_code=200,
            latency_ms=245,
        )
        steps.append(attestation)
        prev = attestation.chain_hash

    proof = build_execution_proof(
        exec_id="exec-route-abc-123",
        route_id="route-abc",
        kernel_urn="ckp://Kernel#OntoSys.Discovery:v1.0",
        network="base-sepolia",
        steps=steps,
        settle_tx="0xabc...",
        payment_split={"total": 0.001},
    )

    sealed = seal_execution("concepts/OntoSys.Discovery", proof)
    assert verify_chain(proof)
"""

import hashlib
import json
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone


__all__ = [
    "StepAttestation",
    "ExecutionProof",
    "hash_data",
    "hash_step",
    "build_execution_proof",
    "seal_execution",
    "verify_chain",
]


@dataclass
class StepAttestation:
    """Cryptographic attestation of one step in a route execution."""
    step_index: int
    service_url: str
    input_hash: str
    output_hash: str
    chain_hash: str
    status_code: int
    latency_ms: int
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


@dataclass
class ExecutionProof:
    """Complete proof of a multi-step route execution."""
    exec_id: str
    route_id: str
    kernel_urn: str
    network: str
    steps: list
    execution_hash: str
    settle_tx: str = ""
    payment_split: dict = field(default_factory=dict)
    started_at: str = ""
    ended_at: str = ""


def hash_data(data) -> str:
    """SHA-256 hex digest of JSON-serialized data.

    Accepts dict, str, or bytes. Dicts are serialized with sorted keys
    for deterministic hashing.
    """
    if isinstance(data, dict):
        content = json.dumps(data, sort_keys=True, separators=(",", ":"))
    elif isinstance(data, str):
        content = data
    elif isinstance(data, bytes):
        return hashlib.sha256(data).hexdigest()
    else:
        content = json.dumps(data, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(content.encode("utf-8")).hexdigest()


def hash_step(
    step_index: int,
    service_url: str,
    input_data,
    output_data,
    previous_chain_hash: str,
    status_code: int = 200,
    latency_ms: int = 0,
) -> StepAttestation:
    """Hash one step's input/output and chain to the previous step.

    Chain algorithm:
        input_hash  = SHA-256(input_data)
        output_hash = SHA-256(output_data)
        chain_hash  = SHA-256(previous_chain_hash + input_hash + output_hash)

    For step 0, previous_chain_hash should be the hash of the original request body.
    """
    input_hash = hash_data(input_data)
    output_hash = hash_data(output_data)
    chain_input = previous_chain_hash + input_hash + output_hash
    chain_hash = hashlib.sha256(chain_input.encode("utf-8")).hexdigest()

    return StepAttestation(
        step_index=step_index,
        service_url=service_url,
        input_hash=input_hash,
        output_hash=output_hash,
        chain_hash=chain_hash,
        status_code=status_code,
        latency_ms=latency_ms,
    )


def build_execution_proof(
    exec_id: str,
    route_id: str,
    kernel_urn: str,
    network: str,
    steps: list,
    settle_tx: str = "",
    payment_split: dict = None,
    started_at: str = "",
    ended_at: str = "",
) -> ExecutionProof:
    """Assemble step attestations into a complete execution proof.

    The execution_hash is the chain_hash of the final step.
    """
    execution_hash = steps[-1].chain_hash if steps else ""

    return ExecutionProof(
        exec_id=exec_id,
        route_id=route_id,
        kernel_urn=kernel_urn,
        network=network,
        steps=steps,
        execution_hash=execution_hash,
        settle_tx=settle_tx,
        payment_split=payment_split or {},
        started_at=started_at or datetime.now(timezone.utc).isoformat(),
        ended_at=ended_at or datetime.now(timezone.utc).isoformat(),
    )


def verify_chain(proof: ExecutionProof) -> bool:
    """Walk the hash chain and confirm each step links to the previous.

    Returns True if the chain is intact, False if any link is broken.
    Does not re-hash the original data (we only have the hashes),
    but verifies that each chain_hash = SHA-256(prev + input + output).
    """
    if not proof.steps:
        return True

    for i, step in enumerate(proof.steps):
        if i == 0:
            # Can't verify the first step's chain_hash without the original
            # request body hash. We trust it as the chain anchor.
            prev = step.chain_hash
            continue

        prev_step = proof.steps[i - 1]
        expected_input = prev_step.chain_hash + step.input_hash + step.output_hash
        expected_chain = hashlib.sha256(expected_input.encode("utf-8")).hexdigest()

        if step.chain_hash != expected_chain:
            return False

        prev = step.chain_hash

    # Verify execution_hash matches final step
    if proof.execution_hash != proof.steps[-1].chain_hash:
        return False

    return True


def seal_execution(ck_dir: str, proof: ExecutionProof) -> dict:
    """Create a sealed instance for this execution.

    Calls create_instance() + seal_instance() from cklib.instance.
    Returns {instance_id, data_hash, manifest_hash, proof_outcome}.
    """
    from cklib.instance import create_instance, seal_instance, append_ledger

    # Serialize steps for storage
    steps_data = []
    for s in proof.steps:
        steps_data.append(asdict(s))

    instance = create_instance(
        ck_dir,
        instance_type="execution",
        instance_id=proof.exec_id,
        metadata={
            "route_id": proof.route_id,
            "kernel_urn": proof.kernel_urn,
            "network": proof.network,
            "execution_hash": proof.execution_hash,
            "settle_tx": proof.settle_tx,
            "steps_count": len(proof.steps),
        },
    )

    append_ledger(instance["path"], "pending", "executing", "Route execution started")
    append_ledger(instance["path"], "executing", "settling", "Steps complete, settling payment")
    append_ledger(instance["path"], "settling", "completed", "Execution sealed")

    result = seal_instance(instance["path"], output={
        "exec_id": proof.exec_id,
        "route_id": proof.route_id,
        "network": proof.network,
        "execution_hash": proof.execution_hash,
        "settle_tx": proof.settle_tx,
        "payment_split": proof.payment_split,
        "steps": steps_data,
        "started_at": proof.started_at,
        "ended_at": proof.ended_at,
    })

    return {
        "instance_id": instance["instance_id"],
        "instance_path": instance["path"],
        "data_hash": result.get("data_hash", ""),
        "manifest_hash": result.get("manifest_hash", ""),
        "proof_outcome": result.get("proof_outcome", ""),
    }
