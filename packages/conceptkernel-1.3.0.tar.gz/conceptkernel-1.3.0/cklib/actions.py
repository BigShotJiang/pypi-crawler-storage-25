"""Action type resolution, composition via edges, and RBAC checks.

Implements SPEC.ACTION-TYPES.md §4 (type resolution), §3 (composition),
and v3.4 access level enforcement.

Usage:
    from cklib.actions import resolve_action_type, resolve_composed_actions, check_access

    atype = resolve_action_type("email.send")        # "operate"
    composed = resolve_composed_actions("concepts/CS.Voting")
    # {'email.send': 'CK.Email', 'email.invite': 'CK.Email', 'register': 'CK.Signup'}
    ok = check_access("email.send", "auth", {"sub": "alice"}, grants)
"""
import os

import yaml


# ---------------------------------------------------------------------------
# §4 — Action Type Map (from SPEC.ACTION-TYPES.md)
# ---------------------------------------------------------------------------

ACTION_TYPE_MAP = {
    # inspect
    "status": "inspect", "ontology": "inspect", "show": "inspect",
    "list": "inspect", "version": "inspect",

    # check
    "check.*": "check", "validate": "check", "probe.*": "check",

    # mutate
    "create": "mutate", "update": "mutate", "complete": "mutate",
    "assign": "mutate", "enable": "mutate", "disable": "mutate",
    "save": "mutate", "load": "mutate",

    # operate
    "spawn": "operate", "execute": "operate", "render": "operate",
    "run": "operate", "fire": "operate", "play": "operate", "stop": "operate",
    "send": "operate", "invite": "operate",

    # query
    "catalog": "query", "graph": "query", "search": "query",
    "pending": "query", "tasks": "query",

    # deploy
    "deploy.*": "deploy", "apply": "deploy", "route.*": "deploy",

    # transfer
    "export.*": "transfer", "import.*": "transfer",
    "sync": "transfer", "regenerate": "transfer",
}

VALID_ACTION_TYPES = {"inspect", "check", "mutate", "operate", "query", "deploy", "transfer"}


def resolve_action_type(action_name):
    """Resolve dotted action name to its type per SPEC.ACTION-TYPES.md §4.

    Resolution order:
      1. Exact match (e.g. "status" → inspect)
      2. Suffix match (e.g. "task.create" → "create" → mutate)
      3. Prefix wildcard (e.g. "check.identity" → "check.*" → check)
      4. Default: inspect (read-only)
    """
    # Exact match
    if action_name in ACTION_TYPE_MAP:
        return ACTION_TYPE_MAP[action_name]

    # Suffix match: task.create → create → mutate
    suffix = action_name.rsplit(".", 1)[-1]
    if suffix in ACTION_TYPE_MAP:
        return ACTION_TYPE_MAP[suffix]

    # Prefix wildcard: check.identity → check.* → check
    prefix = action_name.split(".")[0]
    pattern = prefix + ".*"
    if pattern in ACTION_TYPE_MAP:
        return ACTION_TYPE_MAP[pattern]

    return "inspect"  # default: read-only


# ---------------------------------------------------------------------------
# §3 — Composed Actions via Edges
# ---------------------------------------------------------------------------

def _load_ck_yaml(ck_dir):
    """Load conceptkernel.yaml, return (data, error)."""
    yaml_path = os.path.join(ck_dir, "conceptkernel.yaml")
    if not os.path.isfile(yaml_path):
        return None, "conceptkernel.yaml not found"
    try:
        with open(yaml_path) as f:
            return yaml.safe_load(f), None
    except Exception as e:
        return None, str(e)


def _get_actions_from_spec(data):
    """Extract action names from spec.actions (common + unique)."""
    actions = {}
    spec_actions = data.get("spec", {}).get("actions", {})
    for section in ("common", "unique"):
        for act in spec_actions.get(section, []):
            if isinstance(act, dict) and "name" in act:
                actions[act["name"]] = act
    return actions


def _find_ck_dir_by_name(target_name, concepts_dir):
    """Find a CK directory by its metadata.name.

    Searches two levels: direct child (flat layout) and one level deeper
    (GUID subdirectory layout).
    """
    if not os.path.isdir(concepts_dir):
        return None
    for entry in os.listdir(concepts_dir):
        candidate = os.path.join(concepts_dir, entry)
        if not os.path.isdir(candidate):
            continue
        # Level 1: conceptkernel.yaml at kernel root (flat layout)
        yaml_path = os.path.join(candidate, "conceptkernel.yaml")
        if os.path.isfile(yaml_path):
            try:
                with open(yaml_path) as f:
                    d = yaml.safe_load(f)
                if isinstance(d, dict) and d.get("metadata", {}).get("name") == target_name:
                    return candidate
                # Also check kernel_class field
                if isinstance(d, dict) and d.get("kernel_class") == target_name:
                    return candidate
            except Exception:
                pass
            continue
        # Level 2: conceptkernel.yaml inside a subdirectory (GUID layout)
        for sub in os.listdir(candidate):
            sub_path = os.path.join(candidate, sub)
            if not os.path.isdir(sub_path):
                continue
            yaml_path = os.path.join(sub_path, "conceptkernel.yaml")
            if os.path.isfile(yaml_path):
                try:
                    with open(yaml_path) as f:
                        d = yaml.safe_load(f)
                    if isinstance(d, dict) and d.get("metadata", {}).get("name") == target_name:
                        return sub_path
                    if isinstance(d, dict) and d.get("kernel_class") == target_name:
                        return sub_path
                except Exception:
                    pass
    return None


def resolve_composed_actions(ck_dir, concepts_dir=None):
    """Walk COMPOSES/EXTENDS edges, collect target kernel actions.

    Returns dict: {action_name: target_kernel_name}
    Only follows COMPOSES and EXTENDS edges (not TRIGGERS/PRODUCES/LOOPS_WITH).
    """
    ck_dir = os.path.abspath(ck_dir)
    data, err = _load_ck_yaml(ck_dir)
    if err:
        return {}

    # Derive concepts_dir — walk up until we find a dir containing OTHER kernels
    if concepts_dir is None:
        concepts_dir = os.path.dirname(ck_dir)
        # Check if parent has OTHER kernel directories (not just our own GUID subdir)
        ck_basename = os.path.basename(ck_dir)
        siblings = [d for d in os.listdir(concepts_dir)
                    if d != ck_basename
                    and os.path.isdir(os.path.join(concepts_dir, d))
                    and os.path.isfile(os.path.join(concepts_dir, d, "conceptkernel.yaml"))]
        if not siblings:
            concepts_dir = os.path.dirname(concepts_dir)

    edges_section = data.get("spec", {}).get("edges", data.get("edges", {}))
    outbound = edges_section.get("outbound", [])

    composed = {}
    for edge in outbound:
        if not isinstance(edge, dict):
            continue
        predicate = edge.get("predicate", "")
        if predicate not in ("COMPOSES", "EXTENDS"):
            continue

        target_name = edge.get("target_kernel", "")
        if not target_name:
            continue

        target_dir = _find_ck_dir_by_name(target_name, concepts_dir)
        if not target_dir:
            continue

        target_data, terr = _load_ck_yaml(target_dir)
        if terr:
            continue

        target_actions = _get_actions_from_spec(target_data)
        for action_name in target_actions:
            # Don't override — first edge wins
            if action_name not in composed:
                composed[action_name] = target_name

    return composed


def get_effective_actions(ck_dir):
    """Return the full effective action set: own + composed.

    Returns dict: {action_name: {"source": "own"|kernel_name, "spec": action_dict}}
    """
    ck_dir = os.path.abspath(ck_dir)
    data, err = _load_ck_yaml(ck_dir)
    if err:
        return {}

    effective = {}

    # Own actions
    own_actions = _get_actions_from_spec(data)
    for name, spec in own_actions.items():
        effective[name] = {"source": "own", "spec": spec}

    # Composed actions
    composed = resolve_composed_actions(ck_dir)
    for name, kernel_name in composed.items():
        if name not in effective:
            effective[name] = {"source": kernel_name, "spec": {}}

    return effective


# ---------------------------------------------------------------------------
# RBAC — Access Level Enforcement
# ---------------------------------------------------------------------------

VALID_ACCESS_LEVELS = {"anon", "auth", "owner"}


def check_access(action_name, access_level, caller_claims, grants=None):
    """Verify caller has permission for action based on access level + grants.

    Args:
        action_name: the action being invoked
        access_level: "anon" | "auth" | "owner" from spec.actions
        caller_claims: JWT claims dict (empty for anonymous)
        grants: optional list of grant dicts from conceptkernel.yaml

    Returns:
        True if access is allowed, False otherwise.
    """
    if access_level not in VALID_ACCESS_LEVELS:
        return False

    # anon — always allowed
    if access_level == "anon":
        return True

    # auth — caller must have a subject
    if not caller_claims or not caller_claims.get("sub"):
        return False

    if access_level == "auth":
        # If grants exist, check if caller's identity matches any grant
        if grants:
            return _check_grants(action_name, caller_claims, grants)
        # No grants = any authenticated user
        return True

    # owner — caller must match kernel owner or have admin role
    if access_level == "owner":
        roles = caller_claims.get("realm_access", {}).get("roles", [])
        if "admin" in roles:
            return True
        # Check grants for owner-level access
        if grants:
            return _check_grants(action_name, caller_claims, grants)
        return False

    return False


def _check_grants(action_name, caller_claims, grants):
    """Check if caller matches any grant entry for the given action."""
    if not isinstance(grants, list):
        grants = [grants]

    caller_sub = caller_claims.get("sub", "")
    caller_user = caller_claims.get("preferred_username", "")

    for grant in grants:
        if not isinstance(grant, dict):
            continue

        identity = grant.get("identity", "")
        actions = grant.get("actions", [])

        # Check identity match
        if identity == "*" or identity == caller_sub or identity == caller_user:
            # Check action match
            if isinstance(actions, list):
                if "*" in actions or action_name in actions:
                    return True
            elif actions == "*" or actions == action_name:
                return True

    return False
