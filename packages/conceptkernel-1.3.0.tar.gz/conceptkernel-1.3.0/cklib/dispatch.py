"""Action dispatch — send actions to kernels locally or via queue.

All actions go through the queue. The queue processes FIFO locally.

Usage:
    from cklib.dispatch import send_action, queue_action, run_queue

    # Immediate (bypasses queue for inspect/query actions):
    result = send_action("CK.Task", "status")

    # Queued (for operate/mutate/check/deploy actions):
    queue_action("CK.Task", "task.create", data={...}, persona="builder")

    # Process queue:
    run_queue()
"""
import importlib.util
import json
import os
import time
import glob

PROJECT_ROOT = None
CONCEPTS_DIR = None


def _init_paths():
    global PROJECT_ROOT, CONCEPTS_DIR
    if PROJECT_ROOT is None:
        # Prefer env vars (set by CK.Operator boot or delvinator.sh)
        if os.environ.get("CK_CONCEPTS_DIR"):
            CONCEPTS_DIR = os.environ["CK_CONCEPTS_DIR"]
            PROJECT_ROOT = os.path.dirname(CONCEPTS_DIR)
        elif os.environ.get("PROJECT_ROOT"):
            PROJECT_ROOT = os.environ["PROJECT_ROOT"]
            CONCEPTS_DIR = os.path.join(PROJECT_ROOT, "concepts")
        else:
            # Fallback: walk up from cklib to find concepts/ dir containing kernel dirs
            candidate = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
            for _ in range(5):
                concepts_candidate = os.path.join(candidate, "concepts")
                if os.path.isdir(concepts_candidate):
                    # Verify it has actual kernel directories (not just a stray concepts/ folder)
                    has_kernels = any(
                        os.path.isfile(os.path.join(concepts_candidate, d, "conceptkernel.yaml"))
                        or any(os.path.isfile(os.path.join(concepts_candidate, d, sub, "conceptkernel.yaml"))
                               for sub in os.listdir(os.path.join(concepts_candidate, d))
                               if os.path.isdir(os.path.join(concepts_candidate, d, sub)))
                        for d in os.listdir(concepts_candidate)
                        if os.path.isdir(os.path.join(concepts_candidate, d))
                    )
                    if has_kernels:
                        PROJECT_ROOT = candidate
                        CONCEPTS_DIR = concepts_candidate
                        break
                candidate = os.path.dirname(candidate)
            else:
                PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..", ".."))
                CONCEPTS_DIR = os.path.join(PROJECT_ROOT, "concepts")


def resolve_kernel(name):
    """Resolve kernel name to directory + processor path."""
    _init_paths()
    for prefix in ["", "CK.", "TG.", "LOCAL.", "Test."]:
        ck_dir = os.path.join(CONCEPTS_DIR, prefix + name)
        proc = os.path.join(ck_dir, "tool", "processor.py")
        if os.path.isfile(proc):
            return ck_dir, proc
    return None, None


def load_handler(processor_path):
    """Import handle_message from a processor.py."""
    spec = importlib.util.spec_from_file_location("processor", processor_path)
    mod = importlib.util.module_from_spec(spec)
    old_cwd = os.getcwd()
    os.chdir(os.path.dirname(processor_path))
    try:
        spec.loader.exec_module(mod)
    finally:
        os.chdir(old_cwd)
    return getattr(mod, "handle_message", None)


def send_action(kernel_name, action, data=None):
    """Send action directly — no queue. For inspect/query (stateless reads)."""
    ck_dir, proc_path = resolve_kernel(kernel_name)
    if not proc_path:
        return {"status": "error", "message": "kernel not found: %s" % kernel_name}

    handler = load_handler(proc_path)
    if not handler:
        return {"status": "error", "message": "no handle_message in %s" % kernel_name}

    msg = {"action": action}
    if data:
        msg["data"] = data

    try:
        return handler(msg)
    except Exception as e:
        return {"status": "error", "message": str(e), "kernel": kernel_name}


# ---------------------------------------------------------------------------
# Queue — FIFO for local execution
# ---------------------------------------------------------------------------

def _queue_dir():
    _init_paths()
    qdir = os.path.join(CONCEPTS_DIR, "LOCAL.ClaudeCode", "storage", "queue")
    os.makedirs(qdir, exist_ok=True)
    return qdir


def queue_action(kernel_name, action, data=None, persona="operator",
                 task_id="", goal_id=""):
    """Add an action to the FIFO queue."""
    qdir = _queue_dir()
    ts = int(time.time() * 1000)  # millisecond precision for ordering
    seq = len(glob.glob(os.path.join(qdir, "*.json"))) + 1

    entry = {
        "seq": seq,
        "kernel": kernel_name,
        "action": action,
        "data": data or {},
        "persona": persona,
        "task_id": task_id,
        "goal_id": goal_id,
        "queued_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "status": "pending",
    }

    filename = "%03d-%s-%s-%d.json" % (seq, kernel_name.replace(".", "-"), action.replace(".", "-"), ts)
    with open(os.path.join(qdir, filename), "w") as f:
        json.dump(entry, f, indent=2)

    return entry


def list_queue():
    """List all pending queue entries in FIFO order."""
    qdir = _queue_dir()
    entries = []
    for fname in sorted(os.listdir(qdir)):
        if fname.endswith(".json"):
            with open(os.path.join(qdir, fname)) as f:
                entry = json.load(f)
            entry["_file"] = fname
            entries.append(entry)
    return [e for e in entries if e.get("status") == "pending"]


def run_queue():
    """Process the queue FIFO — one at a time."""
    _init_paths()
    lock_path = os.path.join(CONCEPTS_DIR, "LOCAL.ClaudeCode", "storage", "lock")

    # Check lock
    if os.path.exists(lock_path):
        with open(lock_path) as f:
            pid = f.read().strip()
        # Check if process still running
        try:
            os.kill(int(pid), 0)
            return {"status": "locked", "pid": pid, "message": "Queue runner already active"}
        except (OSError, ValueError):
            os.remove(lock_path)

    # Acquire lock
    with open(lock_path, "w") as f:
        f.write(str(os.getpid()))

    try:
        pending = list_queue()
        results = []
        total = len(pending)

        for i, entry in enumerate(pending, 1):
            kernel = entry["kernel"]
            action = entry["action"]
            persona = entry.get("persona", "operator")

            print("[%d/%d] %s → %s (%s)" % (i, total, entry.get("task_id") or action, kernel, persona))

            result = send_action(kernel, action, entry.get("data"))
            results.append({"entry": entry, "result": result})

            # Mark as completed
            entry["status"] = "completed"
            entry["completed_at"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
            entry["result_status"] = result.get("status", "unknown")

            qpath = os.path.join(_queue_dir(), entry["_file"])
            with open(qpath, "w") as f:
                json.dump(entry, f, indent=2)

            status = result.get("status", "?")
            print("       %s" % status)

        return {"status": "ok", "processed": len(results), "results": results}
    finally:
        if os.path.exists(lock_path):
            os.remove(lock_path)
