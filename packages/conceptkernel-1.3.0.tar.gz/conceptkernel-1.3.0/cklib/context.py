"""Three-loop-aware context builder, extracted from LOCAL.ClaudeCode pattern.

Builds a context payload from a target kernel's three loops:
  CK LOOP:   conceptkernel.yaml, CLAUDE.md, SKILL.md, ontology.yaml
  TOOL LOOP: composed SKILL.md files from COMPOSES/EXTENDS edges
  DATA LOOP: llm/memory/MEMORY.md, llm/tasks/*.md

Usage:
    from cklib.context import build_context

    ctx = build_context("/path/to/concepts/MyKernel/guid")
    ctx = build_context("/path/to/concepts/MyKernel/guid", target_ck="CK.Email")
    ctx = build_context(ck_dir, context_items=["identity", "skill_md", "edges"])
"""
import os

import yaml


# All valid context_items values
ALL_ITEMS = frozenset({
    "identity", "claude_md", "skill_md", "memory", "tasks",
    "edges", "composed_skills", "ontology", "changelog",
})


def build_context(ck_dir, target_ck=None, context_items=None):
    """Build context payload from a target kernel's three loops.

    If target_ck is None, builds context for self (ck_dir).
    If target_ck is a string, resolves it via concepts/ directory.

    context_items controls what to load. Default: all.
    Options: "identity", "claude_md", "skill_md", "memory", "tasks",
             "edges", "composed_skills", "ontology", "changelog"

    Returns dict with:
      identity: parsed conceptkernel.yaml
      claude_md: CLAUDE.md text (CK loop)
      skill_md: SKILL.md text (CK loop)
      ontology: parsed ontology.yaml (CK loop)
      memory_md: llm/memory/MEMORY.md text (DATA loop)
      tasks: list of task filenames in llm/tasks/ (DATA loop)
      edges: outbound edges from spec.edges (CK loop)
      composed_skills: {kernel_name: skill_md_text} for COMPOSES/EXTENDS edges
      changelog: CHANGELOG.md text
      loop: dict mapping each loaded item to its filesystem path
    """
    ck_dir = os.path.abspath(ck_dir)
    project_root = os.path.abspath(os.path.join(ck_dir, "..", ".."))
    concepts_dir = os.path.join(project_root, "concepts")

    # Determine which items to load
    items = ALL_ITEMS if context_items is None else set(context_items) & ALL_ITEMS

    # Resolve target kernel directory
    if target_ck is not None:
        target_dir = _resolve_kernel(target_ck, concepts_dir)
        if target_dir is None:
            return {
                "status": "error",
                "message": "cannot resolve target kernel: %s" % target_ck,
            }
    else:
        target_dir = ck_dir

    result = {}
    loop_map = {}

    # -- CK LOOP ---------------------------------------------------------------

    if "identity" in items:
        identity, path = _load_yaml(target_dir, "conceptkernel.yaml")
        if identity is not None:
            result["identity"] = identity
            loop_map["identity"] = path

    if "claude_md" in items:
        text, path = _load_text_prefer(target_dir, ["CLAUDE.md", "llm/CLAUDE.md"])
        if text is not None:
            result["claude_md"] = text
            loop_map["claude_md"] = path

    if "skill_md" in items:
        text, path = _load_text(target_dir, "SKILL.md")
        if text is not None:
            result["skill_md"] = text
            loop_map["skill_md"] = path

    if "ontology" in items:
        data, path = _load_yaml(target_dir, "ontology.yaml")
        if data is not None:
            result["ontology"] = data
            loop_map["ontology"] = path

    if "edges" in items:
        identity = result.get("identity")
        if identity is None:
            identity, _ = _load_yaml(target_dir, "conceptkernel.yaml")
        if identity is not None:
            edges = _extract_edges(identity)
            if edges:
                result["edges"] = edges
                loop_map["edges"] = os.path.join(target_dir, "conceptkernel.yaml")

    # -- TOOL LOOP (composed skills) -------------------------------------------

    if "composed_skills" in items:
        identity = result.get("identity")
        if identity is None:
            identity, _ = _load_yaml(target_dir, "conceptkernel.yaml")
        if identity is not None:
            composed, paths = _load_composed_skills(identity, concepts_dir)
            if composed:
                result["composed_skills"] = composed
                loop_map["composed_skills"] = paths

    # -- DATA LOOP -------------------------------------------------------------

    if "memory" in items:
        text, path = _load_text(target_dir, os.path.join("llm", "memory", "MEMORY.md"))
        if text is not None:
            result["memory_md"] = text
            loop_map["memory_md"] = path

    if "tasks" in items:
        tasks, path = _list_tasks(target_dir)
        if tasks:
            result["tasks"] = tasks
            loop_map["tasks"] = path

    # -- CHANGELOG -------------------------------------------------------------

    if "changelog" in items:
        text, path = _load_text(target_dir, "CHANGELOG.md")
        if text is not None:
            result["changelog"] = text
            loop_map["changelog"] = path

    result["loop"] = loop_map
    return result


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _resolve_kernel(name, concepts_dir):
    """Resolve a kernel name to its directory under concepts/.

    Scans concepts/ for directories containing a conceptkernel.yaml whose
    metadata.name matches the given name. Also checks if the directory name
    itself matches (common convention).
    """
    if not os.path.isdir(concepts_dir):
        return None

    # Fast path: directory name matches directly
    direct = os.path.join(concepts_dir, name)
    if os.path.isdir(direct):
        yaml_path = os.path.join(direct, "conceptkernel.yaml")
        if os.path.isfile(yaml_path):
            return direct
        # Check one level deeper (concepts/Name/guid/)
        for sub in _listdir_safe(direct):
            sub_path = os.path.join(direct, sub)
            if os.path.isdir(sub_path) and os.path.isfile(
                os.path.join(sub_path, "conceptkernel.yaml")
            ):
                return sub_path

    # Slow path: scan all entries for metadata.name match
    for entry in _listdir_safe(concepts_dir):
        candidate = os.path.join(concepts_dir, entry)
        if not os.path.isdir(candidate):
            continue

        # Check if conceptkernel.yaml is directly in the entry
        ck_yaml = os.path.join(candidate, "conceptkernel.yaml")
        if os.path.isfile(ck_yaml):
            if _yaml_name_matches(ck_yaml, name):
                return candidate
            continue

        # Check one level deeper (concepts/Name/guid/)
        for sub in _listdir_safe(candidate):
            sub_path = os.path.join(candidate, sub)
            if not os.path.isdir(sub_path):
                continue
            ck_yaml = os.path.join(sub_path, "conceptkernel.yaml")
            if os.path.isfile(ck_yaml) and _yaml_name_matches(ck_yaml, name):
                return sub_path

    return None


def _yaml_name_matches(yaml_path, name):
    """Check if a conceptkernel.yaml has metadata.name == name."""
    try:
        with open(yaml_path) as f:
            data = yaml.safe_load(f)
        return isinstance(data, dict) and data.get("metadata", {}).get("name") == name
    except Exception:
        return False


def _listdir_safe(path):
    """os.listdir that returns [] on error."""
    try:
        return os.listdir(path)
    except OSError:
        return []


def _load_yaml(base_dir, rel_path):
    """Load and parse a YAML file. Returns (data, abs_path) or (None, None)."""
    path = os.path.join(base_dir, rel_path)
    if not os.path.isfile(path):
        return None, None
    try:
        with open(path) as f:
            data = yaml.safe_load(f)
        return data, path
    except Exception:
        return None, None


def _load_text(base_dir, rel_path):
    """Load a text file. Returns (text, abs_path) or (None, None)."""
    path = os.path.join(base_dir, rel_path)
    if not os.path.isfile(path):
        return None, None
    try:
        with open(path) as f:
            return f.read(), path
    except Exception:
        return None, None


def _load_text_prefer(base_dir, rel_paths):
    """Try multiple relative paths, return the first that exists."""
    for rel in rel_paths:
        text, path = _load_text(base_dir, rel)
        if text is not None:
            return text, path
    return None, None


def _extract_edges(identity):
    """Extract outbound edges from a parsed conceptkernel.yaml."""
    edges_section = identity.get("spec", {}).get("edges", identity.get("edges", {}))
    if not isinstance(edges_section, dict):
        return []
    outbound = edges_section.get("outbound", [])
    if not isinstance(outbound, list):
        return []
    return outbound


def _load_composed_skills(identity, concepts_dir):
    """For each COMPOSES/EXTENDS edge, resolve target kernel and load its SKILL.md.

    Returns ({kernel_name: skill_md_text}, {kernel_name: abs_path}).
    """
    composed = {}
    paths = {}

    outbound = _extract_edges(identity)
    for edge in outbound:
        if not isinstance(edge, dict):
            continue
        predicate = edge.get("predicate", "")
        if predicate not in ("COMPOSES", "EXTENDS"):
            continue

        target_name = edge.get("target_kernel", "")
        if not target_name:
            continue

        target_dir = _resolve_kernel(target_name, concepts_dir)
        if target_dir is None:
            continue

        skill_text, skill_path = _load_text(target_dir, "SKILL.md")
        if skill_text is not None:
            composed[target_name] = skill_text
            paths[target_name] = skill_path

    return composed, paths


def _list_tasks(base_dir):
    """List .md filenames in llm/tasks/. Returns (list, dir_path) or ([], None)."""
    tasks_dir = os.path.join(base_dir, "llm", "tasks")
    if not os.path.isdir(tasks_dir):
        return [], None
    try:
        files = sorted(
            f for f in os.listdir(tasks_dir)
            if f.endswith(".md") and os.path.isfile(os.path.join(tasks_dir, f))
        )
        return files, tasks_dir
    except OSError:
        return [], None
