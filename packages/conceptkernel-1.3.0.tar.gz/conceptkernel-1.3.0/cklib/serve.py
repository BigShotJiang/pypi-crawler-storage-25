"""KernelServer — FastAPI wrapper for KernelProcessor.

Auto-creates HTTP endpoints from conceptkernel.yaml actions.
Same @on handlers serve both NATS and HTTP.

Usage:
    from cklib import KernelProcessor, on
    from cklib.serve import KernelServer

    class MyKernel(KernelProcessor):
        @on("my.action")
        def do_thing(self, data):
            return {"result": "done"}

    # In processor.py:
    if __name__ == "__main__":
        MyKernel.run()  # --serve flag starts HTTP

Or programmatically:
    server = KernelServer(MyKernel())
    server.run(port=8901)
"""
import asyncio
import json
import os
import uuid
from datetime import datetime, timezone

import uvicorn
from fastapi import FastAPI, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from cklib.actions import check_access, _get_actions_from_spec, _load_ck_yaml
from cklib.auth import CKAuth
from cklib.instance import create_instance, seal_instance, append_ledger


class KernelServer:
    """FastAPI server that wraps a KernelProcessor."""

    def __init__(self, processor, api_token=None, port=8901):
        self.processor = processor
        self.port = port
        self.auth = CKAuth(api_token=api_token)

        # Build action access map from conceptkernel.yaml
        self._action_access = self._build_action_access_map()

        self.app = FastAPI(title=processor.name, version="1.0")
        self.app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_methods=["GET", "POST", "OPTIONS"],
            allow_headers=["*"],
        )

        self._setup_lifecycle()
        self._setup_routes()
        # Custom routes added by processor before static mount
        if hasattr(processor, '_register_routes'):
            processor._register_routes(self)
        self._setup_static()

    def _build_action_access_map(self):
        """Build {action_name: access_level} from conceptkernel.yaml."""
        data, err = _load_ck_yaml(self.processor.ck_dir)
        if err:
            return {}
        actions = _get_actions_from_spec(data)
        return {name: spec.get("access", "auth") for name, spec in actions.items()}

    def _check_action_access(self, action_name, request):
        """Enforce access level for an action. Returns (claims, error_response)."""
        from fastapi.responses import JSONResponse

        access_level = self._action_access.get(action_name, "auth")

        if access_level == "anon":
            # Try auth but don't require it
            try:
                claims = self.auth.authenticate(request)
            except Exception:
                claims = {"sub": "anonymous", "preferred_username": "anonymous"}
            return claims, None

        # auth or owner — require authentication
        try:
            claims = self.auth.authenticate(request)
        except Exception as e:
            return None, JSONResponse({"error": str(e)}, status_code=401)

        # Check grants for owner-level actions
        grants = self.processor.identity.get("grants", [])
        if not check_access(action_name, access_level, claims, grants):
            return None, JSONResponse(
                {"error": "insufficient access for %s" % action_name},
                status_code=403,
            )

        return claims, None

    def _setup_lifecycle(self):
        @self.app.on_event("startup")
        async def startup():
            n = await self.auth.load_jwks()
            print(f"[serve] {self.processor.name} ready")
            print(f"[jwks]  {n} keys loaded")

    def _setup_routes(self):
        proc = self.processor
        auth = self.auth
        server = self

        @self.app.get("/health")
        async def health():
            return {
                "status": "ok",
                "kernel": proc.name,
                "urn": proc.urn,
                "jwks_loaded": auth.jwks_loaded,
            }

        @self.app.get("/ontology.yaml")
        async def ontology_yaml():
            path = os.path.join(proc.ck_dir, "conceptkernel.yaml")
            if os.path.isfile(path):
                return FileResponse(path, media_type="text/yaml")
            return JSONResponse({"error": "not found"}, 404)

        @self.app.get("/action/{action_name}")
        async def action_endpoint(action_name: str, request: Request):
            """Generic action endpoint — dispatches to @on handler."""
            claims, err = server._check_action_access(action_name, request)
            if err:
                return err
            user_id = claims.get("preferred_username", claims.get("sub", "unknown"))

            # Collect query params as data (excluding auth params)
            data = {k: v for k, v in request.query_params.items()
                    if k not in ("token",)}
            data["_user_id"] = user_id
            data["_request"] = True  # mark as HTTP request

            msg = {"action": action_name, "data": data}
            result = proc.handle_message(msg)

            # Record instance
            inst = create_instance(proc.ck_dir, instance_type=action_name, metadata={
                "action": action_name,
                "user_id": user_id,
                "source": "http",
            })
            append_ledger(inst["path"], "pending", "completed", f"{action_name} via HTTP")
            seal_instance(inst["path"], result)

            return JSONResponse(result)

        @self.app.post("/action/{action_name}")
        async def action_post(action_name: str, request: Request):
            """POST action — body is JSON data."""
            claims, err = server._check_action_access(action_name, request)
            if err:
                return err
            user_id = claims.get("preferred_username", claims.get("sub", "unknown"))

            try:
                body = await request.json()
            except Exception:
                body = {}

            body["_user_id"] = user_id
            msg = {"action": action_name, "data": body}
            result = proc.handle_message(msg)

            inst = create_instance(proc.ck_dir, instance_type=action_name, metadata={
                "action": action_name, "user_id": user_id, "source": "http",
            })
            append_ledger(inst["path"], "pending", "completed", f"{action_name} via HTTP POST")
            seal_instance(inst["path"], result)

            return JSONResponse(result)

        # Expose custom routes if processor defines them
        if hasattr(proc, '_http_routes'):
            for route in proc._http_routes:
                self.app.add_api_route(**route)

    def register_instances_endpoint(self, require_auth=True):
        """Add GET /instances — list recent instance manifests from storage/.

        Both VoiceScreen and CS.Voting duplicate this pattern. Call this
        from _register_routes to get it for free.
        """
        proc = self.processor
        auth = self.auth

        @self.app.get("/instances")
        async def list_instances(request: Request):
            if require_auth:
                auth.authenticate(request)
            import json as _json
            instances = []
            inst_dir = os.path.join(proc.ck_dir, "storage", "instances")
            if os.path.isdir(inst_dir):
                for name in sorted(os.listdir(inst_dir), reverse=True)[:50]:
                    mp = os.path.join(inst_dir, name, "manifest.json")
                    if os.path.isfile(mp):
                        with open(mp) as f:
                            instances.append(_json.load(f))
            return instances

    def _setup_static(self):
        """Serve web/ and CK.Lib assets with no-cache headers."""
        proc = self.processor
        web_dir = os.path.join(proc.ck_dir, "web")
        cklib_web = os.path.join(proc.concepts_dir, "CK.Lib", "web")

        # Serve CK.Lib assets
        if os.path.isdir(cklib_web):
            @self.app.get("/ck.lib/{path:path}")
            async def serve_cklib(path: str):
                fpath = os.path.join(cklib_web, path)
                if not os.path.isfile(os.path.realpath(fpath)):
                    return JSONResponse({"error": "not found"}, 404)
                return FileResponse(os.path.realpath(fpath),
                    headers={"Cache-Control": "no-cache, no-store, must-revalidate"})

        # Serve web/ with no-cache (always reads fresh from disk)
        if os.path.isdir(web_dir):
            @self.app.get("/{path:path}")
            async def serve_web(path: str):
                if not path or path == "/":
                    path = "index.html"
                fpath = os.path.join(web_dir, path)
                real = os.path.realpath(fpath)
                if not os.path.isfile(real):
                    # Try index.html for directory paths
                    real = os.path.realpath(os.path.join(web_dir, "index.html"))
                    if not os.path.isfile(real):
                        return JSONResponse({"error": "not found"}, 404)
                return FileResponse(real,
                    headers={"Cache-Control": "no-cache, no-store, must-revalidate"})

    def run(self, host="0.0.0.0", port=None):
        """Start the server."""
        port = port or self.port
        print(f"[serve] http://{host}:{port}")
        uvicorn.run(self.app, host=host, port=port, log_level="info")

    def add_route(self, method, path, handler, **kwargs):
        """Add a custom route (for kernel-specific endpoints beyond @on)."""
        self.app.add_api_route(path, handler, methods=[method], **kwargs)
