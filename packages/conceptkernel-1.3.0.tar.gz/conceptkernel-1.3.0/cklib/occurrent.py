"""Occurrent tracking — ontology-verified action substeps with PROV-O proof.

Every CKP action is an Occurrent (bfo:Process). Each substep within an action
is also an Occurrent, linked to its parent via prov:wasStartedBy.

At completion, the parent action's proof is built from the chain of substep
occurrents — each one verified before the next can start.

Usage:
    from cklib.occurrent import ActionOccurrent

    with ActionOccurrent("project.deploy", kernel_urn="ckp://Kernel#CK.Operator:v1.0") as action:
        action.step("deploy.accepted", {"hostname": "delvinator.tech.games"})
        action.step("deploy.scanning", {"kernels": 6})

        # Substep with verification
        with action.substep("deploy.materialising") as sub:
            sub.detail("resources", 9)
            sub.verify("namespace_created", True)
            sub.verify("pv_bound", True)
            sub.verify("deployment_ready", True)

        action.step("deploy.ready", {"url": "https://delvinator.tech.games/"})

    # action.proof contains the hash chain of all steps
    # action.occurrents contains the full list with URNs and timestamps
"""

import hashlib
import json
import os
import time
import uuid
from datetime import datetime, timezone
from dataclasses import dataclass, field, asdict


@dataclass
class StepRecord:
    """A single occurrent step within an action."""
    step_urn: str
    step_type: str
    timestamp: str
    detail: dict = field(default_factory=dict)
    verifications: list = field(default_factory=list)
    hash: str = ""
    parent_hash: str = ""
    status: str = "ok"


@dataclass
class VerificationRecord:
    """A verification check within a step."""
    check: str
    passed: bool
    detail: str = ""
    timestamp: str = ""


class ActionOccurrent:
    """Track an action as a chain of verified occurrent steps.

    Each step gets:
    - A URN: ckp://Occurrent#{kernel}/{action}/{step}-{ts}
    - A SHA-256 hash chained to the previous step
    - Optional verification checks (pass/fail)
    - PROV-O links: wasStartedBy parent action

    The complete action proof = hash chain of all steps.
    """

    def __init__(self, action_name, kernel_urn="", ck_dir=None):
        self.action_name = action_name
        self.kernel_urn = kernel_urn
        self.ck_dir = ck_dir

        ts_ms = int(time.time() * 1000)
        kernel_short = kernel_urn.split("#")[-1].split(":")[0] if "#" in kernel_urn else "unknown"

        self.action_urn = f"ckp://Action#{kernel_short}/{action_name}-{ts_ms}"
        self.started_at = datetime.now(timezone.utc).isoformat()
        self.ended_at = None
        self.steps = []
        self._prev_hash = self._hash(self.action_urn)
        self._current_substep = None

    def step(self, step_type, detail=None):
        """Record a step in the action."""
        ts = datetime.now(timezone.utc).isoformat()
        ts_ms = int(time.time() * 1000)
        kernel_short = self.kernel_urn.split("#")[-1].split(":")[0] if "#" in self.kernel_urn else "unknown"

        step_urn = f"ckp://Occurrent#{kernel_short}/{self.action_name}/{step_type}-{ts_ms}"

        # Chain hash
        content = json.dumps({"step": step_type, "detail": detail or {}, "prev": self._prev_hash},
                             sort_keys=True)
        step_hash = self._hash(content)

        record = StepRecord(
            step_urn=step_urn,
            step_type=step_type,
            timestamp=ts,
            detail=detail or {},
            hash=step_hash,
            parent_hash=self._prev_hash,
        )

        self.steps.append(record)
        self._prev_hash = step_hash
        return record

    def substep(self, step_type):
        """Context manager for a substep with verification checks."""
        return _Substep(self, step_type)

    def verify_chain(self):
        """Verify the hash chain is intact."""
        prev = self._hash(self.action_urn)
        for s in self.steps:
            content = json.dumps({"step": s.step_type, "detail": s.detail, "prev": prev},
                                 sort_keys=True)
            expected = self._hash(content)
            if s.hash != expected:
                return False, f"Chain broken at {s.step_type}: expected {expected[:12]}, got {s.hash[:12]}"
            prev = s.hash
        return True, "Chain intact"

    @property
    def proof(self):
        """Generate the action proof from the step chain."""
        valid, message = self.verify_chain()
        all_verified = all(
            all(v.passed for v in s.verifications)
            for s in self.steps
        )
        return {
            "action_urn": self.action_urn,
            "kernel_urn": self.kernel_urn,
            "action": self.action_name,
            "started_at": self.started_at,
            "ended_at": self.ended_at,
            "steps": len(self.steps),
            "chain_valid": valid,
            "chain_message": message,
            "all_verified": all_verified,
            "final_hash": self._prev_hash,
            "prov:wasAssociatedWith": self.kernel_urn,
            "prov:startedAtTime": self.started_at,
            "prov:endedAtTime": self.ended_at,
        }

    @property
    def occurrents(self):
        """Return all step records as dicts."""
        return [asdict(s) for s in self.steps]

    def save(self, path=None):
        """Save proof + occurrents to storage/proof/."""
        if path is None and self.ck_dir:
            proof_dir = os.path.join(self.ck_dir, "storage", "proof")
            os.makedirs(proof_dir, exist_ok=True)
            ts = int(time.time())
            path = os.path.join(proof_dir, f"proof-{self.action_name}-{ts}.json")

        if path:
            doc = {
                "proof": self.proof,
                "occurrents": self.occurrents,
            }
            with open(path, "w") as f:
                json.dump(doc, f, indent=2)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.ended_at = datetime.now(timezone.utc).isoformat()
        if exc_type:
            self.step("action.failed", {"error": str(exc_val)})
        if self.ck_dir:
            self.save()

    @staticmethod
    def _hash(content):
        if isinstance(content, dict):
            content = json.dumps(content, sort_keys=True)
        return hashlib.sha256(content.encode()).hexdigest()


class _Substep:
    """Context manager for a substep with verification."""

    def __init__(self, parent, step_type):
        self.parent = parent
        self.step_type = step_type
        self._detail = {}
        self._verifications = []

    def detail(self, key, value):
        self._detail[key] = value

    def verify(self, check_name, passed, detail=""):
        self._verifications.append(VerificationRecord(
            check=check_name,
            passed=passed,
            detail=detail,
            timestamp=datetime.now(timezone.utc).isoformat(),
        ))

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        record = self.parent.step(self.step_type, self._detail)
        record.verifications = self._verifications
        if not all(v.passed for v in self._verifications):
            record.status = "verification_failed"
