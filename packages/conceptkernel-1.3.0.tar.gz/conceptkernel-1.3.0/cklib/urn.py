#!/usr/bin/env python3
"""CK URN — Parse, validate, and construct CKP v3.1 URNs.

Standalone CLI and importable library.

URN format: ckp://{EntityType}#{Identifier}[:{Version}]

Usage:
    python3 tools/ck_urn.py validate "ckp://Kernel#TG.Cymatics:v1.0"
    python3 tools/ck_urn.py parse "ckp://Process#deploy-1773518402000-3fff0e38"
    python3 tools/ck_urn.py fleet                    # validate all fleet URNs
    python3 tools/ck_urn.py build --type Kernel --name TG.Cymatics --version v1.0

As library:
    from tools.ck_urn import parse_urn, validate_urn, build_urn
    parsed = parse_urn("ckp://Kernel#TG.Cymatics:v1.0")
    result = validate_urn("ckp://Kernel#TG.Cymatics:v1.0")
    urn = build_urn("Kernel", "TG.Cymatics", version="v1.0")
"""
import argparse
import glob
import json
import os
import re
import sys

import yaml

# ---------------------------------------------------------------------------
# Entity type registry — continuants vs occurrents
# ---------------------------------------------------------------------------

# Continuants (BFO:0000002) — persist through time
CONTINUANT_TYPES = {
    "Kernel",       # BFO:0000040 MaterialEntity
    "Actor",        # BFO:0000040
    "Role",         # BFO:0000023
    "Edge",         # BFO:0000020 SpecificallyDependentContinuant
    "Goal",         # BFO:0000040
    "Domain",       # BFO:0000040
    "Project",      # BFO:0000040
    "Grant",        # BFO:0000023
}

# Occurrents (BFO:0000003) — unfold over time
OCCURRENT_TYPES = {
    "Process",      # BFO:0000015
    "Task",         # BFO:0000015
    "Instance",     # BFO:0000015
    "Event",        # BFO:0000015
    "Transaction",  # BFO:0000015
    "Message",      # BFO:0000015
    "Check",        # BFO:0000015
    "Action",       # BFO:0000015 (invocation)
    "Deployment",   # BFO:0000015
    "Transfer",     # BFO:0000015
    "Mutation",     # BFO:0000015
}

ALL_TYPES = CONTINUANT_TYPES | OCCURRENT_TYPES

# Valid namespace prefixes for kernel names
VALID_PREFIXES = {"CK", "TG", "CS", "LOCAL", "Test", "TechGames"}

# ---------------------------------------------------------------------------
# Regex patterns
# ---------------------------------------------------------------------------

# Base URN: ckp://{Type}#{Identifier}[:{Version}][?{Query}]
# Identifier may contain / for v3.4 compound URNs (e.g. Action#Kernel/action)
URN_PATTERN = re.compile(
    r'^ckp://([A-Za-z]+)#([^:?]+?)(?::v(\d+\.\d+(?:\.\d+)?))?(?:\?(.+))?$'
)

# Kernel name: {Prefix}.{Name} or {Prefix}.{Cat}.{Name}
KERNEL_NAME_PATTERN = re.compile(
    r'^[A-Z][A-Za-z]+\.[A-Za-z0-9.]+$'
)

# Process/occurrent identifier with timestamp: {Type}-{TimestampMs}-{Hash}
TIMESTAMP_ID_PATTERN = re.compile(
    r'^([A-Za-z0-9.-]+)-(\d{10,13})-([a-f0-9]+)$'
)

# Task ID: T{NNN}
TASK_ID_PATTERN = re.compile(r'^T\d{3,}$')

# Goal ID: G{NNN}
GOAL_ID_PATTERN = re.compile(r'^G\d{3,}$')

# Instance ID: i-{trace}-{ts} or i-tx-{hash}-{ts}
INSTANCE_ID_PATTERN = re.compile(r'^i-[a-z]+-[a-f0-9]+-\d+$')

# UUID v4
UUID_PATTERN = re.compile(
    r'^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$',
    re.IGNORECASE,
)


# ---------------------------------------------------------------------------
# Parse
# ---------------------------------------------------------------------------

def parse_urn(urn):
    """Parse a CKP URN into its components.

    Returns dict with: entity_type, identifier, version, category (continuant/occurrent),
    and type-specific fields.
    """
    if not isinstance(urn, str):
        return {"valid": False, "error": "URN must be a string", "urn": str(urn)}

    match = URN_PATTERN.match(urn)
    if not match:
        return {"valid": False, "error": "Does not match URN pattern", "urn": urn}

    entity_type = match.group(1)
    identifier = match.group(2)
    version = match.group(3)

    result = {
        "valid": True,
        "urn": urn,
        "entity_type": entity_type,
        "identifier": identifier,
        "version": "v" + version if version else None,
    }

    # Categorize
    if entity_type in CONTINUANT_TYPES:
        result["category"] = "continuant"
        result["bfo_class"] = "BFO:0000002"
    elif entity_type in OCCURRENT_TYPES:
        result["category"] = "occurrent"
        result["bfo_class"] = "BFO:0000003"
    else:
        result["category"] = "unknown"

    # Type-specific parsing
    if entity_type == "Kernel":
        result["kernel_name"] = identifier
        parts = identifier.split(".", 1)
        if len(parts) >= 2:
            result["prefix"] = parts[0]

    elif entity_type in ("Process", "Deployment", "Transfer", "Check"):
        ts_match = TIMESTAMP_ID_PATTERN.match(identifier)
        if ts_match:
            result["process_type"] = ts_match.group(1)
            result["timestamp_ms"] = int(ts_match.group(2))
            result["hash"] = ts_match.group(3)

    elif entity_type == "Task":
        result["task_id"] = identifier

    elif entity_type == "Goal":
        result["goal_id"] = identifier

    elif entity_type == "Instance":
        result["instance_id"] = identifier

    elif entity_type == "Edge":
        if identifier.startswith("Connection-"):
            # Parse edge connection: Connection-{Source}-to-{Target}-{Predicate}
            edge_match = re.match(
                r'^Connection-(.+?)-to-(.+?)-([A-Z_]+)$', identifier)
            if edge_match:
                result["source"] = edge_match.group(1)
                result["target"] = edge_match.group(2)
                result["predicate"] = edge_match.group(3)
        else:
            result["predicate"] = identifier

    elif entity_type == "Action":
        # v3.4 slash form: {kernel}/{action_name}[-{ts}]
        # v3.1 dot form:   {kernel}.{action_name}[-{ts}] (deprecated)
        # Strip optional timestamp suffix first
        action_id = identifier
        ts_suffix = None
        dash_parts = identifier.rsplit("-", 1)
        if len(dash_parts) == 2 and dash_parts[1].isdigit():
            action_id = dash_parts[0]
            ts_suffix = int(dash_parts[1])
            result["timestamp_ms"] = ts_suffix

        if "/" in action_id:
            # v3.4 slash form — unambiguous
            kernel_part, action_part = action_id.split("/", 1)
            result["kernel_name"] = kernel_part
            result["action_name"] = action_part
            result["action_path"] = action_id
        else:
            # v3.1 dot form — best-effort parse (deprecated)
            result["action_path"] = action_id

    return result


# ---------------------------------------------------------------------------
# Validate
# ---------------------------------------------------------------------------

def validate_urn(urn):
    """Validate a CKP v3.1 URN. Returns dict with valid, errors, warnings."""
    parsed = parse_urn(urn)
    errors = []
    warnings = []

    if not parsed["valid"]:
        return {"valid": False, "errors": [parsed["error"]], "warnings": [], "urn": urn}

    entity_type = parsed["entity_type"]
    identifier = parsed["identifier"]
    version = parsed.get("version")

    # 1. Protocol prefix
    if not urn.startswith("ckp://"):
        errors.append("URN must start with ckp://")

    # 2. Fragment separator
    if "#" not in urn:
        errors.append("URN must contain # fragment separator")

    # 3. Entity type
    if entity_type not in ALL_TYPES:
        errors.append("Unknown entity type: %s (valid: %s)" % (
            entity_type, ", ".join(sorted(ALL_TYPES))))

    # 4. Continuant-specific rules
    if entity_type in CONTINUANT_TYPES:
        if entity_type == "Kernel":
            if not KERNEL_NAME_PATTERN.match(identifier):
                errors.append("Kernel name must be PascalCase.Dot.Notation: %s" % identifier)
            else:
                prefix = identifier.split(".")[0]
                if prefix not in VALID_PREFIXES:
                    warnings.append("Kernel prefix '%s' not in standard set: %s" % (
                        prefix, ", ".join(sorted(VALID_PREFIXES))))
            if not version:
                warnings.append("Kernel URN should include version (e.g. :v1.0)")

    # 5. Occurrent-specific rules
    if entity_type in OCCURRENT_TYPES:
        if entity_type in ("Process", "Deployment", "Transfer", "Check"):
            ts_match = TIMESTAMP_ID_PATTERN.match(identifier)
            if not ts_match:
                warnings.append("Occurrent identifier should contain timestamp-hash: %s" % identifier)
            else:
                ts = ts_match.group(2)
                if len(ts) < 10:
                    errors.append("Timestamp too short (need 10+ digits): %s" % ts)
        elif entity_type == "Task":
            if not TASK_ID_PATTERN.match(identifier):
                warnings.append("Task identifier should match T{NNN} pattern: %s" % identifier)
        elif entity_type == "Goal":
            if not GOAL_ID_PATTERN.match(identifier):
                warnings.append("Goal identifier should match G{NNN} pattern: %s" % identifier)
        elif entity_type == "Instance":
            if not INSTANCE_ID_PATTERN.match(identifier):
                warnings.append("Instance identifier should match i-{trace}-{ts} pattern: %s" % identifier)

    # 6. Version format
    if version:
        if not re.match(r'^v\d+\.\d+(\.\d+)?$', version):
            errors.append("Version must be vX.Y or vX.Y.Z: %s" % version)

    valid = len(errors) == 0
    return {"valid": valid, "errors": errors, "warnings": warnings,
            "urn": urn, "parsed": parsed}


# ---------------------------------------------------------------------------
# Build
# ---------------------------------------------------------------------------

def build_urn(entity_type, identifier, version=None):
    """Construct a CKP URN from components."""
    if entity_type not in ALL_TYPES:
        raise ValueError("Unknown entity type: %s" % entity_type)
    urn = "ckp://%s#%s" % (entity_type, identifier)
    if version:
        if not version.startswith("v"):
            version = "v" + version
        urn += ":" + version
    return urn


def build_kernel_urn(name, version="v1.0"):
    """Build a Kernel URN."""
    return build_urn("Kernel", name, version)


def build_process_urn(process_type, timestamp_ms, hash_suffix):
    """Build a Process URN with timestamp."""
    identifier = "%s-%d-%s" % (process_type, timestamp_ms, hash_suffix)
    return build_urn("Process", identifier)


def build_instance_urn(trace_id, timestamp):
    """Build an Instance URN."""
    identifier = "i-%s-%d" % (trace_id, timestamp)
    return build_urn("Instance", identifier)


def build_edge_urn(source, target, predicate, version=None):
    """Build an Edge Connection URN."""
    identifier = "Connection-%s-to-%s-%s" % (source, target, predicate)
    return build_urn("Edge", identifier, version)


def build_action_urn(kernel, action_name, timestamp_ms=None):
    """Build an Action invocation URN.

    v3.4: Uses slash separator between kernel and action name.
    Old:  ckp://Action#CK.Task.task.create-1773518402000  (ambiguous)
    New:  ckp://Action#CK.Task/task.create-1773518402000  (unambiguous)
    """
    identifier = "%s/%s" % (kernel, action_name)
    if timestamp_ms:
        identifier += "-%d" % timestamp_ms
    return build_urn("Action", identifier)


# ---------------------------------------------------------------------------
# Fleet validation
# ---------------------------------------------------------------------------

def validate_fleet(concepts_dir=None):
    """Validate all URNs in the fleet."""
    if concepts_dir is None:
        concepts_dir = os.path.join(
            os.path.dirname(os.path.abspath(__file__)), "..", "concepts")

    results = []
    for ck_yaml in sorted(glob.glob(os.path.join(concepts_dir, "*/conceptkernel.yaml"))):
        with open(ck_yaml) as f:
            ck = yaml.safe_load(f)

        folder = os.path.basename(os.path.dirname(ck_yaml))
        urn = ck.get("metadata", {}).get("urn", "")

        if not urn:
            results.append({"kernel": folder, "urn": "", "valid": False,
                           "errors": ["No URN defined"], "warnings": []})
            continue

        result = validate_urn(urn)
        result["kernel"] = folder

        # Cross-check: URN kernel name should match metadata.name
        parsed = result.get("parsed", {})
        meta_name = ck.get("metadata", {}).get("name", "")
        if parsed.get("kernel_name") and parsed["kernel_name"] != meta_name:
            result["warnings"].append(
                "URN identifier '%s' != metadata.name '%s'" % (
                    parsed["kernel_name"], meta_name))

        # Cross-check: kernel_id should be valid UUID
        kernel_id = ck.get("kernel_id", "")
        if kernel_id and not UUID_PATTERN.match(kernel_id):
            result["warnings"].append(
                "kernel_id is not valid UUID v4: %s" % kernel_id[:20])

        results.append(result)

    return results


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="CK URN — Parse, validate, and construct CKP v3.1 URNs")
    sub = parser.add_subparsers(dest="command")

    # validate
    val = sub.add_parser("validate", help="Validate a URN")
    val.add_argument("urn", help="URN to validate")

    # parse
    par = sub.add_parser("parse", help="Parse a URN into components")
    par.add_argument("urn", help="URN to parse")

    # build
    bld = sub.add_parser("build", help="Build a URN from components")
    bld.add_argument("--type", required=True, help="Entity type")
    bld.add_argument("--name", required=True, help="Identifier")
    bld.add_argument("--version", default=None, help="Version")

    # fleet
    sub.add_parser("fleet", help="Validate all fleet URNs")

    # types
    sub.add_parser("types", help="List all entity types")

    args = parser.parse_args()

    if args.command == "validate":
        result = validate_urn(args.urn)
        if result["valid"]:
            print("[PASS] %s" % args.urn)
        else:
            print("[FAIL] %s" % args.urn)
        for e in result["errors"]:
            print("  ERROR: %s" % e)
        for w in result["warnings"]:
            print("  WARN:  %s" % w)
        return 0 if result["valid"] else 1

    elif args.command == "parse":
        parsed = parse_urn(args.urn)
        print(json.dumps(parsed, indent=2))
        return 0 if parsed["valid"] else 1

    elif args.command == "build":
        urn = build_urn(args.type, args.name, args.version)
        print(urn)
        result = validate_urn(urn)
        if not result["valid"]:
            for e in result["errors"]:
                print("  ERROR: %s" % e)
        return 0

    elif args.command == "fleet":
        results = validate_fleet()
        passed = 0
        failed = 0
        for r in results:
            if r["valid"]:
                passed += 1
                symbol = "PASS"
            else:
                failed += 1
                symbol = "FAIL"
            warnings = r.get("warnings", [])
            if warnings:
                symbol += "*"
            print("  [%s] %-28s %s" % (symbol, r["kernel"], r["urn"]))
            for e in r.get("errors", []):
                print("         ERROR: %s" % e)
            for w in warnings:
                print("         WARN:  %s" % w)
        print()
        print("%d/%d passed" % (passed, len(results)))
        return 1 if failed else 0

    elif args.command == "types":
        print("Continuants (persist through time — BFO:0000002):")
        for t in sorted(CONTINUANT_TYPES):
            print("  ckp://%s#..." % t)
        print()
        print("Occurrents (unfold over time — BFO:0000003):")
        for t in sorted(OCCURRENT_TYPES):
            print("  ckp://%s#..." % t)
        return 0

    else:
        parser.print_help()
        return 1


if __name__ == "__main__":
    raise SystemExit(main() or 0)
