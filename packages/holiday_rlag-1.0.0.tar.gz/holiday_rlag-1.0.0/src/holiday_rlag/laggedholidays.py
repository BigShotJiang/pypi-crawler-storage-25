import datetime
import holidays


def _build_lag_column_name(base_column: str, lag_prefix: str, lag_suffix: str) -> str:
    normalized_prefix = lag_prefix.rstrip("_")
    normalized_suffix = lag_suffix.lstrip("_")
    return f"{base_column}{normalized_prefix}_{normalized_suffix}"


def fetch_holidays(
    date_start: datetime.date, 
    date_end: datetime.date, 
    country_code = "DE", 
    reverse_lag = 7,
    col_is_easter = "is_easter",
    col_is_christmas = "is_christmas",
    col_is_bank_holiday = "is_bank_holiday",
    col_lag_prefix = "_in_next_",
    col_lag_suffix = "_days"
) -> list[dict]:
    """
    Fetches holidays for a given date range and country, with optional reverse lagging.

    Parameters:
    - date_start (datetime.date): The start date of the range.
    - date_end (datetime.date): The end date of the range.
    - country_code (str): The country code for which to fetch holidays. Default is "DE".
    - reverse_lag (int): The number of days to look back for reverse lagging. Default is 7.
    - col_is_easter (str): The column name for Easter flag. Default is "is_easter".
    - col_is_christmas (str): The column name for Christmas flag. Default is "is_christmas".
    - col_is_bank_holiday (str): The column name for bank holiday flag. Default is "is_bank_holiday".
    - col_lag_prefix (str): The prefix for lag marker columns. Default is "_in_next_".
    - col_lag_suffix (str): The suffix for lag marker columns. Default is "_days".

    Returns:
    - list[dict]: A list of dictionaries containing holiday information and reverse lag markers.
      This is not a complete date list, so make sure to fill all dates you need and apply
      `fillna(0)` to the resulting DataFrame.
    """
    at_holidays = holidays.country_holidays(
        country = country_code,
        years = range(date_start.year, date_end.year+1)
    )

    hd = {}
    lag_columns = {
        col_is_easter: _build_lag_column_name(col_is_easter, col_lag_prefix, col_lag_suffix),
        col_is_christmas: _build_lag_column_name(col_is_christmas, col_lag_prefix, col_lag_suffix),
        col_is_bank_holiday: _build_lag_column_name(col_is_bank_holiday, col_lag_prefix, col_lag_suffix),
    }

    def ensure_entry(target_date: datetime.date) -> dict:
        if target_date not in hd:
            hd[target_date] = {"date": target_date}
        return hd[target_date]

    def update_lag_marker(entry: dict, column_name: str, lag_distance: int) -> None:
        current_value = entry.get(column_name)
        if current_value is None or lag_distance < current_value:
            entry[column_name] = lag_distance

    for date, name in sorted(at_holidays.items()):
        is_easter = 1 if "Easter" in name else 0
        is_christmas = 1 if "Christmas" in name or "Saint Stephen" in name else 0
        is_bank_holiday = 1
        holiday_flags = {
            col_is_easter: is_easter,
            col_is_christmas: is_christmas,
            col_is_bank_holiday: is_bank_holiday,
        }

        current_entry = ensure_entry(date)

        # set the holiday flags for the current date
        current_entry[col_is_easter] = is_easter
        current_entry[col_is_christmas] = is_christmas
        current_entry[col_is_bank_holiday] = is_bank_holiday

        # set holiday reverse lagging flags for the previous dates within the lagging window
        for i in range(1, reverse_lag+1):    
            earlier_date = date - datetime.timedelta(days=i)
            earlier_entry = ensure_entry(earlier_date)

            for holiday_column, holiday_flag in holiday_flags.items():
                if holiday_flag:
                    update_lag_marker(earlier_entry, lag_columns[holiday_column], i)
            
    # everything else will be filled with zeros by default when converting to a DataFrame
    return [entry for entry in hd.values()]

if __name__ == "__main__":

    hd = fetch_holidays(date_start = datetime.date(2023, 1, 1), date_end = datetime.date(2023, 12, 31), reverse_lag=3)
    import json
    print(json.dumps(hd, indent=4, default=str))
