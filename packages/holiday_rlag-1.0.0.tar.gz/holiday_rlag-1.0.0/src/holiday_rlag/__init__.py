def hello() -> str:
    return "Hello from holiday-rlag!"
