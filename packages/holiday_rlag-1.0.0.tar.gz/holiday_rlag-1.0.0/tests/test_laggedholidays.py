import datetime
import unittest
from unittest.mock import patch

from holiday_rlag.laggedholidays import fetch_holidays


class FetchHolidaysTests(unittest.TestCase):
    @patch("holiday_rlag.laggedholidays.holidays.country_holidays")
    def test_reverse_lag_uses_single_marker_column_per_holiday_type(self, mock_country_holidays):
        mock_country_holidays.return_value = {
            datetime.date(2024, 4, 1): "Easter Monday",
            datetime.date(2024, 5, 1): "Labour Day",
        }

        rows = fetch_holidays(
            date_start=datetime.date(2024, 3, 29),
            date_end=datetime.date(2024, 5, 2),
            reverse_lag=3,
        )

        rows_by_date = {row["date"]: row for row in rows}
        pre_easter_row = rows_by_date[datetime.date(2024, 3, 30)]

        self.assertEqual(pre_easter_row["is_easter_in_next_days"], 2)
        self.assertEqual(pre_easter_row["is_bank_holiday_in_next_days"], 2)
        self.assertNotIn("is_easter_in_next_1_days", pre_easter_row)
        self.assertNotIn("is_bank_holiday_in_next_1_days", pre_easter_row)

    @patch("holiday_rlag.laggedholidays.holidays.country_holidays")
    def test_reverse_lag_keeps_nearest_upcoming_holiday_distance(self, mock_country_holidays):
        mock_country_holidays.return_value = {
            datetime.date(2024, 4, 1): "Holiday A",
            datetime.date(2024, 4, 2): "Holiday B",
        }

        rows = fetch_holidays(
            date_start=datetime.date(2024, 3, 30),
            date_end=datetime.date(2024, 4, 2),
            reverse_lag=3,
        )

        rows_by_date = {row["date"]: row for row in rows}

        self.assertEqual(rows_by_date[datetime.date(2024, 3, 31)]["is_bank_holiday_in_next_days"], 1)
        self.assertEqual(rows_by_date[datetime.date(2024, 3, 30)]["is_bank_holiday_in_next_days"], 2)


if __name__ == "__main__":
    unittest.main()