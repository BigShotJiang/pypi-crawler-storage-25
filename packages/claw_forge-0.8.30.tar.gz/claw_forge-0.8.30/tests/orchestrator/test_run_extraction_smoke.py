"""Smoke tests for the ``run`` command's post-extraction shape.

After PR 7 of the cli.py decomposition, the ``run`` command and its
~2400 lines of dispatcher / task-handler / agent-prep code live under
``claw_forge/orchestrator/``.  These tests pin the public shape that
existing tests rely on so future refactors don't accidentally break the
back-compat shim.
"""

from __future__ import annotations

import pytest
from typer.testing import CliRunner

# Eagerly import claw_forge.cli at collection time so its transitive chain
# (boundaries → agent.permissions → claude_agent_sdk.types) resolves BEFORE
# any other test file's collection-time ``sys.modules`` stubs can shadow
# ``claude_agent_sdk`` with an empty module — see test_release_coverage.py.
from claw_forge import cli as _cli  # noqa: F401


def test_run_command_appears_in_main_cli_help() -> None:
    """``claw-forge --help`` still lists ``run`` after the move."""
    from claw_forge.cli import app

    runner = CliRunner()
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "run" in result.stdout


def test_run_command_help_unchanged(monkeypatch: pytest.MonkeyPatch) -> None:
    """``run --help`` lists every flag it had before the extraction.

    Forces ``COLUMNS=240`` so Typer's Rich-backed renderer doesn't wrap
    long flag names across lines (which would defeat the substring
    assertion).
    """
    monkeypatch.setenv("COLUMNS", "240")
    from claw_forge.cli import app

    runner = CliRunner()
    result = runner.invoke(app, ["run", "--help"])
    assert result.exit_code == 0
    for flag in (
        "--config",
        "--project",
        "--task",
        "--model",
        "--plan-model",
        "--concurrency",
        "--yolo",
        "--dry-run",
        "--edit-mode",
        "--loop-detect-threshold",
        "--verify-on-exit",
        "--push-after-merge",
        "--github-mode",
        "--adversarial-review",
        "--reset-threshold",
    ):
        assert flag in result.stdout, f"missing flag {flag!r}"


def test_run_context_dataclass_importable() -> None:
    """``RunContext`` is exposed from ``orchestrator.task_handler``."""
    from claw_forge.orchestrator.task_handler import RunContext

    assert RunContext.__name__ == "RunContext"
    # Spot-check a few required fields so a future field-rename trips the gate.
    annotations = RunContext.__annotations__
    for field_name in (
        "state_base",
        "session_id",
        "git_ops",
        "git_enabled",
        "active_worktrees",
        "pending_merge_retries",
    ):
        assert field_name in annotations, f"missing RunContext field {field_name}"


def test_cli_shim_reexports_run_helpers() -> None:
    """The four run helpers stay importable from ``claw_forge.cli``.

    test_cli_merge_gating.py imports ``_set_merged_after_merge``,
    test_cli_file_claims.py imports ``_try_claim_files``,
    test_resolve_sdk_credentials.py imports ``_resolve_sdk_credentials``,
    tests/git/test_dispatcher_git.py imports ``_create_and_sync_worktree``.
    """
    from claw_forge.cli import (
        _create_and_sync_worktree,
        _resolve_sdk_credentials,
        _set_merged_after_merge,
        _try_claim_files,
    )

    assert callable(_create_and_sync_worktree)
    assert callable(_resolve_sdk_credentials)
    assert callable(_set_merged_after_merge)
    assert callable(_try_claim_files)


def test_run_command_registered_via_subapp_pattern() -> None:
    """``run`` is registered through ``app.command``-as-function (Pattern A)."""
    from claw_forge.cli import app
    from claw_forge.orchestrator.run_cli import run as run_cmd

    registered = {cmd.name for cmd in app.registered_commands}
    assert "run" in registered

    # The function lives in orchestrator.run_cli, not cli.
    assert run_cmd.__module__ == "claw_forge.orchestrator.run_cli"


def test_checkpointing_module_importable() -> None:
    """``periodic_checkpoint_loop`` is exposed from ``orchestrator.checkpointing``."""
    from claw_forge.orchestrator.checkpointing import periodic_checkpoint_loop

    assert callable(periodic_checkpoint_loop)
