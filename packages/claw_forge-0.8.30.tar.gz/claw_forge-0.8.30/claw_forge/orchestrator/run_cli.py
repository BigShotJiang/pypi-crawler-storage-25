"""Typer command for ``claw-forge run`` — the dispatcher entrypoint.

The bulk of run's behaviour lives in:

* :mod:`claw_forge.orchestrator.task_handler` — per-task coroutine +
  agent prep helpers + ``RunContext`` dataclass
* :mod:`claw_forge.orchestrator.checkpointing` — periodic auto-checkpoint
  loop

This module owns argument parsing, all setup (config load, state-service
auto-start, GitOps construction, project guards), the signal handler
installation (closing over the local ``_active_worktrees`` dict that
also lives on the ``RunContext``), the pause/resume dispatcher wave
loop, and finalisation (GitHub mode, summary print).
"""

from __future__ import annotations

import asyncio
import functools
import json
import os
import shutil
from pathlib import Path
from typing import TYPE_CHECKING, Any

import httpx
import typer

from claw_forge import __version__
from claw_forge._console import console
from claw_forge.config import _load_config
from claw_forge.orchestrator.task_handler import (
    RunContext,
    task_handler,
)
from claw_forge.pool.model_resolver import resolve_model
from claw_forge.pool.providers.registry import load_configs_from_yaml
from claw_forge.state.client import (
    _decorate_resumable,
    _ensure_state_service,
    _task_dict_to_node,
)

if TYPE_CHECKING:
    from claw_forge.state.scheduler import TaskNode



def run(
    config: str = typer.Option(
        "claw-forge.yaml", "--config", "-c",
        help="Path to claw-forge.yaml config file.",
    ),
    project: str = typer.Option(".", "--project", "-p", help="Project directory."),
    task: str = typer.Option(
        "coding", "--task", "-t",
        help="Agent task type: coding | testing | review.",
    ),
    model: str = typer.Option(
        "claude-sonnet-4-6", "--model", "-m",
        help=(
            "Model to use. Supported formats:\n"
            "  claude-sonnet-4-6             bare model (pool picks provider)\n"
            "  anthropic-proxy-1/claude-opus-4-6    pin to specific provider\n"
            "  sonnet                               alias from model_aliases in config\n"
            "Defaults to the value in claw-forge.yaml."
        ),
    ),
    plan_model: str | None = typer.Option(
        None, "--plan-model",
        help=(
            "Model for the planning phase (spec decomposition).\n"
            "Defaults to --model when not set.\n"
            "  claude-opus-4-6                      bare model\n"
            "  anthropic-proxy-1/claude-opus-4-6    pin to provider\n"
            "  opus                                 alias from config\n"
            "Precedence: --plan-model flag → config agent.plan_model → --model."
        ),
    ),
    concurrency: int = typer.Option(
        5, "--concurrency", "-n",
        help="Max parallel coding agents (1–10). Higher = faster but more API spend.",
    ),
    yolo: bool = typer.Option(
        False, "--yolo/--no-yolo",
        help=(
            "YOLO mode: skip human-input gates, max concurrency, "
            "aggressive retry on errors, autonomous main-worktree "
            "cleanup (handle_uncommitted_at_startup defaults to "
            "``smart``).  Explicit config values still win."
        ),
    ),
    dry_run: bool = typer.Option(
        False, "--dry-run",
        help="Print tasks in dependency order without executing.",
    ),
    edit_mode: str = typer.Option(
        "str_replace", "--edit-mode",
        help=(
            "Edit tool mode for agent file operations.\n"
            "  str_replace: current default (exact text matching)\n"
            "  hashline: content-addressed line tagging (better for weak models)\n"
            "[default: str_replace]"
        ),
    ),
    loop_detect_threshold: int = typer.Option(
        5,
        "--loop-detect-threshold",
        help=(
            "Max edits to a single file before injecting a 'reconsider' prompt (0=disable). "
            "When --edit-mode hashline is active, threshold is auto-raised by 3 "
            "(e.g. default 5 → 8). "
            "[default: 5]"
        ),
    ),
    verify_on_exit: bool = typer.Option(
        True, "--verify-on-exit/--no-verify-on-exit",
        help=(
            "Inject a pre-completion verification checklist before the agent exits.\n"
            "Forces re-reading the task spec, running tests, and confirming correctness.\n"
            "Disable for fast iteration / debugging. [default: enabled]"
        ),
    ),
    push_after_merge: bool = typer.Option(
        False, "--push-after-merge/--no-push-after-merge",
        help=(
            "After every successful squash-merge into the target branch, "
            "push the target branch to its remote. Skipped silently when "
            "the configured remote doesn't exist. No-op merges (content "
            "already on target) are skipped to save a round-trip. "
            "[default: disabled]"
        ),
    ),
    push_remote: str = typer.Option(
        "origin", "--push-remote",
        help=(
            "Remote name to push to when --push-after-merge is set. "
            "Default: origin."
        ),
    ),
    github_mode: str | None = typer.Option(
        None, "--github-mode",
        help=(
            "Read spec from a GitHub issue. Format: owner/repo#number.\n"
            "Posts progress comments to the issue and opens a draft PR when complete.\n"
            "Requires the GITHUB_TOKEN environment variable."
        ),
    ),
    adversarial_review: bool = typer.Option(
        False, "--adversarial-review/--no-adversarial-review",
        help=(
            "Enable adversarial review mode for the reviewer plugin.\n"
            "Uses a GAN-inspired adversarial evaluator that grades code on\n"
            "correctness, robustness, and maintainability. [default: disabled]"
        ),
    ),
    reset_threshold: int = typer.Option(
        80, "--reset-threshold",
        help=(
            "Number of tool calls before triggering a context reset.\n"
            "Lower values keep working memory fresh but cost more tokens.\n"
            "[default: 80]"
        ),
    ),
) -> None:
    """Run agents on a project until all features pass.

    Examples:

        # Run with defaults (reads claw-forge.yaml)
        claw-forge run

        # Run with 3 parallel agents
        claw-forge run --concurrency 3

        # Run with a specific model
        claw-forge run --model claude-opus-4-6 --concurrency 2

        # YOLO mode — no human-input gates, max speed
        claw-forge run --yolo

        # Dry-run — see what would execute
        claw-forge run --dry-run
    """

    from claw_forge.orchestrator.dispatcher import Dispatcher

    def _task_dicts_to_nodes(dicts: list[dict[str, Any]]) -> list[TaskNode]:
        """Convert task dicts to TaskNodes, marking resumable ones from git state."""
        nodes = [_task_dict_to_node(t) for t in dicts]
        # Decorate resumable based on whether each task's feature branch already
        # has committed work.  Closure refs are resolved at call-time, so the
        # git_* variables defined below in this same ``run`` function are bound
        # by the time this helper is invoked.
        if git_enabled:
            _decorate_resumable(
                nodes,
                project_path,
                _default_branch,
                git_branch_prefix,
                enabled=git_prefer_resumable,
                stale_threshold=git_resume_stale_threshold,
            )
        return nodes

    # Resolve config path: prefer project-relative if config is a bare filename
    _config_path = Path(config)
    if not _config_path.is_absolute() and not _config_path.exists():
        _project_config = Path(project) / config
        if _project_config.exists():
            config = str(_project_config)
    # Validate edit_mode
    _valid_edit_modes = ("str_replace", "hashline")
    if edit_mode not in _valid_edit_modes:
        console.print(
            f"[red]Invalid --edit-mode '{edit_mode}'. "
            f"Choose from: {', '.join(_valid_edit_modes)}[/red]"
        )
        raise typer.Exit(1) from None

    # Allow config file to set edit_mode (CLI flag takes priority)
    cfg = _load_config(config)
    _config_edit_mode = cfg.get("agent", {}).get("edit_mode", "str_replace")
    if edit_mode == "str_replace" and _config_edit_mode == "hashline":
        edit_mode = _config_edit_mode

    # Allow config to set loop_detect_threshold (CLI flag takes priority)
    _config_threshold = cfg.get("agent", {}).get("loop_detect_threshold", 5)
    if loop_detect_threshold == 5 and _config_threshold != 5:
        loop_detect_threshold = int(_config_threshold)

    if loop_detect_threshold < 0:
        console.print("[red]--loop-detect-threshold must be ≥ 0[/red]")
        raise typer.Exit(1) from None

    # verify_on_exit: CLI flag takes priority; config is fallback for the True default
    _config_verify = cfg.get("agent", {}).get("verify_on_exit", True)
    effective_verify_on_exit: bool = verify_on_exit and bool(_config_verify)

    # ── Agent isolation (v0.8.18 sandbox / v0.8.19 container) ──────────
    # ``agent.isolation: sandbox`` (default, v0.8.21) uses the OS-level
    # filesystem jail (sandbox-exec on macOS; bwrap on Linux v0.8.21+).
    # ``container`` spawns each agent in a Docker/Podman container with
    # the worktree mounted at ``/workspace`` and the parent project
    # absent from the container's filesystem namespace.  Container mode
    # requires ``agent.container.image`` to be set to a locally-built
    # image containing the ``claude`` CLI — see docs/container-isolation.md
    # for the Dockerfile template.
    #
    # ``process`` is accepted as a deprecated alias for ``sandbox``
    # (v0.8.18 → v0.8.20 used ``process`` as the value name; v0.8.21
    # renamed to ``sandbox`` for clarity).  Configs from older versions
    # keep working without modification.
    _agent_cfg = cfg.get("agent", {})
    _isolation_raw: str = _agent_cfg.get("isolation", "sandbox")
    if _isolation_raw == "process":
        _isolation_raw = "sandbox"  # legacy alias resolved here
    agent_isolation: str = _isolation_raw
    _container_cfg = _agent_cfg.get("container", {})
    container_runtime_pref: str = _container_cfg.get("runtime", "auto")
    container_image: str = _container_cfg.get("image", "")
    container_extra_mounts: list[str] = list(
        _container_cfg.get("extra_mounts", []) or [],
    )
    container_extra_env: list[str] = list(
        _container_cfg.get("extra_env", []) or [],
    )
    container_pull_if_missing: bool = bool(
        _container_cfg.get("pull_if_missing", False),
    )
    if agent_isolation not in ("sandbox", "container"):
        console.print(
            f"[red]✗ agent.isolation: {agent_isolation!r} is not a "
            "valid value.  Use ``sandbox`` (default — OS-level jail) "
            "or ``container`` (opt-in — Docker/Podman per-agent "
            "container).  ``process`` is accepted as a legacy alias "
            "for ``sandbox``.[/red]"
        )
        raise typer.Exit(1) from None
    if agent_isolation == "container" and not container_image:
        console.print(
            "[red]✗ agent.isolation: container requires "
            "agent.container.image to be set in claw-forge.yaml.  "
            "See docs/container-isolation.md for the Dockerfile "
            "template and config example.[/red]"
        )
        raise typer.Exit(1) from None

    # Deprecated: ``agent.auto_push`` was a per-turn Stop-hook push that
    # created a remote branch per task.  Replaced by ``git.push_after_merge``
    # which only pushes the target branch after a successful merge.
    if cfg.get("agent", {}).get("auto_push"):
        console.print(
            "[yellow]warning: agent.auto_push is deprecated and ignored; "
            "use git.push_after_merge: true instead.[/yellow]",
        )

    # push_after_merge: CLI flag takes priority over config.
    # Config form: ``git.push_after_merge: true`` or ``"upstream"``.
    # CLI form: ``--push-after-merge --push-remote upstream``.
    effective_push_after_merge: bool | str
    if push_after_merge:
        effective_push_after_merge = (
            push_remote if push_remote != "origin" else True
        )
    else:
        _config_pam = cfg.get("git", {}).get("push_after_merge", False)
        if isinstance(_config_pam, str) and _config_pam:
            effective_push_after_merge = _config_pam
        else:
            effective_push_after_merge = bool(_config_pam)

    resolved = resolve_model(model, cfg)
    if resolved.alias_resolved:
        console.print(f"[dim]Model alias '{model}' → {resolved.model_id}[/dim]")
    if resolved.provider_hint:
        console.print(f"[dim]Provider pinned: {resolved.provider_hint}[/dim]")
    model = resolved.model_id

    # Resolve plan_model: CLI flag → config agent.plan_model → fallback to model
    effective_plan_model: str = model
    if plan_model is not None:
        plan_resolved = resolve_model(plan_model, cfg)
        if plan_resolved.alias_resolved:
            console.print(
                f"[dim]Plan model alias '{plan_model}' → {plan_resolved.model_id}[/dim]"
            )
        effective_plan_model = plan_resolved.model_id
    else:
        _config_plan_model = cfg.get("agent", {}).get("plan_model")
        if _config_plan_model:
            plan_resolved = resolve_model(str(_config_plan_model), cfg)
            if plan_resolved.alias_resolved:
                console.print(
                    f"[dim]Plan model from config: '{_config_plan_model}'"
                    f" → {plan_resolved.model_id}[/dim]"
                )
            effective_plan_model = plan_resolved.model_id

    console.print(f"[bold]claw-forge[/bold] v{__version__}")
    console.print(f"Project: {project}")
    console.print(f"Task: {task}")
    console.print(f"Model: {model}")
    if effective_plan_model != model:
        console.print(f"Plan model: {effective_plan_model}")
    if edit_mode == "hashline":
        console.print(f"Edit mode: [cyan]{edit_mode}[/cyan]  (content-addressed line tagging)")
    console.print(f"Providers: {len(cfg.get('providers', {}))}")
    if shutil.which("claude"):
        console.print("Executor:  claude CLI (autonomous agent — writes files) ✅")
    else:
        console.print(
            "[yellow]Executor:  API-only mode (no claude CLI in PATH — "
            "LLM responses only, files NOT written)[/yellow]"
        )
        console.print(
            "[dim]  → Install claude CLI for full autonomous coding: "
            "https://claude.ai/download[/dim]"
        )

    if yolo:
        cpu_count = max(1, os.cpu_count() or 4)
        console.print(
            f"[bold yellow]⚠️  YOLO MODE: Human approval skipped, max concurrency ({cpu_count}), aggressive retry, autonomous main-worktree cleanup[/bold yellow]"  # noqa: E501
        )

    # Resolve project path and create .claw-forge directory
    project_path = Path(project).resolve()

    # Guard: prevent running agents against the claw-forge source tree itself.
    # Detect by checking whether project_path contains claw_forge/cli.py — if so,
    # the user is pointing the orchestrator at its own repo, which would cause agents
    # to commit generated app code into claw-forge.
    _self_marker = Path(__file__).resolve()
    # __file__ here is .../claw_forge/orchestrator/run_cli.py — the source root
    # is two parents up (orchestrator/ → claw_forge/ → repo-root).
    _source_root = _self_marker.parent.parent.parent
    if (_source_root == project_path) or project_path in _self_marker.parents:
        console.print(
            "[bold red]ERROR:[/bold red] The project path resolves to the claw-forge "
            "source directory itself.\n"
            "Running agents here would commit generated code into the claw-forge repo.\n"
            f"  project_path : {project_path}\n"
            f"  claw-forge   : {_source_root}\n\n"
            "Point --project at your target application directory instead."
        )
        raise SystemExit(1)

    claw_forge_dir = project_path / ".claw-forge"
    claw_forge_dir.mkdir(parents=True, exist_ok=True)

    # ── GitHub mode: validate + fetch issue spec ──────────────────────────
    from claw_forge.github.models import GitHubContext as _GitHubContext

    _github_ctx: _GitHubContext | None = None
    _github_spec_path: Path | None = None  # temp spec file written from issue

    if github_mode:
        import tempfile

        from claw_forge.github import GitHubClient as _GitHubClient
        from claw_forge.github.models import IssueSpec as _IssueSpec

        # Validate format: owner/repo#number
        try:
            if "/" not in github_mode or "#" not in github_mode:
                raise ValueError()
            _repo_part, _issue_part = github_mode.rsplit("#", 1)
            _owner, _repo_name = _repo_part.split("/", 1)
            _issue_number = int(_issue_part)
        except (ValueError, IndexError):
            console.print(
                f"[red]Invalid --github-mode format: {github_mode!r}[/red]\n"
                "[yellow]Expected: owner/repo#number "
                "(e.g. clawinfra/claw-forge#15)[/yellow]"
            )
            raise typer.Exit(1) from None

        _gh_token = os.environ.get("GITHUB_TOKEN")
        if not _gh_token:
            console.print(
                "[red]GITHUB_TOKEN environment variable is not set.[/red]\n"
                "[yellow]Required for --github-mode. "
                "In GitHub Actions this is auto-provided.[/yellow]"
            )
            raise typer.Exit(1) from None

        console.print(
            f"[dim]Fetching issue {_owner}/{_repo_name}#{_issue_number}…[/dim]"
        )

        async def _fetch_issue() -> _IssueSpec:
            async with _GitHubClient(_gh_token) as _gh:
                _data = await _gh.read_issue(_owner, _repo_name, _issue_number)
            return _IssueSpec(
                title=_data["title"],
                description=_data["body"],
                comments=_data["comments"],
                author=_data["user"]["login"],
                number=_data["number"],
                labels=_data["labels"],
            )

        _issue_spec: _IssueSpec = asyncio.run(_fetch_issue())

        _branch_name = f"feat/github-{_issue_number}"
        _github_ctx = _GitHubContext(
            owner=_owner,
            repo=_repo_name,
            issue_number=_issue_number,
            token=_gh_token,
            branch_name=_branch_name,
        )

        # Write spec to a temp XML file so the existing plan→run pipeline
        # can use it unchanged via `claw-forge plan <spec>`.
        _spec_content = _issue_spec.to_xml()
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".xml", delete=False, dir=str(claw_forge_dir),
            prefix=f"github-issue-{_issue_number}-",
        ) as _tmp:
            _tmp.write(_spec_content)
            _github_spec_path = Path(_tmp.name)

        console.print(
            f"[green]✓ Loaded issue spec:[/green] {_issue_spec.title}"
        )
        console.print(
            f"[dim]  Spec written to: {_github_spec_path}[/dim]"
        )

    # Auto-start state service (project-aware: restarts if serving a different project)
    _state_port = cfg.get("state", {}).get("port", 8420)
    _state_port = _ensure_state_service(project_path, _state_port)
    _state_base = f"http://127.0.0.1:{_state_port}"
    console.print(f"[dim]State service on port {_state_port}[/dim]")

    # Set up git tracking
    from claw_forge.git import GitOps
    from claw_forge.git import detect_default_branch as _detect_default_branch

    git_cfg = cfg.get("git", {})
    _default_branch = git_cfg.get("target_branch") or _detect_default_branch(project_path)
    git_enabled = git_cfg.get("enabled", True)
    git_merge_strategy = git_cfg.get("merge_strategy", "auto")
    git_branch_prefix = git_cfg.get("branch_prefix", "feat")
    git_commit_on_boundary = git_cfg.get("commit_on_plugin_boundary", True)
    git_auto_checkpoint_secs: int = int(
        git_cfg.get("auto_checkpoint_interval_seconds", 300)
    )
    # Resume-preference: prefer tasks with committed work on a feature branch
    # over fresh pending tasks (within the same priority tier).  See CLAUDE.md
    # → "Key Conventions" → "Resume preference".
    git_prefer_resumable: bool = bool(git_cfg.get("prefer_resumable", True))
    git_resume_stale_threshold: int = int(
        git_cfg.get("resume_stale_threshold", 50)
    )
    # Autonomous merge-conflict recovery: cap on how many times a single task
    # can re-pend after a squash failure or re-dispatch after a sync conflict.
    # See docs/superpowers/specs/2026-05-10-autonomous-merge-recovery.md.
    # 0 disables the auto-recovery loop entirely (legacy preserve-and-warn).
    git_merge_retry_attempts: int = max(
        0, int(git_cfg.get("merge_retry_attempts", 3)),
    )
    # Smart-mode worktree cleanup: see docs/commands.md → ``claw-forge worktrees``.
    # ``smart`` (default) walks every worktree dir at startup and decides
    # preserve / salvage / remove per-task using the DB state, preventing
    # stale dirs from accumulating across runs.  ``manual`` falls back to
    # the legacy ``orphans_reset > 0`` gate that only fires after an
    # interrupted run.  ``llm_conflict_proposals`` (default ``true``)
    # drafts ``CONFLICT_PROPOSAL.md`` inside the preserved worktree when a
    # smart-mode salvage hits an unresolvable conflict — advisory only,
    # never lands on main.  Set to ``false`` to disable the agent call.
    git_cleanup_mode: str = git_cfg.get("cleanup_orphan_worktrees", "smart")
    git_llm_proposals: bool = bool(git_cfg.get("llm_conflict_proposals", True))
    git_advisor_model: str | None = git_cfg.get("llm_conflict_advisor_model")
    # Uncommitted-state handling at run startup.  Architectural rule: the
    # main worktree must be clean (everything committed to HEAD) before any
    # agent worktree branches off — otherwise the agent's tracked work later
    # collides with main's untracked / unstaged state at squash-merge time.
    # ``smart`` (autonomous): archive untracked files with provenance, stash
    # dirty-tracked state — both reversible, never aborts.  ``abort``: refuse
    # to start whenever any uncommitted state exists (user wants fail-fast).
    # ``ignore``: legacy behaviour, handler doesn't run.
    #
    # ``--yolo`` flips the default from ``ignore`` to ``smart`` so unattended
    # runs aren't blocked by stale main-worktree state.  Explicit config
    # values still win — yolo only changes the default.  Project-wide default
    # flips to ``smart`` next minor regardless of yolo.
    git_handle_uncommitted: str = git_cfg.get(
        "handle_uncommitted_at_startup",
        "smart" if yolo else "ignore",
    )
    git_ops = GitOps(
        project_dir=project_path,
        enabled=git_enabled,
        push_after_merge=effective_push_after_merge,
    )

    agent_cfg = cfg.get("agent", {})
    max_subagents = agent_cfg.get("max_subagents_per_task", 5)

    # adversarial_review: CLI flag takes priority; config fallback
    _config_adversarial = agent_cfg.get("adversarial", False)
    if not adversarial_review and _config_adversarial:
        adversarial_review = bool(_config_adversarial)
    agent_cfg["adversarial"] = adversarial_review

    # reset_threshold: CLI flag takes priority; config fallback
    _config_reset_threshold = agent_cfg.get("context_reset_threshold", 80)
    if reset_threshold == 80 and _config_reset_threshold != 80:
        reset_threshold = int(_config_reset_threshold)
    agent_cfg["context_reset_threshold"] = reset_threshold

    async def main() -> None:
        # Bootstrap session + tasks via state service HTTP API
        try:
            async with httpx.AsyncClient() as init_client:
                resp = await init_client.post(
                    f"{_state_base}/sessions/init",
                    json={"project_path": str(project_path)},
                    timeout=10,
                )
                resp.raise_for_status()
                init_data = resp.json()
        except (httpx.ConnectError, httpx.HTTPStatusError) as exc:
            console.print(
                f"[red]Cannot reach state service at {_state_base}: {exc}[/red]"
            )
            return

        session_id: str = init_data["session_id"]

        if init_data.get("tasks_adopted", 0):
            console.print(
                f"[green]Adopted {init_data['tasks_adopted']} orphaned task(s) "
                "into current session (recovered after DB repair)[/green]"
            )
        if init_data.get("orphans_reset", 0):
            console.print(
                f"[yellow]Reset {init_data['orphans_reset']} orphaned task(s) "
                "from previous interrupted run[/yellow]"
            )

        # ── Uncommitted-state handling at startup ───────────────────────
        # Hard gate: no agent worktrees are created until the main worktree
        # is clean (everything committed to HEAD).  ``smart`` autonomously
        # archives untracked + stashes dirty-tracked, both reversible.
        # ``abort`` refuses to start whenever any uncommitted state exists.
        # Default ``ignore`` preserves legacy behaviour.
        if git_enabled and git_handle_uncommitted == "abort":
            from claw_forge.git.cleanup import (
                _collect_dirty_tracked_files,
                _collect_untracked_files,
            )
            _untracked = _collect_untracked_files(project_path)
            _dirty = _collect_dirty_tracked_files(project_path)
            if _untracked or _dirty:
                console.print(
                    f"[red]✗ Main worktree has uncommitted state "
                    f"(untracked={len(_untracked)}, dirty-tracked={len(_dirty)}) "
                    "— aborting (git.handle_uncommitted_at_startup=abort).[/red]"
                )
                for _p in (_untracked + _dirty)[:20]:
                    console.print(f"  [dim]- {_p}[/dim]")
                console.print(
                    "[yellow]Resolve with `git add` + `git commit`, "
                    "`git stash`, or `rm`, then re-run.  Switch to "
                    "`handle_uncommitted_at_startup: smart` to let claw-forge "
                    "handle it autonomously.[/yellow]"
                )
                raise typer.Exit(1) from None
        elif git_enabled and git_handle_uncommitted == "smart":
            from claw_forge.git.cleanup import (
                smart_handle_uncommitted_in_project_dir,
            )
            _ucm = smart_handle_uncommitted_in_project_dir(
                project_dir=project_path,
                tasks=init_data.get("tasks") or [],
            )
            if _ucm.archived:
                console.print(
                    f"[yellow]Archived {len(_ucm.archived)} untracked "
                    f"file(s) → {_ucm.archive_root}[/yellow]"
                )
                for _p in _ucm.archived[:10]:
                    console.print(f"  [dim]- {_p}[/dim]")
                console.print(
                    "[dim]Recover with: cp -r .claw-forge/orphans/.../ ./[/dim]"
                )
            if _ucm.stashed:
                console.print(
                    f"[yellow]Stashed {len(_ucm.stashed)} dirty-tracked "
                    f"file(s) — stash message: {_ucm.stash_message}[/yellow]"
                )
                for _p in _ucm.stashed[:10]:
                    console.print(f"  [dim]- {_p}[/dim]")
                console.print(
                    "[dim]Recover with: git stash list  →  "
                    "git stash pop[/dim]"
                )

        # ── Boot baseline (v0.8.17 snapshot-rollback) ────────────────────
        # Capture project_path's pre-run state as a stash so the per-task
        # rollback path can enforce "main is HEAD-clean for the run's
        # lifetime" without destroying operator dirt.  Runs AFTER smart-
        # cleanup so the stash only captures dirt smart-cleanup couldn't
        # archive.  Returns ``None`` when main is already clean, which
        # is the healthy default.
        #
        # Skipped when ``handle_uncommitted_at_startup: ignore`` —
        # operators who opted out of cleanup also opted out of any
        # automatic state management of main.  Their dirt stays as-is
        # and the snapshot-rollback invariant doesn't apply for that
        # run; per-task post-rollback degrades to "stash anything dirty
        # post-agent" without a baseline to restore to.
        _boot_baseline_marker: str | None = None
        if git_enabled and git_handle_uncommitted != "ignore":
            from claw_forge.git.leak_watch import capture_boot_baseline
            _boot_baseline_marker = capture_boot_baseline(project_path)
            if _boot_baseline_marker:
                console.print(
                    f"[yellow]Captured boot baseline as "
                    f"{_boot_baseline_marker} — main is now HEAD-clean for "
                    "the run.  Recover pre-run state after the run with: "
                    f"git stash apply <ref>[/yellow]"
                )

        # Salvage / cleanup orphan worktrees.  Three exclusive paths:
        #
        # 1. ``smart`` mode + ``merge_strategy: auto``: walk every worktree
        #    dir, look the corresponding task up by slug, and per-row
        #    preserve / salvage / remove based on task status.  Replaces
        #    both the orphans_reset gate AND the legacy prune_worktrees
        #    sweep — smart mode owns its own cleanup so we skip the
        #    unconditional sweep below.
        # 2. ``manual`` mode (default) + ``merge_strategy: auto``: legacy
        #    behaviour, only fires when orphans_reset > 0 (interrupted-run
        #    recovery).  Followed by the prune_worktrees sweep.
        # 3. ``merge_strategy: manual``: scan + report only, never auto-merge.
        _target_branch = _default_branch
        if (
            git_enabled
            and git_cleanup_mode == "smart"
            and git_merge_strategy == "auto"
        ):
            from claw_forge.git.cleanup import (
                ConflictAdvisor,
                smart_cleanup_worktrees,
            )

            advisor: ConflictAdvisor | None = None
            if git_llm_proposals:
                from claw_forge.git.conflict_advisor import (
                    draft_conflict_proposal,
                )

                _model = git_advisor_model

                def _advisor_impl(
                    project_dir: Path,
                    worktree_path: Path,
                    branch: str,
                    target: str,
                    task: dict[str, Any] | None,
                ) -> Path | None:
                    return draft_conflict_proposal(
                        project_dir, worktree_path, branch, target, task,
                        model=_model,
                    )

                advisor = _advisor_impl

            _outcomes = smart_cleanup_worktrees(
                project_path,
                init_data.get("tasks", []),
                prefix=git_branch_prefix,
                target=_target_branch,
                advisor=advisor,
            )
            _salvaged = [o for o in _outcomes if o.action == "salvage" and o.success]
            _removed = [o for o in _outcomes if o.action == "remove" and o.success]
            _conflicts = [o for o in _outcomes if o.action == "salvage" and not o.success]
            if _salvaged:
                console.print(
                    f"[green]Salvage-merged {len(_salvaged)} worktree branch(es) "
                    f"→ {_target_branch}:[/green]"
                )
                for o in _salvaged:
                    console.print(f"  • {o.branch} → {o.commit_hash or 'merged'}")
            if _removed:
                console.print(
                    f"[dim]Removed {len(_removed)} empty worktree dir(s).[/dim]"
                )
            if _conflicts:
                console.print(
                    f"\n[yellow]Preserved {len(_conflicts)} worktree(s) "
                    f"with merge conflicts (manual resolution required):[/yellow]"
                )
                for o in _conflicts:
                    console.print(f"  [bold]{o.branch}[/bold]")
                    if o.proposal_path:
                        console.print(
                            f"    [cyan]Proposed resolution:[/cyan] {o.proposal_path}"
                        )
                console.print()
        elif git_enabled and init_data.get("orphans_reset", 0):
            # Legacy paths (manual cleanup_mode or merge_strategy=manual).
            if git_merge_strategy == "auto":
                from claw_forge.git.branching import merge_orphaned_worktrees

                salvaged = merge_orphaned_worktrees(
                    project_path,
                    prefix=git_branch_prefix,
                    target=_target_branch,
                )
                if salvaged:
                    console.print(
                        f"[green]Salvage-merged {len(salvaged)} orphaned worktree branch(es) "
                        f"→ {_target_branch}: {', '.join(salvaged)}[/green]"
                    )
            else:
                # Manual merge mode: scan and report orphaned branches
                from claw_forge.git.branching import scan_orphaned_branches

                _orphans = scan_orphaned_branches(
                    project_path,
                    prefix=git_branch_prefix,
                    target=_target_branch,
                )
                if _orphans:
                    console.print(
                        f"\n[yellow]Found {len(_orphans)} orphaned branch(es) with "
                        f"committed work (merge_strategy=manual):[/yellow]"
                    )
                    for _info in _orphans:
                        console.print(
                            f"  [bold]{_info['branch']}[/bold] — "
                            f"{_info['commit_count']} commit(s)"
                        )
                        for _subj in _info["commit_subjects"][:3]:
                            console.print(f"    • {_subj}")
                        console.print(
                            f"    [dim]git log {_info['branch']}[/dim]"
                        )
                        console.print(
                            f"    [dim]git merge --squash {_info['branch']}[/dim]"
                        )
                    console.print()

        # Startup sweep: remove any remaining stale worktree directories.
        # Runs AFTER ``merge_orphaned_worktrees`` so the salvage step can
        # still discover orphan branches via dir listing; anything left is
        # either pre-existing crash debris or failed-salvage residue and is
        # safe to drop (the underlying feature branches survive in git
        # refs and will be re-linked on demand by ``create_worktree``).
        # Skipped in smart mode: ``smart_cleanup_worktrees`` already owns
        # the cleanup decision per slug, and an unconditional sweep here
        # would nuke the worktrees smart mode deliberately preserved.
        if git_enabled and git_cleanup_mode != "smart":
            from claw_forge.git.branching import (
                prune_worktrees as _prune_worktrees,
            )

            _pruned = _prune_worktrees(project_path)
            if _pruned:
                console.print(
                    f"[dim]Pruned {_pruned} stale worktree dir(s) at startup[/dim]"
                )

        raw_tasks: list[dict[str, Any]] = init_data["tasks"]
        if not raw_tasks:
            console.print(
                "[yellow]No pending tasks found — run 'claw-forge plan <spec>' first[/yellow]"
            )
            return

        task_nodes = _task_dicts_to_nodes(raw_tasks)

        # Dry-run: print tasks and exit
        if dry_run:
            from claw_forge.state.scheduler import Scheduler

            scheduler = Scheduler()
            for tn in task_nodes:
                scheduler.add_task(tn)
            waves = scheduler.get_execution_order()

            console.print(f"\n[bold]Execution plan ({len(waves)} waves):[/bold]\n")
            for wave_idx, wave in enumerate(waves, 1):
                console.print(f"  Wave {wave_idx}:")
                for task_id in wave:
                    matched = next(
                        (t for t in task_nodes if t.id == task_id), None,
                    )
                    if matched:
                        desc = matched.description or matched.plugin_name
                        console.print(f"    • {task_id[:8]}…  {desc}")
            console.print(
                f"\n[dim]To run: claw-forge run --project {project_path}[/dim]\n"
                f"[dim]Board:  claw-forge ui  --project {project_path}[/dim]"
            )
            return

        # Build provider pool for direct API fallback.
        # ``from_config`` reads the ``pool:`` section of claw-forge.yaml and
        # threads ``strategy`` / ``failure_threshold`` / ``recovery_timeout``
        # / ``max_retries`` into the manager.  Without this, the yaml
        # ``pool.strategy`` was decorative — the pool always routed by
        # PRIORITY regardless of what the yaml said.
        from claw_forge.pool.manager import ProviderPoolManager

        configs = load_configs_from_yaml(cfg)
        pool = ProviderPoolManager.from_config(configs, cfg)

        # Lock to serialise env-sensitive options construction.
        # Matches the _env_client_lock pattern from autonomous-coding:
        # env reads + ClaudeAgentOptions creation happen under lock;
        # AgentSession connect + agent execution run fully in parallel.
        # The dispatcher's Semaphore(max_concurrency) gates overall
        # concurrency; this lock only prevents env-read races.
        _env_lock = asyncio.Lock()

        # Build task handler — communicates with the state service via HTTP
        # so that WebSocket events are broadcast to the Kanban UI.
        # Generous timeout: read=30s handles SQLite WAL contention under parallel load
        _http_timeout = httpx.Timeout(connect=10.0, read=30.0, write=10.0, pool=10.0)

        # ── Emergency commit signal handlers ──────────────────────────
        # On SIGTERM/SIGINT, best-effort commit dirty worktree files
        # before the process exits so partial work survives.
        _active_worktrees: dict[str, Path] = {}  # task_id -> worktree_path

        # ── Autonomous merge-retry sidecar ────────────────────────────
        # Task IDs that ``_set_merged_after_merge`` re-pended in this
        # wave; the outer loop removes them from ``total_completed`` so
        # the existing _new_pending filter picks them up for re-dispatch.
        # Cleared after each wave.  See spec
        # docs/superpowers/specs/2026-05-10-autonomous-merge-recovery.md.
        _pending_merge_retries: set[str] = set()

        # Construct the per-run context shared with every task_handler
        # invocation.  ``active_worktrees`` and ``pending_merge_retries``
        # are the SAME dict / set the signal handler + wave-loop close
        # over (passed by reference, not copied).
        ctx = RunContext(
            state_base=_state_base,
            state_port=_state_port,
            session_id=session_id,
            http_timeout=_http_timeout,
            model=model,
            effective_plan_model=effective_plan_model,
            pool=pool,
            env_lock=_env_lock,
            edit_mode=edit_mode,
            loop_detect_threshold=loop_detect_threshold,
            effective_verify_on_exit=effective_verify_on_exit,
            max_subagents=max_subagents,
            project_path=project_path,
            agent_isolation=agent_isolation,
            container_runtime_pref=container_runtime_pref,
            container_image=container_image,
            container_extra_mounts=container_extra_mounts,
            container_extra_env=container_extra_env,
            container_pull_if_missing=container_pull_if_missing,
            git_enabled=git_enabled,
            git_ops=git_ops if git_enabled else None,
            git_merge_strategy=git_merge_strategy,
            git_branch_prefix=git_branch_prefix,
            git_commit_on_boundary=git_commit_on_boundary,
            git_auto_checkpoint_secs=git_auto_checkpoint_secs,
            git_handle_uncommitted=git_handle_uncommitted,
            git_merge_retry_attempts=git_merge_retry_attempts,
            default_branch=_default_branch,
            active_worktrees=_active_worktrees,
            pending_merge_retries=_pending_merge_retries,
        )

        import signal as _signal

        from claw_forge.git.commits import emergency_commit as _emergency_commit

        _original_sigterm = _signal.getsignal(_signal.SIGTERM)
        _original_sigint = _signal.getsignal(_signal.SIGINT)

        def _emergency_save(signum: int, frame: Any) -> None:
            for _tid, _wt in _active_worktrees.items():
                _emergency_commit(_wt, task_id=_tid)
            if signum == _signal.SIGTERM and callable(_original_sigterm):
                _original_sigterm(signum, frame)
            elif signum == _signal.SIGINT:
                raise KeyboardInterrupt

        if git_enabled:
            _signal.signal(_signal.SIGTERM, _emergency_save)
            _signal.signal(_signal.SIGINT, _emergency_save)

        # Run dispatcher with pause/resume re-dispatch loop.
        # When Stop All pauses the dispatcher, we wait for Resume All,
        # then re-fetch remaining tasks from the DB and re-dispatch.
        total_completed: dict[str, dict[str, Any]] = {}
        total_failed: dict[str, str] = {}

        # functools.partial binds ``ctx`` so the dispatcher's
        # ``Callable[[TaskNode], Awaitable[dict]]`` signature is satisfied.
        _handler = functools.partial(task_handler, ctx=ctx)

        current_nodes = task_nodes
        while current_nodes:
            dispatcher = Dispatcher(
                handler=_handler,
                max_concurrency=concurrency,
                yolo=yolo,
                state_url=_state_base,
            )
            for node in current_nodes:
                dispatcher.add_task(node)

            dispatch_result = await dispatcher.run()
            total_completed.update(dispatch_result.completed)
            total_failed.update(dispatch_result.failed)

            # Autonomous merge-retry: tasks that re-pended after a squash
            # failure must NOT remain in ``total_completed``, otherwise the
            # _new_pending filter below would skip them on the next wave.
            # Each re-entry consumes one slot from ``merge_retry_attempts``;
            # at the cap ``_set_merged_after_merge`` stops re-pending so
            # the loop is bounded.  See spec
            # docs/superpowers/specs/2026-05-10-autonomous-merge-recovery.md.
            for _retry_id in _pending_merge_retries:
                total_completed.pop(_retry_id, None)
            _pending_merge_retries.clear()

            if not dispatcher.is_paused:
                # Wait for in-flight regression run to finish before
                # checking for bugfix tasks — the reviewer runs in the
                # state service process and may still be mid-test.
                async with httpx.AsyncClient() as check_client:
                    try:
                        for _wait in range(60):  # up to ~60s
                            _reg_resp = await check_client.get(
                                f"{_state_base}/regression/status",
                                timeout=5,
                            )
                            _reg = _reg_resp.json()
                            if not _reg.get("has_pending_work", False):
                                break
                            if _wait == 0:
                                console.print(
                                    "[dim]Waiting for regression suite "
                                    "to finish…[/dim]"
                                )
                            await asyncio.sleep(1)
                    except (httpx.HTTPError, Exception):  # noqa: BLE001
                        pass  # reviewer unreachable — skip wait

                    _tasks_resp = await check_client.get(
                        f"{_state_base}/sessions/{session_id}/tasks",
                        timeout=10,
                    )
                    _tasks_resp.raise_for_status()
                    _all = _tasks_resp.json()
                _new_pending = _task_dicts_to_nodes(
                    [
                        t for t in _all
                        if t["status"] == "pending"
                        and t["id"] not in total_completed
                        and t["id"] not in total_failed
                    ]
                )
                if _new_pending:
                    console.print(
                        f"\n[yellow]🔧 {len(_new_pending)} bugfix task(s) "
                        "dispatched by regression reviewer[/yellow]"
                    )
                    current_nodes = _new_pending
                    continue
                break  # Normal completion — all waves done

            # ── Paused: wait for Resume All ────────────────────────────
            console.print(
                "\n[bold yellow]⏸  Paused — waiting for Resume All…[/bold yellow]"
            )
            async with httpx.AsyncClient() as poll_client:
                while True:
                    await asyncio.sleep(1)
                    try:
                        resp = await poll_client.get(
                            f"{_state_base}/project/paused"
                            f"?session_id={session_id}",
                            timeout=3.0,
                        )
                        if not resp.json().get("paused", True):
                            break
                    except Exception:  # noqa: BLE001
                        pass
            console.print(
                "[bold green]▶  Resumed — re-dispatching tasks…[/bold green]"
            )

            # Re-fetch pending/failed tasks via HTTP for the next cycle
            # (resume-all already reset paused→pending in the state service)
            ctx.seen_logs.clear()
            async with httpx.AsyncClient() as resume_client:
                tasks_resp = await resume_client.get(
                    f"{_state_base}/sessions/{session_id}/tasks",
                    timeout=10,
                )
                tasks_resp.raise_for_status()
                all_tasks = tasks_resp.json()

            current_nodes = _task_dicts_to_nodes(
                [t for t in all_tasks if t["status"] in ("pending", "failed")]
            )

        # Restore original signal handlers after dispatcher loop
        if git_enabled:
            _signal.signal(_signal.SIGTERM, _original_sigterm)
            _signal.signal(_signal.SIGINT, _original_sigint)

        # ── GitHub mode: start reporter, then post summary + create draft PR ──
        if _github_ctx is not None:
            from claw_forge.github import GitHubClient as _GHClient
            from claw_forge.github.reporter import ProgressReporter as _Reporter

            _gh_completed = len(total_completed)
            _gh_failed = len(total_failed)

            async def _github_finalise() -> str | None:
                async with _GHClient(_github_ctx.token) as _gh:
                    _reporter = _Reporter(_gh, _github_ctx)
                    await _reporter.start()

                    # Post run-start comment
                    await _reporter.report_start(_gh_completed + _gh_failed, task)

                    _pr_url: str | None = None
                    try:
                        _pr = await _gh.create_draft_pr(
                            owner=_github_ctx.owner,
                            repo=_github_ctx.repo,
                            head=_github_ctx.branch_name,
                            base="main",
                            title=f"[GHA] {github_mode}",
                            body=(
                                "Auto-generated by claw-forge\n\n"
                                "## Changes\n\n"
                                f"Implementation driven by issue "
                                f"#{_github_ctx.issue_number}.\n\n"
                                "---\n\n"
                                "*This PR was created automatically by "
                                "[claw-forge](https://github.com/clawinfra/claw-forge).*"
                            ),
                            issue_number=_github_ctx.issue_number,
                        )
                        _pr_url = _pr["html_url"]
                        console.print(
                            f"[green]✓ Draft PR created:[/green] {_pr_url}"
                        )
                    except Exception as _pr_exc:  # noqa: BLE001
                        console.print(
                            f"[yellow]⚠ Could not create draft PR: {_pr_exc}[/yellow]"
                        )

                    await _reporter.report_summary(
                        completed=_gh_completed,
                        failed=_gh_failed,
                        pr_url=_pr_url,
                    )
                    await _reporter.stop()
                return _pr_url

            try:
                _pr_url_result = asyncio.run(_github_finalise())
                if _pr_url_result:
                    console.print(
                        f"[dim]GitHub PR:[/dim] {_pr_url_result}"
                    )
            except Exception as _gf_exc:  # noqa: BLE001
                console.print(
                    f"[yellow]⚠ GitHub finalisation error: {_gf_exc}[/yellow]"
                )

            # Clean up temp spec file
            if _github_spec_path is not None and _github_spec_path.exists():
                _github_spec_path.unlink(missing_ok=True)

        # Print summary
        completed = len(total_completed)
        failed = len(total_failed)
        console.print("\n[bold]Run complete:[/bold]")
        console.print(f"  ✅ Completed: {completed}")
        if failed > 0:
            console.print(f"  ❌ Failed: {failed}")
            # Show a concise per-task failure reason (first line only)
            for task_id, err in list(total_failed.items())[:5]:
                short = err.splitlines()[0][:120] if err else "unknown error"
                console.print(f"     [dim]{task_id[:8]}…[/dim] {short}")
            if len(total_failed) > 5:
                console.print(f"     [dim]… and {len(total_failed) - 5} more[/dim]")
            # Give an actionable hint when the error is provider exhaustion
            sample_err = next(iter(total_failed.values()), "")
            if "All providers exhausted" in sample_err or "No agent executor" in sample_err:
                console.print(
                    "\n[yellow]💡 No working providers found.[/yellow]\n"
                    "  • Run [bold]claw-forge pool-status[/bold] to see active providers\n"
                    "  • Add a valid API key to claw-forge.yaml (e.g. ANTHROPIC_API_KEY_1)\n"
                    "  • Or install the claude CLI for OAuth-based execution: "
                    "https://claude.ai/download"
                )
        else:
            console.print("  🎉 All tasks succeeded!")

            # Generate brownfield_manifest.json for future additions
            _manifest_path = project_path / "brownfield_manifest.json"
            if not _manifest_path.exists():
                _spec_candidates = [
                    project_path / "app_spec.txt",
                    project_path / "app_spec.xml",
                ]
                _found_spec: Path | None = None
                for _sc in _spec_candidates:
                    if _sc.exists():
                        _found_spec = _sc
                        break
                if _found_spec is not None:
                    try:
                        from claw_forge.spec import ProjectSpec, generate_brownfield_manifest

                        _parsed_spec = ProjectSpec.from_file(_found_spec)
                        if not _parsed_spec.is_brownfield:
                            _manifest = generate_brownfield_manifest(
                                _parsed_spec, completed, project_path,
                            )
                            _manifest_path.write_text(
                                json.dumps(_manifest, indent=2) + "\n",
                                encoding="utf-8",
                            )
                            console.print(
                                "  [dim]✓ Generated brownfield_manifest.json "
                                "for future additions[/dim]"
                            )
                    except Exception as _mf_exc:  # noqa: BLE001
                        console.print(
                            f"  [dim]⚠ Could not generate brownfield manifest: "
                            f"{_mf_exc}[/dim]"
                        )

    # Pop CLAUDECODE once for the entire run — prevents the claude CLI
    # from refusing to start (it detects nesting via this env var).
    # Restored in finally so the parent session is unaffected.
    _saved_claudecode = os.environ.pop("CLAUDECODE", None)
    try:
        try:
            running_loop = asyncio.get_running_loop()
        except RuntimeError:
            running_loop = None

        if running_loop is not None:
            import concurrent.futures

            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                pool.submit(asyncio.run, main()).result()
        else:
            asyncio.run(main())
    finally:
        if _saved_claudecode is not None:
            os.environ["CLAUDECODE"] = _saved_claudecode
