# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Build & Test

```bash
uv sync --extra dev          # install all deps including dev tools
uv run pytest tests/ -q      # full test suite
uv run pytest tests/path/to/test_file.py::ClassName::test_name -v  # single test
uv run pytest tests/ -q --cov=claw_forge --cov-report=term-missing  # with coverage (must reach 90%)
uv run ruff check claw_forge/ tests/  # lint (CI uses this exact command)
uv run ruff check claw_forge/ tests/ --fix  # auto-fix lint errors
uv run mypy claw_forge/ --ignore-missing-imports  # type check
```

CI runs `uv sync --extra dev` (not plain `uv sync`) — plain sync omits pytest and ruff.

## Release Process

1. Push to `main`
2. Create a GitHub Release with a tag (e.g. `v0.1.0a64`)
3. The `Publish to PyPI` workflow triggers automatically — it re-runs tests, builds the UI, patches the version from the tag, and publishes the wheel

The publish workflow is **not** triggered by CI passing — only by a GitHub Release publication.

**Version in `pyproject.toml` is a static `0.0.0.dev0` placeholder** — do NOT bump it manually. The publish workflow overwrites it with the version from the release tag at build time.

## Architecture Overview

claw-forge is a **multi-provider autonomous coding agent harness**. It reads an app spec, decomposes it into a feature DAG, then orchestrates parallel AI agents to implement features, fix bugs, and run tests — all tracked via a local REST+WebSocket state service.

### Three-Layer Stack

```
CLI (Typer)  ──────────────────────────────────────────
  claw_forge/cli.py — Typer app assembly + 2 residue commands (version, init) + back-compat shim (post 8-PR decomposition of 2026-05-12)
  claw_forge/_console.py — shared Rich Console singleton imported by all CLI modules
  claw_forge/config.py — config loading, env-var expansion, default-config / default-env scaffolding
  claw_forge/state/cli.py — Typer subapp: status | state | pause | resume | input | add (all hit the state-service REST API)
  claw_forge/state/client.py — state-service HTTP client + session-resolution helpers (consumer side of state/service.py)
  claw_forge/spec/cli.py — Typer subapp: plan | validate-spec | import + _write_plan_to_db helper
  claw_forge/orchestrator/run_cli.py — `claw-forge run` Typer command + dispatcher loop + signal-handler installation
  claw_forge/orchestrator/task_handler.py — per-task coroutine (RunContext-driven, promoted from former closure) + agent-prep helpers
  claw_forge/orchestrator/checkpointing.py — periodic auto-checkpoint asyncio task
  claw_forge/pool/cli.py — `claw-forge pool-status` command
  claw_forge/bugfix/cli.py — `claw-forge fix` command
  claw_forge/git/merge_cli.py — `claw-forge merge` command
  claw_forge/git/cli.py — Typer subapp: worktrees list | prune (cleans up .claw-forge/worktrees/)
  claw_forge/git/stash_cli.py — Typer subapp: stash list | drop (manages claw-forge-{auto,manual,leak}-* stash entries)
  claw_forge/ui_cli.py — Typer subapp: ui | dev (Kanban UI launcher, mirrors export_cli.py pattern)
  claw_forge/export_cli.py — Typer subapp: export csv | sql | json | training
  claw_forge/training/cli.py — Typer subapp: traces status | prune
  claw_forge/boundaries/cli.py — Typer subapp: boundaries audit | apply | status
  claw_forge/agent/sandbox.py — OS-level filesystem jail wrapper (macOS sandbox-exec, Linux bwrap; v0.8.26 git common-dir carve-out); owns _make_sdk_sandbox_settings
  claw_forge/agent/container.py — opt-in per-agent container isolation (docker/podman; agent.isolation: container)
  claw_forge/git/leak_watch.py — mid-run leak detector (snapshots project_path before/after each agent; auto-stashes new dirt)
  claw_forge/git/cleanup.py — smart-mode startup cleanup (preserve/salvage/remove per task state)
  claw_forge/git/conflict_advisor.py — opt-in LLM advisor that drafts CONFLICT_PROPOSAL.md on salvage conflict

State Service (FastAPI + SQLite via aiosqlite)  ────────
  claw_forge/state/service.py  — REST API + WebSocket /ws + SSE /events
  claw_forge/state/models.py   — Session, Task, Event ORM models
  claw_forge/state/scheduler.py — topological DAG scheduler

Orchestrator + Agent Execution + Provider Pool  ────────
  claw_forge/orchestrator/dispatcher.py — asyncio.TaskGroup parallel dispatch
  claw_forge/agent/runner.py            — wraps claude-agent-sdk query()
  claw_forge/pool/manager.py            — multi-provider rotation + circuit breaker

Git Workspace Tracking  ────────────────────────────────
  claw_forge/git/slug.py     — centralized slug generation (make_slug, make_branch_name)
  claw_forge/git/branching.py — feature branch create/switch/delete
  claw_forge/git/commits.py  — checkpoint commits with structured trailers
  claw_forge/git/merge.py    — squash-merge feature branches to main; sync_worktree_with_target catches up resumed branches before dispatch

Spec & Export  ──────────────────────────────────────────
  claw_forge/spec/parser.py  — XML/plain-text spec → ProjectSpec; honours <feature index, depends_on>
  claw_forge/exporter.py     — read-only CSV/SQL/JSON export of session+task data from state.db

Boundaries Harness  ─────────────────────────────────────
  claw_forge/boundaries/walker.py    — git ls-files-driven source enumeration
  claw_forge/boundaries/signals.py   — dispatch / import / churn / function signals
  claw_forge/boundaries/scorer.py    — composite weighted score + threshold ranker
  claw_forge/boundaries/audit.py     — top-level audit pipeline (read-only)
  claw_forge/boundaries/classifier.py — subagent that labels hotspots with refactor pattern
  claw_forge/boundaries/report.py    — boundaries_report.md emit/parse round-trip
  claw_forge/boundaries/refactor.py  — pattern-specific subagent prompts
  claw_forge/boundaries/apply.py     — per-hotspot apply lifecycle (gate → merge or revert)
```

### How a `claw-forge run` Works

1. **State service** (`localhost:8420`) is started (subprocess) and manages all task state in SQLite
2. **Dispatcher** pulls "ready" tasks from the scheduler (tasks whose dependencies are all completed)
3. Each task is handed to the matching **plugin** (coding, testing, reviewer, bugfix)
4. The plugin calls `run_agent()` which wraps `claude_agent_sdk.query()` and yields messages
5. Task result is PATCHed back to the state service; WebSocket broadcasts updates to the UI
6. On failure: exponential backoff retry (up to `retry_attempts`); dependent tasks become "blocked"

### Provider Pool (`claw_forge/pool/`)

`ProviderPoolManager` wraps 8 provider implementations (Anthropic, Bedrock, Azure, Vertex, OpenAI-compat, Anthropic-compat, Ollama, OAuth). Each request:
- Routes through `Router` (5 strategies: PRIORITY, ROUND_ROBIN, WEIGHTED_RANDOM, LEAST_COST, LEAST_LATENCY)
- Respects per-provider `CircuitBreaker` (CLOSED → OPEN after N failures → HALF_OPEN after timeout)
- Tracks cost/tokens/latency in `UsageTracker`
- Falls through the full chain before raising `ProviderPoolExhausted`

### Agent Runner (`claw_forge/agent/runner.py`)

`run_agent()` is the main entrypoint for agent execution. It adds on top of the raw SDK:
- **Auto-injected MCP servers**: SDK MCP (in-process, zero cold-start) for features; LSP servers detected from file types (`.py` → pyright, `.ts` → typescript-language-server)
- **Auto-injected skills**: role-specific + task-keyword matched skills from `skills/` directory
- **Thinking strategy**: varies by `agent_type` (initializer = deep, coding = adaptive, testing = medium)
- **Security hooks**: `CanUseTool` callbacks blocking dangerous bash commands; filesystem writes restricted to `project_dir`

`collect_structured_result()` is used when structured JSON output (code review verdicts, feature summaries) is required.

### Worktree-Leakage Defenses (v0.8.16 → v0.8.20)

Five independent layers prevent the v0.8.14/15 leak class — agent writes to the *parent project's* working tree (target branch, typically `main`) instead of its assigned worktree under `.claw-forge/worktrees/<slug>/`.  Each layer is independent so a regression in one still leaves the others as a backstop:

1. **File-tool path sandbox** (`claw_forge/agent/permissions.py:make_can_use_tool`): Read/Write/Edit/Glob/Grep all sandboxed to `project_dir` (= the worktree).  Pre-existing.
2. **Exempt-command jail check** (`make_can_use_tool(forbidden_jail_root=…)`, v0.8.16): even for `SANDBOX_EXEMPT_COMMANDS` (`git`, `python`, `npm`, …), denies path arguments that point inside the parent project but outside the worktree — catches `git -C /<project_root> add foo`, `python /<project_root>/script.py`, `git --git-dir=/<project_root>/.git checkout`.  Wired in `cli.py` to `project_path` whenever `git_enabled`.
3. **Agent-prompt boundary directive** (v0.8.16, hardened in v0.8.18): `cli.py` appends a `## Workspace boundary (CRITICAL)` paragraph to the agent's system prompt.  v0.8.18 *no longer names the parent project's absolute path explicitly* (information-hiding) — the agent only sees its cwd as "the project root" with no observable handle to escape.
4. **OS-level filesystem jail** (`claw_forge/agent/sandbox.py`, v0.8.18 macOS, v0.8.21 Linux, v0.8.26 git common-dir carve-out): wraps the `claude` CLI subprocess in `sandbox-exec` (macOS) or `bwrap` (Linux) so the kernel itself denies `file-write*` outside the worktree.  All escape patterns above are blocked at the syscall level: `git -C`, `python -c "open('/abs', ...)"`, FFI through ctypes, dynamically-built path strings — every one returns `EACCES` (macOS) / `EROFS` (Linux).  Falls back to behavioural-only stack on platforms without sandbox support (Windows, BSD, sandbox binary missing), with a logged warning.  **Critical implementation detail**: the sandbox profile must use canonical paths (`Path.resolve()`) on both OSes — macOS sandbox compares against the kernel's resolved view (`/tmp/foo` references silently no-op against writes the kernel sees as `/private/tmp/foo`); Linux bwrap follows symlinks at mount time, so unresolved paths behave unpredictably across mount layers.  Linux uses the layer-ordering trick `--dev-bind / /` then `--ro-bind <project>` then `--bind <worktree>` (later mounts override at overlapping subpaths) to mirror the macOS profile shape.  **v0.8.26 git common-dir carve-out**: linked worktrees share their object store, refs, and per-worktree metadata at `<project>/.git/`; that whole subtree must be writable for `git commit` to land objects + refs + index.lock atomically.  v0.8.18→v0.8.25 carved out only the worktree's working tree, so any `git` invocation inside the agent's worktree failed with `fatal: Unable to create '...index.lock': Operation not permitted`.  v0.8.26 adds a third allow rule for the common dir resolved via `_resolve_git_common_dir` (reads `<worktree>/.git` pointer file → walks up two levels; falls back to `<project>/.git`).  **Subagent inheritance**: Task-tool subagents share the parent claude process (in-process queries, not new binaries); even when an agent shells out via Bash to spawn a grandchild process, sandbox-exec's process-tree inheritance carries the deny rules through every descendant.  Pinned by `tests/agent/test_sandbox.py::TestMacosWrapperSubagentInheritance`.

5. **Container isolation** (`claw_forge/agent/container.py`, v0.8.19 Level 4 — *opt-in*): each agent runs in a Docker/Podman container with the worktree mounted at `/workspace` and the parent project absent from the container's filesystem namespace entirely.  Strongest isolation — escape paths return `ENOENT` (the path doesn't exist in the namespace) rather than `EACCES`.  Opt-in via `agent.isolation: container` in `claw-forge.yaml` plus an operator-built image (Dockerfile template in `docs/container-isolation.md`).  Pays ~1–3s per-task startup latency, so it's right for security-sensitive deployments and untrusted prompts but overkill for the default dev loop.  Auth passes via env-var forwarding (`-e ANTHROPIC_AUTH_TOKEN`); we do NOT bind-mount `~/.claude/` because the boundary stays cleaner.

**Cross-layer rule — nested sandbox prevention (v0.8.20)**: when Layer 4 (sandbox-exec) or Layer 5 (container) is active, the SDK's `SandboxSettings.enabled` MUST be `False`.  macOS forbids nested `sandbox_apply()` calls; the SDK's per-Bash sandbox would invoke `sandbox-exec` *inside* our outer wrapper, the kernel returns `Operation not permitted`, sandbox-exec exits 71, and the agent's Bash tool fails with `[Tool failure] Bash: Exit code 71`.  Enforced in `claw_forge/cli.py:_make_sdk_sandbox_settings(isolation_active=…)` and locked in by `tests/test_cli_commands.py::TestMakeSdkSandboxSettings`.  **Before adding a third sandbox layer (gVisor, Firecracker, Linux seccomp/landlock) or re-enabling SDK sandbox in any new code path: verify the nesting matrix.**  See `memory/project_nested_sandbox_landmine.md` for the full forensic context from the v0.8.18 → v0.8.20 cycle.

When all three layers fail, the **snapshot-rollback** (`claw_forge/git/leak_watch.py`, hardened in v0.8.17) enforces a stronger invariant: **`project_path` is HEAD-clean for the entire run's lifetime**.  Mechanism:

1. **Boot baseline at dispatcher startup** — after smart-cleanup runs, `capture_boot_baseline(project_path)` stashes any remaining dirt as `claw-forge-boot-<ts>` and leaves `project_path` HEAD-clean.  When smart-cleanup already did its job (the healthy default), this is a no-op.  When the operator has opted out of smart-cleanup, their pre-existing state is preserved in the boot stash and recoverable via `git stash apply <ref>` after the run.

2. **Per-task post-rollback** (in the dispatcher's `finally` block, BEFORE `apply_on_completion`) — under `git_ops.exclusive_section()` (the same lock that serialises `squash_merge`, so rollback never races a mid-flight squash): snapshot `git status --porcelain`, stash any dirt as `claw-forge-leak-<task_id>-<ts>`, verify clean.  Concurrent agents' leaks land in whichever rollback fires first; markers are best-effort attribution.

3. **Pre-task assertion** — every dispatch logs a warning if `project_path` is unexpectedly dirty (concurrent task leak in flight, or invariant violation).  Diagnostic only; does not fail dispatch.

The forensic trail is fully recoverable: `claw-forge stash list` shows all four kinds (`auto`/`manual`/`leak`/`boot`); the operator inspects with `git stash show -p <ref>` and recovers with `git stash apply <ref>`.  Best-effort throughout: a git failure during snapshot/stash logs at `error` level and continues — leak prevention must not become a liveness gate.

### Plugin System (`claw_forge/plugins/`)

Plugins are discovered via Python entry points (`[project.entry-points."claw_forge.plugins"]` in `pyproject.toml`). Each implements the `AgentPlugin` protocol: `name`, `description`, `get_system_prompt(context)`, `execute(context) -> PluginResult`. Built-in plugins: `initializer`, `coding`, `testing`, `reviewer`, `bugfix`.

### MCP Servers (`claw_forge/mcp/`)

Two MCP surfaces:
- **`sdk_server.py`** (`create_feature_mcp_server`) — in-process SDK MCP, used by default (`use_sdk_mcp=True`)
- **`feature_mcp.py`** — subprocess FastMCP server (legacy fallback). Exposes `claim_feature`, `update_feature`, `list_features`, `get_feature` tools to agents.

### State Service Auto-Start (`cli.py` `_ensure_state_service`)

Both `claw-forge run` and `claw-forge ui` auto-start the state service via `_ensure_state_service()`:
- **Project-aware**: passes `--config` pointing to the project directory's `claw-forge.yaml` so the subprocess finds the correct config even when CWD differs from the project dir
- **Project verification**: after starting, verifies `/info` returns a `project_path` matching the intended project (not just non-null)
- **Port fallback**: if the configured port is occupied, tries port+1 … port+4
- **Version check**: restarts the service if the running version differs from the CLI version

### Session Resolution (`cli.py` `_resolve_latest_session`)

All session auto-detection (ui prod, ui dev, dev command) uses `_resolve_latest_session()`:
- **Project-filtered**: queries `WHERE project_path = ?` to avoid picking up stale test sessions or sessions from other projects sharing the same DB
- **Centralized**: all inline session queries have been consolidated into this single function

### State Service API (default `localhost:8420`)

All CLI commands communicate with the state service via HTTP. Key endpoints:
- `POST /sessions`, `GET /sessions`, `GET /sessions/{id}`
- `POST /sessions/{id}/tasks` (accepts optional `touches_files: list[str]` for file-lock declaration), `PATCH /sessions/{id}/tasks/{id}` (status, cost, tokens, merged_to_target_branch)
- `POST /sessions/{id}/tasks/{id}/human-input`
- `POST /sessions/{id}/tasks/stop-all`, `POST /sessions/{id}/tasks/resume-all` — pause/resume in-flight tasks
- `POST /sessions/{id}/tasks/requeue` — batch reset failed/blocked tasks to pending. Body: `{statuses: list[str] = ["failed", "blocked"], error_pattern?: str}`. Optional ``error_pattern`` is a SQL ``LIKE`` filter on ``error_message`` (e.g. ``"%rate_limit%"`` to reset only rate-limit failures). Used by the Kanban UI's "Reset All" button on the Failed and Blocked column headers.
- `POST /sessions/{id}/file-claims` — atomic file-lock claim for a task; returns 200 on success or 409 with conflict list
- `DELETE /sessions/{id}/file-claims/{task_id}` — release all claims held by a task
- `GET /sessions/{id}/file-claims` — list current claims (for debugging)
- `POST /tasks/{id}/agent-log` — record an agent streaming log entry (assistant text, tool_use, tool_result). v0.8.28: persists to the events table AND broadcasts via WebSocket; pre-v0.8.28 was broadcast-only, leaving the activity log marooned in browser sessionStorage with no way to reconcile after a refresh / new tab / config change.
- `GET /sessions/{id}/agent-log?since=<id>&limit=<N>` — hydration endpoint for the Kanban activity log (v0.8.28). Returns `agent_log` events with `id > since`, ordered ascending, capped at `limit` (default 500, max 5000). UI calls with `since=0` on session join, then re-calls with the last-seen id on WebSocket reconnect to fill the disconnect gap. Replaces the per-tab `sessionStorage` cache as the source of truth.
- `WebSocket /ws` — real-time broadcast of feature updates, cost events, pool health
- `GET /pool/status`
- `POST /shutdown`

### UI (`ui/`)

React + Vite + TypeScript Kanban board. Built with `npm --prefix ui run build`; output copied to `claw_forge/ui_dist/` before wheel packaging. In development, served via `claw-forge ui`. Connects to the state service WebSocket for real-time updates.

**`claw-forge ui` production mode init order** (ordering matters — `state_port` must be resolved before anything that depends on it):
1. `_ensure_state_service()` — discover or start the state service, resolve final port
2. `_resolve_latest_session()` — read session from DB filtered by project path
3. Patch `index.html` with runtime JS config (port, session)
4. Build reverse proxy client (`httpx.AsyncClient`) targeting the resolved port
5. Construct Starlette app with proxy routes and static file serving

### spec/parser.py

Parses `app_spec.txt` or `app_spec.xml` (greenfield or brownfield) into a `ProjectSpec` with a list of features and dependency edges. The `initializer` plugin calls this to seed the task DAG in the state service.

The XML schema accepts two forms within a `<category>`:
- **Legacy bullets** (still supported): `- User can register` lines in the category text.
- **`<feature>` elements** with optional `index` and `depends_on` attributes:
  ```xml
  <feature index="14"><description>System displays parse errors</description></feature>
  <feature index="18" depends_on="14"><description>System displays side-by-side diff</description></feature>
  ```
  Both forms coexist within the same `<category>`. The parser resolves `depends_on` (1-based feature numbers) into 0-based positional indices that match the convention used by `_assign_dependencies` and `_write_plan_to_db`. `/create-spec` Phase 3.5 (overlap analysis) emits the `<feature>` form when the user serializes a flagged pair.

The XML schema also accepts three architectural-shape attributes on `<feature>`:

- **`shape="plugin" | "core"`** — declares whether the feature is vertical
  (lives in its own directory under the project's plugin root) or
  cross-cutting.  Plugin-shape features auto-derive `touches_files`;
  core-shape features must declare `touches_files` explicitly or the
  parser raises `ValueError` at parse time.
- **`plugin="<name>"`** — directory ownership for plugin-shape features.
  When `shape="plugin"` and `plugin="auth"`, `touches_files` defaults to
  `["src/plugins/auth/**"]` (override via the explicit `touches_files`
  attribute).  Used by the dispatcher's file-claim locks for parallel
  conflict prevention.
- **`touches_files="path1,path2,..."`** — explicit comma-separated list
  of file globs.  Required when `shape="core"`; optional override when
  `shape="plugin"` (e.g. for plugins that legitimately edit shared
  infrastructure like a DB migration).

```xml
<feature index="14" shape="plugin" plugin="auth">
  <description>User can register with email and password</description>
</feature>
<feature index="20" shape="core"
         touches_files="src/core/middleware/auth.py">
  <description>All endpoints validate JWT</description>
</feature>
```

`shape="core"` without an explicit `touches_files` attribute raises a
parse error (cross-cutting features can't be auto-derived from a
directory).  Specs without `shape` attributes parse identically to
before — pure backward compatibility.

Both `shape` and `plugin` are persisted as columns on the `Task` ORM
and are exposed via the state-service API (`POST /sessions/{id}/tasks`,
`GET /sessions/{id}/tasks`) so the dispatcher and scheduler can read
them at runtime.

### spec/validator.py — Layer 4 (Shape)

`claw-forge validate-spec` runs a fourth layer that catches every
shape-awareness gap left after the parser:

- **Gap 1** (ERROR): `shape="plugin"` features missing both `plugin=` and
  explicit `touches_files=` — silent acceptance would disable file-claim
  locking and break parallel-safety.
- **Gap 3** (WARNING / ERROR strict): a `shape="core"` feature's
  `touches_files` glob overlaps a plugin's directory. Conservative
  fnmatch probe — false-negatives over false-positives.
- **Gap 5** (WARNING / ERROR strict): brownfield-only — `plugin="X"`
  references a directory under `src/plugins/` that doesn't exist. Skipped
  on greenfield projects.
- **Gap 6** (WARNING / ERROR strict): heuristic — a category's unannotated
  bullets look vertical (`User can …`, `displays`, `creates`) but no shape
  is declared. Score uses `VERTICAL_INDICATORS` and `CROSS_CUTTING_INDICATORS`
  vocabularies; threshold is 0.6 vertical-ratio with ≥3 unannotated bullets.
- **Gap 7** (WARNING, never promoted): `depends_on` chain of `shape="core"`
  features depth ≥ 4 — every link serializes at dispatch time, so long
  core chains are an architectural smell worth surfacing.
- **Gap 8** (WARNING / ERROR strict): heuristic — a feature's description
  suggests migration / DB-schema work (`migration`, `alembic`, `create
  table`, `add column`, …) but it isn't declared `shape="core"`.
  Migration-touching features mutate alembic's revision tree, a global
  shared resource; declaring them `shape="core"` makes the dispatcher
  single-flight them, preventing parallel agents from writing duplicate
  `revision="N"` files.  Vocabulary lives in `MIGRATION_INDICATORS`;
  recommended `touches_files` glob is `migrations/versions/**`
  (constant `DEFAULT_MIGRATION_TOUCHES_FILES`).

The parser raises `ValueError` for two parse-time invariants that bypass
Layer 4 entirely (because the dispatcher reads `Task.shape` from the DB
and acts on it — bad values must not reach `claw-forge plan`):

- Unknown `shape=` values (e.g. `shape="ploogin"`).
- `shape="core"` without `touches_files=`.

`--strict-shape` promotes Gap 3, 5, 6, 8 WARNINGs to ERRORs. Gap 1 is
always ERROR; Gap 7 is always WARNING. The flag is the migration on-ramp
for projects that have shape-annotated their spec.

`--project-root` overrides the auto-detected project root for filesystem
checks. Without it, validate-spec walks up from the spec file looking
for `.claw-forge.yaml` first, then `.git`. If neither is found, Layer 4
filesystem checks are skipped with a dim notice.

### Export (`claw_forge/exporter.py`)

`claw-forge export` reads `.claw-forge/state.db` directly via `sqlite3` (no state-service dependency, safe to run while a session is active) and emits CSV (flat or per-table), SQL dump (sqlite-importable), or JSON. Supports `--scope session|all`, `--csv-mode flat|split`, and explicit `--session UUID`. Used for stakeholder reports, spreadsheet analysis, and DB migration round-trips.

### Boundaries Harness (`claw_forge/boundaries/`)

`claw-forge boundaries audit | apply | status` identifies and refactors plugin-extension hotspots in target codebases. Two phases:

**Audit (read-only):** walker enumerates source files via `git ls-files`; signals scorer rates each on dispatch density, import centrality, recent-branch churn, and function centrality; weighted composite score ranks hotspots; classifier subagent labels each with one of four canonical patterns (`registry`, `split`, `extract_collaborators`, `route_table`); emits `boundaries_report.md`.

**Apply (modifies repo):** for each confirmed hotspot, spawns a coding subagent on its own feature branch under `.claw-forge/worktrees/`, runs the project's test command inside the worktree, and squash-merges to main on green or reverts on red. Reuses the existing `git/branching.py` + `git/merge.py` plumbing, so it inherits the merge-conflict handling, no-op detection, and worktree cleanup that `claw-forge run` ships.

Refactors run **serially** (not parallel): refactor B may depend on refactor A's output, and they share files. Use `apply --hotspot <path>` for one-at-a-time runs and `apply --auto` for fully-autonomous batch refactoring.

The boundaries harness composes with shape-aware specs: refactoring a
hotspot file into a registry / split / route-table pattern (the four
canonical patterns the harness emits) means future feature additions
can land as `<feature shape="plugin">` cleanly — the file ownership is
unambiguous so the dispatcher's parallel-safety guarantees apply.  See
`docs/commands.md` → `claw-forge boundaries` → "Brownfield workflow"
for the recommended sequence.

### Git Branch Naming (`claw_forge/git/slug.py`)

Feature branches use semantic names derived from the task's category and description:
- **Format**: `feat/{category}-{description-slug}` (e.g. `feat/auth-jwt-authentication`)
- **Verb stripping**: leading action verbs (add, implement, create, build, fix, …) are removed so branch names read as noun phrases
- **Centralized**: `make_slug()` and `make_branch_name()` replace all ad-hoc slug patterns; all call sites in `cli.py` use these functions
- **Squash merge**: each feature branch is squash-merged to main with a semantic commit message including completed steps, task-ID, and session trailers

### Git Worktree Lifecycle (`claw_forge/git/branching.py`)

Each concurrent agent gets an isolated git worktree under `.claw-forge/worktrees/`. Worktrees share the same `.git` object store (no repo duplication) — only the working-tree files are checked out separately. Cleanup is automatic via three layers:
- **Post-merge** (`merge.py`): `squash_merge()` calls `remove_worktree()` then `delete_branch()` — disk reclaimed immediately after the feature lands
- **Startup sweep** (`prune_worktrees()`): removes all directories under `.claw-forge/worktrees/` and runs `git worktree prune` — catches stale worktrees from crashed runs
- **Pre-create guard** (`create_worktree()`): if the target path already exists, it is force-removed before creating the new worktree
- **Failure preservation**: on task failure, the worktree is preserved if the branch has checkpoint commits so the retry can resume from partial work
- **Orphan scan** (`scan_orphaned_branches()`): when `merge_strategy: manual`, lists orphaned branches with committed work and shows copy-pasteable git commands for manual resolution
- **Manual cleanup** (`claw-forge worktrees [list|prune]`, `claw_forge/git/cli.py`): inspect or clean up residual worktrees outside the `claw-forge run` flow — useful for terminally-failed tasks (no further retry will land) and for completed tasks whose squash-merge itself failed, neither of which trigger the startup salvage path. `prune` salvage-merges then removes; `prune --discard` force-removes everything without salvage. **Safe to run mid-session**: `prune` reads `.claw-forge/state.db` directly (read-only, no service dep) for `status='running'` tasks and skips their slugs in both salvage and discard paths so live agents' worktrees aren't yanked from under them. `--force` opts out of the running-task filter (only after stopping the dispatcher). Branching helpers `merge_orphaned_worktrees(skip_slugs=…)` and `prune_worktrees(skip_slugs=…)` carry the filter; the dispatcher's startup callers pass nothing and behave identically to before.
- **Smart-mode startup cleanup** (`claw_forge/git/cleanup.py`, default `git.cleanup_orphan_worktrees: smart`; opt out with `manual`): walks every worktree directory at `claw-forge run` startup and dispatches preserve / salvage / remove per-slug based on the corresponding task's status in the DB. Replaces both the legacy `orphans_reset > 0` gate AND the unconditional `prune_worktrees` sweep — smart mode owns the cleanup so the unconditional sweep would otherwise nuke the worktrees it deliberately preserved. Decision matrix: `pending` + has commits → preserve (resume substrate for `prefer_resumable`); `failed` or `completed` + has commits → salvage (terminal or v0.5.35 bug class); no matching task + has commits → salvage (orphan); empty → remove. Conflicts on salvage preserve the worktree and are reported to the user. No-op when `merge_strategy: manual` (smart mode never auto-merges).
- **LLM conflict advisor** (`claw_forge/git/conflict_advisor.py`, default `git.llm_conflict_proposals: true`; opt out with `false`): when smart-mode salvage hits a real merge conflict, drafts a `CONFLICT_PROPOSAL.md` inside the preserved worktree using `claude_agent_sdk`. Advisory only — never lands on `main`; the user reads, edits, and applies it manually. Costs one agent call per conflict; conflicts are rare so the spend is bounded. Set to `false` to disable.
- **Post-merge target push** (`git.push_after_merge`, opt-in via config or `--push-after-merge` CLI flag, default `false`): when set to `true` (or a remote name string like `"upstream"`), `apply_on_completion()` pushes the target branch to its remote after every non-no-op squash-merge.  Replaces the deprecated per-turn `agent.auto_push` — only the target branch is pushed, never per-task feature branches, so the remote stays clean of zombie refs.  Push failures are logged as warnings and don't fail the task; the next merge's push catches the remote up.  `agent.auto_push` in user configs now triggers a one-line deprecation warning and is otherwise ignored.
- **Startup uncommitted-state handling** (`git.handle_uncommitted_at_startup`, default `ignore`; will flip to `smart` next minor): at `claw-forge run` startup, scans the main worktree for any uncommitted state — untracked files, unstaged-modified tracked files, and staged-not-committed files — and dispatches per-state actions fully autonomously.  Architectural rule: agent worktrees branch from main's HEAD commit, so anything not in HEAD is invisible to the agent and a future squash-merge collision; the discriminator is binary, committed-to-HEAD vs everything-else.  `smart` mode (autonomous, no human-in-the-loop): archives untracked files to `.claw-forge/orphans/<startup-ts>/<original-path>` with sibling `PROVENANCE.json` (recover via `cp`), and stashes all dirty-tracked state in one `git stash push -m "claw-forge-auto-<ts>"` operation (recover via `git stash pop`).  Both primitives reversible; smart mode never aborts.  `abort` mode (explicit fail-fast opt-in): refuses to start whenever any uncommitted state exists.  `ignore` mode is the legacy behaviour — handler doesn't run.  Hard-gate: no agent worktrees are created until the main worktree is clean.

### Pre-Dispatch Worktree Sync (`cli.py` task_handler + `git/merge.py:sync_worktree_with_target`)

When the dispatcher hands a task to an agent, the worktree is now **synchronised with `target_branch` before agent execution**, not after. The flow:

1. `_create_and_sync_worktree()` (`cli.py`) calls `git_ops.create_worktree(...)` to create or resume the worktree, then immediately `git_ops.sync_worktree(...)` to run `git merge --no-verify --no-edit <target>` *inside* the worktree.
2. Three outcomes possible:
   - **No-op** (`{synced: True, no_op: True, merged_count: 0}`) — branch already at target HEAD; agent runs normally.
   - **Clean merge** (`{synced: True, merged_count: N}`) — N target commits merged without conflict; agent runs on a synchronised worktree.
   - **Conflict** (`{synced: False, conflicts: [...]}`) or dirty worktree (`{synced: False, dirty_worktree: True}`) — agent does NOT run. The task is PATCHed to `failed` with a structured `error_message` (`resume_conflict: ...` listing the offending files), file claims are released, and the worktree is preserved on disk so the operator can `cd` in, resolve manually, and requeue.

This eliminates the failure mode where a resumed branch only sees `target`'s newer commits at squash-merge time — by then the agent has already wasted its turn on stale state. The catch-up rebase inside `squash_merge` stays as a second-line defence for multi-agent runs where `target` moves *during* execution.

`branch_overlap_files()` (`branching.py`) is the read-only diagnostic counterpart — returns the files modified on both branch and target since their merge-base, used in error messages and tests.

### Periodic Auto-Checkpoint (`cli.py` task_handler)

A background `asyncio.Task` periodically commits dirty worktree files during agent execution to minimize data loss on crash:
- **Config**: `git.auto_checkpoint_interval_seconds` in `claw-forge.yaml` (default `300` = 5 minutes, `0` to disable)
- **Phase trailer**: commits use `Phase: auto-save` to distinguish from agent-initiated checkpoints
- **Best-effort**: all checkpoint commits (periodic, boundary, and completion) are best-effort — `commit_checkpoint()` catches `git commit` failures (e.g. pre-commit hooks in the target project) and returns `None` instead of crashing the task
- **Lifecycle**: started after worktree creation, cancelled in the finally block on task completion/failure/cancel

### Emergency Commit on Signals (`cli.py` + `commits.py`)

SIGTERM and SIGINT signal handlers do a best-effort `git add -A && git commit` on all active worktrees before the process exits:
- **`emergency_commit()`** (`commits.py`): synchronous, fast, catches all exceptions — safe to call from signal handlers
- **`_active_worktrees` registry**: task handler registers/deregisters worktree paths so the signal handler knows what to commit
- **Signal restoration**: original handlers are restored after the dispatcher loop completes

### Resume Context on Retry (`cli.py` task_handler)

When a task is retried after failure, the agent receives a structured resume preamble prepended to its prompt:
- **Prior work**: commit subjects from the feature branch (via `branch_commit_subjects()`)
- **Previous failure**: the `error_message` from the prior attempt (stored in the DB)
- **Handoff artifact**: contents of `HANDOFF.md` if it exists in the worktree
- **Instructions**: tells the agent not to redo completed work and to focus on fixing the prior failure

### SQLite Crash Safety

The state service uses SQLite WAL mode with multi-layer corruption defense:
- **`synchronous=FULL`**: every WAL page is fsynced before ack — crash-safe even on dirty kills
- **Lifespan teardown**: async `PRAGMA wal_checkpoint(PASSIVE)` runs on clean FastAPI shutdown
- **atexit handler**: synchronous `PRAGMA wal_checkpoint(TRUNCATE)` via plain `sqlite3` — runs on any normal Python exit (KeyboardInterrupt, SIGTERM), needs no event loop
- **SafeJSON columns**: `TypeDecorator` on all JSON columns catches `JSONDecodeError` from truncated payloads and returns a fallback value instead of crashing
- **Tiered recovery on startup**: Level 1 drops WAL/SHM files → Level 2 uses `sqlite3 .recover` → Level 3 raises actionable error
- **Graceful shutdown**: both `dev.sh` and `claw-forge ui` POST `/shutdown` before sending SIGTERM to give the lifespan teardown time to run

### Training-Trace Capture (`claw_forge/training/`)

**On by default since v0.7.1**: `claw-forge init` scaffolds `claw-forge.yaml` with
both `training_traces.enabled: true` and `training_traces.acknowledged_terms: true`,
so every SDK message from `run_agent()` is teed to the existing `events` table as
`event_type="agent_message"` from the first run. Set both to `false` in the config
to disable. The recorder is a caller-side wrapper around the async iterator —
`run_agent` itself stays a pure SDK wrapper. Capture is best-effort: a state-service
hiccup never aborts an in-flight task. Anthropic's Usage Policies apply — see the
spec at `docs/superpowers/specs/2026-05-06-training-trace-capture-design.md`.

`claw-forge export training` reads `.claw-forge/state.db` directly via `sqlite3`
(no service dep), filters by task outcome (`success` / `recovered` / both, optionally
`--include-failed` for DPO negatives), projects to OpenAI tool-use JSONL by default
(with ShareGPT, ChatML, and raw alternatives), redacts secrets and usernames at export
time, and emits a single file or train/val/test split. The squash-merge commit SHA is
captured on `Task.merge_commit_sha` so `--include-diff` can attach the canonical
ground-truth diff to every successful trajectory.

`claw-forge traces [status|prune]` is the retention surface; auto-prune at
state-service startup is config-driven via `training_traces.retention.keep_days`.

The export CLI lives in `claw_forge/export_cli.py` (not `cli.py`) so tests can import
the `export_app` Typer subapp without dragging the full SDK transitive chain — same
pattern as `claw_forge/training/cli.py` for the `traces` subapp.

The downstream training pipeline (Qwen2.5-Coder + LoRA via Unsloth) is documented in
`docs/training/unsloth-recipe.md` and lives entirely outside the harness — claw-forge
owns the corpus, the user owns the training loop. Anthropic Usage Policies prohibit
using Claude outputs to train competing models; this feature is for personal/internal
distillation only and the user is responsible for compliance with terms.

## Key Conventions

- **Async throughout**: pure `asyncio`, no threads. `asyncio.TaskGroup` for structured concurrency in the dispatcher.
- **No DB migrations**: state service creates tables fresh on startup (`CREATE TABLE IF NOT EXISTS`).
- **`uv run`** is always used to execute Python tools — never activate the venv manually.
- **Coverage gate**: CI enforces `fail_under = 90` (branch coverage). Adding new source files without tests will fail CI.
- **Version in `pyproject.toml`** is a static `0.0.0.dev0` placeholder — never bump it manually. The publish workflow sets the real version from the release tag.
- **`.claw-forge/state.log`** is a runtime file, gitignored. Do not commit it.
- **Default state port is `8420`** — configurable via `--port` flag or `state.port` in `claw-forge.yaml`.
- **Merge-gating** (`merged_to_target_branch` flag on tasks): a dependent task is unblocked only when its parent is `status=completed AND merged_to_target_branch=True`. The dispatcher PATCHes `merged_to_target_branch=False` when starting a task on a feature branch with `merge_strategy: auto`, and back to `True` after a successful squash. If the squash fails, the autonomous merge-recovery loop (see below) re-pends the task up to `git.merge_retry_attempts` times before falling back to "completed but not merged" for human resolution — preventing dependents from running against a stale target branch (defaults to `main`, configurable via `git.target_branch`).
- **Autonomous merge-recovery** (v0.8.23, `git.merge_retry_attempts: 3` default; 0 disables): when `apply_on_completion`'s squash to `target_branch` fails (typically an alembic migration filename collision because another task landed first), `_set_merged_after_merge` re-pends the task with `status='pending'` + `merge_retry_count++` + `error_message='merge_retry_<N>: <reason>'` instead of leaving it terminal. The dispatcher's outer wave-loop sidecar (`_pending_merge_retries`) removes the task ID from `total_completed` so the next wave picks it up under `prefer_resumable`. The agent re-runs in the preserved worktree with a Merge Conflict Recovery preamble that explicitly lists conflicting files and resolution steps (alembic-renumber, lockfile regen, code-conflict markers). Symmetric on the **pre-dispatch sync conflict** path: when `sync_worktree_with_target` would have failed with `resume_conflict:`, the dispatcher now re-syncs with `leave_conflicts=True` (markers stay in the worktree), bumps `merge_retry_count`, and dispatches the agent into the conflict-bearing state. Cap-hit on either side falls through to today's preserve-and-warn (`merge_failed: ... (after N attempts)` / `resume_conflict:`) so the irreducible escape hatch for genuinely-intractable conflicts is unchanged. See `docs/superpowers/specs/2026-05-10-autonomous-merge-recovery.md` for the full design rationale.
- **File-claim locks** (`touches_files` on tasks): a task may declare a list of files it intends to edit. Before starting an agent, the dispatcher POSTs a claim to `/file-claims`; if any file is held by another running task, the dispatcher defers this task to the next dispatch cycle. Claims auto-release on task transition to `completed`/`failed`/`paused`. Tasks that don't declare `touches_files` participate in no locking — full backward compatibility.
- **Resume preference** (`git.prefer_resumable: true`, default on): the scheduler prefers pending tasks whose feature branch already has committed work over fresh pending tasks within the same priority tier. Priority still dominates — a higher-priority task always wins — but a tied-priority resumable task is dispatched first so the agent picks up where the previous run left off rather than starting from scratch. A staleness gate (`git.resume_stale_threshold: 50`) skips the preference when `target_branch` has moved more than N commits ahead of the feature branch, on the assumption that catching up that much will likely conflict. Independent of the staleness gate, every dispatched worktree (fresh or resumed) is run through `sync_worktree_with_target` before the agent starts; conflicts there fail the task immediately with a structured `resume_conflict:` error rather than letting the agent run on stale state.
- **Shape-aware scheduling** (`<feature shape>` from spec → `TaskNode.shape`):
  the scheduler honours two architectural shapes from the spec.
  `shape="plugin"` tasks dispatch freely up to `max_concurrency` (their
  `touches_files` are disjoint by construction since each plugin owns
  its own directory).  `shape="core"` tasks **single-flight** — at most
  one cross-cutting task runs at a time, regardless of `max_concurrency`,
  so middleware/error/database changes don't race each other.  Tasks
  without `shape` (legacy specs) fall through to the existing
  concurrency-cap + file-claim-locks behaviour.  Implementation: the
  filter lives in `Scheduler.get_ready_tasks` and is gated on
  `any_core_running` so it's a no-op on the common path.
