from pathlib import Path

import logfire
from minio import Minio

from .s3_location import S3Location


def download_if_not_exists(
    s3_location: S3Location, dst_path: Path, client: Minio
) -> Path:
    if dst_path.exists():
        logfire.debug(f"Local file already exists at {dst_path}, skipping download")
        return dst_path

    dst_path.parent.mkdir(parents=True, exist_ok=True)
    client.fget_object(s3_location.bucket, s3_location.key, dst_path.as_posix())
    return dst_path
