from pydantic_settings import BaseSettings


class _Settings(BaseSettings):
    S3_ENDPOINT: str
    S3_ACCESS_KEY: str
    S3_SECRET_KEY: str


_settings = _Settings()  # ty: ignore[missing-argument]
