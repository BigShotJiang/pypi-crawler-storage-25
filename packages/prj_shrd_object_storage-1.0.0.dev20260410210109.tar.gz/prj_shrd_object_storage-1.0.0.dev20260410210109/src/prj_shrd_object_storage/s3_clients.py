from minio import Minio
from s3fs import S3FileSystem

from .config import _settings


def get_s3_client() -> Minio:
    return Minio(
        endpoint=_settings.S3_ENDPOINT,
        access_key=_settings.S3_ACCESS_KEY,
        secret_key=_settings.S3_SECRET_KEY,
    )


def get_s3_fs() -> S3FileSystem:
    client = get_s3_client()
    scheme = "https" if client._base_url.is_https else "http"
    endpoint_url = f"{scheme}://{client._base_url.host}"

    return S3FileSystem(
        anon=False,
        key=_settings.S3_ACCESS_KEY,
        secret=_settings.S3_SECRET_KEY,
        endpoint_url=endpoint_url,
    )
