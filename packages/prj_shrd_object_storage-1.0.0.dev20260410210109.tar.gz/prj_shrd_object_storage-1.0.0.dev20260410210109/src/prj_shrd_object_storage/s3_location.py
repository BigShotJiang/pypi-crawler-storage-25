from dataclasses import dataclass
from urllib.parse import urlparse

from minio import Minio
from minio.error import S3Error


@dataclass
class S3Location:
    bucket: str
    key: str

    @classmethod
    def from_uri(cls, uri: str) -> "S3Location":
        if not uri.startswith("s3://"):
            raise ValueError(f"Invalid S3 URI: {uri}")

        parsed = urlparse(uri)
        # urlparse leaves a leading slash on the path, which AWS does NOT want in the key
        key = parsed.path.lstrip("/")

        return cls(bucket=parsed.netloc, key=key)

    @property
    def uri(self) -> str:
        return f"s3://{self.bucket}/{self.key}"

    def exists(self, client: Minio) -> bool:
        try:
            client.stat_object(bucket_name=self.bucket, object_name=self.key)
        except S3Error as error:
            if error.code in {
                "NoSuchBucket",
                "NoSuchKey",
                "NoSuchObject",
                "ResourceNotFound",
            }:
                return False
            raise

        return True
