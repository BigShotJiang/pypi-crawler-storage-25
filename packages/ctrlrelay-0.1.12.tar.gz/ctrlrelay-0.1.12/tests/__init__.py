"""Tests for ctrlrelay package."""
