"""Sillok — placeholder reserve.

This is a placeholder package (version 0.0.1) reserving the PyPI name
``sillok`` for the upcoming open-source release. The real implementation
lands in version 0.1.0a1 and beyond.

Project home: https://github.com/sillok-os/sillok
License:      Apache License 2.0 (see LICENSE)
Notice:       see NOTICE for trademark and attribution information

Importing this placeholder package does nothing useful; please track the
project at the GitHub repository above for release announcements.
"""

__version__ = "0.0.1"
__all__ = ["__version__"]
