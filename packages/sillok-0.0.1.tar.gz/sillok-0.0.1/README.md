# sillok (PyPI placeholder reserve)

This is a **placeholder reserve** for the PyPI name `sillok`.
The real implementation lands as `0.1.0a1` and beyond.

- **Project home**: https://github.com/sillok-os/sillok
- **License**: Apache License 2.0 (see [`LICENSE`](LICENSE))
- **Trademark / Attribution**: see [`NOTICE`](NOTICE)

Sillok is a productized implementation of Andrej Karpathy's "LLM Wiki"
3-layer pattern, extended with:

- a **typed pack registry** (Jikji)
- **two-stage routing** (Naru)
- **proposal-only 4-gate governance** (Sangso)
- **multi-tenant overlays** (Beopjeon scope)
- a **UNESCO Memory of the World Triple Anchor** brand identity
  (Sillok 1997 / Jikji 2001 / Janggyeong 2007)

Track the project on GitHub for release announcements; this 0.0.1
placeholder is published only to reserve the PyPI namespace.
