"""CLI entry point: `dunningkit analyze [path]`."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from dunningkit import __version__
from dunningkit.analyze import AnalysisResult, analyze_file


def _fmt_money(cents: int, currency: str) -> str:
    return f"{currency} {cents / 100:,.2f}"


def _format_human(r: AnalysisResult) -> str:
    lines: list[str] = []
    period = (
        f"{r.period_start[:10]} to {r.period_end[:10]}"
        if r.period_start and r.period_end
        else "(period not detected)"
    )
    lines.append(f"Period: {period}")
    lines.append(
        f"Failed charges: {r.total_count} totalling {_fmt_money(r.total_amount_cents, r.currency)}"
    )
    lines.append("")
    if not r.by_code:
        lines.append(
            "No failed charges found in this CSV. Did you filter Status: Failed in Stripe?"
        )
        return "\n".join(lines)

    lines.append("Decline-code breakdown (sorted by frequency):")
    max_w = max(len(c.code) for c in r.by_code) + 2
    for c in r.by_code:
        lines.append(
            f"  {c.code.ljust(max_w)}{c.count:>4}  "
            f"{_fmt_money(c.amount_cents, r.currency):>16}  "
            f"~{_fmt_money(c.recoverable_with_flow_cents, r.currency):>16} recoverable"
        )

    lines.append("")
    lines.append("Recovery summary:")
    lines.append(
        f"  Retries only          ~{_fmt_money(r.recoverable_retry_only_cents, r.currency):>16}  "
        f"({r.recoverable_retry_only_cents * 100 // max(r.total_amount_cents, 1)}% of total)"
    )
    lines.append(
        f"  + Customer flows      ~{_fmt_money(r.recoverable_with_flow_cents, r.currency):>16}  "
        f"({r.recoverable_with_flow_cents * 100 // max(r.total_amount_cents, 1)}% of total)"
    )
    delta = r.recoverable_with_flow_cents - r.recoverable_retry_only_cents
    if delta > 0:
        lines.append("")
        lines.append(
            f"  Customer flows add ~{_fmt_money(delta, r.currency)} of recovery "
            "on top of retries alone."
        )
        lines.append("  This is the dunning opportunity Stripe Smart Retries doesn't capture.")

    lines.append("")
    lines.append("Caveats:")
    lines.append(
        "  - Numbers are estimates from aggregate recovery-rate data; yours may vary 20-30%."
    )
    lines.append("  - Recovery only happens if you actually run the retry + customer flows.")
    lines.append(
        "  - 'unknown' decline codes use a conservative default; check stripe.com/docs/declines"
    )
    return "\n".join(lines)


def _format_json(r: AnalysisResult) -> str:
    return json.dumps(
        {
            "version": __version__,
            "period_start": r.period_start,
            "period_end": r.period_end,
            "currency": r.currency,
            "total_count": r.total_count,
            "total_amount_cents": r.total_amount_cents,
            "recoverable_retry_only_cents": r.recoverable_retry_only_cents,
            "recoverable_with_flow_cents": r.recoverable_with_flow_cents,
            "by_code": [
                {
                    "code": c.code,
                    "count": c.count,
                    "amount_cents": c.amount_cents,
                    "recoverable_retry_only_cents": c.recoverable_retry_only_cents,
                    "recoverable_with_flow_cents": c.recoverable_with_flow_cents,
                }
                for c in r.by_code
            ],
        },
        indent=2,
    )


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="dunningkit",
        description="Failed-payment recovery toolkit for Stripe-using B2B SaaS.",
    )
    parser.add_argument("--version", action="version", version=f"dunningkit {__version__}")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("analyze", help="Analyze a Stripe failed-charges CSV export.")
    p.add_argument("path", help="Path to the CSV file (Stripe Dashboard export)")
    p.add_argument("--json", action="store_true", help="JSON output instead of human-readable.")

    args = parser.parse_args(argv)

    if args.cmd == "analyze":
        path = Path(args.path)
        if not path.exists():
            print(f"error: {path} not found", file=sys.stderr)
            return 2
        result = analyze_file(path)
        print(_format_json(result) if args.json else _format_human(result))
        return 0

    return 0


if __name__ == "__main__":
    sys.exit(main())
