"""Analyze a Stripe failed-charges CSV export.

Stripe's CSV export from Dashboard → Payments → filter by Failed has columns:
  id, Created (UTC), Amount, Amount Refunded, Currency, Captured, Converted Amount,
  Converted Amount Refunded, Converted Currency, Decline Reason Code, Description,
  Customer ID, Customer Description, Customer Email, ...

We only need a few of these. Be lenient about column naming variants.
"""

from __future__ import annotations

import csv
from collections import Counter
from dataclasses import dataclass
from io import TextIOBase
from pathlib import Path

from dunningkit.recovery_rates import for_code


@dataclass(frozen=True)
class FailedCharge:
    amount_cents: int
    currency: str
    decline_code: str
    customer_email: str | None


@dataclass
class CodeStat:
    code: str
    count: int
    amount_cents: int
    recoverable_retry_only_cents: int
    recoverable_with_flow_cents: int


@dataclass
class AnalysisResult:
    period_start: str | None
    period_end: str | None
    total_count: int
    total_amount_cents: int
    by_code: list[CodeStat]
    recoverable_retry_only_cents: int
    recoverable_with_flow_cents: int
    currency: str  # the dominant currency (or "MIXED" if more than one)


# Map the column-name variants Stripe has used over the years.
COL_ALIASES = {
    "amount": ["Amount", "amount", "Converted Amount"],
    "currency": ["Currency", "currency", "Converted Currency"],
    "decline_code": ["Decline Reason Code", "decline_code", "Decline Code", "Reason Code"],
    "customer_email": ["Customer Email", "customer_email", "Email"],
    "created": ["Created (UTC)", "Created", "created", "Created Date"],
}


def _resolve_column(headers: list[str], aliases: list[str]) -> str | None:
    for a in aliases:
        if a in headers:
            return a
    return None


def parse_csv(stream: TextIOBase) -> tuple[list[FailedCharge], str | None, str | None]:
    """Parse a Stripe CSV stream. Returns (rows, period_start_iso, period_end_iso)."""
    reader = csv.DictReader(stream)
    headers: list[str] = list(reader.fieldnames or [])
    amount_col = _resolve_column(headers, COL_ALIASES["amount"])
    currency_col = _resolve_column(headers, COL_ALIASES["currency"])
    code_col = _resolve_column(headers, COL_ALIASES["decline_code"])
    email_col = _resolve_column(headers, COL_ALIASES["customer_email"])
    created_col = _resolve_column(headers, COL_ALIASES["created"])

    if amount_col is None or code_col is None:
        raise ValueError(
            "Couldn't find an Amount or Decline-Code column in the CSV. "
            "Expected Stripe Dashboard export format. Headers found: " + ", ".join(headers)
        )

    rows: list[FailedCharge] = []
    dates: list[str] = []
    for raw in reader:
        amt_str = (raw.get(amount_col) or "").strip()
        if not amt_str:
            continue
        try:
            # Stripe export amounts are typically in major-units float ("19.99")
            amount = float(amt_str)
        except ValueError:
            continue
        amount_cents = round(amount * 100)
        currency = (raw.get(currency_col) if currency_col else "USD") or "USD"
        code = (raw.get(code_col) or "").strip() or "unknown"
        email = (raw.get(email_col) if email_col else None) or None
        if created_col:
            d = (raw.get(created_col) or "").strip()
            if d:
                dates.append(d)
        rows.append(FailedCharge(amount_cents, currency.upper(), code, email))

    period_start = min(dates) if dates else None
    period_end = max(dates) if dates else None
    return rows, period_start, period_end


def analyze(
    rows: list[FailedCharge], period_start: str | None = None, period_end: str | None = None
) -> AnalysisResult:
    by_code_counter: Counter[str] = Counter()
    by_code_amount: dict[str, int] = {}
    currencies: Counter[str] = Counter()

    for r in rows:
        by_code_counter[r.decline_code] += 1
        by_code_amount[r.decline_code] = by_code_amount.get(r.decline_code, 0) + r.amount_cents
        currencies[r.currency] += 1

    by_code: list[CodeStat] = []
    total_recoverable_retry = 0
    total_recoverable_flow = 0
    for code, n in by_code_counter.most_common():
        amt = by_code_amount[code]
        prof = for_code(code)
        retry_only = amt * prof.retry_only_pct // 100
        with_flow = amt * prof.with_flow_pct // 100
        total_recoverable_retry += retry_only
        total_recoverable_flow += with_flow
        by_code.append(CodeStat(code, n, amt, retry_only, with_flow))

    if len(currencies) == 0:
        dominant_currency = "USD"
    elif len(currencies) == 1:
        dominant_currency = next(iter(currencies))
    else:
        dominant_currency = "MIXED"

    return AnalysisResult(
        period_start=period_start,
        period_end=period_end,
        total_count=len(rows),
        total_amount_cents=sum(r.amount_cents for r in rows),
        by_code=by_code,
        recoverable_retry_only_cents=total_recoverable_retry,
        recoverable_with_flow_cents=total_recoverable_flow,
        currency=dominant_currency,
    )


def analyze_file(path: Path) -> AnalysisResult:
    with path.open() as f:
        rows, ps, pe = parse_csv(f)
    return analyze(rows, ps, pe)
