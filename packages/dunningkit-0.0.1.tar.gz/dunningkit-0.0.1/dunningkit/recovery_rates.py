"""Recovery-rate library — aggregate estimates per Stripe decline code.

Numbers are aggregate estimates from the dunning-tool category, conservatively
chosen. Yours may vary 20-30% based on geography, plan tier, and card-issuer mix.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class CodeProfile:
    code: str
    name: str
    retry_only_pct: int  # recovery % from retries alone
    with_flow_pct: int  # recovery % with retries + customer-facing flow
    flow: str  # "card-update" | "contact-issuer" | "manual-review" | "alternative-payment" | "none"


PROFILES: dict[str, CodeProfile] = {
    p.code: p
    for p in [
        CodeProfile("insufficient_funds", "Insufficient funds", 70, 75, "none"),
        CodeProfile("expired_card", "Expired card", 5, 85, "card-update"),
        CodeProfile("generic_decline", "Generic decline", 25, 40, "contact-issuer"),
        CodeProfile("do_not_honor", "Do not honor", 30, 50, "contact-issuer"),
        CodeProfile("card_velocity_exceeded", "Card velocity exceeded", 10, 55, "none"),
        CodeProfile("incorrect_cvc", "Incorrect CVC", 5, 70, "card-update"),
        CodeProfile("incorrect_number", "Incorrect card number", 0, 70, "card-update"),
        CodeProfile("invalid_cvc", "Invalid CVC", 0, 70, "card-update"),
        CodeProfile("invalid_expiry_year", "Invalid expiry year", 0, 75, "card-update"),
        CodeProfile("invalid_expiry_month", "Invalid expiry month", 0, 75, "card-update"),
        CodeProfile("processing_error", "Processing error", 80, 85, "none"),
        CodeProfile("fraudulent", "Fraudulent", 5, 30, "manual-review"),
        CodeProfile("lost_card", "Lost card", 0, 75, "card-update"),
        CodeProfile("stolen_card", "Stolen card", 0, 75, "card-update"),
        CodeProfile("pickup_card", "Pickup card", 0, 65, "card-update"),
        CodeProfile(
            "currency_not_supported", "Currency not supported", 5, 40, "alternative-payment"
        ),
        CodeProfile("card_not_supported", "Card type not supported", 10, 60, "alternative-payment"),
        CodeProfile(
            "authentication_required", "Authentication required (3DS)", 5, 75, "card-update"
        ),
        CodeProfile("call_issuer", "Call issuer", 15, 50, "contact-issuer"),
        CodeProfile("transaction_not_allowed", "Transaction not allowed", 5, 50, "card-update"),
        CodeProfile(
            "withdrawal_count_limit_exceeded", "Withdrawal count limit exceeded", 30, 60, "none"
        ),
        CodeProfile("service_not_allowed", "Service not allowed", 5, 50, "card-update"),
    ]
}

# Codes we don't have profiles for fall back to this conservative estimate.
UNKNOWN_PROFILE = CodeProfile("unknown", "Unknown decline code", 15, 40, "card-update")


def for_code(code: str) -> CodeProfile:
    """Return the profile for a code, or a conservative default if we don't know it."""
    return PROFILES.get(code, UNKNOWN_PROFILE)
