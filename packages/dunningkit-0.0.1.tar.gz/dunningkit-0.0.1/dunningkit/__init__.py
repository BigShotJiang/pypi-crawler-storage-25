"""DunningKit — failed-payment recovery toolkit for Stripe-using B2B SaaS."""

__version__ = "0.0.1"
