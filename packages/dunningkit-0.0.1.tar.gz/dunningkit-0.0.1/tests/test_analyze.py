"""Tests for the CSV analyzer + recovery-rate library."""

from __future__ import annotations

from pathlib import Path

from dunningkit.analyze import analyze_file
from dunningkit.recovery_rates import for_code

FIXTURE = Path(__file__).parent / "fixtures" / "sample-stripe-failed.csv"


def test_parses_fixture() -> None:
    r = analyze_file(FIXTURE)
    assert r.total_count == 7
    # 99 + 99 + 249 + 249 + 599 + 99 + 29 = 1423
    assert r.total_amount_cents == 142300
    assert r.currency == "USD"


def test_decline_code_breakdown() -> None:
    r = analyze_file(FIXTURE)
    codes = {c.code: c for c in r.by_code}
    assert codes["insufficient_funds"].count == 2
    assert codes["expired_card"].count == 2
    assert codes["do_not_honor"].count == 1
    assert codes["generic_decline"].count == 1
    assert codes["fraudulent"].count == 1


def test_recovery_estimates_match_profiles() -> None:
    r = analyze_file(FIXTURE)
    codes = {c.code: c for c in r.by_code}
    # expired_card: 2 charges * $249 = $498 = 49800 cents
    # with-flow profile is 85% -> 49800 * 85 // 100 = 42330
    assert codes["expired_card"].recoverable_with_flow_cents == 42330


def test_for_code_unknown_falls_back() -> None:
    p = for_code("a_code_that_does_not_exist")
    # Don't return a "fake" 100% — be conservative
    assert p.retry_only_pct < 50
    assert p.with_flow_pct < 50


def test_period_detected() -> None:
    r = analyze_file(FIXTURE)
    assert r.period_start is not None
    assert r.period_end is not None
    assert r.period_start[:10] == "2026-04-02"
    assert r.period_end[:10] == "2026-04-22"


def test_total_recoverable_with_flow_exceeds_retry_only() -> None:
    r = analyze_file(FIXTURE)
    # The whole thesis: customer flows recover more than retries alone.
    assert r.recoverable_with_flow_cents > r.recoverable_retry_only_cents
