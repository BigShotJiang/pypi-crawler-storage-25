import os
from threading import Thread
from collections import defaultdict
from pathlib import Path
import numpy as np
import matplotlib

from PySide6.QtCore import QObject, Signal
from PySide6.QtWidgets import QMessageBox

# import fitspy
from fitspy.core.spectra import Spectra
from fitspy.core.spectrum import Spectrum, empty_expr
from fitspy.core.spectra_map import SpectraMap
from fitspy.core.utils import closest_index, closest_item
from fitspy.core.baseline_methods import get_baseline_method_meta
from fitspy.apps.interactive_bounds_pg import InteractiveBounds
from fitspy.apps.pyside import DEFAULTS

CMAP = matplotlib.colormaps['tab10']
LABEL_OFFSET_RATIO = 0.005  # Ratio to offset label above the peak
YLIM_BUFFER_RATIO = 0.05  # Ratio to extend y-axis limit


class Model(QObject):
    decodedSpectraMap = Signal(str, list)
    mapSwitched = Signal(object)
    spectrumLoaded = Signal(str)
    spectrumDeleted = Signal(object)
    spectraMapDeleted = Signal(str)
    baselinePointsChanged = Signal(list)
    refreshPlot = Signal()
    askConfirmation = Signal(str, object, tuple, dict)
    PeaksChanged = Signal(object)
    BkgsChanged = Signal(object)
    progressUpdated = Signal(object, int, int)
    colorizeFromFitStatus = Signal(dict)
    showToast = Signal(str, str, str)

    def __init__(self):
        super().__init__()
        self._spectra = Spectra()
        self.current_map = None
        self.current_spectra = []
        self.current_mode = None  # plot click mode
        self.peak_model = None
        self.tmp = []
        self.linewidth = 0.5
        self.lines = []
        self.nearest_lines = []
        self.ibounds = None
        self._Y = []

    def set_spectrum_attr(self, fname, attr, value):
        # .json model's "dummy spectrum" is not stored in self.spectra
        if fname == self.current_spectra[0].fname:
            spectrum = self.current_spectra[0]
        else:
            spectrum = self.spectra.get_objects(fname)[0]

        attrs = attr.split(".")
        for attr in attrs[:-1]:
            spectrum = getattr(spectrum, attr)
        setattr(spectrum, attrs[-1], value)

    @property
    def spectra(self):
        return self._spectra

    def load_spectra(self, models):
        """ Load spectra from 'models' related to a .json file """
        self._spectra = Spectra.load(dict_spectra=models, preprocess=True)

        for spectrum in self.spectra:
            self.spectrumLoaded.emit(spectrum.fname)

        for spectra_map in self.spectra.spectra_maps:
            fname = spectra_map.fname
            fnames = [spectrum.fname for spectrum in spectra_map]
            self.decodedSpectraMap.emit(fname, fnames)

    def load_spectrum(self, fnames):
        """Load the given list of file names as spectra"""
        for fname in fnames:
            fname = os.path.normpath(fname)
            try:
                spectrum = Spectrum()
                spectrum.load_profile(fname)
                self.spectra.append(spectrum)
                self.spectrumLoaded.emit(fname)
            except Exception:
                self.showToast.emit("ERROR", "Failed to load spectrum", fname)

    def del_spectrum(self, items):
        """
        Remove the spectrum(s) with the given file name(s).

        Parameters
        ----------
        items: dict
            Dictionary where keys can be None or a spectramap fname,
            and values are always a list of fname.
        """
        deleted_spectra = defaultdict(list)

        for _, fnames in items.items():
            for fname in fnames:
                spectrum, parent = self.spectra.get_objects(fname)
                parent.remove(spectrum)

                parent_fname = getattr(parent, "fname", None)
                deleted_spectra[parent_fname].append(fname)

        self.spectrumDeleted.emit(deleted_spectra)

    def load_map(self, fname):
        """Create a Spectra object from a fname and add it to the spectra list"""
        # from fitspy.core import SpectraMap
        fname = os.path.normpath(fname)

        try:
            spectra_map = SpectraMap.load_map(fname)
            self.spectra.spectra_maps.append(spectra_map)

            fnames = [spectrum.fname for spectrum in spectra_map]
            self.decodedSpectraMap.emit(fname, fnames)
        except Exception:
            QMessageBox.warning(None, "Warning", f"FAILED to load: {Path(fname).name}")

    def del_map(self, fname):
        """Remove the spectramap with the given file name"""
        for spectramap in self.spectra.spectra_maps:
            if spectramap.fname == fname:
                self.spectra.spectra_maps.remove(spectramap)
                self.spectraMapDeleted.emit(fname)
                break

    def reinit_spectra(self, fnames):
        fit_status_dict = {}
        for fname in fnames:
            spectrum = self.spectra.get_objects(fname)[0]
            spectrum.reinit()
            fit_status_dict[fname] = None
        self.colorizeFromFitStatus.emit(fit_status_dict)

    def switch_map(self, fname):
        if fname is None:
            self.current_map = None
            self.mapSwitched.emit(None)
            return

        for spectramap in self.spectra.spectra_maps:
            if spectramap.fname == fname:
                self.current_map = spectramap
                self.mapSwitched.emit(spectramap)
                break

    def add_outlier(self, x):
        spectrum = self.current_spectra[0]
        ind = closest_index(spectrum.x0, x)
        spectrum.outliers_inds += [ind]
        self.refreshPlot.emit()

    def del_outlier(self, x):
        spectrum = self.current_spectra[0]
        if len(spectrum.outliers_inds) == 0:
            return
        dist_min = np.inf
        for i, ind in enumerate(spectrum.outliers_inds):
            dist = abs(spectrum.x0[ind] - x)
            if dist < dist_min:
                dist_min, ind_min = dist, i
        spectrum.outliers_inds.pop(ind_min)
        self.refreshPlot.emit()

    def add_baseline_point(self, x, y):
        first_spectrum = self.current_spectra[0]
        use_points = get_baseline_method_meta(first_spectrum.baseline.mode).get(
            "use_points", False
        )
        if not use_points:
            self.showToast.emit(
                "info",
                "Baseline Mode",
                "Selected baseline method does not support points.",
            )
            return

        if first_spectrum.baseline.is_subtracted:
            self.askConfirmation.emit(
                "This action will reinitialize the spectrum. Continue?",
                self._add_baseline_point, (x, y), {})
            return

        self._add_baseline_point(x, y)

    def _add_baseline_point(self, x, y):
        first_spectrum = self.current_spectra[0]
        if first_spectrum.baseline.is_subtracted:
            for spectrum in self.current_spectra:
                spectrum.load_profile(spectrum.fname)
                spectrum.apply_range()
                spectrum.baseline.is_subtracted = False
                spectrum.baseline.points = [[], []]
                spectrum.baseline.add_point(x, y)
        for spectrum in self.current_spectra:
            spectrum.baseline.add_point(x, y)

        self.baselinePointsChanged.emit(first_spectrum.baseline.points)

    def del_baseline_point(self, x):
        first_spectrum = self.current_spectra[0]
        if len(first_spectrum.baseline.points[0]) == 0:
            return
        dist_min = np.inf
        for i, x0 in enumerate(first_spectrum.baseline.points[0]):
            dist = abs(x0 - x)
            if dist < dist_min:
                dist_min, ind_min = dist, i
        first_spectrum.baseline.points[0].pop(ind_min)
        first_spectrum.baseline.points[1].pop(ind_min)
        self.baselinePointsChanged.emit(first_spectrum.baseline.points)

    def set_baseline_points(self, points):
        if self.current_spectra:
            self.current_spectra[0].baseline.points = points
            self.refreshPlot.emit()

    def load_baseline(self, fname):
        if self.current_spectra:
            self.current_spectra[0].baseline.load_baseline(fname)
            self.refreshPlot.emit()

    def add_peak_model(self, model, x0=None):
        if self.current_spectra:
            spectrum = self.current_spectra[0]
            x0 = x0 if x0 is not None else spectrum.x.mean()
            spectrum.add_peak_model(model, x0=x0)
            self.PeaksChanged.emit(spectrum)
            self.refreshPlot.emit()

    def add_bkg_model(self, bkg_name):
        if self.current_spectra:
            spectrum = self.current_spectra[0]
            spectrum.add_bkg_model(bkg_name)
            self.BkgsChanged.emit(spectrum)
            self.refreshPlot.emit()

    def refresh(self):
        self.PeaksChanged.emit(self.current_spectra[0])
        self.refreshPlot.emit()

    def del_peak_point(self, x):
        first_spectrum = self.current_spectra[0]
        if len(first_spectrum.peak_models) > 0:
            dist_min = np.inf
            for i, peak_model in enumerate(first_spectrum.peak_models):
                x0 = peak_model.param_hints["x0"]["value"]
                dist = abs(x0 - x)
                if dist < dist_min:
                    dist_min, ind_min = dist, i
            first_spectrum.del_peak_model(ind_min)
        self.PeaksChanged.emit(first_spectrum)
        self.refreshPlot.emit()

    def highlight_spectrum(self, ax, event):
        """Select the spectrum closest to the cursor among several spectra."""
        mouse_point = ax.vb.mapSceneToView(event.scenePos())
        Y = np.asarray(self._Y)
        X = np.tile(self.current_spectra[0].x, (Y.shape[0], 1))
        dist = np.sqrt((X - mouse_point.x()) ** 2 + (Y - mouse_point.y()) ** 2)
        ind, _ = np.unravel_index(np.argmin(dist), dist.shape)
        spectrum = self.current_spectra[ind]
        return [spectrum.fname]

    def highlight_peak(self, ax, peak_index, color):
        """Highlight a peak by its index (for table hover/click)."""
        spectrum = self.current_spectra[0]
        model = spectrum.peak_models[peak_index]
        text = []
        for key in ['x0', 'ampli', 'fwhm', 'fwhm_l', 'fwhm_r']:
            if key in model.param_hints:
                text.append(f"{key}: {model.param_hints[key]['value']:.4g}")
        text = "\n".join(text)

        x, y = model.param_hints['x0']['value'], model.param_hints['ampli']['value']
        bbox = {"facecolor": 'w', "edgecolor": color}
        self.tmp.append(ax.annotate(text, xy=(x, y), xycoords="data", bbox=bbox, va="bottom"))

        ax.draw_idle()

    def highlight(self, ax, event=None, index=None):
        """Highlight peaks and secondaries spectra."""
        # Remove previous highlights
        self.clear_highlight(ax)

        peaks = self.get_peaks_lines()
        secondaries = self.get_secondaries_lines()
        if index is not None and 0 <= index < len(peaks):
            peak = peaks[index]
            pen = peak.opts['pen']
            color = pen.color().name()
            self.tmp.append(ax.plot(*peak.getData(), c=color, ls=pen.style(), lw=3)[1])
            self.highlight_peak(ax, index, color)
            ax.draw_idle()

        if event:
            for line in peaks + secondaries:
                if hasattr(line, 'mouseShape') and line.mouseShape().contains(line.mapFromScene(event)):
                    pen = line.opts['pen']
                    color = pen.color().name()
                    self.tmp.append(ax.plot(*line.getData(), c=color, ls=pen.style(), lw=3)[1])

                    if line in peaks:
                        self.highlight_peak(ax, peaks.index(line), color)
                    ax.draw_idle()
                    break

    def clear_highlight(self, ax):
        for item in self.tmp:
            ax.plot_item.removeItem(item)
        self.tmp = []

    def on_motion(self, ax, event):
        self.highlight(ax, event)

    def preprocess(self):
        for spectrum in self.current_spectra:
            spectrum.preprocess()

    def get_peaks_lines(self):
        return [line for line in self.lines if "Peak" in (line.opts['name'] or "")]

    def get_secondaries_lines(self):
        return [line for line in self.lines if "secondaries_spectra" in (line.opts['name'] or "")]

    def get_view_limits(self, ax):
        """Get the current view limits of the plot."""
        if not ax.has_data():
            return None, None
        xlim = ax.get_xlim()
        ylim = ax.get_ylim()
        return xlim, ylim

    def store_original_view_limits(self, ax):
        self.original_xlim, self.original_ylim = self.get_view_limits(ax)

    def _apply_log_ylimits(self, ax):
        y_data = np.concatenate([line.get_ydata()[line.get_ydata() > 0] for line in ax.lines
                                 if "Spectrum" in (line.get_label() or "")])
        if len(y_data):
            ax.set_ylim(y_data.min() * 0.1, y_data.max() * 10)

    def init_ibounds(self, ax):
        self.ibounds = InteractiveBounds(ax,
                                         self.current_spectra[0],
                                         self.peak_model,
                                         cmap=DEFAULTS["peaks_cmap"],
                                         bind_func=self.refresh)

    # @measure_time
    def update_spectraplot(self, ax, view_options):
        """Update the plot with the current spectra"""
        if not hasattr(self, "original_xlim") or not hasattr(self, "original_ylim"):
            self.store_original_view_limits(ax)

        ax.clear()
        self.tmp = []

        if not self.current_spectra:
            ax.draw_idle()
            return

        # 'interactive' baseline points management
        spectrum = self.current_spectra[0]
        baseline = spectrum.baseline
        if not baseline.is_subtracted:
            baseline.plot(ax, spectrum.x, spectrum.y, attached=baseline.attached, label="_Baseline")

        self.lines = []
        spectrum = self.current_spectra[0]
        self.lines += spectrum.plot(ax,
                                    show_weights=view_options["Weights"],
                                    show_outliers=view_options["Outliers"],
                                    show_outliers_limit=view_options["Outliers limits"],
                                    show_negative_values=view_options["Negative values"],
                                    show_peak_models=view_options["Peaks"],
                                    show_peak_decomposition=view_options["Peak decomposition"],
                                    show_noise_level=view_options["Noise level"],
                                    show_baseline=view_options["Baseline"],
                                    show_background=view_options["Background"],
                                    show_result=view_options["Fit"],
                                    subtract_baseline=view_options["Subtract bkg+baseline"],
                                    subtract_bkg=view_options["Subtract bkg+baseline"],
                                    cmap_peaks=DEFAULTS['peaks_cmap'])
        if view_options.get("Residual", False):
            spectrum.plot_residual(ax)
        if view_options.get("Legend", False):
            ax.legend(loc=1)

        subtract_baseline = subtract_bkg = view_options["Subtract bkg+baseline"]
        self._Y = [spectrum.eval_xy(subtract_baseline, subtract_bkg)[1]]
        if len(self.current_spectra) > 1:
            xs, ys = [], []
            for spectrum in self.current_spectra[1:]:
                x, y = spectrum.eval_xy(subtract_baseline, subtract_bkg)
                xs.extend(x)
                ys.extend(y)
                xs.append(np.nan)
                ys.append(np.nan)
                self._Y.append(y)
            self.lines.append(ax.plot(xs, ys, lw=0.5, zorder=0, connect='finite', label="secondaries_spectra")[0])

            if view_options["Outliers"]:
                x_outliers, y_outliers = [], []
                for spectrum in self.current_spectra:
                    xo, yo = spectrum.eval_outliers(subtract_baseline)
                    x_outliers.extend(xo)
                    y_outliers.extend(yo)
                ax.plot(x_outliers, y_outliers, 'o', c='lime', mec='k', label='Outliers')

        spectrum = self.current_spectra[0]

        self.line_bkg_visible = view_options.get("Background", False) and bool(spectrum.bkg_models)

        if self.ibounds is not None:
            self.ibounds.set_cmap(DEFAULTS["peaks_cmap"])
            self.ibounds.update()  # necessary after ax.clear()
            self.ibounds.set_visible(view_options["Interactive bounds"])

        # Add Peak labels annotations
        if view_options.get("Peak labels", True):
            dy_label = LABEL_OFFSET_RATIO * spectrum.y.max()
            annotation_y = []
            for i, label in enumerate(spectrum.peak_labels):
                if not label:
                    continue
                model = spectrum.peak_models[i]
                x_label = model.param_hints["x0"]["value"]
                with empty_expr(model):
                    params = model.make_params()
                y_label = model.eval(params, x=x_label)

                if view_options.get("Subtract bkg+baseline") and spectrum.bkg_models:
                    for bkg_model in spectrum.bkg_models:
                        y_label -= bkg_model.eval(bkg_model.make_params(), x=x_label)

                xy = (x_label, y_label + dy_label)
                annotation_y.append(y_label + 2 * dy_label)
                ax.annotate(label,
                            xy=xy,
                            xycoords="data",
                            textcoords="offset points",
                            ha="center",
                            va="top",
                            size=14,
                            arrowprops={"fc": 'k', "arrowstyle": '->'},
                            annotation_clip=True)

            # Adjust y-axis to contain peak labels
            if annotation_y:
                max_annotation_y = max(annotation_y)
                current_ylim = ax.get_ylim()
                if max_annotation_y > current_ylim[1]:
                    ax.set_ylim(top=max_annotation_y + YLIM_BUFFER_RATIO * spectrum.y.max())

        ax.plot_item.setLogMode(x=view_options.get("X-log", False),
                                y=view_options.get("Y-log", False))

        ax.draw_idle()

    def apply_model(self, model_dict=None, fnames=None, ncpus=None):
        """Apply model to the selected spectra"""
        if model_dict is None:
            self.showToast("error", "No model has been loaded", "")
            return

        nfiles = len(fnames)
        fit_status = {fname: None for fname in fnames}
        for fname in fnames:
            spectrum, _ = self.spectra.get_objects(fname)
            # spectrum.set_attributes(model_dict)
            fit_status[fname] = spectrum
        self.spectra.pbar_index = 0
        show_progressbar = False

        args = (model_dict, fnames, ncpus, show_progressbar)
        thread = Thread(target=self.spectra.apply_model, args=args)
        thread.start()
        self.progressUpdated.emit(self.spectra, nfiles, ncpus)
        thread.join()

        fit_status = {fname: spectrum.result_fit for fname, spectrum in fit_status.items()}
        self.colorizeFromFitStatus.emit(fit_status)
        self.PeaksChanged.emit(self.current_spectra[0])
        self.refreshPlot.emit()

    def save_models(self, fname_json, fnames=None):
        self.spectra.save(fname_json, fnames=fnames)
