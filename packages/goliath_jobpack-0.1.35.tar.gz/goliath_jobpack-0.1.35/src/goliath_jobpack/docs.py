"""Generate markdown and HTML documentation from goliath-jobpack source code."""
from __future__ import annotations

import ast
import textwrap
from dataclasses import dataclass, field
from pathlib import Path

import click

SRC_DIR = Path(__file__).parent

# Modules to document, in display order
DOCUMENTED_MODULES = [
    ("config", "Configuration"),
    ("builder", "Builder"),
    ("uploader", "Uploader"),
    ("utils", "Utilities"),
]

HTML_TEMPLATE = """\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>goliath-jobpack docs</title>
<style>
  :root {{
    --bg: #0d1117;
    --surface: #161b22;
    --surface-hover: #1c2129;
    --border: #30363d;
    --text: #c9d1d9;
    --text-muted: #8b949e;
    --accent: #58a6ff;
    --accent-hover: #79c0ff;
    --green: #3fb950;
    --orange: #d29922;
    --red: #f85149;
    --purple: #bc8cff;
    --code-bg: #1c2129;
    --sidebar-w: 280px;
  }}
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  html {{ scroll-behavior: smooth; scroll-padding-top: 80px; }}
  body {{
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Helvetica, Arial, sans-serif;
    background: var(--bg);
    color: var(--text);
    line-height: 1.65;
  }}

  /* Sidebar */
  .sidebar {{
    position: fixed;
    top: 0; left: 0;
    width: var(--sidebar-w);
    height: 100vh;
    overflow-y: auto;
    background: var(--surface);
    border-right: 1px solid var(--border);
    padding: 1.5rem 1rem;
    z-index: 100;
    transition: transform 0.3s ease;
  }}
  .sidebar-logo {{
    font-size: 1.1rem;
    font-weight: 700;
    color: #f0f6fc;
    margin-bottom: 0.25rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
  }}
  .sidebar-logo .badge {{
    font-size: 0.65rem;
    background: var(--accent);
    color: #0d1117;
    padding: 2px 6px;
    border-radius: 4px;
    font-weight: 600;
    letter-spacing: 0.5px;
  }}
  .sidebar-sub {{
    font-size: 0.75rem;
    color: var(--text-muted);
    margin-bottom: 1.5rem;
  }}
  .sidebar h4 {{
    font-size: 0.7rem;
    text-transform: uppercase;
    letter-spacing: 1px;
    color: var(--text-muted);
    margin: 1.25rem 0 0.5rem;
  }}
  .sidebar ul {{ list-style: none; }}
  .sidebar li {{ margin: 1px 0; }}
  .sidebar a {{
    display: block;
    padding: 5px 10px;
    color: var(--text-muted);
    text-decoration: none;
    font-size: 0.82rem;
    border-radius: 6px;
    transition: all 0.15s;
  }}
  .sidebar a:hover, .sidebar a.active {{
    color: var(--accent);
    background: var(--surface-hover);
  }}

  /* Mobile toggle */
  .menu-toggle {{
    display: none;
    position: fixed;
    top: 12px; left: 12px;
    z-index: 200;
    background: var(--surface);
    border: 1px solid var(--border);
    color: var(--text);
    padding: 8px 12px;
    border-radius: 8px;
    cursor: pointer;
    font-size: 1rem;
  }}

  /* Main content */
  .main {{
    margin-left: var(--sidebar-w);
    padding: 2.5rem 3rem;
    max-width: 960px;
  }}

  /* Typography */
  h1 {{
    font-size: 2rem;
    color: #f0f6fc;
    margin-bottom: 0.5rem;
    padding-bottom: 0.5rem;
    border-bottom: 2px solid var(--border);
  }}
  .hero-sub {{
    color: var(--text-muted);
    font-size: 1rem;
    margin-bottom: 2rem;
    line-height: 1.6;
  }}
  h2 {{
    color: var(--accent);
    font-size: 1.5rem;
    margin-top: 3rem;
    margin-bottom: 1rem;
    padding-bottom: 0.4rem;
    border-bottom: 1px solid var(--border);
  }}
  h3 {{
    color: var(--green);
    font-size: 1.15rem;
    margin-top: 2rem;
    margin-bottom: 0.75rem;
  }}
  h4 {{
    color: var(--purple);
    font-size: 1rem;
    margin-top: 1.5rem;
    margin-bottom: 0.5rem;
  }}
  p {{ margin-bottom: 1rem; }}
  a {{ color: var(--accent); }}
  ul, ol {{ margin: 0.5rem 0 1rem; padding-left: 1.5rem; }}
  li {{ margin: 0.25rem 0; }}

  /* Tables */
  table {{
    width: 100%;
    border-collapse: collapse;
    margin: 1rem 0 1.5rem;
    font-size: 0.88rem;
  }}
  th {{
    background: var(--code-bg);
    color: var(--accent);
    text-align: left;
    padding: 0.6rem 0.75rem;
    border-bottom: 2px solid var(--border);
    font-weight: 600;
    white-space: nowrap;
  }}
  td {{
    padding: 0.5rem 0.75rem;
    border-bottom: 1px solid var(--border);
    vertical-align: top;
  }}
  tr:nth-child(even) td {{ background: rgba(22, 27, 34, 0.5); }}
  td code, th code {{
    background: var(--code-bg);
    padding: 0.15rem 0.4rem;
    border-radius: 4px;
    font-size: 0.82rem;
    font-family: 'SF Mono', 'Fira Code', 'Cascadia Code', monospace;
  }}

  /* Code blocks */
  pre {{
    background: var(--code-bg);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 1rem 1.25rem;
    overflow-x: auto;
    margin: 1rem 0 1.5rem;
    font-size: 0.85rem;
    line-height: 1.55;
  }}
  code {{
    font-family: 'SF Mono', 'Fira Code', 'Cascadia Code', monospace;
    font-size: 0.85rem;
  }}
  :not(pre) > code {{
    background: var(--code-bg);
    padding: 0.15rem 0.45rem;
    border-radius: 4px;
    color: var(--orange);
  }}

  /* Module cards */
  .module {{
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 10px;
    padding: 1.25rem 1.5rem;
    margin: 1rem 0 1.5rem;
  }}
  .module h4 {{ margin-top: 0; }}
  .module p:last-child {{ margin-bottom: 0; }}

  /* Badges */
  .badge-type {{
    display: inline-block;
    font-size: 0.7rem;
    font-weight: 600;
    padding: 2px 8px;
    border-radius: 4px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-left: 8px;
    vertical-align: middle;
  }}
  .badge-class {{ background: #1f6feb33; color: var(--accent); border: 1px solid #1f6feb55; }}
  .badge-func  {{ background: #3fb95033; color: var(--green); border: 1px solid #3fb95055; }}
  .badge-const {{ background: #d2992233; color: var(--orange); border: 1px solid #d2992255; }}

  /* Blockquote */
  blockquote {{
    border-left: 3px solid var(--accent);
    padding: 0.75rem 1rem;
    margin: 1rem 0 1.5rem;
    background: var(--surface);
    border-radius: 0 8px 8px 0;
    color: var(--text-muted);
  }}

  /* Horizontal rule */
  hr {{
    border: none;
    border-top: 1px solid var(--border);
    margin: 2.5rem 0;
  }}

  /* Footer */
  .footer {{
    margin-top: 4rem;
    padding: 1.5rem 0;
    border-top: 1px solid var(--border);
    color: var(--text-muted);
    font-size: 0.8rem;
    text-align: center;
  }}

  /* Responsive */
  @media (max-width: 768px) {{
    .sidebar {{ transform: translateX(-100%); }}
    .sidebar.open {{ transform: translateX(0); }}
    .menu-toggle {{ display: block; }}
    .main {{ margin-left: 0; padding: 1.5rem 1.25rem; padding-top: 3.5rem; }}
  }}
</style>
</head>
<body>

<button class="menu-toggle" onclick="document.querySelector('.sidebar').classList.toggle('open')" aria-label="Toggle navigation">&#9776;</button>

<nav class="sidebar">
  <div class="sidebar-logo">goliath-jobpack <span class="badge">DOCS</span></div>
  <div class="sidebar-sub">Build &amp; upload job packages for Goliath</div>
{sidebar}
</nav>

<div class="main">
{body}

<div class="footer">
  Generated on <span id="gen-date"></span> &mdash; goliath-jobpack documentation
</div>
</div>

<script>
  document.getElementById('gen-date').textContent =
    new Date().toISOString().replace('T', ' ').slice(0, 19) + ' UTC';
</script>

<script>
(function() {{
  var links = document.querySelectorAll('.sidebar a[href^="#"]');
  var sections = [];
  links.forEach(function(a) {{
    var id = a.getAttribute('href').slice(1);
    var el = document.getElementById(id);
    if (el) sections.push({{ el: el, a: a }});
  }});

  function update() {{
    var current = sections[0];
    var scrollY = window.scrollY + 120;
    for (var i = 0; i < sections.length; i++) {{
      if (sections[i].el.offsetTop <= scrollY) current = sections[i];
    }}
    links.forEach(function(a) {{ a.classList.remove('active'); }});
    if (current) current.a.classList.add('active');
  }}

  window.addEventListener('scroll', update, {{ passive: true }});
  update();

  links.forEach(function(a) {{
    a.addEventListener('click', function() {{
      document.querySelector('.sidebar').classList.remove('open');
    }});
  }});
}})();
</script>

</body>
</html>
"""


# ---------------------------------------------------------------------------
# AST extraction helpers
# ---------------------------------------------------------------------------

@dataclass
class FuncInfo:
    name: str
    args: str
    returns: str | None
    docstring: str | None
    decorators: list[str] = field(default_factory=list)
    is_async: bool = False


@dataclass
class ClassInfo:
    name: str
    bases: list[str]
    docstring: str | None
    fields: list[tuple[str, str, str | None]]  # (name, annotation, default)
    methods: list[FuncInfo]


@dataclass
class ModuleInfo:
    docstring: str | None
    functions: list[FuncInfo]
    classes: list[ClassInfo]
    constants: list[tuple[str, str]]  # (name, value_repr)


def _format_arg(arg: ast.arg) -> str:
    name = arg.arg
    if arg.annotation:
        name += f": {ast.unparse(arg.annotation)}"
    return name


def _extract_func(node: ast.FunctionDef | ast.AsyncFunctionDef) -> FuncInfo:
    args_parts: list[str] = []
    args_obj = node.args

    # Positional args (skip 'self'/'cls')
    positional = args_obj.args
    defaults = args_obj.defaults
    n_defaults = len(defaults)
    for i, arg in enumerate(positional):
        if arg.arg in ("self", "cls"):
            continue
        s = _format_arg(arg)
        default_idx = i - (len(positional) - n_defaults)
        if default_idx >= 0:
            s += f" = {ast.unparse(defaults[default_idx])}"
        args_parts.append(s)

    if args_obj.vararg:
        args_parts.append(f"*{_format_arg(args_obj.vararg)}")
    elif args_obj.kwonlyargs:
        args_parts.append("*")

    kw_defaults = args_obj.kw_defaults
    for i, arg in enumerate(args_obj.kwonlyargs):
        s = _format_arg(arg)
        if kw_defaults[i] is not None:
            s += f" = {ast.unparse(kw_defaults[i])}"
        args_parts.append(s)

    if args_obj.kwarg:
        args_parts.append(f"**{_format_arg(args_obj.kwarg)}")

    returns = ast.unparse(node.returns) if node.returns else None
    decorators = [ast.unparse(d) for d in node.decorator_list]
    docstring = ast.get_docstring(node)

    return FuncInfo(
        name=node.name,
        args=", ".join(args_parts),
        returns=returns,
        docstring=docstring,
        decorators=decorators,
        is_async=isinstance(node, ast.AsyncFunctionDef),
    )


def _extract_class(node: ast.ClassDef) -> ClassInfo:
    bases = [ast.unparse(b) for b in node.bases]
    docstring = ast.get_docstring(node)
    fields: list[tuple[str, str, str | None]] = []
    methods: list[FuncInfo] = []

    for child in ast.iter_child_nodes(node):
        if isinstance(child, ast.AnnAssign) and isinstance(child.target, ast.Name):
            ann = ast.unparse(child.annotation)
            default = ast.unparse(child.value) if child.value else None
            fields.append((child.target.id, ann, default))
        elif isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)):
            if not child.name.startswith("_") or child.name == "__init__":
                methods.append(_extract_func(child))

    return ClassInfo(
        name=node.name,
        bases=bases,
        docstring=docstring,
        fields=fields,
        methods=methods,
    )


def parse_module(filepath: Path) -> ModuleInfo:
    """Parse a Python file and extract documentation-relevant info."""
    tree = ast.parse(filepath.read_text(encoding="utf-8"), filename=str(filepath))

    docstring = ast.get_docstring(tree)
    functions: list[FuncInfo] = []
    classes: list[ClassInfo] = []
    constants: list[tuple[str, str]] = []

    for node in ast.iter_child_nodes(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            if not node.name.startswith("_"):
                functions.append(_extract_func(node))
        elif isinstance(node, ast.ClassDef):
            if not node.name.startswith("_"):
                classes.append(_extract_class(node))
        elif isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id.isupper():
                    try:
                        val = ast.unparse(node.value)
                        if len(val) <= 120:
                            constants.append((target.id, val))
                    except Exception:
                        pass

    return ModuleInfo(
        docstring=docstring,
        functions=functions,
        classes=classes,
        constants=constants,
    )


# ---------------------------------------------------------------------------
# Click command extraction
# ---------------------------------------------------------------------------

def _extract_click_commands() -> list[dict]:
    """Extract Click command metadata from cli.py using AST."""
    filepath = SRC_DIR / "cli.py"
    tree = ast.parse(filepath.read_text(encoding="utf-8"), filename=str(filepath))

    commands: list[dict] = []
    for node in ast.iter_child_nodes(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue

        decorators = [ast.unparse(d) for d in node.decorator_list]
        is_command = any("cli.command" in d for d in decorators)
        if not is_command:
            continue

        # Extract arguments and options from decorators
        args: list[str] = []
        options: list[str] = []
        for dec in decorators:
            if "click.argument" in dec:
                # Pull out the first string arg
                for child in ast.walk(node.decorator_list[decorators.index(dec)]):
                    if isinstance(child, ast.Constant) and isinstance(child.value, str):
                        args.append(child.value)
                        break
            elif "click.option" in dec:
                for child in ast.walk(node.decorator_list[decorators.index(dec)]):
                    if isinstance(child, ast.Constant) and isinstance(child.value, str) and child.value.startswith("--"):
                        options.append(child.value)
                        break

        docstring = ast.get_docstring(node) or ""
        commands.append({
            "name": node.name,
            "docstring": docstring,
            "args": args,
            "options": options,
        })

    return commands


# ---------------------------------------------------------------------------
# Markdown generation
# ---------------------------------------------------------------------------

def _md_func(fn: FuncInfo) -> str:
    """Render a function as markdown."""
    prefix = "async " if fn.is_async else ""
    sig = f"`{prefix}def {fn.name}({fn.args})`"
    if fn.returns:
        sig += f" -> `{fn.returns}`"

    lines = [f"#### {fn.name}", "", sig, ""]
    if fn.docstring:
        lines.append(fn.docstring)
        lines.append("")
    return "\n".join(lines)


def _md_class(cls: ClassInfo) -> str:
    """Render a class as markdown."""
    bases_str = f"({', '.join(cls.bases)})" if cls.bases else ""
    lines = [f"### {cls.name}{bases_str}", ""]

    if cls.docstring:
        lines.append(cls.docstring)
        lines.append("")

    if cls.fields:
        lines.append("| Field | Type | Default |")
        lines.append("|-------|------|---------|")
        for name, ann, default in cls.fields:
            lines.append(f"| `{name}` | `{ann}` | {f'`{default}`' if default else '—'} |")
        lines.append("")

    for method in cls.methods:
        if method.name != "__init__":
            lines.append(_md_func(method))

    return "\n".join(lines)


def generate_markdown() -> str:
    """Generate full markdown documentation for goliath-jobpack."""
    from . import __version__

    parts: list[str] = []
    parts.append(f"# goliath-jobpack")
    parts.append("")
    parts.append(f"Version {__version__} — Build and upload Python job packages for the Goliath scheduler.")
    parts.append("")

    # --- CLI commands section ---
    parts.append("## CLI Commands")
    parts.append("")
    parts.append("All commands are available via `goliath <command>`.")
    parts.append("")

    commands = _extract_click_commands()
    for cmd in commands:
        name = cmd["name"]
        parts.append(f"### goliath {name}")
        parts.append("")
        if cmd["docstring"]:
            parts.append(cmd["docstring"])
            parts.append("")
        usage_parts = [f"goliath {name}"]
        for a in cmd["args"]:
            usage_parts.append(f"[{a}]")
        for o in cmd["options"]:
            usage_parts.append(f"{o}")
        parts.append(f"```")
        parts.append(" ".join(usage_parts))
        parts.append("```")
        parts.append("")

    # --- Module sections ---
    for module_name, section_title in DOCUMENTED_MODULES:
        filepath = SRC_DIR / f"{module_name}.py"
        if not filepath.exists():
            continue

        info = parse_module(filepath)

        parts.append(f"## {section_title}")
        parts.append("")
        parts.append(f"`goliath_jobpack.{module_name}`")
        parts.append("")

        if info.docstring:
            parts.append(info.docstring)
            parts.append("")

        if info.constants:
            parts.append("**Constants:**")
            parts.append("")
            for name, value in info.constants:
                parts.append(f"- `{name}` = `{value}`")
            parts.append("")

        for cls in info.classes:
            parts.append(_md_class(cls))

        for fn in info.functions:
            parts.append(_md_func(fn))

    # --- Job format section ---
    parts.append("## Job Package Format")
    parts.append("")
    parts.append("Jobs are defined by a `job.toml` file:")
    parts.append("")
    toml_template = SRC_DIR / "templates" / "job.toml"
    if toml_template.exists():
        parts.append("```toml")
        parts.append(toml_template.read_text(encoding="utf-8").strip())
        parts.append("```")
        parts.append("")

    # --- Handler template section ---
    parts.append("## Handler Template")
    parts.append("")
    parts.append("The starter `handler.py` generated by `goliath init`:")
    parts.append("")
    handler_template = SRC_DIR / "templates" / "handler.py"
    if handler_template.exists():
        parts.append("```python")
        parts.append(handler_template.read_text(encoding="utf-8").strip())
        parts.append("```")
        parts.append("")

    return "\n".join(parts)


def _slugify(text: str) -> str:
    """Convert heading text to a URL-friendly slug."""
    import re
    # Strip inline markup artifacts
    slug = re.sub(r"[`*_]", "", text)
    slug = slug.lower().strip()
    slug = re.sub(r"[^\w\s-]", "", slug)
    slug = re.sub(r"[\s]+", "-", slug)
    return slug


def _md_to_html(text: str) -> tuple[str, list[tuple[str, str]]]:
    """Convert markdown to HTML. Returns (html, sections) where sections is a list of (id, title) for h2 headings."""
    import html as _html
    import re

    lines = text.split("\n")
    out: list[str] = []
    sections: list[tuple[str, str]] = []
    i = 0

    while i < len(lines):
        line = lines[i]

        # Fenced code blocks
        if line.startswith("```"):
            lang = line[3:].strip()
            code_lines: list[str] = []
            i += 1
            while i < len(lines) and not lines[i].startswith("```"):
                code_lines.append(_html.escape(lines[i]))
                i += 1
            i += 1  # skip closing ```
            out.append(f"<pre><code>{'&#10;'.join(code_lines)}</code></pre>")
            continue

        # Headings
        if line.startswith("#"):
            m = re.match(r"^(#{1,6})\s+(.*)", line)
            if m:
                level = len(m.group(1))
                heading_text = m.group(2)
                slug = _slugify(heading_text)
                if level == 1:
                    out.append(f"<h1>{_inline(heading_text)}</h1>")
                    # Capture the next non-blank line as hero subtitle
                    j = i + 1
                    while j < len(lines) and not lines[j].strip():
                        j += 1
                    if j < len(lines) and not lines[j].startswith("#"):
                        out.append(f'<p class="hero-sub">{_inline(lines[j])}</p>')
                        i = j + 1
                        continue
                elif level == 2:
                    sections.append((slug, heading_text))
                    out.append(f"<h2 id=\"{slug}\">{_inline(heading_text)}</h2>")
                else:
                    out.append(f"<h{level} id=\"{slug}\">{_inline(heading_text)}</h{level}>")
                i += 1
                continue

        # Horizontal rule
        if re.match(r"^---+\s*$", line):
            out.append("<hr>")
            i += 1
            continue

        # Table
        if "|" in line and i + 1 < len(lines) and re.match(r"^\|[-| :]+\|$", lines[i + 1].strip()):
            header_cells = [c.strip() for c in line.strip().strip("|").split("|")]
            i += 2  # skip header and separator
            rows: list[list[str]] = []
            while i < len(lines) and "|" in lines[i] and lines[i].strip():
                cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
                rows.append(cells)
                i += 1
            out.append("<table>")
            out.append("<thead><tr>" + "".join(f"<th>{_inline(c)}</th>" for c in header_cells) + "</tr></thead>")
            out.append("<tbody>")
            for row in rows:
                out.append("<tr>" + "".join(f"<td>{_inline(c)}</td>" for c in row) + "</tr>")
            out.append("</tbody></table>")
            continue

        # Unordered list
        if re.match(r"^[-*]\s+", line):
            out.append("<ul>")
            while i < len(lines) and re.match(r"^[-*]\s+", lines[i]):
                content = re.sub(r"^[-*]\s+", "", lines[i])
                out.append(f"<li>{_inline(content)}</li>")
                i += 1
            out.append("</ul>")
            continue

        # Ordered list
        if re.match(r"^\d+\.\s+", line):
            out.append("<ol>")
            while i < len(lines) and re.match(r"^\d+\.\s+", lines[i]):
                content = re.sub(r"^\d+\.\s+", "", lines[i])
                out.append(f"<li>{_inline(content)}</li>")
                i += 1
            out.append("</ol>")
            continue

        # Blank line
        if not line.strip():
            i += 1
            continue

        # Paragraph
        out.append(f"<p>{_inline(line)}</p>")
        i += 1

    return "\n".join(out), sections


def _inline(text: str) -> str:
    """Handle inline markdown: code, bold, italic, links."""
    import html as _html
    import re

    # Inline code (must be first to avoid processing markup inside code)
    parts: list[str] = []
    last = 0
    for m in re.finditer(r"`([^`]+)`", text):
        parts.append(_apply_inline_markup(_html.escape(text[last:m.start()])))
        parts.append(f"<code>{_html.escape(m.group(1))}</code>")
        last = m.end()
    parts.append(_apply_inline_markup(_html.escape(text[last:])))
    return "".join(parts)


def _apply_inline_markup(text: str) -> str:
    """Apply bold, italic, and link markup to already-escaped text."""
    import re

    # Bold
    text = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", text)
    # Italic
    text = re.sub(r"\*(.+?)\*", r"<em>\1</em>", text)
    return text


def _build_sidebar(sections: list[tuple[str, str]]) -> str:
    """Build sidebar navigation HTML from h2 sections."""
    if not sections:
        return ""
    lines = ["  <h4>Sections</h4>", "  <ul>"]
    for slug, title in sections:
        lines.append(f'    <li><a href="#{slug}">{title}</a></li>')
    lines.append("  </ul>")
    return "\n".join(lines)


def generate_html(markdown_text: str) -> str:
    """Convert markdown to a styled HTML page with sidebar navigation."""
    body, sections = _md_to_html(markdown_text)
    sidebar = _build_sidebar(sections)
    return HTML_TEMPLATE.format(body=body, sidebar=sidebar)
