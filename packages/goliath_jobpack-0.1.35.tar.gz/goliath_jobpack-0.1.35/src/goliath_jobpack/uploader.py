from __future__ import annotations

import hashlib
import hmac
import os
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _hmac_sha256(key: bytes, msg: str) -> bytes:
    return hmac.new(key, msg.encode("utf-8"), hashlib.sha256).digest()


def _get_signing_key(secret: str, date_stamp: str, region: str, service: str) -> bytes:
    k_date = _hmac_sha256(f"AWS4{secret}".encode("utf-8"), date_stamp)
    k_region = _hmac_sha256(k_date, region)
    k_service = _hmac_sha256(k_region, service)
    return _hmac_sha256(k_service, "aws4_request")


def _fetch_goliath_secrets() -> tuple[str, str, str | None, str | None]:
    """Fetch AWS credentials from the Goliath secrets API.

    Returns (access_key, secret_key, session_token, region).
    Requires GOLIATH_API_URL and GOLIATH_API_KEY environment variables.
    """
    import json

    api_url = os.environ.get("GOLIATH_API_URL", "").rstrip("/")
    api_key = os.environ.get("GOLIATH_API_KEY", "")
    if not api_url or not api_key:
        return "", "", None, None

    url = f"{api_url}/secrets/?limit=100&section=AWS"
    req = urllib.request.Request(url, headers={"x-api-key": api_key})

    try:
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except Exception:
        return "", "", None, None

    if not data.get("success"):
        return "", "", None, None

    lookup = {s["key"]: s["value"] for s in data.get("secrets", [])}
    return (
        lookup.get("aws_access_key_id", ""),
        lookup.get("aws_secret_access_key", ""),
        lookup.get("aws_session_token"),
        lookup.get("region"),
    )


def _read_aws_credentials_file(profile: str = "default") -> tuple[str, str, str | None]:
    """Read credentials from ~/.aws/credentials INI file."""
    import configparser

    creds_path = Path.home() / ".aws" / "credentials"
    if not creds_path.exists():
        return "", "", None

    config = configparser.ConfigParser()
    config.read(creds_path)

    if profile not in config:
        return "", "", None

    section = config[profile]
    return (
        section.get("aws_access_key_id", ""),
        section.get("aws_secret_access_key", ""),
        section.get("aws_session_token"),
    )


_goliath_region: str | None = None  # cached region from Goliath API


def _log(msg: str) -> None:
    """Print debug info when GOLIATH_DEBUG is set."""
    if os.environ.get("GOLIATH_DEBUG"):
        import sys
        print(f"[uploader] {msg}", file=sys.stderr)


def _resolve_credentials() -> tuple[str, str, str | None]:
    """Return (access_key, secret_key, session_token).

    Resolution order:
      1. AWS_ACCESS_KEY_ID / AWS_SECRET_ACCESS_KEY env vars
      2. Goliath secrets API (GOLIATH_API_URL + GOLIATH_API_KEY)
      3. ~/.aws/credentials file
    """
    global _goliath_region

    access_key = os.environ.get("AWS_ACCESS_KEY_ID", "")
    secret_key = os.environ.get("AWS_SECRET_ACCESS_KEY", "")
    session_token = os.environ.get("AWS_SESSION_TOKEN")

    if access_key and secret_key:
        _log("credentials source: environment variables")
        return access_key, secret_key, session_token

    # Try Goliath secrets API
    access_key, secret_key, session_token, region = _fetch_goliath_secrets()
    if access_key and secret_key:
        _goliath_region = region
        _log(f"credentials source: Goliath secrets API (region={region!r})")
        return access_key, secret_key, session_token

    # Fall back to ~/.aws/credentials file
    profile = os.environ.get("AWS_PROFILE", "default")
    access_key, secret_key, session_token = _read_aws_credentials_file(profile)

    if not access_key or not secret_key:
        raise RuntimeError(
            "AWS credentials not found. Set AWS_ACCESS_KEY_ID and "
            "AWS_SECRET_ACCESS_KEY environment variables, configure "
            "~/.aws/credentials, or set GOLIATH_API_URL and GOLIATH_API_KEY."
        )

    _log(f"credentials source: ~/.aws/credentials (profile={profile!r})")
    return access_key, secret_key, session_token


def _resolve_region(region: str | None) -> str:
    if region:
        _log(f"region source: function argument ({region!r})")
        return region
    # Check environment variables
    env_region = os.environ.get("AWS_DEFAULT_REGION") or os.environ.get("AWS_REGION")
    if env_region:
        _log(f"region source: environment variable ({env_region!r})")
        return env_region
    # Check Goliath secrets API (populated during credential resolution)
    if _goliath_region:
        _log(f"region source: Goliath secrets API ({_goliath_region!r})")
        return _goliath_region
    # Fall back to ~/.aws/config
    import configparser
    config_path = Path.home() / ".aws" / "config"
    if config_path.exists():
        config = configparser.ConfigParser()
        config.read(config_path)
        profile = os.environ.get("AWS_PROFILE", "default")
        section = f"profile {profile}" if profile != "default" else "default"
        if section in config and "region" in config[section]:
            r = config[section]["region"]
            _log(f"region source: ~/.aws/config [{section}] ({r!r})")
            return r
    _log("region source: default (us-east-1)")
    return "us-east-1"


def upload_file_to_s3(
    *,
    file_path: Path,
    bucket: str,
    key: str,
    region: str | None = None,
) -> dict:
    access_key, secret_key, session_token = _resolve_credentials()
    region = _resolve_region(region)

    payload = file_path.read_bytes()
    payload_hash = _sha256(payload)
    content_type = "application/zip"

    now = datetime.now(timezone.utc)
    amz_date = now.strftime("%Y%m%dT%H%M%SZ")
    date_stamp = now.strftime("%Y%m%d")

    # Path-style URL via global endpoint; signing region must be us-east-1
    host = "s3.amazonaws.com"
    signing_region = "us-east-1"
    url = f"https://{host}/{bucket}/{key}"

    # Build canonical headers
    headers: dict[str, str] = {
        "host": host,
        "x-amz-content-sha256": payload_hash,
        "x-amz-date": amz_date,
        "content-type": content_type,
    }
    if session_token:
        headers["x-amz-security-token"] = session_token

    signed_header_names = sorted(headers.keys())
    signed_headers_str = ";".join(signed_header_names)
    canonical_headers = "".join(f"{k}:{headers[k]}\n" for k in signed_header_names)

    canonical_request = "\n".join([
        "PUT",
        f"/{bucket}/{key}",
        "",  # no query string
        canonical_headers,
        signed_headers_str,
        payload_hash,
    ])

    credential_scope = f"{date_stamp}/{signing_region}/s3/aws4_request"
    string_to_sign = "\n".join([
        "AWS4-HMAC-SHA256",
        amz_date,
        credential_scope,
        _sha256(canonical_request.encode("utf-8")),
    ])

    signing_key = _get_signing_key(secret_key, date_stamp, signing_region, "s3")
    signature = hmac.new(signing_key, string_to_sign.encode("utf-8"), hashlib.sha256).hexdigest()

    authorization = (
        f"AWS4-HMAC-SHA256 Credential={access_key}/{credential_scope}, "
        f"SignedHeaders={signed_headers_str}, Signature={signature}"
    )

    request_headers = {
        "Authorization": authorization,
        "x-amz-content-sha256": payload_hash,
        "x-amz-date": amz_date,
        "Content-Type": content_type,
    }
    if session_token:
        request_headers["x-amz-security-token"] = session_token

    req = urllib.request.Request(url, data=payload, headers=request_headers, method="PUT")

    try:
        urllib.request.urlopen(req)
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"S3 upload failed (HTTP {exc.code}): {body}") from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"S3 upload failed: {exc.reason}") from exc

    return {
        "bucket": bucket,
        "key": key,
        "file_name": file_path.name,
    }
