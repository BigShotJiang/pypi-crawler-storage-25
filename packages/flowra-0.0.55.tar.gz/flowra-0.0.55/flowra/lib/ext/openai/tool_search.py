"""OpenAI tool search hook bundle.

Deferred tool loading for large tool sets — marks tools with
``defer_loading: true`` and adds the server-side tool search tool
for the OpenAI Responses API.

Requires ``OpenAIResponsesProvider`` and models that support tool
search (gpt-5.4+).
"""

from collections.abc import Callable

from ....agent import AbstractAgent, AgentRuntime, Event, HookSubscription
from ....llm import LLMRequest, Tool
from ....llm.providers.openai_responses import OpenAIToolExtra
from ...turn import PrepareLLMRequestEvent

__all__ = ["OpenAIToolSearch"]


class OpenAIToolSearch:
    """Defer tool loading and enable tool search via the OpenAI Responses API.

    Marks tools with ``defer_loading: true`` so the model sees only names and
    descriptions (not full schemas). Adds a server-side ``tool_search`` tool
    that discovers full tool definitions on demand.

    Reduces token usage when using many tools (50+).

    Args:
        predicate: Optional callable ``(Tool) -> bool`` to select which tools
            to defer. By default all tools are deferred.
    """

    __slots__ = ("__predicate",)

    def __init__(
        self,
        *,
        predicate: Callable[[Tool], bool] | None = None,
    ) -> None:
        self.__predicate = predicate

    def install(
        self,
        target: AgentRuntime | HookSubscription,
        *,
        scope: str | type[AbstractAgent] | None = None,
    ) -> None:
        hooks = target.hooks if isinstance(target, AgentRuntime) else target
        hooks.on(PrepareLLMRequestEvent, self.on_prepare, scope=scope)

    def on_prepare(self, event: Event[PrepareLLMRequestEvent]) -> None:
        request: LLMRequest = event.data.request
        if not request.tools:
            return

        has_deferred = False
        for tool in request.tools:
            if self.__predicate is None or self.__predicate(tool):
                OpenAIToolExtra(defer_loading=True).write_to(tool)
                has_deferred = True

        if not has_deferred:
            return

        search_tool = Tool(name="__tool_search__", description="")
        OpenAIToolExtra(type="tool_search").write_to(search_tool)
        request.tools.insert(0, search_tool)
