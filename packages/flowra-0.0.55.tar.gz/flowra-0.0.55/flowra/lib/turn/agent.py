import dataclasses
import logging
from typing import Annotated, ClassVar

from ...agent import (
    Agent,
    AgentDefinitionRef,
    AgentStore,
    AppendOnlyList,
    CallAgent,
    Event,
    GotoStep,
    Hooks,
    InterruptedError,
    InterruptToken,
    Scalar,
    ServiceLocator,
    Spawn,
    SpawnChild,
    agent_arg,
    persistent,
    step,
    with_interrupt,
)
from ...llm import (
    AssistantMessage,
    ContentComplete,
    LLMProvider,
    LLMRequest,
    MediaBlock,
    StopReason,
    TextBlock,
    TextDelta,
    ThinkingBlock,
    ThinkingDelta,
    ToolResultBlock,
    ToolUseBlock,
    Usage,
    UserBlock,
    UserMessage,
)
from ..config_value import resolve_config_value
from ..observability import LLMCallSpan, TextDeltaEvent, ThinkingDeltaEvent, UsageEvent
from .config import TurnConfig, matches_tool_filter
from .context import TurnAgentContext
from .hook_events import (
    AfterToolCallEvent,
    BeforeToolCallEvent,
    MessageAcceptedEvent,
    PrepareLLMRequestEvent,
    ResultMessageEvent,
    ServerToolCallEvent,
    ServerToolResultEvent,
    StartIterationEvent,
    StartTurnEvent,
    TextReasoningEvent,
    ThinkingEvent,
    TurnReadyEvent,
)
from .spec import TurnResult, TurnSpec, TurnStatus
from .tool_call import ToolCallAgent, ToolCallResult, ToolCallSpec

__all__ = ["TurnAgent"]

logger = logging.getLogger(__name__)


class TurnAgent(Agent[TurnSpec, TurnResult]):
    __slots__ = (
        "__config",
        "__consecutive_errors",
        "__context",
        "__hooks",
        "__interrupt",
        "__iteration",
        "__provider",
        "__spec",
        "__turn_messages",
        "__usage",
    )
    __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {
        "tool_call": ToolCallAgent,
    }

    def __init__(
        self,
        spec: TurnSpec,
        store: AgentStore,
        services: ServiceLocator,
        config: TurnConfig,
        provider: LLMProvider,
        interrupt: InterruptToken,
        hooks: Hooks,
    ) -> None:
        self.__spec = spec
        self.__turn_messages = store.ephemeral.slot(AppendOnlyList[UserMessage | AssistantMessage], "turn_messages")
        self.__iteration = store.ephemeral.slot(Scalar[int], "iteration")
        self.__usage = store.ephemeral.slot(Scalar[Usage | None], "usage")
        self.__consecutive_errors = store.ephemeral.slot(Scalar[dict[str, int]], "consecutive_errors")
        self.__interrupt = interrupt
        self.__provider = provider
        self.__context = TurnAgentContext()
        self.__config = config
        self.__hooks = hooks

        hooks.on(UsageEvent, self.__on_usage)
        services.provide(self.__context)

    async def __post_init__(self) -> None:
        await self.__hooks.emit(TurnReadyEvent(context=self.__context, turn_messages=self.__turn_messages))

    @step("start", entry=True)
    async def start(self) -> GotoStep:
        event = await self.__hooks.emit(
            StartTurnEvent(
                context=self.__context,
                messages=list(self.__spec.messages),
                metadata=self.__spec.metadata or {},
            )
        )
        self.__turn_messages.extend(event.messages)
        return GotoStep(step=self.message_accepted)

    @step("message_accepted")
    async def message_accepted(self) -> GotoStep:
        assert len(self.__turn_messages)
        await self.__hooks.emit(
            MessageAcceptedEvent(
                messages=self.__turn_messages.get_all(),
                metadata=self.__spec.metadata or {},
            )
        )
        return GotoStep(step=self.call_llm)

    @step("call_llm")
    async def call_llm(self) -> GotoStep | Spawn | TurnResult:
        if self.__interrupt.interrupted:
            return self.__result(TurnStatus.INTERRUPTED)
        if self.__context.is_finish_requested():
            return self.__result(TurnStatus.FINISH_REQUESTED)

        iteration = self.__iteration.get(0)
        max_llm_calls = await resolve_config_value(self.__config.max_llm_calls)
        if iteration >= max_llm_calls:
            return self.__result(TurnStatus.MAX_LLM_CALLS)

        self.__iteration.set(iteration + 1)
        logger.info("Tool loop iteration %d/%d", iteration + 1, max_llm_calls)

        start_event = await self.__hooks.emit(StartIterationEvent(iteration=iteration + 1, context=self.__context))
        if start_event.additional_messages:
            self.__turn_messages.extend(start_event.additional_messages)

        llm_config = await resolve_config_value(self.__config.llm_config)
        system_messages = await resolve_config_value(self.__config.system)
        history = await resolve_config_value(self.__config.history)
        turn_messages = self.__turn_messages.get_all()

        registry = await resolve_config_value(self.__config.tools)
        tools = registry.get_llm_tools() if registry is not None else []
        allowed_tools = await resolve_config_value(self.__config.allowed_tools)
        denied_tools = await resolve_config_value(self.__config.denied_tools)
        if allowed_tools is not None:
            tools = [t for t in tools if matches_tool_filter(t.name, allowed_tools)]
        if denied_tools is not None:
            tools = [t for t in tools if not matches_tool_filter(t.name, denied_tools)]

        messages = [m for m in history if m.blocks] + [m for m in turn_messages if m.blocks]
        json_schema = await resolve_config_value(self.__config.json_schema)

        request = LLMRequest(
            model=llm_config.model,
            system=[m for m in system_messages if m.blocks],
            messages=messages,
            tools=tools,
            json_schema=json_schema,
            temperature=llm_config.temperature,
            top_p=llm_config.top_p,
            max_tokens=llm_config.max_tokens,
            stop_sequences=llm_config.stop_sequences,
            extra=llm_config.extra,
        )

        prepare_event = await self.__hooks.emit(PrepareLLMRequestEvent(request=request))
        request = prepare_event.request

        try:
            async with self.__hooks.span(LLMCallSpan(request=request)) as llm_span:
                if self.__hooks.has_handlers(TextDeltaEvent) or self.__hooks.has_handlers(ThinkingDeltaEvent):
                    response = None
                    async for event in with_interrupt(self.__provider.stream(request), self.__interrupt):
                        match event:
                            case TextDelta(text=text):
                                await self.__hooks.emit(TextDeltaEvent(text=text))
                            case ThinkingDelta(text=text):
                                await self.__hooks.emit(ThinkingDeltaEvent(text=text))
                            case ContentComplete(response=resp):
                                response = resp
                    assert response is not None
                else:
                    response = await self.__provider.call(request)
                llm_span.response = response
        except InterruptedError:
            return self.__result(TurnStatus.INTERRUPTED)

        if response.usage is not None:
            current_usage = self.__usage.get(None)
            self.__usage.set(current_usage + response.usage if current_usage is not None else response.usage)
            await self.__hooks.emit(UsageEvent(usage=response.usage))

        for msg in response.messages:
            match msg:
                case AssistantMessage():
                    for block in msg.blocks:
                        match block:
                            case TextBlock():
                                await self.__hooks.emit(TextReasoningEvent(text=block, context=self.__context))
                            case ThinkingBlock():
                                await self.__hooks.emit(ThinkingEvent(thinking=block, context=self.__context))
                            case ToolUseBlock() if msg is not response.message:
                                await self.__hooks.emit(ServerToolCallEvent(tool_use=block, context=self.__context))
                            case ToolUseBlock():
                                pass
                case UserMessage():
                    for block in msg.blocks:
                        match block:
                            case ToolResultBlock():
                                await self.__hooks.emit(ServerToolResultEvent(result=block, context=self.__context))
                            case TextBlock() | MediaBlock():
                                pass

        match response.stop_reason:
            case StopReason.END_TURN:
                self.__turn_messages.extend(response.messages)

                result_event = await self.__hooks.emit(
                    ResultMessageEvent(message=response.message, context=self.__context)
                )
                if result_event.continue_messages:
                    self.__turn_messages.extend(result_event.continue_messages)
                    return GotoStep(step=self.call_llm)

                return self.__result(
                    TurnStatus.COMPLETED, stop_reason=StopReason.END_TURN, result_message=response.message
                )

            case StopReason.TOOL_USE:
                tool_uses = [block for block in response.message.blocks if isinstance(block, ToolUseBlock)]

                amendments: dict[str, ToolUseBlock] = {}
                final_tool_uses = []
                for tool_use in tool_uses:
                    before_event = await self.__hooks.emit(
                        BeforeToolCallEvent(
                            tool_use=tool_use,
                            tool_definition=registry.get_tool_definition(tool_use.name) if registry else None,
                            context=self.__context,
                        )
                    )
                    final_tool_uses.append(before_event.tool_use)
                    if before_event.tool_use is not tool_use:
                        amendments[tool_use.id] = before_event.tool_use

                if amendments:
                    new_blocks = [
                        amendments.get(b.id, b) if isinstance(b, ToolUseBlock) else b for b in response.message.blocks
                    ]
                    amended = dataclasses.replace(response.message, blocks=new_blocks)
                    self.__turn_messages.extend(
                        [amended if msg is response.message else msg for msg in response.messages]
                    )
                else:
                    self.__turn_messages.extend(response.messages)

                children: list[SpawnChild] = [
                    CallAgent(
                        agent=ToolCallAgent,
                        spec=ToolCallSpec(
                            tool_use=tool_use,
                            allowed_tools=allowed_tools,
                            denied_tools=denied_tools,
                        ),
                        state=persistent.EPHEMERAL,
                    )
                    for tool_use in final_tool_uses
                ]
                return Spawn(children=children, then=self.collect_results)

            case (
                StopReason.MAX_TOKENS
                | StopReason.STOP_SEQUENCE
                | StopReason.SCHEMA_VALIDATION_FAILED
                | StopReason.OTHER
            ):
                self.__turn_messages.extend(response.messages)
                return self.__result(
                    TurnStatus.COMPLETED, stop_reason=response.stop_reason, result_message=response.message
                )

    @step("collect_results")
    async def collect_results(
        self, results: Annotated[list[ToolCallResult], agent_arg.CHILDREN]
    ) -> GotoStep | TurnResult:
        final_blocks: list[UserBlock] = []
        all_additional_messages: list[UserMessage] = []
        consecutive_errors = dict(self.__consecutive_errors.get({}))
        max_consecutive = await resolve_config_value(self.__config.max_consecutive_errors)

        for tc_result in results:
            after_event = await self.__hooks.emit(
                AfterToolCallEvent(
                    tool_use=tc_result.tool_use,
                    result=tc_result.result,
                    error_kind=tc_result.error_kind,
                    context=self.__context,
                )
            )

            result_block = after_event.result
            all_additional_messages.extend(after_event.additional_messages)

            if max_consecutive is not None:
                tool_name = tc_result.tool_use.name
                if result_block.is_error:
                    consecutive_errors[tool_name] = consecutive_errors.get(tool_name, 0) + 1
                    if consecutive_errors[tool_name] >= max_consecutive:
                        result_block = ToolResultBlock(
                            tool_use_id=tc_result.tool_use.id,
                            content=f"Tool {tool_name} has failed {max_consecutive} times consecutively. "
                            f"Please try a different approach.",
                            is_error=True,
                        )
                else:
                    consecutive_errors[tool_name] = 0

            final_blocks.append(result_block)

        self.__consecutive_errors.set(consecutive_errors)
        user_message = UserMessage(blocks=final_blocks)
        self.__turn_messages.append(user_message)

        self.__turn_messages.extend(all_additional_messages)

        if self.__interrupt.interrupted:
            return self.__result(TurnStatus.INTERRUPTED)
        if self.__context.is_finish_requested():
            return self.__result(TurnStatus.FINISH_REQUESTED)

        return GotoStep(step=self.call_llm)

    def __result(
        self,
        status: TurnStatus,
        stop_reason: StopReason | None = None,
        result_message: AssistantMessage | None = None,
    ) -> TurnResult:
        return TurnResult(
            messages=self.__turn_messages.get_all(),
            status=status,
            stop_reason=stop_reason,
            result_message=result_message,
            usage=self.__usage.get(None),
        )

    def __on_usage(self, event: Event[UsageEvent]) -> None:
        current = self.__usage.get(None)
        self.__usage.set(current + event.data.usage if current is not None else event.data.usage)
