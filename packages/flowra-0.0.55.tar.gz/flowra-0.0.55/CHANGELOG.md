# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com),
and this project adheres to [Semantic Versioning](https://semver.org).

## [0.0.55] - 2026-04-20

### Changed
- **Non-dataclass agent/step result and parameter types** — `Agent[Spec, Result]`,
  step return types, and step parameters (with `agent_arg.AGENT_SPEC`,
  `agent_arg.STEP_SPEC`, `agent_arg.CHILD`, or `agent_arg.SERVICE`) now accept
  primitives (`str`, `int`, `float`, `bool`, `bytes`, `UUID`, `datetime`,
  `date`, `time`, `Decimal`) and containers (`list`, `dict`) in addition to
  dataclasses. Generic forms (`list[int]`, `dict[str, Foo]`) are accepted —
  the container origin is used for runtime `isinstance` dispatch, and
  container values serialize recursively through the existing checkpoint
  layer, so they survive snapshot/restore across runtime restarts.
- **Tool result stringification (`format_result`)** — shared between `@tool`
  and `@agent_tool`. Scalars use canonical string forms (`str()` for `UUID` /
  `Decimal` / others, `isoformat()` for `datetime` / `date` / `time`, base64
  for `bytes`), containers are walked recursively so nested dataclasses get
  `mr.dump`'d and mixed lists/dicts stringify reliably. `output_schema` is
  `None` when an agent-as-tool returns a non-dataclass (no JSON Schema root
  for primitives).

### Added
- **`agent_arg.CHILDREN` marker + stricter `CHILD` semantics** — child binding
  is split by signature, not by annotation type:
  - `CHILD` → strictly single. `Annotated[list[X], CHILD]` now means "one
    child whose result IS a list" (previously this meant plural).
  - `CHILDREN` → strictly plural. Requires a `list[X]` annotation; yields
    `[]` when no children match.
  - No marker on `list[X]` → both interpretations are tried at bind time.
    A unique match wins; two matches raise `RuntimeError("Ambiguous binding...")`;
    no match defaults to `[]`.

  Migration: replace `Annotated[list[X], agent_arg.CHILD]` with
  `Annotated[list[X], agent_arg.CHILDREN]` wherever plural join was intended.

## [0.0.54] - 2026-04-17

### Changed
- Renamed `flowra[all]` extra to `flowra[providers]`
- **Hook bundle `install()` methods accept `scope`** — all built-in
  installable bundles (`AnthropicCache*`, `AnthropicCacheHistoryMessages`,
  `AnthropicToolSearch`, `OpenAIToolSearch`, Anthropic caching composite
  presets, `OTEL_TRACING`, `MLFLOW_TRACING`) now take a
  `scope: str | type[AbstractAgent] | None = None` keyword argument and
  forward it to the underlying `hooks.on()` / `hooks.on_span()` calls,
  so installations can be restricted to a specific agent path or agent
  type instead of being global.

## [0.0.53] - 2026-04-13

### Added
- **`UsageEvent`** — emitted after each LLM call by TurnAgent and
  LLMCallAgent. TurnAgent subscribes to accumulate usage from all
  descendants (including sub-agents invoked as tools). Custom agents
  should emit it too when calling LLM providers directly.
- **`LLMCallConfig`** — proper configuration for LLMCallAgent with
  `llm_config`, `system`, `tools`, `json_schema`. LLMCallAgent is now
  a full-featured single-call agent.

### Changed
- **`LLMCallSpec.system` removed** — system messages moved to
  `LLMCallConfig.system`.

## [0.0.52] - 2026-04-12

### Changed
- **Scope hydration is now lazy and per-slot** — all scopes (ephemeral,
  persistent, named) load raw data from storage and deserialize each slot
  individually when `slot()` is called. Fixes named scope hydration failures
  with dataclass types (`TypeError: Unknown type tag`). Removes scope-level
  `type_registry` — type info comes from `slot()` parameters.

## [0.0.51] - 2026-04-12

### Added
- **`include_suffix` on `ToolRegistryBuilder.add()`** — whitelist tools by
  suffix matching. Composable with `exclude_suffix` (include first, then exclude).

### Changed
- **`Conversation` supports slicing** — `conversation[1:3]`, `conversation[-2:]`
  work as expected.

## [0.0.50] - 2026-04-11

### Added
- `agent_arg.AGENT_SPEC`, `agent_arg.STEP_SPEC`, `agent_arg.CHILD`,
  `agent_arg.SERVICE` markers for unified parameter binding
- `__post_init__()` async lifecycle method on agents — called after `__init__`,
  both on creation and crash recovery
- Steps can receive services via DI (no longer limited to `__init__`)
- **`Conversation`** — read-only combined view over history + turn messages.
  Supports forward/reverse iteration, indexing, `len()`.
- **`TurnReadyEvent`** — emitted from `TurnAgent.__post_init__`, exposes
  `turn_messages` on both creation and crash recovery.
- **`ConversationReadyEvent`** — emitted from `ChatAgent`, provides a
  `Conversation` view combining history + current turn.

### Changed
- `agent_arg.SPEC` renamed to `agent_arg.AGENT_SPEC`

### Removed
- `step_arg` module — use `agent_arg` markers instead

## [0.0.49] - 2026-04-10

### Changed
- **`SessionStorage` API** — `save_node_state`/`load_node_state` replaced with
  `save`/`load` (persistent) and `save_ephemeral`/`load_ephemeral` (ephemeral).
  New `clear_ephemeral()` removes all ephemeral data after run completion.
  `store.flush()` now saves all dirty scopes (ephemeral, persistent, named),
  not just the current node's persistent scope.

## [0.0.48] - 2026-04-10

### Added
- **`UserMessage.text(str)`** — factory method for creating a `UserMessage`
  with a single `TextBlock`.
- **`ChatSpec.text(str)` / `TurnSpec.text(str)`** — convenience constructors
  for single-message turns.

### Changed
- **`ChatSpec` and `TurnSpec` accept `messages: list[UserMessage]`** instead
  of `user_message: str`. Pass pre-built messages directly — no more wrapping
  inside the agent.
- **`StartTurnEvent` now carries `messages` and `metadata`** — replaces
  `UserMessageEvent`. Mutate `messages` to augment or transform user input.

### Removed
- **`UserMessageEvent`** — use `StartTurnEvent.messages`.

## [0.0.47] - 2026-04-10

### Added
- **`exclude_suffix` on `ToolRegistryBuilder.add()`** — filter out tools by
  suffix matching (e.g., `exclude_suffix={"get_payees"}` excludes both
  `get_payees` and `mcp__payments__get_payees`). Uses `__` separator convention.
- **Scoped hook subscription** — agents can subscribe to sub-agent events via
  `hooks.on(EventType, handler)` and `hooks.on_span(SpanType, handler)` in
  `__init__`. Optional `scope` parameter: `str` (named child path),
  `type[Agent]` (agent type filter), or `None` (all descendants). Global
  handlers always see all events — scoped handlers are additive.

### Changed
- **Interrupt handling in built-in agents** — `TurnAgent` now catches
  interrupts and returns `TurnResult(status=INTERRUPTED)` with accumulated
  messages instead of propagating `Interrupted`. `ChatAgent` saves turn
  history before propagating the interrupt, preventing message loss.
- **`HookSubscription` and `Hooks` are now ABCs** — `HookSubscription`
  is the subscribe-only interface, `Hooks` adds emit/span capabilities.
  Dynamic handler resolution at emit time (no snapshots).

### Removed
- **`HookEmitter`** — use `Hooks`.
- **`propagate_to()`** — use scoped subscription via `Hooks.on()` /
  `Hooks.on_span()`.
- **`StartTurnEvent.turn_messages`** — unreliable on crash recovery (hook
  doesn't re-fire on resume).

## [0.0.46] - 2026-04-08

### Added
- **`AppendOnlyList.__len__` / `__getitem__`** — read-only sequence access
  (length and indexing) for append-only lists.
- **`StartTurnEvent.turn_messages`** — provides read access to the ephemeral
  turn message slot. Empty on first run; contains pre-crash messages on recovery.
- **LLM call error handling** — `LLMCallAgent` now catches LLM provider
  exceptions and returns `LLMCallResult(error=...)` instead of crashing.
  `LLMCallResult.message` is now optional (`None` on error).

## [0.0.45] - 2026-04-08

### Added
- **Agent tool output schema** — `make_agent_tool` now derives `output_schema`
  from the agent's result type (excluding `ToolResult`).
- **Compile-time result type validation** — step return types must be a subset
  of the Agent's generic result type parameter when explicitly declared.
- **`StartTurnEvent`** — emitted once at the start of each turn, before
  processing the user message. Provides access to `TurnAgentContext`.

### Changed
- **Renamed `ToolLoopAgent` → `TurnAgent`** and all related types:
  `ToolLoopConfig` → `TurnConfig`, `ToolLoopSpec` → `TurnSpec`,
  `ToolLoopResult` → `TurnResult`, `ToolLoopStatus` → `TurnStatus`,
  `ToolLoopAgentContext` → `TurnAgentContext`.
  Package: `flowra.lib.tool_loop` → `flowra.lib.turn`.

## [0.0.44] - 2026-04-07

### Added
- **Agent tool error handling** — agent tools can now return `ToolResult` directly
  to signal errors to the parent LLM. The agent completes normally; the parent LLM
  sees a tool error and can retry.

## [0.0.43] - 2026-04-07

### Changed
- **Tool system redesign** — `ToolRegistry` is now an immutable container of
  `ExecutableTool`s. Tools are passed via `ChatConfig(tools=...)` /
  `ToolLoopConfig(tools=...)` as `ConfigValue[ToolRegistry | None]` instead of
  being a separate service on `AgentRuntime`.
  - `ExecutableTool` — unified frozen type: `ToolDefinition` + `ToolExecutor`
  - `@tool` decorator produces `ExecutableTool` directly; `get_tool()` extracts it
  - `ToolRegistry(tools)` — sync, immutable; `ToolRegistry.builder()` for
    composition with prefix/filter
  - `McpConnection.snapshot()` returns a frozen `ToolRegistry`
  - Duplicate tool names raise `ValueError` (strict)

### Removed
- `LocalTool`, `ToolHandler`, `ToolExecutionContext` — replaced by `ExecutableTool` / `ToolExecutor`
- `LocalToolGroup`, `McpToolGroup`, `ToolSource`, `create_local_tool_group`
- `ToolRegistry.create()`, `ToolRegistry.create_empty()`, `ToolRegistry.close()`
- `get_local_tool()`, `get_executable_tool()` — replaced by `get_tool()`

### Fixed
- Export `StepAction` from `flowra.agent` package (was missing).

## [0.0.42] - 2026-04-03

### Added
- **`ChatConfig.history`** — configurable history storage for `ChatAgent`.
  Accepts a callable `(AgentStore) -> AppendOnlyList` for custom scopes
  (named, ephemeral) or a pre-created slot. Defaults to
  `store.persistent.slot(AppendOnlyList, "history")`.

## [0.0.41] - 2026-04-02

### Added
- **AzureOpenAIProvider** — OpenAI models (GPT) via Azure, with Azure-specific
  pricing. Inherits `OpenAIProvider`; accepts `azure_endpoint` + `api_key` or a
  pre-configured `AsyncAzureOpenAI` client.
- **AnthropicFoundryProvider** — Anthropic models (Claude) via Azure AI Foundry,
  with Azure AI-specific pricing. Inherits `AnthropicProvider`; accepts
  `resource` + `api_key` or a pre-configured `AsyncAnthropicFoundry` client.
- **AnthropicProvider base class** — extracted shared Anthropic logic
  (`AnthropicClient` ABC, `AnthropicMessageParams` dataclass).
  `AnthropicVertexProvider` and `AnthropicFoundryProvider` both inherit from it.
- **Azure pricing** — `sync_pricing.py` now imports `azure` and `azure_ai`
  provider data from litellm. Each provider passes its `pricing_provider` key
  to the base class constructor.

## [0.0.40] - 2026-04-02

### Added
- **Unified scope model** — all agent state goes through explicit scopes:
  `store.ephemeral` (per-run), `store.persistent` (across runs), and
  `store["name"]` (session-wide shared). Bare `store.slot()` is removed.
- **Named scopes** — `store["name"].slot(...)` for cross-agent shared
  persistent state. Multiple agents accessing the same named scope get
  the same slot instances, with full dirty tracking and crash recovery.
- **`persistent` markers** — `persistent.EPHEMERAL` and
  `persistent.NAMED("name")` for the `state` parameter on `CallAgent`,
  `GotoAgent`, and `runtime.run()`.
- **`@shared_persistent` decorator** — opt-in for agents that support
  multiple concurrent instances sharing the same persistent scope.
- **`ScopeData`** — extracted slot storage class (from `RuntimeScope`)
  used for ephemeral, persistent, and named scopes.
- **`Scope` ABC** — base class for `AgentStore` with `slot()` method.

### Changed
- **`CallAgent`** — `storage_key` parameter replaced with `state`.
  Default persistent key = agent's full name in the registry.
- **`CallStep`** — `storage_key` parameter replaced with
  `fork_ephemeral: bool`. Fork only copies ephemeral state.
- **`GotoStep`** — no longer changes scope (same agent, same scopes).
- **`GotoAgent`** — `storage_key` replaced with `state` (same as `CallAgent`).
- **`runtime.run()`** — `storage_key` replaced with `state`.
- **`ChatAgent`** — uses `store.persistent` for history. Parent controls
  scope via `state=` parameter (e.g., `state=persistent.NAMED("session")`).

### Removed
- **`FORK` / `NEW_SCOPE` markers** — replaced by `fork_ephemeral=True`
  on `CallStep` and `persistent.EPHEMERAL` on `CallAgent`.
- **`ChatConfig.history_scope`** — redundant with the unified scope model.

## [0.0.39] - 2026-03-31

### Fixed
- **OpenAI strict tools** — tools are now sent with `strict: True` and
  strict-compatible schemas, fixing `ValueError` during streaming with tools.

### Changed
- **Storage requirement documented** — clarified that multi-turn agents
  (like `ChatAgent`) require a `storage` (`InMemorySessionStorage` or
  `FileSessionStorage`) to preserve state between `run()` calls.

## [0.0.38] - 2026-03-31

### Added
- **`ToolRegistry.create_empty()`** — synchronous factory for creating an empty
  tool registry (no tools, no MCP connections). Useful when agents don't need tools.
- **Optional `ToolRegistry`** — `ToolLoopAgent` and `ToolCallAgent` now accept
  `ToolRegistry | None`. When `None`, an empty registry is created automatically.
  This means you no longer need to pass `ToolRegistry` to `AgentRuntime` services
  when your agent doesn't use tools.

## [0.0.37] - 2026-03-30

### Fixed
- **Tool search ID matching** — `tool_search_call` and `tool_search_output` items
  now share the same ID so that `ToolUseBlock`/`ToolResultBlock` pairs are correctly
  linked. Enables cross-provider conversation continuity (e.g. OpenAI tool search
  turn followed by Anthropic turn on the same history).
- **Tool search output roundtrip** — `tool_search_output` now preserves full tool
  definitions (`model_dump()`) instead of just names, preventing `BadRequestError`
  on multi-turn roundtrips.

## [0.0.36] - 2026-03-30

### Fixed
- **OpenAI namespace wire format** — namespace objects now use `"tools"` key (not
  `"functions"`) and each entry includes `"type": "function"`, matching the OpenAI
  Responses API specification.

## [0.0.35] - 2026-03-30

### Added
- **`ServerToolCallEvent` / `ServerToolResultEvent`** — observation-only events fired
  for server-side tool calls and results in intermediate response messages (e.g. OpenAI
  tool search). Import from `flowra.lib.tool_loop`.

### Changed
- **`LLMResponse.message` → `LLMResponse.messages`** — response now holds a list of
  messages (`list[UserMessage | AssistantMessage]`) instead of a single `AssistantMessage`.
  Property `message` returns the last `AssistantMessage` for backward compatibility.
  Multi-message responses support provider roundtrips such as OpenAI tool search.
- **OpenAI tool search roundtrip** — `OpenAIResponsesProvider` now preserves
  `tool_search_call` and `tool_search_output` items from the Responses API as
  intermediate messages, sending them back correctly in subsequent requests.
- **`TextReasoningEvent` / `ThinkingEvent`** now fire for all `AssistantMessage`s in
  the response, not only the last one.

## [0.0.34] - 2026-03-29

### Added
- **OpenAI namespace support** — `OpenAIToolExtra(namespace="crm")` on tools +
  `OpenAIRequestExtra(namespaces={"crm": "CRM tools"})` on request. Provider groups
  tools into `{"type": "namespace", ...}` objects and translates dot-notation names
  (e.g. `crm.get_orders` → `get_orders`) back in responses.

### Changed
- **`additional_config` → `extra`** — renamed on `LLMRequest` and `LLMConfig`,
  now namespaced by provider key (`extra["anthropic"]`, `extra["openai"]`, `extra["google"]`).
- **ProviderExtra redesign** — replaced accessor-based `ProviderExtra` with
  `mr.MISSING`-defaulted frozen dataclasses. Three operations: `build_extra()` for
  construction, `.write_to()` for mutation, `.read_from()` for reading. `None` clears
  a field from extra, `mr.MISSING` skips it.
- **`additional_config` in traces** renamed — OTel attributes now use provider-namespaced
  keys (`gen_ai.request.anthropic.thinking_budget_tokens`).

## [0.0.33] - 2026-03-29

### Changed
- **Moved provider-specific extensions** — `flowra.lib.anthropic` → `flowra.lib.ext.anthropic`, `flowra.lib.openai` → `flowra.lib.ext.openai`. Provider-specific hooks (caching, tool search) are now optional and don't trigger SDK imports unless explicitly used.
- **Removed eager imports** — `flowra.lib` no longer imports `anthropic` and `openai` subpackages at module load time. `import flowra` works without any provider SDKs installed.

## [0.0.32] - 2026-03-28

### Changed
- **Provider-namespaced `extra`** — `LLMData.extra` now uses provider-specific namespaces (`extra["anthropic"]`, `extra["openai"]`, `extra["google"]`). Each provider defines typed extra classes with property-based access: `AnthropicCacheable` (cache control, any LLMData), `AnthropicToolExtra` (Tool), `AnthropicBlockExtra` (blocks), `OpenAIToolExtra` (Tool), `GoogleBlockExtra` (blocks). Hooks mutate extra in place via typed accessors. Base class `ProviderExtra` exported from `flowra.llm`.

## [0.0.31] - 2026-03-28

### Added
- **`OpenAIResponsesProvider`** — new standalone provider for the OpenAI Responses API. Full-featured: text, tool use, JSON schema, streaming, tool search with `defer_loading`. Use instead of `OpenAIProvider` when you need Responses API features (tool search, better caching, improved performance).
- **`OpenAIToolSearch`** — hook bundle for deferred tool loading with OpenAI. Marks tools with `defer_loading: true` and adds server-side tool search. Requires `OpenAIResponsesProvider` and models that support tool search (gpt-5.4+).
- **`flowra.llm.openai_schema`** — shared OpenAI strict JSON schema transformation, used by both `OpenAIProvider` and `OpenAIResponsesProvider`.

## [0.0.30] - 2026-03-27

### Changed
- **`ToolUseBlock.input`** — type widened from `dict[str, Any]` to `dict[str, Any] | str | None`. Providers now preserve raw input from the LLM (e.g. OpenAI returns a JSON string, Google Vertex may return `None`). Parsing to `dict` happens in `ToolRegistry.execute` at tool invocation time.

## [0.0.29] - 2026-03-27

### Added
- **`BeforeToolCallEvent.tool_definition`** — `BeforeToolCallEvent` now includes
  `tool_definition: ToolDefinition | None` with the tool's schema and metadata
  (`None` when the LLM calls an unknown tool).
- **`ToolRegistry.get_tool_definition()`** — look up a `ToolDefinition` by name.

## [0.0.28] - 2026-03-26

### Changed
- **Span handlers now receive `Event[T]`** — span enter handlers receive `Event[T]`
  (same envelope as regular hooks, with execution context) instead of raw span objects.
  Access span via `event.data`, execution context via `event.context`. Added
  `SpanExitHandler` type alias for proper typing of exit callbacks.

## [0.0.27] - 2026-03-25

### Added
- **Schema utilities exported** — `format_schema_for_llm`, `format_output_schema_for_description`,
  `validate_json_schema`, `strip_markdown_code_block` now available from `flowra.llm` for custom providers.
- **`MediaBlock`** — replaces `ImageBlock`. Supports images, PDFs, and other documents via
  `media_type` dispatch. Providers choose the right wire format automatically (e.g. `image` vs
  `document` for Anthropic, `image_url` vs `file` for OpenAI). Optional `filename` field.

## [0.0.26] - 2026-03-25

### Added
- **`top_p`** parameter in `LLMRequest` and `LLMConfig` — nucleus sampling, supported by all providers.
- **Provider-specific config in traces** — OTel span attributes and MLflow
  inputs now include provider-specific config (e.g. `thinking_budget_tokens`).

### Changed
- **Universal pricing registry** — replaced three separate per-protocol pricing modules
  (`anthropic.py`, `openai.py`, `google.py`) with a single JSON-backed `PricingRegistry`.
  Pricing data now lives in `flowra/llm/pricing/data/generated.json` (auto-generated from
  litellm) and `custom.json` (manual overrides). Supports context tiers (>200k tokens),
  reasoning tokens, and cache creation TTL variants through a uniform `estimate_cost()` API.

## [0.0.25] - 2026-03-24

### Changed
- **MLflow tool output** — JSON tool results are now parsed into structured dicts
  for display in MLflow UI, instead of escaped strings.
- **`SessionStorage`** and **`ChangeSet`** are now exported from `flowra.agent`.

## [0.0.24] - 2026-03-24

### Added
- **`FlowingRegistry`** — replaces `FlowingContextVar`. Registry of flowing variables
  with `on_enter`/`on_exit` callbacks that fire on context switches, keeping external
  `ContextVar`s (MLflow span context, OTel trace context) in sync. Fixes MLflow span
  leakage between parallel agents.
- **`AgentRuntime.hooks`** and **`AgentRuntime.flowing`** properties — access the
  runtime's built-in `HookSubscription` and `FlowingRegistry`. Runtime creates default
  instances automatically; no need to pass them via `services`.
- **`MLFLOW_TRACING`** and **`OTEL_TRACING`** singleton objects with `.install(runtime, ...)`
  method for installing tracing on a runtime.

### Changed
- **Unified install API** — all `.install()` methods (`MLFLOW_TRACING`, `OTEL_TRACING`,
  `ANTHROPIC_CACHE_ALL`, `AnthropicToolSearch`, etc.) now accept `AgentRuntime` directly.
  Anthropic extensions also accept `HookSubscription` for advanced use cases.
- **`experiment_name`** in `MLFLOW_TRACING.install()` is now optional (`None` by default).
  When `None`, no MLflow experiment is created — useful when flowra spans are always
  children of externally created spans (no `mlflow.db` side effect).
- **MLflow tool output** — JSON tool results are now parsed into structured dicts
  for display in MLflow UI, instead of escaped strings.
- **`GoogleVertexProvider.aclose()`** — now properly closes async client via
  `client.aio.aclose()`, fixing "Event loop is closed" errors.

### Removed
- **`FlowingContextVar`** — replaced by `FlowingRegistry`/`FlowingVar`.
- **`install_mlflow_tracing()`** and **`install_otel_tracing()`** functions — use
  `MLFLOW_TRACING.install(runtime)` and `OTEL_TRACING.install(runtime)` instead.

## [0.0.23] - 2026-03-24

### Added
- **`AnthropicCacheNonTransientTools`** — caching bundle for the last non-transient
  tool definition. Mirrors existing `NonTransient` bundles for system messages and
  messages.
- **`ANTHROPIC_CACHE_NON_TRANSIENT`** preset — composite of
  `ANTHROPIC_CACHE_NON_TRANSIENT_SYSTEM_MESSAGES` +
  `ANTHROPIC_CACHE_NON_TRANSIENT_TOOLS` + `ANTHROPIC_CACHE_NON_TRANSIENT_MESSAGES`.
- **Pre-instantiated constants** for all individual caching bundles:
  `ANTHROPIC_CACHE_ALL_MESSAGES`, `ANTHROPIC_CACHE_ALL_SYSTEM_MESSAGES`,
  `ANTHROPIC_CACHE_ALL_TOOLS`, `ANTHROPIC_CACHE_HISTORY_MESSAGES`,
  `ANTHROPIC_CACHE_NON_TRANSIENT_MESSAGES`, `ANTHROPIC_CACHE_NON_TRANSIENT_SYSTEM_MESSAGES`,
  `ANTHROPIC_CACHE_NON_TRANSIENT_TOOLS`. No need to instantiate classes manually.
- **`InMemorySessionStorage` snapshot** — `storage.snapshot()` returns an
  `InMemorySessionSnapshot` (frozen dataclass) with a deep copy of all data.
  `InMemorySessionStorage(snapshot)` creates a new storage from a snapshot.
  Enables cloning: `InMemorySessionStorage(storage.snapshot())`.
- **External tracing context integration** — both MLflow and OTel integrations now
  detect and attach to existing external spans. If flowra is called inside
  `with mlflow.start_span()` or `tracer.start_as_current_span()`, flowra's spans
  become children of the external span.
- **Tracing examples** — 7 new examples demonstrating all MLflow/OTel tracing
  combinations: nested external spans, both independently, dual export, and mixed
  setups. Console OTel span tree visualizer (`otel_visualize.py`).

### Fixed
- **Anthropic extended thinking roundtrip**: `AnthropicVertexProvider` now preserves
  `ThinkingBlock` (with `signature` in `extra`) when sending conversation history back
  to the API. Previously thinking blocks were silently dropped, losing reasoning context.

### Changed
- **NonTransient caching logic**: `NonTransient` bundles now cache the last
  non-transient element in the non-transient prefix — walk forward and stop at
  the first transient element. Previously they searched for the last non-transient
  element overall, which could skip over transient content in the middle.

## [0.0.22] - 2026-03-23

### Changed
- **ChatAgent**: transient messages (`transient=True`) are now automatically filtered
  from session history. Previously required a manual `SaveHistoryEvent` hook.
  Filtering runs after the hook, so hooks can still process transient messages
  before they are stripped.

## [0.0.21] - 2026-03-23

### Added
- **User-facing documentation** — new guide-style docs in `docs/`:
  `getting-started.md`, `llm.md`, `tools.md`, `agents.md`, `patterns.md`,
  `observability.md`. Previous reference docs moved to `docs/internal/`.
- **Runnable doc examples** in `examples/docs/` — standalone scripts matching
  the documentation, runnable via `make docs-example name=<example>`.

### Changed
- **`agent_tool` / `make_agent_tool`**: `description` is now optional — falls back to
  agent class docstring, consistent with `@tool` decorator behavior.

### Removed
- **`Interrupted.reason`** field. Was never populated by the engine (always `None`).
  Will be redesigned when a concrete use case requires it.

## [0.0.20] - 2026-03-23

### Added
- **`ToolErrorKind`** (`flowra.tools`). `StrEnum` classifying tool call failures:
  `UNKNOWN_TOOL`, `SCHEMA_VALIDATION`, `EXECUTION`. Available on `ToolResult.error_kind`,
  `AfterToolCallEvent.error_kind`, and `ToolCallSpan.error_kind`.
- **`InterruptControl`** (`flowra.agent`). New DI service with `interrupt()` (self + children)
  and `interrupt_children()` (children only). Enables in-hierarchy interruption patterns
  like model escalation.
- **`Interrupted` binding in steps**. Steps declaring `| Interrupted` in their union type
  now receive interrupted child results directly instead of auto-propagation.
- **Escalation example** (`examples/escalation.py`). Demonstrates fast model → interrupt →
  smart model pattern using `InterruptControl`, `TierService`, and `AfterToolCallEvent`.
  Run with `make escalation`.

### Changed
- **Observability types moved** from `flowra.llm` to `flowra.lib.observability`:
  `LLMCallSpan`, `ToolCallSpan`, `TextDeltaEvent`, `ThinkingDeltaEvent`.
  Import: `from flowra.lib.observability import LLMCallSpan, ToolCallSpan`.
- **MLflow/OTel** now record `error_kind` on tool spans — MLflow in outputs,
  OTel as `flowra.tool.error_kind` attribute.

## [0.0.19] - 2026-03-22

### Added
- **OpenTelemetry tracing** (`flowra.ext.otel`). Span-hook integration using GenAI
  semantic conventions (`gen_ai.operation.name`, `gen_ai.provider.name`,
  `gen_ai.usage.*`, etc.). Works with any OTel backend — Jaeger, Grafana Tempo,
  Datadog, etc. Optional dependency: `flowra[otel]`.
- **Tracing guide** (`docs/ext/tracing-guide.md`). Describes four setup options:
  MLflow only, OTel only, both independently, MLflow with OTel export — with
  trade-offs and configuration for each.

## [0.0.18] - 2026-03-22

### Added
- **`FlowingContextVar`** (`flowra.agent.flow.flowing`). Typed variables that flow
  with agent execution — the engine manages lifecycle (fork/restore for sibling
  isolation, snapshot/apply for asyncio task inheritance). Any integration can
  create flowing vars to store contextual data that propagates correctly through
  the execution tree.

### Changed
- **MLflow handler rewritten** to use `FlowingContextVar` for parent span tracking.
  Fixes sibling span chaining bug in Spawn (children now correctly appear as parallel
  siblings, not a nested chain). Removes internal `InMemoryTraceManager` dependency,
  uses public `mlflow.update_current_trace()` for trace previews.
  Adds `set_span_in_context()`/`detach_span_from_context()` for W3C `traceparent`
  propagation — external services can now attach their traces as children.

## [0.0.17] - 2026-03-22

### Added
- **`AnthropicToolSearch`** (`flowra.lib.anthropic`). Deferred tool loading for
  large tool sets — marks tools with `defer_loading: true`, adds server-side
  search tool (BM25 or regex). Reduces token usage by ~85% with 50+ tools.

### Changed
- **Moved Anthropic extensions** from `flowra.ext.anthropic` to `flowra.lib.anthropic` —
  split into `cache.py`, `tool_search.py`, `presets.py`. Not an ext (no extra deps).

## [0.0.16] - 2026-03-21

### Added
- **`transient: bool` field on `LLMData`.** All blocks, messages, and `Tool` inherit this
  general-purpose hint that marks content as non-permanent. Used by caching extensions to
  skip transient content when placing cache breakpoints.
- **`PrepareLLMRequestEvent` hook.** Emitted after `LLMRequest` is built but before the LLM
  call. Allows hooks to modify the request (e.g. for prompt caching, tool deferral).
- **Composable Anthropic caching extensions** (`flowra.lib.anthropic`). Hook bundles that set
  `cache_control` via `PrepareLLMRequestEvent`: `AnthropicCacheAllSystemMessages`,
  `AnthropicCacheNonTransientSystemMessages`, `AnthropicCacheAllTools`,
  `AnthropicCacheAllMessages`, `AnthropicCacheNonTransientMessages`,
  `AnthropicCacheHistoryMessages`, and composite presets `ANTHROPIC_CACHE_ALL`
  and `ANTHROPIC_CACHE_SESSION`.
- **`Tool` inherits from `LLMData`.** Tool definitions now have `metadata`, `extra`, and
  `transient` fields.
- **Providers pass through `extra` during serialization.** `AnthropicVertexProvider` merges
  `block.extra` into output dicts (`**block.extra`), enabling direct use of provider-specific
  fields like `cache_control`.

### Removed
- **`cache: bool` field** from all blocks (`TextBlock`, `ImageBlock`, `ToolUseBlock`,
  `ToolResultBlock`, `ThinkingBlock`) and `Tool`. Use `extra={"cache_control": ...}` or
  the `flowra.lib.anthropic` hook bundles instead.
- **`CacheConfig` / cache strategy system.** Removed `CacheConfig`, `CACHE_ALL`,
  `CACHE_SESSION`, `CACHE_MANUAL`, `NO_CACHE`, and all individual strategy functions.
  Replaced by composable hook bundles in `flowra.lib.anthropic`.

### Changed
- **Separated system messages in `LLMRequest`.** `LLMRequest` now has `system: list[SystemMessage]`
  and `messages: list[UserMessage | AssistantMessage]` instead of a single mixed `messages: list[Message]`.
  Providers no longer extract system messages at runtime — the split is enforced by types.
- **Renamed config fields.** `ToolLoopConfig`: `system` + `history` (was `session_messages`).
  `ChatConfig`: `system` (was `system_messages`). `LLMCallSpec`: `system` + `messages`.
- **Renamed `SaveTurnMessagesEvent`** → `SaveHistoryEvent`.
- **MLflow integration** — replaced `Any` types with proper `LLMRequest`, `Message`, `AssistantMessage`;
  rewrote message conversion with exhaustive `match/case`.

## [0.0.15] - 2026-03-19

### Added
- **Multi-agent patterns cookbook** (`docs/patterns.md`). Recipes with minimal code
  examples: router, pipeline, fan-out/fan-in, race (first wins), feedback loop,
  partial results (WhenN), timeout composition.
- **`LLMResponse.extra` for provider-specific data.** All providers now populate
  `extra` with `provider_stop_reason` (raw stop reason string) and `id` (response ID
  where available). Use for debugging and logging.

### Changed
- **Unified `TextDeltaEvent` / `ThinkingDeltaEvent`.** Both agents (`ToolLoopAgent`,
  `LLMCallAgent`) now share a single definition from `flowra.llm`. Removed the
  `context: ToolLoopAgentContext` field — use `event.context` (ExecutionContext) instead.
  Import: `from flowra.llm import TextDeltaEvent, ThinkingDeltaEvent`.

## [0.0.14] - 2026-03-19

### Added
- **MLflow tracing integration** (`flowra/ext/mlflow.py`). `install_mlflow_tracing(hooks)`
  subscribes to span-hooks (`AgentSpan`, `StepSpan`, `LLMCallSpan`, `ToolCallSpan`) and
  maps them to MLflow traces with structured chat UI (OpenAI-format messages, tools, usage).
  Session tracking via `session_id` parameter for multi-turn chat grouping.
  Optional dependency: `flowra[mlflow]`.
- **`__preview__()` protocol for readable trace summaries.** Objects implementing
  `__preview__() -> str` get clean text in MLflow's list/session view instead of
  `str()`. `ChatSpec`, `ChatResult`, `ToolLoopSpec`, `ToolLoopResult` implement it
  out of the box.

## [0.0.13] - 2026-03-19

### Added
- **Span-hooks: observability primitive with guaranteed enter/exit.** New mechanism
  alongside existing hooks, specifically for observability. Register via
  `hooks.on_span(SpanType, handler)`. Handler receives `Event[T]` (same envelope
  as regular hooks, with execution context) — access span via `event.data`. Returns
  `SpanExitHandler(error: BaseException | None)` or `None`. Later subscribers are
  "more outer". Exception-safe — exit handlers always run. `open_span()`/`close_span()`
  for long-lived spans, `async with emitter.span()` for simple cases.
- **Engine-level span types.** `AgentSpan` (agent lifecycle) and `StepSpan`
  (individual step invocations). Engine opens/closes spans at all lifecycle points:
  node creation, GotoStep, GotoAgent, Spawn, completion, interruption.
- **`LLMCallSpan`** and **`ToolCallSpan`** (`flowra.llm`) — shared span types for
  LLM calls and tool calls.

### Removed
- **`BeforeLLMCallEvent` / `AfterLLMCallEvent`** from both `tool_loop` and `llm_call`.
  Replaced by `LLMCallSpan` span-hook.

## [0.0.12] - 2026-03-18

### Added
- **`CostBreakdown` for detailed cost reporting.** New `CostBreakdown` dataclass with
  per-category cost fields: `input`, `output`, `cache_read`, `cache_creation`, and a
  `total` property. Added `cost: CostBreakdown | None` field to `Usage` alongside the
  existing `cost_usd`. All pricing modules now return `CostBreakdown`, and all providers
  populate both fields.
- **`tools/sync_pricing.py`** — script to sync pricing tables from litellm's
  `model_prices_and_context_window.json`. Dry-run by default, `--apply` to update files.

### Changed
- **Pricing modules return `CostBreakdown` instead of `float`.** `estimate_cost()` in
  `anthropic`, `openai`, and `google` pricing modules now returns `CostBreakdown | None`.
- **Updated pricing tables (March 2026).** Added GPT-5.4 mini/nano. Fixed OpenAI
  cache_read prices to match litellm data.

## [0.0.11] - 2026-03-17

### Added
- **`LLMProvider.aclose()` and async context manager.** All providers now support
  `async with provider:` for proper resource cleanup. Providers that create their
  own client close it automatically; pass `owns_client=True` to transfer ownership
  of an externally created client.

### Changed
- **Split `HookRegistry` into `HookSubscription` + `HookEmitter`.** `HookRegistry` is removed.
  Users create `HookSubscription` (register handlers via `on()`), pass it in services.
  Agents receive `HookEmitter` (emit events, check handlers) via DI. Runtime creates
  `HookEmitter` from subscription handlers + `ExecutionContext` automatically.
- **Unified `flowra.agent` package.** Merged `flowra.agent` and `flowra.runtime` into a
  single `flowra.agent` package. All public symbols (`AgentRuntime`, `InMemorySessionStorage`,
  `FileSessionStorage`, `InterruptTokenSource`, etc.) are now imported from `flowra.agent`.
  The `flowra.runtime` package is removed. New subpackage structure: `definition/`, `flow/`,
  `state/`, `storage/`, `runtime/`, `services.py`.
- **New public symbols.** `ExecutionContext`, `ExecutionFrame`, `AgentInfo`, `InterruptedError`,
  `with_interrupt` added to `flowra.agent` public API.
- **`FORK` storage key for explicit scope forking.** `CallStep` without `storage_key` now
  shares the parent's scope (same state). Use `storage_key=FORK` to get an isolated copy
  of the parent's state (previous default behavior). `NEW_SCOPE` and explicit string keys
  still create fresh scopes. `FORK` is also available for `GotoStep`.

### Fixed
- **Schema formatting shows type names in unions.** `format_schema_for_llm` now adds
  `// TypeName` comments after `{` for objects with a `title` field. This helps LLMs
  (especially Anthropic, which uses prompt-based structured output) correctly distinguish
  union variants like `Dog | Cat` instead of merging their fields.

## [0.0.10] - 2026-03-15

### Changed
- **`NoSpec`/`NoResult` replaced with `None`.** Use `Agent[None, MyResult]` instead of
  `Agent[NoSpec, MyResult]`, and `Agent[MySpec, None]` instead of `Agent[MySpec, NoResult]`.
  The sentinel classes are removed.
- **`ServiceLocator.provide()` infers type.** `sl.provide(LLMConfig(...))` now works —
  the type is inferred from `type(value)`. The two-argument form `sl.provide(LLMConfig, ...)`
  still works for providing by base type.

## [0.0.9] - 2026-03-15

### Changed
- **Agent spec injection via constructor.** Agent spec (`S` from `Agent[S, R]`) is now
  passed to the agent's `__init__` by type matching at compile time. Spec is NOT a service —
  it does not leak into child agents via `parent_services`.
  ```python
  class Researcher(Agent[ResearchSpec, ResearchResult]):
      def __init__(self, spec: ResearchSpec, sl: ServiceLocator) -> None:
          sl.provide(LLMConfig, LLMConfig(model=spec.model))
  ```
- **Removed `FromAgentSpec`.** Agent spec is no longer available as a step parameter binding
  source. Use the constructor to receive the spec and store it on `self` if needed in steps.
- **Binding markers → UPPER_CASE sentinels.** `FromSpec`, `FromChild`, `FromChildren`
  replaced with `step_arg.SPEC`, `step_arg.CHILD`. `FromChildren` removed — `list[T]` hint
  handles list mode automatically. `FromToolInput`, `FromToolService` replaced with
  `tool_arg.INPUT`, `tool_arg.SERVICE`. New `agent_arg.SPEC`, `agent_arg.SERVICE` for
  agent constructor binding.
- **Removed `HookContext` and `HookProvider`.** `HookContext` replaced entirely by
  `ExecutionContext`. `HookProvider` protocol removed — use `registry.on()` directly.
- `LLMCallResult` now includes `elapsed: float` — wall-clock seconds for the LLM call.

### Added
- `LLMCallAgent` — pre-built agent for single LLM calls. Messages in, response out,
  no tool loop, no session history. Auto-switches to streaming when `TextDeltaEvent`
  or `ThinkingDeltaEvent` handlers are registered. Own hook events independent from
  `ToolLoopAgent`.
- `ExecutionContext` — automatic execution metadata on every emitted event. Two navigable hierarchies:
  - **Execution stack** (`ExecutionContext.stack`): runtime call chain from root to emitting agent.
    Each `ExecutionFrame` carries `agent: AgentInfo`, `spec`, and `tag`.
  - **Registration hierarchy** (`AgentInfo.parent`): agent's position in the name tree.
    Each `AgentInfo` has `name`, `path`, `source_type`, and `parent`.
  - `HookRegistry.with_context()` creates a new registry sharing handlers but stamping
    a different context — the runtime uses this to give each execution node its own context.
- `ExecutionContext` stack navigation helpers: `find_spec(type)`, `get_spec(type)`,
  `find_frame(spec_type=, agent_type=)`, `get_frame(spec_type=, agent_type=)` — search the
  execution stack from current frame upward. `get_*` variants raise `LookupError` on miss.
- `Event.context` is now always `ExecutionContext` (no longer optional). `HookRegistry.emit()`
  raises `RuntimeError` if called without context — ensures events are only emitted within runtime.

## [0.0.8] - 2026-03-14

### Changed
- Renamed interrupt exception: `Interrupted` → `InterruptedError`. The old name `Interrupted`
  is now a frozen dataclass result type (used for interrupt propagation through the execution tree).
- Renamed internal module `flowra/agent/agent_def.py` → `flowra/agent/model.py`.
- **Per-node interrupt tokens.** Each execution node gets its own `InterruptToken` with
  parent→child cascade. `InterruptedError` is caught per-node and converted to `Interrupted()`
  result. `runtime.run()` returns `Interrupted()` instead of `None` on interrupt.
- **Interrupted auto-propagation.** `Interrupted` results flow up the execution tree.
  Parent join-steps receive `None` for interrupted children's nullable parameters;
  if binding fails due to missing results, the parent auto-propagates `Interrupted()`.

### Added
- `Interrupted` frozen dataclass — typed result for interrupted agents (`reason: str | None`).
- **Composable spawn strategies**: `WhenAll`, `WhenAny`, `WhenN` combinators for `Spawn`.
  `Spawn` now accepts positional `SpawnNode` args (alongside the existing `children=` keyword).
  Combinators are nestable: `Spawn(WhenAny(WhenAll(a, b), c), then="join")`.
- `timeout(seconds=, minutes=)` helper — shortcut for a timeout child agent.
  Returns `TimeoutExpired(seconds=...)` on expiry, `Interrupted()` if cancelled.
- `TimeoutExpired` frozen dataclass — result type for the built-in timeout agent.

## [0.0.7] - 2026-03-13

### Changed
- Slots are now created in the agent constructor via `store.slot(Scalar[int], "key")`
  instead of declarative `slot("key")` class attributes. `AgentStore` now provides the
  `slot()` method; the old `slot()` sentinel and `SlotMarker` are removed.
- **Annotated-based step parameter binding.** Step parameters now bind by matching type
  annotations against available values (step spec, child outputs). Optional
  `step_arg` markers (`step_arg.SPEC`, `step_arg.CHILD`, `step_arg.CHILD`) narrow binding
  to a specific source. Replaces the old `StepSpec`/`AgentResult` base class approach —
  user types no longer need to inherit from marker classes. All step parameter and return
  types (other than action types and `None`) must be dataclasses.
- `NoSpec` / `NoResult` are now standalone sentinels (not frozen dataclasses).
- `Agent[S, R]` generic parameters no longer require `StepSpec`/`AgentResult` bounds.

### Added
- `step_arg.SPEC`, `step_arg.CHILD`, `step_arg.CHILD` markers for `Annotated`-based step parameter binding.
- `ChildOutput` bridge type for passing child results with tags between runtime and agent.
- `tag` field on `CallStep` and `CallAgent` — labels a child so the join step can bind
  its result by tag via `step_arg.CHILD("tag")`.
- `allowed_tools` / `denied_tools` now support wildcard patterns via `fnmatch`
  (e.g. `{"mcp_*"}`, `{"debug_?"}`).
- **Exception-based interrupts** (.NET `CancellationToken` pattern):
  `InterruptToken.check()` raises `Interrupted` (like `ThrowIfCancellationRequested`),
  `with_interrupt()` raises `Interrupted` instead of silently ending the loop.
  Uncaught `Interrupted` from any step is caught by the engine — the entire execution
  tree completes immediately and `runtime.run()` returns `None`. Agents and tools can
  catch `Interrupted` explicitly for graceful partial results; `ToolCallAgent` catches
  it from tool execution and returns an error `ToolResultBlock`.

## [0.0.6] - 2026-03-12

### Changed
- Renamed `ToolLoopConfig.max_iterations` → `max_llm_calls` (and `ToolLoopStatus.MAX_ITERATIONS`
  → `MAX_LLM_CALLS`) to avoid confusion with the new runtime-level `max_iterations`.
- Unified sentinel values: `Scalar` and `AgentRuntime` now use shared `Unset`/`UNSET`
  from `flowra._sentinel` instead of per-module private sentinels.

### Added
- **Agents as tools**: `@agent_tool` decorator exposes an agent class as a tool that
  the LLM can call autonomously. `get_agent_tool()` extracts the tool for registry,
  `make_agent_tool()` builds one programmatically. The LLM sees a regular tool; behind
  the scenes, the sub-agent is spawned with its own system prompt and tool loop.
- **Runtime limits**: `AgentRuntime` now supports `max_iterations` (engine advance steps)
  and `timeout` (seconds). Both can be set as defaults in the constructor and overridden
  per `run()`/`resume()` call.
- `format_schema_for_llm` now handles array-style `type` (e.g. `["string", "null"]`).

## [0.0.5] - 2026-03-11

### Changed
- **Agents as black boxes**: agents now have a single entry point (`@step(entry=True)`),
  a typed spec (`S`), and a typed result (`R`) via `Agent[S, R]`. You run an agent —
  not a step of an agent. Steps are internal implementation details.
- **Explicit control flow separation**: split `Goto`/`Call` into `GotoStep`/`GotoAgent`
  and `CallStep`/`CallAgent` — internal step navigation vs external agent invocation.
- **Compile-time validation**: compiler extracts spec/result types from `Agent[S, R]`,
  validates entry step spec matches generic `S`, enforces single entry per agent,
  resolves `TypeAlias` unions.
- `NoSpec` / `NoResult` sentinels for agents that don't need spec or result types.
- `runtime.run()` no longer accepts `step=` parameter — entry point is determined
  by the agent itself.

### Fixed
- `cache_last_session_message` now correctly clears cache hints from turn messages.

## [0.0.4] - 2026-03-09

### Fixed
- **JSON schema response cleanup**: `AnthropicVertexProvider` now returns a single `TextBlock`
  with clean JSON when `json_schema` is set — markdown fences and thinking blocks are stripped.
  Previously, validated JSON was cleaned internally but the original (fenced) text was returned.
- `validate_json_schema` now returns `(error, cleaned_text)` tuple so callers get the
  fence-stripped text.

## [0.0.3] - 2026-03-08

### Changed
- **Hook system redesign**: replaced `ToolLoopHooks`/`ChatHooks` (24 Protocol classes, 12 executor
  functions, 5 result dataclasses) with generic `HookRegistry` + `Event[T]` pattern. Supports
  multiple handlers per event, `HookProvider` for distributable hook sets, and `propagate_to()`
  for parent/child isolation. Hook events are plain mutable dataclasses with result fields.
- `ToolLoopSpec.meta` / `ChatSpec.meta` renamed to `metadata`.

## [0.0.2] - 2026-03-08

### Added
- **Streaming**: `LLMProvider.stream()` method returns `AsyncIterator[StreamEvent]` with `TextDelta`, `ThinkingDelta`, and `ContentComplete` events. All three built-in providers implement real-time streaming. Default fallback calls `call()` and yields `ContentComplete`.
- **Anthropic thinking**: `AnthropicVertexAdditionalConfig` with `thinking_budget_tokens` enables extended thinking on Claude models. Thinking blocks are now parsed from Anthropic responses (`ThinkingBlock`).
- **Streaming hooks**: `on_text_delta` and `on_thinking_delta` hooks in `ToolLoopHooks`. When set, the agent automatically uses `stream()` instead of `call()`. Streaming respects `InterruptToken` — exits immediately even if the LLM is blocked.
- **`with_interrupt`**: Generic async iterator wrapper that races `__anext__()` against `InterruptToken.wait()` via `asyncio.wait(FIRST_COMPLETED)`. Used internally by `ToolLoopAgent` for streaming; available as `from flowra.agent import with_interrupt`.
- **Thinking model entry**: `anthropic/sonnet-4-5-think` in example model registry with 4000 token thinking budget.
- **Console/TUI streaming**: `--stream` flag for `console_chat.py` and `tui_chat.py` examples.

## [0.0.1] - 2026-03-07

Initial release.

### Added
- State machine agents with `@step` methods, `Goto`, `Spawn`, and stored values (`Scalar`, `AppendOnlyList`)
- Provider-agnostic LLM abstraction (`LLMProvider`, `LLMRequest`, `LLMResponse`)
- LLM providers: `AnthropicVertexProvider`, `GoogleVertexProvider`, `OpenAIProvider`
- Tool integration: `@tool` decorator, MCP server support, DI into tool handlers
- Execution engine with persistence, crash recovery, and cooperative interrupts
- Pre-built agents: `ChatAgent` (multi-turn chat) and `ToolLoopAgent` (tool loop with hooks)
- `ChatHooks` with `on_save_turn_messages` for transient message filtering
- Optional provider dependencies via extras: `flowra[anthropic]`, `flowra[openai]`, `flowra[google]`, `flowra[all]`
- Python 3.12, 3.13, 3.14 support
