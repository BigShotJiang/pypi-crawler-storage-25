import dataclasses
import uuid
from decimal import Decimal
from typing import Annotated, ClassVar

import pytest

from flowra.agent import (
    Agent,
    AgentDefinitionRef,
    AgentRuntime,
    AgentStore,
    CallAgent,
    InMemorySessionStorage,
    Scalar,
    Spawn,
    agent_arg,
    step,
)


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class IntSpec:
    n: int


@dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
class StrSpec:
    s: str


class IntWorker(Agent[IntSpec, int]):
    """Returns spec.n doubled."""

    @step(entry=True)
    async def run(self, spec: Annotated[IntSpec, agent_arg.AGENT_SPEC]) -> int:
        return spec.n * 2


class StrWorker(Agent[StrSpec, str]):
    """Returns spec.s uppercased."""

    @step(entry=True)
    async def run(self, spec: Annotated[StrSpec, agent_arg.AGENT_SPEC]) -> str:
        return spec.s.upper()


class DecimalWorker(Agent[IntSpec, Decimal]):
    """Returns spec.n as Decimal."""

    @step(entry=True)
    async def run(self, spec: Annotated[IntSpec, agent_arg.AGENT_SPEC]) -> Decimal:
        return Decimal(spec.n)


class UUIDWorker(Agent[StrSpec, uuid.UUID]):
    """Returns UUID parsed from spec.s."""

    @step(entry=True)
    async def run(self, spec: Annotated[StrSpec, agent_arg.AGENT_SPEC]) -> uuid.UUID:
        return uuid.UUID(spec.s)


class TestPrimitiveChildJoin:
    async def test_join_single_int_child(self) -> None:
        class Parent(Agent[None, int]):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {"w": IntWorker}

            @step(entry=True)
            async def start(self) -> Spawn:
                return Spawn(children=[CallAgent(agent="parent/w", spec=IntSpec(n=21))], then=self.collect)

            @step
            async def collect(self, value: Annotated[int, agent_arg.CHILD]) -> int:
                return value + 1

        runtime = AgentRuntime(agents={"parent": Parent})
        result = await runtime.run(agent="parent")
        assert result == 43

    async def test_join_single_str_child(self) -> None:
        class Parent(Agent[None, str]):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {"w": StrWorker}

            @step(entry=True)
            async def start(self) -> Spawn:
                return Spawn(
                    children=[CallAgent(agent="parent/w", spec=StrSpec(s="hello"))],
                    then=self.collect,
                )

            @step
            async def collect(self, value: Annotated[str, agent_arg.CHILD]) -> str:
                return f"got {value}"

        runtime = AgentRuntime(agents={"parent": Parent})
        result = await runtime.run(agent="parent")
        assert result == "got HELLO"

    async def test_join_decimal_child(self) -> None:
        class Parent(Agent[None, Decimal]):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {"w": DecimalWorker}

            @step(entry=True)
            async def start(self) -> Spawn:
                return Spawn(
                    children=[CallAgent(agent="parent/w", spec=IntSpec(n=100))],
                    then=self.collect,
                )

            @step
            async def collect(self, value: Annotated[Decimal, agent_arg.CHILD]) -> Decimal:
                return value + Decimal("0.5")

        runtime = AgentRuntime(agents={"parent": Parent})
        result = await runtime.run(agent="parent")
        assert result == Decimal("100.5")

    async def test_join_uuid_child(self) -> None:
        target = uuid.UUID("12345678-1234-5678-1234-567812345678")

        class Parent(Agent[None, str]):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {"w": UUIDWorker}

            @step(entry=True)
            async def start(self) -> Spawn:
                return Spawn(
                    children=[CallAgent(agent="parent/w", spec=StrSpec(s=str(target)))],
                    then=self.collect,
                )

            @step
            async def collect(self, value: Annotated[uuid.UUID, agent_arg.CHILD]) -> str:
                return str(value)

        runtime = AgentRuntime(agents={"parent": Parent})
        result = await runtime.run(agent="parent")
        assert result == str(target)

    async def test_join_list_of_int_children(self) -> None:
        class Parent(Agent[None, int]):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {"w": IntWorker}

            @step(entry=True)
            async def start(self) -> Spawn:
                return Spawn(
                    children=[
                        CallAgent(agent="parent/w", spec=IntSpec(n=1), state="a"),
                        CallAgent(agent="parent/w", spec=IntSpec(n=2), state="b"),
                        CallAgent(agent="parent/w", spec=IntSpec(n=3), state="c"),
                    ],
                    then=self.collect,
                )

            @step
            async def collect(self, values: Annotated[list[int], agent_arg.CHILDREN]) -> int:
                return sum(values)

        runtime = AgentRuntime(agents={"parent": Parent})
        result = await runtime.run(agent="parent")
        assert result == 2 + 4 + 6

    async def test_join_tagged_primitive_children(self) -> None:
        class Parent(Agent[None, str]):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {
                "i": IntWorker,
                "s": StrWorker,
            }

            @step(entry=True)
            async def start(self) -> Spawn:
                return Spawn(
                    children=[
                        CallAgent(agent="parent/i", spec=IntSpec(n=5), tag="num"),
                        CallAgent(agent="parent/s", spec=StrSpec(s="ok"), tag="text"),
                    ],
                    then=self.collect,
                )

            @step
            async def collect(
                self,
                number: Annotated[int, agent_arg.CHILD("num")],
                text: Annotated[str, agent_arg.CHILD("text")],
            ) -> str:
                return f"{text}:{number}"

        runtime = AgentRuntime(agents={"parent": Parent})
        result = await runtime.run(agent="parent")
        assert result == "OK:10"


class TestPrimitiveParamValidation:
    def test_typed_primitive_child_param_compiles(self) -> None:
        """A step can declare Annotated[int, agent_arg.CHILD] at compile time."""

        class Parent(Agent[None, int]):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {"w": IntWorker}

            @step(entry=True)
            async def start(self) -> Spawn:
                return Spawn(children=[CallAgent(agent="parent/w", spec=IntSpec(n=1))], then=self.collect)

            @step
            async def collect(self, value: Annotated[int, agent_arg.CHILD]) -> int:
                return value

        defn = Parent.__agent_definition__
        assert "collect" in defn.steps

    def test_unsupported_class_as_typed_child_raises(self) -> None:
        class Custom:
            pass

        def _build() -> None:
            class Parent(Agent[None, int]):
                @step(entry=True)
                async def start(self) -> int:
                    return 1

                @step
                async def collect(self, value: Annotated[Custom, agent_arg.CHILD]) -> int:
                    _ = value
                    return 1

            assert Parent  # pragma: no cover

        with pytest.raises(TypeError, match="must be a dataclass"):
            _build()


# -- List / dict as results -----------------------------------------------------


class ListWorker(Agent[IntSpec, list[int]]):
    """Returns a list of ints 0..n."""

    @step(entry=True)
    async def run(self, spec: Annotated[IntSpec, agent_arg.AGENT_SPEC]) -> list[int]:
        return list(range(spec.n))


class DictWorker(Agent[StrSpec, dict]):
    """Returns a dict keyed by the spec string."""

    @step(entry=True)
    async def run(self, spec: Annotated[StrSpec, agent_arg.AGENT_SPEC]) -> dict:
        return {"key": spec.s, "length": len(spec.s)}


class MixedDictWorker(Agent[StrSpec, dict]):
    """Returns a dict mixing stdlib types — exercises recursive serialization."""

    @step(entry=True)
    async def run(self, spec: Annotated[StrSpec, agent_arg.AGENT_SPEC]) -> dict:
        return {
            "id": uuid.UUID(spec.s),
            "amount": Decimal("3.14"),
            "items": [1, 2, 3],
        }


class TestListDictResults:
    async def test_list_result_returned_directly(self) -> None:
        runtime = AgentRuntime(agents={"w": ListWorker})
        result = await runtime.run(agent=ListWorker, spec=IntSpec(n=4))
        assert result == [0, 1, 2, 3]

    async def test_dict_result_returned_directly(self) -> None:
        runtime = AgentRuntime(agents={"w": DictWorker})
        result = await runtime.run(agent=DictWorker, spec=StrSpec(s="hello"))
        assert result == {"key": "hello", "length": 5}

    async def test_mixed_dict_roundtrips_through_child_join(self) -> None:
        target_uuid = uuid.UUID("12345678-1234-5678-1234-567812345678")

        class Parent(Agent[None, dict]):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {"w": MixedDictWorker}

            @step(entry=True)
            async def start(self) -> Spawn:
                return Spawn(
                    children=[CallAgent(agent="parent/w", spec=StrSpec(s=str(target_uuid)))],
                    then=self.collect,
                )

            @step
            async def collect(self, value: Annotated[dict, agent_arg.CHILD]) -> dict:
                return value

        runtime = AgentRuntime(agents={"parent": Parent})
        result = await runtime.run(agent="parent")
        assert isinstance(result, dict)
        assert result["id"] == target_uuid
        assert result["amount"] == Decimal("3.14")
        assert result["items"] == [1, 2, 3]

    async def test_list_from_child_bound_as_whole(self) -> None:
        class Parent(Agent[None, int]):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {"w": ListWorker}

            @step(entry=True)
            async def start(self) -> Spawn:
                return Spawn(
                    children=[CallAgent(agent="parent/w", spec=IntSpec(n=5))],
                    then=self.collect,
                )

            @step
            async def collect(self, value: Annotated[list, agent_arg.CHILD]) -> int:
                return sum(value)

        runtime = AgentRuntime(agents={"parent": Parent})
        result = await runtime.run(agent="parent")
        assert result == 0 + 1 + 2 + 3 + 4


# -- Crash recovery -------------------------------------------------------------


class TestCrashRecoveryWithListDictState:
    """Simulate a crash mid-flight and verify that list/dict state survives a snapshot/restore."""

    async def test_list_state_persists_across_runtimes(self) -> None:
        """Agent with persistent list state — snapshot, build fresh runtime, continue."""

        class Collector(Agent[StrSpec, list[str]]):
            __slots__ = ("__items",)

            def __init__(self, store: AgentStore) -> None:
                self.__items = store.persistent.slot(Scalar[list[str]], "items")

            @step(entry=True)
            async def run(self, spec: Annotated[StrSpec, agent_arg.AGENT_SPEC]) -> list[str]:
                current = self.__items.get([])
                updated = [*current, spec.s]
                self.__items.set(updated)
                return updated

        storage1 = InMemorySessionStorage()
        runtime1 = AgentRuntime(agents={"c": Collector}, storage=storage1)
        r1 = await runtime1.run(agent=Collector, spec=StrSpec(s="first"), state="main")
        assert r1 == ["first"]

        snapshot = storage1.snapshot()

        storage2 = InMemorySessionStorage(snapshot)
        runtime2 = AgentRuntime(agents={"c": Collector}, storage=storage2)
        r2 = await runtime2.run(agent=Collector, spec=StrSpec(s="second"), state="main")
        assert r2 == ["first", "second"]

        snapshot2 = storage2.snapshot()
        storage3 = InMemorySessionStorage(snapshot2)
        runtime3 = AgentRuntime(agents={"c": Collector}, storage=storage3)
        r3 = await runtime3.run(agent=Collector, spec=StrSpec(s="third"), state="main")
        assert r3 == ["first", "second", "third"]

    async def test_dict_state_with_stdlib_values_persists(self) -> None:
        """Dict state with UUID/Decimal values survives snapshot/restore."""

        class Recorder(Agent[None, dict]):
            __slots__ = ("__data",)

            def __init__(self, store: AgentStore) -> None:
                self.__data = store.persistent.slot(Scalar[dict], "data")

            @step(entry=True)
            async def run(self) -> dict:
                current = self.__data.get({})
                if not current:
                    current = {
                        "id": uuid.UUID("550e8400-e29b-41d4-a716-446655440000"),
                        "amount": Decimal("100.50"),
                        "tags": ["alpha", "beta"],
                    }
                    self.__data.set(current)
                return current

        storage1 = InMemorySessionStorage()
        runtime1 = AgentRuntime(agents={"r": Recorder}, storage=storage1)
        r1 = await runtime1.run(agent=Recorder, state="main")
        assert r1["id"] == uuid.UUID("550e8400-e29b-41d4-a716-446655440000")
        assert r1["amount"] == Decimal("100.50")
        assert r1["tags"] == ["alpha", "beta"]

        snapshot = storage1.snapshot()
        storage2 = InMemorySessionStorage(snapshot)
        runtime2 = AgentRuntime(agents={"r": Recorder}, storage=storage2)
        r2 = await runtime2.run(agent=Recorder, state="main")
        assert r2 == r1
        assert isinstance(r2["id"], uuid.UUID)
        assert isinstance(r2["amount"], Decimal)

    async def test_child_list_result_survives_snapshot_between_runs(self) -> None:
        """A parent stores a child's list[int] result in persistent state; state survives snapshot.

        Note: the ``collect`` step binds ``Annotated[list, agent_arg.CHILD]`` (bare ``list``) —
        ``Annotated[list[int], agent_arg.CHILDREN]`` would mean "collect multiple int-returning
        children into a list", which is NOT the intent here (we want a single child whose whole
        result is a list).
        """

        class Parent(Agent[IntSpec, list[int]]):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {"w": ListWorker}
            __slots__ = ("__cache",)

            def __init__(self, store: AgentStore) -> None:
                self.__cache = store.persistent.slot(Scalar[list[int] | None], "cache")

            @step(entry=True)
            async def start(self, spec: Annotated[IntSpec, agent_arg.AGENT_SPEC]) -> Spawn | list[int]:
                cached = self.__cache.get(None)
                if cached is not None:
                    return cached
                return Spawn(children=[CallAgent(agent="parent/w", spec=spec)], then=self.collect)

            @step
            async def collect(self, value: Annotated[list, agent_arg.CHILD]) -> list[int]:
                self.__cache.set(value)
                return value

        storage1 = InMemorySessionStorage()
        runtime1 = AgentRuntime(agents={"parent": Parent}, storage=storage1)
        r1 = await runtime1.run(agent="parent", spec=IntSpec(n=5), state="main")
        assert r1 == [0, 1, 2, 3, 4]

        snapshot = storage1.snapshot()
        storage2 = InMemorySessionStorage(snapshot)
        runtime2 = AgentRuntime(agents={"parent": Parent}, storage=storage2)
        # Second run with the same state key should read the cached list without spawning again.
        r2 = await runtime2.run(agent="parent", spec=IntSpec(n=999), state="main")
        assert r2 == [0, 1, 2, 3, 4]


class TestListBindingSemantics:
    """``Annotated[list[X], CHILD]`` means ``collect X-typed children`` — not a single list-returning child."""

    async def test_list_x_binding_collects_x_typed_siblings(self) -> None:
        """`Annotated[list[int], CHILDREN]` collects each int-child's result into a list."""

        class Parent(Agent[None, int]):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {"w": IntWorker}

            @step(entry=True)
            async def start(self) -> Spawn:
                return Spawn(
                    children=[
                        CallAgent(agent="parent/w", spec=IntSpec(n=10), state="a"),
                        CallAgent(agent="parent/w", spec=IntSpec(n=20), state="b"),
                    ],
                    then=self.collect,
                )

            @step
            async def collect(self, values: Annotated[list[int], agent_arg.CHILDREN]) -> int:
                return sum(values)

        runtime = AgentRuntime(agents={"parent": Parent})
        assert await runtime.run(agent="parent") == 60

    async def test_bare_list_binding_collects_single_list_child(self) -> None:
        """`Annotated[list, CHILD]` binds a single child whose result IS a list."""

        class Parent(Agent[None, int]):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {"w": ListWorker}

            @step(entry=True)
            async def start(self) -> Spawn:
                return Spawn(
                    children=[CallAgent(agent="parent/w", spec=IntSpec(n=4))],
                    then=self.collect,
                )

            @step
            async def collect(self, value: Annotated[list, agent_arg.CHILD]) -> int:
                return len(value)

        runtime = AgentRuntime(agents={"parent": Parent})
        assert await runtime.run(agent="parent") == 4


# -- CHILD / CHILDREN marker semantics ------------------------------------------


class TestChildMarkerStrictSingle:
    """CHILD is strictly single — even for list[X], binds one child returning a list."""

    async def test_child_list_x_binds_single_list_child(self) -> None:
        """`Annotated[list[int], CHILD]` must bind one list-returning child."""

        class Parent(Agent[None, int]):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {"w": ListWorker}

            @step(entry=True)
            async def start(self) -> Spawn:
                return Spawn(
                    children=[CallAgent(agent="parent/w", spec=IntSpec(n=3))],
                    then=self.collect,
                )

            @step
            async def collect(self, value: Annotated[list[int], agent_arg.CHILD]) -> int:
                return sum(value)

        runtime = AgentRuntime(agents={"parent": Parent})
        assert await runtime.run(agent="parent") == 0 + 1 + 2

    async def test_child_list_x_rejects_multiple_scalar_children(self) -> None:
        """`Annotated[list[int], CHILD]` with many int-children finds no list — binds to [] via plural fallback? No: CHILD has only SingleBind, so nullable-or-error."""

        class Parent(Agent[None, int]):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {"w": IntWorker}

            @step(entry=True)
            async def start(self) -> Spawn:
                return Spawn(
                    children=[
                        CallAgent(agent="parent/w", spec=IntSpec(n=1), state="a"),
                        CallAgent(agent="parent/w", spec=IntSpec(n=2), state="b"),
                    ],
                    then=self.collect,
                )

            @step
            async def collect(self, value: Annotated[list[int] | None, agent_arg.CHILD] = None) -> int:
                # No list-returning child → CHILD matches nothing → value stays None.
                return -1 if value is None else sum(value)

        runtime = AgentRuntime(agents={"parent": Parent})
        assert await runtime.run(agent="parent") == -1


class TestChildrenMarkerStrictPlural:
    """CHILDREN is strictly plural; requires list[X]; empty list when no children match."""

    async def test_children_with_matching_siblings(self) -> None:
        class Parent(Agent[None, int]):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {"w": IntWorker}

            @step(entry=True)
            async def start(self) -> Spawn:
                return Spawn(
                    children=[
                        CallAgent(agent="parent/w", spec=IntSpec(n=3), state="a"),
                        CallAgent(agent="parent/w", spec=IntSpec(n=4), state="b"),
                    ],
                    then=self.collect,
                )

            @step
            async def collect(self, values: Annotated[list[int], agent_arg.CHILDREN]) -> int:
                return sum(values)

        runtime = AgentRuntime(agents={"parent": Parent})
        assert await runtime.run(agent="parent") == 6 + 8

    async def test_children_with_no_matches_binds_empty_list(self) -> None:
        """CHILDREN type-filters children; if none match, param binds to []."""

        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class OtherResult:
            v: str

        class OtherWorker(Agent[IntSpec, OtherResult]):
            @step(entry=True)
            async def run(self, spec: Annotated[IntSpec, agent_arg.AGENT_SPEC]) -> OtherResult:
                return OtherResult(v=str(spec.n))

        class Parent(Agent[None, int]):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {"w": OtherWorker}

            @step(entry=True)
            async def start(self) -> Spawn:
                return Spawn(
                    children=[CallAgent(agent="parent/w", spec=IntSpec(n=1))],
                    then=self.collect,
                )

            @step
            async def collect(
                self,
                ints: Annotated[list[int], agent_arg.CHILDREN],
                others: Annotated[list[OtherResult], agent_arg.CHILDREN],
            ) -> int:
                assert ints == []
                assert len(others) == 1
                return len(ints) + len(others)

        runtime = AgentRuntime(agents={"parent": Parent})
        assert await runtime.run(agent="parent") == 1

    def test_children_with_non_list_annotation_raises(self) -> None:
        def _build() -> None:
            class BadParent(Agent[None, int]):
                @step(entry=True)
                async def start(self) -> int:
                    return 1

                @step
                async def collect(self, value: Annotated[int, agent_arg.CHILDREN]) -> int:
                    return value

            assert BadParent  # pragma: no cover

        with pytest.raises(TypeError, match="CHILDREN requires a list"):
            _build()


class TestNoMarkerListAmbiguity:
    """No marker on list[X]: engine tries both Single(list) and Plural(X); unique wins."""

    async def test_unique_plural_interpretation_wins(self) -> None:
        """Only X-children present → plural interpretation is the sole match."""

        class Parent(Agent[None, int]):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {"w": IntWorker}

            @step(entry=True)
            async def start(self) -> Spawn:
                return Spawn(
                    children=[
                        CallAgent(agent="parent/w", spec=IntSpec(n=5), state="a"),
                        CallAgent(agent="parent/w", spec=IntSpec(n=6), state="b"),
                    ],
                    then=self.collect,
                )

            @step
            async def collect(self, values: list[int]) -> int:
                return sum(values)

        runtime = AgentRuntime(agents={"parent": Parent})
        assert await runtime.run(agent="parent") == 10 + 12

    async def test_unique_single_interpretation_wins(self) -> None:
        """Only a list-child present → single interpretation is the sole match."""

        class Parent(Agent[None, int]):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {"w": ListWorker}

            @step(entry=True)
            async def start(self) -> Spawn:
                return Spawn(
                    children=[CallAgent(agent="parent/w", spec=IntSpec(n=3))],
                    then=self.collect,
                )

            @step
            async def collect(self, values: list[int]) -> int:
                return len(values)

        runtime = AgentRuntime(agents={"parent": Parent})
        assert await runtime.run(agent="parent") == 3

    async def test_both_interpretations_match_raises_ambiguity(self) -> None:
        """A list-child AND X-children present → ambiguous. Runtime raises."""

        class Parent(Agent[None, int]):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {
                "lst": ListWorker,
                "int": IntWorker,
            }

            @step(entry=True)
            async def start(self) -> Spawn:
                return Spawn(
                    children=[
                        CallAgent(agent="parent/lst", spec=IntSpec(n=2), state="a"),
                        CallAgent(agent="parent/int", spec=IntSpec(n=7), state="b"),
                    ],
                    then=self.collect,
                )

            @step
            async def collect(self, values: list[int]) -> int:
                return sum(values)

        runtime = AgentRuntime(agents={"parent": Parent})
        with pytest.raises(RuntimeError, match="Ambiguous binding"):
            await runtime.run(agent="parent")

    async def test_no_matches_defaults_to_empty_list(self) -> None:
        """Neither interpretation matches → param defaults to []."""

        @dataclasses.dataclass(frozen=True, slots=True, kw_only=True)
        class UnrelatedResult:
            v: str

        class UnrelatedWorker(Agent[IntSpec, UnrelatedResult]):
            @step(entry=True)
            async def run(self, spec: Annotated[IntSpec, agent_arg.AGENT_SPEC]) -> UnrelatedResult:
                return UnrelatedResult(v=str(spec.n))

        class Parent(Agent[None, int]):
            __subagents__: ClassVar[dict[str, AgentDefinitionRef]] = {"w": UnrelatedWorker}

            @step(entry=True)
            async def start(self) -> Spawn:
                return Spawn(
                    children=[CallAgent(agent="parent/w", spec=IntSpec(n=9))],
                    then=self.collect,
                )

            @step
            async def collect(self, values: list[int]) -> int:
                return len(values)

        runtime = AgentRuntime(agents={"parent": Parent})
        assert await runtime.run(agent="parent") == 0
