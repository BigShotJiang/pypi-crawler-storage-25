"""MUX frame protocol — matches the Rust tibet-airlock wire format."""

from __future__ import annotations
import json
from dataclasses import dataclass, field


@dataclass
class MuxFrame:
    """A frame on the TIBET-MUX channel."""

    channel_id: int
    intent: str
    from_aint: str
    payload: str

    def to_bytes(self) -> bytes:
        return json.dumps({
            "channel_id": self.channel_id,
            "intent": self.intent,
            "from_aint": self.from_aint,
            "payload": self.payload,
        }).encode("utf-8")

    @classmethod
    def from_bytes(cls, data: bytes) -> MuxFrame:
        d = json.loads(data)
        return cls(
            channel_id=d["channel_id"],
            intent=d["intent"],
            from_aint=d["from_aint"],
            payload=d["payload"],
        )
