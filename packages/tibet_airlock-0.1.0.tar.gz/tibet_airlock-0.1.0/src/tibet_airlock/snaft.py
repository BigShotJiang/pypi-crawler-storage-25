"""
SNAFT — Syscall monitoring for intent-based execution.

Pure Python implementation matching the Rust SNAFT monitor.
Use this for local policy checking without the full airlock binary.
"""

from __future__ import annotations
from dataclasses import dataclass, field


# Syscalls that are always dangerous regardless of intent
ALWAYS_DANGEROUS = frozenset({
    "sys_ptrace",      # Process tracing — debugger/injection
    "sys_socket",      # Network access — data exfiltration
    "sys_connect",     # Outbound connection
    "sys_dlopen",      # Dynamic library loading
    "sys_fork",        # Process forking
    "sys_clone",       # Thread/process cloning
    "sys_mount",       # Filesystem mount
    "sys_reboot",      # System reboot
    "sys_kexec_load",  # Kernel replacement
})

# Base allowlist for all intents
BASE_ALLOWLIST = frozenset({
    "sys_execve", "sys_write", "sys_read",
    "sys_exit", "sys_brk", "sys_mprotect",
})

# Extra syscalls per intent
INTENT_EXTRAS: dict[str, frozenset[str]] = {
    "analyze_malware_sample": frozenset({"sys_open", "sys_stat", "sys_close"}),
    "code:execute": frozenset({"sys_open", "sys_stat", "sys_close", "sys_getpid"}),
    "file:scan": frozenset({"sys_open", "sys_stat", "sys_close", "sys_getdents"}),
    "call:voice": frozenset({"sys_sendto", "sys_recvfrom", "sys_ioctl"}),
    "call:video": frozenset({"sys_sendto", "sys_recvfrom", "sys_ioctl", "sys_mmap"}),
}

# Payload patterns that map to dangerous syscalls
DANGEROUS_PATTERNS: list[tuple[str, str]] = [
    ("os.system", "sys_socket"),
    ("subprocess", "sys_socket"),
    ("curl ", "sys_socket"),
    ("wget ", "sys_socket"),
    ("bash", "sys_socket"),
    ("/bin/sh", "sys_socket"),
    ("eval(", "sys_ptrace"),
    ("exec(", "sys_ptrace"),
    ("ptrace", "sys_ptrace"),
    ("mmap", "sys_mmap"),
    ("dlopen", "sys_dlopen"),
    ("LD_PRELOAD", "sys_dlopen"),
]


def _get_allowlist(intent: str) -> frozenset[str]:
    """Get the full allowlist for an intent (base + extras)."""
    extras = INTENT_EXTRAS.get(intent, frozenset())
    # Prefix match for call:voice:*, call:video:*
    if not extras:
        for prefix, extra_set in INTENT_EXTRAS.items():
            if intent.startswith(prefix):
                extras = extra_set
                break
    return BASE_ALLOWLIST | extras


@dataclass
class SnaftDecision:
    """Triage decision from SNAFT monitoring."""

    is_safe: bool
    reason: str
    violations: list[str] = field(default_factory=list)
    observed_syscalls: list[str] = field(default_factory=list)

    @property
    def is_kill(self) -> bool:
        return not self.is_safe


class SnaftMonitor:
    """
    Monitor syscalls against intent-specific policy.

    Usage:
        monitor = SnaftMonitor("code:execute")
        monitor.log_syscall("sys_write")    # OK
        monitor.log_syscall("sys_socket")   # VIOLATION
        decision = monitor.triage()
        assert decision.is_kill
    """

    def __init__(self, intent: str):
        self.intent = intent
        self.observed_syscalls: list[str] = []
        self.violations: list[str] = []
        self._allowlist = _get_allowlist(intent)

    def log_syscall(self, call: str) -> bool:
        """Log a syscall. Returns True if allowed, False if violation."""
        self.observed_syscalls.append(call)

        if call in ALWAYS_DANGEROUS:
            msg = f"{call} (blocked: dangerous syscall for any intent)"
            self.violations.append(msg)
            return False

        if call not in self._allowlist:
            msg = f"{call} (not allowed for intent '{self.intent}')"
            self.violations.append(msg)
            return False

        return True

    def scan_payload(self, payload: str) -> list[str]:
        """Scan a payload string for dangerous patterns. Returns detected syscalls."""
        detected = []
        # Always starts with execve
        self.log_syscall("sys_execve")

        for pattern, syscall in DANGEROUS_PATTERNS:
            if pattern in payload:
                self.log_syscall(syscall)
                detected.append(f"{pattern} -> {syscall}")

        if not self.violations:
            self.log_syscall("sys_write")
            self.log_syscall("sys_exit")

        return detected

    def triage(self, error: str | None = None) -> SnaftDecision:
        """Final triage decision based on all observations."""
        if error:
            return SnaftDecision(
                is_safe=False,
                reason=error,
                violations=list(self.violations),
                observed_syscalls=list(self.observed_syscalls),
            )

        if self.violations:
            return SnaftDecision(
                is_safe=False,
                reason=f"SNAFT detected {len(self.violations)} violation(s): {'; '.join(self.violations)}",
                violations=list(self.violations),
                observed_syscalls=list(self.observed_syscalls),
            )

        return SnaftDecision(
            is_safe=True,
            reason=f"All {len(self.observed_syscalls)} syscalls within intent '{self.intent}' bounds",
            violations=[],
            observed_syscalls=list(self.observed_syscalls),
        )
