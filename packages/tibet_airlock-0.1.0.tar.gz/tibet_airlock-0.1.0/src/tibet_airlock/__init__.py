"""
tibet-airlock — Zero-trust sandbox with TIBET provenance.

Kernel isolation in <1ms, cryptographic proof of every execution.
Part of the TIBET ecosystem: pip install tibet[security]

Usage:
    from tibet_airlock import Airlock

    async with Airlock() as airlock:
        result = airlock.execute("code:execute", "print('hello')", agent="root_idd.aint")
        print(result.status)        # 200
        print(result.token)         # TIBET provenance token
        print(result.execution_ms)  # 0.6

    # Or use SNAFT directly for local monitoring:
    from tibet_airlock import SnaftMonitor

    monitor = SnaftMonitor("code:execute")
    monitor.log_syscall("sys_write")   # OK
    monitor.log_syscall("sys_socket")  # VIOLATION
    decision = monitor.triage()
    print(decision.is_safe)  # False
"""

__version__ = "0.1.0"

from .client import Airlock, AirlockResult
from .snaft import SnaftMonitor, SnaftDecision
from .frame import MuxFrame

__all__ = [
    "Airlock",
    "AirlockResult",
    "SnaftMonitor",
    "SnaftDecision",
    "MuxFrame",
]
