"""
Airlock client — connect to the tibet-airlock Rust binary via MUX protocol.

Usage:
    from tibet_airlock import Airlock

    async with Airlock() as airlock:
        result = await airlock.execute("code:execute", "print('hello')")
        print(result.status)   # 200
        print(result.safe)     # True
        print(result.token)    # TIBET provenance dict

    # Or synchronous:
    result = Airlock.run("code:execute", "print('hello')")
"""

from __future__ import annotations
import asyncio
import json
import socket
import time
from dataclasses import dataclass, field
from typing import Any

from .frame import MuxFrame
from .snaft import SnaftMonitor


@dataclass
class AirlockResult:
    """Result from an airlock execution."""

    status: int
    channel_id: int
    intent: str
    token: dict[str, Any]
    roundtrip_ms: float
    raw: str = ""

    @property
    def safe(self) -> bool:
        return self.status == 200

    @property
    def killed(self) -> bool:
        return self.status == 403

    @property
    def rejected(self) -> bool:
        return self.status == 400

    @property
    def violations(self) -> list[str]:
        prov = self.token.get("tibet_provenance", self.token)
        return prov.get("violations", [])


class Airlock:
    """
    Client for the tibet-airlock MUX protocol.

    The airlock binary must be running: `cargo install tibet-airlock && tibet-airlock`
    """

    def __init__(self, host: str = "127.0.0.1", port: int = 4430, agent: str = "python.aint"):
        self.host = host
        self.port = port
        self.agent = agent
        self._channel_counter = 0

    async def __aenter__(self):
        return self

    async def __aexit__(self, *exc):
        pass

    def _next_channel(self) -> int:
        self._channel_counter += 1
        return self._channel_counter

    async def execute(self, intent: str, payload: str, agent: str | None = None) -> AirlockResult:
        """Execute a payload in the airlock. Returns result with TIBET provenance."""
        frame = MuxFrame(
            channel_id=self._next_channel(),
            intent=intent,
            from_aint=agent or self.agent,
            payload=payload,
        )

        t0 = time.perf_counter_ns()

        reader, writer = await asyncio.open_connection(self.host, self.port)
        writer.write(frame.to_bytes())
        await writer.drain()

        chunks = []
        while True:
            data = await asyncio.wait_for(reader.read(8192), timeout=5.0)
            if not data:
                break
            chunks.append(data)

        writer.close()
        roundtrip_ms = (time.perf_counter_ns() - t0) / 1_000_000

        raw = b"".join(chunks).decode("utf-8")
        try:
            response = json.loads(raw)
        except json.JSONDecodeError:
            response = {"raw": raw, "status": 0}

        return AirlockResult(
            status=response.get("status", 0),
            channel_id=response.get("channel_id", frame.channel_id),
            intent=response.get("intent", intent),
            token=response,
            roundtrip_ms=roundtrip_ms,
            raw=raw,
        )

    @classmethod
    def run(cls, intent: str, payload: str, **kwargs) -> AirlockResult:
        """Synchronous convenience method."""
        airlock = cls(**kwargs)
        return asyncio.run(airlock.execute(intent, payload))

    async def check_payload(self, intent: str, payload: str) -> SnaftMonitor:
        """
        Local SNAFT check without sending to the airlock binary.
        Useful for pre-screening before execution.
        """
        monitor = SnaftMonitor(intent)
        monitor.scan_payload(payload)
        return monitor
