#!/bin/bash
set -e

# Parse optional --connection parameter
CONNECTION=""
SNOW_CONNECTION_ARG=""

while [[ $# -gt 0 ]]; do
    case $1 in
        --connection)
            CONNECTION="$2"
            SNOW_CONNECTION_ARG="--connection $2"
            shift 2
            ;;
        *)
            echo "Unknown option: $1"
            echo "Usage: $0 [--connection <connection_name>]"
            exit 1
            ;;
    esac
done

# Get the Snowflake Image Registry URL dynamically
echo "Getting Snowflake Image Registry URL..."
REGISTRY_URL=$(snow spcs image-registry url $SNOW_CONNECTION_ARG | tr -d '[:space:]')

if [ -z "$REGISTRY_URL" ]; then
    echo "Error: Failed to get Snowflake Image Registry URL"
    exit 1
fi

echo "Using registry: $REGISTRY_URL"

IMAGE_PATH="${REGISTRY_URL}/snowconvert_ai/public/images/data-migration-orchestrator:latest"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ORCHESTRATOR_DIR="${SCRIPT_DIR}/.."
REPO_ROOT="${ORCHESTRATOR_DIR}/.."

pushd "${REPO_ROOT}"
docker build -f data-migration-orchestrator/Dockerfile -t data-migration-orchestrator --platform=linux/amd64 .
docker tag data-migration-orchestrator:latest "$IMAGE_PATH"
snow spcs image-registry login $SNOW_CONNECTION_ARG
docker push --platform=linux/amd64 "$IMAGE_PATH"
popd
