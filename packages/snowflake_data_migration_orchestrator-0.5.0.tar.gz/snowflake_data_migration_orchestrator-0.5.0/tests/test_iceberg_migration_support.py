"""
Tests for Iceberg-to-Iceberg migration support.

Covers:
- Serialization/deserialization roundtrip for iceberg_config (including migrationStrategy)
- Schema validation for sourceDataStage and migrationStrategy
- Strategy auto-detection (_resolve_iceberg_strategy)
- Workflow initializer routing for catalog_link, convert_to_managed, and copy_files
"""

from __future__ import annotations

import unittest
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from data_migration_orchestrator.data_migration_cloud.config import (
    configuration_properties_keys as keys,
)
from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    DEFAULT_TARGET_TABLE_TYPE,
    ExtractionConfig,
    IcebergTargetConfig,
    PartitionSizeConfig,
    SynchronizationConfig,
    TableConfiguration,
    TableIdentifier,
)
from data_migration_orchestrator.data_migration_cloud.config.workflow_configuration_schema import (
    validate_workflow_configuration,
)
from data_migration_orchestrator.data_migration_cloud.data_migration_workflow_initializer import (
    DataMigrationWorkflowInitializer,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.table_configuration_service import (
    TableConfigurationService,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_table_config(
    *,
    target_table_type: str = DEFAULT_TARGET_TABLE_TYPE,
    iceberg_config: IcebergTargetConfig | None = None,
) -> TableConfiguration:
    return TableConfiguration(
        source=TableIdentifier(
            database_name="src_db",
            schema_name="src_schema",
            table_name="my_table",
        ),
        target=TableIdentifier(
            database_name="tgt_db",
            schema_name="tgt_schema",
            table_name="my_table",
        ),
        partition_columns=[],
        column_type_mappings={},
        column_name_mappings={},
        primary_key_columns=[],
        synchronization=SynchronizationConfig(),
        extraction=ExtractionConfig(),
        partition_size=PartitionSizeConfig(),
        where_clause_criteria=None,
        target_table_type=target_table_type,
        iceberg_config=iceberg_config,
    )


def _minimal_table_config_dict() -> dict:
    return {
        "source": {
            "databaseName": "source_db",
            "schemaName": "dbo",
            "tableName": "customers",
        },
        "target": {
            "databaseName": "target_db",
            "schemaName": "public",
            "tableName": "customers",
        },
        "columnNamesToPartitionBy": ["id"],
    }


# ---------------------------------------------------------------------------
# 1. Serialization / Deserialization roundtrip
# ---------------------------------------------------------------------------


class TestIcebergConfigSerializationRoundtrip:
    """Verify that iceberg_config survives serialization → storage → deserialization."""

    def _roundtrip(self, table_config: TableConfiguration) -> TableConfiguration:
        """Serialize via the initializer, then parse via the service."""
        serialized = DataMigrationWorkflowInitializer._serialize_target_endpoint(
            table_config
        )
        # Wrap in the same shape that _parse_table_configuration expects
        full_dict = {
            keys.SOURCE: {
                keys.DATABASE_NAME: "src_db",
                keys.SCHEMA_NAME: "src_schema",
                keys.TABLE_NAME: "my_table",
            },
            keys.TARGET: serialized,
            keys.COLUMN_NAMES_TO_PARTITION_BY: [],
            keys.COLUMN_TYPE_MAPPINGS: {},
            keys.COLUMN_NAME_MAPPINGS: {},
            keys.PRIMARY_KEY_COLUMNS: [],
            keys.SYNCHRONIZATION: {keys.STRATEGY: "none"},
            keys.EXTRACTION: {keys.STRATEGY: "regular"},
            keys.PARTITION_SIZE: "auto",
        }
        service = TableConfigurationService(warehouse_proxy=MagicMock())
        return service._parse_table_configuration(full_dict)

    def test_native_table_roundtrip(self):
        tc = _make_table_config()
        result = self._roundtrip(tc)
        assert result.target_table_type == "native"
        assert result.iceberg_config is None

    def test_snowflake_managed_iceberg_roundtrip(self):
        ic = IcebergTargetConfig(
            catalog="SNOWFLAKE",
            external_volume="my_vol",
            base_location_prefix="data/prefix",
            catalog_sync="glue_sync",
        )
        tc = _make_table_config(target_table_type="iceberg", iceberg_config=ic)
        result = self._roundtrip(tc)

        assert result.target_table_type == "iceberg"
        assert result.iceberg_config is not None
        assert result.iceberg_config.catalog == "SNOWFLAKE"
        assert result.iceberg_config.external_volume == "my_vol"
        assert result.iceberg_config.base_location_prefix == "data/prefix"
        assert result.iceberg_config.catalog_sync == "glue_sync"

    def test_external_catalog_iceberg_roundtrip(self):
        ic = IcebergTargetConfig(
            catalog="my_glue_integration",
            external_volume="ext_vol",
            catalog_table_name="glue_db.orders",
        )
        tc = _make_table_config(target_table_type="iceberg", iceberg_config=ic)
        result = self._roundtrip(tc)

        assert result.iceberg_config is not None
        assert result.iceberg_config.catalog == "my_glue_integration"
        assert result.iceberg_config.catalog_table_name == "glue_db.orders"

    def test_source_data_stage_roundtrip(self):
        ic = IcebergTargetConfig(
            catalog="SNOWFLAKE",
            external_volume="my_vol",
            source_data_stage="@TGT_DB.PUBLIC.ICEBERG_SOURCE_STAGE",
        )
        tc = _make_table_config(target_table_type="iceberg", iceberg_config=ic)
        result = self._roundtrip(tc)

        assert result.iceberg_config is not None
        assert (
            result.iceberg_config.source_data_stage
            == "@TGT_DB.PUBLIC.ICEBERG_SOURCE_STAGE"
        )

    def test_native_does_not_serialize_iceberg_fields(self):
        tc = _make_table_config()
        serialized = DataMigrationWorkflowInitializer._serialize_target_endpoint(tc)
        assert keys.TABLE_TYPE not in serialized
        assert keys.ICEBERG_CONFIG not in serialized


# ---------------------------------------------------------------------------
# 2. Schema validation for sourceDataStage
# ---------------------------------------------------------------------------


class TestSourceDataStageSchemaValidation:
    """Validate sourceDataStage field in workflow configuration schema."""

    def test_valid_source_data_stage(self):
        table = _minimal_table_config_dict()
        table["target"]["tableType"] = "iceberg"
        table["target"]["icebergConfig"] = {
            "catalog": "SNOWFLAKE",
            "externalVolume": "vol",
            "sourceDataStage": "@TGT_DB.PUBLIC.ICE_STAGE",
        }
        config = {"tables": [table]}

        result = validate_workflow_configuration(config)
        iceberg = result.tables[0].target.iceberg_config
        assert iceberg.source_data_stage == "@TGT_DB.PUBLIC.ICE_STAGE"

    def test_source_data_stage_defaults_to_none(self):
        table = _minimal_table_config_dict()
        table["target"]["tableType"] = "iceberg"
        table["target"]["icebergConfig"] = {
            "catalog": "SNOWFLAKE",
            "externalVolume": "vol",
        }
        config = {"tables": [table]}

        result = validate_workflow_configuration(config)
        iceberg = result.tables[0].target.iceberg_config
        assert iceberg.source_data_stage is None

    def test_source_data_stage_in_default_config(self):
        config = {
            "defaultTableConfiguration": {
                "source": {"databaseName": "db", "schemaName": "s"},
                "target": {
                    "databaseName": "tgt",
                    "schemaName": "public",
                    "tableType": "iceberg",
                    "icebergConfig": {
                        "catalog": "SNOWFLAKE",
                        "externalVolume": "vol",
                        "sourceDataStage": "@STAGE",
                    },
                },
            },
            "tables": [
                {
                    "source": {"tableName": "t"},
                    "target": {"tableName": "t"},
                    "columnNamesToPartitionBy": ["id"],
                },
            ],
        }

        result = validate_workflow_configuration(config)
        iceberg = result.default_table_configuration.target.iceberg_config
        assert iceberg.source_data_stage == "@STAGE"


# ---------------------------------------------------------------------------
# 3. Workflow initializer — Iceberg task routing
# ---------------------------------------------------------------------------


class TestIcebergTaskRouting(unittest.IsolatedAsyncioTestCase):
    """Verify _create_tasks_for_table routes to Iceberg task chain."""

    def _make_initializer(
        self,
    ) -> tuple[DataMigrationWorkflowInitializer, AsyncMock, AsyncMock]:
        task_queue = AsyncMock()
        task_queue.push_task = AsyncMock(return_value=42)
        warehouse = AsyncMock()
        warehouse.execute_sync_query = AsyncMock(return_value=[{"ID": 99}])
        warehouse.execute_snowflake_query_and_push_task = AsyncMock(return_value=42)
        initializer = DataMigrationWorkflowInitializer(
            task_queue=task_queue,
            warehouse_proxy=warehouse,
        )
        return initializer, task_queue, warehouse

    async def test_approach_a_creates_single_ddl_task(self):
        """External catalog: a single DDL task via warehouse, no schema extraction."""
        initializer, task_queue, warehouse = self._make_initializer()
        ic = IcebergTargetConfig(
            catalog="my_glue_integration",
            external_volume="glue_vol",
            catalog_table_name="glue_db.orders",
        )
        tc = _make_table_config(target_table_type="iceberg", iceberg_config=ic)

        await initializer._create_iceberg_table_tasks(
            workflow_id=1,
            table_config=tc,
            platform=MagicMock(
                name="redshift",
                build_normalized_table_name=MagicMock(
                    side_effect=lambda t: f"{t.database_name}.{t.schema_name}.{t.table_name}"
                ),
            ),
            target_cloud_type="snowflake:stage",
            table_metadata_id=99,
        )

        # DDL executed via warehouse, not pushed to task queue
        task_queue.push_task.assert_not_called()
        warehouse.execute_snowflake_query_and_push_task.assert_called_once()
        call_kwargs = warehouse.execute_snowflake_query_and_push_task.call_args
        ddl = call_kwargs[0][1]  # second positional arg is the query
        self.assertIn("CREATE OR REPLACE ICEBERG TABLE", ddl)
        self.assertIn("CATALOG = 'my_glue_integration'", ddl)
        self.assertIn("CATALOG_TABLE_NAME = 'glue_db.orders'", ddl)

    async def test_approach_b_with_source_stage_creates_single_load_task(self):
        """Snowflake-managed + sourceDataStage: single unblocked load task, no DEA."""
        initializer, task_queue, warehouse = self._make_initializer()
        ic = IcebergTargetConfig(
            catalog="SNOWFLAKE",
            external_volume="my_vol",
            base_location_prefix="data/tables",
            source_data_stage="@TGT.PUBLIC.ICE_STAGE",
        )
        tc = _make_table_config(target_table_type="iceberg", iceberg_config=ic)

        mock_platform = MagicMock(
            name="redshift",
            build_normalized_table_name=MagicMock(
                side_effect=lambda t: f"{t.database_name}.{t.schema_name}.{t.table_name}"
            ),
        )

        await initializer._create_iceberg_table_tasks(
            workflow_id=1,
            table_config=tc,
            platform=mock_platform,
            target_cloud_type="snowflake:stage",
            table_metadata_id=99,
        )

        # Single unblocked load task -- no schema extraction via DEA
        self.assertEqual(task_queue.push_task.call_count, 1)
        pushed_task = task_queue.push_task.call_args[0][0]
        self.assertFalse(pushed_task.is_blocked)

    async def test_approach_b_without_source_stage_creates_schema_and_load(self):
        """Snowflake-managed without sourceDataStage: schema extraction -> load."""
        initializer, task_queue, warehouse = self._make_initializer()
        ic = IcebergTargetConfig(
            catalog="SNOWFLAKE",
            external_volume="my_vol",
            base_location_prefix="data/tables",
        )
        tc = _make_table_config(target_table_type="iceberg", iceberg_config=ic)

        mock_platform = MagicMock(
            name="redshift",
            build_normalized_table_name=MagicMock(
                side_effect=lambda t: f"{t.database_name}.{t.schema_name}.{t.table_name}"
            ),
        )
        mock_platform.query_builder.build_use_database_command.return_value = (
            "USE src_db"
        )
        mock_platform.query_builder.build_external_table_schema_query.return_value = (
            "SELECT * FROM SVV_EXTERNAL_COLUMNS WHERE tablename='my_table'"
        )

        await initializer._create_iceberg_table_tasks(
            workflow_id=1,
            table_config=tc,
            platform=mock_platform,
            target_cloud_type="snowflake:stage",
            table_metadata_id=99,
        )

        # Two tasks: load (blocked) + schema extraction (with successor)
        self.assertEqual(task_queue.push_task.call_count, 2)

    async def test_routing_dispatches_iceberg_over_regular(self):
        """When target_table_type=='iceberg', _create_iceberg_table_tasks is called."""
        initializer, _, _ = self._make_initializer()
        ic = IcebergTargetConfig(
            catalog="my_glue_integration",
            catalog_table_name="t",
        )
        tc = _make_table_config(target_table_type="iceberg", iceberg_config=ic)

        with (
            patch.object(
                initializer, "_create_iceberg_table_tasks", new_callable=AsyncMock
            ) as mock_iceberg,
            patch.object(
                initializer,
                "_bulk_insert_table_metadata",
                new_callable=AsyncMock,
            ) as mock_bulk,
            patch.object(
                initializer,
                "_batch_create_tasks_with_new_partitions",
                new_callable=AsyncMock,
            ),
            patch(
                "data_migration_orchestrator.data_migration_cloud.data_migration_workflow_initializer.PlatformRegistry"
            ) as mock_registry,
        ):
            mock_platform = MagicMock()
            mock_registry.create_by_name_or_alias.return_value = mock_platform
            mock_platform.build_normalized_table_name.return_value = (
                "src_db.src_schema.my_table"
            )
            mock_bulk.return_value = {"src_db.src_schema.my_table": 77}

            await initializer._create_tasks_for_table(
                workflow_id=1,
                table_config=tc,
                source_platform="redshift",
                target_cloud_type="snowflake:stage",
            )

            mock_iceberg.assert_called_once()
            self.assertEqual(mock_iceberg.call_args.kwargs.get("table_metadata_id"), 77)

    async def test_routing_regular_for_native(self):
        """When target_table_type=='native', normal flow is used."""
        initializer, _, _ = self._make_initializer()
        tc = _make_table_config()  # native, no iceberg

        with (
            patch.object(
                initializer, "_create_iceberg_table_tasks", new_callable=AsyncMock
            ) as mock_iceberg,
            patch.object(
                initializer,
                "_bulk_insert_table_metadata",
                new_callable=AsyncMock,
            ) as mock_bulk,
            patch.object(
                initializer,
                "_batch_create_tasks_with_new_partitions",
                new_callable=AsyncMock,
            ) as mock_regular,
            patch.object(
                initializer.partition_reuse_service,
                "find_existing_table_metadata",
                new_callable=AsyncMock,
                return_value=None,
            ),
            patch(
                "data_migration_orchestrator.data_migration_cloud.data_migration_workflow_initializer.PlatformRegistry"
            ) as mock_registry,
        ):
            mock_platform = MagicMock()
            mock_registry.create_by_name_or_alias.return_value = mock_platform
            mock_platform.build_normalized_table_name.return_value = (
                "src_db.src_schema.my_table"
            )
            mock_bulk.return_value = {"src_db.src_schema.my_table": 3}

            await initializer._create_tasks_for_table(
                workflow_id=1,
                table_config=tc,
                source_platform="redshift",
                target_cloud_type="snowflake:stage",
            )

            mock_iceberg.assert_not_called()
            mock_regular.assert_awaited_once()

    async def test_convert_to_managed_creates_two_chained_ddl_tasks(self):
        """convert_to_managed: ALTER pushed to queue (blocked) + CREATE via warehouse."""
        initializer, task_queue, warehouse = self._make_initializer()
        ic = IcebergTargetConfig(
            catalog="my_glue_integration",
            external_volume="glue_vol",
            catalog_table_name="glue_db.orders",
            migration_strategy="convert_to_managed",
        )
        tc = _make_table_config(target_table_type="iceberg", iceberg_config=ic)

        await initializer._create_iceberg_table_tasks(
            workflow_id=1,
            table_config=tc,
            platform=MagicMock(
                name="redshift",
                build_normalized_table_name=MagicMock(
                    side_effect=lambda t: f"{t.database_name}.{t.schema_name}.{t.table_name}"
                ),
            ),
            target_cloud_type="snowflake:stage",
            table_metadata_id=99,
        )

        # ALTER task pushed to queue (blocked), CREATE DDL fired via warehouse
        self.assertEqual(task_queue.push_task.call_count, 1)
        alter_task = task_queue.push_task.call_args_list[0][0][0]
        self.assertIn("CONVERT TO MANAGED", alter_task.payload.query)
        self.assertTrue(alter_task.is_blocked)

        warehouse.execute_snowflake_query_and_push_task.assert_called_once()
        create_call = warehouse.execute_snowflake_query_and_push_task.call_args
        create_ddl = create_call[0][1]
        self.assertIn("CREATE OR REPLACE ICEBERG TABLE", create_ddl)
        self.assertIn("CATALOG = 'my_glue_integration'", create_ddl)

    async def test_explicit_copy_files_with_source_stage(self):
        """copy_files with sourceDataStage: single unblocked load task."""
        initializer, task_queue, warehouse = self._make_initializer()
        ic = IcebergTargetConfig(
            catalog="SNOWFLAKE",
            external_volume="vol",
            source_data_stage="@DB.PUBLIC.STAGE",
            migration_strategy="copy_files",
        )
        tc = _make_table_config(target_table_type="iceberg", iceberg_config=ic)

        await initializer._create_iceberg_table_tasks(
            workflow_id=1,
            table_config=tc,
            platform=MagicMock(
                name="redshift",
                build_normalized_table_name=MagicMock(
                    side_effect=lambda t: f"{t.database_name}.{t.schema_name}.{t.table_name}"
                ),
            ),
            target_cloud_type="snowflake:stage",
            table_metadata_id=99,
        )

        self.assertEqual(task_queue.push_task.call_count, 1)
        self.assertFalse(task_queue.push_task.call_args[0][0].is_blocked)


# ---------------------------------------------------------------------------
# 4. Strategy auto-detection
# ---------------------------------------------------------------------------


class TestIcebergStrategyAutoDetection:
    """Verify _resolve_iceberg_strategy auto-detection logic."""

    def test_external_catalog_auto_detects_catalog_link(self):
        ic = IcebergTargetConfig(catalog="my_glue_integration")
        assert (
            DataMigrationWorkflowInitializer._resolve_iceberg_strategy(ic)
            == "catalog_link"
        )

    def test_snowflake_with_source_stage_auto_detects_copy_files(self):
        ic = IcebergTargetConfig(
            catalog="SNOWFLAKE",
            source_data_stage="@DB.PUBLIC.STAGE",
        )
        assert (
            DataMigrationWorkflowInitializer._resolve_iceberg_strategy(ic)
            == "copy_files"
        )

    def test_snowflake_without_source_stage_auto_detects_copy_files(self):
        ic = IcebergTargetConfig(catalog="SNOWFLAKE")
        assert (
            DataMigrationWorkflowInitializer._resolve_iceberg_strategy(ic)
            == "copy_files"
        )

    def test_explicit_strategy_overrides_auto_detect(self):
        ic = IcebergTargetConfig(
            catalog="my_glue_integration",
            migration_strategy="convert_to_managed",
        )
        assert (
            DataMigrationWorkflowInitializer._resolve_iceberg_strategy(ic)
            == "convert_to_managed"
        )

    def test_explicit_copy_files_on_external_catalog(self):
        ic = IcebergTargetConfig(
            catalog="my_glue_integration",
            migration_strategy="copy_files",
        )
        assert (
            DataMigrationWorkflowInitializer._resolve_iceberg_strategy(ic)
            == "copy_files"
        )


# ---------------------------------------------------------------------------
# 5. migration_strategy serialization roundtrip and schema validation
# ---------------------------------------------------------------------------


class TestMigrationStrategyRoundtrip:
    """Verify migrationStrategy survives serialization -> deserialization."""

    def test_migration_strategy_roundtrip(self):
        ic = IcebergTargetConfig(
            catalog="SNOWFLAKE",
            external_volume="vol",
            migration_strategy="convert_to_managed",
        )
        tc = _make_table_config(target_table_type="iceberg", iceberg_config=ic)

        serialized = DataMigrationWorkflowInitializer._serialize_target_endpoint(tc)
        assert (
            serialized[keys.ICEBERG_CONFIG][keys.MIGRATION_STRATEGY]
            == "convert_to_managed"
        )

        full_dict = {
            keys.SOURCE: {
                keys.DATABASE_NAME: "src_db",
                keys.SCHEMA_NAME: "src_schema",
                keys.TABLE_NAME: "my_table",
            },
            keys.TARGET: serialized,
            keys.COLUMN_NAMES_TO_PARTITION_BY: [],
            keys.COLUMN_TYPE_MAPPINGS: {},
            keys.COLUMN_NAME_MAPPINGS: {},
            keys.PRIMARY_KEY_COLUMNS: [],
            keys.SYNCHRONIZATION: {keys.STRATEGY: "none"},
            keys.EXTRACTION: {keys.STRATEGY: "regular"},
            keys.PARTITION_SIZE: "auto",
        }
        service = TableConfigurationService(warehouse_proxy=MagicMock())
        result = service._parse_table_configuration(full_dict)
        assert result.iceberg_config.migration_strategy == "convert_to_managed"

    def test_none_strategy_not_serialized(self):
        ic = IcebergTargetConfig(catalog="SNOWFLAKE", external_volume="vol")
        tc = _make_table_config(target_table_type="iceberg", iceberg_config=ic)
        serialized = DataMigrationWorkflowInitializer._serialize_target_endpoint(tc)
        assert keys.MIGRATION_STRATEGY not in serialized[keys.ICEBERG_CONFIG]


class TestMigrationStrategySchemaValidation:
    """Validate migrationStrategy field in workflow configuration schema."""

    def test_valid_migration_strategy_accepted(self):
        table = _minimal_table_config_dict()
        table["target"]["tableType"] = "iceberg"
        table["target"]["icebergConfig"] = {
            "catalog": "SNOWFLAKE",
            "externalVolume": "vol",
            "migrationStrategy": "convert_to_managed",
        }
        config = {"tables": [table]}
        result = validate_workflow_configuration(config)
        iceberg = result.tables[0].target.iceberg_config
        assert iceberg.migration_strategy == "convert_to_managed"

    def test_invalid_migration_strategy_rejected(self):
        table = _minimal_table_config_dict()
        table["target"]["tableType"] = "iceberg"
        table["target"]["icebergConfig"] = {
            "catalog": "SNOWFLAKE",
            "externalVolume": "vol",
            "migrationStrategy": "invalid_strategy",
        }
        config = {"tables": [table]}
        with pytest.raises(Exception, match="migrationStrategy"):
            validate_workflow_configuration(config)

    def test_migration_strategy_defaults_to_none(self):
        table = _minimal_table_config_dict()
        table["target"]["tableType"] = "iceberg"
        table["target"]["icebergConfig"] = {
            "catalog": "SNOWFLAKE",
            "externalVolume": "vol",
        }
        config = {"tables": [table]}
        result = validate_workflow_configuration(config)
        iceberg = result.tables[0].target.iceberg_config
        assert iceberg.migration_strategy is None
