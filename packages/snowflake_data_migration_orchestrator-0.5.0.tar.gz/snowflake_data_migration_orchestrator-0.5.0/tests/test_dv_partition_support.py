"""
Tests for DV multi-partition support.

Covers:
- Config chain: partition_column in schema, dataclass, parser
- Partition creation logic in GenerateValidationQueriesHandler
- Condition building in EvaluateLevelResultHandler._build_scoped_where
- DEAPayloadFactory partition WHERE clause passthrough
"""

from __future__ import annotations

import asyncio
from unittest.mock import AsyncMock


from data_migration_orchestrator.data_validation_cloud.config.configuration_properties_keys import (
    PARTITION_COLUMN,
)
from data_migration_orchestrator.data_validation_cloud.config.validation_configuration_parser import (
    ValidationConfigurationParser,
)
from data_migration_orchestrator.data_validation_cloud.config.validation_table_configuration import (
    ValidationTableConfiguration,
)
from data_migration_orchestrator.data_validation_cloud.config.workflow_configuration_schema import (
    validate_data_validation_workflow_configuration,
)
from data_migration_orchestrator.data_validation_cloud.tasks.handlers.evaluate_level_result_handler import (
    EvaluateLevelResultHandler,
)
from data_migration_orchestrator.data_validation_cloud.tasks.handlers.generate_validation_queries_handler import (
    GenerateValidationQueriesHandler,
)
from data_migration_orchestrator.data_validation_cloud.tasks.models.dea_payload_factory import (
    DEAPayloadFactory,
)
from data_migration_orchestrator.data_validation_cloud.tasks.models.task_payload import (
    DataValidationTaskPayload,
)


# =========================================================================
# Config chain tests
# =========================================================================


class TestPartitionColumnConfig:
    """Verify partition_column flows through the entire config chain."""

    def test_schema_accepts_partition_column(self):
        config = {
            "source_platform": "redshift",
            "tables": [
                {
                    "fully_qualified_name": "db.schema.table",
                    "partition_column": "id",
                }
            ],
        }
        schema = validate_data_validation_workflow_configuration(config)
        assert schema.tables[0].partition_column == "id"

    def test_schema_defaults_partition_column_to_none(self):
        config = {
            "source_platform": "redshift",
            "tables": [{"fully_qualified_name": "db.schema.table"}],
        }
        schema = validate_data_validation_workflow_configuration(config)
        assert schema.tables[0].partition_column is None

    def test_dataclass_stores_partition_column(self):
        vtc = ValidationTableConfiguration(
            fully_qualified_name="db.schema.table",
            partition_column="created_at",
        )
        assert vtc.partition_column == "created_at"

    def test_to_sdv_dict_includes_partition_column(self):
        vtc = ValidationTableConfiguration(
            fully_qualified_name="db.schema.table",
            partition_column="id",
        )
        d = vtc.to_sdv_dict()
        assert d[PARTITION_COLUMN] == "id"

    def test_to_sdv_dict_omits_none_partition_column(self):
        vtc = ValidationTableConfiguration(
            fully_qualified_name="db.schema.table",
        )
        d = vtc.to_sdv_dict()
        assert PARTITION_COLUMN not in d

    def test_parser_passes_partition_column(self):
        raw = {
            "source_platform": "redshift",
            "tables": [
                {
                    "fully_qualified_name": "db.schema.table",
                    "partition_column": "id",
                }
            ],
        }
        parser = ValidationConfigurationParser(raw)
        tables = parser.parse_tables()
        assert len(tables) == 1
        assert tables[0].partition_column == "id"

    def test_parser_defaults_partition_column_to_none(self):
        raw = {
            "source_platform": "redshift",
            "tables": [{"fully_qualified_name": "db.schema.table"}],
        }
        parser = ValidationConfigurationParser(raw)
        tables = parser.parse_tables()
        assert tables[0].partition_column is None


# =========================================================================
# Partition creation tests (GenerateValidationQueriesHandler)
# =========================================================================


class TestCreatePartitionMetadata:
    """Tests for _create_partition_metadata in the generate handler."""

    def _make_handler(self, query_results: dict[str, list] | None = None):
        """Build a handler with a mocked warehouse proxy."""
        task_queue = AsyncMock()
        warehouse = AsyncMock()

        call_index = {"i": 0}
        results_list: list[list] = []
        if query_results:
            results_list = list(query_results.values())

        async def execute_side_effect(query: str):
            idx = call_index["i"]
            call_index["i"] += 1
            if idx < len(results_list):
                return results_list[idx]
            return []

        warehouse.execute_sync_query = AsyncMock(side_effect=execute_side_effect)
        return GenerateValidationQueriesHandler(task_queue, warehouse), warehouse

    def test_no_partition_column_inserts_single(self):
        handler, warehouse = self._make_handler()
        asyncio.run(
            handler._create_partition_metadata(
                table_metadata_id=1,
                source_identifier="db.schema.t",
                table_config={},
            )
        )
        warehouse.execute_sync_query.assert_called_once()
        call_sql = warehouse.execute_sync_query.call_args[0][0]
        assert "INSERT_PARTITION_METADATA" in call_sql
        assert "NULL, NULL, NULL" in call_sql

    def test_empty_table_inserts_single(self):
        handler, warehouse = self._make_handler()
        warehouse.execute_sync_query = AsyncMock(
            side_effect=[
                [{"ROW_COUNT": 0}],  # COUNT(*) result
                [{"INSERT_PARTITION_METADATA": 1}],  # single partition insert
            ]
        )
        asyncio.run(
            handler._create_partition_metadata(
                table_metadata_id=1,
                source_identifier="db.schema.t",
                table_config={"partition_column": "id"},
            )
        )
        assert warehouse.execute_sync_query.call_count == 2

    def test_small_table_inserts_single(self):
        handler, warehouse = self._make_handler()
        warehouse.execute_sync_query = AsyncMock(
            side_effect=[
                [{"ROW_COUNT": 1000}],  # small table
                [{"INSERT_PARTITION_METADATA": 1}],  # single partition insert
            ]
        )
        asyncio.run(
            handler._create_partition_metadata(
                table_metadata_id=1,
                source_identifier="db.schema.t",
                table_config={"partition_column": "id"},
            )
        )
        assert warehouse.execute_sync_query.call_count == 2
        last_call = warehouse.execute_sync_query.call_args[0][0]
        assert "INSERT_PARTITION_METADATA" in last_call
        assert "NULL, NULL, NULL" in last_call

    def test_large_table_creates_multiple_partitions(self):
        handler, warehouse = self._make_handler()

        ntile_results = [
            {
                "PARTITION_ID": 1,
                "MIN_VALUE_IN_PARTITION": 1,
                "MAX_VALUE_IN_PARTITION": 500000,
                "N_ROWS": 500000,
            },
            {
                "PARTITION_ID": 2,
                "MIN_VALUE_IN_PARTITION": 500001,
                "MAX_VALUE_IN_PARTITION": 1000000,
                "N_ROWS": 500000,
            },
        ]
        warehouse.execute_sync_query = AsyncMock(
            side_effect=[
                [{"ROW_COUNT": 1_000_000}],  # COUNT(*)
                ntile_results,  # NTILE query
                [{"INSERT_PARTITION_METADATA": 1}],  # insert p1
                [{"INSERT_PARTITION_METADATA": 2}],  # insert p2
            ]
        )
        asyncio.run(
            handler._create_partition_metadata(
                table_metadata_id=1,
                source_identifier="db.schema.t",
                table_config={"partition_column": "id"},
            )
        )
        # COUNT + NTILE + 2 inserts = 4 calls
        assert warehouse.execute_sync_query.call_count == 4

        # Verify NTILE query was run without sampling (under threshold)
        ntile_call = warehouse.execute_sync_query.call_args_list[1][0][0]
        assert "NTILE" in ntile_call
        assert "SELECT id," in ntile_call
        assert "SAMPLE" not in ntile_call

    def test_very_large_table_uses_sampling(self):
        handler, warehouse = self._make_handler()

        ntile_results = [
            {
                "PARTITION_ID": i,
                "MIN_VALUE_IN_PARTITION": (i - 1) * 500000 + 1,
                "MAX_VALUE_IN_PARTITION": i * 500000,
                "N_ROWS": 500000,
            }
            for i in range(1, 101)
        ]
        side_effects = [
            [{"ROW_COUNT": 500_000_000}],  # COUNT(*) — above sampling threshold
            ntile_results,  # NTILE query
        ] + [[{"INSERT_PARTITION_METADATA": i}] for i in range(1, 101)]

        warehouse.execute_sync_query = AsyncMock(side_effect=side_effects)
        asyncio.run(
            handler._create_partition_metadata(
                table_metadata_id=1,
                source_identifier="db.schema.t",
                table_config={
                    "partition_column": "id",
                    "target_database": "DB",
                    "target_schema": "SCH",
                    "target_name": "T",
                },
            )
        )

        ntile_call = warehouse.execute_sync_query.call_args_list[1][0][0]
        assert "NTILE" in ntile_call
        assert "SAMPLE BERNOULLI" in ntile_call

    def test_build_query_no_sampling_below_threshold(self):
        query = GenerateValidationQueriesHandler._build_partition_boundary_query(
            tgt_fqn="DB.SCH.T", col_sql="ID", num_partitions=10, row_count=1_000_000
        )
        assert "NTILE(10)" in query
        assert "FROM DB.SCH.T" in query
        assert "SAMPLE" not in query

    def test_build_query_sampling_above_threshold(self):
        query = GenerateValidationQueriesHandler._build_partition_boundary_query(
            tgt_fqn="DB.SCH.T",
            col_sql="ID",
            num_partitions=100,
            row_count=500_000_000,
        )
        assert "NTILE(100)" in query
        assert "SAMPLE BERNOULLI" in query
        assert "FROM sampled" in query
        assert "FROM DB.SCH.T SAMPLE" in query

    def test_build_query_sampling_percentage_calculation(self):
        query = GenerateValidationQueriesHandler._build_partition_boundary_query(
            tgt_fqn="DB.SCH.T",
            col_sql="ID",
            num_partitions=100,
            row_count=2_000_000_000,
        )
        # 20M / 2B * 100 = 1.0%
        assert "1.000000" in query

    def test_format_as_variant_none(self):
        assert GenerateValidationQueriesHandler._format_as_variant(None) == "NULL"

    def test_format_as_variant_int(self):
        assert GenerateValidationQueriesHandler._format_as_variant(42) == "42::VARIANT"

    def test_format_as_variant_float(self):
        assert (
            GenerateValidationQueriesHandler._format_as_variant(3.14) == "3.14::VARIANT"
        )

    def test_format_as_variant_string(self):
        result = GenerateValidationQueriesHandler._format_as_variant("hello")
        assert result == "'hello'::VARIANT"

    def test_format_as_variant_numeric_string(self):
        assert (
            GenerateValidationQueriesHandler._format_as_variant("42") == "42::VARIANT"
        )

    def test_format_as_variant_bool(self):
        assert (
            GenerateValidationQueriesHandler._format_as_variant(True) == "TRUE::VARIANT"
        )
        assert (
            GenerateValidationQueriesHandler._format_as_variant(False)
            == "FALSE::VARIANT"
        )

    def test_format_as_variant_escapes_quotes(self):
        result = GenerateValidationQueriesHandler._format_as_variant("it's")
        assert result == "'it''s'::VARIANT"


# =========================================================================
# Condition building tests (EvaluateLevelResultHandler)
# =========================================================================


class TestBuildScopedWhere:
    """Tests for _build_scoped_where condition building."""

    def test_no_partition_column_returns_user_where(self):
        result = EvaluateLevelResultHandler._build_scoped_where(
            user_where="status = 'active'",
            partition_column=None,
            min_value=100,
            max_value=200,
            source_platform="redshift",
            target_side=True,
        )
        assert result == "status = 'active'"

    def test_null_bounds_returns_user_where(self):
        result = EvaluateLevelResultHandler._build_scoped_where(
            user_where="status = 'active'",
            partition_column="id",
            min_value=None,
            max_value=None,
            source_platform="redshift",
            target_side=True,
        )
        assert result == "status = 'active'"

    def test_target_side_uses_snowflake_condition(self):
        result = EvaluateLevelResultHandler._build_scoped_where(
            user_where="",
            partition_column="id",
            min_value=100,
            max_value=200,
            source_platform="redshift",
            target_side=True,
        )
        assert "id >= 100" in result
        assert "id <= 200" in result

    def test_source_side_uses_platform_registry(self):
        result = EvaluateLevelResultHandler._build_scoped_where(
            user_where="",
            partition_column="id",
            min_value=100,
            max_value=200,
            source_platform="redshift",
            target_side=False,
        )
        assert "id" in result
        assert ">=" in result

    def test_combines_user_where_with_partition(self):
        result = EvaluateLevelResultHandler._build_scoped_where(
            user_where="status = 'active'",
            partition_column="id",
            min_value=100,
            max_value=200,
            source_platform="redshift",
            target_side=True,
        )
        assert "(status = 'active') AND" in result
        assert "id >= 100" in result

    def test_empty_user_where_returns_only_partition(self):
        result = EvaluateLevelResultHandler._build_scoped_where(
            user_where="",
            partition_column="id",
            min_value=100,
            max_value=200,
            source_platform="redshift",
            target_side=True,
        )
        assert "status" not in result
        assert "id >= 100" in result

    def test_only_min_value_target_side(self):
        result = EvaluateLevelResultHandler._build_scoped_where(
            user_where="",
            partition_column="id",
            min_value=100,
            max_value=None,
            source_platform="redshift",
            target_side=True,
        )
        assert "id > 100" in result

    def test_only_max_value_target_side(self):
        result = EvaluateLevelResultHandler._build_scoped_where(
            user_where="",
            partition_column="id",
            min_value=None,
            max_value=200,
            source_platform="redshift",
            target_side=True,
        )
        assert "id < 200" in result

    def test_unknown_source_platform_falls_back_to_snowflake(self):
        result = EvaluateLevelResultHandler._build_scoped_where(
            user_where="",
            partition_column="id",
            min_value=100,
            max_value=200,
            source_platform="unknown_db",
            target_side=False,
        )
        assert "id >= 100" in result


# =========================================================================
# DEA Payload tests
# =========================================================================


class TestDEAPayloadWhereClause:
    """Tests for where clause fields on DataValidationTaskPayload and factory."""

    def test_payload_has_where_clause_fields(self):
        payload = DataValidationTaskPayload(
            source_query="SELECT 1",
            target_query="SELECT 1",
            validation_type="row",
            source_platform="redshift",
            target_type="snowflake:stage",
            target_id="@stage/1/1/row",
            table_name="db.schema.t",
            table_metadata_id=1,
            workflow_id=1,
            partition_number=None,
            database="",
            schema="",
            source_where_clause="id >= 100 AND id <= 200",
            target_where_clause="id >= 100 AND id <= 200",
        )
        assert payload.source_where_clause == "id >= 100 AND id <= 200"
        assert payload.target_where_clause == "id >= 100 AND id <= 200"

    def test_payload_defaults_where_clause_to_none(self):
        payload = DataValidationTaskPayload(
            source_query="",
            target_query="",
            validation_type="row",
            source_platform="redshift",
            target_type="snowflake:stage",
            target_id="@stage/1/1/row",
            table_name="t",
            table_metadata_id=1,
            workflow_id=1,
            partition_number=None,
            database="",
            schema="",
        )
        assert payload.source_where_clause is None
        assert payload.target_where_clause is None

    def test_factory_row_payload_passes_where_clauses(self):
        factory = DEAPayloadFactory(
            workflow_id=1,
            table_metadata_id=1,
            source_identifier="db.schema.t",
            source_platform="redshift",
        )
        payload = factory.row_payload(
            partition_number=1,
            source_where_clause="id >= 100",
            target_where_clause="id >= 100",
        )
        assert payload.source_where_clause == "id >= 100"
        assert payload.target_where_clause == "id >= 100"

    def test_factory_row_payload_defaults_where_to_none(self):
        factory = DEAPayloadFactory(
            workflow_id=1,
            table_metadata_id=1,
            source_identifier="db.schema.t",
            source_platform="redshift",
        )
        payload = factory.row_payload()
        assert payload.source_where_clause is None
        assert payload.target_where_clause is None


# =========================================================================
# L2 metrics query WHERE clause passthrough tests
# =========================================================================


class TestMetricsQueryWhereClause:
    """Verify build_metrics_queries and _build_table_context propagate WHERE clauses."""

    def test_build_table_context_sets_where_clause(self):
        from data_migration_orchestrator.data_validation_cloud.query.sdv_query_helper import (
            _build_table_context,
        )
        from snowflake.snowflake_data_validation.public import Origin, Platform

        ctx = _build_table_context(
            platform=Platform.SNOWFLAKE,
            origin=Origin.TARGET,
            database_name="db",
            schema_name="schema",
            table_name="t",
            where_clause="id >= 100 AND id <= 200",
        )
        assert ctx.has_where_clause is True
        assert ctx.where_clause == "id >= 100 AND id <= 200"

    def test_build_table_context_no_where_clause(self):
        from data_migration_orchestrator.data_validation_cloud.query.sdv_query_helper import (
            _build_table_context,
        )
        from snowflake.snowflake_data_validation.public import Origin, Platform

        ctx = _build_table_context(
            platform=Platform.SNOWFLAKE,
            origin=Origin.TARGET,
            database_name="db",
            schema_name="schema",
            table_name="t",
        )
        assert ctx.has_where_clause is False
        assert ctx.where_clause == ""

    def test_build_table_context_empty_string_where(self):
        from data_migration_orchestrator.data_validation_cloud.query.sdv_query_helper import (
            _build_table_context,
        )
        from snowflake.snowflake_data_validation.public import Origin, Platform

        ctx = _build_table_context(
            platform=Platform.SNOWFLAKE,
            origin=Origin.TARGET,
            database_name="db",
            schema_name="schema",
            table_name="t",
            where_clause="",
        )
        assert ctx.has_where_clause is False
        assert ctx.where_clause == ""

    def test_build_table_context_two_part_name_no_leading_dot(self):
        """Teradata-style db.table is parsed as ('', db, table); FQN must not start with '.'."""
        from data_migration_orchestrator.data_validation_cloud.query.sdv_query_helper import (
            _build_table_context,
            build_schema_queries,
        )
        from snowflake.snowflake_data_validation.public import Origin, Platform

        ctx = _build_table_context(
            platform=Platform.TERADATA,
            origin=Origin.SOURCE,
            database_name="",
            schema_name="tpcds",
            table_name="catalog_sales",
        )
        assert ctx.fully_qualified_name == "tpcds.catalog_sales"
        assert not ctx.fully_qualified_name.startswith(".")

        source_sql, _ = build_schema_queries(
            source_platform_str="teradata",
            source_db="",
            source_schema="tpcds",
            source_table="catalog_sales",
            target_db="TPCDS_BENCHMARK",
            target_schema="PUBLIC",
            target_table="CATALOG_SALES",
        )
        assert "FROM tpcds.catalog_sales" in source_sql.replace("\n", " ")
        assert "FROM .tpcds" not in source_sql
