import json
import unittest
from unittest.mock import AsyncMock, MagicMock, patch

from snowflake.connector import ProgrammingError
from snowflake.connector.constants import QueryStatus

from data_migration_orchestrator.cloud_core.stored_procedure_calls import (
    pull_tasks_call_template,
)
from data_migration_orchestrator.cloud_core.tasks.constants.task_columns import (
    ID,
    NAME,
    PAYLOAD,
    PRIORITY,
    SCOPE,
    STATUS,
)
from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.snowflake_query_task import (
    SnowflakeQueryTaskPayload,
)
from data_migration_orchestrator.cloud_core.tasks.task import Task
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload import (
    DataMovementTaskPayload,
    ProcessStagedDataTaskPayload,
    TargetType,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload_kind import (
    TaskPayloadKind,
)
from data_migration_orchestrator.cloud_core.tasks.task_status import TaskStatus
from data_migration_orchestrator.cloud_core.tasks.queues.table_task_queue import (
    TableTaskQueue,
)
from shared.enums.source_type import SourceType


def mock_payload_mapper(kind: str, payload_dict: dict):
    """Mock payload mapper for testing."""
    if kind == TaskPayloadKind.DATA_MOVEMENT:
        return DataMovementTaskPayload(
            **{k: v for k, v in payload_dict.items() if k != "kind"}
        )
    elif kind == TaskPayloadKind.PROCESS_STAGED_DATA:
        return ProcessStagedDataTaskPayload(
            **{k: v for k, v in payload_dict.items() if k != "kind"}
        )
    return payload_dict


class TestTableTaskQueue(unittest.IsolatedAsyncioTestCase):
    """
    Test suite for the TableTaskQueue class.

    This test class validates the TableTaskQueue functionality,
    particularly the get_tasks method and its integration with
    Snowflake stored procedures.
    """

    def setUp(self):
        """Set up test fixtures before each test method."""
        self.mock_connection = MagicMock()
        self.task_queue = TableTaskQueue(self.mock_connection, mock_payload_mapper)

    async def test_get_tasks_empty_result(self):
        """Test get_tasks when no tasks are returned."""
        # Mock cursor that returns no rows
        mock_cursor = MagicMock()
        mock_cursor.fetchall.return_value = []
        self.mock_connection.cursor.return_value = mock_cursor

        # Call get_tasks
        tasks = await self.task_queue.get_tasks()

        # Assertions
        self.assertEqual(tasks, [])
        self.mock_connection.cursor.assert_called_once()
        mock_cursor.execute.assert_called_once_with(
            pull_tasks_call_template(),
            (
                ExecutorType.ORCHESTRATOR.value,
                ExecutorType.ORCHESTRATOR.value,
                None,  # affinity
                1000,  # capacity (max_tasks_to_pull default)
            ),
        )
        mock_cursor.fetchall.assert_called_once()

    async def test_get_tasks_single_task(self):
        """Test get_tasks when a single task is returned."""
        workflow_id = 1
        # Create a payload
        payload = DataMovementTaskPayload(
            source_type="sql-server",
            source_id="test_db",
            target_type="snowflake:table",
            target_id="MY_DB.MY_SCHEMA.MY_TABLE",
            statement_location_type="in-payload",
            statement_location_id="SELECT * FROM test_table",
            database="MY_DB",
            schema="MY_SCHEMA",
        )

        # Mock cursor that returns one row (PAYLOAD must be JSON string)
        mock_cursor = MagicMock()
        mock_cursor.fetchall.return_value = [
            {
                ID: 1,
                NAME: "Test Task",
                PRIORITY: 3,
                STATUS: "pending",
                PAYLOAD: json.dumps(payload.__dict__),
                "WORKFLOW_ID": workflow_id,
                SCOPE: "test_scope",
            }
        ]
        self.mock_connection.cursor.return_value = mock_cursor

        # Call get_tasks
        tasks = await self.task_queue.get_tasks()

        # Assertions
        self.assertEqual(len(tasks), 1)
        self.assertIsInstance(tasks[0], Task)
        self.assertEqual(tasks[0].id, 1)
        self.assertEqual(tasks[0].status, TaskStatus.EXECUTING)
        self.assertEqual(tasks[0].payload.source_type, payload.source_type)

    async def test_get_tasks_multiple_tasks(self):
        """Test get_tasks when multiple tasks are returned."""
        workflow_id = 1
        # Create multiple payloads
        payload1 = DataMovementTaskPayload(
            source_type="teradata",
            source_id="teradata_db",
            target_type=TargetType.SNOWFLAKE_STAGE.value,
            target_id="MY_DB.MY_SCHEMA.MY_STAGE/file1.parquet",
            statement_location_type="in-payload",
            statement_location_id="SELECT * FROM table1",
            database="MY_DB",
            schema="MY_SCHEMA",
        )

        payload2 = ProcessStagedDataTaskPayload(
            table_metadata_id=100,
            partition_metadata_id=1,
            partition_index=0,
            target_table="MY_DB.MY_SCHEMA.TARGET_TABLE",
        )

        payload3 = DataMovementTaskPayload(
            source_type=SourceType.REDSHIFT.value,
            source_id="redshift_db",
            target_type="snowflake:table",
            target_id="MY_DB.MY_SCHEMA.ANOTHER_TABLE",
            statement_location_type="snowflake:stage",
            statement_location_id="MY_DB.MY_SCHEMA.MY_STAGE/query.sql",
            database="MY_DB",
            schema="MY_SCHEMA",
        )

        # Mock cursor that returns multiple rows (PAYLOAD must be JSON strings)
        mock_cursor = MagicMock()
        mock_cursor.fetchall.return_value = [
            {
                ID: 10,
                NAME: "Task 1",
                PRIORITY: 3,
                PAYLOAD: json.dumps(payload1.__dict__),
                "WORKFLOW_ID": workflow_id,
                SCOPE: "test_scope",
            },
            {
                ID: 20,
                NAME: "Task 2",
                PRIORITY: 3,
                PAYLOAD: json.dumps(payload2.__dict__),
                "WORKFLOW_ID": workflow_id,
                SCOPE: "test_scope",
            },
            {
                ID: 30,
                NAME: "Task 3",
                PRIORITY: 3,
                PAYLOAD: json.dumps(payload3.__dict__),
                "WORKFLOW_ID": workflow_id,
                SCOPE: "test_scope",
            },
        ]
        self.mock_connection.cursor.return_value = mock_cursor

        # Call get_tasks
        tasks = await self.task_queue.get_tasks()

        # Assertions
        self.assertEqual(len(tasks), 3)

        # Verify task IDs and status
        self.assertEqual(tasks[0].id, 10)
        self.assertEqual(tasks[0].status, TaskStatus.EXECUTING)
        self.assertEqual(tasks[0].payload.kind, payload1.kind)

        self.assertEqual(tasks[1].id, 20)
        self.assertEqual(tasks[1].status, TaskStatus.EXECUTING)
        self.assertEqual(tasks[1].payload.kind, payload2.kind)

        self.assertEqual(tasks[2].id, 30)
        self.assertEqual(tasks[2].status, TaskStatus.EXECUTING)
        self.assertEqual(tasks[2].payload.kind, payload3.kind)

    async def test_get_tasks_uses_dict_cursor(self):
        """Test that get_tasks uses DictCursor for column name access."""
        from snowflake.connector import DictCursor

        # Mock cursor
        mock_cursor = MagicMock()
        mock_cursor.fetchall.return_value = []
        self.mock_connection.cursor.return_value = mock_cursor

        # Call get_tasks
        await self.task_queue.get_tasks()

        # Verify that cursor was called with DictCursor
        self.mock_connection.cursor.assert_called_once_with(DictCursor)

    async def test_get_tasks_calls_correct_stored_procedure(self):
        """Test that get_tasks calls the correct stored procedure with correct parameters."""
        # Mock cursor
        mock_cursor = MagicMock()
        mock_cursor.fetchall.return_value = []
        self.mock_connection.cursor.return_value = mock_cursor

        # Call get_tasks
        await self.task_queue.get_tasks()

        # Verify the stored procedure call
        expected_call = (
            ExecutorType.ORCHESTRATOR.value,
            ExecutorType.ORCHESTRATOR.value,
            None,  # affinity
            1000,  # capacity (max_tasks_to_pull default)
        )

        mock_cursor.execute.assert_called_once_with(
            pull_tasks_call_template(), expected_call
        )

    async def test_get_tasks_with_different_workflow_ids(self):
        """Test get_tasks can be called multiple times."""
        # Reset mock
        self.mock_connection.reset_mock()

        # Mock cursor
        mock_cursor = MagicMock()
        mock_cursor.fetchall.return_value = []
        self.mock_connection.cursor.return_value = mock_cursor

        # Call get_tasks multiple times
        for _ in range(3):
            await self.task_queue.get_tasks()

        # Verify get_tasks was called 3 times
        self.assertEqual(mock_cursor.execute.call_count, 3)

    async def test_get_tasks_with_all_task_statuses(self):
        """Test get_tasks with tasks in all possible statuses."""
        workflow_id = 1
        # Create tasks with different statuses
        base_payload = DataMovementTaskPayload(
            source_type="mysql",
            source_id="mysql_db",
            target_type="snowflake:table",
            target_id="TARGET",
            statement_location_type="in-payload",
            statement_location_id="SELECT 1",
            database="MY_DB",
            schema="MY_SCHEMA",
        )

        statuses = [
            "pending",
            "executing",
            "completed",
            "failed",
            "abandoned",
            "blocked",
        ]

        # Mock cursor that returns tasks with all statuses (PAYLOAD must be JSON string)
        mock_cursor = MagicMock()
        mock_cursor.fetchall.return_value = [
            {
                ID: i + 1,
                NAME: f"Task {i + 1}",
                PRIORITY: 3,
                STATUS: status,
                PAYLOAD: json.dumps(base_payload.__dict__),
                "WORKFLOW_ID": workflow_id,
                SCOPE: "test_scope",
            }
            for i, status in enumerate(statuses)
        ]
        self.mock_connection.cursor.return_value = mock_cursor

        # Call get_tasks
        tasks = await self.task_queue.get_tasks()

        # Assertions
        self.assertEqual(len(tasks), len(statuses))

        for task in tasks:
            self.assertEqual(task.status, TaskStatus.EXECUTING)

    async def test_get_tasks_preserves_order(self):
        """Test that get_tasks preserves the order of tasks from the database."""
        workflow_id = 1
        payload = ProcessStagedDataTaskPayload(
            table_metadata_id=100,
            partition_metadata_id=1,
            partition_index=0,
            target_table="target",
        )

        # Mock cursor with specific order (PAYLOAD must be JSON string)
        task_ids = [100, 50, 75, 25, 200]
        mock_cursor = MagicMock()
        mock_cursor.fetchall.return_value = [
            {
                ID: task_id,
                NAME: f"Task {task_id}",
                PRIORITY: 3,
                STATUS: "pending",
                PAYLOAD: json.dumps(payload.__dict__),
                "WORKFLOW_ID": workflow_id,
                SCOPE: "test_scope",
            }
            for task_id in task_ids
        ]
        self.mock_connection.cursor.return_value = mock_cursor

        # Call get_tasks
        tasks = await self.task_queue.get_tasks()

        # Verify order is preserved
        actual_ids = [task.id for task in tasks]
        self.assertEqual(actual_ids, task_ids)

    async def test_get_tasks_error_handling(self):
        """Test get_tasks behavior when database errors occur."""
        # Mock cursor that raises an exception
        mock_cursor = MagicMock()
        mock_cursor.execute.side_effect = Exception("Database connection error")
        self.mock_connection.cursor.return_value = mock_cursor

        # Verify exception is propagated
        with self.assertRaises(Exception) as context:
            await self.task_queue.get_tasks()

        self.assertIn("Database connection error", str(context.exception))

    def test_get_tasks_is_async(self):
        """Test that get_tasks is defined as an async method."""
        import inspect

        self.assertTrue(inspect.iscoroutinefunction(self.task_queue.get_tasks))


class TestRefreshWarehouseTasks(unittest.IsolatedAsyncioTestCase):
    """Tests for the warehouse task refresh logic using get_query_status."""

    def setUp(self):
        self.mock_connection = MagicMock()
        self.task_queue = TableTaskQueue(self.mock_connection, mock_payload_mapper)
        self._init_cache_from([])

    def _init_cache_from(self, rows: list[tuple[int, str]]):
        """Seed the in-memory cache directly, bypassing the DB query."""
        self.task_queue._pending_warehouse_tasks = dict(rows)
        self.task_queue._warehouse_tasks_loaded = True

    async def test_no_pending_tasks_skips_status_check(self):
        await self.task_queue.refresh_warehouse_tasks()
        self.mock_connection.get_query_status_throw_if_error.assert_not_called()

    async def test_success_completes_and_drains_cache(self):
        self._init_cache_from([(304, "q-abc")])
        self.mock_connection.get_query_status_throw_if_error.return_value = (
            QueryStatus.SUCCESS
        )
        self.mock_connection.is_still_running.return_value = False

        await self.task_queue.refresh_warehouse_tasks()

        self.assertEqual(self.task_queue._pending_warehouse_tasks, {})

    async def test_still_running_stays_in_cache(self):
        self._init_cache_from([(304, "q-abc")])
        self.mock_connection.get_query_status_throw_if_error.return_value = (
            QueryStatus.RUNNING
        )
        self.mock_connection.is_still_running.return_value = True

        await self.task_queue.refresh_warehouse_tasks()

        self.assertIn(304, self.task_queue._pending_warehouse_tasks)

    async def test_error_status_fails_and_drains_cache(self):
        for error_msg in (
            "SQL compilation error: something went wrong",
            "Warehouse task blocked",
            "Query aborted by user",
        ):
            self._init_cache_from([(1, "q-1")])
            self.mock_connection.get_query_status_throw_if_error.side_effect = (
                ProgrammingError(error_msg)
            )

            await self.task_queue.refresh_warehouse_tasks()

            self.assertEqual(
                self.task_queue._pending_warehouse_tasks,
                {},
                f"Failed for error: {error_msg}",
            )

    async def test_error_status_captures_detailed_error_message(self):
        self._init_cache_from([(1, "q-fail")])
        self.mock_connection.get_query_status_throw_if_error.side_effect = (
            ProgrammingError("SQL compilation error: Object 'MY_TABLE' does not exist")
        )

        with patch.object(self.task_queue, "_fail_warehouse_task") as mock_fail:
            await self.task_queue.refresh_warehouse_tasks()

            mock_fail.assert_awaited_once_with(
                1,
                "SQL compilation error: Object 'MY_TABLE' does not exist",
            )

    async def test_ambiguous_terminal_status_keeps_task_in_cache(self):
        self._init_cache_from([(304, "q-abc")])
        self.mock_connection.get_query_status_throw_if_error.return_value = (
            QueryStatus.NO_DATA
        )
        self.mock_connection.is_still_running.return_value = False

        await self.task_queue.refresh_warehouse_tasks()

        self.assertEqual(self.task_queue._pending_warehouse_tasks, {304: "q-abc"})

    async def test_non_snowflake_exception_keeps_task_in_cache(self):
        self._init_cache_from([(304, "q-abc")])
        self.mock_connection.get_query_status_throw_if_error.side_effect = Exception(
            "network timeout"
        )

        await self.task_queue.refresh_warehouse_tasks()

        self.assertEqual(self.task_queue._pending_warehouse_tasks, {304: "q-abc"})

    async def test_multiple_tasks_mixed_statuses(self):
        self._init_cache_from([(1, "q-done"), (2, "q-running"), (3, "q-err")])

        def mock_status_check(qid):
            if qid == "q-err":
                raise ProgrammingError("SQL error")
            return {
                "q-done": QueryStatus.SUCCESS,
                "q-running": QueryStatus.RUNNING,
            }[qid]

        self.mock_connection.get_query_status_throw_if_error.side_effect = (
            mock_status_check
        )
        self.mock_connection.is_still_running.side_effect = (
            lambda s: s == QueryStatus.RUNNING
        )

        await self.task_queue.refresh_warehouse_tasks()

        self.assertEqual(self.task_queue._pending_warehouse_tasks, {2: "q-running"})

    async def test_cache_initialized_from_db_on_first_call(self):
        self.task_queue._warehouse_tasks_loaded = False
        mock_cursor = MagicMock()
        mock_cursor.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor.__exit__ = MagicMock(return_value=False)
        mock_cursor.fetchall.return_value = [(10, "q-1")]
        self.mock_connection.cursor.return_value = mock_cursor
        self.mock_connection.get_query_status_throw_if_error.return_value = (
            QueryStatus.RUNNING
        )
        self.mock_connection.is_still_running.return_value = True

        await self.task_queue.refresh_warehouse_tasks()

        self.assertTrue(self.task_queue._warehouse_tasks_loaded)
        self.assertEqual(self.task_queue._pending_warehouse_tasks, {10: "q-1"})

    async def test_push_warehouse_task_populates_cache(self):
        payload = SnowflakeQueryTaskPayload(query="COPY INTO ...", query_id="q-new")
        mock_cursor = MagicMock()
        mock_cursor.fetchone.return_value = (42,)
        self.mock_connection.cursor.return_value = mock_cursor

        with patch.object(self.task_queue, "get_workflow_affinity", return_value=None):
            await self.task_queue._push_task_internal(
                workflow_id=1,
                executor_type=ExecutorType.WAREHOUSE,
                task_name="COPY INTO",
                payload=payload,
                scope="test",
            )

        self.assertEqual(self.task_queue._pending_warehouse_tasks, {42: "q-new"})

    async def test_push_non_warehouse_task_does_not_populate_cache(self):
        payload = SnowflakeQueryTaskPayload(query="SELECT 1", query_id="q-nope")
        mock_cursor = MagicMock()
        mock_cursor.fetchone.return_value = (42,)
        self.mock_connection.cursor.return_value = mock_cursor

        with patch.object(self.task_queue, "get_workflow_affinity", return_value=None):
            await self.task_queue._push_task_internal(
                workflow_id=1,
                executor_type=ExecutorType.ORCHESTRATOR,
                task_name="Some task",
                payload=payload,
                scope="test",
            )

        self.assertEqual(self.task_queue._pending_warehouse_tasks, {})


class TestPushTasksBatch(unittest.IsolatedAsyncioTestCase):
    """Tests for the batch insert path: push_tasks_batch and push_independent_two_task_chains."""

    def setUp(self):
        self.mock_connection = MagicMock()
        self.task_queue = TableTaskQueue(self.mock_connection, mock_payload_mapper)

    def _make_task(self, scope: str, successor_task_id=None, is_blocked=False) -> Task:
        return Task(
            workflow_id=1,
            executor_type=ExecutorType.ORCHESTRATOR,
            task_name="Test Task",
            payload=ProcessStagedDataTaskPayload(
                table_metadata_id=100,
                partition_metadata_id=1,
                partition_index=0,
                target_table="TARGET",
            ),
            scope=scope,
            successor_task_id=successor_task_id,
            is_blocked=is_blocked,
        )

    async def test_push_tasks_batch_empty_input(self):
        result = await self.task_queue.push_tasks_batch([])
        self.assertEqual(result, [])

    async def test_push_tasks_batch_returns_ids_in_input_order(self):
        tasks = [self._make_task("scope_b"), self._make_task("scope_a")]

        mock_cursor = MagicMock()
        mock_cursor.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor.__exit__ = MagicMock(return_value=False)
        # SELECT returns rows ordered by ID, not by input order
        mock_cursor.fetchall.return_value = [(10, "scope_a"), (20, "scope_b")]
        self.mock_connection.cursor.return_value = mock_cursor

        with patch.object(self.task_queue, "get_workflow_affinity", return_value=None):
            result = await self.task_queue.push_tasks_batch(tasks)

        # Should match input order (scope_b first, scope_a second)
        self.assertEqual(result, [20, 10])

    async def test_push_tasks_batch_raises_on_missing_scope(self):
        tasks = [self._make_task("scope_a")]

        mock_cursor = MagicMock()
        mock_cursor.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor.__exit__ = MagicMock(return_value=False)
        mock_cursor.fetchall.return_value = []  # no rows returned
        self.mock_connection.cursor.return_value = mock_cursor

        with patch.object(self.task_queue, "get_workflow_affinity", return_value=None):
            with self.assertRaises(Exception) as ctx:
                await self.task_queue.push_tasks_batch(tasks)

        self.assertIn("scope_a", str(ctx.exception))

    async def test_push_tasks_batch_successor_id_zero_not_null(self):
        tasks = [self._make_task("scope_a", successor_task_id=0)]

        executed_sqls: list[str] = []
        mock_cursor = MagicMock()
        mock_cursor.__enter__ = MagicMock(return_value=mock_cursor)
        mock_cursor.__exit__ = MagicMock(return_value=False)
        mock_cursor.execute.side_effect = lambda sql: executed_sqls.append(sql)
        mock_cursor.fetchall.return_value = [(1, "scope_a")]
        self.mock_connection.cursor.return_value = mock_cursor

        with patch.object(self.task_queue, "get_workflow_affinity", return_value="aff"):
            await self.task_queue.push_tasks_batch(tasks)

        insert_sql = executed_sqls[0]
        # successor_task_id=0 should appear as literal 0, not NULL
        self.assertIn(", 0, 'pending')", insert_sql)

    async def test_push_independent_chains_does_not_mutate_inputs(self):
        first = self._make_task("scope_first", successor_task_id=None, is_blocked=False)
        second = self._make_task(
            "scope_second", successor_task_id=None, is_blocked=False
        )

        original_first_blocked = first.is_blocked
        original_first_successor = first.successor_task_id
        original_second_blocked = second.is_blocked
        original_second_successor = second.successor_task_id

        with patch.object(
            self.task_queue, "push_tasks_batch", new_callable=AsyncMock
        ) as mock_batch:
            mock_batch.side_effect = [[100], [200]]
            await self.task_queue.push_independent_two_task_chains([(first, second)])

        self.assertEqual(first.is_blocked, original_first_blocked)
        self.assertEqual(first.successor_task_id, original_first_successor)
        self.assertEqual(second.is_blocked, original_second_blocked)
        self.assertEqual(second.successor_task_id, original_second_successor)

    async def test_push_independent_chains_returns_first_second_order(self):
        with patch.object(
            self.task_queue, "push_tasks_batch", new_callable=AsyncMock
        ) as mock_batch:
            # First call returns second_task_ids, second call returns first_task_ids
            mock_batch.side_effect = [[100, 200], [300, 400]]

            result = await self.task_queue.push_independent_two_task_chains(
                [
                    (self._make_task("f1"), self._make_task("s1")),
                    (self._make_task("f2"), self._make_task("s2")),
                ]
            )

        self.assertEqual(result, [300, 100, 400, 200])

    async def test_push_independent_chains_empty_input(self):
        result = await self.task_queue.push_independent_two_task_chains([])
        self.assertEqual(result, [])


class TestRefreshActiveLeases(unittest.IsolatedAsyncioTestCase):
    """Tests for the per-task refresh_active_leases method."""

    def setUp(self):
        self.mock_connection = MagicMock()
        self.task_queue = TableTaskQueue(self.mock_connection, mock_payload_mapper)
        self.mock_cursor = MagicMock()
        self.mock_connection.cursor.return_value.__enter__ = MagicMock(
            return_value=self.mock_cursor
        )
        self.mock_connection.cursor.return_value.__exit__ = MagicMock(
            return_value=False
        )

    async def test_refresh_specific_task_ids(self):
        """Should UPDATE only the given task IDs."""
        await self.task_queue.refresh_active_leases({10, 20})

        sql = self.mock_cursor.execute.call_args[0][0]
        self.assertIn("LEASING_TIME = SYSDATE()", sql)
        self.assertIn("STATUS = 'executing'", sql)
        for tid in (10, 20):
            self.assertIn(str(tid), sql)

    async def test_empty_set_skips_query(self):
        """An empty set should not execute any SQL."""
        await self.task_queue.refresh_active_leases(set())

        self.mock_cursor.execute.assert_not_called()


class TestGetTasksWithMaxTasks(unittest.IsolatedAsyncioTestCase):
    """Tests for the max_tasks parameter on get_tasks."""

    def setUp(self):
        self.mock_connection = MagicMock()
        self.task_queue = TableTaskQueue(self.mock_connection, mock_payload_mapper)

    async def test_get_tasks_default_uses_max_tasks_to_pull(self):
        """When max_tasks is not specified, the default limit (1000) is used."""
        mock_cursor = MagicMock()
        mock_cursor.fetchall.return_value = []
        self.mock_connection.cursor.return_value = mock_cursor

        await self.task_queue.get_tasks()

        mock_cursor.execute.assert_called_once_with(
            pull_tasks_call_template(),
            (
                ExecutorType.ORCHESTRATOR.value,
                ExecutorType.ORCHESTRATOR.value,
                None,
                1000,
            ),
        )

    async def test_get_tasks_with_custom_max_tasks(self):
        """When max_tasks is specified, it is used as the capacity limit."""
        mock_cursor = MagicMock()
        mock_cursor.fetchall.return_value = []
        self.mock_connection.cursor.return_value = mock_cursor

        await self.task_queue.get_tasks(max_tasks=5)

        mock_cursor.execute.assert_called_once_with(
            pull_tasks_call_template(),
            (
                ExecutorType.ORCHESTRATOR.value,
                ExecutorType.ORCHESTRATOR.value,
                None,
                5,
            ),
        )

    async def test_get_tasks_with_zero_max_tasks(self):
        """When max_tasks is 0, the stored procedure is called with capacity 0."""
        mock_cursor = MagicMock()
        mock_cursor.fetchall.return_value = []
        self.mock_connection.cursor.return_value = mock_cursor

        await self.task_queue.get_tasks(max_tasks=0)

        mock_cursor.execute.assert_called_once_with(
            pull_tasks_call_template(),
            (
                ExecutorType.ORCHESTRATOR.value,
                ExecutorType.ORCHESTRATOR.value,
                None,
                0,
            ),
        )


if __name__ == "__main__":
    unittest.main()
