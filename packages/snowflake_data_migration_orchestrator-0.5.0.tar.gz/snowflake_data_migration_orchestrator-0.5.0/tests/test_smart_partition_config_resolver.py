"""Unit tests for SmartPartitionConfigResolver."""

import pytest

from data_migration_orchestrator.data_migration_cloud.config.extraction_strategy import (
    ExtractionStrategy,
)
from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    PartitionSizeConfig,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.smart_partition_config_resolver import (
    SmartPartitionConfigResolver,
    _LARGE_TABLE_MAX_PARTITIONS,
    _LARGE_TABLE_THRESHOLD_MB,
)
from shared.enums.source_type import SourceType


class TestAutoMode:
    """Tests for the auto-resolution mode (both fields None)."""

    @pytest.mark.parametrize(
        "source_type, strategy",
        [
            (SourceType.REDSHIFT, ExtractionStrategy.UNLOAD),
            (SourceType.REDSHIFT, ExtractionStrategy.REGULAR),
            (SourceType.SQLSERVER, ExtractionStrategy.REGULAR),
            (SourceType.POSTGRESQL, ExtractionStrategy.REGULAR),
        ],
    )
    def test_auto_returns_config_for_known_platform(self, source_type, strategy):
        config = SmartPartitionConfigResolver.resolve(
            PartitionSizeConfig(),
            source_type=source_type,
            extraction_strategy=strategy,
        )

        assert config.max_single_partition_size_mb > 0
        assert config.target_partition_size_mb > 0
        assert config.min_partitions >= 2
        assert config.max_rows_per_partition is None

    def test_redshift_unload_has_larger_target_than_odbc(self):
        unload = SmartPartitionConfigResolver.resolve(
            PartitionSizeConfig(),
            source_type=SourceType.REDSHIFT,
            extraction_strategy=ExtractionStrategy.UNLOAD,
        )
        odbc = SmartPartitionConfigResolver.resolve(
            PartitionSizeConfig(),
            source_type=SourceType.REDSHIFT,
            extraction_strategy=ExtractionStrategy.REGULAR,
        )

        assert unload.target_partition_size_mb > odbc.target_partition_size_mb

    def test_large_table_gets_more_max_partitions(self):
        large = SmartPartitionConfigResolver.resolve(
            PartitionSizeConfig(),
            source_type=SourceType.REDSHIFT,
            extraction_strategy=ExtractionStrategy.REGULAR,
            data_size_mb=_LARGE_TABLE_THRESHOLD_MB + 1,
        )
        small = SmartPartitionConfigResolver.resolve(
            PartitionSizeConfig(),
            source_type=SourceType.REDSHIFT,
            extraction_strategy=ExtractionStrategy.REGULAR,
            data_size_mb=1000,
        )

        assert large.max_partitions == _LARGE_TABLE_MAX_PARTITIONS
        assert small.max_partitions < _LARGE_TABLE_MAX_PARTITIONS

    def test_auto_without_data_size_uses_default_max_partitions(self):
        config = SmartPartitionConfigResolver.resolve(
            PartitionSizeConfig(),
            source_type=SourceType.SQLSERVER,
            extraction_strategy=ExtractionStrategy.REGULAR,
            data_size_mb=None,
        )

        assert config.max_partitions == 100


class TestFixedMbMode:
    """Tests for the fixed-MB mode."""

    def test_fixed_mb_sets_target_and_threshold(self):
        config = SmartPartitionConfigResolver.resolve(
            PartitionSizeConfig(target_size_mb=2048),
            source_type=SourceType.SQLSERVER,
            extraction_strategy=ExtractionStrategy.REGULAR,
        )

        assert config.target_partition_size_mb == 2048
        assert config.max_single_partition_size_mb == 2048
        assert config.max_rows_per_partition is None

    def test_fixed_mb_ignores_platform(self):
        """Platform-specific profiles should not affect fixed-MB config."""
        rs = SmartPartitionConfigResolver.resolve(
            PartitionSizeConfig(target_size_mb=512),
            source_type=SourceType.REDSHIFT,
            extraction_strategy=ExtractionStrategy.UNLOAD,
        )
        ss = SmartPartitionConfigResolver.resolve(
            PartitionSizeConfig(target_size_mb=512),
            source_type=SourceType.SQLSERVER,
            extraction_strategy=ExtractionStrategy.REGULAR,
        )

        assert rs.target_partition_size_mb == ss.target_partition_size_mb == 512


class TestFixedRowsMode:
    """Tests for the fixed-rows mode."""

    def test_fixed_rows_sets_max_rows(self):
        config = SmartPartitionConfigResolver.resolve(
            PartitionSizeConfig(max_rows_per_partition=500_000),
            source_type=SourceType.SQLSERVER,
            extraction_strategy=ExtractionStrategy.REGULAR,
        )

        assert config.max_rows_per_partition == 500_000


class TestPartitionSizeConfig:
    """Tests for the PartitionSizeConfig domain model."""

    def test_default_is_auto(self):
        config = PartitionSizeConfig()
        assert config.is_auto

    def test_setting_a_field_is_not_auto(self):
        assert not PartitionSizeConfig(target_size_mb=1024).is_auto
        assert not PartitionSizeConfig(max_rows_per_partition=10_000).is_auto
