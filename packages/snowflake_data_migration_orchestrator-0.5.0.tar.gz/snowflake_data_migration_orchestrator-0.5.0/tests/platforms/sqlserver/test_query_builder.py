"""
Unit tests for SqlServerQueryBuilder.

Tests cover identifier quoting, checksum query generation, and extraction
query building, verifying SQL Server-specific dialect behavior.
"""

import pytest

from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    TableIdentifier,
)
from data_migration_orchestrator.data_migration_cloud.platforms.sqlserver.query_builder import (
    SqlServerQueryBuilder,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.checksum_models import (
    ColumnInfo,
    PartitionInfo,
)
from shared.enums.source_type import SourceType


class TestSqlServerQueryBuilder:
    """Test suite for SqlServerQueryBuilder."""

    @pytest.fixture
    def query_builder(self) -> SqlServerQueryBuilder:
        """Create a SqlServerQueryBuilder instance for testing."""
        return SqlServerQueryBuilder()

    def test_platform_name(self, query_builder: SqlServerQueryBuilder):
        """Test that platform_name returns 'sqlserver'."""
        assert query_builder.platform_name == SourceType.SQLSERVER

    def test_identifier_quote_char(self, query_builder: SqlServerQueryBuilder):
        """Test that SQL Server uses square brackets for identifiers."""
        assert query_builder.identifier_quote_char == ("[", "]")

    def test_build_use_database_command_returns_none(
        self, query_builder: SqlServerQueryBuilder
    ):
        """SQL Server should not produce a USE command (unsupported by Azure SQL)."""
        assert query_builder.build_use_database_command("SampleStoreDB") is None


class TestBuildWhereClauseWithCriteria:
    """Tests for build_where_clause with where_clause_criteria."""

    @pytest.fixture
    def query_builder(self) -> SqlServerQueryBuilder:
        return SqlServerQueryBuilder()

    def test_where_clause_criteria_only(self, query_builder: SqlServerQueryBuilder):
        """Test WHERE clause with only user criteria."""
        result = query_builder.build_where_clause(
            where_clause_criteria="is_deleted = 0"
        )
        assert result == "is_deleted = 0"

    def test_where_clause_criteria_with_partition(
        self, query_builder: SqlServerQueryBuilder
    ):
        """Test WHERE clause combining partition condition and user criteria."""
        result = query_builder.build_where_clause(
            partition_condition="[id] >= 1 AND [id] < 100",
            where_clause_criteria="is_deleted = 0",
        )
        assert result == "[id] >= 1 AND [id] < 100 AND is_deleted = 0"

    def test_where_clause_criteria_with_sync_data(
        self, query_builder: SqlServerQueryBuilder
    ):
        """Test WHERE clause combining watermark sync and user criteria."""
        from data_migration_orchestrator.data_migration_cloud.config.sync_strategy import (
            SyncStrategy,
        )
        from data_migration_orchestrator.data_migration_cloud.tasks.models.synchronization_data import (
            WatermarkSyncData,
        )

        sync_data = WatermarkSyncData(
            strategy=SyncStrategy.WATERMARK,
            watermark_column="updated_at",
            max_watermark_value="2026-01-01T00:00:00.000",
        )
        result = query_builder.build_where_clause(
            sync_data=sync_data,
            where_clause_criteria="status = 'active'",
        )
        assert "status = 'active'" in result
        assert "[updated_at] >" in result
        assert "AND" in result

    def test_where_clause_all_three_conditions(
        self, query_builder: SqlServerQueryBuilder
    ):
        """Test WHERE clause combining partition, sync, and user criteria."""
        from data_migration_orchestrator.data_migration_cloud.config.sync_strategy import (
            SyncStrategy,
        )
        from data_migration_orchestrator.data_migration_cloud.tasks.models.synchronization_data import (
            WatermarkSyncData,
        )

        sync_data = WatermarkSyncData(
            strategy=SyncStrategy.WATERMARK,
            watermark_column="updated_at",
            max_watermark_value="2026-01-01T00:00:00.000",
        )
        result = query_builder.build_where_clause(
            partition_condition="[id] >= 1 AND [id] < 100",
            sync_data=sync_data,
            where_clause_criteria="is_deleted = 0",
        )
        parts = result.split(" AND ")
        assert len(parts) >= 3
        assert "[id] >= 1" in result
        assert "is_deleted = 0" in result
        assert "[updated_at] >" in result

    def test_where_clause_criteria_none(self, query_builder: SqlServerQueryBuilder):
        """Test that None criteria doesn't affect the clause."""
        result = query_builder.build_where_clause(
            partition_condition="[id] >= 1 AND [id] < 100",
            where_clause_criteria=None,
        )
        assert result == "[id] >= 1 AND [id] < 100"

    def test_where_clause_criteria_empty_string(
        self, query_builder: SqlServerQueryBuilder
    ):
        """Test that empty string criteria doesn't affect the clause."""
        result = query_builder.build_where_clause(
            partition_condition="[id] >= 1",
            where_clause_criteria="   ",
        )
        assert result == "[id] >= 1"

    def test_where_clause_criteria_whitespace_stripped(
        self, query_builder: SqlServerQueryBuilder
    ):
        """Test that criteria whitespace is stripped."""
        result = query_builder.build_where_clause(
            where_clause_criteria="  is_deleted = 0  ",
        )
        assert result == "is_deleted = 0"

    def test_no_conditions_returns_none(self, query_builder: SqlServerQueryBuilder):
        """Test that no conditions returns None."""
        result = query_builder.build_where_clause(
            where_clause_criteria=None,
        )
        assert result is None


class TestBuildExtractionQueryWithCriteria:
    """Tests for build_extraction_query with where_clause_criteria."""

    @pytest.fixture
    def query_builder(self) -> SqlServerQueryBuilder:
        return SqlServerQueryBuilder()

    def test_extraction_query_with_criteria(self, query_builder: SqlServerQueryBuilder):
        """Test that where_clause_criteria appears in the extraction query."""
        table = TableIdentifier(
            database_name="TestDB",
            schema_name="dbo",
            table_name="Orders",
        )
        schema = [
            {"column_name": "OrderID", "data_type": "int"},
            {"column_name": "Status", "data_type": "varchar"},
        ]

        result = query_builder.build_extraction_query(
            table_name=table,
            source_schema=schema,
            where_clause_criteria="Status = 'active'",
        )

        assert "WHERE" in result
        assert "Status = 'active'" in result

    def test_extraction_query_without_criteria(
        self, query_builder: SqlServerQueryBuilder
    ):
        """Test extraction query without criteria has no spurious WHERE."""
        table = TableIdentifier(
            database_name="TestDB",
            schema_name="dbo",
            table_name="Orders",
        )
        schema = [
            {"column_name": "OrderID", "data_type": "int"},
        ]

        result = query_builder.build_extraction_query(
            table_name=table,
            source_schema=schema,
        )

        assert "WHERE" not in result

    def test_extraction_query_criteria_with_partition(
        self, query_builder: SqlServerQueryBuilder
    ):
        """Test extraction query combining partition and user criteria."""
        table = TableIdentifier(
            database_name="TestDB",
            schema_name="dbo",
            table_name="Orders",
        )
        schema = [
            {"column_name": "OrderID", "data_type": "int"},
        ]

        result = query_builder.build_extraction_query(
            table_name=table,
            source_schema=schema,
            partition_condition="[OrderID] >= 1 AND [OrderID] < 100",
            where_clause_criteria="is_deleted = 0",
        )

        assert "WHERE" in result
        assert "[OrderID] >= 1 AND [OrderID] < 100" in result
        assert "is_deleted = 0" in result


class TestSqlServerChecksumQuery:
    """Tests for SqlServerQueryBuilder.build_checksum_query."""

    @pytest.fixture
    def builder(self):
        """Create a builder instance."""
        return SqlServerQueryBuilder()

    @pytest.fixture
    def partition_info(self):
        """Create sample partition info."""
        return PartitionInfo(
            database="TestDB",
            schema="dbo",
            table_name="Orders",
            partition_column="order_id",
            min_value="1000",
            max_value="1999",
            partition_number=1,
        )

    @pytest.fixture
    def source_table_id(self):
        """Create sample source table identifier."""
        return TableIdentifier(
            database_name="TestDB",
            schema_name="dbo",
            table_name="Orders",
        )

    @pytest.fixture
    def sample_columns(self):
        """Create sample column list."""
        return [
            ColumnInfo("order_id", "int", False),
            ColumnInfo("customer_name", "varchar", True),
            ColumnInfo("amount", "decimal", True, 18, 2),
            ColumnInfo("created_at", "datetime2", False),
        ]

    def test_build_checksum_query_basic(
        self, builder, partition_info, source_table_id, sample_columns
    ):
        """Test building a basic checksum query."""
        query = builder.build_checksum_query(
            partition_info, source_table_id, sample_columns
        )

        assert "HASHBYTES('md5'" in query
        assert "[TestDB].[dbo].[Orders]" in query
        assert "[order_id] >= N'1000'" in query
        assert "[order_id] <= N'1999'" in query
        assert "SUBSTRING(hashed_columns, 1, 4)" in query
        assert "SUBSTRING(hashed_columns, 5, 4)" in query
        assert "SUBSTRING(hashed_columns, 9, 4)" in query
        assert "SUBSTRING(hashed_columns, 13, 4)" in query
        assert "+ ':' +" in query
        assert "AS checksum" in query

    def test_skipped_column_types(self, builder, partition_info, source_table_id):
        """Test that image, ntext, text columns are skipped."""
        columns = [
            ColumnInfo("id", "int", False),
            ColumnInfo("photo", "image", True),
            ColumnInfo("notes", "ntext", True),
            ColumnInfo("description", "text", True),
        ]

        query = builder.build_checksum_query(partition_info, source_table_id, columns)

        assert "[id]" in query
        assert "[photo]" not in query
        assert "[notes]" not in query
        assert "[description]" not in query

    def test_all_columns_skipped_falls_back_to_count(
        self, builder, partition_info, source_table_id
    ):
        """Test fallback to COUNT when all columns are unhashable."""
        columns = [
            ColumnInfo("photo", "image", True),
            ColumnInfo("content", "ntext", True),
        ]

        query = builder.build_checksum_query(partition_info, source_table_id, columns)

        assert "COUNT_BIG(*)" in query
        assert "HASHBYTES" not in query

    def test_nullable_columns_use_isnull(
        self, builder, partition_info, source_table_id
    ):
        """Test that nullable columns are wrapped with ISNULL."""
        columns = [
            ColumnInfo("id", "int", False),
            ColumnInfo("name", "varchar", True),
        ]

        query = builder.build_checksum_query(partition_info, source_table_id, columns)

        assert "ISNULL(" in query
        assert "-99999999" in query

    def test_partition_without_boundaries(self, builder, source_table_id):
        """Test query when partition has no boundaries (full table)."""
        partition_info = PartitionInfo(
            database="TestDB",
            schema="dbo",
            table_name="Orders",
            partition_column="order_id",
            min_value=None,
            max_value=None,
            partition_number=0,
        )
        columns = [ColumnInfo("id", "int", False)]

        query = builder.build_checksum_query(partition_info, source_table_id, columns)

        assert "WHERE 1=1" in query

    def test_charamelize_datetime_types(self, builder, partition_info, source_table_id):
        """Test character conversion for datetime types."""
        columns = [
            ColumnInfo("created", "datetime", False),
            ColumnInfo("updated", "datetime2", False),
            ColumnInfo("event_date", "date", False),
            ColumnInfo("event_time", "time", False),
            ColumnInfo("with_tz", "datetimeoffset", False),
        ]

        query = builder.build_checksum_query(partition_info, source_table_id, columns)

        assert "CONVERT(nvarchar(29)" in query
        assert "121" in query
        assert "CONVERT(nvarchar(10)" in query
        assert "23" in query
        assert "CONVERT(nvarchar(35)" in query
        assert "127" in query

    def test_charamelize_numeric_types(self, builder, partition_info, source_table_id):
        """Test character conversion for numeric types."""
        columns = [
            ColumnInfo("amount", "decimal", False, 18, 2),
            ColumnInfo("price", "money", False),
            ColumnInfo("qty", "int", False),
            ColumnInfo("rate", "float", False),
        ]

        query = builder.build_checksum_query(partition_info, source_table_id, columns)

        assert "LTRIM(STR(" in query
        assert "CONVERT(nvarchar(50)" in query

    def test_charamelize_binary_types(self, builder, partition_info, source_table_id):
        """Test character conversion for binary types."""
        columns = [
            ColumnInfo("hash", "binary", False),
            ColumnInfo("data", "varbinary", False),
            ColumnInfo("rowver", "timestamp", False),
        ]

        query = builder.build_checksum_query(partition_info, source_table_id, columns)

        assert "CONVERT(nvarchar(max)" in query

    def test_charamelize_special_types(self, builder, partition_info, source_table_id):
        """Test character conversion for special SQL Server types."""
        columns = [
            ColumnInfo("guid", "uniqueidentifier", False),
            ColumnInfo("xml_data", "xml", False),
            ColumnInfo("hierarchy", "hierarchyid", False),
            ColumnInfo("location", "geography", False),
        ]

        query = builder.build_checksum_query(partition_info, source_table_id, columns)

        assert "CONVERT(nvarchar(36)" in query
        assert "CONVERT(XML" in query
        assert ".ToString()" in query
        assert ".STAsText()" in query
