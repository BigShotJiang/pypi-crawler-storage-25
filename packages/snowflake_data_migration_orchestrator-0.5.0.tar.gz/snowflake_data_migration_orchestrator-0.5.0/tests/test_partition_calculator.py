"""Unit tests for PartitionCalculator and PartitionConfig."""

from data_migration_orchestrator.data_migration_cloud.tasks.handlers.partition_calculator import (
    PartitionCalculator,
    PartitionConfig,
)


class TestSizeBasedPartitioning:
    """Tests for the default size-based (MB) partitioning mode."""

    def test_empty_table_returns_no_partition(self):
        calc = PartitionCalculator()
        decision = calc.calculate_partition_strategy(row_count=0, data_size_mb=0)

        assert not decision.should_partition
        assert decision.num_partitions == 1
        assert decision.rows_per_partition == 0

    def test_small_table_below_threshold_returns_no_partition(self):
        config = PartitionConfig(max_single_partition_size_mb=1024)
        calc = PartitionCalculator(config)
        decision = calc.calculate_partition_strategy(row_count=1000, data_size_mb=500)

        assert not decision.should_partition
        assert decision.num_partitions == 1
        assert decision.rows_per_partition == 1000

    def test_large_table_returns_partitions(self):
        config = PartitionConfig(
            max_single_partition_size_mb=1024,
            target_partition_size_mb=512,
        )
        calc = PartitionCalculator(config)
        decision = calc.calculate_partition_strategy(
            row_count=100_000, data_size_mb=2048
        )

        assert decision.should_partition
        assert decision.num_partitions >= 2
        assert decision.rows_per_partition > 0

    def test_partitions_respect_min_bound(self):
        config = PartitionConfig(
            max_single_partition_size_mb=10,
            target_partition_size_mb=10000,
            min_partitions=5,
        )
        calc = PartitionCalculator(config)
        decision = calc.calculate_partition_strategy(row_count=100, data_size_mb=20)

        assert decision.should_partition
        assert decision.num_partitions >= 5

    def test_partitions_respect_max_bound(self):
        config = PartitionConfig(
            max_single_partition_size_mb=1,
            target_partition_size_mb=1,
            max_partitions=10,
        )
        calc = PartitionCalculator(config)
        decision = calc.calculate_partition_strategy(
            row_count=1_000_000, data_size_mb=100_000
        )

        assert decision.should_partition
        assert decision.num_partitions <= 10


class TestRowBasedPartitioning:
    """Tests for the row-based partitioning mode (max_rows_per_partition)."""

    def test_small_table_within_row_limit_returns_no_partition(self):
        config = PartitionConfig(max_rows_per_partition=10_000)
        calc = PartitionCalculator(config)
        decision = calc.calculate_partition_strategy(row_count=5000, data_size_mb=100)

        assert not decision.should_partition
        assert decision.num_partitions == 1
        assert decision.rows_per_partition == 5000

    def test_large_table_partitioned_by_rows(self):
        config = PartitionConfig(max_rows_per_partition=1000)
        calc = PartitionCalculator(config)
        decision = calc.calculate_partition_strategy(row_count=5000, data_size_mb=500)

        assert decision.should_partition
        assert decision.num_partitions == 5
        assert decision.rows_per_partition == 1000

    def test_row_based_ceiling_division(self):
        config = PartitionConfig(max_rows_per_partition=3000)
        calc = PartitionCalculator(config)
        decision = calc.calculate_partition_strategy(row_count=10_000, data_size_mb=500)

        assert decision.should_partition
        assert decision.num_partitions == 4  # ceil(10000/3000) = 4

    def test_row_based_respects_max_partitions(self):
        config = PartitionConfig(
            max_rows_per_partition=10,
            max_partitions=5,
        )
        calc = PartitionCalculator(config)
        decision = calc.calculate_partition_strategy(row_count=1000, data_size_mb=100)

        assert decision.should_partition
        assert decision.num_partitions == 5

    def test_row_based_ignores_data_size_for_threshold(self):
        """Row-based mode uses row_count, not data_size_mb, to decide whether to partition."""
        config = PartitionConfig(max_rows_per_partition=100)
        calc = PartitionCalculator(config)

        decision = calc.calculate_partition_strategy(row_count=500, data_size_mb=0.01)
        assert decision.should_partition
        assert decision.num_partitions == 5
