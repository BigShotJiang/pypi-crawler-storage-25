"""Unit tests for the create-data-validation-workflow command (duplicate name)."""

import json

from argparse import Namespace
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from data_migration_orchestrator.commands.create_data_validation_workflow import (
    create_data_validation_workflow,
)


def _minimal_validation_config() -> dict:
    return {
        "source_platform": "sqlserver",
        "tables": [
            {
                "fully_qualified_name": "src_db.dbo.customers",
            }
        ],
    }


class TestCreateDataValidationWorkflowDuplicateName:
    """Tests for duplicate workflow name rejection."""

    def _make_args(self, config_file: Path, **overrides) -> Namespace:
        defaults = {
            "config_file": config_file,
            "connection_name": None,
            "name": "MY_VALIDATION_WORKFLOW",
            "source_platform": None,
        }
        defaults.update(overrides)
        return Namespace(**defaults)

    def test_exits_on_duplicate_workflow_name(self, tmp_path: Path):
        config = _minimal_validation_config()
        config_file = tmp_path / "config.json"
        config_file.write_text(json.dumps(config))

        mock_cursor = MagicMock()
        mock_conn = MagicMock()
        mock_conn.cursor.return_value = mock_cursor

        args = self._make_args(config_file, name="DUPLICATE_WF")

        with (
            patch(
                "data_migration_orchestrator.commands.create_data_validation_workflow._connect",
                return_value=mock_conn,
            ),
            patch(
                "data_migration_orchestrator.commands.create_data_validation_workflow._workflow_name_exists",
                return_value=True,
            ),
            pytest.raises(SystemExit) as exc_info,
        ):
            create_data_validation_workflow(args)

        assert exc_info.value.code == 1
        mock_cursor.execute.assert_not_called()
        mock_cursor.close.assert_called_once()
        mock_conn.close.assert_called_once()
