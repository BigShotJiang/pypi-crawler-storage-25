"""Unit tests for type mapping functionality."""

from dataclasses import FrozenInstanceError
import pytest

from shared.enums.file_type import FileType
from data_migration_orchestrator.data_migration_core.type_mappings import (
    TypeMapping,
    TypeMappingCategory,
)
from data_migration_orchestrator.data_migration_cloud.utils.type_mapping_loader import (
    TypeMappingLoader,
)
from data_migration_orchestrator.utils.snowflake_metadata import (
    qualified_migration_schema,
)
from data_migration_orchestrator.data_migration_core.type_mappings.models import (
    SourceTypeInfo,
)
from shared.enums.source_type import SourceType


class TestTypeMappingCategory:
    """Tests for TypeMappingCategory enum."""

    def test_category_values(self):
        """Test that all expected categories exist."""
        expected_categories = [
            "Binary",
            "Character",
            "NCharacter",
            "Date",
            "Datetime",
            "Time",
            "Timestamp",
            "Float",
            "Logical",
            "Numeric",
            "Variant",
            "Geography",
            "Other",
        ]

        for category in expected_categories:
            assert TypeMappingCategory(category) is not None

    def test_category_string_representation(self):
        """Test that categories have correct string values."""
        assert TypeMappingCategory.NUMERIC == "Numeric"
        assert TypeMappingCategory.CHARACTER == "Character"
        assert TypeMappingCategory.TIMESTAMP == "Timestamp"


class TestTypeMapping:
    """Tests for TypeMapping dataclass."""

    def test_basic_type_mapping_creation(self):
        """Test creating a basic type mapping."""
        mapping = TypeMapping(
            source_type="VARCHAR",
            snowflake_type="VARCHAR",
            category=TypeMappingCategory.CHARACTER,
        )

        assert mapping.source_type == "VARCHAR"
        assert mapping.snowflake_type == "VARCHAR"
        assert mapping.category == TypeMappingCategory.CHARACTER
        assert mapping.is_lob is False
        assert mapping.notes is None

    def test_type_mapping_with_all_fields(self):
        """Test creating a type mapping with all fields."""
        mapping = TypeMapping(
            source_type="text",
            snowflake_type="varchar",
            category=TypeMappingCategory.CHARACTER,
            is_lob=True,
            notes="Large text field",
        )

        assert mapping.source_type == "TEXT"  # Should be normalized to uppercase
        assert mapping.snowflake_type == "VARCHAR"
        assert mapping.category == TypeMappingCategory.CHARACTER
        assert mapping.is_lob is True
        assert mapping.notes == "Large text field"

    def test_type_mapping_normalization(self):
        """Test that type names are normalized to uppercase."""
        mapping = TypeMapping(
            source_type="varchar",
            snowflake_type="varchar",
            category=TypeMappingCategory.CHARACTER,
        )

        assert mapping.source_type == "VARCHAR"
        assert mapping.snowflake_type == "VARCHAR"

    def test_type_mapping_string_representation(self):
        """Test string representation of type mapping."""
        mapping = TypeMapping(
            source_type="INT",
            snowflake_type="NUMBER",
            category=TypeMappingCategory.NUMERIC,
        )

        str_repr = str(mapping)
        assert "INT" in str_repr
        assert "NUMBER" in str_repr
        assert "Numeric" in str_repr

    def test_type_mapping_lob_in_string(self):
        """Test that LOB marker appears in string representation."""
        mapping = TypeMapping(
            source_type="TEXT",
            snowflake_type="VARCHAR",
            category=TypeMappingCategory.CHARACTER,
            is_lob=True,
        )

        str_repr = str(mapping)
        assert "(LOB)" in str_repr

    def test_type_mapping_immutability(self):
        """Test that TypeMapping is frozen (immutable)."""
        mapping = TypeMapping(
            source_type="INT",
            snowflake_type="NUMBER",
            category=TypeMappingCategory.NUMERIC,
        )

        with pytest.raises((FrozenInstanceError, AttributeError)):
            mapping.source_type = "BIGINT"  # type: ignore[misc]


class TestSourceTypeInfo:
    """Tests for SourceTypeInfo class."""

    def test_get_mapping(self):
        """Test getting a mapping by source type."""
        mappings = {
            "INT": TypeMapping("INT", "NUMBER", TypeMappingCategory.NUMERIC),
            "VARCHAR": TypeMapping("VARCHAR", "VARCHAR", TypeMappingCategory.CHARACTER),
        }

        info = SourceTypeInfo(
            source_system=SourceType.SQLSERVER.value, mappings=mappings
        )

        # Test case-insensitive lookup
        mapping = info.get_mapping("int")
        assert mapping is not None
        assert mapping.source_type == "INT"
        assert mapping.snowflake_type == "NUMBER"

    def test_get_mapping_not_found(self):
        """Test getting a mapping that doesn't exist."""
        info = SourceTypeInfo(source_system=SourceType.SQLSERVER.value, mappings={})

        mapping = info.get_mapping("NONEXISTENT")
        assert mapping is None

    def test_get_snowflake_type(self):
        """Test getting just the Snowflake type."""
        mappings = {
            "INT": TypeMapping("INT", "NUMBER", TypeMappingCategory.NUMERIC),
        }

        info = SourceTypeInfo(
            source_system=SourceType.SQLSERVER.value, mappings=mappings
        )

        snowflake_type = info.get_snowflake_type("INT")
        assert snowflake_type == "NUMBER"

    def test_list_all_source_types(self):
        """Test listing all source types."""
        mappings = {
            "INT": TypeMapping("INT", "NUMBER", TypeMappingCategory.NUMERIC),
            "VARCHAR": TypeMapping("VARCHAR", "VARCHAR", TypeMappingCategory.CHARACTER),
            "DATE": TypeMapping("DATE", "DATE", TypeMappingCategory.DATE),
        }

        info = SourceTypeInfo(
            source_system=SourceType.SQLSERVER.value, mappings=mappings
        )

        source_types = info.list_all_source_types()
        assert len(source_types) == 3
        assert source_types == ["DATE", "INT", "VARCHAR"]  # Should be sorted

    def test_list_by_category(self):
        """Test filtering mappings by category."""
        mappings = {
            "INT": TypeMapping("INT", "NUMBER", TypeMappingCategory.NUMERIC),
            "BIGINT": TypeMapping("BIGINT", "NUMBER", TypeMappingCategory.NUMERIC),
            "VARCHAR": TypeMapping("VARCHAR", "VARCHAR", TypeMappingCategory.CHARACTER),
        }

        info = SourceTypeInfo(
            source_system=SourceType.SQLSERVER.value, mappings=mappings
        )

        numeric_types = info.list_by_category(TypeMappingCategory.NUMERIC)
        assert len(numeric_types) == 2
        assert all(m.category == TypeMappingCategory.NUMERIC for m in numeric_types)


class TestTypeMappingLoader:
    """Tests for TypeMappingLoader class."""

    def test_get_snowflake_type(self):
        """Test getting Snowflake type for a source type."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER.value)

        assert loader.get_snowflake_type("INT") == "NUMBER"
        assert loader.get_snowflake_type("VARCHAR") == "VARCHAR"
        assert loader.get_snowflake_type("DATETIME") == "TIMESTAMP_NTZ"
        assert loader.get_snowflake_type("BIT") == "BOOLEAN"

    def test_get_snowflake_type_case_insensitive(self):
        """Test that type lookup is case-insensitive."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER.value)
        assert loader.get_snowflake_type("int") == "NUMBER"
        assert loader.get_snowflake_type("Int") == "NUMBER"
        assert loader.get_snowflake_type("INT") == "NUMBER"

    def test_get_mapping(self):
        """Test getting full mapping information."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER.value)

        mapping = loader.get_mapping("TEXT")
        assert mapping is not None
        assert mapping.source_type == "TEXT"
        assert mapping.snowflake_type == "VARCHAR"
        assert mapping.category == TypeMappingCategory.CHARACTER
        assert mapping.is_lob is True

    def test_get_mapping_not_found(self):
        """Test getting a mapping that doesn't exist."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER.value)

        mapping = loader.get_mapping("NONEXISTENT_TYPE")
        assert mapping is None

    def test_get_all_mappings(self):
        """Test getting all mappings as a dictionary."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER.value)

        mappings = loader.get_all_mappings()
        assert isinstance(mappings, dict)
        assert len(mappings) > 0

        # Verify some expected types are present
        assert "INT" in mappings
        assert "VARCHAR" in mappings
        assert "DATE" in mappings

    def test_list_all_source_types(self):
        """Test listing all source types."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER.value)

        source_types = loader.list_all_source_types()
        assert isinstance(source_types, list)
        assert len(source_types) > 0
        assert "INT" in source_types
        assert "VARCHAR" in source_types

        # Verify list is sorted
        assert source_types == sorted(source_types)

    def test_list_by_category(self):
        """Test filtering types by category."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER.value)

        # Test numeric types
        numeric_types = loader.list_by_category(TypeMappingCategory.NUMERIC)
        assert len(numeric_types) > 0
        assert all(m.category == TypeMappingCategory.NUMERIC for m in numeric_types)

        # Verify expected numeric types
        numeric_type_names = [m.source_type for m in numeric_types]
        assert "INT" in numeric_type_names
        assert "BIGINT" in numeric_type_names
        assert "DECIMAL" in numeric_type_names

    def test_is_lob_type(self):
        """Test checking if a type is a LOB type."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER.value)

        # LOB types
        assert loader.is_lob_type("TEXT") is True
        assert loader.is_lob_type("NTEXT") is True
        assert loader.is_lob_type("IMAGE") is True

        # Non-LOB types
        assert loader.is_lob_type("VARCHAR") is False
        assert loader.is_lob_type("INT") is False

    def test_get_category(self):
        """Test getting category for a type."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER.value)

        assert loader.get_category("INT") == TypeMappingCategory.NUMERIC
        assert loader.get_category("VARCHAR") == TypeMappingCategory.CHARACTER
        assert loader.get_category("DATE") == TypeMappingCategory.DATE
        assert loader.get_category("TIMESTAMP") == TypeMappingCategory.BINARY

    def test_get_category_not_found(self):
        """Test getting category for non-existent type."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER.value)

        category = loader.get_category("NONEXISTENT")
        assert category is None

    def test_get_available_source_types(self):
        """Test getting list of available source types."""
        available_types = TypeMappingLoader.get_available_source_types()

        assert isinstance(available_types, list)
        assert SourceType.SQLSERVER.value in available_types

    def test_loader_with_unsupported_source_type(self):
        """Test that loader raises error for unsupported source type."""
        with pytest.raises(ValueError, match="is not a valid SourceType"):
            TypeMappingLoader(source_type="unsupported_db")

    def test_comprehensive_sqlserver_mappings(self):
        """Test that all expected SQL Server types are mapped."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER.value)

        # Numeric types (plain NUMBER)
        plain_numeric_types = ["BIGINT", "INT", "SMALLINT", "TINYINT"]
        for type_name in plain_numeric_types:
            assert loader.get_snowflake_type(type_name) == "NUMBER"

        # Numeric types with precision/scale
        assert loader.get_snowflake_type("DECIMAL") == "NUMBER(20, 10)"
        assert loader.get_snowflake_type("NUMERIC") == "NUMBER(20, 10)"
        assert loader.get_snowflake_type("MONEY") == "NUMBER(20, 10)"
        assert loader.get_snowflake_type("SMALLMONEY") == "NUMBER(10, 5)"

        # Float types
        assert loader.get_snowflake_type("FLOAT") == "FLOAT"
        assert loader.get_snowflake_type("REAL") == "FLOAT"

        # Boolean
        assert loader.get_snowflake_type("BIT") == "BOOLEAN"

        # Character types
        char_types = ["CHAR", "VARCHAR", "TEXT"]
        for type_name in char_types:
            assert loader.get_snowflake_type(type_name) == "VARCHAR"

        # National character types
        nchar_types = ["NCHAR", "NVARCHAR", "NTEXT"]
        for type_name in nchar_types:
            assert loader.get_snowflake_type(type_name) == "VARCHAR"

        # Date/time types
        assert loader.get_snowflake_type("DATE") == "DATE"
        assert loader.get_snowflake_type("TIME") == "TIME"
        assert loader.get_snowflake_type("DATETIME") == "TIMESTAMP_NTZ"
        assert loader.get_snowflake_type("DATETIME2") == "TIMESTAMP_NTZ"
        assert loader.get_snowflake_type("DATETIMEOFFSET") == "TIMESTAMP_TZ"

        # Binary types
        binary_types = ["BINARY", "VARBINARY", "IMAGE"]
        for type_name in binary_types:
            assert loader.get_snowflake_type(type_name) == "BINARY"

        # Special types
        assert loader.get_snowflake_type("UNIQUEIDENTIFIER") == "VARCHAR"
        assert loader.get_snowflake_type("XML") == "VARIANT"
        assert loader.get_snowflake_type("GEOGRAPHY") == "GEOGRAPHY"


class TestTypeMappingIntegration:
    """Integration tests for type mapping system."""

    def test_end_to_end_type_lookup(self):
        """Test complete workflow of looking up a type mapping."""
        # Initialize loader
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER.value)

        # Get mapping
        mapping = loader.get_mapping("DATETIME2")

        # Verify all information is available
        assert mapping is not None
        assert mapping.source_type == "DATETIME2"
        assert mapping.snowflake_type == "TIMESTAMP_NTZ"
        assert mapping.category == TypeMappingCategory.TIMESTAMP
        # Notes are optional in simple format
        # assert mapping.notes is not None

    def test_category_filtering_workflow(self):
        """Test workflow of filtering types by category."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER.value)

        # Get all timestamp types
        timestamp_types = loader.list_by_category(TypeMappingCategory.TIMESTAMP)

        # Verify expected types are present
        timestamp_type_names = [m.source_type for m in timestamp_types]
        assert "DATETIME2" in timestamp_type_names
        assert "DATETIMEOFFSET" in timestamp_type_names

    def test_lob_type_identification_workflow(self):
        """Test workflow of identifying LOB types."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER.value)

        # Get all mappings and filter LOB types
        all_mappings = loader.get_all_mappings()
        lob_types = [mapping for mapping in all_mappings.values() if mapping.is_lob]

        # Verify LOB types are correctly identified
        lob_type_names = [m.source_type for m in lob_types]
        assert "TEXT" in lob_type_names
        assert "NTEXT" in lob_type_names
        assert "IMAGE" in lob_type_names

        # Verify non-LOB types are not included
        assert "VARCHAR" not in lob_type_names
        assert "INT" not in lob_type_names


class TestCustomMappings:
    """Tests for custom type mapping overrides."""

    def test_custom_mappings_override(self, tmp_path):
        """Test that custom mappings override default mappings."""
        # Create custom mappings file
        custom_file = tmp_path / "custom_mappings.yaml"
        custom_file.write_text(
            """
# Override INT to use BIGINT instead of NUMBER
INT: BIGINT

# Override VARCHAR to use TEXT
VARCHAR:
  snowflake_type: TEXT
  category: Character
  notes: Custom override for VARCHAR
"""
        )

        # Load with custom mappings
        loader = TypeMappingLoader(
            source_type=SourceType.SQLSERVER, custom_mappings_file=custom_file
        )

        # Verify overrides took effect
        assert loader.get_snowflake_type("INT") == "BIGINT"
        assert loader.get_snowflake_type("VARCHAR") == "TEXT"

        # Verify non-overridden types still work
        assert loader.get_snowflake_type("BIGINT") == "NUMBER"

        # Verify custom notes
        varchar_mapping = loader.get_mapping("VARCHAR")
        assert varchar_mapping is not None
        assert varchar_mapping.notes == "Custom override for VARCHAR"

    def test_custom_mappings_add_new_type(self, tmp_path):
        """Test adding a custom type not in default mappings."""
        custom_file = tmp_path / "custom_mappings.yaml"
        custom_file.write_text(
            """
# Add custom type
CUSTOM_TYPE:
  snowflake_type: VARCHAR(1000)
  category: Character
  notes: Custom application-specific type
"""
        )

        loader = TypeMappingLoader(
            source_type=SourceType.SQLSERVER, custom_mappings_file=custom_file
        )

        # Verify custom type is available
        assert loader.get_snowflake_type("CUSTOM_TYPE") == "VARCHAR(1000)"
        mapping = loader.get_mapping("CUSTOM_TYPE")
        assert mapping is not None
        assert mapping.category == TypeMappingCategory.CHARACTER
        assert mapping.notes is not None
        assert "Custom" in mapping.notes

    def test_custom_mappings_file_not_found(self):
        """Test that loader works when custom file doesn't exist."""
        # Should not raise, just log warning and use defaults
        loader = TypeMappingLoader(
            source_type=SourceType.SQLSERVER,
            custom_mappings_file="/nonexistent/path/mappings.yaml",
        )

        # Verify default mappings still work
        assert loader.get_snowflake_type("INT") == "NUMBER"

    def test_simple_format_auto_detection(self, tmp_path):
        """Test that simple format auto-detects category and LOB."""
        custom_file = tmp_path / "simple_mappings.yaml"
        custom_file.write_text(
            """
# Simple format should auto-detect everything
MYINT: NUMBER
MYVARCHAR: VARCHAR
MYTEXT: VARCHAR
MYBINARY: BINARY
"""
        )

        loader = TypeMappingLoader(
            source_type=SourceType.SQLSERVER, custom_mappings_file=custom_file
        )

        # Verify category auto-detection
        assert loader.get_category("MYINT") == TypeMappingCategory.NUMERIC
        assert loader.get_category("MYVARCHAR") == TypeMappingCategory.CHARACTER
        assert loader.get_category("MYBINARY") == TypeMappingCategory.BINARY

        # Verify LOB auto-detection (TEXT pattern)
        assert loader.is_lob_type("MYTEXT") is True
        assert loader.is_lob_type("MYVARCHAR") is False


class TestCopyIntoGeneration:
    """Tests for COPY INTO statement generation with type transformations."""

    def test_generate_copy_into_column_list_basic(self):
        """Test generating column list with basic type casting."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        columns = [
            ("id", "INT"),
            ("name", "VARCHAR"),
            ("created_at", "DATETIME2"),
        ]

        column_list = loader.generate_copy_into_column_list(columns)

        assert '$1:"id"' in column_list
        assert '$1:"name"' in column_list
        assert '$1:"created_at"' in column_list
        assert ",\n" in column_list

    def test_generate_copy_into_column_list_with_transformations(self):
        """Test generating column list with type transformations."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        columns = [
            ("is_active", "BIT"),
            ("amount", "DECIMAL"),
        ]

        file_schema = {
            "IS_ACTIVE": "BOOLEAN",
            "AMOUNT": "NUMBER",
        }

        column_list = loader.generate_copy_into_column_list(
            columns, parquet_schema=file_schema
        )

        assert 'TO_BOOLEAN($1:"is_active"::NUMBER)::BOOLEAN AS is_active' in column_list
        assert '$1:"amount"' in column_list

    def test_generate_copy_into_column_list_unmapped_type(self):
        """Test handling of unmapped types."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        columns = [
            ("id", "INT"),
            ("custom_col", "UNKNOWN_TYPE"),
        ]

        column_list = loader.generate_copy_into_column_list(columns)

        assert '$1:"id"' in column_list
        assert "$custom_col" in column_list

    def test_generate_copy_into_statement(self):
        """Test generating complete COPY INTO statement."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        columns = [
            ("id", "INT"),
            ("name", "VARCHAR"),
            ("amount", "MONEY"),
        ]

        statement = loader.generate_copy_into_statement(
            target_table="my_schema.my_table",
            columns=columns,
            stage_location="@my_stage/data/",
            file_type=FileType.PARQUET,
        )

        assert "COPY INTO my_schema.my_table" in statement
        assert '$1:"id"' in statement
        assert '$1:"name"' in statement
        assert '$1:"amount"' in statement

    def test_generate_copy_into_statement_custom_format(self):
        """Test COPY INTO with custom file format."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        columns = [("id", "INT"), ("data", "TEXT")]

        statement = loader.generate_copy_into_statement(
            target_table="logs",
            columns=columns,
            stage_location="@logs_stage/2024/",
            file_type=FileType.CSV,
        )

        assert "@logs_stage/2024/" in statement
        # TEXT -> VARCHAR is a text type; BCP empty-string sentinel should be handled
        assert "IFF($2 = CHR(0), '', $2)::VARCHAR" in statement

    def test_csv_copy_into_spatial_types(self):
        """CSV COPY INTO should use TO_GEOGRAPHY/TO_GEOMETRY like Parquet (not bare ::cast)."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        columns = [
            ("geo_col", "GEOGRAPHY"),
            ("geom_col", "GEOMETRY"),
        ]

        statement = loader.generate_copy_into_statement(
            target_table="spatial_table",
            columns=columns,
            stage_location="@stage/spatial/",
            file_type=FileType.CSV,
        )

        assert "TO_GEOGRAPHY($1::VARCHAR)" in statement
        assert "TO_GEOMETRY($2::VARCHAR)" in statement

    def test_copy_into_integration_workflow(self):
        """Test complete workflow: schema to COPY INTO statement."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        source_schema = [
            ("customer_id", "INT"),
            ("first_name", "NVARCHAR"),
            ("email", "VARCHAR"),
            ("signup_date", "DATE"),
            ("last_login", "DATETIME2"),
            ("is_premium", "BIT"),
            ("balance", "MONEY"),
        ]

        statement = loader.generate_copy_into_statement(
            target_table="customers",
            columns=source_schema,
            stage_location="@migration_stage/customers/",
        )

        assert '$1:"customer_id"' in statement
        assert '$1:"first_name"' in statement
        assert '$1:"email"' in statement
        assert '$1:"signup_date"' in statement
        assert '$1:"last_login"' in statement
        assert '$1:"is_premium"' in statement
        assert '$1:"balance"' in statement

        assert statement.startswith("COPY INTO customers")
        assert "FROM" in statement
        assert statement.endswith(")")

    def test_copy_into_with_lob_types(self):
        """Test COPY INTO generation with LOB types."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        columns = [
            ("id", "INT"),
            ("description", "TEXT"),
            ("image_data", "IMAGE"),
        ]

        statement = loader.generate_copy_into_statement(
            target_table="products",
            columns=columns,
            stage_location="@products_stage/",
        )

        assert '$1:"description"' in statement
        assert '$1:"image_data"' in statement

        assert loader.is_lob_type("TEXT") is True
        assert loader.is_lob_type("IMAGE") is True

    def test_bit_to_boolean_transformation(self):
        """Test BIT -> BOOLEAN transformation with TO_BOOLEAN conversion."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        columns = [
            ("is_active", "BIT"),
            ("id", "INT"),
        ]

        file_schema = {
            "IS_ACTIVE": "BOOLEAN",
            "ID": "NUMBER",
        }

        column_list = loader.generate_copy_into_column_list(
            columns=columns,
            parquet_schema=file_schema,
        )

        assert 'TO_BOOLEAN($1:"is_active"::NUMBER)::BOOLEAN AS is_active' in column_list
        assert '$1:"id"' in column_list

    def test_multiple_boolean_transformations(self):
        """Test multiple BIT columns with transformations."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        columns = [
            ("is_active", "BIT"),
            ("is_premium", "BIT"),
            ("is_verified", "BIT"),
        ]

        file_schema = {
            "IS_ACTIVE": "BOOLEAN",
            "IS_PREMIUM": "BOOLEAN",
            "IS_VERIFIED": "BOOLEAN",
        }

        statement = loader.generate_copy_into_statement(
            target_table="users",
            columns=columns,
            stage_location="@stage/users/",
            file_schema=file_schema,
        )

        assert 'TO_BOOLEAN($1:"is_active"::NUMBER)::BOOLEAN AS "is_active"' in statement
        assert (
            'TO_BOOLEAN($1:"is_premium"::NUMBER)::BOOLEAN AS "is_premium"' in statement
        )
        assert (
            'TO_BOOLEAN($1:"is_verified"::NUMBER)::BOOLEAN AS "is_verified"'
            in statement
        )

    def test_mixed_transformations(self):
        """Test mixed types with various transformations."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        columns = [
            ("id", "INT"),
            ("is_active", "BIT"),
            ("created_date", "DATE"),
            ("amount", "MONEY"),
        ]

        file_schema = {
            "ID": "NUMBER",
            "IS_ACTIVE": "BOOLEAN",
            "CREATED_DATE": "DATE",
            "AMOUNT": "NUMBER",
        }

        column_list = loader.generate_copy_into_column_list(
            columns=columns,
            parquet_schema=file_schema,
        )

        assert '$1:"id"' in column_list
        assert 'TO_BOOLEAN($1:"is_active"::NUMBER)::BOOLEAN AS is_active' in column_list
        assert '$1:"created_date"' in column_list
        assert '$1:"amount"' in column_list

    def test_transformation_without_parquet_schema(self):
        """Test that without parquet schema, no transformations are applied."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        columns = [
            ("is_active", "BIT"),
            ("id", "INT"),
        ]

        column_list = loader.generate_copy_into_column_list(columns=columns)

        assert '$1:"is_active"' in column_list
        assert '$1:"id"' in column_list
        assert "CASE WHEN" not in column_list

    def test_binary_types_always_have_explicit_cast(self):
        """
        Test that BINARY/VARBINARY types always get explicit cast in COPY INTO.

        This is necessary because Parquet stores binary data in a way that
        Snowflake needs an explicit cast to interpret correctly.
        """
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        # Test VARBINARY (common for IP addresses, etc.)
        columns = [
            ("IPAddress", "VARBINARY"),
            ("id", "INT"),
            ("name", "VARCHAR"),
        ]

        statement = loader.generate_copy_into_statement(
            target_table="test_table",
            columns=columns,
            stage_location="@my_stage/path/",
        )

        # VARBINARY should have explicit ::BINARY cast (key test!)
        assert '$1:"IPAddress"::BINARY AS "IPAddress"' in statement
        # INT -> NUMBER: without parquet_schema, from_type=to_type=NUMBER, so no cast
        # (this is fine for NUMBER types)
        assert '"id"' in statement
        # VARCHAR -> VARCHAR: same type, no cast needed
        assert '"name"' in statement

    def test_binary_type_explicit_cast(self):
        """Test that BINARY type gets explicit cast."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        columns = [
            ("data", "BINARY"),
            ("timestamp_col", "TIMESTAMP"),  # SQL Server TIMESTAMP is BINARY
        ]

        statement = loader.generate_copy_into_statement(
            target_table="test_table",
            columns=columns,
            stage_location="@my_stage/path/",
        )

        # Both should have explicit ::BINARY cast
        assert '$1:"data"::BINARY AS "data"' in statement
        assert '$1:"timestamp_col"::BINARY AS "timestamp_col"' in statement


class TestCsvBcpEmptyStringHandling:
    """
    Tests for BCP empty-string (NULL character (0x00)) handling in CSV COPY INTO.

    BCP exports empty strings as a single null-byte character (0x00) because
    empty strings represent NULL in SQL Server.  The CSV SELECT must convert
    that sentinel back to '' for text columns.
    """

    def test_csv_varchar_columns_handle_bcp_null_byte(self):
        """Text columns in CSV SELECT should use IFF to convert NULL character (0x00) to ''."""
        loader = TypeMappingLoader(source_type="sqlserver")

        columns = [
            ("name", "VARCHAR"),
            ("description", "NVARCHAR"),
            ("notes", "TEXT"),
            ("code", "CHAR"),
        ]

        statement = loader.generate_copy_into_statement(
            target_table="my_table",
            columns=columns,
            stage_location="@my_stage/data/",
            file_type=FileType.CSV,
        )

        assert "IFF($1 = CHR(0), '', $1)::VARCHAR" in statement  # VARCHAR
        assert "IFF($2 = CHR(0), '', $2)::VARCHAR" in statement  # NVARCHAR -> VARCHAR
        assert "IFF($3 = CHR(0), '', $3)::VARCHAR" in statement  # TEXT -> VARCHAR
        assert "IFF($4 = CHR(0), '', $4)::VARCHAR" in statement  # CHAR -> VARCHAR

    def test_csv_non_text_columns_unaffected(self):
        """Non-text columns should NOT have IFF/CHR(0) handling applied."""
        loader = TypeMappingLoader(source_type="sqlserver")

        columns = [
            ("id", "INT"),
            ("amount", "DECIMAL"),
            ("created_at", "DATETIME2"),
            ("is_active", "BIT"),
        ]

        statement = loader.generate_copy_into_statement(
            target_table="my_table",
            columns=columns,
            stage_location="@my_stage/data/",
            file_type=FileType.CSV,
        )

        assert "$1::NUMBER" in statement
        assert "$2::NUMBER" in statement
        assert "$3::TIMESTAMP_NTZ" in statement
        assert "TO_BOOLEAN($4::NUMBER)::BOOLEAN" in statement
        assert "CHR(0)" not in statement

    def test_csv_mixed_text_and_non_text(self):
        """Only text columns should get IFF; others should be plain casts."""
        loader = TypeMappingLoader(source_type="sqlserver")

        columns = [
            ("id", "INT"),
            ("name", "VARCHAR"),
            ("balance", "FLOAT"),
            ("email", "NVARCHAR"),
        ]

        statement = loader.generate_copy_into_statement(
            target_table="users",
            columns=columns,
            stage_location="@stage/users/",
            file_type=FileType.CSV,
        )

        assert "$1::NUMBER" in statement
        assert "IFF($2 = CHR(0), '', $2)::VARCHAR" in statement
        assert "$3::FLOAT" in statement
        assert "IFF($4 = CHR(0), '', $4)::VARCHAR" in statement

    def test_csv_text_with_column_name_mappings(self):
        """IFF handling should work together with column name mappings."""
        loader = TypeMappingLoader(source_type="sqlserver")

        columns = [
            ("name", "VARCHAR"),
            ("description", "NVARCHAR"),
        ]

        column_name_mappings = {"name": "full_name"}

        statement = loader.generate_copy_into_statement(
            target_table="items",
            columns=columns,
            stage_location="@stage/items/",
            column_name_mappings=column_name_mappings,
            file_type=FileType.CSV,
        )

        assert "IFF($1 = CHR(0), '', $1)::VARCHAR AS \"full_name\"" in statement
        assert "IFF($2 = CHR(0), '', $2)::VARCHAR AS \"description\"" in statement

    def test_csv_bcp_handling_does_not_affect_parquet(self):
        """Parquet COPY INTO should NOT use IFF/CHR(0) for text columns."""
        loader = TypeMappingLoader(source_type="sqlserver")

        columns = [
            ("name", "VARCHAR"),
            ("id", "INT"),
        ]

        statement = loader.generate_copy_into_statement(
            target_table="my_table",
            columns=columns,
            stage_location="@my_stage/data/",
            file_type=FileType.PARQUET,
        )

        assert "CHR(0)" not in statement
        assert '$1:"name"' in statement

    def test_get_csv_transformation_text_types_directly(self):
        """Unit-test get_csv_transformation for each text target type."""
        from data_migration_orchestrator.data_migration_cloud.utils.type_mapping_loader import (
            TypeTransformationEngine,
        )

        engine = TypeTransformationEngine()

        for text_type in ("VARCHAR", "STRING", "TEXT", "CHAR"):
            result = engine.get_csv_transformation(to_type=text_type, column_position=1)
            assert (
                result == f"IFF($1 = CHR(0), '', $1)::{text_type}"
            ), f"Expected IFF for {text_type}, got: {result}"


class TestTableTypeOverrides:
    """Tests for per-table type mapping overrides using with_table_overrides."""

    def test_with_table_overrides_basic(self):
        """Test applying overrides using dict format."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        # Default: BIT -> BOOLEAN
        assert loader.get_snowflake_type("BIT") == "BOOLEAN"

        # Apply override: BIT -> VARCHAR
        custom_loader = loader.with_table_overrides({"BIT": "VARCHAR"})

        # Override should be applied
        assert custom_loader.get_snowflake_type("BIT") == "VARCHAR"

        # Original loader should be unchanged
        assert loader.get_snowflake_type("BIT") == "BOOLEAN"

    def test_with_table_overrides_multiple(self):
        """Test applying multiple overrides."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        custom_loader = loader.with_table_overrides(
            {
                "BIT": "BOOLEAN",
                "MONEY": "DECIMAL(19,4)",
                "INT": "BIGINT",
            }
        )

        assert custom_loader.get_snowflake_type("BIT") == "BOOLEAN"
        assert custom_loader.get_snowflake_type("MONEY") == "DECIMAL(19,4)"
        assert custom_loader.get_snowflake_type("INT") == "BIGINT"

    def test_with_table_overrides_case_insensitive_keys(self):
        """Test that overrides are normalized to uppercase."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        custom_loader = loader.with_table_overrides({"bit": "boolean"})

        # Should be normalized to uppercase
        assert custom_loader.get_snowflake_type("BIT") == "BOOLEAN"
        assert custom_loader.get_snowflake_type("bit") == "BOOLEAN"

    def test_with_table_overrides_preserves_other_mappings(self):
        """Test that non-overridden types still work."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        custom_loader = loader.with_table_overrides({"BIT": "BOOLEAN"})

        # Non-overridden types should still work
        assert custom_loader.get_snowflake_type("VARCHAR") == "VARCHAR"
        assert custom_loader.get_snowflake_type("DATETIME") == "TIMESTAMP_NTZ"
        assert custom_loader.get_snowflake_type("BIGINT") == "NUMBER"

    def test_with_table_overrides_none_returns_self(self):
        """Test that None or empty dict returns original loader."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        # None
        same_loader = loader.with_table_overrides(None)
        assert same_loader is loader

        # Empty dict
        same_loader = loader.with_table_overrides({})
        assert same_loader is loader

    def test_with_table_overrides_copy_into_integration(self):
        """Test that overrides affect COPY INTO statement generation."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        custom_loader = loader.with_table_overrides({"BIT": "BOOLEAN"})

        columns = [
            ("is_active", "BIT"),
            ("id", "INT"),
        ]

        # Without parquet_schema, the target type is used directly
        statement = custom_loader.generate_copy_into_statement(
            target_table="test_table",
            columns=columns,
            stage_location="@my_stage/",
        )

        # BIT should map to BOOLEAN now
        assert "BOOLEAN" in statement or '"is_active"' in statement

    def test_with_table_overrides_category_detection(self):
        """Test that category is auto-detected for overrides."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        custom_loader = loader.with_table_overrides(
            {
                "CUSTOM_INT": "NUMBER",
                "CUSTOM_STR": "VARCHAR",
            }
        )

        # Categories should be detected from target type
        assert custom_loader.get_category("CUSTOM_INT") == TypeMappingCategory.NUMERIC
        assert custom_loader.get_category("CUSTOM_STR") == TypeMappingCategory.CHARACTER

    def test_with_table_overrides_chaining(self):
        """Test that overrides can be chained."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        loader2 = loader.with_table_overrides({"BIT": "BOOLEAN"})

        loader3 = loader2.with_table_overrides({"MONEY": "DECIMAL(19,4)"})

        # Both overrides should be present in loader3
        assert loader3.get_snowflake_type("BIT") == "BOOLEAN"
        assert loader3.get_snowflake_type("MONEY") == "DECIMAL(19,4)"

        # loader2 should only have BIT override
        assert loader2.get_snowflake_type("BIT") == "BOOLEAN"
        assert loader2.get_snowflake_type("MONEY") == "NUMBER(20, 10)"  # Default

    def test_with_table_overrides_dict_format(self):
        """Test applying overrides using dict format (source_type -> target_type)."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        # New simplified dict format
        overrides = {
            "BIT": "BOOLEAN",
            "MONEY": "DECIMAL(19,4)",
        }

        custom_loader = loader.with_table_overrides(overrides)

        assert custom_loader.get_snowflake_type("BIT") == "BOOLEAN"
        assert custom_loader.get_snowflake_type("MONEY") == "DECIMAL(19,4)"

    def test_with_table_overrides_case_insensitive(self):
        """Test that overrides are normalized to uppercase."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        overrides = {"bit": "boolean"}

        custom_loader = loader.with_table_overrides(overrides)

        # Should be normalized to uppercase
        assert custom_loader.get_snowflake_type("BIT") == "BOOLEAN"
        assert custom_loader.get_snowflake_type("bit") == "BOOLEAN"

    def test_with_table_overrides_bit_to_boolean_copy_into(self):
        """
        Test BIT -> BOOLEAN override generates correct COPY INTO with TO_BOOLEAN.

        SQL Server BIT values are stored as 0/1 in Parquet (NUMBER type).
        Direct cast to BOOLEAN fails, so we need TO_BOOLEAN() transformation.
        """
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        # Apply BIT -> BOOLEAN override
        custom_loader = loader.with_table_overrides({"BIT": "BOOLEAN"})

        columns = [
            ("EmployeeID", "INT"),
            ("IsActive", "BIT"),
        ]

        # Parquet schema shows NUMBER for BIT column (as stored by data exchange agent)
        # Keys are uppercase (normalized from INFER_SCHEMA results)
        file_schema = {
            "EMPLOYEEID": "NUMBER",
            "ISACTIVE": "NUMBER",  # BIT stored as NUMBER in Parquet
        }

        statement = custom_loader.generate_copy_into_statement(
            target_table="test_db.test_schema.Employees",
            columns=columns,
            stage_location="@my_stage/data/",
            file_schema=file_schema,
        )

        # Should use TO_BOOLEAN for NUMBER -> BOOLEAN conversion
        # The ::NUMBER cast is needed because $1:"col" returns VARIANT
        assert 'TO_BOOLEAN($1:"IsActive"::NUMBER)::BOOLEAN AS "IsActive"' in statement
        # Other columns should be normal
        assert '"EmployeeID"' in statement

    def test_with_table_overrides_bit_to_boolean_parquet_reports_boolean(self):
        """
        Test BIT -> BOOLEAN applies TO_BOOLEAN even when Parquet reports BOOLEAN.

        INFER_SCHEMA might report BOOLEAN for BIT columns, but the underlying
        data is still stored as 0/1 integers. We must always use TO_BOOLEAN
        for SQL Server BIT source types targeting BOOLEAN.
        """
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        # Apply BIT -> BOOLEAN override
        custom_loader = loader.with_table_overrides({"BIT": "BOOLEAN"})

        columns = [
            ("EmployeeID", "INT"),
            ("IsActive", "BIT"),
        ]

        # Parquet schema reports BOOLEAN (even though data might be 0/1 integers)
        file_schema = {
            "EMPLOYEEID": "NUMBER",
            "ISACTIVE": "BOOLEAN",  # INFER_SCHEMA might report this
        }

        statement = custom_loader.generate_copy_into_statement(
            target_table="test_db.test_schema.Employees",
            columns=columns,
            stage_location="@my_stage/data/",
            file_schema=file_schema,
        )

        # Should STILL use TO_BOOLEAN because source type is BIT
        # The ::NUMBER cast handles VARIANT -> NUMBER conversion
        assert 'TO_BOOLEAN($1:"IsActive"::NUMBER)::BOOLEAN AS "IsActive"' in statement
        # Other columns should be normal
        assert '"EmployeeID"' in statement


class TestColumnNameMappings:
    """Tests for column name mappings in COPY INTO statement generation."""

    def test_generate_copy_into_with_name_mappings(self):
        """Test COPY INTO generation with column name mappings."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        columns = [
            ("id", "INT"),
            ("name", "VARCHAR"),
            ("amount", "MONEY"),
        ]

        column_name_mappings = {
            "id": "old_id",
            "name": "full_name",
        }

        statement = loader.generate_copy_into_statement(
            target_table="my_schema.my_table",
            columns=columns,
            stage_location="@my_stage/data/",
            column_name_mappings=column_name_mappings,
        )

        # Source column names should be used for reading from Parquet
        assert '$1:"id"' in statement
        assert '$1:"name"' in statement
        assert '$1:"amount"' in statement

        # Target column names from mappings should be used in AS clause
        assert 'AS "old_id"' in statement
        assert 'AS "full_name"' in statement
        # Columns without mapping should use original name
        assert 'AS "amount"' in statement

        # Original names should NOT appear in AS clause for mapped columns
        assert 'AS "id"' not in statement
        assert 'AS "name"' not in statement

    def test_generate_copy_into_without_name_mappings(self):
        """Test COPY INTO generation without column name mappings uses original names."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        columns = [
            ("id", "INT"),
            ("name", "VARCHAR"),
        ]

        statement = loader.generate_copy_into_statement(
            target_table="my_schema.my_table",
            columns=columns,
            stage_location="@my_stage/data/",
            column_name_mappings=None,
        )

        # Both source and target names should be the same
        assert '$1:"id"' in statement
        assert 'AS "id"' in statement
        assert '$1:"name"' in statement
        assert 'AS "name"' in statement

    def test_generate_copy_into_with_empty_name_mappings(self):
        """Test COPY INTO generation with empty column name mappings dict."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        columns = [
            ("id", "INT"),
            ("name", "VARCHAR"),
        ]

        statement = loader.generate_copy_into_statement(
            target_table="my_schema.my_table",
            columns=columns,
            stage_location="@my_stage/data/",
            column_name_mappings={},
        )

        # Both source and target names should be the same
        assert 'AS "id"' in statement
        assert 'AS "name"' in statement

    def test_generate_copy_into_partial_name_mappings(self):
        """Test COPY INTO with mappings for only some columns."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        columns = [
            ("id", "INT"),
            ("first_name", "VARCHAR"),
            ("last_name", "VARCHAR"),
            ("email", "VARCHAR"),
        ]

        # Only map some columns
        column_name_mappings = {
            "first_name": "given_name",
        }

        statement = loader.generate_copy_into_statement(
            target_table="users",
            columns=columns,
            stage_location="@my_stage/data/",
            column_name_mappings=column_name_mappings,
        )

        # Mapped column should use target name
        assert 'AS "given_name"' in statement
        assert 'AS "first_name"' not in statement

        # Unmapped columns should use original names
        assert 'AS "id"' in statement
        assert 'AS "last_name"' in statement
        assert 'AS "email"' in statement

    def test_generate_copy_into_name_mappings_with_type_mappings(self):
        """Test COPY INTO with both column name and type mappings."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        columns = [
            ("id", "INT"),
            ("is_active", "BIT"),
            ("amount", "MONEY"),
        ]

        column_name_mappings = {
            "id": "legacy_id",
            "is_active": "active_flag",
        }

        # Provide file_schema to trigger type transformations
        file_schema = {
            "ID": "NUMBER",
            "IS_ACTIVE": "BOOLEAN",
            "AMOUNT": "NUMBER",
        }

        statement = loader.generate_copy_into_statement(
            target_table="my_table",
            columns=columns,
            stage_location="@my_stage/data/",
            column_name_mappings=column_name_mappings,
            file_schema=file_schema,
        )

        # Column names should be mapped
        assert 'AS "legacy_id"' in statement
        assert 'AS "active_flag"' in statement
        assert 'AS "amount"' in statement

        # Source columns should use original names from parquet
        assert '$1:"id"' in statement
        assert '$1:"is_active"' in statement
        assert '$1:"amount"' in statement


class TestTypeNormalization:
    """
    Tests for parameterized type normalization in transformations.

    Snowflake's INFER_SCHEMA returns types with parameters (e.g., "NUMBER(19,0)",
    "TIMESTAMP_NTZ(6)"). The transformation engine must normalize these to match
    the base types used in the transformation lookup table.
    """

    def test_normalize_base_type_with_parameters(self):
        """Test that types with parameters are normalized to base type."""
        from data_migration_orchestrator.data_migration_cloud.utils.type_mapping_loader import (
            _normalize_base_type,
        )

        assert _normalize_base_type("NUMBER(19,0)") == "NUMBER"
        assert _normalize_base_type("TIMESTAMP_NTZ(6)") == "TIMESTAMP_NTZ"
        assert _normalize_base_type("TIMESTAMP_NTZ(9)") == "TIMESTAMP_NTZ"
        assert _normalize_base_type("VARCHAR(16777216)") == "VARCHAR"

    def test_normalize_base_type_without_parameters(self):
        """Test that types without parameters are returned unchanged."""
        from data_migration_orchestrator.data_migration_cloud.utils.type_mapping_loader import (
            _normalize_base_type,
        )

        assert _normalize_base_type("NUMBER") == "NUMBER"
        assert _normalize_base_type("TIMESTAMP_NTZ") == "TIMESTAMP_NTZ"
        assert _normalize_base_type("VARCHAR") == "VARCHAR"
        assert _normalize_base_type("BOOLEAN") == "BOOLEAN"

    def test_timestamp_ntz_with_precision_matches_same_type(self):
        """Test that TIMESTAMP_NTZ(6) from INFER_SCHEMA matches TIMESTAMP_NTZ target."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        columns = [
            ("OrderDate", "DATETIME2"),
        ]

        # INFER_SCHEMA with USE_LOGICAL_TYPE=TRUE returns "TIMESTAMP_NTZ(6)"
        file_schema = {
            "ORDERDATE": "TIMESTAMP_NTZ(6)",
        }

        statement = loader.generate_copy_into_statement(
            target_table="test_table",
            columns=columns,
            stage_location="@my_stage/data/",
            file_schema=file_schema,
        )

        # TIMESTAMP_NTZ(6) should normalize to TIMESTAMP_NTZ, matching the target type.
        # Same-type match means no cast needed — just $1:"column_name".
        assert '$1:"OrderDate" AS "OrderDate"' in statement
        # Should NOT have an unnecessary ::TIMESTAMP_NTZ cast
        assert "::TIMESTAMP_NTZ" not in statement


class TestDatetime2Handling:
    """
    Tests for datetime2 column handling in the migration pipeline.

    SQL Server datetime2 columns are stored as INT64 epoch microseconds in Parquet
    by PyArrow. When Snowflake's USE_LOGICAL_TYPE is disabled, INFER_SCHEMA reports
    these as NUMBER instead of TIMESTAMP_NTZ, requiring special conversion.
    """

    def test_datetime2_with_number_file_schema_uses_to_timestamp(self):
        """
        Test that datetime2 columns reported as NUMBER use TO_TIMESTAMP_NTZ.

        When USE_LOGICAL_TYPE is disabled, INFER_SCHEMA returns NUMBER(19,0)
        for INT64 timestamp columns. A plain ::TIMESTAMP_NTZ cast would interpret
        microseconds as seconds, producing invalid dates.
        """
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        columns = [
            ("OrderID", "INT"),
            ("OrderDate", "DATETIME2"),
            ("CreatedAt", "DATETIME2"),
            ("UpdatedAt", "DATETIME2"),
        ]

        # Simulates INFER_SCHEMA output when USE_LOGICAL_TYPE = FALSE
        file_schema = {
            "ORDERID": "NUMBER(19,0)",
            "ORDERDATE": "NUMBER(19,0)",
            "CREATEDAT": "NUMBER(19,0)",
            "UPDATEDAT": "NUMBER(19,0)",
        }

        statement = loader.generate_copy_into_statement(
            target_table="test_db.test_schema.Orders",
            columns=columns,
            stage_location="@my_stage/data/",
            file_schema=file_schema,
        )

        # datetime2 columns should use TO_TIMESTAMP_NTZ with scale 6 (microseconds)
        assert (
            'TO_TIMESTAMP_NTZ($1:"OrderDate"::NUMBER, 6)::TIMESTAMP_NTZ AS "OrderDate"'
            in statement
        )
        assert (
            'TO_TIMESTAMP_NTZ($1:"CreatedAt"::NUMBER, 6)::TIMESTAMP_NTZ AS "CreatedAt"'
            in statement
        )
        assert (
            'TO_TIMESTAMP_NTZ($1:"UpdatedAt"::NUMBER, 6)::TIMESTAMP_NTZ AS "UpdatedAt"'
            in statement
        )

        # INT column should NOT get timestamp treatment
        assert "TO_TIMESTAMP_NTZ" not in statement.split("OrderID")[0]

    def test_datetime_with_number_file_schema_uses_to_timestamp(self):
        """Test that DATETIME source type also gets defensive timestamp conversion."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        columns = [
            ("created", "DATETIME"),
        ]

        file_schema = {
            "CREATED": "NUMBER(19,0)",
        }

        statement = loader.generate_copy_into_statement(
            target_table="test_table",
            columns=columns,
            stage_location="@my_stage/data/",
            file_schema=file_schema,
        )

        assert 'TO_TIMESTAMP_NTZ($1:"created"::NUMBER, 6)::TIMESTAMP_NTZ' in statement

    def test_datetimeoffset_with_number_file_schema_uses_to_timestamp_tz(self):
        """Test that DATETIMEOFFSET source type uses TO_TIMESTAMP_TZ."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        columns = [
            ("event_time", "DATETIMEOFFSET"),
        ]

        file_schema = {
            "EVENT_TIME": "NUMBER(19,0)",
        }

        statement = loader.generate_copy_into_statement(
            target_table="test_table",
            columns=columns,
            stage_location="@my_stage/data/",
            file_schema=file_schema,
        )

        assert 'TO_TIMESTAMP_TZ($1:"event_time"::NUMBER, 6)::TIMESTAMP_TZ' in statement

    def test_number_to_timestamp_not_applied_for_non_datetime_source(self):
        """
        Test that NUMBER → TIMESTAMP_NTZ conversion is NOT applied for non-datetime sources.

        If a source INT column is custom-mapped to TIMESTAMP_NTZ, the defensive
        conversion should not apply (the user likely intends epoch seconds).
        """
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        # Custom override: map INT to TIMESTAMP_NTZ
        custom_loader = loader.with_table_overrides({"INT": "TIMESTAMP_NTZ"})

        columns = [
            ("epoch_col", "INT"),
        ]

        file_schema = {
            "EPOCH_COL": "NUMBER(19,0)",
        }

        statement = custom_loader.generate_copy_into_statement(
            target_table="test_table",
            columns=columns,
            stage_location="@my_stage/data/",
            file_schema=file_schema,
        )

        # Should NOT use TO_TIMESTAMP_NTZ (source is INT, not a datetime type)
        assert "TO_TIMESTAMP_NTZ" not in statement
        # Should use default cast
        assert "::TIMESTAMP_NTZ" in statement

    def test_datetime2_with_correct_file_schema_no_transformation(self):
        """
        Test that datetime2 columns with correct TIMESTAMP_NTZ schema need no transformation.

        When USE_LOGICAL_TYPE is enabled (the fix), INFER_SCHEMA returns
        TIMESTAMP_NTZ for timestamp columns, so no special handling is needed.
        """
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        columns = [
            ("OrderDate", "DATETIME2"),
            ("CreatedAt", "DATETIME2"),
        ]

        # Simulates INFER_SCHEMA output when USE_LOGICAL_TYPE = TRUE
        file_schema = {
            "ORDERDATE": "TIMESTAMP_NTZ",
            "CREATEDAT": "TIMESTAMP_NTZ",
        }

        statement = loader.generate_copy_into_statement(
            target_table="test_table",
            columns=columns,
            stage_location="@my_stage/data/",
            file_schema=file_schema,
        )

        # Same type match: no cast needed
        assert '$1:"OrderDate" AS "OrderDate"' in statement
        assert '$1:"CreatedAt" AS "CreatedAt"' in statement
        assert "TO_TIMESTAMP_NTZ" not in statement

    def test_full_orders_table_migration(self):
        """
        End-to-end test simulating the Orders table from the bug report.

        Verifies correct COPY INTO generation for a table with multiple
        datetime2 precisions and bit columns, with USE_LOGICAL_TYPE disabled.
        """
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        # Override BIT -> BOOLEAN as the user's output suggests
        custom_loader = loader.with_table_overrides({"BIT": "BOOLEAN"})

        columns = [
            ("OrderID", "INT"),
            ("OrderDate", "DATETIME2"),
            ("CreatedAt", "DATETIME2"),
            ("UpdatedAt", "DATETIME2"),
            ("IsActive", "BIT"),
            ("IsProcessed", "BIT"),
        ]

        # Simulates INFER_SCHEMA when USE_LOGICAL_TYPE = FALSE
        file_schema = {
            "ORDERID": "NUMBER(10,0)",
            "ORDERDATE": "NUMBER(19,0)",
            "CREATEDAT": "NUMBER(19,0)",
            "UPDATEDAT": "NUMBER(19,0)",
            "ISACTIVE": "BOOLEAN",
            "ISPROCESSED": "BOOLEAN",
        }

        statement = custom_loader.generate_copy_into_statement(
            target_table="test_db.data_migration_cloud_test.Orders",
            columns=columns,
            stage_location="@my_stage/data/",
            file_schema=file_schema,
        )

        # All datetime2 columns should use TO_TIMESTAMP_NTZ with scale 6
        assert 'TO_TIMESTAMP_NTZ($1:"OrderDate"::NUMBER, 6)::TIMESTAMP_NTZ' in statement
        assert 'TO_TIMESTAMP_NTZ($1:"CreatedAt"::NUMBER, 6)::TIMESTAMP_NTZ' in statement
        assert 'TO_TIMESTAMP_NTZ($1:"UpdatedAt"::NUMBER, 6)::TIMESTAMP_NTZ' in statement

        # BIT columns should use TO_BOOLEAN
        assert 'TO_BOOLEAN($1:"IsActive"::NUMBER)::BOOLEAN' in statement
        assert 'TO_BOOLEAN($1:"IsProcessed"::NUMBER)::BOOLEAN' in statement

        # INT column should be straightforward
        assert '"OrderID"' in statement


class TestTargetTypesOverride:
    """
    Tests for COPY INTO generation using actual target table types (target_types).

    When a table already exists with specific types like CHAR(25) or NUMBER(10,2),
    the COPY INTO casts should use those exact types, not generic mapped types.
    """

    def test_char_with_length_from_target_types(self):
        """Test that CHAR(25) from target schema is used in cast instead of VARCHAR."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        columns = [
            ("n_nationkey", "INT"),
            ("n_name", "CHAR"),
            ("n_regionkey", "INT"),
            ("n_comment", "VARCHAR"),
        ]

        target_types = {
            "N_NATIONKEY": "NUMBER(38,0)",
            "N_NAME": "CHAR(25)",
            "N_REGIONKEY": "NUMBER(38,0)",
            "N_COMMENT": "VARCHAR(152)",
        }

        statement = loader.generate_copy_into_statement(
            target_table="DATA_MIGRATION_TEST.tpch_10gb.nation",
            columns=columns,
            stage_location=f"@{qualified_migration_schema()}.STAGE/data/",
            target_types=target_types,
        )

        assert '$1:"n_name"::CHAR(25) AS "n_name"' in statement
        assert '$1:"n_comment"::VARCHAR(152) AS "n_comment"' in statement

    def test_number_with_precision_from_target_types(self):
        """Test NUMBER(10,2) from target schema is preserved in cast."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        columns = [
            ("amount", "DECIMAL"),
            ("quantity", "INT"),
        ]

        target_types = {
            "AMOUNT": "NUMBER(10,2)",
            "QUANTITY": "NUMBER(38,0)",
        }

        file_schema = {
            "AMOUNT": "NUMBER(10,2)",
            "QUANTITY": "NUMBER(10,0)",
        }

        statement = loader.generate_copy_into_statement(
            target_table="test_table",
            columns=columns,
            stage_location="@stage/data/",
            file_schema=file_schema,
            target_types=target_types,
        )

        assert '$1:"amount"::NUMBER(10,2) AS "amount"' in statement
        assert '$1:"quantity"::NUMBER(38,0) AS "quantity"' in statement

    def test_target_types_with_type_transformation(self):
        """Test target_types with type transformations (e.g., BOOLEAN -> VARCHAR cast)."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        columns = [
            ("is_active", "BIT"),
        ]

        file_schema = {
            "IS_ACTIVE": "BOOLEAN",
        }

        target_types = {
            "IS_ACTIVE": "BOOLEAN",
        }

        statement = loader.generate_copy_into_statement(
            target_table="test_table",
            columns=columns,
            stage_location="@stage/data/",
            file_schema=file_schema,
            target_types=target_types,
        )

        assert 'TO_BOOLEAN($1:"is_active"::NUMBER)::BOOLEAN' in statement

    def test_target_types_with_different_from_and_to(self):
        """Test when parquet type differs from target type with parameters."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        columns = [
            ("description", "NVARCHAR"),
        ]

        file_schema = {
            "DESCRIPTION": "TEXT",
        }

        target_types = {
            "DESCRIPTION": "VARCHAR(500)",
        }

        statement = loader.generate_copy_into_statement(
            target_table="test_table",
            columns=columns,
            stage_location="@stage/data/",
            file_schema=file_schema,
            target_types=target_types,
        )

        assert '::VARCHAR(500) AS "description"' in statement

    def test_target_types_none_falls_back_to_mapping(self):
        """Test that without target_types, generic mapped types are used."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        columns = [
            ("n_name", "CHAR"),
        ]

        statement_without = loader.generate_copy_into_statement(
            target_table="test_table",
            columns=columns,
            stage_location="@stage/data/",
            target_types=None,
        )

        # CHAR maps to VARCHAR generically, same-type match = no cast
        assert '$1:"n_name" AS "n_name"' in statement_without

        # With target_types, CHAR(25) is used
        statement_with = loader.generate_copy_into_statement(
            target_table="test_table",
            columns=columns,
            stage_location="@stage/data/",
            target_types={"N_NAME": "CHAR(25)"},
        )

        assert '$1:"n_name"::CHAR(25) AS "n_name"' in statement_with

    def test_target_types_csv(self):
        """Test target_types works for CSV file format too."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        columns = [
            ("name", "CHAR"),
            ("amount", "DECIMAL"),
        ]

        target_types = {
            "NAME": "CHAR(25)",
            "AMOUNT": "NUMBER(10,2)",
        }

        statement = loader.generate_copy_into_statement(
            target_table="test_table",
            columns=columns,
            stage_location="@stage/data/",
            file_type=FileType.CSV,
            target_types=target_types,
        )

        assert "IFF($1 = CHR(0), '', $1)::CHAR(25)" in statement
        assert "$2::NUMBER(10,2)" in statement

    def test_target_types_column_list(self):
        """Test target_types with generate_copy_into_column_list."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        columns = [
            ("n_name", "CHAR"),
            ("n_comment", "VARCHAR"),
        ]

        target_types = {
            "N_NAME": "CHAR(25)",
            "N_COMMENT": "VARCHAR(152)",
        }

        column_list = loader.generate_copy_into_column_list(
            columns=columns,
            target_types=target_types,
        )

        assert '$1:"n_name"::CHAR(25) AS n_name' in column_list
        assert '$1:"n_comment"::VARCHAR(152) AS n_comment' in column_list

    def test_target_types_with_column_name_mappings(self):
        """Test target_types works correctly with column name mappings."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        columns = [
            ("name", "CHAR"),
        ]

        target_types = {
            "NAME": "CHAR(25)",
        }

        column_name_mappings = {
            "name": "full_name",
        }

        statement = loader.generate_copy_into_statement(
            target_table="test_table",
            columns=columns,
            stage_location="@stage/data/",
            target_types=target_types,
            column_name_mappings=column_name_mappings,
        )

        assert '$1:"name"::CHAR(25) AS "full_name"' in statement

    def test_full_nation_table_with_target_types(self):
        """
        End-to-end test reproducing the nation table bug.

        When the DDL creates CHAR(25) and VARCHAR(152), the COPY INTO should
        cast to those exact types, not to generic CHAR or VARCHAR.
        """
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        columns = [
            ("n_nationkey", "INT"),
            ("n_name", "CHAR"),
            ("n_regionkey", "INT"),
            ("n_comment", "VARCHAR"),
        ]

        target_types = {
            "N_NATIONKEY": "NUMBER(38,0)",
            "N_NAME": "CHAR(25)",
            "N_REGIONKEY": "NUMBER(38,0)",
            "N_COMMENT": "VARCHAR(152)",
        }

        statement = loader.generate_copy_into_statement(
            target_table="DATA_MIGRATION_TEST.tpch_10gb.nation",
            columns=columns,
            stage_location=(
                f"@{qualified_migration_schema()}."
                "MIGRATIONS_WG_FDE_DEV_PARQUET_STAGE"
                "/task_results/workflows/103/tables/3/data/full_table/"
            ),
            target_types=target_types,
        )

        assert "COPY INTO DATA_MIGRATION_TEST.tpch_10gb.nation" in statement
        assert '$1:"n_name"::CHAR(25) AS "n_name"' in statement
        assert '$1:"n_comment"::VARCHAR(152) AS "n_comment"' in statement

    def test_get_transformation_preserves_type_params(self):
        """Test TypeTransformationEngine preserves type parameters in casts."""
        from data_migration_orchestrator.data_migration_cloud.utils.type_mapping_loader import (
            TypeTransformationEngine,
        )

        engine = TypeTransformationEngine()

        # Different base types: NUMBER -> VARCHAR(152) should cast to VARCHAR(152)
        result = engine.get_transformation(
            from_type="NUMBER",
            to_type="VARCHAR(152)",
            column_name="col",
        )
        assert "::VARCHAR(152)" in result

        # Same base types with params: VARCHAR -> CHAR(25)
        result = engine.get_transformation(
            from_type="TEXT",
            to_type="CHAR(25)",
            column_name="col",
        )
        assert "::CHAR(25)" in result

    def test_timetz_to_timestamp_tz_preserves_timezone(self):
        """TIMETZ exported as VARCHAR is converted via epoch microseconds (same pattern as SQL Server)."""
        from data_migration_orchestrator.data_migration_cloud.utils.type_mapping_loader import (
            TypeTransformationEngine,
        )

        engine = TypeTransformationEngine()
        result = engine.get_transformation(
            from_type="VARCHAR",
            to_type="TIMESTAMP_TZ",
            column_name="col_timetz",
            source_type="TIMETZ",
        )
        assert "TO_TIMESTAMP_TZ" in result
        # Epoch-based conversion: TO_TIMESTAMP_TZ(epoch_us, 6) like SQL Server DATETIMEOFFSET
        assert ", 6)" in result
        assert "::TIMESTAMP_TZ" in result
        assert 'col_timetz"::VARCHAR' in result
        # Normalize Redshift "HH:MI:SS:FF" (colon) to "HH:MI:SS.FF" (period) for TO_TIME
        assert "REGEXP_REPLACE" in result
        assert "HH24:MI:SS.FF" in result

    def test_target_types_partial_override(self):
        """Test when target_types only has some columns - others use mapping."""
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        columns = [
            ("name", "CHAR"),
            ("id", "INT"),
        ]

        target_types = {
            "NAME": "CHAR(25)",
        }

        statement = loader.generate_copy_into_statement(
            target_table="test_table",
            columns=columns,
            stage_location="@stage/data/",
            target_types=target_types,
        )

        assert '$1:"name"::CHAR(25) AS "name"' in statement
        assert '$1:"id" AS "id"' in statement

    def test_target_types_overrides_mapping_when_disagreeing(self):
        """
        Test that target_types wins when it disagrees with the source-to-Snowflake mapping.

        The existing target table is the source of truth. If the DDL was created
        externally (e.g., by SnowConvert) with a type that differs from the default
        mapping, the COPY INTO should cast to the actual table type, not the mapped one.

        Example: source INT normally maps to NUMBER, but the actual table column
        is VARCHAR(100). The cast should use VARCHAR(100).
        """
        loader = TypeMappingLoader(source_type=SourceType.SQLSERVER)

        # INT normally maps to NUMBER
        assert loader.get_snowflake_type("INT") == "NUMBER"

        columns = [
            ("code", "INT"),
        ]

        # But the actual table has VARCHAR(100) for this column
        target_types = {
            "CODE": "VARCHAR(100)",
        }

        statement = loader.generate_copy_into_statement(
            target_table="test_table",
            columns=columns,
            stage_location="@stage/data/",
            target_types=target_types,
        )

        # Target table type wins over the generic mapping.
        # NUMBER -> VARCHAR triggers the TO_VARCHAR transformation, and the
        # final cast uses the full target type VARCHAR(100).
        assert 'TO_VARCHAR($1:"code")::VARCHAR(100) AS "code"' in statement
