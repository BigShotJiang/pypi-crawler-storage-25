"""Focused tests for DataMigrationWorkflowInitializer (non-Iceberg routing)."""

import unittest
from unittest.mock import AsyncMock, MagicMock

from data_migration_orchestrator.cloud_core.workflows.workflow import Workflow
from data_migration_orchestrator.cloud_core.workflows.workflow_status import (
    WorkflowStatus,
)
from data_migration_orchestrator.data_migration_cloud.config.configuration_parser import (
    ConfigurationError,
)
from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    DEFAULT_TARGET_TABLE_TYPE,
    ExtractionConfig,
    IcebergTargetConfig,
    PartitionSizeConfig,
    SynchronizationConfig,
    TableConfiguration,
    TableIdentifier,
)
from data_migration_orchestrator.data_migration_cloud.data_migration_workflow_initializer import (
    DataMigrationWorkflowInitializer,
)
from data_migration_orchestrator.data_migration_cloud.platforms.platform_registry import (
    PlatformRegistry,
)
from shared.enums.source_type import SourceType


def _workflow_for_dm_init() -> Workflow:
    return Workflow(
        id=1,
        name="test-workflow",
        source_platform=SourceType.SQLSERVER,
        target_cloud_type="snowflake:stage",
        target_cloud_stage_name="MY_STAGE",
        target_cloud_url=None,
        schema_version="1",
        workflow_type="data-migration",
        initiator_id="test-initiator",
        status=WorkflowStatus.INITIALIZING,
        configuration={"tables": [{"source": {"tableName": "T"}}]},
        initialization_failures=0,
    )


def _native_table_config() -> TableConfiguration:
    return TableConfiguration(
        source=TableIdentifier(
            database_name="src_db",
            schema_name="src_schema",
            table_name="my_table",
        ),
        target=TableIdentifier(
            database_name="tgt_db",
            schema_name="tgt_schema",
            table_name="my_table",
        ),
        partition_columns=[],
        column_type_mappings={},
        column_name_mappings={},
        primary_key_columns=[],
        synchronization=SynchronizationConfig(),
        extraction=ExtractionConfig(),
        partition_size=PartitionSizeConfig(),
        where_clause_criteria=None,
        target_table_type=DEFAULT_TARGET_TABLE_TYPE,
        iceberg_config=None,
    )


class TestCreateInitialTasksConfigurationError(unittest.IsolatedAsyncioTestCase):
    """``create_initial_tasks`` when table parsing raises ``ConfigurationError``."""

    async def test_propagates_configuration_error_from_parse_tables(self):
        init = DataMigrationWorkflowInitializer(
            task_queue=MagicMock(),
            warehouse_proxy=MagicMock(),
        )
        init.configuration_parser = MagicMock()
        init.configuration_parser.parse_tables = MagicMock(
            side_effect=ConfigurationError("bad table config")
        )
        wf = _workflow_for_dm_init()
        with self.assertRaises(ConfigurationError) as ctx:
            await init.create_initial_tasks(wf)
        self.assertIn("bad table config", str(ctx.exception))


class TestExistingPartitionsFallback(unittest.IsolatedAsyncioTestCase):
    """Incremental path when copying existing partition metadata fails."""

    async def test_copy_failure_falls_back_to_new_partitions(self):
        init = DataMigrationWorkflowInitializer(
            task_queue=MagicMock(),
            warehouse_proxy=MagicMock(),
        )
        init.partition_reuse_service = MagicMock()
        init.partition_reuse_service.copy_table_and_partitions = AsyncMock(
            return_value=None
        )
        init._insert_table_metadata = AsyncMock(return_value=55)
        init._batch_create_tasks_with_new_partitions = AsyncMock()

        platform = PlatformRegistry.create_by_name_or_alias(SourceType.SQLSERVER)
        table_config = _native_table_config()
        fq = platform.build_normalized_table_name(table_config.source)

        await init._create_tasks_with_existing_partitions(
            workflow_id=42,
            table_config=table_config,
            platform=platform,
            target_cloud_type="snowflake:stage",
            existing_table_metadata_id=99,
        )

        init._batch_create_tasks_with_new_partitions.assert_awaited_once_with(
            42,
            [table_config],
            platform.name,
            "snowflake:stage",
            {fq: 55},
        )


class TestCreateInitialTasksBulk(unittest.IsolatedAsyncioTestCase):
    """``create_initial_tasks`` uses bulk metadata SQL and batched task pushes."""

    async def test_two_new_tables_bulk_metadata_and_two_push_tasks_batch(self):
        task_queue = MagicMock()
        task_queue.push_tasks_batch = AsyncMock(
            side_effect=[[201, 202], [301, 302, 303, 304]]
        )
        task_queue.push_independent_two_task_chains = AsyncMock()

        warehouse = MagicMock()
        warehouse.execute_sync_query = AsyncMock(
            side_effect=[
                None,
                [
                    {"ID": 1, "SOURCE_IDENTIFIER": "SRC_DB.SRC_SCHEMA.MY_TABLE"},
                    {"ID": 2, "SOURCE_IDENTIFIER": "SRC_DB.SRC_SCHEMA.OTHER_TABLE"},
                ],
            ]
        )

        init = DataMigrationWorkflowInitializer(
            task_queue=task_queue,
            warehouse_proxy=warehouse,
        )
        init.partition_reuse_service.find_existing_table_metadata = AsyncMock(
            return_value=None
        )

        src = {
            "databaseName": "src_db",
            "schemaName": "src_schema",
            "tableName": "my_table",
        }
        src2 = {
            "databaseName": "src_db",
            "schemaName": "src_schema",
            "tableName": "other_table",
        }
        tgt = {
            "databaseName": "tgt_db",
            "schemaName": "tgt_schema",
            "tableName": "my_table",
        }
        tgt2 = {
            "databaseName": "tgt_db",
            "schemaName": "tgt_schema",
            "tableName": "other_table",
        }
        wf = Workflow(
            id=1,
            name="test-workflow",
            source_platform=SourceType.SQLSERVER,
            target_cloud_type="snowflake:stage",
            target_cloud_stage_name="MY_STAGE",
            target_cloud_url=None,
            schema_version="1",
            workflow_type="data-migration",
            initiator_id="test-initiator",
            status=WorkflowStatus.INITIALIZING,
            configuration={
                "tables": [
                    {"source": src, "target": tgt},
                    {"source": src2, "target": tgt2},
                ]
            },
            initialization_failures=0,
        )

        await init.create_initial_tasks(wf)

        self.assertEqual(warehouse.execute_sync_query.call_count, 2)
        self.assertEqual(task_queue.push_tasks_batch.call_count, 2)
        task_queue.push_independent_two_task_chains.assert_not_awaited()


class TestBuildCatalogLinkDdl(unittest.TestCase):
    """Static DDL builder for Iceberg catalog-link strategy."""

    def test_without_external_volume(self):
        cfg = IcebergTargetConfig(catalog="MY_CATALOG", external_volume=None)
        ddl = DataMigrationWorkflowInitializer._build_catalog_link_ddl(
            "DB.SCHEMA.TGT",
            cfg,
            "cat_tbl",
        )
        self.assertIn("CREATE OR REPLACE ICEBERG TABLE DB.SCHEMA.TGT", ddl)
        self.assertIn("CATALOG = 'MY_CATALOG'", ddl)
        self.assertIn("CATALOG_TABLE_NAME = 'cat_tbl'", ddl)
        self.assertNotIn("EXTERNAL_VOLUME", ddl)

    def test_with_external_volume(self):
        cfg = IcebergTargetConfig(catalog="MY_CATALOG", external_volume="EVOL")
        ddl = DataMigrationWorkflowInitializer._build_catalog_link_ddl(
            "DB.SCHEMA.TGT",
            cfg,
            "cat_tbl",
        )
        self.assertIn("EXTERNAL_VOLUME = 'EVOL'", ddl)
