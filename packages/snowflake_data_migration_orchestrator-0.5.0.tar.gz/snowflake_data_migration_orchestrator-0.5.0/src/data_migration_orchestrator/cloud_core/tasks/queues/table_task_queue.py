import dataclasses
import json
import threading

from collections.abc import Callable
from json import dumps as serialize_to_json
from typing import Any, ClassVar, Generic, Protocol, TypeVar

from snowflake.connector import DictCursor, SnowflakeConnection
from snowflake.connector import Error as SnowflakeError
from snowflake.connector.constants import QueryStatus

import data_migration_orchestrator.cloud_core.workflows.workflow_columns as workflow_columns

from data_migration_orchestrator.cloud_core.constants.priorities import DEFAULT_PRIORITY
from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_core.stored_procedure_calls import (
    complete_task_call_template,
    fail_task_call_template,
    has_workflow_started_call_template,
    pull_tasks_call_template,
    push_task_call_template,
)
from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.queues.base_task_queue import (
    BaseTaskQueue,
)
from data_migration_orchestrator.cloud_core.tasks.snowflake_query_task import (
    SnowflakeQueryTaskPayload,
)
from data_migration_orchestrator.cloud_core.tasks.task import Task
from data_migration_orchestrator.cloud_core.tasks.task_status import TaskStatus
from data_migration_orchestrator.cloud_core.workflows.stored_procedures_calls import (
    complete_workflows_call_template,
    delete_workflow_tasks_call_template,
    expire_stale_initializations_call_template,
    get_pending_workflows_call_template,
)
from data_migration_orchestrator.cloud_core.workflows.workflow import Workflow
from data_migration_orchestrator.cloud_core.workflows.workflow_status import (
    WorkflowStatus,
)
from data_migration_orchestrator.utils.snowflake_metadata import (
    qualified_migration_schema,
)
from shared.enums.source_type import SourceType


logger = get_logger("tasks.queues.table_task_queue")


class DataclassProtocol(Protocol):
    """Protocol for dataclass instances (required for dataclasses.asdict)."""

    __dataclass_fields__: ClassVar[dict[str, Any]]


TPayload = TypeVar("TPayload", bound=DataclassProtocol)


class TableTaskQueue(BaseTaskQueue[TPayload], Generic[TPayload]):
    """Concrete implementation of a task queue that works with a Snowflake table under the hood."""

    MAX_INITIALIZATION_FAILURES = 3

    max_tasks_to_pull: int = 1000

    def __init__(
        self,
        connection: SnowflakeConnection,
        payload_mapper: Callable[[str, dict], TPayload],
        affinity: str | None = None,
    ) -> None:
        """
        Initialize the TableTaskQueue with a Snowflake connection.

        Args:
            connection: The Snowflake database connection to use for task operations.
            payload_mapper: A callable to map payload data to the appropriate type.
            affinity: The affinity group for this task queue. Will determine which workflows and tasks are picked up.

        """
        super().__init__(payload_mapper)
        self.affinity = affinity
        self.workflow_affinity_by_id: dict[int, str | None] = dict()
        self._pending_warehouse_tasks: dict[int, str] = {}
        self._warehouse_tasks_loaded: bool = False
        self._lock = threading.RLock()
        self._thread_local = threading.local()
        self._thread_local.connection = connection

    @property
    def connection(self) -> SnowflakeConnection:
        """Return the Snowflake connection for the current thread."""
        return self._thread_local.connection

    def register_thread_connection(self, connection: SnowflakeConnection) -> None:
        """Register a per-thread Snowflake connection for the calling thread."""
        self._thread_local.connection = connection

    async def _execute_statement(self, statement: str) -> None:
        with self.connection.cursor() as cursor:
            cursor.execute(statement)

    async def _push_task_internal(
        self,
        workflow_id: int,
        executor_type: ExecutorType,
        task_name: str,
        payload: TPayload,
        scope: str,
        priority: float = DEFAULT_PRIORITY,
        successor_task_id: int | None = None,
        is_blocked: bool = False,
    ) -> int | None:
        """
        Push a task into the task queue.

        Args:
            workflow_id: The ID of the workflow to which the task belongs.
            executor_type: The type of executor that should process the task.
            task_name: The name of the task.
            payload: The payload containing task data and metadata.
            scope: The hierarchical scope describing the task's purpose (e.g., 'Table[DB.SCHEMA.TABLE]::Preprocessing').
            priority: The priority of the task (default is 3).
            successor_task_id: The ID of the successor task, if any.
            is_blocked: Whether the task is initially blocked (default is False).

        Returns:
            The ID of the newly created task, or None if creation failed.

        """
        cursor = self.connection.cursor()
        payload_json_string = serialize_to_json(
            dataclasses.asdict(payload), default=str
        )
        affinity = await self.get_workflow_affinity(workflow_id) or None
        cursor.execute(
            push_task_call_template(),
            (
                workflow_id,
                executor_type.value,
                task_name,
                priority,
                successor_task_id,
                is_blocked,
                affinity,
                scope,
                payload_json_string,
            ),
        )
        row = cursor.fetchone()
        task_id: int | None = row[0] if row else None

        if (
            task_id is not None
            and executor_type == ExecutorType.WAREHOUSE
            and isinstance(payload, SnowflakeQueryTaskPayload)
            and payload.query_id
        ):
            with self._lock:
                self._pending_warehouse_tasks[task_id] = payload.query_id

        return task_id

    async def push_tasks_batch(
        self,
        tasks: list[Task[TPayload]],
    ) -> list[int]:
        """
        Push multiple tasks in a single INSERT statement, bypassing the stored procedure.

        Returns task IDs in the same order as the input list, matched by scope.
        """
        if not tasks:
            return []

        first_task = tasks[0]
        affinity = await self.get_workflow_affinity(first_task.workflow_id)

        value_rows: list[str] = []
        for task in tasks:
            payload_json = (
                serialize_to_json(dataclasses.asdict(task.payload), default=str)
                .replace("\\", "\\\\")
                .replace("'", "''")
            )
            successor = (
                str(task.successor_task_id)
                if task.successor_task_id is not None
                else "NULL"
            )
            status = "blocked" if task.is_blocked else "pending"
            escaped_name = task.task_name.replace("'", "''")
            escaped_scope = task.scope.replace("'", "''") if task.scope else ""
            affinity_sql = f"'{affinity}'" if affinity else "NULL"

            value_rows.append(
                f"({task.workflow_id}, '{escaped_name}', '{task.executor_type.value}', "
                f"{task.priority}, {affinity_sql}, '{escaped_scope}', "
                f"'{payload_json}', {successor}, '{status}')"
            )

        qm = qualified_migration_schema()
        insert_sql = (
            f"INSERT INTO {qm}.TASK_QUEUE "
            "(ID, WORKFLOW_ID, NAME, EXECUTOR_TYPE, PRIORITY, AFFINITY, SCOPE, PAYLOAD, SUCCESSOR_TASK_ID, STATUS) "
            f"SELECT {qm}.TASK_ID_SEQUENCE.NEXTVAL, "
            "column1, column2, column3, column4, column5, column6, "
            "PARSE_JSON(column7), column8, column9 "
            f"FROM VALUES {', '.join(value_rows)}"
        )

        with self.connection.cursor() as cursor:
            cursor.execute(insert_sql)

        # Query back IDs keyed by scope (scope is unique per task within a workflow)
        workflow_id = first_task.workflow_id
        scopes = [t.scope.replace("'", "''") for t in tasks]
        scope_list_sql = ", ".join(f"'{s}'" for s in scopes)

        select_sql = (
            "SELECT ID, SCOPE "
            f"FROM {qm}.TASK_QUEUE "
            f"WHERE WORKFLOW_ID = {workflow_id} "
            f"AND SCOPE IN ({scope_list_sql}) "
            "AND STATUS IN ('pending', 'blocked') "
            "ORDER BY ID"
        )

        with self.connection.cursor() as cursor:
            cursor.execute(select_sql)
            rows = cursor.fetchall()

        scope_to_id: dict[str, int] = {}
        for row in rows:
            scope_to_id[str(row[1])] = int(row[0])

        task_ids = []
        for task in tasks:
            task_id = scope_to_id.get(task.scope)
            if task_id is None:
                raise Exception(
                    f"Failed to find task ID for scope '{task.scope}' after batch insert"
                )
            task_ids.append(task_id)

        logger.info(f"Batch-inserted {len(tasks)} tasks for workflow {workflow_id}")
        return task_ids

    async def push_independent_two_task_chains(
        self,
        chains: list[tuple[Task[TPayload], Task[TPayload]]],
    ) -> list[int]:
        """
        Override: batch-insert N independent [first -> second] chains in 3 SQL calls.

        Instead of 2N sequential stored procedure calls.
        """
        if not chains:
            return []

        # Prepare second tasks (blocked) as copies to avoid mutating caller's objects.
        # Preserve any pre-set successor_task_id for fan-in patterns.
        second_tasks: list[Task[TPayload]] = [
            dataclasses.replace(second, is_blocked=True) for _, second in chains
        ]

        # Batch-insert all second tasks
        second_task_ids = await self.push_tasks_batch(second_tasks)

        # Prepare first tasks (unblocked, successor = corresponding second task) as copies
        first_tasks: list[Task[TPayload]] = [
            dataclasses.replace(
                first, is_blocked=False, successor_task_id=second_task_ids[i]
            )
            for i, (first, _) in enumerate(chains)
        ]

        # Batch-insert all first tasks
        first_task_ids = await self.push_tasks_batch(first_tasks)

        all_ids = []
        for i in range(len(chains)):
            all_ids.append(first_task_ids[i])
            all_ids.append(second_task_ids[i])
        return all_ids

    async def check_tasks(
        self, workflow_id: int, task_ids: list[int]
    ) -> list[Task[TPayload]]:
        """Check tasks."""
        cursor = self.connection.cursor()
        # TODO(SNOW-2687870): Do not use interpolation for writing array of ints in SQL code
        qm = qualified_migration_schema()
        cursor.execute(
            f"CALL {qm}.CHECK_TASKS(%s, ARRAY_CONSTRUCT(%s)::ARRAY(INT))",
            (workflow_id, task_ids),
        )
        rows = cursor.fetchall()
        return [self._map_task(row, workflow_id) for row in rows]

    async def unblock_tasks(self):
        """Unblocks tasks for which all predecessor tasks have been completed."""
        await self._execute_statement(
            f"CALL {qualified_migration_schema()}.UNBLOCK_TASKS()"
        )

    async def expire_leases(self):
        """Expire leases for tasks that have exceeded their lease duration."""
        await self._execute_statement(
            f"CALL {qualified_migration_schema()}.EXPIRE_LEASES()"
        )

    async def refresh_active_leases(self, task_ids: set[int]) -> None:
        """
        Refresh leases only for tasks actively being processed by a live worker.

        Uses inline SQL instead of a stored procedure because Snowflake SPs
        don't accept variable-length ID lists. The IDs come from an internal
        in-memory set (not user input), so interpolation is safe here.
        """
        if not task_ids:
            return
        ids_csv = ", ".join(str(tid) for tid in task_ids)
        with self.connection.cursor() as cursor:
            cursor.execute(
                f"UPDATE {qualified_migration_schema()}.TASK_QUEUE "
                f"SET LEASING_TIME = SYSDATE() "
                f"WHERE ID IN ({ids_csv}) AND STATUS = '{TaskStatus.EXECUTING.value}'"
            )

    async def refresh_warehouse_tasks(self):
        """
        Check tasks associated with queries running in a warehouse and mark them as complete.

        Uses the Snowflake Python connector's get_query_status() to check each
        pending warehouse task by query_id directly, instead of relying on
        QUERY_HISTORY_BY_WAREHOUSE() which can miss queries due to retention
        limits or timing issues.
        """
        with self._lock:
            if not self._warehouse_tasks_loaded:
                self._pending_warehouse_tasks = dict(
                    await self._fetch_pending_warehouse_tasks()
                )
                self._warehouse_tasks_loaded = True

            if not self._pending_warehouse_tasks:
                return

            logger.info(
                f"Checking status for {len(self._pending_warehouse_tasks)} pending warehouse task(s)"
            )
            completed_task_ids: list[int] = []
            for task_id, query_id in list(self._pending_warehouse_tasks.items()):
                try:
                    status = self.connection.get_query_status_throw_if_error(query_id)
                except SnowflakeError as e:
                    error_message = str(e)
                    logger.warning(
                        f"Warehouse task {task_id} query failed: {error_message}"
                    )
                    await self._fail_warehouse_task(task_id, error_message)
                    completed_task_ids.append(task_id)
                    continue
                except Exception as e:
                    logger.warning(
                        f"Could not check status for warehouse task {task_id} "
                        f"(query_id={query_id}), will retry next cycle: {e}"
                    )
                    continue

                logger.info(
                    f"Warehouse task {task_id} (query_id={query_id}): status={status.name}"
                )

                if self.connection.is_still_running(status):
                    continue

                if status == QueryStatus.SUCCESS:
                    logger.info(f"Completing warehouse task {task_id}")
                    try:
                        await self._complete_warehouse_task(task_id)
                    except Exception as e:
                        logger.warning(
                            f"Could not mark warehouse task {task_id} as completed, "
                            f"will retry next cycle: {e}"
                        )
                        continue
                else:
                    logger.warning(
                        f"Warehouse task {task_id} query has unexpected terminal "
                        f"status: {status.name}, will retry next cycle"
                    )
                    continue
                completed_task_ids.append(task_id)

            for task_id in completed_task_ids:
                self._pending_warehouse_tasks.pop(task_id, None)

    async def _fetch_pending_warehouse_tasks(self) -> list[tuple[int, str]]:
        """Fetch all pending warehouse tasks and their associated query IDs from the database."""
        qm = qualified_migration_schema()
        with self.connection.cursor() as cursor:
            cursor.execute(
                f"""
                SELECT ID, PAYLOAD:query_id::TEXT AS QUERY_ID
                FROM {qm}.TASK_QUEUE
                WHERE EXECUTOR_TYPE = %s
                    AND STATUS IN (%s, %s)
                    AND PAYLOAD:query_id IS NOT NULL
                """,
                (
                    ExecutorType.WAREHOUSE.value,
                    TaskStatus.PENDING.value,
                    TaskStatus.EXECUTING.value,
                ),
            )
            rows = cursor.fetchall()
            return [(int(row[0]), str(row[1])) for row in rows]

    async def _complete_warehouse_task(self, task_id: int) -> None:
        """
        Mark a warehouse task as completed.

        Warehouse tasks are never leased to a consumer, so we update
        the status directly instead of going through COMPLETE_TASK
        (which requires LEASED_TO to match).
        """
        qm = qualified_migration_schema()
        with self.connection.cursor() as cursor:
            cursor.execute(
                f"""
                UPDATE {qm}.TASK_QUEUE
                SET STATUS = %s,
                    START_TIME = COALESCE(START_TIME, CREATION_TIME),
                    END_TIME = SYSDATE()
                WHERE ID = %s
                    AND EXECUTOR_TYPE = %s
                    AND STATUS IN (%s, %s)
                """,
                (
                    TaskStatus.COMPLETED.value,
                    task_id,
                    ExecutorType.WAREHOUSE.value,
                    TaskStatus.PENDING.value,
                    TaskStatus.EXECUTING.value,
                ),
            )

    async def _fail_warehouse_task(self, task_id: int, error_message: str) -> None:
        """
        Mark a warehouse task as failed.

        Warehouse tasks are never leased to a consumer, so we update
        the status directly instead of going through FAIL_TASK
        (which requires LEASED_TO to match).
        """
        qm = qualified_migration_schema()
        with self.connection.cursor() as cursor:
            cursor.execute(
                f"""
                UPDATE {qm}.TASK_QUEUE
                SET STATUS = %s,
                    LAST_ERROR_MESSAGE = %s,
                    START_TIME = COALESCE(START_TIME, CREATION_TIME),
                    END_TIME = SYSDATE()
                WHERE ID = %s
                    AND EXECUTOR_TYPE = %s
                    AND STATUS IN (%s, %s)
                """,
                (
                    TaskStatus.FAILED.value,
                    error_message,
                    task_id,
                    ExecutorType.WAREHOUSE.value,
                    TaskStatus.PENDING.value,
                    TaskStatus.EXECUTING.value,
                ),
            )

    async def get_tasks(self, max_tasks: int | None = None) -> list[Task]:
        """
        Get tasks for a workflow.

        Args:
            max_tasks: Maximum number of tasks to pull. If None, uses
                max_tasks_to_pull (1000).

        Returns:
            The list of tasks for the workflow.

        """
        limit = max_tasks if max_tasks is not None else self.max_tasks_to_pull
        cursor = self.connection.cursor(DictCursor)
        cursor.execute(
            pull_tasks_call_template(),
            (
                ExecutorType.ORCHESTRATOR.value,
                ExecutorType.ORCHESTRATOR.value,
                self.affinity,
                limit,
            ),
        )
        rows = cursor.fetchall()
        logger.info("PULL_TASKS returned %d row(s) (limit=%d)", len(rows), limit)

        tasks = [
            self._map_task_by_column_name(
                row,
                executor_type=ExecutorType.ORCHESTRATOR,
                status=TaskStatus.EXECUTING,
            )
            for row in rows
        ]
        filtered_tasks = [task for task in tasks if task is not None]
        if len(filtered_tasks) != len(tasks):
            logger.warning(f"{len(tasks) - len(filtered_tasks)} task(s) failed to map")
        return filtered_tasks

    async def has_workflow_started(self, workflow_id: int) -> bool:
        """
        Check if the workflow has started.

        This checks if the workflow has any tasks in the task queue.
        """
        cursor = self.connection.cursor()
        cursor.execute(has_workflow_started_call_template(), (workflow_id,))
        row = cursor.fetchone()
        has_workflow_started: bool = row[0] if row else False
        return has_workflow_started

    async def complete_task(self, consumer_type: ExecutorType, task_id: int) -> bool:
        """
        Complete a task.

        Args:
            consumer_type: The type of consumer that completed the task.
            task_id: The ID of the task to complete.

        Returns:
            True if the task was successfully completed, False otherwise.

        """
        with self.connection.cursor() as cursor:
            cursor.execute(
                complete_task_call_template(), (consumer_type.value, task_id)
            )
            row = cursor.fetchone()
            return row[0] if row else False

    async def fail_task(
        self, consumer_id: str, task_id: int, error_message: str
    ) -> bool:
        """
        Mark a task as failed.

        Args:
            consumer_id: The ID of the consumer that failed the task.
            task_id: The ID of the task to mark as failed.
            error_message: The error message describing the failure.

        Returns:
            True if the task was marked as failed successfully, False otherwise.

        """
        with self.connection.cursor() as cursor:
            cursor.execute(
                fail_task_call_template(), (task_id, consumer_id, error_message)
            )
            row = cursor.fetchone()
            return row[0] if row else False

    async def get_pending_workflows(self) -> list[Workflow]:
        """
        Get pending workflows to be started.

        Returns:
            The list of pending workflows to be started.

        """
        with self.connection.cursor(DictCursor) as cursor:
            cursor.execute(get_pending_workflows_call_template(), (self.affinity,))
            rows = cursor.fetchall()
            return [self._map_row_to_workflow(row) for row in rows]

    async def complete_workflows(self):
        """Complete executing workflows for which all tasks are in terminal state."""
        await self._execute_statement(complete_workflows_call_template())

    async def set_workflow_running(self, workflow_id: int) -> None:
        """Transition a workflow from 'initializing' to 'running'."""
        qm = qualified_migration_schema()
        with self.connection.cursor() as cursor:
            cursor.execute(
                f"""
                UPDATE {qm}.WORKFLOW
                SET STATUS = %s,
                    INITIALIZATION_START_TIME = NULL
                WHERE ID = %s AND STATUS = %s
                """,
                (
                    WorkflowStatus.RUNNING.value,
                    workflow_id,
                    WorkflowStatus.INITIALIZING.value,
                ),
            )

    async def fail_workflow_initialization(
        self, workflow_id: int, error_message: str
    ) -> None:
        """Record a failed initialization attempt for a workflow."""
        qm = qualified_migration_schema()
        with self.connection.cursor() as cursor:
            cursor.execute(
                f"""
                UPDATE {qm}.WORKFLOW
                SET
                    INITIALIZATION_FAILURES = INITIALIZATION_FAILURES + 1,
                    LAST_ERROR_MESSAGE = %s,
                    INITIALIZATION_START_TIME = NULL,
                    STATUS = CASE
                        WHEN INITIALIZATION_FAILURES + 1 >= %s THEN 'finished'
                        ELSE 'pending'
                    END,
                    END_TIME = CASE
                        WHEN INITIALIZATION_FAILURES + 1 >= %s THEN SYSDATE()
                        ELSE END_TIME
                    END
                WHERE ID = %s AND STATUS = %s
                """,
                (
                    error_message,
                    self.MAX_INITIALIZATION_FAILURES,
                    self.MAX_INITIALIZATION_FAILURES,
                    workflow_id,
                    WorkflowStatus.INITIALIZING.value,
                ),
            )

    async def expire_stale_initializations(self) -> None:
        """Expire workflows stuck in 'initializing' for longer than the timeout."""
        await self._execute_statement(expire_stale_initializations_call_template())

    async def delete_workflow_tasks(self, workflow_id: int) -> None:
        """Delete all tasks, table metadata, and partition metadata for a workflow."""
        with self.connection.cursor() as cursor:
            cursor.execute(delete_workflow_tasks_call_template(), (workflow_id,))

    @staticmethod
    def _parse_workflow_status(raw_status: str) -> WorkflowStatus:

        if raw_status.startswith("assigning"):
            """
            If we get a status that starts with "assigning",
            it means that the workflow is being assigned to an orchestrator and will move to RUNNING state immediately
            """
            return WorkflowStatus.RUNNING
        return WorkflowStatus(raw_status)

    def _map_row_to_workflow(self, row: dict) -> Workflow:
        return Workflow(
            id=row[workflow_columns.ID],
            name=row[workflow_columns.NAME],
            source_platform=SourceType.from_string(
                row[workflow_columns.SOURCE_PLATFORM]
            ),
            target_cloud_type=row[workflow_columns.TARGET_CLOUD_TYPE],
            target_cloud_stage_name=row[workflow_columns.TARGET_CLOUD_STAGE_NAME],
            target_cloud_url=row.get(workflow_columns.TARGET_CLOUD_URL),
            schema_version=row.get(workflow_columns.SCHEMA_VERSION, ""),
            workflow_type=row[workflow_columns.WORKFLOW_TYPE],
            initiator_id=row.get(workflow_columns.INITIATOR_ID, ""),
            status=self._parse_workflow_status(row[workflow_columns.STATUS]),
            configuration=json.loads(row[workflow_columns.CONFIGURATION]),
            creation_time=row.get(workflow_columns.CREATION_TIME),
            end_time=row.get(workflow_columns.END_TIME),
            affinity=row.get(workflow_columns.AFFINITY) or None,
            initialization_failures=row.get(
                workflow_columns.INITIALIZATION_FAILURES, 0
            ),
        )

    async def get_workflow_affinity(self, workflow_id: int) -> str | None:
        """
        Get the affinity group for a workflow.

        Args:
            workflow_id: The ID of the workflow.

        Returns:
            The affinity group for the workflow, or None if not found.

        """
        with self._lock:
            if workflow_id in self.workflow_affinity_by_id:
                return self.workflow_affinity_by_id[workflow_id]

        qm = qualified_migration_schema()
        with self.connection.cursor(DictCursor) as cursor:
            cursor.execute(
                f"""
                    SELECT AFFINITY
                    FROM {qm}.WORKFLOW
                    WHERE ID = %s
                """,
                (workflow_id,),
            )
            row = cursor.fetchone()
            if row is None:
                logger.warning(
                    f"Workflow with ID {workflow_id} not found (when looking for affinity)."
                )
                return None

            affinity: str | None = row.get(workflow_columns.AFFINITY) or None
            with self._lock:
                self.workflow_affinity_by_id[workflow_id] = affinity
            return affinity
