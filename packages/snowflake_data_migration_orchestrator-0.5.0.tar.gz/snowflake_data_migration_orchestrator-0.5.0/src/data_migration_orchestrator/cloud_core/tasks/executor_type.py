from enum import StrEnum


class ExecutorType(StrEnum):
    """
    Enum representing possible task statuses.

    Used to track the state of tasks throughout their lifecycle.
    """

    DATA_EXCHANGE_AGENT = "data-exchange-agent"
    ORCHESTRATOR = "orchestrator"
    WAREHOUSE = "warehouse"
