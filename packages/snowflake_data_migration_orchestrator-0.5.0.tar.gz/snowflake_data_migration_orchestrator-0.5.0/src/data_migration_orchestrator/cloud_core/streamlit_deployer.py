"""
Generic Streamlit-in-Snowflake deployer.

Provides a reusable ``deploy_streamlit_app`` function that any dashboard
module can call with its own configuration (schema, app/stage names, and
the path to the local ``app.py`` file).
"""

import hashlib
import logging
import os

from dataclasses import dataclass
from pathlib import Path

import snowflake.connector


@dataclass(frozen=True)
class StreamlitAppConfig:
    """All the identifiers needed to deploy a single Streamlit app."""

    qualified_schema: str
    app_name: str
    stage_name: str
    app_file: Path
    companion_files: tuple[Path, ...] = ()

    @property
    def qualified_stage(self) -> str:
        """Fully qualified stage name (``schema.stage``)."""
        return f"{self.qualified_schema}.{self.stage_name}"

    @property
    def qualified_app(self) -> str:
        """Fully qualified Streamlit app name (``schema.app``)."""
        return f"{self.qualified_schema}.{self.app_name}"


def deploy_streamlit_app(
    connection: snowflake.connector.SnowflakeConnection,
    config: StreamlitAppConfig,
    logger: logging.Logger,
) -> None:
    """
    Deploy or update a Streamlit app when the local code has changed.

    Compares a SHA-256 hash of the local ``app.py`` (plus companion files) against
    the hash stored in the Streamlit object's COMMENT field. The bundle is
    re-uploaded only when the hashes differ, keeping startup fast when nothing
    changed.

    Set environment variable ``STREAMLIT_FORCE_REDEPLOY`` to ``1``, ``true``, or
    ``yes`` to always PUT files and refresh the COMMENT (both migration and DV
    dashboards honor this when the orchestrator starts).
    """
    logger.info("Checking if Streamlit dashboard deployment is needed...")

    force = os.environ.get("STREAMLIT_FORCE_REDEPLOY", "").strip().lower() in (
        "1",
        "true",
        "yes",
    )
    if force:
        logger.info(
            "STREAMLIT_FORCE_REDEPLOY is set — re-uploading Streamlit app '%s' "
            "regardless of stored hash",
            config.app_name,
        )

    local_hash = _compute_local_hash(config)
    remote_comment = _get_streamlit_comment(connection, config, logger)
    app_exists = remote_comment is not None

    if not force and app_exists and remote_comment == local_hash:
        logger.info(
            f"Streamlit app '{config.app_name}' is up to date, " "skipping deployment"
        )
        return

    action = "Updating" if app_exists else "Creating"
    logger.info(f"{action} Streamlit app '{config.app_name}'...")

    try:
        _create_stage_if_needed(connection, config, logger)
        _upload_app_file(connection, config, logger)

        if not app_exists:
            _create_streamlit_app(connection, config, logger)

        _set_streamlit_comment(connection, config, local_hash)
        logger.info(f"Streamlit app '{config.app_name}' deployed successfully")
        logger.info(
            "Snowsight: files are on the stage. For warehouse-runtime apps, open the "
            "app and click Run (or close the tab and reopen) so your session reloads "
            "from the stage—otherwise you may still see the previous copy."
        )
    except Exception as e:
        logger.error(f"Failed to deploy Streamlit app: {e}")
        raise


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _compute_local_hash(config: StreamlitAppConfig) -> str:
    """Hash main and companion files so redeploy runs when baked metadata changes."""
    paths = (
        config.app_file,
        *sorted(config.companion_files, key=lambda p: p.as_posix()),
    )
    digest = hashlib.sha256()
    for path in paths:
        digest.update(path.as_posix().encode("utf-8"))
        digest.update(b"\0")
        digest.update(path.read_bytes())
    return digest.hexdigest()


def _get_streamlit_comment(
    connection: snowflake.connector.SnowflakeConnection,
    config: StreamlitAppConfig,
    logger: logging.Logger,
) -> str | None:
    cursor = connection.cursor(snowflake.connector.DictCursor)
    try:
        # nosemgrep: python.lang.security.audit.formatted-sql-query.formatted-sql-query
        # nosemgrep: python.sqlalchemy.security.sqlalchemy-execute-raw-query.sqlalchemy-execute-raw-query
        cursor.execute(
            f"SHOW STREAMLITS LIKE '{config.app_name}' "
            f"IN SCHEMA {config.qualified_schema}"
        )
        results = cursor.fetchall()
        if len(results) == 0:
            return None
        return results[0]["comment"] or ""
    except Exception as e:
        logger.warning(f"Error checking for existing Streamlit app: {e}")
        return None
    finally:
        cursor.close()


def _set_streamlit_comment(
    connection: snowflake.connector.SnowflakeConnection,
    config: StreamlitAppConfig,
    comment: str,
) -> None:
    cursor = connection.cursor()
    try:
        # nosemgrep: python.lang.security.audit.formatted-sql-query.formatted-sql-query
        # nosemgrep: python.sqlalchemy.security.sqlalchemy-execute-raw-query.sqlalchemy-execute-raw-query
        cursor.execute(
            f"ALTER STREAMLIT {config.qualified_app} SET COMMENT = '{comment}'"
        )
    finally:
        cursor.close()


def _create_stage_if_needed(
    connection: snowflake.connector.SnowflakeConnection,
    config: StreamlitAppConfig,
    logger: logging.Logger,
) -> None:
    cursor = connection.cursor()
    try:
        # nosemgrep: python.lang.security.audit.formatted-sql-query.formatted-sql-query
        # nosemgrep: python.sqlalchemy.security.sqlalchemy-execute-raw-query.sqlalchemy-execute-raw-query
        cursor.execute(f"CREATE STAGE IF NOT EXISTS {config.qualified_stage}")
        logger.info(f"Stage '{config.stage_name}' ready")
    finally:
        cursor.close()


def _upload_app_file(
    connection: snowflake.connector.SnowflakeConnection,
    config: StreamlitAppConfig,
    logger: logging.Logger,
) -> None:
    to_upload = (config.app_file, *config.companion_files)
    cursor = connection.cursor()
    try:
        for path in to_upload:
            if not path.exists():
                raise FileNotFoundError(f"Streamlit app file not found: {path}")
            # nosemgrep: python.lang.security.audit.formatted-sql-query.formatted-sql-query
            # nosemgrep: python.sqlalchemy.security.sqlalchemy-execute-raw-query.sqlalchemy-execute-raw-query
            cursor.execute(
                f"PUT 'file://{path.as_posix()}' "
                f"@{config.qualified_stage} AUTO_COMPRESS=FALSE OVERWRITE=TRUE"
            )
        logger.info(
            "Uploaded %s file(s) to stage '%s'",
            len(to_upload),
            config.stage_name,
        )
    finally:
        cursor.close()


def _create_streamlit_app(
    connection: snowflake.connector.SnowflakeConnection,
    config: StreamlitAppConfig,
    logger: logging.Logger,
) -> None:
    cursor = connection.cursor()
    try:
        cursor.execute("SELECT CURRENT_WAREHOUSE()")
        result = cursor.fetchone()
        if not result or not result[0]:
            raise RuntimeError(
                "No active warehouse found. Please ensure a warehouse is set "
                "on the Snowflake connection."
            )
        warehouse = result[0]

        # nosemgrep: python.lang.security.audit.formatted-sql-query.formatted-sql-query
        # nosemgrep: python.sqlalchemy.security.sqlalchemy-execute-raw-query.sqlalchemy-execute-raw-query
        cursor.execute(
            f"""
            CREATE STREAMLIT IF NOT EXISTS {config.qualified_app}
            ROOT_LOCATION = '@{config.qualified_stage}'
            MAIN_FILE = 'app.py'
            QUERY_WAREHOUSE = {warehouse}
        """
        )
        logger.info(f"Created Streamlit app '{config.app_name}'")
    finally:
        cursor.close()
