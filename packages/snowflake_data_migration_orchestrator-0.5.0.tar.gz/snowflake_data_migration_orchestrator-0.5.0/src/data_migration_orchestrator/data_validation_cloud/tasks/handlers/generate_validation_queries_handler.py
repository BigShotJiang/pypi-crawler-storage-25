"""
Handler for GENERATE_VALIDATION_QUERIES tasks.

Reads staged source metadata, determines partitioning, generates L1 schema
validation queries via sdv, and pushes L1 DEA tasks + write-results +
blocked EVALUATE_LEVEL_RESULT.
"""

from __future__ import annotations

import json

from typing import Any

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.queues.base_task_queue import (
    BaseTaskQueue,
)
from data_migration_orchestrator.cloud_core.tasks.task import Task
from data_migration_orchestrator.cloud_core.tasks.task_builder import TaskBuilder
from data_migration_orchestrator.cloud_core.warehouse import Warehouse
from data_migration_orchestrator.data_migration_cloud.platforms.snowflake.identifiers import (
    quote_identifier,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.partition_calculator import (
    PartitionCalculator,
    PartitionConfig,
)
from data_migration_orchestrator.data_validation_cloud.query.sdv_query_helper import (
    build_schema_queries,
    load_datatypes_mappings,
)
from data_migration_orchestrator.data_validation_cloud.scope import (
    build_evaluate_scope,
    build_validation_scope,
    build_write_results_scope,
)
from data_migration_orchestrator.data_validation_cloud.tasks.models.dea_payload_factory import (
    DEAPayloadFactory,
)
from data_migration_orchestrator.data_validation_cloud.tasks.models.task_payload import (
    EvaluateLevelResultPayload,
    GenerateValidationQueriesPayload,
    WriteValidationResultsPayload,
)
from data_migration_orchestrator.data_validation_core.constants import (
    METRICS_VALIDATION,
    ROW_VALIDATION,
    SCHEMA_VALIDATION,
    SKIP_LEVEL,
    data_validation_full_schema,
    fq_schema_validation_results,
    validation_csv_file_format_fqn,
)


logger = get_logger("dv.generate_validation_queries_handler")

# Partitioning thresholds
DEFAULT_BASE_MAX_ROWS_PER_PARTITION = 500_000

# Sampling thresholds (aligned with DM's Redshift query builder)
SAMPLING_THRESHOLD_ROWS = 100_000_000
SAMPLING_TARGET_ROWS = 20_000_000


class GenerateValidationQueriesHandler:
    """
    Handle GENERATE_VALIDATION_QUERIES tasks.

    Reads staged metadata, determines partitioning strategy, generates L1 schema
    queries, and pushes the L1 task chain: DEA validation -> write results ->
    evaluate level result.
    """

    def __init__(
        self,
        task_queue: BaseTaskQueue,
        warehouse_proxy: Warehouse,
    ) -> None:
        """
        Initialize the handler.

        Args:
            task_queue: Task queue for pushing follow-up tasks.
            warehouse_proxy: Warehouse proxy for Snowflake operations.

        """
        self.task_queue = task_queue
        self.warehouse_proxy = warehouse_proxy

    async def handle(self, task: Task) -> None:
        """
        Handle the generate validation queries task.

        1. Read table configuration from TABLE_METADATA
        2. Insert PARTITION_METADATA rows based on row count and column count
        3. Generate L1 schema validation queries
        4. Push L1 task chain

        Args:
            task: The task containing GenerateValidationQueriesPayload.

        """
        payload: GenerateValidationQueriesPayload = task.payload
        assert task.id is not None, "Task must have an ID when being handled"
        table_metadata_id = payload.table_metadata_id
        source_identifier = payload.source_identifier
        workflow_id = payload.workflow_id
        source_platform = payload.source_platform

        logger.info(
            "Generating validation queries for table_metadata_id=%d, source=%s",
            table_metadata_id,
            source_identifier,
        )

        config_result = await self.warehouse_proxy.execute_sync_query(
            f"CALL {data_validation_full_schema()}.GET_TABLE_CONFIGURATION({table_metadata_id})"
        )
        table_config_variant = (
            next(iter(config_result[0].values())) if config_result else None
        )
        table_config = (
            json.loads(table_config_variant)
            if isinstance(table_config_variant, str)
            else (table_config_variant or {})
        )

        await self.warehouse_proxy.execute_sync_query(
            f"CALL {data_validation_full_schema()}.UPDATE_TABLE_VALIDATION_STATUS({table_metadata_id}, 'IN_PROGRESS')"
        )

        await self._create_partition_metadata(
            table_metadata_id=table_metadata_id,
            source_identifier=source_identifier,
            table_config=table_config,
        )

        # Determine if L1 schema validation is enabled
        schema_enabled = table_config.get("schema_validation", True)
        metrics_enabled = table_config.get("metrics_validation", True)
        row_enabled = table_config.get("row_validation", False)
        continue_on_failure = table_config.get("continue_on_failure", False)

        if not schema_enabled:
            logger.info(
                "Schema validation disabled for %s, checking next level",
                source_identifier,
            )
            next_level = (
                METRICS_VALIDATION
                if metrics_enabled
                else (ROW_VALIDATION if row_enabled else None)
            )
            if next_level is None:
                logger.info("No validation levels enabled for %s", source_identifier)
                await self.task_queue.complete_task(ExecutorType.ORCHESTRATOR, task.id)
                return
            await self._push_skip_to_level(
                workflow_id=workflow_id,
                table_metadata_id=table_metadata_id,
                source_identifier=source_identifier,
                source_platform=source_platform,
                target_level=next_level,
                metrics_enabled=metrics_enabled,
                row_enabled=row_enabled,
                continue_on_failure=continue_on_failure,
            )
            await self.task_queue.complete_task(ExecutorType.ORCHESTRATOR, task.id)
            return

        # Push L1 schema validation task chain
        await self._push_l1_schema_chain(
            workflow_id=workflow_id,
            table_metadata_id=table_metadata_id,
            source_identifier=source_identifier,
            source_platform=source_platform,
            table_config=table_config,
            metrics_enabled=metrics_enabled,
            row_enabled=row_enabled,
            continue_on_failure=continue_on_failure,
        )

        await self.task_queue.complete_task(ExecutorType.ORCHESTRATOR, task.id)

    async def _push_l1_schema_chain(
        self,
        workflow_id: int,
        table_metadata_id: int,
        source_identifier: str,
        source_platform: str,
        table_config: dict,
        metrics_enabled: bool,
        row_enabled: bool,
        continue_on_failure: bool,
    ) -> None:
        """Push the L1 schema validation task chain: DEA -> write -> evaluate."""
        next_level = (
            METRICS_VALIDATION
            if metrics_enabled
            else (ROW_VALIDATION if row_enabled else None)
        )
        next_level_enabled = next_level is not None

        column_mappings = table_config.get("column_mappings", {})
        datatypes_mappings = load_datatypes_mappings(source_platform)

        src_db, src_schema, src_table = self._parse_fqn(source_identifier)
        tgt_db = table_config.get("target_database", "")
        tgt_schema = table_config.get("target_schema", src_schema)
        tgt_table = table_config.get("target_name", src_table)

        source_query, target_query = build_schema_queries(
            source_platform_str=source_platform,
            source_db=src_db,
            source_schema=src_schema,
            source_table=src_table,
            target_db=tgt_db,
            target_schema=tgt_schema,
            target_table=tgt_table,
        )

        dea_factory = DEAPayloadFactory(
            workflow_id=workflow_id,
            table_metadata_id=table_metadata_id,
            source_identifier=source_identifier,
            source_platform=source_platform,
        )

        # Build tasks in execution order: DEA -> write -> evaluate
        dea_task = TaskBuilder(
            workflow_id=workflow_id,
            task_name=f"Validate schema for {source_identifier}",
            executor_type=ExecutorType.DATA_EXCHANGE_AGENT,
            payload=dea_factory.schema_payload(
                source_query=source_query,
                target_query=target_query,
                column_mappings=column_mappings or None,
                datatypes_mappings=datatypes_mappings or None,
            ),
            scope=build_validation_scope(source_identifier, SCHEMA_VALIDATION),
        ).build()

        copy_query = self._build_schema_copy_into_query(
            workflow_id, table_metadata_id, dea_factory.stage_path(SCHEMA_VALIDATION)
        )
        write_task = TaskBuilder(
            workflow_id=workflow_id,
            task_name=f"Write L1 results for {source_identifier}",
            executor_type=ExecutorType.ORCHESTRATOR,
            payload=WriteValidationResultsPayload(
                query=copy_query,
                table_metadata_id=table_metadata_id,
                workflow_id=workflow_id,
                validation_level=SCHEMA_VALIDATION,
            ),
            scope=build_write_results_scope(source_identifier, SCHEMA_VALIDATION),
        ).build()

        evaluate_task = TaskBuilder(
            workflow_id=workflow_id,
            task_name=f"Evaluate L1 result for {source_identifier}",
            executor_type=ExecutorType.ORCHESTRATOR,
            payload=EvaluateLevelResultPayload(
                table_metadata_id=table_metadata_id,
                completed_level=SCHEMA_VALIDATION,
                next_level=next_level,
                continue_on_failure=continue_on_failure,
                next_level_enabled=next_level_enabled,
                workflow_id=workflow_id,
                source_platform=source_platform,
                source_identifier=source_identifier,
            ),
            scope=build_evaluate_scope(source_identifier, SCHEMA_VALIDATION),
        ).build()

        await self.task_queue.push_task_chain([dea_task, write_task, evaluate_task])

        logger.info(
            "Pushed L1 schema chain for %s: DEA -> write -> evaluate",
            source_identifier,
        )

    async def _push_skip_to_level(
        self,
        workflow_id: int,
        table_metadata_id: int,
        source_identifier: str,
        source_platform: str,
        target_level: str,
        metrics_enabled: bool,
        row_enabled: bool,
        continue_on_failure: bool,
    ) -> None:
        """Push an evaluate task that will generate the next enabled level's queries."""
        evaluate_scope = build_evaluate_scope(source_identifier, SKIP_LEVEL)
        evaluate_task = TaskBuilder(
            workflow_id=workflow_id,
            task_name=f"Skip to {target_level} for {source_identifier}",
            executor_type=ExecutorType.ORCHESTRATOR,
            payload=EvaluateLevelResultPayload(
                table_metadata_id=table_metadata_id,
                completed_level=SKIP_LEVEL,
                next_level=target_level,
                continue_on_failure=continue_on_failure,
                next_level_enabled=True,
                workflow_id=workflow_id,
                source_platform=source_platform,
                source_identifier=source_identifier,
            ),
            scope=evaluate_scope,
        ).build()
        await self.task_queue.push_task(evaluate_task)

    @staticmethod
    def _parse_fqn(fqn: str) -> tuple[str, str, str]:
        """Parse a 'db.schema.table' fully qualified name into parts."""
        parts = fqn.split(".")
        if len(parts) == 3:
            return parts[0], parts[1], parts[2]
        if len(parts) == 2:
            return "", parts[0], parts[1]
        return "", "", parts[0]

    @staticmethod
    def _build_schema_copy_into_query(
        workflow_id: int, table_metadata_id: int, stage_path: str
    ) -> str:
        """Build COPY INTO SQL for schema validation results."""
        return (
            f"COPY INTO {fq_schema_validation_results()} "
            f"(WORKFLOW_ID, TABLE_METADATA_ID, VALIDATION_TYPE, TABLE_NAME, "
            f"COLUMN_VALIDATED, EVALUATION_CRITERIA, SOURCE_VALUE, "
            f"SNOWFLAKE_VALUE, STATUS, COMMENTS) "
            f"FROM (SELECT "
            f"$1, $2, $3, $4, $5, $6, $7, $8, $9, $10 "
            f"FROM '{stage_path}/') "
            f"FILE_FORMAT = (FORMAT_NAME = '{validation_csv_file_format_fqn()}') "
            f"ON_ERROR = 'CONTINUE'"
        )

    async def _create_partition_metadata(
        self,
        table_metadata_id: int,
        source_identifier: str,
        table_config: dict,
    ) -> None:
        """
        Populate PARTITION_METADATA using DM's PartitionCalculator and NTILE.

        When ``partition_column`` is configured, queries the Snowflake target
        for a row count, uses :class:`PartitionCalculator` (row-based mode) to
        decide how many partitions are needed, then runs an NTILE query on the
        target to compute boundaries and inserts them into PARTITION_METADATA.

        Falls back to a single virtual partition (NULL min/max) when no
        partition column is configured, the table is empty, or only one
        partition is needed.
        """
        partition_column = table_config.get("partition_column")

        if not partition_column:
            await self._insert_single_partition(table_metadata_id)
            return

        src_db, src_schema, src_table = self._parse_fqn(source_identifier)
        tgt_db = table_config.get("target_database", "")
        tgt_schema = table_config.get("target_schema", src_schema)
        tgt_table = table_config.get("target_name", src_table)
        tgt_fqn = (
            f"{tgt_db}.{tgt_schema}.{tgt_table}"
            if tgt_db
            else f"{tgt_schema}.{tgt_table}"
        )

        count_result = await self.warehouse_proxy.execute_sync_query(
            f"SELECT COUNT(*) AS ROW_COUNT FROM {tgt_fqn}"
        )
        row_count = int(next(iter(count_result[0].values()))) if count_result else 0

        if row_count == 0:
            await self._insert_single_partition(table_metadata_id)
            return

        calculator = PartitionCalculator(
            PartitionConfig(max_rows_per_partition=DEFAULT_BASE_MAX_ROWS_PER_PARTITION)
        )
        decision = calculator.calculate_partition_strategy(row_count, data_size_mb=0)

        if not decision.should_partition or decision.num_partitions <= 1:
            await self._insert_single_partition(table_metadata_id)
            logger.info(
                "Single partition for table_metadata_id=%d: %s",
                table_metadata_id,
                decision.reasoning,
            )
            return

        num_partitions = decision.num_partitions
        col_sql = quote_identifier(partition_column, force_quote=False)
        ntile_query = self._build_partition_boundary_query(
            tgt_fqn, col_sql, num_partitions, row_count
        )

        boundary_rows = await self.warehouse_proxy.execute_sync_query(ntile_query)

        if not boundary_rows:
            await self._insert_single_partition(table_metadata_id)
            return

        for row in boundary_rows:
            part_num = row.get("PARTITION_ID", row.get("partition_id"))
            min_val = row.get(
                "MIN_VALUE_IN_PARTITION", row.get("min_value_in_partition")
            )
            max_val = row.get(
                "MAX_VALUE_IN_PARTITION", row.get("max_value_in_partition")
            )
            n_rows = row.get("N_ROWS", row.get("n_rows", 0))

            min_sql = self._format_as_variant(min_val)
            max_sql = self._format_as_variant(max_val)
            await self.warehouse_proxy.execute_sync_query(
                f"CALL {data_validation_full_schema()}.INSERT_PARTITION_METADATA("
                f"{table_metadata_id}, {part_num}, {min_sql}, {max_sql}, {n_rows})"
            )

        logger.info(
            "Created %d partitions for table_metadata_id=%d using column '%s' (%s)",
            len(boundary_rows),
            table_metadata_id,
            partition_column,
            decision.reasoning,
        )

    async def _insert_single_partition(self, table_metadata_id: int) -> None:
        """Insert a single virtual partition with NULL bounds."""
        await self.warehouse_proxy.execute_sync_query(
            f"CALL {data_validation_full_schema()}.INSERT_PARTITION_METADATA("
            f"{table_metadata_id}, 1, NULL, NULL, NULL)"
        )

    @staticmethod
    def _build_partition_boundary_query(
        tgt_fqn: str,
        col_sql: str,
        num_partitions: int,
        row_count: int,
    ) -> str:
        """
        Build NTILE partition boundary query against the Snowflake target.

        For large tables (>= SAMPLING_THRESHOLD_ROWS), uses Snowflake's
        SAMPLE BERNOULLI to avoid a full table scan + sort, mirroring the
        sampling strategy used by DM's Redshift query builder.
        """
        if row_count >= SAMPLING_THRESHOLD_ROWS:
            sample_pct = min((SAMPLING_TARGET_ROWS / row_count) * 100, 100.0)
            return (
                f"WITH sampled AS ("
                f"SELECT {col_sql} "
                f"FROM {tgt_fqn} SAMPLE BERNOULLI ({sample_pct:.6f})"
                f"), "
                f"partitioned AS ("
                f"SELECT {col_sql}, "
                f"NTILE({num_partitions}) OVER (ORDER BY {col_sql}) AS partition_id "
                f"FROM sampled"
                f") "
                f"SELECT partition_id, "
                f"MIN({col_sql}) AS min_value_in_partition, "
                f"MAX({col_sql}) AS max_value_in_partition, "
                f"COUNT(*) AS n_rows "
                f"FROM partitioned "
                f"GROUP BY partition_id "
                f"ORDER BY partition_id"
            )

        return (
            f"WITH partitioned AS ("
            f"SELECT {col_sql}, "
            f"NTILE({num_partitions}) OVER (ORDER BY {col_sql}) AS partition_id "
            f"FROM {tgt_fqn}"
            f") "
            f"SELECT partition_id, "
            f"MIN({col_sql}) AS min_value_in_partition, "
            f"MAX({col_sql}) AS max_value_in_partition, "
            f"COUNT(*) AS n_rows "
            f"FROM partitioned "
            f"GROUP BY partition_id "
            f"ORDER BY partition_id"
        )

    @staticmethod
    def _format_as_variant(value: Any) -> str:
        """Format a Python value as a Snowflake VARIANT literal."""
        if value is None:
            return "NULL"
        if isinstance(value, bool):
            return "TRUE::VARIANT" if value else "FALSE::VARIANT"
        if isinstance(value, int | float):
            return f"{value}::VARIANT"
        if isinstance(value, str):
            try:
                int(value)
                return f"{value}::VARIANT"
            except ValueError:
                pass
            try:
                float(value)
                return f"{value}::VARIANT"
            except ValueError:
                pass
            escaped = value.replace("'", "''")
            return f"'{escaped}'::VARIANT"
        escaped = str(value).replace("'", "''")
        return f"'{escaped}'::VARIANT"
