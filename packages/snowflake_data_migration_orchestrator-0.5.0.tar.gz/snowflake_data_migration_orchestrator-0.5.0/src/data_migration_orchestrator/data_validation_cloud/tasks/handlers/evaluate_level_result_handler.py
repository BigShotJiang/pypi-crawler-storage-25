"""
Handler for EVALUATE_LEVEL_RESULT tasks.

Sits between validation levels and implements gating logic: reads results
from the completed level, decides whether to proceed to the next level,
and generates next-level tasks when appropriate.
"""

from __future__ import annotations

import json

from typing import Any

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.queues.base_task_queue import (
    BaseTaskQueue,
)
from data_migration_orchestrator.cloud_core.tasks.task import Task
from data_migration_orchestrator.cloud_core.tasks.task_builder import TaskBuilder
from data_migration_orchestrator.cloud_core.warehouse import Warehouse
from data_migration_orchestrator.data_migration_cloud.platforms.platform_registry import (
    PlatformRegistry,
)
from data_migration_orchestrator.data_migration_cloud.platforms.snowflake import (
    build_snowflake_partition_condition,
)
from data_migration_orchestrator.data_validation_cloud.config import (
    configuration_properties_keys as keys,
)
from data_migration_orchestrator.data_validation_cloud.query.sdv_query_helper import (
    build_cell_validation_queries,
    build_metrics_queries,
    build_normalized_cell_validation_queries,
    make_column_metadata,
)
from data_migration_orchestrator.data_validation_cloud.scope import (
    build_evaluate_scope,
    build_validation_scope,
    build_write_results_scope,
)
from data_migration_orchestrator.data_validation_cloud.tasks.models.dea_payload_factory import (
    DEAPayloadFactory,
)
from data_migration_orchestrator.data_validation_cloud.tasks.models.task_payload import (
    ColumnMetadataDict,
    EvaluateLevelResultPayload,
    WriteValidationResultsPayload,
)
from data_migration_orchestrator.data_validation_core.constants import (
    COL_COLUMN_NAME,
    COL_COLUMN_VALIDATED,
    COL_DATA_TYPE,
    COL_MAX_VALUE,
    COL_MIN_VALUE,
    COL_PARTITION_NUMBER,
    COL_SOURCE_VALUE,
    LEVEL_RESULT_FAILED,
    LEVEL_RESULT_PASSED,
    METRICS_VALIDATION,
    ROW_VALIDATION,
    ROW_VALIDATION_MODE_CELL,
    ROW_VALIDATION_MODE_ROW,
    SCHEMA_VALIDATION,
    SKIP_LEVEL,
    TABLE_STATUS_COMPLETED,
    TABLE_STATUS_FAILED,
    RowValidationMode,
    data_validation_full_schema,
    fq_cell_validation_results,
    fq_chunk_hashes,
    fq_metrics_validation_results,
    fq_row_validation_results,
    fq_row_validation_summary,
    fq_schema_validation_results,
    task_results_stage,
    validation_csv_file_format_fqn,
)


logger = get_logger("dv.evaluate_level_result_handler")

# Keys for the metrics context dict returned by _fetch_metrics_column_metadata
_CTX_SOURCE_COLUMNS = "source_columns"
_CTX_TARGET_COLUMNS = "target_columns"
_CTX_SRC_DB = "src_db"
_CTX_SRC_SCHEMA = "src_schema"
_CTX_SRC_TABLE = "src_table"
_CTX_TGT_DB = "tgt_db"
_CTX_TGT_SCHEMA = "tgt_schema"
_CTX_TGT_TABLE = "tgt_table"
_CTX_SRC_FQ = "src_fq"
_CTX_TGT_FQ = "tgt_fq"


def _results_table_for_level(
    level: str, row_validation_mode: RowValidationMode | None
) -> str | None:
    if level == ROW_VALIDATION and row_validation_mode == ROW_VALIDATION_MODE_CELL:
        return fq_cell_validation_results()
    if level == SCHEMA_VALIDATION:
        return fq_schema_validation_results()
    if level == METRICS_VALIDATION:
        return fq_metrics_validation_results()
    if level == ROW_VALIDATION:
        return fq_row_validation_results()
    return None


class EvaluateLevelResultHandler:
    """
    Handle EVALUATE_LEVEL_RESULT tasks.

    Implements the level-gating decision point between validation levels.
    After a level completes, this handler:
    1. Reads results from the level's results table to determine pass/fail
    2. Checks the continue_on_failure flag and whether the next level is enabled
    3. If proceeding: generates next-level queries and pushes DEA tasks
    4. If stopping: marks the table as complete
    """

    def __init__(
        self,
        task_queue: BaseTaskQueue,
        warehouse_proxy: Warehouse,
    ) -> None:
        """
        Initialize the handler.

        Args:
            task_queue: Task queue for pushing follow-up tasks.
            warehouse_proxy: Warehouse proxy for Snowflake operations.

        """
        self.task_queue = task_queue
        self.warehouse_proxy = warehouse_proxy

    async def handle(self, task: Task) -> None:
        """
        Handle the evaluate level result task.

        Args:
            task: The task containing EvaluateLevelResultPayload.

        """
        payload: EvaluateLevelResultPayload = task.payload
        assert task.id is not None, "Task must have an ID when being handled"

        logger.info(
            "Evaluating level '%s' results for table_metadata_id=%d",
            payload.completed_level,
            payload.table_metadata_id,
        )

        if payload.completed_level == SKIP_LEVEL:
            if payload.next_level and payload.next_level_enabled:
                await self._generate_next_level(payload)
            await self.task_queue.complete_task(ExecutorType.ORCHESTRATOR, task.id)
            return

        level_passed = await self._check_level_passed(
            workflow_id=payload.workflow_id,
            table_metadata_id=payload.table_metadata_id,
            level=payload.completed_level,
            row_validation_mode=payload.row_validation_mode,
        )

        logger.info(
            "Level '%s' for table_metadata_id=%d: %s",
            payload.completed_level,
            payload.table_metadata_id,
            LEVEL_RESULT_PASSED if level_passed else LEVEL_RESULT_FAILED,
        )

        should_proceed = level_passed or payload.continue_on_failure
        has_next = payload.next_level is not None and payload.next_level_enabled

        if should_proceed and has_next:
            await self._generate_next_level(payload)
        else:
            status = TABLE_STATUS_COMPLETED if level_passed else TABLE_STATUS_FAILED
            if not has_next:
                status = TABLE_STATUS_COMPLETED
            await self.warehouse_proxy.execute_sync_query(
                f"CALL {data_validation_full_schema()}.UPDATE_TABLE_VALIDATION_STATUS({payload.table_metadata_id}, '{status}')"
            )
            logger.info(
                "Table %d marked as %s (level_passed=%s, has_next=%s, continue_on_failure=%s)",
                payload.table_metadata_id,
                status,
                level_passed,
                has_next,
                payload.continue_on_failure,
            )

        await self.task_queue.complete_task(ExecutorType.ORCHESTRATOR, task.id)

    async def _check_level_passed(
        self,
        workflow_id: int,
        table_metadata_id: int,
        level: str,
        row_validation_mode: RowValidationMode | None = None,
    ) -> bool:
        """
        Check if a validation level passed by querying its results table.

        A level is considered passed only when results exist AND none of
        them are failures.  If the results table has zero rows for this
        table, the level is treated as **not passed** — this prevents
        the evaluate handler from advancing to the next level when an
        out-of-order execution causes it to run before the predecessor
        chain has written its results.
        """
        results_table = _results_table_for_level(level, row_validation_mode)
        if not results_table:
            logger.warning("Unknown level '%s', treating as passed", level)
            return True

        if level == ROW_VALIDATION:
            # L3 result tables only contain diff rows (no STATUS column).
            # A zero row count means no differences were found, i.e. the
            # level passed.  This differs from L1/L2 which store every
            # result row and filter on STATUS to determine failures.
            query = (
                f"SELECT COUNT(*) FROM {results_table} "
                f"WHERE WORKFLOW_ID = {workflow_id} "
                f"AND TABLE_METADATA_ID = {table_metadata_id}"
            )
            result = await self.warehouse_proxy.execute_sync_query(query)
            diff_count = (
                int(next(iter(result[0].values()))) if result and result[0] else 0
            )
            return diff_count == 0

        total_query = (
            f"SELECT COUNT(*) FROM {results_table} "
            f"WHERE WORKFLOW_ID = {workflow_id} "
            f"AND TABLE_METADATA_ID = {table_metadata_id}"
        )
        total_result = await self.warehouse_proxy.execute_sync_query(total_query)
        total_count = (
            int(next(iter(total_result[0].values())))
            if total_result and total_result[0]
            else 0
        )

        if total_count == 0:
            logger.error(
                "No results found for level '%s' (workflow=%d, "
                "table_metadata_id=%d). Predecessor may not have "
                "completed yet — treating as failed.",
                level,
                workflow_id,
                table_metadata_id,
            )
            return False

        failure_query = (
            f"SELECT COUNT(*) FROM {results_table} "
            f"WHERE WORKFLOW_ID = {workflow_id} "
            f"AND TABLE_METADATA_ID = {table_metadata_id} "
            f"AND STATUS NOT IN ('SUCCESS', 'WARNING')"
        )
        failure_result = await self.warehouse_proxy.execute_sync_query(failure_query)
        failure_count = (
            int(next(iter(failure_result[0].values())))
            if failure_result and failure_result[0]
            else 0
        )
        return failure_count == 0

    async def _generate_next_level(self, payload: EvaluateLevelResultPayload) -> None:
        """Generate and push tasks for the next validation level."""
        next_level = payload.next_level
        if next_level is None:
            return

        logger.info(
            "Generating %s level tasks for table_metadata_id=%d",
            next_level,
            payload.table_metadata_id,
        )

        if next_level == METRICS_VALIDATION:
            await self._push_metrics_chain(payload)
        elif next_level == ROW_VALIDATION:
            await self._push_row_chain(payload)
        else:
            logger.error("Unknown next level: %s", next_level)

    async def _push_metrics_chain(self, payload: EvaluateLevelResultPayload) -> None:
        """
        Push L2 metrics validation task chain.

        Reads L1 schema results to obtain column names and data types, then
        uses ``build_metrics_query`` to generate CTE-based per-column metrics
        queries for both source and target platforms.

        Column metadata is fetched and validated **before** any tasks are
        pushed so that a missing prerequisite (e.g. L1 results not yet
        written) marks the table as failed instead of creating orphaned
        tasks.
        """
        config_result = await self.warehouse_proxy.execute_sync_query(
            f"CALL {data_validation_full_schema()}.GET_TABLE_CONFIGURATION({payload.table_metadata_id})"
        )
        table_config_variant = (
            next(iter(config_result[0].values())) if config_result else None
        )
        table_config = (
            json.loads(table_config_variant)
            if isinstance(table_config_variant, str)
            else table_config_variant
        )

        column_mappings = (
            table_config.get(keys.COLUMN_MAPPINGS, {}) if table_config else {}
        )
        tolerance = 0.001
        row_enabled = (
            table_config.get(keys.ROW_VALIDATION, False) if table_config else False
        )
        row_validation_mode = (
            table_config.get(keys.ROW_VALIDATION_MODE, ROW_VALIDATION_MODE_ROW)
            if table_config
            else ROW_VALIDATION_MODE_ROW
        )

        next_level = ROW_VALIDATION if row_enabled else None
        next_level_enabled = next_level is not None

        partitions = await self._get_partitions(payload.table_metadata_id)

        if not partitions:
            partitions = [{"ID": None, "PARTITION_NUMBER": None}]

        partition_column = (
            table_config.get(keys.PARTITION_COLUMN) if table_config else None
        )
        user_source_where = (
            table_config.get(keys.WHERE_CLAUSE, "") if table_config else ""
        )
        user_target_where = (
            table_config.get(keys.TARGET_WHERE_CLAUSE, "") if table_config else ""
        )

        # --- Fetch and validate column metadata BEFORE pushing any tasks ---
        dea_factory = DEAPayloadFactory(
            workflow_id=payload.workflow_id,
            table_metadata_id=payload.table_metadata_id,
            source_identifier=payload.source_identifier,
            source_platform=payload.source_platform,
        )

        metrics_ctx = await self._fetch_metrics_column_metadata(
            workflow_id=payload.workflow_id,
            table_metadata_id=payload.table_metadata_id,
            source_identifier=payload.source_identifier,
            table_config=table_config or {},
            source_platform=payload.source_platform,
        )

        if not metrics_ctx[_CTX_SOURCE_COLUMNS] or not metrics_ctx[_CTX_TARGET_COLUMNS]:
            logger.error(
                "Cannot generate L2 metrics queries for %s "
                "(table_metadata_id=%d): missing column metadata "
                "(source=%d cols, target=%d cols). "
                "L1 schema results may not have been written yet. "
                "Marking table as FAILED.",
                payload.source_identifier,
                payload.table_metadata_id,
                len(metrics_ctx[_CTX_SOURCE_COLUMNS]),
                len(metrics_ctx[_CTX_TARGET_COLUMNS]),
            )
            await self.warehouse_proxy.execute_sync_query(
                f"CALL {data_validation_full_schema()}.UPDATE_TABLE_VALIDATION_STATUS("
                f"{payload.table_metadata_id}, '{TABLE_STATUS_FAILED}')"
            )
            return

        # --- All prerequisites validated — now push tasks ---

        # The evaluate task is a fan-in sink: blocked until ALL partition
        # write tasks complete (each write task's successor points here).
        evaluate_task = (
            TaskBuilder(
                workflow_id=payload.workflow_id,
                task_name=f"Evaluate L2 result for {payload.source_identifier}",
                executor_type=ExecutorType.ORCHESTRATOR,
                payload=EvaluateLevelResultPayload(
                    table_metadata_id=payload.table_metadata_id,
                    completed_level=METRICS_VALIDATION,
                    next_level=next_level,
                    continue_on_failure=payload.continue_on_failure,
                    next_level_enabled=next_level_enabled,
                    workflow_id=payload.workflow_id,
                    source_platform=payload.source_platform,
                    source_identifier=payload.source_identifier,
                    row_validation_mode=row_validation_mode,
                ),
                scope=build_evaluate_scope(
                    payload.source_identifier, METRICS_VALIDATION
                ),
            )
            .blocked()
            .build()
        )
        evaluate_task_id = await self.task_queue.push_task(evaluate_task)

        chains: list[tuple[Task, Task]] = []
        for partition in partitions:
            partition_num = partition.get(COL_PARTITION_NUMBER)
            min_val = partition.get(COL_MIN_VALUE)
            max_val = partition.get(COL_MAX_VALUE)

            source_where = self._build_scoped_where(
                user_source_where,
                partition_column,
                min_val,
                max_val,
                payload.source_platform,
                target_side=False,
            )
            target_where = self._build_scoped_where(
                user_target_where,
                partition_column,
                min_val,
                max_val,
                payload.source_platform,
                target_side=True,
            )

            source_query, target_query = self._build_partition_metrics_queries(
                metrics_ctx,
                source_platform=payload.source_platform,
                source_where_clause=source_where,
                target_where_clause=target_where,
            )

            stage_path = dea_factory.stage_path(METRICS_VALIDATION, partition_num)
            copy_query = self._build_metrics_copy_into_query(
                payload.workflow_id, payload.table_metadata_id, stage_path
            )

            dea_task = TaskBuilder(
                workflow_id=payload.workflow_id,
                task_name=f"Validate metrics for {payload.source_identifier} p{partition_num}",
                executor_type=ExecutorType.DATA_EXCHANGE_AGENT,
                payload=dea_factory.metrics_payload(
                    source_query=source_query,
                    target_query=target_query,
                    partition_number=partition_num,
                    column_mappings=column_mappings or None,
                    tolerance=tolerance,
                ),
                scope=build_validation_scope(
                    payload.source_identifier, METRICS_VALIDATION, partition_num
                ),
            ).build()

            write_task = (
                TaskBuilder(
                    workflow_id=payload.workflow_id,
                    task_name=f"Write L2 results for {payload.source_identifier} p{partition_num}",
                    executor_type=ExecutorType.ORCHESTRATOR,
                    payload=WriteValidationResultsPayload(
                        query=copy_query,
                        table_metadata_id=payload.table_metadata_id,
                        workflow_id=payload.workflow_id,
                        validation_level=METRICS_VALIDATION,
                    ),
                    scope=build_write_results_scope(
                        payload.source_identifier, METRICS_VALIDATION, partition_num
                    ),
                )
                .with_successor(evaluate_task_id)
                .build()
            )

            chains.append((dea_task, write_task))

        await self.task_queue.push_independent_two_task_chains(chains)

        logger.info(
            "Pushed L2 metrics chain for %s (%d partition(s))",
            payload.source_identifier,
            len(partitions),
        )

    async def _push_row_chain(self, payload: EvaluateLevelResultPayload) -> None:
        """
        Push L3 row/cell validation task chain.

        Reads the table configuration to determine the validation mode and
        gather the metadata the DEA needs. For row mode, builds payloads
        with index columns and column metadata for the MD5 pipeline. For
        cell mode, generates SELECT queries for direct comparison.

        Uses the same fan-in pattern as L2: a blocked evaluate task is
        unblocked after all partition write tasks complete.
        """
        config_result = await self.warehouse_proxy.execute_sync_query(
            f"CALL {data_validation_full_schema()}.GET_TABLE_CONFIGURATION({payload.table_metadata_id})"
        )
        table_config_variant = (
            next(iter(config_result[0].values())) if config_result else None
        )
        table_config = (
            json.loads(table_config_variant)
            if isinstance(table_config_variant, str)
            else table_config_variant
        ) or {}

        mode = payload.row_validation_mode or table_config.get(
            keys.ROW_VALIDATION_MODE, ROW_VALIDATION_MODE_ROW
        )

        src_db, src_schema, src_table = self._parse_fqn(payload.source_identifier)
        tgt_db = table_config.get(keys.TARGET_DATABASE, "")
        tgt_schema = table_config.get(keys.TARGET_SCHEMA, src_schema)
        tgt_table = table_config.get(keys.TARGET_NAME, src_table)

        src_fq = (
            f"{src_db}.{src_schema}.{src_table}"
            if src_db
            else f"{src_schema}.{src_table}"
        )
        tgt_fq = (
            f"{tgt_db}.{tgt_schema}.{tgt_table}"
            if tgt_db
            else f"{tgt_schema}.{tgt_table}"
        )

        index_column_list = table_config.get(keys.INDEX_COLUMN_LIST) or []
        target_index_column_list = (
            table_config.get(keys.TARGET_INDEX_COLUMN_LIST) or index_column_list
        )
        chunk_number = table_config.get(keys.CHUNK_NUMBER)
        max_failed_rows_number = table_config.get(keys.MAX_FAILED_ROWS_NUMBER)

        columns_metadata = await self._get_columns_metadata(
            payload.workflow_id,
            payload.table_metadata_id,
            payload.source_platform,
        )

        partitions = await self._get_partitions(payload.table_metadata_id)
        if not partitions:
            partitions = [{"ID": None, "PARTITION_NUMBER": None}]

        cell_metrics_ctx: dict[str, Any] | None = None
        if mode == ROW_VALIDATION_MODE_CELL:
            cell_metrics_ctx = await self._fetch_metrics_column_metadata(
                payload.workflow_id,
                payload.table_metadata_id,
                payload.source_identifier,
                table_config,
                payload.source_platform,
            )

        dea_factory = DEAPayloadFactory(
            workflow_id=payload.workflow_id,
            table_metadata_id=payload.table_metadata_id,
            source_identifier=payload.source_identifier,
            source_platform=payload.source_platform,
        )

        evaluate_task = (
            TaskBuilder(
                workflow_id=payload.workflow_id,
                task_name=f"Evaluate L3 result for {payload.source_identifier}",
                executor_type=ExecutorType.ORCHESTRATOR,
                payload=EvaluateLevelResultPayload(
                    table_metadata_id=payload.table_metadata_id,
                    completed_level=ROW_VALIDATION,
                    next_level=None,
                    continue_on_failure=payload.continue_on_failure,
                    next_level_enabled=False,
                    workflow_id=payload.workflow_id,
                    source_platform=payload.source_platform,
                    source_identifier=payload.source_identifier,
                    row_validation_mode=mode,
                ),
                scope=build_evaluate_scope(payload.source_identifier, ROW_VALIDATION),
            )
            .blocked()
            .build()
        )
        evaluate_task_id = await self.task_queue.push_task(evaluate_task)

        user_source_where = table_config.get(keys.WHERE_CLAUSE, "")
        user_target_where = table_config.get(keys.TARGET_WHERE_CLAUSE, "")
        partition_column = table_config.get(keys.PARTITION_COLUMN)

        chains: list[tuple[Task, Task]] = []
        for partition in partitions:
            partition_num = partition.get(COL_PARTITION_NUMBER)
            min_val = partition.get(COL_MIN_VALUE)
            max_val = partition.get(COL_MAX_VALUE)

            source_where = self._build_scoped_where(
                user_source_where,
                partition_column,
                min_val,
                max_val,
                payload.source_platform,
                target_side=False,
            )
            target_where = self._build_scoped_where(
                user_target_where,
                partition_column,
                min_val,
                max_val,
                payload.source_platform,
                target_side=True,
            )

            if mode == ROW_VALIDATION_MODE_CELL:
                normalized_pair = None
                if cell_metrics_ctx:
                    normalized_pair = build_normalized_cell_validation_queries(
                        payload.source_platform,
                        cell_metrics_ctx[_CTX_SRC_DB],
                        cell_metrics_ctx[_CTX_SRC_SCHEMA],
                        cell_metrics_ctx[_CTX_SRC_TABLE],
                        src_fq,
                        cell_metrics_ctx[_CTX_TGT_DB],
                        cell_metrics_ctx[_CTX_TGT_SCHEMA],
                        cell_metrics_ctx[_CTX_TGT_TABLE],
                        tgt_fq,
                        cell_metrics_ctx[_CTX_SOURCE_COLUMNS],
                        cell_metrics_ctx[_CTX_TARGET_COLUMNS],
                        source_where_clause=source_where,
                        target_where_clause=target_where,
                        order_by_columns=index_column_list or None,
                    )
                if normalized_pair:
                    source_query, target_query = normalized_pair
                else:
                    logger.warning(
                        "Cell validation: could not build normalized queries for %s "
                        "(missing or misaligned column metadata); using raw SELECT *",
                        payload.source_identifier,
                    )
                    source_query, target_query = build_cell_validation_queries(
                        src_fq,
                        tgt_fq,
                        source_where,
                        target_where,
                        order_by_columns=index_column_list or None,
                    )

                stage_path = dea_factory.stage_path("cell", partition_num)
                copy_query = self._build_cell_diffs_copy_query(stage_path)

                dea_task = TaskBuilder(
                    workflow_id=payload.workflow_id,
                    task_name=f"Validate cells for {payload.source_identifier} p{partition_num}",
                    executor_type=ExecutorType.DATA_EXCHANGE_AGENT,
                    payload=dea_factory.cell_payload(
                        source_query=source_query,
                        target_query=target_query,
                        partition_number=partition_num,
                        source_table_fqn=src_fq,
                        target_table_fqn=tgt_fq,
                        index_column_list=index_column_list,
                    ),
                    scope=build_validation_scope(
                        payload.source_identifier, ROW_VALIDATION, partition_num
                    ),
                ).build()
            else:
                stage_path = dea_factory.stage_path("row", partition_num)
                copy_diffs = self._build_row_diffs_copy_query(stage_path)
                copy_summary = self._build_row_summary_copy_query(stage_path)
                copy_hashes = self._build_chunk_hashes_copy_query(stage_path)
                copy_query = f"{copy_diffs}; {copy_summary}; {copy_hashes}"

                dea_task = TaskBuilder(
                    workflow_id=payload.workflow_id,
                    task_name=f"Validate rows for {payload.source_identifier} p{partition_num}",
                    executor_type=ExecutorType.DATA_EXCHANGE_AGENT,
                    payload=dea_factory.row_payload(
                        partition_number=partition_num,
                        index_column_list=index_column_list,
                        target_index_column_list=target_index_column_list,
                        source_table_fqn=src_fq,
                        target_table_fqn=tgt_fq,
                        chunk_number=chunk_number,
                        max_failed_rows_number=max_failed_rows_number,
                        columns_metadata=columns_metadata,
                        source_where_clause=source_where or None,
                        target_where_clause=target_where or None,
                    ),
                    scope=build_validation_scope(
                        payload.source_identifier, ROW_VALIDATION, partition_num
                    ),
                ).build()

            write_task = (
                TaskBuilder(
                    workflow_id=payload.workflow_id,
                    task_name=f"Write L3 results for {payload.source_identifier} p{partition_num}",
                    executor_type=ExecutorType.ORCHESTRATOR,
                    payload=WriteValidationResultsPayload(
                        query=copy_query,
                        table_metadata_id=payload.table_metadata_id,
                        workflow_id=payload.workflow_id,
                        validation_level=ROW_VALIDATION,
                    ),
                    scope=build_write_results_scope(
                        payload.source_identifier, ROW_VALIDATION, partition_num
                    ),
                )
                .with_successor(evaluate_task_id)
                .build()
            )

            chains.append((dea_task, write_task))

        await self.task_queue.push_independent_two_task_chains(chains)

        logger.info(
            "Pushed L3 %s chain for %s (%d partition(s))",
            mode,
            payload.source_identifier,
            len(partitions),
        )

    async def _get_columns_metadata(
        self,
        workflow_id: int,
        table_metadata_id: int,
        source_platform: str,
    ) -> list[ColumnMetadataDict]:
        """
        Read source column names + data types from L1 schema results.

        If no results found (e.g. due to the COPY INTO not having run yet),
        attempts to re-run the COPY INTO from the stage as a fallback.
        """
        columns = await self._query_schema_columns(
            workflow_id, table_metadata_id, source_platform
        )
        if columns:
            return columns

        logger.warning(
            "No L1 schema results found for workflow=%d, table_metadata_id=%d. "
            "Attempting to load from stage as fallback.",
            workflow_id,
            table_metadata_id,
        )
        stage_path = (
            f"@{task_results_stage()}/{workflow_id}/{table_metadata_id}/schema/"
        )
        # Remove any stale rows for this table before re-loading so that
        # FORCE=TRUE does not create duplicates.
        delete_sql = (
            f"DELETE FROM {fq_schema_validation_results()} "
            f"WHERE WORKFLOW_ID = {workflow_id} "
            f"AND TABLE_METADATA_ID = {table_metadata_id}"
        )
        copy_sql = (
            f"COPY INTO {fq_schema_validation_results()} "
            f"(WORKFLOW_ID, TABLE_METADATA_ID, VALIDATION_TYPE, TABLE_NAME, "
            f"COLUMN_VALIDATED, EVALUATION_CRITERIA, SOURCE_VALUE, "
            f"SNOWFLAKE_VALUE, STATUS, COMMENTS) "
            f"FROM (SELECT $1, $2, $3, $4, $5, $6, $7, $8, $9, $10 "
            f"FROM '{stage_path}') "
            f"FILE_FORMAT = (FORMAT_NAME = '{validation_csv_file_format_fqn()}') "
            f"FORCE = TRUE ON_ERROR = 'CONTINUE'"
        )
        try:
            await self.warehouse_proxy.execute_sync_query(delete_sql)
            await self.warehouse_proxy.execute_sync_query(copy_sql)
        except Exception:
            logger.warning(
                "Fallback COPY INTO failed for workflow=%d, table_metadata_id=%d",
                workflow_id,
                table_metadata_id,
                exc_info=True,
            )

        return await self._query_schema_columns(
            workflow_id, table_metadata_id, source_platform
        )

    async def _query_schema_columns(
        self,
        workflow_id: int,
        table_metadata_id: int,
        source_platform: str,
    ) -> list[ColumnMetadataDict]:
        """Query SCHEMA_VALIDATION_RESULTS for column metadata."""
        schema_rows = await self.warehouse_proxy.execute_sync_query(
            f"SELECT COLUMN_VALIDATED, SOURCE_VALUE "
            f"FROM {fq_schema_validation_results()} "
            f"WHERE WORKFLOW_ID = {workflow_id} "
            f"AND TABLE_METADATA_ID = {table_metadata_id} "
            f"AND EVALUATION_CRITERIA = 'DATA_TYPE' "
            f"AND SOURCE_VALUE != 'MISSING'"
        )
        columns: list[ColumnMetadataDict] = []
        if schema_rows:
            for row in schema_rows:
                col_name = row.get(COL_COLUMN_VALIDATED, "")
                src_type = row.get(COL_SOURCE_VALUE, "")
                if col_name and src_type:
                    if source_platform and source_platform.lower() == "redshift":
                        col_name = col_name.lower()
                    elif source_platform and source_platform.lower() == "teradata":
                        col_name = col_name.upper()
                    columns.append({"name": col_name, "data_type": src_type})
        return columns

    @staticmethod
    def _parse_fqn(fqn: str) -> tuple[str, str, str]:
        """Parse a 'db.schema.table' fully qualified name into parts."""
        parts = fqn.split(".")
        if len(parts) == 3:
            return parts[0], parts[1], parts[2]
        if len(parts) == 2:
            return "", parts[0], parts[1]
        return "", "", parts[0]

    async def _fetch_metrics_column_metadata(
        self,
        workflow_id: int,
        table_metadata_id: int,
        source_identifier: str,
        table_config: dict,
        source_platform: str,
    ) -> dict:
        """
        Fetch source and target column metadata needed for L2 metrics queries.

        Queries ``SCHEMA_VALIDATION_RESULTS`` for source column data types and
        ``information_schema.columns`` for target columns. The result dict is
        partition-independent and should be fetched once per table, then passed
        to :meth:`_build_partition_metrics_queries` for each partition.
        """
        src_db, src_schema, src_table = EvaluateLevelResultHandler._parse_fqn(
            source_identifier
        )
        tgt_db = table_config.get(keys.TARGET_DATABASE, "")
        tgt_schema = table_config.get(keys.TARGET_SCHEMA, src_schema)
        tgt_table = table_config.get(keys.TARGET_NAME, src_table)

        schema_rows = await self.warehouse_proxy.execute_sync_query(
            f"SELECT COLUMN_VALIDATED, SOURCE_VALUE "
            f"FROM {fq_schema_validation_results()} "
            f"WHERE WORKFLOW_ID = {workflow_id} "
            f"AND TABLE_METADATA_ID = {table_metadata_id} "
            f"AND EVALUATION_CRITERIA = 'DATA_TYPE' "
            f"AND SOURCE_VALUE != 'MISSING'"
        )

        source_columns = []
        if schema_rows:
            for row in schema_rows:
                col_name = row.get(COL_COLUMN_VALIDATED, "")
                src_type = row.get(COL_SOURCE_VALUE, "")
                if col_name and src_type:
                    if source_platform and source_platform.lower() == "redshift":
                        col_name = col_name.lower()
                    elif source_platform and source_platform.lower() == "teradata":
                        col_name = col_name.upper()
                    source_columns.append(
                        make_column_metadata(name=col_name, data_type=src_type)
                    )

        tgt_fq_prefix = f"{tgt_db}." if tgt_db else ""
        target_col_rows = await self.warehouse_proxy.execute_sync_query(
            f"SELECT column_name, data_type "
            f"FROM {tgt_fq_prefix}information_schema.columns "
            f"WHERE table_schema = '{tgt_schema.upper()}' "
            f"AND table_name = '{tgt_table.upper()}' "
            f"ORDER BY ordinal_position"
        )

        target_columns = []
        if target_col_rows:
            for row in target_col_rows:
                col_name = row.get(COL_COLUMN_NAME, row.get("column_name", ""))
                data_type = row.get(COL_DATA_TYPE, row.get("data_type", ""))
                if col_name and data_type:
                    target_columns.append(
                        make_column_metadata(name=col_name, data_type=data_type)
                    )

        src_fq = (
            f"{src_db}.{src_schema}.{src_table}"
            if src_db
            else f"{src_schema}.{src_table}"
        )
        tgt_fq = (
            f"{tgt_db}.{tgt_schema}.{tgt_table}"
            if tgt_db
            else f"{tgt_schema}.{tgt_table}"
        )

        return {
            _CTX_SOURCE_COLUMNS: source_columns,
            _CTX_TARGET_COLUMNS: target_columns,
            _CTX_SRC_DB: src_db,
            _CTX_SRC_SCHEMA: src_schema,
            _CTX_SRC_TABLE: src_table,
            _CTX_TGT_DB: tgt_db,
            _CTX_TGT_SCHEMA: tgt_schema,
            _CTX_TGT_TABLE: tgt_table,
            _CTX_SRC_FQ: src_fq,
            _CTX_TGT_FQ: tgt_fq,
        }

    @staticmethod
    def _build_partition_metrics_queries(
        metrics_ctx: dict,
        source_platform: str,
        source_where_clause: str = "",
        target_where_clause: str = "",
    ) -> tuple[str, str]:
        """
        Build per-column metrics queries for a single partition.

        Uses pre-fetched column metadata from :meth:`_fetch_metrics_column_metadata`
        and partition-specific WHERE clauses.
        """
        return build_metrics_queries(
            source_platform_str=source_platform or "redshift",
            source_db=metrics_ctx[_CTX_SRC_DB],
            source_schema=metrics_ctx[_CTX_SRC_SCHEMA],
            source_table=metrics_ctx[_CTX_SRC_TABLE],
            source_columns=metrics_ctx[_CTX_SOURCE_COLUMNS],
            target_db=metrics_ctx[_CTX_TGT_DB],
            target_schema=metrics_ctx[_CTX_TGT_SCHEMA],
            target_table=metrics_ctx[_CTX_TGT_TABLE],
            target_columns=metrics_ctx[_CTX_TARGET_COLUMNS],
            source_fqn=metrics_ctx[_CTX_SRC_FQ],
            target_fqn=metrics_ctx[_CTX_TGT_FQ],
            source_where_clause=source_where_clause,
            target_where_clause=target_where_clause,
        )

    @staticmethod
    def _build_scoped_where(
        user_where: str,
        partition_column: str | None,
        min_value: Any,
        max_value: Any,
        source_platform: str,
        *,
        target_side: bool,
    ) -> str:
        """
        Combine a user WHERE clause with a partition range condition.

        Delegates to ``build_snowflake_partition_condition`` for Snowflake
        target-side conditions and to the source platform's query builder
        (via :class:`PlatformRegistry`) for source-side conditions.  Virtual
        partitions (both bounds ``None``) pass through the user clause
        unchanged.
        """
        if not partition_column or (min_value is None and max_value is None):
            return user_where

        if target_side:
            range_clause = build_snowflake_partition_condition(
                partition_column,
                min_value,
                max_value,
            )
        else:
            try:
                platform = PlatformRegistry.create_by_name_or_alias(
                    source_platform,
                )
                range_clause = platform.query_builder.build_partition_condition(
                    partition_column,
                    min_value,
                    max_value,
                )
            except (KeyError, ValueError):
                range_clause = build_snowflake_partition_condition(
                    partition_column,
                    min_value,
                    max_value,
                )

        if range_clause == "1=1":
            return user_where

        if user_where:
            return f"({user_where}) AND {range_clause}"
        return range_clause

    async def _get_partitions(self, table_metadata_id: int) -> list[dict]:
        """Get partition metadata for a table, returns empty list if none."""
        result = await self.warehouse_proxy.execute_sync_query(
            f"CALL {data_validation_full_schema()}.GET_PARTITION_METADATA({table_metadata_id})"
        )
        if not result:
            return []
        if isinstance(result, list):
            return result
        return []

    @staticmethod
    def _build_metrics_copy_into_query(
        workflow_id: int, table_metadata_id: int, stage_path: str
    ) -> str:
        """Build COPY INTO SQL for metrics validation results."""
        return (
            f"COPY INTO {fq_metrics_validation_results()} "
            f"(WORKFLOW_ID, TABLE_METADATA_ID, VALIDATION_TYPE, TABLE_NAME, "
            f"COLUMN_VALIDATED, EVALUATION_CRITERIA, SOURCE_VALUE, "
            f"SNOWFLAKE_VALUE, STATUS, COMMENTS) "
            f"FROM (SELECT "
            f"$1, $2, $3, $4, $5, $6, $7, $8, $9, $10 "
            f"FROM '{stage_path}/') "
            f"FILE_FORMAT = (FORMAT_NAME = '{validation_csv_file_format_fqn()}') "
            f"ON_ERROR = 'CONTINUE'"
        )

    @staticmethod
    def _build_row_diffs_copy_query(stage_path: str) -> str:
        """Build COPY INTO SQL for row validation diffs."""
        return (
            f"COPY INTO {fq_row_validation_results()} "
            f"(WORKFLOW_ID, TABLE_METADATA_ID, TABLE_NAME, "
            f"OBJECT_TYPE, RESULT, SOURCE_INDEX_VALUES, TARGET_INDEX_VALUES, "
            f"TARGET_TABLE_NAME) "
            f"FROM (SELECT "
            f"$1, $2, $3, $4, $5, $6, $7, $8 "
            f"FROM '{stage_path}/diffs/') "
            f"FILE_FORMAT = (FORMAT_NAME = '{validation_csv_file_format_fqn()}') "
            f"ON_ERROR = 'CONTINUE'"
        )

    @staticmethod
    def _build_row_summary_copy_query(stage_path: str) -> str:
        """Build COPY INTO SQL for row validation summary."""
        return (
            f"COPY INTO {fq_row_validation_summary()} "
            f"(WORKFLOW_ID, TABLE_METADATA_ID, TABLE_NAME, TOTAL_CHUNKS, "
            f"MATCHING_CHUNKS, DIFFERING_CHUNKS, TOTAL_ROWS_COMPARED, "
            f"ROWS_NOT_FOUND_IN_TARGET, ROWS_NOT_FOUND_IN_SOURCE, "
            f"ROWS_WITH_DIFFERENCES, IS_VALID) "
            f"FROM (SELECT "
            f"$1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11 "
            f"FROM '{stage_path}/summary/') "
            f"FILE_FORMAT = (FORMAT_NAME = '{validation_csv_file_format_fqn()}') "
            f"ON_ERROR = 'CONTINUE'"
        )

    @staticmethod
    def _build_chunk_hashes_copy_query(stage_path: str) -> str:
        """Build COPY INTO SQL for chunk hashes."""
        return (
            f"COPY INTO {fq_chunk_hashes()} "
            f"(WORKFLOW_ID, TABLE_METADATA_ID, TABLE_NAME, CHUNK_ID, "
            f"SOURCE_HASH, TARGET_HASH, IS_MATCH) "
            f"FROM (SELECT "
            f"$1, $2, $3, $4, $5, $6, $7 "
            f"FROM '{stage_path}/hashes/') "
            f"FILE_FORMAT = (FORMAT_NAME = '{validation_csv_file_format_fqn()}') "
            f"ON_ERROR = 'CONTINUE'"
        )

    @staticmethod
    def _build_cell_diffs_copy_query(stage_path: str) -> str:
        """Build COPY INTO SQL for cell validation diffs."""
        return (
            f"COPY INTO {fq_cell_validation_results()} "
            f"(WORKFLOW_ID, TABLE_METADATA_ID, TABLE_NAME, "
            f"ROW_INDEX, COLUMN_NAME, SOURCE_VALUE, TARGET_VALUE) "
            f"FROM (SELECT "
            f"$1, $2, $3, $4, $5, $6, $7 "
            f"FROM '{stage_path}/diffs/') "
            f"FILE_FORMAT = (FORMAT_NAME = '{validation_csv_file_format_fqn()}') "
            f"ON_ERROR = 'CONTINUE'"
        )
