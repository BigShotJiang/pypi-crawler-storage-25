"""Map raw task payload dictionaries to typed data validation payload dataclasses."""

from data_migration_orchestrator.data_validation_cloud.tasks.models.task_payload import (
    DataValidationTaskPayload,
    DataValidationTaskPayloadUnion,
    EvaluateLevelResultPayload,
    ExtractSourceMetadataPayload,
    GenerateValidationQueriesPayload,
    SnowflakeQueryTaskPayload,
    WriteValidationResultsPayload,
)
from data_migration_orchestrator.data_validation_cloud.tasks.models.task_payload_kind import (
    DataValidationTaskPayloadKind,
)


def map_data_validation_task_payload(
    kind: str, payload_dict: dict
) -> DataValidationTaskPayloadUnion:
    """Map a task payload dictionary to the appropriate dataclass based on kind."""
    match kind:
        case DataValidationTaskPayloadKind.EXTRACT_SOURCE_METADATA.value:
            return ExtractSourceMetadataPayload(**payload_dict)
        case DataValidationTaskPayloadKind.GENERATE_VALIDATION_QUERIES.value:
            return GenerateValidationQueriesPayload(**payload_dict)
        case DataValidationTaskPayloadKind.EVALUATE_LEVEL_RESULT.value:
            return EvaluateLevelResultPayload(**payload_dict)
        case DataValidationTaskPayloadKind.DATA_VALIDATION.value:
            return DataValidationTaskPayload(**payload_dict)
        case DataValidationTaskPayloadKind.WRITE_VALIDATION_RESULTS.value:
            return WriteValidationResultsPayload(**payload_dict)
        case DataValidationTaskPayloadKind.SNOWFLAKE_QUERY.value:
            return SnowflakeQueryTaskPayload(**payload_dict)
        case _:
            raise ValueError(f"Unknown data validation task payload kind: {kind}")
