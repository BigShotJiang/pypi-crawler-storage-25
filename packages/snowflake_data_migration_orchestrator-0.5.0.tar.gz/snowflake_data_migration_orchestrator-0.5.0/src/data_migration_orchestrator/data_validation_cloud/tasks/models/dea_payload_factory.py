"""
Factory for building DEA-bound ``DataValidationTaskPayload`` instances.

Centralises the boilerplate shared across schema / metrics / row validation
payloads (workflow context, stage path construction, target type) so that
handler code only has to supply the level-specific parameters.
"""

from __future__ import annotations

from data_migration_orchestrator.data_validation_cloud.constants.stages import (
    default_internal_stage,
)
from data_migration_orchestrator.data_validation_cloud.tasks.models.task_payload import (
    ColumnMetadataDict,
    DataValidationTaskPayload,
)
from data_migration_orchestrator.data_validation_core.constants import (
    METRICS_VALIDATION,
    ROW_VALIDATION,
    SCHEMA_VALIDATION,
    RowValidationMode,
)


class DEAPayloadFactory:
    """Builds ``DataValidationTaskPayload`` for a given table within a workflow."""

    def __init__(
        self,
        workflow_id: int,
        table_metadata_id: int,
        source_identifier: str,
        source_platform: str,
    ) -> None:
        """Initialize the factory with shared workflow context."""
        self.workflow_id = workflow_id
        self.table_metadata_id = table_metadata_id
        self.source_identifier = source_identifier
        self.source_platform = source_platform

    def stage_path(
        self,
        level: str,
        partition_number: int | None = None,
    ) -> str:
        """Build the Snowflake stage path for a validation level + partition."""
        base = (
            f"{default_internal_stage()}/{self.workflow_id}"
            f"/{self.table_metadata_id}/{level}"
        )
        if partition_number is not None:
            return f"{base}/p{partition_number}"
        return base

    def schema_payload(
        self,
        *,
        source_query: str,
        target_query: str,
        column_mappings: dict[str, str] | None = None,
        datatypes_mappings: dict[str, str] | None = None,
    ) -> DataValidationTaskPayload:
        """Create a DEA payload for L1 schema validation."""
        return DataValidationTaskPayload(
            source_query=source_query,
            target_query=target_query,
            validation_type=SCHEMA_VALIDATION,
            source_platform=self.source_platform,
            target_type="snowflake:stage",
            target_id=self.stage_path("schema"),
            table_name=self.source_identifier,
            table_metadata_id=self.table_metadata_id,
            workflow_id=self.workflow_id,
            partition_number=None,
            database="",
            schema="",
            column_mappings=column_mappings,
            datatypes_mappings=datatypes_mappings,
        )

    def metrics_payload(
        self,
        *,
        source_query: str,
        target_query: str,
        partition_number: int | None = None,
        column_mappings: dict[str, str] | None = None,
        tolerance: float | None = None,
    ) -> DataValidationTaskPayload:
        """Create a DEA payload for L2 metrics validation."""
        return DataValidationTaskPayload(
            source_query=source_query,
            target_query=target_query,
            validation_type=METRICS_VALIDATION,
            source_platform=self.source_platform,
            target_type="snowflake:stage",
            target_id=self.stage_path("metrics", partition_number),
            table_name=self.source_identifier,
            table_metadata_id=self.table_metadata_id,
            workflow_id=self.workflow_id,
            partition_number=partition_number,
            database="",
            schema="",
            column_mappings=column_mappings,
            tolerance=tolerance,
        )

    def row_payload(
        self,
        *,
        partition_number: int | None = None,
        index_column_list: list[str] | None = None,
        target_index_column_list: list[str] | None = None,
        source_table_fqn: str | None = None,
        target_table_fqn: str | None = None,
        chunk_number: int | None = None,
        max_failed_rows_number: int | None = None,
        columns_metadata: list[ColumnMetadataDict] | None = None,
        source_where_clause: str | None = None,
        target_where_clause: str | None = None,
    ) -> DataValidationTaskPayload:
        """Create a DEA payload for L3 row-by-row (MD5) validation."""
        return DataValidationTaskPayload(
            source_query="",
            target_query="",
            validation_type=ROW_VALIDATION,
            source_platform=self.source_platform,
            target_type="snowflake:stage",
            target_id=self.stage_path("row", partition_number),
            table_name=self.source_identifier,
            table_metadata_id=self.table_metadata_id,
            workflow_id=self.workflow_id,
            partition_number=partition_number,
            database="",
            schema="",
            row_validation_mode=RowValidationMode.ROW,
            index_column_list=index_column_list,
            target_index_column_list=target_index_column_list,
            source_table_fqn=source_table_fqn,
            target_table_fqn=target_table_fqn,
            chunk_number=chunk_number,
            max_failed_rows_number=max_failed_rows_number,
            columns_metadata=columns_metadata,
            source_where_clause=source_where_clause,
            target_where_clause=target_where_clause,
        )

    def cell_payload(
        self,
        *,
        source_query: str,
        target_query: str,
        partition_number: int | None = None,
        source_table_fqn: str | None = None,
        target_table_fqn: str | None = None,
        index_column_list: list[str] | None = None,
    ) -> DataValidationTaskPayload:
        """Create a DEA payload for L3 cell-by-cell validation."""
        return DataValidationTaskPayload(
            source_query=source_query,
            target_query=target_query,
            validation_type=ROW_VALIDATION,
            source_platform=self.source_platform,
            target_type="snowflake:stage",
            target_id=self.stage_path("cell", partition_number),
            table_name=self.source_identifier,
            table_metadata_id=self.table_metadata_id,
            workflow_id=self.workflow_id,
            partition_number=partition_number,
            database="",
            schema="",
            row_validation_mode=RowValidationMode.CELL,
            source_table_fqn=source_table_fqn,
            target_table_fqn=target_table_fqn,
            index_column_list=index_column_list,
        )
