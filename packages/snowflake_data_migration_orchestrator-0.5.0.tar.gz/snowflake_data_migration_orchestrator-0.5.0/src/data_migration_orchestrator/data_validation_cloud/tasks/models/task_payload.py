"""Task payload dataclasses for data validation workflows."""

from dataclasses import dataclass
from typing import Literal, TypedDict

from data_migration_orchestrator.cloud_core.tasks.snowflake_query_task import (
    SnowflakeQueryTaskPayload,
)
from data_migration_orchestrator.data_validation_cloud.tasks.models.task_payload_kind import (
    DataValidationTaskPayloadKind,
)
from data_migration_orchestrator.data_validation_core.constants import (
    RowValidationMode,
)


# ==================== ORCHESTRATOR PAYLOADS ====================


@dataclass
class ExtractSourceMetadataPayload:
    """Payload for the metadata extraction task (reuses DEA data_movement)."""

    table_metadata_id: int
    source_identifier: str
    workflow_id: int
    source_platform: str
    kind: Literal[DataValidationTaskPayloadKind.EXTRACT_SOURCE_METADATA] = (
        DataValidationTaskPayloadKind.EXTRACT_SOURCE_METADATA
    )


@dataclass
class GenerateValidationQueriesPayload:
    """Payload for the query generation + partitioning orchestrator task."""

    table_metadata_id: int
    source_identifier: str
    workflow_id: int
    source_platform: str
    kind: Literal[DataValidationTaskPayloadKind.GENERATE_VALIDATION_QUERIES] = (
        DataValidationTaskPayloadKind.GENERATE_VALIDATION_QUERIES
    )


@dataclass
class EvaluateLevelResultPayload:
    """Payload for the level-gating orchestrator task."""

    table_metadata_id: int
    completed_level: str
    next_level: str | None
    continue_on_failure: bool
    next_level_enabled: bool
    workflow_id: int
    source_platform: str
    source_identifier: str
    row_validation_mode: RowValidationMode | None = None
    kind: Literal[DataValidationTaskPayloadKind.EVALUATE_LEVEL_RESULT] = (
        DataValidationTaskPayloadKind.EVALUATE_LEVEL_RESULT
    )


# ==================== DEA PAYLOADS ====================


class ColumnMetadataDict(TypedDict):
    """Shape of each entry in the ``columns_metadata`` payload list."""

    name: str
    data_type: str


@dataclass
class DataValidationTaskPayload:
    """Payload sent from orchestrator to DEA for validation execution."""

    source_query: str
    target_query: str
    validation_type: str
    source_platform: str
    target_type: str
    target_id: str
    table_name: str
    table_metadata_id: int
    workflow_id: int
    partition_number: int | None
    database: str
    schema: str
    column_mappings: dict[str, str] | None = None
    datatypes_mappings: dict[str, str] | None = None
    tolerance: float | None = None
    use_database_command: str | None = None
    row_validation_mode: RowValidationMode | None = None
    index_column_list: list[str] | None = None
    target_index_column_list: list[str] | None = None
    source_table_fqn: str | None = None
    target_table_fqn: str | None = None
    chunk_number: int | None = None
    max_failed_rows_number: int | None = None
    columns_metadata: list[ColumnMetadataDict] | None = None
    source_where_clause: str | None = None
    target_where_clause: str | None = None
    kind: Literal[DataValidationTaskPayloadKind.DATA_VALIDATION] = (
        DataValidationTaskPayloadKind.DATA_VALIDATION
    )


# ==================== WAREHOUSE PAYLOADS ====================


@dataclass
class WriteValidationResultsPayload:
    """Payload for the warehouse COPY INTO task (wraps SnowflakeQueryTaskPayload)."""

    query: str
    table_metadata_id: int
    workflow_id: int
    validation_level: str
    query_id: str | None = None
    kind: Literal[DataValidationTaskPayloadKind.WRITE_VALIDATION_RESULTS] = (
        DataValidationTaskPayloadKind.WRITE_VALIDATION_RESULTS
    )


# ==================== UNION TYPE ====================

DataValidationTaskPayloadUnion = (
    ExtractSourceMetadataPayload
    | GenerateValidationQueriesPayload
    | EvaluateLevelResultPayload
    | DataValidationTaskPayload
    | WriteValidationResultsPayload
    | SnowflakeQueryTaskPayload
)
