"""
Scope utilities for data validation tasks.

Scopes follow a hierarchical format:
    DV::Table[db.schema.table]::SchemaValidation
    DV::Table[db.schema.table]::Partition[2]::MetricsValidation
    DV::Table[db.schema.table]::Partition[2]::RowValidation
"""

from __future__ import annotations

from enum import StrEnum


FRAGMENT_SEPARATOR = "::"


class ValidationScopeOperation(StrEnum):
    """Operations in the data validation scope hierarchy."""

    PREPROCESSING = "Preprocessing"
    SCHEMA_VALIDATION = "SchemaValidation"
    METRICS_VALIDATION = "MetricsValidation"
    ROW_VALIDATION = "RowValidation"
    EVALUATE = "Evaluate"
    WRITE_RESULTS = "WriteResults"


def build_table_scope(source_identifier: str) -> str:
    """Build the base table scope fragment."""
    return f"DV{FRAGMENT_SEPARATOR}Table[{source_identifier}]"


def build_preprocessing_scope(source_identifier: str) -> str:
    """Build a preprocessing scope for metadata extraction."""
    return f"{build_table_scope(source_identifier)}{FRAGMENT_SEPARATOR}{ValidationScopeOperation.PREPROCESSING}"


def build_validation_scope(
    source_identifier: str,
    validation_level: str,
    partition_number: int | None = None,
) -> str:
    """Build a validation scope for a specific level and optional partition."""
    op = _level_to_operation(validation_level)
    base = build_table_scope(source_identifier)
    if partition_number is not None:
        return f"{base}{FRAGMENT_SEPARATOR}Partition[{partition_number}]{FRAGMENT_SEPARATOR}{op}"
    return f"{base}{FRAGMENT_SEPARATOR}{op}"


def build_evaluate_scope(source_identifier: str, completed_level: str) -> str:
    """Build a scope for a level evaluation task."""
    return f"{build_table_scope(source_identifier)}{FRAGMENT_SEPARATOR}{ValidationScopeOperation.EVALUATE}[{completed_level}]"


def build_write_results_scope(
    source_identifier: str,
    validation_level: str,
    partition_number: int | None = None,
) -> str:
    """Build a scope for a write-results task."""
    base = build_table_scope(source_identifier)
    level_fragment = f"[{validation_level}]"
    if partition_number is not None:
        return (
            f"{base}{FRAGMENT_SEPARATOR}Partition[{partition_number}]"
            f"{FRAGMENT_SEPARATOR}{ValidationScopeOperation.WRITE_RESULTS}{level_fragment}"
        )
    return f"{base}{FRAGMENT_SEPARATOR}{ValidationScopeOperation.WRITE_RESULTS}{level_fragment}"


def _level_to_operation(validation_level: str) -> str:
    """Map a validation level string to a scope operation."""
    mapping = {
        "schema": ValidationScopeOperation.SCHEMA_VALIDATION,
        "metrics": ValidationScopeOperation.METRICS_VALIDATION,
        "row": ValidationScopeOperation.ROW_VALIDATION,
    }
    op = mapping.get(validation_level)
    if op is None:
        raise ValueError(f"Unknown validation level: {validation_level}")
    return op
