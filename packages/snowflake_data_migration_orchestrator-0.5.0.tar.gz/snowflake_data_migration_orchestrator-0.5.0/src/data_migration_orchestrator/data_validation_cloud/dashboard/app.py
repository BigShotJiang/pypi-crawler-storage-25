"""
Data Validation Dashboard.

Monitor and explore data validation results across workflows.
Designed for Streamlit in Snowflake (SiS).
"""

import pandas as pd
import streamlit as st

from snowflake.snowpark.context import get_active_session


try:
    from sis_streamlit_metadata import (
        migration_schema_for_streamlit_dashboard,
        validation_schema_for_streamlit_dashboard,
    )
except ModuleNotFoundError:
    from data_migration_orchestrator.utils.sis_streamlit_metadata import (
        migration_schema_for_streamlit_dashboard,
        validation_schema_for_streamlit_dashboard,
    )


RESULT_STATUSES = ["SUCCESS", "WARNING", "FAILURE"]

STATUS_DISPLAY = {
    "SUCCESS": "Success",
    "WARNING": "Warning",
    "FAILURE": "Failure",
}

STATUS_EMOJI = {
    "SUCCESS": "🟢",
    "WARNING": "🟡",
    "FAILURE": "🔴",
}

st.set_page_config(
    page_title="Data Validation Dashboard",
    page_icon="🔍",
    layout="wide",
)

session = get_active_session()


def run_query(sql: str) -> pd.DataFrame:
    """Execute a query and return results as a pandas DataFrame."""
    return session.sql(sql).to_pandas()


# ---------------------------------------------------------------------------
# Data loaders
# ---------------------------------------------------------------------------


@st.cache_data(ttl=60)
def get_workflows():
    """Fetch workflows that have DV data, returning id→name mapping."""
    try:
        df = run_query(
            f"""
            SELECT DISTINCT tm.WORKFLOW_ID, w.NAME
            FROM {validation_schema_for_streamlit_dashboard()}.TABLE_METADATA tm
            JOIN {migration_schema_for_streamlit_dashboard()}.WORKFLOW w ON tm.WORKFLOW_ID = w.ID
            ORDER BY tm.WORKFLOW_ID DESC
            """
        )
        if len(df) > 0:
            return dict(
                zip(df["WORKFLOW_ID"].tolist(), df["NAME"].tolist(), strict=False)
            )
        return {}
    except Exception:
        return {}


@st.cache_data(ttl=30)
def get_table_metadata(workflow_id: int | None = None):
    """Fetch table metadata with validation status."""
    try:
        where = f"WHERE WORKFLOW_ID = {workflow_id}" if workflow_id else ""
        return run_query(
            f"""
            SELECT
                ID,
                WORKFLOW_ID,
                SOURCE_IDENTIFIER,
                TARGET_IDENTIFIER,
                HAS_BEEN_PREPROCESSED,
                VALIDATION_STATUS,
                CREATED_AT,
                UPDATED_AT
            FROM {validation_schema_for_streamlit_dashboard()}.TABLE_METADATA
            {where}
            ORDER BY
                CASE VALIDATION_STATUS
                    WHEN 'FAILED' THEN 0
                    WHEN 'IN_PROGRESS' THEN 1
                    WHEN 'PENDING' THEN 2
                    WHEN 'COMPLETED' THEN 3
                    ELSE 4
                END,
                SOURCE_IDENTIFIER
            """
        )
    except Exception:
        return pd.DataFrame()


@st.cache_data(ttl=30)
def get_overview_metrics(workflow_id: int | None = None):
    """Aggregate KPIs across all validation result tables."""
    try:
        wf_filter = f"WHERE WORKFLOW_ID = {workflow_id}" if workflow_id else ""
        tm_filter = f"WHERE tm.WORKFLOW_ID = {workflow_id}" if workflow_id else ""

        return run_query(
            f"""
            WITH table_counts AS (
                SELECT
                    COUNT(*) AS total_tables,
                    SUM(CASE WHEN VALIDATION_STATUS = 'COMPLETED' THEN 1 ELSE 0 END) AS completed_tables,
                    SUM(CASE WHEN VALIDATION_STATUS = 'FAILED' THEN 1 ELSE 0 END) AS failed_tables,
                    SUM(CASE WHEN VALIDATION_STATUS = 'IN_PROGRESS' THEN 1 ELSE 0 END) AS in_progress_tables,
                    SUM(CASE WHEN VALIDATION_STATUS = 'PENDING' THEN 1 ELSE 0 END) AS pending_tables
                FROM {validation_schema_for_streamlit_dashboard()}.TABLE_METADATA
                {wf_filter}
            ),
            schema_counts AS (
                SELECT
                    COUNT(*) AS schema_total,
                    SUM(CASE WHEN UPPER(sv.STATUS) = 'SUCCESS' THEN 1 ELSE 0 END) AS schema_pass,
                    SUM(CASE WHEN UPPER(sv.STATUS) = 'WARNING' THEN 1 ELSE 0 END) AS schema_warning,
                    SUM(CASE WHEN UPPER(sv.STATUS) = 'FAILURE' THEN 1 ELSE 0 END) AS schema_failure
                FROM {validation_schema_for_streamlit_dashboard()}.SCHEMA_VALIDATION_RESULTS sv
                JOIN {validation_schema_for_streamlit_dashboard()}.TABLE_METADATA tm ON sv.TABLE_METADATA_ID = tm.ID
                {tm_filter}
            ),
            metrics_counts AS (
                SELECT
                    COUNT(*) AS metrics_total,
                    SUM(CASE WHEN UPPER(mv.STATUS) = 'SUCCESS' THEN 1 ELSE 0 END) AS metrics_pass,
                    SUM(CASE WHEN UPPER(mv.STATUS) = 'WARNING' THEN 1 ELSE 0 END) AS metrics_warning,
                    SUM(CASE WHEN UPPER(mv.STATUS) = 'FAILURE' THEN 1 ELSE 0 END) AS metrics_failure
                FROM {validation_schema_for_streamlit_dashboard()}.METRICS_VALIDATION_RESULTS mv
                JOIN {validation_schema_for_streamlit_dashboard()}.TABLE_METADATA tm ON mv.TABLE_METADATA_ID = tm.ID
                {tm_filter}
            ),
            row_counts AS (
                SELECT
                    COALESCE(SUM(TOTAL_ROWS_COMPARED), 0) AS total_rows_compared,
                    COALESCE(SUM(ROWS_WITH_DIFFERENCES), 0) AS rows_with_diffs,
                    COALESCE(SUM(ROWS_NOT_FOUND_IN_TARGET), 0) AS rows_missing_target,
                    COALESCE(SUM(ROWS_NOT_FOUND_IN_SOURCE), 0) AS rows_missing_source,
                    SUM(CASE WHEN IS_VALID THEN 1 ELSE 0 END) AS row_tables_valid,
                    COUNT(*) AS row_tables_total
                FROM {validation_schema_for_streamlit_dashboard()}.ROW_VALIDATION_SUMMARY rv
                JOIN {validation_schema_for_streamlit_dashboard()}.TABLE_METADATA tm ON rv.TABLE_METADATA_ID = tm.ID
                {tm_filter}
            )
            SELECT * FROM table_counts, schema_counts, metrics_counts, row_counts
            """
        )
    except Exception:
        return pd.DataFrame()


@st.cache_data(ttl=30)
def get_schema_results(
    workflow_id: int | None = None,
    status_filter: list[str] | None = None,
    table_search: str | None = None,
):
    """Fetch schema validation results with optional filters."""
    try:
        conditions = []
        if workflow_id:
            conditions.append(f"tm.WORKFLOW_ID = {workflow_id}")
        if status_filter:
            quoted = ", ".join(f"'{s}'" for s in status_filter)
            conditions.append(f"UPPER(sv.STATUS) IN ({quoted})")
        if table_search:
            safe = table_search.replace("'", "''")
            conditions.append(f"sv.TABLE_NAME ILIKE '%{safe}%'")

        where = "WHERE " + " AND ".join(conditions) if conditions else ""
        return run_query(
            f"""
            SELECT
                sv.WORKFLOW_ID,
                sv.TABLE_NAME,
                sv.VALIDATION_TYPE,
                sv.COLUMN_VALIDATED,
                sv.EVALUATION_CRITERIA,
                sv.SOURCE_VALUE,
                sv.SNOWFLAKE_VALUE,
                UPPER(sv.STATUS) AS STATUS,
                sv.COMMENTS,
                sv.CREATED_AT
            FROM {validation_schema_for_streamlit_dashboard()}.SCHEMA_VALIDATION_RESULTS sv
            JOIN {validation_schema_for_streamlit_dashboard()}.TABLE_METADATA tm ON sv.TABLE_METADATA_ID = tm.ID
            {where}
            ORDER BY
                CASE UPPER(sv.STATUS)
                    WHEN 'FAILURE' THEN 0
                    WHEN 'WARNING' THEN 1
                    WHEN 'SUCCESS' THEN 2
                    ELSE 3
                END,
                sv.TABLE_NAME, sv.COLUMN_VALIDATED
            """
        )
    except Exception:
        return pd.DataFrame()


@st.cache_data(ttl=30)
def get_metrics_results(
    workflow_id: int | None = None,
    status_filter: list[str] | None = None,
    table_search: str | None = None,
):
    """Fetch metrics validation results with optional filters."""
    try:
        conditions = []
        if workflow_id:
            conditions.append(f"tm.WORKFLOW_ID = {workflow_id}")
        if status_filter:
            quoted = ", ".join(f"'{s}'" for s in status_filter)
            conditions.append(f"UPPER(mv.STATUS) IN ({quoted})")
        if table_search:
            safe = table_search.replace("'", "''")
            conditions.append(f"mv.TABLE_NAME ILIKE '%{safe}%'")

        where = "WHERE " + " AND ".join(conditions) if conditions else ""
        return run_query(
            f"""
            SELECT
                mv.WORKFLOW_ID,
                mv.TABLE_NAME,
                mv.VALIDATION_TYPE,
                mv.COLUMN_VALIDATED,
                mv.EVALUATION_CRITERIA,
                mv.SOURCE_VALUE,
                mv.SNOWFLAKE_VALUE,
                UPPER(mv.STATUS) AS STATUS,
                mv.COMMENTS,
                mv.CREATED_AT
            FROM {validation_schema_for_streamlit_dashboard()}.METRICS_VALIDATION_RESULTS mv
            JOIN {validation_schema_for_streamlit_dashboard()}.TABLE_METADATA tm ON mv.TABLE_METADATA_ID = tm.ID
            {where}
            ORDER BY
                CASE UPPER(mv.STATUS)
                    WHEN 'FAILURE' THEN 0
                    WHEN 'WARNING' THEN 1
                    WHEN 'SUCCESS' THEN 2
                    ELSE 3
                END,
                mv.TABLE_NAME, mv.COLUMN_VALIDATED
            """
        )
    except Exception:
        return pd.DataFrame()


@st.cache_data(ttl=30)
def get_row_validation_summary(
    workflow_id: int | None = None,
    table_search: str | None = None,
):
    """Fetch row validation summary."""
    try:
        conditions = []
        if workflow_id:
            conditions.append(f"tm.WORKFLOW_ID = {workflow_id}")
        if table_search:
            safe = table_search.replace("'", "''")
            conditions.append(f"rv.TABLE_NAME ILIKE '%{safe}%'")

        where = "WHERE " + " AND ".join(conditions) if conditions else ""
        return run_query(
            f"""
            SELECT
                rv.WORKFLOW_ID,
                rv.TABLE_NAME,
                rv.TOTAL_CHUNKS,
                rv.MATCHING_CHUNKS,
                rv.DIFFERING_CHUNKS,
                rv.TOTAL_ROWS_COMPARED,
                rv.ROWS_NOT_FOUND_IN_TARGET,
                rv.ROWS_NOT_FOUND_IN_SOURCE,
                rv.ROWS_WITH_DIFFERENCES,
                rv.IS_VALID,
                rv.CREATED_AT
            FROM {validation_schema_for_streamlit_dashboard()}.ROW_VALIDATION_SUMMARY rv
            JOIN {validation_schema_for_streamlit_dashboard()}.TABLE_METADATA tm ON rv.TABLE_METADATA_ID = tm.ID
            {where}
            ORDER BY
                rv.IS_VALID ASC,
                rv.TABLE_NAME
            """
        )
    except Exception:
        return pd.DataFrame()


@st.cache_data(ttl=30)
def get_chunk_hashes(
    workflow_id: int | None = None,
    table_search: str | None = None,
    only_mismatches: bool = False,
):
    """Fetch chunk hash comparison data."""
    try:
        conditions = []
        if workflow_id:
            conditions.append(f"tm.WORKFLOW_ID = {workflow_id}")
        if table_search:
            safe = table_search.replace("'", "''")
            conditions.append(f"ch.TABLE_NAME ILIKE '%{safe}%'")
        if only_mismatches:
            conditions.append("ch.IS_MATCH = FALSE")

        where = "WHERE " + " AND ".join(conditions) if conditions else ""
        return run_query(
            f"""
            SELECT
                ch.WORKFLOW_ID,
                ch.TABLE_NAME,
                ch.CHUNK_ID,
                ch.SOURCE_HASH,
                ch.TARGET_HASH,
                ch.HASH_ALGORITHM,
                ch.IS_MATCH,
                ch.CREATED_AT
            FROM {validation_schema_for_streamlit_dashboard()}.CHUNK_HASHES ch
            JOIN {validation_schema_for_streamlit_dashboard()}.TABLE_METADATA tm ON ch.TABLE_METADATA_ID = tm.ID
            {where}
            ORDER BY ch.IS_MATCH ASC, ch.TABLE_NAME, ch.CHUNK_ID
            """
        )
    except Exception:
        return pd.DataFrame()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _safe_int(value) -> int:
    """Convert a value to int, treating NaN/None as 0."""
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return 0
    return int(value)


def _status_icon(status: str) -> str:
    """Return an emoji for a given validation status."""
    return STATUS_EMOJI.get(status.upper() if isinstance(status, str) else "", "⚪")


def _status_label(status: str) -> str:
    """Return a human-friendly label for a status value."""
    return STATUS_DISPLAY.get(status.upper() if isinstance(status, str) else "", status)


def _render_status_badges(df: pd.DataFrame, col: str = "STATUS") -> pd.DataFrame:
    """Prepend status emoji to the STATUS column for visual scanning."""
    if col in df.columns:
        out = df.copy()
        out[col] = out[col].apply(lambda v: f"{_status_icon(v)} {_status_label(v)}")
        return out
    return df


def _result_status_pills(
    key_prefix: str,
    default: list[str] | None = None,
) -> list[str]:
    """Render multi-select status filter and return selected values."""
    options = RESULT_STATUSES
    fmt = {s: f"{STATUS_EMOJI[s]} {STATUS_DISPLAY[s]}" for s in options}
    selected_display = st.multiselect(
        "Filter by status",
        options=[fmt[s] for s in options],
        default=[fmt[s] for s in (default or ["FAILURE"])],
        key=f"{key_prefix}_status",
    )
    reverse = {v: k for k, v in fmt.items()}
    return [reverse[d] for d in selected_display]


# ---------------------------------------------------------------------------
# Layout
# ---------------------------------------------------------------------------

st.title("🔍 Data validation dashboard")

# -- Sidebar ---------------------------------------------------------------
with st.sidebar:
    st.header("Filters")

    if st.button("Refresh data"):
        st.cache_data.clear()

    st.caption("Data refreshes every 30 seconds")

    workflows = get_workflows()  # {id: name, ...}
    wf_display = {
        wf_id: name or f"Workflow {wf_id}" for wf_id, name in workflows.items()
    }
    wf_options = ["All workflows"] + [wf_display[wid] for wid in wf_display]
    name_to_id = {display: wid for wid, display in wf_display.items()}

    selected_wf_str = st.selectbox(
        "Workflow",
        options=wf_options,
        index=0,
        key="wf_filter",
        help="Filter dashboard by a specific workflow",
        disabled=len(workflows) == 0,
    )

    selected_wf = (
        None if selected_wf_str == "All workflows" else name_to_id.get(selected_wf_str)
    )

    if len(workflows) == 0:
        st.warning("No workflows found.")

# -- Tabs -------------------------------------------------------------------
tab_overview, tab_schema, tab_metrics, tab_rows, tab_tables = st.tabs(
    [
        "Overview",
        "Schema validation",
        "Metrics validation",
        "Row validation",
        "Table progress",
    ]
)

# ===== OVERVIEW ============================================================
with tab_overview:
    overview = get_overview_metrics(selected_wf)

    if len(overview) > 0:
        m = overview.iloc[0]

        if selected_wf is not None and selected_wf_str != "All workflows":
            st.info(f"Showing data for **{selected_wf_str}**")

        # -- Table-level KPIs
        st.subheader("Tables")
        cols = st.columns(5)
        with cols[0]:
            st.metric("Total", _safe_int(m["TOTAL_TABLES"]))
        with cols[1]:
            st.metric("Completed", _safe_int(m["COMPLETED_TABLES"]))
        with cols[2]:
            st.metric("In progress", _safe_int(m["IN_PROGRESS_TABLES"]))
        with cols[3]:
            st.metric("Pending", _safe_int(m["PENDING_TABLES"]))
        with cols[4]:
            failed_t = _safe_int(m["FAILED_TABLES"])
            st.metric(
                "Failed",
                failed_t,
                delta="needs attention" if failed_t > 0 else None,
                delta_color="inverse",
            )

        # -- Schema validation KPIs
        st.subheader("Schema validation checks")
        cols = st.columns(4)
        with cols[0]:
            st.metric("Total checks", _safe_int(m["SCHEMA_TOTAL"]))
        with cols[1]:
            st.metric("🟢 Success", _safe_int(m["SCHEMA_PASS"]))
        with cols[2]:
            st.metric("🟡 Warning", _safe_int(m["SCHEMA_WARNING"]))
        with cols[3]:
            sf = _safe_int(m["SCHEMA_FAILURE"])
            st.metric(
                "🔴 Failure",
                sf,
                delta="needs attention" if sf > 0 else None,
                delta_color="inverse",
            )

        # -- Metrics validation KPIs
        st.subheader("Metrics validation checks")
        cols = st.columns(4)
        with cols[0]:
            st.metric("Total checks", _safe_int(m["METRICS_TOTAL"]))
        with cols[1]:
            st.metric("🟢 Success", _safe_int(m["METRICS_PASS"]))
        with cols[2]:
            st.metric("🟡 Warning", _safe_int(m["METRICS_WARNING"]))
        with cols[3]:
            mf = _safe_int(m["METRICS_FAILURE"])
            st.metric(
                "🔴 Failure",
                mf,
                delta="needs attention" if mf > 0 else None,
                delta_color="inverse",
            )

        # -- Row validation KPIs
        st.subheader("Row validation")
        row_total = _safe_int(m["ROW_TABLES_TOTAL"])
        if row_total > 0:
            cols = st.columns(5)
            with cols[0]:
                st.metric("Tables checked", row_total)
            with cols[1]:
                st.metric("Valid", _safe_int(m["ROW_TABLES_VALID"]))
            with cols[2]:
                st.metric("Rows compared", f"{_safe_int(m['TOTAL_ROWS_COMPARED']):,}")
            with cols[3]:
                rd = _safe_int(m["ROWS_WITH_DIFFS"])
                st.metric(
                    "Rows with diffs",
                    f"{rd:,}",
                    delta="needs attention" if rd > 0 else None,
                    delta_color="inverse",
                )
            with cols[4]:
                missing = _safe_int(m["ROWS_MISSING_TARGET"]) + _safe_int(
                    m["ROWS_MISSING_SOURCE"]
                )
                st.metric("Rows missing", f"{missing:,}")
        else:
            st.info("No row validation data available yet.")

        # -- Combined bar chart
        st.subheader("Validation status breakdown")
        chart_data = pd.DataFrame(
            {
                "Level": [
                    "Schema",
                    "Schema",
                    "Schema",
                    "Metrics",
                    "Metrics",
                    "Metrics",
                ],
                "Status": ["Success", "Warning", "Failure"] * 2,
                "Count": [
                    _safe_int(m["SCHEMA_PASS"]),
                    _safe_int(m["SCHEMA_WARNING"]),
                    _safe_int(m["SCHEMA_FAILURE"]),
                    _safe_int(m["METRICS_PASS"]),
                    _safe_int(m["METRICS_WARNING"]),
                    _safe_int(m["METRICS_FAILURE"]),
                ],
            }
        )
        chart_data = chart_data[chart_data["Count"] > 0]
        if len(chart_data) > 0:
            pivot = chart_data.pivot_table(
                index="Level", columns="Status", values="Count", fill_value=0
            )
            col_order = [
                c for c in ["Success", "Warning", "Failure"] if c in pivot.columns
            ]
            st.bar_chart(pivot[col_order])
        else:
            st.info("No validation results yet.")
    else:
        st.warning(
            "No validation data available. Run a data validation workflow first."
        )


# ===== SCHEMA VALIDATION ===================================================
with tab_schema:
    if selected_wf is not None and selected_wf_str != "All workflows":
        st.info(f"Showing schema results for **{selected_wf_str}**")

    col_filter, col_search = st.columns([1, 2])
    with col_filter:
        schema_statuses = _result_status_pills("schema")
    with col_search:
        schema_search = st.text_input(
            "Search tables",
            placeholder="Filter by table name...",
            key="schema_search",
            label_visibility="collapsed",
        )

    schema_df = get_schema_results(
        selected_wf,
        schema_statuses if schema_statuses else None,
        schema_search or None,
    )

    if len(schema_df) > 0:
        cols = st.columns(4)
        with cols[0]:
            st.metric("Total results", len(schema_df))
        for i, s in enumerate(RESULT_STATUSES):
            with cols[i + 1]:
                cnt = len(schema_df[schema_df["STATUS"] == s])
                st.metric(f"{STATUS_EMOJI[s]} {STATUS_DISPLAY[s]}", cnt)

        st.dataframe(
            _render_status_badges(schema_df),
            use_container_width=True,
        )

        if st.checkbox("Show detail view", key="schema_detail"):
            for _, row in schema_df.iterrows():
                label = (
                    f"{_status_icon(row['STATUS'])} {row['TABLE_NAME']} "
                    f"| {row['COLUMN_VALIDATED']} | {row['EVALUATION_CRITERIA']}"
                )
                with st.expander(label):
                    c1, c2 = st.columns(2)
                    with c1:
                        st.text(f"Source:    {row['SOURCE_VALUE']}")
                    with c2:
                        st.text(f"Snowflake: {row['SNOWFLAKE_VALUE']}")
                    if row["COMMENTS"]:
                        st.caption(row["COMMENTS"])
    else:
        st.info("No schema validation results match the current filters.")


# ===== METRICS VALIDATION ==================================================
with tab_metrics:
    if selected_wf is not None and selected_wf_str != "All workflows":
        st.info(f"Showing metrics results for **{selected_wf_str}**")

    col_filter, col_search = st.columns([1, 2])
    with col_filter:
        metrics_statuses = _result_status_pills("metrics")
    with col_search:
        metrics_search = st.text_input(
            "Search tables",
            placeholder="Filter by table name...",
            key="metrics_search",
            label_visibility="collapsed",
        )

    metrics_df = get_metrics_results(
        selected_wf,
        metrics_statuses if metrics_statuses else None,
        metrics_search or None,
    )

    if len(metrics_df) > 0:
        cols = st.columns(4)
        with cols[0]:
            st.metric("Total results", len(metrics_df))
        for i, s in enumerate(RESULT_STATUSES):
            with cols[i + 1]:
                cnt = len(metrics_df[metrics_df["STATUS"] == s])
                st.metric(f"{STATUS_EMOJI[s]} {STATUS_DISPLAY[s]}", cnt)

        st.dataframe(
            _render_status_badges(metrics_df),
            use_container_width=True,
        )

        if st.checkbox("Show detail view", key="metrics_detail"):
            for _, row in metrics_df.iterrows():
                label = (
                    f"{_status_icon(row['STATUS'])} {row['TABLE_NAME']} "
                    f"| {row['COLUMN_VALIDATED']} | {row['EVALUATION_CRITERIA']}"
                )
                with st.expander(label):
                    c1, c2 = st.columns(2)
                    with c1:
                        st.text(f"Source:    {row['SOURCE_VALUE']}")
                    with c2:
                        st.text(f"Snowflake: {row['SNOWFLAKE_VALUE']}")
                    if row["COMMENTS"]:
                        st.caption(row["COMMENTS"])
    else:
        st.info("No metrics validation results match the current filters.")


# ===== ROW VALIDATION ======================================================
with tab_rows:
    if selected_wf is not None and selected_wf_str != "All workflows":
        st.info(f"Showing row validation for **{selected_wf_str}**")

    row_search = st.text_input(
        "Search tables",
        placeholder="Filter by table name...",
        key="row_search",
        label_visibility="collapsed",
    )

    # -- Summary
    st.subheader("Row validation summary")
    row_summary_df = get_row_validation_summary(selected_wf, row_search or None)

    if len(row_summary_df) > 0:
        cols = st.columns(4)
        total_t = len(row_summary_df)
        valid_t = len(row_summary_df[row_summary_df["IS_VALID"] == True])  # noqa: E712
        with cols[0]:
            st.metric("Tables", total_t)
        with cols[1]:
            st.metric("Valid", valid_t)
        with cols[2]:
            st.metric("Invalid", total_t - valid_t)
        with cols[3]:
            total_diffs = int(row_summary_df["ROWS_WITH_DIFFERENCES"].sum())
            st.metric("Total row diffs", f"{total_diffs:,}")

        display = row_summary_df.copy()
        display["VALID"] = display["IS_VALID"].apply(
            lambda v: "🟢 Yes" if v else "🔴 No"
        )
        st.dataframe(display, use_container_width=True)
    else:
        st.info("No row validation summary data available.")

    # -- Chunk hashes
    st.subheader("Chunk hash comparison")
    only_mismatches = st.checkbox(
        "Show only mismatches", value=True, key="chunk_mismatch"
    )
    chunk_df = get_chunk_hashes(selected_wf, row_search or None, only_mismatches)

    if len(chunk_df) > 0:
        chunk_display = chunk_df.copy()
        chunk_display["MATCH"] = chunk_display["IS_MATCH"].apply(
            lambda v: "🟢 Match" if v else "🔴 Mismatch"
        )
        st.dataframe(chunk_display, use_container_width=True)
    else:
        if only_mismatches:
            st.success("All chunk hashes match!")
        else:
            st.info("No chunk hash data available.")


# ===== TABLE PROGRESS ======================================================
with tab_tables:
    if selected_wf is not None and selected_wf_str != "All workflows":
        st.info(f"Showing tables for **{selected_wf_str}**")

    table_df = get_table_metadata(selected_wf)

    if len(table_df) > 0:
        status_counts = table_df["VALIDATION_STATUS"].value_counts()

        cols = st.columns(5)
        with cols[0]:
            st.metric("Total tables", len(table_df))
        for i, s in enumerate(["COMPLETED", "IN_PROGRESS", "PENDING", "FAILED"]):
            with cols[i + 1]:
                cnt = int(status_counts.get(s, 0))
                color = {
                    "COMPLETED": "🟢",
                    "IN_PROGRESS": "🔵",
                    "PENDING": "⚪",
                    "FAILED": "🔴",
                }.get(s, "")
                st.metric(f"{color} {s.replace('_', ' ').title()}", cnt)

        search = st.text_input(
            "Search tables",
            placeholder="Filter by table name...",
            key="table_search",
            label_visibility="collapsed",
        )

        display = table_df
        if search:
            display = table_df[
                table_df["SOURCE_IDENTIFIER"].str.contains(search, case=False, na=False)
            ]

        if len(display) > 0:
            fmt = display.copy()
            status_map = {
                "COMPLETED": "🟢 Completed",
                "IN_PROGRESS": "🔵 In Progress",
                "PENDING": "⚪ Pending",
                "FAILED": "🔴 Failed",
            }
            fmt["VALIDATION_STATUS"] = fmt["VALIDATION_STATUS"].map(
                lambda v: status_map.get(v, v)
            )
            st.dataframe(fmt, use_container_width=True)
        else:
            st.info("No tables match the current filter.")
    else:
        st.info("No table metadata available.")
