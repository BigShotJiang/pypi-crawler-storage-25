"""
Thin wrapper around the ``snowflake-data-validation`` library query API.

Provides convenience functions that build ``TableContext`` objects and call
``generate_schema_query`` / ``generate_metrics_query`` so that the
orchestrator never has to craft raw SQL for validation queries.
"""

from __future__ import annotations

from pathlib import Path

from snowflake.snowflake_data_validation.public import (
    ColumnMetadata,
    ObjectType,
    Origin,
    Platform,
    SQLQueriesTemplateGenerator,
    TableContext,
    TemplatesLoaderManager,
    generate_cell_validation_data_query,
    generate_metrics_query,
    generate_schema_query,
)
from snowflake.snowflake_data_validation.utils.helpers.helper_templates import (
    HelperTemplates,
)

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)


logger = get_logger("dv.sdv_query_helper")

# ---------------------------------------------------------------------------
# Platform resolution
# ---------------------------------------------------------------------------

_PLATFORM_MAP: dict[str, Platform] = {
    "redshift": Platform.REDSHIFT,
    "snowflake": Platform.SNOWFLAKE,
    "sqlserver": Platform.SQLSERVER,
    "sql_server": Platform.SQLSERVER,
    "teradata": Platform.TERADATA,
}


def resolve_platform(platform_str: str) -> Platform:
    """Map a human-readable platform string to the SDV ``Platform`` enum."""
    p = _PLATFORM_MAP.get(platform_str.lower())
    if p is None:
        raise ValueError(f"Unknown platform: {platform_str}")
    return p


# ---------------------------------------------------------------------------
# Template-path resolution
# ---------------------------------------------------------------------------

_PLATFORM_DIRS: dict[Platform, str] = {
    Platform.REDSHIFT: "redshift",
    Platform.SNOWFLAKE: "snowflake",
    Platform.SQLSERVER: "sqlserver",
    Platform.TERADATA: "teradata",
}


def _sdv_package_root() -> Path:
    """Return the root directory of the installed *snowflake-data-validation* package."""
    import snowflake.snowflake_data_validation as _sdv

    return Path(_sdv.__file__).parent


def _templates_path(platform: Platform) -> str:
    subdir = _PLATFORM_DIRS.get(platform, platform.value)
    return str(_sdv_package_root() / subdir / "extractor" / "templates")


# ---------------------------------------------------------------------------
# Datatypes mappings
# ---------------------------------------------------------------------------

_DATATYPES_MAPPING_FORMAT = (
    "{source_platform}_to_{target_platform}_datatypes_mapping_template.yaml"
)


def load_datatypes_mappings(
    source_platform_str: str,
    target_platform_str: str = "snowflake",
) -> dict[str, str]:
    """
    Load the source-to-target datatypes mapping from the SDV YAML template.

    E.g. for Redshift→Snowflake this returns ``{"INTEGER": "NUMBER", ...}``.
    Returns an empty dict if the mapping file does not exist for the platform
    combination.
    """
    source_platform = resolve_platform(source_platform_str)
    file_name = _DATATYPES_MAPPING_FORMAT.format(
        source_platform=source_platform.value,
        target_platform=target_platform_str.lower(),
    )
    mapping_path = Path(_templates_path(source_platform)) / file_name

    if not mapping_path.exists():
        logger.warning(
            "Datatypes mapping file not found: %s – using empty mapping",
            mapping_path,
        )
        return {}

    mappings = HelperTemplates.load_datatypes_mapping_templates_from_yaml(
        yaml_path=mapping_path
    )
    logger.info(
        "Loaded %d datatypes mappings from %s",
        len(mappings),
        mapping_path.name,
    )
    return mappings


# ---------------------------------------------------------------------------
# TableContext factory
# ---------------------------------------------------------------------------


def _join_non_empty_fqn_parts(*parts: str) -> str:
    """
    Join identifier segments with '.', omitting empty strings.

    Two-part names (e.g. Teradata ``database.table``) are parsed as
    ``("", database, table)`` for compatibility with Snowflake-style
    ``schema.table``. Building ``f"{db}.{schema}.{table}"`` would yield a
    leading ``.`` and invalid SQL (e.g. ``FROM .tpcds.catalog_sales``).
    """
    return ".".join(p for p in parts if p)


def _build_table_context(
    platform: Platform,
    origin: Origin,
    database_name: str,
    schema_name: str,
    table_name: str,
    fully_qualified_name: str = "",
    columns: list[ColumnMetadata] | None = None,
    row_count: int = 0,
    where_clause: str = "",
) -> TableContext:
    """Create a ``TableContext`` populated with only what query generation needs."""
    fqn = fully_qualified_name or _join_non_empty_fqn_parts(
        database_name, schema_name, table_name
    )
    templates_dir = _templates_path(platform)

    sql_generator = SQLQueriesTemplateGenerator(
        jinja_templates_folder_path=templates_dir,
    )
    templates_loader_manager = TemplatesLoaderManager(
        templates_directory_path=Path(templates_dir),
        platform=platform,
    )

    return TableContext(
        apply_metric_column_modifier=True,
        chunk_number=1,
        column_mappings={},
        column_selection_list=[],
        columns=columns or [],
        database_name=database_name,
        exclude_metrics=False,
        fully_qualified_name=fqn,
        has_where_clause=bool(where_clause),
        id=0,
        internal_fully_qualified_name=fqn,
        internal_table_name=table_name,
        is_case_sensitive=False,
        is_exclusion_mode=False,
        is_temporary_table=False,
        max_failed_rows_number=100,
        object_type=ObjectType.TABLE,
        origin=origin,
        platform=platform,
        row_count=row_count,
        run_id="0",
        run_start_time="",
        schema_name=schema_name,
        sql_generator=sql_generator,
        table_name=table_name,
        templates_loader_manager=templates_loader_manager,
        user_index_column_collection=[],
        where_clause=where_clause,
    )


# ---------------------------------------------------------------------------
# ColumnMetadata factory
# ---------------------------------------------------------------------------


def make_column_metadata(
    name: str,
    data_type: str,
    nullable: bool = True,
    is_primary_key: bool = False,
) -> ColumnMetadata:
    """Create a ``ColumnMetadata`` from minimal inputs."""
    return ColumnMetadata(
        name=name,
        data_type=data_type,
        nullable=nullable,
        is_primary_key=is_primary_key,
        calculated_column_size_in_bytes=0,
        properties={},
    )


# ---------------------------------------------------------------------------
# Public helpers
# ---------------------------------------------------------------------------


def build_schema_queries(
    source_platform_str: str,
    source_db: str,
    source_schema: str,
    source_table: str,
    target_db: str,
    target_schema: str,
    target_table: str,
) -> tuple[str, str]:
    """
    Generate schema metadata extraction queries for source and target.

    Returns (source_query, target_query) using the SDV Jinja2 templates.
    """
    source_platform = resolve_platform(source_platform_str)

    source_ctx = _build_table_context(
        platform=source_platform,
        origin=Origin.SOURCE,
        database_name=source_db,
        schema_name=source_schema,
        table_name=source_table,
    )
    target_ctx = _build_table_context(
        platform=Platform.SNOWFLAKE,
        origin=Origin.TARGET,
        database_name=target_db,
        schema_name=target_schema,
        table_name=target_table,
    )

    source_query = generate_schema_query(source_ctx).query_string
    target_query = generate_schema_query(target_ctx).query_string

    logger.info(
        "Generated schema queries via SDV for %s.%s.%s -> %s.%s.%s",
        source_db,
        source_schema,
        source_table,
        target_db,
        target_schema,
        target_table,
    )
    return source_query, target_query


def build_metrics_queries(
    source_platform_str: str,
    source_db: str,
    source_schema: str,
    source_table: str,
    source_columns: list[ColumnMetadata],
    target_db: str,
    target_schema: str,
    target_table: str,
    target_columns: list[ColumnMetadata],
    source_fqn: str = "",
    target_fqn: str = "",
    row_count: int = 0,
    source_where_clause: str = "",
    target_where_clause: str = "",
) -> tuple[str, str]:
    """
    Generate per-column metrics queries for source and target.

    Returns (source_query, target_query) using SDV's CTE-based template
    system.  Columns must include at least ``name`` and ``data_type``.

    When *source_where_clause* / *target_where_clause* are provided the
    generated CTE queries include a ``WHERE`` clause so that metrics are
    computed over a partition slice rather than the full table.
    """
    source_platform = resolve_platform(source_platform_str)

    source_ctx = _build_table_context(
        platform=source_platform,
        origin=Origin.SOURCE,
        database_name=source_db,
        schema_name=source_schema,
        table_name=source_table,
        fully_qualified_name=source_fqn,
        columns=source_columns,
        row_count=row_count,
        where_clause=source_where_clause,
    )
    target_ctx = _build_table_context(
        platform=Platform.SNOWFLAKE,
        origin=Origin.TARGET,
        database_name=target_db,
        schema_name=target_schema,
        table_name=target_table,
        fully_qualified_name=target_fqn,
        columns=target_columns,
        row_count=row_count,
        where_clause=target_where_clause,
    )

    source_query = generate_metrics_query(source_ctx).query_string
    target_query = generate_metrics_query(target_ctx).query_string

    logger.info(
        "Generated metrics queries via SDV: %d source cols, %d target cols",
        len(source_columns),
        len(target_columns),
    )
    return source_query, target_query


def align_target_columns_to_source_order(
    source_columns: list[ColumnMetadata],
    target_columns: list[ColumnMetadata],
) -> list[ColumnMetadata] | None:
    """Reorder *target* columns to match *source* order for positional L3 cell compare."""
    tgt_by_name = {c.name.casefold(): c for c in target_columns}
    aligned: list[ColumnMetadata] = []
    for sc in source_columns:
        tc = tgt_by_name.get(sc.name.casefold())
        if tc is None:
            return None
        aligned.append(tc)
    return aligned


def build_normalized_cell_validation_queries(
    source_platform_str: str,
    source_db: str,
    source_schema: str,
    source_table: str,
    source_fqn: str,
    target_db: str,
    target_schema: str,
    target_table: str,
    target_fqn: str,
    source_columns: list[ColumnMetadata],
    target_columns: list[ColumnMetadata],
    source_where_clause: str = "",
    target_where_clause: str = "",
    order_by_columns: list[str] | None = None,
) -> tuple[str, str] | None:
    """
    Build normalized cell-validation SELECT statements for Teradata and Snowflake.

    Uses SDV datatype normalization (same templates as L3 MD5). Returns None if
    columns cannot be aligned.
    """
    aligned_target = align_target_columns_to_source_order(
        source_columns, target_columns
    )
    if aligned_target is None or not source_columns:
        return None

    source_platform = resolve_platform(source_platform_str)

    source_ctx = _build_table_context(
        platform=source_platform,
        origin=Origin.SOURCE,
        database_name=source_db,
        schema_name=source_schema,
        table_name=source_table,
        fully_qualified_name=source_fqn,
        columns=source_columns,
        where_clause=source_where_clause,
    )
    target_ctx = _build_table_context(
        platform=Platform.SNOWFLAKE,
        origin=Origin.TARGET,
        database_name=target_db,
        schema_name=target_schema,
        table_name=target_table,
        fully_qualified_name=target_fqn,
        columns=aligned_target,
        where_clause=target_where_clause,
    )

    source_query = generate_cell_validation_data_query(
        source_ctx, order_by_columns=order_by_columns
    ).query_string
    target_query = generate_cell_validation_data_query(
        target_ctx, order_by_columns=order_by_columns
    ).query_string

    logger.info(
        "Generated normalized cell validation queries for %s -> %s (%d columns)",
        source_fqn,
        target_fqn,
        len(source_columns),
    )
    return source_query, target_query


def build_cell_validation_queries(
    source_fqn: str,
    target_fqn: str,
    source_where_clause: str = "",
    target_where_clause: str = "",
    column_list: list[str] | None = None,
    order_by_columns: list[str] | None = None,
) -> tuple[str, str]:
    """
    Generate SELECT queries for cell-by-cell validation.

    Cell mode does not use SDV for query generation -- it just pulls
    the table data and lets SDV compare DataFrames in memory.
    When *column_list* is provided the query selects only those columns
    instead of ``SELECT *``, which avoids pulling large LOB columns.
    When *order_by_columns* is provided both queries include an ORDER BY
    clause so rows arrive pre-sorted, avoiding a client-side sort.
    """
    columns = ", ".join(column_list) if column_list else "*"
    order_clause = (
        " ORDER BY " + ", ".join(f'"{c}"' for c in order_by_columns)
        if order_by_columns
        else ""
    )

    source_query = f"SELECT {columns} FROM {source_fqn}"
    if source_where_clause:
        source_query += f" WHERE {source_where_clause}"
    source_query += order_clause

    target_query = f"SELECT {columns} FROM {target_fqn}"
    if target_where_clause:
        target_query += f" WHERE {target_where_clause}"
    target_query += order_clause

    logger.info(
        "Generated cell validation queries for %s -> %s",
        source_fqn,
        target_fqn,
    )
    return source_query, target_query
