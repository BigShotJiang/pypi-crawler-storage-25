"""
Parser for data validation workflow configurations.

Converts raw JSON config dicts into typed ValidationTableConfiguration objects
and resolves global defaults.
"""

from __future__ import annotations

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.data_validation_cloud.config import (
    configuration_properties_keys as keys,
)
from data_migration_orchestrator.data_validation_cloud.config.validation_table_configuration import (
    ValidationTableConfiguration,
)
from data_migration_orchestrator.data_validation_cloud.config.workflow_configuration_schema import (
    TableSchema,
    validate_data_validation_workflow_configuration,
)
from data_migration_orchestrator.data_validation_core.constants import (
    RowValidationMode,
)


logger = get_logger("data_validation.configuration_parser")

DEFAULT_TOLERANCE = 0.001
DEFAULT_MAX_FAILED_ROWS = 100


class ValidationConfigurationError(Exception):
    """Raised when data validation configuration is invalid."""


class ValidationConfigurationParser:
    """
    Parse and validate data validation workflow configurations.

    Converts raw JSON configuration dicts into strongly-typed objects suitable
    for the orchestrator and DEA.
    """

    def __init__(self, raw_config: dict) -> None:
        """
        Initialize the parser by validating the raw configuration.

        Args:
            raw_config: Raw JSON configuration dictionary from the workflow.

        """
        self._schema = validate_data_validation_workflow_configuration(raw_config)
        self._raw = raw_config

    @property
    def source_platform(self) -> str:
        """Return the source platform identifier."""
        return self._schema.source_platform

    @property
    def target_platform(self) -> str:
        """Return the target platform identifier."""
        return self._schema.target_platform

    @property
    def target_database(self) -> str | None:
        """Return the default target database, if set."""
        return self._schema.target_database

    @property
    def affinity(self) -> str | None:
        """Return the task affinity group, if set."""
        return self._schema.affinity

    @property
    def use_snowflake_compute(self) -> bool:
        """Return whether Snowflake-side computation is enabled."""
        return self._schema.use_snowflake_compute

    @property
    def tolerance(self) -> float:
        """Return the numeric comparison tolerance for metrics validation."""
        if (
            self._schema.comparison_configuration
            and self._schema.comparison_configuration.tolerance
        ):
            return self._schema.comparison_configuration.tolerance
        return DEFAULT_TOLERANCE

    @property
    def type_mapping_file_path(self) -> str | None:
        """Return the path to the type mapping file, if configured."""
        if self._schema.comparison_configuration:
            return self._schema.comparison_configuration.type_mapping_file_path
        return None

    @property
    def database_mappings(self) -> dict[str, str]:
        """Return source-to-target database name mappings."""
        return self._schema.database_mappings or {}

    @property
    def schema_mappings(self) -> dict[str, str]:
        """Return source-to-target schema name mappings."""
        return self._schema.schema_mappings or {}

    @property
    def schema_validation_enabled(self) -> bool:
        """Return whether L1 schema validation is enabled globally."""
        vc = self._schema.validation_configuration
        if vc and vc.schema_validation is not None:
            return vc.schema_validation
        return True

    @property
    def metrics_validation_enabled(self) -> bool:
        """Return whether L2 metrics validation is enabled globally."""
        vc = self._schema.validation_configuration
        if vc and vc.metrics_validation is not None:
            return vc.metrics_validation
        return True

    @property
    def row_validation_enabled(self) -> bool:
        """Return whether L3 row validation is enabled globally."""
        vc = self._schema.validation_configuration
        if vc and vc.row_validation is not None:
            return vc.row_validation
        return False

    @property
    def row_validation_mode(self) -> RowValidationMode:
        """Return the L3 row validation mode (row or cell)."""
        vc = self._schema.validation_configuration
        if vc and vc.row_validation_mode is not None:
            return RowValidationMode(vc.row_validation_mode)
        return RowValidationMode.ROW

    @property
    def continue_on_failure(self) -> bool:
        """Return whether validation should continue to the next level on failure."""
        vc = self._schema.validation_configuration
        if vc and vc.continue_on_failure is not None:
            return vc.continue_on_failure
        return False

    @property
    def max_failed_rows_number(self) -> int:
        """Return the maximum number of failed rows to report in L3 validation."""
        vc = self._schema.validation_configuration
        if vc and vc.max_failed_rows_number is not None:
            return vc.max_failed_rows_number
        return DEFAULT_MAX_FAILED_ROWS

    @property
    def exclude_metrics(self) -> bool:
        """Return whether to exclude unsupported metric columns globally."""
        vc = self._schema.validation_configuration
        if vc and vc.exclude_metrics is not None:
            return vc.exclude_metrics
        return False

    @property
    def apply_metric_column_modifier(self) -> bool:
        """Return whether to apply metric column modifiers globally."""
        vc = self._schema.validation_configuration
        if vc and vc.apply_metric_column_modifier is not None:
            return vc.apply_metric_column_modifier
        return True

    def parse_tables(self) -> list[ValidationTableConfiguration]:
        """Parse all table configurations with global defaults applied."""
        tables: list[ValidationTableConfiguration] = []
        for table_schema in self._schema.tables:
            tables.append(self._parse_table(table_schema, object_type="TABLE"))

        if self._schema.views:
            for view_schema in self._schema.views:
                tables.append(self._parse_table(view_schema, object_type="VIEW"))

        return tables

    def _parse_table(
        self, table_schema: TableSchema, object_type: str
    ) -> ValidationTableConfiguration:
        """Parse a single table/view schema into a ValidationTableConfiguration."""
        table_vc = getattr(table_schema, "validation_configuration", None)

        schema_val = self._resolve_bool(
            table_vc, keys.SCHEMA_VALIDATION, self.schema_validation_enabled
        )
        metrics_val = self._resolve_bool(
            table_vc, keys.METRICS_VALIDATION, self.metrics_validation_enabled
        )
        row_val = self._resolve_bool(
            table_vc, keys.ROW_VALIDATION, self.row_validation_enabled
        )
        cont_fail = self._resolve_bool(
            table_vc, keys.CONTINUE_ON_FAILURE, self.continue_on_failure
        )

        row_mode = self.row_validation_mode
        if table_vc is not None:
            table_row_mode = getattr(table_vc, keys.ROW_VALIDATION_MODE, None)
            if table_row_mode is not None:
                row_mode = table_row_mode

        return ValidationTableConfiguration(
            fully_qualified_name=table_schema.fully_qualified_name,
            use_column_selection_as_exclude_list=table_schema.use_column_selection_as_exclude_list,
            column_selection_list=table_schema.column_selection_list or [],
            target_name=table_schema.target_name,
            target_database=table_schema.target_database or self.target_database,
            target_schema=table_schema.target_schema,
            where_clause=table_schema.where_clause or "",
            target_where_clause=table_schema.target_where_clause or "",
            index_column_list=table_schema.index_column_list or [],
            target_index_column_list=table_schema.target_index_column_list or [],
            column_mappings=table_schema.column_mappings or {},
            is_case_sensitive=table_schema.is_case_sensitive or False,
            chunk_number=table_schema.chunk_number,
            max_failed_rows_number=table_schema.max_failed_rows_number
            or self.max_failed_rows_number,
            exclude_metrics=(
                table_schema.exclude_metrics
                if table_schema.exclude_metrics is not None
                else self.exclude_metrics
            ),
            apply_metric_column_modifier=(
                table_schema.apply_metric_column_modifier
                if table_schema.apply_metric_column_modifier is not None
                else self.apply_metric_column_modifier
            ),
            object_type=object_type,
            partition_column=table_schema.partition_column,
            schema_validation=schema_val,
            metrics_validation=metrics_val,
            row_validation=row_val,
            row_validation_mode=row_mode,
            continue_on_failure=cont_fail,
        )

    @staticmethod
    def _resolve_bool(
        table_vc: object | None, attr_name: str, global_default: bool
    ) -> bool:
        """Resolve a boolean value from per-table override or global default."""
        if table_vc is not None:
            val = getattr(table_vc, attr_name, None)
            if val is not None:
                return val
        return global_default
