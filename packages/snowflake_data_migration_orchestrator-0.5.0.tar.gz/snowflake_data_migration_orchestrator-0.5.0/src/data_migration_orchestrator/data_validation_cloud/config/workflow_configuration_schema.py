"""
Pydantic schema for structural validation of data validation workflow configurations.

Validates the raw JSON config dict before the ValidationConfigurationParser
performs semantic validation and builds domain objects.
"""

from pydantic import BaseModel, ConfigDict, Field, field_validator


class ValidationLevelSchema(BaseModel):
    """Schema for the validation_configuration block."""

    model_config = ConfigDict(extra="forbid")

    schema_validation: bool | None = None
    metrics_validation: bool | None = None
    row_validation: bool | None = None
    row_validation_mode: str | None = None
    continue_on_failure: bool | None = None
    max_failed_rows_number: int | None = Field(default=None, gt=0)
    exclude_metrics: bool | None = None
    apply_metric_column_modifier: bool | None = None


class ComparisonSchema(BaseModel):
    """Schema for the comparison_configuration block."""

    model_config = ConfigDict(extra="forbid")

    tolerance: float | None = Field(default=None, gt=0)
    type_mapping_file_path: str | None = None


class TableSchema(BaseModel):
    """Schema for a single table configuration entry."""

    model_config = ConfigDict(extra="forbid")

    fully_qualified_name: str
    use_column_selection_as_exclude_list: bool = False
    column_selection_list: list[str] = Field(default_factory=list)
    target_name: str | None = None
    target_database: str | None = None
    target_schema: str | None = None
    where_clause: str | None = None
    target_where_clause: str | None = None
    index_column_list: list[str] | None = None
    target_index_column_list: list[str] | None = None
    column_mappings: dict[str, str] | None = None
    is_case_sensitive: bool | None = None
    chunk_number: int | None = Field(default=None, gt=0)
    max_failed_rows_number: int | None = Field(default=None, gt=0)
    exclude_metrics: bool | None = None
    apply_metric_column_modifier: bool | None = None
    object_type: str | None = None
    partition_column: str | None = None
    validation_configuration: ValidationLevelSchema | None = None


class DataValidationWorkflowConfigurationSchema(BaseModel):
    """
    Top-level schema for a Data Validation Workflow configuration.

    Aligned with SDV ConfigurationModel fields, minus connection/output fields.
    """

    model_config = ConfigDict(extra="forbid")

    source_platform: str
    target_platform: str = "Snowflake"
    target_database: str | None = None
    validation_configuration: ValidationLevelSchema | None = None
    comparison_configuration: ComparisonSchema | None = None
    database_mappings: dict[str, str] | None = None
    schema_mappings: dict[str, str] | None = None
    tables: list[TableSchema]
    views: list[TableSchema] | None = None
    affinity: str | None = None
    use_snowflake_compute: bool = False

    @field_validator("tables")
    @classmethod
    def tables_must_not_be_empty(cls, v: list[TableSchema]) -> list[TableSchema]:
        """Ensure at least one table is configured."""
        if len(v) == 0:
            raise ValueError("'tables' must contain at least one table configuration")
        return v


def validate_data_validation_workflow_configuration(
    configuration: dict | None,
) -> DataValidationWorkflowConfigurationSchema:
    """
    Validate a raw data validation workflow configuration dict.

    Args:
        configuration: Raw config dict from the workflow, or None.

    Returns:
        Validated schema model.

    Raises:
        ValueError: If configuration is None or structurally invalid.

    """
    if configuration is None:
        raise ValueError("Workflow configuration must not be None")

    return DataValidationWorkflowConfigurationSchema.model_validate(configuration)
