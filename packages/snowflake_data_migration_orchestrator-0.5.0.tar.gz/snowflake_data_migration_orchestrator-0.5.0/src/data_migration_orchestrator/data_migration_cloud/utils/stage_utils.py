"""Utilities for reading staged data in Snowflake."""

import asyncio

from dataclasses import dataclass
from typing import Any

from data_migration_orchestrator.cloud_core.constants.file_formats import (
    parquet_file_format_fqn,
)
from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.data_migration_cloud.config.extraction_strategy import (
    ExtractionStrategy,
)
from data_migration_orchestrator.data_migration_cloud.constants.stages import (
    default_internal_stage,
)


logger = get_logger("utils.stage_utils")


# =============================================================================
# Stage Resolution for Extraction Strategies
# =============================================================================


@dataclass
class StageResolution:
    """Result of resolving stage information for an extraction strategy."""

    stage_id: str
    """The Snowflake stage identifier to use (e.g., @MY_DB.MY_SCHEMA.MY_STAGE)"""

    is_external: bool
    """Whether this is an external stage (e.g., S3-backed)"""

    external_stage_base_path: str | None = None
    """
    For external stages, the base path within the stage for data files.
    This path is relative to the stage root and maps to the S3 prefix.
    Example: If stage points to s3://bucket/prefix/ and data is at
    s3://bucket/prefix/workflow_1/table_2/, this would be "workflow_1/table_2/"
    """


def resolve_stage_for_strategy(
    extraction_strategy: ExtractionStrategy,
    strategy_config: dict[str, Any] | None = None,
    workflow_external_stage: str | None = None,
    table_external_stage: str | None = None,
) -> StageResolution:
    """
    Resolve the appropriate stage to use based on the extraction strategy.

    Different extraction strategies may require different stages:
    - REGULAR: Uses the default internal stage (@TASK_RESULTS)
    - UNLOAD: Uses an external stage pointing to S3 (configured via table_external_stage,
              strategy_config, or workflow_external_stage)

    For UNLOAD strategy, the external stage can be configured (in order of precedence):
    1. Via table_external_stage parameter (from table's strategy.externalStage config)
    2. Via 'external_stage' key in strategy_config (workflow-level config)
    3. Via the workflow_external_stage parameter (fallback, typically from
       workflow's target_cloud_stage_name)

    The stage should be a Snowflake external stage that points to the S3 bucket
    where UNLOAD writes data.

    Args:
        extraction_strategy: The extraction strategy being used
        strategy_config: Strategy-specific configuration from the workflow (deprecated)
        workflow_external_stage: Optional fallback external stage from workflow config
        table_external_stage: External stage from table's strategy configuration

    Returns:
        StageResolution containing stage_id, is_external flag, and optional base path

    Raises:
        ValueError: If UNLOAD strategy is used but no external_stage is available

    Example:
        >>> result = resolve_stage_for_strategy(
        ...     ExtractionStrategy.UNLOAD,
        ...     table_external_stage="@MY_DB.MY_SCHEMA.S3_STAGE"
        ... )
        >>> result.stage_id
        '@MY_DB.MY_SCHEMA.S3_STAGE'
        >>> result.is_external
        True

    """
    if extraction_strategy == ExtractionStrategy.UNLOAD:
        # Priority: table config > workflow strategy_config > workflow external stage
        external_stage = table_external_stage

        if not external_stage and strategy_config:
            external_stage = strategy_config.get("external_stage")

        if not external_stage:
            external_stage = workflow_external_stage

        if not external_stage:
            raise ValueError(
                "UNLOAD extraction strategy requires 'externalStage' in the table's "
                "strategy configuration or a workflow-level external stage. "
                "This should be a Snowflake external stage pointing to the S3 bucket "
                "where UNLOAD will write data (e.g., @MY_DB.MY_SCHEMA.S3_STAGE)."
            )

        # Normalize the stage identifier (ensure it starts with @)
        stage_id = (
            external_stage if external_stage.startswith("@") else f"@{external_stage}"
        )

        # Get optional S3 prefix for path computation
        s3_prefix = ""
        if strategy_config:
            s3_prefix = strategy_config.get("s3_prefix", "")
        if s3_prefix:
            s3_prefix = s3_prefix.strip("/")

        return StageResolution(
            stage_id=stage_id,
            is_external=True,
            external_stage_base_path=s3_prefix if s3_prefix else None,
        )

    # Default: REGULAR strategy uses internal stage
    return StageResolution(
        stage_id=default_internal_stage(),
        is_external=False,
    )


def build_external_stage_data_path(
    stage_resolution: StageResolution,
    workflow_id: int,
    table_metadata_id: int,
    partition_index: int,
) -> str:
    """
    Build the full path for data files when using an external stage.

    For UNLOAD strategy, data is written directly to S3 by Redshift, and then
    Snowflake reads it via an external stage. Uses the same relative path
    structure as internal stages for consistency.

    Args:
        stage_resolution: The resolved stage information
        workflow_id: The workflow ID
        table_metadata_id: The table metadata ID
        partition_index: The partition index

    Returns:
        Full stage path for the partition data (stage + optional base path + relative path)

    """
    # Build the base: stage_id + optional external_stage_base_path
    base_parts = [stage_resolution.stage_id.rstrip("/")]
    if stage_resolution.external_stage_base_path:
        base_parts.append(stage_resolution.external_stage_base_path.strip("/"))

    base = "/".join(base_parts)

    # Use the standard relative path structure
    relative = relative_path_for_partition_data(
        workflow_id, table_metadata_id, partition_index
    )

    return f"{base}/{relative}"


# =============================================================================
# Deterministic Path Computation Functions
# =============================================================================
#
# Paths follow a consistent structure with two layers:
#
# 1. RELATIVE PATHS (platform-agnostic, no base):
#    task_results/workflows/{workflow_id}/tables/{table_metadata_id}/{subfolder}
#
# 2. ABSOLUTE PATHS (with base):
#    - Snowflake stage: @{stage_id}/{relative_path}
#    - S3 (for UNLOAD): DEA prepends its configured s3_bucket + s3_prefix
#
# Where {subfolder} can be:
#   - data/full_table or data/partition_{N} - extracted data files
#   - schema/ - source table schema metadata
#   - metadata/ - table row count and size metadata
#   - boundaries/ - partition boundary definitions
#   - checksum/partition_{N} - checksum computation results
#
# Both internal stage uploads and UNLOAD use the same relative path structure.
# =============================================================================


# -----------------------------------------------------------------------------
# Relative Path Functions (platform-agnostic, no base)
# -----------------------------------------------------------------------------
# These functions generate paths without any base prefix.
# Use these when you need to:
#   - Pass relative paths to external systems (e.g., DEA for UNLOAD)
#   - Build paths that will have different bases in different contexts
# -----------------------------------------------------------------------------


def _relative_base_path(workflow_id: int, table_metadata_id: int) -> str:
    """
    Generate the relative base path for a table in a workflow.

    This is the root path structure (without any stage/S3 prefix) under which
    all table-related artifacts are stored.

    Args:
        workflow_id: The workflow ID for the current migration
        table_metadata_id: The unique identifier for the table metadata

    Returns:
        Relative path like task_results/workflows/{id}/tables/{id}

    """
    return f"task_results/workflows/{workflow_id}/tables/{table_metadata_id}"


def relative_path_for_partition_data(
    workflow_id: int, table_metadata_id: int, partition_index: int
) -> str:
    """
    Generate the relative path for partition data (no base prefix).

    Use this for UNLOAD operations where the DEA will prepend its S3 bucket,
    or when you need just the path structure.

    Args:
        workflow_id: The workflow ID for the current migration
        table_metadata_id: The unique identifier for the table metadata
        partition_index: The index of the partition (0 for full table, >0 for partitions)

    Returns:
        Relative path like task_results/.../data/partition_{N}/

    """
    base_path = _relative_base_path(workflow_id, table_metadata_id)
    partition_fragment = (
        f"partition_{partition_index}" if partition_index > 0 else "full_table"
    )
    return f"{base_path}/data/{partition_fragment}/"


def relative_path_for_schema(workflow_id: int, table_metadata_id: int) -> str:
    """
    Generate the relative path for source table schema metadata (no base prefix).

    Args:
        workflow_id: The workflow ID for the current migration
        table_metadata_id: The unique identifier for the table metadata

    Returns:
        Relative path like task_results/.../schema/

    """
    base_path = _relative_base_path(workflow_id, table_metadata_id)
    return f"{base_path}/schema/"


def relative_path_for_metadata(workflow_id: int, table_metadata_id: int) -> str:
    """
    Generate the relative path for table metadata (no base prefix).

    Args:
        workflow_id: The workflow ID for the current migration
        table_metadata_id: The unique identifier for the table metadata

    Returns:
        Relative path like task_results/.../metadata/

    """
    base_path = _relative_base_path(workflow_id, table_metadata_id)
    return f"{base_path}/metadata/"


def relative_path_for_boundaries(workflow_id: int, table_metadata_id: int) -> str:
    """
    Generate the relative path for partition boundaries (no base prefix).

    Args:
        workflow_id: The workflow ID for the current migration
        table_metadata_id: The unique identifier for the table metadata

    Returns:
        Relative path like task_results/.../boundaries/

    """
    base_path = _relative_base_path(workflow_id, table_metadata_id)
    return f"{base_path}/boundaries/"


def relative_path_for_checksum(
    workflow_id: int, table_metadata_id: int, partition_index: int
) -> str:
    """
    Generate the relative path for checksum results (no base prefix).

    Args:
        workflow_id: The workflow ID for the current migration
        table_metadata_id: The unique identifier for the table metadata
        partition_index: The index of the partition

    Returns:
        Relative path like task_results/.../checksum/partition_{N}/

    """
    base_path = _relative_base_path(workflow_id, table_metadata_id)
    return f"{base_path}/checksum/partition_{partition_index}/"


# -----------------------------------------------------------------------------
# Stage Path Functions (Snowflake stage base + relative path)
# -----------------------------------------------------------------------------
# These functions prepend a Snowflake stage identifier to the relative path.
# Use these when working with Snowflake internal stages.
# -----------------------------------------------------------------------------


def stage_path_for_partition_data(
    stage_id: str, workflow_id: int, table_metadata_id: int, partition_index: int
) -> str:
    """
    Generate the full stage path for partition data in Snowflake.

    Args:
        stage_id: The Snowflake stage identifier (e.g., @MY_DB.MY_SCHEMA.MY_STAGE)
        workflow_id: The workflow ID for the current migration
        table_metadata_id: The unique identifier for the table metadata
        partition_index: The index of the partition (0 for full table, >0 for partitions)

    Returns:
        Full path like @STAGE/task_results/.../data/partition_{N}/

    """
    relative = relative_path_for_partition_data(
        workflow_id, table_metadata_id, partition_index
    )
    return f"{stage_id}/{relative}"


def stage_path_for_schema(
    stage_id: str, workflow_id: int, table_metadata_id: int
) -> str:
    """
    Generate the full stage path for source table schema metadata.

    Args:
        stage_id: The Snowflake stage identifier (e.g., @MY_DB.MY_SCHEMA.MY_STAGE)
        workflow_id: The workflow ID for the current migration
        table_metadata_id: The unique identifier for the table metadata

    Returns:
        Full path like @STAGE/task_results/.../schema/

    """
    relative = relative_path_for_schema(workflow_id, table_metadata_id)
    return f"{stage_id}/{relative}"


def stage_path_for_metadata(
    stage_id: str, workflow_id: int, table_metadata_id: int
) -> str:
    """
    Generate the full stage path for table metadata (row count, size).

    Args:
        stage_id: The Snowflake stage identifier (e.g., @MY_DB.MY_SCHEMA.MY_STAGE)
        workflow_id: The workflow ID for the current migration
        table_metadata_id: The unique identifier for the table metadata

    Returns:
        Full path like @STAGE/task_results/.../metadata/

    """
    relative = relative_path_for_metadata(workflow_id, table_metadata_id)
    return f"{stage_id}/{relative}"


def stage_path_for_boundaries(
    stage_id: str, workflow_id: int, table_metadata_id: int
) -> str:
    """
    Generate the full stage path for partition boundaries.

    Args:
        stage_id: The Snowflake stage identifier (e.g., @MY_DB.MY_SCHEMA.MY_STAGE)
        workflow_id: The workflow ID for the current migration
        table_metadata_id: The unique identifier for the table metadata

    Returns:
        Full path like @STAGE/task_results/.../boundaries/

    """
    relative = relative_path_for_boundaries(workflow_id, table_metadata_id)
    return f"{stage_id}/{relative}"


def stage_path_for_checksum(
    stage_id: str, workflow_id: int, table_metadata_id: int, partition_index: int
) -> str:
    """
    Generate the full stage path for checksum computation results.

    Args:
        stage_id: The Snowflake stage identifier (e.g., @MY_DB.MY_SCHEMA.MY_STAGE)
        workflow_id: The workflow ID for the current migration
        table_metadata_id: The unique identifier for the table metadata
        partition_index: The index of the partition

    Returns:
        Full path like @STAGE/task_results/.../checksum/partition_{N}/

    """
    relative = relative_path_for_checksum(
        workflow_id, table_metadata_id, partition_index
    )
    return f"{stage_id}/{relative}"


async def read_metadata_from_stage(
    warehouse_proxy, metadata_location: str
) -> dict[str, Any]:
    """
    Read table metadata from Snowflake stage.

    Queries staged Parquet file directly without loading.
    Returns: {'row_count': int, 'data_size_mb': float}
    """
    query = f"""
        SELECT
            $1:row_count AS row_count,
            $1:data_size_mb AS data_size_mb
        FROM {metadata_location}
        (FILE_FORMAT => '{parquet_file_format_fqn()}',
        PATTERN => '.*[.]parquet')
        LIMIT 1
    """
    logger.info(f"Read metadata from stage: {query}")

    result = await warehouse_proxy.execute_sync_query(query)

    if not result:
        raise ValueError(
            f"No metadata found at {metadata_location}. "
            "This typically indicates that the source table does not exist or is empty. "
            "Please verify that the table name specified in your configuration exists "
            "in the source database."
        )

    row = result[0]

    # Extract values from result (Snowflake returns uppercase column names)
    row_count_raw = row.get("ROW_COUNT") or row.get("row_count")
    data_size_mb_raw = row.get("DATA_SIZE_MB") or row.get("data_size_mb")

    if row_count_raw is None:
        raise ValueError(f"Missing row_count in staged metadata at {metadata_location}")
    if data_size_mb_raw is None:
        raise ValueError(
            f"Missing data_size_mb in staged metadata at {metadata_location}"
        )

    row_count = int(row_count_raw)
    data_size_mb = float(data_size_mb_raw)

    if row_count < 0 or data_size_mb < 0:
        raise ValueError(
            f"Invalid values: row_count={row_count}, data_size_mb={data_size_mb}"
        )

    return {"row_count": row_count, "data_size_mb": data_size_mb}


async def read_boundaries_from_stage(
    warehouse_proxy, boundaries_location: str
) -> list[dict[str, Any]]:
    """
    Read partition boundaries from Snowflake stage.

    Returns: [{'partition_id': int, 'min_value_in_partition': Any,
               'max_value_in_partition': Any, 'n_rows': int}, ...]
    """
    query = f"""
        SELECT
            $1:partition_id AS partition_id,
            $1:min_value_in_partition AS min_value_in_partition,
            $1:max_value_in_partition AS max_value_in_partition,
            $1:n_rows AS n_rows
        FROM {boundaries_location}
        (FILE_FORMAT => '{parquet_file_format_fqn()}',
        PATTERN => '.*[.]parquet')
        ORDER BY partition_id
    """
    logger.info(f"Read boundaries from stage: {query}")

    result = await warehouse_proxy.execute_sync_query(query)

    if not result or len(result) < 2:
        raise ValueError(f"Invalid boundaries at {boundaries_location}")

    # Parse results (Snowflake returns uppercase column names)
    boundaries = []
    for row in result:
        partition_id_raw = row.get("PARTITION_ID") or row.get("partition_id")
        if partition_id_raw is None:
            raise ValueError(
                f"Missing partition_id in staged boundary data at {boundaries_location}"
            )
        partition_id = int(partition_id_raw)

        min_value_in_partition = row.get("MIN_VALUE_IN_PARTITION") or row.get(
            "min_value_in_partition"
        )
        max_value_in_partition = row.get("MAX_VALUE_IN_PARTITION") or row.get(
            "max_value_in_partition"
        )
        n_rows_raw = row.get("N_ROWS") or row.get("n_rows")

        if n_rows_raw is None:
            raise ValueError(
                f"Missing n_rows in staged boundary data at {boundaries_location}"
            )
        n_rows = int(n_rows_raw)

        boundaries.append(
            {
                "partition_id": partition_id,
                "min_value_in_partition": min_value_in_partition,
                "max_value_in_partition": max_value_in_partition,
                "n_rows": n_rows,
            }
        )

    return boundaries


async def read_schema_from_stage(
    warehouse_proxy, schema_location: str
) -> list[dict[str, Any]]:
    """
    Read source table schema metadata from Snowflake stage.

    Returns: [{'column_name': str, 'data_type': str, 'max_length': int|None,
               'precision': int|None, 'scale': int|None, 'is_nullable': str,
               'ordinal_position': int}, ...]
    """
    query = f"""
        SELECT
            $1:column_name AS column_name,
            $1:data_type AS data_type,
            $1:max_length AS max_length,
            $1:precision AS precision,
            $1:scale AS scale,
            $1:is_nullable AS is_nullable,
            $1:ordinal_position AS ordinal_position
        FROM {schema_location}
        (FILE_FORMAT => '{parquet_file_format_fqn()}',
        PATTERN => '.*[.]parquet')
        ORDER BY ordinal_position
    """
    logger.info(f"Read schema from stage: {query}")

    # TODO(SNOW-2993674): Remove this after improving stage fetch processes
    await asyncio.sleep(3)
    print(f"Executing query: {query} after 5 seconds")
    result = await warehouse_proxy.execute_sync_query(query)

    if not result:
        raise ValueError(
            f"No schema found at {schema_location}. "
            "This typically indicates that the source table does not exist. "
            "Please verify that the table name specified in your configuration exists "
            "in the source database."
        )

    schema = []
    for row in result:
        column_name = row.get("COLUMN_NAME") or row.get("column_name")
        data_type = row.get("DATA_TYPE") or row.get("data_type")
        ordinal_position_raw = row.get("ORDINAL_POSITION") or row.get(
            "ordinal_position"
        )

        if not column_name or not data_type or ordinal_position_raw is None:
            raise ValueError(
                f"Missing required schema fields in staged data at {schema_location}"
            )

        max_length_raw = row.get("MAX_LENGTH") or row.get("max_length")
        precision_raw = row.get("PRECISION") or row.get("precision")
        scale_raw = row.get("SCALE") or row.get("scale")
        is_nullable = row.get("IS_NULLABLE") or row.get("is_nullable")

        schema.append(
            {
                "column_name": column_name.strip('"'),
                "data_type": data_type.strip('"').upper(),
                "max_length": (
                    int(max_length_raw) if max_length_raw is not None else None
                ),
                "precision": int(precision_raw) if precision_raw is not None else None,
                "scale": int(scale_raw) if scale_raw is not None else None,
                "is_nullable": is_nullable,
                "ordinal_position": int(ordinal_position_raw),
            }
        )

    return schema
