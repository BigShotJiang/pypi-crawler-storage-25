"""
Checksum task creator for CHECKSUM sync strategy.

Creates COMPARE_PARTITION_CHECKSUM tasks for partition-level checksum comparison.
"""

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.queues.base_task_queue import (
    BaseTaskQueue,
)
from data_migration_orchestrator.cloud_core.tasks.task_builder import TaskBuilder
from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    TableIdentifier,
)
from data_migration_orchestrator.data_migration_cloud.constants.priorities import (
    compute_priority_for_extraction_task,
)
from data_migration_orchestrator.data_migration_cloud.platforms.platform_registry import (
    PlatformRegistry,
)
from data_migration_orchestrator.data_migration_cloud.scope import ScopeBuilder
from data_migration_orchestrator.data_migration_cloud.tasks.models.synchronization_data import (
    ChecksumSyncData,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload import (
    ComparePartitionChecksumPayload,
)
from data_migration_orchestrator.data_migration_cloud.tasks.task_chain_creator import (
    PartitionInput,
)
from shared.enums.source_type import SourceType


logger = get_logger("tasks.checksum_task_creator")


class ChecksumTaskCreator:
    """Creates COMPARE_PARTITION_CHECKSUM tasks for CHECKSUM sync strategy."""

    def __init__(self, task_queue: BaseTaskQueue):
        """Initialize with task queue."""
        self.task_queue = task_queue

    async def create_checksum_comparison_tasks(
        self,
        workflow_id: int,
        table_metadata_id: int,
        source_table_id: TableIdentifier,
        source_type: SourceType,
        target_table: str,
        partition_inputs: list[PartitionInput],
        avg_row_size_bytes: float | None = None,
    ) -> list[int]:
        """
        Create COMPARE_PARTITION_CHECKSUM tasks for CHECKSUM strategy.

        For each partition, creates a single COMPARE_CHECKSUM task that will:
        1. Compute the source partition checksum
        2. Compare with stored checksum (if any)
        3. Dynamically create extraction chain if checksum changed

        This approach avoids pre-creating tasks that may not be needed.

        Args:
            workflow_id: The workflow ID
            table_metadata_id: The table metadata ID
            source_table_id: The source table identifier
            source_type: The source type (e.g., sqlserver, redshift)
            target_table: The fully qualified target table name
            partition_inputs: List of partition inputs with boundaries and sync data
            avg_row_size_bytes: Average row size in bytes for batch size calculation

        Returns:
            List of created task IDs

        """
        task_ids: list[int] = []

        platform = PlatformRegistry.create(source_type)
        for partition_input in partition_inputs:
            partition_id = partition_input.partition_metadata_id

            if partition_id is None:
                raise ValueError(
                    f"Partition metadata ID is required for partition {partition_input.partition_index}"
                )

            checksum_scope = (
                ScopeBuilder.for_table(source_table_id, platform)
                .partition(partition_id)
                .extraction()  # Checksum comparison is part of extraction phase
            )

            # Extract stored checksum from sync_data if available
            stored_checksum: str | None = None
            if partition_input.sync_data is not None and isinstance(
                partition_input.sync_data, ChecksumSyncData
            ):
                stored_checksum = partition_input.sync_data.checksum

            # Create COMPARE_PARTITION_CHECKSUM task
            task_name = (
                f"Compare checksum for partition #{partition_input.partition_index}"
                f" of {source_table_id.fully_qualified_friendly_name}"
            )
            compare_task = (
                TaskBuilder(
                    workflow_id=workflow_id,
                    executor_type=ExecutorType.ORCHESTRATOR,
                    task_name=task_name,
                    scope=checksum_scope,
                    payload=ComparePartitionChecksumPayload(
                        partition_metadata_id=partition_id,
                        table_metadata_id=table_metadata_id,
                        partition_number=partition_input.partition_index,
                        min_value=partition_input.partition_boundary.min_value,
                        max_value=partition_input.partition_boundary.max_value,
                        stored_checksum=stored_checksum,
                        database=source_table_id.database_name,
                        schema=source_table_id.schema_name,
                        table_name=source_table_id.table_name,
                        source_type=source_type.value,
                        target_table=target_table,
                        avg_row_size_bytes=avg_row_size_bytes,
                    ),
                )
                .with_priority(compute_priority_for_extraction_task(partition_id))
                .blocked()
                .build()
            )
            compare_task_id = await self.task_queue.push_task(compare_task)

            task_ids.append(compare_task_id)
            logger.info(
                f"Created COMPARE_CHECKSUM task {compare_task_id} for "
                f"partition #{partition_input.partition_index} (stored_checksum={stored_checksum})"
            )

        return task_ids
