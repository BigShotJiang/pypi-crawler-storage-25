"""
Process analyze results handler.

Reads partition boundaries and creates parallel extraction chains.
"""

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_core.tasks.executor_type import ExecutorType
from data_migration_orchestrator.cloud_core.tasks.queues.base_task_queue import (
    BaseTaskQueue,
)
from data_migration_orchestrator.cloud_core.tasks.task import Task
from data_migration_orchestrator.cloud_core.warehouse import Warehouse
from data_migration_orchestrator.data_migration_cloud.config.sync_strategy import (
    SyncStrategy,
)
from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    TableIdentifier,
)
from data_migration_orchestrator.data_migration_cloud.constants.stages import (
    default_internal_stage,
)
from data_migration_orchestrator.data_migration_cloud.platforms.platform_registry import (
    PlatformRegistry,
)
from data_migration_orchestrator.data_migration_cloud.services.batch_size_calculator import (
    calculate_suggested_batch_size_from_bytes,
)
from data_migration_orchestrator.data_migration_cloud.tasks.checksum_task_creator import (
    ChecksumTaskCreator,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.base_task_handler import (
    BaseTaskHandler,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.partition_boundary_generator import (
    PartitionBoundaryGenerator,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.partition_reuse_service import (
    ExistingPartition,
    PartitionReuseService,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.synchronization_config_service import (
    SynchronizationConfigService,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.table_configuration_service import (
    TableConfigurationService,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.workflow_config_service import (
    WorkflowConfigService,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.workflow_progress_service import (
    WorkflowProgressService,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload import (
    CreatePartitionTasksPayload,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload_kind import (
    TaskPayloadKind,
)
from data_migration_orchestrator.data_migration_cloud.tasks.task_chain_creator import (
    PartitionInput,
    TaskChainContext,
    TaskChainCreator,
)
from data_migration_orchestrator.data_migration_cloud.utils.stage_utils import (
    read_boundaries_from_stage,
    read_schema_from_stage,
    resolve_stage_for_strategy,
    stage_path_for_boundaries,
    stage_path_for_schema,
)
from shared.enums.source_type import SourceType


logger = get_logger("tasks.handlers.create_partition_tasks")


class CreatePartitionTasksHandler(BaseTaskHandler):
    """Creates N parallel extraction chains: [EXTRACT -> LOAD -> COPY_INTO] × N."""

    def __init__(self, task_queue: BaseTaskQueue, warehouse: Warehouse):
        """Initialize handler with task queue and warehouse proxy."""
        super().__init__(
            TaskPayloadKind.CREATE_PARTITION_TASKS,
            task_queue,
            warehouse,
        )
        self.boundary_generator = PartitionBoundaryGenerator()
        self.progress_service = WorkflowProgressService(warehouse)
        self.sync_config_service = SynchronizationConfigService(warehouse)
        self.partition_reuse_service = PartitionReuseService(warehouse)
        self.table_config_service = TableConfigurationService(warehouse)
        self.workflow_config_service = WorkflowConfigService(warehouse)

    async def handle(self, task: Task) -> None:
        """
        Read boundaries and create N partitioned extraction chains.

        For incremental sync, if boundaries_location is empty, reads existing
        partitions from PARTITION_METADATA (preserving SYNCHRONIZATION_DATA).
        Otherwise, reads boundaries from the stage and generates new partitions.
        """
        if not isinstance(task.payload, CreatePartitionTasksPayload):
            raise ValueError(
                f"Expected CreatePartitionTasksPayload, got {type(task.payload)}"
            )

        payload = task.payload
        logger.info(
            f"CreatePartitionTasksHandler: table_metadata_id={payload.table_metadata_id}"
        )

        table_config = (
            await self.table_config_service.fetch_required_table_configuration(
                payload.table_metadata_id
            )
        )
        partition_column = table_config.partition_column

        # Fetch synchronization config for watermark-based extraction
        sync_config = await self.sync_config_service.fetch_synchronization_config(
            payload.table_metadata_id
        )
        logger.info(
            f"Using sync strategy: {sync_config.strategy.value} for {payload.table_name}"
        )

        # Build partition inputs based on the scenario:
        # 1. Existing partitions exist -> use them (incremental sync)
        # 2. Single partition (num_partitions=1) -> create directly (no boundaries)
        # 3. Multiple partitions -> read boundaries from stage
        existing_partitions = (
            await self.partition_reuse_service.get_existing_partitions(
                payload.table_metadata_id
            )
        )
        is_incremental = self._should_use_existing_partitions(existing_partitions)

        if is_incremental:
            partition_inputs = self._build_inputs_from_existing_partitions(
                payload, existing_partitions, partition_column
            )
        elif payload.num_partitions == 1:
            # Single partition - create directly without reading boundaries
            partition_inputs = await self._build_single_partition_input(
                payload, partition_column
            )
        else:
            # Multiple partitions - read boundaries from stage
            partition_inputs = await self._build_inputs_from_new_boundaries(
                task.workflow_id, payload, partition_column
            )

        logger.info(
            f"Creating {len(partition_inputs)} chains for {payload.table_name}"
            f"{' (incremental)' if is_incremental else ''}"
        )

        # Create parallel chains based on sync strategy
        try:
            if sync_config.strategy == SyncStrategy.CHECKSUM:
                # For CHECKSUM strategy, create COMPARE_CHECKSUM tasks
                # These will dynamically create extraction chains based on checksum comparison
                task_ids = await self._create_checksum_partition_tasks(
                    task.workflow_id,
                    payload,
                    partition_inputs,
                )
            else:
                # For NONE/WATERMARK strategies, create standard extraction chains
                task_ids = await self._create_regular_partition_tasks(
                    task.workflow_id,
                    payload,
                    partition_inputs,
                )
        except Exception as e:
            raise Exception(
                f"Failed to create partitioned extraction chains for {payload.table_name}: {e}"
            ) from e

        # Mark table as preprocessed (only for new partitions)
        if not is_incremental:
            await self.progress_service.update_table_preprocessed(
                payload.table_metadata_id
            )

        logger.info(f"Created {len(task_ids)} extraction tasks")

        # Complete
        if task.id is None:
            raise ValueError("Task ID is required")

        await self.task_queue.complete_task(
            consumer_type=ExecutorType.ORCHESTRATOR,
            task_id=task.id,
        )

    def _should_use_existing_partitions(
        self,
        existing_partitions: list[ExistingPartition],
    ) -> bool:
        """
        Determine if we should use existing partitions.

        Returns True if existing partitions exist (copied from a previous workflow).
        The sync strategy determines what happens during extraction (checksum comparison,
        watermark filtering, or full extraction), not whether we reuse partition boundaries.

        Args:
            existing_partitions: Partitions from PARTITION_METADATA table

        Returns:
            True if existing partitions should be reused, False otherwise

        """
        return len(existing_partitions) > 0

    def _build_inputs_from_existing_partitions(
        self,
        payload: CreatePartitionTasksPayload,
        existing_partitions: list[ExistingPartition],
        partition_column: str | None,
    ) -> list[PartitionInput]:
        """Build partition inputs from existing partitions (incremental sync)."""
        logger.info(
            f"Reusing existing partitions for {payload.table_name} (incremental sync)"
        )

        partition_inputs = []
        for existing in existing_partitions:
            boundary = self.boundary_generator.generate_single_boundary(
                partition_column=partition_column,
                partition_id=existing.partition_number,
                min_value=existing.min_value,
                max_value=existing.max_value,
                source_type=SourceType.from_string(payload.source_type),
            )
            partition_inputs.append(
                PartitionInput(
                    partition_index=existing.partition_number,
                    partition_boundary=boundary,
                    partition_metadata_id=existing.id,
                    sync_data=existing.synchronization_data,
                )
            )

        return partition_inputs

    async def _build_single_partition_input(
        self,
        payload: CreatePartitionTasksPayload,
        partition_column: str | None,
    ) -> list[PartitionInput]:
        """
        Build a single partition input for non-partitioned tables.

        For tables with num_partitions=1, no boundary analysis was done.
        We create a single partition covering the full table (no WHERE clause).
        """
        logger.info(
            f"Creating single partition for {payload.table_name} (no boundaries needed)"
        )

        # Insert partition metadata for tracking
        partition_metadata_id = await self.progress_service.insert_partition_metadata(
            table_metadata_id=payload.table_metadata_id,
            partition_number=0,
            min_value=None,
            max_value=None,
            rows=None,
        )

        if partition_metadata_id is None:
            raise Exception(
                f"Failed to insert partition metadata for {payload.table_name}"
            )

        # Generate boundary with no WHERE clause (full table)
        boundary = self.boundary_generator.generate_single_boundary(
            partition_column=partition_column,
            partition_id=0,
            min_value=None,
            max_value=None,
            source_type=SourceType.from_string(payload.source_type),
        )

        return [
            PartitionInput(
                partition_index=0,
                partition_boundary=boundary,
                partition_metadata_id=partition_metadata_id,
                sync_data=None,
            )
        ]

    async def _build_inputs_from_new_boundaries(
        self,
        workflow_id: int,
        payload: CreatePartitionTasksPayload,
        partition_column: str | None,
    ) -> list[PartitionInput]:
        """Build partition inputs from new boundaries (first-time sync with multiple partitions)."""
        # Compute boundaries location deterministically
        # TODO: Support external stages for UNLOAD strategy
        stage_id = default_internal_stage()
        boundaries_location = stage_path_for_boundaries(
            stage_id, workflow_id, payload.table_metadata_id
        )

        try:
            boundary_values = await read_boundaries_from_stage(
                self.warehouse_proxy, boundaries_location
            )
        except Exception as e:
            raise Exception(
                f"Failed to read boundaries from {boundaries_location}: {e}"
            ) from e

        partitions = self.boundary_generator.generate_boundaries(
            partition_column=partition_column,
            boundary_values=boundary_values,
            num_partitions=payload.num_partitions,
            source_type=SourceType.from_string(payload.source_type),
        )

        batch_tuples = [
            (p.partition_index, p.min_value, p.max_value) for p in partitions
        ]
        id_map = await self.progress_service.insert_partition_metadata_batch(
            table_metadata_id=payload.table_metadata_id,
            partitions=batch_tuples,
        )

        partition_inputs = []
        for partition in partitions:
            partition_metadata_id = id_map.get(partition.partition_index)
            if partition_metadata_id is None:
                raise Exception(
                    f"Failed to get partition metadata ID for partition {partition.partition_index}"
                )
            partition_inputs.append(
                PartitionInput(
                    partition_index=partition.partition_index,
                    partition_boundary=partition,
                    partition_metadata_id=partition_metadata_id,
                    sync_data=None,
                )
            )

        return partition_inputs

    async def _create_checksum_partition_tasks(
        self,
        workflow_id: int,
        payload: CreatePartitionTasksPayload,
        partition_inputs: list[PartitionInput],
    ) -> list[int]:
        """Create COMPARE_PARTITION_CHECKSUM tasks for CHECKSUM strategy."""
        source_type = SourceType.from_string(payload.source_type)
        source_table_id = TableIdentifier(
            database_name=payload.database,
            schema_name=payload.schema,
            table_name=payload.table_name,
        )

        checksum_task_creator = ChecksumTaskCreator(self.task_queue)
        return await checksum_task_creator.create_checksum_comparison_tasks(
            workflow_id=workflow_id,
            table_metadata_id=payload.table_metadata_id,
            source_table_id=source_table_id,
            source_type=source_type,
            target_table=payload.target_table,
            partition_inputs=partition_inputs,
            avg_row_size_bytes=payload.avg_row_size_bytes,
        )

    async def _create_regular_partition_tasks(
        self,
        workflow_id: int,
        payload: CreatePartitionTasksPayload,
        partition_inputs: list[PartitionInput],
    ) -> list[int]:
        """
        Create N independent chains: EXTRACT -> LOAD for each partition.

        Used for NONE and WATERMARK strategies. For WATERMARK, the extraction
        query includes a filter based on the max watermark value.
        """
        suggested_batch_size = (
            None
            if payload.avg_row_size_bytes is None
            else calculate_suggested_batch_size_from_bytes(payload.avg_row_size_bytes)
        )

        platform = PlatformRegistry.create_by_name_or_alias(payload.source_type)
        table_config = (
            await self.table_config_service.fetch_required_table_configuration(
                payload.table_metadata_id
            )
        )

        # Fetch strategy config and resolve stage based on extraction strategy
        strategy_config = await self.workflow_config_service.fetch_strategy_config(
            workflow_id, table_config.extraction_strategy.value
        )
        # Fetch workflow's external stage as fallback for strategies that need it
        workflow_external_stage = (
            await self.workflow_config_service.fetch_workflow_external_stage(
                workflow_id
            )
        )
        stage_resolution = resolve_stage_for_strategy(
            table_config.extraction_strategy,
            strategy_config,
            workflow_external_stage,
            table_external_stage=table_config.extraction.external_stage,
        )

        # Read source schema so extraction queries can apply server-side type
        # conversions for problematic types (geography, geometry, etc.).
        # Schema is always stored on internal stage (PUT only works with internal stages)
        schema_location = stage_path_for_schema(
            default_internal_stage(), workflow_id, payload.table_metadata_id
        )
        source_schema = await read_schema_from_stage(
            self.warehouse_proxy, schema_location
        )

        task_chain_context = TaskChainContext(
            workflow_id=workflow_id,
            table_metadata_id=payload.table_metadata_id,
            table_config=table_config,
            source_schema=source_schema,
            suggested_batch_size=suggested_batch_size,
            strategy_config=strategy_config or {},
            external_stage_location=(
                stage_resolution.stage_id if stage_resolution.is_external else None
            ),
        )
        task_chain_creator = TaskChainCreator(
            platform, self.task_queue, task_chain_context
        )
        return await task_chain_creator.build_task_chains_for_extraction_and_load(
            partition_inputs=partition_inputs,
        )
