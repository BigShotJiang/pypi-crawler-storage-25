"""
Service for fetching workflow configuration with LRU caching.

This module provides a service to fetch the full workflow configuration
from the WORKFLOW table and extract strategy-specific configuration
sections, avoiding the need to thread raw dicts through payloads.
"""

import json

from typing import Any, cast

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_core.warehouse import Warehouse
from data_migration_orchestrator.cloud_core.workflows import workflow_columns
from data_migration_orchestrator.utils.lru_cache import LRUCache
from data_migration_orchestrator.utils.snowflake_metadata import (
    qualified_migration_schema,
)


logger = get_logger("tasks.handlers.workflow_config_service")


# Cache for full workflow configuration by workflow_id
# Shared across all WorkflowConfigService instances
_workflow_config_cache: LRUCache[int, dict[str, Any] | None] = LRUCache(
    max_size=100,
    ttl_seconds=7200.0,  # 2 hours (workflow config doesn't change mid-run)
)

# Key used in the workflow configuration JSON for strategy-specific settings
STRATEGY_CONFIG_KEY = "strategyConfig"


class WorkflowConfigService:
    """
    Service for fetching workflow configuration from the WORKFLOW table.

    Replaces the pattern of threading strategy_config / workflow_config
    through task payloads. Configuration is fetched on demand and cached
    with LRU+TTL, matching the pattern used by SynchronizationConfigService
    and the staged-data-handler mapping caches.
    """

    def __init__(self, warehouse_proxy: Warehouse):
        """
        Initialize the workflow config service.

        Args:
            warehouse_proxy: Proxy for executing warehouse queries

        """
        self.warehouse_proxy = warehouse_proxy

    async def fetch_workflow_config(self, workflow_id: int) -> dict[str, Any] | None:
        """
        Fetch the full CONFIGURATION column from the WORKFLOW table.

        Args:
            workflow_id: ID of the workflow

        Returns:
            Parsed configuration dict, or None if not found

        """
        # Check cache first
        cached = _workflow_config_cache.get_with_sentinel(workflow_id)
        if cached is not LRUCache.NOT_FOUND:
            cached_value = cast(dict[str, Any] | None, cached)
            if cached_value is not None:
                logger.debug(
                    "Cache hit: workflow config for workflow_id=%s", workflow_id
                )
            return cached_value

        # Cache miss — fetch from database
        try:
            query = f"""
                SELECT {workflow_columns.CONFIGURATION}
                FROM {qualified_migration_schema()}.WORKFLOW
                WHERE ID = {workflow_id}
            """
            result = await self.warehouse_proxy.execute_sync_query(query)

            config: dict[str, Any] | None = None
            if result and len(result) > 0:
                raw = result[0].get(workflow_columns.CONFIGURATION)
                if raw:
                    try:
                        config = json.loads(raw) if isinstance(raw, str) else raw
                    except (json.JSONDecodeError, TypeError) as e:
                        logger.warning(
                            "Failed to parse workflow config for workflow_id=%s: %s",
                            workflow_id,
                            e,
                        )

            _workflow_config_cache.set(workflow_id, config)

            if config is not None:
                logger.debug(
                    "Fetched and cached workflow config for workflow_id=%s",
                    workflow_id,
                )
            return config

        except Exception as e:
            logger.error(
                "Failed to fetch workflow config for workflow_id=%s: %s",
                workflow_id,
                e,
            )
            return None

    async def fetch_strategy_config(
        self, workflow_id: int, strategy_name: str
    ) -> dict[str, Any]:
        """
        Extract strategy-specific configuration from the workflow config.

        Fetches the workflow configuration (cached) and returns the section
        nested under ``strategyConfig.<strategy_name>``.

        Args:
            workflow_id: ID of the workflow
            strategy_name: Strategy identifier (e.g., ``"unload"``, ``"odbc"``)

        Returns:
            Strategy-specific configuration dict (empty dict if absent)

        """
        workflow_config = await self.fetch_workflow_config(workflow_id)
        if workflow_config is None:
            return {}

        strategy_configs = workflow_config.get(STRATEGY_CONFIG_KEY, {})
        if not isinstance(strategy_configs, dict):
            return {}

        strategy_section = strategy_configs.get(strategy_name, {})
        return strategy_section if isinstance(strategy_section, dict) else {}

    async def fetch_workflow_external_stage(self, workflow_id: int) -> str | None:
        """
        Fetch the workflow's target_cloud_stage_name (external stage) from the WORKFLOW table.

        This is used as a fallback for extraction strategies that need an external stage
        (e.g., UNLOAD) when one isn't explicitly configured in strategy_config.

        Args:
            workflow_id: ID of the workflow

        Returns:
            The workflow's target_cloud_stage_name, or None if not found

        """
        query = f"""
            SELECT {workflow_columns.TARGET_CLOUD_STAGE_NAME}
            FROM {qualified_migration_schema()}.WORKFLOW
            WHERE ID = {workflow_id}
        """
        result = await self.warehouse_proxy.execute_sync_query(query)

        if result and len(result) > 0:
            return result[0].get(workflow_columns.TARGET_CLOUD_STAGE_NAME)
        return None
