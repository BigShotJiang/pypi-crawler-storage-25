"""
Smart partition configuration resolver.

Resolves a user-facing ``PartitionSizeConfig`` (auto, fixed-MB, or fixed-rows)
into a concrete ``PartitionConfig`` that the ``PartitionCalculator`` can use.

When in *auto* mode the resolver selects parameters based on the source
platform, extraction strategy, and (optionally) the table's data size so that
partition sizes are appropriate for each scenario.
"""

from __future__ import annotations

from dataclasses import dataclass

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.data_migration_cloud.config.extraction_strategy import (
    ExtractionStrategy,
)
from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    PartitionSizeConfig,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.partition_calculator import (
    PartitionConfig,
)
from shared.enums.source_type import SourceType


logger = get_logger("tasks.handlers.smart_partition_config_resolver")


@dataclass(frozen=True)
class _PlatformProfile:
    """Pre-tuned partition parameters for a platform / extraction strategy pair."""

    max_single_partition_size_mb: int
    target_partition_size_mb: int
    target_fill_percentage: float = 0.9
    min_partitions: int = 2
    max_partitions: int = 100


_FALLBACK_PROFILE = _PlatformProfile(
    max_single_partition_size_mb=5 * 1024,
    target_partition_size_mb=2 * 1024,
)

_PLATFORM_PROFILES: dict[tuple[SourceType, ExtractionStrategy], _PlatformProfile] = {
    # Redshift UNLOAD writes Parquet to S3; S3 and Snowflake external stages
    # handle large files efficiently, so we allow bigger partitions.
    (SourceType.REDSHIFT, ExtractionStrategy.UNLOAD): _PlatformProfile(
        max_single_partition_size_mb=10 * 1024,
        target_partition_size_mb=5 * 1024,
    ),
    # Redshift REGULAR (ODBC) — data flows through the worker's memory, so
    # partitions should be smaller to limit memory pressure.
    (SourceType.REDSHIFT, ExtractionStrategy.REGULAR): _PlatformProfile(
        max_single_partition_size_mb=5 * 1024,
        target_partition_size_mb=2 * 1024,
    ),
    # SQL Server REGULAR (ODBC / BCP) — similar memory constraints as Redshift
    # ODBC, but throughput per partition tends to be lower.
    (SourceType.SQLSERVER, ExtractionStrategy.REGULAR): _PlatformProfile(
        max_single_partition_size_mb=2 * 1024,
        target_partition_size_mb=1 * 1024,
    ),
    # PostgreSQL REGULAR (ODBC) — same extraction path as SQL Server.
    (SourceType.POSTGRESQL, ExtractionStrategy.REGULAR): _PlatformProfile(
        max_single_partition_size_mb=2 * 1024,
        target_partition_size_mb=1 * 1024,
    ),
}

# Tables above this threshold (in MB) get an increased max_partitions cap
# so that very large datasets benefit from additional parallelism.
_LARGE_TABLE_THRESHOLD_MB = 100 * 1024  # 100 GB
_LARGE_TABLE_MAX_PARTITIONS = 200


class SmartPartitionConfigResolver:
    """
    Resolves a ``PartitionSizeConfig`` into a ``PartitionConfig``.

    Resolution modes:
    - **auto**: Selects a pre-tuned profile based on the source platform and
      extraction strategy.  For very large tables the maximum partition count
      is raised to allow more parallelism.
    - **fixed-MB** (``target_size_mb``): Uses the user-provided target size.
    - **fixed-rows** (``max_rows_per_partition``): Uses the user-provided row cap.
    """

    @staticmethod
    def resolve(
        partition_size_config: PartitionSizeConfig,
        source_type: SourceType,
        extraction_strategy: ExtractionStrategy,
        data_size_mb: float | None = None,
    ) -> PartitionConfig:
        """
        Resolve user config into a concrete ``PartitionConfig``.

        Args:
            partition_size_config: User-facing partition size configuration.
            source_type: Source database platform.
            extraction_strategy: Extraction strategy in use.
            data_size_mb: Total table data size (used for adaptive scaling in
                auto mode).  May be ``None`` when not yet known.

        Returns:
            A ``PartitionConfig`` ready for ``PartitionCalculator``.

        """
        if partition_size_config.max_rows_per_partition is not None:
            return SmartPartitionConfigResolver._resolve_fixed_rows(
                partition_size_config.max_rows_per_partition
            )

        if partition_size_config.target_size_mb is not None:
            return SmartPartitionConfigResolver._resolve_fixed_mb(
                partition_size_config.target_size_mb
            )

        return SmartPartitionConfigResolver._resolve_auto(
            source_type, extraction_strategy, data_size_mb
        )

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _resolve_auto(
        source_type: SourceType,
        extraction_strategy: ExtractionStrategy,
        data_size_mb: float | None,
    ) -> PartitionConfig:
        profile = _PLATFORM_PROFILES.get(
            (source_type, extraction_strategy), _FALLBACK_PROFILE
        )

        max_partitions = profile.max_partitions
        if data_size_mb is not None and data_size_mb > _LARGE_TABLE_THRESHOLD_MB:
            max_partitions = _LARGE_TABLE_MAX_PARTITIONS

        config = PartitionConfig(
            max_single_partition_size_mb=profile.max_single_partition_size_mb,
            target_partition_size_mb=profile.target_partition_size_mb,
            target_fill_percentage=profile.target_fill_percentage,
            min_partitions=profile.min_partitions,
            max_partitions=max_partitions,
        )

        logger.info(
            f"Auto-resolved partition config for {source_type}/{extraction_strategy}: "
            f"target={profile.target_partition_size_mb} MB, "
            f"threshold={profile.max_single_partition_size_mb} MB, "
            f"max_partitions={max_partitions}"
        )
        return config

    @staticmethod
    def _resolve_fixed_mb(target_size_mb: int) -> PartitionConfig:
        config = PartitionConfig(
            max_single_partition_size_mb=target_size_mb,
            target_partition_size_mb=target_size_mb,
        )
        logger.info(
            f"Fixed-MB partition config: target={target_size_mb} MB per partition"
        )
        return config

    @staticmethod
    def _resolve_fixed_rows(max_rows_per_partition: int) -> PartitionConfig:
        config = PartitionConfig(
            max_rows_per_partition=max_rows_per_partition,
        )
        logger.info(
            f"Fixed-rows partition config: max {max_rows_per_partition:,} rows/partition"
        )
        return config
