"""
Workflow progress service for tracking table and partition metadata.

This module provides a centralized service for updating progress tracking
metadata during workflow execution.
"""

from typing import Any

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_core.warehouse import Warehouse
from data_migration_orchestrator.utils.snowflake_metadata import (
    qualified_migration_schema,
)


logger = get_logger("tasks.handlers.workflow_progress")


class WorkflowProgressService:
    """
    Service for tracking workflow progress via table and partition metadata.

    Provides methods for updating table preprocessing status and inserting
    partition metadata records.
    """

    def __init__(self, warehouse_proxy: Warehouse | None):
        """
        Initialize the service with a warehouse proxy.

        Args:
            warehouse_proxy: The warehouse proxy for executing database operations.

        """
        self.warehouse_proxy = warehouse_proxy

    async def update_table_preprocessed(self, table_metadata_id: int | None) -> None:
        """
        Update table metadata to mark it as preprocessed.

        Called after all partitions have been inserted.

        Args:
            table_metadata_id: ID of the table metadata record

        """
        if table_metadata_id is None or self.warehouse_proxy is None:
            return

        try:
            query = (
                f"UPDATE {qualified_migration_schema()}.TABLE_METADATA "
                f"SET HAS_BEEN_PREPROCESSED = TRUE, UPDATED_AT = CURRENT_TIMESTAMP() "
                f"WHERE ID = {table_metadata_id}"
            )
            await self.warehouse_proxy.execute_sync_query(query)
            logger.info(f"Marked table metadata {table_metadata_id} as preprocessed")
        except Exception as e:
            logger.error(f"Failed to update table metadata {table_metadata_id}: {e}")

    async def insert_partition_metadata(
        self,
        table_metadata_id: int | None,
        partition_number: int | None,
        min_value: Any,
        max_value: Any,
        rows: int | None,
    ) -> int | None:
        """
        Insert a partition metadata record and return its ID.

        Args:
            table_metadata_id: ID of the parent table metadata record
            partition_number: Number of the partition for the table
            min_value: Minimum boundary value (any type supported by VARIANT)
            max_value: Maximum boundary value (any type supported by VARIANT)
            rows: Number of rows in this partition (may be None if unknown)

        Returns:
            The ID of the inserted partition metadata record, or None if insertion failed

        """
        if table_metadata_id is None:
            logger.warning(
                "table_metadata_id is None, skipping partition metadata insert"
            )
            return None
        if self.warehouse_proxy is None:
            logger.warning(
                "warehouse_proxy is None, skipping partition metadata insert"
            )
            return None

        query: str | None = None
        try:
            min_val_sql = self._format_as_variant(min_value)
            max_val_sql = self._format_as_variant(max_value)
            rows_sql = str(rows) if rows is not None else "NULL"

            query = (
                f"CALL {qualified_migration_schema()}.INSERT_PARTITION_METADATA("
                f"{table_metadata_id}, "
                f"{partition_number}, "
                f"{min_val_sql}, "
                f"{max_val_sql}, "
                f"{rows_sql})"
            )  # TODO: Sanitize this query
            result = await self.warehouse_proxy.execute_sync_query(query)
            if not result:
                return None

            # The stored procedure returns the new ID as the first (and only) column
            first_row = result[0]
            partition_metadata_id = next(iter(first_row.values()), None)
            logger.info(f"Inserted partition metadata with ID {partition_metadata_id}")
            return partition_metadata_id
        except Exception as e:
            logger.error(
                f"Failed to insert partition metadata: {e}. Query: {query}",
                exc_info=True,
            )
            return None

    async def insert_partition_metadata_batch(
        self,
        table_metadata_id: int,
        partitions: list[tuple[int, Any, Any]],
    ) -> dict[int, int]:
        """
        Insert multiple partition metadata records in a single SQL statement.

        Args:
            table_metadata_id: ID of the parent table metadata record
            partitions: List of (partition_number, min_value, max_value) tuples

        Returns:
            Mapping of partition_number -> partition_metadata_id

        Raises:
            Exception: If the batch insert fails or returns fewer IDs than expected

        """
        if not partitions:
            return {}
        if self.warehouse_proxy is None:
            raise Exception("warehouse_proxy is required for batch insert")

        values_rows = []
        for partition_number, min_value, max_value in partitions:
            min_sql = self._format_sql_literal(min_value)
            max_sql = self._format_sql_literal(max_value)
            values_rows.append(
                f"({table_metadata_id}, {partition_number}, {min_sql}, {max_sql}, NULL, 'EXTRACTING')"
            )

        qm = qualified_migration_schema()
        insert_query = (
            f"INSERT INTO {qm}.PARTITION_METADATA "
            "(ID, TABLE_ID, PARTITION_NUMBER, MIN_VALUE, MAX_VALUE, N_ROWS, MIGRATION_STATUS) "
            f"SELECT {qm}.PARTITION_METADATA_ID_SEQ.NEXTVAL, "
            "column1, column2, TO_VARIANT(column3), TO_VARIANT(column4), column5, column6 "
            f"FROM VALUES {', '.join(values_rows)}"
        )
        await self.warehouse_proxy.execute_sync_query(insert_query)

        select_query = (
            "SELECT ID, PARTITION_NUMBER "
            f"FROM {qm}.PARTITION_METADATA "
            f"WHERE TABLE_ID = {table_metadata_id} "
            "AND MIGRATION_STATUS = 'EXTRACTING' "
            "ORDER BY PARTITION_NUMBER"
        )
        result = await self.warehouse_proxy.execute_sync_query(select_query)

        id_map: dict[int, int] = {}
        for row in result:
            raw_pid = row.get("ID") if row.get("ID") is not None else row.get("id")
            raw_pnum = (
                row.get("PARTITION_NUMBER")
                if row.get("PARTITION_NUMBER") is not None
                else row.get("partition_number")
            )
            if raw_pid is None or raw_pnum is None:
                raise ValueError(
                    f"Partition metadata row missing ID or PARTITION_NUMBER: {row!r}"
                )
            pid = int(raw_pid)
            pnum = int(raw_pnum)
            id_map[pnum] = pid

        if len(id_map) < len(partitions):
            raise Exception(
                f"Batch insert returned {len(id_map)} IDs but expected {len(partitions)}"
            )

        logger.info(
            f"Batch-inserted {len(partitions)} partition metadata records "
            f"for table_metadata_id={table_metadata_id}"
        )
        return id_map

    @staticmethod
    def _format_sql_literal(value: Any) -> str:
        """
        Format a Python value as a plain SQL literal (no VARIANT cast).

        Suitable for use inside VALUES clauses where ::VARIANT casts are not allowed.
        """
        if value is None:
            return "NULL"
        if isinstance(value, bool):
            return "TRUE" if value else "FALSE"
        if isinstance(value, (int | float)):
            return str(value)
        if isinstance(value, str):
            try:
                int(value)
                return value
            except ValueError:
                pass
            try:
                float(value)
                return value
            except ValueError:
                pass
            escaped = value.replace("'", "''")
            return f"'{escaped}'"
        escaped = str(value).replace("'", "''")
        return f"'{escaped}'"

    def _format_as_variant(self, value: Any) -> str:
        """
        Format a Python value as a VARIANT for Snowflake stored procedure call.

        VARIANT supports native types: INT, FLOAT, BOOLEAN, TEXT, etc.

        Args:
            value: Any Python value

        Returns:
            SQL expression with ::VARIANT cast, or NULL

        """
        if value is None:
            return "NULL"
        if isinstance(value, bool):
            return "TRUE::VARIANT" if value else "FALSE::VARIANT"
        if isinstance(value, (int | float)):
            return f"{value}::VARIANT"
        if isinstance(value, str):
            # Check if it's a numeric string
            try:
                # Try int first
                int(value)
                return f"{value}::VARIANT"
            except ValueError:
                pass
            try:
                # Try float
                float(value)
                return f"{value}::VARIANT"
            except ValueError:
                pass
            # It's a real string, quote it
            escaped = value.replace("'", "''")
            return f"'{escaped}'::VARIANT"
        # Fallback: convert to quoted string
        escaped = str(value).replace("'", "''")
        return f"'{escaped}'::VARIANT"
