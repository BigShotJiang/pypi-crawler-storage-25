"""Partition calculation for determining optimal partitioning strategy."""

import math

from dataclasses import dataclass


@dataclass
class PartitionConfig:
    """
    Partition configuration thresholds.

    Two calculation modes:
    - **Size-based** (default): Uses ``target_partition_size_mb`` and table
      data size to derive partition count.
    - **Row-based**: When ``max_rows_per_partition`` is set, partition count is
      derived from row count alone, ignoring data size.

    """

    max_single_partition_size_mb: int = 10 * 1024  # 10 GB threshold
    target_partition_size_mb: int = 10 * 512  # 5 GB target per partition
    target_fill_percentage: float = 0.9  # Safety margin
    min_partitions: int = 2
    max_partitions: int = 100
    max_rows_per_partition: int | None = None


@dataclass
class PartitionDecision:
    """Partition analysis result."""

    should_partition: bool
    num_partitions: int
    rows_per_partition: int
    reasoning: str
    partition_column: str | None = None


class PartitionCalculator:
    """
    Calculates partitioning strategy based on table size.

    Binary decision based on max_single_partition_size_mb (size-based mode)
    or max_rows_per_partition (row-based mode):
    - Small tables: No partitioning
    - Large tables: Partition using percentiles
    """

    def __init__(self, config: PartitionConfig | None = None):
        """Initialize calculator with optional custom config."""
        self.config = config or PartitionConfig()

    def calculate_partition_strategy(
        self, row_count: int, data_size_mb: float
    ) -> PartitionDecision:
        """Decide: partition or not? If yes, how many partitions?."""
        if row_count == 0:
            return PartitionDecision(
                should_partition=False,
                num_partitions=1,
                rows_per_partition=0,
                reasoning="Empty table - single extraction",
            )

        if self.config.max_rows_per_partition is not None:
            return self._calculate_row_based_strategy(row_count, data_size_mb)

        return self._calculate_size_based_strategy(row_count, data_size_mb)

    def _calculate_size_based_strategy(
        self, row_count: int, data_size_mb: float
    ) -> PartitionDecision:
        """Size-based partitioning: use data_size_mb to decide."""
        if data_size_mb <= self.config.max_single_partition_size_mb:
            return PartitionDecision(
                should_partition=False,
                num_partitions=1,
                rows_per_partition=row_count,
                reasoning=f"{data_size_mb:.2f} MB ({row_count:,} rows) - single extraction",
            )

        num_partitions = self._calculate_num_partitions_by_size(row_count, data_size_mb)
        rows_per_partition = row_count // num_partitions

        return PartitionDecision(
            should_partition=True,
            num_partitions=num_partitions,
            rows_per_partition=rows_per_partition,
            reasoning=(
                f"{data_size_mb:.2f} MB ({row_count:,} rows) - "
                f"{num_partitions} partitions (~{rows_per_partition:,} rows each)"
            ),
        )

    def _calculate_row_based_strategy(
        self, row_count: int, data_size_mb: float
    ) -> PartitionDecision:
        """Row-based partitioning: use max_rows_per_partition to decide."""
        max_rows = self.config.max_rows_per_partition
        if max_rows is None:
            raise RuntimeError(
                "_calculate_row_based_strategy called without max_rows_per_partition"
            )

        if row_count <= max_rows:
            return PartitionDecision(
                should_partition=False,
                num_partitions=1,
                rows_per_partition=row_count,
                reasoning=(
                    f"{row_count:,} rows (max {max_rows:,}/partition) - single extraction"
                ),
            )

        num_partitions = math.ceil(row_count / max_rows)
        num_partitions = max(
            self.config.min_partitions,
            min(num_partitions, self.config.max_partitions),
        )
        rows_per_partition = row_count // num_partitions

        return PartitionDecision(
            should_partition=True,
            num_partitions=num_partitions,
            rows_per_partition=rows_per_partition,
            reasoning=(
                f"{data_size_mb:.2f} MB ({row_count:,} rows) - "
                f"{num_partitions} partitions (~{rows_per_partition:,} rows each, "
                f"max {max_rows:,}/partition)"
            ),
        )

    def _calculate_num_partitions_by_size(
        self, row_count: int, data_size_mb: float
    ) -> int:
        """Calculate number of partitions needed based on data size."""
        avg_row_size_mb = data_size_mb / row_count if row_count > 0 else 0
        target_size = (
            self.config.target_partition_size_mb * self.config.target_fill_percentage
        )

        if avg_row_size_mb > 0:
            rows_per_partition = int(target_size / avg_row_size_mb)
            num_partitions = (row_count + rows_per_partition - 1) // rows_per_partition
        else:
            num_partitions = self.config.min_partitions

        return max(
            self.config.min_partitions, min(num_partitions, self.config.max_partitions)
        )
