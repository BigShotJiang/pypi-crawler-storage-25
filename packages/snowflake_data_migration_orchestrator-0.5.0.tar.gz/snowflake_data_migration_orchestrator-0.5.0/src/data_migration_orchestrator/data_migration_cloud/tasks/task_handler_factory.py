"""
Task Handler Factory for executing orchestrator tasks.

This factory creates handlers for orchestrator tasks only.
"""

from typing import Generic, Protocol, TypeVar

from data_migration_orchestrator.cloud_core.exceptions.unsupported_payload_kind_error import (
    UnsupportedPayloadKindError,
)
from data_migration_orchestrator.cloud_core.tasks.queues.base_task_queue import (
    BaseTaskQueue,
)
from data_migration_orchestrator.cloud_core.tasks.task import Task
from data_migration_orchestrator.cloud_core.warehouse import Warehouse
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.clear_partition_data_handler import (
    ClearPartitionDataHandler,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.compare_partition_checksum_handler import (
    ComparePartitionChecksumHandler,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.complete_partition_migration_handler import (
    CompletePartitionMigrationHandler,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.create_partition_tasks_handler import (
    CreatePartitionTasksHandler,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.deduplicate_partition_data_handler import (
    DeduplicatePartitionDataHandler,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.partition_strategy_handler import (
    PartitionStrategyHandler,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.process_checksum_result_handler import (
    ProcessChecksumResultHandler,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.staged_data_handler import (
    StagedDataHandler,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload_kind import (
    TaskPayloadKind,
)


TPayload = TypeVar("TPayload")


class TaskHandler(Protocol, Generic[TPayload]):
    """Protocol for task handlers."""

    async def handle(self, task: Task[TPayload]) -> None:
        """Handle a task."""
        ...


class TaskHandlerFactory(Generic[TPayload]):
    """
    Factory for creating task handlers.

    This factory creates handlers for ORCHESTRATOR tasks only.
    It provides a clean separation between task creation (TaskBuilder)
    and task execution (TaskHandlerFactory).

    Usage:
        factory = TaskHandlerFactory(task_queue, warehouse_proxy)
        handler = factory.get_handler(TaskPayloadKind.PROCESS_STAGED_DATA)
        await handler.handle(workflow_id, task)
    """

    def __init__(
        self,
        task_queue: BaseTaskQueue[TPayload],
        warehouse_proxy: Warehouse,
    ):
        """
        Initialize the task handler factory.

        Args:
            task_queue: Task queue for task operations
            warehouse_proxy: Warehouse proxy for Snowflake operations

        """
        self.task_queue = task_queue
        self.warehouse_proxy = warehouse_proxy

        self._handlers = {
            TaskPayloadKind.PROCESS_STAGED_DATA: StagedDataHandler(
                self.task_queue,
                self.warehouse_proxy,
            ),
            TaskPayloadKind.DETERMINE_PARTITION_STRATEGY: PartitionStrategyHandler(
                self.task_queue,
                self.warehouse_proxy,
            ),
            TaskPayloadKind.CREATE_PARTITION_TASKS: CreatePartitionTasksHandler(
                self.task_queue,
                self.warehouse_proxy,
            ),
            TaskPayloadKind.COMPLETE_PARTITION_MIGRATION: CompletePartitionMigrationHandler(
                self.task_queue,
                self.warehouse_proxy,
            ),
            TaskPayloadKind.COMPARE_PARTITION_CHECKSUM: ComparePartitionChecksumHandler(
                self.task_queue,
                self.warehouse_proxy,
            ),
            TaskPayloadKind.PROCESS_CHECKSUM_RESULT: ProcessChecksumResultHandler(
                self.task_queue,
                self.warehouse_proxy,
            ),
            TaskPayloadKind.CLEAR_PARTITION_DATA: ClearPartitionDataHandler(
                self.task_queue,
                self.warehouse_proxy,
            ),
            TaskPayloadKind.DEDUPLICATE_PARTITION_DATA: DeduplicatePartitionDataHandler(
                self.task_queue,
                self.warehouse_proxy,
            ),
        }

    def get_handler(self, payload_kind: TaskPayloadKind) -> TaskHandler[TPayload]:
        """
        Get a handler for the given payload kind.

        Args:
            payload_kind: The task payload kind

        Returns:
            The appropriate handler

        Raises:
            UnsupportedPayloadKindError: If no handler exists for the payload kind

        """
        handler = self._handlers.get(payload_kind)

        if handler is None:
            raise UnsupportedPayloadKindError(payload_kind, list(self._handlers.keys()))

        return handler

    def has_handler(self, payload_kind: TaskPayloadKind) -> bool:
        """
        Check if a handler exists for the payload kind.

        Args:
            payload_kind: The task payload kind

        Returns:
            True if handler exists, False otherwise

        """
        return payload_kind in self._handlers

    def get_supported_task_types(self) -> list[TaskPayloadKind]:
        """
        Get list of supported task types.

        Returns:
            List of payload kinds that have handlers

        """
        return list(self._handlers.keys())


# TODO(SNOW-3105393): Use Registry pattern instead? And also for WorkflowInitializer?
