# Workflow configuration properties
SOURCE = "source"
TARGET = "target"
TABLES = "tables"
DEFAULT_TABLE_CONFIGURATION = "defaultTableConfiguration"
SCHEMA_VERSION = "schemaVersion"
TABLE_NAME = "tableName"
SCHEMA_NAME = "schemaName"
DATABASE_NAME = "databaseName"
COLUMN_NAMES_TO_PARTITION_BY = "columnNamesToPartitionBy"

# Column type mappings
COLUMN_TYPE_MAPPINGS = "columnTypeMappings"
SOURCE_TYPE = "sourceType"
TARGET_TYPE = "targetType"

# Column name mappings
COLUMN_NAME_MAPPINGS = "columnNameMappings"
SOURCE_NAME = "sourceName"
TARGET_NAME = "targetName"

# Synchronization configuration
SYNCHRONIZATION = "synchronization"
WATERMARK_COLUMN = "watermarkColumn"
TRACK_MODIFICATIONS = "trackModifications"

# Extraction configuration (extraction strategy)
# Uses tagged union pattern with "strategy" as discriminator
EXTRACTION = "extraction"
STRATEGY = "strategy"
EXTERNAL_STAGE = "externalStage"

# Table metadata
PRIMARY_KEY_COLUMNS = "primaryKeyColumns"

# Where clause criteria
WHERE_CLAUSE_CRITERIA = "whereClauseCriteria"

# Partition size configuration
PARTITION_SIZE = "partitionSize"
TARGET_SIZE_MB = "targetSizeMb"
MAX_ROWS_PER_PARTITION = "maxRowsPerPartition"

# Target table type and Iceberg configuration
TABLE_TYPE = "tableType"
ICEBERG_CONFIG = "icebergConfig"
CATALOG = "catalog"
EXTERNAL_VOLUME = "externalVolume"
BASE_LOCATION_PREFIX = "baseLocationPrefix"
CATALOG_TABLE_NAME = "catalogTableName"
CATALOG_SYNC = "catalogSync"
SOURCE_DATA_STAGE = "sourceDataStage"
MIGRATION_STRATEGY = "migrationStrategy"
