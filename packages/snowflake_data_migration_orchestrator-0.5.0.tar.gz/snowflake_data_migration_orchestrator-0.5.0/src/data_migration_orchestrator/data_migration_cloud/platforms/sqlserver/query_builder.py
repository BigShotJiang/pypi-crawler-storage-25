"""
SQL Server-specific SQL query builder.

This module provides the SqlServerQueryBuilder class that generates
SQL queries using Microsoft SQL Server syntax for metadata extraction,
schema queries, partition calculations, and checksum computation.
"""

from __future__ import annotations

import re

from datetime import datetime
from typing import Any

from data_migration_orchestrator.data_migration_cloud.config.table_configuration import (
    TableIdentifier,
)
from data_migration_orchestrator.data_migration_cloud.platforms.base_query_builder import (
    BaseQueryBuilder,
)
from data_migration_orchestrator.data_migration_cloud.platforms.sqlserver.checksum import (
    build_sqlserver_checksum_query,
)
from data_migration_orchestrator.data_migration_cloud.platforms.sqlserver.identifiers import (
    normalize_identifier_sqlserver,
    quote_identifier_for_ref_sqlserver,
)
from data_migration_orchestrator.data_migration_cloud.tasks.handlers.checksum_models import (
    ColumnInfo,
    PartitionInfo,
)
from data_migration_orchestrator.data_migration_core.queries.constants import (
    COLUMN_NAME,
    DATA_TYPE,
)
from data_migration_orchestrator.utils.datetime_utils import is_datetime_string
from shared.enums.source_type import SourceType


# Server-side conversions for types the ODBC driver cannot decode cleanly.
# Mirrors DMVA's system_sqlserver.charamelize conversions.
_SQLSERVER_EXTRACTION_CONVERSIONS: dict[str, str] = {
    "geography": "{col}.STAsText()",
    "geometry": "{col}.STAsText()",
    "hierarchyid": "{col}.ToString()",
    "sql_variant": "CAST({col} AS NVARCHAR(MAX))",
    "xml": "CAST(CONVERT(XML, {col}) AS NVARCHAR(MAX))",
}


# Pattern to detect timezone offset at end of string (e.g., +00:00, -05:30)
TIMEZONE_OFFSET_PATTERN = re.compile(r"[+-]\d{2}:\d{2}$")

# Pattern to truncate fractional seconds to 3 digits (milliseconds)
# Matches: .NNNNNN (any number of digits after decimal, captures first 3)
FRACTIONAL_SECONDS_PATTERN = re.compile(r"\.(\d{3})\d*")


class SqlServerQueryBuilder(BaseQueryBuilder):
    """
    Query builder for Microsoft SQL Server SQL syntax.

    Generates SQL queries compatible with SQL Server, using T-SQL syntax
    and system views for metadata extraction. Checksum query generation
    is delegated to :mod:`~...platforms.sqlserver.checksum`.
    """

    @property
    def platform_name(self) -> SourceType:
        """Return the platform name."""
        return SourceType.SQLSERVER

    @property
    def identifier_quote_char(self) -> tuple[str, str]:
        """Return square brackets for SQL Server identifier quoting."""
        return ("[", "]")

    @property
    def string_literal_prefix(self) -> str:
        """Return N prefix for SQL Server Unicode strings."""
        return "N"

    def normalize_identifier(self, identifier: str) -> str:
        """Normalize an identifier for SQL Server (uppercase unquoted, preserve quoted)."""
        return normalize_identifier_sqlserver(identifier)

    def quote_column_name(self, column_name: str) -> str:
        """Quote a column name only when needed for SQL Server."""
        return quote_identifier_for_ref_sqlserver(column_name)

    def build_use_database_command(self, database: str) -> str | None:
        """
        Return ``None`` because Azure SQL does not support ``USE`` statements.

        Azure SQL Database connections are scoped to a single database at
        connect time, so runtime database switching is not possible.  The
        database context is set via the connection string instead.

        Args:
            database: The target database name (unused).

        Returns:
            Always ``None``.

        """
        return None

    def quote_identifier(self, identifier: str) -> str:
        """
        Quote an identifier using square brackets.

        Args:
            identifier: Identifier to quote

        Returns:
            Quoted identifier

        """
        open_q, close_q = self.identifier_quote_char
        # Escape any existing close brackets by doubling them
        escaped = identifier.replace("]", "]]")
        return f"{open_q}{escaped}{close_q}"

    def build_metadata_query(self, table_name: TableIdentifier) -> str:
        """
        Generate SQL query to get table metadata from SQL Server.

        Uses sys.dm_db_partition_stats for row count and sys.allocation_units
        for size information.

        Args:
            table_name: Fully qualified table name (database.schema.table)

        Returns:
            SQL query string

        """
        # Build the query with optional database context
        db_prefix = f"[{table_name.database_name}]."

        return f"""
SELECT
    SUM(p.rows) AS row_count,
    ROUND(SUM(a.total_pages) * 8.0 / 1024, 2) AS data_size_mb
FROM {db_prefix}sys.tables t
INNER JOIN {db_prefix}sys.schemas s ON t.schema_id = s.schema_id
INNER JOIN {db_prefix}sys.indexes i ON t.object_id = i.object_id
INNER JOIN {db_prefix}sys.partitions p ON i.object_id = p.object_id AND i.index_id = p.index_id
INNER JOIN {db_prefix}sys.allocation_units a ON p.partition_id = a.container_id
WHERE s.name = '{table_name.schema_name}'
  AND t.name = '{table_name.table_name}'
  AND i.index_id IN (0, 1)
GROUP BY s.name, t.name
""".strip()

    def build_schema_query(self, table_name: TableIdentifier) -> str:
        """
        Generate SQL query to get table schema from SQL Server.

        Uses INFORMATION_SCHEMA.COLUMNS to get column definitions.

        Args:
            table_name: Fully qualified table name (database.schema.table)

        Returns:
            SQL query string

        """
        # Build optional database filter
        db_filter = f"AND TABLE_CATALOG = '{table_name.database_name}'"

        return f"""
SELECT
    COLUMN_NAME AS column_name,
    DATA_TYPE AS data_type,
    CHARACTER_MAXIMUM_LENGTH AS character_maximum_length,
    NUMERIC_PRECISION AS numeric_precision,
    NUMERIC_SCALE AS numeric_scale,
    IS_NULLABLE AS is_nullable,
    COLUMN_DEFAULT AS column_default,
    ORDINAL_POSITION AS ordinal_position
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = '{table_name.schema_name}'
  AND TABLE_NAME = '{table_name.table_name}'
  {db_filter}
ORDER BY ORDINAL_POSITION
""".strip()

    def build_select_query(
        self,
        table_name: TableIdentifier,
        column_types: list[dict[str, str]],
        where_clause: str | None = None,
    ) -> str:
        """Build a type-aware SELECT with server-side conversions where needed."""
        fqn = self.build_table_fqn(table_name)
        # Build column expressions with conversions where needed
        col_expressions: list[str] = []
        for col in column_types:
            col_name = col[COLUMN_NAME]
            data_type = col.get(DATA_TYPE, "").lower()
            quoted_col = self.quote_identifier(col_name)

            conversion_template = _SQLSERVER_EXTRACTION_CONVERSIONS.get(data_type)
            if conversion_template:
                expr = conversion_template.format(col=quoted_col)
                col_expressions.append(f"{expr} AS {quoted_col}")
            else:
                col_expressions.append(quoted_col)

        col_str = ", ".join(col_expressions)
        query = f"SELECT {col_str} FROM {fqn}"

        if where_clause:
            query += f" WHERE {where_clause}"

        return query

    def format_sql_value(self, value: Any) -> str:
        """
        Format a value for SQL Server WHERE clauses.

        Uses CONVERT expressions for datetime values to ensure proper parsing
        with SQL Server's DateTime, DateTime2, and DateTimeOffset types.

        Args:
            value: The value to format

        Returns:
            A SQL Server-compatible string representation of the value

        """
        if value is None:
            return "NULL"

        if isinstance(value, (int | float)):
            return str(value)

        # Handle Python datetime objects with CONVERT
        if isinstance(value, datetime):
            return self._format_datetime_for_sqlserver(value)

        if isinstance(value, str):
            # Remove surrounding double quotes if present (from Snowflake VARIANT)
            trimmed = value
            if value.startswith('"') and value.endswith('"'):
                trimmed = value[1:-1]

            # Check if string looks like a datetime value - use CONVERT
            if is_datetime_string(trimmed):
                return self._format_datetime_string_for_sqlserver(trimmed)

            # Regular string: escape single quotes and wrap in quotes
            return self.quote_string_literal(trimmed)

        # Fallback: convert to string and quote
        return self.quote_string_literal(str(value))

    def _format_datetime_for_sqlserver(self, dt: datetime) -> str:
        """
        Format a Python datetime object for SQL Server.

        Uses CONVERT with style 126 (ISO8601) for maximum compatibility
        with DateTime, DateTime2, and DateTimeOffset types.

        Args:
            dt: The datetime object to format

        Returns:
            SQL Server CONVERT expression string

        """
        if dt.tzinfo is not None:
            # DateTimeOffset: include timezone
            iso_str = dt.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3]  # Trim to milliseconds
            offset = dt.strftime("%z")
            # Format offset as +HH:MM or -HH:MM
            if offset:
                formatted_offset = f"{offset[:3]}:{offset[3:]}"
                iso_str = f"{iso_str}{formatted_offset}"
            return f"CONVERT(datetimeoffset, '{iso_str}', 127)"
        else:
            # DateTime/DateTime2: no timezone
            iso_str = dt.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3]  # Trim to milliseconds
            return f"CONVERT(datetime2, '{iso_str}', 126)"

    def _format_datetime_string_for_sqlserver(self, value: str) -> str:
        """
        Format a datetime string for SQL Server.

        Converts common datetime string formats to SQL Server compatible format
        using CONVERT function.

        Args:
            value: The datetime string to format

        Returns:
            SQL Server CONVERT expression string

        """
        # Check for timezone offset (DateTimeOffset)
        has_timezone = bool(TIMEZONE_OFFSET_PATTERN.search(value))

        # Normalize the datetime string:
        # - Replace space separator with 'T' for ISO format
        # - Truncate microseconds to milliseconds (6 digits -> 3 digits)
        normalized = value.replace(" ", "T")

        # Truncate fractional seconds to 3 digits (milliseconds) for SQL Server compatibility
        normalized = FRACTIONAL_SECONDS_PATTERN.sub(r".\1", normalized)

        if has_timezone:
            return f"CONVERT(datetimeoffset, '{normalized}', 127)"
        else:
            return f"CONVERT(datetime2, '{normalized}', 126)"

    def build_checksum_query(
        self,
        partition_info: PartitionInfo,
        source_table_id: TableIdentifier,
        columns: list[ColumnInfo],
    ) -> str:
        """
        Build SQL Server checksum query.

        Delegates to :func:`~...platforms.sqlserver.checksum.build_sqlserver_checksum_query`.

        """
        where_clause = self.build_partition_condition(
            partition_info.partition_column,
            partition_info.min_value,
            partition_info.max_value,
        )
        return build_sqlserver_checksum_query(
            partition_info=partition_info,
            source_table_id=source_table_id,
            columns=columns,
            quote_identifier_fn=self.quote_identifier,
            where_clause=where_clause,
        )
