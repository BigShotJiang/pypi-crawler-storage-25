"""
Snowflake query builder for target database operations.

This module provides a standalone query builder for Snowflake target operations
such as DELETE statements for clearing partition data. It is intentionally
separate from BaseQueryBuilder, which is designed for source platforms.

The module-level :func:`build_snowflake_partition_condition` is the single
source of truth for building partition boundary WHERE conditions against
Snowflake.  Both :class:`SnowflakeQueryBuilder` and other target-side
handlers (e.g. deduplication) should delegate to it.
"""

from dataclasses import dataclass
from datetime import datetime
from typing import Any

from data_migration_orchestrator.data_migration_cloud.platforms.snowflake.identifiers import (
    quote_identifier,
)


# ---------------------------------------------------------------------------
# Module-level helpers (used by both the utility function and the class)
# ---------------------------------------------------------------------------


def _format_snowflake_value(value: Any) -> str:
    """
    Format a value for use in Snowflake SQL WHERE clauses.

    Handles common Python types and converts them to Snowflake-compatible
    SQL literal representations.

    Args:
        value: The value to format (None, int, float, str, datetime, etc.)

    Returns:
        A SQL-safe string representation of the value

    """
    if value is None:
        return "NULL"

    if isinstance(value, (int | float)):
        return str(value)

    if isinstance(value, datetime):
        iso_str = value.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
        return _quote_snowflake_string_literal(iso_str)

    if isinstance(value, str):
        trimmed = value
        if value.startswith('"') and value.endswith('"'):
            trimmed = value[1:-1]
        return _quote_snowflake_string_literal(trimmed)

    return _quote_snowflake_string_literal(str(value))


def _quote_snowflake_string_literal(value: str) -> str:
    """Quote a string literal for Snowflake SQL."""
    escaped = value.replace("'", "''")
    return f"'{escaped}'"


# ---------------------------------------------------------------------------
# Public utility function
# ---------------------------------------------------------------------------


def build_snowflake_partition_condition(
    column: str | None,
    min_value: Any | None,
    max_value: Any | None,
) -> str:
    """
    Build SQL condition for partition boundaries on Snowflake (without WHERE keyword).

    This is the single source of truth for Snowflake target partition
    boundary conditions, mirroring ``BaseQueryBuilder.build_partition_condition``
    for source platforms.

    Convention:
    - Both bounds present (normal partition): inclusive on both sides
      ``col >= min AND col <= max`` (identifiers unquoted when valid so
      Snowflake case-folds to uppercase, matching typical target tables)
    - Only min, max is None (upper edge partition): exclusive lower bound
      ``col > min``
    - Only max, min is None (lower edge partition): exclusive upper bound
      ``col < max``
    - Both None (full table / single partition): ``1=1``

    Args:
        column: Column name used for partitioning (unquoted), or None
        min_value: Minimum value of the partition range, or None
        max_value: Maximum value of the partition range, or None

    Returns:
        SQL condition string without the WHERE keyword

    """
    if (min_value is None and max_value is None) or column is None:
        return "1=1"

    conditions: list[str] = []
    col_sql = quote_identifier(column, force_quote=False)

    if min_value is not None:
        op = ">" if max_value is None else ">="
        conditions.append(f"{col_sql} {op} {_format_snowflake_value(min_value)}")

    if max_value is not None:
        op = "<" if min_value is None else "<="
        conditions.append(f"{col_sql} {op} {_format_snowflake_value(max_value)}")

    return " AND ".join(conditions) if conditions else "1=1"


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class PartitionRange:
    """
    Partition range for WHERE clause generation.

    This dataclass represents the essential information needed to build
    partition boundary conditions in SQL queries.

    Attributes:
        column: The column name used for partitioning
        min_value: Minimum value of the partition range, already parsed
        max_value: Maximum value of the partition range, already parsed

    """

    column: str | None
    min_value: Any
    max_value: Any


# ---------------------------------------------------------------------------
# Query builder class
# ---------------------------------------------------------------------------


class SnowflakeQueryBuilder:
    """
    Query builder for Snowflake target operations.

    This class provides methods for building SQL statements that run on
    Snowflake as the target database, such as DELETE statements for
    clearing partition data during incremental sync operations.

    Unlike BaseQueryBuilder (for source platforms), this is a standalone
    class focused specifically on target database operations.
    """

    def build_delete_statement(
        self, table_name: str, partition_range: PartitionRange
    ) -> str:
        """
        Build DELETE statement with partition boundary conditions.

        Generates a DELETE SQL statement that removes rows within the specified
        partition range from the target Snowflake table.

        Args:
            table_name: Fully qualified table name (e.g., 'db.schema.table')
            partition_range: The partition range defining which rows to delete

        Returns:
            DELETE SQL statement

        Example:
            >>> builder = SnowflakeQueryBuilder()
            >>> builder.build_delete_statement(
            ...     "mydb.myschema.mytable",
            ...     PartitionRange(column="id", min_value=1, max_value=100)
            ... )
            'DELETE FROM mydb.myschema.mytable WHERE id >= 1 AND id <= 100'

        """
        where_clause = build_snowflake_partition_condition(
            partition_range.column,
            partition_range.min_value,
            partition_range.max_value,
        )
        return f"DELETE FROM {table_name} WHERE {where_clause}"
