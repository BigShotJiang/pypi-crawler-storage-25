"""
Data Migration Dashboard.

Monitor the progress of cloud data migration workflows.
Designed for Streamlit in Snowflake (SiS).
"""

import pandas as pd
import streamlit as st

from snowflake.snowpark.context import get_active_session


try:
    from sis_streamlit_metadata import migration_schema_for_streamlit_dashboard
except ModuleNotFoundError:
    from data_migration_orchestrator.utils.sis_streamlit_metadata import (
        migration_schema_for_streamlit_dashboard,
    )


st.set_page_config(
    page_title="Data Migration Dashboard",
    page_icon="🔄",
    layout="wide",
)

# Get active Snowflake session (SiS provides this automatically)
session = get_active_session()


def run_query(sql: str) -> pd.DataFrame:
    """Execute a query and return results as a pandas DataFrame."""
    return session.sql(sql).to_pandas()


@st.cache_data(ttl=60)
def get_workflows():
    """Fetch workflows with progress: id → name (from WORKFLOW table)."""
    try:
        qm = migration_schema_for_streamlit_dashboard()
        df = run_query(
            f"""
            SELECT DISTINCT tp.WORKFLOW_ID, w.NAME
            FROM {qm}.TABLE_PROGRESS tp
            INNER JOIN {qm}.WORKFLOW w ON tp.WORKFLOW_ID = w.ID
            ORDER BY tp.WORKFLOW_ID DESC
        """
        )
        if len(df) > 0:
            return dict(
                zip(df["WORKFLOW_ID"].tolist(), df["NAME"].tolist(), strict=False)
            )
        return {}
    except Exception:
        return {}


@st.cache_data(ttl=30)
def get_overview_metrics(workflow_id: int | None = None):
    """Fetch high-level migration metrics, optionally filtered by workflow."""
    try:
        where_clause = f"WHERE WORKFLOW_ID = {workflow_id}" if workflow_id else ""
        qm = migration_schema_for_streamlit_dashboard()
        df = run_query(
            f"""
            SELECT
                COUNT(DISTINCT WORKFLOW_ID) as total_workflows,
                COUNT(DISTINCT TABLE_ID) as total_tables,
                COALESCE(SUM(TOTAL_PARTITIONS), 0) as total_partitions,
                COALESCE(SUM(LOADED_PARTITIONS), 0) as loaded_partitions,
                COALESCE(SUM(FAILED_PARTITIONS), 0) as failed_partitions,
                COALESCE(SUM(PARTITIONS_IN_EXTRACTION_PHASE), 0) as extracting,
                COALESCE(SUM(PARTITIONS_IN_LOADING_PHASE), 0) as loading
            FROM {qm}.TABLE_PROGRESS
            {where_clause}
        """
        )
        return df.iloc[0] if len(df) > 0 else None
    except Exception:
        return None


@st.cache_data(ttl=30)
def get_workflow_summary():
    """Fetch summary statistics per workflow (TABLE_PROGRESS + WORKFLOW name / last messages)."""
    try:
        qm = migration_schema_for_streamlit_dashboard()
        df = run_query(
            f"""
            SELECT
                WORKFLOW_ID,
                COUNT(DISTINCT TABLE_ID) as TABLES,
                COALESCE(SUM(TOTAL_PARTITIONS), 0) as TOTAL_PARTITIONS,
                COALESCE(SUM(LOADED_PARTITIONS), 0) as LOADED,
                COALESCE(SUM(FAILED_PARTITIONS), 0) as FAILED,
                COALESCE(SUM(PARTITIONS_IN_EXTRACTION_PHASE), 0)
                + COALESCE(SUM(PARTITIONS_IN_LOADING_PHASE), 0) as IN_PROGRESS,
                CASE
                    WHEN COALESCE(SUM(TOTAL_PARTITIONS), 0) > 0
                    THEN ROUND(COALESCE(SUM(LOADED_PARTITIONS), 0) * 100.0 / SUM(TOTAL_PARTITIONS), 1)
                    ELSE 0
                END as PROGRESS_PCT
            FROM {qm}.TABLE_PROGRESS
            GROUP BY WORKFLOW_ID
            ORDER BY WORKFLOW_ID DESC
        """
        )
        if len(df) == 0:
            return df
        df = df.rename(columns={c: str(c).upper() for c in df.columns})
        try:
            ids = [int(x) for x in df["WORKFLOW_ID"].tolist()]
            ids_sql = ", ".join(str(i) for i in ids)
            meta = run_query(
                f"""
                SELECT
                    ID AS WORKFLOW_ID,
                    NAME AS NAME,
                    LAST_ERROR_MESSAGE AS LAST_ERROR,
                    LAST_WARNING_MESSAGE AS LAST_WARNING
                FROM {qm}.WORKFLOW
                WHERE ID IN ({ids_sql})
                """
            )
            if len(meta) > 0:
                meta = meta.rename(columns={c: str(c).upper() for c in meta.columns})
                df = df.merge(meta, on="WORKFLOW_ID", how="left")
            else:
                df["NAME"] = pd.NA
                df["LAST_ERROR"] = pd.NA
                df["LAST_WARNING"] = pd.NA
        except Exception:
            df["NAME"] = pd.NA
            df["LAST_ERROR"] = pd.NA
            df["LAST_WARNING"] = pd.NA

        col_order = [
            "WORKFLOW_ID",
            "NAME",
            "TABLES",
            "TOTAL_PARTITIONS",
            "LOADED",
            "FAILED",
            "IN_PROGRESS",
            "PROGRESS_PCT",
            "LAST_ERROR",
            "LAST_WARNING",
        ]
        ordered = [c for c in col_order if c in df.columns]
        return df[ordered]
    except Exception:
        return pd.DataFrame()


@st.cache_data(ttl=30)
def get_table_progress(workflow_id: int = None):
    """Fetch table-level progress data, optionally filtered by workflow."""
    try:
        where_clause = f"WHERE WORKFLOW_ID = {workflow_id}" if workflow_id else ""
        qm = migration_schema_for_streamlit_dashboard()
        return run_query(
            f"""
            SELECT
                WORKFLOW_ID,
                TABLE_ID,
                TABLE_NAME,
                HAS_BEEN_PREPROCESSED,
                COALESCE(TOTAL_PARTITIONS, 0) as TOTAL_PARTITIONS,
                COALESCE(PARTITIONS_IN_EXTRACTION_PHASE, 0) as PARTITIONS_IN_EXTRACTION_PHASE,
                COALESCE(PARTITIONS_IN_LOADING_PHASE, 0) as PARTITIONS_IN_LOADING_PHASE,
                COALESCE(LOADED_PARTITIONS, 0) as LOADED_PARTITIONS,
                COALESCE(FAILED_PARTITIONS, 0) as FAILED_PARTITIONS,
                EXAMPLE_ERROR_MESSAGE
            FROM {qm}.TABLE_PROGRESS_WITH_EXAMPLE_ERROR
            {where_clause}
            ORDER BY
                CASE WHEN COALESCE(FAILED_PARTITIONS, 0) > 0 THEN 0 ELSE 1 END,
                TABLE_NAME
        """
        )
    except Exception:
        return pd.DataFrame()


@st.cache_data(ttl=30)
def get_error_logs(workflow_id: int | None = None, table_name: str | None = None):
    """Fetch error logs, optionally filtered by workflow and/or table."""
    try:
        conditions = []
        if workflow_id:
            conditions.append(f"WORKFLOW_ID = {workflow_id}")
        if table_name and table_name != "All tables":
            safe_table_name = table_name.replace("'", "''")
            conditions.append(f"TABLE_NAME = '{safe_table_name}'")

        where_clause = "WHERE " + " AND ".join(conditions) if conditions else ""
        qm = migration_schema_for_streamlit_dashboard()
        return run_query(
            f"""
            SELECT
                WORKFLOW_ID,
                TABLE_NAME,
                PARTITION_NUMBER,
                COALESCE(PARTITION_ROWS, 0) as PARTITION_ROWS,
                TASK_NAME,
                TASK_START_TIME,
                TASK_END_TIME,
                LAST_ERROR_MESSAGE
            FROM {qm}.DATA_MIGRATION_ERROR
            {where_clause}
            ORDER BY TASK_START_TIME DESC
        """
        )
    except Exception:
        return pd.DataFrame()


@st.cache_data(ttl=30)
def get_task_queue_executor_types(workflow_id: int | None) -> list[str]:
    """Distinct EXECUTOR_TYPE values, optionally scoped to one workflow."""
    try:
        qm = migration_schema_for_streamlit_dashboard()
        wf_clause = (
            f"WHERE WORKFLOW_ID = {workflow_id}" if workflow_id is not None else ""
        )
        df = run_query(
            f"""
            SELECT DISTINCT EXECUTOR_TYPE
            FROM {qm}.TASK_QUEUE
            {wf_clause}
            ORDER BY EXECUTOR_TYPE
            """
        )
        if len(df) == 0:
            return []
        col = df.columns[0]
        return [str(x) for x in df[col].dropna().tolist() if str(x).strip() != ""]
    except Exception:
        return []


@st.cache_data(ttl=30)
def get_task_queue(
    workflow_id: int | None,
    status_filter: str,
    executor_type: str | None,
) -> pd.DataFrame:
    """TASK_QUEUE rows with optional workflow, status bucket, and executor filters."""
    try:
        conditions: list[str] = []
        if workflow_id is not None:
            conditions.append(f"WORKFLOW_ID = {workflow_id}")
        if status_filter == "non_terminal":
            conditions.append("STATUS NOT IN ('completed', 'failed')")
        elif status_filter == "completed":
            conditions.append("STATUS = 'completed'")
        elif status_filter == "failed":
            conditions.append("STATUS IN ('failed', 'abandoned')")
        elif status_filter == "executing":
            conditions.append("STATUS = 'executing'")
        elif status_filter != "all":
            return pd.DataFrame()

        if executor_type:
            safe_et = executor_type.replace("'", "''")
            conditions.append(f"EXECUTOR_TYPE = '{safe_et}'")

        where_sql = "WHERE " + " AND ".join(conditions) if conditions else ""
        qm = migration_schema_for_streamlit_dashboard()
        return run_query(
            f"""
            SELECT
                WORKFLOW_ID,
                ID,
                NAME,
                EXECUTOR_TYPE,
                STATUS,
                PRIORITY,
                AFFINITY,
                LAST_ERROR_MESSAGE,
                FAILURES,
                PAYLOAD,
                LEASING_TIME,
                CREATION_TIME,
                START_TIME,
                END_TIME
            FROM {qm}.TASK_QUEUE
            {where_sql}
            ORDER BY NAME
            """
        )
    except Exception:
        return pd.DataFrame()


# Title
st.title("🔄 Data migration dashboard")

# Sidebar with workflow filter and refresh
with st.sidebar:
    st.header("🔍 Filters")

    if st.button("🔄 Refresh data"):
        st.cache_data.clear()

    st.caption("Data refreshes every 30 seconds")

    # Workflow filter (by WORKFLOW.NAME; resolve to id for queries)
    workflows = get_workflows()
    wf_display = {
        wf_id: (name or f"Workflow {wf_id}") for wf_id, name in workflows.items()
    }
    workflow_options = ["All workflows"] + [wf_display[wid] for wid in wf_display]
    name_to_id = {display: wid for wid, display in wf_display.items()}

    selected_workflow_str = st.selectbox(
        "Workflow name",
        options=workflow_options,
        index=0,
        key="workflow_filter",
        help="Filter the dashboard by workflow name",
        disabled=len(workflows) == 0,
    )

    selected_workflow = (
        None
        if selected_workflow_str == "All workflows"
        else name_to_id.get(selected_workflow_str)
    )

    if len(workflows) == 0:
        st.warning("No workflows found in the database.")

# Main content tabs
tab_overview, tab_workflows, tab_tables, tab_errors, tab_tasks = st.tabs(
    [
        "📊 Overview",
        "🔀 Workflows",
        "📋 Table progress",
        "⚠️ Error logs",
        "📌 Tasks",
    ]
)

# Overview Dashboard Tab
with tab_overview:
    metrics = get_overview_metrics(selected_workflow)

    if metrics is not None:
        total_workflows = int(metrics["TOTAL_WORKFLOWS"] or 0)
        total_tables = int(metrics["TOTAL_TABLES"] or 0)
        total_partitions = int(metrics["TOTAL_PARTITIONS"] or 0)
        loaded = int(metrics["LOADED_PARTITIONS"] or 0)
        failed = int(metrics["FAILED_PARTITIONS"] or 0)
        extracting = int(metrics["EXTRACTING"] or 0)
        loading = int(metrics["LOADING"] or 0)

        progress_pct = (loaded / total_partitions * 100) if total_partitions > 0 else 0
        in_progress = extracting + loading

        # Show which workflow is selected
        if selected_workflow is not None and selected_workflow_str != "All workflows":
            st.info(f"Showing data for **{selected_workflow_str}**")

        # KPI Row
        cols = st.columns(6 if selected_workflow is None else 5)
        col_idx = 0
        if selected_workflow is None:
            with cols[col_idx]:
                st.metric("Workflows", f"{total_workflows:,}")
            col_idx += 1
        with cols[col_idx]:
            st.metric("Tables", f"{total_tables:,}")
        with cols[col_idx + 1]:
            st.metric("Total partitions", f"{total_partitions:,}")
        with cols[col_idx + 2]:
            st.metric(
                "Loaded",
                f"{loaded:,}",
                delta=f"{progress_pct:.1f}% complete",
            )
        with cols[col_idx + 3]:
            st.metric(
                "In progress",
                f"{in_progress:,}",
                delta=f"{extracting:,} extracting, {loading:,} loading",
                delta_color="off",
            )
        with cols[col_idx + 4]:
            st.metric(
                "Failed",
                f"{failed:,}",
                delta="needs attention" if failed > 0 else None,
                delta_color="inverse",
            )

        # Progress visualization
        col1, col2 = st.columns(2)

        with col1:
            with st.container():
                st.subheader("Overall progress")
                if total_partitions > 0:
                    st.progress(loaded / total_partitions)
                    st.caption(f"{loaded:,} of {total_partitions:,} partitions loaded")
                else:
                    st.info("No partitions found")

        with col2:
            with st.container():
                st.subheader("Partition status breakdown")
                status_data = pd.DataFrame(
                    {
                        "Status": ["Loaded", "Extracting", "Loading", "Failed"],
                        "Count": [loaded, extracting, loading, failed],
                    }
                )
                status_data = status_data[status_data["Count"] > 0]
                if len(status_data) > 0:
                    st.bar_chart(status_data.set_index("Status"))
                else:
                    st.info("No partition data available")
    else:
        st.warning(
            "No migration data available. Ensure the migration workflow is running."
        )

# Workflows Tab
with tab_workflows:
    st.subheader("Workflow summary")

    workflow_df = get_workflow_summary()

    if len(workflow_df) > 0:
        # Workflow KPIs
        total_wf = len(workflow_df)
        completed_wf = len(workflow_df[workflow_df["PROGRESS_PCT"] == 100])
        failed_wf = len(workflow_df[workflow_df["FAILED"] > 0])

        cols = st.columns(4)
        with cols[0]:
            st.metric("Total workflows", total_wf)
        with cols[1]:
            st.metric("Completed", completed_wf)
        with cols[2]:
            st.metric(
                "With errors",
                failed_wf,
                delta="needs attention" if failed_wf > 0 else None,
                delta_color="inverse",
            )
        with cols[3]:
            st.metric("In progress", total_wf - completed_wf)

        # Workflow table with progress bars
        st.dataframe(
            workflow_df,
            use_container_width=True,
        )

        # Workflow comparison chart
        with st.container():
            st.subheader("Workflow progress comparison")
            if len(workflow_df) > 0:
                chart_df = workflow_df[
                    ["WORKFLOW_ID", "LOADED", "FAILED", "IN_PROGRESS"]
                ].copy()
                chart_df["WORKFLOW_ID"] = chart_df["WORKFLOW_ID"].astype(str)
                chart_df = chart_df.set_index("WORKFLOW_ID")
                st.bar_chart(chart_df)
            else:
                st.info("No workflow data to display.")
    else:
        st.info("No workflow data available.")

# Table Progress Tab
with tab_tables:
    if selected_workflow is not None and selected_workflow_str != "All workflows":
        st.info(f"Showing tables for **{selected_workflow_str}**")

    table_df = get_table_progress(selected_workflow)

    if len(table_df) > 0:
        # Summary stats
        tables_with_errors = len(table_df[table_df["FAILED_PARTITIONS"] > 0])
        tables_complete = len(
            table_df[
                (table_df["LOADED_PARTITIONS"] == table_df["TOTAL_PARTITIONS"])
                & (table_df["TOTAL_PARTITIONS"] > 0)
            ]
        )

        cols = st.columns(3)
        with cols[0]:
            st.metric("Tables with errors", tables_with_errors)
        with cols[1]:
            st.metric("Tables complete", tables_complete)
        with cols[2]:
            st.metric(
                "Tables in progress",
                len(table_df) - tables_complete - tables_with_errors,
            )

        # Search filter
        search = st.text_input(
            "Search tables",
            placeholder="Filter by table name...",
            label_visibility="collapsed",
        )

        filtered_df = table_df
        if search:
            filtered_df = table_df[
                table_df["TABLE_NAME"].str.contains(search, case=False, na=False)
            ]

        # Add computed columns for display
        if len(filtered_df) > 0:
            display_df = filtered_df.copy()
            display_df["PROGRESS"] = display_df.apply(
                lambda r: (
                    (r["LOADED_PARTITIONS"] / r["TOTAL_PARTITIONS"] * 100)
                    if r["TOTAL_PARTITIONS"] > 0
                    else 0
                ),
                axis=1,
            )
            display_df["STATUS"] = display_df.apply(
                lambda r: (
                    "Failed"
                    if r["FAILED_PARTITIONS"] > 0
                    else (
                        "Complete"
                        if r["LOADED_PARTITIONS"] == r["TOTAL_PARTITIONS"]
                        and r["TOTAL_PARTITIONS"] > 0
                        else "In progress"
                    )
                ),
                axis=1,
            )
        else:
            display_df = pd.DataFrame()

        # Display dataframe with progress bars
        if len(display_df) > 0:
            st.dataframe(
                display_df,
                use_container_width=True,
            )
        else:
            st.info("No tables match the current filter.")
    else:
        st.info("No table progress data available.")

# Error Logs Tab
with tab_errors:
    if selected_workflow is not None and selected_workflow_str != "All workflows":
        st.info(f"Showing errors for **{selected_workflow_str}**")

    # Get unique table names for filter (respecting workflow filter)
    table_df = get_table_progress(selected_workflow)
    table_names = ["All tables"]
    if len(table_df) > 0 and "TABLE_NAME" in table_df.columns:
        unique_tables = table_df["TABLE_NAME"].dropna().unique().tolist()
        if unique_tables:
            table_names = table_names + sorted(unique_tables)

    # Table filter
    selected_table = st.selectbox(
        "Filter by table", options=table_names, label_visibility="collapsed"
    )

    error_df = get_error_logs(selected_workflow, selected_table)

    if len(error_df) > 0:
        st.caption(f"Showing {len(error_df):,} error records")

        st.dataframe(
            error_df,
            use_container_width=True,
        )

        # Error message detail expander
        if st.checkbox("Show full error details"):
            for _idx, row in error_df.iterrows():
                with st.expander(
                    f"{row['TABLE_NAME']} - Partition {row['PARTITION_NUMBER']}"
                ):
                    st.code(row["LAST_ERROR_MESSAGE"], language=None)
    else:
        st.success("No errors found. All partitions are processing successfully.")

# Tasks tab (TASK_QUEUE)
_TASK_STATUS_LABELS = (
    "All statuses",
    "Non-terminal (not completed / not failed)",
    "Completed",
    "Failed (failed or abandoned)",
    "Executing",
)
_TASK_STATUS_KEYS = ("all", "non_terminal", "completed", "failed", "executing")

with tab_tasks:
    st.info(
        "Each **workflow** is broken down into **tasks**: one row here is one queued "
        "unit of work. This tab is intentionally detailed—columns include payload, errors, "
        "and timings—so you can debug and inspect the queue. Other tabs stay at a higher level."
    )

    if selected_workflow is not None and selected_workflow_str != "All workflows":
        st.info(f"Showing tasks for **{selected_workflow_str}**")

    c1, c2 = st.columns(2)
    with c1:
        status_label = st.selectbox(
            "Task status",
            options=_TASK_STATUS_LABELS,
            index=0,
            key="tasks_status_filter",
        )
    with c2:
        executor_options = ["All executor types"] + get_task_queue_executor_types(
            selected_workflow
        )
        executor_label = st.selectbox(
            "Executor type",
            options=executor_options,
            index=0,
            key="tasks_executor_filter",
        )

    status_key = dict(zip(_TASK_STATUS_LABELS, _TASK_STATUS_KEYS, strict=True))[
        status_label
    ]
    executor_arg = None if executor_label == "All executor types" else executor_label
    task_df = get_task_queue(selected_workflow, status_key, executor_arg)

    if len(task_df) > 0:
        st.caption(f"Showing {len(task_df):,} task(s)")
        st.dataframe(task_df, use_container_width=True)
    else:
        st.info("No tasks match the current filters.")
