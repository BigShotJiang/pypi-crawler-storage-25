"""
Streamlit Dashboard Deployer.

Handles automatic deployment of the Streamlit dashboard to Snowflake
when the orchestrator starts.
"""

import os
import shutil

from pathlib import Path

import snowflake.connector

from data_migration_orchestrator.cloud_core.observability.logging_config import (
    get_logger,
)
from data_migration_orchestrator.cloud_core.snowflake_account import (
    qualified_migration_schema,
)
from data_migration_orchestrator.cloud_core.streamlit_deployer import (
    StreamlitAppConfig,
    deploy_streamlit_app,
)


logger = get_logger("streamlit_deployer")

STREAMLIT_APP_NAME = os.environ.get("STREAMLIT_APP_NAME", "DATA_MIGRATION_DASHBOARD")
STREAMLIT_STAGE_NAME = os.environ.get(
    "STREAMLIT_STAGE_NAME", "STREAMLIT_DASHBOARD_STAGE"
)

_BAKED_METADATA_NAME = "_streamlit_baked_metadata.py"
_SIS_STAGED_NAME = "sis_streamlit_metadata.py"
_PACKAGE_ROOT = Path(__file__).resolve().parent.parent.parent
_SIS_STREAMLIT_METADATA_SOURCE = _PACKAGE_ROOT / "utils" / _SIS_STAGED_NAME


def _write_dm_baked_metadata(qualified_migration: str, path: Path) -> None:
    path.write_text(
        '"""Generated when deploying to Streamlit in Snowflake; do not commit.\n\n'
        "Defines the migration metadata schema (database.schema) from deploy time so the\n"
        'SiS runtime does not need CUSTOM_* environment variables.\n"""\n\n'
        f"QUALIFIED_MIGRATION_SCHEMA = {qualified_migration!r}\n",
        encoding="utf-8",
    )


def deploy_streamlit_if_needed(
    connection: snowflake.connector.SnowflakeConnection,
) -> None:
    """Deploy or update the Streamlit dashboard when the local code has changed."""
    qm = qualified_migration_schema()
    dashboard_dir = Path(__file__).parent
    baked_path = dashboard_dir / _BAKED_METADATA_NAME
    _write_dm_baked_metadata(qm, baked_path)
    sis_staged = dashboard_dir / _SIS_STAGED_NAME
    shutil.copyfile(_SIS_STREAMLIT_METADATA_SOURCE, sis_staged)
    config = StreamlitAppConfig(
        qualified_schema=qm,
        app_name=STREAMLIT_APP_NAME,
        stage_name=STREAMLIT_STAGE_NAME,
        app_file=dashboard_dir / "app.py",
        companion_files=(baked_path, sis_staged),
    )
    deploy_streamlit_app(connection, config, logger)
