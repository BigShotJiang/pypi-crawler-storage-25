"""Custom exceptions for the tasks module."""

from .table_not_found_error import TableNotFoundError
from .unsupported_extraction_strategy_error import UnsupportedExtractionStrategyError


__all__ = [
    "TableNotFoundError",
    "UnsupportedExtractionStrategyError",
]
