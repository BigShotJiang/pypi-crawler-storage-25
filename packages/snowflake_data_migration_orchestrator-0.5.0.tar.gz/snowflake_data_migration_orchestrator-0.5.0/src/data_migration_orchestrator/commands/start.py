"""
Command to start the data migration orchestrator loop.

Connects to Snowflake, runs schema migrations, deploys the Streamlit
dashboard, and enters the main orchestration loop.
"""

import argparse
import asyncio
import time

from pathlib import Path
from typing import cast

from data_migration_orchestrator.__version__ import __version__
from data_migration_orchestrator.cloud_core.connection_manager import (
    get_connection_config,
)
from data_migration_orchestrator.cloud_core.observability.logging_config import (
    LogDestination,
    get_log_level_from_string,
    get_logger,
    parse_log_destination,
    setup_logging,
    shutdown_logging,
)
from data_migration_orchestrator.cloud_core.observability.telemetry_lifecycle import (
    create_orchestrator_connection,
    log_orchestrator_crash,
    log_orchestrator_start,
    log_orchestrator_stop,
)
from data_migration_orchestrator.cloud_core.orchestrator_affinity import (
    get_affinity_from_env,
)
from data_migration_orchestrator.cloud_core.tasks.queues.table_task_queue import (
    TableTaskQueue,
)
from data_migration_orchestrator.cloud_core.warehouse import Warehouse
from data_migration_orchestrator.cloud_orchestrator.orchestrator import Orchestrator
from data_migration_orchestrator.cloud_orchestrator.schema import run_schema_migrations
from data_migration_orchestrator.cloud_orchestrator.worker_context import WorkerContext
from data_migration_orchestrator.commands import START
from data_migration_orchestrator.data_migration_cloud.dashboard import (
    deploy_streamlit_if_needed,
)
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload import (
    TaskPayload,
)
from data_migration_orchestrator.data_migration_cloud.tasks.task_handler_factory import (
    TaskHandlerFactory,
)
from data_migration_orchestrator.data_migration_cloud.tasks.task_payload_mapper import (
    map_data_migration_task_payload,
)
from data_migration_orchestrator.data_validation_cloud.dashboard import (
    deploy_dv_streamlit_if_needed,
)
from data_migration_orchestrator.data_validation_cloud.tasks.task_handler_factory import (
    DataValidationTaskHandlerFactory,
)
from data_migration_orchestrator.data_validation_cloud.tasks.task_payload_mapper import (
    map_data_validation_task_payload,
)


async def _run(args: argparse.Namespace) -> None:
    """Run the data migration orchestrator."""
    setup_logging(
        destination=args.log_destination,
        log_file_path=args.log_file,
        log_level=args.log_level,
    )

    logger = get_logger("main")
    logger.info("Starting data migration orchestrator")

    start_time = time.time()

    try:
        connection_config = get_connection_config()
        affinity = get_affinity_from_env()
        logger.info(f"Orchestrator affinity: {affinity}")

        connection = create_orchestrator_connection(__version__, connection_config)

        with connection:
            log_orchestrator_start(
                affinity, args.log_level, args.log_destination, logger
            )

            run_schema_migrations(connection)

            try:
                deploy_streamlit_if_needed(connection)
            except Exception:
                logger.warning(
                    "Dashboard deployment failed — continuing without it",
                    exc_info=True,
                )

            try:
                deploy_dv_streamlit_if_needed(connection)
            except Exception:
                logger.warning(
                    "DV dashboard deployment failed — continuing without it",
                    exc_info=True,
                )

            def _combined_payload_mapper(kind: str, payload_dict: dict) -> TaskPayload:
                """Try DV mapper first, fall back to DM mapper."""
                try:
                    return cast(
                        TaskPayload,
                        map_data_validation_task_payload(kind, payload_dict),
                    )
                except ValueError:
                    return cast(
                        TaskPayload,
                        map_data_migration_task_payload(kind, payload_dict),
                    )

            logger.info("Initializing task queue and warehouse proxy")
            task_queue = TableTaskQueue[TaskPayload](
                connection=connection,
                payload_mapper=_combined_payload_mapper,
                affinity=affinity,
            )
            warehouse_proxy = Warehouse(conn=connection, task_queue=task_queue)

            def make_worker_context() -> WorkerContext:
                conn = create_orchestrator_connection(__version__, connection_config)
                wh = Warehouse(conn=conn, task_queue=task_queue)
                hf = TaskHandlerFactory(task_queue=task_queue, warehouse_proxy=wh)
                dv_hf = DataValidationTaskHandlerFactory(
                    task_queue=task_queue, warehouse_proxy=wh
                )
                return WorkerContext(
                    connection=conn,
                    task_queue=task_queue,
                    warehouse=wh,
                    handler_factory=hf,
                    dv_handler_factory=dv_hf,
                )

            orchestrator = Orchestrator(
                task_queue=task_queue,
                warehouse_proxy=warehouse_proxy,
                worker_context_factory=make_worker_context,
            )

            logger.info("Starting orchestrator")
            try:
                await orchestrator.start()
            finally:
                orchestrator.stop()
    except Exception as e:
        logger.error(f"Application error: {e}", exc_info=True)
        log_orchestrator_crash(e)
        raise
    finally:
        logger.info("Shutting down data migration orchestrator")
        log_orchestrator_stop(start_time, logger)
        shutdown_logging()


def register_subparser(subparsers: argparse._SubParsersAction) -> None:
    """Register the ``start`` subcommand."""
    start_parser = subparsers.add_parser(
        START,
        help="Start the orchestrator loop (default command)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python -m data_migration_orchestrator.main start
  python -m data_migration_orchestrator.main start --log-destination stdout
  python -m data_migration_orchestrator.main start --log-level DEBUG
        """,
    )
    start_parser.set_defaults(func=lambda args: asyncio.run(_run(args)))

    start_parser.add_argument(
        "--log-destination",
        type=parse_log_destination,
        default=LogDestination.BOTH,
        help="Where to send logs: stdout, file, or both (default: both)",
    )
    start_parser.add_argument(
        "--log-file",
        type=Path,
        default=None,
        help="Path to log file (default: logs/data_migration_orchestrator.log)",
    )
    start_parser.add_argument(
        "--log-level",
        type=get_log_level_from_string,
        default="INFO",
        help="Logging level: DEBUG, INFO, WARNING, ERROR, or CRITICAL (default: INFO)",
    )
