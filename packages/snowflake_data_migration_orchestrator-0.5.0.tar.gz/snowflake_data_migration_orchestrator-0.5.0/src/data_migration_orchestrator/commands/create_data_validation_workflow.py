"""
Command to create a Data Validation Workflow.

Reads a JSON configuration file, validates it against the data validation
schema, and inserts a row into the WORKFLOW table with type 'data-validation'.
"""

import argparse
import json
import sys

from pathlib import Path

import snowflake.connector

from data_migration_orchestrator.cloud_core.connection_manager import (
    get_connection_config,
)
from data_migration_orchestrator.commands import CREATE_DATA_VALIDATION_WORKFLOW
from data_migration_orchestrator.data_validation_cloud.config.workflow_configuration_schema import (
    validate_data_validation_workflow_configuration,
)
from data_migration_orchestrator.data_validation_cloud.constants.stages import (
    default_internal_stage,
)
from data_migration_orchestrator.utils.snowflake_metadata import (
    qualified_migration_schema,
)
from data_migration_orchestrator.utils.snowflake_sql_utils import escape_sql_string


def register_subparser(subparsers: argparse._SubParsersAction) -> None:
    """Register the ``create-data-validation-workflow`` subcommand."""
    create_parser = subparsers.add_parser(
        CREATE_DATA_VALIDATION_WORKFLOW,
        help="Validate a data validation config and insert it into the WORKFLOW table",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python -m data_migration_orchestrator create-data-validation-workflow config.json
  python -m data_migration_orchestrator create-data-validation-workflow config.json --name my_validation
  python -m data_migration_orchestrator create-data-validation-workflow config.json --source-platform "SQL server"
        """,
    )
    create_parser.set_defaults(func=create_data_validation_workflow)

    create_parser.add_argument(
        "config_file",
        type=Path,
        help="Path to the JSON data validation workflow configuration file",
    )
    create_parser.add_argument(
        "--connection-name",
        type=str,
        default=None,
        help="Snowflake connection name (uses default from env vars if omitted)",
    )
    create_parser.add_argument(
        "--name",
        type=str,
        default="MY_VALIDATION_WORKFLOW",
        help="Workflow name (default: MY_VALIDATION_WORKFLOW)",
    )
    create_parser.add_argument(
        "--source-platform",
        type=str,
        help="Source platform (overrides the value in the config file)",
    )


_TARGET_CLOUD_TYPE = "snowflake:stage"
_SCHEMA_VERSION = "1.0"


def _read_config_file(config_file: Path) -> dict:
    """Read and parse a JSON configuration file."""
    if not config_file.is_file():
        print(f"Error: configuration file not found: {config_file}", file=sys.stderr)
        sys.exit(1)

    try:
        with open(config_file) as f:
            return json.load(f)
    except json.JSONDecodeError as e:
        print(f"Error: invalid JSON in {config_file}: {e}", file=sys.stderr)
        sys.exit(1)


def _connect(connection_name: str | None) -> snowflake.connector.SnowflakeConnection:
    """Create a Snowflake connection."""
    if connection_name is not None:
        print(f"Using Snowflake connection: {connection_name}")
        return snowflake.connector.connect(connection_name=connection_name)

    config = get_connection_config()
    display_name = config.get("connection_name") or config.get("account", "default")
    print(f"Using Snowflake connection: {display_name}")
    return snowflake.connector.connect(**config)


def _workflow_name_exists(
    cursor: snowflake.connector.cursor.SnowflakeCursor,
    name: str,
) -> bool:
    """Check whether a workflow with the given name already exists."""
    qm = qualified_migration_schema()
    cursor.execute(
        f"SELECT 1 FROM {qm}.WORKFLOW WHERE NAME = %s LIMIT 1",
        (name,),
    )
    return cursor.fetchone() is not None


def _build_insert_sql(
    *,
    name: str,
    source_platform: str,
    configuration_json: str,
    affinity: str | None,
) -> str:
    """Build the INSERT SQL for a data validation workflow."""
    qm = qualified_migration_schema()
    affinity_sql = f"'{escape_sql_string(affinity)}'" if affinity else "NULL"
    return f"""\
INSERT INTO {qm}.WORKFLOW(
    NAME,
    WORKFLOW_TYPE,
    SOURCE_PLATFORM,
    TARGET_CLOUD_TYPE,
    TARGET_CLOUD_STAGE_NAME,
    TARGET_CLOUD_URL,
    SCHEMA_VERSION,
    INITIATOR_ID,
    CONFIGURATION,
    AFFINITY
)
SELECT
    '{escape_sql_string(name)}',
    'data-validation',
    '{escape_sql_string(source_platform)}',
    '{_TARGET_CLOUD_TYPE}',
    '{default_internal_stage()}',
    '',
    '{_SCHEMA_VERSION}',
    '',
    PARSE_JSON('{escape_sql_string(configuration_json)}'),
    {affinity_sql}
"""


def create_data_validation_workflow(args: argparse.Namespace) -> None:
    """Entry point invoked by the CLI subcommand."""
    config = _read_config_file(args.config_file)

    validated = validate_data_validation_workflow_configuration(config)
    print("Data validation workflow configuration is valid.")

    source_platform = args.source_platform or validated.source_platform
    affinity = validated.affinity
    configuration_json = json.dumps(config)

    sql = _build_insert_sql(
        name=args.name,
        source_platform=source_platform,
        configuration_json=configuration_json,
        affinity=affinity,
    )

    connection = _connect(args.connection_name)
    try:
        cursor = connection.cursor()
        try:
            if _workflow_name_exists(cursor, args.name):
                print(
                    f"Error: a workflow named '{args.name}' already exists. "
                    "Choose a different name.",
                    file=sys.stderr,
                )
                sys.exit(1)
            cursor.execute(sql)
            print("Data validation workflow created successfully.")
        finally:
            cursor.close()
    finally:
        connection.close()
