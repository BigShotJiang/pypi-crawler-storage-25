"""Schema migrations for Data Migration Orchestrator."""

from data_migration_orchestrator.cloud_orchestrator.schema.migrations.base_migration import (
    BaseMigration,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0001_initial import (
    Migration0001Initial,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0002_data_validation import (
    Migration0002DataValidation,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0003_partition_support import (
    Migration0003PartitionSupport,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0004_csv_record_delimiter import (
    Migration0004CsvRecordDelimiter,
)
from data_migration_orchestrator.cloud_orchestrator.schema.migrations.migration_0005_validation_progress import (
    Migration0005ValidationProgress,
)


__all__ = [
    "BaseMigration",
    "Migration0001Initial",
    "Migration0002DataValidation",
    "Migration0003PartitionSupport",
    "Migration0004CsvRecordDelimiter",
    "Migration0005ValidationProgress",
]
