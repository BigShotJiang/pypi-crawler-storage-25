from collections.abc import Callable
from dataclasses import dataclass, field

from snowflake.connector import SnowflakeConnection

from data_migration_orchestrator.cloud_core.tasks.queues.base_task_queue import (
    BaseTaskQueue,
)
from data_migration_orchestrator.cloud_core.warehouse import Warehouse
from data_migration_orchestrator.data_migration_cloud.tasks.models.task_payload import (
    TaskPayload,
)
from data_migration_orchestrator.data_migration_cloud.tasks.task_handler_factory import (
    TaskHandlerFactory,
)
from data_migration_orchestrator.data_validation_cloud.tasks.task_handler_factory import (
    DataValidationTaskHandlerFactory,
)


@dataclass
class WorkerContext:
    """
    Per-thread resources for task execution workers.

    Each worker thread owns its own Snowflake connection and the dependent
    objects built on top of it (task queue, warehouse proxy, handler factories).
    """

    connection: SnowflakeConnection
    task_queue: BaseTaskQueue[TaskPayload]
    warehouse: Warehouse
    handler_factory: TaskHandlerFactory[TaskPayload]
    dv_handler_factory: DataValidationTaskHandlerFactory | None = field(default=None)


WorkerContextFactory = Callable[[], WorkerContext]
