# Iceberg Table Migration Support

## Overview

The data-migration-orchestrator supports migrating data into **Apache Iceberg tables on Snowflake**. This enables customers to adopt the open Iceberg table format while using the orchestrator's managed workflow engine for reliable, scalable migrations.

Three migration strategies are available, each targeting a different trade-off between data movement, write capability, and operational complexity:

| Strategy | Data Movement | DML on Target | Primary Use Case |
|---|---|---|---|
| **`catalog_link`** | None (zero-copy) | Read-only | Quick access to existing Iceberg data without copying anything |
| **`convert_to_managed`** | None (zero-copy) | Full DML | Take ownership of existing Iceberg data without rewriting files |
| **`copy_files`** | Server-side binary copy | Full DML | Create a new Snowflake-managed Iceberg table from staged Parquet files |

---

## Architecture

### How Iceberg Migrations Differ from Native Migrations

In a standard (native) migration, the orchestrator follows a multi-phase pipeline:

```
Source Table → Data Exchange Agent (ODBC/UNLOAD) → Stage (Parquet/CSV) → COPY INTO → Snowflake Native Table
```

Iceberg migrations bypass much of this pipeline. Since the source data is typically already stored as Parquet files on S3, there is no need for ODBC extraction or UNLOAD operations. Instead, the orchestrator issues DDL and DML statements directly in Snowflake:

```
Existing Parquet on S3
       │
       ├── catalog_link ──────────► CREATE ICEBERG TABLE ... CATALOG = '<integration>'
       │                            (points Snowflake at existing catalog metadata)
       │
       ├── convert_to_managed ───► CREATE ICEBERG TABLE ... CATALOG = '<integration>'
       │                           then ALTER ICEBERG TABLE ... CONVERT TO MANAGED
       │                           (Snowflake takes ownership of metadata)
       │
       └── copy_files ──────────► CREATE ICEBERG TABLE ... CATALOG = 'SNOWFLAKE'
                                   then COPY INTO ... LOAD_MODE = ADD_FILES_COPY
                                   (server-side binary copy of Parquet files)
```

### Component Responsibilities

| Component | File | Role in Iceberg Migrations |
|---|---|---|
| **`DataMigrationWorkflowInitializer`** | `data_migration_cloud/data_migration_workflow_initializer.py` | Routes Iceberg targets to dedicated task chains; resolves migration strategy; builds catalog-link DDL; serializes `icebergConfig` to table metadata |
| **`ConfigurationParser`** | `data_migration_cloud/config/configuration_parser.py` | Parses `tableType` and `icebergConfig` from workflow JSON; validates required fields per strategy |
| **`IcebergTargetConfig`** | `data_migration_cloud/config/table_configuration.py` | Data model for Iceberg target configuration; validates `migrationStrategy` values |
| **`IcebergConfigSchema`** | `data_migration_cloud/config/workflow_configuration_schema.py` | Pydantic validation schema for `icebergConfig` in workflow JSON |
| **`StagedDataHandler`** | `data_migration_cloud/tasks/handlers/staged_data_handler.py` | Generates `CREATE ICEBERG TABLE` DDL with column definitions; builds `COPY INTO ... LOAD_MODE = ADD_FILES_COPY`; infers schema from Parquet via `INFER_SCHEMA` |
| **`SnowflakeQueryHandler`** | `data_migration_cloud/tasks/handlers/snowflake_query_handler.py` | Executes DDL tasks for `catalog_link` and `convert_to_managed` strategies |
| **`TableConfigurationService`** | `data_migration_cloud/tasks/handlers/table_configuration_service.py` | Reconstructs `IcebergTargetConfig` from stored table metadata |
| **`RedshiftQueryBuilder`** | `platforms/redshift/query_builder.py` | Provides `build_external_table_schema_query` and `build_external_metadata_query` for Iceberg/external table metadata discovery |

### Task Flow by Strategy

#### `catalog_link`

```
┌─────────────────────────────────────────────────────┐
│  SNOWFLAKE_QUERY: CREATE ICEBERG TABLE              │
│    CATALOG = '<catalog_integration>'                │
│    CATALOG_TABLE_NAME = '<glue_db.table>'           │
│    EXTERNAL_VOLUME = '<ext_vol>'                    │
└─────────────────────────────────────────────────────┘
```

Single task. Executed by the Orchestrator via `SnowflakeQueryHandler`.

#### `convert_to_managed`

```
┌─────────────────────────────────────────────────────┐
│  SNOWFLAKE_QUERY: CREATE ICEBERG TABLE              │
│    CATALOG = '<catalog_integration>'                │
│    CATALOG_TABLE_NAME = '<glue_db.table>'           │
│    EXTERNAL_VOLUME = '<ext_vol>'                    │
└────────────────────────┬────────────────────────────┘
                         │ successor
                         ▼
┌─────────────────────────────────────────────────────┐
│  SNOWFLAKE_QUERY: ALTER ICEBERG TABLE               │
│    <target> CONVERT TO MANAGED                      │
└─────────────────────────────────────────────────────┘
```

Two sequential tasks. The ALTER is blocked until the CREATE completes.

#### `copy_files` (with `sourceDataStage`)

```
┌─────────────────────────────────────────────────────┐
│  PROCESS_STAGED_DATA:                               │
│    1. INFER_SCHEMA from sourceDataStage             │
│    2. CREATE ICEBERG TABLE (CATALOG='SNOWFLAKE')    │
│    3. COPY INTO ... LOAD_MODE = ADD_FILES_COPY      │
└─────────────────────────────────────────────────────┘
```

Single task. Schema is inferred from Parquet files on the stage. No Data Exchange Agent involvement.

#### `copy_files` (without `sourceDataStage` -- DEA fallback)

```
┌─────────────────────────────────────────────────────┐
│  DATA_EXCHANGE_AGENT: Extract schema from source    │
│    (SVV_EXTERNAL_COLUMNS or information_schema)     │
└────────────────────────┬────────────────────────────┘
                         │ successor
                         ▼
┌─────────────────────────────────────────────────────┐
│  PROCESS_STAGED_DATA:                               │
│    1. CREATE ICEBERG TABLE (CATALOG='SNOWFLAKE')    │
│    2. COPY INTO ... LOAD_MODE = ADD_FILES_COPY      │
└─────────────────────────────────────────────────────┘
```

Two tasks. The Data Exchange Agent extracts the schema from the source database; the load task is blocked until schema extraction completes.

### Strategy Auto-Detection

When `migrationStrategy` is omitted from `icebergConfig`, the orchestrator resolves the strategy automatically based on the `catalog` value:

| `catalog` Value | Auto-Detected Strategy |
|---|---|
| Not `"SNOWFLAKE"` (e.g., a Glue integration name) | `catalog_link` |
| `"SNOWFLAKE"` | `copy_files` |

To use `convert_to_managed`, you must set `migrationStrategy` explicitly since the auto-detection defaults to `catalog_link` for external catalogs.

---

## Prerequisites (Snowflake Account Setup)

Before running any Iceberg migration, the following objects and permissions must be configured in the target Snowflake account. **These are one-time setup steps** that must be completed by a Snowflake account administrator.

### 1. External Volume

An external volume is **required for all Iceberg migration strategies**. It defines the S3 location where Iceberg data and metadata files are stored.

```sql
CREATE EXTERNAL VOLUME my_iceberg_ext_vol
  STORAGE_LOCATIONS = (
    (
      NAME = 'iceberg-s3-location'
      STORAGE_BASE_URL = 's3://my-iceberg-bucket/data/'
      STORAGE_PROVIDER = 'S3'
      STORAGE_AWS_ROLE_ARN = 'arn:aws:iam::123456789012:role/SnowflakeIcebergRole'
    )
  );
```

After creation, retrieve the Snowflake-generated IAM user and external ID:

```sql
DESCRIBE EXTERNAL VOLUME my_iceberg_ext_vol;
```

Record the `STORAGE_AWS_IAM_USER_ARN` and `STORAGE_AWS_EXTERNAL_ID` values -- you must add these to the IAM trust policy of the role referenced by `STORAGE_AWS_ROLE_ARN`.

#### IAM Trust Policy for the External Volume Role

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "AWS": "<STORAGE_AWS_IAM_USER_ARN from DESCRIBE>"
      },
      "Action": "sts:AssumeRole",
      "Condition": {
        "StringEquals": {
          "sts:ExternalId": "<STORAGE_AWS_EXTERNAL_ID from DESCRIBE>"
        }
      }
    }
  ]
}
```

#### IAM Permissions Policy for the External Volume Role

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "s3:PutObject",
        "s3:GetObject",
        "s3:GetObjectVersion",
        "s3:DeleteObject",
        "s3:DeleteObjectVersion"
      ],
      "Resource": "arn:aws:s3:::my-iceberg-bucket/*"
    },
    {
      "Effect": "Allow",
      "Action": [
        "s3:ListBucket",
        "s3:GetBucketLocation"
      ],
      "Resource": "arn:aws:s3:::my-iceberg-bucket"
    }
  ]
}
```

### 2. Catalog Integration (Required for `catalog_link` and `convert_to_managed`)

A catalog integration connects Snowflake to an external Iceberg catalog such as AWS Glue. This is **not needed** for the `copy_files` strategy with `CATALOG='SNOWFLAKE'`.

```sql
CREATE CATALOG INTEGRATION my_glue_catalog_integration
  CATALOG_SOURCE = GLUE
  TABLE_FORMAT = ICEBERG
  CATALOG_NAMESPACE = 'my_glue_database'
  GLUE_AWS_ROLE_ARN = 'arn:aws:iam::123456789012:role/SnowflakeGlueRole'
  GLUE_CATALOG_ID = '123456789012'
  GLUE_REGION = 'us-east-1'
  ENABLED = TRUE;
```

After creation, verify the integration:

```sql
DESCRIBE CATALOG INTEGRATION my_glue_catalog_integration;
```

The IAM role referenced by `GLUE_AWS_ROLE_ARN` needs both the trust policy (same pattern as external volume) and Glue permissions:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "glue:GetTable",
        "glue:GetTables",
        "glue:GetDatabase",
        "glue:GetDatabases"
      ],
      "Resource": [
        "arn:aws:glue:us-east-1:123456789012:catalog",
        "arn:aws:glue:us-east-1:123456789012:database/my_glue_database",
        "arn:aws:glue:us-east-1:123456789012:table/my_glue_database/*"
      ]
    }
  ]
}
```

### 3. Source Data Stage (Required for `copy_files` with `sourceDataStage`)

When using the `copy_files` strategy with `sourceDataStage`, you need a Snowflake external stage pointing to the S3 location of the existing Parquet files:

```sql
CREATE STAGE TARGET_DB.PUBLIC.ICEBERG_SOURCE_STAGE
  URL = 's3://my-iceberg-bucket/data/'
  STORAGE_INTEGRATION = my_s3_integration;
```

Verify files are accessible:

```sql
LIST @TARGET_DB.PUBLIC.ICEBERG_SOURCE_STAGE;
```

### 4. Role and Privilege Requirements

The Snowflake role used by the orchestrator needs the following privileges:

| Privilege | Object | Required For |
|---|---|---|
| `CREATE ICEBERG TABLE` | Schema | All strategies |
| `USAGE` | External volume | All strategies |
| `USAGE` | Catalog integration | `catalog_link`, `convert_to_managed` |
| `USAGE` | Stage | `copy_files` with `sourceDataStage` |
| `USAGE` | Database, Schema | All strategies |
| `OWNERSHIP` or `ALTER` | Iceberg table | `convert_to_managed` (for ALTER statement) |

```sql
GRANT CREATE ICEBERG TABLE ON SCHEMA TARGET_DB.PUBLIC TO ROLE migration_role;
GRANT USAGE ON EXTERNAL VOLUME my_iceberg_ext_vol TO ROLE migration_role;
GRANT USAGE ON INTEGRATION my_glue_catalog_integration TO ROLE migration_role;
```

### Prerequisites Checklist

Before starting an Iceberg migration workflow, verify:

- [ ] External volume created and IAM trust relationship configured
- [ ] S3 bucket accessible from Snowflake (test with `LIST @stage_name`)
- [ ] Catalog integration created and Glue access verified (if using external catalog)
- [ ] Source data stage created and Parquet files accessible (if using `copy_files` with `sourceDataStage`)
- [ ] Snowflake role has all required privileges
- [ ] Target database and schema exist in Snowflake

---

## User Guide

### Choosing a Strategy

| Situation | Recommended Strategy | Rationale |
|---|---|---|
| You have Iceberg tables registered in Glue and want read-only access from Snowflake | `catalog_link` | Zero data movement; instant setup |
| You have Iceberg tables in Glue and want Snowflake to take full ownership with DML support | `convert_to_managed` | Zero data movement; Snowflake manages metadata going forward |
| You have Parquet files on S3 and want to create new Snowflake-managed Iceberg tables | `copy_files` | Server-side binary copy; Snowflake has full control |
| You have Redshift native tables and want them as Iceberg in Snowflake | Standard migration + Iceberg target | UNLOAD to Parquet, then load into Iceberg |

### Workflow Configuration

Iceberg migration is configured through the `target` section of each table in the workflow JSON. The key fields are `tableType` (set to `"iceberg"`) and the `icebergConfig` object.

#### Configuration Schema Reference

```
target.tableType: "iceberg"        (required -- enables Iceberg target)
target.icebergConfig:              (required when tableType is "iceberg")
  ├── catalog: string              (default: "SNOWFLAKE")
  │     "SNOWFLAKE" for managed Iceberg, or catalog integration name
  ├── externalVolume: string       (required for SNOWFLAKE catalog)
  │     Name of the external volume in Snowflake
  ├── baseLocationPrefix: string   (optional, SNOWFLAKE catalog only)
  │     Prefix for the table's base_location path
  ├── catalogTableName: string     (required for external catalog)
  │     Fully qualified table name in the external catalog (e.g., "glue_db.my_table")
  ├── catalogSync: string          (optional)
  │     Catalog integration name to sync Snowflake-managed metadata back to
  ├── sourceDataStage: string      (optional, SNOWFLAKE catalog only)
  │     Stage path (must start with @) pointing to existing Parquet files
  └── migrationStrategy: string    (optional -- auto-detected when omitted)
        One of: "catalog_link", "convert_to_managed", "copy_files"
```

#### Validation Rules

The configuration parser enforces these rules at workflow creation time:

| Rule | Error When Violated |
|---|---|
| `tableType` must be `"native"` or `"iceberg"` | `ConfigurationError` |
| `icebergConfig` is required when `tableType` is `"iceberg"` | `ConfigurationError` |
| `externalVolume` is required when `catalog` is `"SNOWFLAKE"` | `ConfigurationError` |
| `catalogTableName` is required when `catalog` is not `"SNOWFLAKE"` | `ConfigurationError` |
| `migrationStrategy` must be one of the three valid values | `ValueError` |

### Example 1: Catalog Link (External Catalog, Zero-Copy)

This creates read-only Iceberg tables in Snowflake that point to existing data managed by an external catalog (e.g., AWS Glue).

```json
{
  "defaultTableConfiguration": {
    "source": {
      "schemaName": "iceberg_tpch",
      "databaseName": "ecommerce_db"
    },
    "target": {
      "schemaName": "public",
      "databaseName": "TARGET_DB",
      "tableType": "iceberg",
      "icebergConfig": {
        "catalog": "my_glue_catalog_integration",
        "externalVolume": "my_iceberg_ext_vol"
      }
    },
    "partitionSize": "auto"
  },
  "tables": [
    {
      "source": { "tableName": "region" },
      "target": {
        "tableName": "region",
        "icebergConfig": { "catalogTableName": "iceberg_tpch.region" }
      }
    },
    {
      "source": { "tableName": "nation" },
      "target": {
        "tableName": "nation",
        "icebergConfig": { "catalogTableName": "iceberg_tpch.nation" }
      }
    }
  ]
}
```

**Generated DDL** (per table):

```sql
CREATE OR REPLACE ICEBERG TABLE TARGET_DB.PUBLIC.region
  CATALOG = 'my_glue_catalog_integration'
  CATALOG_TABLE_NAME = 'iceberg_tpch.region'
  EXTERNAL_VOLUME = 'my_iceberg_ext_vol'
```

**What happens**: Each table in the `tables` array inherits `tableType` and `icebergConfig` from `defaultTableConfiguration`, and overrides `catalogTableName` at the table level. Since `catalog` is not `"SNOWFLAKE"`, the strategy auto-detects to `catalog_link`.

### Example 2: Convert to Managed (Zero-Copy, Full DML)

This starts as a catalog link, then converts the table so Snowflake manages the metadata and enables full DML (INSERT, UPDATE, DELETE, MERGE).

```json
{
  "defaultTableConfiguration": {
    "source": {
      "schemaName": "iceberg_tpch",
      "databaseName": "ecommerce_db"
    },
    "target": {
      "schemaName": "public",
      "databaseName": "TARGET_DB",
      "tableType": "iceberg",
      "icebergConfig": {
        "catalog": "my_glue_catalog_integration",
        "externalVolume": "my_iceberg_ext_vol"
      }
    }
  },
  "tables": [
    {
      "source": { "tableName": "orders" },
      "target": {
        "tableName": "orders",
        "icebergConfig": {
          "catalogTableName": "iceberg_tpch.orders",
          "migrationStrategy": "convert_to_managed"
        }
      }
    }
  ]
}
```

**Generated DDL**:

```sql
-- Step 1: Create catalog-linked table
CREATE OR REPLACE ICEBERG TABLE TARGET_DB.PUBLIC.orders
  CATALOG = 'my_glue_catalog_integration'
  CATALOG_TABLE_NAME = 'iceberg_tpch.orders'
  EXTERNAL_VOLUME = 'my_iceberg_ext_vol'

-- Step 2: Convert to Snowflake-managed
ALTER ICEBERG TABLE TARGET_DB.PUBLIC.orders CONVERT TO MANAGED
```

**Important**: You must explicitly set `"migrationStrategy": "convert_to_managed"` because auto-detection for external catalogs defaults to `catalog_link`.

### Example 3: Copy Files (Server-Side Binary Copy)

This creates a new Snowflake-managed Iceberg table and performs a server-side binary copy of Parquet files from a specified stage.

```json
{
  "defaultTableConfiguration": {
    "source": {
      "schemaName": "public",
      "databaseName": "analytics_db"
    },
    "target": {
      "schemaName": "public",
      "databaseName": "TARGET_DB",
      "tableType": "iceberg",
      "icebergConfig": {
        "catalog": "SNOWFLAKE",
        "externalVolume": "my_iceberg_ext_vol",
        "baseLocationPrefix": "migrations/redshift",
        "sourceDataStage": "@TARGET_DB.PUBLIC.ICEBERG_SOURCE_STAGE"
      }
    },
    "extraction": {
      "strategy": "unload",
      "externalStage": "TARGET_DB.PUBLIC.S3_EXTERNAL_STAGE"
    },
    "partitionSize": "auto"
  },
  "tables": [
    {
      "source": { "tableName": "customers" },
      "target": { "tableName": "customers" }
    }
  ]
}
```

**Generated DDL and DML**:

```sql
-- Step 1: Infer schema from Parquet files
SELECT * FROM TABLE(
  INFER_SCHEMA(
    LOCATION => '@TARGET_DB.PUBLIC.ICEBERG_SOURCE_STAGE',
    FILE_FORMAT => 'PARQUET'
  )
);

-- Step 2: Create the Iceberg table
CREATE ICEBERG TABLE TARGET_DB.PUBLIC.customers (col1 NUMBER(38,0), col2 VARCHAR, ...)
  CATALOG = 'SNOWFLAKE'
  EXTERNAL_VOLUME = 'my_iceberg_ext_vol'
  BASE_LOCATION = 'migrations/redshift/TARGET_DB/PUBLIC/customers'

-- Step 3: Binary copy of Parquet files
COPY INTO TARGET_DB.PUBLIC.customers
  FROM '@TARGET_DB.PUBLIC.ICEBERG_SOURCE_STAGE'
  LOAD_MODE = ADD_FILES_COPY
  MATCH_BY_COLUMN_NAME = CASE_INSENSITIVE
  PATTERN = '.*\.parquet'
```

**Key behavior**:
- Schema is inferred from the Parquet files using `INFER_SCHEMA` -- no Data Exchange Agent is needed
- `LOAD_MODE = ADD_FILES_COPY` performs a server-side binary copy (files are not re-read or re-serialized)
- `BASE_LOCATION` is derived from `baseLocationPrefix` + the fully qualified target table name (dots replaced with slashes)
- When `baseLocationPrefix` is not set, `BASE_LOCATION` defaults to the target table name path (e.g., `TARGET_DB/PUBLIC/customers`)

### Example 4: Mixed Strategies in a Single Workflow

A single workflow can mix strategies across tables. Default `icebergConfig` values are inherited and can be overridden per table:

```json
{
  "defaultTableConfiguration": {
    "source": {
      "schemaName": "public",
      "databaseName": "analytics_db"
    },
    "target": {
      "schemaName": "public",
      "databaseName": "TARGET_DB",
      "tableType": "iceberg",
      "icebergConfig": {
        "catalog": "SNOWFLAKE",
        "externalVolume": "my_iceberg_ext_vol",
        "baseLocationPrefix": "migrations/redshift",
        "sourceDataStage": "@TARGET_DB.PUBLIC.ICEBERG_SOURCE_STAGE"
      }
    },
    "partitionSize": "auto"
  },
  "tables": [
    {
      "source": { "tableName": "customers" },
      "target": { "tableName": "customers" },
      "columnNamesToPartitionBy": ["customer_id"]
    },
    {
      "source": { "tableName": "events" },
      "target": {
        "tableName": "events",
        "tableType": "iceberg",
        "icebergConfig": {
          "catalog": "my_glue_catalog_integration",
          "externalVolume": "my_iceberg_ext_vol",
          "catalogTableName": "glue_db.events"
        }
      }
    },
    {
      "source": { "tableName": "orders" },
      "target": {
        "tableName": "orders",
        "tableType": "iceberg",
        "icebergConfig": {
          "catalog": "my_glue_catalog_integration",
          "externalVolume": "my_iceberg_ext_vol",
          "catalogTableName": "glue_db.orders",
          "migrationStrategy": "convert_to_managed"
        }
      }
    }
  ]
}
```

In this workflow:
- **`customers`**: Uses default `icebergConfig` with `catalog=SNOWFLAKE` -> auto-detects to `copy_files`
- **`events`**: Overrides to an external catalog -> auto-detects to `catalog_link` (read-only)
- **`orders`**: Overrides to an external catalog with explicit `convert_to_managed` strategy

---

## Important Considerations and Nuances

### Configuration Inheritance and Merging

The `icebergConfig` at the table level is **merged** with the `defaultTableConfiguration.target.icebergConfig`. Table-level keys override default keys. This means you can set common values (like `externalVolume`) in the defaults and only specify per-table values (like `catalogTableName`) on each table entry.

### BASE_LOCATION Uniqueness

For Snowflake-managed Iceberg tables (`catalog='SNOWFLAKE'`), each table **must** have a unique `BASE_LOCATION` to avoid data file collisions. The orchestrator derives this automatically:

- With `baseLocationPrefix`: `{prefix}/{database}/{schema}/{table}`
- Without `baseLocationPrefix`: `{database}/{schema}/{table}`

You do not need to set `BASE_LOCATION` manually; the orchestrator computes it from the target table's fully qualified name.

### Iceberg Data Type Restrictions

Snowflake-managed Iceberg tables support a restricted set of data types compared to native Snowflake tables. The following types are **not supported** in Iceberg tables:

- `VARIANT`
- `OBJECT`
- `ARRAY`
- `GEOGRAPHY`
- `GEOMETRY`

Source columns with these types must be mapped to `STRING` (or `VARCHAR`) using `columnTypeMappings` in the workflow configuration:

```json
{
  "columnTypeMappings": {
    "SUPER": "VARCHAR",
    "GEOMETRY": "VARCHAR"
  }
}
```

### Supported Iceberg Column Types

| Type | Notes |
|---|---|
| `BOOLEAN` | |
| `INT` | 32-bit integer |
| `LONG` | 64-bit integer |
| `FLOAT` | Single precision |
| `DOUBLE` | Double precision |
| `DECIMAL(p,s)` | Exact numeric |
| `DATE` | Date only |
| `TIME` | Time only |
| `TIMESTAMP_NTZ` | Timestamp without timezone |
| `TIMESTAMP_LTZ` | Timestamp with timezone |
| `STRING` / `VARCHAR` | Variable-length text |
| `BINARY` | Variable-length binary |
| `FIXED(n)` | Fixed-length binary |

### INFER_SCHEMA and Type Handling

When using the `copy_files` strategy with `sourceDataStage`, the schema is inferred from Parquet files using Snowflake's `INFER_SCHEMA` function. The returned types are already Snowflake-native (e.g., `NUMBER(38,0)`, `VARCHAR(16777216)`) and are used directly in the `CREATE ICEBERG TABLE` DDL without any type mapping transformation.

### COPY INTO Behavior for Iceberg Tables

For the `copy_files` strategy, `COPY INTO` uses the following settings:

- `LOAD_MODE = ADD_FILES_COPY`: Performs a server-side binary copy. Parquet files are registered in the Iceberg metadata without being re-read or re-serialized, making this significantly faster than a full ingest.
- `MATCH_BY_COLUMN_NAME = CASE_INSENSITIVE`: Columns are matched by name rather than position, accommodating case differences.
- `PATTERN = '.*\.parquet'`: Only Parquet files are processed.

`ADD_FILES_COPY` is **only supported** for Snowflake-managed Iceberg tables (`catalog='SNOWFLAKE'`). Attempting to use it with an external catalog will fail.

### convert_to_managed Implications

After running `ALTER ICEBERG TABLE ... CONVERT TO MANAGED`:

- Snowflake takes ownership of the table's metadata files.
- The table becomes writable (full DML support).
- The external catalog (e.g., Glue) will **no longer reflect changes** made to the table in Snowflake, unless you also configure `CATALOG_SYNC`.
- The underlying Parquet data files remain in place -- no data is moved or rewritten.
- This operation is **irreversible**: once converted to managed, the table cannot be reverted to externally managed.

### catalog_link Limitations

Catalog-linked Iceberg tables are **read-only** by default. This means:
- `INSERT`, `UPDATE`, `DELETE`, and `MERGE` are not supported.
- `COPY INTO` is not supported.
- The table reflects the state of the external catalog; changes in Glue are visible in Snowflake (with metadata refresh).

If you need DML support, use `convert_to_managed` or `copy_files` instead.

### Data Exchange Agent Involvement

The Data Exchange Agent (DEA) is **not used** for the following Iceberg strategies:
- `catalog_link` -- pure DDL, no data extraction
- `convert_to_managed` -- pure DDL, no data extraction
- `copy_files` with `sourceDataStage` -- schema is inferred from Parquet; data is copied server-side

The DEA **is used** only for `copy_files` without `sourceDataStage`, where it performs schema extraction from the source database (using `SVV_EXTERNAL_COLUMNS` for Redshift external tables, or `information_schema.columns` for native tables).

### Partitioning and Incremental Sync

Iceberg migration workflows **do not go through** the standard partitioning pipeline (metadata extraction -> boundary analysis -> partition creation). The Iceberg task chain is a separate code path that bypasses partition-based extraction entirely.

As a result:
- `columnNamesToPartitionBy` is not used during the Iceberg loading phase (though it may still be present in the configuration for source-side extraction if combining strategies).
- Incremental sync (`synchronization` settings) does not apply to Iceberg migrations -- each execution performs the full operation for the given strategy.

### catalog_sync for Dual-Engine Access

If you need the Snowflake-managed Iceberg table to remain accessible from other engines (Spark, Trino, Redshift) via the Glue catalog, add `catalogSync`:

```json
{
  "icebergConfig": {
    "catalog": "SNOWFLAKE",
    "externalVolume": "my_ext_vol",
    "baseLocationPrefix": "migrations",
    "catalogSync": "my_glue_catalog_integration"
  }
}
```

This generates:

```sql
CREATE ICEBERG TABLE ... CATALOG_SYNC = 'my_glue_catalog_integration'
```

Snowflake will automatically register table metadata updates in the Glue catalog.

---

## Data Type Mapping Reference

### Redshift Native -> Snowflake Iceberg

| Redshift Native Type | Parquet Type (UNLOAD) | Snowflake Iceberg Type |
|---|---|---|
| `SMALLINT` | `INT32` | `INT` |
| `INTEGER` | `INT32` | `INT` |
| `BIGINT` | `INT64` | `LONG` |
| `DECIMAL(p,s)` | `FIXED_LEN_BYTE_ARRAY` | `DECIMAL(p,s)` |
| `REAL` | `FLOAT` | `FLOAT` |
| `DOUBLE PRECISION` | `DOUBLE` | `DOUBLE` |
| `BOOLEAN` | `BOOLEAN` | `BOOLEAN` |
| `CHAR(n)` | `BYTE_ARRAY (UTF8)` | `STRING` |
| `VARCHAR(n)` | `BYTE_ARRAY (UTF8)` | `STRING` |
| `DATE` | `INT32 (DATE)` | `DATE` |
| `TIMESTAMP` | `INT96` or `INT64` | `TIMESTAMP_NTZ` |
| `TIMESTAMPTZ` | `INT96` or `INT64` | `TIMESTAMP_LTZ` |
| `TIME` | N/A (cast to VARCHAR) | `STRING` |
| `VARBYTE` | N/A (cast via TO_HEX) | `STRING` |
| `GEOMETRY` | N/A (cast via ST_AsText) | `STRING` |
| `SUPER` | `BYTE_ARRAY (UTF8)` | `STRING` |

### Redshift Iceberg (Glue) -> Snowflake Iceberg

| Glue/Iceberg Type | Snowflake Iceberg Type | Notes |
|---|---|---|
| `boolean` | `BOOLEAN` | |
| `int` | `NUMBER(10,0)` | 32-bit integer |
| `bigint` / `long` | `NUMBER(19,0)` | 64-bit integer |
| `float` | `FLOAT` | |
| `double` | `DOUBLE` | |
| `decimal(p,s)` | `DECIMAL(p,s)` | |
| `string` | `VARCHAR` | |
| `binary` | `BINARY` | |
| `date` | `DATE` | |
| `timestamp` | `TIMESTAMP_NTZ` | |
| `timestamptz` | `TIMESTAMP_LTZ` | |
| `list<T>` | Not supported | Flatten or convert to `VARCHAR` (JSON) |
| `map<K,V>` | Not supported | Convert to `VARCHAR` (JSON) |
| `struct<...>` | Not supported | Convert to `VARCHAR` (JSON) |

---

## Troubleshooting

### 1. "Invalid migration_strategy" Error

**Symptom**: `ValueError: Invalid migration_strategy 'xxx'. Valid options: catalog_link, convert_to_managed, copy_files`

**Cause**: The `migrationStrategy` field contains an unsupported value.

**Solution**: Set `migrationStrategy` to one of: `catalog_link`, `convert_to_managed`, `copy_files`. Or omit it entirely to enable auto-detection.

### 2. "External volume does not exist" Error

**Symptom**: `CREATE ICEBERG TABLE` fails with "External volume 'XXX' does not exist"

**Cause**: The external volume has not been created in the Snowflake account, or the role executing the migration does not have `USAGE` privileges on it.

**Solution**:
1. Create the external volume (see [Prerequisites](#1-external-volume) above)
2. Grant `USAGE` to the migration role:

```sql
GRANT USAGE ON EXTERNAL VOLUME my_iceberg_ext_vol TO ROLE migration_role;
```

### 3. "Catalog integration not found" Error

**Symptom**: `CREATE ICEBERG TABLE` fails with "Catalog 'my_glue_integration' does not exist"

**Cause**: The catalog integration has not been created, or the role lacks `USAGE` privileges.

**Solution**:
1. Create the catalog integration (see [Prerequisites](#2-catalog-integration-required-for-catalog_link-and-convert_to_managed) above)
2. Grant `USAGE` to the migration role:

```sql
GRANT USAGE ON INTEGRATION my_glue_catalog_integration TO ROLE migration_role;
```

### 4. Schema Inference Fails (No Files Found)

**Symptom**: `INFER_SCHEMA` returns no results; `TableNotFoundError` during `copy_files` strategy

**Cause**: The `sourceDataStage` path does not contain any Parquet files, or the stage is misconfigured.

**Solution**:
1. Verify files exist at the stage:

```sql
LIST @TARGET_DB.PUBLIC.ICEBERG_SOURCE_STAGE;
```

2. Ensure the stage URL points to the correct S3 prefix
3. Check that the storage integration has read access to the S3 path

### 5. LOAD_MODE = ADD_FILES_COPY Fails

**Symptom**: `COPY INTO ... LOAD_MODE = ADD_FILES_COPY` returns an error

**Cause**: `ADD_FILES_COPY` is only supported for Snowflake-managed Iceberg tables (`catalog='SNOWFLAKE'`).

**Solution**:
- Verify `catalog` is set to `"SNOWFLAKE"` in `icebergConfig`
- If using an external catalog, use `catalog_link` or `convert_to_managed` instead

### 6. Auto-Detection Picks Wrong Strategy

**Symptom**: The orchestrator selects `catalog_link` but you wanted `convert_to_managed`, or selects `copy_files` but you wanted `catalog_link`

**Cause**: Auto-detection is based solely on the `catalog` value. External catalog defaults to `catalog_link`; `"SNOWFLAKE"` defaults to `copy_files`.

**Solution**: Explicitly set `migrationStrategy`:

```json
{
  "icebergConfig": {
    "catalog": "my_glue_integration",
    "externalVolume": "vol",
    "catalogTableName": "glue_db.my_table",
    "migrationStrategy": "convert_to_managed"
  }
}
```

### 7. Type Conversion Errors During COPY INTO

**Symptom**: COPY INTO fails with type mismatch errors

**Cause**: Source column types are not compatible with Iceberg column types (e.g., `SUPER`, `VARIANT`, `ARRAY`).

**Solution**:
- Use `columnTypeMappings` to override incompatible types:

```json
{
  "columnTypeMappings": {
    "SUPER": "VARCHAR",
    "GEOMETRY": "VARCHAR",
    "VARIANT": "VARCHAR"
  }
}
```

- For `copy_files` with `sourceDataStage`, schema is inferred from Parquet and types are already Snowflake-native -- type mapping overrides do not apply in this path

### 8. IAM Trust Policy Not Working

**Symptom**: External volume or catalog integration creation succeeds, but operations fail with "Access Denied" or "AssumeRole" errors

**Cause**: The IAM trust policy does not include the Snowflake-generated IAM user ARN and external ID.

**Solution**:
1. Run `DESCRIBE EXTERNAL VOLUME <name>` or `DESCRIBE CATALOG INTEGRATION <name>`
2. Copy the `STORAGE_AWS_IAM_USER_ARN` and `STORAGE_AWS_EXTERNAL_ID` values
3. Update the IAM trust policy (see [Prerequisites](#iam-trust-policy-for-the-external-volume-role) above)
4. Wait a few minutes for IAM propagation

### Debug Checklist

When troubleshooting Iceberg migrations, work through these steps:

1. **Validate prerequisites**:
   - [ ] External volume exists: `DESCRIBE EXTERNAL VOLUME <name>`
   - [ ] Catalog integration exists (if applicable): `DESCRIBE CATALOG INTEGRATION <name>`
   - [ ] IAM trust policies include Snowflake's IAM user and external ID
   - [ ] Source data stage contains Parquet files: `LIST @<stage_name>`
   - [ ] Migration role has all required privileges

2. **Check workflow configuration**:
   - [ ] `tableType` is set to `"iceberg"` in the target
   - [ ] `icebergConfig` is present with required fields for the chosen strategy
   - [ ] `migrationStrategy` is valid or omitted for auto-detection
   - [ ] `sourceDataStage` starts with `@` (if specified)

3. **Review orchestrator logs**:
   - Look for `Iceberg [<strategy>]: created ...` log messages confirming task creation
   - Check for `ConfigurationError` at workflow initialization
   - Verify the resolved strategy matches your intent

4. **Test Snowflake objects independently**:
   - Manually run the `CREATE ICEBERG TABLE` DDL to isolate DDL errors from orchestrator issues
   - Test `INFER_SCHEMA` on the source data stage: `SELECT * FROM TABLE(INFER_SCHEMA(LOCATION => '@stage', FILE_FORMAT => 'PARQUET'))`
   - Test `COPY INTO` with a small sample to verify file access and type compatibility

5. **Common log patterns**:
   - `"Iceberg copy_files strategy auto-selected without sourceDataStage"` -- the orchestrator is falling back to DEA extraction. Set `sourceDataStage` to avoid this.
   - `"Failed to insert table metadata"` -- check Snowflake connectivity and permissions for the `TABLE_METADATA` stored procedure.
