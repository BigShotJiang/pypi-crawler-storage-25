# Cloud Data Validation Workflow (engineering notes)

## CLI and Hatch scripts

- **Python:** `python -m data_migration_orchestrator create-data-validation-workflow <config.json> --source-platform <platform> [--name ...] [--connection-name ...]`
- **Hatch (from `data-migration-orchestrator/`):** `hatch run create-validation-workflow -- <config.json> --source-platform <platform> [extra args]`

Pass `--source-platform` on every invocation; its value must match `source_platform` in the JSON (the field remains required in the file for validation).

## Code map

| Area | Location |
|------|----------|
| CLI | `src/data_migration_orchestrator/commands/create_data_validation_workflow.py` |
| JSON schema (structural) | `data_validation_cloud/config/workflow_configuration_schema.py` |
| Parsed config / defaults | `data_validation_cloud/config/validation_configuration_parser.py` |
| Workflow initialization | `data_validation_cloud/data_validation_workflow_initializer.py` |
| Worker execution | `data-exchange-agent` — `tasks/data_validation/` (dispatched from `tasks/manager.py` for `data_validation` tasks) |

## Dependencies

- Orchestrator packages include validation modules in-repo.
- Workers need **`snowflake-data-validation`** installed to run validation tasks (row/cell/schema/metrics), in addition to source ODBC drivers as appropriate.

## Metadata layout

- Workflow rows for validation use `WORKFLOW_TYPE = 'data-validation'` in the **data migration** metadata schema (default `SNOWCONVERT_AI.DATA_MIGRATION`), same `WORKFLOW` table as migrations.
- Result tables and validation-specific objects live under the **data validation** schema (default `SNOWCONVERT_AI.DATA_VALIDATION`), controlled by `CUSTOM_SNOWFLAKE_SCHEMA_FOR_DATA_VALIDATION_METADATA`.

## User-facing reference

The public **README.md** documents the JSON fields and defaults. A minimal example file lives at `docs/public/example-workflows/example-data-validation-workflow.json`.
