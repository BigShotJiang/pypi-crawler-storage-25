"""AFS MCP server — colony-based exploration tools."""

from .server import mcp
