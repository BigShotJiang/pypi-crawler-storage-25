"""CLI entry point for the AFS MCP server."""

from .server import mcp


def main():
    mcp.run()


if __name__ == "__main__":
    main()
