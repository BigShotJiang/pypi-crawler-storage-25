"""Concept — An attractor in the N-dimensional field."""

import numpy as np
from typing import Optional

_concept_counter = 0


class Concept:
    """
    A concept (attractor) in the AFS field.

    Concepts have positions in N-dimensional space and exert gravitational
    pull on nearby cells. Their positions shift based on cell density
    (concept dynamics).
    """

    __slots__ = (
        "id", "name", "position", "velocity", "mass",
        "prompt_resonance", "energy",
    )

    def __init__(self, name: str, n_dims: int,
                 position: Optional[np.ndarray] = None,
                 concept_id: Optional[str] = None):
        global _concept_counter
        _concept_counter += 1
        self.id = concept_id or f"concept_{_concept_counter}"
        self.name = name
        self.position = position if position is not None else np.random.uniform(0.2, 0.8, n_dims)
        self.velocity = np.zeros(n_dims, dtype=np.float64)
        self.mass = 10.0
        self.prompt_resonance = 0.5
        self.energy = 0.0  # accumulated from nearby cells
