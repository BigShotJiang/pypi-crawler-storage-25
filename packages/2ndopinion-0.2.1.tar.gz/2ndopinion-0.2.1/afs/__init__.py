"""AFS Engine — Atomata Field System colony exploration."""
__version__ = "0.2.1"
