"""AFS GPU acceleration — WGSL compute shaders via wgpu."""

from .wgpu_force_kernel import WgpuForceKernel, gpu_available
