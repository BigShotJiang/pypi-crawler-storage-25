// Position update — integrates forces into velocity and position.
//
// Combines: similarity matrix forces + concept gravity forces + thermal noise + boundary forces.
// Then applies momentum damping, speed clamping, position integration, and boundary reflection.
//
// Matches Python engine lines 198-238:
//   1. Add thermal noise + boundary forces to the combined force inputs
//   2. velocity = velocity * momentum + total_force * dt_norm
//   3. Clamp velocity to [-max_speed, max_speed]
//   4. position += velocity * dt_norm
//   5. Reflect velocity at boundaries, clamp position to [0, 1]
//
// One thread per cell.

struct Params {
    num_cells: u32,
    num_dims: u32,
    _pad0: u32,
    _pad1: u32,
    dt_norm: f32,
    momentum: f32,
    max_speed: f32,
    boundary_margin: f32,
    boundary_strength: f32,
    thermal_noise: f32,
    noise_seed: f32,
    _pad2: f32,
}

@group(0) @binding(0) var<uniform> params: Params;
@group(0) @binding(1) var<storage, read> matrix_forces: array<f32>;   // (C * D) from similarity shader
@group(0) @binding(2) var<storage, read> gravity_forces: array<f32>;  // (C * D) from gravity shader
@group(0) @binding(3) var<storage, read_write> velocities: array<f32>; // (C * D) read + write
@group(0) @binding(4) var<storage, read_write> positions: array<f32>;  // (C * D) read + write

// Simple hash-based noise — deterministic per cell/dim/seed
fn hash_noise(cell: u32, dim: u32, seed: f32) -> f32 {
    let h = cell * 374761393u + dim * 668265263u + bitcast<u32>(seed);
    let h2 = (h ^ (h >> 13u)) * 1274126177u;
    let h3 = h2 ^ (h2 >> 16u);
    // Map to [-1, 1]
    return f32(h3 & 0x00FFFFFFu) / f32(0x00FFFFFFu) * 2.0 - 1.0;
}

@compute @workgroup_size(64)
fn main(@builtin(global_invocation_id) id: vec3<u32>) {
    let cell = id.x;
    if (cell >= params.num_cells) { return; }

    let D = params.num_dims;
    let cell_offset = cell * D;
    let epsilon: f32 = 1e-6;

    for (var d = 0u; d < D; d++) {
        let idx = cell_offset + d;
        let pos = positions[idx];
        let vel = velocities[idx];

        // 1. Thermal noise
        let noise = hash_noise(cell, d, params.noise_seed) * params.thermal_noise;

        // 2. Boundary forces (soft repulsion)
        var boundary: f32 = 0.0;
        let margin = params.boundary_margin;
        if (pos < margin) {
            boundary = params.boundary_strength * (margin - pos) / (margin + epsilon);
        } else if (pos > 1.0 - margin) {
            boundary = -params.boundary_strength * (pos - (1.0 - margin)) / (margin + epsilon);
        }

        // 3. Total force
        let total_force = matrix_forces[idx] + gravity_forces[idx] + noise + boundary;

        // 4. Velocity integration with momentum damping
        var new_vel = vel * params.momentum + total_force * params.dt_norm;

        // 5. Speed clamping
        new_vel = clamp(new_vel, -params.max_speed, params.max_speed);

        // 6. Position integration
        var new_pos = pos + new_vel * params.dt_norm;

        // 7. Boundary reflection
        if (new_pos < 0.0) {
            new_vel = abs(new_vel) * 0.5;
            new_pos = clamp(new_pos, 0.0, 1.0);
        } else if (new_pos > 1.0) {
            new_vel = -abs(new_vel) * 0.5;
            new_pos = clamp(new_pos, 0.0, 1.0);
        }

        velocities[idx] = new_vel;
        positions[idx] = new_pos;
    }
}
