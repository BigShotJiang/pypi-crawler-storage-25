// Similarity matrix forces — couples velocity in dimension i to force in dimension j.
//
// Physics: force[cell, j] = sum_i(velocity[cell, i] * matrix[i, j]) * force_scale
// Negative matrix entries create trade-off dynamics (movement toward one concept
// pushes away from another). This is the core mechanism that drives colony differentiation.
//
// One thread per cell. Loops over D×D matrix entries.
// Buffers are flat arrays — 2D indexing via stride.

struct Params {
    num_cells: u32,
    num_dims: u32,
    force_scale: f32,
    tradeoff_amplifier: f32,
}

@group(0) @binding(0) var<uniform> params: Params;
@group(0) @binding(1) var<storage, read> velocities: array<f32>;       // (C * D) row-major
@group(0) @binding(2) var<storage, read> similarity_matrix: array<f32>; // (D * D) row-major
@group(0) @binding(3) var<storage, read_write> forces: array<f32>;      // (C * D) row-major

@compute @workgroup_size(64)
fn main(@builtin(global_invocation_id) id: vec3<u32>) {
    let cell = id.x;
    if (cell >= params.num_cells) { return; }

    let D = params.num_dims;
    let cell_offset = cell * D;

    // force[j] = sum_i(velocity[i] * matrix[i][j]) * force_scale
    // With tradeoff amplification on negative matrix entries
    for (var j = 0u; j < D; j++) {
        var f: f32 = 0.0;
        for (var i = 0u; i < D; i++) {
            if (i == j) { continue; }
            var sim = similarity_matrix[i * D + j];
            if (sim < 0.0) {
                sim *= params.tradeoff_amplifier;
            }
            f += velocities[cell_offset + i] * sim;
        }
        forces[cell_offset + j] = f * params.force_scale;
    }
}
