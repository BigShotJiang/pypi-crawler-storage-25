// Concept gravity — cells are attracted to concept positions (attractor basins).
//
// Physics: for each concept k in range of cell c:
//   delta = concept_pos[k] - cell_pos[c]
//   dist = length(delta)
//   magnitude = strength * dist / (softening² + dist² * sharpness) * dt_norm
//   force += normalize(delta) * magnitude
//
// This creates basins that rise near concepts, peak at moderate distance,
// and fall to zero AT the concept — preventing oscillation.
//
// One thread per cell. Loops over K concepts.

struct Params {
    num_cells: u32,
    num_concepts: u32,
    num_dims: u32,
    _pad0: u32,
    gravity_strength: f32,
    gravity_sharpness: f32,
    gravity_range: f32,
    softening: f32,
    dt_norm: f32,
    _pad1: f32,
    _pad2: f32,
    _pad3: f32,
}

@group(0) @binding(0) var<uniform> params: Params;
@group(0) @binding(1) var<storage, read> cell_positions: array<f32>;     // (C * D)
@group(0) @binding(2) var<storage, read> concept_positions: array<f32>;  // (K * D)
@group(0) @binding(3) var<storage, read_write> forces: array<f32>;       // (C * D)

@compute @workgroup_size(64)
fn main(@builtin(global_invocation_id) id: vec3<u32>) {
    let cell = id.x;
    if (cell >= params.num_cells) { return; }

    let D = params.num_dims;
    let K = params.num_concepts;
    let cell_offset = cell * D;

    // Zero this cell's output slice before accumulating.
    // Eliminates the CPU-side write_buffer zero pass — this thread owns these
    // locations exclusively, so a sequential write here is safe.
    for (var d = 0u; d < D; d++) {
        forces[cell_offset + d] = 0.0;
    }

    // Accumulate gravity forces from all concepts
    for (var k = 0u; k < K; k++) {
        let concept_offset = k * D;

        // Compute delta and distance
        var dist_sq: f32 = 0.0;
        for (var d = 0u; d < D; d++) {
            let delta = concept_positions[concept_offset + d] - cell_positions[cell_offset + d];
            dist_sq += delta * delta;
        }
        let dist = sqrt(dist_sq);

        // Skip if out of range or too close
        if (dist >= params.gravity_range || dist < 0.001) { continue; }

        // Gravity magnitude: strength * dist / (softening² + dist² * sharpness) * dt_norm
        let soft_sq = params.softening * params.softening;
        let magnitude = params.gravity_strength * dist
            / (soft_sq + dist_sq * params.gravity_sharpness)
            * params.dt_norm;

        // Apply force in direction of concept (normalized delta * magnitude)
        let inv_dist = 1.0 / max(dist, 1e-6);
        for (var d = 0u; d < D; d++) {
            let delta = concept_positions[concept_offset + d] - cell_positions[cell_offset + d];
            forces[cell_offset + d] += delta * inv_dist * magnitude;
        }
    }
}
