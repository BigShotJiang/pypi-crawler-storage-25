from distutils.core import setup
from setuptools import find_packages

with open('README.rst', 'r', encoding="utf-8") as f:
    long_description = f.read()

setup(name='fast_mq_task',
      version='2.0.17',
      description='Fast RabbitMQ task management library for asynchronous message handling',
      long_description=long_description,
      long_description_content_type='text/x-rst',
      author='zsodata',
      author_email='team@zso.io',
      url='https://github.com/zsodata/fast-mq-task',
      install_requires=[
          'aio-pika>=9.0.0,<10.0.0',
          'pydantic>=2.0.0,<3.0.0',
          'tenacity>=8.0.0,<10.0.0',
      ],
      python_requires='>=3.7',
      license='BSD License',
      packages=find_packages(),
      platforms=['all'],
      include_package_data=True,
      classifiers=[
          'Development Status :: 5 - Production/Stable',
          'Intended Audience :: Developers',
          'License :: OSI Approved :: BSD License',
          'Operating System :: OS Independent',
          'Programming Language :: Python :: 3',
          'Programming Language :: Python :: 3.7',
          'Programming Language :: Python :: 3.8',
          'Programming Language :: Python :: 3.9',
          'Programming Language :: Python :: 3.10',
          'Programming Language :: Python :: 3.11',
          'Topic :: Software Development :: Libraries :: Python Modules',
      ],
      keywords='rabbitmq mq messaging task queue async aio-pika',
      )
