# -*- coding: utf-8 -*-
"""
RabbitMQ 客户端基础模块
提供连接管理、信道、交换机和队列的生命周期管理

优化点：
- 连接池和信道池管理
- 性能监控指标
- 智能资源复用
- 配置验证
"""
import logging
import os
import time
from typing import Dict, Optional, Any
from dataclasses import dataclass, field
from collections import defaultdict
import asyncio
from functools import wraps

import aio_pika
from aio_pika import ExchangeType, Channel
from aio_pika.abc import AbstractExchange, AbstractQueue
from aiormq import ConnectionClosed, ChannelClosed, AMQPConnectionError
from tenacity import retry, retry_if_exception_type, wait_exponential, stop_after_attempt, retry_any

from .keys import RabbitKeys

# 遵循 Python 库的日志最佳实践：
# - 不调用 basicConfig，避免污染第三方系统的日志配置
# - 添加 NullHandler 避免 "No handler found" 警告
# - 由使用方（应用层）配置日志级别、格式和输出方式
LOGGER = logging.getLogger('MQT客户端')
# 添加 NullHandler 以避免没有配置 handler 时的警告
if not LOGGER.handlers:
    LOGGER.addHandler(logging.NullHandler())


@dataclass
class ChannelInfo:
    """信道信息"""
    channel: Channel
    task_type: str
    prefetch: int
    created_at: float = field(default_factory=time.time)
    last_used: float = field(default_factory=time.time)
    usage_count: int = 0


@dataclass
class MetricsData:
    """性能指标数据结构"""
    latency_sum: float = 0.0
    latency_count: int = 0
    latency_min: float = float('inf')
    latency_max: float = 0.0
    throughput_count: int = 0
    error_count: int = 0
    last_updated: float = field(default_factory=time.time)

    def record_latency(self, latency: float):
        """记录延迟"""
        self.latency_sum += latency
        self.latency_count += 1
        self.latency_min = min(self.latency_min, latency)
        self.latency_max = max(self.latency_max, latency)
        self.last_updated = time.time()

    def record_throughput(self):
        """记录吞吐量"""
        self.throughput_count += 1
        self.last_updated = time.time()

    def record_error(self):
        """记录错误"""
        self.error_count += 1
        self.last_updated = time.time()

    @property
    def avg_latency(self) -> float:
        """平均延迟（秒）"""
        return self.latency_sum / self.latency_count if self.latency_count > 0 else 0.0

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            'avg_latency_ms': round(self.avg_latency * 1000, 2),
            'min_latency_ms': round(self.latency_min * 1000, 2) if self.latency_min != float('inf') else 0,
            'max_latency_ms': round(self.latency_max * 1000, 2),
            'throughput_count': self.throughput_count,
            'error_count': self.error_count,
            'sample_count': self.latency_count,
            'last_updated': self.last_updated,
        }


def track_performance(metric_name: str = 'operation'):
    """性能追踪装饰器 (兼容字典和对象形式的 metrics)"""

    def decorator(func):
        @wraps(func)
        async def wrapper(self, *args, **kwargs):
            start_time = time.time()
            try:
                result = await func(self, *args, **kwargs)
                # 记录成功指标 (兼容字典和对象形式)
                if hasattr(self, '_metrics'):
                    if isinstance(self._metrics, dict):
                        self._metrics[f'{metric_name}_success'].record_throughput()
                        latency = time.time() - start_time
                        self._metrics[f'{metric_name}_latency'].record_latency(latency)
                    # 如果是 ProducerMetrics 或 ConsumerMetrics 对象，由各自方法内部记录
                return result
            except Exception as e:
                # 记录错误指标
                if hasattr(self, '_metrics'):
                    if isinstance(self._metrics, dict):
                        self._metrics[f'{metric_name}_error'].record_error()
                    elif hasattr(self._metrics, 'record_error'):
                        self._metrics.record_error()
                raise

        return wrapper

    return decorator


class RabbitMQClient:
    """
    RabbitMQ 异步客户端基类

    提供连接管理、资源声明和清理功能，支持自动重连和资源复用

    优化特性：
    - 连接池和信道池管理
    - 性能监控指标
    - 智能资源复用

    Attributes:
        amqp_url: RabbitMQ 连接地址
        message_ttl: 消息存活时间（毫秒），默认 5 天
        max_executors: 最大线程池数量，防止资源泄漏
        max_channels: 最大信道数量，防止资源耗尽
    """

    MAX_EXECUTORS = 32  # 类级别常量，限制最大线程池数
    DEFAULT_MAX_CHANNELS = 64  # 默认最大信道数

    def __init__(
            self,
            amqp_url: str,
            message_ttl: Optional[int] = None,
            max_executors: int = 32,
            max_channels: Optional[int] = None,
            enable_metrics: bool = True,
            app_prefix: Optional[str] = None,
            series_prefix: Optional[str] = None,
    ):
        """
        初始化 RabbitMQ 客户端

        Args:
            amqp_url: RabbitMQ 连接地址，格式：amqp://user:pass@host:port/vhost
            message_ttl: 消息默认存活时间（毫秒），默认 5 天 (432000000ms)
            max_executors: 最大并发资源数，防止资源耗尽
            max_channels: 最大信道数量，默认 50
            enable_metrics: 是否启用性能指标，默认 True
            app_prefix: 应用前缀（可选），优先级高于环境变量
            series_prefix: 系列前缀（可选），优先级高于环境变量

        Note:
            前缀优先级机制：
            1. 构造函数直接传入的参数
            2. 环境变量 (MQT_APP_PREFIX, MQT_SERIES_PREFIX)
            3. 默认值 ('app', 'fast')
        """
        # 验证 AMQP URL 格式
        if not amqp_url or not amqp_url.startswith('amqp://'):
            raise ValueError(
                f"AMQP URL 格式错误，应为 amqp://user:pass@host:port/vhost，实际：{amqp_url}"
            )

        self.amqp_url = amqp_url
        self.message_ttl = (
            message_ttl
            if message_ttl is not None
            else 432000000
        )
        self.max_executors = max_executors
        self.max_channels = max_channels or self.DEFAULT_MAX_CHANNELS
        self.enable_metrics = enable_metrics

        # 初始化 Keys 实例（前缀管理）
        self.rabbit_keys = RabbitKeys(
            app_prefix=app_prefix,
            series_prefix=series_prefix
        )

        self.connection = None
        self._channels: Dict[str, ChannelInfo] = {}  # 使用 ChannelInfo 替代简单字典
        self._exchanges: Dict[str, AbstractExchange] = {}
        self._queues: Dict[str, AbstractQueue] = {}
        self._connection_count = 0
        self._channel_lock = asyncio.Lock()  # 信道创建锁
        self._metrics: Dict[str, MetricsData] = defaultdict(MetricsData)  # 性能指标

        # 验证配置
        self._validate_config()

    def _validate_config(self):
        """验证配置参数"""
        if self.max_channels < 1:
            raise ValueError(f"max_channels 必须大于 0，当前：{self.max_channels}")
        if self.max_executors < 1:
            raise ValueError(f"max_executors 必须大于 0，当前：{self.max_executors}")
        if self.message_ttl < 0:
            raise ValueError(f"message_ttl 必须非负，当前：{self.message_ttl}")

    @retry(
        retry=retry_any(
            retry_if_exception_type(ConnectionClosed),
            retry_if_exception_type(ConnectionError),
            retry_if_exception_type(ChannelClosed),
            retry_if_exception_type(AMQPConnectionError)
        ),
        wait=wait_exponential(multiplier=1, min=5, max=60),  # 指数退避：5s, 10s, 20s, 40s, 60s...
        stop=stop_after_attempt(10),
        reraise=True
    )
    async def connect(self):
        """
        建立 RabbitMQ 连接，支持自动重连

        使用指数退避策略重试连接，最多尝试 10 次

        Returns:
            self: 返回客户端实例

        Raises:
            AMQPConnectionError: 连接失败
        """
        if self.connection and not self.connection.is_closed:
            return self

        if self.connection and self.connection.is_closed:
            LOGGER.warning("链路已关闭清理旧资源")
            await self._cleanup_resources()

        try:
            self.connection = await aio_pika.connect_robust(
                self.amqp_url,
                timeout=10,
                heartbeat=60,  # 添加心跳机制，60 秒检测一次连接
                client_properties={"connection_name": f"fast-mq-task-{os.getpid()}"}
            )
            # 添加连接断开回调
            if hasattr(self.connection, 'add_close_callback'):
                self.connection.add_close_callback(self._on_connection_closed)
            self._connection_count += 1
            LOGGER.info(f"链路连接成功 count={self._connection_count}, channels={len(self._channels)}/{self.max_channels}")
            return self
        except Exception as e:
            LOGGER.error(f"链路连接异常 error={e.__class__.__name__}: {e}")
            raise

    def _on_connection_closed(self, connection, reason: str = "unknown"):
        """
        连接断开回调函数

        Args:
            connection: 连接对象
            reason: 断开原因
        """
        LOGGER.warning(f"连接已断开 reason={reason}")
        # 清理缓存的资源，触发重新连接
        self._exchanges.clear()
        self._queues.clear()

    async def _cleanup_resources(self):
        """清理所有缓存资源"""
        try:
            for channel_info in list(self._channels.values()):
                if not channel_info.channel.is_closed:
                    await channel_info.channel.close()
        except Exception as e:
            LOGGER.error(f"信道关闭异常 error={e.__class__.__name__}: {e}")

        try:
            if self.connection and not self.connection.is_closed:
                await self.connection.close()
        except Exception as e:
            LOGGER.error(f"连接关闭异常 error={e.__class__.__name__}: {e}")
        finally:
            self._exchanges.clear()
            self._queues.clear()
            self._channels.clear()

    async def close(self):
        """
        优雅关闭连接，释放所有资源

        按顺序关闭：信道 -> 连接 -> 清理字典
        """
        LOGGER.debug("链路关闭开始")
        try:
            for channel_info in list(self._channels.values()):
                try:
                    if not channel_info.channel.is_closed:
                        await channel_info.channel.close()
                except Exception as e:
                    LOGGER.error(f"链路关闭异常 task_type={channel_info.task_type}, error={e.__class__.__name__}: {e}")

            if self.connection and not self.connection.is_closed:
                await self.connection.close()

            LOGGER.info("链路关闭完成")
        except Exception as e:
            LOGGER.error(f"链路关闭异常 error={e.__class__.__name__}: {e}")
        finally:
            self._exchanges.clear()
            self._queues.clear()
            self._channels.clear()

    @track_performance('get_channel')
    async def get_channel(self, task_type: str, prefetch: int = 4) -> Channel:
        """
        获取或创建信道（智能复用）

        优化点：
        - 信道数量限制
        - LRU 淘汰策略
        - 使用统计追踪

        Args:
            task_type: 任务类型标识
            prefetch: 预取消息数量，控制消费者并发度

        Returns:
            Channel: 信道对象

        Raises:
            ResourceExhaustedError: 信道资源耗尽
        """
        if not self.connection or self.connection.is_closed:
            await self.connect()

        task_type = task_type or 'default'

        async with self._channel_lock:
            # 检查是否已存在
            if task_type in self._channels:
                channel_info = self._channels[task_type]
                channel_info.last_used = time.time()
                channel_info.usage_count += 1
                LOGGER.debug(f"信道复用 task_type={task_type}, usage_count={channel_info.usage_count}")
                return channel_info.channel

            # 检查信道数量上限
            if len(self._channels) >= self.max_channels:
                # LRU 淘汰：淘汰最久未使用的信道
                await self._evict_lru_channel()

            # 创建新信道
            channel = await self.connection.channel()
            await channel.set_qos(prefetch_count=prefetch)

            channel_info = ChannelInfo(
                channel=channel,
                task_type=task_type,
                prefetch=prefetch,
                usage_count=1
            )
            self._channels[task_type] = channel_info

            LOGGER.debug(f"信道创建成功 task_type={task_type}, prefetch={prefetch}, channels={len(self._channels)}/{self.max_channels}")
            return channel

    async def _evict_lru_channel(self):
        """
        淘汰最久未使用的信道（LRU）

        注意：只淘汰真正空闲的信道（使用次数为 0 或已关闭）
        """
        if not self._channels:
            return

        # 找到最久未使用且空闲的信道
        idle_channels = [
            (task_type, info)
            for task_type, info in self._channels.items()
            if info.usage_count == 0 or info.channel.is_closed
        ]

        if not idle_channels:
            # 如果没有空闲信道，警告但不淘汰
            LOGGER.warning(f"信道资源已达上限 max={self.max_channels}, 建议扩容")
            return

        # 淘汰最久未使用的空闲信道
        oldest_task_type, channel_info = min(
            idle_channels,
            key=lambda x: x[1].last_used
        )

        try:
            if not channel_info.channel.is_closed:
                await channel_info.channel.close()
            del self._channels[oldest_task_type]
            LOGGER.info(f"信道LRU淘汰 task_type={oldest_task_type}")
        except Exception as e:
            LOGGER.error(f"信道LRU淘汰异常 task_type={oldest_task_type}, error={e.__class__.__name__}: {e}")

    async def get_exchange(
            self,
            channel: Channel,
            exchange_name: Optional[str] = None,
            exchange_type: str = "topic"
    ) -> AbstractExchange:
        """
        获取或创建交换机

        Args:
            channel: 信道对象
            exchange_name: 交换机名称，默认使用项目配置的交换机
            exchange_type: 交换机类型 (topic/direct/fanout/headers)

        Returns:
            AbstractExchange: 交换机对象

        Raises:
            ValueError: 交换机类型无效
        """
        exchange_type = exchange_type.lower()

        valid_types = ["direct", "topic", "fanout", "headers"]
        if exchange_type not in valid_types:
            raise ValueError(f"无效的交换机类型：{exchange_type}，有效类型：{valid_types}")

        if not exchange_name:
            exchange_name = self.rabbit_keys.get_exchange_name()

        if exchange_name not in self._exchanges:
            self._exchanges[exchange_name] = await channel.declare_exchange(
                name=exchange_name,
                type=exchange_type,
                durable=True,
                auto_delete=False
            )
            LOGGER.debug(f"交换机创建成功 type={exchange_type}, name={exchange_name}")

        return self._exchanges[exchange_name]

    async def _ensure_dlx_resources(self, channel: Channel, task_type: str):
        """确保死信交换机和队列已声明"""
        dlx_exchange_name = self.rabbit_keys.get_dlx_exchange_name()
        dlq_queue_name = self.rabbit_keys.get_dlq_queue_name(task_type)

        if dlx_exchange_name not in self._exchanges:
            dlx_exchange = await channel.declare_exchange(
                name=dlx_exchange_name,
                type=ExchangeType.DIRECT,
                durable=True,
                auto_delete=False
            )
            self._exchanges[dlx_exchange_name] = dlx_exchange

        if dlq_queue_name not in self._queues:
            dlq_queue = await channel.declare_queue(
                name=dlq_queue_name,
                durable=True,
                auto_delete=False,
                arguments={
                    'x-message-ttl': 30 * 24 * 3600 * 1000,
                    'x-max-length': 10000,
                    'x-max-length-bytes': 104857600,
                }
            )
            await dlq_queue.bind(dlx_exchange_name, routing_key=task_type)
            self._queues[dlq_queue_name] = dlq_queue

        LOGGER.debug(f"死信队列创建成功 task_type={task_type}, name={dlq_queue_name}, binding={task_type}, dlx_exchange={dlx_exchange_name}, ttl=30d")
        return self._exchanges[dlx_exchange_name], self._queues[dlq_queue_name]

    @track_performance('ensure_declare')
    async def ensure_declare(
            self,
            task_type: str,
            prefetch: int = 10,
            queue_args: Optional[Dict[str, Any]] = None
    ):
        """
        确保交换机和队列已声明（包括死信队列）

        Args:
            task_type: 任务类型
            prefetch: 预取消息数量
            queue_args: 队列参数，会覆盖默认参数

        Returns:
            tuple: (队列对象，交换机对象)
        """
        channel = await self.get_channel(task_type, prefetch)

        exchange_key = self.rabbit_keys.get_exchange_name()
        exchange_type = ExchangeType.TOPIC
        routing_key = self.rabbit_keys.get_routing_key(task_type)
        queue_key = self.rabbit_keys.get_queue_name(task_type)

        exchange = await self.get_exchange(
            channel=channel,
            exchange_name=exchange_key,
            exchange_type=exchange_type
        )

        # 声明死信资源（交换机和队列）- 使用提取的独立方法
        await self._ensure_dlx_resources(channel, task_type)
        if queue_key not in self._queues:
            default_queue_args = {
                'x-max-priority': 10,
                'x-message-ttl': self.message_ttl,
                # 配置死信队列参数
                'x-dead-letter-exchange': self.rabbit_keys.get_dlx_exchange_name(),
                'x-dead-letter-routing-key': task_type,
            }
            final_queue_args = {**default_queue_args, **(queue_args or {})}

            try:
                queue = await channel.declare_queue(
                    name=queue_key,
                    durable=True,
                    arguments=final_queue_args
                )
                await queue.bind(exchange, routing_key)
                LOGGER.debug(f"消息队列创建成功 task_type={task_type}, name={queue_key}, routing_key={routing_key}")
                self._queues[queue_key] = queue
            except Exception as e:
                # 如果队列已存在且参数不匹配，记录警告并使用现有队列（不带死信配置）
                if "PRECONDITION_FAILED" in str(e) or "inequivalent arg" in str(e):
                    LOGGER.warning(f"消息队列已存在，参数不匹配，无死信 task_type={task_type}, name={queue_key}")
                    # 创建新信道（因为参数不匹配可能导致当前信道关闭）
                    new_channel = await self.connection.channel()

                    # 尝试以被动模式获取现有队列（不指定参数）
                    queue = await new_channel.declare_queue(
                        name=queue_key,
                        durable=True,
                        passive=True
                    )
                    await queue.bind(exchange, routing_key)
                    self._queues[queue_key] = queue
                    LOGGER.info(f"消息队列绑定成功，无死信配置 task_type={task_type}, name={queue_key}")

                    # 更新信道缓存，避免资源泄漏
                    channel_info = ChannelInfo(
                        channel=new_channel,
                        task_type=task_type,
                        prefetch=prefetch,
                        usage_count=1
                    )
                    self._channels[task_type] = channel_info
                else:
                    raise

        return self._queues[queue_key], exchange

    async def health_check(self) -> Dict[str, Any]:
        """
        健康检查接口

        Returns:
            dict: 连接状态和统计信息
        """
        return {
            "connected": bool(self.connection and not self.connection.is_closed),
            "channels_count": len(self._channels),
            "channels_limit": self.max_channels,
            "queues_count": len(self._queues),
            "exchanges_count": len(self._exchanges),
            "connection_count": self._connection_count,
            "metrics_enabled": self.enable_metrics,
        }

    def get_metrics(self, metric_name: str) -> Optional[Dict[str, Any]]:
        """
        获取性能指标

        Args:
            metric_name: 指标名称

        Returns:
            dict: 指标数据，不存在返回 None
        """
        if metric_name not in self._metrics:
            return None
        return self._metrics[metric_name].to_dict()

    def get_all_metrics(self) -> Dict[str, Dict[str, Any]]:
        """
        获取所有性能指标

        Returns:
            dict: 所有指标数据
        """
        return {name: data.to_dict() for name, data in self._metrics.items()}

    async def get_queue_stats(self, queue_name: str) -> Optional[Dict[str, Any]]:
        """
        获取队列统计信息

        Args:
            queue_name: 队列名称

        Returns:
            dict: 队列统计信息，包括消息数和消费者数
        """
        queue = self._queues.get(queue_name)
        if not queue:
            LOGGER.warning(f"消息队列不存在 name={queue_name}")
            return None

        try:
            state = await queue.declare()
            return {
                "queue_name": queue_name,
                "message_count": state.message_count,
                "consumer_count": state.consumer_count
            }
        except Exception as e:
            LOGGER.error(f"消息队列统计获取失败 name={queue_name}, error={e.__class__.__name__}: {e}")
            return None

    async def __aenter__(self):
        """异步上下文管理器入口"""
        await self.connect()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """异步上下文管理器出口，确保资源清理"""
        await self.close()
