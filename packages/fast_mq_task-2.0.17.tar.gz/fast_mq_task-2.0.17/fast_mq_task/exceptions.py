# -*- coding: utf-8 -*-
"""
异常模块
定义任务处理相关的自定义异常
"""


class FastMQTaskException(Exception):
    """基础异常类，所有自定义异常的基类"""
    pass


class DropMessageException(FastMQTaskException):
    """
    丢弃消息异常
    
    当任务处理失败且不应该重试时抛出此异常
    
    Attributes:
        msg: 错误描述信息
        code: 错误码（可选）
    """

    def __init__(self, msg: str = None, code: int = None):
        self.msg = msg
        self.code = code
        super().__init__(msg)


class RequeueMessageException(FastMQTaskException):
    """
    重新入队异常
    
    当任务处理失败但应该重试时抛出此异常
    
    Attributes:
        msg: 错误描述信息
        retry_after: 建议的重试间隔（秒）
    """

    def __init__(self, msg: str = None, retry_after: int = None):
        self.msg = msg
        self.retry_after = retry_after
        super().__init__(msg)


class TaskValidationError(FastMQTaskException):
    """
    任务验证异常
    
    当任务数据验证失败时抛出此异常
    """
    pass


class TaskExecutionError(FastMQTaskException):
    """
    任务执行异常
    
    当任务执行过程中发生错误时抛出此异常
    """
    pass


class ResourceExhaustedError(FastMQTaskException):
    """
    资源耗尽异常
    
    当线程池、连接等资源耗尽时抛出此异常
    """
    pass
