# -*- coding: utf-8 -*-
"""
装饰器模块
提供任务处理器注册功能

优化点：
- 完善的类型提示
- 增强的文档字符串
- 参数验证
"""
import inspect
import logging
from typing import Callable, Dict, Optional
from functools import wraps

from .models import RabbitMeta

LOGGER = logging.getLogger('MQT注册器')


class TaskRegistry:
    """
    任务注册器

    单例模式，用于注册和管理任务处理器

    使用方式:
        1. 使用装饰器:
            @task_handler(task_type="email.send")
            async def handle_email(task):
                pass

        2. 使用 register_handler:
            TaskRegistry.register_handler("email.send", handle_email)

    混合模式说明:
        - 装饰器模式：适合简单场景，配置集中，代码简洁
        - 配置模式：适合复杂场景，配置灵活，便于动态调整
        - 混合模式：装饰器配置优先，task_config 可覆盖

    Attributes:
        _handlers: 已注册的处理器字典
    """

    _handlers: Dict[str, RabbitMeta] = {}

    @classmethod
    def decorator_handler(
        cls,
        task_type: str,
        prefetch: Optional[int] = None,
        max_workers: Optional[int] = None
    ) -> Callable:
        """
        任务处理器装饰器

        Args:
            task_type: 任务类型标识（必填）
            prefetch: 预取消息数（可选）
            max_workers: 最大工作线程数（可选）

        Returns:
            Callable: 装饰器函数

        Raises:
            ValueError: task_type 为空时抛出

        Example:
            >>> @task_handler(task_type="email.send", prefetch=20)
            ... async def handle_email(task: TaskMessage):
            ...     print(f"处理邮件任务：{task.data}")

        注意:
            - 装饰器配置的优先级低于 task_config 中的显式配置
            - 如果 task_config 中指定了 handler，将覆盖装饰器的注册
            - 装饰器适合快速配置，task_config 适合精细化控制
        """
        if not task_type or not task_type.strip():
            raise ValueError("`task_type` 不能为空")

        def decorator(func: Callable) -> Callable:
            is_coro = inspect.iscoroutinefunction(func)

            if is_coro:
                @wraps(func)
                async def async_wrapper(*args, **kwargs):
                    return await func(*args, **kwargs)
                wrapper = async_wrapper
            else:
                @wraps(func)
                def sync_wrapper(*args, **kwargs):
                    return func(*args, **kwargs)
                wrapper = sync_wrapper

            meta = RabbitMeta(
                task_type=task_type,
                handler_func=wrapper,
                prefetch=prefetch,
                max_workers=max_workers
            )
            cls._handlers[task_type] = meta
            # TODO CLEAN
            # logger.info(f"处理器注册成功 | mode=装饰器, task_type={task_type}, queue={meta.queue_key}, func={func.__name__}, prefetch={prefetch}, max_workers={max_workers}")

            return wrapper

        return decorator

    @classmethod
    def register_handler(
        cls,
        task_type: str,
        func: Callable,
        prefetch: Optional[int] = None,
        max_workers: Optional[int] = None
    ) -> Callable:
        """
        注册任务处理器

        Args:
            task_type: 任务类型标识（必填）
            func: 处理函数（必填）
            prefetch: 预取消息数（可选）
            max_workers: 最大工作线程数（可选）

        Returns:
            Callable: 处理函数本身

        Raises:
            ValueError: task_type 为空或 func 不可调用时抛出

        Example:
            >>> async def handle_email(task):
            ...     pass
            >>> TaskRegistry.register_handler("email.send", handle_email, prefetch=20)
        """
        if not task_type or not task_type.strip():
            raise ValueError("`task_type` 不能为空")

        if not callable(func):
            raise ValueError("`func` 必须是可调用对象")

        meta = RabbitMeta(
            task_type=task_type,
            handler_func=func,
            prefetch=prefetch,
            max_workers=max_workers
        )
        cls._handlers[task_type] = meta
        LOGGER.info(f"注册成功 mode=配置, task_type={task_type}, queue={meta.queue_key}, func={func.__name__}")

        return func

    @classmethod
    def get_handler(cls, task_type: str) -> Optional[RabbitMeta]:
        """
        获取任务处理器元数据

        Args:
            task_type: 任务类型

        Returns:
            RabbitMeta: 处理器元数据，不存在则返回 None
        """
        return cls._handlers.get(task_type)

    @classmethod
    def list_handlers(cls) -> Dict[str, RabbitMeta]:
        """
        列出所有已注册的处理器

        Returns:
            dict: 任务类型到元数据的映射
        """
        return cls._handlers.copy()

    @classmethod
    def clear_handlers(cls):
        """
        清空所有处理器注册

        用于测试或重新加载
        """
        cls._handlers.clear()
        LOGGER.info("处理器注册已清空")


# 快捷方式
task_handler = TaskRegistry.decorator_handler
