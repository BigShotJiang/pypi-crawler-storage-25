# -*- coding: utf-8 -*-
"""
键名生成模块
负责生成交换机、路由键和队列的名称

重构为 Keys 类实现，支持实例化的前缀配置
"""
import os
from typing import Optional


class RabbitKeys:
    """
    RabbitMQ 键名生成器

    负责生成交换机、路由键和队列的名称，支持自定义前缀配置

    前缀优先级机制：
    1. 构造函数直接传入的参数（最高优先级）
    2. 环境变量 (MQT_APP_PREFIX, MQT_SERIES_PREFIX)
    3. 默认值 ('app', 'fast')

    Attributes:
        app_prefix: 应用前缀
        series_prefix: 系列前缀

    使用示例:
        # 使用默认前缀
        keys = RabbitKeys()

        # 使用自定义前缀
        keys = RabbitKeys(app_prefix='myapp', series_prefix='prod')

        # 在客户端中使用
        client = RabbitMQClient(amqp_url, app_prefix='myapp', series_prefix='prod')
        queue_name = client.keys.get_queue_name('email.send')
    """

    # 默认值
    DEFAULT_APP_PREFIX = 'app'
    DEFAULT_SERIES_PREFIX = 'fast'

    def __init__(
        self,
        app_prefix: Optional[str] = None,
        series_prefix: Optional[str] = None,
    ):
        """
        初始化键名生成器

        Args:
            app_prefix: 应用前缀（可选）
            series_prefix: 系列前缀（可选）

        Note:
            前缀优先级：
            1. 构造函数传入的参数
            2. 环境变量
            3. 默认值
        """
        self._app_prefix = app_prefix or os.getenv('MQT_APP_PREFIX') or os.getenv('APP_CODE') or self.DEFAULT_APP_PREFIX
        self._series_prefix = series_prefix or os.getenv('MQT_SERIES_PREFIX') or self.DEFAULT_SERIES_PREFIX

    @property
    def app_prefix(self) -> str:
        """获取应用前缀"""
        return self._app_prefix

    @property
    def series_prefix(self) -> str:
        """获取系列前缀"""
        return self._series_prefix

    def get_exchange_name(self) -> str:
        """
        获取交换机名称

        格式：{series_prefix}.{app_prefix}
        示例：fast.myapp

        Returns:
            str: 交换机名称
        """
        return f"{self._series_prefix}.{self._app_prefix}"

    def get_routing_key(self, task_type: str) -> str:
        """
        获取路由键

        格式：{series_prefix}.{app_prefix}.{task_type}
        示例：fast.myapp.email.send

        Args:
            task_type: 任务类型标识

        Returns:
            str: 路由键

        Raises:
            ValueError: task_type 为空时抛出
        """
        if not task_type or not task_type.strip():
            raise ValueError(f'task_type 不能为空：task_type={task_type}')

        return f"{self._series_prefix}.{self._app_prefix}.{task_type}"

    def get_queue_name(self, task_type: str) -> str:
        """
        获取队列名称

        格式：{series_prefix}.{app_prefix}.{task_type}
        示例：fast.myapp.email.send

        Args:
            task_type: 任务类型标识

        Returns:
            str: 队列名称

        Raises:
            ValueError: task_type 为空时抛出
        """
        if not task_type or not task_type.strip():
            raise ValueError(f'task_type 不能为空：task_type={task_type}')

        return f"{self._series_prefix}.{self._app_prefix}.{task_type}"

    def get_dlq_queue_name(self, task_type: str) -> str:
        """
        获取死信队列名称

        格式：{series_prefix}.{app_prefix}.{task_type}.dlq
        示例：fast.myapp.email.send.dlq

        Args:
            task_type: 任务类型标识

        Returns:
            str: 死信队列名称

        Raises:
            ValueError: task_type 为空时抛出
        """
        if not task_type or not task_type.strip():
            raise ValueError(f'task_type 不能为空：task_type={task_type}')

        return f"{self._series_prefix}.{self._app_prefix}.{task_type}.dlq"

    def get_dlx_exchange_name(self) -> str:
        """
        获取死信交换机名称

        格式：{series_prefix}.{app_prefix}.dlx
        示例：fast.myapp.dlx

        Returns:
            str: 死信交换机名称
        """
        return f"{self._series_prefix}.{self._app_prefix}.dlx"

    def __repr__(self) -> str:
        """返回对象的字符串表示"""
        return f"Keys(app_prefix='{self._app_prefix}', series_prefix='{self._series_prefix}')"



