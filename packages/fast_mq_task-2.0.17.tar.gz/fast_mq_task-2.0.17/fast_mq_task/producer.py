# -*- coding: utf-8 -*-
"""
生产者模块
负责任务消息的发布

优化点：
- 消息压缩支持（zlib）
- 性能监控指标
- 批量发布优化
- 类型提示完善
- 配置验证
"""
import logging
import time
import zlib
import asyncio
from typing import List, Optional, Dict, Any
from dataclasses import dataclass
from aio_pika import Message, DeliveryMode
from aiormq import AMQPConnectionError, ConnectionClosed, ChannelInvalidStateError
from tenacity import retry, retry_if_exception_type, wait_fixed, wait_exponential, stop_after_attempt, retry_any

from .client import RabbitMQClient, track_performance
from .models import TaskMessage

LOGGER = logging.getLogger('MQT生产者')


@dataclass
class ProducerMetrics:
    """生产者性能指标"""
    published_count: int = 0
    error_count: int = 0
    compressed_count: int = 0
    total_bytes: int = 0
    compressed_bytes: int = 0
    last_updated: float = 0.0

    def __post_init__(self):
        self.last_updated = time.time()

    def record_published(self, body_size: int, compressed_size: Optional[int] = None):
        """记录发布成功"""
        self.published_count += 1
        self.total_bytes += body_size
        if compressed_size is not None:
            self.compressed_count += 1
            self.compressed_bytes += compressed_size
        self.last_updated = time.time()

    def record_error(self):
        """记录错误"""
        self.error_count += 1
        self.last_updated = time.time()

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        compression_ratio = (
            (1 - self.compressed_bytes / self.total_bytes * 100)
            if self.total_bytes > 0 and self.compressed_bytes > 0
            else 0
        )
        return {
            'published_count': self.published_count,
            'error_count': self.error_count,
            'compressed_count': self.compressed_count,
            'total_bytes': self.total_bytes,
            'compressed_bytes': self.compressed_bytes,
            'compression_ratio_percent': round(compression_ratio, 2),
            'last_updated': self.last_updated,
        }


class TaskProducer(RabbitMQClient):
    """
    任务生产者

    支持单个和批量发布任务消息，具有自动重连和消息持久化功能

    优化特性：
    - 消息压缩支持（zlib，大于阈值自动压缩）
    - 性能监控指标
    - 批量发布优化
    - 配置验证

    使用示例:
        async with TaskProducer(amqp_url) as producer:
            task = TaskMessage(task_type="email.send", data={"to": "user@example.com"})
            await producer.publish_task(task)
    """

    def __init__(
        self,
        amqp_url: str,
        compression_enabled: bool = True,
        compression_threshold: int = 1024,  # 大于 1KB 才压缩
        enable_metrics: bool = True,
        app_prefix: Optional[str] = None,
        series_prefix: Optional[str] = None,
        **kwargs,
    ):
        """
        初始化任务生产者

        Args:
            amqp_url: RabbitMQ 连接地址
            compression_enabled: 是否启用压缩，默认 True
            compression_threshold: 压缩阈值（字节），默认 1024
            enable_metrics: 是否启用性能指标，默认 True
            app_prefix: 应用前缀（可选），优先级高于环境变量
            series_prefix: 系列前缀（可选），优先级高于环境变量
            **kwargs: 传递给父类的其他参数

        Note:
            前缀优先级机制：
            1. 构造函数直接传入的参数
            2. 环境变量 (MQT_APP_PREFIX, MQT_SERIES_PREFIX)
            3. 默认值 ('app', 'fast')
        """
        super().__init__(
            amqp_url,
            enable_metrics=enable_metrics,
            app_prefix=app_prefix,
            series_prefix=series_prefix,
            **kwargs
        )
        self.compression_enabled = compression_enabled
        self.compression_threshold = compression_threshold
        self._metrics = ProducerMetrics()

        LOGGER.info(f"初始化成功 compression_enabled={compression_enabled}, threshold={compression_threshold}B, keys={self.rabbit_keys}")

    @retry(
        retry=retry_if_exception_type((AMQPConnectionError, ConnectionClosed, ChannelInvalidStateError)),
        wait=wait_exponential(multiplier=1, min=2, max=10),  # 指数退避：2s, 4s, 8s, 10s
        stop=stop_after_attempt(3),
        reraise=True
    )
    async def republish_from_dlq(
        self,
        task_type: str,
        msg_id: Optional[str] = None,
        limit: int = 100
    ) -> Dict[str, Any]:
        """
        从死信队列重新发布消息到原队列

        Args:
            task_type: 任务类型
            msg_id: 指定消息 ID，为 None 时重放所有消息
            limit: 最大重放消息数量，默认 100

        Returns:
            dict: 重放统计信息
        """
        queue_key = self.rabbit_keys.get_queue_name(task_type)
        dlq_queue_name = self.rabbit_keys.get_dlq_queue_name(task_type)

        # 声明所有必需资源（主队列、死信队列、交换机）
        _, exchange = await self.ensure_declare(task_type=task_type)

        # 获取死信队列
        dlq_queue = self._queues.get(dlq_queue_name)
        if not dlq_queue:
            LOGGER.error(f"死信队列不存在 task_type={task_type}, dlq={dlq_queue_name}")
            return {
                "success": False,
                "error": f"死信队列不存在：{dlq_queue_name}",
                "republished_count": 0,
            }

        LOGGER.info(f"开始重放死信队列消息 task_type={task_type}, dlq={dlq_queue_name}, msg_id={msg_id}, limit={limit}")

        republished_count = 0
        failed_count = 0

        try:
            # 从死信队列获取消息
            async with dlq_queue.iterator() as queue_iter:
                async for msg in queue_iter:
                    try:
                        # 检查是否达到限制
                        if republished_count >= limit:
                            break

                        # 如果指定了 msg_id，只重放该消息
                        if msg_id and msg.message_id != msg_id:
                            await msg.ack()
                            continue

                        # 重新发布到原队列
                        headers = dict(msg.headers) if msg.headers else {}
                        headers['x-republished-from-dlq'] = True
                        headers['x-republish-time'] = int(time.time())

                        await exchange.publish(
                            Message(
                                body=msg.body,
                                headers=headers,
                                delivery_mode=msg.delivery_mode,
                                content_type=msg.content_type,
                                content_encoding=msg.content_encoding,
                                priority=msg.priority,
                                correlation_id=msg.correlation_id,
                                reply_to=msg.reply_to,
                                expiration=msg.expiration,
                                message_id=msg.message_id,
                                timestamp=msg.timestamp,
                                type=msg.type,
                                user_id=msg.user_id,
                                app_id=msg.app_id,
                            ),
                            routing_key=msg.routing_key,
                        )

                        # 确认并从死信队列删除
                        await msg.ack()
                        republished_count += 1

                        LOGGER.info(f"死信消息重放成功 task_type={task_type}, msg_id={msg.message_id}, from={dlq_queue_name}, to={queue_key}")

                    except Exception as e:
                        LOGGER.error(f"死信消息重放失败 task_type={task_type}, msg_id={msg.message_id} | error={e.__class__.__name__}: {e}")
                        failed_count += 1
                        # 不 ack，让消息留在死信队列

        except Exception as e:
            LOGGER.error(f"死信消息重放异常 task_type={task_type}, error={e.__class__.__name__}: {e}")
            return {
                "success": False,
                "error": str(e),
                "republished_count": republished_count,
                "failed_count": failed_count,
            }

        LOGGER.info(f"死信消息重放完成 task_type={task_type}, republished={republished_count}, failed={failed_count}, dlq={dlq_queue_name}")

        return {
            "success": True,
            "republished_count": republished_count,
            "failed_count": failed_count,
            "dlq_queue": dlq_queue_name,
            "target_queue": queue_key,
        }

    async def get_dlq_messages(
        self,
        task_type: str,
        limit: int = 100
    ) -> List[Dict[str, Any]]:
        """
        获取死信队列中的消息列表（不删除）

        Args:
            task_type: 任务类型
            limit: 最大获取数量，默认 100

        Returns:
            list: 消息列表
        """
        queue_key = self.rabbit_keys.get_queue_name(task_type)
        dlq_queue_name = self.rabbit_keys.get_dlq_queue_name(task_type)

        # 先调用 ensure_declare 确保死信队列已创建
        await self.ensure_declare(task_type=task_type)

        dlq_queue = self._queues.get(dlq_queue_name)
        if not dlq_queue:
            LOGGER.error(f"死信队列不存在 task_type={task_type}, dlq={dlq_queue_name}")
            return []

        messages = []
        try:
            # 获取队列状态
            queue_state = await dlq_queue.declare()
            total_messages = queue_state.message_count

            LOGGER.info(f"死信队列消息统计 task_type={task_type}, dlq={dlq_queue_name}, count={total_messages}")

            # 注意：aio_pika 不支持只读获取消息，这里返回元数据
            return [{
                "dlq_queue": dlq_queue_name,
                "total_messages": total_messages,
                "note": "死信队列消息需要通过 republish_from_dlq 方法重放",
            }]

        except Exception as e:
            LOGGER.error(f"死信队列消息获取失败 task_type={task_type}, dlq={dlq_queue_name}, error={e.__class__.__name__}: {e}")
            return []

    @track_performance('publish_task')
    async def publish_task(self, task: TaskMessage) -> bool:
        _, exchange = await self.ensure_declare(task_type=task.task_type)

        # 序列化（使用自定义编码器支持任意类型的 data）
        body = task.model_dump_json_custom().encode()
        headers = {
            "x-task-type": task.task_type,
            "x-created-at": time.time(),
            "x-task-id": task.task_id,
            "x-compressed": "false",
        }

        # 压缩（如果启用且超过阈值）
        compressed_size = None
        if self.compression_enabled and len(body) > self.compression_threshold:
            body = zlib.compress(body, level=6)  # 使用默认压缩级别
            headers["x-compressed"] = "true"
            compressed_size = len(body)
            original_size = len(task.model_dump_json_custom().encode())
            LOGGER.debug(f"消息压缩 task_type={task.task_type}, task_id={task.task_id}, original={original_size}B, compressed={len(body)}B")

        message = Message(
            body=body,
            content_type="application/json",
            headers=headers,
            delivery_mode=DeliveryMode.PERSISTENT,
            priority=task.priority
        )

        try:
            await exchange.publish(
                message=message,
                routing_key=self.rabbit_keys.get_routing_key(task.task_type)
            )

            # 记录指标
            self._metrics.record_published(len(task.model_dump_json_custom().encode()), compressed_size)

            LOGGER.debug(f"任务发布成功 task_id={task.task_id}, type={task.task_type}")
            return True
        except (AMQPConnectionError, ConnectionClosed, ChannelInvalidStateError, RuntimeError) as e:
            self._metrics.record_error()
            LOGGER.error(f"任务发布失败 task_id={task.task_id}, error={e.__class__.__name__}: {e}")
            raise

    @track_performance("publish_batch")
    async def publish_batch(
            self,
            tasks: List[TaskMessage],
            batch_size: int = 100,
    ) -> int:
        """
        批量发布任务

        优化点：
        - 按任务类型分组
        - 队列只声明一次
        - 每批并发 publish，而不是串行 await
        - 避免重复 JSON 序列化
        - 保留逐条失败记录
        """
        if not tasks:
            LOGGER.warning("[生产者] 批量发布-跳过-任务列表为空")
            return 0

        # 1. 按任务类型分组
        tasks_by_type: Dict[str, List[TaskMessage]] = {}
        for task in tasks:
            tasks_by_type.setdefault(task.task_type, []).append(task)

        # 2. 提前声明队列，并缓存 exchange
        exchange_by_type = {}

        declare_results = await asyncio.gather(
            *[
                self.ensure_declare(task_type=task_type)
                for task_type in tasks_by_type.keys()
            ],
            return_exceptions=True,
        )

        for task_type, result in zip(tasks_by_type.keys(), declare_results):
            if isinstance(result, Exception):
                LOGGER.error(
                    f"[生产者] 批量发布-预声明队列失败 | "
                    f"task_type={task_type}, "
                    f"error={result.__class__.__name__}: {result}"
                )
                continue

            _, exchange = result
            exchange_by_type[task_type] = exchange

        total_published = 0
        total_tasks = len(tasks)

        async def publish_one(exchange, task: TaskMessage):
            """
            发布单条消息。
            返回指标所需数据，异常交给 gather 捕获。
            """
            raw_body = task.model_dump_json_custom().encode()
            body = raw_body

            headers = {
                "x-task-type": task.task_type,
                "x-created-at": time.time(),
                "x-task-id": task.task_id,
                "x-compressed": "false",
            }

            compressed_size = None
            if self.compression_enabled and len(body) > self.compression_threshold:
                body = zlib.compress(body, level=6)
                headers["x-compressed"] = "true"
                compressed_size = len(body)

            message = Message(
                body=body,
                content_type="application/json",
                headers=headers,
                delivery_mode=DeliveryMode.PERSISTENT,
                priority=task.priority,
            )

            await exchange.publish(
                message=message,
                routing_key=self.rabbit_keys.get_routing_key(task.task_type),
            )

            return len(raw_body), compressed_size

        # 3. 每种任务类型分批并发发布
        for task_type, type_tasks in tasks_by_type.items():
            exchange = exchange_by_type.get(task_type)
            if exchange is None:
                LOGGER.error(
                    f"[生产者] 批量发布-跳过 | "
                    f"task_type={task_type}, 原因=exchange未准备好"
                )
                continue

            for start in range(0, len(type_tasks), batch_size):
                batch_tasks = type_tasks[start:start + batch_size]

                coroutines = [
                    publish_one(exchange, task)
                    for task in batch_tasks
                ]

                results = await asyncio.gather(
                    *coroutines,
                    return_exceptions=True,
                )

                for task, result in zip(batch_tasks, results):
                    if isinstance(result, Exception):
                        self._metrics.record_error()
                        LOGGER.error(
                            f"[生产者] 批量发布任务失败 | "
                            f"task_id={task.task_id}, "
                            f"error={result.__class__.__name__}: {result}"
                        )
                        continue

                    raw_size, compressed_size = result
                    total_published += 1

                    self._metrics.record_published(
                        raw_size,
                        compressed_size,
                    )

                if total_published and total_published % 500 == 0:
                    LOGGER.info(
                        f"[生产者] 已发布 {total_published}/{total_tasks} 个任务"
                    )

        LOGGER.info(
            f"[生产者] 批量发布完成 | 成功 {total_published}/{total_tasks} 个任务"
        )
        return total_published

    def get_metrics(self) -> Dict[str, Any]:
        """
        获取生产者性能指标

        Returns:
            dict: 指标数据
        """
        return self._metrics.to_dict()
