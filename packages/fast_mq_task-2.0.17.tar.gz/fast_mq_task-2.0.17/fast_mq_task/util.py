# -*- coding: utf-8 -*-
"""
工具函数模块
提供通用辅助函数
"""


def ref_to_obj(ref: str):
    """
    将引用字符串转换为对象

    支持从模块路径导入对象，例如：
    - "mymodule:MyClass" -> MyClass 对象
    - "mymodule.submodule:my_function" -> my_function 对象
    - "mymodule:Class.method" -> method 对象

    Args:
        ref: 引用字符串，格式为 "module_path:object_path"

    Returns:
        object: 导入的对象

    Raises:
        TypeError: ref 不是字符串
        ValueError: ref 格式不正确（不包含 :）
        LookupError: 无法导入模块或找不到对象

    Example:
        >>> handler = ref_to_obj("myapp.handlers:email_handler")
        >>> handler(task)
    """
    if not isinstance(ref, str):
        raise TypeError(f'ref 必须是字符串类型，当前类型：{type(ref)}')

    if ':' not in ref:
        raise ValueError(f'无效的引用格式：{ref}，正确格式应为 "module:object"')

    module_name, rest = ref.split(':', 1)

    try:
        obj = __import__(module_name, fromlist=[rest])
    except ImportError as e:
        raise LookupError(f'导入模块失败：{ref}，错误：{e}')

    try:
        for name in rest.split('.'):
            obj = getattr(obj, name)
        return obj
    except AttributeError as e:
        raise LookupError(f'查找对象失败：{ref}，错误：{e}')
