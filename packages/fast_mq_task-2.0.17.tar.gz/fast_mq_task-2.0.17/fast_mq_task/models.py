# -*- coding: utf-8 -*-
"""
数据模型模块
定义任务消息和元数据结构

优化点：
- 任务追踪和日志关联（trace_id, correlation_id, parent_task_id）
- 类型提示完善
- 文档字符串增强
- data 字段支持任意类型（dict、list、自定义类等）
"""
import json
import time
import uuid
from typing import Any, Dict, Callable, Optional, List
from aio_pika import ExchangeType
from pydantic import BaseModel, Field, ConfigDict


class CustomJSONEncoder(json.JSONEncoder):
    """
    自定义 JSON 编码器，支持更多类型的序列化

    支持类型：
    - 基本类型：str, int, float, bool, None
    - 集合类型：dict, list, tuple, set
    - 自定义对象：调用 __dict__ 或 model_dump()
    """

    def default(self, obj):
        """自定义序列化逻辑"""
        # Pydantic 模型
        if hasattr(obj, 'model_dump'):
            return obj.model_dump(mode='json')
        # 有 __dict__ 的自定义对象
        elif hasattr(obj, '__dict__'):
            return obj.__dict__
        # 集合类型
        elif isinstance(obj, (set, frozenset)):
            return list(obj)
        # 其他类型尝试使用默认行为
        return super().default(obj)


class RabbitMeta(BaseModel):
    """
    消息发布元数据

    包含交换机、队列、路由键等 RabbitMQ 配置信息

    Attributes:
        task_type: 任务类型标识
        exchange_key: 交换机名称
        exchange_type: 交换机类型
        routing_key: 路由键
        queue_key: 队列名称
        prefetch: 预取消息数量
        max_workers: 最大工作线程数
        handler_func: 消息处理函数
    """

    model_config = ConfigDict(
        arbitrary_types_allowed=True,
        extra='ignore'
    )

    task_type: str
    prefetch: Optional[int] = None
    max_workers: Optional[int] = None
    handler_func: Optional[Callable] = None

    exchange_key: str = ""
    exchange_type: str = ExchangeType.TOPIC
    routing_key: Optional[str] = None
    queue_key: Optional[str] = None

    def __init__(
        self,
        task_type: str,
        prefetch: Optional[int] = None,
        max_workers: Optional[int] = None,
        handler_func: Optional[Callable] = None
    ):
        """
        初始化 RabbitMeta

        Args:
            task_type: 任务类型（必填）
            prefetch: 预取消息数
            max_workers: 最大工作线程数
            handler_func: 处理函数
            **data: 其他可选参数

        Raises:
            ValueError: task_type 为空时抛出
        """
        if not task_type or not task_type.strip():
            raise ValueError("task_type 不能为空")

        super().__init__(
            task_type=task_type,
            prefetch=prefetch,
            max_workers=max_workers,
            handler_func=handler_func
        )


class TaskMessage(BaseModel):
    """
    任务消息模型

    封装要发送的任务数据，包含任务类型、数据负载和元信息

    优化特性：
    - 任务追踪（trace_id, correlation_id）
    - 日志关联（span_id）
    - 延迟任务支持（execute_at, delay_seconds）

    Attributes:
        task_type: 任务类型标识
        data: 任务数据负载
        task_id: 任务唯一标识（UUID）
        created_at: 创建时间戳（秒）
        priority: 任务优先级（0-10，数字越大优先级越高）
        trace_id: 链路追踪 ID（用于分布式追踪）
        correlation_id: 关联 ID（用于关联相关任务）
        parent_task_id: 父任务 ID（用于任务链）
        span_id: 当前执行跨度 ID（用于日志关联）
        execute_at: 计划执行时间戳（秒），为 None 表示立即执行
        delay_seconds: 延迟执行秒数，为 None 表示立即执行
    """

    model_config = ConfigDict(
        extra='ignore',  # 忽略额外字段，向后兼容旧消息
        arbitrary_types_allowed=True
    )

    task_type: str
    data: Any = None  # 支持任意类型：dict、list、自定义类等
    task_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    created_at: int = Field(default_factory=lambda: int(time.time()))
    priority: int = Field(default=0, ge=0, le=10, description="任务优先级，0-10，数字越大优先级越高")
    # 任务处理链
    task_chain: Optional[List[str]] = Field(default=None, description="任务处理链，用于动态控制节点处理流程")

    # 任务追踪字段（可选，向后兼容）
    trace_id: Optional[str] = Field(
        default=None,
        description="链路追踪 ID，用于分布式系统追踪"
    )
    correlation_id: Optional[str] = Field(
        default=None,
        description="关联 ID，用于关联相关任务或请求"
    )
    parent_task_id: Optional[str] = Field(
        default=None,
        description="父任务 ID，用于任务链追踪"
    )
    span_id: Optional[str] = Field(
        default=None,
        description="当前执行跨度 ID，用于日志关联"
    )

    # 延迟任务支持（可选，向后兼容）
    execute_at: Optional[int] = Field(
        default=None,
        description="计划执行时间戳（秒），为 None 表示立即执行"
    )
    delay_seconds: Optional[int] = Field(
        default=None,
        description="延迟执行秒数，为 None 表示立即执行"
    )

    def __init__(self, **data):
        """
        初始化任务消息

        Args:
            **data: 任务数据

        注意：
        - 自动为旧消息生成 span_id（如果未提供）
        - 忽略额外字段（向后兼容）
        """
        # 为旧消息自动生成 span_id
        if 'span_id' not in data or data.get('span_id') is None:
            data['span_id'] = str(uuid.uuid4())[:8]
        super().__init__(**data)

    def model_dump_dict(self) -> Dict[str, Any]:
        """
        转换为字典（Pydantic v2 风格）

        Returns:
            dict: 任务消息的字典表示
        """
        return self.model_dump()

    def model_dump_json_custom(self) -> str:
        """
        自定义 JSON 序列化，支持任意类型的 data 字段

        使用 CustomJSONEncoder 处理 Pydantic 默认编码器不支持的类型

        Returns:
            str: JSON 字符串
        """
        # 先转换为 dict
        data_dict = self.model_dump()
        # 使用自定义编码器序列化为 JSON
        return json.dumps(data_dict, cls=CustomJSONEncoder, ensure_ascii=False)

    @classmethod
    def model_validate_json_custom(cls, json_str: str) -> 'TaskMessage':
        """
        自定义 JSON 反序列化，支持任意类型的 data 字段

        Args:
            json_str: JSON 字符串

        Returns:
            TaskMessage: 任务消息实例
        """
        # 先解析为 dict
        data_dict = json.loads(json_str)
        # 使用 Pydantic 验证
        return cls.model_validate(data_dict)

    def set_trace_context(self, trace_id: str, span_id: Optional[str] = None):
        """
        设置追踪上下文

        Args:
            trace_id: 链路追踪 ID
            span_id: 跨度 ID，默认自动生成
        """
        self.trace_id = trace_id
        self.span_id = span_id or str(uuid.uuid4())[:8]

    def set_correlation(self, correlation_id: str):
        """
        设置关联 ID

        Args:
            correlation_id: 关联 ID
        """
        self.correlation_id = correlation_id

    def set_parent_task(self, parent_task_id: str):
        """
        设置父任务 ID

        Args:
            parent_task_id: 父任务 ID
        """
        self.parent_task_id = parent_task_id

    def schedule_at(self, execute_at: int):
        """
        设置计划执行时间

        Args:
            execute_at: 执行时间戳（秒）

        Returns:
            self: 当前实例（链式调用）
        """
        self.execute_at = execute_at
        self.delay_seconds = None
        return self

    def schedule_delay(self, delay_seconds: int):
        """
        设置延迟执行

        Args:
            delay_seconds: 延迟秒数

        Returns:
            self: 当前实例（链式调用）
        """
        self.delay_seconds = delay_seconds
        self.execute_at = int(time.time()) + delay_seconds
        return self

    def get_scheduled_time(self) -> Optional[int]:
        """
        获取计划执行时间

        Returns:
            int: 执行时间戳，None 表示立即执行
        """
        return self.execute_at

    def is_scheduled(self) -> bool:
        """
        判断是否是延迟任务

        Returns:
            bool: 是否是延迟任务
        """
        return self.execute_at is not None or self.delay_seconds is not None
