# -*- coding: utf-8 -*-
"""
fast-mq-task
基于 RabbitMQ 的分布式任务处理框架

提供生产者 - 消费者模式的任务发布与处理功能

优化特性：
- 连接池和信道池管理
- 动态线程池管理
- 消息压缩支持
- 性能监控指标
- 任务追踪和日志关联
- 配置验证
- 增强的类型提示

使用示例:
    # 生产者
    from fast_mq_task import TaskProducer, TaskMessage

    async with TaskProducer(amqp_url, compression_enabled=True) as producer:
        task = TaskMessage(
            task_type="email.send",
            data={"to": "user@example.com"},
            trace_id="trace-123",  # 任务追踪
        )
        await producer.publish_task(task)

    # 消费者
    from fast_mq_task import TaskConsumer, task_handler

    @task_handler(task_type="email.send")
    async def handle_email(task):
        print(f"发送邮件给：{task.data['to']}")

    # 示例 1：激活所有处理器（默认）
    consumer = TaskConsumer(
        amqp_url,
        task_config={...},
        enable_metrics=True,
    )
    await consumer.start(never_stop=True)

    # 示例 2：仅激活指定的处理器
    consumer = TaskConsumer(
        amqp_url,
        task_config={...},
        active_tasks=["email.send", "sms.send"],  # 选择性激活
    )
    await consumer.start(never_stop=True)
"""

__version__ = '1.3.0'
__author__ = 'zsodata'
__all__ = [
    # 核心类
    'TaskProducer',
    'TaskConsumer',
    'RabbitMQClient',

    # 模型
    'TaskMessage',
    'RabbitMeta',

    # 装饰器
    'task_handler',
    'TaskRegistry',

    # 异常
    'FastMQTaskException',
    'DropMessageException',
    'RequeueMessageException',
    'TaskValidationError',
    'TaskExecutionError',
    'ResourceExhaustedError',

    # 工具函数
    'ref_to_obj',

    # 键名生成
    'RabbitKeys',

    # 配置模型
    'TaskConfig',
]

from .client import RabbitMQClient
from .producer import TaskProducer
from .consumer import TaskConsumer, TaskConfig
from .models import TaskMessage, RabbitMeta
from .register import task_handler, TaskRegistry
from .exceptions import (
    FastMQTaskException,
    DropMessageException,
    RequeueMessageException,
    TaskValidationError,
    TaskExecutionError,
    ResourceExhaustedError,
)
from .util import ref_to_obj
from .keys import RabbitKeys
