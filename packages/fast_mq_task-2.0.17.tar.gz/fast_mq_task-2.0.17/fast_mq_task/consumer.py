# -*- coding: utf-8 -*-
"""
消费者模块
负责任务消息的消费和处理

优化点：
- 动态线程池管理（支持最小/最大 worker 数，空闲回收）
- 性能监控指标
- 配置验证
- 类型提示完善
- 错误处理优化
"""
import asyncio
import inspect
import logging
import traceback
import time
import zlib
from functools import partial
from typing import Callable, Dict, Optional, Any, List, Union
from collections import OrderedDict
from dataclasses import dataclass, field
from concurrent.futures import ThreadPoolExecutor
from aio_pika import IncomingMessage
from pydantic import BaseModel, field_validator

from .client import RabbitMQClient, track_performance
from .register import TaskRegistry
from .exceptions import DropMessageException, RequeueMessageException
from .models import TaskMessage, RabbitMeta
from .util import ref_to_obj

LOGGER = logging.getLogger('MQT消费者')


@dataclass
class DynamicThreadPool:
    """
    动态线程池
    支持最小/最大 worker 数，空闲自动回收
    """
    executor: ThreadPoolExecutor
    min_workers: int
    max_workers: int
    idle_timeout: int = 60  # 空闲线程超时回收时间（秒）
    created_at: float = field(default_factory=time.time)
    last_used: float = field(default_factory=time.time)
    task_count: int = 0

    def record_usage(self):
        """记录使用情况"""
        self.last_used = time.time()
        self.task_count += 1


@dataclass
class ConsumerMetrics:
    """消费者性能指标"""
    processed_count: int = 0
    error_count: int = 0
    avg_latency_ms: float = 0.0
    latency_samples: List[float] = field(default_factory=list)
    queue_depth_samples: List[int] = field(default_factory=list)
    last_updated: float = field(default_factory=time.time)

    def record_processed(self, latency_ms: float):
        """记录处理成功"""
        self.processed_count += 1
        self._update_avg_latency(latency_ms)
        self.last_updated = time.time()

    def record_error(self):
        """记录错误"""
        self.error_count += 1
        self.last_updated = time.time()

    def _update_avg_latency(self, latency_ms: float):
        """更新平均延迟（只保留最近 100 个样本）"""
        self.latency_samples.append(latency_ms)
        if len(self.latency_samples) > 100:
            self.latency_samples.pop(0)
        self.avg_latency_ms = sum(self.latency_samples) / len(self.latency_samples)

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            'processed_count': self.processed_count,
            'error_count': self.error_count,
            'avg_latency_ms': round(self.avg_latency_ms, 2),
            'min_latency_ms': round(min(self.latency_samples), 2) if self.latency_samples else 0,
            'max_latency_ms': round(max(self.latency_samples), 2) if self.latency_samples else 0,
            'last_updated': self.last_updated,
        }


class TaskConfig(BaseModel):
    """
    任务配置模型（带验证）
    """
    handler: Optional[Union[Callable, str]] = None
    max_workers: int = 4
    min_workers: int = 1
    prefetch: int = 10
    timeout: int = 300
    max_retries: int = 3
    idle_timeout: int = 60

    @field_validator('max_workers')
    @classmethod
    def validate_max_workers(cls, v):
        if v < 1 or v > 100:
            raise ValueError(f"max_workers 必须在 1-100 之间，当前：{v}")
        return v

    @field_validator('min_workers')
    @classmethod
    def validate_min_workers(cls, v, info):
        if v < 1:
            raise ValueError(f"min_workers 必须大于 0，当前：{v}")
        # Pydantic v2 使用 info.data 访问其他字段
        if hasattr(info, 'data') and 'max_workers' in info.data and v > info.data['max_workers']:
            raise ValueError(
                f"min_workers ({v}) 不能大于 max_workers ({info.data['max_workers']})"
            )
        return v

    @field_validator('prefetch')
    @classmethod
    def validate_prefetch(cls, v):
        if v < 1 or v > 1000:
            raise ValueError(f"prefetch 必须在 1-1000 之间，当前：{v}")
        return v

    @field_validator('timeout')
    @classmethod
    def validate_timeout(cls, v):
        if v < 1 or v > 3600:
            raise ValueError(f"timeout 必须在 1-3600 秒之间，当前：{v}")
        return v

    @field_validator('max_retries')
    @classmethod
    def validate_max_retries(cls, v):
        if v < 0 or v > 10:
            raise ValueError(f"max_retries 必须在 0-10 之间，当前：{v}")
        return v


class TaskConsumer(RabbitMQClient):
    """
    任务消费者

    支持多种任务类型的并发处理，具有线程池管理、超时控制、异常处理等功能

    优化特性：
    - 动态线程池管理（支持最小/最大 worker 数，空闲回收）
    - 性能监控指标
    - 配置验证
    - 增强的错误处理

    Attributes:
        task_config: 任务专属配置（prefetch, max_workers, timeout 等）
        default_prefetch: 默认预取消息数
        max_retries: 最大重试次数
        default_timeout: 默认任务超时时间（秒）
    """

    def __init__(
            self,
            amqp_url: str,
            task_config: Optional[Dict[str, Dict]] = None,
            default_prefetch: int = 10,
            max_retries: int = 3,
            default_timeout: int = 300,
            enable_metrics: bool = True,
            active_tasks: Optional[List[str]] = None,
            app_prefix: Optional[str] = None,
            series_prefix: Optional[str] = None,
            **kwargs,
    ):
        """
        初始化任务消费者

        Args:
            amqp_url: RabbitMQ 连接地址
            task_config: 任务配置字典，例如：
                {
                    "email.send": {
                        "handler": handle_email,
                        "max_workers": 8,
                        "min_workers": 2,
                        "prefetch": 20,
                        "timeout": 60,
                        "max_retries": 3
                    }
                }
            default_prefetch: 默认预取消息数
            max_retries: 最大重试次数
            default_timeout: 默认任务超时时间（秒）
            enable_metrics: 是否启用性能指标
            active_tasks: 激活的任务类型列表，仅这些任务会被注册和消费。
                         如果为 None，则激活所有已注册的任务。
                         例如：["email.send", "sms.send"]
            app_prefix: 应用前缀（可选），优先级高于环境变量
            series_prefix: 系列前缀（可选），优先级高于环境变量
            **kwargs: 传递给父类的其他参数

        Note:
            前缀优先级机制：
            1. 构造函数直接传入的参数
            2. 环境变量 (MQT_APP_PREFIX, MQT_SERIES_PREFIX)
            3. 默认值 ('app', 'fast')
        """
        # 验证并处理配置
        validated_config = {}
        if task_config:
            for task_type, config in task_config.items():
                try:
                    validated_config[task_type] = TaskConfig(**config)
                except Exception as e:
                    LOGGER.error(f"配置验证异常 task_type={task_type}, error={e.__class__.__name__}: {e}")
                    raise

        super().__init__(
            amqp_url,
            enable_metrics=enable_metrics,
            app_prefix=app_prefix,
            series_prefix=series_prefix,
            **kwargs
        )
        self.task_config = validated_config
        self.default_prefetch = default_prefetch
        self.max_retries = max_retries
        self.default_timeout = default_timeout
        self.active_tasks = set(active_tasks) if active_tasks else []
        self._running = False
        self._executors: OrderedDict[str, DynamicThreadPool] = OrderedDict()
        self._semaphores: Dict[str, asyncio.Semaphore] = {}
        self._metrics: ConsumerMetrics = ConsumerMetrics()
        self._task_metrics: Dict[str, ConsumerMetrics] = {}
        self._cleanup_task: Optional[asyncio.Task] = None

        LOGGER.info(f"=" * 30)
        LOGGER.info(f"amqp_url={self.amqp_url}")
        LOGGER.info(f"active_tasks={sorted(self.active_tasks)}")
        LOGGER.info(f"task_config={self.task_config}")
        LOGGER.info(f"=" * 30)

    async def init_resource(self, task_type: str):
        """
        初始化任务执行资源（动态线程池和信号量）

        优化点：
        - 支持最小/最大 worker 数
        - 空闲超时自动回收
        - LRU 淘汰策略
        - 混合模式：装饰器配置优先，task_config 可覆盖
        - active_tasks 过滤：仅激活指定任务

        Args:
            task_type: 任务类型

        Returns:
            bool: 如果任务被跳过（不在 active_tasks 中），返回 False；否则返回 True
        """
        # 检查是否在 active_tasks 列表中
        if self.active_tasks is not None and task_type not in self.active_tasks:
            LOGGER.debug(f"非激活处理器 task_type={task_type}, active_tasks={sorted(self.active_tasks)}")
            return False

        config = self.task_config.get(task_type)
        if not config:
            config = TaskConfig()

        # 检查是否已通过装饰器注册
        decorated_meta = TaskRegistry.get_handler(task_type)

        # 参数级合并：task_config 参数覆盖装饰器参数，未指定的保留装饰器值
        handler = config.handler
        if handler:
            # 获取 handler 函数
            handler_func = handler if callable(handler) else ref_to_obj(handler)
            handler_mode = "配置注册" if not isinstance(handler, str) else "配置注册(字符串)"

            if decorated_meta:
                # 合并模式：使用 task_config 的 handler，参数级覆盖
                decorated_meta.handler_func = handler_func
                if config.prefetch != TaskConfig.model_fields['prefetch'].default:
                    decorated_meta.prefetch = config.prefetch
                if config.max_workers != TaskConfig.model_fields['max_workers'].default:
                    decorated_meta.max_workers = config.max_workers
                LOGGER.debug(f"处理器参数合并 task_type={task_type}, handler={handler_func.__name__}, prefetch={decorated_meta.prefetch}, max_workers={decorated_meta.max_workers}")
            else:
                # 无装饰器，直接注册
                TaskRegistry.register_handler(task_type, handler_func, config.prefetch, config.max_workers)
                LOGGER.debug(f"处理器{handler_mode} task_type={task_type}, handler={handler_func.__name__}, prefetch={config.prefetch}, max_workers={config.max_workers}")
        elif decorated_meta and (config.prefetch != TaskConfig.model_fields['prefetch'].default or config.max_workers != TaskConfig.model_fields['max_workers'].default):
            # 仅使用装饰器 handler，但更新参数
            if config.prefetch != TaskConfig.model_fields['prefetch'].default:
                decorated_meta.prefetch = config.prefetch
            if config.max_workers != TaskConfig.model_fields['max_workers'].default:
                decorated_meta.max_workers = config.max_workers
            LOGGER.debug(f"处理器参数更新 task_type={task_type}, handler={decorated_meta.handler_func.__name__}, prefetch={decorated_meta.prefetch}, max_workers={decorated_meta.max_workers}")

        # 获取最终使用的参数（合并后的 RabbitMeta 值）
        final_meta = TaskRegistry.get_handler(task_type)
        final_prefetch = final_meta.prefetch if final_meta and final_meta.prefetch is not None else config.prefetch
        final_max_workers = final_meta.max_workers if final_meta and final_meta.max_workers is not None else config.max_workers

        # LRU 淘汰：如果线程池数量超过上限，淘汰最旧的
        if len(self._executors) >= self.max_executors:
            LOGGER.warning(f"线程池数量达上限, 淘汰旧线程池 max={self.max_executors}")
            oldest_key = next(iter(self._executors))
            await self._cleanup_executor(oldest_key)

        # 创建动态线程池（使用合并后的 max_workers）
        if task_type not in self._executors:
            executor = ThreadPoolExecutor(
                max_workers=final_max_workers,
                thread_name_prefix=f"Worker-{task_type}-"
            )
            pool = DynamicThreadPool(
                executor=executor,
                min_workers=config.min_workers,
                max_workers=final_max_workers,
                idle_timeout=config.idle_timeout,
            )
            self._executors[task_type] = pool
            LOGGER.debug(f"创建线程池 task_type={task_type}, workers={config.min_workers}-{final_max_workers}")

        # 创建信号量（使用合并后的 prefetch）
        self._semaphores[task_type] = asyncio.Semaphore(final_prefetch)
        LOGGER.debug(f"创建信号量 task_type={task_type}, prefetch={final_prefetch}")

        # 初始化补充任务元数据
        rabbit_meta = TaskRegistry.get_handler(task_type) or {}
        if rabbit_meta and self.rabbit_keys:
            rabbit_meta.exchange_key = self.rabbit_keys.get_exchange_name()
            rabbit_meta.routing_key = self.rabbit_keys.get_routing_key(task_type)
            rabbit_meta.queue_key = self.rabbit_keys.get_queue_name(task_type)
            LOGGER.info(f"处理器初始化成功 task_type={task_type}, queue={rabbit_meta.queue_key}, prefetch={final_prefetch}, workers={config.min_workers}-{final_max_workers}")
        else:
            LOGGER.info(f"处理器初始化失败 task_type={task_type}")

        return True

    async def _init_resources(self):
        """
        初始化所有任务的执行资源

        逻辑说明：
        1. 收集所有需要初始化的任务类型：
           - task_config 中配置的任务
           - 装饰器注册的任务（如果不在 task_config 中）
        2. 根据 active_tasks 过滤
        3. 初始化资源
        """
        # 收集所有任务类型
        all_task_types = set(self.task_config.keys())

        # 添加装饰器注册的任务
        for task_type in TaskRegistry._handlers.keys():
            all_task_types.add(task_type)

        LOGGER.info(f"资源初始化开始 total={len(all_task_types)}, config={len(self.task_config)}, decorators={len(TaskRegistry._handlers)}")

        initialized_list = []
        skipped_list = []

        for task_type in all_task_types:
            result = await self.init_resource(task_type)
            if result:
                initialized_list.append(task_type)
            else:
                skipped_list.append(task_type)

        LOGGER.info(f"资源初始化完成 initialized={initialized_list}, skipped={skipped_list}")

    async def _cleanup_executor(self, task_type: str):
        """
        清理线程池

        Args:
            task_type: 任务类型
        """
        if task_type in self._executors:
            pool = self._executors[task_type]
            pool.executor.shutdown(wait=False)
            del self._executors[task_type]
            LOGGER.info(f"线程池已清理 task_type={task_type}")

        if task_type in self._semaphores:
            del self._semaphores[task_type]

    async def _start_cleanup_task(self):
        """启动后台清理任务，定期回收空闲线程池"""

        async def cleanup_loop():
            LOGGER.info("启动清理回收定时任务")
            while self._running:
                try:
                    await asyncio.sleep(60)  # 每分钟检查一次
                    current_time = time.time()

                    for task_type, pool in list(self._executors.items()):
                        idle_time = current_time - pool.last_used
                        if idle_time > pool.idle_timeout and pool.task_count == 0:
                            # 空闲且无任务，缩容到最小 worker 数
                            LOGGER.info(f"执行清理回收任务 task_type={task_type}, idle_time={idle_time:.1f}s")
                            # 注意：ThreadPoolExecutor 不支持动态缩容，这里仅记录日志
                            # 实际应用中可以考虑使用 custom thread pool 实现

                except asyncio.CancelledError:
                    break
                except Exception as e:
                    LOGGER.error(f"清理回收任务异常 error={e.__class__.__name__}: {e}")

        self._cleanup_task = asyncio.create_task(cleanup_loop())

    async def _execute_handler(self, handler: Callable, task: TaskMessage, executor: ThreadPoolExecutor):
        """
        执行处理器（支持同步和异步）

        Args:
            handler: 处理函数
            task: 任务消息
            executor: 线程池执行器
        """
        if inspect.iscoroutinefunction(handler):
            await handler(task)
        else:
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(
                executor,
                partial(handler, task)
            )

    async def _send_to_dlq(self, msg: IncomingMessage, error: Exception):
        """
        发送消息到死信队列（实际实现）

        Args:
            msg: 原始消息
            error: 导致失败的异常
        """
        try:
            # 从 routing_key 提取 task_type
            # routing_key 格式：{series_prefix}.{app_prefix}.{task_type}
            routing_key_parts = msg.routing_key.split('.', 2)
            if len(routing_key_parts) >= 3:
                task_type = routing_key_parts[2]
            else:
                # 降级处理：如果格式不对，使用整个 routing_key 作为 task_type
                task_type = msg.routing_key

            # 使用 keys 实例构建死信队列名称
            dlq_queue_name = self.rabbit_keys.get_dlq_queue_name(task_type)

            # 获取死信队列
            dlq_queue = self._queues.get(dlq_queue_name)

            if dlq_queue:
                # 准备消息头信息
                headers = dict(msg.headers) if msg.headers else {}
                headers.update({
                    'x-death-reason': str(error),
                    'x-death-time': int(time.time()),
                    'x-original-message-id': msg.message_id,
                    'x-original-routing-key': msg.routing_key,
                    'x-exception-type': error.__class__.__name__,
                })

                # 重新发布消息到死信队列
                await self._channel.basic_publish(
                    body=msg.body,
                    routing_key=msg.routing_key,
                    headers=headers,
                    delivery_mode=msg.delivery_mode,
                    content_type=msg.content_type,
                    content_encoding=msg.content_encoding,
                    priority=msg.priority,
                    correlation_id=msg.correlation_id,
                    reply_to=msg.reply_to,
                    expiration=msg.expiration,
                    message_id=msg.message_id,
                    timestamp=msg.timestamp,
                    type=msg.type,
                    user_id=msg.user_id,
                    app_id=msg.app_id,
                )

                LOGGER.info(f"死信发送 dlq={dlq_queue_name}, msg_id={msg.message_id}, error={error.__class__.__name__}: {error}")
            else:
                LOGGER.error(f"死信发送失败 dlq={dlq_queue_name}, msg_id={msg.message_id}, reason=队列不存在")
        except Exception as e:
            LOGGER.error(f"死信发送异常 msg_id={msg.message_id}, error={e.__class__.__name__}: {e}, original_error={error.__class__.__name__}: {error}")

    @track_performance('process_message')
    async def _process_message(self, rabbit_meta: RabbitMeta, msg: IncomingMessage):
        """
        处理消息

        包含超时控制、异常处理、重试逻辑、性能监控

        Args:
            rabbit_meta: RabbitMQ 元数据
            msg: 接收到的消息
        """
        start_time = time.time()
        handler: Callable = rabbit_meta.handler_func
        task_type = rabbit_meta.task_type

        semaphore = self._semaphores.get(task_type)
        executor_pool = self._executors.get(task_type)

        if not semaphore or not executor_pool:
            LOGGER.error(f"资源未初始化 task_type={task_type}, rabbit_meta={rabbit_meta}")
            await msg.nack(requeue=False)
            return

        executor = executor_pool.executor
        executor_pool.record_usage()

        config = self.task_config.get(task_type)
        if not config:
            config = TaskConfig()

        timeout = config.timeout
        max_retries = config.max_retries

        try:
            async with semaphore:
                # 自动解压：检查 x-compressed header
                body = msg.body
                is_compressed = msg.headers.get("x-compressed") == "true" if msg.headers else False

                if is_compressed:
                    try:
                        body = zlib.decompress(body)
                        LOGGER.debug(f"消息解压 task_type={task_type}, msg_id={msg.message_id}, original_size={len(msg.body)}B, decompressed_size={len(body)}B")
                    except Exception as e:
                        LOGGER.error(f"消息解压失败 task_type={task_type}, msg_id={msg.message_id}, error={e.__class__.__name__}: {e}")
                        await msg.nack(requeue=False)
                        self._metrics.record_error()
                        return

                # 反序列化（使用自定义解码器支持任意类型的 data）
                task = TaskMessage.model_validate_json_custom(body.decode())

                try:
                    await asyncio.wait_for(
                        self._execute_handler(handler, task, executor),
                        timeout=timeout
                    )

                    await msg.ack()

                    # 记录性能指标
                    latency_ms = (time.time() - start_time) * 1000
                    self._metrics.record_processed(latency_ms)

                    if task_type not in self._task_metrics:
                        self._task_metrics[task_type] = ConsumerMetrics()
                    self._task_metrics[task_type].record_processed(latency_ms)

                except asyncio.TimeoutError:
                    LOGGER.error(f"消息处理超时 task_type={task_type}, msg_id={msg.message_id}, timeout={timeout}s")
                    await msg.nack(requeue=False)
                    self._metrics.record_error()

        except DropMessageException as e:
            LOGGER.info(f"消息处理异常 action=主动丢弃, task_type={task_type}, msg_id={msg.message_id}, reason={e.msg}")
            await msg.nack(requeue=False)
            self._metrics.record_error()

        except RequeueMessageException as e:
            retry_count = msg.headers.get('x-retry-count', 0) if msg.headers else 0
            if retry_count >= max_retries:
                LOGGER.error(f"消息处理异常 action=重试次数超限发送死信队列, task_type={task_type}, msg_id={msg.message_id}, retries={retry_count}/{max_retries}")
                await self._send_to_dlq(msg, e)
                await msg.nack(requeue=False)
            else:
                LOGGER.warning(f"消息处理异常 action=重试, task_type={task_type}, msg_id={msg.message_id}, attempt={retry_count + 1}/{max_retries}")
                headers = dict(msg.headers) if msg.headers else {}
                headers['x-retry-count'] = retry_count + 1
                await msg.nack(requeue=True)
            self._metrics.record_error()

        except Exception as e:
            if isinstance(e, (ConnectionError, TimeoutError, OSError)):
                LOGGER.warning(f"消息处理异常 action=临时错误重试, task_type={task_type}, msg_id={msg.message_id}, error={e.__class__.__name__}: {e}")
                await msg.nack(requeue=True)
            else:
                LOGGER.error(f"消息处理异常 action=未知异常发送死信队列, task_type={task_type}, msg_id={msg.message_id}, error={e.__class__.__name__}: {e}")
                LOGGER.debug(f"消息处理异常堆栈：\n{traceback.format_exc()}")
                await self._send_to_dlq(msg, e)
                await msg.nack(requeue=False)
            self._metrics.record_error()

    async def _setup_queues(self):
        """
        初始化队列和消费者

        为每个注册的任务类型创建专属消费者（受 active_tasks 过滤）
        """
        LOGGER.info(f"开始初始化队列和消费者 handlers={len(TaskRegistry._handlers)}")
        setup_count = 0
        skipped_count = 0

        for rabbit_meta in TaskRegistry._handlers.values():
            task_type = rabbit_meta.task_type

            # 检查是否在 active_tasks 列表中
            if self.active_tasks is not None and task_type not in self.active_tasks:
                LOGGER.debug(f"非激活处理器 task_type={task_type}, active_tasks={sorted(self.active_tasks)}")
                skipped_count += 1
                continue

            queue, _ = await self.ensure_declare(
                task_type=task_type,
                prefetch=rabbit_meta.prefetch or self.default_prefetch
            )

            await queue.consume(
                partial(self._process_message, rabbit_meta),
                no_ack=False
            )
            LOGGER.info(f"消费者启动成功 task_type={task_type}, queue_key={rabbit_meta.queue_key}, max_workers={rabbit_meta.max_workers}, prefetch={rabbit_meta.prefetch}, handler={rabbit_meta.handler_func}")
            setup_count += 1

        LOGGER.info(f"初始化队列和消费者完成 setup={setup_count}, skipped={skipped_count}")

    async def start(self, never_stop: bool = False):
        """
        启动消费者

        Args:
            never_stop: 是否持续运行（不退出）
        """
        LOGGER.info(f"启动中")
        await self._init_resources()
        await self._setup_queues()
        await self._start_cleanup_task()
        self._running = True
        LOGGER.info(f"已启动成功")

        if never_stop:
            try:
                while self._running:
                    await asyncio.sleep(1)
            except KeyboardInterrupt:
                LOGGER.info(f"中断信号 action=准备关闭")
                await self.stop()

    async def stop(self):
        """
        优雅关闭消费者

        关闭所有线程池和连接
        """
        LOGGER.info(f"关闭中")
        self._running = False

        if self._cleanup_task:
            self._cleanup_task.cancel()
            try:
                await self._cleanup_task
            except asyncio.CancelledError:
                pass

        for task_type in list(self._executors.keys()):
            await self._cleanup_executor(task_type)

        await super().close()

        LOGGER.info(f"已关闭 processed={self._metrics.processed_count}, errors={self._metrics.error_count}")

    def get_stats(self) -> Dict[str, Any]:
        """
        获取消费者统计信息

        Returns:
            dict: 包含处理计数、错误计数、延迟等指标
        """
        return {
            "processed_count": self._metrics.processed_count,
            "error_count": self._metrics.error_count,
            "avg_latency_ms": self._metrics.avg_latency_ms,
            "running": self._running,
            "executors_count": len(self._executors),
            "queues_count": len(self._queues),
            "metrics": self._metrics.to_dict(),
        }

    def get_task_stats(self, task_type: str) -> Optional[Dict[str, Any]]:
        """
        获取特定任务的统计信息

        Args:
            task_type: 任务类型

        Returns:
            dict: 任务统计信息
        """
        if task_type not in self._task_metrics:
            return None
        return self._task_metrics[task_type].to_dict()

    def get_all_task_stats(self) -> Dict[str, Dict[str, Any]]:
        """
        获取所有任务的统计信息

        Returns:
            dict: 所有任务的统计信息
        """
        return {
            task_type: metrics.to_dict()
            for task_type, metrics in self._task_metrics.items()
        }
