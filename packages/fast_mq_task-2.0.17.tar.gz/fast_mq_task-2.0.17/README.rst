fast-mq-task
============

Fast RabbitMQ task management library for asynchronous message handling.

Features
--------

* Asynchronous RabbitMQ message handling
* Task queue management with Pydantic validation
* Robust retry mechanisms with Tenacity
* Easy-to-use decorators for consumers and producers
* Support for both sync and async handlers

Installation
------------

.. code-block:: bash

    pip install fast-mq-task

Quick Start
-----------

Producer Example:

.. code-block:: python

    from fast_mq_task import Producer
    from fast_mq_task.models import TaskMessage

    producer = Producer()
    await producer.publish_task(task_message)

Consumer Example:

.. code-block:: python

    from fast_mq_task import Consumer
    from fast_mq_task.register import consumer

    @consumer(queue_name="task_queue")
    async def handle_task(message: TaskMessage):
        # Process your task here
        pass

Requirements
------------

* Python >= 3.7
* aio-pika
* pydantic
* tenacity

License
-------

BSD License

Author
------

zsodata <team@zso.io>
