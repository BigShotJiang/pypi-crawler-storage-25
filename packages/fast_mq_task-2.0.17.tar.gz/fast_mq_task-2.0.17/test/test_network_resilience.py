# -*- coding: utf-8 -*-
"""
网络容错能力测试

验证在网络环境不稳定或 MQ 服务器可能偶尔踢链接的情况下的适应能力
"""
import asyncio
import pytest
from unittest.mock import AsyncMock, patch, MagicMock
from aiormq import ConnectionClosed, ChannelClosed, AMQPConnectionError, ChannelInvalidStateError

from fast_mq_task.client import RabbitMQClient
from fast_mq_task.producer import TaskProducer
from fast_mq_task.models import TaskMessage


class TestNetworkResilience:
    """网络容错能力测试"""

    @pytest.mark.asyncio
    async def test_heartbeat_config(self):
        """测试心跳配置是否正确"""
        amqp_url = "amqp://guest:guest@localhost:5672/test"
        client = RabbitMQClient(amqp_url)
        
        # 验证 connect 方法调用时包含 heartbeat 参数
        with patch('aio_pika.connect_robust') as mock_connect:
            mock_connection = AsyncMock()
            mock_connection.is_closed = False
            mock_connection.add_close_callback = MagicMock()
            mock_connect.return_value = mock_connection
            
            await client.connect()
            
            # 验证 heartbeat 参数
            call_kwargs = mock_connect.call_args.kwargs
            assert 'heartbeat' in call_kwargs, "heartbeat 参数未设置"
            assert call_kwargs['heartbeat'] == 60, f"heartbeat 应为 60，实际为 {call_kwargs['heartbeat']}"
            print("[OK] 心跳配置正确：heartbeat=60")

    @pytest.mark.asyncio
    async def test_connection_callback(self):
        """测试连接断开回调是否注册"""
        amqp_url = "amqp://guest:guest@localhost:5672/test"
        client = RabbitMQClient(amqp_url)
        
        with patch('aio_pika.connect_robust') as mock_connect:
            mock_connection = AsyncMock()
            mock_connection.is_closed = False
            mock_connection.add_close_callback = MagicMock()
            mock_connect.return_value = mock_connection
            
            await client.connect()
            
            # 验证回调已注册
            mock_connection.add_close_callback.assert_called_once()
            print("[OK] 连接断开回调已注册")

    @pytest.mark.asyncio
    async def test_connection_retry_exponential_backoff(self):
        """测试连接重试使用指数退避"""
        amqp_url = "amqp://guest:guest@localhost:5672/test"
        client = RabbitMQClient(amqp_url)
        
        # 验证重试装饰器配置
        from tenacity import Retrying
        retry_func = client.connect
        
        # 获取重试策略
        retry_obj = retry_func.retry
        assert retry_obj is not None, "重试装饰器未配置"
        
        # 验证等待策略是指数退避
        wait_strategy = retry_obj.wait
        assert wait_strategy is not None, "等待策略未配置"
        
        # 验证是指数退避（wait_exponential）
        from tenacity.wait import wait_exponential
        assert isinstance(wait_strategy, wait_exponential), \
            f"等待策略应为指数退避，实际为 {type(wait_strategy)}"
        
        print("[OK] 连接重试使用指数退避策略")

    @pytest.mark.asyncio
    async def test_publish_task_retry(self):
        """测试 publish_task 方法有重试机制"""
        amqp_url = "amqp://guest:guest@localhost:5672/test"
        producer = TaskProducer(amqp_url)
        
        # 验证重试装饰器配置
        from tenacity import Retrying
        retry_func = producer.publish_task
        
        # 获取重试策略
        retry_obj = retry_func.retry
        assert retry_obj is not None, "publish_task 重试装饰器未配置"
        
        # 验证等待策略是指数退避
        wait_strategy = retry_obj.wait
        from tenacity.wait import wait_exponential
        assert isinstance(wait_strategy, wait_exponential), \
            "publish_task 应使用指数退避策略"
        
        print("[OK] publish_task 使用指数退避重试策略")

    @pytest.mark.asyncio
    async def test_connection_closed_callback_execution(self):
        """测试连接断开回调函数执行"""
        amqp_url = "amqp://guest:guest@localhost:5672/test"
        client = RabbitMQClient(amqp_url)
        
        # 预填充一些数据
        client._exchanges['test_exchange'] = MagicMock()
        client._queues['test_queue'] = MagicMock()
        
        # 调用回调函数
        mock_connection = MagicMock()
        client._on_connection_closed(mock_connection, "connection reset")
        
        # 验证资源已清理
        assert len(client._exchanges) == 0, "交换机缓存未清理"
        assert len(client._queues) == 0, "队列缓存未清理"
        
        print("[OK] 连接断开回调函数正确执行并清理资源")

    @pytest.mark.asyncio
    async def test_retry_on_connection_error(self):
        """测试连接错误时自动重试"""
        amqp_url = "amqp://guest:guest@localhost:5672/test"
        producer = TaskProducer(amqp_url)
        
        call_count = 0
        
        async def mock_ensure_declare(*args, **kwargs):
            nonlocal call_count
            call_count += 1
            if call_count < 2:
                raise AMQPConnectionError("模拟连接错误")
            # 创建 mock 队列和交换机
            mock_queue = AsyncMock()
            mock_queue.channel = AsyncMock()
            mock_exchange = AsyncMock()
            return mock_queue, mock_exchange
        
        with patch.object(producer, 'ensure_declare', side_effect=mock_ensure_declare):
            with patch.object(producer._metrics, 'record_published'):
                task = TaskMessage(task_type="test", data={"key": "value"})
                
                # 应该重试成功
                result = await producer.publish_task(task)
                
                assert result is True, "发布应成功"
                assert call_count == 2, f"应重试 2 次，实际 {call_count} 次"
                
                print(f"[OK] 连接错误时自动重试成功（调用 {call_count} 次）")

    @pytest.mark.asyncio
    async def test_retry_exhausted_on_persistent_error(self):
        """测试持续错误时重试耗尽"""
        amqp_url = "amqp://guest:guest@localhost:5672/test"
        producer = TaskProducer(amqp_url, enable_metrics=False)
        
        async def mock_ensure_declare(*args, **kwargs):
            raise AMQPConnectionError("持续连接错误")
        
        with patch.object(producer, 'ensure_declare', side_effect=mock_ensure_declare):
            task = TaskMessage(task_type="test", data={"key": "value"})
            
            # 应该重试耗尽并抛出异常
            with pytest.raises(AMQPConnectionError):
                await producer.publish_task(task)
            
            print("[OK] 持续错误时重试正确耗尽")


@pytest.mark.asyncio
async def test_heartbeat_parameter_in_connect():
    """独立测试：验证 heartbeat 参数"""
    print("\n=== 测试心跳参数配置 ===")
    amqp_url = "amqp://guest:guest@localhost:5672/test"
    client = RabbitMQClient(amqp_url)
    
    with patch('aio_pika.connect_robust') as mock_connect:
        mock_connection = AsyncMock()
        mock_connection.is_closed = False
        mock_connection.add_close_callback = MagicMock()
        mock_connect.return_value = mock_connection
        
        await client.connect()
        
        # 验证调用参数
        assert mock_connect.called, "connect_robust 未被调用"
        call_kwargs = mock_connect.call_args.kwargs
        
        assert 'heartbeat' in call_kwargs, "缺少 heartbeat 参数"
        assert call_kwargs['heartbeat'] == 60, f"heartbeat 值错误：{call_kwargs['heartbeat']}"
        print(f"[OK] heartbeat={call_kwargs['heartbeat']} (60 秒)")


if __name__ == '__main__':
    pytest.main([__file__, '-v', '-s'])
