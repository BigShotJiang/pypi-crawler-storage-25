# -*- coding: utf-8 -*-
"""
测试参数级合并逻辑

验证场景：
1. 装饰器注册 + task_config 仅指定 handler → 保留装饰器的 prefetch 和 max_workers
2. 装饰器注册 + task_config 指定 handler 和部分参数 → 配置参数覆盖，未指定的保留装饰器值
3. 装饰器注册 + task_config 仅指定部分参数 → 保留装饰器的 handler 和其他参数
4. 仅装饰器注册 → 使用装饰器的所有参数
5. 仅 task_config 注册 → 使用 task_config 的所有参数
"""
import asyncio
import sys
import os

# 添加项目根目录到路径
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from fast_mq_task import TaskRegistry, task_handler, TaskConsumer, TaskMessage


# 测试 handler 函数
async def decorator_handler(task: TaskMessage):
    """装饰器注册的 handler"""
    print(f"decorator_handler 处理任务: {task.task_type}")


async def config_handler(task: TaskMessage):
    """task_config 指定的 handler"""
    print(f"config_handler 处理任务: {task.task_type}")


async def partial_override_handler(task: TaskMessage):
    """部分覆盖的 handler"""
    print(f"partial_override_handler 处理任务: {task.task_type}")


def test_scenario_1():
    """场景 1：task_config 仅指定 handler，保留装饰器的 prefetch 和 max_workers"""
    print("\n" + "=" * 60)
    print("场景 1：task_config 仅指定 handler")
    print("=" * 60)
    
    # 清空注册表
    TaskRegistry.clear_handlers()
    
    # 装饰器注册
    @task_handler(task_type="test.scenario1", prefetch=20, max_workers=8)
    async def handler1(task: TaskMessage):
        pass
    
    # 验证装饰器注册
    meta = TaskRegistry.get_handler("test.scenario1")
    assert meta is not None, "装饰器注册失败"
    assert meta.prefetch == 20, f"装饰器 prefetch 错误: {meta.prefetch}"
    assert meta.max_workers == 8, f"装饰器 max_workers 错误: {meta.max_workers}"
    print(f"[OK] 装饰器注册成功: prefetch={meta.prefetch}, max_workers={meta.max_workers}")
    
    # 模拟 Consumer 初始化时的参数合并
    from fast_mq_task.consumer import TaskConfig
    
    task_config = {
        "test.scenario1": {
            "handler": config_handler,  # 仅指定 handler
        }
    }
    
    # 验证参数合并逻辑
    config = TaskConfig(**task_config["test.scenario1"])
    decorated_meta = TaskRegistry.get_handler("test.scenario1")
    
    # 模拟合并逻辑
    if config.handler and callable(config.handler):
        if decorated_meta:
            merged_prefetch = config.prefetch if config.prefetch != TaskConfig.model_fields['prefetch'].default else decorated_meta.prefetch
            merged_max_workers = config.max_workers if config.max_workers != TaskConfig.model_fields['max_workers'].default else decorated_meta.max_workers
            
            decorated_meta.handler_func = config.handler
            if merged_prefetch is not None:
                decorated_meta.prefetch = merged_prefetch
            if merged_max_workers is not None:
                decorated_meta.max_workers = merged_max_workers
    
    # 验证合并结果
    meta = TaskRegistry.get_handler("test.scenario1")
    assert meta.handler_func == config_handler, "handler 未更新"
    assert meta.prefetch == 20, f"prefetch 应保留装饰器值: {meta.prefetch}"
    assert meta.max_workers == 8, f"max_workers 应保留装饰器值: {meta.max_workers}"
    print(f"[OK] 参数合并成功: handler=config_handler, prefetch={meta.prefetch}, max_workers={meta.max_workers}")
    print("[OK] 场景 1 测试通过\n")


def test_scenario_2():
    """场景 2：task_config 指定 handler 和 prefetch，保留装饰器的 max_workers"""
    print("\n" + "=" * 60)
    print("场景 2：task_config 指定 handler 和 prefetch")
    print("=" * 60)
    
    # 清空注册表
    TaskRegistry.clear_handlers()
    
    # 装饰器注册
    @task_handler(task_type="test.scenario2", prefetch=20, max_workers=8)
    async def handler2(task: TaskMessage):
        pass
    
    # 验证装饰器注册
    meta = TaskRegistry.get_handler("test.scenario2")
    assert meta.prefetch == 20, f"装饰器 prefetch 错误: {meta.prefetch}"
    assert meta.max_workers == 8, f"装饰器 max_workers 错误: {meta.max_workers}"
    print(f"[OK] 装饰器注册成功: prefetch={meta.prefetch}, max_workers={meta.max_workers}")
    
    # 模拟 Consumer 初始化时的参数合并
    from fast_mq_task.consumer import TaskConfig
    
    task_config = {
        "test.scenario2": {
            "handler": config_handler,
            "prefetch": 50,  # 覆盖 prefetch
        }
    }
    
    # 验证参数合并逻辑
    config = TaskConfig(**task_config["test.scenario2"])
    decorated_meta = TaskRegistry.get_handler("test.scenario2")
    
    # 模拟合并逻辑
    if config.handler and callable(config.handler):
        if decorated_meta:
            merged_prefetch = config.prefetch if config.prefetch != TaskConfig.model_fields['prefetch'].default else decorated_meta.prefetch
            merged_max_workers = config.max_workers if config.max_workers != TaskConfig.model_fields['max_workers'].default else decorated_meta.max_workers
            
            decorated_meta.handler_func = config.handler
            if merged_prefetch is not None:
                decorated_meta.prefetch = merged_prefetch
            if merged_max_workers is not None:
                decorated_meta.max_workers = merged_max_workers
    
    # 验证合并结果
    meta = TaskRegistry.get_handler("test.scenario2")
    assert meta.handler_func == config_handler, "handler 未更新"
    assert meta.prefetch == 50, f"prefetch 应使用配置值: {meta.prefetch}"
    assert meta.max_workers == 8, f"max_workers 应保留装饰器值: {meta.max_workers}"
    print(f"[OK] 参数合并成功: handler=config_handler, prefetch={meta.prefetch}, max_workers={meta.max_workers}")
    print("[OK] 场景 2 测试通过\n")


def test_scenario_3():
    """场景 3：task_config 仅指定部分参数，保留装饰器的 handler"""
    print("\n" + "=" * 60)
    print("场景 3：task_config 仅指定部分参数")
    print("=" * 60)
    
    # 清空注册表
    TaskRegistry.clear_handlers()
    
    # 装饰器注册
    @task_handler(task_type="test.scenario3", prefetch=20, max_workers=8)
    async def handler3(task: TaskMessage):
        pass
    
    # 验证装饰器注册
    meta = TaskRegistry.get_handler("test.scenario3")
    assert meta.handler_func == handler3, "装饰器 handler 错误"
    assert meta.prefetch == 20, f"装饰器 prefetch 错误: {meta.prefetch}"
    assert meta.max_workers == 8, f"装饰器 max_workers 错误: {meta.max_workers}"
    print(f"[OK] 装饰器注册成功: handler={meta.handler_func.__name__}, prefetch={meta.prefetch}, max_workers={meta.max_workers}")
    
    # 模拟 Consumer 初始化时的参数合并
    from fast_mq_task.consumer import TaskConfig
    
    task_config = {
        "test.scenario3": {
            "prefetch": 50,  # 仅覆盖 prefetch
            "max_workers": 15,  # 仅覆盖 max_workers
        }
    }
    
    # 验证参数合并逻辑
    config = TaskConfig(**task_config["test.scenario3"])
    decorated_meta = TaskRegistry.get_handler("test.scenario3")
    
    # 模拟合并逻辑（无 handler 覆盖，但更新参数）
    if not config.handler:
        # 使用装饰器的 handler，但配置参数使用 config 的值
        if config.prefetch != TaskConfig.model_fields['prefetch'].default or config.max_workers != TaskConfig.model_fields['max_workers'].default:
            if config.prefetch != TaskConfig.model_fields['prefetch'].default:
                decorated_meta.prefetch = config.prefetch
            if config.max_workers != TaskConfig.model_fields['max_workers'].default:
                decorated_meta.max_workers = config.max_workers
    
    # 验证最终结果
    meta = TaskRegistry.get_handler("test.scenario3")
    assert meta.handler_func == handler3, "handler 应保持装饰器值"
    assert meta.prefetch == 50, f"prefetch 应使用配置值: {meta.prefetch}"
    assert meta.max_workers == 15, f"max_workers 应使用配置值: {meta.max_workers}"
    print(f"[OK] 参数合并成功: handler={meta.handler_func.__name__}, prefetch={meta.prefetch}, max_workers={meta.max_workers}")
    print("[OK] 场景 3 测试通过\n")


def test_scenario_4():
    """场景 4：仅装饰器注册"""
    print("\n" + "=" * 60)
    print("场景 4：仅装饰器注册")
    print("=" * 60)
    
    # 清空注册表
    TaskRegistry.clear_handlers()
    
    # 装饰器注册
    @task_handler(task_type="test.scenario4", prefetch=20, max_workers=8)
    async def handler4(task: TaskMessage):
        pass
    
    # 验证装饰器注册
    meta = TaskRegistry.get_handler("test.scenario4")
    assert meta is not None, "装饰器注册失败"
    assert meta.handler_func == handler4, "handler 错误"
    assert meta.prefetch == 20, f"prefetch 错误: {meta.prefetch}"
    assert meta.max_workers == 8, f"max_workers 错误: {meta.max_workers}"
    print(f"[OK] 装饰器注册成功: handler={meta.handler_func.__name__}, prefetch={meta.prefetch}, max_workers={meta.max_workers}")
    print("[OK] 场景 4 测试通过\n")


def test_scenario_5():
    """场景 5：仅 task_config 注册"""
    print("\n" + "=" * 60)
    print("场景 5：仅 task_config 注册")
    print("=" * 60)
    
    # 清空注册表
    TaskRegistry.clear_handlers()
    
    # 模拟 Consumer 初始化时的注册
    from fast_mq_task.consumer import TaskConfig
    
    task_config = {
        "test.scenario5": {
            "handler": config_handler,
            "prefetch": 30,
            "max_workers": 10,
        }
    }
    
    config = TaskConfig(**task_config["test.scenario5"])
    TaskRegistry.register_handler("test.scenario5", config.handler, config.prefetch, config.max_workers)
    
    # 验证注册结果
    meta = TaskRegistry.get_handler("test.scenario5")
    assert meta is not None, "配置注册失败"
    assert meta.handler_func == config_handler, "handler 错误"
    assert meta.prefetch == 30, f"prefetch 错误: {meta.prefetch}"
    assert meta.max_workers == 10, f"max_workers 错误: {meta.max_workers}"
    print(f"[OK] 配置注册成功: handler={meta.handler_func.__name__}, prefetch={meta.prefetch}, max_workers={meta.max_workers}")
    print("[OK] 场景 5 测试通过\n")


if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("参数级合并逻辑测试")
    print("=" * 60)
    
    try:
        test_scenario_1()
        test_scenario_2()
        test_scenario_3()
        test_scenario_4()
        test_scenario_5()
        
        print("=" * 60)
        print("[SUCCESS] 所有测试通过！")
        print("=" * 60)
    except AssertionError as e:
        print(f"\n[FAILED] 测试失败: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"\n[ERROR] 测试异常: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
