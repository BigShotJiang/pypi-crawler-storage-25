# -*- coding: utf-8 -*-
"""
混合配置模式测试脚本
验证装饰器和 task_config 的优先级关系
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fast_mq_task.register import task_handler, TaskRegistry
from fast_mq_task.consumer import TaskConfig
from fast_mq_task.models import TaskMessage


def test_decorator_only():
    """测试仅使用装饰器"""
    print("\n=== Test 1: Decorator Only ===")
    TaskRegistry.clear_handlers()
    
    @task_handler(task_type="test.decorator_only", prefetch=20, max_workers=8)
    async def handler(task: TaskMessage):
        pass
    
    meta = TaskRegistry.get_handler("test.decorator_only")
    assert meta is not None, "Processor should be registered"
    assert meta.prefetch == 20, f"prefetch should be 20, got {meta.prefetch}"
    assert meta.max_workers == 8, f"max_workers should be 8, got {meta.max_workers}"
    print("[PASS] Decorator registration successful")


def test_config_only():
    """测试仅使用 task_config"""
    print("\n=== Test 2: Config Only ===")
    TaskRegistry.clear_handlers()
    
    async def handler(task: TaskMessage):
        pass
    
    TaskRegistry.register_handler("test.config_only", handler, prefetch=25, max_workers=10)
    
    meta = TaskRegistry.get_handler("test.config_only")
    assert meta is not None, "Processor should be registered"
    assert meta.prefetch == 25, f"prefetch should be 25, got {meta.prefetch}"
    assert meta.max_workers == 10, f"max_workers should be 10, got {meta.max_workers}"
    print("[PASS] Config registration successful")


def test_mixed_mode_no_override():
    """测试混合模式：task_config 不覆盖装饰器配置"""
    print("\n=== Test 3: Mixed Mode (No Override) ===")
    TaskRegistry.clear_handlers()
    
    @task_handler(task_type="test.mixed_no_override", prefetch=20, max_workers=8)
    async def handler(task: TaskMessage):
        pass
    
    decorated_meta = TaskRegistry.get_handler("test.mixed_no_override")
    assert decorated_meta is not None, "Decorator should have registered processor"
    assert decorated_meta.prefetch == 20, "Should use decorator's prefetch"
    assert decorated_meta.max_workers == 8, "Should use decorator's max_workers"
    print("[PASS] Mixed mode (no override) successful, using decorator config")


def test_mixed_mode_with_override():
    """测试混合模式：task_config 覆盖装饰器配置"""
    print("\n=== Test 4: Mixed Mode (With Override) ===")
    TaskRegistry.clear_handlers()
    
    @task_handler(task_type="test.mixed_override", prefetch=20, max_workers=8)
    async def handler(task: TaskMessage):
        pass
    
    config = TaskConfig(
        prefetch=50,
        max_workers=15,
        timeout=60,
        max_retries=3,
    )
    
    decorated_meta = TaskRegistry.get_handler("test.mixed_override")
    assert decorated_meta is not None, "Decorator should have registered processor"
    assert config.prefetch == 50, "task_config prefetch should be 50"
    assert config.max_workers == 15, "task_config max_workers should be 15"
    print("[PASS] Mixed mode (with override) successful, task_config takes priority")


def test_config_override_handler():
    """测试 task_config 覆盖 handler"""
    print("\n=== Test 5: Config Override Handler ===")
    TaskRegistry.clear_handlers()
    
    @task_handler(task_type="test.override_handler", prefetch=20)
    async def decorator_handler(task: TaskMessage):
        pass
    
    async def config_handler(task: TaskMessage):
        pass
    
    decorated_meta = TaskRegistry.get_handler("test.override_handler")
    assert decorated_meta is not None, "Decorator should have registered processor"
    
    TaskRegistry.register_handler("test.override_handler", config_handler, prefetch=30)
    
    new_meta = TaskRegistry.get_handler("test.override_handler")
    assert new_meta.handler_func == config_handler, "handler should be overridden"
    assert new_meta.prefetch == 30, "prefetch should be overridden"
    print("[PASS] Config override handler successful")


def test_clear_handlers():
    """测试清空处理器"""
    print("\n=== Test 6: Clear Handlers ===")
    TaskRegistry.clear_handlers()
    
    @task_handler(task_type="test.clear", prefetch=10)
    async def handler(task: TaskMessage):
        pass
    
    assert TaskRegistry.get_handler("test.clear") is not None, "Processor should be registered"
    
    TaskRegistry.clear_handlers()
    assert TaskRegistry.get_handler("test.clear") is None, "Processor should be cleared"
    print("[PASS] Clear handlers successful")


if __name__ == "__main__":
    print("=" * 60)
    print("Mixed Configuration Mode Test")
    print("=" * 60)
    
    try:
        test_decorator_only()
        test_config_only()
        test_mixed_mode_no_override()
        test_mixed_mode_with_override()
        test_config_override_handler()
        test_clear_handlers()
        
        print("\n" + "=" * 60)
        print("[SUCCESS] All tests passed!")
        print("=" * 60)
    except AssertionError as e:
        print(f"\n[FAIL] Test failed: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"\n[ERROR] Test exception: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
