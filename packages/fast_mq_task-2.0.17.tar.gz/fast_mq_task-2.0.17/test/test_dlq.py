# -*- coding: utf-8 -*-
"""
死信队列功能测试脚本
测试死信队列的完整功能
"""
import asyncio
import os
import sys

# 设置环境变量
os.environ['APP_CODE'] = 'test'

# 添加项目路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fast_mq_task.register import task_handler
from fast_mq_task.models import TaskMessage
from fast_mq_task.producer import TaskProducer
from fast_mq_task.consumer import TaskConsumer
from fast_mq_task.exceptions import DropMessageException, RequeueMessageException


# 测试配置
RABBITMQ_URL = os.getenv('RABBITMQ_URL', 'amqp://root:Dangerous!@192.168.10.99:5672/fast_sku')
TEST_TASK_TYPE = "dlq.test"


# ==================== 测试处理器 ====================

@task_handler(task_type=TEST_TASK_TYPE, prefetch=5)
async def handle_dlq_test(task: TaskMessage):
    """
    测试处理器：模拟失败场景
    """
    data = task.data
    scenario = data.get('scenario', 'success')
    
    print(f"\n处理任务：task_id={task.task_id}, scenario={scenario}")
    
    if scenario == 'fail_immediate':
        # 场景 1: 立即失败，应该进入死信队列
        print(f"  ❌ 模拟立即失败")
        raise DropMessageException("测试：主动丢弃消息")
    
    elif scenario == 'fail_requeue':
        # 场景 2: 重试失败，达到最大重试次数后进入死信队列
        retry_count = data.get('retry_count', 0)
        print(f"  ⚠️ 模拟重试失败，retry_count={retry_count}")
        raise RequeueMessageException(f"测试：需要重试 {retry_count}")
    
    elif scenario == 'fail_exception':
        # 场景 3: 严重异常，直接进入死信队列
        print(f"  ❌ 模拟严重异常")
        raise ValueError("测试：严重异常")
    
    else:
        # 场景 4: 成功处理
        print(f"  ✅ 处理成功")


# ==================== 测试函数 ====================

async def test_dlq_declaration():
    """测试 1: 验证死信队列是否被正确创建"""
    print("\n" + "="*60)
    print("测试 1: 验证死信队列声明")
    print("="*60)
    
    try:
        # 创建生产者并声明队列
        async with TaskProducer(RABBITMQ_URL) as producer:
            _, exchange = await producer.ensure_declare(task_type=TEST_TASK_TYPE)
            
            # 检查队列是否创建
            main_queue_name = f"fast.test.{TEST_TASK_TYPE}"
            dlq_queue_name = f"{main_queue_name}.dlq"
            dlx_exchange_name = f"fast.test.dlx"
            
            print(f"\n✓ 主队列：{main_queue_name}")
            print(f"✓ 死信队列：{dlq_queue_name}")
            print(f"✓ 死信交换机：{dlx_exchange_name}")
            
            # 获取队列统计信息
            main_stats = await producer.get_queue_stats(main_queue_name)
            dlq_stats = await producer.get_queue_stats(dlq_queue_name)
            
            print(f"\n主队列统计：{main_stats}")
            print(f"死信队列统计：{dlq_stats}")
            
            if dlq_stats:
                print(f"\n✅ 死信队列创建成功！")
                return True
            else:
                print(f"\n❌ 死信队列创建失败！")
                return False
                
    except Exception as e:
        print(f"\n❌ 测试失败：{e}")
        import traceback
        traceback.print_exc()
        return False


async def test_send_to_dlq():
    """测试 2: 发送消息到死信队列"""
    print("\n" + "="*60)
    print("测试 2: 发送消息到死信队列")
    print("="*60)
    
    try:
        # 先启动消费者
        consumer = await TaskConsumer(
            amqp_url=RABBITMQ_URL,
            task_config={
                TEST_TASK_TYPE: {
                    "handler": handle_dlq_test,
                    "max_workers": 2,
                    "prefetch": 5,
                    "max_retries": 0,  # 不重试，直接进入死信队列
                }
            },
            default_prefetch=10,
        ).connect()
        
        # 启动消费者任务
        consumer_task = asyncio.create_task(consumer.start(never_stop=True))
        print("\n✓ 消费者已启动")
        
        # 等待消费者准备就绪
        await asyncio.sleep(2)
        
        try:
            # 发布测试消息
            async with TaskProducer(RABBITMQ_URL) as producer:
                # 发送会失败的消息
                task = TaskMessage(
                    task_type=TEST_TASK_TYPE,
                    data={'scenario': 'fail_immediate'},
                )
                await producer.publish_task(task)
                print(f"\n✓ 已发送测试消息：task_id={task.task_id}")
                
                # 等待消息被处理并进入死信队列
                print("\n等待 5 秒让消息进入死信队列...")
                await asyncio.sleep(5)
                
                # 检查死信队列
                dlq_queue_name = f"fast.test.{TEST_TASK_TYPE}.dlq"
                dlq_stats = await producer.get_queue_stats(dlq_queue_name)
                
                print(f"\n死信队列统计：{dlq_stats}")
                
                if dlq_stats and dlq_stats.get('message_count', 0) > 0:
                    print(f"\n✅ 消息已成功进入死信队列！")
                    result = True
                else:
                    print(f"\n⚠️ 死信队列为空，可能未正确配置")
                    result = False
        finally:
            # 停止消费者
            await consumer.stop()
            consumer_task.cancel()
            try:
                await consumer_task
            except asyncio.CancelledError:
                pass
        
        return result
                
    except Exception as e:
        print(f"\n❌ 测试失败：{e}")
        import traceback
        traceback.print_exc()
        return False


async def test_dlq_republish():
    """测试 3: 从死信队列重放消息"""
    print("\n" + "="*60)
    print("测试 3: 从死信队列重放消息")
    print("="*60)
    
    try:
        async with TaskProducer(RABBITMQ_URL) as producer:
            dlq_queue_name = f"fast.test.{TEST_TASK_TYPE}.dlq"
            
            # 先查看死信队列消息
            print(f"\n查看死信队列消息...")
            dlq_messages = await producer.get_dlq_messages(TEST_TASK_TYPE)
            print(f"死信队列消息：{dlq_messages}")
            
            # 重放消息
            print(f"\n重放死信队列消息...")
            result = await producer.republish_from_dlq(
                task_type=TEST_TASK_TYPE,
                limit=10
            )
            
            print(f"\n重放结果：{result}")
            
            if result.get('success'):
                print(f"\n✅ 消息重放成功！重放数量：{result.get('republished_count')}")
                return True
            else:
                print(f"\n❌ 消息重放失败：{result.get('error')}")
                return False
                
    except Exception as e:
        print(f"\n❌ 测试失败：{e}")
        import traceback
        traceback.print_exc()
        return False


async def test_consumer_with_dlq():
    """测试 4: 消费者处理死信队列"""
    print("\n" + "="*60)
    print("测试 4: 消费者处理死信队列（手动测试）")
    print("="*60)
    
    print("\n说明：此测试需要手动验证")
    print("步骤：")
    print("1. 启动消费者（运行 10 秒）")
    print("2. 发送 3 条测试消息（成功、失败、异常各一条）")
    print("3. 观察日志，确认失败消息进入死信队列")
    print("4. 检查死信队列消息数量")
    
    # 创建消费者
    consumer = await TaskConsumer(
        amqp_url=RABBITMQ_URL,
        task_config={
            TEST_TASK_TYPE: {
                "handler": handle_dlq_test,
                "max_workers": 2,
                "prefetch": 5,
                "max_retries": 3,
            }
        },
        default_prefetch=10,
    ).connect()
    
    # 启动消费者（运行 10 秒）
    print("\n启动消费者，运行 10 秒...")
    try:
        await asyncio.wait_for(consumer.start(never_stop=True), timeout=10.0)
    except asyncio.TimeoutError:
        pass
    finally:
        await consumer.stop()
    
    # 打印统计信息
    stats = consumer.get_stats()
    print(f"\n消费者统计：{stats}")
    
    print(f"\n✅ 消费者测试完成！请检查日志确认死信队列功能")
    return True


async def run_all_tests():
    """运行所有测试"""
    print("\n" + "="*60)
    print("死信队列功能完整测试")
    print("="*60)
    
    results = []
    
    # 测试 1: 死信队列声明
    results.append(("死信队列声明", await test_dlq_declaration()))
    await asyncio.sleep(2)
    
    # 测试 2: 发送消息到死信队列
    results.append(("发送消息到死信队列", await test_send_to_dlq()))
    await asyncio.sleep(2)
    
    # 测试 3: 死信队列重放
    results.append(("死信队列重放", await test_dlq_republish()))
    await asyncio.sleep(2)
    
    # 测试 4: 消费者处理（可选）
    # results.append(("消费者处理", await test_consumer_with_dlq()))
    
    # 打印测试结果
    print("\n" + "="*60)
    print("测试结果汇总")
    print("="*60)
    
    for test_name, result in results:
        status = "✅ 通过" if result else "❌ 失败"
        print(f"{status} - {test_name}")
    
    passed = sum(1 for _, r in results if r)
    total = len(results)
    print(f"\n总计：{passed}/{total} 测试通过")
    
    return passed == total


# ==================== 主程序 ====================

if __name__ == '__main__':
    try:
        success = asyncio.run(run_all_tests())
        sys.exit(0 if success else 1)
    except KeyboardInterrupt:
        print("\n\n测试被用户中断")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ 测试异常：{e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
