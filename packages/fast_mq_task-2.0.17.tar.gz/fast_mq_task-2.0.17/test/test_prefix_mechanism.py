# -*- coding: utf-8 -*-
"""
前缀机制测试脚本
测试 Keys 类的前缀优先级机制和实例化功能
"""
import os
import sys
import asyncio

# 添加项目路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fast_mq_task import RabbitKeys, TaskProducer, TaskConsumer, TaskMessage
from fast_mq_task.client import RabbitMQClient


# ==================== Keys 类基础测试 ====================

def test_keys_default_prefixes():
    """测试 1: 默认前缀（无环境变量，无参数）"""
    print("\n" + "="*60)
    print("测试 1: 默认前缀")
    print("="*60)

    keys = RabbitKeys()

    assert keys.app_prefix == 'app', f"期望 'app'，实际：{keys.app_prefix}"
    assert keys.series_prefix == 'fast', f"期望 'fast'，实际：{keys.series_prefix}"

    assert keys.get_exchange_name() == 'fast.app'
    assert keys.get_routing_key('email.send') == 'fast.app.email.send'
    assert keys.get_queue_name('email.send') == 'fast.app.email.send'
    assert keys.get_dlq_queue_name('email.send') == 'fast.app.email.send.dlq'
    assert keys.get_dlx_exchange_name() == 'fast.app.dlx'

    print(f"[PASS] 默认前缀测试通过 | {keys}")
    return True


def test_keys_with_parameters():
    """测试 2: 构造函数传入参数"""
    print("\n" + "="*60)
    print("测试 2: 构造函数传入参数")
    print("="*60)

    keys = RabbitKeys(app_prefix='myapp', series_prefix='prod')

    assert keys.app_prefix == 'myapp'
    assert keys.series_prefix == 'prod'

    assert keys.get_exchange_name() == 'prod.myapp'
    assert keys.get_routing_key('sms.send') == 'prod.myapp.sms.send'

    print(f"[PASS] 参数传入测试通过 | {keys}")
    return True


def test_keys_with_environment_variables():
    """测试 3: 环境变量"""
    print("\n" + "="*60)
    print("测试 3: 环境变量")
    print("="*60)

    # 设置环境变量
    os.environ['MQT_APP_PREFIX'] = 'envapp'
    os.environ['MQT_SERIES_PREFIX'] = 'envseries'

    try:
        keys = RabbitKeys()

        assert keys.app_prefix == 'envapp', f"期望 'envapp'，实际：{keys.app_prefix}"
        assert keys.series_prefix == 'envseries', f"期望 'envseries'，实际：{keys.series_prefix}"

        print(f"[PASS] 环境变量测试通过 | {keys}")
        return True
    finally:
        # 清理环境变量
        del os.environ['MQT_APP_PREFIX']
        del os.environ['MQT_SERIES_PREFIX']


def test_keys_priority_parameters_over_env():
    """测试 4: 优先级 - 参数 > 环境变量"""
    print("\n" + "="*60)
    print("测试 4: 优先级 - 参数 > 环境变量")
    print("="*60)

    # 设置环境变量
    os.environ['MQT_APP_PREFIX'] = 'envapp'
    os.environ['MQT_SERIES_PREFIX'] = 'envseries'

    try:
        # 传入参数
        keys = RabbitKeys(app_prefix='paramapp', series_prefix='paramseries')

        assert keys.app_prefix == 'paramapp', f"期望 'paramapp'，实际：{keys.app_prefix}"
        assert keys.series_prefix == 'paramseries', f"期望 'paramseries'，实际：{keys.series_prefix}"

        print(f"[PASS] 优先级测试通过 | {keys}")
        return True
    finally:
        # 清理环境变量
        del os.environ['MQT_APP_PREFIX']
        del os.environ['MQT_SERIES_PREFIX']


def test_keys_app_code_fallback():
    """测试 5: APP_CODE 向后兼容（已移除）"""
    print("\n" + "="*60)
    print("测试 5: APP_CODE 向后兼容（已移除）")
    print("="*60)

    # 此测试已移除，因为不再支持 APP_CODE 环境变量
    print("[SKIP] APP_CODE 兼容测试已移除")
    return True


def test_keys_partial_parameters():
    """测试 6: 部分参数"""
    print("\n" + "="*60)
    print("测试 6: 部分参数")
    print("="*60)

    os.environ['MQT_SERIES_PREFIX'] = 'envseries'

    try:
        # 只传入 app_prefix
        keys = RabbitKeys(app_prefix='myapp')

        assert keys.app_prefix == 'myapp'
        assert keys.series_prefix == 'envseries'

        print(f"[PASS] 部分参数测试通过 | {keys}")
        return True
    finally:
        del os.environ['MQT_SERIES_PREFIX']


# ==================== 客户端集成测试 ====================

async def test_rabbitmq_client_with_prefixes():
    """测试 7: RabbitMQClient 集成"""
    print("\n" + "="*60)
    print("测试 7: RabbitMQClient 集成")
    print("="*60)

    # 使用自定义前缀创建客户端
    client = RabbitMQClient(
        amqp_url='amqp://guest:guest@localhost:5672/',
        app_prefix='testapp',
        series_prefix='testseries'
    )

    assert hasattr(client, 'keys'), "RabbitMQClient 应该有 keys 属性"
    assert client.rabbit_keys.app_prefix == 'testapp'
    assert client.rabbit_keys.series_prefix == 'testseries'

    assert client.rabbit_keys.get_exchange_name() == 'testseries.testapp'
    assert client.rabbit_keys.get_routing_key('task') == 'testseries.testapp.task'

    print(f"[PASS] RabbitMQClient 集成测试通过 | {client.rabbit_keys}")

    # 关闭客户端
    await client.close()
    return True


async def test_producer_with_prefixes():
    """测试 8: TaskProducer 集成"""
    print("\n" + "="*60)
    print("测试 8: TaskProducer 集成")
    print("="*60)

    # 使用自定义前缀创建生产者
    producer = TaskProducer(
        amqp_url='amqp://guest:guest@localhost:5672/',
        app_prefix='producerapp',
        series_prefix='produceseries'
    )

    assert producer.rabbit_keys.app_prefix == 'producerapp'
    assert producer.rabbit_keys.series_prefix == 'produceseries'

    # 测试键名生成
    assert producer.rabbit_keys.get_queue_name('email') == 'produceseries.producerapp.email'

    print(f"[PASS] TaskProducer 集成测试通过 | {producer.rabbit_keys}")

    # 关闭生产者
    await producer.close()
    return True


async def test_consumer_with_prefixes():
    """测试 9: TaskConsumer 集成"""
    print("\n" + "="*60)
    print("测试 9: TaskConsumer 集成")
    print("="*60)

    # 使用自定义前缀创建消费者
    consumer = TaskConsumer(
        amqp_url='amqp://guest:guest@localhost:5672/',
        app_prefix='consumerapp',
        series_prefix='consumeseries'
    )

    assert consumer.rabbit_keys.app_prefix == 'consumerapp'
    assert consumer.rabbit_keys.series_prefix == 'consumeseries'

    print(f"[PASS] TaskConsumer 集成测试通过 | {consumer.rabbit_keys}")

    # 关闭消费者
    await consumer.close()
    return True


def test_backward_compatibility_functions():
    """测试 10: 向后兼容函数（已移除）"""
    print("\n" + "="*60)
    print("测试 10: 向后兼容函数（已移除）")
    print("="*60)

    # 此测试已移除，因为向后兼容函数已清理
    print("[SKIP] 向后兼容函数测试已移除")
    return True


async def run_all_tests():
    """运行所有测试"""
    print("\n" + "="*60)
    print("前缀机制完整测试")
    print("="*60)

    results = []

    # 基础测试
    results.append(("默认前缀", test_keys_default_prefixes()))
    results.append(("构造函数参数", test_keys_with_parameters()))
    results.append(("环境变量", test_keys_with_environment_variables()))
    results.append(("优先级 - 参数>环境变量", test_keys_priority_parameters_over_env()))
    results.append(("APP_CODE 兼容", test_keys_app_code_fallback()))
    results.append(("部分参数", test_keys_partial_parameters()))
    results.append(("向后兼容函数", test_backward_compatibility_functions()))

    # 集成测试
    results.append(("RabbitMQClient 集成", await test_rabbitmq_client_with_prefixes()))
    results.append(("TaskProducer 集成", await test_producer_with_prefixes()))
    results.append(("TaskConsumer 集成", await test_consumer_with_prefixes()))

    # 打印结果
    print("\n" + "="*60)
    print("测试结果汇总")
    print("="*60)

    for test_name, result in results:
        status = "[PASS]" if result else "[FAIL]"
        print(f"{status} - {test_name}")

    passed = sum(1 for _, r in results if r)
    total = len(results)
    print(f"\n总计：{passed}/{total} 测试通过")

    return passed == total


# ==================== 主程序 ====================

if __name__ == '__main__':
    try:
        success = asyncio.run(run_all_tests())
        sys.exit(0 if success else 1)
    except KeyboardInterrupt:
        print("\n\n测试被用户中断")
        sys.exit(1)
    except Exception as e:
        print(f"\n[FAIL] 测试异常：{e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
