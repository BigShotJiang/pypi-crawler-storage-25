# -*- coding: utf-8 -*-
"""
active_tasks 参数功能测试
验证 active_tasks 参数是否正确过滤任务处理器
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fast_mq_task.register import task_handler, TaskRegistry
from fast_mq_task.consumer import TaskConsumer
from fast_mq_task.models import TaskMessage


def test_active_tasks_filter():
    """测试 active_tasks 过滤功能"""
    print("\n=== Test: active_tasks Filter ===")
    TaskRegistry.clear_handlers()
    
    # 注册多个处理器
    @task_handler(task_type="task.a", prefetch=10)
    async def handler_a(task: TaskMessage):
        pass
    
    @task_handler(task_type="task.b", prefetch=20)
    async def handler_b(task: TaskMessage):
        pass
    
    @task_handler(task_type="task.c", prefetch=30)
    async def handler_c(task: TaskMessage):
        pass
    
    # 验证所有处理器已注册
    assert len(TaskRegistry._handlers) == 3, "Should have 3 registered handlers"
    print("[PASS] All handlers registered")
    
    # 创建 consumer，仅激活 task.a 和 task.b
    consumer = TaskConsumer(
        amqp_url="amqp://test",
        task_config={
            "task.a": {"timeout": 60},
            "task.b": {"timeout": 60},
            "task.c": {"timeout": 60},
        },
        active_tasks=["task.a", "task.b"]
    )
    
    # 验证 active_tasks 设置
    assert consumer.active_tasks == {"task.a", "task.b"}, "active_tasks should be set correctly"
    print("[PASS] active_tasks set correctly")
    
    # 验证 task_config 包含所有任务
    assert len(consumer.task_config) == 3, "task_config should have all 3 tasks"
    print("[PASS] task_config has all tasks")
    
    consumer.task_config.clear()
    TaskRegistry.clear_handlers()
    print("[PASS] Cleanup successful")


def test_no_active_tasks():
    """测试不设置 active_tasks 的情况"""
    print("\n=== Test: No active_tasks ===")
    TaskRegistry.clear_handlers()
    
    @task_handler(task_type="task.all", prefetch=10)
    async def handler_all(task: TaskMessage):
        pass
    
    # 创建 consumer，不设置 active_tasks
    consumer = TaskConsumer(
        amqp_url="amqp://test",
        task_config={
            "task.all": {"timeout": 60},
        },
        active_tasks=None  # 不设置，激活所有任务
    )
    
    # 验证 active_tasks 为 None
    assert consumer.active_tasks is None, "active_tasks should be None"
    print("[PASS] active_tasks is None (all tasks activated)")
    
    consumer.task_config.clear()
    TaskRegistry.clear_handlers()


def test_empty_active_tasks():
    """测试 active_tasks 为空列表的情况"""
    print("\n=== Test: Empty active_tasks ===")
    TaskRegistry.clear_handlers()
    
    @task_handler(task_type="task.none", prefetch=10)
    async def handler_none(task: TaskMessage):
        pass
    
    # 创建 consumer，active_tasks 为空列表
    # 空列表会被视为 None，激活所有任务
    consumer = TaskConsumer(
        amqp_url="amqp://test",
        task_config={
            "task.none": {"timeout": 60},
        },
        active_tasks=[]  # 空列表等同于 None
    )
    
    # 验证空列表被转换为 None（激活所有任务）
    assert consumer.active_tasks is None, "Empty active_tasks should be treated as None"
    print("[PASS] Empty active_tasks treated as None (all tasks activated)")
    
    consumer.task_config.clear()
    TaskRegistry.clear_handlers()


def test_active_tasks_with_config_mode():
    """测试 active_tasks 与配置模式结合"""
    print("\n=== Test: active_tasks with Config Mode ===")
    TaskRegistry.clear_handlers()
    
    # 配置模式（不使用装饰器）
    async def handler_config(task: TaskMessage):
        pass
    
    consumer = TaskConsumer(
        amqp_url="amqp://test",
        task_config={
            "config.task": {
                "handler": handler_config,
                "timeout": 60,
                "prefetch": 20,
            },
        },
        active_tasks=["config.task"]
    )
    
    # 验证 active_tasks 设置
    assert consumer.active_tasks == {"config.task"}, "active_tasks should include config.task"
    print("[PASS] active_tasks works with config mode")
    
    consumer.task_config.clear()
    TaskRegistry.clear_handlers()


if __name__ == "__main__":
    print("=" * 60)
    print("active_tasks Parameter Tests")
    print("=" * 60)
    
    try:
        test_active_tasks_filter()
        test_no_active_tasks()
        test_empty_active_tasks()
        test_active_tasks_with_config_mode()
        
        print("\n" + "=" * 60)
        print("[SUCCESS] All tests passed!")
        print("=" * 60)
    except AssertionError as e:
        print(f"\n[FAIL] Test failed: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"\n[ERROR] Test exception: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
