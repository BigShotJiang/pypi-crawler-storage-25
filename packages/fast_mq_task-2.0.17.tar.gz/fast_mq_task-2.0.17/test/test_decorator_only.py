# -*- coding: utf-8 -*-
"""
测试仅使用装饰器的场景
验证没有 task_config 时，装饰器注册的任务能正常激活
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from fast_mq_task.register import task_handler, TaskRegistry
from fast_mq_task.consumer import TaskConsumer
from fast_mq_task.models import TaskMessage


async def test_decorator_only_no_config():
    """测试：仅使用装饰器，没有 task_config"""
    print("\n=== Test: Decorator Only (No task_config) ===")
    TaskRegistry.clear_handlers()

    # 仅使用装饰器注册
    @task_handler(task_type="task.a", prefetch=10, max_workers=4)
    async def handler_a(task: TaskMessage):
        pass

    @task_handler(task_type="task.b", prefetch=20, max_workers=6)
    async def handler_b(task: TaskMessage):
        pass

    # 没有 task_config，active_tasks 为 None（激活所有）
    consumer = TaskConsumer(
        amqp_url="amqp://test",
        task_config={},  # 空配置
        active_tasks=None  # 激活所有装饰器注册的任务
    )

    # 验证装饰器已注册
    assert len(TaskRegistry._handlers) == 2, "Should have 2 registered handlers"
    print("[PASS] Decorators registered")

    # 验证 task_config 为空
    assert len(consumer.task_config) == 0, "task_config should be empty"
    print("[PASS] task_config is empty")

    # 验证 active_tasks 为 None
    assert consumer.active_tasks is None, "active_tasks should be None"
    print("[PASS] active_tasks is None")

    consumer.task_config.clear()
    TaskRegistry.clear_handlers()
    print("[PASS] Test passed")


async def test_decorator_with_active_tasks():
    """测试：仅使用装饰器，有 active_tasks 过滤"""
    print("\n=== Test: Decorator with active_tasks Filter ===")
    TaskRegistry.clear_handlers()

    # 使用装饰器注册 3 个任务
    @task_handler(task_type="task.a", prefetch=10)
    async def handler_a(task: TaskMessage):
        pass

    @task_handler(task_type="task.b", prefetch=20)
    async def handler_b(task: TaskMessage):
        pass

    @task_handler(task_type="task.c", prefetch=30)
    async def handler_c(task: TaskMessage):
        pass

    # 没有 task_config，但 active_tasks 指定激活部分任务
    consumer = TaskConsumer(
        amqp_url="amqp://test",
        task_config={},  # 空配置
        active_tasks=["task.a", "task.b"]  # 仅激活这两个
    )

    # 验证装饰器已注册
    assert len(TaskRegistry._handlers) == 3, "Should have 3 registered handlers"
    print("[PASS] All decorators registered")

    # 验证 active_tasks 设置正确
    assert consumer.active_tasks == {"task.a", "task.b"}, "active_tasks should be set correctly"
    print("[PASS] active_tasks set correctly")

    consumer.task_config.clear()
    TaskRegistry.clear_handlers()
    print("[PASS] Test passed")


async def test_mixed_decorator_and_config():
    """测试：装饰器和 task_config 混合使用"""
    print("\n=== Test: Mixed Decorator and Config ===")
    TaskRegistry.clear_handlers()

    # 装饰器注册
    @task_handler(task_type="task.decorator", prefetch=15)
    async def handler_decorator(task: TaskMessage):
        pass

    # task_config 配置另一个任务
    async def handler_config(task: TaskMessage):
        pass

    consumer = TaskConsumer(
        amqp_url="amqp://test",
        task_config={
            "task.config": {
                "handler": handler_config,
                "prefetch": 20,
            }
        },
        active_tasks=None  # 激活所有
    )

    # 验证两种任务都被收集
    all_tasks = set(consumer.task_config.rabbit_keys())
    for task_type in TaskRegistry._handlers.keys():
        all_tasks.add(task_type)

    assert len(all_tasks) == 2, f"Should have 2 task types, got {len(all_tasks)}"
    assert "task.decorator" in all_tasks, "Should include decorator task"
    assert "task.config" in all_tasks, "Should include config task"
    print("[PASS] Both decorator and config tasks included")

    consumer.task_config.clear()
    TaskRegistry.clear_handlers()
    print("[PASS] Test passed")


async def main():
    print("=" * 60)
    print("Decorator Only Mode Tests")
    print("=" * 60)

    try:
        await test_decorator_only_no_config()
        await test_decorator_with_active_tasks()
        await test_mixed_decorator_and_config()

        print("\n" + "=" * 60)
        print("[SUCCESS] All tests passed!")
        print("=" * 60)
    except AssertionError as e:
        print(f"\n[FAIL] Test failed: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
    except Exception as e:
        print(f"\n[ERROR] Test exception: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    import asyncio
    asyncio.run(main())
