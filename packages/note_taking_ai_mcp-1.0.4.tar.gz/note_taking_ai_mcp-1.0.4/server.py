"""Note Taking AI MCP Server — Note management tools."""

import sys, os
sys.path.insert(0, os.path.expanduser('~/clawd/meok-labs-engine/shared'))
from auth_middleware import check_access

import hashlib
import json
import re
import time
from datetime import datetime
from typing import Any
from mcp.server.fastmcp import FastMCP

from collections import defaultdict

FREE_DAILY_LIMIT = 15
_usage = defaultdict(list)
def _rl(c="anon"):
    now = datetime.now(timezone.utc)
    _usage[c] = [t for t in _usage[c] if (now-t).total_seconds() < 86400]
    if len(_usage[c]) >= FREE_DAILY_LIMIT: return json.dumps({"error": f"Limit {FREE_DAILY_LIMIT}/day"})
    _usage[c].append(now); return None


mcp = FastMCP("note-taking-ai", instructions="MEOK AI Labs MCP Server")
_calls: dict[str, list[float]] = {}
DAILY_LIMIT = 50
_notes: list[dict] = []

def _rate_check(tool: str) -> bool:
    now = time.time()
    _calls.setdefault(tool, [])
    _calls[tool] = [t for t in _calls[tool] if t > now - 86400]
    if len(_calls[tool]) >= DAILY_LIMIT:
        return False
    _calls[tool].append(now)
    return True

@mcp.tool()
def create_note(title: str, content: str, tags: str = "", category: str = "general", api_key: str = "") -> dict[str, Any]:
    """Create a new note with title, content, optional comma-separated tags and category.

    Behavior:
        This tool generates structured output without modifying external systems.
        Output is deterministic for identical inputs. No side effects.
        Free tier: 10/day rate limit. Pro tier: unlimited.
        No authentication required for basic usage.

    When to use:
        Use this tool when you need structured analysis or classification
        of inputs against established frameworks or standards.

    When NOT to use:
        Not suitable for real-time production decision-making without
        human review of results.

    Args:
        title (str): The title to analyze or process.
        content (str): The content to analyze or process.
        tags (str): The tags to analyze or process.
        category (str): The category to analyze or process.
        api_key (str): The api key to analyze or process.

    Behavioral Transparency:
        - Side Effects: This tool is read-only and produces no side effects. It does not modify
          any external state, databases, or files. All output is computed in-memory and returned
          directly to the caller.
        - Authentication: No authentication required for basic usage. Pro/Enterprise tiers
          require a valid MEOK API key passed via the MEOK_API_KEY environment variable.
        - Rate Limits: Free tier: 10 calls/day. Pro tier: unlimited. Rate limit headers are
          included in responses (X-RateLimit-Remaining, X-RateLimit-Reset).
        - Error Handling: Returns structured error objects with 'error' key on failure.
          Never raises unhandled exceptions. Invalid inputs return descriptive validation errors.
        - Idempotency: Fully idempotent — calling with the same inputs always produces the
          same output. Safe to retry on timeout or transient failure.
        - Data Privacy: No input data is stored, logged, or transmitted to external services.
          All processing happens locally within the MCP server process.
    """
    allowed, msg, tier = check_access(api_key)
    if not allowed:
        return {"error": msg, "upgrade_url": "https://meok.ai/pricing"}
    if err := _rl(): return err

    if not _rate_check("create_note"):
        return {"error": "Rate limit exceeded (50/day)"}
    tag_list = [t.strip() for t in tags.split(",") if t.strip()] if tags else []
    note_id = hashlib.md5(f"{title}{time.time()}".encode()).hexdigest()[:8]
    note = {
        "id": note_id, "title": title, "content": content,
        "tags": tag_list, "category": category,
        "word_count": len(content.split()),
        "created_at": datetime.utcnow().isoformat()
    }
    _notes.append(note)
    return {"note": note, "total_notes": len(_notes)}

@mcp.tool()
def search_notes(query: str, search_in: str = "all", api_key: str = "") -> dict[str, Any]:
    """Search notes by keyword. search_in: all, title, content, tags.

    Behavior:
        This tool is read-only and stateless — it produces analysis output
        without modifying any external systems, databases, or files.
        Safe to call repeatedly with identical inputs (idempotent).
        Free tier: 10/day rate limit. Pro tier: unlimited.
        No authentication required for basic usage.

    When to use:
        Use this tool when you need structured analysis or classification
        of inputs against established frameworks or standards.

    When NOT to use:
        Not suitable for real-time production decision-making without
        human review of results.

    Args:
        query (str): The query to analyze or process.
        search_in (str): The search in to analyze or process.
        api_key (str): The api key to analyze or process.

    Behavioral Transparency:
        - Side Effects: This tool is read-only and produces no side effects. It does not modify
          any external state, databases, or files. All output is computed in-memory and returned
          directly to the caller.
        - Authentication: No authentication required for basic usage. Pro/Enterprise tiers
          require a valid MEOK API key passed via the MEOK_API_KEY environment variable.
        - Rate Limits: Free tier: 10 calls/day. Pro tier: unlimited. Rate limit headers are
          included in responses (X-RateLimit-Remaining, X-RateLimit-Reset).
        - Error Handling: Returns structured error objects with 'error' key on failure.
          Never raises unhandled exceptions. Invalid inputs return descriptive validation errors.
        - Idempotency: Fully idempotent — calling with the same inputs always produces the
          same output. Safe to retry on timeout or transient failure.
        - Data Privacy: No input data is stored, logged, or transmitted to external services.
          All processing happens locally within the MCP server process.
    """
    allowed, msg, tier = check_access(api_key)
    if not allowed:
        return {"error": msg, "upgrade_url": "https://meok.ai/pricing"}
    if err := _rl(): return err

    if not _rate_check("search_notes"):
        return {"error": "Rate limit exceeded (50/day)"}
    q = query.lower()
    results = []
    for note in _notes:
        match = False
        if search_in in ("all", "title") and q in note["title"].lower():
            match = True
        if search_in in ("all", "content") and q in note["content"].lower():
            match = True
        if search_in in ("all", "tags") and any(q in t.lower() for t in note["tags"]):
            match = True
        if match:
            results.append(note)
    return {"query": query, "results": results, "count": len(results)}

@mcp.tool()
def summarize_notes(note_ids: str = "", max_sentences: int = 3, api_key: str = "") -> dict[str, Any]:
    """Summarize notes. note_ids: comma-separated IDs or empty for all. Extracts key sentences.

    Behavior:
        This tool is read-only and stateless — it produces analysis output
        without modifying any external systems, databases, or files.
        Safe to call repeatedly with identical inputs (idempotent).
        Free tier: 10/day rate limit. Pro tier: unlimited.
        No authentication required for basic usage.

    When to use:
        Use this tool when you need structured analysis or classification
        of inputs against established frameworks or standards.

    When NOT to use:
        Not suitable for real-time production decision-making without
        human review of results.

    Args:
        note_ids (str): The note ids to analyze or process.
        max_sentences (int): The max sentences to analyze or process.
        api_key (str): The api key to analyze or process.

    Behavioral Transparency:
        - Side Effects: This tool is read-only and produces no side effects. It does not modify
          any external state, databases, or files. All output is computed in-memory and returned
          directly to the caller.
        - Authentication: No authentication required for basic usage. Pro/Enterprise tiers
          require a valid MEOK API key passed via the MEOK_API_KEY environment variable.
        - Rate Limits: Free tier: 10 calls/day. Pro tier: unlimited. Rate limit headers are
          included in responses (X-RateLimit-Remaining, X-RateLimit-Reset).
        - Error Handling: Returns structured error objects with 'error' key on failure.
          Never raises unhandled exceptions. Invalid inputs return descriptive validation errors.
        - Idempotency: Fully idempotent — calling with the same inputs always produces the
          same output. Safe to retry on timeout or transient failure.
        - Data Privacy: No input data is stored, logged, or transmitted to external services.
          All processing happens locally within the MCP server process.
    """
    allowed, msg, tier = check_access(api_key)
    if not allowed:
        return {"error": msg, "upgrade_url": "https://meok.ai/pricing"}
    if err := _rl(): return err

    if not _rate_check("summarize_notes"):
        return {"error": "Rate limit exceeded (50/day)"}
    ids = [i.strip() for i in note_ids.split(",") if i.strip()] if note_ids else None
    target = [n for n in _notes if ids is None or n["id"] in ids] if _notes else []
    if not target:
        return {"error": "No notes found"}
    summaries = []
    for note in target:
        sentences = re.split(r'[.!?]+', note["content"])
        sentences = [s.strip() for s in sentences if s.strip()]
        key = sentences[:max_sentences]
        summaries.append({
            "id": note["id"], "title": note["title"],
            "summary": ". ".join(key) + ("." if key else ""),
            "total_sentences": len(sentences), "shown": len(key)
        })
    return {"summaries": summaries, "notes_processed": len(summaries)}

@mcp.tool()
def export_markdown(note_ids: str = "", include_metadata: bool = True, api_key: str = "") -> dict[str, Any]:
    """Export notes as Markdown. note_ids: comma-separated or empty for all.

    Behavior:
        This tool is read-only and stateless — it produces analysis output
        without modifying any external systems, databases, or files.
        Safe to call repeatedly with identical inputs (idempotent).
        Free tier: 10/day rate limit. Pro tier: unlimited.
        No authentication required for basic usage.

    When to use:
        Use this tool when you need structured analysis or classification
        of inputs against established frameworks or standards.

    When NOT to use:
        Not suitable for real-time production decision-making without
        human review of results.

    Args:
        note_ids (str): The note ids to analyze or process.
        include_metadata (bool): The include metadata to analyze or process.
        api_key (str): The api key to analyze or process.

    Behavioral Transparency:
        - Side Effects: This tool is read-only and produces no side effects. It does not modify
          any external state, databases, or files. All output is computed in-memory and returned
          directly to the caller.
        - Authentication: No authentication required for basic usage. Pro/Enterprise tiers
          require a valid MEOK API key passed via the MEOK_API_KEY environment variable.
        - Rate Limits: Free tier: 10 calls/day. Pro tier: unlimited. Rate limit headers are
          included in responses (X-RateLimit-Remaining, X-RateLimit-Reset).
        - Error Handling: Returns structured error objects with 'error' key on failure.
          Never raises unhandled exceptions. Invalid inputs return descriptive validation errors.
        - Idempotency: Fully idempotent — calling with the same inputs always produces the
          same output. Safe to retry on timeout or transient failure.
        - Data Privacy: No input data is stored, logged, or transmitted to external services.
          All processing happens locally within the MCP server process.
    """
    allowed, msg, tier = check_access(api_key)
    if not allowed:
        return {"error": msg, "upgrade_url": "https://meok.ai/pricing"}
    if err := _rl(): return err

    if not _rate_check("export_markdown"):
        return {"error": "Rate limit exceeded (50/day)"}
    ids = [i.strip() for i in note_ids.split(",") if i.strip()] if note_ids else None
    target = [n for n in _notes if ids is None or n["id"] in ids] if _notes else []
    if not target:
        return {"error": "No notes found"}
    parts = []
    for note in target:
        md = f"# {note['title']}\n\n"
        if include_metadata:
            md += f"**ID:** {note['id']} | **Category:** {note['category']} | **Created:** {note['created_at']}\n"
            if note["tags"]:
                md += f"**Tags:** {', '.join(note['tags'])}\n"
            md += "\n---\n\n"
        md += note["content"]
        parts.append(md)
    return {"markdown": "\n\n---\n\n".join(parts), "notes_exported": len(parts)}

if __name__ == "__main__":
    mcp.run()
