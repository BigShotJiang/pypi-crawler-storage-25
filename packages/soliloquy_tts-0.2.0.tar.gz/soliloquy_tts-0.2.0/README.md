# Soliloquy

A text-to-speech MCP server powered by [Kokoro](https://github.com/hexgrad/kokoro) — gives Claude Code a voice.

## Requirements

- **macOS** (uses `afplay` for audio playback)
- **Python 3.10+**

> **Note:** Installation downloads ~2GB of dependencies (PyTorch, model weights). First run also downloads the Kokoro-82M model from HuggingFace.

## Install

```bash
pip install soliloquy-tts
```

Or install from source:

```bash
git clone https://github.com/bstovall/soliloquy.git
cd soliloquy
pip install -e .
```

## Register with Claude Code

```bash
claude mcp add soliloquy -- soliloquy
```

If installed in a virtual environment:

```bash
claude mcp add soliloquy -- /path/to/venv/bin/soliloquy
```

Restart Claude Code after registering. Claude can now speak using the `speak` tool.

## How It Works

Soliloquy uses a hybrid architecture to share a single model across multiple Claude Code sessions:

- **First session** loads the Kokoro model and starts a local backend server
- **Additional sessions** detect the running backend and connect as lightweight proxies (near-instant startup, no extra memory)
- If the backend exits, the next session automatically takes over

This is completely transparent — no configuration needed.

## Tools

### `speak`

Synthesize and play text aloud.

| Parameter | Default | Description |
|-----------|---------|-------------|
| `text` | *(required)* | Text to speak |
| `voice` | `af_heart` | Voice ID (see below) |
| `speed` | `1.0` | Speed multiplier (0.5 - 2.0) |
| `lang` | `en-us` | Language code |

### `list_voices`

Returns all available voices with language and gender metadata.

## Voices

28 voices across American and British English:

| Voice | Accent | Gender |
|-------|--------|--------|
| af_heart | American | Female | ★ default
| af_alloy | American | Female |
| af_aoede | American | Female |
| af_bella | American | Female |
| af_jessica | American | Female |
| af_kore | American | Female |
| af_nicole | American | Female |
| af_nova | American | Female |
| af_river | American | Female |
| af_sarah | American | Female |
| af_sky | American | Female |
| am_adam | American | Male |
| am_echo | American | Male |
| am_eric | American | Male |
| am_fenrir | American | Male |
| am_liam | American | Male |
| am_michael | American | Male |
| am_onyx | American | Male |
| am_puck | American | Male |
| am_santa | American | Male |
| bf_alice | British | Female |
| bf_emma | British | Female |
| bf_isabella | British | Female |
| bf_lily | British | Female |
| bm_daniel | British | Male |
| bm_fable | British | Male |
| bm_george | British | Male |
| bm_lewis | British | Male |

## Languages

`en-us` (default), `en-gb`, `ja`, `zh`, `es`, `fr`, `hi`, `it`, `pt-br`

## Development

```bash
git clone https://github.com/bstovall/soliloquy.git
cd soliloquy
python3.11 -m venv .venv
source .venv/bin/activate
pip install -e .
```

Run the benchmark:

```bash
python scripts/benchmark_tts.py
```

## License

MIT
