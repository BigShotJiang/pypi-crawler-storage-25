"""Soliloquy — A text-to-speech MCP server powered by Kokoro."""

__version__ = "0.2.0"

from .main import main

__all__ = ["main", "__version__"]
