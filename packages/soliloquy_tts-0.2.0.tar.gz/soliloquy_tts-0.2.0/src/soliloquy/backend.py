"""Dual-mode backend: runs SSE server for proxies + stdio for the launching session."""

import atexit

import anyio
import uvicorn
from starlette.requests import Request
from starlette.responses import PlainTextResponse
from starlette.routing import Route

from .lock import remove_lock


async def _health(request: Request) -> PlainTextResponse:
    return PlainTextResponse("ok")


async def run_backend_and_stdio(port: int) -> None:
    """Start the SSE backend and stdio MCP server concurrently.

    Lock file must already be written by the caller (main.py).
    """
    # Import server here to trigger kokoro/tool registration
    from . import server

    server.warm_up()
    atexit.register(remove_lock)

    # Build SSE app with health endpoint
    app = server.mcp.sse_app()
    app.routes.insert(0, Route("/health", _health))

    try:
        async with anyio.create_task_group() as tg:

            async def run_sse():
                config = uvicorn.Config(
                    app, host="127.0.0.1", port=port, log_level="warning"
                )
                srv = uvicorn.Server(config)
                await srv.serve()

            async def run_stdio():
                await server.mcp.run_stdio_async()

            tg.start_soon(run_sse)
            tg.start_soon(run_stdio)
    finally:
        remove_lock()
