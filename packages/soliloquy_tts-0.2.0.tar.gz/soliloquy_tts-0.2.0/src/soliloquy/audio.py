"""Audio playback for Soliloquy. Currently macOS-only (afplay)."""

import os
import platform
import subprocess
import tempfile
import threading

import numpy as np
import soundfile as sf


def _check_platform():
    if platform.system() != "Darwin":
        raise RuntimeError(
            f"Soliloquy audio playback requires macOS (afplay). "
            f"Current platform: {platform.system()}. "
            f"Contributions for Linux/Windows support welcome!"
        )


def play_audio(audio: np.ndarray, sample_rate: int = 24000) -> None:
    """Play audio using macOS afplay in a background thread."""
    _check_platform()
    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
        sf.write(f.name, audio, sample_rate)
        path = f.name

    def _play_and_cleanup():
        try:
            subprocess.run(
                ["afplay", path],
                check=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        finally:
            os.unlink(path)

    threading.Thread(target=_play_and_cleanup, daemon=True).start()


def stream_play_audio(chunks: list[np.ndarray], sample_rate: int = 24000) -> None:
    """Concatenate chunks and play."""
    if not chunks:
        return
    audio = np.concatenate(chunks)
    play_audio(audio, sample_rate)
