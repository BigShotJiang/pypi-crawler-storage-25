# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What This Is

Soliloquy is a text-to-speech MCP server powered by Kokoro that gives Claude Code a voice. It exposes two MCP tools (`speak` and `list_voices`) over stdio transport. Distributed as `soliloquy-tts` on PyPI.

## Development

```bash
python3.11 -m venv .venv
source .venv/bin/activate
pip install -e .

# Run the MCP server directly
soliloquy

# Or via module
python -m soliloquy

# Run benchmarks
python scripts/benchmark_tts.py
```

## Architecture

```
src/soliloquy/
  __init__.py   — version, re-exports main()
  __main__.py   — python -m soliloquy support
  main.py       — entry point: decides backend vs proxy mode
  server.py     — FastMCP tool definitions, Kokoro pipeline management
  backend.py    — dual-mode runner (SSE server + stdio, concurrent via anyio)
  proxy.py      — lightweight stdio-to-SSE stream bridge (~30 lines)
  lock.py       — lock file protocol for backend discovery
  audio.py      — audio playback (macOS afplay, background thread)
scripts/
  benchmark_tts.py — performance benchmarking (not part of package)
```

### Hybrid Backend

Multiple Claude Code sessions share a single Kokoro model instance:

1. **First `soliloquy` process** — loads model, starts SSE server on a dynamic port, runs stdio for the launching session, writes lock to `~/.soliloquy/backend.lock`
2. **Subsequent processes** — detect the lock, skip model loading, run as lightweight stdio-to-SSE proxies (near-instant startup)
3. **Stale lock recovery** — if the backend dies, next process detects it via PID + health probe and takes over

The proxy (`proxy.py`) is a transparent stream bridge — it forwards raw MCP messages between stdio and SSE without understanding the protocol. It imports only `mcp` and `anyio`, never `kokoro` or `torch`.

## Key Details

- **macOS-only**: Audio playback uses `afplay` — platform check in `audio.py`
- **MPS fallback**: `PYTORCH_ENABLE_MPS_FALLBACK=1` must be set before torch import (handled at top of `server.py`)
- **Import weight**: `server.py` imports `kokoro` at module level (triggers torch/transformers). Proxy mode avoids importing `server.py` entirely.
- **28 voices** across American/British, male/female. Default is `af_heart`
- **9 languages**: en-us, en-gb, ja, zh, es, fr, hi, it, pt-br
- **No test suite** — tools self-validate inputs (voice name, speed 0.5-2.0, language code)
- **Heavy install** (~2GB) due to PyTorch and model weights
- **First run** downloads Kokoro-82M from HuggingFace
