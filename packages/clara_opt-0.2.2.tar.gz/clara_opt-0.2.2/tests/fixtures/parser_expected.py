"""
Expected parse results for LP parser test fixtures.
Used by tests/test_lp_parser.py to validate parsing correctness.
"""

import math

# ============================================================
# parser_comprehensive.lp
# ============================================================

COMPREHENSIVE = {
    "name": "parser_comprehensive",
    "sense": "maximize",
    "objective_name": "profit",

    # Variables ordered by first appearance:
    # x1 (obj), x2 (obj), x3 (obj), y1 (obj), y2 (obj), z1 (obj)
    "variable_names": ["x1", "x2", "x3", "y1", "y2", "z1"],
    "num_variables": 6,

    # Objective: 3 x1 + 4.5 x2 - 2 x3 + 15 y1 + 1 y2 + 7 z1
    "c": [3.0, 4.5, -2.0, 15.0, 1.0, 7.0],
    "obj_offset": 0.0,

    # Constraints (5 total)
    "constraint_names": ["capacity1", "capacity2", "balance", "c4", "demand"],
    "num_constraints_ub": 3,  # capacity1, capacity2, demand (c4 is >= → flipped)
    "num_constraints_eq": 1,  # balance

    # After conversion (>= flipped to <=):
    # capacity1: x1 + 2 x2 + x3 <= 1200
    # capacity2: x1 + 3 x3 <= 1400
    # c4 (flipped): -x1 - x2 - x3 - y1 - y2 - z1 <= -100
    # demand: -x1 + 2 x2 - 3 x3 + y1 <= 500
    # balance (eq): x1 - x2 = 0

    # Bounds
    "bounds": {
        "x1": (0.0, 1000.0),
        "x2": (0.0, 800.0),       # default lower 0, explicit upper 800
        "x3": (10.0, math.inf),    # explicit lower 10, default upper inf
        "y1": (50.0, 50.0),        # fixed
        "y2": (-math.inf, math.inf),  # free
        "z1": (-math.inf, math.inf),  # -inf to +inf
    },

    # MIP features
    "integer_vars": {"x1", "x3"},  # from General section
    "binary_vars": {"y1"},          # from Binary section
    # Note: y1 is both Binary and fixed at 50 — binary bounds [0,1]
    # should be overridden by explicit bound. Parser should warn.
}

# ============================================================
# parser_minimal.lp
# ============================================================

MINIMAL = {
    "name": "parser_minimal",
    "sense": "minimize",
    "objective_name": "obj",        # default
    "variable_names": ["x"],
    "c": [1.0],                     # implicit coefficient
    "obj_offset": 0.0,
    "constraint_names": ["c1"],     # auto-named (>= flipped to <=)
    # x >= 1 → -x <= -1
    "bounds": {
        "x": (0.0, math.inf),      # default
    },
    "integer_vars": set(),
    "binary_vars": set(),
}

# ============================================================
# albici_base.lp (cross-check with albici_expected.py)
# ============================================================

ALBICI_BASE = {
    "name": "albici_base",
    "sense": "maximize",
    "objective_name": "obj",
    "variable_names": ["x1", "x2", "x3"],
    "c": [3.0, 4.0, 5.0],
    "obj_offset": 0.0,
    "constraint_names": ["S1", "S2", "S3", "S4"],
    "num_constraints_ub": 4,
    "num_constraints_eq": 0,
    "bounds": {
        "x1": (0.0, math.inf),
        "x2": (0.0, math.inf),
        "x3": (0.0, math.inf),
    },
    "integer_vars": set(),
    "binary_vars": set(),
}