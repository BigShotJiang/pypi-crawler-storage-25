"""
CLARA Phase 2 — Diff Report Design Specification
==================================================

The Diff Report compares two SolveStates (old vs new) and generates
a human-readable explanation of what changed and why.

This is the final piece of the reoptimization pipeline:
    Change Detector → Impact Analyzer → Reoptimizer → **Diff Report**

The Diff Report answers three questions:
    1. What parameters changed? (from ParameterChange)
    2. How did the solution change? (SolveState diff)
    3. What should the decision-maker do next? (actionable insights)

Branch: feat/diff-report
"""


# ============================================================
# 1. Public API
# ============================================================

API = """
# Module: clara/reopt/diff_report.py

class DiffReporter:
    '''Compare two SolveStates and generate an explanation of changes.'''

    def diff(
        self,
        old_state: SolveState,
        new_state: SolveState,
        change: ParameterChange,
        reopt_result: ReoptResult,
    ) -> DiffReport:
        '''Generate a diff report comparing old and new solutions.

        Args:
            old_state: Previous SolveState.
            new_state: Reoptimized SolveState.
            change: What parameters changed (from ChangeDetector).
            reopt_result: How the reoptimization was performed.

        Returns:
            DiffReport with structured comparison and natural language summary.
        '''

# Usage (end-to-end pipeline):
    # 1. Detect
    change = ChangeDetector().detect(old_problem, new_problem)

    # 2. Analyze
    decision = ImpactAnalyzer().analyze(old_state, change, old_problem)

    # 3. Reoptimize
    result = Reoptimizer().reoptimize(old_state, new_problem, change, decision)

    # 4. Explain the diff
    report = DiffReporter().diff(old_state, result.new_state, change, result)
    print(report.to_text())
    print(report.to_json())
"""


# ============================================================
# 2. DiffReport Data Structure
# ============================================================

DATA_STRUCTURE = """
Add to clara/reopt/types.py:

@dataclass(frozen=True)
class VariableChange:
    '''Change in a single variable between old and new solution.'''
    name: str
    old_value: float
    new_value: float
    delta: float                    # new - old
    delta_pct: float                # (new - old) / |old| * 100 (0 if old=0)
    old_basis: BasisStatus
    new_basis: BasisStatus
    basis_changed: bool             # entered or left basis

@dataclass(frozen=True)
class ConstraintChange:
    '''Change in a single constraint between old and new solution.'''
    name: str
    old_rhs: float
    new_rhs: float                  # same as old if only c changed
    old_slack: float
    new_slack: float
    old_dual: float
    new_dual: float
    old_binding: bool
    new_binding: bool
    became_binding: bool            # was non-binding, now binding
    became_nonbinding: bool         # was binding, now non-binding

@dataclass(frozen=True)
class DiffReport:
    '''Complete comparison of two solutions.'''

    # --- Input context ---
    change: ParameterChange
    reopt_result: ReoptResult

    # --- Objective ---
    old_objective: float
    new_objective: float
    objective_delta: float
    objective_delta_pct: float

    # --- Variable changes (only variables with significant change) ---
    variable_changes: tuple[VariableChange, ...]
    variables_entered_basis: tuple[str, ...]     # newly basic
    variables_left_basis: tuple[str, ...]        # newly non-basic

    # --- Constraint changes ---
    constraint_changes: tuple[ConstraintChange, ...]
    became_binding: tuple[str, ...]
    became_nonbinding: tuple[str, ...]

    # --- Bottleneck shift ---
    old_bottleneck: str | None       # constraint with highest |dual| in old
    new_bottleneck: str | None       # constraint with highest |dual| in new
    bottleneck_shifted: bool

    # --- Summary ---
    summary: str                     # multi-line natural language summary

    def to_text(self) -> str: ...
    def to_dict(self) -> dict: ...
    def to_json(self, indent: int = 2) -> str: ...
"""


# ============================================================
# 3. Text Output Template
# ============================================================

TEXT_TEMPLATE = """

--- Example: Albici base → b2 (RHS change, basis broken) ---

═══════════════════════════════════════════════════════════════
CLARA — Solution Change Report
═══════════════════════════════════════════════════════════════

PARAMETER CHANGE
  Type: RHS change (Type R)
  RHS changed in 3 constraint(s):
    S1: 1200 → 1500 (+300)
    S2: 1400 → 1300 (-100)
    S3: 2000 → 2400 (+400)

REOPTIMIZATION
  Method: warm-start (3 pivots, est. 4.2x faster than scratch)
  Basis preserved: No

OBJECTIVE
  Old: 3688.8889 → New: 4300.0000 (+611.1111, +16.6%)

VARIABLE CHANGES
  x1: 755.56 → 940.00 (+184.44, +24.4%) — remained in basis
  x2: 133.33 → 220.00 (+86.67, +65.0%) — remained in basis
  x3: 177.78 → 120.00 (-57.78, -32.5%) — remained in basis

CONSTRAINT CHANGES
  S1: non-binding → binding (slack 0.00 → 0.00, dual 0.78 → 1.50)
  S2: non-binding → non-binding (slack 111.11 → 60.00)
  S4: binding → binding (dual 0.67 → 0.83)

BOTTLENECK SHIFT
  Old bottleneck: S3 (shadow price 1.1111)
  New bottleneck: S1 (shadow price 1.5000)
  → S1 is now the most valuable constraint to expand.


--- Example: Albici base → cost change (obj coeff, basis broken) ---

═══════════════════════════════════════════════════════════════
CLARA — Solution Change Report
═══════════════════════════════════════════════════════════════

PARAMETER CHANGE
  Type: Objective coefficient change (Type C)
  Coefficients changed for 3 variable(s):
    x1: 3.0000 → 8.0000 (+5.0000)
    x2: 4.0000 → 6.0000 (+2.0000)
    x3: 5.0000 → 7.0000 (+2.0000)
  Oguz bound: 125.0% (δ = 1.6667)

REOPTIMIZATION
  Method: warm-start (2 pivots, est. 3.0x faster than scratch)
  Basis preserved: No

OBJECTIVE
  Old: 3688.8889 → New: 8266.6667 (+4577.7778, +124.1%)

VARIABLE CHANGES
  x1: 755.56 → 933.33 (+177.78, +23.5%) — remained in basis
  x2: 133.33 → 133.33 (+0.00, +0.0%) — remained in basis
  x3: 177.78 → 0.00 (-177.78, -100.0%) — LEFT basis
  → P3 is no longer produced with the new pricing.

CONSTRAINT CHANGES
  S2: non-binding → non-binding (slack 111.11 → 466.67, more unused)
  S4: binding → non-binding (slack 0.00 → 533.33)
  → S4 is no longer a bottleneck. Department 4 has excess capacity.

BOTTLENECK SHIFT
  Old bottleneck: S3 (shadow price 1.1111)
  New bottleneck: S3 (shadow price unchanged)
  → Bottleneck unchanged.


--- Example: Albici base → b1 (RHS change, basis preserved) ---

═══════════════════════════════════════════════════════════════
CLARA — Solution Change Report
═══════════════════════════════════════════════════════════════

PARAMETER CHANGE
  Type: RHS change (Type R)
  RHS changed in 4 constraint(s):
    S1: 1200 → 1300 (+100)
    S2: 1400 → 1200 (-200)
    S3: 2000 → 1800 (-200)
    S4: 800 → 1000 (+200)

REOPTIMIZATION
  Method: recompute (0 pivots — basis preserved)
  Basis preserved: Yes

OBJECTIVE
  Old: 3688.8889 → New: 3677.7778 (-11.1111, -0.3%)

VARIABLE CHANGES
  x1: 755.56 → 611.11 (-144.44, -19.1%)
  x2: 133.33 → 266.67 (+133.33, +100.0%)
  x3: 177.78 → 155.56 (-22.22, -12.5%)
  All variables remain in basis — solution structure unchanged.

BOTTLENECK SHIFT
  Old bottleneck: S3 (shadow price 1.1111)
  New bottleneck: S3 (shadow price 1.1111)
  → Bottleneck and shadow prices unchanged (same basis).
"""


# ============================================================
# 4. JSON Output Structure
# ============================================================

JSON_STRUCTURE = """
{
  "change": {
    "type": "TYPE_R",
    "summary": "RHS changed in 3 constraint(s)",
    "delta_b": [300, -100, 400, 0],
    "delta_c": null
  },
  "reoptimization": {
    "method": "warm_start",
    "pivots": 3,
    "scratch_estimate": 12,
    "speedup": 4.0,
    "basis_preserved": false,
    "time_seconds": 0.0012
  },
  "objective": {
    "old": 3688.8889,
    "new": 4300.0,
    "delta": 611.1111,
    "delta_pct": 16.57
  },
  "variable_changes": [
    {
      "name": "x1",
      "old": 755.5556,
      "new": 940.0,
      "delta": 184.4444,
      "delta_pct": 24.41,
      "basis_changed": false
    }
  ],
  "constraint_changes": [
    {
      "name": "S1",
      "old_binding": false,
      "new_binding": true,
      "became_binding": true,
      "old_dual": 0.7778,
      "new_dual": 1.5
    }
  ],
  "bottleneck": {
    "old": "S3",
    "new": "S1",
    "shifted": true
  }
}
"""


# ============================================================
# 5. Implementation
# ============================================================

IMPLEMENTATION = """
class DiffReporter:

    CHANGE_TOL = 1e-6  # ignore variable changes smaller than this

    def diff(self, old_state, new_state, change, reopt_result) -> DiffReport:

        # --- Objective ---
        old_obj = old_state.optimal_value
        new_obj = new_state.optimal_value
        obj_delta = new_obj - old_obj
        obj_delta_pct = (obj_delta / abs(old_obj) * 100) if abs(old_obj) > 1e-10 else 0.0

        # --- Variable changes ---
        var_changes = []
        entered = []
        left = []
        old_vars = {v.name: v for v in old_state.variables}
        new_vars = {v.name: v for v in new_state.variables}

        for name in old_vars:
            if name not in new_vars:
                continue  # variable removed (structural change)
            ov = old_vars[name]
            nv = new_vars[name]
            delta = nv.value - ov.value
            if abs(delta) < self.CHANGE_TOL and ov.basis_status == nv.basis_status:
                continue  # no meaningful change

            delta_pct = (delta / abs(ov.value) * 100) if abs(ov.value) > 1e-10 else 0.0
            basis_changed = ov.basis_status != nv.basis_status

            var_changes.append(VariableChange(
                name=name,
                old_value=ov.value, new_value=nv.value,
                delta=delta, delta_pct=delta_pct,
                old_basis=ov.basis_status, new_basis=nv.basis_status,
                basis_changed=basis_changed,
            ))

            if ov.basis_status != BasisStatus.BASIC and nv.basis_status == BasisStatus.BASIC:
                entered.append(name)
            elif ov.basis_status == BasisStatus.BASIC and nv.basis_status != BasisStatus.BASIC:
                left.append(name)

        # Sort by absolute delta descending
        var_changes.sort(key=lambda vc: abs(vc.delta), reverse=True)

        # --- Constraint changes ---
        con_changes = []
        became_binding = []
        became_nonbinding = []
        old_cons = {c.name: c for c in old_state.constraints}
        new_cons = {c.name: c for c in new_state.constraints}

        for name in old_cons:
            if name not in new_cons:
                continue
            oc = old_cons[name]
            nc = new_cons[name]

            bb = not oc.is_binding and nc.is_binding
            bn = oc.is_binding and not nc.is_binding

            # Determine new_rhs: if change has delta_b, compute it
            new_rhs = oc.rhs
            if change.delta_b is not None:
                idx = list(old_state.constraint_names).index(name)
                if idx < len(change.delta_b):
                    new_rhs = oc.rhs + change.delta_b[idx]

            con_changes.append(ConstraintChange(
                name=name,
                old_rhs=oc.rhs, new_rhs=new_rhs,
                old_slack=oc.slack, new_slack=nc.slack,
                old_dual=oc.dual_value, new_dual=nc.dual_value,
                old_binding=oc.is_binding, new_binding=nc.is_binding,
                became_binding=bb, became_nonbinding=bn,
            ))

            if bb:
                became_binding.append(name)
            if bn:
                became_nonbinding.append(name)

        # --- Bottleneck ---
        old_bn = self._find_bottleneck(old_state)
        new_bn = self._find_bottleneck(new_state)
        bn_shifted = old_bn != new_bn

        # --- Summary ---
        summary = self._make_summary(
            change, reopt_result, obj_delta, obj_delta_pct,
            var_changes, entered, left,
            became_binding, became_nonbinding,
            old_bn, new_bn,
        )

        return DiffReport(
            change=change,
            reopt_result=reopt_result,
            old_objective=old_obj,
            new_objective=new_obj,
            objective_delta=obj_delta,
            objective_delta_pct=obj_delta_pct,
            variable_changes=tuple(var_changes),
            variables_entered_basis=tuple(entered),
            variables_left_basis=tuple(left),
            constraint_changes=tuple(con_changes),
            became_binding=tuple(became_binding),
            became_nonbinding=tuple(became_nonbinding),
            old_bottleneck=old_bn,
            new_bottleneck=new_bn,
            bottleneck_shifted=bn_shifted,
            summary=summary,
        )

    def _find_bottleneck(self, state: SolveState) -> str | None:
        binding = [c for c in state.constraints if c.is_binding]
        if not binding:
            return None
        return max(binding, key=lambda c: abs(c.dual_value)).name

    def _make_summary(self, change, result, obj_delta, obj_delta_pct,
                       var_changes, entered, left,
                       became_binding, became_nonbinding,
                       old_bn, new_bn) -> str:
        parts = []

        # Parameter change
        parts.append(f"Parameter change: {change.summary}.")

        # Reoptimization
        parts.append(f"Reoptimization: {result.summary}")

        # Objective
        direction = "increased" if obj_delta > 0 else "decreased"
        parts.append(
            f"Objective {direction} by {abs(obj_delta_pct):.1f}% "
            f"({abs(obj_delta):.4f})."
        )

        # Structural solution changes
        if entered:
            parts.append(f"Variables entered basis: {', '.join(entered)}.")
        if left:
            parts.append(f"Variables left basis: {', '.join(left)}.")
        if not entered and not left:
            parts.append("Solution structure unchanged (same basis).")

        # Constraint changes
        if became_binding:
            parts.append(f"Newly binding: {', '.join(became_binding)}.")
        if became_nonbinding:
            parts.append(f"No longer binding: {', '.join(became_nonbinding)}.")

        # Bottleneck
        if old_bn and new_bn and old_bn != new_bn:
            parts.append(f"Bottleneck shifted from {old_bn} to {new_bn}.")

        return "\n".join(parts)
"""


# ============================================================
# 6. CLI Integration: `clara diff`
# ============================================================

CLI_INTEGRATION = """
New CLI command for comparing two LP files:

    clara diff old.lp new.lp [options]

Implementation in cli.py:

    @main.command()
    @click.argument("old_file", type=click.Path(exists=True, dir_okay=False))
    @click.argument("new_file", type=click.Path(exists=True, dir_okay=False))
    @click.option("--engine", type=click.Choice(["internal", "highs"]),
                  default="internal")
    @click.option("--format", "fmt", type=click.Choice(["text", "json"]),
                  default="text")
    @click.option("--output", "-o", type=click.Path(), default=None)
    def diff(old_file, new_file, engine, fmt, output):
        '''Compare two LP problems and explain what changed.

        Runs the full reoptimization pipeline:
        detect → analyze → reoptimize → diff report.
        '''
        old_problem = _parse_file(old_file)
        new_problem = _parse_file(new_file)

        # Solve old problem
        old_state = _solve(old_problem, engine)
        if not old_state.is_optimal:
            click.secho(f"Old problem is {old_state.status.name}.", fg="red", err=True)
            sys.exit(1)

        # Full pipeline
        change = ChangeDetector().detect(old_problem, new_problem)
        if change is None:
            click.echo("No parameter changes detected. Solutions are identical.")
            return

        decision = ImpactAnalyzer().analyze(old_state, change, old_problem)
        result = Reoptimizer().reoptimize(old_state, new_problem, change, decision)

        report = DiffReporter().diff(old_state, result.new_state, change, result)

        if fmt == "json":
            text = report.to_json()
        else:
            text = report.to_text()

        _write_output(text, output)

Usage:
    # Compare original Albici problem with RHS change
    clara diff tests/fixtures/albici_base.lp tests/fixtures/albici_reopt_b1.lp

    # JSON output
    clara diff tests/fixtures/albici_base.lp tests/fixtures/albici_reopt_cost.lp --format json
"""


# ============================================================
# 7. Test Cases
# ============================================================

TEST_CASES = """
tests/test_diff_report.py

Setup: solve albici_base → old_state. For each scenario, run full pipeline.

1. Albici b1 (basis preserved)
   - test_b1_objective_delta
        → delta ≈ -11.11, delta_pct ≈ -0.3%
   - test_b1_no_basis_change
        → variables_entered_basis == (), variables_left_basis == ()
   - test_b1_bottleneck_same
        → bottleneck_shifted == False
   - test_b1_summary_contains_preserved
        → "unchanged" or "same basis" in summary

2. Albici b2 (basis broken)
   - test_b2_objective_increased
        → new > old, delta_pct ≈ +16.6%
   - test_b2_variable_changes
        → x1, x2, x3 all changed significantly
   - test_b2_constraint_binding_changed
        → at least one constraint became binding or nonbinding

3. Albici cost change (obj coeff)
   - test_cost_x3_left_basis
        → "x3" in variables_left_basis
   - test_cost_objective_doubled
        → delta_pct > 100%
   - test_cost_summary_mentions_oguz
        → Oguz bound value somewhere in pipeline

4. Albici column addition
   - test_columns_structural_scratch
        → reopt_result.method_used == "scratch"
   - test_columns_new_vars_in_solution
        → new_state has variables not in old_state

5. Text output
   - test_to_text_not_empty
        → len(report.to_text()) > 100
   - test_to_text_has_sections
        → "PARAMETER CHANGE", "OBJECTIVE", "VARIABLE CHANGES" in text
   - test_to_text_has_numbers
        → old and new objective values in text

6. JSON output
   - test_to_json_valid
        → json.loads(report.to_json()) succeeds
   - test_json_has_keys
        → "objective", "variable_changes", "bottleneck" keys present
   - test_json_roundtrip
        → values match DiffReport fields

7. CLI `clara diff`
   - test_cli_diff_albici_b1
        → exit 0, output contains objective values
   - test_cli_diff_albici_cost
        → exit 0, mentions x3 leaving basis
   - test_cli_diff_json
        → valid JSON output
   - test_cli_diff_no_change
        → "No parameter changes detected"
   - test_cli_diff_output_file
        → writes to file

8. Edge cases
   - test_identical_problems_no_diff    → change is None, no report
   - test_all_variables_changed         → all vars in variable_changes
   - test_zero_old_value                → delta_pct = 0 (no division by zero)
   - test_bottleneck_none               → no binding constraints in one state
"""


# ============================================================
# 8. Module Structure
# ============================================================

MODULE_STRUCTURE = """
New files:
    clara/reopt/diff_report.py        # DiffReporter class
    tests/test_diff_report.py         # all tests

Modified files:
    clara/reopt/types.py              # add VariableChange, ConstraintChange, DiffReport
    clara/reopt/__init__.py           # re-export DiffReporter, DiffReport
    clara/cli.py                      # add `clara diff` command
"""


# ============================================================
# 9. Implementation Order
# ============================================================

IMPLEMENTATION_ORDER = """
1. git checkout -b feat/diff-report

2. Add data structures to clara/reopt/types.py
   - VariableChange, ConstraintChange, DiffReport
   - Commit: "feat: add DiffReport data structures"

3. Implement clara/reopt/diff_report.py
   - DiffReporter.diff()
   - _find_bottleneck(), _make_summary()
   - to_text(), to_dict(), to_json()
   - Commit: "feat: Diff Report generator"

4. CLI `clara diff` command
   - Add to clara/cli.py
   - Full pipeline: detect → analyze → reoptimize → diff
   - Commit: "feat: `clara diff` CLI command"

5. Tests
   - tests/test_diff_report.py
   - All Albici scenarios
   - CLI tests
   - Commit: "test: Diff Report tests with Albici validation"

6. pytest full suite, update CLAUDE.md
   - Commit: "docs: update CLAUDE.md for Phase 2 Diff Report"
"""


# ============================================================
# 10. Phase 2 Complete — What This Enables
# ============================================================

PHASE_2_COMPLETE = """
With Diff Report done, the full Phase 2 pipeline works end-to-end:

    $ clara diff production_q1.lp production_q2.lp

    Parameter change: RHS changed in 2 constraint(s).
    Reoptimization: warm-start (3 pivots, 4.2x faster than scratch).
    Objective increased by 8.3% (245.50).
    Variables entered basis: x5.
    Variables left basis: x2.
    Newly binding: capacity_B.
    Bottleneck shifted from capacity_A to capacity_B.

This is the MPC paper's core demonstration:
    1. Detect → WHAT changed (Albici taxonomy)
    2. Analyze → SHOULD we reoptimize (Oguz bound + sensitivity)
    3. Reoptimize → HOW efficiently (B⁻¹ warm-start)
    4. Explain → WHY the solution changed (Diff Report)

No existing tool does all four. EOR (Zhang 2025) does explain but
uses LLM post-hoc and always scratch re-solves. CLARA does it
intrinsically with mathematical guarantees.

After this, remaining Phase 2 work:
    - Parametric LP (Type RC) — upgrade placeholder to real implementation
    - `clara watch` streaming interface — apply pipeline to a stream of changes
    - v1.0.0 release + MPC paper draft
"""