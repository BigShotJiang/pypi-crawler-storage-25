"""
CLARA — MIP Opportunity Cost Bound Implementation Specification
================================================================

Implements Theorems 1-7 from the theory document.
Integrates with existing CLARA pipeline:
    - Uses Internal B&B (bnb.py) for MIP solving
    - Uses Internal Simplex (simplex.py) for LP relaxation
    - Uses existing SolveState for B⁻¹, sensitivity ranges
    - Connects to Impact Analyzer and Reoptimizer

Branch: feat/mip-bound
"""


# ============================================================
# 1. Public API
# ============================================================

API = """
# Module: clara/reopt/mip_bound.py

class MIPBoundAnalyzer:
    '''Compute opportunity cost bounds for MIP reoptimization decisions.

    Implements LP-relaxation-based bounds (Theorems 1-5) and
    gap-corrected estimates (Proposition 6) for deciding whether
    to reoptimize a MIP after parameter changes.
    '''

    def __init__(self, epsilon: float = 0.05):
        '''
        Args:
            epsilon: Acceptable relative opportunity cost threshold.
                     Default 5% — "losing at most 5% is acceptable."
        '''

    def analyze(
        self,
        mip_state: SolveState,           # original MIP solution (from B&B)
        lp_state: SolveState,            # original LP relaxation solution
        old_problem: LPProblem,          # original problem
        new_problem: LPProblem,          # changed problem
        change: ParameterChange,         # from ChangeDetector
    ) -> MIPBoundResult:
        '''Compute bound and make reoptimization decision.

        Args:
            mip_state: SolveState from Internal B&B (has x*, z*_MIP).
            lp_state: SolveState from Internal Simplex on LP relaxation
                      (has x̄, z*_LP, B⁻¹, sensitivity ranges).
            old_problem: The original MIP problem.
            new_problem: The changed problem.
            change: Detected parameter change.

        Returns:
            MIPBoundResult with bound, decision, and decomposition.
        '''

# Usage:
    from clara.engine.bnb import BranchAndBound
    from clara.engine.simplex import RevisedSimplex

    # Step 1: Solve original MIP
    mip_solver = BranchAndBound(problem)
    mip_state = mip_solver.solve()

    # Step 2: Solve LP relaxation (strip integrality)
    lp_problem = problem.as_lp()  # new method: remove integer/binary constraints
    lp_solver = RevisedSimplex(lp_problem)
    lp_state = lp_solver.solve()

    # Step 3: Detect change
    change = ChangeDetector().detect(old_problem, new_problem)

    # Step 4: Compute bound and decide
    analyzer = MIPBoundAnalyzer(epsilon=0.05)
    result = analyzer.analyze(mip_state, lp_state, old_problem, new_problem, change)

    if result.decision == "skip":
        print(f"Safe to skip: OC ≤ {result.bound:.2f} ({result.bound_ratio:.1%} of z'_LP)")
    else:
        print(f"Reoptimize: bound {result.bound:.2f} exceeds threshold")
"""


# ============================================================
# 2. MIPBoundResult Data Structure
# ============================================================

DATA_STRUCTURE = """
Add to clara/reopt/types.py:

@dataclass(frozen=True)
class MIPBoundResult:
    '''Result of MIP opportunity cost bound analysis.'''

    # Decision
    decision: str                          # "skip" or "reoptimize" or "infeasible"
    reason: str                            # human-readable explanation

    # Bound (Theorem 2: LP-relaxation bound)
    bound: float                           # B = z'*_LP - c'^T x*
    bound_ratio: float                     # B / z'*_LP (relative)

    # Gap-corrected estimate (Proposition 6)
    bound_corrected: float | None          # B_c (tighter but not guaranteed)
    bound_corrected_ratio: float | None

    # Decomposition (Equation 4 in paper)
    original_integrality_gap: float        # z*_LP - z*_MIP
    gap_ratio: float                       # (z*_LP - z*_MIP) / z*_LP

    # Values used in computation
    z_mip_old: float                       # z*_MIP (original)
    z_lp_old: float                        # z*_LP (original)
    z_lp_new: float | None                 # z'*_LP (changed LP, if computed)
    c_new_x_old: float                     # c'^T x* (old MIP solution, new objective)

    # Feasibility (Theorem 4)
    old_solution_feasible: bool            # Ax* ≤ b'?
    max_violation: float                   # max(Ax* - b', 0) if infeasible

    # Sensitivity check (Theorem 3)
    within_lp_sensitivity: bool            # Δc within LP sensitivity range?
    lp_solve_needed: bool                  # did we need a new LP solve?

    # Oguz bound (Theorem 1, for comparison)
    oguz_relative_bound: float | None      # 2δ/(1+δ) if computable
    delta: float | None                    # max relative change

    @property
    def summary(self) -> str:
        if self.decision == "infeasible":
            return (f"Old MIP solution is infeasible for changed problem "
                    f"(max violation = {self.max_violation:.4f}). "
                    f"Reoptimization is mandatory.")

        parts = [f"MIP opportunity cost bound: B = {self.bound:.4f} "
                 f"({self.bound_ratio:.1%} of z'_LP)."]

        parts.append(f"Original integrality gap: {self.gap_ratio:.1%}.")

        if self.bound_corrected is not None:
            parts.append(f"Gap-corrected estimate: B_c = {self.bound_corrected:.4f} "
                         f"({self.bound_corrected_ratio:.1%}).")

        if self.within_lp_sensitivity:
            parts.append("Computed via LP sensitivity (no new LP solve needed).")
        else:
            parts.append("Required one LP relaxation solve.")

        if self.decision == "skip":
            parts.append(f"Decision: SKIP reoptimization (bound below threshold).")
        else:
            parts.append(f"Decision: REOPTIMIZE (bound exceeds threshold).")

        if self.oguz_relative_bound is not None:
            parts.append(f"Oguz relative bound: {self.oguz_relative_bound:.1%} "
                         f"(δ = {self.delta:.4f}).")

        return "\n".join(parts)
"""


# ============================================================
# 3. Implementation
# ============================================================

IMPLEMENTATION = """
class MIPBoundAnalyzer:

    def __init__(self, epsilon: float = 0.05):
        self.epsilon = epsilon

    def analyze(self, mip_state, lp_state, old_problem, new_problem, change):

        z_mip_old = mip_state.optimal_value
        z_lp_old = lp_state.optimal_value
        x_star = np.array([v.value for v in mip_state.variables])
        x_bar = np.array([v.value for v in lp_state.variables])

        gap = z_lp_old - z_mip_old
        gap_ratio = gap / z_lp_old if abs(z_lp_old) > 1e-10 else 0.0

        # --- Step 1: Feasibility check (Theorem 4) ---
        if change.delta_b is not None:
            b_new = old_problem.b + change.delta_b
            violations = old_problem.A @ x_star[:old_problem.num_variables] - b_new
            max_violation = max(0, float(np.max(violations)))
            feasible = max_violation < 1e-8
        else:
            feasible = True
            max_violation = 0.0

        if not feasible:
            return MIPBoundResult(
                decision="infeasible",
                reason=f"Old solution violates {np.sum(violations > 1e-8)} constraints.",
                bound=float('inf'), bound_ratio=1.0,
                bound_corrected=None, bound_corrected_ratio=None,
                original_integrality_gap=gap, gap_ratio=gap_ratio,
                z_mip_old=z_mip_old, z_lp_old=z_lp_old,
                z_lp_new=None, c_new_x_old=0.0,
                old_solution_feasible=False, max_violation=max_violation,
                within_lp_sensitivity=False, lp_solve_needed=False,
                oguz_relative_bound=None, delta=None,
            )

        # --- Compute c'^T x* ---
        c_new = new_problem.c
        c_new_x_old = float(c_new @ x_star[:new_problem.num_variables])

        # --- Step 2: LP sensitivity check (Theorem 3) ---
        within_sens = self._check_lp_sensitivity(lp_state, change, old_problem)

        if within_sens:
            # No new LP solve needed — use old LP solution
            c_new_x_bar = float(c_new @ x_bar[:new_problem.num_variables])
            z_lp_new = c_new_x_bar  # same basis, different objective
            lp_solve_needed = False
        else:
            # Solve changed LP relaxation
            lp_new_problem = new_problem.as_lp()
            lp_new_solver = RevisedSimplex(lp_new_problem)
            lp_new_state = lp_new_solver.solve()
            z_lp_new = lp_new_state.optimal_value
            lp_solve_needed = True

        # --- Compute bound B (Theorem 2) ---
        bound = z_lp_new - c_new_x_old
        bound_ratio = bound / z_lp_new if abs(z_lp_new) > 1e-10 else 0.0

        # --- Gap-corrected estimate (Proposition 6) ---
        if abs(z_lp_old) > 1e-10:
            gap_est = gap * (z_lp_new / z_lp_old)
            bound_corrected = max(bound - gap_est, 0.0)
            bound_corrected_ratio = bound_corrected / z_lp_new if abs(z_lp_new) > 1e-10 else 0.0
        else:
            bound_corrected = None
            bound_corrected_ratio = None

        # --- Oguz bound (Theorem 1, for comparison) ---
        delta, oguz = self._oguz_bound(change, old_problem)

        # --- Decision (Theorem 7) ---
        if bound_ratio <= self.epsilon:
            decision = "skip"
            reason = (f"Bound B = {bound:.4f} ({bound_ratio:.1%} of z'_LP) "
                      f"≤ threshold {self.epsilon:.0%}. Safe to skip.")
        else:
            decision = "reoptimize"
            reason = (f"Bound B = {bound:.4f} ({bound_ratio:.1%} of z'_LP) "
                      f"> threshold {self.epsilon:.0%}. Reoptimization recommended.")

        return MIPBoundResult(
            decision=decision, reason=reason,
            bound=bound, bound_ratio=bound_ratio,
            bound_corrected=bound_corrected,
            bound_corrected_ratio=bound_corrected_ratio,
            original_integrality_gap=gap, gap_ratio=gap_ratio,
            z_mip_old=z_mip_old, z_lp_old=z_lp_old,
            z_lp_new=z_lp_new, c_new_x_old=c_new_x_old,
            old_solution_feasible=True, max_violation=0.0,
            within_lp_sensitivity=within_sens,
            lp_solve_needed=lp_solve_needed,
            oguz_relative_bound=oguz, delta=delta,
        )

    def _check_lp_sensitivity(self, lp_state, change, old_problem):
        '''Check if Δc and Δb are within LP sensitivity ranges.'''
        # Reuse ImpactAnalyzer's sensitivity check logic
        if change.delta_c is not None:
            for j, name in enumerate(old_problem.var_names):
                if abs(change.delta_c[j]) < 1e-10:
                    continue
                if name not in lp_state.sensitivity.obj_coeff_ranges:
                    return False
                lo, hi = lp_state.sensitivity.obj_coeff_ranges[name]
                new_c = old_problem.c[j] + change.delta_c[j]
                if new_c < lo - 1e-8 or new_c > hi + 1e-8:
                    return False

        if change.delta_b is not None:
            for i, name in enumerate(old_problem.constraint_names):
                if abs(change.delta_b[i]) < 1e-10:
                    continue
                if name not in lp_state.sensitivity.rhs_ranges:
                    return False
                lo, hi = lp_state.sensitivity.rhs_ranges[name]
                new_b = old_problem.b[i] + change.delta_b[i]
                if new_b < lo - 1e-8 or new_b > hi + 1e-8:
                    return False

        return True

    def _oguz_bound(self, change, old_problem):
        '''Compute Oguz relative bound 2δ/(1+δ) if applicable.'''
        if change.delta_c is None:
            return None, None

        delta = 0.0
        for j in range(len(old_problem.var_names)):
            if abs(change.delta_c[j]) > 1e-10:
                if abs(old_problem.c[j]) < 1e-10:
                    return float('inf'), 1.0  # c_j = 0, δ undefined
                rel = abs(change.delta_c[j] / old_problem.c[j])
                delta = max(delta, rel)

        if delta == 0:
            return 0.0, 0.0

        oguz = 2 * delta / (1 + delta)
        return delta, oguz
"""


# ============================================================
# 4. LPProblem.as_lp() Method
# ============================================================

AS_LP = """
Add to clara/model/problem.py:

class LPProblem:
    # ... existing fields ...

    def as_lp(self) -> 'LPProblem':
        '''Return a copy with integrality constraints removed.

        For MIP → LP relaxation: same A, b, c, bounds
        but integer_vars and binary_vars are empty.
        '''
        return LPProblem(
            c=self.c.copy(),
            A=self.A.copy(),
            b=self.b.copy(),
            var_names=list(self.var_names),
            constraint_names=list(self.constraint_names),
            name=self.name + "_lp_relaxation",
            sense=self.sense,
            lower_bounds=self.lower_bounds.copy() if self.lower_bounds is not None else None,
            upper_bounds=self.upper_bounds.copy() if self.upper_bounds is not None else None,
            integer_vars=set(),      # removed
            binary_vars=set(),       # removed
        )
"""


# ============================================================
# 5. CLI Integration: clara mip-bound
# ============================================================

CLI = """
New CLI command:

    clara mip-bound problem.lp --change new_problem.lp [--epsilon 0.05]

Or integrated into existing clara diff for MIP problems:

    clara diff old.lp new.lp
    → auto-detects MIP → runs MIPBoundAnalyzer → reports bound + decision

Update clara/cli.py diff command:
    if problem has integer/binary variables:
        # Run MIP bound analysis in addition to LP reopt pipeline
        mip_state = BranchAndBound(old_problem).solve()
        lp_state = RevisedSimplex(old_problem.as_lp()).solve()
        mip_result = MIPBoundAnalyzer().analyze(
            mip_state, lp_state, old_problem, new_problem, change
        )
        # Include MIP bound info in diff report
"""


# ============================================================
# 6. Test Cases
# ============================================================

TEST_CASES = """
tests/test_mip_bound.py

Setup: Use knapsack and multi-constraint instances with nonzero gap.

### 1. Bound validity (Theorem 2)
    - test_bound_nonneg
        → B ≥ 0 always
    - test_bound_ge_oc_objective_change
        → B ≥ true OC for various Δc perturbations
    - test_bound_ge_oc_rhs_change
        → B ≥ true OC when x* feasible
    - test_bound_ge_oc_compound
        → B ≥ true OC for compound changes
    - test_bound_exact_when_no_gap
        → TU problems (assignment): gap=0, B = OC exactly

### 2. Feasibility check (Theorem 4)
    - test_feasible_when_rhs_increases
        → Δb > 0 → always feasible (for <= constraints)
    - test_infeasible_when_rhs_decreases_past_slack
        → Δb_i < -slack_i → infeasible detected
    - test_infeasible_decision
        → decision = "infeasible"

### 3. Sensitivity-tightened (Theorem 3)
    - test_within_sensitivity_no_lp_solve
        → small Δc within range → lp_solve_needed = False
    - test_outside_sensitivity_lp_solve
        → large Δc → lp_solve_needed = True
    - test_sensitivity_bound_matches_full
        → within_sens bound ≈ full LP bound (same when basis preserved)

### 4. Gap-corrected estimate (Proposition 6)
    - test_corrected_tighter_than_raw
        → bound_corrected ≤ bound always
    - test_corrected_nonneg
        → bound_corrected ≥ 0 always (clamped)

### 5. Decision framework (Theorem 7)
    - test_skip_small_change
        → small perturbation → "skip"
    - test_reoptimize_large_change
        → large perturbation → "reoptimize"
    - test_skip_correctness
        → when skip, true OC/z'_LP < epsilon (no false skips)
    - test_custom_epsilon
        → epsilon=0.01 → more conservative, epsilon=0.20 → more permissive

### 6. Oguz comparison
    - test_oguz_bound_valid
        → Oguz 2δ/(1+δ) is valid relative bound
    - test_our_bound_computable_oguz_not
        → Our B is computable, Oguz needs z'*_MIP

### 7. Integration
    - test_with_knapsack_fixture
        → CLARA's knapsack_small.lp: z_LP=44, z_MIP=42
    - test_with_facility_fixture
        → CLARA's facility_small.lp
    - test_summary_readable
        → result.summary contains bound value, gap, decision

### 8. Edge cases
    - test_zero_change
        → no change → B = integrality gap, decision based on gap/z_LP
    - test_zero_gap_problem
        → TU problem, gap=0 → B = OC exactly
    - test_c_with_zeros
        → c has zero components → delta undefined, but our bound works
"""


# ============================================================
# 7. Experiment Addition
# ============================================================

EXPERIMENT = """
### Exp 9: MIP Opportunity Cost Bound (NEW)

benchmarks/scripts/run_mip_bound_benchmark.py

Instances:
    A. CLARA MIP fixtures (3): knapsack_small, facility_small, assignment_small
    B. Random binary programs (50): n=10..50, m=2n, generated with gap
    C. MIP Workshop 2023 benchmark (if available, download from GitHub)

For each (instance, perturbation):
    1. Solve original MIP → mip_state
    2. Solve LP relaxation → lp_state
    3. Apply perturbation → new_problem
    4. MIPBoundAnalyzer().analyze() → result (B, B_c, decision)
    5. Solve changed MIP → z'*_MIP (ground truth)
    6. Compute true OC = z'*_MIP - c'^T x*

Output CSV: benchmarks/results/exp9_mip_bound.csv
    instance, perturbation, change_type, magnitude,
    z_mip_old, z_lp_old, z_mip_new, z_lp_new,
    gap_old, gap_new, oc_true, bound_B, bound_Bc,
    B_valid, Bc_valid, B_over_OC, Bc_over_OC,
    decision, actual_needed, decision_correct,
    within_sensitivity, lp_solve_needed, delta, oguz_bound

Tables:
    Table 11: MIP bound tightness by problem type and change magnitude
    Table 12: Decision accuracy (skip vs reoptimize) at various thresholds

Figures:
    Figure 9: Scatter: B vs true OC (should be above y=x diagonal)
    Figure 10: Decision accuracy vs threshold curve
"""


# ============================================================
# 8. Module Structure
# ============================================================

MODULE_STRUCTURE = """
New files:
    clara/reopt/mip_bound.py             # MIPBoundAnalyzer
    tests/test_mip_bound.py              # all tests
    benchmarks/scripts/run_mip_bound_benchmark.py  # Exp 9

Modified files:
    clara/reopt/types.py                 # add MIPBoundResult
    clara/reopt/__init__.py              # re-export
    clara/model/problem.py               # add as_lp() method
    clara/cli.py                         # integrate MIP bound into diff command
"""


# ============================================================
# 9. Implementation Order
# ============================================================

IMPLEMENTATION_ORDER = """
1. git checkout -b feat/mip-bound

2. Add MIPBoundResult to clara/reopt/types.py
   Commit: "feat: add MIPBoundResult dataclass"

3. Add as_lp() to LPProblem
   Commit: "feat: LPProblem.as_lp() for LP relaxation"

4. Implement clara/reopt/mip_bound.py
   - MIPBoundAnalyzer class
   - _check_lp_sensitivity()
   - _oguz_bound()
   - analyze() main method
   Commit: "feat: MIP opportunity cost bound analyzer"

5. Tests
   - tests/test_mip_bound.py
   - Knapsack + multi-constraint golden values from numerical verification
   - Commit: "test: MIP bound tests with numerical verification"

6. CLI integration (optional, can defer)
   - Commit: "feat: MIP bound in clara diff for MIP problems"

7. Benchmark script
   - benchmarks/scripts/run_mip_bound_benchmark.py
   - Commit: "bench: Exp 9 MIP opportunity cost bound benchmark"

8. pytest full suite, update CLAUDE.md
   - Commit: "docs: update CLAUDE.md for MIP bound"
"""


# ============================================================
# 10. Golden Test Values (from numerical verification)
# ============================================================

GOLDEN_VALUES = """
Knapsack (c=[16,22,12,8,11], A=[5,7,4,3,4], b=14, binary):
    z*_LP = 44.0, z*_MIP = 42.0, gap = 4.55%
    x* = [0, 1, 1, 1, 0], x̄ = [1, 1, 0.5, 0, 0]

    Δc = [2,-2,1,-1,0]:  OC = 2.0,  B = 5.29,  B≥OC ✓
    Δc = [5,-5,3,-2,4]:  OC = 13.0, B = 15.43, B≥OC ✓
    Δc = [8,-8,6,-4,5]:  OC = 22.0, B = 24.0,  B≥OC ✓

    Δb = -1: infeasible (slack=0)
    Δb = +2: OC = 8.0, B = 8.0, B/OC = 1.00 (exact!)
    Δb = +5: OC = 16.0, B = 16.25, B/OC = 1.02

Multi-constraint (n=15, m=8, binary, seed=777):
    z*_LP = 162.36, z*_MIP = 154.57, gap = 4.79%

    Δc scale=0.5: OC = 1.47, B = 11.82, Bc = 3.68
    Δc scale=1.0: OC = 4.73, B = 15.86, Bc = 7.36
"""