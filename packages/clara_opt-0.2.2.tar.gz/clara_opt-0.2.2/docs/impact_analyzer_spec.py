"""
CLARA Phase 2 — Impact Analyzer Design Specification
======================================================

The Impact Analyzer takes a ParameterChange (from Change Detector)
and the current SolveState, then decides:
    1. Is reoptimization needed?
    2. If yes, what method? (warm-start vs scratch)
    3. How bad is it if we skip reoptimization?

Three-step decision pipeline:
    Step 1: Oguz bound (Type C only) — quick upper bound on opportunity cost
    Step 2: Sensitivity range check — does the change break the current basis?
    Step 3: Reoptimization method recommendation

Output: ReoptDecision (already defined in reopt/types.py)

Branch: feat/impact-analyzer
"""


# ============================================================
# 1. Public API
# ============================================================

API = """
# Module: clara/reopt/analyzer.py

class ImpactAnalyzer:
    '''Decide whether reoptimization is needed and recommend a method.

    Uses mathematical guarantees (Oguz bound, sensitivity ranges)
    rather than heuristics wherever possible.
    '''

    def __init__(
        self,
        oguz_threshold: float = 0.05,     # skip reopt if bound < 5%
        force_reopt_types: set[ChangeType] = {ChangeType.TYPE_V, ChangeType.TYPE_X,
                                                ChangeType.TYPE_M, ChangeType.TYPE_MULTI},
    ):
        '''
        Args:
            oguz_threshold: If Oguz bound < this, recommend skipping reoptimization.
                           Default 5% — "losing at most 5% is acceptable."
            force_reopt_types: Change types that always require reoptimization
                              (structural changes can't be analyzed by sensitivity alone).
        '''

    def analyze(
        self,
        state: SolveState,
        change: ParameterChange,
        old_problem: LPProblem,
    ) -> ReoptDecision:
        '''Analyze the impact of a parameter change on the current solution.

        Args:
            state: Current SolveState (with sensitivity ranges and optionally B⁻¹).
            change: Detected parameter change (from ChangeDetector).
            old_problem: Original problem (for objective coefficients in Oguz bound).

        Returns:
            ReoptDecision with recommendation and supporting evidence.
        '''

# Usage:
    analyzer = ImpactAnalyzer()
    decision = analyzer.analyze(current_state, change, old_problem)

    if decision.should_reoptimize:
        print(f"Reoptimization needed: {decision.reason}")
        print(f"Recommended method: {decision.recommended_method}")
    else:
        print(f"Safe to skip: {decision.reason}")
        if decision.oguz_bound is not None:
            print(f"Max opportunity cost: {decision.oguz_bound:.2%}")
"""


# ============================================================
# 2. Step 1: Oguz Bound (Type C only)
# ============================================================

OGUZ_BOUND = """
Reference: Oguz (2000), Management Science 46(7).

When only objective coefficients change (Type C):
    δ = max_j |Δc_j / c_j|   (max relative change across all variables)

    Oguz bound = 2δ / (1 + δ)

    This bounds the relative opportunity cost of using the OLD solution
    with the NEW objective, vs. reoptimizing:
        (z_new* - c_new^T x_old) / z_new*  ≤  2δ / (1 + δ)

    Where z_new* is the new optimal and x_old is the old solution.

Wendell tolerance tightening:
    If the sensitivity range gives a tolerance α (smallest relative change
    that breaks the basis), then:
        δ' = (δ - α) / (1 + α)
    And the tightened bound is 2δ' / (1 + δ')
    (Only applies if δ > α, otherwise basis is preserved and bound = 0)

Implementation:
    def _oguz_bound(
        self,
        change: ParameterChange,
        old_problem: LPProblem,
        state: SolveState,
    ) -> tuple[float, float, str]:
        '''Compute Oguz bound and Wendell-tightened bound.

        Returns:
            (raw_bound, tightened_bound, explanation)
        '''
        # Compute δ = max relative change
        delta = 0.0
        for j, name in enumerate(old_problem.var_names):
            if change.delta_c is not None and abs(change.delta_c[j]) > 1e-10:
                if abs(old_problem.c[j]) > 1e-10:
                    rel = abs(change.delta_c[j] / old_problem.c[j])
                    delta = max(delta, rel)
                else:
                    # c_j was 0, now nonzero → infinite relative change
                    delta = float('inf')

        raw_bound = 2 * delta / (1 + delta) if delta < float('inf') else 1.0

        # Wendell tolerance: smallest relative obj coeff change that breaks basis
        alpha = float('inf')
        for name in old_problem.var_names:
            if name in state.sensitivity.obj_coeff_ranges:
                lo, hi = state.sensitivity.obj_coeff_ranges[name]
                j = old_problem.var_names.index(name)
                c_j = old_problem.c[j]
                if abs(c_j) > 1e-10:
                    # How much can c_j change relatively before basis breaks?
                    tol_down = abs((c_j - lo) / c_j) if lo > float('-inf') else float('inf')
                    tol_up = abs((hi - c_j) / c_j) if hi < float('inf') else float('inf')
                    alpha = min(alpha, tol_down, tol_up)

        if alpha == float('inf'):
            tightened_bound = raw_bound
        elif delta <= alpha:
            tightened_bound = 0.0  # change within tolerance → no cost
        else:
            delta_prime = (delta - alpha) / (1 + alpha)
            tightened_bound = 2 * delta_prime / (1 + delta_prime)

        explanation = (
            f"Oguz bound: δ = {delta:.4f}, raw bound = {raw_bound:.4f} "
            f"({raw_bound:.1%} max opportunity cost). "
            f"Wendell tolerance α = {alpha:.4f}, "
            f"tightened bound = {tightened_bound:.4f} ({tightened_bound:.1%})."
        )

        return raw_bound, tightened_bound, explanation

Note: Oguz bound only applies to Type C. For Type R, RC, and structural changes,
we skip directly to sensitivity range check or force reoptimization.
"""


# ============================================================
# 3. Step 2: Sensitivity Range Check
# ============================================================

SENSITIVITY_CHECK = """
For each changed parameter, check if the change falls within the
sensitivity range stored in SolveState.

Type R (RHS change):
    For each constraint i where delta_b[i] != 0:
        (lo_i, hi_i) = state.sensitivity.rhs_ranges[constraint_name]
        new_b_i = old_problem.b[i] + delta_b[i]
        if lo_i <= new_b_i <= hi_i:
            → basis preserved for this constraint
        else:
            → basis broken, reoptimization needed

    If ALL changed constraints are within range:
        → basis preserved, just recompute x_B = B⁻¹ * b_new
        → no pivots needed, O(m²) cost
        → recommended_method = "basis_update" (not even warm-start, just recompute)

Type C (objective change):
    For each variable j where delta_c[j] != 0:
        (lo_j, hi_j) = state.sensitivity.obj_coeff_ranges[var_name]
        new_c_j = old_problem.c[j] + delta_c[j]
        if lo_j <= new_c_j <= hi_j:
            → basis preserved for this variable
        else:
            → optimality violated, reoptimization needed

    If ALL changed coefficients are within range:
        → basis still optimal, objective value changes but solution doesn't
        → recommended_method = "none" (just recompute objective = c_new^T x_old)

Type RC (compound):
    Check both b and c ranges independently.
    If BOTH are within ranges → basis preserved.
    If either breaks → parametric LP needed (or scratch re-solve).
    → recommended_method = "parametric_lp" or "warm_start"

Implementation:
    def _sensitivity_check(
        self,
        state: SolveState,
        change: ParameterChange,
        old_problem: LPProblem,
    ) -> tuple[bool, list[str], str]:
        '''Check if all changes fall within sensitivity ranges.

        Returns:
            (within_range, violated_parameters, explanation)

            within_range: True if ALL changes are within ranges.
            violated_parameters: List of parameter names that break the basis.
            explanation: Human-readable summary.
        '''
"""


# ============================================================
# 4. Step 3: Recommendation
# ============================================================

RECOMMENDATION = """
Based on Steps 1 and 2, recommend one of:

    "none"          → No action needed. Current solution is still optimal,
                      or opportunity cost is below threshold.

    "recompute"     → Basis preserved. Just recompute x_B = B⁻¹ * b_new
                      and/or z = c_new^T * x. No pivots. O(m²).

    "warm_start"    → Basis broken but close. Warm-start simplex from
                      current B⁻¹. Expect few pivots.

    "parametric_lp" → Type RC compound change. Use parametric LP solver
                      to trace the path from old to new. (Phase 2 later)

    "scratch"       → Major structural change or too far from current basis.
                      Re-solve from scratch (no warm-start benefit).

Decision tree:
    change.type in {V, X, M, MULTI, A}?
        → "scratch" (structural changes require full re-solve)

    change.type == TYPE_C?
        → Compute Oguz bound
        → If tightened_bound < threshold → "none"
        → Else check sensitivity ranges
            → All within range → "none" (obj value changes, solution doesn't)
            → Some violated → "warm_start"

    change.type == TYPE_R?
        → Check sensitivity ranges
            → All within range → "recompute" (B⁻¹ * b_new, no pivots)
            → Some violated → "warm_start"

    change.type == TYPE_RC?
        → Check sensitivity ranges (both b and c)
            → All within range → "recompute"
            → Some violated → "parametric_lp" (if available) or "warm_start"
"""


# ============================================================
# 5. ReoptDecision Construction
# ============================================================

REOPT_DECISION = """
Already defined in reopt/types.py:

    @dataclass(frozen=True)
    class ReoptDecision:
        should_reoptimize: bool
        reason: str
        oguz_bound: Optional[float] = None
        within_sensitivity: bool = False
        estimated_pivots: Optional[int] = None
        recommended_method: Optional[str] = None

Example outputs:

TYPE_C, within sensitivity:
    ReoptDecision(
        should_reoptimize=False,
        reason="All objective coefficient changes are within sensitivity ranges. "
               "Current basis remains optimal. Objective value changes from 3688.89 to 8266.67 "
               "but solution structure is unchanged.",
        oguz_bound=0.0,
        within_sensitivity=True,
        recommended_method="none",
    )

TYPE_C, Oguz bound below threshold:
    ReoptDecision(
        should_reoptimize=False,
        reason="Oguz bound = 2.3% (below 5% threshold). "
               "Maximum opportunity cost of keeping the old solution is 2.3%.",
        oguz_bound=0.023,
        within_sensitivity=False,
        recommended_method="none",
    )

TYPE_C, reopt needed:
    ReoptDecision(
        should_reoptimize=True,
        reason="Objective coefficient changes exceed sensitivity ranges for x1, x3. "
               "Oguz bound = 125% — reoptimization strongly recommended.",
        oguz_bound=1.25,
        within_sensitivity=False,
        recommended_method="warm_start",
    )

TYPE_R, basis preserved:
    ReoptDecision(
        should_reoptimize=False,
        reason="All RHS changes are within sensitivity ranges. "
               "Basis preserved — recompute x_B = B⁻¹ * b_new (no pivots needed).",
        within_sensitivity=True,
        recommended_method="recompute",
    )

TYPE_R, basis broken:
    ReoptDecision(
        should_reoptimize=True,
        reason="RHS change in S1 (1200 → 1800) exceeds sensitivity range [1109, 1600]. "
               "Basis is no longer feasible — warm-start from current basis recommended.",
        within_sensitivity=False,
        recommended_method="warm_start",
    )

TYPE_V (structural):
    ReoptDecision(
        should_reoptimize=True,
        reason="2 new variables added. Structural change requires full re-solve.",
        recommended_method="scratch",
    )
"""


# ============================================================
# 6. Full analyze() Logic
# ============================================================

ANALYZE_LOGIC = """
def analyze(self, state, change, old_problem) -> ReoptDecision:

    # Structural changes → always re-solve
    if change.change_type in self.force_reopt_types:
        return ReoptDecision(
            should_reoptimize=True,
            reason=f"{change.summary}. Structural change requires full re-solve.",
            recommended_method="scratch",
        )

    # Type C: Oguz bound first, then sensitivity
    if change.change_type == ChangeType.TYPE_C:
        raw, tightened, oguz_expl = self._oguz_bound(change, old_problem, state)
        within, violated, sens_expl = self._sensitivity_check(state, change, old_problem)

        if within:
            return ReoptDecision(
                should_reoptimize=False,
                reason=f"All objective coefficient changes within sensitivity ranges. {oguz_expl}",
                oguz_bound=tightened,
                within_sensitivity=True,
                recommended_method="none",
            )

        if tightened < self.oguz_threshold:
            return ReoptDecision(
                should_reoptimize=False,
                reason=f"Oguz bound {tightened:.1%} below threshold {self.oguz_threshold:.0%}. "
                       f"Max opportunity cost is small. {oguz_expl}",
                oguz_bound=tightened,
                within_sensitivity=False,
                recommended_method="none",
            )

        return ReoptDecision(
            should_reoptimize=True,
            reason=f"Sensitivity ranges violated for: {', '.join(violated)}. {oguz_expl}",
            oguz_bound=tightened,
            within_sensitivity=False,
            recommended_method="warm_start",
        )

    # Type R: sensitivity check only
    if change.change_type == ChangeType.TYPE_R:
        within, violated, sens_expl = self._sensitivity_check(state, change, old_problem)

        if within:
            return ReoptDecision(
                should_reoptimize=False,
                reason=f"All RHS changes within sensitivity ranges. "
                       f"Recompute x_B = B⁻¹ * b_new (no pivots). {sens_expl}",
                within_sensitivity=True,
                recommended_method="recompute",
            )

        return ReoptDecision(
            should_reoptimize=True,
            reason=f"RHS sensitivity ranges violated for: {', '.join(violated)}. {sens_expl}",
            within_sensitivity=False,
            recommended_method="warm_start",
        )

    # Type RC: check both, recommend parametric if available
    if change.change_type == ChangeType.TYPE_RC:
        within, violated, sens_expl = self._sensitivity_check(state, change, old_problem)

        if within:
            return ReoptDecision(
                should_reoptimize=False,
                reason=f"All changes within sensitivity ranges (both RHS and obj). {sens_expl}",
                within_sensitivity=True,
                recommended_method="recompute",
            )

        return ReoptDecision(
            should_reoptimize=True,
            reason=f"Compound change — sensitivity violated for: {', '.join(violated)}. "
                   f"Parametric LP recommended for accurate path tracing. {sens_expl}",
            within_sensitivity=False,
            recommended_method="parametric_lp",
        )

    # Type A or unknown → warm_start
    return ReoptDecision(
        should_reoptimize=True,
        reason=f"{change.summary}. Reoptimization recommended.",
        recommended_method="warm_start",
    )
"""


# ============================================================
# 7. Test Cases
# ============================================================

TEST_CASES = """
tests/test_impact_analyzer.py

Uses Albici fixtures + SolveState from InternalSimplex.

Setup: solve albici_base.lp → get base_state. Then apply each change scenario.

1. Oguz bound computation
   - test_oguz_albici_cost_change
        → delta_c = [5, 2, 2], c_orig = [3, 4, 5]
        → δ = max(5/3, 2/4, 2/5) = 5/3
        → raw_bound = 2*(5/3) / (1 + 5/3) = (10/3) / (8/3) = 10/8 = 1.25
        → Very large → reoptimization strongly recommended

   - test_oguz_small_change
        → delta_c = [0.1, 0.1, 0.1], c_orig = [3, 4, 5]
        → δ = max(0.1/3, 0.1/4, 0.1/5) = 0.0333
        → raw_bound = 2*0.0333 / 1.0333 ≈ 0.0645 (6.45%)
        → Above default 5% threshold → but check sensitivity first

   - test_oguz_tiny_change
        → delta_c = [0.01, 0, 0], c_orig = [3, 4, 5]
        → δ = 0.01/3 ≈ 0.0033
        → raw_bound ≈ 0.0066 (0.66%)
        → Below 5% threshold → skip reoptimization

   - test_oguz_zero_original_coeff
        → c_orig has a zero → δ = inf → bound = 1.0 (100%)
        → Always reoptimize

   - test_wendell_tightening
        → δ > α but tightened bound < threshold → skip

2. Sensitivity range check
   - test_type_r_within_range
        → Albici b1: delta_b = [100, -200, -200, 200]
        → All within sensitivity ranges → within=True, method="recompute"

   - test_type_r_outside_range
        → Albici b2: delta_b = [300, -100, 400, 0]
        → Some constraints violated → within=False, method="warm_start"

   - test_type_c_within_range
        → Small cost perturbation within obj coeff ranges
        → within=True, method="none"

   - test_type_c_outside_range
        → Albici cost change: [5, 2, 2]
        → Ranges violated → within=False, method="warm_start"

   - test_type_rc_within_range
        → Both b and c changes small enough → "recompute"

   - test_type_rc_outside_range
        → Compound change exceeds ranges → "parametric_lp"

3. Structural changes
   - test_type_v_always_scratch      → TYPE_V → "scratch"
   - test_type_x_always_scratch      → TYPE_X → "scratch"
   - test_type_m_always_scratch      → TYPE_M → "scratch"
   - test_type_multi_always_scratch  → TYPE_MULTI → "scratch"

4. Full pipeline integration
   - test_full_pipeline_b1
        → detect(base, b1) → analyze(state, change, base) → should_reoptimize=False
   - test_full_pipeline_b2
        → detect(base, b2) → analyze(state, change, base) → should_reoptimize=True
   - test_full_pipeline_cost
        → detect(base, cost) → analyze(state, change, base) → should_reoptimize=True
   - test_full_pipeline_columns
        → detect(base, columns) → analyze(state, change, base) → should_reoptimize=True, "scratch"

5. Decision reason quality
   - test_reason_contains_violated_params  → violated parameter names in reason
   - test_reason_contains_oguz_value       → Oguz bound value in reason
   - test_reason_contains_sensitivity_info → range values in reason

6. Configurable threshold
   - test_custom_threshold_strict   → oguz_threshold=0.01 → more reopt
   - test_custom_threshold_lenient  → oguz_threshold=0.20 → less reopt
"""


# ============================================================
# 8. Module Structure
# ============================================================

MODULE_STRUCTURE = """
New files:
    clara/reopt/analyzer.py          # ImpactAnalyzer class
    tests/test_impact_analyzer.py    # all tests

Modified files:
    clara/reopt/__init__.py          # re-export ImpactAnalyzer
"""


# ============================================================
# 9. Implementation Order
# ============================================================

IMPLEMENTATION_ORDER = """
1. git checkout -b feat/impact-analyzer

2. Implement clara/reopt/analyzer.py
   - ImpactAnalyzer class
   - _oguz_bound() with Wendell tightening
   - _sensitivity_check() for Type R, C, RC
   - analyze() main decision tree
   - Commit: "feat: Impact Analyzer (Oguz bound + sensitivity check)"

3. Tests
   - tests/test_impact_analyzer.py
   - Oguz bound numerical tests (hand-verified)
   - Sensitivity range tests using Albici fixtures
   - Full pipeline tests (detect → analyze)
   - Commit: "test: Impact Analyzer tests with Albici validation"

4. pytest full suite, update CLAUDE.md
   - Commit: "docs: update CLAUDE.md for Phase 2 Impact Analyzer"
"""