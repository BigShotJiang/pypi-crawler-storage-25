"""
CLARA — Parametric LP Design Specification
=============================================

Parametric LP solves Type RC compound changes (b and c change simultaneously)
by tracing the optimal path from the old problem (θ=0) to the new problem (θ=1).

    max (c + θΔc)ᵀx,  s.t. Ax ≤ b + θΔb,  x ≥ 0,  θ ∈ [0, 1]

At each breakpoint θ*, the basis changes — meaning the solution structure
qualitatively shifts. Between breakpoints, the same basis is optimal
and the solution varies linearly with θ.

This is CLARA's unique contribution that no existing tool provides:
    - Albici (2010): no compound changes (Gap B)
    - Oguz (2000): Type C only, no RHS changes
    - EOR (Zhang 2025): always scratch re-solve
    - CLARA: traces the exact path, explains each structural transition

Theory: Gal & Greenberg (1997), Advances in Sensitivity Analysis and Parametric Programming.

Branch: feat/parametric-lp
"""


# ============================================================
# 1. Algorithm
# ============================================================

ALGORITHM = """
Input:
    - old problem (b₀, c₀) with solved SolveState (basis B, B⁻¹)
    - change vectors Δb, Δc
    - θ ranges from 0 (old) to 1 (new)

At θ=0, we have optimal basis B with:
    x_B(θ) = B⁻¹ @ (b₀ + θΔb)            — basic variable values as function of θ
    c̄_j(θ) = (c₀ + θΔc)_j - (c_B + θΔc_B)ᵀ B⁻¹ aⱼ  — reduced costs as function of θ

Both x_B and c̄_j are LINEAR in θ. The current basis stays optimal as long as:
    1. Primal feasibility: x_B(θ) ≥ 0      (all basic vars non-negative)
    2. Dual feasibility: c̄_j(θ) ≤ 0        (all reduced costs ≤ 0 for max)

Breakpoint: the smallest θ* > current_θ where either condition is violated.

Algorithm:
    current_θ = 0
    current_basis = B
    current_B_inv = B⁻¹
    breakpoints = []

    while current_θ < 1:
        # Compute next breakpoint
        θ_primal, primal_info = find_primal_breakpoint(current_θ)
        θ_dual, dual_info = find_dual_breakpoint(current_θ)
        θ_next = min(θ_primal, θ_dual)

        if θ_next >= 1:
            # No more breakpoints before θ=1 → current basis is optimal at θ=1
            break

        # Record breakpoint
        breakpoints.append(Breakpoint(θ=θ_next, type=..., info=...))

        # Perform one pivot at θ_next
        if θ_next == θ_primal:
            # Primal breakpoint: a basic variable hits 0 → leaves basis
            # Use dual simplex ratio test to select entering variable
            pivot_dual(primal_info)
        else:
            # Dual breakpoint: a reduced cost hits 0 → variable wants to enter
            # Use primal simplex ratio test to select leaving variable
            pivot_primal(dual_info)

        current_θ = θ_next

    # Evaluate final solution at θ=1
    x_B_final = current_B_inv @ (b₀ + 1.0 * Δb)
    return solution, breakpoints
"""


# ============================================================
# 2. Finding Breakpoints
# ============================================================

BREAKPOINTS = """
Given current basis B with B⁻¹, current_θ:

PRIMAL BREAKPOINTS (x_B hits 0):
    For each basic variable i:
        x_B_i(θ) = [B⁻¹ @ b₀]_i + θ * [B⁻¹ @ Δb]_i
                  = val_i + θ * slope_i

        (Adjusted from current_θ):
        x_B_i(θ) = val_i + current_θ * slope_i + (θ - current_θ) * slope_i

        If slope_i < 0:  (value decreasing)
            θ*_i = -val_i(current_θ) / slope_i + current_θ
            where val_i(current_θ) = [B⁻¹ @ (b₀ + current_θ * Δb)]_i

        θ_primal = min { θ*_i : θ*_i > current_θ + ε }

    Implementation:
        def _find_primal_breakpoint(self, current_theta):
            b_theta = self.b0 + current_theta * self.delta_b
            x_B = self.B_inv @ b_theta
            slope = self.B_inv @ self.delta_b

            best_theta = float('inf')
            leaving_row = -1

            for i in range(self.m):
                if slope[i] < -PIVOT_TOL:
                    theta_i = current_theta + (-x_B[i] / slope[i])
                    if theta_i > current_theta + PIVOT_TOL and theta_i < best_theta:
                        best_theta = theta_i
                        leaving_row = i

            return best_theta, leaving_row


DUAL BREAKPOINTS (reduced cost hits 0):
    For each non-basic variable j:
        c̄_j(θ) = c_j + θ*Δc_j - (c_B + θ*Δc_B)ᵀ B⁻¹ aⱼ
                = rc_j(current_θ) + (θ - current_θ) * rc_slope_j

        rc_j(θ) = [c₀_j + θΔc_j] - [c_B₀ + θΔc_B]ᵀ B⁻¹ aⱼ

        Simpler: rc_j(θ) = rc_j_base + θ * rc_j_delta
        where:
            rc_j_base = c₀_j - c_B₀ᵀ B⁻¹ aⱼ        (reduced cost at θ=0)
            rc_j_delta = Δc_j - Δc_Bᵀ B⁻¹ aⱼ        (slope of reduced cost)

        For max: we need rc_j ≤ 0.
        If rc_j_slope > 0: (reduced cost increasing toward positive)
            θ*_j = -rc_j(current_θ) / rc_j_slope + current_θ

        θ_dual = min { θ*_j : θ*_j > current_θ + ε }

    Implementation:
        def _find_dual_breakpoint(self, current_theta):
            c_B = self._get_c_B(current_theta)
            dc_B = self._get_dc_B()
            y = c_B @ self.B_inv
            dy = dc_B @ self.B_inv

            best_theta = float('inf')
            entering_col = -1

            for j in range(self.N):
                if j in self.basis:
                    continue
                a_j = self.A_full[:, j]

                # rc at current_theta
                c_j_theta = self.c0_full[j] + current_theta * self.dc_full[j]
                rc_j = c_j_theta - y @ a_j

                # slope of rc w.r.t. theta
                rc_slope = self.dc_full[j] - dy @ a_j

                if rc_slope > PIVOT_TOL and rc_j < -PIVOT_TOL:
                    # rc is increasing and currently negative → will hit 0
                    theta_j = current_theta + (-rc_j / rc_slope)
                    if theta_j > current_theta + PIVOT_TOL and theta_j < best_theta:
                        best_theta = theta_j
                        entering_col = j

            return best_theta, entering_col
"""


# ============================================================
# 3. Pivot at Breakpoint
# ============================================================

PIVOT = """
At a primal breakpoint (basic variable goes to 0):
    - Leaving variable: basis[leaving_row]
    - Need to find entering variable via DUAL ratio test
    - Same as one step of dual simplex at this θ

    w = B⁻¹[leaving_row, :]          # pivot row of B⁻¹
    For each non-basic j:
        d_j = w @ a_j
        if d_j < -tol:
            rc_j = current reduced cost at θ*
            ratio = rc_j / d_j         # both ≤ 0 → ratio ≥ 0
    entering = argmin ratio (Bland's rule for ties)

At a dual breakpoint (reduced cost reaches 0):
    - Entering variable: the non-basic variable whose rc hit 0
    - Need to find leaving variable via PRIMAL ratio test
    - Same as one step of primal simplex at this θ

    d = B⁻¹ @ a_entering
    x_B = B⁻¹ @ b(θ*)
    For each basic i:
        if d[i] > tol:
            ratio = x_B[i] / d[i]
    leaving = argmin ratio (Bland's rule for ties)

After pivot: update B⁻¹ using standard eta update (same as primal/dual simplex).
"""


# ============================================================
# 4. Breakpoint Data Structure
# ============================================================

BREAKPOINT_STRUCTURE = """
Add to clara/reopt/types.py:

@dataclass(frozen=True)
class ParametricBreakpoint:
    '''A point where the basis changes along the parametric path.'''
    theta: float                        # θ value where basis changes
    breakpoint_type: str                # "primal" or "dual"

    # What triggered the breakpoint
    leaving_var: str | None             # variable that left basis (primal breakpoint)
    entering_var: str | None            # variable that entered basis (dual breakpoint)

    # Solution at this breakpoint
    objective_value: float              # z(θ*)
    basic_variables: tuple[str, ...]    # basis after pivot

    # Explanation
    explanation: str                    # human-readable description


@dataclass(frozen=True)
class ParametricResult:
    '''Output of parametric LP solver.'''
    new_state: SolveState               # solution at θ=1
    breakpoints: tuple[ParametricBreakpoint, ...]
    theta_start: float                  # always 0
    theta_end: float                    # always 1
    num_pivots: int                     # total pivots along path
    path_monotone: bool                 # was objective monotonically changing?
    solve_time_seconds: float

    @property
    def num_breakpoints(self) -> int:
        return len(self.breakpoints)

    @property
    def summary(self) -> str:
        if not self.breakpoints:
            return ("No breakpoints — current basis is optimal for the entire "
                    "parameter range [0, 1]. Solution changes continuously.")
        return (
            f"{self.num_breakpoints} breakpoint(s) found along θ ∈ [0, 1]. "
            f"{self.num_pivots} pivot(s) performed. "
            f"First structural change at θ = {self.breakpoints[0].theta:.4f}."
        )
"""


# ============================================================
# 5. Public API
# ============================================================

API = """
# Module: clara/reopt/parametric.py

class ParametricLPSolver:
    '''Trace the optimal path from old to new problem via parametric LP.

    Solves: max (c₀ + θΔc)ᵀx  s.t.  Ax ≤ b₀ + θΔb,  x ≥ 0,  θ ∈ [0, 1]

    Requires B⁻¹ from the old solution (InternalSimplex only).
    '''

    def solve(
        self,
        old_state: SolveState,
        old_problem: LPProblem,
        delta_b: np.ndarray,
        delta_c: np.ndarray,
    ) -> ParametricResult:
        '''Trace the parametric path from θ=0 to θ=1.

        Args:
            old_state: Solved state at θ=0 (must have B⁻¹).
            old_problem: The original problem.
            delta_b: RHS change vector (b_new - b_old).
            delta_c: Objective change vector (c_new - c_old).

        Returns:
            ParametricResult with breakpoints and final solution.
        '''
"""


# ============================================================
# 6. Breakpoint Explanation Generation
# ============================================================

EXPLANATIONS = """
Each breakpoint generates a natural language explanation:

Primal breakpoint (θ=0.625, y2 leaves):
    "At θ = 0.6250 (62.5% of the way to the new parameters), slack variable y2
     (constraint S2) hits zero — S2 becomes binding. This means Department 2
     reaches full capacity at this point. Before: 3 binding constraints.
     After: all 4 constraints are binding."

Dual breakpoint (θ=0.6667, y4 enters):
    "At θ = 0.6667 (66.7%), the reduced cost of slack y4 reaches zero —
     constraint S4 wants to become non-binding. Variable x3 leaves the basis
     (x3 drops to 0). Product P3 is no longer manufactured beyond this point."

No breakpoints:
    "The current basis remains optimal for the entire parameter change.
     The solution shifts continuously from x_old to x_new without any
     structural change. This happens because all changes fall within
     the combined sensitivity ranges."

This is the unique explainability contribution:
    - Other tools: "old solution → new solution" (black box)
    - CLARA: "at 62.5% of the change, Department 2 becomes a bottleneck.
              At 66.7%, Product 3 drops out of production."
"""


# ============================================================
# 7. Integration with Reoptimizer
# ============================================================

REOPTIMIZER_INTEGRATION = """
Update reoptimizer.py _parametric_lp():

BEFORE (placeholder):
    def _parametric_lp(self, old_state, new_problem, change):
        return self._warm_start(old_state, new_problem, change)

AFTER (real implementation):
    def _parametric_lp(self, old_state, new_problem, change):
        if old_state.basis_inverse is None:
            return self._scratch(new_problem)

        if change.delta_b is None or change.delta_c is None:
            # Not a compound change — shouldn't be here, but handle gracefully
            return self._warm_start(old_state, new_problem, change)

        solver = ParametricLPSolver()
        param_result = solver.solve(
            old_state, old_problem, change.delta_b, change.delta_c
        )

        return ReoptResult(
            new_state=param_result.new_state,
            method_used="parametric_lp",
            pivots=param_result.num_pivots,
            scratch_estimate=old_state.iteration_count,
            basis_preserved=(param_result.num_breakpoints == 0),
            reopt_time_seconds=param_result.solve_time_seconds,
        )

Also need to pass old_problem to _parametric_lp. Update the dispatch in reoptimize():
    elif method == "parametric_lp":
        return self._parametric_lp(old_state, new_problem, change, old_problem)

And update the reoptimize() signature to accept old_problem (or retrieve it from change context).
"""


# ============================================================
# 8. Integration with Diff Report
# ============================================================

DIFF_REPORT_INTEGRATION = """
When parametric LP is used, the Diff Report gains a new section:

    PARAMETRIC PATH
    ─────────────────────────────────────────────────
    Compound change traced via parametric LP (θ ∈ [0, 1]):

      θ = 0.0000: z = 3688.89  [original solution]
      θ = 0.6250: z = 7292.19  ← Breakpoint: S2 becomes binding (y2 leaves basis)
      θ = 0.6667: z = 7563.00  ← Breakpoint: x3 drops to 0 (leaves basis)
      θ = 1.0000: z = 10000.00 [new solution]

    2 structural transitions detected.
    First change occurs at 62.5% of the parameter shift.

Add to DiffReport.to_text():
    if self.reopt_result.method_used == "parametric_lp" and hasattr(...):
        # Include parametric path section

Add optional parametric_result field to DiffReport (or embed via ReoptResult).
"""


# ============================================================
# 9. Albici Verified Test Data (golden values)
# ============================================================

VERIFIED_DATA = """
Problem: Albici base → compound change (b2 + cost)
    b: (1200, 1400, 2000, 800) → (1500, 1300, 2400, 800)
    c: (3, 4, 5) → (8, 6, 7)
    Δb = [300, -100, 400, 0]
    Δc = [5, 2, 2]

Original basis: {y2, x1, x2, x3} with known B⁻¹

Breakpoints (analytically derived and scipy-verified):
    1. θ* = 5/8 = 0.625 — PRIMAL breakpoint
       y2 (slack S2) hits 0, S2 becomes binding
       x_B[0] = 111.11 + θ*(-177.78) ≈ 0
       z(0.625) = 7292.19

    2. θ* = 2/3 ≈ 0.6667 — DUAL breakpoint
       c̄_y4 hits 0, constraint S4 wants to enter
       x3 leaves basis (drops to 0)
       z(0.667) = 7563.00

After θ = 2/3: basis changes, x3 = 0 for remaining path

Solution at θ = 1:
    z = 10000.0, x = [1100, 200, 0]

Path samples (all verified by scipy):
    θ=0.0: z=3688.89  x=[755.56, 133.33, 177.78]
    θ=0.1: z=4207.67  x=[776.67, 140.00, 173.33]
    θ=0.2: z=4748.44  x=[797.78, 146.67, 168.89]
    θ=0.3: z=5311.22  x=[818.89, 153.33, 164.44]
    θ=0.4: z=5896.00  x=[840.00, 160.00, 160.00]
    θ=0.5: z=6502.78  x=[861.11, 166.67, 155.56]
    θ=0.6: z=7131.56  x=[882.22, 173.33, 151.11]
    θ=0.625: z=7292.19 ← breakpoint 1
    θ=0.667: z=7563.00 ← breakpoint 2
    θ=0.7: z=7797.00  x=[1050.00, 180.00, 0.00]
    θ=0.8: z=8512.00  x=[1066.67, 186.67, 0.00]
    θ=0.9: z=9246.33  x=[1083.33, 193.33, 0.00]
    θ=1.0: z=10000.00 x=[1100.00, 200.00, 0.00]
"""


# ============================================================
# 10. Test Cases
# ============================================================

TEST_CASES = """
tests/test_parametric_lp.py

1. Breakpoint detection
   - test_albici_primal_breakpoint
        → θ* = 5/8 = 0.625, leaving_row = 0 (y2)
   - test_albici_dual_breakpoint
        → θ* = 2/3 ≈ 0.6667, entering_col = y4 column
   - test_breakpoint_order
        → primal (0.625) comes before dual (0.667)

2. Full parametric solve
   - test_albici_compound_optimal
        → final optimal = 10000.0 at θ=1
   - test_albici_compound_num_breakpoints
        → exactly 2 breakpoints
   - test_albici_compound_x3_zero_after_breakpoint
        → x3 = 0 for θ > 2/3
   - test_albici_compound_matches_scratch
        → parametric result == scratch solve of the θ=1 problem

3. Path correctness
   - test_path_samples
        → verify z(θ) at sampled θ values against known values (tol 0.01)
   - test_path_monotone
        → objective is monotonically increasing for this problem
   - test_between_breakpoints_linear
        → z(θ) is linear between consecutive breakpoints

4. No breakpoints case
   - test_small_change_no_breakpoints
        → Δb and Δc both small (within sensitivity) → 0 breakpoints, 0 pivots
   - test_no_breakpoints_basis_preserved
        → result.basis_preserved == True

5. Explanations
   - test_breakpoint_explanation_primal
        → "S2 becomes binding" in explanation
   - test_breakpoint_explanation_dual
        → "x3 drops to 0" or "leaves basis" in explanation
   - test_result_summary
        → "2 breakpoint(s) found"

6. Integration with reoptimizer
   - test_reoptimizer_type_rc_uses_parametric
        → detect(base, compound) → analyze → reoptimize
        → method_used == "parametric_lp"
   - test_reoptimizer_parametric_optimal
        → final value matches scratch solve

7. Integration with diff report
   - test_diff_report_compound_change
        → DiffReport text contains breakpoint information

8. Edge cases
   - test_only_b_change_no_parametric
        → Type R shouldn't use parametric (use dual simplex instead)
   - test_only_c_change_no_parametric
        → Type C shouldn't use parametric (use primal warm-start)
   - test_no_binv_fallback
        → B⁻¹ unavailable → scratch fallback
   - test_degenerate_breakpoint
        → two breakpoints at same θ → handle without cycling
"""


# ============================================================
# 11. Module Structure
# ============================================================

MODULE_STRUCTURE = """
New files:
    clara/reopt/parametric.py           # ParametricLPSolver
    tests/test_parametric_lp.py         # all tests

Modified files:
    clara/reopt/types.py                # add ParametricBreakpoint, ParametricResult
    clara/reopt/reoptimizer.py          # real _parametric_lp() implementation
    clara/reopt/diff_report.py          # optional parametric path section in to_text()
    clara/reopt/__init__.py             # re-export
"""


# ============================================================
# 12. Implementation Order
# ============================================================

IMPLEMENTATION_ORDER = """
1. git checkout -b feat/parametric-lp

2. Add types to clara/reopt/types.py
   - ParametricBreakpoint, ParametricResult
   - Commit: "feat: add parametric LP data structures"

3. Implement clara/reopt/parametric.py
   - ParametricLPSolver with:
     - _find_primal_breakpoint()
     - _find_dual_breakpoint()
     - _pivot_at_breakpoint() (dual ratio test for primal bp, primal ratio test for dual bp)
     - _make_explanation()
     - solve() main loop
   - Uses existing _update_basis_inverse() logic (copy or call)
   - Commit: "feat: parametric LP solver for Type RC compound changes"

4. Update clara/reopt/reoptimizer.py
   - Replace _parametric_lp() placeholder with real implementation
   - Pass old_problem through to parametric solver
   - Commit: "feat: reoptimizer uses parametric LP for Type RC"

5. Update clara/reopt/diff_report.py
   - Add parametric path section to to_text() when method == "parametric_lp"
   - Commit: "feat: parametric path in diff report"

6. Tests
   - tests/test_parametric_lp.py
   - Albici compound golden tests (breakpoints, path, final value)
   - Commit: "test: parametric LP tests with Albici compound validation"

7. pytest full suite, update CLAUDE.md
   - Commit: "docs: update CLAUDE.md for parametric LP"
"""