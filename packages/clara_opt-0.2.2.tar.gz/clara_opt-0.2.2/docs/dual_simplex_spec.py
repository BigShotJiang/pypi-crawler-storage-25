"""
CLARA — Dual Simplex Design Specification
===========================================

Dual Simplex restores primal feasibility when the current basis is
dual feasible but primal infeasible. This is exactly the situation
in Type R reoptimization when RHS changes break the basis.

Primal Simplex:  starts dual infeasible, restores dual feasibility (optimality)
Dual Simplex:    starts primal infeasible, restores primal feasibility

Key use case:
    Old solution: B⁻¹ @ b_old ≥ 0 (primal feasible)
    After RHS change: B⁻¹ @ b_new has negatives (primal infeasible)
    But c didn't change → reduced costs still valid (dual feasible)
    → Dual simplex warm-start from current B⁻¹

Branch: feat/dual-simplex
"""


# ============================================================
# 1. Algorithm
# ============================================================

ALGORITHM = """
Dual Simplex Method (for maximization, Ax ≤ b, x ≥ 0)

Precondition: current basis is dual feasible (all reduced costs ≤ 0 for max).
Goal: restore primal feasibility (all basic variable values ≥ 0).

Loop:
    1. Compute x_B = B⁻¹ @ b
    2. If x_B ≥ 0 → OPTIMAL (primal and dual feasible)

    3. SELECT LEAVING VARIABLE (pricing):
       Choose r = argmin_i x_B[i]   (most negative basic variable)
       If x_B[r] ≥ -tolerance → OPTIMAL

    4. COMPUTE PIVOT ROW:
       w = (B⁻¹)_r   (r-th row of B⁻¹)
       For each non-basic variable j:
           d_j = w @ a_j   (r-th row of B⁻¹ @ column j of A_full)

    5. SELECT ENTERING VARIABLE (ratio test):
       Among non-basic j where d_j < -tolerance:
           ratio_j = reduced_cost_j / d_j   (both negative → positive ratio)
       Choose entering = argmin ratio_j
       (Bland's rule: smallest index for ties)

       If no eligible j → INFEASIBLE (dual unbounded)

    6. PIVOT:
       - Update B⁻¹ using elementary row operations (same as primal)
       - Swap entering into basis, leaving out
       - Record DualIterationSnapshot

    7. Go to step 1

Termination:
    - OPTIMAL: all x_B ≥ 0
    - INFEASIBLE: no eligible entering variable in ratio test
    - ITERATION_LIMIT: exceeded max iterations
"""


# ============================================================
# 2. Comparison with Primal Simplex
# ============================================================

COMPARISON = """
                    Primal Simplex              Dual Simplex
                    ─────────────               ────────────
Start condition     x_B ≥ 0 (feasible)         rc ≤ 0 for max (optimal)
                    rc may be > 0               x_B may be < 0

Entering choice     min rc (most improving)     ratio test on rc/d
Leaving choice      ratio test on x_B/d         min x_B (most negative)

Pivot updates       identical B⁻¹ update        identical B⁻¹ update

Terminates when     all rc ≤ 0                  all x_B ≥ 0
Infeasible when     (detected by Phase I)       no eligible entering var

Typically used      fresh solve, Type C reopt   Type R reopt, adding cuts
"""


# ============================================================
# 3. Public API
# ============================================================

API = """
Two options for where to put dual simplex:

Option A: Method on existing RevisedSimplex class
    solver = RevisedSimplex.from_warm_start(problem, basis, B_inv)
    state = solver.solve_dual()     # new method

Option B: Standalone function (simpler, no class modification)
    state = dual_simplex_solve(problem, basis, B_inv)

Recommendation: Option A — keeps warm-start and dual simplex together.

# Addition to clara/engine/simplex.py

class RevisedSimplex:
    # ... existing ...

    def solve_dual(self) -> SolveState:
        '''Run Dual Simplex from current (dual-feasible) basis.

        Precondition: current basis has valid reduced costs (≤ 0 for max).
        Restores primal feasibility by pivoting out negative basic variables.

        Returns:
            SolveState with complete trace.

        Raises:
            InfeasibleError: If dual simplex detects infeasibility.
        '''
"""


# ============================================================
# 4. Implementation Detail
# ============================================================

IMPLEMENTATION = """
def solve_dual(self) -> SolveState:
    '''Dual Simplex: restore primal feasibility from dual-feasible basis.'''
    start_time = time.perf_counter()
    status = SolveStatus.OPTIMAL

    for iteration in range(1, MAX_ITERATIONS + 1):
        # Step 1: basic variable values
        x_B = self.B_inv @ self.b

        # Step 2: check primal feasibility
        min_val = float('inf')
        leaving_row = -1
        for i in range(self.m):
            if x_B[i] < min_val:
                min_val = x_B[i]
                leaving_row = i
            # Bland's rule: if tie, take smallest basis index
            elif abs(x_B[i] - min_val) < PIVOT_TOL:
                if self.basis[i] < self.basis[leaving_row]:
                    leaving_row = i

        if min_val >= -PIVOT_TOL:
            status = SolveStatus.OPTIMAL
            break

        # Step 3: compute reduced costs for all non-basic
        c_B = self.c_full[self.basis]
        y = c_B @ self.B_inv

        # Step 4: pivot row — r-th row of B⁻¹
        w = self.B_inv[leaving_row]

        # Step 5: ratio test for entering variable
        entering_col = -1
        min_ratio = float('inf')
        for j in range(self.N):
            if j in self.basis:
                continue
            d_j = w @ self.A_full[:, j]
            if d_j < -PIVOT_TOL:
                rc_j = self.c_full[j] - y @ self.A_full[:, j]
                # For max: rc_j ≤ 0 (dual feasible)
                # ratio = rc_j / d_j (both ≤ 0 and < 0 → ratio ≥ 0)
                ratio = rc_j / d_j
                if ratio < min_ratio - PIVOT_TOL:
                    min_ratio = ratio
                    entering_col = j
                elif abs(ratio - min_ratio) < PIVOT_TOL:
                    # Bland's rule: smallest index
                    if j < entering_col:
                        entering_col = j

        if entering_col == -1:
            status = SolveStatus.INFEASIBLE
            break

        # Step 6: compute full pivot column for B⁻¹ update
        d = self.B_inv @ self.A_full[:, entering_col]
        pivot_element = d[leaving_row]

        # Record snapshot
        leaving_col = self.basis[leaving_row]
        self._update_basis_inverse(d, leaving_row)
        self.basis[leaving_row] = entering_col

        x_B_new = self.B_inv @ self.b
        c_B_new = self.c_full[self.basis]
        obj_new = float(c_B_new @ x_B_new)

        snapshot = IterationSnapshot(
            iteration=iteration,
            entering_var=self.all_var_names[entering_col],
            leaving_var=self.all_var_names[leaving_col],
            pivot_row=leaving_row,
            pivot_col=entering_col,
            pivot_element=pivot_element,
            objective_value=obj_new,
            basic_variables=tuple(self.all_var_names[j] for j in self.basis),
            entering_reduced_cost=min_ratio,  # dual ratio
            leaving_ratio=min_val,             # most negative x_B
            basic_values=tuple(x_B_new),
        )
        self.iterations.append(snapshot)
    else:
        status = SolveStatus.ITERATION_LIMIT

    elapsed = time.perf_counter() - start_time
    return self._make_state(status, elapsed)

Key points:
    - _update_basis_inverse() is IDENTICAL to primal simplex (same eta update)
    - _make_state() is IDENTICAL (same SolveState construction)
    - IterationSnapshot is reused (entering/leaving meaning flipped but fields work)
    - Only the selection logic (steps 3-5) differs from solve()
"""


# ============================================================
# 5. Integration with Reoptimizer
# ============================================================

REOPTIMIZER_INTEGRATION = """
Change in reoptimizer.py _warm_start():

BEFORE:
    x_B = B_inv @ new_problem.b
    if np.any(x_B < -1e-8):
        return self._scratch(new_problem)       # ← wasteful!
    new_state = solver.solve()

AFTER:
    x_B = B_inv @ new_problem.b
    if np.any(x_B < -1e-8):
        # Primal infeasible, dual feasible → dual simplex
        new_state = solver.solve_dual()
    else:
        # Primal feasible, possibly dual infeasible → primal simplex
        new_state = solver.solve()

This is the key change. Now Type R with broken basis actually
warm-starts instead of falling back to scratch.

The method_used should reflect what happened:
    return ReoptResult(
        method_used="warm_start_dual" if used_dual else "warm_start",
        ...
    )
"""


# ============================================================
# 6. Verifying Dual Feasibility
# ============================================================

DUAL_FEASIBILITY_CHECK = """
Before calling solve_dual(), we should verify the basis is dual feasible.
Otherwise dual simplex may produce wrong results.

    def _is_dual_feasible(self) -> bool:
        '''Check if current basis is dual feasible (all reduced costs ≤ 0 for max).'''
        c_B = self.c_full[self.basis]
        y = c_B @ self.B_inv
        for j in range(self.N):
            if j in self.basis:
                continue
            rc_j = self.c_full[j] - y @ self.A_full[:, j]
            if rc_j > OPTIMALITY_TOL:
                return False
        return True

In reoptimizer._warm_start():
    solver = RevisedSimplex.from_warm_start(problem, basis, B_inv)

    x_B = B_inv @ new_problem.b
    primal_infeasible = np.any(x_B < -1e-8)

    if primal_infeasible and solver._is_dual_feasible():
        new_state = solver.solve_dual()
    elif primal_infeasible:
        # Both primal and dual infeasible — scratch is safest
        return self._scratch(new_problem)
    else:
        new_state = solver.solve()

Type R: c unchanged → dual feasible guaranteed → dual simplex always works
Type C: b unchanged → primal feasible → primal simplex (already handled)
Type RC: both may be infeasible → scratch or parametric LP
"""


# ============================================================
# 7. Test Cases
# ============================================================

TEST_CASES = """
tests/test_dual_simplex.py

1. Core dual simplex correctness
   - test_dual_simplex_small
        → manually construct a dual-feasible, primal-infeasible basis
        → solve_dual() → OPTIMAL, correct values
   - test_dual_matches_primal
        → same LP solved by primal and dual → same optimal value
   - test_dual_iteration_count
        → dual simplex from near-optimal basis → fewer iterations than scratch

2. Albici reoptimization scenarios
   - test_albici_b2_dual_simplex
        → base B⁻¹ + b2 → primal infeasible (y2 = -66.67)
        → solve_dual() → optimal = 4300.0
        → fewer pivots than scratch solve
   - test_albici_b2_warm_start_uses_dual
        → full pipeline: detect → analyze → reoptimize
        → result.method_used == "warm_start_dual"
        → result.pivots < scratch pivots

3. Edge cases
   - test_dual_already_feasible
        → x_B ≥ 0 → solve_dual returns immediately (0 pivots)
   - test_dual_infeasible
        → problem with no feasible solution → status = INFEASIBLE
   - test_dual_bland_rule
        → degenerate problem → Bland's rule prevents cycling
   - test_dual_feasibility_check
        → _is_dual_feasible() returns True for unchanged c, False after c change

4. Integration
   - test_reoptimizer_type_r_broken_uses_dual
        → Type R with broken basis → dual simplex, not scratch
   - test_reoptimizer_type_c_uses_primal
        → Type C → primal simplex (not dual)
   - test_reoptimizer_type_rc_both_infeasible
        → scratch fallback when both primal and dual infeasible

5. Snapshot recording
   - test_dual_snapshots_recorded
        → iteration_history is populated
   - test_dual_snapshot_fields
        → entering/leaving vars present, objective monotonically decreasing
        → (dual simplex: objective decreases toward optimal, opposite of primal)

6. Performance comparison
   - test_dual_fewer_pivots_than_scratch
        → Albici b2: dual pivots < scratch pivots
   - test_warm_start_speedup_reported
        → ReoptResult.speedup > 1.0 for Type R scenarios
"""


# ============================================================
# 8. Module Structure
# ============================================================

MODULE_STRUCTURE = """
Modified files:
    clara/engine/simplex.py           # add solve_dual(), _is_dual_feasible()
    clara/reopt/reoptimizer.py        # update _warm_start() to use dual simplex
    tests/test_dual_simplex.py        # new test file
    tests/test_reoptimizer.py         # update warm_start tests

No new modules — dual simplex is a method on the existing RevisedSimplex class.
"""


# ============================================================
# 9. Implementation Order
# ============================================================

IMPLEMENTATION_ORDER = """
1. git checkout -b feat/dual-simplex

2. Implement solve_dual() in clara/engine/simplex.py
   - Dual simplex loop (steps 1-6 from ALGORITHM section)
   - _is_dual_feasible() check
   - Reuses _update_basis_inverse() and _make_state()
   - Commit: "feat: dual simplex method for warm-start reoptimization"

3. Update clara/reopt/reoptimizer.py
   - _warm_start() uses solve_dual() when primal infeasible + dual feasible
   - method_used = "warm_start_dual" when dual simplex used
   - Commit: "feat: reoptimizer uses dual simplex for Type R warm-start"

4. Tests
   - tests/test_dual_simplex.py — correctness, Albici b2, edge cases
   - Update tests/test_reoptimizer.py — verify method_used and pivot counts
   - Commit: "test: dual simplex and reoptimizer integration tests"

5. pytest full suite, update CLAUDE.md
   - Remove "Warm-start falls back to scratch for primal-infeasible basis" from Known Limitations
   - Add dual simplex to Completed list
   - Commit: "docs: update CLAUDE.md for dual simplex"
"""


# ============================================================
# 10. MPC Paper Contribution
# ============================================================

MPC_CONTRIBUTION = """
With dual simplex, CLARA can demonstrate:

    Experiment: Albici base → b2 (RHS change, basis broken)

    | Method            | Pivots | Time   |
    |-------------------|--------|--------|
    | Scratch re-solve  | ~5     | 0.003s |
    | Dual simplex warm | ~1-2   | 0.001s |

    "For Type R changes where the basis breaks, CLARA uses dual simplex
     warm-started from B⁻¹, requiring only K pivots to restore feasibility
     compared to K' pivots from scratch. The old basis provides a near-optimal
     starting point because only the RHS changed."

This is a concrete, measurable improvement that reviewers can verify.
Combined with the Oguz bound analysis ("is it worth reoptimizing?"),
it forms a complete reoptimization decision framework.
"""