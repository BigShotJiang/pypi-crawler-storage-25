"""
CLARA v0.1.0 Release — Specification
======================================

Goal: First public release on PyPI.
Branch: release/v0.1.0 (from dev)

This spec covers four tasks in one pass:
  1. English conversion (all source code, docs, CLI)
  2. HiGHS backend + cross-validation
  3. Example files
  4. PyPI release preparation

Estimated effort: one Claude Code session.
"""


# ============================================================
# Task 1: English Conversion
# ============================================================

ENGLISH_CONVERSION = """
Scope: everything EXCEPT docs/project_plan_v3.md and docs/*_spec.py.

Files to convert (in order):

1. clara/**/*.py
   - All comments (inline and block)
   - All docstrings
   - All error messages
   - All CLI help text (already English if cli_spec was followed)
   - String literals in Explainer templates (should already be English)

2. tests/**/*.py
   - Test docstrings and comments
   - Test names should already be English (test_xxx)

3. CLAUDE.md
   - Full rewrite in English
   - Keep same structure and content, just translate

4. README.md
   - Full rewrite in English (see Task 4 for content)

5. CONTRIBUTING.md
   - Write in English (see Task 4)

6. .github/ (if any CI configs have Korean comments)

Rules:
  - Do NOT translate docs/project_plan_v3.md (personal research plan, Korean OK)
  - Do NOT translate docs/*_spec.py (internal reference, Korean OK)
  - Commit message: "chore: convert codebase to English for public release"
  - Do this FIRST, before other tasks, so subsequent commits are all English
"""


# ============================================================
# Task 2: HiGHS Backend + Cross-Validation
# ============================================================

HIGHS_BACKEND = """
Module: clara/engine/highs_backend.py

Implementation:
  class HiGHSBackend:
      '''Solve engine using HiGHS via highspy.

      For large problems where InternalSimplex is too slow.
      Provides result-level explanation only (no iteration trace, no B^-1).
      '''

      def solve(self, problem: LPProblem) -> SolveState:
          '''Solve using HiGHS and return a SolveState.

          SolveState fields populated:
            ✓ status, optimal_value, variables, constraints
            ✓ sensitivity (via HiGHS getRanging API)
            ✗ basis_inverse = None (HiGHS does not expose B^-1)
            ✗ iteration_history = None
          Engine = EngineType.HIGHS
          '''

HiGHS API usage (highspy):
  import highspy

  h = highspy.Highs()
  h.setOptionValue("output_flag", False)  # suppress solver output

  # Add variables
  for j in range(n_vars):
      h.addVar(lower_bounds[j], upper_bounds[j])

  # Set objective
  h.changeColsCost(range(n_vars), obj_coeffs)
  h.changeObjectiveSense(highspy.ObjSense.kMaximize)  # or kMinimize

  # Add constraints (row by row)
  for i in range(n_constraints):
      nonzero_indices = [j for j in range(n_vars) if A[i][j] != 0]
      nonzero_values = [A[i][j] for j in nonzero_indices]
      h.addRow(-highspy.kHighsInf, rhs[i], len(nonzero_indices),
               nonzero_indices, nonzero_values)

  # Solve
  h.run()
  status = h.getInfoValue("primal_solution_status")

  # Extract results
  solution = h.getSolution()
  info = h.getInfoValue("objective_function_value")
  basis = h.getBasis()

  # Sensitivity analysis
  ranging = h.getRanging()
  # ranging.col_cost_up, ranging.col_cost_dn — obj coeff ranges
  # ranging.row_bound_up, ranging.row_bound_dn — RHS ranges

Building SolveState from HiGHS:
  - optimal_value ← h.getInfoValue("objective_function_value")
  - variable_values ← solution.col_value
  - dual_values ← solution.row_dual
  - reduced_costs ← solution.col_dual
  - slack ← RHS - A @ x (compute manually, or from row_value)
  - basis_status ← basis.col_status / basis.row_status mapping:
      HighsBasisStatus.kBasic → BasisStatus.BASIC
      HighsBasisStatus.kLower → BasisStatus.NONBASIC_LOWER
      HighsBasisStatus.kUpper → BasisStatus.NONBASIC_UPPER
      etc.
  - sensitivity ← ranging (map to SensitivityRanges format)
  - basis_inverse ← None (not available)
  - iteration_history ← None (not available)
  - engine ← EngineType.HIGHS

Integer / Binary handling:
  - For MIP: h.changeColsIntegrality(indices, types)
  - types: highspy.HighsVarType.kInteger or kSemiContinuous
  - Phase 1: only LP support needed. MIP is Phase 1.5.
  - If problem has integer/binary vars, raise NotImplementedError with
    message: "MIP not yet supported. Use LP relaxation or wait for Phase 1.5."


Cross-Validation Tests:
  tests/test_cross_validation.py

  Core idea: solve the same problem with both engines,
  compare results within tolerance.

  class TestCrossValidation:
      '''Compare InternalSimplex vs HiGHS on the same problems.'''

      TOLERANCE_OPTIMAL = 1e-6
      TOLERANCE_DUAL = 1e-4
      TOLERANCE_SENSITIVITY = 1e-3  # sensitivity ranges can differ slightly

      @pytest.fixture(params=[
          "tests/fixtures/albici_base.lp",
          "tests/fixtures/albici_reopt_b1.lp",
          "tests/fixtures/albici_reopt_b2.lp",
          "tests/fixtures/albici_reopt_cost.lp",
          "tests/fixtures/albici_reopt_columns.lp",
          "tests/fixtures/parser_comprehensive.lp",
          "tests/fixtures/parser_minimal.lp",
      ])
      def dual_solve(self, request):
          problem = read_lp(request.param)
          internal = InternalSimplex().solve(problem)
          highs = HiGHSBackend().solve(problem)
          return internal, highs

      def test_optimal_value_match(self, dual_solve):
          internal, highs = dual_solve
          assert abs(internal.optimal_value - highs.optimal_value) < self.TOLERANCE_OPTIMAL

      def test_variable_values_match(self, dual_solve):
          internal, highs = dual_solve
          for vi, vh in zip(internal.variables, highs.variables):
              assert abs(vi.value - vh.value) < self.TOLERANCE_DUAL

      def test_dual_values_match(self, dual_solve):
          internal, highs = dual_solve
          for ci, ch in zip(internal.constraints, highs.constraints):
              assert abs(ci.dual_value - ch.dual_value) < self.TOLERANCE_DUAL

      def test_binding_constraints_match(self, dual_solve):
          internal, highs = dual_solve
          internal_binding = {c.name for c in internal.binding_constraints}
          highs_binding = {c.name for c in highs.binding_constraints}
          assert internal_binding == highs_binding

      def test_sensitivity_ranges_close(self, dual_solve):
          internal, highs = dual_solve
          for var_name in internal.sensitivity.obj_coeff_ranges:
              i_lo, i_hi = internal.sensitivity.obj_coeff_ranges[var_name]
              h_lo, h_hi = highs.sensitivity.obj_coeff_ranges[var_name]
              if i_lo != float('-inf'):
                  assert abs(i_lo - h_lo) < self.TOLERANCE_SENSITIVITY
              if i_hi != float('inf'):
                  assert abs(i_hi - h_hi) < self.TOLERANCE_SENSITIVITY

      def test_highs_no_basis_inverse(self, dual_solve):
          _, highs = dual_solve
          assert highs.basis_inverse is None

      def test_highs_no_iteration_history(self, dual_solve):
          _, highs = dual_solve
          assert highs.iteration_history is None

      def test_engine_type(self, dual_solve):
          internal, highs = dual_solve
          assert internal.engine == EngineType.INTERNAL_SIMPLEX
          assert highs.engine == EngineType.HIGHS

  Additional standalone tests:
      - test_highs_cli_option        → clara explain file.lp --engine highs works
      - test_highs_json_output       → JSON has engine: "HIGHS"
      - test_highs_explain_works     → Explainer produces valid report from HiGHS SolveState
"""


# ============================================================
# Task 3: Example Files
# ============================================================

EXAMPLES = """
examples/ — self-contained Python scripts demonstrating CLARA features.
Each file is runnable: python examples/01_basic_lp.py

examples/
├── 01_basic_lp.py           # Solve + explain a simple production problem
├── 02_sensitivity.py        # Focus on sensitivity analysis interpretation
├── 03_engine_comparison.py  # Internal vs HiGHS side by side
└── 04_json_output.py        # Programmatic use of JSON output


--- 01_basic_lp.py ---
'''Solve and explain a simple production planning problem.

This example demonstrates CLARA's core workflow:
  1. Parse an LP file
  2. Solve with the internal simplex engine
  3. Generate a human-readable explanation

Usage:
  python examples/01_basic_lp.py
  # or equivalently:
  clara explain examples/production.lp
'''
from clara.io import read_lp
from clara.engine.simplex import InternalSimplex
from clara.explain import Explainer, DetailLevel

problem = read_lp("tests/fixtures/albici_base.lp")
state = InternalSimplex().solve(problem)
report = Explainer().explain(state, level=DetailLevel.DETAILED)
print(report.to_text())


--- 02_sensitivity.py ---
'''Explore sensitivity analysis results.

Demonstrates how to programmatically access sensitivity ranges
to answer questions like:
  - How much can a product's profit change before the solution changes?
  - Which constraint is the bottleneck?
  - Where should we invest to improve the objective?
'''
from clara.io import read_lp
from clara.engine.simplex import InternalSimplex

problem = read_lp("tests/fixtures/albici_base.lp")
state = InternalSimplex().solve(problem)

print(f"Optimal value: {state.optimal_value:.4f}")
print()

# Find bottleneck
bottleneck = max(state.binding_constraints, key=lambda c: abs(c.dual_value))
print(f"Bottleneck: {bottleneck.name}")
print(f"  Shadow price: {bottleneck.dual_value:.4f}")
print(f"  Expanding {bottleneck.name} by 1 unit improves objective by {bottleneck.dual_value:.4f}")
print()

# Find most fragile variable
for name, (lo, hi) in state.sensitivity.obj_coeff_ranges.items():
    v = state.get_variable(name)
    width = hi - lo if hi != float('inf') else float('inf')
    print(f"{name} (current profit = {v.obj_coeff_range}): "
          f"allowable range [{lo:.4f}, {hi:.4f}], width = {width:.4f}")


--- 03_engine_comparison.py ---
'''Compare internal simplex engine with HiGHS.

Shows that both engines produce the same optimal value and solution,
but the internal engine additionally provides B^-1 and iteration history.
'''
from clara.io import read_lp
from clara.engine.simplex import InternalSimplex
from clara.engine.highs_backend import HiGHSBackend

problem = read_lp("tests/fixtures/albici_base.lp")

internal = InternalSimplex().solve(problem)
highs = HiGHSBackend().solve(problem)

print("=== Internal Simplex ===")
print(f"Optimal: {internal.optimal_value:.4f}")
print(f"Iterations: {internal.iteration_count}")
print(f"Has B^-1: {internal.has_basis_inverse}")
print(f"Has trace: {internal.has_internal_trace}")

print()

print("=== HiGHS ===")
print(f"Optimal: {highs.optimal_value:.4f}")
print(f"Iterations: {highs.iteration_count}")
print(f"Has B^-1: {highs.has_basis_inverse}")
print(f"Has trace: {highs.has_internal_trace}")

print()

diff = abs(internal.optimal_value - highs.optimal_value)
print(f"Optimal value difference: {diff:.2e}")
print("Match!" if diff < 1e-6 else "MISMATCH — investigate!")


--- 04_json_output.py ---
'''Demonstrate JSON output for programmatic use.

JSON output can be piped to other tools (jq, Python scripts, dashboards).
Equivalent to: clara explain file.lp --format json
'''
import json
from clara.io import read_lp
from clara.engine.simplex import InternalSimplex
from clara.explain import Explainer, DetailLevel

problem = read_lp("tests/fixtures/albici_base.lp")
state = InternalSimplex().solve(problem)
report = Explainer().explain(state, level=DetailLevel.BRIEF)

data = report.to_dict()

# Programmatic access
print(f"Optimal: {data['optimal_value']}")
print(f"Bottleneck: {data['sensitivity_report']['bottleneck']}")
print(f"Number of binding constraints: {len(data['binding_report']['binding'])}")

# Full JSON
print()
print(json.dumps(data, indent=2))
"""


# ============================================================
# Task 4: PyPI Release Preparation
# ============================================================

PYPI_PREP = """
Files to create/update:

1. README.md — full rewrite in English:

   # CLARA — Classical LP Analysis for Reoptimization and Attribution

   [![PyPI](https://img.shields.io/pypi/v/clara-opt)](https://pypi.org/project/clara-opt/)
   [![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
   [![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://python.org)

   A white-box optimization solver that explains why solutions are optimal,
   when reoptimization is needed, and what changed.

   ## Features

   - **Solver-intrinsic explanations** — not post-hoc ML surrogate, but direct
     interpretation of basis, dual values, and sensitivity ranges
   - **Dual backend** — Internal Revised Simplex (full transparency, step-by-step trace)
     or HiGHS (performance for large problems)
   - **Three explanation levels** mapped to the XAIOR framework (De Bock et al., 2024):
     - *Understandability*: Which constraints are binding? What resources are fully used?
     - *Justifiability*: Why is each variable at this value? What's the reduced cost?
     - *Actionability*: What can change without breaking the solution? Where to invest?
   - **CLI and Python API** — `clara explain problem.lp` or import as library

   ## Installation

   ```bash
   pip install clara-opt
   ```

   ## Quick Start

   ```bash
   # Explain a production planning problem
   clara explain examples/production.lp

   # Brief summary
   clara explain examples/production.lp --level brief

   # JSON output
   clara explain examples/production.lp --format json

   # Use HiGHS engine for larger problems
   clara explain problem.lp --engine highs
   ```

   ### Python API

   ```python
   from clara.io import read_lp
   from clara.engine.simplex import InternalSimplex
   from clara.explain import Explainer

   problem = read_lp("problem.lp")
   state = InternalSimplex().solve(problem)
   report = Explainer().explain(state)
   print(report.to_text())
   ```

   ## Roadmap

   - [x] v0.1.0 — LP solver + explainer + CLI (you are here)
   - [ ] v0.5.0 — MIP (Branch-and-Bound), counterfactual analysis, TUI
   - [ ] v1.0.0 — Incremental reoptimization, parametric LP, streaming
   - [ ] v2.0.0 — LLM hybrid explanations, web UI

   ## Academic Use

   CLARA fills a gap identified in the XAIOR framework (De Bock et al., 2024, EJOR):
   explainable AI for mathematical optimization solvers. If you use CLARA in research,
   please cite:

   ```
   (citation TBD — paper in preparation for Mathematical Programming Computation)
   ```

   ## License

   MIT


2. CONTRIBUTING.md:

   # Contributing to CLARA

   ## Development Setup

   ```bash
   git clone https://github.com/<username>/clara-opt.git
   cd clara-opt
   pip install -e ".[dev]"
   ```

   ## Code Style

   - Python 3.10+, type hints required
   - Format: `ruff format clara/ tests/`
   - Lint: `ruff check clara/ tests/`
   - Tests: `pytest tests/`

   ## Branch Convention

   - `feat/*` — new features
   - `bench/*` — benchmarks
   - `paper/*` — paper writing
   - All PRs target `dev` branch

   ## Commit Convention

   `feat:`, `fix:`, `test:`, `bench:`, `paper:`, `docs:`, `refactor:`, `ci:`, `chore:`


3. pyproject.toml updates:
   - Verify version = "0.1.0"
   - Verify all metadata is correct
   - Verify classifiers include "Development Status :: 3 - Alpha"


4. Release steps (manual, after all code changes):
   ```bash
   # Ensure clean state
   git checkout dev
   git pull
   pytest tests/

   # Create release branch
   git checkout -b release/v0.1.0

   # Build
   pip install build
   python -m build

   # Check package
   pip install twine
   twine check dist/*

   # Upload to Test PyPI first
   twine upload --repository testpypi dist/*
   pip install --index-url https://test.pypi.org/simple/ clara-opt

   # Verify installation works
   clara --version
   clara explain tests/fixtures/albici_base.lp

   # Upload to PyPI
   twine upload dist/*

   # Tag and merge
   git tag v0.1.0
   git checkout main
   git merge release/v0.1.0
   git push origin main --tags
   git checkout dev
   git merge main
   git push origin dev
   ```
"""


# ============================================================
# Task Execution Order
# ============================================================

EXECUTION_ORDER = """
Claude Code should execute in this order:

1. git checkout -b release/v0.1.0 (from dev)

2. English conversion
   - Scan all .py files under clara/ and tests/ for Korean text
   - Convert comments, docstrings, error messages to English
   - Rewrite CLAUDE.md in English
   - Commit: "chore: convert codebase to English for public release"

3. HiGHS backend
   - Implement clara/engine/highs_backend.py
   - Implement tests/test_cross_validation.py
   - Update clara/cli.py _make_engine() to use real HiGHSBackend
   - Run pytest — all cross-validation tests pass
   - Commit: "feat: HiGHS backend with cross-validation tests"

4. Examples
   - Create examples/01_basic_lp.py through 04_json_output.py
   - Verify each runs without error
   - Commit: "docs: add example scripts"

5. Release preparation
   - Rewrite README.md (English, badges, quick start, roadmap)
   - Create CONTRIBUTING.md
   - Verify pyproject.toml metadata
   - Run full test suite: pytest tests/ -v
   - Commit: "docs: README, CONTRIBUTING for v0.1.0 release"

6. Final verification
   - pip install -e ".[dev]"
   - clara --version
   - clara explain tests/fixtures/albici_base.lp
   - clara explain tests/fixtures/albici_base.lp --engine highs
   - clara explain tests/fixtures/albici_base.lp --format json
   - clara solve tests/fixtures/albici_base.lp
   - clara info tests/fixtures/albici_base.lp
   - python examples/01_basic_lp.py
   - python examples/03_engine_comparison.py
   - pytest tests/ -v --tb=short

After Claude Code finishes, manually:
   - Review diff
   - Build and upload to PyPI (see Task 4 release steps)
   - Create GitHub release with tag v0.1.0
"""