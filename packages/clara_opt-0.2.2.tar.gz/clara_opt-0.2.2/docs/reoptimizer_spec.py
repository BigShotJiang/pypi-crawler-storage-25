"""
CLARA Phase 2 — Warm-start Reoptimizer Design Specification
=============================================================

The Reoptimizer takes a ReoptDecision (from Impact Analyzer),
the current SolveState (with B⁻¹), and the new problem,
then produces a new SolveState with minimal computational effort.

Pipeline position:
    Change Detector → Impact Analyzer → **Reoptimizer** → Diff Report

Key insight: B⁻¹ from the old solution is the bridge.
    - Type R (basis preserved): x_B_new = B⁻¹ * b_new (zero pivots)
    - Type R (basis broken): dual simplex warm-start from B⁻¹
    - Type C (basis preserved): same solution, just recompute objective
    - Type C (basis broken): primal simplex warm-start from B⁻¹
    - Type RC: parametric LP or warm-start
    - Type V: check reduced costs of new columns via B⁻¹
    - Structural (X, M): scratch re-solve

Branch: feat/reoptimizer
"""


# ============================================================
# 1. Public API
# ============================================================

API = """
# Module: clara/reopt/reoptimizer.py

class Reoptimizer:
    '''Reoptimize using the old solution's B⁻¹ for warm-start.

    Implements the reoptimization procedures from Albici et al. (2010)
    with B⁻¹-based warm-start for the Internal Simplex engine.
    Falls back to scratch re-solve via HiGHS when B⁻¹ is unavailable.
    '''

    def reoptimize(
        self,
        old_state: SolveState,
        new_problem: LPProblem,
        change: ParameterChange,
        decision: ReoptDecision,
    ) -> ReoptResult:
        '''Reoptimize the new problem using information from the old solution.

        Args:
            old_state: Previous SolveState (must have B⁻¹ for warm-start methods).
            new_problem: The modified LP problem.
            change: Detected parameter change.
            decision: Impact Analyzer's recommendation.

        Returns:
            ReoptResult containing the new SolveState and reoptimization metadata.
        '''

# Usage:
    detector = ChangeDetector()
    analyzer = ImpactAnalyzer()
    reoptimizer = Reoptimizer()

    change = detector.detect(old_problem, new_problem)
    decision = analyzer.analyze(old_state, change, old_problem)

    if decision.should_reoptimize:
        result = reoptimizer.reoptimize(old_state, new_problem, change, decision)
        print(f"Reoptimized in {result.pivots} pivots (vs ~{result.scratch_estimate} from scratch)")
        new_state = result.new_state
    else:
        # decision.recommended_method == "none" or "recompute"
        result = reoptimizer.reoptimize(old_state, new_problem, change, decision)
        new_state = result.new_state  # still works — just does minimal work
"""


# ============================================================
# 2. ReoptResult Data Structure
# ============================================================

REOPT_RESULT = """
Add to clara/reopt/types.py:

@dataclass(frozen=True)
class ReoptResult:
    '''Output of the Reoptimizer.'''

    new_state: SolveState               # the reoptimized solution
    method_used: str                    # "none", "recompute", "warm_start",
                                        #   "parametric_lp", "scratch"
    pivots: int                         # number of simplex pivots in reoptimization
    scratch_estimate: int | None        # estimated pivots if solved from scratch
                                        #   (for comparison, None if unknown)
    basis_preserved: bool               # was the old basis still optimal?
    reopt_time_seconds: float           # time for reoptimization only

    @property
    def speedup(self) -> float | None:
        '''Estimated speedup vs scratch solve.'''
        if self.scratch_estimate and self.scratch_estimate > 0:
            return self.scratch_estimate / max(self.pivots, 1)
        return None

    @property
    def summary(self) -> str:
        '''One-line summary.'''
        if self.basis_preserved:
            return (f"Basis preserved — recomputed in {self.reopt_time_seconds:.4f}s "
                    f"(0 pivots).")
        return (f"Reoptimized via {self.method_used}: {self.pivots} pivots "
                f"in {self.reopt_time_seconds:.4f}s"
                f"{f' (est. {self.speedup:.1f}x speedup)' if self.speedup else ''}.")
"""


# ============================================================
# 3. Method: "none" — No Action
# ============================================================

METHOD_NONE = """
When decision.recommended_method == "none" and change is Type C:
    The old solution is still optimal (or Oguz bound says it's close enough).
    Just recompute the objective value with new coefficients.

    new_obj = c_new^T @ x_old

    Return the old SolveState with updated optimal_value.
    (Technically a new SolveState since it's frozen.)

    pivots = 0, basis_preserved = True.
"""


# ============================================================
# 4. Method: "recompute" — Basis Preserved (Type R)
# ============================================================

METHOD_RECOMPUTE = """
When all RHS changes are within sensitivity ranges (Type R, basis preserved):
    The current basis B is still optimal. Just recompute:

    x_B_new = B⁻¹ @ b_new

    Then rebuild the SolveState with updated:
    - variable values (from x_B_new)
    - slack values (from b_new - A @ x_new)
    - optimal value (c^T @ x_new)
    - constraint info (new RHS, new slack, binding status may change)

    Dual values and sensitivity ranges are UNCHANGED (same basis).

    pivots = 0, basis_preserved = True.

Implementation:
    def _recompute(self, old_state, new_problem, change) -> ReoptResult:
        B_inv = old_state.basis_inverse
        if B_inv is None:
            return self._scratch(new_problem)  # fallback

        b_new = new_problem.b
        x_B_new = B_inv @ b_new

        # Verify all basic variables are still non-negative
        if np.any(x_B_new < -1e-8):
            # Sensitivity check was wrong, or numerical issue → warm-start instead
            return self._warm_start(old_state, new_problem, change)

        # Build new solution vector
        # ... (map basic variable values back to full variable vector)
        # ... (recompute objective, slack, etc.)

        return ReoptResult(
            new_state=new_state,
            method_used="recompute",
            pivots=0,
            scratch_estimate=old_state.iteration_count,
            basis_preserved=True,
            reopt_time_seconds=elapsed,
        )
"""


# ============================================================
# 5. Method: "warm_start" — B⁻¹ Warm-start Simplex
# ============================================================

METHOD_WARM_START = """
When basis is broken (Type R outside range, or Type C outside range):

Type R (primal infeasible, dual feasible):
    B⁻¹ @ b_new has negative components → primal infeasible.
    But dual values are still valid (c didn't change).
    → Dual simplex warm-start: start from current B⁻¹, restore primal feasibility.

Type C (primal feasible, dual infeasible):
    x_B is still feasible (b didn't change).
    But reduced costs are wrong (c changed) → some may be positive.
    → Primal simplex warm-start: start from current B⁻¹, restore dual feasibility.

Type RC:
    Both may be infeasible → primal simplex warm-start (general).

Implementation:
    def _warm_start(self, old_state, new_problem, change) -> ReoptResult:
        '''Warm-start simplex from the old basis.'''

        B_inv = old_state.basis_inverse
        if B_inv is None:
            return self._scratch(new_problem)

        # Create a RevisedSimplex instance with the new problem
        solver = RevisedSimplex(new_problem)

        # Inject the old basis into the solver
        # The old basis indices tell us which variables were basic
        old_basis = self._extract_basis_indices(old_state, new_problem)
        solver.basis = old_basis
        solver.B_inv = B_inv.copy()

        # Run simplex from warm-started state
        # (The existing solve() loop handles this — it starts from whatever
        #  basis/B_inv is set, checks optimality, and pivots as needed)
        new_state = solver.solve()

        return ReoptResult(
            new_state=new_state,
            method_used="warm_start",
            pivots=len(solver.iterations),
            scratch_estimate=old_state.iteration_count,
            basis_preserved=False,
            reopt_time_seconds=new_state.solve_time_seconds,
        )

Key implementation detail:
    RevisedSimplex.__init__ currently sets basis to slacks and B_inv to identity.
    For warm-start, we need to inject basis and B_inv AFTER __init__ but BEFORE solve().
    Options:
    (a) Add basis/B_inv parameters to __init__
    (b) Set solver.basis and solver.B_inv directly after construction
    (c) Add a classmethod: RevisedSimplex.from_warm_start(problem, basis, B_inv)

    Option (c) is cleanest. Add to simplex.py:

    @classmethod
    def from_warm_start(
        cls,
        problem: LPProblem,
        basis: list[int],
        basis_inverse: np.ndarray,
    ) -> RevisedSimplex:
        '''Create a solver warm-started from an existing basis.'''
        solver = cls(problem)
        solver.basis = list(basis)
        solver.B_inv = basis_inverse.copy()
        return solver
"""


# ============================================================
# 6. Method: "scratch" — Full Re-solve
# ============================================================

METHOD_SCRATCH = """
For structural changes (Type V, X, M) or when B⁻¹ is unavailable:
    Solve the new problem from scratch using InternalSimplex.
    No warm-start benefit, but still records the solve for comparison.

    def _scratch(self, new_problem) -> ReoptResult:
        solver = RevisedSimplex(new_problem)
        new_state = solver.solve()
        return ReoptResult(
            new_state=new_state,
            method_used="scratch",
            pivots=len(solver.iterations),
            scratch_estimate=None,  # this IS the scratch solve
            basis_preserved=False,
            reopt_time_seconds=new_state.solve_time_seconds,
        )
"""


# ============================================================
# 7. Method: "parametric_lp" — Placeholder for Phase 2+
# ============================================================

METHOD_PARAMETRIC = """
For Type RC compound changes, the ideal approach is parametric LP:
    Trace the path from old to new along θ ∈ [0, 1].
    This is designed but deferred to the next sub-task.

For now, fall back to warm-start:
    def _parametric_lp(self, old_state, new_problem, change) -> ReoptResult:
        # Phase 2+: implement parametric LP from the project plan
        # For now, use warm-start as fallback
        return self._warm_start(old_state, new_problem, change)
"""


# ============================================================
# 8. Extracting Basis Indices
# ============================================================

BASIS_EXTRACTION = """
SolveState stores basis_status per variable and per constraint,
but the Simplex solver needs integer indices into the augmented [A|I] system.

    def _extract_basis_indices(
        self,
        state: SolveState,
        problem: LPProblem,
    ) -> list[int]:
        '''Extract basis column indices from SolveState.

        In the augmented system [A|I]:
            Columns 0..n-1 are decision variables
            Columns n..n+m-1 are slack variables

        A BASIC decision variable j → index j
        A BASIC slack for constraint i → index n + i
        '''
        n = problem.num_variables
        m = problem.num_constraints
        basis = []

        # For each constraint row, find the basic variable
        # Constraints whose slack is basic → slack index (n + i)
        # Constraints whose slack is non-basic → some decision var is basic for that row
        basic_decision_vars = []
        basic_slack_rows = []

        for j, v in enumerate(state.variables):
            if v.basis_status == BasisStatus.BASIC:
                basic_decision_vars.append(j)

        for i, c in enumerate(state.constraints):
            if c.basis_status == BasisStatus.BASIC:
                basic_slack_rows.append(i)

        # Basis has m entries total (one per row)
        # Order matters: basis[i] is the basic variable for row i
        # Without the original basis ordering from the solver, we reconstruct:
        # Put slacks first in their natural row, then fill decision vars
        basis = [0] * m
        used_rows = set()

        for i in basic_slack_rows:
            if i < m:
                basis[i] = n + i
                used_rows.add(i)

        # Assign basic decision vars to remaining rows
        remaining_rows = [i for i in range(m) if i not in used_rows]
        for j, row in zip(basic_decision_vars, remaining_rows):
            basis[row] = j

        return basis
"""


# ============================================================
# 9. Main dispatch
# ============================================================

DISPATCH = """
def reoptimize(self, old_state, new_problem, change, decision) -> ReoptResult:

    method = decision.recommended_method or "scratch"

    if method == "none":
        return self._no_action(old_state, new_problem, change)

    elif method == "recompute":
        return self._recompute(old_state, new_problem, change)

    elif method == "warm_start":
        return self._warm_start(old_state, new_problem, change)

    elif method == "parametric_lp":
        return self._parametric_lp(old_state, new_problem, change)

    elif method == "scratch":
        return self._scratch(new_problem)

    else:
        return self._scratch(new_problem)
"""


# ============================================================
# 10. simplex.py Modification: from_warm_start
# ============================================================

SIMPLEX_MODIFICATION = """
Add to clara/engine/simplex.py:

class RevisedSimplex:
    # ... existing __init__ and solve() ...

    @classmethod
    def from_warm_start(
        cls,
        problem: LPProblem,
        basis: list[int],
        basis_inverse: np.ndarray,
    ) -> 'RevisedSimplex':
        '''Create a solver instance warm-started from an existing basis.

        Args:
            problem: The (possibly modified) LP problem.
            basis: List of m column indices forming the basis.
            basis_inverse: The m×m B⁻¹ matrix from the previous solve.

        Returns:
            A RevisedSimplex instance ready to call .solve().
            solve() will start from the given basis instead of the identity.
        '''
        solver = cls(problem)
        solver.basis = list(basis)
        solver.B_inv = basis_inverse.copy()
        return solver

This is safe because solve() starts by computing x_B = B_inv @ b and
checking reduced costs — it works regardless of whether the initial
basis is optimal, feasible, or neither.
"""


# ============================================================
# 11. Test Cases
# ============================================================

TEST_CASES = """
tests/test_reoptimizer.py

Setup: solve albici_base.lp → get base_state with B⁻¹.

1. Method "none" (Type C, within range)
   - test_none_preserves_solution
        → Same variable values, different optimal_value (c_new^T x)
   - test_none_zero_pivots
        → result.pivots == 0, basis_preserved == True
   - test_none_correct_objective
        → new obj = c_new @ x_old, matches expected value

2. Method "recompute" (Type R, within range — Albici b1)
   - test_recompute_albici_b1
        → x_B_new = B⁻¹ @ b1, optimal = 33100/9
        → result.pivots == 0, basis_preserved == True
   - test_recompute_correct_values
        → variable values match B⁻¹ @ b_new
   - test_recompute_slack_updated
        → slack values = b_new - A @ x_new, binding status updated
   - test_recompute_no_binv_fallback
        → If B⁻¹ is None (HiGHS state), falls back to scratch

3. Method "warm_start" (Type R, outside range — Albici b2)
   - test_warmstart_albici_b2
        → optimal = 4300.0, matches scratch solve
   - test_warmstart_fewer_pivots
        → result.pivots < result.scratch_estimate (or equal, but not more)
   - test_warmstart_type_c
        → Albici cost change, warm-start from old basis
        → optimal = 24800/3, matches scratch

4. Method "scratch"
   - test_scratch_type_v
        → Albici column addition, solved from scratch
        → optimal = 33700/9
   - test_scratch_matches_fresh
        → Same result as solving new problem independently

5. Full pipeline integration
   - test_pipeline_b1_recompute
        → detect → analyze → reoptimize → result.method_used == "recompute"
        → result.pivots == 0
   - test_pipeline_b2_warmstart
        → detect → analyze → reoptimize → result.method_used == "warm_start"
        → result.new_state.optimal_value == 4300.0
   - test_pipeline_cost_warmstart
        → detect → analyze → reoptimize → result.method_used == "warm_start"
   - test_pipeline_columns_scratch
        → detect → analyze → reoptimize → result.method_used == "scratch"

6. Warm-start correctness
   - test_warmstart_same_as_scratch
        → For every Albici scenario: warm-start optimal == scratch optimal
   - test_from_warm_start_classmethod
        → RevisedSimplex.from_warm_start works correctly

7. ReoptResult properties
   - test_speedup_computed
        → speedup = scratch_estimate / pivots
   - test_summary_basis_preserved
        → "Basis preserved" in summary when pivots == 0
   - test_summary_warm_start
        → method and pivots in summary

8. Edge cases
   - test_no_binv_always_scratch
        → HiGHS SolveState (B⁻¹ = None) → scratch for any method
   - test_recompute_negative_xb_fallback
        → B⁻¹ @ b_new has negative → falls back to warm_start
"""


# ============================================================
# 12. Module Structure
# ============================================================

MODULE_STRUCTURE = """
New files:
    clara/reopt/reoptimizer.py        # Reoptimizer class
    tests/test_reoptimizer.py         # all tests

Modified files:
    clara/reopt/types.py              # add ReoptResult dataclass
    clara/reopt/__init__.py           # re-export Reoptimizer, ReoptResult
    clara/engine/simplex.py           # add from_warm_start() classmethod
"""


# ============================================================
# 13. Implementation Order
# ============================================================

IMPLEMENTATION_ORDER = """
1. git checkout -b feat/reoptimizer

2. Add ReoptResult to clara/reopt/types.py
   - Commit: "feat: add ReoptResult dataclass"

3. Add from_warm_start() to clara/engine/simplex.py
   - Commit: "feat: RevisedSimplex.from_warm_start() classmethod"

4. Implement clara/reopt/reoptimizer.py
   - _no_action(), _recompute(), _warm_start(), _scratch(), _parametric_lp()
   - _extract_basis_indices()
   - Main dispatch: reoptimize()
   - Commit: "feat: Warm-start Reoptimizer (B⁻¹ based)"

5. Tests
   - tests/test_reoptimizer.py
   - All Albici scenarios: recompute, warm-start, scratch
   - Full pipeline: detect → analyze → reoptimize
   - Commit: "test: Reoptimizer tests with Albici validation"

6. pytest full suite, update CLAUDE.md
   - Commit: "docs: update CLAUDE.md for Phase 2 Reoptimizer"
"""


# ============================================================
# 14. Connection to Diff Report (next step)
# ============================================================

NEXT_STEP = """
After reoptimization, the Diff Report compares old_state and new_state:

    result = reoptimizer.reoptimize(old_state, new_problem, change, decision)

    diff = DiffReporter().diff(
        old_state=old_state,
        new_state=result.new_state,
        change=change,
        reopt_result=result,
    )

    print(diff.to_text())
    # "RHS changed in S1 (1200 → 1500) and S3 (2000 → 2400).
    #  Basis broke — reoptimized via warm-start (3 pivots, 4.2x faster than scratch).
    #  x1 increased from 755.56 to 940.00 (+24.4%).
    #  S3 is no longer the bottleneck — S1 now has the highest shadow price."

This is the final piece that makes the complete reoptimization pipeline
explainable end-to-end.
"""