"""
CLARA Phase 2 — Change Detector Design Specification
======================================================

The Change Detector compares two LPProblem instances (old vs new)
and classifies what changed using Albici et al. (2010) taxonomy.

This is the entry point of the reoptimization pipeline:
    Change Detector → Impact Analyzer → Reoptimizer → Diff Report

Branch: feat/change-detector
"""


# ============================================================
# 1. Public API
# ============================================================

API = """
# Module: clara/reopt/detector.py

class ChangeDetector:
    '''Compare two LP problems and classify the parameter changes.

    Based on Albici et al. (2010) taxonomy, extended with Type RC.
    '''

    def detect(
        self,
        old: LPProblem,
        new: LPProblem,
    ) -> ParameterChange:
        '''Compare old and new problem, return classified change.

        Args:
            old: The original problem (already solved, SolveState available).
            new: The modified problem.

        Returns:
            ParameterChange with change_type and relevant delta vectors.

        Raises:
            IncompatibleProblemsError: If problems can't be meaningfully compared
                (e.g., completely different variable sets with no overlap).
        '''

# Usage:
    detector = ChangeDetector()
    change = detector.detect(old_problem, new_problem)

    # change.change_type → ChangeType.TYPE_R / TYPE_C / TYPE_RC / etc.
    # change.delta_b → numpy array of RHS changes (or None)
    # change.delta_c → numpy array of obj coeff changes (or None)
    # change.new_columns → dict of new variables (or None)
    # etc.
"""


# ============================================================
# 2. Change Type Classification (Albici 2010 + extensions)
# ============================================================

CLASSIFICATION = """
Detection logic (in order of checks):

1. Compare variable sets:
   - old_vars ⊂ new_vars → possible Type V (column addition)
   - new_vars ⊂ old_vars → possible Type M (variable removal) — unusual
   - Completely different → IncompatibleProblemsError

2. Compare constraint sets:
   - old_constraints ⊂ new_constraints → possible Type X (row addition)
   - new_constraints ⊂ old_constraints → possible Type M (row removal)

3. For shared variables and constraints, compare parameters:
   - delta_b = new.b - old.b (RHS changes)
   - delta_c = new.c - old.c (objective coefficient changes)
   - delta_A = new.A - old.A (constraint matrix changes)

4. Classify:
   ┌────────────────────────────┬──────────────┐
   │ Condition                  │ Type         │
   ├────────────────────────────┼──────────────┤
   │ Only b changed             │ TYPE_R       │
   │ Only c changed             │ TYPE_C       │
   │ Both b and c changed       │ TYPE_RC      │
   │ New columns added          │ TYPE_V       │
   │ New rows added             │ TYPE_X       │
   │ Rows removed               │ TYPE_M       │
   │ A matrix changed           │ TYPE_A (new) │
   │ Multiple structural changes│ TYPE_MULTI   │
   │ Nothing changed            │ None         │
   └────────────────────────────┴──────────────┘

   Priority: structural changes (V, X, M) override parametric changes (R, C, RC).
   If both structural and parametric changes exist → TYPE_MULTI.

5. Tolerance: changes smaller than 1e-10 are treated as zero (numerical noise).
"""


# ============================================================
# 3. ParameterChange Construction
# ============================================================

PARAMETER_CHANGE = """
Already defined in reopt/types.py. The detector fills it:

For TYPE_R:
    ParameterChange(
        change_type=ChangeType.TYPE_R,
        delta_b=np.array([100, -200, 0, 50]),  # per-constraint RHS change
    )

For TYPE_C:
    ParameterChange(
        change_type=ChangeType.TYPE_C,
        delta_c=np.array([5, 2, 2]),  # per-variable obj coeff change
    )

For TYPE_RC:
    ParameterChange(
        change_type=ChangeType.TYPE_RC,
        delta_b=np.array([300, -100, 400, 0]),
        delta_c=np.array([5, 2, 2]),
    )

For TYPE_V:
    ParameterChange(
        change_type=ChangeType.TYPE_V,
        new_columns={
            "x4": {"cost": 3.0, "column": [2.0, 0.0, 1.0, 0.0]},
            "x5": {"cost": 5.0, "column": [3.0, 1.0, 0.0, 1.0]},
        },
    )

For TYPE_X:
    ParameterChange(
        change_type=ChangeType.TYPE_X,
        new_rows={
            "new_c1": {"coeffs": [1.0, 1.0, 0.0], "rhs": 500.0},
        },
    )

For TYPE_M:
    ParameterChange(
        change_type=ChangeType.TYPE_M,
        removed_rows=["S4"],
    )
"""


# ============================================================
# 4. Additional Types Needed
# ============================================================

ADDITIONAL_TYPES = """
Add to reopt/types.py:

class ChangeType(Enum):
    # ... existing ...
    TYPE_A = auto()      # constraint matrix A changed (not just b or c)
    TYPE_MULTI = auto()  # multiple structural changes

class IncompatibleProblemsError(Exception):
    '''Raised when two problems cannot be meaningfully compared.'''
    pass

Update ParameterChange to include:
    delta_A: Optional[np.ndarray] = None   # A matrix change (for TYPE_A)
    added_vars: Optional[list[str]] = None  # names of added variables (TYPE_V)
    removed_vars: Optional[list[str]] = None  # names of removed variables

Add summary property:
    @property
    def summary(self) -> str:
        '''Human-readable one-line summary of the change.'''
        if self.change_type == ChangeType.TYPE_R:
            n_changed = int(np.sum(np.abs(self.delta_b) > 1e-10))
            return f"RHS changed in {n_changed} constraint(s)"
        elif self.change_type == ChangeType.TYPE_C:
            n_changed = int(np.sum(np.abs(self.delta_c) > 1e-10))
            return f"Objective coefficients changed for {n_changed} variable(s)"
        elif self.change_type == ChangeType.TYPE_RC:
            return "Both RHS and objective coefficients changed (compound)"
        elif self.change_type == ChangeType.TYPE_V:
            return f"{len(self.new_columns)} new variable(s) added"
        elif self.change_type == ChangeType.TYPE_X:
            return f"{len(self.new_rows)} new constraint(s) added"
        elif self.change_type == ChangeType.TYPE_M:
            return f"{len(self.removed_rows)} constraint(s) removed"
        return "Unknown change"
"""


# ============================================================
# 5. Implementation
# ============================================================

IMPLEMENTATION = """
class ChangeDetector:

    TOLERANCE = 1e-10

    def detect(self, old: LPProblem, new: LPProblem) -> ParameterChange | None:

        # Step 1: Variable set comparison
        old_vars = set(old.var_names)
        new_vars = set(new.var_names)
        added_vars = new_vars - old_vars
        removed_vars = old_vars - new_vars
        common_vars = old_vars & new_vars

        if not common_vars:
            raise IncompatibleProblemsError(
                f"No common variables between problems. "
                f"Old: {old.var_names}, New: {new.var_names}"
            )

        # Step 2: Constraint set comparison
        old_cons = set(old.constraint_names)
        new_cons = set(new.constraint_names)
        added_cons = new_cons - old_cons
        removed_cons = old_cons - new_cons
        common_cons = old_cons & new_cons

        # Step 3: For common vars/constraints, compute deltas
        # Build index maps: old variable position → new variable position
        old_var_idx = {name: i for i, name in enumerate(old.var_names)}
        new_var_idx = {name: i for i, name in enumerate(new.var_names)}
        old_con_idx = {name: i for i, name in enumerate(old.constraint_names)}
        new_con_idx = {name: i for i, name in enumerate(new.constraint_names)}

        # Compute delta_c for common variables
        delta_c = np.zeros(len(old.var_names))
        c_changed = False
        for name in common_vars:
            oi, ni = old_var_idx[name], new_var_idx[name]
            d = new.c[ni] - old.c[oi]
            delta_c[oi] = d
            if abs(d) > self.TOLERANCE:
                c_changed = True

        # Compute delta_b for common constraints
        delta_b = np.zeros(len(old.constraint_names))
        b_changed = False
        for name in common_cons:
            oi, ni = old_con_idx[name], new_con_idx[name]
            d = new.b[ni] - old.b[oi]
            delta_b[oi] = d
            if abs(d) > self.TOLERANCE:
                b_changed = True

        # Compute delta_A for common vars × common constraints
        a_changed = False
        for con_name in common_cons:
            for var_name in common_vars:
                oi_c, ni_c = old_con_idx[con_name], new_con_idx[con_name]
                oi_v, ni_v = old_var_idx[var_name], new_var_idx[var_name]
                d = new.A[ni_c, ni_v] - old.A[oi_c, oi_v]
                if abs(d) > self.TOLERANCE:
                    a_changed = True
                    break
            if a_changed:
                break

        # Step 4: Classify
        has_structural = bool(added_vars or removed_vars or added_cons or removed_cons)

        if not has_structural and not c_changed and not b_changed and not a_changed:
            return None  # No change detected

        # Build new_columns dict for added vars
        new_columns = None
        if added_vars:
            new_columns = {}
            for name in added_vars:
                ni = new_var_idx[name]
                # Get column from new problem for common constraints
                col = []
                for con_name in old.constraint_names:
                    if con_name in new_con_idx:
                        col.append(float(new.A[new_con_idx[con_name], ni]))
                    else:
                        col.append(0.0)
                new_columns[name] = {
                    "cost": float(new.c[ni]),
                    "column": col,
                }

        # Build new_rows dict for added constraints
        new_rows = None
        if added_cons:
            new_rows = {}
            for name in added_cons:
                ni = new_con_idx[name]
                coeffs = []
                for var_name in old.var_names:
                    if var_name in new_var_idx:
                        coeffs.append(float(new.A[ni, new_var_idx[var_name]]))
                    else:
                        coeffs.append(0.0)
                new_rows[name] = {
                    "coeffs": coeffs,
                    "rhs": float(new.b[ni]),
                }

        removed_row_list = sorted(removed_cons) if removed_cons else None

        # Classification
        if has_structural:
            if added_vars and not added_cons and not removed_cons and not b_changed and not c_changed:
                change_type = ChangeType.TYPE_V
            elif added_cons and not added_vars and not removed_vars and not b_changed and not c_changed:
                change_type = ChangeType.TYPE_X
            elif removed_cons and not added_vars and not added_cons and not b_changed and not c_changed:
                change_type = ChangeType.TYPE_M
            else:
                change_type = ChangeType.TYPE_MULTI
        elif a_changed:
            change_type = ChangeType.TYPE_A
        elif b_changed and c_changed:
            change_type = ChangeType.TYPE_RC
        elif b_changed:
            change_type = ChangeType.TYPE_R
        elif c_changed:
            change_type = ChangeType.TYPE_C
        else:
            return None

        return ParameterChange(
            change_type=change_type,
            delta_b=delta_b if b_changed else None,
            delta_c=delta_c if c_changed else None,
            new_columns=new_columns,
            new_rows=new_rows,
            removed_rows=removed_row_list,
        )
"""


# ============================================================
# 6. Test Cases
# ============================================================

TEST_CASES = """
tests/test_change_detector.py

Uses Albici et al. fixtures as primary test data.

1. Albici scenarios (golden tests from the paper)
   - test_albici_base_to_b1          → TYPE_R, delta_b = [100, -200, -200, 200]
   - test_albici_base_to_b2          → TYPE_R, delta_b = [300, -100, 400, 0]
   - test_albici_base_to_cost        → TYPE_C, delta_c = [5, 2, 2]
   - test_albici_base_to_columns     → TYPE_V, 2 new columns (x4, x5)
   - test_albici_compound_b2_cost    → TYPE_RC, both delta_b and delta_c present

2. No change
   - test_identical_problems         → returns None
   - test_negligible_change          → change < tolerance → None

3. Structural changes
   - test_add_constraint             → TYPE_X, new_rows populated
   - test_remove_constraint          → TYPE_M, removed_rows populated
   - test_add_variable               → TYPE_V, new_columns populated
   - test_mixed_structural           → TYPE_MULTI (add var + change b)

4. Edge cases
   - test_incompatible_problems      → IncompatibleProblemsError
   - test_single_variable_change     → TYPE_C, only one element of delta_c nonzero
   - test_single_constraint_change   → TYPE_R, only one element of delta_b nonzero
   - test_a_matrix_change            → TYPE_A (coefficient matrix changed)

5. Summary property
   - test_summary_type_r             → "RHS changed in 2 constraint(s)"
   - test_summary_type_c             → "Objective coefficients changed for 3 variable(s)"
   - test_summary_type_rc            → "Both RHS and objective coefficients changed (compound)"
   - test_summary_type_v             → "2 new variable(s) added"

6. Delta vector correctness
   - test_delta_b_matches_manual     → compare against hand-computed Albici deltas
   - test_delta_c_preserves_order    → delta_c indices match old.var_names ordering
   - test_new_column_values          → column coefficients match new problem's A matrix
"""


# ============================================================
# 7. Module Structure
# ============================================================

MODULE_STRUCTURE = """
New files:
    clara/reopt/detector.py           # ChangeDetector class
    tests/test_change_detector.py     # all tests

Modified files:
    clara/reopt/types.py              # add TYPE_A, TYPE_MULTI, IncompatibleProblemsError,
                                      #   delta_A field, summary property
    clara/reopt/__init__.py           # re-export ChangeDetector
"""


# ============================================================
# 8. Implementation Order
# ============================================================

IMPLEMENTATION_ORDER = """
1. git checkout -b feat/change-detector

2. Update clara/reopt/types.py
   - Add ChangeType.TYPE_A, TYPE_MULTI
   - Add IncompatibleProblemsError
   - Add delta_A field to ParameterChange
   - Add summary property
   - Commit: "feat: extend reopt types for change detection"

3. Implement clara/reopt/detector.py
   - ChangeDetector.detect()
   - Full classification logic
   - Commit: "feat: Change Detector (Albici-based change classification)"

4. Tests
   - tests/test_change_detector.py
   - All Albici scenarios + edge cases
   - Commit: "test: Change Detector tests with Albici validation"

5. pytest full suite, update CLAUDE.md
   - Commit: "docs: update CLAUDE.md for Phase 2 Change Detector"
"""


# ============================================================
# 9. Connection to Next Step (Impact Analyzer)
# ============================================================

NEXT_STEP = """
After Change Detector, the Impact Analyzer uses its output:

    change = ChangeDetector().detect(old_problem, new_problem)

    if change is None:
        print("No change detected — solution is still valid.")

    elif change.change_type == ChangeType.TYPE_C:
        # Oguz bound: 2δ/(1+δ)
        delta = max(|Δc_j / c_j| for j where Δc_j ≠ 0)
        bound = 2 * delta / (1 + delta)
        if bound < threshold:
            print("Opportunity cost is small — reoptimization unnecessary.")
        else:
            # Check sensitivity ranges
            ...

    elif change.change_type == ChangeType.TYPE_R:
        # Check if delta_b falls within SolveState sensitivity ranges
        ...

    elif change.change_type == ChangeType.TYPE_RC:
        # Parametric LP needed
        ...

This pipeline is designed in the next spec (impact_analyzer_spec.py).
"""