"""
CLARA Branch-and-Bound Engine — Design Specification (Educational)
===================================================================

A transparent, explainable Branch-and-Bound MIP solver.
Uses InternalSimplex as LP relaxation solver at each node.

Design goals:
    1. Explainable: every node decision recorded as BnBNodeSnapshot
    2. Transparent: users see WHY each branch was chosen, WHY a node was fathomed
    3. Simple: minimal implementation, maximum traceability
    4. Practical MIP solving deferred to HiGHS backend

Non-goals (deferred):
    - Gomory cuts (Phase 2+)
    - Strong branching (Phase 2+)
    - Presolve beyond bound tightening (Phase 2+)
    - Performance competition with HiGHS/SCIP/Gurobi

Branch: feat/bnb-engine
Milestone: v0.5.0 (Phase 1.5)
"""


# ============================================================
# 1. Architecture
# ============================================================

ARCHITECTURE = """
┌──────────────────────────────────────────────────┐
│                  InternalBnB                      │
│                                                   │
│  1. Bound tightening (integer vars only)          │
│  2. Root LP relaxation (InternalSimplex)          │
│  3. If integer feasible → done                    │
│  4. B&B tree search:                              │
│     ┌──────────────────────────────────┐          │
│     │  Pop node from queue             │          │
│     │  Solve LP relaxation (warm-start)│          │
│     │  Fathom check:                   │          │
│     │    - infeasible?                 │          │
│     │    - bound worse than incumbent? │          │
│     │    - integer feasible?           │          │
│     │  If not fathomed:                │          │
│     │    - Pick branching variable     │          │
│     │    - Create two child nodes      │          │
│     │  Record BnBNodeSnapshot          │          │
│     └──────────────────────────────────┘          │
│  5. Return SolveState with full bnb_history       │
└──────────────────────────────────────────────────┘

LP solver: InternalSimplex (reuses B⁻¹ for warm-start between parent→child)
"""


# ============================================================
# 2. Public API
# ============================================================

API = """
# Module: clara/engine/bnb.py

class InternalBnB:
    '''Educational Branch-and-Bound MIP solver with full explainability.

    For performance on real MIP problems, use HiGHS backend.
    This engine is for understanding and explaining the B&B process.
    '''

    def __init__(
        self,
        node_selection: str = "best_first",  # "best_first" | "depth_first"
        max_nodes: int = 10_000,             # node limit
        max_time: float = 60.0,              # time limit (seconds)
        gap_tolerance: float = 1e-6,         # relative MIP gap
        int_tolerance: float = 1e-6,         # integrality tolerance
    ):
        ...

    def solve(self, problem: LPProblem) -> SolveState:
        '''Solve a MIP and return SolveState with full B&B trace.

        If problem has no integer/binary variables, delegates to
        InternalSimplex directly.

        SolveState.bnb_history contains every node explored.
        '''
"""


# ============================================================
# 3. Bound Tightening (only presolve step)
# ============================================================

BOUND_TIGHTENING = """
For integer variables only. Applied once before root LP.

For each constraint  a1*x1 + a2*x2 + ... <= b:
    For integer variable x_j with coefficient a_j > 0:
        implied_upper = floor((b - sum of a_i * lb_i for i != j) / a_j)
        if implied_upper < current_upper:
            tighten upper bound

    Similarly for a_j < 0 → tighten lower bound.

Binary variables: bounds are already [0, 1], but constraints may imply fixing.
Example: if x1 + x2 <= 1 and x1 >= 1, then x2 must be 0.

Implementation:
    def _tighten_bounds(self, problem: LPProblem) -> LPProblem:
        '''Return problem with tightened integer variable bounds.
        Does NOT modify the original problem (returns a copy).
        '''

Simple, no postsolve needed (bounds are just tightened, no variables removed).
"""


# ============================================================
# 4. Branching: Most Fractional
# ============================================================

BRANCHING = """
Single strategy: Most Fractional.

For each integer variable with fractional LP value:
    fractionality = value - floor(value)
    score = 0.5 - abs(fractionality - 0.5)
    (score = 0.5 when fractionality = 0.5, score → 0 when nearly integer)

Select the variable with the highest score.
Tiebreak: lowest variable index (deterministic).

    @dataclass(frozen=True)
    class BranchDecision:
        variable: str
        variable_index: int
        current_value: float
        branch_down: float         # floor(current_value)
        branch_up: float           # ceil(current_value)
        fractionality: float       # value - floor(value)

    def _select_branching_variable(
        self,
        state: SolveState,
        problem: LPProblem,
    ) -> BranchDecision:
        '''Select most fractional integer variable for branching.'''

Explainability:
    "Branching on x3 (value = 2.67, fractionality = 0.67).
     Down branch: x3 ≤ 2. Up branch: x3 ≥ 3."
"""


# ============================================================
# 5. Node Selection
# ============================================================

NODE_SELECTION = """
Two strategies, selected by constructor parameter:

Best-First (default):
    Priority queue ordered by LP relaxation bound.
    MAX: highest bound first. MIN: lowest bound first.
    Implementation: heapq.

Depth-First:
    Stack (LIFO). Explores most recently created child first.
    Implementation: list with append/pop.

    class _BestFirstQueue:
        def push(self, node: _BnBNode) -> None: ...
        def pop(self) -> _BnBNode: ...
        def __len__(self) -> int: ...
        def prune(self, cutoff: float) -> int:
            '''Remove nodes with bound worse than cutoff. Return count removed.'''

    class _DepthFirstQueue:
        # Same interface, but LIFO

    @dataclass
    class _BnBNode:
        node_id: int
        parent_id: int | None
        depth: int
        lp_bound: float
        branch_constraints: list[tuple[str, str, float]]
            # accumulated: [(var_name, "<="|">=", value), ...]

Node queue classes are internal (_prefixed), not part of public API.
"""


# ============================================================
# 6. Main B&B Loop
# ============================================================

MAIN_LOOP = """
def solve(self, problem: LPProblem) -> SolveState:

    # Pure LP check
    if not problem.integer_vars and not problem.binary_vars:
        return InternalSimplex().solve(problem)

    # Bound tightening
    problem = self._tighten_bounds(problem)

    # Root LP
    root_state = InternalSimplex().solve(problem)
    if not root_state.is_optimal:
        return root_state

    if self._is_integer_feasible(root_state, problem):
        return root_state  # solved at root!

    # Initialize tree
    incumbent = None
    incumbent_value = -inf  # MAX; +inf for MIN
    queue = self._make_queue(node_selection)
    queue.push(_BnBNode(id=0, parent=None, depth=0,
                         bound=root_state.optimal_value,
                         constraints=[]))
    snapshots = []
    next_id = 1

    while len(queue) > 0 and nodes < max_nodes and time < max_time:

        node = queue.pop()

        # Bound pruning
        if incumbent and node.lp_bound <= incumbent_value:  # MAX
            snapshots.append(snapshot(node, fathom="bound"))
            continue

        # Solve LP at this node
        node_problem = self._add_constraints(problem, node.branch_constraints)
        node_state = InternalSimplex().solve(node_problem)
        nodes += 1

        # Infeasible
        if not node_state.is_optimal:
            snapshots.append(snapshot(node, fathom="infeasible"))
            continue

        # Bound pruning (after solve)
        if incumbent and node_state.optimal_value <= incumbent_value:
            snapshots.append(snapshot(node, fathom="bound"))
            continue

        # Integer feasible → new incumbent?
        if self._is_integer_feasible(node_state, problem):
            if node_state.optimal_value > incumbent_value:
                incumbent = node_state
                incumbent_value = node_state.optimal_value
                queue.prune(incumbent_value)  # remove dominated nodes
            snapshots.append(snapshot(node, fathom="integer", incumbent=incumbent_value))
            continue

        # Branch
        decision = self._select_branching_variable(node_state, problem)
        snapshots.append(snapshot(node, branch=decision))

        # Create children
        down = _BnBNode(id=next_id, parent=node.id, depth=node.depth+1,
                         bound=node_state.optimal_value,
                         constraints=node.constraints + [(decision.variable, "<=", decision.branch_down)])
        up = _BnBNode(id=next_id+1, parent=node.id, depth=node.depth+1,
                       bound=node_state.optimal_value,
                       constraints=node.constraints + [(decision.variable, ">=", decision.branch_up)])
        next_id += 2
        queue.push(down)
        queue.push(up)

    # Build SolveState
    return self._build_state(incumbent, snapshots, problem)
"""


# ============================================================
# 7. BnBNodeSnapshot
# ============================================================

NODE_SNAPSHOT = """
Already defined in solve_state_design.py:

    @dataclass(frozen=True)
    class BnBNodeSnapshot:
        node_id: int
        parent_id: int | None
        depth: int
        branching_var: str
        branching_direction: str        # "<=", ">="
        branching_value: float
        lp_relaxation_value: float
        is_integer_feasible: bool
        is_fathomed: bool
        fathom_reason: str | None       # "bound", "infeasible", "integer_feasible"
        incumbent_value: float | None

For branched (non-fathomed) nodes:
    branching_var = decision.variable
    branching_direction = "" (both children created)
    is_fathomed = False

For fathomed nodes:
    branching_var = "" (no branching)
    is_fathomed = True
    fathom_reason = "bound" | "infeasible" | "integer_feasible"
"""


# ============================================================
# 8. B&B Explainer
# ============================================================

BNB_EXPLAINER = """
Module: clara/explain/bnb_report.py

class BnBReportGenerator:
    def generate(self, state: SolveState, level: DetailLevel) -> BnBReport:
        '''Generate B&B explanation from bnb_history.'''

@dataclass
class BnBReport:
    summary: str
    root_lp_bound: float
    mip_optimal: float
    gap_closed_pct: float
    nodes_explored: int
    nodes_by_reason: dict[str, int]   # {"bound": 23, "infeasible": 8, ...}
    optimal_node_id: int
    optimal_depth: int
    max_depth: int

    def to_text(self, level: DetailLevel) -> str: ...
    def to_dict(self) -> dict: ...

--- BRIEF output ---
MIP solved: 42.0000 (LP relaxation: 44.0000, gap closed: 100%)
Explored 15 nodes in 0.02s. Solution found at node 7 (depth 3).

--- DETAILED output ---
BRANCH-AND-BOUND TREE
─────────────────────────────────────────────────
Root LP relaxation: 44.0000
MIP optimal: 42.0000 (gap: 0.00%)
Nodes explored: 15 (9 pruned by bound, 2 infeasible, 3 integer-feasible)
Solution found at node 7 (depth 3)
Max tree depth: 5

Node trace:
  Node 0 (root): LP = 44.00, branch on x3 (value = 0.50)
    Node 1 (x3 ≤ 0): LP = 38.00, integer feasible → incumbent = 38.00
    Node 2 (x3 ≥ 1): LP = 42.00, branch on x1 (value = 0.57)
      Node 3 (x1 ≤ 0): LP = 42.00, integer feasible → incumbent = 42.00
      Node 4 (x1 ≥ 1): LP = 41.00, pruned by bound
  [remaining nodes pruned by incumbent = 42.00]

Explainer integration:
    ExplanationReport gets a new optional field:
        bnb: BnBReport | None  (None for pure LP)

    ExplanationReport.to_text() includes B&B section if bnb is present,
    placed between header and Binding Report.
"""


# ============================================================
# 9. Module Structure
# ============================================================

MODULE_STRUCTURE = """
New files:
    clara/engine/bnb.py             # InternalBnB + _BnBNode + queues + branching
    clara/explain/bnb_report.py     # BnBReportGenerator + BnBReport
    tests/test_bnb.py               # all B&B tests
    tests/fixtures/knapsack_small.lp
    tests/fixtures/assignment_small.lp
    tests/fixtures/facility_small.lp

Modified files:
    clara/explain/explainer.py      # add bnb report to ExplanationReport
    clara/explain/types.py          # add BnBReport dataclass
    clara/cli.py                    # auto-detect LP vs MIP
    clara/model/solve_state.py      # add SolveStatus.NODE_LIMIT, TIME_LIMIT if missing

Everything in bnb.py is one file — no need to split into branching.py,
node_selection.py etc. for this scope. Keep it simple.
"""


# ============================================================
# 10. MIP Test Fixtures (verified by scipy)
# ============================================================

TEST_FIXTURES = """

--- knapsack_small.lp ---
  Maximize
    obj: 16 x1 + 22 x2 + 12 x3 + 8 x4 + 11 x5
  Subject To
    weight: 5 x1 + 7 x2 + 4 x3 + 3 x4 + 4 x5 <= 14
  Binary
    x1 x2 x3 x4 x5
  End

  LP relaxation: 44.0 (x1=1, x2=1, x3=0.5)
  MIP optimal: 42.0 (x1=0, x2=1, x3=1, x4=1)
  Gap: 4.76%
  Purpose: fractional root, branching needed, solution structure changes entirely.


--- assignment_small.lp ---
  Minimize
    obj: 9 x11 + 2 x12 + 7 x13 + 8 x14
       + 6 x21 + 4 x22 + 3 x23 + 7 x24
       + 5 x31 + 8 x32 + x33 + 8 x34
       + 7 x41 + 6 x42 + 9 x43 + 4 x44
  Subject To
    w1: x11 + x12 + x13 + x14 = 1
    w2: x21 + x22 + x23 + x24 = 1
    w3: x31 + x32 + x33 + x34 = 1
    w4: x41 + x42 + x43 + x44 = 1
    t1: x11 + x21 + x31 + x41 = 1
    t2: x12 + x22 + x32 + x42 = 1
    t3: x13 + x23 + x33 + x43 = 1
    t4: x14 + x24 + x34 + x44 = 1
  Binary
    x11 x12 x13 x14 x21 x22 x23 x24 x31 x32 x33 x34 x41 x42 x43 x44
  End

  LP = MIP = 13 (totally unimodular → integer at root)
  W1→T2(2), W2→T1(6), W3→T3(1), W4→T4(4)
  Purpose: B&B detects integrality at root, no branching needed.


--- facility_small.lp ---
  Minimize
    obj: 20 y1 + 25 y2 + 18 y3
       + 4 x11 + 6 x12 + 9 x13 + 8 x14 + 7 x15
       + 6 x21 + 3 x22 + 7 x23 + 4 x24 + 5 x25
       + 5 x31 + 7 x32 + 3 x33 + 6 x34 + 4 x35
  Subject To
    d1: x11 + x21 + x31 = 1
    d2: x12 + x22 + x32 = 1
    d3: x13 + x23 + x33 = 1
    d4: x14 + x24 + x34 = 1
    d5: x15 + x25 + x35 = 1
    l11: x11 - y1 <= 0
    l12: x12 - y1 <= 0
    l13: x13 - y1 <= 0
    l14: x14 - y1 <= 0
    l15: x15 - y1 <= 0
    l21: x21 - y2 <= 0
    l22: x22 - y2 <= 0
    l23: x23 - y2 <= 0
    l24: x24 - y2 <= 0
    l25: x25 - y2 <= 0
    l31: x31 - y3 <= 0
    l32: x32 - y3 <= 0
    l33: x33 - y3 <= 0
    l34: x34 - y3 <= 0
    l35: x35 - y3 <= 0
    c1: x11 + x12 + x13 + x14 + x15 - 3 y1 <= 0
    c2: x21 + x22 + x23 + x24 + x25 - 2 y2 <= 0
    c3: x31 + x32 + x33 + x34 + x35 - 3 y3 <= 0
  Bounds
    0 <= y1 <= 1
    0 <= y2 <= 1
    0 <= y3 <= 1
    0 <= x11 <= 1
    0 <= x12 <= 1
    0 <= x13 <= 1
    0 <= x14 <= 1
    0 <= x15 <= 1
    0 <= x21 <= 1
    0 <= x22 <= 1
    0 <= x23 <= 1
    0 <= x24 <= 1
    0 <= x25 <= 1
    0 <= x31 <= 1
    0 <= x32 <= 1
    0 <= x33 <= 1
    0 <= x34 <= 1
    0 <= x35 <= 1
  Binary
    y1 y2 y3
  End

  LP relaxation: 56.33 (y1=0.67, y2=0, y3=1)
  MIP optimal: 61.0 (y1=1, y3=1; fac1→{1,2}, fac3→{3,4,5})
  Gap: 7.65%
  Purpose: mixed integer (binary+continuous), fractional y at root.
"""


# ============================================================
# 11. Test Cases
# ============================================================

TEST_CASES = """
tests/test_bnb.py

1. Pure LP fallback
   - test_pure_lp_delegates           → no integer vars → uses simplex, same result
   - test_pure_lp_no_bnb_history      → bnb_history is None for pure LP

2. Root node
   - test_root_integer_feasible       → assignment: solved at root, 0 branches
   - test_root_fractional             → knapsack: root is fractional, tree needed

3. Optimality
   - test_knapsack_optimal            → MIP optimal = 42.0
   - test_assignment_optimal          → MIP optimal = 13.0
   - test_facility_optimal            → MIP optimal = 61.0
   - test_knapsack_matches_highs      → same value as HiGHS backend
   - test_facility_matches_highs      → same value as HiGHS backend

4. Branching
   - test_most_fractional_picks_x3    → knapsack: x3=0.5 is most fractional
   - test_branch_creates_two_children → node produces exactly 2 children
   - test_branch_constraints_accumulate → child has parent's constraints + new one

5. Node selection
   - test_best_first_explores_best    → first non-root node has best bound
   - test_depth_first_explores_deep   → explores children before siblings

6. Fathoming
   - test_fathom_by_bound             → node with LP bound ≤ incumbent is pruned
   - test_fathom_infeasible           → infeasible node is pruned
   - test_fathom_integer_updates_incumbent → new integer solution updates incumbent

7. Limits
   - test_node_limit                  → stops at max_nodes, returns best found
   - test_reports_node_limit_status   → status = NODE_LIMIT

8. Explainability (bnb_history)
   - test_history_not_none            → bnb_history is populated
   - test_history_has_root            → node_id=0 exists
   - test_history_tree_connected      → every parent_id exists (except root)
   - test_all_fathom_reasons_valid    → only "bound"|"infeasible"|"integer_feasible"
   - test_snapshot_fields_complete    → all fields populated in each snapshot

9. B&B Report
   - test_bnb_report_brief            → summary string present
   - test_bnb_report_detailed         → node trace present
   - test_bnb_report_json             → valid JSON with bnb_report key

10. CLI integration
    - test_explain_mip_file           → clara explain knapsack.lp works
    - test_explain_mip_json           → JSON has bnb_report section
    - test_explain_auto_detects_mip   → no --engine flag needed for MIP
"""


# ============================================================
# 12. CLI Updates
# ============================================================

CLI_UPDATES = """
clara explain auto-detects LP vs MIP:
    - Has integer/binary vars → InternalBnB (internal) or HiGHS (highs)
    - Pure LP → InternalSimplex (internal) or HiGHS (highs)

No new CLI flags needed. Just smarter engine dispatch.

MIP explain output adds B&B section between header and Binding Report:

  ═══════════════════════════════════════════════════
  CLARA — knapsack_small
  Optimal value: 42.0000 (OPTIMAL)
  MIP gap: 0.00%
  15 nodes explored, 0.02s (INTERNAL_BNB)
  ═══════════════════════════════════════════════════

  BRANCH-AND-BOUND SUMMARY
  ─────────────────────────────────────────────────
  Root LP relaxation: 44.0000
  Nodes explored: 15 (9 pruned by bound, 2 infeasible)
  Solution found at node 7 (depth 3)

  [Then existing Binding / Variable / Sensitivity reports]
"""


# ============================================================
# 13. Implementation Order
# ============================================================

IMPLEMENTATION_ORDER = """
1. git checkout -b feat/bnb-engine

2. MIP test fixtures
   - Create knapsack_small.lp, assignment_small.lp, facility_small.lp
   - Commit: "test: add MIP test fixtures"

3. InternalBnB engine (clara/engine/bnb.py)
   - _BnBNode, _BestFirstQueue, _DepthFirstQueue
   - _tighten_bounds, _select_branching_variable (most fractional)
   - Main B&B loop
   - tests/test_bnb.py
   - Commit: "feat: educational Branch-and-Bound MIP solver"

4. B&B explainer (clara/explain/bnb_report.py)
   - BnBReport dataclass
   - BnBReportGenerator
   - Integrate into ExplanationReport
   - Commit: "feat: B&B explanation report"

5. CLI update
   - Auto-detect LP vs MIP in _make_engine()
   - B&B report in explain output
   - tests/test_cli.py (add MIP tests)
   - Commit: "feat: CLI auto-detect MIP"

6. Cross-validation
   - Add MIP fixtures to test_cross_validation.py
   - Commit: "test: MIP cross-validation with HiGHS"

7. Final
   - pytest full suite
   - Update CLAUDE.md
   - Commit: "docs: update CLAUDE.md for Phase 1.5 B&B"
"""