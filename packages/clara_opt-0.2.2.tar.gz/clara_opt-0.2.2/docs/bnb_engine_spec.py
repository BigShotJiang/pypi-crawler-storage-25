"""
CLARA Branch-and-Bound Engine — Design Specification
======================================================

A practical, explainable Branch-and-Cut MIP solver.
Uses InternalSimplex as LP relaxation solver at each node.

Design goals:
    1. Practical: Gomory cuts, strong branching, presolve — not a toy
    2. Explainable: every node decision recorded as BnBNodeSnapshot
    3. Transparent: users can see WHY each branch was chosen, WHY a node was fathomed
    4. Dual backend: Internal B&B (full trace) vs HiGHS (performance)

Branch: feat/bnb-engine
Milestone: v0.5.0 (Phase 1.5)
"""


# ============================================================
# 1. Architecture Overview
# ============================================================

ARCHITECTURE = """
┌─────────────────────────────────────────────────────────┐
│                   InternalBnB                            │
│                                                          │
│  ┌──────────┐    ┌──────────────┐    ┌───────────────┐  │
│  │ Presolve │───▶│  Root Node   │───▶│   Cut Loop    │  │
│  │          │    │ (LP relax)   │    │ (Gomory GMI)  │  │
│  └──────────┘    └──────┬───────┘    └───────┬───────┘  │
│                         │                    │           │
│                         ▼                    ▼           │
│              ┌─────────────────────────┐                 │
│              │     B&B Tree Search     │                 │
│              │                         │                 │
│              │  Node Selection         │                 │
│              │  ├── best_first         │                 │
│              │  └── depth_first        │                 │
│              │                         │                 │
│              │  Branching Strategy     │                 │
│              │  ├── most_fractional    │                 │
│              │  └── strong_branching   │                 │
│              │                         │                 │
│              │  At each node:          │                 │
│              │  1. Solve LP relaxation │                 │
│              │     (InternalSimplex    │                 │
│              │      with warm-start)   │                 │
│              │  2. Check fathom        │                 │
│              │  3. Record snapshot     │                 │
│              │  4. Branch or cut       │                 │
│              └─────────────────────────┘                 │
│                         │                                │
│                         ▼                                │
│              ┌─────────────────────┐                     │
│              │     SolveState      │                     │
│              │  (MIP solution +    │                     │
│              │   full B&B trace)   │                     │
│              └─────────────────────┘                     │
└─────────────────────────────────────────────────────────┘

LP relaxation solver: InternalSimplex (reuses B^-1 for warm-start between nodes)
"""


# ============================================================
# 2. Public API
# ============================================================

API = """
# Module: clara/engine/bnb.py

class InternalBnB:
    '''Branch-and-Cut MIP solver with full explainability.

    Uses InternalSimplex as LP sub-solver at each B&B node.
    Records every branching decision for step-by-step explanation.
    '''

    def __init__(
        self,
        node_selection: str = "best_first",     # "best_first" | "depth_first"
        branching: str = "strong",               # "most_fractional" | "strong"
        enable_cuts: bool = True,                # Gomory GMI cuts at root
        max_cuts_rounds: int = 10,               # max cut rounds at root node
        max_nodes: int = 100_000,                # node limit
        max_time: float = 300.0,                 # time limit (seconds)
        gap_tolerance: float = 1e-6,             # relative MIP gap for termination
        int_tolerance: float = 1e-6,             # integrality tolerance
    ):
        ...

    def solve(self, problem: LPProblem) -> SolveState:
        '''Solve a MIP and return SolveState with B&B trace.

        If problem has no integer/binary variables, falls back to
        InternalSimplex directly (pure LP).

        SolveState fields:
            status: OPTIMAL, INFEASIBLE, UNBOUNDED, NODE_LIMIT, TIME_LIMIT
            optimal_value: best integer-feasible objective
            variables: solution values (integer vars rounded)
            constraints: dual values from final LP relaxation
            sensitivity: from final LP relaxation at optimal node
            basis_inverse: from final LP relaxation
            iteration_history: LP iterations at root node
            bnb_history: tuple[BnBNodeSnapshot, ...] ← FULL TREE TRACE
            engine: EngineType.INTERNAL_BNB
        '''

    # Read-only properties for intermediate state (useful for streaming/TUI)
    @property
    def incumbent_value(self) -> float | None: ...
    @property
    def best_bound(self) -> float: ...
    @property
    def gap(self) -> float: ...
    @property
    def nodes_explored(self) -> int: ...
    @property
    def nodes_remaining(self) -> int: ...
"""


# ============================================================
# 3. Presolve
# ============================================================

PRESOLVE = """
Basic presolve techniques (applied before root LP):

1. Fixed variables
   - If lower_bound == upper_bound: substitute out, reduce problem size
   - Binary variables with implied bounds from constraints

2. Dominated constraints
   - Remove constraints that are implied by others
   - Example: if x1 <= 10 and x1 <= 20, remove the latter

3. Bound tightening
   - For each constraint, tighten variable bounds using coefficient analysis
   - Example: 2x1 + 3x2 <= 10, x1,x2 >= 0 → x1 <= 5, x2 <= 3.33
   - For integer variables, round bounds: x1 <= 5.7 → x1 <= 5

4. Probing (binary variables only)
   - Fix binary var to 0 or 1, propagate implications
   - If fixing to 0 causes infeasibility → var must be 1 (and vice versa)
   - If fixing to 0 tightens bounds on other vars → record implications

Implementation:
    class Presolver:
        def presolve(self, problem: LPProblem) -> tuple[LPProblem, PresolveInfo]:
            '''Return reduced problem and info needed to recover original solution.'''

        def postsolve(self, state: SolveState, info: PresolveInfo) -> SolveState:
            '''Map reduced solution back to original problem variables.'''

    @dataclass(frozen=True)
    class PresolveInfo:
        fixed_vars: dict[str, float]          # variable_name → fixed_value
        removed_constraints: list[str]         # constraint names removed
        tightened_bounds: dict[str, tuple[float, float]]  # var → (new_lb, new_ub)
        original_problem: LPProblem            # for postsolve

Explainability:
    Presolve results are recorded and can be explained:
    "Presolve fixed 3 variables, tightened 5 bounds, removed 2 redundant constraints.
     Problem reduced from 20 vars × 15 constraints to 17 vars × 13 constraints."
"""


# ============================================================
# 4. Gomory Mixed Integer (GMI) Cuts
# ============================================================

GOMORY_CUTS = """
Applied at root node (cut-and-branch strategy).

Theory:
    Given optimal LP basis B with B^-1 * b = x_B (basic solution).
    For basic variable x_{B_i} that should be integer but has fractional value:
        b̄_i = (B^-1 * b)_i,  f_0 = b̄_i - floor(b̄_i)
        For each non-basic variable j:
            ā_ij = (B^-1 * N)_ij,  f_j = ā_ij - floor(ā_ij)

    GMI cut:
        For integer non-basic vars:
            if f_j <= f_0:  coeff = f_j / f_0
            else:           coeff = (1 - f_j) / (1 - f_0)
        For continuous non-basic vars:
            if ā_ij >= 0:   coeff = ā_ij / f_0
            else:           coeff = -ā_ij / (1 - f_0)

        sum(coeff_j * x_j for j in non-basic) >= 1

Implementation:
    class GomoryCutGenerator:
        def __init__(self, max_rounds: int = 10, min_violation: float = 1e-4):
            ...

        def generate_cuts(
            self,
            state: SolveState,
            problem: LPProblem,
        ) -> list[GomoryCut]:
            '''Generate GMI cuts from current LP optimal basis.

            Requires state.basis_inverse (InternalSimplex only).
            Returns list of cuts, most violated first.
            '''

        def select_cuts(
            self,
            cuts: list[GomoryCut],
            max_cuts: int = 20,
        ) -> list[GomoryCut]:
            '''Select subset of cuts to add (avoid numerical issues).

            Selection criteria:
                1. Violation (how much the current solution violates the cut)
                2. Sparsity (sparser cuts are numerically more stable)
                3. Orthogonality (diverse cuts are better than parallel ones)
            '''

    @dataclass(frozen=True)
    class GomoryCut:
        source_row: int                 # which fractional basic var generated this
        source_var: str                 # name of the fractional variable
        coefficients: dict[str, float]  # variable_name → coefficient
        rhs: float                      # right-hand side
        violation: float                # how much current LP solution violates
        fractionality: float            # f_0 = b̄_i - floor(b̄_i)

Cut loop at root:
    1. Solve root LP relaxation
    2. If integer feasible → done
    3. Generate GMI cuts from fractional basic variables
    4. Select best cuts (max 20 per round)
    5. Add cuts to problem as new constraints
    6. Re-solve LP (warm-start from current basis)
    7. Repeat until:
       - No more violated cuts found, or
       - Improvement < 0.1% per round, or
       - max_rounds reached

Explainability:
    Each cut is recorded with its source:
    "Cut 1: Generated from x3 (value = 2.67, fractional part = 0.67).
     Tightened LP bound from 156.3 to 152.8 (2.2% improvement)."
"""


# ============================================================
# 5. Branching Strategies
# ============================================================

BRANCHING = """
Strategy 1: Most Fractional
    Select the integer variable whose LP value is closest to 0.5
    (i.e., most fractional = hardest to round).

    score(x_j) = 0.5 - |x_j - floor(x_j) - 0.5|

    Pros: O(n) — fast
    Cons: Often poor in practice (ignores objective impact)

Strategy 2: Strong Branching
    For each candidate integer variable with fractional LP value:
        1. Temporarily branch down: add x_j <= floor(x_j), solve LP
        2. Temporarily branch up: add x_j >= ceil(x_j), solve LP
        3. Score = min(down_degradation, up_degradation) × max(down_degradation, up_degradation)
           (product score, as used in SCIP)
    Select the variable with the highest score.

    Pros: Much better branching decisions → smaller trees
    Cons: O(n × LP_solve) per node — expensive
    Mitigation: limit candidates to top-k most fractional (k=10)

Implementation:
    class BranchingStrategy(ABC):
        @abstractmethod
        def select_variable(
            self,
            state: SolveState,
            problem: LPProblem,
            integer_vars: set[int],
        ) -> BranchDecision: ...

    class MostFractional(BranchingStrategy): ...
    class StrongBranching(BranchingStrategy):
        def __init__(self, max_candidates: int = 10): ...

    @dataclass(frozen=True)
    class BranchDecision:
        variable: str
        variable_index: int
        current_value: float
        branch_down: float         # floor(current_value)
        branch_up: float           # ceil(current_value)
        score: float
        strategy: str              # "most_fractional" | "strong"
        # Strong branching only:
        down_bound: float | None = None   # LP bound after branching down
        up_bound: float | None = None     # LP bound after branching up

Explainability:
    "Branching on x3 (value = 2.67, score = 12.45).
     Strong branching: down (x3 ≤ 2) → bound 148.2, up (x3 ≥ 3) → bound 151.5.
     Down branch degrades more → likely to be pruned sooner."
"""


# ============================================================
# 6. Node Selection Strategies
# ============================================================

NODE_SELECTION = """
Strategy 1: Best-First (Best Bound)
    Always explore the node with the best LP relaxation bound.
    For MAX: highest upper bound. For MIN: lowest lower bound.

    Pros: Finds optimal solution with fewer nodes (tighter bound)
    Cons: Memory-heavy (stores many open nodes), incumbent found late

Strategy 2: Depth-First
    Always explore the most recently created child node (LIFO).
    Backtrack when fathomed.

    Pros: Memory-efficient, finds incumbent fast (good for feasibility)
    Cons: May explore many nodes before proving optimality

Implementation:
    class NodeQueue(ABC):
        @abstractmethod
        def push(self, node: BnBNode) -> None: ...
        @abstractmethod
        def pop(self) -> BnBNode: ...
        @abstractmethod
        def __len__(self) -> int: ...

    class BestFirstQueue(NodeQueue):
        '''Priority queue ordered by LP relaxation bound.'''
        # Uses heapq internally

    class DepthFirstQueue(NodeQueue):
        '''Stack (LIFO) for depth-first traversal.'''
        # Uses list as stack

    @dataclass
    class BnBNode:
        node_id: int
        parent_id: int | None
        depth: int
        lp_bound: float                    # LP relaxation bound at this node
        added_constraints: list[tuple[str, str, float]]
            # (var_name, sense, rhs) — branching constraints accumulated
        warm_start_basis: dict | None      # basis from parent for warm-start
"""


# ============================================================
# 7. Main B&B Loop
# ============================================================

MAIN_LOOP = """
def _branch_and_bound(self, problem: LPProblem) -> SolveState:

    # --- Phase 0: Presolve ---
    reduced, presolve_info = self.presolver.presolve(problem)

    # --- Phase 1: Root node ---
    root_state = self.lp_solver.solve(reduced)
    if not root_state.is_optimal:
        return root_state  # infeasible or unbounded

    # Check if already integer feasible
    if self._is_integer_feasible(root_state, reduced):
        return self.presolver.postsolve(root_state, presolve_info)

    # --- Phase 2: Root cuts ---
    if self.enable_cuts:
        root_state = self._cut_loop(root_state, reduced)
        if self._is_integer_feasible(root_state, reduced):
            return self.presolver.postsolve(root_state, presolve_info)

    # --- Phase 3: B&B tree search ---
    incumbent: SolveState | None = None
    incumbent_value = float('-inf')  # for MAX; float('inf') for MIN
    best_bound = root_state.optimal_value

    queue = self._make_queue()
    root_node = BnBNode(node_id=0, parent_id=None, depth=0,
                        lp_bound=root_state.optimal_value,
                        added_constraints=[], warm_start_basis=None)
    queue.push(root_node)
    snapshots = []

    while len(queue) > 0:
        # Check limits
        if self.nodes_explored >= self.max_nodes:
            break  # NODE_LIMIT
        if elapsed > self.max_time:
            break  # TIME_LIMIT

        node = queue.pop()

        # Pruning: if node bound is worse than incumbent, skip
        if incumbent and self._bound_prune(node, incumbent_value):
            snapshots.append(self._make_snapshot(node, "fathomed_by_bound"))
            continue

        # Solve LP relaxation at this node
        node_problem = self._apply_branch_constraints(reduced, node)
        node_state = self.lp_solver.solve(node_problem, warm_start=node.warm_start_basis)

        self.nodes_explored += 1

        # Fathom checks
        if not node_state.is_optimal:
            snapshots.append(self._make_snapshot(node, "fathomed_infeasible"))
            continue

        if incumbent and self._bound_prune_state(node_state, incumbent_value):
            snapshots.append(self._make_snapshot(node, "fathomed_by_bound"))
            continue

        if self._is_integer_feasible(node_state, reduced):
            if node_state.optimal_value > incumbent_value:  # MAX
                incumbent = node_state
                incumbent_value = node_state.optimal_value
                snapshots.append(self._make_snapshot(node, "new_incumbent",
                                                     incumbent_value=incumbent_value))
                # Prune nodes worse than new incumbent
                queue = self._prune_queue(queue, incumbent_value)
            continue

        # Branch
        decision = self.branching.select_variable(node_state, reduced,
                                                   reduced.integer_vars)
        snapshots.append(self._make_snapshot(node, "branched",
                                             branch_decision=decision))

        # Create child nodes
        down_node = BnBNode(
            node_id=self._next_id(),
            parent_id=node.node_id,
            depth=node.depth + 1,
            lp_bound=node_state.optimal_value,
            added_constraints=node.added_constraints + [
                (decision.variable, "<=", decision.branch_down)
            ],
            warm_start_basis=self._extract_basis(node_state),
        )
        up_node = BnBNode(
            node_id=self._next_id(),
            parent_id=node.node_id,
            depth=node.depth + 1,
            lp_bound=node_state.optimal_value,
            added_constraints=node.added_constraints + [
                (decision.variable, ">=", decision.branch_up)
            ],
            warm_start_basis=self._extract_basis(node_state),
        )
        queue.push(down_node)
        queue.push(up_node)

        # Update best bound
        best_bound = self._compute_best_bound(queue, incumbent_value)

        # Check gap
        if incumbent and self._gap_closed(incumbent_value, best_bound):
            break

    # --- Build final SolveState ---
    status = self._determine_status(incumbent, ...)
    final_state = self._build_solve_state(
        incumbent, snapshots, reduced, presolve_info
    )
    return final_state
"""


# ============================================================
# 8. BnBNodeSnapshot (Explainability)
# ============================================================

NODE_SNAPSHOT = """
Already defined in solve_state_design.py. Here's how it's populated:

    @dataclass(frozen=True)
    class BnBNodeSnapshot:
        node_id: int
        parent_id: int | None
        depth: int
        branching_var: str
        branching_direction: str        # "<=", ">="
        branching_value: float
        lp_relaxation_value: float
        is_integer_feasible: bool
        is_fathomed: bool
        fathom_reason: str | None       # "bound", "infeasible", "integer_feasible"
        incumbent_value: float | None

    Additional fields for practical B&B (extend the existing dataclass):
        branching_score: float          # score from branching strategy
        branching_strategy: str         # "most_fractional" | "strong"
        num_fractional: int             # fractional integer vars at this node
        gap_at_node: float              # (best_bound - incumbent) / |incumbent|
        cuts_added: int                 # cuts added at this node (root only typically)
        lp_iterations: int              # simplex iterations to solve this node's LP

Explainer generates tree-level explanation:
    "B&B tree explored 47 nodes (23 pruned by bound, 8 infeasible, 3 integer-feasible).
     Optimal solution found at node 15 (depth 4): objective = 152.
     Strong branching on x3 at root (score 12.45) was the key decision —
     the down branch (x3 ≤ 2) was pruned immediately, saving 40% of the tree.
     5 Gomory cuts at root tightened the bound from 156.3 to 153.1 (2.0% gap closed)."
"""


# ============================================================
# 9. Module Structure
# ============================================================

MODULE_STRUCTURE = """
clara/engine/
├── base.py                  # SolveEngine interface (existing)
├── simplex.py               # InternalSimplex (existing)
├── highs_backend.py         # HiGHS backend (existing)
├── bnb.py                   # InternalBnB (main orchestrator)
├── branching.py             # BranchingStrategy, MostFractional, StrongBranching
├── node_selection.py        # NodeQueue, BestFirstQueue, DepthFirstQueue
├── cuts.py                  # GomoryCutGenerator, GomoryCut
└── presolve.py              # Presolver, PresolveInfo

clara/explain/
├── ... (existing)
└── bnb_report.py            # B&B-specific explanation generator (NEW)

tests/
├── test_bnb.py              # Main B&B tests
├── test_branching.py        # Branching strategy tests
├── test_cuts.py             # Gomory cut tests
├── test_presolve.py         # Presolve tests
└── fixtures/
    ├── ... (existing LP fixtures)
    ├── knapsack_small.lp     # 5 items, binary (NEW)
    ├── knapsack_medium.lp    # 20 items, binary (NEW)
    ├── facility_small.lp     # 3 facilities, 5 clients (NEW)
    └── assignment_small.lp   # 4×4 assignment (NEW)
"""


# ============================================================
# 10. MIP Test Fixtures
# ============================================================

TEST_FIXTURES = """

--- knapsack_small.lp ---
5-item 0-1 knapsack. LP relaxation has fractional solution.

  Maximize
    obj: 16 x1 + 22 x2 + 12 x3 + 8 x4 + 11 x5
  Subject To
    weight: 5 x1 + 7 x2 + 4 x3 + 3 x4 + 4 x5 <= 14
  Binary
    x1 x2 x3 x4 x5
  End

  LP relaxation: 44.0 (x1=1, x2=1, x3=0.5, x4=0, x5=0)
  MIP optimal: 42.0 (x1=0, x2=1, x3=1, x4=1, x5=0)
  LP-MIP gap: 4.76%
  Good test: fractional x3 at root, branching changes solution structure entirely.


--- assignment_small.lp ---
4×4 assignment problem (minimize).
Cost matrix:
    Task1  Task2  Task3  Task4
W1    9      2      7      8
W2    6      4      3      7
W3    5      8      1      8
W4    7      6      9      4

  Minimize
    obj: 9 x11 + 2 x12 + 7 x13 + 8 x14
       + 6 x21 + 4 x22 + 3 x23 + 7 x24
       + 5 x31 + 8 x32 + 1 x33 + 8 x34
       + 7 x41 + 6 x42 + 9 x43 + 4 x44
  Subject To
    w1: x11 + x12 + x13 + x14 = 1
    w2: x21 + x22 + x23 + x24 = 1
    w3: x31 + x32 + x33 + x34 = 1
    w4: x41 + x42 + x43 + x44 = 1
    t1: x11 + x21 + x31 + x41 = 1
    t2: x12 + x22 + x32 + x42 = 1
    t3: x13 + x23 + x33 + x43 = 1
    t4: x14 + x24 + x34 + x44 = 1
  Binary
    x11 x12 x13 x14 x21 x22 x23 x24 x31 x32 x33 x34 x41 x42 x43 x44
  End

  LP relaxation = MIP optimal = 13 (totally unimodular)
  Assignment: W1→T2(2), W2→T1(6), W3→T3(1), W4→T4(4)
  Good test: B&B should detect integrality at root without branching.


--- facility_small.lp ---
Capacitated facility location: 3 facilities, 5 clients.
Binary y_i (open facility), continuous x_ij (serve fraction).
Fixed costs: [20, 25, 18], capacities: [3, 2, 3].

  Minimize
    obj: 20 y1 + 25 y2 + 18 y3
       + 4 x11 + 6 x12 + 9 x13 + 8 x14 + 7 x15
       + 6 x21 + 3 x22 + 7 x23 + 4 x24 + 5 x25
       + 5 x31 + 7 x32 + 3 x33 + 6 x34 + 4 x35
  Subject To
    [demand constraints: sum_i x_ij = 1 for each j]
    [linking constraints: x_ij - y_i <= 0 for each i,j]
    [capacity constraints: sum_j x_ij - cap_i * y_i <= 0 for each i]
  Bounds
    [all vars in [0, 1]]
  Binary
    y1 y2 y3
  End

  LP relaxation: 56.33 (y1=0.67, y2=0, y3=1)
  MIP optimal: 61 (y1=1, y3=1; fac1 serves {1,2}, fac3 serves {3,4,5})
  LP-MIP gap: 7.65%
  Good test: mixed integer (binary + continuous), fractional y at root,
  needs branching on y1 to determine which facilities to open.
"""


# ============================================================
# 11. Test Cases
# ============================================================

TEST_CASES = """
tests/test_bnb.py

1. Pure LP fallback
   - test_pure_lp_uses_simplex         → no integer vars → delegates to simplex
   - test_pure_lp_matches_simplex      → same optimal value as InternalSimplex

2. Root node
   - test_root_lp_relaxation           → root LP bound computed correctly
   - test_root_integer_feasible        → assignment problem solved at root (TU)
   - test_root_fractional              → knapsack has fractional root

3. Gomory cuts
   - test_cuts_tighten_bound           → root bound improves after cuts
   - test_cuts_no_violation_stops      → loop terminates when no more cuts
   - test_cuts_disabled                → enable_cuts=False skips cut phase
   - test_cut_is_valid                 → cut does not remove integer-feasible points
   - test_gomory_formula               → verify GMI formula on known tableau

4. Branching
   - test_most_fractional_selects      → picks variable closest to 0.5
   - test_strong_branching_selects     → picks variable with best score
   - test_strong_better_tree           → strong branching explores fewer nodes

5. Node selection
   - test_best_first_order             → nodes explored in bound order
   - test_depth_first_order            → nodes explored LIFO
   - test_best_first_fewer_nodes       → typically explores fewer nodes

6. Fathoming
   - test_fathom_by_bound              → node LP bound worse than incumbent
   - test_fathom_infeasible            → node LP is infeasible
   - test_fathom_integer_feasible      → node LP is already integer → new incumbent

7. Optimality
   - test_knapsack_small_optimal       → correct MIP optimal value
   - test_facility_small_optimal       → correct MIP optimal
   - test_gap_zero_at_termination      → gap = 0 when optimal

8. Limits
   - test_node_limit                   → stops at max_nodes, returns best incumbent
   - test_time_limit                   → stops at max_time
   - test_status_node_limit            → status = NODE_LIMIT

9. Explainability
   - test_bnb_history_recorded         → bnb_history is not None
   - test_bnb_history_has_root         → node_id=0 exists
   - test_snapshot_fields_populated    → all BnBNodeSnapshot fields present
   - test_tree_is_connected            → every node's parent_id exists (except root)

10. Cross-validation with HiGHS
    - test_knapsack_matches_highs      → Internal B&B optimal = HiGHS optimal
    - test_facility_matches_highs      → same

11. CLI integration
    - test_clara_explain_mip           → clara explain knapsack.lp works
    - test_clara_explain_mip_json      → JSON output has bnb_report section

tests/test_branching.py
    - test_most_fractional_score       → score = 0.5 for value 2.5
    - test_most_fractional_tiebreak    → deterministic tiebreak (lowest index)
    - test_strong_score_product        → score = min(d,u) * max(d,u)
    - test_strong_candidates_limit     → only evaluates top-k candidates

tests/test_cuts.py
    - test_gomory_from_known_tableau   → verify against hand-computed cut
    - test_cut_valid_for_integers      → cut satisfied by all integer points
    - test_cut_violates_lp_solution    → current LP optimum violates the cut
    - test_cut_selection_violation     → most violated cuts selected first
    - test_cut_selection_sparsity      → sparser cuts preferred
    - test_numerical_stability         → no cuts with very small coefficients

tests/test_presolve.py
    - test_fixed_var_removed           → fixed variable substituted out
    - test_bound_tightening            → integer bounds rounded
    - test_postsolve_recovers          → solution mapped back to original vars
    - test_presolve_preserves_optimal  → optimal value unchanged
"""


# ============================================================
# 12. CLI Updates
# ============================================================

CLI_UPDATES = """
clara explain now auto-detects MIP:
  - If problem has integer/binary vars → use InternalBnB
  - If pure LP → use InternalSimplex (as before)
  - --engine internal: auto-detect LP vs MIP
  - --engine highs: use HiGHS for both LP and MIP

New explain output for MIP includes B&B report section:

  ═══════════════════════════════════════════════════
  CLARA — knapsack_small
  Optimal value: 65 (OPTIMAL)
  MIP gap: 0.00%
  47 nodes explored, 0.12s (INTERNAL_BNB)
  ═══════════════════════════════════════════════════

  BRANCH-AND-BOUND SUMMARY
  ─────────────────────────────────────────────────
  Root LP relaxation: 82.857
  Root bound after 5 Gomory cuts: 78.333 (5.5% gap closed)
  Nodes explored: 47 (23 pruned by bound, 8 infeasible)
  Best solution found at node 15 (depth 4)
  Branching strategy: strong branching

  [Then existing Binding / Variable / Sensitivity reports for the MIP solution]

JSON output adds:
  "bnb_report": {
    "root_lp_bound": 82.857,
    "root_bound_after_cuts": 78.333,
    "cuts_generated": 5,
    "nodes_explored": 47,
    "nodes_pruned_bound": 23,
    "nodes_infeasible": 8,
    "nodes_integer_feasible": 3,
    "incumbent_found_at_node": 15,
    "branching_strategy": "strong",
    "node_selection": "best_first",
    "gap": 0.0
  }
"""


# ============================================================
# 13. Implementation Order for Claude Code
# ============================================================

IMPLEMENTATION_ORDER = """
Claude Code should implement in this order:

1. git checkout -b feat/bnb-engine

2. MIP test fixtures
   - Create knapsack_small.lp, facility_small.lp, assignment_small.lp
   - Verify with HiGHS (scipy) for ground-truth optimal values
   - Commit: "test: add MIP test fixtures"

3. Presolve (clara/engine/presolve.py)
   - Fixed variable elimination + bound tightening + postsolve
   - tests/test_presolve.py
   - Commit: "feat: basic MIP presolve"

4. Gomory cuts (clara/engine/cuts.py)
   - GMI cut generation from B^-1 + selection
   - tests/test_cuts.py
   - Commit: "feat: Gomory mixed integer cuts"

5. Branching strategies (clara/engine/branching.py)
   - MostFractional + StrongBranching
   - tests/test_branching.py
   - Commit: "feat: branching strategies (most fractional + strong)"

6. Node selection (clara/engine/node_selection.py)
   - BestFirstQueue + DepthFirstQueue
   - Commit: "feat: node selection strategies"

7. Main B&B engine (clara/engine/bnb.py)
   - Full loop integrating presolve + cuts + branching + node selection
   - tests/test_bnb.py
   - Commit: "feat: Branch-and-Cut MIP solver"

8. B&B explainer (clara/explain/bnb_report.py)
   - Tree summary, cut report, branching analysis
   - Commit: "feat: B&B explanation report"

9. CLI update (clara/cli.py)
   - Auto-detect LP vs MIP
   - B&B report in explain output
   - Commit: "feat: CLI MIP support"

10. Cross-validation with HiGHS
    - tests/test_cross_validation.py (add MIP cases)
    - Commit: "test: MIP cross-validation with HiGHS"

11. Final: pytest full suite, update CLAUDE.md
    - Commit: "docs: update CLAUDE.md for Phase 1.5 B&B"
"""