"""
CLARA — MPS Parser Design Specification
=========================================

Implements an MPS file format parser that converts .mps files into LPProblem.
Supports both fixed format (Netlib originals) and free format (HiGHS output).

MPS is column-oriented (unlike LP which is row-oriented).
Variable names have no restrictions — dots, numbers, any characters allowed.
This is the key reason for implementing MPS natively instead of LP conversion.

Output: same LPProblem dataclass as LP parser → all downstream code works unchanged.

Branch: feat/mps-parser
"""


# ============================================================
# 1. MPS Format Sections
# ============================================================

SECTIONS = """
Sections in order:

NAME        problem name (optional, single line)
OBJSENSE    MIN or MAX (optional, default MIN)
ROWS        constraint types and names
COLUMNS     variable coefficients (column-oriented)
RHS         right-hand side values
RANGES      range constraints (optional — support but rarely used)
BOUNDS      variable bounds (optional)
ENDATA      end of file

Comments: lines starting with * are ignored.
"""


# ============================================================
# 2. Format: Fixed vs Free
# ============================================================

FORMAT = """
Fixed format (Netlib originals):
    Field 1: columns 2-3   (indicator/type)
    Field 2: columns 5-12  (name)
    Field 3: columns 15-22 (name)
    Field 4: columns 25-36 (value)
    Field 5: columns 40-47 (name)
    Field 6: columns 50-61 (value)

Free format (HiGHS output, modern solvers):
    Fields separated by whitespace, no column restrictions.
    Names can be longer than 8 characters.

Auto-detection strategy:
    Try free format first (split by whitespace).
    MPS files from Netlib work with whitespace splitting too,
    as long as names don't contain spaces (they don't in practice).
    So free-format parsing handles both cases.
"""


# ============================================================
# 3. Section Parsing Details
# ============================================================

PARSING = """
### ROWS section
    Each line: TYPE  ROW_NAME
    Types:
        N  → objective function (first N row is the objective)
        L  → <= constraint
        G  → >= constraint
        E  → = constraint

    Multiple N rows: first one is objective, rest are free rows (ignored).

### COLUMNS section
    Each line: COL_NAME  ROW_NAME  VALUE  [ROW_NAME  VALUE]
    (one or two coefficients per line)

    Variables are discovered in order of first appearance.
    A variable can appear on multiple lines.
    Duplicate entries for same (col, row) are ADDED together.

    Integer markers:
        MARKER_NAME  'MARKER'  'INTORG'   → start integer section
        MARKER_NAME  'MARKER'  'INTEND'   → end integer section
        Variables between markers are integer.

### RHS section
    Each line: RHS_NAME  ROW_NAME  VALUE  [ROW_NAME  VALUE]
    RHS_NAME is ignored (use first RHS vector).
    Rows not mentioned have RHS = 0.

### RANGES section (optional)
    Each line: RNG_NAME  ROW_NAME  VALUE  [ROW_NAME  VALUE]
    A range r on row i means:
        For L row: b_i - |r| <= a_i^T x <= b_i
        For G row: b_i <= a_i^T x <= b_i + |r|
        For E row: b_i - |r|/2 <= a_i^T x <= b_i + |r|/2  (less common)

    Implementation: convert range constraints to two <= constraints.
    If RANGES section is complex, log a warning and handle best-effort.

### BOUNDS section (optional)
    Each line: TYPE  BND_NAME  COL_NAME  [VALUE]
    BND_NAME is ignored (use first bound vector).

    Types:
        LO  → lower bound: lb = VALUE
        UP  → upper bound: ub = VALUE
        FX  → fixed: lb = ub = VALUE
        FR  → free: lb = -inf, ub = +inf
        MI  → minus infinity lower: lb = -inf (ub stays at +inf or as set)
        PL  → plus infinity upper: ub = +inf (default, rarely explicit)
        BV  → binary: lb = 0, ub = 1, integer
        LI  → integer lower bound: lb = VALUE, marks as integer
        UI  → integer upper bound: ub = VALUE, marks as integer

    Default (no BOUNDS): 0 <= x <= +inf for all variables.

### OBJSENSE section (optional)
    Single line after NAME: MAX or MIN
    Default: MIN (standard MPS convention)
"""


# ============================================================
# 4. LPProblem Mapping
# ============================================================

MAPPING = """
MPS → LPProblem conversion:

    .name              ← NAME section or filename stem
    .c                 ← coefficients from the N-type row
    .A                 ← coefficient matrix (only L, G, E rows)
    .b                 ← RHS values for constraints

    >= constraints (G rows): negate row → -a_i^T x <= -b_i
    = constraints (E rows): keep as-is for LPProblem
        Note: LPProblem currently uses Ax <= b form.
        For = constraints, Internal Simplex handles via Big-M Phase I.
        Store as <= with both the row and its negation, OR
        add support for A_eq/b_eq in LPProblem.

    Actually, looking at the existing code:
        - LP parser converts >= to <= by negation
        - Internal Simplex handles = via Big-M
        - LPProblem has A (for <=) only, no A_eq
        → Follow same pattern: >= rows negated, = rows handled by Big-M

    .var_names         ← column names from COLUMNS section (order of appearance)
    .constraint_names  ← row names from ROWS section (excluding N rows)
    .lower_bounds      ← from BOUNDS section (default 0)
    .upper_bounds      ← from BOUNDS section (default +inf)
    .integer_vars      ← from INTORG/INTEND markers or LI/UI/BV bounds
    .binary_vars       ← from BV bounds

    Objective sense:
        MPS default is minimize. LPProblem/Internal Simplex is maximize.
        If MIN: negate c (c *= -1) and note the negation.
        Store original sense so we can negate the optimal value back.

        Option A: negate c at parse time, negate optimal value at output
        Option B: add sense field to LPProblem, let engine handle it

        Option A is simpler and consistent with how LP parser handles it.
        But we need to un-negate the optimal value in Explainer/CLI output.

        Better: Option B — add 'sense' field to LPProblem.
        Then engine can check: if sense == 'minimize', negate c internally.
        This is cleaner for the user (they see the original objective).

    → Add to LPProblem:
        sense: str = "maximize"  # "maximize" or "minimize"

    → Update Internal Simplex to check problem.sense:
        if problem.sense == "minimize":
            self.c_full[:n] = -problem.c  # negate internally
            # After solving, negate optimal_value back

    → HiGHS backend already supports both senses via:
        h.changeObjectiveSense(highspy.ObjSense.kMinimize)
"""


# ============================================================
# 5. Public API
# ============================================================

API = """
# Module: clara/io/mps_parser.py

def read_mps(filepath: str | Path) -> LPProblem:
    '''Read an MPS file and return an LPProblem instance.

    Supports both fixed and free format MPS.
    Auto-detects OBJSENSE (default: minimize).
    '''

def parse_mps(content: str, name: str = "unnamed") -> LPProblem:
    '''Parse MPS format string and return an LPProblem instance.'''

class MPSParseError(Exception):
    '''Raised for MPS file syntax errors.'''
    def __init__(self, message: str, line_number: int | None = None): ...

# Re-export from clara/io/__init__.py:
from clara.io.mps_parser import read_mps, parse_mps, MPSParseError
"""


# ============================================================
# 6. CLI Integration
# ============================================================

CLI_INTEGRATION = """
Update clara/cli.py _parse_file():

    def _parse_file(filepath: str):
        path = Path(filepath)
        if path.suffix.lower() == ".mps":
            from clara.io.mps_parser import read_mps, MPSParseError
            try:
                return read_mps(filepath)
            except MPSParseError as e:
                click.secho(f"MPS parse error: {e}", fg="red", err=True)
                sys.exit(1)
        else:
            # existing LP parsing
            ...

Now all CLI commands work with .mps files:
    clara explain problem.mps
    clara solve problem.mps
    clara info problem.mps
    clara diff old.mps new.mps
"""


# ============================================================
# 7. LPProblem.sense Field Addition
# ============================================================

LPPROBLEM_SENSE = """
Add to clara/model/problem.py:

    @dataclass
    class LPProblem:
        c: np.ndarray
        A: np.ndarray
        b: np.ndarray
        var_names: list[str] = field(default_factory=list)
        constraint_names: list[str] = field(default_factory=list)
        name: str = ""
        sense: str = "maximize"          # NEW: "maximize" or "minimize"
        lower_bounds: np.ndarray | None = None
        upper_bounds: np.ndarray | None = None
        integer_vars: set[int] = field(default_factory=set)
        binary_vars: set[int] = field(default_factory=set)

Default "maximize" preserves backward compatibility with all existing code.
LP parser sets sense based on Minimize/Maximize keyword (it may already do this).
MPS parser sets sense from OBJSENSE section (default "minimize").

Update Internal Simplex to handle minimize:
    if problem.sense == "minimize":
        self.c_full[:n] = -problem.c
    else:
        self.c_full[:n] = problem.c

    # After solving, in _make_state():
    if self.problem.sense == "minimize":
        optimal_value = -optimal_value  # un-negate

Update HiGHS backend:
    if problem.sense == "minimize":
        h.changeObjectiveSense(highspy.ObjSense.kMinimize)
    else:
        h.changeObjectiveSense(highspy.ObjSense.kMaximize)

This is the cleanest approach: parser stores original sense,
engines handle the conversion internally, user always sees correct values.
"""


# ============================================================
# 8. Benchmark Script Updates
# ============================================================

BENCHMARK_UPDATES = """
Update benchmarks/scripts/run_benchmark.py:
    - Remove MPS→LP conversion step
    - Read .mps files directly: read_mps("benchmarks/netlib/afiro.mps")
    - convert_mps_to_lp.py becomes unnecessary (can be deleted or kept as utility)

Update benchmarks/scripts/download_netlib.py:
    - Download MPS files to benchmarks/netlib/ (no /mps/ subdirectory needed)
    - Verify each file parses with read_mps()
"""


# ============================================================
# 9. Test Cases
# ============================================================

TEST_CASES = """
tests/test_mps_parser.py

1. Basic parsing
   - test_parse_simple_lp          → small handcrafted MPS, verify vars/cons/coefficients
   - test_parse_minimize           → OBJSENSE MIN, verify sense = "minimize"
   - test_parse_maximize           → OBJSENSE MAX, verify sense = "maximize"
   - test_parse_no_objsense        → default minimize
   - test_parse_named_problem      → NAME section parsed

2. Rows
   - test_rows_l_type              → L rows → <= constraints
   - test_rows_g_type              → G rows → negated to <= constraints
   - test_rows_e_type              → E rows → equality constraints
   - test_rows_n_type              → N row → objective
   - test_multiple_n_rows          → first N = objective, rest ignored

3. Columns
   - test_columns_basic            → coefficients extracted correctly
   - test_columns_two_per_line     → two (row, value) pairs on one line
   - test_columns_duplicate_add    → duplicate entries added together
   - test_variable_order           → order of first appearance preserved
   - test_integer_markers          → INTORG/INTEND → integer_vars populated

4. RHS
   - test_rhs_values               → RHS values assigned to correct constraints
   - test_rhs_missing_default_zero → constraints not in RHS get 0
   - test_rhs_two_per_line         → two entries per line

5. Bounds
   - test_bounds_lo                → lower bound
   - test_bounds_up                → upper bound
   - test_bounds_fx                → fixed variable
   - test_bounds_fr                → free variable (-inf, +inf)
   - test_bounds_mi                → minus infinity lower
   - test_bounds_bv                → binary → [0, 1] + binary_vars
   - test_bounds_li_ui             → integer bounds → integer_vars
   - test_bounds_default           → no BOUNDS section → [0, +inf]

6. Netlib instances (the main goal)
   - test_parse_afiro              → 32 vars, 27 constraints
   - test_parse_adlittle           → 97 vars, 56 constraints
   - test_parse_blend              → 83 vars, 74 constraints
   - test_parse_sc50a              → 48 vars, 50 constraints
   - test_parse_sc50b              → 48 vars, 50 constraints
   - test_parse_sc105              → 103 vars, 105 constraints
   - test_parse_kb2                → 41 vars, 43 constraints
   - test_parse_share2b            → 79 vars, 96 constraints

7. Cross-validation with HiGHS (via .mps)
   - test_afiro_internal_vs_highs  → same optimal value
   - test_sc50a_internal_vs_highs  → same optimal value
   - (for each parseable instance)

8. Minimize handling
   - test_minimize_simplex         → Internal Simplex handles minimize correctly
   - test_minimize_highs           → HiGHS handles minimize correctly
   - test_minimize_cross_match     → both give same result for minimize problem

9. Edge cases
   - test_comments_ignored         → lines starting with *
   - test_empty_rhs               → no RHS section → all zeros
   - test_names_with_dots          → "D3T...BW" style names (Netlib kb2)
   - test_names_with_numbers       → "1", "2" style names (Netlib blend)
   - test_names_three_dots         → "...100" style names (Netlib adlittle)
   - test_endata_required          → file without ENDATA → warning but still parse

10. CLI integration
    - test_clara_explain_mps       → clara explain afiro.mps works
    - test_clara_info_mps          → clara info afiro.mps shows correct var/con count
    - test_clara_diff_mps          → clara diff old.mps new.mps works
"""


# ============================================================
# 10. Module Structure
# ============================================================

MODULE_STRUCTURE = """
New files:
    clara/io/mps_parser.py           # MPS parser (read_mps, parse_mps, MPSParseError)
    tests/test_mps_parser.py         # all tests

Modified files:
    clara/model/problem.py           # add sense field to LPProblem
    clara/engine/simplex.py          # handle minimize (negate c, un-negate optimal)
    clara/engine/highs_backend.py    # use problem.sense for objective direction
    clara/engine/bnb.py              # pass through sense to simplex
    clara/io/__init__.py             # re-export read_mps, parse_mps
    clara/cli.py                     # auto-detect .lp vs .mps in _parse_file()
    benchmarks/scripts/run_benchmark.py  # read .mps directly
"""


# ============================================================
# 11. Implementation Order
# ============================================================

IMPLEMENTATION_ORDER = """
1. git checkout -b feat/mps-parser

2. Add sense field to LPProblem (clara/model/problem.py)
   - sense: str = "maximize" (backward compatible)
   - Commit: "feat: add sense field to LPProblem"

3. Update engines to handle minimize
   - simplex.py: negate c for minimize, un-negate optimal
   - highs_backend.py: use problem.sense for ObjSense
   - bnb.py: pass through (uses simplex internally)
   - Test: existing LP tests still pass (all maximize)
   - Commit: "feat: engines handle minimize problems"

4. Implement clara/io/mps_parser.py
   - _MPSParser class with section handlers
   - read_mps() / parse_mps() public API
   - Handle: ROWS, COLUMNS, RHS, BOUNDS, RANGES, OBJSENSE
   - Integer markers (INTORG/INTEND)
   - >= rows negated to <=
   - Commit: "feat: MPS file format parser"

5. CLI integration
   - Update _parse_file() for .mps auto-detection
   - Commit: "feat: CLI auto-detect .lp vs .mps"

6. Tests
   - tests/test_mps_parser.py — all cases above
   - Commit: "test: MPS parser tests including Netlib instances"

7. Benchmark script updates
   - Remove MPS→LP conversion, read .mps directly
   - Re-run benchmarks
   - Commit: "bench: update scripts to use MPS parser directly"

8. pytest full suite + CLAUDE.md update
   - Commit: "docs: update CLAUDE.md for MPS parser"
"""