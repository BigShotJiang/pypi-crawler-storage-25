"""Solver engine."""
