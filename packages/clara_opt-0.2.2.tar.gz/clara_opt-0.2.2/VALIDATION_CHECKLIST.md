# CLARA Paper-Code Validation Checklist

## Context
The CLARA paper (clara_cor.tex) makes specific claims about what the software does.
Before submission, every claim must be verified against the actual codebase.
This document lists each claim, where to find it in the paper, and what to check/implement in code.

Repository: clara-opt (PyPI: pip install clara-opt)
Paper: clara_cor.tex

---

## PRIORITY A: Claims that are FALSE if code doesn't match

### A1. Chebyshev LP includes OAT bounding box rows
**Paper claim (S4.3, Definition, eq:bounded_poly):**
```
H = [-B^{-1}; I_m; -I_m] ∈ R^{3m × m}
h = [x_B; α⁺; α⁻] ∈ R^{3m}
```
The paper explicitly states the Chebyshev LP uses 3m constraints (m primal + 2m box).

**Validation:**
1. Find the function that constructs H and h for the Chebyshev center LP
2. Check if it includes OAT box rows (I_m and -I_m) or only uses -B^{-1}
3. If missing: add OAT box rows. α⁺ and α⁻ should come from sensitivity ranges already computed in SolveState

**Expected location:** likely in `region.py` or `sensitivity.py` or similar module

---

### A2. Condition number κ(B) computation and warning
**Paper claim (S3 + S4.1):**
- "CLARA computes the condition number κ(B) and flags instances where numerical instability may affect downstream explanations"
- "When κ(B) exceeds a user-configurable threshold (default: 10^8), the explanation report includes a warning"

**Validation:**
1. Check if κ(B) is computed anywhere (np.linalg.cond or ||B|| * ||B^{-1}||)
2. Check if it's stored in SolveState or ExplanationReport
3. Check if threshold warning exists
4. If missing: add `condition_number` field to SolveState, compute during solve, add warning logic

**Implementation if missing:**
```python
# In solve or SolveState construction:
condition_number = np.linalg.cond(B)
# In explanation report:
if condition_number > threshold:
    warnings.append(f"Basis condition number {condition_number:.2e} exceeds threshold {threshold:.2e}")
```

---

### A3. Degeneracy diagnostics (3 items)
**Paper claim (S4.1, "Degeneracy diagnostics" paragraph):**
- "(i) the number of degenerate basic variables (x_{B_i} = 0 or below tolerance)"
- "(ii) the condition number κ(B)" (covered by A2)
- "(iii) a degeneracy flag on each constraint whose shadow price may be non-unique"

**Validation:**
1. Check if degenerate_count is computed
2. Check if per-constraint degeneracy flags exist
3. If missing: add to ExplanationReport

**Implementation if missing:**
```python
DEGEN_TOL = 1e-8
degenerate_mask = x_B < DEGEN_TOL
degenerate_count = int(np.sum(degenerate_mask))
# Flag constraints: if basic variable i is degenerate, constraint i's shadow price may be non-unique
```

---

### A4. Bland's rule for anti-cycling
**Paper claim (S5.3):**
"CLARA uses Bland's rule as an anti-cycling safeguard."

**Validation:**
1. Find the simplex pivot selection code (entering variable selection)
2. Check if Bland's rule is implemented (choose smallest-index variable with negative reduced cost)
3. If current code uses most-negative-reduced-cost (Dantzig's rule) only, either:
   a. Add Bland's rule option and set as default, OR
   b. Change paper to say "Dantzig's rule" (less desirable — Bland's is safer)

**Key distinction:**
- Dantzig: enter variable with most negative c̄_j (fastest but can cycle)
- Bland: enter variable with smallest index among negative c̄_j (slower but no cycling)

---

### A5. Basis robustness d₀ computation
**Paper claim (S4.4, Definition 5):**
```
d₀ = min_i (x_B)_i / ||(B^{-1})_{i,:}||_2
```
"computable in O(mn) time without solving any LP, directly from B^{-1} and x_B"

**Validation:**
1. Check if d₀ is computed anywhere in the codebase
2. Check if it's exposed in any result object (RegionResult, ExplanationReport, etc.)
3. If missing: implement and add to appropriate result

**Implementation if missing:**
```python
def basis_robustness(B_inv, x_B):
    row_norms = np.linalg.norm(B_inv, axis=1)
    # Avoid division by zero for zero rows
    safe_norms = np.where(row_norms > 1e-12, row_norms, np.inf)
    d0 = np.min(x_B / safe_norms)
    i_star = np.argmin(x_B / safe_norms)
    return d0, i_star
```

---

### A6. Nonlinearity measure η
**Paper claim (S4.2):**
"we define the nonlinearity measure η = |r| / |Δz| to quantify the extent of basis disruption"

**Validation:**
1. Check if η is computed in attribution code
2. Check if it's stored in AttributionResult or similar
3. If missing: compute residual after first-order decomposition, compute η

**Implementation if missing:**
```python
first_order = rhs_effect + obj_effect + interaction
residual = delta_z - first_order
eta = abs(residual) / abs(delta_z) if abs(delta_z) > 1e-12 else 0.0
```

---

### A7. Sensitivity classification (bottleneck/fragile/robust)
**Paper claim (S4.1, "Sensitivity classification" paragraph):**
"CLARA classifies each parameter into one of three categories:
bottleneck (binding + narrow OAT range),
fragile (non-binding but narrow OAT range),
robust (wide OAT range)"

**Validation:**
1. Check if classification logic exists
2. Check what threshold is used ("default: 10th percentile" or similar)
3. If missing: implement classification

**Implementation if missing:**
```python
def classify_sensitivity(binding, oat_range, threshold_percentile=10):
    threshold = np.percentile(oat_range[oat_range > 0], threshold_percentile)
    classifications = []
    for i in range(len(binding)):
        if binding[i] and oat_range[i] < threshold:
            classifications.append('bottleneck')
        elif not binding[i] and oat_range[i] < threshold:
            classifications.append('fragile')
        else:
            classifications.append('robust')
    return classifications
```

---

## PRIORITY B: Data that is approximate in paper and needs real values

### B1. Instance statistics (S6.1)
**Paper states:**
- "18 (15%) exhibit primal degeneracy"
- "median basis condition number is κ(B) = 4.2 × 10³"
- "maximum of 2.1 × 10⁷"

**Action:** These are PLACEHOLDER values I generated. Run the following on actual experiment data:
```python
# For each of 120 random instances:
degen_count = sum(1 for inst in instances if any(x_B < 1e-8))
kappas = [np.linalg.cond(B) for B in all_bases]
print(f"Degenerate: {degen_count}/{len(instances)} ({100*degen_count/len(instances):.0f}%)")
print(f"κ(B) median: {np.median(kappas):.2e}, max: {np.max(kappas):.2e}")
```
Update S6.1 in clara_cor.tex with actual values.

### B2. Region table statistics (S6.4)
**Paper states (Table: region):**
- n=5-10: std=3.51, max=18.7
- n=15-20: std=4.22, max=22.4
- n=30-50: std=5.89, max=28.6

**Action:** These are PLACEHOLDER values. Extract from actual experiment CSV (exp8_region.csv or similar).

### B3. Attribution table breakdown (S6.3)
**Paper states (Table: attribution):**
- RC_small: 132.4%, 108.6%
- RC_medium: 145.7%, 119.3%
- etc.

**Action:** Verify against actual experiment CSV (exp7_attribution.csv or similar).

### B4. Warm-start table breakdown (S6.5)
**Paper states (Table: warm-start):**
- Type R: 85.2% match, 48.3x speedup, max 122x
- Type C: 82.4%, 28.1x, 89x
- etc.

**Action:** Verify against actual experiment CSV (exp3_warmstart.csv or similar).

### B5. Decision quality table (S6.5)
**Paper states (Table: decision):**
- TP/TN/FP/FN breakdown by Type R/C/RC is currently "---"

**Action:** Fill from exp2_reopt_decision.csv.

---

## PRIORITY C: Verification only (code likely correct, just confirm)

### C1. Oguz bound direction
**Paper claim (S5.2, eq:oguz):**
OC = z'(x*) - z'* where z'(x*) = c'ᵀx* (old solution, new objective)

**Check:** Does the code compute opportunity cost in this direction? For minimization, old solution should be >= new optimum, so OC >= 0.

### C2. Attribution theorem implementation
**Paper claim (S4.2, Theorem 1):**
Δz = yᵀΔb + Δcᵀx* + Δc_Bᵀ B^{-1} Δb

**Check:** Verify the three-term decomposition matches this formula exactly.

### C3. Shapley two-player split
**Paper claim (S4.2):**
φ_b = ((z_b - z*) + (z'* - z_c)) / 2
φ_c = ((z_c - z*) + (z'* - z_b)) / 2

**Check:** Verify formula and that two additional LPs are solved.

### C4. Dual ratio test
**Paper claim (S5.3, eq:dual_ratio):**
j* = argmin_{j: (B^{-1}a_j)_i < 0} -c̄_j / (B^{-1}a_j)_i

**Check:** Verify the dual simplex warm-start uses this ratio test.

### C5. Parametric LP breakpoint computation
**Paper claim (S5.3, eq:theta_primal):**
θ̄_P = min_{i: (B^{-1}Δb)_i < 0} (x_B)_i / (-(B^{-1}Δb)_i)

**Check:** Verify parametric LP traces breakpoints using this formula.

---

## Execution order

1. Start by finding the repository structure: `find . -name "*.py" | head -40` and `cat setup.py` or `cat pyproject.toml`
2. For each A-priority item, search for relevant code, verify or implement
3. For each B-priority item, locate experiment data and extract real values
4. For C-priority items, quick verification only

## Important notes
- After implementing any changes, run the full test suite: `python -m pytest tests/`
- Cross-validate: after adding OAT box to Chebyshev LP, re-run region experiments to verify r* values don't change significantly (box rows should be non-binding in most cases)
- The paper file is at: /path/to/clara_cor.tex — update placeholder values with real data
