// ═══════════════════════════════════════════════════════════════════════════════
// gen_logi_fixed_hier_crtp_multiv.stan
//
// PURPOSE: Hierarchical Bayesian forward calibration.
//          Fits a generalized logistic (Richards) curve to culture, mesocosm,
//          AND coretop data jointly. This is the PRIMARY forward calibration
//          model in TEXAS-PSM.
//
// MODEL DESIGN:
//   Two-group hierarchy: culture+mesocosm (culmeso) data constrain the
//   SHAPE of the RI–T curve; coretop (crtp) parameters are drawn from
//   hierarchical priors centered on the culmeso estimates (partial pooling).
//   Optional ecology corrections are applied to coretop data only.
//
// CALIBRATION CURVE — generalized logistic (Richards, upper asymptote fixed = 1, Q fixed = 1):
//   RI = b + (1 - b) / (1 + exp(-k · (T - T₀)))^(1/ν)    [Eq. 1]
//
// NON-THERMAL CORRECTIONS (if enabled, coretop only):
//   RI += β_{G₂/₃} · (gdgt23ratio)                            [Eq. 6]
//   RI += β_{NO₃}  · log₁₀(NO₃)   [only where 0 < NO₃ < cutoff]  [Eq. 7]
// ═══════════════════════════════════════════════════════════════════════════════

data {
    // ─── Culture data ─────────────────────────────────────────────────────────
    int<lower=1> N_cul;
    vector[N_cul] t_cul;           // Known temperature for each culture experiment (°C)
    vector[N_cul] proxyObs_cul;    // Observed scaled Ring Index (∈ [0,1])

    // ─── Mesocosm data ────────────────────────────────────────────────────────
    int<lower=1> N_meso;
    vector[N_meso] t_meso;         // Known temperature for each mesocosm experiment (°C)
    vector[N_meso] proxyObs_meso;

    // ─── Coretop (sediment) data ──────────────────────────────────────────────
    int<lower=1> N_crtp;
    vector[N_crtp] t_crtp;         // Modern instrumental temperature at each site (°C)
    vector[N_crtp] proxyObs_crtp;  // Observed scaled Ring Index from sediment

    // ─── Optional non-thermal predictors (coretop only) ───────────────────────
    // Flags (0 or 1) control whether each correction is applied in the model.
    vector[N_crtp] gdgt23ratio_crtp;
    int<lower=0, upper=1> use_gdgt23ratio;

    vector[N_crtp] no3_crtp;       // Nitrate concentration (μmol/L)
    int<lower=0, upper=1> use_no3;
    real no3_cutoff;               // Threshold: NO₃ correction applied below this value
}

parameters {
    // ─── Generalized-logistic curve parameters (culture + mesocosm) ───────────
    // These describe the shape of the RI–T relationship.
    // Eq. 1: RI = b + (1 - b) / (1 + exp(-k · (T - T₀)))^(1/ν)   [Q fixed = 1]
    //
    // NOTE: T₀ is NOT the inflection point of the curve in general —
    //   it is the reference temperature where the logistic term equals 1/(1+1)^(1/ν).
    //   ν shifts and skews the inflection away from T₀.
    real<lower=10, upper=50>  t0_culmeso;  // T₀: reference (center) temperature (°C)
    real<lower=0, upper=0.5>  k_culmeso;   // k: steepness of the RI–T slope
    real<lower=0, upper=1>    b_culmeso;   // b: lower asymptote (RI at very cold T)
    real<lower=0.1, upper=10> v_culmeso;   // ν: shape; ν=1 → symmetric logistic

    // ─── Coretop curve parameters (hierarchically linked to culmeso) ──────────
    // Each parameter is drawn from a normal centered on the culmeso value
    // (see hierarchical priors in the model block). This "partial pooling"
    // regularizes coretop estimates when data are sparse.
    real<lower=10, upper=50>  t0_crtp;
    real<lower=0, upper=0.5>  k_crtp;
    real<lower=0, upper=1>    b_crtp;
    real<lower=0.1, upper=10> v_crtp;

    // ─── Non-thermal regression coefficients (coretop only) ───────────────────
    // Bounded negative: these correct for warm bias in RI.
    real<lower=-1, upper=0>   beta_G23_crtp;  // β_{G₂/₃}: ecology correction coefficient
    real<lower=-1, upper=0>   beta_NO3_crtp;  // β_{NO₃}: nutrient correction coefficient

    // ─── Hierarchical scale parameters (hyperparameters) ──────────────────────
    // Controls how much each coretop parameter can deviate from its culmeso mean.
    // Large sigma → weak pooling (coretop data dominant).
    // Small sigma → strong pooling (culmeso data dominant).
    // These are inferred from data, so the model learns the appropriate balance.
    real<lower=0>  sigma_t0_culmeso;
    real<lower=0>  sigma_k_culmeso;
    real<lower=0>  sigma_b_culmeso;
    real<lower=0>  sigma_v_culmeso;

    // ─── Residual observation noise ───────────────────────────────────────────
    // Captures RI variability not explained by temperature (or ecology corrections).
    real<lower=0>  sigma_proxyObs_cul;
    real<lower=0>  sigma_proxyObs_meso;
    real<lower=0>  sigma_proxyObs_crtp;
}

model {
    // ─── 1. Priors for culmeso curve parameters ───────────────────────────────
    // Weakly informative: broad enough to let data dominate, but anchored to
    // the known range of the RI–T relationship.
    t0_culmeso ~ normal(30, 10) T[10, 50];  // Truncated to match declared bounds
    k_culmeso  ~ normal(0, 0.2) T[0, 0.5];
    b_culmeso  ~ beta(2, 5);
    v_culmeso  ~ normal(1, 2) T[0.1, 10];

    // ─── 2. Hyperpriors for hierarchical scale parameters ─────────────────────
    // Half-normal (truncated at 0): scales must be positive; penalize very
    // large deviations to prevent complete independence of the two data groups.
    sigma_t0_culmeso ~ normal(0, 5)   T[0, ];
    sigma_k_culmeso  ~ normal(0, 0.2) T[0, ];
    sigma_b_culmeso  ~ normal(0, 0.2) T[0, ];
    sigma_v_culmeso  ~ normal(0, 2)   T[0, ];

    // ─── 3. Priors for residual noise ─────────────────────────────────────────
    sigma_proxyObs_cul  ~ normal(0.01, 0.1);
    sigma_proxyObs_meso ~ normal(0.01, 0.1);

    // ─── 4. Likelihood for culture + mesocosm data ────────────────────────────
    // Compute expected RI at each known temperature using the Richards curve.
    // Vectorized: Stan evaluates all N_cul / N_meso points in one expression.
    vector[N_cul] mu_proxyObs_cul = b_culmeso + (1 - b_culmeso)
        ./ pow(1 + exp(-k_culmeso * (t_cul - t0_culmeso)), 1.0 / v_culmeso);
    vector[N_meso] mu_proxyObs_meso = b_culmeso + (1 - b_culmeso)
        ./ pow(1 + exp(-k_culmeso * (t_meso - t0_culmeso)), 1.0 / v_culmeso);

    proxyObs_cul  ~ normal(mu_proxyObs_cul,  sigma_proxyObs_cul);
    proxyObs_meso ~ normal(mu_proxyObs_meso, sigma_proxyObs_meso);

    // ─── 5. Hierarchical priors linking coretop parameters to culmeso ─────────
    // Each coretop parameter is drawn from a normal centered on the culmeso
    // estimate: crtp_param ~ Normal(culmeso_param, sigma_culmeso).
    // Truncation mirrors the bounds in the parameters block.
    // This is the key "borrowing strength" step: coretop estimates are pulled
    // toward the lab calibration shape, reducing overfitting to sparse coretop data.
    t0_crtp ~ normal(t0_culmeso, sigma_t0_culmeso) T[10, 50];
    k_crtp  ~ normal(k_culmeso,  sigma_k_culmeso)  T[0, 0.5];
    b_crtp  ~ normal(b_culmeso,  sigma_b_culmeso)  T[0, 1];
    v_crtp  ~ normal(v_culmeso,  sigma_v_culmeso)  T[0.1, 10];

    // Tight priors on correction coefficients (expected small effect sizes).
    beta_G23_crtp ~ normal(0, 0.05);
    beta_NO3_crtp ~ normal(0, 0.05); //normal(-0.064, 0.008); // tight, informative prior based on strong nutrient effect region

    // ─── 6. Likelihood for coretop data (with optional non-thermal corrections) ─
    //
    // Step A: Base thermal term — vectorized over all N_crtp sites at once.
    //   Computes the Richards curve at each measured temperature.
    vector[N_crtp] mu_proxyObs_crtp = b_crtp + (1 - b_crtp)
        ./ pow(1 + exp(-k_crtp * (t_crtp - t0_crtp)), 1.0 / v_crtp);

    // Step B: Ecology correction (if enabled) — add β_{G₂/₃} × gdgt23ratio.
    //   Fully vectorized (element-wise multiply, no loop needed).
    if (use_gdgt23ratio == 1)
        mu_proxyObs_crtp += beta_G23_crtp * gdgt23ratio_crtp;

    // Step C: NO₃ correction (if enabled) — add β_{NO₃} × log₁₀(NO₃).
    //   Requires a loop because the threshold condition (0 < NO₃ < cutoff)
    //   must be checked for each site individually.
    if (use_no3 == 1) {
        for (i in 1:N_crtp) {
            if (no3_crtp[i] > 0 && no3_crtp[i] < no3_cutoff)
                mu_proxyObs_crtp[i] += beta_NO3_crtp * log10(no3_crtp[i]);
        }
    }

    sigma_proxyObs_crtp ~ normal(0, 0.1);
    proxyObs_crtp ~ normal(mu_proxyObs_crtp, sigma_proxyObs_crtp);
}

generated quantities {
    // ── In-sample R² for this model ───────────────────────────────────────────
    // R2_full     : frequentist 1 - RSS/TSS  (matches figure; fixed denominator)
    // bayesR2_full: Bayesian var(μ)/(var(μ)+σ²)  (Gelman et al. 2019)
    // Both computed using this model's own estimated parameters.
    // Sequential variance partitioning (deltaR2_G23, deltaR2_NO3, etc.) is
    // derived in Python by differencing R2_full across separately-fit posteriors.
    real R2_full;
    real bayesR2_full;
    real RMSE_full;

    {   // local scope — mu vector not saved
        vector[N_crtp] mu = b_crtp + (1 - b_crtp)
            ./ pow(1 + exp(-k_crtp * (t_crtp - t0_crtp)), 1.0 / v_crtp);

        if (use_gdgt23ratio == 1)
            mu += beta_G23_crtp * gdgt23ratio_crtp;

        if (use_no3 == 1) {
            for (i in 1:N_crtp) {
                if (no3_crtp[i] > 0 && no3_crtp[i] < no3_cutoff)
                    mu[i] += beta_NO3_crtp * log10(no3_crtp[i]);
            }
        }

        vector[N_crtp] resid = proxyObs_crtp - mu;
        real ybar    = mean(proxyObs_crtp);
        real TSS     = dot_self(proxyObs_crtp - ybar);
        real RSS     = dot_self(resid);
        R2_full      = 1 - RSS / TSS;
        RMSE_full    = sqrt(RSS / N_crtp);

        real var_mu  = variance(mu);
        real sigma2  = sigma_proxyObs_crtp ^ 2;
        bayesR2_full = var_mu / (var_mu + sigma2);
    }
}
