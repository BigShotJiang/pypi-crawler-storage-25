from . import Api


class TokenApi:

    def __init__(self, api: Api):
        self.api = api

    def create_token(self, name: str):
        return self.api.post("/user/token", json={"name": name})

    def refresh_token(self, name: str):
        return self.api.put("/user/token", json={"name": name})

    def revoke_token(self, id: int):
        self.api.delete(f"/user/token/{id}")
