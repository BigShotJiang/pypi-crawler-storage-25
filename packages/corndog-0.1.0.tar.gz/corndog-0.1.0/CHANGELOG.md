# Changelog

## v0.1.0

### ✨ New features

* Initial commit from package template [[e5bd1a8](https://github.com/mbercx/corndog/commit/e5bd1a89b58c639ba022e50b95dbb8f65e35218a)]

