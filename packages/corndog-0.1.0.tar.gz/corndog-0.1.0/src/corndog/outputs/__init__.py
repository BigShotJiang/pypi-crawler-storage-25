"""Public output classes."""

from corndog.outputs.demo import DemoOutput

__all__ = ["DemoOutput"]
