# Introduction

This is the documentation of the `corndog` Python package.
