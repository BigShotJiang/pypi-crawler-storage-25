"""Gerber file loading and layer identification via gerbonara."""

from __future__ import annotations

import logging
import re
import zipfile
from pathlib import Path
from tempfile import TemporaryDirectory

from gerbonara import LayerStack
from gerbonara.excellon import ExcellonFile
from gerbonara.rs274x import GerberFile
from gerbonara.utils import MM

from wgv.gerber.layers import BoardLayer, LayerType

logger = logging.getLogger(__name__)

# Mapping from gerbonara (side, use) keys to our LayerType enum.
_GERBONARA_KEY_TO_LAYER: dict[tuple[str, str], LayerType] = {
    lt.value: lt for lt in LayerType if isinstance(lt.value, tuple)
}

# Filename-based layer detection patterns (case-insensitive).
# Order matters: first match wins.
_FILENAME_PATTERNS: list[tuple[str, str]] = [
    # KiCad patterns
    (r".*[-_.]F[._]Cu\b", "top copper"),
    (r".*[-_.]B[._]Cu\b", "bottom copper"),
    (r".*[-_.]F[._]SilkS\b", "top silk"),
    (r".*[-_.]B[._]SilkS\b", "bottom silk"),
    (r".*[-_.]F[._]Silk\b", "top silk"),
    (r".*[-_.]B[._]Silk\b", "bottom silk"),
    (r".*[-_.]F[._]Mask\b", "top mask"),
    (r".*[-_.]B[._]Mask\b", "bottom mask"),
    (r".*[-_.]F[._]Paste\b", "top paste"),
    (r".*[-_.]B[._]Paste\b", "bottom paste"),
    (r".*[-_.]Edge[._]Cuts\b", "mechanical outline"),
    (r".*[-_.]In(\d+)[._]Cu\b", None),  # inner layers, handled specially
    # Allegro naming conventions
    (r"^top\.art$", "top copper"),
    (r"^bot\.art$", "bottom copper"),
    (r"^silk_top\.art$", "top silk"),
    (r"^silk_bot\.art$", "bottom silk"),
    (r"^solder_top\.art$", "top mask"),
    (r"^solder_bot\.art$", "bottom mask"),
    (r"^paste_top\.art$", "top paste"),
    (r"^paste_bot\.art$", "bottom paste"),
    (r"^fab_outline\.art$", "mechanical outline"),
    (r"^art(\d+)\.art$", None),  # inner layers
    # Extension-based (Protel/Altium)
    (r".*\.gtl$", "top copper"),
    (r".*\.gbl$", "bottom copper"),
    (r".*\.gto$", "top silk"),
    (r".*\.gbo$", "bottom silk"),
    (r".*\.gts$", "top mask"),
    (r".*\.gbs$", "bottom mask"),
    (r".*\.gtp$", "top paste"),
    (r".*\.gbp$", "bottom paste"),
    (r".*\.gm[l1]$", "mechanical outline"),
    (r".*\.gko$", "mechanical outline"),
    (r".*\.g(\d+)l?$", None),  # inner layers
    # Drill files
    (r".*\.drl$", "drill"),
    (r".*[-_.]PTH\.drl$", "drill_pth"),
    (r".*[-_.]NPTH\.drl$", "drill_npth"),
    (r".*\.xln$", "drill"),
    (r".*\.rou$", "drill"),  # Allegro routed slots
]


def load_layer_stack(path: Path) -> LayerStack:
    """Load gerber files from a directory or zip file.

    Tries gerbonara's auto-detection first. On failure, falls back to
    our own filename-based matching.
    """
    if path.is_file() and zipfile.is_zipfile(path):
        return _load_zip(path)
    elif path.is_dir():
        return _load_dir(path)
    else:
        raise ValueError(f"Path must be a directory or zip file: {path}")


def _load_zip(zip_path: Path) -> LayerStack:
    """Extract zip to clean temp dir (filtering __MACOSX etc.), then load."""
    tmpdir = TemporaryDirectory(prefix="wgv_")
    tmp = Path(tmpdir.name)
    _extract_zip_clean(zip_path, tmp)
    return _load_dir(tmp, _tmpdir_handle=tmpdir)


def _load_dir(directory: Path, *, _tmpdir_handle: TemporaryDirectory | None = None) -> LayerStack:
    """Load from directory, trying gerbonara auto-detect then our fallback."""
    try:
        return LayerStack.open(str(directory))
    except (ValueError, SystemError) as e:
        logger.warning("Gerbonara auto-detect failed: %s", e)
        logger.info("Falling back to filename-based layer matching")
        return _load_from_dir_fallback(directory)


def _load_from_dir_fallback(directory: Path) -> LayerStack:
    """Build a LayerStack by matching filenames to layer types."""
    stack = LayerStack()

    gerber_exts = {".gbr", ".ger", ".gtl", ".gbl", ".gto", ".gbo", ".gts", ".gbs",
                   ".gtp", ".gbp", ".gm1", ".gml", ".gko", ".pho", ".art"}
    drill_exts = {".drl", ".xln", ".exc", ".ncd"}

    for f in sorted(directory.iterdir()):
        if not f.is_file():
            continue

        ext = f.suffix.lower()
        name = f.name

        layer_key = _match_filename(name)
        if layer_key is None:
            if ext in gerber_exts or ext in drill_exts:
                logger.warning("Could not identify layer for: %s", name)
            continue

        try:
            if layer_key.startswith("drill"):
                ef = ExcellonFile.open(str(f))
                if layer_key == "drill_pth":
                    stack.drill_pth = ef
                elif layer_key == "drill_npth":
                    stack.drill_npth = ef
                else:
                    # Generic drill — assign to PTH by default
                    if stack.drill_pth is None:
                        stack.drill_pth = ef
                    else:
                        stack.drill_npth = ef
            else:
                gf = GerberFile.open(str(f))
                stack[layer_key] = gf
                logger.info("Loaded %s as %s", name, layer_key)
        except Exception:
            logger.warning("Failed to parse %s, skipping", name, exc_info=True)

    return stack


def _extract_zip_clean(zip_path: Path, dest: Path) -> None:
    """Extract zip to dest, skipping __MACOSX and other OS junk."""
    with zipfile.ZipFile(zip_path) as z:
        for info in z.infolist():
            # Skip macOS resource fork junk
            if info.filename.startswith("__MACOSX"):
                continue
            if info.filename.startswith("._"):
                continue
            # Skip directories
            if info.is_dir():
                continue
            # Flatten: extract only the basename (ignore subdirectories in zip)
            basename = Path(info.filename).name
            if not basename or basename.startswith("."):
                continue
            target = dest / basename
            target.write_bytes(z.read(info.filename))


def _match_filename(name: str) -> str | None:
    """Match a filename to a gerbonara layer key string (e.g. 'top copper').

    Returns None if no match.
    """
    name_lower = name.lower()
    for pattern, layer_key in _FILENAME_PATTERNS:
        m = re.match(pattern, name_lower)
        if not m:
            continue

        if layer_key is not None:
            return layer_key

        # Inner layer — extract number
        try:
            num = int(m.group(1))
            return f"inner_{num:02d} copper"
        except (IndexError, ValueError):
            continue

    return None


def identify_layers(stack: LayerStack) -> list[BoardLayer]:
    """Map gerbonara's identified layers to our BoardLayer model.

    Returns a list of BoardLayer objects sorted by z-order.
    """
    layers: list[BoardLayer] = []

    for (side, use), gerber_file in stack.graphic_layers.items():
        # Skip empty layers (LayerStack pre-populates standard layers)
        if not list(gerber_file.objects):
            continue

        key = (side, use)
        layer_type = _GERBONARA_KEY_TO_LAYER.get(key)
        if layer_type is None:
            # Try matching inner layers with different numbering
            if m := re.match(r"inner_(\d+)", side):
                padded = f"inner_{int(m.group(1)):02d}"
                layer_type = _GERBONARA_KEY_TO_LAYER.get((padded, use))
            if layer_type is None:
                logger.warning("Unrecognized layer: side=%r use=%r, skipping", side, use)
                continue

        layers.append(BoardLayer(layer_type=layer_type, source_file=gerber_file))

    if stack.drill_pth is not None and list(stack.drill_pth.objects):
        layers.append(BoardLayer(layer_type=LayerType.DRILL_PTH, source_file=stack.drill_pth))
    if stack.drill_npth is not None and list(stack.drill_npth.objects):
        layers.append(BoardLayer(layer_type=LayerType.DRILL_NPTH, source_file=stack.drill_npth))

    # Gerbonara puts drill files with unknown plating in _drill_layers
    # (not drill_pth/drill_npth). Include them as PTH by default.
    for drill_file in stack._drill_layers:
        if list(drill_file.objects):
            # Skip if we already have this file via drill_pth/drill_npth
            if drill_file is stack.drill_pth or drill_file is stack.drill_npth:
                continue
            # Assign to PTH if no PTH yet, otherwise NPTH
            if not any(bl.layer_type == LayerType.DRILL_PTH for bl in layers):
                layers.append(BoardLayer(layer_type=LayerType.DRILL_PTH, source_file=drill_file))
            elif not any(bl.layer_type == LayerType.DRILL_NPTH for bl in layers):
                layers.append(BoardLayer(layer_type=LayerType.DRILL_NPTH, source_file=drill_file))
            else:
                logger.warning("Extra drill file ignored: %s", drill_file)

    layers.sort(key=lambda bl: bl.z_order)
    return layers


def board_bounding_box(
    layers: list[BoardLayer],
) -> tuple[tuple[float, float], tuple[float, float]] | None:
    """Compute the board bounding box.

    Prefers the Edge.Cuts/outline layer bbox (defines the physical board).
    Falls back to the union of all layers, excluding outliers that are
    more than 3x the median layer size (likely unit misparse or fab notes
    outside the board).

    Returns ((min_x, min_y), (max_x, max_y)) in mm, or None if no layers
    have geometry.
    """
    # Try Edge.Cuts / outline layer first — most authoritative
    for bl in layers:
        if bl.layer_type == LayerType.EDGE_CUTS:
            bbox = bl.source_file.bounding_box(unit=MM)
            if bbox is not None:
                (min_x, min_y), (max_x, max_y) = bbox
                if max_x - min_x > 1 and max_y - min_y > 1:
                    logger.info(
                        "Using Edge.Cuts bbox: %.1f x %.1f mm",
                        max_x - min_x, max_y - min_y,
                    )
                    return bbox

    # Fallback: union of all layers with outlier filtering
    layer_bboxes: list[tuple[BoardLayer, tuple[tuple[float, float], tuple[float, float]]]] = []
    for bl in layers:
        bbox = bl.source_file.bounding_box(unit=MM)
        if bbox is None:
            continue
        layer_bboxes.append((bl, bbox))

    if not layer_bboxes:
        return None

    # Compute median layer size to detect outliers
    sizes = sorted(
        max(x2 - x1, y2 - y1)
        for _, ((x1, y1), (x2, y2)) in layer_bboxes
    )
    median_size = sizes[len(sizes) // 2]

    overall_min_x = float("inf")
    overall_min_y = float("inf")
    overall_max_x = float("-inf")
    overall_max_y = float("-inf")
    found_any = False

    for bl, ((min_x, min_y), (max_x, max_y)) in layer_bboxes:
        layer_size = max(max_x - min_x, max_y - min_y)
        if median_size > 0 and layer_size > median_size * 3:
            logger.warning(
                "Skipping layer %s from bbox: size %.0fmm vs median %.0fmm",
                bl.display_name, layer_size, median_size,
            )
            continue
        overall_min_x = min(overall_min_x, min_x)
        overall_min_y = min(overall_min_y, min_y)
        overall_max_x = max(overall_max_x, max_x)
        overall_max_y = max(overall_max_y, max_y)
        found_any = True

    if not found_any:
        return None
    return (overall_min_x, overall_min_y), (overall_max_x, overall_max_y)
