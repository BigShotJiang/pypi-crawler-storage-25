"""Layer type definitions, colors, and ordering for PCB visualization."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class Side(Enum):
    TOP = "top"
    BOTTOM = "bottom"
    BOTH = "both"


class LayerType(Enum):
    """Canonical layer types for PCB visualization.

    The value is a (side, use) tuple matching gerbonara's LayerStack key scheme,
    or a special string for drill layers.
    """

    F_CU = ("top", "copper")
    B_CU = ("bottom", "copper")
    F_SILK = ("top", "silk")
    B_SILK = ("bottom", "silk")
    F_MASK = ("top", "mask")
    B_MASK = ("bottom", "mask")
    F_PASTE = ("top", "paste")
    B_PASTE = ("bottom", "paste")
    EDGE_CUTS = ("mechanical", "outline")
    DRILL_PTH = "drill_pth"
    DRILL_NPTH = "drill_npth"

    # Inner copper layers (up to 30)
    IN1_CU = ("inner_01", "copper")
    IN2_CU = ("inner_02", "copper")
    IN3_CU = ("inner_03", "copper")
    IN4_CU = ("inner_04", "copper")
    IN5_CU = ("inner_05", "copper")
    IN6_CU = ("inner_06", "copper")
    IN7_CU = ("inner_07", "copper")
    IN8_CU = ("inner_08", "copper")
    IN9_CU = ("inner_09", "copper")
    IN10_CU = ("inner_10", "copper")
    IN11_CU = ("inner_11", "copper")
    IN12_CU = ("inner_12", "copper")
    IN13_CU = ("inner_13", "copper")
    IN14_CU = ("inner_14", "copper")


# Which side of the board each layer belongs to
LAYER_SIDE: dict[LayerType, Side] = {
    LayerType.F_CU: Side.TOP,
    LayerType.B_CU: Side.BOTTOM,
    LayerType.F_SILK: Side.TOP,
    LayerType.B_SILK: Side.BOTTOM,
    LayerType.F_MASK: Side.TOP,
    LayerType.B_MASK: Side.BOTTOM,
    LayerType.F_PASTE: Side.TOP,
    LayerType.B_PASTE: Side.BOTTOM,
    LayerType.EDGE_CUTS: Side.BOTH,
    LayerType.DRILL_PTH: Side.BOTH,
    LayerType.DRILL_NPTH: Side.BOTH,
    LayerType.IN1_CU: Side.BOTH,
    LayerType.IN2_CU: Side.BOTH,
    LayerType.IN3_CU: Side.BOTH,
    LayerType.IN4_CU: Side.BOTH,
    LayerType.IN5_CU: Side.BOTH,
    LayerType.IN6_CU: Side.BOTH,
    LayerType.IN7_CU: Side.BOTH,
    LayerType.IN8_CU: Side.BOTH,
    LayerType.IN9_CU: Side.BOTH,
    LayerType.IN10_CU: Side.BOTH,
    LayerType.IN11_CU: Side.BOTH,
    LayerType.IN12_CU: Side.BOTH,
    LayerType.IN13_CU: Side.BOTH,
    LayerType.IN14_CU: Side.BOTH,
}

# Display names for the UI
LAYER_DISPLAY_NAME: dict[LayerType, str] = {
    LayerType.F_CU: "Front Copper",
    LayerType.B_CU: "Back Copper",
    LayerType.F_SILK: "Front Silkscreen",
    LayerType.B_SILK: "Back Silkscreen",
    LayerType.F_MASK: "Front Mask",
    LayerType.B_MASK: "Back Mask",
    LayerType.F_PASTE: "Front Paste",
    LayerType.B_PASTE: "Back Paste",
    LayerType.EDGE_CUTS: "Board Outline",
    LayerType.DRILL_PTH: "Drill (PTH)",
    LayerType.DRILL_NPTH: "Drill (NPTH)",
    LayerType.IN1_CU: "Inner 1 Copper",
    LayerType.IN2_CU: "Inner 2 Copper",
    LayerType.IN3_CU: "Inner 3 Copper",
    LayerType.IN4_CU: "Inner 4 Copper",
    LayerType.IN5_CU: "Inner 5 Copper",
    LayerType.IN6_CU: "Inner 6 Copper",
    LayerType.IN7_CU: "Inner 7 Copper",
    LayerType.IN8_CU: "Inner 8 Copper",
    LayerType.IN9_CU: "Inner 9 Copper",
    LayerType.IN10_CU: "Inner 10 Copper",
    LayerType.IN11_CU: "Inner 11 Copper",
    LayerType.IN12_CU: "Inner 12 Copper",
    LayerType.IN13_CU: "Inner 13 Copper",
    LayerType.IN14_CU: "Inner 14 Copper",
}

# Default RGBA colors for rendering (0-255 per channel)
LAYER_COLOR: dict[LayerType, tuple[int, int, int, int]] = {
    LayerType.F_CU: (200, 30, 30, 200),
    LayerType.B_CU: (30, 30, 200, 200),
    LayerType.F_SILK: (255, 255, 255, 230),
    LayerType.B_SILK: (255, 255, 255, 230),
    LayerType.F_MASK: (0, 100, 0, 100),
    LayerType.B_MASK: (0, 100, 0, 100),
    LayerType.F_PASTE: (150, 150, 150, 180),
    LayerType.B_PASTE: (150, 150, 150, 180),
    LayerType.EDGE_CUTS: (200, 200, 0, 255),
    LayerType.DRILL_PTH: (40, 40, 40, 255),
    LayerType.DRILL_NPTH: (80, 80, 80, 255),
    LayerType.IN1_CU: (200, 100, 30, 180),
    LayerType.IN2_CU: (30, 200, 100, 180),
    LayerType.IN3_CU: (100, 30, 200, 180),
    LayerType.IN4_CU: (200, 200, 30, 180),
    LayerType.IN5_CU: (30, 200, 200, 180),
    LayerType.IN6_CU: (200, 30, 200, 180),
    LayerType.IN7_CU: (150, 100, 50, 180),
    LayerType.IN8_CU: (50, 150, 100, 180),
    LayerType.IN9_CU: (100, 50, 150, 180),
    LayerType.IN10_CU: (200, 150, 50, 180),
    LayerType.IN11_CU: (50, 200, 150, 180),
    LayerType.IN12_CU: (150, 50, 200, 180),
    LayerType.IN13_CU: (200, 100, 100, 180),
    LayerType.IN14_CU: (100, 200, 100, 180),
}

# Z-order for compositing (lower = drawn first / further back)
LAYER_Z_ORDER: dict[LayerType, int] = {
    LayerType.B_PASTE: 0,
    LayerType.B_CU: 1,
    LayerType.B_MASK: 2,
    LayerType.B_SILK: 3,
    LayerType.IN14_CU: 4,
    LayerType.IN13_CU: 5,
    LayerType.IN12_CU: 6,
    LayerType.IN11_CU: 7,
    LayerType.IN10_CU: 8,
    LayerType.IN9_CU: 9,
    LayerType.IN8_CU: 10,
    LayerType.IN7_CU: 11,
    LayerType.IN6_CU: 12,
    LayerType.IN5_CU: 13,
    LayerType.IN4_CU: 14,
    LayerType.IN3_CU: 15,
    LayerType.IN2_CU: 16,
    LayerType.IN1_CU: 17,
    LayerType.DRILL_NPTH: 20,
    LayerType.DRILL_PTH: 21,
    LayerType.F_PASTE: 30,
    LayerType.F_CU: 31,
    LayerType.F_MASK: 32,
    LayerType.F_SILK: 33,
    LayerType.EDGE_CUTS: 40,
}

# Layers visible by default in top view
DEFAULT_VISIBLE_TOP: set[LayerType] = {
    LayerType.F_CU,
    LayerType.F_SILK,
    LayerType.F_MASK,
    LayerType.EDGE_CUTS,
    LayerType.DRILL_PTH,
}

# Layers visible by default in bottom view
DEFAULT_VISIBLE_BOTTOM: set[LayerType] = {
    LayerType.B_CU,
    LayerType.B_SILK,
    LayerType.B_MASK,
    LayerType.EDGE_CUTS,
    LayerType.DRILL_PTH,
}


@dataclass(frozen=True)
class BoardLayer:
    """A resolved layer: ties a LayerType to the actual gerbonara file object."""

    layer_type: LayerType
    source_file: object  # gerbonara GerberFile or ExcellonFile

    @property
    def side(self) -> Side:
        return LAYER_SIDE[self.layer_type]

    @property
    def display_name(self) -> str:
        return LAYER_DISPLAY_NAME[self.layer_type]

    @property
    def color(self) -> tuple[int, int, int, int]:
        return LAYER_COLOR[self.layer_type]

    @property
    def z_order(self) -> int:
        return LAYER_Z_ORDER[self.layer_type]

    @property
    def default_visible_top(self) -> bool:
        return self.layer_type in DEFAULT_VISIBLE_TOP

    @property
    def default_visible_bottom(self) -> bool:
        return self.layer_type in DEFAULT_VISIBLE_BOTTOM
