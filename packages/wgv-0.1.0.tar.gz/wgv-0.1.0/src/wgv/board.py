"""Board model — central orchestrator for WGV."""

from __future__ import annotations

import logging
import math
from pathlib import Path

from gerbonara.utils import MM

from wgv.csv.bom import BomEntry, parse_bom_csv
from wgv.csv.merge import merge_bom_placement
from wgv.csv.placement import PlacementEntry, parse_placement_csv
from wgv.gerber.layers import BoardLayer, LayerType
from wgv.gerber.parser import board_bounding_box, identify_layers, load_layer_stack
from wgv.site.generator import generate_site

logger = logging.getLogger(__name__)


class Board:
    """Represents a loaded PCB board ready for rendering.

    Usage::

        board = Board(Path("gerbers/"))
        print(board.bounds)
        for layer in board.layers:
            print(layer.display_name)
        board.generate(Path("output/"))
    """

    def __init__(
        self,
        gerber_path: Path,
        bom_csv: Path | None = None,
        placement_csv: Path | None = None,
    ) -> None:
        self._gerber_path = Path(gerber_path)
        self._bom_csv = Path(bom_csv) if bom_csv else None
        self._placement_csv = Path(placement_csv) if placement_csv else None

        self._stack = load_layer_stack(self._gerber_path)
        self._layers = identify_layers(self._stack)
        self._bounds = board_bounding_box(self._layers)

        # Parse CSV data
        self._bom: list[BomEntry] | None = None
        self._placement: list[PlacementEntry] | None = None
        if self._bom_csv:
            self._bom = parse_bom_csv(self._bom_csv)
        if self._placement_csv:
            self._placement = parse_placement_csv(self._placement_csv)

    @property
    def name(self) -> str:
        """Board name, auto-detected by gerbonara or derived from path."""
        return self._stack.board_name or self._gerber_path.stem

    @property
    def generator(self) -> str | None:
        """EDA tool that generated these files, if detected."""
        return self._stack.generator

    @property
    def layers(self) -> list[BoardLayer]:
        """All identified layers, sorted by z-order."""
        return self._layers

    @property
    def bounds(self) -> tuple[tuple[float, float], tuple[float, float]] | None:
        """Board bounding box as ((min_x, min_y), (max_x, max_y)) in mm.

        None if no geometry was found.
        """
        return self._bounds

    @property
    def width_mm(self) -> float:
        """Board width in mm."""
        assert self._bounds is not None, "Board has no geometry"
        (min_x, _), (max_x, _) = self._bounds
        return max_x - min_x

    @property
    def height_mm(self) -> float:
        """Board height in mm."""
        assert self._bounds is not None, "Board has no geometry"
        (_, min_y), (_, max_y) = self._bounds
        return max_y - min_y

    @property
    def components(self) -> list[dict]:
        """Merged BOM + placement component list."""
        return merge_bom_placement(self._bom, self._placement)

    def _placement_to_gerber_offset(self) -> tuple[float, float]:
        """Compute the (dx, dy) offset to convert placement coords to gerber coords.

        KiCad (and some other EDA tools) can use a different origin for
        placement/drill files vs gerber files. We detect this by matching
        pad positions in the gerber paste/mask layers against placement
        coordinates.

        Returns (offset_x, offset_y) such that:
            gerber_x = placement_x + offset_x
            gerber_y = placement_y + offset_y
        """
        if not self._placement or self._bounds is None:
            return (0.0, 0.0)

        # Collect pad centers from front paste or front mask layer
        pad_centers = self._extract_pad_centers()
        if not pad_centers:
            logger.warning("No paste/mask pads found, cannot compute placement offset")
            return (0.0, 0.0)

        # For every (placement, pad) pair, compute offset = pad - placement.
        # The correct offset will appear many times (one per matched pad).
        # Collect all offsets and find the dominant cluster.
        offset_votes: list[tuple[float, float]] = []
        max_offset = max(self.width_mm, self.height_mm)

        for pe in self._placement:
            if pe.side != "top":
                continue
            for gx, gy in pad_centers:
                dx = gx - pe.x
                dy = gy - pe.y
                # Skip implausible offsets (larger than board)
                if abs(dx) > max_offset or abs(dy) > max_offset:
                    continue
                offset_votes.append((dx, dy))

        if not offset_votes:
            return (0.0, 0.0)

        # Cluster votes: find the offset that most entries agree on.
        # Use a simple binning approach with 0.5mm tolerance.
        best_offset = _find_consensus_offset(offset_votes, tolerance=0.5)

        if abs(best_offset[0]) > 0.1 or abs(best_offset[1]) > 0.1:
            logger.info(
                "Detected placement-to-gerber offset: dx=%.2f dy=%.2f mm "
                "(from pad matching)",
                best_offset[0], best_offset[1],
            )

        return best_offset

    def _extract_pad_centers(self) -> list[tuple[float, float]]:
        """Extract pad center positions from front paste or front mask layer."""
        # Prefer paste (only pads, no traces). Fall back to mask.
        for target_type in (LayerType.F_PASTE, LayerType.F_MASK):
            for bl in self._layers:
                if bl.layer_type != target_type:
                    continue
                centers = []
                for obj in bl.source_file.objects:
                    for prim in obj.to_primitives(unit=MM):
                        bb = prim.bounding_box()
                        if bb is None:
                            continue
                        (px_min, py_min), (px_max, py_max) = bb
                        cx = (px_min + px_max) / 2
                        cy = (py_min + py_max) / 2
                        centers.append((cx, cy))
                if centers:
                    logger.info(
                        "Using %d pad centers from %s for offset detection",
                        len(centers), bl.display_name,
                    )
                    return centers
        return []

    def generate(
        self,
        output_dir: Path,
        *,
        zoom_min: int = 0,
        zoom_max: int | None = None,
        jobs: int | None = None,
        placement_offset_override: tuple[float, float] | None = None,
    ) -> None:
        """Generate the complete static viewer site.

        Args:
            output_dir: Directory to write the static site to.
            zoom_min: Minimum zoom level for tile pyramid.
            zoom_max: Maximum zoom level. None = auto (0.5 mil/pixel).
            jobs: Number of parallel workers (default: CPU count).
            placement_offset_override: Manual (dx, dy) offset in mm.
                Overrides auto-detection when provided.
        """
        assert self._bounds is not None, "Cannot render a board with no geometry"

        from wgv.render.extents import TileExtents
        extents = TileExtents.from_bounds(self._bounds)
        if zoom_max is None:
            # Target: 0.5 mil = 0.0127 mm per pixel
            zoom_max = extents.max_zoom_for_resolution(0.0127)
            logger.info(
                "Auto zoom_max=%d (%.1f um/px at max zoom, board %.0fx%.0fmm)",
                zoom_max,
                extents.mm_per_pixel(zoom_max) * 1000,
                self.width_mm, self.height_mm,
            )

        components = self.components if (self._bom or self._placement) else None
        if placement_offset_override is not None:
            placement_offset = placement_offset_override
            logger.info(
                "Using manual placement offset: dx=%.2f dy=%.2f mm",
                *placement_offset,
            )
        else:
            placement_offset = self._placement_to_gerber_offset()

        generate_site(
            board_name=self.name,
            generator=self.generator,
            layers=self._layers,
            bounds=self._bounds,
            components=components,
            placement_offset=placement_offset,
            output_dir=Path(output_dir),
            zoom_min=zoom_min,
            zoom_max=zoom_max,
        )


def _find_consensus_offset(
    votes: list[tuple[float, float]], tolerance: float
) -> tuple[float, float]:
    """Find the offset with the most votes using 2D histogram binning."""
    if not votes:
        return (0.0, 0.0)

    # Bin votes into a 2D grid with bin_size = tolerance
    bins: dict[tuple[int, int], list[tuple[float, float]]] = {}
    for dx, dy in votes:
        bx = round(dx / tolerance)
        by = round(dy / tolerance)
        key = (bx, by)
        if key not in bins:
            bins[key] = []
        bins[key].append((dx, dy))

    # Find the bin with the most votes (check neighbors too for edge cases)
    best_count = 0
    best_dx = 0.0
    best_dy = 0.0

    for (bx, by), bin_votes in bins.items():
        # Merge with neighboring bins for robustness
        merged = list(bin_votes)
        for nbx in (bx - 1, bx, bx + 1):
            for nby in (by - 1, by, by + 1):
                if (nbx, nby) != (bx, by) and (nbx, nby) in bins:
                    merged.extend(bins[(nbx, nby)])

        if len(merged) > best_count:
            best_count = len(merged)
            best_dx = sum(v[0] for v in merged) / len(merged)
            best_dy = sum(v[1] for v in merged) / len(merged)

    logger.info(
        "Offset consensus: %d/%d votes in best bin (%.1f%%)",
        best_count, len(votes), 100 * best_count / len(votes),
    )
    return (best_dx, best_dy)
