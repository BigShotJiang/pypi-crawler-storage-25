"use strict";

(async function() {

// ============================================================
// Data loading
// ============================================================

const boardData = await fetch("data/board.json").then(r => r.json());
let components = [];
try {
    components = await fetch("data/components.json").then(r => r.json());
} catch (e) { /* no components */ }

// ============================================================
// GerberRenderer — draws primitives onto a canvas 2D context
// ============================================================

class GerberRenderer {
    drawPrimitive(ctx, prim) {
        switch (prim.t) {
            case "C": this._circle(ctx, prim.d); break;
            case "R": this._rect(ctx, prim.d); break;
            case "L": this._line(ctx, prim.d); break;
            case "A": this._arc(ctx, prim.d); break;
            case "P": this._arcPoly(ctx, prim.d); break;
        }
    }

    _circle(ctx, d) {
        ctx.beginPath();
        ctx.arc(d[0], d[1], d[2], 0, 2 * Math.PI);
        ctx.fill();
    }

    _rect(ctx, d) {
        const [x, y, w, h, rot_mrad] = d;
        ctx.save();
        ctx.translate(x, y);
        if (rot_mrad) ctx.rotate(rot_mrad / 1000);
        ctx.fillRect(-w / 2, -h / 2, w, h);
        ctx.restore();
    }

    _line(ctx, d) {
        const [x1, y1, x2, y2, width] = d;
        ctx.beginPath();
        ctx.lineWidth = width;
        ctx.lineCap = "round";
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.stroke();
    }

    _arc(ctx, d) {
        const [x1, y1, x2, y2, cx, cy, cw, width] = d;
        const r = Math.hypot(x1 - cx, y1 - cy);
        if (r < 1e-9) return;
        ctx.beginPath();
        ctx.lineWidth = width;
        ctx.lineCap = "round";
        ctx.arc(cx, cy, r,
            Math.atan2(y1 - cy, x1 - cx),
            Math.atan2(y2 - cy, x2 - cx),
            cw === 1); // Y-flip inverts arc direction
        ctx.stroke();
    }

    _arcPoly(ctx, d) {
        const [flat, arcs] = d;
        const n = flat.length / 2;
        if (n < 2) return;
        ctx.beginPath();
        ctx.moveTo(flat[0], flat[1]);
        const nSeg = arcs.length || (n - 1);
        for (let i = 0; i < nSeg; i++) {
            const ni = (i + 1) % n;
            const x2 = flat[ni * 2], y2 = flat[ni * 2 + 1];
            const arc = arcs[i];
            if (!arc) {
                ctx.lineTo(x2, y2);
            } else {
                const [cw, cx, cy] = arc;
                const x1 = flat[i * 2], y1 = flat[i * 2 + 1];
                const r = Math.hypot(x1 - cx, y1 - cy);
                if (r < 1e-9) { ctx.lineTo(x2, y2); continue; }
                ctx.arc(cx, cy, r,
                    Math.atan2(y1 - cy, x1 - cx),
                    Math.atan2(y2 - cy, x2 - cx),
                    cw === 1);
            }
        }
        ctx.closePath();
        ctx.fill();
    }
}

// ============================================================
// Viewer — main canvas, d3-zoom, layers, components, tools
// ============================================================

class Viewer {
    constructor(container) {
        this._container = container;
        this._renderer = new GerberRenderer();

        // Canvas — draggable=false prevents the browser from hijacking
        // mousedown→mousemove as a native image drag gesture.
        this._canvas = document.createElement("canvas");
        this._canvas.style.position = "absolute";
        this._canvas.style.top = "0";
        this._canvas.style.left = "0";
        this._canvas.style.touchAction = "none";
        this._canvas.style.userSelect = "none";
        this._canvas.setAttribute("draggable", "false");
        container.appendChild(this._canvas);
        this._ctx = this._canvas.getContext("2d");

        // Layer state: { id, color, primitives, bounds, visible, zOrder }
        this._layers = [];
        this._flipped = false;

        // Board geometry (gerber mm)
        this._originX = boardData.origin_x;
        this._originYTop = boardData.origin_y_top;
        this._boardMinX = this._originX + boardData.board_x;
        this._boardMaxX = this._boardMinX + boardData.board_w;
        this._boardMinY = this._originYTop - boardData.board_y - boardData.board_h;
        this._boardMaxY = this._originYTop - boardData.board_y;
        this._boardCenterGX = (this._boardMinX + this._boardMaxX) / 2;

        // Components
        this._components = components;
        this._componentsVisible = true;
        this._compOffsetX = 0;
        this._compOffsetY = 0;
        this._highlightRef = null;
        this._compMarkerRadius = 4; // screen px
        this._compHitRadius = 12;   // screen px

        // Measurement tool
        this._measureStart = null;   // gerber coords
        this._measureEnd = null;
        this._measuringLive = false; // tracking mouse for live rubber-band
        this._measureLiveEnd = null;

        // Shift+drag box zoom (screen pixels)
        this._boxZoomStart = null;
        this._boxZoomEnd = null;

        // Popup
        this._popupEl = document.getElementById("popup");

        // d3 zoom
        this._transform = d3.zoomIdentity;
        this._setupZoom();
        this._resize();
        this._fitBoard();

        window.addEventListener("resize", () => { this._resize(); this.render(); });
    }

    // --- Coordinate transforms ---

    /** Gerber mm → screen pixels using current d3 transform */
    gerberToScreen(gx, gy) {
        // Our canvas transform maps gerber directly:
        //   screen_x = k * gx + tx       (or -k * gx + tx when flipped)
        //   screen_y = -k * gy + ty       (Y flip: gerber Y-up → screen Y-down)
        const t = this._transform;
        const sx = this._flipped
            ? -t.k * gx + t.k * 2 * this._boardCenterGX + t.x
            : t.k * gx + t.x;
        const sy = -t.k * gy + t.y;
        return [sx, sy];
    }

    /** Screen pixels → gerber mm */
    screenToGerber(sx, sy) {
        const t = this._transform;
        const gy = -(sy - t.y) / t.k;
        const gx = this._flipped
            ? -(sx - t.k * 2 * this._boardCenterGX - t.x) / t.k
            : (sx - t.x) / t.k;
        return [gx, gy];
    }

    /** Gerber coords from component tile-space coords (applying offset) */
    compGerber(comp) {
        let tx = comp.x + this._compOffsetX;
        let ty = comp.y - this._compOffsetY;
        // tile_x = gx - originX,  tile_y = originYTop - gy
        const gx = tx + this._originX;
        const gy = this._originYTop - ty;
        return [gx, gy];
    }

    // --- Zoom setup ---

    _setupZoom() {
        const minK = 256 * Math.pow(2, boardData.zoom_min) / boardData.world_size;
        const maxK = 256 * Math.pow(2, boardData.zoom_max + 2) / boardData.world_size;

        this._zoom = d3.zoom()
            .scaleExtent([minK, maxK])
            .filter((event) => {
                // Let shift+drag through to box-zoom, not d3-zoom
                if (event.shiftKey && event.type === "mousedown") return false;
                // Default d3-zoom filter: no ctrl (except wheel), no secondary button
                return (!event.ctrlKey || event.type === "wheel") && !event.button;
            })
            .on("zoom", (event) => {
                this._transform = event.transform;
                this.render();
                this._hidePopup();
            });

        this._d3canvas = d3.select(this._canvas);
        this._d3canvas.call(this._zoom);

        // Disable default context menu on canvas for measurement tool
        this._canvas.addEventListener("contextmenu", (e) => {
            e.preventDefault();
            this._onRightClick(e);
        });

        this._canvas.addEventListener("click", (e) => this._onClick(e));
        this._canvas.addEventListener("mousemove", (e) => this._onMouseMove(e));
        this._canvas.addEventListener("mouseout", () => this._onMouseOut());
        this._canvas.addEventListener("mousedown", (e) => this._onMouseDown(e));
        document.addEventListener("keydown", (e) => {
            if (e.key === "Escape") {
                this._clearMeasure();
                this._cancelBoxZoom();
            }
            if (e.key === "Home") {
                this._fitBoard(true);
            }
        });
    }

    _resize() {
        const dpr = window.devicePixelRatio || 1;
        const w = this._container.clientWidth;
        const h = this._container.clientHeight;
        this._canvas.width = w * dpr;
        this._canvas.height = h * dpr;
        this._canvas.style.width = w + "px";
        this._canvas.style.height = h + "px";
        this._dpr = dpr;
        this._w = w;
        this._h = h;
    }

    _fitBoard(animate) {
        this._zoomToRect(
            this._boardMinX, this._boardMinY,
            this._boardMaxX, this._boardMaxY,
            animate,
        );
    }

    zoomTo(gx, gy, k) {
        // Animate to center on (gx, gy) at scale k
        const tx = this._w / 2 - k * gx;
        const ty = this._h / 2 + k * gy;

        // When flipped, adjust X: screen_x = -k*gx + k*2*boardCenterGX + tx_base
        // We want screen center = -k*gx + k*2*bcgx + tx → tx = w/2 + k*gx - k*2*bcgx
        let finalTx = tx;
        if (this._flipped) {
            finalTx = this._w / 2 + k * gx - k * 2 * this._boardCenterGX;
        }

        const t = d3.zoomIdentity.translate(finalTx, ty).scale(k);
        this._d3canvas.transition().duration(500).call(this._zoom.transform, t);
    }

    // --- Layer management ---

    addLayer(layerDef) {
        const entry = {
            id: layerDef.id,
            color: layerDef.color,
            zOrder: layerDef.z_order,
            visible: false,
            primitives: null,
            bounds: null,
        };
        this._layers.push(entry);
        this._layers.sort((a, b) => a.zOrder - b.zOrder);

        // Load primitives async (CBOR binary format)
        fetch(layerDef.primitives_url)
            .then(r => r.arrayBuffer())
            .then(buf => {
                const data = CBOR.decode(buf);
                entry.primitives = data.primitives;
                entry.bounds = data.bounds;
                if (entry.visible) this.render();
            });

        return entry;
    }

    setLayerVisible(id, visible) {
        const layer = this._layers.find(l => l.id === id);
        if (layer) {
            layer.visible = visible;
            this.render();
        }
    }

    setFlipped(flipped) {
        if (flipped === this._flipped) return;

        // Remember the gerber point at screen center
        const [gx, gy] = this.screenToGerber(this._w / 2, this._h / 2);

        this._flipped = flipped;

        // Compute new tx so that same gerber point stays at screen center
        const t = this._transform;
        let newTx;
        if (this._flipped) {
            // screen_x = -k*gx + k*2*boardCenterGX + tx
            newTx = this._w / 2 + t.k * gx - t.k * 2 * this._boardCenterGX;
        } else {
            // screen_x = k*gx + tx
            newTx = this._w / 2 - t.k * gx;
        }

        const newT = d3.zoomIdentity.translate(newTx, t.y).scale(t.k);
        this._d3canvas.call(this._zoom.transform, newT);
    }

    // --- Component state ---

    setComponentsVisible(v) { this._componentsVisible = v; this.render(); }
    setCompOffset(dx, dy) { this._compOffsetX = dx; this._compOffsetY = dy; this.render(); }
    setHighlight(ref) { this._highlightRef = ref; this.render(); }

    // --- Rendering ---

    render() {
        const ctx = this._ctx;
        const dpr = this._dpr;
        const w = this._canvas.width;
        const h = this._canvas.height;

        ctx.setTransform(1, 0, 0, 1, 0, 0);
        ctx.clearRect(0, 0, w, h);

        const t = this._transform;
        // k/tx/ty are in mm-to-screen-pixel space (with dpr)
        const k = t.k * dpr;
        const tx = t.x * dpr;
        const ty = t.y * dpr;

        // Viewport in primitive integer units (0.1µm) for culling
        const U = 10000; // units per mm
        const [vpMinGX, vpMaxGY] = this.screenToGerber(0, 0);
        const [vpMaxGX, vpMinGY] = this.screenToGerber(this._w, this._h);
        const vpMinXu = Math.min(vpMinGX, vpMaxGX) * U;
        const vpMaxXu = Math.max(vpMinGX, vpMaxGX) * U;
        const vpMinYu = vpMinGY * U;
        const vpMaxYu = vpMaxGY * U;
        const minPxSizeU = 0.5 / k * U; // LOD threshold in integer units

        // Draw each visible layer
        for (const layer of this._layers) {
            if (!layer.visible || !layer.primitives) continue;
            this._renderLayer(layer, k, tx, ty, vpMinXu, vpMaxXu, vpMinYu, vpMaxYu, minPxSizeU);
        }

        // Components
        if (this._componentsVisible && this._components.length > 0) {
            this._renderComponents(ctx, dpr);
        }

        // Measurement overlay
        this._renderMeasurement(ctx, dpr);

        // Box zoom overlay
        this._renderBoxZoom(ctx, dpr);

        // Board outline (debug)
        this._renderBoardOutline(ctx, dpr);
    }

    _renderLayer(layer, k, tx, ty, vpMinXu, vpMaxXu, vpMinYu, vpMaxYu, minPxSizeU) {
        // Each layer renders on an offscreen canvas for polarity isolation,
        // then composites onto the main canvas.
        const w = this._canvas.width;
        const h = this._canvas.height;

        const offscreen = new OffscreenCanvas(w, h);
        const octx = offscreen.getContext("2d");

        // Primitives are in integer 0.1µm units; transform includes /10000 to mm
        const U = 10000;
        const ku = k / U; // screen pixels per integer unit
        if (this._flipped) {
            octx.setTransform(-ku, 0, 0, -ku,
                k * 2 * this._boardCenterGX + tx, ty);
        } else {
            octx.setTransform(ku, 0, 0, -ku, tx, ty);
        }

        const [r, g, b, a] = layer.color;
        const colorStr = `rgba(${r},${g},${b},${a / 255})`;

        for (const prim of layer.primitives) {
            if (prim.b) {
                const [bx0, by0, bx1, by1] = prim.b;
                if (bx1 < vpMinXu || bx0 > vpMaxXu ||
                    by1 < vpMinYu || by0 > vpMaxYu) continue;
                if ((bx1 - bx0) < minPxSizeU && (by1 - by0) < minPxSizeU) continue;
            }

            if (prim.p === 0) {
                octx.globalCompositeOperation = "destination-out";
                octx.fillStyle = "black";
                octx.strokeStyle = "black";
            } else {
                octx.globalCompositeOperation = "source-over";
                octx.fillStyle = colorStr;
                octx.strokeStyle = colorStr;
            }

            this._renderer.drawPrimitive(octx, prim);
        }

        // Composite offscreen onto main canvas
        this._ctx.setTransform(1, 0, 0, 1, 0, 0);
        this._ctx.drawImage(offscreen, 0, 0);
    }

    _renderComponents(ctx, dpr) {
        ctx.setTransform(1, 0, 0, 1, 0, 0);
        const viewSide = this._flipped ? "bottom" : "top";
        const r = this._compMarkerRadius * dpr;

        for (const comp of this._components) {
            if (!("x" in comp)) continue;
            if ((comp.side || "top") !== viewSide) continue;

            const [gx, gy] = this.compGerber(comp);
            const [sx, sy] = this.gerberToScreen(gx, gy);
            const cx = sx * dpr;
            const cy = sy * dpr;

            ctx.beginPath();
            ctx.arc(cx, cy, r, 0, 2 * Math.PI);
            ctx.fillStyle = "rgba(255,204,0,0.7)";
            ctx.fill();
            ctx.strokeStyle = "rgba(255,204,0,1)";
            ctx.lineWidth = dpr;
            ctx.stroke();

            if (comp.ref === this._highlightRef) {
                ctx.beginPath();
                ctx.arc(cx, cy, r * 3, 0, 2 * Math.PI);
                ctx.strokeStyle = "#ff4444";
                ctx.lineWidth = 3 * dpr;
                ctx.stroke();
            }
        }
    }

    _renderBoardOutline(ctx, dpr) {
        ctx.setTransform(1, 0, 0, 1, 0, 0);
        const [x1, y1] = this.gerberToScreen(this._boardMinX, this._boardMinY);
        const [x2, y2] = this.gerberToScreen(this._boardMaxX, this._boardMaxY);
        const left = Math.min(x1, x2) * dpr;
        const top = Math.min(y1, y2) * dpr;
        const w = Math.abs(x2 - x1) * dpr;
        const h = Math.abs(y2 - y1) * dpr;
        ctx.strokeStyle = "#00ff00";
        ctx.lineWidth = 2 * dpr;
        ctx.setLineDash([6 * dpr, 4 * dpr]);
        ctx.strokeRect(left, top, w, h);
        ctx.setLineDash([]);
    }

    _renderMeasurement(ctx, dpr) {
        const start = this._measureStart;
        const end = this._measuringLive ? this._measureLiveEnd : this._measureEnd;
        if (!start || !end) return;

        ctx.setTransform(1, 0, 0, 1, 0, 0);
        const [sx1, sy1] = this.gerberToScreen(start[0], start[1]);
        const [sx2, sy2] = this.gerberToScreen(end[0], end[1]);
        const px1 = sx1 * dpr, py1 = sy1 * dpr;
        const px2 = sx2 * dpr, py2 = sy2 * dpr;

        // Dashed line
        ctx.strokeStyle = "#ff4444";
        ctx.lineWidth = 2 * dpr;
        ctx.setLineDash([6 * dpr, 4 * dpr]);
        ctx.beginPath();
        ctx.moveTo(px1, py1);
        ctx.lineTo(px2, py2);
        ctx.stroke();
        ctx.setLineDash([]);

        // Endpoint dots
        for (const [px, py] of [[px1, py1], [px2, py2]]) {
            ctx.beginPath();
            ctx.arc(px, py, 4 * dpr, 0, 2 * Math.PI);
            ctx.fillStyle = "#ff4444";
            ctx.fill();
        }

        // Label near endpoint, on the opposite side from the start point
        const dx = end[0] - start[0];
        const dy = end[1] - start[1];
        const dist = Math.hypot(dx, dy);

        const fmtMm = v => v.toFixed(2);
        const fmtMil = v => (v / 0.0254).toFixed(1);
        const lines = [
            `d: ${fmtMm(dist)} mm (${fmtMil(dist)} mil)`,
            `dx: ${fmtMm(dx)} mm (${fmtMil(dx)} mil)`,
            `dy: ${fmtMm(dy)} mm (${fmtMil(dy)} mil)`,
        ];

        ctx.font = `${11 * dpr}px "SF Mono", "Menlo", "Consolas", monospace`;
        const lineH = 14 * dpr;
        const pad = 4 * dpr;
        const textW = Math.max(...lines.map(l => ctx.measureText(l).width));
        const boxW = textW + 2 * pad;
        const boxH = lines.length * lineH + 2 * pad;
        const gap = 10 * dpr;

        // Place on the side away from start: if end is right of start,
        // label goes to the right of end; if left, label goes to the left.
        const labelLeft = px2 >= px1
            ? px2 + gap
            : px2 - gap - boxW;
        // Vertically: center on the endpoint, but bias downward if end is
        // above start, upward if below, to avoid the segment.
        const labelTop = py2 <= py1
            ? py2 + gap
            : py2 - gap - boxH;

        // Background
        ctx.fillStyle = "rgba(255, 255, 255, 0.85)";
        ctx.fillRect(labelLeft, labelTop, boxW, boxH);

        // Text
        ctx.fillStyle = "#222";
        ctx.textBaseline = "top";
        for (let i = 0; i < lines.length; i++) {
            ctx.fillText(lines[i], labelLeft + pad, labelTop + pad + i * lineH);
        }

        // Also update the bottom-left info bar
        document.getElementById("measure-info").innerHTML =
            `d: ${fmtMm(dist)} mm (${fmtMil(dist)} mil) &nbsp; ` +
            `dx: ${fmtMm(dx)} mm (${fmtMil(dx)} mil) &nbsp; ` +
            `dy: ${fmtMm(dy)} mm (${fmtMil(dy)} mil)`;
    }

    // --- Interaction ---

    _onClick(e) {
        // Left click finishes an active measurement
        if (this._measuringLive) {
            const [gx, gy] = this.screenToGerber(e.offsetX, e.offsetY);
            this._measureEnd = [gx, gy];
            this._measuringLive = false;
            this.render();
            return;
        }

        const comp = this._findComponentAt(e.offsetX, e.offsetY);
        if (comp) {
            this._highlightRef = comp.ref;
            this._showPopup(comp, e.offsetX, e.offsetY);
            this.render();
        } else {
            this._highlightRef = null;
            this._hidePopup();
            this.render();
        }
    }

    _onRightClick(e) {
        const [gx, gy] = this.screenToGerber(e.offsetX, e.offsetY);

        if (!this._measureStart || (this._measureEnd && !this._measuringLive)) {
            // Start new measurement
            this._measureStart = [gx, gy];
            this._measureEnd = null;
            this._measuringLive = true;
            this._measureLiveEnd = [gx, gy];
            document.getElementById("measure-info").textContent = "Right-click to set end point...";
            this.render();
        } else {
            // Finalize measurement
            this._measureEnd = [gx, gy];
            this._measuringLive = false;
            this.render();
        }
    }

    _onMouseMove(e) {
        // Update cursor position
        const [gx, gy] = this.screenToGerber(e.offsetX, e.offsetY);
        const bx = gx - this._boardMinX;
        const by = this._boardMaxY - gy;
        const posEl = document.getElementById("cursor-pos");
        posEl.textContent =
            `X: ${bx.toFixed(2)} mm (${(bx / 0.0254).toFixed(1)} mil)  ` +
            `Y: ${by.toFixed(2)} mm (${(by / 0.0254).toFixed(1)} mil)`;

        // Live measurement
        if (this._measuringLive) {
            this._measureLiveEnd = [gx, gy];
            this.render();
        }
    }

    _onMouseOut() {
        document.getElementById("cursor-pos").textContent = "--";
    }

    _clearMeasure() {
        this._measureStart = null;
        this._measureEnd = null;
        this._measuringLive = false;
        this._measureLiveEnd = null;
        document.getElementById("measure-info").textContent = "";
        this.render();
    }

    // --- Shift+drag box zoom ---

    _onMouseDown(e) {
        if (!e.shiftKey || e.button !== 0) return;
        e.preventDefault();
        this._boxZoomStart = [e.offsetX, e.offsetY];
        this._boxZoomEnd = [e.offsetX, e.offsetY];

        const onMove = (ev) => {
            this._boxZoomEnd = [ev.offsetX, ev.offsetY];
            this.render();
        };
        const onUp = (ev) => {
            this._canvas.removeEventListener("mousemove", onMove);
            document.removeEventListener("mouseup", onUp);
            this._finishBoxZoom();
        };
        this._canvas.addEventListener("mousemove", onMove);
        document.addEventListener("mouseup", onUp);
        this.render();
    }

    _finishBoxZoom() {
        const s = this._boxZoomStart;
        const e = this._boxZoomEnd;
        this._boxZoomStart = null;
        this._boxZoomEnd = null;

        if (!s || !e) return;
        const dx = Math.abs(e[0] - s[0]);
        const dy = Math.abs(e[1] - s[1]);
        if (dx < 5 && dy < 5) { this.render(); return; } // too small, ignore

        // Convert screen corners to gerber coords
        const [gx1, gy1] = this.screenToGerber(s[0], s[1]);
        const [gx2, gy2] = this.screenToGerber(e[0], e[1]);
        const gMinX = Math.min(gx1, gx2);
        const gMaxX = Math.max(gx1, gx2);
        const gMinY = Math.min(gy1, gy2);
        const gMaxY = Math.max(gy1, gy2);

        this._zoomToRect(gMinX, gMinY, gMaxX, gMaxY, true);
    }

    _cancelBoxZoom() {
        this._boxZoomStart = null;
        this._boxZoomEnd = null;
        this.render();
    }

    _zoomToRect(gMinX, gMinY, gMaxX, gMaxY, animate) {
        const padFrac = 0.05;
        const pw = (gMaxX - gMinX) * (1 + 2 * padFrac);
        const ph = (gMaxY - gMinY) * (1 + 2 * padFrac);

        const [minK, maxK] = this._zoom.scaleExtent();
        const k = Math.max(minK, Math.min(maxK,
            Math.min(this._w / pw, this._h / ph)));

        const cx = (gMinX + gMaxX) / 2;
        const cy = (gMinY + gMaxY) / 2;
        const tx = this._flipped
            ? this._w / 2 + k * cx - k * 2 * this._boardCenterGX
            : this._w / 2 - k * cx;
        const ty = this._h / 2 + k * cy;

        const t = d3.zoomIdentity.translate(tx, ty).scale(k);
        if (animate) {
            this._d3canvas.transition().duration(300).call(this._zoom.transform, t);
        } else {
            this._d3canvas.call(this._zoom.transform, t);
        }
    }

    _renderBoxZoom(ctx, dpr) {
        if (!this._boxZoomStart || !this._boxZoomEnd) return;
        const [sx1, sy1] = this._boxZoomStart;
        const [sx2, sy2] = this._boxZoomEnd;
        ctx.setTransform(1, 0, 0, 1, 0, 0);
        ctx.strokeStyle = "#4a9af5";
        ctx.lineWidth = 2 * dpr;
        ctx.setLineDash([6 * dpr, 4 * dpr]);
        ctx.fillStyle = "rgba(74, 154, 245, 0.1)";
        const x = Math.min(sx1, sx2) * dpr;
        const y = Math.min(sy1, sy2) * dpr;
        const w = Math.abs(sx2 - sx1) * dpr;
        const h = Math.abs(sy2 - sy1) * dpr;
        ctx.fillRect(x, y, w, h);
        ctx.strokeRect(x, y, w, h);
        ctx.setLineDash([]);
    }

    _findComponentAt(sx, sy) {
        if (!this._componentsVisible) return null;
        const viewSide = this._flipped ? "bottom" : "top";
        let best = null;
        let bestDist = this._compHitRadius;

        for (const comp of this._components) {
            if (!("x" in comp)) continue;
            if ((comp.side || "top") !== viewSide) continue;
            const [gx, gy] = this.compGerber(comp);
            const [csx, csy] = this.gerberToScreen(gx, gy);
            const dist = Math.hypot(csx - sx, csy - sy);
            if (dist < bestDist) {
                bestDist = dist;
                best = comp;
            }
        }
        return best;
    }

    _showPopup(comp, sx, sy) {
        const el = this._popupEl;
        el.innerHTML =
            `<b>${comp.ref}</b><br>` +
            (comp.value ? `Value: ${comp.value}<br>` : "") +
            (comp.footprint ? `Footprint: ${comp.footprint}<br>` : "") +
            (comp.side ? `Side: ${comp.side}` : "");
        el.style.left = (sx + 12) + "px";
        el.style.top = (sy - 12) + "px";
        el.style.display = "block";
    }

    _hidePopup() {
        this._popupEl.style.display = "none";
    }
}

// ============================================================
// UI wiring
// ============================================================

const container = document.getElementById("viewer");
const viewer = new Viewer(container);

// --- Load layers ---
const layerEntries = {};
for (const layerDef of boardData.layers) {
    layerEntries[layerDef.id] = viewer.addLayer(layerDef);
}

// --- Layer control panel (components first, then layers top-to-bottom) ---
const layerList = document.getElementById("layer-list");

// Components pseudo-layer at the top
{
    const div = document.createElement("div");
    div.className = "layer-item";
    const cb = document.createElement("input");
    cb.type = "checkbox";
    cb.id = "layer-cb-components";
    cb.checked = true;
    cb.addEventListener("change", function() {
        viewer.setComponentsVisible(this.checked);
    });
    const swatch = document.createElement("span");
    swatch.className = "layer-swatch";
    swatch.style.background = "rgba(255,204,0,0.7)";
    const name = document.createElement("span");
    name.className = "layer-name";
    name.textContent = "Components";
    div.appendChild(cb);
    div.appendChild(swatch);
    div.appendChild(name);
    layerList.appendChild(div);
}

// Gerber layers in reverse z-order (top-to-bottom visually)
const reversedLayers = [...boardData.layers].reverse();
for (const layerDef of reversedLayers) {
    const div = document.createElement("div");
    div.className = "layer-item";

    const cb = document.createElement("input");
    cb.type = "checkbox";
    cb.id = "layer-cb-" + layerDef.id;
    cb.checked = layerDef.default_visible_top;
    cb.addEventListener("change", function() {
        viewer.setLayerVisible(layerDef.id, this.checked);
    });

    const swatch = document.createElement("span");
    swatch.className = "layer-swatch";
    const [r, g, b, a] = layerDef.color;
    swatch.style.background = `rgba(${r},${g},${b},${a / 255})`;

    const name = document.createElement("span");
    name.className = "layer-name";
    name.textContent = layerDef.display_name;
    name.title = layerDef.display_name;

    div.appendChild(cb);
    div.appendChild(swatch);
    div.appendChild(name);
    layerList.appendChild(div);

    if (layerDef.default_visible_top) {
        viewer.setLayerVisible(layerDef.id, true);
    }
}

// --- View toggle ---
let currentView = "top";
const btnTop = document.getElementById("btn-top");
const btnBottom = document.getElementById("btn-bottom");

function setView(view) {
    currentView = view;
    const flipped = (view === "bottom");
    btnTop.classList.toggle("active", view === "top");
    btnBottom.classList.toggle("active", view === "bottom");

    for (const layerDef of boardData.layers) {
        const defaultOn = view === "top"
            ? layerDef.default_visible_top
            : layerDef.default_visible_bottom;
        const cb = document.getElementById("layer-cb-" + layerDef.id);
        cb.checked = defaultOn;
        viewer.setLayerVisible(layerDef.id, defaultOn);
    }
    viewer.setFlipped(flipped);
}

btnTop.addEventListener("click", () => setView("top"));
btnBottom.addEventListener("click", () => setView("bottom"));

// --- Search ---
const searchInput = document.getElementById("search-input");
const searchResults = document.getElementById("search-results");

searchInput.addEventListener("input", function() {
    const query = this.value.trim().toLowerCase();
    searchResults.innerHTML = "";
    if (!query) return;

    const matches = components.filter(c =>
        c.ref.toLowerCase().includes(query) ||
        (c.value && c.value.toLowerCase().includes(query))
    ).slice(0, 20);

    for (const comp of matches) {
        const div = document.createElement("div");
        div.className = "search-result";
        div.innerHTML = `<span class="ref">${comp.ref}</span>` +
            (comp.value ? `<span class="value">${comp.value}</span>` : "");
        div.addEventListener("click", () => focusComponent(comp.ref));
        searchResults.appendChild(div);
    }
});

searchInput.addEventListener("keydown", function(e) {
    if (e.key === "Enter") {
        const first = searchResults.querySelector(".search-result .ref");
        if (first) focusComponent(first.textContent);
    }
});

function focusComponent(ref) {
    const comp = components.find(c => c.ref === ref);
    if (!comp) return;

    const compSide = comp.side || "top";
    if (currentView !== (compSide === "bottom" ? "bottom" : "top")) {
        setView(compSide === "bottom" ? "bottom" : "top");
    }

    viewer.setHighlight(ref);
    const [gx, gy] = viewer.compGerber(comp);
    const maxK = 256 * Math.pow(2, boardData.zoom_max) / boardData.world_size;
    viewer.zoomTo(gx, gy, maxK);

    searchInput.value = "";
    searchResults.innerHTML = "";
}

// --- Board info ---
const boardInfo = document.getElementById("board-info");
boardInfo.textContent = `${boardData.board_name} \u2014 ${boardData.board_w.toFixed(1)} \u00d7 ${boardData.board_h.toFixed(1)} mm`;
if (boardData.generator) {
    boardInfo.textContent += ` (${boardData.generator})`;
}

// --- Placement offset controls ---
const offsetXInput = document.getElementById("offset-x");
const offsetYInput = document.getElementById("offset-y");

function applyOffset() {
    viewer.setCompOffset(
        parseFloat(offsetXInput.value) || 0,
        parseFloat(offsetYInput.value) || 0
    );
}

offsetXInput.addEventListener("change", applyOffset);
offsetYInput.addEventListener("change", applyOffset);

for (const btn of document.querySelectorAll(".offset-btn")) {
    btn.addEventListener("click", function() {
        const input = this.dataset.axis === "x" ? offsetXInput : offsetYInput;
        input.value = (parseFloat(input.value) || 0) + parseFloat(this.dataset.dir) * parseFloat(input.step);
        applyOffset();
    });
}

document.getElementById("offset-reset").addEventListener("click", function() {
    offsetXInput.value = "0";
    offsetYInput.value = "0";
    applyOffset();
});

// --- Panel toggle ---
const panel = document.getElementById("panel");
const panelToggle = document.getElementById("panel-toggle");
panelToggle.addEventListener("click", function() {
    panel.style.display = panel.style.display === "none" ? "" : "none";
    this.textContent = panel.style.display === "none" ? "\u2630" : "\u2715";
});

})();
