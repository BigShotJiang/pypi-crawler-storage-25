"""Static site generator — assembles the output directory."""

from __future__ import annotations

import json
import logging
import shutil
from importlib import resources
from pathlib import Path

import cbor2

from wgv.gerber.layers import BoardLayer
from wgv.render.extents import TileExtents
from wgv.render.primitives_export import PrimitiveSerializer

logger = logging.getLogger(__name__)


def generate_site(
    board_name: str,
    generator: str | None,
    layers: list[BoardLayer],
    bounds: tuple[tuple[float, float], tuple[float, float]],
    components: list[dict] | None,
    output_dir: Path,
    zoom_min: int = 0,
    zoom_max: int = 6,
    placement_offset: tuple[float, float] = (0.0, 0.0),
) -> None:
    """Generate the complete static viewer site.

    Args:
        board_name: Display name for the board.
        generator: EDA tool name or None.
        layers: List of BoardLayer objects to render.
        bounds: Board bounding box ((min_x, min_y), (max_x, max_y)) in mm.
        components: List of component dicts (from CSV merge), or None.
        output_dir: Directory to write the static site to.
        zoom_min: Minimum tile zoom level.
        zoom_max: Maximum tile zoom level (inclusive).
        placement_offset: (dx, dy) to convert placement coords to gerber coords.
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    extents = TileExtents.from_bounds(bounds)
    (min_x, min_y), (max_x, max_y) = bounds

    # 1. Copy static assets
    _copy_static_assets(output_dir)

    # 2. Export primitives for each layer as JSON
    data_dir = output_dir / "data"
    data_dir.mkdir(parents=True, exist_ok=True)
    layers_dir = data_dir / "layers"
    layers_dir.mkdir(parents=True, exist_ok=True)

    serializer = PrimitiveSerializer()
    for bl in layers:
        layer_id = _layer_id(bl)
        layer_data = serializer.serialize_layer(bl)
        (layers_dir / f"{layer_id}.cbor").write_bytes(cbor2.dumps(layer_data))
        logger.info("Layer %s: %d primitives", bl.display_name, len(layer_data["primitives"]))

    # 3. Generate board.json
    board_data = {
        "board_name": board_name,
        "generator": generator,
        "origin_x": extents.origin_x,
        "origin_y_top": extents.origin_y_top,
        "board_x": min_x - extents.origin_x,
        "board_y": extents.origin_y_top - max_y,  # Y flipped: tile Y=0 is gerber Y max
        "board_w": max_x - min_x,
        "board_h": max_y - min_y,
        "world_size": extents.world_size_mm,
        "zoom_min": zoom_min,
        "zoom_max": zoom_max,
        "layers": [
            {
                "id": _layer_id(bl),
                "display_name": bl.display_name,
                "color": list(bl.color),
                "z_order": bl.z_order,
                "side": bl.side.value,
                "default_visible_top": bl.default_visible_top,
                "default_visible_bottom": bl.default_visible_bottom,
                "primitives_url": f"data/layers/{_layer_id(bl)}.cbor",
            }
            for bl in layers
        ],
    }
    (data_dir / "board.json").write_text(json.dumps(board_data, indent=2))

    # 4. Generate components.json (transform placement coords to tile space)
    off_x, off_y = placement_offset
    if components:
        transformed = []
        for comp in components:
            tc = dict(comp)
            if "x" in tc and "y" in tc:
                # Convert placement coords to gerber coords, then to tile space
                gerber_x = tc["x"] + off_x
                gerber_y = tc["y"] + off_y
                tc["x"] = gerber_x - extents.origin_x
                tc["y"] = extents.origin_y_top - gerber_y  # flip Y
            transformed.append(tc)
        (data_dir / "components.json").write_text(json.dumps(transformed, indent=2))
    else:
        (data_dir / "components.json").write_text("[]")

    logger.info("Site generated at %s", output_dir)


def _layer_id(bl: BoardLayer) -> str:
    """Generate a filesystem-safe layer ID."""
    return bl.layer_type.name


def _copy_static_assets(output_dir: Path) -> None:
    """Copy HTML, JS, CSS, and d3-zoom to the output directory."""
    static_src = resources.files("wgv.site") / "static"
    assets_dir = output_dir / "assets"

    # Copy d3 modules
    d3_dst = assets_dir / "d3"
    d3_dst.mkdir(parents=True, exist_ok=True)
    d3_src = static_src / "d3"
    with resources.as_file(d3_src) as d3_path:
        for f in d3_path.iterdir():
            shutil.copy2(f, d3_dst / f.name)

    # Copy viewer JS, CSS, and CBOR decoder
    for filename in ("viewer.js", "viewer.css", "cbor.min.js"):
        src_file = static_src / filename
        with resources.as_file(src_file) as p:
            shutil.copy2(p, assets_dir / filename)

    # Copy index.html to root
    with resources.as_file(static_src / "index.html") as p:
        shutil.copy2(p, output_dir / "index.html")
