"""WGV — Web Gerber Viewer."""

from wgv.board import Board

__all__ = ["Board"]
