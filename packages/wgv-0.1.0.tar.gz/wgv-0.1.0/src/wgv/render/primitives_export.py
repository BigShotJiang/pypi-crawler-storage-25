"""Export gerbonara primitives to dicts for CBOR serialization.

All coordinates are encoded as integers in units of 0.1 µm (10⁻⁷ m).
The JS viewer divides by 10000 to recover mm.
"""

from __future__ import annotations

import logging

import gerbonara.graphic_primitives as gp
from gerbonara.utils import MM

from wgv.gerber.layers import BoardLayer

logger = logging.getLogger(__name__)

# 1 mm = 10000 units (0.1 µm per unit)
UNITS_PER_MM = 10000


def _i(mm: float) -> int:
    """Convert mm to integer 0.1µm units."""
    return round(mm * UNITS_PER_MM)


class PrimitiveSerializer:
    """Serialize gerbonara graphic primitives to compact integer dicts.

    All coordinates are in 0.1µm units (divide by 10000 to get mm).

    Output format per primitive::

        {"t": "C", "d": [x, y, r], "b": [x0, y0, x1, y1]}
        {"t": "R", "d": [x, y, w, h, rotation_mrad]}
        {"t": "L", "d": [x1, y1, x2, y2, width]}
        {"t": "A", "d": [x1, y1, x2, y2, cx, cy, cw, width]}
        {"t": "P", "d": [[x0,y0,x1,y1,...], [null, [cw,cx,cy], ...]]}

    ``p`` field (polarity) is only included when clear (``"p": 0``).
    ``b`` field (bounding box) is omitted when unavailable.
    Rotation is in milliradians (integer).
    """

    def serialize_layer(self, layer: BoardLayer) -> dict:
        """Convert all primitives in a layer to the export format."""
        primitives = []
        for obj in layer.source_file.objects:
            for prim in obj.to_primitives(unit=MM):
                primitives.append(self._serialize_primitive(prim))

        bbox = layer.source_file.bounding_box(unit=MM)
        bounds = (
            [_i(bbox[0][0]), _i(bbox[0][1]), _i(bbox[1][0]), _i(bbox[1][1])]
            if bbox is not None else None
        )

        logger.info(
            "Layer %s: %d primitives serialized",
            layer.display_name, len(primitives),
        )
        return {"primitives": primitives, "bounds": bounds}

    def _serialize_primitive(self, prim: gp.GraphicPrimitive) -> dict:
        if isinstance(prim, gp.Circle):
            result = self._serialize_circle(prim)
        elif isinstance(prim, gp.Rectangle):
            result = self._serialize_rectangle(prim)
        elif isinstance(prim, gp.Line):
            result = self._serialize_line(prim)
        elif isinstance(prim, gp.Arc):
            result = self._serialize_arc(prim)
        elif isinstance(prim, gp.ArcPoly):
            result = self._serialize_arcpoly(prim)
        else:
            assert False, f"Unknown primitive type: {type(prim).__name__}"

        if not prim.polarity_dark:
            result["p"] = 0

        bbox = prim.bounding_box()
        if bbox is not None:
            (x0, y0), (x1, y1) = bbox
            result["b"] = [_i(x0), _i(y0), _i(x1), _i(y1)]

        return result

    def _serialize_circle(self, c: gp.Circle) -> dict:
        return {"t": "C", "d": [_i(c.x), _i(c.y), _i(c.r)]}

    def _serialize_rectangle(self, r: gp.Rectangle) -> dict:
        return {"t": "R", "d": [
            _i(r.x), _i(r.y), _i(r.w), _i(r.h),
            round(r.rotation * 1000),  # milliradians
        ]}

    def _serialize_line(self, line: gp.Line) -> dict:
        return {"t": "L", "d": [
            _i(line.x1), _i(line.y1), _i(line.x2), _i(line.y2),
            _i(line.width),
        ]}

    def _serialize_arc(self, arc: gp.Arc) -> dict:
        return {"t": "A", "d": [
            _i(arc.x1), _i(arc.y1), _i(arc.x2), _i(arc.y2),
            _i(arc.cx), _i(arc.cy), 1 if arc.clockwise else 0,
            _i(arc.width),
        ]}

    def _serialize_arcpoly(self, poly: gp.ArcPoly) -> dict:
        outline_flat = []
        for x, y in poly.outline:
            outline_flat.append(_i(x))
            outline_flat.append(_i(y))

        arcs = []
        if poly.arc_centers:
            for entry in poly.arc_centers:
                if entry is None:
                    arcs.append(None)
                else:
                    cw, (cx, cy) = entry
                    arcs.append([1 if cw else 0, _i(cx), _i(cy)])

        return {"t": "P", "d": [outline_flat, arcs]}
