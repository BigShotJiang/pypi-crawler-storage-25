"""Tile extents: mapping between board coordinates (mm) and tile/pixel space."""

from __future__ import annotations

import math
from dataclasses import dataclass

TILE_SIZE = 256
PADDING_FACTOR = 0.05  # 5% padding around the board


@dataclass
class TileExtents:
    """Defines the mapping between board coordinates (mm) and tile space.

    The board is placed inside a square "world" whose side length is a
    power-of-two multiple of the tile size at zoom 0.  At zoom level z,
    the world is 2^z tiles wide and tall.

    We use Leaflet's L.CRS.Simple which maps pixel coordinates directly:
    at zoom z, one tile = TILE_SIZE pixels, so the world is 2^z * TILE_SIZE
    pixels wide.  We choose the world_size_mm so the board fits (with padding)
    at zoom 0 in one tile.
    """

    # Tile coordinate system: X increases right, Y increases downward.
    # Gerber coordinate system: X increases right, Y increases upward.
    # The Y axis is flipped between the two.
    origin_x: float  # left edge in gerber mm (min X)
    origin_y_top: float  # gerber Y corresponding to tile row 0 (max Y in gerber)
    world_size_mm: float  # side of the square world in mm

    @classmethod
    def from_bounds(
        cls,
        bounds: tuple[tuple[float, float], tuple[float, float]],
    ) -> TileExtents:
        """Create tile extents from a board bounding box.

        The world is a square whose side is the larger of width/height,
        padded, and used directly (no power-of-two rounding of the world
        itself — the zoom levels handle the power-of-two scaling).
        """
        (min_x, min_y), (max_x, max_y) = bounds
        width = max_x - min_x
        height = max_y - min_y
        pad = max(width, height) * PADDING_FACTOR
        padded_w = width + 2 * pad
        padded_h = height + 2 * pad
        world = max(padded_w, padded_h)

        # Center the board in the world square
        cx = (min_x + max_x) / 2
        cy = (min_y + max_y) / 2
        origin_x = cx - world / 2
        # origin_y_top = top of tile space = max gerber Y (+ padding)
        origin_y_top = cy + world / 2

        return cls(origin_x=origin_x, origin_y_top=origin_y_top, world_size_mm=world)

    def mm_per_pixel(self, zoom: int) -> float:
        """Physical size of one pixel at given zoom level."""
        tiles_per_side = 2**zoom
        return self.world_size_mm / (tiles_per_side * TILE_SIZE)

    def max_zoom_for_resolution(self, target_mm_per_pixel: float) -> int:
        """Compute the minimum zoom level that achieves the target resolution.

        Returns the zoom level where mm_per_pixel <= target_mm_per_pixel.
        """
        # mm_per_pixel at zoom z = world_size / (2^z * TILE_SIZE)
        # We want world_size / (2^z * TILE_SIZE) <= target
        # 2^z >= world_size / (target * TILE_SIZE)
        z = math.ceil(math.log2(self.world_size_mm / (target_mm_per_pixel * TILE_SIZE)))
        return max(0, z)

    def leaflet_bounds(self) -> list[list[float]]:
        """Return [[south, west], [north, east]] for Leaflet CRS.Simple."""
        return [
            [0, 0],
            [self.world_size_mm, self.world_size_mm],
        ]
