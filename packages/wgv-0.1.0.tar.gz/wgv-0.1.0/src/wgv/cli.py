"""CLI entry point for WGV."""

from __future__ import annotations

import json
import logging
import sys
from pathlib import Path

import click

from wgv.board import Board


@click.group()
def main() -> None:
    """WGV — Web Gerber Viewer."""


@main.command()
@click.argument("gerber_path", type=click.Path(exists=True))
@click.option(
    "-o", "--output", "output_dir",
    type=click.Path(),
    default="output",
    help="Output directory for the static site.",
)
@click.option("--bom", type=click.Path(exists=True), help="BOM CSV file.")
@click.option("--placement", type=click.Path(exists=True), help="Placement CSV file.")
@click.option("--zoom-min", type=int, default=0, help="Minimum zoom level.")
@click.option("--zoom-max", type=int, default=None, help="Maximum zoom level (default: auto, targeting 0.5 mil/pixel).")
@click.option(
    "--placement-offset", type=(float, float), default=None,
    help="Manual placement-to-gerber offset as 'DX DY' in mm. "
         "Overrides auto-detection. Use 'wgv info' to diagnose.",
)
@click.option("-v", "--verbose", is_flag=True, help="Verbose logging.")
def generate(
    gerber_path: str,
    output_dir: str,
    bom: str | None,
    placement: str | None,
    zoom_min: int,
    zoom_max: int,
    placement_offset: tuple[float, float] | None,
    verbose: bool,
) -> None:
    """Generate a static PCB viewer from Gerber files.

    GERBER_PATH is a directory or zip file containing Gerber and drill files.
    """
    logging.basicConfig(
        level=logging.DEBUG if verbose else logging.INFO,
        format="%(levelname)s: %(message)s",
    )
    log = logging.getLogger("wgv")

    board = Board(
        gerber_path=Path(gerber_path),
        bom_csv=Path(bom) if bom else None,
        placement_csv=Path(placement) if placement else None,
    )

    log.info("Board: %s", board.name)
    if board.generator:
        log.info("Generator: %s", board.generator)
    log.info("Layers: %s", ", ".join(l.display_name for l in board.layers))

    if board.bounds is None:
        log.error("No geometry found in gerber files")
        sys.exit(1)

    log.info("Board size: %.1f x %.1f mm", board.width_mm, board.height_mm)
    if zoom_max is not None:
        log.info("Generating tiles (zoom %d-%d)...", zoom_min, zoom_max)
    else:
        log.info("Generating tiles (zoom %d-auto)...", zoom_min)

    board.generate(
        output_dir=Path(output_dir),
        zoom_min=zoom_min,
        zoom_max=zoom_max,
        placement_offset_override=placement_offset,
    )

    log.info("Done! Open %s/index.html in a browser.", output_dir)


@main.command()
@click.argument("gerber_path", type=click.Path(exists=True))
@click.option("--bom", type=click.Path(exists=True), help="BOM CSV file.")
@click.option("--placement", type=click.Path(exists=True), help="Placement CSV file.")
@click.option("-v", "--verbose", is_flag=True, help="Verbose logging.")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def info(
    gerber_path: str,
    bom: str | None,
    placement: str | None,
    verbose: bool,
    as_json: bool,
) -> None:
    """Show coordinate system diagnostics for gerber and placement data.

    Prints bounding boxes, centroids, axis directions, and the offset
    correction that would be applied during generation.
    """
    logging.basicConfig(
        level=logging.DEBUG if verbose else logging.WARNING,
        format="%(levelname)s: %(message)s",
    )

    board = Board(
        gerber_path=Path(gerber_path),
        bom_csv=Path(bom) if bom else None,
        placement_csv=Path(placement) if placement else None,
    )

    report = _build_info_report(board)

    if as_json:
        print(json.dumps(report, indent=2))
    else:
        _print_info_report(report)


def _build_info_report(board: Board) -> dict:
    from gerbonara.utils import MM
    from wgv.gerber.layers import LayerType

    report: dict = {
        "board_name": board.name,
        "generator": board.generator,
        "layers": [bl.display_name for bl in board.layers],
    }

    # Gerber bounding box (overall and per key layer)
    if board.bounds:
        (gx1, gy1), (gx2, gy2) = board.bounds
        report["gerber_bbox"] = {
            "min": [round(gx1, 3), round(gy1, 3)],
            "max": [round(gx2, 3), round(gy2, 3)],
            "centroid": [round((gx1 + gx2) / 2, 3), round((gy1 + gy2) / 2, 3)],
            "size": [round(gx2 - gx1, 3), round(gy2 - gy1, 3)],
        }

        # Edge.Cuts specifically
        for bl in board.layers:
            if bl.layer_type == LayerType.EDGE_CUTS:
                bb = bl.source_file.bounding_box(unit=MM)
                if bb:
                    (ex1, ey1), (ex2, ey2) = bb
                    report["edge_cuts_bbox"] = {
                        "min": [round(ex1, 3), round(ey1, 3)],
                        "max": [round(ex2, 3), round(ey2, 3)],
                        "centroid": [round((ex1 + ex2) / 2, 3), round((ey1 + ey2) / 2, 3)],
                        "size": [round(ex2 - ex1, 3), round(ey2 - ey1, 3)],
                    }

        # Drill bbox (shares origin with placement in KiCad)
        for bl in board.layers:
            if bl.layer_type in (LayerType.DRILL_PTH, LayerType.DRILL_NPTH):
                bb = bl.source_file.bounding_box(unit=MM)
                if bb:
                    (dx1, dy1), (dx2, dy2) = bb
                    key = "drill_pth_bbox" if bl.layer_type == LayerType.DRILL_PTH else "drill_npth_bbox"
                    report[key] = {
                        "min": [round(dx1, 3), round(dy1, 3)],
                        "max": [round(dx2, 3), round(dy2, 3)],
                        "centroid": [round((dx1 + dx2) / 2, 3), round((dy1 + dy2) / 2, 3)],
                        "size": [round(dx2 - dx1, 3), round(dy2 - dy1, 3)],
                    }

        # Y axis direction heuristic: if min_y < 0 and max_y < 0,
        # likely Y-down (KiCad-style) with origin above the board.
        # If min_y > 0, likely Y-up (standard gerber).
        if gy1 >= 0 and gy2 >= 0:
            report["gerber_y_direction"] = "likely Y-up (standard gerber)"
        elif gy1 < 0 and gy2 < 0:
            report["gerber_y_direction"] = "likely Y-down (KiCad-style, all negative)"
        else:
            report["gerber_y_direction"] = "mixed sign (origin inside board area)"

    # Placement bounding box
    if board._placement:
        placed = board._placement
        px_min = min(p.x for p in placed)
        px_max = max(p.x for p in placed)
        py_min = min(p.y for p in placed)
        py_max = max(p.y for p in placed)
        report["placement_bbox"] = {
            "min": [round(px_min, 3), round(py_min, 3)],
            "max": [round(px_max, 3), round(py_max, 3)],
            "centroid": [round((px_min + px_max) / 2, 3), round((py_min + py_max) / 2, 3)],
            "size": [round(px_max - px_min, 3), round(py_max - py_min, 3)],
            "count": len(placed),
        }

        if py_min >= 0 and py_max >= 0:
            report["placement_y_direction"] = "all positive"
        elif py_min < 0 and py_max < 0:
            report["placement_y_direction"] = "all negative"
        else:
            report["placement_y_direction"] = "mixed sign"

        # Compare sizes: placement range vs gerber range
        if board.bounds:
            gw = gx2 - gx1
            gh = gy2 - gy1
            pw = px_max - px_min
            ph = py_max - py_min
            report["size_comparison"] = {
                "gerber_wxh": f"{gw:.1f} x {gh:.1f}",
                "placement_wxh": f"{pw:.1f} x {ph:.1f}",
                "ratio_w": round(pw / gw, 3) if gw > 0 else None,
                "ratio_h": round(ph / gh, 3) if gh > 0 else None,
            }

    # Offset correction
    offset = board._placement_to_gerber_offset()
    report["correction"] = {
        "offset_x": round(offset[0], 3),
        "offset_y": round(offset[1], 3),
        "description": (
            f"gerber_x = placement_x + {offset[0]:.3f}, "
            f"gerber_y = placement_y + {offset[1]:.3f}"
        ),
    }

    return report


def _print_info_report(report: dict) -> None:
    print(f"Board: {report['board_name']}")
    if report.get("generator"):
        print(f"Generator: {report['generator']}")
    print(f"Layers ({len(report['layers'])}): {', '.join(report['layers'])}")
    print()

    if "gerber_bbox" in report:
        gb = report["gerber_bbox"]
        print("Gerber bounding box (used for tile rendering):")
        print(f"  Min:      ({gb['min'][0]:>10.3f}, {gb['min'][1]:>10.3f})")
        print(f"  Max:      ({gb['max'][0]:>10.3f}, {gb['max'][1]:>10.3f})")
        print(f"  Centroid: ({gb['centroid'][0]:>10.3f}, {gb['centroid'][1]:>10.3f})")
        print(f"  Size:      {gb['size'][0]:.3f} x {gb['size'][1]:.3f} mm")
        print(f"  Y axis:    {report.get('gerber_y_direction', '?')}")
        print()

    if "edge_cuts_bbox" in report:
        eb = report["edge_cuts_bbox"]
        print("Edge.Cuts bounding box (physical board outline):")
        print(f"  Min:      ({eb['min'][0]:>10.3f}, {eb['min'][1]:>10.3f})")
        print(f"  Max:      ({eb['max'][0]:>10.3f}, {eb['max'][1]:>10.3f})")
        print(f"  Centroid: ({eb['centroid'][0]:>10.3f}, {eb['centroid'][1]:>10.3f})")
        print(f"  Size:      {eb['size'][0]:.3f} x {eb['size'][1]:.3f} mm")
        print()

    for drill_key, drill_label in [("drill_pth_bbox", "Drill PTH"), ("drill_npth_bbox", "Drill NPTH")]:
        if drill_key in report:
            db = report[drill_key]
            print(f"{drill_label} bounding box (same origin as placement in KiCad):")
            print(f"  Min:      ({db['min'][0]:>10.3f}, {db['min'][1]:>10.3f})")
            print(f"  Max:      ({db['max'][0]:>10.3f}, {db['max'][1]:>10.3f})")
            print(f"  Centroid: ({db['centroid'][0]:>10.3f}, {db['centroid'][1]:>10.3f})")
            print(f"  Size:      {db['size'][0]:.3f} x {db['size'][1]:.3f} mm")
            print()

    if "placement_bbox" in report:
        pb = report["placement_bbox"]
        print(f"Placement bounding box ({pb['count']} components):")
        print(f"  Min:      ({pb['min'][0]:>10.3f}, {pb['min'][1]:>10.3f})")
        print(f"  Max:      ({pb['max'][0]:>10.3f}, {pb['max'][1]:>10.3f})")
        print(f"  Centroid: ({pb['centroid'][0]:>10.3f}, {pb['centroid'][1]:>10.3f})")
        print(f"  Size:      {pb['size'][0]:.3f} x {pb['size'][1]:.3f} mm")
        print(f"  Y axis:    {report.get('placement_y_direction', '?')}")
        print()

    if "size_comparison" in report:
        sc = report["size_comparison"]
        print("Size comparison:")
        print(f"  Gerber:    {sc['gerber_wxh']} mm")
        print(f"  Placement: {sc['placement_wxh']} mm")
        print(f"  Ratio:     W={sc['ratio_w']}, H={sc['ratio_h']}")
        print()

    if "correction" in report:
        c = report["correction"]
        print("Correction applied:")
        print(f"  Offset:    dx={c['offset_x']:+.3f}  dy={c['offset_y']:+.3f} mm")
        print(f"  Formula:   {c['description']}")
