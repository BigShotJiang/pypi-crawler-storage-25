"""Placement CSV parsing with header auto-detection."""

from __future__ import annotations

import csv
import logging
import re
from dataclasses import dataclass
from pathlib import Path

logger = logging.getLogger(__name__)

# Known column name patterns (case-insensitive, normalized)
_REF_PATTERNS = {"ref", "reference", "designator", "refdes", "ref des", "refdes"}
_X_PATTERNS = {"x", "posx", "pos x", "mid x", "center x", "location x", "sym x"}
_Y_PATTERNS = {"y", "posy", "pos y", "mid y", "center y", "location y", "sym y"}
_ROT_PATTERNS = {"rot", "rotation", "angle", "orient", "sym rotate"}
_SIDE_PATTERNS = {"side", "layer", "tb", "board side", "sym mirror"}
_VALUE_PATTERNS = {"value", "val", "comment", "comp value"}
_FP_PATTERNS = {"package", "footprint", "fp", "package_footprint", "sym name"}

# Side value normalization
_SIDE_TOP = {"top", "t", "f", "front", "f.cu", "toplayer", "top layer", "no"}
_SIDE_BOTTOM = {"bottom", "b", "bot", "back", "b.cu", "bottomlayer", "bottom layer", "bot layer", "yes"}


@dataclass
class PlacementEntry:
    """Position and metadata for one component."""

    ref: str
    x: float  # mm
    y: float  # mm
    rotation: float  # degrees
    side: str  # "top" or "bottom"
    value: str | None = None
    footprint: str | None = None


def parse_placement_csv(path: Path) -> list[PlacementEntry]:
    """Parse a placement/position CSV file with auto-detected columns.

    Coordinates are normalized to mm. Side is normalized to "top"/"bottom".
    Raises ValueError if required columns cannot be identified.
    """
    path = Path(path)
    rows = _read_csv(path)
    if not rows:
        raise ValueError(f"Placement CSV is empty: {path}")

    # Find the header row (skip preamble lines if any)
    header_idx = None
    col_map = {}
    for i, row in enumerate(rows):
        col_map = _detect_columns(row)
        if col_map.get("ref") is not None and col_map.get("x") is not None and col_map.get("y") is not None:
            header_idx = i
            break

    if header_idx is None:
        raise ValueError(
            f"Cannot identify ref/X/Y columns in placement CSV. "
            f"Scanned {len(rows)} rows, no matching header found."
        )

    headers = rows[header_idx]
    rows = rows[header_idx:]

    ref_col = col_map["ref"]
    x_col = col_map["x"]
    y_col = col_map["y"]

    rot_col = col_map.get("rot")
    side_col = col_map.get("side")
    value_col = col_map.get("value")
    fp_col = col_map.get("footprint")

    logger.info(
        "Placement column mapping: ref=%r x=%r y=%r rot=%r side=%r",
        headers[ref_col], headers[x_col], headers[y_col],
        headers[rot_col] if rot_col is not None else None,
        headers[side_col] if side_col is not None else None,
    )

    # Parse data rows, collect raw coordinates for unit detection
    raw_entries: list[tuple[str, float, float, float, str, str | None, str | None]] = []
    for row in rows[1:]:
        if len(row) <= max(ref_col, x_col, y_col):
            continue
        ref = row[ref_col].strip()
        if not ref:
            continue

        try:
            x = float(row[x_col].replace(",", "."))
            y = float(row[y_col].replace(",", "."))
        except ValueError:
            logger.warning("Skipping row with non-numeric coords: ref=%s", ref)
            continue

        rot = 0.0
        if rot_col is not None and rot_col < len(row):
            try:
                rot = float(row[rot_col].replace(",", "."))
            except ValueError:
                pass

        side = "top"
        if side_col is not None and side_col < len(row):
            side = _normalize_side(row[side_col].strip())

        value = row[value_col].strip() if value_col is not None and value_col < len(row) else None
        fp = row[fp_col].strip() if fp_col is not None and fp_col < len(row) else None

        raw_entries.append((ref, x, y, rot, side, value, fp))

    # Detect units (mils vs mm) from coordinate magnitudes
    scale = _detect_unit_scale(raw_entries)

    entries = [
        PlacementEntry(
            ref=ref, x=x * scale, y=y * scale, rotation=rot,
            side=side, value=value, footprint=fp,
        )
        for ref, x, y, rot, side, value, fp in raw_entries
    ]

    logger.info("Parsed %d placement entries", len(entries))
    return entries


def _read_csv(path: Path) -> list[list[str]]:
    """Read CSV with auto-detected delimiter."""
    text = path.read_text(encoding="utf-8-sig")
    sniffer = csv.Sniffer()
    try:
        dialect = sniffer.sniff(text[:4096], delimiters=",;\t")
    except csv.Error:
        dialect = csv.excel
    reader = csv.reader(text.splitlines(), dialect)
    return list(reader)


def _detect_columns(headers: list[str]) -> dict[str, int | None]:
    """Map field names to column indices."""
    normalized = [_normalize(h) for h in headers]
    return {
        "ref": _find_col(normalized, _REF_PATTERNS),
        "x": _find_col(normalized, _X_PATTERNS),
        "y": _find_col(normalized, _Y_PATTERNS),
        "rot": _find_col(normalized, _ROT_PATTERNS),
        "side": _find_col(normalized, _SIDE_PATTERNS),
        "value": _find_col(normalized, _VALUE_PATTERNS),
        "footprint": _find_col(normalized, _FP_PATTERNS),
    }


def _normalize(s: str) -> str:
    s = s.strip().strip('"').strip("'").lower()
    s = re.sub(r"[_\-/]", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s


def _find_col(normalized: list[str], patterns: set[str]) -> int | None:
    for i, h in enumerate(normalized):
        if h in patterns:
            return i
    return None


def _normalize_side(raw: str) -> str:
    """Normalize side string to 'top' or 'bottom'."""
    low = raw.strip().lower()
    if low in _SIDE_TOP:
        return "top"
    if low in _SIDE_BOTTOM:
        return "bottom"
    return "top"  # default


def _detect_unit_scale(
    entries: list[tuple[str, float, float, float, str, str | None, str | None]],
) -> float:
    """Detect if coordinates are in mils or mm, return scale factor to mm.

    Heuristic: if median |coordinate| > 500, likely mils (1 mil = 0.0254 mm).
    Typical PCB: 10-200mm → coordinates 10-200 in mm, 394-7874 in mils.
    """
    if not entries:
        return 1.0

    coords = []
    for _, x, y, *_ in entries:
        coords.append(abs(x))
        coords.append(abs(y))

    coords.sort()
    median = coords[len(coords) // 2] if coords else 0

    if median > 500:
        logger.info("Detected mil units (median coord=%.1f), converting to mm", median)
        return 0.0254  # mil to mm
    return 1.0  # already mm
