"""Merge BOM and placement data by reference designator."""

from __future__ import annotations

import logging

from wgv.csv.bom import BomEntry
from wgv.csv.placement import PlacementEntry

logger = logging.getLogger(__name__)


def merge_bom_placement(
    bom: list[BomEntry] | None,
    placement: list[PlacementEntry] | None,
) -> list[dict]:
    """Merge BOM and placement into a unified component list.

    Returns a list of dicts suitable for JSON serialization, with keys:
    ref, value, footprint, mpn, x, y, rotation, side.

    Components in placement but not in BOM still appear (fiducials, test points).
    Components in BOM but not in placement are included without coordinates.
    """
    # Build BOM lookup: ref -> (value, footprint, mpn)
    bom_lookup: dict[str, tuple[str, str | None, str | None]] = {}
    if bom:
        for entry in bom:
            for ref in entry.refs:
                bom_lookup[ref] = (entry.value, entry.footprint, entry.mpn)

    # Build placement lookup
    placement_lookup: dict[str, PlacementEntry] = {}
    if placement:
        for entry in placement:
            placement_lookup[entry.ref] = entry

    # Merge: all refs from both sources
    all_refs = set(bom_lookup.keys()) | set(placement_lookup.keys())
    components: list[dict] = []

    for ref in sorted(all_refs):
        comp: dict = {"ref": ref}

        if ref in bom_lookup:
            value, footprint, mpn = bom_lookup[ref]
            comp["value"] = value
            if footprint:
                comp["footprint"] = footprint
            if mpn:
                comp["mpn"] = mpn

        if ref in placement_lookup:
            pe = placement_lookup[ref]
            comp["x"] = pe.x
            comp["y"] = pe.y
            comp["rotation"] = pe.rotation
            comp["side"] = pe.side
            # Placement may also have value/footprint — use as fallback
            if "value" not in comp and pe.value:
                comp["value"] = pe.value
            if "footprint" not in comp and pe.footprint:
                comp["footprint"] = pe.footprint

        components.append(comp)

    placed = sum(1 for c in components if "x" in c)
    logger.info(
        "Merged %d components (%d with placement, %d BOM-only)",
        len(components), placed, len(components) - placed,
    )
    return components
