"""BOM CSV parsing with header auto-detection."""

from __future__ import annotations

import csv
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)

# Known column name patterns per field (case-insensitive, stripped).
_REF_PATTERNS = {"ref", "reference", "designator", "refdes", "ref des", "references",
                  "part reference"}
_VALUE_PATTERNS = {"value", "val", "comment", "comp value"}
_FOOTPRINT_PATTERNS = {"package", "footprint", "fp", "package_footprint", "pcb footprint"}
_QTY_PATTERNS = {"quantity", "qty", "count"}
_MPN_PATTERNS = {"mpn", "manufacturer part", "part number", "mfr part",
                  "mfg1 pn", "mfg1_pn"}


@dataclass
class BomEntry:
    """A single BOM line (may cover multiple refs if grouped)."""

    refs: list[str]
    value: str
    footprint: str | None = None
    mpn: str | None = None


def parse_bom_csv(path: Path) -> list[BomEntry]:
    """Parse a BOM CSV file with auto-detected column mapping.

    Supports KiCad, Altium, Eagle, and generic formats.
    Raises ValueError if required columns (ref, value) cannot be identified.
    """
    path = Path(path)
    rows = _read_csv(path)
    if not rows:
        raise ValueError(f"BOM CSV is empty: {path}")

    # Find the header row: scan rows until we find one with a ref column
    header_idx = None
    col_map = {}
    for i, row in enumerate(rows):
        col_map = _detect_columns(row)
        if col_map.get("ref") is not None and col_map.get("value") is not None:
            header_idx = i
            break

    if header_idx is None:
        raise ValueError(
            f"Cannot identify reference/designator + value columns in BOM CSV. "
            f"Scanned {len(rows)} rows, no matching header found."
        )

    headers = rows[header_idx]
    rows = rows[header_idx:]  # re-base so rows[0] is headers, rows[1:] is data

    ref_col = col_map["ref"]
    value_col = col_map["value"]

    fp_col = col_map.get("footprint")
    mpn_col = col_map.get("mpn")

    logger.info(
        "BOM column mapping: ref=%r value=%r footprint=%r mpn=%r",
        headers[ref_col], headers[value_col],
        headers[fp_col] if fp_col is not None else None,
        headers[mpn_col] if mpn_col is not None else None,
    )

    entries: list[BomEntry] = []
    for row in rows[1:]:
        if len(row) <= max(c for c in (ref_col, value_col) if c is not None):
            continue

        raw_ref = row[ref_col].strip()
        if not raw_ref:
            continue

        # Split grouped refs: "C1, C2, C3" or "C1;C2;C3" or "C1 C2 C3"
        refs = _split_refs(raw_ref)

        value = row[value_col].strip() if value_col < len(row) else ""
        footprint = row[fp_col].strip() if fp_col is not None and fp_col < len(row) else None
        mpn = row[mpn_col].strip() if mpn_col is not None and mpn_col < len(row) else None

        entries.append(BomEntry(refs=refs, value=value, footprint=footprint, mpn=mpn))

    logger.info("Parsed %d BOM entries covering %d refs",
                len(entries), sum(len(e.refs) for e in entries))
    return entries


def _read_csv(path: Path) -> list[list[str]]:
    """Read CSV, auto-detecting delimiter."""
    text = path.read_text(encoding="utf-8-sig")  # handle BOM
    # Try to detect delimiter
    sniffer = csv.Sniffer()
    try:
        dialect = sniffer.sniff(text[:4096], delimiters=",;\t")
    except csv.Error:
        dialect = csv.excel  # fallback to comma
    reader = csv.reader(text.splitlines(), dialect)
    return list(reader)


def _detect_columns(headers: list[str]) -> dict[str, int | None]:
    """Map field names to column indices by matching header patterns."""
    normalized = [_normalize(h) for h in headers]

    result: dict[str, int | None] = {}
    for field_name, patterns in [
        ("ref", _REF_PATTERNS),
        ("value", _VALUE_PATTERNS),
        ("footprint", _FOOTPRINT_PATTERNS),
        ("mpn", _MPN_PATTERNS),
    ]:
        result[field_name] = _find_column(normalized, patterns)

    return result


def _normalize(s: str) -> str:
    """Lowercase, strip, remove quotes and common punctuation."""
    s = s.strip().strip('"').strip("'").lower()
    s = re.sub(r"[_\-/]", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s


def _find_column(normalized_headers: list[str], patterns: set[str]) -> int | None:
    """Find first column whose normalized header matches a pattern."""
    for i, h in enumerate(normalized_headers):
        if h in patterns:
            return i
    return None


def _split_refs(raw: str) -> list[str]:
    """Split a potentially grouped ref string into individual refs."""
    # Try comma, semicolon, then space (but only if refs look like "C1 C2")
    parts = re.split(r"[,;]\s*", raw)
    if len(parts) > 1:
        return [p.strip() for p in parts if p.strip()]
    # Space-separated only if they look like designators
    parts = raw.split()
    if len(parts) > 1 and all(re.match(r"[A-Z]+\d+", p) for p in parts):
        return parts
    return [raw]
