"""Raw `.ts` assets for the optional VRT scaffold (enabled via --features=vrt)."""
