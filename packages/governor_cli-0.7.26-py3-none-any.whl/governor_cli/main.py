"""Governor CLI entry point."""

from __future__ import annotations

# Load ~/.governor/config.json into os.environ before importing anything that
# reads settings at module load (governor_core.db.session pulls DATABASE_URL).
from governor_cli.config import load_env_from_config

load_env_from_config()

import typer  # noqa: E402

from governor_cli.commands import (  # noqa: E402
    detect,
    generate,
    init,
    pr,
    reset,
    shadow,
    start,
    status,
    stop,
    sync,
)

app = typer.Typer(
    name="governor",
    help=(
        "Governor — BigQuery cost optimization for dbt projects. "
        "Detect, generate solutions, validate via shadow runs, open PRs."
    ),
    no_args_is_help=True,
    add_completion=False,
)


app.command(name="init")(init.init_command)
app.command(name="start")(start.start_command)
app.command(name="stop")(stop.stop_command)
app.command(name="reset")(reset.reset_command)
app.command(name="sync")(sync.sync_command)
app.command(name="detect")(detect.detect_command)
app.command(name="generate")(generate.generate_command)
app.command(name="shadow")(shadow.shadow_command)
app.command(name="pr")(pr.pr_command)
app.command(name="status")(status.status_command)


if __name__ == "__main__":  # pragma: no cover
    app()
