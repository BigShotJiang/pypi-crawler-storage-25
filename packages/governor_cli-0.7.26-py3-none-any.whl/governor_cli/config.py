"""Persistent CLI configuration at ``~/.governor/config.json`` + PID tracking.

Mirrors the pre-split ``app.cli.config`` (spec 079) minus the local-mode
flag (removed alongside the runtime env toggle in spec 120; each deployable
is now explicitly one thing).
"""

from __future__ import annotations

import json
import os
import secrets
from pathlib import Path
from typing import Any

CONFIG_DIR = Path(os.path.expanduser("~/.governor"))
CONFIG_FILE = CONFIG_DIR / "config.json"
PID_FILE = CONFIG_DIR / "server.pid"
LOG_FILE = CONFIG_DIR / "server.log"
STATE_DB_PATH = CONFIG_DIR / "state.db"
DEFAULT_DATABASE_URL = f"sqlite:///{STATE_DB_PATH}"


def ensure_config_dir() -> Path:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    return CONFIG_DIR


def _load() -> dict[str, Any]:
    if not CONFIG_FILE.exists():
        return {}
    try:
        return json.loads(CONFIG_FILE.read_text())
    except (OSError, json.JSONDecodeError):
        return {}


def _save(data: dict[str, Any]) -> None:
    ensure_config_dir()
    tmp = CONFIG_FILE.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(data, indent=2, sort_keys=True))
    tmp.replace(CONFIG_FILE)
    try:
        CONFIG_FILE.chmod(0o600)
    except OSError:
        pass


def load_config() -> dict[str, Any]:
    """Return the current config dict (empty if nothing persisted yet)."""
    return _load()


def load_env_from_config() -> dict[str, str]:
    """Hydrate os.environ from the persisted CLI config.

    Called from every command before engine imports so ``get_settings()`` picks
    up user-provided DATABASE_URL, LLM_API_KEY, etc.
    """
    data = _load()
    applied: dict[str, str] = {}

    # Always default DATABASE_URL to SQLite if not set.
    if not os.environ.get("DATABASE_URL"):
        os.environ["DATABASE_URL"] = str(data.get("database_url") or DEFAULT_DATABASE_URL)
        applied["DATABASE_URL"] = os.environ["DATABASE_URL"]

    # Generate and persist a SECRET_KEY if the user doesn't have one.
    if "secret_key" not in data:
        data["secret_key"] = secrets.token_urlsafe(48)
        _save(data)
    os.environ.setdefault("SECRET_KEY", data["secret_key"])

    for env_key, cfg_key in (
        ("LLM_API_KEY", "llm_api_key"),
        ("LLM_MODEL", "llm_model"),
        ("BIGQUERY_REGION", "bigquery_region"),
        ("GITHUB_APP_ID", "github_app_id"),
        ("GITHUB_APP_INSTALLATION_ID", "github_app_installation_id"),
        ("GITHUB_APP_PRIVATE_KEY", "github_app_private_key"),
    ):
        if cfg_key in data and not os.environ.get(env_key):
            os.environ[env_key] = str(data[cfg_key])
            applied[env_key] = os.environ[env_key]

    return applied


def update_config(**kwargs: Any) -> None:
    """Update persisted config fields (creates file if absent)."""
    data = _load()
    data.update({k: v for k, v in kwargs.items() if v is not None})
    _save(data)


# ── PID file helpers ─────────────────────────────────────────────────────────

def read_pid() -> int | None:
    """Return the PID of the managed server, or None if no pidfile/invalid."""
    if not PID_FILE.exists():
        return None
    try:
        return int(PID_FILE.read_text().strip())
    except (OSError, ValueError):
        return None


def write_pid(pid: int) -> None:
    ensure_config_dir()
    PID_FILE.write_text(str(pid))


def clear_pid() -> None:
    try:
        PID_FILE.unlink()
    except FileNotFoundError:
        pass
