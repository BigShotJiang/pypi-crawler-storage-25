"""SQLite state bootstrap for the CLI.

Ensures the database exists, the core Alembic migrations have been applied
(including the SQLite compatibility shim), and returns a ready-to-use
SessionLocal bound to the configured database URL.
"""

from __future__ import annotations

import logging
import os
from pathlib import Path

from alembic import command
from alembic.config import Config
from sqlalchemy.orm import sessionmaker

logger = logging.getLogger(__name__)


def _core_alembic_config(database_url: str) -> Config:
    """Build an Alembic Config that points at governor_core's migration tree.

    We don't rely on ``packages/core/alembic.ini`` being on the user's disk
    (the CLI is installed standalone via ``uv tool install``) — instead we
    construct the Config in-memory and point ``script_location`` at the
    package's ``migrations`` directory, which ships as package data.
    """
    import governor_core

    core_root = Path(governor_core.__file__).resolve().parent
    cfg = Config()
    cfg.set_main_option("script_location", str(core_root / "migrations"))
    cfg.set_main_option("version_table", "alembic_core_version")
    cfg.set_main_option("sqlalchemy.url", database_url)
    return cfg


def ensure_database() -> tuple:
    """Apply core migrations to the configured DB and return (engine, SessionLocal).

    Idempotent: no-op on subsequent calls when the DB is at head.
    """
    from governor_core.core.config import get_settings
    from governor_core.db.base import Base  # noqa: F401 (registers core models)
    from governor_core.db.session import create_engine_for_url
    from governor_core.db.sqlite_compat import (
        apply_sqlite_compat,
        declare_web_stub_tables,
    )

    # Core ORM models declare foreign keys into web-owned tables (users,
    # verification_runs). Ensure those tables exist in Base.metadata for
    # SQLAlchemy's schema sort to succeed. Prefer the authoritative web models
    # when they're installed alongside the CLI (workspace builds, `pip install
    # governor-bq`). Otherwise register minimal stubs so core migrations can
    # run standalone.
    #
    # Runtime ``importlib.util.find_spec`` — *not* a source-level import — so
    # the import-boundary check still passes (CLI does not statically depend
    # on web).
    import importlib
    import importlib.util

    if importlib.util.find_spec("governor_web") is not None:
        importlib.import_module("governor_web")  # registers full web models
    else:
        declare_web_stub_tables(Base.metadata)

    settings = get_settings()
    database_url = settings.database_url

    # Ensure parent directory exists for SQLite file URLs.
    if database_url.startswith("sqlite:///"):
        db_path = Path(database_url.replace("sqlite:///", "", 1))
        db_path.parent.mkdir(parents=True, exist_ok=True)

    # Apply JSONB→JSON + ARRAY→JSON patch before create_all / migrations.
    apply_sqlite_compat(Base.metadata)

    engine = create_engine_for_url(database_url)
    apply_sqlite_compat(Base.metadata)

    from sqlalchemy import inspect

    inspector = inspect(engine)
    fresh_install = "manifest_configurations" not in set(inspector.get_table_names())

    cfg = _core_alembic_config(database_url)
    if fresh_install:
        # Fresh install: create schema directly from the ORM metadata and stamp
        # Alembic head. The CLI doesn't need the full legacy revision chain,
        # some of which uses ALTER TABLE operations SQLite can't run.
        logger.debug("Fresh SQLite install at %s — create_all + stamp head", database_url)
        Base.metadata.create_all(engine)
        command.stamp(cfg, "head")
    else:
        # Existing database (e.g., user points DATABASE_URL at Postgres):
        # upgrade with regular Alembic migrations.
        logger.debug("Running Alembic upgrade against %s", database_url)
        command.upgrade(cfg, "head")

    session_local = sessionmaker(
        bind=engine, autocommit=False, autoflush=False, expire_on_commit=False
    )
    return engine, session_local
