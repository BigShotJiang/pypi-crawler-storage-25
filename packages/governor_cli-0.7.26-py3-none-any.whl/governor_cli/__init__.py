"""Governor CLI — single-user local dbt cost optimization."""

__version__ = "0.7.0"
