"""``governor status`` — print a snapshot of the local state + server status."""

from __future__ import annotations

import os

import typer

from governor_cli import config as cli_config


def status_command() -> None:
    """Print server state + sync/detection/solution/PR counts."""
    # --- Server status ------------------------------------------------------
    pid = cli_config.read_pid()
    if pid:
        try:
            os.kill(pid, 0)
            typer.secho(f"Server: running (PID {pid})", fg=typer.colors.GREEN)
        except ProcessLookupError:
            typer.echo("Server: stopped (stale pidfile — clearing)")
            cli_config.clear_pid()
        except PermissionError:
            typer.secho(
                f"Server: running (PID {pid}, no signal permission)",
                fg=typer.colors.GREEN,
            )
    else:
        typer.echo("Server: not running")

    # --- Data snapshot ------------------------------------------------------
    from governor_cli.state import ensure_database
    from governor_core.configurations.models import ManifestConfiguration
    from governor_core.opportunities.models import Opportunity
    from governor_core.pullrequests.models import PullRequestRecord
    from governor_core.solutions.models import Solution
    from governor_core.sync.models import SyncOperation

    _, session_local = ensure_database()
    with session_local() as db:
        configs = db.query(ManifestConfiguration).all()
        typer.echo(f"Configurations: {len(configs)}")
        for cfg in configs:
            typer.echo(f"  {cfg.id}  {cfg.name}  ({cfg.manifest_source})")

        total_syncs = db.query(SyncOperation).count()
        completed = (
            db.query(SyncOperation).filter(SyncOperation.status == "completed").count()
        )
        typer.echo(f"Syncs: {completed} completed / {total_syncs} total")

        active_opps = (
            db.query(Opportunity).filter(Opportunity.status == "active").count()
        )
        resolved_opps = (
            db.query(Opportunity).filter(Opportunity.status == "resolved").count()
        )
        typer.echo(f"Opportunities: {active_opps} active / {resolved_opps} resolved")

        solutions = db.query(Solution).count()
        typer.echo(f"Solutions generated: {solutions}")

        prs = db.query(PullRequestRecord).count()
        open_prs = (
            db.query(PullRequestRecord).filter(PullRequestRecord.status == "open").count()
        )
        typer.echo(f"Pull requests: {open_prs} open / {prs} total")
