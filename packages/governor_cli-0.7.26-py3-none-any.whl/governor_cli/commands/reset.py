"""``governor reset`` — clear operational data from the configured database.

Preserves schema (tables keep existing) and, on Postgres, preserves auth +
Alembic state. Works on both SQLite (CLI default) and Postgres.
"""

from __future__ import annotations

import os
import signal
from typing import Annotated

import typer
from sqlalchemy import create_engine, text
from sqlalchemy.exc import SQLAlchemyError

from governor_cli import config as cli_config


_OPERATIONAL_TABLES = [
    "solutions",
    "solution_jobs",
    "pull_request_records",
    "opportunities",
    "detection_jobs",
    "opportunity_detection_history",
    "table_storage_metrics",
    "bigquery_jobs",
    "manifest_versions",
    "sync_errors",
    "sync_operations",
    "cost_verification_runs",
    "shadow_model_executions",
    "shadow_validation_runs",
]
_CONFIG_TABLES = [
    "manifest_configurations",
]


def _stop_running_server_if_needed() -> None:
    pid = cli_config.read_pid()
    if not pid:
        return
    try:
        os.kill(pid, signal.SIGTERM)
        typer.echo(f"Stopped running server (PID {pid})")
    except ProcessLookupError:
        pass
    cli_config.clear_pid()


def _truncate(database_url: str, tables: list[str]) -> int:
    """Empty the listed tables; return how many were cleared."""
    engine = create_engine(database_url, pool_pre_ping=True)
    dialect = engine.dialect.name
    cleared = 0
    with engine.begin() as conn:
        # Delete in reverse order so child-table rows are removed before
        # parent-table rows (avoids FK violations on SQLite).
        for table_name in reversed(tables):
            # Check whether the table actually exists (SQLite CLI users may
            # have a subset of the schema).
            try:
                if dialect == "postgresql":
                    conn.execute(text(f"TRUNCATE TABLE {table_name} CASCADE"))
                else:
                    conn.execute(text(f"DELETE FROM {table_name}"))
                cleared += 1
            except SQLAlchemyError:
                # Table missing — skip silently.
                continue
    return cleared


def reset_command(
    full: Annotated[
        bool,
        typer.Option(
            "--full",
            help=(
                "Also clear configuration tables (manifest_configurations). "
                "Without --full only operational data is removed."
            ),
        ),
    ] = False,
    yes: Annotated[
        bool,
        typer.Option(
            "--yes", "-y", help="Skip the confirmation prompt."
        ),
    ] = False,
) -> None:
    """Reset Governor data stored in the configured database."""
    cli_config.load_env_from_config()
    db_url = os.environ.get("DATABASE_URL", cli_config.DEFAULT_DATABASE_URL)

    tables = _OPERATIONAL_TABLES + _CONFIG_TABLES if full else _OPERATIONAL_TABLES
    scope = "operational + configuration data" if full else "operational data"

    if not yes:
        confirmed = typer.confirm(
            f"Reset {scope}? This cannot be undone.",
            default=False,
        )
        if not confirmed:
            typer.echo("Reset cancelled.")
            raise typer.Exit(code=0)

    _stop_running_server_if_needed()

    try:
        cleared = _truncate(db_url, tables)
    except SQLAlchemyError as exc:
        typer.secho(f"Database reset failed: {exc}", fg=typer.colors.RED, err=True)
        raise typer.Exit(code=1) from exc

    typer.secho(
        f"Cleared {cleared} table(s) ({scope}).",
        fg=typer.colors.GREEN,
    )
