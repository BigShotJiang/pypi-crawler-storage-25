"""``governor detect`` — run detection rules against the latest sync."""

from __future__ import annotations

from typing import Annotated

import typer


def detect_command(
    list_rules: Annotated[
        bool,
        typer.Option(
            "--list",
            help="Print the detection rule catalog and exit.",
        ),
    ] = False,
    config_id: Annotated[
        str | None,
        typer.Option(
            "--config-id",
            "-c",
            help="Configuration id. Defaults to most recent.",
        ),
    ] = None,
) -> None:
    """Run detection; print opportunities found."""
    from governor_cli.state import ensure_database
    from governor_core.configurations.models import ManifestConfiguration
    from governor_core.opportunities.catalog import get_detection_rule_catalog
    from governor_core.sync.models import SyncOperation

    if list_rules:
        for entry in get_detection_rule_catalog():
            status = "enabled" if entry.enabled else "disabled"
            typer.echo(
                f"  {entry.rule_type:34}  [{status}]  {entry.display_name}"
            )
        return

    _, session_local = ensure_database()
    with session_local() as db:
        config = (
            db.query(ManifestConfiguration)
            .filter(
                (ManifestConfiguration.id == config_id)
                if config_id
                else ManifestConfiguration.status == "active"
            )
            .order_by(ManifestConfiguration.created_at.desc())
            .first()
        )
        if config is None:
            typer.secho(
                "No configuration found. Run `governor init`.",
                fg=typer.colors.RED,
                err=True,
            )
            raise typer.Exit(code=1)

        latest_sync = (
            db.query(SyncOperation)
            .filter(
                SyncOperation.config_id == config.id,
                SyncOperation.status == "completed",
            )
            .order_by(SyncOperation.completed_at.desc())
            .first()
        )
        if latest_sync is None:
            typer.secho(
                "No completed sync yet. Run `governor sync` first.",
                fg=typer.colors.RED,
                err=True,
            )
            raise typer.Exit(code=1)

        from governor_core.opportunities.service import OpportunityService
        from governor_core.opportunities.detector import DetectionEngine

        engine = DetectionEngine(db)
        opp_service = OpportunityService(db)

        job = opp_service.create_detection_job(
            config_id=config.id, sync_id=latest_sync.id
        )
        db.commit()

        result = engine.run_detection(job)
        db.commit()

        typer.secho(
            f"Detection complete: {result.opportunities_found_count} opportunities found, "
            f"{result.opportunities_updated_count} updated, "
            f"{result.opportunities_resolved_count} resolved.",
            fg=typer.colors.GREEN,
        )
