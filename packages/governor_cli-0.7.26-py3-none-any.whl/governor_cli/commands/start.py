"""``governor start`` — boot the web app in background (or foreground).

Replaces the pre-split ``app.cli.main.start`` command. Spawns
``uvicorn governor_web.main:app`` as a subprocess so the CLI can return to
the shell; uvicorn itself does the work. The CLI doesn't import governor_web
(FR-006) — it just invokes uvicorn against the module path.
"""

from __future__ import annotations

import os
import socket
import subprocess
import sys
import time
from typing import Annotated

import typer

from governor_cli import config as cli_config


def _is_tcp_port_open(host: str, port: int) -> bool:
    try:
        with socket.create_connection((host, port), timeout=0.2):
            return True
    except OSError:
        return False


def _is_process_running(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def _wait_for_server(proc, port: int, timeout_seconds: float = 15.0) -> tuple[bool, int | None]:
    deadline = time.monotonic() + timeout_seconds
    while time.monotonic() < deadline:
        exit_code = proc.poll()
        if exit_code is not None:
            return False, exit_code
        if _is_tcp_port_open("127.0.0.1", port):
            return True, None
        time.sleep(0.2)
    return False, None


def start_command(
    port: Annotated[
        int,
        typer.Option(
            "--port", "-p", help="Port to bind uvicorn to. Default 8000."
        ),
    ] = 8000,
    fg: Annotated[
        bool,
        typer.Option(
            "--fg",
            help="Run uvicorn in the foreground (blocks until Ctrl+C).",
        ),
    ] = False,
) -> None:
    """Start the Governor web server (uvicorn governor_web.main:app)."""
    # Check for an existing managed server.
    existing_pid = cli_config.read_pid()
    if existing_pid and _is_process_running(existing_pid):
        if _is_tcp_port_open("127.0.0.1", port):
            typer.secho(
                f"Server already running on http://localhost:{port} "
                f"(PID {existing_pid})",
                fg=typer.colors.GREEN,
            )
            return
    elif existing_pid:
        # Stale pidfile — clean up.
        cli_config.clear_pid()

    cfg = cli_config.load_config()
    db_url = cfg.get("database_url") or cli_config.DEFAULT_DATABASE_URL
    os.environ.setdefault("DATABASE_URL", db_url)

    # CLI-spawned server runs in LOCAL MODE: last-run-only dashboard,
    # reduced sidebar (no Pull Requests / Sync Queue / Schedules / Users
    # / Audit Log), no login screen (auto-admin), no cloud scheduler, no
    # BigQuery INFORMATION_SCHEMA (sync reads manifest + run_results from
    # the local dbt project). See ``governor_core.core.config.is_local_mode``.
    os.environ["GOVERNOR_LOCAL_MODE"] = "true"

    # Bootstrap the SQLite schema so a fresh ``pipx install governor-bq`` can
    # ``governor start`` without a prior ``governor status`` / ``init`` priming
    # the DB. Idempotent on warm installs.
    from governor_cli.state import ensure_database

    try:
        ensure_database()
    except Exception as exc:
        typer.secho(
            f"Failed to bootstrap database: {exc}", fg=typer.colors.RED, err=True
        )
        raise typer.Exit(code=1) from exc

    if fg:
        typer.secho(
            f"Starting Governor web on http://localhost:{port} (foreground)...",
            fg=typer.colors.GREEN,
        )
        import uvicorn

        uvicorn.run(
            "governor_web.main:app",
            host="0.0.0.0",
            port=port,
        )
        return

    # Background: spawn uvicorn as a detached subprocess, wait for readiness.
    log_path = cli_config.ensure_config_dir() / "server.log"
    log_file = log_path.open("ab")
    try:
        proc = subprocess.Popen(
            [
                sys.executable,
                "-m",
                "uvicorn",
                "governor_web.main:app",
                "--host",
                "0.0.0.0",
                "--port",
                str(port),
            ],
            env={**os.environ, "DATABASE_URL": db_url, "GOVERNOR_LOCAL_MODE": "true"},
            stdout=log_file,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
    finally:
        log_file.close()

    ready, exit_code = _wait_for_server(proc, port=port)
    if not ready:
        cli_config.clear_pid()
        if exit_code is None:
            proc.terminate()
            reason = "did not become ready within 15 seconds"
        else:
            reason = f"exited with code {exit_code}"
        typer.secho(f"Server failed to start: {reason}", fg=typer.colors.RED, err=True)
        typer.echo(f"See logs: {log_path}")
        raise typer.Exit(code=1)

    cli_config.write_pid(proc.pid)
    typer.secho(
        f"Server started on http://localhost:{port} (PID {proc.pid})",
        fg=typer.colors.GREEN,
    )
    typer.echo(f"Logs: {log_path}")
