"""``governor sync`` — run a single sync foreground (no worker thread)."""

from __future__ import annotations

from typing import Annotated

import typer


def sync_command(
    config_id: Annotated[
        str | None,
        typer.Option(
            "--config-id",
            "-c",
            help="Configuration id to sync. Defaults to the most recent configuration.",
        ),
    ] = None,
) -> None:
    """Run one sync synchronously against the configured dbt/BigQuery setup."""
    from governor_cli.state import ensure_database
    from governor_core.configurations.models import ManifestConfiguration
    from governor_core.sync.service import SyncService
    from governor_core.sync.worker import Worker

    _, session_local = ensure_database()
    with session_local() as db:
        config = (
            db.query(ManifestConfiguration)
            .filter(
                (ManifestConfiguration.id == config_id)
                if config_id
                else ManifestConfiguration.status == "active"
            )
            .order_by(ManifestConfiguration.created_at.desc())
            .first()
        )
        if config is None:
            typer.secho(
                "No configuration found. Run `governor init` first.",
                fg=typer.colors.RED,
                err=True,
            )
            raise typer.Exit(code=1)

        service = SyncService(db)
        sync_op = service.create_sync_operation(
            config_id=config.id, triggered_by="manual"
        )
        db.commit()
        typer.echo(f"Created sync operation {sync_op.id} for config {config.id}")

    # Run processing in the foreground; NullHooks so no audit/org-settings reads.
    worker = Worker(session_local)
    worker.process_sync(sync_op)
    typer.secho("Sync complete.", fg=typer.colors.GREEN)
