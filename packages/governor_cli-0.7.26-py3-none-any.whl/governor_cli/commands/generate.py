"""``governor generate <opportunity-id>`` — run the ADK pipeline for one opportunity."""

from __future__ import annotations

from typing import Annotated

import typer


def generate_command(
    opportunity_id: Annotated[
        str,
        typer.Argument(help="Opportunity id to generate a solution for."),
    ],
) -> None:
    """Invoke the ADK multi-agent pipeline and persist the resulting Solution."""
    from governor_cli.state import ensure_database
    from governor_core.opportunities.models import Opportunity
    from governor_core.solutions.service import SolutionService

    _, session_local = ensure_database()
    with session_local() as db:
        opp = db.get(Opportunity, opportunity_id)
        if opp is None:
            typer.secho(f"Opportunity {opportunity_id} not found.", fg=typer.colors.RED, err=True)
            raise typer.Exit(code=1)

        service = SolutionService(db)
        job = service.create_solution_job(opportunity=opp, triggered_by="cli")
        db.commit()

        typer.echo(f"Queued solution job {job.id} for opportunity {opp.id}")
        # Solution generation is performed by a foreground processor call. In
        # cloud mode the worker would pick this up off the queue; in CLI we
        # run it inline for immediate feedback.
        from governor_core.sync.worker import Worker

        worker = Worker(session_local)
        worker.process_solution_job(job)

        typer.secho("Solution generation complete.", fg=typer.colors.GREEN)
