"""``governor stop`` — terminate the managed Governor web server."""

from __future__ import annotations

import os
import signal

import typer

from governor_cli import config as cli_config


def stop_command() -> None:
    """Stop the Governor web server started via ``governor start``."""
    pid = cli_config.read_pid()
    if not pid:
        typer.echo("No server PID on file — nothing to stop.")
        return

    try:
        os.kill(pid, signal.SIGTERM)
        typer.secho(f"Server stopped (PID {pid})", fg=typer.colors.GREEN)
    except ProcessLookupError:
        typer.echo(f"Server PID {pid} already gone; clearing pidfile.")

    cli_config.clear_pid()
