"""``governor pr <solution-id>`` — open a GitHub PR or emit a local commit."""

from __future__ import annotations

from typing import Annotated

import typer


def pr_command(
    solution_id: Annotated[
        str,
        typer.Argument(help="Solution id to submit as a pull request."),
    ],
    local: Annotated[
        bool,
        typer.Option(
            "--local",
            help=(
                "Skip GitHub; write the solution's after_content to the local "
                "file path and make a git commit."
            ),
        ),
    ] = False,
) -> None:
    from governor_cli.state import ensure_database
    from governor_core.pullrequests.service import PullRequestService
    from governor_core.solutions.models import Solution
    from governor_core.configurations.models import ManifestConfiguration
    from governor_core.opportunities.models import Opportunity

    _, session_local = ensure_database()
    with session_local() as db:
        solution = db.get(Solution, solution_id)
        if solution is None:
            typer.secho(
                f"Solution {solution_id} not found.", fg=typer.colors.RED, err=True
            )
            raise typer.Exit(code=1)

        opp = db.get(Opportunity, solution.opportunity_id)
        if opp is None:
            typer.secho(
                "Associated opportunity missing.", fg=typer.colors.RED, err=True
            )
            raise typer.Exit(code=1)
        config = db.get(ManifestConfiguration, opp.config_id)

        if local:
            if not (config and config.local_project_path):
                typer.secho(
                    "--local requires the configuration's local_project_path to be set.",
                    fg=typer.colors.RED,
                    err=True,
                )
                raise typer.Exit(code=1)
            from pathlib import Path
            import subprocess

            target = Path(config.local_project_path) / solution.file_path
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(solution.after_content or "")
            typer.echo(f"Wrote {target}")

            msg = f"Governor: apply fix for {opp.affected_table or opp.opportunity_type}"
            subprocess.run(
                ["git", "-C", config.local_project_path, "add", solution.file_path],
                check=False,
            )
            subprocess.run(
                ["git", "-C", config.local_project_path, "commit", "-m", msg],
                check=False,
            )
            typer.secho("Local commit created.", fg=typer.colors.GREEN)
            return

        # Non-local: go through the core PR service (requires GitHub App creds).
        from governor_core.setup.runtime import create_github_client

        github_client = create_github_client()
        if github_client is None:
            typer.secho(
                "GitHub App not configured. Set GITHUB_APP_ID / GITHUB_APP_PRIVATE_KEY / "
                "GITHUB_APP_INSTALLATION_ID, or re-run with --local.",
                fg=typer.colors.RED,
                err=True,
            )
            raise typer.Exit(code=1)

        service = PullRequestService(db, github_client)
        record = service.create_pr(
            opportunity_id=opp.id,
            solution_id=solution.id,
            user_id=None,
        )
        db.commit()
        typer.secho(f"PR opened: {record.pr_url}", fg=typer.colors.GREEN)
