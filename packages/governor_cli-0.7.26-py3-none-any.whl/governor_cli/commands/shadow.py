"""``governor shadow <solution-id>`` — run shadow validation on a generated solution."""

from __future__ import annotations

from typing import Annotated

import typer


def shadow_command(
    solution_id: Annotated[
        str,
        typer.Argument(help="Solution id to shadow-validate."),
    ],
) -> None:
    from governor_cli.state import ensure_database
    from governor_core.shadow.service import run_shadow_validation
    from governor_core.solutions.models import Solution

    _, session_local = ensure_database()
    with session_local() as db:
        solution = db.get(Solution, solution_id)
        if solution is None:
            typer.secho(f"Solution {solution_id} not found.", fg=typer.colors.RED, err=True)
            raise typer.Exit(code=1)

        run = run_shadow_validation(
            db=db,
            solution=solution,
            progress_callback=lambda phase, line: typer.echo(f"[{phase}] {line}"),
        )
        db.commit()

    typer.secho(
        f"Shadow validation complete: status={run.status}",
        fg=typer.colors.GREEN if run.status == "completed" else typer.colors.YELLOW,
    )
