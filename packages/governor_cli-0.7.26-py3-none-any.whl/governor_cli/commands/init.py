"""``governor init`` — auto-detect dbt project, provision everything.

Mirrors ``_auto_setup_local_project`` from main (pre-split ``app.cli.main``):

  1. Find the nearest ``dbt_project.yml`` (cwd or --project-path)
  2. Read ``target/manifest.json`` (requires ``dbt compile`` first)
  3. Create/update a ``ManifestConfiguration`` with manifest_source=local
  4. Store the manifest bytes as a ``ManifestVersion``
  5. Seed a sentinel admin user (``admin@governor.local``) for auto-login
  6. Mark ``SetupState`` as complete so the wizard is skipped
  7. Print next-step instructions

After ``governor init`` succeeds, ``governor start`` spawns the web UI
with ``GOVERNOR_LOCAL_MODE=true`` and the dashboard shows last-run data
only.
"""

from __future__ import annotations

import json
import uuid
from pathlib import Path
from typing import Annotated

import typer


def _find_dbt_project(start: Path) -> Path | None:
    current = start.resolve()
    for candidate in [current, *current.parents]:
        if (candidate / "dbt_project.yml").exists():
            return candidate
    return None


def _ensure_admin_user(session_local, email: str = "admin@governor.local") -> str:
    """Create a local-mode admin user if none exists. Returns the user id."""
    from governor_web.auth import models  # type: ignore[attr-defined]
    from governor_web.auth.hashing import hash_password  # type: ignore[attr-defined]

    with session_local() as db:
        admin_role = (
            db.query(models.Role).filter(models.Role.name == "admin").one_or_none()
        )
        if admin_role is None:
            admin_role = models.Role(id=str(uuid.uuid4()), name="admin")
            db.add(admin_role)
            db.commit()
            db.refresh(admin_role)

        admin = (
            db.query(models.User)
            .join(models.User.roles)
            .filter(models.Role.id == admin_role.id)
            .order_by(models.User.created_at.asc())
            .first()
        )
        if admin:
            return admin.id

        admin = models.User(
            id=str(uuid.uuid4()),
            email=email,
            display_name="Admin",
            password_hash=hash_password("governor"),
            status="active",
        )
        db.add(admin)
        db.commit()
        db.refresh(admin)
        admin.roles.append(admin_role)
        db.commit()
        return admin.id


def _mark_setup_complete(session_local) -> None:
    """Mark SetupState.is_complete so the setup wizard is skipped."""
    from governor_web.setup.models import SetupState  # type: ignore[attr-defined]

    with session_local() as db:
        state = db.query(SetupState).first()
        if state is None:
            state = SetupState(is_complete=True, step_reached=7)
            db.add(state)
        else:
            state.is_complete = True
            state.step_reached = 7
        db.commit()


def init_command(
    project_dir: Annotated[
        Path | None,
        typer.Argument(
            help=(
                "Path to a dbt project. Defaults to the nearest ancestor that "
                "contains dbt_project.yml."
            ),
        ),
    ] = None,
    name: Annotated[
        str | None,
        typer.Option(
            "--name",
            help="Display name for the configuration (defaults to the dbt project name).",
        ),
    ] = None,
    github_repo: Annotated[
        str | None,
        typer.Option(
            "--github-repo",
            help="GitHub repo in 'owner/name' form (used when opening PRs).",
        ),
    ] = None,
) -> None:
    """Initialise a Governor configuration for the local dbt project."""
    import yaml

    from governor_cli.state import ensure_database
    from governor_core.configurations.models import ManifestConfiguration
    from governor_core.sync.models import ManifestVersion, SyncOperation
    from governor_core.workspace.detection import (
        detect_workspace,
        infer_gcp_project_from_run_results,
        read_local_manifest,
        read_local_run_results,
    )

    start = project_dir or Path.cwd()
    project_root = _find_dbt_project(start)
    if project_root is None:
        typer.secho(
            "error: no dbt_project.yml found in the current directory or any ancestor.",
            fg=typer.colors.RED,
            err=True,
        )
        raise typer.Exit(code=1)

    workspace = detect_workspace(str(project_root))
    dbt_yml = yaml.safe_load((project_root / "dbt_project.yml").read_text())
    dbt_name = dbt_yml.get("name", project_root.name)

    _, session_local = ensure_database()

    # 1) Seed admin user (for local-mode auto-login)
    admin_id = _ensure_admin_user(session_local)

    with session_local() as db:
        existing = (
            db.query(ManifestConfiguration)
            .filter(ManifestConfiguration.local_project_path == str(project_root))
            .one_or_none()
        )
        if existing:
            config = existing
            typer.secho(
                f"Configuration exists for {project_root} (id={config.id}).",
                fg=typer.colors.YELLOW,
            )
        else:
            config = ManifestConfiguration(
                id=str(uuid.uuid4()),
                name=name or workspace.dbt_project_name or dbt_name,
                manifest_source="local",
                local_project_path=str(project_root),
                github_repo=github_repo or workspace.git_repo or "",
                gcp_project_id="",
                bucket_name=None,
                path_prefix=None,
                object_name=None,
                status="active",
                created_by_id=admin_id,
                updated_by_id=admin_id,
            )
            db.add(config)
            db.commit()
            db.refresh(config)
            typer.secho(
                f"Configuration created: {config.name} (id={config.id})",
                fg=typer.colors.GREEN,
            )

        # 2) Read and store manifest + run_results if the user has run dbt
        manifest_bytes = read_local_manifest(str(project_root))
        run_results = read_local_run_results(str(project_root))
        inferred_gcp_project_id = infer_gcp_project_from_run_results(run_results)
        if inferred_gcp_project_id and config.gcp_project_id != inferred_gcp_project_id:
            config.gcp_project_id = inferred_gcp_project_id
            db.commit()

        if manifest_bytes:
            try:
                manifest_content = json.loads(manifest_bytes)
            except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                typer.secho(
                    f"warning: could not parse manifest.json: {exc}",
                    fg=typer.colors.YELLOW,
                )
                manifest_content = None

            if manifest_content is not None:
                from datetime import datetime, timezone
                from hashlib import sha256

                content_hash = sha256(
                    json.dumps(manifest_content, sort_keys=True).encode("utf-8")
                ).hexdigest()
                already = (
                    db.query(ManifestVersion)
                    .filter(
                        ManifestVersion.config_id == config.id,
                        ManifestVersion.content_hash == content_hash,
                    )
                    .one_or_none()
                )
                if already is None:
                    # The manifest version must link to a sync row so bookkeeping
                    # queries that JOIN on sync_id still work.
                    sync_op = SyncOperation(
                        id=str(uuid.uuid4()),
                        config_id=config.id,
                        status="completed",
                        triggered_by="manual_upload",
                        queued_at=datetime.now(timezone.utc),
                        started_at=datetime.now(timezone.utc),
                        completed_at=datetime.now(timezone.utc),
                        run_results_json=run_results,
                    )
                    db.add(sync_op)
                    db.flush()

                    manifest_version = ManifestVersion(
                        id=str(uuid.uuid4()),
                        config_id=config.id,
                        sync_id=sync_op.id,
                        content_hash=content_hash,
                        content=manifest_content,
                        retrieved_at=datetime.now(timezone.utc),
                    )
                    db.add(manifest_version)
                    db.commit()
                    typer.secho(
                        f"Manifest loaded ({len(manifest_bytes)} bytes).",
                        fg=typer.colors.GREEN,
                    )
                    if run_results is not None:
                        typer.secho("Run results loaded.", fg=typer.colors.GREEN)
        else:
            typer.secho(
                "note: no target/manifest.json yet — run `dbt compile` in your "
                "project, then `governor sync` to pull it in.",
                fg=typer.colors.YELLOW,
            )

    # 3) Mark setup complete so the web wizard is skipped
    _mark_setup_complete(session_local)

    typer.echo("")
    typer.secho("Setup complete.", fg=typer.colors.GREEN)
    typer.echo(
        "\nNext steps:\n"
        "  governor start      # open the local web UI at http://localhost:8000\n"
        "  governor detect     # run detection rules against the loaded manifest\n"
        "  governor status     # snapshot of syncs / opportunities / solutions\n"
    )
