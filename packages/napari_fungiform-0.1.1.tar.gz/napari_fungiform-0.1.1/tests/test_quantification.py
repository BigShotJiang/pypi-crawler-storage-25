"""Unit tests for quantification module and aligned-template helpers."""
from __future__ import annotations

import numpy as np
import pytest


def test_align_with_ncc_recovers_known_transform(synthetic_perfect_template):
    """Rotate the template by a known angle and shift it; NCC should recover both."""
    from scipy.ndimage import rotate as nd_rotate
    from detect_pattern import align_with_ncc

    H, W = synthetic_perfect_template.shape
    rotated = nd_rotate(
        synthetic_perfect_template.astype(np.float32),
        angle=12.0, reshape=False, order=1, cval=0,
    )
    target = np.zeros_like(rotated)
    target[20:, 15:] = rotated[:H - 20, :W - 15]

    rec = align_with_ncc(
        target_image=target,
        template=synthetic_perfect_template,
        coarse_step=2.0, fine_step=0.5, prior_sigma=0.5,
    )
    assert set(rec.keys()) >= {"theta_deg", "c_ref", "c_det", "score"}
    assert abs(rec["theta_deg"] - 12.0) < 1.5
    rr, cc = np.nonzero(synthetic_perfect_template)
    bbox_center = np.array([(rr.min() + rr.max()) / 2.0, (cc.min() + cc.max()) / 2.0])
    expected_det = bbox_center + np.array([20.0, 15.0])
    assert abs(rec["c_det"][0] - expected_det[0]) < 6
    assert abs(rec["c_det"][1] - expected_det[1]) < 6
    assert rec["score"] > 0.5


def test_warp_template_to_image_identity(synthetic_perfect_template):
    """With c_ref == c_det and theta=0, warped template == original."""
    from quantification import warp_template_to_image

    out_shape = synthetic_perfect_template.shape
    c = np.array([float(synthetic_perfect_template.shape[0]) / 2,
                  float(synthetic_perfect_template.shape[1]) / 2])

    warped = warp_template_to_image(
        synthetic_perfect_template,
        theta_deg=0.0,
        c_ref=c, c_det=c, output_shape=out_shape,
    )
    overlap = (warped & synthetic_perfect_template).sum()
    union = (warped | synthetic_perfect_template).sum()
    assert overlap / union > 0.98


def test_warp_template_to_image_rotation_recovery(
    synthetic_perfect_template, synthetic_head_template, synthetic_stem_template,
):
    """Rotate template by 15 deg and shift it; recover transform with NCC; warp
    head/stem with the recovered transform."""
    from scipy.ndimage import rotate as nd_rotate
    from detect_pattern import align_with_ncc
    from quantification import warp_template_to_image

    rotated = nd_rotate(
        synthetic_perfect_template.astype(np.float32),
        angle=15.0, reshape=False, order=1, cval=0,
    )
    H, W = rotated.shape
    target = np.zeros_like(rotated)
    target[10:, 8:] = rotated[:H - 10, :W - 8]

    rec = align_with_ncc(
        target_image=target, template=synthetic_perfect_template,
        coarse_step=2.0, fine_step=0.5, prior_sigma=0.5,
    )

    warped_head = warp_template_to_image(
        synthetic_head_template, theta_deg=rec["theta_deg"],
        c_ref=rec["c_ref"], c_det=rec["c_det"], output_shape=target.shape,
    )
    warped_stem = warp_template_to_image(
        synthetic_stem_template, theta_deg=rec["theta_deg"],
        c_ref=rec["c_ref"], c_det=rec["c_det"], output_shape=target.shape,
    )

    rotated_perfect_bin = rotated > 0.5
    target_perfect_bin = np.zeros_like(rotated_perfect_bin)
    target_perfect_bin[10:, 8:] = rotated_perfect_bin[:H - 10, :W - 8]

    combined = warped_head | warped_stem
    iou = (combined & target_perfect_bin).sum() / (combined | target_perfect_bin).sum()
    assert iou > 0.7
    assert warped_head.sum() > 100
    assert warped_stem.sum() > 100


def test_build_aligned_regions_identity(
    synthetic_perfect_template, synthetic_head_template, synthetic_stem_template,
):
    """With zero transform, regions match input templates."""
    from quantification import build_aligned_regions

    H, W = synthetic_perfect_template.shape
    c = np.array([H / 2, W / 2])

    regions = build_aligned_regions(
        head_template=synthetic_head_template,
        stem_template=synthetic_stem_template,
        theta_deg=0.0,
        c_ref=c, c_det=c, output_shape=(H, W),
        stem_tip_fraction=0.25,
    )

    assert "head" in regions and "stem" in regions and "stem_tip" in regions
    assert "stem_axis" in regions
    assert "stem_base_point" in regions
    assert "stem_tip_point" in regions

    assert (regions["stem_tip"] & ~regions["stem"]).sum() == 0
    ratio = regions["stem_tip"].sum() / regions["stem"].sum()
    assert 0.18 <= ratio <= 0.32

    axis = regions["stem_axis"]
    assert abs(axis[0] - 1.0) < 0.05
    assert abs(axis[1]) < 0.05

    base = regions["stem_base_point"]
    tip = regions["stem_tip_point"]
    assert tip[0] < base[0]


def test_measure_region_intensity_uniform(
    synthetic_cell_mask, synthetic_protein, synthetic_head_template,
    synthetic_stem_template,
):
    """Synthetic protein: 100 in stem (rows<230), 800 in head (rows>=230).
    Background outside cell = 50.
    """
    from quantification import measure_region_intensity

    # Cell-only ROI
    cell_only = synthetic_cell_mask
    # head & cell
    head_in_cell = synthetic_head_template & cell_only
    # stem & cell
    stem_in_cell = synthetic_stem_template & cell_only

    head_metrics = measure_region_intensity(
        synthetic_protein, region_mask=head_in_cell,
        cell_mask=cell_only, pixel_size=1.0, label="Head",
    )
    stem_metrics = measure_region_intensity(
        synthetic_protein, region_mask=stem_in_cell,
        cell_mask=cell_only, pixel_size=1.0, label="Stem",
    )

    # Head should be ~800
    assert abs(head_metrics["Protein_Head_Mean"] - 800) < 5
    # Stem should be ~100
    assert abs(stem_metrics["Protein_Stem_Mean"] - 100) < 5
    # IntDen = mean × area
    assert abs(head_metrics["Protein_Head_IntDen"]
               - head_metrics["Protein_Head_Mean"] * head_in_cell.sum()) < 1
    # Fractions sum behavior — head fraction > stem fraction
    assert head_metrics["Protein_Head_Fraction"] > stem_metrics["Protein_Stem_Fraction"]
    # Fractions in [0, 1]
    for m in (head_metrics, stem_metrics):
        for k, v in m.items():
            if k.endswith("_Fraction"):
                assert 0.0 <= v <= 1.0


def test_measure_region_intensity_empty(synthetic_cell_mask, synthetic_protein):
    from quantification import measure_region_intensity

    empty = np.zeros_like(synthetic_cell_mask)
    metrics = measure_region_intensity(
        synthetic_protein, region_mask=empty,
        cell_mask=synthetic_cell_mask, pixel_size=0.5, label="Empty",
    )
    assert metrics["Protein_Empty_Mean"] == 0.0
    assert metrics["Protein_Empty_IntDen"] == 0.0
    assert metrics["Protein_Empty_Fraction"] == 0.0


def test_stem_extension_known_geometry(synthetic_cell_mask, synthetic_stem_template):
    """Stem template rows 80..220, cell mask is template dilated by 5 px.
    Stem axis is vertical (1, 0). Stem base point is around row 220 (overlap with head).
    Topmost cell pixel within stem region should be near row 75 (220 - 145 dilated).
    """
    from quantification import compute_stem_extension

    H, W = synthetic_cell_mask.shape
    cx = W // 2
    # Construct minimal aligned regions for this test
    # Stem axis pointing down
    stem_axis = np.array([1.0, 0.0])
    stem_base_point = np.array([220.0, float(cx)])  # bottom of stem

    extension_um = compute_stem_extension(
        cell_mask=synthetic_cell_mask,
        stem_mask=synthetic_stem_template,
        stem_base_point=stem_base_point,
        stem_axis=stem_axis,
        pixel_size=1.0,
    )
    # Cell mask is template dilated by 5; topmost stem-overlapping cell row ≈ 75
    # Distance from base (row 220) to top (row ~75) along axis = ~145
    assert 130 < extension_um < 160


def test_protein_extension_no_signal_beyond_tip(synthetic_protein):
    """If protein signal does not extend above stem tip, extension is negative."""
    from quantification import compute_protein_extension

    # Set stem-tip point above all signal
    H, W = synthetic_protein.shape
    stem_tip_point = np.array([10.0, float(W // 2)])  # very top of image
    stem_axis = np.array([1.0, 0.0])

    ext = compute_protein_extension(
        protein_ch=synthetic_protein,
        signal_threshold=200,  # only head pixels exceed this
        stem_tip_point=stem_tip_point,
        stem_axis=stem_axis,
        pixel_size=1.0,
        column_window_px=50,
    )
    # Signal exists only around rows 230+ (head); stem tip at row 10.
    # Topmost signal row > stem tip row → extension is negative.
    assert ext < 0


def test_protein_extension_signal_above_tip():
    """Construct protein channel with signal above and below stem tip."""
    from quantification import compute_protein_extension

    H, W = 400, 400
    cx = W // 2
    img = np.zeros((H, W), dtype=np.uint16)
    # Bright pixel at row 50, col cx (above stem tip at row 80)
    img[50, cx] = 5000
    # Bright pixels at row 200 (well below)
    img[200, cx - 5:cx + 5] = 5000

    stem_tip_point = np.array([80.0, float(cx)])
    stem_axis = np.array([1.0, 0.0])

    ext = compute_protein_extension(
        protein_ch=img,
        signal_threshold=2000,
        stem_tip_point=stem_tip_point,
        stem_axis=stem_axis,
        pixel_size=1.0,
        column_window_px=20,
    )
    # Topmost signal row 50; stem tip row 80; signal extends 30 px above tip.
    assert 28 < ext < 32


def test_detect_protrusions_known_finger():
    """Cell = round head + one finger sticking out — expect 1 protrusion.

    Uses a round (not mushroom-shaped) cell so that the rolling-ball opening
    smooths the cell back to itself; the only structure that survives
    ``cell AND NOT body`` is the finger.
    """
    from quantification import detect_head_protrusions_rolling_ball

    H, W = 400, 400
    cx = W // 2

    yy, xx = np.ogrid[:H, :W]
    head = ((yy - 300) ** 2 + (xx - cx) ** 2 <= 60 ** 2)

    # Cell = head circle + a single finger sticking downward.
    cell = head.copy()
    cell[360:390, cx - 4:cx + 4] = True

    protrusions, _body, _mic, _R = detect_head_protrusions_rolling_ball(
        cell_mask=cell,
        head_mask=head,
        ball_radius_fraction=0.25,
        min_area_px=20,
        head_dilation_px=30,
    )
    assert len(protrusions) == 1
    p = protrusions[0]
    # Connected-component area of the finger ≈ 30 × 8 = 240 px
    assert 200 < p["area_px"] <= 300
    # Bounding box rows from ~360 to ~390
    assert p["bbox"][0] >= 358 and p["bbox"][2] <= 392


def test_measure_protrusion_length_and_angle_vertical():
    """A vertical 30-px finger pointing downward (along stem axis) should have
    length ≈ 30 px and angle ≈ 180° (downward = +stem axis = 0°? we define
    angle relative to stem axis so axis-parallel = 0°)."""
    from quantification import measure_protrusion

    H, W = 400, 400
    cx = W // 2
    comp = np.zeros((H, W), dtype=bool)
    # Finger: 8 px wide, 30 px long
    comp[360:390, cx - 4:cx + 4] = True

    head_mask = np.zeros_like(comp)
    yy, xx = np.ogrid[:H, :W]
    head_mask = ((yy - 300) ** 2 + (xx - cx) ** 2 <= 60 ** 2)

    stem_axis = np.array([1.0, 0.0])  # downward

    metrics = measure_protrusion(
        component_mask=comp,
        head_mask=head_mask,
        stem_axis=stem_axis,
        pixel_size=1.0,
    )
    # Length should be ~30 (skeleton of 30-px-long bar, allowing some endpoint loss)
    assert 25 <= metrics["length_um"] <= 35
    # Direction is ~downward → close to stem axis → angle ≈ 0°
    assert abs(metrics["angle_deg"]) < 15.0


def test_measure_protrusion_length_and_angle_lateral():
    """A 25-px horizontal finger should have length ≈ 25 and angle ≈ 90°."""
    from quantification import measure_protrusion

    H, W = 400, 400
    cx = W // 2
    comp = np.zeros((H, W), dtype=bool)
    # Horizontal finger sticking right out of head edge
    comp[300:308, cx + 60:cx + 85] = True
    yy, xx = np.ogrid[:H, :W]
    head_mask = ((yy - 300) ** 2 + (xx - cx) ** 2 <= 60 ** 2)

    metrics = measure_protrusion(
        component_mask=comp, head_mask=head_mask,
        stem_axis=np.array([1.0, 0.0]), pixel_size=1.0,
    )
    assert 20 <= metrics["length_um"] <= 30
    assert 75 <= abs(metrics["angle_deg"]) <= 105


def test_summarize_protrusions_empty():
    from quantification import summarize_protrusions
    out = summarize_protrusions([], head_mask=np.zeros((10, 10), dtype=bool),
                                stem_axis=np.array([1.0, 0.0]), pixel_size=1.0)
    assert out["Protrusion_Count"] == 0
    assert out["Protrusion_MaxLength_um"] == 0.0
    assert out["_per_protrusion"] == []


def test_segment_nucleus_finds_blob(synthetic_nucleus, synthetic_cell_mask):
    """Synthetic DAPI Gaussian blob inside cell — segmentation should produce
    a non-empty mask wholly inside the cell."""
    from quantification import segment_nucleus

    nuc_mask = segment_nucleus(synthetic_nucleus, synthetic_cell_mask, min_area_px=50)
    assert nuc_mask.sum() > 100
    # Nuclear mask must be inside cell
    assert (nuc_mask & ~synthetic_cell_mask).sum() == 0


def test_compute_nuc_cyt_ratio_uniform():
    """If protein is uniform inside cell, nuc/cyt ratio ≈ 1."""
    from quantification import compute_nuc_cyt_ratio

    H, W = 200, 200
    cell = np.zeros((H, W), dtype=bool)
    cell[40:160, 40:160] = True
    nuc = np.zeros_like(cell)
    nuc[80:120, 80:120] = True

    protein = np.zeros((H, W), dtype=np.uint16)
    protein[cell] = 500

    metrics = compute_nuc_cyt_ratio(protein, nuc_mask=nuc, cell_mask=cell,
                                    pixel_size=1.0)
    assert abs(metrics["Protein_NucCyt_Ratio"] - 1.0) < 0.05
    assert metrics["Nuclear_Area_um2"] == nuc.sum()


def test_compute_nuc_cyt_ratio_empty_nucleus():
    from quantification import compute_nuc_cyt_ratio
    H, W = 100, 100
    cell = np.zeros((H, W), dtype=bool)
    cell[20:80, 20:80] = True
    protein = np.full((H, W), 100, dtype=np.uint16)

    metrics = compute_nuc_cyt_ratio(protein, nuc_mask=np.zeros_like(cell),
                                    cell_mask=cell, pixel_size=1.0)
    assert metrics["Nuclear_Area_um2"] == 0
    assert metrics["Protein_Nuclear_Mean"] == 0.0
    assert metrics["Protein_NucCyt_Ratio"] == 0.0


def test_quantify_cell_end_to_end(
    synthetic_cell_mask, synthetic_perfect_template, synthetic_head_template,
    synthetic_stem_template, synthetic_protein, synthetic_nucleus,
):
    """End-to-end: identity transform, all metrics computed, no crashes."""
    from quantification import quantify_cell, build_aligned_regions

    H, W = synthetic_cell_mask.shape
    c = np.array([H / 2, W / 2])
    regions = build_aligned_regions(
        head_template=synthetic_head_template,
        stem_template=synthetic_stem_template,
        theta_deg=0.0,
        c_ref=c, c_det=c, output_shape=(H, W),
    )

    metrics = quantify_cell(
        cell_mask=synthetic_cell_mask,
        regions=regions,
        protein_ch=synthetic_protein,
        nucleus_ch=synthetic_nucleus,
        pixel_size=1.0,
        protein_threshold=200,
    )

    expected_keys = {
        "Protein_Whole_Mean",
        "Protein_Head_Mean", "Protein_Head_IntDen", "Protein_Head_Fraction",
        "Protein_Stem_Mean", "Protein_Stem_IntDen", "Protein_Stem_Fraction",
        "Protein_StemTip_Mean", "Protein_StemTip_IntDen", "Protein_StemTip_Fraction",
        "StemExtension_um", "ProteinExtension_um",
        "Protrusion_Count", "Protrusion_TotalLength_um",
        "Protrusion_MaxLength_um", "Protrusion_MeanLength_um",
        "Protrusion_MeanAngleDeg",
        "Nuclear_Area_um2", "Protein_Nuclear_Mean", "Protein_Cytoplasmic_Mean",
        "Protein_NucCyt_Ratio",
    }
    assert expected_keys.issubset(metrics.keys())
    # Sanity: head protein should be much higher than stem protein
    assert metrics["Protein_Head_Mean"] > metrics["Protein_Stem_Mean"]
    # Stem extension should be > 0 (cell extends into stem)
    assert metrics["StemExtension_um"] > 0
