"""End-to-end smoke test: synthetic 4-channel TIFF → automated_pipeline → CSV + QC."""
from __future__ import annotations
import subprocess
import sys
from pathlib import Path

import numpy as np
import tifffile


def _make_synthetic_4ch_tiff(dst: Path, size: int = 400):
    """Build a tiny 4-channel TIFF with a recognisable pattern."""
    H = W = size
    cx = W // 2
    yy, xx = np.ogrid[:H, :W]

    # CellBorder (C1): bright ring around mushroom
    cell = np.zeros((H, W), dtype=np.uint16)
    pattern = np.zeros((H, W), dtype=bool)
    pattern[80:240, cx - 15:cx + 15] = True
    pattern |= ((yy - 300) ** 2 + (xx - cx) ** 2 <= 70 ** 2)
    from scipy.ndimage import binary_dilation, binary_erosion
    ring = binary_dilation(pattern, iterations=5) & ~binary_erosion(pattern, iterations=2)
    cell[ring] = 5000

    # Protein (C2): bright in head, dim in stem
    protein = np.zeros((H, W), dtype=np.uint16)
    protein[pattern & (yy >= 230)] = 3000
    protein[pattern & (yy < 230)] = 500

    # Nucleus (C3): blob at head center
    nuc = (np.exp(-((yy - 290) ** 2 + (xx - cx) ** 2) / (2 * 30 ** 2)) * 4000).astype(np.uint16)

    # Pattern (C4): a noisy version of the pattern
    pattern_ch = (pattern.astype(np.uint16) * 8000
                  + np.random.default_rng(0).integers(0, 200, (H, W)))

    stack = np.stack([cell, protein, nuc, pattern_ch], axis=0).astype(np.uint16)
    tifffile.imwrite(dst, stack)


def test_pipeline_runs_end_to_end(tmp_path):
    project_root = Path(__file__).parent.parent
    in_dir = tmp_path / "in"
    in_dir.mkdir()
    out_dir = tmp_path / "out"

    _make_synthetic_4ch_tiff(in_dir / "synthetic.tif")

    # Save synthetic templates that match what _make_synthetic_4ch_tiff used
    H = W = 400
    cx = W // 2
    yy, xx = np.ogrid[:H, :W]
    pattern = np.zeros((H, W), dtype=bool)
    pattern[80:240, cx - 15:cx + 15] = True
    pattern |= ((yy - 300) ** 2 + (xx - cx) ** 2 <= 70 ** 2)
    head = ((yy - 300) ** 2 + (xx - cx) ** 2 <= 70 ** 2)
    stem = np.zeros((H, W), dtype=bool)
    stem[80:220, cx - 15:cx + 15] = True

    ref_path = tmp_path / "ref.tiff"
    head_path = tmp_path / "head.tiff"
    stem_path = tmp_path / "stem.tiff"
    tifffile.imwrite(ref_path, (pattern.astype(np.uint8) * 255))
    tifffile.imwrite(head_path, (head.astype(np.uint8) * 255))
    tifffile.imwrite(stem_path, (stem.astype(np.uint8) * 255))

    # Run pipeline with NCC alignment using our synthetic templates
    cmd = [
        sys.executable, str(project_root / "src" / "automated_pipeline.py"),
        "--dir", str(in_dir),
        "--out", str(out_dir),
        "--pattern-template", str(ref_path),
        "--head-template", str(head_path),
        "--stem-template", str(stem_path),
        "--coarse-step", "5.0",
        "--fine-step", "1.0",
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, cwd=project_root)
    assert result.returncode == 0, f"stdout:\n{result.stdout}\nstderr:\n{result.stderr}"

    csv_path = out_dir / "_allResults.csv"
    assert csv_path.exists()
    contents = csv_path.read_text()
    # Header must include new columns
    assert "Protein_Head_Mean" in contents
    assert "Protrusion_Count" in contents
    assert "Protein_NucCyt_Ratio" in contents
