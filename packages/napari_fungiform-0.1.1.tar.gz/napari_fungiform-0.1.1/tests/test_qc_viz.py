"""Smoke tests for qc_viz: outputs are produced and have non-zero size."""
from __future__ import annotations
from pathlib import Path

import numpy as np


def test_save_cell_qc_png_creates_file(
    tmp_path, synthetic_cell_mask, synthetic_perfect_template,
    synthetic_head_template, synthetic_stem_template,
    synthetic_protein, synthetic_nucleus,
):
    from quantification import quantify_cell, build_aligned_regions
    from qc_viz import save_cell_qc_png

    H, W = synthetic_cell_mask.shape
    c = np.array([H / 2, W / 2])
    regions = build_aligned_regions(
        head_template=synthetic_head_template,
        stem_template=synthetic_stem_template,
        theta_deg=0.0,
        c_ref=c, c_det=c, output_shape=(H, W),
    )
    metrics = quantify_cell(
        cell_mask=synthetic_cell_mask,
        regions=regions,
        protein_ch=synthetic_protein,
        nucleus_ch=synthetic_nucleus,
        pixel_size=1.0,
    )

    dst = tmp_path / "test_cell_qc.png"
    save_cell_qc_png(
        cell_mask=synthetic_cell_mask,
        cell_id="TEST_Cell_1",
        regions=regions,
        protein_ch=synthetic_protein,
        nucleus_ch=synthetic_nucleus,
        metrics=metrics,
        dst=dst,
    )
    assert dst.exists()
    assert dst.stat().st_size > 10_000  # non-trivial PNG
