"""Smoke tests for the napari pipeline widget.

These tests are skipped when napari or Qt isn't available, but the underlying
pipeline-state and IO helpers are tested directly without a Qt event loop.
"""

from __future__ import annotations

import os
import sys
import threading
from pathlib import Path

import numpy as np
import pytest

from fungiform._state import PipelineState


def test_pipeline_state_invalidation():
    s = PipelineState(title="t", channels={"cell": np.zeros((4, 4))}, pixel_size=1.0)
    s.quantification = object()  # type: ignore[assignment]
    s.reset_downstream("alignment")
    assert s.quantification is None


def test_split_channels_role_mapping():
    from fungiform._io import split_channels

    stack = np.stack([np.full((3, 3), i, dtype=np.uint16) for i in range(4)], axis=0)
    out = split_channels(stack, {"cell": 1, "protein": 2, "nucleus": 3, "pattern": 4})
    assert out["cell"][0, 0] == 0
    assert out["protein"][0, 0] == 1
    assert out["nucleus"][0, 0] == 2
    assert out["pattern"][0, 0] == 3


def test_split_channels_bad_index():
    from fungiform._io import split_channels

    stack = np.zeros((2, 3, 3), dtype=np.uint16)
    with pytest.raises(IndexError):
        split_channels(stack, {"cell": 5})


@pytest.mark.skipif(
    bool(os.environ.get("CI")) and sys.platform == "darwin",
    reason="napari.Viewer() segfaults under vispy/OpenGL on headless macOS CI",
)
def test_widget_constructs():
    """Widget construction smoke test (requires Qt). Skipped headless."""
    qtpy = pytest.importorskip("qtpy.QtWidgets")
    pytest.importorskip("napari")
    from napari import Viewer

    app = qtpy.QApplication.instance() or qtpy.QApplication([])
    viewer = Viewer(show=False)
    try:
        from fungiform._widget import PipelineWidget

        w = PipelineWidget(viewer=viewer)
        assert w is not None
        # Default channel mapping
        assert w._channel_mapping() == {"cell": 1, "protein": 2, "nucleus": 3, "pattern": 4}
    finally:
        viewer.close()


def test_batch_runner_with_synthetic_state(tmp_path, monkeypatch):
    """Exercise the batch runner with a fake task that succeeds + a cancel."""
    from fungiform import _batch

    class _NoopTask:
        name = "noop"
        def run(self, state, params, log):
            return state

    monkeypatch.setitem(_batch.TASK_MAP, "noop", _NoopTask)

    # Build two fake items by patching load_item.
    fake_array = np.zeros((4, 8, 8), dtype=np.uint16)

    def fake_load(item):
        return fake_array, 1.0

    monkeypatch.setattr(_batch, "load_item", fake_load)

    import logging
    log = logging.getLogger("test")

    items = [
        _batch.ImageItem(title="a", layout="merged", path=Path("a.tif")),
        _batch.ImageItem(title="b", layout="merged", path=Path("b.tif")),
    ]
    events = list(_batch.run_batch(
        items, ["noop"],
        params={"output_dir": str(tmp_path)},
        channel_mapping={"cell": 1, "protein": 2, "nucleus": 3, "pattern": 4},
        output_dir=tmp_path,
        cancel_event=threading.Event(),
        log=log,
    ))
    progress = [e for e in events if e[0] == "progress"]
    assert progress[-1][1:3] == (2, 2)
    assert (tmp_path / "run_manifest.json").exists()
