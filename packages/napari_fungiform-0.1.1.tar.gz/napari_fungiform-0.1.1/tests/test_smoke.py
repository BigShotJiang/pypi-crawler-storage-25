def test_fixtures_load(synthetic_perfect_template, synthetic_cell_mask,
                      synthetic_protein, synthetic_nucleus):
    assert synthetic_perfect_template.dtype == bool
    assert synthetic_perfect_template.sum() > 0
    assert synthetic_cell_mask.sum() > synthetic_perfect_template.sum()
    assert synthetic_protein.shape == synthetic_perfect_template.shape
    assert synthetic_nucleus.max() > 1000
