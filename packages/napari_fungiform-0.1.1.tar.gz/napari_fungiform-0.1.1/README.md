# Fungiform

[![Python](https://img.shields.io/badge/python-3.10%20%7C%203.11%20%7C%203.12-blue.svg)](https://www.python.org/)
[![License: BSD-3](https://img.shields.io/badge/License-BSD%203--Clause-blue.svg)](LICENSE)
[![CI](https://github.com/lxfhfut/Fungiform/actions/workflows/test.yml/badge.svg)](https://github.com/lxfhfut/Fungiform/actions/workflows/test.yml)

A napari plugin and CLI for **quantifying cell shape and protein distribution
on micropatterned substrates**. Designed for multi-channel fluorescence
confocal images of cells grown on mushroom-shaped fibronectin micropatterns.

Fungiform aligns a canonical pattern template to each image via normalised
cross-correlation, warps head / stem / stem-tip sub-regions into image
coordinates, segments cells in the cell-border channel, and reports a rich
per-cell table of region-based protein intensities, stem-axis geometry,
head-region protrusions, and nuclear / cytoplasmic ratios.

## Installation

```bash
pip install napari-fungiform
```

Or from source:

```bash
git clone https://github.com/lxfhfut/Fungiform.git
cd Fungiform
pip install -e .
```

Python ≥ 3.10 required.

## Quick start

### Napari plugin

```bash
napari
```

Then open **Plugins → Fungiform**. The widget has two sections:

- **Single Input** — point at a single 4-channel TIFF (merged layout) or a
  folder containing per-channel siblings `*_C0.tif … *_C3.tif` (split layout).
- **Batch** — point at a folder of images; outputs go to `<folder>/results/`
  by default.

### CLI

```bash
fungiform --dir ./my_images --out ./results
```

Common flags:

| Flag | Default | Effect |
|------|---------|--------|
| `--split-channels` | off | Inputs are split per channel (`*_C0..C3.tif`) |
| `--channel-cell` | 1 | 1-indexed cell-border channel (e.g. WGA) |
| `--channel-protein` | 2 | Protein-of-interest channel |
| `--channel-nucleus` | 3 | Nucleus channel (e.g. DAPI) |
| `--channel-pattern` | 4 | Pattern channel (e.g. fibronectin) |
| `--ball-radius-fraction` | 0.25 | Rolling-ball radius as fraction of cell's MIC |
| `--no-align` | off | Skip NCC alignment (use when no pattern channel) |

Run `fungiform --help` for the full option list.

## Output

For each input image `MAX_<title>.tif`, Fungiform writes into the output
directory:

```
_allResults.csv                          # one row per detected cell
MAX_<title>_Cell_mask.jpg                # labeled segmentation mask
MAX_<title>_mask_overlay.jpg             # cell channel + segmentation overlay
MAX_<title>_image_qc.png                 # 3-panel per-image overview
qc_cells/<Label>_qc.png                  # 6-panel per-cell QC
protrusions/<Label>_protrusions.png      # per-cell protrusion detail
protrusions/MAX_<title>_protrusions.png  # rolling-ball multi-cell detail
protrusions/MAX_<title>_protrusions_overview.png
```

See **[docs/Results_interpretations.md](docs/Results_interpretations.md)** for
a column-by-column description of `_allResults.csv` and a panel-by-panel guide
to every visualisation.

## Pattern templates

Fungiform ships with default mushroom-pattern templates (perfect / head /
stem) under `src/fungiform/templates/`. To use your own pattern shape, supply
`--pattern-template`, `--head-template`, and `--stem-template` pointing at
TIFF masks.

## Citation

If you use Fungiform in your research, please cite this repository:

```bibtex
@software{fungiform,
  author = {Lin, Xufeng},
  title  = {Fungiform: Napari plugin for micropattern cell quantification},
  url    = {https://github.com/lxfhfut/Fungiform},
  year   = {2026}
}
```

## License

BSD 3-Clause — see [LICENSE](LICENSE).
