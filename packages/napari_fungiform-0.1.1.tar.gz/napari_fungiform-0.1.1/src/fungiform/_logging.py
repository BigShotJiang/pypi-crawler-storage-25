"""Logging utilities: route to a Qt text widget + an optional file."""

from __future__ import annotations

import html
import logging
from pathlib import Path

from qtpy.QtCore import QObject, Signal


LOGGER_NAME = "gui"

# Solarised-ish, readable on both light and dark Qt themes.
LEVEL_COLOURS = {
    logging.DEBUG:    "#6b7280",
    logging.INFO:     "#2e7d32",
    logging.WARNING:  "#b8860b",
    logging.ERROR:    "#c62828",
    logging.CRITICAL: "#7b1fa2",
}
LEVEL_TAGS = {
    logging.DEBUG:    "DBG",
    logging.INFO:     "INFO",
    logging.WARNING:  "WARN",
    logging.ERROR:    "ERR ",
    logging.CRITICAL: "CRIT",
}


class QtLogBridge(QObject):
    """Qt signal emitter that a ``QTextEdit`` can subscribe to."""

    message = Signal(str)  # HTML-formatted line


class _QtLogHandler(logging.Handler):
    def __init__(self, bridge: QtLogBridge) -> None:
        super().__init__()
        self.bridge = bridge

    def emit(self, record: logging.LogRecord) -> None:
        try:
            self.bridge.message.emit(self._format_html(record))
        except Exception:
            pass

    @staticmethod
    def _format_html(record: logging.LogRecord) -> str:
        import time as _time
        ts = _time.strftime("%H:%M:%S", _time.localtime(record.created))
        colour = LEVEL_COLOURS.get(record.levelno, "#444")
        tag = LEVEL_TAGS.get(record.levelno, record.levelname[:4])
        msg = html.escape(record.getMessage())
        if record.exc_info:
            msg += "<br>" + html.escape(
                logging.Formatter().formatException(record.exc_info)
            ).replace("\n", "<br>")
        return (
            f'<span style="color:#888">{ts}</span> '
            f'<span style="color:{colour};font-weight:600">{tag}</span> '
            f'<span>{msg}</span>'
        )


def get_logger() -> logging.Logger:
    log = logging.getLogger(LOGGER_NAME)
    if not log.handlers:
        log.setLevel(logging.INFO)
        log.propagate = False
    return log


def attach_qt_bridge(bridge: QtLogBridge) -> _QtLogHandler:
    log = get_logger()
    handler = _QtLogHandler(bridge)
    log.addHandler(handler)
    return handler


def attach_file_handler(path: Path) -> logging.FileHandler:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    log = get_logger()
    fh = logging.FileHandler(path, mode="a", encoding="utf-8")
    fh.setFormatter(logging.Formatter("%(asctime)s  %(levelname)s  %(message)s"))
    log.addHandler(fh)
    return fh


def detach_handler(handler: logging.Handler) -> None:
    get_logger().removeHandler(handler)
    try:
        handler.close()
    except Exception:
        pass
