"""Batch runner: iterates ImageItems and runs selected tasks off the GUI thread."""

from __future__ import annotations

import json
import logging
import platform
import threading
import time
import traceback
from pathlib import Path
from typing import Iterable

import numpy as np

from ._io import ImageItem, load_item, split_channels
from ._state import PipelineState
from ._tasks import AlignmentTask, QuantificationTask, SegmentationTask


TASK_MAP = {
    "alignment": AlignmentTask,
    "segmentation": SegmentationTask,
    "quantification": QuantificationTask,
}


def run_batch(
    items: list[ImageItem],
    tasks: list[str],
    params: dict,
    channel_mapping: dict[str, int],
    output_dir: Path,
    cancel_event: threading.Event,
    log: logging.Logger,
):
    """Generator yielding (kind, *payload) tuples for the widget to dispatch.

    Yields:
        ("progress", i, n, title)
        ("log", message)
        ("state", final_state) — only for the last successfully processed image
        ("error", title, traceback_str)
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    task_objs = [TASK_MAP[t]() for t in tasks]
    manifest = {
        "input_count": len(items),
        "tasks": tasks,
        "channel_mapping": channel_mapping,
        "params": {k: _jsonable(v) for k, v in params.items()},
        "host": platform.node(),
        "start": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "results": [],
    }

    final_state: PipelineState | None = None
    n = len(items)
    for i, item in enumerate(items):
        if cancel_event.is_set():
            log.info("Batch cancelled before %s", item.title)
            break
        try:
            yield ("log", f"[{i+1}/{n}] {item.title} loading")
            projected, pixel_size = load_item(item)
            channels = split_channels(projected, channel_mapping)
            state = PipelineState(
                title=item.title,
                src_path=item.path if item.layout == "merged" else None,
                channels=channels,
                pixel_size=pixel_size,
            )
            # Quantification needs an output dir.
            params_for_run = dict(params)
            params_for_run.setdefault("output_dir", str(output_dir))

            for task in task_objs:
                if cancel_event.is_set():
                    break
                task.run(state, params_for_run, log)

            manifest["results"].append({"title": item.title, "ok": True})
            final_state = state
        except Exception as e:
            tb = traceback.format_exc()
            log.error("[%s] failed: %s\n%s", item.title, e, tb)
            manifest["results"].append({"title": item.title, "ok": False, "error": str(e)})
            yield ("error", item.title, tb)
        yield ("progress", i + 1, n, item.title)

    manifest["end"] = time.strftime("%Y-%m-%dT%H:%M:%S")
    try:
        with open(output_dir / "run_manifest.json", "w") as f:
            json.dump(manifest, f, indent=2)
    except Exception as e:
        log.warning("failed to write run_manifest.json: %s", e)

    if final_state is not None:
        yield ("state", final_state)


def _jsonable(v):
    if isinstance(v, (str, int, float, bool)) or v is None:
        return v
    if isinstance(v, (list, tuple)):
        return [_jsonable(x) for x in v]
    if isinstance(v, dict):
        return {str(k): _jsonable(x) for k, x in v.items()}
    if isinstance(v, np.ndarray):
        return v.tolist()
    return str(v)
