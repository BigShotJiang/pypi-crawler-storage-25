"""Main dockable QWidget for the Cell Pattern Pipeline plugin."""

from __future__ import annotations

import threading
from pathlib import Path
from typing import Any

import numpy as np
from qtpy.QtCore import Qt
from qtpy.QtWidgets import (
    QAbstractSpinBox,
    QButtonGroup,
    QCheckBox,
    QComboBox,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPlainTextEdit,
    QTextEdit,
    QProgressBar,
    QPushButton,
    QRadioButton,
    QScrollArea,
    QSizePolicy,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)

from ._batch import run_batch
from ._io import ImageItem, discover_batch, load_item, split_channels
from ._logging import (
    QtLogBridge, attach_qt_bridge, attach_file_handler, detach_handler, get_logger,
)
from ._state import PipelineState
from ._tasks import AlignmentTask, QuantificationTask, SegmentationTask

try:
    from napari.qt.threading import thread_worker
except ImportError:  # pragma: no cover - imported in napari runtime
    thread_worker = None


# Display order matches the biological channel order.
CHANNEL_ORDER = ("cell", "protein", "nucleus", "pattern")
CHANNEL_COLORMAPS = {
    "cell": "red",
    "protein": "green",
    "nucleus": "blue",
    "pattern": "yellow",
}
CHANNEL_OPACITY = {
    "cell": 1.0,
    "protein": 0.85,
    "nucleus": 0.75,
    "pattern": 0.6,
}


class PipelineWidget(QWidget):
    """The dockable pipeline widget."""

    def __init__(
        self,
        napari_viewer: Any = None,
        viewer: Any = None,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        # napari passes the viewer as ``napari_viewer`` when instantiating
        # plugin widgets; fall back to the global current viewer if neither
        # kw was supplied (e.g. constructed manually from a script).
        self.viewer = napari_viewer or viewer
        if self.viewer is None:
            try:
                import napari
                self.viewer = napari.current_viewer()
            except Exception:
                self.viewer = None
        self.state: PipelineState | None = None
        self._cancel_event = threading.Event()
        self._worker = None

        # Logging bridge to the on-widget panel.
        self._log_bridge = QtLogBridge()
        self._log_handler = attach_qt_bridge(self._log_bridge)
        self._file_handler = None
        self.log = get_logger()
        self._log_bridge.message.connect(self._append_log)

        self._build_ui()
        self._maximize_viewer_window()

    def _maximize_viewer_window(self) -> None:
        """Show the napari main window maximized when the widget loads."""
        try:
            win = getattr(self.viewer, "window", None)
            qt_win = getattr(win, "_qt_window", None) if win is not None else None
            if qt_win is not None:
                from qtpy.QtCore import QTimer
                QTimer.singleShot(0, qt_win.showMaximized)
        except Exception:
            pass

    def sizeHint(self):  # noqa: D401
        from qtpy.QtCore import QSize
        return QSize(440, 600)

    def minimumSizeHint(self):
        from qtpy.QtCore import QSize
        return QSize(420, 400)

    # -- UI construction ---------------------------------------------------

    @staticmethod
    def _set_path(edit: QLineEdit, path: str | Path) -> None:
        """Display the full path; scroll to the tail so the filename is visible."""
        p = Path(str(path)).expanduser()
        s = str(p)
        edit.setProperty("full_path", s)
        edit.setText(s)
        edit.setToolTip(s)
        edit.setCursorPosition(len(s))

    @staticmethod
    def _get_path(edit: QLineEdit) -> str:
        """Return the visible text (full path)."""
        return edit.text().strip()

    @staticmethod
    def _compact(w):
        """Cap a numeric input's width so it doesn't stretch the parent."""
        if isinstance(w, QAbstractSpinBox):
            w.setMaximumWidth(70)
            w.setButtonSymbols(QAbstractSpinBox.NoButtons)
        else:
            w.setMaximumWidth(70)
        return w

    def _form(self, parent_layout, rows):
        """Add a 2-column grid: (label, widget) pairs, wrapping to 2 per row."""
        grid = QGridLayout()
        grid.setHorizontalSpacing(6)
        grid.setVerticalSpacing(4)
        for i, (label, widget) in enumerate(rows):
            r, c = divmod(i, 2)
            grid.addWidget(QLabel(label), r, c * 2)
            grid.addWidget(widget, r, c * 2 + 1)
        # Push everything left.
        grid.setColumnStretch(grid.columnCount(), 1)
        parent_layout.addLayout(grid)

    def _build_ui(self) -> None:
        outer = QVBoxLayout(self)
        outer.setContentsMargins(4, 4, 4, 4)
        outer.setSpacing(4)

        # Let the dock decide the width; the widget can shrink narrow.
        self.setMinimumWidth(420)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll.setFrameShape(QScrollArea.NoFrame)
        inner = QWidget()
        inner.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Minimum)
        self._inner_layout = QVBoxLayout(inner)
        self._inner_layout.setContentsMargins(2, 2, 2, 2)
        self._inner_layout.setSpacing(6)
        scroll.setWidget(inner)
        outer.addWidget(scroll, 1)

        self._inner_layout.addWidget(self._build_input_section())
        self._inner_layout.addWidget(self._build_alignment_section())
        self._inner_layout.addWidget(self._build_segmentation_section())
        self._inner_layout.addWidget(self._build_quantification_section())
        self._inner_layout.addWidget(self._build_batch_section())
        self._inner_layout.addStretch(1)

        self.log_view = QTextEdit()
        self.log_view.setReadOnly(True)
        self.log_view.setPlaceholderText("Log output…")
        self.log_view.setMinimumHeight(120)
        self.log_view.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.log_view.document().setMaximumBlockCount(5000)
        from qtpy.QtGui import QFont
        f = QFont("Menlo")
        f.setStyleHint(QFont.Monospace)
        f.setPointSize(10)
        self.log_view.setFont(f)
        # Subtle background so the log panel stands apart from controls.
        self.log_view.setStyleSheet(
            "QTextEdit { background: #1e1e1e; color: #e0e0e0; "
            "border: 1px solid #444; padding: 4px; }"
        )
        outer.addWidget(self.log_view, 0)

    def _build_input_section(self) -> QGroupBox:
        gb = QGroupBox("Single Input")
        v = QVBoxLayout(gb)

        # Layout (decides whether Path is a file or a directory)
        layout_row = QHBoxLayout()
        layout_row.addWidget(QLabel("Layout:"))
        self.layout_merged = QRadioButton("4D TIFF")
        self.layout_split = QRadioButton("Split *_C{idx}.tif")
        self.layout_merged.setChecked(True)
        lg = QButtonGroup(self)
        lg.addButton(self.layout_merged)
        lg.addButton(self.layout_split)
        layout_row.addWidget(self.layout_merged)
        layout_row.addWidget(self.layout_split)
        layout_row.addStretch(1)
        v.addLayout(layout_row)

        # Path (file when layout=4D TIFF, directory when layout=split)
        path_row = QHBoxLayout()
        path_row.setSpacing(4)
        self.path_label = QLabel("File:")
        path_row.addWidget(self.path_label)
        self.path_edit = QLineEdit()
        self.path_edit.setMinimumWidth(80)
        self.path_edit.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.path_edit.returnPressed.connect(self._on_load)
        path_row.addWidget(self.path_edit, 1)
        browse = QPushButton("…")
        browse.setMaximumWidth(28)
        browse.clicked.connect(self._browse_input)
        path_row.addWidget(browse)
        v.addLayout(path_row)
        # Keep the label in sync with the chosen layout.
        self.layout_merged.toggled.connect(
            lambda on: self.path_label.setText("File:" if on else "Folder:")
        )

        # Channel mapping (1-indexed)
        self.ch_cell = QSpinBox(); self.ch_cell.setRange(1, 16); self.ch_cell.setValue(1)
        self.ch_protein = QSpinBox(); self.ch_protein.setRange(1, 16); self.ch_protein.setValue(2)
        self.ch_nucleus = QSpinBox(); self.ch_nucleus.setRange(1, 16); self.ch_nucleus.setValue(3)
        self.ch_pattern = QSpinBox(); self.ch_pattern.setRange(1, 16); self.ch_pattern.setValue(4)
        for w in (self.ch_cell, self.ch_protein, self.ch_nucleus, self.ch_pattern):
            self._compact(w)
        self._form(v, [
            ("Cell ch.", self.ch_cell),
            ("Protein ch.", self.ch_protein),
            ("Nucleus ch.", self.ch_nucleus),
            ("Pattern ch.", self.ch_pattern),
        ])

        self.btn_load = QPushButton("Load")
        self.btn_load.clicked.connect(self._on_load)
        v.addWidget(self.btn_load)
        return gb

    def _build_alignment_section(self) -> QGroupBox:
        gb = QGroupBox("1. Alignment")
        v = QVBoxLayout(gb)
        tdir = Path(__file__).resolve().parent / "templates"
        self.pattern_template = self._template_row(v, "Pattern template",
                                                   str(tdir / "perfect_template.tiff"))
        self.head_template = self._template_row(v, "Head template",
                                                str(tdir / "head_template.tiff"))
        self.stem_template = self._template_row(v, "Stem template",
                                                str(tdir / "stem_template.tiff"))

        self.coarse_step = QDoubleSpinBox(); self.coarse_step.setRange(0.05, 10); self.coarse_step.setValue(1.0); self.coarse_step.setSingleStep(0.1)
        self.fine_step = QDoubleSpinBox(); self.fine_step.setRange(0.01, 1); self.fine_step.setValue(0.1); self.fine_step.setSingleStep(0.05); self.fine_step.setDecimals(2)
        self.prior_sigma = QDoubleSpinBox(); self.prior_sigma.setRange(0, 5); self.prior_sigma.setValue(0.3); self.prior_sigma.setSingleStep(0.1)
        self.angle_min = QDoubleSpinBox(); self.angle_min.setRange(-360, 360); self.angle_min.setValue(0.0)
        self.angle_max = QDoubleSpinBox(); self.angle_max.setRange(-360, 720); self.angle_max.setValue(360.0)
        for w in (self.coarse_step, self.fine_step, self.prior_sigma,
                  self.angle_min, self.angle_max):
            self._compact(w)
        self._form(v, [
            ("Coarse step", self.coarse_step),
            ("Fine step", self.fine_step),
            ("Prior σ", self.prior_sigma),
            ("Angle min", self.angle_min),
            ("Angle max", self.angle_max),
        ])

        run_row = QHBoxLayout()
        self.btn_align = QPushButton("Run Alignment")
        self.btn_align.clicked.connect(self._on_run_alignment)
        run_row.addWidget(self.btn_align)
        self.show_align = QCheckBox("Show overlay layers"); self.show_align.setChecked(True)
        run_row.addWidget(self.show_align); run_row.addStretch(1)
        v.addLayout(run_row)
        return gb

    def _build_segmentation_section(self) -> QGroupBox:
        gb = QGroupBox("2. Cell Segmentation")
        v = QVBoxLayout(gb)
        self.seg_sigma = QDoubleSpinBox(); self.seg_sigma.setRange(0, 20); self.seg_sigma.setValue(3.0)
        self.seg_min_area = QDoubleSpinBox(); self.seg_min_area.setRange(0, 1e6); self.seg_min_area.setValue(100); self.seg_min_area.setDecimals(0)
        self.seg_circ_max = QDoubleSpinBox(); self.seg_circ_max.setRange(0, 1); self.seg_circ_max.setSingleStep(0.05); self.seg_circ_max.setValue(0.95)
        self.seg_clahe = QSpinBox(); self.seg_clahe.setRange(8, 1024); self.seg_clahe.setValue(64)
        for w in (self.seg_sigma, self.seg_min_area, self.seg_circ_max, self.seg_clahe):
            self._compact(w)
        self._form(v, [
            ("Gaussian σ", self.seg_sigma),
            ("Min area µm²", self.seg_min_area),
            ("Max circ.", self.seg_circ_max),
            ("CLAHE block", self.seg_clahe),
        ])
        run_row = QHBoxLayout()
        self.btn_seg = QPushButton("Run Segmentation")
        self.btn_seg.clicked.connect(self._on_run_segmentation)
        run_row.addWidget(self.btn_seg)
        self.show_labels = QCheckBox("Show labels layer"); self.show_labels.setChecked(True)
        run_row.addWidget(self.show_labels); run_row.addStretch(1)
        v.addLayout(run_row)
        return gb

    def _build_quantification_section(self) -> QGroupBox:
        gb = QGroupBox("3. Quantification")
        v = QVBoxLayout(gb)
        # Stem-tip frac. = top fraction of the stem template treated as the
        # "stem tip" region (drives Protein_StemTip_* columns). Not protrusion-
        # related — it's a region-mask control.
        self.stem_tip_frac = QDoubleSpinBox(); self.stem_tip_frac.setRange(0.01, 1); self.stem_tip_frac.setValue(0.25); self.stem_tip_frac.setSingleStep(0.05)
        self.prot_min_area = QSpinBox(); self.prot_min_area.setRange(0, 10000); self.prot_min_area.setValue(50)
        self.prot_min_len = QDoubleSpinBox(); self.prot_min_len.setRange(0, 100); self.prot_min_len.setValue(0.8); self.prot_min_len.setSingleStep(0.1)
        for w in (self.stem_tip_frac, self.prot_min_area, self.prot_min_len):
            self._compact(w)
        # ---- Rolling-ball protrusion detection ----
        # R = ball_radius_fraction × MIC_radius (per cell).
        # Mirrors legacy/protrusion_detection.py.
        self.ball_radius_fraction = QDoubleSpinBox()
        self.ball_radius_fraction.setRange(0.01, 1.0)
        self.ball_radius_fraction.setSingleStep(0.05)
        self.ball_radius_fraction.setValue(0.25)
        self.ball_radius_fraction.setDecimals(2)
        self._compact(self.ball_radius_fraction)

        self._form(v, [
            ("Stem-tip frac.", self.stem_tip_frac),
            ("Prot. area px", self.prot_min_area),
            ("Prot. len µm", self.prot_min_len),
            ("Ball radius frac.", self.ball_radius_fraction),
        ])

        cb_row = QHBoxLayout()
        self.save_cell_qc = QCheckBox("Save per-cell QC PNGs"); self.save_cell_qc.setChecked(True)
        self.save_image_qc = QCheckBox("Save per-image overview PNG"); self.save_image_qc.setChecked(True)
        cb_row.addWidget(self.save_cell_qc); cb_row.addWidget(self.save_image_qc); cb_row.addStretch(1)
        v.addLayout(cb_row)

        out_row = QHBoxLayout()
        out_row.setSpacing(4)
        out_row.addWidget(QLabel("Out:"))
        self.output_dir = QLineEdit()
        self.output_dir.setMinimumWidth(80)
        self.output_dir.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self._set_path(self.output_dir, Path.cwd() / "results")
        out_row.addWidget(self.output_dir, 1)
        out_browse = QPushButton("…"); out_browse.setMaximumWidth(28)
        out_browse.clicked.connect(self._browse_output_dir)
        out_row.addWidget(out_browse)
        v.addLayout(out_row)

        self.btn_quant = QPushButton("Run Quantification")
        self.btn_quant.clicked.connect(self._on_run_quantification)
        v.addWidget(self.btn_quant)
        return gb

    def _build_batch_section(self) -> QGroupBox:
        gb = QGroupBox("Batch")
        v = QVBoxLayout(gb)

        # Folder
        folder_row = QHBoxLayout()
        folder_row.setSpacing(4)
        folder_row.addWidget(QLabel("Folder:"))
        self.batch_path_edit = QLineEdit()
        self.batch_path_edit.setMinimumWidth(80)
        self.batch_path_edit.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        folder_row.addWidget(self.batch_path_edit, 1)
        batch_browse = QPushButton("…")
        batch_browse.setMaximumWidth(28)
        batch_browse.clicked.connect(self._browse_batch_folder)
        folder_row.addWidget(batch_browse)
        v.addLayout(folder_row)

        # Output folder (defaults to <batch folder>/results when blank).
        out_row = QHBoxLayout()
        out_row.setSpacing(4)
        out_row.addWidget(QLabel("Out:"))
        self.batch_output_dir = QLineEdit()
        self.batch_output_dir.setMinimumWidth(80)
        self.batch_output_dir.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.batch_output_dir.setPlaceholderText("<batch folder>/results")
        out_row.addWidget(self.batch_output_dir, 1)
        bout_browse = QPushButton("…")
        bout_browse.setMaximumWidth(28)
        bout_browse.clicked.connect(self._browse_batch_output_dir)
        out_row.addWidget(bout_browse)
        v.addLayout(out_row)

        # Layout (independent of the Single Input layout)
        blayout_row = QHBoxLayout()
        blayout_row.addWidget(QLabel("Layout:"))
        self.batch_layout_merged = QRadioButton("4D TIFF")
        self.batch_layout_split = QRadioButton("Split *_C{idx}.tif")
        self.batch_layout_merged.setChecked(True)
        blg = QButtonGroup(self)
        blg.addButton(self.batch_layout_merged)
        blg.addButton(self.batch_layout_split)
        blayout_row.addWidget(self.batch_layout_merged)
        blayout_row.addWidget(self.batch_layout_split)
        blayout_row.addStretch(1)
        v.addLayout(blayout_row)

        # Tasks
        row = QHBoxLayout()
        self.batch_align = QCheckBox("Align"); self.batch_align.setChecked(True)
        self.batch_seg = QCheckBox("Segment"); self.batch_seg.setChecked(True)
        self.batch_quant = QCheckBox("Quantify"); self.batch_quant.setChecked(True)
        for w in (self.batch_align, self.batch_seg, self.batch_quant):
            row.addWidget(w)
        row.addStretch(1)
        v.addLayout(row)

        btns = QHBoxLayout()
        self.btn_batch = QPushButton("Run Batch")
        self.btn_batch.clicked.connect(self._on_run_batch)
        self.btn_cancel = QPushButton("Cancel")
        self.btn_cancel.clicked.connect(self._on_cancel)
        self.btn_cancel.setEnabled(False)
        btns.addWidget(self.btn_batch); btns.addWidget(self.btn_cancel); btns.addStretch(1)
        v.addLayout(btns)

        self.progress = QProgressBar(); self.progress.setRange(0, 1); self.progress.setValue(0)
        v.addWidget(self.progress)
        self.progress_lbl = QLabel("")
        v.addWidget(self.progress_lbl)
        return gb

    def _template_row(self, parent_layout, label: str, default_value: str) -> QLineEdit:
        row = QHBoxLayout()
        row.setSpacing(4)
        lab = QLabel(label + ":")
        lab.setMinimumWidth(60)
        row.addWidget(lab)
        edit = QLineEdit()
        edit.setMinimumWidth(80)
        edit.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self._set_path(edit, default_value)
        row.addWidget(edit, 1)
        btn = QPushButton("…")
        btn.setMaximumWidth(28)
        btn.clicked.connect(lambda: self._browse_file_into(edit, "TIFF files (*.tif *.tiff)"))
        row.addWidget(btn)
        parent_layout.addLayout(row)
        return edit

    # -- Helpers ------------------------------------------------------------

    def _append_log(self, msg: str) -> None:
        # ``msg`` is an HTML snippet produced by gui._logging._QtLogHandler.
        self.log_view.append(msg)
        # Auto-scroll to bottom.
        sb = self.log_view.verticalScrollBar()
        if sb is not None:
            sb.setValue(sb.maximum())

    def _browse_input(self) -> None:
        # Single Input: pick a file for the 4D-TIFF layout, a folder containing
        # the C0..C3 siblings for the split layout.
        if self.layout_merged.isChecked():
            path, _ = QFileDialog.getOpenFileName(self, "Select TIFF",
                                                  filter="TIFF files (*.tif *.tiff)")
            if path:
                self._set_path(self.path_edit, path)
                self._on_load()
        else:
            path = QFileDialog.getExistingDirectory(self, "Select folder")
            if path:
                self._set_path(self.path_edit, path)
                self._on_load()

    def _browse_batch_folder(self) -> None:
        path = QFileDialog.getExistingDirectory(self, "Select batch folder")
        if path:
            self._set_path(self.batch_path_edit, path)

    def _browse_output_dir(self) -> None:
        path = QFileDialog.getExistingDirectory(self, "Select output folder",
                                                self._get_path(self.output_dir))
        if path:
            self._set_path(self.output_dir, path)

    def _browse_batch_output_dir(self) -> None:
        start = self._get_path(self.batch_output_dir) or self._get_path(self.batch_path_edit)
        path = QFileDialog.getExistingDirectory(self, "Select batch output folder", start)
        if path:
            self._set_path(self.batch_output_dir, path)

    def _browse_file_into(self, edit: QLineEdit, filt: str) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Select file", filter=filt)
        if path:
            self._set_path(edit, path)

    def _channel_mapping(self) -> dict[str, int]:
        return {
            "cell": self.ch_cell.value(),
            "protein": self.ch_protein.value(),
            "nucleus": self.ch_nucleus.value(),
            "pattern": self.ch_pattern.value(),
        }

    def _layout_kind(self) -> str:
        """Layout for the Single Input section."""
        return "merged" if self.layout_merged.isChecked() else "split"

    def _batch_layout_kind(self) -> str:
        """Layout for the Batch section."""
        return "merged" if self.batch_layout_merged.isChecked() else "split"

    def _alignment_params(self) -> dict:
        return dict(
            pattern_template=self._get_path(self.pattern_template),
            head_template=self._get_path(self.head_template),
            stem_template=self._get_path(self.stem_template),
            coarse_step=self.coarse_step.value(),
            fine_step=self.fine_step.value(),
            prior_sigma=self.prior_sigma.value(),
            angle_min=self.angle_min.value(),
            angle_max=self.angle_max.value(),
            stem_tip_fraction=self.stem_tip_frac.value(),
        )

    def _segmentation_params(self) -> dict:
        return dict(
            gaussian_sigma=self.seg_sigma.value(),
            min_cell_size_um2=self.seg_min_area.value(),
            max_circularity=self.seg_circ_max.value(),
            clahe_kernel=self.seg_clahe.value(),
        )

    def _quantification_params(self) -> dict:
        return dict(
            stem_tip_fraction=self.stem_tip_frac.value(),
            protrusion_min_area_px=self.prot_min_area.value(),
            protrusion_min_length_um=self.prot_min_len.value(),
            ball_radius_fraction=self.ball_radius_fraction.value(),
            ball_radius_px=None,
            save_cell_qc=self.save_cell_qc.isChecked(),
            save_image_qc=self.save_image_qc.isChecked(),
            output_dir=self._get_path(self.output_dir),
        )

    def _all_params(self) -> dict:
        p = {}
        p.update(self._alignment_params())
        p.update(self._segmentation_params())
        p.update(self._quantification_params())
        return p

    def _set_run_buttons_enabled(self, enabled: bool) -> None:
        for b in (self.btn_align, self.btn_seg, self.btn_quant,
                  self.btn_batch, self.btn_load):
            b.setEnabled(enabled)
        self.btn_cancel.setEnabled(not enabled)

    def _show_channels(self) -> None:
        if self.state is None:
            return
        if self.viewer is None:
            try:
                import napari
                self.viewer = napari.current_viewer()
            except Exception:
                pass
        if self.viewer is None:
            self.log.warning("No napari viewer attached — cannot display channels")
            return
        # Add bottom-to-top: Pattern first (bottom of layer list), Cell last (top).
        for role in reversed(CHANNEL_ORDER):
            arr = self.state.channels.get(role)
            if arr is None:
                continue
            name = role.capitalize()
            if name in self.viewer.layers:
                self.viewer.layers.remove(name)
            lo, hi = self._auto_contrast(arr)
            self.viewer.add_image(
                arr,
                name=name,
                colormap=CHANNEL_COLORMAPS.get(role, "gray"),
                blending="additive",
                opacity=CHANNEL_OPACITY.get(role, 1.0),
                contrast_limits=(lo, hi),
            )

    @staticmethod
    def _auto_contrast(arr) -> tuple[float, float]:
        """Percentile-based contrast limits, robust to outliers."""
        import numpy as np
        flat = arr[arr > 0] if (arr > 0).any() else arr
        lo = float(np.percentile(flat, 1))
        hi = float(np.percentile(flat, 99.5))
        if hi <= lo:
            hi = float(arr.max())
            lo = float(arr.min())
        return lo, hi

    # -- Load --------------------------------------------------------------

    def _on_load(self) -> None:
        path_str = self._get_path(self.path_edit).strip()
        if not path_str:
            self.log.warning("No input path set")
            return
        path = Path(path_str)
        layout = self._layout_kind()
        mapping = self._channel_mapping()
        try:
            if layout == "merged":
                item = ImageItem(title=path.stem, layout="merged", path=path)
            else:
                # Split layout: ``path`` is a folder containing one image's
                # C0..C3 siblings; pick the first group found.
                items = discover_batch(path, "split")
                if not items:
                    self.log.error("No split-channel groups found in %s", path)
                    return
                if len(items) > 1:
                    self.log.warning(
                        "Found %d split-channel groups in %s; using the first "
                        "(%s). Use Batch to process them all.",
                        len(items), path, items[0].title,
                    )
                item = items[0]
            projected, ps = load_item(item)
            self.state = PipelineState(
                title=item.title,
                src_path=item.path,
                channels=split_channels(projected, mapping),
                pixel_size=ps,
            )
            self.log.info("● Loaded   %s  shape=%s  pixel=%.4f µm/px",
                          item.title, projected.shape, ps)
            self._show_channels()
        except Exception as e:
            self.log.error("Load failed: %s", e)

    # -- Per-task runners --------------------------------------------------

    def _require_state(self) -> bool:
        if self.state is None or not self.state.channels:
            self.log.warning("No image loaded — click Load first.")
            return False
        return True

    def _run_in_worker(self, work_fn, on_done) -> None:
        """Run ``work_fn`` off the GUI thread via napari thread_worker."""
        if thread_worker is None:
            try:
                result = work_fn()
            except Exception as e:
                self.log.error("%s", e)
                self._set_run_buttons_enabled(True)
                return
            on_done(result)
            self._set_run_buttons_enabled(True)
            return

        self._set_run_buttons_enabled(False)

        @thread_worker
        def _w():
            return work_fn()

        worker = _w()
        worker.returned.connect(lambda r: (on_done(r), self._set_run_buttons_enabled(True)))
        worker.errored.connect(lambda e: (self.log.error("Worker error: %s", e),
                                          self._set_run_buttons_enabled(True)))
        self._worker = worker
        worker.start()

    def _on_run_alignment(self) -> None:
        if not self._require_state():
            return
        params = self._alignment_params()
        task = AlignmentTask()
        state = self.state

        def work():
            return task.run(state, params, self.log)

        def done(new_state):
            self.state = new_state
            if self.viewer is not None and self.show_align.isChecked():
                task.visualize(new_state, self.viewer)

        self._run_in_worker(work, done)

    def _on_run_segmentation(self) -> None:
        if not self._require_state():
            return
        params = self._segmentation_params()
        task = SegmentationTask()
        state = self.state

        def work():
            return task.run(state, params, self.log)

        def done(new_state):
            self.state = new_state
            if self.viewer is not None and self.show_labels.isChecked():
                task.visualize(new_state, self.viewer)

        self._run_in_worker(work, done)

    def _on_run_quantification(self) -> None:
        if not self._require_state():
            return
        state = self.state
        align_params = self._alignment_params()
        seg_params = self._segmentation_params()
        quant_params = self._quantification_params()

        def work():
            if state.alignment is None:
                self.log.info("Quantification needs alignment — auto-running")
                AlignmentTask().run(state, align_params, self.log)
            if state.segmentation is None:
                self.log.info("Quantification needs segmentation — auto-running")
                SegmentationTask().run(state, seg_params, self.log)
            return QuantificationTask().run(state, quant_params, self.log)

        def done(new_state):
            self.state = new_state

        self._run_in_worker(work, done)

    # -- Batch --------------------------------------------------------------

    def _on_run_batch(self) -> None:
        path_str = self._get_path(self.batch_path_edit).strip()
        if not path_str:
            self.log.warning("No batch folder set")
            return
        path = Path(path_str)
        layout = self._batch_layout_kind()
        items = discover_batch(path, layout)
        if not items:
            self.log.error("No images found in %s (layout=%s)", path, layout)
            return

        tasks = []
        if self.batch_align.isChecked(): tasks.append("alignment")
        if self.batch_seg.isChecked(): tasks.append("segmentation")
        if self.batch_quant.isChecked(): tasks.append("quantification")
        if not tasks:
            self.log.warning("No tasks selected for batch run.")
            return

        params = self._all_params()
        mapping = self._channel_mapping()
        batch_out = self._get_path(self.batch_output_dir).strip()
        if batch_out:
            out_dir = Path(batch_out)
        else:
            out_dir = path / "results"
        params["output_dir"] = str(out_dir)
        out_dir.mkdir(parents=True, exist_ok=True)

        # File log handler for this run.
        if self._file_handler is not None:
            detach_handler(self._file_handler)
        self._file_handler = attach_file_handler(out_dir / "pipeline.log")

        self._cancel_event.clear()
        self.progress.setRange(0, len(items)); self.progress.setValue(0)
        self.progress_lbl.setText(f"0/{len(items)}")
        self.log.info("Batch starting: %d image(s), tasks=%s", len(items), tasks)
        self._set_run_buttons_enabled(False)

        cancel_event = self._cancel_event
        log = self.log

        if thread_worker is None:
            # Fallback: run synchronously (used only when napari isn't importable,
            # i.e. headless test paths). Not ideal but keeps the GUI code testable.
            try:
                final_state = None
                for ev in run_batch(items, tasks, params, mapping, out_dir,
                                    cancel_event, log):
                    final_state = self._dispatch_batch_event(ev, final_state)
                if final_state is not None:
                    self._show_final(final_state, tasks)
            finally:
                self._set_run_buttons_enabled(True)
            return

        @thread_worker
        def _runner():
            for ev in run_batch(items, tasks, params, mapping, out_dir,
                                cancel_event, log):
                yield ev

        worker = _runner()
        self._final_state_holder: list[PipelineState] = []
        worker.yielded.connect(lambda ev: self._dispatch_batch_event(ev, None))
        worker.finished.connect(self._on_batch_finished)
        worker.errored.connect(lambda e: (self.log.error("Batch error: %s", e),
                                          self._on_batch_finished()))
        self._batch_tasks = tasks
        self._worker = worker
        worker.start()

    def _dispatch_batch_event(self, ev, final_state):
        kind = ev[0]
        if kind == "log":
            self.log.info("%s", ev[1])
        elif kind == "progress":
            i, n, title = ev[1], ev[2], ev[3]
            self.progress.setMaximum(n); self.progress.setValue(i)
            self.progress_lbl.setText(f"{i}/{n} — {title}")
        elif kind == "error":
            title, tb = ev[1], ev[2]
            self.log.error("Failed %s: %s", title, tb.splitlines()[-1] if tb else "")
        elif kind == "state":
            final_state = ev[1]
            self._final_state_holder = [final_state]
        return final_state

    def _on_batch_finished(self):
        self._set_run_buttons_enabled(True)
        if self._file_handler is not None:
            detach_handler(self._file_handler)
            self._file_handler = None
        if getattr(self, "_final_state_holder", None):
            self._show_final(self._final_state_holder[0], getattr(self, "_batch_tasks", []))

    def _show_final(self, state: PipelineState, tasks: list[str]) -> None:
        if self.viewer is None:
            return
        self.state = state
        self._show_channels()
        if "alignment" in tasks:
            AlignmentTask().visualize(state, self.viewer)
        if "segmentation" in tasks:
            SegmentationTask().visualize(state, self.viewer)

    def _on_cancel(self) -> None:
        self.log.info("Cancellation requested")
        self._cancel_event.set()

    # -- Qt teardown --------------------------------------------------------

    def closeEvent(self, event):  # pragma: no cover
        try:
            detach_handler(self._log_handler)
            if self._file_handler is not None:
                detach_handler(self._file_handler)
        finally:
            super().closeEvent(event)
