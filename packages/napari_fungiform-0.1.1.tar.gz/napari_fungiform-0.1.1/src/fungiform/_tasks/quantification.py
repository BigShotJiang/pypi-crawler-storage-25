"""Quantification task: per-cell measurements + CSV + QC PNGs."""

from __future__ import annotations

import csv
import logging
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import numpy as np

from automated_pipeline import CSV_COLUMNS, measure_cells, save_cell_mask_jpg, save_overlay_jpg
from qc_viz import (
    save_cell_protrusion_png,
    save_cell_qc_png,
    save_image_qc_png,
    save_protrusion_visualisations,
)

from .._state import PipelineState, QuantificationResult


class QuantificationTask:
    name = "quantification"

    def run(self, state: PipelineState, params: dict, log: logging.Logger) -> PipelineState:
        if state.alignment is None or state.alignment.error:
            raise RuntimeError("Quantification requires alignment first")
        if state.segmentation is None or state.segmentation.labeled is None:
            raise RuntimeError("Quantification requires segmentation first")

        log.info("▶ Quantify %s", state.title)

        out_dir = Path(params["output_dir"]).resolve()
        out_dir.mkdir(parents=True, exist_ok=True)

        align = state.alignment
        seg = state.segmentation

        rows, qc_records = measure_cells(
            state.channels["cell"],
            state.channels["protein"],
            seg.regions,
            state.pixel_size,
            state.title,
            nucleus_ch=state.channels["nucleus"],
            aligned_regions=align.regions,
            perfect_warped=align.perfect_warped,
            cell_label_image=seg.labeled,
            protrusion_min_area_px=int(params.get("protrusion_min_area_px", 5)),
            protrusion_min_length_um=float(params.get("protrusion_min_length_um", 0.8)),
            ball_radius_fraction=float(params.get("ball_radius_fraction", 0.25)),
            ball_radius_px=(
                int(params["ball_radius_px"])
                if params.get("ball_radius_px") not in (None, 0)
                else None
            ),
        )

        # Mask + overlay JPEGs (mirrors CLI behavior).
        save_cell_mask_jpg(seg.labeled, out_dir / f"MAX_{state.title}_Cell_mask.jpg")
        save_overlay_jpg(state.channels["cell"], seg.labeled,
                         out_dir / f"MAX_{state.title}_mask_overlay.jpg")

        if params.get("save_cell_qc", True):
            qc_dir = out_dir / "qc_cells"
            prot_dir = out_dir / "protrusions"
            qc_dir.mkdir(parents=True, exist_ok=True)
            prot_dir.mkdir(parents=True, exist_ok=True)
            for row, qc in zip(rows, qc_records):
                if not qc:
                    continue
                merged = {**row, **{k: v for k, v in qc.items() if k.startswith("_")}}
                save_cell_qc_png(
                    cell_mask=qc["_full_cell_mask"],
                    cell_id=row["Label"],
                    regions=align.regions,
                    protein_ch=state.channels["protein"],
                    nucleus_ch=state.channels["nucleus"],
                    metrics=merged,
                    dst=qc_dir / f"{row['Label']}_qc.png",
                )
                save_cell_protrusion_png(
                    cell_mask=qc["_full_cell_mask"],
                    cell_id=row["Label"],
                    regions=align.regions,
                    protein_ch=state.channels["protein"],
                    metrics=merged,
                    dst=prot_dir / f"{row['Label']}_protrusions.png",
                )

        if params.get("save_image_qc", True) and align.perfect_warped is not None:
            save_image_qc_png(
                cell_ch=state.channels["cell"],
                labeled=seg.labeled,
                regions=align.regions,
                pattern_mask=align.perfect_warped,
                title=state.title,
                dst=out_dir / f"MAX_{state.title}_image_qc.png",
            )
            prot_root = out_dir / "protrusions"
            prot_root.mkdir(parents=True, exist_ok=True)
            save_protrusion_visualisations(
                cell_channel=state.channels["cell"],
                cell_label_image=seg.labeled,
                cell_records=qc_records,
                pixel_size=state.pixel_size,
                ball_radius_fraction=float(params.get("ball_radius_fraction", 0.25)),
                dst_protrusions=prot_root / f"MAX_{state.title}_protrusions.png",
            )

        # Single shared CSV; rows for this image replace any rows for the same
        # title from a previous run (matches the CLI's merge behaviour).
        csv_path = out_dir / "_allResults.csv"
        retained: list[dict] = []
        if csv_path.exists():
            with open(csv_path, newline="") as f:
                reader = csv.DictReader(f)
                for row in reader:
                    label = row.get("Label", "")
                    title_in_label = label.removeprefix("MAX_").rsplit("_Cell_", 1)[0]
                    if title_in_label != state.title:
                        for col in CSV_COLUMNS:
                            row.setdefault(col, "")
                        retained.append(row)
        with open(csv_path, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=CSV_COLUMNS)
            writer.writeheader()
            writer.writerows(retained + rows)

        state.quantification = QuantificationResult(
            rows=rows, qc_records=qc_records, csv_path=csv_path,
        )
        log.info("✓ Quantify %d row(s) → %s", len(rows), csv_path.name)
        return state

    def visualize(self, state: PipelineState, viewer: Any) -> None:
        # Quantification produces no new layers itself; results live on disk.
        return
