"""Common Protocol + helpers for pipeline tasks."""

from __future__ import annotations

import logging
from typing import Any, Callable, Protocol

from .._state import PipelineState

Log = logging.Logger


class PipelineTask(Protocol):
    name: str

    def run(self, state: PipelineState, params: dict, log: Log) -> PipelineState: ...

    def visualize(self, state: PipelineState, viewer: Any) -> None: ...


def _replace_layer(viewer: Any, name: str, factory: Callable[[], Any]) -> Any:
    """Add or replace a layer by name. ``factory`` returns the created layer."""
    if name in viewer.layers:
        viewer.layers.remove(name)
    return factory()
