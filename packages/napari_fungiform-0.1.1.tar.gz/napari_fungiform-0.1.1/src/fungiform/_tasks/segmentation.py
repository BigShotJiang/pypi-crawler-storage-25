"""Cell segmentation task (wraps automated_pipeline.segment_cells)."""

from __future__ import annotations

import logging
from typing import Any

import numpy as np

import automated_pipeline as ap
from automated_pipeline import segment_cells
from quantification import segment_nucleus

from .._state import PipelineState, SegmentationResult
from ._base import _replace_layer


class SegmentationTask:
    name = "segmentation"

    def run(self, state: PipelineState, params: dict, log: logging.Logger) -> PipelineState:
        log.info("▶ Segment  %s", state.title)
        # Apply parameter overrides via the module-level constants the
        # underlying code reads from (kept consistent with CLI behavior).
        old = (ap.GAUSSIAN_SIGMA, ap.MIN_CELL_SIZE_UM2, ap.MAX_CIRCULARITY, ap.CLAHE_KERNEL)
        try:
            if "gaussian_sigma" in params:
                ap.GAUSSIAN_SIGMA = float(params["gaussian_sigma"])
            if "min_cell_size_um2" in params:
                ap.MIN_CELL_SIZE_UM2 = float(params["min_cell_size_um2"])
            if "max_circularity" in params:
                ap.MAX_CIRCULARITY = float(params["max_circularity"])
            if "clahe_kernel" in params:
                ap.CLAHE_KERNEL = int(params["clahe_kernel"])
            labeled, regions = segment_cells(state.channels["cell"], state.pixel_size)
        finally:
            ap.GAUSSIAN_SIGMA, ap.MIN_CELL_SIZE_UM2, ap.MAX_CIRCULARITY, ap.CLAHE_KERNEL = old

        # Nucleus segmentation per cell (matches the quantification pipeline)
        nucleus_labels = np.zeros_like(labeled, dtype=np.int32)
        nucleus_ch = state.channels.get("nucleus")
        if nucleus_ch is not None and len(regions) > 0:
            full_cell_union = labeled > 0
            nuc = segment_nucleus(nucleus_ch, full_cell_union)
            # Inherit each nucleus pixel's cell label so colors match.
            nucleus_labels[nuc] = labeled[nuc]

        state.segmentation = SegmentationResult(labeled=labeled, regions=regions)
        # Stash the nucleus mask for visualisation; downstream tasks recompute
        # it per-cell so this is only for display.
        state.segmentation.nucleus_labels = nucleus_labels  # type: ignore[attr-defined]
        state.reset_downstream("segmentation")
        log.info("✓ Segment  %d cell(s), nucleus area=%d px",
                 len(regions), int((nucleus_labels > 0).sum()))
        return state

    def visualize(self, state: PipelineState, viewer: Any) -> None:
        if state.segmentation is None or state.segmentation.labeled is None:
            return
        cells_display = _random_relabel(state.segmentation.labeled, seed=1)
        _replace_layer(viewer, "Cell labels",
                       lambda: viewer.add_labels(
                           cells_display, name="Cell labels", opacity=0.5))
        nuc_labels = getattr(state.segmentation, "nucleus_labels", None)
        if nuc_labels is not None and (nuc_labels > 0).any():
            # Different seed → different random integers → distinct napari colours.
            nuc_display = _random_relabel(nuc_labels, seed=2)
            _replace_layer(viewer, "Nucleus labels",
                           lambda: viewer.add_labels(
                               nuc_display, name="Nucleus labels", opacity=0.5))


def _random_relabel(labels: np.ndarray, seed: int) -> np.ndarray:
    """Return a copy of ``labels`` with each positive label remapped to a
    random integer drawn deterministically from ``seed``. Background (0)
    stays 0. Used purely for napari display so cell vs. nucleus layers
    get visually distinct colours (napari hashes the label value into a
    colormap entry)."""
    if labels.size == 0:
        return labels.astype(np.int32)
    uniq = np.unique(labels)
    rng = np.random.default_rng(seed)
    lut_size = int(uniq.max()) + 1
    lut = np.zeros(lut_size, dtype=np.int32)
    # Spread labels widely across the colormap range.
    for v in uniq:
        if v == 0:
            continue
        lut[int(v)] = int(rng.integers(1, 2 ** 30))
    return lut[labels.astype(np.int64)]
