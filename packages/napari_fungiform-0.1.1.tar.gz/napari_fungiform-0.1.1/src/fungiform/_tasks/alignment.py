"""Alignment task: NCC template matching + warped region masks."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

import numpy as np
import tifffile

from detect_pattern import align_with_ncc
from quantification import (
    build_aligned_regions,
    compute_protein_extension,
    warp_template_to_image,
)

from .._state import AlignmentResult, PipelineState
from ._base import _replace_layer


def _load_template(path: str | Path) -> np.ndarray:
    return tifffile.imread(str(path)) > 128


class AlignmentTask:
    name = "alignment"

    def run(self, state: PipelineState, params: dict, log: logging.Logger) -> PipelineState:
        log.info("▶ Align    %s", state.title)
        pattern_template = _load_template(params["pattern_template"])
        head_template = _load_template(params["head_template"])
        stem_template = _load_template(params["stem_template"])
        if not (pattern_template.shape == head_template.shape == stem_template.shape):
            raise ValueError("Template shape mismatch (pattern/head/stem)")

        pattern_ch = state.channels["pattern"].astype(np.float32)
        lo, hi = np.percentile(pattern_ch, [1, 99])
        pattern_norm = np.clip((pattern_ch - lo) / max(hi - lo, 1e-6), 0, 1)

        record = align_with_ncc(
            target_image=pattern_norm,
            template=pattern_template,
            coarse_step=params.get("coarse_step", 1.0),
            fine_step=params.get("fine_step", 0.1),
            prior_sigma=params.get("prior_sigma", 0.3),
            angle_range=(params.get("angle_min", 0.0), params.get("angle_max", 360.0)),
        )

        output_shape = state.channels["cell"].shape
        regions = build_aligned_regions(
            head_template=head_template,
            stem_template=stem_template,
            theta_deg=record["theta_deg"],
            c_ref=record["c_ref"],
            c_det=record["c_det"],
            output_shape=output_shape,
            stem_tip_fraction=params.get("stem_tip_fraction", 0.25),
        )
        perfect_warped = warp_template_to_image(
            pattern_template,
            theta_deg=record["theta_deg"],
            c_ref=record["c_ref"],
            c_det=record["c_det"],
            output_shape=output_shape,
        )

        # Image-level precomputations shared across all cells.
        from scipy.ndimage import binary_dilation
        from skimage.filters import threshold_otsu

        regions["_near_head"] = binary_dilation(regions["head"], iterations=30)
        protein_ch = state.channels["protein"]
        try:
            protein_thresh = float(threshold_otsu(protein_ch))
        except ValueError:
            protein_thresh = float(protein_ch.mean())
        regions["_protein_threshold"] = protein_thresh
        regions["_protein_extension_um"] = compute_protein_extension(
            protein_ch=protein_ch,
            signal_threshold=protein_thresh,
            stem_tip_point=regions["stem_tip_point"],
            stem_axis=regions["stem_axis"],
            pixel_size=state.pixel_size,
        )

        state.alignment = AlignmentResult(
            theta_deg=float(record["theta_deg"]),
            c_ref=np.asarray(record["c_ref"]),
            c_det=np.asarray(record["c_det"]),
            score=float(record["score"]),
            regions=regions,
            perfect_warped=perfect_warped,
            template_paths={
                "pattern": str(params["pattern_template"]),
                "head": str(params["head_template"]),
                "stem": str(params["stem_template"]),
            },
        )
        state.reset_downstream("alignment")
        log.info(
            "✓ Align    θ=%+.2f°  NCC=%.3f", record["theta_deg"], record["score"],
        )
        return state

    def visualize(self, state: PipelineState, viewer: Any) -> None:
        if state.alignment is None or state.alignment.error:
            return
        r = state.alignment.regions
        _replace_layer(viewer, "Pattern aligned",
                       lambda: viewer.add_image(
                           state.alignment.perfect_warped.astype(float),
                           name="Pattern aligned", colormap="magenta",
                           blending="additive", opacity=0.5))
        _replace_layer(viewer, "Head region",
                       lambda: viewer.add_labels(
                           r["head"].astype(np.uint8), name="Head region"))
        _replace_layer(viewer, "Stem region",
                       lambda: viewer.add_labels(
                           (r["stem"].astype(np.uint8) * 2), name="Stem region"))
        # Remove any stale "Stem tip" layer from a prior run.
        if "Stem tip" in viewer.layers:
            viewer.layers.remove("Stem tip")
