"""State dataclasses shared between pipeline tasks."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np


@dataclass
class AlignmentResult:
    theta_deg: float = 0.0
    c_ref: np.ndarray | None = None
    c_det: np.ndarray | None = None
    score: float = 0.0
    regions: dict[str, Any] = field(default_factory=dict)
    perfect_warped: np.ndarray | None = None
    template_paths: dict[str, str] = field(default_factory=dict)
    error: str | None = None


@dataclass
class SegmentationResult:
    labeled: np.ndarray | None = None
    regions: list = field(default_factory=list)
    error: str | None = None


@dataclass
class QuantificationResult:
    rows: list[dict] = field(default_factory=list)
    qc_records: list[dict] = field(default_factory=list)
    csv_path: Path | None = None
    error: str | None = None


@dataclass
class PipelineState:
    title: str = ""
    src_path: Path | None = None
    channels: dict[str, np.ndarray] = field(default_factory=dict)  # cell/protein/nucleus/pattern
    pixel_size: float = 1.0
    alignment: AlignmentResult | None = None
    segmentation: SegmentationResult | None = None
    quantification: QuantificationResult | None = None

    def reset_downstream(self, source: str) -> None:
        """Re-running ``source`` invalidates dependent slots.

        Dependency matrix: quantification depends on (alignment, segmentation).
        Alignment and segmentation are independent of each other.
        """
        if source in ("alignment", "segmentation"):
            self.quantification = None
