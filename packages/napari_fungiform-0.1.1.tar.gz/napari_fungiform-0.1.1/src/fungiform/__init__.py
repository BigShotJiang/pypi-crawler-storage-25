"""Napari plugin GUI for the cell pattern analysis pipeline."""

from ._widget import PipelineWidget

__all__ = ["PipelineWidget"]
__version__ = "0.1.0"
