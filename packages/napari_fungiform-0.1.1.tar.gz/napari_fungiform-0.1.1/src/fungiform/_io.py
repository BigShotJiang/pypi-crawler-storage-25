"""Image loading + batch discovery for the napari plugin.

Thin wrappers over ``automated_pipeline`` so the core CLI code stays untouched.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Literal

import numpy as np

from automated_pipeline import (
    find_split_channel_groups,
    load_and_max_project,
    load_split_channel_group,
)


Layout = Literal["merged", "split"]


@dataclass
class ImageItem:
    title: str
    layout: Layout
    path: Path | None = None  # merged 4D TIFF
    split_paths: dict[int, Path] | None = None  # {0..3: path}


def load_item(item: ImageItem) -> tuple[np.ndarray, float]:
    """Load a single item; returns (C,H,W) uint16 array + pixel size."""
    if item.layout == "split":
        if not item.split_paths:
            raise ValueError(f"{item.title}: missing split channel paths")
        return load_split_channel_group(item.split_paths)
    if item.path is None:
        raise ValueError(f"{item.title}: missing merged path")
    return load_and_max_project(item.path)


def discover_batch(path: Path, layout: Layout) -> list[ImageItem]:
    """List all images in ``path`` (directory) or wrap ``path`` itself if it is
    a single TIFF file, filtered by ``layout``."""
    path = Path(path)
    items: list[ImageItem] = []

    # Single-file shortcut: accept a .tif/.tiff path directly (merged layout
    # only; split layout requires a directory to group the C0..C3 siblings).
    if path.is_file():
        if layout != "merged":
            return []
        if path.suffix.lower() not in (".tif", ".tiff"):
            return []
        return [ImageItem(title=path.stem, layout="merged", path=path)]

    if layout == "split":
        for base, chs in find_split_channel_groups(path):
            items.append(ImageItem(title=base, layout="split", split_paths=chs))
    else:
        tifs = sorted(path.glob("*.tif")) + sorted(path.glob("*.tiff"))
        tifs = [
            f for f in tifs
            if "_pattern_mask" not in f.name
            and "_aligned" not in f.name
            and not f.stem.endswith(("_C0", "_C1", "_C2", "_C3"))
        ]
        for f in tifs:
            items.append(ImageItem(title=f.stem, layout="merged", path=f))
    return items


def split_channels(
    projected: np.ndarray,
    mapping: dict[str, int],
) -> dict[str, np.ndarray]:
    """Slice a (C,H,W) stack by 1-indexed channel mapping into role->array."""
    out: dict[str, np.ndarray] = {}
    n_channels = projected.shape[0]
    for role, idx_1 in mapping.items():
        idx_0 = idx_1 - 1
        if idx_0 < 0 or idx_0 >= n_channels:
            raise IndexError(
                f"Channel {idx_1} requested for {role!r} but image has "
                f"only {n_channels} channels"
            )
        out[role] = projected[idx_0]
    return out
