"""Region-based and cross-channel quantification for cell-pattern analysis.

All metrics operate on aligned-image coordinates: head/stem templates are
warped from canonical (template-canvas) coordinates onto the input-image
coordinates using the rigid transform produced by
``detect_pattern.align_with_ncc``.

Transform convention (template -> image):
    p_image = R(theta_deg) @ (p_template - c_ref) + c_det
where ``c_ref`` is the bbox center of the template in its canonical canvas,
and ``c_det`` is the NCC peak in the target image.
"""
from __future__ import annotations

import numpy as np


def _apply_rigid_transform(
    src_mask: np.ndarray,
    theta_deg: float,
    c_ref: np.ndarray,
    c_det: np.ndarray,
    output_shape: tuple[int, int],
) -> np.ndarray:
    """Forward rigid transform: rotate src around c_ref then translate to c_det.

    Uses scipy.ndimage.affine_transform, which expects an INVERSE mapping:
        p_src = R(-theta) @ (p_out - c_det) + c_ref
    """
    from scipy.ndimage import affine_transform

    theta_rad = np.radians(theta_deg)
    cos_t, sin_t = np.cos(theta_rad), np.sin(theta_rad)
    R_inv = np.array([[cos_t, sin_t],
                      [-sin_t, cos_t]])
    offset = c_ref - R_inv @ c_det

    transformed = affine_transform(
        src_mask.astype(np.float64), R_inv, offset=offset,
        output_shape=output_shape, order=0, cval=0.0,
    )
    return transformed > 0.5


def warp_template_to_image(
    template: np.ndarray,
    theta_deg: float,
    c_ref: np.ndarray,
    c_det: np.ndarray,
    output_shape: tuple[int, int],
) -> np.ndarray:
    """Warp a binary template into image coords using a rigid transform.

    Forward transform:
        p_image = R(theta_deg) @ (p_template - c_ref) + c_det
    """
    return _apply_rigid_transform(
        template.astype(bool), theta_deg, c_ref, c_det, output_shape,
    )


def build_aligned_regions(
    head_template: np.ndarray,
    stem_template: np.ndarray,
    theta_deg: float,
    c_ref: np.ndarray,
    c_det: np.ndarray,
    output_shape: tuple[int, int],
    stem_tip_fraction: float = 0.25,
) -> dict:
    """Warp head, stem, stem-tip templates into image coords + compute geometry.

    The stem-tip mask is the topmost ``stem_tip_fraction`` of the stem template
    (by row index, before warping), then warped together with the rest.

    Returns dict with:
        head, stem, stem_tip:  bool arrays of shape ``output_shape``
        stem_axis:             (drow, dcol) unit vector pointing DOWN the stem
                               (from tip toward head) in image coords
        stem_base_point:       (row, col) midpoint of the head/stem touching
                               arc — average of the arc's leftmost and
                               rightmost endpoints in template space, then
                               warped to image coords. Lies on the stem's
                               symmetry axis whenever the templates are
                               left/right symmetric about it.
        stem_tip_point:        (row, col) centroid of warped stem-tip mask
    """
    stem_rows, stem_cols = np.nonzero(stem_template)
    if len(stem_rows) == 0:
        raise ValueError("stem_template is empty")
    r_min = int(stem_rows.min())
    r_max = int(stem_rows.max())
    cutoff = r_min + int(round(stem_tip_fraction * (r_max - r_min)))
    stem_tip_template = stem_template & (
        np.arange(stem_template.shape[0])[:, None] <= cutoff
    )

    head = warp_template_to_image(
        head_template, theta_deg, c_ref, c_det, output_shape,
    )
    stem = warp_template_to_image(
        stem_template, theta_deg, c_ref, c_det, output_shape,
    )
    stem_tip = warp_template_to_image(
        stem_tip_template, theta_deg, c_ref, c_det, output_shape,
    )

    # Forward rigid transform: p_image = R(theta) @ (p_template - c_ref) + c_det
    theta_fwd = np.radians(theta_deg)
    cos_f, sin_f = np.cos(theta_fwd), np.sin(theta_fwd)
    R_fwd = np.array([[cos_f, -sin_f], [sin_f, cos_f]])

    # Stem tip point = topmost pixel of the stem template, transformed to image
    # coords. Work in template space (before warping) so the point is exact
    # regardless of how the warped raster resolves at the tip.
    top_row = int(stem_rows.min())
    cols_at_top = stem_cols[stem_rows == top_row]
    tip_template = np.array([float(top_row), float(cols_at_top.mean())])
    stem_tip_point = R_fwd @ (tip_template - c_ref) + c_det

    # Stem base point = midpoint of the head/stem touching arc, computed in
    # template space and warped to image coords (mirroring the stem-tip
    # calculation). The touching region between a curved head and the stem is
    # an arc, not a horizontal line, so its midpoint is the average of the
    # arc's leftmost and rightmost endpoints. For a left/right symmetric pair
    # of templates these endpoints are mirror images about the symmetry axis,
    # so their column-mean lands exactly on the stem's centerline.
    overlap_template = (
        head_template.astype(bool) & stem_template.astype(bool)
    )
    if overlap_template.any():
        ov_rr, ov_cc = np.nonzero(overlap_template)
        left_col = int(ov_cc.min())
        right_col = int(ov_cc.max())
        left_rows = ov_rr[ov_cc == left_col]
        right_rows = ov_rr[ov_cc == right_col]
        left_pt = np.array([float(left_rows.mean()), float(left_col)])
        right_pt = np.array([float(right_rows.mean()), float(right_col)])
        base_template = (left_pt + right_pt) / 2.0
        stem_base_point = R_fwd @ (base_template - c_ref) + c_det
    else:
        # Fallback: bottommost row of stem template (mirror of tip).
        bot_row = int(stem_rows.max())
        cols_at_bot = stem_cols[stem_rows == bot_row]
        base_template = np.array(
            [float(bot_row), float(cols_at_bot.mean())]
        )
        stem_base_point = R_fwd @ (base_template - c_ref) + c_det

    # Derive stem_axis directly from the warped tip→base direction so it always
    # matches the rendered geometry, regardless of any rotation convention drift.
    vec = stem_base_point - stem_tip_point
    n = float(np.linalg.norm(vec))
    if n > 1e-9:
        stem_axis = vec / n  # points DOWN the stem (tip toward base/head)
    else:
        theta_rad = np.radians(theta_deg)
        stem_axis = np.array([np.cos(theta_rad), np.sin(theta_rad)])

    return {
        "head": head,
        "stem": stem,
        "stem_tip": stem_tip,
        "stem_axis": stem_axis,
        "stem_base_point": stem_base_point,
        "stem_tip_point": stem_tip_point,
    }


def measure_region_intensity(
    protein_ch: np.ndarray,
    region_mask: np.ndarray,
    cell_mask: np.ndarray,
    pixel_size: float,
    label: str,
) -> dict:
    """Mean / IntDen / fraction of protein within a region (intersected with cell).

    Returns dict with keys:
        Protein_<label>_Mean      mean intensity within region∩cell
        Protein_<label>_IntDen    mean × calibrated area of region∩cell
        Protein_<label>_Fraction  sum(intensity in region∩cell) / sum(intensity in cell)

    If the region∩cell mask is empty, all values are 0.0.
    """
    region_in_cell = region_mask & cell_mask
    n_region = int(region_in_cell.sum())
    n_cell = int(cell_mask.sum())

    if n_region == 0:
        return {
            f"Protein_{label}_Mean": 0.0,
            f"Protein_{label}_IntDen": 0.0,
            f"Protein_{label}_Fraction": 0.0,
        }

    region_vals = protein_ch[region_in_cell].astype(np.float64)
    cell_vals = protein_ch[cell_mask].astype(np.float64)
    region_sum = float(region_vals.sum())
    cell_sum = float(cell_vals.sum())

    mean = region_sum / n_region
    intden = mean * n_region * (pixel_size ** 2)
    fraction = (region_sum / cell_sum) if cell_sum > 0 else 0.0

    return {
        f"Protein_{label}_Mean": round(mean, 3),
        f"Protein_{label}_IntDen": round(intden, 3),
        f"Protein_{label}_Fraction": round(fraction, 4),
    }


def compute_stem_extension(
    cell_mask: np.ndarray,
    stem_mask: np.ndarray,
    stem_base_point: np.ndarray,
    stem_axis: np.ndarray,
    pixel_size: float,
) -> float:
    """Distance from stem base to the cell-mask pixel furthest along the
    *upward* stem axis (i.e., toward the stem tip).

    Definition: project all (cell ∩ stem) pixel coordinates onto -stem_axis,
    relative to stem_base_point. Report the maximum projection × pixel_size.

    If cell ∩ stem is empty, returns 0.0.
    """
    inter = cell_mask & stem_mask
    if inter.sum() == 0:
        return 0.0
    rr, cc = np.nonzero(inter)
    coords = np.stack([rr.astype(np.float64), cc.astype(np.float64)], axis=1)
    rel = coords - stem_base_point  # (N, 2)
    # Project onto upward axis = -stem_axis
    upward = -stem_axis / max(np.linalg.norm(stem_axis), 1e-9)
    proj = rel @ upward
    extension_px = float(max(proj.max(), 0.0))
    return round(extension_px * pixel_size, 3)


def compute_cell_length(
    cell_mask: np.ndarray,
    stem_axis: np.ndarray,
    pixel_size: float,
) -> float:
    """Full extent of the cell along the stem axis direction.

    Projects every cell-mask pixel onto the upward stem axis and returns
    (max_projection - min_projection) × pixel_size.
    """
    rr, cc = np.nonzero(cell_mask)
    if rr.size == 0:
        return 0.0
    coords = np.stack([rr.astype(np.float64), cc.astype(np.float64)], axis=1)
    upward = -stem_axis / max(np.linalg.norm(stem_axis), 1e-9)
    proj = coords @ upward
    return round(float(proj.max() - proj.min()) * pixel_size, 3)


def compute_stem_tip_to_cell_top(
    cell_mask: np.ndarray,
    stem_tip_point: np.ndarray,
    stem_axis: np.ndarray,
    pixel_size: float,
) -> float:
    """Signed distance from the stem-tip point to the topmost cell pixel,
    both projected onto the upward stem axis.

    Positive = cell extends beyond (above) the stem tip.
    Negative = cell top falls short of the stem tip.
    """
    rr, cc = np.nonzero(cell_mask)
    if rr.size == 0:
        return 0.0
    coords = np.stack([rr.astype(np.float64), cc.astype(np.float64)], axis=1)
    upward = -stem_axis / max(np.linalg.norm(stem_axis), 1e-9)
    tip_proj = float(stem_tip_point @ upward)
    cell_top_proj = float((coords @ upward).max())
    return round((cell_top_proj - tip_proj) * pixel_size, 3)


def compute_protein_extension(
    protein_ch: np.ndarray,
    signal_threshold: float,
    stem_tip_point: np.ndarray,
    stem_axis: np.ndarray,
    pixel_size: float,
    column_window_px: int = 50,
) -> float:
    """Signed distance from stem-tip point to the topmost above-threshold protein
    pixel, projected onto the upward stem axis.

    Only pixels within ``column_window_px`` of stem_tip_point along the
    perpendicular-to-axis direction are considered, to avoid picking up
    bright spots in unrelated parts of the image.

    Positive = signal extends *beyond* (above) stem tip.
    Negative = signal does not reach stem tip.
    Zero    = no above-threshold pixels in window.
    """
    H, W = protein_ch.shape
    rr, cc = np.indices((H, W))
    coords = np.stack([rr.ravel(), cc.ravel()], axis=1).astype(np.float64)
    rel = coords - stem_tip_point  # (N, 2)
    upward = -stem_axis / max(np.linalg.norm(stem_axis), 1e-9)
    perp = np.array([-upward[1], upward[0]])  # 90° rotation
    along = rel @ upward
    cross = np.abs(rel @ perp)

    bright = protein_ch.ravel() >= signal_threshold
    in_window = cross <= column_window_px
    candidates = bright & in_window
    if not candidates.any():
        return 0.0
    max_along = float(along[candidates].max())
    return round(max_along * pixel_size, 3)


def detect_head_protrusions_rolling_ball(
    cell_mask: np.ndarray,
    head_mask: np.ndarray,
    ball_radius_fraction: float = 0.25,
    ball_radius_px: int | None = None,
    min_area_px: int = 50,
    head_dilation_px: int = 30,
    near_head: np.ndarray | None = None,
) -> tuple[list[dict], np.ndarray, float, float]:
    """Rolling-ball-style protrusion detection.

    Idea: morphologically open the cell mask with a disk of radius ``R`` to
    produce the "smoothed cell body"; the candidate protrusion mask is
    (cell_mask AND NOT body) restricted to the dilated head region.
    Components smaller than ``min_area_px`` are filtered out.

    The ball radius ``R`` follows the legacy ``protrusion_detection.py``
    convention:
        R = ball_radius_px           if ball_radius_px is not None
        R = ball_radius_fraction × MIC_radius   otherwise
    where MIC_radius is the cell's maximum inscribed circle radius
    (i.e. ``distance_transform_edt(cell_mask).max()``).

    Returns
    -------
    candidates    : list of per-protrusion dicts (same schema as the
                    template-difference detector).
    body          : Boolean mask of the smoothed cell body.
    mic_radius_px : Cell's MIC radius in pixels.
    ball_R_px     : The radius actually used for the rolling ball.
    """
    from scipy.ndimage import (
        binary_dilation, binary_opening, distance_transform_edt,
    )
    from skimage.measure import label, regionprops
    from skimage.morphology import disk, opening as sk_opening

    edt = distance_transform_edt(cell_mask.astype(bool))
    mic_radius_px = float(edt.max()) if edt.size else 0.0

    if ball_radius_px is not None:
        R = max(1, int(round(float(ball_radius_px))))
    else:
        R = max(3, int(round(mic_radius_px * float(ball_radius_fraction))))

    selem = disk(R)
    body = sk_opening(cell_mask.astype(bool), selem)
    outside_body = cell_mask & ~body

    if near_head is None:
        near_head = binary_dilation(head_mask, iterations=head_dilation_px)

    candidate = outside_body & near_head
    candidate = binary_opening(candidate, iterations=1)

    labeled = label(candidate.astype(np.uint8))
    out: list[dict] = []
    for region in regionprops(labeled):
        if region.area < min_area_px:
            continue
        comp_mask = (labeled == region.label)
        out.append({
            "label": int(region.label),
            "area_px": int(region.area),
            "bbox": tuple(int(x) for x in region.bbox),
            "coords": region.coords.copy(),
            "component_mask": comp_mask,
        })
    return out, body, mic_radius_px, float(R)


def measure_protrusion(
    component_mask: np.ndarray,
    head_mask: np.ndarray,
    stem_axis: np.ndarray,
    pixel_size: float,
    body: np.ndarray | None = None,
) -> dict:
    """Length (skeleton-based) and direction (body boundary → outward tip).

    Length:
        Skeletonize the protrusion + a 2-px-dilated head boundary
        (so the protrusion connects to its base). Pixel count of the
        protrusion's skeleton (intersected with the protrusion itself,
        not the head dilation) ≈ length in pixels.

    Direction (mirrors legacy/protrusion_detection.py):
        If ``body`` (smoothed cell body from rolling-ball opening) is given:
          base = centroid of body-boundary pixels adjacent to the protrusion
          outward = body-boundary tangent normal (PCA on local boundary),
                    oriented away from body centroid
          tip  = farthest protrusion pixel inside a ±45° cone around outward
                 (relaxes to outward half-space, then any pixel, if empty)
        Otherwise (fallback): base = overlap with dilated head_mask, tip =
        farthest pixel from base — same as the original implementation.

        angle_deg = signed angle between (tip - base) and stem_axis
                    (positive = clockwise; 0 = parallel to stem axis)

    Aspect (curvature-tolerant):
        width_px = 2 × max(distance_transform(component_mask))
        aspect   = length_px / width_px
    """
    from scipy.ndimage import binary_dilation, distance_transform_edt
    from skimage.morphology import disk, skeletonize
    from skimage.segmentation import find_boundaries

    head_anchor = binary_dilation(head_mask, iterations=2)

    # ---- length ----
    skel_full = skeletonize(component_mask | head_anchor)
    length_px = int((skel_full & component_mask).sum())
    if length_px == 0:
        # Tiny single-pixel protrusion edge case
        length_px = int(component_mask.sum())

    # ---- direction ----
    base = None
    outward_unit = None
    if body is not None and body.any():
        body_boundary = find_boundaries(body, mode="outer")
        contact = body_boundary & binary_dilation(component_mask, iterations=2)
        if contact.sum() > 0:
            rr_c, cc_c = np.nonzero(contact)
            base = np.array([rr_c.mean(), cc_c.mean()])

            # Outward normal via PCA on local body boundary around base
            tangent_radius = 20
            boundary_pts = np.stack(np.nonzero(body_boundary), axis=1).astype(float)
            local = boundary_pts[
                np.linalg.norm(boundary_pts - base, axis=1) < tangent_radius
            ]
            rr_b, cc_b = np.nonzero(body)
            body_centroid = np.array([rr_b.mean(), cc_b.mean()])
            if len(local) >= 2:
                centered = local - local.mean(axis=0)
                _, _, Vt = np.linalg.svd(centered, full_matrices=False)
                tangent = Vt[0]
                normal = np.array([-tangent[1], tangent[0]])
                if np.dot(normal, base - body_centroid) < 0:
                    normal = -normal
                outward_unit = normal
            else:
                v = base - body_centroid
                n = np.linalg.norm(v)
                outward_unit = v / n if n > 0 else np.array([0.0, 1.0])

    if base is None:
        # Fallback: original behaviour using warped head template overlap
        base_overlap = component_mask & head_anchor
        if base_overlap.sum() > 0:
            rr, cc = np.nonzero(base_overlap)
        else:
            rr, cc = np.nonzero(component_mask)
        base = np.array([rr.mean(), cc.mean()])

    rr_full, cc_full = np.nonzero(component_mask)
    coords = np.stack([rr_full.astype(np.float64),
                       cc_full.astype(np.float64)], axis=1)
    dists = np.linalg.norm(coords - base, axis=1)

    if outward_unit is not None:
        cos45 = np.cos(np.radians(45))
        with np.errstate(invalid="ignore"):
            cosines = np.where(
                dists > 0, (coords - base) @ outward_unit / dists, 0.0,
            )
        in_cone = cosines > cos45
        if in_cone.any():
            tip = coords[np.where(in_cone, dists, -1).argmax()]
        else:
            in_half = cosines > 0
            tip = coords[
                np.where(in_half, dists, -1).argmax()
                if in_half.any() else int(dists.argmax())
            ]
    else:
        tip = coords[int(dists.argmax())]

    vec = tip - base  # (drow, dcol)
    norm = np.linalg.norm(vec)
    if norm == 0:
        angle_deg = 0.0
    else:
        v = vec / norm
        axis = stem_axis / max(np.linalg.norm(stem_axis), 1e-9)
        # Signed angle: cross then atan2(cross, dot)
        cross = axis[0] * v[1] - axis[1] * v[0]
        dot = axis[0] * v[0] + axis[1] * v[1]
        angle_deg = float(np.degrees(np.arctan2(cross, dot)))

    # ---- width + aspect ----
    width_px = 2.0 * float(distance_transform_edt(component_mask).max())
    aspect = (length_px / width_px) if width_px > 0 else 0.0

    return {
        "length_um": round(length_px * pixel_size, 3),
        "length_px": int(length_px),
        "width_px": round(width_px, 2),
        "aspect": round(aspect, 3),
        "angle_deg": round(angle_deg, 3),
        "base_point": base,
        "tip_point": tip,
    }


def summarize_protrusions(
    protrusions: list[dict],
    head_mask: np.ndarray,
    stem_axis: np.ndarray,
    pixel_size: float,
    min_length_um: float = 0.0,
    min_aspect: float = 0.0,
    body: np.ndarray | None = None,
) -> dict:
    """Measure, filter, and aggregate protrusions.

    Each candidate component is measured (length, width, aspect, angle);
    components with ``length_um < min_length_um`` or ``aspect < min_aspect``
    are discarded. The returned ``_kept_protrusions`` list mirrors the
    filtered ``_per_protrusion`` list so downstream QC viz draws only the
    components that were also counted in the CSV.
    """
    empty = {
        "Protrusion_Count": 0,
        "Protrusion_TotalLength_um": 0.0,
        "Protrusion_MaxLength_um": 0.0,
        "Protrusion_MeanLength_um": 0.0,
        "Protrusion_MeanAngleDeg": 0.0,
        "_per_protrusion": [],
        "_kept_protrusions": [],
    }
    if not protrusions:
        return empty

    measured = [
        (p, measure_protrusion(p["component_mask"], head_mask,
                               stem_axis, pixel_size, body=body))
        for p in protrusions
    ]
    kept = [
        (p, m) for p, m in measured
        if m["length_um"] >= min_length_um and m["aspect"] >= min_aspect
    ]
    if not kept:
        return empty

    per = [m for _, m in kept]
    lengths = np.array([m["length_um"] for m in per])
    angles = np.array([m["angle_deg"] for m in per])
    return {
        "Protrusion_Count": int(len(per)),
        "Protrusion_TotalLength_um": round(float(lengths.sum()), 3),
        "Protrusion_MaxLength_um": round(float(lengths.max()), 3),
        "Protrusion_MeanLength_um": round(float(lengths.mean()), 3),
        "Protrusion_MeanAngleDeg": round(float(angles.mean()), 3),
        "_per_protrusion": per,
        "_kept_protrusions": [p for p, _ in kept],
    }


def segment_nucleus(
    nucleus_ch: np.ndarray,
    cell_mask: np.ndarray,
    min_area_px: int = 50,
) -> np.ndarray:
    """Otsu-threshold DAPI inside the cell mask, return cleaned binary nucleus.

    Steps:
        1. Restrict to cell mask
        2. Otsu threshold on the masked pixels
        3. Fill holes
        4. Remove small objects (< min_area_px)
        5. Keep result intersected with cell_mask
    """
    from scipy.ndimage import binary_fill_holes
    from skimage.filters import threshold_otsu
    from skimage.morphology import remove_small_objects

    if cell_mask.sum() == 0:
        return np.zeros_like(cell_mask)

    masked_vals = nucleus_ch[cell_mask]
    if masked_vals.size == 0 or masked_vals.max() == masked_vals.min():
        return np.zeros_like(cell_mask)

    try:
        thresh = threshold_otsu(masked_vals)
    except ValueError:
        return np.zeros_like(cell_mask)

    binary = (nucleus_ch > thresh) & cell_mask
    binary = binary_fill_holes(binary)
    binary = remove_small_objects(binary, min_size=min_area_px)
    return (binary & cell_mask).astype(bool)


def compute_nuc_cyt_ratio(
    protein_ch: np.ndarray,
    nuc_mask: np.ndarray,
    cell_mask: np.ndarray,
    pixel_size: float,
) -> dict:
    """Mean protein in nucleus, in cytoplasm, and ratio."""
    nuc = nuc_mask & cell_mask
    cyt = cell_mask & ~nuc

    n_nuc = int(nuc.sum())
    n_cyt = int(cyt.sum())

    nuc_mean = float(protein_ch[nuc].mean()) if n_nuc > 0 else 0.0
    cyt_mean = float(protein_ch[cyt].mean()) if n_cyt > 0 else 0.0
    ratio = (nuc_mean / cyt_mean) if (cyt_mean > 0 and n_nuc > 0) else 0.0

    return {
        "Nuclear_Area_um2": round(n_nuc * (pixel_size ** 2), 3),
        "Protein_Nuclear_Mean": round(nuc_mean, 3),
        "Protein_Cytoplasmic_Mean": round(cyt_mean, 3),
        "Protein_NucCyt_Ratio": round(ratio, 4),
    }


def quantify_cell(
    cell_mask: np.ndarray,
    regions: dict,
    protein_ch: np.ndarray,
    nucleus_ch: np.ndarray,
    pixel_size: float,
    protein_threshold: float | None = None,
    protrusion_min_area_px: int = 5,
    protrusion_min_length_um: float = 0.8,
    ball_radius_fraction: float = 0.25,
    ball_radius_px: int | None = None,
) -> dict:
    """Compute all new region/cross-channel metrics for a single cell.

    Returns a flat dict suitable for merging into the per-cell CSV row.
    The ``_per_protrusion`` and ``_nuc_mask`` and similar keys (prefixed
    with ``_``) are also returned for use by qc_viz; downstream CSV
    writing should drop keys starting with ``_``.
    """
    from skimage.filters import threshold_otsu

    out: dict = {}

    # ---- Whole-cell protein ----
    cell_vals = protein_ch[cell_mask].astype(np.float64)
    out["Protein_Whole_Mean"] = (
        round(float(cell_vals.mean()), 3) if cell_vals.size else 0.0
    )

    # ---- Region-based protein ----
    for label_, mask in (("Head", regions["head"]),
                        ("Stem", regions["stem"]),
                        ("StemTip", regions["stem_tip"])):
        out.update(measure_region_intensity(
            protein_ch, region_mask=mask, cell_mask=cell_mask,
            pixel_size=pixel_size, label=label_,
        ))

    # ---- Cell length along stem axis ----
    out["CellLength_um"] = compute_cell_length(
        cell_mask=cell_mask,
        stem_axis=regions["stem_axis"],
        pixel_size=pixel_size,
    )

    # ---- Stem-tip to cell-top gap ----
    out["StemTipToCellTop_um"] = compute_stem_tip_to_cell_top(
        cell_mask=cell_mask,
        stem_tip_point=regions["stem_tip_point"],
        stem_axis=regions["stem_axis"],
        pixel_size=pixel_size,
    )

    # ---- Stem extension (cell length along stem) ----
    out["StemExtension_um"] = compute_stem_extension(
        cell_mask=cell_mask,
        stem_mask=regions["stem"],
        stem_base_point=regions["stem_base_point"],
        stem_axis=regions["stem_axis"],
        pixel_size=pixel_size,
    )

    # ---- Protein extension beyond stem tip ----
    # Image-level quantity: reuse precomputed value if present (same for all cells).
    if "_protein_extension_um" in regions:
        out["ProteinExtension_um"] = regions["_protein_extension_um"]
        protein_threshold = regions.get("_protein_threshold", protein_threshold)
    else:
        if protein_threshold is None:
            try:
                protein_threshold = float(threshold_otsu(protein_ch))
            except ValueError:
                protein_threshold = float(protein_ch.mean())
        out["ProteinExtension_um"] = compute_protein_extension(
            protein_ch=protein_ch,
            signal_threshold=protein_threshold,
            stem_tip_point=regions["stem_tip_point"],
            stem_axis=regions["stem_axis"],
            pixel_size=pixel_size,
        )

    # ---- Protrusions (rolling-ball method) ----
    candidates, _body, _mic_R, _ball_R = detect_head_protrusions_rolling_ball(
        cell_mask=cell_mask,
        head_mask=regions["head"],
        ball_radius_fraction=float(ball_radius_fraction),
        ball_radius_px=ball_radius_px,
        near_head=regions.get("_near_head"),
        min_area_px=protrusion_min_area_px,
    )
    out["_rolling_body"] = _body
    out["_mic_radius_px"] = _mic_R
    out["_rolling_ball_R_px"] = _ball_R
    summary = summarize_protrusions(
        candidates, head_mask=regions["head"],
        stem_axis=regions["stem_axis"], pixel_size=pixel_size,
        min_length_um=protrusion_min_length_um,
        body=_body,
    )
    per_protrusion = summary.pop("_per_protrusion")
    kept = summary.pop("_kept_protrusions")
    out.update(summary)
    out["_protrusions"] = kept
    out["_per_protrusion"] = per_protrusion

    # ---- Nucleus + N/C ratio ----
    nuc_mask = segment_nucleus(nucleus_ch, cell_mask)
    out.update(compute_nuc_cyt_ratio(
        protein_ch, nuc_mask=nuc_mask, cell_mask=cell_mask,
        pixel_size=pixel_size,
    ))
    out["_nuc_mask"] = nuc_mask
    out["_protein_threshold"] = protein_threshold

    return out
