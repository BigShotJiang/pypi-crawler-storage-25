"""Per-cell and per-image QC visualisations for the cross-channel pipeline."""
from __future__ import annotations
from pathlib import Path

import numpy as np


# Palette used by the protrusion overview / detail figures. Mirrors the
# constant in ``protrusion_detection.py`` so the pipeline output is identical
# whether driven by the standalone CLI script or the napari plugin.
PROTRUSION_COLORS = [
    "#e6194b", "#3cb44b", "#4363d8", "#f58231", "#911eb4",
    "#42d4f4", "#f032e6", "#bfef45", "#fabed4", "#469990",
]


def _visualise_protrusions(mip, labeled_cells, results, pixel_size, out_path):
    """In-tree copy of ``protrusion_detection.visualise``.

    Saves two figures next to ``out_path``:
        <out_path>                          — per-cell 3-panel detail
        <out_path stem>_overview.png        — whole-image overview
    """
    import matplotlib.colors as mc
    import matplotlib.patches as mpatches
    import matplotlib.pyplot as plt
    from skimage.segmentation import find_boundaries

    lo, hi = np.percentile(mip, [1, 99])
    mip_norm = np.clip((mip.astype(float) - lo) / max(hi - lo, 1.0), 0, 1)

    # ---- Overview -------------------------------------------------------
    fig_ov, ax = plt.subplots(figsize=(8, 8))
    ax.imshow(mip_norm, cmap="gray", vmin=0, vmax=1)

    for res in results:
        bov = np.zeros((*mip_norm.shape, 4), dtype=float)
        bov[res["cell_mask"]] = [1, 1, 0, 0.2]
        cb = find_boundaries(res["cell_mask"], mode="outer")
        bov[cb] = [1, 1, 0, 0.9]
        ax.imshow(bov)

        bdy = find_boundaries(res["main_body"], mode="outer")
        bdov = np.zeros((*mip_norm.shape, 4), dtype=float)
        bdov[bdy & ~cb] = [0.2, 0.9, 1.0, 0.7]
        ax.imshow(bdov)

        for j, prot in enumerate(res["protrusions"]):
            col = PROTRUSION_COLORS[j % len(PROTRUSION_COLORS)]
            rgba = np.zeros((*mip_norm.shape, 4), dtype=float)
            rgba[prot["_mask"]] = [*mc.to_rgb(col), 0.65]
            ax.imshow(rgba)
            tip = prot["tip_point"]
            base = prot["base_point"]
            ax.annotate("", xy=(tip[1], tip[0]), xytext=(base[1], base[0]),
                        arrowprops=dict(arrowstyle="->", color=col, lw=2.0))
            length_um = prot["length_px"] * pixel_size
            ax.text(tip[1] + 4, tip[0], f"{length_um:.1f}µm",
                    color="white", fontsize=8, fontweight="bold",
                    bbox=dict(boxstyle="round,pad=0.25", fc=col,
                              alpha=0.9, lw=0.3, ec="white"))

        rr, cc = np.nonzero(res["cell_mask"])
        ax.text(cc.mean(), rr.mean(), f"C{res['cell_idx']}",
                color="white", fontsize=11, ha="center", va="center",
                fontweight="bold",
                bbox=dict(boxstyle="circle,pad=0.3", fc="black",
                          alpha=0.65, lw=0.8, ec="white"))

    legend_handles = [
        mpatches.Patch(color="yellow", label="Cell boundary"),
        mpatches.Patch(color="#33e5ff", label="Main body (rolling ball)"),
        mpatches.Patch(color="tomato", alpha=0.65, label="Protrusion"),
    ]
    ax.legend(handles=legend_handles, loc="lower right", fontsize=9,
              framealpha=0.7, facecolor="black", labelcolor="white")
    ax.set_title("Overview — rolling-ball protrusion detection", fontsize=11)
    ax.axis("off")
    fig_ov.tight_layout()
    ov_path = out_path.with_name(out_path.stem + "_overview.png")
    fig_ov.savefig(ov_path, dpi=150, bbox_inches="tight")
    plt.close(fig_ov)

    # ---- Per-cell 3-panel detail ----------------------------------------
    n = len(results)
    # Extra vertical headroom per row so the suptitle and per-axes titles
    # don't collide; larger title font matches.
    fig, axes = plt.subplots(n, 3, figsize=(16, 5.6 * n), squeeze=False,
                              facecolor="#dddddd")

    title_kw = dict(fontsize=11, pad=10, color="black")

    def _label_bbox(face_color):
        # White text on a saturated coloured pill — high contrast on any
        # underlying gray/heatmap background.
        return dict(
            boxstyle="round,pad=0.3", fc=face_color, alpha=0.9, lw=0.4,
            ec="white",
        )

    for i, res in enumerate(results):
        bbox = res["bbox"]
        crop = mip_norm[bbox[0]:bbox[2], bbox[1]:bbox[3]]
        edt_crop = res["edt"][bbox[0]:bbox[2], bbox[1]:bbox[3]]

        axes[i][0].imshow(crop, cmap="gray", vmin=0, vmax=1)
        cell_c = res["cell_mask"][bbox[0]:bbox[2], bbox[1]:bbox[3]]
        body_c = res["main_body"][bbox[0]:bbox[2], bbox[1]:bbox[3]]
        ov0 = np.zeros((*crop.shape, 4), dtype=float)
        ov0[cell_c] = [1, 1, 0, 0.25]
        cb = find_boundaries(cell_c, mode="outer")
        ov0[cb] = [1, 1, 0, 1.0]
        bb = find_boundaries(body_c, mode="outer")
        ov0[bb & ~cb] = [0.2, 0.9, 1, 0.9]
        axes[i][0].imshow(ov0)
        axes[i][0].set_title(
            f"Cell {res['cell_idx']} — mask (yellow) / body (cyan)\n"
            f"MIC={res['mic_radius']:.0f}px   ball R={res['ball_R']:.0f}px",
            **title_kw,
        )
        axes[i][0].axis("off")

        edt_disp = np.where(cell_c, edt_crop, np.nan)
        im = axes[i][1].imshow(edt_disp, cmap="hot", interpolation="nearest")
        ball_centers = edt_crop >= res["ball_R"]
        bc_ov = np.zeros((*crop.shape, 4), dtype=float)
        bc_ov[ball_centers] = [0.2, 0.8, 0.2, 0.4]
        axes[i][1].imshow(bc_ov)
        plt.colorbar(im, ax=axes[i][1], fraction=0.04, label="EDT (px)")
        axes[i][1].set_title(
            f"Cell {res['cell_idx']} — EDT heatmap\n"
            f"green = ball-center region (EDT ≥ {res['ball_R']:.0f}px)",
            **title_kw,
        )
        axes[i][1].axis("off")

        axes[i][2].imshow(crop, cmap="gray", vmin=0, vmax=1)
        ov2 = np.zeros((*crop.shape, 4), dtype=float)
        ov2[bb] = [0.2, 0.9, 1, 0.8]
        axes[i][2].imshow(ov2)

        for j, prot in enumerate(res["protrusions"]):
            col = PROTRUSION_COLORS[j % len(PROTRUSION_COLORS)]
            pm = prot["_mask"][bbox[0]:bbox[2], bbox[1]:bbox[3]]
            rgba = np.zeros((*crop.shape, 4), dtype=float)
            rgba[pm] = [*mc.to_rgb(col), 0.65]
            axes[i][2].imshow(rgba)
            base = prot["base_point"] - np.array([bbox[0], bbox[1]])
            tip = prot["tip_point"] - np.array([bbox[0], bbox[1]])
            axes[i][2].annotate(
                "", xy=(tip[1], tip[0]), xytext=(base[1], base[0]),
                arrowprops=dict(arrowstyle="->", color=col, lw=2.2),
            )
            length_um = prot["length_px"] * pixel_size
            axes[i][2].text(
                tip[1] + 4, tip[0],
                f"#{j+1}  {length_um:.1f}µm   AR={prot['aspect_ratio']}\n"
                f"{prot['angle_deg']:.0f}°   neck={prot['neck_width_px']:.0f}px",
                color="white", fontsize=8, va="center", fontweight="bold",
                bbox=_label_bbox(col),
            )

        n_prot = len(res["protrusions"])
        axes[i][2].set_title(
            f"Cell {res['cell_idx']} — {n_prot} protrusion"
            f"{'s' if n_prot != 1 else ''}",
            **title_kw,
        )
        axes[i][2].axis("off")

    fig.suptitle(
        "Rolling-ball protrusion detection   |   EDT heatmap   |   protrusions",
        fontsize=14, y=0.995, color="black",
    )
    # Reserve a taller top strip so the suptitle sits well above the per-axes
    # titles, and add inter-row gap to prevent vertical overlap.
    fig.tight_layout(rect=[0, 0, 1, 0.93])
    fig.subplots_adjust(hspace=0.34, top=max(0.91, 1 - 0.7 / max(n, 1)))
    fig.savefig(out_path, dpi=150, bbox_inches="tight",
                facecolor=fig.get_facecolor())
    plt.close(fig)


def _stretch(img: np.ndarray) -> np.ndarray:
    """Percentile-stretch to [0, 1] for display."""
    vals = img[img > 0] if img.any() else img.ravel()
    if vals.size == 0:
        return np.zeros_like(img, dtype=np.float32)
    lo, hi = np.percentile(vals, [1, 99])
    return np.clip(
        (img.astype(np.float32) - lo) / max(hi - lo, 1e-6), 0, 1,
    )


def _crop_for_cell(arr: np.ndarray, cell_mask: np.ndarray, pad: int = 30,
                   extra_masks: list[np.ndarray] | None = None):
    """Return (cropped_array, (r0, c0)) restricted to (cell_mask ∪ extras) bbox + pad.

    ``extra_masks`` is used to guarantee that the warped pattern (head ∪ stem)
    is fully contained in the crop, so it isn't clipped when rendered.
    """
    union = cell_mask.astype(bool)
    if extra_masks:
        for m in extra_masks:
            if m is not None and m.shape == cell_mask.shape:
                union = union | m.astype(bool)
    rr, cc = np.nonzero(union)
    if rr.size == 0:
        return arr, (0, 0)
    r0, r1 = max(rr.min() - pad, 0), min(rr.max() + pad + 1, arr.shape[0])
    c0, c1 = max(cc.min() - pad, 0), min(cc.max() + pad + 1, arr.shape[1])
    return arr[r0:r1, c0:c1], (r0, c0)


def save_cell_qc_png(
    cell_mask: np.ndarray,
    cell_id: str,
    regions: dict,
    protein_ch: np.ndarray,
    nucleus_ch: np.ndarray,
    metrics: dict,
    dst: Path,
) -> None:
    """6-panel QC PNG for one cell.

    Layout:
        (0,0) cell mask + region contours (head=red, stem=green, tip=yellow)
        (0,1) protein heatmap + cell + region contours
        (0,2) nucleus heatmap + nuclear mask contour + cell contour
        (1,0) protrusions colored, with arrow base->tip + length label
        (1,1) stem extension annotation + protein extension annotation
        (1,2) text panel with metric values
    """
    import matplotlib.pyplot as plt

    pad = 30
    extras = [regions.get("head"), regions.get("stem")]
    cropped_cell, (r0, c0) = _crop_for_cell(cell_mask, cell_mask, pad, extras)

    def crop(arr: np.ndarray) -> np.ndarray:
        return arr[r0:r0 + cropped_cell.shape[0],
                   c0:c0 + cropped_cell.shape[1]]

    head_c = crop(regions["head"])
    stem_c = crop(regions["stem"])
    protein_c = crop(protein_ch)
    nucleus_c = crop(nucleus_ch)
    nuc_mask = metrics.get("_nuc_mask", np.zeros_like(cell_mask))
    nuc_mask_c = crop(nuc_mask)

    fig, axes = plt.subplots(2, 3, figsize=(18, 12))

    # (0,0) Cell mask + region contours
    axes[0, 0].imshow(cropped_cell, cmap="gray")
    axes[0, 0].contour(head_c, levels=[0.5], colors="red", linewidths=1.5)
    axes[0, 0].contour(stem_c, levels=[0.5], colors="lime", linewidths=1.5)
    stem_tip_pt = regions["stem_tip_point"] - np.array([r0, c0])
    axes[0, 0].plot(stem_tip_pt[1], stem_tip_pt[0], "y*", ms=10, label="stem tip")
    axes[0, 0].set_title(f"{cell_id} — cell + regions"); axes[0, 0].axis("off")

    # (0,1) Protein + cell + region contours
    axes[0, 1].imshow(_stretch(protein_c), cmap="magma")
    axes[0, 1].contour(cropped_cell, levels=[0.5], colors="cyan", linewidths=1.0)
    axes[0, 1].contour(head_c, levels=[0.5], colors="red", linewidths=1.0)
    axes[0, 1].contour(stem_c, levels=[0.5], colors="lime", linewidths=1.0)
    axes[0, 1].plot(stem_tip_pt[1], stem_tip_pt[0], "y*", ms=10)
    axes[0, 1].set_title(
        f"protein — head={metrics['Protein_Head_Mean']:.0f} "
        f"stem={metrics['Protein_Stem_Mean']:.0f}")
    axes[0, 1].axis("off")

    # (0,2) Nucleus + nuc mask + cell contour
    axes[0, 2].imshow(_stretch(nucleus_c), cmap="Blues_r")
    axes[0, 2].contour(cropped_cell, levels=[0.5], colors="cyan", linewidths=1.0)
    if nuc_mask_c.any():
        axes[0, 2].contour(nuc_mask_c, levels=[0.5], colors="magenta",
                           linewidths=1.5)
    axes[0, 2].set_title(
        f"DAPI — N/C ratio={metrics['Protein_NucCyt_Ratio']:.2f}  "
        f"NucArea={metrics['Nuclear_Area_um2']:.0f}")
    axes[0, 2].axis("off")

    # (1,0) Protrusions
    per_p = metrics.get("_per_protrusion", [])
    protrusions = metrics.get("_protrusions", [])
    axes[1, 0].imshow(cropped_cell, cmap="gray")
    axes[1, 0].contour(head_c, levels=[0.5], colors="red", linewidths=1.0)
    axes[1, 0].contour(stem_c, levels=[0.5], colors="lime", linewidths=1.0)
    cmap = plt.get_cmap("tab10")
    for i, (p, m) in enumerate(zip(protrusions, per_p)):
        comp_c = crop(p["component_mask"])
        rgba = list(cmap(i % 10))
        rgba[3] = 0.7
        axes[1, 0].contour(comp_c, levels=[0.5], colors=[tuple(rgba)],
                           linewidths=1.5)
        # base/tip arrow (translate to crop coords)
        base_r, base_c = m["base_point"][0] - r0, m["base_point"][1] - c0
        tip_r, tip_c = m["tip_point"][0] - r0, m["tip_point"][1] - c0
        axes[1, 0].annotate(
            "", xy=(tip_c, tip_r), xytext=(base_c, base_r),
            arrowprops=dict(arrowstyle="->", color=tuple(rgba), lw=1.5),
        )
        axes[1, 0].text(
            tip_c + 2, tip_r,
            f"L={m['length_um']:.1f}\n{m['angle_deg']:+.0f}°",
            color=tuple(rgba), fontsize=7,
        )
    axes[1, 0].set_title(
        f"Protrusions — count={metrics['Protrusion_Count']}  "
        f"max={metrics['Protrusion_MaxLength_um']:.1f} µm")
    axes[1, 0].axis("off")

    # (1,1) Cell length + stem-tip-to-cell-top + protein extension
    axes[1, 1].imshow(cropped_cell, cmap="gray")
    axes[1, 1].contour(stem_c, levels=[0.5], colors="lime", linewidths=1.0)

    stem_axis = regions["stem_axis"]
    upward = -stem_axis / max(float(np.linalg.norm(stem_axis)), 1e-9)
    base = regions["stem_base_point"] - np.array([r0, c0])
    tip = regions["stem_tip_point"] - np.array([r0, c0])

    # Stem axis guide line
    axes[1, 1].plot([base[1], tip[1]], [base[0], tip[0]], "y--", lw=1.5,
                    label="Stem axis")
    axes[1, 1].plot(tip[1], tip[0], "y*", ms=14, label="Stem tip")
    axes[1, 1].plot(base[1], base[0], "y+", ms=14, label="Stem base")

    # --- Cell length: double-headed arrow between topmost and bottommost
    #     cell pixels projected onto the stem axis ---
    rr_all, cc_all = np.nonzero(cropped_cell)
    if rr_all.size > 0:
        coords_full = np.stack(
            [rr_all.astype(float) + r0, cc_all.astype(float) + c0], axis=1
        )
        proj_full = coords_full @ upward
        bot_pt = coords_full[proj_full.argmin()] - np.array([r0, c0])
        top_pt = coords_full[proj_full.argmax()] - np.array([r0, c0])
        axes[1, 1].annotate(
            "", xy=(top_pt[1], top_pt[0]), xytext=(bot_pt[1], bot_pt[0]),
            arrowprops=dict(arrowstyle="<->", color="white", lw=2.0),
        )
        mid = (top_pt + bot_pt) / 2
        axes[1, 1].text(
            mid[1] + 4, mid[0],
            f"L={metrics.get('CellLength_um', 0):.1f} µm",
            color="white", fontsize=8, va="center",
        )

        # --- Stem-tip to cell-top gap: arrow from stem tip to topmost cell
        #     pixel; green = cell overhangs, red = cell falls short ---
        gap = metrics.get("StemTipToCellTop_um", 0)
        gap_color = "lime" if gap >= 0 else "tomato"
        axes[1, 1].annotate(
            "", xy=(top_pt[1], top_pt[0]),
            xytext=(tip[1], tip[0]),
            arrowprops=dict(arrowstyle="->", color=gap_color, lw=2.0),
        )
        axes[1, 1].text(
            top_pt[1] + 4, (top_pt[0] + tip[0]) / 2,
            f"gap={gap:+.1f} µm",
            color=gap_color, fontsize=8, va="center",
        )

    axes[1, 1].legend(loc="upper right", fontsize=7)
    axes[1, 1].set_title(
        f"Cell length={metrics.get('CellLength_um', 0):.1f} µm  "
        f"gap={metrics.get('StemTipToCellTop_um', 0):+.1f} µm"
    )
    axes[1, 1].axis("off")

    # (1,2) Text panel
    axes[1, 2].axis("off")
    text_lines = [
        f"{cell_id}",
        "",
        f"protein Whole Mean    : {metrics['Protein_Whole_Mean']:.1f}",
        f"protein Head Mean     : {metrics['Protein_Head_Mean']:.1f}",
        f"protein Head Fraction : {metrics['Protein_Head_Fraction']:.3f}",
        f"protein Stem Mean     : {metrics['Protein_Stem_Mean']:.1f}",
        f"protein Stem Fraction : {metrics['Protein_Stem_Fraction']:.3f}",
        f"protein StemTip Mean  : {metrics['Protein_StemTip_Mean']:.1f}",
        f"CellLength_um      : {metrics.get('CellLength_um', 0):.2f}",
        f"StemTipToCellTop_um: {metrics.get('StemTipToCellTop_um', 0):+.2f}",
        f"StemExtension_um   : {metrics['StemExtension_um']:.2f}",
        f"ProteinExtension_um: {metrics['ProteinExtension_um']:+.2f}",
        f"Protrusion Count   : {metrics['Protrusion_Count']}",
        f"Protr. TotalLen_um : {metrics['Protrusion_TotalLength_um']:.2f}",
        f"Protr. MaxLen_um   : {metrics['Protrusion_MaxLength_um']:.2f}",
        f"Protr. MeanAngle°  : {metrics['Protrusion_MeanAngleDeg']:.1f}",
        f"Nuclear Area um2   : {metrics['Nuclear_Area_um2']:.1f}",
        f"protein Nuclear Mean  : {metrics['Protein_Nuclear_Mean']:.1f}",
        f"protein Cytopl. Mean  : {metrics['Protein_Cytoplasmic_Mean']:.1f}",
        f"protein N/C Ratio     : {metrics['Protein_NucCyt_Ratio']:.3f}",
    ]
    axes[1, 2].text(
        0.02, 0.98, "\n".join(text_lines),
        family="monospace", fontsize=9, va="top", ha="left",
        transform=axes[1, 2].transAxes,
    )

    fig.tight_layout()
    fig.savefig(dst, dpi=100, bbox_inches="tight")
    import matplotlib.pyplot as _plt2
    _plt2.close(fig)


def save_cell_protrusion_png(
    cell_mask: np.ndarray,
    cell_id: str,
    regions: dict,
    protein_ch: np.ndarray,
    metrics: dict,
    dst: Path,
) -> None:
    """Focused per-cell protrusion image.

    Two panels: (left) cell mask with head/stem contours and colored
    protrusions + base→tip arrows + length/angle labels; (right) protein
    heatmap with the same annotations.
    """
    import matplotlib.pyplot as plt

    pad = 30
    extras = [regions.get("head"), regions.get("stem")]
    cropped_cell, (r0, c0) = _crop_for_cell(cell_mask, cell_mask, pad, extras)

    def crop(arr: np.ndarray) -> np.ndarray:
        return arr[r0:r0 + cropped_cell.shape[0],
                   c0:c0 + cropped_cell.shape[1]]

    head_c = crop(regions["head"])
    stem_c = crop(regions["stem"])
    protein_c = crop(protein_ch)

    per_p = metrics.get("_per_protrusion", [])
    protrusions = metrics.get("_protrusions", [])

    fig, axes = plt.subplots(1, 2, figsize=(14, 7), facecolor="#dddddd")

    cmap = plt.get_cmap("tab10")

    def _draw_protrusions(ax):
        ax.contour(cropped_cell, levels=[0.5], colors="cyan", linewidths=1.0)
        ax.contour(head_c, levels=[0.5], colors="red", linewidths=1.0)
        ax.contour(stem_c, levels=[0.5], colors="lime", linewidths=1.0)
        for i, (p, m) in enumerate(zip(protrusions, per_p)):
            comp_c = crop(p["component_mask"])
            rgba = list(cmap(i % 10))
            rgba[3] = 0.85
            ax.contour(
                comp_c, levels=[0.5], colors=[tuple(rgba)], linewidths=2.0,
            )
            base_r, base_c_ = m["base_point"][0] - r0, m["base_point"][1] - c0
            tip_r, tip_c_ = m["tip_point"][0] - r0, m["tip_point"][1] - c0
            ax.annotate(
                "", xy=(tip_c_, tip_r), xytext=(base_c_, base_r),
                arrowprops=dict(arrowstyle="->", color=tuple(rgba), lw=2.0),
            )
            ax.text(
                tip_c_ + 2, tip_r,
                f"#{i+1}  L={m['length_um']:.1f}µm  {m['angle_deg']:+.0f}°",
                color=tuple(rgba), fontsize=8,
                bbox=dict(facecolor="black", alpha=0.4, pad=1, edgecolor="none"),
            )

    sub_title_kw = dict(fontsize=10, pad=10, color="black")

    # Left: cell mask background
    axes[0].imshow(cropped_cell, cmap="gray")
    _draw_protrusions(axes[0])
    axes[0].set_title(f"{cell_id} — protrusions on cell mask", **sub_title_kw)
    axes[0].axis("off")

    # Right: protein heatmap background
    axes[1].imshow(_stretch(protein_c), cmap="magma")
    _draw_protrusions(axes[1])
    axes[1].set_title("Protrusions on protein heatmap", **sub_title_kw)
    axes[1].axis("off")

    fig.suptitle(
        f"{cell_id}  —  count={metrics.get('Protrusion_Count', 0)}  "
        f"total={metrics.get('Protrusion_TotalLength_um', 0):.1f} µm  "
        f"max={metrics.get('Protrusion_MaxLength_um', 0):.1f} µm  "
        f"mean angle={metrics.get('Protrusion_MeanAngleDeg', 0):.0f}°",
        fontsize=12, color="black", y=0.99,
    )
    fig.tight_layout(rect=[0, 0, 1, 0.90])
    fig.subplots_adjust(top=0.86)
    fig.savefig(dst, dpi=100, bbox_inches="tight",
                facecolor=fig.get_facecolor())
    import matplotlib.pyplot as _plt2
    _plt2.close(fig)


def save_protrusion_visualisations(
    cell_channel: np.ndarray,
    cell_label_image: np.ndarray,
    cell_records: list[dict],
    pixel_size: float,
    dst_protrusions: Path,
    ball_radius_fraction: float = 0.25,
) -> None:
    """Build the per-cell ``results`` schema and delegate to the in-tree
    ``_visualise_protrusions`` (an exact copy of ``protrusion_detection.visualise``).

    Per-cell ``mic_radius`` and ``ball_R`` are taken from the cell record
    (``_mic_radius_px`` / ``_rolling_ball_R_px``) when present; otherwise we
    fall back to recomputing the MIC from the cell mask and applying
    ``ball_radius_fraction``.

    Writes:
        <dst_protrusions>                      — per-cell 3-panel detail
        <dst_protrusions stem>_overview.png    — overview, auto-derived
    """
    from scipy.ndimage import distance_transform_edt
    from skimage.morphology import binary_opening, disk

    results: list[dict] = []
    for rec in cell_records:
        full_cell_mask = rec.get("_full_cell_mask")
        if full_cell_mask is None:
            continue

        edt = distance_transform_edt(full_cell_mask)
        mic_radius = float(rec.get("_mic_radius_px",
                                   float(edt.max()) if edt.size else 0.0))
        ball_R = float(rec.get("_rolling_ball_R_px",
                                max(3, int(round(mic_radius * ball_radius_fraction)))))

        body = rec.get("_rolling_body")
        if body is None:
            body = binary_opening(full_cell_mask.astype(bool),
                                  disk(max(int(ball_R), 1)))

        rr, cc = np.nonzero(full_cell_mask)
        if rr.size == 0:
            continue
        pad = 20
        bbox = (
            max(0, int(rr.min()) - pad),
            max(0, int(cc.min()) - pad),
            min(full_cell_mask.shape[0], int(rr.max()) + pad + 1),
            min(full_cell_mask.shape[1], int(cc.max()) + pad + 1),
        )

        # Adapt our protrusion records → protrusion_detection.visualise schema.
        prots_out: list[dict] = []
        components = rec.get("_protrusions", []) or []
        per_p = rec.get("_per_protrusion", []) or []
        for i, (p, m) in enumerate(zip(components, per_p)):
            # visualise() displays length_um = length_px * pixel_size, so feed
            # it the calibrated length back-converted to "pixels" to keep the
            # printed label consistent with the CSV's length_um.
            length_um = float(m.get("length_um", 0.0))
            length_px_for_viz = length_um / pixel_size if pixel_size > 0 else 0.0
            prots_out.append({
                "label":         i + 1,
                "area_px":       int(p["component_mask"].sum()),
                "length_px":     length_px_for_viz,
                "angle_deg":     float(m.get("angle_deg", 0.0)),
                "base_point":    np.asarray(m["base_point"], dtype=float),
                "tip_point":     np.asarray(m["tip_point"], dtype=float),
                "neck_width_px": float(m.get("width_px", 0.0)),
                "aspect_ratio":  float(m.get("aspect", 0.0)),
                "_mask":         p["component_mask"],
            })

        # Cell index from the label string ``MAX_<title>_Cell_<n>``.
        lbl = rec.get("_label", "") or rec.get("Label", "")
        try:
            cell_idx = int(str(lbl).rsplit("_Cell_", 1)[-1])
        except (ValueError, IndexError):
            cell_idx = 0

        results.append({
            "cell_idx":    cell_idx,
            "cell_mask":   full_cell_mask,
            "main_body":   body.astype(bool),
            "edt":         edt,
            "mic_radius":  mic_radius,
            "ball_R":      ball_R,
            "bbox":        bbox,
            "protrusions": prots_out,
        })

    if not results:
        return

    _visualise_protrusions(
        mip=cell_channel,
        labeled_cells=cell_label_image,
        results=results,
        pixel_size=float(pixel_size),
        out_path=Path(dst_protrusions),
    )


def save_image_protrusions_png(
    cell_label_image: np.ndarray,
    regions: dict,
    cell_records: list[dict],
    title: str,
    dst: Path,
) -> None:
    """Per-image protrusion result figure.

    Two panels:
        (left)  cell mask filled + rolling-ball body outline + head/stem
                contours + protrusion outlines + per-protrusion length labels
        (right) EDT (Euclidean distance transform) heatmap of the cell mask,
                same protrusion overlays
    """
    import matplotlib.pyplot as plt
    from scipy.ndimage import distance_transform_edt

    cell_mask = cell_label_image > 0

    fig, axes = plt.subplots(1, 2, figsize=(16, 8))
    cmap = plt.get_cmap("tab10")

    # Smoothed "body" (rolling-ball opening of the cell mask) for context.
    try:
        from skimage.morphology import binary_opening, disk
        body = binary_opening(cell_mask, disk(8))
    except Exception:
        body = cell_mask

    # Aggregate every protrusion across every cell, then assign colors.
    all_prot: list[tuple[dict, dict, str]] = []
    for rec in cell_records:
        prots = rec.get("_protrusions", []) or []
        per_p = rec.get("_per_protrusion", []) or []
        label = rec.get("Label", rec.get("_label", "Cell"))
        for p, m in zip(prots, per_p):
            all_prot.append((p, m, label))

    def _draw(ax, base_img, base_cmap, base_alpha=1.0):
        ax.imshow(base_img, cmap=base_cmap, alpha=base_alpha)
        ax.contour(cell_mask, levels=[0.5], colors="cyan", linewidths=0.8)
        ax.contour(body, levels=[0.5], colors="white", linewidths=0.6,
                   linestyles="--")
        ax.contour(regions["head"], levels=[0.5], colors="red", linewidths=0.8)
        ax.contour(regions["stem"], levels=[0.5], colors="lime", linewidths=0.8)
        for i, (p, m, lbl) in enumerate(all_prot):
            rgba = list(cmap(i % 10)); rgba[3] = 0.9
            ax.contour(p["component_mask"], levels=[0.5],
                       colors=[tuple(rgba)], linewidths=1.4)
            tip_r, tip_c = m["tip_point"]
            ax.text(tip_c + 2, tip_r,
                    f"L={m['length_um']:.1f}µm",
                    color=tuple(rgba), fontsize=6,
                    bbox=dict(facecolor="black", alpha=0.4, pad=0.5,
                              edgecolor="none"))
        ax.axis("off")

    # Left: cell mask fill + body
    fill = np.zeros_like(cell_mask, dtype=np.float32)
    fill[cell_mask] = 0.65
    fill[body] = 1.0
    _draw(axes[0], fill, "gray")
    axes[0].set_title(f"{title} — cell + body + protrusions"
                      f"  (n={len(all_prot)})")

    # Right: EDT heatmap inside the cell
    edt = distance_transform_edt(cell_mask)
    _draw(axes[1], edt, "inferno", base_alpha=1.0)
    axes[1].set_title("EDT heatmap + protrusions")

    fig.tight_layout()
    fig.savefig(dst, dpi=120, bbox_inches="tight")
    import matplotlib.pyplot as _plt2
    _plt2.close(fig)


def save_image_protrusions_overview_png(
    cell_label_image: np.ndarray,
    regions: dict,
    cell_records: list[dict],
    title: str,
    dst: Path,
) -> None:
    """Per-image protrusion overview.

    One panel on a dim cell-mask backdrop with each protrusion drawn as a
    filled coloured region, a base→tip arrow, and a length / angle label.
    """
    import matplotlib.pyplot as plt
    from matplotlib.colors import to_rgba

    cell_mask = cell_label_image > 0

    fig, ax = plt.subplots(figsize=(10, 10))
    backdrop = np.where(cell_mask, 0.25, 0.0).astype(np.float32)
    ax.imshow(backdrop, cmap="gray", vmin=0, vmax=1)
    ax.contour(cell_mask, levels=[0.5], colors="cyan", linewidths=0.8)
    ax.contour(regions["head"], levels=[0.5], colors="red", linewidths=0.6)
    ax.contour(regions["stem"], levels=[0.5], colors="lime", linewidths=0.6)

    cmap = plt.get_cmap("tab20")
    H, W = cell_mask.shape
    rgba_overlay = np.zeros((H, W, 4), dtype=np.float32)
    counter = 0
    total_len = 0.0
    for rec in cell_records:
        prots = rec.get("_protrusions", []) or []
        per_p = rec.get("_per_protrusion", []) or []
        for p, m in zip(prots, per_p):
            color = np.array(to_rgba(cmap(counter % 20)))
            color[3] = 0.65
            mask = p["component_mask"]
            rgba_overlay[mask] = color
            base_r, base_c = m["base_point"]
            tip_r, tip_c = m["tip_point"]
            ax.annotate(
                "", xy=(tip_c, tip_r), xytext=(base_c, base_r),
                arrowprops=dict(arrowstyle="->", color=tuple(color[:3]),
                                lw=1.8),
            )
            ax.text(
                tip_c + 3, tip_r,
                f"#{counter+1} L={m['length_um']:.1f}µm  {m['angle_deg']:+.0f}°",
                color=tuple(color[:3]), fontsize=7,
                bbox=dict(facecolor="black", alpha=0.5, pad=1,
                          edgecolor="none"),
            )
            counter += 1
            total_len += float(m["length_um"])
    ax.imshow(rgba_overlay)
    ax.set_title(
        f"{title} — protrusion overview  "
        f"(count={counter}, total={total_len:.1f} µm)"
    )
    ax.axis("off")
    fig.tight_layout()
    fig.savefig(dst, dpi=120, bbox_inches="tight")
    import matplotlib.pyplot as _plt2
    _plt2.close(fig)


def save_image_qc_png(
    cell_ch: np.ndarray,
    labeled: np.ndarray,
    regions: dict,
    pattern_mask: np.ndarray,
    title: str,
    dst: Path,
) -> None:
    """Per-image overview: original + segmented cells + aligned regions."""
    import matplotlib.pyplot as plt
    from skimage.segmentation import find_boundaries

    fig, axes = plt.subplots(1, 3, figsize=(18, 6))

    cell_disp = _stretch(cell_ch)
    axes[0].imshow(cell_disp, cmap="gray")
    axes[0].contour(pattern_mask, levels=[0.5], colors="orange", linewidths=1.0)
    axes[0].set_title(f"{title} — cell channel + pattern mask")
    axes[0].axis("off")

    overlay = np.stack([cell_disp] * 3, axis=-1)
    boundaries = find_boundaries(labeled, mode="outer")
    overlay[boundaries] = [1, 0, 0]
    axes[1].imshow(overlay)
    axes[1].set_title("Cell segmentation (red contours)")
    axes[1].axis("off")

    axes[2].imshow(np.zeros_like(cell_ch), cmap="gray")
    axes[2].contour(regions["head"], levels=[0.5], colors="red", linewidths=1.0)
    axes[2].contour(regions["stem"], levels=[0.5], colors="lime", linewidths=1.0)
    tip_pt = regions["stem_tip_point"]
    axes[2].plot(tip_pt[1], tip_pt[0], "y*", ms=10, label="stem tip")
    axes[2].contour(labeled > 0, levels=[0.5], colors="cyan", linewidths=1.0)
    axes[2].set_title("Aligned regions (red=head, green=stem, yellow*=stem tip, cyan=cells)")
    axes[2].axis("off")

    fig.tight_layout()
    fig.savefig(dst, dpi=100, bbox_inches="tight")
    import matplotlib.pyplot as _plt2
    _plt2.close(fig)
