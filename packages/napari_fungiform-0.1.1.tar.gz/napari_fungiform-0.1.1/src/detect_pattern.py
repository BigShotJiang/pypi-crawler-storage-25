"""
Detect and outline a mushroom-shaped micropattern in a noisy uint8/uint16 image
using NCC-based template matching with rotation search.

Usage:
    python detect_pattern.py --image <path> [--template perfect_template.tiff]
                             [--output-dir .] [--coarse-step 1.0] [--fine-step 0.1]
"""

import argparse
import numpy as np
import tifffile
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from pathlib import Path
from scipy.ndimage import rotate as nd_rotate, binary_fill_holes
from skimage.feature import match_template
from skimage.morphology import binary_dilation, disk


# ── helpers ──────────────────────────────────────────────────────────────────

def load_as_2d_float(path: str) -> np.ndarray:
    """Load image (any dtype, any Z depth) as MIP-projected float32 in [0,1]."""
    img = tifffile.imread(path)
    if img.ndim == 3:
        img = img.max(axis=0)          # MIP along Z
    img = img.astype(np.float32)
    lo, hi = np.percentile(img, 1), np.percentile(img, 99)
    img = np.clip((img - lo) / (hi - lo + 1e-8), 0, 1)
    return img


def crop_to_bbox(binary: np.ndarray):
    """Return (cropped_array, (rmin, rmax, cmin, cmax))."""
    rows = np.any(binary, axis=1)
    cols = np.any(binary, axis=0)
    rmin, rmax = np.where(rows)[0][[0, -1]]
    cmin, cmax = np.where(cols)[0][[0, -1]]
    return binary[rmin:rmax+1, cmin:cmax+1].astype(np.float32), (rmin, rmax, cmin, cmax)


def rotate_template(template_f32: np.ndarray, angle_deg: float) -> np.ndarray:
    """Rotate a float32 template; keep float32, no reshape."""
    return nd_rotate(template_f32, angle_deg, reshape=False,
                     order=1, mode="constant", cval=0.0)


def make_location_prior(shape: tuple, sigma_fraction: float = 0.3) -> np.ndarray:
    """
    2-D Gaussian centred at the image centre.
    sigma = sigma_fraction * min(H, W), so the weight decays smoothly
    toward the corners without hard-clipping any region.
    """
    H, W = shape
    sigma = sigma_fraction * min(H, W)
    cy, cx = H / 2.0, W / 2.0
    y = np.arange(H, dtype=np.float32)
    x = np.arange(W, dtype=np.float32)
    yy, xx = np.meshgrid(y, x, indexing="ij")
    prior = np.exp(-((yy - cy) ** 2 + (xx - cx) ** 2) / (2 * sigma ** 2))
    return prior                          # in (0, 1], peak = 1 at centre


def ncc_peak(target: np.ndarray, tmpl: np.ndarray,
             location_prior: np.ndarray | None = None):
    """
    Run NCC via match_template (FFT-based).
    If location_prior is given, the NCC map is multiplied element-wise by it
    before the peak is selected — preferring detections near the image centre.
    Returns (score, peak_row, peak_col) where (peak_row, peak_col)
    is the location of the CENTRE of the template in target coordinates.
    """
    result = match_template(target, tmpl, pad_input=True)
    if location_prior is not None:
        result = result * location_prior
    idx = np.unravel_index(np.argmax(result), result.shape)
    return float(result[idx]), int(idx[0]), int(idx[1])


def place_mask(rotated_binary: np.ndarray, canvas_shape: tuple,
               centre_r: int, centre_c: int) -> np.ndarray:
    """Place a rotated binary template centred at (centre_r, centre_c) on a canvas."""
    H, W = canvas_shape
    h, w = rotated_binary.shape
    canvas = np.zeros((H, W), dtype=bool)

    r0 = centre_r - h // 2
    c0 = centre_c - w // 2
    # Source and destination slice accounting for canvas boundaries
    rs, re = max(0, r0), min(H, r0 + h)
    cs, ce = max(0, c0), min(W, c0 + w)
    ts_r = rs - r0
    ts_c = cs - c0
    canvas[rs:re, cs:ce] = rotated_binary[ts_r:ts_r+(re-rs), ts_c:ts_c+(ce-cs)] > 0.5
    return canvas


# ── alignment ────────────────────────────────────────────────────────────────

def align_with_ncc(
    target_image: np.ndarray,
    template: np.ndarray,
    coarse_step: float = 1.0,
    fine_step: float = 0.1,
    prior_sigma: float = 0.3,
    angle_range: tuple[float, float] = (0.0, 360.0),
) -> dict:
    """Align a binary template to a target image via NCC + rotation sweep.

    Returns a transform record:
        {
            "theta_deg":  best rotation angle (degrees),
            "c_ref":      (row, col) bbox center of the foreground in the
                          template's canonical canvas — used as rotation pivot
                          when warping head/stem templates,
            "c_det":      (best_r, best_c) — peak location in target coords,
            "score":      NCC peak value (float),
            "coarse_angles": np.ndarray of coarse sweep angles (for diagnostics),
            "coarse_scores": np.ndarray of coarse sweep scores (for diagnostics),
        }

    Transform: p_target = R(theta_deg) @ (p_template - c_ref) + c_det
    """
    target = target_image.astype(np.float32)
    if target.max() > 1.0 or target.min() < 0.0:
        lo, hi = np.percentile(target, [1, 99])
        target = np.clip((target - lo) / (hi - lo + 1e-8), 0, 1)

    tmpl_bin = (template > 0).astype(np.float32)
    tmpl_crop, (rmin, rmax, cmin, cmax) = crop_to_bbox(tmpl_bin)

    c_ref = np.array([(rmin + rmax) / 2.0, (cmin + cmax) / 2.0])

    H, W = target.shape
    prior = (
        make_location_prior((H, W), sigma_fraction=prior_sigma)
        if prior_sigma > 0 else None
    )

    a0, a1 = angle_range
    coarse_angles = np.arange(a0, a1, coarse_step)
    coarse_scores = np.empty(len(coarse_angles), dtype=np.float64)

    best_score, best_angle, best_r, best_c = -np.inf, 0.0, 0, 0
    for i, ang in enumerate(coarse_angles):
        rot = rotate_template(tmpl_crop, ang)
        score, pr, pc = ncc_peak(target, rot, prior)
        coarse_scores[i] = score
        if score > best_score:
            best_score, best_angle, best_r, best_c = score, ang, pr, pc

    half = max(fine_step * 2, 2.0)
    fine_angles = np.arange(
        best_angle - half, best_angle + half + fine_step, fine_step,
    )
    for ang in fine_angles:
        rot = rotate_template(tmpl_crop, ang)
        score, pr, pc = ncc_peak(target, rot, prior)
        if score > best_score:
            best_score, best_angle, best_r, best_c = score, ang, pr, pc

    return {
        "theta_deg": float(best_angle),
        "c_ref": c_ref,
        "c_det": np.array([float(best_r), float(best_c)]),
        "score": float(best_score),
        "coarse_angles": coarse_angles,
        "coarse_scores": coarse_scores,
    }


# ── main ─────────────────────────────────────────────────────────────────────

def detect(image_path: str, template_path: str,
           coarse_step: float = 1.0, fine_step: float = 0.1,
           output_dir: str = ".", prior_sigma: float = 0.3):

    out = Path(output_dir)
    stem = Path(image_path).stem

    print("Loading image …")
    target = load_as_2d_float(image_path)
    H, W = target.shape

    print("Loading template …")
    tmpl_raw = tifffile.imread(template_path)
    tmpl_bin = (tmpl_raw > 127).astype(np.float32)

    print(f"  Target : {H}×{W}")
    print(f"  Location prior: Gaussian sigma={prior_sigma:.2f} × min(H,W) = "
          f"{prior_sigma * min(H, W):.0f} px")

    rec = align_with_ncc(
        target, tmpl_bin,
        coarse_step=coarse_step, fine_step=fine_step,
        prior_sigma=prior_sigma,
    )
    best_angle = rec["theta_deg"]
    best_r, best_c = int(rec["c_det"][0]), int(rec["c_det"][1])
    best_score = rec["score"]
    coarse_angles = rec["coarse_angles"]
    coarse_scores = rec["coarse_scores"]

    print(f"  Best fit:    angle={best_angle:.2f}°  score={best_score:.4f}  "
          f"centre=({best_r},{best_c})")

    # --- Reconstruct fitted mask ---
    # Rotate full-resolution template (not just cropped) so the mask fits exactly
    full_rot = nd_rotate(tmpl_bin, best_angle, reshape=False,
                         order=1, mode="constant", cval=0.0)
    fitted_mask = place_mask(full_rot, (H, W), best_r, best_c)
    fitted_mask = binary_fill_holes(fitted_mask)

    # --- Outline (1-px dilation XOR mask) ---
    outline = binary_dilation(fitted_mask, disk(2)) & ~fitted_mask

    # --- Save fitted mask ---
    mask_path = out / f"{stem}_fitted_mask.tiff"
    tifffile.imwrite(str(mask_path), fitted_mask.astype(np.uint8) * 255)
    print(f"Saved mask → {mask_path}")

    # --- QC figure ---
    fig, axes = plt.subplots(1, 3, figsize=(18, 6))

    # Panel 1: target MIP (stretched)
    axes[0].imshow(target, cmap="gray")
    axes[0].set_title("Target MIP (percentile-stretched)")
    axes[0].axis("off")

    # Panel 2: fitted mask
    axes[1].imshow(fitted_mask, cmap="gray")
    axes[1].set_title(f"Fitted mask  angle={best_angle:.2f}°")
    axes[1].axis("off")

    # Panel 3: overlay — image + coloured outline
    overlay = np.stack([target, target, target], axis=-1)
    overlay[outline] = [1.0, 0.0, 0.0]   # red outline
    axes[2].imshow(overlay)
    axes[2].set_title("Overlay (red = detected outline)")
    axes[2].axis("off")

    # Coarse score curve as inset
    ax_inset = axes[2].inset_axes([0.0, -0.28, 1.0, 0.22])
    ax_inset.plot(coarse_angles, coarse_scores, lw=0.8)
    ax_inset.axvline(best_angle % 360, color="r", lw=1.5, label=f"{best_angle:.1f}°")
    ax_inset.set_xlabel("Rotation angle (°)", fontsize=8)
    ax_inset.set_ylabel("NCC score", fontsize=8)
    ax_inset.legend(fontsize=7)
    ax_inset.tick_params(labelsize=7)

    plt.tight_layout()
    qc_path = out / f"{stem}_detection_qc.png"
    plt.savefig(str(qc_path), dpi=100, bbox_inches="tight")
    print(f"Saved QC  → {qc_path}")

    return best_angle, best_r, best_c, best_score


# ── CLI ───────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Detect mushroom pattern via NCC rotation search")
    parser.add_argument("--image",    required=True,  help="Path to noisy target image (TIFF, 2D or 3D)")
    parser.add_argument("--template", default="perfect_template.tiff", help="Binary template TIFF")
    parser.add_argument("--output-dir", default=".", help="Where to write outputs")
    parser.add_argument("--coarse-step", type=float, default=1.0, help="Coarse sweep step in degrees")
    parser.add_argument("--fine-step",   type=float, default=0.1,  help="Fine sweep step in degrees")
    parser.add_argument("--prior-sigma", type=float, default=0.3,
                        help="Gaussian location prior sigma as fraction of min(H,W). "
                             "Larger = weaker prior. 0 = disable prior.")
    args = parser.parse_args()

    detect(args.image, args.template, args.coarse_step, args.fine_step,
           args.output_dir, args.prior_sigma)
