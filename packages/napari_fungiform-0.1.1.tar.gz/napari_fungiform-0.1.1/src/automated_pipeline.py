#!/usr/bin/env python3
"""
Automated microscopy analysis pipeline.

Replaces the manual ImageJ workflow:
  RotatingScript  ->  AlignmentScript  ->  Mushroom_Pattern_Analysis_WholeCell

Processes 4-channel confocal TIFFs:
  C1 = CellBorder  (segmentation)
  C2 = Protein      (intensity measurement)
  C3 = Nucleus
  C4 = Pattern      (alignment reference)

Usage (with NCC auto-alignment):
  python automated_pipeline.py \\
      --dir ./data/Merged_ZStacks \\
      --pattern-template ./perfect_template.tiff \\
      --head-template ./head_template.tiff \\
      --stem-template ./stem_template.tiff

Usage (analysis only, no alignment):
  python automated_pipeline.py --dir ./data/Merged_ZStacks --no-align

Dependencies:
  pip install numpy tifffile scikit-image scipy matplotlib
"""

import argparse
import csv
import fnmatch
import re
import sys
import time
from contextlib import contextmanager
from pathlib import Path

import numpy as np
import tifffile

# -- Settings matching WholeCell ImageJ macro ---------------------------------
GAUSSIAN_SIGMA = 3          # Gaussian blur sigma (pixels)
CONTRAST_SAT = 1.5          # Enhance Contrast saturation (%)
MIN_CELL_SIZE_UM2 = 100     # Minimum cell area (um^2)
MAX_CIRCULARITY = 0.95      # Exclude near-perfect circles
CLAHE_KERNEL = 127          # CLAHE block size
CLAHE_BINS = 256            # CLAHE histogram bins
CLAHE_CLIP = 3.0            # CLAHE maximum slope

CSV_COLUMNS = [
    # Existing shape + intensity (unchanged)
    "Label", "Area", "Perimeter", "Circularity", "Solidity",
    "Feret", "MinFeret", "AR", "Roundness",
    "CentroidX", "CentroidY", "ProtrusionIndex",
    "Protein_Mean", "Protein_IntDen", "Protein_RawIntDen",
    # New: region-based protein
    "Protein_Whole_Mean",
    "Protein_Head_Mean", "Protein_Head_IntDen", "Protein_Head_Fraction",
    "Protein_Stem_Mean", "Protein_Stem_IntDen", "Protein_Stem_Fraction",
    "Protein_StemTip_Mean", "Protein_StemTip_IntDen", "Protein_StemTip_Fraction",
    # New: extension
    "CellLength_um", "StemTipToCellTop_um",
    "StemExtension_um", "ProteinExtension_um",
    # New: protrusions
    "Protrusion_Count", "Protrusion_TotalLength_um",
    "Protrusion_MaxLength_um", "Protrusion_MeanLength_um",
    "Protrusion_MeanAngleDeg",
    # New: nucleus
    "Nuclear_Area_um2", "Protein_Nuclear_Mean",
    "Protein_Cytoplasmic_Mean", "Protein_NucCyt_Ratio",
]


# -- I/O helpers --------------------------------------------------------------

def read_pixel_size(path: Path) -> float:
    """Read pixel size in um/pixel from TIFF metadata. Returns 1.0 if unavailable."""
    with tifffile.TiffFile(path) as tf:
        page = tf.pages[0]
        xres_tag = page.tags.get("XResolution")
        ij = tf.imagej_metadata or {}
        if xres_tag and ij.get("unit") == "micron":
            num, den = xres_tag.value
            if num > 0:
                return den / num
    return 1.0


def load_and_max_project(path: Path) -> tuple[np.ndarray, float]:
    """Load multi-channel TIFF and max-project along Z.

    Returns:
        projected: (C, Y, X) uint16 array
        pixel_size: um per pixel (1.0 if uncalibrated)
    """
    stack = tifffile.imread(path)
    pixel_size = read_pixel_size(path)

    if stack.ndim == 4:
        # (Z, C, Y, X) when shape[0] > shape[1], else (C, Z, Y, X)
        if stack.shape[0] > stack.shape[1]:
            projected = stack.max(axis=0)
        else:
            projected = stack.max(axis=1)
    elif stack.ndim == 3:
        projected = stack
    elif stack.ndim == 2:
        projected = stack[np.newaxis]
    else:
        raise ValueError(f"Unexpected shape {stack.shape}")

    return projected.astype(np.uint16), pixel_size


def _max_project_single(stack: np.ndarray) -> np.ndarray:
    """Max-project a single-channel stack to 2D. Handles (Z,H,W) or (H,W)."""
    if stack.ndim == 3:
        return stack.max(axis=0)
    return stack


def find_split_channel_groups(in_dir: Path) -> list[tuple[str, dict[int, Path]]]:
    """Find groups of split-channel TIFFs (*_C0.tif + _C1 + _C2 + _C3).

    Scans both:
        - ``in_dir/*_C[0-3].tif``        (legacy flat layout)
        - ``in_dir/*/*_C[0-3].tif``      (per-image subfolder layout)

    Returns list of (base_name, {0: c0_path, 1: c1_path, 2: c2_path, 3: c3_path})
    sorted by base_name. Groups missing any channel are silently skipped.
    """
    groups: dict[str, dict[int, Path]] = {}
    pat = re.compile(r"^(.+)_C(\d+)$")
    candidates = sorted(
        list(in_dir.glob("*_C[0-3].tif"))
        + list(in_dir.glob("*/*_C[0-3].tif"))
    )
    for p in candidates:
        m = pat.match(p.stem)
        if not m:
            continue
        base, ch = m.group(1), int(m.group(2))
        groups.setdefault(base, {})[ch] = p

    return [
        (base, chs)
        for base, chs in sorted(groups.items())
        if len(chs) == 4
    ]


def load_split_channel_group(
    channel_paths: dict[int, Path],
) -> tuple[np.ndarray, float]:
    """Load four single-channel TIFFs and merge into a (4, H, W) array.

    Each file may be a single-plane (H, W) or Z-stack (Z, H, W); Z-stacks
    are max-projected. Pixel size is read from channel 0.

    Returns:
        projected: (4, H, W) uint16 array  (C0=index 0 … C3=index 3)
        pixel_size: um per pixel
    """
    channels = []
    for ch_idx in range(4):
        raw = tifffile.imread(channel_paths[ch_idx])
        channels.append(_max_project_single(raw))

    pixel_size = read_pixel_size(channel_paths[0])
    projected = np.stack(channels, axis=0).astype(np.uint16)
    return projected, pixel_size


# -- Preprocessing (replicating WholeCell macro) ------------------------------

def enhance_contrast_normalize(img: np.ndarray, saturation: float = CONTRAST_SAT) -> np.ndarray:
    """Replicate ImageJ 'Enhance Contrast' with saturated=X and normalize.

    Clips the bottom and top (saturation/2)% of pixel intensities,
    then stretches to the full uint16 range [0, 65535].
    """
    lo = np.percentile(img, saturation / 2)
    hi = np.percentile(img, 100 - saturation / 2)
    if hi <= lo:
        return img.copy()
    stretched = (img.astype(np.float64) - lo) / (hi - lo)
    return (np.clip(stretched, 0, 1) * 65535).astype(np.uint16)


def apply_clahe(img: np.ndarray) -> np.ndarray:
    """Apply CLAHE matching ImageJ CLAHE plugin settings.

    Note: skimage's clip_limit scale differs from ImageJ's "maximum slope".
    Empirically, clip_limit=0.01 (skimage default) best matches ImageJ's
    slope=3.0 for these 16-bit confocal images.
    """
    from skimage.exposure import equalize_adapthist

    img_f = img.astype(np.float64) / max(img.max(), 1)
    result = equalize_adapthist(
        img_f, kernel_size=CLAHE_KERNEL, nbins=CLAHE_BINS, clip_limit=0.01,
    )
    return (result * 65535).astype(np.uint16)


# -- Cell segmentation --------------------------------------------------------

def segment_cells(cell_ch: np.ndarray, pixel_size: float = 1.0) -> tuple[np.ndarray, list]:
    """Segment cells from CellBorder channel, replicating WholeCell macro.

    Pipeline: Enhance Contrast -> CLAHE -> Gaussian blur -> Otsu -> Fill holes ->
              Erode -> Label -> Filter (size, circularity, edge exclusion).

    Args:
        cell_ch:    2-D uint16 CellBorder image (max Z-projection).
        pixel_size: um per pixel (for calibrated size filtering).

    Returns:
        labeled:  2-D int32 label image (0 = background).
        regions:  list of skimage RegionProperties passing all filters.
    """
    from scipy.ndimage import binary_fill_holes, binary_erosion
    from skimage.filters import gaussian, threshold_otsu
    from skimage.measure import label, regionprops

    # 1. Enhance contrast (saturated=1.5, normalize)
    seg = enhance_contrast_normalize(cell_ch)

    # 2. CLAHE
    seg = apply_clahe(seg)

    # 3. Gaussian blur
    seg = gaussian(seg, sigma=GAUSSIAN_SIGMA, preserve_range=True).astype(np.uint16)

    # 4. Otsu threshold (dark background)
    thresh = threshold_otsu(seg)
    binary = seg > thresh

    # 5. Fill holes
    binary = binary_fill_holes(binary)

    # 6. Erode (one iteration, 3x3 structuring element -- ImageJ default)
    binary = binary_erosion(binary, structure=np.ones((3, 3)))

    # 7. Label connected components
    labeled = label(binary.astype(np.uint8))
    regions = regionprops(labeled)

    H, W = cell_ch.shape
    px2 = pixel_size ** 2  # pixel area in um^2

    # 8. Filter by calibrated size, circularity, and edge exclusion
    #    ImageJ's size=100 is in calibrated um^2 when image has spatial calibration
    def passes_filter(r):
        if r.area * px2 < MIN_CELL_SIZE_UM2:
            return False
        circ = 4 * np.pi * r.area / (r.perimeter ** 2) if r.perimeter > 0 else 0
        if circ > MAX_CIRCULARITY:
            return False
        # Exclude particles touching the edge
        coords = r.coords
        if (coords[:, 0].min() == 0 or coords[:, 0].max() == H - 1 or
                coords[:, 1].min() == 0 or coords[:, 1].max() == W - 1):
            return False
        return True

    filtered = [r for r in regions if passes_filter(r)]

    # Re-label to keep only passing regions
    keep_labels = {r.label for r in filtered}
    clean = np.where(np.isin(labeled, list(keep_labels)), labeled, 0)

    return clean, filtered


# -- Measurement helpers ------------------------------------------------------

def compute_feret_diameters(coords: np.ndarray) -> tuple[float, float]:
    """Compute Feret (max caliper) and MinFeret (min caliper) from 2-D coords.

    Uses convex hull vertices and rotating-calipers for MinFeret.
    """
    from scipy.spatial import ConvexHull

    if len(coords) < 3:
        ptp = coords.ptp(axis=0).astype(float)
        diag = np.sqrt(np.sum(ptp ** 2))
        return diag, float(min(ptp)) if ptp.min() > 0 else diag

    try:
        hull = ConvexHull(coords.astype(np.float64))
    except Exception:
        ptp = coords.ptp(axis=0).astype(float)
        return np.sqrt(np.sum(ptp ** 2)), float(min(ptp))

    pts = coords[hull.vertices].astype(np.float64)
    n = len(pts)

    # Feret = max distance between any two hull vertices
    max_dist = 0.0
    for i in range(n):
        diffs = pts[i + 1:] - pts[i]
        dists = np.sqrt(np.sum(diffs ** 2, axis=1))
        if len(dists) > 0:
            max_dist = max(max_dist, float(dists.max()))

    # MinFeret = minimum caliper width across all edge directions
    min_width = np.inf
    for i in range(n):
        edge = pts[(i + 1) % n] - pts[i]
        edge_len = np.linalg.norm(edge)
        if edge_len == 0:
            continue
        normal = np.array([-edge[1], edge[0]]) / edge_len
        projections = pts @ normal
        width = float(projections.max() - projections.min())
        min_width = min(min_width, width)

    if min_width == np.inf:
        min_width = max_dist

    return max_dist, min_width


def measure_cells(
    cell_ch: np.ndarray,
    protein_ch: np.ndarray,
    regions: list,
    pixel_size: float,
    title: str,
    nucleus_ch: np.ndarray | None = None,
    aligned_regions: dict | None = None,
    perfect_warped: np.ndarray | None = None,
    cell_label_image: np.ndarray | None = None,
    protrusion_min_area_px: int = 5,
    protrusion_min_length_um: float = 0.8,
    ball_radius_fraction: float = 0.25,
    ball_radius_px: int | None = None,
) -> tuple[list[dict], list[dict]]:
    """Returns (csv_rows, qc_records).

    qc_records is a parallel list (same length as csv_rows) holding the
    *_protrusions, _per_protrusion, _nuc_mask keys for visualization use;
    these are stripped before CSV writing.
    """
    from quantification import quantify_cell

    rows: list[dict] = []
    qc_records: list[dict] = []
    for idx, region in enumerate(regions, start=1):
        # -- Existing shape + protein measurement (unchanged) ----------------
        area_px = region.area
        area = area_px * pixel_size ** 2
        perimeter_px = region.perimeter
        perimeter = perimeter_px * pixel_size
        circularity = (4 * np.pi * area / perimeter ** 2) if perimeter > 0 else 0
        solidity = region.solidity
        feret_px, minferet_px = compute_feret_diameters(region.coords)
        feret = feret_px * pixel_size
        minferet = minferet_px * pixel_size
        ar = feret / minferet if minferet > 0 else 0
        roundness = (4 * area / (np.pi * feret ** 2)) if feret > 0 else 0
        cy_px, cx_px = region.centroid
        centroid_x = cx_px * pixel_size
        centroid_y = cy_px * pixel_size
        protrusion_idx = (perimeter ** 2 / (4 * np.pi * area)) if area > 0 else 0

        bbox = region.bbox
        roi_mask = region.image
        protein_roi = protein_ch[bbox[0]:bbox[2], bbox[1]:bbox[3]]
        protein_values = protein_roi[roi_mask].astype(np.float64)
        protein_mean = float(protein_values.mean()) if len(protein_values) > 0 else 0.0
        protein_intden = protein_mean * area
        protein_rawintden = float(protein_values.sum())

        row = {
            "Label": f"MAX_{title}_Cell_{idx}",
            "Area": round(area, 3),
            "Perimeter": round(perimeter, 3),
            "Circularity": round(circularity, 3),
            "Solidity": round(solidity, 3),
            "Feret": round(feret, 3),
            "MinFeret": round(minferet, 3),
            "AR": round(ar, 3),
            "Roundness": round(roundness, 3),
            "CentroidX": round(centroid_x, 3),
            "CentroidY": round(centroid_y, 3),
            "ProtrusionIndex": round(protrusion_idx, 3),
            "Protein_Mean": round(protein_mean, 3),
            "Protein_IntDen": round(protein_intden, 3),
            "Protein_RawIntDen": round(protein_rawintden, 3),
        }

        # -- NEW: cross-channel quantification --------------------------------
        if (aligned_regions is not None and perfect_warped is not None
                and nucleus_ch is not None):
            # Reconstruct full-image cell mask for this region
            full_cell_mask = np.zeros(cell_ch.shape, dtype=bool)
            full_cell_mask[bbox[0]:bbox[2], bbox[1]:bbox[3]][roi_mask] = True

            metrics = quantify_cell(
                cell_mask=full_cell_mask,
                regions=aligned_regions,
                protein_ch=protein_ch,
                nucleus_ch=nucleus_ch,
                pixel_size=pixel_size,
                protrusion_min_area_px=protrusion_min_area_px,
                protrusion_min_length_um=protrusion_min_length_um,
                ball_radius_fraction=ball_radius_fraction,
                ball_radius_px=ball_radius_px,
            )
            # Drop private keys for CSV; preserve them in qc_records
            qc_record = {k: v for k, v in metrics.items() if k.startswith("_")}
            qc_record["_full_cell_mask"] = full_cell_mask
            qc_record["_label"] = row["Label"]

            for k, v in metrics.items():
                if not k.startswith("_"):
                    row[k] = v
        else:
            # Alignment unavailable -- fill new columns with zero placeholders
            qc_record = {}
            for col in [c for c in CSV_COLUMNS if c not in row]:
                row[col] = 0.0
            row["Protrusion_Count"] = 0  # int

        rows.append(row)
        qc_records.append(qc_record)

    return rows, qc_records


# -- Visualization ------------------------------------------------------------

def save_cell_mask_jpg(labeled: np.ndarray, dst: Path) -> None:
    """Save binary cell mask as JPEG (white cells on black background)."""
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(6, 6))
    ax.imshow(labeled > 0, cmap="gray")
    ax.axis("off")
    fig.tight_layout(pad=0)
    fig.savefig(dst, dpi=150, bbox_inches="tight", pil_kwargs={"quality": 90})
    plt.close(fig)


def save_overlay_jpg(cell_ch: np.ndarray, labeled: np.ndarray, dst: Path) -> None:
    """Save CellBorder image with cell contour overlay as JPEG."""
    import matplotlib.pyplot as plt
    from skimage.segmentation import find_boundaries

    # Stretch for display
    lo, hi = np.percentile(cell_ch, [1, 99])
    disp = np.clip((cell_ch.astype(np.float32) - lo) / max(hi - lo, 1e-6), 0, 1)

    # Create RGB with red contours
    rgb = np.stack([disp, disp, disp], axis=-1)
    boundaries = find_boundaries(labeled, mode="outer")
    rgb[boundaries] = [1, 0, 0]

    fig, ax = plt.subplots(figsize=(6, 6))
    ax.imshow(rgb)
    ax.axis("off")
    fig.tight_layout(pad=0)
    fig.savefig(dst, dpi=150, bbox_inches="tight", pil_kwargs={"quality": 90})
    plt.close(fig)


# -- Progress helpers ---------------------------------------------------------

@contextmanager
def _step(label: str, width: int = 12):
    """Print a labelled step with elapsed time on completion."""
    print(f"    {label:<{width}}", end="", flush=True)
    t0 = time.perf_counter()
    yield
    print(f"  {time.perf_counter() - t0:.1f}s", end="")


def _eta_str(elapsed: float, done: int, total: int) -> str:
    """Return a human-readable ETA string, or empty string if not enough data."""
    if done == 0:
        return ""
    remaining = elapsed / done * (total - done)
    if remaining < 60:
        return f"ETA ~{remaining:.0f}s"
    return f"ETA ~{remaining / 60:.1f} min"


# -- Per-file processing ------------------------------------------------------

def process_one(
    src: Path,
    out_dir: Path,
    args,
    pattern_template: np.ndarray | None = None,
    head_template: np.ndarray | None = None,
    stem_template: np.ndarray | None = None,
    projected: np.ndarray | None = None,
    title: str | None = None,
    pixel_size: float | None = None,
) -> list[dict]:
    """Process one multi-channel TIFF: align -> segment -> measure.

    If ``projected`` (C,H,W) is supplied, the file at ``src`` is not read.
    ``title`` overrides the stem of ``src`` as the image name. ``pixel_size``
    skips a TIFF re-open when caller already has it.

    Returns list of measurement dicts (one per cell).
    """
    # -- Load -----------------------------------------------------------------
    with _step("load"):
        if projected is None:
            projected, pixel_size = load_and_max_project(src)
        elif pixel_size is None:
            pixel_size = read_pixel_size(src)
        if title is None:
            title = src.stem
    print(f"  shape={projected.shape}  pixel_size={pixel_size:.4f} um/px")

    # -- Channel extraction (1-indexed flags → 0-indexed array) ---------------
    ch_cell    = args.channel_cell    - 1
    ch_protein = args.channel_protein - 1
    ch_nucleus = args.channel_nucleus - 1
    ch_pattern = args.channel_pattern - 1

    align_record: dict | None = None
    if args.align and pattern_template is not None:
        from detect_pattern import align_with_ncc

        with _step("align"):
            pattern_ch = projected[ch_pattern].astype(np.float32)
            lo, hi = np.percentile(pattern_ch, [1, 99])
            pattern_ch_norm = np.clip(
                (pattern_ch - lo) / max(hi - lo, 1e-6), 0, 1
            )
            align_record = align_with_ncc(
                target_image=pattern_ch_norm,
                template=pattern_template,
                coarse_step=args.coarse_step,
                fine_step=args.fine_step,
                prior_sigma=args.prior_sigma,
                angle_range=(args.angle_min, args.angle_max),
            )
        print(f"  theta={align_record['theta_deg']:+.2f}deg  "
              f"NCC={align_record['score']:.3f}  "
              f"centre=({int(align_record['c_det'][0])}, "
              f"{int(align_record['c_det'][1])})")

    # -- Channel extraction ---------------------------------------------------
    cell_ch    = projected[ch_cell]
    protein_ch = projected[ch_protein]
    nucleus_ch = projected[ch_nucleus]

    # -- Cell segmentation ----------------------------------------------------
    with _step("segment"):
        labeled, regions = segment_cells(cell_ch, pixel_size)
    n_cells = len(regions)
    if n_cells == 0:
        print(f"  WARNING: no cells detected -- skipping")
        return []
    print(f"  {n_cells} cell(s) detected")

    # -- Build aligned regions ------------------------------------------------
    aligned_regions: dict | None = None
    perfect_warped: np.ndarray | None = None
    if align_record is not None and head_template is not None and stem_template is not None:
        with _step("warp regions"):
            from quantification import (
                build_aligned_regions, compute_protein_extension,
                warp_template_to_image,
            )
            aligned_regions = build_aligned_regions(
                head_template=head_template,
                stem_template=stem_template,
                theta_deg=align_record["theta_deg"],
                c_ref=align_record["c_ref"],
                c_det=align_record["c_det"],
                output_shape=cell_ch.shape,
                stem_tip_fraction=args.stem_tip_fraction,
            )
            perfect_warped = warp_template_to_image(
                pattern_template,
                theta_deg=align_record["theta_deg"],
                c_ref=align_record["c_ref"],
                c_det=align_record["c_det"],
                output_shape=cell_ch.shape,
            )
            # Precompute image-level work that's identical across all cells
            # in this image: dilated head mask, protein threshold, and the
            # protein-extension measurement.
            from scipy.ndimage import binary_dilation
            from skimage.filters import threshold_otsu
            aligned_regions["_near_head"] = binary_dilation(
                aligned_regions["head"], iterations=30,
            )
            try:
                protein_threshold = float(threshold_otsu(protein_ch))
            except ValueError:
                protein_threshold = float(protein_ch.mean())
            aligned_regions["_protein_threshold"] = protein_threshold
            aligned_regions["_protein_extension_um"] = compute_protein_extension(
                protein_ch=protein_ch,
                signal_threshold=protein_threshold,
                stem_tip_point=aligned_regions["stem_tip_point"],
                stem_axis=aligned_regions["stem_axis"],
                pixel_size=pixel_size,
            )
        print()

    # -- Measurements ---------------------------------------------------------
    with _step("measure"):
        rows, qc_records = measure_cells(
            cell_ch, protein_ch, regions, pixel_size, title,
            nucleus_ch=nucleus_ch,
            aligned_regions=aligned_regions,
            perfect_warped=perfect_warped,
            cell_label_image=labeled,
            protrusion_min_area_px=args.protrusion_min_area_px,
            protrusion_min_length_um=args.protrusion_min_length_um,
            ball_radius_fraction=getattr(args, "ball_radius_fraction", 0.25),
            ball_radius_px=getattr(args, "ball_radius_px", None),
        )
    print(f"  {len(rows)} row(s)")
    for row in rows:
        print(f"      {row['Label']}  Area={row['Area']:.1f}  "
              f"Circ={row['Circularity']:.3f}  ProtMean={row['Protein_Mean']:.1f}")

    # -- Visualizations -------------------------------------------------------
    with _step("save viz"):
        save_cell_mask_jpg(labeled, out_dir / f"MAX_{title}_Cell_mask.jpg")
        save_overlay_jpg(cell_ch, labeled, out_dir / f"MAX_{title}_mask_overlay.jpg")

        if args.save_cell_qc and aligned_regions is not None:
            from qc_viz import (
                save_cell_qc_png, save_cell_protrusion_png, save_image_qc_png,
            )
            qc_dir = out_dir / "qc_cells"
            qc_dir.mkdir(parents=True, exist_ok=True)
            prot_dir = out_dir / "protrusions"
            prot_dir.mkdir(parents=True, exist_ok=True)
            for row, qc in zip(rows, qc_records):
                if not qc:
                    continue
                merged = {**row, **{k: v for k, v in qc.items()
                                    if k.startswith("_")}}
                save_cell_qc_png(
                    cell_mask=qc["_full_cell_mask"],
                    cell_id=row["Label"],
                    regions=aligned_regions,
                    protein_ch=protein_ch,
                    nucleus_ch=nucleus_ch,
                    metrics=merged,
                    dst=qc_dir / f"{row['Label']}_qc.png",
                )
                save_cell_protrusion_png(
                    cell_mask=qc["_full_cell_mask"],
                    cell_id=row["Label"],
                    regions=aligned_regions,
                    protein_ch=protein_ch,
                    metrics=merged,
                    dst=prot_dir / f"{row['Label']}_protrusions.png",
                )
            if perfect_warped is not None:
                save_image_qc_png(
                    cell_ch=cell_ch, labeled=labeled,
                    regions=aligned_regions, pattern_mask=perfect_warped,
                    title=title, dst=out_dir / f"MAX_{title}_image_qc.png",
                )
                from qc_viz import save_protrusion_visualisations
                prot_root = out_dir / "protrusions"
                prot_root.mkdir(parents=True, exist_ok=True)
                save_protrusion_visualisations(
                    cell_channel=cell_ch,
                    cell_label_image=labeled,
                    cell_records=qc_records,
                    pixel_size=pixel_size,
                    ball_radius_fraction=getattr(args, "ball_radius_fraction", 0.25),
                    dst_protrusions=prot_root / f"MAX_{title}_protrusions.png",
                )
    print()

    return rows


# -- Main ---------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Automated microscopy analysis pipeline. "
                    "Replaces RotatingScript + AlignmentScript + WholeCell macros.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("--dir", default="./data/Merged_ZStacks",
                        help="Input directory containing multi-channel TIFF files")
    parser.add_argument("--out", default=None,
                        help="Output directory (default: <dir>/Analysis_auto/)")
    parser.add_argument("--split-channels", action="store_true", default=False,
                        help="Input files are split per-channel (*_C0.tif … *_C3.tif). "
                             "Channel files may sit directly in --dir (flat layout) "
                             "or inside per-image subfolders <dir>/<base>/<base>_C{0..3}.tif.")
    parser.add_argument("--pattern", default="*",
                        help="Glob pattern to select a subset of images "
                             "(matched against base name in split-channels mode, "
                             "or filename in merged mode)")
    parser.add_argument("--channel-cell", type=int, default=1,
                        help="CellBorder/WGA channel, 1-indexed "
                             "(default 1 for merged ZStacks; use 2 for Micropatterns_2026)")
    parser.add_argument("--channel-protein", type=int, default=2,
                        help="Protein channel, 1-indexed "
                             "(default 2 for merged ZStacks; use 3 for Micropatterns_2026)")
    parser.add_argument("--channel-nucleus", type=int, default=3,
                        help="Nucleus/DAPI channel, 1-indexed "
                             "(default 3 for merged ZStacks; use 1 for Micropatterns_2026)")
    parser.add_argument("--channel-pattern", type=int, default=4,
                        help="Pattern channel, 1-indexed (default 4 for both datasets)")

    # Alignment
    align_grp = parser.add_argument_group("alignment (NCC)")
    align_grp.add_argument("--align", action=argparse.BooleanOptionalAction,
                           default=True,
                           help="Run NCC pattern alignment before cell analysis")
    _templates = Path(__file__).resolve().parent / "fungiform" / "templates"
    align_grp.add_argument("--pattern-template",
                           default=str(_templates / "perfect_template.tiff"),
                           help="Path to perfect pattern template TIFF (used by NCC)")
    align_grp.add_argument("--coarse-step", type=float, default=1.0,
                           help="Coarse rotation sweep step (degrees)")
    align_grp.add_argument("--fine-step", type=float, default=0.1,
                           help="Fine rotation sweep step (degrees)")
    align_grp.add_argument("--prior-sigma", type=float, default=0.3,
                           help="Gaussian location prior sigma as fraction of "
                                "min(H,W); 0 disables the prior")
    align_grp.add_argument("--angle-min", type=float, default=0.0,
                           help="Minimum search angle (degrees)")
    align_grp.add_argument("--angle-max", type=float, default=360.0,
                           help="Maximum search angle (degrees, exclusive)")

    # Quantification
    qparser = parser.add_argument_group("quantification")
    qparser.add_argument("--head-template",
                         default=str(_templates / "head_template.tiff"),
                         help="Path to head sub-region template TIFF")
    qparser.add_argument("--stem-template",
                         default=str(_templates / "stem_template.tiff"),
                         help="Path to stem sub-region template TIFF")
    qparser.add_argument("--stem-tip-fraction", type=float, default=0.25,
                         help="Top fraction of stem to treat as 'stem tip'")
    qparser.add_argument("--protrusion-min-area-px", type=int, default=5,
                         help="Cheap pre-filter: skip head-region components "
                              "smaller than N pixels before skeletonising")
    qparser.add_argument("--protrusion-min-length-um", type=float, default=0.8,
                         help="Minimum skeleton length for a protrusion (um)")
    qparser.add_argument("--ball-radius-fraction", type=float, default=0.25,
                         help="Rolling-ball radius as fraction of the cell's "
                              "MIC (maximum inscribed circle) radius. "
                              "Smaller = more / smaller protrusions detected. "
                              "Matches legacy/protrusion_detection.py.")
    qparser.add_argument("--ball-radius-px", type=int, default=None,
                         help="Override rolling-ball radius (pixels). When "
                              "set, --ball-radius-fraction is ignored.")
    qparser.add_argument("--save-cell-qc", action=argparse.BooleanOptionalAction,
                         default=True,
                         help="Save per-cell QC PNG showing all new quantifications")

    # Output
    parser.add_argument("--save-intermediate", action=argparse.BooleanOptionalAction,
                        default=False,
                        help="Save alignment diagnostic PNGs")

    args = parser.parse_args()

    in_dir = Path(args.dir).resolve()
    out_dir = Path(args.out).resolve() if args.out else in_dir / "Analysis_auto"
    out_dir.mkdir(parents=True, exist_ok=True)

    # -- Build a uniform list of work items: (display_name, src_path, projected_or_None) --
    work: list[tuple[str, Path, np.ndarray | None, float | None]] = []
    if args.split_channels:
        groups = find_split_channel_groups(in_dir)
        if args.pattern != "*":
            groups = [(b, c) for b, c in groups if fnmatch.fnmatch(b, args.pattern)]
        if not groups:
            print(f"No split-channel groups matching '{args.pattern}' found in {in_dir}")
            sys.exit(0)
        print(f"Found {len(groups)} split-channel group(s) in {in_dir}"
              + (f" (pattern: {args.pattern})" if args.pattern != "*" else ""))
        # Deferred loading: actual TIFF reads happen inside the main loop so
        # the "load" timing in process_one reflects them honestly.
        for base, chs in groups:
            work.append((base, chs[0], None, None))
        split_paths_by_title = {base: chs for base, chs in groups}
    else:
        tifs = sorted(in_dir.glob("*.tif")) + sorted(in_dir.glob("*.tiff"))
        tifs = [f for f in tifs
                if "_pattern_mask" not in f.name and "_aligned" not in f.name
                and not f.stem.endswith(("_C0", "_C1", "_C2", "_C3"))]
        if args.pattern != "*":
            tifs = [f for f in tifs if fnmatch.fnmatch(f.name, args.pattern)]
        if not tifs:
            print(f"No TIFF files matching '{args.pattern}' found in {in_dir}")
            sys.exit(0)
        print(f"Found {len(tifs)} file(s) in {in_dir}"
              + (f" (pattern: {args.pattern})" if args.pattern != "*" else ""))
        for tif in tifs:
            work.append((tif.stem, tif, None, None))
        split_paths_by_title = {}

    print(f"Output: {out_dir}")
    print()

    # -- Load templates if alignment is enabled ------------------------------
    pattern_template = None
    head_template = None
    stem_template = None
    if args.align:
        for arg_name, var_name in (
            ("pattern_template", "pattern_template"),
            ("head_template", "head_template"),
            ("stem_template", "stem_template"),
        ):
            path = Path(getattr(args, arg_name)).resolve()
            if not path.exists():
                sys.exit(f"ERROR: {arg_name} not found: {path}")
        pattern_template = tifffile.imread(args.pattern_template) > 128
        head_template = tifffile.imread(args.head_template) > 128
        stem_template = tifffile.imread(args.stem_template) > 128
        if not (pattern_template.shape == head_template.shape == stem_template.shape):
            sys.exit(
                f"ERROR: template shape mismatch -- perfect "
                f"{pattern_template.shape}, head {head_template.shape}, "
                f"stem {stem_template.shape}"
            )
        print(f"Pattern template: {Path(args.pattern_template).name}  "
              f"{pattern_template.shape}")
        print(f"Head template:    {Path(args.head_template).name}")
        print(f"Stem template:    {Path(args.stem_template).name}")
        print()

    # -- Process each file / group --------------------------------------------
    all_rows: list[dict] = []
    processed_titles: set[str] = set()
    errors = []
    t0_overall = time.perf_counter()
    n_total = len(work)

    for idx, (display_title, src_path, _, _) in enumerate(work, start=1):
        t0_image = time.perf_counter()
        print(f"\n[{idx}/{n_total}] {display_title}")
        try:
            projected_data: np.ndarray | None = None
            ps: float | None = None
            if display_title in split_paths_by_title:
                projected_data, ps = load_split_channel_group(
                    split_paths_by_title[display_title]
                )
            rows = process_one(
                src_path, out_dir, args,
                pattern_template=pattern_template,
                head_template=head_template,
                stem_template=stem_template,
                projected=projected_data,
                title=display_title,
                pixel_size=ps,
            )
            all_rows.extend(rows)
            processed_titles.add(display_title)
        except Exception as e:
            import traceback
            print(f"  ERROR processing {display_title}: {e}")
            traceback.print_exc()
            errors.append((display_title, e))
            continue
        elapsed_image = time.perf_counter() - t0_image
        eta = _eta_str(time.perf_counter() - t0_overall, idx, n_total)
        print(f"    done in {elapsed_image:.1f}s"
              + (f"  |  {eta}" if eta else ""))

    total_elapsed = time.perf_counter() - t0_overall

    # -- Write CSV (merge with existing results) -------------------------------
    # Keep rows from prior runs for images not processed this time.
    csv_path = out_dir / "_allResults.csv"
    retained_rows: list[dict] = []
    if csv_path.exists() and processed_titles:
        with open(csv_path, newline="") as f:
            reader = csv.DictReader(f)
            for row in reader:
                label = row.get("Label", "")
                # Label format: MAX_{title}_Cell_{n}
                # Drop rows whose title was reprocessed this run.
                title_in_label = label.removeprefix("MAX_").rsplit("_Cell_", 1)[0]
                if title_in_label not in processed_titles:
                    # Fill any missing columns (e.g. from an older pipeline run)
                    for col in CSV_COLUMNS:
                        row.setdefault(col, "")
                    retained_rows.append(row)
        if retained_rows:
            print(f"  Retained {len(retained_rows)} rows from previous run(s)")

    with open(csv_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=CSV_COLUMNS)
        writer.writeheader()
        writer.writerows(retained_rows + all_rows)

    mins, secs = divmod(int(total_elapsed), 60)
    elapsed_str = f"{mins}m {secs}s" if mins else f"{secs}s"
    total_rows = len(retained_rows) + len(all_rows)
    print(f"\nResults: {csv_path}")
    print(f"  {len(all_rows)} new cells, {total_rows} total  |  "
          f"{n_total - len(errors)}/{n_total} images this run  |  "
          f"total {elapsed_str}")

    if errors:
        print("\nFailed:")
        for name, err in errors:
            print(f"  {name}: {err}")
        sys.exit(1)


if __name__ == "__main__":
    main()
