# Open Private Markets

## Abstract

Open Private Markets (OPM) is a public initiative to build shared, open infrastructure for the private markets industry. It provides the commons that individual firms and software vendors can build on rather than reinvent. The first component, and the foundation for everything that follows, is a shared reference vocabulary published as a glossary. Future components may include shared calculation libraries, reference data schemas, validation tooling, and other infrastructure the industry benefits from having in common. This document covers the vision, the architecture, the technology stack, the sequential build plan for the first component with exact file paths and folder structure snapshots at each stage, and the Docker-based development discipline. It is the single source of truth for the OPM project.

---

**Status** Draft
**Version** 1.7
**Timestamp** 2026-04-21
**Maintainer** Sean Henney
**Copyright holder** Sean Henney

---

# Part I — Vision and architecture

## 1. Why this exists

Private markets lacks the shared infrastructure that other parts of finance take for granted.

Every firm defines its own version of common terms. Every software vendor hard-codes its own taxonomy. Every analyst implements IRR slightly differently. Every report templates its data schema differently. The fragmentation costs the industry real money. It makes benchmarking imprecise, regulatory reporting harder, and every new piece of software reinvent the same foundational work.

Other parts of finance have solved comparable problems with open, shared infrastructure. The Financial Industry Business Ontology does it for banking vocabulary. OpenAPI does it for API specifications. JSON Schema does it for data validation. Schema.org does it for structured data on the web. Each is a commons: a neutral, open, maintained piece of infrastructure that many parties depend on and none of them own.

Private markets has no equivalent. OPM is the project to build one.

## 2. What OPM is, and what it becomes

OPM is a public umbrella for open, shared private markets infrastructure, maintained by Sean Henney and contributed to by the industry. The components of OPM are published as open-source packages, as documentation, and as reference specifications that anyone can adopt.

### 2.1 Current component

**The glossary.** A shared reference vocabulary covering firm types, fund structures, strategies, asset classes, instruments, and roles. Every concept has a stable identifier, a concise definition, relationships to other terms, and optional alignment to external standards. Published as the `privatemarkets` Python package on PyPI and as a documentation website at `openprivatemarkets.org`.

The glossary is the first component because vocabulary is the foundation everything else depends on.

### 2.2 Plausible future components

Illustrative, not committed. Shared calculations (IRR, MOIC, DPI, and so on). Reference data schemas. Validation tooling. Reference workflows. Interoperability specifications. The next component will be chosen based on genuine industry demand.

## 3. Principles that hold across all components

**Narrow interfaces over broad scope.** Each component does one thing.

**Open by default.** Content CC BY 4.0. Code MIT.

**Vocabulary first.** Every component depends on the glossary for names.

## 4. Names and addresses

**Project** Open Private Markets (OPM)
**PyPI package** `privatemarkets`
**Python import** `privatemarkets`
**GitHub organisation** `openprivatemarkets`
**Repository** `privatemarkets`
**Primary domain** `openprivatemarkets.org`

Early development happens under the maintainer's personal GitHub account at `github.com/seanhenney/privatemarkets`. Transfer to the organisation follows once populated. Documentation at https://docs.github.com/en/repositories/creating-and-managing-repositories/transferring-a-repository.

## 5. Relationship to adjacent standards

**FIBO** covers banking, securities, and market data. Coverage of private markets is thin, which OPM fills. Specification at https://spec.edmcouncil.org/fibo.

**Schema.org** is the model for governance. Process at https://schema.org/docs/howwework.html.

**OpenAPI** and **JSON Schema** are the models for "one source, many outputs."

## 6. Relationship to consumers

Third parties install the package and use it in their software. Trinity (the maintainer's commercial application) is a consumer like any other. The PMT website consumes the package for its reference model content.

## 7. Governance

Founder-led, then committee, then council if warranted. Semantic versioning.

## 8. License

OPM content and OPM code have different licenses, packaged together because the repository contains both.

**Content** (the glossary definitions, the prose bodies of each term, the documentation pages) is licensed under Creative Commons Attribution 4.0 International. Anyone can use, adapt, and redistribute, including commercially, with credit to OPM. Full text at https://creativecommons.org/licenses/by/4.0/legalcode.

**Code** (the Python loader, the Pydantic model, the tests, the build scripts, the workflows, the JSON Schema) is licensed under the MIT License. Anyone can use, modify, and redistribute, including commercially, with attribution. Full text at https://opensource.org/licenses/MIT.

The two licenses are declared together in the package metadata as an SPDX expression: `MIT AND CC-BY-4.0`. Both license texts ship with the package, so downstream consumers know which license applies to which material.

Copyright is held by Sean Henney personally. License notices read "Copyright © 2026 Sean Henney."

Contributors retain copyright on their own contributions and grant a license back through a standard Contributor License Agreement referenced in CONTRIBUTING.md.

---

# Part II — The first component: the glossary

## 9. Naming conventions

**Hyphens in identifier values.** Every identifier that refers to a concept uses hyphens. This applies to the `id` field in YAML, filenames, URL paths, wikilink targets, and Python dictionary keys. One convention, used everywhere.

**Underscores in field names.** The keys of the YAML structure itself (for example, `sub_types`) use underscores because they map directly to Python attributes through Pydantic.

```yaml
---
id: fund-manager
name: Fund Manager
category: firm-type
sub_types:
  - private-equity-manager
related_terms:
  - allocator
  - general-partner
fibo_equivalent: null
status: approved
version: 1.0.0
last_updated: 2026-04-21
---
```

In Python:

```python
from privatemarkets import glossary

terms = glossary()
fund_manager = terms["fund-manager"]
print(fund_manager.sub_types)
```

## 10. Data model

Each glossary term lives in its own markdown file with a YAML header and a prose body. The YAML holds the facts a computer needs. The markdown holds the explanation a human needs.

Cross-references use `[[term-id]]` syntax. A plugin resolves each wikilink to a hyperlink at build time and validates that the target exists. A companion plugin generates a "referenced by" panel.

Every YAML block must conform to a JSON Schema, which is checked on every contribution.

## 11. Where the glossary lives in the repository

The glossary content lives at `src/privatemarkets/glossary/`, inside the Python package rather than at the repository root.

This placement matters because of how Python packaging works. When someone runs `pip install privatemarkets`, the installer copies the contents of `src/privatemarkets/` into their environment. The glossary content must live inside that folder to ship with the package. The build system (Hatchling, configured in `pyproject.toml`) is told explicitly to include the markdown files in the wheel, otherwise it would include only the Python files by default.

MkDocs reads from the same `src/privatemarkets/glossary/` location when building the website. One folder, two uses: what consumers get on install, and what the website renders.

Each category gets its own folder. Each term is a markdown file inside the relevant category folder. The `index.md` inside each category folder is the landing page for that section; MkDocs serves it when the reader navigates to `/category/` with no trailing term.

The specific categories and terms are not prescribed by this document. The maintainer populates them from their taxonomy work.

## 12. Why Pydantic (and why not more than that)

The glossary enters the Python runtime as untrusted YAML data. Something has to check that fields have the right types and that the structure matches expectations.

Two validation layers cooperate.

**JSON Schema** validates every YAML file at build time. It enforces that identifiers match kebab-case, statuses are drawn from an allowed list, and so on. Contributions that fail validation are rejected in continuous integration before they merge.

**Pydantic**, inside the loader, turns validated dictionaries into typed Python objects so consumers get proper attribute access (`term.sub_types`) and type-checker support.

The Pydantic model is deliberately plain. It declares field names and types and does no additional validation, because JSON Schema has already done that work. Duplicating the regex patterns and enum checks inside Pydantic would waste effort and make the two sources of truth drift apart. The division of labour is: JSON Schema validates, Pydantic types.

## 13. Technology stack

**UV** for Python dependency management, virtual environments, package builds, and publishing to PyPI. Used on the host for project scaffolding and dependency changes, inside the Docker container for day-to-day commands, and on GitHub Actions runners for CI and release. Section 14 explains these four environments in detail. Documentation at https://docs.astral.sh/uv.

**MkDocs with Material for MkDocs** for the documentation website. MkDocs at https://www.mkdocs.org. Material at https://squidfunk.github.io/mkdocs-material.

**Zensical** is the likely future replacement for MkDocs. Migration happens when its module system supports wikilinks and backlinks. Zensical at https://zensical.org.

**Docker** for the reproducible development environment. Documentation at https://docs.docker.com.

**Just** as command runner. Documentation at https://just.systems.

**GitHub Actions** for CI. Documentation at https://docs.github.com/en/actions.

**GitHub Pages** for hosting. Documentation at https://docs.github.com/en/pages.

**Hatchling** as the build backend (set up automatically by `uv init --package`). Documentation at https://hatch.pypa.io.

**Pydantic** for typed data models. Documentation at https://docs.pydantic.dev.

**JSON Schema** for YAML validation. Specification at https://json-schema.org.

**pytest** for tests. Documentation at https://docs.pytest.org.

**Ruff** for linting. Documentation at https://docs.astral.sh/ruff.

---

# Part III — Development discipline

## 14. The four environments

The project runs in four distinct environments. They all read the same `pyproject.toml` and `uv.lock`, so they install the same dependency versions, but the environments exist for different reasons.

**The host machine.** Your laptop. UV is installed here via the curl installer (Step 1). Used only for project scaffolding (`uv init`) and dependency changes (`uv add`, `uv remove`, `uv build`). No Python code runs here in normal use. You need UV on the host because these commands modify `pyproject.toml` and `uv.lock`, which are files on your laptop's filesystem.

**The Docker container on your laptop.** A reproducible Linux environment built from Astral's official `ghcr.io/astral-sh/uv:python3.12-bookworm-slim` image. This image already has UV and Python pre-installed. The image build copies your `pyproject.toml` and `uv.lock` in and runs `uv sync --frozen`, which installs every dependency (including dev dependencies like MkDocs, pytest, ruff) into the container's virtual environment. Every day-to-day command (`just serve`, `just test`, `just lint`) executes inside this container. You never install MkDocs on your host.

**The GitHub Actions runner.** An ephemeral Ubuntu machine that boots fresh for each workflow run. UV is installed there by the `astral-sh/setup-uv@v3` action. `uv sync` installs dependencies from the lockfile. MkDocs, pytest, and ruff run directly on the runner. No Docker is involved here because the runner is already a reproducible environment and adding Docker would slow it down for no benefit.

**A consumer's machine.** Someone running `pip install privatemarkets`. They get only the runtime dependencies (`pyyaml`, `pydantic`), not the dev dependencies. MkDocs never ends up here because it is in the dev group. This is why the runtime/dev split matters: it keeps consumers' installs lean.

Four environments, one lockfile, consistent versions everywhere. UV on the host and in the container and on the GitHub runner are three separate UV installations, each managing its own filesystem, reading the same source of truth.

## 15. What lives where

**On the host.** UV, Docker, Just, Git, code editor. No Python packages installed directly; everything Python-related is either inside the container or inside the virtual environment UV created at `.venv/` (which exists for the host UV to operate on when adding dependencies, but is not where day-to-day commands run).

**In the container.** UV (from the base image), Python 3.12, and every dependency in the lockfile. MkDocs, pytest, ruff, mypy, Pydantic, PyYAML. This is where every `uv run <command>` executes in day-to-day work.

**On GitHub Actions.** UV (from the setup action), Python, and dependencies. Same as the container but on Ubuntu rather than Debian-slim and without Docker.

**On consumers' machines.** Only what is in the `dependencies` list. Nothing else.

## 16. UV on the host, Docker for everything else

The practical rule: host UV for `uv init`, `uv add`, `uv remove`, `uv build` (rare). Container for everything else, through Just recipes.

`uv add` on the host updates `pyproject.toml` and `uv.lock` on the host filesystem. The next `just rebuild` picks up the changes by copying the updated lockfile into a new container image.

## 17. Never hand-edit dependency sections

`pyproject.toml` has three kinds of content that matter here. Project metadata, dependency lists, and tool configuration. They have different rules.

**Project metadata** (`[project]`: name, description, authors, URLs, `requires-python`): hand-edit. UV has no commands for setting your description.

**Dependency lists** (`dependencies`, `[dependency-groups.dev]`): **never hand-edit**. Use `uv add <package>` and `uv add --dev <package>`. UV maintains `pyproject.toml` and `uv.lock` in sync. Hand-editing breaks the lockfile.

**Tool configuration** (`[tool.ruff]`, `[tool.mypy]`, `[tool.pytest.ini_options]`, `[tool.hatch.*]`): hand-edit. UV does not manage these.

**Build system** (`[build-system]`): leave alone. UV set this up during `uv init --package`.

## 18. Dependency groups, modern style

UV uses the PEP 735 standard: `[dependency-groups.dev]` for development dependencies rather than the older `[tool.uv] dev-dependencies` format. When you run `uv add --dev <package>`, UV writes to the modern location automatically. You do not need to remember this; UV does it correctly.

## 19. Debugging failures

**Container logs.** `docker compose logs docs`.

**Rebuild the image.** `just rebuild`.

**Shell inside.** `just shell`.

---

# Part IV — Sequential build plan

Follow in order. Paths are relative to the repository root. Files without extensions (`Dockerfile`, `LICENSE`, `justfile`) stay without extensions. Folders starting with a dot are significant.

## Step 1, install prerequisites

Docker Desktop at https://www.docker.com/products/docker-desktop.

UV. macOS/Linux: `curl -LsSf https://astral.sh/uv/install.sh | sh`. https://docs.astral.sh/uv/getting-started/installation.

Just. macOS: `brew install just`. https://just.systems/man/en/packages.html.

Git configured with your GitHub account. https://docs.github.com/en/get-started/quickstart/set-up-git.

Cursor at https://www.cursor.com or VS Code at https://code.visualstudio.com.

GitHub, PyPI (with 2FA), and Cloudflare accounts.

Verify:

```
docker --version
uv --version
just --version
git --version
```

## Step 2, reserve namespaces

Create the GitHub organisation `openprivatemarkets` at https://github.com/organizations/new. Free plan.

Register `openprivatemarkets.org` through Cloudflare's registrar.

The PyPI name `privatemarkets` is claimed by first publish in Step 23.

## Step 3, create the GitHub repository

Under your personal GitHub account, create `privatemarkets` at https://github.com/new. Public. Initialise with README and Python `.gitignore`. **Do not** add a license file through GitHub's interface; we create two license files manually in Step 6 because OPM is dual-licensed.

## Step 4, clone locally

```
git clone https://github.com/seanhenney/privatemarkets.git
cd privatemarkets
```

### Folder structure after Step 4

```
privatemarkets/
├── .git/
├── .gitignore
└── README.md
```

## Step 5, scaffold with UV

```
uv init --package . --python 3.12
```

The `.` scaffolds into the current directory. `--package` sets up a library layout with source under `src/`. `--python 3.12` pins the development Python version.

UV creates `pyproject.toml`, `src/privatemarkets/__init__.py`, `src/privatemarkets/py.typed`, and `.python-version`, and overwrites `README.md` with a default.

https://docs.astral.sh/uv/concepts/projects.

### Folder structure after Step 5

```
privatemarkets/
├── .git/
├── .gitignore
├── .python-version
├── README.md
├── pyproject.toml
└── src/
    └── privatemarkets/
        ├── __init__.py
        └── py.typed
```

## Step 6, create the two license files

OPM is dual-licensed. Content (glossary definitions, prose) is CC BY 4.0. Code (loader, tests, scripts) is MIT. Both licenses ship with the package so consumers can see exactly what applies to what. Section 8 of Part I explains the reasoning.

### Step 6a, create LICENSE-MIT

**Path:** `LICENSE-MIT`

Content:

```
MIT License

Copyright (c) 2026 Sean Henney

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

### Step 6b, create LICENSE-CC-BY-4.0

**Path:** `LICENSE-CC-BY-4.0`

Content:

```
Creative Commons Attribution 4.0 International License

Copyright (c) 2026 Sean Henney

The content in this repository (the glossary definitions, prose bodies of
terms, and documentation pages, as distinct from the Python source code) is
licensed under a Creative Commons Attribution 4.0 International License.

You are free to:

  Share — copy and redistribute the material in any medium or format.
  Adapt — remix, transform, and build upon the material for any purpose,
  even commercially.

Under the following terms:

  Attribution — You must give appropriate credit, provide a link to the
  license, and indicate if changes were made. You may do so in any
  reasonable manner, but not in any way that suggests the licensor
  endorses you or your use.

  No additional restrictions — You may not apply legal terms or
  technological measures that legally restrict others from doing anything
  the license permits.

The full legal code is available at:
https://creativecommons.org/licenses/by/4.0/legalcode
```

### Step 6c, update .gitignore

**Path being edited:** `.gitignore`

Append this line:

```
site/
```

This keeps MkDocs build output out of version control.

### Folder structure after Step 6

```
privatemarkets/
├── .git/
├── .gitignore
├── .python-version
├── LICENSE-CC-BY-4.0
├── LICENSE-MIT
├── README.md
├── pyproject.toml
└── src/
    └── privatemarkets/
        ├── __init__.py
        └── py.typed
```

## Step 7, edit project metadata

Open the `pyproject.toml` UV created. Replace its contents with the version below.

**Important:** the file below contains only metadata, tool configuration, and build system settings. It does **not** contain any dependency lists. Dependencies will be added by `uv add` in Steps 8 and 9, and UV will populate the dependency sections automatically. Do not add `dependencies = []` or `[dependency-groups.dev] = [...]` by hand. Let UV do it.

**Path being edited:** `pyproject.toml`

Content:

```toml
[project]
name = "privatemarkets"
version = "0.0.1"
description = "Open Private Markets (OPM) — shared, open infrastructure for the private markets industry. This package provides the reference vocabulary; more components to follow."
readme = "README.md"
requires-python = ">=3.11"
license = "MIT AND CC-BY-4.0"
license-files = ["LICENSE-MIT", "LICENSE-CC-BY-4.0"]
authors = [
    { name = "Sean Henney" }
]
keywords = ["private markets", "finance", "vocabulary", "ontology", "reference data"]

[project.urls]
Homepage = "https://openprivatemarkets.org"
Repository = "https://github.com/openprivatemarkets/privatemarkets"
Documentation = "https://openprivatemarkets.org"

[build-system]
requires = ["hatchling>=1.27"]
build-backend = "hatchling.build"

[tool.hatch.build.targets.wheel]
packages = ["src/privatemarkets"]

[tool.hatch.build.targets.wheel.force-include]
"src/privatemarkets/glossary" = "privatemarkets/glossary"

[tool.ruff]
line-length = 100
target-version = "py311"

[tool.ruff.lint]
select = ["E", "F", "I", "N", "UP", "B", "SIM", "RUF"]

[tool.mypy]
python_version = "3.11"
strict = true

[tool.pytest.ini_options]
pythonpath = ["src"]
```

Three things worth understanding in this file.

**The license declaration.** `license = "MIT AND CC-BY-4.0"` is a formal SPDX expression declaring the package is dual-licensed. The `license-files` list points at both license files in the repository, which ship with the published package. This format is defined by PEP 639 and is the current standard; the older table-based format (`license = { text = "..." }`) is deprecated and stops working in February 2026. Specification at https://packaging.python.org/en/latest/specifications/pyproject-toml/#license.

**The Hatchling version pin.** `"hatchling>=1.27"` ensures the build backend supports PEP 639 license expressions. Earlier versions reject the SPDX string.

**The Hatch build configuration.** `[tool.hatch.build.targets.wheel] packages = ["src/privatemarkets"]` tells Hatchling that `src/privatemarkets/` is the Python package to ship. `[tool.hatch.build.targets.wheel.force-include]` explicitly includes the `glossary/` folder and its markdown files in the built wheel. Hatchling excludes non-Python files from wheels by default; without this block, installed consumers would get the Python code but no glossary data.

**Staged setup note.** If `src/privatemarkets/glossary/` does not exist yet at this step, temporarily omit the `force-include` block and add it back immediately after creating the glossary folder. Otherwise `uv add` or `uv sync` can fail because Hatch cannot find the forced path.

`requires-python = ">=3.11"` is the minimum Python version for consumers installing from PyPI. `.python-version` pins development to 3.12. These are intentionally different.

Specification at https://packaging.python.org/en/latest/specifications/pyproject-toml. Hatchling documentation at https://hatch.pypa.io/latest/config/build.

## Step 8, add runtime dependencies

```
uv add pyyaml pydantic
```

UV adds these under `dependencies` in `pyproject.toml` and records exact versions in `uv.lock`.

## Step 9, add development dependencies

```
uv add --dev mkdocs "mkdocs-material>=9.6" mkdocs-ezlinks-plugin mkdocs-backlinks jsonschema pytest ruff mypy types-pyyaml
```

UV adds these under `[dependency-groups.dev]`.

### What `pyproject.toml` looks like after Steps 8 and 9

You do not type this. UV generates it. Showing it here so you can verify the state is right.

```toml
[project]
name = "privatemarkets"
version = "0.0.1"
description = "Open Private Markets (OPM) — shared, open infrastructure for the private markets industry. This package provides the reference vocabulary; more components to follow."
# ... (metadata as above) ...
dependencies = [
    "pyyaml>=6.0",
    "pydantic>=2.0",
]

[dependency-groups]
dev = [
    "mkdocs>=1.6",
    "mkdocs-material>=9.6",
    "mkdocs-ezlinks-plugin>=0.1",
    "mkdocs-backlinks>=0.9",
    "jsonschema>=4.0",
    "pytest>=8.0",
    "ruff>=0.6",
    "mypy>=1.11",
    "types-pyyaml>=6.0",
]

# ... (build-system, tool.hatch, tool.ruff etc as above) ...
```

Version numbers will reflect whatever is current when you run the commands. UV fills them in.

### Folder structure after Step 9

```
privatemarkets/
├── .git/
├── .gitignore
├── .python-version
├── .venv/                         (git-ignored)
├── LICENSE-CC-BY-4.0
├── LICENSE-MIT
├── README.md
├── pyproject.toml
├── src/
│   └── privatemarkets/
│       ├── __init__.py
│       └── py.typed
└── uv.lock
```

## Step 10, create the Dockerfile

**Path:** `Dockerfile`

```dockerfile
FROM ghcr.io/astral-sh/uv:python3.12-bookworm-slim

WORKDIR /app

COPY pyproject.toml uv.lock ./
RUN uv sync --frozen

COPY . .

EXPOSE 8000

CMD ["uv", "run", "mkdocs", "serve", "--dev-addr=0.0.0.0:8000"]
```

https://docs.astral.sh/uv/guides/integration/docker.

## Step 11, create the compose file

**Path:** `compose.yaml`

```yaml
services:
  docs:
    build: .
    ports:
      - "${DOCS_PORT:-8000}:8000"
    volumes:
      - .:/app
    working_dir: /app
```

`${DOCS_PORT:-8000}:8000` defaults to 8000, overridable with `DOCS_PORT=8765 just up` if 8000 is busy. Internal port is always 8000.

## Step 12, create the justfile

**Path:** `justfile`

```
# Show available recipes
default:
    @just --list

# Start the dev container in the background
up:
    docker compose up -d

# Stop the dev container
down:
    docker compose down

# Show the URL where the docs site is served
url:
    @printf "http://localhost:%s\n" "$(docker compose port docs 8000 | cut -d: -f2)"

# Run the MkDocs preview server
serve:
    docker compose exec docs uv run mkdocs serve --dev-addr=0.0.0.0:8000

# Run pytest
test:
    docker compose exec docs uv run pytest

# Lint with Ruff
lint:
    docker compose exec docs uv run ruff check .

# Format with Ruff
format:
    docker compose exec docs uv run ruff format .

# Type check with mypy
typecheck:
    docker compose exec docs uv run mypy src/

# Build the docs site
build:
    docker compose exec docs uv run mkdocs build --strict

# Open a bash shell inside the container
shell:
    docker compose exec docs bash

# Rebuild the container image (run after host-side dependency changes)
rebuild:
    docker compose down && docker compose up -d --build

# Clean up
clean:
    docker compose down -v
    rm -rf site/ dist/
```

No `add` recipe. Adding dependencies runs on the host: `uv add <package>` followed by `just rebuild`.

### Folder structure after Step 12

```
privatemarkets/
├── .git/
├── .gitignore
├── .python-version
├── .venv/                         (git-ignored)
├── Dockerfile
├── LICENSE-CC-BY-4.0
├── LICENSE-MIT
├── README.md
├── compose.yaml
├── justfile
├── pyproject.toml
├── src/
│   └── privatemarkets/
│       ├── __init__.py
│       └── py.typed
└── uv.lock
```

## Step 13, start the container

```
just up
just url
```

First build takes a minute or two. `just url` prints the URL.

Open it. MkDocs shows an error; no content yet. Expected.

## Step 14, create the JSON Schema

**Path:** `schemas/glossary-term.schema.json`

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "Glossary Term",
  "description": "Validation contract for glossary term YAML front matter.",
  "type": "object",
  "required": ["id", "name", "category", "status", "version"],
  "additionalProperties": false,
  "properties": {
    "id": {
      "type": "string",
      "pattern": "^[a-z0-9-]+$",
      "description": "Stable term identifier in lowercase kebab-case."
    },
    "name": {
      "type": "string",
      "description": "Human-readable term name."
    },
    "category": {
      "type": "string",
      "description": "Top-level grouping used for navigation and organization."
    },
    "sub_types": {
      "type": "array",
      "description": "Optional list of subtype term IDs.",
      "items": {
        "type": "string",
        "pattern": "^[a-z0-9-]+$",
        "description": "Subtype term ID in lowercase kebab-case."
      }
    },
    "typical_roles": {
      "type": "array",
      "description": "Optional list of role term IDs commonly associated with this term.",
      "items": {
        "type": "string",
        "pattern": "^[a-z0-9-]+$",
        "description": "Role term ID in lowercase kebab-case."
      }
    },
    "related_terms": {
      "type": "array",
      "description": "Optional list of related term IDs.",
      "items": {
        "type": "string",
        "pattern": "^[a-z0-9-]+$",
        "description": "Related term ID in lowercase kebab-case."
      }
    },
    "fibo_equivalent": {
      "type": ["string", "null"],
      "description": "Optional FIBO URI for equivalent concept, or null if none."
    },
    "status": {
      "type": "string",
      "enum": ["draft", "review", "approved", "deprecated"],
      "description": "Editorial lifecycle status for the term."
    },
    "version": {
      "type": "string",
      "pattern": "^\\d+\\.\\d+\\.\\d+$",
      "description": "Semantic version of the term definition (major.minor.patch)."
    },
    "last_updated": {
      "type": "string",
      "format": "date",
      "description": "Optional ISO date (YYYY-MM-DD) for most recent substantive update."
    }
  }
}
```

## Step 15, create the Pydantic model

**Path:** `src/privatemarkets/models.py`

```python
"""Typed model for glossary terms."""

from __future__ import annotations

from datetime import date

from pydantic import BaseModel


class GlossaryTerm(BaseModel):
    """A glossary term loaded from a markdown file.

    Fields mirror the YAML front matter, with the markdown body appended
    as ``body``. JSON Schema validation runs upstream, so this model's
    job is typing rather than validation.
    """

    id: str
    name: str
    category: str
    sub_types: list[str] = []
    typical_roles: list[str] = []
    related_terms: list[str] = []
    fibo_equivalent: str | None = None
    status: str
    version: str
    last_updated: date | None = None
    body: str = ""
```

## Step 16, create the loader

**Path:** `src/privatemarkets/loader.py`

```python
"""Load glossary terms from YAML front matter in markdown files."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from privatemarkets.models import GlossaryTerm

FRONTMATTER_DELIMITER = "---"


class FrontmatterError(ValueError):
    """Raised when a markdown file has missing or malformed YAML front matter."""


def parse_frontmatter(path: Path) -> tuple[dict[str, Any], str]:
    """Split a markdown file into its YAML front matter and prose body."""
    text = path.read_text(encoding="utf-8")

    if not text.startswith(FRONTMATTER_DELIMITER):
        raise FrontmatterError(f"{path} has no YAML front matter")

    try:
        _, frontmatter_text, body = text.split(FRONTMATTER_DELIMITER, maxsplit=2)
    except ValueError as exc:
        raise FrontmatterError(f"{path} has malformed front matter") from exc

    data = yaml.safe_load(frontmatter_text) or {}
    return data, body.strip()


def load_term(path: Path) -> GlossaryTerm:
    """Load a single glossary term from a markdown file."""
    data, body = parse_frontmatter(path)
    data["body"] = body
    return GlossaryTerm.model_validate(data)


def load_glossary(glossary_dir: Path) -> dict[str, GlossaryTerm]:
    """Load every glossary term under a directory, keyed by id.

    Skips ``index.md`` files, which are category landing pages rather
    than terms.
    """
    terms: dict[str, GlossaryTerm] = {}
    for md_path in glossary_dir.rglob("*.md"):
        if md_path.name == "index.md":
            continue
        term = load_term(md_path)
        terms[term.id] = term
    return terms
```

## Step 17, replace the package entry point

**Path being edited:** `src/privatemarkets/__init__.py`

```python
"""Open Private Markets reference vocabulary."""

from __future__ import annotations

from functools import cache
from pathlib import Path

from privatemarkets.loader import load_glossary
from privatemarkets.models import GlossaryTerm

__version__ = "0.0.1"

_GLOSSARY_DIR = Path(__file__).parent / "glossary"


@cache
def glossary() -> dict[str, GlossaryTerm]:
    """Return every glossary term keyed by id."""
    return load_glossary(_GLOSSARY_DIR)


__all__ = ["GlossaryTerm", "glossary"]
```

The path is computed as `Path(__file__).parent / "glossary"`, which resolves to `src/privatemarkets/glossary/` during development and to the installed package's `glossary/` folder when someone has installed the package from PyPI. Both paths work because the glossary sits next to `__init__.py`.

## Step 18, create tests

**Path:** `tests/test_loader.py`

```python
"""Tests for the glossary loader."""

from __future__ import annotations

from pathlib import Path

import pytest

from privatemarkets import GlossaryTerm, glossary
from privatemarkets.loader import FrontmatterError, parse_frontmatter


def test_glossary_returns_dict():
    terms = glossary()
    assert isinstance(terms, dict)


def test_glossary_values_are_terms():
    for term in glossary().values():
        assert isinstance(term, GlossaryTerm)


def test_glossary_keys_are_kebab_case():
    for term_id in glossary():
        assert term_id.replace("-", "").isalnum()
        assert term_id.replace("-", "").islower()


def test_parse_frontmatter_rejects_file_without_frontmatter(tmp_path: Path):
    bad_file = tmp_path / "bad.md"
    bad_file.write_text("# Just a heading, no frontmatter\n")
    with pytest.raises(FrontmatterError):
        parse_frontmatter(bad_file)


def test_parse_frontmatter_extracts_data_and_body(tmp_path: Path):
    good_file = tmp_path / "good.md"
    good_file.write_text(
        "---\n"
        "id: example-term\n"
        "name: Example Term\n"
        "---\n"
        "Body content here.\n"
    )
    data, body = parse_frontmatter(good_file)
    assert data["id"] == "example-term"
    assert body == "Body content here."
```

```
just test
```

First three tests pass on an empty glossary (loops do not execute) and start enforcing real constraints once content is added. Last two tests exercise the parser directly using pytest's `tmp_path` fixture for isolated file creation.

https://docs.pytest.org/en/stable/getting-started.html.

## Step 19, configure MkDocs

**Path:** `mkdocs.yml`

```yaml
site_name: Open Private Markets
site_url: https://openprivatemarkets.org
site_description: Shared reference vocabulary for private markets
repo_url: https://github.com/openprivatemarkets/privatemarkets
repo_name: openprivatemarkets/privatemarkets

docs_dir: src/privatemarkets/glossary

theme:
  name: material
  palette:
    - scheme: default
      primary: black
      accent: teal
  features:
    - navigation.instant
    - navigation.tracking
    - navigation.sections
    - navigation.top
    - search.suggest
    - toc.integrate
    - content.action.edit

plugins:
  - search
  - ezlinks:
      wikilinks: true
  - backlinks

markdown_extensions:
  - admonition
  - pymdownx.details
  - pymdownx.superfences
  - toc:
      permalink: true
  - attr_list
  - md_in_html

strict: true
```

`docs_dir: src/privatemarkets/glossary` means MkDocs reads from the same location that ships in the package.

`nav:` is intentionally omitted until the category taxonomy is decided.

## Step 20, create the glossary landing page

**Path:** `src/privatemarkets/glossary/index.md`

```markdown
# Open Private Markets Glossary

A shared reference vocabulary for private markets. Work in progress.
```

### Folder structure after Step 20

```
privatemarkets/
├── .git/
├── .gitignore
├── .python-version
├── .venv/                         (git-ignored)
├── Dockerfile
├── LICENSE-CC-BY-4.0
├── LICENSE-MIT
├── README.md
├── compose.yaml
├── justfile
├── mkdocs.yml
├── pyproject.toml
├── schemas/
│   └── glossary-term.schema.json
├── src/
│   └── privatemarkets/
│       ├── __init__.py
│       ├── glossary/
│       │   └── index.md
│       ├── loader.py
│       ├── models.py
│       └── py.typed
├── tests/
│   └── test_loader.py
└── uv.lock
```

## Step 21, preview

```
just url
```

Open the URL. The landing page renders.

## Step 22, PyPI trusted publishing and GitHub environment

PyPI: Your projects → Publishing → Add a new pending publisher.

- Project name: `privatemarkets`
- Owner: `seanhenney`
- Repository: `privatemarkets`
- Workflow: `publish.yml`
- Environment: `pypi`

https://docs.pypi.org/trusted-publishers/adding-a-publisher.

GitHub: repository Settings → Environments → New environment. Name `pypi`.

## Step 23, create GitHub Actions workflows

### Step 23a, validate

**Path:** `.github/workflows/validate.yml`

```yaml
name: Validate

on:
  pull_request:
    branches: [main]

jobs:
  validate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: astral-sh/setup-uv@v3
      - run: uv sync
      - run: uv run ruff check .
      - run: uv run mypy src/
      - run: uv run pytest
      - run: uv run mkdocs build --strict
```

### Step 23b, deploy

**Path:** `.github/workflows/deploy.yml`

```yaml
name: Deploy

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    permissions:
      contents: write
    steps:
      - uses: actions/checkout@v4
      - uses: astral-sh/setup-uv@v3
      - run: uv sync
      - run: uv run mkdocs gh-deploy --force
```

### Step 23c, publish

**Path:** `.github/workflows/publish.yml`

```yaml
name: Publish to PyPI

on:
  release:
    types: [published]

jobs:
  publish:
    runs-on: ubuntu-latest
    environment: pypi
    permissions:
      id-token: write
    steps:
      - uses: actions/checkout@v4
      - uses: astral-sh/setup-uv@v3
      - run: uv build
      - run: uv publish --trusted-publishing automatic
```

## Step 24, commit and publish

```
git add .
git commit -m "Initial OPM glossary infrastructure"
git push
```

Validation runs. On pass, deploy runs and docs go live.

Publish the package by drafting a GitHub Release. Tag `v0.0.1`, target main, title "Initial release," publish. The package claims the name on PyPI.

## Step 25, custom domain

Cloudflare DNS for `openprivatemarkets.org`: CNAME `@` → `seanhenney.github.io`. CNAME `www` → same.

GitHub Settings → Pages: Custom domain `openprivatemarkets.org`. Enforce HTTPS.

GitHub commits `CNAME` automatically. Pull main.

**Path created by GitHub:** `CNAME`

## Step 26, transfer to the organisation

Settings → Danger Zone → Transfer → `openprivatemarkets`.

Update the PyPI trusted publisher owner.

---

# Part V — Content phase

## 27. Adding a glossary term

Pick the category. If the category folder does not exist under `src/privatemarkets/glossary/`, create it. Inside, create a markdown file named after the term's identifier.

**Example path:** `src/privatemarkets/glossary/firm-types/fund-manager.md`

```markdown
---
id: fund-manager
name: Fund Manager
category: firm-type
sub_types:
  - private-equity-manager
related_terms:
  - allocator
  - general-partner
fibo_equivalent: null
status: approved
version: 1.0.0
last_updated: 2026-04-21
---

# Fund Manager

A fund manager is a firm that raises capital from investors into pooled
investment vehicles and deploys that capital into private market assets
according to a defined strategy. The fund manager typically takes the
[[general-partner]] role in the fund structures it operates.
```

## 28. Adding a category landing page

**Example path:** `src/privatemarkets/glossary/firm-types/index.md`

Regular markdown; no YAML front matter needed.

## 29. Adding a Python dependency

```
uv add <package>
just rebuild
```

`uv add` on the host updates `pyproject.toml` and `uv.lock`. `just rebuild` picks it up in the container.

## 30. Example folder structure with content

Illustrative. Categories and terms are your decision.

```
src/privatemarkets/glossary/
├── index.md
├── firm-types/
│   ├── index.md
│   ├── fund-manager.md
│   └── allocator.md
├── fund-structures/
│   ├── index.md
│   ├── closed-end-fund.md
│   └── separately-managed-account.md
├── strategies/
│   ├── index.md
│   └── buyout.md
├── asset-classes/
│   └── index.md
├── instruments/
│   └── index.md
└── roles/
    ├── index.md
    ├── general-partner.md
    └── limited-partner.md
```

---

# Part VI — Beyond the first component

## 31. After the glossary ships

Ship 0.1.0, 0.2.0 as coverage grows. Once external users and contributor activity are real, consider the next component.

## 32. When a new component starts

Each new component gets its own document. Sub-modules of `privatemarkets` or sibling packages under the organisation: per-component decision.

## 33. Scope discipline

Glossary is vocabulary. Calculations, schemas, workflows, classifications of companies go elsewhere.

---

# Part VII — File path reference

| Path | Step | Purpose |
|---|---|---|
| `LICENSE-MIT` | 6a | Code license (MIT) |
| `LICENSE-CC-BY-4.0` | 6b | Content license (CC BY 4.0) |
| `.gitignore` | 6c | Append `site/` |
| `pyproject.toml` | 5 (created), 7 (metadata hand-edited) | Metadata + tool config; dependencies via UV |
| `Dockerfile` | 10 | Docker image recipe |
| `compose.yaml` | 11 | Compose orchestration |
| `justfile` | 12 | Task runner recipes |
| `schemas/glossary-term.schema.json` | 14 | JSON Schema |
| `src/privatemarkets/__init__.py` | 5 (created), 17 (replaced) | Package entry point |
| `src/privatemarkets/models.py` | 15 | Pydantic model |
| `src/privatemarkets/loader.py` | 16 | YAML loader |
| `src/privatemarkets/glossary/index.md` | 20 | Landing page |
| `tests/test_loader.py` | 18 | Tests |
| `mkdocs.yml` | 19 | MkDocs config |
| `.github/workflows/validate.yml` | 23a | PR validation |
| `.github/workflows/deploy.yml` | 23b | Site deploy |
| `.github/workflows/publish.yml` | 23c | PyPI publish |
| `CNAME` | 25 | Custom domain (created by GitHub) |

## 34. Common questions

**Why the glossary lives inside the Python package.** When someone installs `privatemarkets` from PyPI, Hatchling's wheel includes everything under `src/privatemarkets/`. The glossary must live there to ship. The `[tool.hatch.build.targets.wheel.force-include]` block makes this explicit for non-Python files like markdown.

**Why we never hand-edit dependency sections in pyproject.toml.** UV keeps `pyproject.toml` and `uv.lock` in sync via `uv add` and `uv remove`. Hand-editing desyncs them, causing subtle install problems.

**Why runtime and dev dependencies are split.** Runtime dependencies are what consumers need (`pyyaml`, `pydantic`). Dev dependencies are what the maintainer needs (`mkdocs`, `pytest`, etc). A consumer installing the glossary should not be forced to download MkDocs.

**Where dev dependencies live in pyproject.toml.** Under `[dependency-groups.dev]`, which is the PEP 735 standard. UV writes to this location when you run `uv add --dev`.

**Why UV runs on the host for some commands.** `uv init`, `uv add`, `uv remove` modify `pyproject.toml` and `uv.lock` on the host. The next Docker build reads those files. Day-to-day commands run inside the container.

**Why Dockerfile and justfile have no extension.** Docker and Just look for these exact names.

**Why the port uses `${DOCS_PORT:-8000}`.** Default 8000; override when busy. `just url` reports the actual bound port.

**Why `.python-version` says 3.12 while `requires-python` says `>=3.11`.** Development is pinned to one specific version for reproducibility. Consumers get flexibility to use 3.11 or later.

**Why two LICENSE files.** OPM has two kinds of material in one repository: software (the Python code, scripts, workflows) and creative content (the glossary definitions and prose). MIT is the right license for software but is ambiguous when applied to prose. CC BY 4.0 is the right license for creative content. The dual license removes the ambiguity. `LICENSE-MIT` covers code, `LICENSE-CC-BY-4.0` covers content.

**Why the `license` field is `"MIT AND CC-BY-4.0"`.** This is a formal SPDX license expression, defined by PEP 639. Tools that read PyPI metadata can parse it unambiguously. The older `license = { text = "MIT" }` format is deprecated and stops working in February 2026.
