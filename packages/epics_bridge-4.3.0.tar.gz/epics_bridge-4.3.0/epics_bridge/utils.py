"""Small utilities: timing context manager."""

import time
from types import TracebackType
from typing import Optional, Type


class Timer:
    """
    Context manager that records elapsed time in seconds.

    After exiting the context, the duration is available as the ``duration``
    attribute (and ``start`` / ``end`` as perf_counter timestamps).
    """

    start: float
    end: float
    duration: float

    def __enter__(self) -> "Timer":
        self.start = time.perf_counter()
        return self

    def __exit__(
        self,
        exc_type: Optional[Type[BaseException]],
        exc_value: Optional[BaseException],
        traceback: Optional[TracebackType],
    ) -> None:
        self.end = time.perf_counter()
        self.duration = self.end - self.start
