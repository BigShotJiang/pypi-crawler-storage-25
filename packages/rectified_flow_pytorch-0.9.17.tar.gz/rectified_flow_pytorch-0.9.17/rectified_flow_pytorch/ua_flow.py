from functools import partial

import torch
from torch.nn import Module
import torch.nn.functional as F
from einops import reduce, rearrange, einsum
from torchdiffeq import odeint
import einx


def exists(v):
    return v is not None

def default(v, d):
    return v if exists(v) else d

def identity(t):
    return t

def append_dims(t, dims):
    shape = t.shape
    ones = ((1,) * dims)
    return t.reshape(*shape, *ones)


class UAFlow(Module):
    def __init__(
        self,
        model: Module,
        times_cond_kwarg = None,
        data_shape = None,
        normalize_data_fn = identity,
        unnormalize_data_fn = identity,
        max_timesteps = 100,
        ucg_scale = 1.0, 
        cfg_scale = 1.0, 
        beta_nll = 1.0,
        odeint_kwargs : dict = dict(method='heun2')
    ):
        super().__init__()

        self.model = model
        
        # get the predicted mean and log_var
        self.model.register_forward_hook(lambda m, i, out: (out[0], 2 * torch.log(out[1].clamp(min=1e-8))))

        self.times_cond_kwarg = times_cond_kwarg
        self.data_shape = data_shape

        self.normalize_data_fn = normalize_data_fn
        self.unnormalize_data_fn = unnormalize_data_fn
        self.max_timesteps = max_timesteps
        
        self.ucg_scale = ucg_scale
        self.cfg_scale = cfg_scale
        self.beta_nll = beta_nll

        self.odeint_fn = partial(odeint, **odeint_kwargs)

    @torch.no_grad()
    def sample(
        self,
        steps = 16,
        batch_size = 1,
        data_shape = None,
        **kwargs
    ):
        assert 1 <= steps <= self.max_timesteps


        data_shape = default(data_shape, self.data_shape)
        assert exists(data_shape), 'shape of the data must be passed in, or set at init or during training'
        device = next(self.model.parameters()).device

        noise = torch.randn((batch_size, *data_shape), device = device)
        # TODO - implement variance propagation 
        state_variance = torch.zeros_like(noise)

        times = torch.linspace(0., 1., steps + 1, device = device)

        denoised = noise

        def ode_fn(t, x_current):
            time_b = t.expand(batch_size)
            time_kwarg = {self.times_cond_kwarg: time_b} if exists(self.times_cond_kwarg) else dict()

            def wrapped_model(x_in):
                return self.model(x_in, **time_kwarg, **kwargs)

            with torch.set_grad_enabled(self.ucg_scale > 0):
                x_in = x_current.detach()
                if self.ucg_scale > 0:
                    x_in.requires_grad_(True)

                # u-cf block
                if 'cond' in kwargs and self.cfg_scale > 0.0:
                    cond = kwargs['cond']
                    v_cond, log_var_cond = wrapped_model(x_in)
                    
                    kwargs['cond'] = torch.full_like(cond, -1)
                    v_null, log_var_null = wrapped_model(x_in)
                    kwargs['cond'] = cond
                    
                    # finding the closed form lambda
                    sigma_y = torch.exp(0.5 * log_var_cond)
                    sigma_null = torch.exp(0.5 * log_var_null)

                    lambda_num = einsum(sigma_y, sigma_null - sigma_y, 'b c h w, b c h w -> b')
                    lambda_den = reduce((sigma_y - sigma_null) ** 2, 'b c h w -> b', 'sum') + 1e-8

                    lambda_opt = lambda_num / lambda_den

                    lambda_star = torch.clamp(lambda_opt, min=0.0, max=self.cfg_scale)
                    lambda_star = rearrange(lambda_star, 'b -> b 1 1 1')

                    pred_mean = v_cond + lambda_star * (v_cond - v_null)

                    sigma_cfg = (1.0 + lambda_star) * sigma_y - lambda_star * sigma_null
                    pred_var = sigma_cfg ** 2
                    
                else:
                    pred_mean, log_var = wrapped_model(x_in)
                    pred_var = torch.exp(log_var)

               
                if self.ucg_scale > 0:
                    # get derivative of uncertainty w.r.t. input
                    f_unc = - (reduce(pred_var, 'b c h w -> b', 'mean')) ** 2
                    grad_x = torch.autograd.grad(f_unc.sum(), x_in)[0]

                    grad_norm = torch.linalg.norm(grad_x.reshape(batch_size, -1), dim=1).view(-1, 1, 1, 1) + 1e-8
                    grad_x = grad_x / grad_norm

                    b_t = (1.0 - t) / (t + 1e-5)
                    b_t = torch.clamp(b_t, max=5.0) 
                    
                    velocity = pred_mean + b_t * self.ucg_scale * grad_x
                else:
                    velocity = pred_mean


            return velocity

        denoised = self.odeint_fn(ode_fn, denoised, times)[-1]

        denoised = self.unnormalize_data_fn(denoised)
        denoised = denoised.clamp(0., 1.) 

        return denoised

            
    def forward(self, data, noise=None, times=None, **kwargs):

        if isinstance(data, (tuple, list)):
            actual_image, cond = data[0], data[1]
            cond = cond.flatten()
            
            if self.training and torch.rand(1).item() < 0.1:
                cond = torch.full_like(cond, -1)
                
            kwargs['cond'] = cond
            data = actual_image
    
        data = self.normalize_data_fn(data)

        shape, ndim = data.shape, data.ndim
        self.data_shape = default(self.data_shape, shape[1:]) 
        batch, device = shape[0], data.device

        times = default(times, torch.rand(batch, device=device))
        times = times * (1. - self.max_timesteps ** -1)

        noise = default(noise, torch.randn_like(data))
        padded_times = append_dims(times, ndim - 1)
        noised_data = noise.lerp(data, padded_times) 

        time_kwarg = {self.times_cond_kwarg: times} if exists(self.times_cond_kwarg) else dict() 
        
        pred_mean, pred_log_var = self.model(noised_data, **time_kwarg, **kwargs)

        # uncertainty-aware loss computation

        padded_times = rearrange(times, 'b -> b 1 1 1 1')

        exact_mean = einx.multiply("b, j c h w -> b j c h w", times, data)
        exact_variance = (1.0 - padded_times) ** 2 + 1e-8
        
        squared_err = (einx.subtract("b c h w, b j c h w -> b j c h w", noised_data, exact_mean) ** 2) / (2 * exact_variance)
        dist = reduce(squared_err, 'b j c h w -> b j', 'sum')

        weights = torch.softmax(-dist, dim=1)

        ut_cond_all = einx.subtract("j c h w, b c h w -> b j c h w", data, noised_data) / (1.0 - padded_times + 1e-8)

        u_hat = einsum(ut_cond_all, weights, "b j c h w, b j -> b c h w",)

        flow_cond = data - noise 

        correction = (u_hat ** 2 - flow_cond ** 2).detach()

        pred_var = torch.exp(pred_log_var)

        loss = ((pred_mean - flow_cond) ** 2) / (2 * pred_var) +  0.5 *  pred_log_var + (correction / (2 * pred_var))

        if self.beta_nll > 0.0:
            loss = (pred_var.detach() ** self.beta_nll) * loss

        return loss.mean()