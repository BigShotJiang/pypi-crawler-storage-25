"""Package version metadata."""

__version__ = "0.13.7"
