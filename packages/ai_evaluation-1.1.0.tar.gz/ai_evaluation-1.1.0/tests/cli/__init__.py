"""CLI test suite."""
