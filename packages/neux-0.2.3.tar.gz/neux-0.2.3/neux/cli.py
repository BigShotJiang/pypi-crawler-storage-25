"""NEUX command-line interface powered by typer + rich."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import typer
from rich.console import Console
from rich.panel import Panel
from rich.progress import BarColumn, Progress, SpinnerColumn, TextColumn
from rich.table import Table
from rich.tree import Tree

from neux import __version__
from neux.detectors import DetectionContext, DetectionEngine, all_detectors
from neux.engine import GraphEngine
from neux.generator.claude_md import generate_all
from neux.reviewer import review_session
from neux.scanner import DEFAULT_IGNORE_DIRS, ProjectScanner

app = typer.Typer(
    name="neux",
    help="NEUX — codebase nervous system for AI-assisted development.",
    add_completion=False,
    no_args_is_help=True,
)

console = Console()


# ======================================================================
# init / scan
# ======================================================================


@app.command()
def init(
    path: Path = typer.Argument(Path.cwd(), help="Project root (defaults to current directory)"),
    install_hooks: bool = typer.Option(True, help="Install Claude Code hooks in .claude/settings.json"),
) -> None:
    """Initialize NEUX for a project: scan, detect, generate docs, install hooks."""
    root = path.resolve()
    console.print(Panel.fit(f"[bold cyan]NEUX v{__version__}[/bold cyan] — initializing {root}", border_style="cyan"))

    with GraphEngine(root) as engine:
        scanner = ProjectScanner(engine)
        stack = scanner.detect_stack(root)
        console.print(f"[dim]Stack:[/dim] {stack['languages'] or 'unknown'} {('+ ' + ', '.join(stack['frameworks'])) if stack['frameworks'] else ''}")

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            console=console,
            transient=True,
        ) as progress:
            task = progress.add_task("Scanning files...", total=None)
            stats = scanner.scan_project(root, progress_cb=lambda p: progress.update(task, description=f"Scanning {p}"))

        console.print(
            f"[green]Scanned[/green] {stats.files_scanned} files · "
            f"{stats.nodes_added} nodes · {stats.edges_added} edges · {stats.errors} errors"
        )

        console.print("[dim]Running detectors...[/dim]")
        results = _run_detectors(engine, root, stack)
        console.print(f"[green]Detected[/green] {sum(1 for r in results if r.type=='pattern')} patterns, "
                      f"{sum(1 for r in results if r.type=='convention')} conventions, "
                      f"{sum(len(r.inconsistencies) for r in results)} inconsistencies")

        console.print("[dim]Generating CLAUDE.md and sub-manuals...[/dim]")
        written = generate_all(root, engine)
        console.print(f"[green]Generated[/green] {len(written)} docs")

        if install_hooks:
            installed = _install_hooks(root)
            if installed:
                console.print(f"[green]Hooks installed[/green] at {installed}")

    console.print(Panel.fit(
        f"[bold green]NEUX ready.[/bold green]\n"
        f"Run `neux status` to inspect the graph, `neux impact <target>` for blast radius.",
        border_style="green",
    ))


@app.command()
def scan(
    changed: bool = typer.Option(False, "--changed", "-c", help="Only rescan files whose content changed"),
    path: Path = typer.Argument(Path.cwd()),
) -> None:
    """Scan the codebase and refresh the graph."""
    root = path.resolve()
    with GraphEngine(root) as engine:
        scanner = ProjectScanner(engine)
        if changed:
            stats = scanner.scan_changed(root)
            console.print(f"[green]Rescanned[/green] {stats.files_scanned} files ({stats.files_skipped} unchanged)")
        else:
            with Progress(SpinnerColumn(), TextColumn("{task.description}"), console=console, transient=True) as progress:
                task = progress.add_task("Scanning...", total=None)
                stats = scanner.scan_project(root, progress_cb=lambda p: progress.update(task, description=f"Scanning {p}"))
            console.print(f"[green]Scanned[/green] {stats.files_scanned} files · {stats.nodes_added} nodes")

        stack = scanner.detect_stack(root)
        _run_detectors(engine, root, stack)
        generate_all(root, engine)
        console.print("[green]CLAUDE.md regenerated[/green]")


# ======================================================================
# Read-only commands
# ======================================================================


@app.command()
def status(
    as_json: bool = typer.Option(False, "--json", "-j", help="Full report as JSON (all sections)"),
    path: Path = typer.Argument(Path.cwd()),
) -> None:
    """Full project report — health, god nodes, patterns, inconsistencies, modules. One command."""
    from neux.dashboard.api import overview as api_overview, patterns as api_patterns
    from neux.dashboard.api import inconsistencies as api_incs, conventions as api_conventions

    with GraphEngine(path.resolve()) as engine:
        ov = api_overview(engine)
        pats = api_patterns(engine)
        convs = api_conventions(engine)
        incs = api_incs(engine, status="open")
        mods = engine.get_modules()

    if as_json:
        console.print_json(data={
            "overview": ov,
            "patterns": pats,
            "conventions": convs,
            "inconsistencies": incs,
            "modules": [dict(m) for m in mods],
        })
        return

    # ── Health ──
    s = ov["stats"]
    health = ov["health_score"]
    health_pct = round(health * 100)
    hc = "green" if health >= 0.7 else "yellow" if health >= 0.4 else "red"

    console.print(Panel.fit(
        f"[bold {hc}]HEALTH: {health_pct}%[/bold {hc}]  ·  "
        f"compliance: {round(ov['average_compliance'] * 100)}%",
        title="[bold cyan]NEUX STATUS[/bold cyan]",
        border_style="cyan",
    ))

    metrics = Table(show_header=False, box=None, pad_edge=False)
    metrics.add_column(style="cyan")
    metrics.add_column(justify="right")
    metrics.add_row("Nodes", str(s["nodes"]))
    metrics.add_row("Edges", str(s["edges"]))
    metrics.add_row("Modules", str(s["modules"]))
    metrics.add_row("Patterns", f"{s['patterns_confirmed']} confirmed / {s['patterns']} total")
    metrics.add_row("Conventions", str(s["conventions"]))
    metrics.add_row("Open issues", f"[{'red' if s['inconsistencies_open'] > 0 else 'green'}]{s['inconsistencies_open']}[/]")
    metrics.add_row("Sessions", str(s["sessions"]))
    console.print(metrics)

    # ── Modules ──
    if mods:
        console.print()
        mod_table = Table(title="Modules", title_style="bold")
        mod_table.add_column("name", style="cyan")
        mod_table.add_column("layer")
        mod_table.add_column("nodes", justify="right")
        mod_table.add_column("edges", justify="right")
        mod_table.add_column("coupling", justify="right")
        for m in mods:
            mod_table.add_row(
                m["name"], m["layer"] or "—",
                str(m["node_count"]), str(m["edge_count"]),
                f"{int((m['coupling_score'] or 0) * 100)}%",
            )
        console.print(mod_table)

    # ── God nodes ──
    god = ov.get("god_nodes") or []
    if god:
        console.print()
        god_table = Table(title="God nodes (high-impact — modify with care)", title_style="bold")
        god_table.add_column("name")
        god_table.add_column("module", style="cyan")
        god_table.add_column("file")
        god_table.add_column("connections", justify="right")
        for g in god:
            conn = g.get("total_connections") or g.get("connections") or 0
            god_table.add_row(g["name"], g.get("module", "—"), g.get("file_path", "—"), str(conn))
        console.print(god_table)

    # ── Patterns ──
    pat_items = pats.get("items") or []
    if pat_items:
        console.print()
        pat_table = Table(title="Patterns", title_style="bold")
        pat_table.add_column("id")
        pat_table.add_column("category")
        pat_table.add_column("status")
        pat_table.add_column("confidence", justify="right")
        pat_table.add_column("rule")
        for p in pat_items:
            st = p["status"]
            sc = "green" if st == "confirmed" else "cyan" if st == "candidate" else "dim"
            pat_table.add_row(
                p["id"], p["category"], f"[{sc}]{st}[/]",
                f"{p['confidence']:.0%}", (p.get("rule_text") or p.get("description") or "")[:60],
            )
        console.print(pat_table)

    # ── Conventions ──
    conv_items = convs.get("items") or []
    if conv_items:
        console.print()
        conv_table = Table(title="Conventions", title_style="bold")
        conv_table.add_column("name")
        conv_table.add_column("compliance", justify="right")
        conv_table.add_column("status")
        conv_table.add_column("rule")
        for c in conv_items:
            comp = c.get("compliance") or 0
            cc = "green" if comp >= 0.9 else "yellow" if comp >= 0.7 else "red"
            st = c["status"]
            sc = "green" if st == "confirmed" else "cyan" if st == "candidate" else "dim"
            conv_table.add_row(
                c["name"], f"[{cc}]{comp:.0%}[/]", f"[{sc}]{st}[/]",
                (c.get("rule_text") or c.get("description") or "")[:60],
            )
        console.print(conv_table)

    # ── Inconsistencies ──
    inc_items = incs.get("items") or []
    if inc_items:
        console.print()
        by_sev = incs.get("by_severity") or {}
        sev_str = "  ".join(
            f"[{'red' if sv in ('error','critical') else 'yellow' if sv == 'warning' else 'blue'}]{sv}: {n}[/]"
            for sv, n in by_sev.items()
        )
        inc_table = Table(title=f"Open inconsistencies ({sev_str})", title_style="bold")
        inc_table.add_column("severity")
        inc_table.add_column("file:line")
        inc_table.add_column("rule")
        inc_table.add_column("description")
        for i in inc_items[:25]:
            sev = i.get("severity", "info")
            c = "red" if sev in ("error", "critical") else "yellow" if sev == "warning" else "blue"
            loc = i.get("file_path") or "—"
            if i.get("line_number"):
                loc += f":{i['line_number']}"
            inc_table.add_row(f"[{c}]{sev}[/]", loc, i.get("rule_id", "—"), (i.get("description") or "")[:60])
        if len(inc_items) > 25:
            console.print(f"[dim]  … and {len(inc_items) - 25} more[/dim]")
        console.print(inc_table)


@app.command()
def impact(
    target: str = typer.Argument(..., help="Node id or fragment (matches via FTS)"),
    depth: int = typer.Option(3, "--depth", "-d"),
    reverse: bool = typer.Option(False, "--reverse", "-r", help="Show dependents instead of dependencies"),
    path: Path = typer.Argument(Path.cwd()),
) -> None:
    """What breaks if I change this — forward (or reverse) impact analysis."""
    with GraphEngine(path.resolve()) as engine:
        node = _resolve_node(engine, target)
        if node is None:
            console.print(f"[red]No node matches '{target}'[/red]")
            raise typer.Exit(code=1)
        console.print(f"[bold]Target:[/bold] {node['id']} [{node['kind']}] [dim]{node.get('file_path') or ''}[/dim]")

        levels = (engine.reverse_impact if reverse else engine.impact_analysis)(node["id"], max_depth=depth)
        if not levels:
            console.print("[dim]No connected nodes.[/dim]")
            return
        tree = Tree(node["id"])
        for d in sorted(levels):
            branch = tree.add(f"[cyan]depth {d}[/cyan]")
            for item in levels[d][:30]:
                target_node = engine.get_node(item["node_id"])
                label = item["node_id"]
                if target_node and target_node.get("file_path"):
                    label += f" [dim]({target_node['file_path']})[/dim]"
                branch.add(f"{label} via [yellow]{item['relation']}[/yellow]")
        console.print(tree)


@app.command()
def context(
    target: str = typer.Argument(..., help="File path or fragment"),
    path: Path = typer.Argument(Path.cwd()),
) -> None:
    """Show the minimal context needed to understand or modify a file."""
    with GraphEngine(path.resolve()) as engine:
        file_path = target
        ctx = engine.get_context(file_path)
        tree = Tree(f"[bold]{file_path}[/bold] ([cyan]{ctx['module']}[/cyan])")
        own = tree.add(f"[yellow]Own nodes[/yellow] ({len(ctx['own_nodes'])})")
        for n in ctx["own_nodes"][:15]:
            own.add(f"{n['kind']} {n['name']}")
        deps = tree.add(f"[green]Dependencies[/green] ({len(ctx['dependencies'])})")
        for d in ctx["dependencies"][:15]:
            deps.add(d)
        dependents = tree.add(f"[magenta]Dependents[/magenta] ({len(ctx['dependents'])})")
        for d in ctx["dependents"][:15]:
            dependents.add(d)
        siblings = tree.add(f"[dim]Siblings[/dim] ({len(ctx['siblings'])})")
        for s in ctx["siblings"][:10]:
            siblings.add(s)
        console.print(tree)


@app.command()
def stats(path: Path = typer.Argument(Path.cwd())) -> None:
    """Print raw graph stats as JSON."""
    with GraphEngine(path.resolve()) as engine:
        console.print_json(data=engine.get_stats())


@app.command()
def export(
    out: Path = typer.Option(Path(".neux/export.json"), "--out", "-o"),
    path: Path = typer.Argument(Path.cwd()),
) -> None:
    """Export the full graph + patterns + conventions to a JSON file."""
    root = path.resolve()
    with GraphEngine(root) as engine:
        data = engine.export_json()
    out_path = (root / out) if not out.is_absolute() else out
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(data, indent=2, default=str), encoding="utf-8")
    console.print(f"[green]Exported[/green] {out_path}")


@app.command()
def modules(path: Path = typer.Argument(Path.cwd())) -> None:
    """List project modules with their coupling scores."""
    with GraphEngine(path.resolve()) as engine:
        table = Table(title="Modules")
        for col in ("name", "layer", "nodes", "edges", "coupling"):
            table.add_column(col)
        for m in engine.get_modules():
            table.add_row(
                m["name"], m["layer"] or "-",
                str(m["node_count"]), str(m["edge_count"]),
                f"{int((m['coupling_score'] or 0) * 100)}%",
            )
        console.print(table)


@app.command()
def overview(
    as_json: bool = typer.Option(False, "--json", "-j", help="Output as JSON for machine consumption"),
    path: Path = typer.Argument(Path.cwd()),
) -> None:
    """Full project overview — same data as the dashboard Overview tab."""
    from neux.dashboard.api import overview as api_overview

    with GraphEngine(path.resolve()) as engine:
        data = api_overview(engine)

    if as_json:
        console.print_json(data=data)
        return

    s = data["stats"]
    health = data["health_score"]
    health_pct = round(health * 100)
    health_color = "green" if health >= 0.7 else "yellow" if health >= 0.4 else "red"

    console.print(Panel.fit(
        f"[bold {health_color}]HEALTH: {health_pct}%[/bold {health_color}]  ·  "
        f"compliance: {round(data['average_compliance'] * 100)}%",
        title="[bold cyan]NEUX OVERVIEW[/bold cyan]",
        border_style="cyan",
    ))

    metrics = Table(show_header=False, box=None, pad_edge=False)
    metrics.add_column(style="cyan")
    metrics.add_column(justify="right")
    metrics.add_row("Nodes", str(s["nodes"]))
    metrics.add_row("Edges", str(s["edges"]))
    metrics.add_row("Modules", str(s["modules"]))
    metrics.add_row("Patterns", f"{s['patterns_confirmed']} confirmed / {s['patterns']} total")
    metrics.add_row("Conventions", str(s["conventions"]))
    metrics.add_row("Open issues", f"[{'red' if s['inconsistencies_open'] > 0 else 'green'}]{s['inconsistencies_open']}[/]")
    metrics.add_row("Sessions", str(s["sessions"]))
    console.print(metrics)

    if data["god_nodes"]:
        console.print()
        god_table = Table(title="God nodes (high-impact)", title_style="bold")
        god_table.add_column("name")
        god_table.add_column("module", style="cyan")
        god_table.add_column("file")
        god_table.add_column("connections", justify="right")
        for g in data["god_nodes"]:
            conn = g.get("total_connections") or g.get("connections") or 0
            god_table.add_row(g["name"], g.get("module", "—"), g.get("file_path", "—"), str(conn))
        console.print(god_table)

    incs = data.get("recent_inconsistencies") or []
    if incs:
        console.print()
        inc_table = Table(title=f"Open inconsistencies (top {len(incs)})", title_style="bold")
        inc_table.add_column("severity")
        inc_table.add_column("file:line")
        inc_table.add_column("description")
        for i in incs:
            sev = i.get("severity", "info")
            sev_color = "red" if sev in ("error", "critical") else "yellow" if sev == "warning" else "blue"
            loc = (i.get("file_path") or i.get("node_id") or "—")
            if i.get("line_number"):
                loc += f":{i['line_number']}"
            inc_table.add_row(f"[{sev_color}]{sev}[/]", loc, (i.get("description") or "")[:80])
        console.print(inc_table)


@app.command()
def inconsistencies(
    status: str = typer.Option("open", "--status", "-s", help="Filter: open, resolved, all"),
    as_json: bool = typer.Option(False, "--json", "-j"),
    path: Path = typer.Argument(Path.cwd()),
) -> None:
    """List all inconsistencies with severity and location."""
    from neux.dashboard.api import inconsistencies as api_incs

    with GraphEngine(path.resolve()) as engine:
        data = api_incs(engine, status=status)

    if as_json:
        console.print_json(data=data)
        return

    console.print(f"[bold]Inconsistencies[/bold] (status={status})")
    by_sev = data.get("by_severity") or {}
    if by_sev:
        parts = []
        for sev, n in by_sev.items():
            c = "red" if sev in ("error", "critical") else "yellow" if sev == "warning" else "blue"
            parts.append(f"[{c}]{sev}: {n}[/]")
        console.print("  ".join(parts))

    if not data["items"]:
        console.print("[green]All clear — no inconsistencies.[/green]")
        return

    table = Table()
    table.add_column("severity")
    table.add_column("file:line")
    table.add_column("rule")
    table.add_column("description")
    for i in data["items"]:
        sev = i.get("severity", "info")
        c = "red" if sev in ("error", "critical") else "yellow" if sev == "warning" else "blue"
        loc = i.get("file_path") or "—"
        if i.get("line_number"):
            loc += f":{i['line_number']}"
        table.add_row(f"[{c}]{sev}[/]", loc, i.get("rule_id", "—"), (i.get("description") or "")[:80])
    console.print(table)


@app.command()
def patterns(
    status_filter: str = typer.Option(None, "--status", "-s", help="Filter: candidate, confirmed, discarded"),
    as_json: bool = typer.Option(False, "--json", "-j"),
    path: Path = typer.Argument(Path.cwd()),
) -> None:
    """List detected patterns with confidence and status."""
    from neux.dashboard.api import patterns as api_patterns

    with GraphEngine(path.resolve()) as engine:
        data = api_patterns(engine, status=status_filter)

    if as_json:
        console.print_json(data=data)
        return

    counts = data.get("counts") or {}
    console.print(f"[bold]Patterns[/bold]  " + "  ".join(f"{k}: {v}" for k, v in counts.items()))

    if not data["items"]:
        console.print("[dim]No patterns detected.[/dim]")
        return

    table = Table()
    table.add_column("id")
    table.add_column("category")
    table.add_column("status")
    table.add_column("confidence", justify="right")
    table.add_column("description")
    for p in data["items"]:
        st = p["status"]
        st_color = "green" if st == "confirmed" else "cyan" if st == "candidate" else "dim"
        table.add_row(
            p["id"], p["category"], f"[{st_color}]{st}[/]",
            f"{p['confidence']:.0%}", (p.get("description") or "")[:70],
        )
    console.print(table)


@app.command(name="god-nodes")
def god_nodes(
    min_conn: int = typer.Option(5, "--min", "-m", help="Minimum connections to qualify"),
    as_json: bool = typer.Option(False, "--json", "-j"),
    path: Path = typer.Argument(Path.cwd()),
) -> None:
    """List high-connection god nodes that need careful handling."""
    with GraphEngine(path.resolve()) as engine:
        nodes = engine.get_god_nodes(min_connections=min_conn)

    if as_json:
        console.print_json(data=nodes)
        return

    if not nodes:
        console.print("[dim]No god nodes above threshold.[/dim]")
        return

    table = Table(title=f"God nodes (≥{min_conn} connections)")
    table.add_column("name")
    table.add_column("kind")
    table.add_column("module", style="cyan")
    table.add_column("file")
    table.add_column("total", justify="right")
    table.add_column("in", justify="right")
    table.add_column("out", justify="right")
    for g in nodes:
        table.add_row(
            g["name"], g["kind"], g.get("module", "—"),
            g.get("file_path", "—"),
            str(g.get("total_connections", 0)),
            str(g.get("incoming", 0)),
            str(g.get("outgoing", 0)),
        )
    console.print(table)


@app.command()
def review(path: Path = typer.Argument(Path.cwd())) -> None:
    """Interactively confirm or discard candidate patterns and conventions."""
    with GraphEngine(path.resolve()) as engine:
        review_session(engine)


@app.command()
def rules(
    add: str = typer.Option(None, "--add", help="Add a manual rule (description)"),
    category: str = typer.Option("architecture", "--category"),
    path: Path = typer.Argument(Path.cwd()),
) -> None:
    """List or add manual rules."""
    with GraphEngine(path.resolve()) as engine:
        if add:
            import uuid
            rid = f"manual_{uuid.uuid4().hex[:8]}"
            engine.add_pattern(
                id=rid,
                category=category,
                name=rid,
                description=add,
                evidence=[{"source": "manual"}],
                confidence=1.0,
                rule_text=add,
                status="confirmed",
            )
            console.print(f"[green]Added rule[/green] {rid}")
            return

        table = Table(title="Rules")
        for col in ("id", "category", "status", "confidence", "text"):
            table.add_column(col)
        for p in engine.get_patterns():
            table.add_row(p["id"], p["category"], p["status"], f"{p['confidence']:.2f}", (p["rule_text"] or p["description"])[:80])
        console.print(table)


# ======================================================================
# Hook passthrough
# ======================================================================


@app.command()
def hook(action: str) -> None:
    """Internal: dispatch to hook handlers (used by Claude Code)."""
    from neux import hook_entry
    sys.argv = ["neux", action]
    sys.exit(hook_entry.main())


@app.command()
def serve(
    port: int = typer.Option(7777, "--port", "-p", help="Port to bind"),
    no_open: bool = typer.Option(False, "--no-open", help="Don't open a browser automatically"),
    path: Path = typer.Argument(Path.cwd()),
) -> None:
    """Launch the NEUX dashboard (React SPA + JSON API) on http://127.0.0.1:7777."""
    from neux.dashboard.server import serve as run_server
    run_server(project_root=path.resolve(), port=port, open_browser=not no_open)


# ======================================================================
# Internals
# ======================================================================


def _run_detectors(engine: GraphEngine, root: Path, stack: dict) -> list:
    files: dict[str, str] = {}
    for p in root.rglob("*"):
        if not p.is_file():
            continue
        parts = p.relative_to(root).parts
        if any(part in DEFAULT_IGNORE_DIRS for part in parts):
            continue
        if p.suffix.lower() not in {".py", ".ts", ".tsx", ".js", ".jsx", ".sql", ".css", ".scss", ".less"}:
            continue
        try:
            files[str(p.relative_to(root))] = p.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue

    nodes = [dict(r) for r in engine.conn.execute("SELECT * FROM nodes")]
    edges = [dict(r) for r in engine.conn.execute("SELECT * FROM edges")]
    ctx = DetectionContext(
        nodes=nodes, edges=edges, files=files,
        project_info={"languages": stack.get("languages", [])},
    )
    det_engine = DetectionEngine(all_detectors())
    results = det_engine.run_all(ctx)
    det_engine.persist(engine, results)
    return results


def _install_hooks(project_root: Path) -> Path | None:
    """Merge NEUX hook commands into ``.claude/settings.json`` without clobbering."""
    settings_dir = project_root / ".claude"
    settings_dir.mkdir(exist_ok=True)
    settings_file = settings_dir / "settings.json"

    current: dict = {}
    if settings_file.exists():
        try:
            current = json.loads(settings_file.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            current = {}

    hooks_section = current.setdefault("hooks", {})

    def _ensure(event_name: str, matcher: str | None, command: str) -> None:
        existing = hooks_section.setdefault(event_name, [])
        for entry in existing:
            for hook in entry.get("hooks", []):
                if hook.get("command") == command:
                    return
        new_entry = {"hooks": [{"type": "command", "command": command}]}
        if matcher:
            new_entry["matcher"] = matcher
        existing.append(new_entry)

    _ensure("PreToolUse", "Write|Edit|MultiEdit", "python -m neux.hook_entry pre-tool-use")
    _ensure("PostToolUse", "Write|Edit|MultiEdit", "python -m neux.hook_entry post-tool-use")
    _ensure("SessionStart", None, "python -m neux.hook_entry session-start")

    settings_file.write_text(json.dumps(current, indent=2), encoding="utf-8")
    return settings_file


def _resolve_node(engine: GraphEngine, target: str) -> dict | None:
    """Look up a node by exact id, then FTS, preferring real nodes over placeholders.

    Placeholders (``module_node`` kind with ``file_path IS NULL``) exist to
    satisfy FK constraints for unresolved imports — they should never win a
    tie against a real node that lives in the user's code.
    """
    node = engine.get_node(target)
    if node:
        return node
    matches = engine.search_nodes(target)
    if not matches:
        return None
    real = [m for m in matches if m.get("file_path")]
    return real[0] if real else matches[0]


if __name__ == "__main__":
    app()
