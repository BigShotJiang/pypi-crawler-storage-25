"""SecurityDetector — hardcoded secrets + unauthenticated endpoints."""

from __future__ import annotations

import re
from typing import Any

from neux.detectors.base import (
    BaseDetector,
    DetectionContext,
    DetectionResult,
    InconsistencyRecord,
)

SECRET_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    ("generic_api_key", re.compile(r"(?i)(api[_-]?key|apikey|token|secret|password)\s*[:=]\s*[\"']([A-Za-z0-9_\-]{16,})[\"']")),
    ("aws_access_key", re.compile(r"AKIA[0-9A-Z]{16}")),
    ("slack_token", re.compile(r"xox[baprs]-[A-Za-z0-9-]{10,}")),
    ("github_token", re.compile(r"ghp_[A-Za-z0-9]{36,}")),
    ("private_key", re.compile(r"-----BEGIN (RSA |EC |DSA )?PRIVATE KEY-----")),
]

AUTH_DECORATORS: set[str] = {
    "login_required", "requires_auth", "authenticated", "jwt_required",
    "require_auth", "oauth_required", "current_user", "Depends",
}


class SecurityDetector(BaseDetector):
    name = "security"
    languages = ["*"]

    def detect(self, ctx: DetectionContext) -> list[DetectionResult]:
        results: list[DetectionResult] = []
        secret_incs: list[InconsistencyRecord] = []

        for path, content in ctx.files.items():
            for line_no, line in enumerate(content.splitlines(), start=1):
                if not line.strip() or line.lstrip().startswith(("#", "//", "/*", "*")):
                    continue
                for label, pattern in SECRET_PATTERNS:
                    if pattern.search(line):
                        secret_incs.append(
                            InconsistencyRecord(
                                file_path=path,
                                line_number=line_no,
                                description=f"Hardcoded secret ({label}) detected",
                                expected="Load from environment variable",
                                actual=line.strip()[:80],
                                severity="error",
                            )
                        )
                        break

        if secret_incs:
            results.append(
                DetectionResult(
                    type="pattern",
                    category="security",
                    name="no_hardcoded_secrets",
                    description=f"{len(secret_incs)} hardcoded secrets detected",
                    confidence=1.0,
                    rule_text=(
                        "NEVER hardcode API keys, tokens, or passwords. "
                        "Read from environment variables or a secret manager."
                    ),
                    evidence=[{"count": len(secret_incs)}],
                    inconsistencies=secret_incs,
                    occurrences=len(secret_incs),
                    severity="error",
                )
            )

        unauth_endpoints = _unauth_endpoints(ctx.nodes)
        if unauth_endpoints:
            incs = [
                InconsistencyRecord(
                    file_path=n["file_path"] or "",
                    line_number=n.get("line_start"),
                    node_id=n["id"],
                    description=f"Endpoint {n['name']} has no authentication decorator",
                    severity="warning",
                )
                for n in unauth_endpoints[:50]
            ]
            results.append(
                DetectionResult(
                    type="convention",
                    category="security",
                    name="endpoints_require_auth",
                    description="HTTP endpoints should require authentication",
                    confidence=0.6,
                    compliance=0.0 if unauth_endpoints else 1.0,
                    total_instances=len(unauth_endpoints),
                    compliant_count=0,
                    rule_text=(
                        "All HTTP endpoints must be wrapped by an auth dependency "
                        "(e.g. FastAPI Depends, @login_required) unless explicitly public."
                    ),
                    inconsistencies=incs,
                    severity="warning",
                )
            )

        return results


def _unauth_endpoints(nodes: list[dict[str, Any]]) -> list[dict[str, Any]]:
    import json
    flagged: list[dict[str, Any]] = []
    for n in nodes:
        if n["kind"] != "endpoint":
            continue
        meta_raw = n.get("metadata")
        meta: dict[str, Any] = {}
        if meta_raw:
            try:
                meta = json.loads(meta_raw) if isinstance(meta_raw, str) else meta_raw
            except (json.JSONDecodeError, TypeError):
                meta = {}
        decorators = meta.get("decorators", []) if isinstance(meta, dict) else []
        if not any(any(tok in d for tok in AUTH_DECORATORS) for d in decorators):
            flagged.append(n)
    return flagged
