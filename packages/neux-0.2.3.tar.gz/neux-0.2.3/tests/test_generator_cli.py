"""Generator + CLI integration tests."""

from __future__ import annotations

import json
from pathlib import Path

from typer.testing import CliRunner

from neux.categorizer import TaskCategorizer
from neux.cli import app
from neux.engine import GraphEngine
from neux.generator.claude_md import generate_all
from neux.scanner import ProjectScanner

runner = CliRunner()


def test_categorizer_picks_style_change() -> None:
    cat = TaskCategorizer().categorize("cambiar el color del boton", "components/Button.tsx")
    assert cat.category == "style_change"


def test_categorizer_falls_back_to_general() -> None:
    cat = TaskCategorizer().categorize("", "")
    assert cat.category == "general"


def test_generator_writes_claude_md(mixed_project: Path) -> None:
    engine = GraphEngine(mixed_project)
    ProjectScanner(engine).scan_project(mixed_project)
    written = generate_all(mixed_project, engine)
    engine.close()
    assert (mixed_project / "CLAUDE.md").exists()
    assert "CLAUDE.md" in written
    assert (mixed_project / ".neux" / "modules").exists()


def test_cli_init_idempotent(mixed_project: Path) -> None:
    result1 = runner.invoke(app, ["init", str(mixed_project)])
    assert result1.exit_code == 0, result1.output
    result2 = runner.invoke(app, ["init", str(mixed_project)])
    assert result2.exit_code == 0, result2.output

    settings = json.loads((mixed_project / ".claude" / "settings.json").read_text())
    for event in ("PreToolUse", "PostToolUse", "SessionStart"):
        assert len(settings["hooks"][event]) == 1


def test_cli_status_runs(mixed_project: Path) -> None:
    runner.invoke(app, ["init", str(mixed_project)])
    result = runner.invoke(app, ["status", str(mixed_project)])
    assert result.exit_code == 0
    assert "NEUX graph" in result.output


def test_cli_impact_resolves_and_walks(mixed_project: Path) -> None:
    runner.invoke(app, ["init", str(mixed_project)])
    result = runner.invoke(app, ["impact", "list_users", str(mixed_project)])
    assert result.exit_code == 0


def test_cli_export_dumps_json(mixed_project: Path) -> None:
    runner.invoke(app, ["init", str(mixed_project)])
    result = runner.invoke(app, ["export", str(mixed_project)])
    assert result.exit_code == 0
    assert (mixed_project / ".neux" / "export.json").exists()
