"""Ressources de l'API Cauris."""

from __future__ import annotations
from dataclasses import dataclass


@dataclass
class Charge:
    """Représente un paiement Mobile Money."""

    id: str
    status: str
    payment_url: str | None = None

    @staticmethod
    def create(
        amount: int,
        phone: str,
        currency: str = "XAF",
        notify_url: str | None = None,
        metadata: dict | None = None,
    ) -> Charge:
        """Initie un paiement.

        Args:
            amount: Montant en unité minimale (ex: 5000 = 5000 XAF).
            phone: Numéro de téléphone au format international (ex: "237691234567").
            currency: Devise (défaut: "XAF").
            notify_url: URL de callback quand le paiement est confirmé.
            metadata: Données supplémentaires libres.

        Returns:
            Charge avec id, status et payment_url.
        """
        import cauris

        data = {
            "amount": amount,
            "phone_number": phone,
            "currency": currency,
        }
        if notify_url:
            data["notify_url"] = notify_url
        if metadata:
            data["metadata"] = metadata

        resp = cauris._get_client().post("/v1/charges", data)
        return Charge(
            id=resp["id"],
            status=resp["status"],
            payment_url=resp.get("payment_url"),
        )

    @staticmethod
    def retrieve(charge_id: str) -> Charge:
        """Récupère l'état d'un paiement.

        Args:
            charge_id: L'ID de la charge retourné par create().

        Returns:
            Charge avec le status mis à jour.
        """
        import cauris

        resp = cauris._get_client().get(f"/v1/charges/{charge_id}")
        return Charge(
            id=resp["id"],
            status=resp["status"],
            payment_url=resp.get("payment_url"),
        )
