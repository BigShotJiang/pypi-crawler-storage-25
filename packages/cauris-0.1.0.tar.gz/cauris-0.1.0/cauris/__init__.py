"""Cauris — API de paiement Mobile Money pour l'Afrique."""

from cauris.client import CaurisClient
from cauris.resources import Charge

__version__ = "0.1.0"

# Clé API globale — le dev la set une seule fois
api_key: str = ""
base_url: str = "https://api.cauris.dev"

# Client partagé
_client: CaurisClient | None = None


def _get_client() -> CaurisClient:
    global _client
    if _client is None or _client.api_key != api_key:
        _client = CaurisClient(api_key=api_key, base_url=base_url)
    return _client
