"""Client HTTP pour l'API Cauris."""

import requests


class CaurisError(Exception):
    """Erreur retournée par l'API Cauris."""

    def __init__(self, message: str, status_code: int = 0):
        self.message = message
        self.status_code = status_code
        super().__init__(self.message)


class CaurisClient:
    """Client bas niveau — gère les appels HTTP vers l'API."""

    def __init__(self, api_key: str, base_url: str):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "User-Agent": "cauris-python/0.1.0",
        })

    def post(self, path: str, data: dict) -> dict:
        url = f"{self.base_url}{path}"
        resp = self.session.post(url, json=data)
        return self._handle_response(resp)

    def get(self, path: str) -> dict:
        url = f"{self.base_url}{path}"
        resp = self.session.get(url)
        return self._handle_response(resp)

    def _handle_response(self, resp: requests.Response) -> dict:
        body = resp.json()
        if resp.status_code >= 400:
            raise CaurisError(
                message=body.get("error", "unknown error"),
                status_code=resp.status_code,
            )
        return body
