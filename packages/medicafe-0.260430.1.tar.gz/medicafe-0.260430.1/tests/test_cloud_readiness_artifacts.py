﻿#!/usr/bin/env python
"""
Unit tests for MediCafe.cloud_readiness.
Tests evidence selection, run_phase_f_manual, run_phase_f_manual_for_run_id, is_pipeline_running.
"""
from __future__ import print_function

import json
import os
import sqlite3
import sys
import tempfile
import time
import unittest

try:
    from unittest.mock import patch, MagicMock
except ImportError:
    from mock import patch, MagicMock  # pyright: ignore[reportMissingModuleSource]

_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)


def _make_lab():
    """Create temp lab dir with reports."""
    lab_root = tempfile.mkdtemp()
    reports_dir = os.path.join(lab_root, 'reports')
    os.makedirs(reports_dir, exist_ok=True)
    return lab_root, reports_dir


class TestSystemHealthRunbookPerf(unittest.TestCase):
    def test_system_health_pack_runbook_reuses_dat_focus_lines(self):
        from MediCafe import cloud_readiness_runbooks as runbooks
        calls = []

        def fake_dat_focus_lines(state, lab_root=None, repo_root_hint=''):
            calls.append((state, lab_root, repo_root_hint))
            return [' - dat_focus_snapshot=selected:1, qa_pass:0, qa_reject:1, canonical:0, pass_rate:0.000']

        with tempfile.TemporaryDirectory() as lab_root:
            with patch.object(runbooks, '_build_dat_qa_focus_lines', side_effect=fake_dat_focus_lines):
                lines = runbooks.build_system_health_pack_runbook(
                    lab_root,
                    {'overall': {'status': 'warn'}, 'migration_stage': 'xp_validation'},
                    {'repo_root': os.path.dirname(lab_root)},
                    parse_iso_utc_epoch_fn=lambda _value: None,
                    load_json_dict_fn=lambda _path: {'last_shadow_pipeline_outcome': 'completed'},
                    state_override={'last_phase_d_dat_telemetry': {'dat_selected_count': 1}},
                    pack_scope='completed_run',
                    anchor_run_id='20260415-232243-0b19e55a')
        self.assertEqual(len(calls), 1)
        self.assertIn(' - dat_focus_snapshot=selected:1, qa_pass:0, qa_reject:1, canonical:0, pass_rate:0.000', lines)
        self.assertIn(' - Track dat_focus_snapshot and dat_reject_mix_top deltas across consecutive health packs.', lines)


class TestSystemHealthPackWiring(unittest.TestCase):
    def test_unified_db_readiness_lines_grade_live_shallow_db_pattern(self):
        from MediCafe import cloud_readiness as cr
        snap = {
            'ok': True,
            'counts': {
                'patient': 5825,
                'coverage': 0,
                'encounter': 0,
                'claim': 0,
                'claim_line': 0,
            },
            'patient_count_effective': 2803,
            'patient_latest_identity_count': 2803,
            'qa_reject_count_effective': 840,
            'replay_pending_count': 840,
            'projection_success_count_effective': 19715,
            'projection_reject_count_effective': 0,
        }
        summary = {
            'ok': True,
            'canonical_type_counts': {
                'patient_csv_row': 12035,
                'docx_schedule': 7679,
                'dat_record': 0,
            },
            'csv_docx_join': {
                'csv_join_key_count': 4781,
                'docx_join_key_count': 4039,
                'overlap_join_key_count': 3797,
                'csv_only_join_key_count': 984,
                'docx_only_join_key_count': 242,
            },
        }
        state = {
            'last_phase_d_csv_docx_join_telemetry': {
                'matched_count': 0,
                'csv_only_count': 140,
                'docx_only_count': 0,
                'ambiguous_count': 1,
            },
            'last_phase_d_dat_csv_join_telemetry': {
                'matched_count': 0,
                'invalid_external_id_csv_count': 137,
            },
            'last_phase_d_constraint_skip_counts': {
                'patient_invalid_external_id': 99,
            },
            'last_phase_d_dat_telemetry': {
                'dat_selected_count': 1,
                'dat_qa_pass_count': 0,
                'dat_qa_reject_count': 1,
                'dat_canonical_record_count': 0,
                'dat_field_presence_by_alias': {'records_seen': 0},
                'dat_qa_reject_counts_by_reason': {
                    'QA_ARTIFACT_CLASS_REQUIRED_FIELDS': 1,
                },
            },
        }
        with patch.object(cr, '_collect_db_enrichment_summary', return_value=summary):
            lines = cr._build_unified_db_readiness_lines('/lab', snapshot=snap, diagnostics_state=state)
        text = '\n'.join(lines)
        self.assertIn('Unified DB Readiness:', text)
        self.assertIn('overall=blocked', text)
        self.assertIn('blockers=dat_selected_but_not_integrated,relational_chain_shallow,quality_backlog_active,invalid_external_patient_ids', text)
        self.assertIn('patient_identity=patient_count:2803, raw_patient_rows:5825, duplicate_identity_rows:3022, projection_success:19715', text)
        self.assertIn('cross_source_csv_docx=cumulative_overlap_keys:3797', text)
        self.assertIn('latest_matched:0', text)
        self.assertIn('dat_integration=selected:1, records_seen:0, qa_pass:0, qa_reject:1, canonical:0, dat_csv_matched:0, invalid_external_id_csv:137', text)
        self.assertIn('relational_depth=coverage:0, encounter:0, claim:0, claim_line:0', text)
        self.assertIn('quality_backlog=qa_reject:840, replay_pending:840, patient_invalid_external_id_skips:99', text)
        self.assertIn('parser_parity=production_parser_status:dat_selected_zero_records', text)
        self.assertIn('migration_guidance=not_gcp_ready', text)

    def test_system_health_pack_includes_unified_db_readiness_section(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            audit_json = os.path.join(reports, 'audit_migration_health_summary_latest.json')
            with open(audit_json, 'w', encoding='utf-8') as f:
                json.dump({'overall': {'status': 'warn'}, 'generated_at_utc': '2026-04-24T00:00:00Z'}, f)
            audit_txt = os.path.join(reports, 'audit_migration_health_summary_latest.txt')
            with open(audit_txt, 'w', encoding='utf-8') as f:
                f.write('summary')
            shadow_json = os.path.join(reports, 'shadow_run_report_rid-db.json')
            with open(shadow_json, 'w', encoding='utf-8') as f:
                json.dump({'run_id': 'rid-db'}, f)
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({'pipeline_state': 'completed', 'last_shadow_pipeline_run_id': 'rid-db'}, f)
            with patch.object(cr, '_collect_system_health_artifacts', return_value={
                'lab_root': lab,
                'reports_dir': reports,
                'consolidated_ok': True,
                'consolidated_message': '',
                'consolidated_path': '',
                'audit_summary_txt': audit_txt,
                'audit_summary_json': audit_json,
                'audit_metrics_json': '',
                'shadow_report_path': shadow_json,
                'shadow_index_path': '',
                'phase_f_mismatch_path': '',
                'delivery_status_path': '',
            }):
                with patch.object(cr, 'get_health_lines', return_value=['health-line']):
                    with patch.object(cr, '_collect_data_plane_snapshot', return_value={'ok': True, 'counts': {}, 'patient_count_effective': 0}):
                        with patch.object(cr, '_build_db_enrichment_overview_lines', return_value=['DB enrichment overview (cumulative lab state):', ' - stub']):
                            with patch.object(cr, '_build_unified_db_readiness_lines', return_value=['Unified DB Readiness:', ' - overall=blocked score=0/100 blockers=test']):
                                ok, msg, path = cr.open_latest_system_health_pack(
                                    repo, lambda name, default: default, include_delivery_status=False)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('DB enrichment overview (cumulative lab state):', text)
            self.assertIn('Unified DB Readiness:', text)
            self.assertIn('overall=blocked score=0/100 blockers=test', text)
            self.assertIn('Data plane snapshot (cumulative lab state):', text)

    def test_run_system_health_triage_returns_hints_and_artifacts(self):
        from MediCafe import cloud_readiness as cr
        with patch.object(cr, 'run_migration_health_audit', return_value=(
            True,
            'Audit completed with status=warn, score=80, exit_code=0',
            {'hints': ['h1']},
        )):
            with patch.object(cr, 'open_latest_system_health_pack', return_value=(
                True,
                '',
                '/repo/lab/reports/system_health_pack_latest.txt',
            )):
                with patch.object(cr, 'open_latest_migration_health_report', return_value=(
                    True,
                    '',
                    '/repo/lab/reports/audit_migration_health_summary_latest.txt',
                )):
                    ok, msg, data = cr.run_system_health_triage(
                        '/repo',
                        '/py',
                        {},
                        lambda name, default: default,
                        scope='both',
                        cloud_required=False,
                    )
        self.assertTrue(ok)
        self.assertIn('System health triage', msg)
        self.assertTrue(isinstance(data, dict))
        self.assertEqual(data.get('hints'), ['h1'])
        self.assertTrue('/repo/lab/reports/system_health_pack_latest.txt' in data.get('artifacts', []))
        self.assertTrue('/repo/lab/reports/audit_migration_health_summary_latest.txt' in data.get('artifacts', []))
        self.assertTrue(isinstance(data.get('runbook', {}), dict))
        self.assertTrue(isinstance(data.get('runbook_lines', []), list))
        self.assertIn('decision', data.get('runbook', {}))

    def test_send_latest_system_health_pack_includes_pack_and_delivery(self):
        from MediCafe import cloud_readiness as cr
        artifacts = {
            'delivery_status_path': '/lab/reports/report_delivery_status.txt',
            'consolidated_path': '/lab/reports/consolidated_health_snapshot.txt',
            'audit_summary_txt': '/lab/reports/audit_migration_health_summary_latest.txt',
            'audit_summary_json': '/lab/reports/audit_migration_health_summary_latest.json',
            'audit_metrics_json': '/lab/reports/audit_migration_health_metrics_latest.json',
            'phase_f_mismatch_path': '/lab/reports/phase_f_mismatch_latest.txt',
        }
        with patch.object(cr, 'resolve_lab_root', return_value='/lab'):
            with patch.object(cr, '_reports_dir_access_error', return_value=None):
                with patch.object(cr, 'open_latest_system_health_pack', return_value=(
                    True,
                    '',
                    '/lab/reports/system_health_pack_latest.txt',
                )):
                    with patch.object(cr, '_collect_system_health_artifacts', return_value=artifacts):
                        with patch.object(cr, '_select_latest_evidence_files', return_value=[
                            ('shadow_run_report_latest.txt', '/lab/reports/shadow_run_report_latest.txt'),
                        ]):
                            with patch.object(cr, '_collect_delivery_diagnostics', return_value={}):
                                with patch.object(cr, 'collect_support_bundle', return_value='/tmp/bundle.zip') as mock_collect:
                                    with patch.object(cr, '_submit_bundle_with_delivery_diagnostics', return_value=(True, '', {})):
                                        with patch('MediCafe.cloud_readiness.os.path.isfile', return_value=True):
                                            ok, msg, data = cr.send_latest_system_health_pack(
                                                '/repo',
                                                lambda name, default: default,
                                            )
        self.assertTrue(ok)
        self.assertEqual(msg, '')
        self.assertEqual(data.get('delivery_status_path'), '/lab/reports/report_delivery_status.txt')
        meta = mock_collect.call_args[1].get('extra_meta', {})
        self.assertTrue(meta.get('system_health_pack'))
        self.assertEqual(meta.get('send_source'), 'manual_system_health_pack')
        self.assertEqual(meta.get('operator_execution_mode'), 'explicit_send_menu')
        extra_files = mock_collect.call_args[1].get('extra_files', [])
        basenames = [item[0] for item in extra_files]
        self.assertIn('system_health_pack_latest.txt', basenames)
        self.assertIn('report_delivery_status.txt', basenames)
        self.assertTrue(isinstance(data.get('pre_send_runbook_lines', []), list))
        self.assertTrue(len(data.get('pre_send_runbook_lines', [])) > 0)

    def test_send_latest_system_health_pack_stamps_follow_recommendation_meta(self):
        from MediCafe import cloud_readiness as cr
        artifacts = {
            'delivery_status_path': '/lab/reports/report_delivery_status.txt',
            'consolidated_path': '/lab/reports/consolidated_health_snapshot.txt',
            'audit_summary_txt': '/lab/reports/audit_migration_health_summary_latest.txt',
            'audit_summary_json': '/lab/reports/audit_migration_health_summary_latest.json',
            'audit_metrics_json': '/lab/reports/audit_migration_health_metrics_latest.json',
            'phase_f_mismatch_path': '/lab/reports/phase_f_mismatch_latest.txt',
        }
        recommendation = {
            'recommended_action_kind': 'send_bundle',
            'preferred_when_stable_action_kind': 'send_bundle',
            'best_now_action_kind': 'send_bundle',
            'recommended_report_kind': 'system_health_pack',
            'primary_send': 'run_evidence',
            'preferred_when_stable': 'run_evidence',
            'best_now_send': 'system_health',
            'pipeline_running': True,
            'summary_line': 'Recommended: send latest System Health Pack.',
        }
        with patch.object(cr, 'resolve_lab_root', return_value='/lab'):
            with patch.object(cr, '_reports_dir_access_error', return_value=None):
                with patch.object(cr, 'open_latest_system_health_pack', return_value=(
                    True,
                    '',
                    '/lab/reports/system_health_pack_latest.txt',
                )):
                    with patch.object(cr, '_collect_system_health_artifacts', return_value=artifacts):
                        with patch.object(cr, '_select_latest_evidence_files', return_value=[]):
                            with patch.object(cr, '_collect_delivery_diagnostics', return_value={}):
                                with patch.object(cr, 'collect_support_bundle', return_value='/tmp/bundle.zip') as mock_collect:
                                    with patch.object(cr, '_submit_bundle_with_delivery_diagnostics', return_value=(True, '', {})):
                                        with patch('MediCafe.cloud_readiness.os.path.isfile', return_value=True):
                                            ok, msg, _data = cr.send_latest_system_health_pack(
                                                '/repo',
                                                lambda name, default: default,
                                                recommendation=recommendation,
                                                send_source='follow_rec_system_health',
                                                operator_execution_mode='follow_recommendation',
                                            )
        self.assertTrue(ok)
        self.assertEqual(msg, '')
        meta = mock_collect.call_args[1].get('extra_meta', {})
        self.assertEqual(meta.get('send_source'), 'follow_rec_system_health')
        self.assertEqual(meta.get('operator_execution_mode'), 'follow_recommendation')
        self.assertEqual(meta.get('operator_primary_report_surface'), 'system_health_pack')
        self.assertEqual(meta.get('follow_recommendation_now'), 'send_system_health_pack')
        self.assertEqual(meta.get('follow_recommendation_when_stable'), 'send_run_evidence_bundle')
    def test_send_latest_system_health_pack_includes_current_run_companions_and_lock_diag(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            current_run_id = 'rid-current'
            pack_path = os.path.join(reports, 'system_health_pack_latest.txt')
            with open(pack_path, 'w', encoding='utf-8') as f:
                f.write('pack')
            with open(os.path.join(reports, 'consolidated_health_snapshot.txt'), 'w', encoding='utf-8') as f:
                f.write('consolidated')
            with open(os.path.join(reports, 'audit_migration_health_summary_latest.txt'), 'w', encoding='utf-8') as f:
                f.write('summary txt')
            with open(os.path.join(reports, 'audit_migration_health_summary_latest.json'), 'w', encoding='utf-8') as f:
                f.write('{}')
            with open(os.path.join(reports, 'audit_migration_health_metrics_latest.json'), 'w', encoding='utf-8') as f:
                f.write('{}')
            with open(os.path.join(reports, 'report_delivery_status.txt'), 'w', encoding='utf-8') as f:
                f.write('delivery')
            older_shadow = os.path.join(reports, 'shadow_run_report_latest.txt')
            with open(older_shadow, 'w', encoding='utf-8') as f:
                f.write('older')
            lock_diag = os.path.join(reports, 'phase_f_lock_diag_{0}_20260323T143753Z.json'.format(current_run_id))
            with open(lock_diag, 'w', encoding='utf-8') as f:
                json.dump({'reason': 'acquire_system_exit'}, f)
            diagnostics_state_path = os.path.join(lab, 'diagnostics_state.json')
            with open(diagnostics_state_path, 'w', encoding='utf-8') as f:
                json.dump({
                    'last_shadow_pipeline_run_id': current_run_id,
                    'last_phase_f_lock_diag_path': lock_diag,
                }, f)
            current_files = []
            for name in (
                    'artifact_discovery_summary_BRID.json',
                    'ingest_write_summary_CRID.json',
                    'qa_canonical_summary_DRID.json',
                    'projection_parity_summary_ERID.json',
                    'shadow_run_report_{0}.json'.format(current_run_id),
                    'shadow_evidence_index_{0}.json'.format(current_run_id)):
                path_current = os.path.join(reports, name)
                with open(path_current, 'w', encoding='utf-8') as f:
                    f.write('{}')
                current_files.append(path_current)
            run_cursor = os.path.join(lab, 'run_cursor.json')
            with open(run_cursor, 'w', encoding='utf-8') as f:
                f.write('{}')
            artifacts = {
                'delivery_status_path': os.path.join(reports, 'report_delivery_status.txt'),
                'consolidated_path': os.path.join(reports, 'consolidated_health_snapshot.txt'),
                'audit_summary_txt': os.path.join(reports, 'audit_migration_health_summary_latest.txt'),
                'audit_summary_json': os.path.join(reports, 'audit_migration_health_summary_latest.json'),
                'audit_metrics_json': os.path.join(reports, 'audit_migration_health_metrics_latest.json'),
                'phase_f_mismatch_path': '',
            }
            snapshot = {
                'artifact_files': current_files,
                'context_files': [diagnostics_state_path, run_cursor],
            }
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                with patch.object(cr, '_reports_dir_access_error', return_value=None):
                    with patch.object(cr, 'open_latest_system_health_pack', return_value=(True, '', pack_path)):
                        with patch.object(cr, '_collect_system_health_artifacts', return_value=artifacts):
                            with patch.object(cr, '_select_latest_evidence_files', return_value=[
                                ('shadow_run_report_latest.txt', older_shadow),
                            ]):
                                with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snapshot)):
                                    with patch.object(cr, '_collect_delivery_diagnostics', return_value={}):
                                        with patch.object(cr, 'collect_support_bundle', return_value='/tmp/bundle.zip') as mock_collect:
                                            with patch.object(cr, '_submit_bundle_with_delivery_diagnostics', return_value=(True, '', {})):
                                                ok, msg, data = cr.send_latest_system_health_pack(
                                                    repo,
                                                    lambda name, default: default,
                                                )
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            extra_files = mock_collect.call_args[1].get('extra_files', [])
            basenames = [item[0] for item in extra_files]
            self.assertIn(os.path.basename(lock_diag), basenames)
            self.assertIn('artifact_discovery_summary_BRID.json', basenames)
            self.assertIn('ingest_write_summary_CRID.json', basenames)
            self.assertIn('qa_canonical_summary_DRID.json', basenames)
            self.assertIn('projection_parity_summary_ERID.json', basenames)
            self.assertIn('shadow_run_report_{0}.json'.format(current_run_id), basenames)
            self.assertIn('shadow_evidence_index_{0}.json'.format(current_run_id), basenames)
            self.assertTrue(isinstance(data.get('pre_send_runbook_lines', []), list))

    def test_collect_system_health_artifacts_prefers_diagnostics_anchored_phase_f_files(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rid_current = 'rid-current'
            rid_stale = 'rid-stale'
            stale_report = os.path.join(reports, 'shadow_run_report_{0}.json'.format(rid_stale))
            stale_index = os.path.join(reports, 'shadow_evidence_index_{0}.json'.format(rid_stale))
            stale_mismatch = os.path.join(reports, 'phase_f_mismatch_{0}.txt'.format(rid_stale))
            current_report = os.path.join(reports, 'shadow_run_report_{0}.json'.format(rid_current))
            current_index = os.path.join(reports, 'shadow_evidence_index_{0}.json'.format(rid_current))
            current_mismatch = os.path.join(reports, 'phase_f_mismatch_{0}.txt'.format(rid_current))
            for path in (stale_report, stale_index, stale_mismatch, current_report, current_index, current_mismatch):
                with open(path, 'w', encoding='utf-8') as f:
                    f.write('{}' if path.endswith('.json') else 'mismatch')
            newer = time.time() + 120
            for path in (stale_report, stale_index, stale_mismatch):
                os.utime(path, (newer, newer))
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'completed',
                    'active_run_id': '',
                    'last_shadow_pipeline_run_id': rid_current,
                }, f)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                with patch.object(cr, 'open_consolidated_health_report', return_value=(True, '', '')):
                    artifacts = cr._collect_system_health_artifacts(
                        repo,
                        lambda _name, default: default,
                        include_delivery_status=False,
                    )
            self.assertEqual(artifacts.get('shadow_report_path'), current_report)
            self.assertEqual(artifacts.get('shadow_index_path'), current_index)
            self.assertEqual(artifacts.get('phase_f_mismatch_path'), current_mismatch)

    def test_open_latest_system_health_pack_includes_runbook_section(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            json_dir = os.path.join(repo, 'json')
            os.makedirs(reports)
            os.makedirs(json_dir)
            with open(os.path.join(json_dir, 'config.json'), 'w', encoding='utf-8') as f:
                json.dump(
                    {
                        'MediLink_Config': {
                            'fixedWidthSlices': {
                                'service_slices': {
                                    'DATE1': [0, 10],
                                    'DOS': [10, 20],
                                    'CPT': [20, 25],
                                }
                            }
                        }
                    },
                    f,
                )
            with open(os.path.join(json_dir, 'crosswalk.json'), 'w', encoding='utf-8') as f:
                json.dump(
                    {
                        'mains_mapping': {
                            'slices': {
                                'DATE1': [0, 10],
                                'PROC': [10, 15],
                            }
                        }
                    },
                    f,
                )
            with open(os.path.join(reports, 'audit_migration_health_summary_latest.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'overall': {'status': 'warn'},
                    'generated_at_utc': '2026-02-19T00:00:00Z',
                    'degradations': [{'surface': 'cloud', 'reason': 'firestore_unavailable'}],
                }, f)
            with open(os.path.join(reports, 'audit_migration_health_summary_latest.txt'), 'w', encoding='utf-8') as f:
                f.write('summary')
            shadow_json = os.path.join(reports, 'shadow_run_report_rid-b.json')
            with open(shadow_json, 'w', encoding='utf-8') as f:
                json.dump({
                    'machine_hostname': 'XP-CLIENT-01',
                    'machine_app_version': '0.260326.1',
                    'machine_python_version': '3.4.4',
                    'machine_platform': 'Windows-XP',
                    'machine_test_mode': False,
                }, f)
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump(
                    {
                        'pipeline_state': 'running',
                        'active_run_id': 'rid-a',
                        'last_shadow_pipeline_run_id': 'rid-b',
                        'last_discovery_dat_telemetry': {
                            'dat_manifest_rows_count': 389,
                            'dat_configured_root_missing_count': 1,
                            'dat_selected_root_source_id': 'dat_cfg_1',
                            'dat_selection_mode': 'configured',
                        },
                        'last_phase_d_dat_telemetry': {
                            'dat_selected_count': 389,
                            'dat_qa_pass_count': 0,
                            'dat_qa_reject_count': 389,
                            'dat_canonical_record_count': 0,
                            'dat_field_presence_by_alias': {
                                'records_seen': 389,
                                'PATID': 382,
                                'patient_id': 0,
                                'DOS': 0,
                                'DATE1': 9,
                                'date_of_service': 0,
                                'PAYERID': 370,
                                'INSID': 12,
                                'payer_id': 0,
                            },
                            'dat_qa_reject_counts_by_reason': {
                                'QA_DAT_DATE_OF_SERVICE_MISSING': 370,
                                'QA_ARTIFACT_CLASS_REQUIRED_FIELDS': 12,
                                'QA_DAT_PATIENT_ANCHOR_MISSING': 7,
                            },
                        },
                    },
                    f,
                )
            with patch.object(cr, '_collect_system_health_artifacts', return_value={
                'lab_root': lab,
                'reports_dir': reports,
                'consolidated_ok': True,
                'consolidated_message': '',
                'consolidated_path': '',
                'audit_summary_txt': os.path.join(reports, 'audit_migration_health_summary_latest.txt'),
                'audit_summary_json': os.path.join(reports, 'audit_migration_health_summary_latest.json'),
                'audit_metrics_json': '',
                'shadow_report_path': shadow_json,
                'shadow_index_path': '',
                'phase_f_mismatch_path': '',
                'delivery_status_path': '',
            }):
                with patch.object(cr, 'get_health_lines', return_value=['health-line']):
                    ok, msg, path = cr.open_latest_system_health_pack(
                        repo, lambda name, default: default, include_delivery_status=False)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            assert isinstance(path, str)
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('machine_fingerprint=host:XP-CLIENT-01, app_version:0.260326.1, python:3.4.4, platform:Windows-XP, test_mode:False', text)
            self.assertIn('pack_anchor_run_id=rid-b', text)
            self.assertIn('pack_scope=mixed_scope', text)
            self.assertIn('Anchored completed-run snapshot:', text)
            self.assertIn('System Health Runbook:', text)
            self.assertIn('Data plane snapshot (cumulative lab state):', text)
            self.assertIn('Note: phase detail rows B..E reflect per-run summary counts from the live diagnostics state file', text)
            self.assertIn('run_alignment=active_differs_from_last', text)
            self.assertIn('cloud_degraded_mode=True', text)
            self.assertIn('cloud_degradation_reasons=firestore_unavailable', text)
            self.assertIn('dat_focus_snapshot=selected:389, qa_pass:0, qa_reject:389, canonical:0, pass_rate:0.000', text)
            self.assertIn(
                'dat_discovery_snapshot=manifest_rows:389, selected_root:dat_cfg_1, selection_mode:configured, missing_configured_roots:1',
                text,
            )
            self.assertIn(
                'dat_parser_slice_snapshot=config_service(DOS:True,DATE1:True,DATE:False,count:3), crosswalk_mains(DOS:False,DATE1:True,DATE:False,count:2)',
                text,
            )
            self.assertIn(
                'dat_alias_presence=records:389, PATID:382, patient_id:0, DOS:0, DATE1:9, DATE:0, date_of_service:0, PAYERID:370, INSID:12, payer_id:0',
                text,
            )
            self.assertIn('dat_reject_mix_top=QA_DAT_DATE_OF_SERVICE_MISSING:370(0.951)', text)
            self.assertIn('next_health_focus=dat_qa_full_block', text)
            self.assertIn(
                'next_health_target=drive dat_qa_pass_count>0 and dat_canonical_record_count>0 for the next run',
                text,
            )
            self.assertIn('dat_failure_mode_hypothesis=date_alias_or_slice_mismatch_high', text)
            self.assertIn(
                'next_health_target=confirm alias presence trends vs reject mix (DOS/DATE1/DATE, PATID/patient_id, PAYERID/INSID)',
                text,
            )
            self.assertIn(
                'Track dat_focus_snapshot and dat_reject_mix_top deltas across consecutive health packs.',
                text,
            )
            self.assertIn('Open cloud degraded validation runbook: docs/runbooks/Cloud_Readiness_Cloud_Degraded_Validation.md', text)
            self.assertIn('Check (firestore_unavailable):', text)

    def test_open_latest_system_health_pack_includes_phase_f_lock_context(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            audit_json = os.path.join(reports, 'audit_migration_health_summary_latest.json')
            with open(audit_json, 'w', encoding='utf-8') as f:
                json.dump({'overall': {'status': 'fail'}, 'generated_at_utc': '2026-02-19T00:00:00Z'}, f)
            audit_txt = os.path.join(reports, 'audit_migration_health_summary_latest.txt')
            with open(audit_txt, 'w', encoding='utf-8') as f:
                f.write('summary')
            lock_diag = os.path.join(reports, 'phase_f_lock_diag_rid-lock_20260323T143753Z.json')
            with open(lock_diag, 'w', encoding='utf-8') as f:
                json.dump({
                    'reason': 'acquire_system_exit',
                    'lock_owner_running': True,
                    'lock_heartbeat_stale': False,
                    'lock_pid': '4321',
                }, f)
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'failed',
                    'last_shadow_pipeline_run_id': 'rid-lock',
                    'last_shadow_pipeline_error_code': 'PHASE_F_LOCK_FAIL',
                    'last_phase_f_lock_diag_path': lock_diag,
                }, f)
            with patch.object(cr, '_collect_system_health_artifacts', return_value={
                'lab_root': lab,
                'reports_dir': reports,
                'consolidated_ok': True,
                'consolidated_message': '',
                'consolidated_path': '',
                'audit_summary_txt': audit_txt,
                'audit_summary_json': audit_json,
                'audit_metrics_json': '',
                'shadow_report_path': '',
                'shadow_index_path': '',
                'phase_f_mismatch_path': '',
                'delivery_status_path': '',
            }):
                with patch.object(cr, 'get_health_lines', return_value=['health-line']):
                    ok, msg, pack_path = cr.open_latest_system_health_pack(
                        repo, lambda name, default: default, include_delivery_status=False)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            with open(pack_path, 'r', encoding='utf-8') as f:
                report_text = f.read()
            self.assertIn('Phase F lock context: reason=acquire_system_exit, owner_running=True, heartbeat_stale=False, pid=4321, diag=phase_f_lock_diag_rid-lock_20260323T143753Z.json', report_text)

    def test_open_latest_system_health_pack_uses_repo_json_when_lab_is_external(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            with tempfile.TemporaryDirectory() as external_lab:
                reports = os.path.join(external_lab, 'reports')
                json_dir = os.path.join(repo, 'json')
                os.makedirs(reports)
                os.makedirs(json_dir)
                with open(os.path.join(json_dir, 'config.json'), 'w', encoding='utf-8') as f:
                    json.dump(
                        {
                            'MediLink_Config': {
                                'fixedWidthSlices': {
                                    'service_slices': {
                                        'DATE1': [0, 10],
                                        'DOS': [10, 20],
                                    }
                                }
                            }
                        },
                        f,
                    )
                with open(os.path.join(json_dir, 'crosswalk.json'), 'w', encoding='utf-8') as f:
                    json.dump(
                        {
                            'mains_mapping': {
                                'slices': {
                                    'DATE1': [0, 10],
                                }
                            }
                        },
                        f,
                    )
                with open(os.path.join(reports, 'audit_migration_health_summary_latest.json'), 'w', encoding='utf-8') as f:
                    json.dump(
                        {
                            'overall': {'status': 'warn'},
                            'generated_at_utc': '2026-02-19T00:00:00Z',
                        },
                        f,
                    )
                with open(os.path.join(reports, 'audit_migration_health_summary_latest.txt'), 'w', encoding='utf-8') as f:
                    f.write('summary')
                with open(os.path.join(external_lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                    json.dump(
                        {
                            'last_phase_d_dat_telemetry': {
                                'dat_selected_count': 10,
                                'dat_qa_pass_count': 0,
                                'dat_qa_reject_count': 10,
                                'dat_canonical_record_count': 0,
                                'dat_qa_reject_counts_by_reason': {
                                    'QA_DAT_DATE_OF_SERVICE_MISSING': 10,
                                },
                            },
                        },
                        f,
                    )
                with patch.object(cr, '_collect_system_health_artifacts', return_value={
                    'lab_root': external_lab,
                    'reports_dir': reports,
                    'consolidated_ok': True,
                    'consolidated_message': '',
                    'consolidated_path': '',
                    'audit_summary_txt': os.path.join(reports, 'audit_migration_health_summary_latest.txt'),
                    'audit_summary_json': os.path.join(reports, 'audit_migration_health_summary_latest.json'),
                    'audit_metrics_json': '',
                    'shadow_report_path': '',
                    'shadow_index_path': '',
                    'phase_f_mismatch_path': '',
                    'delivery_status_path': '',
                }):
                    with patch.object(cr, 'get_health_lines', return_value=['health-line']):
                        ok, msg, path = cr.open_latest_system_health_pack(
                            repo, lambda name, default: default, include_delivery_status=False)
                self.assertTrue(ok)
                self.assertEqual(msg, '')
                with open(path, 'r', encoding='utf-8') as f:
                    text = f.read()
                self.assertIn(
                    'dat_parser_slice_snapshot=config_service(DOS:True,DATE1:True,DATE:False,count:2), crosswalk_mains(DOS:False,DATE1:True,DATE:False,count:1)',
                    text,
                )

    def test_open_latest_system_health_pack_includes_db_enrichment_overview(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            helper = TestGuidedPatientCompletenessRunbook()
            db_path = helper._seed_lab_db(lab)
            conn = sqlite3.connect(db_path)
            conn.execute("PRAGMA foreign_keys = ON")
            conn.execute(
                "UPDATE extracted_canonical_record SET canonical_json = ? WHERE canonical_record_id = 1",
                ('{"Patient ID":"22222","Surgery Date":"02/19/2026"}',)
            )
            conn.execute(
                "UPDATE extracted_canonical_record SET canonical_json = ? WHERE canonical_record_id = 2",
                ('{"Patient ID":"33333","Surgery Date":"02/20/2026"}',)
            )
            conn.execute(
                "INSERT INTO ingest_artifact "
                "(artifact_id, ingest_key, source_system, source_type, source_ref, payload_json, ingest_status) "
                "VALUES (4, 'k4', 'xp_local', 'docx', 's4', '{}', 'projected')"
            )
            conn.execute(
                "INSERT INTO extracted_canonical_record "
                "(canonical_record_id, artifact_id, canonical_type, canonical_key, extractor_version, canonical_json, provenance_json) "
                "VALUES (4, 4, 'docx_schedule', 'sched-1', 'canon_v1', '{\"patient_id\":\"22222\",\"schedule_key\":\"2026-02-19\"}', '{\"patient_id\":\"22222\",\"schedule_key\":\"2026-02-19\"}')"
            )
            conn.commit()
            conn.close()
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({'pipeline_state': 'completed', 'active_run_id': '', 'last_shadow_pipeline_run_id': 'rid-x'}, f)
            with patch.object(cr, '_collect_system_health_artifacts', return_value={
                'lab_root': lab,
                'reports_dir': reports,
                'consolidated_ok': True,
                'consolidated_message': '',
                'consolidated_path': '',
                'audit_summary_txt': '',
                'audit_summary_json': '',
                'audit_metrics_json': '',
                'shadow_report_path': '',
                'shadow_index_path': '',
                'phase_f_mismatch_path': '',
                'delivery_status_path': '',
            }):
                with patch.object(cr, 'get_health_lines', return_value=['health-line']):
                    ok, msg, path = cr.open_latest_system_health_pack(
                        repo, lambda name, default: default, include_delivery_status=False)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            assert isinstance(path, str)
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('DB enrichment overview (cumulative lab state):', text)
            self.assertIn('intake_sources=csv:3, docx:1', text)
            self.assertIn('upstream_csv_docx_join=csv_rows=2, csv_keys=2, docx_rows=1, docx_keys=1, overlap_keys=1, csv_only_keys=1, docx_only_keys=0, historical_duplicate_keys=0, csv_missing_join_key=0', text)
            self.assertIn('relational_depth=patient_count=3, coverage_count=1, encounter_count=1, claim_count=1, claim_line_count=1', text)

    def test_open_latest_system_health_pack_includes_recent_run_actuals(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            runs = [
                {
                    'run_id': 'rid-new',
                    'generated_at_utc': '2026-02-20T01:00:00Z',
                    'pipeline_ok': True,
                    'failed_phase': '',
                    'error_code': '',
                    'post_medisoft_status': 'exercised',
                    'post_medisoft_blocked_stage': '',
                    'phase_b_dat_manifest_rows_count': 7,
                    'phase_d_dat_selected_count': 7,
                    'phase_d_dat_qa_pass_count': 7,
                    'phase_d_dat_qa_reject_count': 0,
                    'phase_d_dat_canonical_record_count': 7,
                    'mtime': 200,
                },
                {
                    'run_id': 'rid-old',
                    'generated_at_utc': '2026-02-19T01:00:00Z',
                    'pipeline_ok': False,
                    'failed_phase': 'D',
                    'error_code': 'QA_DAT',
                    'post_medisoft_status': 'blocked',
                    'post_medisoft_blocked_stage': 'qa',
                    'phase_b_dat_manifest_rows_count': 5,
                    'phase_d_dat_selected_count': 5,
                    'phase_d_dat_qa_pass_count': 3,
                    'phase_d_dat_qa_reject_count': 2,
                    'phase_d_dat_canonical_record_count': 3,
                    'mtime': 100,
                },
            ]
            for item in runs:
                path = os.path.join(reports, 'shadow_run_report_{0}.json'.format(item['run_id']))
                with open(path, 'w', encoding='utf-8') as f:
                    json.dump({
                        'run_id': item['run_id'],
                        'generated_at_utc': item['generated_at_utc'],
                        'pipeline_ok': item['pipeline_ok'],
                        'failed_phase': item['failed_phase'],
                        'error_code': item['error_code'],
                        'post_medisoft_status': item['post_medisoft_status'],
                        'post_medisoft_blocked_stage': item['post_medisoft_blocked_stage'],
                        'phase_b_dat_manifest_rows_count': item['phase_b_dat_manifest_rows_count'],
                        'phase_d_dat_selected_count': item['phase_d_dat_selected_count'],
                        'phase_d_dat_qa_pass_count': item['phase_d_dat_qa_pass_count'],
                        'phase_d_dat_qa_reject_count': item['phase_d_dat_qa_reject_count'],
                        'phase_d_dat_canonical_record_count': item['phase_d_dat_canonical_record_count'],
                    }, f)
                os.utime(path, (item['mtime'], item['mtime']))
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({'pipeline_state': 'completed', 'active_run_id': '', 'last_shadow_pipeline_run_id': 'rid-new'}, f)
            with patch.object(cr, '_collect_system_health_artifacts', return_value={
                'lab_root': lab,
                'reports_dir': reports,
                'consolidated_ok': True,
                'consolidated_message': '',
                'consolidated_path': '',
                'audit_summary_txt': '',
                'audit_summary_json': '',
                'audit_metrics_json': '',
                'shadow_report_path': os.path.join(reports, 'shadow_run_report_rid-new.json'),
                'shadow_index_path': '',
                'phase_f_mismatch_path': '',
                'delivery_status_path': '',
            }):
                with patch.object(cr, 'get_health_lines', return_value=['health-line']):
                    ok, msg, path = cr.open_latest_system_health_pack(
                        repo, lambda name, default: default, include_delivery_status=False)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            assert isinstance(path, str)
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('Recent run actuals:', text)
            self.assertIn('rid-new: pipeline=ok, post_medisoft=exercised, manifest_rows=7, selected=7, qa_pass=7, qa_reject=0, canonical=7', text)
            self.assertIn('rid-old: pipeline=fail:D:QA_DAT, post_medisoft=blocked(qa), manifest_rows=5, selected=5, qa_pass=3, qa_reject=2, canonical=3', text)
            self.assertIn('delta_vs_previous=pipeline:fail:D:QA_DAT->ok, post_medisoft:blocked(qa)->exercised, manifest_rows:+2, selected:+2, qa_pass:+4, qa_reject:-2, canonical:+4', text)
            self.assertNotIn('regression_hints=', text)

    def test_open_latest_system_health_pack_includes_recent_run_regression_hints(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            runs = [
                {
                    'run_id': 'rid-new',
                    'generated_at_utc': '2026-02-20T01:00:00Z',
                    'pipeline_ok': True,
                    'failed_phase': '',
                    'error_code': '',
                    'post_medisoft_status': 'blocked',
                    'post_medisoft_blocked_stage': 'qa',
                    'phase_b_dat_manifest_rows_count': 2,
                    'phase_d_dat_selected_count': 2,
                    'phase_d_dat_qa_pass_count': 1,
                    'phase_d_dat_qa_reject_count': 1,
                    'phase_d_dat_canonical_record_count': 1,
                    'phase_d_dat_v2_inserted_total': 1,
                    'mtime': 200,
                },
                {
                    'run_id': 'rid-old',
                    'generated_at_utc': '2026-02-19T01:00:00Z',
                    'pipeline_ok': True,
                    'failed_phase': '',
                    'error_code': '',
                    'post_medisoft_status': 'exercised',
                    'post_medisoft_blocked_stage': '',
                    'phase_b_dat_manifest_rows_count': 6,
                    'phase_d_dat_selected_count': 6,
                    'phase_d_dat_qa_pass_count': 6,
                    'phase_d_dat_qa_reject_count': 0,
                    'phase_d_dat_canonical_record_count': 6,
                    'phase_d_dat_v2_inserted_total': 6,
                    'mtime': 100,
                },
            ]
            for item in runs:
                path = os.path.join(reports, 'shadow_run_report_{0}.json'.format(item['run_id']))
                with open(path, 'w', encoding='utf-8') as f:
                    json.dump({
                        'run_id': item['run_id'],
                        'generated_at_utc': item['generated_at_utc'],
                        'pipeline_ok': item['pipeline_ok'],
                        'failed_phase': item['failed_phase'],
                        'error_code': item['error_code'],
                        'post_medisoft_status': item['post_medisoft_status'],
                        'post_medisoft_blocked_stage': item['post_medisoft_blocked_stage'],
                        'phase_b_dat_manifest_rows_count': item['phase_b_dat_manifest_rows_count'],
                        'phase_d_dat_selected_count': item['phase_d_dat_selected_count'],
                        'phase_d_dat_qa_pass_count': item['phase_d_dat_qa_pass_count'],
                        'phase_d_dat_qa_reject_count': item['phase_d_dat_qa_reject_count'],
                        'phase_d_dat_canonical_record_count': item['phase_d_dat_canonical_record_count'],
                        'phase_d_dat_v2_inserted_total': item['phase_d_dat_v2_inserted_total'],
                    }, f)
                os.utime(path, (item['mtime'], item['mtime']))
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({'pipeline_state': 'completed', 'active_run_id': '', 'last_shadow_pipeline_run_id': 'rid-new'}, f)
            with patch.object(cr, '_collect_system_health_artifacts', return_value={
                'lab_root': lab,
                'reports_dir': reports,
                'consolidated_ok': True,
                'consolidated_message': '',
                'consolidated_path': '',
                'audit_summary_txt': '',
                'audit_summary_json': '',
                'audit_metrics_json': '',
                'shadow_report_path': os.path.join(reports, 'shadow_run_report_rid-new.json'),
                'shadow_index_path': '',
                'phase_f_mismatch_path': '',
                'delivery_status_path': '',
            }):
                with patch.object(cr, 'get_health_lines', return_value=['health-line']):
                    ok, msg, path = cr.open_latest_system_health_pack(
                        repo, lambda name, default: default, include_delivery_status=False)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            assert isinstance(path, str)
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('regression_hints=post_medisoft_regressed:exercised->blocked(qa)', text)
            self.assertIn('manifest_rows_drop:6->2', text)
            self.assertIn('selected_drop:6->2', text)
            self.assertIn('qa_pass_drop:6->1', text)
            self.assertIn('canonical_drop:6->1', text)
            self.assertIn('v2_inserted_drop:6->1', text)

    def test_open_latest_system_health_pack_suppresses_small_recent_run_drops(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            runs = [
                {
                    'run_id': 'rid-new',
                    'generated_at_utc': '2026-02-20T01:00:00Z',
                    'pipeline_ok': True,
                    'failed_phase': '',
                    'error_code': '',
                    'post_medisoft_status': 'exercised',
                    'post_medisoft_blocked_stage': '',
                    'phase_b_dat_manifest_rows_count': 9,
                    'phase_d_dat_selected_count': 9,
                    'phase_d_dat_qa_pass_count': 9,
                    'phase_d_dat_qa_reject_count': 0,
                    'phase_d_dat_canonical_record_count': 9,
                    'phase_d_dat_v2_inserted_total': 9,
                    'mtime': 200,
                },
                {
                    'run_id': 'rid-old',
                    'generated_at_utc': '2026-02-19T01:00:00Z',
                    'pipeline_ok': True,
                    'failed_phase': '',
                    'error_code': '',
                    'post_medisoft_status': 'exercised',
                    'post_medisoft_blocked_stage': '',
                    'phase_b_dat_manifest_rows_count': 10,
                    'phase_d_dat_selected_count': 10,
                    'phase_d_dat_qa_pass_count': 10,
                    'phase_d_dat_qa_reject_count': 0,
                    'phase_d_dat_canonical_record_count': 10,
                    'phase_d_dat_v2_inserted_total': 10,
                    'mtime': 100,
                },
            ]
            for item in runs:
                path = os.path.join(reports, 'shadow_run_report_{0}.json'.format(item['run_id']))
                with open(path, 'w', encoding='utf-8') as f:
                    json.dump({
                        'run_id': item['run_id'],
                        'generated_at_utc': item['generated_at_utc'],
                        'pipeline_ok': item['pipeline_ok'],
                        'failed_phase': item['failed_phase'],
                        'error_code': item['error_code'],
                        'post_medisoft_status': item['post_medisoft_status'],
                        'post_medisoft_blocked_stage': item['post_medisoft_blocked_stage'],
                        'phase_b_dat_manifest_rows_count': item['phase_b_dat_manifest_rows_count'],
                        'phase_d_dat_selected_count': item['phase_d_dat_selected_count'],
                        'phase_d_dat_qa_pass_count': item['phase_d_dat_qa_pass_count'],
                        'phase_d_dat_qa_reject_count': item['phase_d_dat_qa_reject_count'],
                        'phase_d_dat_canonical_record_count': item['phase_d_dat_canonical_record_count'],
                        'phase_d_dat_v2_inserted_total': item['phase_d_dat_v2_inserted_total'],
                    }, f)
                os.utime(path, (item['mtime'], item['mtime']))
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({'pipeline_state': 'completed', 'active_run_id': '', 'last_shadow_pipeline_run_id': 'rid-new'}, f)
            with patch.object(cr, '_collect_system_health_artifacts', return_value={
                'lab_root': lab,
                'reports_dir': reports,
                'consolidated_ok': True,
                'consolidated_message': '',
                'consolidated_path': '',
                'audit_summary_txt': '',
                'audit_summary_json': '',
                'audit_metrics_json': '',
                'shadow_report_path': os.path.join(reports, 'shadow_run_report_rid-new.json'),
                'shadow_index_path': '',
                'phase_f_mismatch_path': '',
                'delivery_status_path': '',
            }):
                with patch.object(cr, 'get_health_lines', return_value=['health-line']):
                    ok, msg, path = cr.open_latest_system_health_pack(
                        repo, lambda name, default: default, include_delivery_status=False)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            assert isinstance(path, str)
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertNotIn('regression_hints=', text)
            self.assertIn('delta_vs_previous=manifest_rows:-1, selected:-1, qa_pass:-1, canonical:-1, v2_inserted:-1', text)

    def test_open_latest_system_health_pack_flags_stale_audit_against_current_run(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rid_current = 'rid-current'
            rid_old = 'rid-old'
            with open(os.path.join(reports, 'shadow_run_report_{0}.json'.format(rid_current)), 'w', encoding='utf-8') as f:
                json.dump({
                    'run_id': rid_current,
                    'generated_at_utc': '2026-02-20T01:00:00Z',
                    'pipeline_ok': True,
                    'failed_phase': '',
                    'error_code': '',
                    'post_medisoft_status': 'blocked',
                    'post_medisoft_blocked_stage': 'qa',
                    'phase_b_dat_manifest_rows_count': 3,
                    'phase_d_dat_selected_count': 3,
                    'phase_d_dat_qa_pass_count': 0,
                    'phase_d_dat_qa_reject_count': 3,
                    'phase_d_dat_canonical_record_count': 0,
                }, f)
            with open(os.path.join(reports, 'shadow_run_report_{0}.json'.format(rid_old)), 'w', encoding='utf-8') as f:
                json.dump({
                    'run_id': rid_old,
                    'generated_at_utc': '2026-02-19T01:00:00Z',
                    'pipeline_ok': True,
                    'failed_phase': '',
                    'error_code': '',
                    'post_medisoft_status': 'not_exercised',
                    'post_medisoft_blocked_stage': '',
                    'phase_b_dat_manifest_rows_count': 0,
                    'phase_d_dat_selected_count': 0,
                    'phase_d_dat_qa_pass_count': 0,
                    'phase_d_dat_qa_reject_count': 0,
                    'phase_d_dat_canonical_record_count': 0,
                }, f)
            with open(os.path.join(reports, 'audit_migration_health_summary_latest.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'generated_at_utc': '2026-02-19T00:00:00Z',
                    'overall': {'status': 'warn'},
                    'surfaces': {
                        'xp_local': {
                            'run_ids': {'shadow': rid_old},
                            'metrics': [
                                {'key': 'xp.post_medisoft_status', 'status': 'pass', 'value': 'not_exercised'},
                            ],
                        },
                    },
                }, f)
            with open(os.path.join(reports, 'audit_migration_health_summary_latest.txt'), 'w', encoding='utf-8') as f:
                f.write('summary')
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'completed',
                    'active_run_id': '',
                    'last_shadow_pipeline_run_id': rid_current,
                    'last_phase_f_at_utc': '2026-02-20T01:01:00Z',
                    'last_discovery_dat_telemetry': {
                        'dat_manifest_rows_count': 3,
                    },
                    'last_phase_d_dat_telemetry': {
                        'dat_selected_count': 3,
                        'dat_qa_pass_count': 0,
                        'dat_qa_reject_count': 3,
                        'dat_canonical_record_count': 0,
                        'post_medisoft_blocked_stage': 'qa',
                    },
                }, f)
            with patch.object(cr, '_collect_system_health_artifacts', return_value={
                'lab_root': lab,
                'reports_dir': reports,
                'consolidated_ok': True,
                'consolidated_message': '',
                'consolidated_path': '',
                'audit_summary_txt': os.path.join(reports, 'audit_migration_health_summary_latest.txt'),
                'audit_summary_json': os.path.join(reports, 'audit_migration_health_summary_latest.json'),
                'audit_metrics_json': '',
                'shadow_report_path': os.path.join(reports, 'shadow_run_report_{0}.txt'.format(rid_old)),
                'shadow_index_path': '',
                'phase_f_mismatch_path': '',
                'delivery_status_path': '',
            }):
                with patch.object(cr, 'get_health_lines', return_value=['health-line']):
                    ok, msg, path = cr.open_latest_system_health_pack(
                        repo, lambda name, default: default, include_delivery_status=False)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            assert isinstance(path, str)
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('pack_anchor_run_id=rid-current', text)
            self.assertIn('Anchored completed-run snapshot:', text)
            self.assertIn('note: audit summary shadow_run_id=rid-old is older than current state last_shadow_pipeline_run_id=rid-current', text)
            self.assertIn('current state: post_medisoft=blocked(qa), manifest_rows=3, selected=3, qa_pass=0, qa_reject=3, canonical=0', text)
            self.assertIn('note: latest shadow_run_report pointer run_id=rid-old lags current state last_shadow_pipeline_run_id=rid-current', text)
            self.assertIn('rid-current: pipeline=ok, post_medisoft=blocked(qa), manifest_rows=3, selected=3, qa_pass=0, qa_reject=3, canonical=0', text)
            self.assertIn('audit hints suppressed because audit summary is older than current completed-run evidence.', text)


    def test_open_latest_system_health_pack_stale_audit_uses_phase_d_block_when_manifest_present(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rid_current = 'rid-current'
            rid_old = 'rid-old'
            with open(os.path.join(reports, 'shadow_run_report_{0}.json'.format(rid_current)), 'w', encoding='utf-8') as f:
                json.dump({
                    'run_id': rid_current,
                    'generated_at_utc': '2026-02-20T01:00:00Z',
                    'pipeline_ok': True,
                    'failed_phase': '',
                    'error_code': '',
                    'post_medisoft_status': 'blocked',
                    'post_medisoft_blocked_stage': 'phase_d',
                    'phase_b_dat_manifest_rows_count': 3,
                    'phase_d_dat_selected_count': 0,
                    'phase_d_dat_qa_pass_count': 0,
                    'phase_d_dat_qa_reject_count': 0,
                    'phase_d_dat_canonical_record_count': 0,
                }, f)
            with open(os.path.join(reports, 'shadow_run_report_{0}.json'.format(rid_old)), 'w', encoding='utf-8') as f:
                json.dump({
                    'run_id': rid_old,
                    'generated_at_utc': '2026-02-19T01:00:00Z',
                    'pipeline_ok': True,
                    'failed_phase': '',
                    'error_code': '',
                    'post_medisoft_status': 'not_exercised',
                    'post_medisoft_blocked_stage': '',
                    'phase_b_dat_manifest_rows_count': 0,
                    'phase_d_dat_selected_count': 0,
                    'phase_d_dat_qa_pass_count': 0,
                    'phase_d_dat_qa_reject_count': 0,
                    'phase_d_dat_canonical_record_count': 0,
                }, f)
            with open(os.path.join(reports, 'audit_migration_health_summary_latest.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'generated_at_utc': '2026-02-19T00:00:00Z',
                    'overall': {'status': 'warn'},
                    'surfaces': {
                        'xp_local': {
                            'run_ids': {'shadow': rid_old},
                            'metrics': [
                                {'key': 'xp.post_medisoft_status', 'status': 'pass', 'value': 'not_exercised'},
                            ],
                        },
                    },
                }, f)
            with open(os.path.join(reports, 'audit_migration_health_summary_latest.txt'), 'w', encoding='utf-8') as f:
                f.write('summary')
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'completed',
                    'active_run_id': '',
                    'last_shadow_pipeline_run_id': rid_current,
                    'last_phase_f_at_utc': '2026-02-20T01:01:00Z',
                    'last_discovery_dat_telemetry': {
                        'dat_manifest_rows_count': 3,
                    },
                    'last_phase_d_dat_telemetry': {
                        'dat_selected_count': 0,
                        'dat_qa_pass_count': 0,
                        'dat_qa_reject_count': 0,
                        'dat_canonical_record_count': 0,
                    },
                }, f)
            with patch.object(cr, '_collect_system_health_artifacts', return_value={
                'lab_root': lab,
                'reports_dir': reports,
                'consolidated_ok': True,
                'consolidated_message': '',
                'consolidated_path': '',
                'audit_summary_txt': os.path.join(reports, 'audit_migration_health_summary_latest.txt'),
                'audit_summary_json': os.path.join(reports, 'audit_migration_health_summary_latest.json'),
                'audit_metrics_json': '',
                'shadow_report_path': os.path.join(reports, 'shadow_run_report_{0}.txt'.format(rid_old)),
                'shadow_index_path': '',
                'phase_f_mismatch_path': '',
                'delivery_status_path': '',
            }):
                with patch.object(cr, 'get_health_lines', return_value=['health-line']):
                    ok, msg, path = cr.open_latest_system_health_pack(
                        repo, lambda name, default: default, include_delivery_status=False)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            assert isinstance(path, str)
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('current state: post_medisoft=blocked(phase_d), manifest_rows=3, selected=0, qa_pass=0, qa_reject=0, canonical=0', text)


    def test_open_latest_system_health_pack_runbook_uses_live_lock_transition_state(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            with open(os.path.join(reports, 'audit_migration_health_summary_latest.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'overall': {'status': 'pass'},
                    'generated_at_utc': '2026-02-20T00:00:00Z',
                }, f)
            with open(os.path.join(reports, 'audit_migration_health_summary_latest.txt'), 'w', encoding='utf-8') as f:
                f.write('summary')
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'completed',
                    'active_run_id': '',
                    'last_shadow_pipeline_run_id': 'rid-last-completed',
                }, f)
            with open(os.path.join(lab, 'shadow_pipeline.lock'), 'w', encoding='utf-8') as f:
                f.write('heartbeat_at_utc=2026-02-20T00:01:00Z\n')
            with patch.object(cr, '_collect_system_health_artifacts', return_value={
                'lab_root': lab,
                'reports_dir': reports,
                'consolidated_ok': True,
                'consolidated_message': '',
                'consolidated_path': '',
                'audit_summary_txt': os.path.join(reports, 'audit_migration_health_summary_latest.txt'),
                'audit_summary_json': os.path.join(reports, 'audit_migration_health_summary_latest.json'),
                'audit_metrics_json': '',
                'shadow_report_path': '',
                'shadow_index_path': '',
                'phase_f_mismatch_path': '',
                'delivery_status_path': '',
            }):
                with patch.object(cr, 'get_health_lines', return_value=['health-line', 'Note: shadow_pipeline.lock is present; pipeline activity may still be in progress.']):
                    ok, msg, path = cr.open_latest_system_health_pack(
                        repo, lambda name, default: default, include_delivery_status=False)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            assert isinstance(path, str)
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('pipeline_state=running', text)
            self.assertIn('run_alignment=transition_in_progress', text)
            self.assertIn('Shadow pipeline activity is still in progress; wait for completion then refresh pack.', text)
            self.assertNotIn('pipeline_state=completed', text)
            self.assertNotIn('Pack is fresh and aligned; proceed with routine verification and evidence send if needed.', text)

    def test_open_latest_system_health_pack_prefers_anchor_dat_detail_over_live_state(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            shadow_json = os.path.join(reports, 'shadow_run_report_rid-b.json')
            with open(shadow_json, 'w', encoding='utf-8') as f:
                json.dump({
                    'run_id': 'rid-b',
                    'generated_at_utc': '2026-03-30T01:00:00Z',
                    'pipeline_ok': True,
                    'failed_phase': '',
                    'error_code': '',
                    'post_medisoft_status': 'blocked',
                    'post_medisoft_blocked_stage': 'qa',
                    'phase_b_dat_manifest_rows_count': 10,
                    'phase_b_dat_selection_mode': 'configured',
                    'phase_b_dat_selected_root_source_id': 'dat_cfg_1',
                    'phase_d_dat_selected_count': 10,
                    'phase_d_dat_qa_pass_count': 2,
                    'phase_d_dat_qa_reject_count': 8,
                    'phase_d_dat_qa_reject_counts_by_reason': {'QA_DAT_DATE_OF_SERVICE_MISSING': 8},
                    'phase_d_dat_field_presence_by_alias': {'records_seen': 10, 'PATID': 10, 'patient_id': 0, 'DOS': 0, 'DATE1': 10, 'date_of_service': 0, 'PAYERID': 0, 'INSID': 10, 'payer_id': 0},
                    'phase_d_dat_parse_diagnostics': {'tuple_parse_failure_count': 1, 'first_failure_class': 'ValueError'},
                    'phase_d_dat_file_prefix_counts': {'Z': 10},
                    'phase_d_dat_reject_file_prefix_counts': {'ZM': 8},
                    'phase_d_dat_canonical_record_count': 2,
                    'phase_d_entity_scope': 'v2',
                }, f)
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'running',
                    'active_run_id': 'rid-live',
                    'last_shadow_pipeline_run_id': 'rid-b',
                    'last_discovery_dat_telemetry': {
                        'dat_manifest_rows_count': 99,
                        'dat_configured_root_missing_count': 0,
                        'dat_selected_root_source_id': 'live_cfg',
                        'dat_selection_mode': 'configured',
                    },
                    'last_phase_d_dat_telemetry': {
                        'dat_selected_count': 99,
                        'dat_qa_pass_count': 0,
                        'dat_qa_reject_count': 99,
                        'dat_canonical_record_count': 0,
                        'dat_field_presence_by_alias': {'records_seen': 99, 'PATID': 1, 'patient_id': 0, 'DOS': 0, 'DATE1': 0, 'date_of_service': 0, 'PAYERID': 0, 'INSID': 0, 'payer_id': 0},
                        'dat_qa_reject_counts_by_reason': {'QA_DAT_PATIENT_ANCHOR_MISSING': 99},
                        'dat_parse_diagnostics': {'tuple_parse_failure_count': 0, 'first_failure_class': ''},
                        'dat_file_prefix_counts': {'LIVE': 99},
                        'dat_reject_file_prefix_counts': {'LIVE': 99},
                    },
                }, f)
            with patch.object(cr, '_collect_system_health_artifacts', return_value={
                'lab_root': lab,
                'reports_dir': reports,
                'consolidated_ok': True,
                'consolidated_message': '',
                'consolidated_path': '',
                'audit_summary_txt': '',
                'audit_summary_json': '',
                'audit_metrics_json': '',
                'shadow_report_path': shadow_json,
                'shadow_index_path': '',
                'phase_f_mismatch_path': '',
                'delivery_status_path': '',
            }):
                with patch.object(cr, 'get_health_lines', return_value=['health-line']):
                    ok, msg, path = cr.open_latest_system_health_pack(
                        repo, lambda name, default: default, include_delivery_status=False)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            assert isinstance(path, str)
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('dat_alias_presence=records:10, PATID:10, patient_id:0, DOS:0, DATE1:10, DATE:0, date_of_service:0, PAYERID:0, INSID:10, payer_id:0', text)
            self.assertIn('dat_reject_mix_top=QA_DAT_DATE_OF_SERVICE_MISSING:8(1.000)', text)
            self.assertIn('dat_parse_exceptions=count:1, first:ValueError', text)
            self.assertIn('dat_file_prefix_mix=Z:10', text)
            self.assertNotIn('dat_file_prefix_mix=LIVE:99', text)

    def test_open_latest_system_health_pack_replays_live_z_zm_reject_mix(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            shadow_json = os.path.join(reports, 'shadow_run_report_20260421-003615-6722364b.json')
            with open(shadow_json, 'w', encoding='utf-8') as f:
                json.dump({
                    'run_id': '20260421-003615-6722364b',
                    'generated_at_utc': '2026-04-21T00:36:33Z',
                    'pipeline_ok': True,
                    'failed_phase': '',
                    'error_code': '',
                    'post_medisoft_status': 'blocked',
                    'post_medisoft_blocked_stage': 'qa',
                    'phase_b_dat_manifest_rows_count': 408,
                    'phase_b_dat_selection_mode': 'configured',
                    'phase_b_dat_selected_root_source_id': 'dat_cfg_0',
                    'phase_d_dat_selected_count': 5,
                    'phase_d_dat_qa_pass_count': 0,
                    'phase_d_dat_qa_reject_count': 5,
                    'phase_d_dat_qa_reject_counts_by_reason': {
                        'QA_DAT_PAYER_ANCHOR_MISSING': 4,
                        'QA_DAT_PATIENT_ANCHOR_MISSING': 1,
                    },
                    'phase_d_dat_field_presence_by_alias': {
                        'records_seen': 167,
                        'PATID': 6,
                        'patient_id': 6,
                        'DOS': 0,
                        'DATE1': 0,
                        'DATE': 66,
                        'date_of_service': 66,
                        'PAYERID': 0,
                        'INSID': 0,
                        'payer_id': 0,
                    },
                    'phase_d_dat_parse_diagnostics': {
                        'tuple_parse_failure_count': 0,
                        'first_failure_class': '',
                    },
                    'phase_d_dat_file_prefix_counts': {'Z': 4, 'ZM': 1},
                    'phase_d_dat_reject_file_prefix_counts': {'Z': 4, 'ZM': 1},
                    'phase_d_dat_canonical_record_count': 0,
                    'phase_d_entity_scope': 'v1',
                }, f)
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'running',
                    'active_run_id': 'rid-live',
                    'last_shadow_pipeline_run_id': '20260421-003615-6722364b',
                    'last_discovery_dat_telemetry': {
                        'dat_manifest_rows_count': 999,
                        'dat_configured_root_missing_count': 0,
                        'dat_selected_root_source_id': 'live_cfg',
                        'dat_selection_mode': 'configured',
                    },
                    'last_phase_d_dat_telemetry': {
                        'dat_selected_count': 999,
                        'dat_qa_pass_count': 0,
                        'dat_qa_reject_count': 999,
                        'dat_canonical_record_count': 0,
                        'dat_field_presence_by_alias': {
                            'records_seen': 999,
                            'PATID': 1,
                            'patient_id': 0,
                            'DOS': 0,
                            'DATE1': 0,
                            'date_of_service': 0,
                            'PAYERID': 0,
                            'INSID': 0,
                            'payer_id': 0,
                        },
                        'dat_qa_reject_counts_by_reason': {'QA_DAT_PATIENT_ANCHOR_MISSING': 999},
                        'dat_file_prefix_counts': {'LIVE': 999},
                        'dat_reject_file_prefix_counts': {'LIVE': 999},
                    },
                }, f)
            with patch.object(cr, '_collect_system_health_artifacts', return_value={
                'lab_root': lab,
                'reports_dir': reports,
                'consolidated_ok': True,
                'consolidated_message': '',
                'consolidated_path': '',
                'audit_summary_txt': '',
                'audit_summary_json': '',
                'audit_metrics_json': '',
                'shadow_report_path': shadow_json,
                'shadow_index_path': '',
                'phase_f_mismatch_path': '',
                'delivery_status_path': '',
            }):
                with patch.object(cr, 'get_health_lines', return_value=['health-line']):
                    ok, msg, path = cr.open_latest_system_health_pack(
                        repo, lambda name, default: default, include_delivery_status=False)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('dat_focus_snapshot=selected:5, qa_pass:0, qa_reject:5, canonical:0, pass_rate:0.000', text)
            self.assertIn('dat_alias_presence=records:167, PATID:6, patient_id:6, DOS:0, DATE1:0, DATE:66, date_of_service:66, PAYERID:0, INSID:0, payer_id:0', text)
            self.assertIn('dat_reject_mix_top=QA_DAT_PAYER_ANCHOR_MISSING:4(0.800), QA_DAT_PATIENT_ANCHOR_MISSING:1(0.200)', text)
            self.assertIn('dat_file_prefix_mix=Z:4, ZM:1', text)
            self.assertIn('dat_reject_file_prefix_mix=Z:4, ZM:1', text)
            self.assertIn('dat_failure_mode_hypothesis=patient_anchor_alias_mismatch_watch', text)
            self.assertNotIn('dat_file_prefix_mix=LIVE:999', text)

    def test_open_latest_system_health_pack_marks_pending_current_run_when_phase_f_json_missing(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'completed',
                    'active_run_id': '',
                    'last_shadow_pipeline_run_id': 'rid-pending',
                }, f)
            with patch.object(cr, '_collect_system_health_artifacts', return_value={
                'lab_root': lab,
                'reports_dir': reports,
                'consolidated_ok': True,
                'consolidated_message': '',
                'consolidated_path': '',
                'audit_summary_txt': '',
                'audit_summary_json': '',
                'audit_metrics_json': '',
                'shadow_report_path': '',
                'shadow_index_path': '',
                'phase_f_mismatch_path': '',
                'delivery_status_path': '',
            }):
                with patch.object(cr, 'get_health_lines', return_value=['health-line']):
                    ok, msg, path = cr.open_latest_system_health_pack(
                        repo, lambda name, default: default, include_delivery_status=False)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            assert isinstance(path, str)
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('current_run=rid-pending: pending shadow_run_report JSON finalization', text)
            self.assertNotIn('none (no shadow_run_report_*.json payloads found)', text)



class TestRunCentricArtifactTools(unittest.TestCase):
    def test_open_latest_artifact_triage_pack_writes_latest_file(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rid = '20260219-064740-157a78b1'
            for name, body in (
                ('artifact_discovery_summary_{0}.json'.format(rid), '{}'),
                ('ingest_write_summary_{0}.json'.format(rid), '{}'),
                ('qa_canonical_summary_{0}.json'.format(rid), '{}'),
                ('projection_parity_summary_{0}.json'.format(rid), '{}'),
                ('shadow_run_report_{0}.txt'.format(rid), 'ok'),
            ):
                with open(os.path.join(reports, name), 'w', encoding='utf-8') as f:
                    f.write(body)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, path = cr.open_latest_artifact_triage_pack(repo)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            assert isinstance(path, str)
            self.assertTrue(os.path.exists(path))
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('Artifact Triage Pack', text)
            self.assertIn(rid, text)
            self.assertIn('bundle_scope_note=', text)
            self.assertIn('Runbook Interpretation:', text)
            self.assertIn('Consequential Diagnostics:', text)
            self.assertIn('What To Do Now:', text)

    def test_complete_artifacts_send_bundle_triage_prefers_follow_recommendation(self):
        from MediCafe import cloud_readiness_artifact_tools as art
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rid = '20260410-011341-b73de336'
            snapshot = {
                'repo_root': repo,
                'lab_root': lab,
                'reports_dir': reports,
                'run_id': rid,
                'pipeline_run_id': rid,
                'phase_rows': [
                    {'code': 'B', 'name': 'Discovery', 'status': 'complete', 'resolved_run_id': rid, 'files': [], 'required_missing': []},
                    {'code': 'C', 'name': 'Ingest', 'status': 'complete', 'resolved_run_id': rid, 'files': [], 'required_missing': []},
                    {'code': 'D', 'name': 'QA', 'status': 'complete', 'resolved_run_id': rid, 'files': [], 'required_missing': []},
                    {'code': 'E', 'name': 'Projection', 'status': 'complete', 'resolved_run_id': rid, 'files': [], 'required_missing': []},
                    {'code': 'F', 'name': 'Shadow Health', 'status': 'complete', 'resolved_run_id': rid, 'files': [], 'required_missing': []},
                ],
                'artifact_files': [],
                'context_files': [],
                'missing_required': [],
                'diagnostics_state': {
                    'pipeline_state': 'completed',
                    'active_run_id': '',
                    'last_shadow_pipeline_run_id': rid,
                },
                'nearest_complete_run_id': '',
                'recent_run_ids': [],
                'pipeline_running': False,
                'phase_run_ids': {'B': rid, 'C': rid, 'D': rid, 'E': rid, 'F': rid},
                'resolution_decision': 'single_token',
                'resolution_confidence': 'high',
                'resolution_reason': 'complete run',
                'resolution_notes': [],
                'lineage_issues': [],
            }
            triage_path = art.write_artifact_triage_pack(
                snapshot,
                latest_alias=False,
                recommended_action={'recommended_action_kind': 'send_bundle', 'recommended_report_kind': 'artifact_triage_pack'},
            )
            with open(triage_path, 'r', encoding='utf-8') as f:
                triage = f.read()
            self.assertIn('Use Follow recommendation to send the latest run evidence bundle', triage)
            self.assertIn('Open run artifact index only if developer/support asks for file-level verification or specific file paths.', triage)
            self.assertNotIn('Use run artifact index for detailed file-level verification before handoff.', triage)
            self.assertNotIn('Send latest run evidence bundle if you need to escalate or archive evidence.', triage)

    def test_complete_artifacts_send_bundle_index_is_support_only_surface(self):
        from MediCafe import cloud_readiness_artifact_tools as art
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rid = '20260410-011341-b73de336'
            snapshot = {
                'repo_root': repo,
                'lab_root': lab,
                'reports_dir': reports,
                'run_id': rid,
                'pipeline_run_id': rid,
                'phase_rows': [
                    {'code': 'B', 'name': 'Discovery', 'status': 'complete', 'resolved_run_id': rid, 'files': [], 'required_missing': []},
                    {'code': 'C', 'name': 'Ingest', 'status': 'complete', 'resolved_run_id': rid, 'files': [], 'required_missing': []},
                    {'code': 'D', 'name': 'QA', 'status': 'complete', 'resolved_run_id': rid, 'files': [], 'required_missing': []},
                    {'code': 'E', 'name': 'Projection', 'status': 'complete', 'resolved_run_id': rid, 'files': [], 'required_missing': []},
                    {'code': 'F', 'name': 'Shadow Health', 'status': 'complete', 'resolved_run_id': rid, 'files': [], 'required_missing': []},
                ],
                'artifact_files': [],
                'context_files': [],
                'missing_required': [],
                'diagnostics_state': {
                    'pipeline_state': 'completed',
                    'active_run_id': '',
                    'last_shadow_pipeline_run_id': rid,
                },
                'nearest_complete_run_id': '',
                'recent_run_ids': [],
                'pipeline_running': False,
                'phase_run_ids': {'B': rid, 'C': rid, 'D': rid, 'E': rid, 'F': rid},
                'resolution_decision': 'single_token',
                'resolution_confidence': 'high',
                'resolution_reason': 'complete run',
                'resolution_notes': [],
                'lineage_issues': [],
            }
            index_path = art.write_run_artifact_index(
                snapshot,
                latest_alias=False,
                recommended_action={'recommended_action_kind': 'send_bundle', 'recommended_report_kind': 'artifact_triage_pack'},
            )
            with open(index_path, 'r', encoding='utf-8') as f:
                index = f.read()
            self.assertIn('the triage pack and Follow recommendation are the primary operator surfaces.', index)
            self.assertIn('Use this index only if developer/support asks for file-level verification or specific file paths.', index)
            self.assertNotIn('This run has required artifacts across B..F; use this index for file-level review.', index)
            self.assertNotIn('Send latest run evidence bundle if escalation/archive is required.', index)
    def test_open_latest_artifact_triage_pack_incomplete_contains_actionable_runbook(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rid = '20260219-071129-5d5c869f'
            with open(os.path.join(reports, 'ingest_write_summary_{0}.json'.format(rid)), 'w', encoding='utf-8') as f:
                f.write('{}')
            with open(os.path.join(reports, 'ingest_write_anomalies_{0}.jsonl'.format(rid)), 'w', encoding='utf-8') as f:
                f.write('[]')
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'idle',
                    'active_run_id': '',
                    'last_shadow_pipeline_run_id': rid,
                    'last_error_code': 'PHASE_F_NOT_RUN',
                }, f)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, path = cr.open_latest_artifact_triage_pack(repo)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            assert isinstance(path, str)
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('classification=INCOMPLETE', text)
            self.assertIn('Trigger full shadow pipeline (A->F)', text)
            self.assertIn('run_id_alignment=last_completed', text)
            self.assertIn('last_error_code=PHASE_F_NOT_RUN', text)

    def test_complete_artifacts_coherence_blocked_triage_and_index_align(self):
        """Failed/misaligned diagnostics => REVIEW_REQUIRED triage and cautious index (no optimistic handoff)."""
        from MediCafe import cloud_readiness as cr
        from MediCafe import cloud_readiness_artifact_tools as art
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rid = '20260220-012634-daeb6154'
            other = '20260326-171733-607409d9'
            for name, body in (
                ('artifact_discovery_summary_{0}.json'.format(rid), '{}'),
                ('ingest_write_summary_{0}.json'.format(rid), '{}'),
                ('qa_canonical_summary_{0}.json'.format(rid), '{}'),
                ('projection_parity_summary_{0}.json'.format(rid), '{}'),
                ('shadow_run_report_{0}.txt'.format(rid), 'ok'),
            ):
                with open(os.path.join(reports, name), 'w', encoding='utf-8') as f:
                    f.write(body)
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'failed',
                    'active_run_id': '',
                    'last_shadow_pipeline_run_id': other,
                    'last_error_code': 'PHASE_F_LOCK_FAIL',
                }, f)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, snapshot = cr._build_run_artifact_snapshot(repo, run_id='')
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            triage_path = art.write_artifact_triage_pack(snapshot, latest_alias=False)
            index_path = art.write_run_artifact_index(snapshot, latest_alias=False)
            with open(triage_path, 'r', encoding='utf-8') as f:
                triage = f.read()
            with open(index_path, 'r', encoding='utf-8') as f:
                index = f.read()
            self.assertIn('classification=REVIEW_REQUIRED', triage)
            self.assertNotIn('classification=READY', triage)
            self.assertIn('bundle_scope_note=', triage)
            self.assertNotIn('This run has required artifacts across B..F', index)
            self.assertIn('lab diagnostics show pipeline failure or run misalignment', index)

    def test_review_dat_qa_full_block_keeps_operator_handoff_when_live_state_mixed(self):
        from MediCafe import cloud_readiness_artifact_tools as art
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            anchor = '20260423-195302-4b32cb4c'
            live = '20260424-233913-bf3c48b4'
            snapshot = {
                'repo_root': repo,
                'lab_root': lab,
                'reports_dir': reports,
                'run_id': anchor,
                'pipeline_run_id': anchor,
                'phase_rows': [
                    {'code': 'B', 'name': 'Discovery', 'status': 'complete', 'resolved_run_id': 'b', 'files': [], 'required_missing': []},
                    {'code': 'C', 'name': 'Ingest', 'status': 'complete', 'resolved_run_id': 'c', 'files': [], 'required_missing': []},
                    {'code': 'D', 'name': 'QA', 'status': 'complete', 'resolved_run_id': 'd', 'files': [], 'required_missing': []},
                    {'code': 'E', 'name': 'Projection', 'status': 'complete', 'resolved_run_id': 'e', 'files': [], 'required_missing': []},
                    {'code': 'F', 'name': 'Shadow Health', 'status': 'complete', 'resolved_run_id': anchor, 'files': [], 'required_missing': []},
                ],
                'artifact_files': [],
                'context_files': [],
                'missing_required': [],
                'diagnostics_state': {
                    'pipeline_state': 'running',
                    'active_run_id': live,
                    'last_shadow_pipeline_run_id': anchor,
                },
                'pipeline_running': False,
                'nearest_complete_run_id': '20260423-015108-aa7cae14',
                'recent_run_ids': [],
                'phase_run_ids': {'B': 'b', 'C': 'c', 'D': 'd', 'E': 'e', 'F': anchor},
                'resolution_decision': 'pipeline_phase_map',
                'resolution_confidence': 'medium',
                'resolution_reason': 'shadow_report_source_summary_paths',
                'resolution_notes': [],
                'lineage_issues': [],
            }
            rec = {
                'recommended_action_kind': 'review_dat_qa_full_block',
                'recommended_report_kind': 'artifact_triage_pack',
                'operator_primary_report_surface': 'artifact_triage_pack',
                'follow_recommendation_now': 'send_anchored_run_evidence_bundle',
                'follow_recommendation_when_stable': 'send_anchored_run_evidence_bundle',
                'operator_manual_review_required': False,
                'reply_required': False,
                'recommendation_anchor_run_id': anchor,
                'recommendation_live_run_id': live,
            }
            triage_path = art.write_artifact_triage_pack(snapshot, latest_alias=False, recommended_action=rec)
            index_path = art.write_run_artifact_index(snapshot, latest_alias=False, recommended_action=rec)
            with open(triage_path, 'r', encoding='utf-8') as f:
                triage = f.read()
            with open(index_path, 'r', encoding='utf-8') as f:
                index = f.read()
            self.assertIn('classification=REVIEW_REQUIRED', triage)
            self.assertIn('Use Follow recommendation to send the anchored run evidence bundle', triage)
            self.assertIn('developer/support context', triage)
            self.assertNotIn('Review diagnostics_state.json', triage)
            self.assertNotIn('Resolve pipeline failure or rerun shadow pipeline', triage)
            self.assertIn('Follow recommendation as the operator surfaces', index)
            self.assertNotIn('Read diagnostics_state.json', index)
            self.assertNotIn('Resolve pipeline state / alignment', index)

    def test_lineage_contradiction_marks_bundle_review_required(self):
        from MediCafe import cloud_readiness_artifact_tools as art
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            anchor = '20260330-232228-c66fa6a1'
            phase_c_expected = '20260330-232310-dc3c07d5'
            phase_c_stale = '20260330-151330-34e4afb4'
            phase_d_run = '20260330-232319-8a25eb37'
            phase_e_run = '20260330-232320-f360d9bb'
            d_path = os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(phase_d_run))
            shadow_path = os.path.join(reports, 'shadow_run_report_{0}.json'.format(anchor))
            with open(d_path, 'w', encoding='utf-8') as f:
                json.dump({
                    'run_id': phase_d_run,
                    'phase_c_summary_run_id_used_for_zero_selection': phase_c_stale,
                    'phase_c_context_mismatch_warning': 'run_cursor.last_phase_c_run_id={0} vs resolved_phase_c={1}'.format(phase_c_expected, phase_c_stale),
                }, f)
            with open(shadow_path, 'w', encoding='utf-8') as f:
                json.dump({
                    'run_id': anchor,
                    'phase_run_ids': {'C': phase_c_expected, 'D': phase_d_run, 'E': phase_e_run},
                }, f)
            snapshot = {
                'repo_root': repo,
                'lab_root': lab,
                'reports_dir': reports,
                'run_id': anchor,
                'pipeline_run_id': anchor,
                'phase_rows': [
                    {'code': 'B', 'name': 'B', 'status': 'complete', 'resolved_run_id': anchor, 'files': [], 'required_missing': []},
                    {'code': 'C', 'name': 'C', 'status': 'complete', 'resolved_run_id': phase_c_expected, 'files': [], 'required_missing': []},
                    {'code': 'D', 'name': 'D', 'status': 'complete', 'resolved_run_id': phase_d_run, 'files': [d_path], 'required_missing': []},
                    {'code': 'E', 'name': 'E', 'status': 'complete', 'resolved_run_id': phase_e_run, 'files': [], 'required_missing': []},
                    {'code': 'F', 'name': 'F', 'status': 'complete', 'resolved_run_id': anchor, 'files': [shadow_path], 'required_missing': []},
                ],
                'artifact_files': [],
                'context_files': [],
                'missing_required': [],
                'diagnostics_state': {},
                'nearest_complete_run_id': '',
                'recent_run_ids': [],
                'pipeline_running': False,
                'phase_run_ids': {'C': phase_c_expected, 'D': phase_d_run, 'E': phase_e_run, 'F': anchor},
                'resolution_decision': 'pipeline_phase_map',
                'resolution_confidence': 'high',
                'resolution_reason': 'phase map from anchored shadow payload',
                'resolution_notes': [],
            }
            snapshot['lineage_issues'] = art._collect_snapshot_lineage_issues(snapshot)
            triage_path = art.write_artifact_triage_pack(snapshot, latest_alias=False)
            index_path = art.write_run_artifact_index(snapshot, latest_alias=False)
            with open(triage_path, 'r', encoding='utf-8') as f:
                triage = f.read()
            with open(index_path, 'r', encoding='utf-8') as f:
                index = f.read()
            self.assertTrue(art.artifact_snapshot_coherence_blocked(snapshot))
            self.assertIn('classification=REVIEW_REQUIRED', triage)
            self.assertIn('phase_d_zero_selection_phase_c_run_id_mismatch', triage)
            self.assertIn('lineage_issue_count=', triage)
            self.assertIn('anchored phase lineage is contradictory', index)
            self.assertIn('cross-run contaminated', index)

    def test_latest_snapshot_prefers_diagnostics_run_over_optional_file_mtime(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rid_current = '20260329-171213-current'
            rid_stale = '20260329-171213-stale'
            for name in (
                    'artifact_discovery_summary_{0}.json'.format(rid_current),
                    'ingest_write_summary_{0}.json'.format(rid_current),
                    'qa_canonical_summary_{0}.json'.format(rid_current),
                    'projection_parity_summary_{0}.json'.format(rid_current),
                    'shadow_run_report_{0}.json'.format(rid_current)):
                with open(os.path.join(reports, name), 'w', encoding='utf-8') as f:
                    f.write('{}')
            stale_optional = os.path.join(reports, 'shadow_evidence_index_{0}.json'.format(rid_stale))
            with open(stale_optional, 'w', encoding='utf-8') as f:
                f.write('{}')
            newer = time.time() + 60
            os.utime(stale_optional, (newer, newer))
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'completed',
                    'active_run_id': '',
                    'last_shadow_pipeline_run_id': rid_current,
                }, f)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, snapshot = cr._build_run_artifact_snapshot(repo, run_id='')
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            self.assertEqual(snapshot.get('run_id'), rid_current)
            self.assertNotEqual(snapshot.get('run_id'), rid_stale)

    def test_snapshot_prefers_single_canonical_summary_variant(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rid = '20260329-171213-canonical'
            for prefix in (
                    'ingest_write_summary_',
                    'qa_canonical_summary_',
                    'projection_parity_summary_',
                    'shadow_run_report_'):
                with open(os.path.join(reports, '{0}{1}.json'.format(prefix, rid)), 'w', encoding='utf-8') as f:
                    f.write('{}')
            summary_txt = os.path.join(reports, 'artifact_discovery_summary_{0}.txt'.format(rid))
            summary_json = os.path.join(reports, 'artifact_discovery_summary_{0}.json'.format(rid))
            with open(summary_txt, 'w', encoding='utf-8') as f:
                f.write('older')
            with open(summary_json, 'w', encoding='utf-8') as f:
                f.write('{}')
            old = time.time() - 120
            new = time.time() - 30
            os.utime(summary_txt, (old, old))
            os.utime(summary_json, (new, new))
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'completed',
                    'active_run_id': '',
                    'last_shadow_pipeline_run_id': rid,
                }, f)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, snapshot = cr._build_run_artifact_snapshot(repo, run_id='')
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            discovery_rows = [row for row in snapshot.get('phase_rows', []) if row.get('code') == 'B']
            self.assertEqual(len(discovery_rows), 1)
            self.assertEqual(discovery_rows[0].get('files'), [summary_json])
            self.assertNotIn(summary_txt, snapshot.get('artifact_files', []))

    def test_open_run_artifact_index_for_run_id_requires_existing_run_artifacts(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, path = cr.open_run_artifact_index_for_run_id(repo, '20260219-000000-deadbeef')
            self.assertFalse(ok)
            self.assertIn('No artifacts found', msg)
            self.assertIsNone(path)

    def test_open_latest_run_artifact_index_passes_recommended_action(self):
        """Direct index openers should receive the same recommendation block as triage/bundle paths."""
        from MediCafe import cloud_readiness as cr

        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            snap = {
                'repo_root': repo,
                'lab_root': lab,
                'reports_dir': os.path.join(lab, 'reports'),
                'run_id': '20260330-120000-idxlatest01',
            }
            fake_rec = {
                'recommended_action_kind': 'historical_phase_d_reprocess',
                'historical_reprocess_preview_path': os.path.join(lab, 'reports', 'phase_d_historical_reprocess_preview_latest.txt'),
            }
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snap)):
                with patch.object(cr, '_recommended_action_for_snapshot', return_value=fake_rec) as mock_rec:
                    with patch.object(cr, '_write_run_artifact_index', return_value=os.path.join(repo, 'index.txt')) as mock_w:
                        ok, msg, path = cr.open_latest_run_artifact_index(repo)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            mock_rec.assert_called_once_with(snap)
            mock_w.assert_called_once()
            self.assertEqual(mock_w.call_args[1].get('recommended_action'), fake_rec)
            self.assertTrue(mock_w.call_args[1].get('latest_alias'))

    def test_open_run_artifact_index_for_run_id_passes_recommended_action(self):
        from MediCafe import cloud_readiness as cr

        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            rid = '20260330-120000-idxexplicit01'
            snap = {
                'repo_root': repo,
                'lab_root': lab,
                'reports_dir': os.path.join(lab, 'reports'),
                'run_id': rid,
            }
            fake_rec = {'recommended_action_kind': 'send_bundle', 'milestone_verdict': 'Not advanced'}
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snap)):
                with patch.object(cr, '_recommended_action_for_snapshot', return_value=fake_rec) as mock_rec:
                    with patch.object(cr, '_write_run_artifact_index', return_value=os.path.join(repo, 'index_run.txt')) as mock_w:
                        ok, msg, path = cr.open_run_artifact_index_for_run_id(repo, rid)
            self.assertTrue(ok)
            mock_rec.assert_called_once_with(snap)
            mock_w.assert_called_once()
            self.assertEqual(mock_w.call_args[1].get('recommended_action'), fake_rec)
            self.assertFalse(mock_w.call_args[1].get('latest_alias'))

    def test_recommended_action_for_snapshot_passes_snapshot_run_id_as_anchor(self):
        """Milestone lane must use snapshot run_id so evidence_coherence matches the opened run."""
        from MediCafe import cloud_readiness as cr

        snap = {
            'repo_root': '/tmp/repo',
            'lab_root': '/tmp/repo/lab',
            'run_id': 'opened-run-anchor-1',
            'reports_dir': '/tmp/repo/lab/reports',
        }
        with patch.object(cr, 'compute_operator_support_send_recommendation_core', return_value={}) as mock_core:
            cr._recommended_action_for_snapshot(snap)
        mock_core.assert_called_once()
        self.assertEqual(mock_core.call_args[1].get('recommendation_anchor_run_id'), 'opened-run-anchor-1')
        self.assertEqual(mock_core.call_args[1].get('recommendation_live_run_id'), 'opened-run-anchor-1')

    def test_open_run_artifact_index_for_pipeline_run_uses_phase_map(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rid_f = '20260219-153853-fae6fbd9'
            rid_b = '20260219-153857-8110f389'
            rid_c = '20260219-153910-eb915f3c'
            rid_d = '20260219-153914-ec72027e'
            rid_e = '20260219-153915-4dc5298f'

            for name, body in (
                ('artifact_discovery_summary_{0}.json'.format(rid_b), '{}'),
                ('ingest_write_summary_{0}.json'.format(rid_c), '{}'),
                ('qa_canonical_summary_{0}.json'.format(rid_d), '{}'),
                ('projection_parity_summary_{0}.json'.format(rid_e), '{}'),
                ('shadow_run_report_{0}.txt'.format(rid_f), 'ok'),
            ):
                with open(os.path.join(reports, name), 'w', encoding='utf-8') as f:
                    f.write(body)

            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'completed',
                    'active_run_id': '',
                    'last_shadow_pipeline_run_id': rid_f,
                    'last_shadow_pipeline_phase_run_ids': {
                        'B': rid_b,
                        'C': rid_c,
                        'D': rid_d,
                        'E': rid_e,
                    },
                }, f)

            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, path = cr.open_run_artifact_index_for_run_id(repo, rid_f)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            assert isinstance(path, str)
            self.assertTrue(os.path.exists(path))
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('resolution_decision=pipeline_phase_map', text)
            self.assertIn('phase_run_ids=B:{0},C:{1},D:{2},E:{3},F:{4}'.format(rid_b, rid_c, rid_d, rid_e, rid_f), text)
            self.assertIn('[B] Discovery status=COMPLETE resolved_run_id={0}'.format(rid_b), text)
            self.assertIn('[E] Projection status=COMPLETE resolved_run_id={0}'.format(rid_e), text)

    def test_open_run_artifact_index_for_pipeline_run_falls_back_when_map_stale(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rid_f = '20260219-153853-fae6fbd9'

            for name, body in (
                ('artifact_discovery_summary_{0}.json'.format(rid_f), '{}'),
                ('ingest_write_summary_{0}.json'.format(rid_f), '{}'),
                ('qa_canonical_summary_{0}.json'.format(rid_f), '{}'),
                ('projection_parity_summary_{0}.json'.format(rid_f), '{}'),
                ('shadow_run_report_{0}.txt'.format(rid_f), 'ok'),
            ):
                with open(os.path.join(reports, name), 'w', encoding='utf-8') as f:
                    f.write(body)

            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'completed',
                    'active_run_id': '',
                    'last_shadow_pipeline_run_id': rid_f,
                    'last_shadow_pipeline_phase_run_ids': {
                        'B': '20260219-bad-b',
                        'C': '20260219-bad-c',
                        'D': '20260219-bad-d',
                        'E': '20260219-bad-e',
                    },
                }, f)

            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, path = cr.open_run_artifact_index_for_run_id(repo, rid_f)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            assert isinstance(path, str)
            self.assertTrue(os.path.exists(path))
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('resolution_decision=single_token', text)
            self.assertIn('resolution_reason=phase_map_state_file_drift_fallback_single_token', text)
            self.assertIn('[B] Discovery status=COMPLETE resolved_run_id={0}'.format(rid_f), text)

    def test_open_run_artifact_index_ignores_unanchored_state_phase_map(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rid_f = '20260219-153853-fae6fbd9'
            rid_b = '20260219-153857-8110f389'
            rid_c = '20260219-153910-eb915f3c'
            rid_d = '20260219-153914-ec72027e'
            rid_e = '20260219-153915-4dc5298f'

            for name, body in (
                ('artifact_discovery_summary_{0}.json'.format(rid_b), '{}'),
                ('ingest_write_summary_{0}.json'.format(rid_c), '{}'),
                ('qa_canonical_summary_{0}.json'.format(rid_d), '{}'),
                ('projection_parity_summary_{0}.json'.format(rid_e), '{}'),
                ('shadow_run_report_{0}.json'.format(rid_f), json.dumps({'source_summary_paths': []})),
                ('shadow_run_report_{0}.txt'.format(rid_f), 'ok'),
            ):
                with open(os.path.join(reports, name), 'w', encoding='utf-8') as f:
                    f.write(body)

            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'completed',
                    'active_run_id': '',
                    'last_shadow_pipeline_run_id': '20260219-other-root-ffffffff',
                    'last_shadow_pipeline_phase_run_ids': {
                        'B': rid_b,
                        'C': rid_c,
                        'D': rid_d,
                        'E': rid_e,
                    },
                }, f)

            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, path = cr.open_run_artifact_index_for_run_id(repo, rid_f)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            assert isinstance(path, str)
            self.assertTrue(os.path.exists(path))
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('resolution_decision=single_token', text)
            self.assertIn('resolution_reason=state_phase_map_unanchored_fallback_single_token', text)
            self.assertIn('[B] Discovery status=MISSING resolved_run_id={0}'.format(rid_f), text)

    def test_open_run_artifact_index_prefers_shadow_lineage_when_state_conflicts(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rid_f = '20260219-153853-fae6fbd9'
            rid_b_old = '20260219-153857-oldb'
            rid_c_old = '20260219-153910-oldc'
            rid_d_old = '20260219-153914-oldd'
            rid_e_old = '20260219-153915-olde'
            rid_b_new = '20260219-153857-newb'
            rid_c_new = '20260219-153910-newc'
            rid_d_new = '20260219-153914-newd'
            rid_e_new = '20260219-153915-newe'

            shadow_paths = [
                os.path.join(reports, 'artifact_discovery_summary_{0}.json'.format(rid_b_old)),
                os.path.join(reports, 'ingest_write_summary_{0}.json'.format(rid_c_old)),
                os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(rid_d_old)),
                os.path.join(reports, 'projection_parity_summary_{0}.json'.format(rid_e_old)),
            ]
            with open(os.path.join(reports, 'shadow_run_report_{0}.json'.format(rid_f)), 'w', encoding='utf-8') as f:
                json.dump({'source_summary_paths': shadow_paths}, f)
            with open(os.path.join(reports, 'shadow_run_report_{0}.txt'.format(rid_f)), 'w', encoding='utf-8') as f:
                f.write('ok')

            with open(os.path.join(reports, 'artifact_discovery_summary_{0}.json'.format(rid_b_old)), 'w', encoding='utf-8') as f:
                f.write('{}')

            for rid, prefix in (
                (rid_b_new, 'artifact_discovery_summary_'),
                (rid_c_new, 'ingest_write_summary_'),
                (rid_d_new, 'qa_canonical_summary_'),
                (rid_e_new, 'projection_parity_summary_'),
            ):
                with open(os.path.join(reports, '{0}{1}.json'.format(prefix, rid)), 'w', encoding='utf-8') as f:
                    f.write('{}')

            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'completed',
                    'active_run_id': '',
                    'last_shadow_pipeline_run_id': rid_f,
                    'last_shadow_pipeline_phase_run_ids': {
                        'B': rid_b_new,
                        'C': rid_c_new,
                        'D': rid_d_new,
                        'E': rid_e_new,
                    },
                }, f)

            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, path = cr.open_run_artifact_index_for_run_id(repo, rid_f)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            assert isinstance(path, str)
            self.assertTrue(os.path.exists(path))
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('resolution_decision=single_token', text)
            self.assertIn('[B] Discovery status=MISSING resolved_run_id={0}'.format(rid_f), text)

    def test_send_latest_run_evidence_bundle_includes_run_id_meta(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rid = '20260219-064740-157a78b1'
            with open(os.path.join(reports, 'artifact_discovery_summary_{0}.json'.format(rid)), 'w', encoding='utf-8') as f:
                f.write('{}')
            with open(os.path.join(reports, 'ingest_write_summary_{0}.json'.format(rid)), 'w', encoding='utf-8') as f:
                f.write('{}')
            with open(os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(rid)), 'w', encoding='utf-8') as f:
                f.write('{}')
            with open(os.path.join(reports, 'projection_parity_summary_{0}.json'.format(rid)), 'w', encoding='utf-8') as f:
                f.write('{}')
            with open(os.path.join(reports, 'shadow_run_report_{0}.txt'.format(rid)), 'w', encoding='utf-8') as f:
                f.write('ok')
            delivery_path = os.path.join(reports, 'report_delivery_status.txt')
            with open(delivery_path, 'w', encoding='utf-8') as f:
                f.write('delivery')

            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                with patch.object(cr, 'open_report_delivery_status', return_value=(True, '', delivery_path)):
                    with patch.object(cr, '_collect_delivery_diagnostics', return_value={}):
                        with patch.object(cr, 'collect_support_bundle', return_value='/tmp/run_bundle.zip') as mock_collect:
                            with patch.object(cr, '_submit_bundle_with_delivery_diagnostics', return_value=(True, '', {})):
                                ok, msg, data = cr.send_latest_run_evidence_bundle(repo)
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            assert isinstance(data, dict)
            self.assertEqual(data.get('run_id'), rid)
            meta = mock_collect.call_args[1].get('extra_meta', {})
            self.assertEqual(meta.get('artifact_run_id'), rid)
            self.assertEqual(meta.get('send_source'), 'manual_run_evidence_bundle')
            self.assertEqual(meta.get('operator_execution_mode'), 'explicit_send_menu')
            self.assertTrue(meta.get('run_evidence_bundle'))
            self.assertEqual(meta.get('diagnostics_state_scope'), 'lab_root_current')
            self.assertEqual(meta.get('run_cursor_scope'), 'lab_root_current')
            self.assertEqual(meta.get('log_tail_scope'), 'latest_application_log')
            basenames = [x[0] for x in mock_collect.call_args[1].get('extra_files', [])]
            self.assertTrue(any(name.startswith('artifact_triage_pack_') for name in basenames))
            self.assertTrue(any(name.startswith('run_artifact_index_') for name in basenames))
            self.assertTrue(isinstance(data.get('runbook_lines', []), list))
            self.assertTrue(len(data.get('runbook_lines', [])) > 0)

    def test_send_latest_run_evidence_bundle_stamps_follow_recommendation_meta(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rid = '20260219-064740-157a78b1'
            for name in (
                    'artifact_discovery_summary_{0}.json'.format(rid),
                    'ingest_write_summary_{0}.json'.format(rid),
                    'qa_canonical_summary_{0}.json'.format(rid),
                    'projection_parity_summary_{0}.json'.format(rid),
                    'shadow_run_report_{0}.txt'.format(rid)):
                with open(os.path.join(reports, name), 'w', encoding='utf-8') as f:
                    f.write('{}' if name.endswith('.json') else 'ok')
            delivery_path = os.path.join(reports, 'report_delivery_status.txt')
            with open(delivery_path, 'w', encoding='utf-8') as f:
                f.write('delivery')
            recommendation = {
                'recommended_action_kind': 'send_bundle',
                'preferred_when_stable_action_kind': 'send_bundle',
                'best_now_action_kind': 'send_bundle',
                'recommended_report_kind': 'artifact_triage_pack',
                'primary_send': 'run_evidence',
                'preferred_when_stable': 'run_evidence',
                'best_now_send': 'run_evidence',
                'pipeline_running': False,
                'summary_line': 'Recommended: send latest run evidence bundle (phases B..F).',
            }
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                with patch.object(cr, 'open_report_delivery_status', return_value=(True, '', delivery_path)):
                    with patch.object(cr, '_collect_delivery_diagnostics', return_value={}):
                        with patch.object(cr, 'compute_operator_support_send_recommendation_core', return_value=recommendation):
                            with patch.object(cr, 'collect_support_bundle', return_value='/tmp/run_bundle.zip') as mock_collect:
                                with patch.object(cr, '_submit_bundle_with_delivery_diagnostics', return_value=(True, '', {})):
                                    ok, msg, _data = cr.send_latest_run_evidence_bundle(
                                        repo,
                                        send_source='follow_rec_run_evidence',
                                        operator_execution_mode='follow_recommendation',
                                    )
            self.assertTrue(ok)
            self.assertEqual(msg, '')
            meta = mock_collect.call_args[1].get('extra_meta', {})
            self.assertEqual(meta.get('send_source'), 'follow_rec_run_evidence')
            self.assertEqual(meta.get('operator_execution_mode'), 'follow_recommendation')
            self.assertEqual(meta.get('operator_primary_report_surface'), 'artifact_triage_pack')
            self.assertEqual(meta.get('follow_recommendation_now'), 'send_run_evidence_bundle')
            self.assertEqual(meta.get('follow_recommendation_when_stable'), 'send_run_evidence_bundle')
    def test_send_latest_run_evidence_bundle_review_dat_qa_full_block_uses_anchor_snapshot(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            anchor = '20260329-171213-1ccb1c51'
            latest_other = '20260331-999999-otheriddd'
            for rid in (anchor, latest_other):
                for name_tmpl, body in (
                    ('artifact_discovery_summary_{0}.json', '{}'),
                    ('ingest_write_summary_{0}.json', '{}'),
                    ('qa_canonical_summary_{0}.json', '{}'),
                    ('projection_parity_summary_{0}.json', '{}'),
                ):
                    with open(os.path.join(reports, name_tmpl.format(rid)), 'w', encoding='utf-8') as f:
                        f.write(body)
                with open(os.path.join(reports, 'shadow_run_report_{0}.txt'.format(rid)), 'w', encoding='utf-8') as f:
                    f.write('ok')
            delivery_path = os.path.join(reports, 'report_delivery_status.txt')
            with open(delivery_path, 'w', encoding='utf-8') as f:
                f.write('delivery')
            qa_path = os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(anchor))

            def snap_side_effect(r, run_id=''):
                rid = str(run_id or '').strip()
                if not rid:
                    return (True, '', {
                        'run_id': latest_other,
                        'lab_root': lab,
                        'reports_dir': reports,
                        'repo_root': r,
                        'artifact_files': [],
                        'context_files': [],
                    })
                if rid == anchor:
                    return (True, '', {
                        'run_id': anchor,
                        'lab_root': lab,
                        'reports_dir': reports,
                        'repo_root': r,
                        'artifact_files': [
                            os.path.join(reports, 'artifact_discovery_summary_{0}.json'.format(anchor)),
                            os.path.join(reports, 'qa_canonical_summary_{0}.json'.format(anchor)),
                        ],
                        'context_files': [],
                    })
                return (False, 'missing', {})

            rec_qa = {
                'recommended_action_kind': 'review_dat_qa_full_block',
                'recommended_report_kind': 'artifact_triage_pack',
                'recommendation_anchor_run_id': anchor,
                'action_preview': {
                    'anchor_run_id': anchor,
                    'phase_d_summary_path': qa_path,
                    'qa_reject_samples_path': '',
                    'shadow_run_report_path': os.path.join(reports, 'shadow_run_report_{0}.json'.format(anchor)),
                },
            }

            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                with patch.object(cr, 'open_report_delivery_status', return_value=(True, '', delivery_path)):
                    with patch.object(cr, '_collect_delivery_diagnostics', return_value={}):
                        with patch.object(cr, '_build_run_artifact_snapshot', side_effect=snap_side_effect):
                            with patch.object(cr, 'compute_operator_support_send_recommendation_core', return_value=rec_qa):
                                with patch.object(cr, '_collect_run_evidence_context_attachment', return_value=('', None)):
                                    with patch.object(cr, 'collect_support_bundle', return_value='/tmp/run_bundle.zip') as mock_collect:
                                        with patch.object(cr, '_submit_bundle_with_delivery_diagnostics', return_value=(True, '', {})):
                                            ok, msg, data = cr.send_latest_run_evidence_bundle(repo)
            self.assertTrue(ok)
            meta = mock_collect.call_args[1].get('extra_meta', {})
            self.assertEqual(meta.get('artifact_run_id'), anchor)
            self.assertEqual((data or {}).get('run_id'), anchor)

    def test_send_latest_run_evidence_bundle_runbook_when_coherence_blocked(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rid = '20260219-064740-157a78b1'
            for name, body in (
                ('artifact_discovery_summary_{0}.json'.format(rid), '{}'),
                ('ingest_write_summary_{0}.json'.format(rid), '{}'),
                ('qa_canonical_summary_{0}.json'.format(rid), '{}'),
                ('projection_parity_summary_{0}.json'.format(rid), '{}'),
                ('shadow_run_report_{0}.txt'.format(rid), 'ok'),
            ):
                with open(os.path.join(reports, name), 'w', encoding='utf-8') as f:
                    f.write(body)
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'failed',
                    'active_run_id': '',
                    'last_shadow_pipeline_run_id': '20260326-171733-other',
                    'last_error_code': 'PHASE_F_LOCK_FAIL',
                }, f)
            delivery_path = os.path.join(reports, 'report_delivery_status.txt')
            with open(delivery_path, 'w', encoding='utf-8') as f:
                f.write('delivery')
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                with patch.object(cr, 'open_report_delivery_status', return_value=(True, '', delivery_path)):
                    with patch.object(cr, '_collect_delivery_diagnostics', return_value={}):
                        with patch.object(cr, 'collect_support_bundle', return_value='/tmp/run_bundle.zip'):
                            with patch.object(cr, '_submit_bundle_with_delivery_diagnostics', return_value=(True, '', {})):
                                ok, msg, data = cr.send_latest_run_evidence_bundle(repo)
            self.assertTrue(ok)
            assert isinstance(data, dict)
            bq = data.get('bundle_quality') or {}
            self.assertEqual(bq.get('recommendation'), 'review_lab_state')
            lines = data.get('runbook_lines') or []
            self.assertTrue(any('Lab diagnostics conflict' in ln for ln in lines))

    def test_artifact_bundle_quality_coherence_blocked_incomplete_prefers_nearest_complete(self):
        """LOW + nearest_complete wins over review_lab_state when diagnostics are incoherent."""
        from MediCafe import cloud_readiness_artifact_tools as art

        def _row(st):
            return {
                'code': 'B',
                'name': 'Phase',
                'status': st,
                'resolved_run_id': '-',
                'files': [],
                'required_missing': [],
            }

        rows = [_row('complete'), _row('missing'), _row('missing'), _row('missing'), _row('missing')]
        snap = {
            'run_id': '20260220-curr',
            'nearest_complete_run_id': '20260220-nearest',
            'phase_rows': rows,
            'diagnostics_state': {
                'pipeline_state': 'failed',
                'active_run_id': '',
                'last_shadow_pipeline_run_id': '20260326-other',
            },
        }
        bq = art.artifact_bundle_quality(snap)
        self.assertEqual(bq.get('recommendation'), 'prefer_nearest_complete')
        self.assertEqual(bq.get('missing'), 4)

    def test_preferred_when_stable_coherence_blocked_incomplete_nearest_diagnostics_note(self):
        from MediCafe import cloud_readiness as cr
        from MediCafe import cloud_readiness_artifact_tools as art

        rows = []
        for i, st in enumerate(['complete', 'missing', 'missing', 'missing', 'missing']):
            rows.append({
                'code': 'BCDEF'[i] if i < 5 else 'B',
                'name': 'Phase',
                'status': st,
                'resolved_run_id': '-',
                'files': [],
                'required_missing': [],
            })
        snap = {
            'run_id': '20260220-curr',
            'nearest_complete_run_id': '20260220-nearest',
            'phase_rows': rows,
            'diagnostics_state': {
                'pipeline_state': 'failed',
                'active_run_id': '',
                'last_shadow_pipeline_run_id': '20260326-other',
            },
        }
        self.assertTrue(art.artifact_snapshot_coherence_blocked(snap))
        why = []
        pref = cr._preferred_when_stable_from_snapshot(True, snap, '', '20260220-nearest', why)
        self.assertEqual(pref, 'system_health')
        joined = ' '.join(why)
        self.assertIn('LOW', joined)
        self.assertIn('Lab diagnostics still conflict', joined)
        self.assertNotIn('Run-evidence files are complete', joined)

    def test_review_lab_state_missing_phases_without_nearest_message(self):
        """review_lab_state must not claim B..F complete when phases are missing."""
        from MediCafe import cloud_readiness as cr

        rows = []
        for i, st in enumerate(['complete', 'missing', 'missing', 'missing', 'missing']):
            rows.append({
                'code': 'BCDEF'[i],
                'name': 'Phase',
                'status': st,
                'resolved_run_id': '-',
                'files': [],
                'required_missing': [],
            })
        snap = {
            'run_id': '20260220-curr',
            'nearest_complete_run_id': '',
            'phase_rows': rows,
            'diagnostics_state': {
                'pipeline_state': 'failed',
                'active_run_id': '',
                'last_shadow_pipeline_run_id': '20260220-curr',
            },
        }
        bq = cr._artifact_bundle_quality(snap)
        self.assertEqual(bq.get('recommendation'), 'review_lab_state')
        why = []
        cr._preferred_when_stable_from_snapshot(True, snap, '', '', why)
        joined = ' '.join(why)
        self.assertIn('phase coverage is incomplete', joined)
        self.assertNotIn('Run-evidence files are complete', joined)

    def test_send_latest_run_evidence_bundle_runbook_incomplete_coherence_dual_hints(self):
        from MediCafe import cloud_readiness as cr

        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rows = []
            codes = ('B', 'C', 'D', 'E', 'F')
            for i, st in enumerate(['complete', 'missing', 'missing', 'missing', 'missing']):
                rows.append({
                    'code': codes[i],
                    'name': 'Phase',
                    'status': st,
                    'resolved_run_id': '-',
                    'files': [],
                    'required_missing': [],
                })
            snap = {
                'lab_root': lab,
                'reports_dir': reports,
                'run_id': '20260219-partial',
                'pipeline_run_id': '20260219-partial',
                'phase_rows': rows,
                'artifact_files': [],
                'context_files': [],
                'missing_required': [],
                'diagnostics_state': {
                    'pipeline_state': 'failed',
                    'active_run_id': '',
                    'last_shadow_pipeline_run_id': '20260326-other',
                },
                'nearest_complete_run_id': '20260218-full',
                'recent_run_ids': [],
                'pipeline_running': False,
                'phase_run_ids': {},
                'resolution_decision': 'single_token',
                'resolution_confidence': 'unknown',
                'resolution_reason': '',
                'resolution_notes': [],
            }
            delivery_path = os.path.join(reports, 'report_delivery_status.txt')
            with open(delivery_path, 'w', encoding='utf-8') as f:
                f.write('delivery')
            with patch.object(cr, '_build_run_artifact_snapshot', return_value=(True, '', snap)):
                with patch.object(cr, 'open_report_delivery_status', return_value=(True, '', delivery_path)):
                    with patch.object(cr, '_collect_delivery_diagnostics', return_value={}):
                        with patch.object(cr, 'collect_support_bundle', return_value='/tmp/run_bundle.zip'):
                            with patch.object(cr, '_submit_bundle_with_delivery_diagnostics', return_value=(True, '', {})):
                                ok, msg, data = cr.send_latest_run_evidence_bundle(repo)
            self.assertTrue(ok)
            assert isinstance(data, dict)
            bq = data.get('bundle_quality') or {}
            self.assertEqual(bq.get('recommendation'), 'prefer_nearest_complete')
            lines = data.get('runbook_lines') or []
            self.assertTrue(any('nearest complete run_id=' in ln for ln in lines))
            self.assertTrue(any('Lab diagnostics still conflict' in ln for ln in lines))



class TestGuidedPatientCompletenessRunbook(unittest.TestCase):
    def _seed_lab_db(self, lab_root):
        db_path = os.path.join(lab_root, 'unified_model_xp.db')
        schema_path = os.path.join(_PROJECT_ROOT, 'sql', 'unified_relational_model_v1.sql')
        with open(schema_path, 'r', encoding='utf-8') as f:
            schema_sql = f.read()
        conn = sqlite3.connect(db_path)
        conn.execute("PRAGMA foreign_keys = ON")
        conn.executescript(schema_sql)

        conn.execute(
            "INSERT INTO ingest_artifact "
            "(artifact_id, ingest_key, source_system, source_type, source_ref, payload_json, ingest_status) "
            "VALUES (1, 'k1', 'xp_local', 'csv', 's1', '{}', 'projected')"
        )
        conn.execute(
            "INSERT INTO ingest_artifact "
            "(artifact_id, ingest_key, source_system, source_type, source_ref, payload_json, ingest_status) "
            "VALUES (2, 'k2', 'xp_local', 'csv', 's2', '{}', 'qa_failed')"
        )
        conn.execute(
            "INSERT INTO ingest_artifact "
            "(artifact_id, ingest_key, source_system, source_type, source_ref, payload_json, ingest_status) "
            "VALUES (3, 'k3', 'xp_local', 'csv', 's3', '{}', 'ingested')"
        )

        conn.execute(
            "INSERT INTO patient (patient_id, patient_key, external_patient_id, full_name, birth_date, source_system) "
            "VALUES (1, 'pk-risk', '11111', '', '', 'xp_local')"
        )
        conn.execute(
            "INSERT INTO patient (patient_id, patient_key, external_patient_id, full_name, birth_date, source_system) "
            "VALUES (2, 'pk-good', '22222', 'Baseline Patient', '1980-01-01', 'xp_local')"
        )
        conn.execute(
            "INSERT INTO patient (patient_id, patient_key, external_patient_id, full_name, birth_date, source_system) "
            "VALUES (3, 'pk-reject', '33333', 'Reject Patient', '1990-02-02', 'xp_local')"
        )
        conn.execute(
            "INSERT INTO payer (payer_id, payer_key, payer_external_id, payer_name, endpoint_name) "
            "VALUES (1, 'payer-1', 'P1', 'Payer One', 'endpoint')"
        )
        conn.execute(
            "INSERT INTO insurance_plan (plan_id, plan_key, payer_id, medisoft_insurance_ids_json) "
            "VALUES (1, 'plan-1', 1, '[]')"
        )
        conn.execute(
            "INSERT INTO coverage (coverage_id, coverage_key, patient_id, plan_id, active_flag) "
            "VALUES (1, 'cov-good', 2, 1, 1)"
        )
        conn.execute(
            "INSERT INTO encounter (encounter_id, encounter_key, patient_id, date_of_service, source_artifact_id) "
            "VALUES (1, 'enc-good', 2, '2026-02-19', 1)"
        )
        conn.execute(
            "INSERT INTO claim (claim_id, claim_key, encounter_id, payer_id, claim_number, source_artifact_id) "
            "VALUES (1, 'claim-good', 1, 1, 'CLM-222', 1)"
        )
        conn.execute(
            "INSERT INTO claim_line (claim_line_id, claim_line_key, claim_id, line_number) "
            "VALUES (1, 'line-good', 1, 1)"
        )
        conn.execute(
            "INSERT INTO extracted_canonical_record "
            "(canonical_record_id, artifact_id, canonical_type, canonical_key, extractor_version, canonical_json, provenance_json) "
            "VALUES (1, 1, 'patient_csv_row', 'pk-good', 'canon_v1', '{}', '{}')"
        )
        conn.execute(
            "INSERT INTO projection_result "
            "(projection_id, canonical_record_id, projection_type, projection_version, projection_status, projected_json) "
            "VALUES (1, 1, 'patient_v1', 'v1', 'success', '{\"external_patient_id\":\"22222\"}')"
        )
        conn.execute(
            "INSERT INTO extracted_canonical_record "
            "(canonical_record_id, artifact_id, canonical_type, canonical_key, extractor_version, canonical_json, provenance_json) "
            "VALUES (2, 2, 'patient_csv_row', 'pk-reject', 'canon_v1', '{}', '{}')"
        )
        conn.execute(
            "INSERT INTO projection_result "
            "(projection_id, canonical_record_id, projection_type, projection_version, projection_status, projected_json) "
            "VALUES (2, 2, 'patient_v1', 'v1', 'rejected', '{\"reject_reason\":\"missing_required_fields\"}')"
        )
        conn.execute(
            "INSERT INTO qa_result "
            "(qa_result_id, artifact_id, qa_stage, qa_version, status, reject_code, reject_reason, deterministic_key) "
            "VALUES (1, 2, 'phase_d', 'v1', 'reject', 'QA_REQUIRED', 'missing patient id', 'd1')"
        )
        conn.execute(
            "INSERT INTO replay_queue (replay_id, artifact_id, reason_code, status, attempt_count) "
            "VALUES (1, 2, 'QA_REQUIRED', 'pending', 0)"
        )
        conn.commit()
        conn.close()
        return db_path

    def test_get_guided_patient_completeness_options_returns_enriched_letters(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            db_path = self._seed_lab_db(lab)
            conn = sqlite3.connect(db_path)
            conn.execute("PRAGMA foreign_keys = ON")
            conn.execute(
                "UPDATE extracted_canonical_record SET canonical_json = ? WHERE canonical_record_id = 1",
                ('{"Patient ID":"22222","Surgery Date":"02/19/2026"}',)
            )
            conn.execute(
                "UPDATE extracted_canonical_record SET canonical_json = ? WHERE canonical_record_id = 2",
                ('{"Patient ID":"33333","Surgery Date":"02/20/2026"}',)
            )
            conn.execute(
                "INSERT INTO ingest_artifact "
                "(artifact_id, ingest_key, source_system, source_type, source_ref, payload_json, ingest_status) "
                "VALUES (4, 'k4', 'xp_local', 'docx', 's4', '{}', 'projected')"
            )
            conn.execute(
                "INSERT INTO extracted_canonical_record "
                "(canonical_record_id, artifact_id, canonical_type, canonical_key, extractor_version, canonical_json, provenance_json) "
                "VALUES (4, 4, 'docx_schedule', 'sched-1', 'canon_v1', '{\"patient_id\":\"22222\",\"schedule_key\":\"2026-02-19\"}', '{\"patient_id\":\"22222\",\"schedule_key\":\"2026-02-19\"}')"
            )
            conn.commit()
            conn.close()
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({'pipeline_state': 'idle', 'last_shadow_pipeline_run_id': '20260219-071129-5d5c869f'}, f)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, data = cr.get_guided_patient_completeness_options(repo)
            self.assertTrue(ok)
            self.assertIn('options ready', msg.lower())
            assert isinstance(data, dict)
            options = data.get('options', [])
            codes = [x.get('code') for x in options]
            self.assertIn('A', codes)
            self.assertIn('D', codes)
            self.assertIn('B', codes)
            self.assertTrue(any(str(x.get('display_id')) == '33333' for x in options if x.get('code') == 'B'))
            self.assertTrue(isinstance(data.get('runbook_lines', []), list))
            self.assertTrue(any('data_plane_status=' in line for line in data.get('runbook_lines', [])))

    def test_get_guided_patient_completeness_options_no_patient_rows_returns_guidance(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            db_path = os.path.join(lab, 'unified_model_xp.db')
            conn = sqlite3.connect(db_path)
            conn.close()
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'completed',
                    'active_run_id': '',
                    'last_shadow_pipeline_run_id': '20260219-071129-5d5c869f',
                }, f)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, data = cr.get_guided_patient_completeness_options(repo)
            self.assertFalse(ok)
            self.assertIn('data-state', msg.lower())
            assert isinstance(data, dict)
            self.assertEqual(data.get('condition'), 'no_patient_rows')
            self.assertEqual(data.get('options', []), [])
            runbook_lines = data.get('runbook_lines', [])
            self.assertTrue(any('patient_count=0' in line for line in runbook_lines))
            self.assertTrue(any('qa_reject_count=' in line for line in runbook_lines))
            self.assertTrue(any('replay_pending_count=' in line for line in runbook_lines))
            self.assertTrue(any('projection_success_count=' in line for line in runbook_lines))
            self.assertTrue(any('last_shadow_pipeline_run_id=20260219-071129-5d5c869f' in line for line in runbook_lines))
            self.assertTrue(any(str(line).strip() == 'What To Do Now:' for line in runbook_lines))
            self.assertTrue(any(str(line).strip().startswith('1) ') for line in runbook_lines))
            actions = data.get('actions', [])
            self.assertTrue(isinstance(actions, list))
            self.assertTrue(len(actions) >= 2)
            self.assertTrue(any('investigate' in a.lower() for a in actions))

    def test_open_guided_patient_completeness_runbook_writes_report(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            self._seed_lab_db(lab)
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({'pipeline_state': 'idle', 'last_shadow_pipeline_run_id': '20260219-071129-5d5c869f'}, f)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, path = cr.open_guided_patient_completeness_runbook(repo, 'B')
            self.assertTrue(ok)
            self.assertIn('verdict=', msg)
            assert isinstance(path, str)
            self.assertTrue(os.path.exists(path))
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('Patient Completeness Runbook', text)
            self.assertIn('Runbook Interpretation:', text)
            self.assertIn('What To Do Now:', text)
            self.assertIn('Artifact pointers:', text)

    def test_open_guided_patient_completeness_runbook_prefers_dat_qa_action_when_latest_run_blocked(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            self._seed_lab_db(lab)
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'completed',
                    'last_shadow_pipeline_run_id': '20260323-013957-de087671',
                    'last_phase_d_dat_telemetry': {
                        'dat_selected_count': 3,
                        'dat_qa_reject_count': 3,
                        'post_medisoft_blocked_stage': 'qa',
                    },
                }, f)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, path = cr.open_guided_patient_completeness_runbook(repo, 'A')
            self.assertTrue(ok)
            assert isinstance(path, str)
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('Inspect latest DAT QA rejects in qa_reject_samples; latest run is blocked at Phase D QA (selected=3, qa_reject=3).', text)
            self.assertNotIn('Re-run Phase C ingest or full A->F pipeline to populate missing encounter/claim chain.', text)

    def test_patient_flow_reference_options_preserve_chain_fields(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            self._seed_lab_db(lab)
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({'pipeline_state': 'idle', 'last_shadow_pipeline_run_id': '20260219-071129-5d5c869f'}, f)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, data = cr.get_patient_flow_reference_options(repo, limit=10)
            self.assertTrue(ok)
            assert isinstance(data, dict)
            options = data.get('options', [])
            self.assertTrue(len(options) > 0)
            first = options[0]
            self.assertIn('claim_count', first)
            self.assertIn('canonical_count', first)
            self.assertIn('full_name', first)

    def test_find_patient_option_by_reference_prefers_external_id_over_numeric_patient_id(self):
        from MediCafe import cloud_readiness_patient_tools as pt
        rows = [
            {'patient_id': 33333, 'patient_key': 'pk-a', 'external_patient_id': '55555'},
            {'patient_id': 42, 'patient_key': 'pk-b', 'external_patient_id': '33333'},
        ]
        picked = pt.find_patient_option_by_reference(rows, '33333')
        assert isinstance(picked, dict)
        self.assertEqual(picked.get('patient_id'), 42)

    def test_get_patient_flow_reference_options_autopopulates_refs(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            self._seed_lab_db(lab)
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({'pipeline_state': 'idle', 'last_shadow_pipeline_run_id': '20260219-071129-5d5c869f'}, f)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, data = cr.get_patient_flow_reference_options(repo, limit=10)
            self.assertTrue(ok)
            self.assertIn('options ready', msg.lower())
            assert isinstance(data, dict)
            options = data.get('options', [])
            self.assertTrue(len(options) > 0)
            self.assertTrue(any(str(x.get('patient_ref')) == '33333' for x in options))

    def test_open_patient_flow_runbook_by_external_patient_id_writes_report(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            self._seed_lab_db(lab)
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({'pipeline_state': 'idle', 'last_shadow_pipeline_run_id': '20260219-071129-5d5c869f'}, f)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, path = cr.open_patient_flow_runbook(repo, '33333')
            self.assertTrue(ok)
            self.assertIn('Patient flow runbook generated', msg)
            assert isinstance(path, str)
            self.assertTrue(os.path.exists(path))
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('Data View Samples (first 3 rows per table):', text)
            self.assertIn(' - patient:', text)
            self.assertIn(' - claim:', text)
            self.assertIn(' - qa_result:', text)

    def test_open_patient_flow_runbook_unknown_patient_returns_not_found(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            self._seed_lab_db(lab)
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({'pipeline_state': 'idle', 'last_shadow_pipeline_run_id': '20260219-071129-5d5c869f'}, f)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, path = cr.open_patient_flow_runbook(repo, 'does-not-exist')
            self.assertFalse(ok)
            self.assertIn('not found', msg.lower())
            self.assertIsNone(path)

    def test_open_data_plane_audit_report_writes_readable_snapshot(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            db_path = self._seed_lab_db(lab)
            conn = sqlite3.connect(db_path)
            conn.execute("PRAGMA foreign_keys = ON")
            conn.execute(
                "UPDATE extracted_canonical_record SET canonical_json = ? WHERE canonical_record_id = 1",
                ('{"Patient ID":"22222","Surgery Date":"02/19/2026"}',)
            )
            conn.execute(
                "UPDATE extracted_canonical_record SET canonical_json = ? WHERE canonical_record_id = 2",
                ('{"Patient ID":"33333","Surgery Date":"02/20/2026"}',)
            )
            conn.execute(
                "INSERT INTO ingest_artifact "
                "(artifact_id, ingest_key, source_system, source_type, source_ref, payload_json, ingest_status) "
                "VALUES (4, 'k4', 'xp_local', 'docx', 's4', '{}', 'projected')"
            )
            conn.execute(
                "INSERT INTO extracted_canonical_record "
                "(canonical_record_id, artifact_id, canonical_type, canonical_key, extractor_version, canonical_json, provenance_json) "
                "VALUES (4, 4, 'docx_schedule', 'sched-1', 'canon_v1', '{\"patient_id\":\"22222\",\"schedule_key\":\"2026-02-19\"}', '{\"patient_id\":\"22222\",\"schedule_key\":\"2026-02-19\"}')"
            )
            conn.commit()
            conn.close()
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({'pipeline_state': 'idle', 'last_shadow_pipeline_run_id': '20260219-071129-5d5c869f'}, f)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, path = cr.open_data_plane_audit_report(repo, report_type='overview', limit=20)
            self.assertTrue(ok)
            self.assertIn('report generated', msg.lower())
            assert isinstance(path, str)
            self.assertTrue(os.path.exists(path))
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('DB Data Audit Report', text)
            self.assertIn('Data Plane Summary:', text)
            self.assertIn('DB Enrichment Overview:', text)
            self.assertIn('active backlog only', text)
            self.assertIn('Table row counts:', text)
            self.assertIn('intake_sources=csv:3, docx:1', text)
            self.assertIn('upstream_csv_docx_join=csv_rows=2, csv_keys=2, docx_rows=1, docx_keys=1, overlap_keys=1, csv_only_keys=1, docx_only_keys=0, historical_duplicate_keys=0, csv_missing_join_key=0', text)
            self.assertIn('join_scope_note=overlap/csv_only/docx_only describe deduped cumulative unique join keys; historical_duplicate_pressure captures repeated-key pressure across stored DB history and is not unresolved ambiguity by itself', text)
            self.assertIn('relational_depth=patient_count=3, coverage_count=1, encounter_count=1, claim_count=1, claim_line_count=1', text)
            self.assertIn('Patient sample rows:', text)
            self.assertIn('created_at is DB row creation timestamp', text)
            self.assertIn('33333', text)

    def test_open_data_plane_audit_report_includes_historical_duplicate_examples(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            db_path = self._seed_lab_db(lab)
            conn = sqlite3.connect(db_path)
            conn.execute("PRAGMA foreign_keys = ON")
            conn.execute(
                "UPDATE ingest_artifact SET source_type = 'file_csv' WHERE artifact_id IN (1,2,3)"
            )
            conn.execute(
                "UPDATE extracted_canonical_record SET canonical_json = ? WHERE canonical_record_id = 1",
                ('{"Patient ID":"22222","Surgery Date":"02/19/2026"}',)
            )
            conn.execute(
                "UPDATE extracted_canonical_record SET canonical_json = ? WHERE canonical_record_id = 2",
                ('{"Patient ID":"22222","Surgery Date":"02/19/2026"}',)
            )
            conn.execute(
                "INSERT INTO ingest_artifact "
                "(artifact_id, ingest_key, source_system, source_type, source_ref, payload_json, ingest_status) "
                "VALUES (4, 'k4', 'xp_local', 'file_docx', 's4', '{}', 'projected')"
            )
            conn.execute(
                "INSERT INTO ingest_artifact "
                "(artifact_id, ingest_key, source_system, source_type, source_ref, payload_json, ingest_status) "
                "VALUES (5, 'k5', 'xp_local', 'file_docx', 's5', '{}', 'projected')"
            )
            conn.execute(
                "INSERT INTO extracted_canonical_record "
                "(canonical_record_id, artifact_id, canonical_type, canonical_key, extractor_version, canonical_json, provenance_json) "
                "VALUES (4, 4, 'docx_schedule', 'sched-1', 'canon_v1', '{\"patient_id\":\"22222\",\"schedule_key\":\"2026-02-19\"}', '{\"patient_id\":\"22222\",\"schedule_key\":\"2026-02-19\"}')"
            )
            conn.execute(
                "INSERT INTO extracted_canonical_record "
                "(canonical_record_id, artifact_id, canonical_type, canonical_key, extractor_version, canonical_json, provenance_json) "
                "VALUES (5, 5, 'docx_schedule', 'sched-2', 'canon_v1', '{\"patient_id\":\"22222\",\"schedule_key\":\"2026-02-19\"}', '{\"patient_id\":\"22222\",\"schedule_key\":\"2026-02-19\"}')"
            )
            conn.commit()
            conn.close()
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({'pipeline_state': 'idle', 'last_shadow_pipeline_run_id': '20260219-071129-5d5c869f'}, f)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, path = cr.open_data_plane_audit_report(repo, report_type='overview', limit=20)
            self.assertTrue(ok)
            self.assertIn('report generated', msg.lower())
            assert isinstance(path, str)
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('historical_duplicate_breakdown=both_sources=1, csv_only=0, docx_only=0', text)
            self.assertIn('historical_duplicate_examples=22222|02-19-2026(csv=2,docx=2)', text)

    def test_collect_db_enrichment_summary_distinguishes_overlap_from_historical_duplicates(self):
        from MediCafe import cloud_readiness_patient_tools as pt
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            os.makedirs(os.path.join(lab, 'reports'))
            db_path = self._seed_lab_db(lab)
            conn = sqlite3.connect(db_path)
            conn.execute("PRAGMA foreign_keys = ON")
            conn.execute(
                "UPDATE ingest_artifact SET source_type = 'file_csv' WHERE artifact_id IN (1,2,3)"
            )
            conn.execute(
                "UPDATE extracted_canonical_record SET canonical_json = ? WHERE canonical_record_id = 1",
                ('{"Patient ID":"22222","Surgery Date":"02/19/2026"}',)
            )
            conn.execute(
                "UPDATE extracted_canonical_record SET canonical_json = ? WHERE canonical_record_id = 2",
                ('{"Patient ID":"22222","Surgery Date":"02/19/2026"}',)
            )
            conn.execute(
                "INSERT INTO ingest_artifact "
                "(artifact_id, ingest_key, source_system, source_type, source_ref, payload_json, ingest_status) "
                "VALUES (4, 'k4', 'xp_local', 'file_docx', 's4', '{}', 'projected')"
            )
            conn.execute(
                "INSERT INTO ingest_artifact "
                "(artifact_id, ingest_key, source_system, source_type, source_ref, payload_json, ingest_status) "
                "VALUES (5, 'k5', 'xp_local', 'file_docx', 's5', '{}', 'projected')"
            )
            conn.execute(
                "INSERT INTO extracted_canonical_record "
                "(canonical_record_id, artifact_id, canonical_type, canonical_key, extractor_version, canonical_json, provenance_json) "
                "VALUES (4, 4, 'docx_schedule', 'sched-1', 'canon_v1', '{\"patient_id\":\"22222\",\"schedule_key\":\"2026-02-19\"}', '{\"patient_id\":\"22222\",\"schedule_key\":\"2026-02-19\"}')"
            )
            conn.execute(
                "INSERT INTO extracted_canonical_record "
                "(canonical_record_id, artifact_id, canonical_type, canonical_key, extractor_version, canonical_json, provenance_json) "
                "VALUES (5, 5, 'docx_schedule', 'sched-2', 'canon_v1', '{\"patient_id\":\"22222\",\"schedule_key\":\"2026-02-19\"}', '{\"patient_id\":\"22222\",\"schedule_key\":\"2026-02-19\"}')"
            )
            conn.commit()
            conn.close()
            summary = pt.collect_db_enrichment_summary(lab)
            self.assertTrue(summary.get('ok'))
            self.assertEqual(summary.get('ingest_source_type_counts', {}).get('csv'), 3)
            self.assertEqual(summary.get('ingest_source_type_counts', {}).get('docx'), 2)
            join = summary.get('csv_docx_join', {})
            self.assertEqual(join.get('csv_candidate_count'), 2)
            self.assertEqual(join.get('docx_candidate_count'), 2)
            self.assertEqual(join.get('overlap_join_key_count'), 1)
            self.assertEqual(join.get('csv_only_join_key_count'), 0)
            self.assertEqual(join.get('docx_only_join_key_count'), 0)
            self.assertEqual(join.get('historical_duplicate_key_count'), 1)
            self.assertEqual(join.get('ambiguous_count'), 0)
            examples = join.get('historical_duplicate_examples', [])
            self.assertEqual(len(examples), 1)
            self.assertEqual(examples[0].get('join_key'), '22222|02-19-2026')
            self.assertEqual(examples[0].get('csv_count'), 2)
            self.assertEqual(examples[0].get('docx_count'), 2)

    def test_open_latest_data_plane_audit_report_returns_latest_file(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            self._seed_lab_db(lab)
            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({'pipeline_state': 'idle', 'last_shadow_pipeline_run_id': '20260219-071129-5d5c869f'}, f)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok_gen, _, path_gen = cr.open_data_plane_audit_report(repo, report_type='overview', limit=10)
                ok_latest, msg_latest, path_latest = cr.open_latest_data_plane_audit_report(repo, report_type='overview')
            self.assertTrue(ok_gen)
            self.assertTrue(path_gen and os.path.exists(path_gen))
            self.assertTrue(ok_latest)
            self.assertEqual(msg_latest, '')
            assert isinstance(path_latest, str)
            self.assertTrue(os.path.exists(path_latest))
            self.assertTrue(os.path.basename(path_latest).startswith('db_data_audit_overview_'))

    def test_open_data_plane_audit_report_uses_version_scoped_quality_counters(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            db_path = self._seed_lab_db(lab)

            conn = sqlite3.connect(db_path)
            conn.execute("PRAGMA foreign_keys = ON")
            conn.execute(
                "INSERT INTO qa_result "
                "(qa_result_id, artifact_id, qa_stage, qa_version, status, reject_code, reject_reason, deterministic_key) "
                "VALUES (2, 2, 'phase_d', 'qa_v2', 'reject', 'QA_REQUIRED', 'missing patient id', 'd2')"
            )
            conn.execute(
                "INSERT INTO projection_result "
                "(projection_id, canonical_record_id, projection_type, projection_version, projection_status, projected_json) "
                "VALUES (3, 1, 'patient_v1', 'proj_v2', 'success', '{\"external_patient_id\":\"22222\"}')"
            )
            conn.execute(
                "INSERT INTO projection_result "
                "(projection_id, canonical_record_id, projection_type, projection_version, projection_status, projected_json) "
                "VALUES (4, 2, 'patient_v1', 'proj_v2', 'rejected', '{\"reject_reason\":\"missing_required_fields\"}')"
            )
            conn.commit()
            conn.close()

            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'idle',
                    'last_shadow_pipeline_run_id': '20260219-071129-5d5c869f',
                    'last_qa_policy_version': 'qa_v2',
                    'last_projection_version': 'proj_v2',
                }, f)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, path = cr.open_data_plane_audit_report(repo, report_type='overview', limit=20)
            self.assertTrue(ok)
            self.assertIn('report generated', msg.lower())
            assert isinstance(path, str)
            self.assertTrue(os.path.exists(path))
            with open(path, 'r', encoding='utf-8') as f:
                text = f.read()
            self.assertIn('qa_reject_count=1 (qa_version=qa_v2, raw=2)', text)
            self.assertIn('projection_success_count=1 (projection_version=proj_v2, raw=2)', text)
            self.assertIn('projection_reject_count=1 (projection_version=proj_v2, raw=2)', text)

    def test_get_patient_flow_reference_options_collapses_to_latest_identity_row(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            db_path = self._seed_lab_db(lab)

            conn = sqlite3.connect(db_path)
            conn.execute("PRAGMA foreign_keys = ON")
            conn.execute(
                "INSERT INTO patient "
                "(patient_id, patient_key, external_patient_id, full_name, birth_date, source_system) "
                "VALUES (4, 'pk-risk-v2', '11111', 'Updated Risk Patient', '1971-01-01', 'xp_local')"
            )
            conn.execute(
                "INSERT INTO extracted_canonical_record "
                "(canonical_record_id, artifact_id, canonical_type, canonical_key, extractor_version, canonical_json, provenance_json) "
                "VALUES (3, 3, 'patient_csv_row', 'pk-risk-v2', 'canon_v1', '{}', '{}')"
            )
            conn.execute(
                "INSERT INTO projection_result "
                "(projection_id, canonical_record_id, projection_type, projection_version, projection_status, projected_json) "
                "VALUES (3, 3, 'patient_v1', 'proj_v2', 'success', '{\"external_patient_id\":\"11111\"}')"
            )
            conn.commit()
            conn.close()

            with open(os.path.join(lab, 'diagnostics_state.json'), 'w', encoding='utf-8') as f:
                json.dump({
                    'pipeline_state': 'idle',
                    'last_shadow_pipeline_run_id': '20260219-071129-5d5c869f',
                    'last_projection_version': 'proj_v2',
                }, f)
            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                ok, msg, data = cr.get_patient_flow_reference_options(repo, limit=20)
            self.assertTrue(ok)
            self.assertIn('options ready', msg.lower())
            assert isinstance(data, dict)
            options = data.get('options', [])
            matches = [x for x in options if str(x.get('patient_ref', '')) == '11111']
            self.assertEqual(len(matches), 1)
            self.assertEqual(matches[0].get('full_name'), 'Updated Risk Patient')



class TestConsolidatedHealthPhaseFAppendix(unittest.TestCase):
    def test_phase_f_fail_uses_stub_not_stale_latest(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            old_txt = os.path.join(reports, 'shadow_run_report_oldrun.txt')
            with open(old_txt, 'w', encoding='utf-8') as f:
                f.write('Shadow Run Report (Phase F)\nrun_id: oldrun\npipeline_ok: True\n')
            diag = os.path.join(lab, 'diagnostics_state.json')
            with open(diag, 'w', encoding='utf-8') as f:
                json.dump({
                    'last_shadow_pipeline_run_id': 'newrun',
                    'last_shadow_pipeline_failed_phase': 'F',
                    'last_shadow_pipeline_error_code': 'PHASE_F_LOCK_FAIL',
                    'last_phase_f_lock_diag_path': 'phase_f_lock_diag_new.json',
                }, f)

            def env_flag(_n, default):
                return default

            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                with patch.object(cr, 'get_health_lines', return_value=['snapshot-line']):
                    ok, msg, path = cr.open_consolidated_health_report(repo, env_flag)
            self.assertTrue(ok)
            assert isinstance(path, str)
            with open(path, 'r', encoding='utf-8') as f:
                body = f.read()
            self.assertIn('No shadow_run_report_newrun.txt', body)
            self.assertNotIn('pipeline_ok: True', body)

    def test_prefers_shadow_report_for_expected_run_id(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            rid = 'expected-rid-1'
            path_txt = os.path.join(reports, 'shadow_run_report_{0}.txt'.format(rid))
            with open(path_txt, 'w', encoding='utf-8') as f:
                f.write('Shadow Run Report (Phase F)\nrun_id: {0}\nok\n'.format(rid))
            diag = os.path.join(lab, 'diagnostics_state.json')
            with open(diag, 'w', encoding='utf-8') as f:
                json.dump({'last_shadow_pipeline_run_id': rid}, f)

            def env_flag(_n, default):
                return default

            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                with patch.object(cr, 'get_health_lines', return_value=['h']):
                    ok, _, out = cr.open_consolidated_health_report(repo, env_flag)
            self.assertTrue(ok)
            assert isinstance(out, str)
            with open(out, 'r', encoding='utf-8') as f:
                body = f.read()
            self.assertIn('expected-rid-1', body)
            self.assertNotIn('WARNING:', body)

    def test_fallback_appendix_uses_latest_txt_when_json_is_newer(self):
        from MediCafe import cloud_readiness as cr
        with tempfile.TemporaryDirectory() as repo:
            lab = os.path.join(repo, 'lab')
            reports = os.path.join(lab, 'reports')
            os.makedirs(reports)
            txt_path = os.path.join(reports, 'shadow_run_report_oldrid.txt')
            with open(txt_path, 'w', encoding='utf-8') as f:
                f.write(
                    'Shadow Run Report (Phase F)\nrun_id: oldrid\n'
                    'UNIQUE_TXT_APPENDIX_MARKER\n'
                )
            json_path = os.path.join(reports, 'shadow_run_report_newrid.json')
            with open(json_path, 'w', encoding='utf-8') as f:
                f.write('{}')
            old = time.time() - 100
            os.utime(txt_path, (old, old))
            new = time.time() + 10
            os.utime(json_path, (new, new))
            diag = os.path.join(lab, 'diagnostics_state.json')
            with open(diag, 'w', encoding='utf-8') as f:
                json.dump({}, f)

            def env_flag(_n, default):
                return default

            with patch.object(cr, 'resolve_lab_root', return_value=lab):
                with patch.object(cr, 'get_health_lines', return_value=['snapshot']):
                    ok, _, out = cr.open_consolidated_health_report(repo, env_flag)
            self.assertTrue(ok)
            assert isinstance(out, str)
            with open(out, 'r', encoding='utf-8') as f:
                body = f.read()
            self.assertIn('Phase F detailed report', body)
            self.assertIn('UNIQUE_TXT_APPENDIX_MARKER', body)


