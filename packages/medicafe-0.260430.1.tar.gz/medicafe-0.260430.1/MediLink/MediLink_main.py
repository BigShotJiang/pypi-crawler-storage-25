# MediLink.py - Orchestrating script for MediLink operations
import csv, os, re, subprocess, sys, time
import threading
from datetime import datetime, timedelta

# Add workspace directory to Python path for MediCafe imports
current_dir = os.path.dirname(os.path.abspath(__file__))
workspace_dir = os.path.dirname(current_dir)
if workspace_dir not in sys.path:
    sys.path.insert(0, workspace_dir)

# Import centralized logging configuration and timing utils
try:
    from MediCafe.logging_config import PERFORMANCE_LOGGING
except ImportError:
    PERFORMANCE_LOGGING = False
try:
    from MediCafe.timing_utils import start_run, stage_timer, noop_timer, record_stage, is_timing_enabled, get_storage_path
except ImportError:
    start_run = None
    stage_timer = None

    class _NoopTimerFallback(object):
        """Matches MediCafe.timing_utils._NoopTimer for Pyright/with-statement checking."""

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            return False

    noop_timer = _NoopTimerFallback()
    record_stage = None
    is_timing_enabled = None
    get_storage_path = None

# Add timing for import phase
start_time = time.time()
if PERFORMANCE_LOGGING:
    print("Starting MediLink initialization...")


# Now import core utilities after path setup
from MediCafe.core_utils import get_config_loader_with_fallback, setup_module_paths, extract_medilink_config
from MediCafe.error_reporter import collect_support_bundle, capture_unhandled_traceback
from MediCafe.error_reporter import submit_support_bundle_email, list_queued_bundles, submit_all_queued_bundles, delete_all_queued_bundles
try:
    from MediCafe.action_intent import mark_user_exit as _mark_user_exit
except Exception:
    def _mark_user_exit(reason='user_exit'):
        return bool(False)
setup_module_paths(__file__)

# Import modules after path setup
import MediLink_Down
import MediLink_Up
import MediLink_DataMgmt
import MediLink_UI  # Import UI module for handling all user interfaces
import MediLink_PatientProcessor  # Import patient processing functions

# Use core utilities for standardized config loader
MediLink_ConfigLoader = get_config_loader_with_fallback()

import_time = time.time()
if PERFORMANCE_LOGGING:
    print("Import phase completed in {:.2f} seconds".format(import_time - start_time))

# NOTE: Configuration loading moved to function level to avoid import-time dependencies

# --- Safe logging helpers (XP/3.4.4 compatible) ---
def _safe_log(message, level="INFO"):
    """Attempt to log via MediLink logger, fallback to print on failure."""
    try:
        MediLink_ConfigLoader.log(message, level=level)
    except Exception:
        try:
            print(message)
        except Exception:
            pass

def _safe_debug(message):
    _safe_log(message, level="DEBUG")

# Import shared display utilities
try:
    from MediLink.MediLink_Display_Utils import print_error as _print_error, print_warning as _print_warning
except Exception:
    # Fallback if import fails
    def _print_error(message, sleep_seconds=3):
        try:
            print("\n" + "="*60)
            print("ERROR: {}".format(str(message) if message else ""))
            print("="*60)
            time.sleep(max(0, float(sleep_seconds)) if sleep_seconds else 3)
        except Exception:
            pass
    def _print_warning(message, sleep_seconds=3):
        try:
            print("\n" + "="*60)
            print("WARNING: {}".format(str(message) if message else ""))
            print("="*60)
            time.sleep(max(0, float(sleep_seconds)) if sleep_seconds else 3)
        except Exception:
            pass


def _refresh_deductible_cache_if_online(config):
    """Run the headless deductible cache builder when internet is available."""
    _safe_log("Deductible cache refresh check started (trigger: MediLink boot)", level="DEBUG")
    # Performance optimization: Check if cache was recently built (within last 24 hours)
    # This prevents redundant cache builds when CSV processing just completed
    # 24h threshold matches _RECENT_CACHE_MAX_AGE_HOURS used in MediLink_Deductible_v1_5
    _DEDUCTIBLE_REFRESH_SKIP_AGE_SECONDS = 24 * 3600
    try:
        from MediLink.insurance_type_cache import get_csv_dir_from_config, get_cache_path
        csv_dir = get_csv_dir_from_config(config) if get_csv_dir_from_config else ''
        if csv_dir:
            cache_path = get_cache_path(csv_dir)
            if cache_path and os.path.exists(cache_path):
                try:
                    cache_mtime = os.path.getmtime(cache_path)
                    time_since_update = time.time() - cache_mtime
                    if time_since_update < _DEDUCTIBLE_REFRESH_SKIP_AGE_SECONDS:
                        _safe_log("Deductible cache refresh skipped (cache built {} seconds ago)".format(
                            int(time_since_update)), level="DEBUG")
                        return
                    _safe_log("Deductible cache refresh: proceeding (cache file older than 24 hours, {}s)".format(
                        int(time_since_update)), level="DEBUG")
                except Exception:
                    # If mtime check fails, proceed with refresh
                    _safe_log("Deductible cache refresh: proceeding (cache mtime check failed)", level="DEBUG")
                    pass
            else:
                _safe_log("Deductible cache refresh: proceeding (cache file absent)", level="DEBUG")
        else:
            _safe_log("Deductible cache refresh: proceeding (no csv_dir from config)", level="DEBUG")
    except Exception as e:
        # If cache check fails, proceed with refresh
        _safe_log("Deductible cache refresh: proceeding (cache check failed: {})".format(e), level="DEBUG")
        pass
    
    _safe_log("Checking internet connectivity for cache refresh", level="DEBUG")
    try:
        online = MediLink_Up.check_internet_connection()
    except ImportError:
        # If core_utils is not available, this is a configuration issue
        # Log it but don't fail the cache refresh attempt
        _safe_log("Cannot check internet connectivity - core_utils not available. Skipping cache refresh.", level="DEBUG")
        return
    except Exception:
        # For other exceptions (network errors, etc.), assume offline
        online = False
    if not online:
        _safe_log("Deductible cache refresh skipped (offline). Connect to internet and restart to build cache.", level="DEBUG")
        return
    try:
        _safe_log("Importing deductible cache builder module", level="DEBUG")
        from MediLink.MediLink_Deductible_v1_5 import run_headless_batch, get_last_batch_status
        _safe_log("Starting headless deductible cache build", level="DEBUG")
        run_headless_batch(config)
        batch_status = {}
        try:
            batch_status = get_last_batch_status() or {}
        except Exception:
            batch_status = {}
        if batch_status.get("success") is False:
            _safe_log(
                "Deductible cache refresh completed with issues: {}.".format(batch_status.get("reason", "unknown")),
                level="WARNING"
            )
        else:
            _safe_log(
                "Deductible cache refresh completed successfully ({} patient(s) refreshed).".format(
                    batch_status.get("patients_refreshed", 0)
                ),
                level="INFO"
            )
    except Exception as exc:
        _safe_log("Deductible cache refresh failed: {}. Check logs for details.".format(exc), level="INFO")

# TODO There needs to be a crosswalk auditing feature right alongside where all the names get fetched during initial startup maybe? 
# Vision:
# - Fast audit pass on startup with 3s timeout: report missing names/IDs, do not block.
# - Allow manual remediation flows for Medisoft IDs; only call APIs when beneficial (missing names).
# - XP note: default to console prompts; optional UI later.
# This already happens when MediLink is opened.

# Simple in-process scheduler for ack polls
_last_ack_updated_at = None
_scheduled_ack_checks = []  # list of epoch timestamps
_scheduled_ack_checks_lock = threading.Lock()  # Lock to protect _scheduled_ack_checks from race conditions
_boot_ack_new_records = False
_boot_ack_notification_shown = False

# Remittance check serialization: only one check (boot or menu) runs at a time.
_remittance_check_lock = threading.Lock()
_boot_remittance_completed_at = None  # time when boot remittance check finished; set while holding lock
REMITTANCE_CHECK_WAIT_TIMEOUT = 300   # seconds to wait for in-progress check when user selects (1)
REMITTANCE_RECENT_BOOT_WINDOW = 300   # seconds; if boot completed within this window, menu (1) reuses result (no second run)

def _attempt_cache_build(config):
    """
    Attempt to build the insurance type cache.
    Returns (success: bool, error_message: str or None)
    """
    try:
        _safe_log("Attempting auto-build of insurance type cache", level="INFO")
        try:
            online = MediLink_Up.check_internet_connection()
        except ImportError:
            # If core_utils is not available, this is a configuration issue
            _safe_log("Cannot check internet connectivity - core_utils not available. Skipping cache build.", level="WARNING")
            return False, "Configuration issue - cannot check internet connectivity"
        if not online:
            _safe_log("Cache auto-build skipped: offline", level="INFO")
            return False, "Offline - cannot build cache without internet connection"
        
        from MediLink.MediLink_Deductible_v1_5 import run_headless_batch
        _safe_log("Starting cache auto-build", level="INFO")
        run_headless_batch(config)
        _safe_log("Cache auto-build completed successfully", level="INFO")
        return True, None
    except Exception as exc:
        error_msg = str(exc)
        _safe_log("Cache auto-build failed: {}".format(error_msg), level="ERROR")
        return False, error_msg

def _report_cache_build_failure(error_message):
    """
    Submit error report for cache build failure via MediCafe error reporting.
    Continues execution regardless of report success/failure.
    
    Args:
        error_message: Error message from the failed cache build attempt
    """
    try:
        if collect_support_bundle is None or submit_support_bundle_email is None:
            _safe_log("Error reporting not available for cache build failure", level="WARNING")
            return
        
        _safe_log("Collecting error report for cache build failure: {}".format(error_message), level="INFO")
        zip_path = collect_support_bundle(include_traceback=True)
        if not zip_path:
            _safe_log("Failed to create error report bundle for cache build failure", level="WARNING")
            return
        
        try:
            online = MediLink_Up.check_internet_connection()
        except ImportError:
            # If core_utils is not available, this is a configuration issue
            # Assume offline to preserve the error bundle
            online = False
            print("Warning: Could not check internet connectivity - preserving error bundle.")
        except Exception:
            # For other exceptions (network errors, etc.), assume offline
            online = False
        
        if online:
            success = submit_support_bundle_email(zip_path)
            if success:
                try:
                    os.remove(zip_path)
                    _safe_log("Error report for cache build failure submitted successfully", level="INFO")
                except Exception:
                    pass
            else:
                _safe_log("Error report send failed - bundle preserved at {} for retry".format(zip_path), level="WARNING")
        else:
            _safe_log("Offline - error bundle queued at {} for retry when online".format(zip_path), level="INFO")
    except Exception as report_exc:
        _safe_log("Error report collection failed for cache build failure: {}".format(str(report_exc)), level="WARNING")

def _check_cache_status(config):
    """
    Check cache status and attempt auto-build if needed.
    Distinguishes between missing cache, empty cache, and recently updated cache.
    Submits error report if auto-build fails, but continues execution.
    """
    try:
        from MediLink.insurance_type_cache import get_csv_dir_from_config, load_cache, get_cache_path
        csv_dir = get_csv_dir_from_config(config) if get_csv_dir_from_config else ''
        if not csv_dir:
            _safe_log("Cache status check skipped: csv_dir is empty", level="INFO")
            return
        cache_path = get_cache_path(csv_dir)
        cache_exists = os.path.exists(cache_path) if cache_path else False

        cache_dict = load_cache(csv_dir)
        patient_count = len(cache_dict.get('by_patient_id', {}))

        _safe_log("Cache status: file exists={}, patients in cache={}, directory='{}'".format(
            cache_exists, patient_count, csv_dir), level="INFO")

        # Check if cache was recently updated (within last 5 minutes) - indicates cache build just ran
        cache_recently_updated = False
        if cache_exists and cache_dict:
            try:
                last_updated_str = cache_dict.get('lastUpdated', '')
                if last_updated_str:
                    last_updated = datetime.strptime(last_updated_str, '%Y-%m-%dT%H:%M:%SZ')
                    time_diff = datetime.utcnow() - last_updated
                    cache_recently_updated = time_diff.total_seconds() < 300  # 5 minutes
            except Exception:
                pass

        # Helper function to handle build result
        def _handle_build_result(build_success, error_msg):
            """Handle the result of a cache build attempt."""
            if build_success:
                # Re-check cache status after build
                cache_dict = load_cache(csv_dir)
                patient_count = len(cache_dict.get('by_patient_id', {}))
                if patient_count > 0:
                    _safe_log("Cache build completed successfully. {} patients in cache.".format(patient_count), level="INFO")
                else:
                    _print_warning("Build attempt just completed but found no valid patients. Check CSV file and payer ID configuration. Claims will default to code 12.")
            else:
                # Build failed - submit error report and continue
                _print_warning("Cache build failed: {}. Error report submitted. Claims will default to code 12.".format(error_msg))
                _report_cache_build_failure(error_msg)

        # Handle different scenarios
        if not cache_exists:
            # Cache file missing - attempt auto-build
            _print_warning("Insurance type cache is missing. Attempting auto-build...")
            build_success, error_msg = _attempt_cache_build(config)
            _handle_build_result(build_success, error_msg)
        elif patient_count == 0:
            # Cache exists but is empty
            if cache_recently_updated:
                # Cache was just built but found no patients - likely CSV/payer ID issue
                _print_warning("Detected recently built cache with no valid patients. Check CSV file and payer ID configuration. Claims will default to code 12.")
            else:
                # Cache exists but is old and empty - attempt auto-build
                _print_warning("Insurance type cache is empty. Attempting auto-build...")
                build_success, error_msg = _attempt_cache_build(config)
                _handle_build_result(build_success, error_msg)
        # If cache exists and has patients, no action needed
    except Exception as e:
        _safe_log("Cache status check error: {}".format(str(e)), level="WARNING")

def _normalize_contextual_date_to_iso(date_value):
    """Best-effort date normalization for contextual deductible review."""
    if not date_value:
        return ''
    if isinstance(date_value, datetime):
        return date_value.strftime('%Y-%m-%d')
    raw = str(date_value).strip()
    if not raw:
        return ''
    for fmt in ('%Y-%m-%d', '%m-%d-%Y', '%m/%d/%Y', '%m.%d.%Y', '%m-%d-%y', '%m/%d/%y', '%m.%d.%y'):
        try:
            parsed = datetime.strptime(raw, fmt)
            return parsed.strftime('%Y-%m-%d')
        except Exception:
            continue
    return raw


def _normalize_match_token(value, lowercase=True):
    text = str(value or '').strip()
    if not text:
        return ''
    text = " ".join(text.split())
    return text.lower() if lowercase else text


def _normalize_match_family_key(value):
    raw = str(value or '').strip()
    if not raw:
        return ''
    parts = [p.strip().lower() for p in raw.split('|')]
    return "|".join(parts)


def _build_row_match_keys(row):
    keys = set()
    if not isinstance(row, dict):
        return keys

    claim_key = _normalize_match_token(row.get('claim_key'))
    if claim_key:
        keys.add("claim|{}".format(claim_key))

    family_key = _normalize_match_family_key(row.get('family_key'))
    if family_key:
        keys.add("family|{}".format(family_key))

    dos = _normalize_contextual_date_to_iso(
        row.get('dos') or row.get('_display_dos') or row.get('service_start_date')
    )
    dos_norm = _normalize_match_token(dos)

    patient_ids = [
        row.get('patient_id'),
        row.get('_display_patient_id'),
        row.get('member_id'),
        row.get('patid'),
    ]
    payers = [
        row.get('payer_id'),
        row.get('_display_payer'),
        row.get('primary_insurance'),
    ]
    patient_name = _normalize_match_token(
        row.get('patient_name') or row.get('_display_patient_name')
    )

    for pid in patient_ids:
        pid_norm = _normalize_match_token(pid)
        if pid_norm and dos_norm:
            keys.add("pid_dos|{}|{}".format(pid_norm, dos_norm))
            for payer in payers:
                payer_norm = _normalize_match_token(payer)
                if payer_norm:
                    keys.add("pid_payer_dos|{}|{}|{}".format(pid_norm, payer_norm, dos_norm))

    if patient_name and dos_norm:
        keys.add("name_dos|{}|{}".format(patient_name, dos_norm))

    return keys


def _build_patient_data_match_keys(data):
    keys = set()
    if not isinstance(data, dict):
        return keys

    claim_key = _normalize_match_token(data.get('claim_key'))
    if claim_key:
        keys.add("claim|{}".format(claim_key))

    dos = _normalize_contextual_date_to_iso(
        data.get('surgery_date_iso') or data.get('surgery_date')
    )
    dos_norm = _normalize_match_token(dos)

    patient_ids = [
        data.get('patient_id'),
        data.get('patid'),
        data.get('member_id'),
    ]
    payers = [
        data.get('payer_id'),
        data.get('primary_insurance'),
    ]
    patient_name = _normalize_match_token(data.get('patient_name'))

    for pid in patient_ids:
        pid_norm = _normalize_match_token(pid)
        if pid_norm and dos_norm:
            keys.add("pid_dos|{}|{}".format(pid_norm, dos_norm))
            for payer in payers:
                payer_norm = _normalize_match_token(payer)
                if payer_norm:
                    keys.add("pid_payer_dos|{}|{}|{}".format(pid_norm, payer_norm, dos_norm))

    if patient_name and dos_norm:
        keys.add("name_dos|{}|{}".format(patient_name, dos_norm))

    # Build family key from available patient/payer/dos combinations.
    for pid in patient_ids:
        pid_norm = _normalize_match_token(pid)
        if not pid_norm or not dos_norm:
            continue
        for payer in payers:
            payer_norm = _normalize_match_token(payer)
            if not payer_norm:
                continue
            keys.add("family|{}|{}|{}".format(pid_norm, payer_norm, dos_norm))

    return keys


def _resolve_consolidated_rows_cached(config, cache_state, force_refresh=False):
    """
    Return consolidated latest-variant rows using a simple cache-state dict.

    cache_state keys:
      - rows: list
      - cached_at: float epoch
      - ttl_seconds: float
    """
    if not isinstance(cache_state, dict):
        cache_state = {}
    rows = cache_state.get('rows') or []
    cached_at = float(cache_state.get('cached_at') or 0.0)
    ttl_seconds = float(cache_state.get('ttl_seconds') or 300.0)
    now_ts = time.time()
    cache_fresh = bool(rows) and ((now_ts - cached_at) < ttl_seconds)
    if cache_fresh and not force_refresh:
        return rows

    resolved = []
    health = {}
    try:
        from MediCafe.submission_query import (
            get_consolidated_latest_variants_from_all_sources,
            get_last_submission_index_health,
        )
        resolved = get_consolidated_latest_variants_from_all_sources(
            config,
            days=120,
            limit=200
        )
        health = get_last_submission_index_health()
    except Exception as e:
        _safe_log("Consolidated latest-variant query failed: {}".format(e), level="WARNING")
        resolved = []
        health = {}

    cache_state['rows'] = resolved
    cache_state['cached_at'] = now_ts
    cache_state['ttl_seconds'] = ttl_seconds
    cache_state['index_health'] = health if isinstance(health, dict) else {}
    return resolved


_DAT_TS_TOKEN = re.compile(r'_(\d{8}_\d{6})$')


def _filename_ts_token_from_path(path):
    """Return YYYYMMDD_HHMMSS token from basename if present (e.g. ``..._20260115_143022.dat``)."""
    try:
        base = os.path.splitext(os.path.basename(path))[0]
    except Exception:
        return ''
    m = _DAT_TS_TOKEN.search(base)
    return m.group(1) if m else ''


def _max_dat_mtime_in_paths(paths):
    """Newest modification time among existing .dat paths in paths (0.0 if none)."""
    mx = 0.0
    for p in paths or []:
        if not isinstance(p, str) or not p.lower().endswith('.dat'):
            continue
        try:
            if os.path.isfile(p):
                mx = max(mx, float(os.path.getmtime(p)))
        except Exception:
            continue
    return mx


def _resolve_current_export_dat_files(files_snapshot, preferred_paths=None, batch_window_seconds=120.0):
    """
    Narrow directory-wide detection to the current Medisoft export batch.

    Resolution order:
    1. Paths from ``detect_new_files`` that were just renamed in this run (``preferred_paths``),
       intersected with ``files_snapshot``.
    2. Else, all ``.dat`` files whose basename shares the lexicographically greatest
       ``_YYYYMMDD_HHMMSS`` suffix (one export batch sharing one timestamp).
    3. Else (no timestamp tokens), the single newest file by mtime (avoids mixing rapid
       re-exports that fell within a broad mtime window).

    ``batch_window_seconds`` is retained for API compatibility; mtime clustering is no longer used.
    """
    del batch_window_seconds  # unused; callers/tests may still pass it

    def _norm_key(p):
        try:
            return os.path.normcase(os.path.normpath(os.path.abspath(p)))
        except Exception:
            return None

    existing = []
    seen = set()
    for f in files_snapshot or []:
        if not isinstance(f, str) or not f.lower().endswith('.dat'):
            continue
        try:
            ap = os.path.normpath(os.path.abspath(f))
        except Exception:
            continue
        if not os.path.isfile(ap):
            continue
        nk = _norm_key(ap)
        if not nk or nk in seen:
            continue
        seen.add(nk)
        existing.append(ap)

    if not existing:
        return []

    if preferred_paths:
        norm_to_ap = {}
        for ap in existing:
            nk = _norm_key(ap)
            if nk:
                norm_to_ap[nk] = ap
        picked = []
        seen_pick = set()
        for pp in preferred_paths:
            if not isinstance(pp, str) or not pp.lower().endswith('.dat'):
                continue
            nk = _norm_key(pp)
            if nk and nk in norm_to_ap and nk not in seen_pick:
                seen_pick.add(nk)
                picked.append(norm_to_ap[nk])
        if picked:
            return picked

    tokens = []
    for ap in existing:
        tok = _filename_ts_token_from_path(ap)
        if tok:
            tokens.append((ap, tok))
    if tokens:
        max_tok = max(t for _, t in tokens)
        return [ap for ap, t in tokens if t == max_tok]

    scored = []
    for ap in existing:
        try:
            mt = os.path.getmtime(ap)
        except Exception:
            continue
        scored.append((ap, mt))
    if not scored:
        return []
    scored.sort(key=lambda x: x[1], reverse=True)
    return [scored[0][0]]


def _should_force_consolidated_refresh_on_submit(flagged_snapshot, cache_state, newest_dat_mtime):
    """
    Refresh consolidated rows when detection flagged a rename, or when any .dat is newer
    than the last submit visit (catches timestamped exports without file_flagged).
    """
    if flagged_snapshot:
        return True
    if not isinstance(cache_state, dict):
        return False
    try:
        prev = float(cache_state.get('submit_dat_seen_mtime') or 0.0)
    except Exception:
        prev = 0.0
    try:
        cur = float(newest_dat_mtime or 0.0)
    except Exception:
        cur = 0.0
    return cur > prev


def _maybe_notify_submission_index_health(cache_state, notice_state):
    """
    Print/log a one-time operator notice when submission_index.jsonl is degraded.
    """
    if not isinstance(cache_state, dict) or not isinstance(notice_state, dict):
        return False
    if notice_state.get('submission_index_health'):
        return False
    health = cache_state.get('index_health') or {}
    try:
        from MediCafe.submission_query import build_submission_index_health_notice
        notice = build_submission_index_health_notice(health)
    except Exception:
        notice = None
    if not notice:
        return False

    from MediCafe.operator_notices import emit_once_notice
    return emit_once_notice(
        notice_state,
        'submission_index_health',
        notice.get('operator_notice') or "",
        "Submit claims: {}.".format(
            notice.get('log_message') or "submission index health degraded"
        ),
        emit_print=print,
        emit_log=lambda msg: _safe_log(msg, level="WARNING"),
    )


def _get_submission_index_health_notice(cache_state):
    if not isinstance(cache_state, dict):
        return None
    health = cache_state.get('index_health') or {}
    try:
        from MediCafe.submission_query import build_submission_index_health_notice
        return build_submission_index_health_notice(health)
    except Exception:
        return None


def _scan_json_health(config, cache_state, notice_state, force_refresh=False, emit_notice=True):
    """
    Run lightweight JSON health scan for submit flow.
    """
    if not isinstance(cache_state, dict):
        return {}
    cached = cache_state.get('json_health')
    if (
        (not force_refresh)
        and isinstance(cached, dict)
        and cached.get('scan_id')
    ):
        return cached
    try:
        from MediCafe.json_health import run_json_health_scan, build_json_health_notice
        summary = run_json_health_scan(
            config=config,
            artifact_keys=['submission_index'],
            persist=True,
        )
        cache_state['json_health'] = summary
        notice = build_json_health_notice(summary)
        if emit_notice and notice:
            from MediCafe.operator_notices import emit_once_notice
            emit_once_notice(
                notice_state,
                'json_health',
                notice.get('operator_notice') or '',
                "Submit claims: {}.".format(notice.get('log_message') or 'json health degraded'),
                emit_print=print,
                emit_log=lambda msg: _safe_log(msg, level="WARNING"),
            )
        return summary
    except Exception as e:
        try:
            from MediCafe.operator_notices import safe_exception_token
            error_token = safe_exception_token(e)
        except Exception:
            error_token = 'Exception'
        _safe_log("Submit claims: json health scan failed: {}".format(error_token), level="WARNING")
        return {}


def _maybe_notify_combined_health(config, cache_state, notice_state, force_refresh=False):
    """
    Emit a single health notice per run by preferring JSON health notice and
    falling back to submission-index parse health notice.
    """
    if not isinstance(notice_state, dict):
        return False
    if notice_state.get('combined_health'):
        return False

    parse_notice = _get_submission_index_health_notice(cache_state)
    summary = _scan_json_health(
        config,
        cache_state,
        notice_state,
        force_refresh=force_refresh,
        emit_notice=False,
    )
    json_notice = None
    try:
        from MediCafe.json_health import build_json_health_notice
        json_notice = build_json_health_notice(summary)
    except Exception:
        json_notice = None

    notice = json_notice or parse_notice
    if not notice:
        return False

    from MediCafe.operator_notices import emit_once_notice
    return emit_once_notice(
        notice_state,
        'combined_health',
        notice.get('operator_notice') or "",
        "Submit claims: {}.".format(
            notice.get('log_message') or "submission index/json health degraded"
        ),
        emit_print=print,
        emit_log=lambda msg: _safe_log(msg, level="WARNING"),
    )


def _filter_detailed_data_by_consolidated_rows(detailed_patient_data, selected_rows):
    """
    Filter parsed patient rows down to operator-selected consolidated variants.
    Uses multi-key matching (claim_key, family key, patient/payer/DOS, fallback name+DOS)
    to remain resilient across mixed source formats.
    """
    if not detailed_patient_data or not selected_rows:
        return detailed_patient_data

    selected_keys = set()
    for row in selected_rows:
        selected_keys.update(_build_row_match_keys(row))

    if not selected_keys:
        return detailed_patient_data

    # Match in tiers to avoid broad fallback keys (name+dos) over-selecting rows.
    strong_keys = set([
        k for k in selected_keys
        if k.startswith('claim|') or k.startswith('family|') or k.startswith('pid_payer_dos|')
    ])
    medium_keys = set([k for k in selected_keys if k.startswith('pid_dos|')])
    weak_keys = set([k for k in selected_keys if k.startswith('name_dos|')])
    if not (strong_keys or medium_keys or weak_keys):
        medium_keys = set(selected_keys)

    def _run_match(target_keys):
        if not target_keys:
            return []
        out = []
        for data in detailed_patient_data:
            if not isinstance(data, dict):
                continue
            data_keys = _build_patient_data_match_keys(data)
            if data_keys and data_keys.intersection(target_keys):
                out.append(data)
        return out

    filtered = _run_match(strong_keys)
    if filtered:
        return filtered
    filtered = _run_match(medium_keys)
    if filtered:
        return filtered
    filtered = _run_match(weak_keys)
    return filtered


def _submission_results_have_success(submission_results):
    if not isinstance(submission_results, dict):
        return False
    for _endpoint, files in submission_results.items():
        if not isinstance(files, dict):
            continue
        for file_path, result in files.items():
            if isinstance(file_path, str) and file_path.startswith('_'):
                continue
            try:
                status, _message = result
            except Exception:
                status = False
            if status:
                return True
    return False


def _launch_claim_status_followup():
    """Open Claims Status from within MediLink without relying on launcher root."""
    try:
        rc = subprocess.call([sys.executable, '-m', 'MediCafe', 'claims_status'], cwd=workspace_dir)
    except Exception as exc:
        print("Error launching Claims Status: {}".format(exc))
        return 1
    if rc != 0:
        print("Claims Status exited with code {}".format(rc))
    return rc


def _launch_deductible_followup():
    """Open full deductible checker from within MediLink Claims."""
    try:
        rc = subprocess.call([sys.executable, '-m', 'MediCafe', 'deductible'], cwd=workspace_dir)
    except Exception as exc:
        print("Error launching Deductible checker: {}".format(exc))
        return 1
    if rc != 0:
        print("Deductible checker exited with code {}".format(rc))
    return rc


def _run_reconciliation_gate(config, context_label=''):
    """Run reconciliation gate inline so operators do not need to leave MediLink."""
    try:
        from MediCafe.reconciliation import (
            run_reconciliation,
            print_reconciliation_summary,
            write_reconciliation_artifacts,
            SEVERITY_PASS,
            SEVERITY_WARN,
            SEVERITY_FAIL,
        )
    except Exception as exc:
        print("Reconciliation gate is unavailable: {}".format(exc))
        return 1
    try:
        medi = extract_medilink_config(config) if extract_medilink_config else {}
        if not isinstance(medi, dict):
            medi = {}
        storage_path = medi.get('local_storage_path', '.') or '.'
        receipts_root = medi.get('local_claims_path', '') or storage_path
        if storage_path and not os.path.isabs(storage_path):
            storage_path = os.path.abspath(os.path.join(workspace_dir, storage_path))
        if receipts_root and not os.path.isabs(receipts_root):
            receipts_root = os.path.abspath(os.path.join(workspace_dir, receipts_root))
        if storage_path and not os.path.isdir(storage_path):
            try:
                os.makedirs(storage_path)
            except Exception:
                pass
        # Normalize paths back into config so reconciliation internals that resolve
        # ledger locations from config (e.g. submission_attempts) read the same roots.
        medi['local_storage_path'] = storage_path
        medi['local_claims_path'] = receipts_root
        config['MediLink_Config'] = medi
        if context_label:
            print("\nReconciliation gate ({})...".format(context_label))
        else:
            print("\nReconciliation gate...")
        result = run_reconciliation(config, receipts_root=receipts_root, storage_path=storage_path)
        severity = result.get('severity', SEVERITY_PASS)
        print_reconciliation_summary(result, storage_path)
        write_reconciliation_artifacts(result, storage_path)
        if severity == SEVERITY_FAIL:
            print("Reconciliation: attention required (FAIL severity).")
            return 1
        if severity == SEVERITY_WARN:
            print("Reconciliation: completed with warnings.")
            return 0
        print("Reconciliation: pass.")
        return 0
    except Exception as exc:
        print("Reconciliation execution error: {}".format(exc))
        return 1


def _claim_lifecycle_financial_menu(config):
    """
    Claim lifecycle submenu focused on in-flow financial decision support.
    """
    while True:
        MediLink_UI.display_section_header("Claim Lifecycle & Financial Operations")
        print("Use this menu to keep claim submission, status tracking, and financial")
        print("reconciliation in one flow. Contextual deductible review is still offered")
        print("during Submit claims step [3/6] for date-of-service aware candidates.\n")
        options = [
            "Claim Status follow-up",
            "Run reconciliation gate now",
            "Run full deductible checker",
        ]
        MediLink_UI.display_menu(options, zero_option='Back')
        choice = MediLink_UI.get_user_choice().strip()
        if choice == '0':
            break
        if choice == '1':
            _launch_claim_status_followup()
            continue
        if choice == '2':
            _run_reconciliation_gate(config, context_label='manual')
            MediLink_UI.prompt_press_enter_to_continue()
            continue
        if choice == '3':
            _launch_deductible_followup()
            continue
        MediLink_UI.display_invalid_choice()


def _prompt_post_submission_claim_status_followup():
    try:
        answer = input("Open Claim Status follow-up now? (y/N): ").strip().lower()
    except Exception:
        answer = ''
    if answer in ('y', 'yes'):
        return _launch_claim_status_followup()
    return 0


def _load_contextual_deductible_csv_rows(config):
    rows = []
    csv_path = config.get('CSV_FILE_PATH', '') if isinstance(config, dict) else ''
    if not csv_path or not os.path.exists(csv_path):
        return rows
    try:
        with open(csv_path, 'r') as handle:
            reader = csv.DictReader(handle)
            for row in reader:
                if isinstance(row, dict):
                    rows.append(row)
    except Exception as exc:
        _safe_log("Contextual deductible CSV read failed: {}".format(exc), level="WARNING")
    return rows


def _build_contextual_deductible_patient_tuples(prepared_data, config):
    candidate_dates_by_patid = {}
    for data in (prepared_data or []):
        if not isinstance(data, dict):
            continue
        patid = str(data.get('patid') or '').strip()
        if not patid:
            continue
        service_date_iso = _normalize_contextual_date_to_iso(data.get('surgery_date_iso') or data.get('surgery_date'))
        candidate_dates_by_patid.setdefault(patid, set()).add(service_date_iso or '')

    if not candidate_dates_by_patid:
        return []

    rows = _load_contextual_deductible_csv_rows(config)
    patients = []
    seen = set()
    for row in rows:
        patid = str(row.get('Patient ID 2') or row.get('Patient ID #2') or row.get('Patient ID') or '').strip()
        if not patid or patid not in candidate_dates_by_patid:
            continue
        service_date_iso = _normalize_contextual_date_to_iso(
            row.get('Surgery Date') or row.get('Service Date') or row.get('Date of Service') or row.get('DOS')
        )
        allowed_dates = candidate_dates_by_patid.get(patid) or set()
        if allowed_dates and '' not in allowed_dates and service_date_iso not in allowed_dates:
            continue
        dob = str(row.get('Patient DOB') or row.get('DOB') or '').strip()
        member_id = str(row.get('Primary Policy Number') or row.get('Ins1 Member ID') or row.get('Member ID') or '').strip()
        payer_id = str(row.get('Ins1 Payer ID') or row.get('Payer ID') or '').strip()
        if not (patid and dob and member_id):
            continue
        dedupe_key = (patid, dob, member_id, payer_id, service_date_iso)
        if dedupe_key in seen:
            continue
        seen.add(dedupe_key)
        patients.append((patid, dob, member_id, payer_id or None, service_date_iso or None))
    return patients


def _run_contextual_deductible_review(prepared_data, config):
    try:
        from MediLink.MediLink_Deductible_v1_5 import run_batch
    except Exception as exc:
        print("Deductible review is unavailable: {}".format(exc))
        MediLink_UI.prompt_press_enter_to_continue()
        return False

    patients = _build_contextual_deductible_patient_tuples(prepared_data, config)
    if not patients:
        print("No deductible review candidates matched the current CSV data.")
        MediLink_UI.prompt_press_enter_to_continue()
        return False

    print("Running deductible review for {} candidate(s)...".format(len(patients)))
    try:
        run_batch(patients, config, silent=False)
        print("Deductible review complete. Returning to claim preparation.")
        MediLink_UI.prompt_press_enter_to_continue()
        return True
    except Exception as exc:
        print("Deductible review failed: {}".format(exc))
        MediLink_UI.prompt_press_enter_to_continue()
        return False


def _maybe_offer_contextual_deductible_review(prepared_data, config):
    print("You can review deductibles for the current candidate set before insurance editing.")
    try:
        answer = input("Run eligibility / deductible review now? (y/N): ").strip().lower()
    except Exception:
        answer = ''
    if answer in ('y', 'yes'):
        return _run_contextual_deductible_review(prepared_data, config)
    return False


def _remittances_menu(config):
    """
    Remittances submenu: consolidated entry point for all remittance operations.
    
    Replaces separate "Check for new remittances" and "View remittance data" menu items.
    Provides:
    - Sync now (manual download/check)
    - View summary
    - View details
    - Connectivity diagnostics
    - Export
    """
    global _last_ack_updated_at, _boot_ack_new_records, _boot_ack_notification_shown, _boot_remittance_completed_at
    
    while True:
        MediLink_UI.display_section_header("Remittances")
        
        # Show notification if boot scan found new records (display once per menu entry)
        if _boot_ack_new_records and not _boot_ack_notification_shown:
            print("\nNOTE: New records were found during startup scan (see logs).")
            _boot_ack_notification_shown = True
        
        options = [
            "Sync now (full sync includes repair)",
            "View summary",
            "View details",
            "Claim Status follow-up",
            "Reconciliation gate (submission vs remittance)",
            "Connectivity diagnostics",
            "Export CSV",
        ]
        MediLink_UI.display_menu(options, zero_option='Back')
        choice = MediLink_UI.get_user_choice().strip()
        
        if choice == '0':
            break
        
        if choice == '1':
            # Sync now: manual check/download with full interactive flow
            # Serialize with boot remittance check: wait for in-progress check or reuse recent boot result.
            if not _remittance_check_lock.acquire(timeout=REMITTANCE_CHECK_WAIT_TIMEOUT):
                print("\nRemittance check is still running from startup. Try again in a moment.")
                continue
            try:
                # Manual sync now always performs the full sync + embedded repair path.
                result = MediLink_Down.check_for_new_remittances(
                    config,
                    is_boot_scan=False,
                    force_full_repair=True,
                )
                _last_ack_updated_at = int(time.time())
                _boot_remittance_completed_at = time.time()
                
                # If no records found, offer connectivity diagnostics
                if not result:
                    print("\nNo records found. Would you like to run connectivity diagnostics? (y/n): ", end="")
                    try:
                        diagnostic_choice = input().strip().lower()
                        if diagnostic_choice in ['y', 'yes']:
                            print("\nRunning connectivity diagnostics...")
                            connectivity_results = MediLink_Down.test_endpoint_connectivity(config)
                            MediLink_UI.display_connectivity_results(connectivity_results)
                    except Exception:
                        pass  # Ignore input errors
                
                # UX hint: suggest deeper United details
                try:
                    print("Tip: For United details, run the United Claims Status checker.")
                except Exception:
                    pass
                if result:
                    _run_reconciliation_gate(config, context_label='post-remittance-sync')
            finally:
                _remittance_check_lock.release()
        
        elif choice == '2':
            MediLink_UI.view_remittance_summary(config)
        
        elif choice == '3':
            MediLink_UI.view_remittance_details(config)
        
        elif choice == '4':
            _launch_claim_status_followup()
        
        elif choice == '5':
            _run_reconciliation_gate(config, context_label='manual-remittance')
            MediLink_UI.prompt_press_enter_to_continue()

        elif choice == '6':
            # Connectivity diagnostics
            print("\nRunning connectivity diagnostics...")
            try:
                connectivity_results = MediLink_Down.test_endpoint_connectivity(config)
                MediLink_UI.display_connectivity_results(connectivity_results)
            except Exception as e:
                print("Error running diagnostics: {}".format(e))
            MediLink_UI.prompt_press_enter_to_continue()
        
        elif choice == '7':
            MediLink_UI.export_remittance_data(config)
        
        else:
            MediLink_UI.display_invalid_choice()

def main_menu():
    """
    Initializes the main menu loop and handles the overall program flow,
    including loading configurations and managing user input for menu selections.
    """
    global _last_ack_updated_at, _scheduled_ack_checks, _boot_ack_notification_shown
    menu_start_time = time.time()

    _storage = get_storage_path(repo_root=workspace_dir) if get_storage_path else None
    run_id = start_run('medilink', storage_path=_storage) if (start_run and is_timing_enabled and is_timing_enabled()) else None
    if run_id and record_stage:
        record_stage(run_id, 'medilink', 'import_phase', int((import_time - start_time) * 1000))

    # Load configuration settings and display the initial welcome message.
    config_start_time = time.time()
    if PERFORMANCE_LOGGING:
        print("Loading configuration...")
    if run_id and stage_timer:
        with stage_timer(run_id, 'medilink', 'config_load'):
            config, crosswalk = MediLink_ConfigLoader.load_configuration()
    else:
        config, crosswalk = MediLink_ConfigLoader.load_configuration()
    config_end_time = time.time()
    if PERFORMANCE_LOGGING:
        print("Configuration loading completed in {:.2f} seconds".format(config_end_time - config_start_time))
    
    # Note: OPTUMAI payer list update is handled by launcher (primary entry point)
    # No need to check here since MediLink is typically launched from launcher
    # This eliminates redundant checks and reduces log noise
    
    # Check to make sure payer_id key is available in crosswalk, otherwise, go through that crosswalk initialization flow
    crosswalk_check_start = time.time()
    _ctx = stage_timer(run_id, 'medilink', 'crosswalk_validation') if (run_id and stage_timer) else noop_timer
    with _ctx:
        if 'payer_id' not in crosswalk:
            print("\n" + "="*60)
            print("SETUP REQUIRED: Payer Information Database Missing")
            print("="*60)
            print("\nThe system needs to build a database of insurance company information")
            print("before it can process claims. This is a one-time setup requirement.")
            print("\nThis typically happens when:")
            print("- You're running MediLink for the first time")
            print("- The payer database was accidentally deleted or corrupted")
            print("- You're using a new installation of the system")
            print("\nTO FIX THIS:")
            print("1. Open a command prompt/terminal")
            print("2. Navigate to the MediCafe directory")
            print("3. Run: python MediBot/MediBot_Preprocessor.py --update-crosswalk")
            print("4. Wait for the process to complete (this may take a few minutes)")
            print("5. Return here and restart MediLink")
            print("\nThis will download and build the insurance company database.")
            print("="*60)
            print("\nPress Enter to exit...")
            input()
            return  # Graceful exit instead of abrupt halt
    crosswalk_check_end = time.time()
    if PERFORMANCE_LOGGING:
        print("Crosswalk validation completed in {:.2f} seconds".format(crosswalk_check_end - crosswalk_check_start))

    # Check if the application is in test mode
    test_mode_start = time.time()
    _ctx2 = stage_timer(run_id, 'medilink', 'test_mode_check') if (run_id and stage_timer) else noop_timer
    with _ctx2:
        if config.get("MediLink_Config", {}).get("TestMode", False):
            print("\n--- MEDILINK TEST MODE --- \nTo enable full functionality, please update the config file \nand set 'TestMode' to 'false'.")
    test_mode_end = time.time()
    if PERFORMANCE_LOGGING:
        print("Test mode check completed in {:.2f} seconds".format(test_mode_end - test_mode_start))

    # Refresh deductible cache silently when online (non-blocking)
    def _refresh_cache_async():
        """Background function to refresh deductible cache without blocking menu."""
        try:
            _refresh_deductible_cache_if_online(config)
        except Exception as e:
            _safe_log("Deductible cache refresh failed: {}".format(e), level="WARNING")
    
    cache_thread = threading.Thread(target=_refresh_cache_async, daemon=True)
    cache_thread.start()

    # Boot-time one-time ack poll (non-blocking, no wait)
    # Check runs in background; result surfaced when user returns to menu.
    # Held under _remittance_check_lock so menu (1) can wait or reuse recent result.
    def _check_remittances_async():
        """Background function to check for remittances without blocking menu."""
        global _last_ack_updated_at, _boot_ack_new_records, _boot_remittance_completed_at
        _remittance_check_lock.acquire()
        try:
            got_new = MediLink_Down.check_for_new_remittances(config, is_boot_scan=True)
            _last_ack_updated_at = int(time.time())
            _boot_ack_new_records = bool(got_new)
            _boot_remittance_completed_at = time.time()
            _safe_log("Boot-time remittance check completed", level="INFO")
        except Exception as e:
            _boot_ack_new_records = False
            _safe_log("Boot-time remittance check failed: {}".format(e), level="WARNING")
        finally:
            _remittance_check_lock.release()
    
    # Start remittance check in background thread (never wait)
    remittance_thread = threading.Thread(target=_check_remittances_async, daemon=True)
    remittance_thread.start()
    _safe_log("Remittance check running in background", level="INFO")
    
    # Set default timestamp if check hasn't completed yet (use global variable directly)
    if _last_ack_updated_at is None:
        _last_ack_updated_at = int(time.time())

    # TODO: Once we start building out the whole submission tracking persist structure,
    # this boot-time scan should check when the last acknowledgement check was run
    # and skip if it was run recently (e.g., within the last day) to avoid
    # constantly running it on every startup. The submission tracking system should
    # store the timestamp of the last successful acknowledgement check and use it
    # to determine if a new scan is needed.

    # Clear screen before showing menu header
    try:
        os.system('cls' if os.name == 'nt' else 'clear')
    except Exception as e:
        _safe_debug("Clear screen failed: {}".format(e))  # Fallback if cls/clear fails

    # Display Welcome Message
    welcome_start = time.time()
    _ctx3 = stage_timer(run_id, 'medilink', 'welcome_display') if (run_id and stage_timer) else noop_timer
    with _ctx3:
        MediLink_UI.display_welcome()
    welcome_end = time.time()
    if PERFORMANCE_LOGGING:
        print("Welcome display completed in {:.2f} seconds".format(welcome_end - welcome_start))

    # Startup: (removed) automatic HTTP queue flush for error reports to simplify UX
    # Boot-time "New records" message is shown in menu loop when check completes (see _boot_ack_new_records).

    # Normalize the directory path for file operations.
    path_norm_start = time.time()
    _ctx4 = stage_timer(run_id, 'medilink', 'path_normalization') if (run_id and stage_timer) else noop_timer
    with _ctx4:
        medi = extract_medilink_config(config)
        input_file_path = medi.get('inputFilePath')
        if not input_file_path:
            raise ValueError("Configuration error: 'inputFilePath' missing in MediLink_Config")
        directory_path = os.path.normpath(input_file_path)
    path_norm_end = time.time()
    if PERFORMANCE_LOGGING:
        print("Path normalization completed in {:.2f} seconds".format(path_norm_end - path_norm_start))

    # NEW: Submission index upkeep (XP-safe, inline)
    try:
        receipts_root = medi.get('local_claims_path', None)
        if receipts_root:
            from MediCafe.submission_index import ensure_submission_index
            ensure_submission_index(os.path.normpath(receipts_root))
    except Exception:
        # Silent failure - do not block menu
        pass

    # Detect files and determine if a new file is flagged (non-blocking - defer to background)
    # Initialize with empty list - will be populated in background
    all_files = []
    file_flagged = False
    detection_preferred_paths = []
    _file_detection_complete = threading.Event()
    _file_detection_lock = threading.Lock()
    
    def _detect_files_async():
        """Background function to detect files without blocking menu."""
        nonlocal all_files, file_flagged, detection_preferred_paths
        try:
            file_detect_start = time.time()
            if PERFORMANCE_LOGGING:
                print("Starting file detection...")
            detected, flagged, preferred = MediLink_DataMgmt.detect_new_files(directory_path, run_id=run_id)
            file_detect_end = time.time()
            if run_id and record_stage:
                record_stage(run_id, 'medilink', 'file_detection', int((file_detect_end - file_detect_start) * 1000))
            if PERFORMANCE_LOGGING:
                print("File detection completed in {:.2f} seconds".format(file_detect_end - file_detect_start))
                print("Found {} files, flagged: {}".format(len(detected), flagged))
            MediLink_ConfigLoader.log("Found {} files, flagged: {}".format(len(detected), flagged), level="DEBUG")
            with _file_detection_lock:
                all_files, file_flagged, detection_preferred_paths = detected, flagged, preferred
                _file_detection_complete.set()
        except Exception as e:
            _safe_log("File detection failed: {}".format(e), level="WARNING")
            with _file_detection_lock:
                all_files = []
                file_flagged = False
                detection_preferred_paths = []
                _file_detection_complete.set()
    
    # Start file detection in background thread (never wait)
    file_detect_thread = threading.Thread(target=_detect_files_async, daemon=True)
    file_detect_thread.start()

    menu_init_end = time.time()
    if run_id and record_stage:
        record_stage(run_id, 'medilink', 'menu_init', int((menu_init_end - menu_start_time) * 1000))
    if PERFORMANCE_LOGGING:
        print("Main menu initialization completed in {:.2f} seconds".format(menu_init_end - menu_start_time))

    # Cache consolidated latest-variant rows for submit UX responsiveness.
    consolidated_cache_state = {
        'rows': [],
        'cached_at': 0.0,
        'ttl_seconds': 300.0,
        'index_health': {},
        'json_health': None,
    }
    submission_index_notice_state = {'shown': False}

    

    while True:
        # Run any due scheduled ack checks before showing menu (non-blocking)
        try:
            now_ts = int(time.time())
            # Use lock to safely read the list and identify due checks
            with _scheduled_ack_checks_lock:
                if _scheduled_ack_checks:
                    due = [t for t in _scheduled_ack_checks if t <= now_ts]
                    # Remove due timestamps immediately to prevent duplicate checks
                    if due:
                        _scheduled_ack_checks = [t for t in _scheduled_ack_checks if t > now_ts]
                else:
                    due = []
            
            if due:
                # Run scheduled check in background thread to avoid blocking menu
                def _scheduled_ack_check():
                    try:
                        print("\nAuto-checking acknowledgements (scheduled)...")
                        MediLink_Down.check_for_new_remittances(config, is_boot_scan=False)
                        global _last_ack_updated_at
                        _last_ack_updated_at = now_ts
                    except Exception as e:
                        _safe_log("Scheduled acknowledgements check failed: {}".format(e), level="WARNING")
                
                ack_thread = threading.Thread(target=_scheduled_ack_check, daemon=True)
                ack_thread.start()
                # Don't wait for completion - let it run in background
        except Exception as e:
            _safe_log("Scheduled acknowledgements check skipped: {}".format(e), level="WARNING")

        # Define static menu options for consistent numbering (Exit is always 0)
        options = ["Remittances", "Submit claims", "Tools"]

        # Display the menu options.
        menu_display_start = time.time()
        _ctx_menu = stage_timer(run_id, 'medilink', 'menu_display') if (run_id and stage_timer) else noop_timer
        with _ctx_menu:
            try:
                if _boot_ack_new_records and not _boot_ack_notification_shown:
                    _safe_log("New records were found during the boot-time acknowledgement scan. View via 'Remittances' menu.", level="INFO")
                    _boot_ack_notification_shown = True
            except Exception as e:
                _safe_debug("Boot ack notification check failed: {}".format(e))
            MediLink_UI.display_menu(options, zero_option='Exit')
        menu_display_end = time.time()
        if PERFORMANCE_LOGGING:
            print("Menu display completed in {:.2f} seconds".format(menu_display_end - menu_display_start))

        # Retrieve user choice and handle it.
        choice_start = time.time()
        _ctx_choice = stage_timer(run_id, 'medilink', 'user_choice') if (run_id and stage_timer) else noop_timer
        with _ctx_choice:
            choice = MediLink_UI.get_user_choice()
        choice_end = time.time()
        if PERFORMANCE_LOGGING:
            print("User choice retrieval completed in {:.2f} seconds".format(choice_end - choice_start))

        if choice == '0':
            MediLink_UI.display_exit_message()
            _mark_user_exit()
            break
        elif choice == '1':
            # Remittances menu
            _remittances_menu(config)
        elif choice == '2':
            # Wait briefly for file detection if still running (non-blocking check)
            if not _file_detection_complete.is_set():
                print("File detection in progress...")
                # Wait up to 2 seconds for file detection to complete
                _file_detection_complete.wait(timeout=2.0)
            # Read under lock to avoid race with background thread (timeout or mid-update)
            with _file_detection_lock:
                files_snapshot = list(all_files)
                flagged_snapshot = file_flagged
                preferred_snapshot = list(detection_preferred_paths)

            new_dat_milestone = _max_dat_mtime_in_paths(files_snapshot)
            force_refresh = _should_force_consolidated_refresh_on_submit(
                flagged_snapshot, consolidated_cache_state, new_dat_milestone
            )
            consolidated_rows = _resolve_consolidated_rows_cached(
                config, consolidated_cache_state, force_refresh=force_refresh
            )
            try:
                consolidated_cache_state['submit_dat_seen_mtime'] = float(new_dat_milestone or 0.0)
            except Exception:
                consolidated_cache_state['submit_dat_seen_mtime'] = new_dat_milestone
            _maybe_notify_combined_health(
                config,
                consolidated_cache_state,
                submission_index_notice_state,
                force_refresh=force_refresh,
            )

            dat_files_resolved = _resolve_current_export_dat_files(
                files_snapshot, preferred_paths=preferred_snapshot
            )
            dat_files_any = [
                f for f in (files_snapshot or [])
                if isinstance(f, str) and f.lower().endswith('.dat')
            ]
            selection_result = {'action': 'legacy', 'selected_rows': []}
            last_selector_scope = 'none'

            try:
                from MediCafe.submission_query import (
                    build_current_export_rows_from_dat_paths,
                    build_consolidated_latest_variants,
                )
            except Exception:
                build_current_export_rows_from_dat_paths = None
                build_consolidated_latest_variants = None

            current_rows = []
            if dat_files_resolved and build_current_export_rows_from_dat_paths and build_consolidated_latest_variants:
                raw_export = build_current_export_rows_from_dat_paths(
                    dat_files_resolved, config, include_file_fallback=False
                )
                if raw_export:
                    current_rows = build_consolidated_latest_variants([], [], raw_export)

            if dat_files_resolved and current_rows:
                last_selector_scope = 'current_export'
                while True:
                    selection_result = MediLink_UI.select_patients_from_consolidated_menu(
                        current_rows,
                        fallback_file_list=files_snapshot,
                        config=config,
                        table_title='Current Medisoft export',
                        preamble_kind='current_export',
                        allow_broad_activity=True,
                        broad_activity_available=bool(consolidated_rows),
                    )
                    if selection_result.get('action') == 'refresh':
                        raw_export = build_current_export_rows_from_dat_paths(
                            dat_files_resolved, config, include_file_fallback=False
                        )
                        current_rows = (
                            build_consolidated_latest_variants([], [], raw_export)
                            if raw_export else []
                        )
                        if not current_rows:
                            print("Current export list is empty after refresh.")
                        continue
                    if selection_result.get('action') == 'broad_activity' and consolidated_rows:
                        last_selector_scope = 'broad'
                        while True:
                            selection_result = MediLink_UI.select_patients_from_consolidated_menu(
                                consolidated_rows,
                                fallback_file_list=files_snapshot,
                                config=config,
                                table_title='Recent claim activity',
                                preamble_kind='broad',
                                allow_broad_activity=False,
                                broad_activity_available=False,
                            )
                            if selection_result.get('action') == 'refresh':
                                consolidated_rows = _resolve_consolidated_rows_cached(
                                    config, consolidated_cache_state, force_refresh=True
                                )
                                _maybe_notify_combined_health(
                                    config,
                                    consolidated_cache_state,
                                    submission_index_notice_state,
                                    force_refresh=True,
                                )
                                if not consolidated_rows:
                                    print("No consolidated rows available after refresh.")
                                    _safe_log(
                                        "Submit claims: consolidated rows unavailable after refresh.",
                                        level="INFO",
                                    )
                                continue
                            break
                        break
                    break
            elif dat_files_any and not current_rows:
                if build_current_export_rows_from_dat_paths and build_consolidated_latest_variants:
                    pe = MediLink_UI.prompt_current_export_parse_failure(bool(consolidated_rows))
                    if pe == 'broad' and consolidated_rows:
                        last_selector_scope = 'broad'
                        while True:
                            selection_result = MediLink_UI.select_patients_from_consolidated_menu(
                                consolidated_rows,
                                fallback_file_list=files_snapshot,
                                config=config,
                                table_title='Recent claim activity',
                                preamble_kind='broad',
                                allow_broad_activity=False,
                                broad_activity_available=False,
                            )
                            if selection_result.get('action') == 'refresh':
                                consolidated_rows = _resolve_consolidated_rows_cached(
                                    config, consolidated_cache_state, force_refresh=True
                                )
                                _maybe_notify_combined_health(
                                    config,
                                    consolidated_cache_state,
                                    submission_index_notice_state,
                                    force_refresh=True,
                                )
                                if not consolidated_rows:
                                    print("No consolidated rows available after refresh.")
                                continue
                            break
                    elif pe == 'legacy':
                        selection_result = {'action': 'legacy', 'selected_rows': []}
                    else:
                        selection_result = {'action': 'cancel', 'selected_rows': []}
                else:
                    selection_result = {'action': 'legacy', 'selected_rows': []}
            elif consolidated_rows:
                last_selector_scope = 'broad'
                while True:
                    selection_result = MediLink_UI.select_patients_from_consolidated_menu(
                        consolidated_rows,
                        fallback_file_list=files_snapshot,
                        config=config,
                        table_title='Recent claim activity',
                        preamble_kind='broad',
                        allow_broad_activity=False,
                        broad_activity_available=False,
                    )
                    if selection_result.get('action') == 'refresh':
                        consolidated_rows = _resolve_consolidated_rows_cached(
                            config, consolidated_cache_state, force_refresh=True
                        )
                        _maybe_notify_combined_health(
                            config,
                            consolidated_cache_state,
                            submission_index_notice_state,
                            force_refresh=True,
                        )
                        if not consolidated_rows:
                            print("No consolidated rows available after refresh.")
                            _safe_log(
                                "Submit claims: consolidated rows unavailable after user refresh; legacy fallback remains available.",
                                level="INFO"
                            )
                        continue
                    break
            else:
                _safe_log(
                    "Submit claims: consolidated rows unavailable (empty result); using legacy file behavior.",
                    level="INFO"
                )

            if (
                selection_result.get('action') == 'legacy_unusable'
                and dat_files_any
                and last_selector_scope == 'current_export'
            ):
                if build_current_export_rows_from_dat_paths and build_consolidated_latest_variants:
                    pe = MediLink_UI.prompt_current_export_parse_failure(bool(consolidated_rows))
                    if pe == 'broad' and consolidated_rows:
                        last_selector_scope = 'broad'
                        while True:
                            selection_result = MediLink_UI.select_patients_from_consolidated_menu(
                                consolidated_rows,
                                fallback_file_list=files_snapshot,
                                config=config,
                                table_title='Recent claim activity',
                                preamble_kind='broad',
                                allow_broad_activity=False,
                                broad_activity_available=False,
                            )
                            if selection_result.get('action') == 'refresh':
                                consolidated_rows = _resolve_consolidated_rows_cached(
                                    config, consolidated_cache_state, force_refresh=True
                                )
                                _maybe_notify_combined_health(
                                    config,
                                    consolidated_cache_state,
                                    submission_index_notice_state,
                                    force_refresh=True,
                                )
                                if not consolidated_rows:
                                    print("No consolidated rows available after refresh.")
                                continue
                            break
                    elif pe == 'legacy':
                        selection_result = {'action': 'legacy', 'selected_rows': []}
                    else:
                        selection_result = {'action': 'cancel', 'selected_rows': []}
                else:
                    selection_result = {'action': 'legacy', 'selected_rows': []}

            if selection_result.get('action') == 'cancel':
                print("Submission cancelled. No changes were made.")
                continue
            if selection_result.get('action') == 'legacy':
                _safe_log(
                    "Submit claims: operator selected legacy Z.DAT picker from consolidated selector.",
                    level="INFO"
                )
            elif selection_result.get('action') == 'legacy_unusable':
                _safe_log(
                    "Submit claims: consolidated rows present but lacked patient identity; using legacy file picker.",
                    level="INFO"
                )

            submission_start = time.time()
            _ctx_sub = stage_timer(run_id, 'medilink', 'submission_flow') if (run_id and stage_timer) else noop_timer
            with _ctx_sub:
                selected_rows = selection_result.get('selected_rows', [])
                selected_files = []

                if selection_result.get('action') == 'selected':
                    # Use DAT files linked to selected rows when available.
                    selected_dat_files = []
                    for row in selected_rows:
                        dat_file = row.get('dat_file') if isinstance(row, dict) else ''
                        if dat_file and os.path.exists(dat_file):
                            selected_dat_files.append(dat_file)
                    # De-duplicate while preserving order.
                    seen_files = set()
                    selected_dat_files_unique = []
                    for path in selected_dat_files:
                        if path not in seen_files:
                            seen_files.add(path)
                            selected_dat_files_unique.append(path)

                    if selected_dat_files_unique:
                        selected_files = selected_dat_files_unique
                    elif files_snapshot:
                        # Fallback: parse detected files and then filter by selected families.
                        selected_files = files_snapshot
                    else:
                        print("No claim source files found for consolidated selection.")
                        print("Verify input DAT files are available, then retry Submit claims.")
                        continue
                elif flagged_snapshot and files_snapshot:
                    selected_files = [max(files_snapshot, key=os.path.getctime)]
                else:
                    if not files_snapshot:
                        print("No claim source files found.")
                        print("Verify inputFilePath and source DAT exports, then retry Submit claims.")
                        continue
                    selected_files = MediLink_UI.user_select_files(files_snapshot)

                if not selected_files:
                    print("No files selected. Returning to main menu.")
                    continue

                _check_cache_status(config)
                patient_data_start = time.time()
                _ctx_pat = stage_timer(run_id, 'medilink', 'patient_data') if (run_id and stage_timer) else noop_timer
                with _ctx_pat:
                    detailed_patient_data = MediLink_PatientProcessor.collect_detailed_patient_data(selected_files, config, crosswalk)
                    if selection_result.get('action') == 'selected':
                        filtered_data = _filter_detailed_data_by_consolidated_rows(
                            detailed_patient_data,
                            selected_rows
                        )
                        if filtered_data:
                            detailed_patient_data = filtered_data
                        else:
                            print("No parsed patients matched the consolidated selection.")
                            print("Try selecting by broader criteria (name/date) or use legacy file picker.")
                            continue
                patient_data_end = time.time()
                if PERFORMANCE_LOGGING:
                    print("Patient data collection completed in {:.2f} seconds".format(patient_data_end - patient_data_start))
                submission_success = handle_submission(detailed_patient_data, config, crosswalk)
                if submission_success:
                    try:
                        now_ts2 = int(time.time())
                        with _scheduled_ack_checks_lock:
                            _scheduled_ack_checks.append(now_ts2 + 90)
                            _scheduled_ack_checks.append(now_ts2 + 7200)
                        print("Scheduled acknowledgements checks in 1-2 minutes and again ~2 hours.")
                        _prompt_post_submission_claim_status_followup()
                        # Reconciliation here is advisory decision support inside the same flow,
                        # not a hard block on operator continuation.
                        _run_reconciliation_gate(config, context_label='post-submit')
                    except Exception:
                        pass
            submission_end = time.time()
            if PERFORMANCE_LOGGING:
                print("Claims submission flow completed in {:.2f} seconds".format(submission_end - submission_start))
        elif choice == '3':
            MediLink_UI.tools_menu(config, medi, claims_ops_handler=lambda: _claim_lifecycle_financial_menu(config))
        else:
            # Display an error message if the user's choice does not match any valid option.
            MediLink_UI.display_invalid_choice()

def _print_submission_stage(step, total_steps, label):
    print("\n[{}/{} {}]".format(step, total_steps, label))


def prepare_submission_candidates(detailed_patient_data, config, crosswalk):
    """
    Prepare submission candidates before downstream editing/review.
    Ordering is intentionally early to minimize wasted user effort.

    Returns:
      - (filtered_candidates, crosswalk) on success
      - (None, crosswalk) when user cancels
    """
    _print_submission_stage(2, 6, "Retry filter")
    try:
        candidates = MediLink_UI.apply_retry_policy(detailed_patient_data, config)
        if candidates is None:
            print("Submission cancelled. No changes were made.")
            return None, crosswalk
        if not candidates:
            print("\nNo patients remain after retry filtering.")
            print("Try one of the following:")
            print("- Retry safe failures + rejected (277/999)")
            print("- Submit all for manual audit workflows")
            print("Returning to main menu.")
            return [], crosswalk
        return candidates, crosswalk
    except Exception as exc:
        _print_error("Retry analysis failed: {}. Submission cancelled to avoid unintended claim broadening.".format(exc), sleep_seconds=1)
        return None, crosswalk


def handle_submission(detailed_patient_data, config, crosswalk):
    """
    Handles the submission process for claims based on detailed patient data.
    This function orchestrates the flow from user decision on endpoint suggestions to the actual submission of claims.
    """
    _print_submission_stage(1, 6, "Parsed candidates")
    print("Patients parsed from selected file(s): {}".format(len(detailed_patient_data or [])))

    prepared_data, crosswalk = prepare_submission_candidates(detailed_patient_data, config, crosswalk)
    if prepared_data is None:
        return False
    if not prepared_data:
        return False

    insurance_edited = False  # Flag to track if insurance types were edited

    _print_submission_stage(3, 6, "Eligibility / Deductible review")
    _maybe_offer_contextual_deductible_review(prepared_data, config)

    _print_submission_stage(4, 6, "Insurance")
    # Ask the user if they want to edit insurance types
    edit_insurance = input("Do you want to edit insurance types? (y/n): ").strip().lower()
    if edit_insurance in ['y', 'yes', '']:
        insurance_edited = True  # User chose to edit insurance types

        # Get insurance options from config
        medi = extract_medilink_config(config)
        insurance_options = medi.get('insurance_options', {})

        while True:
            # Bulk edit insurance types
            MediLink_DataMgmt.bulk_edit_insurance_types(prepared_data, insurance_options)

            # Review and confirm changes
            if MediLink_DataMgmt.review_and_confirm_changes(prepared_data, insurance_options):
                break  # Exit the loop if changes are confirmed
            else:
                print("Returning to bulk edit insurance types.")

    _print_submission_stage(5, 6, "Endpoint review")
    # Initiate user interaction to confirm or adjust suggested endpoints.
    adjusted_data, updated_crosswalk = MediLink_UI.user_decision_on_suggestions(prepared_data, config, insurance_edited, crosswalk)

    # Update crosswalk reference if it was modified
    if updated_crosswalk:
        crosswalk = updated_crosswalk

    # Upstream duplicate prompt: flag and allow user to exclude duplicates before submission
    try:
        medi_cfg = extract_medilink_config(config)
        receipts_root = medi_cfg.get('local_claims_path', None)
        if receipts_root:
            try:
                from MediCafe.submission_index import compute_claim_key, find_by_claim_key
            except Exception:
                compute_claim_key = None
                find_by_claim_key = None
            if compute_claim_key and find_by_claim_key:
                for data in adjusted_data:
                    try:
                        # Use precomputed claim_key when available, else build it
                        claim_key = data.get('claim_key', None)
                        if not claim_key:
                            claim_key = compute_claim_key(
                                data.get('patient_id', ''),
                                '',
                                data.get('primary_insurance', ''),
                                data.get('surgery_date_iso', data.get('surgery_date', '')),
                                data.get('primary_procedure_code', '')
                            )
                        existing = find_by_claim_key(receipts_root, claim_key) if claim_key else None
                        if existing:
                            # Show informative prompt
                            print("\nPotential duplicate detected:")
                            print("- Patient: {} ({})".format(data.get('patient_name', ''), data.get('patient_id', '')))
                            print("- DOS: {} | Insurance: {} | Proc: {}".format(
                                data.get('surgery_date', ''),
                                data.get('primary_insurance', ''),
                                data.get('primary_procedure_code', '')
                            ))
                            print("- Prior submission: {} via {} (receipt: {})".format(
                                existing.get('submitted_at', 'unknown'),
                                existing.get('endpoint', 'unknown'),
                                existing.get('receipt_file', 'unknown')
                            ))
                            ans = input("Submit anyway? (Y/N): ").strip().lower()
                            if ans not in ['y', 'yes']:
                                data['exclude_from_submission'] = True
                    except Exception:
                        continue
    except Exception:
        pass

    # Filter out excluded items prior to confirmation and submission
    pre_duplicate_count = len(adjusted_data)
    adjusted_data = [d for d in adjusted_data if not d.get('exclude_from_submission')]
    post_duplicate_count = len(adjusted_data)
    excluded_duplicates = max(0, pre_duplicate_count - post_duplicate_count)

    if not adjusted_data:
        print("No patients remain after duplicate exclusions. Returning to main menu.")
        return False

    _print_submission_stage(6, 6, "Submit")
    print("\nExclusion summary before final submit:")
    print("- Retry policy excluded: {}".format(max(0, len(detailed_patient_data) - len(prepared_data))))
    print("- Duplicate declined by user: {}".format(excluded_duplicates))

    # Confirm all remaining suggested endpoints.
    confirmed_data = MediLink_DataMgmt.confirm_all_suggested_endpoints(adjusted_data)
    if not confirmed_data:
        return False

    organized_data = MediLink_DataMgmt.organize_patient_data_by_endpoint(confirmed_data)
    if not MediLink_Up.confirm_transmission(organized_data):
        print("Submission cancelled. No changes were made.")
        return False

    try:
        online = MediLink_Up.check_internet_connection()
    except ImportError:
        _print_error("Cannot check internet connectivity - configuration issue. Please check MediCafe installation.")
        return False
    if not online:
        print("Internet connection error. Please ensure you're connected and try again.")
        return False

    submission_results = MediLink_Up.submit_claims(organized_data, config, crosswalk)
    return _submission_results_have_success(submission_results)

if __name__ == "__main__":
    total_start_time = time.time()
    exit_code = 0
    try:
        # Install unhandled exception hook to capture tracebacks
        try:
            sys.excepthook = capture_unhandled_traceback
        except Exception:
            pass
        main_menu()
    except ValueError as e:
        # Graceful domain error: show concise message without traceback, then exit
        sys.stderr.write("\n" + "="*60 + "\n")
        sys.stderr.write("PROCESS HALTED\n")
        sys.stderr.write("="*60 + "\n")
        sys.stderr.write(str(e) + "\n")
        sys.stderr.write("\nPress Enter to exit...\n")
        try:
            input()
        except Exception:
            pass
        exit_code = 1
    except KeyboardInterrupt:
        _mark_user_exit()
        print("\nOperation cancelled by user.")
        exit_code = 1
    except Exception as e:
        sys.stderr.write("An unexpected error occurred; process halted.\n")
        sys.stderr.write(str(e) + "\n")
        from MediCafe.error_reporter import collect_support_bundle
        zip_path = collect_support_bundle(include_traceback=True)
        if not zip_path:
            print("Failed to create bundle - exiting.")
            exit_code = 1
        else:
            try:
                from MediCafe.core_utils import check_internet_connection
                online = check_internet_connection()
            except ImportError:
                # If we can't check connectivity during error reporting, assume offline
                # to preserve the error bundle for later
                online = False
                print("Warning: Could not check internet connectivity - preserving error bundle.")
            if online:
                success = submit_support_bundle_email(zip_path)
                if success:
                    # On success, remove the bundle
                    try:
                        os.remove(zip_path)
                    except Exception:
                        pass
                else:
                    # Preserve bundle for manual retry
                    print("Send failed - bundle preserved at {} for retry.".format(zip_path))
            else:
                ans = input("Offline. Connect to internet, then press Y to retry or N to discard: ").strip().lower()
                if ans == 'y':
                    try:
                        online = check_internet_connection()
                    except ImportError:
                        print("Warning: Could not check internet connectivity - preserving error bundle.")
                        online = False
                    if online:
                        success = submit_support_bundle_email(zip_path)
                        if success:
                            try:
                                os.remove(zip_path)
                            except Exception:
                                pass
                        else:
                            print("Send failed - bundle preserved at {} for retry.".format(zip_path))
                    else:
                        print("Still offline - preserving bundle at {} for retry.".format(zip_path))
                else:
                    print("Discarding bundle at user request.")
                    try:
                        os.remove(zip_path)
                    except Exception:
                        pass
        exit_code = 1
    finally:
        if exit_code == 0 and PERFORMANCE_LOGGING:
            total_end_time = time.time()
            print("Total MediLink execution time: {:.2f} seconds".format(total_end_time - total_start_time))
    sys.exit(exit_code)
