#!/usr/bin/env python
"""
Phase D QA and canonicalization: unit tests.
Tests canonical key determinism, parse providers, QA evaluator, lock fail, state persistence.
XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import json
import os
import sqlite3
import sys
import tempfile
import unittest

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.abspath(os.path.join(_SCRIPT_DIR, "..", ".."))
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

from phase_d_common import (
    PHASE_D_LOCK_FAIL,
    QA_DAT_DATE_OF_SERVICE_MISSING,
    QA_DAT_EMPTY_FILE,
    QA_DAT_PARSE_NO_RECORDS,
    QA_DAT_PAYER_ANCHOR_MISSING,
    QA_DAT_PATIENT_ANCHOR_MISSING,
    QA_DAT_UNSUPPORTED_LAYOUT,
    QA_POLICY_VERSION,
    QA_FILE_READ_ERROR,
    QA_UNKNOWN_ARTIFACT_CLASS,
    compute_canonical_key,
    compute_patient_key,
    compute_qa_deterministic_key,
)
from phase_d_historical_reprocess import (
    collect_phase_d_reject_snapshot,
    execute_historical_phase_d_reprocess,
    preview_historical_phase_d_reprocess,
)

try:
    from unittest.mock import patch, MagicMock
except ImportError:
    from mock import patch, MagicMock

SQL_PATH = os.path.join(_ROOT, "sql", "unified_relational_model_v1.sql")


def _make_lab_with_db():
    """Create temp lab dir with unified_model_xp.db and schema."""
    lab_root = tempfile.mkdtemp()
    db_path = os.path.join(lab_root, "unified_model_xp.db")
    reports_dir = os.path.join(lab_root, "reports")
    os.makedirs(reports_dir, exist_ok=True)
    if os.path.exists(SQL_PATH):
        with open(SQL_PATH, "r", encoding="utf-8") as f:
            conn = sqlite3.connect(db_path)
            conn.executescript(f.read())
            conn.close()
    return lab_root, db_path, reports_dir


class TestCanonicalKeyDeterminism(unittest.TestCase):
    """Canonical key formulas: determinism and null handling."""

    def test_same_values_same_key(self):
        k1 = compute_canonical_key(["a", "b", "c"])
        k2 = compute_canonical_key(["a", "b", "c"])
        self.assertEqual(k1, k2)
        self.assertEqual(len(k1), 64)

    def test_null_handling(self):
        k1 = compute_canonical_key(["a", None, "c"])
        k2 = compute_canonical_key(["a", None, "c"])
        self.assertEqual(k1, k2)

    def test_empty_string_handling(self):
        k1 = compute_canonical_key(["a", "", "c"])
        k2 = compute_canonical_key(["a", "", "c"])
        self.assertEqual(k1, k2)

    def test_json_dumps_determinism(self):
        vals = ["x", "y", "z"]
        k1 = compute_canonical_key(vals)
        k2 = compute_canonical_key(vals)
        self.assertEqual(k1, k2)


class TestPatientFieldMapper(unittest.TestCase):
    """Shared CSV patient field mapping helpers."""

    def test_extract_birth_date_patient_dob_alias(self):
        from patient_field_mapper import extract_birth_date
        row = {"Patient DOB": "1985-12-25"}
        self.assertEqual(extract_birth_date(row), "1985-12-25")

    def test_extract_full_name_first_last_fallback(self):
        from patient_field_mapper import extract_full_name
        row = {"Patient First": "Jane", "Patient Last": "Doe"}
        self.assertEqual(extract_full_name(row), "Jane Doe")

    def test_external_id_validation(self):
        from patient_field_mapper import classify_external_patient_id_5_digit, is_valid_external_patient_id_5_digit
        self.assertTrue(is_valid_external_patient_id_5_digit("12345"))
        self.assertFalse(is_valid_external_patient_id_5_digit("3712"))
        self.assertFalse(is_valid_external_patient_id_5_digit(""))
        diag = classify_external_patient_id_5_digit("3712", "test_source")
        self.assertFalse(diag.get("is_valid"))
        self.assertEqual(diag.get("pattern"), "^[0-9]{5}$")
        self.assertEqual(diag.get("source"), "test_source")
        self.assertEqual(diag.get("reason"), "wrong_length")


class TestQaEvaluator(unittest.TestCase):
    """QA evaluator pass/reject and unknown class."""

    def test_csv_pass_with_patient_id(self):
        from qa_evaluator import evaluate_qa
        envelope = {"rows": [{"Patient ID": "12345"}], "row_count": 1, "has_patient_id": True}
        pass_qa, code, reason = evaluate_qa("csv", envelope)
        self.assertTrue(pass_qa)
        self.assertIsNone(code)

    def test_csv_reject_no_patient_id(self):
        from qa_evaluator import evaluate_qa
        envelope = {"rows": [{"other": "x"}], "row_count": 1, "has_patient_id": False}
        pass_qa, code, reason = evaluate_qa("csv", envelope)
        self.assertFalse(pass_qa)
        self.assertIsNotNone(code)

    def test_unknown_class_reject(self):
        from qa_evaluator import evaluate_qa
        pass_qa, code, reason = evaluate_qa("unknown_class", {})
        self.assertFalse(pass_qa)
        self.assertEqual(code, QA_UNKNOWN_ARTIFACT_CLASS)

    def test_dat_empty_file_uses_qa_dat_empty_file(self):
        from qa_evaluator import evaluate_qa
        envelope = {
            "records": [],
            "file_size_bytes": 0,
            "parser_diagnostics": {"raw_record_count": 0, "tuple_candidate_count": 0, "parsed_record_count": 0},
        }
        pass_qa, code, reason = evaluate_qa("dat", envelope)
        self.assertFalse(pass_qa)
        self.assertEqual(code, QA_DAT_EMPTY_FILE)

    def test_dat_nonempty_zero_parsed_records_uses_qa_dat_parse_no_records(self):
        from qa_evaluator import evaluate_qa
        envelope = {
            "records": [],
            "file_size_bytes": 100,
            "parser_diagnostics": {"raw_record_count": 2, "tuple_candidate_count": 2, "parsed_record_count": 0},
        }
        pass_qa, code, reason = evaluate_qa("dat", envelope)
        self.assertFalse(pass_qa)
        self.assertEqual(code, QA_DAT_PARSE_NO_RECORDS)

    def test_dat_dict_records_without_anchor_contract_use_unsupported_layout_code(self):
        from qa_evaluator import evaluate_qa
        envelope = {"records": [{"foo": "bar", "nope": "1"}], "file_size_bytes": 10}
        pass_qa, code, reason = evaluate_qa("dat", envelope)
        self.assertFalse(pass_qa)
        self.assertEqual(code, QA_DAT_UNSUPPORTED_LAYOUT)

    def test_dat_reject_missing_patient_anchor(self):
        from qa_evaluator import evaluate_qa
        envelope = {"records": [{"FIRST": "Pat", "LAST": "Smith", "DOS": "2025-01-15", "PAYERID": "payer-a"}]}
        pass_qa, code, reason = evaluate_qa("dat", envelope)
        self.assertFalse(pass_qa)
        self.assertEqual(code, QA_DAT_PATIENT_ANCHOR_MISSING)

    def test_dat_reject_missing_date_of_service(self):
        from qa_evaluator import evaluate_qa
        envelope = {"records": [{"PATID": "12345", "PAYERID": "payer-a"}]}
        pass_qa, code, reason = evaluate_qa("dat", envelope)
        self.assertFalse(pass_qa)
        self.assertEqual(code, QA_DAT_DATE_OF_SERVICE_MISSING)

    def test_dat_reject_missing_payer_anchor(self):
        from qa_evaluator import evaluate_qa
        envelope = {"records": [{"PATID": "12345", "DOS": "2025-01-15"}]}
        pass_qa, code, reason = evaluate_qa("dat", envelope)
        self.assertFalse(pass_qa)
        self.assertEqual(code, QA_DAT_PAYER_ANCHOR_MISSING)

    def test_dat_live_z_row_with_date_alias_still_rejects_missing_payer_anchor(self):
        from qa_evaluator import evaluate_qa
        envelope = {"records": [{
            "CHART": "BENMI010",
            "PATID": "91086",
            "DATE": "04-08-26",
            "INAME": "UNITED HEALTHCARE GA    740800",
        }]}
        pass_qa, code, reason = evaluate_qa("dat", envelope)
        self.assertFalse(pass_qa)
        self.assertEqual(code, QA_DAT_PAYER_ANCHOR_MISSING)

    def test_resolve_dat_payer_anchor_keeps_insurance_name_diagnostic_only(self):
        from dat_contract import resolve_dat_payer_anchor

        payer = resolve_dat_payer_anchor({
            "PATID": "91086",
            "DATE": "04-08-26",
            "INAME": "UNITED HEALTHCARE GA    740800",
        })
        self.assertEqual(payer.get("payer_id"), "")
        self.assertEqual(payer.get("payer_anchor_status"), "missing")
        self.assertEqual(payer.get("insurance_name_source"), "INAME")
        self.assertTrue(payer.get("insurance_name_diagnostic_only"))
        self.assertEqual(payer.get("payer_anchor_diagnostic"), "insurance_name_present_but_not_payer_anchor")

        payer2 = resolve_dat_payer_anchor({"INSID": "payer-a", "INAME": "Aetna"})
        self.assertEqual(payer2.get("payer_id"), "payer-a")
        self.assertEqual(payer2.get("payer_anchor_source"), "INSID")

    def test_dat_live_zm_row_missing_patid_rejects_patient_anchor(self):
        from qa_evaluator import evaluate_qa
        envelope = {"records": [{
            "CHART": "A",
            "DATE": "PO Bo",
            "AMOUNT": "0.00",
            "CITY": "ATLANTA",
        }]}
        pass_qa, code, reason = evaluate_qa("dat", envelope)
        self.assertFalse(pass_qa)
        self.assertEqual(code, QA_DAT_PATIENT_ANCHOR_MISSING)

    def test_dat_pass_with_normalized_aliases(self):
        from qa_evaluator import evaluate_qa
        envelope = {"records": [{"chart_number": "C-1", "patient_id": "12345", "date_of_service": "2025-01-15", "payer_id": "payer-a"}]}
        pass_qa, code, reason = evaluate_qa("dat", envelope)
        self.assertTrue(pass_qa)
        self.assertIsNone(code)

    def test_dat_pass_with_medisoft_DATE_alias(self):
        """
        Medisoft fixed-width DAT files expose the service date as the `DATE` column
        (see MediLink/MediLink_PatientProcessor.py `raw_dos = parsed_data.get('DATE')`
        and MediLink/MediLink_837p_encoder_library.py). The Phase D QA DAT contract
        must treat `DATE` as an accepted service-date alias, otherwise every real
        Medisoft DAT record rejects with QA_DAT_DATE_OF_SERVICE_MISSING.
        """
        from qa_evaluator import evaluate_qa
        envelope = {"records": [{"PATID": "12345", "DATE": "03-25-26", "PAYERID": "payer-a"}]}
        pass_qa, code, reason = evaluate_qa("dat", envelope)
        self.assertTrue(pass_qa)
        self.assertIsNone(code)

    def test_resolve_dat_fields_accepts_medisoft_DATE_service_date(self):
        from dat_contract import resolve_dat_fields
        resolved = resolve_dat_fields({"PATID": "12345", "DATE": "03-25-26"})
        self.assertEqual(resolved.get("date_of_service"), "03-25-26")

    def test_resolve_dat_fields_precedence_prefers_DOS_over_DATE(self):
        """Adding DATE must not shift existing alias precedence: normalized -> DOS -> DATE1 -> service_date -> DATE."""
        from dat_contract import resolve_dat_fields
        resolved = resolve_dat_fields({"PATID": "12345", "DOS": "2025-01-01", "DATE": "2026-03-25"})
        self.assertEqual(resolved.get("date_of_service"), "2025-01-01")

    def test_dat_reject_chart_only_without_patid(self):
        from qa_evaluator import evaluate_qa
        envelope = {"records": [{"chart_number": "C-1", "date_of_service": "2025-01-15", "payer_id": "payer-a"}]}
        pass_qa, code, reason = evaluate_qa("dat", envelope)
        self.assertFalse(pass_qa)
        self.assertEqual(code, QA_DAT_PATIENT_ANCHOR_MISSING)

    def test_dat_pass_when_later_record_satisfies_contract(self):
        from qa_evaluator import evaluate_qa
        envelope = {
            "records": [
                {"FIRST": "Pat", "LAST": "Smith", "DOS": "2025-01-15", "PAYERID": "payer-a"},
                {"PATID": "12345", "DOS": "2025-01-15", "PAYERID": "payer-a"},
            ]
        }
        pass_qa, code, reason = evaluate_qa("dat", envelope)
        self.assertTrue(pass_qa)
        self.assertIsNone(code)


class TestParseProviders(unittest.TestCase):
    """Parse providers: unavailable -> row-level reject, safe wrapper."""

    def test_unknown_artifact_class(self):
        from parse_providers import parse_artifact
        ok, envelope, code = parse_artifact("/nonexistent", "unknown_class")
        self.assertFalse(ok)
        self.assertEqual(code, QA_UNKNOWN_ARTIFACT_CLASS)

    def test_missing_locator(self):
        from parse_providers import parse_artifact, get_last_parse_diag
        ok, envelope, code = parse_artifact("", "csv")
        self.assertFalse(ok)
        self.assertIsNotNone(code)
        self.assertEqual(code, QA_FILE_READ_ERROR)
        diag = get_last_parse_diag()
        self.assertEqual(diag.get("error_code"), QA_FILE_READ_ERROR)
        self.assertEqual(diag.get("provider"), "file_reader")

    def test_csv_patient_id_field_passes_qa(self):
        """CSV with patient_id (not Patient ID) header should pass QA."""
        from parse_providers import parse_csv
        from qa_evaluator import evaluate_qa
        fd, path = None, None
        try:
            fd, path = tempfile.mkstemp(suffix=".csv")
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                f.write("patient_id,Patient Name,Birth Date,Surgery Date\n")
                f.write("12345,Test Patient,01-01-1990,01-15-2025\n")
            fd = None
            ok, envelope, code = parse_csv(path)
            self.assertTrue(ok)
            self.assertIsNotNone(envelope)
            self.assertTrue(envelope.get("has_patient_id"))
            pass_qa, _, _ = evaluate_qa("csv", envelope)
            self.assertTrue(pass_qa)
        finally:
            if path and os.path.exists(path):
                try:
                    os.remove(path)
                except Exception:
                    pass

    def test_jsonl_non_dict_line_does_not_raise(self):
        """JSONL with non-dict line (e.g. [1,2,3]) should parse without AttributeError."""
        from parse_providers import parse_jsonl
        fd, path = None, None
        try:
            fd, path = tempfile.mkstemp(suffix=".jsonl")
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                f.write('{"claim_number": "C1", "payer_id": "P1"}\n')
                f.write("[1, 2, 3]\n")
                f.write('{"Claim #": "C2"}\n')
            fd = None
            ok, envelope, code = parse_jsonl(path)
            self.assertTrue(ok)
            self.assertIsNotNone(envelope)
            self.assertEqual(envelope.get("row_count"), 3)
            self.assertTrue(envelope.get("has_claim_number"))
        finally:
            if path and os.path.exists(path):
                try:
                    os.remove(path)
                except Exception:
                    pass

    def test_parse_dat_normalizes_contract_aliases(self):
        from parse_providers import parse_dat
        fake_records = [{
            "CHART": "C-100",
            "PATID": "12345",
            "FIRST": "Pat",
            "LAST": "Smith",
            "DATE1": "2025-01-15",
            "INSID": "payer-a",
            "INAME": "Aetna",
        }]

        with patch("parse_providers._safe_wrap_legacy", return_value=(True, fake_records, None)):
            with patch("MediCafe.core_utils.get_shared_config_loader") as mock_loader:
                mock_loader.return_value.load_configuration.return_value = ({}, {})
                ok, envelope, code = parse_dat("/tmp/example.dat")

        self.assertTrue(ok)
        self.assertEqual(code, None)
        record = envelope["records"][0]
        self.assertEqual(record.get("chart_number"), "C-100")
        self.assertEqual(record.get("patient_id"), "12345")
        self.assertEqual(record.get("date_of_service"), "2025-01-15")
        self.assertEqual(record.get("payer_id"), "payer-a")
        self.assertEqual(record.get("insurance_name"), "Aetna")

    def test_parse_dat_tuple_failures_surface_parser_diagnostics(self):
        from parse_providers import parse_dat

        fake_records = [
            ("good", "payer", "service"),
            ("bad", "payer", "service"),
        ]

        def _fake_parse_fixed_width(personal_info, insurance_info, service_info, service_info_2=None, service_info_3=None, config=None):
            if personal_info == "bad":
                raise ValueError("bad tuple payload")
            return {
                "CHART": "C-100",
                "PATID": "12345",
                "DATE1": "2025-01-15",
                "INSID": "payer-a",
            }

        with patch("parse_providers._safe_wrap_legacy", return_value=(True, fake_records, None)):
            with patch("MediLink.MediLink_DataMgmt.parse_fixed_width_data", side_effect=_fake_parse_fixed_width):
                with patch("MediCafe.core_utils.get_shared_config_loader") as mock_loader:
                    mock_loader.return_value.load_configuration.return_value = ({}, {})
                    ok, envelope, code = parse_dat("/tmp/example.dat")

        self.assertTrue(ok)
        self.assertEqual(code, None)
        diag = envelope.get("parser_diagnostics") or {}
        self.assertEqual(diag.get("tuple_candidate_count"), 2)
        self.assertEqual(diag.get("tuple_parse_failure_count"), 1)
        self.assertEqual(diag.get("first_failure_class"), "ValueError")
        self.assertEqual(diag.get("parsed_record_count"), 1)
        self.assertEqual((diag.get("record_shape_counts") or {}).get("tuple"), 2)
        self.assertTrue(any("PATID" in item for item in (diag.get("raw_key_sets_sample") or [])))

    def test_parse_dat_non_dict_tuple_result_counts_as_failure(self):
        from parse_providers import parse_dat

        fake_records = [("bad", "payer", "service")]

        with patch("parse_providers._safe_wrap_legacy", return_value=(True, fake_records, None)):
            with patch("MediLink.MediLink_DataMgmt.parse_fixed_width_data", return_value=None):
                with patch("MediCafe.core_utils.get_shared_config_loader") as mock_loader:
                    mock_loader.return_value.load_configuration.return_value = ({}, {})
                    ok, envelope, code = parse_dat("/tmp/example.dat")

        self.assertTrue(ok)
        self.assertEqual(code, None)
        diag = envelope.get("parser_diagnostics") or {}
        self.assertEqual(diag.get("tuple_candidate_count"), 1)
        self.assertEqual(diag.get("tuple_parse_failure_count"), 1)
        self.assertEqual(diag.get("first_failure_class"), "NonDictParsedRecord")
        self.assertEqual(diag.get("first_failure_detail"), "parse_fixed_width_data returned NoneType")
        self.assertEqual(diag.get("parsed_record_count"), 0)


class TestDatContractHelpers(unittest.TestCase):
    """Shared DAT contract helpers."""

    def test_resolve_dat_fields_matches_legacy_and_normalized_aliases(self):
        from dat_contract import resolve_dat_fields

        provenance = {"source_ref": "src|dat", "record_index": "3", "attachment_sha256": "sha-1"}
        legacy = {
            "CHART": "C-100",
            "PATID": "12345",
            "FIRST": "Pat",
            "LAST": "Smith",
            "DATE1": "2025-01-15",
            "INSID": "payer-a",
            "INAME": "Aetna",
            "MEMID": "M-1",
        }
        normalized = {
            "chart_number": "C-100",
            "patient_id": "12345",
            "first_name": "Pat",
            "last_name": "Smith",
            "patient_name": "Pat Smith",
            "date_of_service": "2025-01-15",
            "payer_id": "payer-a",
            "insurance_name": "Aetna",
            "member_id": "M-1",
        }
        self.assertEqual(resolve_dat_fields(legacy, provenance), resolve_dat_fields(normalized, provenance))

    def test_extract_canonical_records_dat_preserves_attachment_sha256(self):
        from canonical_extractor import extract_canonical_records

        recs = extract_canonical_records(
            7,
            "dat",
            {"records": [{"PATID": "12345", "DATE1": "2025-01-15", "INSID": "payer-a"}]},
            "xp_local",
            "src|dat",
            "sha-123",
        )
        self.assertEqual(len(recs), 1)
        provenance = json.loads(recs[0]["provenance_json"])
        payload = json.loads(recs[0]["canonical_json"])
        self.assertEqual(provenance.get("attachment_sha256"), "sha-123")
        self.assertEqual(provenance.get("record_index"), 0)
        self.assertEqual(payload.get("patient_id"), "12345")
        self.assertEqual(payload.get("payer_id"), "payer-a")


class TestRunQaCanonical(unittest.TestCase):
    """run_qa_canonical: no eligible rows, lock fail, state persistence."""

    def test_no_eligible_rows_ok(self):
        from run_qa_canonical import run_qa_canonical
        lab_root, db_path, reports_dir = _make_lab_with_db()
        try:
            with patch("run_qa_canonical.acquire_lock"):
                with patch("run_qa_canonical.release_lock"):
                    ok, rid, summary, err = run_qa_canonical(lab_root)
            self.assertTrue(ok)
            self.assertEqual(summary.get("rows_selected"), 0)
            self.assertIsNone(err)
        finally:
            try:
                for f in os.listdir(reports_dir):
                    os.remove(os.path.join(reports_dir, f))
                os.remove(db_path)
                os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass

    def test_lock_fail_returns_error(self):
        from run_qa_canonical import run_qa_canonical
        lab_root, db_path, reports_dir = _make_lab_with_db()
        try:
            with patch("run_qa_canonical.acquire_lock", side_effect=SystemExit(1)):
                ok, rid, summary, err = run_qa_canonical(lab_root)
            self.assertFalse(ok)
            self.assertEqual(err, PHASE_D_LOCK_FAIL)
        finally:
            try:
                if os.path.exists(db_path):
                    os.remove(db_path)
                if os.path.exists(reports_dir):
                    for f in os.listdir(reports_dir):
                        os.remove(os.path.join(reports_dir, f))
                    os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass


class TestPlanningTelemetry(unittest.TestCase):
    """Planning telemetry classification for patient vs non-patient canonicals."""

    def test_non_patient_total_excludes_patient_canonical_types(self):
        from run_qa_canonical import _build_planning_telemetry

        canonical_records = [
            {"canonical_type": "patient_csv_row"},
            {"canonical_type": "x12_member"},
            {"canonical_type": "x12_member"},
            {"canonical_type": "remittance_row"},
        ]

        telemetry = _build_planning_telemetry(
            canonical_records,
            reject_counts_by_code={},
            reject_counts_by_artifact_code={},
            constraint_skip_counts={},
        )

        self.assertEqual(
            (telemetry.get("workstream_d") or {}).get("canonical_count_non_patient_total"),
            1,
        )

    def test_artifact_class_filter_selects_only_requested_classes(self):
        from run_qa_canonical import run_qa_canonical
        lab_root, db_path, reports_dir = _make_lab_with_db()
        csv_path = None
        try:
            csv_path = os.path.join(lab_root, "filtered.csv")
            with open(csv_path, "w", encoding="utf-8") as f:
                f.write("Patient ID,Patient Name,Birth Date\n")
                f.write("12345,Filter Test,01-01-1990\n")

            conn = sqlite3.connect(db_path)
            payload_csv = json.dumps({
                "artifact_class": "csv",
                "locator": csv_path,
            }, separators=(",", ":"))
            payload_docx = json.dumps({
                "artifact_class": "docx",
                "locator": "",
            }, separators=(",", ":"))
            conn.execute(
                "INSERT INTO ingest_artifact (ingest_key, source_system, source_type, source_ref, message_id, "
                "attachment_name, attachment_sha256, payload_json, ingest_status) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                ("filter_csv_1", "xp_local", "file_csv", "src|path", None, "filtered.csv", "", payload_csv, "ingested"),
            )
            conn.execute(
                "INSERT INTO ingest_artifact (ingest_key, source_system, source_type, source_ref, message_id, "
                "attachment_name, attachment_sha256, payload_json, ingest_status) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                ("filter_docx_1", "xp_local", "file_docx", "src|path", None, "filtered.docx", "", payload_docx, "ingested"),
            )
            conn.commit()
            conn.close()

            with patch("run_qa_canonical.acquire_lock"):
                with patch("run_qa_canonical.release_lock"):
                    ok, rid, summary, err = run_qa_canonical(lab_root, artifact_classes=["csv"])
            self.assertTrue(ok)
            self.assertEqual(summary.get("rows_selected"), 1)
            self.assertEqual(summary.get("artifact_class_filter"), ["csv"])
        finally:
            try:
                if csv_path and os.path.exists(csv_path):
                    os.remove(csv_path)
                if os.path.exists(db_path):
                    os.remove(db_path)
                if os.path.exists(reports_dir):
                    for f in os.listdir(reports_dir):
                        os.remove(os.path.join(reports_dir, f))
                    os.rmdir(reports_dir)
                os.rmdir(lab_root)
            except Exception:
                pass


class TestCanonicalExtractor(unittest.TestCase):
    """Canonical extractor: produces records with provenance."""

    def test_extract_produces_records(self):
        from canonical_extractor import extract_canonical_records
        envelope = {"rows": [{"Patient ID": "123", "Birth Date": "01-01-1990"}], "row_count": 1}
        recs = extract_canonical_records(1, "csv", envelope, "xp_local", "src|path")
        self.assertGreater(len(recs), 0)
        for r in recs:
            self.assertIn("canonical_type", r)
            self.assertIn("canonical_key", r)
            self.assertIn("provenance_json", r)

    def test_v2_upserts_carry_canonical_lineage(self):
        from canonical_extractor import build_domain_upserts

        canonical_records = [{
            "canonical_type": "dat_record",
            "canonical_key": "canon-dat-1",
            "canonical_json": json.dumps({
                "PATID": "12345",
                "INSID": "payer-a",
                "DATE1": "2025-01-15",
                "CPT": "66984",
            }),
        }]

        upserts, _v2_stats = build_domain_upserts(
            canonical_records, artifact_id=7, source_system="xp_local", entity_scope="v2"
        )
        self.assertTrue(upserts["payer"])
        self.assertEqual(upserts["payer"][0].get("canonical_type"), "dat_record")
        self.assertEqual(upserts["payer"][0].get("canonical_key"), "canon-dat-1")
        self.assertEqual(upserts["claim"][0].get("canonical_type"), "dat_record")


class TestRunQaCanonicalIntegration(unittest.TestCase):
    """End-to-end row processing: pass, reject, parse-fail; qa_result, replay_queue, extracted_canonical_record, patient."""

    def test_integration_pass_reject_parsefail(self):
        from run_qa_canonical import run_qa_canonical
        lab_root, db_path, reports_dir = _make_lab_with_db()
        csv_pass_path = None
        csv_reject_path = None
        try:
            csv_pass_path = os.path.join(lab_root, "test_pass.csv")
            with open(csv_pass_path, "w", encoding="utf-8") as f:
                f.write("Patient ID,Patient Name,Birth Date,Surgery Date\n")
                f.write("12345,Test Patient,01-01-1990,01-15-2025\n")
            csv_reject_path = os.path.join(lab_root, "test_reject.csv")
            with open(csv_reject_path, "w", encoding="utf-8") as f:
                f.write("other,value\n")
                f.write("x,y\n")
            conn = sqlite3.connect(db_path)
            payload_pass = json.dumps({
                "artifact_class": "csv",
                "locator": csv_pass_path,
                "normalized_path": "test_pass.csv",
            }, separators=(",", ":"))
            payload_reject = json.dumps({
                "artifact_class": "csv",
                "locator": csv_reject_path,
                "normalized_path": "test_reject.csv",
            }, separators=(",", ":"))
            payload_fail = json.dumps({
                "artifact_class": "csv",
                "locator": "",
                "normalized_path": "nonexistent.csv",
            }, separators=(",", ":"))
            for ingest_key, payload in [
                ("int_test_pass_1", payload_pass),
                ("int_test_reject_2", payload_reject),
                ("int_test_fail_3", payload_fail),
            ]:
                conn.execute(
                    "INSERT INTO ingest_artifact (ingest_key, source_system, source_type, source_ref, message_id, "
                    "attachment_name, attachment_sha256, payload_json, ingest_status) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (ingest_key, "xp_local", "file_csv", "src|path", None, "x.csv", "", payload, "ingested"),
                )
            conn.commit()
            conn.close()
            with patch("run_qa_canonical.acquire_lock"):
                with patch("run_qa_canonical.release_lock"):
                    ok, rid, summary, err = run_qa_canonical(lab_root)
            self.assertTrue(ok)
            self.assertEqual(summary.get("rows_selected"), 3)
            self.assertEqual(summary.get("qa_pass_count"), 1)
            self.assertEqual(summary.get("qa_reject_count"), 2)
            conn = sqlite3.connect(db_path)
            qa_pass = conn.execute(
                "SELECT COUNT(*) FROM qa_result WHERE status='pass' AND qa_stage='phase_d'"
            ).fetchone()[0]
            qa_reject = conn.execute(
                "SELECT COUNT(*) FROM qa_result WHERE status='reject' AND qa_stage='phase_d'"
            ).fetchone()[0]
            self.assertEqual(qa_pass, 1)
            self.assertEqual(qa_reject, 2)
            replay_count = conn.execute("SELECT COUNT(*) FROM replay_queue").fetchone()[0]
            self.assertEqual(replay_count, 2)
            replay_reasons = [r[0] for r in conn.execute("SELECT reason_code FROM replay_queue").fetchall()]
            self.assertIn(QA_FILE_READ_ERROR, replay_reasons)
            canon_count = conn.execute("SELECT COUNT(*) FROM extracted_canonical_record").fetchone()[0]
            self.assertGreaterEqual(canon_count, 1)
            patient_count = conn.execute("SELECT COUNT(*) FROM patient").fetchone()[0]
            self.assertGreaterEqual(patient_count, 1)
            conn.close()
        finally:
            try:
                if csv_pass_path and os.path.exists(csv_pass_path):
                    os.remove(csv_pass_path)
                if csv_reject_path and os.path.exists(csv_reject_path):
                    os.remove(csv_reject_path)
                if os.path.exists(reports_dir):
                    for f in os.listdir(reports_dir):
                        os.remove(os.path.join(reports_dir, f))
                    os.rmdir(reports_dir)
                if os.path.exists(db_path):
                    os.remove(db_path)
                os.rmdir(lab_root)
            except Exception:
                pass

    def test_invalid_external_patient_id_logged_and_skipped(self):
        from run_qa_canonical import run_qa_canonical
        lab_root, db_path, reports_dir = _make_lab_with_db()
        try:
            conn = sqlite3.connect(db_path)
            payload = json.dumps({
                "artifact_class": "csv",
                "locator": "",
                "normalized_path": "invalid_id.csv",
            }, separators=(",", ":"))
            conn.execute(
                "INSERT INTO ingest_artifact (ingest_key, source_system, source_type, source_ref, message_id, "
                "attachment_name, attachment_sha256, payload_json, ingest_status) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                ("invalid_id_case", "xp_local", "file_csv", "src|path", None, "invalid_id.csv", "", payload, "ingested"),
            )
            conn.commit()
            conn.close()

            mocked_envelope = {
                "rows": [{
                    "Patient ID": "3712",
                    "Patient First": "Invalid",
                    "Patient Last": "Id",
                    "Patient DOB": "1990-01-01",
                }],
                "row_count": 1,
                "has_patient_id": True,
            }
            with patch("run_qa_canonical.parse_artifact", return_value=(True, mocked_envelope, None)):
                with patch("run_qa_canonical.acquire_lock"):
                    with patch("run_qa_canonical.release_lock"):
                        ok, rid, summary, err = run_qa_canonical(lab_root)
            self.assertTrue(ok)
            self.assertEqual(summary.get("qa_pass_count"), 1)
            self.assertEqual(
                (summary.get("constraint_skip_counts") or {}).get("patient_invalid_external_id"),
                1,
            )
            telemetry = summary.get("planning_telemetry") or {}
            self.assertTrue(((telemetry.get("workstream_c") or {}).get("activation_recommended")))
            self.assertEqual(
                (telemetry.get("workstream_c") or {}).get("invalid_external_patient_id_count"),
                1,
            )

            conn = sqlite3.connect(db_path)
            patient_count = conn.execute("SELECT COUNT(*) FROM patient").fetchone()[0]
            self.assertEqual(patient_count, 0)
            log_rows = conn.execute(
                "SELECT decision_type, decision_context_json FROM rule_decision_log WHERE decision_type='constraint_fail'"
            ).fetchall()
            self.assertEqual(len(log_rows), 1)
            context = json.loads(log_rows[0][1])
            from phase_d_v2_metrics import CONSTRAINT_PATIENT_EXTERNAL_ID_INVALID

            self.assertEqual(context.get("reason_code"), CONSTRAINT_PATIENT_EXTERNAL_ID_INVALID)
            self.assertEqual(context.get("invalid_external_patient_id_pattern"), "^[0-9]{5}$")
            self.assertEqual(context.get("invalid_external_patient_id_source"), "patient_csv_row.Patient ID")
            self.assertEqual(context.get("invalid_external_patient_id_reason"), "wrong_length")
            telemetry_rows = conn.execute(
                "SELECT telemetry_json FROM qa_planning_telemetry_log WHERE qa_stage='phase_d'"
            ).fetchall()
            self.assertEqual(len(telemetry_rows), 1)
            telemetry_context = json.loads(telemetry_rows[0][0])
            self.assertEqual(telemetry_context.get("event"), "planning_telemetry_snapshot")
            self.assertTrue(
                ((telemetry_context.get("telemetry") or {}).get("workstream_c") or {}).get("activation_recommended")
            )
            workstream_c = ((telemetry_context.get("telemetry") or {}).get("workstream_c") or {})
            self.assertEqual(workstream_c.get("invalid_external_patient_id_pattern"), "^[0-9]{5}$")
            self.assertEqual((workstream_c.get("invalid_external_patient_id_by_source") or {}).get("patient_csv_row.Patient ID"), 1)
            qa_rows = conn.execute(
                "SELECT COUNT(*) FROM qa_result WHERE qa_stage='phase_d' AND qa_version=? AND status='pass'",
                (QA_POLICY_VERSION,),
            ).fetchone()[0]
            self.assertEqual(qa_rows, 1)
            conn.close()
        finally:
            try:
                if os.path.exists(reports_dir):
                    for f in os.listdir(reports_dir):
                        os.remove(os.path.join(reports_dir, f))
                    os.rmdir(reports_dir)
                if os.path.exists(db_path):
                    os.remove(db_path)
                os.rmdir(lab_root)
            except Exception:
                pass

    def test_dat_summary_telemetry_counts_pass_and_canonical(self):
        from run_qa_canonical import run_qa_canonical
        lab_root, db_path, reports_dir = _make_lab_with_db()
        try:
            conn = sqlite3.connect(db_path)
            payload = json.dumps({
                "artifact_class": "dat",
                "locator": "",
                "normalized_path": "sample.ZDAT",
            }, separators=(",", ":"))
            conn.execute(
                "INSERT INTO ingest_artifact (ingest_key, source_system, source_type, source_ref, message_id, "
                "attachment_name, attachment_sha256, payload_json, ingest_status) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                ("dat_case", "xp_local", "file_dat", "src|path", None, "sample.ZDAT", "", payload, "ingested"),
            )
            conn.commit()
            conn.close()

            mocked_envelope = {
                "records": [{
                    "PATID": "12345",
                    "FIRST": "Pat",
                    "LAST": "Smith",
                    "INSID": "payer-a",
                    "DATE1": "2025-01-15",
                }],
                "record_count": 1,
                "parser_diagnostics": {
                    "tuple_parse_failure_count": 1,
                    "first_failure_class": "ValueError",
                    "first_failure_detail": "bad tuple payload",
                    "record_shape_counts": {"dict": 1, "tuple": 1},
                    "raw_key_sets_sample": ["DATE1,INSID,PATID"],
                },
            }
            with patch("run_qa_canonical.parse_artifact", return_value=(True, mocked_envelope, None)):
                with patch("run_qa_canonical.acquire_lock"):
                    with patch("run_qa_canonical.release_lock"):
                        ok, rid, summary, err = run_qa_canonical(lab_root)
            self.assertTrue(ok)
            dat_telemetry = summary.get("dat_telemetry") or {}
            self.assertEqual(dat_telemetry.get("dat_selected_count"), 1)
            self.assertEqual(dat_telemetry.get("dat_qa_pass_count"), 1)
            self.assertEqual(dat_telemetry.get("dat_qa_reject_count"), 0)
            self.assertEqual(dat_telemetry.get("dat_canonical_record_count"), 1)
            self.assertTrue(dat_telemetry.get("post_medisoft_exercised"))
            alias_counts = dat_telemetry.get("dat_field_presence_by_alias") or {}
            self.assertEqual(alias_counts.get("records_seen"), 1)
            self.assertEqual(alias_counts.get("PATID"), 1)
            self.assertEqual(alias_counts.get("DATE1"), 1)
            self.assertEqual(alias_counts.get("INSID"), 1)
            self.assertIn("DATE", alias_counts)
            self.assertEqual(alias_counts.get("DATE"), 0)
            parse_diag = dat_telemetry.get("dat_parse_diagnostics") or {}
            self.assertEqual(parse_diag.get("tuple_parse_failure_count"), 1)
            self.assertEqual(parse_diag.get("first_failure_class"), "ValueError")
            self.assertEqual((parse_diag.get("record_shape_counts") or {}).get("dict"), 1)
            self.assertIn("DATE1,INSID,PATID", parse_diag.get("raw_key_sets_sample") or [])
            self.assertEqual((dat_telemetry.get("dat_file_prefix_counts") or {}).get("SAMPLE"), 1)
            self.assertEqual(dat_telemetry.get("dat_reject_file_prefix_counts") or {}, {})

            with open(os.path.join(lab_root, "diagnostics_state.json"), "r", encoding="utf-8") as f:
                state = json.load(f)
            self.assertEqual(((state.get("last_phase_d_dat_telemetry") or {}).get("dat_selected_count")), 1)
            self.assertTrue(((state.get("last_phase_d_dat_telemetry") or {}).get("post_medisoft_exercised")))

            with open(os.path.join(lab_root, "run_cursor.json"), "r", encoding="utf-8") as f:
                cursor = json.load(f)
            self.assertEqual(((cursor.get("last_phase_d_dat_telemetry") or {}).get("dat_qa_pass_count")), 1)
        finally:
            try:
                if os.path.exists(reports_dir):
                    for f in os.listdir(reports_dir):
                        os.remove(os.path.join(reports_dir, f))
                    os.rmdir(reports_dir)
                if os.path.exists(db_path):
                    os.remove(db_path)
                os.rmdir(lab_root)
            except Exception:
                pass

    def test_dat_summary_telemetry_captures_live_z_zm_full_block_pattern(self):
        from run_qa_canonical import run_qa_canonical
        lab_root, db_path, reports_dir = _make_lab_with_db()
        try:
            conn = sqlite3.connect(db_path)
            artifact_specs = [
                ("dat_z_1", "src|z.dat", "sha-z-1", {"artifact_class": "dat", "locator": "F:\\Z\\Z.DAT"}),
                ("dat_z_2", "src|z_172334.dat", "sha-z-2", {"artifact_class": "dat", "locator": "F:\\Z\\Z_20260420_172334.DAT"}),
                ("dat_z_3", "src|z_184100.dat", "sha-z-3", {"artifact_class": "dat", "locator": "F:\\Z\\Z_20260420_184100.DAT"}),
                ("dat_z_4", "src|z_190046.dat", "sha-z-4", {"artifact_class": "dat", "locator": "F:\\Z\\Z_20260420_190046.DAT"}),
                ("dat_zm_1", "src|zm_184100.dat", "sha-zm-1", {"artifact_class": "dat", "locator": "F:\\Z\\ZM_20260420_184100.DAT"}),
            ]
            for ingest_key, source_ref, sha, payload in artifact_specs:
                conn.execute(
                    "INSERT INTO ingest_artifact (ingest_key, source_system, source_type, source_ref, message_id, "
                    "attachment_name, attachment_sha256, payload_json, ingest_status) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (
                        ingest_key,
                        "xp_local",
                        "file_dat",
                        source_ref,
                        None,
                        os.path.basename(payload["locator"]),
                        sha,
                        json.dumps(payload, separators=(",", ":")),
                        "ingested",
                    ),
                )
            conn.commit()
            conn.close()

            envelope_map = {
                "z.dat": {"records": [{"CHART": "BENMI010", "PATID": "91086", "DATE": "04-08-26"}], "record_count": 1},
                "z_20260420_172334.dat": {"records": [{"CHART": "WALCA020", "PATID": "90851", "DATE": "04-06-26"}], "record_count": 1},
                "z_20260420_184100.dat": {"records": [{"CHART": "WALCA020", "PATID": "90851", "DATE": "04-06-26"}], "record_count": 1},
                "z_20260420_190046.dat": {"records": [{"CHART": "PIEJO000", "PATID": "90802", "DATE": "04-07-26"}], "record_count": 1},
                "zm_20260420_184100.dat": {"records": [{"CHART": "A", "DATE": "PO Bo", "AMOUNT": "0.00"}], "record_count": 1},
            }

            def _parse_side_effect(locator, artifact_class, payload=None):
                key = os.path.basename(locator or "").lower()
                return True, envelope_map[key], None

            with patch("run_qa_canonical.parse_artifact", side_effect=_parse_side_effect):
                with patch("run_qa_canonical.acquire_lock"):
                    with patch("run_qa_canonical.release_lock"):
                        ok, rid, summary, err = run_qa_canonical(lab_root)

            self.assertTrue(ok)
            self.assertEqual(err, None)
            dat_telemetry = summary.get("dat_telemetry") or {}
            self.assertEqual(dat_telemetry.get("dat_selected_count"), 5)
            self.assertEqual(dat_telemetry.get("dat_qa_pass_count"), 0)
            self.assertEqual(dat_telemetry.get("dat_qa_reject_count"), 5)
            self.assertEqual(dat_telemetry.get("dat_canonical_record_count"), 0)
            self.assertFalse(dat_telemetry.get("post_medisoft_exercised"))
            self.assertEqual(
                dat_telemetry.get("dat_qa_reject_counts_by_reason"),
                {
                    "QA_DAT_PAYER_ANCHOR_MISSING": 4,
                    "QA_DAT_PATIENT_ANCHOR_MISSING": 1,
                },
            )
            self.assertEqual(dat_telemetry.get("dat_file_prefix_counts"), {"Z": 4, "ZM": 1})
            self.assertEqual(dat_telemetry.get("dat_reject_file_prefix_counts"), {"Z": 4, "ZM": 1})
            alias_counts = dat_telemetry.get("dat_field_presence_by_alias") or {}
            self.assertEqual(alias_counts.get("records_seen"), 5)
            self.assertEqual(alias_counts.get("PATID"), 4)
            self.assertEqual(alias_counts.get("DATE"), 5)
            self.assertEqual(alias_counts.get("PAYERID"), 0)
            self.assertEqual(alias_counts.get("INSID"), 0)
            self.assertEqual(
                summary.get("reject_counts_by_code"),
                {
                    "QA_DAT_PAYER_ANCHOR_MISSING": 4,
                    "QA_DAT_PATIENT_ANCHOR_MISSING": 1,
                },
            )

            reject_samples_path = os.path.join(reports_dir, "qa_reject_samples_{0}.jsonl".format(rid))
            self.assertTrue(os.path.exists(reject_samples_path))
            with open(reject_samples_path, "r", encoding="utf-8") as f:
                sample_rows = [json.loads(line) for line in f if line.strip()]
            self.assertEqual(len(sample_rows), 5)
            self.assertEqual(
                dict((code, len([row for row in sample_rows if row.get("reject_code") == code])) for code in (
                    "QA_DAT_PAYER_ANCHOR_MISSING",
                    "QA_DAT_PATIENT_ANCHOR_MISSING",
                )),
                {
                    "QA_DAT_PAYER_ANCHOR_MISSING": 4,
                    "QA_DAT_PATIENT_ANCHOR_MISSING": 1,
                },
            )
            self.assertEqual(
                dict((prefix, len([row for row in sample_rows if row.get("dat_file_prefix") == prefix])) for prefix in ("Z", "ZM")),
                {"Z": 4, "ZM": 1},
            )
            self.assertIn("PATID required", " ".join(row.get("reason", "") for row in sample_rows))
        finally:
            try:
                if os.path.exists(reports_dir):
                    for f in os.listdir(reports_dir):
                        os.remove(os.path.join(reports_dir, f))
                    os.rmdir(reports_dir)
                if os.path.exists(db_path):
                    os.remove(db_path)
                os.rmdir(lab_root)
            except Exception:
                pass


class TestRunQaCanonicalV2Metrics(unittest.TestCase):
    """Phase D v2 entity scope: domain metrics, DAT compact slice, reprocessing."""

    def test_v2_extractor_skip_missing_payer_anchor(self):
        from canonical_extractor import build_domain_upserts
        from phase_d_v2_metrics import DAT_V2_SKIP_MISSING_PAYER_ANCHOR, V2_SOURCE_LANE_DAT

        row = {"PATID": "12345", "DATE1": "2025-01-15"}
        canonical_records = [{
            "canonical_type": "dat_record",
            "canonical_key": "k1",
            "canonical_json": json.dumps(row, separators=(",", ":")),
        }]
        ups, stats = build_domain_upserts(canonical_records, 9, "xp_local", entity_scope="v2")
        self.assertFalse(ups["payer"])
        sk = (stats.get("skipped_by_reason") or {}).get(V2_SOURCE_LANE_DAT) or {}
        self.assertEqual(sk.get(DAT_V2_SKIP_MISSING_PAYER_ANCHOR), 1)

    def test_v2_extractor_skip_records_provenance_context(self):
        from canonical_extractor import build_domain_upserts
        from phase_d_v2_metrics import DAT_V2_SKIP_MISSING_PAYER_ANCHOR

        canonical_records = [{
            "canonical_type": "dat_record",
            "canonical_key": "k1",
            "canonical_json": json.dumps({
                "PATID": "12345",
                "DATE1": "2025-01-15",
                "CHART": "C-9",
                "INAME": "Aetna",
            }, separators=(",", ":")),
            "provenance_json": json.dumps({
                "source_ref": "src|dat",
                "record_index": 4,
                "attachment_sha256": "sha-dat",
            }, separators=(",", ":")),
        }]
        _ups, stats = build_domain_upserts(canonical_records, 9, "xp_local", entity_scope="v2")
        events = stats.get("skip_events") or []
        self.assertEqual(len(events), 1)
        event = events[0]
        self.assertEqual(event.get("reason_code"), DAT_V2_SKIP_MISSING_PAYER_ANCHOR)
        self.assertEqual(event.get("source_ref"), "src|dat")
        self.assertEqual(event.get("record_index"), 4)
        self.assertEqual(event.get("attachment_sha256"), "sha-dat")
        self.assertEqual(event.get("resolved_patient_id"), "12345")
        self.assertEqual(event.get("resolved_date_of_service"), "2025-01-15")
        self.assertEqual(event.get("resolved_chart_number"), "C-9")
        self.assertEqual(event.get("resolved_insurance_name"), "Aetna")

    def test_v2_payload_two_dat_rows_same_payer_key(self):
        from canonical_extractor import build_domain_upserts

        row = {"PATID": "12345", "INSID": "p1", "DATE1": "2025-01-15", "CPT": "1"}
        cj = json.dumps(row, separators=(",", ":"))
        recs = [
            {"canonical_type": "dat_record", "canonical_key": "a", "canonical_json": cj},
            {"canonical_type": "dat_record", "canonical_key": "b", "canonical_json": cj},
        ]
        ups, stats = build_domain_upserts(recs, 1, "xp_local", entity_scope="v2")
        self.assertEqual(len(ups["payer"]), 2)
        pay_pl = (stats.get("payload_attempted") or {}).get("dat_record") or {}
        self.assertEqual(pay_pl.get("payer"), 2)

    def test_v2_dat_precedence_prefers_extract_dat_join_identity_fields(self):
        """
        join_contract.extract_dat_join_identity is normalized-first: patient_id before PATID;
        date_of_service before DOS before DATE1. build_domain_upserts uses those values first,
        then falls back to legacy keys only when extract returns empty.
        """
        from canonical_extractor import build_domain_upserts

        row = {
            "patient_id": "11111",
            "PATID": "22222",
            "INSID": "p1",
            "date_of_service": "2025-06-15",
            "DOS": "2025-01-01",
            "DATE1": "2025-02-01",
            "CPT": "99",
        }
        recs = [{
            "canonical_type": "dat_record",
            "canonical_key": "prec",
            "canonical_json": json.dumps(row, separators=(",", ":")),
        }]
        ups, _st = build_domain_upserts(recs, 42, "xp_local", entity_scope="v2")
        self.assertTrue(ups["patient"])
        self.assertEqual(ups["patient"][0].get("external_patient_id"), "11111")
        self.assertTrue(ups["coverage"])
        self.assertEqual(ups["coverage"][0].get("effective_start"), "2025-06-15")

    def test_v2_constraint_fail_plan_payer_unresolved_dat_lane_only(self):
        from run_qa_canonical import _execute_domain_upserts
        from phase_d_v2_metrics import (
            CONSTRAINT_PLAN_PAYER_UNRESOLVED,
            V2_SOURCE_LANE_DAT,
            V2_SOURCE_LANE_REMIT,
            build_phase_d_v2_domain_metrics,
            empty_executor_v2_stats,
            empty_extractor_v2_stats,
        )

        lab_root, db_path, reports_dir = _make_lab_with_db()
        try:
            conn = sqlite3.connect(db_path)
            domain_upsert_rows = {
                "patient": [],
                "payer": [],
                "insurance_plan": [{
                    "artifact_id": 99,
                    "plan_key": "plan_orphan_key",
                    "payer_key": "missing_payer_key_xyz",
                    "medisoft_insurance_ids_json": "[]",
                    "canonical_type": "dat_record",
                    "canonical_key": "ck_orphan",
                    "source_system": "xp_local",
                }],
                "coverage": [],
                "encounter": [],
                "claim": [],
                "claim_line": [],
            }
            ex = empty_executor_v2_stats()
            _execute_domain_upserts(conn, domain_upsert_rows, "v2", v2_exec_stats=ex)
            conn.commit()
            conn.close()
            dm = build_phase_d_v2_domain_metrics(empty_extractor_v2_stats(), ex)
            cf_d = (dm.get("constraint_failed_by_reason") or {}).get(V2_SOURCE_LANE_DAT) or {}
            self.assertGreaterEqual(int(cf_d.get(CONSTRAINT_PLAN_PAYER_UNRESOLVED) or 0), 1)
            cf_r = (dm.get("constraint_failed_by_reason") or {}).get(V2_SOURCE_LANE_REMIT) or {}
            self.assertEqual(int(cf_r.get(CONSTRAINT_PLAN_PAYER_UNRESOLVED) or 0), 0)
        finally:
            try:
                if os.path.exists(reports_dir):
                    for f in os.listdir(reports_dir):
                        os.remove(os.path.join(reports_dir, f))
                    os.rmdir(reports_dir)
                if os.path.exists(db_path):
                    os.remove(db_path)
                os.rmdir(lab_root)
            except Exception:
                pass

    def test_v2_constraint_fail_rows_include_dat_provenance_for_parent_chain(self):
        from run_qa_canonical import _execute_domain_upserts
        from phase_d_v2_metrics import (
            CONSTRAINT_CLAIM_LINE_PARENT_UNRESOLVED,
            CONSTRAINT_CLAIM_PARENT_UNRESOLVED,
            CONSTRAINT_COVERAGE_PARENT_UNRESOLVED,
            CONSTRAINT_ENCOUNTER_PATIENT_UNRESOLVED,
            empty_executor_v2_stats,
        )

        lab_root, db_path, reports_dir = _make_lab_with_db()
        shared = {
            "artifact_id": 77,
            "canonical_type": "dat_record",
            "source_system": "xp_local",
            "source_ref": "src|dat",
            "record_index": 2,
            "attachment_sha256": "sha-parent",
            "resolved_patient_id": "12345",
            "resolved_date_of_service": "2025-01-15",
            "resolved_payer_id": "payer-a",
            "resolved_chart_number": "C-12",
            "resolved_insurance_name": "Aetna",
            "resolved_member_id": "M-12",
        }
        try:
            conn = sqlite3.connect(db_path)
            domain_upsert_rows = {
                "patient": [],
                "payer": [],
                "insurance_plan": [],
                "coverage": [dict(shared, coverage_key="cov_missing", patient_key="pk_missing", plan_key="plan_missing", canonical_key="ck_cov")],
                "encounter": [dict(shared, encounter_key="enc_missing", patient_key="pk_missing", date_of_service="2025-01-15", source_artifact_id=77, canonical_key="ck_enc")],
                "claim": [dict(shared, claim_key="claim_missing", encounter_key="enc_missing", payer_key="payer_missing", source_artifact_id=77, canonical_key="ck_claim")],
                "claim_line": [dict(shared, claim_line_key="line_missing", claim_key="claim_missing", line_number=1, canonical_key="ck_line")],
            }
            _execute_domain_upserts(conn, domain_upsert_rows, "v2", v2_exec_stats=empty_executor_v2_stats())
            conn.commit()
            rows = conn.execute(
                "SELECT decision_context_json FROM rule_decision_log WHERE decision_type='constraint_fail' ORDER BY decision_id"
            ).fetchall()
            conn.close()
            contexts = [json.loads(row[0]) for row in rows]
            by_reason = {}
            for context in contexts:
                by_reason[context.get("reason_code")] = context
            self.assertIn(CONSTRAINT_COVERAGE_PARENT_UNRESOLVED, by_reason)
            self.assertIn(CONSTRAINT_ENCOUNTER_PATIENT_UNRESOLVED, by_reason)
            self.assertIn(CONSTRAINT_CLAIM_PARENT_UNRESOLVED, by_reason)
            self.assertIn(CONSTRAINT_CLAIM_LINE_PARENT_UNRESOLVED, by_reason)
            for context in by_reason.values():
                self.assertEqual(context.get("source_ref"), "src|dat")
                self.assertEqual(context.get("record_index"), 2)
                self.assertEqual(context.get("attachment_sha256"), "sha-parent")
                self.assertEqual(context.get("resolved_patient_id"), "12345")
                self.assertEqual(context.get("resolved_date_of_service"), "2025-01-15")
                self.assertEqual(context.get("resolved_payer_id"), "payer-a")
            self.assertEqual(by_reason[CONSTRAINT_COVERAGE_PARENT_UNRESOLVED].get("plan_key"), "plan_missing")
            self.assertEqual(by_reason[CONSTRAINT_ENCOUNTER_PATIENT_UNRESOLVED].get("patient_key"), "pk_missing")
            self.assertEqual(by_reason[CONSTRAINT_CLAIM_PARENT_UNRESOLVED].get("encounter_key"), "enc_missing")
            self.assertEqual(by_reason[CONSTRAINT_CLAIM_LINE_PARENT_UNRESOLVED].get("claim_key"), "claim_missing")
        finally:
            try:
                if os.path.exists(reports_dir):
                    for f in os.listdir(reports_dir):
                        os.remove(os.path.join(reports_dir, f))
                    os.rmdir(reports_dir)
                if os.path.exists(db_path):
                    os.remove(db_path)
                os.rmdir(lab_root)
            except Exception:
                pass

    def test_run_qa_canonical_logs_extractor_skip_rows_with_dat_provenance(self):
        from run_qa_canonical import run_qa_canonical
        from phase_d_v2_metrics import DAT_V2_SKIP_MISSING_PAYER_ANCHOR
        from unified_rollout_policy import INTERNAL_PHASE_D_ENTITY_SCOPE_ENV

        lab_root, db_path, reports_dir = _make_lab_with_db()
        old_env = os.environ.get(INTERNAL_PHASE_D_ENTITY_SCOPE_ENV)
        os.environ[INTERNAL_PHASE_D_ENTITY_SCOPE_ENV] = "v2"
        try:
            conn = sqlite3.connect(db_path)
            payload = json.dumps({
                "artifact_class": "dat",
                "locator": "",
                "normalized_path": "skip.ZDAT",
            }, separators=(",", ":"))
            conn.execute(
                "INSERT INTO ingest_artifact (ingest_key, source_system, source_type, source_ref, message_id, "
                "attachment_name, attachment_sha256, payload_json, ingest_status) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                ("dat_v2_skip", "xp_local", "file_dat", "src|path", None, "skip.ZDAT", "sha-dat", payload, "ingested"),
            )
            conn.commit()
            conn.close()

            mocked_envelope = {
                "records": [
                    {"PATID": "12345", "DATE1": "2025-01-15", "CHART": "C-9"},
                    {"PATID": "12345", "DATE1": "2025-01-15", "INSID": "payer-a", "CPT": "66984"},
                ],
            }
            with patch("run_qa_canonical.parse_artifact", return_value=(True, mocked_envelope, None)):
                with patch("run_qa_canonical.acquire_lock"):
                    with patch("run_qa_canonical.release_lock"):
                        ok, rid, summary, err = run_qa_canonical(lab_root)
            self.assertTrue(ok)
            self.assertIsNone(err)
            self.assertGreaterEqual(int((summary.get("dat_telemetry") or {}).get("phase_d_dat_v2_skipped_total", 0)), 1)

            conn = sqlite3.connect(db_path)
            rows = conn.execute(
                "SELECT decision_context_json FROM rule_decision_log WHERE decision_type='extractor_skip' ORDER BY decision_id"
            ).fetchall()
            conn.close()
            self.assertEqual(len(rows), 1)
            context = json.loads(rows[0][0])
            self.assertEqual(context.get("reason_code"), DAT_V2_SKIP_MISSING_PAYER_ANCHOR)
            self.assertEqual(context.get("source_ref"), "src|path")
            self.assertEqual(context.get("record_index"), 0)
            self.assertEqual(context.get("attachment_sha256"), "sha-dat")
            self.assertEqual(context.get("resolved_patient_id"), "12345")
            self.assertEqual(context.get("resolved_date_of_service"), "2025-01-15")
            self.assertEqual(context.get("resolved_payer_id"), "")
        finally:
            if old_env is None:
                try:
                    del os.environ[INTERNAL_PHASE_D_ENTITY_SCOPE_ENV]
                except Exception:
                    pass
            else:
                os.environ[INTERNAL_PHASE_D_ENTITY_SCOPE_ENV] = old_env
            try:
                if os.path.exists(reports_dir):
                    for f in os.listdir(reports_dir):
                        os.remove(os.path.join(reports_dir, f))
                    os.rmdir(reports_dir)
                if os.path.exists(db_path):
                    os.remove(db_path)
                os.rmdir(lab_root)
            except Exception:
                pass

    def test_run_qa_canonical_logs_dat_invalid_id_skip_with_pattern_source(self):
        from run_qa_canonical import run_qa_canonical
        from phase_d_v2_metrics import DAT_V2_SKIP_INVALID_PATIENT_ID
        from unified_rollout_policy import INTERNAL_PHASE_D_ENTITY_SCOPE_ENV

        lab_root, db_path, reports_dir = _make_lab_with_db()
        old_env = os.environ.get(INTERNAL_PHASE_D_ENTITY_SCOPE_ENV)
        os.environ[INTERNAL_PHASE_D_ENTITY_SCOPE_ENV] = "v2"
        try:
            conn = sqlite3.connect(db_path)
            payload = json.dumps({
                "artifact_class": "dat",
                "locator": "",
                "normalized_path": "invalid.ZDAT",
            }, separators=(",", ":"))
            conn.execute(
                "INSERT INTO ingest_artifact (ingest_key, source_system, source_type, source_ref, message_id, "
                "attachment_name, attachment_sha256, payload_json, ingest_status) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                ("dat_v2_invalid", "xp_local", "file_dat", "src|invalid", None, "invalid.ZDAT", "sha-invalid", payload, "ingested"),
            )
            conn.commit()
            conn.close()

            mocked_envelope = {
                "records": [
                    {"PATID": "3712", "DATE1": "2025-01-15", "INSID": "payer-a", "CHART": "C-9"},
                ],
            }
            with patch("run_qa_canonical.parse_artifact", return_value=(True, mocked_envelope, None)):
                with patch("run_qa_canonical.acquire_lock"):
                    with patch("run_qa_canonical.release_lock"):
                        ok, rid, summary, err = run_qa_canonical(lab_root)
            self.assertTrue(ok)
            self.assertIsNone(err)
            dm = summary.get("phase_d_v2_domain_metrics") or {}
            skipped = (dm.get("skipped_by_reason") or {}).get("dat_record") or {}
            self.assertEqual(skipped.get(DAT_V2_SKIP_INVALID_PATIENT_ID), 1)

            conn = sqlite3.connect(db_path)
            rows = conn.execute(
                "SELECT decision_context_json FROM rule_decision_log WHERE decision_type='extractor_skip' ORDER BY decision_id"
            ).fetchall()
            conn.close()
            self.assertEqual(len(rows), 1)
            context = json.loads(rows[0][0])
            self.assertEqual(context.get("reason_code"), DAT_V2_SKIP_INVALID_PATIENT_ID)
            self.assertEqual(context.get("resolved_patient_id"), "3712")
            self.assertEqual(context.get("invalid_external_patient_id_pattern"), "^[0-9]{5}$")
            self.assertEqual(context.get("invalid_external_patient_id_source"), "dat_record.patient_id")
            self.assertEqual(context.get("invalid_external_patient_id_reason"), "wrong_length")
            self.assertEqual(context.get("resolved_payer_id"), "payer-a")
            self.assertEqual(context.get("resolved_payer_id_source"), "payer_id")
        finally:
            if old_env is None:
                try:
                    del os.environ[INTERNAL_PHASE_D_ENTITY_SCOPE_ENV]
                except Exception:
                    pass
            else:
                os.environ[INTERNAL_PHASE_D_ENTITY_SCOPE_ENV] = old_env
            try:
                if os.path.exists(reports_dir):
                    for f in os.listdir(reports_dir):
                        os.remove(os.path.join(reports_dir, f))
                    os.rmdir(reports_dir)
                if os.path.exists(db_path):
                    os.remove(db_path)
                os.rmdir(lab_root)
            except Exception:
                pass

    def test_v2_dat_inserts_payer_claim_line_and_summary_metrics(self):
        from run_qa_canonical import run_qa_canonical
        from unified_rollout_policy import INTERNAL_PHASE_D_ENTITY_SCOPE_ENV

        lab_root, db_path, reports_dir = _make_lab_with_db()
        old_env = os.environ.get(INTERNAL_PHASE_D_ENTITY_SCOPE_ENV)
        os.environ[INTERNAL_PHASE_D_ENTITY_SCOPE_ENV] = "v2"
        try:
            conn = sqlite3.connect(db_path)
            payload = json.dumps({
                "artifact_class": "dat",
                "locator": "",
                "normalized_path": "depth.ZDAT",
            }, separators=(",", ":"))
            conn.execute(
                "INSERT INTO ingest_artifact (ingest_key, source_system, source_type, source_ref, message_id, "
                "attachment_name, attachment_sha256, payload_json, ingest_status) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                ("dat_v2_depth", "xp_local", "file_dat", "src|path", None, "depth.ZDAT", "", payload, "ingested"),
            )
            conn.commit()
            conn.close()

            mocked_envelope = {
                "records": [{
                    "PATID": "12345",
                    "FIRST": "A",
                    "LAST": "B",
                    "INSID": "payz",
                    "DATE1": "2025-01-20",
                    "CPT": "66984",
                }],
            }
            with patch("run_qa_canonical.parse_artifact", return_value=(True, mocked_envelope, None)):
                with patch("run_qa_canonical.acquire_lock"):
                    with patch("run_qa_canonical.release_lock"):
                        ok, rid, summary, err = run_qa_canonical(lab_root)
            self.assertTrue(ok)
            dm = summary.get("phase_d_v2_domain_metrics") or {}
            self.assertEqual(dm.get("schema_version"), "phase_d_v2_domain_metrics_v1")
            dat_lane = (dm.get("dat_record") or {}).get("by_entity") or {}
            self.assertGreaterEqual(int((dat_lane.get("payer") or {}).get("payload_attempted", 0)), 1)
            self.assertGreaterEqual(int((dat_lane.get("payer") or {}).get("inserted", 0)), 1)
            te = summary.get("dat_telemetry") or {}
            self.assertGreaterEqual(int(te.get("phase_d_dat_v2_inserted_payer", 0)), 1)
            self.assertGreaterEqual(int(te.get("phase_d_dat_v2_inserted_claim_line", 0)), 1)

            conn = sqlite3.connect(db_path)
            self.assertGreater(conn.execute("SELECT COUNT(*) FROM payer").fetchone()[0], 0)
            self.assertGreater(conn.execute("SELECT COUNT(*) FROM claim_line").fetchone()[0], 0)
            conn.close()
        finally:
            if old_env is None:
                try:
                    del os.environ[INTERNAL_PHASE_D_ENTITY_SCOPE_ENV]
                except Exception:
                    pass
            else:
                os.environ[INTERNAL_PHASE_D_ENTITY_SCOPE_ENV] = old_env
            try:
                if os.path.exists(reports_dir):
                    for f in os.listdir(reports_dir):
                        os.remove(os.path.join(reports_dir, f))
                    os.rmdir(reports_dir)
                if os.path.exists(db_path):
                    os.remove(db_path)
                os.rmdir(lab_root)
            except Exception:
                pass

    def test_v2_reprocess_after_qa_result_clear_has_ignored_duplicate(self):
        from run_qa_canonical import run_qa_canonical
        from unified_rollout_policy import INTERNAL_PHASE_D_ENTITY_SCOPE_ENV

        lab_root, db_path, reports_dir = _make_lab_with_db()
        old_env = os.environ.get(INTERNAL_PHASE_D_ENTITY_SCOPE_ENV)
        os.environ[INTERNAL_PHASE_D_ENTITY_SCOPE_ENV] = "v2"
        try:
            conn = sqlite3.connect(db_path)
            payload = json.dumps({
                "artifact_class": "dat",
                "locator": "",
                "normalized_path": "idem.ZDAT",
            }, separators=(",", ":"))
            conn.execute(
                "INSERT INTO ingest_artifact (ingest_key, source_system, source_type, source_ref, message_id, "
                "attachment_name, attachment_sha256, payload_json, ingest_status) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                ("dat_v2_idem", "xp_local", "file_dat", "src|path", None, "idem.ZDAT", "", payload, "ingested"),
            )
            conn.commit()
            conn.close()

            mocked_envelope = {
                "records": [{
                    "PATID": "12345",
                    "FIRST": "A",
                    "LAST": "B",
                    "INSID": "payi",
                    "DATE1": "2025-03-01",
                    "CPT": "66984",
                }],
            }
            with patch("run_qa_canonical.parse_artifact", return_value=(True, mocked_envelope, None)):
                with patch("run_qa_canonical.acquire_lock"):
                    with patch("run_qa_canonical.release_lock"):
                        ok1, _rid1, sum1, _e1 = run_qa_canonical(lab_root)
            self.assertTrue(ok1)

            conn = sqlite3.connect(db_path)
            conn.execute("DELETE FROM qa_result WHERE qa_stage='phase_d'")
            conn.commit()
            conn.close()

            with patch("run_qa_canonical.parse_artifact", return_value=(True, mocked_envelope, None)):
                with patch("run_qa_canonical.acquire_lock"):
                    with patch("run_qa_canonical.release_lock"):
                        ok2, _rid2, sum2, _e2 = run_qa_canonical(lab_root)
            self.assertTrue(ok2)
            self.assertGreater(int(sum2.get("rows_selected") or 0), 0)
            ign = int((sum2.get("dat_telemetry") or {}).get("phase_d_dat_v2_ignored_duplicate_total", 0))
            self.assertGreaterEqual(ign, 1)
        finally:
            if old_env is None:
                try:
                    del os.environ[INTERNAL_PHASE_D_ENTITY_SCOPE_ENV]
                except Exception:
                    pass
            else:
                os.environ[INTERNAL_PHASE_D_ENTITY_SCOPE_ENV] = old_env
            try:
                if os.path.exists(reports_dir):
                    for f in os.listdir(reports_dir):
                        os.remove(os.path.join(reports_dir, f))
                    os.rmdir(reports_dir)
                if os.path.exists(db_path):
                    os.remove(db_path)
                os.rmdir(lab_root)
            except Exception:
                pass

    def test_v2_mixed_dat_and_remittance_lanes(self):
        from run_qa_canonical import run_qa_canonical
        from unified_rollout_policy import INTERNAL_PHASE_D_ENTITY_SCOPE_ENV

        lab_root, db_path, reports_dir = _make_lab_with_db()
        old_env = os.environ.get(INTERNAL_PHASE_D_ENTITY_SCOPE_ENV)
        os.environ[INTERNAL_PHASE_D_ENTITY_SCOPE_ENV] = "v2"
        try:
            conn = sqlite3.connect(db_path)
            p_dat = json.dumps({
                "artifact_class": "dat",
                "locator": "",
                "normalized_path": "mix.ZDAT",
            }, separators=(",", ":"))
            p_jl = json.dumps({
                "artifact_class": "jsonl",
                "locator": "",
                "normalized_path": "mix.jsonl",
            }, separators=(",", ":"))
            conn.execute(
                "INSERT INTO ingest_artifact (ingest_key, source_system, source_type, source_ref, message_id, "
                "attachment_name, attachment_sha256, payload_json, ingest_status) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                ("mix_dat", "xp_local", "file_dat", "src|path", None, "mix.ZDAT", "", p_dat, "ingested"),
            )
            conn.execute(
                "INSERT INTO ingest_artifact (ingest_key, source_system, source_type, source_ref, message_id, "
                "attachment_name, attachment_sha256, payload_json, ingest_status) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                ("mix_jl", "xp_local", "file_jsonl", "src|path", None, "mix.jsonl", "", p_jl, "ingested"),
            )
            conn.commit()
            conn.close()

            def _parse_side_effect(locator, artifact_class, payload):
                if artifact_class == "dat":
                    return (True, {
                        "records": [{
                            "PATID": "11111",
                            "FIRST": "D",
                            "LAST": "E",
                            "INSID": "pd1",
                            "DATE1": "2025-04-01",
                            "CPT": "100",
                        }],
                    }, None)
                if artifact_class == "jsonl":
                    return (True, {
                        "rows": [{
                            "payer_id": "pr1",
                            "Payer Name": "R1",
                            "Patient ID": "22222",
                            "date_of_service": "2025-04-02",
                            "claim_number": "c1",
                        }],
                    }, None)
                return (False, {}, "x")

            with patch("run_qa_canonical.parse_artifact", side_effect=_parse_side_effect):
                with patch("run_qa_canonical.acquire_lock"):
                    with patch("run_qa_canonical.release_lock"):
                        ok, rid, summary, err = run_qa_canonical(lab_root)
            self.assertTrue(ok)
            dm = summary.get("phase_d_v2_domain_metrics") or {}
            rem = (dm.get("remittance_row") or {}).get("by_entity") or {}
            dat_lane = (dm.get("dat_record") or {}).get("by_entity") or {}
            self.assertGreaterEqual(int((rem.get("payer") or {}).get("inserted", 0)), 1)
            self.assertGreaterEqual(int((dat_lane.get("payer") or {}).get("inserted", 0)), 1)
        finally:
            if old_env is None:
                try:
                    del os.environ[INTERNAL_PHASE_D_ENTITY_SCOPE_ENV]
                except Exception:
                    pass
            else:
                os.environ[INTERNAL_PHASE_D_ENTITY_SCOPE_ENV] = old_env
            try:
                if os.path.exists(reports_dir):
                    for f in os.listdir(reports_dir):
                        os.remove(os.path.join(reports_dir, f))
                    os.rmdir(reports_dir)
                if os.path.exists(db_path):
                    os.remove(db_path)
                os.rmdir(lab_root)
            except Exception:
                pass


class TestCsvDocxJoinTelemetry(unittest.TestCase):
    def test_normalize_surgery_date_key_handles_slash_and_iso_values(self):
        from patient_field_mapper import normalize_surgery_date_key

        self.assertEqual(normalize_surgery_date_key("01/15/2025"), "01-15-2025")
        self.assertEqual(normalize_surgery_date_key("2025-01-15T00:00:00"), "01-15-2025")

    def test_annotate_csv_docx_join_counts_matched_csv_only_and_docx_only(self):
        from canonical_extractor import annotate_csv_docx_join

        canonical_records = [
            {
                "artifact_id": 1,
                "canonical_type": "patient_csv_row",
                "canonical_key": "csv-1",
                "canonical_json": json.dumps({
                    "Patient ID": "12345",
                    "Patient Name": "Match",
                    "Surgery Date": "01/15/2025",
                }, separators=(",", ":")),
                "provenance_json": json.dumps({"artifact_id": 1}, separators=(",", ":")),
            },
            {
                "artifact_id": 2,
                "canonical_type": "patient_csv_row",
                "canonical_key": "csv-2",
                "canonical_json": json.dumps({
                    "Patient ID": "67890",
                    "Patient Name": "Csv Only",
                    "Surgery Date": "01/16/2025",
                }, separators=(",", ":")),
                "provenance_json": json.dumps({"artifact_id": 2}, separators=(",", ":")),
            },
            {
                "artifact_id": 3,
                "canonical_type": "docx_schedule",
                "canonical_key": "docx-1",
                "canonical_json": json.dumps({
                    "diagnosis": "Cataract",
                    "eye": "OD",
                    "femto": "Y",
                }, separators=(",", ":")),
                "provenance_json": json.dumps({
                    "artifact_id": 3,
                    "patient_id": "12345",
                    "schedule_key": "01-15-2025",
                }, separators=(",", ":")),
            },
            {
                "artifact_id": 4,
                "canonical_type": "docx_schedule",
                "canonical_key": "docx-2",
                "canonical_json": json.dumps({
                    "diagnosis": "Other",
                }, separators=(",", ":")),
                "provenance_json": json.dumps({
                    "artifact_id": 4,
                    "patient_id": "99999",
                    "schedule_key": "01-20-2025",
                }, separators=(",", ":")),
            },
        ]

        telemetry = annotate_csv_docx_join(canonical_records)

        self.assertEqual(telemetry.get("matched_count"), 1)
        self.assertEqual(telemetry.get("csv_only_count"), 1)
        self.assertEqual(telemetry.get("docx_only_count"), 1)
        self.assertEqual(telemetry.get("ambiguous_count"), 0)

        matched_row = json.loads(canonical_records[0]["canonical_json"])
        self.assertEqual(matched_row.get("docx_schedule_match_status"), "matched")
        self.assertEqual(matched_row.get("docx_schedule_diagnosis"), "Cataract")

        csv_only_row = json.loads(canonical_records[1]["canonical_json"])
        self.assertEqual(csv_only_row.get("docx_schedule_match_status"), "csv_only")

    def test_annotate_csv_docx_join_surfaces_ambiguity_defaults(self):
        from canonical_extractor import annotate_csv_docx_join

        canonical_records = [
            {
                "artifact_id": 11,
                "canonical_type": "patient_csv_row",
                "canonical_key": "csv-a",
                "canonical_json": json.dumps({
                    "Patient ID": "12345",
                    "Surgery Date": "01/15/2025",
                }, separators=(",", ":")),
                "provenance_json": json.dumps({"artifact_id": 11}, separators=(",", ":")),
            },
            {
                "artifact_id": 12,
                "canonical_type": "patient_csv_row",
                "canonical_key": "csv-b",
                "canonical_json": json.dumps({
                    "Patient ID": "12345",
                    "Surgery Date": "01/15/2025",
                }, separators=(",", ":")),
                "provenance_json": json.dumps({"artifact_id": 12}, separators=(",", ":")),
            },
            {
                "artifact_id": 13,
                "canonical_type": "docx_schedule",
                "canonical_key": "docx-a",
                "canonical_json": json.dumps({
                    "diagnosis": "Cataract",
                }, separators=(",", ":")),
                "provenance_json": json.dumps({
                    "artifact_id": 13,
                    "patient_id": "12345",
                    "schedule_key": "01-15-2025",
                }, separators=(",", ":")),
            },
        ]

        telemetry = annotate_csv_docx_join(canonical_records)

        self.assertEqual(telemetry.get("ambiguous_count"), 1)
        self.assertEqual(telemetry.get("ambiguous_default_policy"), "suppress_docx_enrichment_keep_csv_row")
        self.assertEqual(telemetry.get("ambiguous_negotiation"), "multiple_candidates_shared_join_key_no_deterministic_docx_winner")
        example = (telemetry.get("ambiguous_examples") or [])[0]
        self.assertEqual(example.get("join_key"), "12345|01-15-2025")
        self.assertEqual(example.get("csv_candidate_count"), 2)
        self.assertEqual(example.get("docx_candidate_count"), 1)
        self.assertEqual(example.get("selected_default"), "suppress_docx_enrichment_keep_csv_row")

        ambiguous_row = json.loads(canonical_records[0]["canonical_json"])
        self.assertEqual(ambiguous_row.get("docx_schedule_match_status"), "ambiguous")
        self.assertEqual(ambiguous_row.get("docx_schedule_match_policy"), "suppress_docx_enrichment_keep_csv_row")
        self.assertEqual(ambiguous_row.get("docx_schedule_match_reason"), "multiple_candidates_shared_join_key_no_deterministic_docx_winner")


class TestRunQaCanonicalCsvDocxJoinIntegration(unittest.TestCase):
    def test_run_qa_canonical_persists_csv_docx_join_telemetry_and_annotations(self):
        from run_qa_canonical import run_qa_canonical

        lab_root, db_path, reports_dir = _make_lab_with_db()
        try:
            conn = sqlite3.connect(db_path)
            payload_csv = json.dumps({
                "artifact_class": "csv",
                "locator": os.path.join(lab_root, "upstream.csv"),
            }, separators=(",", ":"))
            payload_docx = json.dumps({
                "artifact_class": "docx",
                "locator": os.path.join(lab_root, "schedule.docx"),
            }, separators=(",", ":"))
            conn.execute(
                "INSERT INTO ingest_artifact (ingest_key, source_system, source_type, source_ref, message_id, "
                "attachment_name, attachment_sha256, payload_json, ingest_status) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                ("csv_join_1", "xp_local", "file_csv", "src|csv", None, "upstream.csv", "", payload_csv, "ingested"),
            )
            conn.execute(
                "INSERT INTO ingest_artifact (ingest_key, source_system, source_type, source_ref, message_id, "
                "attachment_name, attachment_sha256, payload_json, ingest_status) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                ("docx_join_1", "xp_local", "file_docx", "src|docx", None, "schedule.docx", "", payload_docx, "ingested"),
            )
            conn.commit()
            conn.close()

            def fake_parse(locator, artifact_class, payload=None):
                if artifact_class == "csv":
                    return True, {
                        "rows": [{
                            "Patient ID": "12345",
                            "Patient Name": "Join Test",
                            "Birth Date": "01-01-1990",
                            "Surgery Date": "01/15/2025",
                        }],
                        "row_count": 1,
                        "has_patient_id": True,
                    }, None
                if artifact_class == "docx":
                    return True, {
                        "patient_data": {
                            "12345": {
                                "01-15-2025": {
                                    "diagnosis": "Cataract",
                                    "eye": "OD",
                                    "femto": "Y",
                                }
                            }
                        }
                    }, None
                raise AssertionError("unexpected artifact_class={0}".format(artifact_class))

            with patch("run_qa_canonical.parse_artifact", side_effect=fake_parse):
                with patch("run_qa_canonical.acquire_lock"):
                    with patch("run_qa_canonical.release_lock"):
                        ok, rid, summary, err = run_qa_canonical(lab_root)

            self.assertTrue(ok)
            self.assertIsNone(err)
            join = summary.get("csv_docx_join_telemetry") or {}
            self.assertEqual(join.get("join_key"), "patient_id+surgery_date")
            self.assertEqual(join.get("matched_count"), 1)
            self.assertEqual(join.get("csv_only_count"), 0)
            self.assertEqual(join.get("docx_only_count"), 0)
            self.assertEqual(join.get("ambiguous_count"), 0)
            self.assertEqual(join.get("csv_candidate_count"), 1)
            self.assertEqual(join.get("csv_join_key_count"), 1)
            self.assertEqual(join.get("docx_candidate_count"), 1)
            self.assertEqual(join.get("docx_join_key_count"), 1)

            conn = sqlite3.connect(db_path)
            row = conn.execute(
                "SELECT canonical_json FROM extracted_canonical_record WHERE canonical_type='patient_csv_row'"
            ).fetchone()
            conn.close()
            self.assertTrue(row)
            annotated = json.loads(row[0])
            self.assertEqual(annotated.get("docx_schedule_match_status"), "matched")
            self.assertEqual(annotated.get("docx_schedule_diagnosis"), "Cataract")
            self.assertEqual(annotated.get("docx_schedule_eye"), "OD")
            self.assertEqual(annotated.get("docx_schedule_femto"), "Y")

            with open(os.path.join(lab_root, "diagnostics_state.json"), "r", encoding="utf-8") as f:
                state = json.load(f)
            self.assertEqual(((state.get("last_phase_d_csv_docx_join_telemetry") or {}).get("matched_count")), 1)

            with open(os.path.join(lab_root, "run_cursor.json"), "r", encoding="utf-8") as f:
                cursor = json.load(f)
            self.assertEqual(((cursor.get("last_phase_d_csv_docx_join_telemetry") or {}).get("docx_only_count")), 0)
        finally:
            try:
                if os.path.exists(reports_dir):
                    for f in os.listdir(reports_dir):
                        os.remove(os.path.join(reports_dir, f))
                    os.rmdir(reports_dir)
                if os.path.exists(db_path):
                    os.remove(db_path)
                os.rmdir(lab_root)
            except Exception:
                pass

    def test_run_qa_canonical_logs_csv_docx_ambiguity_defaults(self):
        from run_qa_canonical import run_qa_canonical

        lab_root, db_path, reports_dir = _make_lab_with_db()
        try:
            conn = sqlite3.connect(db_path)
            payload_csv = json.dumps({
                "artifact_class": "csv",
                "locator": os.path.join(lab_root, "ambiguous.csv"),
            }, separators=(",", ":"))
            payload_docx = json.dumps({
                "artifact_class": "docx",
                "locator": os.path.join(lab_root, "ambiguous.docx"),
            }, separators=(",", ":"))
            conn.execute(
                "INSERT INTO ingest_artifact (ingest_key, source_system, source_type, source_ref, message_id, "
                "attachment_name, attachment_sha256, payload_json, ingest_status) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                ("csv_ambiguous_1", "xp_local", "file_csv", "src|csv", None, "ambiguous.csv", "", payload_csv, "ingested"),
            )
            conn.execute(
                "INSERT INTO ingest_artifact (ingest_key, source_system, source_type, source_ref, message_id, "
                "attachment_name, attachment_sha256, payload_json, ingest_status) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                ("docx_ambiguous_1", "xp_local", "file_docx", "src|docx", None, "ambiguous.docx", "", payload_docx, "ingested"),
            )
            conn.commit()
            conn.close()

            def fake_parse(locator, artifact_class, payload=None):
                if artifact_class == "csv":
                    return True, {
                        "rows": [
                            {"Patient ID": "12345", "Patient Name": "Join A", "Birth Date": "01-01-1990", "Surgery Date": "01/15/2025"},
                            {"Patient ID": "12345", "Patient Name": "Join B", "Birth Date": "01-01-1990", "Surgery Date": "01/15/2025"},
                        ],
                        "row_count": 2,
                        "has_patient_id": True,
                    }, None
                if artifact_class == "docx":
                    return True, {
                        "patient_data": {
                            "12345": {
                                "01-15-2025": {"diagnosis": "Cataract", "eye": "OD", "femto": "Y"}
                            }
                        }
                    }, None
                raise AssertionError("unexpected artifact_class={0}".format(artifact_class))

            with patch("run_qa_canonical.parse_artifact", side_effect=fake_parse):
                with patch("run_qa_canonical.acquire_lock"):
                    with patch("run_qa_canonical.release_lock"):
                        ok, rid, summary, err = run_qa_canonical(lab_root)

            self.assertTrue(ok)
            self.assertIsNone(err)
            join = summary.get("csv_docx_join_telemetry") or {}
            self.assertEqual(join.get("ambiguous_count"), 1)
            self.assertEqual(join.get("csv_candidate_count"), 2)
            self.assertEqual(join.get("csv_join_key_count"), 1)
            self.assertEqual(join.get("docx_candidate_count"), 1)
            self.assertEqual(join.get("docx_join_key_count"), 1)
            self.assertEqual(join.get("negotiation_run_id"), rid)
            self.assertTrue(str(join.get("negotiation_log_ref", "")).startswith("qa_planning_telemetry_log#"))
            self.assertEqual(join.get("ambiguous_default_policy"), "suppress_docx_enrichment_keep_csv_row")
            self.assertEqual(join.get("ambiguous_negotiation"), "multiple_candidates_shared_join_key_no_deterministic_docx_winner")
            example = (join.get("ambiguous_examples") or [])[0]
            self.assertEqual(example.get("selected_default"), "suppress_docx_enrichment_keep_csv_row")

            summary_txt = os.path.join(reports_dir, "qa_canonical_summary_{0}.txt".format(rid))
            with open(summary_txt, "r", encoding="utf-8") as f:
                text = f.read()
            self.assertIn("csv_docx_join_ambiguous_default_policy: suppress_docx_enrichment_keep_csv_row", text)
            self.assertIn("csv_docx_join_negotiation_log: qa_planning_telemetry_log#", text)
            self.assertIn("(run_id={0})".format(rid), text)
            self.assertIn("12345|01-15-2025(csv=2,docx=1;default=suppress_docx_enrichment_keep_csv_row)", text)

            conn = sqlite3.connect(db_path)
            telemetry_rows = conn.execute(
                "SELECT telemetry_json FROM qa_planning_telemetry_log ORDER BY telemetry_id"
            ).fetchall()
            canonical_rows = conn.execute(
                "SELECT canonical_json FROM extracted_canonical_record WHERE canonical_type='patient_csv_row' ORDER BY canonical_record_id"
            ).fetchall()
            conn.close()
            negotiation_events = [json.loads(row[0]) for row in telemetry_rows if json.loads(row[0]).get("event") == "csv_docx_join_negotiation"]
            self.assertEqual(len(negotiation_events), 1)
            self.assertEqual(negotiation_events[0].get("run_id"), rid)
            self.assertEqual((((negotiation_events[0].get("telemetry") or {}).get("ambiguous_examples") or [])[0].get("join_key")), "12345|01-15-2025")
            ambiguous_row = json.loads(canonical_rows[0][0])
            self.assertEqual(ambiguous_row.get("docx_schedule_match_status"), "ambiguous")
            self.assertEqual(ambiguous_row.get("docx_schedule_match_policy"), "suppress_docx_enrichment_keep_csv_row")
        finally:
            try:
                if os.path.exists(reports_dir):
                    for f in os.listdir(reports_dir):
                        os.remove(os.path.join(reports_dir, f))
                    os.rmdir(reports_dir)
                if os.path.exists(db_path):
                    os.remove(db_path)
                os.rmdir(lab_root)
            except Exception:
                pass


class TestJoinContractDatCsvAlignment(unittest.TestCase):
    """DAT↔CSV alignment via join_contract.annotate_dat_csv_alignment."""

    def test_dat_alias_patient_id_date_of_service_joins_csv(self):
        import patient_field_mapper as pfm
        from join_contract import annotate_dat_csv_alignment

        canonical_records = [
            {
                "canonical_type": "patient_csv_row",
                "artifact_id": 1,
                "canonical_json": json.dumps({
                    "Patient ID": "12345",
                    "Surgery Date": "01/15/2025",
                }, separators=(",", ":")),
            },
            {
                "canonical_type": "dat_record",
                "artifact_id": 2,
                "canonical_json": json.dumps({
                    "patient_id": "12345",
                    "date_of_service": "2025-01-15",
                    "PAYERID": "payer-x",
                }, separators=(",", ":")),
                "provenance_json": json.dumps({
                    "artifact_id": 2,
                    "source_ref": "a.dat",
                    "record_index": 0,
                }, separators=(",", ":")),
            },
        ]
        tel = annotate_dat_csv_alignment(canonical_records, pfm)
        self.assertEqual(tel.get("matched_count"), 1)
        self.assertEqual(tel.get("csv_only_count"), 0)
        row = json.loads(canonical_records[0]["canonical_json"])
        self.assertEqual(row.get("dat_alignment_status"), "matched")

    def test_multi_dat_same_artifact_record_index_primary_is_lower(self):
        import patient_field_mapper as pfm
        from join_contract import annotate_dat_csv_alignment, dat_csv_needs_negotiation_log

        canonical_records = [
            {
                "canonical_type": "patient_csv_row",
                "artifact_id": 1,
                "canonical_json": json.dumps({
                    "Patient ID": "12345",
                    "Surgery Date": "01/15/2025",
                }, separators=(",", ":")),
            },
            {
                "canonical_type": "dat_record",
                "artifact_id": 2,
                "canonical_json": json.dumps({
                    "PATID": "12345",
                    "DOS": "01/15/2025",
                    "PAYERID": "p1",
                }, separators=(",", ":")),
                "provenance_json": json.dumps({
                    "artifact_id": 2,
                    "source_ref": "z.dat",
                    "record_index": 1,
                }, separators=(",", ":")),
            },
            {
                "canonical_type": "dat_record",
                "artifact_id": 2,
                "canonical_json": json.dumps({
                    "PATID": "12345",
                    "DOS": "01/15/2025",
                    "PAYERID": "p1",
                }, separators=(",", ":")),
                "provenance_json": json.dumps({
                    "artifact_id": 2,
                    "source_ref": "z.dat",
                    "record_index": 0,
                }, separators=(",", ":")),
            },
        ]
        tel = annotate_dat_csv_alignment(canonical_records, pfm)
        self.assertEqual(tel.get("ambiguous_multi_dat_count"), 1)
        self.assertTrue(dat_csv_needs_negotiation_log(tel))
        row = json.loads(canonical_records[0]["canonical_json"])
        self.assertEqual(row.get("dat_alignment_status"), "ambiguous_multi_dat")
        self.assertEqual(row.get("dat_alignment_primary_record_index"), 0)

    def test_payer_mismatch_increments_and_requires_log(self):
        import patient_field_mapper as pfm
        from join_contract import annotate_dat_csv_alignment, dat_csv_needs_negotiation_log

        canonical_records = [
            {
                "canonical_type": "patient_csv_row",
                "artifact_id": 1,
                "canonical_json": json.dumps({
                    "Patient ID": "12345",
                    "Surgery Date": "01/15/2025",
                    "Insurance ID": "ins-a",
                }, separators=(",", ":")),
            },
            {
                "canonical_type": "dat_record",
                "artifact_id": 2,
                "canonical_json": json.dumps({
                    "PATID": "12345",
                    "DOS": "01/15/2025",
                    "PAYERID": "ins-b",
                }, separators=(",", ":")),
                "provenance_json": json.dumps({"artifact_id": 2, "source_ref": "x.dat", "record_index": 0}, separators=(",", ":")),
            },
        ]
        tel = annotate_dat_csv_alignment(canonical_records, pfm)
        self.assertEqual(tel.get("payer_mismatch_count"), 1)
        self.assertTrue(dat_csv_needs_negotiation_log(tel))
        row = json.loads(canonical_records[0]["canonical_json"])
        self.assertTrue(row.get("dat_alignment_payer_mismatch"))


class TestRunQaCanonicalDatCsvOrder(unittest.TestCase):
    """upstream_first_insert_or_ignore: non-dat artifacts run before dat (D-038)."""

    def test_phase_d_invokes_parse_csv_before_dat_when_dat_inserted_first(self):
        from run_qa_canonical import run_qa_canonical

        lab_root, db_path, reports_dir = _make_lab_with_db()
        env_key = "MEDICAFE_INTERNAL_PHASE_D_ENTITY_SCOPE"
        old_env = os.environ.get(env_key)
        try:
            # v2: dat_record also emits patient upserts so CSV-first + INSERT OR IGNORE proves upstream wins.
            os.environ[env_key] = "v2"
            conn = sqlite3.connect(db_path)
            payload_dat = json.dumps({
                "artifact_class": "dat",
                "locator": os.path.join(lab_root, "post.dat"),
            }, separators=(",", ":"))
            payload_csv = json.dumps({
                "artifact_class": "csv",
                "locator": os.path.join(lab_root, "pre.csv"),
            }, separators=(",", ":"))
            conn.execute(
                "INSERT INTO ingest_artifact (ingest_key, source_system, source_type, source_ref, message_id, "
                "attachment_name, attachment_sha256, payload_json, ingest_status) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                ("dat_first", "xp_local", "file_dat", "src|dat", None, "post.dat", "", payload_dat, "ingested"),
            )
            conn.execute(
                "INSERT INTO ingest_artifact (ingest_key, source_system, source_type, source_ref, message_id, "
                "attachment_name, attachment_sha256, payload_json, ingest_status) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                ("csv_second", "xp_local", "file_csv", "src|csv", None, "pre.csv", "", payload_csv, "ingested"),
            )
            conn.commit()
            conn.close()

            parse_order = []

            def fake_parse(locator, artifact_class, payload=None):
                parse_order.append(artifact_class)
                if artifact_class == "csv":
                    return True, {
                        "rows": [{
                            "Patient ID": "12345",
                            "Patient Name": "Order Test",
                            "Surgery Date": "01/15/2025",
                        }],
                        "row_count": 1,
                        "has_patient_id": True,
                    }, None
                if artifact_class == "dat":
                    return True, {
                        "records": [{
                            "PATID": "12345",
                            "FIRST": "O",
                            "LAST": "T",
                            "DOS": "01/15/2025",
                            "PAYERID": "pay1",
                        }],
                        "record_count": 1,
                    }, None
                raise AssertionError("unexpected artifact_class={0}".format(artifact_class))

            with patch("run_qa_canonical.parse_artifact", side_effect=fake_parse):
                with patch("run_qa_canonical.acquire_lock"):
                    with patch("run_qa_canonical.release_lock"):
                        ok, rid, summary, err = run_qa_canonical(lab_root)

            self.assertTrue(ok)
            self.assertIsNone(err)
            self.assertEqual(parse_order, ["csv", "dat"])
            dcsv = summary.get("dat_csv_join_telemetry") or {}
            self.assertEqual(dcsv.get("matched_count"), 1)
            conn_chk = sqlite3.connect(db_path)
            try:
                row_pat = conn_chk.execute(
                    "SELECT full_name FROM patient WHERE external_patient_id=?",
                    ("12345",),
                ).fetchone()
            finally:
                conn_chk.close()
            self.assertIsNotNone(row_pat)
            self.assertEqual(row_pat[0], "Order Test")
            with open(os.path.join(lab_root, "diagnostics_state.json"), "r", encoding="utf-8") as f:
                state = json.load(f)
            self.assertIn("last_phase_d_dat_csv_join_telemetry", state)
        finally:
            if old_env is None:
                os.environ.pop(env_key, None)
            else:
                os.environ[env_key] = old_env
            try:
                if os.path.exists(reports_dir):
                    for f in os.listdir(reports_dir):
                        os.remove(os.path.join(reports_dir, f))
                    os.rmdir(reports_dir)
                if os.path.exists(db_path):
                    os.remove(db_path)
                os.rmdir(lab_root)
            except Exception:
                pass

    def test_run_qa_canonical_logs_dat_csv_negotiation_on_payer_mismatch(self):
        from run_qa_canonical import run_qa_canonical

        lab_root, db_path, reports_dir = _make_lab_with_db()
        env_key = "MEDICAFE_INTERNAL_PHASE_D_ENTITY_SCOPE"
        old_env = os.environ.get(env_key)
        try:
            os.environ[env_key] = "v1"
            conn = sqlite3.connect(db_path)
            payload_csv = json.dumps({
                "artifact_class": "csv",
                "locator": os.path.join(lab_root, "m.csv"),
            }, separators=(",", ":"))
            payload_dat = json.dumps({
                "artifact_class": "dat",
                "locator": os.path.join(lab_root, "m.dat"),
            }, separators=(",", ":"))
            conn.execute(
                "INSERT INTO ingest_artifact (ingest_key, source_system, source_type, source_ref, message_id, "
                "attachment_name, attachment_sha256, payload_json, ingest_status) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                ("csv_pm", "xp_local", "file_csv", "src|csv", None, "m.csv", "", payload_csv, "ingested"),
            )
            conn.execute(
                "INSERT INTO ingest_artifact (ingest_key, source_system, source_type, source_ref, message_id, "
                "attachment_name, attachment_sha256, payload_json, ingest_status) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                ("dat_pm", "xp_local", "file_dat", "src|dat", None, "m.dat", "", payload_dat, "ingested"),
            )
            conn.commit()
            conn.close()

            def fake_parse(locator, artifact_class, payload=None):
                if artifact_class == "csv":
                    return True, {
                        "rows": [{
                            "Patient ID": "12345",
                            "Patient Name": "PM Test",
                            "Surgery Date": "01/15/2025",
                            "Insurance ID": "ins-csv",
                        }],
                        "row_count": 1,
                        "has_patient_id": True,
                    }, None
                if artifact_class == "dat":
                    return True, {
                        "records": [{
                            "PATID": "12345",
                            "FIRST": "P",
                            "LAST": "M",
                            "DOS": "01/15/2025",
                            "PAYERID": "ins-dat",
                        }],
                        "record_count": 1,
                    }, None
                raise AssertionError("unexpected artifact_class={0}".format(artifact_class))

            with patch("run_qa_canonical.parse_artifact", side_effect=fake_parse):
                with patch("run_qa_canonical.acquire_lock"):
                    with patch("run_qa_canonical.release_lock"):
                        ok, rid, summary, err = run_qa_canonical(lab_root)

            self.assertTrue(ok)
            self.assertIsNone(err)
            dcsv = summary.get("dat_csv_join_telemetry") or {}
            self.assertEqual(dcsv.get("payer_mismatch_count"), 1)
            self.assertTrue(str(dcsv.get("negotiation_log_ref", "")).startswith("qa_planning_telemetry_log#"))

            conn = sqlite3.connect(db_path)
            rows = conn.execute("SELECT telemetry_json FROM qa_planning_telemetry_log").fetchall()
            conn.close()
            events = [json.loads(r[0]) for r in rows]
            dat_events = [e for e in events if e.get("event") == "dat_csv_join_negotiation"]
            self.assertEqual(len(dat_events), 1)
            self.assertEqual(dat_events[0].get("run_id"), rid)
        finally:
            if old_env is None:
                os.environ.pop(env_key, None)
            else:
                os.environ[env_key] = old_env
            try:
                if os.path.exists(reports_dir):
                    for f in os.listdir(reports_dir):
                        os.remove(os.path.join(reports_dir, f))
                    os.rmdir(reports_dir)
                if os.path.exists(db_path):
                    os.remove(db_path)
                os.rmdir(lab_root)
            except Exception:
                pass


class TestPersistPhaseDRunCursorUpdatedAt(unittest.TestCase):
    """persist_phase_d_state sets updated_at_utc to match last_phase_d_at_utc."""

    def test_updated_at_matches_phase_d_timestamp(self):
        from run_qa_canonical import persist_phase_d_state

        lab_root = tempfile.mkdtemp()
        cursor_path = os.path.join(lab_root, "run_cursor.json")
        state_path = os.path.join(lab_root, "diagnostics_state.json")
        try:
            with open(cursor_path, "w", encoding="utf-8") as f:
                json.dump({"updated_at_utc": "2000-01-01T00:00:00Z"}, f)
            persist_phase_d_state(
                lab_root,
                "rid-d-test",
                True,
                None,
                0,
                0,
                0,
                0,
                {},
            )
            with open(cursor_path, "r", encoding="utf-8") as f:
                cursor = json.load(f)
            self.assertEqual(cursor.get("updated_at_utc"), cursor.get("last_phase_d_at_utc"))
            self.assertNotEqual(cursor.get("updated_at_utc"), "2000-01-01T00:00:00Z")
        finally:
            for p in (cursor_path, state_path):
                if os.path.exists(p):
                    os.remove(p)
            os.rmdir(lab_root)


class TestZeroSelectionLineageResolution(unittest.TestCase):
    def test_resolver_prefers_pipeline_phase_hint_over_stale_cursor(self):
        from run_qa_canonical import _resolve_phase_c_summary_for_zero_selection

        lab_root = tempfile.mkdtemp()
        reports_dir = os.path.join(lab_root, "reports")
        os.makedirs(reports_dir)
        current_c = "20260330-232310-dc3c07d5"
        stale_c = "20260330-151330-34e4afb4"
        old_env = os.environ.get("MEDICAFE_SHADOW_PIPELINE_PHASE_RUN_IDS_JSON")
        try:
            with open(os.path.join(reports_dir, "ingest_write_summary_{0}.json".format(current_c)), "w", encoding="utf-8") as f:
                json.dump({"run_id": current_c, "rows_inserted": 0}, f)
            with open(os.path.join(reports_dir, "ingest_write_summary_{0}.json".format(stale_c)), "w", encoding="utf-8") as f:
                json.dump({"run_id": stale_c, "rows_inserted": 0}, f)
            with open(os.path.join(lab_root, "diagnostics_state.json"), "w", encoding="utf-8") as f:
                json.dump({"last_shadow_pipeline_phase_run_ids": {"C": current_c}}, f)
            with open(os.path.join(lab_root, "run_cursor.json"), "w", encoding="utf-8") as f:
                json.dump({"last_phase_c_run_id": stale_c}, f)
            os.environ["MEDICAFE_SHADOW_PIPELINE_PHASE_RUN_IDS_JSON"] = json.dumps({"C": current_c})

            rid_used, path_used, payload, mismatch, resolution_source, expected_phase_c_run_id = _resolve_phase_c_summary_for_zero_selection(lab_root)

            self.assertEqual(rid_used, current_c)
            self.assertEqual(expected_phase_c_run_id, current_c)
            self.assertEqual(resolution_source, "pipeline_phase_hint")
            self.assertTrue(path_used.endswith("ingest_write_summary_{0}.json".format(current_c)))
            self.assertEqual((payload or {}).get("run_id"), current_c)
            self.assertIn(stale_c, mismatch)
        finally:
            if old_env is None:
                os.environ.pop("MEDICAFE_SHADOW_PIPELINE_PHASE_RUN_IDS_JSON", None)
            else:
                os.environ["MEDICAFE_SHADOW_PIPELINE_PHASE_RUN_IDS_JSON"] = old_env
            try:
                import shutil
                shutil.rmtree(lab_root, ignore_errors=True)
            except Exception:
                pass


class TestHistoricalPhaseDReprocess(unittest.TestCase):
    def setUp(self):
        self.lab_root = tempfile.mkdtemp()
        self.db_path = os.path.join(self.lab_root, 'unified_model_xp.db')
        self.conn = sqlite3.connect(self.db_path)
        self.conn.execute('CREATE TABLE ingest_artifact (artifact_id INTEGER PRIMARY KEY, source_type TEXT, payload_json TEXT)')
        self.conn.execute('CREATE TABLE qa_result (artifact_id INTEGER, qa_stage TEXT, qa_version TEXT, status TEXT)')
        self.conn.execute('CREATE TABLE replay_queue (artifact_id INTEGER, status TEXT)')
        self.conn.commit()

    def tearDown(self):
        try:
            self.conn.close()
        except Exception:
            pass
        try:
            import shutil
            shutil.rmtree(self.lab_root, ignore_errors=True)
        except Exception:
            pass

    def test_collect_snapshot_counts_current_version_rejects_and_pending_replay(self):
        self.conn.execute("INSERT INTO ingest_artifact VALUES (1, 'file_dat', '{}')")
        self.conn.execute("INSERT INTO ingest_artifact VALUES (2, 'file_csv', '{}')")
        self.conn.execute("INSERT INTO qa_result VALUES (1, 'phase_d', 'qa_v2', 'reject')")
        self.conn.execute("INSERT INTO qa_result VALUES (2, 'phase_d', 'qa_v2', 'reject')")
        self.conn.execute("INSERT INTO replay_queue VALUES (1, 'pending')")
        self.conn.execute("INSERT INTO replay_queue VALUES (2, 'pending')")
        self.conn.commit()

        snapshot = collect_phase_d_reject_snapshot(self.lab_root)
        self.assertTrue(snapshot.get('ok'))
        self.assertEqual(snapshot.get('targeted_artifact_classes'), ['csv', 'dat'])
        self.assertEqual(snapshot.get('reject_counts_by_class', {}).get('dat'), 1)
        self.assertEqual(snapshot.get('reject_counts_by_class', {}).get('csv'), 1)
        self.assertEqual(snapshot.get('pending_replay_counts_by_class', {}).get('dat'), 1)
        self.assertEqual(snapshot.get('pending_replay_counts_by_class', {}).get('csv'), 1)

    def test_preview_writes_report_without_mutating_state(self):
        self.conn.execute("INSERT INTO ingest_artifact VALUES (1, 'file_dat', '{}')")
        self.conn.execute("INSERT INTO qa_result VALUES (1, 'phase_d', 'qa_v2', 'reject')")
        self.conn.commit()

        preview = preview_historical_phase_d_reprocess(self.lab_root, artifact_classes=['dat'])
        self.assertTrue(preview.get('ok'))
        self.assertTrue(os.path.isfile(preview.get('report_path')))
        remaining = self.conn.execute("SELECT COUNT(*) FROM qa_result WHERE status='reject'").fetchone()[0]
        self.assertEqual(remaining, 1)

    def test_execute_clears_only_targeted_rejects_and_abandons_pending_replay(self):
        self.conn.execute("INSERT INTO ingest_artifact VALUES (1, 'file_dat', '{}')")
        self.conn.execute("INSERT INTO ingest_artifact VALUES (2, 'file_dat', '{}')")
        self.conn.execute("INSERT INTO ingest_artifact VALUES (3, 'file_csv', '{}')")
        self.conn.execute("INSERT INTO qa_result VALUES (1, 'phase_d', 'qa_v2', 'reject')")
        self.conn.execute("INSERT INTO qa_result VALUES (2, 'phase_d', 'qa_v2', 'pass')")
        self.conn.execute("INSERT INTO qa_result VALUES (3, 'phase_d', 'qa_v2', 'reject')")
        self.conn.execute("INSERT INTO replay_queue VALUES (1, 'pending')")
        self.conn.execute("INSERT INTO replay_queue VALUES (3, 'pending')")
        self.conn.commit()

        result = execute_historical_phase_d_reprocess(self.lab_root, artifact_classes=['dat'])
        self.assertTrue(result.get('ok'))
        self.assertTrue(os.path.isfile(result.get('execution_report_path')))
        dat_rejects = self.conn.execute("SELECT COUNT(*) FROM qa_result WHERE artifact_id=1 AND status='reject'").fetchone()[0]
        dat_passes = self.conn.execute("SELECT COUNT(*) FROM qa_result WHERE artifact_id=2 AND status='pass'").fetchone()[0]
        csv_rejects = self.conn.execute("SELECT COUNT(*) FROM qa_result WHERE artifact_id=3 AND status='reject'").fetchone()[0]
        dat_replay_status = self.conn.execute("SELECT status FROM replay_queue WHERE artifact_id=1").fetchone()[0]
        csv_replay_status = self.conn.execute("SELECT status FROM replay_queue WHERE artifact_id=3").fetchone()[0]
        self.assertEqual(dat_rejects, 0)
        self.assertEqual(dat_passes, 1)
        self.assertEqual(csv_rejects, 1)
        self.assertEqual(dat_replay_status, 'abandoned')
        self.assertEqual(csv_replay_status, 'pending')


class TestPhaseDSummaryContract(unittest.TestCase):
    """Phase D summary JSON: fixed keys for lineage / zero-selection explanations."""

    def test_build_summary_zero_selection_reason_codes_always_list(self):
        from run_qa_canonical import _build_summary

        s = _build_summary(
            "rid-1",
            ok=True,
            rows_selected=3,
            qa_pass_count=1,
            qa_reject_count=0,
        )
        self.assertIsInstance(s.get("zero_selection_reason_codes"), list)
        self.assertEqual(s["zero_selection_reason_codes"], [])
        self.assertEqual(s.get("selection_scope"), "new_artifacts_current_qa_only")
        self.assertTrue(s.get("zero_selection_analysis_available"))

    def test_infra_failure_db_missing_skips_zero_selection_enrichment(self):
        """Missing DB must not emit no_unevaluated_* or other selection-truth codes."""
        lab_root = tempfile.mkdtemp()
        reports_dir = os.path.join(lab_root, "reports")
        os.makedirs(reports_dir, exist_ok=True)
        try:
            from run_qa_canonical import run_qa_canonical

            with patch("run_qa_canonical.acquire_lock"):
                with patch("run_qa_canonical.release_lock"):
                    ok, _rid, summary, _err = run_qa_canonical(lab_root)
            self.assertFalse(ok)
            self.assertEqual(summary.get("zero_selection_reason_codes"), [])
            self.assertFalse(summary.get("zero_selection_analysis_available"))
            self.assertNotIn("no_unevaluated_artifacts_current_qa", summary.get("zero_selection_reason_codes") or [])
        finally:
            try:
                import shutil
                shutil.rmtree(lab_root, ignore_errors=True)
            except Exception:
                pass

    def test_infra_failure_eligibility_query_skips_zero_selection_enrichment(self):
        """If eligibility discovery throws, do not stamp zero-selection reason codes."""
        lab_root, db_path, reports_dir = _make_lab_with_db()
        try:
            import run_qa_canonical as rqc

            with patch.object(rqc.sqlite3, "connect", side_effect=sqlite3.OperationalError("test")):
                with patch.object(rqc, "acquire_lock"):
                    with patch.object(rqc, "release_lock"):
                        ok, _rid, summary, _err = rqc.run_qa_canonical(lab_root)
            self.assertFalse(ok)
            self.assertEqual(summary.get("zero_selection_reason_codes"), [])
            self.assertFalse(summary.get("zero_selection_analysis_available"))
        finally:
            try:
                import shutil
                shutil.rmtree(lab_root, ignore_errors=True)
            except Exception:
                pass


if __name__ == "__main__":
    unittest.main()
