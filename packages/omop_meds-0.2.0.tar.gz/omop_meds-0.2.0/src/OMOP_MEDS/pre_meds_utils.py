import logging
from collections.abc import Callable, Iterable, Iterator
from pathlib import Path
from typing import Any

import polars as pl
import polars.selectors as cs
import pyarrow.parquet as pq
from MEDS_transforms.utils import write_lazyframe
from polars import Boolean
from polars.type_aliases import SelectorType
from typing import Optional
from loguru import logger
from omop_schema.convert import convert_to_schema_polars
from omop_schema.schema.base import OMOPSchemaBase
from omop_schema.utils import pyarrow_to_polars_schema
import math

from . import dataset_info, premeds_cfg

DATASET_NAME = dataset_info.dataset_name
ADMISSION_ID = premeds_cfg.admission_id
SUBJECT_ID = premeds_cfg.subject_id
OMOP_TIME_FORMATS: Iterable[str] = ("%Y-%m-%d %H:%M:%S%.f", "%Y-%m-%d")


def get_table_path(input_dir: Path, table_name: str) -> Path | None:
    table_path = input_dir / table_name
    if table_path.exists():
        return table_path
    table_path_with_ext = list(input_dir.glob(f"{table_name}.*"))
    if table_path_with_ext:
        return table_path_with_ext[0]
    return None


def parse_time(time: pl.Expr, time_formats: Iterable[str]) -> pl.Expr:
    return pl.coalesce(
        [
            time.str.to_datetime(time_format, strict=False, time_unit="us")
            for time_format in time_formats
        ]
    )


def cast_to_datetime(schema: Any, column: str, move_to_end_of_day: bool = False):
    if schema[column] == pl.Utf8():
        if not move_to_end_of_day:
            return parse_time(pl.col(column), OMOP_TIME_FORMATS)
        else:
            # Try to cast time to a datetime but if only the date is available, then use
            # that date with a timestamp of 23:59:59
            time = pl.col(column)
            time = pl.coalesce(
                time.str.to_datetime(
                    "%Y-%m-%d %H:%M:%S%.f", strict=False, time_unit="us"
                ),
                time.str.to_datetime("%Y-%m-%d", strict=False, time_unit="us")
                .dt.offset_by("1d")
                .dt.offset_by("-1s"),
            )
            return time
    elif schema[column] == pl.Date():
        time = pl.col(column).cast(pl.Datetime(time_unit="us"))
        if move_to_end_of_day:
            time = time.dt.offset_by("1d").dt.offset_by("-1s")
        return time
    elif isinstance(schema[column], pl.Datetime):
        return pl.col(column).cast(pl.Datetime(time_unit="us"))
    else:
        return pl.col(column)
        # raise RuntimeError("Unknown how to handle date type? " + schema[column] + " " + column)


def get_patient_link(
    person_df: pl.LazyFrame,
    death_df: pl.LazyFrame,
    visit_df: pl.LazyFrame,
    schema_loader: OMOPSchemaBase,
    limit: int = 0,
    join_on_visit: bool = True,
) -> pl.LazyFrame:
    """
    Process the persons table and death table to get an accurate birth and death datetime.
    Will produce a table of the subjects that will be included in the MEDS cohort.

    The output of this process is ultimately converted to events via the `patient` key in the
    `configs/event_configs.yaml` file.
        Args:
        person_df: A Polars LazyFrame containing person data.
        death_df: A Polars LazyFrame containing death data.
        visit_df: A Polars LazyFrame containing visit data.
        schema_loader: An instance of OMOPSchemaBase to load the schema.
        limit: An optional limit on the number of rows to process.
        join_on_visit: Whether to join the visit table with the person table or not.

    Returns:
        A Polars LazyFrame with the processed patient data, including date of birth and date of death.

    Examples:
    >>> import polars as pl
    >>> from datetime import datetime
    >>> from omop_schema.utils import get_schema_loader
    >>> person_data = {
    ...     "person_id": [1, 2],
    ...     "year_of_birth": [1980, 1990],
    ...     "month_of_birth": [1, 2],
    ...     "day_of_birth": [1, 2],
    ...     "birth_datetime": [None, None]
    ... }
    >>> death_data = {
    ...     "person_id": [1],
    ...     "death_datetime": ["2020-01-01 00:00:00"]
    ... }
    >>> person_df = pl.DataFrame(person_data).lazy()
    >>> death_df = pl.DataFrame(death_data).lazy()
    >>> visit_df = pl.DataFrame({"person_id": [1, 2]}).lazy()
    >>> schema_loader = get_schema_loader(5.3)
    >>> result = get_patient_link(person_df, death_df, visit_df, schema_loader)
    >>> result_dict = result.collect().to_dict(as_series=False)  # Convert to plain Python dict
    """
    if join_on_visit:
        # Keep only the persons that are in the visit table
        person_df = person_df.join(
            visit_df.select(SUBJECT_ID), on=SUBJECT_ID, how="semi"
        )
    else:
        person_df_ids = person_df.join(
            visit_df.select(SUBJECT_ID), on=SUBJECT_ID, how="anti"
        )
        logger.warning(
            f"We will not require a visit per patient."
            f"Found {person_df_ids.count().collect()[0, 0]} persons without visits."
        )
    if limit > 0:
        # Limit the number of persons
        logger.info(f"Limiting the number of persons to {limit}")
        person_df = person_df.limit(limit)
    date_parsing = pl.datetime(
        pl.col("year_of_birth").replace(0, 1800).fill_null(1900),
        pl.col("month_of_birth").replace(0, 1).fill_null(1),
        pl.col("day_of_birth").replace(0, 1).fill_null(1),
        time_unit="us",
    )
    person_schema = person_df.collect_schema()
    if "birth_datetime" in person_schema:
        date_of_birth = (
            pl.when(pl.col("birth_datetime").is_not_null())
            .then(cast_to_datetime(person_df.collect_schema(), "birth_datetime"))
            .otherwise(date_parsing)
        )
    else:
        date_of_birth = date_parsing

    if death_df is None:
        death_schema = pyarrow_to_polars_schema(
            schema_loader.get_pyarrow_schema("death")
        )
        death_df = (
            pl.DataFrame(
                data=[],
                schema=death_schema,
            )
        ).lazy()
    date_of_death = pl.when(pl.col("death_datetime").is_not_null()).then(
        cast_to_datetime(death_df.collect_schema(), "death_datetime")
    )

    return (
        person_df.sort(by=date_of_birth)
        # .with_columns(pl.col(SUBJECT_ID))
        .group_by(SUBJECT_ID)
        .first()
        .join(death_df, on=SUBJECT_ID, how="left")  # Use renamed column
        .select(
            pl.col(SUBJECT_ID),
            date_of_birth.alias("date_of_birth"),
            # admission_time.alias("first_admitted_at_time"),
            date_of_death.alias("date_of_death"),
        )
        .with_columns(table_name=pl.lit("person"))
        .collect()
        .lazy()
    )  # We get parquet sink error if we don't collect here


def join_concept(
    table_name: str,
    reference_cols: str | list[str] | None = None,
    output_data_cols: list[str] | None = None,
    concept_cols: list[str] | None = None,
    prefer_source: bool = False,
) -> Callable[[pl.LazyFrame, pl.LazyFrame], pl.LazyFrame]:
    """Returns a function that joins a dataframe to the `patient` table and adds pseudotimes.
    Also raises specified warning strings via the logger for uncertain columns.
    All args except `table_name` are taken from the table_preprocessors.yaml.
    Args:
        table_name: name of the table that should be joined
        output_data_cols: list of all data columns included in the output
        reference_cols: list of all columns that link to the concept_id
        concept_cols: list of all columns that are included in the concept table and
        should be added to the output
        prefer_source: If True, prefer the source concept over the mapped concept.
    Returns:
        Function that expects the raw data stored in the `table_name` table and the joined output of the
        `process_patient_and_admissions` function. Both inputs are expected to be `pl.DataFrame`s.

    Examples:
        >>> from omop_schema.utils import get_schema_loader
        >>> from OMOP_MEDS.pre_meds_utils import load_raw_file, join_concept, get_patient_link
        >>> func = join_concept(
        ...     "observation",
        ...     ["observation_source_concept_id"],  # Add a comma here
        ...     ["observation_datetime", "observation_type_concept_id", "value_as_number", "value_as_string",
        ...     "value_as_concept_id", "qualifier_concept_id", "unit_concept_id", "visit_occurrence_id",
        ...      "visit_detail_id", "observation_source_value", "observation_source_concept_id"],
        ...     ["vocabulary_id", "concept_code"],
        ...     prefer_source=False,
        ...
        ... )
        >>> schema_loader = get_schema_loader(5.3)
        >>> observation_df = load_raw_file(Path("tests/demo_resources/observation.csv"), schema_loader)
        >>> person_df = load_raw_file(Path("tests/demo_resources/person.csv"), schema_loader)
        >>> death_df = load_raw_file(Path("tests/demo_resources/death.csv"), schema_loader)
        >>> concept_df = load_raw_file(Path("tests/demo_resources/concept.csv"), schema_loader)
        >>> visit_df = load_raw_file(Path("tests/demo_resources/visit_occurrence.csv"), schema_loader)
        >>> patient_link = get_patient_link(person_df, death_df, visit_df, schema_loader)
        >>> processed_df = func(observation_df, concept_df, patient_link)
    """

    if output_data_cols is None:
        output_data_cols = []

    if reference_cols is None:
        reference_cols = []

    if concept_cols is None:
        concept_cols = []

    if isinstance(reference_cols, str):
        reference_cols = [reference_cols]

    base_output_cols = list(output_data_cols)
    base_concept_cols = list(concept_cols)

    def fn(
        df: pl.LazyFrame, concept_df: pl.LazyFrame, person_df: pl.LazyFrame
    ) -> pl.LazyFrame:
        f"""Takes the {table_name} table and converts it to a form that includes the original concepts.

        The output of this process is ultimately converted to events via the `{table_name}` key in the
        `configs/event_configs.yaml` file.

        Args:
            df: The raw {table_name} data.
            concept_df: The concepts to join.
            person_df: The patient data to keep.

        Returns:
            The processed {table_name} data.
        """
        # logger.info(df.collect_schema())
        # # Join the patient table to the data table, INSPIRE only has subject_id as key
        # joined = df.join(patient_df.lazy(), on=ADMISSION_ID, how="inner")
        # collected = df.collect()
        df = df.with_columns(pl.col(SUBJECT_ID).cast(pl.Int64))
        # df = df.with_columns("preferred_concept_name", pl.lit(None))
        # df = df.with_columns("preferred_vocabulary_name", pl.lit(None))
        # Keep only the persons that are in the patient table
        df = df.join(person_df, on=SUBJECT_ID, how="semi")
        if len(reference_cols) > 0:
            df = df.with_columns(pl.col(reference_cols).cast(pl.Int64).replace(0, None))
            if len(reference_cols) == 1:
                df = df.join(
                    concept_df,
                    left_on=reference_cols,
                    right_on="concept_id",
                    how="left",
                )
                df = df.with_columns(
                    pl.col(reference_cols).alias("preferred_concept_name"),
                    pl.col("vocabulary_id").alias("preferred_vocabulary_name"),
                )
            else:
                clean_item = ""
                for item in reference_cols:
                    table_names = table_name.split("_")
                    clean_item = item
                    for part in table_names:
                        clean_item = clean_item.replace(part, "")
                    clean_item = clean_item.lstrip("_")
                    # Remove the table name prefix
                    df = df.join(
                        concept_df,
                        left_on=item,
                        right_on="concept_id",
                        how="left",
                        suffix=f"_{clean_item}",
                    )
                # Determine the concept id for the codes
                df = determine_concept_id(
                    df,
                    original_concept_id_cols=reference_cols,
                    mapped_concept_col="concept_code",
                    mapped_vocab_col="vocabulary_id",
                    source_concept_col=f"concept_code_{clean_item}",
                    source_vocab_col=f"vocabulary_id_{clean_item}",
                    prefer_source=prefer_source,
                )
        # df_collected = df.collect()
        selected_cols = [*base_output_cols, *base_concept_cols]
        schema_names = set(df.collect_schema().names())

        # Keep order stable while preventing duplicate projection names.
        to_select: list[str] = []
        seen: set[str] = set()
        for col in selected_cols:
            if col in schema_names and col not in seen:
                to_select.append(col)
                seen.add(col)
        to_select.append(SUBJECT_ID)
        if "preferred_concept_name" in schema_names:
            to_select.extend(["preferred_concept_name", "preferred_vocabulary_name"])
            df = df.with_columns(
                pl.col("preferred_vocabulary_name").replace(None, f"OMOP_{table_name}")
            )
        return df.select(to_select)

    return fn


def col_selector(
    columns: Optional[list[str]] = None,
    patterns: Optional[list[str]] = None,
) -> SelectorType:
    """
    Returns a selector for explicit column names, a regex pattern, or both.
    Raises if neither is provided.
    """
    if not columns and not patterns:
        raise ValueError("Provide at least one of: columns, pattern")

    selector = None

    if columns:
        selector = cs.by_name(*columns)
    if patterns:
        if isinstance(patterns, str):
            patterns = [patterns]  # Ensure patterns is a list
        for pattern in patterns:
            regex_sel = cs.matches(pattern)
            selector = regex_sel if selector is None else selector | regex_sel

    return selector


def load_raw_file(
    fp: Path, schema_loader: OMOPSchemaBase, selector: SelectorType = cs.all()
) -> pl.LazyFrame | None:
    """Retrieve all .csv/.csv.gz/.parquet files for the OMOP table given by fp

    Because OMOP tables can be quite large for datasets comprising millions
    of subjects, those tables are often split into compressed shards. So
    the `measurements` "table" might actually be a folder containing files
    `000000000000.csv.gz` up to `000000000152.csv.gz`. This function
    takes a path corresponding to an OMOP table with its standard name (e.g.,
    `condition_occurrence`, `measurement`, `observation`) and returns two list
    of paths.

    The first list contains all the csv files. The second list contains all parquet files.

    Examples:
        >>> from pathlib import Path
        >>> import polars as pl
        >>> from omop_schema.utils import get_schema_loader
        >>> schema_loader = get_schema_loader(5.3)
        >>> fp = Path("tests/demo_resources/observation.csv")
        >>> df = load_raw_file(fp, schema_loader)
    """
    # TODO: Write tool/method that reads a specific omop table with a specific datatypes
    table_name = fp.stem.split(".")[0]  # Infer table name from file path
    schema = pyarrow_to_polars_schema(schema_loader.get_pyarrow_schema(table_name))

    # pa.schema([(col, dtype) for coll, dtype in schema.items()])
    # Convert dict to pa.Schema
    if fp.suffixes == [".csv", ".gz"]:
        file = pl.scan_csv(
            fp, compression="gzip", infer_schema=False, schema_overrides=schema
        ).select(selector)
        logging.info(f"Loaded gzipped CSV file from {fp}")
    elif fp.suffix == ".csv":
        # Using schema_overrides to set the schema as the ordering could be different
        # and there could be extra columns
        file = pl.scan_csv(
            fp, infer_schema=False, has_header=True, schema_overrides=schema
        ).select(selector)
        logging.info(f"Loaded CSV file from {fp}")
    elif fp.suffix == ".parquet":
        file = pl.scan_parquet(fp).select(selector)
        file = convert_to_schema_polars(file, schema, allow_extra_columns=True)
        logging.info(f"Loaded Parquet file from {fp}")
    elif fp.is_dir():
        files = list(fp.glob("**/*"))
        csv_files = [file for file in files if file.suffix in [".csv", ".gz"]]
        parquet_files = [file for file in files if file.suffix == ".parquet"]
        # mismatching_schema_check = True
        if csv_files:
            file = pl.scan_csv(
                fp, infer_schema=False, has_header=True, schema_overrides=schema
            ).select(selector)
            logging.info(f"Loaded CSV files as directory from {fp}")
        elif parquet_files:
            # Memory-safe schema harmonization across shards
            # file = scan_harmonized(fp, glob="**/*.parquet")
            # # Keep only requested columns and cast to OMOP schema permissively
            # file = file.select(selector)
            # file = convert_to_schema_polars(
            #     file, schema, allow_extra_columns=True, allow_missing_columns=True
            # )
            # Per-shard projection/cast to avoid building one huge harmonized concat plan.
            # shard_lfs: list[pl.LazyFrame] = []
            # for shard_fp in sorted(parquet_files):
            #     shard_lf = pl.scan_parquet(shard_fp).select(selector)
            #     shard_lf = project_to_target_schema(shard_lf, schema)
            #     shard_lfs.append(shard_lf)
            #
            # if not shard_lfs:
            #     return None
            # Safer for very large dirs: build aligned shards in bounded batches.
            # This avoids one giant concat graph that can OOM/panic native Polars.
            parquet_files = sorted(parquet_files)
            batch_size = 64  # tune 32-128 based on memory
            batch_lfs: list[pl.LazyFrame] = []

            # Restrict schema to selected columns to lower memory.
            # selector may be a callable selector; this path keeps full schema if unsure.
            target_schema = schema

            for i in range(0, len(parquet_files), batch_size):
                chunk = parquet_files[i : i + batch_size]
                shard_lfs: list[pl.LazyFrame] = []

                for shard_fp in chunk:
                    shard = pl.scan_parquet(shard_fp, rechunk=False).select(selector)
                    shard = _align_shard_to_schema(shard, target_schema)
                    shard_lfs.append(shard)

                if shard_lfs:
                    batch_lfs.append(pl.concat(shard_lfs, how="vertical_relaxed"))

            if not batch_lfs:
                return None
            # vertical_relaxed allows minor dtype reconciliation without exploding memory.
            file = pl.concat(batch_lfs, how="vertical_relaxed")
            logging.info(
                f"Loaded Parquet files as directory from {fp} of {len(parquet_files)} shards"
            )

            # # pl.scan_parquet(fp)
            # file = pl.scan_parquet(fp).select(
            #     selector
            # )  # , schema=schema, allow_missing_columns=True)
            # # if mismatching_schema_check:
            # #     cast_files_to_schema(str(fp), schema, str(fp))
            # file = convert_to_schema_polars(file, schema, allow_extra_columns=False)
            # logging.info(f"Loaded Parquet files as directory from {fp}")
        else:
            return None
    else:
        return None
    file = file.select(pl.all().name.to_lowercase())
    # logging.info(f"Loaded {file} with schema: {file.collect_columns}")
    return file


class ShardedTableDataLoader:
    """Load OMOP tables with optional shard-wise batching for selected tables.

    For non-selected tables this class defers to ``load_raw_file`` to preserve
    existing behavior. For selected parquet directory tables, it can yield data
    in bounded batches to lower peak memory.
    """

    def __init__(
        self,
        schema_loader: OMOPSchemaBase,
        selector: SelectorType = cs.all(),
        chunked_tables: list[str] | None = None,
        batching_row_threshold: int = 1_000_000,
        batch_mode: str = "auto",
        batch_size_shards: int = 1,
        batch_input_rows: int = 0,
    ) -> None:
        """
        Initializes the ShardedTableDataLoader.

        Args:
            schema_loader (OMOPSchemaBase): The schema loader instance to retrieve table schemas.
            selector (SelectorType, optional): A column selector to filter columns during loading. Defaults to `cs.all()`.
            chunked_tables (list[str] | None, optional): A list of table names that are eligible to be processed in chunks. Defaults to None.
            batching_row_threshold (int, optional): The row count threshold for enabling batching. Defaults to 1,000,000.
            batch_mode (str, optional): The batching mode. Can be "auto", "per_shard", "by_shards", or "by_rows". Defaults to "auto".
            batch_size_shards (int, optional): The number of shards to include in each batch when using "by_shards" mode. Defaults to 1.
            batch_input_rows (int, optional): The maximum number of rows per batch when using "by_rows" mode. Defaults to 0 (disabled).

        Returns:
            None
        """
        self.schema_loader = schema_loader
        self.selector = selector
        self.chunked_tables = set(chunked_tables or [])
        self.batching_row_threshold = batching_row_threshold
        self.batch_mode = batch_mode
        self.batch_size_shards = max(1, int(batch_size_shards))
        self.batch_input_rows = max(0, int(batch_input_rows))

    def load_table(self, fp: Path) -> pl.LazyFrame | None:
        """Load a table with existing non-batched semantics."""
        return load_raw_file(fp, self.schema_loader, self.selector)

    def should_batch(self, table_name: str, fp: Path) -> bool:
        """Return whether batching should be used for this table/path."""
        if table_name not in self.chunked_tables:
            return False

        estimated_rows = self.estimate_rows(fp)
        if estimated_rows is None:
            return False

        if self.batching_row_threshold <= 0:
            return True
        return estimated_rows > self.batching_row_threshold

    def iter_table_batches(self, table_name: str, fp: Path) -> Iterator[pl.LazyFrame]:
        """Yield one or more LazyFrame batches for a table.

        If batching is not enabled (or not applicable), yields exactly one frame.
        """
        if not self.should_batch(table_name, fp):
            lf = self.load_table(fp)
            if lf is not None:
                yield lf
            return

        parquet_files = self._list_parquet_files(fp)
        if not parquet_files:
            lf = self.load_table(fp)
            if lf is not None:
                yield lf
            return

        for batch_files in self._build_batches(parquet_files):
            yield self._scan_parquet_batch(batch_files, table_name)

    def estimate_rows(self, fp: Path) -> int | None:
        """Estimate total row count using parquet metadata only."""
        parquet_files = self._list_parquet_files(fp)
        if not parquet_files:
            return None

        total = 0
        for path in parquet_files:
            try:
                total += pq.ParquetFile(path).metadata.num_rows
            except Exception:
                return None
        return total

    def estimate_batches(self, fp: Path) -> int | None:
        """Estimate total batch count using parquet metadata only."""
        parquet_files = self._list_parquet_files(fp)
        if not parquet_files:
            return None

        mode = self._effective_batch_mode()

        if mode == "per_shard":
            return len(parquet_files)

        if mode == "by_shards":
            step = max(1, self.batch_size_shards)
            return math.ceil(len(parquet_files) / step)

        if mode == "by_rows":
            if self.batch_input_rows <= 0:
                return len(parquet_files)

            batches = 0
            current_rows = 0
            for path in parquet_files:
                try:
                    shard_rows = pq.ParquetFile(path).metadata.num_rows
                except Exception:
                    shard_rows = 0

                if current_rows > 0 and current_rows >= self.batch_input_rows:
                    batches += 1
                    current_rows = 0

                current_rows += shard_rows

            if current_rows > 0:
                batches += 1
            return batches

        return len(parquet_files)

    def _list_parquet_files(self, fp: Path) -> list[Path]:
        if fp.is_file() and fp.suffix == ".parquet":
            return [fp]
        if fp.is_dir():
            return sorted(p for p in fp.glob("**/*.parquet") if p.is_file())
        return []

    def _effective_batch_mode(self) -> str:
        if self.batch_mode == "auto":
            if self.batch_input_rows > 0:
                return "by_rows"
            if self.batch_size_shards > 1:
                return "by_shards"
            return "per_shard"
        return self.batch_mode

    def _build_batches(self, parquet_files: list[Path]) -> list[list[Path]]:
        mode = self._effective_batch_mode()

        if mode == "per_shard":
            return [[p] for p in parquet_files]

        if mode == "by_shards":
            step = self.batch_size_shards
            return [
                parquet_files[i : i + step] for i in range(0, len(parquet_files), step)
            ]

        if mode == "by_rows":
            if self.batch_input_rows <= 0:
                return [[p] for p in parquet_files]

            batches: list[list[Path]] = []
            current: list[Path] = []
            current_rows = 0
            for path in parquet_files:
                try:
                    shard_rows = pq.ParquetFile(path).metadata.num_rows
                except Exception:
                    shard_rows = 0

                if current and current_rows >= self.batch_input_rows:
                    batches.append(current)
                    current = []
                    current_rows = 0

                current.append(path)
                current_rows += shard_rows

            if current:
                batches.append(current)
            return batches

        return [[p] for p in parquet_files]

    def _scan_parquet_batch(
        self, parquet_paths: list[Path], table_name: str
    ) -> pl.LazyFrame:
        schema = pyarrow_to_polars_schema(
            self.schema_loader.get_pyarrow_schema(table_name)
        )
        shard_lfs: list[pl.LazyFrame] = []
        for shard_fp in parquet_paths:
            shard = pl.scan_parquet(shard_fp, rechunk=False)
            shard = _align_shard_to_schema(shard, schema)
            shard = shard.select(self.selector)
            shard_lfs.append(shard)

        if len(shard_lfs) == 1:
            file = shard_lfs[0]
        else:
            file = pl.concat(shard_lfs, how="vertical_relaxed")
        return file.select(pl.all().name.to_lowercase())


def cast_files_to_schema(folder_path: str, target_schema: dict, output_folder: str):
    """
    Casts all files in a folder to the target schema using convert_to_schema_polars.
    Used when the schema of the files in the folder is inconsistent.

    Args:
        folder_path (str): Path to the folder containing the files.
        target_schema (dict): The target schema (column name -> data type).
        output_folder (str): Path to the folder where processed files will be saved.

    Returns:
        None
    """
    folder = Path(folder_path)
    output_dir = Path(output_folder)
    output_dir.mkdir(parents=True, exist_ok=True)

    # Check for column mismatches
    mismatched_columns = check_column_mismatches(folder_path)

    if mismatched_columns:
        print(f"Found mismatched columns: {mismatched_columns}")

    # Process each file in the folder
    for file in folder.glob("*.parquet"):
        print(f"Processing file: {file}")
        df = pl.scan_parquet(file)

        # Align the file's schema with the target schema
        df = convert_to_schema_polars(
            dataset=df.lazy(),
            target_schema=target_schema,
            allow_extra_columns=False,
            allow_missing_columns=True,
            add_missing_columns=True,
        ).collect()

        # Save the processed file to the output folder
        output_file = output_dir / file.name
        df.write_parquet(output_file)
        print(f"File saved to: {output_file}")


def check_column_mismatches(folder_path: str):
    """
    Check for column mismatches (e.g., datatype inconsistencies) across all Parquet files in a folder.

    Parameters:
    folder_path (str): The path to the folder containing Parquet files.

    Returns:
    dict: A dictionary where keys are column names and values are lists of inconsistent datatypes.
    """
    column_types = {}

    # Iterate through all Parquet files in the folder
    for file in Path(folder_path).glob("*.parquet"):
        print(f"Checking file: {file}")
        # Read the schema of the Parquet file
        df = pl.read_parquet(file)
        schema = df.schema

        # Compare the schema with the accumulated column types
        for col, dtype in schema.items():
            if col not in column_types:
                column_types[col] = set()
            column_types[col].add(dtype)

    # Identify mismatched columns
    mismatched_columns = {
        col: list(dtypes) for col, dtypes in column_types.items() if len(dtypes) > 1
    }

    if mismatched_columns:
        print("Mismatched columns found:")
        for col, dtypes in mismatched_columns.items():
            print(f"  Column: {col}, Datatypes: {dtypes}")
    else:
        print("No mismatched columns found. All schemas are consistent.")

    return mismatched_columns


def extract_metadata(
    concept_df: pl.LazyFrame, concept_relationship_df: pl.LazyFrame
) -> pl.LazyFrame:
    # concept_id_map: Dict[int, str] = {}  # [key] concept_id -> [value] concept_code
    # concept_name_map: Dict[int, str] = {}  # [key] concept_id -> [value] concept_name
    # code_metadata: Dict[str, Any] = {}  # [key] concept_code -> [value] metadata

    # Read in the OMOP `CONCEPT` table from disk
    # (see https://ohdsi.github.io/TheBookOfOhdsi/StandardizedVocabularies.html#concepts)
    # and use it to generate metadata file as well as populate maps
    # from (concept ID -> concept code) and (concept ID -> concept name)
    # for concept_file in tqdm(itertools.chain(*get_table_files(path_to_src_omop_dir, "concept")),
    #                          total=len(get_table_files(path_to_src_omop_dir, "concept")[0]) +
    #                          len(get_table_files(path_to_src_omop_dir, "concept")[1]),
    #                          desc="Generating metadata from OMOP `concept` table"):
    #     # Note: Concept table is often split into gzipped shards by default
    #     if verbose:
    #         print(concept_file)
    #     with load_file(path_to_decompressed_dir, concept_file) as f:
    # Read the contents of the `concept` table shard
    # `load_file` will unzip the file into `path_to_decompressed_dir` if needed
    logger.info(
        "Generating codes metadata from OMOP `concept` table and `concept_relationship` table"
    )
    concept = concept_df
    concept_id = pl.col("concept_id").cast(pl.Int64)
    # code = pl.col("vocabulary_id") + "//" + pl.col("concept_code")
    logger.info(concept.collect_schema())
    # Convert the table into a dictionary
    result = concept.select(
        concept_id=concept_id,
        vocabulary_id=pl.col("vocabulary_id"),
        description=pl.col("concept_name"),
    )
    concept_relationship_df = concept_relationship_df.with_columns(
        pl.col("concept_id_1").cast(pl.Int64), pl.col("concept_id_2").cast(pl.Int64)
    )

    # Take the parents of the concepts
    parent_codes = concept_relationship_df.filter(
        pl.col("relationship_id") == "Maps to"
    )
    parent_codes = parent_codes.join(
        concept_df, left_on="concept_id_2", right_on="concept_id", how="left"
    )
    parent_codes = parent_codes.with_columns(
        parent_codes=pl.col("vocabulary_id") + "//" + pl.col("concept_code")
    )
    parent_codes = parent_codes.with_columns(
        parent_codes=pl.col("parent_codes").cast(pl.List(pl.String))
    )
    result = result.join(
        parent_codes, left_on="concept_id", right_on="concept_id_1", how="left"
    )
    # code_metadata = result
    code_metadata = result.with_columns(
        code=pl.col("vocabulary_id").cast(pl.Utf8)
        + "//"
        + pl.col("concept_id").cast(pl.Utf8)
    )
    code_metadata = code_metadata.select(
        "code", "vocabulary_id", "concept_id", "description", "parent_codes"
    )

    # code_metadata = code_metadata.with_columns(pl.col("name").alias("description"))
    # result = result.to_dict(as_series=False)

    # Update our running dictionary with the concepts we read in from
    # the concept table shard
    # concept_id_map |= dict(zip(result["concept_id"], result["code"]))
    # concept_name_map |= dict(zip(result["concept_id"], result["name"]))

    # Assuming custom concepts have concept_id > 2000000000 we create a
    # record for them in `code_metadata` with no parent codes. Such a
    # custom code could be eg `STANFORD_RACE/Black or African American`
    # with `concept_id` 2000039197
    # custom_concepts = (
    #     concept.filter(concept_id > CUSTOMER_CONCEPT_ID_START)
    #     .select(concept_id=concept_id, code=code, description=pl.col("concept_name"))
    #     .to_dict()
    # )
    # for i in range(len(custom_concepts["code"])):
    #     code_metadata[custom_concepts["code"][i]] = {
    #         "code": custom_concepts["code"][i],
    #         "description": custom_concepts["description"][i],
    #         "parent_codes": [],
    #     }

    # Include map from custom concepts to normalized (ie standard ontology)
    # parent concepts, where possible, in the code_metadata dictionary
    # for concept_relationship_file in tqdm(itertools.chain(
    # *get_table_files(path_to_src_omop_dir, "concept_relationship")),
    #   total=len(get_table_files(path_to_src_omop_dir, "concept_relationship")[0]) +
    #   len(get_table_files(path_to_src_omop_dir, "concept_relationship")[1]),
    #   desc="Generating metadata from OMOP `concept_relationship` table"):
    #     with load_file(path_to_decompressed_dir, concept_relationship_file) as f:
    # This table has `concept_id_1`, `concept_id_2`, `relationship_id` columns

    # custom_relationships = (
    #     concept_relationship.filter(
    #         concept_id_1 > CUSTOMER_CONCEPT_ID_START,
    #         pl.col("relationship_id") == "Maps to",
    #         concept_id_1 != concept_id_2,
    #     )
    #     .select(concept_id_1=concept_id_1, concept_id_2=concept_id_2)
    #     .to_dict(as_series=False)
    # )

    # for concept_id_1, concept_id_2 in zip(
    #     custom_relationships["concept_id_1"], custom_relationships["concept_id_2"]
    # ):
    #     if concept_id_1 in concept_id_map and concept_id_2 in concept_id_map:
    #         code_metadata[concept_id_map[concept_id_1]]["parent_codes"].append(concept_id_map[concept_id_2])
    return code_metadata  # concept_id_map, concept_name_map


def determine_concept_id(
    df: pl.LazyFrame,
    original_concept_id_cols: list[str],
    mapped_concept_col: str,
    mapped_vocab_col: str,
    source_concept_col: str,
    source_vocab_col: str,
    prefer_source: bool = False,
) -> pl.LazyFrame:
    """
    Determines the concept ID and vocabulary ID for a given DataFrame by prioritizing
    either the source or mapped concept columns based on the `prefer_source` flag.

    Args:
        df (pl.LazyFrame): The input DataFrame containing concept-related columns.
        original_concept_id_cols (list[str]): List of original concept ID columns to consider.
        mapped_concept_col (str): Column name for the mapped concept ID.
        mapped_vocab_col (str): Column name for the mapped vocabulary ID.
        source_concept_col (str): Column name for the source concept ID.
        source_vocab_col (str): Column name for the source vocabulary ID.
        prefer_source (bool, optional): If `True`, prioritizes the source concept and vocabulary
            columns over the mapped ones. Defaults to `False`.

    Returns:
        pl.LazyFrame: A new DataFrame with the determined concept ID and vocabulary ID
        added as `preferred_concept_name` and `preferred_vocabulary_name` columns.

    Example:
        >>> df = pl.LazyFrame({"mapped_concept_col": [1, None], "source_concept_col": [None, 2]})
        >>> result = determine_concept_id(
        ...     df,
        ...     original_concept_id_cols=["original_col"],
        ...     mapped_concept_col="mapped_concept_col",
        ...     mapped_vocab_col="mapped_vocab_col",
        ...     source_concept_col="source_concept_col",
        ...     source_vocab_col="source_vocab_col",
        ...     prefer_source=True
        ... )
    """
    if prefer_source:
        vocab_id = (
            pl.when(
                pl.col(source_concept_col).is_not_null()
                & pl.col(source_vocab_col).is_not_null()
            )
            .then(pl.col(source_vocab_col))
            .otherwise(
                pl.when(
                    pl.col(mapped_concept_col).is_not_null()
                    & pl.col(mapped_vocab_col).is_not_null()
                )
                .then(pl.col(mapped_vocab_col))
                .otherwise(
                    pl.lit(None)
                )  # Default to None if no valid vocab_id is found
            )
        )

        concept_id = (
            pl.when(pl.col(source_concept_col).is_not_null())
            .then(pl.col(source_concept_col))
            .otherwise(
                pl.when(pl.col(mapped_concept_col).is_not_null())
                .then(pl.col(mapped_concept_col))
                .otherwise(
                    pl.when(pl.col(original_concept_id_cols[0]).is_not_null())
                    .then(
                        original_concept_id_cols[0]
                        + ":"
                        + pl.concat_str(original_concept_id_cols[0], separator=",")
                    )
                    .otherwise(
                        pl.lit(None)
                    )  # Default to None if no valid concept_id is found
                )
            )
        )
    else:
        vocab_id = (
            pl.when(
                pl.col(mapped_vocab_col).is_not_null()
                & pl.col(mapped_concept_col).is_not_null()
            )
            .then(pl.col(mapped_vocab_col))
            .otherwise(
                pl.when(
                    pl.col(source_vocab_col).is_not_null()
                    & pl.col(source_concept_col).is_not_null()
                )
                .then(pl.col(source_vocab_col))
                .otherwise(
                    pl.lit(None)
                )  # Default to None if no valid vocab_id is found
            )
        )

        concept_id = (
            pl.when(pl.col(mapped_concept_col).is_not_null())
            .then(pl.col(mapped_concept_col))
            .otherwise(
                pl.when(pl.col(source_concept_col).is_not_null())
                .then(pl.col(source_concept_col))
                .otherwise(
                    pl.when(pl.col(original_concept_id_cols[0]).is_not_null())
                    .then(
                        pl.concat_str(
                            [
                                original_concept_id_cols[0]
                                + ":"
                                + pl.concat_str(original_concept_id_cols, separator=",")
                            ]
                        )
                    )
                    # .then("".join([f"{col} = {pl.col(col)}" for col in original_concept_id_cols]))
                    # .then(pl.when(len(list(original_concept_id_cols))> 1 &
                    # pl.col(original_concept_id_cols[1])
                    # .is_not_null())
                    #     .then(original_concept_id_cols[0] +":" +
                    #           pl.concat_str(original_concept_id_cols, separator=f",
                    #           {original_concept_id_cols[1]}"))
                    #     .otherwise(original_concept_id_cols[0] + pl.concat_str(original_concept_id_cols,
                    #     separator=",")))
                    .otherwise(
                        pl.lit(None)
                    )  # Default to None if no valid concept_id is found
                )
            )
        )
    df = df.with_columns(
        concept_id.alias("preferred_concept_name"),
        vocab_id.alias("preferred_vocabulary_name"),
    )
    return df


def rename_demo_files(directory: Path):
    """Rename files in the directory by removing the '2b_' prefix in the MIMIC-OMOP demo."""
    for file_path in directory.glob("2b_*"):
        new_name = file_path.name.replace("2b_", "")
        new_path = file_path.with_name(new_name)
        file_path.rename(new_path)
        logger.info(f"Renamed: {file_path} to {new_path}")


# ── Type resolution ────────────────────────────────────────────────────────────


def _resolve_conflict(dtypes: set[pl.DataType]) -> pl.DataType:
    """Given a set of conflicting types for the same column, pick a safe common type."""
    if len(dtypes) == 1:
        return next(iter(dtypes))

    # Decimal[p1,s] vs Decimal[p2,s] → Float64 (covers your exact error)
    if any(d.is_decimal() for d in dtypes):
        return pl.Float64

    # Mixed int widths → widest signed int, or Float64 if floats involved
    if all(d.is_numeric() for d in dtypes):
        if any(d.is_float() for d in dtypes):
            return pl.Float64
        # All integers: pick widest
        int_widths = {
            pl.Int8: 8,
            pl.Int16: 16,
            pl.Int32: 32,
            pl.Int64: 64,
            pl.UInt8: 8,
            pl.UInt16: 16,
            pl.UInt32: 32,
            pl.UInt64: 64,
        }
        return max((d for d in dtypes if d in int_widths), key=lambda d: int_widths[d])

    # Datetime with differing time_unit or time_zone → normalize to us / UTC
    if all(isinstance(d, pl.Datetime) for d in dtypes):
        return pl.Datetime("us", "UTC")

    # Fallback: String is always safe
    return pl.String


# ── Schema inspection (metadata-only, no data read) ───────────────────────────


def collect_shard_schemas(
    paths: list[Path],
) -> dict[Path, dict[str, pl.DataType]]:
    """Read only parquet footer metadata — zero data loaded."""
    return {p: pl.read_parquet_schema(p) for p in paths}


def resolve_target_schema(
    shard_schemas: dict[Path, dict[str, pl.DataType]],
    keep_columns: Optional[list[str]] = None,
) -> dict[str, pl.DataType]:
    """
    Build a unified target schema from all shard schemas.
    - Union of all columns (shards missing a column will get a null literal)
    - Type conflicts resolved via _resolve_conflict()
    - If keep_columns is given, output is restricted to those columns
    """
    col_types: dict[str, set[pl.DataType]] = {}
    for schema in shard_schemas.values():
        for col, dtype in schema.items():
            col_types.setdefault(col, set()).add(dtype)

    target = {col: _resolve_conflict(types) for col, types in col_types.items()}

    if keep_columns:
        missing = set(keep_columns) - set(target)
        if missing:
            raise ValueError(f"Requested columns not found in any shard: {missing}")
        target = {c: target[c] for c in keep_columns}

    return target


# ── Per-shard harmonization (fully lazy) ──────────────────────────────────────


def harmonize_shard(
    path: Path,
    target_schema: dict[str, pl.DataType],
    shard_schema: dict[str, pl.DataType],
) -> pl.LazyFrame:
    """
    Return a LazyFrame for one shard that:
      - adds missing columns as typed nulls
      - drops extra columns not in target_schema
      - casts columns whose type differs from target
    All operations are lazy — nothing is collected.
    """
    lf = pl.scan_parquet(path)
    exprs: list[pl.Expr] = []

    for col, target_dtype in target_schema.items():
        if col not in shard_schema:
            # Column absent in this shard → null literal
            exprs.append(pl.lit(None).cast(target_dtype).alias(col))
        elif shard_schema[col] != target_dtype:
            # Type mismatch → cast (use try_cast to avoid hard failures on bad values)
            exprs.append(pl.col(col).cast(target_dtype, strict=False).alias(col))
        else:
            exprs.append(pl.col(col))

    return lf.select(exprs)


# ── Public entry point ─────────────────────────────────────────────────────────


def scan_harmonized(
    directory: str | Path,
    glob: str = "**/*.parquet",
    keep_columns: Optional[list[str]] = None,
    schema_sample: Optional[int] = None,
) -> pl.LazyFrame:
    """
    Lazily scan all parquet shards in a directory, harmonizing schemas.

    Args:
        directory:     Root folder containing sharded parquet files.
        glob:          Glob pattern to find shards (default: all parquet recursively).
        keep_columns:  If set, only these columns are retained in the output.
        schema_sample: If set, only inspect the first N shards for schema inference
                       (useful when there are thousands of shards with stable schemas).

    Returns:
        A single lazy LazyFrame with a unified, harmonized schema.
    """
    paths = sorted(Path(directory).glob(glob))
    if not paths:
        raise FileNotFoundError(
            f"No parquet files found in {directory!r} with {glob!r}"
        )

    sample = paths[:schema_sample] if schema_sample else paths
    shard_schemas = collect_shard_schemas(sample)
    target_schema = resolve_target_schema(shard_schemas, keep_columns=keep_columns)

    # Extend target to all paths (not just the sample) using cached schemas
    all_schemas = shard_schemas if not schema_sample else collect_shard_schemas(paths)

    # Build schemas for all paths, using target_schema as fallback for unsampled paths
    all_schemas = {}
    for path in paths:
        if path in shard_schemas:
            all_schemas[path] = shard_schemas[path]
        else:
            all_schemas[path] = target_schema

    frames = [harmonize_shard(path, target_schema, all_schemas[path]) for path in paths]
    logger.info(
        f"Harmonized {len(frames)} shards in {directory!r} with target schema: {target_schema}"
    )
    return pl.concat(frames, how="diagonal_relaxed")


def set_up_metadata(
    MEDS_input_dir: Path,
    do_overwrite: Boolean,
    OMOP_input_dir: Path,
    join_on_visit: Boolean,
    limit,
    schema_loader: OMOPSchemaBase,
    selector: SelectorType,
) -> tuple[pl.LazyFrame, pl.LazyFrame]:
    person_out_fp = MEDS_input_dir / "person_birth_death.parquet"
    concept_out_fp = MEDS_input_dir / "concept.parquet"
    concept_relationship_out_fp = MEDS_input_dir / "concept_relationship.parquet"
    codes_out_fp = MEDS_input_dir / "codes.parquet"

    if concept_out_fp.is_file() and do_overwrite:
        logger.info(
            f"Removing existing concept output {str(concept_out_fp.resolve())} because do_overwrite=True"
        )
        concept_out_fp.unlink()

    if concept_out_fp.is_file():
        logger.info(
            f"Reloading processed concepts df from {str(concept_out_fp.resolve())}"
        )
        concept_df = pl.read_parquet(concept_out_fp, use_pyarrow=True).lazy()
    else:
        logger.info("Processing concepts table first...")
        concept_path = get_table_path(OMOP_input_dir, "concept")
        if not concept_path:
            raise FileNotFoundError("No concept table found in the input directory.")
        concept_df = load_raw_file(concept_path, schema_loader, selector)
        concept_df = concept_df.with_columns(pl.col("concept_id").cast(pl.Int64))
        write_lazyframe(concept_df, concept_out_fp)

    if person_out_fp.is_file() and do_overwrite:
        logger.info(
            f"Removing existing patient output {str(person_out_fp.resolve())} because do_overwrite=True"
        )
        person_out_fp.unlink()

    if person_out_fp.is_file():
        logger.info(
            f"Reloading processed patient df from {str(person_out_fp.resolve())}"
        )
        patient_df = pl.scan_parquet(person_out_fp)
    else:
        logger.info("Processing person table...")
        person_in_fp = get_table_path(OMOP_input_dir, "person")
        if person_in_fp:
            person_df = load_raw_file(person_in_fp, schema_loader, selector)
        else:
            raise FileNotFoundError("No person table found in the input directory.")

        death_in_fp = get_table_path(OMOP_input_dir, "death")
        if death_in_fp:
            death_df = load_raw_file(death_in_fp, schema_loader, selector)
        else:
            death_df = None

        visit_in_fp = get_table_path(OMOP_input_dir, "visit_occurrence")
        visit_df = load_raw_file(visit_in_fp, schema_loader, selector)

        patient_df = get_patient_link(
            person_df=person_df,
            death_df=death_df,
            visit_df=visit_df,
            schema_loader=schema_loader,
            limit=limit,
            join_on_visit=join_on_visit,
        )
        patient_df = patient_df.with_columns(table_name=pl.lit("person_death"))
        patient_df.sink_parquet(person_out_fp)

    if concept_relationship_out_fp.is_file() and do_overwrite:
        logger.info(
            "Removing existing concept_relationship output "
            f"{str(concept_relationship_out_fp.resolve())} because do_overwrite=True"
        )
        concept_relationship_out_fp.unlink()

    if concept_relationship_out_fp.is_file():
        logger.info(
            f"Reloading processed concept_relationship df from {str(concept_relationship_out_fp.resolve())}"
        )
        concept_relationship_df = pl.scan_parquet(concept_relationship_out_fp)
    else:
        logger.info("Processing concept_relationship table first...")
        concept_relationship_fp = get_table_path(OMOP_input_dir, "concept_relationship")
        if not concept_relationship_fp:
            raise FileNotFoundError(
                "No concept relationship table found in the input directory."
            )
        logger.info(f"Loading {str(concept_relationship_fp.resolve())}...")
        concept_relationship_df = load_raw_file(
            concept_relationship_fp, schema_loader, selector
        )
        write_lazyframe(concept_relationship_df, concept_relationship_out_fp)

    # patient_df = patient_df.join(visit_df, on=SUBJECT_ID)
    if codes_out_fp.is_file() and do_overwrite:
        logger.info(
            f"Removing existing code metadata {str(codes_out_fp.resolve())} because do_overwrite=True"
        )
        codes_out_fp.unlink()

    if codes_out_fp.is_file():
        logger.info(f"Reusing existing code metadata at {str(codes_out_fp.resolve())}")
    else:
        metadata = extract_metadata(concept_df, concept_relationship_df)
        metadata.sink_parquet(codes_out_fp)
        logger.info(f"Wrote code metadata to {str(codes_out_fp.resolve())}")
    return concept_df, patient_df


def project_to_target_schema(
    lf: pl.LazyFrame, target_schema: dict[str, pl.DataType]
) -> pl.LazyFrame:
    existing = set(lf.collect_schema().names())
    exprs: list[pl.Expr] = []
    for col, dtype in target_schema.items():
        if col in existing:
            exprs.append(pl.col(col).cast(dtype, strict=False).alias(col))
        else:
            exprs.append(pl.lit(None, dtype=dtype).alias(col))
    return lf.select(exprs)


def _align_shard_to_schema(
    lf: pl.LazyFrame, target_schema: dict[str, pl.DataType]
) -> pl.LazyFrame:
    """Project a shard to exactly target schema (add missing as null, cast permissively)."""
    existing = set(lf.collect_schema().names())
    exprs: list[pl.Expr] = []
    for col, dtype in target_schema.items():
        if col in existing:
            exprs.append(pl.col(col).cast(dtype, strict=False).alias(col))
        else:
            exprs.append(pl.lit(None).cast(dtype).alias(col))
    return lf.select(exprs)
