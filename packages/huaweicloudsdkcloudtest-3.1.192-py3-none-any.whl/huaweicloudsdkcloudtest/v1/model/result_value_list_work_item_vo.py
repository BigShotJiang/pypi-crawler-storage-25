# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ResultValueListWorkItemVo:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'value': 'list[WorkItemVo]'
    }

    attribute_map = {
        'value': 'value'
    }

    def __init__(self, value=None):
        r"""ResultValueListWorkItemVo

        The model defined in huaweicloud sdk

        :param value: 实际的数据类型：单个对象，集合 或 NULL
        :type value: list[:class:`huaweicloudsdkcloudtest.v1.WorkItemVo`]
        """
        
        

        self._value = None
        self.discriminator = None

        if value is not None:
            self.value = value

    @property
    def value(self):
        r"""Gets the value of this ResultValueListWorkItemVo.

        实际的数据类型：单个对象，集合 或 NULL

        :return: The value of this ResultValueListWorkItemVo.
        :rtype: list[:class:`huaweicloudsdkcloudtest.v1.WorkItemVo`]
        """
        return self._value

    @value.setter
    def value(self, value):
        r"""Sets the value of this ResultValueListWorkItemVo.

        实际的数据类型：单个对象，集合 或 NULL

        :param value: The value of this ResultValueListWorkItemVo.
        :type value: list[:class:`huaweicloudsdkcloudtest.v1.WorkItemVo`]
        """
        self._value = value

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ResultValueListWorkItemVo):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
