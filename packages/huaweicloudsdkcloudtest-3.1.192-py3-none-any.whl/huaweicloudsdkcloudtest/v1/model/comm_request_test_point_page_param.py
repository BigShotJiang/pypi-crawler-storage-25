# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class CommRequestTestPointPageParam:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'params': 'TestPointPageParam'
    }

    attribute_map = {
        'params': 'params'
    }

    def __init__(self, params=None):
        r"""CommRequestTestPointPageParam

        The model defined in huaweicloud sdk

        :param params: 
        :type params: :class:`huaweicloudsdkcloudtest.v1.TestPointPageParam`
        """
        
        

        self._params = None
        self.discriminator = None

        if params is not None:
            self.params = params

    @property
    def params(self):
        r"""Gets the params of this CommRequestTestPointPageParam.

        :return: The params of this CommRequestTestPointPageParam.
        :rtype: :class:`huaweicloudsdkcloudtest.v1.TestPointPageParam`
        """
        return self._params

    @params.setter
    def params(self, params):
        r"""Sets the params of this CommRequestTestPointPageParam.

        :param params: The params of this CommRequestTestPointPageParam.
        :type params: :class:`huaweicloudsdkcloudtest.v1.TestPointPageParam`
        """
        self._params = params

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CommRequestTestPointPageParam):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
