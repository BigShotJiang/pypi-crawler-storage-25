"""CLI entrypoint for gh-wait."""

from __future__ import annotations

import argparse
import sys

from .github import detect_repo, get_latest_pr_number
from .poller import wait_ci, wait_coderabbit, wait_mergeable, wait_pr, wait_reviews

_PR_HELP = "PR number"


def _resolve_repo(args: argparse.Namespace) -> str:
    repo = getattr(args, "repo", None) or detect_repo()
    if not repo:
        print("Cannot detect repo. Use -R owner/repo", file=sys.stderr)
        raise SystemExit(1)
    return repo


def _resolve_pr(args: argparse.Namespace, repo: str) -> int:
    if args.pr:
        return int(args.pr)
    branch = getattr(args, "branch", None)
    return get_latest_pr_number(repo, branch)


def cmd_pr(args: argparse.Namespace) -> None:
    repo = _resolve_repo(args)
    pr = _resolve_pr(args, repo)
    ok = wait_pr(repo, pr, poll_interval=args.interval, timeout=args.timeout)
    sys.exit(0 if ok else 1)


def cmd_ci(args: argparse.Namespace) -> None:
    repo = _resolve_repo(args)
    ok = wait_ci(repo, int(args.run_id), poll_interval=args.interval, timeout=args.timeout)
    sys.exit(0 if ok else 1)


def cmd_reviews(args: argparse.Namespace) -> None:
    repo = _resolve_repo(args)
    pr = _resolve_pr(args, repo)
    ok = wait_reviews(repo, pr, poll_interval=args.interval, timeout=args.timeout)
    sys.exit(0 if ok else 1)


def cmd_coderabbit(args: argparse.Namespace) -> None:
    repo = _resolve_repo(args)
    pr = _resolve_pr(args, repo)
    ok = wait_coderabbit(repo, pr, poll_interval=args.interval, timeout=args.timeout)
    sys.exit(0 if ok else 1)


def cmd_mergeable(args: argparse.Namespace) -> None:
    repo = _resolve_repo(args)
    pr = _resolve_pr(args, repo)
    ok = wait_mergeable(repo, pr, poll_interval=args.interval, timeout=args.timeout)
    sys.exit(0 if ok else 1)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="gh-wait",
        description="Smart CI/PR wait tool. Polls GitHub Actions, reviews, etc.",
    )
    parser.add_argument(
        "-R",
        "--repo",
        help="owner/repo (default: auto-detect from git remote)",
    )
    parser.add_argument(
        "-i",
        "--interval",
        type=int,
        default=30,
        help="poll interval seconds (default: 30)",
    )
    parser.add_argument(
        "-t",
        "--timeout",
        type=int,
        default=600,
        help="timeout seconds (default: 600)",
    )
    parser.add_argument("--branch", help="branch name to find PR (alternative to PR number)")

    sub = parser.add_subparsers(dest="command", required=True)

    pr_cmd = sub.add_parser("pr", help="Wait for all PR checks to complete")
    pr_cmd.add_argument("pr", nargs="?", help="PR number (default: latest open PR)")
    pr_cmd.set_defaults(func=cmd_pr)

    ci_cmd = sub.add_parser("ci", help="Wait for a specific workflow run")
    ci_cmd.add_argument("run_id", help="Workflow run ID")
    ci_cmd.set_defaults(func=cmd_ci)

    rev_cmd = sub.add_parser("reviews", help="Wait for all requested reviews")
    rev_cmd.add_argument("pr", nargs="?", help=_PR_HELP)
    rev_cmd.set_defaults(func=cmd_reviews)

    cr_cmd = sub.add_parser("coderabbit", help="Wait for CodeRabbit review")
    cr_cmd.add_argument("pr", nargs="?", help=_PR_HELP)
    cr_cmd.set_defaults(func=cmd_coderabbit)

    merge_cmd = sub.add_parser("mergeable", help="Wait for PR to be mergeable")
    merge_cmd.add_argument("pr", nargs="?", help=_PR_HELP)
    merge_cmd.set_defaults(func=cmd_mergeable)

    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    args.func(args)
