"""Polling logic for gh-wait subcommands."""

from __future__ import annotations

import sys
import time

from .github import (
    CheckResult,
    get_pr_checks,
    get_pr_head_sha,
    get_pr_reviews,
    get_pr_state,
    get_workflow_run_jobs,
)


def _format_check(c: CheckResult) -> str:
    icons = {"success": "✓", "failure": "✗", "cancelled": "⊘", "skipped": "○"}
    icon = icons.get(c.conclusion or "", "·")
    status_map = {"in_progress": "⏳", "queued": "⏳", "waiting": "⏳", "completed": " "}
    status_icon = status_map.get(c.status, " ")
    return f"  {icon} {status_icon} {c.name}: {c.conclusion or c.status}"


def _summary_line(checks: list[CheckResult]) -> str:
    done = sum(1 for c in checks if c.status == "completed")
    total = len(checks)
    failed = sum(1 for c in checks if c.conclusion == "failure")
    parts = [f"{done}/{total} done"]
    if failed:
        parts.append(f"{failed} failed")
    return ", ".join(parts)


def _write_pr_status(
    repo: str, pr: int, checks: list[CheckResult], state, elapsed: int, prev_line_count: int
) -> int:
    lines = [
        f"\r⏳ PR #{pr} [{_summary_line(checks)}] {elapsed}s elapsed",
    ]
    if state.mergeable is not None:
        lines.append(f"  mergeable: {state.mergeable_state}")
    for c in checks:
        lines.append(_format_check(c))
    output = "\n".join(lines)
    sys.stdout.write(f"\x1b[{prev_line_count}F\x1b[J{output}\n")
    sys.stdout.flush()
    return output.count("\n") + 1


def _handle_pr_completion(checks: list[CheckResult]) -> bool:
    failed_conclusions = {
        "failure",
        "cancelled",
        "skipped",
        "stale",
        "neutral",
        "timed_out",
        "action_required",
    }
    failed = [c for c in checks if c.conclusion in failed_conclusions]
    succeeded = [c for c in checks if c.conclusion == "success"]
    if failed:
        print(f"\n✗ {len(failed)} check(s) failed:", file=sys.stderr)
        for c in failed:
            print(f"  ✗ {c.name} ({c.conclusion})", file=sys.stderr)
        return False
    print(f"\n✓ {len(succeeded)} checks passed")
    return True


def wait_pr(repo: str, pr: int, poll_interval: int = 30, timeout: int = 600) -> bool:
    """Wait for all required PR checks to complete. Returns True if all pass."""
    start = time.monotonic()
    prev_line_count = 0

    while True:
        elapsed = int(time.monotonic() - start)
        if elapsed > timeout:
            print(f"\n⏰ Timeout after {timeout}s", file=sys.stderr)
            return False

        checks = get_pr_checks(repo, pr)
        state = get_pr_state(repo, pr)
        prev_line_count = _write_pr_status(repo, pr, checks, state, elapsed, prev_line_count)

        running = [c for c in checks if c.status != "completed"]
        if not running:
            return _handle_pr_completion(checks)

        time.sleep(poll_interval)


def wait_ci(repo: str, run_id: int, poll_interval: int = 30, timeout: int = 600) -> bool:
    """Wait for a specific workflow run to complete. Returns True if all jobs pass."""
    start = time.monotonic()
    prev_line_count = 0

    while True:
        elapsed = int(time.monotonic() - start)
        if elapsed > timeout:
            print(f"\n⏰ Timeout after {timeout}s", file=sys.stderr)
            return False

        jobs = get_workflow_run_jobs(repo, run_id)
        running = [j for j in jobs if j.status != "completed"]
        failed = [j for j in jobs if j.conclusion == "failure"]
        succeeded = [j for j in jobs if j.conclusion == "success"]

        lines = [
            f"\r⏳ Run {run_id} [{_summary_line(jobs)}] {elapsed}s elapsed",
        ]
        for j in jobs:
            lines.append(_format_check(j))

        output = "\n".join(lines)
        sys.stdout.write(f"\x1b[{prev_line_count}F\x1b[J{output}\n")
        sys.stdout.flush()
        prev_line_count = output.count("\n") + 1

        if not running:
            all_pass = len(failed) == 0
            if all_pass:
                print(f"\n✓ All {len(succeeded)} jobs passed")
            else:
                print(f"\n✗ {len(failed)} job(s) failed:", file=sys.stderr)
                for j in failed:
                    print(f"  ✗ {j.name}", file=sys.stderr)
            return all_pass

        time.sleep(poll_interval)


def wait_reviews(repo: str, pr: int, poll_interval: int = 30, timeout: int = 600) -> bool:
    """Wait for all requested reviews to be submitted. Returns True if all approved."""
    start = time.monotonic()

    while True:
        elapsed = int(time.monotonic() - start)
        if elapsed > timeout:
            print(f"\n⏰ Timeout after {timeout}s", file=sys.stderr)
            return False

        reviews = get_pr_reviews(repo, pr)
        state = get_pr_state(repo, pr)

        if state.review_decision in ("APPROVED",):
            print(f"✓ PR #{pr} approved ({elapsed}s)")
            return True

        review_summary = {}
        for r in reviews:
            user = r["user"]["login"]
            review_summary[user] = r["state"]

        if review_summary:
            parts = [f"{u}: {s}" for u, s in review_summary.items()]
            print(f"\r⏳ PR #{pr} reviews: {', '.join(parts)} ({elapsed}s)", end="", flush=True)
        else:
            print(f"\r⏳ PR #{pr} waiting for reviews... ({elapsed}s)", end="", flush=True)

        time.sleep(poll_interval)


def wait_coderabbit(
    repo: str,
    pr: int,
    poll_interval: int = 30,
    timeout: int = 600,
) -> bool:
    """Wait for CodeRabbit review for the latest commit. Returns True if non-blocking."""
    start = time.monotonic()

    while True:
        elapsed = int(time.monotonic() - start)
        if elapsed > timeout:
            print(f"\n⏰ Timeout after {timeout}s", file=sys.stderr)
            return False

        head_sha = get_pr_head_sha(repo, pr)
        reviews = get_pr_reviews(repo, pr)

        # Only consider reviews for the latest commit
        cr_reviews = [
            r
            for r in reviews
            if r.get("user", {}).get("login", "").lower() in ("coderabbitai", "coderabbitai[bot]")
            and r.get("commit_id") == head_sha
        ]

        # CodeRabbit posts a preliminary "review in progress" review before the
        # actual review. Skip it — we want the final review with actual findings.
        cr_reviews = [
            r for r in cr_reviews if "review in progress" not in (r.get("body") or "").lower()
        ]

        if cr_reviews:
            latest = cr_reviews[-1]
            state = latest["state"]
            print(f"✓ CodeRabbit review: {state} ({elapsed}s)")
            return state != "CHANGES_REQUESTED"

        msg = f"\r⏳ Waiting for CodeRabbit review on PR #{pr}... "
        print(f"{msg}({elapsed}s)", end="", flush=True)
        time.sleep(poll_interval)


def wait_mergeable(repo: str, pr: int, poll_interval: int = 15, timeout: int = 120) -> bool:
    """Wait for PR mergeable_state to become clean. Returns True if mergeable."""
    start = time.monotonic()

    while True:
        elapsed = int(time.monotonic() - start)
        if elapsed > timeout:
            print(f"\n⏰ Timeout after {timeout}s", file=sys.stderr)
            return False

        state = get_pr_state(repo, pr)

        if state.mergeable_state == "clean":
            print(f"✓ PR #{pr} is mergeable ({elapsed}s)")
            return True

        if state.mergeable_state == "dirty":
            print(f"✗ PR #{pr} has merge conflicts ({elapsed}s)", file=sys.stderr)
            return False

        if state.mergeable_state == "blocked":
            print(f"✗ PR #{pr} is blocked ({elapsed}s)", file=sys.stderr)
            return False

        if state.mergeable is False and state.mergeable_state in ("blocked", "unknown"):
            print(
                f"\r⏳ PR #{pr} mergeable_state={state.mergeable_state}... ({elapsed}s)",
                end="",
                flush=True,
            )

        time.sleep(poll_interval)
