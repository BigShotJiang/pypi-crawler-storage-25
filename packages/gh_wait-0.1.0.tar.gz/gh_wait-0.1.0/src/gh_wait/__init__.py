"""gh-wait: Smart CI/PR wait tool."""

from __future__ import annotations

__version__ = "0.1.0"
