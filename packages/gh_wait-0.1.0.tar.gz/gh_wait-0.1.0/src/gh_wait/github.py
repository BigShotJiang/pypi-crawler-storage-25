"""GitHub API helpers using `gh` CLI."""

from __future__ import annotations

import json
import subprocess
import sys
from dataclasses import dataclass


@dataclass
class CheckResult:
    name: str
    conclusion: str | None  # success, failure, null (running)
    status: str  # completed, in_progress, queued, waiting


@dataclass
class PRState:
    mergeable: bool | None
    mergeable_state: str
    state: str
    review_decision: str | None


def _gh(*args: str, repo: str | None = None) -> str:
    cmd = ["gh"]
    # gh api subcommand embeds repo in the URL path and doesn't accept -R.
    # Only pass -R for non-api subcommands like `pr`, `issue`, etc.
    if repo and (not args or args[0] != "api"):
        cmd += ["-R", repo]
    cmd += list(args)
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True, timeout=30)
        return result.stdout.strip()
    except subprocess.CalledProcessError as e:
        print(f"gh command failed: {' '.join(cmd)}\n{e.stderr}", file=sys.stderr)
        raise SystemExit(1) from e
    except subprocess.TimeoutExpired:
        print(f"gh command timed out: {' '.join(cmd)}", file=sys.stderr)
        raise SystemExit(1) from None


def _gh_json(*args: str, repo: str | None = None) -> dict | list:
    return json.loads(_gh(*args, repo=repo))


def detect_repo() -> str | None:
    try:
        result = subprocess.run(
            ["git", "remote", "get-url", "origin"],
            capture_output=True,
            text=True,
            check=True,
            timeout=10,
        )
        url = result.stdout.strip()
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired, FileNotFoundError):
        return None
    if ":" in url and "/" in url:
        suffix = ".git"
        if url.endswith(suffix):
            url = url[: -len(suffix)]
        parts = url.split(":")[-1].split("/")
        if len(parts) >= 2:
            return f"{parts[-2]}/{parts[-1]}"
    return None


def get_pr_checks(repo: str, pr: int) -> list[CheckResult]:
    data: dict = _gh_json("api", f"repos/{repo}/pulls/{pr}", repo=repo)  # type: ignore[assignment]  # _gh_json returns dict|list, known shape
    head_sha: str = data["head"]["sha"]

    checks_json: dict = _gh_json(  # type: ignore[assignment]  # _gh_json returns dict|list, known shape
        "api",
        f"repos/{repo}/commits/{head_sha}/check-runs?per_page=100",
        repo=repo,
    )
    return [
        CheckResult(
            name=cr["name"],
            conclusion=cr.get("conclusion"),
            status=cr["status"],
        )
        for cr in checks_json.get("check_runs", [])
    ]


def get_pr_state(repo: str, pr: int) -> PRState:
    data: dict = _gh_json("api", f"repos/{repo}/pulls/{pr}", repo=repo)  # type: ignore[assignment]  # _gh_json returns dict|list, known shape
    return PRState(
        mergeable=data.get("mergeable"),
        mergeable_state=data.get("mergeable_state", "unknown"),
        state=data["state"],
        review_decision=data.get("review_decision"),
    )


def get_workflow_run_jobs(repo: str, run_id: int) -> list[CheckResult]:
    data: dict = _gh_json("api", f"repos/{repo}/actions/runs/{run_id}/jobs", repo=repo)  # type: ignore[assignment]  # _gh_json returns dict|list, known shape
    return [
        CheckResult(
            name=job["name"],
            conclusion=job.get("conclusion"),
            status=job["status"],
        )
        for job in data.get("jobs", [])
    ]


def get_pr_head_sha(repo: str, pr: int) -> str:
    data: dict = _gh_json("api", f"repos/{repo}/pulls/{pr}", repo=repo)  # type: ignore[assignment]
    return data["head"]["sha"]  # type: ignore[no-any-return]


def get_pr_reviews(repo: str, pr: int) -> list[dict]:
    return _gh_json("api", f"repos/{repo}/pulls/{pr}/reviews", repo=repo)  # type: ignore[no-any-return]  # _gh_json returns dict|list, known shape


def get_pr_review_comments(repo: str, pr: int) -> list[dict]:
    return _gh_json("api", f"repos/{repo}/pulls/{pr}/comments", repo=repo)  # type: ignore[no-any-return]  # _gh_json returns dict|list, known shape


def get_pr_comment_body(repo: str, comment_id: int) -> str:
    data: dict = _gh_json("api", f"repos/{repo}/pulls/comments/{comment_id}", repo=repo)  # type: ignore[assignment]  # _gh_json returns dict|list, known shape
    return data.get("body", "")


def get_latest_pr_number(repo: str, branch: str | None = None) -> int:
    args = ["pr", "list", "--state", "open", "--limit", "1", "--json", "number"]
    if branch:
        args += ["--head", branch]
    data = _gh_json(*args, repo=repo)
    if not data:
        raise SystemExit("No open PRs found")
    return data[0]["number"]  # type: ignore[no-any-return]  # _gh_json returns dict|list, known shape
