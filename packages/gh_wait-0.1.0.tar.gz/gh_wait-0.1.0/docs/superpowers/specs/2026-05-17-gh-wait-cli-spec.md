# SPEC: gh-wait CLI Architecture

**Date:** 2026-05-17  
**Status:** Draft  

## Overview

gh-wait is a zero-dependency Python CLI that polls GitHub CI/CD state and blocks until a target condition is met. It wraps the `gh` CLI for all API access, avoiding external HTTP client dependencies.

## Architecture

### Entrypoint

```
gh-wait → gh_wait.cli:main → argparse → subcommand dispatch
```

### Module boundaries

```
┌─────────────┐     ┌──────────────┐     ┌──────────────┐
│  cli.py     │────▶│  poller.py   │────▶│  github.py   │
│  (argparse) │     │  (loop/sleep)│     │  (gh wrapper)│
│  exit codes │     │  ANSI render │     │  dataclasses │
└─────────────┘     └──────────────┘     └──────────────┘
```

- **cli.py** — Parses args, resolves repo/PR, calls poller, exits.
- **poller.py** — Each `wait_*` function is a fetch→render→sleep loop returning `bool`.
- **github.py** — `_gh()` shells out to `gh`. `_gh_json()` parses JSON response. Dataclasses provide typed returns.

### Data flow

1. User runs `gh-wait pr 42 -R owner/repo`
2. `cli.cmd_pr()` resolves args, calls `poller.wait_pr("owner/repo", 42, 30, 600)`
3. `wait_pr` loops:
   - Calls `github.get_pr_checks()` and `github.get_pr_state()`
   - Renders progress via ANSI escape codes
   - Sleeps `poll_interval` seconds
   - Breaks when all checks complete or timeout
4. Returns `True` (all pass) or `False` (failure/timeout)
5. `cli.cmd_pr()` calls `sys.exit(0 if ok else 1)`

## Subcommand reference

### `gh-wait pr [PR]`

Waits for all check runs on a PR to complete.

- Fetches: `get_pr_checks()` + `get_pr_state()`
- Terminal: live-updating table with check statuses
- Exit: 0 if all pass, 1 if any fail or timeout

### `gh-wait ci RUN_ID`

Waits for a specific workflow run (by numeric ID) to complete.

- Fetches: `get_workflow_run_jobs()`
- Terminal: live-updating job list
- Exit: 0 if all jobs pass, 1 if any fail or timeout

### `gh-wait coderabbit [PR]`

Waits for CodeRabbit AI review to appear on the PR.

- Fetches: `get_pr_reviews()`, filtered by `coderabbitai[bot]` login
- Checks for any review from CodeRabbit bot
- Terminal: single-line spinner
- Exit: 0 if review is not CHANGES_REQUESTED, 1 if CHANGES_REQUESTED or timeout

### `gh-wait reviews [PR]`

Waits for all requested reviews to be submitted.

- Fetches: `get_pr_reviews()` + `get_pr_state()` (for `review_decision`)
- Terminal: live summary of reviewer states
- Exit: 0 if `review_decision == "APPROVED"`, 1 if timeout

### `gh-wait mergeable [PR]`

Waits for PR's `mergeable_state` to become `clean`.

- Fetches: `get_pr_state()`
- Shorter defaults: interval=15s, timeout=120s
- Exit: 0 if clean, 1 if dirty or timeout

## Error handling

| Scenario | Behavior |
|----------|----------|
| `gh` not installed | `subprocess.CalledProcessError` → print stderr → `sys.exit(1)` |
| No git remote | `detect_repo()` returns None → error message → `sys.exit(1)` |
| No open PRs | `get_latest_pr_number()` → `sys.exit("No open PRs found")` |
| `gh` command times out | `subprocess.TimeoutExpired` → error message → `sys.exit(1)` |
| Poll timeout | Print "Timeout after Ns" → return False → `sys.exit(1)` |

## Configuration surface

All config is CLI flags. No config files, no env vars (except `GH_TOKEN` which `gh` manages).

| Flag | Default | Purpose |
|------|---------|---------|
| `-R, --repo` | auto-detect | GitHub owner/repo |
| `-i, --interval` | 30 (15 for mergeable) | Poll interval in seconds |
| `-t, --timeout` | 600 (120 for mergeable) | Timeout in seconds |
| `--branch` | none | Find PR by head branch |

## Future considerations

- **Multiple PRs**: Accept comma-separated PR numbers, wait for all.
- **JSON output**: `--json` flag for machine-readable status.
- **Webhook mode**: Skip polling entirely, listen for webhook events.
- **daemon mode**: Long-lived process that watches multiple PRs.
