"""Tests for gh-wait."""

from __future__ import annotations

import subprocess
from unittest.mock import patch

from gh_wait.github import CheckResult, PRState
from gh_wait.poller import wait_ci, wait_coderabbit, wait_mergeable, wait_pr, wait_reviews


def _mock_subprocess_run(responses: list[str]):
    call_count = 0

    def _run(cmd):
        nonlocal call_count
        if call_count < len(responses):
            result = subprocess.CompletedProcess(
                cmd, returncode=0, stdout=responses[call_count], stderr=""
            )
            call_count += 1
            return result
        raise AssertionError(f"unexpected subprocess call #{call_count}: {cmd}")

    return _run


class TestCheckResult:
    def test_completed_success(self):
        c = CheckResult(name="test", conclusion="success", status="completed")
        assert c.status == "completed"
        assert c.conclusion == "success"

    def test_running(self):
        c = CheckResult(name="test", conclusion=None, status="in_progress")
        assert c.conclusion is None


class TestWaitCi:
    @patch("gh_wait.poller.get_workflow_run_jobs")
    def test_all_pass(self, mock_jobs):
        mock_jobs.return_value = [
            CheckResult("Lint", "success", "completed"),
            CheckResult("Test", "success", "completed"),
        ]
        assert wait_ci("owner/repo", 123, poll_interval=0, timeout=10) is True

    @patch("gh_wait.poller.get_workflow_run_jobs")
    def test_failure(self, mock_jobs):
        mock_jobs.return_value = [
            CheckResult("Lint", "success", "completed"),
            CheckResult("Test", "failure", "completed"),
        ]
        assert wait_ci("owner/repo", 123, poll_interval=0, timeout=10) is False

    @patch("gh_wait.poller.get_workflow_run_jobs")
    def test_timeout(self, mock_jobs):
        mock_jobs.return_value = [
            CheckResult("Test", None, "in_progress"),
        ]
        assert wait_ci("owner/repo", 123, poll_interval=0, timeout=0) is False

    @patch("gh_wait.poller.get_workflow_run_jobs")
    def test_transitions_from_running_to_done(self, mock_jobs):
        call_count = 0

        def _jobs(*args):
            nonlocal call_count
            call_count += 1
            if call_count <= 2:
                return [CheckResult("Test", None, "in_progress")]
            return [CheckResult("Test", "success", "completed")]

        mock_jobs.side_effect = _jobs
        assert wait_ci("owner/repo", 123, poll_interval=0, timeout=10) is True


class TestWaitPr:
    @patch("gh_wait.poller.get_pr_state")
    @patch("gh_wait.poller.get_pr_checks")
    def test_all_pass(self, mock_checks, mock_state):
        mock_checks.return_value = [CheckResult("CI", "success", "completed")]
        mock_state.return_value = PRState(True, "clean", "open", "APPROVED")
        assert wait_pr("owner/repo", 1, poll_interval=0, timeout=10) is True

    @patch("gh_wait.poller.get_pr_state")
    @patch("gh_wait.poller.get_pr_checks")
    def test_failure(self, mock_checks, mock_state):
        mock_checks.return_value = [CheckResult("CI", "failure", "completed")]
        mock_state.return_value = PRState(True, "clean", "open", None)
        assert wait_pr("owner/repo", 1, poll_interval=0, timeout=10) is False


class TestWaitMergeable:
    @patch("gh_wait.poller.get_pr_state")
    def test_clean(self, mock_state):
        mock_state.return_value = PRState(True, "clean", "open", None)
        assert wait_mergeable("owner/repo", 1, poll_interval=0, timeout=10) is True

    @patch("gh_wait.poller.get_pr_state")
    def test_dirty(self, mock_state):
        mock_state.return_value = PRState(False, "dirty", "open", None)
        assert wait_mergeable("owner/repo", 1, poll_interval=0, timeout=10) is False

    @patch("gh_wait.poller.get_pr_state")
    def test_timeout(self, mock_state):
        mock_state.return_value = PRState(None, "unknown", "open", None)
        assert wait_mergeable("owner/repo", 1, poll_interval=0, timeout=0) is False


class TestWaitReviews:
    @patch("gh_wait.poller.get_pr_state")
    @patch("gh_wait.poller.get_pr_reviews")
    def test_approved(self, mock_reviews, mock_state):
        mock_reviews.return_value = [{"user": {"login": "alice"}, "state": "APPROVED"}]
        mock_state.return_value = PRState(True, "clean", "open", "APPROVED")
        assert wait_reviews("owner/repo", 1, poll_interval=0, timeout=10) is True

    @patch("gh_wait.poller.get_pr_state")
    @patch("gh_wait.poller.get_pr_reviews")
    def test_timeout(self, mock_reviews, mock_state):
        mock_reviews.return_value = []
        mock_state.return_value = PRState(True, "clean", "open", "REVIEW_REQUIRED")
        assert wait_reviews("owner/repo", 1, poll_interval=0, timeout=0) is False


HEAD_SHA = "abc123"


class TestWaitCoderabbit:
    @patch("gh_wait.poller.get_pr_head_sha")
    @patch("gh_wait.poller.get_pr_reviews")
    def test_review_found(self, mock_reviews, mock_head):
        mock_head.return_value = HEAD_SHA
        mock_reviews.return_value = [
            {
                "user": {"login": "coderabbitai"},
                "state": "COMMENTED",
                "body": "Looks good",
                "commit_id": HEAD_SHA,
            },
        ]
        assert wait_coderabbit("owner/repo", 1, poll_interval=0, timeout=10) is True

    @patch("gh_wait.poller.get_pr_head_sha")
    @patch("gh_wait.poller.get_pr_reviews")
    def test_skips_stale_commit_review(self, mock_reviews, mock_head):
        """Review for an old commit should be skipped; wait for current commit review."""
        mock_head.return_value = HEAD_SHA
        mock_reviews.return_value = [
            {
                "user": {"login": "coderabbitai"},
                "state": "COMMENTED",
                "body": "Looks good",
                "commit_id": "oldsha999",
            },
        ]
        assert wait_coderabbit("owner/repo", 1, poll_interval=0, timeout=0) is False

    @patch("gh_wait.poller.get_pr_head_sha")
    @patch("gh_wait.poller.get_pr_reviews")
    def test_accepts_when_commit_id_updates(self, mock_reviews, mock_head):
        """After push, should reject reviews for old SHA then accept new."""
        mock_head.return_value = HEAD_SHA
        mock_reviews.side_effect = [
            # First poll: only old commit review
            [
                {
                    "user": {"login": "coderabbitai"},
                    "state": "COMMENTED",
                    "body": "Old review",
                    "commit_id": "oldsha999",
                },
            ],
            # Second poll: new commit review appears
            [
                {
                    "user": {"login": "coderabbitai"},
                    "state": "COMMENTED",
                    "body": "Old review",
                    "commit_id": "oldsha999",
                },
                {
                    "user": {"login": "coderabbitai"},
                    "state": "COMMENTED",
                    "body": "New review on latest commit",
                    "commit_id": HEAD_SHA,
                },
            ],
        ]
        assert wait_coderabbit("owner/repo", 1, poll_interval=0, timeout=10) is True

    @patch("gh_wait.poller.get_pr_head_sha")
    @patch("gh_wait.poller.get_pr_reviews")
    def test_skips_in_progress_review(self, mock_reviews, mock_head):
        """Preliminary 'review in progress' should be skipped; wait for actual review."""
        mock_head.return_value = HEAD_SHA
        mock_reviews.return_value = [
            {
                "user": {"login": "coderabbitai[bot]"},
                "state": "COMMENTED",
                "body": "review in progress by coderabbit.ai",
                "commit_id": HEAD_SHA,
            },
        ]
        # Only "in progress" review — should time out
        assert wait_coderabbit("owner/repo", 1, poll_interval=0, timeout=0) is False

    @patch("gh_wait.poller.get_pr_head_sha")
    @patch("gh_wait.poller.get_pr_reviews")
    def test_skips_in_progress_then_accepts_final(self, mock_reviews, mock_head):
        """After 'in progress' is replaced by final review, should accept final."""
        mock_head.return_value = HEAD_SHA
        mock_reviews.side_effect = [
            [
                {
                    "user": {"login": "coderabbitai[bot]"},
                    "state": "COMMENTED",
                    "body": "review in progress by coderabbit.ai",
                    "commit_id": HEAD_SHA,
                },
            ],
            [
                {
                    "user": {"login": "coderabbitai[bot]"},
                    "state": "COMMENTED",
                    "body": "review in progress by coderabbit.ai",
                    "commit_id": HEAD_SHA,
                },
                {
                    "user": {"login": "coderabbitai[bot]"},
                    "state": "COMMENTED",
                    "body": "Final review: looks good 🐰",
                    "commit_id": HEAD_SHA,
                },
            ],
        ]
        assert wait_coderabbit("owner/repo", 1, poll_interval=0, timeout=10) is True

    @patch("gh_wait.poller.get_pr_head_sha")
    @patch("gh_wait.poller.get_pr_reviews")
    def test_changes_requested(self, mock_reviews, mock_head):
        mock_head.return_value = HEAD_SHA
        mock_reviews.return_value = [
            {
                "user": {"login": "coderabbitai[bot]"},
                "state": "CHANGES_REQUESTED",
                "body": "Fix: ...",
                "commit_id": HEAD_SHA,
            },
        ]
        assert wait_coderabbit("owner/repo", 1, poll_interval=0, timeout=10) is False

    @patch("gh_wait.poller.get_pr_head_sha")
    @patch("gh_wait.poller.get_pr_reviews")
    def test_timeout(self, mock_reviews, mock_head):
        mock_head.return_value = HEAD_SHA
        mock_reviews.return_value = []
        assert wait_coderabbit("owner/repo", 1, poll_interval=0, timeout=0) is False
