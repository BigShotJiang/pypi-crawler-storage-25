from __future__ import annotations

import argparse
from unittest.mock import MagicMock, patch

import pytest

from gh_wait.cli import (
    _resolve_repo,
    build_parser,
    cmd_ci,
    cmd_coderabbit,
    cmd_mergeable,
    cmd_pr,
    cmd_reviews,
    main,
)


class TestBuildParser:
    def test_builds_parser(self):
        parser = build_parser()
        assert isinstance(parser, argparse.ArgumentParser)
        assert parser.prog == "gh-wait"

    def test_pr_subcommand(self):
        parser = build_parser()
        args = parser.parse_args(["pr", "42"])
        assert args.command == "pr"
        assert args.pr == "42"

    def test_pr_with_repo(self):
        parser = build_parser()
        args = parser.parse_args(["-R", "owner/repo", "pr", "42"])
        assert args.repo == "owner/repo"

    def test_ci_subcommand(self):
        parser = build_parser()
        args = parser.parse_args(["ci", "12345"])
        assert args.command == "ci"
        assert args.run_id == "12345"

    def test_reviews_subcommand(self):
        parser = build_parser()
        args = parser.parse_args(["reviews"])
        assert args.command == "reviews"

    def test_coderabbit_subcommand(self):
        parser = build_parser()
        args = parser.parse_args(["coderabbit", "99"])
        assert args.command == "coderabbit"
        assert args.pr == "99"

    def test_mergeable_subcommand(self):
        parser = build_parser()
        args = parser.parse_args(["mergeable", "7"])
        assert args.command == "mergeable"
        assert args.pr == "7"

    def test_default_interval(self):
        parser = build_parser()
        args = parser.parse_args(["pr"])
        assert args.interval == 30

    def test_custom_interval(self):
        parser = build_parser()
        args = parser.parse_args(["-i", "15", "pr"])
        assert args.interval == 15

    def test_default_timeout(self):
        parser = build_parser()
        args = parser.parse_args(["pr"])
        assert args.timeout == 600

    def test_custom_timeout(self):
        parser = build_parser()
        args = parser.parse_args(["-t", "300", "pr"])
        assert args.timeout == 300


class TestResolveRepo:
    @patch("gh_wait.cli.detect_repo")
    def test_uses_provided_repo(self, mock_detect):
        args = argparse.Namespace(repo="my/repo")
        result = _resolve_repo(args)
        assert result == "my/repo"
        mock_detect.assert_not_called()

    @patch("gh_wait.cli.detect_repo")
    def test_falls_back_to_detect(self, mock_detect):
        mock_detect.return_value = "detected/repo"
        args = argparse.Namespace(repo=None)
        result = _resolve_repo(args)
        assert result == "detected/repo"

    @patch("gh_wait.cli.detect_repo")
    def test_exits_when_no_repo(self, mock_detect):
        mock_detect.return_value = None
        args = argparse.Namespace(repo=None)
        with pytest.raises(SystemExit) as exc:
            _resolve_repo(args)
        assert exc.value.code == 1


class TestResolvePr:
    @patch("gh_wait.cli.get_latest_pr_number")
    def test_uses_provided_pr(self, mock_get_latest):
        parser = build_parser()
        args = parser.parse_args(["pr", "42"])
        from gh_wait.cli import _resolve_pr

        result = _resolve_pr(args, "owner/repo")
        assert result == 42
        mock_get_latest.assert_not_called()

    @patch("gh_wait.cli.get_latest_pr_number")
    def test_falls_back_to_latest(self, mock_get_latest):
        mock_get_latest.return_value = 7
        parser = build_parser()
        args = parser.parse_args(["pr"])
        from gh_wait.cli import _resolve_pr

        result = _resolve_pr(args, "owner/repo")
        assert result == 7


def _make_args(**kw):
    defaults = {
        "repo": None,
        "pr": None,
        "branch": None,
        "interval": 30,
        "timeout": 600,
        "run_id": None,
    }
    defaults.update(kw)
    return argparse.Namespace(**defaults)


class TestCmdPr:
    @patch("gh_wait.cli._resolve_repo")
    @patch("gh_wait.cli._resolve_pr")
    @patch("gh_wait.cli.wait_pr")
    def test_success_exits_zero(self, mock_wait, mock_resolve_pr, mock_resolve_repo):
        mock_resolve_repo.return_value = "owner/repo"
        mock_resolve_pr.return_value = 1
        mock_wait.return_value = True
        with pytest.raises(SystemExit) as exc:
            cmd_pr(_make_args())
        assert exc.value.code == 0

    @patch("gh_wait.cli._resolve_repo")
    @patch("gh_wait.cli._resolve_pr")
    @patch("gh_wait.cli.wait_pr")
    def test_failure_exits_one(self, mock_wait, mock_resolve_pr, mock_resolve_repo):
        mock_resolve_repo.return_value = "owner/repo"
        mock_resolve_pr.return_value = 1
        mock_wait.return_value = False
        with pytest.raises(SystemExit) as exc:
            cmd_pr(_make_args())
        assert exc.value.code == 1


class TestCmdCi:
    @patch("gh_wait.cli._resolve_repo")
    @patch("gh_wait.cli.wait_ci")
    def test_exit_zero(self, mock_wait, mock_repo):
        mock_repo.return_value = "owner/repo"
        mock_wait.return_value = True
        with pytest.raises(SystemExit) as exc:
            cmd_ci(_make_args(run_id="123"))
        assert exc.value.code == 0

    @patch("gh_wait.cli._resolve_repo")
    @patch("gh_wait.cli.wait_ci")
    def test_exit_one(self, mock_wait, mock_repo):
        mock_repo.return_value = "owner/repo"
        mock_wait.return_value = False
        with pytest.raises(SystemExit) as exc:
            cmd_ci(_make_args(run_id="123"))
        assert exc.value.code == 1


class TestCmdReviews:
    @patch("gh_wait.cli._resolve_repo")
    @patch("gh_wait.cli._resolve_pr")
    @patch("gh_wait.cli.wait_reviews")
    def test_exit_zero(self, mock_wait, mock_pr, mock_repo):
        mock_repo.return_value = "owner/repo"
        mock_pr.return_value = 1
        mock_wait.return_value = True
        with pytest.raises(SystemExit) as exc:
            cmd_reviews(_make_args())
        assert exc.value.code == 0

    @patch("gh_wait.cli._resolve_repo")
    @patch("gh_wait.cli._resolve_pr")
    @patch("gh_wait.cli.wait_reviews")
    def test_exit_one(self, mock_wait, mock_pr, mock_repo):
        mock_repo.return_value = "owner/repo"
        mock_pr.return_value = 1
        mock_wait.return_value = False
        with pytest.raises(SystemExit) as exc:
            cmd_reviews(_make_args())
        assert exc.value.code == 1


class TestCmdCoderabbit:
    @patch("gh_wait.cli._resolve_repo")
    @patch("gh_wait.cli._resolve_pr")
    @patch("gh_wait.cli.wait_coderabbit")
    def test_exit_zero(self, mock_wait, mock_pr, mock_repo):
        mock_repo.return_value = "owner/repo"
        mock_pr.return_value = 1
        mock_wait.return_value = True
        with pytest.raises(SystemExit) as exc:
            cmd_coderabbit(_make_args())
        assert exc.value.code == 0

    @patch("gh_wait.cli._resolve_repo")
    @patch("gh_wait.cli._resolve_pr")
    @patch("gh_wait.cli.wait_coderabbit")
    def test_exit_one(self, mock_wait, mock_pr, mock_repo):
        mock_repo.return_value = "owner/repo"
        mock_pr.return_value = 1
        mock_wait.return_value = False
        with pytest.raises(SystemExit) as exc:
            cmd_coderabbit(_make_args())
        assert exc.value.code == 1


class TestCmdMergeable:
    @patch("gh_wait.cli._resolve_repo")
    @patch("gh_wait.cli._resolve_pr")
    @patch("gh_wait.cli.wait_mergeable")
    def test_exit_zero(self, mock_wait, mock_pr, mock_repo):
        mock_repo.return_value = "owner/repo"
        mock_pr.return_value = 1
        mock_wait.return_value = True
        with pytest.raises(SystemExit) as exc:
            cmd_mergeable(_make_args())
        assert exc.value.code == 0

    @patch("gh_wait.cli._resolve_repo")
    @patch("gh_wait.cli._resolve_pr")
    @patch("gh_wait.cli.wait_mergeable")
    def test_exit_one(self, mock_wait, mock_pr, mock_repo):
        mock_repo.return_value = "owner/repo"
        mock_pr.return_value = 1
        mock_wait.return_value = False
        with pytest.raises(SystemExit) as exc:
            cmd_mergeable(_make_args())
        assert exc.value.code == 1


class TestMain:
    @patch("gh_wait.cli.build_parser")
    def test_main_calls_func(self, mock_builder):
        mock_parser = MagicMock()
        mock_args = MagicMock()
        mock_parser.parse_args.return_value = mock_args
        mock_builder.return_value = mock_parser
        main()
        mock_args.func.assert_called_once_with(mock_args)
