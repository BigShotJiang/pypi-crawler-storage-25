from __future__ import annotations

import json
import subprocess
from unittest.mock import patch

import pytest

from gh_wait.github import (
    _gh,
    _gh_json,
    detect_repo,
    get_latest_pr_number,
    get_pr_checks,
    get_pr_comment_body,
    get_pr_review_comments,
    get_pr_reviews,
    get_pr_state,
    get_workflow_run_jobs,
)


class TestGh:
    @patch("gh_wait.github.subprocess.run")
    def test_gh_basic(self, mock_run):
        mock_run.return_value = subprocess.CompletedProcess(
            ["gh", "version"], returncode=0, stdout="gh 2.0.0\n", stderr=""
        )
        result = _gh("version")
        assert result == "gh 2.0.0"

    @patch("gh_wait.github.subprocess.run")
    def test_gh_with_repo(self, mock_run):
        mock_run.return_value = subprocess.CompletedProcess(
            ["gh", "-R", "o/r", "pr", "list"], returncode=0, stdout="[]", stderr=""
        )
        result = _gh("pr", "list", repo="o/r")
        assert result == "[]"
        args = mock_run.call_args[0][0]
        assert "-R" in args
        assert "o/r" in args

    @patch("gh_wait.github.subprocess.run")
    def test_gh_skips_r_for_api(self, mock_run):
        """gh api subcommand does not accept -R; repo embedded in URL instead."""
        mock_run.return_value = subprocess.CompletedProcess(
            ["gh", "api", "repos/o/r/pulls/1"], returncode=0, stdout="{}", stderr=""
        )
        result = _gh("api", "repos/o/r/pulls/1", repo="o/r")
        assert result == "{}"
        args = mock_run.call_args[0][0]
        assert "-R" not in args, "api subcommand should not receive -R"

    @patch("gh_wait.github.subprocess.run")
    def test_gh_called_process_error(self, mock_run):
        mock_run.side_effect = subprocess.CalledProcessError(
            1, ["gh", "api", "bad"], stderr="not found"
        )
        with pytest.raises(SystemExit) as exc:
            _gh("api", "bad")
        assert exc.value.code == 1

    @patch("gh_wait.github.subprocess.run")
    def test_gh_timeout(self, mock_run):
        mock_run.side_effect = subprocess.TimeoutExpired(cmd=["gh", "api", "x"], timeout=30)
        with pytest.raises(SystemExit) as exc:
            _gh("api", "x")
        assert exc.value.code == 1


class TestGhJson:
    @patch("gh_wait.github._gh")
    def test_returns_parsed_json(self, mock_gh):
        mock_gh.return_value = '{"key": "value"}'
        result = _gh_json("api", "something", repo="o/r")
        assert result == {"key": "value"}


class TestDetectRepo:
    @patch("gh_wait.github.subprocess.run")
    def test_detects_ssh_url(self, mock_run):
        mock_run.return_value = subprocess.CompletedProcess(
            [], 0, stdout="git@github.com:owner/repo.git\n", stderr=""
        )
        assert detect_repo() == "owner/repo"

    @patch("gh_wait.github.subprocess.run")
    def test_detects_https_url(self, mock_run):
        mock_run.return_value = subprocess.CompletedProcess(
            [], 0, stdout="https://github.com/owner/repo\n", stderr=""
        )
        assert detect_repo() == "owner/repo"

    @patch("gh_wait.github.subprocess.run")
    def test_returns_none_on_error(self, mock_run):
        mock_run.side_effect = subprocess.CalledProcessError(128, ["git"], stderr="not a git repo")
        assert detect_repo() is None

    @patch("gh_wait.github.subprocess.run")
    def test_returns_none_on_timeout(self, mock_run):
        mock_run.side_effect = subprocess.TimeoutExpired(cmd=["git"], timeout=10)
        assert detect_repo() is None

    @patch("gh_wait.github.subprocess.run")
    def test_returns_none_on_filenotfound(self, mock_run):
        mock_run.side_effect = FileNotFoundError()
        assert detect_repo() is None

    @patch("gh_wait.github.subprocess.run")
    def test_malformed_url(self, mock_run):
        mock_run.return_value = subprocess.CompletedProcess([], 0, stdout="not-a-url\n", stderr="")
        assert detect_repo() is None

    @patch("gh_wait.github.subprocess.run")
    def test_short_url(self, mock_run):
        mock_run.return_value = subprocess.CompletedProcess([], 0, stdout="short\n", stderr="")
        assert detect_repo() is None


class TestGetPrChecks:
    @patch("gh_wait.github.subprocess.run")
    def test_parses_check_runs(self, mock_run):
        pr_data = json.dumps({"head": {"sha": "abc123"}})
        checks_data = json.dumps(
            {
                "check_runs": [
                    {"name": "Lint", "conclusion": "success", "status": "completed"},
                    {"name": "Test", "conclusion": None, "status": "in_progress"},
                ]
            }
        )
        mock_run.side_effect = [
            subprocess.CompletedProcess([], 0, stdout=pr_data, stderr=""),
            subprocess.CompletedProcess([], 0, stdout=checks_data, stderr=""),
        ]
        checks = get_pr_checks("owner/repo", 1)
        assert len(checks) == 2
        assert checks[0].name == "Lint"
        assert checks[1].conclusion is None

    @patch("gh_wait.github.subprocess.run")
    def test_empty_check_runs(self, mock_run):
        pr_data = json.dumps({"head": {"sha": "abc123"}})
        checks_data = json.dumps({"check_runs": []})
        mock_run.side_effect = [
            subprocess.CompletedProcess([], 0, stdout=pr_data, stderr=""),
            subprocess.CompletedProcess([], 0, stdout=checks_data, stderr=""),
        ]
        checks = get_pr_checks("owner/repo", 1)
        assert len(checks) == 0


class TestGetPrState:
    @patch("gh_wait.github.subprocess.run")
    def test_parses_pr_state(self, mock_run):
        data = json.dumps(
            {
                "mergeable": True,
                "mergeable_state": "clean",
                "state": "open",
                "review_decision": "APPROVED",
            }
        )
        mock_run.return_value = subprocess.CompletedProcess([], 0, stdout=data, stderr="")
        state = get_pr_state("owner/repo", 1)
        assert state.mergeable is True
        assert state.mergeable_state == "clean"
        assert state.review_decision == "APPROVED"

    @patch("gh_wait.github.subprocess.run")
    def test_mergeable_null(self, mock_run):
        data = json.dumps(
            {
                "mergeable": None,
                "mergeable_state": "unknown",
                "state": "open",
                "review_decision": None,
            }
        )
        mock_run.return_value = subprocess.CompletedProcess([], 0, stdout=data, stderr="")
        state = get_pr_state("owner/repo", 1)
        assert state.mergeable is None


class TestGetWorkflowRunJobs:
    @patch("gh_wait.github.subprocess.run")
    def test_parses_jobs(self, mock_run):
        data = json.dumps(
            {
                "jobs": [
                    {"name": "Build", "conclusion": "success", "status": "completed"},
                ]
            }
        )
        mock_run.return_value = subprocess.CompletedProcess([], 0, stdout=data, stderr="")
        jobs = get_workflow_run_jobs("owner/repo", 123)
        assert len(jobs) == 1
        assert jobs[0].name == "Build"
        assert jobs[0].conclusion == "success"

    @patch("gh_wait.github.subprocess.run")
    def test_empty_jobs(self, mock_run):
        data = json.dumps({"jobs": []})
        mock_run.return_value = subprocess.CompletedProcess([], 0, stdout=data, stderr="")
        jobs = get_workflow_run_jobs("owner/repo", 123)
        assert len(jobs) == 0


class TestGetPrReviews:
    @patch("gh_wait.github.subprocess.run")
    def test_returns_reviews(self, mock_run):
        reviews = [{"user": {"login": "alice"}, "state": "APPROVED"}]
        mock_run.return_value = subprocess.CompletedProcess(
            [], 0, stdout=json.dumps(reviews), stderr=""
        )
        result = get_pr_reviews("owner/repo", 1)
        assert len(result) == 1
        assert result[0]["user"]["login"] == "alice"


class TestGetPrReviewComments:
    @patch("gh_wait.github.subprocess.run")
    def test_returns_comments(self, mock_run):
        comments = [{"id": 1, "body": "looks good"}]
        mock_run.return_value = subprocess.CompletedProcess(
            [], 0, stdout=json.dumps(comments), stderr=""
        )
        result = get_pr_review_comments("owner/repo", 1)
        assert len(result) == 1
        assert result[0]["body"] == "looks good"


class TestGetPrCommentBody:
    @patch("gh_wait.github.subprocess.run")
    def test_returns_body(self, mock_run):
        data = {"body": "please fix this"}
        mock_run.return_value = subprocess.CompletedProcess(
            [], 0, stdout=json.dumps(data), stderr=""
        )
        result = get_pr_comment_body("owner/repo", 42)
        assert result == "please fix this"

    @patch("gh_wait.github.subprocess.run")
    def test_missing_body(self, mock_run):
        data = {}
        mock_run.return_value = subprocess.CompletedProcess(
            [], 0, stdout=json.dumps(data), stderr=""
        )
        result = get_pr_comment_body("owner/repo", 42)
        assert result == ""


class TestGetLatestPrNumber:
    @patch("gh_wait.github.subprocess.run")
    def test_returns_number(self, mock_run):
        data = json.dumps([{"number": 42}])
        mock_run.return_value = subprocess.CompletedProcess([], 0, stdout=data, stderr="")
        result = get_latest_pr_number("owner/repo")
        assert result == 42

    @patch("gh_wait.github.subprocess.run")
    def test_exits_when_no_prs(self, mock_run):
        mock_run.return_value = subprocess.CompletedProcess([], 0, stdout="[]", stderr="")
        with pytest.raises(SystemExit):
            get_latest_pr_number("owner/repo")

    @patch("gh_wait.github.subprocess.run")
    def test_with_branch_filter(self, mock_run):
        data = json.dumps([{"number": 7}])
        mock_run.return_value = subprocess.CompletedProcess([], 0, stdout=data, stderr="")
        result = get_latest_pr_number("owner/repo", "feat/x")
        assert result == 7
        cmd = mock_run.call_args[0][0]
        assert "--head" in cmd
        assert "feat/x" in cmd
