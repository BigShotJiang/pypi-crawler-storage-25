"""
Session manager — JSONL-based conversation persistence with in-memory cache.

Sessions are keyed by (channel, sender_id). Each session stores the
conversation history as append-only JSONL for crash safety.
"""

from __future__ import annotations

import json
import re
import uuid
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from loguru import logger

from workpilot.config.schema import ChannelType


class SessionManager:
    """Manages conversation sessions with optional JSONL persistence."""

    def __init__(self, data_dir: Path | None = None) -> None:
        self._data_dir = data_dir
        if self._data_dir:
            self._data_dir.mkdir(parents=True, exist_ok=True)
        self._sessions: dict[str, list[dict[str, Any]]] = {}

    def list_sessions(self) -> list[dict[str, Any]]:
        """List all known sessions with metadata.

        Returns lightweight metadata without loading full message histories.
        Uses file metadata (size) for on-disk sessions and in-memory
        counts for already-loaded sessions.
        """
        results: list[dict[str, Any]] = []

        # In-memory sessions
        seen: set[str] = set()
        for sid, msgs in self._sessions.items():
            if msgs:
                results.append({"session_id": sid, "message_count": len(msgs)})
                seen.add(sid)

        # On-disk sessions not yet loaded — use file stat instead of loading
        # Skip archive files (e.g. cli_local_2026-03-14.jsonl) — they contain
        # a date suffix from session splitting and are not active sessions.
        if self._data_dir and self._data_dir.exists():
            for path in self._data_dir.glob("*.jsonl"):
                sid = path.stem
                # Skip archive files (contain date suffix like _2026-03-14)
                if re.search(r"_\d{4}-\d{2}-\d{2}$", sid):
                    continue
                if sid not in seen:
                    try:
                        stat = path.stat()
                        # Estimate message count from line count without loading
                        line_count = path.read_text(encoding="utf-8").count("\n")
                        results.append(
                            {
                                "session_id": sid,
                                "message_count": line_count,
                                "size_bytes": stat.st_size,
                            }
                        )
                    except (OSError, ValueError):
                        continue

        return results

    def get_or_create_id(self, channel: ChannelType, sender_id: str) -> str:
        """Get a deterministic session ID for a channel+sender pair."""
        key = f"{channel}_{sender_id}"
        return key

    @staticmethod
    def _normalize_id(session_id: str) -> str:
        """Canonical form: colons and slashes become underscores."""
        return session_id.replace(":", "_").replace("/", "_")

    # Roles accepted by LLM APIs — any other roles are UI-only metadata
    _LLM_ROLES: frozenset[str] = frozenset({"user", "assistant", "system", "tool"})

    def get_messages(self, session_id: str, llm_only: bool = False) -> list[dict[str, Any]]:
        """Get conversation history for a session.

        Parameters
        ----------
        llm_only:
            If True, filter out non-LLM roles (e.g. ``approval_request``)
            that are stored for UI purposes but rejected by the LLM API.

        Note: ``_compaction`` audit entries are always filtered out — they
        are metadata for audit only, not conversation messages.
        """
        session_id = self._normalize_id(session_id)
        if session_id not in self._sessions:
            self._sessions[session_id] = self._load_from_disk(session_id)
        msgs = self._sessions[session_id]
        # Filter out _compaction audit entries (always)
        msgs_filtered = [m for m in msgs if "_compaction" not in m]
        if llm_only:
            return [
                m
                for m in msgs_filtered
                if m.get("role") in self._LLM_ROLES and not m.get("is_error")
            ]
        return msgs_filtered

    def add_message(self, session_id: str, message: dict[str, Any]) -> None:
        """Append a message to the session history.

        Injects ``_ts`` (ISO 8601 UTC timestamp) into the message dict
        before appending, unless the message already has one (e.g. audit
        entries that set their own timestamp).
        """
        session_id = self._normalize_id(session_id)
        if "_ts" not in message:
            message["_ts"] = datetime.now(UTC).isoformat()
        if session_id not in self._sessions:
            self._sessions[session_id] = self._load_from_disk(session_id)
        self._sessions[session_id].append(message)
        self._persist(session_id, message)

    def clear(self, session_id: str) -> None:
        """Clear a session's history and metadata.

        Session JSONL files are archived (renamed with timestamp), not deleted,
        so they remain available for history indexing and audit.
        """
        session_id = self._normalize_id(session_id)
        self._sessions[session_id] = []
        if self._data_dir:
            ts = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
            archive_dir = self._data_dir / "archive"
            created = False
            path = self._session_path(session_id)
            if path.exists():
                if not created:
                    archive_dir.mkdir(parents=True, exist_ok=True)
                    created = True
                path.rename(archive_dir / f"{path.stem}_{ts}{path.suffix}")
            meta = self._meta_path(session_id)
            if meta and meta.exists():
                if not created:
                    archive_dir.mkdir(parents=True, exist_ok=True)
                    created = True
                # Archive as {session_id}_{ts}.meta.json (matches delete glob)
                meta.rename(archive_dir / f"{session_id}_{ts}.meta.json")
            # Archive split files (date-suffixed), but NOT fork sessions
            for split in self._data_dir.glob(f"{session_id}_*.jsonl"):
                if "_fork_" in split.stem:
                    continue
                if not created:
                    archive_dir.mkdir(parents=True, exist_ok=True)
                    created = True
                split.rename(archive_dir / f"{split.stem}_{ts}{split.suffix}")

    def delete(self, session_id: str) -> None:
        """Permanently delete a session's files, metadata, and archived copies."""
        session_id = self._normalize_id(session_id)
        self._sessions.pop(session_id, None)
        if self._data_dir:
            path = self._session_path(session_id)
            if path.exists():
                path.unlink()
            meta = self._meta_path(session_id)
            if meta and meta.exists():
                meta.unlink()
            for split in self._data_dir.glob(f"{session_id}_*.jsonl"):
                if "_fork_" in split.stem:
                    continue
                split.unlink()
            # Also remove archived copies from clear()
            archive_dir = self._data_dir / "archive"
            if archive_dir.exists():
                for f in archive_dir.glob(f"{session_id}_*.jsonl"):
                    f.unlink()
                for f in archive_dir.glob(f"{session_id}_*.meta.json"):
                    f.unlink()

    def trim(self, session_id: str, keep_last: int) -> list[dict[str, Any]]:
        """Trim session to keep only the last N messages **in memory**.

        Returns the trimmed (removed) messages for memory consolidation.
        The disk JSONL file is **not** rewritten — it stays append-only.

        The split point is adjusted so tool-call groups (assistant with
        tool_calls + tool results) are never broken apart.
        """
        session_id = self._normalize_id(session_id)
        if session_id not in self._sessions:
            self._sessions[session_id] = self._load_from_disk(session_id)
        # Operate on the raw in-memory list directly (not the filtered
        # copy from get_messages()) to preserve _compaction audit entries
        # and avoid creating a disconnected copy.
        messages = self._sessions[session_id]
        if len(messages) <= keep_last:
            return []

        # Find safe split point that doesn't break tool-call groups
        idx = len(messages) - keep_last
        while idx > 0 and messages[idx].get("role") == "tool":
            idx -= 1

        trimmed = messages[:idx]
        self._sessions[session_id] = messages[idx:]

        # NOTE: no JSONL rewrite — disk stays append-only.
        # Consolidation uses _ts position tracking via meta.json instead.

        return trimmed

    def replace_messages(self, session_id: str, messages: list[dict[str, Any]]) -> None:
        """Replace in-memory session history without rewriting disk.

        Used after compaction to update the working set while keeping the
        append-only JSONL intact for consolidation.
        """
        session_id = self._normalize_id(session_id)
        self._sessions[session_id] = messages

    def fork(self, session_id: str) -> str:
        """Create a linked empty branch for sub-agents.

        The forked session has empty history but is linked to the parent
        for tracking purposes.
        """
        session_id = self._normalize_id(session_id)
        fork_id = f"{session_id}_fork_{uuid.uuid4().hex[:8]}"
        self._sessions[fork_id] = []
        return fork_id

    def is_loaded(self, session_id: str) -> bool:
        """Check if session is already in memory."""
        return self._normalize_id(session_id) in self._sessions

    def smart_load_session(
        self,
        session_id: str,
        context_limit: int,
    ) -> list[dict[str, Any]]:
        """Load a smart tail from the active JSONL file.

        Instead of loading the full history, loads:
        - Phase 1: last 5 user turns with full tool context
        - Phase 2: +10 user turns with tool content replaced by placeholder
        - Token check: trim oldest if > 50% context_limit

        Archive files are NOT loaded — only the active session file.
        See compaction.md §9.8.
        """
        session_id = self._normalize_id(session_id)
        all_msgs = self._load_from_disk(session_id)
        if not all_msgs:
            self._sessions[session_id] = []
            return []

        # Filter out _compaction audit entries
        msgs = [m for m in all_msgs if "_compaction" not in m]

        # Find user turn positions
        user_indices: list[int] = [i for i, m in enumerate(msgs) if m.get("role") == "user"]

        if len(user_indices) <= 5:
            # Short session — keep everything as-is
            self._sessions[session_id] = msgs
            return msgs

        # Phase 1 boundary: 5th-from-last user turn
        phase1_start = user_indices[-5]
        # Phase 2 boundary: 15th-from-last user turn (or beginning)
        phase2_start = user_indices[-15] if len(user_indices) >= 15 else 0

        # Build result: Phase 2 (placeholders) + Phase 1 (full)
        result: list[dict[str, Any]] = []

        for i in range(phase2_start, len(msgs)):
            msg = msgs[i]
            if i >= phase1_start:
                # Phase 1: keep full content
                result.append(msg)
            else:
                # Phase 2: keep user + assistant intact, replace tool content
                if msg.get("role") == "tool" and msg.get("content"):
                    if msg["content"].startswith("[tool result cleared:"):
                        result.append(msg)  # Already a placeholder
                    else:
                        # Build placeholder with status/preview
                        from workpilot.agent.compaction import _build_tool_placeholder

                        content = msg["content"]
                        is_error = msg.get("is_error", False) or content.startswith(
                            ("Error", "BLOCKED")
                        )
                        tool_name = self._resolve_tool_name(msgs, i)
                        placeholder = _build_tool_placeholder(tool_name, content, is_error=is_error)
                        result.append({**msg, "content": placeholder})
                else:
                    result.append(msg)

        # Token check: trim oldest if > 50% context_limit
        from workpilot.agent.compaction import estimate_tokens

        half_limit = context_limit // 2
        while estimate_tokens(result) > half_limit and len(result) > 10:
            # Skip past tool-call group at the start
            if result and result[0].get("role") == "tool":
                result.pop(0)
            else:
                result.pop(0)

        # Ensure we don't start on a tool message (broken group)
        while result and result[0].get("role") == "tool":
            result.pop(0)

        self._sessions[session_id] = result
        logger.info(
            "Smart loaded session {}: {} of {} messages (phase2 from {}, phase1 from {})",
            session_id,
            len(result),
            len(msgs),
            phase2_start,
            phase1_start,
        )
        return result

    @staticmethod
    def _resolve_tool_name(msgs: list[dict[str, Any]], tool_idx: int) -> str:
        """Look backward from a tool message to find its name from assistant tool_calls."""
        tc_id = msgs[tool_idx].get("tool_call_id", "")
        for j in range(tool_idx - 1, -1, -1):
            if msgs[j].get("role") == "assistant":
                for tc in msgs[j].get("tool_calls", []):
                    if tc.get("id") == tc_id:
                        return str(tc.get("function", {}).get("name", "?"))
                break
        return "?"

    def generate_id(self) -> str:
        return str(uuid.uuid4())

    # ── Meta sidecar ────────────────────────────────────────────────────

    def _meta_path(self, session_id: str) -> Path | None:
        """Return the path to the meta.json sidecar file."""
        if not self._data_dir:
            return None
        safe_id = self._normalize_id(session_id)
        return self._data_dir / f"{safe_id}.meta.json"

    def read_meta(self, session_id: str) -> dict[str, Any]:
        """Read session metadata from the sidecar file."""
        path = self._meta_path(session_id)
        if not path or not path.exists():
            return {}
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else {}
        except (json.JSONDecodeError, OSError):
            return {}

    def update_meta(self, session_id: str, **fields: Any) -> None:
        """Merge fields into the session metadata sidecar."""
        path = self._meta_path(session_id)
        if not path:
            return
        meta = self.read_meta(session_id)
        meta.update(fields)
        path.write_text(json.dumps(meta, default=str, ensure_ascii=False), encoding="utf-8")

    # ── Disk readers ────────────────────────────────────────────────────

    def load_disk_messages(
        self,
        session_id: str,
        *,
        after_ts: str | None = None,
    ) -> list[dict[str, Any]]:
        """Read messages from the session JSONL on disk.

        Optionally filters to messages with ``_ts > after_ts``.
        Always skips ``_compaction`` audit entries.
        """
        session_id = self._normalize_id(session_id)
        if not self._data_dir:
            return []
        path = self._session_path(session_id)
        if not path.exists():
            return []

        messages: list[dict[str, Any]] = []
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                msg = json.loads(line)
            except json.JSONDecodeError:
                continue
            # Skip audit entries
            if "_compaction" in msg:
                continue
            # Filter by timestamp
            if after_ts and msg.get("_ts", "") <= after_ts:
                continue
            messages.append(msg)
        return messages

    # ── Session file splitting ──────────────────────────────────────────

    _SPLIT_SIZE_BYTES = 32 * 1024 * 1024  # 32 MB

    def maybe_split_session(self, session_id: str) -> bool:
        """Split session JSONL at >32 MB using dual threshold (2-day / 50-msg).

        Returns True if a split occurred.
        """
        session_id = self._normalize_id(session_id)
        if not self._data_dir:
            return False
        path = self._session_path(session_id)
        if not path.exists():
            return False
        try:
            file_size = path.stat().st_size
        except OSError:
            return False
        if file_size <= self._SPLIT_SIZE_BYTES:
            return False

        # Read all messages from disk
        all_msgs: list[dict[str, Any]] = []
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line:
                try:
                    all_msgs.append(json.loads(line))
                except json.JSONDecodeError:
                    continue

        if len(all_msgs) <= 50:
            return False

        now = datetime.now(UTC)
        two_days_ago = now.timestamp() - (2 * 86400)

        # Find 2-day boundary: archive messages ≥2 days old
        day_split = 0
        for i, msg in enumerate(all_msgs):
            ts_str = msg.get("_ts", "")
            if ts_str:
                try:
                    msg_time = datetime.fromisoformat(ts_str).timestamp()
                    if msg_time < two_days_ago:
                        day_split = i + 1
                    else:
                        break
                except (ValueError, TypeError):
                    continue

        # 50-message boundary: keep last 50 messages
        msg_split = max(0, len(all_msgs) - 50)

        # Use whichever keeps more (retain at least 50 msgs AND at least 2 days)
        split_idx = (
            min(day_split, msg_split) if day_split and msg_split else max(day_split, msg_split)
        )
        if split_idx <= 0:
            return False

        archive_msgs = all_msgs[:split_idx]
        keep_msgs = all_msgs[split_idx:]

        # Name archive by the last message date in archived portion
        last_ts = archive_msgs[-1].get("_ts", "")
        if last_ts:
            try:
                last_date = datetime.fromisoformat(last_ts).strftime("%Y-%m-%d")
            except (ValueError, TypeError):
                last_date = now.strftime("%Y-%m-%d")
        else:
            last_date = now.strftime("%Y-%m-%d")

        archive_path = self._data_dir / f"{self._normalize_id(session_id)}_{last_date}.jsonl"

        # Write archive (append if exists)
        with archive_path.open("a", encoding="utf-8") as f:
            for msg in archive_msgs:
                f.write(json.dumps(msg, default=str, ensure_ascii=False) + "\n")

        # Rewrite active file with kept messages only
        with path.open("w", encoding="utf-8") as f:
            for msg in keep_msgs:
                f.write(json.dumps(msg, default=str, ensure_ascii=False) + "\n")

        # Update in-memory cache
        self._sessions[self._normalize_id(session_id)] = keep_msgs

        logger.info(
            "Session split: {} archived {} messages, kept {}",
            session_id,
            len(archive_msgs),
            len(keep_msgs),
        )
        return True

    # ── Internal ────────────────────────────────────────────────────────

    def _session_path(self, session_id: str) -> Path:
        safe_id = self._normalize_id(session_id)
        return self._data_dir / f"{safe_id}.jsonl" if self._data_dir else Path("/dev/null")

    def _load_from_disk(self, session_id: str) -> list[dict[str, Any]]:
        if not self._data_dir:
            return []
        path = self._session_path(session_id)
        if not path.exists():
            return []
        messages: list[dict[str, Any]] = []
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line:
                try:
                    messages.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
        return messages

    def _persist(self, session_id: str, message: dict[str, Any]) -> None:
        if not self._data_dir:
            return
        path = self._session_path(session_id)
        with path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(message, default=str, ensure_ascii=False) + "\n")
