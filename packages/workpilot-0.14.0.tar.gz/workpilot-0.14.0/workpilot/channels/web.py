"""
Web channel — HTTP/SSE/WebSocket channel via self-hosted web server.

Routes messages through the message bus using per-request asyncio.Queue
for bridging synchronous HTTP request-response with async bus messaging.
"""

from __future__ import annotations

import asyncio
import uuid
from typing import Any

from loguru import logger

from workpilot.bus.events import EventType, StreamingChunk
from workpilot.bus.queue import MessageBus
from workpilot.channels.base import BaseChannel
from workpilot.config.schema import ChannelType


class WebChannel(BaseChannel):
    """HTTP/SSE/WebSocket channel via self-hosted web server."""

    def __init__(self, bus: MessageBus, allow_from: list[str] | None = None) -> None:
        super().__init__(bus, allow_from)
        # Per-request response routing: channel_id -> asyncio.Queue[str | None]
        self._response_queues: dict[str, asyncio.Queue[str | None]] = {}
        # Per-request streaming routing: channel_id -> asyncio.Queue[StreamingChunk | None]
        self._stream_queues: dict[str, asyncio.Queue[StreamingChunk | None]] = {}
        # Push notification queues for connected WebSocket clients (scheduler/background jobs)
        self._push_queues: dict[str, asyncio.Queue[str | None]] = {}
        self._running = False

    @property
    def name(self) -> str:
        return ChannelType.WEB

    @property
    def is_connected(self) -> bool:
        """True when at least one WebSocket client is connected."""
        return bool(self._push_queues)

    async def start(self) -> None:
        self._running = True
        logger.info("Web channel started")

    async def stop(self) -> None:
        self._running = False
        # Signal all waiting queues to terminate
        for rq in self._response_queues.values():
            try:
                rq.put_nowait(None)
            except asyncio.QueueFull:
                pass
        for sq in self._stream_queues.values():
            try:
                sq.put_nowait(None)
            except asyncio.QueueFull:
                pass
        for pq in self._push_queues.values():
            try:
                pq.put_nowait(None)
            except asyncio.QueueFull:
                pass
        self._response_queues.clear()
        self._stream_queues.clear()
        self._push_queues.clear()
        logger.info("Web channel stopped")

    async def send(self, channel_id: str, content: str, **kwargs: Any) -> None:
        """Route outbound messages to the correct per-request queue.

        If no request queue matches (e.g. scheduler notifications), broadcast
        to all connected push subscribers (WebSocket clients).
        """
        q = self._response_queues.get(channel_id)
        if q is not None:
            try:
                q.put_nowait(content)
            except asyncio.QueueFull:
                logger.warning(f"Response queue full for {channel_id}")
        elif self._push_queues:
            # Broadcast notifications (scheduler, notify tool, background tasks) to WS clients
            for pid, pq in list(self._push_queues.items()):
                try:
                    pq.put_nowait(content)
                except asyncio.QueueFull:
                    logger.warning(f"Push queue full for {pid}")
        else:
            logger.warning(
                f"Response dropped: no queue for channel_id={channel_id} (request may have timed out)"
            )

    async def send_streaming(self, channel_id: str, chunk: StreamingChunk) -> None:
        """Route streaming chunks to the correct per-request queue."""
        q = self._stream_queues.get(channel_id)
        if q is not None:
            try:
                q.put_nowait(chunk)
            except asyncio.QueueFull:
                logger.warning(f"Stream queue full for {channel_id}")

    def register_request(self, channel_id: str) -> asyncio.Queue[str | None]:
        """Register a per-request response queue. Returns the queue to await."""
        q: asyncio.Queue[str | None] = asyncio.Queue(maxsize=1)
        self._response_queues[channel_id] = q
        return q

    def unregister_request(self, channel_id: str) -> None:
        """Clean up queues after request completes."""
        self._response_queues.pop(channel_id, None)
        self._stream_queues.pop(channel_id, None)

    def register_stream(self, channel_id: str) -> asyncio.Queue[StreamingChunk | None]:
        """Register a streaming queue for SSE/WS. Returns queue to iterate."""
        q: asyncio.Queue[StreamingChunk | None] = asyncio.Queue(maxsize=100)
        self._stream_queues[channel_id] = q
        return q

    def register_push(self, connection_id: str) -> asyncio.Queue[str | None]:
        """Register a push notification queue for a persistent connection (WebSocket).

        Push queues receive unsolicited messages (scheduler notifications,
        background job results) that don't match any per-request queue.
        """
        was_empty = not self._push_queues
        q: asyncio.Queue[str | None] = asyncio.Queue(maxsize=50)
        self._push_queues[connection_id] = q
        # First WebSocket client → channel is now connected
        if was_empty:
            self._bus.events.emit(EventType.CHANNEL_CONNECTED, {"channel": self.name})
        return q

    def unregister_push(self, connection_id: str) -> None:
        """Remove a push notification queue when a connection closes."""
        self._push_queues.pop(connection_id, None)

    @staticmethod
    def make_channel_id(prefix: str = "web-req") -> str:
        """Generate a unique channel_id for a request."""
        return f"{prefix}-{uuid.uuid4().hex[:12]}"

    async def submit_and_wait(
        self,
        *,
        channel_id: str,
        sender_id: str,
        content: str,
        timeout: float = 300,
    ) -> str:
        """Submit a message through the bus and wait for the response.

        Creates a response queue, publishes via _handle_message, and awaits
        the agent's response with a timeout.
        """
        response_queue = self.register_request(channel_id)
        try:
            await self._handle_message(
                channel_id=channel_id,
                sender_id=sender_id,
                sender_name=sender_id,
                content=content,
            )
            result = await asyncio.wait_for(response_queue.get(), timeout=timeout)
            if result is None:
                raise TimeoutError("Channel shutting down")
            return result
        finally:
            self.unregister_request(channel_id)
