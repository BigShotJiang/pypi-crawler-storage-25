"""MCP auth — Agency CLI detection, auth status check, HTTP auth resolution."""

from __future__ import annotations

import os
import shutil
from typing import TYPE_CHECKING

import httpx
from loguru import logger

if TYPE_CHECKING:
    from workpilot.config.schema import MCPAuthConfig, MCPServerConfig, ProvidersConfig


async def pre_connect_agency_check() -> tuple[bool, str]:
    """Check Agency CLI availability.

    Returns (ok, message). Called automatically when connecting
    any server where ``config.is_agency`` is True.

    Note: Agency CLI does not expose an auth status subcommand.
    EntraID auth is handled interactively by Agency when the MCP
    server is first used.
    """
    agency_bin = shutil.which("agency")
    if not agency_bin:
        return False, (
            "Agency CLI not found. Install via:\n"
            "  workpilot mcp add-agency\n"
            'Or manually: iex "& { $(irm aka.ms/InstallTool.ps1)} agency"'
        )
    return True, f"Agency CLI found: {agency_bin}"


async def resolve_auth_headers(
    config: MCPServerConfig,
    providers: ProvidersConfig | None = None,
) -> dict[str, str]:
    """Resolve auth headers for HTTP transport.

    Stdio servers (including Agency) handle auth internally — returns empty dict.

    For ``auth.type: "none"``, checks secret store / env / ``gh auth token``
    as implicit bearer (zero-config GitHub MCP support).  If no token is found,
    returns empty dict so the caller can fall back to OAuth auto-discovery.

    Args:
        config: MCP server config.
        providers: Provider config (unused, kept for API compatibility).

    Returns:
        Dict of HTTP headers to pass to the transport.
    """
    # Stdio transport — auth handled by subprocess
    if config.command is not None:
        return {}

    match config.auth.type:
        case "none":
            # Try stored or CLI token as implicit bearer (zero-config GitHub MCP).
            token = _resolve_implicit_token()
            if token:
                return {"Authorization": f"Bearer {token}"}
            return {}
        case "bearer":
            token = _resolve_bearer_token(config.auth)
            if token:
                return {"Authorization": f"Bearer {token}"}
            logger.warning("MCP auth: bearer token not found (check token or token_env)")
            return {}
        case "oauth":
            token = await _oauth_client_credentials(config.auth)
            if token:
                return {"Authorization": f"Bearer {token}"}
            logger.warning("MCP auth: OAuth token exchange failed")
            return {}
        case _:
            logger.warning(f"MCP auth: unknown type '{config.auth.type}'")
            return {}


def _resolve_bearer_token(auth: MCPAuthConfig) -> str | None:
    """Resolve bearer token from config, secret store, or environment.

    Priority: config token → SecretStore(token_env) → env var(token_env).
    Does NOT fall back to gh CLI — that's handled by ``_resolve_implicit_token``
    for ``type: "none"``.
    """
    if auth.token is not None:
        val = auth.token.get_secret_value()
        if val and not val.startswith("SECRET["):
            return val
    if auth.token_env:
        # SecretStore first (consistent with providers/resolver.py)
        try:
            from workpilot.security.secrets import get_secret_store

            value = get_secret_store().get(auth.token_env)
            if value:
                return value
        except Exception as exc:
            from loguru import logger

            logger.debug("Secret store unavailable for MCP token, falling back to env: {}", exc)
        # Then env var
        value = os.environ.get(auth.token_env)
        if value:
            return value
    return None


def _resolve_gh_cli_token() -> str | None:
    """Get token from GitHub CLI (``gh auth token``)."""
    import subprocess

    try:
        result = subprocess.run(
            ["gh", "auth", "token"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            token = result.stdout.strip()
            if token:
                logger.debug("MCP GitHub token resolved from 'gh auth token'")
                return token
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass
    return None


def _resolve_implicit_token() -> str | None:
    """Resolve a GitHub token from secret store, env, or gh CLI.

    Used for ``auth.type: "none"`` to provide zero-config GitHub MCP support.
    Checks secret store first (where device code login persists tokens),
    then environment, then ``gh auth token``.
    """
    # 1. Secret store (device code login stores GITHUB_TOKEN here)
    try:
        from workpilot.security.secrets import get_secret_store

        val = get_secret_store().get("GITHUB_TOKEN")
        if val:
            logger.debug("Implicit token resolved from secret store")
            return val
    except Exception:
        pass
    # 2. Environment variable
    val = os.environ.get("GITHUB_TOKEN")
    if val:
        return val
    # 3. gh auth token
    return _resolve_gh_cli_token()


# GitHub CLI's public OAuth App client ID (https://github.com/cli/cli)
_GH_CLI_CLIENT_ID = "178c6fc778ccc68e1d6a"
# Scopes matching `gh auth login` defaults — needed for GitHub MCP (repos, PRs, etc.)
_GH_MCP_SCOPE = "repo read:org gist workflow"


async def _oauth_client_credentials(auth: MCPAuthConfig) -> str | None:
    """Exchange client credentials for an OAuth2 access token.

    Uses the standard OAuth2 client_credentials grant type.
    Requires ``client_id``, ``client_secret``, and at least one scope.
    Token endpoint is always ``https://login.microsoftonline.com/common/oauth2/v2.0/token``.
    """
    if not auth.client_id or not auth.client_secret:
        logger.warning("MCP OAuth: client_id and client_secret are required")
        return None

    scopes = auth.scopes or []
    scope_str = " ".join(scopes) if scopes else ""

    # Default Azure AD token endpoint (common tenant)
    token_url = "https://login.microsoftonline.com/common/oauth2/v2.0/token"

    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                token_url,
                data={
                    "grant_type": "client_credentials",
                    "client_id": auth.client_id,
                    "client_secret": auth.client_secret.get_secret_value(),
                    "scope": scope_str,
                },
            )
            response.raise_for_status()
            data = response.json()
            access_token: str | None = data.get("access_token")
            if access_token:
                logger.debug("MCP OAuth: token obtained successfully")
            return access_token
    except httpx.HTTPError as exc:
        logger.warning(f"MCP OAuth token exchange failed: {exc}")
        return None
    except Exception as exc:
        logger.warning(f"MCP OAuth unexpected error: {exc}")
        return None
