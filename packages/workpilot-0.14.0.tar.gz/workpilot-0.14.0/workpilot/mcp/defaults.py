"""Default descriptions for well-known MCP servers."""

# Curated descriptions for Agency MCP servers.
# Used as runtime fallback when config has no explicit description.
AGENCY_DESCRIPTIONS: dict[str, str] = {
    "ado": "work items, repos, pipelines, PRs, wiki (read + write)",
    "enghub": "docs, TSGs, ServiceTree search",
    "kusto": "KQL queries, schema discovery, data ingestion",
    "bluebird": "semantic code search, PRs, work items, wiki in ADO repos",
    "icm": "query incidents, on-call schedules, customer impact analysis",
    "security-context": "security posture, threat analysis, penetration testing",
    "es-chat": "engineering knowledge Q&A across eng.ms, ADO Wiki, OneDoc",
    "workiq": "query Microsoft 365 Copilot data, emails, docs, meetings",
    "teams": "send messages, search chats, manage channels",
    "mail": "read, compose, send, forward Outlook emails with attachments",
    "calendar": "view, create, manage Outlook calendar events",
    "s360-breeze": "S360 KPI health, action items, compliance insights",
    "cloudbuild": "build analysis, queue health, error diagnosis, KQL queries",
    "sharepoint": "files, folders, sharing in SharePoint and OneDrive",
    "word": "create Word documents, add comments in OneDrive",
}


def get_default_description(name: str, *, is_agency: bool = False) -> str | None:
    """Return the preset description for a known agency server, or None."""
    if is_agency:
        return AGENCY_DESCRIPTIONS.get(name)
    return None
