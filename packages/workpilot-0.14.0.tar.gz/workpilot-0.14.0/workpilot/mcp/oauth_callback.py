"""OAuth callback server and browser redirect handlers for MCP authorization code flow.

Provides :func:`create_oauth_handlers` which returns the ``redirect_handler`` and
``callback_handler`` callables required by the MCP SDK's
:class:`~mcp.client.auth.OAuthClientProvider`.
"""

from __future__ import annotations

import asyncio
import socket
import threading
import webbrowser
from collections.abc import Awaitable, Callable
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs, urlparse

from loguru import logger

# HTML returned to the browser after a successful callback.
_SUCCESS_HTML = b"""\
<!DOCTYPE html>
<html><head><title>WorkPilot</title></head>
<body style="font-family:system-ui;text-align:center;padding:4em">
<h2>Authorization complete</h2>
<p>You may close this tab and return to WorkPilot.</p>
</body></html>
"""


def create_oauth_handlers(
    port: int = 0,
) -> tuple[
    Callable[[str], Awaitable[None]],
    Callable[[], Awaitable[tuple[str, str | None]]],
    int,
]:
    """Create redirect + callback handlers for the OAuth authorization code flow.

    Args:
        port: Fixed localhost port for the callback server.  ``0`` (default)
              lets the OS pick a free port.

    Returns:
        ``(redirect_handler, callback_handler, actual_port)`` — the first two
        are async callables matching the MCP SDK's ``OAuthClientProvider``
        constructor signature; the third is the bound port for building
        ``redirect_uris``.
    """
    # Probe for an available port, then release immediately.  The socket is
    # only re-bound when callback_handler() is actually called (on 401).
    # This avoids holding a port/FD for servers that never need OAuth.
    info = socket.getaddrinfo(
        "localhost", port, socket.AF_UNSPEC, socket.SOCK_STREAM, 0, socket.AI_PASSIVE
    )
    family = info[0][0] if info else socket.AF_INET
    addr = "::1" if family == socket.AF_INET6 else "127.0.0.1"
    probe = socket.socket(family, socket.SOCK_STREAM)
    probe.bind((addr, port))
    actual_port: int = probe.getsockname()[1]
    probe.close()

    # Shared state between the HTTP handler thread and the async caller.
    _result_future: asyncio.Future[tuple[str | None, str | None]] | None = None
    _loop: asyncio.AbstractEventLoop | None = None

    class _CallbackHandler(BaseHTTPRequestHandler):
        """Handles a single ``GET /callback?code=…&state=…``."""

        def do_GET(self) -> None:  # noqa: N802 (HTTP method convention)
            parsed = urlparse(self.path)
            if parsed.path not in ("/", "/callback"):
                self.send_response(404)
                self.end_headers()
                return

            params = parse_qs(parsed.query)
            code = params.get("code", [None])[0]  # type: ignore[arg-type]
            state = params.get("state", [None])[0]  # type: ignore[arg-type]

            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(_SUCCESS_HTML)

            if _loop is not None and _result_future is not None and not _result_future.done():
                result: tuple[str | None, str | None] = (code, state)
                _loop.call_soon_threadsafe(_result_future.set_result, result)

        def log_message(self, format: str, *args: object) -> None:  # noqa: A002
            pass  # suppress HTTP server logs

    # -- handlers --------------------------------------------------------------

    async def redirect_handler(authorization_url: str) -> None:
        """Open the system browser for user authorization."""
        try:
            opened = webbrowser.open(authorization_url)
            if opened:
                logger.debug("Opened browser for OAuth authorization")
                return
        except Exception:
            pass
        # Headless / SSH / browser failed — print URL for manual copy-paste.
        logger.info("Open this URL to authorize:\n  {}", authorization_url)

    async def callback_handler() -> tuple[str, str | None]:
        """Start the localhost callback server and wait for the auth code."""
        nonlocal _result_future, _loop
        _loop = asyncio.get_running_loop()
        _result_future = _loop.create_future()

        # Bind now (deferred from factory creation to avoid holding a port).
        server_socket = socket.socket(family, socket.SOCK_STREAM)
        server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server_socket.bind((addr, actual_port))
        server_socket.listen(5)

        server = HTTPServer(("localhost", 0), _CallbackHandler, bind_and_activate=False)
        server.socket = server_socket

        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()

        try:
            code, state = await asyncio.wait_for(_result_future, timeout=300)
            if code is None:
                raise RuntimeError("OAuth callback did not contain an authorization code")
            return code, state
        except TimeoutError:
            raise RuntimeError(
                "OAuth callback timed out (300 s). "
                "Please complete authorization in the browser and try again."
            ) from None
        finally:
            server.shutdown()
            server.server_close()
            server_socket.close()
            thread.join(timeout=5)

    return redirect_handler, callback_handler, actual_port
