"""MCP OAuth provider factory — creates httpx.Auth instances for MCP servers.

Wraps the MCP Python SDK's :class:`~mcp.client.auth.OAuthClientProvider` and
:class:`~mcp.client.auth.extensions.client_credentials.ClientCredentialsOAuthProvider`
to provide:

* **Auto-discovery** — HTTP servers with ``auth.type: "none"`` get a passive
  ``OAuthClientProvider`` that activates only when a 401 is received.
* **Explicit OAuth** — servers with ``auth.type: "oauth"`` get a fully
  configured provider (authorization-code or client-credentials).

Token persistence uses :class:`~workpilot.mcp.oauth_storage.MCPTokenStorage`
(OS keyring via WorkPilot secret store, with encrypted-file overflow).
"""

from __future__ import annotations

import warnings
from typing import TYPE_CHECKING

import httpx
from loguru import logger

if TYPE_CHECKING:
    from workpilot.config.schema import MCPServerConfig, ProvidersConfig


async def create_oauth_auth(
    server_name: str,
    config: MCPServerConfig,
    providers: ProvidersConfig | None = None,
) -> httpx.Auth | None:
    """Create an :class:`httpx.Auth` for an MCP server's OAuth requirements.

    Returns ``None`` when static headers should be used instead (``bearer``
    or stdio transports).
    """
    if config.auth.type == "bearer":
        return None
    if config.url is None:
        return None

    if config.auth.type == "oauth":
        grant = _resolve_grant_type(config)
        if grant == "client_credentials":
            return _create_client_credentials(server_name, config)

    # authorization_code (explicit or auto-discovery for type=="none")
    return await _create_authorization_code(server_name, config)


def _resolve_grant_type(config: MCPServerConfig) -> str:
    """Determine effective grant type with backward-compatibility handling."""
    auth = config.auth
    if auth.grant_type is not None:
        return auth.grant_type
    if auth.client_secret is not None:
        warnings.warn(
            "MCPAuthConfig: 'oauth' with client_secret but no explicit grant_type. "
            "Defaulting to 'client_credentials' for backward compatibility. "
            "Please set grant_type explicitly.",
            FutureWarning,
            stacklevel=3,
        )
        return "client_credentials"
    return "authorization_code"


async def _create_authorization_code(
    server_name: str,
    config: MCPServerConfig,
) -> httpx.Auth:
    """Authorization Code + PKCE provider.

    Handles both explicit ``auth.type: "oauth"`` and passive auto-discovery
    (``auth.type: "none"`` + HTTP).  With default config values the provider
    is a no-op until a 401 is received.
    """
    from mcp.client.auth import OAuthClientProvider
    from mcp.shared.auth import OAuthClientInformationFull, OAuthClientMetadata
    from pydantic import AnyUrl

    from workpilot.mcp.oauth_callback import create_oauth_handlers
    from workpilot.mcp.oauth_storage import MCPTokenStorage

    auth = config.auth
    storage = MCPTokenStorage(server_name)
    redirect_handler, callback_handler, port = create_oauth_handlers(auth.callback_port or 0)
    # Use "localhost" (matches VS Code app registration) with "/" path.
    redirect_uri = AnyUrl(f"http://localhost:{port}/")

    client_metadata = OAuthClientMetadata(
        redirect_uris=[redirect_uri],
        client_name="WorkPilot",
        grant_types=["authorization_code", "refresh_token"],
        response_types=["code"],
        token_endpoint_auth_method="client_secret_post" if auth.client_secret else "none",
        scope=" ".join(auth.scopes) if auth.scopes else None,
    )

    # Always write client_info — redirect_uris change with each random port.
    if auth.client_id:
        await storage.set_client_info(
            OAuthClientInformationFull(
                client_id=auth.client_id,
                client_secret=(
                    auth.client_secret.get_secret_value() if auth.client_secret else None
                ),
                redirect_uris=client_metadata.redirect_uris,
                client_name="WorkPilot",
                grant_types=client_metadata.grant_types,
                response_types=client_metadata.response_types,
                token_endpoint_auth_method=client_metadata.token_endpoint_auth_method,
            )
        )

    logger.debug("MCP OAuth: authorization_code provider for '{}'", server_name)
    provider = OAuthClientProvider(
        server_url=config.url,  # type: ignore[arg-type]  # checked at entry
        client_metadata=client_metadata,
        storage=storage,
        redirect_handler=redirect_handler,
        callback_handler=callback_handler,
    )
    if auth.auth_server_url:
        provider.context.auth_server_url = auth.auth_server_url
    return provider


def _create_client_credentials(
    server_name: str,
    config: MCPServerConfig,
) -> httpx.Auth:
    """Client Credentials grant (M2M)."""
    from mcp.client.auth.extensions.client_credentials import ClientCredentialsOAuthProvider

    from workpilot.mcp.oauth_storage import MCPTokenStorage

    auth = config.auth
    if not auth.client_id or not auth.client_secret:
        raise RuntimeError(
            f"MCP server '{server_name}': client_credentials grant requires "
            "both client_id and client_secret"
        )

    logger.debug("MCP OAuth: client_credentials provider for '{}'", server_name)
    return ClientCredentialsOAuthProvider(
        server_url=config.url,  # type: ignore[arg-type]  # checked at entry
        storage=MCPTokenStorage(server_name),
        client_id=auth.client_id,
        client_secret=auth.client_secret.get_secret_value(),
        scopes=" ".join(auth.scopes) if auth.scopes else None,
    )
