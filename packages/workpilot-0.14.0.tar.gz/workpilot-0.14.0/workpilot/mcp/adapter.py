"""
MCP tool adapter — wraps external MCP tool descriptors as Tool ABC instances.

Each MCPToolAdapter adapts an MCP tool descriptor (from ``MCPClient.list_tools()``)
into a ``Tool`` that can be registered in the agent's ``ToolRegistry`` and used
by the LLM for function calling.

MCP tools are untrusted by default — ``assess_risk()`` returns ``RiskPrompt``
with the tool description so the LLM scorer can evaluate.
"""

from __future__ import annotations

import asyncio
import re
from collections.abc import AsyncGenerator
from typing import Any

from loguru import logger

from workpilot.agent.tools.base import Tool, ToolMetadata
from workpilot.agent.tools.registry import PROTECTED_TOOLS, ToolRegistry
from workpilot.mcp.client import MCPClient
from workpilot.security.risk import RiskAssessment, RiskPrompt, RiskScore

# ── Config-driven rule engine ─────────────────────────────────────────────────


def _match_rules(
    rules: list[dict[str, Any]],
    tool_name: str,
    args: dict[str, Any],
    variables: dict[str, str] | None = None,
) -> int | str | None:
    """Evaluate rules top-to-bottom, return first matching risk value.

    Each rule: {"match": {"tool": regex, "arg_name": regex, ...}, "risk": int|str}
    All match conditions are AND. Values are regex patterns.
    Patterns support ``${var}`` expansion from *variables* dict
    (e.g. ``${user_email}``, ``${user_org}``).
    Returns int, str, or None if no rule matches.
    """
    for rule in rules:
        match_cond = rule.get("match", {})
        risk: int | str | None = rule.get("risk")
        if risk is None:
            continue
        matched = True
        for key, pattern in match_cond.items():
            if key == "tool":
                value = tool_name
            else:
                value = str(args.get(key, ""))
            pattern_str = str(pattern)
            # Expand ${var} placeholders in patterns
            if variables and "${" in pattern_str:
                for var_name, var_val in variables.items():
                    pattern_str = pattern_str.replace(f"${{{var_name}}}", re.escape(var_val))
            try:
                if not value or not re.search(pattern_str, value, re.IGNORECASE):
                    matched = False
                    break
            except re.error:
                logger.warning("Invalid regex in MCP risk rule: %r", pattern)
                matched = False
                break
        if matched:
            return risk
    return None


def _resolve_mcp_risk(
    tool_name: str,
    args: dict[str, Any],
    server_name: str | None,
    server_config_risk: dict[str, Any] | None,
    policy: dict[str, Any] | None,
    variables: dict[str, str] | None = None,
) -> int | str | None:
    """8-level MCP risk resolution. Returns int, str, or None.

    Priority:
    1. server config risk_rules
    2. server config tool_risks
    3. server config risk
    4. policy.{server}._rules
    5. policy.{server}.{tool}
    6. policy.{server}._default_risk
    7. policy._rules
    8. policy._default_risk
    """
    # Levels 1-3: mcp_servers config (user overrides)
    if server_config_risk:
        # 1. risk_rules
        risk_rules = server_config_risk.get("risk_rules", [])
        if risk_rules:
            result = _match_rules(risk_rules, tool_name, args, variables)
            if result is not None:
                return result
        # 2. tool_risks (case-insensitive lookup)
        tool_risks = server_config_risk.get("tool_risks", {})
        tool_risks_lower: dict[str, int | str] = {k.lower(): v for k, v in tool_risks.items()}
        if tool_name in tool_risks_lower:
            return tool_risks_lower[tool_name]
        # 3. risk (server default)
        srv_risk: int | str | None = server_config_risk.get("risk")
        if srv_risk is not None:
            return srv_risk

    # Levels 4-8: mcp_risk_policy (bundled knowledge)
    if policy and server_name:
        server_policy = policy.get(server_name)
        if isinstance(server_policy, dict):
            # 4. server _rules
            server_rules = server_policy.get("_rules", [])
            if server_rules:
                result = _match_rules(server_rules, tool_name, args, variables)
                if result is not None:
                    return result
            # 5. server tool score (case-insensitive lookup)
            for key, val in server_policy.items():
                if not key.startswith("_") and key.lower() == tool_name:
                    tool_val: int | str = val
                    return tool_val
            # 6. server _default_risk
            srv_default: int | str | None = server_policy.get("_default_risk")
            if srv_default is not None:
                return srv_default

    if policy:
        # 7. global _rules
        global_rules = policy.get("_rules", [])
        if global_rules:
            result = _match_rules(global_rules, tool_name, args, variables)
            if result is not None:
                return result
        # 8. global _default_risk
        global_default: int | str | None = policy.get("_default_risk")
        if global_default is not None:
            return global_default

    return None


class MCPToolAdapter(Tool):
    """Adapts an MCP tool descriptor into the WorkPilot Tool ABC.

    Args:
        descriptor: MCP tool descriptor dict with ``name``, ``description``,
            and ``inputSchema`` keys (as returned by ``MCPClient.list_tools()``).
        mcp_client: The connected ``MCPClient`` used to invoke the tool.
        server_name: Server namespace prefix. If set, the tool is registered
            as ``MCP_{server_name}_{tool_name}`` and described with ``[MCP:{server_name}]``.
        timeout: Per-server timeout override (seconds).
    """

    def __init__(
        self,
        descriptor: dict[str, Any],
        mcp_client: MCPClient,
        *,
        server_name: str | None = None,
        timeout: int = 30,
        streaming: bool = False,
        risk_config: dict[str, Any] | None = None,
        risk_policy: dict[str, Any] | None = None,
        risk_variables: dict[str, str] | None = None,
    ) -> None:
        self._descriptor = descriptor
        self._mcp_client = mcp_client
        self._raw_tool_name: str = descriptor.get("name", "")
        self._server_name = server_name
        self._risk_config: dict[str, Any] | None = risk_config
        self._risk_policy: dict[str, Any] | None = risk_policy
        self._risk_variables: dict[str, str] | None = risk_variables
        self._tool_name: str = (
            f"MCP_{server_name}_{self._raw_tool_name}" if server_name else self._raw_tool_name
        )
        raw_desc: str = descriptor.get("description", "")
        self._tool_description: str = f"[MCP:{server_name}] {raw_desc}" if server_name else raw_desc
        self._timeout: int = timeout
        self._streaming: bool = streaming
        # Compute risk_range from policy for portal display
        self.risk_range = self._compute_risk_range()
        self._input_schema: dict[str, Any] = descriptor.get(
            "inputSchema",
            {
                "type": "object",
                "properties": {},
            },
        )

    @property
    def name(self) -> str:
        return self._tool_name

    @property
    def description(self) -> str:
        return self._tool_description

    @property
    def parameters(self) -> dict[str, Any]:
        return self._input_schema

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(
            isolation="process",
            category="mcp",
            tier="standard",
            timeout=self._timeout,
            streaming=self._streaming,
        )

    def _compute_risk_range(self) -> tuple[int, int]:
        """Derive risk_range from policy config for portal display."""
        result = _resolve_mcp_risk(
            tool_name=self._raw_tool_name.lower(),
            args={},
            server_name=self._server_name,
            server_config_risk=self._risk_config,
            policy=self._risk_policy,
        )
        if isinstance(result, int):
            return (result, result)
        return (0, 10)  # string (LLM) or no match

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        """MCP tool risk — 8-level config-driven resolution.

        See security-classification.md §3.2 for priority order.
        """
        name = self._raw_tool_name.lower()
        desc = self._tool_description or self._raw_tool_name

        result = _resolve_mcp_risk(
            tool_name=name,
            args=args,
            server_name=self._server_name,
            server_config_risk=self._risk_config,
            policy=self._risk_policy,
            variables=self._risk_variables,
        )

        if result is not None:
            if isinstance(result, int):
                return RiskScore(result, reason=f"MCP risk policy: {self._raw_tool_name}")
            return RiskPrompt(str(result))

        # No match at any level → LLM with tool description
        return RiskPrompt(
            f"MCP tool: {self._tool_name}\nDescription: {desc}\n"
            f"No risk policy configured. Range: 2~8\n"
            f"Scoring factors:\n"
            f"  2: Simple data retrieval (get, list, read, show)\n"
            f"  3: Read-only query, search, or count with no side effects\n"
            f"  4: Verify, check, or validate (may probe external state)\n"
            f"  5: Modify or update an existing resource (edit, patch, set)\n"
            f"  6: Create new resource or action visible to others (post, assign, remove)\n"
            f"  7: Execute code/query, disable service, or broad-scope write\n"
            f"  8: Delete, revoke, or irreversible destructive operation"
        )

    def validate(self, args: dict[str, Any]) -> list[str]:
        """Basic validation — check required fields from input schema."""
        errors: list[str] = []
        required = self._input_schema.get("required", [])
        for field in required:
            if field not in args:
                errors.append(f"Missing required parameter: {field}")
        return errors

    async def execute(self, **kwargs: Any) -> str:
        """Execute the tool via the MCP client."""
        if not self._mcp_client.is_connected:
            server = self._mcp_client.name
            return (
                f"MCP server '{server}' is disconnected. "
                f"Use tools(name='MCP_{server}') to reconnect."
            )
        try:
            # Use raw (un-prefixed) name for the actual MCP call
            return await self._mcp_client.call_tool(
                self._raw_tool_name, kwargs, timeout=self._timeout
            )
        except ConnectionError as exc:
            logger.warning(f"MCP tool '{self._tool_name}' connection lost: {exc}")
            server = self._mcp_client.name
            return (
                f"MCP tool '{self._tool_name}' failed: connection lost ({exc}). "
                f"Use tools(name='MCP_{server}') to reconnect."
            )
        except (RuntimeError, TimeoutError) as exc:
            logger.warning(f"MCP tool '{self._tool_name}' execution failed: {exc}")
            # Probe the server in the background: if it is unreachable (e.g.
            # Agency backend down while its subprocess is still alive), the
            # probe will trigger reconnect_now so a reconnect starts immediately
            # rather than waiting for the next scheduled ping (up to 300 s).
            asyncio.create_task(
                self._mcp_client.probe_and_reconnect(),
                name=f"mcp-probe-{self._mcp_client.name}",
            )
            return f"MCP tool '{self._tool_name}' failed: {exc}."

    async def execute_streaming(self, **kwargs: Any) -> AsyncGenerator[str, None]:
        """Stream tool results. Falls back to single-chunk if server doesn't support streaming."""
        if not self._mcp_client.is_connected:
            server = self._mcp_client.name
            yield (
                f"MCP server '{server}' is disconnected. "
                f"Use tools(name='MCP_{server}') to reconnect."
            )
            return
        try:
            async for chunk in self._mcp_client.call_tool_streaming(
                self._raw_tool_name, kwargs, timeout=self._timeout
            ):
                yield chunk
        except (ConnectionError, RuntimeError, TimeoutError) as exc:
            yield f"MCP tool '{self._tool_name}' failed: {exc}."


AGENCY_DEFAULTS: dict[str, int] = {
    "timeout": 120,
}

STANDARD_DEFAULTS: dict[str, int] = {
    "timeout": 60,
}


def _build_risk_config(server_config: Any) -> dict[str, Any] | None:
    """Extract risk config from MCPServerConfig for assess_risk."""
    if server_config is None:
        return None
    risk: dict[str, Any] = {}
    if hasattr(server_config, "risk") and server_config.risk is not None:
        risk["risk"] = server_config.risk
    if hasattr(server_config, "tool_risks") and server_config.tool_risks:
        risk["tool_risks"] = dict(server_config.tool_risks)
    if hasattr(server_config, "risk_rules") and server_config.risk_rules:
        risk["risk_rules"] = list(server_config.risk_rules)
    return risk or None


def _resolve_server_timeout(
    server_config: Any | None,
) -> int:
    """Resolve timeout from server config."""
    if server_config is not None and hasattr(server_config, "is_agency"):
        defaults = AGENCY_DEFAULTS if server_config.is_agency else STANDARD_DEFAULTS
        return int(server_config.timeout or defaults["timeout"])
    return int(STANDARD_DEFAULTS["timeout"])


async def register_mcp_tools(
    registry: ToolRegistry,
    mcp_client: MCPClient,
    *,
    security_profile: str | None = None,
    server_name: str | None = None,
    server_config: Any | None = None,
    risk_policy: dict[str, Any] | None = None,
    risk_variables: dict[str, str] | None = None,
) -> list[str]:
    """Discover tools from an MCP server and register them in the ToolRegistry.

    When *server_name* is provided, tools are registered with namespace prefix
    (e.g. ``MCP_icm_get_incident``). Without it, tools keep their original names
    (backward-compatible).

    Args:
        registry: The agent's tool registry.
        mcp_client: A connected ``MCPClient``.
        security_profile: Security profile name (unused, kept for API compat).
        server_name: Namespace prefix for tool names (e.g. ``"icm"``).
        server_config: ``MCPServerConfig`` for per-server overrides.
        risk_policy: ``mcp_risk_policy`` from config.

    Returns:
        List of registered tool names (namespaced if server_name provided).
    """
    timeout = _resolve_server_timeout(server_config)

    try:
        descriptors = await mcp_client.list_tools(timeout=timeout)
    except Exception as exc:
        logger.warning(f"MCP server '{mcp_client.name}': failed to list tools: {exc}")
        return []

    registered: list[str] = []
    for descriptor in descriptors:
        raw_name = descriptor.get("name", "")
        if not raw_name:
            logger.warning(f"MCP server '{mcp_client.name}': skipping tool with empty name")
            continue

        # Compute the name that will be registered
        reg_name = f"MCP_{server_name}_{raw_name}" if server_name else raw_name

        # Anti-shadowing: only relevant for un-namespaced tools
        if not server_name and raw_name in PROTECTED_TOOLS:
            logger.warning(
                f"MCP server '{mcp_client.name}': skipping tool '{raw_name}' "
                f"-- name conflicts with protected built-in tool"
            )
            continue

        if registry.get(reg_name) is not None:
            logger.warning(
                f"MCP server '{mcp_client.name}': skipping tool '{reg_name}' "
                f"-- namespace collision with already-registered tool"
            )
            continue

        # Build risk config dict from server config for scorer Tier 1/2
        risk_config = _build_risk_config(server_config) if server_config else None

        adapter = MCPToolAdapter(
            descriptor,
            mcp_client,
            server_name=server_name,
            timeout=timeout,
            risk_config=risk_config,
            risk_policy=risk_policy,
            risk_variables=risk_variables,
        )
        try:
            registry.register(adapter)
            registered.append(reg_name)
        except ValueError as exc:
            logger.warning(
                f"MCP server '{mcp_client.name}': failed to register tool '{reg_name}': {exc}"
            )

    logger.debug(
        f"MCP server '{mcp_client.name}': registered {len(registered)}/{len(descriptors)} tools"
    )
    return registered
