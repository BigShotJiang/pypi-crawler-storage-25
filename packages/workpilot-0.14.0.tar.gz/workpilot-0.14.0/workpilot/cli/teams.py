"""Teams CLI subcommands — workpilot teams install|uninstall|status."""

from __future__ import annotations

import time
from pathlib import Path
from typing import TYPE_CHECKING

import typer
from rich.panel import Panel
from rich.table import Table

from workpilot.cli.commands import console, teams_app

# Re-export for use by init.py and commands.py
__all__ = ["is_teams_installed", "teams_install", "teams_uninstall", "teams_status"]

if TYPE_CHECKING:
    import msal


@teams_app.callback()
def _teams_default(ctx: typer.Context) -> None:
    """Teams app sideload management — install / uninstall / status."""
    if ctx.invoked_subcommand is not None:
        return

    # Invoke via typer context to ensure Option defaults are applied
    ctx.invoke(teams_status, online=False)
    console.print()

    saved = _load_install_data()
    version = tuple(int(x) for x in (saved or {}).get("version", "0").split(".") if x.isdigit())
    if saved and saved.get("appId") and version >= (2, 0, 0):
        console.print(
            "[dim]Run [cyan]wp teams install[/cyan] to update to the latest version.[/dim]"
        )
        return

    ctx.invoke(teams_install, package=None)


# ── Constants ──────────────────────────────────────────────────────────────

# Teams Toolkit well-known first-party app — pre-authorized for MOS3 in all
# M365 tenants; no Azure Portal registration needed.
_TOOLKIT_CLIENT_ID = "7ea7c24c-b1f6-4a20-9d11-9ae12e9e7ac0"
_AUTHORITY = "https://login.microsoftonline.com/common"
_MOS3_BASE = "https://titles.prod.mos.microsoft.com"
_MOS3_SCOPE = f"{_MOS3_BASE}/.default"

_PACKAGE_URL = "https://aka.ms/workpilot/teams-app.zip"
_INSTALL_DATA_FILE = "teams_install.json"


# ── Helpers ────────────────────────────────────────────────────────────────


def _print_click_hint() -> None:
    """Print a hint about how to open links based on the terminal environment."""
    import os

    term = os.environ.get("TERM_PROGRAM", "")
    wt = os.environ.get("WT_SESSION", "")
    if wt:
        console.print("  [dim]Ctrl+Click to open links in Windows Terminal[/dim]")
    elif term == "vscode":
        console.print("  [dim]Ctrl+Click to open links in VS Code terminal[/dim]")
    elif term in ("iTerm.app", "Apple_Terminal"):
        console.print("  [dim]Cmd+Click to open links[/dim]")
    else:
        console.print("  [dim]Ctrl+Click or Cmd+Click to open links[/dim]")


def _download_package() -> bytes | None:
    """Download the latest Teams app package from the website. Returns None on failure."""
    try:
        import httpx

        resp = httpx.get(_PACKAGE_URL, timeout=15, follow_redirects=True)
        if resp.status_code == 200 and len(resp.content) > 0:
            return resp.content
    except Exception:
        pass
    return None


def _get_package(package: str | None) -> bytes:
    """Resolve app package: explicit path → website download."""
    if package:
        p = Path(package)
        if not p.exists():
            console.print(f"[red]Package not found:[/red] {p}")
            raise typer.Exit(1)
        return p.read_bytes()

    with console.status("[bold cyan]Downloading app package\u2026"):
        data = _download_package()
    if data:
        console.print(f"  [green]\u2713[/green] Downloaded ({len(data) / 1024:.0f} KB)")
        return data

    console.print(f"[red]Failed to download from {_PACKAGE_URL}[/red]")
    console.print("Pass --package <path> to specify a local zip.")
    raise typer.Exit(1)


def _save_install_data(data: dict) -> None:  # type: ignore[type-arg]
    """Persist install result to ~/.workpilot/teams_install.json."""
    import json

    from workpilot.utils.helpers import get_data_dir

    path = get_data_dir() / _INSTALL_DATA_FILE
    payload = {
        "appId": data.get("appId", ""),
        "titleId": data.get("titleId", ""),
        "manifestId": data.get("manifestId", ""),
        "userOid": data.get("userOid", ""),
        "shareLink": data.get("shareLink", ""),
        "name": data.get("name", ""),
        "acquisitionState": data.get("acquisitionState", ""),
        "version": data.get("version", ""),
        "installedAt": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def _load_install_data() -> dict | None:  # type: ignore[type-arg]
    """Load saved install data from ~/.workpilot/teams_install.json."""
    import json

    from workpilot.utils.helpers import get_data_dir

    path = get_data_dir() / _INSTALL_DATA_FILE
    if not path.exists():
        return None
    try:
        return dict(json.loads(path.read_text(encoding="utf-8")))
    except Exception:
        return None


def _remove_install_data() -> None:
    """Remove saved install data."""
    from workpilot.utils.helpers import get_data_dir

    path = get_data_dir() / _INSTALL_DATA_FILE
    path.unlink(missing_ok=True)


def is_teams_installed() -> bool:
    """Quick local check: return True if Teams app install data exists with an appId."""
    saved = _load_install_data()
    return bool(saved and saved.get("appId"))


_token_cache: msal.SerializableTokenCache | None = None


def _cache_path() -> Path:
    """MSAL cache path: ~/.workpilot/auth/teams_sideload.bin"""
    from workpilot.utils.helpers import get_auth_dir

    return get_auth_dir() / "teams_sideload.bin"


def _load_token_cache() -> msal.SerializableTokenCache:
    """Load (and decrypt) persisted MSAL token cache."""
    import msal

    global _token_cache  # noqa: PLW0603
    if _token_cache is not None:
        return _token_cache

    _token_cache = msal.SerializableTokenCache()
    path = _cache_path()
    if path.exists():
        try:
            from workpilot.security.secrets import decrypt_at_rest

            raw = decrypt_at_rest(path.read_bytes())
            if raw:
                _token_cache.deserialize(raw.decode("utf-8"))
        except Exception as exc:
            from loguru import logger

            logger.warning("Cannot load Teams MSAL cache at {} ({}); starting fresh.", path, exc)
    return _token_cache


def _persist_token_cache() -> None:
    """Encrypt and persist MSAL token cache to disk."""
    if _token_cache is None or not _token_cache.has_state_changed:
        return
    try:
        from workpilot.security.secrets import encrypt_at_rest, is_encrypted

        plaintext = _token_cache.serialize().encode("utf-8")
        data = encrypt_at_rest(plaintext)
        path = _cache_path()
        # Avoid overwriting an encrypted cache with plaintext
        if data == plaintext and path.exists() and is_encrypted(path.read_bytes()):
            return
        tmp = path.with_suffix(".tmp")
        tmp.write_bytes(data)
        try:
            tmp.chmod(0o600)
        except (NotImplementedError, OSError):
            pass
        tmp.replace(path)
    except Exception as exc:
        from loguru import logger

        logger.warning("Failed to persist Teams MSAL cache: {}", exc)


def _get_msal_app() -> msal.PublicClientApplication:
    """Create MSAL PublicClientApplication with persisted token cache."""
    import msal

    cache = _load_token_cache()
    return msal.PublicClientApplication(
        client_id=_TOOLKIT_CLIENT_ID,
        authority=_AUTHORITY,
        token_cache=cache,
    )


def _acquire_token(msal_app: msal.PublicClientApplication) -> str:
    """Acquire MOS3 token — silent if cached, otherwise interactive."""
    # 1. Silent (cached)
    accounts = msal_app.get_accounts()
    if accounts:
        with console.status("[bold cyan]Authenticating\u2026"):
            result = msal_app.acquire_token_silent([_MOS3_SCOPE], account=accounts[0])
        if result and "access_token" in result:
            _persist_token_cache()
            console.print("  [green]\u2713[/green] Authenticated (cached)")
            return str(result["access_token"])

    # 2. Interactive (browser PKCE)
    console.print()
    console.print("[bold]Opening browser for Microsoft 365 sign-in\u2026[/bold]")
    console.print("[dim]Close the tab or press Ctrl+C to cancel.[/dim]")
    import socket

    port = 49216
    for candidate in (port, 52814, 0):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("localhost", candidate))
                port = s.getsockname()[1]
                break
            except OSError:
                continue
    result = msal_app.acquire_token_interactive(scopes=[_MOS3_SCOPE], port=port)

    if "access_token" not in result:
        error = result.get("error_description") or result.get("error") or "Unknown error"
        console.print(f"[red]Authentication failed:[/red] {error}")
        raise typer.Exit(1)

    _persist_token_cache()
    console.print("  [green]\u2713[/green] Authenticated")

    return str(result["access_token"])


def _mos3_headers(token: str) -> dict[str, str]:
    return {
        "Authorization": f"Bearer {token}",
        "Accept": "application/json",
    }


def _get_user_oid(msal_app: msal.PublicClientApplication) -> str:
    """Return the current user's OID from the MSAL account cache."""
    accounts = msal_app.get_accounts()
    if not accounts:
        return ""
    account = accounts[0]
    # Prefer oid from id_token_claims; fall back to local_account_id
    claims = account.get("id_token_claims") or {}
    return str(claims.get("oid") or account.get("local_account_id") or "")


def _personalize_package(package: bytes, user_oid: str) -> bytes:
    """Rewrite manifest 'id' to a per-user UUID5 so sideloads don't collide.

    ``new_id = uuid5(base_manifest_id, user_oid)`` — deterministic, unique per user.
    """
    import io
    import json
    import uuid
    import zipfile

    if not user_oid:
        return package

    buf_in = io.BytesIO(package)
    buf_out = io.BytesIO()
    try:
        with zipfile.ZipFile(buf_in, "r") as zf_in, zipfile.ZipFile(buf_out, "w") as zf_out:
            for item in zf_in.infolist():
                data = zf_in.read(item.filename)
                if item.filename == "manifest.json":
                    manifest = json.loads(data)
                    base_id = manifest.get("id", "")
                    if base_id:
                        ns = uuid.UUID(base_id)
                        manifest["id"] = str(uuid.uuid5(ns, user_oid))
                    data = json.dumps(manifest, indent=2).encode("utf-8")
                    item.file_size = len(data)
                zf_out.writestr(item, data)
        return buf_out.getvalue()
    except Exception:
        return package


def _upload_and_acquire(token: str, package: bytes) -> dict:  # type: ignore[type-arg]
    """Upload package via MOS3 Builder API and return result with titleId/appId.

    Uses /builder/v1/users/packages?scope=Shared. Falls back to /dev/v1/ if unavailable.
    """
    import httpx

    headers = _mos3_headers(token)

    # Step 1: Upload package via Builder v2 API
    with console.status("[bold cyan]Uploading app package\u2026"):
        resp = httpx.post(
            f"{_MOS3_BASE}/builder/v1/users/packages?scope=Shared",
            headers=headers,
            files={"file": ("WorkPilot-teams-app.zip", package, "application/zip")},
            timeout=60,
        )

        # Fallback to v1 if Builder API not available
        if resp.status_code in (400, 404, 405):
            resp = httpx.post(
                f"{_MOS3_BASE}/dev/v1/users/packages",
                headers=headers,
                files={"file": ("WorkPilot-teams-app.zip", package, "application/zip")},
                timeout=60,
            )

    if resp.status_code not in (200, 201, 202):
        console.print(f"[red]Upload failed ({resp.status_code}):[/red] {resp.text}")
        raise typer.Exit(1)

    console.print("  [green]\u2713[/green] Uploaded")

    data = resp.json()

    # MOS3 may return the result directly (with titlePreview) — no polling needed
    preview = data.get("titlePreview") or {}
    if preview.get("titleId"):
        return dict(preview)
    if data.get("titleId"):
        return dict(data)

    status_id = data.get("statusId") or data.get("operationId") or data.get("id")
    if not status_id:
        console.print(f"[red]Unexpected response:[/red] {data}")
        raise typer.Exit(1)

    # Step 2: Poll until upload completes
    with console.status("[bold cyan]Processing\u2026"):
        poll_base = f"{_MOS3_BASE}/builder/v1/users/packages/status"
        for attempt in range(60):
            time.sleep(1)
            poll = httpx.get(
                f"{poll_base}/{status_id}",
                headers=headers,
                timeout=30,
            )
            # Fallback poll endpoint on first failure
            if poll.status_code in (400, 404) and attempt == 0:
                poll_base = f"{_MOS3_BASE}/dev/v1/users/packages/status"
                continue
            if poll.status_code != 200:
                continue
            status = poll.json()
            state = status.get("state") or status.get("status") or ""
            if state.lower() in ("completed", "succeeded", "ok"):
                title_id = status.get("titleId") or status.get("id")
                if title_id:
                    return dict(status)
            elif state.lower() in ("failed", "error"):
                error = status.get("error") or status.get("message") or status
                console.print(f"[red]Upload failed:[/red] {error}")
                raise typer.Exit(1)

    console.print("[red]Timed out waiting for upload to complete.[/red]")
    raise typer.Exit(1)


def _unacquire(token: str, title_id: str) -> None:
    """Uninstall (unacquire) app by titleId."""
    import httpx

    resp = httpx.delete(
        f"{_MOS3_BASE}/catalog/v1/users/acquisitions/{title_id}",
        headers=_mos3_headers(token),
        timeout=30,
    )
    if resp.status_code not in (200, 204):
        console.print(f"[red]Uninstall failed ({resp.status_code}):[/red] {resp.text}")
        raise typer.Exit(1)


def _copilot_link(title_id: str) -> str:
    """Construct M365 Copilot link from titleId."""
    return f"https://m365.cloud.microsoft/chat/?titleId={title_id}" if title_id else ""


def _get_launch_info(token: str, manifest_id: str) -> dict | None:  # type: ignore[type-arg]
    """Get launch info for an app by manifest ID."""
    import httpx

    try:
        resp = httpx.post(
            f"{_MOS3_BASE}/catalog/v1/users/titles/launchInfo",
            headers=_mos3_headers(token),
            json={
                "Id": manifest_id,
                "IdType": "ManifestId",
                "Filter": {"SupportedElementTypes": ["Bots"]},
            },
            timeout=15,
        )
        if resp.status_code == 200:
            data = resp.json()
            # Flatten nested titleId and titleDefinition into top-level keys
            acq = data.get("acquisition") or {}
            tid = acq.get("titleId") or {}
            td = acq.get("titleDefinition") or {}
            return {
                "titleId": tid.get("id", ""),
                "appId": acq.get("appId", ""),
                "manifestId": acq.get("manifestId", ""),
                "name": td.get("name", ""),
                "acquisitionState": acq.get("acquisitionState", ""),
                "version": td.get("version", ""),
            }
    except Exception:
        pass
    return None


def _user_manifest_id(user_oid: str) -> str:
    """Derive the per-user manifest ID from base ID + user OID."""
    import uuid

    base_id = _read_manifest_field("id")
    if not base_id or not user_oid:
        return base_id
    return str(uuid.uuid5(uuid.UUID(base_id), user_oid))


def _verify_online(token: str, saved: dict | None, *, user_oid: str = "") -> dict | None:  # type: ignore[type-arg]
    """Verify app is installed via MOS3 launchInfo. Returns info dict or None."""
    # Try: saved manifestId → per-user derived ID
    candidates: list[str] = []
    saved_mid = (saved or {}).get("manifestId", "")
    if saved_mid:
        candidates.append(saved_mid)
    # Use provided user_oid, or fall back to saved userOid
    oid = user_oid or (saved or {}).get("userOid", "")
    if oid:
        derived = _user_manifest_id(oid)
        if derived not in candidates:
            candidates.append(derived)

    for manifest_id in candidates:
        info = _get_launch_info(token, manifest_id)
        if info and info.get("titleId"):
            info["shareLink"] = _copilot_link(info["titleId"])
            info["method"] = "launchInfo"
            return info

    return None


_MANIFEST_DEFAULTS: dict[str, str] = {
    "id": "cfcdde49-617a-4fbd-bf0f-7c3bab131982",
    "botId": "80a9478e-6cc7-4e7a-84bc-37abbd81f5f6",
}


def _read_manifest_field(field: str) -> str:
    """Read a field from teams/manifest.json, falling back to built-in defaults."""
    import json

    manifest = Path(__file__).resolve().parents[2] / "teams" / "manifest.json"
    try:
        data = json.loads(manifest.read_text(encoding="utf-8"))
        if field == "botId":
            bots = data.get("bots") or []
            return str(bots[0]["botId"]) if bots else _MANIFEST_DEFAULTS.get(field, "")
        return str(data.get(field, "") or _MANIFEST_DEFAULTS.get(field, ""))
    except Exception:
        return _MANIFEST_DEFAULTS.get(field, "")


# ── Commands ───────────────────────────────────────────────────────────────


@teams_app.command("install")
def teams_install(
    package: str | None = typer.Option(
        None, "--package", "-p", help="Path to .zip app package (auto-detected if omitted)"
    ),
) -> None:
    """Install WorkPilot Teams app for the current user (sideload via MOS3)."""
    try:
        import httpx  # noqa: F401
        import msal  # noqa: F401
    except ImportError:
        console.print("[red]Missing dependencies.[/red] Run: pip install msal httpx")
        raise typer.Exit(1)

    console.print(
        Panel(
            "[bold]WorkPilot Teams App \u2014 Sideload Install[/bold]",
            border_style="#7B83EB",
        )
    )

    # [1/3] Download
    console.print("\n[bold cyan][1/3][/bold cyan] [bold]Download package[/bold]")
    pkg = _get_package(package)

    # [2/3] Authenticate
    console.print("\n[bold cyan][2/3][/bold cyan] [bold]Microsoft 365 sign-in[/bold]")
    msal_app = _get_msal_app()
    token = _acquire_token(msal_app)

    # [3/3] Upload & install
    console.print("\n[bold cyan][3/3][/bold cyan] [bold]Upload & install[/bold]")
    user_oid = _get_user_oid(msal_app)
    pkg = _personalize_package(pkg, user_oid)
    result = _upload_and_acquire(token, pkg)

    # Collect all links — reuse previous data for v1 fallback (appId changes each upload)
    app_id = result.get("appId", "")
    title_id = result.get("titleId", "")
    bot_id = _read_manifest_field("botId")
    if not result.get("manifestId"):
        result["manifestId"] = _user_manifest_id(user_oid) if user_oid else ""
    result["userOid"] = user_oid
    copilot_link = _copilot_link(title_id)

    prev = _load_install_data() or {}
    # v1 fallback generates new appId each time — reuse previous if available
    if prev.get("appId") and title_id.startswith("U_"):
        app_id = prev["appId"]

    result["shareLink"] = copilot_link
    result["appId"] = app_id
    _save_install_data(result)

    app_link = f"https://teams.microsoft.com/l/app/{app_id}" if app_id else ""
    app_link_native = f"msteams://l/app/{app_id}" if app_id else ""
    chat_link = f"https://teams.microsoft.com/l/chat/0/0?users=28:{bot_id}" if bot_id else ""

    console.print()
    console.print("  [green]\u2713[/green] [bold]Teams app installed successfully![/bold]")
    console.print()
    if app_link:
        console.print(f"  [#7B83EB]Teams App[/#7B83EB]     : [link={app_link}]{app_link}[/link]")
    if chat_link:
        console.print(f"  [#7B83EB]Teams Chat[/#7B83EB]    : [link={chat_link}]{chat_link}[/link]")
    # TODO: unhide when Copilot custom engine agent registration is resolved
    # if copilot_link:
    #     console.print(
    #         f"  [#10A37F]M365 Copilot[/#10A37F]  : [link={copilot_link}]{copilot_link}[/link]"
    #     )
    console.print()
    _print_click_hint()

    if app_link_native:
        import webbrowser

        with console.status("[bold cyan]Opening Teams\u2026"):
            time.sleep(2)
        console.print(f"  [#7B83EB]Opening:[/#7B83EB] {app_link_native}")
        webbrowser.open(app_link_native)


@teams_app.command("uninstall")
def teams_uninstall() -> None:
    """Uninstall (remove) the sideloaded WorkPilot Teams app."""
    try:
        import httpx  # noqa: F401
        import msal  # noqa: F401
    except ImportError:
        console.print("[red]Missing dependencies.[/red] Run: pip install msal httpx")
        raise typer.Exit(1)

    saved = _load_install_data()
    msal_app = _get_msal_app()
    token = _acquire_token(msal_app)

    title_id = (saved or {}).get("titleId", "")
    if not title_id:
        # No local data — try to find it online
        with console.status("[bold cyan]Looking up app\u2026"):
            result = _verify_online(token, saved, user_oid=_get_user_oid(msal_app))
        if result:
            title_id = result["titleId"]
        else:
            console.print("[yellow]App not found \u2014 it may not be installed.[/yellow]")
            raise typer.Exit(0)

    with console.status("[bold cyan]Uninstalling\u2026"):
        _unacquire(token, title_id)
        _remove_install_data()
    console.print("  [green]\u2713[/green] WorkPilot Teams app uninstalled.")


@teams_app.command("status")
def teams_status(
    online: bool = typer.Option(False, "--online", help="Skip local data, verify via MOS3 API"),
) -> None:
    """Check if the WorkPilot Teams app is installed for the current user."""
    saved = _load_install_data()
    info: dict | None = None  # type: ignore[type-arg]

    if not online and saved and saved.get("appId"):
        # Local data available
        info = dict(saved)
    else:
        # No local data — try online lookup
        try:
            import httpx  # noqa: F401
            import msal  # noqa: F401
        except ImportError:
            console.print("[yellow]Not installed.[/yellow]")
            console.print("Run [cyan]wp teams install[/cyan] to install.")
            return

        msal_app = _get_msal_app()
        token = _acquire_token(msal_app)
        result = _verify_online(token, saved, user_oid=_get_user_oid(msal_app))
        if result:
            info = result
            _save_install_data(info)
        else:
            console.print("[yellow]Not installed.[/yellow]")
            console.print("Run [cyan]wp teams install[/cyan] to install.")
            return

    # Display all available info
    app_id = info.get("appId", "")
    title_id = info.get("titleId", "")
    name = info.get("name", "")
    version = info.get("version", "")
    state = info.get("acquisitionState", "")
    installed_at = info.get("installedAt", "")
    # copilot_link = info.get("shareLink", "")  # TODO: unhide with Copilot link
    bot_id = _read_manifest_field("botId")

    label = name or "WorkPilot"
    console.print(f"[#7B83EB]{label}[/#7B83EB] \u2014 [green]{state or 'installed'}[/green]")
    console.print()

    tbl = Table(show_header=False, box=None, padding=(0, 2))
    tbl.add_column("Key", style="dim")
    tbl.add_column("Value")
    if app_id:
        tbl.add_row("appId", f"[cyan]{app_id}[/cyan]")
    if title_id:
        tbl.add_row("titleId", f"[cyan]{title_id}[/cyan]")
    if version:
        tbl.add_row("version", f"[dim]{version}[/dim]")
    if installed_at:
        tbl.add_row("installed at", f"[dim]{installed_at}[/dim]")
    console.print(tbl)
    console.print()

    # Links
    app_link = f"https://teams.microsoft.com/l/app/{app_id}" if app_id else ""
    chat_link = f"https://teams.microsoft.com/l/chat/0/0?users=28:{bot_id}" if bot_id else ""

    if app_link:
        console.print(f"  [#7B83EB]Teams App[/#7B83EB]     : [link={app_link}]{app_link}[/link]")
    if chat_link:
        console.print(f"  [#7B83EB]Teams Chat[/#7B83EB]    : [link={chat_link}]{chat_link}[/link]")
    # TODO: unhide when Copilot custom engine agent registration is resolved
    # if copilot_link:
    #     console.print(
    #         f"  [#10A37F]M365 Copilot[/#10A37F]  : [link={copilot_link}]{copilot_link}[/link]"
    #     )
    if app_link or chat_link:
        console.print()
        _print_click_hint()
