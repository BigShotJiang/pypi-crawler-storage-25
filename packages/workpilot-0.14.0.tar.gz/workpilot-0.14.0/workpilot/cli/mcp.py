"""MCP CLI subcommands — workpilot mcp list|add|add-json|remove|get|add-agency."""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    import httpx

import typer
import yaml
from rich.table import Table

from workpilot.cli.commands import (
    _load_config_safe,
    console,
    mcp_app,
)
from workpilot.cli.commands import (
    resolve_config_path as _resolve_config_path,
)
from workpilot.cli.commands import (
    resolve_local_config_path as _resolve_local_config_path,
)
from workpilot.config.loader import ensure_schema_line
from workpilot.mcp.defaults import AGENCY_DESCRIPTIONS as _AGENCY_DESCRIPTIONS
from workpilot.mcp.defaults import get_default_description


def _load_yaml(config_path: Path) -> dict[str, Any]:
    return yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}


def _save_mcp_servers(config_path: Path, servers: dict[str, dict[str, Any]]) -> None:
    """Update only the tools.mcp_servers section in a workpilot yaml file.

    Preserves the rest of the file as-is by doing targeted text replacement.
    Works for both workpilot.yaml (base) and workpilot.local.yaml (override).
    """

    content = config_path.read_text(encoding="utf-8") if config_path.is_file() else ""

    # Build the new mcp_servers YAML block
    lines: list[str] = []
    for name, srv in servers.items():
        lines.append(f"    {name}:")
        for key, val in srv.items():
            if isinstance(val, list):
                # Flow style for short lists: args: ["mcp", "icm"]
                items = ", ".join(f'"{v}"' if isinstance(v, str) else str(v) for v in val)
                lines.append(f"      {key}: [{items}]")
            elif isinstance(val, dict):
                lines.append(f"      {key}:")
                for dk, dv in val.items():
                    lines.append(f"        {dk}: {_yaml_scalar(dv)}")
            else:
                lines.append(f"      {key}: {_yaml_scalar(val)}")
    new_block = "\n".join(lines)

    # Try to find and replace existing tools.mcp_servers section
    # Pattern: "tools:\n  mcp_servers:\n" followed by indented content until next top-level key
    pattern = r"(tools:\s*\n\s*mcp_servers:\s*\n)((?:\s{4,}\S.*\n)*)"
    if re.search(pattern, content):
        replacement = f"tools:\n  mcp_servers:\n{new_block}\n"
        content = re.sub(pattern, replacement, content)
    else:
        # No existing section — insert before channels: or append
        insert_before = re.search(r"^(channels:|cron:|logging:)", content, re.MULTILINE)
        block = f"\ntools:\n  mcp_servers:\n{new_block}\n\n"
        if insert_before:
            pos = insert_before.start()
            content = content[:pos] + block + content[pos:]
        else:
            content = content.rstrip() + "\n" + block

    config_path.write_text(content, encoding="utf-8")
    ensure_schema_line(config_path)


def _yaml_scalar(val: Any) -> str:
    """Format a scalar value for inline YAML."""
    if isinstance(val, bool):
        return "true" if val else "false"
    if isinstance(val, (int, float)):
        return str(val)
    if isinstance(val, str):
        if any(c in val for c in ":#{}[]|>&*!%@`"):
            return f'"{val}"'
        return f'"{val}"'
    return str(val)


@mcp_app.command("list")
def mcp_list(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """List configured MCP servers."""
    cfg = _load_config_safe(config)

    servers = cfg.tools.mcp_servers
    if not servers:
        console.print("[dim]No MCP servers configured.[/dim]")
        return

    table = Table(title="MCP Servers")
    table.add_column("Name", style="bold")
    table.add_column("Description")
    table.add_column("Status")

    for name, srv in servers.items():
        desc = (
            srv.description
            if srv.description is not None
            else get_default_description(name, is_agency=srv.is_agency) or ""
        )
        if not srv.enabled:
            status = "[dim]disabled[/dim]"
        elif srv.is_agency:
            status = "[green]agency[/green]"
        elif srv.url:
            status = "http"
        else:
            status = "stdio"

        name_display = f"[dim]{name}[/dim]" if not srv.enabled else name
        table.add_row(name_display, desc, status)

    console.print(table)


@mcp_app.command("add")
def mcp_add(
    name: str = typer.Argument(..., help="MCP server name"),
    command: list[str] | None = typer.Argument(None, help="Server command and args (after --)"),
    transport: str = typer.Option(
        "stdio", "--transport", "-t", help="Transport: stdio (default) or http"
    ),
    url: str | None = typer.Option(
        None, "--url", help="HTTP endpoint URL (alternative to command)"
    ),
    env: list[str] | None = typer.Option(
        None, "-e", "--env", help="Environment variable KEY=VALUE (repeatable)"
    ),
    timeout: int | None = typer.Option(None, "--timeout", help="Tool call timeout in seconds"),
    risk: int | None = typer.Option(None, "--risk", help="Server default risk score: 0-10"),
    namespace: str | None = typer.Option(None, "--namespace", help="Override namespace prefix"),
    header: list[str] | None = typer.Option(
        None, "--header", help="HTTP header 'Key: Value' (repeatable)"
    ),
    auth: str | None = typer.Option(
        None, "--auth", help="Auth type: oauth (bearer auto-detected from --header)"
    ),
    client_id: str | None = typer.Option(None, "--client-id", help="OAuth client ID"),
    grant_type: str | None = typer.Option(
        None, "--grant-type", help="OAuth grant: authorization_code or client_credentials"
    ),
    callback_port: int | None = typer.Option(None, "--callback-port", help="OAuth callback port"),
    auth_server_url: str | None = typer.Option(
        None, "--auth-server-url", help="OAuth auth server URL (skip discovery)"
    ),
    force: bool = typer.Option(False, "--force", help="Overwrite existing server config"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Add an MCP server to the configuration.

    Stdio: workpilot mcp add <name> -- <command> [args...]
    HTTP:  workpilot mcp add --transport http <name> --url <url>
    """
    config_path = _resolve_config_path(config)
    local_path = _resolve_local_config_path(config_path)

    # Collision check against merged config (base + local)
    merged_cfg = _load_config_safe(str(config_path.parent))
    if name in merged_cfg.tools.mcp_servers and not force:
        console.print(
            f"[yellow]MCP server '{name}' already exists. Use --force to overwrite.[/yellow]"
        )
        raise typer.Exit(1)

    # Read local override to update (never touch the base workpilot.yaml)
    local_raw = _load_yaml(local_path) if local_path.is_file() else {}
    tools_section = local_raw.setdefault("tools", {})
    mcp_section = tools_section.setdefault("mcp_servers", {})

    entry: dict[str, Any] = {}

    if transport == "http" or url:
        # HTTP transport
        if not url and command:
            url = command[0]  # first positional arg as URL
        if not url:
            console.print("[red]HTTP transport requires --url or a URL argument.[/red]")
            raise typer.Exit(1)
        entry["url"] = url
        # Headers → auth config
        if header:
            for h in header:
                if ":" in h:
                    key, val = h.split(":", 1)
                    key, val = key.strip(), val.strip()
                    if key.lower() == "authorization" and val.lower().startswith("bearer "):
                        entry.setdefault("auth", {})["type"] = "bearer"
                        entry["auth"]["token"] = val[7:]  # strip "Bearer "
        # OAuth auth config (overrides any bearer detected from --header)
        if auth and auth != "oauth":
            console.print(
                f"[red]Invalid --auth '{auth}'. Use 'oauth' (bearer is auto-detected from --header).[/red]"
            )
            raise typer.Exit(1)
        if auth == "oauth" or client_id:
            auth_cfg = entry.setdefault("auth", {})
            auth_cfg.pop("token", None)  # clear conflicting bearer keys
            auth_cfg.pop("token_env", None)
            auth_cfg["type"] = "oauth"
            if client_id:
                auth_cfg["client_id"] = client_id
            if grant_type:
                if grant_type not in ("authorization_code", "client_credentials"):
                    console.print(
                        f"[red]Invalid --grant-type '{grant_type}'. "
                        "Use 'authorization_code' or 'client_credentials'.[/red]"
                    )
                    raise typer.Exit(1)
                auth_cfg["grant_type"] = grant_type
            if callback_port is not None:
                auth_cfg["callback_port"] = callback_port
            if auth_server_url:
                auth_cfg["auth_server_url"] = auth_server_url
        # Env for HTTP (rare but supported)
        if env:
            env_dict: dict[str, str] = {}
            for e in env:
                if "=" in e:
                    k, v = e.split("=", 1)
                    env_dict[k] = v
            if env_dict:
                entry["env"] = env_dict
    else:
        # Stdio transport
        if not command:
            console.print(
                "[red]Stdio transport requires a command. Usage: wp mcp add <name> -- <command> [args...][/red]"
            )
            raise typer.Exit(1)
        entry["command"] = command[0]
        if len(command) > 1:
            entry["args"] = list(command[1:])
        # Env vars
        if env:
            env_dict = {}
            for e in env:
                if "=" in e:
                    k, v = e.split("=", 1)
                    env_dict[k] = v
            if env_dict:
                entry["env"] = env_dict

    # Optional per-server overrides
    if timeout is not None:
        entry["timeout"] = timeout
    if risk is not None:
        entry["risk"] = risk
    if namespace:
        entry["namespace"] = namespace

    mcp_section[name] = entry
    _save_mcp_servers(local_path, mcp_section)
    console.print(
        f"  [green]\u2713[/green] MCP server [bold]{name}[/bold] added to [cyan]{local_path}[/cyan]"
    )


@mcp_app.command("add-json")
def mcp_add_json(
    name: str = typer.Argument(..., help="MCP server name"),
    json_config: str = typer.Argument(..., help="JSON configuration string"),
    force: bool = typer.Option(False, "--force", help="Overwrite existing server config"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Add an MCP server from a JSON configuration string.

    Example: workpilot mcp add-json icm '{"command":"agency","args":["mcp","icm"],"timeout":60}'
    """

    config_path = _resolve_config_path(config)
    local_path = _resolve_local_config_path(config_path)

    merged_cfg = _load_config_safe(str(config_path.parent))
    if name in merged_cfg.tools.mcp_servers and not force:
        console.print(
            f"[yellow]MCP server '{name}' already exists. Use --force to overwrite.[/yellow]"
        )
        raise typer.Exit(1)

    try:
        entry = json.loads(json_config)
    except json.JSONDecodeError as exc:
        console.print(f"[red]Invalid JSON: {exc}[/red]")
        raise typer.Exit(1)

    if not isinstance(entry, dict):
        console.print("[red]JSON must be an object.[/red]")
        raise typer.Exit(1)

    local_raw = (_load_yaml(local_path) if local_path.is_file() else {}) or {}
    mcp_section = local_raw.setdefault("tools", {}).setdefault("mcp_servers", {})
    mcp_section[name] = entry
    _save_mcp_servers(local_path, mcp_section)
    console.print(
        f"  [green]\u2713[/green] MCP server [bold]{name}[/bold] added to [cyan]{local_path}[/cyan]"
    )


@mcp_app.command("remove")
def mcp_remove(
    name: str = typer.Argument(..., help="MCP server name to remove"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Remove an MCP server from the configuration."""
    config_path = _resolve_config_path(config)
    local_path = _resolve_local_config_path(config_path)

    # Check existence against merged config
    merged_cfg = _load_config_safe(str(config_path.parent))
    if name not in merged_cfg.tools.mcp_servers:
        console.print(f"[yellow]MCP server '{name}' not found in config.[/yellow]")
        raise typer.Exit(1)

    removed_from: list[str] = []

    # Remove from local override if present
    if local_path.is_file():
        local_raw = _load_yaml(local_path)
        local_mcp = local_raw.get("tools", {}).get("mcp_servers", {})
        if name in local_mcp:
            del local_mcp[name]
            if local_mcp:
                _save_mcp_servers(local_path, local_mcp)
            else:
                # Last server removed — wipe the tools.mcp_servers key from the file
                tools_sec = local_raw.get("tools", {})
                tools_sec.pop("mcp_servers", None)
                if not tools_sec:
                    local_raw.pop("tools", None)
                from workpilot.config.loader import save_yaml

                save_yaml(local_path, local_raw)
            removed_from.append(str(local_path))

    # Remove from base config if present
    base_raw = _load_yaml(config_path) if config_path.is_file() else {}
    base_mcp = base_raw.get("tools", {}).get("mcp_servers", {})
    if name in base_mcp:
        del base_mcp[name]
        _save_mcp_servers(config_path, base_mcp)
        removed_from.append(str(config_path))

    if removed_from:
        console.print(
            f"  [green]\u2713[/green] MCP server [bold]{name}[/bold] removed"
            f" from [cyan]{', '.join(removed_from)}[/cyan]"
        )
    else:
        console.print(
            f"[yellow]MCP server '{name}' exists in merged config but was not found "
            f"in any editable file (may be inherited via extends: or bundled defaults).[/yellow]"
        )


@mcp_app.command("get")
def mcp_get(
    name: str = typer.Argument(..., help="MCP server name"),
    raw_output: bool = typer.Option(False, "--raw", help="Output as JSON"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Show detailed configuration for a specific MCP server."""

    cfg = _load_config_safe(config)
    srv = cfg.tools.mcp_servers.get(name)

    if srv is None:
        console.print(f"[yellow]MCP server '{name}' not found in config.[/yellow]")
        raise typer.Exit(1)

    if raw_output:
        console.print(json.dumps(srv.model_dump(exclude_none=True), indent=2))
        return

    # Formatted output
    if srv.command:
        transport = "stdio"
        target = f"{srv.command} {' '.join(srv.args)}"
    elif srv.url:
        transport = "http"
        target = srv.url
    else:
        transport = "unknown"
        target = ""

    console.print(f"[bold]Server:[/bold] {name}")
    if srv.description is not None:
        effective_desc = srv.description
    else:
        effective_desc = get_default_description(name, is_agency=srv.is_agency) or ""
    if effective_desc:
        console.print(f"[bold]Description:[/bold] {effective_desc}")
    console.print(f"[bold]Enabled:[/bold] {'yes' if srv.enabled else '[red]no[/red]'}")
    console.print(f"[bold]Transport:[/bold] {transport}")
    console.print(f"[bold]{'Command' if srv.command else 'URL'}:[/bold] {target}")

    if srv.is_agency:
        console.print("[bold]Agency:[/bold] yes (auto-detected)")

    if srv.timeout is not None:
        console.print(f"[bold]Timeout:[/bold] {srv.timeout}s")
    else:
        default = "120s" if srv.is_agency else "60s"
        console.print(f"[bold]Timeout:[/bold] {default} (default)")

    if srv.risk is not None:
        console.print(f"[bold]Risk:[/bold] {srv.risk}")
    else:
        console.print("[bold]Risk:[/bold] (policy/auto)")

    if srv.namespace:
        console.print(f"[bold]Namespace:[/bold] {srv.namespace}")
    else:
        console.print(f"[bold]Namespace:[/bold] {name}")

    if srv.env:
        env_str = ", ".join(f"{k}=..." for k in srv.env)
        console.print(f"[bold]Env:[/bold] {env_str}")

    if srv.command:
        console.print("[bold]Auth:[/bold] none (stdio — handled internally)")
    else:
        console.print(f"[bold]Auth:[/bold] {srv.auth.type}")


def _test_mcp_server(
    srv_name: str,
    *,
    command: str | None = None,
    args: list[str] | None = None,
    url: str | None = None,
    headers: dict[str, str] | None = None,
    auth: httpx.Auth | None = None,
    timeout: float = 60.0,
) -> tuple[bool, str, list[dict[str, Any]]]:
    """Test any MCP server (stdio or HTTP) using MCPClient.

    Returns (ok, message, tools_list).
    """
    import asyncio as _asyncio

    async def _test() -> tuple[bool, str, list[dict[str, Any]]]:
        from loguru import logger as _logger  # noqa: I001
        from workpilot.mcp.client import SUPPORTED_VERSIONS, MCPClient

        _logger.disable("workpilot.mcp.transport")
        _logger.disable("workpilot.mcp.client")
        try:
            client = MCPClient(
                command=command,
                args=args,
                url=url,
                headers=headers,
                auth=auth,
                name=srv_name,
            )
            ok: bool = False
            msg: str = ""
            tools: list[dict[str, Any]] = []
            try:
                async with _asyncio.timeout(len(SUPPORTED_VERSIONS) * timeout):
                    await client.connect(timeout=timeout)
                tools = await client.list_tools(timeout=timeout)
                protocol = client.protocol_version or "unknown"
                ok = True
                msg = f"{len(tools)} tools (protocol {protocol})"
            except TimeoutError:
                msg = f"timeout ({timeout:.0f}s)"
            except Exception as exc:
                msg = str(exc)
            finally:
                try:
                    await client.disconnect()
                except Exception:
                    pass
            return ok, msg, tools
        finally:
            _logger.enable("workpilot.mcp.transport")
            _logger.enable("workpilot.mcp.client")

    # Run async test in a thread, print dots while waiting
    import threading

    result_holder: list[tuple[bool, str, list[dict[str, Any]]]] = []

    def _run() -> None:
        try:
            result_holder.append(_asyncio.run(_test()))
        except Exception as exc:
            result_holder.append((False, str(exc), []))

    t = threading.Thread(target=_run, daemon=True)
    t.start()

    while t.is_alive():
        t.join(timeout=15)
        if t.is_alive():
            sys.stdout.write(".")
            sys.stdout.flush()

    return result_holder[0] if result_holder else (False, "no result", [])


@mcp_app.command("test")
def mcp_test(
    name: str = typer.Argument(..., help="MCP server name to test"),
    show_tools: bool = typer.Option(False, "--tools", "-t", help="List discovered tools"),
    timeout_override: int | None = typer.Option(
        None, "--timeout", help="Override timeout in seconds"
    ),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Test connectivity and auth for a configured MCP server.

    Connects to the server, negotiates the MCP protocol, and lists available tools.
    """
    import asyncio as _asyncio

    cfg = _load_config_safe(config)
    srv = cfg.tools.mcp_servers.get(name)

    if srv is None:
        console.print(f"[red]MCP server '{name}' not found in config.[/red]")
        console.print("[dim]Run 'wp mcp list' to see configured servers.[/dim]")
        raise typer.Exit(1)

    if not srv.enabled:
        console.print(f"[yellow]MCP server '{name}' is disabled.[/yellow]")
        raise typer.Exit(1)

    # Determine transport info
    if srv.command:
        transport = "stdio"
        target = f"{srv.command} {' '.join(srv.args)}"
    elif srv.url:
        transport = "http"
        target = srv.url
    else:
        console.print(f"[red]MCP server '{name}' has no command or url configured.[/red]")
        raise typer.Exit(1)

    console.print(f"[bold]Testing:[/bold] {name} ({transport}: {target})")

    # Resolve timeout
    if timeout_override is not None:
        timeout = max(1.0, float(timeout_override))
    elif srv.timeout is not None:
        timeout = max(1.0, float(srv.timeout))
    elif srv.is_agency:
        timeout = 120.0
    else:
        timeout = 60.0

    # Resolve auth for HTTP servers.
    headers: dict[str, str] | None = None
    auth_provider = None
    if srv.url:
        try:
            from workpilot.mcp.oauth_provider import create_oauth_auth

            auth_provider = _asyncio.run(create_oauth_auth(name, srv, cfg.providers))
        except Exception as exc:
            if srv.auth.type == "oauth":
                console.print(f"[red]OAuth setup failed: {exc}[/red]")
                raise typer.Exit(1)
            auth_provider = None  # auto-discovery failed, fall back to static headers
        if auth_provider is not None:
            headers = (
                {k: v for k, v in srv.headers.items() if k.lower() != "authorization"}
                if srv.headers
                else None
            )
        else:
            try:
                resolved = _asyncio.run(_resolve_auth_headers_for_test(srv, cfg))
                headers = {**srv.headers, **resolved} if (srv.headers or resolved) else None
            except Exception as exc:
                console.print(f"[red]Auth resolution failed: {exc}[/red]")
                raise typer.Exit(1)

    sys.stdout.write(f"Connecting (timeout {timeout:.0f}s) ")
    sys.stdout.flush()

    ok, msg, tools = _test_mcp_server(
        name,
        command=srv.command,
        args=srv.args if srv.args else None,
        url=srv.url,
        headers=headers,
        auth=auth_provider,
        timeout=timeout,
    )

    print()  # newline after dots
    if ok:
        console.print(f"[green]OK[/green] — {msg}")
        if show_tools and tools:
            from rich.table import Table as RichTable

            table = RichTable(title=f"Tools ({len(tools)})")
            table.add_column("Name", style="bold")
            table.add_column("Description")
            for tool in tools:
                table.add_row(tool.get("name", "?"), tool.get("description", "")[:80])
            console.print(table)
    else:
        console.print(f"[red]FAILED[/red] — {msg}")
        if srv.is_agency:
            console.print(f"[dim]Try running manually: agency mcp {name}[/dim]")
        raise typer.Exit(1)


async def _resolve_auth_headers_for_test(srv: Any, cfg: Any) -> dict[str, str]:
    """Resolve auth headers for the test command."""
    from workpilot.mcp.auth import resolve_auth_headers

    return await resolve_auth_headers(srv, cfg.providers)


def _refresh_path() -> None:
    """Refresh PATH so a just-installed binary can be found."""

    if sys.platform == "win32":
        try:
            r = subprocess.run(
                [
                    "powershell",
                    "-NoProfile",
                    "-Command",
                    '[System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + '
                    '[System.Environment]::GetEnvironmentVariable("Path","User")',
                ],
                capture_output=True,
                text=True,
                timeout=10,
            )
            if r.returncode == 0 and r.stdout.strip():
                os.environ["PATH"] = r.stdout.strip()
        except Exception:
            pass
    else:
        # Append common install directories if not already in PATH
        for d in ("~/.local/bin", "~/bin", "/usr/local/bin"):
            expanded = os.path.expanduser(d)
            if os.path.isdir(expanded) and expanded not in os.environ.get("PATH", ""):
                os.environ["PATH"] = expanded + os.pathsep + os.environ.get("PATH", "")


def _ensure_agency_installed(raise_on_failure: bool = True) -> str | None:
    """Check for Agency CLI binary; auto-install if missing.

    Returns binary path on success.
    If ``raise_on_failure`` is False, prints a warning and returns None instead
    of raising (used by init so the rest of setup continues uninterrupted).
    """

    def _fail(msg: str) -> str | None:
        console.print(f"[yellow]{msg}[/yellow]")
        if raise_on_failure:
            raise typer.Exit(1)
        console.print("Run [cyan]wp mcp add-agency[/cyan] to install manually.")
        return None

    agency_bin = shutil.which("agency")
    if agency_bin:
        return agency_bin

    console.print("[yellow]Agency CLI not found in PATH.[/yellow]")
    console.print("Attempting auto-install...")

    if sys.platform == "win32":
        cmd = [
            "powershell",
            "-NoProfile",
            "-Command",
            'iex "& { $(irm https://aka.ms/InstallTool.ps1)} agency"',
        ]
        manual = 'iex "& { $(irm https://aka.ms/InstallTool.ps1)} agency"'
    else:
        dl = "curl -sSfL" if shutil.which("curl") else "wget -qO-"
        if not shutil.which(dl.split()[0]):
            return _fail("Neither curl nor wget found.")
        cmd = ["sh", "-c", f"{dl} https://aka.ms/InstallTool.sh | sh -s agency"]
        manual = f"{dl} https://aka.ms/InstallTool.sh | sh -s agency"

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
    except subprocess.TimeoutExpired:
        return _fail(f"Install timed out. Manual install:\n  {manual}")

    if result.returncode != 0:
        if result.stderr.strip():
            console.print(f"[dim]{result.stderr.strip()[:500]}[/dim]")
        return _fail(f"Install failed. Manual install:\n  {manual}")

    _refresh_path()

    agency_bin = shutil.which("agency")
    if not agency_bin:
        return _fail(
            "Agency installed but not found in PATH. Please restart your terminal and retry."
        )

    console.print(f"[green]Agency installed: {agency_bin}[/green]")
    return agency_bin


def _discover_agency_servers(agency_bin: str) -> list[tuple[str, str]]:
    """Run `agency mcp --help` and parse available servers.

    Returns list of (name, description) tuples.
    """

    try:
        result = subprocess.run(
            [agency_bin, "mcp", "--help"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        help_text = result.stdout + result.stderr
    except Exception as exc:
        console.print(f"[red]Failed to run 'agency mcp --help': {exc}[/red]")
        raise typer.Exit(1)

    skip = {
        "help",
        "remote",
        "local",
        "npx",
        "calculator",
        "stack",
        "msft-learn",  # already provided as a built-in HTTP MCP entry in workpilot.yaml
    }
    discovered: list[tuple[str, str]] = []
    in_commands = False
    for line in help_text.splitlines():
        stripped = line.strip()
        if stripped.startswith("Commands:"):
            in_commands = True
            continue
        if stripped.startswith("Options:"):
            in_commands = False
            continue
        if in_commands and stripped:
            parts = stripped.split(None, 1)
            if parts and parts[0] not in skip:
                name = parts[0]
                desc = parts[1].strip() if len(parts) > 1 else ""
                # Clean up common prefixes from descriptions
                for prefix in ("Launch ", "Launch a "):
                    if desc.startswith(prefix):
                        desc = desc[len(prefix) :]
                        break
                # Use curated description if available, else cleaned help text
                desc = _AGENCY_DESCRIPTIONS.get(name, desc)
                discovered.append((name, desc))

    return discovered


# Servers that need extra CLI arguments
_AGENCY_SERVER_PARAMS: dict[str, dict[str, str]] = {
    "ado": {"--organization": "ADO org name (e.g. microsoft)"},
    "bluebird": {
        "--org": "ADO org name (e.g. microsoft)",
        "--project": "ADO project name",
        "--repository": "ADO repository name",
    },
    "kusto": {"--service-uri": "Kusto cluster URL"},
}

# Default values for server params
_AGENCY_PARAM_DEFAULTS: dict[str, dict[str, str]] = {
    "ado": {"--organization": "microsoft"},
    "bluebird": {"--org": "microsoft"},
    "kusto": {"--service-uri": "https://kusto.aria.microsoft.com"},
}


# Servers not pre-selected in interactive mode (niche, most users don't need)
_AGENCY_NOT_RECOMMENDED = frozenset({"athena", "cloudbuild"})

# Servers that use npx/uvx (need package download — longer timeout)
_AGENCY_PACKAGE_SERVERS = frozenset({"ado", "kusto", "workiq"})


def _detect_ado_org() -> str | None:
    """Try to detect ADO org from current git remote."""

    try:
        result = subprocess.run(
            ["git", "remote", "get-url", "origin"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        url = result.stdout.strip()
        # https://dev.azure.com/org/project or https://org.visualstudio.com/project
        if "dev.azure.com" in url:
            parts = url.split("dev.azure.com/")
            if len(parts) > 1:
                org = parts[1].split("/")[0]
                if org:
                    return org
        elif "visualstudio.com" in url:
            host = url.split("//")[1].split("/")[0] if "//" in url else ""
            org = host.split(".")[0] if host else ""
            if org:
                return org
    except Exception:
        pass
    return None


def _resolve_server_args(name: str) -> list[str]:
    """Prompt user for required server args, using defaults where available."""
    params = _AGENCY_SERVER_PARAMS.get(name, {})
    defaults = _AGENCY_PARAM_DEFAULTS.get(name, {})
    args: list[str] = []

    # Special handling for ADO: auto-detect org from git remote
    if name in ("ado", "bluebird"):
        detected_org = _detect_ado_org()
        if detected_org:
            console.print(f"    [dim]Detected ADO org: {detected_org}[/dim]")
            if name == "ado":
                defaults = {**defaults, "--organization": detected_org}
            else:
                defaults = {**defaults, "--org": detected_org}

    for flag, desc in params.items():
        default = defaults.get(flag, "")
        prompt = f"    {flag} ({desc})"
        if default:
            prompt += f" [{default}]"
        prompt += ": "
        val = console.input(prompt).strip() or default
        if val:
            args.extend([flag, val])
        else:
            return []  # user skipped

    return args


def _test_agency_server(
    agency_bin: str, name: str, extra_args: list[str] | None = None
) -> tuple[bool, str]:
    """Test an Agency MCP server using the same MCPClient used at runtime.

    Timeout: 90s for HTTP proxy servers, 180s for npx/uvx servers.
    """
    timeout = 180 if name in _AGENCY_PACKAGE_SERVERS else 90
    args = ["mcp", name] + (extra_args or [])
    ok, msg, _tools = _test_mcp_server(name, command=agency_bin, args=args, timeout=timeout)
    if not ok and "timeout" not in msg:
        # Preserve original error truncation for add-agency display
        if "required arguments" in msg.lower():
            msg = msg.split("\n")[-1].strip()[:80]
        else:
            msg = msg[:80]
    elif not ok:
        msg = f"timeout ({timeout}s) — try: agency mcp {name}"
    return ok, msg


# Curated agency descriptions resolved from workpilot.mcp.defaults (imported at top).


def _run_add_agency(
    config_dir: Path,
    *,
    select_all: bool = False,
    dry_run: bool = False,
    skip_test: bool = False,
    raise_on_failure: bool = True,
) -> dict[str, dict[str, Any]] | None:
    """Core add-agency logic shared by ``init`` and ``mcp add-agency``."""

    # 1. Ensure Agency CLI + discover servers
    agency_bin = _ensure_agency_installed(raise_on_failure=raise_on_failure)
    if agency_bin is None:
        return None
    console.print(f"Using agency: {agency_bin}")

    discovered = _discover_agency_servers(agency_bin)
    if not discovered:
        console.print("[yellow]No MCP servers found.[/yellow]")
        return None

    # 2. Filter already-configured (merged base + local)
    try:
        existing = set(_load_config_safe(str(config_dir)).tools.mcp_servers.keys())
    except Exception:
        existing = set()

    # Use existing local file if present; otherwise default to .yaml extension
    local_path = next(
        (
            config_dir / c
            for c in ("workpilot.local.yaml", "workpilot.local.yml")
            if (config_dir / c).exists()
        ),
        config_dir / "workpilot.local.yaml",
    )
    local_raw = (_load_yaml(local_path) if local_path.is_file() else {}) or {}
    tools_val = local_raw.get("tools")
    tools_sec: dict[str, Any] = tools_val if isinstance(tools_val, dict) else {}
    local_raw["tools"] = tools_sec
    mcp_val = tools_sec.get("mcp_servers")
    mcp_sec: dict[str, Any] = mcp_val if isinstance(mcp_val, dict) else {}
    tools_sec["mcp_servers"] = mcp_sec

    known = existing | set(mcp_sec.keys())
    if known:
        console.print(
            f"[dim]Already configured: {', '.join(n for n, _ in discovered if n in known)}[/dim]"
        )

    # 3. Select servers — show ALL discovered (including already-installed)
    if select_all:
        # --all adds servers not already configured and not requiring extra params
        selected = [
            n
            for n, _ in discovered
            if n not in known
            and n not in _AGENCY_SERVER_PARAMS
            and n not in _AGENCY_NOT_RECOMMENDED
        ]
        if not selected:
            console.print(
                "[dim]No servers to add (already configured or require manual setup).[/dim]\n"
                "  Use [bold]wp mcp add-agency[/bold] (without --all) to pick interactively."
            )
            return None
    else:
        selected = _interactive_select(discovered, known)

    if not selected:
        console.print("No servers selected.")
        return None
    if dry_run:
        console.print(f"\n[dim]--dry-run: would add {len(selected)}: {', '.join(selected)}[/dim]")
        return None

    # 4. Install each server
    total = len(selected)
    if skip_test:
        console.print(f"\nAdding {total} servers [dim](skipping auth test)...[/dim]\n")
    else:
        console.print(f"\nInstalling {total} servers [dim](verifying auth)...[/dim]\n")

    added: dict[str, dict[str, Any]] = {}
    auth_pending: list[str] = []

    for idx, name in enumerate(selected, 1):
        sys.stdout.write(f"  [{idx}/{total}] {name:20s} ")
        sys.stdout.flush()

        # Resolve extra args
        extra_args = _resolve_extra_args(name, select_all)
        if extra_args is None:
            print("skipped")
            continue

        # Test auth
        if skip_test:
            print("added")
        else:
            timeout = 180 if name in _AGENCY_PACKAGE_SERVERS else 90
            sys.stdout.write(f"testing (up to {timeout}s) ")
            sys.stdout.flush()
            ok, info = _test_agency_server(agency_bin, name, extra_args or None)
            if ok:
                print(f" OK  {info}")
            else:
                print(" added (auth pending)")
                auth_pending.append(name)

        # Write entry — description is NOT persisted; resolved at runtime
        # from workpilot.mcp.defaults when config has no explicit description.
        entry: dict[str, Any] = {"command": "agency", "args": ["mcp", name] + extra_args}
        # Risk scoring is handled by mcp_risk_policy in workpilot.yaml
        # (per-tool scores + _rules). Don't write server-level risk here
        # as it would override the fine-grained policy scores.
        added[name] = entry
        mcp_sec[name] = entry
        _save_mcp_servers(local_path, mcp_sec)

    # Summary
    if added:
        console.print(f"\n[green]Added {len(added)} MCP servers to {local_path}.[/green]")
    if auth_pending:
        console.print("[yellow]Auth pending — run to complete login:[/yellow]")
        for n in auth_pending:
            console.print(f"  agency mcp {n}")

    return added or None


def _interactive_select(
    available: list[tuple[str, str]], known: set[str] | None = None
) -> list[str]:
    """Show interactive checkbox for server selection.

    Pre-selects recommended servers (no required params, not niche).
    Already-installed servers are shown but not pre-selected.
    Uses arrow-key navigation in a real terminal, numbered fallback otherwise.
    """
    known = known or set()
    items = [(n, d) for n, d in available]
    selected: set[str] = {
        n
        for n, _ in items
        if n not in _AGENCY_SERVER_PARAMS and n not in _AGENCY_NOT_RECOMMENDED and n not in known
    }

    from workpilot.cli.init import _is_tty

    if _is_tty():
        try:
            return _multiselect_arrows(items, selected, known)
        except Exception:
            pass
    return _multiselect_numbered(items, selected, known)


def _multiselect_arrows(
    items: list[tuple[str, str]],
    selected: set[str],
    known: set[str],
) -> list[str]:
    """Arrow-key multi-select with space-to-toggle. Returns list of selected names."""
    import sys

    from workpilot.cli.init import _read_key

    cur = 0
    n = len(items)
    max_name = max(len(name) for name, _ in items)
    # lines: header + blank + n items + blank + hint = n + 4
    total_lines = n + 4

    def _render(first: bool = False) -> None:
        out = sys.stdout
        if not first:
            out.write(f"\033[{total_lines}A")
        count = len(selected)
        out.write(f"\033[2K  \033[1mAgency MCP servers\033[0m \033[90m({count} selected)\033[0m\n")
        out.write("\n")
        for i, (name, desc) in enumerate(items):
            check = "\033[32m\u2713\033[0m" if name in selected else " "
            pad = name.ljust(max_name)
            tags = ""
            if name in _AGENCY_SERVER_PARAMS:
                tags += "  \033[90m(needs config)\033[0m"
            if name in known:
                tags += "  \033[90m(installed)\033[0m"
            if i == cur:
                line = f"  [{check}] \033[1;36m{pad}\033[0m  \033[90m{desc}\033[0m{tags}"
            else:
                line = f"  [{check}] {pad}  \033[90m{desc}\033[0m{tags}"
            out.write(f"\033[2K{line}\n")
        out.write("\n")
        out.write(
            "\033[2K  \033[90m\u2191\u2193 navigate \u00b7"
            " space toggle \u00b7 a all \u00b7 n none \u00b7 enter confirm\033[0m\n"
        )
        out.flush()

    sys.stdout.write("\033[?25l")  # hide cursor
    try:
        _render(first=True)
        while True:
            key = _read_key()
            if key in ("up", "k"):
                cur = (cur - 1) % n
                _render()
            elif key in ("down", "j"):
                cur = (cur + 1) % n
                _render()
            elif key == " ":
                name = items[cur][0]
                selected ^= {name}
                _render()
            elif key == "a":
                selected.clear()
                selected.update(name for name, _ in items if name not in known)
                _render()
            elif key == "n":
                selected.clear()
                _render()
            elif key == "enter":
                # Erase the rendered menu
                sys.stdout.write(f"\033[{total_lines}A")
                for _ in range(total_lines):
                    sys.stdout.write("\033[2K\n")
                sys.stdout.write(f"\033[{total_lines}A")
                sys.stdout.flush()
                result = [name for name, _ in items if name in selected]
                if result:
                    console.print(
                        f"  [green]\u2713[/green] {len(result)} server(s): {', '.join(result)}"
                    )
                else:
                    console.print("  [dim]No servers selected[/dim]")
                return result
            elif key.isdigit():
                idx = int(key) - 1
                if 0 <= idx < n:
                    cur = idx
                    selected ^= {items[idx][0]}
                    _render()
    finally:
        sys.stdout.write("\033[?25h\033[0m")
        sys.stdout.flush()


def _multiselect_numbered(
    items: list[tuple[str, str]],
    selected: set[str],
    known: set[str],
) -> list[str]:
    """Numbered checkbox fallback for non-TTY. Returns list of selected names."""
    console.print(f"\nAvailable Agency MCP servers ({len(items)}):")
    console.print(
        "[dim]Enter numbers to toggle, 'a' for all new, 'n' for none, Enter to confirm.[/dim]"
    )
    if known:
        console.print("[dim]To remove an installed server:  wp mcp remove <name>[/dim]\n")
    else:
        console.print()

    while True:
        for i, (n, d) in enumerate(items, 1):
            mark = "[green]x[/green]" if n in selected else " "
            installed_tag = " [dim](installed)[/dim]" if n in known else ""
            config_tag = " [dim](needs config)[/dim]" if n in _AGENCY_SERVER_PARAMS else ""
            console.print(f"  [{mark}] {i:2d}. {n:20s} {d}{config_tag}{installed_tag}")

        choice = (
            console.input(
                f"\n[bold]Toggle ([cyan]1-{len(items)}[/cyan],"
                f" [cyan]a[/cyan]ll, [cyan]n[/cyan]one) or Enter:[/bold] "
            )
            .strip()
            .lower()
        )

        if not choice:
            break
        elif choice == "a":
            selected.clear()
            selected.update(n for n, _ in items if n not in known)
        elif choice == "n":
            selected.clear()
        else:
            for p in choice.replace(",", " ").split():
                try:
                    idx = int(p) - 1
                    if 0 <= idx < len(items):
                        selected ^= {items[idx][0]}
                except ValueError:
                    pass
        console.print()

    return [n for n, _ in items if n in selected]


def _resolve_extra_args(name: str, use_defaults: bool) -> list[str] | None:
    """Resolve extra CLI args for servers that need them.

    Returns [] for no-param servers, list of args, or None if user skips.
    """
    if name not in _AGENCY_SERVER_PARAMS:
        return []

    if use_defaults:
        args: list[str] = []
        for flag, val in _AGENCY_PARAM_DEFAULTS.get(name, {}).items():
            args.extend([flag, val])
        return args or None

    print("configuring...")
    return _resolve_server_args(name) or None


@mcp_app.command("login")
def mcp_login(
    name: str = typer.Argument(..., help="MCP server name"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Authenticate with an OAuth-protected MCP server.

    Opens a browser for authorization and stores tokens locally.
    """
    import asyncio as _asyncio

    cfg = _load_config_safe(config)
    srv = cfg.tools.mcp_servers.get(name)
    if srv is None:
        console.print(f"[red]MCP server '{name}' not found in config.[/red]")
        raise typer.Exit(1)
    if not srv.url:
        console.print(f"[red]MCP server '{name}' uses stdio — OAuth login is not applicable.[/red]")
        raise typer.Exit(1)

    async def _login() -> None:
        import httpx

        from workpilot.mcp.oauth_provider import create_oauth_auth

        provider = await create_oauth_auth(name, srv, cfg.providers)
        if provider is None:
            console.print(
                f"[yellow]MCP server '{name}' uses static bearer auth. "
                "No OAuth login needed.[/yellow]"
            )
            return

        # Trigger the OAuth flow via a JSON-RPC POST (matches MCP protocol).
        # MCP servers expect POST; GET may return 404/405 without a 401 challenge.
        extra_headers = {
            k: v for k, v in (srv.headers or {}).items() if k.lower() != "authorization"
        }
        async with httpx.AsyncClient(auth=provider, headers=extra_headers, timeout=60.0) as client:
            payload = {
                "jsonrpc": "2.0",
                "id": "mcp-login-probe",
                "method": "initialize",
                "params": {"capabilities": {}},
            }
            resp = await client.post(srv.url, json=payload)  # type: ignore[arg-type]
            from workpilot.mcp.oauth_storage import MCPTokenStorage

            has_token = await MCPTokenStorage(name).get_tokens() is not None
            if has_token:
                console.print(f"[green]Authenticated with '{name}'.[/green] Token stored.")
            elif resp.status_code < 400:
                console.print(
                    f"[dim]Server returned {resp.status_code} without requiring auth. "
                    "No OAuth token needed.[/dim]"
                )
            else:
                console.print(
                    f"[yellow]Server returned {resp.status_code}. "
                    "Authentication may have failed — try 'mcp test'.[/yellow]"
                )

    try:
        _asyncio.run(_login())
    except Exception as exc:
        console.print(f"[red]OAuth login failed: {exc}[/red]")
        raise typer.Exit(1)


@mcp_app.command("logout")
def mcp_logout(
    name: str = typer.Argument(..., help="MCP server name"),
) -> None:
    """Remove stored OAuth tokens for an MCP server."""
    from workpilot.mcp.oauth_storage import MCPTokenStorage

    storage = MCPTokenStorage(name)
    storage.clear()
    console.print(f"[green]Removed OAuth tokens for '{name}'.[/green]")


@mcp_app.command("add-agency")
def mcp_add_agency(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
    all_servers: bool = typer.Option(
        False, "--all", help="Add all discovered servers without prompting"
    ),
    skip_test: bool = typer.Option(
        False, "--skip-test", help="Skip auth testing (add without verifying)"
    ),
    dry_run: bool = typer.Option(
        False, "--dry-run", help="Show what would be added without writing"
    ),
) -> None:
    """Auto-discover Agency MCP servers and add them to the config.

    Shows an interactive selection with recommended servers pre-selected.
    Use --all to skip the prompt and add everything.
    Use --skip-test to skip auth verification (faster, no timeout waits).
    """
    config_path = _resolve_config_path(config)
    result = _run_add_agency(
        config_dir=config_path.parent,
        select_all=all_servers,
        skip_test=skip_test,
        dry_run=dry_run,
    )
    if result is None and not dry_run:
        raise typer.Exit(0)
