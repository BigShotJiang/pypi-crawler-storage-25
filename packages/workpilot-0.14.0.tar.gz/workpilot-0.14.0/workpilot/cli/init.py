"""Init CLI command — workpilot init."""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Any

import typer
from rich.panel import Panel
from rich.table import Table

from workpilot.cli.commands import (
    app,
    console,
)

_TOTAL_STEPS = 6


# ── Modern interactive selection ──────────────────────────────────────────────


def _step_header(n: int, label: str) -> None:
    """Print step header: ``[1/5] Label``."""
    console.print(f"\n[bold cyan][{n}/{_TOTAL_STEPS}][/bold cyan] [bold]{label}[/bold]")


def _step_done(value: str) -> None:
    """Print a completed step result with green checkmark."""
    console.print(f"  [green]\u2713[/green] {value}")


def _is_tty() -> bool:
    """Return True if running in a real terminal (not piped/test)."""
    try:
        return sys.stdin.isatty() and sys.stdout.isatty()
    except Exception:
        return False


def _read_key() -> str:
    """Read a single keypress. Returns ``'up'``, ``'down'``, ``'enter'``, or the character."""
    if sys.platform == "win32":
        import msvcrt

        ch = msvcrt.getwch()
        if ch in ("\x00", "\xe0"):
            ch2 = msvcrt.getwch()
            return {"H": "up", "P": "down"}.get(ch2, "")
        if ch == "\r":
            return "enter"
        if ch == "\x03":
            raise KeyboardInterrupt
        return ch
    else:
        import termios
        import tty

        fd = sys.stdin.fileno()
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch = sys.stdin.read(1)
            if ch == "\x1b":
                ch2 = sys.stdin.read(1)
                ch3 = sys.stdin.read(1)
                if ch2 == "[":
                    return {"A": "up", "B": "down"}.get(ch3, "")
                return ""
            if ch in ("\r", "\n"):
                return "enter"
            if ch == "\x03":
                raise KeyboardInterrupt
            return ch
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)


def _select(
    options: list[tuple[str, str]],
    *,
    default: int = 1,
) -> int:
    """Show a selection menu and return the 1-based chosen index.

    Uses arrow-key navigation in a real terminal. Falls back to numbered
    input in non-TTY environments (tests, piped stdin).
    """
    if _is_tty():
        try:
            return _select_arrows(options, default=default - 1) + 1
        except Exception:
            pass
    return _select_numbered(options, default=default)


def _select_arrows(
    options: list[tuple[str, str]],
    *,
    default: int = 0,
) -> int:
    """Inline arrow-key radio selector. Returns 0-based index.

    Renders options with ``\u25cf`` / ``\u25cb`` markers, then erases itself
    after the user presses Enter — leaving the cursor right below the
    step header so the caller can print a result line.
    """
    cur = default
    n = len(options)
    max_label = max(len(label) for label, _ in options)
    # lines rendered: blank + n options + blank + hint = n + 3
    total_lines = n + 3

    def _render(first: bool = False) -> None:
        out = sys.stdout
        if not first:
            out.write(f"\033[{total_lines}A")
        out.write("\n")
        for i, (label, desc) in enumerate(options):
            pad = label.ljust(max_label)
            if i == cur:
                line = f"  \033[36m\u25cf\033[0m \033[1m{pad}\033[0m"
            else:
                line = f"  \033[90m\u25cb {pad}\033[0m"
            if desc:
                line += f"  \033[90m\u2014 {desc}\033[0m"
            out.write(f"\033[2K{line}\n")
        out.write("\n\033[2K  \033[90m\u2191\u2193 navigate \u00b7 enter confirm\033[0m\n")
        out.flush()

    sys.stdout.write("\033[?25l")  # hide cursor
    try:
        _render(first=True)
        while True:
            key = _read_key()
            if key in ("up", "k"):
                cur = (cur - 1) % n
                _render()
            elif key in ("down", "j"):
                cur = (cur + 1) % n
                _render()
            elif key == "enter":
                # Erase the rendered menu
                sys.stdout.write(f"\033[{total_lines}A")
                for _ in range(total_lines):
                    sys.stdout.write("\033[2K\n")
                sys.stdout.write(f"\033[{total_lines}A")
                sys.stdout.flush()
                return cur
            elif key.isdigit():
                idx = int(key) - 1
                if 0 <= idx < n:
                    cur = idx
                    _render()
    finally:
        sys.stdout.write("\033[?25h\033[0m")  # show cursor, reset attrs
        sys.stdout.flush()


def _select_numbered(
    options: list[tuple[str, str]],
    *,
    default: int = 1,
) -> int:
    """Numbered fallback for non-TTY (tests, piped input). Returns 1-based index."""
    for i, (label, desc) in enumerate(options, 1):
        marker = " *" if i == default else ""
        if desc:
            console.print(f"  [bold]{i}.[/bold] {label}  [dim]\u2014 {desc}[/dim]{marker}")
        else:
            console.print(f"  [bold]{i}.[/bold] {label}{marker}")
    while True:
        raw = typer.prompt(f"Select [1-{len(options)}]", default=str(default))
        try:
            choice = int(raw)
            if 1 <= choice <= len(options):
                return choice
        except ValueError:
            pass
        console.print(f"  [yellow]Please enter 1\u2013{len(options)}[/yellow]")


# ── Utilities ─────────────────────────────────────────────────────────────────


def _check_connectivity() -> bool:
    """Return True if github.com is reachable (quick HEAD check)."""
    try:
        import httpx

        with httpx.Client(timeout=5) as http:
            resp = http.head("https://github.com")
            return resp.status_code < 500
    except Exception:
        return False


def _show_environment(shutil: Any) -> None:
    """Detect and display installed tools during init."""
    import platform

    tools = ["git", "gh", "node", "az", "agency", "claude"]

    detected: list[str] = []
    for tool_name in tools:
        if shutil.which(tool_name):
            detected.append(f"[green]{tool_name}[/green]")

    plat = f"{platform.system()} {platform.machine()}"
    console.print(f"[bold]Environment:[/bold] {plat}\n[bold]Tools:[/bold] {', '.join(detected)}\n")


def _detect_github_context() -> tuple[bool, list[str]]:
    """Detect whether the user likely uses GitHub.

    Returns ``(is_developer, reasons)`` where *reasons* lists what was found.
    """
    import shutil

    reasons: list[str] = []

    # 1. git / gh CLI installed
    if shutil.which("git"):
        reasons.append("git installed")
    if shutil.which("gh"):
        reasons.append("gh CLI installed")

    # 2. GITHUB_TOKEN set
    if os.environ.get("GITHUB_TOKEN"):
        reasons.append("$GITHUB_TOKEN set")

    # 3. gh auth token available (check even if git/gh CLI found)
    if not any("gh CLI" in r for r in reasons):
        try:
            import subprocess

            r = subprocess.run(["gh", "auth", "token"], capture_output=True, text=True, timeout=5)
            if r.returncode == 0 and r.stdout.strip():
                reasons.append("gh auth token available")
        except Exception:
            pass

    # 4. .git in cwd or parents
    cwd = Path.cwd()
    for p in [cwd, *cwd.parents]:
        if (p / ".git").exists():
            reasons.append(f".git found in {p}")
            break
        if p == p.parent:
            break

    # 5. Dev project files in cwd
    dev_files = ["package.json", "pyproject.toml", "Cargo.toml", "go.mod", "pom.xml", "Makefile"]
    for f in dev_files:
        if (cwd / f).exists():
            reasons.append(f"{f} in cwd")
            break

    # 6. ~/.gitconfig
    if (Path.home() / ".gitconfig").exists():
        reasons.append("~/.gitconfig exists")

    return bool(reasons), reasons


# ── Main init command ─────────────────────────────────────────────────────────


@app.command()
def init(
    directory: str | None = typer.Option(
        None, "--dir", "-d", help="Target directory (default: ~/.workpilot)"
    ),
    name: str | None = typer.Option(
        None, "--name", "-n", help="Project name (sets top-level 'name' in config)"
    ),
    quick: bool = typer.Option(False, "--quick", "-q", help="Accept all defaults, no prompts"),
) -> None:
    """Create or update the local config override (workpilot.local.yaml).

    By default this writes to ``~/.workpilot/workpilot.local.yaml``.
    Safe to run multiple times \u2014 existing values are shown as defaults
    so you only change what you want. Use --quick to accept all defaults.
    """
    import shutil

    import yaml

    dir_path = (Path.home() / ".workpilot") if directory is None else Path(directory).resolve()
    dir_path.mkdir(parents=True, exist_ok=True)

    local_path = dir_path / "workpilot.local.yaml"

    # Load existing config to use as defaults
    existing: dict = {}
    is_update = local_path.exists()
    if is_update:
        try:
            loaded = yaml.safe_load(local_path.read_text(encoding="utf-8"))
            existing = loaded if isinstance(loaded, dict) else {}
        except Exception:
            existing = {}

    # ── Environment detection ─────────────────────────────────────────
    _show_environment(shutil)

    if quick:
        console.print("[dim]--quick mode: accepting all defaults[/dim]\n")
    else:
        action = "Update" if is_update else "Create"
        console.print(
            Panel(
                f"[bold]WorkPilot Setup[/bold]\n\n"
                f"{'Updating' if is_update else 'Creating'} [cyan]{local_path}[/cyan]",
                title=f"{action} workpilot.local.yaml",
                border_style="blue",
            )
        )

    # ── [1/5] GitHub token ────────────────────────────────────────────
    raw_token: str = (existing.get("providers") or {}).get("github_copilot", {}).get(
        "token", ""
    ) or ""
    # A SECRET[…] or ${…} reference means a token is configured but resolved at runtime.
    has_configured_token = bool(raw_token)
    current_token = "" if raw_token.startswith(("${", "SECRET[")) else raw_token

    github_token: str | None = None
    if quick:
        if raw_token:
            # Preserve existing token reference (SECRET[…] / ${…} / plaintext) as-is
            github_token = None
        else:
            env_token = os.environ.get("GITHUB_TOKEN")
            if env_token:
                console.print(
                    "[yellow]Note:[/yellow] Using $GITHUB_TOKEN from environment (plaintext).\n"
                    "  For better security, run:"
                    " [bold]wp secrets set GITHUB_COPILOT_TOKEN[/bold]"
                )
            github_token = env_token or "${GITHUB_TOKEN}"
    elif current_token:
        _step_header(1, "GitHub Copilot (LLM Provider)")
        console.print(f"  [dim]Current token: {current_token[:8]}...[/dim]")
        _GH_REAUTH_OPTS: list[tuple[str, str]] = [
            ("Keep current token", ""),
            ("Re-authenticate with GitHub", "opens browser, paste a code to authorize"),
        ]
        choice = _select(_GH_REAUTH_OPTS, default=1)
        _step_done(_GH_REAUTH_OPTS[choice - 1][0])
        if choice == 2:
            with console.status("[bold cyan]Checking connectivity\u2026"):
                online = _check_connectivity()
            if online:
                from workpilot.security.github_auth import github_device_login

                try:
                    github_token = github_device_login(console=console)
                except Exception as exc:
                    console.print(f"  [yellow]GitHub sign-in failed:[/yellow] {exc}")
                    github_token = current_token
            else:
                console.print(
                    "  [yellow]Cannot reach github.com \u2014 keeping current token[/yellow]"
                )
                github_token = current_token
        else:
            github_token = current_token
    else:
        _step_header(1, "GitHub Copilot (LLM Provider)")
        if has_configured_token:
            if raw_token.startswith("SECRET["):
                console.print("  [dim]Already configured (SecretStore)[/dim]")
            elif raw_token.startswith("${"):
                console.print("  [dim]Already configured (environment variable)[/dim]")
            else:
                console.print("  [dim]Already configured[/dim]")
        _GH_NEW_OPTS: list[tuple[str, str]] = [
            ("Sign in with GitHub", "opens browser, paste a code to authorize"),
            ("Skip", "keep current" if has_configured_token else "configure later"),
        ]
        choice = _select(_GH_NEW_OPTS, default=2 if has_configured_token else 1)
        _step_done(_GH_NEW_OPTS[choice - 1][0])
        if choice == 1:
            with console.status("[bold cyan]Checking connectivity\u2026"):
                online = _check_connectivity()
            if online:
                from workpilot.security.github_auth import github_device_login

                try:
                    github_token = github_device_login(console=console)
                except Exception as exc:
                    console.print(f"  [yellow]GitHub sign-in failed:[/yellow] {exc}")
            else:
                console.print(
                    "  [yellow]Cannot reach github.com \u2014 skipping GitHub auth.[/yellow]\n"
                    "  Run [bold]wp init[/bold] again when online."
                )
        # choice == 2: skip, github_token stays None

    # ── [2/5] Security profile ────────────────────────────────────────
    _PROFILES: list[tuple[str, str]] = [
        ("open", "full autonomy, no approvals"),
        ("standard", "medium-risk needs approval"),
        ("controlled", "Risk Scorer reviews all tool calls"),
        ("restricted", "human approval for everything"),
    ]
    _PROFILE_NAMES = [p[0] for p in _PROFILES]

    current_profile: str = (existing.get("security") or {}).get("profile", "standard") or "standard"
    if quick:
        security_profile = current_profile
    else:
        _step_header(2, "Security Profile")
        default_idx = (
            (_PROFILE_NAMES.index(current_profile) + 1) if current_profile in _PROFILE_NAMES else 2
        )
        choice = _select(_PROFILES, default=default_idx)
        security_profile = _PROFILE_NAMES[choice - 1]
        _step_done(security_profile)

    # ── [3/5] Web channel (web server) ────────────────────────────────
    current_gw: dict = (existing.get("channels") or {}).get("web") or existing.get("gateway") or {}
    current_gw_enabled: bool = bool(current_gw.get("enabled", True))
    if quick:
        enable_web = current_gw_enabled
    else:
        web_port = current_gw.get("port", 3003)
        _step_header(3, f"Web UI (localhost:{web_port})")
        _WEB_OPTS: list[tuple[str, str]] = [("Enable", ""), ("Disable", "")]
        choice = _select(_WEB_OPTS, default=1 if current_gw_enabled else 2)
        enable_web = choice == 1
        _step_done("enabled" if enable_web else "disabled")

    # ── [4/5] Cloud channel (Teams, Web Chat) ─────────────────────────
    current_cloud: dict = (existing.get("channels") or {}).get("cloud") or {}
    current_cloud_enabled: bool = bool(current_cloud.get("enabled", True))
    if quick:
        enable_cloud = current_cloud_enabled
    else:
        _step_header(4, "Cloud Connection (Teams, Web Chat)")
        _CLOUD_OPTS: list[tuple[str, str]] = [("Enable", ""), ("Disable", "")]
        choice = _select(_CLOUD_OPTS, default=1 if current_cloud_enabled else 2)
        enable_cloud = choice == 1
        _step_done("enabled" if enable_cloud else "disabled")

    # Auto-check Teams app when cloud is enabled
    if enable_cloud and not quick:
        from workpilot.cli.teams import is_teams_installed

        if is_teams_installed():
            console.print("  [green]\u2713[/green] Teams app already installed")
        elif not _is_tty():
            console.print(
                "  [dim]Teams app not detected; run"
                " [cyan]wp teams install[/cyan] to install it later.[/dim]"
            )
        else:
            console.print(
                "\n  [dim]Teams app not detected \u2014 starting sideload install\u2026[/dim]"
            )
            try:
                from workpilot.cli.teams import teams_install as _teams_install

                _teams_install(package=None)
            except KeyboardInterrupt:
                console.print("  [dim]Teams install skipped by user.[/dim]")
            except typer.Exit as exc:
                if getattr(exc, "exit_code", 1) == 0:
                    console.print("  [dim]Teams install skipped.[/dim]")
                else:
                    console.print(
                        "  [yellow]Warning:[/yellow] Teams install failed;"
                        " cloud features may not work.\n"
                        "  [dim]Run [cyan]wp teams install[/cyan] to retry.[/dim]"
                    )

    # ── Build config (deep-merge: preserve existing keys, update changed ones) ──
    local_config: dict = dict(existing)  # start from existing

    if name:
        local_config["name"] = name

    local_config.setdefault("providers", {}).setdefault("github_copilot", {})
    if github_token and not github_token.startswith("${"):
        # New real token — store in SecretStore, write reference in YAML
        try:
            from workpilot.security.secrets import set_secret

            set_secret("GITHUB_COPILOT_TOKEN", github_token)
            local_config["providers"]["github_copilot"]["token"] = "SECRET[GITHUB_COPILOT_TOKEN]"
            console.print("  [green]\u2713[/green] Token stored in SecretStore")
        except Exception as exc:
            console.print(
                f"  [yellow]Warning:[/yellow] SecretStore unavailable ({exc}).\n"
                "  Token will be stored as plaintext in workpilot.local.yaml."
            )
            local_config["providers"]["github_copilot"]["token"] = github_token
    elif github_token:
        # Explicit "${GITHUB_TOKEN}" env-var reference
        local_config["providers"]["github_copilot"]["token"] = github_token
    elif raw_token:
        # User skipped — preserve existing reference (SECRET[…] / ${…} / plaintext)
        local_config["providers"]["github_copilot"]["token"] = raw_token
    else:
        # No token at all — fallback to env-var reference
        local_config["providers"]["github_copilot"]["token"] = "${GITHUB_TOKEN}"

    local_config.setdefault("security", {})
    local_config["security"]["profile"] = security_profile

    local_config.setdefault("logging", {"level": "INFO", "format": "pretty"})

    gw = local_config.setdefault("channels", {}).setdefault("web", {})
    gw["enabled"] = enable_web
    if enable_web:
        gw.setdefault("host", "localhost")
        gw.setdefault("port", current_gw.get("port", 3003))

    cloud = local_config.setdefault("channels", {}).setdefault("cloud", {})
    cloud["enabled"] = enable_cloud

    # ── [5/6] GitHub MCP ───────────────────────────────────────────────
    github_mcp_enabled: bool | None = None  # None = no change
    github_mcp_device_login: bool = False  # True if device code login succeeded
    existing_mcp = (existing.get("tools") or {}).get("mcp_servers") or {}
    github_mcp_configured = "github" in existing_mcp

    if quick:
        pass  # leave as-is
    else:
        is_dev, dev_reasons = _detect_github_context()
        _step_header(5, "GitHub MCP (repos, PRs, issues, code search)")

        if is_dev:
            console.print(f"  [dim]Detected: {', '.join(dev_reasons[:3])}[/dim]")

        # Check if a token is already available (gh CLI or env or secret store)
        from workpilot.mcp.auth import _resolve_gh_cli_token

        has_token = bool(os.environ.get("GITHUB_TOKEN") or _resolve_gh_cli_token())
        if not has_token:
            try:
                from workpilot.security.secrets import get_secret_store

                has_token = bool(get_secret_store().get("GITHUB_TOKEN"))
            except Exception:
                pass

        github_mcp_disabled = github_mcp_configured and not existing_mcp.get("github", {}).get(
            "enabled", True
        )

        if github_mcp_configured:
            if github_mcp_disabled:
                console.print("  [dim]Currently disabled[/dim]")
            elif has_token:
                console.print("  [dim]Configured, token available[/dim]")
            else:
                console.print("  [yellow]Configured but no token found[/yellow]")

        # Build options: 1. keep (if configured) 2. use existing token 3. device code 4. disable
        _GH_MCP_OPTS: list[tuple[str, str]] = []
        if github_mcp_configured and not github_mcp_disabled and has_token:
            _GH_MCP_OPTS.append(("Keep current config", "token available"))
        if has_token and not (github_mcp_configured and not github_mcp_disabled):
            _GH_MCP_OPTS.append(("Use existing token", "from gh CLI or $GITHUB_TOKEN"))
        _GH_MCP_OPTS.append(("Sign in with GitHub", "device code flow — opens browser"))
        _GH_MCP_OPTS.append(("Disable", "recommended" if not is_dev else "skip GitHub integration"))

        default_gh = 1  # keep / use existing token / device code
        if not is_dev and not has_token:
            default_gh = len(_GH_MCP_OPTS)  # default to Disable

        choice = _select(_GH_MCP_OPTS, default=default_gh)
        selected = _GH_MCP_OPTS[choice - 1][0]
        _step_done(selected)

        if selected == "Keep current config":
            pass  # github_mcp_enabled stays None = no change
        elif selected == "Use existing token":
            github_mcp_enabled = True
            console.print("  [green]\u2713[/green] GitHub token ready")
        elif selected == "Sign in with GitHub":
            github_mcp_enabled = True
            with console.status("[bold cyan]Checking connectivity\u2026"):
                online = _check_connectivity()
            if online:
                try:
                    from workpilot.mcp.auth import _GH_CLI_CLIENT_ID, _GH_MCP_SCOPE
                    from workpilot.security.github_auth import github_device_login

                    token = github_device_login(
                        client_id=_GH_CLI_CLIENT_ID,
                        scope=_GH_MCP_SCOPE,
                        console=console,
                    )
                    try:
                        from workpilot.security.secrets import get_secret_store

                        get_secret_store().set("GITHUB_TOKEN", token)
                        github_mcp_device_login = True
                        console.print("  [green]\u2713[/green] GitHub token saved to SecretStore")
                    except Exception:
                        pass
                except Exception as exc:
                    console.print(f"  [yellow]GitHub login failed:[/yellow] {exc}")
                    console.print("  [dim]Run [cyan]gh auth login[/cyan] later.[/dim]")
            else:
                console.print(
                    "  [yellow]Cannot reach github.com[/yellow] \u2014 "
                    "run [cyan]gh auth login[/cyan] later."
                )
        else:  # Disable
            github_mcp_enabled = False

    # Apply GitHub MCP config to local yaml.
    if github_mcp_device_login:
        # Device code login succeeded — write auth reference so config is visible
        mcp_section = local_config.setdefault("tools", {}).setdefault("mcp_servers", {})
        mcp_section["github"] = {"auth": {"type": "bearer", "token": "SECRET[GITHUB_TOKEN]"}}
    elif github_mcp_enabled is False:
        mcp_section = local_config.setdefault("tools", {}).setdefault("mcp_servers", {})
        mcp_section["github"] = {"enabled": False}

    # ── [6/6] Agency MCP servers ──────────────────────────────────────
    mcp_added: dict[str, Any] = {}
    if quick:
        install_mcp = True
        mcp_mode = "all"
    else:
        _step_header(6, "Agency MCP Servers (ICM, ADO, EngHub, Kusto, \u2026)")
        _MCP_OPTS: list[tuple[str, str]] = [
            ("Install recommended servers", "auto-select and test"),
            ("Choose servers interactively", "pick from list"),
            ("Skip", "configure later via wp mcp add-agency"),
        ]
        choice = _select(_MCP_OPTS, default=1)
        _step_done(_MCP_OPTS[choice - 1][0])
        install_mcp = choice != 3
        mcp_mode = "all" if choice == 1 else "interactive"

    if install_mcp:
        from workpilot.cli.mcp import _run_add_agency

        added = _run_add_agency(
            config_dir=dir_path,
            select_all=(mcp_mode == "all"),
            skip_test=quick,
            raise_on_failure=False,
        )
        if added:
            mcp_added = added
            mcp_section = local_config.setdefault("tools", {}).setdefault("mcp_servers", {})
            mcp_section.update(added)

    from workpilot.config.loader import save_yaml

    header = (
        "# WorkPilot local config override\n"
        "# This file is gitignored \u2014 use it for API keys, model preferences,\n"
        "# and local settings that should not be committed.\n"
        "# Values here are deep-merged on top of workpilot.yaml.\n"
        "\n"
    )
    save_yaml(local_path, local_config, header=header)

    verb = "Updated" if is_update else "Created"
    console.print(f"\n  [green]\u2713[/green] [bold]{verb}[/bold] {local_path}")

    # ── Summary (especially useful for --quick mode) ──────────────────
    if quick:
        summary = Table(show_header=False, box=None, padding=(0, 2))
        summary.add_column(style="bold")
        summary.add_column()

        token_ref = local_config.get("providers", {}).get("github_copilot", {}).get("token", "")
        if token_ref == "SECRET[GITHUB_COPILOT_TOKEN]":
            provider_desc = "GitHub Copilot (SecretStore)"
        elif token_ref.startswith("${"):
            provider_desc = f"GitHub Copilot ({token_ref})"
        elif token_ref:
            provider_desc = "GitHub Copilot (token set)"
        else:
            provider_desc = "not configured"
        summary.add_row("Provider", provider_desc)
        summary.add_row("Profile", security_profile)
        web_port = gw.get("port", 3003)
        summary.add_row("Web UI", f"enabled (:{web_port})" if enable_web else "disabled")
        summary.add_row("Cloud", "enabled" if enable_cloud else "disabled")
        summary.add_row("MCP", f"{len(mcp_added)} server(s) added" if mcp_added else "none added")

        console.print(Panel(summary, title="Quick Setup Summary", border_style="cyan"))

    # ── Completion ────────────────────────────────────────────────────
    console.print(
        Panel(
            "[bold]Next steps:[/bold]\n"
            "  wp s              \u2014 start the server\n"
            "  wp chat           \u2014 start chatting\n"
            "  wp doctor         \u2014 verify setup\n"
            "  wp mcp add-agency \u2014 add more MCP servers",
            title="\u2728 Setup Complete",
            border_style="green",
        )
    )


# Backward-compat alias (hidden, not in help)
app.command("onboard", hidden=True)(init)
