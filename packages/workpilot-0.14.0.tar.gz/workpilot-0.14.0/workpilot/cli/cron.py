"""Cron CLI subcommands — workpilot cron list|add|remove|enable|disable|status|history|info."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import typer
from rich.table import Table

from workpilot.cli.commands import (
    _load_config_safe,
    console,
    cron_app,
)
from workpilot.utils.helpers import get_data_dir


def _cron_dir() -> Path:
    """Resolve cron data dir (same path as SchedulerService)."""
    return get_data_dir() / "cron"


def _make_service(config: str = ".") -> Any:
    """Create a SchedulerService for CLI operations (not running, just CRUD)."""
    from workpilot.cron.service import SchedulerService

    cfg = _load_config_safe(config)
    return SchedulerService(cfg.cron)


def _load_jobs() -> list[dict[str, Any]]:
    """Load dynamic jobs from jobs.json (same file SchedulerService uses)."""
    jobs_file = _cron_dir() / "jobs.json"
    if not jobs_file.is_file():
        return []
    try:
        data: list[dict[str, Any]] = json.loads(jobs_file.read_text(encoding="utf-8"))
        return data
    except Exception:
        return []


@cron_app.command("list")
def cron_list(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """List cron jobs."""
    cfg = _load_config_safe(config)

    if not cfg.cron.enabled:
        console.print("[dim]Cron service is disabled.[/dim]")
        console.print("  Set [bold]cron.enabled: true[/bold] in workpilot.yaml")
        return

    svc = _make_service(config)
    jobs = svc.list_jobs()
    if not jobs:
        console.print("[dim]No cron jobs.[/dim]")
        return

    table = Table(title="Cron Jobs")
    table.add_column("Name", style="bold")
    table.add_column("Schedule")
    table.add_column("Mode")
    table.add_column("Content")
    table.add_column("Deliver to")
    table.add_column("Enabled")

    for job in jobs:
        mode = job.get("mode", "prompt")
        content = job.get("message") or job.get("prompt") or job.get("tool", "")
        content_preview = content[:50] + "..." if len(content) > 50 else content
        deliver = ", ".join(job.get("notify_channels", ["*"]))
        table.add_row(
            job["name"],
            str(job["schedule"]),
            mode,
            content_preview,
            deliver,
            "[green]yes[/green]" if job.get("enabled", True) else "[red]no[/red]",
        )

    console.print(table)


@cron_app.command("add")
def cron_add(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Add a cron job interactively. Use 'workpilot chat' for richer job creation."""
    console.print(
        "[yellow]For full job creation with message/prompt/tool modes and notify_channels, "
        "use:[/yellow]\n"
        "  [bold]wp chat[/bold] → ask the agent to create a cron job\n"
    )
    console.print("[dim]Quick add (prompt mode only):[/dim]")

    name: str = typer.prompt("Job name")
    schedule: str = typer.prompt("Schedule (e.g. '0 9 * * *', 'at:+300', '3600')")
    prompt: str = typer.prompt("Prompt (intent for LLM agent)")

    cfg = _load_config_safe(config)
    if not cfg.cron.enabled:
        console.print("[yellow]Warning: cron is disabled. Enable with cron.enabled: true[/yellow]")

    svc = _make_service(config)
    try:
        svc.add_job(name=name, schedule=schedule, prompt=prompt, dynamic=True)
    except ValueError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(1)

    console.print(f"  [green]\u2713[/green] Job [bold]{name}[/bold] added")
    console.print(
        "[dim]Restart your Workpilot server (stop it and re-run 'wp serve') to pick up the new job.[/dim]"
    )


@cron_app.command("remove")
def cron_remove(
    job_id: str = typer.Argument(..., help="Job name to remove"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
) -> None:
    """Remove a cron job."""
    svc = _make_service(config)
    if not yes:
        typer.confirm(f"Remove job '{job_id}'?", abort=True)
    try:
        svc.remove_job(job_id)
    except ValueError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(1)
    console.print(f"  [green]\u2713[/green] Removed job [bold]{job_id}[/bold]")


@cron_app.command("enable")
def cron_enable(
    job_id: str = typer.Argument(..., help="Job name to enable"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Enable a disabled cron job."""
    svc = _make_service(config)
    try:
        svc.enable(job_id)
    except ValueError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(1)
    console.print(f"  [green]\u2713[/green] Enabled job [bold]{job_id}[/bold]")


@cron_app.command("disable")
def cron_disable(
    job_id: str = typer.Argument(..., help="Job name to disable"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Disable a cron job without removing it."""
    svc = _make_service(config)
    try:
        svc.disable(job_id)
    except ValueError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(1)
    console.print(f"  [dim]\u2713[/dim] Disabled job [bold]{job_id}[/bold]")


@cron_app.command("info")
def cron_info(
    job_id: str = typer.Argument(..., help="Job name"),
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Show details for a single cron job."""
    svc = _make_service(config)
    jobs = svc.list_jobs()
    job = next((j for j in jobs if j["name"] == job_id), None)
    if not job:
        console.print(f"[red]Job not found:[/red] {job_id}")
        raise typer.Exit(1)

    mode = job.get("mode", "prompt")
    deliver = ", ".join(job.get("notify_channels", ["*"]))

    table = Table(title=f"Job: {job_id}")
    table.add_column("Field", style="bold")
    table.add_column("Value")
    table.add_row("Schedule", f"{job['trigger_type']} ({job['schedule']})")
    table.add_row("Mode", mode)
    table.add_row("Deliver to", deliver)
    table.add_row("Enabled", "yes" if job.get("enabled", True) else "no")
    table.add_row("Failures", str(job.get("failure_count", 0)))

    if mode == "message":
        table.add_row("Content", job.get("message", ""))
    elif mode == "prompt":
        table.add_row("Prompt", job.get("prompt", ""))
    elif mode == "tool":
        table.add_row("Tool", job.get("tool", ""))
        table.add_row("Arguments", json.dumps(job.get("arguments", {})))

    console.print(table)


@cron_app.command("status")
def cron_status(
    config: str = typer.Option(".", "--config", "-c", help="Config file or directory"),
) -> None:
    """Show scheduler health and job counts."""
    cfg = _load_config_safe(config)
    enabled = cfg.cron.enabled
    jobs = _load_jobs()
    enabled_count = sum(1 for j in jobs if j.get("enabled", True))

    table = Table(title="Cron Status")
    table.add_column("Field", style="bold")
    table.add_column("Value")
    table.add_row("Enabled", "[green]yes[/green]" if enabled else "[red]no[/red]")
    table.add_row("Total jobs", str(len(jobs)))
    table.add_row("Enabled jobs", str(enabled_count))
    table.add_row("Disabled jobs", str(len(jobs) - enabled_count))
    console.print(table)


@cron_app.command("history")
def cron_history(
    job_id: str | None = typer.Argument(None, help="Job name (omit for all jobs)"),
    lines: int = typer.Option(20, "--lines", "-n", help="Max entries to show per job"),
) -> None:
    """Show execution history for cron jobs."""
    runs_dir = _cron_dir() / "runs"
    if not runs_dir.exists():
        console.print("[dim]No cron run history found.[/dim]")
        return

    files = sorted(runs_dir.glob("*.jsonl"))
    if job_id:
        safe = job_id.replace("/", "_").replace(":", "_")
        files = [f for f in files if f.stem == safe or f.stem == job_id]
        if not files:
            console.print(f"[red]No history for job:[/red] {job_id}")
            return

    for path in files:
        records = []
        for line in path.read_text(encoding="utf-8").splitlines():
            if line.strip():
                try:
                    records.append(json.loads(line))
                except Exception:
                    pass
        records = records[-lines:]
        if not records:
            continue

        table = Table(title=f"Job: {path.stem}")
        table.add_column("Run ID", style="dim")
        table.add_column("Started")
        table.add_column("Status")
        table.add_column("Duration")
        table.add_column("Result preview")
        for r in records:
            status = r.get("status", "?")
            colour = "green" if status == "success" else "red"
            table.add_row(
                r.get("run_id", "?")[:12],
                r.get("triggered_at", "?")[:19],
                f"[{colour}]{status}[/{colour}]",
                f"{r.get('duration_s', 0):.1f}s",
                (r.get("result_preview") or r.get("error", ""))[:60],
            )
        console.print(table)
