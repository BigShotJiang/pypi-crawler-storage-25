"""
Git tool — version control operations within the workspace.
"""

from __future__ import annotations

import asyncio
import re
from typing import Any

from workpilot.agent.tools.base import Tool, ToolMetadata
from workpilot.security.risk import RiskAssessment, RiskPrompt, RiskScore
from workpilot.security.sandbox import Sandbox

# ── Git risk classification patterns ─────────────────────────────────────────

# Score 0: Pure read, no state change
_GIT_READ_OPS = re.compile(
    r"^(status|log|diff|show|blame|shortlog|describe|ls-files|ls-tree|rev-parse"
    r"|branch\s*$|branch\s+-[avrl]|remote\s*$|remote\s+-v|tag\s*$|tag\s+-l"
    r"|fetch|clean\s+-n|clean\s+--dry-run)\b",
    re.IGNORECASE,
)
# Score 2: Trivial local setup
_GIT_TRIVIAL = re.compile(r"^(init|clone)\b", re.IGNORECASE)
# Score 3: Local write (reversible, limited scope)
_GIT_LOCAL_WRITE = re.compile(
    r"^(add|commit|stash|checkout|switch|restore|merge|rebase|cherry-pick"
    r"|pull|config|tag\s+\S|reset(?!\s+--hard))\b",
    re.IGNORECASE,
)
# Score 4: Recoverable with effort (broader impact)
_GIT_MODERATE = re.compile(
    r"^(submodule|remote\s+(add|remove|rename|set-url))\b",
    re.IGNORECASE,
)
# git rm = local tracked-file removal, same as local write → 3
_GIT_RM = re.compile(r"^rm\b", re.IGNORECASE)
# branch -d (safe delete) = 4, branch -D (force delete) = 5
_GIT_BRANCH_DELETE = re.compile(r"^branch\s+-d\s", re.IGNORECASE)
_GIT_BRANCH_FORCE_DELETE = re.compile(r"^branch\s+-D\s")
# Score 5 (riskier than normal push / safe branch delete, but safer than --force)
_GIT_FORCE_WITH_LEASE = re.compile(r"push\s+.*--force-with-lease\b", re.IGNORECASE)
_GIT_PUSH_MAIN = re.compile(r"push\s+\S+\s+(main|master)\b", re.IGNORECASE)
# Score 8
_GIT_FORCE_PUSH = re.compile(r"push\s+.*(--force\s|--force$|-f\s|-f$)", re.IGNORECASE)
_GIT_HARD_RESET = re.compile(r"reset\s+--hard\b", re.IGNORECASE)
# Score 9
_GIT_CLEAN_FORCE = re.compile(r"clean\s+-[fd]*f", re.IGNORECASE)


class GitTool(Tool):
    risk_range = (0, 9)

    def __init__(self, sandbox: Sandbox) -> None:
        self._sandbox = sandbox

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(timeout=90, tier="standard")

    def assess_risk(self, args: dict[str, Any]) -> RiskAssessment:
        git_args = (args.get("args", "") or "").strip()
        if not git_args:
            return RiskScore(0, reason="Empty git command")
        # Dangerous ops first (order matters: force-with-lease before force)
        if _GIT_CLEAN_FORCE.search(git_args):
            return RiskScore(9, reason=f"Clean force: git {git_args}")
        if _GIT_FORCE_WITH_LEASE.search(git_args):
            return RiskScore(5, reason=f"Force-with-lease push: git {git_args}")
        if _GIT_FORCE_PUSH.search(git_args):
            return RiskScore(8, reason=f"Force push: git {git_args}")
        if _GIT_HARD_RESET.search(git_args):
            return RiskScore(8, reason=f"Hard reset: git {git_args}")
        # Read-only
        if _GIT_READ_OPS.match(git_args):
            return RiskScore(0, reason="Read-only git operation")
        # Push
        if _GIT_PUSH_MAIN.search(git_args):
            return RiskScore(6, reason="Push to main/master branch")
        if git_args.startswith("push"):
            return RiskScore(4, reason="Git push to remote")
        # Force-delete branch (case-sensitive -D)
        if _GIT_BRANCH_FORCE_DELETE.match(git_args):
            return RiskScore(5, reason=f"Force delete branch: git {git_args}")
        # Moderate: submodule, remote config, branch -d
        if _GIT_BRANCH_DELETE.match(git_args):
            return RiskScore(4, reason=f"Delete merged branch: git {git_args}")
        if _GIT_MODERATE.match(git_args):
            return RiskScore(4, reason=f"Git structural change: git {git_args}")
        if _GIT_RM.match(git_args):
            return RiskScore(3, reason=f"Remove tracked file: git {git_args}")
        # Local write (pull, commit, merge, rebase, config, reset --soft, etc.)
        if _GIT_LOCAL_WRITE.match(git_args):
            return RiskScore(3, reason="Local git write operation")
        # Trivial setup (init, clone)
        if _GIT_TRIVIAL.match(git_args):
            return RiskScore(2, reason=f"Git setup: git {git_args}")
        # Truly unknown — LLM fallback (should be rare now)
        return RiskPrompt(
            f"Git command: git {git_args}. Range: 2~6\n"
            f"Scoring factors:\n"
            f"  2: Setup or config (init, clone, config)\n"
            f"  3: Local write (commit, merge, rebase, stash)\n"
            f"  4: Structural change or push to personal branch\n"
            f"  5: Forceful shared-state change (force-with-lease, branch -D)\n"
            f"  6: Push to shared/protected branch (main, master)"
        )

    @property
    def name(self) -> str:
        return "git"

    @property
    def description(self) -> str:
        return "Run a git command."

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "args": {
                    "type": "string",
                    "description": (
                        "Git subcommand and arguments. "
                        "Common: status, diff, log, add, commit, branch, checkout, "
                        "merge, rebase, stash, tag, remote, fetch, pull, push. "
                        "Blocked: push --force, reset --hard, clean -f. "
                        "Example: 'log -5 --oneline'"
                    ),
                },
            },
            "required": ["args"],
        }

    _BLOCKED_SUBCOMMANDS = frozenset(
        {
            "push --force",
            "push -f",
            "reset --hard",
            "clean -f",
            "clean -fd",
        }
    )

    async def execute(self, **kwargs: Any) -> str:
        args_str: str = kwargs["args"]

        # Block dangerous git commands
        args_lower = args_str.lower().strip()
        for blocked in self._BLOCKED_SUBCOMMANDS:
            if args_lower.startswith(blocked):
                return f"BLOCKED: 'git {blocked}' is not allowed for safety"

        try:
            proc = await asyncio.create_subprocess_exec(
                "git",
                *args_str.split(),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=str(self._sandbox.workspace),
            )
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(), timeout=self.metadata.timeout
            )
            output_parts = []
            if stdout:
                output_parts.append(stdout.decode("utf-8", errors="replace"))
            if stderr:
                output_parts.append(stderr.decode("utf-8", errors="replace"))
            output = "\n".join(output_parts).strip() or "(no output)"
            if proc.returncode != 0:
                output = f"Exit code {proc.returncode}\n{output}"
            return output
        except TimeoutError:
            proc.kill()
            await proc.wait()
            return "Git command timed out"
        except Exception as exc:
            return f"Git error: {exc}"
