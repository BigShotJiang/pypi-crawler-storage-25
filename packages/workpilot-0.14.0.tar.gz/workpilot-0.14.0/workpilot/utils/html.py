"""HTML to Markdown conversion for rich text messages."""

from __future__ import annotations


def html_to_markdown(html: str) -> str:
    """Convert HTML to Markdown. Uses markdownify if available, else regex fallback."""
    try:
        import markdownify

        return markdownify.markdownify(html, strip=["img"]).strip()
    except ImportError:
        pass
    except Exception as exc:
        from loguru import logger

        logger.debug("markdownify failed, using regex fallback: {}", exc)
    return _regex_fallback(html)


def _regex_fallback(html: str) -> str:
    """Best-effort HTML->Markdown using regex (no external deps)."""
    import html as html_mod
    import re

    # Convert <a href="url">text</a> -> [text](url)
    text = re.sub(
        r'<a\s+[^>]*href=["\']([^"\']*)["\'][^>]*>(.*?)</a>',
        r"[\2](\1)",
        html,
        flags=re.IGNORECASE | re.DOTALL,
    )
    # <b>/<strong> -> ** (allow attributes)
    text = re.sub(
        r"<(b|strong)\b[^>]*>(.*?)</\1>", r"**\2**", text, flags=re.IGNORECASE | re.DOTALL
    )
    # <i>/<em> -> * (allow attributes)
    text = re.sub(r"<(i|em)\b[^>]*>(.*?)</\1>", r"*\2*", text, flags=re.IGNORECASE | re.DOTALL)
    # <br> -> newline
    text = re.sub(r"<br\s*/?>", "\n", text, flags=re.IGNORECASE)
    # <p>...</p> -> paragraph with blank line (allow attributes)
    text = re.sub(r"<p\b[^>]*>(.*?)</p>", r"\1\n\n", text, flags=re.IGNORECASE | re.DOTALL)
    # Strip remaining tags
    text = re.sub(r"<[^>]+>", "", text)
    # Decode HTML entities, then strip any tags that unescape may have reintroduced
    text = html_mod.unescape(text)
    text = re.sub(r"<[^>]+>", "", text)
    # Clean up whitespace
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()
