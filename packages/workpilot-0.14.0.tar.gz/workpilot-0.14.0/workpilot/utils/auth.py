"""Shared Entra ID token acquisition — used by CLI chat for web server auth."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from loguru import logger


def acquire_entra_token(
    *,
    tenant_id: str,
    client_id: str,
    scope: str | None = None,
) -> str | None:
    """Acquire an Entra ID token: silent from cache, then interactive.

    Uses the same MSAL cache as CloudChannel so a prior ``workpilot cloud``
    login is reused automatically.

    Returns the access token string, or None on failure.
    """
    import msal

    from workpilot.utils.helpers import get_auth_dir

    effective_scope = scope or f"{client_id}/access_as_user"
    cache_path = get_auth_dir() / f"token_cache_{client_id[:8]}.json"
    cache = msal.SerializableTokenCache()
    if cache_path.exists():
        try:
            from workpilot.security.secrets import decrypt_at_rest

            raw = decrypt_at_rest(cache_path.read_bytes())
            if raw:
                cache.deserialize(raw.decode("utf-8"))
        except Exception as exc:
            logger.warning("Corrupted MSAL cache at {} ({}); starting fresh", cache_path, exc)
            cache_path.unlink(missing_ok=True)

    app = msal.PublicClientApplication(
        client_id,
        authority=f"https://login.microsoftonline.com/{tenant_id}",
        token_cache=cache,
    )

    # 1. Silent (cached)
    accounts = app.get_accounts()
    result = None
    if accounts:
        result = app.acquire_token_silent([effective_scope], account=accounts[0])
        if result and "access_token" in result:
            logger.debug("Entra token acquired silently (cached)")
            _persist_cache(cache, cache_path)
            return str(result["access_token"])

    # 2. Interactive (browser PKCE)
    logger.info("Entra ID interactive login required")
    result = app.acquire_token_interactive([effective_scope], prompt="select_account")
    if result and "access_token" in result:
        _persist_cache(cache, cache_path)
        return str(result["access_token"])

    error = (
        result.get("error_description", result.get("error", "unknown")) if result else "no result"
    )
    logger.warning("Entra token acquisition failed: {}", error)
    return None


def _persist_cache(cache: Any, cache_path: Path) -> None:
    """Write MSAL cache to disk if changed, encrypting at rest."""
    if not (hasattr(cache, "has_state_changed") and cache.has_state_changed):
        return
    from workpilot.security.secrets import encrypt_at_rest, is_encrypted

    plaintext = cache.serialize().encode("utf-8")
    data = encrypt_at_rest(plaintext)
    # Don't overwrite encrypted cache with plaintext if key unavailable
    if data == plaintext and cache_path.exists():
        try:
            if is_encrypted(cache_path.read_bytes()):
                return
        except OSError:
            return  # can't read existing cache — don't risk overwriting
    from workpilot.security.secrets import _atomic_write_file

    _atomic_write_file(cache_path, data)
