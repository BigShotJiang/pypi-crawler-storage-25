#####################################################################
Changelog
#####################################################################

Version 0.49 (14 April 2026)
============================
- Rename 'survey_meth' to 'survey_method', but retain both spellings as separate columns, in elevation_surveys

Version 0.48 (24 March 2026)
============================
- Add 4 queries:
  - drillhole_deviation_summary
  - drillhole_deviation_survey_data
  - salinities_valid
  - salinities_valid_measured_during_monitoring

Version 0.47 (8 January 2026)
=============================
- Add petroleum_wells_summary and mineral_wells_summary for plugin
- Expand docstring for SAGeodataConnection.find_wells
- Return SQL to predefined query method docstrings
- Move changelog to separate file in docs
- Add all predefined query methods to documentation

Version 0.46 (2 January 2026)
=============================
- Add water_wells_summary and non_water_wells_summary as faster alternatives
  to wells_summary. Otherwise identical.

Version 0.45 (23 December 2025)
===============================
- Move from cx_Oracle to oracledb following upgrade to Oracle version in September in PIRSA to DEW migration

Version 0.23 (24/11/2023)
=========================
- Fix #2 - data_available query's salinities field incorrect - was counting only water chem. 
  Now counting salinity samples as well.

Version 0.14
============
- Add pressure fields to water_levels predefined query (#3)
