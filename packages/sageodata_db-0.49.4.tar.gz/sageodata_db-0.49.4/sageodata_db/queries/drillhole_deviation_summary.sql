select
    min_dip.drillhole_no as dh_no,                                         --col
    To_char(dh.map_100000_no)
                  || '-'
                  || To_char(dh.dh_seq_no) AS unit_hyphen,                 --col
         Trim(To_char(dh.obs_well_plan_code))
                  || Trim(To_char(dh.obs_well_seq_no, '000')) AS obs_no,   --col
         dh.dh_name                                           AS dh_name,  --col
         summ.aq_subaq                                        AS aquifer,  --col
    abs(min_dip.declin_from_horiz) as min_dip,        --col
    abs(surveys.avg_declin_from_horiz) as mean_dip,   --col
    dip_meas_methods_table.dip_meas_methods,          --col
    min_dip.declin_meas_no as min_dip_meas_no,        --col
    min_dip.declin_svy_depth as min_dip_survey_depth, --col
    surveys.max_survey_depth,                         --col
    surveys.count_survey_depths,                      --col
    surveys.avg_azimuth,                              --col
    azimuth_survey_types.azimuth_types                --col
from (
    with ranked_survey_data as (
        select drillhole_no,
               declin_meas_no,
               declin_svy_depth,
               declin_from_horiz,
               row_number() over (
                   partition by drillhole_no
                   order by declin_from_horiz desc
                ) as rn
        from dd_declin_meas
        where drillhole_no in {DH_NO} --arg DH_NO (sequence of int): drillhole numbers or a :class:`pandas.DataFrame` with a "dh_no" column
    ) select drillhole_no,
             declin_svy_depth,
             declin_meas_no,
             declin_from_horiz
    from ranked_survey_data
    where rn = 1 ) min_dip
join ( 
    select drillhole_no,
           avg(declin_from_horiz) as avg_declin_from_horiz,
           max(declin_svy_depth) as max_survey_depth,
           count(declin_svy_depth) as count_survey_depths,
           avg(azimuth) as avg_azimuth
    from dd_declin_meas
    where drillhole_no in {DH_NO} --arg DH_NO (sequence of int): drillhole numbers or a :class:`pandas.DataFrame` with a "dh_no" column
    group by drillhole_no) surveys
                           on min_dip.drillhole_no = surveys.drillhole_no
join ( 
    select drillhole_no,
           listagg(dip_meas_method, '+') within group (order by dip_meas_method) as dip_meas_methods
    from (
        select distinct drillhole_no,
                        m.declin_meas_method_code as dip_meas_method
        from dd_declin_meas m 
        left join dd_declin_meas_method v on m.declin_meas_method_code = v.declin_meas_method_code
        where drillhole_no in {DH_NO} --arg DH_NO (sequence of int): drillhole numbers or a :class:`pandas.DataFrame` with a "dh_no" column
        )
    group by drillhole_no) dip_meas_methods_table
                           on min_dip.drillhole_no = dip_meas_methods_table.drillhole_no
join ( 
    select drillhole_no,
           listagg(azimuth_type, ', ') within group (order by azimuth_type) as azimuth_types
    from (
        select distinct drillhole_no,
                        v.meas_type_desc as azimuth_type
        from dd_declin_meas m 
        left join dd_azimuth_meas_type v on m.azimuth_meas_type_code = v.meas_type_code
        where drillhole_no in {DH_NO} --arg DH_NO (sequence of int): drillhole numbers or a :class:`pandas.DataFrame` with a "dh_no" column
        )
    group by drillhole_no) azimuth_survey_types
                           on min_dip.drillhole_no = azimuth_survey_types.drillhole_no
join dd_drillhole dh on min_dip.drillhole_no = dh.drillhole_no
join dd_drillhole_summary summ on min_dip.drillhole_no = summ.drillhole_no
where dh.deletion_ind = 'N'