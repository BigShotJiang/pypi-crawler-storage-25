# Sanicode Performance Benchmarks

Benchmark results for the sanicode scan pipeline in degraded mode (AST pattern matching only, no LLM).

## Environment

| Property | Value |
|----------|-------|
| Platform | macOS-26.3-arm64-arm-64bit |
| Machine | arm64 (Apple Silicon) |
| CPU count | 14 |
| Python | 3.11.12 |
| Sanicode | 0.8.0 |
| LLM tier | none (degraded mode) |
| Timestamp | 2026-03-02T04:38:18Z |

## Summary

| Project | Git Ref | LOC | Files | Findings | Wall Clock (s) | Peak RSS (MB) | Throughput (LOC/s) |
|---------|---------|----:|------:|---------:|---------------:|--------------:|-------------------:|
| requests | v2.31.0 | 7,981 | 21 | 56 | 1.22 | 1.5 | 6,542 |
| flask | 3.0.3 | 12,722 | 34 | 91 | 1.86 | 14.2 | 6,839 |
| fastapi | 0.110.0 | 94,240 | 651 | 673 | 21.54 | 36.7 | 4,375 |
| django | 5.0.4 | 380,411 | 869 | 1,106 | 47.27 | 132.1 | 8,047 |

## Per-Stage Breakdown

Wall clock time per pipeline stage (seconds):

| Stage | requests | flask | fastapi | django |
|-------|----------:|------:|--------:|-------:|
| file_collection | 0.011 | 0.018 | 0.152 | 0.508 |
| graph_build | 0.287 | 0.374 | 3.114 | 9.362 |
| pattern_detection | 0.921 | 1.413 | 18.168 | 36.424 |
| compliance_enrichment | 0.001 | 0.001 | 0.002 | 0.002 |
| llm_graph_reasoning | 0.001 | 0.003 | 0.044 | 0.943 |
| content_policy | <0.001 | <0.001 | <0.001 | <0.001 |

The `llm_classification`, `llm_data_flow`, and `llm_compliance` stages are inactive in degraded mode and contribute negligible time.

`pattern_detection` dominates at 75–84% of wall time across all four projects. `graph_build` accounts for 14–24%. `file_collection` is under 1% for smaller projects and roughly 1% for django at 380K LOC.

## Performance Target

Target: scan 50,000 LOC of Python in under 30 seconds without an LLM configured.

The minimum required throughput is 50,000 / 30 = **1,667 LOC/s**. All four benchmark projects exceed this:

| Project | Throughput | Multiple of target |
|---------|----------:|-------------------:|
| requests | 6,542 LOC/s | 3.9× |
| flask | 6,839 LOC/s | 4.1× |
| fastapi | 4,375 LOC/s | 2.6× |
| django | 8,047 LOC/s | 4.8× |

Linear interpolation between the fastapi (94K LOC, 21.5s) and django (380K LOC, 47.3s) data points places 50K LOC at approximately 7–12 seconds. **Target: PASS.**

## Known Limitations

- Peak RSS reflects `ru_maxrss` high-water mark for the entire process. When multiple projects are scanned in sequence within a single run, per-project deltas become less accurate for later entries as resident memory is not released between scans.
- LOC counts exclude `tests/`, `test/`, `__pycache__/`, and `.git/` directories via the `--exclude` patterns applied during file collection.
- All results are degraded (AST-only) mode. No LLM-enabled comparison data exists yet; that requires a configured model endpoint with a suitable analysis or reasoning tier.
- The fastapi LOC figure (94K) includes `examples/` and `docs/` Python files beyond the core library, which inflates the count relative to the runtime surface area.

## Reproducing

```bash
python scripts/benchmark-scale.py -o research/bench-results.json
```
