#!/usr/bin/env bash
# Create an offline pip install bundle for RHEL 9.x hosts without internet.
#
# Run this script on a connected RHEL 9.x machine (or a compatible Linux host
# with Python 3.11). Transfer the resulting directory to the disconnected host
# and run install.sh there.
#
# Usage:
#   ./scripts/bundle-offline-pip.sh [version]
#
# Examples:
#   ./scripts/bundle-offline-pip.sh           # bundles 0.9.0
#   ./scripts/bundle-offline-pip.sh 0.10.0

set -euo pipefail

VERSION="${1:-0.9.0}"
BUNDLE_DIR="sanicode-offline-${VERSION}"

if [[ -d "${BUNDLE_DIR}" ]]; then
    echo "Bundle directory '${BUNDLE_DIR}' already exists. Remove it first."
    exit 1
fi

mkdir -p "${BUNDLE_DIR}/wheels"

echo "==> Downloading sanicode==${VERSION} and all dependencies as wheels"
echo "    Platform: manylinux2014_x86_64 (RHEL 9 / x86_64)"
echo "    Python:   3.11"
echo

# --platform + --only-binary=:all: restricts to pre-built binary wheels so the
# disconnected host never needs a compiler.  If a dependency lacks a binary
# wheel for this platform, the download will fail here — resolve it on the
# connected machine before transferring the bundle.
pip download "sanicode==${VERSION}" \
    --dest "${BUNDLE_DIR}/wheels" \
    --platform manylinux2014_x86_64 \
    --python-version 311 \
    --only-binary=:all:

# ---------------------------------------------------------------------------
# Install script embedded into the bundle so operators on the disconnected
# host have a single entry point.
# ---------------------------------------------------------------------------
cat > "${BUNDLE_DIR}/install.sh" <<'INSTALL_EOF'
#!/usr/bin/env bash
# Install sanicode from this offline bundle.
# Run as a user with write access to the Python installation, or with sudo.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "==> Installing sanicode from offline bundle..."
python3.11 -m pip install \
    --no-index \
    --find-links="${SCRIPT_DIR}/wheels" \
    sanicode

echo "==> Installation complete."
echo "    Version: $(sanicode --version)"
echo
echo "Configure your LLM endpoint:"
echo "    sanicode config"
echo "Or copy a sanicode.toml to: ~/.config/sanicode/config.toml"
INSTALL_EOF
chmod +x "${BUNDLE_DIR}/install.sh"

echo "==> Bundle created: ${BUNDLE_DIR}/"
echo
echo "    Contents:"
echo "      ${BUNDLE_DIR}/wheels/   — $(ls "${BUNDLE_DIR}/wheels/" | wc -l | tr -d ' ') wheel files"
echo "      ${BUNDLE_DIR}/install.sh"
echo
echo "Transfer the directory to the disconnected host (scp, rsync, USB, etc.),"
echo "then on that host:"
echo
echo "    cd ${BUNDLE_DIR} && ./install.sh"
