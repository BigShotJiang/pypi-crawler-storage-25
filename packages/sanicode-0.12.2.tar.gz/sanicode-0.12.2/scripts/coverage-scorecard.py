"""Generate a self-contained HTML coverage scorecard for sanicode rules.

Usage:
    python scripts/coverage-scorecard.py

Reads:
    - src/sanicode/rules/ via RuleRegistry (implemented rules)
    - data/planned_coverage.json (planned CWE x language pairs)

Writes:
    - docs/coverage-scorecard.html
"""

from __future__ import annotations

import json
import sys
from datetime import datetime, timezone
from pathlib import Path

# Resolve project root relative to this script's location.
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from sanicode.rules import get_rule_registry, init_rules  # noqa: E402

GITHUB_REPO = "https://github.com/rdwj/sanicode"

# ---------------------------------------------------------------------------
# Static reference data
# ---------------------------------------------------------------------------

CWE_TOP_25: list[int] = [
    787, 79, 89, 416, 78, 20, 125, 22, 352, 434,
    862, 476, 287, 190, 502, 77, 119, 798, 918, 306,
    362, 269, 94, 863, 400,
]

# CWE hierarchy: child CWE → Top 25 parent CWE.  Rules tagged with a child
# CWE also contribute coverage to the parent.  Only entries whose parent is
# in CWE_TOP_25 are needed here.
CWE_CHILD_TO_PARENT: dict[int, int] = {
    1333: 400,  # ReDoS is a sub-type of Uncontrolled Resource Consumption
    770: 400,   # Allocation Without Limits is a sub-type of Resource Consumption
    # Issue #134: TOCTOU variant
    367: 362,   # TOCTOU Race → Race Condition
    # Issue #138: path traversal variant tagging
    59: 22,     # Symlink Following → Path Traversal
    23: 22,     # Relative Path Traversal → Path Traversal
    35: 22,     # Path Traversal ('../') → Path Traversal
    73: 22,     # External File Path Control → Path Traversal
    98: 22,     # Include Path Control → Path Traversal
    # Issue #139: parent/variant compliance mapping
    77: 74,     # Command Injection → Injection
    327: 310,   # Weak Crypto → Cryptographic Issues
    # Issue #133: authorization hierarchy mappings
    862: 284,   # Missing Authorization → Improper Access Control
    863: 285,   # Incorrect Authorization → Improper Authorization
    # Issue #129: IDOR → Missing Authorization (Top 25)
    639: 862,   # IDOR → Missing Authorization
}

CWE_NAMES: dict[int, str] = {
    # CWE Top 25 (2024)
    787: "Out-of-bounds Write",
    79: "XSS",
    89: "SQL Injection",
    416: "Use After Free",
    78: "OS Command Injection",
    20: "Improper Input Validation",
    125: "Out-of-bounds Read",
    22: "Path Traversal",
    352: "CSRF",
    434: "Unrestricted Upload",
    862: "Missing Authorization",
    476: "NULL Pointer Deref",
    287: "Improper Authentication",
    190: "Integer Overflow",
    502: "Deserialization",
    77: "Command Injection",
    119: "Buffer Overflow",
    798: "Hardcoded Credentials",
    918: "SSRF",
    306: "Missing Authentication",
    362: "Race Condition",
    269: "Improper Privilege Mgmt",
    94: "Code Injection",
    863: "Incorrect Authorization",
    400: "Resource Consumption",
    # Non-Top-25 CWEs that appear in implemented rules or planned issues
    23: "Relative Path Traversal",
    35: "Path Traversal ('../')",
    59: "Symlink Following",
    73: "External File Path Control",
    74: "Injection",
    98: "Include Path Control",
    90: "LDAP Injection",
    120: "Buffer Copy Overflow",
    134: "Format String",
    200: "Information Exposure",
    201: "Sensitive Info in Response",
    209: "Error Detail Exposure",
    213: "Object Dump Exposure",
    242: "Dangerous Functions",
    248: "Uncaught Exception",
    250: "Unnecessary Privileges",
    252: "Unchecked Return Value",
    266: "Incorrect Privilege Assignment",
    276: "Incorrect Default Permissions",
    284: "Improper Access Control",
    285: "Improper Authorization",
    295: "Cert Validation",
    310: "Cryptographic Issues",
    327: "Weak Crypto",
    330: "Insufficient Randomness",
    338: "Weak PRNG",
    359: "PII Exposure in Logs",
    367: "TOCTOU Race",
    377: "Insecure Temp File",
    401: "Memory Leak",
    404: "Resource Shutdown",
    425: "Forced Browsing",
    426: "Untrusted Search Path",
    457: "Uninitialized Variable",
    474: "Use of Obsolete Function",
    494: "Download w/o Verification",
    532: "Log Injection",
    552: "Files/Dirs Accessible",
    598: "Sensitive GET Parameters",
    611: "XXE",
    639: "IDOR",
    668: "Resource Exposure",
    732: "Incorrect Permission Assignment",
    754: "Improper Exception Handling",
    770: "Allocation w/o Limits",
    829: "Untrusted Functionality Inclusion",
    843: "Type Confusion",
    913: "Collection Modification",
    915: "Mass Assignment",
    917: "Expression Language Injection",
    1321: "Prototype Pollution",
    1333: "ReDoS",
}

# Language display abbreviations, ordered: Python first, then alphabetical.
LANG_ORDER: list[str] = [
    "python",  # most rules — always first
    "bash", "c", "cobol", "cpp", "csharp", "fortran", "fsharp",
    "go", "java", "javascript", "julia", "kotlin", "lua", "matlab",
    "perl", "php", "r", "ruby", "rust", "scala", "sql",
]

LANG_ABBREV: dict[str, str] = {
    "python": "PY",
    "javascript": "JS",
    "go": "GO",
    "java": "JAVA",
    "php": "PHP",
    "ruby": "RB",
    "csharp": "C#",
    "c": "C",
    "cpp": "C++",
    "r": "R",
    "perl": "PERL",
    "fortran": "FORT",
    "matlab": "MAT",
    "julia": "JUL",
    "rust": "RUST",
    "kotlin": "KOT",
    "scala": "SCALA",
    "bash": "BASH",
    "sql": "SQL",
    "lua": "LUA",
    "fsharp": "F#",
    "cobol": "COBOL",
}


# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------

def load_implemented() -> dict[tuple[str, int], list[str]]:
    """Return mapping of (language, cwe_id) -> [rule_id, ...] from RuleRegistry."""
    init_rules()
    registry = get_rule_registry()
    result: dict[tuple[str, int], list[str]] = {}
    for rule in registry.all_rules():
        key = (rule.language, rule.cwe_id)
        result.setdefault(key, []).append(rule.rule_id)
    return result


def load_planned() -> tuple[dict[tuple[str, int], list[str]], dict[str, dict]]:
    """Return (cell_map, raw_data) from planned_coverage.json.

    cell_map: (language, cwe_id) -> [issue_number_str, ...]
    raw_data: the original JSON dict (issue_num_str -> entry)
    """
    planned_path = PROJECT_ROOT / "data" / "planned_coverage.json"
    with planned_path.open() as fh:
        raw: dict[str, dict] = json.load(fh)

    result: dict[tuple[str, int], list[str]] = {}
    for issue_num, entry in raw.items():
        cwes: list[int] = entry.get("cwes", [])
        languages: list[str] = entry.get("languages", [])
        for lang in languages:
            for cwe in cwes:
                key = (lang, cwe)
                result.setdefault(key, []).append(f"#{issue_num}")
    return result, raw


# ---------------------------------------------------------------------------
# HTML generation
# ---------------------------------------------------------------------------

CSS = """
* { box-sizing: border-box; margin: 0; padding: 0; }

body {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    background: #f5f5f5;
    color: #333;
    line-height: 1.4;
}

.page {
    max-width: 100%;
    margin: 0 auto;
    padding: 20px;
}

/* Header */
.header {
    background: #2c3e50;
    color: white;
    padding: 20px 24px;
    border-radius: 8px 8px 0 0;
    margin-bottom: 0;
}

.header h1 {
    font-size: 24px;
    font-weight: 600;
    letter-spacing: -0.3px;
}

.header .subtitle {
    font-size: 13px;
    color: #bdc3c7;
    margin-top: 4px;
}

/* Summary cards */
.summary-section {
    background: white;
    padding: 20px 24px;
    border-bottom: 1px solid #e0e0e0;
}

.stat-cards {
    display: flex;
    gap: 16px;
    flex-wrap: wrap;
    margin-bottom: 16px;
}

.stat-card {
    background: #f8f9fa;
    border: 1px solid #e0e0e0;
    border-radius: 6px;
    padding: 12px 20px;
    text-align: center;
    min-width: 120px;
}

.stat-card .number {
    font-size: 28px;
    font-weight: 700;
    color: #2c3e50;
    display: block;
}

.stat-card .label {
    font-size: 11px;
    color: #666;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-top: 2px;
}

/* Top 25 progress bar */
.top25-bar-container {
    margin-top: 12px;
}

.top25-label {
    font-size: 13px;
    font-weight: 600;
    color: #444;
    margin-bottom: 6px;
}

.progress-bar-track {
    background: #e0e0e0;
    border-radius: 4px;
    height: 20px;
    width: 100%;
    max-width: 480px;
    position: relative;
    overflow: hidden;
}

.progress-bar-fill {
    background: linear-gradient(90deg, #27ae60, #2ecc71);
    height: 100%;
    border-radius: 4px;
    display: flex;
    align-items: center;
    justify-content: flex-end;
    padding-right: 6px;
}

.progress-bar-fill span {
    font-size: 11px;
    font-weight: 700;
    color: white;
    white-space: nowrap;
}

/* Legend */
.legend {
    display: flex;
    gap: 20px;
    align-items: center;
    flex-wrap: wrap;
    margin-top: 16px;
    padding-top: 16px;
    border-top: 1px solid #eee;
}

.legend-item {
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: 12px;
    color: #555;
}

.legend-swatch {
    width: 18px;
    height: 18px;
    border-radius: 3px;
    border: 1px solid rgba(0,0,0,0.1);
    flex-shrink: 0;
}

.swatch-implemented { background: #c6efce; }
.swatch-planned     { background: #ffeb9c; }
.swatch-both        { background: #c6efce; position: relative; overflow: hidden; }
.swatch-both::after {
    content: "";
    position: absolute;
    bottom: 0;
    right: 0;
    width: 0;
    height: 0;
    border-style: solid;
    border-width: 0 0 8px 8px;
    border-color: transparent transparent #e6a817 transparent;
}
.swatch-empty       { background: #f9f9f9; }

/* Matrix table wrapper */
.matrix-section {
    background: white;
    padding: 0 0 24px 0;
}

.section-title {
    font-size: 16px;
    font-weight: 600;
    padding: 16px 24px 12px;
    color: #2c3e50;
    border-bottom: 1px solid #eee;
}

.table-wrapper {
    overflow-x: auto;
    overflow-y: auto;
    max-height: 75vh;
}

table {
    border-collapse: collapse;
    font-size: 12px;
    width: max-content;
    min-width: 100%;
}

th {
    background: #4472c4;
    color: white;
    font-weight: 600;
    padding: 6px 8px;
    border: 1px solid #3660b0;
    text-align: center;
    position: sticky;
    top: 0;
    z-index: 2;
    white-space: nowrap;
}

th.cwe-col-header {
    text-align: left;
    min-width: 220px;
    position: sticky;
    left: 0;
    z-index: 3;
    background: #4472c4;
}

td {
    padding: 4px 6px;
    border: 1px solid #ddd;
    text-align: center;
    min-width: 60px;
    vertical-align: top;
}

td.cwe-label {
    position: sticky;
    left: 0;
    background: white;
    z-index: 1;
    text-align: left;
    font-weight: 500;
    white-space: nowrap;
    min-width: 220px;
    color: #2c3e50;
    border-right: 2px solid #aaa;
}

td.cell-implemented {
    background: #c6efce;
    color: #006100;
}

td.cell-planned {
    background: #ffeb9c;
    color: #9c6500;
}

td.cell-both {
    background: #c6efce;
    color: #006100;
    position: relative;
}

td.cell-both::after {
    content: "";
    position: absolute;
    bottom: 0;
    right: 0;
    width: 0;
    height: 0;
    border-style: solid;
    border-width: 0 0 10px 10px;
    border-color: transparent transparent #e6a817 transparent;
}

td.cell-empty {
    background: #f9f9f9;
}

.cell-text {
    font-size: 11px;
    font-weight: 600;
    line-height: 1.3;
}

.rule-link {
    color: inherit;
    text-decoration: none;
}

.rule-link:hover {
    text-decoration: underline;
}

.issue-cell-link {
    color: inherit;
    text-decoration: none;
}

.issue-cell-link:hover {
    text-decoration: underline;
}

.planned-note {
    display: block;
    font-size: 9px;
    color: #9c6500;
    margin-top: 1px;
    font-weight: normal;
}

tr.section-header td {
    background: #e2efda;
    font-weight: bold;
    font-size: 13px;
    color: #375623;
    padding: 8px 12px;
    position: sticky;
    left: 0;
    z-index: 1;
    border-bottom: 2px solid #c6d9b5;
    text-align: left;
}

/* Issues table */
.issues-section {
    background: white;
    margin-top: 20px;
    border-radius: 0 0 8px 8px;
    padding-bottom: 24px;
}

.issues-section .section-title {
    border-radius: 0;
}

.issues-table-wrapper {
    padding: 0 24px;
}

.issues-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
}

.issues-table th {
    position: static;
    z-index: auto;
    background: #4472c4;
    border-color: #3660b0;
    text-align: left;
}

.issues-table td {
    text-align: left;
    min-width: unset;
    padding: 6px 10px;
    border-color: #e0e0e0;
}

.issues-table tr:nth-child(even) td {
    background: #f8f9fa;
}

.issue-link {
    color: #2c6fad;
    font-weight: 600;
    text-decoration: none;
}

.issue-link:hover {
    text-decoration: underline;
}

.cwe-tag {
    display: inline-block;
    background: #e8f0fe;
    color: #1a56b0;
    border-radius: 3px;
    padding: 1px 5px;
    font-size: 11px;
    margin: 1px;
    white-space: nowrap;
}

.lang-tag {
    display: inline-block;
    background: #f0f0f0;
    color: #444;
    border-radius: 3px;
    padding: 1px 5px;
    font-size: 11px;
    margin: 1px;
    white-space: nowrap;
}

/* Card container */
.card {
    background: white;
    border-radius: 8px;
    box-shadow: 0 1px 4px rgba(0,0,0,0.1);
    overflow: hidden;
    margin-bottom: 20px;
}

.footer {
    text-align: center;
    color: #999;
    font-size: 12px;
    padding: 16px 0 8px;
}
"""


def _cwe_label(cwe: int) -> str:
    name = CWE_NAMES.get(cwe, "Unknown")
    return f"CWE-{cwe}: {name}"


def _escape(text: str) -> str:
    return (
        text.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace('"', "&quot;")
    )


def _rule_link(rule_id: str, rule_sources: dict[str, str]) -> str:
    """Wrap a rule ID in a link to its source file on GitHub, if known."""
    rel_path = rule_sources.get(rule_id)
    if rel_path:
        url = f"{GITHUB_REPO}/blob/main/{rel_path}"
        return f'<a href="{_escape(url)}" class="rule-link">{_escape(rule_id)}</a>'
    return _escape(rule_id)


def _issue_link(issue_ref: str) -> str:
    """Wrap an issue reference like '#79' in a link to the GitHub issue."""
    num = issue_ref.lstrip("#")
    url = f"{GITHUB_REPO}/issues/{num}"
    return f'<a href="{_escape(url)}" class="issue-cell-link">{_escape(issue_ref)}</a>'


def _render_cell(
    impl_ids: list[str],
    plan_ids: list[str],
    rule_messages: dict[str, str],
    rule_sources: dict[str, str],
) -> str:
    """Return an HTML <td> element for one (language, cwe) cell."""
    has_impl = bool(impl_ids)
    has_plan = bool(plan_ids)

    if not has_impl and not has_plan:
        return '<td class="cell-empty"></td>'

    if has_impl and has_plan:
        css_class = "cell-both"
    elif has_impl:
        css_class = "cell-implemented"
    else:
        css_class = "cell-planned"

    # Build tooltip
    parts: list[str] = []
    if impl_ids:
        for rid in impl_ids:
            msg = rule_messages.get(rid, "")
            parts.append(f"{rid}: {msg}" if msg else rid)
    if plan_ids:
        parts.append("Planned: " + ", ".join(plan_ids))
    title = _escape(" | ".join(parts))

    # Cell text
    inner_parts: list[str] = []
    if impl_ids:
        links = ", ".join(_rule_link(rid, rule_sources) for rid in impl_ids)
        inner_parts.append(f'<span class="cell-text">{links}</span>')
    if plan_ids:
        links = ", ".join(_issue_link(ref) for ref in plan_ids)
        if has_impl:
            inner_parts.append(f'<span class="planned-note">+{links}</span>')
        else:
            inner_parts.append(f'<span class="cell-text">{links}</span>')

    inner = "\n".join(inner_parts)
    return f'<td class="{css_class}" title="{title}">{inner}</td>'


def render_html(
    implemented: dict[tuple[str, int], list[str]],
    planned: dict[tuple[str, int], list[str]],
    all_cwes: list[int],
    all_languages: list[str],
    planned_raw: dict[str, dict],
    rule_messages: dict[str, str],
    rule_sources: dict[str, str],
) -> str:
    """Generate the full self-contained HTML scorecard."""
    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

    # Summary stats
    total_rules = sum(len(v) for v in implemented.values())
    num_languages = len(all_languages)
    covered_cwes = {cwe for (_lang, cwe) in implemented}
    # Include parent CWEs covered via child rules (e.g., CWE-1333 → CWE-400).
    for child, parent in CWE_CHILD_TO_PARENT.items():
        if child in covered_cwes:
            covered_cwes.add(parent)
    num_covered_cwes = len(covered_cwes)

    top25_covered = sum(1 for cwe in CWE_TOP_25 if cwe in covered_cwes)
    top25_pct = round(top25_covered / len(CWE_TOP_25) * 100)
    bar_width = top25_pct

    # Split CWEs into Top 25 (ordered by rank) and others (sorted by ID)
    top25_set = set(CWE_TOP_25)
    top25_cwes = [cwe for cwe in CWE_TOP_25 if cwe in all_cwes]
    other_cwes = sorted(cwe for cwe in all_cwes if cwe not in top25_set)

    # Build column headers
    col_headers_html = '<th class="cwe-col-header">CWE</th>\n'
    for lang in all_languages:
        abbrev = LANG_ABBREV.get(lang, lang.upper()[:5])
        col_headers_html += f'<th title="{_escape(lang)}">{_escape(abbrev)}</th>\n'

    def render_section(cwes: list[int], section_label: str) -> str:
        html = (
            f'<tr class="section-header">'
            f'<td colspan="{1 + len(all_languages)}">{_escape(section_label)}</td>'
            f'</tr>\n'
        )
        for cwe in cwes:
            label = _cwe_label(cwe)
            row = f'<tr>\n<td class="cwe-label">{_escape(label)}</td>\n'
            for lang in all_languages:
                impl_ids = implemented.get((lang, cwe), [])
                plan_ids = planned.get((lang, cwe), [])
                row += _render_cell(impl_ids, plan_ids, rule_messages, rule_sources)
                row += "\n"
            row += "</tr>\n"
            html += row
        return html

    table_body = render_section(top25_cwes, "CWE Top 25 (2024) — ordered by rank")
    if other_cwes:
        table_body += render_section(other_cwes, "Other CWEs — sorted by ID")

    # Issues table
    issues_rows = ""
    for issue_num, entry in sorted(planned_raw.items(), key=lambda x: int(x[0])):
        title = _escape(entry.get("title", ""))
        cwes_list = entry.get("cwes", [])
        langs_list = entry.get("languages", [])
        cwe_tags = "".join(f'<span class="cwe-tag">CWE-{c}</span>' for c in cwes_list)
        lang_tags = "".join(f'<span class="lang-tag">{_escape(lang)}</span>' for lang in langs_list)
        if not cwe_tags:
            cwe_tags = '<span style="color:#aaa">—</span>'
        if not lang_tags:
            lang_tags = '<span style="color:#aaa">—</span>'
        issues_rows += (
            f"<tr>\n"
            f'<td><a class="issue-link" href="https://github.com/rdwj/sanicode/issues/{issue_num}">'
            f"#{issue_num}</a></td>\n"
            f"<td>{title}</td>\n"
            f"<td>{cwe_tags}</td>\n"
            f"<td>{lang_tags}</td>\n"
            f"</tr>\n"
        )

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Sanicode Coverage Scorecard</title>
<style>
{CSS}
</style>
</head>
<body>
<div class="page">

  <!-- Header + Summary card -->
  <div class="card">
    <div class="header">
      <h1>Sanicode Coverage Scorecard</h1>
      <div class="subtitle">Generated {timestamp}</div>
    </div>

    <div class="summary-section">
      <div class="stat-cards">
        <div class="stat-card">
          <span class="number">{total_rules}</span>
          <div class="label">Total Rules</div>
        </div>
        <div class="stat-card">
          <span class="number">{num_languages}</span>
          <div class="label">Languages</div>
        </div>
        <div class="stat-card">
          <span class="number">{num_covered_cwes}</span>
          <div class="label">CWEs Covered</div>
        </div>
        <div class="stat-card">
          <span class="number">{top25_covered}/25</span>
          <div class="label">CWE Top 25 Hit</div>
        </div>
      </div>

      <div class="top25-bar-container">
        <div class="top25-label">CWE Top 25 (2024) Coverage — {top25_pct}% ({top25_covered} of 25 CWEs have at least one rule)</div>
        <div class="progress-bar-track">
          <div class="progress-bar-fill" style="width: {bar_width}%">
            <span>{top25_pct}%</span>
          </div>
        </div>
      </div>

      <div class="legend">
        <strong style="font-size:12px; color:#444;">Legend:</strong>
        <div class="legend-item">
          <div class="legend-swatch swatch-implemented"></div>
          Implemented (rule IDs shown)
        </div>
        <div class="legend-item">
          <div class="legend-swatch swatch-planned"></div>
          Planned (issue #s shown)
        </div>
        <div class="legend-item">
          <div class="legend-swatch swatch-both"></div>
          Implemented, with additional rules planned (amber corner)
        </div>
        <div class="legend-item">
          <div class="legend-swatch swatch-empty"></div>
          Not covered
        </div>
      </div>
    </div>
  </div>

  <!-- Matrix card -->
  <div class="card">
    <div class="matrix-section">
      <div class="section-title">CWE × Language Coverage Matrix</div>
      <div class="table-wrapper">
        <table>
          <thead>
            <tr>
              {col_headers_html}
            </tr>
          </thead>
          <tbody>
            {table_body}
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- Open Issues card -->
  <div class="card issues-section">
    <div class="section-title">Open Coverage Issues</div>
    <div class="issues-table-wrapper">
      <table class="issues-table">
        <thead>
          <tr>
            <th style="width:70px">Issue</th>
            <th>Title</th>
            <th>CWEs</th>
            <th>Languages</th>
          </tr>
        </thead>
        <tbody>
          {issues_rows}
        </tbody>
      </table>
    </div>
  </div>

  <div class="footer">Sanicode &mdash; generated {timestamp}</div>
</div>
</body>
</html>"""

    return html


def main() -> None:
    implemented = load_implemented()
    planned, planned_raw = load_planned()

    # Build full set of CWEs: those in implemented rules + those in planned issues.
    all_cwes_set: set[int] = set()
    for _lang, cwe in implemented:
        all_cwes_set.add(cwe)
    for _lang, cwe in planned:
        all_cwes_set.add(cwe)
    all_cwes = sorted(all_cwes_set)

    # Languages: respect LANG_ORDER for known ones, append any unknowns alphabetically.
    known_langs = set(LANG_ORDER)
    impl_langs = {lang for lang, _cwe in implemented}
    plan_langs = {lang for lang, _cwe in planned}
    all_langs_set = impl_langs | plan_langs
    all_languages = [lang for lang in LANG_ORDER if lang in all_langs_set]
    extras = sorted(lang for lang in all_langs_set if lang not in known_langs)
    all_languages.extend(extras)

    # Build rule_messages and rule_sources for tooltips and links.
    # init_rules() already called by load_implemented().
    import inspect

    registry = get_rule_registry()
    rule_messages: dict[str, str] = {}
    rule_sources: dict[str, str] = {}
    for rule in registry.all_rules():
        rule_messages[rule.rule_id] = rule.message
        try:
            src = Path(inspect.getfile(type(rule)))
            rule_sources[rule.rule_id] = str(src.relative_to(PROJECT_ROOT))
        except (TypeError, ValueError):
            pass

    html = render_html(
        implemented=implemented,
        planned=planned,
        all_cwes=all_cwes,
        all_languages=all_languages,
        planned_raw=planned_raw,
        rule_messages=rule_messages,
        rule_sources=rule_sources,
    )

    docs_dir = PROJECT_ROOT / "docs"
    docs_dir.mkdir(exist_ok=True)
    out_path = docs_dir / "coverage-scorecard.html"
    out_path.write_text(html, encoding="utf-8")

    # Summary stats for stdout
    covered_cwes = {cwe for (_lang, cwe) in implemented}
    for child, parent in CWE_CHILD_TO_PARENT.items():
        if child in covered_cwes:
            covered_cwes.add(parent)
    top25_covered = sum(1 for cwe in CWE_TOP_25 if cwe in covered_cwes)
    top25_pct = round(top25_covered / len(CWE_TOP_25) * 100)
    total_rules = sum(len(v) for v in implemented.values())

    print(
        f"Generated docs/coverage-scorecard.html: "
        f"{total_rules} rules, {len(all_languages)} languages, "
        f"{len(covered_cwes)} CWEs, {top25_pct}% Top 25 coverage "
        f"({top25_covered}/25)"
    )


if __name__ == "__main__":
    main()
