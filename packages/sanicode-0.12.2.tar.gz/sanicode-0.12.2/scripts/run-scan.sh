#!/bin/bash
# Usage: run-scan.sh <repo>
REPO="$1"
CONFIG="/Users/wjackson/Developer/sanicode/sanicode-eval.toml"
TARGET="/Users/wjackson/Developer/unsanitary-code-examples/$REPO"

python -m sanicode scan "$TARGET" --config "$CONFIG" --format json --offline --no-deps 2>/dev/null
