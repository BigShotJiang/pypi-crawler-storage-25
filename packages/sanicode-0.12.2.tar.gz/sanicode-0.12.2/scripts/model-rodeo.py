#!/usr/bin/env python3
"""Model Rodeo — systematic LLM comparison for security vulnerability analysis.

Runs each configured model under six experimental conditions against the
benchmark corpus, scores results against ground truth, and produces checkpoint
data, a JSON scorecard, an HTML scorecard, and a narrative summary.

Conditions:
  A — Cold (raw code only)
  B — Hinted (security analyst persona)
  C — CPG-enriched (code + graph data, LLM reasons independently)
  D — CPG + deterministic findings (LLM reviews existing findings)
  E — Augment + tiebreaker (C then 3-way vote on disagreement)
  F — Review + tiebreaker (D then 3-way vote on disagreement)

Usage:
    .venv/bin/python scripts/model-rodeo.py [--models MODEL,...] [--conditions A,B,C,D,E,F]
                                             [--samples GLOB] [--reset]
"""

from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import requests

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parent.parent
CORPUS_DIR = PROJECT_ROOT / "benchmarks" / "llm_validation" / "corpus"
GROUND_TRUTH_PATH = PROJECT_ROOT / "benchmarks" / "llm_validation" / "ground_truth.json"
RESULTS_DIR = PROJECT_ROOT / "benchmarks" / "rodeo-results"
CHECKPOINT_PATH = RESULTS_DIR / "checkpoint.json"
SCAN_CACHE_DIR = RESULTS_DIR / "scan-cache"
SCORECARD_JSON = RESULTS_DIR / "scorecard.json"
SCORECARD_HTML = RESULTS_DIR / "scorecard.html"
SUMMARY_MD = RESULTS_DIR / "summary.md"

OLLAMA_URL = "http://localhost:11434"
OLLAMA_CHAT_URL = f"{OLLAMA_URL}/api/chat"
OLLAMA_TAGS_URL = f"{OLLAMA_URL}/api/tags"

TEMPERATURE = 0.2
REQUEST_TIMEOUT = 120  # seconds

CONDITIONS = ("A", "B", "C", "D", "E", "F")

# Models keyed by display name → Ollama tag.
# Capped at ~16B to avoid thermal throttling on M4 Pro 48GB.
# 30B+ models (qwen3-coder:30b, granite-code:34b-instruct) and 20B+
# dense/large-MoE models (codestral, gpt-oss:20b) removed.
MODELS: dict[str, str] = {
    # Code-specific
    "granite4:350m": "granite4:350m",
    "granite4:1b": "granite4:1b",
    "starcoder2:3b": "starcoder2:3b",
    "codellama:latest": "codellama:latest",
    "qwen2.5-coder:7b": "qwen2.5-coder:7b",
    "deepseek-coder-v2:16b": "deepseek-coder-v2:16b",
    "granite4:7b-a1b-h": "granite4:7b-a1b-h",
    # General-purpose controls
    "gemma3:270m": "gemma3:270m",
    "llama3:8b": "llama3:8b",
    "granite3.3:8b": "granite3.3:8b",
    "mistral-nemo:latest": "mistral-nemo:latest",
    "gpt-oss:20b": "gpt-oss:20b",
    # Cloud models (Anthropic)
    "claude-haiku-4-5": "claude-haiku-4-5-20251001",
}

MODEL_WEIGHT_CLASS: dict[str, str] = {
    "granite4:350m": "tiny",
    "granite4:1b": "tiny",
    "gemma3:270m": "tiny",
    "starcoder2:3b": "small",
    "codellama:latest": "7B",
    "qwen2.5-coder:7b": "7B",
    "llama3:8b": "8B",
    "granite3.3:8b": "8B",
    "mistral-nemo:latest": "12B",
    "deepseek-coder-v2:16b": "16B",
    "granite4:7b-a1b-h": "7B",
    "gpt-oss:20b": "20B",
    "claude-haiku-4-5": "cloud",
}

MODEL_TYPE: dict[str, str] = {
    "granite4:350m": "code",
    "granite4:1b": "code",
    "starcoder2:3b": "code",
    "codellama:latest": "code",
    "qwen2.5-coder:7b": "code",
    "deepseek-coder-v2:16b": "code",
    "granite4:7b-a1b-h": "code",
    "gemma3:270m": "general",
    "llama3:8b": "general",
    "granite3.3:8b": "general",
    "mistral-nemo:latest": "general",
    "gpt-oss:20b": "general",
    "claude-haiku-4-5": "general",
}


# ---------------------------------------------------------------------------
# Prompt templates
# ---------------------------------------------------------------------------

RESPONSE_FORMAT_ABC = """\
Respond ONLY with a JSON object (no markdown, no commentary) in this format:
{
  "vulnerable": true or false,
  "confidence": 0.0 to 1.0,
  "findings": [
    {"cwe_id": "CWE-XX", "line": <int>, "explanation": "..."}
  ],
  "reasoning": "Brief explanation of your analysis"
}
If the code is safe, set "vulnerable" to false, "findings" to [], and explain why in "reasoning"."""

RESPONSE_FORMAT_D = """\
Respond ONLY with a JSON object (no markdown, no commentary) in this format:
{
  "review": [
    {
      "rule_id": "SCXXX",
      "original_cwe": "CWE-XX",
      "verdict": "true_positive" or "false_positive",
      "correct_cwe": "CWE-XX",
      "explanation": "..."
    }
  ],
  "additional_findings": [
    {"cwe_id": "CWE-XX", "line": <int>, "explanation": "..."}
  ],
  "overall_vulnerable": true or false
}"""


def prompt_cold(code: str) -> list[dict[str, str]]:
    """Condition A: raw code only."""
    return [
        {
            "role": "user",
            "content": (
                "Analyze this code for security vulnerabilities. For each "
                "vulnerability found, provide: 1) Whether the code is vulnerable "
                "(yes/no), 2) The CWE ID, 3) Brief explanation. If the code is "
                "safe, say so.\n\n"
                f"```python\n{code}\n```\n\n"
                f"{RESPONSE_FORMAT_ABC}"
            ),
        }
    ]


def prompt_hinted(code: str) -> list[dict[str, str]]:
    """Condition B: code + security analyst persona."""
    return [
        {
            "role": "system",
            "content": (
                "You are a security code analyst. Focus on input validation, "
                "injection, data flow, cryptographic misuse, and deserialization "
                "vulnerabilities."
            ),
        },
        {
            "role": "user",
            "content": (
                "Analyze the following code for security vulnerabilities.\n\n"
                f"```python\n{code}\n```\n\n"
                f"{RESPONSE_FORMAT_ABC}"
            ),
        },
    ]


def prompt_cpg(code: str, graph_data: dict) -> list[dict[str, str]]:
    """Condition C: code + CPG graph data."""
    graph_str = json.dumps(graph_data, indent=2)
    return [
        {
            "role": "system",
            "content": (
                "You are a security code analyst with access to a Code Property "
                "Graph (CPG) extracted from the source code. Use the graph's "
                "node types (sinks, entry_points, sanitizers) and edges (data "
                "flow) to reason about whether identified sinks are actually "
                "vulnerable."
            ),
        },
        {
            "role": "user",
            "content": (
                "The following code property graph was extracted from this code:\n\n"
                f"```json\n{graph_str}\n```\n\n"
                "Source code:\n\n"
                f"```python\n{code}\n```\n\n"
                "Analyze whether the identified sinks are actually vulnerable "
                "considering the data flow.\n\n"
                f"{RESPONSE_FORMAT_ABC}"
            ),
        },
    ]


def prompt_cpg_findings(
    code: str, graph_data: dict, findings: list[dict]
) -> list[dict[str, str]]:
    """Condition D: code + CPG + deterministic findings."""
    graph_str = json.dumps(graph_data, indent=2)
    findings_str = json.dumps(findings, indent=2)
    return [
        {
            "role": "system",
            "content": (
                "You are a security code analyst reviewing static analysis "
                "results. You have access to the source code, a Code Property "
                "Graph, and the findings from a deterministic static analyzer. "
                "Review each finding and determine whether it is a true positive "
                "or false positive, and whether the CWE classification is correct."
            ),
        },
        {
            "role": "user",
            "content": (
                "Code Property Graph:\n\n"
                f"```json\n{graph_str}\n```\n\n"
                "Source code:\n\n"
                f"```python\n{code}\n```\n\n"
                "A static analyzer found the following potential vulnerabilities:\n\n"
                f"```json\n{findings_str}\n```\n\n"
                "Review each finding and determine:\n"
                "1) Is this a true positive or false positive?\n"
                "2) If true positive, is the CWE classification correct?\n\n"
                f"{RESPONSE_FORMAT_D}"
            ),
        },
    ]


def prompt_tiebreaker(
    code: str,
    deterministic_assessment: str,
    llm_assessment: str,
    graph_data: dict,
) -> list[dict[str, str]]:
    """Tiebreaker prompt: adjudicate between disagreeing analyses."""
    graph_str = json.dumps(graph_data, indent=2)
    return [
        {
            "role": "system",
            "content": (
                "You are a security code analyst resolving a disagreement "
                "between two analyses of the same code. Review both positions "
                "carefully and determine which is correct."
            ),
        },
        {
            "role": "user",
            "content": (
                "Two analyses of this code disagree:\n\n"
                "**Analysis A (Static Analyzer):**\n"
                f"{deterministic_assessment}\n\n"
                "**Analysis B (AI Reviewer):**\n"
                f"{llm_assessment}\n\n"
                "Source code:\n\n"
                f"```python\n{code}\n```\n\n"
                "Code Property Graph:\n\n"
                f"```json\n{graph_str}\n```\n\n"
                "Carefully consider both analyses. Which is correct?\n\n"
                f"{RESPONSE_FORMAT_ABC}"
            ),
        },
    ]


def summarize_deterministic(findings: list[dict]) -> str:
    """Produce a human-readable summary of deterministic scan findings."""
    if not findings:
        return "The static analyzer found no vulnerabilities in this code."
    parts = []
    for f in findings:
        cwe = f.get("cwe_id", "unknown CWE")
        if isinstance(cwe, int):
            cwe = f"CWE-{cwe}"
        rule = f.get("rule_id", "")
        line = f.get("line", "?")
        msg = f.get("message", f.get("explanation", ""))
        desc = f"{cwe}"
        if rule:
            desc += f" ({rule})"
        desc += f" at line {line}"
        if msg:
            desc += f" \u2014 {msg}"
        parts.append(desc)
    count = len(findings)
    noun = "vulnerability" if count == 1 else "vulnerabilities"
    listing = "; ".join(parts)
    return f"The static analyzer found {count} {noun}: {listing}."


def summarize_llm_response(parsed: dict | None, condition: str) -> str:
    """Summarize the LLM's Pass 2 output for the tiebreaker prompt."""
    if parsed is None:
        return "The AI reviewer's response could not be parsed."

    if condition in ("D", "F"):
        # D-format response.
        overall = parsed.get("overall_vulnerable")
        reviews = parsed.get("review", [])
        if overall is None:
            overall = any(r.get("verdict") == "true_positive" for r in reviews)
        status = "vulnerable" if overall else "not vulnerable"
        if reviews:
            verdicts = [
                f"{r.get('rule_id', '?')}: {r.get('verdict', '?')}"
                for r in reviews
            ]
            detail = "; ".join(verdicts)
            return (
                f"The AI reviewer determined the code is {status}. "
                f"Finding reviews: {detail}."
            )
        return f"The AI reviewer determined the code is {status}."

    # ABC-format response (conditions A, B, C, E).
    vuln = parsed.get("vulnerable")
    if vuln is None:
        vuln = len(parsed.get("findings", [])) > 0
    status = "vulnerable" if vuln else "not vulnerable"
    findings = parsed.get("findings", [])
    reasoning = parsed.get("reasoning", "")
    if findings:
        details = []
        for f in findings:
            cwe = f.get("cwe_id", "?")
            expl = f.get("explanation", "")
            details.append(f"{cwe}: {expl}" if expl else str(cwe))
        detail_str = "; ".join(details)
        return (
            f"The AI reviewer determined the code is {status}. "
            f"Findings: {detail_str}."
        )
    if reasoning:
        return (
            f"The AI reviewer determined the code is {status}. "
            f"Reasoning: {reasoning}"
        )
    return f"The AI reviewer determined the code is {status}."


def _llm_says_vulnerable(parsed: dict | None, condition: str) -> bool:
    """Determine whether the LLM's parsed response claims the code is vulnerable."""
    if parsed is None:
        return False
    if condition in ("D", "F"):
        overall = parsed.get("overall_vulnerable")
        if overall is not None:
            return bool(overall)
        return any(
            r.get("verdict") == "true_positive"
            for r in parsed.get("review", [])
        )
    # ABC-format.
    vuln = parsed.get("vulnerable")
    if vuln is not None:
        return bool(vuln)
    return len(parsed.get("findings", [])) > 0


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def ts() -> str:
    """Compact UTC timestamp for progress lines."""
    return datetime.now(timezone.utc).strftime("%H:%M:%S")


def elapsed_str(seconds: float) -> str:
    h, rem = divmod(int(seconds), 3600)
    m, s = divmod(rem, 60)
    return f"{h}h{m:02d}m{s:02d}s"


def strip_paths(obj: Any) -> Any:
    """Recursively strip absolute paths from graph JSON for prompt hygiene."""
    if isinstance(obj, dict):
        return {
            k: (
                os.path.basename(v)
                if k == "file" and isinstance(v, str) and "/" in v
                else strip_paths(v)
            )
            for k, v in obj.items()
        }
    if isinstance(obj, list):
        return [strip_paths(item) for item in obj]
    return obj


def extract_json(text: str) -> dict | None:
    """Try to parse JSON from model output, handling markdown fences."""
    # Try raw parse first.
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    # Try extracting from markdown code block.
    m = re.search(r"```(?:json)?\s*\n?(.*?)\n?\s*```", text, re.DOTALL)
    if m:
        try:
            return json.loads(m.group(1))
        except json.JSONDecodeError:
            pass

    # Try finding outermost braces.
    start = text.find("{")
    end = text.rfind("}")
    if start != -1 and end != -1 and end > start:
        try:
            return json.loads(text[start : end + 1])
        except json.JSONDecodeError:
            pass

    return None


def available_ollama_models() -> set[str]:
    """Return set of model tags currently pulled in Ollama."""
    try:
        resp = requests.get(OLLAMA_TAGS_URL, timeout=10)
        resp.raise_for_status()
        data = resp.json()
        return {m["name"] for m in data.get("models", [])}
    except Exception as exc:
        print(f"[{ts()}] WARNING: cannot query Ollama tags: {exc}")
        return set()


def call_ollama(model: str, messages: list[dict[str, str]]) -> dict:
    """Send a chat completion request to Ollama. Returns parsed response dict
    or an error dict."""
    payload = {
        "model": model,
        "messages": messages,
        "stream": False,
        "options": {"temperature": TEMPERATURE},
    }
    try:
        resp = requests.post(
            OLLAMA_CHAT_URL, json=payload, timeout=REQUEST_TIMEOUT
        )
        resp.raise_for_status()
        data = resp.json()
        content = data.get("message", {}).get("content", "")
        return {
            "raw_response": content,
            "parsed": extract_json(content),
            "error": None,
            "duration_ns": data.get("total_duration", 0),
        }
    except requests.exceptions.Timeout:
        return {"raw_response": "", "parsed": None, "error": "timeout"}
    except requests.exceptions.ConnectionError:
        return {"raw_response": "", "parsed": None, "error": "connection_error"}
    except Exception as exc:
        return {"raw_response": "", "parsed": None, "error": str(exc)}


def call_anthropic(model: str, messages: list[dict[str, str]]) -> dict:
    """Send a chat completion request to the Anthropic API. Returns parsed
    response dict or an error dict, matching call_ollama's return format."""
    try:
        import anthropic
    except ImportError:
        return {"raw_response": "", "parsed": None, "error": "anthropic SDK not installed"}

    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        return {"raw_response": "", "parsed": None, "error": "ANTHROPIC_API_KEY not set"}

    # Extract system message (if any) from the messages list.
    system_text = None
    api_messages = []
    for msg in messages:
        if msg["role"] == "system":
            system_text = msg["content"]
        else:
            api_messages.append({"role": msg["role"], "content": msg["content"]})

    try:
        client = anthropic.Anthropic(api_key=api_key, timeout=60.0)
        kwargs: dict[str, Any] = {
            "model": model,
            "max_tokens": 1024,
            "temperature": TEMPERATURE,
            "messages": api_messages,
        }
        if system_text:
            kwargs["system"] = system_text

        t0_ns = time.monotonic_ns()
        response = client.messages.create(**kwargs)
        duration_ns = time.monotonic_ns() - t0_ns

        content = response.content[0].text if response.content else ""
        return {
            "raw_response": content,
            "parsed": extract_json(content),
            "error": None,
            "duration_ns": duration_ns,
        }
    except anthropic.RateLimitError as exc:
        return {"raw_response": "", "parsed": None, "error": f"rate_limit: {exc}"}
    except anthropic.APITimeoutError:
        return {"raw_response": "", "parsed": None, "error": "timeout"}
    except anthropic.APIConnectionError as exc:
        return {"raw_response": "", "parsed": None, "error": f"connection_error: {exc}"}
    except Exception as exc:
        return {"raw_response": "", "parsed": None, "error": str(exc)}


def is_anthropic_model(model_name: str) -> bool:
    """Return True if the model name indicates an Anthropic cloud model."""
    return model_name.startswith("claude-")


# ---------------------------------------------------------------------------
# Sanicode scanning
# ---------------------------------------------------------------------------


def run_sanicode_scan(sample_path: Path) -> tuple[list[dict], dict]:
    """Run deterministic sanicode scan on a sample file.

    Returns (findings_list, graph_dict).  Results are cached on disk.
    """
    cache_key = str(sample_path.relative_to(CORPUS_DIR)).replace("/", "__")
    findings_cache = SCAN_CACHE_DIR / f"{cache_key}.findings.json"
    graph_cache = SCAN_CACHE_DIR / f"{cache_key}.graph.json"

    if findings_cache.exists() and graph_cache.exists():
        return (
            json.loads(findings_cache.read_text()),
            json.loads(graph_cache.read_text()),
        )

    report_dir = PROJECT_ROOT / "sanicode-reports"
    report_file = report_dir / "report.json"
    graph_file = report_dir / "graph.json"

    # Remove stale output.
    for f in (report_file, graph_file):
        f.unlink(missing_ok=True)

    cmd = [
        str(PROJECT_ROOT / ".venv" / "bin" / "python"),
        "-m",
        "sanicode",
        "scan",
        str(sample_path),
        "-f",
        "json",
        "--no-deps",
    ]
    try:
        subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=30,
            cwd=str(PROJECT_ROOT),
        )
    except subprocess.TimeoutExpired:
        pass

    findings: list[dict] = []
    graph: dict = {}

    if report_file.exists():
        try:
            report = json.loads(report_file.read_text())
            findings = report.get("findings", [])
        except json.JSONDecodeError:
            pass

    if graph_file.exists():
        try:
            graph = json.loads(graph_file.read_text())
        except json.JSONDecodeError:
            pass

    SCAN_CACHE_DIR.mkdir(parents=True, exist_ok=True)
    findings_cache.write_text(json.dumps(findings, indent=2))
    graph_cache.write_text(json.dumps(graph, indent=2))

    return findings, graph


# ---------------------------------------------------------------------------
# Scoring
# ---------------------------------------------------------------------------


@dataclass
class SampleScore:
    sample: str = ""
    model: str = ""
    condition: str = ""
    correct_classification: bool = False
    correct_cwe: bool = False
    false_positive_filtered: bool = False
    value_add: bool = False
    degradation: bool = False
    parse_error: bool = False
    error: str | None = None


def normalize_cwe(cwe_val: Any) -> int | None:
    """Extract integer CWE id from various formats (89, 'CWE-89', 'cwe-89')."""
    if isinstance(cwe_val, int):
        return cwe_val
    if isinstance(cwe_val, str):
        m = re.search(r"(\d+)", cwe_val)
        return int(m.group(1)) if m else None
    return None


def score_abc(
    parsed: dict | None,
    gt: dict,
    deterministic_findings: list[dict],
    sample_key: str,
) -> SampleScore:
    """Score a Condition A/B/C response against ground truth."""
    sc = SampleScore(sample=sample_key)

    if parsed is None:
        sc.parse_error = True
        return sc

    gt_vuln = gt["ground_truth_vulnerable"]
    model_vuln = parsed.get("vulnerable", None)

    if model_vuln is None:
        # Infer from findings list.
        findings = parsed.get("findings", [])
        model_vuln = len(findings) > 0

    sc.correct_classification = bool(model_vuln) == gt_vuln

    # FP filtering — only relevant for samples where static analysis would flag.
    if not gt_vuln and gt.get("llm_should_filter"):
        sc.false_positive_filtered = not bool(model_vuln)

    # CWE accuracy (only meaningful for true positives).
    if gt_vuln and model_vuln:
        model_cwes = set()
        for f in parsed.get("findings", []):
            c = normalize_cwe(f.get("cwe_id"))
            if c is not None:
                model_cwes.add(c)
        gt_cwes = {ef["cwe_id"] for ef in gt["expected_static_findings"]}
        sc.correct_cwe = bool(model_cwes & gt_cwes)

    # Value-add: model found something deterministic missed.
    if gt_vuln and model_vuln:
        det_cwes = {f.get("cwe_id") for f in deterministic_findings}
        model_cwes = set()
        for f in parsed.get("findings", []):
            c = normalize_cwe(f.get("cwe_id"))
            if c is not None:
                model_cwes.add(c)
        gt_cwes = {ef["cwe_id"] for ef in gt["expected_static_findings"]}
        novel = (model_cwes & gt_cwes) - det_cwes
        sc.value_add = len(novel) > 0

    # Degradation: model says safe when deterministic correctly said vuln.
    if gt_vuln and not model_vuln and len(deterministic_findings) > 0:
        sc.degradation = True

    return sc


def score_d(
    parsed: dict | None,
    gt: dict,
    deterministic_findings: list[dict],
    sample_key: str,
) -> SampleScore:
    """Score a Condition D (review-mode) response against ground truth."""
    sc = SampleScore(sample=sample_key)

    if parsed is None:
        sc.parse_error = True
        return sc

    gt_vuln = gt["ground_truth_vulnerable"]

    # Overall classification.
    model_vuln = parsed.get("overall_vulnerable", None)
    if model_vuln is None:
        # Infer from review verdicts.
        reviews = parsed.get("review", [])
        model_vuln = any(
            r.get("verdict") == "true_positive" for r in reviews
        )

    sc.correct_classification = bool(model_vuln) == gt_vuln

    # FP filtering.
    if not gt_vuln and gt.get("llm_should_filter"):
        sc.false_positive_filtered = not bool(model_vuln)

    # CWE accuracy from review verdicts.
    if gt_vuln:
        gt_cwes = {ef["cwe_id"] for ef in gt["expected_static_findings"]}
        for review in parsed.get("review", []):
            if review.get("verdict") == "true_positive":
                c = normalize_cwe(review.get("correct_cwe") or review.get("original_cwe"))
                if c is not None and c in gt_cwes:
                    sc.correct_cwe = True
                    break

    # Value-add from additional_findings.
    if gt_vuln:
        det_cwes = {f.get("cwe_id") for f in deterministic_findings}
        gt_cwes = {ef["cwe_id"] for ef in gt["expected_static_findings"]}
        for af in parsed.get("additional_findings", []):
            c = normalize_cwe(af.get("cwe_id"))
            if c is not None and c in gt_cwes and c not in det_cwes:
                sc.value_add = True
                break

    # Degradation: model marks a correct deterministic finding as FP.
    if gt_vuln:
        gt_rules = {ef["rule_id"] for ef in gt["expected_static_findings"]}
        for review in parsed.get("review", []):
            if (
                review.get("verdict") == "false_positive"
                and review.get("rule_id") in gt_rules
            ):
                sc.degradation = True
                break

    return sc


# ---------------------------------------------------------------------------
# Aggregation
# ---------------------------------------------------------------------------


@dataclass
class AggregateMetrics:
    model: str = ""
    condition: str = ""
    total: int = 0
    correct: int = 0
    tp_total: int = 0  # ground truth positive samples
    tp_detected: int = 0  # model correctly said vulnerable
    fp_total: int = 0  # ground truth negative with static findings
    fp_filtered: int = 0  # model correctly said not vulnerable
    correct_cwe_count: int = 0
    value_add_count: int = 0
    degradation_count: int = 0
    parse_errors: int = 0
    errors: int = 0

    @property
    def precision(self) -> float:
        # TP / (TP + FP-not-filtered)
        denom = self.tp_detected + (self.fp_total - self.fp_filtered)
        return self.tp_detected / denom if denom > 0 else 0.0

    @property
    def recall(self) -> float:
        return self.tp_detected / self.tp_total if self.tp_total > 0 else 0.0

    @property
    def f1(self) -> float:
        p, r = self.precision, self.recall
        return 2 * p * r / (p + r) if (p + r) > 0 else 0.0

    @property
    def fp_filter_rate(self) -> float:
        return self.fp_filtered / self.fp_total if self.fp_total > 0 else 0.0

    @property
    def accuracy(self) -> float:
        return self.correct / self.total if self.total > 0 else 0.0

    @property
    def value_add_rate(self) -> float:
        return self.value_add_count / self.total if self.total > 0 else 0.0

    @property
    def degradation_rate(self) -> float:
        return self.degradation_count / self.total if self.total > 0 else 0.0

    def to_dict(self) -> dict:
        return {
            "model": self.model,
            "condition": self.condition,
            "total": self.total,
            "correct": self.correct,
            "accuracy": round(self.accuracy, 4),
            "precision": round(self.precision, 4),
            "recall": round(self.recall, 4),
            "f1": round(self.f1, 4),
            "fp_filter_rate": round(self.fp_filter_rate, 4),
            "value_add_rate": round(self.value_add_rate, 4),
            "degradation_rate": round(self.degradation_rate, 4),
            "parse_errors": self.parse_errors,
            "errors": self.errors,
            "tp_total": self.tp_total,
            "tp_detected": self.tp_detected,
            "fp_total": self.fp_total,
            "fp_filtered": self.fp_filtered,
            "correct_cwe_count": self.correct_cwe_count,
            "value_add_count": self.value_add_count,
            "degradation_count": self.degradation_count,
        }


def aggregate(
    scores: list[SampleScore],
    ground_truth: dict[str, dict],
    model: str,
    condition: str,
) -> AggregateMetrics:
    m = AggregateMetrics(model=model, condition=condition)
    for sc in scores:
        m.total += 1
        gt = ground_truth.get(sc.sample, {})
        gt_vuln = gt.get("ground_truth_vulnerable", False)

        if sc.error:
            m.errors += 1
            continue
        if sc.parse_error:
            m.parse_errors += 1
            continue

        if sc.correct_classification:
            m.correct += 1

        if gt_vuln:
            m.tp_total += 1
            if sc.correct_classification:
                m.tp_detected += 1
        elif gt.get("llm_should_filter"):
            m.fp_total += 1
            if sc.false_positive_filtered:
                m.fp_filtered += 1

        if sc.correct_cwe:
            m.correct_cwe_count += 1
        if sc.value_add:
            m.value_add_count += 1
        if sc.degradation:
            m.degradation_count += 1

    return m


# ---------------------------------------------------------------------------
# Checkpoint management
# ---------------------------------------------------------------------------


def load_checkpoint() -> dict:
    if CHECKPOINT_PATH.exists():
        return json.loads(CHECKPOINT_PATH.read_text())
    return {"version": 1, "results": {}, "started_at": datetime.now(timezone.utc).isoformat()}


def save_checkpoint(ckpt: dict) -> None:
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    tmp = CHECKPOINT_PATH.with_suffix(".tmp")
    tmp.write_text(json.dumps(ckpt, indent=2))
    tmp.rename(CHECKPOINT_PATH)


def experiment_key(model: str, condition: str, sample: str) -> str:
    return f"{model}|{condition}|{sample}"


# ---------------------------------------------------------------------------
# HTML scorecard generation
# ---------------------------------------------------------------------------


def color_cell(value: float) -> str:
    """Return CSS background color based on metric value."""
    if value >= 0.80:
        return "#2d8a4e"  # green
    if value >= 0.60:
        return "#c49b1a"  # yellow
    return "#c44125"  # red


def generate_html_scorecard(
    all_metrics: list[AggregateMetrics],
    checkpoint: dict,
    ground_truth: dict[str, dict],
) -> str:
    """Build a self-contained HTML scorecard."""

    # Organize metrics.
    by_model: dict[str, dict[str, AggregateMetrics]] = {}
    for m in all_metrics:
        by_model.setdefault(m.model, {})[m.condition] = m

    # Rank models by average F1 across conditions.
    model_avg_f1: list[tuple[str, float]] = []
    for model, conds in by_model.items():
        f1s = [c.f1 for c in conds.values()]
        model_avg_f1.append((model, sum(f1s) / len(f1s) if f1s else 0.0))
    model_avg_f1.sort(key=lambda x: x[1], reverse=True)

    # Weight class winners.
    weight_class_best: dict[str, tuple[str, float]] = {}
    for model, avg_f1 in model_avg_f1:
        wc = MODEL_WEIGHT_CLASS.get(model, "unknown")
        if wc not in weight_class_best or avg_f1 > weight_class_best[wc][1]:
            weight_class_best[wc] = (model, avg_f1)

    # Best condition per model.
    best_condition: dict[str, tuple[str, float]] = {}
    for model, conds in by_model.items():
        best = max(conds.items(), key=lambda x: x[1].f1)
        best_condition[model] = (best[0], best[1].f1)

    # Collect per-sample results for the detail section.
    sample_results: dict[str, list[dict]] = {}  # sample -> list of result dicts
    for key, result in checkpoint.get("results", {}).items():
        parts = key.split("|", 2)
        if len(parts) == 3:
            sample = parts[2]
            sample_results.setdefault(sample, []).append(result)

    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    condition_labels = {
        "A": "Cold (code only)",
        "B": "Hinted (persona)",
        "C": "CPG-enriched",
        "D": "CPG + findings",
        "E": "Augment + tiebreaker",
        "F": "Review + tiebreaker",
    }

    # Build HTML.
    rows_summary = []
    for rank, (model, avg_f1) in enumerate(model_avg_f1, 1):
        wc = MODEL_WEIGHT_CLASS.get(model, "?")
        mt = MODEL_TYPE.get(model, "?")
        bc = best_condition.get(model, ("?", 0.0))
        rows_summary.append(
            f"<tr>"
            f"<td>{rank}</td>"
            f"<td><strong>{model}</strong></td>"
            f"<td>{wc}</td>"
            f"<td>{mt}</td>"
            f"<td style='background:{color_cell(avg_f1)};color:#fff'>{avg_f1:.3f}</td>"
            f"<td>{bc[0]} ({bc[1]:.3f})</td>"
            f"</tr>"
        )

    # Heatmap rows (model x condition x metric).
    metrics_list = ["f1", "precision", "recall", "fp_filter_rate", "accuracy"]
    heatmap_rows = []
    for model, _ in model_avg_f1:
        conds = by_model.get(model, {})
        cells = f"<td><strong>{model}</strong></td>"
        for cond in CONDITIONS:
            m = conds.get(cond)
            if m is None:
                cells += "<td colspan='5' style='background:#666;color:#ccc'>not run</td>"
            else:
                for metric_name in metrics_list:
                    val = getattr(m, metric_name, 0.0)
                    if callable(val):
                        val = val()
                    cells += (
                        f"<td style='background:{color_cell(val)};color:#fff;"
                        f"text-align:center'>{val:.2f}</td>"
                    )
        heatmap_rows.append(f"<tr>{cells}</tr>")

    # Condition comparison table.
    condition_rows = []
    for model, _ in model_avg_f1:
        conds = by_model.get(model, {})
        cells = f"<td><strong>{model}</strong></td>"
        for cond in CONDITIONS:
            m = conds.get(cond)
            if m is None:
                cells += "<td>-</td>"
            else:
                cells += (
                    f"<td>F1={m.f1:.2f} P={m.precision:.2f} R={m.recall:.2f} "
                    f"FPF={m.fp_filter_rate:.2f}</td>"
                )
        condition_rows.append(f"<tr>{cells}</tr>")

    # Weight class winners table.
    wc_rows = []
    for wc in sorted(weight_class_best.keys(), key=lambda x: (
        0 if x == "tiny" else 1 if x == "small" else int(x.replace("B", ""))
        if x.replace("B", "").isdigit() else 99
    )):
        model, f1 = weight_class_best[wc]
        wc_rows.append(
            f"<tr><td>{wc}</td><td>{model}</td>"
            f"<td style='background:{color_cell(f1)};color:#fff'>{f1:.3f}</td></tr>"
        )

    # Per-sample detail — collapsible.
    sample_detail_html = []
    for sample_key in sorted(ground_truth.keys()):
        gt = ground_truth[sample_key]
        results = sample_results.get(sample_key, [])
        if not results:
            continue
        detail_rows = []
        for r in results:
            model_name = r.get("model", "?")
            cond = r.get("condition", "?")
            sc = r.get("score", {})
            detail_rows.append(
                f"<tr>"
                f"<td>{model_name}</td>"
                f"<td>{cond}</td>"
                f"<td>{'Y' if sc.get('correct_classification') else 'N'}</td>"
                f"<td>{'Y' if sc.get('correct_cwe') else '-'}</td>"
                f"<td>{'Y' if sc.get('false_positive_filtered') else '-'}</td>"
                f"<td>{'ERR' if sc.get('parse_error') else 'OK'}</td>"
                f"</tr>"
            )
        detail_table = (
            "<table class='detail'>"
            "<tr><th>Model</th><th>Cond</th><th>Class</th><th>CWE</th>"
            "<th>FPF</th><th>Parse</th></tr>"
            + "\n".join(detail_rows)
            + "</table>"
        )
        vuln_label = "VULNERABLE" if gt["ground_truth_vulnerable"] else "SAFE"
        sample_detail_html.append(
            f"<details><summary>{sample_key} ({vuln_label})</summary>"
            f"{detail_table}</details>"
        )

    # Heatmap header.
    heatmap_header_cells = "<th>Model</th>"
    for cond in CONDITIONS:
        for metric in metrics_list:
            heatmap_header_cells += f"<th>{cond}:{metric[:4]}</th>"

    html = f"""\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Model Rodeo Scorecard</title>
<style>
body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI",
  Helvetica, Arial, sans-serif; margin: 2em;
  background: #1a1a2e; color: #e0e0e0; }}
h1, h2, h3 {{ color: #fff; }}
table {{ border-collapse: collapse; width: 100%; margin-bottom: 1.5em; }}
th, td {{ border: 1px solid #333; padding: 6px 10px; text-align: left; font-size: 0.85em; }}
th {{ background: #16213e; color: #ddd; }}
tr:nth-child(even) {{ background: #1a1a2e; }}
tr:nth-child(odd) {{ background: #16213e; }}
details {{ margin: 4px 0; }}
summary {{ cursor: pointer; padding: 4px; background: #16213e; border-radius: 4px; }}
summary:hover {{ background: #1a3a5e; }}
.detail th {{ font-size: 0.8em; }}
.detail td {{ font-size: 0.8em; }}
.meta {{ color: #888; font-size: 0.85em; }}
</style>
</head>
<body>
<h1>Model Rodeo Scorecard</h1>
<p class="meta">Generated: {timestamp}</p>

<h2>Overall Ranking (by average F1 across conditions)</h2>
<table>
<tr><th>#</th><th>Model</th><th>Weight</th><th>Type</th><th>Avg F1</th><th>Best Condition</th></tr>
{"".join(rows_summary)}
</table>

<h2>Weight Class Winners</h2>
<table>
<tr><th>Weight Class</th><th>Model</th><th>Avg F1</th></tr>
{"".join(wc_rows)}
</table>

<h2>Condition Comparison</h2>
<table>
<tr><th>Model</th>{"".join(f"<th>{condition_labels.get(c, c)}</th>" for c in CONDITIONS)}</tr>
{"".join(condition_rows)}
</table>

<h2>Heatmap: Models x Conditions x Metrics</h2>
<table>
<tr>{heatmap_header_cells}</tr>
{"".join(heatmap_rows)}
</table>

<h2>Per-Sample Detail</h2>
{"".join(sample_detail_html)}

<h2>Methodology</h2>
<ul>
<li><strong>Condition A (Cold)</strong>: Model receives raw code only, no hints.</li>
<li><strong>Condition B (Hinted)</strong>: Model receives a security analyst persona prompt.</li>
<li><strong>Condition C (CPG-enriched)</strong>: Code + CPG data.</li>
<li><strong>Condition D (CPG + findings)</strong>: Reviews deterministic findings.</li>
<li><strong>Condition E (Augment + tiebreaker)</strong>: Runs C, then if LLM disagrees with
deterministic findings, a tiebreaker call adjudicates (3-way vote).</li>
<li><strong>Condition F (Review + tiebreaker)</strong>: Runs D, then if LLM disagrees with
deterministic findings, a tiebreaker call adjudicates (3-way vote).</li>
<li><strong>Temperature</strong>: {TEMPERATURE}</li>
<li><strong>Timeout</strong>: {REQUEST_TIMEOUT}s per call</li>
<li><strong>Scoring</strong>: Precision, Recall, F1 based on vulnerability classification.
FP Filter Rate measures how often the model correctly dismisses false positives
from the deterministic scanner.</li>
</ul>
</body>
</html>
"""
    return html


# ---------------------------------------------------------------------------
# Markdown summary generation
# ---------------------------------------------------------------------------


def generate_summary(
    all_metrics: list[AggregateMetrics],
    ground_truth: dict[str, dict],
) -> str:
    # Rank by average F1.
    by_model: dict[str, list[AggregateMetrics]] = {}
    for m in all_metrics:
        by_model.setdefault(m.model, []).append(m)

    model_avg_f1: list[tuple[str, float]] = []
    for model, mlist in by_model.items():
        f1s = [m.f1 for m in mlist]
        model_avg_f1.append((model, sum(f1s) / len(f1s) if f1s else 0.0))
    model_avg_f1.sort(key=lambda x: x[1], reverse=True)

    total_samples = len(ground_truth)
    n_models = len(by_model)
    n_conditions = len(CONDITIONS)

    lines = [
        "# Model Rodeo Summary",
        "",
        f"Tested **{n_models} models** across **{n_conditions} conditions** "
        f"on **{total_samples} benchmark samples**.",
        "",
        "## Top 5 Models (by average F1)",
        "",
    ]
    for i, (model, f1) in enumerate(model_avg_f1[:5], 1):
        wc = MODEL_WEIGHT_CLASS.get(model, "?")
        mt = MODEL_TYPE.get(model, "?")
        lines.append(f"{i}. **{model}** ({wc}, {mt}) — F1={f1:.3f}")

    lines += ["", "## Key Findings", ""]

    # Best FP filter rate.
    best_fpf_model = ""
    best_fpf = 0.0
    for m in all_metrics:
        if m.fp_filter_rate > best_fpf:
            best_fpf = m.fp_filter_rate
            best_fpf_model = f"{m.model} (condition {m.condition})"
    lines.append(f"- Best FP filter rate: **{best_fpf:.1%}** by {best_fpf_model}")

    # Does CPG help?
    cpg_better = 0
    cpg_worse = 0
    for _model, mlist in by_model.items():
        cond_map = {m.condition: m for m in mlist}
        a = cond_map.get("A")
        c = cond_map.get("C")
        if a and c:
            if c.f1 > a.f1:
                cpg_better += 1
            elif c.f1 < a.f1:
                cpg_worse += 1
    lines.append(
        f"- CPG enrichment (C vs A): improved F1 for **{cpg_better}** models, "
        f"degraded for **{cpg_worse}**"
    )

    # Does hinting help?
    hint_better = 0
    hint_worse = 0
    for _model, mlist in by_model.items():
        cond_map = {m.condition: m for m in mlist}
        a = cond_map.get("A")
        b = cond_map.get("B")
        if a and b:
            if b.f1 > a.f1:
                hint_better += 1
            elif b.f1 < a.f1:
                hint_worse += 1
    lines.append(
        f"- Hinting (B vs A): improved F1 for **{hint_better}** models, "
        f"degraded for **{hint_worse}**"
    )

    # Does tiebreaker help (E vs C, F vs D)?
    for base, tb, label in [("C", "E", "Augment tiebreaker (E vs C)"),
                            ("D", "F", "Review tiebreaker (F vs D)")]:
        tb_better = 0
        tb_worse = 0
        for _model, mlist in by_model.items():
            cond_map = {m.condition: m for m in mlist}
            b_m = cond_map.get(base)
            t_m = cond_map.get(tb)
            if b_m and t_m:
                if t_m.f1 > b_m.f1:
                    tb_better += 1
                elif t_m.f1 < b_m.f1:
                    tb_worse += 1
        if tb_better or tb_worse:
            lines.append(
                f"- {label}: improved F1 for **{tb_better}** models, "
                f"degraded for **{tb_worse}**"
            )

    # Code vs general.
    code_f1s = [f1 for model, f1 in model_avg_f1 if MODEL_TYPE.get(model) == "code"]
    gen_f1s = [f1 for model, f1 in model_avg_f1 if MODEL_TYPE.get(model) == "general"]
    if code_f1s and gen_f1s:
        lines.append(
            f"- Code-specific models avg F1: **{sum(code_f1s)/len(code_f1s):.3f}** "
            f"vs general-purpose: **{sum(gen_f1s)/len(gen_f1s):.3f}**"
        )

    # Parse error summary.
    total_parse_errors = sum(m.parse_errors for m in all_metrics)
    total_experiments = sum(m.total for m in all_metrics)
    if total_experiments > 0:
        lines.append(
            f"- Parse errors: **{total_parse_errors}** / {total_experiments} "
            f"({total_parse_errors/total_experiments:.1%})"
        )

    lines += [
        "",
        "## Weight Class Winners",
        "",
    ]
    weight_class_best: dict[str, tuple[str, float]] = {}
    for model, f1 in model_avg_f1:
        wc = MODEL_WEIGHT_CLASS.get(model, "unknown")
        if wc not in weight_class_best or f1 > weight_class_best[wc][1]:
            weight_class_best[wc] = (model, f1)
    for wc in sorted(weight_class_best.keys()):
        model, f1 = weight_class_best[wc]
        lines.append(f"- **{wc}**: {model} (F1={f1:.3f})")

    lines.append("")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Main experiment loop
# ---------------------------------------------------------------------------


def main() -> None:
    parser = argparse.ArgumentParser(description="Model Rodeo experiment harness")
    parser.add_argument(
        "--models",
        type=str,
        default=None,
        help="Comma-separated model names to test (default: all)",
    )
    parser.add_argument(
        "--conditions",
        type=str,
        default=None,
        help="Comma-separated conditions to test, e.g. A,B,C,D,E,F (default: all)",
    )
    parser.add_argument(
        "--samples",
        type=str,
        default=None,
        help="Glob filter for sample keys, e.g. 'true_positives/*'",
    )
    parser.add_argument(
        "--reset",
        action="store_true",
        help="Discard checkpoint and start fresh",
    )
    parser.add_argument(
        "--no-warmup",
        action="store_true",
        help="Skip model warm-up checks",
    )
    args = parser.parse_args()

    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    SCAN_CACHE_DIR.mkdir(parents=True, exist_ok=True)

    # Load ground truth.
    ground_truth: dict[str, dict] = json.loads(GROUND_TRUTH_PATH.read_text())

    # Filter samples.
    sample_keys = sorted(ground_truth.keys())
    if args.samples:
        import fnmatch

        sample_keys = [s for s in sample_keys if fnmatch.fnmatch(s, args.samples)]
    if not sample_keys:
        print("ERROR: no samples match filter")
        sys.exit(1)

    # Filter models.
    models_to_test = list(MODELS.keys())
    if args.models:
        requested = [m.strip() for m in args.models.split(",")]
        models_to_test = [m for m in requested if m in MODELS]
        unknown = [m for m in requested if m not in MODELS]
        if unknown:
            print(f"WARNING: unknown models skipped: {unknown}")
    if not models_to_test:
        print("ERROR: no valid models selected")
        sys.exit(1)

    # Filter conditions.
    conditions = list(CONDITIONS)
    if args.conditions:
        conditions = [c.strip().upper() for c in args.conditions.split(",")]
        invalid = [c for c in conditions if c not in CONDITIONS]
        if invalid:
            print(f"WARNING: invalid conditions skipped: {invalid}")
            conditions = [c for c in conditions if c in CONDITIONS]

    # Split models into Ollama and Anthropic groups for availability checks.
    ollama_models = [m for m in models_to_test if not is_anthropic_model(m)]
    anthropic_models = [m for m in models_to_test if is_anthropic_model(m)]

    # Check Ollama availability for local models.
    if ollama_models:
        available = available_ollama_models()
        if not available:
            print(
                "WARNING: could not reach Ollama or no models pulled. "
                "Will attempt to use models anyway (Ollama may auto-pull)."
            )
        else:
            missing = [m for m in ollama_models if MODELS[m] not in available]
            if missing:
                print(
                    f"WARNING: these models are not pulled in Ollama and will be "
                    f"skipped: {missing}"
                )
                ollama_models = [m for m in ollama_models if MODELS[m] in available]

    # Check Anthropic availability.
    if anthropic_models:
        if not os.environ.get("ANTHROPIC_API_KEY"):
            print(
                f"WARNING: ANTHROPIC_API_KEY not set, skipping Anthropic models: {anthropic_models}"
            )
            anthropic_models = []

    models_to_test = ollama_models + anthropic_models
    if not models_to_test:
        print("ERROR: no available models to test")
        sys.exit(1)

    # Checkpoint.
    if args.reset and CHECKPOINT_PATH.exists():
        CHECKPOINT_PATH.unlink()
    ckpt = load_checkpoint()

    # Pre-scan all samples with sanicode.
    print(f"[{ts()}] Pre-scanning {len(sample_keys)} samples with sanicode...")
    scan_cache: dict[str, tuple[list[dict], dict]] = {}
    for i, sample_key in enumerate(sample_keys):
        sample_path = CORPUS_DIR / sample_key
        if not sample_path.exists():
            print(f"  WARNING: {sample_key} not found, skipping")
            continue
        findings, graph = run_sanicode_scan(sample_path)
        scan_cache[sample_key] = (findings, graph)
        if (i + 1) % 20 == 0 or i == len(sample_keys) - 1:
            print(f"  [{ts()}] Scanned {i + 1}/{len(sample_keys)}")

    # Pre-flight: Graph quality check
    true_positive_keys = [k for k in sample_keys if "true_positive" in k]
    if true_positive_keys:
        samples_with_edges = 0
        samples_with_findings = 0
        for sk in true_positive_keys:
            if sk not in scan_cache:
                continue
            findings, graph = scan_cache[sk]
            if findings:
                samples_with_findings += 1
            links = graph.get("edges", [])
            if links:
                samples_with_edges += 1

        edge_rate = samples_with_edges / len(true_positive_keys) if true_positive_keys else 0
        finding_rate = samples_with_findings / len(true_positive_keys) if true_positive_keys else 0

        tp_total = len(true_positive_keys)
        print(
            f"[{ts()}] Pre-flight: {samples_with_findings}/{tp_total} true_positive "
            f"samples have deterministic findings ({finding_rate:.0%})"
        )
        print(
            f"[{ts()}] Pre-flight: {samples_with_edges}/{tp_total} true_positive "
            f"samples have graph edges ({edge_rate:.0%})"
        )

        if finding_rate < 0.5:
            print(
                f"[{ts()}] WARNING: <50% of true_positive samples produced findings. "
                f"Deterministic scanner may have issues."
            )
            print(
                f"[{ts()}] Consider fixing scanner rules before running the rodeo. "
                f"Continue anyway? (results may not be meaningful)"
            )

        if edge_rate < 0.1:
            print(
                f"[{ts()}] WARNING: <10% of true_positive samples have graph edges. "
                f"CPG edge creation may have issues."
            )
            print(
                f"[{ts()}] Conditions C/D/E/F depend on graph data — "
                f"results will be degraded without edges."
            )

    # Pre-flight: Scan coverage — check false positives produce expected findings
    false_positive_keys = [k for k in sample_keys if "false_positive" in k]
    if false_positive_keys:
        fp_with_findings = sum(
            1 for sk in false_positive_keys
            if sk in scan_cache and scan_cache[sk][0]
        )
        fp_rate = fp_with_findings / len(false_positive_keys) if false_positive_keys else 0
        fp_total = len(false_positive_keys)
        print(
            f"[{ts()}] Pre-flight: {fp_with_findings}/{fp_total} false_positive "
            f"samples trigger deterministic findings ({fp_rate:.0%})"
        )
        if fp_rate < 0.5:
            print(
                f"[{ts()}] WARNING: <50% of false_positive samples trigger findings. "
                f"FP filter testing may be unreliable."
            )

    # Pre-flight: Model warm-up — verify each model actually responds
    if not args.no_warmup:
        print(f"[{ts()}] Pre-flight: Warming up {len(models_to_test)} models...")
        warmed_up = []
        for model_name in models_to_test:
            model_tag = MODELS[model_name]
            test_messages = [{"role": "user", "content": "Respond with the single word OK."}]
            if is_anthropic_model(model_name):
                result = call_anthropic(model_tag, test_messages)
            else:
                result = call_ollama(model_tag, test_messages)

            if result["error"]:
                print(f"[{ts()}]   SKIP {model_name}: warm-up failed ({result['error']})")
            else:
                print(f"[{ts()}]   OK   {model_name}")
                warmed_up.append(model_name)

        if not warmed_up:
            print(f"[{ts()}] ERROR: No models passed warm-up. Aborting.")
            sys.exit(1)

        skipped = set(models_to_test) - set(warmed_up)
        if skipped:
            print(f"[{ts()}] Skipping {len(skipped)} models that failed warm-up: {sorted(skipped)}")
        models_to_test = warmed_up

    # Count total experiments.
    total_experiments = len(models_to_test) * len(conditions) * len(sample_keys)
    completed = sum(
        1
        for m in models_to_test
        for c in conditions
        for s in sample_keys
        if experiment_key(m, c, s) in ckpt["results"]
    )
    remaining = total_experiments - completed
    print(
        f"[{ts()}] Starting rodeo: {len(models_to_test)} models x "
        f"{len(conditions)} conditions x {len(sample_keys)} samples = "
        f"{total_experiments} experiments ({completed} cached, {remaining} to run)"
    )

    start_time = time.monotonic()
    done_count = completed
    run_count = 0  # experiments actually run this session (for ETA)

    # Runtime guard state
    model_parse_errors: dict[str, int] = {}
    model_total_samples: dict[str, int] = {}
    model_consecutive_failures: dict[str, int] = {}
    model_skipped: set[str] = set()

    for model_name in models_to_test:
        if model_name in model_skipped:
            continue
        model_tag = MODELS[model_name]
        for condition in conditions:
            if model_name in model_skipped:
                break
            condition_correct = 0
            condition_total = 0
            condition_parse_errors = 0

            for sample_key in sample_keys:
                ekey = experiment_key(model_name, condition, sample_key)
                if ekey in ckpt["results"]:
                    continue

                # Read source code.
                sample_path = CORPUS_DIR / sample_key
                if not sample_path.exists():
                    continue
                code = sample_path.read_text()

                # Get scan data.
                findings, graph = scan_cache.get(sample_key, ([], {}))
                graph_clean = strip_paths(graph)
                findings_clean = strip_paths(findings)

                # Build prompt and run.
                gt = ground_truth[sample_key]

                if condition in ("E", "F"):
                    # --- Tiebreaker pipeline for conditions E/F ---
                    base_cond = "C" if condition == "E" else "D"
                    base_ekey = experiment_key(model_name, base_cond, sample_key)
                    base_result = ckpt["results"].get(base_ekey)

                    t0 = time.monotonic()

                    if base_result and base_result["response"].get("parsed") is not None:
                        # Reuse cached Pass 2 result.
                        pass2_parsed = base_result["response"]["parsed"]
                        pass2_error = base_result["response"].get("error")
                        pass2_raw = base_result["response"].get("raw", "")
                    else:
                        # Run the base condition fresh.
                        if base_cond == "C":
                            base_messages = prompt_cpg(code, graph_clean)
                        else:
                            base_messages = prompt_cpg_findings(
                                code, graph_clean, findings_clean
                            )
                        if is_anthropic_model(model_name):
                            base_resp = call_anthropic(model_tag, base_messages)
                        else:
                            base_resp = call_ollama(model_tag, base_messages)
                        pass2_parsed = base_resp["parsed"]
                        pass2_error = base_resp["error"]
                        pass2_raw = base_resp["raw_response"]

                    # If Pass 2 failed, record error and move on.
                    if pass2_error or pass2_parsed is None:
                        call_duration = time.monotonic() - t0
                        if pass2_error:
                            sc = SampleScore(sample=sample_key, error=pass2_error)
                        else:
                            sc = SampleScore(sample=sample_key, parse_error=True)
                        ckpt["results"][ekey] = {
                            "model": model_name,
                            "condition": condition,
                            "sample": sample_key,
                            "pass2_condition": base_cond,
                            "disagreement": False,
                            "tiebreaker_called": False,
                            "response": {
                                "raw": (pass2_raw or "")[:2000],
                                "parsed": pass2_parsed,
                                "error": pass2_error,
                            },
                            "score": {
                                "correct_classification": sc.correct_classification,
                                "correct_cwe": sc.correct_cwe,
                                "false_positive_filtered": sc.false_positive_filtered,
                                "value_add": sc.value_add,
                                "degradation": sc.degradation,
                                "parse_error": sc.parse_error,
                                "error": sc.error,
                            },
                            "call_duration_s": round(call_duration, 2),
                            "timestamp": datetime.now(timezone.utc).isoformat(),
                        }
                        save_checkpoint(ckpt)
                        done_count += 1
                        run_count += 1
                        condition_total += 1
                        continue

                    # Detect disagreement.
                    has_det_findings = len(findings) > 0
                    llm_says_vuln = _llm_says_vulnerable(pass2_parsed, base_cond)
                    disagreement = has_det_findings != llm_says_vuln

                    vote_record: dict[str, Any] | None = None
                    final_parsed = pass2_parsed
                    final_raw = pass2_raw or ""
                    tiebreaker_called = False

                    if disagreement:
                        # Build tiebreaker prompt and call.
                        det_summary = summarize_deterministic(findings)
                        llm_summary = summarize_llm_response(pass2_parsed, base_cond)
                        tb_messages = prompt_tiebreaker(
                            code, det_summary, llm_summary, graph_clean
                        )
                        if is_anthropic_model(model_name):
                            tb_result = call_anthropic(model_tag, tb_messages)
                        else:
                            tb_result = call_ollama(model_tag, tb_messages)
                        tiebreaker_called = True

                        tb_parsed = tb_result["parsed"]
                        tb_vote = _llm_says_vulnerable(tb_parsed, "C")  # ABC format

                        det_vote = has_det_findings
                        pass2_vote = llm_says_vuln
                        votes = [det_vote, pass2_vote, tb_vote]
                        majority = sum(votes) >= 2

                        vote_record = {
                            "deterministic": det_vote,
                            "pass2": pass2_vote,
                            "tiebreaker": tb_vote,
                            "majority": majority,
                        }

                        # Select the best detailed response for the final result.
                        if majority:
                            # Majority says vulnerable — prefer whichever
                            # "vulnerable" response has detail.
                            if pass2_vote and pass2_parsed:
                                final_parsed = pass2_parsed
                                final_raw = pass2_raw or ""
                            elif tb_parsed:
                                final_parsed = tb_parsed
                                final_raw = tb_result.get("raw_response", "")
                            # else keep pass2 as fallback
                        else:
                            # Majority says not vulnerable.
                            if not pass2_vote and pass2_parsed:
                                final_parsed = pass2_parsed
                                final_raw = pass2_raw or ""
                            elif tb_parsed and not tb_vote:
                                final_parsed = tb_parsed
                                final_raw = tb_result.get("raw_response", "")

                        # Override the vulnerable field to match majority vote.
                        if final_parsed is not None:
                            final_parsed = dict(final_parsed)
                            final_parsed["vulnerable"] = majority
                            # Normalize D-format keys for ABC scoring.
                            if "overall_vulnerable" in final_parsed:
                                del final_parsed["overall_vulnerable"]
                            if "review" in final_parsed and "findings" not in final_parsed:
                                # Convert review verdicts to findings list.
                                converted = []
                                for r in final_parsed.get("review", []):
                                    if r.get("verdict") == "true_positive":
                                        converted.append({
                                            "cwe_id": (
                                                r.get("correct_cwe")
                                                or r.get("original_cwe", "")
                                            ),
                                            "line": 0,
                                            "explanation": r.get("explanation", ""),
                                        })
                                final_parsed["findings"] = converted
                                del final_parsed["review"]

                    call_duration = time.monotonic() - t0

                    # Score the final result with ABC scorer.
                    sc = score_abc(final_parsed, gt, findings, sample_key)

                    # Store result with tiebreaker metadata.
                    result_record: dict[str, Any] = {
                        "model": model_name,
                        "condition": condition,
                        "sample": sample_key,
                        "pass2_condition": base_cond,
                        "disagreement": disagreement,
                        "tiebreaker_called": tiebreaker_called,
                        "response": {
                            "raw": final_raw[:2000],
                            "parsed": final_parsed,
                            "error": None,
                        },
                        "score": {
                            "correct_classification": sc.correct_classification,
                            "correct_cwe": sc.correct_cwe,
                            "false_positive_filtered": sc.false_positive_filtered,
                            "value_add": sc.value_add,
                            "degradation": sc.degradation,
                            "parse_error": sc.parse_error,
                            "error": sc.error,
                        },
                        "call_duration_s": round(call_duration, 2),
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                    }
                    if vote_record is not None:
                        result_record["vote"] = vote_record
                    ckpt["results"][ekey] = result_record

                else:
                    # --- Standard pipeline for conditions A/B/C/D ---
                    if condition == "A":
                        messages = prompt_cold(code)
                    elif condition == "B":
                        messages = prompt_hinted(code)
                    elif condition == "C":
                        messages = prompt_cpg(code, graph_clean)
                    elif condition == "D":
                        messages = prompt_cpg_findings(code, graph_clean, findings_clean)
                    else:
                        continue

                    # Call model.
                    t0 = time.monotonic()
                    if is_anthropic_model(model_name):
                        result = call_anthropic(model_tag, messages)
                    else:
                        result = call_ollama(model_tag, messages)
                    call_duration = time.monotonic() - t0

                    # Score.
                    if result["error"]:
                        sc = SampleScore(
                            sample=sample_key, error=result["error"]
                        )
                    elif result["parsed"] is None:
                        sc = SampleScore(sample=sample_key, parse_error=True)
                    else:
                        if condition == "D":
                            sc = score_d(
                                result["parsed"], gt, findings, sample_key
                            )
                        else:
                            sc = score_abc(
                                result["parsed"], gt, findings, sample_key
                            )

                    # Store result.
                    ckpt["results"][ekey] = {
                        "model": model_name,
                        "condition": condition,
                        "sample": sample_key,
                        "response": {
                            "raw": result["raw_response"][:2000],
                            "parsed": result["parsed"],
                            "error": result["error"],
                        },
                        "score": {
                            "correct_classification": sc.correct_classification,
                            "correct_cwe": sc.correct_cwe,
                            "false_positive_filtered": sc.false_positive_filtered,
                            "value_add": sc.value_add,
                            "degradation": sc.degradation,
                            "parse_error": sc.parse_error,
                            "error": sc.error,
                        },
                        "call_duration_s": round(call_duration, 2),
                        "timestamp": datetime.now(timezone.utc).isoformat(),
                    }

                save_checkpoint(ckpt)
                done_count += 1
                run_count += 1
                condition_total += 1
                if sc.parse_error:
                    condition_parse_errors += 1
                    model_parse_errors[model_name] = model_parse_errors.get(model_name, 0) + 1
                model_total_samples[model_name] = model_total_samples.get(model_name, 0) + 1
                if sc.correct_classification:
                    condition_correct += 1

                # Early stop check after 20 samples
                if condition_total == 20 and condition_correct < 4:
                    print(
                        f"[{ts()}] EARLY STOP: {model_name} cond={condition} "
                        f"at {condition_correct}/20 ({condition_correct/20:.0%}) "
                        f"— skipping remaining samples"
                    )
                    break

            # Progress after each model+condition.
            elapsed = time.monotonic() - start_time
            if run_count > 0:
                rate = elapsed / run_count
                eta = rate * (total_experiments - done_count)
                eta_str = elapsed_str(eta)
            else:
                eta_str = "?"

            acc_str = (
                f"{condition_correct}/{condition_total}"
                if condition_total > 0
                else "cached"
            )
            pe_str = f" pe={condition_parse_errors}" if condition_parse_errors > 0 else ""
            print(
                f"[{ts()}] {model_name} cond={condition}: "
                f"{acc_str} correct{pe_str} | "
                f"{done_count}/{total_experiments} done | "
                f"elapsed {elapsed_str(elapsed)} | ETA {eta_str}"
            )

            # Runtime guard: parse error rate
            model_pe = model_parse_errors.get(model_name, 0)
            model_ts = model_total_samples.get(model_name, 0)
            if model_ts > 0:
                pe_rate = model_pe / model_ts
                if pe_rate > 0.8 and model_ts >= len(sample_keys):
                    print(
                        f"[{ts()}] GUARD: {model_name} has {pe_rate:.0%} parse error "
                        f"rate — skipping remaining conditions"
                    )
                    model_skipped.add(model_name)

            # Runtime guard: catastrophic failure
            if condition_total > 0:
                condition_accuracy = condition_correct / condition_total
                if condition_accuracy < 0.2:
                    consecutive_failures = model_consecutive_failures.get(model_name, 0) + 1
                    model_consecutive_failures[model_name] = consecutive_failures
                    if consecutive_failures >= 2:
                        print(
                            f"[{ts()}] GUARD: {model_name} has <20% accuracy for "
                            f"2 consecutive conditions — skipping remaining"
                        )
                        model_skipped.add(model_name)
                else:
                    model_consecutive_failures[model_name] = 0

    # ---------------------------------------------------------------------------
    # Generate outputs
    # ---------------------------------------------------------------------------

    print(f"[{ts()}] Generating scorecard...")

    # Rebuild scores from checkpoint for aggregation.
    all_metrics: list[AggregateMetrics] = []
    for model_name in models_to_test:
        for condition in conditions:
            scores: list[SampleScore] = []
            for sample_key in sample_keys:
                ekey = experiment_key(model_name, condition, sample_key)
                r = ckpt["results"].get(ekey)
                if r is None:
                    continue
                s = r["score"]
                sc = SampleScore(
                    sample=sample_key,
                    model=model_name,
                    condition=condition,
                    correct_classification=s["correct_classification"],
                    correct_cwe=s["correct_cwe"],
                    false_positive_filtered=s["false_positive_filtered"],
                    value_add=s["value_add"],
                    degradation=s["degradation"],
                    parse_error=s["parse_error"],
                    error=s["error"],
                )
                scores.append(sc)
            if scores:
                metrics = aggregate(scores, ground_truth, model_name, condition)
                all_metrics.append(metrics)

    # JSON scorecard.
    scorecard_data = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "models_tested": models_to_test,
        "conditions": conditions,
        "total_samples": len(sample_keys),
        "metrics": [m.to_dict() for m in all_metrics],
    }
    SCORECARD_JSON.write_text(json.dumps(scorecard_data, indent=2))
    print(f"  -> {SCORECARD_JSON}")

    # HTML scorecard.
    html = generate_html_scorecard(all_metrics, ckpt, ground_truth)
    SCORECARD_HTML.write_text(html)
    print(f"  -> {SCORECARD_HTML}")

    # Markdown summary.
    summary = generate_summary(all_metrics, ground_truth)
    SUMMARY_MD.write_text(summary)
    print(f"  -> {SUMMARY_MD}")

    total_elapsed = time.monotonic() - start_time
    print(f"[{ts()}] Rodeo complete in {elapsed_str(total_elapsed)}.")


if __name__ == "__main__":
    main()
