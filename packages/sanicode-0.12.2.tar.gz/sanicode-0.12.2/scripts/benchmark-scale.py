#!/usr/bin/env python3
"""Scale benchmark harness for sanicode.

Measures wall-clock time, peak RSS, and per-stage breakdowns across
real open-source codebases.
"""

from __future__ import annotations

import argparse
import dataclasses
import json
import os
import platform
import resource
import shutil
import subprocess
import sys
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from rich.console import Console
from rich.table import Table

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT / "src"))

from sanicode.config import SanicodeConfig, load_config  # noqa: E402
from sanicode.scanner.executor import run_scan  # noqa: E402
from sanicode.version import __version__  # noqa: E402

console = Console()

CORPUS = [
    {
        "name": "flask",
        "url": "https://github.com/pallets/flask.git",
        "ref": "3.0.3",
        "description": "Micro web framework (~15K LOC)",
        "slow": False,
    },
    {
        "name": "requests",
        "url": "https://github.com/psf/requests.git",
        "ref": "v2.31.0",
        "description": "HTTP library (~15K LOC)",
        "slow": False,
    },
    {
        "name": "fastapi",
        "url": "https://github.com/fastapi/fastapi.git",
        "ref": "0.110.0",
        "description": "Async web framework (~25K LOC)",
        "slow": False,
    },
    {
        "name": "django",
        "url": "https://github.com/django/django.git",
        "ref": "5.0.4",
        "description": "Full web framework (~100K+ LOC)",
        "slow": True,
    },
]

DEFAULT_EXCLUDE = [
    "**/__pycache__/**",
    "**/.git/**",
    "**/tests/**",
    "**/test/**",
]


@dataclass
class ProjectResult:
    name: str
    git_ref: str
    loc: int
    file_count: int
    finding_count: int
    wall_clock_s: float
    peak_rss_mb: float
    stage_timings: dict[str, float]
    llm_tier: str
    error: str | None


@dataclass
class BenchmarkOutput:
    metadata: dict
    results: list[ProjectResult]


def collect_hardware_info() -> dict:
    return {
        "platform": platform.platform(),
        "machine": platform.machine(),
        "python_version": platform.python_version(),
        "cpu_count": os.cpu_count(),
        "sanicode_version": __version__,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


def clone_or_update(project: dict, cache_dir: Path) -> Path:
    """Clone the project at the given ref, skipping if already cached."""
    dest = cache_dir / project["name"]
    ref = project["ref"]

    if dest.exists():
        # Check if the existing checkout already matches the desired tag.
        result = subprocess.run(
            ["git", "describe", "--tags", "--exact-match", "HEAD"],
            cwd=dest,
            capture_output=True,
            text=True,
        )
        current_tag = result.stdout.strip()
        if current_tag == ref:
            console.print(
                f"    [dim]Cache hit for {project['name']} at {ref}, skipping clone.[/dim]"
            )
            return dest
        # Tag mismatch — warn the user explicitly and re-clone.
        console.print(
            f"    [yellow]Warning: cached {project['name']} is at tag '{current_tag}', "
            f"expected '{ref}'. Deleting and re-cloning.[/yellow]"
        )
        shutil.rmtree(dest)

    subprocess.run(
        [
            "git",
            "clone",
            "--depth",
            "1",
            "--branch",
            ref,
            project["url"],
            str(dest),
        ],
        check=True,
        capture_output=True,
        text=True,
    )
    return dest


def count_loc(repo_dir: Path) -> int:
    """Count non-blank, non-comment lines across all .py files in the repository."""
    total = 0
    for py_file in repo_dir.rglob("*.py"):
        try:
            text = py_file.read_text(encoding="utf-8")
        except (UnicodeDecodeError, OSError):
            continue
        for line in text.splitlines():
            stripped = line.strip()
            if stripped and not stripped.startswith("#"):
                total += 1
    return total


def _effective_llm_tier(cfg: SanicodeConfig) -> str:
    if cfg.llm.reasoning.endpoint:
        return "reasoning"
    if cfg.llm.analysis.endpoint:
        return "analysis"
    if cfg.llm.fast.endpoint:
        return "fast"
    return "none"


def _rss_delta_mb(before: int, after: int) -> float:
    """Convert an ru_maxrss delta to megabytes (macOS=bytes, Linux=KB)."""
    delta = after - before
    return delta / (1024 * 1024) if sys.platform == "darwin" else delta / 1024


def run_benchmark(project: dict, repo_dir: Path, cfg: SanicodeConfig) -> ProjectResult:
    """Run a single scan benchmark, recording wall-clock time and peak RSS.

    Note: ru_maxrss is a high-water mark that never decreases within a
    process, so per-project deltas become less accurate for later projects.
    """
    tier = _effective_llm_tier(cfg)
    rss_before = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss

    try:
        loc = count_loc(repo_dir)
        t0 = time.monotonic()
        output = run_scan(repo_dir, cfg)
        wall_clock_s = time.monotonic() - t0

        rss_after = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        peak_rss_mb = _rss_delta_mb(rss_before, rss_after)

        return ProjectResult(
            name=project["name"],
            git_ref=project["ref"],
            loc=loc,
            file_count=output.file_count,
            finding_count=len(output.enriched_findings),
            wall_clock_s=wall_clock_s,
            peak_rss_mb=peak_rss_mb,
            stage_timings=output.stage_timings,
            llm_tier=tier,
            error=None,
        )
    except Exception as exc:  # noqa: BLE001
        rss_after = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        peak_rss_mb = _rss_delta_mb(rss_before, rss_after)

        return ProjectResult(
            name=project["name"],
            git_ref=project["ref"],
            loc=0,
            file_count=0,
            finding_count=0,
            wall_clock_s=0.0,
            peak_rss_mb=peak_rss_mb,
            stage_timings={},
            llm_tier=tier,
            error=str(exc),
        )


def print_summary(results: list[ProjectResult]) -> None:
    """Print a Rich summary table and per-project stage-timing sub-tables."""
    main_table = Table(title="Benchmark Results", show_lines=True)
    main_table.add_column("Project", style="cyan")
    main_table.add_column("LOC", justify="right")
    main_table.add_column("Files", justify="right")
    main_table.add_column("Findings", justify="right")
    main_table.add_column("Wall Clock (s)", justify="right")
    main_table.add_column("Peak RSS (MB)", justify="right")
    main_table.add_column("LLM Tier")
    main_table.add_column("Status")

    for r in results:
        if r.error:
            status = r.error[:40]
            status_style = "red"
        else:
            status = "OK"
            status_style = "green"

        main_table.add_row(
            r.name,
            f"{r.loc:,}" if r.loc else "—",
            str(r.file_count) if r.file_count else "—",
            str(r.finding_count),
            f"{r.wall_clock_s:.2f}" if r.wall_clock_s else "—",
            f"{r.peak_rss_mb:.1f}" if r.peak_rss_mb else "—",
            r.llm_tier,
            f"[{status_style}]{status}[/{status_style}]",
        )

    console.print(main_table)

    # Per-project stage timing sub-tables for successful runs.
    for r in results:
        if r.error or not r.stage_timings:
            continue

        stage_table = Table(
            title=f"Stage timings — {r.name} ({r.llm_tier})",
            show_lines=False,
        )
        stage_table.add_column("Stage", style="dim")
        stage_table.add_column("Duration (s)", justify="right")

        for stage, duration in r.stage_timings.items():
            stage_table.add_row(stage, f"{duration:.3f}")

        console.print(stage_table)


def make_nollm_config(exclude_patterns: list[str]) -> SanicodeConfig:
    """Build a config with no LLM and no dependency scanning."""
    cfg = SanicodeConfig()
    cfg.dependencies.enabled = False
    cfg.scan.exclude_patterns = exclude_patterns
    return cfg


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Sanicode scale benchmark harness"
    )
    parser.add_argument(
        "-o",
        "--output",
        default="bench-results.json",
        help="JSON output path",
    )
    parser.add_argument(
        "--cache-dir",
        default=Path.home() / ".cache" / "sanicode" / "bench-corpora",
        type=Path,
        help="Corpus cache directory",
    )
    parser.add_argument(
        "--projects",
        default=None,
        help="Comma-separated project filter (e.g. flask,fastapi)",
    )
    parser.add_argument(
        "--include-llm",
        action="store_true",
        help="Also benchmark with LLM-enabled config",
    )
    args = parser.parse_args()

    # Filter corpus by name if requested.
    projects = CORPUS
    if args.projects:
        names = {n.strip() for n in args.projects.split(",")}
        projects = [p for p in CORPUS if p["name"] in names]
        if not projects:
            print(
                f"No matching projects. Available: {', '.join(p['name'] for p in CORPUS)}",
                file=sys.stderr,
            )
            sys.exit(1)

    # Surface a notice for slow projects so users aren't surprised.
    slow = [p["name"] for p in projects if p.get("slow")]
    if slow:
        print(
            f"Note: {', '.join(slow)} marked as slow — benchmark may take a while.",
            file=sys.stderr,
        )

    args.cache_dir.mkdir(parents=True, exist_ok=True)

    nollm_cfg = make_nollm_config(DEFAULT_EXCLUDE)
    configs: list[tuple[str, SanicodeConfig]] = [("no-llm", nollm_cfg)]

    if args.include_llm:
        llm_cfg = load_config()
        llm_cfg.dependencies.enabled = False
        llm_cfg.scan.exclude_patterns = DEFAULT_EXCLUDE
        configs.append(("llm", llm_cfg))

    all_results: list[ProjectResult] = []

    for label, cfg in configs:
        tier = _effective_llm_tier(cfg)
        console.print(f"\n[bold]Running benchmarks ({label}, tier={tier})[/bold]\n")

        for proj in projects:
            console.print(
                f"  Benchmarking [cyan]{proj['name']}[/cyan] ({proj['description']})..."
            )
            try:
                repo_dir = clone_or_update(proj, args.cache_dir)
            except Exception as exc:  # noqa: BLE001
                all_results.append(
                    ProjectResult(
                        name=proj["name"],
                        git_ref=proj["ref"],
                        loc=0,
                        file_count=0,
                        finding_count=0,
                        wall_clock_s=0.0,
                        peak_rss_mb=0.0,
                        stage_timings={},
                        llm_tier=tier,
                        error=f"clone failed: {exc}",
                    )
                )
                continue

            result = run_benchmark(proj, repo_dir, cfg)
            all_results.append(result)

    print_summary(all_results)

    output = BenchmarkOutput(
        metadata=collect_hardware_info(),
        results=all_results,
    )

    output_path = Path(args.output)
    output_path.write_text(
        json.dumps(dataclasses.asdict(output), indent=2, default=str)
    )
    console.print(f"\nResults written to [green]{output_path}[/green]")


if __name__ == "__main__":
    main()
