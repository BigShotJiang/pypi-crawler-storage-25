#!/usr/bin/env python3
"""Eval iteration harness — run sanicode score serially per-repo, merge results."""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path

import yaml

RUNS_DIR = Path("sanicode-eval-run/runs")

# Internal tier value → human-readable label used in the JSON schema.
_TIER_LABEL = {1: 1, 2: 2, 3: 1.5}
_NON_SCORABLE_TYPES = {"tool", "reference"}

# Repos to skip entirely — too large to finish in reasonable time.
SKIP_REPOS = {"juliet-test-suite-c"}


# ---------------------------------------------------------------------------
# Catalog loading
# ---------------------------------------------------------------------------

def _load_entities(repos_dir: Path, tiers: set[str] | None = None) -> list[dict]:
    """Build a flat list of scorable entities from the ground-truth catalogs.

    Args:
        repos_dir: Path to the unsanitary-code-examples repo.
        tiers: Set of tier labels to include (e.g. {"Tier 1.5", "Tier 2"}).
               None means include all tiers.

    Returns a list of dicts, each with:
      - name: str         identifier passed to -r
      - display: str      human-friendly label
      - tier_label: str   "Tier 1", "Tier 1.5", or "Tier 2"
    """
    scoring_dir = repos_dir / "scoring"
    entities: list[dict] = []

    # Tier 1 — synthetic projects
    synthetic_path = scoring_dir / "synthetic-ground-truth.yaml"
    if synthetic_path.exists() and (tiers is None or "Tier 1" in tiers):
        raw = yaml.safe_load(synthetic_path.read_text(encoding="utf-8"))
        for entry in raw.get("projects", []):
            proj = entry.get("project", {})
            pid = proj.get("id", "")
            pname = proj.get("name", pid)
            if pid:
                entities.append({"name": pid, "display": pname, "tier_label": "Tier 1"})

    # Tier 1.5 — real repos with line-level annotations.
    # Always build tier1_5_names for deduplication against Tier 2, even when
    # Tier 1.5 itself is not selected.
    tier1_5_path = scoring_dir / "python-ground-truth.yaml"
    tier1_5_names: set[str] = set()
    if tier1_5_path.exists():
        raw = yaml.safe_load(tier1_5_path.read_text(encoding="utf-8"))
        for entry in raw.get("projects", []):
            proj = entry.get("project", {})
            pname = proj.get("name", "")
            pid = proj.get("id", pname)
            if pname:
                tier1_5_names.add(pname)
                if tiers is None or "Tier 1.5" in tiers:
                    entities.append({"name": pname, "display": pname, "tier_label": "Tier 1.5"})

    # Tier 2 — real repos (skip tool/reference, SKIP_REPOS, and anything already in Tier 1.5)
    real_repos_path = scoring_dir / "real-repos-catalog.yaml"
    if real_repos_path.exists() and (tiers is None or "Tier 2" in tiers):
        raw = yaml.safe_load(real_repos_path.read_text(encoding="utf-8"))
        for entry in raw.get("repositories", []):
            repo_name = entry.get("name", "")
            repo_type = entry.get("type", "")
            if repo_type in _NON_SCORABLE_TYPES:
                continue
            if repo_name in tier1_5_names:
                continue
            if repo_name in SKIP_REPOS:
                continue
            if repo_name:
                entities.append({"name": repo_name, "display": repo_name, "tier_label": "Tier 2"})

    return entities


# ---------------------------------------------------------------------------
# Result merging
# ---------------------------------------------------------------------------

def _recompute_aggregate(per_repo: list[dict]) -> dict:
    """Recompute the aggregate section from a merged per_repo list.

    Mirrors the logic in ScoringReport / generate_json_report without
    importing sanicode (to keep this script self-contained).
    """
    tier1_tp = tier1_fp = tier1_fn = 0
    tier1_5_tp = tier1_5_fp = tier1_5_fn = 0
    tier2_tp = tier2_fp = 0
    total_findings = 0
    repos_with_findings = 0
    has_tier1_5 = False

    total_gaps = 0
    total_top25 = 0

    for r in per_repo:
        total_findings += r.get("findings_count", 0)
        if r.get("findings_count", 0) > 0:
            repos_with_findings += 1

        tier = r.get("tier")

        if tier == 1:
            t1 = r.get("tier1", {})
            tier1_tp += t1.get("tp", 0)
            tier1_fp += t1.get("fp", 0)
            tier1_fn += t1.get("fn", 0)
        elif tier == 1.5:
            has_tier1_5 = True
            t1 = r.get("tier1", {})
            tier1_5_tp += t1.get("tp", 0)
            tier1_5_fp += t1.get("fp", 0)
            tier1_5_fn += t1.get("fn", 0)
            t2 = r.get("tier2", {})
            tier2_tp += t2.get("tp", 0)
            tier2_fp += t2.get("fp", 0)
        elif tier == 2:
            t2 = r.get("tier2", {})
            tier2_tp += t2.get("tp", 0)
            tier2_fp += t2.get("fp", 0)

        ga = r.get("gap_analysis", {})
        total_gaps += ga.get("gap_count", 0)
        total_top25 += ga.get("top_25_gap_count", 0)

    def _precision(tp, fp):
        return tp / (tp + fp) if (tp + fp) > 0 else None

    def _recall(tp, fn):
        return tp / (tp + fn) if (tp + fn) > 0 else None

    def _f1(p, r):
        if p is not None and r is not None and (p + r) > 0:
            return 2 * p * r / (p + r)
        return None

    t1_p = _precision(tier1_tp, tier1_fp)
    t1_r = _recall(tier1_tp, tier1_fn)
    t1_f = _f1(t1_p, t1_r)

    # Grade uses the best available precision+recall pair.  Prefer T1
    # (line-level), fall back to T1.5, then use T2 precision with recall=1
    # (Tier 2 is category-level so recall isn't directly measured).
    grade_r, grade_p = t1_r, t1_p
    if grade_r is None or grade_p is None:
        t15_p_tmp = _precision(tier1_5_tp, tier1_5_fp)
        t15_r_tmp = _recall(tier1_5_tp, tier1_5_fn)
        if t15_r_tmp is not None and t15_p_tmp is not None:
            grade_r, grade_p = t15_r_tmp, t15_p_tmp
        else:
            # Tier 2 only — use precision; assume recall=1 since we don't
            # measure it at category level.
            t2_p_tmp = _precision(tier2_tp, tier2_fp)
            grade_r = 1.0 if t2_p_tmp is not None else None
            grade_p = t2_p_tmp
    grade = _compute_grade(grade_r, grade_p)

    agg: dict = {
        "repos_scanned": len(per_repo),
        "repos_with_findings": repos_with_findings,
        "tier1": {
            "tp": tier1_tp, "fp": tier1_fp, "fn": tier1_fn,
            "precision": t1_p, "recall": t1_r, "f1": t1_f,
        },
        "tier2": {
            "tp": tier2_tp, "fp": tier2_fp,
            "precision": _precision(tier2_tp, tier2_fp),
        },
        "grade": grade,
        "gaps": {"total": total_gaps, "top_25": total_top25},
    }

    if has_tier1_5:
        t15_p = _precision(tier1_5_tp, tier1_5_fp)
        t15_r = _recall(tier1_5_tp, tier1_5_fn)
        t15_f = _f1(t15_p, t15_r)
        agg["tier1_5"] = {
            "tp": tier1_5_tp, "fp": tier1_5_fp, "fn": tier1_5_fn,
            "precision": t15_p, "recall": t15_r, "f1": t15_f,
        }

    return agg


def _compute_grade(recall, precision) -> str:
    if recall is None or precision is None:
        return "F"
    if recall >= 0.85 and precision >= 0.80:
        return "A"
    if recall >= 0.70 and precision >= 0.70:
        return "B"
    if recall >= 0.55 and precision >= 0.60:
        return "C"
    if recall >= 0.40 and precision >= 0.50:
        return "D"
    return "F"


# ---------------------------------------------------------------------------
# Progress line formatting
# ---------------------------------------------------------------------------

def _format_repo_line(index: int, total: int, display: str, tier_label: str,
                      repo_entry: dict | None, elapsed: float, error: str | None) -> str:
    prefix = f"[{index}/{total}] {display} ({tier_label})..."

    if error:
        return f"{prefix} ERROR: {error} ({elapsed:.1f}s)"

    if repo_entry is None:
        return f"{prefix} skipped ({elapsed:.1f}s)"

    findings = repo_entry.get("findings_count", 0)
    tier = repo_entry.get("tier")

    parts = [f"{findings} findings"]

    if tier in (1, 1.5):
        t1 = repo_entry.get("tier1", {})
        tp = t1.get("tp", 0)
        fp = t1.get("fp", 0)
        p = t1.get("precision")
        p_str = f"{p:.2f}" if p is not None else "N/A"
        parts.append(f"TP={tp} FP={fp} P={p_str}")
    elif tier == 2:
        t2 = repo_entry.get("tier2", {})
        tp = t2.get("tp", 0)
        fp = t2.get("fp", 0)
        p = t2.get("precision")
        p_str = f"{p:.2f}" if p is not None else "N/A"
        parts.append(f"TP={tp} FP={fp} P={p_str}")

    return f"{prefix} {', '.join(parts)} ({elapsed:.1f}s)"


# ---------------------------------------------------------------------------
# Baseline comparison
# ---------------------------------------------------------------------------

def find_latest_run(runs_dir: Path, exclude: Path | None = None) -> Path | None:
    candidates = sorted(runs_dir.glob("*/scoring-report.json"))
    for c in reversed(candidates):
        if exclude and c.parent == exclude:
            continue
        return c
    return None


def _print_delta(current: dict, baseline: dict) -> None:
    curr_agg = current.get("aggregate", {})
    prev_agg = baseline.get("aggregate", {})

    curr_grade = curr_agg.get("grade", "?")
    prev_grade = prev_agg.get("grade", "?")
    grade_change = f"{prev_grade} → {curr_grade}" if curr_grade != prev_grade else curr_grade

    curr_t1 = curr_agg.get("tier1", {})
    prev_t1 = prev_agg.get("tier1", {})

    def _delta_str(curr_val, prev_val, fmt=".2f"):
        if curr_val is None or prev_val is None:
            return "N/A"
        delta = curr_val - prev_val
        sign = "+" if delta >= 0 else ""
        return f"{curr_val:{fmt}} ({sign}{delta:{fmt}})"

    curr_t1_p = curr_t1.get("precision")
    prev_t1_p = prev_t1.get("precision")
    curr_t1_r = curr_t1.get("recall")
    prev_t1_r = prev_t1.get("recall")

    curr_t2 = curr_agg.get("tier2", {})
    prev_t2 = prev_agg.get("tier2", {})
    curr_t2_p = curr_t2.get("precision")
    prev_t2_p = prev_t2.get("precision")

    curr_gaps = curr_agg.get("gaps", {}).get("total", 0)
    prev_gaps = prev_agg.get("gaps", {}).get("total", 0)
    gap_delta = curr_gaps - prev_gaps
    gap_sign = "+" if gap_delta >= 0 else ""

    print("\nDelta from baseline:")
    print(f"  Grade:         {grade_change}")
    print(f"  T1 Precision:  {_delta_str(curr_t1_p, prev_t1_p)}")
    print(f"  T1 Recall:     {_delta_str(curr_t1_r, prev_t1_r)}")
    print(f"  T2 Precision:  {_delta_str(curr_t2_p, prev_t2_p)}")
    print(f"  Gaps:          {curr_gaps} ({gap_sign}{gap_delta})")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> int:
    parser = argparse.ArgumentParser(description="Run sanicode eval iteration serially")
    parser.add_argument(
        "repos_dir",
        type=Path,
        help="Path to the unsanitary-code-examples repo",
    )
    parser.add_argument(
        "--repos",
        type=str,
        default=None,
        help="Comma-separated list of repos/project IDs to score (default: all)",
    )
    parser.add_argument(
        "--runs-dir",
        type=Path,
        default=RUNS_DIR,
        help=f"Directory to store runs (default: {RUNS_DIR})",
    )
    parser.add_argument(
        "--config",
        type=str,
        default="sanicode-eval.toml",
        help="Sanicode config file (default: sanicode-eval.toml, resolved relative to project root)",
    )
    parser.add_argument(
        "--tiers",
        type=str,
        default="1.5,2",
        help="Comma-separated tier numbers to include: 1, 1.5, 2 (default: 1.5,2)",
    )
    args = parser.parse_args()

    repos_filter = set(args.repos.split(",")) if args.repos else None
    repos_dir = args.repos_dir.resolve()
    tier_filter = {f"Tier {t.strip()}" for t in args.tiers.split(",")}

    config_path = Path(args.config)
    if not config_path.is_absolute():
        config_path = Path(__file__).resolve().parent.parent / config_path

    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    run_dir = args.runs_dir / timestamp
    run_dir.mkdir(parents=True, exist_ok=True)

    # Discover baseline before we start (exclude the run dir we just created).
    baseline_path = find_latest_run(args.runs_dir, exclude=run_dir)

    print(f"Eval run: {timestamp}")
    print(f"Config:   {config_path}")
    print(f"Tiers:    {args.tiers}")
    if baseline_path:
        print(f"Baseline: {baseline_path}")
    print()

    # Build entity list and apply filter.
    try:
        all_entities = _load_entities(repos_dir, tiers=tier_filter)
    except Exception as exc:
        print(f"ERROR: Failed to load entity catalog: {exc}", file=sys.stderr)
        return 1

    if repos_filter:
        entities = [e for e in all_entities if e["name"] in repos_filter]
        missing = repos_filter - {e["name"] for e in entities}
        if missing:
            print(f"WARNING: No catalog entry found for: {', '.join(sorted(missing))}", file=sys.stderr)
    else:
        entities = all_entities

    if not entities:
        print("No entities to score.", file=sys.stderr)
        return 1

    total = len(entities)
    all_per_repo: list[dict] = []
    failed: list[str] = []
    run_start = time.monotonic()

    for idx, entity in enumerate(entities, start=1):
        name = entity["name"]
        display = entity["display"]
        tier_label = entity["tier_label"]

        t0 = time.monotonic()
        repo_entry: dict | None = None
        error_msg: str | None = None

        with tempfile.TemporaryDirectory() as tmpdir:
            cmd = [
                sys.executable, "-m", "sanicode", "score",
                str(repos_dir),
                "--config", str(config_path),
                "--output-dir", tmpdir,
                "--no-llm-judge",
                "-r", name,
            ]
            try:
                result = subprocess.run(
                    cmd,
                    stderr=subprocess.DEVNULL,
                    stdout=subprocess.DEVNULL,
                )
                if result.returncode != 0:
                    error_msg = f"sanicode score exited {result.returncode}"
                    failed.append(name)
                else:
                    report_path = Path(tmpdir) / "scoring-report.json"
                    if report_path.exists():
                        data = json.loads(report_path.read_text(encoding="utf-8"))
                        per_repo_list = data.get("per_repo", [])
                        if per_repo_list:
                            repo_entry = per_repo_list[0]
                            all_per_repo.append(repo_entry)
                    else:
                        error_msg = "no scoring-report.json produced"
                        failed.append(name)
            except Exception as exc:
                error_msg = str(exc)
                failed.append(name)

        elapsed = time.monotonic() - t0
        print(_format_repo_line(idx, total, display, tier_label, repo_entry, elapsed, error_msg))

    total_elapsed = time.monotonic() - run_start

    # Build merged report.
    agg = _recompute_aggregate(all_per_repo)

    # Collect sanicode version from one of the per-repo reports (if any).
    sanicode_version = "unknown"
    report_path_sample = None
    # Re-run one quick non-scanning command to get version if needed.
    try:
        ver_result = subprocess.run(
            [sys.executable, "-c", "from sanicode import __version__; print(__version__)"],
            capture_output=True, text=True,
        )
        if ver_result.returncode == 0:
            sanicode_version = ver_result.stdout.strip()
    except Exception:
        pass

    merged: dict = {
        "sanicode_version": sanicode_version,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "repos_dir": str(repos_dir),
        "aggregate": agg,
        "per_repo": all_per_repo,
    }

    report_out = run_dir / "scoring-report.json"
    report_out.write_text(json.dumps(merged, indent=2, default=str), encoding="utf-8")

    # Final summary banner.
    total_findings = sum(r.get("findings_count", 0) for r in all_per_repo)
    t1 = agg.get("tier1", {})
    t2 = agg.get("tier2", {})
    gaps = agg.get("gaps", {})
    t1_tp = t1.get("tp", 0)
    t1_fp = t1.get("fp", 0)
    t2_tp = t2.get("tp", 0)
    t2_fp = t2.get("fp", 0)
    all_tp = t1_tp + t2_tp
    all_fp = t1_fp + t2_fp
    all_p = all_tp / (all_tp + all_fp) if (all_tp + all_fp) > 0 else None
    p_str = f"{all_p:.2f}" if all_p is not None else "N/A"

    print()
    print("━" * 44)
    print(
        f"Total: {total_findings} findings | TP: {all_tp} | FP: {all_fp} | Precision: {p_str}"
    )
    print(f"Gaps: {gaps.get('total', 0)} ({gaps.get('top_25', 0)} Top-25)")
    print(f"Grade: {agg.get('grade', '?')}")
    print(f"Total time: {total_elapsed:.1f}s")

    if failed:
        print(f"\nFailed ({len(failed)}): {', '.join(failed)}", file=sys.stderr)

    # Baseline comparison.
    if baseline_path and baseline_path.exists():
        try:
            baseline_data = json.loads(baseline_path.read_text(encoding="utf-8"))
            _print_delta(merged, baseline_data)
        except Exception as exc:
            print(f"\nWARNING: Could not load baseline for comparison: {exc}", file=sys.stderr)

    print(f"\nRun saved: {run_dir}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
