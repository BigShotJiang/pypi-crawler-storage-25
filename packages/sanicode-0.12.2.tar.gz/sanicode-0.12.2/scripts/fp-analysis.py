#!/usr/bin/env python3
"""Scan top-10 FP repos and extract per-CWE false positive counts."""

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

SANICODE_ROOT = Path("/Users/wjackson/Developer/sanicode")
REPOS_ROOT = Path("/Users/wjackson/Developer/unsanitary-code-examples")
REPORT_FILE = SANICODE_ROOT / "sanicode-reports" / "scan-result.json"
OUTPUT_DIR = SANICODE_ROOT / "sanicode-reports" / "fp-analysis"

REPOS = {
    "go-test-bench":        {22,77,78,79,88,89,94,113,200,287,330,601,798,918},
    "crAPI":                {22,77,78,89,94,200,215,287,295,306,312,327,330,352,384,400,522,532,601,639,798,915,918},
    "VulnerableApp":        {22,78,79,89,94,200,287,306,312,327,330,347,352,434,502,601,611,639,776,798,916,918,1333},
    "VulnerableApp-php":    {89,79,200,434,287},
    "crypto-attacks":       {326,327,328,330,347},
    "railsgoat":            {22,77,78,79,89,94,113,200,287,327,330,352,384,434,502,601,613,614,639,798,916,1333},
    "Android-InsecureBankv2": {287,319,798,926,200,312,327,22},
    "kubernetes-goat":      {78,200,215,269,284,306,311,502,611,639,732,918},
    "leaky-repo":           {77,79,94,200,287,312,330,502,798,918},
    "NodeGoat":             {79,89,200,215,287,639,352,94,502,798,330,22,78,327},
}


def scan_repo(name: str) -> dict:
    """Run sanicode scan on a repo and return the parsed JSON result."""
    repo_path = REPOS_ROOT / name
    env = os.environ.copy()
    env["ANTHROPIC_API_KEY"] = ""

    cmd = [
        sys.executable, "-m", "sanicode", "scan",
        str(repo_path),
        "--config", str(SANICODE_ROOT / "sanicode-eval.toml"),
        "--format", "json",
        "--offline",
        "--no-deps",
    ]

    print(f"  Scanning {name}...", flush=True)
    result = subprocess.run(
        cmd,
        cwd=str(SANICODE_ROOT),
        env=env,
        capture_output=True,
        text=True,
        timeout=300,
    )

    if not REPORT_FILE.exists():
        print(f"  WARNING: No report for {name}, stderr: {result.stderr[-200:]}")
        return {}

    with open(REPORT_FILE) as f:
        data = json.load(f)

    # Save per-repo copy
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    shutil.copy(REPORT_FILE, OUTPUT_DIR / f"{name}.json")

    return data


def analyze_repo(name: str, data: dict, expected_cwes: set) -> dict:
    """Extract CWE counts and classify as TP or FP."""
    findings = data.get("findings", [])
    cwe_counts = {}
    for f in findings:
        cwe = f.get("cwe_id")
        if cwe:
            cwe_counts[cwe] = cwe_counts.get(cwe, 0) + 1

    tp_cwes = {}
    fp_cwes = {}
    for cwe, count in cwe_counts.items():
        if cwe in expected_cwes:
            tp_cwes[cwe] = count
        else:
            fp_cwes[cwe] = count

    return {
        "total_findings": len(findings),
        "cwe_counts": cwe_counts,
        "tp_cwes": tp_cwes,
        "fp_cwes": fp_cwes,
        "tp_count": sum(tp_cwes.values()),
        "fp_count": sum(fp_cwes.values()),
        "missed_cwes": sorted(expected_cwes - set(cwe_counts.keys())),
    }


def main():
    all_results = {}

    print("=== Scanning repos ===", flush=True)
    for name, expected in REPOS.items():
        data = scan_repo(name)
        if data:
            all_results[name] = analyze_repo(name, data, expected)
        else:
            all_results[name] = {
                "total_findings": 0, "cwe_counts": {}, "tp_cwes": {},
                "fp_cwes": {}, "tp_count": 0, "fp_count": 0, "missed_cwes": sorted(expected),
            }

    # Aggregate FP counts across all repos
    aggregate_fp = {}
    aggregate_tp = {}
    for name, r in all_results.items():
        for cwe, count in r["fp_cwes"].items():
            aggregate_fp[cwe] = aggregate_fp.get(cwe, 0) + count
        for cwe, count in r["tp_cwes"].items():
            aggregate_tp[cwe] = aggregate_tp.get(cwe, 0) + count

    # Print per-repo breakdown
    print("\n" + "=" * 80)
    print("PER-REPO BREAKDOWN")
    print("=" * 80)
    for name, r in all_results.items():
        print(f"\n--- {name} ---")
        print(f"  Total findings: {r['total_findings']}  |  TP: {r['tp_count']}  |  FP: {r['fp_count']}")
        if r["fp_cwes"]:
            fp_sorted = sorted(r["fp_cwes"].items(), key=lambda x: -x[1])
            print(f"  FP CWEs: {', '.join(f'CWE-{c}({n})' for c,n in fp_sorted)}")
        if r["tp_cwes"]:
            tp_sorted = sorted(r["tp_cwes"].items(), key=lambda x: -x[1])
            print(f"  TP CWEs: {', '.join(f'CWE-{c}({n})' for c,n in tp_sorted)}")
        if r["missed_cwes"]:
            print(f"  Missed (expected but not found): {', '.join(f'CWE-{c}' for c in r['missed_cwes'])}")

    # Top 20 FP CWEs
    print("\n" + "=" * 80)
    print("TOP 20 FP CWEs (aggregate across all repos)")
    print("=" * 80)
    print(f"{'Rank':<6}{'CWE':<12}{'FP Count':<12}{'Repos Affected'}")
    print("-" * 50)

    fp_sorted = sorted(aggregate_fp.items(), key=lambda x: -x[1])[:20]
    for i, (cwe, count) in enumerate(fp_sorted, 1):
        repos_with = [n for n, r in all_results.items() if cwe in r["fp_cwes"]]
        print(f"{i:<6}CWE-{cwe:<8}{count:<12}{len(repos_with)} repos")

    # Summary totals
    total_tp = sum(r["tp_count"] for r in all_results.values())
    total_fp = sum(r["fp_count"] for r in all_results.values())
    total_all = sum(r["total_findings"] for r in all_results.values())
    print(f"\nTOTALS: {total_all} findings = {total_tp} TP + {total_fp} FP")
    if total_all > 0:
        print(f"FP rate: {total_fp/total_all*100:.1f}%")

    # Save structured output
    output = {
        "per_repo": all_results,
        "aggregate_fp": dict(sorted(aggregate_fp.items(), key=lambda x: -x[1])),
        "aggregate_tp": dict(sorted(aggregate_tp.items(), key=lambda x: -x[1])),
        "totals": {"total": total_all, "tp": total_tp, "fp": total_fp},
    }
    out_path = OUTPUT_DIR / "fp-analysis-results.json"
    with open(out_path, "w") as f:
        json.dump(output, f, indent=2)
    print(f"\nDetailed results saved to: {out_path}")


if __name__ == "__main__":
    main()
