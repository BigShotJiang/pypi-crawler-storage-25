#!/usr/bin/env bash
# Mirror sanicode and model images to a disconnected (private) registry.
#
# Prerequisites: skopeo must be installed and authenticated to both the source
# registry (quay.io) and the target registry before running this script.
#
# Usage:
#   ./scripts/mirror-images.sh <target-registry> [version]
#
# Examples:
#   ./scripts/mirror-images.sh registry.internal.example.com:5000
#   ./scripts/mirror-images.sh registry.internal.example.com:5000 0.9.0
#
# After mirroring, deploy the ImageDigestMirrorSet so OpenShift rewrites image
# references automatically:
#   oc apply -f deploy/disconnected/imagedigestmirrorset.yaml

set -euo pipefail

TARGET_REGISTRY="${1:?Usage: $0 <target-registry> [version]}"
VERSION="${2:-0.9.0}"

# ---------------------------------------------------------------------------
# Images to mirror.
# ModelCar images are commented out; uncomment and edit the tag if you are
# using the OCI model weight approach (see models/modelcar/README.md).
# ---------------------------------------------------------------------------
IMAGES=(
    "quay.io/wjackson/sanicode:${VERSION}"
    "quay.io/wjackson/sanicode:latest"
    # "quay.io/wjackson/granite-8b-modelcar:v1"
)

echo "==> Mirroring sanicode images to ${TARGET_REGISTRY}"
echo "    Version: ${VERSION}"
echo

for img in "${IMAGES[@]}"; do
    # Strip the leading registry hostname to build the target path.
    # quay.io/wjackson/sanicode:0.9.0  →  <target>/wjackson/sanicode:0.9.0
    rel="${img#*/}"
    target="${TARGET_REGISTRY}/${rel}"

    echo "  Mirroring: ${img}"
    echo "         to: ${target}"

    # --all copies every manifest-list entry (amd64, arm64, etc.).
    # Remove --all if your registry does not support manifest lists.
    skopeo copy --all \
        "docker://${img}" \
        "docker://${target}"

    echo
done

echo "==> Done. Images available at ${TARGET_REGISTRY}"
echo
echo "Next steps:"
echo "  1. Update the mirror hostname in deploy/disconnected/imagedigestmirrorset.yaml"
echo "     (replace '<your-registry>' with ${TARGET_REGISTRY})"
echo "  2. Apply the mirror policy on your OpenShift cluster:"
echo "     oc apply -f deploy/disconnected/imagedigestmirrorset.yaml"
echo "  3. Wait for MachineConfigPool to finish rolling (oc get mcp)."
