#!/usr/bin/env bash
# Prepare a standalone RHEL 9.x host to run sanicode via Podman.
#
# This script must be run as root (sudo) on the target host.  It expects:
#   - Podman to be installed (dnf install -y podman)
#   - The sanicode container image saved as a tar archive (see below)
#
# Saving the image on a connected machine:
#   podman pull quay.io/wjackson/sanicode:0.9.0
#   podman save quay.io/wjackson/sanicode:0.9.0 -o sanicode-0.9.0.tar
#   # Transfer the tar to the disconnected host via scp, rsync, USB, etc.
#
# Usage:
#   sudo ./scripts/setup-rhel-standalone.sh <image-tarball>
#
# Example:
#   sudo ./scripts/setup-rhel-standalone.sh /tmp/sanicode-0.9.0.tar

set -euo pipefail

TARBALL="${1:?Usage: $0 <image-tarball>}"
SERVICE_SRC="$(dirname "${BASH_SOURCE[0]}")/../deploy/standalone/sanicode.service"

# ---------------------------------------------------------------------------
# Validate inputs
# ---------------------------------------------------------------------------
if [[ ! -f "${TARBALL}" ]]; then
    echo "ERROR: tarball not found: ${TARBALL}" >&2
    exit 1
fi

if [[ ! -f "${SERVICE_SRC}" ]]; then
    echo "ERROR: service file not found: ${SERVICE_SRC}" >&2
    echo "  Make sure you are running this script from the sanicode repo root." >&2
    exit 1
fi

if [[ "${EUID}" -ne 0 ]]; then
    echo "ERROR: this script must be run as root (sudo)." >&2
    exit 1
fi

# ---------------------------------------------------------------------------
# Create the sanicode system user if it does not already exist
# ---------------------------------------------------------------------------
if ! id sanicode &>/dev/null; then
    echo "==> Creating system user: sanicode"
    useradd --system --no-create-home --shell /sbin/nologin sanicode
fi

# ---------------------------------------------------------------------------
# Create required directories
# ---------------------------------------------------------------------------
echo "==> Creating directories"
mkdir -p /etc/sanicode
mkdir -p /var/lib/sanicode/data
chown sanicode:sanicode /var/lib/sanicode/data
chmod 750 /var/lib/sanicode/data

# ---------------------------------------------------------------------------
# Load the container image from the tarball
# ---------------------------------------------------------------------------
echo "==> Loading container image from ${TARBALL}"
LOADED_IMAGE=$(podman load -i "${TARBALL}" | grep -oP 'Loaded image: \K.*' || true)
if [[ -z "${LOADED_IMAGE}" ]]; then
    echo "ERROR: podman load did not report a loaded image." >&2
    exit 1
fi
echo "    Loaded: ${LOADED_IMAGE}"

# The systemd service references localhost/wjackson/sanicode:latest.
# Retag the loaded image so Podman can find it by that name.
echo "==> Retagging as localhost/wjackson/sanicode:latest"
podman tag "${LOADED_IMAGE}" localhost/wjackson/sanicode:latest

# ---------------------------------------------------------------------------
# Write a default sanicode.toml if one does not already exist
# ---------------------------------------------------------------------------
if [[ ! -f /etc/sanicode/sanicode.toml ]]; then
    echo "==> Writing default /etc/sanicode/sanicode.toml"
    cat > /etc/sanicode/sanicode.toml <<'EOF'
# sanicode.toml — standalone RHEL deployment
#
# Sanicode operates in degraded mode (AST-only, no LLM) when [llm] is absent
# or disabled.  This still produces useful SARIF output with CWE, ASVS, and
# STIG mappings.

[scan]
graph_path_depth = 5
exclude_patterns = [
    "**/.venv/**",
    "**/node_modules/**",
    "**/dist/**",
    "**/build/**",
    "**/__pycache__/**",
    "**/migrations/**",
    "**/*.min.js",
]
include_extensions = [".py"]
max_file_size_kb = 512

[output]
formats = ["markdown", "sarif"]
output_dir = "/data/sanicode-reports"

[compliance]
profiles = ["owasp-asvs", "nist-800-53", "asd-stig"]

# Uncomment and configure the [llm.*] sections if a local LLM is available,
# for example via vLLM running on the same host or a nearby node.
#
# [llm.fast]
# provider = "openai_compatible"
# endpoint = "http://localhost:8080/v1"
# model = "granite-nano"
# timeout_seconds = 15
#
# [llm.analysis]
# provider = "openai_compatible"
# endpoint = "http://localhost:8080/v1"
# model = "granite-code-8b"
# timeout_seconds = 30
#
# [llm.reasoning]
# provider = "openai_compatible"
# endpoint = "http://localhost:8080/v1"
# model = "granite-code-8b"
# timeout_seconds = 60
EOF
    chmod 640 /etc/sanicode/sanicode.toml
    chown root:sanicode /etc/sanicode/sanicode.toml
else
    echo "    /etc/sanicode/sanicode.toml already exists, skipping."
fi

# ---------------------------------------------------------------------------
# Install and enable the systemd service
# ---------------------------------------------------------------------------
echo "==> Installing systemd service"
cp "${SERVICE_SRC}" /etc/systemd/system/sanicode.service
systemctl daemon-reload
systemctl enable --now sanicode

# ---------------------------------------------------------------------------
# Verify the service started
# ---------------------------------------------------------------------------
echo "==> Waiting for sanicode to become ready..."
for i in {1..12}; do
    if curl -sf http://localhost:8080/api/v1/health &>/dev/null; then
        echo "==> sanicode is healthy."
        break
    fi
    if [[ ${i} -eq 12 ]]; then
        echo "WARNING: health check did not succeed after 60 s." >&2
        echo "         Check logs: journalctl -u sanicode -n 50" >&2
    fi
    sleep 5
done

echo
echo "==> Setup complete."
echo
echo "Service status:  systemctl status sanicode"
echo "Logs:            journalctl -u sanicode -f"
echo "Health check:    curl http://localhost:8080/api/v1/health"
echo "Config:          /etc/sanicode/sanicode.toml"
echo "Data directory:  /var/lib/sanicode/data/"
