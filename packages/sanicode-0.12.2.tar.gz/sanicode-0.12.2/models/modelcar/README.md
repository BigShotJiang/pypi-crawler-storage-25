# ModelCar OCI Images

A ModelCar is an OCI image that contains only model weights — no runtime, no Python, no entrypoint. The image is used as an init container that copies weights into a shared volume, then exits. The serving container (vLLM) reads from that volume.

This separates the model supply chain from the runtime supply chain: you version, sign, and mirror model weights independently from the inference server image.

## Building a ModelCar

On an internet-connected machine:

```bash
# Download weights (requires huggingface-hub)
pip install huggingface-hub
huggingface-cli download ibm-granite/granite-8b-code-instruct-128k \
    --local-dir ./granite-8b

# Build the OCI image
podman build -f Containerfile.modelcar \
    -t quay.io/YOUR_ORG/granite-8b-modelcar:v1 .

# Push to your registry
podman push quay.io/YOUR_ORG/granite-8b-modelcar:v1
```

## Using a ModelCar in a Deployment

Add an init container that copies the weights to a shared emptyDir volume:

```yaml
initContainers:
  - name: model-weights
    image: quay.io/YOUR_ORG/granite-8b-modelcar:v1
    command: ["cp", "-r", "/models/.", "/model-cache/"]
    volumeMounts:
      - name: model-cache
        mountPath: /model-cache
containers:
  - name: vllm
    image: vllm/vllm-openai:v0.11.2
    volumeMounts:
      - name: model-cache
        mountPath: /root/.cache/huggingface
volumes:
  - name: model-cache
    emptyDir: {}
```

This pattern replaces the PVC-based staging approach. Use whichever fits your storage infrastructure — PVC staging is covered in `docs/granite-deployment.md`.

## Mirroring to a Disconnected Registry

```bash
# On a connected machine: save to tar
podman save quay.io/YOUR_ORG/granite-8b-modelcar:v1 \
    -o granite-8b-modelcar-v1.tar

# Transfer the tar to the disconnected network, then:
podman load -i granite-8b-modelcar-v1.tar
podman tag quay.io/YOUR_ORG/granite-8b-modelcar:v1 \
    internal-registry.example.com/models/granite-8b-modelcar:v1
podman push internal-registry.example.com/models/granite-8b-modelcar:v1
```

For large models (70B+), consider `skopeo copy` with `--dest-compress-format=zstd` to reduce transfer size by ~30%.

## Trade-offs vs. PVC Staging

| Approach | Versioning | Air-gap | Startup time | Storage reuse |
|----------|-----------|---------|--------------|---------------|
| ModelCar (OCI) | OCI tags + signatures | Mirror like any image | Copy on each pod start | No — each pod copies |
| PVC staging | Manual / rsync | rsync or Job | Zero copy if PVC is pre-populated | Yes — PVC shared across pods |

For single-replica deployments the startup overhead is usually acceptable. For multi-replica deployments, prefer a pre-populated PVC to avoid copying multi-gigabyte weights per pod.
