# FIPS 140-2/140-3 Compliance

Sanicode is designed to run in FIPS-enabled environments.  Compliance is
inherited from the host operating system or OpenShift cluster — no special
sanicode build is required.

## What FIPS Means for Sanicode

FIPS mode restricts cryptographic operations to algorithms validated by NIST:
SHA-2 family (SHA-256, SHA-384, SHA-512), AES, and RSA/ECDSA.  Weak algorithms
such as MD5, SHA-1 (for security use), and RC4 are blocked by the kernel.

Sanicode's crypto surface is minimal:
- `hashlib.sha256()` in baseline diffing — FIPS-approved, no change needed.
- UUID generation via `os.urandom` — FIPS-compliant.
- TLS connections to KFP/DSPA endpoints — must use verified certificates.

## OpenShift Cluster-Level FIPS Requirements

Enable FIPS at install time in the OpenShift `install-config.yaml`:

```yaml
fips: true
```

FIPS cannot be enabled post-install on RHEL CoreOS nodes.  When the cluster
has FIPS enabled, every pod automatically inherits FIPS mode through the kernel
flag at `/proc/sys/crypto/fips_enabled`.

## How Sanicode Inherits FIPS

When sanicode runs inside a UBI 9 container on a FIPS-enabled node:

1. The kernel sets `/proc/sys/crypto/fips_enabled` to `1`.
2. OpenSSL loads the FIPS provider and blocks non-FIPS algorithms.
3. Python's `hashlib` and `ssl` modules use the FIPS-restricted OpenSSL.

No sanicode configuration is required for this to take effect.

## Validating Your Deployment

Run `sanicode fips-check` to verify the current environment:

```
$ sanicode fips-check
FIPS Mode: enabled
OpenSSL: OpenSSL 3.0.9 (FIPS provider active)

Checks:
  ✓ hashlib uses FIPS-validated OpenSSL backend
  ✓ No weak hash algorithms available for security use
  ✓ TLS certificate verification enabled

All FIPS compliance checks passed.
```

Exit code is 0 on success, 1 if any issues are found.

## Configuring Custom CA Bundles (KFP/DSPA)

Internal OpenShift routes typically use cluster-internal CAs.  Configure the
CA bundle in `sanicode.toml`:

```toml
[pipeline]
dspa_endpoint = "https://ds-pipeline-dspa.example.svc:8443"
ca_bundle = "/etc/pki/tls/certs/ca-bundle.crt"  # default RHEL system bundle
# ca_bundle = "/path/to/custom-ca.crt"           # override for internal CAs
```

If the configured path does not exist, sanicode logs a warning and falls back
to the RHEL system bundle, then to the certifi bundle.  TLS verification is
never silently disabled.

## STIG Mapping

| STIG ID     | Title                                              | CAT  | Coverage                                      |
|-------------|----------------------------------------------------|------|-----------------------------------------------|
| V-222570    | Use FIPS-validated cryptographic modules           | I    | UBI 9 base image; kernel FIPS mode required   |
| V-222571    | Use approved hash algorithms                       | II   | `hashlib.sha256()` only; MD5 blocked          |
| V-222572    | Protect data in transit with FIPS-approved TLS     | II   | `pipeline.ca_bundle` enforces verified TLS    |
