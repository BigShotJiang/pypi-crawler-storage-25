# Air-Gapped Deployment Architecture

Sanicode is **offline-native**, not merely offline-compatible. Zero egress at
runtime is an architectural requirement, not a configuration option.

## Design Principles

**Offline-native means no runtime internet access by design.** All compliance
data (OWASP ASVS 5.0, NIST 800-53, ASD STIG v4r11, CWE cross-references),
rule definitions, and prompt templates ship inside the Python package and
container image. Nothing is fetched from the internet during a scan.

**Model weights are a separate supply-chain artifact.** They are never bundled
into the sanicode image. Weights are delivered via a PVC (see `pvc-models.yaml`)
or a ModelCar OCI image, then mounted at `/models` by the Deployment. The LLM
client only ever speaks to a configured in-cluster endpoint.

**Degraded mode is first-class.** With no LLM endpoint configured, sanicode
still produces SARIF-compliant output from AST pattern matching and data flow
graph analysis. LLM tiers add context-awareness on top; they do not gate core
functionality.

## Component Diagram

```
┌─────────────────────────────────────────────────────────┐
│  sanicode namespace                                      │
│                                                          │
│  ┌──────────────┐        ┌──────────────────────────┐   │
│  │ sanicode pod │──LLM──▶│  KServe / vLLM Service   │   │
│  │              │  HTTP  │  (models namespace)       │   │
│  │  AST scanner │        └──────────┬───────────────┘   │
│  │  graph build │                   │                    │
│  │  compliance  │        ┌──────────▼───────────────┐   │
│  │  SARIF out   │        │  PVC / ModelCar OCI      │   │
│  └──────┬───────┘        │  (weights on disk)       │   │
│         │                └──────────────────────────┘   │
│         │ /metrics                                       │
└─────────┼───────────────────────────────────────────────┘
          │
          ▼  (ingress from monitoring namespace only)
    Prometheus scrape
```

Network boundaries enforced by NetworkPolicy:
- **Egress**: DNS (kube-system:53), model serving namespace (8080/8443),
  OpenShift API server (6443). Everything else is denied.
- **Ingress**: OpenShift router (8080/8443), monitoring namespace (8080).

## Resource Requirements

| Component | CPU | RAM | Disk | GPU |
|-----------|-----|-----|------|-----|
| sanicode (scan only) | 2 cores | 4 GiB | 1 GiB | none |
| sanicode (with LLM) | 2 cores | 4 GiB | 1 GiB | none |
| Granite Nano (fast tier) | 2 cores | 4 GiB | 2 GiB | none (CPU) |
| Granite Code 8B (analysis) | 4 cores | 24 GiB | 20 GiB | 1× A10/T4 (16 GiB) |
| Llama 3.1 70B (reasoning) | 8 cores | 64 GiB | 150 GiB | 2× A100 (80 GiB) |

## Dependency Bundling

All Python dependencies are installed into the container image at build time.
`pip install` is never run at container startup. The multi-stage Containerfile
installs dependencies in a builder layer; only the virtualenv is copied into
the final UBI9 image. If a dependency introduces a transitive network call
(e.g., certificate updates, telemetry), it will be blocked by the egress
NetworkPolicy and will fail loudly rather than silently.

## Known External Call: OSV Vulnerability Database

`src/sanicode/dependencies/osv_client.py` calls `https://api.osv.dev` to look
up dependency vulnerabilities. This is the only intentional runtime egress in
the codebase.

**Air-gapped mode disables this automatically** via the existing config knob:

```toml
# sanicode.toml
[dependencies]
osv_enabled = false
```

Or at CLI invocation:

```bash
sanicode scan --offline /path/to/project
```

The `--offline` flag sets `cfg.dependencies.osv_enabled = False` before
execution. With OSV disabled, the dependency scan reports lockfile inventory
without vulnerability cross-referencing. No other external call is made.

## Enabling NetworkPolicy

The Helm chart ships network policies gated behind `networkPolicy.enabled`
(default: `false`). Enable them for production air-gapped deployments:

```yaml
# values-airgap.yaml
networkPolicy:
  enabled: true
  modelNamespace: "granite-code"   # namespace where KServe InferenceService runs
```

Standalone manifests are also available in `deploy/networkpolicy/` for
environments not managed by Helm.

## Verification: Confirming Zero Egress

After deployment with NetworkPolicy enforced, verify no traffic escapes:

```bash
# Open a debug shell on the running pod
oc debug -n <namespace> deployment/sanicode -- /bin/bash

# Inside the pod: confirm DNS resolves in-cluster but external hosts fail
curl -m 5 https://api.osv.dev/v1/query      # must time out / be refused
curl -m 5 http://llm-service.models.svc:8080/health  # must succeed

# Packet-level confirmation via tcpdump on the node (requires node-debug pod)
oc debug node/<node-name> -- chroot /host \
  tcpdump -i any -n 'host 8.8.8.8 or host api.osv.dev' -c 10
```

A clean air-gapped pod will produce zero packets to external addresses.
