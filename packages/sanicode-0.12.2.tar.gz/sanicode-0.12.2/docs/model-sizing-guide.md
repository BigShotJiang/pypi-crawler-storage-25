# Model Sizing Guide

This guide covers resource requirements and configuration for the three model tiers used by Sanicode. See `docs/granite-deployment.md` for the Granite Code 8B deployment walkthrough and air-gapped staging instructions.

## Recommended Models (Model Rodeo Results)

Benchmark testing across 13 models on 70 security analysis samples (March 2026):

| Preset | Model | Strategy | F1 | FP Filter | Requirements |
|---|---|---|---|---|---|
| cloud-haiku | Claude Haiku 4.5 | augment | 1.000 | 100% | API key |
| local-large | gpt-oss:20b | augment | 0.970 | 97% | 13 GB RAM |
| local-medium | granite3.3:8b | augment | 0.930 | 86% | 5 GB RAM |
| local-small | mistral-nemo | review | 0.896 | 89% | 7 GB RAM |

Key findings:
- CPG context is the primary differentiator — more impactful than model size or code specialization
- Code-specific models did not consistently outperform general-purpose models
- Strong models (Haiku, gpt-oss, granite3.3) perform best with `augment` (independent reasoning with CPG context)
- Mid-tier models (mistral-nemo, deepseek) perform best with `review` (deterministic findings as scaffolding)
- Models below ~7B parameters are not recommended — accuracy drops significantly
- The graph edge fix in the CPG significantly improved `review` strategy performance
- Full benchmark data available at `benchmarks/rodeo-results/scorecard.html`

The table above supersedes the per-tier recommendations below for projects using the new augment/review pipeline. The hardware requirements tables remain relevant for capacity planning.

## Pass 3 Tiebreaker Cost Overhead

When Pass 1 (deterministic) and Pass 2 (augment/review) disagree on a finding, a Pass 3 tiebreaker call presents both positions to the same pipeline model for an independent verdict. Based on benchmark data, disagreements occur on ~5-15% of findings, making the tiebreaker's total inference cost overhead roughly 10% on top of the Pass 2 cost. The tiebreaker prompt is shorter than the augment/review prompt (512 max tokens vs 1024), so per-call cost is also lower.

## Recommended Models by Tier

| Model | Tier | Parameters | Format | Disk | CPU RAM | GPU VRAM | Approx. speed |
|-------|------|------------|--------|------|---------|----------|---------------|
| Granite Nano (1B) | Fast / classification | 1B | safetensors | 2 GiB | 4 GiB | None — CPU OK | ~50 tok/s (CPU) |
| Granite Code 8B | Code analysis | 8B | safetensors | 20 GiB | 24 GiB | 16 GiB (A10/T4) | ~40 tok/s (GPU) |
| Llama 3.1 8B Instruct | General analysis | 8B | safetensors | 20 GiB | 24 GiB | 16 GiB (A10/T4) | ~40 tok/s (GPU) |
| Llama 3.1 70B Instruct | Deep reasoning | 70B | safetensors | 150 GiB | 64 GiB | 2× 80 GiB (A100) | ~15 tok/s (GPU) |

Speeds are illustrative; actual throughput depends on batch size, sequence length, and hardware generation.

## GGUF Format (CPU-Only Deployments)

GGUF quantized weights (Q4_K_M, Q5_K_M, Q8_0) can run the 8B models on CPU at reduced throughput (~5–15 tok/s). Use `llama.cpp` or `ollama` as the serving backend instead of vLLM. Sanicode's LiteLLM integration supports both via the `openai`-compatible endpoint.

Rough disk/RAM for Q4_K_M quantization:
- 8B model → ~5 GiB disk, ~6 GiB RAM
- 70B model → ~42 GiB disk, ~44 GiB RAM

CPU mode is acceptable for the fast tier (short prompts, classification); avoid it for the analysis and reasoning tiers where latency compounds across many findings.

## vLLM Configuration Tips

**Tensor parallelism** splits the model across multiple GPUs. Set `--tensor-parallel-size` to match the GPU count:

```bash
# Two A100s for 70B
--tensor-parallel-size=2
```

**Context length** trades GPU memory for throughput. Reduce `--max-model-len` if the pod is OOMKilled:

```bash
# Sanicode rarely needs more than 8k for code analysis
--max-model-len=8192
```

**KV cache memory fraction** controls how much GPU memory vLLM reserves for the KV cache (default 0.9). Lower it if you share a GPU with other workloads:

```bash
--gpu-memory-utilization=0.85
```

## OpenShift AI InferenceService Examples

See `models/inferenceservice-examples/` for ready-to-apply KServe manifests for each tier.

Quick reference for `sanicode.toml` after deploying:

```toml
[llm.fast]
endpoint = "http://granite-nano.llm-serving.svc.cluster.local:8080/v1"
model = "granite-nano"

[llm.analysis]
endpoint = "http://granite-code-8b.granite-code.svc.cluster.local:8080/v1"
model = "granite-code-8b"

[llm.reasoning]
endpoint = "http://llama-31-70b.llm-serving.svc.cluster.local:8080/v1"
model = "llama-3.1-70b-instruct"
```

## Updating Models in Disconnected Environments

1. On a connected machine, download the new weights:
   ```bash
   huggingface-cli download ibm-granite/granite-8b-code-instruct-128k \
       --local-dir ./granite-8b-new
   ```

2. If using a ModelCar: rebuild and push the OCI image, then mirror it to your internal registry. See `models/modelcar/README.md`.

3. If using a PVC: stage the new weights into the PVC using `oc rsync` as described in `docs/granite-deployment.md`, then restart the serving deployment:
   ```bash
   oc rollout restart deployment/granite-code-8b -n granite-code
   ```

4. Validate the new model is serving:
   ```bash
   bash scripts/validate-granite.sh
   ```
