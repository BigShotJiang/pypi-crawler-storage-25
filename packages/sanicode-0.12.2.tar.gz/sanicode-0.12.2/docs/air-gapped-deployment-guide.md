# Air-Gapped Deployment Guide

Sanicode is a security scanner that builds a codebase knowledge graph and maps
findings to OWASP ASVS 5.0, NIST 800-53, and ASD STIG controls. This guide
covers deploying it in environments with zero outbound internet access.

## 1. Overview

"Air-gapped" in this context means **zero runtime egress**: no DNS lookups to
external hosts, no telemetry, no model downloads at startup. Sanicode is
offline-native — compliance data, rule definitions, and prompt templates all
ship inside the package and container image. This makes it suitable for SCIF
environments and IL4/IL5 accredited clusters.

Three deployment paths are covered here:

| Path | Best for |
|------|----------|
| OpenShift (sections 4–4e) | Production; enforced NetworkPolicy; GPU model serving |
| Standalone RHEL (section 5) | Single-host; systemd-managed; no cluster required |
| Podman Desktop (section 6) | Developer workstations; local LLM optional |

## 2. Prerequisites and Resource Requirements

**OpenShift path:**
- OpenShift 4.14+ (IDMS support; earlier clusters use ICSP — see section 4a)
- cluster-admin privileges for mirroring and MachineConfig changes
- A private container registry reachable from all cluster nodes (e.g., Quay
  Enterprise, Harbor, or OpenShift's built-in registry)
- `skopeo` installed on the connected staging machine
- GPU worker nodes if running Granite Code 8B or Llama 3.1 70B

**Standalone RHEL path:**
- RHEL 9.x with Podman installed
- Root access on the target host
- The sanicode image `.tar` archive transferred via approved media

**Resource summary** (sanicode API server only):

| Component | CPU | RAM | Disk |
|-----------|-----|-----|------|
| sanicode | 2 cores | 4 GiB | 1 GiB |

For LLM model resource requirements — including GPU VRAM, tensor parallelism
settings, and GGUF CPU-only options — see `docs/model-sizing-guide.md`. Model
weights are **never bundled** in the sanicode image; they are a separate
supply-chain artifact delivered via PVC or ModelCar OCI image.

## 3. Preparing on a Connected Machine

All staging work happens on an internet-connected machine before transfer to
the air-gapped network.

### Pull and save the sanicode image

```bash
podman pull quay.io/wjackson/sanicode:0.9.0
podman save quay.io/wjackson/sanicode:0.9.0 -o sanicode-0.9.0.tar
```

### Pull and save supporting images

```bash
# UBI9 base (required by setup script on standalone RHEL)
podman pull registry.redhat.io/ubi9/ubi-minimal:latest
podman save registry.redhat.io/ubi9/ubi-minimal:latest -o ubi9-minimal.tar

# vLLM serving image (OpenShift path only, if not using KServe)
podman pull vllm/vllm-openai:v0.11.2
podman save vllm/vllm-openai:v0.11.2 -o vllm-v0.11.2.tar
```

### Download model weights

Download to a local directory on the connected machine:

```bash
pip install huggingface-hub
huggingface-cli download ibm-granite/granite-8b-code-instruct-128k \
    --local-dir ./granite-8b
```

See `docs/granite-deployment.md` for the full download and PVC-staging
walkthrough. See `docs/model-sizing-guide.md` for model selection guidance,
including CPU-only GGUF options if GPU nodes are unavailable.

### Build a ModelCar OCI image (optional, recommended for OpenShift)

A ModelCar packages model weights as an OCI image, versioned and signed
independently from the inference server. See `models/modelcar/README.md` for
build instructions. The resulting tar can be mirrored like any container image.

### Create an offline pip bundle (standalone RHEL without Podman)

If the target RHEL host cannot use containers at all:

```bash
bash scripts/bundle-offline-pip.sh
```

This produces a `sanicode-offline-bundle/` directory with all wheels. Transfer
it and install with `pip install --no-index --find-links=./sanicode-offline-bundle sanicode`.

## 4. OpenShift Deployment (Primary Path)

### 4a. Mirror images to disconnected registry

Use the mirror script on the connected machine, targeting your internal registry:

```bash
./scripts/mirror-images.sh registry.internal.example.com:5000 0.9.0
```

Or mirror individual images with skopeo:

```bash
skopeo copy \
    docker://quay.io/wjackson/sanicode:0.9.0 \
    docker://registry.internal.example.com:5000/wjackson/sanicode:0.9.0
```

Then apply the image mirror policy on the cluster. For OpenShift 4.14+, use
the ImageDigestMirrorSet:

```bash
# Replace the placeholder with your registry hostname
sed -i 's|<your-registry>|registry.internal.example.com:5000|g' \
    deploy/disconnected/imagedigestmirrorset.yaml
oc apply -f deploy/disconnected/imagedigestmirrorset.yaml
```

For OpenShift 4.13 and earlier, use the ImageContentSourcePolicy instead:

```bash
sed -i 's|<your-registry>|registry.internal.example.com:5000|g' \
    deploy/disconnected/imagecontentsourcepolicy.yaml
oc apply -f deploy/disconnected/imagecontentsourcepolicy.yaml
```

See `deploy/disconnected/README.md` for the full procedure.

**Wait for MachineConfigPool rollout** before proceeding. The mirror policy
triggers a rolling node restart (5–15 minutes on a 3-node cluster):

```bash
oc get mcp -w   # wait until UPDATED=true, DEGRADED=false for all pools
```

### 4b. Deploy model serving

Skip this section if running sanicode in degraded mode (AST-only, no LLM).
Degraded mode still produces complete SARIF output with compliance mappings.

**Option A: PVC with pre-staged weights**

Create the PVC and stage weights into it using `oc rsync`. Full instructions
are in `docs/granite-deployment.md` (Air-Gapped Deployment section).

**Option B: ModelCar OCI image (recommended)**

Mirror the ModelCar image to your internal registry (see `models/modelcar/README.md`),
then reference it as an init container in the serving deployment. The init
container copies weights to a shared `emptyDir` volume at pod startup.

**Apply the InferenceService**

Ready-to-use KServe manifests for each model tier are in
`models/inferenceservice-examples/`. Apply the one matching your hardware:

```bash
# GPU node with Granite Code 8B
oc apply -f models/inferenceservice-examples/granite-code-8b-gpu.yaml -n granite-code

# Multi-GPU for Llama 3.1 70B
oc apply -f models/inferenceservice-examples/llama-31-70b-multi-gpu.yaml -n llm-serving
```

Validate the endpoint once the InferenceService is ready:

```bash
bash scripts/validate-granite.sh
```

### 4c. Deploy sanicode

Create the namespace and install from the Helm chart:

```bash
oc new-project sanicode

helm install sanicode charts/sanicode/ -n sanicode \
    --set image.repository=registry.internal.example.com:5000/wjackson/sanicode \
    --set imagePullSecrets[0].name=internal-registry-pull-secret \
    --set networkPolicy.enabled=true \
    --set networkPolicy.modelNamespace=granite-code
```

If deploying without a local LLM (degraded mode), omit the `modelNamespace`
override. The scanner produces AST-only output and skips LLM tiers.

To configure LLM endpoints, pass a custom `sanicode.toml` via the `config`
value. See `charts/sanicode/values.yaml` for the full annotated template.

**Verify the deployment:**

```bash
oc rollout status deployment/sanicode -n sanicode
curl -s http://$(oc get route sanicode -n sanicode -o jsonpath='{.spec.host}')/api/v1/health
```

### 4d. Apply NetworkPolicy

NetworkPolicy is enabled via the `networkPolicy.enabled=true` Helm value shown
above. It restricts egress to DNS (kube-system:53), the model-serving namespace
(8080/8443), and the OpenShift API server (6443). All other outbound traffic is
denied.

To apply the standalone manifests instead of Helm-managed policies:

```bash
oc apply -f deploy/networkpolicy/deny-egress.yaml -n sanicode
oc apply -f deploy/networkpolicy/allow-ingress.yaml -n sanicode
```

See `deploy/networkpolicy/` for the full manifest set.

### 4e. Verify zero egress

Open a debug shell and confirm that external hosts are unreachable:

```bash
oc debug -n sanicode deployment/sanicode -- /bin/bash

# Inside the pod:
curl -m 5 https://api.osv.dev/v1/query         # must time out
curl -m 5 http://llm-service.granite-code.svc:8080/health  # must succeed
```

For packet-level verification on the node:

```bash
oc debug node/<node-name> -- chroot /host \
    tcpdump -i any -n 'host 8.8.8.8 or host api.osv.dev' -c 10
```

A clean air-gapped pod produces zero packets to external addresses.

## 5. Standalone RHEL Deployment

Transfer the image tarball to the disconnected host (scp, rsync, USB, or
your organization's approved transfer method), then run:

```bash
sudo ./scripts/setup-rhel-standalone.sh /path/to/sanicode-0.9.0.tar
```

The setup script creates a `sanicode` system user, initializes config and
data directories, loads the image, and installs a systemd service. See
`deploy/standalone/README.md` for the full step-by-step and configuration
reference.

**Verify the service:**

```bash
systemctl status sanicode
curl http://localhost:8080/api/v1/health
```

**Configure a local LLM (optional):**

If vLLM or ollama is running on the same host, edit
`/etc/sanicode/sanicode.toml` and uncomment the `[llm.*]` sections, pointing
endpoints at `http://localhost:<port>/v1`. Restart after editing:

```bash
systemctl restart sanicode
```

The default configuration runs in degraded mode (AST-only), which still
produces full SARIF output with CWE, ASVS 5.0, NIST 800-53, and ASD STIG
v4r11 mappings.

## 6. Podman Desktop Deployment (Dev/Test)

For local testing on a developer workstation with an internet connection for
the initial pull:

```bash
podman run -d \
    --name sanicode \
    -p 8080:8080 \
    -v $(pwd)/sanicode.toml:/etc/sanicode/sanicode.toml:ro \
    quay.io/wjackson/sanicode:0.9.0
```

Scan a local codebase by mounting it into the container:

```bash
podman run --rm \
    -v /path/to/project:/scan:ro \
    quay.io/wjackson/sanicode:0.9.0 \
    sanicode scan --offline /scan
```

The `--offline` flag disables the OSV dependency lookup, which is the only
intentional runtime egress in the codebase.

If a local LLM is running (e.g., ollama on the host), pass its endpoint:

```bash
podman run --rm \
    -v /path/to/project:/scan:ro \
    -e SANICODE_LLM_FAST_ENDPOINT=http://host.containers.internal:11434/v1 \
    quay.io/wjackson/sanicode:0.9.0 \
    sanicode scan /scan
```

## 7. FIPS Mode Configuration

Sanicode inherits FIPS compliance from the host kernel — no special sanicode
build is required.

**OpenShift:** Enable FIPS at cluster install time in `install-config.yaml`
(`fips: true`). FIPS cannot be enabled post-install on RHCOS nodes. Once
enabled, all pods automatically inherit FIPS mode.

**Standalone RHEL:** Enable FIPS at OS install time or with
`fips-mode-setup --enable` followed by a reboot.

After deployment, validate:

```bash
sanicode fips-check
```

Expected output shows FIPS mode enabled, OpenSSL FIPS provider active, and
all internal checks passing. See `docs/fips-compliance.md` for the full
validation procedure and STIG mapping (V-222570 through V-222572).

## 8. Integration with Centralized Logging

**Standalone RHEL:** Logs go to the journal:

```bash
journalctl -u sanicode -f
```

Sanicode emits structured JSON audit events to the journal. Forward to
centralized logging (Splunk, Elasticsearch) using the standard journald
forwarding mechanisms for your organization.

**OpenShift:** Pod logs flow to the cluster logging stack (EFK/Loki) automatically.
No sanicode-specific configuration is required. Audit events are emitted to
stdout in structured JSON format alongside application logs.

## 9. Updating in Disconnected Environments

**Sanicode image updates:**

1. On a connected machine, pull and save the new image:
   ```bash
   podman pull quay.io/wjackson/sanicode:<new-version>
   podman save quay.io/wjackson/sanicode:<new-version> -o sanicode-<new-version>.tar
   ```
2. Mirror to your internal registry, then run a rolling update:
   ```bash
   helm upgrade sanicode charts/sanicode/ -n sanicode \
       --set image.tag=<new-version> \
       --reuse-values
   ```

Rule definitions are bundled inside the image and update automatically with
each release. No separate rule update step is needed.

**Model weight updates:**

- **PVC approach:** Download new weights on a connected machine, stage into
  the PVC via `oc rsync`, then restart the serving deployment. See
  `docs/model-sizing-guide.md` for the full procedure.
- **ModelCar approach:** Build a new ModelCar image with the updated weights,
  mirror it to the internal registry, update the init container image reference,
  then restart the deployment.

Validate after any model update:

```bash
bash scripts/validate-granite.sh
```

## 10. Troubleshooting

| Symptom | Likely cause | Fix |
|---------|-------------|-----|
| Pod `CrashLoopBackOff` | Missing `sanicode.toml` ConfigMap | Check Helm `config` value; verify ConfigMap exists: `oc get cm sanicode-config -n sanicode` |
| LLM requests time out | NetworkPolicy blocking model namespace egress | Verify `networkPolicy.modelNamespace` matches the namespace running the InferenceService |
| No LLM findings in report | Scanner running in degraded mode | Check pod logs for `degraded mode` message; verify `[llm.*]` endpoints are reachable from the pod |
| GPU OOM (pod `OOMKilled`) | Insufficient VRAM for model | Reduce `--max-model-len` to 4096; see `docs/model-sizing-guide.md` |
| Image pull error | Mirror not configured or MCP rollout incomplete | Apply IDMS/ICSP, then wait for `oc get mcp -w` to show all pools updated |
| Tokenizer not found (air-gapped) | Incomplete weight transfer | Ensure `tokenizer.json`, `tokenizer_config.json`, and `special_tokens_map.json` are present in the model directory |
| `fips-check` reports failure | Host kernel FIPS not enabled | Enable FIPS at install time (cannot be added post-install on RHCOS) |
| OSV lookup errors in logs | `--offline` flag not set | Add `osv_enabled = false` to `[dependencies]` in `sanicode.toml`, or pass `--offline` on the CLI |

For issues not covered here, check the pod events and recent logs:

```bash
oc describe pod -l app=sanicode -n sanicode
oc logs -l app=sanicode -n sanicode --tail=100
```
