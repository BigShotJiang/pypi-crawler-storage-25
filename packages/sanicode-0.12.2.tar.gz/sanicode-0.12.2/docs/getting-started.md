# Getting Started with Sanicode

This guide walks you through a complete scan of a sample vulnerable application. By the end you'll understand how to read findings, integrate SARIF output into CI/CD, and gate builds on severity thresholds.

## 1. Install

```
pip install sanicode
```

Requires Python 3.10+. No LLM configuration is required for the initial scan — sanicode runs in degraded mode using AST pattern matching and taint analysis.

## 2. Scan the sample app

The sample application in `examples/sample-app/app.py` contains intentional vulnerabilities across five CWE classes:

```
sanicode scan examples/sample-app/app.py
```

Expected output (abridged):

```
Sanicode — scan complete
  Files scanned : 1
  Findings      : 7
  Critical      : 0
  High          : 5  (SQL injection x2, command injection x2, code injection x1)
  Medium        : 2  (XSS x1, path traversal x1)

Reports written to sanicode-reports/
```

## 3. Understanding the findings

### SQL Injection — CWE-89 (STIG APSC-DV-002540, CAT I / ASVS v5.0.0-5.3.4)

`search_users` and `get_user_by_id` both interpolate user-controlled values into SQL strings via string concatenation and `%`-formatting. An attacker can escape the query and execute arbitrary SQL.

**Fix:** use parameterized queries — `cursor.execute("... WHERE id = ?", (user_id,))`. See `app_fixed.py` for the exact replacement.

### OS Command Injection — CWE-78 (STIG APSC-DV-002510, CAT I / ASVS v5.0.0-5.3.8)

`ping_host` passes user input into a shell string with `shell=True`. `run_report` concatenates input directly into `os.system()`. Either allows an attacker to append `; rm -rf /` or similar.

**Fix:** pass an argument list to `subprocess.run` and set `shell=False` (the default). Replace `os.system` with `subprocess.run(["generate-report", report_name])`.

### Code Injection — CWE-94 (STIG APSC-DV-002560, CAT I / ASVS v5.0.0-5.3.9)

`evaluate_expression` calls `eval()` on a user-supplied string. `eval()` executes arbitrary Python — including imports, file writes, and network calls.

**Fix:** `ast.literal_eval()` evaluates only Python literals (strings, numbers, lists, dicts). If you need a real expression evaluator, use a dedicated math-parsing library.

### Cross-Site Scripting — CWE-79 (STIG APSC-DV-002520, CAT II / ASVS v5.0.0-5.2.8)

`render_greeting` interpolates `name` directly into an HTML template. A value like `<script>alert(1)</script>` renders as executable JavaScript.

**Fix:** `from html import escape; f"<h1>Hello, {escape(name)}!</h1>"`.

### Path Traversal — CWE-22 (STIG APSC-DV-002560, CAT II / ASVS v5.0.0-5.3.11)

`read_upload` opens `/var/uploads/{filename}` without checking that `filename` stays within `/var/uploads`. A value of `../../etc/passwd` reads an arbitrary file.

**Fix:** resolve the path and assert it is relative to the upload root before opening:

```python
target = (UPLOAD_DIR / filename).resolve()
if not target.is_relative_to(UPLOAD_DIR):
    raise ValueError("access denied")
```

## 4. Verify the fixed version

```
sanicode scan examples/sample-app/app_fixed.py
```

This should report zero high/critical findings, confirming the remediations are effective.

## 5. SARIF output for CI/CD

SARIF is the interchange format used by GitHub Code Scanning, VS Code, Azure DevOps, and Tekton gating:

```
sanicode scan examples/sample-app/ --format sarif
```

The SARIF file is written to `sanicode-reports/report.sarif`. Each finding includes the rule ID, CWE, ASVS reference, and a code region pointing to the exact line.

## 6. Gating builds on severity

Exit non-zero when any high or critical finding exists:

```
sanicode scan examples/sample-app/ --fail-on high
```

Exit codes:
- `0` — scan completed, no findings at or above the threshold
- `1` — findings found at or above the threshold (use in CI to block the build)
- `2` — scan error (configuration problem, parse failure, etc.)

## 7. GitHub Actions integration

```yaml
- uses: rdwj/sanicode@v0
  with:
    path: .
    fail-on: high
    format: sarif
    upload-sarif: "true"
```

The action installs sanicode, runs the scan, uploads the SARIF file to GitHub Code Scanning, and archives the full report directory as a build artifact. See [`action.yml`](../action.yml) for all available inputs.

## Next steps

- **Air-gapped deployment** — run with a local Granite or Llama model, no egress required: [`docs/air-gapped-deployment-guide.md`](air-gapped-deployment-guide.md)
- **Custom rules** — write YAML-based detection rules for your specific frameworks: [`examples/custom-rules-example.yaml`](../examples/custom-rules-example.yaml)
- **FIPS compliance** — deploy on a FIPS-enabled UBI9 host with a FIPS-validated model: [`docs/fips-compliance.md`](fips-compliance.md)
- **STIG checklist output** — generate a `.ckl` file for DISA STIG Viewer as part of an ATO package: `sanicode scan . --format stig-checklist`
