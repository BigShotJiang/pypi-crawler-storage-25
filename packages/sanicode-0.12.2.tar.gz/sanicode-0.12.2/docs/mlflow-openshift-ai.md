# MLflow Integration on OpenShift AI

Sanicode can log each scan as an MLflow experiment run, capturing metrics,
parameters, and report artifacts for trend analysis and audit trails.

## Purpose

Each `sanicode scan` invocation records:
- Finding counts by severity and STIG CAT level
- Compliance score and graph topology metrics
- Scan duration and file/dependency counts
- Report files (SARIF, Markdown, CKL) as run artifacts
- LLM classification decisions as `llm-decisions.json` (when a fast-tier LLM is configured)

This gives you a persistent history of your codebase's security posture across
commits, branches, and deployments.

## Prerequisites

- MLflow server accessible from your scan environment (OpenShift AI Data Science Project with MLflow, or a standalone MLflow instance)
- Sanicode installed with the MLflow extra: `pip install 'sanicode[mlflow]'`

## Configuration

### sanicode.toml

```toml
[integrations.mlflow]
enabled           = true
tracking_uri      = "https://mlflow.apps.cluster.example.com"
experiment_prefix = "sanicode"   # experiment = prefix/repo-name
log_artifacts     = true         # upload report files to the run
```

The `tracking_uri` can be omitted to use the local `~/.mlruns` directory
(useful for offline or development environments).

### Environment variables

Environment variables take precedence over the TOML values:

| Variable                        | Effect                                         |
|---------------------------------|------------------------------------------------|
| `SANICODE_MLFLOW_ENABLED`       | `true`/`1` enables, `false`/`0` disables       |
| `SANICODE_MLFLOW_TRACKING_URI`  | Overrides `integrations.mlflow.tracking_uri`   |

These are useful in CI/CD pipelines or OpenShift workloads where injecting
secrets through environment variables is preferable to modifying config files.

## Viewing Results

Open the MLflow UI at your tracking URI. Experiments are named
`{experiment_prefix}/{repo-name}` (e.g. `sanicode/my-app`). Each run
corresponds to one `sanicode scan` invocation.

Key metrics to monitor across runs:
- `findings_total`, `cat_i_count`, `cat_ii_count` — finding trend over time
- `compliance_score` — overall posture score (0.0–1.0)
- `scan_duration_sec` — scan performance

The `llm-decisions.json` artifact contains one entry per finding classified by
the LLM, including the classification outcome and confidence score. This
supports audit workflows where you need to explain why a finding was suppressed.

## Grafana Dashboard

If you have a Grafana instance configured against your MLflow-backed metrics
store, the sanicode overview dashboard (`sanicode-overview`) includes panels
for MLflow trends. Set `grafana_url` in `sanicode.toml` under `[ui]` to enable
deep-link navigation from the CLI report output to the dashboard.

For Prometheus-based dashboards (the default for `sanicode serve`), MLflow
trends are complementary — MLflow captures per-scan history while Prometheus
tracks the live API server metrics.
