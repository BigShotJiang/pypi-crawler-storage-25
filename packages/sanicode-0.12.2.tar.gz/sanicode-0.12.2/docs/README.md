# Sanicode Documentation

Reference documentation for [sanicode](../README.md), the AI-assisted code sanitization scanner.

## Getting started

- [Getting Started Guide](getting-started.md) — Install, scan a sample app, interpret findings

## User guides

- [CI/CD Integration](ci-cd-integration.md) — GitHub Actions, GitLab CI, Jenkins, Azure DevOps, Tekton
- [Granite Deployment](granite-deployment.md) — Deploy the Granite Code 8B model for local LLM tiers
- [Air-Gapped Deployment](air-gapped-deployment-guide.md) — Zero-egress deployment on OpenShift, RHEL, or Podman

## Architecture and compliance

- [Air-Gapped Architecture](air-gapped-architecture.md) — Offline-native design principles and component diagram
- [SARIF Contract](sarif-contract.md) — SARIF v2.1.0 output schema (enriched/standard/minimal tiers)
- [FIPS Compliance](fips-compliance.md) — FIPS 140-2/140-3 validation and configuration
- [MLflow Integration](mlflow-openshift-ai.md) — Experiment tracking on OpenShift AI
- [Model Sizing Guide](model-sizing-guide.md) — Model Rodeo benchmark results and preset recommendations

## Generated artifacts

- [Coverage Scorecard](coverage-scorecard.html) — Live rule inventory (regenerate with `python scripts/coverage-scorecard.py`)

## Other directories

- [`../planning/`](../planning/) — In-flight designs, scope documents, session notes
- [`../research/`](../research/) — Benchmarks, investigations, comparisons
- [`../demos/`](../demos/) — CI example configs, runnable scenario walkthroughs
