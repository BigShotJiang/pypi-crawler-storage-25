"""Sample vulnerable web application for Sanicode demonstration.

Each function demonstrates a different vulnerability class with its
corresponding CWE and STIG mapping. Run:

    sanicode scan examples/sample-app/

to see all findings, then compare with app_fixed.py to see the remediation.
"""

import os
import sqlite3
import subprocess


def get_db():
    """Return a database connection."""
    return sqlite3.connect("app.db")


# CWE-89: SQL Injection (STIG APSC-DV-002540, CAT I)
def search_users(query):
    """Search users by name — VULNERABLE: string concatenation in SQL."""
    db = get_db()
    results = db.execute(
        "SELECT * FROM users WHERE name LIKE '%" + query + "%'"
    ).fetchall()
    return results


# CWE-89: SQL Injection variant — %-style formatting (SC006)
def get_user_by_id(user_id):
    """Fetch a user by ID — VULNERABLE: format string in SQL."""
    db = get_db()
    cursor = db.cursor()
    cursor.execute("SELECT * FROM users WHERE id = '%s'" % user_id)  # noqa: UP031
    return cursor.fetchone()


# CWE-78: OS Command Injection (STIG APSC-DV-002510, CAT I)
def ping_host(hostname):
    """Ping a host to check connectivity — VULNERABLE: shell=True with user input."""
    result = subprocess.run(
        f"ping -c 1 {hostname}",
        shell=True,
        capture_output=True,
        text=True,
    )
    return result.stdout


# CWE-78: OS Command Injection variant — os.system (SC003)
def run_report(report_name):
    """Generate a named report — VULNERABLE: os.system with user input."""
    os.system("generate-report " + report_name)


# CWE-94: Code Injection (STIG APSC-DV-002560, CAT I)
def evaluate_expression(expr):
    """Evaluate a user-provided math expression — VULNERABLE: eval() on user input."""
    return eval(expr)  # noqa: S307


# CWE-79: Cross-Site Scripting (STIG APSC-DV-002520, CAT II)
def render_greeting(name):
    """Render a personalized greeting — VULNERABLE: unsanitized input in HTML output."""
    return f"<h1>Hello, {name}!</h1>"


# CWE-22: Path Traversal (STIG APSC-DV-002560, CAT II)
def read_upload(filename):
    """Read a file from the uploads directory — VULNERABLE: no path boundary check."""
    with open(f"/var/uploads/{filename}") as f:
        return f.read()
