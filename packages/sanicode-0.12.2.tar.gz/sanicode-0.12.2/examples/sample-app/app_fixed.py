"""Remediated version of the sample application.

Compare with app.py to see the before/after for each vulnerability class.
Run `sanicode scan examples/sample-app/app_fixed.py` to verify zero findings.
"""

import ast
import os
import sqlite3
import subprocess
from html import escape
from pathlib import Path

UPLOAD_DIR = Path("/var/uploads")


def get_db():
    """Return a database connection."""
    return sqlite3.connect("app.db")


# CWE-89 FIX: Parameterized query — user input never interpolated into SQL
def search_users(query):
    """Search users by name — safe: parameterized query."""
    db = get_db()
    results = db.execute(
        "SELECT * FROM users WHERE name LIKE ?",
        (f"%{query}%",),
    ).fetchall()
    return results


# CWE-89 FIX: Parameterized query (tuple form)
def get_user_by_id(user_id):
    """Fetch a user by ID — safe: parameterized query."""
    db = get_db()
    cursor = db.cursor()
    cursor.execute("SELECT * FROM users WHERE id = ?", (user_id,))
    return cursor.fetchone()


# CWE-78 FIX: Argument list, no shell — OS never interprets the string
def ping_host(hostname):
    """Ping a host to check connectivity — safe: shell=False, argument list."""
    result = subprocess.run(
        ["ping", "-c", "1", hostname],
        capture_output=True,
        text=True,
    )
    return result.stdout


# CWE-78 FIX: subprocess with argument list replaces os.system
def run_report(report_name):
    """Generate a named report — safe: subprocess with argument list."""
    subprocess.run(["generate-report", report_name], check=True)


# CWE-94 FIX: ast.literal_eval only parses literals, not arbitrary code
def evaluate_expression(expr):
    """Evaluate a user-provided expression — safe: ast.literal_eval rejects code."""
    return ast.literal_eval(expr)


# CWE-79 FIX: html.escape neutralizes all HTML special characters
def render_greeting(name):
    """Render a personalized greeting — safe: name is HTML-escaped."""
    return f"<h1>Hello, {escape(name)}!</h1>"


# CWE-22 FIX: Resolve symlinks and assert path is inside UPLOAD_DIR
def read_upload(filename):
    """Read a file from the uploads directory — safe: boundary check before open."""
    target = (UPLOAD_DIR / filename).resolve()
    if not target.is_relative_to(UPLOAD_DIR):
        raise ValueError(f"Access denied: {filename!r} is outside the upload directory")
    with open(target) as f:
        return f.read()
