"""Sanicode KFP 2.x pipeline — wraps ``sanicode scan`` for Data Science Pipelines.

Pipeline DAG (single-repo):

    clone_repo ──→ scan ──→ generate_reports ──→ log_to_mlflow (conditional)

The multi-repo variant wraps the same DAG in ``ParallelFor`` across a list of
repositories with a configurable parallelism cap.
"""

from kfp import dsl
from kfp.dsl import Dataset, Input, Output

SANICODE_IMAGE = "quay.io/wjackson/sanicode:0.9.0"


# ---------------------------------------------------------------------------
# Components
# ---------------------------------------------------------------------------


@dsl.component(
    base_image="registry.access.redhat.com/ubi9/python-311:latest",
    packages_to_install=["gitpython"],
)
def clone_repo(
    repo_url: str,
    branch: str,
    source: Output[Dataset],
) -> None:
    """Shallow-clone a git repository."""
    import git

    git.Repo.clone_from(repo_url, source.path, branch=branch, depth=1)


@dsl.component(base_image=SANICODE_IMAGE)
def scan(
    source: Input[Dataset],
    config_toml: str,
    offline: bool,
    formats: str,
    scan_result: Output[Dataset],
) -> dict:
    """Run ``sanicode scan`` against the cloned source and persist results.

    Returns the scan summary dict (findings counts, graph metrics) so
    downstream steps can consume it without re-reading the artifact.
    """
    import json
    import re
    import subprocess
    import tempfile
    from pathlib import Path

    out_dir = Path(scan_result.path)
    out_dir.mkdir(parents=True, exist_ok=True)

    # Build config TOML — mirrors the Tekton task pattern exactly:
    # if the user supplied config already contains output_dir, patch it;
    # otherwise append an [output] section.
    config_text = config_toml if config_toml else ""
    if "output_dir" in config_text:
        config_text = re.sub(
            r'output_dir\s*=\s*"[^"]*"',
            f'output_dir = "{out_dir}"',
            config_text,
        )
    elif "[output]" in config_text:
        config_text = config_text.replace(
            "[output]", f'[output]\noutput_dir = "{out_dir}"'
        )
    else:
        config_text += f'\n[output]\noutput_dir = "{out_dir}"\n'

    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".toml", delete=False
    ) as cfg_file:
        cfg_file.write(config_text)
        cfg_path = cfg_file.name

    # Build CLI arguments
    args = ["sanicode", "scan", source.path, "--config", cfg_path]
    for fmt in formats.split():
        args.extend(["--format", fmt])
    if offline:
        args.append("--offline")

    subprocess.run(args, check=True)

    # Return summary for downstream steps (passed by value via KFP)
    result_file = out_dir / "scan-result.json"
    if not result_file.exists():
        raise FileNotFoundError(
            f"scan-result.json not found in {out_dir}; "
            "sanicode scan may have failed silently"
        )
    data = json.loads(result_file.read_text())
    summary = data.get("summary")
    if summary is None:
        raise KeyError(
            f"'summary' key missing from scan-result.json: {list(data.keys())}"
        )
    return summary


@dsl.component(base_image=SANICODE_IMAGE)
def generate_reports(
    scan_output: Input[Dataset],
    additional_formats: str,
    reports: Output[Dataset],
) -> None:
    """Generate additional report formats from persisted scan results.

    Separated from the scan step so heavy formats (HTML, STIG checklist,
    POAM) can be retried independently without re-running the scan.
    """
    import json
    import shutil
    from pathlib import Path

    in_dir = Path(scan_output.path)
    out_dir = Path(reports.path)
    out_dir.mkdir(parents=True, exist_ok=True)

    # Copy base scan artifacts (scan-result.json, graph.json, SARIF, etc.)
    for f in in_dir.iterdir():
        if f.is_file():
            shutil.copy2(f, out_dir / f.name)

    from sanicode.report.persist import load_scan_result

    result = load_scan_result(out_dir / "scan-result.json")

    for fmt in additional_formats.split():
        if fmt == "html":
            from sanicode.report.html import generate_html

            graph_file = out_dir / "graph.json"
            graph_data = (
                json.loads(graph_file.read_text()) if graph_file.exists() else None
            )
            (out_dir / "report.html").write_text(
                generate_html(result, graph_data=graph_data), encoding="utf-8"
            )
        elif fmt == "stig-checklist":
            from sanicode.report.stig import (
                generate_stig_checklist,
                generate_stig_summary,
            )

            (out_dir / "report.ckl").write_text(
                generate_stig_checklist(result), encoding="utf-8"
            )
            (out_dir / "report-stig-summary.md").write_text(
                generate_stig_summary(result), encoding="utf-8"
            )
        elif fmt == "poam":
            from sanicode.report.poam import (
                generate_poam_csv,
                generate_poam_json,
                generate_poam_summary,
            )

            (out_dir / "report-poam.csv").write_text(
                generate_poam_csv(result), encoding="utf-8"
            )
            (out_dir / "report-poam.json").write_text(
                json.dumps(generate_poam_json(result), indent=2), encoding="utf-8"
            )
            (out_dir / "report-poam-summary.md").write_text(
                generate_poam_summary(result), encoding="utf-8"
            )


@dsl.component(
    base_image=SANICODE_IMAGE,
    packages_to_install=["mlflow>=2.0"],
)
def log_to_mlflow(
    reports: Input[Dataset],
    source: Input[Dataset],
    scan_summary: dict,
    mlflow_tracking_uri: str,
    mlflow_experiment_prefix: str,
    repo_url: str,
) -> str:
    """Log scan metrics and report artifacts to an MLflow tracking server.

    Mirrors the metric/tag layout from ``sanicode.integrations.mlflow`` so
    that KFP runs and CLI-driven runs land in the same experiment namespace.
    """
    import subprocess
    from pathlib import Path

    import mlflow

    mlflow.set_tracking_uri(mlflow_tracking_uri)

    # Name the experiment after the scanned repo — same convention as the
    # built-in MLflow integration.
    repo_name = repo_url.rsplit("/", 1)[-1].removesuffix(".git")
    experiment_name = f"{mlflow_experiment_prefix}/{repo_name}"
    mlflow.set_experiment(experiment_name)

    with mlflow.start_run() as run:
        # -- Metrics (mirrors _log_metrics in integrations/mlflow.py) --
        mlflow.log_metric(
            "findings_total", scan_summary.get("total_findings", 0)
        )
        by_severity = scan_summary.get("by_severity", {})
        for sev in ("critical", "high", "medium", "low", "info"):
            mlflow.log_metric(f"findings_{sev}", by_severity.get(sev, 0))

        # STIG CAT level aggregations
        cat_i = by_severity.get("critical", 0) + by_severity.get("high", 0)
        mlflow.log_metric("cat_i_count", cat_i)
        mlflow.log_metric("cat_ii_count", by_severity.get("medium", 0))
        mlflow.log_metric("cat_iii_count", by_severity.get("low", 0))

        # Graph topology (all 5 metrics, matching integrations/mlflow.py)
        mlflow.log_metric("graph_nodes", scan_summary.get("graph_nodes", 0))
        mlflow.log_metric("graph_edges", scan_summary.get("graph_edges", 0))
        mlflow.log_metric(
            "graph_entry_points", scan_summary.get("graph_entry_points", 0)
        )
        mlflow.log_metric("graph_sinks", scan_summary.get("graph_sinks", 0))
        mlflow.log_metric(
            "graph_sanitizers", scan_summary.get("graph_sanitizers", 0)
        )
        if (score := scan_summary.get("compliance_score")) is not None:
            mlflow.log_metric("compliance_score", score)
        # Note: scan_duration_sec is omitted — KFP tracks step duration natively.

        # -- Parameters --
        mlflow.log_param("repo_url", repo_url)

        # -- Tags --
        try:
            sha = subprocess.check_output(
                ["git", "rev-parse", "HEAD"],
                cwd=source.path,
                text=True,
                stderr=subprocess.DEVNULL,
            ).strip()
            mlflow.set_tag("commit_sha", sha)
        except (subprocess.SubprocessError, FileNotFoundError):
            pass

        # Correlate with the sanicode release that produced these findings.
        import importlib.metadata

        try:
            mlflow.set_tag(
                "sanicode_version",
                importlib.metadata.version("sanicode"),
            )
        except importlib.metadata.PackageNotFoundError:
            pass

        # -- Artifacts --
        artifact_suffixes = {".json", ".sarif", ".md", ".csv", ".html", ".ckl"}
        for artifact in Path(reports.path).iterdir():
            if artifact.is_file() and artifact.suffix in artifact_suffixes:
                mlflow.log_artifact(str(artifact))

        return run.info.run_id


# ---------------------------------------------------------------------------
# Pipeline definitions
# ---------------------------------------------------------------------------


@dsl.pipeline(
    name="sanicode-scan",
    description=(
        "Scan a repository with sanicode, build a knowledge graph, and "
        "generate compliance-mapped reports (OWASP ASVS, NIST 800-53, ASD STIG)."
    ),
)
def sanicode_pipeline(
    repo_url: str,
    branch: str = "main",
    scan_formats: str = "sarif json markdown",
    additional_formats: str = "html",
    offline: bool = True,
    config_toml: str = "",
    mlflow_tracking_uri: str = "",
    mlflow_experiment_prefix: str = "sanicode",
) -> None:
    clone_task = clone_repo(repo_url=repo_url, branch=branch)

    scan_task = scan(
        source=clone_task.outputs["source"],
        config_toml=config_toml,
        offline=offline,
        formats=scan_formats,
    )

    reports_task = generate_reports(
        scan_output=scan_task.outputs["scan_result"],
        additional_formats=additional_formats,
    )

    with dsl.If(mlflow_tracking_uri != "", "mlflow-enabled"):
        log_to_mlflow(
            reports=reports_task.outputs["reports"],
            source=clone_task.outputs["source"],
            scan_summary=scan_task.outputs["Output"],
            mlflow_tracking_uri=mlflow_tracking_uri,
            mlflow_experiment_prefix=mlflow_experiment_prefix,
            repo_url=repo_url,
        )


@dsl.pipeline(
    name="sanicode-multi-scan",
    description=(
        "Scan multiple repositories in parallel with sanicode. Each repo "
        "goes through clone -> scan -> report -> optional MLflow logging."
    ),
)
def sanicode_multi_scan_pipeline(
    repos: list,  # list of {"url": str, "branch": str} dicts
    scan_formats: str = "sarif json markdown",
    additional_formats: str = "html",
    offline: bool = True,
    config_toml: str = "",
    mlflow_tracking_uri: str = "",
    mlflow_experiment_prefix: str = "sanicode",
) -> None:
    with dsl.ParallelFor(repos, parallelism=4) as repo:
        clone_task = clone_repo(repo_url=repo.url, branch=repo.branch)

        scan_task = scan(
            source=clone_task.outputs["source"],
            config_toml=config_toml,
            offline=offline,
            formats=scan_formats,
        )

        reports_task = generate_reports(
            scan_output=scan_task.outputs["scan_result"],
            additional_formats=additional_formats,
        )

        with dsl.If(mlflow_tracking_uri != "", "mlflow-enabled"):
            log_to_mlflow(
                reports=reports_task.outputs["reports"],
                source=clone_task.outputs["source"],
                scan_summary=scan_task.outputs["Output"],
                mlflow_tracking_uri=mlflow_tracking_uri,
                mlflow_experiment_prefix=mlflow_experiment_prefix,
                repo_url=repo.url,
            )
