"""Compile sanicode KFP pipelines to IR YAML for upload to DSPA.

Usage:
    python deploy/kfp/compile.py              # writes to deploy/kfp/
    python deploy/kfp/compile.py /tmp/out     # writes to /tmp/out/
"""

from __future__ import annotations

import sys
from pathlib import Path

# Ensure pipeline.py is importable from the same directory.
sys.path.insert(0, str(Path(__file__).resolve().parent))


def main(out_dir: Path | None = None) -> None:
    from kfp import compiler
    from pipeline import sanicode_multi_scan_pipeline, sanicode_pipeline

    if out_dir is None:
        out_dir = Path(__file__).resolve().parent
    out_dir.mkdir(parents=True, exist_ok=True)

    compiler.Compiler().compile(
        sanicode_pipeline, str(out_dir / "pipeline.yaml")
    )
    compiler.Compiler().compile(
        sanicode_multi_scan_pipeline, str(out_dir / "pipeline-multi-scan.yaml")
    )
    print(f"Compiled to {out_dir}/: pipeline.yaml, pipeline-multi-scan.yaml")


if __name__ == "__main__":
    target = Path(sys.argv[1]) if len(sys.argv) > 1 else None
    main(target)
