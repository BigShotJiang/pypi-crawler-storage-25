# Disconnected OpenShift Deployment

These manifests support deploying sanicode on OpenShift clusters with no
outbound internet access.

## Prerequisites

- cluster-admin privileges on the target cluster
- `skopeo` installed on the connected machine used for mirroring
- A private container registry reachable from all cluster nodes
- Authentication to both quay.io (source) and your internal registry (target)
  configured in `~/.docker/config.json` or via `skopeo login`

## Step 1 — Mirror images

On a connected machine, mirror all required images to your internal registry:

```bash
./scripts/mirror-images.sh registry.internal.example.com:5000 0.9.0
```

## Step 2 — Apply the mirror policy

Edit the manifest for your OpenShift version, replacing `<your-registry>` with
the hostname (and port) of your internal registry:

**OpenShift 4.14+**
```bash
sed -i 's|<your-registry>|registry.internal.example.com:5000|g' \
    deploy/disconnected/imagedigestmirrorset.yaml
oc apply -f deploy/disconnected/imagedigestmirrorset.yaml
```

**OpenShift 4.13 and earlier**
```bash
sed -i 's|<your-registry>|registry.internal.example.com:5000|g' \
    deploy/disconnected/imagecontentsourcepolicy.yaml
oc apply -f deploy/disconnected/imagecontentsourcepolicy.yaml
```

## Step 3 — Wait for rollout

The mirror policy triggers a MachineConfig update that restarts CRI-O on
every node. This causes a rolling reboot of worker nodes.

```bash
# Watch all MachineConfigPools until UPDATED=true, DEGRADED=false
oc get mcp -w
```

Typical rollout time: 5–15 minutes for a 3-node cluster.

## Step 4 — Deploy sanicode

Update the image repository in the Helm values to point at your internal
registry, then install as normal:

```bash
helm upgrade --install sanicode charts/sanicode/ \
    --set image.repository=registry.internal.example.com:5000/wjackson/sanicode \
    --set imagePullSecrets[0].name=internal-registry-pull-secret \
    -n sanicode --create-namespace
```

## Model weights

If you are serving a local LLM (e.g., Granite Code 8B) in the disconnected
cluster, also mirror the model weights. The recommended approach is a ModelCar
OCI image — see `models/modelcar/README.md` for build and mirroring
instructions. Uncomment the ModelCar lines in the mirror manifests and the
mirroring script once the image is built.
