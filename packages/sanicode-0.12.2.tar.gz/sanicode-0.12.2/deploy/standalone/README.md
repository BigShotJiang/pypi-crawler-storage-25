# Standalone RHEL Deployment

Run sanicode as a Podman-managed systemd service on a standalone RHEL 9.x
host without OpenShift or internet access.

## Prerequisites

- RHEL 9.x with Podman installed (`dnf install -y podman`)
- The sanicode container image as a `.tar` archive (see below)
- Root access on the target host

## Step 1 — Save the image on a connected machine

```bash
podman pull quay.io/wjackson/sanicode:0.9.0
podman save quay.io/wjackson/sanicode:0.9.0 -o sanicode-0.9.0.tar
```

Transfer `sanicode-0.9.0.tar` to the disconnected host via scp, rsync, USB
drive, or your organization's approved transfer method.

## Step 2 — Run the setup script

From the sanicode repo root on the disconnected host:

```bash
sudo ./scripts/setup-rhel-standalone.sh /path/to/sanicode-0.9.0.tar
```

The script:
1. Creates a `sanicode` system user (non-root, no shell)
2. Creates `/etc/sanicode/` and `/var/lib/sanicode/data/`
3. Loads the container image with `podman load`
4. Writes a default `/etc/sanicode/sanicode.toml` (if absent)
5. Installs and enables `sanicode.service` via systemd

## Step 3 — Verify

```bash
systemctl status sanicode
curl http://localhost:8080/api/v1/health
```

## Configuration

Edit `/etc/sanicode/sanicode.toml` to configure scan settings and, optionally,
a local LLM endpoint. Restart the service after changes:

```bash
systemctl restart sanicode
```

The default configuration runs in degraded mode (AST-only, no LLM), which
still produces full SARIF output with CWE, ASVS 5.0, NIST 800-53, and
ASD STIG v4r11 compliance mappings.

## Logs

```bash
journalctl -u sanicode -f
```

## Connecting to a local LLM

If vLLM is running on the same host, uncomment the `[llm.*]` sections in
`/etc/sanicode/sanicode.toml` and set the endpoint to
`http://localhost:<vllm-port>/v1`. Restart sanicode after editing.

## Alternative: pip install (no container)

If Podman is not available, install sanicode directly with pip using an offline
bundle. See `scripts/bundle-offline-pip.sh` for how to create the bundle on a
connected machine.
