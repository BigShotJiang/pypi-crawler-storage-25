"""Baseline and suppression management for incremental adoption.

A baseline captures all current findings so that subsequent scans only report
*new* issues.  Findings are matched by a fingerprint of (rule_id, relative
file path, line content hash), which is stable across minor reformatting.

Inline suppression via ``# sanicode:ignore`` comments is also handled here.
"""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import asdict, dataclass, field
from datetime import date, datetime, timezone
from pathlib import Path

# ---------------------------------------------------------------------------
# Fingerprinting
# ---------------------------------------------------------------------------

def _line_hash(file_path: Path, line: int) -> str:
    """Compute a short SHA-256 hash of the stripped content at *line*.

    Returns the first 8 hex characters, or ``"00000000"`` on any read error.
    """
    try:
        lines = file_path.read_text(encoding="utf-8").splitlines()
        if 0 < line <= len(lines):
            content = lines[line - 1].strip()
            return hashlib.sha256(content.encode()).hexdigest()[:8]
    except (OSError, UnicodeDecodeError):
        pass
    return "00000000"


# ---------------------------------------------------------------------------
# Baseline data model
# ---------------------------------------------------------------------------

@dataclass
class BaselineEntry:
    """A single suppressed finding in the baseline."""

    rule_id: str
    file: str
    line_hash: str
    message: str
    severity: str
    cwe_id: int
    approver: str | None = None
    justification: str | None = None
    expires: str | None = None  # ISO date string, e.g. "2026-06-23"

    @property
    def fingerprint(self) -> tuple[str, str, str]:
        return (self.rule_id, self.file, self.line_hash)

    def is_expired(self) -> bool:
        if self.expires is None:
            return False
        try:
            return date.fromisoformat(self.expires) < date.today()
        except ValueError:
            return False


@dataclass
class Baseline:
    """Container for a full baseline file."""

    version: int = 1
    created: str = ""
    sanicode_version: str = ""
    entries: list[BaselineEntry] = field(default_factory=list)

    def fingerprints(self) -> set[tuple[str, str, str]]:
        """Return the set of active (non-expired) fingerprints."""
        return {e.fingerprint for e in self.entries if not e.is_expired()}

    def save(self, path: Path) -> None:
        """Serialize this baseline to a JSON file."""
        data = {
            "version": self.version,
            "created": self.created,
            "sanicode_version": self.sanicode_version,
            "entries": [asdict(e) for e in self.entries],
        }
        path.write_text(
            json.dumps(data, indent=2, sort_keys=False),
            encoding="utf-8",
        )

    @classmethod
    def load(cls, path: Path) -> Baseline:
        """Deserialize a baseline from a JSON file."""
        raw = json.loads(path.read_text(encoding="utf-8"))
        entries = [BaselineEntry(**e) for e in raw.get("entries", [])]
        return cls(
            version=raw.get("version", 1),
            created=raw.get("created", ""),
            sanicode_version=raw.get("sanicode_version", ""),
            entries=entries,
        )


# ---------------------------------------------------------------------------
# Baseline creation
# ---------------------------------------------------------------------------

def create_baseline(findings: list, target: Path, sanicode_version: str) -> Baseline:
    """Create a baseline from a list of enriched findings.

    Each finding's file path is stored relative to *target* so baselines are
    portable across machines.
    """
    target = target.resolve()
    entries: list[BaselineEntry] = []
    for f in findings:
        file_path = f.file if isinstance(f.file, Path) else Path(f.file)
        try:
            rel = str(file_path.relative_to(target))
        except ValueError:
            rel = str(file_path)
        entries.append(BaselineEntry(
            rule_id=f.rule_id,
            file=rel,
            line_hash=_line_hash(file_path, f.line),
            message=f.message,
            severity=getattr(f, "derived_severity", None) or f.severity,
            cwe_id=f.cwe_id,
        ))
    return Baseline(
        created=datetime.now(timezone.utc).isoformat(),
        sanicode_version=sanicode_version,
        entries=entries,
    )


# ---------------------------------------------------------------------------
# Baseline filtering
# ---------------------------------------------------------------------------

def filter_by_baseline(
    findings: list,
    baseline: Baseline,
    target: Path,
) -> tuple[list, list]:
    """Partition findings into new and suppressed lists.

    Returns:
        A ``(new_findings, suppressed_findings)`` tuple.
    """
    target = target.resolve()
    active_fps = baseline.fingerprints()
    new: list = []
    suppressed: list = []
    for f in findings:
        file_path = f.file if isinstance(f.file, Path) else Path(f.file)
        try:
            rel = str(file_path.relative_to(target))
        except ValueError:
            rel = str(file_path)
        fp = (f.rule_id, rel, _line_hash(file_path, f.line))
        if fp in active_fps:
            suppressed.append(f)
        else:
            new.append(f)
    return new, suppressed


# ---------------------------------------------------------------------------
# Inline suppression
# ---------------------------------------------------------------------------

_IGNORE_PATTERN = re.compile(
    r"#\s*sanicode:ignore"
    r"(?:\[([^\]]+)\])?"   # optional [rule-id]
    r"\s*(.*)",            # rest of line = justification
)


def check_inline_suppression(file_path: Path, line: int, rule_id: str) -> str | None:
    """Check if a finding is suppressed by an inline ``# sanicode:ignore`` comment.

    The comment may appear on the finding's line or the line immediately above.
    A justification is **mandatory** -- bare ``# sanicode:ignore`` without
    explanatory text is not honoured.

    Returns:
        The justification string if suppressed, ``None`` otherwise.
    """
    try:
        lines = file_path.read_text(encoding="utf-8").splitlines()
    except (OSError, UnicodeDecodeError):
        return None

    for check_line in (line, line - 1):
        if 0 < check_line <= len(lines):
            match = _IGNORE_PATTERN.search(lines[check_line - 1])
            if match:
                rule_filter = match.group(1)
                justification = match.group(2).strip()
                if not justification:
                    return None  # justification is mandatory
                if rule_filter is None or rule_filter == rule_id:
                    return justification
    return None
