"""Domain-specific query facade for the knowledge graph.

Provides a focused API that rules use to query the graph without coupling
to NetworkX internals. Extend methods here when new rule patterns need
queries not yet covered.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from sanicode.graph.builder import KnowledgeGraph


@dataclass(frozen=True)
class NodeInfo:
    """Lightweight graph node summary for rule consumption."""

    node_id: str
    label: str
    kind: str
    file: Path | None
    line: int | None
    function: str | None
    extra: dict = field(default_factory=dict)


class GraphQueryHelper:
    """Domain-specific query API wrapping a KnowledgeGraph.

    Rules call methods on this helper rather than touching the underlying
    NetworkX graph directly. This keeps rules decoupled from graph
    internals and makes it easy to extend the query surface without
    modifying the core graph model.
    """

    def __init__(self, kg: KnowledgeGraph) -> None:
        self._kg = kg

    # -- internal helpers --------------------------------------------------

    def _to_info(self, node_id: str, attrs: dict) -> NodeInfo:
        """Convert raw graph node data to a NodeInfo."""
        file_val = attrs.get("file")
        return NodeInfo(
            node_id=node_id,
            label=attrs.get("label", node_id),
            kind=attrs.get("kind", "unknown"),
            file=Path(file_val) if file_val else None,
            line=attrs.get("line"),
            function=attrs.get("function"),
            extra={
                k: v for k, v in attrs.items()
                if k not in ("label", "kind", "file", "line", "function")
            },
        )

    def _nodes_of_kind(self, kind: str, file: Path | None = None) -> list[NodeInfo]:
        """Return all nodes of a given kind, optionally filtered by file."""
        result = []
        file_str = str(file) if file else None
        for node_id, attrs in self._kg.all_nodes():
            if attrs.get("kind") != kind:
                continue
            if file_str is not None and attrs.get("file") != file_str:
                continue
            result.append(self._to_info(node_id, attrs))
        return result

    # -- public query API --------------------------------------------------

    def entry_points(self, file: Path | None = None) -> list[NodeInfo]:
        """All entry points, optionally filtered to a single file."""
        return self._nodes_of_kind("entry_point", file=file)

    def sinks(
        self, file: Path | None = None, cwe_id: int | None = None,
    ) -> list[NodeInfo]:
        """All sinks, optionally filtered by file and/or CWE ID."""
        nodes = self._nodes_of_kind("sink", file=file)
        if cwe_id is not None:
            nodes = [n for n in nodes if n.extra.get("cwe_id") == cwe_id]
        return nodes

    def sanitizers(self, file: Path | None = None) -> list[NodeInfo]:
        """All sanitizer nodes, optionally filtered by file."""
        return self._nodes_of_kind("sanitizer", file=file)

    def auth_guards(self, file: Path | None = None) -> list[NodeInfo]:
        """All auth guard nodes, optionally filtered by file."""
        return self._nodes_of_kind("auth_guard", file=file)

    def is_guarded(self, entry_node_id: str) -> bool:
        """Does this entry point have an incoming 'guards' edge?"""
        if not self._kg.has_node(entry_node_id):
            return False
        for pred in self._kg.predecessors(entry_node_id):
            if self._kg.edge_data(pred, entry_node_id).get("kind") == "guards":
                return True
        return False

    def unguarded_entries(self) -> list[NodeInfo]:
        """HTTP handlers without any auth guard edge."""
        result = []
        for node_id, attrs in self._kg.all_nodes():
            if attrs.get("kind") != "entry_point":
                continue
            if attrs.get("entry_kind") not in ("http_handler", "graphql_resolver"):
                continue
            if not self.is_guarded(node_id):
                result.append(self._to_info(node_id, attrs))
        return result

    def paths_between(
        self, src_id: str, tgt_id: str, cutoff: int = 10,
    ) -> list[list[NodeInfo]]:
        """All simple paths between two nodes, up to *cutoff* length."""
        try:
            raw_paths = self._kg.all_simple_paths(src_id, tgt_id, cutoff=cutoff)
            result = []
            for path in raw_paths:
                info_path = []
                for nid in path:
                    attrs = self._kg.node_data(nid)
                    info_path.append(self._to_info(nid, attrs))
                result.append(info_path)
        except (KeyError, ValueError):
            return []
        return result

    def has_sanitizer_on_path(self, src_id: str, tgt_id: str) -> bool:
        """Is there any sanitizer node or sanitized edge on any path between src and tgt?"""
        try:
            raw_paths = self._kg.all_simple_paths(src_id, tgt_id, cutoff=10)
            for path in raw_paths:
                # Check for sanitizer nodes on the path.
                for nid in path:
                    if self._kg.node_data(nid).get("kind") == "sanitizer":
                        return True
                # Check for sanitized edges on the path.
                for u, v in zip(path, path[1:], strict=False):
                    if self._kg.edge_data(u, v).get("sanitized"):
                        return True
        except (KeyError, ValueError):
            return False
        return False

    def reachable_sinks(self, entry_id: str) -> list[NodeInfo]:
        """Sink nodes reachable from a given entry point."""
        try:
            reachable = self._kg.descendants(entry_id)
        except (KeyError, ValueError):
            return []
        result = []
        for nid in reachable:
            attrs = self._kg.node_data(nid)
            if attrs.get("kind") == "sink":
                result.append(self._to_info(nid, attrs))
        return result

    def node_at(self, file: Path, line: int) -> NodeInfo | None:
        """Look up a graph node by source location (file + line)."""
        file_str = str(file)
        for node_id, attrs in self._kg.all_nodes():
            if attrs.get("file") == file_str and attrs.get("line") == line:
                return self._to_info(node_id, attrs)
        return None

    def nodes_in_file(self, file: Path) -> list[NodeInfo]:
        """All graph nodes located in a specific file."""
        file_str = str(file)
        result = []
        for node_id, attrs in self._kg.all_nodes():
            if attrs.get("file") == file_str:
                result.append(self._to_info(node_id, attrs))
        return result

    def predecessors(self, node_id: str) -> list[NodeInfo]:
        """Immediate upstream nodes (predecessors in the directed graph)."""
        result = []
        try:
            for pred_id in self._kg.predecessors(node_id):
                attrs = self._kg.node_data(pred_id)
                result.append(self._to_info(pred_id, attrs))
        except (KeyError, ValueError):
            pass
        return result

    def successors(self, node_id: str) -> list[NodeInfo]:
        """Immediate downstream nodes (successors in the directed graph)."""
        result = []
        try:
            for succ_id in self._kg.successors(node_id):
                attrs = self._kg.node_data(succ_id)
                result.append(self._to_info(succ_id, attrs))
        except (KeyError, ValueError):
            pass
        return result
