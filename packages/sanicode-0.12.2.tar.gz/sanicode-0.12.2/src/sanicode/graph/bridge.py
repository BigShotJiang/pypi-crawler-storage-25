"""Bridge between treeloom's CodePropertyGraph and sanicode's KnowledgeGraph API.

Wraps a treeloom CPG and exposes the same public interface as
KnowledgeGraph, allowing incremental migration of consumers.
"""

from __future__ import annotations

import logging
from collections import deque
from pathlib import Path
from typing import Any

from treeloom import CodePropertyGraph, NodeId

_log = logging.getLogger(__name__)


class CpgBridge:
    """Adapts a treeloom CodePropertyGraph to sanicode's KnowledgeGraph interface.

    The bridge maintains a bidirectional mapping between sanicode-style
    string IDs (``"entry_1"``, ``"sink_3"``) and treeloom ``NodeId``
    objects.  When a security primitive is registered via
    ``add_entry_point()`` etc., the bridge first tries to find a
    matching CPG node at the given ``(file, line)``; if found, it
    annotates that node with sanicode metadata.  If no CPG node exists
    at that location, the primitive is tracked as a *synthetic* node
    (stored only in the bridge's internal dictionaries).

    Consumers that need the underlying CPG can access it via
    ``self.cpg``.
    """

    def __init__(self, cpg: CodePropertyGraph) -> None:
        self.cpg = cpg
        self._node_counter: int = 0

        # Sanicode string ID -> treeloom NodeId (only for nodes with a CPG match)
        self._id_map: dict[str, NodeId] = {}
        # treeloom NodeId string repr -> sanicode string ID
        self._reverse_map: dict[str, str] = {}
        # Sanicode node attributes (kind, label, file, line, extras)
        self._sanicode_attrs: dict[str, dict[str, Any]] = {}

        # Edges added by sanicode (not from treeloom's structural graph).
        # Each entry: (from_sanicode_id, to_sanicode_id, attrs_dict).
        self._sanicode_edges: list[tuple[str, str, dict[str, Any]]] = []

        # Framework metadata (same format as KnowledgeGraph._graph.graph["frameworks"])
        self._frameworks: list[dict[str, Any]] = []

        # Index CPG nodes by (file_str, line) for efficient lookup
        self._location_index: dict[tuple[str, int], list[NodeId]] = {}
        self._build_location_index()

    # ── Internal helpers ──────────────────────────────────────────────

    def _build_location_index(self) -> None:
        """Index CPG nodes by (file, line) for efficient lookup."""
        for node in self.cpg.nodes():
            if node.location:
                key = (str(node.location.file), node.location.line)
                self._location_index.setdefault(key, []).append(node.id)

    def _next_id(self, prefix: str) -> str:
        self._node_counter += 1
        return f"{prefix}_{self._node_counter}"

    def _find_cpg_node(self, file: Path | None, line: int | None) -> NodeId | None:
        """Find a treeloom CPG node at the given file/line."""
        if file is None or line is None:
            return None
        key = (str(file), line)
        candidates = self._location_index.get(key, [])
        return candidates[0] if candidates else None

    def _register_node(
        self,
        prefix: str,
        label: str,
        file: Path | None,
        line: int | None,
        kind: str,
        **attrs: Any,
    ) -> str:
        """Register a sanicode security node, linking to CPG node if possible."""
        sanicode_id = self._next_id(prefix)
        cpg_node_id = self._find_cpg_node(file, line)

        if cpg_node_id is not None:
            self._id_map[sanicode_id] = cpg_node_id
            self._reverse_map[str(cpg_node_id)] = sanicode_id
            # Annotate the CPG node with sanicode metadata
            self.cpg.annotate_node(cpg_node_id, "sanicode.kind", kind)
            self.cpg.annotate_node(cpg_node_id, "sanicode.label", label)
            self.cpg.annotate_node(cpg_node_id, "sanicode.id", sanicode_id)

        self._sanicode_attrs[sanicode_id] = {
            "kind": kind,
            "label": label,
            "file": str(file) if file else None,
            "line": line,
            **attrs,
        }
        return sanicode_id

    def _resolve_id(self, sanicode_id: str) -> NodeId | None:
        """Resolve a sanicode string ID to its treeloom NodeId, if mapped."""
        return self._id_map.get(sanicode_id)

    # ── Node addition methods ─────────────────────────────────────────

    def add_entry_point(
        self,
        label: str,
        file: Path | None = None,
        line: int | None = None,
        **attrs: Any,
    ) -> str:
        """Add an entry point node (e.g., an HTTP handler, CLI argument reader)."""
        return self._register_node("entry", label, file, line, "entry_point", **attrs)

    def add_sink(
        self,
        label: str,
        file: Path | None = None,
        line: int | None = None,
        cwe_id: int | None = None,
        **attrs: Any,
    ) -> str:
        """Add a sink node (e.g., SQL query, shell command, eval call)."""
        return self._register_node(
            "sink", label, file, line, "sink", cwe_id=cwe_id, **attrs
        )

    def add_sanitizer(
        self,
        label: str,
        file: Path | None = None,
        line: int | None = None,
        **attrs: Any,
    ) -> str:
        """Add a sanitizer node (e.g., html.escape, parameterized query wrapper)."""
        return self._register_node("sanitizer", label, file, line, "sanitizer", **attrs)

    def add_import(
        self,
        label: str,
        file: Path | None = None,
        line: int | None = None,
        **attrs: Any,
    ) -> str:
        """Add an import node to the graph."""
        return self._register_node("import", label, file, line, "import", **attrs)

    def add_auth_guard(
        self,
        label: str,
        file: Path | None = None,
        line: int | None = None,
        **attrs: Any,
    ) -> str:
        """Add an auth guard node (e.g., @login_required, @Secured)."""
        return self._register_node("guard", label, file, line, "auth_guard", **attrs)

    # ── Edge methods ──────────────────────────────────────────────────

    def add_data_flow(self, from_node: str, to_node: str, **attrs: Any) -> None:
        """Add a directed data-flow edge between two graph nodes."""
        if from_node not in self._sanicode_attrs:
            raise ValueError(f"Source node not in graph: {from_node!r}")
        if to_node not in self._sanicode_attrs:
            raise ValueError(f"Target node not in graph: {to_node!r}")
        edge_attrs = {"kind": "data_flow", **attrs}
        self._sanicode_edges.append((from_node, to_node, edge_attrs))

    def add_guards_edge(
        self, guard_node: str, entry_node: str, **attrs: Any
    ) -> None:
        """Add a directed 'guards' edge from an auth guard to an entry point."""
        if guard_node not in self._sanicode_attrs:
            raise ValueError(f"Guard node not in graph: {guard_node!r}")
        if entry_node not in self._sanicode_attrs:
            raise ValueError(f"Entry point node not in graph: {entry_node!r}")
        edge_attrs = {"kind": "guards", **attrs}
        self._sanicode_edges.append((guard_node, entry_node, edge_attrs))

    # ── Query methods ─────────────────────────────────────────────────

    def all_nodes(self) -> list[tuple[str, dict]]:
        """Return all sanicode-tracked nodes with their attributes."""
        return [(nid, dict(attrs)) for nid, attrs in self._sanicode_attrs.items()]

    def nodes_by_kind(self, kind: str) -> list[tuple[str, dict]]:
        """Return all nodes of a given kind."""
        return [
            (nid, dict(attrs))
            for nid, attrs in self._sanicode_attrs.items()
            if attrs.get("kind") == kind
        ]

    def node_counts_by_kind(self) -> dict[str, int]:
        """Count nodes grouped by kind in a single pass."""
        counts: dict[str, int] = {}
        for attrs in self._sanicode_attrs.values():
            kind = attrs.get("kind", "unknown")
            counts[kind] = counts.get(kind, 0) + 1
        return counts

    def successors(self, node_id: str) -> list[str]:
        """Return successor node IDs (nodes this node has edges to)."""
        return [to_id for from_id, to_id, _ in self._sanicode_edges if from_id == node_id]

    def predecessors(self, node_id: str) -> list[str]:
        """Return predecessor node IDs (nodes with edges to this node)."""
        return [
            from_id for from_id, to_id, _ in self._sanicode_edges if to_id == node_id
        ]

    def edge_data(self, from_id: str, to_id: str) -> dict:
        """Return edge attributes between two nodes.

        Raises ``KeyError`` if no such edge exists.
        """
        for f, t, attrs in self._sanicode_edges:
            if f == from_id and t == to_id:
                return dict(attrs)
        raise KeyError(f"No edge from {from_id!r} to {to_id!r}")

    def node_data(self, node_id: str) -> dict:
        """Return attributes for a single node.

        Raises ``KeyError`` if the node does not exist.
        """
        if node_id not in self._sanicode_attrs:
            raise KeyError(f"Node not in graph: {node_id!r}")
        return dict(self._sanicode_attrs[node_id])

    def set_node_attr(self, node_id: str, key: str, value: Any) -> None:
        """Set a single attribute on a node."""
        if node_id not in self._sanicode_attrs:
            raise KeyError(f"Node not in graph: {node_id!r}")
        self._sanicode_attrs[node_id][key] = value

    def has_node(self, node_id: str) -> bool:
        """Check whether a node exists in the graph."""
        return node_id in self._sanicode_attrs

    def has_edge(self, from_id: str, to_id: str) -> bool:
        """Check whether an edge exists between two nodes."""
        return any(
            f == from_id and t == to_id for f, t, _ in self._sanicode_edges
        )

    def has_path(self, source: str, target: str) -> bool:
        """Check whether a directed path exists between two nodes (BFS)."""
        if source == target:
            return True
        visited: set[str] = set()
        queue: deque[str] = deque([source])
        while queue:
            current = queue.popleft()
            if current == target:
                return True
            if current in visited:
                continue
            visited.add(current)
            for succ in self.successors(current):
                if succ not in visited:
                    queue.append(succ)
        return False

    def all_simple_paths(
        self, source: str, target: str, cutoff: int = 10
    ) -> list[list[str]]:
        """Return all simple (loop-free) paths between two nodes."""
        results: list[list[str]] = []
        self._dfs_paths(source, target, [source], set(), cutoff, results)
        return results

    def _dfs_paths(
        self,
        current: str,
        target: str,
        path: list[str],
        visited: set[str],
        cutoff: int,
        results: list[list[str]],
    ) -> None:
        """Depth-first enumeration of simple paths."""
        if current == target and len(path) > 1:
            results.append(list(path))
            return
        if len(path) > cutoff:
            return
        visited.add(current)
        for succ in self.successors(current):
            if succ not in visited:
                path.append(succ)
                self._dfs_paths(succ, target, path, visited, cutoff, results)
                path.pop()
        visited.discard(current)

    def descendants(self, node_id: str) -> set[str]:
        """Return all nodes reachable from the given node."""
        visited: set[str] = set()
        queue: deque[str] = deque([node_id])
        while queue:
            current = queue.popleft()
            if current in visited:
                continue
            visited.add(current)
            for succ in self.successors(current):
                if succ not in visited:
                    queue.append(succ)
        visited.discard(node_id)  # Exclude the start node itself
        return visited

    def in_edges(self, node_id: str) -> list[tuple[str, str, dict]]:
        """Return incoming edges with data for a node."""
        return [
            (f, t, dict(attrs))
            for f, t, attrs in self._sanicode_edges
            if t == node_id
        ]

    def out_edges(self, node_id: str) -> list[tuple[str, str, dict]]:
        """Return outgoing edges with data for a node."""
        return [
            (f, t, dict(attrs))
            for f, t, attrs in self._sanicode_edges
            if f == node_id
        ]

    def all_edges(self) -> list[tuple[str, str, dict]]:
        """Return all edges with their attributes."""
        return [(f, t, dict(attrs)) for f, t, attrs in self._sanicode_edges]

    def in_degree(self, node_id: str) -> int:
        """Return the number of incoming edges for a node."""
        return sum(1 for _, t, _ in self._sanicode_edges if t == node_id)

    def out_degree(self, node_id: str) -> int:
        """Return the number of outgoing edges for a node."""
        return sum(1 for f, _, _ in self._sanicode_edges if f == node_id)

    # ── Serialization ─────────────────────────────────────────────────

    def to_dict(self) -> dict[str, Any]:
        """Serialize the graph to a plain dict (JSON-serializable).

        Returns a node/edge format. Historically this used the
        ``nx.node_link_data`` "links" key for edges, but sanicode has
        always presented them as "edges" in the CLI, scoring, and
        other surfaces, so the JSON export now matches. Consumers
        reading ``graph.json`` should look up ``edges`` rather than
        ``links``.
        """
        nodes = []
        for nid, attrs in self._sanicode_attrs.items():
            node_entry = {"id": nid, **attrs}
            nodes.append(node_entry)

        edges = []
        for from_id, to_id, attrs in self._sanicode_edges:
            edge_entry = {"source": from_id, "target": to_id, **attrs}
            edges.append(edge_entry)

        return {
            "directed": True,
            "multigraph": False,
            "graph": {"frameworks": self._frameworks},
            "nodes": nodes,
            "edges": edges,
        }

    # ── Taint & security queries ──────────────────────────────────────

    def taint_flows_for_sink(self, file: str, line: int) -> list[list[dict]]:
        """Extract taint flow steps ending at a given sink location.

        Searches for taint-confirmed edges whose target node matches
        the given file and line.  Returns step sequences suitable for
        SARIF codeFlows emission.
        """
        taint_confidences = {"taint_analysis", "interprocedural_taint"}
        flows: list[list[dict]] = []

        # Find all sanicode nodes at (file, line).
        target_ids = [
            nid
            for nid, attrs in self._sanicode_attrs.items()
            if str(attrs.get("file", "")) == file and attrs.get("line") == line
        ]

        for target_id in target_ids:
            target_attrs = self._sanicode_attrs[target_id]
            for source_id, _, edge_data in self.in_edges(target_id):
                if edge_data.get("confidence") not in taint_confidences:
                    continue

                source_attrs = self._sanicode_attrs.get(source_id, {})
                steps: list[dict] = []

                # Step 1: taint source
                steps.append(
                    {
                        "file": str(source_attrs.get("file", "")),
                        "line": source_attrs.get("line", 1),
                        "message": f"Taint source: {source_attrs.get('label', source_id)}",
                    }
                )

                # Step 2: intermediate call (inter-procedural only)
                via_call = edge_data.get("via_call")
                if via_call:
                    steps.append(
                        {
                            "file": str(source_attrs.get("file", "")),
                            "line": source_attrs.get("line", 1),
                            "message": f"Via call: {via_call}",
                        }
                    )

                # Step 3: sink
                steps.append(
                    {
                        "file": str(target_attrs.get("file", "")),
                        "line": target_attrs.get("line", 1),
                        "message": f"Sink: {target_attrs.get('label', target_id)}",
                    }
                )

                flows.append(steps)

        return flows

    def unguarded_entry_points(self) -> list[tuple[str, dict]]:
        """Return HTTP entry points with no incoming 'guards' edge.

        Only considers entry_point nodes with entry_kind='http_handler'
        or 'graphql_resolver', since non-HTTP entry points don't need auth.
        """
        unguarded = []
        for node_id, attrs in self._sanicode_attrs.items():
            if attrs.get("kind") != "entry_point":
                continue
            if attrs.get("entry_kind") not in ("http_handler", "graphql_resolver"):
                continue
            has_guard = any(
                edge_attrs.get("kind") == "guards"
                for _, _, edge_attrs in self.in_edges(node_id)
            )
            if not has_guard:
                unguarded.append((node_id, dict(attrs)))
        return unguarded

    # ── Properties ────────────────────────────────────────────────────

    @property
    def detected_frameworks(self) -> list[dict[str, Any]]:
        """Frameworks detected during graph construction."""
        return list(self._frameworks)

    @property
    def node_count(self) -> int:
        """Number of sanicode-tracked nodes."""
        return len(self._sanicode_attrs)

    @property
    def edge_count(self) -> int:
        """Number of sanicode-tracked edges."""
        return len(self._sanicode_edges)

    def __repr__(self) -> str:
        return f"CpgBridge(nodes={self.node_count}, edges={self.edge_count})"
