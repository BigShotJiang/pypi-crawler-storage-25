"""Security annotation layer for treeloom CPG.

Runs sanicode's language-plugin-based security detection (entry points,
sinks, sanitizers, auth guards) and annotates the corresponding treeloom
CPG nodes with sanicode-specific metadata.

The detection logic mirrors ``KnowledgeGraph._populate()`` but instead
of building a standalone NetworkX graph, it annotates an existing
treeloom ``CodePropertyGraph`` and returns metadata that ``CpgBridge``
can consume.
"""

from __future__ import annotations

import logging
from collections import defaultdict
from pathlib import Path
from typing import Any

from treeloom import CodePropertyGraph

from sanicode.scanner.registry import get_registry

_log = logging.getLogger(__name__)


def annotate_security(
    cpg: CodePropertyGraph,
    file_trees: list[tuple[Path, Any]],
) -> dict[str, Any]:
    """Run security detection and annotate CPG nodes.

    Walks the pre-parsed file trees using sanicode's language plugins,
    detects security primitives (entry points, sinks, sanitizers,
    auth guards, imports), and annotates the corresponding CPG nodes
    with ``sanicode.*`` metadata keys.

    Args:
        cpg: A built treeloom CodePropertyGraph.
        file_trees: Pre-parsed ``(file_path, tree_sitter_Tree)`` pairs
            from sanicode's language plugins.

    Returns:
        Metadata dict with keys:

        - ``frameworks``: list of detected framework dicts
          (``{"name": ..., "modules": ...}``).
        - ``node_index``: mapping from ``(file_str, line, name)`` to
          the sanicode node ID string assigned during annotation.
        - ``by_function``: per-function groupings
          (``{fn_name: {"entries": [...], "sanitizers": [...], "sinks": [...]}}``).
        - ``guard_by_function``: per-function guard groupings
          (``{fn_name: [guard_id, ...]}``).
    """
    registry = get_registry()

    # Build a location index for efficient CPG node lookups.
    location_index: dict[tuple[str, int], list[Any]] = {}
    for node in cpg.nodes():
        if node.location:
            key = (str(node.location.file), node.location.line)
            location_index.setdefault(key, []).append(node.id)

    # Monotonic counter for sanicode IDs.
    counter = [0]

    def next_id(prefix: str) -> str:
        counter[0] += 1
        return f"{prefix}_{counter[0]}"

    def find_and_annotate(
        file: Path | None, line: int | None, kind: str, label: str, sanicode_id: str,
    ) -> None:
        """Annotate the CPG node at (file, line) if one exists."""
        if file is None or line is None:
            return
        key = (str(file), line)
        candidates = location_index.get(key, [])
        if not candidates:
            return
        cpg_node_id = candidates[0]
        cpg.annotate_node(cpg_node_id, "sanicode.kind", kind)
        cpg.annotate_node(cpg_node_id, "sanicode.label", label)
        cpg.annotate_node(cpg_node_id, "sanicode.id", sanicode_id)

    # ── First pass: imports and framework detection ───────────────────

    all_imports: list[Any] = []
    for file_path, tree in file_trees:
        plugin = registry.for_extension(file_path.suffix)
        if plugin is None:
            continue
        file_imports = plugin.detect_imports(tree, file_path)
        all_imports.extend(file_imports)
        for imp in file_imports:
            sid = next_id("import")
            find_and_annotate(imp.file, imp.line, "import", imp.module, sid)

    frameworks: list[Any] = []
    if file_trees:
        first_plugin = registry.for_extension(file_trees[0][0].suffix)
        if first_plugin is not None:
            frameworks = first_plugin.detect_frameworks(all_imports)

    framework_dicts = [{"name": fw.name, "modules": fw.modules} for fw in frameworks]

    # ── Second pass: data-flow primitives ─────────────────────────────

    by_function: dict[str, dict[str, list[str]]] = defaultdict(
        lambda: {"entries": [], "sanitizers": [], "sinks": []}
    )
    node_index: dict[tuple[str, int, str], str] = {}

    # Collect raw primitives for the bridge builder.
    entry_point_infos: list[dict[str, Any]] = []
    sink_infos: list[dict[str, Any]] = []
    sanitizer_infos: list[dict[str, Any]] = []
    import_infos: list[dict[str, Any]] = []

    # Record import info from the first pass.
    for imp in all_imports:
        import_infos.append({
            "module": imp.module,
            "file": str(imp.file) if imp.file else None,
            "line": imp.line,
            "is_from": imp.is_from,
            "names": imp.names,
        })

    for file_path, tree in file_trees:
        plugin = registry.for_extension(file_path.suffix)
        if plugin is None:
            continue

        entry_points = plugin.detect_entry_points(tree, file_path)
        sinks = plugin.detect_sinks(tree, file_path, frameworks=frameworks)
        sanitizers = plugin.detect_sanitizers(tree, file_path)

        for ep in entry_points:
            sid = next_id("entry")
            find_and_annotate(ep.file, ep.line, "entry_point", ep.name, sid)
            node_index[(str(ep.file), ep.line, ep.name)] = sid
            if ep.function is not None:
                by_function[ep.function]["entries"].append(sid)
            elif ep.kind in ("http_handler", "graphql_resolver"):
                by_function[ep.name]["entries"].append(sid)
            info: dict[str, Any] = {
                "_ann_id": sid,
                "name": ep.name, "kind": ep.kind,
                "file": str(ep.file) if ep.file else None,
                "line": ep.line, "function": ep.function,
            }
            if ep.param_type_annotations:
                info["param_type_annotations"] = ep.param_type_annotations
            entry_point_infos.append(info)

        for si in sinks:
            sid = next_id("sink")
            find_and_annotate(si.file, si.line, "sink", si.name, sid)
            node_index[(str(si.file), si.line, si.name)] = sid
            if si.function is not None:
                by_function[si.function]["sinks"].append(sid)
            else:
                # Module-level sink — index by sink name so cross-function
                # edges can still connect.
                by_function[si.name]["sinks"].append(sid)
            sink_infos.append({
                "_ann_id": sid,
                "name": si.name, "kind": si.kind,
                "file": str(si.file) if si.file else None,
                "line": si.line, "function": si.function,
                "cwe_id": si.cwe_id,
            })

        for san in sanitizers:
            sid = next_id("sanitizer")
            find_and_annotate(san.file, san.line, "sanitizer", san.name, sid)
            node_index[(str(san.file), san.line, san.name)] = sid
            if san.function is not None:
                by_function[san.function]["sanitizers"].append(sid)
            else:
                # Module-level sanitizer — index by name for cross-function
                # edge connectivity.
                by_function[san.name]["sanitizers"].append(sid)
            sanitizer_infos.append({
                "_ann_id": sid,
                "name": san.name, "kind": san.kind,
                "file": str(san.file) if san.file else None,
                "line": san.line, "function": san.function,
            })

    # ── Third pass: auth guards ───────────────────────────────────────

    guard_by_function: dict[str, list[str]] = defaultdict(list)
    auth_guard_infos: list[dict[str, Any]] = []
    for file_path, tree in file_trees:
        plugin = registry.for_extension(file_path.suffix)
        if plugin is None:
            continue
        guards = plugin.detect_auth_guards(tree, file_path, frameworks=frameworks)
        for guard in guards:
            sid = next_id("guard")
            find_and_annotate(guard.file, guard.line, "auth_guard", guard.name, sid)
            if guard.function is not None:
                guard_by_function[guard.function].append(sid)
            auth_guard_infos.append({
                "_ann_id": sid,
                "name": guard.name, "kind": guard.kind,
                "guard_type": guard.guard_type,
                "file": str(guard.file) if guard.file else None,
                "line": guard.line, "function": guard.function,
                "framework": guard.framework,
            })

    return {
        "frameworks": framework_dicts,
        "node_index": node_index,
        "by_function": dict(by_function),
        "guard_by_function": dict(guard_by_function),
        "entry_points": entry_point_infos,
        "sinks": sink_infos,
        "sanitizers": sanitizer_infos,
        "imports": import_infos,
        "auth_guards": auth_guard_infos,
        "_all_imports": all_imports,
    }
