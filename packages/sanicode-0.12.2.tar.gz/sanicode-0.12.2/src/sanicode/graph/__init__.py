"""Graph subpackage — knowledge graph construction, querying, and LLM reasoning."""

from sanicode.graph.annotator import annotate_security
from sanicode.graph.bridge import CpgBridge
from sanicode.graph.builder import KnowledgeGraph
from sanicode.graph.domain import (
    DomainClassification,
    DomainReachabilityResult,
    PruningClassification,
    PruningPlan,
    build_pruning_plan,
    classify_by_domain,
    reconcile_domain_tags,
)
from sanicode.graph.overlays import build_security_overlays
from sanicode.graph.query import GraphQueryHelper, NodeInfo
from sanicode.graph.reasoning import (
    GraphAssessment,
    ThreatPath,
    assess_threat_paths,
    collect_code_snippets,
    extract_threat_paths,
    parse_assessment_response,
    serialize_path_for_llm,
)

__all__ = [
    "KnowledgeGraph",
    "CpgBridge",
    "annotate_security",
    "build_security_overlays",
    "GraphQueryHelper",
    "NodeInfo",
    "DomainClassification",
    "DomainReachabilityResult",
    "PruningClassification",
    "PruningPlan",
    "build_pruning_plan",
    "classify_by_domain",
    "reconcile_domain_tags",
    "GraphAssessment",
    "ThreatPath",
    "assess_threat_paths",
    "collect_code_snippets",
    "extract_threat_paths",
    "parse_assessment_response",
    "serialize_path_for_llm",
]
