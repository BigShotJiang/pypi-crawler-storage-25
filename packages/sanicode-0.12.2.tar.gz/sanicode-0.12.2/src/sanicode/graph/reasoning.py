"""LLM reasoning over the knowledge graph.

Serializes threat paths from the knowledge graph into a format the LLM
can reason about, then parses responses to produce structured assessments.

The main public entry point is :func:`assess_threat_paths`, which extracts
entry-to-sink paths from the knowledge graph, serializes them, sends them to
the reasoning LLM in batches, and returns :class:`GraphAssessment` objects.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from sanicode.graph.builder import KnowledgeGraph
    from sanicode.llm.client import LLMClient

_log = logging.getLogger(__name__)

# Maximum number of paths to send in a single LLM request.
# Keeps prompt size manageable while reducing the number of API calls.
_BATCH_SIZE = 5


@dataclass
class ThreatPath:
    """A path through the knowledge graph from an entry point to a sink."""

    path_id: str
    entry_node: dict  # node attrs: label, kind, file, line, function, …
    sink_node: dict
    intermediates: list[dict] = field(default_factory=list)
    # Confidence labels on each edge along the path.
    # E.g. ["taint_analysis", "heuristic"] for a two-edge path.
    edge_confidences: list[str] = field(default_factory=list)
    is_sanitized: bool = False


@dataclass
class GraphAssessment:
    """LLM assessment of a single threat path."""

    path_id: str
    risk_level: str  # "critical" | "high" | "medium" | "low" | "none"
    is_exploitable: bool
    reasoning: str
    recommended_fix: str
    confidence: float


@dataclass
class PathExtractionResult:
    """Result of extracting threat paths from the knowledge graph."""

    paths: list[ThreatPath]
    truncated_pairs: list[tuple[str, str]]  # (entry_id, sink_id)
    cutoff_used: int


# ---------------------------------------------------------------------------
# Path extraction
# ---------------------------------------------------------------------------


def extract_threat_paths(kg: KnowledgeGraph, cutoff: int = 10) -> PathExtractionResult:
    """Extract entry-to-sink data flow paths from the knowledge graph.

    Uses NetworkX's ``all_simple_paths`` to enumerate paths from every
    entry_point node to every sink node.  Paths are capped at ``cutoff``
    nodes deep to avoid combinatorial explosion in large graphs.

    When no path is found within the cutoff but a longer path exists,
    the ``(entry_id, sink_id)`` pair is recorded in
    :attr:`PathExtractionResult.truncated_pairs` and a warning is logged.

    Intermediate nodes on each path are examined for ``kind="sanitizer"``
    to set :attr:`ThreatPath.is_sanitized`.

    Args:
        kg: A populated :class:`~sanicode.graph.builder.KnowledgeGraph`.
        cutoff: Maximum path depth passed to ``nx.all_simple_paths``.
            Defaults to 10.

    Returns:
        :class:`PathExtractionResult` containing deduplicated
        :class:`ThreatPath` objects, any truncated entry/sink pairs, and
        the cutoff value used.  ``paths`` is empty if the graph has no
        entry points or no sinks.
    """
    entry_ids = [nid for nid, attrs in kg.all_nodes() if attrs.get("kind") == "entry_point"]
    sink_ids = [nid for nid, attrs in kg.all_nodes() if attrs.get("kind") == "sink"]

    if not entry_ids or not sink_ids:
        return PathExtractionResult(paths=[], truncated_pairs=[], cutoff_used=cutoff)

    paths: list[ThreatPath] = []
    path_counter = 0
    truncated_pairs: list[tuple[str, str]] = []

    for entry_id in entry_ids:
        for sink_id in sink_ids:
            if entry_id == sink_id:
                continue
            try:
                simple_paths = kg.all_simple_paths(entry_id, sink_id, cutoff=cutoff)
            except (KeyError, ValueError):
                continue

            for node_sequence in simple_paths:
                path_counter += 1
                path_id = f"path_{path_counter}"

                entry_attrs = dict(kg.node_data(node_sequence[0]))
                sink_attrs = dict(kg.node_data(node_sequence[-1]))

                intermediate_attrs: list[dict] = []
                edge_confidences: list[str] = []
                has_sanitizer = False

                for i, nid in enumerate(node_sequence):
                    # Collect intermediate nodes (everything except entry and sink).
                    if i > 0 and i < len(node_sequence) - 1:
                        node_attrs = dict(kg.node_data(nid))
                        intermediate_attrs.append(node_attrs)
                        if node_attrs.get("kind") == "sanitizer":
                            has_sanitizer = True

                    # Collect edge confidence labels.
                    if i < len(node_sequence) - 1:
                        edge_data = kg.edge_data(nid, node_sequence[i + 1])
                        edge_confidences.append(edge_data.get("confidence", "heuristic"))
                        # Also check if the edge itself is marked as sanitized.
                        if edge_data.get("sanitized", False):
                            has_sanitizer = True

                paths.append(
                    ThreatPath(
                        path_id=path_id,
                        entry_node=entry_attrs,
                        sink_node=sink_attrs,
                        intermediates=intermediate_attrs,
                        edge_confidences=edge_confidences,
                        is_sanitized=has_sanitizer,
                    )
                )

            if not simple_paths:
                # No path within cutoff — check if a longer path exists.
                try:
                    if kg.has_path(entry_id, sink_id):
                        truncated_pairs.append((entry_id, sink_id))
                        _log.warning(
                            "Graph path depth cutoff (%d) truncated path from %s to %s",
                            cutoff,
                            entry_id,
                            sink_id,
                        )
                except (KeyError, ValueError):
                    pass

    return PathExtractionResult(paths=paths, truncated_pairs=truncated_pairs, cutoff_used=cutoff)


# ---------------------------------------------------------------------------
# Serialization
# ---------------------------------------------------------------------------


def serialize_path_for_llm(
    path: ThreatPath,
    code_snippets: dict[str, str] | None = None,
) -> str:
    """Convert a :class:`ThreatPath` to a human-readable text block.

    The output is structured text (not JSON) so that the LLM can reason
    about it in natural language before producing a JSON response.

    Args:
        path: The threat path to serialize.
        code_snippets: Optional mapping of ``"file:line"`` to code text,
            included inline when available.

    Returns:
        A multi-line string describing the path.
    """
    lines: list[str] = [f"--- {path.path_id} ---"]

    def _node_desc(attrs: dict) -> str:
        label = attrs.get("label", "<unknown>")
        kind = attrs.get("kind", "unknown")
        file_ = attrs.get("file") or ""
        line_ = attrs.get("line")
        fn = attrs.get("function") or ""
        loc = f"{file_}:{line_}" if file_ and line_ else file_ or ""
        fn_part = f" in {fn}()" if fn else ""
        return f"{label} [{kind}] @ {loc}{fn_part}" if loc else f"{label} [{kind}]{fn_part}"

    lines.append(f"Entry: {_node_desc(path.entry_node)}")

    entry_loc = _snippet_key(path.entry_node)
    if code_snippets and entry_loc and entry_loc in code_snippets:
        lines.append(f"  Code:\n{_indent(code_snippets[entry_loc])}")

    for i, mid in enumerate(path.intermediates):
        confidence = path.edge_confidences[i] if i < len(path.edge_confidences) else "?"
        lines.append(f"  -> {_node_desc(mid)} [edge: {confidence}]")
        mid_loc = _snippet_key(mid)
        if code_snippets and mid_loc and mid_loc in code_snippets:
            lines.append(f"     Code:\n{_indent(code_snippets[mid_loc])}")

    last_edge = path.edge_confidences[-1] if path.edge_confidences else "?"
    lines.append(f"  -> Sink: {_node_desc(path.sink_node)} [edge: {last_edge}]")

    sink_loc = _snippet_key(path.sink_node)
    if code_snippets and sink_loc and sink_loc in code_snippets:
        lines.append(f"     Code:\n{_indent(code_snippets[sink_loc])}")

    sanitized_flag = "YES" if path.is_sanitized else "NO"
    lines.append(f"Sanitized on path: {sanitized_flag}")

    if path.sink_node.get("cwe_id"):
        lines.append(f"CWE: {path.sink_node['cwe_id']}")

    return "\n".join(lines)


def _snippet_key(attrs: dict) -> str | None:
    """Build the ``"file:line"`` lookup key for a node's code snippet."""
    file_ = attrs.get("file")
    line_ = attrs.get("line")
    if file_ and line_ is not None:
        return f"{file_}:{line_}"
    return None


def _indent(text: str, prefix: str = "    ") -> str:
    return "\n".join(prefix + ln for ln in text.splitlines())


# ---------------------------------------------------------------------------
# LLM assessment
# ---------------------------------------------------------------------------


def assess_threat_paths(
    llm: LLMClient,
    paths: list[ThreatPath],
    code_snippets: dict[str, str] | None = None,
) -> list[GraphAssessment]:
    """Send threat paths to the reasoning LLM for exploitability assessment.

    Paths are sent in batches of :data:`_BATCH_SIZE` to keep prompt sizes
    reasonable.  Any batch that fails (network error, bad JSON, etc.) is
    logged and skipped — we never raise from here, treating LLM failures as
    non-fatal.

    Args:
        llm: Configured :class:`~sanicode.llm.client.LLMClient`.
        paths: Threat paths extracted from the knowledge graph.
        code_snippets: Optional ``"file:line"`` → code snippet mapping.

    Returns:
        List of :class:`GraphAssessment` objects.  Returns an empty list when
        the reasoning tier is not configured or when ``paths`` is empty.
    """
    # Import here to avoid circular imports at module level.
    from sanicode.llm.client import LLMNotConfiguredError  # noqa: PLC0415
    from sanicode.llm.prompts import render_prompt  # noqa: PLC0415

    if not llm.has_tier("reasoning"):
        _log.debug("Graph reasoning skipped: reasoning tier not configured")
        return []

    if not paths:
        return []

    assessments: list[GraphAssessment] = []

    for batch_start in range(0, len(paths), _BATCH_SIZE):
        batch = paths[batch_start : batch_start + _BATCH_SIZE]
        batch_ids = [p.path_id for p in batch]

        serialized_parts = [serialize_path_for_llm(p, code_snippets) for p in batch]
        paths_text = "\n\n".join(serialized_parts)

        try:
            prompt = render_prompt("graph_reason", paths=paths_text)
            response = llm.reason(prompt)
            batch_assessments = parse_assessment_response(response.content, batch_ids)
            assessments.extend(batch_assessments)
            _log.info(
                "Graph reasoning: assessed batch of %d paths (%d returned)",
                len(batch),
                len(batch_assessments),
            )
        except LLMNotConfiguredError:
            _log.debug("Graph reasoning skipped mid-run: reasoning tier disappeared")
            break
        except Exception as exc:
            _log.warning(
                "Graph reasoning failed for batch %s: %s",
                batch_ids,
                exc,
            )
            # Emit stub assessments so callers know the paths exist.
            for path in batch:
                assessments.append(
                    GraphAssessment(
                        path_id=path.path_id,
                        risk_level="review",
                        is_exploitable=False,
                        reasoning=f"Assessment failed: {exc}",
                        recommended_fix="",
                        confidence=0.0,
                    )
                )

    return assessments


@dataclass
class AuthAssessment:
    """LLM assessment of an unguarded endpoint."""

    endpoint_id: str
    is_intentionally_public: bool
    risk_level: str  # "critical" | "high" | "medium" | "low" | "none"
    cwe_id: int  # 306 or 862
    reasoning: str
    recommended_fix: str
    confidence: float


def serialize_endpoint_for_llm(node_id: str, attrs: dict) -> str:
    """Convert an unguarded entry point to a text block for the LLM."""
    label = attrs.get("label", "<unknown>")
    file_ = attrs.get("file") or ""
    line_ = attrs.get("line")
    fn = attrs.get("function") or ""
    loc = f"{file_}:{line_}" if file_ and line_ else file_ or ""
    fn_part = f" in {fn}()" if fn else ""
    return f"--- {node_id} ---\nEndpoint: {label}{fn_part}\nLocation: {loc}"


def assess_unguarded_endpoints(
    llm: LLMClient,
    kg: KnowledgeGraph,
    code_snippets: dict[str, str] | None = None,
) -> list[AuthAssessment]:
    """Send unguarded endpoints to the LLM for assessment.

    Calls ``kg.unguarded_entry_points()`` to find HTTP handlers without
    auth guards, serializes them, and sends to the reasoning tier.

    Args:
        llm: Configured LLMClient.
        kg: A populated KnowledgeGraph with auth guard detection.
        code_snippets: Optional ``"file:line"`` → code snippet mapping.

    Returns:
        List of AuthAssessment objects. Empty if the reasoning tier
        is not configured or no unguarded endpoints exist.
    """
    from sanicode.llm.client import LLMNotConfiguredError  # noqa: PLC0415
    from sanicode.llm.prompts import render_prompt  # noqa: PLC0415

    if not llm.has_tier("reasoning"):
        _log.debug("Auth reasoning skipped: reasoning tier not configured")
        return []

    unguarded = kg.unguarded_entry_points()
    if not unguarded:
        return []

    assessments: list[AuthAssessment] = []

    for batch_start in range(0, len(unguarded), _BATCH_SIZE):
        batch = unguarded[batch_start : batch_start + _BATCH_SIZE]
        batch_ids = [nid for nid, _ in batch]

        parts = []
        for node_id, attrs in batch:
            text = serialize_endpoint_for_llm(node_id, attrs)
            snippet_key = _snippet_key(attrs)
            if code_snippets and snippet_key and snippet_key in code_snippets:
                text += f"\nCode:\n{_indent(code_snippets[snippet_key])}"
            parts.append(text)

        endpoints_text = "\n\n".join(parts)

        try:
            prompt = render_prompt("auth_reason", endpoints=endpoints_text)
            response = llm.reason(prompt)
            batch_assessments = parse_auth_assessment_response(
                response.content, batch_ids
            )
            assessments.extend(batch_assessments)
            _log.info(
                "Auth reasoning: assessed batch of %d endpoints (%d returned)",
                len(batch),
                len(batch_assessments),
            )
        except LLMNotConfiguredError:
            _log.debug("Auth reasoning skipped mid-run: reasoning tier disappeared")
            break
        except Exception as exc:
            _log.warning(
                "Auth reasoning failed for batch %s: %s",
                batch_ids,
                exc,
            )
            for node_id, _ in batch:
                assessments.append(
                    AuthAssessment(
                        endpoint_id=node_id,
                        is_intentionally_public=False,
                        risk_level="review",
                        cwe_id=306,
                        reasoning=f"Assessment failed: {exc}",
                        recommended_fix="",
                        confidence=0.0,
                    )
                )

    return assessments


def parse_auth_assessment_response(
    response_text: str,
    endpoint_ids: list[str],
) -> list[AuthAssessment]:
    """Parse the LLM's JSON response into AuthAssessment objects.

    Tolerates minor formatting issues: strips markdown fences if present,
    and falls back gracefully when the JSON is malformed or incomplete.

    Args:
        response_text: Raw text returned by the LLM.
        endpoint_ids: Expected endpoint IDs, used for fallback when parsing fails.

    Returns:
        List of AuthAssessment objects.  If the entire response
        fails to parse, returns a stub "review" assessment for each endpoint_id.
    """
    from sanicode.llm.client import repair_json

    _VALID_RISK_LEVELS = frozenset({"critical", "high", "medium", "low", "none", "review"})

    try:
        data = repair_json(response_text)
    except (json.JSONDecodeError, ValueError) as exc:
        _log.warning("Auth reasoning: could not parse response as JSON: %s", exc)
        return _stub_auth_assessments(endpoint_ids, f"JSON parse error: {exc}")

    if not isinstance(data, list):
        _log.warning("Auth reasoning: expected JSON array, got %s", type(data).__name__)
        return _stub_auth_assessments(endpoint_ids, "Response was not a JSON array")

    assessments: list[AuthAssessment] = []
    for item in data:
        if not isinstance(item, dict):
            continue
        risk = item.get("risk_level", "review").lower()
        if risk not in _VALID_RISK_LEVELS:
            risk = "review"
        try:
            confidence = float(item.get("confidence", 0.0))
        except (TypeError, ValueError):
            confidence = 0.0
        confidence = max(0.0, min(1.0, confidence))

        cwe_id = item.get("cwe_id", 306)
        if cwe_id not in (306, 862):
            cwe_id = 306

        assessments.append(
            AuthAssessment(
                endpoint_id=str(item.get("endpoint_id", "")),
                is_intentionally_public=bool(item.get("is_intentionally_public", False)),
                risk_level=risk,
                cwe_id=cwe_id,
                reasoning=str(item.get("reasoning", "")),
                recommended_fix=str(item.get("recommended_fix", "")),
                confidence=confidence,
            )
        )

    return assessments


def _stub_auth_assessments(endpoint_ids: list[str], reason: str) -> list[AuthAssessment]:
    """Return placeholder assessments when the LLM response cannot be parsed."""
    return [
        AuthAssessment(
            endpoint_id=eid,
            is_intentionally_public=False,
            risk_level="review",
            cwe_id=306,
            reasoning=reason,
            recommended_fix="",
            confidence=0.0,
        )
        for eid in endpoint_ids
    ]


def parse_assessment_response(
    response_text: str,
    path_ids: list[str],
) -> list[GraphAssessment]:
    """Parse the LLM's JSON response into :class:`GraphAssessment` objects.

    Tolerates minor formatting issues: strips markdown fences if present,
    and falls back gracefully when the JSON is malformed or incomplete.

    Args:
        response_text: Raw text returned by the LLM.
        path_ids: Expected path IDs, used for fallback when parsing fails.

    Returns:
        List of :class:`GraphAssessment` objects.  If the entire response
        fails to parse, returns a stub "review" assessment for each path_id.
    """
    from sanicode.llm.client import repair_json

    _VALID_RISK_LEVELS = frozenset({"critical", "high", "medium", "low", "none", "review"})

    try:
        data = repair_json(response_text)
    except (json.JSONDecodeError, ValueError) as exc:
        _log.warning("Graph reasoning: could not parse LLM response as JSON: %s", exc)
        return _stub_assessments(path_ids, f"JSON parse error: {exc}")

    if not isinstance(data, list):
        _log.warning(
            "Graph reasoning: expected JSON array, got %s", type(data).__name__
        )
        return _stub_assessments(path_ids, "Response was not a JSON array")

    assessments: list[GraphAssessment] = []
    for item in data:
        if not isinstance(item, dict):
            continue
        risk = item.get("risk_level", "review").lower()
        if risk not in _VALID_RISK_LEVELS:
            risk = "review"

        try:
            confidence = float(item.get("confidence", 0.0))
        except (TypeError, ValueError):
            confidence = 0.0
        confidence = max(0.0, min(1.0, confidence))

        assessments.append(
            GraphAssessment(
                path_id=str(item.get("path_id", "")),
                risk_level=risk,
                is_exploitable=bool(item.get("is_exploitable", False)),
                reasoning=str(item.get("reasoning", "")),
                recommended_fix=str(item.get("recommended_fix", "")),
                confidence=confidence,
            )
        )

    return assessments


def _stub_assessments(path_ids: list[str], reason: str) -> list[GraphAssessment]:
    """Return placeholder assessments when the LLM response cannot be parsed."""
    return [
        GraphAssessment(
            path_id=pid,
            risk_level="review",
            is_exploitable=False,
            reasoning=reason,
            recommended_fix="",
            confidence=0.0,
        )
        for pid in path_ids
    ]


# ---------------------------------------------------------------------------
# Code snippet collection (utility for callers)
# ---------------------------------------------------------------------------


def collect_code_snippets(
    paths: list[ThreatPath],
    context_lines: int = 3,
) -> dict[str, str]:
    """Read code snippets for all nodes in the given threat paths.

    Produces a mapping of ``"file:line"`` → snippet text that can be passed
    to :func:`serialize_path_for_llm` / :func:`assess_threat_paths`.

    Args:
        paths: Threat paths whose nodes need code context.
        context_lines: Lines of context before and after the node's line.

    Returns:
        Dict mapping ``"file:line"`` keys to snippet strings.  Keys that
        cannot be read (missing files, decode errors) are silently omitted.
    """
    needed: set[tuple[str, int]] = set()

    def _collect_node(attrs: dict) -> None:
        file_ = attrs.get("file")
        line_ = attrs.get("line")
        if file_ and line_ is not None:
            needed.add((file_, int(line_)))

    for path in paths:
        _collect_node(path.entry_node)
        _collect_node(path.sink_node)
        for mid in path.intermediates:
            _collect_node(mid)

    snippets: dict[str, str] = {}
    for file_str, line_num in needed:
        key = f"{file_str}:{line_num}"
        try:
            content = Path(file_str).read_text(encoding="utf-8").splitlines()
            start = max(0, line_num - context_lines - 1)
            end = min(len(content), line_num + context_lines)
            numbered = [f"{i + 1:4d} | {content[i]}" for i in range(start, end)]
            snippets[key] = "\n".join(numbered)
        except (OSError, UnicodeDecodeError):
            pass

    return snippets
