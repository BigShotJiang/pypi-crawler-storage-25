"""Domain reachability analysis for the knowledge graph.

Classifies every graph node by which domains can reach it, supporting
three configurable strategies for handling unclassified entry points:
  - conservative: unclassified-reachable nodes are treated as shared
  - strict: unclassified-reachable nodes are excluded (stay as-is)
  - report-only: no reclassification, both outcomes recorded
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field

from sanicode.compliance.enrichment import EnrichedFinding  # noqa: TC001
from sanicode.graph.builder import KnowledgeGraph  # noqa: TC001

# Confidence hierarchy: higher index = higher confidence.
_CONFIDENCE_RANK = {
    "heuristic": 0,
    "call_graph": 1,
    "taint_analysis": 2,
    "interprocedural_taint": 2,
}

# Maximum representative paths stored per domain per node.
_MAX_PATHS_PER_DOMAIN = 3


@dataclass
class DomainClassification:
    """Classification of a single graph node by domain reachability."""

    node_id: str
    node_attrs: dict
    domains: set[str] = field(default_factory=set)
    # One of: "exclusive" | "shared" | "unreachable" | "unclassified_reachable"
    classification: str = "unreachable"
    exclusive_domain: str | None = None
    confidence: str = "low"  # "high" | "medium" | "low"
    paths_by_domain: dict[str, list[list[str]]] = field(default_factory=dict)


@dataclass
class DomainReachabilityResult:
    """Result of domain reachability analysis over the entire graph."""

    strategy: str
    domain_entry_points: dict[str, list[str]] = field(default_factory=dict)
    unclassified_entry_points: list[str] = field(default_factory=list)
    classifications: dict[str, DomainClassification] = field(default_factory=dict)
    exclusive_counts: dict[str, int] = field(default_factory=dict)
    shared_count: int = 0
    unreachable_count: int = 0
    unclassified_reachable_count: int = 0


@dataclass
class PruningClassification:
    """Classification of a single node in a pruning plan."""

    node_id: str
    node_attrs: dict
    category: str  # "safe_to_prune" | "needs_analysis"
    domain: str
    shared_with: list[str] = field(default_factory=list)
    confidence: str = "low"
    backward_paths: list[list[str]] = field(default_factory=list)
    relationship_type: str = ""   # "direct_dependency" | "transitive_dependency"
    suggested_action: str = ""


@dataclass
class PruningPlan:
    """Result of pruning plan analysis for a domain removal."""

    remove_domain: str
    strategy: str
    safe_to_prune: list[PruningClassification] = field(default_factory=list)
    needs_analysis: list[PruningClassification] = field(default_factory=list)
    safe_to_keep_count: int = 0
    total_nodes: int = 0
    content_policy_matches: list = field(default_factory=list)  # list[Finding]


def reconcile_domain_tags(
    kg: KnowledgeGraph,
    findings: list[EnrichedFinding],
) -> None:
    """Bridge domain tags from findings to knowledge graph entry-point nodes.

    Matches findings to entry_point nodes by exact (file, line), then by
    function-name fallback. Sets node["domain"] attribute on matching
    entry points.

    Args:
        kg: The knowledge graph whose entry-point nodes will be tagged.
        findings: Enriched findings carrying domain classification data.
    """
    # Build index of entry points by (file, line) and by label.
    ep_by_file_line: dict[tuple[str, int], str] = {}
    ep_by_label: dict[str, str] = {}
    for node_id, attrs in kg.nodes_by_kind("entry_point"):
        file_val = attrs.get("file")
        line_val = attrs.get("line")
        if file_val is not None and line_val is not None:
            ep_by_file_line[(str(file_val), int(line_val))] = node_id
        label = attrs.get("label")
        if label:
            ep_by_label[label] = node_id

    for finding in findings:
        if not finding.domain:
            continue
        # Exact (file, line) match.
        key = (str(finding.file), finding.line)
        node_id = ep_by_file_line.get(key)
        # Fallback: function name match via rule_id suffix or message.
        if node_id is None:
            for label, nid in ep_by_label.items():
                if label in finding.message or label in finding.rule_id:
                    node_id = nid
                    break
        if node_id is not None:
            kg.set_node_attr(node_id, "domain", finding.domain)


def _confidence_label(rank: int) -> str:
    """Map a numeric confidence rank to a label."""
    if rank >= 2:
        return "high"
    if rank >= 1:
        return "medium"
    return "low"


_REL_DIRECT = "direct_dependency"
_REL_TRANSITIVE = "transitive_dependency"


def _suggested_action(node_attrs: dict, has_backward_paths: bool, is_shared: bool) -> str:
    """Generate a suggested action string for a needs-analysis node."""
    kind = node_attrs.get("kind", "")
    if kind == "sanitizer":
        return "Review sanitizer coverage for retained domains"
    if kind == "sink":
        return "Verify sink is still needed by retained domains"
    if kind == "entry_point":
        return "Check if entry point serves retained domains"
    if is_shared and has_backward_paths:
        return "Consider factoring out domain-specific branches"
    return "Review for domain-specific logic"


def _bfs_forward(
    kg: KnowledgeGraph,
    start_nodes: list[str],
) -> tuple[set[str], dict[str, int], dict[str, list[list[str]]]]:
    """BFS forward from start_nodes, collecting reachable nodes and representative paths.

    Each path's confidence is its weakest edge. When multiple paths reach the
    same node, the one with the highest minimum-edge confidence is preferred.

    Args:
        kg: The knowledge graph to traverse.
        start_nodes: Node IDs to begin BFS from.

    Returns:
        Tuple of (reachable_node_ids, node_confidence_rank, paths_by_node).
        node_confidence_rank maps node_id -> highest confidence rank across all
        reaching paths.
        paths_by_node maps node_id -> list of paths (each path is a list of node IDs).
    """
    reachable: set[str] = set()
    node_confidence: dict[str, int] = {}
    paths_by_node: dict[str, list[list[str]]] = {}

    queue: deque[tuple[str, int, list[str]]] = deque()
    for start in start_nodes:
        reachable.add(start)
        node_confidence[start] = 2  # entry points get high confidence
        paths_by_node[start] = [[start]]
        queue.append((start, 2, [start]))

    while queue:
        current, path_min_conf, path = queue.popleft()
        for successor in kg.successors(current):
            edge_data = kg.edge_data(current, successor)
            edge_conf_str = edge_data.get("confidence", "heuristic")
            edge_conf = _CONFIDENCE_RANK.get(edge_conf_str, 0)
            new_path_conf = min(path_min_conf, edge_conf)
            new_path = path + [successor]

            prev_conf = node_confidence.get(successor, -1)
            is_new = successor not in reachable

            if is_new or new_path_conf > prev_conf:
                reachable.add(successor)
                node_confidence[successor] = max(prev_conf, new_path_conf)

                # Store representative paths (capped at _MAX_PATHS_PER_DOMAIN).
                if successor not in paths_by_node:
                    paths_by_node[successor] = []
                if len(paths_by_node[successor]) < _MAX_PATHS_PER_DOMAIN:
                    paths_by_node[successor].append(new_path)

                if is_new:
                    queue.append((successor, new_path_conf, new_path))

    return reachable, node_confidence, paths_by_node


def _bfs_backward(
    kg: KnowledgeGraph,
    start_nodes: list[str],
) -> tuple[set[str], dict[str, int], dict[str, list[list[str]]]]:
    """BFS backward from start_nodes via predecessors, collecting reachable nodes and paths.

    Mirrors _bfs_forward but traverses edges in reverse. Used to discover
    utility code feeding into a set of nodes (e.g., exclusive nodes in a
    pruning plan).

    Args:
        kg: The knowledge graph to traverse.
        start_nodes: Node IDs to begin backward BFS from.

    Returns:
        Tuple of (reachable_node_ids, node_confidence_rank, paths_by_node).
    """
    reachable: set[str] = set()
    node_confidence: dict[str, int] = {}
    paths_by_node: dict[str, list[list[str]]] = {}

    queue: deque[tuple[str, int, list[str]]] = deque()
    for start in start_nodes:
        reachable.add(start)
        node_confidence[start] = 2
        paths_by_node[start] = [[start]]
        queue.append((start, 2, [start]))

    while queue:
        current, path_min_conf, path = queue.popleft()
        for predecessor in kg.predecessors(current):
            edge_data = kg.edge_data(predecessor, current)
            edge_conf_str = edge_data.get("confidence", "heuristic")
            edge_conf = _CONFIDENCE_RANK.get(edge_conf_str, 0)
            new_path_conf = min(path_min_conf, edge_conf)
            new_path = path + [predecessor]

            prev_conf = node_confidence.get(predecessor, -1)
            is_new = predecessor not in reachable

            if is_new or new_path_conf > prev_conf:
                reachable.add(predecessor)
                node_confidence[predecessor] = max(prev_conf, new_path_conf)

                if predecessor not in paths_by_node:
                    paths_by_node[predecessor] = []
                if len(paths_by_node[predecessor]) < _MAX_PATHS_PER_DOMAIN:
                    paths_by_node[predecessor].append(new_path)

                if is_new:
                    queue.append((predecessor, new_path_conf, new_path))

    return reachable, node_confidence, paths_by_node


def classify_by_domain(
    kg: KnowledgeGraph,
    strategy: str = "conservative",
    requested_domain: str | None = None,
) -> DomainReachabilityResult:
    """Classify every graph node by which domains can reach it.

    Entry points must have a ``domain`` attribute (set by
    :func:`reconcile_domain_tags`) for their reachability to be domain-specific.
    Entry points without a domain are considered "unclassified" and handled
    according to the chosen strategy.

    Args:
        kg: The knowledge graph to analyze.
        strategy: How to handle nodes only reachable from unclassified entry points.
            "conservative" - treat unclassified-reachable nodes as shared.
            "strict" - leave them as "unclassified_reachable" (excluded from domains).
            "report-only" - no reclassification; record both possible outcomes.
        requested_domain: If set, only analyze entry points for this domain.
            Other domain entry points are ignored during BFS.

    Returns:
        DomainReachabilityResult with a classification for every node in the graph.
    """
    result = DomainReachabilityResult(strategy=strategy)

    # 1. Partition entry points by domain attribute.
    domain_eps: dict[str, list[str]] = {}
    unclassified_eps: list[str] = []

    for node_id, attrs in kg.nodes_by_kind("entry_point"):
        domain = attrs.get("domain")
        if domain:
            domain_eps.setdefault(domain, []).append(node_id)
        else:
            unclassified_eps.append(node_id)

    result.domain_entry_points = domain_eps
    result.unclassified_entry_points = unclassified_eps

    # Filter to requested domain if specified.
    if requested_domain:
        domain_eps = {d: eps for d, eps in domain_eps.items() if d == requested_domain}

    # 2. BFS forward from each domain's entry points.
    reachable_from: dict[str, set[str]] = {}
    confidence_from: dict[str, dict[str, int]] = {}
    paths_from: dict[str, dict[str, list[list[str]]]] = {}

    for domain, eps in domain_eps.items():
        reachable, conf, paths = _bfs_forward(kg, eps)
        reachable_from[domain] = reachable
        confidence_from[domain] = conf
        paths_from[domain] = paths

    # 3. BFS from unclassified entry points.
    unclassified_reachable: set[str] = set()
    unclassified_conf: dict[str, int] = {}
    if unclassified_eps:
        unclassified_reachable, unclassified_conf, _ = _bfs_forward(kg, unclassified_eps)

    # 4. Classify each node.
    all_nodes = list(kg.all_nodes())
    exclusive_counts: dict[str, int] = {d: 0 for d in domain_eps}
    shared_count = 0
    unreachable_count = 0
    unclassified_reachable_count = 0

    for node_id, attrs in all_nodes:
        reaching_domains = {
            d for d, reachable in reachable_from.items() if node_id in reachable
        }
        in_unclassified = node_id in unclassified_reachable

        # Collect representative paths for this node from each reaching domain.
        node_paths: dict[str, list[list[str]]] = {}
        for d in reaching_domains:
            d_paths = paths_from.get(d, {}).get(node_id, [])
            node_paths[d] = d_paths[:_MAX_PATHS_PER_DOMAIN]

        # Confidence: highest rank across all paths that reach this node.
        max_conf_rank = -1
        for d in reaching_domains:
            d_conf = confidence_from.get(d, {}).get(node_id, 0)
            max_conf_rank = max(max_conf_rank, d_conf)
        if in_unclassified:
            max_conf_rank = max(max_conf_rank, unclassified_conf.get(node_id, 0))

        # Classification logic.
        classification: str
        exclusive_domain: str | None = None

        if not reaching_domains and not in_unclassified:
            classification = "unreachable"
            unreachable_count += 1
        elif in_unclassified and not reaching_domains:
            # Only reachable from unclassified entry points.
            if strategy == "conservative":
                classification = "shared"
                shared_count += 1
            else:
                classification = "unclassified_reachable"
                unclassified_reachable_count += 1
        elif len(reaching_domains) == 1 and not in_unclassified:
            classification = "exclusive"
            exclusive_domain = next(iter(reaching_domains))
            exclusive_counts[exclusive_domain] = exclusive_counts.get(exclusive_domain, 0) + 1
        elif len(reaching_domains) == 1 and in_unclassified:
            # Reachable from one domain AND from unclassified entry points.
            if strategy == "conservative":
                classification = "shared"
                shared_count += 1
            elif strategy == "strict":
                classification = "exclusive"
                exclusive_domain = next(iter(reaching_domains))
                exclusive_counts[exclusive_domain] = exclusive_counts.get(exclusive_domain, 0) + 1
            else:  # report-only
                classification = "exclusive"
                exclusive_domain = next(iter(reaching_domains))
                exclusive_counts[exclusive_domain] = exclusive_counts.get(exclusive_domain, 0) + 1
                unclassified_reachable_count += 1
        else:
            # Multiple domains reach this node.
            classification = "shared"
            shared_count += 1

        conf_label = _confidence_label(max_conf_rank) if max_conf_rank >= 0 else "low"

        result.classifications[node_id] = DomainClassification(
            node_id=node_id,
            node_attrs=dict(attrs),
            domains=reaching_domains,
            classification=classification,
            exclusive_domain=exclusive_domain,
            confidence=conf_label,
            paths_by_domain=node_paths,
        )

    result.exclusive_counts = exclusive_counts
    result.shared_count = shared_count
    result.unreachable_count = unreachable_count
    result.unclassified_reachable_count = unclassified_reachable_count

    return result


def build_pruning_plan(
    kg: KnowledgeGraph,
    remove_domain: str,
    strategy: str = "conservative",
) -> PruningPlan:
    """Build a pruning plan for removing a domain from a deliverable.

    Combines forward domain reachability with backward BFS to identify:
    - safe_to_prune: nodes exclusive to the removed domain (including utility
      code discovered via backward BFS that only feeds exclusive nodes)
    - needs_analysis: shared nodes used by both the removed and retained domains
    - safe_to_keep_count: everything else

    Args:
        kg: The knowledge graph to analyze.
        remove_domain: The domain to remove (e.g. "financial").
        strategy: Unclassified entry point strategy (passed to classify_by_domain).

    Returns:
        PruningPlan with categorized nodes and summary counts.
    """
    # Step 1: Forward reachability.
    forward = classify_by_domain(kg, strategy=strategy)

    plan = PruningPlan(
        remove_domain=remove_domain,
        strategy=strategy,
        total_nodes=len(forward.classifications),
    )

    # Step 2: Collect exclusive and shared nodes for the removed domain.
    exclusive_node_ids: list[str] = []
    classified_ids: set[str] = set()

    for node_id, dc in forward.classifications.items():
        if dc.classification == "exclusive" and dc.exclusive_domain == remove_domain:
            exclusive_node_ids.append(node_id)
            classified_ids.add(node_id)
            plan.safe_to_prune.append(PruningClassification(
                node_id=node_id,
                node_attrs=dc.node_attrs,
                category="safe_to_prune",
                domain=remove_domain,
                confidence=dc.confidence,
            ))
        elif dc.classification == "shared" and remove_domain in dc.domains:
            classified_ids.add(node_id)
            retained = sorted(d for d in dc.domains if d != remove_domain)
            plan.needs_analysis.append(PruningClassification(
                node_id=node_id,
                node_attrs=dc.node_attrs,
                category="needs_analysis",
                domain=remove_domain,
                shared_with=retained,
                confidence=dc.confidence,
                relationship_type=_REL_DIRECT,
                suggested_action=_suggested_action(dc.node_attrs, False, True),
            ))

    # Step 3: Backward BFS from exclusive nodes.
    if exclusive_node_ids:
        backward_reachable, backward_conf, backward_paths = _bfs_backward(
            kg, exclusive_node_ids,
        )

        for node_id in backward_reachable:
            if node_id in classified_ids:
                continue
            classified_ids.add(node_id)

            dc = forward.classifications.get(node_id)
            node_attrs = (
                dc.node_attrs if dc else (kg.node_data(node_id) if kg.has_node(node_id) else {})
            )
            fwd_class = dc.classification if dc else "unreachable"
            conf_rank = backward_conf.get(node_id, 0)
            conf_label = _confidence_label(conf_rank)
            bw_paths = backward_paths.get(node_id, [])

            if fwd_class == "unreachable":
                plan.safe_to_prune.append(PruningClassification(
                    node_id=node_id,
                    node_attrs=node_attrs,
                    category="safe_to_prune",
                    domain=remove_domain,
                    confidence=conf_label,
                    backward_paths=bw_paths,
                ))
            elif fwd_class == "shared" and dc is not None:
                retained = sorted(d for d in dc.domains if d != remove_domain)
                plan.needs_analysis.append(PruningClassification(
                    node_id=node_id,
                    node_attrs=node_attrs,
                    category="needs_analysis",
                    domain=remove_domain,
                    shared_with=retained,
                    confidence=conf_label,
                    backward_paths=bw_paths,
                    relationship_type=_REL_TRANSITIVE,
                    suggested_action=_suggested_action(node_attrs, bool(bw_paths), True),
                ))
            # Exclusive to a different domain → skip (shouldn't be pruned).

    # Step 4: Safe to keep = everything not pruned or needs-analysis.
    plan.safe_to_keep_count = (
        plan.total_nodes - len(plan.safe_to_prune) - len(plan.needs_analysis)
    )

    return plan
