"""Knowledge graph construction for data flow analysis.

Builds a treeloom Code Property Graph from source files, annotates it
with sanicode's security detection results, and constructs taint/heuristic
edges for data flow analysis.
"""

from __future__ import annotations

import logging
import warnings
from pathlib import Path
from typing import Any

from sanicode.graph.bridge import CpgBridge
from sanicode.scanner.registry import get_registry

_log = logging.getLogger(__name__)


class KnowledgeGraph(CpgBridge):
    """Knowledge graph backed by treeloom's Code Property Graph.

    Inherits the full graph API from CpgBridge.  Use from_source() or
    from_parsed() to build a populated graph, or construct directly
    for manual node/edge addition (useful in tests).
    """

    def __init__(self) -> None:
        from treeloom import CodePropertyGraph

        super().__init__(CodePropertyGraph())

    @classmethod
    def from_parsed(
        cls,
        file_trees: list[tuple[Path, Any]],
    ) -> KnowledgeGraph:
        """Build a KnowledgeGraph from pre-parsed ASTs.

        Args:
            file_trees: List of (file_path, parsed_ast) pairs.

        Returns:
            A populated KnowledgeGraph.
        """
        from treeloom import CPGBuilder, TaintLabel, TaintPolicy

        from sanicode.graph.annotator import annotate_security

        # Build treeloom CPG from the same files sanicode already parsed.
        builder = CPGBuilder()
        for file_path, _tree in file_trees:
            builder.add_file(file_path)
        cpg = builder.build()

        # Create KnowledgeGraph wrapping the CPG.
        kg = cls.__new__(cls)
        CpgBridge.__init__(kg, cpg)

        # Run security annotation.
        metadata = annotate_security(cpg, file_trees)
        kg._frameworks = metadata.get("frameworks", [])

        # The annotator assigns its own IDs (entry_1, sink_2, ...) which are
        # referenced in by_function/guard_by_function.  When we register
        # nodes on the bridge, it assigns new IDs.  Build a mapping from
        # annotator IDs -> bridge IDs so the edge-building logic works.
        # Each info dict carries an ``_ann_id`` key for this purpose.
        ann_to_bridge: dict[str, str] = {}

        # Register detected primitives on the bridge.
        for info in metadata.get("entry_points", []):
            ep_extra: dict = {}
            if info.get("param_type_annotations"):
                ep_extra["param_type_annotations"] = info["param_type_annotations"]
            bridge_id = kg.add_entry_point(
                label=info["name"],
                file=Path(info["file"]) if info.get("file") else None,
                line=info.get("line"),
                entry_kind=info.get("kind"),
                function=info.get("function"),
                **ep_extra,
            )
            ann_to_bridge[info["_ann_id"]] = bridge_id

        for info in metadata.get("sinks", []):
            bridge_id = kg.add_sink(
                label=info["name"],
                file=Path(info["file"]) if info.get("file") else None,
                line=info.get("line"),
                cwe_id=info.get("cwe_id"),
                sink_kind=info.get("kind"),
                function=info.get("function"),
            )
            ann_to_bridge[info["_ann_id"]] = bridge_id

        for info in metadata.get("sanitizers", []):
            bridge_id = kg.add_sanitizer(
                label=info["name"],
                file=Path(info["file"]) if info.get("file") else None,
                line=info.get("line"),
                sanitizer_kind=info.get("kind"),
                function=info.get("function"),
            )
            ann_to_bridge[info["_ann_id"]] = bridge_id

        for info in metadata.get("imports", []):
            kg.add_import(
                label=info["module"],
                file=Path(info["file"]) if info.get("file") else None,
                line=info.get("line"),
                is_from=info.get("is_from", False),
                names=info.get("names", []),
            )

        for info in metadata.get("auth_guards", []):
            bridge_id = kg.add_auth_guard(
                label=info["name"],
                file=Path(info["file"]) if info.get("file") else None,
                line=info.get("line"),
                guard_kind=info.get("kind"),
                guard_type=info.get("guard_type"),
                function=info.get("function"),
                framework=info.get("framework", ""),
            )
            ann_to_bridge[info["_ann_id"]] = bridge_id

        # Remap by_function and guard_by_function to use bridge IDs.
        def _remap(ann_id: str) -> str:
            return ann_to_bridge.get(ann_id, ann_id)

        raw_by_function = metadata.get("by_function", {})
        by_function: dict[str, dict[str, list[str]]] = {}
        for fn_name, groups in raw_by_function.items():
            by_function[fn_name] = {
                "entries": [_remap(x) for x in groups.get("entries", [])],
                "sinks": [_remap(x) for x in groups.get("sinks", [])],
                "sanitizers": [_remap(x) for x in groups.get("sanitizers", [])],
            }

        raw_guard_by_function = metadata.get("guard_by_function", {})
        guard_by_function: dict[str, list[str]] = {
            fn: [_remap(x) for x in ids]
            for fn, ids in raw_guard_by_function.items()
        }

        for fn_name, groups in by_function.items():
            guard_ids = guard_by_function.get(fn_name, [])
            for guard_id in guard_ids:
                for entry_id in groups["entries"]:
                    kg.add_guards_edge(guard_id, entry_id)

        # ── 2. Treeloom taint analysis ────────────────────────────────
        #
        # The taint policy must work at the CPG node level, not just
        # sanicode-annotated nodes.  Sanicode annotates *functions* as
        # entry points, but taint sources are their *parameters*.
        # Similarly, sanicode annotates at the sink *line* but the taint
        # engine follows DFG edges from CALL nodes.
        from treeloom import NodeKind as TLNodeKind

        # Pre-compute sets for fast lookup in the hot policy lambdas.
        _entry_node_ids = {
            str(n.id)
            for n in cpg.nodes()
            if cpg.get_annotation(n.id, "sanicode.kind") == "entry_point"
        }
        _sink_lines: set[tuple[str, int]] = set()
        for n in cpg.nodes():
            if cpg.get_annotation(n.id, "sanicode.kind") == "sink":
                if n.location:
                    _sink_lines.add((str(n.location.file), n.location.line))
        _sanitizer_lines: set[tuple[str, int]] = set()
        for n in cpg.nodes():
            if cpg.get_annotation(n.id, "sanicode.kind") == "sanitizer":
                if n.location:
                    _sanitizer_lines.add(
                        (str(n.location.file), n.location.line)
                    )

        # Patterns that indicate user-controlled data in web frameworks.
        _REQUEST_PATTERNS = (
            "request.form", "request.args", "request.cookies",
            "request.data", "request.json", "request.values",
            "request.get_json", "request.headers",
            "request.files", "request.environ",
        )

        def _is_source(node):
            # Direct annotation match.
            if cpg.get_annotation(node.id, "sanicode.kind") == "entry_point":
                return TaintLabel("user_input", node.id)
            # Parameters of entry-point functions are taint sources.
            if node.kind == TLNodeKind.PARAMETER and node.scope:
                if str(node.scope) in _entry_node_ids:
                    return TaintLabel("user_input", node.id)
            # request.form/args/cookies access patterns.
            if node.kind == TLNodeKind.CALL:
                name_lower = node.name.lower()
                for pat in _REQUEST_PATTERNS:
                    if pat in name_lower:
                        return TaintLabel("user_input", node.id)
            return None

        def _is_sink(node):
            if cpg.get_annotation(node.id, "sanicode.kind") == "sink":
                return True
            # CALL nodes at sink lines are sinks (the annotator may have
            # matched a VARIABLE at that line instead of the CALL).
            if node.kind == TLNodeKind.CALL and node.location:
                key = (str(node.location.file), node.location.line)
                if key in _sink_lines:
                    return True
            return False

        def _is_sanitizer(node):
            if cpg.get_annotation(node.id, "sanicode.kind") == "sanitizer":
                return True
            if node.location:
                key = (str(node.location.file), node.location.line)
                if key in _sanitizer_lines:
                    return True
            return False

        policy = TaintPolicy(
            sources=_is_source,
            sinks=_is_sink,
            sanitizers=_is_sanitizer,
            implicit_param_sources=True,
        )
        taint_result = cpg.taint(policy)

        # Map taint results back to sanicode node IDs.  The taint engine
        # may find paths through PARAMETER/CALL nodes that aren't directly
        # in the bridge's ID map, so we also try the scope (parent function)
        # and the (file, line) location index.
        # Build a reverse lookup from (file, line) -> sanicode ID for
        # taint path resolution.
        _file_line_to_sani: dict[tuple[str, int], str] = {}
        for sani_id, attrs in kg._sanicode_attrs.items():
            f = attrs.get("file")
            ln = attrs.get("line")
            if f and ln:
                _file_line_to_sani.setdefault((str(f), ln), sani_id)

        def _resolve_sani_id(cpg_node):
            """Find the sanicode bridge ID for a CPG node."""
            # Direct match via CPG NodeId.
            sid = kg._reverse_map.get(str(cpg_node.id))
            if sid:
                return sid
            # Try parent scope (e.g., PARAMETER -> its FUNCTION).
            if cpg_node.scope:
                sid = kg._reverse_map.get(str(cpg_node.scope))
                if sid:
                    return sid
            # Fall back to (file, line) match against sanicode's own
            # registered nodes.
            if cpg_node.location:
                key = (
                    str(cpg_node.location.file),
                    cpg_node.location.line,
                )
                sid = _file_line_to_sani.get(key)
                if sid:
                    return sid
            # Walk up scope chain to find enclosing entry point.
            # This handles PARAMETER nodes and request.form calls
            # inside functions that sanicode classified as entry points.
            scope = cpg_node.scope
            while scope:
                sid = kg._reverse_map.get(str(scope))
                if sid:
                    return sid
                parent = cpg.node(scope)
                if parent is None:
                    break
                # Also check (file, line) of the scope node.
                if parent.location:
                    pkey = (
                        str(parent.location.file),
                        parent.location.line,
                    )
                    sid = _file_line_to_sani.get(pkey)
                    if sid:
                        return sid
                scope = parent.scope
            return None

        # Cache for on-demand parameter entry nodes created when the
        # taint engine finds paths from implicit parameter sources.
        _param_entry_cache: dict[str, str] = {}

        def _ensure_param_entry(cpg_node) -> str | None:
            """Create an entry node for a parameter's function on demand."""
            from treeloom import NodeKind as _NK

            if cpg_node.kind != _NK.PARAMETER or not cpg_node.scope:
                return None
            scope_key = str(cpg_node.scope)
            if scope_key in _param_entry_cache:
                return _param_entry_cache[scope_key]
            parent = cpg.node(cpg_node.scope)
            if parent is None:
                return None
            fn_name = parent.name
            file_path = (
                Path(str(parent.location.file))
                if parent.location else None
            )
            line = parent.location.line if parent.location else None
            entry_id = kg._register_node(
                "param_entry",
                f"{fn_name}(params)",
                file_path,
                line,
                "entry_point",
                entry_kind="parameter",
                function=fn_name,
            )
            _param_entry_cache[scope_key] = entry_id
            _log.debug(
                "Created taint-driven parameter entry %s for %s",
                entry_id, fn_name,
            )
            return entry_id

        # First pass: resolve sink IDs before creating any param_entry
        # nodes, to prevent scope-chain resolution from finding param
        # entries registered at the enclosing function's line.
        resolved_paths: list[tuple[Any, str | None, str | None]] = []
        for path in taint_result.paths:
            source_sani_id = _resolve_sani_id(path.source)
            sink_sani_id = _resolve_sani_id(path.sink)
            resolved_paths.append((path, source_sani_id, sink_sani_id))

        # Build a lookup from sanicode source/sink IDs to their function
        # name, so we can find co-located sanitizer nodes.
        def _node_function(sani_id: str) -> str | None:
            return kg._sanicode_attrs.get(sani_id, {}).get("function")

        # Second pass: create param_entry nodes for unresolved sources
        # and emit edges.
        for path, source_sani_id, sink_sani_id in resolved_paths:
            if source_sani_id is None:
                source_sani_id = _ensure_param_entry(path.source)
            if (
                source_sani_id
                and sink_sani_id
                and source_sani_id != sink_sani_id
                and not kg.has_edge(source_sani_id, sink_sani_id)
            ):
                sanitizer_names = [s.name for s in path.sanitizers]
                edge_labels = taint_result.edge_labels(
                    path.source.id, path.sink.id
                )
                taint_label_names = sorted(
                    {lbl.name for lbl in edge_labels}
                ) if edge_labels else []
                flow_attrs: dict[str, Any] = {
                    "confidence": "taint_analysis",
                    "sanitized": path.is_sanitized,
                    "sanitizers": sanitizer_names,
                }
                if taint_label_names:
                    flow_attrs["taint_labels"] = taint_label_names

                # When the taint path is sanitized and there are sanicode
                # sanitizer nodes in the same function, route through them
                # to preserve the expected graph topology.
                sink_fn = _node_function(sink_sani_id)
                fn_sans = (
                    by_function.get(sink_fn, {}).get("sanitizers", [])
                    if sink_fn else []
                )
                if path.is_sanitized and fn_sans:
                    chain = [source_sani_id, *fn_sans, sink_sani_id]
                    for up, down in zip(chain, chain[1:], strict=False):
                        if not kg.has_edge(up, down):
                            kg.add_data_flow(up, down, **flow_attrs)
                else:
                    kg.add_data_flow(
                        source_sani_id, sink_sani_id, **flow_attrs
                    )

        # ── 3. Heuristic intra-function edges ─────────────────────────
        #
        # Note: Synthetic param_entry nodes and cross-function heuristic
        # edges are no longer needed — treeloom's TaintPolicy with
        # implicit_param_sources=True handles parameter-to-sink paths
        # natively.
        for _fn_name, groups in by_function.items():
            entries = groups["entries"]
            sinks_list = groups["sinks"]
            sans = groups["sanitizers"]

            if not entries or not sinks_list:
                continue

            for entry_id in entries:
                for sink_id in sinks_list:
                    if sans:
                        chain = [entry_id, *sans, sink_id]
                        for upstream, downstream in zip(chain, chain[1:], strict=False):
                            kg.add_data_flow(
                                upstream, downstream, confidence="heuristic"
                            )
                    else:
                        kg.add_data_flow(entry_id, sink_id, confidence="heuristic")

        # ── 4. Call graph edges ───────────────────────────────────────
        if file_trees:
            registry = get_registry()
            first_plugin = registry.for_extension(file_trees[0][0].suffix)
            if first_plugin is not None:
                project_root = first_plugin.find_package_root(file_trees[0][0])
                definitions = first_plugin.collect_definitions(
                    file_trees, project_root=project_root
                )
                call_sites = first_plugin.collect_call_sites(file_trees)
                all_imports_raw = metadata.get("_all_imports", [])
                resolved = first_plugin.resolve_calls(
                    definitions, call_sites, all_imports_raw
                )

                for site, target_def in resolved:
                    caller_entries = by_function.get(site.caller, {}).get("entries", [])
                    callee_sinks = by_function.get(target_def.name, {}).get("sinks", [])
                    callee_sans = by_function.get(target_def.name, {}).get(
                        "sanitizers", []
                    )

                    if not caller_entries or not callee_sinks:
                        continue

                    for entry_id in caller_entries:
                        for sink_id in callee_sinks:
                            if callee_sans:
                                chain = [entry_id, *callee_sans, sink_id]
                                for up, down in zip(chain, chain[1:], strict=False):
                                    if not kg.has_edge(up, down):
                                        kg.add_data_flow(
                                            up, down, confidence="call_graph"
                                        )
                            else:
                                if not kg.has_edge(entry_id, sink_id):
                                    kg.add_data_flow(
                                        entry_id, sink_id, confidence="call_graph"
                                    )

        return kg

    @classmethod
    def from_source(cls, path: Path) -> KnowledgeGraph:
        """Build a KnowledgeGraph by scanning a source path.

        Args:
            path: Path to a file or directory.

        Returns:
            A populated KnowledgeGraph.

        Raises:
            FileNotFoundError: If path doesn't exist.
        """
        path = path.resolve()
        if not path.exists():
            raise FileNotFoundError(f"Path does not exist: {path}")

        registry = get_registry()
        file_trees: list[tuple[Path, Any]] = []

        if path.is_file():
            plugin = registry.for_extension(path.suffix)
            if plugin is not None:
                tree = plugin.parse_file(path)
                if tree.root_node.has_error:
                    warnings.warn(
                        f"Skipping {path}: syntax error — tree-sitter parse error",
                        stacklevel=2,
                    )
                else:
                    file_trees.append((path, tree))
        else:
            for src_file in sorted(path.rglob("*")):
                plugin = registry.for_extension(src_file.suffix)
                if plugin is None:
                    continue
                tree = plugin.parse_file(src_file)
                if tree.root_node.has_error:
                    warnings.warn(
                        f"Skipping {src_file}: syntax error — tree-sitter parse error",
                        stacklevel=2,
                    )
                else:
                    file_trees.append((src_file, tree))

        return cls.from_parsed(file_trees)
