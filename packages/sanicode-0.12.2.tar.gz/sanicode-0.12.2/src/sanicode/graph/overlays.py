"""Security visualization overlays for treeloom CPG.

Builds Overlay objects that add sanicode's security color scheme
on top of treeloom's base graph visualization.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from treeloom import CodePropertyGraph, TaintResult

from treeloom import Overlay, OverlayStyle


def build_security_overlays(
    cpg: CodePropertyGraph,
    taint_result: TaintResult | None = None,
) -> list[Overlay]:
    """Build sanicode security overlays for treeloom HTML visualization.

    Creates two overlays:
    1. Security Roles — colors nodes by their sanicode classification
       (entry point=blue, sink=red, sanitizer=green, auth guard=purple)
    2. Taint Flows — highlights unsanitized taint paths in red,
       sanitized paths in green (only if taint_result provided)

    Args:
        cpg: A treeloom CodePropertyGraph with sanicode annotations.
        taint_result: Optional taint analysis result for path highlighting.

    Returns:
        List of Overlay objects ready for ``generate_html()``.
    """
    overlays = []

    # ── Overlay 1: Security Roles ────────────────────────────────────
    roles_overlay = Overlay(
        name="Security Roles",
        description="Highlights nodes by sanicode security classification",
    )

    _ROLE_STYLES = {
        "entry_point": OverlayStyle(color="#4A90D9", shape="ellipse", size=32, label="Entry Point"),
        "sink": OverlayStyle(color="#D94A4A", shape="diamond", size=34, label="Sink"),
        "sanitizer": OverlayStyle(color="#4AD94A", shape="hexagon", size=32, label="Sanitizer"),
        "auth_guard": OverlayStyle(
            color="#8E44AD", shape="round-rectangle", size=28, label="Auth Guard",
        ),
        "import": OverlayStyle(color="#999999", shape="ellipse", size=18, label="Import"),
    }

    for node in cpg.nodes():
        kind = cpg.get_annotation(node.id, "sanicode.kind")
        if kind and kind in _ROLE_STYLES:
            roles_overlay.node_styles[node.id] = _ROLE_STYLES[kind]

    overlays.append(roles_overlay)

    # ── Overlay 2: Taint Flows (if available) ────────────────────────
    if taint_result is not None:
        taint_overlay = Overlay(
            name="Taint Flows",
            description="Highlights taint analysis paths (red=unsanitized, green=sanitized)",
            default_visible=True,
        )

        for path in taint_result.unsanitized_paths():
            taint_overlay.node_styles[path.source.id] = OverlayStyle(
                color="#FF9800", label="Taint Source", size=36,
            )
            taint_overlay.node_styles[path.sink.id] = OverlayStyle(
                color="#E53935", label="Unsanitized Sink", size=38,
            )
            # Color intermediate path edges red
            for i in range(len(path.intermediates) - 1):
                edge_key = (path.intermediates[i].id, path.intermediates[i + 1].id)
                taint_overlay.edge_styles[edge_key] = OverlayStyle(
                    color="#C0392B", width=3.0, label="Unsanitized",
                )

        for path in taint_result.sanitized_paths():
            taint_overlay.node_styles[path.sink.id] = OverlayStyle(
                color="#4CAF50", label="Sanitized Sink", size=35,
            )
            for sanitizer in path.sanitizers:
                taint_overlay.node_styles[sanitizer.id] = OverlayStyle(
                    color="#2196F3", label="Sanitizer", size=35,
                )

        overlays.append(taint_overlay)

    return overlays
