"""Configuration loading for Sanicode.

Searches for config in this order:
  1. Path provided by the caller (CLI --config flag)
  2. SANICODE_CONFIG environment variable
  3. sanicode.toml in the current working directory
  4. ~/.config/sanicode/config.toml
  5. /etc/sanicode/config.toml
"""

from __future__ import annotations

import os
import sys
from dataclasses import dataclass, field
from pathlib import Path

import tomlkit

if sys.version_info >= (3, 11):
    import tomllib
else:
    try:
        import tomllib  # type: ignore[no-redef]
    except ImportError:
        import tomli as tomllib  # type: ignore[no-redef]

# Preset definitions for the augment/review pipeline.
# Users can set [llm] preset = "cloud-haiku" (or similar) in sanicode.toml to
# configure provider, model, and strategy in one shot.  Individual fields
# (model, strategy, provider, endpoint, api_key) always override preset values.
LLM_PRESETS: dict[str, dict[str, str]] = {
    "cloud-haiku": {
        "provider": "anthropic",
        "model": "claude-haiku-4-5-20251001",
        "strategy": "augment",
    },
    "local-large": {
        "provider": "ollama",
        "model": "gpt-oss:20b",
        "strategy": "augment",
    },
    "local-medium": {
        "provider": "ollama",
        "model": "granite3.3:8b",
        "strategy": "augment",
    },
    "local-small": {
        "provider": "ollama",
        "model": "mistral-nemo:latest",
        "strategy": "review",
    },
}

# Default search paths, in priority order (index 0 = highest priority).
_DEFAULT_SEARCH_PATHS = [
    Path("sanicode.toml"),
    Path.home() / ".config" / "sanicode" / "config.toml",
    Path("/etc/sanicode/config.toml"),
]


@dataclass
class LLMTierConfig:
    """Configuration for a single LLM tier (fast / analysis / reasoning)."""

    endpoint: str = ""
    model: str = ""
    provider: str = "openai"
    api_key: str | None = None
    timeout_seconds: int = 30


@dataclass
class LLMConfig:
    """Tiered LLM endpoint configuration."""

    # Existing tier fields — kept for backward compatibility.
    fast: LLMTierConfig = field(default_factory=LLMTierConfig)
    analysis: LLMTierConfig = field(default_factory=LLMTierConfig)
    reasoning: LLMTierConfig = field(default_factory=LLMTierConfig)

    # Augment/review pipeline fields.
    # Set `preset` to a key from LLM_PRESETS for quick configuration.
    # Any of the explicit fields below override preset-derived values.
    preset: str = ""
    model: str = ""
    strategy: str = ""       # "augment" or "review"
    provider: str = ""
    endpoint: str = ""
    api_key: str | None = None

    def resolve(self) -> tuple[str, str, str, str, str | None]:
        """Resolve effective (provider, model, strategy, endpoint, api_key).

        Priority: explicit fields > preset > empty (no LLM).
        """
        provider = self.provider
        model = self.model
        strategy = self.strategy
        endpoint = self.endpoint
        api_key = self.api_key

        if self.preset and self.preset in LLM_PRESETS:
            p = LLM_PRESETS[self.preset]
            if not provider:
                provider = p["provider"]
            if not model:
                model = p["model"]
            if not strategy:
                strategy = p["strategy"]

        return provider, model, strategy, endpoint, api_key

    def has_pipeline(self) -> bool:
        """Return True if the augment/review pipeline is configured."""
        provider, model, strategy, _, _ = self.resolve()
        return bool(provider and model and strategy)


@dataclass
class ScanConfig:
    """Scan behavior configuration."""

    exclude_patterns: list[str] = field(default_factory=list)
    # Empty list means "scan all files handled by a registered language plugin".
    # Set explicitly to restrict scanning to specific extensions.
    include_extensions: list[str] = field(default_factory=list)
    max_file_size_kb: int = 512
    graph_path_depth: int = 10
    custom_rules: str | None = None
    # When True (default), SC2111 (generic CWE-345 data authenticity)
    # findings are suppressed in files where a more specific vulnerability
    # rule (SC006 SQL injection, SC009 command injection, etc.) already
    # fires. Set to False to surface every SC2111 finding regardless of
    # overlap. See issue #219.
    dedupe_generic_rules: bool = True


@dataclass
class OutputConfig:
    """Report output preferences."""

    formats: list[str] = field(default_factory=lambda: ["markdown", "sarif"])
    output_dir: str = "sanicode-reports"


@dataclass
class ComplianceConfig:
    """Compliance profile selection."""

    # Supported profiles: owasp-asvs, nist-800-53, asd-stig, pci-dss
    profiles: list[str] = field(
        default_factory=lambda: ["owasp-asvs", "nist-800-53", "asd-stig"]
    )


@dataclass
class StigConfig:
    """Asset metadata written into STIG Viewer .ckl files."""

    hostname: str = ""
    host_ip: str = ""
    host_fqdn: str = ""
    target_comment: str = "Sanicode automated STIG assessment"
    tech_area: str = ""


@dataclass
class DependencyConfig:
    """Dependency scanning configuration."""

    enabled: bool = True
    osv_enabled: bool = True
    osv_timeout: int = 30
    generate_sbom: bool = False


_VALID_DOMAIN_STRATEGIES = ("conservative", "strict", "report-only")


@dataclass
class DomainConfig:
    """Domain reachability analysis configuration."""

    unclassified_strategy: str = "conservative"


@dataclass
class ContentPolicyPattern:
    """A single blocked content pattern."""

    id: str
    pattern: str
    severity: str = "medium"
    description: str = ""
    regex: bool = False
    case_sensitive: bool = True
    domain: str = ""
    cwe_id: int = 200


@dataclass
class ContentPolicyConfig:
    """Content policy scanning configuration."""

    enabled: bool = False
    patterns: list[ContentPolicyPattern] = field(default_factory=list)
    include_globs: list[str] = field(default_factory=list)
    exclude_globs: list[str] = field(default_factory=list)


@dataclass
class MLflowConfig:
    """Configuration for optional MLflow experiment tracking."""

    enabled: bool = False
    tracking_uri: str = ""
    experiment_prefix: str = "sanicode"
    log_artifacts: bool = True


@dataclass
class IntegrationsConfig:
    """Container for optional third-party integration configs."""

    mlflow: MLflowConfig = field(default_factory=MLflowConfig)


@dataclass
class UIConfig:
    """Configuration for the web UI."""

    grafana_url: str = ""
    dashboard_uid: str = "sanicode-overview"


@dataclass
class PipelineConfig:
    """Configuration for KFP pipeline integration."""

    dspa_endpoint: str = ""
    dspa_ui_url: str = ""
    pipeline_name: str = "sanicode-scan"
    sa_token_path: str = "/var/run/secrets/kubernetes.io/serviceaccount/token"
    # Path to a CA bundle for TLS verification.  Set to the RHEL system bundle
    # by default; override in sanicode.toml when using a custom internal CA.
    # Set to an empty string to disable verification (NOT recommended).
    ca_bundle: str = "/etc/pki/tls/certs/ca-bundle.crt"


@dataclass
class SanicodeConfig:
    """Root configuration object for Sanicode."""

    llm: LLMConfig = field(default_factory=LLMConfig)
    scan: ScanConfig = field(default_factory=ScanConfig)
    output: OutputConfig = field(default_factory=OutputConfig)
    compliance: ComplianceConfig = field(default_factory=ComplianceConfig)
    stig: StigConfig = field(default_factory=StigConfig)
    dependencies: DependencyConfig = field(default_factory=DependencyConfig)
    domain: DomainConfig = field(default_factory=DomainConfig)
    content_policy: ContentPolicyConfig = field(default_factory=ContentPolicyConfig)
    integrations: IntegrationsConfig = field(default_factory=IntegrationsConfig)
    ui: UIConfig = field(default_factory=UIConfig)
    pipeline: PipelineConfig = field(default_factory=PipelineConfig)

    # Path this config was loaded from; None if using defaults.
    _source_path: Path | None = field(default=None, compare=False, repr=False)


def _parse_toml(path: Path) -> SanicodeConfig:
    """Parse a TOML file into a SanicodeConfig."""
    with open(path, "rb") as fh:
        raw = tomllib.load(fh)

    cfg = SanicodeConfig(_source_path=path)

    if llm_raw := raw.get("llm", {}):
        for tier_name in ("fast", "analysis", "reasoning"):
            if tier_raw := llm_raw.get(tier_name, {}):
                tier = LLMTierConfig(
                    endpoint=tier_raw.get("endpoint", ""),
                    model=tier_raw.get("model", ""),
                    provider=tier_raw.get("provider", "openai"),
                    api_key=tier_raw.get("api_key"),
                    timeout_seconds=tier_raw.get("timeout_seconds", 30),
                )
                setattr(cfg.llm, tier_name, tier)
        # Augment/review pipeline fields (top-level under [llm]).
        cfg.llm.preset = llm_raw.get("preset", "")
        cfg.llm.model = llm_raw.get("model", "")
        cfg.llm.strategy = llm_raw.get("strategy", "")
        cfg.llm.provider = llm_raw.get("provider", "")
        cfg.llm.endpoint = llm_raw.get("endpoint", "")
        cfg.llm.api_key = llm_raw.get("api_key")

    if scan_raw := raw.get("scan", {}):
        cfg.scan = ScanConfig(
            exclude_patterns=scan_raw.get("exclude_patterns", []),
            include_extensions=scan_raw.get("include_extensions", []),
            max_file_size_kb=scan_raw.get("max_file_size_kb", 512),
            graph_path_depth=scan_raw.get("graph_path_depth", 10),
            custom_rules=scan_raw.get("custom_rules"),
            dedupe_generic_rules=scan_raw.get("dedupe_generic_rules", True),
        )

    if output_raw := raw.get("output", {}):
        cfg.output = OutputConfig(
            formats=output_raw.get("formats", ["markdown", "sarif"]),
            output_dir=output_raw.get("output_dir", "sanicode-reports"),
        )

    if compliance_raw := raw.get("compliance", {}):
        cfg.compliance = ComplianceConfig(
            profiles=compliance_raw.get(
                "profiles", ["owasp-asvs", "nist-800-53", "asd-stig"]
            )
        )

    if stig_raw := raw.get("stig", {}):
        cfg.stig = StigConfig(
            hostname=stig_raw.get("hostname", ""),
            host_ip=stig_raw.get("host_ip", ""),
            host_fqdn=stig_raw.get("host_fqdn", ""),
            target_comment=stig_raw.get(
                "target_comment", "Sanicode automated STIG assessment"
            ),
            tech_area=stig_raw.get("tech_area", ""),
        )

    if deps_raw := raw.get("dependencies", {}):
        cfg.dependencies = DependencyConfig(
            enabled=deps_raw.get("enabled", True),
            osv_enabled=deps_raw.get("osv_enabled", True),
            osv_timeout=deps_raw.get("osv_timeout", 30),
            generate_sbom=deps_raw.get("generate_sbom", False),
        )

    if domain_raw := raw.get("domain", {}):
        strategy = domain_raw.get("unclassified_strategy", "conservative")
        if strategy not in _VALID_DOMAIN_STRATEGIES:
            raise ValueError(
                f"Invalid domain.unclassified_strategy: {strategy!r}. "
                f"Valid values: {', '.join(_VALID_DOMAIN_STRATEGIES)}"
            )
        cfg.domain = DomainConfig(unclassified_strategy=strategy)

    if cp_raw := raw.get("content_policy", {}):
        _valid_severities = ("critical", "high", "medium", "low", "info")
        patterns = []
        for p_raw in cp_raw.get("patterns", []):
            pid = p_raw.get("id")
            ppat = p_raw.get("pattern")
            if not pid or not ppat:
                raise ValueError(
                    "Each [[content_policy.patterns]] entry must have 'id' and 'pattern'. "
                    f"Got: {p_raw!r}"
                )
            sev = p_raw.get("severity", "medium")
            if sev not in _valid_severities:
                raise ValueError(
                    f"Invalid content_policy pattern severity: {sev!r}. "
                    f"Valid values: {', '.join(_valid_severities)}"
                )
            patterns.append(ContentPolicyPattern(
                id=pid,
                pattern=ppat,
                severity=sev,
                description=p_raw.get("description", ""),
                regex=p_raw.get("regex", False),
                case_sensitive=p_raw.get("case_sensitive", True),
                domain=p_raw.get("domain", ""),
                cwe_id=p_raw.get("cwe_id", 200),
            ))
        cfg.content_policy = ContentPolicyConfig(
            enabled=cp_raw.get("enabled", False),
            patterns=patterns,
            include_globs=cp_raw.get("include_globs", []),
            exclude_globs=cp_raw.get("exclude_globs", []),
        )

    if integrations_raw := raw.get("integrations", {}):
        mlflow_raw = integrations_raw.get("mlflow", {})
        if mlflow_raw:
            cfg.integrations = IntegrationsConfig(
                mlflow=MLflowConfig(
                    enabled=mlflow_raw.get("enabled", False),
                    tracking_uri=mlflow_raw.get("tracking_uri", ""),
                    experiment_prefix=mlflow_raw.get("experiment_prefix", "sanicode"),
                    log_artifacts=mlflow_raw.get("log_artifacts", True),
                )
            )

    if ui_raw := raw.get("ui", {}):
        cfg.ui = UIConfig(
            grafana_url=ui_raw.get("grafana_url", ""),
            dashboard_uid=ui_raw.get("dashboard_uid", "sanicode-overview"),
        )

    if pipeline_raw := raw.get("pipeline", {}):
        cfg.pipeline = PipelineConfig(
            dspa_endpoint=pipeline_raw.get("dspa_endpoint", ""),
            dspa_ui_url=pipeline_raw.get("dspa_ui_url", ""),
            pipeline_name=pipeline_raw.get("pipeline_name", "sanicode-scan"),
            sa_token_path=pipeline_raw.get(
                "sa_token_path",
                "/var/run/secrets/kubernetes.io/serviceaccount/token",
            ),
        )

    return cfg


DEFAULT_CONFIG_TEMPLATE = """\
# sanicode.toml — generated by `sanicode config --init`
#
# Config search order:
#   1. Path passed via --config flag
#   2. SANICODE_CONFIG environment variable
#   3. sanicode.toml in the current directory
#   4. ~/.config/sanicode/config.toml
#   5. /etc/sanicode/config.toml

# ---------------------------------------------------------------------------
# LLM endpoints — tiered by task complexity.
# All tiers are optional. Without any LLM configured, Sanicode runs in
# degraded mode: AST patterns, graph construction, and compliance lookups
# still work; LLM-assisted reasoning is skipped.
#
# Each tier accepts:
#   provider         — sanicode provider name (see `sanicode config setup`)
#   model            — model name passed to the provider
#   endpoint         — base URL for self-hosted endpoints (omit for cloud APIs)
#   api_key          — explicit API key (omit to use env vars)
#   timeout_seconds  — request timeout (default: 30)
# ---------------------------------------------------------------------------

# --- Self-hosted (Ollama, vLLM, OpenShift AI) ---
# No API key needed; set endpoint to your inference server.

[llm.fast]
# Quick classification tasks (true-positive filtering, severity estimation).
# Recommended: Granite Nano, Mistral 7B, or any small instruction-tuned model.
# provider = "ollama"
# endpoint = "http://localhost:11434/v1"
# model    = "granite3-dense:2b"
# timeout_seconds = 15

[llm.analysis]
# Data flow and sanitization chain reasoning.
# Recommended: Granite Code 8B, DeepSeek Coder 7B, or similar code-focused model.
# provider = "vllm"
# endpoint = "http://localhost:8000/v1"
# model    = "granite-3.2-8b-instruct"
# timeout_seconds = 30

[llm.reasoning]
# Compliance mapping and report generation — highest quality output.
# Recommended: Llama 3.1 70B, Mixtral 8x22B, or a large reasoning model.
# provider = "openshift_ai"
# endpoint = "http://llama-70b.my-project.svc.cluster.local/v1"
# model    = "llama-3.1-70b-instruct"
# timeout_seconds = 60

# --- Cloud APIs (uncomment one set) ---
# API keys are read from environment variables by default.

# Anthropic — set ANTHROPIC_API_KEY:
# [llm.fast]
# provider = "anthropic"
# model    = "claude-haiku-4-5-20251001"
#
# [llm.analysis]
# provider = "anthropic"
# model    = "claude-sonnet-4-6"
#
# [llm.reasoning]
# provider = "anthropic"
# model    = "claude-sonnet-4-6"
# timeout_seconds = 60

# OpenAI — set OPENAI_API_KEY:
# [llm.fast]
# provider = "openai"
# model    = "gpt-4o-mini"
#
# [llm.reasoning]
# provider = "openai"
# model    = "gpt-4o"

# Gemini — set GEMINI_API_KEY:
# [llm.fast]
# provider = "gemini"
# model    = "gemini-2.0-flash"
#
# [llm.reasoning]
# provider = "gemini"
# model    = "gemini-2.5-pro"

# Groq — set GROQ_API_KEY:
# [llm.fast]
# provider = "groq"
# model    = "llama-3.1-8b-instant"

# --- Special auth (Azure, Bedrock) ---
# These providers require extra environment variables beyond a single API key.

# Azure OpenAI — set AZURE_API_KEY, AZURE_API_BASE, AZURE_API_VERSION:
# [llm.fast]
# provider = "azure"
# model    = "gpt-4o-mini"

# AWS Bedrock — set AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_REGION_NAME:
# [llm.fast]
# provider = "bedrock"
# model    = "anthropic.claude-3-haiku-20240307-v1:0"

# ---------------------------------------------------------------------------
# Scan settings
# ---------------------------------------------------------------------------

[scan]
# Glob patterns to exclude from scanning.
exclude_patterns = [
    "**/.venv/**",
    "**/venv/**",
    "**/site-packages/**",
    "**/node_modules/**",
    "**/dist/**",
    "**/build/**",
    "**/__pycache__/**",
    "**/migrations/**",
    "**/*.min.js",
    "**/tests/**",
    "**/test/**",
    "**/fixtures/**",
    "**/examples/**",
]

# File extensions to include.
# Empty list (the default) means scan all files with a matching language plugin.
# Set explicitly to restrict scanning to specific extensions, e.g.:
# include_extensions = [".py", ".java", ".js"]
include_extensions = []

# Skip files larger than this.
max_file_size_kb = 512

# Maximum depth for entry-to-sink path enumeration in the knowledge graph.
# Increase if truncation warnings appear. Higher values use more CPU/memory.
# graph_path_depth = 10

# ---------------------------------------------------------------------------
# Output settings
# ---------------------------------------------------------------------------

[output]
formats    = ["markdown", "sarif"]
output_dir = "sanicode-reports"

# ---------------------------------------------------------------------------
# Compliance profile selection
# ---------------------------------------------------------------------------

[compliance]
profiles = ["owasp-asvs", "nist-800-53", "asd-stig"]

# ---------------------------------------------------------------------------
# STIG asset metadata — written into .ckl files for STIG Viewer / eMASS.
# Only used when --format stig-checklist is specified.
# ---------------------------------------------------------------------------

# [stig]
# hostname       = ""
# host_ip        = ""
# host_fqdn      = ""
# target_comment = "Sanicode automated STIG assessment"
# tech_area      = ""

# ---------------------------------------------------------------------------
# Dependency scanning
# ---------------------------------------------------------------------------

[dependencies]
# Enable dependency vulnerability scanning via lockfile analysis.
enabled = true

# Query the OSV database for known vulnerabilities. Disable for air-gapped mode.
osv_enabled = true

# Timeout for OSV API queries in seconds.
osv_timeout = 30

# Generate a CycloneDX 1.5 SBOM alongside scan results.
generate_sbom = false

# ---------------------------------------------------------------------------
# Optional integrations
# ---------------------------------------------------------------------------

# MLflow experiment tracking — records each scan as a run under an experiment
# named after the scanned repository.  Requires: pip install 'sanicode[mlflow]'
#
# [integrations.mlflow]
# enabled           = true
# tracking_uri      = "http://mlflow.example.com"   # omit for local ~/.mlruns
# experiment_prefix = "sanicode"                    # experiment = prefix/repo-name
# log_artifacts     = true                          # upload report files to MLflow

# ---------------------------------------------------------------------------
# Web UI settings
# ---------------------------------------------------------------------------

# [ui]
# grafana_url    = "https://grafana.example.com"
# dashboard_uid  = "sanicode-overview"

# ---------------------------------------------------------------------------
# KFP pipeline integration
# ---------------------------------------------------------------------------

# [pipeline]
# dspa_endpoint  = "https://ds-pipeline-dspa.my-project.svc.cluster.local:8443"
# dspa_ui_url    = "https://rhods-dashboard.apps.example.com/pipelineRuns/my-namespace"
# pipeline_name  = "sanicode-scan"
# sa_token_path  = "/var/run/secrets/kubernetes.io/serviceaccount/token"
"""


def _apply_env_overrides(cfg: SanicodeConfig) -> None:
    """Apply environment variable overrides to a loaded config (in-place).

    Supported variables:
      SANICODE_MLFLOW_ENABLED      — "true"/"1" enables, "false"/"0" disables
      SANICODE_MLFLOW_TRACKING_URI — overrides integrations.mlflow.tracking_uri
    """
    env_enabled = os.environ.get("SANICODE_MLFLOW_ENABLED")
    if env_enabled is not None:
        cfg.integrations.mlflow.enabled = env_enabled.strip().lower() in ("true", "1", "yes")

    env_uri = os.environ.get("SANICODE_MLFLOW_TRACKING_URI")
    if env_uri is not None:
        cfg.integrations.mlflow.tracking_uri = env_uri.strip()


def load_config(explicit_path: Path | None = None) -> SanicodeConfig:
    """Load configuration from the first available source.

    Args:
        explicit_path: If provided, use this path and raise if it doesn't exist.

    Returns:
        A populated SanicodeConfig (falls back to defaults if no file found).

    Raises:
        FileNotFoundError: If explicit_path is given but does not exist.
        ValueError: If the config file cannot be parsed.
    """
    if explicit_path is not None:
        if not explicit_path.exists():
            raise FileNotFoundError(
                f"Config file not found: {explicit_path}"
            )
        cfg = _parse_toml(explicit_path)
        _apply_env_overrides(cfg)
        return cfg

    env_path = os.environ.get("SANICODE_CONFIG")
    if env_path is not None:
        env_file = Path(env_path)
        if not env_file.exists():
            raise FileNotFoundError(
                f"Config file not found (via SANICODE_CONFIG): {env_path}"
            )
        cfg = _parse_toml(env_file)
        _apply_env_overrides(cfg)
        return cfg

    for candidate in _DEFAULT_SEARCH_PATHS:
        if candidate.exists():
            cfg = _parse_toml(candidate)
            _apply_env_overrides(cfg)
            return cfg

    # No file found — return a default config with env overrides applied.
    cfg = SanicodeConfig()
    _apply_env_overrides(cfg)
    return cfg


# ---------------------------------------------------------------------------
# Config-writing helpers
# ---------------------------------------------------------------------------


def _load_or_create_tomlkit_doc(path: Path) -> tomlkit.TOMLDocument:
    """Load an existing TOML file or parse the default template.

    Args:
        path: Path to the TOML file to load.

    Returns:
        A tomlkit document, either parsed from disk or from DEFAULT_CONFIG_TEMPLATE.
    """
    if path.exists():
        with path.open("r", encoding="utf-8") as fh:
            return tomlkit.load(fh)
    return tomlkit.parse(DEFAULT_CONFIG_TEMPLATE)


def find_writable_config_path(explicit: Path | None = None) -> Path:
    """Determine the appropriate path for writing config.

    Resolution order:
      1. Return ``explicit`` directly if provided.
      2. Return the path of the config already loaded from the search order.
      3. If that path is under /etc/, raise PermissionError.
      4. Fall back to ``sanicode.toml`` in the current working directory.

    Args:
        explicit: Caller-supplied path (e.g. from --config flag).

    Returns:
        Path to write config to.

    Raises:
        PermissionError: If the discovered config lives under /etc/ and no
            explicit override was provided.
    """
    if explicit is not None:
        return explicit

    cfg = load_config()
    source = cfg._source_path

    if source is not None:
        if source.resolve().is_relative_to(Path("/etc").resolve()):
            raise PermissionError(
                f"Config file is at {source} which is not user-writable. "
                "Use --config to specify an alternative path."
            )
        return source

    return Path("sanicode.toml")


def write_llm_tier(
    path: Path,
    tier_name: str,
    *,
    provider: str | None = None,
    model: str | None = None,
    endpoint: str | None = None,
    api_key: str | None = None,
    timeout_seconds: int | None = None,
) -> None:
    """Create or update a single [llm.{tier}] section in a TOML config file.

    Only keys that are explicitly passed (not None) are written; existing keys
    in the section are left untouched.

    Args:
        path: Config file to write. Created (with parent dirs) if it doesn't
            exist.
        tier_name: One of "fast", "analysis", or "reasoning".
        provider: LiteLLM provider prefix (e.g. "openai", "anthropic").
        model: Model identifier passed to the provider.
        endpoint: Base URL for self-hosted inference endpoints.
        api_key: Explicit API key (prefer env vars when omitted).
        timeout_seconds: Request timeout in seconds.
    """
    path.parent.mkdir(parents=True, exist_ok=True)

    doc = _load_or_create_tomlkit_doc(path)

    if "llm" not in doc:
        doc.add("llm", tomlkit.table())

    llm_table = doc["llm"]
    if tier_name not in llm_table:
        llm_table.add(tier_name, tomlkit.table())

    tier_table = llm_table[tier_name]

    updates = {
        "provider": provider,
        "model": model,
        "endpoint": endpoint,
        "api_key": api_key,
        "timeout_seconds": timeout_seconds,
    }
    for key, value in updates.items():
        if value is not None:
            tier_table[key] = value

    path.write_text(tomlkit.dumps(doc))


def write_domain_config(
    path: Path,
    *,
    unclassified_strategy: str | None = None,
) -> None:
    """Create or update the [domain] section in a TOML config file.

    Only keys that are explicitly passed (not None) are written; existing keys
    in the section are left untouched.

    Args:
        path: Config file to write. Created (with parent dirs) if it doesn't
            exist.
        unclassified_strategy: Strategy for unclassified domains. Must be one
            of "conservative", "strict", or "report-only".
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    doc = _load_or_create_tomlkit_doc(path)

    if "domain" not in doc:
        doc.add("domain", tomlkit.table())

    domain_table = doc["domain"]

    if unclassified_strategy is not None:
        if unclassified_strategy not in _VALID_DOMAIN_STRATEGIES:
            raise ValueError(
                f"Invalid unclassified_strategy: {unclassified_strategy!r}. "
                f"Valid values: {', '.join(_VALID_DOMAIN_STRATEGIES)}"
            )
        domain_table["unclassified_strategy"] = unclassified_strategy

    path.write_text(tomlkit.dumps(doc))


def write_scan_config(
    path: Path,
    *,
    include_extensions: list[str] | None = None,
    exclude_patterns: list[str] | None = None,
) -> None:
    """Create or update the [scan] section in a TOML config file.

    Only keys that are explicitly passed (not None) are written; existing keys
    in the section are left untouched.

    Args:
        path: Config file to write. Created (with parent dirs) if it doesn't
            exist.
        include_extensions: List of file extensions to scan (e.g. [".py", ".java"]).
            Pass an empty list to restore the default "scan all supported" behavior.
        exclude_patterns: List of glob patterns to exclude from scanning.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    doc = _load_or_create_tomlkit_doc(path)

    if "scan" not in doc:
        doc.add("scan", tomlkit.table())

    scan_table = doc["scan"]

    if include_extensions is not None:
        arr = tomlkit.array()
        arr.extend(include_extensions)
        scan_table["include_extensions"] = arr

    if exclude_patterns is not None:
        arr = tomlkit.array()
        arr.extend(exclude_patterns)
        scan_table["exclude_patterns"] = arr

    path.write_text(tomlkit.dumps(doc))
