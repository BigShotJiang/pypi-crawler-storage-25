"""Optional MLflow integration for tracking scan runs as experiments.

MLflow concept mapping:
  Experiment = A codebase/repository
  Run        = A single scan execution
  Parameters = Scan config (file count, commit SHA, branch, target)
  Metrics    = findings_total, cat_i_count, compliance_score, scan_duration_sec, etc.
  Artifacts  = SARIF report, knowledge graph snapshot, markdown report, llm-decisions.json
  Tags       = sanicode_version, scan_id

This module is entirely optional. If mlflow is not installed or the integration
is disabled in config, all functions return None without raising.
"""

from __future__ import annotations

import json
import logging
import subprocess
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from sanicode.scanner.executor import ScanOutput

_log = logging.getLogger(__name__)

# File suffixes considered valid artifacts to upload.
_ARTIFACT_SUFFIXES = frozenset({".json", ".sarif", ".md", ".csv", ".html", ".ckl"})

# ---------------------------------------------------------------------------
# LLM decision log — module-level accumulator, reset each scan run.
# ---------------------------------------------------------------------------

_llm_decisions: list[dict] = []


def reset_llm_decision_log() -> None:
    """Clear accumulated LLM decisions. Called at the start of each scan run."""
    _llm_decisions.clear()


def log_llm_decision(
    prompt_summary: str,
    response_summary: str,
    classification: str,
    confidence: float,
    finding_id: str,
) -> None:
    """Append one LLM classification decision to the in-memory log.

    This is a no-op when the log has not been initialised (i.e. MLflow is
    disabled or mlflow is not installed).  All arguments are plain strings or
    floats so this function never raises.

    Args:
        prompt_summary: A short summary of the prompt sent to the LLM.
        response_summary: A short summary of the raw LLM response.
        classification: Human-readable outcome, e.g. "true_positive" or
            "false_positive".
        confidence: Confidence value returned by the LLM (0.0–1.0).
        finding_id: The rule_id or other identifier for the finding.
    """
    _llm_decisions.append(
        {
            "finding_id": finding_id,
            "classification": classification,
            "confidence": confidence,
            "prompt_summary": prompt_summary,
            "response_summary": response_summary,
        }
    )


def _get_git_info(target: Path) -> dict[str, str]:
    """Extract git metadata from the target directory.

    Returns an empty dict (never raises) when the target is not a git repo
    or git is not available.
    """
    info: dict[str, str] = {}
    try:
        info["commit_sha"] = subprocess.check_output(
            ["git", "rev-parse", "HEAD"],
            cwd=target,
            text=True,
            stderr=subprocess.DEVNULL,
        ).strip()
        info["branch"] = subprocess.check_output(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            cwd=target,
            text=True,
            stderr=subprocess.DEVNULL,
        ).strip()
        raw_url = subprocess.check_output(
            ["git", "config", "--get", "remote.origin.url"],
            cwd=target,
            text=True,
            stderr=subprocess.DEVNULL,
        ).strip()
        # Extract the bare repo name from the remote URL.
        repo_name = raw_url.rsplit("/", 1)[-1].removesuffix(".git")
        if repo_name:
            info["repo_name"] = repo_name
    except (subprocess.SubprocessError, FileNotFoundError, IndexError):
        pass
    return info


def log_scan_run(
    output: ScanOutput,
    target: Path,
    mlflow_cfg: object,  # MLflowConfig — typed as object to avoid circular import at call site
    scan_duration_sec: float,
    output_dir: Path | None = None,
) -> str | None:
    """Log a completed scan run to MLflow.

    Args:
        output: The ScanOutput returned by run_scan().
        target: The directory that was scanned (used for git metadata and
            experiment naming).
        mlflow_cfg: An MLflowConfig instance.  Typed as ``object`` here so
            callers don't need to import MLflowConfig just to pass it through.
        scan_duration_sec: Wall-clock seconds the scan took.
        output_dir: Directory containing generated report files. When set,
            eligible files are uploaded as MLflow artifacts.

    Returns:
        The MLflow run ID string on success, None otherwise.
    """
    if not mlflow_cfg.enabled:  # type: ignore[union-attr]
        return None

    try:
        import mlflow
    except ImportError:
        _log.warning(
            "MLflow integration is enabled but mlflow is not installed. "
            "Run: pip install 'sanicode[mlflow]'"
        )
        return None

    try:
        if mlflow_cfg.tracking_uri:  # type: ignore[union-attr]
            mlflow.set_tracking_uri(mlflow_cfg.tracking_uri)  # type: ignore[union-attr]

        # Name the experiment after the scanned repo (or directory).
        git_info = _get_git_info(target)
        repo_name = git_info.get("repo_name", target.name)
        experiment_name = f"{mlflow_cfg.experiment_prefix}/{repo_name}"  # type: ignore[union-attr]
        mlflow.set_experiment(experiment_name)

        with mlflow.start_run() as run:
            _log_params(mlflow, output, target, git_info)
            _log_metrics(mlflow, output, scan_duration_sec)
            _log_tags(mlflow, output)

            if (
                mlflow_cfg.log_artifacts  # type: ignore[union-attr]
                and output_dir is not None
                and output_dir.exists()
            ):
                _log_artifacts(mlflow, output_dir)
                _log_llm_decisions_artifact(mlflow, output_dir)

            run_id = run.info.run_id
            _log.info(
                "MLflow run logged: %s (experiment: %s)", run_id, experiment_name
            )
            return run_id

    except Exception as exc:
        _log.warning("MLflow logging failed (non-fatal): %s", exc)
        return None


# ---------------------------------------------------------------------------
# Private helpers — each logs a distinct category of data to an active run.
# ---------------------------------------------------------------------------


def _log_params(mlflow: object, output: ScanOutput, target: Path, git_info: dict[str, str]) -> None:
    """Log scan parameters to the active MLflow run."""
    mlflow.log_param("target", str(target))  # type: ignore[union-attr]
    mlflow.log_param("file_count", output.file_count)  # type: ignore[union-attr]
    if commit := git_info.get("commit_sha"):
        mlflow.log_param("commit_sha", commit)  # type: ignore[union-attr]
    if branch := git_info.get("branch"):
        mlflow.log_param("branch", branch)  # type: ignore[union-attr]


def _log_metrics(mlflow: object, output: ScanOutput, scan_duration_sec: float) -> None:
    """Log numeric scan metrics to the active MLflow run."""
    summary = output.result.summary

    mlflow.log_metric("findings_total", summary.get("total_findings", 0))  # type: ignore[union-attr]
    mlflow.log_metric("scan_duration_sec", scan_duration_sec)  # type: ignore[union-attr]

    by_severity = summary.get("by_severity", {})
    for sev in ("critical", "high", "medium", "low", "info"):
        mlflow.log_metric(f"findings_{sev}", by_severity.get(sev, 0))  # type: ignore[union-attr]

    # Map severity buckets to STIG CAT levels.
    cat_i = by_severity.get("critical", 0) + by_severity.get("high", 0)
    mlflow.log_metric("cat_i_count", cat_i)  # type: ignore[union-attr]
    mlflow.log_metric("cat_ii_count", by_severity.get("medium", 0))  # type: ignore[union-attr]
    mlflow.log_metric("cat_iii_count", by_severity.get("low", 0))  # type: ignore[union-attr]

    # Knowledge graph topology.
    mlflow.log_metric("graph_nodes", summary.get("graph_nodes", 0))  # type: ignore[union-attr]
    mlflow.log_metric("graph_edges", summary.get("graph_edges", 0))  # type: ignore[union-attr]
    mlflow.log_metric("graph_entry_points", summary.get("graph_entry_points", 0))  # type: ignore[union-attr]
    mlflow.log_metric("graph_sinks", summary.get("graph_sinks", 0))  # type: ignore[union-attr]
    mlflow.log_metric("graph_sanitizers", summary.get("graph_sanitizers", 0))  # type: ignore[union-attr]

    if (score := summary.get("compliance_score")) is not None:
        mlflow.log_metric("compliance_score", score)  # type: ignore[union-attr]

    if output.dependency_count:
        mlflow.log_metric("dependency_count", output.dependency_count)  # type: ignore[union-attr]
        mlflow.log_metric("lockfiles_scanned", len(output.lockfiles_scanned))  # type: ignore[union-attr]


def _log_tags(mlflow: object, output: ScanOutput) -> None:
    """Log metadata tags to the active MLflow run."""
    mlflow.set_tag("sanicode_version", output.result.sanicode_version)  # type: ignore[union-attr]
    mlflow.set_tag("scan_id", output.result.scan_id)  # type: ignore[union-attr]


def _log_artifacts(mlflow: object, output_dir: Path) -> None:
    """Upload eligible report files from output_dir as MLflow artifacts."""
    for artifact in output_dir.iterdir():
        if artifact.is_file() and artifact.suffix in _ARTIFACT_SUFFIXES:
            mlflow.log_artifact(str(artifact))  # type: ignore[union-attr]


def _log_llm_decisions_artifact(mlflow: object, output_dir: Path) -> None:
    """Write llm-decisions.json to output_dir and upload it as an artifact.

    Skips upload when no decisions were recorded (fast tier not configured or
    no findings were classified).
    """
    if not _llm_decisions:
        return
    decisions_path = output_dir / "llm-decisions.json"
    try:
        decisions_path.write_text(
            json.dumps(_llm_decisions, indent=2), encoding="utf-8"
        )
        mlflow.log_artifact(str(decisions_path))  # type: ignore[union-attr]
    except Exception as exc:
        _log.warning("Failed to write llm-decisions.json artifact: %s", exc)
