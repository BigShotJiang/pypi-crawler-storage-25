"""KFP integration for triggering pipeline runs via the DSPA REST API.

Uses httpx (a core dependency) to call the KFP v2beta1 API directly,
avoiding the heavy ``kfp`` SDK as a runtime dependency.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path

import httpx

_log = logging.getLogger(__name__)

# RHEL system CA bundle; used when the configured path is absent (e.g. on macOS
# or in development environments without the full RHEL PKI tree).
_RHEL_CA_BUNDLE = "/etc/pki/tls/certs/ca-bundle.crt"


def _resolve_verify(ca_bundle: str) -> str | bool:
    """Return the httpx ``verify`` argument for the given CA bundle path.

    Resolution order:
    1. If *ca_bundle* is a non-empty path that exists on disk, use it.
    2. If the RHEL system bundle exists, fall back to it.
    3. Otherwise let httpx use its default (certifi) bundle.

    An empty string for *ca_bundle* is treated the same as "not configured" —
    we never silently disable verification.
    """
    if ca_bundle:
        bundle_path = Path(ca_bundle)
        if bundle_path.exists():
            return str(bundle_path)
        _log.warning(
            "Configured ca_bundle %r not found; falling back to system CA bundle",
            ca_bundle,
        )

    rhel_path = Path(_RHEL_CA_BUNDLE)
    if rhel_path.exists():
        return str(rhel_path)

    # certifi or OS trust store — still verified, just not RHEL-specific.
    return True


def trigger_pipeline_run(
    repo_url: str,
    branch: str,
    pipeline_cfg: object,
) -> str | None:
    """Trigger a KFP pipeline run for the given repository.

    Args:
        repo_url: Git repository URL to scan.
        branch: Git branch to check out.
        pipeline_cfg: A PipelineConfig instance. Typed as ``object``
            to avoid circular imports at call sites.

    Returns:
        The KFP run ID string on success, None otherwise.
    """
    endpoint = pipeline_cfg.dspa_endpoint  # type: ignore[union-attr]
    if not endpoint:
        return None

    token = _read_sa_token(pipeline_cfg.sa_token_path)  # type: ignore[union-attr]
    pipeline_name = pipeline_cfg.pipeline_name  # type: ignore[union-attr]
    ca_bundle: str = getattr(pipeline_cfg, "ca_bundle", _RHEL_CA_BUNDLE)
    base = endpoint.rstrip("/")
    headers: dict[str, str] = {}
    if token:
        headers["Authorization"] = f"Bearer {token}"

    verify = _resolve_verify(ca_bundle)

    try:
        with httpx.Client(verify=verify, timeout=30, headers=headers) as client:
            # Look up pipeline by display_name.
            resp = client.get(
                f"{base}/apis/v2beta1/pipelines",
                params={"page_size": "100"},
            )
            resp.raise_for_status()
            pipelines = resp.json().get("pipelines", [])

            pipeline_id = None
            for p in pipelines:
                if p.get("display_name") == pipeline_name:
                    pipeline_id = p["pipeline_id"]
                    break

            if not pipeline_id:
                _log.warning(
                    "Pipeline %r not found on %s (have: %s)",
                    pipeline_name,
                    endpoint,
                    [p.get("display_name") for p in pipelines],
                )
                return None

            # Get the latest pipeline version.
            ver_resp = client.get(
                f"{base}/apis/v2beta1/pipelines/{pipeline_id}/versions",
                params={"page_size": "1", "sort_by": "created_at desc"},
            )
            ver_resp.raise_for_status()
            versions = ver_resp.json().get("pipeline_versions", [])
            if not versions:
                _log.warning("No versions found for pipeline %s", pipeline_id)
                return None
            version_id = versions[0]["pipeline_version_id"]

            # Create a run.
            run_body = {
                "display_name": f"scan-{repo_url.rsplit('/', 1)[-1].removesuffix('.git')}",
                "pipeline_version_reference": {
                    "pipeline_id": pipeline_id,
                    "pipeline_version_id": version_id,
                },
                "runtime_config": {
                    "parameters": {
                        "repo_url": repo_url,
                        "branch": branch,
                    },
                },
            }
            run_resp = client.post(
                f"{base}/apis/v2beta1/runs",
                content=json.dumps(run_body),
                headers={"Content-Type": "application/json"},
            )
            run_resp.raise_for_status()
            run_id = run_resp.json().get("run_id")
            _log.info(
                "KFP run triggered: %s (pipeline: %s)", run_id, pipeline_name
            )
            return run_id

    except Exception as exc:
        _log.warning("KFP pipeline trigger failed (non-fatal): %s", exc)
        return None


def _read_sa_token(path: str) -> str | None:
    """Read the Kubernetes service account token, or return None."""
    token_path = Path(path)
    if token_path.exists():
        return token_path.read_text().strip()
    return None
