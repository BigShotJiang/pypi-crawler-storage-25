"""SBOM-aware dependency scanning for sanicode."""

from sanicode.dependencies.integration import dependency_findings_to_enriched, scan_dependencies
from sanicode.dependencies.lockfile import discover_lockfiles
from sanicode.dependencies.models import DependencyFinding, ParsedDependency, VulnerabilityInfo
from sanicode.dependencies.osv_client import OSVClient
from sanicode.dependencies.sbom import generate_sbom

__all__ = [
    "DependencyFinding",
    "OSVClient",
    "ParsedDependency",
    "VulnerabilityInfo",
    "dependency_findings_to_enriched",
    "discover_lockfiles",
    "generate_sbom",
    "scan_dependencies",
]
