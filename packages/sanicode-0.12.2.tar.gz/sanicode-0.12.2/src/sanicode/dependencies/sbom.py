"""Minimal CycloneDX 1.5 JSON SBOM generation.

Produces a standards-compliant SBOM as a plain dict (no external library
required).  Use ``sbom_to_json`` for serialization.
"""

from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone

from sanicode.dependencies.models import ParsedDependency, VulnerabilityInfo

# PURL type strings per ecosystem.
_PURL_TYPE: dict[str, str] = {
    "PyPI": "pypi",
    "npm": "npm",
    "Packagist": "composer",
    "Go": "golang",
    "RubyGems": "gem",
    "crates.io": "cargo",
    "Maven": "maven",
    "NuGet": "nuget",
}


def _purl(dep: ParsedDependency) -> str:
    """Generate a Package URL (PURL) for *dep*."""
    purl_type = _PURL_TYPE.get(dep.ecosystem, dep.ecosystem.lower())
    # Scoped npm packages: @scope/name -> pkg:npm/%40scope/name@version
    if purl_type == "npm" and "/" in dep.name:
        namespace, name = dep.name.rsplit("/", 1)
        return f"pkg:{purl_type}/{namespace}/{name}@{dep.version}"
    # Maven: name is "groupId:artifactId" -> pkg:maven/groupId/artifactId@version
    if purl_type == "maven" and ":" in dep.name:
        group_id, artifact_id = dep.name.split(":", 1)
        return f"pkg:{purl_type}/{group_id}/{artifact_id}@{dep.version}"
    return f"pkg:{purl_type}/{dep.name}@{dep.version}"


def generate_sbom(
    deps: list[ParsedDependency],
    vulns: dict[tuple[str, str], list[VulnerabilityInfo]] | None = None,
    tool_name: str = "sanicode",
    tool_version: str = "",
) -> dict:
    """Generate a CycloneDX 1.5 JSON SBOM.

    Args:
        deps: Parsed dependencies to include as components.
        vulns: Optional vulnerability map keyed by ``(name, version)``.
        tool_name: Name of the tool producing this SBOM.
        tool_version: Version string; defaults to ``sanicode.__version__``.

    Returns:
        A dict conforming to the CycloneDX 1.5 JSON schema.
    """
    if not tool_version:
        from sanicode import __version__

        tool_version = __version__

    components = []
    for dep in deps:
        components.append(
            {
                "type": "library",
                "name": dep.name,
                "version": dep.version,
                "purl": _purl(dep),
            }
        )

    sbom: dict = {
        "bomFormat": "CycloneDX",
        "specVersion": "1.5",
        "serialNumber": f"urn:uuid:{uuid.uuid4()}",
        "version": 1,
        "metadata": {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "tools": {
                "components": [
                    {"type": "application", "name": tool_name, "version": tool_version}
                ]
            },
        },
        "components": components,
    }

    if vulns:
        vuln_list = _build_vulnerability_section(vulns, components)
        if vuln_list:
            sbom["vulnerabilities"] = vuln_list

    return sbom


def _build_vulnerability_section(
    vulns: dict[tuple[str, str], list[VulnerabilityInfo]],
    components: list[dict],
) -> list[dict]:
    """Build the CycloneDX ``vulnerabilities`` array."""
    vuln_list: list[dict] = []
    for (pkg_name, pkg_version), vuln_infos in vulns.items():
        for vi in vuln_infos:
            entry: dict = {
                "id": vi.osv_id,
                "source": {"name": "OSV", "url": "https://osv.dev"},
                "description": vi.summary,
            }
            if vi.aliases:
                entry["references"] = [
                    {"id": alias, "source": {"name": "CVE"}}
                    for alias in vi.aliases
                    if alias.startswith("CVE-")
                ]
            matching = [
                c
                for c in components
                if c["name"] == pkg_name and c["version"] == pkg_version
            ]
            if matching:
                entry["affects"] = [{"ref": matching[0]["purl"]}]
            vuln_list.append(entry)
    return vuln_list


def sbom_to_json(sbom: dict, indent: int = 2) -> str:
    """Serialize an SBOM dict to a JSON string."""
    return json.dumps(sbom, indent=indent)
