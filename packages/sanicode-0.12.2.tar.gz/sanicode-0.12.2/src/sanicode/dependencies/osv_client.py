"""OSV.dev API client for vulnerability lookups.

Designed offline-first: when the client is disabled or the network is
unreachable, every public method returns an empty result rather than raising.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field

import httpx

from sanicode.dependencies.models import ParsedDependency, VulnerabilityInfo

_log = logging.getLogger(__name__)

OSV_API_URL = "https://api.osv.dev"

# Ecosystem names as expected by the OSV API.
_ECOSYSTEM_MAP: dict[str, str] = {
    "PyPI": "PyPI",
    "npm": "npm",
    "Packagist": "Packagist",
    "Go": "Go",
    "RubyGems": "RubyGems",
    "crates.io": "crates.io",
    "Maven": "Maven",
    "NuGet": "NuGet",
}


@dataclass
class OSVClient:
    """Thin wrapper around the OSV batch and single-query endpoints."""

    enabled: bool = True
    timeout: int = 30
    _client: httpx.Client | None = field(default=None, repr=False)

    def _get_client(self) -> httpx.Client:
        if self._client is None:
            self._client = httpx.Client(timeout=self.timeout)
        return self._client

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def query_batch(
        self, deps: list[ParsedDependency]
    ) -> dict[tuple[str, str], list[VulnerabilityInfo]]:
        """Query OSV for all *deps* in a single batch request.

        Returns a dict keyed by ``(name, version)`` with a list of
        ``VulnerabilityInfo`` for each affected package.  Packages with
        no known vulnerabilities are omitted.
        """
        if not self.enabled or not deps:
            return {}

        queries = []
        for dep in deps:
            ecosystem = _ECOSYSTEM_MAP.get(dep.ecosystem, dep.ecosystem)
            queries.append(
                {
                    "version": dep.version,
                    "package": {"name": dep.name, "ecosystem": ecosystem},
                }
            )

        try:
            client = self._get_client()
            resp = client.post(
                f"{OSV_API_URL}/v1/querybatch",
                json={"queries": queries},
                timeout=self.timeout,
            )
            resp.raise_for_status()
            data = resp.json()
        except (httpx.HTTPError, httpx.TimeoutException, Exception) as exc:
            _log.warning("OSV batch query failed: %s", exc)
            return {}

        results: dict[tuple[str, str], list[VulnerabilityInfo]] = {}
        for dep, result in zip(deps, data.get("results", []), strict=False):
            vulns = [_parse_vuln(v) for v in result.get("vulns", [])]
            if vulns:
                results[(dep.name, dep.version)] = vulns
        return results

    def query_single(self, dep: ParsedDependency) -> list[VulnerabilityInfo]:
        """Fallback single-dependency query."""
        if not self.enabled:
            return []

        ecosystem = _ECOSYSTEM_MAP.get(dep.ecosystem, dep.ecosystem)
        try:
            client = self._get_client()
            resp = client.post(
                f"{OSV_API_URL}/v1/query",
                json={
                    "version": dep.version,
                    "package": {"name": dep.name, "ecosystem": ecosystem},
                },
                timeout=self.timeout,
            )
            resp.raise_for_status()
            data = resp.json()
        except (httpx.HTTPError, httpx.TimeoutException, Exception) as exc:
            _log.warning("OSV query failed for %s==%s: %s", dep.name, dep.version, exc)
            return []

        return [_parse_vuln(v) for v in data.get("vulns", [])]

    def close(self) -> None:
        """Close the underlying HTTP client."""
        if self._client is not None:
            self._client.close()
            self._client = None


# ------------------------------------------------------------------
# Internal helpers
# ------------------------------------------------------------------


def _parse_vuln(vuln: dict) -> VulnerabilityInfo:
    """Parse an OSV vulnerability record into ``VulnerabilityInfo``."""
    osv_id = vuln.get("id", "")
    aliases = vuln.get("aliases", [])
    summary = vuln.get("summary", "")
    details_url = f"https://osv.dev/vulnerability/{osv_id}" if osv_id else ""

    severity = _extract_severity(vuln)
    cwe_ids = _extract_cwes(vuln)

    return VulnerabilityInfo(
        osv_id=osv_id,
        aliases=aliases,
        summary=summary,
        severity=severity,
        cwe_ids=cwe_ids,
        details_url=details_url,
    )


def _extract_severity(vuln: dict) -> str:
    """Derive a severity label from CVSS data embedded in the vulnerability."""
    # 1. Check database_specific for a numeric CVSS score.
    db_specific = vuln.get("database_specific", {})
    cvss_score = db_specific.get("cvss", {}).get("score")
    if cvss_score is not None:
        return _cvss_to_severity(float(cvss_score))

    # 2. Check severity entries for CVSS_V3 type with a score.
    for entry in vuln.get("severity", []):
        if entry.get("type") == "CVSS_V3":
            score_str = entry.get("score", "")
            # Some entries embed the base score directly.
            try:
                return _cvss_to_severity(float(score_str))
            except (ValueError, TypeError):
                pass

    # 3. Fallback to the string severity in database_specific (GitHub).
    gh_severity = db_specific.get("severity")
    if gh_severity and isinstance(gh_severity, str):
        normalised = gh_severity.lower()
        if normalised in ("critical", "high", "medium", "low"):
            return normalised

    return "medium"


def _cvss_to_severity(score: float) -> str:
    """Map a CVSS base score to a severity label."""
    if score >= 9.0:
        return "critical"
    if score >= 7.0:
        return "high"
    if score >= 4.0:
        return "medium"
    return "low"


def _extract_cwes(vuln: dict) -> list[int]:
    """Extract CWE IDs from ``database_specific.cwe_ids``."""
    cwes: list[int] = []
    db_specific = vuln.get("database_specific", {})
    for cwe_entry in db_specific.get("cwe_ids", []):
        if isinstance(cwe_entry, str) and cwe_entry.startswith("CWE-"):
            try:
                cwes.append(int(cwe_entry.split("-")[1]))
            except (ValueError, IndexError):
                pass
    return cwes
