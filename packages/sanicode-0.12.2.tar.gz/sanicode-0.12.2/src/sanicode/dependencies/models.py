"""Data models for dependency scanning."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class ParsedDependency:
    """A single dependency extracted from a lockfile."""

    name: str  # "requests", "lodash"
    version: str  # "2.31.0"
    ecosystem: str  # OSV ecosystem: "PyPI", "npm", "Packagist"
    lockfile: Path
    lockfile_line: int | None = None


@dataclass
class VulnerabilityInfo:
    """Vulnerability metadata from OSV or similar source."""

    osv_id: str  # "GHSA-xxxx-xxxx-xxxx"
    aliases: list[str] = field(default_factory=list)  # CVE aliases
    summary: str = ""
    severity: str = "medium"  # "critical", "high", "medium", "low"
    cwe_ids: list[int] = field(default_factory=list)
    details_url: str = ""


@dataclass
class DependencyFinding:
    """A vulnerability finding linked to a specific dependency."""

    dependency: ParsedDependency
    vulnerability: VulnerabilityInfo
    rule_id: str = "DEP001"
    message: str = ""
    severity: str = "medium"
    cwe_id: int = 1395  # CWE-1395 default; override if OSV provides specific CWE
