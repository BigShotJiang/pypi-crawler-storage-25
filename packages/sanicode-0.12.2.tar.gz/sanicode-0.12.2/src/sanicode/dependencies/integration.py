"""Bridge between the dependency module and the main sanicode scan pipeline.

Provides ``scan_dependencies`` as the top-level entry point and
``dependency_findings_to_enriched`` to convert dependency findings into
``EnrichedFinding`` objects for unified reporting.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path

from sanicode.dependencies.lockfile import discover_lockfiles, parse_lockfile
from sanicode.dependencies.models import DependencyFinding, ParsedDependency, VulnerabilityInfo
from sanicode.dependencies.osv_client import OSVClient
from sanicode.dependencies.sbom import generate_sbom

_log = logging.getLogger(__name__)


@dataclass
class DependencyScanResult:
    """Aggregated result of a dependency scan."""

    dependencies: list[ParsedDependency] = field(default_factory=list)
    findings: list[DependencyFinding] = field(default_factory=list)
    lockfiles_scanned: list[Path] = field(default_factory=list)
    sbom: dict | None = None


def scan_dependencies(
    target: Path,
    exclude_patterns: list[str] | None = None,
    osv_enabled: bool = True,
    osv_timeout: int = 30,
    generate_sbom_flag: bool = False,
) -> DependencyScanResult:
    """Full pipeline: discover lockfiles -> parse -> query OSV -> build findings.

    Args:
        target: Root directory to scan.
        exclude_patterns: fnmatch patterns for paths to skip.
        osv_enabled: Whether to query OSV for vulnerability data.
        osv_timeout: HTTP timeout in seconds for OSV requests.
        generate_sbom_flag: If ``True``, attach a CycloneDX SBOM to the result.

    Returns:
        A ``DependencyScanResult`` with all parsed dependencies, vulnerability
        findings, and optionally an SBOM.
    """
    result = DependencyScanResult()

    lockfiles = discover_lockfiles(target, exclude_patterns)
    result.lockfiles_scanned = lockfiles

    if not lockfiles:
        _log.info("No lockfiles found in %s", target)
        return result

    # Parse all lockfiles
    all_deps: list[ParsedDependency] = []
    for lf in lockfiles:
        deps = parse_lockfile(lf)
        all_deps.extend(deps)
        _log.info("Parsed %d dependencies from %s", len(deps), lf)

    result.dependencies = all_deps

    if not all_deps:
        return result

    # Query OSV for vulnerabilities
    vuln_map: dict[tuple[str, str], list[VulnerabilityInfo]] = {}
    if osv_enabled:
        client = OSVClient(enabled=True, timeout=osv_timeout)
        try:
            vuln_map = client.query_batch(all_deps)
        finally:
            client.close()

        if vuln_map:
            _log.info("OSV returned vulnerabilities for %d packages", len(vuln_map))

    # Build findings
    for dep in all_deps:
        vulns = vuln_map.get((dep.name, dep.version), [])
        for vuln in vulns:
            cwe_id = vuln.cwe_ids[0] if vuln.cwe_ids else 1395
            finding = DependencyFinding(
                dependency=dep,
                vulnerability=vuln,
                rule_id="DEP001",
                message=(
                    f"{dep.name}=={dep.version} has known vulnerability "
                    f"{vuln.osv_id}: {vuln.summary}"
                ),
                severity=vuln.severity,
                cwe_id=cwe_id,
            )
            result.findings.append(finding)

    # Generate SBOM if requested
    if generate_sbom_flag:
        result.sbom = generate_sbom(all_deps, vuln_map if vuln_map else None)

    return result


def dependency_findings_to_enriched(
    findings: list[DependencyFinding],
    mapper,  # ComplianceMapper — loosely typed to avoid circular import
) -> list:
    """Convert ``DependencyFinding`` objects to ``EnrichedFinding`` for unified reporting.

    Uses *mapper* to add OWASP / NIST / STIG / PCI cross-references.

    Args:
        findings: Dependency findings to convert.
        mapper: A ``ComplianceMapper`` instance.

    Returns:
        List of ``EnrichedFinding`` objects.
    """
    from sanicode.compliance.enrichment import EnrichedFinding
    from sanicode.compliance.mapper import derive_severity

    enriched = []
    for f in findings:
        mapping = mapper.map_cwe(f.cwe_id)
        ef = EnrichedFinding(
            file=f.dependency.lockfile,
            line=f.dependency.lockfile_line or 0,
            column=0,
            rule_id=f.rule_id,
            message=f.message,
            severity=f.severity,
            cwe_id=f.cwe_id,
            cwe_name=mapping.cwe_name,
            compliance=mapping,
            derived_severity=derive_severity(mapping) or f.severity,
        )
        enriched.append(ef)
    return enriched
