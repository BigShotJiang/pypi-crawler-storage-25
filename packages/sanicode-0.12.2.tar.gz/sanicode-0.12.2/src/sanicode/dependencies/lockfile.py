"""Lockfile discovery and parsing for Python, npm, and Composer ecosystems.

All parsers are pure Python -- no subprocess calls. Each parser returns an
empty list on any file-read or parse error, making the pipeline tolerant of
partial or corrupt lockfiles.
"""

from __future__ import annotations

import json
import logging
import xml.etree.ElementTree as ET
from collections.abc import Callable
from pathlib import Path

from sanicode.dependencies.models import ParsedDependency
from sanicode.scanner.globs import matches_glob

_log = logging.getLogger(__name__)

# Lockfile basenames that we know how to parse.
_KNOWN_LOCKFILES = {
    "requirements.txt",
    "package-lock.json",
    "composer.lock",
    "go.sum",
    "Gemfile.lock",
    "Cargo.lock",
    "pom.xml",
    "packages.lock.json",
}


# ---------------------------------------------------------------------------
# Discovery
# ---------------------------------------------------------------------------


def discover_lockfiles(
    target: Path,
    exclude_patterns: list[str] | None = None,
) -> list[Path]:
    """Walk *target* for known lockfile names, respecting exclude patterns.

    Args:
        target: Root directory to search.
        exclude_patterns: fnmatch-style patterns applied to relative paths.
            A file is skipped if any pattern matches.

    Returns:
        Sorted list of absolute ``Path`` objects.
    """
    excludes = exclude_patterns or []
    found: list[Path] = []

    if not target.is_dir():
        return found

    for path in target.rglob("*"):
        if path.name not in _KNOWN_LOCKFILES:
            continue
        rel = str(path.relative_to(target))
        if any(matches_glob(rel, pat) for pat in excludes):
            continue
        found.append(path)

    found.sort()
    return found


# ---------------------------------------------------------------------------
# requirements.txt
# ---------------------------------------------------------------------------


def parse_requirements_txt(path: Path) -> list[ParsedDependency]:
    """Parse pinned ``pkg==version`` lines from a requirements file.

    Skips comments, blank lines, ``-r`` includes, ``-e`` editable installs,
    and any line without an ``==`` pin.
    """
    deps: list[ParsedDependency] = []
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except OSError as exc:
        _log.warning("Cannot read %s: %s", path, exc)
        return deps

    for lineno, raw in enumerate(lines, start=1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith(("-r", "-e", "-c")):
            continue
        if "==" not in line:
            continue
        # Strip inline comments and environment markers
        if " #" in line:
            line = line[: line.index(" #")].strip()
        if ";" in line:
            line = line[: line.index(";")].strip()
        name, _, version = line.partition("==")
        name = name.strip()
        version = version.strip()
        if name and version:
            deps.append(
                ParsedDependency(
                    name=name,
                    version=version,
                    ecosystem="PyPI",
                    lockfile=path,
                    lockfile_line=lineno,
                )
            )
    return deps


# ---------------------------------------------------------------------------
# package-lock.json (npm)
# ---------------------------------------------------------------------------


def parse_package_lock_json(path: Path) -> list[ParsedDependency]:
    """Parse an npm ``package-lock.json`` file (v1, v2, and v3 formats).

    For v2/v3 the ``packages`` dict is used (current npm default).  Falls
    back to the v1 ``dependencies`` dict when ``packages`` is absent.
    """
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        _log.warning("Cannot parse %s: %s", path, exc)
        return []

    deps: list[ParsedDependency] = []

    # v2/v3: "packages" dict.  The root project has key "" -- skip it.
    packages = data.get("packages")
    if packages and isinstance(packages, dict):
        for key, info in packages.items():
            if not key:  # root project entry
                continue
            # Key format: "node_modules/@scope/name" or "node_modules/name"
            parts = key.split("node_modules/")
            name = parts[-1] if parts else key
            version = info.get("version", "")
            if name and version:
                deps.append(
                    ParsedDependency(
                        name=name,
                        version=version,
                        ecosystem="npm",
                        lockfile=path,
                    )
                )
        return deps

    # v1 fallback: "dependencies" dict
    v1_deps = data.get("dependencies")
    if v1_deps and isinstance(v1_deps, dict):
        for name, info in v1_deps.items():
            version = info.get("version", "")
            if name and version:
                deps.append(
                    ParsedDependency(
                        name=name,
                        version=version,
                        ecosystem="npm",
                        lockfile=path,
                    )
                )

    return deps


# ---------------------------------------------------------------------------
# composer.lock (PHP/Packagist)
# ---------------------------------------------------------------------------


def parse_composer_lock(path: Path) -> list[ParsedDependency]:
    """Parse a Composer ``composer.lock`` file.

    Strips a leading ``v`` from version strings (e.g. ``v2.0.0`` -> ``2.0.0``).
    """
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        _log.warning("Cannot parse %s: %s", path, exc)
        return []

    deps: list[ParsedDependency] = []
    for pkg in data.get("packages", []):
        name = pkg.get("name", "")
        version = pkg.get("version", "")
        if version.startswith("v"):
            version = version[1:]
        if name and version:
            deps.append(
                ParsedDependency(
                    name=name,
                    version=version,
                    ecosystem="Packagist",
                    lockfile=path,
                )
            )
    return deps


# ---------------------------------------------------------------------------
# go.sum
# ---------------------------------------------------------------------------


def parse_go_sum(path: Path) -> list[ParsedDependency]:
    """Parse a Go ``go.sum`` checksum file.

    Each line has the form ``module version hash``.  Lines whose version
    suffix is ``/go.mod`` are checksum-only entries and are skipped.
    Duplicate ``(module, version)`` pairs (source + go.mod entries) are
    deduplicated before returning.
    """
    deps: list[ParsedDependency] = []
    seen: set[tuple[str, str]] = set()
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except OSError as exc:
        _log.warning("Cannot read %s: %s", path, exc)
        return deps

    for lineno, raw in enumerate(lines, start=1):
        line = raw.strip()
        if not line:
            continue
        parts = line.split()
        if len(parts) < 2:
            continue
        name, version_field = parts[0], parts[1]
        # Skip go.mod-only checksum entries
        if version_field.endswith("/go.mod"):
            continue
        version = version_field.lstrip("v")
        key = (name, version)
        if key in seen:
            continue
        seen.add(key)
        deps.append(
            ParsedDependency(
                name=name,
                version=version,
                ecosystem="Go",
                lockfile=path,
                lockfile_line=lineno,
            )
        )
    return deps


# ---------------------------------------------------------------------------
# Gemfile.lock
# ---------------------------------------------------------------------------


def parse_gemfile_lock(path: Path) -> list[ParsedDependency]:
    """Parse a Bundler ``Gemfile.lock`` file.

    Finds the ``GEM`` section, then the ``specs:`` subsection, and extracts
    top-level gem entries (exactly 4-space indent) of the form ``name (version)``.
    """
    deps: list[ParsedDependency] = []
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except OSError as exc:
        _log.warning("Cannot read %s: %s", path, exc)
        return deps

    in_gem = False
    in_specs = False
    for lineno, raw in enumerate(lines, start=1):
        stripped = raw.strip()
        # Detect GEM section header (non-indented)
        if stripped == "GEM":
            in_gem = True
            in_specs = False
            continue
        # Detect end of GEM section (another non-indented keyword)
        if in_gem and stripped and not raw[0].isspace():
            in_gem = False
            in_specs = False
            continue
        if in_gem and stripped == "specs:":
            in_specs = True
            continue
        if not in_specs:
            continue
        # Top-level gem: exactly 4-space indent
        if raw.startswith("    ") and not raw.startswith("     "):
            entry = raw.strip()
            if " (" in entry and entry.endswith(")"):
                name, _, rest = entry.partition(" (")
                version = rest.rstrip(")")
                if name and version:
                    deps.append(
                        ParsedDependency(
                            name=name,
                            version=version,
                            ecosystem="RubyGems",
                            lockfile=path,
                            lockfile_line=lineno,
                        )
                    )
    return deps


# ---------------------------------------------------------------------------
# Cargo.lock
# ---------------------------------------------------------------------------


def parse_cargo_lock(path: Path) -> list[ParsedDependency]:
    """Parse a Cargo ``Cargo.lock`` file (TOML-like, text-parsed).

    Iterates ``[[package]]`` sections and extracts ``name`` and ``version``
    fields without importing a TOML library.
    """
    deps: list[ParsedDependency] = []
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except OSError as exc:
        _log.warning("Cannot read %s: %s", path, exc)
        return deps

    current_name: str | None = None
    current_version: str | None = None

    def _flush() -> None:
        if current_name and current_version:
            deps.append(
                ParsedDependency(
                    name=current_name,
                    version=current_version,
                    ecosystem="crates.io",
                    lockfile=path,
                )
            )

    for raw in lines:
        line = raw.strip()
        if line == "[[package]]":
            _flush()
            current_name = None
            current_version = None
        elif line.startswith("name = "):
            current_name = line.split("=", 1)[1].strip().strip('"')
        elif line.startswith("version = "):
            current_version = line.split("=", 1)[1].strip().strip('"')

    _flush()
    return deps


# ---------------------------------------------------------------------------
# pom.xml (Maven)
# ---------------------------------------------------------------------------

_MAVEN_NS = "http://maven.apache.org/POM/4.0.0"


def parse_pom_xml(path: Path) -> list[ParsedDependency]:
    """Parse a Maven ``pom.xml`` file for declared dependencies.

    Handles both bare and namespaced element names.  Skips version strings
    containing ``${`` (unresolved property references).
    """
    deps: list[ParsedDependency] = []
    try:
        tree = ET.parse(path)  # noqa: S314 — local file, not network input
    except (ET.ParseError, OSError) as exc:
        _log.warning("Cannot parse %s: %s", path, exc)
        return deps

    root = tree.getroot()

    def _find_text(parent: ET.Element, tag: str) -> str:
        # Try namespaced first, then bare
        el = parent.find(f"{{{_MAVEN_NS}}}{tag}")
        if el is None:
            el = parent.find(tag)
        return (el.text or "").strip() if el is not None else ""

    # Search for <dependency> elements anywhere in the tree
    for dep_el in root.iter(f"{{{_MAVEN_NS}}}dependency"):
        group_id = _find_text(dep_el, "groupId")
        artifact_id = _find_text(dep_el, "artifactId")
        version = _find_text(dep_el, "version")
        if not (group_id and artifact_id and version):
            continue
        if "${" in version:
            continue
        deps.append(
            ParsedDependency(
                name=f"{group_id}:{artifact_id}",
                version=version,
                ecosystem="Maven",
                lockfile=path,
            )
        )

    # Also handle bare (no namespace) pom.xml files
    if not deps:
        for dep_el in root.iter("dependency"):
            group_id = _find_text(dep_el, "groupId")
            artifact_id = _find_text(dep_el, "artifactId")
            version = _find_text(dep_el, "version")
            if not (group_id and artifact_id and version):
                continue
            if "${" in version:
                continue
            deps.append(
                ParsedDependency(
                    name=f"{group_id}:{artifact_id}",
                    version=version,
                    ecosystem="Maven",
                    lockfile=path,
                )
            )

    return deps


# ---------------------------------------------------------------------------
# packages.lock.json (.NET/NuGet)
# ---------------------------------------------------------------------------


def parse_packages_lock_json(path: Path) -> list[ParsedDependency]:
    """Parse a .NET ``packages.lock.json`` file.

    The format has a ``dependencies`` top-level key mapping target framework
    monikers to dicts of package name -> ``{"resolved": "version"}``.
    Deduplicates across all target frameworks.
    """
    deps: list[ParsedDependency] = []
    seen: set[tuple[str, str]] = set()
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        _log.warning("Cannot parse %s: %s", path, exc)
        return deps

    frameworks = data.get("dependencies", {})
    if not isinstance(frameworks, dict):
        return deps

    for _framework, packages in frameworks.items():
        if not isinstance(packages, dict):
            continue
        for name, info in packages.items():
            if not isinstance(info, dict):
                continue
            version = info.get("resolved", "")
            if not (name and version):
                continue
            key = (name, version)
            if key in seen:
                continue
            seen.add(key)
            deps.append(
                ParsedDependency(
                    name=name,
                    version=version,
                    ecosystem="NuGet",
                    lockfile=path,
                )
            )
    return deps


# ---------------------------------------------------------------------------
# Dispatcher
# ---------------------------------------------------------------------------

_LOCKFILE_PARSERS: dict[str, Callable[[Path], list[ParsedDependency]]] = {
    "requirements.txt": parse_requirements_txt,
    "package-lock.json": parse_package_lock_json,
    "composer.lock": parse_composer_lock,
    "go.sum": parse_go_sum,
    "Gemfile.lock": parse_gemfile_lock,
    "Cargo.lock": parse_cargo_lock,
    "pom.xml": parse_pom_xml,
    "packages.lock.json": parse_packages_lock_json,
}


def parse_lockfile(path: Path) -> list[ParsedDependency]:
    """Dispatch to the correct parser based on filename, or return ``[]``."""
    parser = _LOCKFILE_PARSERS.get(path.name)
    if parser is None:
        return []
    return parser(path)
