"""SARIF ingestion and compliance enrichment.

Accepts SARIF output from any SAST tool (Bandit, Semgrep, CodeQL, Opengrep)
and maps CWE findings through sanicode's compliance database to add OWASP ASVS,
NIST 800-53, ASD STIG, PCI DSS, FedRAMP, and CMMC 2.0 cross-references.
"""

from __future__ import annotations

import copy
import json
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

from sanicode.compliance.mapper import ComplianceMapper, ComplianceMapping
from sanicode.version import __version__

_CWE_PATTERN = re.compile(r"CWE[- ]?(\d+)", re.IGNORECASE)

# SARIF 2.1.0 is the current standard version.
_SARIF_SCHEMA_VERSION = "2.1.0"
_SARIF_SCHEMA_URI = (
    "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/"
    "main/sarif-2.1/schema/sarif-schema-2.1.0.json"
)

_TAXONOMY_NAME = "sanicode-compliance"
_TAXONOMY_URI = "https://github.com/rdwj/sanicode"


def extract_cwe_ids(result: dict, run: dict) -> list[int]:
    """Extract CWE IDs from a SARIF result using multiple strategies.

    Tries each extraction strategy in priority order and returns all
    unique CWE IDs found across all strategies.

    Args:
        result: A single SARIF result object.
        run: The parent SARIF run object (needed for rule lookups).

    Returns:
        Sorted list of unique CWE IDs (integers).
    """
    found: set[int] = set()

    # Strategy 1: result.taxa with toolComponent.name containing "cwe"
    for taxon in result.get("taxa", []):
        component = taxon.get("toolComponent", {})
        if "cwe" in component.get("name", "").lower():
            match = _CWE_PATTERN.search(taxon.get("id", ""))
            if match:
                found.add(int(match.group(1)))

    # Strategy 2: rule tags containing "cwe-XXX" (Semgrep style)
    rule_props = result.get("rule", {}).get("properties", {})
    for tag in rule_props.get("tags", []):
        match = _CWE_PATTERN.search(tag)
        if match:
            found.add(int(match.group(1)))

    # Strategy 3: ruleId matching CWE pattern
    rule_id = result.get("ruleId", "")
    for match in _CWE_PATTERN.finditer(rule_id):
        found.add(int(match.group(1)))

    # Strategy 4: run.tool.driver.rules[ruleIndex].properties.tags
    rule_index = result.get("ruleIndex")
    rules = run.get("tool", {}).get("driver", {}).get("rules", [])
    if rule_index is not None and 0 <= rule_index < len(rules):
        rule_def = rules[rule_index]
        for tag in rule_def.get("properties", {}).get("tags", []):
            match = _CWE_PATTERN.search(tag)
            if match:
                found.add(int(match.group(1)))

    # Also try matching by ruleId against rules[].id
    if rule_index is None and rule_id:
        for rule_def in rules:
            if rule_def.get("id") == rule_id:
                for tag in rule_def.get("properties", {}).get("tags", []):
                    match = _CWE_PATTERN.search(tag)
                    if match:
                        found.add(int(match.group(1)))
                # Strategy 5: rules[].relationships with CWE taxonomy
                for rel in rule_def.get("relationships", []):
                    target = rel.get("target", {})
                    target_id = target.get("id", "")
                    match = _CWE_PATTERN.search(target_id)
                    if match:
                        found.add(int(match.group(1)))
                break

    # Strategy 5 also for rule_index case
    if rule_index is not None and 0 <= rule_index < len(rules):
        rule_def = rules[rule_index]
        for rel in rule_def.get("relationships", []):
            target = rel.get("target", {})
            target_id = target.get("id", "")
            match = _CWE_PATTERN.search(target_id)
            if match:
                found.add(int(match.group(1)))

    # Strategy 6: result.properties.cwe_id (direct)
    direct_cwe = result.get("properties", {}).get("cwe_id")
    if direct_cwe is not None:
        try:
            found.add(int(direct_cwe))
        except (ValueError, TypeError):
            pass

    return sorted(found)


def _compliance_to_dict(mapping: ComplianceMapping) -> dict:
    """Convert a ComplianceMapping to the enrichment dict format."""
    return {
        "cwe_id": mapping.cwe_id,
        "cwe_name": mapping.cwe_name,
        "owasp_asvs": mapping.owasp_asvs,
        "nist_800_53": mapping.nist_800_53,
        "asd_stig": mapping.asd_stig,
        "pci_dss": mapping.pci_dss,
        "fedramp": mapping.fedramp,
        "cmmc": mapping.cmmc,
        "remediation": mapping.remediation,
    }


def _stig_severity(mapping: ComplianceMapping) -> str | None:
    """Derive a severity string from the highest STIG category."""
    cat_map = {"CAT I": "error", "CAT II": "warning", "CAT III": "note"}
    for cat in ("CAT I", "CAT II", "CAT III"):
        for entry in mapping.asd_stig:
            entry_cat = entry.get("cat", "")
            if entry_cat == cat or f"CAT {entry_cat}" == cat:
                return cat_map[cat]
    return None


def _build_taxonomy(
    all_mappings: list[ComplianceMapping],
) -> dict:
    """Build the sanicode-compliance SARIF taxonomy object.

    Deduplicates taxa entries across all mappings.
    """
    taxa: dict[str, dict] = {}

    for mapping in all_mappings:
        for entry in mapping.owasp_asvs:
            tid = f"OWASP-ASVS-{entry['id']}"
            if tid not in taxa:
                taxa[tid] = {
                    "id": tid,
                    "name": entry.get("title", entry["id"]),
                    "shortDescription": {
                        "text": entry.get("title", entry["id"])
                    },
                }

        for ctrl in mapping.nist_800_53:
            tid = f"NIST-800-53-{ctrl}"
            if tid not in taxa:
                taxa[tid] = {
                    "id": tid,
                    "name": ctrl,
                    "shortDescription": {"text": f"NIST 800-53 {ctrl}"},
                }

        for entry in mapping.asd_stig:
            tid = f"ASD-STIG-{entry['id']}"
            if tid not in taxa:
                taxa[tid] = {
                    "id": tid,
                    "name": entry.get("title", entry["id"]),
                    "shortDescription": {
                        "text": entry.get("title", entry["id"])
                    },
                }

    return {
        "name": _TAXONOMY_NAME,
        "version": __version__,
        "informationUri": _TAXONOMY_URI,
        "taxa": list(taxa.values()),
    }


def _taxa_references(mapping: ComplianceMapping) -> list[dict]:
    """Build taxaReferences for a single enriched result."""
    refs: list[dict] = []

    for entry in mapping.owasp_asvs:
        refs.append({
            "id": f"OWASP-ASVS-{entry['id']}",
            "toolComponent": {"name": _TAXONOMY_NAME},
        })

    for ctrl in mapping.nist_800_53:
        refs.append({
            "id": f"NIST-800-53-{ctrl}",
            "toolComponent": {"name": _TAXONOMY_NAME},
        })

    for entry in mapping.asd_stig:
        refs.append({
            "id": f"ASD-STIG-{entry['id']}",
            "toolComponent": {"name": _TAXONOMY_NAME},
        })

    return refs


@dataclass
class EnrichmentStats:
    """Counters for the enrichment process."""

    total_results: int = 0
    enriched: int = 0
    unenriched: int = 0
    by_framework: dict[str, int] = field(default_factory=lambda: {
        "owasp_asvs": 0,
        "nist_800_53": 0,
        "asd_stig": 0,
        "pci_dss": 0,
        "fedramp": 0,
        "cmmc": 0,
    })


def enrich_sarif(
    sarif_data: dict,
    mapper: ComplianceMapper | None = None,
) -> tuple[dict, EnrichmentStats, list[ComplianceMapping]]:
    """Enrich a parsed SARIF document with compliance cross-references.

    Modifies the SARIF data in-place and returns it along with stats.

    Args:
        sarif_data: A parsed SARIF log object (will be modified in-place).
        mapper: ComplianceMapper instance. Created automatically if None.

    Returns:
        Tuple of (enriched SARIF dict, stats, all compliance mappings used).
    """
    if mapper is None:
        mapper = ComplianceMapper()

    stats = EnrichmentStats()
    all_mappings: list[ComplianceMapping] = []

    for run in sarif_data.get("runs", []):
        for result in run.get("results", []):
            stats.total_results += 1
            cwe_ids = extract_cwe_ids(result, run)

            if not cwe_ids:
                stats.unenriched += 1
                continue

            # Collect compliance data for all CWEs on this result.
            compliance_entries: list[dict] = []
            result_mappings: list[ComplianceMapping] = []
            any_enriched = False

            for cwe_id in cwe_ids:
                mapping = mapper.map_cwe(cwe_id)
                if not mapping.cwe_name:
                    # Unknown CWE -- no compliance data available
                    continue
                any_enriched = True
                result_mappings.append(mapping)
                compliance_entries.append(_compliance_to_dict(mapping))

            if not any_enriched:
                stats.unenriched += 1
                continue

            stats.enriched += 1
            all_mappings.extend(result_mappings)

            # Track framework coverage.
            for m in result_mappings:
                if m.owasp_asvs:
                    stats.by_framework["owasp_asvs"] += 1
                if m.nist_800_53:
                    stats.by_framework["nist_800_53"] += 1
                if m.asd_stig:
                    stats.by_framework["asd_stig"] += 1
                if m.pci_dss:
                    stats.by_framework["pci_dss"] += 1
                if m.fedramp:
                    stats.by_framework["fedramp"] += 1
                if m.cmmc:
                    stats.by_framework["cmmc"] += 1

            # Write compliance data into result.properties.
            props = result.setdefault("properties", {})
            props["compliance"] = (
                compliance_entries[0]
                if len(compliance_entries) == 1
                else compliance_entries
            )

            # Add STIG-derived severity from the highest-severity mapping.
            for m in result_mappings:
                sev = _stig_severity(m)
                if sev:
                    props["stig_severity"] = sev
                    break

            # Add taxa references (clear existing sanicode refs first
            # to avoid duplication on re-enrichment).
            all_refs: list[dict] = []
            for m in result_mappings:
                all_refs.extend(_taxa_references(m))
            if all_refs:
                existing_taxa = result.get("taxa", [])
                existing_taxa = [
                    t for t in existing_taxa
                    if not (
                        isinstance(t, dict)
                        and t.get("toolComponent", {}).get("name")
                        == _TAXONOMY_NAME
                    )
                ]
                result["taxa"] = existing_taxa + all_refs

    # Add/update taxonomy at the run level.
    if all_mappings:
        taxonomy = _build_taxonomy(all_mappings)
        for run in sarif_data.get("runs", []):
            taxonomies = run.setdefault("taxonomies", [])
            # Remove any existing sanicode taxonomy to avoid duplicates.
            taxonomies[:] = [
                t for t in taxonomies
                if t.get("name") != _TAXONOMY_NAME
            ]
            taxonomies.append(taxonomy)

    return sarif_data, stats, all_mappings


def merge_sarif(sarif_documents: list[dict]) -> dict:
    """Merge multiple SARIF documents into a single log.

    Combines all runs from all inputs. Deduplicates taxonomies by name.

    Args:
        sarif_documents: List of parsed SARIF log objects.

    Returns:
        A single merged SARIF log object.
    """
    merged: dict = {
        "$schema": _SARIF_SCHEMA_URI,
        "version": _SARIF_SCHEMA_VERSION,
        "runs": [],
    }

    for doc in sarif_documents:
        for run in doc.get("runs", []):
            merged["runs"].append(copy.deepcopy(run))

    # Deduplicate taxonomies across runs by name.
    seen_taxonomies: dict[str, dict] = {}
    for run in merged["runs"]:
        deduped: list[dict] = []
        for tax in run.get("taxonomies", []):
            name = tax.get("name", "")
            if name not in seen_taxonomies:
                seen_taxonomies[name] = tax
                deduped.append(tax)
            else:
                # Keep the one with more taxa entries.
                existing = seen_taxonomies[name]
                if len(tax.get("taxa", [])) > len(
                    existing.get("taxa", [])
                ):
                    seen_taxonomies[name] = tax
                    deduped.append(tax)
        run["taxonomies"] = deduped

    return merged


def generate_json_summary(
    sarif_data: dict,
    stats: EnrichmentStats,
    input_files: list[str],
) -> dict:
    """Generate a flat JSON compliance summary from enriched SARIF data.

    Args:
        sarif_data: The enriched SARIF document.
        stats: Enrichment statistics.
        input_files: Names of the original input files.

    Returns:
        A JSON-serializable summary dict.
    """
    findings: list[dict] = []

    for run in sarif_data.get("runs", []):
        tool_name = (
            run.get("tool", {}).get("driver", {}).get("name", "unknown")
        )
        for result in run.get("results", []):
            cwe_ids = extract_cwe_ids(result, run)
            location = {}
            locations = result.get("locations", [])
            if locations:
                phys = locations[0].get("physicalLocation", {})
                artifact = phys.get("artifactLocation", {})
                region = phys.get("region", {})
                location = {
                    "file": artifact.get("uri", ""),
                    "line": region.get("startLine"),
                }

            msg = result.get("message", {})
            message = msg.get("text", "") if isinstance(msg, dict) else ""

            finding: dict = {
                "source_tool": tool_name,
                "rule_id": result.get("ruleId", ""),
                "cwe_id": cwe_ids[0] if len(cwe_ids) == 1 else cwe_ids,
                **location,
                "message": message,
            }

            compliance = result.get("properties", {}).get("compliance")
            if compliance:
                finding["compliance"] = compliance

            findings.append(finding)

    return {
        "sanicode_version": __version__,
        "enriched_at": datetime.now(timezone.utc).isoformat(),
        "input_files": input_files,
        "summary": {
            "total_results": stats.total_results,
            "enriched": stats.enriched,
            "unenriched": stats.unenriched,
            "by_framework": stats.by_framework,
        },
        "findings": findings,
    }


def load_sarif(path: Path) -> dict:
    """Load and minimally validate a SARIF file.

    Args:
        path: Path to the SARIF file.

    Returns:
        Parsed SARIF document as a dict.

    Raises:
        FileNotFoundError: If the file does not exist.
        ValueError: If the file is not valid JSON or lacks SARIF structure.
    """
    if not path.exists():
        raise FileNotFoundError(f"SARIF file not found: {path}")

    try:
        with open(path, encoding="utf-8") as fh:
            data = json.load(fh)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid JSON in {path}: {exc}") from exc

    if not isinstance(data, dict):
        raise ValueError(f"Expected a JSON object in {path}, got {type(data).__name__}")
    if "runs" not in data:
        raise ValueError(f"Missing 'runs' key in {path} -- not a valid SARIF file")

    return data
