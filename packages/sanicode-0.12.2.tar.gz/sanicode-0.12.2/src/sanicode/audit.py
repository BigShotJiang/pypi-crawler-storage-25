"""Structured audit logging for sanicode operations.

Produces JSON-line audit records for scan invocations, rule suppressions,
and configuration events. Compatible with Elasticsearch, Splunk, Loki.
"""

from __future__ import annotations

import getpass
import json
import logging
import os
from datetime import datetime, timezone

from sanicode.version import __version__

_audit_logger: logging.Logger | None = None


def _get_audit_logger() -> logging.Logger:
    """Return (and lazily initialise) the audit logger singleton."""
    global _audit_logger
    if _audit_logger is not None:
        return _audit_logger

    logger = logging.getLogger("sanicode.audit")
    logger.setLevel(logging.INFO)
    logger.propagate = False  # Don't bubble to root logger

    audit_path = os.environ.get("SANICODE_AUDIT_LOG", "sanicode-audit.jsonl")
    handler = logging.FileHandler(audit_path, encoding="utf-8")
    handler.setFormatter(logging.Formatter("%(message)s"))  # Raw JSON lines
    logger.addHandler(handler)

    _audit_logger = logger
    return logger


def reset() -> None:
    """Reset the cached logger (for testing)."""
    global _audit_logger
    if _audit_logger is not None:
        for h in list(_audit_logger.handlers):
            h.close()
            _audit_logger.removeHandler(h)
    _audit_logger = None


def _base_record(event_type: str) -> dict:
    """Build base audit record with common fields."""
    return {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "event_type": event_type,
        "sanicode_version": __version__,
        "user": _get_user(),
    }


def _get_user() -> str:
    """Get current user/service account identifier."""
    for var in ("SANICODE_USER", "USER", "USERNAME"):
        val = os.environ.get(var)
        if val:
            return val
    try:
        return getpass.getuser()
    except Exception:
        return "unknown"


def _emit(record: dict) -> None:
    """Write an audit record as a JSON line."""
    _get_audit_logger().info(json.dumps(record, default=str))


def log_scan_start(target: str, config_summary: dict) -> None:
    """Record the start of a scan invocation."""
    record = _base_record("scan_start")
    record["target"] = target
    record["config"] = config_summary
    _emit(record)


def log_scan_complete(
    target: str,
    finding_count: int,
    by_severity: dict,
    duration_sec: float,
    exit_code: int,
) -> None:
    """Record scan completion with summary."""
    record = _base_record("scan_complete")
    record["target"] = target
    record["finding_count"] = finding_count
    record["by_severity"] = by_severity
    record["duration_sec"] = round(duration_sec, 3)
    record["exit_code"] = exit_code
    _emit(record)


def log_suppression(
    rule_id: str,
    file: str,
    line: int,
    mechanism: str,
    justification: str | None = None,
) -> None:
    """Record a finding suppression.

    Args:
        rule_id: The rule that produced the suppressed finding.
        file: Source file path.
        line: Line number of the finding.
        mechanism: How it was suppressed ("baseline" or "inline").
        justification: Human-provided reason, if any.
    """
    record = _base_record("finding_suppressed")
    record["rule_id"] = rule_id
    record["file"] = file
    record["line"] = line
    record["mechanism"] = mechanism
    record["justification"] = justification
    _emit(record)


def log_config_loaded(config_path: str | None, overrides: dict | None = None) -> None:
    """Record configuration loading."""
    record = _base_record("config_loaded")
    record["config_path"] = config_path
    record["overrides"] = overrides or {}
    _emit(record)
