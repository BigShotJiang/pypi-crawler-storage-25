"""LiteLLM-backed LLM client with tiered endpoint support.

Two modes of operation:

  1. **Tier-based** (legacy): three named tiers (fast / analysis / reasoning),
     each pointing to a different model/endpoint.
  2. **Pipeline** (new): a single model with an ``augment`` or ``review``
     strategy.  ``augment`` asks the LLM to analyze code independently;
     ``review`` asks the LLM to validate deterministic findings.

All modes are optional. Sanicode operates in degraded mode when no LLM
is configured — AST patterns and graph analysis still run, LLM steps are skipped.
"""

from __future__ import annotations

import json
import os
import re
import time
from dataclasses import dataclass
from typing import Any

# Silence litellm's verbose startup logging and the first-use feedback banner.
# These environment variables must be set BEFORE the import below. The banner
# prints via print() on first LLM call, which pollutes stdout for CI pipelines
# that pipe sanicode output to jq or similar tools.
os.environ.setdefault("LITELLM_LOG", "ERROR")

import litellm  # noqa: E402

litellm.suppress_debug_info = True

from sanicode.config import LLMTierConfig  # noqa: E402
from sanicode.llm.prompts import render_prompt  # noqa: E402
from sanicode.llm.providers import get_provider  # noqa: E402
from sanicode.metrics import (  # noqa: E402
    LLM_ERRORS_TOTAL,
    LLM_REQUEST_DURATION,
    LLM_REQUESTS_TOTAL,
    LLM_TOKENS_CONSUMED,
)

_log = __import__("logging").getLogger(__name__)

# Regex for extracting the outermost JSON object or array from surrounding prose.
_JSON_EXTRACT_RE = re.compile(r'(\{[\s\S]*\}|\[[\s\S]*\])')
# Trailing commas before closing braces/brackets.
_TRAILING_COMMA_RE = re.compile(r',\s*([}\]])')


def repair_json(text: str) -> dict | list:
    """Best-effort JSON extraction and repair for LLM output.

    Handles, in order:
      1. Markdown code fences (```json ... ``` or ``` ... ```)
      2. Straight ``json.loads`` (fast path for well-formed output)
      3. Trailing comma removal
      4. Extraction of the outermost JSON structure from surrounding prose

    Returns the parsed JSON.  Raises ``json.JSONDecodeError`` if all
    repair strategies fail.
    """
    # Step 1: strip markdown fences.
    stripped = text.strip()
    fence = re.search(r'```(?:json)?\s*\n(.*?)```', stripped, re.DOTALL)
    if fence:
        stripped = fence.group(1).strip()

    # Step 2: fast-path parse.
    try:
        return json.loads(stripped)
    except json.JSONDecodeError:
        pass

    # Step 3: trailing-comma repair.
    repaired = _TRAILING_COMMA_RE.sub(r'\1', stripped)
    try:
        return json.loads(repaired)
    except json.JSONDecodeError:
        pass

    # Step 4: extract JSON from surrounding prose.
    match = _JSON_EXTRACT_RE.search(stripped)
    if match:
        extracted = _TRAILING_COMMA_RE.sub(r'\1', match.group(1))
        try:
            return json.loads(extracted)
        except json.JSONDecodeError:
            pass

    # All strategies failed — raise with the original text for debugging.
    _log.debug("JSON repair failed on (first 500 chars): %.500s", text)
    return json.loads(stripped)


class LLMNotConfiguredError(RuntimeError):
    """Raised when an LLM operation is attempted with no endpoint configured."""


@dataclass
class LLMResponse:
    """Structured response from an LLM call."""

    content: str
    model: str
    tier: str
    usage: dict[str, int]

    def parse_json(self) -> dict:
        """Extract and parse JSON from the response, with repair.

        Handles common LLM output issues: markdown fences, trailing
        commas, surrounding prose, and other malformed JSON.

        Returns:
            The parsed JSON as a dict.

        Raises:
            ValueError: If the response content is empty.
            json.JSONDecodeError: If the content is not valid JSON after repair.
        """
        text = self.content.strip()
        if not text:
            raise ValueError("Empty LLM response")
        return repair_json(text)


class LLMClient:
    """Multi-tier LLM client for Sanicode analysis tasks.

    Each method corresponds to a specific analysis tier. If the endpoint
    for a tier is not configured, LLMNotConfiguredError is raised with
    instructions for setting up the endpoint via sanicode.toml.
    """

    def __init__(
        self,
        fast: LLMTierConfig | None = None,
        analysis: LLMTierConfig | None = None,
        reasoning: LLMTierConfig | None = None,
        *,
        pipeline_provider: str = "",
        pipeline_model: str = "",
        pipeline_strategy: str = "",
        pipeline_endpoint: str = "",
        pipeline_api_key: str | None = None,
    ) -> None:
        self._tiers: dict[str, LLMTierConfig | None] = {
            "fast": fast,
            "analysis": analysis,
            "reasoning": reasoning,
        }
        self._pipeline_provider = pipeline_provider
        self._pipeline_model = pipeline_model
        self._pipeline_strategy = pipeline_strategy
        self._pipeline_endpoint = pipeline_endpoint
        self._pipeline_api_key = pipeline_api_key

    @property
    def pipeline_strategy(self) -> str:
        """The configured pipeline strategy ("augment", "review", or "")."""
        return self._pipeline_strategy

    @property
    def has_pipeline(self) -> bool:
        """Whether the augment/review pipeline is fully configured."""
        return bool(self._pipeline_model and self._pipeline_strategy)

    @classmethod
    def from_config(cls, config: Any) -> LLMClient:
        """Construct an LLMClient from a SanicodeConfig instance.

        Args:
            config: A SanicodeConfig (or any object with a .llm attribute).
        """
        llm_cfg = config.llm
        provider, model, strategy, endpoint, api_key = llm_cfg.resolve()
        return cls(
            fast=llm_cfg.fast if llm_cfg.fast.model else None,
            analysis=llm_cfg.analysis if llm_cfg.analysis.model else None,
            reasoning=llm_cfg.reasoning if llm_cfg.reasoning.model else None,
            pipeline_provider=provider,
            pipeline_model=model,
            pipeline_strategy=strategy,
            pipeline_endpoint=endpoint,
            pipeline_api_key=api_key,
        )

    def has_tier(self, tier_name: str) -> bool:
        """Check whether a tier is configured without raising.

        Args:
            tier_name: One of "fast", "analysis", "reasoning".

        Returns:
            True if the tier has a configured endpoint, False otherwise.
        """
        return self._tiers.get(tier_name) is not None

    def _require_tier(self, tier_name: str) -> LLMTierConfig:
        tier = self._tiers.get(tier_name)
        if tier is None:
            raise LLMNotConfiguredError(
                f"No LLM configured for the '{tier_name}' tier. "
                f"Add an [llm.{tier_name}] section to your sanicode.toml with "
                "a model field (and provider for cloud APIs, or endpoint for "
                "self-hosted), then run 'sanicode config --show' to verify."
            )
        return tier

    def _call_tier(self, tier_name: str, prompt: str, **kwargs: Any) -> LLMResponse:
        """Send a prompt to the specified tier's model via LiteLLM.

        Args:
            tier_name: One of "fast", "analysis", "reasoning".
            prompt: The prompt to send.
            **kwargs: Additional arguments forwarded to litellm.completion().

        Returns:
            An LLMResponse with the model's output.
        """
        tier = self._require_tier(tier_name)
        start = time.monotonic()
        try:
            provider_info = get_provider(tier.provider)
            litellm_prefix = provider_info.litellm_prefix if provider_info else tier.provider
            call_kwargs: dict[str, Any] = {
                "model": f"{litellm_prefix}/{tier.model}",
                "messages": [{"role": "user", "content": prompt}],
                "timeout": tier.timeout_seconds,
            }
            if tier.endpoint:
                call_kwargs["api_base"] = tier.endpoint
            if tier.api_key:
                call_kwargs["api_key"] = tier.api_key
            elif tier.endpoint:
                # Self-hosted or endpoint-based: only inject placeholder key
                # if the provider doesn't need real auth (e.g., vllm, ollama).
                # For providers that need auth even with an endpoint (e.g., Azure),
                # let LiteLLM pick up credentials from env vars.
                if provider_info is None or not provider_info.needs_api_key:
                    call_kwargs["api_key"] = "unused"
            call_kwargs.update(kwargs)
            response = litellm.completion(**call_kwargs)
            choice = response.choices[0]
            usage = response.usage

            LLM_REQUESTS_TOTAL.labels(model=tier.model, tier=tier_name).inc()
            LLM_REQUEST_DURATION.labels(tier=tier_name).observe(time.monotonic() - start)
            if usage:
                LLM_TOKENS_CONSUMED.labels(tier=tier_name, direction="prompt").inc(
                    usage.prompt_tokens or 0
                )
                LLM_TOKENS_CONSUMED.labels(tier=tier_name, direction="completion").inc(
                    usage.completion_tokens or 0
                )

            return LLMResponse(
                content=choice.message.content or "",
                model=response.model or tier.model,
                tier=tier_name,
                usage={
                    "prompt_tokens": usage.prompt_tokens if usage else 0,
                    "completion_tokens": usage.completion_tokens if usage else 0,
                    "total_tokens": usage.total_tokens if usage else 0,
                },
            )
        except Exception as exc:
            LLM_ERRORS_TOTAL.labels(model=tier.model, error_type=type(exc).__name__).inc()
            LLM_REQUEST_DURATION.labels(tier=tier_name).observe(time.monotonic() - start)
            raise

    def test_connection(self, tier_name: str) -> LLMResponse:
        """Send a minimal test prompt to verify connectivity.

        Args:
            tier_name: One of "fast", "analysis", "reasoning".

        Returns:
            An LLMResponse from the tier's model.

        Raises:
            LLMNotConfiguredError: If the tier is not configured.
        """
        return self._call_tier(tier_name, "Say 'ok'.", timeout=5)

    def classify(self, prompt: str, **kwargs: Any) -> LLMResponse:
        """Run a fast classification task using the 'fast' tier.

        Typical use: determine whether a detected pattern is a true positive.

        Args:
            prompt: The prompt to send to the model.

        Returns:
            An LLMResponse from the fast-tier model.
        """
        return self._call_tier("fast", prompt, **kwargs)

    def analyze(self, prompt: str, **kwargs: Any) -> LLMResponse:
        """Run a data flow analysis task using the 'analysis' tier.

        Typical use: assess whether data flow paths are sanitized end-to-end.

        Args:
            prompt: The prompt to send to the model.

        Returns:
            An LLMResponse from the analysis-tier model.
        """
        return self._call_tier("analysis", prompt, **kwargs)

    def reason(self, prompt: str, **kwargs: Any) -> LLMResponse:
        """Run compliance reasoning using the 'reasoning' tier.

        Typical use: generate compliance-mapped remediation recommendations.

        Args:
            prompt: The prompt to send to the model.

        Returns:
            An LLMResponse from the reasoning-tier model.
        """
        return self._call_tier("reasoning", prompt, **kwargs)

    # ------------------------------------------------------------------
    # Augment / review pipeline
    # ------------------------------------------------------------------

    def _call_pipeline(self, prompt: str, **kwargs: Any) -> LLMResponse:
        """Send a prompt to the pipeline model via LiteLLM.

        Uses ``_pipeline_*`` attributes instead of tier config.  Raises
        :class:`LLMNotConfiguredError` if the pipeline is not configured.

        Args:
            prompt: The rendered prompt to send.
            **kwargs: Additional arguments forwarded to litellm.completion().

        Returns:
            An LLMResponse with the model's output.
        """
        if not self.has_pipeline:
            raise LLMNotConfiguredError(
                "No pipeline model configured. Set [llm] preset, or explicit "
                "model + strategy fields in sanicode.toml."
            )

        tier_label = "pipeline"
        start = time.monotonic()
        try:
            provider_info = get_provider(self._pipeline_provider)
            litellm_prefix = (
                provider_info.litellm_prefix if provider_info else self._pipeline_provider
            )
            call_kwargs: dict[str, Any] = {
                "model": f"{litellm_prefix}/{self._pipeline_model}",
                "messages": [{"role": "user", "content": prompt}],
            }
            if self._pipeline_endpoint:
                call_kwargs["api_base"] = self._pipeline_endpoint
            if self._pipeline_api_key:
                call_kwargs["api_key"] = self._pipeline_api_key
            elif self._pipeline_endpoint:
                if provider_info is None or not provider_info.needs_api_key:
                    call_kwargs["api_key"] = "unused"
            call_kwargs.update(kwargs)
            response = litellm.completion(**call_kwargs)
            choice = response.choices[0]
            usage = response.usage

            LLM_REQUESTS_TOTAL.labels(
                model=self._pipeline_model, tier=tier_label
            ).inc()
            LLM_REQUEST_DURATION.labels(tier=tier_label).observe(
                time.monotonic() - start
            )
            if usage:
                LLM_TOKENS_CONSUMED.labels(
                    tier=tier_label, direction="prompt"
                ).inc(usage.prompt_tokens or 0)
                LLM_TOKENS_CONSUMED.labels(
                    tier=tier_label, direction="completion"
                ).inc(usage.completion_tokens or 0)

            return LLMResponse(
                content=choice.message.content or "",
                model=response.model or self._pipeline_model,
                tier=tier_label,
                usage={
                    "prompt_tokens": usage.prompt_tokens if usage else 0,
                    "completion_tokens": usage.completion_tokens if usage else 0,
                    "total_tokens": usage.total_tokens if usage else 0,
                },
            )
        except Exception as exc:
            LLM_ERRORS_TOTAL.labels(
                model=self._pipeline_model, error_type=type(exc).__name__
            ).inc()
            LLM_REQUEST_DURATION.labels(tier=tier_label).observe(
                time.monotonic() - start
            )
            raise

    def augment(self, code: str, graph_data: str) -> LLMResponse:
        """Run augment strategy: LLM analyzes code with CPG context independently.

        Args:
            code: Source code to analyze.
            graph_data: JSON-serialized Code Property Graph data.

        Returns:
            An LLMResponse containing the model's vulnerability analysis.
        """
        prompt = render_prompt("augment", code=code, graph_data=graph_data)
        return self._call_pipeline(prompt)

    def review(self, code: str, graph_data: str, findings: str) -> LLMResponse:
        """Run review strategy: LLM reviews deterministic findings with CPG context.

        Args:
            code: Source code to analyze.
            graph_data: JSON-serialized Code Property Graph data.
            findings: JSON-serialized list of deterministic findings to review.

        Returns:
            An LLMResponse containing the model's finding reviews.
        """
        prompt = render_prompt(
            "review", code=code, graph_data=graph_data, findings=findings
        )
        return self._call_pipeline(prompt)

    def tiebreak(
        self,
        code: str,
        graph_data: str,
        rule_id: str,
        cwe_id: str,
        line: str,
        message: str,
        llm_assessment: str,
        llm_reasoning: str,
    ) -> LLMResponse:
        """Run tiebreaker: resolve disagreement between deterministic and LLM.

        Only called when Pass 1 and Pass 2 disagree on a finding.

        Args:
            code: Source code containing the finding.
            graph_data: JSON-serialized CPG data.
            rule_id: The rule ID of the disputed finding.
            cwe_id: CWE ID as a string.
            line: Line number as a string.
            message: The finding's message.
            llm_assessment: The LLM's dissenting assessment.
            llm_reasoning: The LLM's reasoning for disagreeing.

        Returns:
            An LLMResponse containing the tiebreaker verdict.
        """
        prompt = render_prompt(
            "tiebreaker",
            code=code,
            graph_data=graph_data,
            rule_id=rule_id,
            cwe_id=cwe_id,
            line=line,
            message=message,
            llm_assessment=llm_assessment,
            llm_reasoning=llm_reasoning,
        )
        return self._call_pipeline(prompt)
