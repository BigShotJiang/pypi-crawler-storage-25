"""Markdown report generator."""

from __future__ import annotations

from sanicode.report.persist import ScanResult

_SEVERITY_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
_ALL_SEVERITIES = ["critical", "high", "medium", "low", "info"]


def _effective_severity(finding: dict) -> str:
    return finding.get("derived_severity") or finding.get("severity", "info")


def _format_compliance(compliance: dict) -> list[str]:
    """Return formatted compliance lines for a finding's compliance block."""
    lines: list[str] = []

    owasp = compliance.get("owasp_asvs")
    if owasp:
        ids = ", ".join(item["id"] for item in owasp if item.get("id"))
        level = owasp[0].get("level") if owasp else None
        entry = f"- OWASP ASVS: {ids}"
        if level:
            entry += f" ({level})"
        lines.append(entry)

    nist = compliance.get("nist_800_53")
    if nist:
        lines.append(f"- NIST 800-53: {', '.join(nist)}")

    stig = compliance.get("asd_stig")
    if stig:
        ids = ", ".join(item["id"] for item in stig if item.get("id"))
        cat = stig[0].get("cat") if stig else None
        entry = f"- ASD STIG: {ids}"
        if cat:
            entry += f" ({cat})"
        lines.append(entry)

    pci = compliance.get("pci_dss")
    if pci:
        lines.append(f"- PCI DSS: {', '.join(pci)}")

    fedramp = compliance.get("fedramp")
    if fedramp:
        lines.append(f"- FedRAMP: {', '.join(b.capitalize() for b in fedramp)}")

    cmmc = compliance.get("cmmc")
    if cmmc:
        ids = ", ".join(item["id"] for item in cmmc if item.get("id"))
        level = cmmc[0].get("level") if cmmc else None
        entry = f"- CMMC 2.0: {ids}"
        if level:
            entry += f" (Level {level})"
        lines.append(entry)

    return lines


def _format_domain_reachability(dr: dict) -> list[str]:
    """Format the domain reachability section for the markdown report."""
    lines = [
        "### Domain Reachability Analysis",
        "",
        f"**Strategy:** {dr.get('strategy', 'unknown')}",
        "",
    ]

    # Entry points by domain.
    domain_eps = dr.get("domain_entry_points", {})
    if domain_eps:
        lines.append("**Entry points by domain:**")
        lines.append("")
        lines.append("| Domain | Entry Points |")
        lines.append("|--------|------------:|")
        for domain, count in sorted(domain_eps.items()):
            lines.append(f"| {domain} | {count} |")
        lines.append("")

    unclassified = dr.get("unclassified_entry_points", 0)
    if unclassified:
        lines.append(f"**Unclassified entry points:** {unclassified}")
        lines.append("")

    # Node classification counts.
    lines.append("**Node classifications:**")
    lines.append("")
    lines.append("| Classification | Count |")
    lines.append("|----------------|------:|")

    exclusive_counts = dr.get("exclusive_counts", {})
    for domain, count in sorted(exclusive_counts.items()):
        if count > 0:
            lines.append(f"| Exclusive ({domain}) | {count} |")

    shared = dr.get("shared_count", 0)
    if shared:
        lines.append(f"| Shared | {shared} |")

    unreachable = dr.get("unreachable_count", 0)
    if unreachable:
        lines.append(f"| Unreachable | {unreachable} |")

    unclassified_reachable = dr.get("unclassified_reachable_count", 0)
    if unclassified_reachable:
        lines.append(f"| Unclassified Reachable | {unclassified_reachable} |")

    lines.append("")

    return lines


def _format_pruning_plan(pp: dict) -> list[str]:
    """Format the pruning plan section for the markdown report."""
    lines = [
        "### Pruning Plan",
        "",
        f"**Remove domain:** {pp.get('remove_domain', 'unknown')}  ",
        f"**Strategy:** {pp.get('strategy', 'unknown')}",
        "",
    ]

    safe_to_prune = pp.get("safe_to_prune", [])
    needs_analysis = pp.get("needs_analysis", [])
    safe_to_keep = pp.get("safe_to_keep_count", 0)

    # Safe to Prune table.
    lines.append(f"**Safe to Prune** ({len(safe_to_prune)} nodes)")
    lines.append("")
    if safe_to_prune:
        lines.append("| Node | File:Line | Kind | Confidence |")
        lines.append("|------|-----------|------|------------|")
        for node in safe_to_prune:
            label = node.get("label", node.get("node_id", ""))
            file_val = node.get("file", "")
            line_val = node.get("line", "")
            loc = f"{file_val}:{line_val}" if file_val else ""
            kind = node.get("kind", "")
            conf = node.get("confidence", "")
            lines.append(f"| {label} | {loc} | {kind} | {conf} |")
        lines.append("")

    # Needs Analysis table.
    lines.append(f"**Needs Analysis** ({len(needs_analysis)} nodes)")
    lines.append("")
    if needs_analysis:
        lines.append(
            "| Node | File:Line | Kind | Shared With "
            "| Confidence | Relationship | Suggested Action |"
        )
        lines.append("|------|-----------|------|-------------|------------|--------------|------------------|")
        for node in needs_analysis:
            label = node.get("label", node.get("node_id", ""))
            file_val = node.get("file", "")
            line_val = node.get("line", "")
            loc = f"{file_val}:{line_val}" if file_val else ""
            kind = node.get("kind", "")
            shared = ", ".join(node.get("shared_with", []))
            conf = node.get("confidence", "")
            rel = node.get("relationship_type", "")
            action = node.get("suggested_action", "")
            lines.append(f"| {label} | {loc} | {kind} | {shared} | {conf} | {rel} | {action} |")
        lines.append("")

    # Content to Scrub table.
    content_matches = pp.get("content_policy_matches", [])
    if content_matches:
        noun = "match" if len(content_matches) == 1 else "matches"
        lines.append(f"**Content to Scrub** ({len(content_matches)} {noun})")
        lines.append("")
        lines.append("| Pattern | File:Line | Severity | Message |")
        lines.append("|---------|-----------|----------|---------|")
        for match in content_matches:
            pattern = match.get("rule_id", "")
            file_val = match.get("file", "")
            line_val = match.get("line", "")
            loc = f"{file_val}:{line_val}" if file_val else ""
            severity = match.get("severity", "")
            message = match.get("message", "")
            lines.append(f"| {pattern} | {loc} | {severity} | {message} |")
        lines.append("")

    lines.append(f"**Safe to Keep:** {safe_to_keep} nodes")
    lines.append("")

    return lines


def generate_markdown(result: ScanResult) -> str:
    """Generate a Markdown-formatted security report from a ScanResult.

    Findings are sorted by severity (critical first), then by file path,
    then by line number. Uses ``derived_severity`` when present, falling
    back to ``severity``.

    Args:
        result: Completed ScanResult produced by the scanner.

    Returns:
        A Markdown string suitable for writing to a .md file or stdout.
    """
    lines: list[str] = []

    # Header
    lines += [
        "# Sanicode Security Report",
        "",
        f"**Scanned:** {result.scanned_path}  ",
        f"**Date:** {result.scan_timestamp}  ",
        f"**Scan ID:** {result.scan_id}  ",
        f"**Sanicode Version:** {result.sanicode_version}",
        "",
    ]

    # Summary table
    summary = result.summary
    by_severity: dict[str, int] = summary.get("by_severity", {})
    total = summary.get("total_findings", len(result.findings))

    lines += [
        "## Summary",
        "",
        "| Severity | Count |",
        "|----------|------:|",
    ]
    for sev in _ALL_SEVERITIES:
        lines.append(f"| {sev.capitalize()} | {by_severity.get(sev, 0)} |")

    lines += [
        "",
        f"**Total findings:** {total}",
        "",
    ]

    # Knowledge graph stats (optional block)
    graph_nodes = summary.get("graph_nodes")
    if graph_nodes is not None:
        entry_points = summary.get("graph_entry_points", 0)
        sinks = summary.get("graph_sinks", 0)
        sanitizers = summary.get("graph_sanitizers", 0)
        graph_edges = summary.get("graph_edges", 0)
        lines += [
            "### Knowledge Graph",
            "",
            f"- **Nodes:** {graph_nodes} "
            f"(entry points: {entry_points}, sinks: {sinks}, sanitizers: {sanitizers})",
            f"- **Edges:** {graph_edges}",
            "",
        ]

    # Domain reachability analysis (optional block)
    dr = summary.get("domain_reachability")
    if dr:
        lines += _format_domain_reachability(dr)

    # Pruning plan (optional block)
    pp = summary.get("pruning_plan")
    if pp:
        lines += _format_pruning_plan(pp)

    # Truncation warning (optional)
    truncated = summary.get("graph_truncated_path_pairs", 0)
    if truncated > 0:
        lines += [
            "### Warnings",
            "",
            f"**{truncated} entry-to-sink path pair(s)** were truncated by the "
            f"graph depth cutoff. Some attack paths may exceed the configured "
            f"depth limit and are not reflected in the findings above.",
            "",
            "Re-run with `--graph-depth <N>` (e.g. `--graph-depth 20`) to "
            "include longer paths.",
            "",
        ]

    # Findings section
    lines.append("## Findings")

    if not result.findings:
        lines += ["", "No security findings detected."]
        return "\n".join(lines)

    sorted_findings = sorted(
        result.findings,
        key=lambda f: (
            _SEVERITY_ORDER.get(_effective_severity(f), 4),
            f.get("file", ""),
            f.get("line", 0),
        ),
    )

    for i, finding in enumerate(sorted_findings):
        sev = _effective_severity(finding)
        rule_id = finding.get("rule_id", "")
        message = finding.get("message", "")
        cwe_id = finding.get("cwe_id")
        cwe_name = finding.get("cwe_name", "")
        file_path = finding.get("file", "")
        line = finding.get("line", "")
        compliance = finding.get("compliance")
        remediation = finding.get("remediation") or (
            compliance.get("remediation") if compliance else None
        )

        cwe_suffix = f" (CWE-{cwe_id})" if cwe_id else ""
        lines += [
            "",
            f"### [{sev.upper()}] {rule_id} — {message}{cwe_suffix}",
            "",
            f"**File:** {file_path}:{line}  ",
            f"**Severity:** {sev}  ",
        ]

        if cwe_id:
            cwe_label = f"CWE-{cwe_id}"
            if cwe_name:
                cwe_label += f" ({cwe_name})"
            lines.append(f"**CWE:** {cwe_label}")

        if compliance:
            compliance_lines = _format_compliance(compliance)
            if compliance_lines:
                lines += ["", "**Compliance:**"] + compliance_lines

        if remediation:
            lines += ["", f"**Remediation:** {remediation}"]

        minority_report = finding.get("minority_report")
        if minority_report is not None:
            dissenter = minority_report.get("dissenter", "unknown")
            assessment = minority_report.get("assessment", "")
            reasoning = minority_report.get("reasoning", "")
            dissenter_label = {
                "llm": "LLM dissent",
                "llm_pass2": "LLM Pass 2 dissent",
                "deterministic": "Deterministic dissent",
            }.get(dissenter, f"{dissenter} dissent")
            assessment_text = (
                f" The AI analysis considers this a {assessment}."
                if assessment
                else ""
            )
            lines += [
                "",
                f"> **Minority Report** (*{dissenter_label}*):{assessment_text}",
                f"> Reasoning: {reasoning}",
            ]

            tb_verdict = minority_report.get("tiebreaker_verdict")
            tb_reasoning = minority_report.get("tiebreaker_reasoning")
            if tb_verdict:
                source = finding.get("source", "")
                vote_label = (
                    "2-1 in favor of static analysis"
                    if source == "2-1 deterministic"
                    else "2-1 in favor of LLM"
                )
                lines += [
                    f"> **Tiebreaker verdict:** {tb_verdict} ({vote_label})",
                    f"> Tiebreaker reasoning: {tb_reasoning}",
                ]

        if i < len(sorted_findings) - 1:
            lines += ["", "---"]

    return "\n".join(lines)
