"""Compare two scan results and produce a structured delta."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

# Severity weights for scoring — a critical SQL injection fix counts more
# than a low-severity informational finding.
SEVERITY_WEIGHT = {
    "critical": 10,
    "high": 5,
    "medium": 2,
    "low": 1,
    "info": 0,
}


def _finding_key(finding: dict) -> str:
    """Build a matching key from a serialized finding.

    Uses rule_id + file basename + line for matching. File basename is used
    instead of full path because scans may be run from different roots.
    """
    f = Path(finding.get("file", "")).name
    return f"{finding['rule_id']}:{f}:{finding['line']}"


def _effective_severity(finding: dict) -> str:
    """Return derived_severity if present, else severity."""
    return finding.get("derived_severity") or finding.get("severity", "medium")


@dataclass
class DiffResult:
    """Structured comparison between two scan results."""

    added: list[dict] = field(default_factory=list)
    removed: list[dict] = field(default_factory=list)
    unchanged: list[dict] = field(default_factory=list)

    # Summaries
    baseline_count: int = 0
    current_count: int = 0

    @property
    def baseline_score(self) -> int:
        """Severity-weighted score for baseline."""
        score = 0
        for f in self.removed:
            score += SEVERITY_WEIGHT.get(_effective_severity(f), 1)
        for f in self.unchanged:
            score += SEVERITY_WEIGHT.get(_effective_severity(f), 1)
        return score

    @property
    def current_score(self) -> int:
        """Severity-weighted score for current."""
        score = 0
        for f in self.added:
            score += SEVERITY_WEIGHT.get(_effective_severity(f), 1)
        for f in self.unchanged:
            score += SEVERITY_WEIGHT.get(_effective_severity(f), 1)
        return score

    @property
    def score_delta(self) -> int:
        """Negative means improvement, positive means regression."""
        return self.current_score - self.baseline_score

    def by_severity(self, findings: list[dict]) -> dict[str, int]:
        """Count findings grouped by effective severity."""
        counts: dict[str, int] = {}
        for f in findings:
            sev = _effective_severity(f)
            counts[sev] = counts.get(sev, 0) + 1
        return counts

    def by_cwe(self, findings: list[dict]) -> dict[str, int]:
        """Count findings grouped by CWE."""
        counts: dict[str, int] = {}
        for f in findings:
            cwe = f"CWE-{f.get('cwe_id', '?')}"
            counts[cwe] = counts.get(cwe, 0) + 1
        return counts

    def to_dict(self) -> dict:
        """Serialize to a JSON-compatible dict."""
        return {
            "summary": {
                "baseline_findings": self.baseline_count,
                "current_findings": self.current_count,
                "added": len(self.added),
                "removed": len(self.removed),
                "unchanged": len(self.unchanged),
                "baseline_score": self.baseline_score,
                "current_score": self.current_score,
                "score_delta": self.score_delta,
            },
            "added": self.added,
            "removed": self.removed,
        }


def compare_scan_results(
    baseline_path: Path,
    current_path: Path,
) -> DiffResult:
    """Compare two scan-result JSON files and return a DiffResult.

    Finding matching uses rule_id + file basename + line number. This is
    intentionally based on basename (not full path) so scans of the same
    code from different working directories can still be compared.
    """
    baseline_data = json.loads(baseline_path.read_text(encoding="utf-8"))
    current_data = json.loads(current_path.read_text(encoding="utf-8"))

    baseline_findings = baseline_data.get("findings", [])
    current_findings = current_data.get("findings", [])

    # Index by key
    baseline_by_key = {}
    for f in baseline_findings:
        key = _finding_key(f)
        baseline_by_key[key] = f

    current_by_key = {}
    for f in current_findings:
        key = _finding_key(f)
        current_by_key[key] = f

    baseline_keys = set(baseline_by_key)
    current_keys = set(current_by_key)

    return DiffResult(
        added=[current_by_key[k] for k in sorted(current_keys - baseline_keys)],
        removed=[baseline_by_key[k] for k in sorted(baseline_keys - current_keys)],
        unchanged=[current_by_key[k] for k in sorted(baseline_keys & current_keys)],
        baseline_count=len(baseline_findings),
        current_count=len(current_findings),
    )
