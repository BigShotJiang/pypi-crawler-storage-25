"""POA&M (Plan of Action and Milestones) report generation.

Generates POA&M entries from sanicode scan findings, grouped by CWE ID.
POA&M is a required artifact for federal ATO (Authority to Operate) packages.
Output formats: CSV (for eMASS/XACTA import), JSON, and Markdown summary.

Scheduled completion dates are derived from STIG CAT levels:
  CAT I  (critical/high) — 30 days
  CAT II (medium)        — 90 days
  CAT III (low)          — 180 days
"""

from __future__ import annotations

import csv
import io
from datetime import datetime, timedelta

from sanicode.report.persist import ScanResult
from sanicode.version import __version__

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_SEVERITY_ORDER = {
    "critical": 5,
    "high": 4,
    "medium": 3,
    "low": 2,
    "info": 1,
}

_CAT_ORDER = {"I": 1, "II": 2, "III": 3}

_CAT_COMPLETION_DAYS = {
    "I": 30,
    "II": 90,
    "III": 180,
}

_SEVERITY_TO_CAT = {
    "critical": "I",
    "high": "I",
    "medium": "II",
    "low": "III",
    "info": "III",
}

_DEFAULT_COMPLETION_DAYS = 180

_CSV_HEADERS = [
    "POA&M ID",
    "Weakness Name",
    "CWE",
    "Severity",
    "STIG ID",
    "STIG CAT",
    "NIST Controls",
    "CMMC Practices",
    "Status",
    "Detection Date",
    "Scheduled Completion",
    "Point of Contact",
    "Affected Files",
    "Remediation Plan",
]


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _parse_scan_date(timestamp: str) -> datetime:
    """Parse an ISO 8601 scan timestamp into a datetime."""
    # Handle both timezone-aware and naive timestamps
    try:
        return datetime.fromisoformat(timestamp)
    except ValueError:
        # Fallback: strip trailing Z and parse as UTC-naive
        cleaned = timestamp.rstrip("Z")
        return datetime.fromisoformat(cleaned)


def _best_cat(findings: list[dict]) -> str | None:
    """Return the most severe (lowest numeral) CAT across findings.

    Returns None if no STIG data is available.
    """
    best: str | None = None
    best_order = 999

    for f in findings:
        compliance = f.get("compliance") or {}
        for entry in compliance.get("asd_stig") or []:
            cat_raw = entry.get("cat", "")
            # Normalize "CAT I" -> "I", "I" -> "I"
            cat = cat_raw.replace("CAT ", "").strip()
            order = _CAT_ORDER.get(cat, 999)
            if order < best_order:
                best_order = order
                best = cat

    return best


def _best_severity(findings: list[dict]) -> str:
    """Return the highest severity across findings."""
    best = "info"
    best_order = 0

    for f in findings:
        sev = f.get("derived_severity") or f.get("severity", "info")
        order = _SEVERITY_ORDER.get(sev, 0)
        if order > best_order:
            best_order = order
            best = sev

    return best


def _collect_stig_ids(findings: list[dict]) -> list[str]:
    """Collect unique STIG IDs across findings, preserving order."""
    seen: set[str] = set()
    result: list[str] = []
    for f in findings:
        compliance = f.get("compliance") or {}
        for entry in compliance.get("asd_stig") or []:
            stig_id = entry.get("id", "")
            if stig_id and stig_id not in seen:
                seen.add(stig_id)
                result.append(stig_id)
    return result


def _collect_nist_controls(findings: list[dict]) -> list[str]:
    """Collect unique NIST 800-53 controls across findings."""
    seen: set[str] = set()
    result: list[str] = []
    for f in findings:
        compliance = f.get("compliance") or {}
        for ctrl in compliance.get("nist_800_53") or []:
            if ctrl and ctrl not in seen:
                seen.add(ctrl)
                result.append(ctrl)
    return result


def _collect_cmmc_practices(findings: list[dict]) -> list[str]:
    """Collect unique CMMC 2.0 practice IDs across findings, preserving order."""
    seen: set[str] = set()
    result: list[str] = []
    for f in findings:
        compliance = f.get("compliance") or {}
        for entry in compliance.get("cmmc") or []:
            practice_id = entry.get("id", "") if isinstance(entry, dict) else str(entry)
            if practice_id and practice_id not in seen:
                seen.add(practice_id)
                result.append(practice_id)
    return result


def _collect_file_locations(findings: list[dict]) -> list[str]:
    """Build file:line location strings for all findings."""
    locations: list[str] = []
    for f in findings:
        file_path = f.get("file", "")
        line = f.get("line", "")
        locations.append(f"{file_path}:{line}")
    return locations


def _best_remediation(findings: list[dict]) -> str:
    """Pick the most informative remediation string from the group."""
    for f in findings:
        # Prefer compliance-level remediation
        compliance = f.get("compliance") or {}
        rem = compliance.get("remediation", "")
        if rem:
            return rem
    for f in findings:
        rem = f.get("remediation", "")
        if rem:
            return rem
    return "Remediation required"


def _completion_days(cat: str | None, severity: str) -> int:
    """Compute completion days from CAT level, falling back to severity."""
    if cat:
        return _CAT_COMPLETION_DAYS.get(cat, _DEFAULT_COMPLETION_DAYS)
    mapped_cat = _SEVERITY_TO_CAT.get(severity)
    if mapped_cat:
        return _CAT_COMPLETION_DAYS.get(
            mapped_cat, _DEFAULT_COMPLETION_DAYS
        )
    return _DEFAULT_COMPLETION_DAYS


def _format_date(dt: datetime) -> str:
    """Format a datetime as YYYY-MM-DD."""
    return dt.strftime("%Y-%m-%d")


def _build_milestones(
    detection: datetime, days: int,
) -> list[dict]:
    """Build the three standard milestones for a POA&M entry."""
    completion = detection + timedelta(days=days)
    halfway = detection + timedelta(days=days // 2)
    return [
        {
            "milestone": "Identify root cause and remediation approach",
            "due_date": _format_date(detection + timedelta(days=7)),
        },
        {
            "milestone": "Implement remediation",
            "due_date": _format_date(halfway),
        },
        {
            "milestone": "Verify remediation and close",
            "due_date": _format_date(completion),
        },
    ]


def _group_findings_by_cwe(
    findings: list[dict],
) -> dict[int, list[dict]]:
    """Group findings by CWE ID. Findings without a CWE use 0."""
    grouped: dict[int, list[dict]] = {}
    for f in findings:
        cwe = f.get("cwe_id", 0) or 0
        grouped.setdefault(cwe, []).append(f)
    return grouped


def _build_entries(result: ScanResult) -> list[dict]:
    """Build the list of POA&M entry dicts from a ScanResult."""
    grouped = _group_findings_by_cwe(result.findings)
    detection = _parse_scan_date(result.scan_timestamp)
    entries: list[dict] = []

    # Sort by CWE ID for stable ordering
    for poam_id, cwe_id in enumerate(sorted(grouped.keys()), start=1):
        group = grouped[cwe_id]
        cat = _best_cat(group)
        severity = _best_severity(group)
        days = _completion_days(cat, severity)
        scheduled = detection + timedelta(days=days)
        stig_ids = _collect_stig_ids(group)
        nist_controls = _collect_nist_controls(group)
        cmmc_practices = _collect_cmmc_practices(group)
        file_locations = _collect_file_locations(group)

        # Use the CWE name from the first finding that has one
        cwe_name = ""
        if cwe_id == 0:
            cwe_name = "Unknown Weakness"
        else:
            for f in group:
                name = f.get("cwe_name", "")
                if name:
                    cwe_name = name
                    break

        # Build weakness description from first finding's message
        first_msg = group[0].get("message", "")
        compliance_desc = (
            (group[0].get("compliance") or {}).get("description", "")
        )
        description = first_msg
        if compliance_desc:
            description = f"{first_msg} — {compliance_desc}"

        entries.append({
            "poam_id": poam_id,
            "weakness_name": cwe_name or f"CWE-{cwe_id}",
            "weakness_description": description,
            "cwe_id": cwe_id,
            "source": f"sanicode scan {result.scan_id}",
            "detection_date": _format_date(detection),
            "severity": severity,
            "stig_id": stig_ids[0] if stig_ids else "",
            "stig_cat": cat or "",
            "nist_controls": nist_controls,
            "cmmc_practices": cmmc_practices,
            "status": "Open",
            "point_of_contact": "[POC Required]",
            "resources_required": "Developer remediation",
            "scheduled_completion_date": _format_date(scheduled),
            "milestones": _build_milestones(detection, days),
            "file_locations": file_locations,
            "affected_count": len(group),
            "remediation_plan": _best_remediation(group),
        })

    return entries


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def generate_poam_csv(result: ScanResult) -> str:
    """Generate POA&M entries in CSV format for eMASS/XACTA import.

    Args:
        result: A ScanResult from the scanner.

    Returns:
        A CSV string with one row per POA&M entry (grouped by CWE).
    """
    entries = _build_entries(result)
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(_CSV_HEADERS)

    for e in entries:
        writer.writerow([
            e["poam_id"],
            e["weakness_name"],
            f"CWE-{e['cwe_id']}" if e["cwe_id"] else "N/A",
            e["severity"],
            e["stig_id"],
            e["stig_cat"],
            "; ".join(e["nist_controls"]),
            "; ".join(e["cmmc_practices"]),
            e["status"],
            e["detection_date"],
            e["scheduled_completion_date"],
            e["point_of_contact"],
            "; ".join(e["file_locations"]),
            e["remediation_plan"],
        ])

    return buf.getvalue()


def generate_poam_json(result: ScanResult) -> dict:
    """Generate POA&M entries in JSON format.

    Args:
        result: A ScanResult from the scanner.

    Returns:
        A dict suitable for ``json.dumps()`` containing all POA&M data.
    """
    entries = _build_entries(result)

    by_cat: dict[str, int] = {}
    by_status: dict[str, int] = {}
    for e in entries:
        cat_key = e["stig_cat"] or "None"
        by_cat[cat_key] = by_cat.get(cat_key, 0) + 1
        by_status[e["status"]] = by_status.get(e["status"], 0) + 1

    return {
        "sanicode_version": __version__,
        "scan_id": result.scan_id,
        "generated_at": _format_date(
            _parse_scan_date(result.scan_timestamp)
        ),
        "summary": {
            "total_entries": len(entries),
            "by_cat": by_cat,
            "by_status": by_status,
        },
        "entries": entries,
    }


def generate_poam_summary(result: ScanResult) -> str:
    """Generate a Markdown summary of POA&M entries.

    Args:
        result: A ScanResult from the scanner.

    Returns:
        A Markdown string with entry count, severity breakdown,
        and a table of all entries.
    """
    entries = _build_entries(result)

    # Count by CAT level
    by_cat: dict[str, int] = {}
    for e in entries:
        cat_key = e["stig_cat"] or "None"
        by_cat[cat_key] = by_cat.get(cat_key, 0) + 1

    lines: list[str] = [
        "# POA&M Summary",
        "",
        f"**Scanned:** {result.scanned_path}  ",
        f"**Date:** {result.scan_timestamp}  ",
        f"**Sanicode Version:** {__version__}",
        "",
        f"**Total POA&M Entries:** {len(entries)}  ",
    ]

    if by_cat:
        cat_parts = [f"CAT {k}: {v}" for k, v in sorted(by_cat.items())]
        lines.append(f"**By CAT Level:** {', '.join(cat_parts)}")
    lines.append("")

    if not entries:
        lines.append("No findings to report.")
        lines.append("")
        return "\n".join(lines)

    # Entry table
    lines.extend([
        "| # | CWE | Weakness | Severity | CAT | Completion | Files |",
        "|---|-----|----------|----------|-----|------------|-------|",
    ])

    for e in entries:
        lines.append(
            f"| {e['poam_id']} "
            f"| {'CWE-' + str(e['cwe_id']) if e['cwe_id'] else 'N/A'} "
            f"| {e['weakness_name']} "
            f"| {e['severity']} "
            f"| {e['stig_cat'] or '—'} "
            f"| {e['scheduled_completion_date']} "
            f"| {e['affected_count']} |"
        )

    lines.append("")
    return "\n".join(lines)
