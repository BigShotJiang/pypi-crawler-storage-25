"""SARIF 2.1.0 report generator.

SARIF (Static Analysis Results Interchange Format) is the standard output
format for ecosystem interoperability with:
  - GitHub Code Scanning / GitHub Advanced Security
  - VS Code Problems panel (via SARIF Viewer extension)
  - Azure DevOps pipeline gating
  - Tekton task result consumers

Reference schema: https://docs.oasis-open.org/sarif/sarif/v2.1.0/sarif-v2.1.0.html
JSON schema:      https://json.schemastore.org/sarif-2.1.0.json

Stigcode contract properties (stigIds, stigCheckIds, cweIds, nist80053,
stigCategory) are emitted on every result that carries compliance data.
Rule descriptors emit cweIds when a CWE ID is known. These properties
allow downstream consumers (stigcode, IDE plugins) to correlate findings
with STIG and NIST controls without parsing the raw compliance blob.
"""

from __future__ import annotations

from sanicode.report.persist import ScanResult
from sanicode.scanner.patterns import KNOWN_BAD_PATTERNS

# ---------------------------------------------------------------------------
# APSC-DV → V-ID lazy loader (stigcode contract)
# ---------------------------------------------------------------------------

_APSC_TO_VID: dict[str, str] | None = None


def _get_apsc_to_vid_map() -> dict[str, str]:
    """Lazy-load the APSC-DV ID → V-ID mapping from stig_checklist_meta.json."""
    global _APSC_TO_VID
    if _APSC_TO_VID is not None:
        return _APSC_TO_VID

    from sanicode.report.stig import _load_meta  # noqa: PLC0415

    meta = _load_meta()
    _APSC_TO_VID = {}
    for apsc_id, rule_data in meta.get("rules", {}).items():
        vid = rule_data.get("vuln_num")
        if vid:
            _APSC_TO_VID[apsc_id] = vid
    return _APSC_TO_VID


# SARIF 2.1.0 schema URI — must appear in the $schema field of every SARIF document.
SARIF_SCHEMA_URI = "https://json.schemastore.org/sarif-2.1.0.json"
SARIF_VERSION = "2.1.0"

_TOOL_NAME = "sanicode"
_TOOL_INFO_URI = "https://github.com/rdwj/sanicode"
_CWE_URI_TEMPLATE = "https://cwe.mitre.org/data/definitions/{cwe_id}.html"

# Maps sanicode severity levels to SARIF result levels.
_SEVERITY_TO_SARIF_LEVEL: dict[str, str] = {
    "critical": "error",
    "high": "error",
    "medium": "warning",
    "low": "note",
    "info": "note",
}


def _sarif_level(severity: str) -> str:
    """Map a sanicode severity string to a SARIF result level."""
    return _SEVERITY_TO_SARIF_LEVEL.get(severity.lower(), "warning")


def _build_rule_descriptor(
    rule_id: str, cwe_id: int | None, compliance: dict | None = None
) -> dict:
    """Build a SARIF reportingDescriptor for a single rule."""
    short_description = KNOWN_BAD_PATTERNS.get(rule_id, rule_id)
    descriptor: dict = {
        "id": rule_id,
        "shortDescription": {"text": short_description},
    }

    properties: dict = {}
    if cwe_id is not None:
        descriptor["helpUri"] = _CWE_URI_TEMPLATE.format(cwe_id=cwe_id)
        properties["cweIds"] = [cwe_id]

    if compliance and isinstance(compliance, dict):
        asd_stig = compliance.get("asd_stig", [])
        if asd_stig:
            check_ids = [s["id"] for s in asd_stig if isinstance(s, dict) and "id" in s]
            if check_ids:
                properties["stigCheckIds"] = check_ids
                apsc_map = _get_apsc_to_vid_map()
                v_ids = [apsc_map[cid] for cid in check_ids if cid in apsc_map]
                if v_ids:
                    properties["stigIds"] = v_ids
            cat = asd_stig[0].get("cat") if isinstance(asd_stig[0], dict) else None
            if cat:
                properties["stigCategory"] = cat

        nist = compliance.get("nist_800_53", [])
        if nist:
            properties["nist80053"] = list(nist)

    if properties:
        descriptor["properties"] = properties
    return descriptor


def _build_result(finding: dict) -> dict:
    """Build a single SARIF result object from a serialized finding dict."""
    rule_id: str = finding.get("rule_id", "UNKNOWN")
    severity: str = finding.get("derived_severity") or finding.get("severity", "medium")
    message: str = finding.get("message", "")

    # SARIF regions are 1-based; AST col_offset is 0-based.
    start_line: int = finding.get("line", 1) or 1
    start_column: int = (finding.get("column") or 0) + 1

    result: dict = {
        "ruleId": rule_id,
        "level": _sarif_level(severity),
        "message": {"text": message},
        "locations": [
            {
                "physicalLocation": {
                    "artifactLocation": {
                        "uri": finding.get("file", ""),
                        "uriBaseId": "%SRCROOT%",
                    },
                    "region": {
                        "startLine": start_line,
                        "startColumn": start_column,
                    },
                }
            }
        ],
    }

    # Attach CWE and compliance data as properties for consumers that support it.
    properties: dict = {}
    cwe_id = finding.get("cwe_id")
    if cwe_id is not None:
        properties["cwe_id"] = cwe_id
    compliance = finding.get("compliance")
    if compliance:
        properties["compliance"] = compliance
    # Classification taxonomy fields (issue #112)
    tags = finding.get("tags")
    if tags:
        properties["tags"] = tags
    domain = finding.get("domain")
    if domain:
        properties["domain"] = domain
    action = finding.get("action")
    if action:
        properties["action"] = action
    domain_reachability = finding.get("domain_reachability")
    if domain_reachability:
        properties["domain_reachability"] = domain_reachability

    # Stigcode contract properties — emitted so downstream consumers can
    # correlate findings with STIG/NIST controls without parsing the full
    # compliance blob.  Result-level properties take precedence per the spec.
    if compliance:
        # cweIds — prefer compliance.cwe_id, fall back to top-level cwe_id
        cwe = (
            compliance.get("cwe_id")
            if isinstance(compliance, dict)
            else getattr(compliance, "cwe_id", None)
        )
        if cwe is None:
            cwe = cwe_id
        if cwe is not None:
            properties["cweIds"] = [cwe]

        # stigCheckIds (APSC-DV IDs) and stigIds (V-IDs)
        asd_stig = (
            compliance.get("asd_stig", [])
            if isinstance(compliance, dict)
            else getattr(compliance, "asd_stig", [])
        )
        if asd_stig:
            check_ids = [s["id"] for s in asd_stig if isinstance(s, dict) and "id" in s]
            if check_ids:
                properties["stigCheckIds"] = check_ids
                apsc_map = _get_apsc_to_vid_map()
                v_ids = [apsc_map[cid] for cid in check_ids if cid in apsc_map]
                if v_ids:
                    properties["stigIds"] = v_ids

            # stigCategory from the highest-severity (first) entry
            first_cat = asd_stig[0].get("cat") if isinstance(asd_stig[0], dict) else None
            if first_cat:
                properties["stigCategory"] = first_cat

        # nist80053
        nist = (
            compliance.get("nist_800_53", [])
            if isinstance(compliance, dict)
            else getattr(compliance, "nist_800_53", [])
        )
        if nist:
            properties["nist80053"] = list(nist)

    elif cwe_id is not None:
        # No compliance data but CWE is known — still emit cweIds
        properties["cweIds"] = [cwe_id]

    # Remediation guidance. SARIF's ``fixes[]`` field requires each fix to
    # carry concrete ``artifactChanges`` with ``replacements`` — descriptive
    # prose alone doesn't satisfy the schema and GitHub Code Scanning
    # rejects such SARIF on upload. Since sanicode's remediation text is
    # human-readable guidance rather than a structured patch, emit it as a
    # custom property instead of a non-conforming ``fixes[]`` entry.
    # See issue #226.
    remediation = finding.get("remediation")
    if not remediation and compliance and isinstance(compliance, dict):
        remediation = compliance.get("remediation")
    if remediation:
        properties["remediation"] = remediation

    # LLM attribution fields (source + minority report).
    source = finding.get("source")
    minority_report = finding.get("minority_report")
    if source:
        properties["source"] = source
    if minority_report is not None:
        mr = minority_report
        mr_props: dict = {
            "dissenter": mr.get("dissenter", ""),
            "assessment": mr.get("assessment", ""),
            "reasoning": mr.get("reasoning", ""),
        }
        if "tiebreaker_verdict" in mr:
            mr_props["tiebreakerVerdict"] = mr["tiebreaker_verdict"]
        if "tiebreaker_reasoning" in mr:
            mr_props["tiebreakerReasoning"] = mr["tiebreaker_reasoning"]
        properties["minorityReport"] = mr_props
    node_ref = finding.get("node_ref")
    if node_ref is not None:
        properties["nodeRef"] = node_ref

    if properties:
        result["properties"] = properties

    # SARIF codeFlows for taint-tracking findings (issue #194).
    taint_flow = finding.get("taint_flow")
    if taint_flow:
        thread_flow_locations = []
        for step in taint_flow:
            thread_flow_locations.append({
                "location": {
                    "physicalLocation": {
                        "artifactLocation": {
                            "uri": step.get("file", ""),
                            "uriBaseId": "%SRCROOT%",
                        },
                        "region": {
                            "startLine": step.get("line", 1),
                        },
                    },
                    "message": {"text": step.get("message", "")},
                }
            })
        if thread_flow_locations:
            result["codeFlows"] = [
                {
                    "threadFlows": [
                        {"locations": thread_flow_locations}
                    ]
                }
            ]

    return result


def generate_sarif(result: ScanResult) -> dict:
    """Generate a SARIF 2.1.0-compliant report dict.

    The returned dict can be serialized with json.dumps() and consumed by any
    SARIF-compatible tool (GitHub Code Scanning, VS Code, Azure DevOps, etc.).

    Args:
        result: A ScanResult produced by build_scan_result() and optionally
                persisted via save_scan_result().

    Returns:
        A SARIF 2.1.0 document as a Python dict, ready for json.dumps().
    """
    # Ensure rule metadata is available in KNOWN_BAD_PATTERNS (no-op if already done).
    from sanicode.scanner.patterns import init_known_bad_patterns
    init_known_bad_patterns()

    findings: list[dict] = result.findings

    # Collect deduplicated rules, preserving first-seen order.
    seen_rule_ids: set[str] = set()
    rules: list[dict] = []
    for finding in findings:
        rule_id = finding.get("rule_id", "UNKNOWN")
        if rule_id not in seen_rule_ids:
            seen_rule_ids.add(rule_id)
            cwe_id = finding.get("cwe_id")
            compliance = finding.get("compliance")
            rules.append(_build_rule_descriptor(rule_id, cwe_id, compliance))

    results = [_build_result(f) for f in findings]

    # Ensure the scanned_path URI ends with a slash (SARIF directory convention).
    scanned_path = result.scanned_path.rstrip("/") + "/"
    base_uri = f"file://{scanned_path}"

    return {
        "$schema": SARIF_SCHEMA_URI,
        "version": SARIF_VERSION,
        "runs": [
            {
                "tool": {
                    "driver": {
                        "name": _TOOL_NAME,
                        "version": result.sanicode_version,
                        "informationUri": _TOOL_INFO_URI,
                        "rules": rules,
                    }
                },
                "originalUriBaseIds": {
                    "%SRCROOT%": {"uri": base_uri},
                },
                "results": results,
            }
        ],
    }
