"""FIPS 140-2/140-3 compliance utilities for Sanicode.

Sanicode inherits FIPS compliance from the host/cluster when deployed on a
FIPS-enabled RHEL or OpenShift node.  This module provides helpers so operators
can verify that the running environment meets FIPS requirements and that no
Sanicode configuration silently undermines them.
"""

from __future__ import annotations

import hashlib
import ssl
import sys


def _load_config():  # noqa: ANN201
    """Lazy wrapper around ``sanicode.config.load_config``.

    Kept as a named module-level callable so tests can patch it with
    ``patch("sanicode.fips._load_config")``.
    """
    from sanicode.config import load_config

    return load_config()


def check_fips_mode() -> bool:
    """Return True if the host kernel reports FIPS mode enabled.

    On Linux this reads ``/proc/sys/crypto/fips_enabled``.  On all other
    platforms (macOS, Windows) the function returns False because those
    platforms do not expose a kernel FIPS flag through this mechanism.
    """
    if sys.platform != "linux":
        return False

    try:
        with open("/proc/sys/crypto/fips_enabled", encoding="ascii") as fh:
            return fh.read().strip() == "1"
    except OSError:
        return False


def _openssl_fips_active() -> bool:
    """Return True if the active OpenSSL provider reports FIPS mode."""
    # ssl.OPENSSL_VERSION is available on all supported Python versions.
    # OpenSSL built with FIPS support sets the FIPS provider as default when
    # the kernel flag is on; we detect this by attempting a prohibited digest.
    try:
        # MD5 is forbidden in FIPS mode; if it raises ValueError, FIPS is active.
        hashlib.new("md5", usedforsecurity=True)
        return False
    except ValueError:
        return True


def validate_fips_compliance() -> list[str]:
    """Return a list of FIPS compliance issues found in the current process.

    An empty list means no issues were detected.  Each entry in a non-empty
    list is a human-readable description of a problem, suitable for display
    via ``sanicode fips-check``.
    """
    issues: list[str] = []

    # 1. Confirm the hashlib/OpenSSL backend is FIPS-validated.
    openssl_version = ssl.OPENSSL_VERSION
    if "fips" not in openssl_version.lower() and not _openssl_fips_active():
        # Only flag this when the kernel also says FIPS is on; otherwise it is
        # just a dev environment without FIPS enabled.
        if check_fips_mode():
            issues.append(
                f"OpenSSL ({openssl_version}) does not appear to have the FIPS "
                "provider active even though the kernel has FIPS mode enabled."
            )

    # 2. Detect non-FIPS hash algorithms in hashlib usage.
    #    We check if SHA-1 can still be used for security purposes; it should
    #    be disabled in strict FIPS mode (RHEL 9+).
    #    This is advisory — SHA-1 is allowed for non-security uses.
    _NON_FIPS_ALGORITHMS = {"md5", "md4", "md2", "sha", "rc4"}
    available = {a.lower() for a in hashlib.algorithms_available}
    blocked_in_fips = available & _NON_FIPS_ALGORITHMS
    if check_fips_mode() and blocked_in_fips:
        # If these algorithms are available for security use, they shouldn't be.
        still_usable = []
        for algo in sorted(blocked_in_fips):
            try:
                hashlib.new(algo, usedforsecurity=True)
                still_usable.append(algo)
            except ValueError:
                pass  # Correctly blocked.
        if still_usable:
            issues.append(
                f"Non-FIPS hash algorithms available for security use: "
                f"{', '.join(still_usable)}.  Expected these to be blocked in "
                "FIPS mode."
            )

    # 3. Check that the KFP client is not configured with verify=False.
    #    We do this by inspecting the config, not the live client.
    try:
        # Import lazily to avoid circular imports; patched in tests via
        # patch("sanicode.fips._load_config").
        cfg = _load_config()
        ca_bundle = cfg.pipeline.ca_bundle
        if ca_bundle == "" or ca_bundle.lower() in {"false", "0", "no"}:
            issues.append(
                "pipeline.ca_bundle is disabled in sanicode.toml — KFP TLS "
                "certificate verification will be skipped, violating FIPS TLS "
                "requirements.  Set pipeline.ca_bundle to a valid CA bundle path."
            )
    except Exception:
        # Config load errors are not a FIPS issue per se; ignore.
        pass

    return issues
