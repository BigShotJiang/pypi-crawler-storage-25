"""Sanicode CLI — entry point for all subcommands."""

from __future__ import annotations

import json
import logging
import sys
import time
from collections import Counter
from pathlib import Path

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from sanicode import __version__

# Route sanicode's logger output to stderr so that LLM warnings, graph taint
# warnings, and other diagnostics can't leak into stdout and break CI pipelines
# that consume --format json / --format sarif output. Propagation stays
# enabled so pytest's caplog fixture (which attaches to the root logger) can
# still capture sanicode log records in tests; the root logger has no stream
# handlers by default, so there is no duplicate emission.
_sanicode_logger = logging.getLogger("sanicode")
if not _sanicode_logger.handlers:
    _handler = logging.StreamHandler(sys.stderr)
    _handler.setFormatter(logging.Formatter("%(levelname)s: %(message)s"))
    _sanicode_logger.addHandler(_handler)
    _sanicode_logger.setLevel(logging.WARNING)

app = typer.Typer(
    name="sanicode",
    help="AI-assisted code sanitization scanner with compliance mapping.",
    no_args_is_help=True,
)
console = Console()
err_console = Console(stderr=True)


def _version_callback(value: bool) -> None:
    if value:
        console.print(f"sanicode {__version__}")
        raise typer.Exit()


@app.callback()
def main_callback(
    version: bool | None = typer.Option(
        None,
        "--version",
        "-V",
        callback=_version_callback,
        is_eager=True,
        help="Show version and exit.",
    ),
) -> None:
    """Sanicode — AI-assisted code sanitization scanner."""


config_app = typer.Typer(
    name="config",
    help="Configure the LLM backend and scanner settings.",
    invoke_without_command=True,
)
app.add_typer(config_app)


@config_app.callback(invoke_without_command=True)
def config(
    ctx: typer.Context,
    show: bool = typer.Option(False, "--show", help="Print the resolved configuration."),
    init: bool = typer.Option(
        False, "--init", help="Create a starter sanicode.toml in the current directory."
    ),
    config_file: Path | None = typer.Option(
        None, "--config", "-c", help="Path to a sanicode.toml config file."
    ),
) -> None:
    """Configure the LLM backend and scanner settings."""
    if ctx.invoked_subcommand is not None:
        return

    from sanicode.config import DEFAULT_CONFIG_TEMPLATE, load_config

    if init:
        dest = Path("sanicode.toml")
        if dest.exists():
            console.print(
                "[red]Error:[/red] sanicode.toml already exists in the current directory."
            )
            raise typer.Exit(code=1)
        dest.write_text(DEFAULT_CONFIG_TEMPLATE, encoding="utf-8")
        console.print(f"[green]Created[/green] {dest.resolve()}")
        console.print(
            "Edit the file to configure your LLM endpoints,"
            " then run [bold]sanicode scan[/bold]."
        )
        return

    try:
        cfg = load_config(config_file)
    except FileNotFoundError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1) from exc

    source_label = (
        str(cfg._source_path) if cfg._source_path else "defaults (no config file found)"
    )
    console.print(Panel(
        f"[bold]Sanicode Configuration[/bold]\nSource: {source_label}",
        expand=False,
    ))

    # LLM tiers
    llm_table = Table(title="LLM Tiers", show_lines=False)
    llm_table.add_column("Tier", style="bold")
    llm_table.add_column("Provider")
    llm_table.add_column("Endpoint", no_wrap=True)
    llm_table.add_column("Model")
    llm_table.add_column("API Key")
    for tier_name in ("fast", "analysis", "reasoning"):
        tier = getattr(cfg.llm, tier_name)
        if tier.model:
            api_key_display = "[hidden]" if tier.api_key else "[dim]—[/dim]"
            llm_table.add_row(
                tier_name,
                tier.provider,
                tier.endpoint or "[dim]—[/dim]",
                tier.model,
                api_key_display,
            )
        else:
            llm_table.add_row(
                tier_name,
                "[dim]—[/dim]",
                "[dim]—[/dim]",
                "[dim]not configured[/dim]",
                "[dim]—[/dim]",
            )
    console.print(llm_table)

    # Scan
    scan_table = Table(title="Scan", show_lines=False)
    scan_table.add_column("Setting", style="bold")
    scan_table.add_column("Value")
    exts = (
        ", ".join(cfg.scan.include_extensions)
        if cfg.scan.include_extensions else "(all supported)"
    )
    scan_table.add_row("Extensions", exts)
    scan_table.add_row("Max file size", f"{cfg.scan.max_file_size_kb} KB")
    excl = ", ".join(cfg.scan.exclude_patterns) if cfg.scan.exclude_patterns else "(none)"
    scan_table.add_row("Exclusions", excl)
    console.print(scan_table)

    # Output
    out_table = Table(title="Output", show_lines=False)
    out_table.add_column("Setting", style="bold")
    out_table.add_column("Value")
    out_table.add_row("Formats", ", ".join(cfg.output.formats))
    out_table.add_row("Output dir", cfg.output.output_dir)
    console.print(out_table)

    # Compliance
    comp_table = Table(title="Compliance", show_lines=False)
    comp_table.add_column("Setting", style="bold")
    comp_table.add_column("Value")
    comp_table.add_row("Profiles", ", ".join(cfg.compliance.profiles))
    console.print(comp_table)


_LLM_TIERS = ("fast", "analysis", "reasoning")
_LLM_FIELDS = ("provider", "model", "endpoint", "api_key", "timeout_seconds")
_DOMAIN_FIELDS = ("unclassified_strategy",)
_SCAN_FIELDS = ("include_extensions", "exclude_patterns")
_VALID_KEYS = frozenset(
    [f"llm.{tier}.{field}" for tier in _LLM_TIERS for field in _LLM_FIELDS]
    + [f"domain.{field}" for field in _DOMAIN_FIELDS]
    + [f"scan.{field}" for field in _SCAN_FIELDS]
)


@config_app.command("set")
def set_(
    key: str = typer.Argument(..., help="Dotted config key (e.g. llm.fast.provider)."),
    value: str = typer.Argument(..., help="Value to set."),
    config_file: Path | None = typer.Option(
        None, "--config", "-c", help="Path to a sanicode.toml config file."
    ),
) -> None:
    """Set a single configuration value by dotted path."""
    from sanicode.config import (
        find_writable_config_path,
        write_domain_config,
        write_llm_tier,
        write_scan_config,
    )

    if key not in _VALID_KEYS:
        console.print(
            f"[red]Error:[/red] Invalid key [bold]{key}[/bold]."
        )
        console.print("Valid keys:")
        for vk in sorted(_VALID_KEYS):
            console.print(f"  {vk}")
        raise typer.Exit(code=1)

    try:
        path = find_writable_config_path(config_file)
    except PermissionError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1) from exc

    parts = key.split(".")

    if parts[0] == "domain":
        field_name = parts[1]
        try:
            write_domain_config(path, **{field_name: value})
        except ValueError as exc:
            console.print(f"[red]Error:[/red] {exc}")
            raise typer.Exit(code=1) from exc
    elif parts[0] == "llm":
        _, tier_name, field_name = parts
        coerced_value: str | int = value
        if field_name == "timeout_seconds":
            try:
                coerced_value = int(value)
            except ValueError:
                console.print(
                    f"[red]Error:[/red] [bold]timeout_seconds[/bold] must be an integer, "
                    f"got {value!r}."
                )
                raise typer.Exit(code=1) from None
        write_llm_tier(path, tier_name, **{field_name: coerced_value})
    elif parts[0] == "scan":
        field_name = parts[1]
        # Both scan list fields accept comma-separated input, e.g. ".py,.java,.js"
        parsed_list = [item.strip() for item in value.split(",") if item.strip()]
        write_scan_config(path, **{field_name: parsed_list})
    else:
        console.print(f"[red]Error:[/red] Unsupported key prefix: {parts[0]}")
        raise typer.Exit(code=1)

    display_value = "[hidden]" if "api_key" in key else value
    console.print(f"[green]Set[/green] {key} = {display_value}")
    console.print(f"Written to {path}")


@config_app.command("get")
def get_(
    key: str = typer.Argument(..., help="Dotted config key (e.g. llm.fast.provider)."),
    config_file: Path | None = typer.Option(
        None, "--config", "-c", help="Path to a sanicode.toml config file."
    ),
) -> None:
    """Get a single configuration value by dotted path."""
    from sanicode.config import load_config

    if key not in _VALID_KEYS:
        console.print(
            f"[red]Error:[/red] Invalid key [bold]{key}[/bold]."
        )
        console.print("Valid keys:")
        for vk in sorted(_VALID_KEYS):
            console.print(f"  {vk}")
        raise typer.Exit(code=1)

    try:
        cfg = load_config(config_file)
    except FileNotFoundError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1) from exc

    parts = key.split(".")

    if parts[0] == "domain":
        value = getattr(cfg.domain, parts[1], "")
    elif parts[0] == "llm":
        tier = getattr(cfg.llm, parts[1], None)
        value = getattr(tier, parts[2], "") if tier else ""
    elif parts[0] == "scan":
        raw_value = getattr(cfg.scan, parts[1], [])
        # List values are printed as comma-separated for readability.
        value = ", ".join(raw_value) if isinstance(raw_value, list) else raw_value
    else:
        console.print(f"[red]Error:[/red] Unsupported key prefix: {parts[0]}")
        raise typer.Exit(code=1)

    console.print(str(value))


@config_app.command()
def setup(
    config_file: Path | None = typer.Option(
        None, "--config", "-c", help="Path to write the config file."
    ),
) -> None:
    """Interactive wizard to configure LLM providers and models."""
    from rich.prompt import Confirm, Prompt

    from sanicode.config import find_writable_config_path, write_llm_tier
    from sanicode.llm.providers import (
        cloud_providers,
        get_provider,
        self_hosted_providers,
    )

    # Step 1: Show grouped provider list.
    cloud = cloud_providers()
    self_hosted = self_hosted_providers()

    console.print("\n[bold]Cloud providers:[/bold]")
    for p in cloud:
        console.print(f"  {p.name:<14} {p.display_name}")
    console.print("\n[bold]Self-hosted:[/bold]")
    for p in self_hosted:
        console.print(f"  {p.name:<14} {p.display_name}")
    console.print()

    all_names = [p.name for p in cloud] + [p.name for p in self_hosted]
    provider_name = Prompt.ask(
        "Provider",
        choices=all_names + ["other"],
        default="anthropic",
    )

    provider_info = get_provider(provider_name)

    # Step 2: Endpoint URL (self-hosted or unknown providers).
    endpoint = None
    if provider_info and provider_info.requires_endpoint:
        endpoint = Prompt.ask(
            "Inference endpoint URL",
            default=provider_info.endpoint_hint,
        )
    elif provider_info is None and provider_name != "other":
        # Unknown provider — might need an endpoint.
        endpoint = Prompt.ask("Inference endpoint URL (leave blank for cloud)", default="")
        if not endpoint:
            endpoint = None
    elif provider_name == "other":
        endpoint = Prompt.ask("Inference endpoint URL (leave blank for cloud)", default="")
        if not endpoint:
            endpoint = None

    # Step 3: Model per tier (with suggestions if available).
    tier_names = ("fast", "analysis", "reasoning")
    suggestion_map: dict[str, str] = {}
    if provider_info and provider_info.suggestions:
        for s in provider_info.suggestions:
            suggestion_map[s.tier] = s.model

    all_tiers = Confirm.ask("Apply the same model to all tiers?", default=False)

    tier_configs: list[dict] = []
    if all_tiers:
        default_model = suggestion_map.get("analysis", suggestion_map.get("fast"))
        model = Prompt.ask("Model name", default=default_model)
        for name in tier_names:
            tier_configs.append({"tier": name, "model": model, "endpoint": endpoint})
    else:
        for name in tier_names:
            console.print(f"\n[bold]{name}[/bold] tier:")
            default_model = suggestion_map.get(name)
            tier_model = Prompt.ask("  Model", default=default_model)
            tier_endpoint = endpoint
            if provider_info and provider_info.requires_endpoint:
                tier_endpoint = Prompt.ask("  Endpoint URL", default=endpoint or "")
                if not tier_endpoint:
                    tier_endpoint = None
            tier_configs.append({"tier": name, "model": tier_model, "endpoint": tier_endpoint})

    # Step 4: API key (only for providers that need one).
    api_key = None
    if provider_info is None or provider_info.needs_api_key:
        api_key = Prompt.ask(
            "API key (leave blank to use environment variable)",
            default="",
        )
        if not api_key:
            api_key = None
            if provider_info and provider_info.auth_env_vars:
                env_hint = ", ".join(provider_info.auth_env_vars)
                console.print(f"[dim]Hint: set {env_hint} in your environment.[/dim]")

    # Step 5: Determine write path.
    try:
        path = find_writable_config_path(config_file)
    except PermissionError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1) from exc

    # Step 6: Summary and confirmation.
    summary = Table(title="Configuration Summary")
    summary.add_column("Tier", style="bold")
    summary.add_column("Provider")
    summary.add_column("Model")
    summary.add_column("Endpoint")
    summary.add_column("API Key")

    for tier_cfg in tier_configs:
        auth_display = "[hidden]" if api_key else "(env var)"
        if provider_info and not provider_info.needs_api_key:
            auth_display = "(not required)"
        endpoint_display = tier_cfg["endpoint"] or "[dim]—[/dim]"
        summary.add_row(
            tier_cfg["tier"],
            provider_name,
            tier_cfg["model"],
            endpoint_display,
            auth_display,
        )

    console.print(summary)

    if not Confirm.ask("Write this configuration?", default=True):
        console.print("[yellow]Cancelled.[/yellow]")
        raise typer.Exit()

    # Write each tier.
    for tier_cfg in tier_configs:
        write_llm_tier(
            path,
            tier_cfg["tier"],
            provider=provider_name,
            model=tier_cfg["model"],
            endpoint=tier_cfg["endpoint"],
            api_key=api_key,
        )

    console.print(f"\n[green]Configuration written to[/green] [bold]{path}[/bold]")


@config_app.command()
def test(
    config_file: Path | None = typer.Option(
        None, "--config", "-c", help="Path to a sanicode.toml config file."
    ),
) -> None:
    """Test connectivity to configured LLM endpoints."""
    import os
    import time

    from sanicode.config import load_config
    from sanicode.llm.client import LLMClient
    from sanicode.llm.providers import get_provider

    try:
        cfg = load_config(config_file)
    except FileNotFoundError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1) from exc

    llm = LLMClient.from_config(cfg)
    tier_names = ("fast", "analysis", "reasoning")
    configured = [t for t in tier_names if llm.has_tier(t)]

    if not configured:
        console.print("No LLM tiers configured. Nothing to test.")
        console.print("Run [bold]sanicode config setup[/bold] to configure endpoints.")
        raise typer.Exit()

    results = Table(title="LLM Connectivity Test")
    results.add_column("Tier", style="bold")
    results.add_column("Provider")
    results.add_column("Model")
    results.add_column("Status")
    results.add_column("Latency", justify="right")

    any_failed = False

    for tier_name in configured:
        tier_cfg = getattr(cfg.llm, tier_name)
        provider_info = get_provider(tier_cfg.provider)

        # Check auth env vars.
        if provider_info and provider_info.needs_api_key and not tier_cfg.api_key:
            missing = [v for v in provider_info.auth_env_vars if not os.environ.get(v)]
            if missing:
                console.print(
                    f"[yellow]Warning:[/yellow] {tier_name} tier uses "
                    f"{provider_info.display_name} but these env vars are not set: "
                    f"{', '.join(missing)}"
                )

        start = time.monotonic()
        try:
            llm.test_connection(tier_name)
            elapsed = time.monotonic() - start
            results.add_row(
                tier_name,
                tier_cfg.provider,
                tier_cfg.model,
                "[green]ok[/green]",
                f"{elapsed:.1f}s",
            )
        except Exception as exc:
            elapsed = time.monotonic() - start
            any_failed = True
            results.add_row(
                tier_name,
                tier_cfg.provider,
                tier_cfg.model,
                f"[red]FAIL[/red] {type(exc).__name__}: {exc}",
                f"{elapsed:.1f}s",
            )

    console.print(results)

    if any_failed:
        raise typer.Exit(code=1)


@app.command()
def scan(
    path: Path = typer.Argument(
        Path("."), help="Path to the codebase to scan."
    ),
    config_file: Path | None = typer.Option(
        None, "--config", "-c", help="Path to a sanicode.toml config file."
    ),
    output_format: list[str] = typer.Option(
        ["auto"], "--format", "-f",
        help="Output format(s): markdown, json, sarif, html, stig-checklist, poam. "
             "Defaults to markdown (TTY) or sarif (non-TTY/piped).",
    ),
    fail_on: str | None = typer.Option(
        None, "--fail-on", "--severity-threshold",
        help="Exit non-zero if findings at or above this severity "
             "(critical, high, medium, low).",
    ),
    no_deps: bool = typer.Option(
        False, "--no-deps", help="Skip dependency vulnerability scanning."
    ),
    sbom: Path | None = typer.Option(
        None, "--sbom", help="Write CycloneDX SBOM to this path."
    ),
    offline: bool = typer.Option(
        False, "--offline", help="Skip all network requests (OSV queries)."
    ),
    graph_depth: int | None = typer.Option(
        None, "--graph-depth",
        help="Max path depth for knowledge graph analysis (default: 10).",
    ),
    skip_content_policy: bool = typer.Option(
        False, "--skip-content-policy",
        help="Skip content policy scanning.",
    ),
    profile: bool = typer.Option(
        False, "--profile",
        help="Print per-stage timing breakdown to stderr.",
    ),
    quiet: bool = typer.Option(
        False, "--quiet", "-q",
        help="Suppress informational output. Show only findings and errors.",
    ),
    baseline: Path | None = typer.Option(
        None, "--baseline", "-b",
        help="Path to a baseline file (.sanicode-baseline.json). "
             "Findings matching the baseline are suppressed.",
    ),
    custom_rules: Path | None = typer.Option(
        None, "--custom-rules",
        help="Path to a YAML file with regex-based custom detection rules.",
    ),
    no_llm: bool = typer.Option(
        False, "--no-llm", help="Skip all LLM stages (deterministic analysis only).",
    ),
    cwe_filter: list[int] | None = typer.Option(
        None, "--cwe", help="Filter to specific CWE IDs (repeatable).",
    ),
    output_dir_flag: Path | None = typer.Option(
        None, "--output-dir", "-o",
        help="Directory for report output (overrides config).",
    ),
) -> None:
    """Scan a codebase, build a knowledge graph, and identify findings."""
    if output_format == ["auto"]:
        output_format = ["sarif"] if not sys.stdout.isatty() else ["markdown"]

    # Machine mode: user asked for exactly one structured format. Suppress
    # rich tables and decoration, emit the structured content to stdout so
    # pipelines like `sanicode scan --format json | jq .` work cleanly.
    is_machine_format = (
        len(output_format) == 1 and output_format[0] in {"json", "sarif"}
    )

    from sanicode.config import load_config
    from sanicode.scanner.executor import run_scan

    target = path.resolve()
    try:
        cfg = load_config(config_file)
    except FileNotFoundError as exc:
        err_console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=2) from exc

    # Build config overrides dict for audit logging.
    config_overrides: dict = {}
    if no_deps:
        cfg.dependencies.enabled = False
        config_overrides["no_deps"] = True
    if offline:
        cfg.dependencies.osv_enabled = False
        config_overrides["offline"] = True
    if sbom:
        cfg.dependencies.generate_sbom = True
        config_overrides["sbom"] = str(sbom)
    if graph_depth is not None:
        cfg.scan.graph_path_depth = graph_depth
        config_overrides["graph_depth"] = graph_depth
    if skip_content_policy:
        cfg.content_policy.enabled = False
        config_overrides["skip_content_policy"] = True
    if custom_rules is not None:
        cfg.scan.custom_rules = str(custom_rules)
        config_overrides["custom_rules"] = str(custom_rules)
    if output_dir_flag is not None:
        config_overrides["output_dir"] = str(output_dir_flag)
    if cwe_filter:
        config_overrides["cwe_filter"] = cwe_filter

    # Audit: config loaded.
    try:
        from sanicode.audit import log_config_loaded, log_scan_start

        log_config_loaded(
            str(cfg._source_path) if cfg._source_path else None,
            overrides=config_overrides or None,
        )
        log_scan_start(str(target), {
            "formats": output_format,
            "fail_on": fail_on,
            "extensions": cfg.scan.include_extensions,
            "exclude_patterns": cfg.scan.exclude_patterns[:3],  # truncate for brevity
        })
    except Exception:
        pass  # Never let audit failures break the scan

    if not quiet:
        err_console.print(f"Scanning [bold]{target}[/bold] ...")
        if no_llm:
            err_console.print("[dim]LLM stages skipped (--no-llm)[/dim]")

    scan_start = time.monotonic()
    try:
        output = run_scan(target, cfg, skip_llm=no_llm)
    except FileNotFoundError as exc:
        err_console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=2) from exc
    scan_duration = time.monotonic() - scan_start

    for err in output.parse_errors:
        err_console.print(f"[yellow]Warning:[/yellow] Skipping {err}")

    if profile and output.stage_timings:
        from rich.table import Table as _Table

        total = sum(output.stage_timings.values()) or 1.0
        table = _Table(title="Pipeline stage timings")
        table.add_column("Stage", style="bold")
        table.add_column("Duration (s)", justify="right")
        table.add_column("% of total", justify="right")
        for stage, elapsed in output.stage_timings.items():
            pct = elapsed / total * 100
            table.add_row(stage, f"{elapsed:.3f}", f"{pct:.1f}%")
        table.add_row("TOTAL", f"{total:.3f}", "100.0%", style="bold")
        err_console.print(table)

    # --- CWE filter (applied before report generation) ---
    if cwe_filter:
        from sanicode.report.persist import ScanResult

        cwe_set = set(cwe_filter)
        filtered_findings = [
            f for f in output.result.findings if f.get("cwe_id") in cwe_set
        ]
        by_severity_filtered: dict[str, int] = {}
        by_cwe_filtered: dict[str, int] = {}
        for f in filtered_findings:
            sev = f.get("derived_severity") or f.get("severity", "info")
            by_severity_filtered[sev] = by_severity_filtered.get(sev, 0) + 1
            cwe_key = str(f.get("cwe_id", ""))
            by_cwe_filtered[cwe_key] = by_cwe_filtered.get(cwe_key, 0) + 1
        filtered_summary = dict(output.result.summary)
        filtered_summary["total_findings"] = len(filtered_findings)
        filtered_summary["by_severity"] = by_severity_filtered
        filtered_summary["by_cwe"] = by_cwe_filtered
        output.result = ScanResult(
            sanicode_version=output.result.sanicode_version,
            scan_id=output.result.scan_id,
            scanned_path=output.result.scanned_path,
            scan_timestamp=output.result.scan_timestamp,
            summary=filtered_summary,
            findings=filtered_findings,
        )

    # Write report files.
    from sanicode.report.json_report import generate_json
    from sanicode.report.markdown import generate_markdown
    from sanicode.report.persist import ScanResult, save_scan_result  # noqa: F811
    from sanicode.report.sarif import generate_sarif

    output_dir = (
        Path(output_dir_flag) if output_dir_flag is not None
        else Path(cfg.output.output_dir)
    )
    output_dir.mkdir(parents=True, exist_ok=True)

    # Timestamp for output filenames to avoid overwriting previous results.
    _ts = output.result.scan_timestamp.replace(":", "-").replace("T", "_")[:19]
    scan_result_name = f"scan-result_{_ts}.json"
    save_scan_result(output.result, output_dir, filename=scan_result_name)

    graph_path = output_dir / f"graph_{_ts}.json"
    graph_path.write_text(
        json.dumps(output.graph_data, indent=2), encoding="utf-8"
    )

    report_files: list[str] = []
    for fmt in output_format:
        if fmt == "sarif":
            sarif_path = output_dir / f"report_{_ts}.sarif"
            content = json.dumps(generate_sarif(output.result), indent=2)
            sarif_path.write_text(content, encoding="utf-8")
            report_files.append(f"report_{_ts}.sarif")
        elif fmt == "json":
            json_path = output_dir / f"report_{_ts}.json"
            content = json.dumps(generate_json(output.result), indent=2)
            json_path.write_text(content, encoding="utf-8")
            report_files.append(f"report_{_ts}.json")
        elif fmt == "markdown":
            md_path = output_dir / f"report_{_ts}.md"
            md_path.write_text(generate_markdown(output.result), encoding="utf-8")
            report_files.append(f"report_{_ts}.md")
        elif fmt == "html":
            from sanicode.report.html import generate_html
            html_path = output_dir / f"report_{_ts}.html"
            html_path.write_text(
                generate_html(output.result, graph_data=output.graph_data),
                encoding="utf-8",
            )
            report_files.append(f"report_{_ts}.html")
        elif fmt == "stig-checklist":
            from sanicode.report.stig import generate_stig_checklist, generate_stig_summary
            asset_cfg = {
                "hostname": cfg.stig.hostname,
                "host_ip": cfg.stig.host_ip,
                "host_fqdn": cfg.stig.host_fqdn,
                "target_comment": cfg.stig.target_comment,
                "tech_area": cfg.stig.tech_area,
            }
            ckl_path = output_dir / f"report_{_ts}.ckl"
            ckl_path.write_text(
                generate_stig_checklist(output.result, asset_cfg), encoding="utf-8"
            )
            report_files.append(f"report_{_ts}.ckl")
            summary_path = output_dir / f"report-stig-summary_{_ts}.md"
            summary_path.write_text(
                generate_stig_summary(output.result), encoding="utf-8"
            )
            report_files.append(f"report-stig-summary_{_ts}.md")
        elif fmt == "poam":
            from sanicode.report.poam import (
                generate_poam_csv,
                generate_poam_json,
                generate_poam_summary,
            )
            report_dir = output_dir
            csv_content = generate_poam_csv(output.result)
            json_content = json.dumps(
                generate_poam_json(output.result), indent=2,
            )
            md_content = generate_poam_summary(output.result)
            report_dir.joinpath(f"report-poam_{_ts}.csv").write_text(
                csv_content, encoding="utf-8",
            )
            report_dir.joinpath(f"report-poam_{_ts}.json").write_text(
                json_content, encoding="utf-8",
            )
            report_dir.joinpath(f"report-poam-summary_{_ts}.md").write_text(
                md_content, encoding="utf-8",
            )
            report_files.append(f"report-poam_{_ts}.csv")
            report_files.append(f"report-poam_{_ts}.json")
            report_files.append(f"report-poam-summary_{_ts}.md")

    written = [scan_result_name, f"graph_{_ts}.json"] + report_files
    if not quiet:
        err_console.print(
            f"\n[green]Reports written to[/green] [bold]{output_dir}/[/bold]"
        )
        for fname in written:
            err_console.print(f"  {fname}")

    # MLflow run logging (optional — skipped when integration is disabled or mlflow not installed).
    if cfg.integrations.mlflow.enabled:
        from sanicode.integrations.mlflow import log_scan_run

        mlflow_run_id = log_scan_run(
            output=output,
            target=target,
            mlflow_cfg=cfg.integrations.mlflow,
            scan_duration_sec=scan_duration,
            output_dir=output_dir,
        )
        if mlflow_run_id and not quiet:
            err_console.print(f"\n[dim]MLflow run:[/dim] {mlflow_run_id}")

    # Print summary.
    summary = output.result.summary
    if not quiet:
        err_console.print()
        err_console.print("[bold]Knowledge Graph[/bold]")
        err_console.print(
            f"  Nodes: {summary.get('graph_nodes', 0)}  "
            f"(entry points: {summary.get('graph_entry_points', 0)}, "
            f"sinks: {summary.get('graph_sinks', 0)}, "
            f"sanitizers: {summary.get('graph_sanitizers', 0)})"
        )
        err_console.print(f"  Edges: {summary.get('graph_edges', 0)}")

        if output.graph_truncated_pairs:
            n = len(output.graph_truncated_pairs)
            depth = output.graph_path_depth_used
            err_console.print(
                f"\n[yellow]Warning:[/yellow] {n} entry-to-sink path pair(s) "
                f"truncated by depth cutoff ({depth})."
            )
            err_console.print(
                f"  Re-run with [bold]--graph-depth {depth * 2}[/bold] "
                f"to include longer paths."
            )

        if output.lockfiles_scanned:
            err_console.print()
            err_console.print("[bold]Dependencies[/bold]")
            err_console.print(f"  Lockfiles: {len(output.lockfiles_scanned)}")
            err_console.print(f"  Dependencies: {output.dependency_count}")

    if sbom and output.sbom:
        sbom.write_text(json.dumps(output.sbom, indent=2), encoding="utf-8")
        if not quiet:
            err_console.print(
                f"[green]SBOM written to[/green] [bold]{sbom}[/bold]"
            )
    elif sbom and not output.sbom and not quiet:
        if no_deps:
            err_console.print(
                "\n[yellow]Warning:[/yellow] --sbom was requested but "
                "--no-deps disables dependency scanning."
            )
        elif target.is_file():
            err_console.print(
                "\n[yellow]Warning:[/yellow] --sbom was requested but "
                "dependency scanning requires a directory target."
            )
        else:
            err_console.print(
                "\n[yellow]Warning:[/yellow] --sbom was requested but no "
                "lockfiles were found (supported: requirements.txt, "
                "Pipfile.lock, poetry.lock, package-lock.json, yarn.lock, "
                "go.sum, Cargo.lock, pom.xml, Gemfile.lock)."
            )

    enriched = output.enriched_findings

    # --- Inline suppression filtering ---
    from sanicode.baseline import check_inline_suppression

    inline_suppressed: list = []
    remaining: list = []
    for ef in enriched:
        justification = check_inline_suppression(ef.file, ef.line, ef.rule_id)
        if justification is not None:
            inline_suppressed.append(ef)
        else:
            remaining.append(ef)
    enriched = remaining

    # --- Baseline suppression filtering ---
    baseline_suppressed: list = []
    if baseline is not None:
        from sanicode.baseline import Baseline, filter_by_baseline

        if not baseline.exists():
            err_console.print(
                f"[red]Error:[/red] Baseline file not found: {baseline}"
            )
            raise typer.Exit(code=2)
        bl = Baseline.load(baseline)
        enriched, baseline_suppressed = filter_by_baseline(enriched, bl, target)

    # --- CWE filter (enriched list — output.result already filtered above) ---
    if cwe_filter:
        cwe_set = set(cwe_filter)
        enriched = [ef for ef in enriched if ef.cwe_id in cwe_set]

    # Audit: log each suppressed finding.
    try:
        from sanicode.audit import log_suppression

        for ef in inline_suppressed:
            justification = check_inline_suppression(ef.file, ef.line, ef.rule_id)
            log_suppression(
                ef.rule_id, str(ef.file), ef.line,
                mechanism="inline", justification=justification,
            )
        for ef in baseline_suppressed:
            log_suppression(
                ef.rule_id, str(ef.file), ef.line,
                mechanism="baseline",
            )
    except Exception:
        pass  # Never let audit failures break the scan

    # Report suppression counts (useful status line on stderr regardless
    # of format, so machine-mode callers can eyeball progress).
    total_suppressed = len(inline_suppressed) + len(baseline_suppressed)
    err_console.print()
    err_console.print(f"[bold]Findings:[/bold] {len(enriched)}")
    if total_suppressed:
        parts: list[str] = []
        if baseline_suppressed:
            parts.append(f"{len(baseline_suppressed)} by baseline")
        if inline_suppressed:
            parts.append(f"{len(inline_suppressed)} by inline comment")
        err_console.print(
            f"[dim]  Suppressed: {total_suppressed} "
            f"({', '.join(parts)})[/dim]"
        )

    # Rich tables are the "human" view. Skip them in machine mode so that
    # stdout is reserved for the structured JSON/SARIF emit below.
    if enriched and not is_machine_format:
        # Per-finding detail table.
        detail_table = Table(title="Findings", show_lines=False)
        detail_table.add_column("File", style="cyan", no_wrap=True)
        detail_table.add_column("Line", justify="right")
        detail_table.add_column("Severity")
        detail_table.add_column("Rule", style="bold")
        detail_table.add_column("CWE", style="bold")
        detail_table.add_column("Message")

        for ef in enriched:
            sev = ef.derived_severity or ef.severity
            if sev in ("critical", "high"):
                sev_style = f"[red]{sev}[/red]"
            elif sev == "medium":
                sev_style = f"[yellow]{sev}[/yellow]"
            else:
                sev_style = f"[dim]{sev}[/dim]"

            rel_file = str(ef.file)
            try:
                rel_file = str(ef.file.relative_to(target))
            except ValueError:
                pass

            cwe_label = f"CWE-{ef.cwe_id}"
            if ef.cwe_name:
                cwe_label += f" ({ef.cwe_name})"

            detail_table.add_row(
                rel_file, str(ef.line), sev_style, ef.rule_id, cwe_label, ef.message
            )

        console.print(detail_table)
        console.print()

        # Top CWEs table.
        cwe_counts: Counter[str] = Counter()
        for ef in enriched:
            label = f"CWE-{ef.cwe_id}"
            if ef.cwe_name:
                label += f" ({ef.cwe_name})"
            cwe_counts[label] += 1

        table = Table(title="Top CWEs", show_lines=False)
        table.add_column("CWE", style="bold")
        table.add_column("Count", justify="right")
        for cwe_label, count in cwe_counts.most_common(10):
            table.add_row(cwe_label, str(count))
        console.print(table)

    # Machine mode: emit the structured report to stdout so callers can
    # pipe or redirect sanicode output directly into other tools.
    if is_machine_format:
        fmt = output_format[0]
        if fmt == "json":
            stdout_payload = json.dumps(
                generate_json(output.result), indent=2
            )
        else:  # sarif
            stdout_payload = json.dumps(
                generate_sarif(output.result), indent=2
            )
        sys.stdout.write(stdout_payload)
        sys.stdout.write("\n")
        sys.stdout.flush()

    # Audit: scan complete.
    try:
        from sanicode.audit import log_scan_complete

        by_severity: dict[str, int] = {}
        for ef in enriched:
            sev = (ef.derived_severity or ef.severity).lower()
            by_severity[sev] = by_severity.get(sev, 0) + 1
        log_scan_complete(
            target=str(target),
            finding_count=len(enriched),
            by_severity=by_severity,
            duration_sec=scan_duration,
            exit_code=0,
        )
    except Exception:
        pass  # Never let audit failures break the scan

    # Check --fail-on threshold.
    if fail_on:
        severity_order = {"critical": 4, "high": 3, "medium": 2, "low": 1, "info": 0}
        threshold = severity_order.get(fail_on.lower())
        if threshold is None:
            err_console.print(
                f"[red]Error:[/red] Invalid --fail-on severity: {fail_on}"
            )
            err_console.print("Valid values: critical, high, medium, low")
            raise typer.Exit(code=2)
        breaching = [
            ef for ef in enriched
            if severity_order.get(
                (ef.derived_severity or ef.severity).lower(), 0
            ) >= threshold
        ]
        if breaching:
            err_console.print(
                f"\n[red]FAIL:[/red] {len(breaching)} finding(s) at or above "
                f"'{fail_on}' severity."
            )
            raise typer.Exit(code=1)


@app.command()
def report(
    scan_result_path: Path = typer.Argument(
        ..., help="Path to a scan-result.json file."
    ),
    output_format: list[str] = typer.Option(
        ["markdown", "sarif"], "--format", "-f",
        help="Output format(s): markdown, json, sarif, html, stig-checklist, poam.",
    ),
    output_dir: Path | None = typer.Option(
        None, "--output-dir", "-o",
        help="Output directory (default: same as scan-result.json)."
    ),
    severity_filter: str | None = typer.Option(
        None, "--severity", "-s", help="Minimum severity threshold: critical, high, medium, low."
    ),
    cwe_filter: list[int] | None = typer.Option(
        None, "--cwe", help="Filter to specific CWE IDs (repeatable)."
    ),
    config_file: Path | None = typer.Option(
        None, "--config", "-c",
        help="Path to a sanicode.toml config file (for STIG asset metadata).",
    ),
    stig_hostname: str | None = typer.Option(
        None, "--stig-hostname", help="Asset hostname for STIG .ckl output."
    ),
    stig_host_ip: str | None = typer.Option(
        None, "--stig-host-ip", help="Asset IP address for STIG .ckl output."
    ),
    stig_host_fqdn: str | None = typer.Option(
        None, "--stig-host-fqdn", help="Asset FQDN for STIG .ckl output."
    ),
    domain_filter: str | None = typer.Option(
        None, "--domain", help="Filter findings to a specific domain."
    ),
    tags_filter: list[str] | None = typer.Option(
        None, "--tags", help="Filter findings that have any of the specified tags (repeatable)."
    ),
    action_filter: str | None = typer.Option(
        None, "--action", help="Filter findings by action (review, remove, refactor, flag)."
    ),
) -> None:
    """Generate reports from a saved scan-result.json file."""
    from sanicode.config import load_config
    from sanicode.report.json_report import generate_json
    from sanicode.report.markdown import generate_markdown
    from sanicode.report.persist import ScanResult, load_scan_result
    from sanicode.report.sarif import generate_sarif

    # Load config for STIG asset metadata (tolerates missing config file)
    try:
        cfg = load_config(config_file)
    except FileNotFoundError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1) from exc

    try:
        result = load_scan_result(scan_result_path)
    except FileNotFoundError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1) from exc
    except ValueError as exc:
        console.print(f"[red]Error:[/red] Invalid scan result file: {exc}")
        raise typer.Exit(code=1) from exc

    # Apply filters to findings
    filtered = result.findings

    if severity_filter:
        severity_levels = {"critical": 4, "high": 3, "medium": 2, "low": 1, "info": 0}
        threshold = severity_levels.get(severity_filter.lower())
        if threshold is None:
            console.print(f"[red]Error:[/red] Unknown severity: {severity_filter}")
            raise typer.Exit(code=1)
        filtered = [
            f for f in filtered
            if severity_levels.get(
                f.get("derived_severity") or f.get("severity", "info"), 0
            ) >= threshold
        ]

    if cwe_filter:
        cwe_set = set(cwe_filter)
        filtered = [f for f in filtered if f.get("cwe_id") in cwe_set]

    if domain_filter:
        filtered = [f for f in filtered if f.get("domain") == domain_filter]
    if tags_filter:
        tag_set = set(tags_filter)
        filtered = [f for f in filtered if tag_set & set(f.get("tags", []))]
    if action_filter:
        filtered = [f for f in filtered if f.get("action") == action_filter]

    # Build a filtered ScanResult (update summary counts)
    by_severity: dict[str, int] = {}
    by_cwe: dict[str, int] = {}
    for f in filtered:
        sev = f.get("derived_severity") or f.get("severity", "info")
        by_severity[sev] = by_severity.get(sev, 0) + 1
        cwe_key = str(f.get("cwe_id", ""))
        by_cwe[cwe_key] = by_cwe.get(cwe_key, 0) + 1

    filtered_summary = dict(result.summary)
    filtered_summary["total_findings"] = len(filtered)
    filtered_summary["by_severity"] = by_severity
    filtered_summary["by_cwe"] = by_cwe

    filtered_result = ScanResult(
        sanicode_version=result.sanicode_version,
        scan_id=result.scan_id,
        scanned_path=result.scanned_path,
        scan_timestamp=result.scan_timestamp,
        summary=filtered_summary,
        findings=filtered,
    )

    # Determine output directory
    dest = output_dir if output_dir else scan_result_path.parent
    dest.mkdir(parents=True, exist_ok=True)

    # Generate reports
    report_files: list[str] = []
    for fmt in output_format:
        if fmt == "sarif":
            out = dest / "report.sarif"
            out.write_text(json.dumps(generate_sarif(filtered_result), indent=2), encoding="utf-8")
            report_files.append("report.sarif")
        elif fmt == "json":
            out = dest / "report.json"
            out.write_text(json.dumps(generate_json(filtered_result), indent=2), encoding="utf-8")
            report_files.append("report.json")
        elif fmt == "markdown":
            out = dest / "report.md"
            out.write_text(generate_markdown(filtered_result), encoding="utf-8")
            report_files.append("report.md")
        elif fmt == "html":
            from sanicode.report.html import generate_html
            out = dest / "report.html"
            out.write_text(generate_html(filtered_result), encoding="utf-8")
            report_files.append("report.html")
        elif fmt == "stig-checklist":
            from sanicode.report.stig import generate_stig_checklist, generate_stig_summary
            asset_cfg = {
                "hostname": stig_hostname or cfg.stig.hostname,
                "host_ip": stig_host_ip or cfg.stig.host_ip,
                "host_fqdn": stig_host_fqdn or cfg.stig.host_fqdn,
                "target_comment": cfg.stig.target_comment,
                "tech_area": cfg.stig.tech_area,
            }
            ckl_out = dest / "report.ckl"
            ckl_out.write_text(
                generate_stig_checklist(filtered_result, asset_cfg), encoding="utf-8"
            )
            report_files.append("report.ckl")
            summary_out = dest / "report-stig-summary.md"
            summary_out.write_text(
                generate_stig_summary(filtered_result), encoding="utf-8"
            )
            report_files.append("report-stig-summary.md")
        elif fmt == "poam":
            from sanicode.report.poam import (
                generate_poam_csv,
                generate_poam_json,
                generate_poam_summary,
            )
            csv_content = generate_poam_csv(filtered_result)
            json_content = json.dumps(
                generate_poam_json(filtered_result), indent=2,
            )
            md_content = generate_poam_summary(filtered_result)
            dest.joinpath("report-poam.csv").write_text(
                csv_content, encoding="utf-8",
            )
            dest.joinpath("report-poam.json").write_text(
                json_content, encoding="utf-8",
            )
            dest.joinpath("report-poam-summary.md").write_text(
                md_content, encoding="utf-8",
            )
            report_files.append("report-poam.csv")
            report_files.append("report-poam.json")
            report_files.append("report-poam-summary.md")

    console.print(f"[green]Reports written to[/green] [bold]{dest}/[/bold]")
    for fname in report_files:
        console.print(f"  {fname}")


@app.command()
def enrich(
    inputs: list[Path] = typer.Argument(..., help="SARIF file(s) to enrich."),
    output: Path | None = typer.Option(
        None, "--output", "-o", help="Output file path (default: stdout)."
    ),
    merge: bool = typer.Option(
        False, "--merge", help="Merge multiple SARIF inputs into a single output."
    ),
    output_format: str = typer.Option(
        "sarif", "--format", "-f", help="Output format: sarif, json."
    ),
) -> None:
    """Enrich SARIF output from any SAST tool with compliance cross-references.

    Reads SARIF files produced by Bandit, Semgrep, CodeQL, Opengrep, or any
    SARIF-producing tool and maps CWE findings to OWASP ASVS, NIST 800-53,
    ASD STIG, PCI DSS, FedRAMP, and CMMC 2.0 controls using sanicode's
    compliance database.
    """
    from sanicode.enrich import (
        enrich_sarif,
        generate_json_summary,
        load_sarif,
        merge_sarif,
    )

    if output_format not in ("sarif", "json"):
        console.print(
            f"[red]Error:[/red] Unknown format '{output_format}'. "
            "Valid choices: sarif, json."
        )
        raise typer.Exit(code=1)

    # Load all inputs.
    documents: list[dict] = []
    for path in inputs:
        try:
            documents.append(load_sarif(path))
        except FileNotFoundError as exc:
            console.print(f"[red]Error:[/red] {exc}")
            raise typer.Exit(code=1) from exc
        except ValueError as exc:
            console.print(f"[red]Error:[/red] {exc}")
            raise typer.Exit(code=1) from exc

    input_names = [p.name for p in inputs]

    if merge and len(documents) > 1:
        documents = [merge_sarif(documents)]
        console.print(
            f"Merged {len(inputs)} SARIF files into a single document."
        )

    # Enrich each document.
    all_stats = []
    all_mappings = []
    for doc in documents:
        _, stats, mappings = enrich_sarif(doc)
        all_stats.append(stats)
        all_mappings.extend(mappings)

    # Aggregate stats across documents.
    total_results = sum(s.total_results for s in all_stats)
    total_enriched = sum(s.enriched for s in all_stats)
    total_unenriched = sum(s.unenriched for s in all_stats)

    # Print summary to stderr via Rich console.
    console.print(
        f"Enriched [bold]{total_enriched}[/bold] of "
        f"{total_results} results "
        f"({total_unenriched} without compliance data)."
    )

    # Generate output.
    if output_format == "json":
        # Aggregate stats for JSON summary.
        from sanicode.enrich import EnrichmentStats

        combined_stats = EnrichmentStats(
            total_results=total_results,
            enriched=total_enriched,
            unenriched=total_unenriched,
        )
        for s in all_stats:
            for fw, count in s.by_framework.items():
                combined_stats.by_framework[fw] = (
                    combined_stats.by_framework.get(fw, 0) + count
                )
        # Use the first (possibly merged) document for findings.
        out_data = generate_json_summary(
            documents[0], combined_stats, input_names
        )
        content = json.dumps(out_data, indent=2)
        if output:
            output.write_text(content, encoding="utf-8")
            console.print(
                f"[green]Written to[/green] [bold]{output}[/bold]"
            )
        else:
            typer.echo(content)
    elif len(documents) == 1:
        content = json.dumps(documents[0], indent=2)
        if output:
            output.write_text(content, encoding="utf-8")
            console.print(
                f"[green]Written to[/green] [bold]{output}[/bold]"
            )
        else:
            typer.echo(content)
    else:
        # Multiple SARIF documents without --merge: write each separately.
        if output:
            stem = output.stem
            suffix = output.suffix or ".sarif"
            parent = output.parent
            for i, doc in enumerate(documents):
                dest = parent / f"{stem}-{i + 1}{suffix}"
                dest.write_text(
                    json.dumps(doc, indent=2), encoding="utf-8"
                )
                console.print(
                    f"[green]Written to[/green] [bold]{dest}[/bold]"
                )
        else:
            for doc in documents:
                typer.echo(json.dumps(doc, indent=2))


def _run_domain_reachability(
    kg,
    target: Path,
    requested_domain: str | None,
    strategy_override: str | None,
    output_format: str | None,
    config_file: Path | None,
) -> None:
    """Run domain reachability analysis and display results."""
    from sanicode.config import load_config
    from sanicode.graph.domain import classify_by_domain, reconcile_domain_tags
    from sanicode.scanner.patterns import init_known_bad_patterns
    from sanicode.scanner.registry import get_registry

    # Run pattern detection to get domain-tagged findings.
    init_known_bad_patterns()
    registry = get_registry()
    findings = []
    for file_path, tree in _collect_file_trees(kg, target, registry):
        plugin = registry.for_extension(file_path.suffix)
        if plugin is not None:
            findings.extend(plugin.check_patterns(tree, file_path))

    # Enrich findings to get domain tags.
    from sanicode.compliance.enrichment import enrich_findings
    enriched = enrich_findings(findings)

    # Reconcile domain tags to graph nodes.
    reconcile_domain_tags(kg, enriched)

    # Determine strategy.
    strategy = strategy_override
    if strategy is None:
        try:
            cfg = load_config(config_file)
            strategy = cfg.domain.unclassified_strategy
        except FileNotFoundError:
            strategy = "conservative"

    # Run classification.
    result = classify_by_domain(kg, strategy=strategy, requested_domain=requested_domain)

    # Output results.
    if output_format == "json":
        output = {
            "strategy": result.strategy,
            "domain_entry_points": {
                d: len(eps) for d, eps in result.domain_entry_points.items()
            },
            "unclassified_entry_points": len(result.unclassified_entry_points),
            "exclusive_counts": result.exclusive_counts,
            "shared_count": result.shared_count,
            "unreachable_count": result.unreachable_count,
            "unclassified_reachable_count": result.unclassified_reachable_count,
            "classifications": {
                node_id: {
                    "classification": c.classification,
                    "domains": sorted(c.domains),
                    "exclusive_domain": c.exclusive_domain,
                    "confidence": c.confidence,
                }
                for node_id, c in result.classifications.items()
            },
        }
        console.print_json(json.dumps(output, default=str))
    else:
        _print_domain_reachability_summary(result)


def _collect_file_trees(kg, target: Path, registry):
    """Parse source files for pattern detection (reusable helper)."""
    if target.is_file():
        plugin = registry.for_extension(target.suffix)
        if plugin is not None:
            tree = plugin.parse_file(target)
            if not tree.root_node.has_error:
                yield (target, tree)
    else:
        for src_file in sorted(target.rglob("*")):
            plugin = registry.for_extension(src_file.suffix)
            if plugin is None:
                continue
            tree = plugin.parse_file(src_file)
            if not tree.root_node.has_error:
                yield (src_file, tree)


def _print_domain_reachability_summary(result) -> None:
    """Print a rich summary of domain reachability results."""
    console.print()
    console.print(Panel("[bold]Domain Reachability Analysis[/bold]"))
    console.print(f"  Strategy: [bold]{result.strategy}[/bold]")
    console.print()

    # Entry points by domain.
    if result.domain_entry_points:
        ep_table = Table(title="Entry Points by Domain", show_lines=False)
        ep_table.add_column("Domain", style="bold")
        ep_table.add_column("Entry Points", justify="right")
        for domain, eps in sorted(result.domain_entry_points.items()):
            ep_table.add_row(domain, str(len(eps)))
        console.print(ep_table)
    else:
        console.print("  [yellow]No domain-tagged entry points found.[/yellow]")

    if result.unclassified_entry_points:
        console.print(
            f"  Unclassified entry points: [yellow]{len(result.unclassified_entry_points)}[/yellow]"
        )

    console.print()

    # Node classification counts.
    counts_table = Table(title="Node Classifications", show_lines=False)
    counts_table.add_column("Classification", style="bold")
    counts_table.add_column("Count", justify="right")

    for domain, count in sorted(result.exclusive_counts.items()):
        if count > 0:
            counts_table.add_row(f"Exclusive ({domain})", str(count))
    if result.shared_count:
        counts_table.add_row("Shared", str(result.shared_count))
    if result.unreachable_count:
        counts_table.add_row("Unreachable", str(result.unreachable_count))
    if result.unclassified_reachable_count:
        counts_table.add_row("Unclassified Reachable", str(result.unclassified_reachable_count))

    console.print(counts_table)


def _run_pruning_plan(
    kg,
    target: Path,
    remove_domain: str,
    strategy_override: str | None,
    output_format: str | None,
    config_file: Path | None,
) -> None:
    """Run pruning plan analysis and display results."""
    from sanicode.config import load_config
    from sanicode.graph.domain import build_pruning_plan, reconcile_domain_tags
    from sanicode.scanner.patterns import init_known_bad_patterns
    from sanicode.scanner.registry import get_registry

    # Run pattern detection to get domain-tagged findings.
    init_known_bad_patterns()
    registry = get_registry()
    findings = []
    for file_path, tree in _collect_file_trees(kg, target, registry):
        plugin = registry.for_extension(file_path.suffix)
        if plugin is not None:
            findings.extend(plugin.check_patterns(tree, file_path))

    # Enrich findings to get domain tags.
    from sanicode.compliance.enrichment import enrich_findings
    enriched = enrich_findings(findings)

    # Reconcile domain tags to graph nodes.
    reconcile_domain_tags(kg, enriched)

    # Determine strategy.
    strategy = strategy_override
    if strategy is None:
        try:
            cfg = load_config(config_file)
            strategy = cfg.domain.unclassified_strategy
        except FileNotFoundError:
            strategy = "conservative"

    # Build pruning plan.
    plan = build_pruning_plan(kg, remove_domain, strategy=strategy)

    # Content policy: scan for domain-filtered matches.
    try:
        cp_cfg_source = load_config(config_file)
        cp_cfg = cp_cfg_source.content_policy
    except FileNotFoundError:
        from sanicode.config import ContentPolicyConfig
        cp_cfg = ContentPolicyConfig()

    if cp_cfg.enabled and cp_cfg.patterns:
        from sanicode.scanner.content_policy import scan_content_policy

        domain_patterns = [p for p in cp_cfg.patterns if p.domain == remove_domain]
        if domain_patterns:
            from sanicode.config import ContentPolicyConfig as CPConfig
            filtered_cfg = CPConfig(
                enabled=True,
                patterns=domain_patterns,
                include_globs=cp_cfg.include_globs,
                exclude_globs=cp_cfg.exclude_globs,
            )
            cp_result = scan_content_policy(target, filtered_cfg)
            plan.content_policy_matches = cp_result.findings

    # Output results.
    if output_format == "json":
        output = {
            "remove_domain": plan.remove_domain,
            "strategy": plan.strategy,
            "total_nodes": plan.total_nodes,
            "safe_to_prune_count": len(plan.safe_to_prune),
            "needs_analysis_count": len(plan.needs_analysis),
            "safe_to_keep_count": plan.safe_to_keep_count,
            "safe_to_prune": [
                {
                    "node_id": pc.node_id,
                    "category": pc.category,
                    "file": pc.node_attrs.get("file"),
                    "line": pc.node_attrs.get("line"),
                    "label": pc.node_attrs.get("label"),
                    "kind": pc.node_attrs.get("kind"),
                    "confidence": pc.confidence,
                    "backward_paths": pc.backward_paths,
                }
                for pc in plan.safe_to_prune
            ],
            "needs_analysis": [
                {
                    "node_id": pc.node_id,
                    "category": pc.category,
                    "file": pc.node_attrs.get("file"),
                    "line": pc.node_attrs.get("line"),
                    "label": pc.node_attrs.get("label"),
                    "kind": pc.node_attrs.get("kind"),
                    "confidence": pc.confidence,
                    "shared_with": pc.shared_with,
                    "backward_paths": pc.backward_paths,
                    "relationship_type": pc.relationship_type,
                    "suggested_action": pc.suggested_action,
                }
                for pc in plan.needs_analysis
            ],
            "content_policy_matches": [
                {
                    "rule_id": f.rule_id,
                    "file": str(f.file),
                    "line": f.line,
                    "severity": str(f.severity),
                    "message": f.message,
                    "domain": f.domain,
                }
                for f in plan.content_policy_matches
            ],
        }
        console.print_json(json.dumps(output, default=str))
    else:
        _print_pruning_plan(plan)


def _print_pruning_plan(plan) -> None:
    """Print a rich summary of a pruning plan."""
    console.print()
    console.print(Panel(f"[bold]Pruning Plan — Remove '{plan.remove_domain}'[/bold]"))
    console.print(f"  Strategy: [bold]{plan.strategy}[/bold]")
    console.print(f"  Total nodes: {plan.total_nodes}")
    console.print()

    # Safe to prune table.
    if plan.safe_to_prune:
        prune_table = Table(
            title=f"Safe to Prune ({len(plan.safe_to_prune)} nodes)", show_lines=False
        )
        prune_table.add_column("Node", style="bold")
        prune_table.add_column("File:Line")
        prune_table.add_column("Kind")
        prune_table.add_column("Confidence")
        for pc in plan.safe_to_prune:
            label = pc.node_attrs.get("label", pc.node_id)
            file_val = pc.node_attrs.get("file", "")
            line_val = pc.node_attrs.get("line", "")
            loc = f"{file_val}:{line_val}" if file_val else ""
            kind = pc.node_attrs.get("kind", "")
            prune_table.add_row(label, loc, kind, pc.confidence)
        console.print(prune_table)
    else:
        console.print("  [green]No nodes safe to prune.[/green]")

    console.print()

    # Needs analysis table.
    if plan.needs_analysis:
        analysis_table = Table(
            title=f"Needs Analysis ({len(plan.needs_analysis)} nodes)", show_lines=False
        )
        analysis_table.add_column("Node", style="bold")
        analysis_table.add_column("File:Line")
        analysis_table.add_column("Kind")
        analysis_table.add_column("Shared With")
        analysis_table.add_column("Confidence")
        analysis_table.add_column("Relationship")
        analysis_table.add_column("Suggested Action")
        for pc in plan.needs_analysis:
            label = pc.node_attrs.get("label", pc.node_id)
            file_val = pc.node_attrs.get("file", "")
            line_val = pc.node_attrs.get("line", "")
            loc = f"{file_val}:{line_val}" if file_val else ""
            kind = pc.node_attrs.get("kind", "")
            shared = ", ".join(pc.shared_with) if pc.shared_with else ""
            analysis_table.add_row(
                label, loc, kind, shared, pc.confidence,
                pc.relationship_type, pc.suggested_action,
            )
        console.print(analysis_table)
    else:
        console.print("  [green]No nodes need analysis.[/green]")

    # Content to scrub table.
    if plan.content_policy_matches:
        console.print()
        scrub_table = Table(
            title=f"Content to Scrub ({len(plan.content_policy_matches)} matches)",
            show_lines=False,
        )
        scrub_table.add_column("Pattern", style="bold")
        scrub_table.add_column("File:Line")
        scrub_table.add_column("Severity")
        scrub_table.add_column("Message")
        for finding in plan.content_policy_matches:
            scrub_table.add_row(
                finding.rule_id,
                f"{finding.file}:{finding.line}",
                str(finding.severity),
                finding.message,
            )
        console.print(scrub_table)

    console.print()
    console.print(f"  Safe to keep: [bold green]{plan.safe_to_keep_count}[/bold green] nodes")


@app.command()
def graph(
    path: Path = typer.Argument(
        Path("."), help="Path to the codebase to build a graph from."
    ),
    export: Path | None = typer.Option(
        None, "--export", "-e", help="Export graph to this file (JSON). Omit for stdout."
    ),
    visualize: Path | None = typer.Option(
        None, "--visualize", "--viz",
        help="Generate an interactive HTML visualization at this path."
    ),
    domain_reachability: bool = typer.Option(
        False, "--domain-reachability",
        help="Run domain reachability analysis on the graph.",
    ),
    domain: str | None = typer.Option(
        None, "--domain",
        help="Filter domain reachability to a specific domain.",
    ),
    unclassified_strategy: str | None = typer.Option(
        None, "--unclassified-strategy",
        help="Strategy for unclassified entry points: conservative, strict, report-only.",
    ),
    output_format: str | None = typer.Option(
        None, "--format",
        help="Output format for domain reachability: json or summary (default: summary).",
    ),
    pruning_plan: bool = typer.Option(
        False, "--pruning-plan",
        help="Generate a pruning plan for removing a domain from a deliverable.",
    ),
    remove_domain: str | None = typer.Option(
        None, "--remove-domain",
        help="Domain to remove (required with --pruning-plan).",
    ),
    config_file: Path | None = typer.Option(
        None, "--config", "-c", help="Path to a sanicode.toml config file."
    ),
) -> None:
    """Build and inspect or export the knowledge graph."""
    from sanicode.graph.builder import KnowledgeGraph

    target = path.resolve()
    if not target.exists():
        console.print(f"[red]Error:[/red] Path does not exist: {target}")
        raise typer.Exit(code=1)

    kg = KnowledgeGraph.from_source(target)

    if domain_reachability:
        _run_domain_reachability(
            kg, target, domain, unclassified_strategy, output_format, config_file,
        )
        return

    if pruning_plan:
        if not remove_domain:
            console.print("[red]Error:[/red] --remove-domain is required with --pruning-plan")
            raise typer.Exit(code=1)
        _run_pruning_plan(
            kg, target, remove_domain, unclassified_strategy, output_format, config_file,
        )
        return

    data = kg.to_dict()

    if export:
        export.write_text(json.dumps(data, indent=2, default=str), encoding="utf-8")
        console.print(f"Graph exported to [bold]{export}[/bold] "
                      f"({kg.node_count} nodes, {kg.edge_count} edges)")

    if visualize:
        from treeloom import NodeKind as TLNodeKind
        from treeloom import generate_html as treeloom_generate_html

        from sanicode.graph.overlays import build_security_overlays
        overlays = build_security_overlays(kg.cpg)
        html_content = treeloom_generate_html(
            kg.cpg,
            overlays=overlays,
            title="Sanicode — Knowledge Graph",
            exclude_kinds=frozenset({TLNodeKind.IMPORT}),
        )
        visualize.write_text(html_content, encoding="utf-8")
        console.print(f"Visualization written to [bold]{visualize}[/bold] "
                      f"({kg.node_count} nodes, {kg.edge_count} edges)")

    if not export and not visualize:
        console.print_json(json.dumps(data, default=str))


@app.command()
def rules(
    list_rules: bool = typer.Option(False, "--list", "-l", help="List all registered rules."),
    validate: Path | None = typer.Option(
        None, "--validate", help="Validate a YAML rules file and report any errors."
    ),
) -> None:
    """List or validate detection rules."""
    from sanicode.rules import get_rule_registry, init_rules
    from sanicode.rules.custom import load_yaml_rules

    if validate is not None:
        # Initialise the built-in rule registry before validating user YAML.
        # This ensures sanicode.rules.base is loaded so _spec_to_rule can
        # import CallRule without any import-order surprises.
        init_rules()
        # Validate mode — parse the file and report errors without touching the registry.
        try:
            loaded = load_yaml_rules(validate)
        except FileNotFoundError as exc:
            console.print(f"[red]Error:[/red] {exc}")
            raise typer.Exit(code=1) from exc
        except ValueError as exc:
            from rich.markup import escape
            console.print(f"[red]Validation failed:[/red] {escape(str(exc))}")
            raise typer.Exit(code=1) from exc

        console.print(
            f"[green]OK[/green] {validate} — {len(loaded)} rule(s) valid"
        )
        for rule in loaded:
            parts = [f"  {rule.rule_id}  [{rule.language}]"]
            if rule.cwe_id:
                parts.append(f"CWE-{rule.cwe_id}")
            if rule.domain:
                parts.append(f"domain={rule.domain}")
            parts.append(rule.severity)
            if rule.tags:
                parts.append(f"tags={rule.tags}")
            console.print("  ".join(parts))
        return

    if not list_rules:
        # Neither flag given — show help excerpt.
        console.print("Use [bold]--list[/bold] to show all rules or "
                      "[bold]--validate <file>[/bold] to validate a YAML rules file.")
        raise typer.Exit()

    # List mode — discover and display all registered rules.
    init_rules()
    registry = get_rule_registry()
    all_registered = registry.all_rules()

    if not all_registered:
        console.print("No rules registered.")
        raise typer.Exit()

    # Check if any rule uses classification fields
    any_domain = any(getattr(r, "domain", "") for r in all_registered)
    any_tags = any(getattr(r, "tags", []) for r in all_registered)

    table = Table(title=f"Registered Rules ({len(all_registered)} total)", show_lines=False)
    table.add_column("ID", style="bold", no_wrap=True)
    table.add_column("CWE", no_wrap=True)
    table.add_column("Severity")
    table.add_column("Language")
    table.add_column("Message")
    if any_domain:
        table.add_column("Domain")
    if any_tags:
        table.add_column("Tags")

    severity_styles = {
        "critical": "red",
        "high": "red",
        "medium": "yellow",
        "low": "dim",
        "info": "dim",
    }

    for rule in sorted(all_registered, key=lambda r: r.rule_id):
        sev = rule.severity
        sev_styled = f"[{severity_styles.get(sev, '')}]{sev}[/{severity_styles.get(sev, '')}]"
        row = [
            rule.rule_id,
            f"CWE-{rule.cwe_id}" if rule.cwe_id else "",
            sev_styled,
            rule.language,
            rule.message,
        ]
        if any_domain:
            row.append(getattr(rule, "domain", ""))
        if any_tags:
            tags = getattr(rule, "tags", [])
            row.append(", ".join(tags) if tags else "")
        table.add_row(*row)

    console.print(table)


@app.command(name="validate-rules")
def validate_rules(
    rule_file: Path = typer.Argument(..., help="Path to a custom pattern-rule YAML file."),
) -> None:
    """Validate regex-based custom rule YAML syntax."""
    from sanicode.rules.pattern_rules import load_pattern_rules

    try:
        rules = load_pattern_rules(rule_file)
    except FileNotFoundError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1) from exc
    except ValueError as exc:
        from rich.markup import escape
        console.print(f"[red]Validation failed:[/red]\n{escape(str(exc))}")
        raise typer.Exit(code=1) from exc

    # Use typer.echo (plain text, no Rich wrapping) for the summary line so
    # that headless CI environments with narrow terminal widths don't split
    # "N rule(s) valid" across a line boundary. See issue #227.
    typer.echo(f"OK {rule_file} -- {len(rules)} rule(s) valid")
    for rule in rules:
        typer.echo(
            f"  {rule.rule_id}: {rule.name}  [CWE-{rule.cwe_id}] [{rule.severity}]"
        )


@app.command(name="test-rules")
def test_rules(
    rule_file: Path = typer.Argument(..., help="Path to a custom pattern-rule YAML file."),
    fixture: Path = typer.Option(
        ..., "--fixture", "-f", help="Path to a source file to test against."
    ),
) -> None:
    """Test regex-based custom rules against a fixture file."""
    from sanicode.rules.pattern_rules import apply_pattern_rules, load_pattern_rules

    try:
        rules = load_pattern_rules(rule_file)
    except (FileNotFoundError, ValueError) as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1) from exc

    try:
        content = fixture.read_text(encoding="utf-8")
    except FileNotFoundError:
        console.print(f"[red]Error:[/red] Fixture file not found: {fixture}")
        raise typer.Exit(code=1) from None

    findings = apply_pattern_rules(rules, fixture, content)
    if findings:
        console.print(f"[bold]{len(findings)} finding(s):[/bold]")
        for f in findings:
            console.print(
                f"  {f.rule_id} at {f.file}:{f.line} -- {f.message}"
            )
    else:
        console.print("[yellow]No findings.[/yellow]")


@app.command()
def serve(
    host: str = typer.Option("0.0.0.0", "--host", help="Host to bind the API server to."),
    port: int = typer.Option(8080, "--port", "-p", help="Port to listen on."),
    config_file: Path | None = typer.Option(
        None, "--config", "-c", help="Path to a sanicode.toml config file."
    ),
) -> None:
    """Start the Sanicode FastAPI server for remote/hybrid scan mode."""
    import uvicorn

    from sanicode.config import load_config
    from sanicode.server.app import app as fastapi_app
    from sanicode.server.app import configure

    try:
        cfg = load_config(config_file)
    except FileNotFoundError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1) from exc

    configure(cfg)
    console.print(f"Starting Sanicode API server on {host}:{port}")
    console.print(f"  Docs: http://{host}:{port}/api/v1/docs")
    console.print(f"  Metrics: http://{host}:{port}/metrics")
    uvicorn.run(fastapi_app, host=host, port=port)


@app.command()
def score(
    repos_dir: Path = typer.Argument(..., help="Path to the unsanitary-code-examples repo."),
    scoring_dir: Path | None = typer.Option(
        None, "--scoring-dir", help="Path to scoring/ directory. Default: repos_dir/scoring/."
    ),
    output_dir: Path = typer.Option(
        Path("./sanicode-scores"), "--output-dir", "-o", help="Output directory for score reports."
    ),
    repos: list[str] | None = typer.Option(
        None, "--repos", "-r", help="Only score these repos (by name). Repeatable."
    ),
    no_llm_judge: bool = typer.Option(
        False, "--no-llm-judge", help="Skip LLM judge (mechanical scoring only)."
    ),
    config_file: Path | None = typer.Option(
        None, "--config", "-c", help="Path to a sanicode.toml config file."
    ),
    baseline: Path | None = typer.Option(
        None, "--baseline", help="Path to a previous scoring-report.json for delta comparison."
    ),
) -> None:
    """Score sanicode against ground-truth vulnerability catalogs."""
    from sanicode.config import load_config
    from sanicode.scoring.report import (
        compute_delta,
        generate_json_report,
        generate_summary,
        save_report,
    )
    from sanicode.scoring.runner import run_scoring

    # Resolve scoring directory
    resolved_scoring = scoring_dir if scoring_dir else repos_dir / "scoring"
    if not resolved_scoring.exists():
        console.print(
            f"[red]Error:[/red] Scoring directory not found: {resolved_scoring}"
        )
        raise typer.Exit(code=1)

    try:
        cfg = load_config(config_file)
    except FileNotFoundError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1) from exc

    console.print(f"Scoring against repos at [bold]{repos_dir}[/bold]")
    console.print(f"Ground truth from [bold]{resolved_scoring}[/bold]")
    if no_llm_judge:
        console.print("[dim]LLM judge disabled — mechanical scoring only[/dim]")

    report = run_scoring(
        repos_dir=repos_dir.resolve(),
        scoring_dir=resolved_scoring.resolve(),
        output_dir=output_dir.resolve(),
        cfg=cfg,
        repos_filter=repos if repos else None,
        skip_llm_judge=no_llm_judge,
    )

    # Print summary to terminal
    console.print()
    console.print(generate_summary(report))

    # Save JSON report
    json_path = save_report(report, output_dir.resolve())
    console.print()
    console.print(f"[green]Report saved to[/green] [bold]{json_path}[/bold]")

    if baseline:
        if not baseline.exists():
            console.print(f"[red]Error:[/red] Baseline file not found: {baseline}")
            raise typer.Exit(code=1)

        import json as json_mod

        prev_data = json_mod.loads(baseline.read_text(encoding="utf-8"))
        curr_data = generate_json_report(report)
        delta = compute_delta(curr_data, prev_data)

        console.print()
        console.print("[bold]Delta vs baseline:[/bold]")
        agg = delta.get("aggregate", {})
        findings_d = agg.get("findings_delta", 0)
        sign = "+" if findings_d > 0 else ""
        console.print(f"  Findings: {sign}{findings_d}")
        console.print(
            f"  Grade: {agg.get('grade', {}).get('previous', '?')} -> "
            f"{agg.get('grade', {}).get('current', '?')}"
        )

        if "gap_count_delta" in agg:
            gap_d = agg["gap_count_delta"]
            gap_sign = "+" if gap_d > 0 else ""
            console.print(f"  Gaps: {gap_sign}{gap_d}")

        for rd in delta.get("per_repo", []):
            if rd.get("status") == "new":
                console.print(
                    f"  [green]+ {rd['name']}[/green] (new, {rd['findings_delta']} findings)"
                )
            elif rd.get("status") == "removed":
                console.print(f"  [red]- {rd['name']}[/red] (removed)")
            elif rd.get("findings_delta", 0) != 0:
                fd = rd["findings_delta"]
                s = "+" if fd > 0 else ""
                console.print(f"  {rd['name']}: {s}{fd} findings")
                if rd.get("gaps_closed"):
                    console.print(f"    Gaps closed: {', '.join(rd['gaps_closed'])}")
                if rd.get("gaps_opened"):
                    console.print(f"    Gaps opened: {', '.join(rd['gaps_opened'])}")

        delta_path = output_dir.resolve() / "scoring-delta.json"
        delta_path.write_text(json_mod.dumps(delta, indent=2, default=str), encoding="utf-8")
        console.print(f"\n[green]Delta saved to[/green] [bold]{delta_path}[/bold]")


@app.command()
def benchmark(
    corpus_dir: Path | None = typer.Argument(
        None, help="Path to benchmark corpus directory (default: bundled)."
    ),
    tools: list[str] = typer.Option(
        ["sanicode"], "--tool", "-t",
        help="Tools to benchmark. Repeatable. Choices: sanicode, bandit, semgrep.",
    ),
    output: Path | None = typer.Option(
        None, "--output", "-o", help="Save raw results to this JSON file."
    ),
) -> None:
    """Run benchmarks comparing sanicode against other security tools."""
    from sanicode.benchmarks.runner import (
        bundled_corpus_dir,
        bundled_ground_truth_path,
        compare_results,
        load_ground_truth,
        run_bandit_benchmark,
        run_sanicode_benchmark,
        run_semgrep_benchmark,
    )

    resolved_corpus = (corpus_dir or bundled_corpus_dir()).resolve()
    if not resolved_corpus.exists():
        console.print(f"[red]Error:[/red] Corpus directory not found: {resolved_corpus}")
        raise typer.Exit(code=1)

    ground_truth_path = bundled_ground_truth_path()
    if not ground_truth_path.exists():
        console.print(f"[red]Error:[/red] Ground truth file not found: {ground_truth_path}")
        raise typer.Exit(code=1)

    ground_truth = load_ground_truth(ground_truth_path)
    console.print(
        f"Corpus: [bold]{resolved_corpus}[/bold] "
        f"({len(ground_truth)} files in ground truth)"
    )

    valid_tools = {"sanicode", "bandit", "semgrep"}
    invalid = set(tools) - valid_tools
    if invalid:
        console.print(
            f"[red]Error:[/red] Unknown tool(s): {', '.join(sorted(invalid))}. "
            f"Valid choices: {', '.join(sorted(valid_tools))}"
        )
        raise typer.Exit(code=1)

    all_results: dict = {}

    if "sanicode" in tools:
        console.print("Running [bold]sanicode[/bold] ...")
        all_results["sanicode"] = run_sanicode_benchmark(resolved_corpus, ground_truth)

    if "bandit" in tools:
        console.print("Running [bold]bandit[/bold] ...")
        all_results["bandit"] = run_bandit_benchmark(resolved_corpus, ground_truth)
        if not all_results["bandit"]:
            console.print("[yellow]  bandit not installed — skipped[/yellow]")

    if "semgrep" in tools:
        console.print("Running [bold]semgrep[/bold] ...")
        all_results["semgrep"] = run_semgrep_benchmark(resolved_corpus, ground_truth)
        if not all_results["semgrep"]:
            console.print("[yellow]  semgrep not installed — skipped[/yellow]")

    console.print()
    console.print(compare_results(all_results))

    if output:
        import dataclasses as _dc
        import json as _json
        serializable = {
            tool: [_dc.asdict(r) for r in res]
            for tool, res in all_results.items()
        }
        output.write_text(_json.dumps(serializable, indent=2), encoding="utf-8")
        console.print(f"[green]Results saved to[/green] [bold]{output}[/bold]")


@app.command(name="validate-llm")
def validate_llm(
    corpus_dir: Path | None = typer.Argument(
        None, help="Path to validation corpus. Default: bundled."
    ),
    passes: str | None = typer.Option(
        None, "--pass", "-p",
        help="Comma-separated passes to run: static,classify,analyze,full.",
    ),
    output: Path | None = typer.Option(
        None, "--output", "-o", help="Save results to this JSON file."
    ),
    markdown: Path | None = typer.Option(
        None, "--markdown", "-m", help="Save results as markdown."
    ),
    config_file: Path | None = typer.Option(
        None, "--config", "-c", help="Path to a sanicode.toml config file."
    ),
) -> None:
    """Validate LLM integration quality against a curated corpus.

    Runs the validation corpus through up to four pipeline passes
    (static → classify → analyze → full) and prints a quality comparison
    table showing how each LLM tier improves precision/recall/F1.

    Exits 0 if the LLM meets the minimum quality bar (FP reduction >=15%
    or TP increase >=10%). Exits 1 if it falls short or only one pass is run.
    """
    from sanicode.config import load_config
    from sanicode.validation.report import format_markdown, format_table, save_json
    from sanicode.validation.runner import (
        PASS_CONFIGS,
        bundled_corpus_dir,
        bundled_ground_truth_path,
        check_minimum_bar,
        run_validation,
    )

    try:
        cfg = load_config(config_file)
    except FileNotFoundError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1) from exc

    resolved_corpus = (corpus_dir or bundled_corpus_dir()).resolve()
    ground_truth_path = bundled_ground_truth_path()

    if not resolved_corpus.exists():
        console.print(
            f"[red]Error:[/red] Corpus directory not found: {resolved_corpus}"
        )
        raise typer.Exit(code=1)

    if not ground_truth_path.exists():
        console.print(
            f"[red]Error:[/red] Ground truth not found: {ground_truth_path}"
        )
        raise typer.Exit(code=1)

    # Parse requested passes.
    pass_list: list[str] | None = None
    if passes:
        pass_list = [p.strip() for p in passes.split(",") if p.strip()]
        invalid = [p for p in pass_list if p not in PASS_CONFIGS]
        if invalid:
            console.print(
                f"[red]Error:[/red] Unknown pass(es): {', '.join(invalid)}. "
                f"Valid: {', '.join(PASS_CONFIGS.keys())}"
            )
            raise typer.Exit(code=1)

    console.print(
        f"Running LLM validation against [bold]{resolved_corpus}[/bold] ..."
    )

    result = run_validation(
        corpus_dir=resolved_corpus,
        ground_truth_path=ground_truth_path,
        cfg=cfg,
        passes=pass_list,
    )

    table_text = format_table(result)
    console.print()
    console.print(table_text)
    console.print()

    if output:
        save_json(result, output)
        console.print(f"[green]Results saved to[/green] [bold]{output}[/bold]")

    if markdown:
        md_text = format_markdown(result)
        markdown.write_text(md_text, encoding="utf-8")
        console.print(f"[green]Markdown saved to[/green] [bold]{markdown}[/bold]")

    # Exit logic: only compare when multiple passes were run.
    only_static = (
        pass_list is not None
        and len(pass_list) == 1
        and pass_list[0] == "static"
    )
    if only_static or len(result.passes) <= 1:
        # Nothing to compare — always exit 0.
        raise typer.Exit(code=0)

    if check_minimum_bar(result):
        console.print("[green]LLM quality bar met.[/green]")
        raise typer.Exit(code=0)
    else:
        console.print(
            "[yellow]LLM quality bar not met[/yellow] "
            "(FP reduction <15% and TP change <10%)."
        )
        raise typer.Exit(code=1)


@app.command()
def deps(
    path: Path = typer.Argument(Path("."), help="Path to scan for lockfiles."),
    sbom_path: Path | None = typer.Option(
        None, "--sbom", help="Write CycloneDX SBOM to this path."
    ),
    offline: bool = typer.Option(
        False, "--offline", help="Skip OSV queries."
    ),
    output_format: str = typer.Option(
        "table", "--format", "-f", help="Output format: table, json."
    ),
) -> None:
    """Scan lockfiles for dependency vulnerabilities."""
    from sanicode.dependencies.integration import scan_dependencies
    from sanicode.dependencies.sbom import sbom_to_json

    target = path.resolve()
    if not target.exists():
        console.print(f"[red]Error:[/red] Path does not exist: {target}")
        raise typer.Exit(code=1)

    result = scan_dependencies(
        target,
        osv_enabled=not offline,
        generate_sbom_flag=sbom_path is not None,
    )

    if not result.lockfiles_scanned:
        console.print("No lockfiles found.")
        raise typer.Exit()

    if output_format == "json":
        data = {
            "lockfiles": [str(lf) for lf in result.lockfiles_scanned],
            "dependency_count": len(result.dependencies),
            "findings": [
                {
                    "package": f.dependency.name,
                    "version": f.dependency.version,
                    "ecosystem": f.dependency.ecosystem,
                    "vulnerability": f.vulnerability.osv_id,
                    "severity": f.severity,
                    "cwe_id": f.cwe_id,
                    "summary": f.vulnerability.summary,
                }
                for f in result.findings
            ],
        }
        typer.echo(json.dumps(data, indent=2))
    else:
        # Table output
        console.print(
            f"Scanned {len(result.lockfiles_scanned)} lockfile(s), "
            f"found {len(result.dependencies)} dependencies."
        )

        if result.findings:
            table = Table(title="Dependency Vulnerabilities", show_lines=False)
            table.add_column("Package", style="bold")
            table.add_column("Version")
            table.add_column("Vuln ID", style="cyan")
            table.add_column("Severity")
            table.add_column("Summary")

            for f in result.findings:
                sev = f.severity
                if sev in ("critical", "high"):
                    sev_style = f"[red]{sev}[/red]"
                elif sev == "medium":
                    sev_style = f"[yellow]{sev}[/yellow]"
                else:
                    sev_style = f"[dim]{sev}[/dim]"

                table.add_row(
                    f.dependency.name,
                    f.dependency.version,
                    f.vulnerability.osv_id,
                    sev_style,
                    f.vulnerability.summary[:80],
                )
            console.print(table)
        else:
            console.print("[green]No known vulnerabilities found.[/green]")

    if sbom_path and result.sbom:
        sbom_path.write_text(sbom_to_json(result.sbom), encoding="utf-8")
        console.print(f"[green]SBOM written to[/green] [bold]{sbom_path}[/bold]")


# ---------------------------------------------------------------------------
# Diff — compare two scan results
# ---------------------------------------------------------------------------

_DIFF_SEV_ORDER = {"critical": 4, "high": 3, "medium": 2, "low": 1, "info": 0}


@app.command()
def diff(
    baseline: Path = typer.Argument(
        ...,
        help="Path to baseline scan-result JSON file.",
    ),
    current: Path = typer.Argument(
        ...,
        help="Path to current scan-result JSON file.",
    ),
    output_format: str = typer.Option(
        "table",
        "--format",
        "-f",
        help="Output format: table (human-readable) or json.",
    ),
) -> None:
    """Compare two scan results and show what changed."""
    from sanicode.report.diff import compare_scan_results

    for p in (baseline, current):
        if not p.exists():
            err_console.print(f"[red]Error:[/red] File not found: {p}")
            raise typer.Exit(code=2)

    result = compare_scan_results(baseline, current)

    if output_format == "json":
        console.print_json(data=result.to_dict())
        return

    # Table output
    console.print()

    # Summary
    delta_sign = "+" if result.score_delta > 0 else ""
    score_color = (
        "red"
        if result.score_delta > 0
        else "green"
        if result.score_delta < 0
        else "dim"
    )
    console.print(
        f"[bold]Baseline:[/bold] {result.baseline_count} findings "
        f"(score: {result.baseline_score})"
    )
    console.print(
        f"[bold]Current:[/bold]  {result.current_count} findings "
        f"(score: {result.current_score})"
    )
    console.print(
        f"[bold]Delta:[/bold]    [{score_color}]{delta_sign}{result.score_delta}"
        f"[/{score_color}] (weighted by severity)"
    )
    console.print()

    # Removed (fixed) findings
    if result.removed:
        removed_table = Table(
            title=f"[green]Fixed ({len(result.removed)})[/green]",
            show_lines=False,
        )
        removed_table.add_column("File", style="cyan")
        removed_table.add_column("Line", justify="right")
        removed_table.add_column("Severity")
        removed_table.add_column("Rule", style="bold")
        removed_table.add_column("CWE")
        for f in result.removed:
            sev = f.get("derived_severity") or f.get("severity", "")
            removed_table.add_row(
                f.get("file", ""),
                str(f.get("line", "")),
                sev,
                f.get("rule_id", ""),
                f"CWE-{f.get('cwe_id', '?')}",
            )
        console.print(removed_table)
        console.print()

    # Added (new) findings
    if result.added:
        added_table = Table(
            title=f"[red]New ({len(result.added)})[/red]",
            show_lines=False,
        )
        added_table.add_column("File", style="cyan")
        added_table.add_column("Line", justify="right")
        added_table.add_column("Severity")
        added_table.add_column("Rule", style="bold")
        added_table.add_column("CWE")
        for f in result.added:
            sev = f.get("derived_severity") or f.get("severity", "")
            added_table.add_row(
                f.get("file", ""),
                str(f.get("line", "")),
                sev,
                f.get("rule_id", ""),
                f"CWE-{f.get('cwe_id', '?')}",
            )
        console.print(added_table)
        console.print()

    # Severity breakdown
    if result.removed or result.added:
        breakdown = Table(title="By Severity", show_lines=False)
        breakdown.add_column("Severity", style="bold")
        breakdown.add_column("Fixed", justify="right", style="green")
        breakdown.add_column("New", justify="right", style="red")
        removed_by_sev = result.by_severity(result.removed)
        added_by_sev = result.by_severity(result.added)
        sevs = sorted(
            set(list(removed_by_sev) + list(added_by_sev)),
            key=lambda s: _DIFF_SEV_ORDER.get(s, 0),
            reverse=True,
        )
        for sev in sevs:
            breakdown.add_row(
                sev,
                str(removed_by_sev.get(sev, 0)),
                str(added_by_sev.get(sev, 0)),
            )
        console.print(breakdown)

    if not result.removed and not result.added:
        console.print("[dim]No differences found.[/dim]")


# ---------------------------------------------------------------------------
# Baseline management
# ---------------------------------------------------------------------------

baseline_app = typer.Typer(help="Manage scan baselines for incremental adoption.")
app.add_typer(baseline_app, name="baseline")


@baseline_app.command("create")
def baseline_create(
    scan_dir: Path = typer.Argument(
        Path("sanicode-reports"),
        help="Directory containing scan-result.json from a previous scan.",
    ),
    output: Path = typer.Option(
        Path(".sanicode-baseline.json"),
        "--output",
        "-o",
        help="Path to write the baseline file.",
    ),
    target: Path = typer.Option(
        Path("."),
        "--target",
        "-t",
        help="Root of the scanned codebase (for relative paths).",
    ),
) -> None:
    """Create a baseline from existing scan results.

    The baseline captures all current findings so that subsequent scans
    (with ``--baseline``) only report *new* issues.
    """
    from sanicode.baseline import Baseline, BaselineEntry, _line_hash
    from sanicode.report.persist import load_scan_result

    scan_result_path = scan_dir / "scan-result.json" if scan_dir.is_dir() else scan_dir
    try:
        result = load_scan_result(scan_result_path)
    except FileNotFoundError as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(code=1) from exc
    except ValueError as exc:
        console.print(f"[red]Error:[/red] Invalid scan result: {exc}")
        raise typer.Exit(code=1) from exc

    target = target.resolve()
    entries: list[BaselineEntry] = []
    for f in result.findings:
        file_str = f.get("file", "")
        abs_file = (target / file_str).resolve()
        line = f.get("line", 0)
        entries.append(BaselineEntry(
            rule_id=f.get("rule_id", ""),
            file=file_str,
            line_hash=_line_hash(abs_file, line),
            message=f.get("message", ""),
            severity=f.get("derived_severity") or f.get("severity", ""),
            cwe_id=f.get("cwe_id", 0),
        ))

    from datetime import datetime, timezone

    baseline = Baseline(
        created=datetime.now(timezone.utc).isoformat(),
        sanicode_version=result.sanicode_version,
        entries=entries,
    )
    baseline.save(output)
    console.print(
        f"[green]Baseline created:[/green] {len(entries)} finding(s) "
        f"written to [bold]{output}[/bold]"
    )


@baseline_app.command("audit")
def baseline_audit(
    baseline_file: Path = typer.Argument(
        Path(".sanicode-baseline.json"),
        help="Path to the baseline file.",
    ),
) -> None:
    """List all active suppressions in the baseline."""
    from sanicode.baseline import Baseline

    if not baseline_file.exists():
        console.print(f"[red]Error:[/red] Baseline file not found: {baseline_file}")
        raise typer.Exit(code=1)

    baseline = Baseline.load(baseline_file)

    active = [e for e in baseline.entries if not e.is_expired()]
    expired = [e for e in baseline.entries if e.is_expired()]

    console.print(
        f"[bold]Baseline:[/bold] {baseline_file} "
        f"(v{baseline.version}, created {baseline.created})"
    )
    console.print(
        f"  sanicode {baseline.sanicode_version}"
    )
    console.print(
        f"  {len(active)} active, {len(expired)} expired, "
        f"{len(baseline.entries)} total"
    )

    if active:
        table = Table(title="Active suppressions", show_lines=False)
        table.add_column("Rule", style="bold")
        table.add_column("File", style="cyan")
        table.add_column("Severity")
        table.add_column("CWE")
        table.add_column("Expires")
        table.add_column("Approver")
        for e in active:
            sev = e.severity
            if sev in ("critical", "high"):
                sev_style = f"[red]{sev}[/red]"
            elif sev == "medium":
                sev_style = f"[yellow]{sev}[/yellow]"
            else:
                sev_style = f"[dim]{sev}[/dim]"
            table.add_row(
                e.rule_id,
                e.file,
                sev_style,
                f"CWE-{e.cwe_id}",
                e.expires or "[dim]never[/dim]",
                e.approver or "[dim]--[/dim]",
            )
        console.print(table)

    if expired:
        console.print(
            f"\n[yellow]{len(expired)} expired entry/entries "
            f"(no longer suppressing findings).[/yellow]"
        )


@app.command(name="fips-check")
def fips_check() -> None:
    """Validate FIPS 140-2/140-3 compliance for the current deployment.

    Checks kernel FIPS mode, OpenSSL provider status, and sanicode
    configuration for settings that would violate FIPS requirements.
    Exits with code 1 if any issues are found.
    """
    import ssl

    from sanicode.fips import check_fips_mode, validate_fips_compliance

    fips_on = check_fips_mode()
    openssl_version = ssl.OPENSSL_VERSION

    fips_label = "[green]enabled[/green]" if fips_on else "[yellow]not detected[/yellow]"
    console.print(f"FIPS Mode: {fips_label}")
    console.print(f"OpenSSL: {openssl_version}")
    console.print()

    issues = validate_fips_compliance()

    console.print("[bold]Checks:[/bold]")
    if not issues:
        console.print("  [green]✓[/green] hashlib uses FIPS-validated OpenSSL backend")
        console.print("  [green]✓[/green] No weak hash algorithms available for security use")
        console.print("  [green]✓[/green] TLS certificate verification enabled")
        console.print()
        console.print("[green]All FIPS compliance checks passed.[/green]")
    else:
        for issue in issues:
            console.print(f"  [red]✗[/red] {issue}")
        console.print()
        console.print(
            f"[red]{len(issues)} FIPS compliance issue(s) found.[/red]  "
            "See docs/fips-compliance.md for remediation guidance."
        )
        raise typer.Exit(code=1)


def main() -> None:
    """Entrypoint wrapper required by the pyproject.toml script declaration."""
    app()
