"""Version information for sanicode."""

__version__ = "0.12.2"
