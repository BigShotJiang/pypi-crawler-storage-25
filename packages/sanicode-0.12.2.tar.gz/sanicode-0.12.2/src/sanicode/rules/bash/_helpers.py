"""Shared helpers for Bash rule modules.

These mirror the private helpers in ``scanner/languages/bash_lang.py`` but
are kept here so rule modules don't need to reach into scanner internals.

.. note:: If you fix a bug in any helper here, also update the
   corresponding private helper in ``scanner/languages/bash_lang.py``.
"""

from __future__ import annotations

from tree_sitter import Node

# Node type constants for Bash.
BASH_COMMAND = "command"
BASH_PIPELINE = "pipeline"
BASH_VARIABLE_ASSIGNMENT = "variable_assignment"
BASH_DECLARATION_COMMAND = "declaration_command"
BASH_REDIRECTED_STATEMENT = "redirected_statement"


def bash_command_name(node: Node) -> str:
    """Extract the command name from a ``command`` node.

    The first child of a ``command`` is ``command_name``, which wraps a
    ``word`` whose text is the actual command (e.g. ``eval``, ``chmod``).
    """
    for child in node.children:
        if child.type == "command_name":
            # command_name wraps a word (or sometimes a simple_expansion)
            for sub in child.children:
                if sub.type == "word" and sub.text:
                    return sub.text.decode("utf-8")
            # If command_name itself has text (fallback)
            if child.text:
                return child.text.decode("utf-8")
    return ""


def bash_command_args(node: Node) -> list[Node]:
    """Get argument nodes from a ``command`` node.

    Returns all children after ``command_name`` that are not punctuation
    or redirect nodes.
    """
    args: list[Node] = []
    past_name = False
    for child in node.children:
        if child.type == "command_name":
            past_name = True
            continue
        if not past_name:
            continue
        # Skip redirects and punctuation
        if child.type in ("file_redirect", "heredoc_redirect", ">", "<", ">>", "2>", "&>"):
            continue
        args.append(child)
    return args


def bash_first_arg(node: Node) -> Node | None:
    """Return the first argument node of a command, or None."""
    args = bash_command_args(node)
    return args[0] if args else None


def bash_has_expansion(node: Node) -> bool:
    """Return True if *node* or any descendant contains a variable expansion.

    Checks for ``simple_expansion`` ($var) and ``expansion`` (${var}).
    """
    if node.type in ("simple_expansion", "expansion"):
        return True
    for child in node.children:
        if bash_has_expansion(child):
            return True
    return False


def bash_has_command_substitution(node: Node) -> bool:
    """Return True if *node* or any descendant contains a command substitution.

    Checks for ``command_substitution`` ($() or backtick syntax).
    """
    if node.type == "command_substitution":
        return True
    for child in node.children:
        if bash_has_command_substitution(child):
            return True
    return False


def bash_pipeline_commands(node: Node) -> list[Node]:
    """Extract the list of ``command`` nodes from a ``pipeline``.

    A pipeline's children are commands separated by ``|`` tokens.
    """
    return [c for c in node.children if c.type == "command"]


def bash_pipeline_last_command_name(node: Node) -> str:
    """Get the name of the last command in a pipeline."""
    cmds = bash_pipeline_commands(node)
    if cmds:
        return bash_command_name(cmds[-1])
    return ""


def bash_enclosing_function(node: Node) -> str | None:
    """Walk the parent chain to find the enclosing function name.

    Bash ``function_definition`` has a ``word`` child that is the function
    name (for ``name() {}`` syntax) or the word after ``function`` keyword.
    """
    current = node.parent
    while current is not None:
        if current.type == "function_definition":
            for child in current.children:
                if child.type == "word" and child.text:
                    return child.text.decode("utf-8")
        current = current.parent
    return None


def bash_is_string_literal(node: Node) -> bool:
    """Return True if *node* is a plain word or string without expansions."""
    if node.type == "word":
        return not bash_has_expansion(node)
    if node.type == "string":
        return not bash_has_expansion(node)
    if node.type == "raw_string":
        return True  # Single-quoted strings have no expansion
    return False


def bash_variable_name(node: Node) -> str:
    """Extract variable name from a ``variable_assignment`` node."""
    for child in node.children:
        if child.type == "variable_name" and child.text:
            return child.text.decode("utf-8")
    return ""


def bash_variable_value(node: Node) -> Node | None:
    """Extract the value node from a ``variable_assignment``.

    Skips the variable_name and '=' to find the value child.
    """
    past_eq = False
    for child in node.children:
        if child.type == "=":
            past_eq = True
            continue
        if past_eq and child.type not in ("=",):
            return child
    return None
