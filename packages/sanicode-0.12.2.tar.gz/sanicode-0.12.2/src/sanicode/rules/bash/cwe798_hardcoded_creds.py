"""Hardcoded credentials detection for Bash (CWE-798).

SC1708 — Hardcoded credentials in variable assignments    medium  CWE-798
"""

from __future__ import annotations

import re
from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.bash._helpers import (
    BASH_DECLARATION_COMMAND,
    BASH_VARIABLE_ASSIGNMENT,
    bash_has_expansion,
    bash_variable_name,
    bash_variable_value,
)
from sanicode.scanner.patterns import Finding

_CRED_PATTERN = re.compile(
    r"(PASSWORD|PASSWD|SECRET|TOKEN|API_KEY|APIKEY|PRIVATE_KEY|ACCESS_KEY)",
    re.IGNORECASE,
)


class BashHardcodedCredsRule(Rule):
    """Detect hardcoded credentials in variable assignments."""

    rule_id = "SC1708"
    cwe_id = 798
    severity = "medium"
    language = "bash"
    message = "Hardcoded credential in variable assignment — credential exposure risk (CWE-798)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            # Check both plain assignments and export/declare
            if node.type == BASH_VARIABLE_ASSIGNMENT:
                self._check_assignment(node, plugin, file_path, findings)
            elif node.type == BASH_DECLARATION_COMMAND:
                for child in node.children:
                    if child.type == BASH_VARIABLE_ASSIGNMENT:
                        self._check_assignment(child, plugin, file_path, findings)
        return findings

    def _check_assignment(
        self, node, plugin, file_path: Path, findings: list[Finding]
    ) -> None:
        name = bash_variable_name(node)
        if not _CRED_PATTERN.search(name):
            return
        value = bash_variable_value(node)
        if value is None:
            return
        # Only flag if value is a literal (not from expansion/env var)
        if not bash_has_expansion(value) and value.text:
            text = value.text.decode("utf-8").strip("\"'")
            # Skip empty values and placeholder patterns
            if text and text not in ("", "''", '""', "${" + name + "}"):
                findings.append(self._make_finding(node, plugin, file_path))
