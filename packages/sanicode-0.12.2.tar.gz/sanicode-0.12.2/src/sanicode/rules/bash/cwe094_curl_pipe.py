"""Curl/wget pipe to shell detection for Bash (CWE-94).

SC1703 — curl/wget piped to bash/sh/python/perl    high  CWE-94
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.bash._helpers import (
    BASH_PIPELINE,
    bash_command_name,
    bash_pipeline_commands,
)
from sanicode.scanner.patterns import Finding

_FETCH_COMMANDS = frozenset({"curl", "wget"})
_SHELL_COMMANDS = frozenset({"bash", "sh", "zsh", "python", "python3", "perl", "ruby"})


class BashCurlPipeRule(Rule):
    """Detect curl/wget piped to shell — remote code execution risk."""

    rule_id = "SC1703"
    cwe_id = 94
    severity = "high"
    language = "bash"
    message = "Remote content piped to shell interpreter — remote code execution risk (CWE-94)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if node.type != BASH_PIPELINE:
                continue
            cmds = bash_pipeline_commands(node)
            if len(cmds) < 2:
                continue
            first_name = bash_command_name(cmds[0])
            last_name = bash_command_name(cmds[-1])
            if first_name in _FETCH_COMMANDS and last_name in _SHELL_COMMANDS:
                findings.append(self._make_finding(node, plugin, file_path))
        return findings
