"""Symlink creation detection for Bash (CWE-59).

SC1722 — ln -s (symlink creation)    medium  CWE-59

Detects ``ln -s`` and ``ln -sf`` (and other flag combinations containing
``-s``) which create symbolic links.  Symlink creation in scripts without
path validation may expose the program to symlink-following attacks.
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule, _walk
from sanicode.rules.bash._helpers import BASH_COMMAND, bash_command_args, bash_command_name
from sanicode.scanner.patterns import Finding


def _args_contain_symlink_flag(args) -> bool:
    """Return True if any argument looks like a flag that includes ``-s``.

    Accepts combined flags like ``-sf``, ``-fs``, ``-s``, etc.
    The argument must start with ``-`` and contain the letter ``s``.
    """
    for arg in args:
        if arg.text is None:
            continue
        text = arg.text.decode("utf-8")
        if text.startswith("-") and not text.startswith("--") and "s" in text:
            return True
    return False


class BashSymlinkRule(Rule):
    """Detect ``ln -s`` symlink creation — symlink following risk.

    Hard links (``ln`` without ``-s``) are not flagged because they cannot
    point outside the filesystem and do not enable symlink-following attacks.
    """

    rule_id = "SC1722"
    cwe_id = 59
    severity = "medium"
    language = "bash"
    message = (
        "Symlink operation without safety checks — "
        "symlink following may allow unauthorized file access (CWE-59)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []

        for node in _walk(tree.root_node):
            if node.type != BASH_COMMAND:
                continue
            if bash_command_name(node) != "ln":
                continue
            args = bash_command_args(node)
            if _args_contain_symlink_flag(args):
                findings.append(self._make_finding(node, plugin, file_path))

        return findings
