"""Uncontrolled search path detection for Bash (CWE-427).

SC1721 — source/dot with bare (search-path) filename    medium  CWE-427

Detects ``source script.sh`` and ``. script.sh`` where the argument is a
plain word (no variable expansion) that does not start with ``/``, ``./``,
or ``../``.  Such invocations rely on ``PATH`` or the shell's current
directory to locate the file, which can be hijacked.
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule, _walk
from sanicode.rules.bash._helpers import (
    bash_command_args,
    bash_command_name,
    bash_is_string_literal,
)
from sanicode.scanner.patterns import Finding

_SOURCE_COMMANDS = frozenset({"source", "."})


def _is_absolute_or_explicit_relative(text: str) -> bool:
    """Return True if *text* is an absolute or explicitly relative path."""
    stripped = text.strip("'\"")
    return (
        stripped.startswith("/")
        or stripped.startswith("./")
        or stripped.startswith("../")
        or stripped.startswith("\\\\")
        or (len(stripped) >= 3 and stripped[1] == ":" and stripped[2] in ("/", "\\"))
    )


class BashSearchPathSourceRule(Rule):
    """Detect source/dot with a bare filename — uncontrolled search path.

    ``source utils.sh`` searches the shell's ``PATH`` (and sometimes the
    current directory) to find the file.  An attacker who can place a file
    earlier in the search path can cause arbitrary code execution.  Using
    ``source ./utils.sh`` or ``source /opt/lib/utils.sh`` is safe.
    """

    rule_id = "SC1721"
    cwe_id = 427
    severity = "medium"
    language = "bash"
    message = (
        "source/dot with bare filename \u2014 "
        "uncontrolled search path risk (CWE-427)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in _walk(tree.root_node):
            if node.type != "command":
                continue
            cmd_name = bash_command_name(node)
            if cmd_name not in _SOURCE_COMMANDS:
                continue
            args = bash_command_args(node)
            if not args:
                continue
            first = args[0]
            # Only flag plain string literals; variables are a separate concern (CWE-829).
            if not bash_is_string_literal(first):
                continue
            text = plugin.node_text(first)
            if not _is_absolute_or_explicit_relative(text):
                findings.append(self._make_finding(node, plugin, file_path))
        return findings
