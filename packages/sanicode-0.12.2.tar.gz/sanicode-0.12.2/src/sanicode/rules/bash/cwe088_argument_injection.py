"""Argument injection detection for Bash (CWE-88).

SC1719 — Known utility with variable arguments    medium  CWE-88
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.bash._helpers import (
    BASH_COMMAND,
    bash_command_args,
    bash_command_name,
    bash_has_expansion,
)
from sanicode.scanner.patterns import Finding

# Utilities that are argument-injection sensitive: the command itself is known,
# but attacker-controlled arguments can inject flags (e.g., --upload-pack for git,
# -o ProxyCommand for ssh, etc.).
_SENSITIVE_UTILITIES = frozenset({
    "git", "curl", "wget", "ssh", "scp", "rsync", "tar",
    "find", "xargs", "zip", "unzip", "gpg",
})


class BashArgumentInjectionRule(Rule):
    """Detect known utilities invoked with variable-expansion arguments."""

    rule_id = "SC1719"
    cwe_id = 88
    severity = "medium"
    language = "bash"
    message = (
        "Known utility with variable arguments "
        "— potential argument injection (CWE-88)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []

        for node in plugin.walk(tree.root_node):
            if node.type != BASH_COMMAND:
                continue

            name = bash_command_name(node)
            if name not in _SENSITIVE_UTILITIES:
                continue

            args = bash_command_args(node)
            if not args:
                continue

            # At least one argument must contain a variable expansion
            for arg in args:
                if bash_has_expansion(arg):
                    findings.append(self._make_finding(node, plugin, file_path))
                    break

        return findings
