"""Sensitive information in log output for Bash (CWE-532).

SC1718 — Logging command includes secret-named variable    medium  CWE-532
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules._sensitive_patterns import SECRET_VAR_PATTERN
from sanicode.rules.base import Rule, _walk
from sanicode.rules.bash._helpers import bash_command_args, bash_command_name
from sanicode.scanner.patterns import Finding

_LOG_COMMANDS: frozenset[str] = frozenset({"echo", "printf", "logger"})


class BashLogSecretsRule(Rule):
    """Detect logging commands that include secret-named variable expansions."""

    rule_id = "SC1718"
    cwe_id = 532
    severity = "medium"
    language = "bash"
    message = (
        "Logging command includes secret-named variable "
        "— may expose credentials in logs (CWE-532)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if node.type != "command":
                continue
            cmd_name = bash_command_name(node)
            if cmd_name not in _LOG_COMMANDS:
                continue
            if self._has_secret_expansion(node, plugin):
                findings.append(self._make_finding(node, plugin, file_path))
        return findings

    @staticmethod
    def _has_secret_expansion(command_node, plugin) -> bool:
        """Check if any argument contains a secret-named variable expansion."""
        args = bash_command_args(command_node)
        for arg in args:
            for child in _walk(arg):
                if child.type in ("simple_expansion", "expansion"):
                    # Extract the variable name from the expansion
                    for sub in child.children:
                        if sub.type == "variable_name" and sub.text:
                            var_name = sub.text.decode("utf-8")
                            if SECRET_VAR_PATTERN.search(var_name):
                                return True
                        # Also check 'special_variable_name' as fallback
                        if sub.type == "special_variable_name" and sub.text:
                            var_name = sub.text.decode("utf-8")
                            if SECRET_VAR_PATTERN.search(var_name):
                                return True
        return False
