"""Command injection detection for Bash (CWE-78).

SC1702 — exec / su -c / sudo / ssh with variable expansion    high  CWE-78
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.bash._helpers import (
    BASH_COMMAND,
    bash_command_args,
    bash_command_name,
    bash_has_expansion,
)
from sanicode.scanner.patterns import Finding

_DANGEROUS_COMMANDS = frozenset({"exec", "su", "sudo", "ssh", "xargs"})


class BashCommandInjectionRule(Rule):
    """Detect command execution with dynamic arguments — command injection risk."""

    rule_id = "SC1702"
    cwe_id = 78
    severity = "high"
    language = "bash"
    message = "Command execution with dynamic argument — command injection risk (CWE-78)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if node.type != BASH_COMMAND:
                continue
            name = bash_command_name(node)
            if name not in _DANGEROUS_COMMANDS:
                continue
            args = bash_command_args(node)
            for arg in args:
                if bash_has_expansion(arg):
                    findings.append(self._make_finding(node, plugin, file_path))
                    break
        return findings
