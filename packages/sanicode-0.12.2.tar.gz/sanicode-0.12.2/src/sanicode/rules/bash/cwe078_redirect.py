"""Unsafe redirect detection for Bash (CWE-78).

SC1709 — Output redirect to variable path    medium  CWE-78
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.bash._helpers import (
    BASH_REDIRECTED_STATEMENT,
    bash_has_expansion,
)
from sanicode.scanner.patterns import Finding


class BashUnsafeRedirectRule(Rule):
    """Detect output redirect to dynamic path — path injection risk."""

    rule_id = "SC1709"
    cwe_id = 78
    severity = "medium"
    language = "bash"
    message = "Output redirect to dynamic path — path injection risk (CWE-78)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if node.type != BASH_REDIRECTED_STATEMENT:
                continue
            # Check file_redirect children for variable expansion
            for child in node.children:
                if child.type == "file_redirect":
                    # The redirect destination is the last non-operator child
                    for redir_child in child.children:
                        if redir_child.type in (">", ">>", "<", "2>", "&>"):
                            continue
                        if bash_has_expansion(redir_child):
                            findings.append(self._make_finding(node, plugin, file_path))
                            break
                    break  # Only check first file_redirect
        return findings
