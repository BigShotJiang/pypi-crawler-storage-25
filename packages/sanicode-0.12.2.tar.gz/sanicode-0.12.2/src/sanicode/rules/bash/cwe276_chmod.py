"""Insecure file permissions via chmod for Bash (CWE-276).

SC1704 — chmod with overly permissive mode (777, 666, o+w)    medium  CWE-276
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.bash._helpers import (
    BASH_COMMAND,
    bash_command_args,
    bash_command_name,
)
from sanicode.scanner.patterns import Finding

_DANGEROUS_MODES = frozenset(
    {"777", "776", "666", "o+w", "a+w", "o+rw", "a+rw", "o+rwx", "a+rwx"}
)


class BashChmodRule(Rule):
    """Detect chmod with overly permissive modes — insecure permissions risk."""

    rule_id = "SC1704"
    cwe_id = 276
    severity = "medium"
    language = "bash"
    message = "Use of chmod with overly permissive mode — insecure permissions risk (CWE-276)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if node.type != BASH_COMMAND:
                continue
            if bash_command_name(node) != "chmod":
                continue
            args = bash_command_args(node)
            for arg in args:
                if arg.text:
                    text = arg.text.decode("utf-8")
                    if text in _DANGEROUS_MODES:
                        findings.append(self._make_finding(node, plugin, file_path))
                        break
        return findings
