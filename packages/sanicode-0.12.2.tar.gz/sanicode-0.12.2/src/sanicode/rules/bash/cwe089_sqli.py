"""SQL injection via CLI commands for Bash (CWE-89).

SC1707 — mysql/psql/sqlite3 with dynamic query    high  CWE-89
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.bash._helpers import (
    BASH_COMMAND,
    bash_command_args,
    bash_command_name,
    bash_has_expansion,
)
from sanicode.scanner.patterns import Finding

_SQL_COMMANDS = frozenset({"mysql", "psql", "sqlite3"})


class BashSQLInjectionRule(Rule):
    """Detect SQL CLI commands with dynamic queries — SQL injection risk."""

    rule_id = "SC1707"
    cwe_id = 89
    severity = "high"
    language = "bash"
    message = "SQL CLI command with dynamic query — SQL injection risk (CWE-89)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if node.type != BASH_COMMAND:
                continue
            if bash_command_name(node) not in _SQL_COMMANDS:
                continue
            args = bash_command_args(node)
            # Flag any SQL command where arguments contain variable expansion
            for arg in args:
                if bash_has_expansion(arg):
                    findings.append(self._make_finding(node, plugin, file_path))
                    break
        return findings
