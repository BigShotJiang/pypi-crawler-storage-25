"""Code injection via arithmetic expansion for Bash (CWE-94).

SC1710 -- $(( )) with variable expansion    medium  CWE-94

When ``$(( ))`` contains a variable, the variable's value is evaluated as an
arithmetic expression. An attacker who controls the variable can execute
arbitrary code via array subscript syntax (e.g. ``a[$(evil_cmd)]``).
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.bash._helpers import bash_has_expansion
from sanicode.scanner.patterns import Finding


def _arithmetic_has_variable(node) -> bool:
    """Check if an arithmetic_expansion contains actual variable references.

    Inside ``$(( ))``, variables can appear in three forms:
    - ``$var`` (simple_expansion)
    - ``${var}`` (expansion)
    - ``var`` (bare variable_name -- bash evaluates these as variables)

    We walk descendants looking for any of these, skipping delimiters.
    """
    for child in node.children:
        if child.type in ("$((", "))"):
            continue
        if child.type == "variable_name":
            return True
        if bash_has_expansion(child):
            return True
        if _arithmetic_has_variable(child):
            return True
    return False


class BashArithmeticInjectionRule(Rule):
    """Detect variable expansion inside arithmetic context."""

    rule_id = "SC1710"
    cwe_id = 94
    severity = "medium"
    language = "bash"
    message = (
        "Arithmetic expansion with variable — value is evaluated as expression, "
        "potential code injection (CWE-94)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if node.type != "arithmetic_expansion":
                continue
            if _arithmetic_has_variable(node):
                findings.append(self._make_finding(node, plugin, file_path))
        return findings
