"""Overly permissive umask detection for Bash (CWE-732).

SC1715 -- umask with values that produce world-readable/writable files    medium  CWE-732

A low umask (e.g. ``000``, ``002``, ``007``) means newly created files and
directories are accessible to other users. This complements SC1704 (chmod)
by catching the default-permission side of CWE-732.
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.bash._helpers import (
    BASH_COMMAND,
    bash_command_args,
    bash_command_name,
)
from sanicode.scanner.patterns import Finding

# Umask values where the "other" bits are insufficiently masked.
# 000 = no mask at all; 002 = other can read; 007 = other can do nothing
# but group has full access; 011 = no write mask for anyone.
# We flag values whose octal digits leave files world-readable or writable.
_PERMISSIVE_UMASKS = frozenset({
    "0", "00", "000", "0000",   # no mask
    "002", "0002",               # other-write allowed
    "006", "0006",               # other-read+write allowed
    "007", "0007",               # other gets nothing, but group is fully open
    "011", "0011",               # minimal mask
    "022", "0022",               # common default, but world-readable
})


class BashPermissiveUmaskRule(Rule):
    """Detect umask with permissive values that allow broad file access."""

    rule_id = "SC1715"
    cwe_id = 732
    severity = "medium"
    language = "bash"
    message = (
        "Overly permissive umask — newly created files may be "
        "world-readable or writable (CWE-732)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if node.type != BASH_COMMAND:
                continue
            if bash_command_name(node) != "umask":
                continue
            args = bash_command_args(node)
            for arg in args:
                if arg.text:
                    text = arg.text.decode("utf-8")
                    if text in _PERMISSIVE_UMASKS:
                        findings.append(self._make_finding(node, plugin, file_path))
                        break
        return findings
