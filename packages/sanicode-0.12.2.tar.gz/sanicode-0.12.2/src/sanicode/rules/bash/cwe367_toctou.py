"""TOCTOU race condition detection for Bash (CWE-367).

SC1712 -- test -f / [ -f ... ] file existence check    medium  CWE-367

File existence tests (``test -f``, ``[ -e ... ]``) followed by operations on
the same path create a time-of-check-to-time-of-use race window. An attacker
can replace the file between the test and the operation.

This rule flags the check itself as a potential TOCTOU origin. It is an
intentional approximation -- not every file test leads to a race, but the
pattern is common enough in shell scripts to warrant a warning.
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.bash._helpers import (
    BASH_COMMAND,
    bash_command_args,
    bash_command_name,
)
from sanicode.scanner.patterns import Finding

_FILE_TEST_FLAGS = frozenset({"-f", "-e", "-d", "-r", "-w", "-x", "-s", "-L", "-h"})


def _test_command_has_file_flag(node) -> bool:
    """Walk descendants of a test_command looking for file-test operators."""
    for child in node.children:
        if child.type == "test_operator" and child.text:
            text = child.text.decode("utf-8")
            if text in _FILE_TEST_FLAGS:
                return True
        # Recurse into unary_expression etc.
        if _test_command_has_file_flag(child):
            return True
    return False


class BashTOCTOURule(Rule):
    """Detect file existence tests that create TOCTOU race windows."""

    rule_id = "SC1712"
    cwe_id = 367
    severity = "medium"
    language = "bash"
    message = (
        "File existence test creates a TOCTOU race window — the file may "
        "change between check and use (CWE-367)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            # Handle `test -f ...` (parsed as regular command)
            if node.type == BASH_COMMAND:
                name = bash_command_name(node)
                if name != "test":
                    continue
                args = bash_command_args(node)
                arg_texts = []
                for a in args:
                    if a.text:
                        arg_texts.append(a.text.decode("utf-8"))
                if any(t in _FILE_TEST_FLAGS for t in arg_texts):
                    findings.append(self._make_finding(node, plugin, file_path))

            # Handle `[ -f ... ]` (parsed as test_command)
            elif node.type == "test_command":
                if _test_command_has_file_flag(node):
                    findings.append(self._make_finding(node, plugin, file_path))

        return findings
