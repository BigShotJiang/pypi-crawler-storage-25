"""Insecure temporary file creation for Bash (CWE-377).

SC1705 — Hardcoded /tmp path without mktemp    medium  CWE-377
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.bash._helpers import (
    BASH_VARIABLE_ASSIGNMENT,
    bash_variable_value,
)
from sanicode.scanner.patterns import Finding


class BashTempFileRule(Rule):
    """Detect hardcoded /tmp paths — insecure temp file creation risk."""

    rule_id = "SC1705"
    cwe_id = 377
    severity = "medium"
    language = "bash"
    message = "Hardcoded /tmp path without mktemp — insecure temp file risk (CWE-377)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if node.type != BASH_VARIABLE_ASSIGNMENT:
                continue
            value = bash_variable_value(node)
            if value is None or not value.text:
                continue
            text = value.text.decode("utf-8")
            # Flag assignments to /tmp/ paths (but not mktemp results)
            if text.startswith("/tmp/") or text.startswith("/tmp\\"):
                findings.append(self._make_finding(node, plugin, file_path))
        return findings
