"""Unsafe source/dot command for Bash (CWE-78).

SC1706 — source/dot with variable path    medium  CWE-78
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.bash._helpers import (
    BASH_COMMAND,
    bash_command_name,
    bash_first_arg,
    bash_has_expansion,
)
from sanicode.scanner.patterns import Finding


class BashUnsafeSourceRule(Rule):
    """Detect source/dot with dynamic path — untrusted code sourcing risk."""

    rule_id = "SC1706"
    cwe_id = 78
    severity = "medium"
    language = "bash"
    message = "Use of source/dot with dynamic path — untrusted code sourcing risk (CWE-78)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if node.type != BASH_COMMAND:
                continue
            name = bash_command_name(node)
            if name not in ("source", "."):
                continue
            first = bash_first_arg(node)
            if first is not None and bash_has_expansion(first):
                findings.append(self._make_finding(node, plugin, file_path))
        return findings
