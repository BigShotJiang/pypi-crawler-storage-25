"""Public cloud storage resource exposure detection for Bash (CWE-668).

SC1724 — AWS CLI call sets public ACL on bucket/object  medium  CWE-668

Detects ``aws`` commands that pass ``--acl public-read`` or
``--acl public-read-write``.  Both the ``--acl`` flag and the public value
must be present together to trigger a finding.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from tree_sitter import Tree

from sanicode.rules.base import Rule, _walk
from sanicode.rules.bash._helpers import bash_command_args, bash_command_name
from sanicode.scanner.patterns import Finding

if TYPE_CHECKING:
    from sanicode.scanner.languages.base import TreeSitterPlugin

_PUBLIC_ACLS: frozenset[str] = frozenset({"public-read", "public-read-write"})


def _arg_text(node) -> str:
    return node.text.decode("utf-8") if node.text else ""


class BashPublicResourceRule(Rule):
    """Detect ``aws`` CLI calls that set a public ACL (CWE-668)."""

    rule_id = "SC1724"
    cwe_id = 668
    severity = "medium"
    language = "bash"
    message = (
        "Public ACL on cloud storage resource "
        "\u2014 review access control (CWE-668)"
    )
    tags = ["cloud", "access_control"]
    domain = "access_control"
    action = "review"

    def check(self, tree: Tree, file_path: Path, plugin: TreeSitterPlugin) -> list[Finding]:
        findings: list[Finding] = []

        for node in _walk(tree.root_node):
            if node.type != "command":
                continue
            if bash_command_name(node) != "aws":
                continue

            arg_texts = [_arg_text(a) for a in bash_command_args(node)]

            # Handle both `--acl public-read` (two tokens) and
            # `--acl=public-read` (single token) forms.
            has_acl_flag = "--acl" in arg_texts
            has_public_value = any(a in _PUBLIC_ACLS for a in arg_texts)

            if not (has_acl_flag and has_public_value):
                # Check for --acl=value form.
                for a in arg_texts:
                    if a.startswith("--acl=") and a[len("--acl="):] in _PUBLIC_ACLS:
                        has_acl_flag = True
                        has_public_value = True
                        break

            if has_acl_flag and has_public_value:
                findings.append(self._make_finding(node, plugin, file_path))

        return findings
