"""Execution with unnecessary privileges for Bash (CWE-250).

SC1723 — chmod setting setuid/setgid bit    medium  CWE-250
"""

from __future__ import annotations

import re
from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule, _walk
from sanicode.rules.bash._helpers import bash_command_args, bash_command_name
from sanicode.scanner.patterns import Finding

# Octal modes where the first digit is 2, 4, or 6 (setuid/setgid bits).
_SETUID_OCTAL_RE = re.compile(r"^[246]\d{3}$")

# Symbolic mode patterns that set the setuid/setgid bit.
_SETUID_SYMBOLIC = frozenset({"u+s", "g+s", "+s"})


class BashUnnecessaryPrivRule(Rule):
    """Detect chmod setting the setuid/setgid bit in Bash scripts."""

    rule_id = "SC1723"
    cwe_id = 250
    severity = "medium"
    language = "bash"
    message = (
        "chmod setting setuid/setgid bit "
        "— unnecessary privilege escalation (CWE-250)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in _walk(tree.root_node):
            if node.type != "command":
                continue
            if bash_command_name(node) != "chmod":
                continue
            args = bash_command_args(node)
            for arg in args:
                text = plugin.node_text(arg)
                if text in _SETUID_SYMBOLIC:
                    findings.append(self._make_finding(node, plugin, file_path))
                    break
                if _SETUID_OCTAL_RE.match(text):
                    findings.append(self._make_finding(node, plugin, file_path))
                    break
        return findings
