"""Backgrounded command without cleanup detection for Bash (CWE-459).

SC1713 -- command & without trap/wait cleanup    low  CWE-459

Backgrounded processes that are not tracked with ``wait`` or cleaned up via
``trap`` can become orphans or zombies. This is a resource management concern
(CWE-459: Incomplete Cleanup).

Detection: find nodes where a ``&`` background operator appears as a sibling
of a command within a ``list`` (semicolon/newline/background separated
statement sequence).
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.scanner.patterns import Finding


class BashBackgroundNoCleanupRule(Rule):
    """Detect backgrounded commands that may lack cleanup."""

    rule_id = "SC1713"
    cwe_id = 459
    severity = "low"
    language = "bash"
    message = (
        "Backgrounded command without explicit cleanup — orphan/zombie "
        "process risk (CWE-459)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            # In tree-sitter bash, `cmd &` produces a node structure where
            # "&" appears as a child token inside a list or compound statement.
            if node.type != "&":
                continue
            # The parent is typically a list; the preceding sibling is the command.
            parent = node.parent
            if parent is None:
                continue
            # Find the command node that precedes the `&`
            prev = node.prev_sibling
            if prev is not None and prev.type in ("command", "pipeline", "subshell"):
                findings.append(self._make_finding(prev, plugin, file_path))
        return findings
