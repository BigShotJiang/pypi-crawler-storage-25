"""Missing shell safety flags detection for Bash (CWE-754).

SC1716 -- script without set -e / set -o errexit / set -o pipefail    low  CWE-754

Scripts that lack ``set -e`` (or ``set -o errexit``) silently continue after
failures, which can lead to partially applied state and security issues.
This is a whole-file heuristic: if no ``set`` invocation with error-handling
flags is found anywhere in the file, a single finding is emitted at line 1.
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.bash._helpers import (
    BASH_COMMAND,
    bash_command_args,
    bash_command_name,
)
from sanicode.scanner.patterns import Finding

# Flags/words that indicate error-handling is enabled.
_SAFETY_INDICATORS = frozenset({
    "-e", "-euo", "-eu", "-eo", "-eux", "-euxo",
    "errexit", "pipefail",
})


class BashMissingSetSafetyRule(Rule):
    """Detect scripts that lack ``set -e`` or ``set -o errexit``."""

    rule_id = "SC1716"
    cwe_id = 754
    severity = "low"
    language = "bash"
    message = (
        "Script lacks 'set -e' or 'set -o errexit' — failures will be "
        "silently ignored (CWE-754)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        has_safety = False
        for node in plugin.walk(tree.root_node):
            if node.type != BASH_COMMAND:
                continue
            if bash_command_name(node) != "set":
                continue
            args = bash_command_args(node)
            for arg in args:
                if arg.text:
                    text = arg.text.decode("utf-8")
                    if text in _SAFETY_INDICATORS:
                        has_safety = True
                        break
            if has_safety:
                break

        if not has_safety:
            # Emit finding at the root node (line 1)
            return [self._make_finding(tree.root_node, plugin, file_path)]
        return []
