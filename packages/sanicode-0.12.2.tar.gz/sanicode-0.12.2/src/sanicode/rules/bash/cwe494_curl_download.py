"""Download without integrity check detection for Bash (CWE-494).

SC1714 -- curl -o / wget -O downloading to file    high  CWE-494

Downloading a file with ``curl -o`` or ``wget -O`` without verifying its
integrity (checksum, signature) before execution is a supply chain risk.
The pipe-to-shell variant is already covered by SC1703; this rule targets
the download-to-file pattern.
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.bash._helpers import (
    BASH_COMMAND,
    bash_command_args,
    bash_command_name,
)
from sanicode.scanner.patterns import Finding

_DOWNLOAD_COMMANDS = frozenset({"curl", "wget"})
_OUTPUT_FLAGS = frozenset({"-o", "--output", "-O", "--output-document"})


class BashCurlDownloadRule(Rule):
    """Detect curl/wget downloading to a file without integrity verification."""

    rule_id = "SC1714"
    cwe_id = 494
    severity = "high"
    language = "bash"
    message = (
        "Download to file without integrity check — downloaded content "
        "may be tampered with (CWE-494)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if node.type != BASH_COMMAND:
                continue
            name = bash_command_name(node)
            if name not in _DOWNLOAD_COMMANDS:
                continue
            args = bash_command_args(node)
            for arg in args:
                if arg.text:
                    text = arg.text.decode("utf-8")
                    if text in _OUTPUT_FLAGS:
                        findings.append(self._make_finding(node, plugin, file_path))
                        break
        return findings
