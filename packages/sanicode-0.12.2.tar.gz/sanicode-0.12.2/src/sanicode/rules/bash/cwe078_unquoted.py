"""Unquoted variable expansion detection for Bash (CWE-78).

SC1717 -- $var in command argument without double quotes    medium  CWE-78

When a variable expansion appears in a command argument without quoting,
Bash performs word splitting and pathname expansion (globbing) on the result.
If an attacker controls the variable's value, they can inject additional
arguments or trigger unexpected behavior.

Detection: find ``simple_expansion`` nodes inside ``command`` arguments that
are NOT wrapped in a ``string`` (double-quoted context). Expansions inside
``string`` nodes are safe from word splitting.
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Node, Tree

from sanicode.rules.base import Rule
from sanicode.rules.bash._helpers import (
    BASH_COMMAND,
    bash_command_args,
    bash_command_name,
)
from sanicode.scanner.patterns import Finding

# Commands where unquoted expansion is especially dangerous.
# We limit to actual commands (not builtins like echo) to reduce noise.
_DANGEROUS_COMMANDS = frozenset({
    "rm", "mv", "cp", "cat", "chmod", "chown", "mkdir", "rmdir",
    "ln", "install", "find", "xargs", "tar", "dd", "mount",
    "curl", "wget", "ssh", "scp", "rsync",
})


def _is_inside_string(node: Node) -> bool:
    """Return True if *node* is a descendant of a ``string`` node (double-quoted)."""
    current = node.parent
    while current is not None:
        if current.type in ("string", "raw_string"):
            return True
        current = current.parent
    return False


def _has_unquoted_expansion(node: Node) -> bool:
    """Return True if *node* contains a simple_expansion not inside quotes."""
    if node.type == "simple_expansion" and not _is_inside_string(node):
        return True
    # Also catch ${var} (expansion node) not inside string
    if node.type == "expansion" and not _is_inside_string(node):
        return True
    for child in node.children:
        if _has_unquoted_expansion(child):
            return True
    return False


class BashUnquotedExpansionRule(Rule):
    """Detect unquoted variable expansion in command arguments."""

    rule_id = "SC1717"
    cwe_id = 78
    severity = "medium"
    language = "bash"
    message = (
        "Unquoted variable expansion in command argument — word splitting "
        "and globbing may cause unexpected behavior (CWE-78)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if node.type != BASH_COMMAND:
                continue
            name = bash_command_name(node)
            if name not in _DANGEROUS_COMMANDS:
                continue
            args = bash_command_args(node)
            for arg in args:
                if _has_unquoted_expansion(arg):
                    findings.append(self._make_finding(node, plugin, file_path))
                    break
        return findings
