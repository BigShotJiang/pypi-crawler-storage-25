"""Code injection via eval for Bash (CWE-94).

SC1701 — eval with variable expansion    high  CWE-94
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.bash._helpers import (
    BASH_COMMAND,
    bash_command_args,
    bash_command_name,
    bash_has_command_substitution,
    bash_has_expansion,
)
from sanicode.scanner.patterns import Finding


class BashEvalRule(Rule):
    """Detect eval with dynamic arguments — code injection risk."""

    rule_id = "SC1701"
    cwe_id = 94
    severity = "high"
    language = "bash"
    message = "Use of eval with dynamic argument — code injection risk (CWE-94)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if node.type != BASH_COMMAND:
                continue
            if bash_command_name(node) != "eval":
                continue
            args = bash_command_args(node)
            # Flag if any argument contains variable expansion or command substitution
            for arg in args:
                if bash_has_expansion(arg) or bash_has_command_substitution(arg):
                    findings.append(self._make_finding(node, plugin, file_path))
                    break
        return findings
