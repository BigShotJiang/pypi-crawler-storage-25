"""Untrusted inclusion detection for Bash (CWE-829).

SC1720 — source/dot with variable path    medium  CWE-829
"""
from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule, _walk
from sanicode.rules.bash._helpers import bash_command_args, bash_command_name, bash_has_expansion
from sanicode.scanner.patterns import Finding

_SOURCE_COMMANDS = frozenset({"source", "."})


class BashUntrustedInclusionRule(Rule):
    """Detect source/dot with a variable (non-literal) path."""

    rule_id = "SC1720"
    cwe_id = 829
    severity = "medium"
    language = "bash"
    message = (
        "source/dot with variable path — "
        "untrusted code inclusion risk (CWE-829)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in _walk(tree.root_node):
            if node.type != "command":
                continue
            cmd_name = bash_command_name(node)
            if cmd_name not in _SOURCE_COMMANDS:
                continue
            args = bash_command_args(node)
            if not args:
                continue
            first = args[0]
            if bash_has_expansion(first):
                findings.append(self._make_finding(node, plugin, file_path))
        return findings
