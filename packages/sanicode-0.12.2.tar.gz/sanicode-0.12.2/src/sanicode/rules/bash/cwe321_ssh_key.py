"""Hardcoded SSH private key detection for Bash (CWE-321).

SC1711 -- Private key material in heredoc body    high  CWE-321

Embedding private key material directly in a script is a severe secret
management failure. Keys should be loaded from files, vaults, or environment
variables at runtime.
"""

from __future__ import annotations

import re
from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.scanner.patterns import Finding

_KEY_PATTERN = re.compile(
    r"BEGIN\s+(RSA\s+|DSA\s+|EC\s+|OPENSSH\s+)?PRIVATE\s+KEY"
)


class BashHardcodedSSHKeyRule(Rule):
    """Detect private key material embedded in heredoc bodies."""

    rule_id = "SC1711"
    cwe_id = 321
    severity = "high"
    language = "bash"
    message = (
        "Hardcoded SSH private key in heredoc — use a secrets manager or "
        "file reference instead (CWE-321)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if node.type != "heredoc_body":
                continue
            text = node.text.decode("utf-8") if node.text else ""
            if _KEY_PATTERN.search(text):
                findings.append(self._make_finding(node, plugin, file_path))
        return findings
