"""Bash-specific pattern detection rules."""
