"""Input validation detection for C (CWE-20).

SC714 — atoi()/atol()/atof() no error indication    medium  CWE-20
"""

from sanicode.rules._c_shared import _AtoiAtol


class CAtoiAtol(_AtoiAtol):
    """Detect atoi()/atol()/atof() calls in C code."""

    rule_id = "SC714"
    language = "c"
