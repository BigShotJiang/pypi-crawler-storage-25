"""Heap buffer overflow via wide-string functions for C (CWE-122).

SC721 — wcscpy()/wcscat()/swprintf() wide-string overflow    high  CWE-122
"""

from sanicode.rules._c_shared import _WideStringOverflow


class CWideStringOverflow(_WideStringOverflow):
    """Detect wide-string overflow functions in C code."""

    rule_id = "SC721"
    language = "c"
