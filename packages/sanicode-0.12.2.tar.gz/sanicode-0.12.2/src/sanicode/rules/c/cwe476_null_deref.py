"""NULL pointer dereference detection for C (CWE-476).

SC716 — Use of null-returning function without NULL check    high  CWE-476
"""

from sanicode.rules._c_shared import _MallocNullCheck


class CMallocNullCheck(_MallocNullCheck):
    """Detect use of null-returning functions without NULL check in C code."""

    rule_id = "SC716"
    language = "c"
