"""Format string vulnerability for C (CWE-134).

SC706 — printf(var)/fprintf(var) format string    high  CWE-134
"""

from sanicode.rules._c_shared import _FormatString


class CFormatString(_FormatString):
    """Detect format string vulnerabilities in C code."""

    rule_id = "SC706"
    language = "c"
