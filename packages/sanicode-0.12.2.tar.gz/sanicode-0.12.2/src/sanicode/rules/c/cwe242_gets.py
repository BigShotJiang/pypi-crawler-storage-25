"""Unbounded input via gets() for C (CWE-242).

SC705 — gets() unbounded input    high  CWE-242
"""

from sanicode.rules._c_shared import _Gets


class CGets(_Gets):
    """Detect gets() calls in C code."""

    rule_id = "SC705"
    language = "c"
