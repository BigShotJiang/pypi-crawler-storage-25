"""Filesystem TOCTOU race condition detection for C (CWE-362).

SC723 — access()/stat()/lstat() check-then-act    medium  CWE-362
"""

from sanicode.rules._c_shared import _TOCTOUCheck


class CTOCTOUCheck(_TOCTOUCheck):
    """Detect TOCTOU race conditions via access()/stat()/lstat() in C."""

    rule_id = "SC723"
    language = "c"
