"""Uncontrolled search path detection for C (CWE-427).

SC722 — dlopen / LoadLibrary with bare name    medium  CWE-427
"""

from sanicode.rules._c_shared import _SearchPathLoad


class CSearchPathLoadRule(_SearchPathLoad):
    """Detect dlopen/LoadLibrary calls in C code with a bare library name."""

    rule_id = "SC722"
    language = "c"
