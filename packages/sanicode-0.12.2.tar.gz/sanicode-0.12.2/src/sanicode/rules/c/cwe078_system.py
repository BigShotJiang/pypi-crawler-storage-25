"""Command injection via system()/popen() for C (CWE-78).

SC701 — system()/popen() command injection    high  CWE-78
"""

from sanicode.rules._c_shared import _SystemPopen


class CSystemPopen(_SystemPopen):
    """Detect system()/popen() calls in C code."""

    rule_id = "SC701"
    language = "c"
