"""Integer overflow in allocation size for C (CWE-190).

SC715 — malloc()/calloc() with arithmetic in size    high  CWE-190
"""

from sanicode.rules._c_shared import _MallocOverflow


class CMallocOverflow(_MallocOverflow):
    """Detect malloc()/calloc() with arithmetic in size argument in C code."""

    rule_id = "SC715"
    language = "c"
