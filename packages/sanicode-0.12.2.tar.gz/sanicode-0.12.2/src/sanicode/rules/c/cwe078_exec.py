"""Command injection via exec*() family for C (CWE-78).

SC702 — exec*() family command injection    high  CWE-78
"""

from sanicode.rules._c_shared import _ExecFamily


class CExecFamily(_ExecFamily):
    """Detect exec*() family calls in C code."""

    rule_id = "SC702"
    language = "c"
