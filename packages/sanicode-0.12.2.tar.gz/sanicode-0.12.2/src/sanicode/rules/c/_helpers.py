"""Shared helpers for C rule modules.

Re-exports shared C/C++ helpers under ``c_`` prefixed names.
"""

from __future__ import annotations

from tree_sitter import Node

from sanicode.rules._c_shared import (
    _bare_function_name,
    _call_args,
    _is_string_literal,
)


def c_function_name(node: Node) -> str:
    """Extract unqualified function name from a ``call_expression``'s function field."""
    return _bare_function_name(node)


def c_call_arguments(call_node: Node) -> list[Node]:
    """Return argument nodes from a ``call_expression``'s argument_list."""
    return _call_args(call_node)


def c_is_literal_string(node: Node) -> bool:
    """Return True if *node* is a string literal type."""
    return _is_string_literal(node)
