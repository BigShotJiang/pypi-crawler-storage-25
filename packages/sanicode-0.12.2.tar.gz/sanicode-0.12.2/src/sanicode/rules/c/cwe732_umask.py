"""Overly permissive umask for C (CWE-732).

SC718 — umask() with permissive value    medium  CWE-732
"""

from sanicode.rules._c_shared import _PermissiveUmask


class CPermissiveUmask(_PermissiveUmask):
    """Detect umask() with permissive values in C code."""

    rule_id = "SC718"
    language = "c"
