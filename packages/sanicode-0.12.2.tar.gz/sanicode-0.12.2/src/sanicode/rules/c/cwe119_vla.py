"""Variable-length array detection for C (CWE-119).

SC720 — variable-length array    high  CWE-119
"""

from sanicode.rules._c_shared import _VariableLengthArray


class CVariableLengthArray(_VariableLengthArray):
    """Detect variable-length arrays in C code."""

    rule_id = "SC720"
    language = "c"
