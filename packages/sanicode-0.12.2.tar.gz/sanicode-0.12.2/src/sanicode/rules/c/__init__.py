"""C-specific pattern detection rules."""
