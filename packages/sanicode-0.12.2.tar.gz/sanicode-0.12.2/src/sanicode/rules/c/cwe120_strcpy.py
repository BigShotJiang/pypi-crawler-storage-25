"""Buffer overflow via strcpy()/strcat() for C (CWE-120).

SC704 — strcpy()/strcat() buffer overflow    high  CWE-120
"""

from sanicode.rules._c_shared import _StrcpyStrcat


class CStrcpyStrcat(_StrcpyStrcat):
    """Detect strcpy()/strcat() calls in C code."""

    rule_id = "SC704"
    language = "c"
