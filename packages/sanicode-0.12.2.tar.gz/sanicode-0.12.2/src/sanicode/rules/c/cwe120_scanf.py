"""Buffer overflow via unbounded scanf() for C (CWE-120).

SC709 — scanf()/fscanf() without width specifier    medium  CWE-120
"""

from sanicode.rules._c_shared import _ScanfUnbounded


class CScanfUnbounded(_ScanfUnbounded):
    """Detect scanf()/fscanf() with unbounded %s/%[ in C code."""

    rule_id = "SC709"
    language = "c"
