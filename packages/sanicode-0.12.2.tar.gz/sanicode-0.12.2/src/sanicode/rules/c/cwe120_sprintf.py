"""Buffer overflow via sprintf()/vsprintf() for C (CWE-120).

SC703 — sprintf()/vsprintf() buffer overflow    high  CWE-120
"""

from sanicode.rules._c_shared import _SprintfVsprintf


class CSprintfVsprintf(_SprintfVsprintf):
    """Detect sprintf()/vsprintf() calls in C code."""

    rule_id = "SC703"
    language = "c"
