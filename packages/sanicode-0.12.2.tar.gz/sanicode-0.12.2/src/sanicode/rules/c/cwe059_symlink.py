"""Symlink following detection for C (CWE-59).

SC724 — symlink() / readlink()    medium  CWE-59
"""

from sanicode.rules._c_shared import _SymlinkOps


class CSymlinkOps(_SymlinkOps):
    """Detect symlink()/readlink() calls in C code."""

    rule_id = "SC724"
    language = "c"
