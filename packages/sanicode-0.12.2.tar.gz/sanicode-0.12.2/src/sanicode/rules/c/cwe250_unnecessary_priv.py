"""Execution with unnecessary privileges for C (CWE-250).

SC725 — setuid/setgid/seteuid/setegid called with 0 (root)    medium  CWE-250
"""

from sanicode.rules._c_shared import _PrivilegedSetuid


class CPrivilegedSetuid(_PrivilegedSetuid):
    """Detect explicit privilege escalation to root in C."""

    rule_id = "SC725"
    language = "c"
