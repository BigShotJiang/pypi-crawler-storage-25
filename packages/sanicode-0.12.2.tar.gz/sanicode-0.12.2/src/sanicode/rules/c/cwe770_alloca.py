"""Stack overflow via alloca() for C (CWE-770).

SC710 — alloca() stack overflow risk    medium  CWE-770
"""

from sanicode.rules._c_shared import _Alloca


class CAlloca(_Alloca):
    """Detect alloca() calls in C code."""

    rule_id = "SC710"
    language = "c"
