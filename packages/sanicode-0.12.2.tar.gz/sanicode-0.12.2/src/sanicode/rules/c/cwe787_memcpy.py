"""Out-of-bounds write via memcpy()/memmove()/memset()/strncpy() for C (CWE-787).

SC711 — memcpy()/memmove()/memset()/strncpy() OOB write    high  CWE-787
"""

from sanicode.rules._c_shared import _MemcpyMemmove


class CMemcpyMemmove(_MemcpyMemmove):
    """Detect memcpy()/memmove()/memset()/strncpy() calls in C code."""

    rule_id = "SC711"
    language = "c"
