"""Out-of-bounds read via memcmp()/memchr()/strncmp() for C (CWE-125).

SC712 — memcmp()/memchr()/strncmp() OOB read    medium  CWE-125
"""

from sanicode.rules._c_shared import _MemReadFunctions


class CMemReadFunctions(_MemReadFunctions):
    """Detect memcmp()/memchr()/strncmp() calls in C code."""

    rule_id = "SC712"
    language = "c"
