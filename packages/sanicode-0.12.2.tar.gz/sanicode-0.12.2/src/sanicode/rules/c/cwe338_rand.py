"""Weak PRNG via rand()/srand() for C (CWE-338).

SC708 — rand()/srand() weak PRNG    medium  CWE-338
"""

from sanicode.rules._c_shared import _WeakPrng


class CWeakPrng(_WeakPrng):
    """Detect rand()/srand() calls in C code."""

    rule_id = "SC708"
    language = "c"
