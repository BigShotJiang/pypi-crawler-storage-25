"""Unchecked security function return value for C (CWE-390).

SC719 — setuid/setgid/chdir/chroot with discarded return value    medium  CWE-390
"""

from sanicode.rules._c_shared import _UncheckedSecurityReturn


class CUncheckedSecurityReturn(_UncheckedSecurityReturn):
    """Detect discarded return values from security-critical functions in C."""

    rule_id = "SC719"
    language = "c"
