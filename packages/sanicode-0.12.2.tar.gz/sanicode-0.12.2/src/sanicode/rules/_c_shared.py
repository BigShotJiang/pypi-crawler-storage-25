"""Shared base classes for C and C++ detection rules.

Base classes have ``rule_id = ""`` to stay invisible to auto-discovery.
Thin subclasses in ``rules/c/`` and ``rules/cpp/`` set the concrete
``rule_id`` and ``language`` values.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import TYPE_CHECKING

from tree_sitter import Node, Tree

from sanicode.rules.base import Rule
from sanicode.scanner.patterns import Finding

if TYPE_CHECKING:
    from sanicode.scanner.languages.base import TreeSitterPlugin

# ---------------------------------------------------------------------------
# Node helpers
# ---------------------------------------------------------------------------

_STRING_LITERAL_TYPES = frozenset(
    {"string_literal", "concatenated_string", "char_literal"}
)

# Regex to detect unbounded %s or %[ in a format string.
# Matches % NOT immediately followed by digits before s or [.
# e.g. "%s" or "%[a-z]" are unsafe; "%20s" is bounded (safe).
_UNBOUNDED_FORMAT_RE = re.compile(r"%(?!\d)[^%\n]*?[s\[]")


def _bare_function_name(node: Node) -> str:
    """Extract the unqualified function name from a ``call_expression``'s
    ``function`` field.

    Handles the four cases that arise in C and C++:

    - ``identifier`` — bare name like ``system``
    - ``qualified_identifier`` — last identifier child (``std::system`` → ``system``)
    - ``field_expression`` — the ``field`` child (``obj->method()`` → ``method``)
    - ``template_function`` — the first identifier-like child
      (``reinterpret_cast<int*>`` → ``reinterpret_cast``)
    """
    if node.type == "identifier":
        return node.text.decode("utf-8") if node.text else ""

    if node.type == "qualified_identifier":
        # Walk children right-to-left and return the first identifier.
        for child in reversed(node.children):
            if child.type == "identifier" and child.text:
                return child.text.decode("utf-8")
        return node.text.decode("utf-8") if node.text else ""

    if node.type == "field_expression":
        field = node.child_by_field_name("field")
        if field is not None and field.text:
            return field.text.decode("utf-8")
        return ""

    if node.type == "template_function":
        # The ``name`` field is the unspecialised name (``reinterpret_cast``, etc.).
        name = node.child_by_field_name("name")
        if name is not None and name.text:
            return name.text.decode("utf-8")
        # Fallback: first identifier child.
        for child in node.children:
            if child.type == "identifier" and child.text:
                return child.text.decode("utf-8")
        return ""

    # Unknown node type — return raw text as best-effort.
    return node.text.decode("utf-8") if node.text else ""


def _call_args(call_node: Node) -> list[Node]:
    """Return the argument nodes from the ``argument_list`` of a
    ``call_expression``, skipping punctuation tokens.
    """
    args_node = call_node.child_by_field_name("arguments")
    if args_node is None:
        return []
    results: list[Node] = []
    for child in args_node.children:
        if child.type in ("(", ")", ","):
            continue
        results.append(child)
    return results


def _is_string_literal(node: Node) -> bool:
    """Return True if *node* is a string literal type."""
    return node.type in _STRING_LITERAL_TYPES


# ---------------------------------------------------------------------------
# Base rule implementations
# ---------------------------------------------------------------------------


class _SystemPopen(Rule):
    """CWE-78: Use of system()/popen() — command injection risk."""

    rule_id: str = ""
    cwe_id: int = 78
    severity = "high"
    message: str = "Use of system()/popen() — command injection risk (CWE-78)"

    _TARGETS = frozenset({"system", "popen"})

    def check(self, tree: Tree, file_path: Path, plugin: TreeSitterPlugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node
        for call_node in plugin.captures("(call_expression) @call", root).get("call", []):
            func = call_node.child_by_field_name("function")
            if func is not None and _bare_function_name(func) in self._TARGETS:
                findings.append(self._make_finding(call_node, plugin, file_path))
        return findings


class _ExecFamily(Rule):
    """CWE-78: Use of exec*() family — command injection risk."""

    rule_id: str = ""
    cwe_id: int = 78
    severity = "high"
    message: str = "Use of exec*() family — command injection risk (CWE-78)"

    _TARGETS = frozenset({"execl", "execle", "execlp", "execv", "execve", "execvp"})

    def check(self, tree: Tree, file_path: Path, plugin: TreeSitterPlugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node
        for call_node in plugin.captures("(call_expression) @call", root).get("call", []):
            func = call_node.child_by_field_name("function")
            if func is not None and _bare_function_name(func) in self._TARGETS:
                findings.append(self._make_finding(call_node, plugin, file_path))
        return findings


class _SprintfVsprintf(Rule):
    """CWE-120: Use of sprintf()/vsprintf() — buffer overflow risk."""

    rule_id: str = ""
    cwe_id: int = 120
    severity = "high"
    message: str = "Use of sprintf()/vsprintf() — buffer overflow risk (CWE-120)"

    _TARGETS = frozenset({"sprintf", "vsprintf"})

    def check(self, tree: Tree, file_path: Path, plugin: TreeSitterPlugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node
        for call_node in plugin.captures("(call_expression) @call", root).get("call", []):
            func = call_node.child_by_field_name("function")
            if func is not None and _bare_function_name(func) in self._TARGETS:
                findings.append(self._make_finding(call_node, plugin, file_path))
        return findings


class _StrcpyStrcat(Rule):
    """CWE-120: Use of strcpy()/strcat() without bounds checking — buffer overflow risk."""

    rule_id: str = ""
    cwe_id: int = 120
    severity = "high"
    message: str = (
        "Use of strcpy()/strcat() without bounds checking — "
        "buffer overflow risk (CWE-120)"
    )

    _TARGETS = frozenset({"strcpy", "strcat"})

    def check(self, tree: Tree, file_path: Path, plugin: TreeSitterPlugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node
        for call_node in plugin.captures("(call_expression) @call", root).get("call", []):
            func = call_node.child_by_field_name("function")
            if func is not None and _bare_function_name(func) in self._TARGETS:
                findings.append(self._make_finding(call_node, plugin, file_path))
        return findings


class _Gets(Rule):
    """CWE-242: Use of gets() — unbounded input."""

    rule_id: str = ""
    cwe_id: int = 242
    severity = "high"
    message: str = "Use of gets() — unbounded input, use fgets() instead (CWE-242)"

    def check(self, tree: Tree, file_path: Path, plugin: TreeSitterPlugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node
        for call_node in plugin.captures("(call_expression) @call", root).get("call", []):
            func = call_node.child_by_field_name("function")
            if func is not None and _bare_function_name(func) == "gets":
                findings.append(self._make_finding(call_node, plugin, file_path))
        return findings


class _FormatString(Rule):
    """CWE-134: Format string from non-literal — format string vulnerability."""

    rule_id: str = ""
    cwe_id: int = 134
    severity = "high"
    message: str = "Format string from non-literal — format string vulnerability (CWE-134)"

    # Maps function name → index of the format argument.
    # printf: arg 0; fprintf/sprintf: arg 1 (first arg is FILE*/buffer).
    _FORMAT_ARG_INDEX: dict[str, int] = {
        "printf": 0,
        "fprintf": 1,
        "sprintf": 1,
    }

    def check(self, tree: Tree, file_path: Path, plugin: TreeSitterPlugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node
        for call_node in plugin.captures("(call_expression) @call", root).get("call", []):
            func = call_node.child_by_field_name("function")
            if func is None:
                continue
            name = _bare_function_name(func)
            if name not in self._FORMAT_ARG_INDEX:
                continue
            fmt_idx = self._FORMAT_ARG_INDEX[name]
            args = _call_args(call_node)
            if len(args) <= fmt_idx:
                continue
            fmt_arg = args[fmt_idx]
            if not _is_string_literal(fmt_arg):
                findings.append(self._make_finding(call_node, plugin, file_path))
        return findings


class _Mktemp(Rule):
    """CWE-377: Use of mktemp() — insecure temporary file creation."""

    rule_id: str = ""
    cwe_id: int = 377
    severity = "medium"
    message: str = "Use of mktemp() — insecure temporary file creation (CWE-377)"

    def check(self, tree: Tree, file_path: Path, plugin: TreeSitterPlugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node
        for call_node in plugin.captures("(call_expression) @call", root).get("call", []):
            func = call_node.child_by_field_name("function")
            if func is not None and _bare_function_name(func) == "mktemp":
                findings.append(self._make_finding(call_node, plugin, file_path))
        return findings


class _WeakPrng(Rule):
    """CWE-338: Use of rand()/srand() — weak PRNG."""

    rule_id: str = ""
    cwe_id: int = 338
    severity = "medium"
    message: str = "Use of rand()/srand() — weak PRNG, not suitable for security purposes (CWE-338)"

    _TARGETS = frozenset({"rand", "srand"})

    def check(self, tree: Tree, file_path: Path, plugin: TreeSitterPlugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node
        for call_node in plugin.captures("(call_expression) @call", root).get("call", []):
            func = call_node.child_by_field_name("function")
            if func is not None and _bare_function_name(func) in self._TARGETS:
                findings.append(self._make_finding(call_node, plugin, file_path))
        return findings


class _ScanfUnbounded(Rule):
    """CWE-120: scanf()/fscanf() with unbounded %s/%[ — buffer overflow risk."""

    rule_id: str = ""
    cwe_id: int = 120
    severity = "medium"
    message: str = "scanf()/fscanf() with unbounded %s/%[ — buffer overflow risk (CWE-120)"

    # Maps function name → index of the format argument.
    _FORMAT_ARG_INDEX: dict[str, int] = {
        "scanf": 0,
        "fscanf": 1,
    }

    def check(self, tree: Tree, file_path: Path, plugin: TreeSitterPlugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node
        for call_node in plugin.captures("(call_expression) @call", root).get("call", []):
            func = call_node.child_by_field_name("function")
            if func is None:
                continue
            name = _bare_function_name(func)
            if name not in self._FORMAT_ARG_INDEX:
                continue
            fmt_idx = self._FORMAT_ARG_INDEX[name]
            args = _call_args(call_node)
            if len(args) <= fmt_idx:
                continue
            fmt_arg = args[fmt_idx]
            # We can only check the format string if it's a literal.
            if not _is_string_literal(fmt_arg):
                continue
            fmt_text = plugin.node_text(fmt_arg)
            if _UNBOUNDED_FORMAT_RE.search(fmt_text):
                findings.append(self._make_finding(call_node, plugin, file_path))
        return findings


class _Alloca(Rule):
    """CWE-770: Use of alloca() — stack overflow risk with large/unvalidated sizes."""

    rule_id: str = ""
    cwe_id: int = 770
    severity = "medium"
    message: str = "Use of alloca() — stack overflow risk with large/unvalidated sizes (CWE-770)"

    def check(self, tree: Tree, file_path: Path, plugin: TreeSitterPlugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node
        for call_node in plugin.captures("(call_expression) @call", root).get("call", []):
            func = call_node.child_by_field_name("function")
            if func is not None and _bare_function_name(func) == "alloca":
                findings.append(self._make_finding(call_node, plugin, file_path))
        return findings


class _MemcpyMemmove(Rule):
    """CWE-787: Use of memcpy()/memmove()/memset()/strncpy() — out-of-bounds write risk."""

    rule_id: str = ""
    cwe_id: int = 787
    severity = "high"
    message: str = (
        "Use of memcpy()/memmove()/memset()/strncpy() — "
        "out-of-bounds write risk (CWE-787)"
    )

    _TARGETS = frozenset({"memcpy", "memmove", "memset", "strncpy"})

    def check(self, tree: Tree, file_path: Path, plugin: TreeSitterPlugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node
        for call_node in plugin.captures("(call_expression) @call", root).get("call", []):
            func = call_node.child_by_field_name("function")
            if func is not None and _bare_function_name(func) in self._TARGETS:
                findings.append(self._make_finding(call_node, plugin, file_path))
        return findings


class _MemReadFunctions(Rule):
    """CWE-125: Use of memcmp()/memchr()/strncmp() — out-of-bounds read risk."""

    rule_id: str = ""
    cwe_id: int = 125
    severity = "medium"
    message: str = (
        "Use of memcmp()/memchr()/strncmp() — "
        "out-of-bounds read risk (CWE-125)"
    )

    _TARGETS = frozenset({"memcmp", "memchr", "strncmp"})

    def check(self, tree: Tree, file_path: Path, plugin: TreeSitterPlugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node
        for call_node in plugin.captures("(call_expression) @call", root).get("call", []):
            func = call_node.child_by_field_name("function")
            if func is not None and _bare_function_name(func) in self._TARGETS:
                findings.append(self._make_finding(call_node, plugin, file_path))
        return findings


class _ReallocUseAfterFree(Rule):
    """CWE-416: Use of realloc() — use-after-free risk if original pointer retained."""

    rule_id: str = ""
    cwe_id: int = 416
    severity = "high"
    message: str = (
        "Use of realloc() — use-after-free risk if original pointer is retained "
        "after realloc returns a different address (CWE-416)"
    )

    def check(self, tree: Tree, file_path: Path, plugin: TreeSitterPlugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node
        for call_node in plugin.captures("(call_expression) @call", root).get("call", []):
            func = call_node.child_by_field_name("function")
            if func is not None and _bare_function_name(func) == "realloc":
                findings.append(self._make_finding(call_node, plugin, file_path))
        return findings


class _AtoiAtol(Rule):
    """CWE-20: Use of atoi()/atol()/atof() — no error indication on invalid input."""

    rule_id: str = ""
    cwe_id: int = 20
    severity = "medium"
    message: str = (
        "Use of atoi()/atol()/atof() — returns 0 on invalid input with no error "
        "indication, use strtol()/strtod() with errno check instead (CWE-20)"
    )

    _TARGETS = frozenset({"atoi", "atol", "atof", "atoll"})

    def check(self, tree: Tree, file_path: Path, plugin: TreeSitterPlugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node
        for call_node in plugin.captures("(call_expression) @call", root).get("call", []):
            func = call_node.child_by_field_name("function")
            if func is not None and _bare_function_name(func) in self._TARGETS:
                findings.append(self._make_finding(call_node, plugin, file_path))
        return findings


class _MallocOverflow(Rule):
    """CWE-190: malloc()/calloc() with arithmetic in size — integer overflow risk."""

    rule_id: str = ""
    cwe_id: int = 190
    severity = "high"
    message: str = (
        "Arithmetic in malloc()/calloc() size argument — "
        "integer overflow may cause undersized allocation (CWE-190)"
    )

    _TARGETS = frozenset({"malloc", "calloc"})

    def check(self, tree: Tree, file_path: Path, plugin: TreeSitterPlugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node
        for call_node in plugin.captures("(call_expression) @call", root).get("call", []):
            func = call_node.child_by_field_name("function")
            if func is None:
                continue
            name = _bare_function_name(func)
            if name not in self._TARGETS:
                continue
            args = _call_args(call_node)
            for arg in args:
                if self._has_arithmetic(arg):
                    findings.append(self._make_finding(call_node, plugin, file_path))
                    break
        return findings

    @staticmethod
    def _has_arithmetic(node: Node) -> bool:
        """Return True if node contains binary arithmetic (* + - <<)."""
        if node.type == "binary_expression":
            for child in node.children:
                if child.type in ("*", "+", "-", "<<"):
                    return True
                if child.text and child.text in (b"*", b"+", b"-", b"<<"):
                    return True
        for child in node.children:
            if _MallocOverflow._has_arithmetic(child):
                return True
        return False


def _is_constant_size(node: Node) -> bool:
    """Return True if *node* is a compile-time constant array size expression.

    Recognises:
    - ``number_literal`` — plain integer constants (``100``, ``0x40``)
    - ``sizeof_expression`` — ``sizeof(type)`` or ``sizeof expr``
    - ``binary_expression`` — arithmetic composed entirely of the above
      (e.g. ``sizeof(int) * 8`` or ``100 + 4``)
    - Parenthesised variants of the above (``parenthesized_expression``)
    """
    if node.type in ("number_literal", "sizeof_expression"):
        return True
    if node.type == "parenthesized_expression":
        # Walk into the single inner child (skip parenthesis tokens).
        for child in node.children:
            if child.type not in ("(", ")"):
                return _is_constant_size(child)
    if node.type == "binary_expression":
        return all(
            _is_constant_size(child)
            for child in node.children
            if child.type not in ("+", "-", "*", "/", "%", "<<", ">>", "&", "|", "^")
        )
    return False


class _VariableLengthArray(Rule):
    """CWE-119: Variable-length array — stack buffer overflow risk."""

    rule_id: str = ""
    cwe_id: int = 119
    severity = "high"
    message: str = "Variable-length array — stack buffer overflow risk (CWE-119)"

    def check(self, tree: Tree, file_path: Path, plugin: TreeSitterPlugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node
        for decl_node in plugin.captures("(array_declarator) @arr", root).get("arr", []):
            size = decl_node.child_by_field_name("size")
            # No size means flexible array member (int arr[]) — skip.
            if size is None:
                continue
            # Compile-time constant sizes are safe; runtime values (identifiers,
            # arbitrary expressions) indicate a VLA and are flagged.
            if not _is_constant_size(size):
                findings.append(self._make_finding(decl_node, plugin, file_path))
        return findings


class _WideStringOverflow(Rule):
    """CWE-122: Use of wide-string functions without bounds — heap buffer overflow risk."""

    rule_id: str = ""
    cwe_id: int = 122
    severity = "high"
    message: str = (
        "Use of wcscpy()/wcscat()/swprintf() — wide-string buffer overflow risk (CWE-122)"
    )

    _TARGETS = frozenset({"wcscpy", "wcscat", "swprintf"})

    def check(self, tree: Tree, file_path: Path, plugin: TreeSitterPlugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node
        for call_node in plugin.captures("(call_expression) @call", root).get("call", []):
            func = call_node.child_by_field_name("function")
            if func is not None and _bare_function_name(func) in self._TARGETS:
                findings.append(self._make_finding(call_node, plugin, file_path))
        return findings


class _UncheckedSecurityReturn(Rule):
    """CWE-390: Security-critical function call with discarded return value.

    Flags calls to privilege/directory functions whose return value is discarded
    (the call_expression appears directly inside an expression_statement, meaning
    it is neither assigned nor used as a condition).
    """

    rule_id: str = ""
    cwe_id: int = 390
    severity = "medium"
    message: str = (
        "Return value of security-critical function discarded — "
        "failed privilege/directory change goes undetected (CWE-390)"
    )

    _TARGETS: frozenset[str] = frozenset({"setuid", "setgid", "chdir", "chroot"})

    def check(self, tree: Tree, file_path: Path, plugin: TreeSitterPlugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node
        for call_node in plugin.captures("(call_expression) @call", root).get("call", []):
            func = call_node.child_by_field_name("function")
            if func is None or _bare_function_name(func) not in self._TARGETS:
                continue
            # Flag only when the call is a bare expression statement (return value discarded).
            parent = call_node.parent
            if parent is not None and parent.type == "expression_statement":
                findings.append(self._make_finding(call_node, plugin, file_path))
        return findings


class _PrivilegedSetuid(Rule):
    """CWE-250: Explicit privilege escalation to root via setuid/setgid(0).

    Flags calls to setuid/setgid/seteuid/setegid with a literal ``0`` argument,
    indicating explicit escalation to root privileges.  Distinct from CWE-390
    which flags *unchecked* return values of these functions.
    """

    rule_id: str = ""
    cwe_id: int = 250
    severity = "medium"
    message: str = (
        "Process privileges escalated to root via setuid/setgid(0) — "
        "unnecessary privilege escalation (CWE-250)"
    )

    _TARGETS: frozenset[str] = frozenset({"setuid", "setgid", "seteuid", "setegid"})

    def check(self, tree: Tree, file_path: Path, plugin: TreeSitterPlugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node
        for call_node in plugin.captures("(call_expression) @call", root).get("call", []):
            func = call_node.child_by_field_name("function")
            if func is None:
                continue
            if _bare_function_name(func) not in self._TARGETS:
                continue
            args = _call_args(call_node)
            if not args:
                continue
            first_arg = args[0]
            if first_arg.type == "number_literal" and first_arg.text == b"0":
                findings.append(self._make_finding(call_node, plugin, file_path))
        return findings


class _MallocNullCheck(Rule):
    """CWE-476: Use of null-returning function without NULL check — null dereference risk."""

    rule_id: str = ""
    cwe_id: int = 476
    severity = "high"
    message: str = (
        "Return value of null-returning function used without NULL check — "
        "null pointer dereference risk (CWE-476)"
    )

    _TARGETS = frozenset({
        "malloc", "calloc", "realloc", "fopen", "popen", "freopen",
        "tmpfile", "getenv", "strchr", "strrchr", "strstr", "strtok",
        "localtime", "gmtime",
    })

    def check(self, tree: Tree, file_path: Path, plugin: TreeSitterPlugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node
        for call_node in plugin.captures("(call_expression) @call", root).get("call", []):
            func = call_node.child_by_field_name("function")
            if func is not None and _bare_function_name(func) in self._TARGETS:
                findings.append(self._make_finding(call_node, plugin, file_path))
        return findings


class _FilePermissions(Rule):
    """CWE-276: chmod/fchmod/open/mkdir with overly permissive mode."""

    rule_id: str = ""
    cwe_id: int = 276
    severity = "medium"
    message: str = (
        "File operation with overly permissive mode — "
        "files may be world-writable (CWE-276)"
    )

    # C/C++ octal literals for dangerous modes (C uses 0777-style prefix).
    _DANGEROUS_MODES = frozenset({
        "0777", "0776", "0766", "0666",
    })

    # Maps function name → 0-based index of the mode argument.
    # chmod(path, mode)       → mode at index 1
    # fchmod(fd, mode)        → mode at index 1
    # open(path, flags, mode) → mode at index 2
    # mkdir(path, mode)       → mode at index 1
    _MODE_ARG_INDEX: dict[str, int] = {
        "chmod": 1,
        "fchmod": 1,
        "open": 2,
        "mkdir": 1,
    }

    def _is_dangerous_mode(self, node: Node) -> bool:
        """Return True if *node* is a number_literal in the dangerous set."""
        if node.type != "number_literal":
            return False
        text = node.text.decode("utf-8") if node.text else ""
        return text in self._DANGEROUS_MODES

    def check(self, tree: Tree, file_path: Path, plugin: TreeSitterPlugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node
        for call_node in plugin.captures("(call_expression) @call", root).get("call", []):
            func = call_node.child_by_field_name("function")
            if func is None:
                continue
            name = _bare_function_name(func)
            if name not in self._MODE_ARG_INDEX:
                continue
            mode_idx = self._MODE_ARG_INDEX[name]
            args = _call_args(call_node)
            if len(args) <= mode_idx:
                continue
            if self._is_dangerous_mode(args[mode_idx]):
                findings.append(self._make_finding(call_node, plugin, file_path))
        return findings


class _PermissiveUmask(Rule):
    """CWE-732: umask() with permissive mask value."""

    rule_id: str = ""
    cwe_id: int = 732
    severity = "medium"
    message: str = (
        "umask() with overly permissive value — "
        "newly created files may be world-readable or writable (CWE-732)"
    )

    # Octal umask values that leave files world-readable or world-writable.
    # C umask uses C-style octal literals (0022, 0002, etc.).
    _PERMISSIVE_UMASKS = frozenset({
        "0",      # decimal zero — no masking at all
        "0000",   # octal zero
        "0002",   # other-write allowed
        "0006",   # other read+write
        "0007",   # group fully open
        "0011",   # minimal mask
        "0022",   # world-readable (common default)
    })

    def check(self, tree: Tree, file_path: Path, plugin: TreeSitterPlugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node
        for call_node in plugin.captures("(call_expression) @call", root).get("call", []):
            func = call_node.child_by_field_name("function")
            if func is None:
                continue
            if _bare_function_name(func) != "umask":
                continue
            args = _call_args(call_node)
            if not args:
                continue
            arg = args[0]
            if arg.type == "number_literal":
                text = arg.text.decode("utf-8") if arg.text else ""
                if text in self._PERMISSIVE_UMASKS:
                    findings.append(self._make_finding(call_node, plugin, file_path))
        return findings



# ---------------------------------------------------------------------------
# CWE-427 helpers and base class
# ---------------------------------------------------------------------------


def _is_absolute_or_explicit_relative(text: str) -> bool:
    """Return True if *text* is an absolute or explicitly relative path.

    Safe paths start with ``/``, ``./``, ``../``, ``\\\\`` (UNC), or a
    Windows drive letter (e.g. ``C:\\``).  Everything else relies on
    OS search-path resolution and is considered unsafe.

    Handles C/C++ string encoding prefixes (``L``, ``u8``, ``u``, ``U``)
    before stripping quote delimiters.
    """
    # Strip C/C++ string encoding prefixes (L, u, U) before the quote.
    prefix_chars = set("LuU")
    i = 0
    while i < len(text) and text[i] in prefix_chars:
        i += 1
    text = text[i:]
    stripped = text.strip("'\"")
    return (
        stripped.startswith("/")
        or stripped.startswith("./")
        or stripped.startswith("../")
        or stripped.startswith("\\\\")
        or (len(stripped) >= 3 and stripped[1] == ":" and stripped[2] in ("/", "\\"))
    )


class _TOCTOUCheck(Rule):
    """CWE-362: Filesystem TOCTOU race — check-then-act on access()/stat()/lstat()."""

    rule_id: str = ""
    cwe_id: int = 362
    severity = "medium"
    message: str = (
        "Filesystem TOCTOU race — check-then-act on "
        "access()/stat()/lstat() result can be exploited (CWE-362)"
    )

    _TARGETS = frozenset({"access", "stat", "lstat"})

    def check(self, tree: Tree, file_path: Path, plugin: TreeSitterPlugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node
        for call_node in plugin.captures("(call_expression) @call", root).get("call", []):
            func = call_node.child_by_field_name("function")
            if func is not None and _bare_function_name(func) in self._TARGETS:
                findings.append(self._make_finding(call_node, plugin, file_path))
        return findings


class _SymlinkOps(Rule):
    """CWE-59: symlink()/readlink() — symlink following risk."""

    rule_id: str = ""
    cwe_id: int = 59
    severity = "medium"
    message: str = (
        "Symlink operation without safety checks — "
        "symlink following may allow unauthorized file access (CWE-59)"
    )

    _TARGETS = frozenset({"symlink", "readlink"})

    def check(self, tree: Tree, file_path: Path, plugin: TreeSitterPlugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node
        for call_node in plugin.captures("(call_expression) @call", root).get("call", []):
            func = call_node.child_by_field_name("function")
            if func is not None and _bare_function_name(func) in self._TARGETS:
                findings.append(self._make_finding(call_node, plugin, file_path))
        return findings


class _SearchPathLoad(Rule):
    """CWE-427: Library loaded via uncontrolled search path.

    Detects calls to ``dlopen`` / ``LoadLibrary*`` where the first
    argument is a string literal without an absolute or explicit-relative
    path prefix -- meaning the OS will search ``LD_LIBRARY_PATH``,
    ``PATH``, or ``%PATH%`` to resolve the library.
    """

    rule_id: str = ""
    cwe_id: int = 427
    severity = "medium"
    message: str = (
        "Library loaded via search path \u2014 "
        "uncontrolled search path risk (CWE-427)"
    )

    _TARGETS = frozenset({
        "dlopen",
        "LoadLibrary",
        "LoadLibraryA",
        "LoadLibraryW",
        "LoadLibraryEx",
        "LoadLibraryExA",
        "LoadLibraryExW",
    })

    def check(self, tree: Tree, file_path: Path, plugin: TreeSitterPlugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node
        for call_node in plugin.captures("(call_expression) @call", root).get("call", []):
            func = call_node.child_by_field_name("function")
            if func is None:
                continue
            name = _bare_function_name(func)
            if name not in self._TARGETS:
                continue
            args = _call_args(call_node)
            if not args:
                continue
            first_arg = args[0]
            if not _is_string_literal(first_arg):
                continue
            text = plugin.node_text(first_arg)
            if not _is_absolute_or_explicit_relative(text):
                findings.append(self._make_finding(call_node, plugin, file_path))
        return findings
