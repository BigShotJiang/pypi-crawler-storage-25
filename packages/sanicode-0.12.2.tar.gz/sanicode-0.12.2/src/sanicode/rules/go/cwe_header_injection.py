"""CRLF and HTTP header injection detection for Go (CWE-93, CWE-113).

SC323 — CRLF injection via header manipulation    medium  CWE-93
SC324 — HTTP response splitting via headers       medium  CWE-113

Detects patterns like ``w.Header().Set(...)`` and ``w.Header().Add(...)``.
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule, _walk
from sanicode.scanner.patterns import Finding

_HEADER_METHODS = frozenset({"Set", "Add"})


def _is_header_chain(call_node) -> bool:
    """Check if a call_expression is a ``*.Header().Set/Add(...)`` pattern.

    The tree-sitter structure looks like:
        call_expression
          function: selector_expression
            operand: call_expression          <- the Header() call
              function: selector_expression
                operand: identifier (e.g. w)
                field: identifier (Header)
            field: identifier (Set | Add)
    """
    func_node = call_node.child_by_field_name("function")
    if func_node is None or func_node.type != "selector_expression":
        return False

    # The method name must be Set or Add
    field_node = func_node.child_by_field_name("field")
    if field_node is None or not field_node.text:
        return False
    method = field_node.text.decode("utf-8")
    if method not in _HEADER_METHODS:
        return False

    # The operand must be a call_expression ending in .Header()
    operand = func_node.child_by_field_name("operand")
    if operand is None or operand.type != "call_expression":
        return False

    inner_func = operand.child_by_field_name("function")
    if inner_func is None:
        return False

    # Could be selector_expression (w.Header) or just identifier
    if inner_func.type == "selector_expression":
        inner_field = inner_func.child_by_field_name("field")
        if inner_field and inner_field.text:
            return inner_field.text.decode("utf-8") == "Header"
    elif inner_func.type == "identifier":
        name = inner_func.text.decode("utf-8") if inner_func.text else ""
        return name == "Header"

    return False


def _check_header_calls(
    tree: Tree, file_path: Path, plugin, rule: Rule,
) -> list[Finding]:
    """Shared detection logic for Go HTTP header chain calls."""
    findings: list[Finding] = []

    for node in _walk(tree.root_node):
        if node.type != "call_expression":
            continue
        if _is_header_chain(node):
            findings.append(rule._make_finding(node, plugin, file_path))

    return findings


class CRLFInjectionRule(Rule):
    """Detect w.Header().Set/Add calls in Go — CRLF injection risk."""

    rule_id = "SC323"
    cwe_id = 93
    severity = "medium"
    language = "go"
    message = (
        "HTTP header set \u2014 verify value is sanitized against "
        "CRLF injection (CWE-93)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        return _check_header_calls(tree, file_path, plugin, self)


class HeaderInjectionRule(Rule):
    """Detect w.Header().Set/Add calls in Go — response splitting risk."""

    rule_id = "SC324"
    cwe_id = 113
    severity = "medium"
    language = "go"
    message = (
        "HTTP header set \u2014 verify value prevents "
        "response splitting (CWE-113)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        return _check_header_calls(tree, file_path, plugin, self)
