"""IDOR detection for Go (CWE-639).

SC357 — User input flows directly into database lookup    medium  CWE-639
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.go._helpers import go_dotted_name
from sanicode.scanner.patterns import Finding

_DB_METHODS = frozenset({"First", "Find", "Where", "Take", "Last"})
_REQUEST_PATTERNS = ("Param(", "Query().Get(", "FormValue(", "PathValue(")


class GoIdorRule(Rule):
    """Detect GORM lookups with user-controlled path/query parameters."""

    rule_id = "SC357"
    cwe_id = 639
    severity = "medium"
    language = "go"
    tags = ["auth", "idor"]
    domain = "access_control"
    message = (
        "User input flows directly into database lookup — "
        "potential IDOR vulnerability (CWE-639)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(call_expression) @call", tree.root_node)
        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue
            dotted = go_dotted_name(func_node)
            parts = dotted.split(".")
            method = parts[-1] if parts else ""
            if method not in _DB_METHODS:
                continue

            args_node = call_node.child_by_field_name("arguments")
            if args_node is None:
                continue
            args_text = plugin.node_text(args_node)

            if any(pat in args_text for pat in _REQUEST_PATTERNS):
                findings.append(self._make_finding(call_node, plugin, file_path))
        return findings
