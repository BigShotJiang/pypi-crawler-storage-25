"""Argument injection detection for Go (CWE-88).

SC325 — exec.Command/exec.CommandContext with literal command and variable args    medium  CWE-88
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.go._helpers import go_call_arguments, go_dotted_name
from sanicode.scanner.patterns import Finding

_EXEC_FUNCS = frozenset({
    "exec.Command",
    "exec.CommandContext",
})


def _is_string_literal(node) -> bool:
    """Return True if node is a Go string literal."""
    return node.type in ("interpreted_string_literal", "raw_string_literal")


class GoArgumentInjectionRule(Rule):
    """Detect exec.Command() with literal command and variable arguments."""

    rule_id = "SC325"
    cwe_id = 88
    severity = "medium"
    language = "go"
    message = (
        "exec.Command with literal command and variable arguments "
        "— potential argument injection (CWE-88)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(call_expression) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue

            name = go_dotted_name(func_node)
            if name not in _EXEC_FUNCS:
                continue

            args = go_call_arguments(call_node)
            if not args:
                continue

            # For exec.CommandContext, the first arg is the context — skip it
            if name == "exec.CommandContext":
                if len(args) < 2:
                    continue
                cmd_arg = args[1]
                remaining = args[2:]
            else:
                cmd_arg = args[0]
                remaining = args[1:]

            # Command must be a string literal
            if not _is_string_literal(cmd_arg):
                continue

            # At least one remaining arg must be non-literal (a variable)
            if not remaining:
                continue

            has_variable_arg = any(
                not _is_string_literal(arg) for arg in remaining
            )
            if has_variable_arg:
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
