"""Session and cookie security detection rules for Go (CWE-614, CWE-384, CWE-613).

SC332 -- Insecure cookie configuration (missing Secure flag)     medium  CWE-614
SC333 -- Session fixation (auth without session regeneration)    medium  CWE-384
SC334 -- Session timeout / cookie integrity                      low     CWE-613
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule, _walk
from sanicode.rules.go._helpers import go_dotted_name
from sanicode.scanner.patterns import Finding


class GoInsecureCookieRule(Rule):
    """Detect cookie creation without the Secure flag (CWE-614).

    Flags ``http.SetCookie(w, cookie)`` calls as requiring Secure flag
    review, and ``cookie.Secure = false`` assignments.
    """

    rule_id = "SC332"
    cwe_id = 614
    severity = "medium"
    language = "go"
    message = "Cookie created \u2014 verify Secure flag is set (CWE-614)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        # Pattern 1: http.SetCookie(w, cookie)
        call_captures = plugin.captures("(call_expression) @call", root)
        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue
            if go_dotted_name(func_node) == "http.SetCookie":
                findings.append(self._make_finding(call_node, plugin, file_path))

        # Pattern 2: cookie.Secure = false
        for node in _walk(root):
            if node.type != "assignment_statement":
                continue
            left = node.child_by_field_name("left")
            right = node.child_by_field_name("right")
            if left is None or right is None:
                continue
            # left is an expression_list, get first child
            left_exprs = [c for c in left.children if c.type not in (",",)]
            right_exprs = [c for c in right.children if c.type not in (",",)]
            if not left_exprs or not right_exprs:
                continue
            left_text = left_exprs[0].text.decode("utf-8") if left_exprs[0].text else ""
            right_text = right_exprs[0].text.decode("utf-8") if right_exprs[0].text else ""
            if left_text.endswith(".Secure") and right_text == "false":
                findings.append(self._make_finding(node, plugin, file_path))

        return findings


class GoSessionFixationRule(Rule):
    """Detect session-related patterns needing regeneration review (CWE-384).

    Flags session save/set operations and login handlers as requiring
    session regeneration review.
    """

    rule_id = "SC333"
    cwe_id = 384
    severity = "medium"
    language = "go"
    message = (
        "Session operation \u2014 verify session ID is regenerated after login (CWE-384)"
    )

    _SESSION_METHODS = frozenset({"Save", "Set"})

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        call_captures = plugin.captures("(call_expression) @call", root)
        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue
            _dotted = go_dotted_name(func_node)
            # Match session.Save(), session.Set()
            if func_node.type == "selector_expression":
                operand = func_node.child_by_field_name("operand")
                field = func_node.child_by_field_name("field")
                if operand and field and field.text:
                    operand_text = operand.text.decode("utf-8") if operand.text else ""
                    method = field.text.decode("utf-8")
                    if "session" in operand_text.lower() and method in self._SESSION_METHODS:
                        findings.append(
                            self._make_finding(call_node, plugin, file_path)
                        )

        return findings


class GoSessionTimeoutRule(Rule):
    """Detect session/cookie misconfiguration: HttpOnly disabled (CWE-613).

    Flags ``cookie.HttpOnly = false`` assignments.
    """

    rule_id = "SC334"
    cwe_id = 613
    severity = "low"
    language = "go"
    message = (
        "Session configuration \u2014 verify timeout and integrity settings (CWE-613)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        for node in _walk(root):
            if node.type != "assignment_statement":
                continue
            left = node.child_by_field_name("left")
            right = node.child_by_field_name("right")
            if left is None or right is None:
                continue
            left_exprs = [c for c in left.children if c.type not in (",",)]
            right_exprs = [c for c in right.children if c.type not in (",",)]
            if not left_exprs or not right_exprs:
                continue
            left_text = left_exprs[0].text.decode("utf-8") if left_exprs[0].text else ""
            right_text = right_exprs[0].text.decode("utf-8") if right_exprs[0].text else ""
            if left_text.endswith(".HttpOnly") and right_text == "false":
                findings.append(self._make_finding(node, plugin, file_path))

        return findings
