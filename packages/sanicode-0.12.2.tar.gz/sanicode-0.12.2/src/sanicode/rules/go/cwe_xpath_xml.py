"""XPath and XML injection detection for Go (CWE-91, CWE-643, CWE-776).

SC326 -- XPath injection via dynamic query             medium  CWE-91
SC327 -- Unsanitized data in XPath expression          medium  CWE-643
SC328 -- XML parser without entity expansion limits    low     CWE-776
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.go._helpers import go_call_arguments, go_dotted_name
from sanicode.scanner.patterns import Finding

# XPath function names (dotted).
_XPATH_DOTTED = frozenset({
    "xmlpath.Compile",
    "xpath.Compile",
    "xpath.MustCompile",
    "xmlquery.Find",
    "xmlquery.FindOne",
    "xmlquery.QueryAll",
})

# Go string literal node type.
_LITERAL_TYPES = frozenset({
    "interpreted_string_literal",
    "raw_string_literal",
})

# XML decoder creation functions.
_XML_DECODER_DOTTED = frozenset({
    "xml.NewDecoder",
})


def _is_go_literal(node) -> bool:
    """Return True if node is a Go string literal."""
    return node.type in _LITERAL_TYPES


def _find_xpath_findings(tree: Tree, file_path: Path, plugin, rule) -> list[Finding]:
    """Shared detection logic for CWE-91 and CWE-643 XPath injection."""
    findings: list[Finding] = []
    captures = plugin.captures("(call_expression) @call", tree.root_node)

    for call_node in captures.get("call", []):
        func_node = call_node.child_by_field_name("function")
        if func_node is None:
            continue

        dotted = go_dotted_name(func_node)
        if dotted not in _XPATH_DOTTED:
            continue

        args = go_call_arguments(call_node)
        if not args:
            continue

        # The first argument is the XPath expression (or for xmlquery.Find,
        # the second argument is the XPath but the first is the doc node).
        if "Find" in dotted or "FindOne" in dotted or "QueryAll" in dotted:
            if len(args) < 2:
                continue
            xpath_arg = args[1]
        else:
            xpath_arg = args[0]

        if _is_go_literal(xpath_arg):
            continue

        findings.append(rule._make_finding(call_node, plugin, file_path))

    return findings


class GoXPathInjectionRule(Rule):
    """Detect XPath queries built from dynamic input -- XPath injection."""

    rule_id = "SC326"
    cwe_id = 91
    severity = "medium"
    language = "go"
    message = (
        "XPath query built from dynamic input "
        "\u2014 potential XPath injection (CWE-91)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        return _find_xpath_findings(tree, file_path, plugin, self)


class GoXPathDataInjectionRule(Rule):
    """Detect unsanitized data in XPath expressions -- injection."""

    rule_id = "SC327"
    cwe_id = 643
    severity = "medium"
    language = "go"
    message = (
        "XPath expression includes unsanitized data "
        "\u2014 potential injection (CWE-643)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        return _find_xpath_findings(tree, file_path, plugin, self)


class GoXMLEntityExpansionRule(Rule):
    """Detect XML decoder creation that may allow entity expansion.

    Go's encoding/xml package does not support DTD entity expansion by
    default, so this is a low-severity review flag rather than a direct
    vulnerability.  Flags xml.NewDecoder() for review.
    """

    rule_id = "SC328"
    cwe_id = 776
    severity = "low"
    language = "go"
    message = (
        "XML decoder created without explicit entity limits "
        "\u2014 review for entity expansion safety (CWE-776)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        captures = plugin.captures("(call_expression) @call", tree.root_node)

        for call_node in captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue

            dotted = go_dotted_name(func_node)
            if dotted in _XML_DECODER_DOTTED:
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
