"""Input validation detection for Go (CWE-20).

SC315 — strconv.Atoi/ParseInt/ParseFloat on request data    medium  CWE-20
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.go._helpers import go_dotted_name
from sanicode.scanner.patterns import Finding

_PARSE_FUNCS = frozenset({
    "strconv.Atoi",
    "strconv.ParseInt",
    "strconv.ParseFloat",
    "strconv.ParseUint",
})

# Keywords indicating the argument originates from external/request input.
_REQUEST_KEYWORDS = frozenset({
    "FormValue", "Query", "Param", "Header", "os.Args", "os.Getenv",
})


class GoInputValidationRule(Rule):
    """Detect strconv parsing of request data without validation."""

    rule_id = "SC315"
    cwe_id = 20
    severity = "medium"
    language = "go"
    message = "Numeric parsing of external input — validate and check error return (CWE-20)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(call_expression) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue
            name = go_dotted_name(func_node)
            if name not in _PARSE_FUNCS:
                continue
            # Only flag when the argument appears to come from request/env data.
            args_text = call_node.text.decode("utf-8") if call_node.text else ""
            if any(kw in args_text for kw in _REQUEST_KEYWORDS):
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
