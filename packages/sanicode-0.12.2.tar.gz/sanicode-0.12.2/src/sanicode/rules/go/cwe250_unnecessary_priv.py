"""Execution with unnecessary privileges for Go (CWE-250).

SC352 — syscall.Setuid/Setgid called with 0 (root)    medium  CWE-250
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.go._helpers import go_call_arguments, go_dotted_name
from sanicode.scanner.patterns import Finding

_PRIV_FUNCTIONS: frozenset[str] = frozenset(
    {"syscall.Setuid", "syscall.Setgid", "syscall.Seteuid", "syscall.Setegid"}
)


class GoUnnecessaryPrivRule(Rule):
    """Detect explicit privilege escalation to root in Go."""

    rule_id = "SC352"
    cwe_id = 250
    severity = "medium"
    language = "go"
    message = (
        "Process privileges escalated to root via syscall.Setuid/Setgid(0) "
        "— unnecessary privilege escalation (CWE-250)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        captures = plugin.captures("(call_expression) @call", tree.root_node)
        for call_node in captures.get("call", []):
            func = call_node.child_by_field_name("function")
            if func is None:
                continue
            name = go_dotted_name(func)
            if name not in _PRIV_FUNCTIONS:
                continue
            args = go_call_arguments(call_node)
            if not args:
                continue
            first = args[0]
            if first.type == "int_literal" and plugin.node_text(first) == "0":
                findings.append(self._make_finding(call_node, plugin, file_path))
        return findings
