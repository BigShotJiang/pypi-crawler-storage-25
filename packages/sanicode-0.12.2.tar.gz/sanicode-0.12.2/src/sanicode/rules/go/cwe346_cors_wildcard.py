"""CORS wildcard origin detection for Go (CWE-346).

SC343 — Access-Control-Allow-Origin set to wildcard *    medium  CWE-346
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.go._helpers import go_call_arguments
from sanicode.scanner.patterns import Finding

_HEADER_NAME = "access-control-allow-origin"
_SET_METHODS = frozenset({"Set", "Add"})


def _string_text(node) -> str:
    """Extract unquoted text from a Go string literal."""
    if node.type not in ("interpreted_string_literal", "raw_string_literal"):
        return ""
    text = node.text.decode("utf-8") if node.text else ""
    # Strip surrounding quotes (double or backtick)
    return text.strip('"`')


class GoCorsWildcardRule(Rule):
    """Detect w.Header().Set('Access-Control-Allow-Origin', '*') in Go."""

    rule_id = "SC343"
    cwe_id = 346
    severity = "medium"
    language = "go"
    message = "Access-Control-Allow-Origin set to wildcard '*' (CWE-346)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(call_expression) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue
            # For w.Header().Set(...), func_node is a selector_expression
            # whose field is "Set" or "Add"
            if func_node.type != "selector_expression":
                continue
            field_node = func_node.child_by_field_name("field")
            if field_node is None:
                continue
            method = field_node.text.decode("utf-8") if field_node.text else ""
            if method not in _SET_METHODS:
                continue
            args = go_call_arguments(call_node)
            if len(args) < 2:
                continue
            header_text = _string_text(args[0])
            if _HEADER_NAME not in header_text.lower():
                continue
            value_text = _string_text(args[1])
            if value_text == "*":
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
