"""PII exposure in log output for Go (CWE-359).

SC351 — Logging call includes PII-named variable    medium  CWE-359
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules._sensitive_patterns import PII_VAR_PATTERN
from sanicode.rules.base import Rule, _walk
from sanicode.rules.go._helpers import go_dotted_name
from sanicode.scanner.patterns import Finding

_LOG_DOTTED: frozenset[str] = frozenset(
    {
        "log.Println",
        "log.Printf",
        "log.Print",
        "log.Fatal",
        "log.Fatalf",
        "log.Fatalln",
        "log.Panic",
        "log.Panicf",
        "log.Panicln",
        "logger.Println",
        "logger.Printf",
        "logger.Info",
        "logger.Debug",
        "logger.Warn",
        "logger.Error",
        "fmt.Println",
        "fmt.Printf",
        "fmt.Fprintf",
    }
)


class GoPiiLoggingRule(Rule):
    """Detect logging calls that include PII-named variable arguments."""

    rule_id = "SC351"
    cwe_id = 359
    severity = "medium"
    language = "go"
    message = (
        "Logging call includes PII-named variable "
        "— may expose personal information in logs (CWE-359)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        captures = plugin.captures("(call_expression) @call", tree.root_node)
        for call_node in captures.get("call", []):
            func = call_node.child_by_field_name("function")
            if func is None:
                continue
            name = go_dotted_name(func)
            if name not in _LOG_DOTTED:
                continue
            if self._has_pii_arg(call_node, plugin):
                findings.append(self._make_finding(call_node, plugin, file_path))
        return findings

    @staticmethod
    def _has_pii_arg(call_node, plugin) -> bool:
        args = call_node.child_by_field_name("arguments")
        if args is None:
            return False
        for child in _walk(args):
            if child.type == "identifier":
                name = plugin.node_text(child)
                if PII_VAR_PATTERN.search(name):
                    return True
        return False
