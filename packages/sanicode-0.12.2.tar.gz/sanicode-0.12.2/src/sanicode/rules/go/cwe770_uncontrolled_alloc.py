"""CWE-770 uncontrolled resource allocation for Go.

SC337 — make() with non-literal size    medium  CWE-770
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.go._helpers import go_call_arguments, go_dotted_name
from sanicode.scanner.patterns import Finding

_LITERAL_TYPES = frozenset({"int_literal", "float_literal"})


class GoUncontrolledAllocRule(Rule):
    """Flag make() calls with dynamic (non-literal) size arguments."""

    rule_id = "SC337"
    cwe_id = 770
    severity = "medium"
    language = "go"
    message = (
        "make() called with a non-literal size — "
        "an attacker-controlled value can cause excessive memory allocation (CWE-770)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []

        for node in plugin.captures(
            "(call_expression) @call", tree.root_node
        ).get("call", []):
            func = node.child_by_field_name("function")
            if func is None:
                continue
            if go_dotted_name(func) != "make":
                continue
            args = go_call_arguments(node)
            # make(type) — no size argument; make(type, size) or make(type, size, cap)
            if len(args) < 2:
                continue
            size_arg = args[1]
            if size_arg.type not in _LITERAL_TYPES:
                findings.append(self._make_finding(node, plugin, file_path))

        return findings
