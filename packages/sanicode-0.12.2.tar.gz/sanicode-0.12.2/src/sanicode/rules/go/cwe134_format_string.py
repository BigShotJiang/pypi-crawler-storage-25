"""CWE-134 format string vulnerability for Go.

SC338 — fmt format functions with non-literal format string    high  CWE-134
"""
from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.go._helpers import go_call_arguments, go_dotted_name
from sanicode.scanner.patterns import Finding

_GO_STRING_LITERALS = frozenset({"raw_string_literal", "interpreted_string_literal"})

# Map of fmt function name → index of the format string argument.
_FMT_FORMAT_ARG_INDEX: dict[str, int] = {
    "fmt.Sprintf": 0,
    "fmt.Printf": 0,
    "fmt.Errorf": 0,
    "fmt.Sscanf": 1,
    "fmt.Fprintf": 1,
    "fmt.Fscanf": 1,
}


class GoFormatStringRule(Rule):
    """Flag fmt format functions with non-literal format string."""

    rule_id = "SC338"
    cwe_id = 134
    severity = "high"
    language = "go"
    message = (
        "fmt format function called with a non-literal format string — "
        "an attacker-controlled format string can leak data or crash the program (CWE-134)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.captures("(call_expression) @call", tree.root_node).get("call", []):
            func = node.child_by_field_name("function")
            if func is None:
                continue
            name = go_dotted_name(func)
            if name not in _FMT_FORMAT_ARG_INDEX:
                continue
            fmt_idx = _FMT_FORMAT_ARG_INDEX[name]
            args = go_call_arguments(node)
            if len(args) <= fmt_idx:
                continue
            fmt_arg = args[fmt_idx]
            if fmt_arg.type not in _GO_STRING_LITERALS:
                findings.append(self._make_finding(node, plugin, file_path))
        return findings
