"""TLS misconfiguration detection for Go (CWE-326).

SC362 — Weak TLS version or cipher suite in tls.Config    high  CWE-326
"""
from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule, _walk
from sanicode.rules.go._helpers import go_dotted_name
from sanicode.scanner.patterns import Finding

# Weak TLS version constants (anything below TLS 1.2).
_WEAK_TLS_VERSIONS = frozenset({
    "tls.VersionTLS10",
    "tls.VersionTLS11",
    "tls.VersionSSL30",
})

# Weak cipher suite identifiers.
_WEAK_CIPHER_SUITES = frozenset({
    "tls.TLS_RSA_WITH_RC4_128_SHA",
    "tls.TLS_RSA_WITH_3DES_EDE_CBC_SHA",
    "tls.TLS_RSA_WITH_AES_128_CBC_SHA",
    "tls.TLS_ECDHE_RSA_WITH_RC4_128_SHA",
    "tls.TLS_ECDHE_ECDSA_WITH_RC4_128_SHA",
})


class GoTLSConfigRule(Rule):
    """Detect weak TLS version or cipher suite configuration in Go.

    Detects:
    - ``tls.VersionTLS10``, ``tls.VersionTLS11``, ``tls.VersionSSL30`` used
      as MinVersion in tls.Config
    - Known-weak cipher suite constants in CipherSuites arrays
    """

    rule_id = "SC362"
    cwe_id = 326
    severity = "high"
    language = "go"
    message = "Weak TLS version or cipher suite configuration (CWE-326)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []

        for node in _walk(tree.root_node):
            if node.type != "selector_expression":
                continue
            dotted = go_dotted_name(node)
            if dotted in _WEAK_TLS_VERSIONS or dotted in _WEAK_CIPHER_SUITES:
                findings.append(self._make_finding(node, plugin, file_path))

        return findings
