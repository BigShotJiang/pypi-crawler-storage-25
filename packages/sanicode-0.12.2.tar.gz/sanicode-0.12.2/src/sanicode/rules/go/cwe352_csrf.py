"""CSRF protection bypass detection for Go (CWE-352).

SC313 — nosurf.Exempt* / CSRF bypass    medium  CWE-352
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.go._helpers import go_dotted_name
from sanicode.scanner.patterns import Finding

_CSRF_EXEMPT_FUNCS = frozenset({
    "nosurf.ExemptFunc",
    "nosurf.ExemptPath",
    "nosurf.ExemptGlob",
    "nosurf.ExemptRegexp",
})


class GoCsrfExemptRule(Rule):
    """Detect CSRF exemption patterns in Go web applications."""

    rule_id = "SC313"
    cwe_id = 352
    severity = "medium"
    language = "go"
    message = "CSRF protection exempted — potential CSRF vulnerability (CWE-352)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(call_expression) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue
            name = go_dotted_name(func_node)
            if name in _CSRF_EXEMPT_FUNCS:
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
