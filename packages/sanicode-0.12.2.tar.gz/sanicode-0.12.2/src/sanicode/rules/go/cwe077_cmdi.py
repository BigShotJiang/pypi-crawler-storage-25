"""Template injection detection for Go (CWE-77).

SC318 — template.Parse() with non-literal argument.

Go's text/template and html/template packages execute arbitrary logic
when Parse() receives untrusted input, enabling template injection.
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.go._helpers import go_call_arguments
from sanicode.scanner.patterns import Finding


class GoTemplateInjectionRule(Rule):
    """Detect template.Parse() with non-literal argument — template injection."""

    rule_id = "SC318"
    cwe_id = 77
    severity = "high"
    language = "go"
    message = "Template parsed from non-literal string — template injection risk (CWE-77)"

    _PARSE_METHODS = frozenset({"Parse"})

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        captures = plugin.captures("(call_expression) @call", tree.root_node)

        for call_node in captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None or func_node.type != "selector_expression":
                continue

            field = func_node.child_by_field_name("field")
            if not field or not field.text:
                continue

            method = field.text.decode("utf-8")
            if method not in self._PARSE_METHODS:
                continue

            args = go_call_arguments(call_node)
            if not args:
                continue

            first = args[0]
            # Safe: string literals (raw_string_literal, interpreted_string_literal)
            if first.type in ("raw_string_literal", "interpreted_string_literal"):
                continue

            findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
