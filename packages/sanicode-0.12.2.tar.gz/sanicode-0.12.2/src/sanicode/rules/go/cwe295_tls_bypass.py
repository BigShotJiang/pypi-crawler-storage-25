"""TLS certificate verification bypass detection for Go (CWE-295).

SC363 — InsecureSkipVerify: true in tls.Config    high  CWE-295
"""
from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule, _walk
from sanicode.scanner.patterns import Finding


class GoTLSBypassRule(Rule):
    """Detect ``InsecureSkipVerify: true`` in Go tls.Config.

    This completely disables TLS certificate verification,
    making the connection vulnerable to MITM attacks.
    """

    rule_id = "SC363"
    cwe_id = 295
    severity = "high"
    language = "go"
    message = "TLS certificate verification disabled — InsecureSkipVerify: true (CWE-295)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []

        for node in _walk(tree.root_node):
            # Go struct field: InsecureSkipVerify: true
            # In tree-sitter-go this is a keyed_element inside a literal_value
            if node.type == "keyed_element":
                children = node.named_children
                if len(children) >= 2:
                    key = children[0]
                    value = children[1]
                    key_text = key.text.decode("utf-8") if key.text else ""
                    value_text = value.text.decode("utf-8") if value.text else ""
                    if key_text == "InsecureSkipVerify" and value_text == "true":
                        findings.append(self._make_finding(node, plugin, file_path))

        return findings
