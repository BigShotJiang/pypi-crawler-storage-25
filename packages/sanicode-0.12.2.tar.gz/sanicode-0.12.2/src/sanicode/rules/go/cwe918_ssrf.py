"""HTTP requests with non-literal URL (CWE-918).

SC312 — HTTP request with non-literal URL — potential SSRF    high  CWE-918
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.go._helpers import go_call_arguments, go_dotted_name
from sanicode.scanner.patterns import Finding

_HTTP_FUNCS = frozenset({
    "http.Get", "http.Post", "http.Head", "http.NewRequest",
})

_GO_STRING_TYPES = frozenset({"interpreted_string_literal", "raw_string_literal"})


class GoSsrfRule(Rule):
    """Detect net/http calls where the URL argument is not a string literal."""

    rule_id = "SC312"
    cwe_id = 918
    severity = "high"
    language = "go"
    message = "HTTP request with non-literal URL — potential SSRF (CWE-918)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(call_expression) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue
            if go_dotted_name(func_node) not in _HTTP_FUNCS:
                continue
            args = go_call_arguments(call_node)
            if not args:
                continue
            # For http.NewRequest the URL is the second argument (index 1);
            # for Get/Post/Head it is the first (index 0).
            url_arg_index = 1 if go_dotted_name(func_node) == "http.NewRequest" else 0
            if url_arg_index >= len(args):
                continue
            if args[url_arg_index].type not in _GO_STRING_TYPES:
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
