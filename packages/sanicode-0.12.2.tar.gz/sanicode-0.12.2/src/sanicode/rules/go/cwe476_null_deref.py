"""NULL pointer dereference detection for Go (CWE-476).

SC317 — Chained member/method access on function return without nil check    high  CWE-476
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.scanner.patterns import Finding

# Functions whose return values are commonly nil-checked in Go.
# Excludes Exec (returns (Result, error), not a nullable pointer).
_NULLABLE_FUNCS = frozenset({
    "QueryRow", "Query",
    "Open", "Create", "Dial",
    "Get", "Lookup", "Find",
})


class GoNullDerefRule(Rule):
    """Detect chained member/method access on call return without nil check."""

    rule_id = "SC317"
    cwe_id = 476
    severity = "high"
    language = "go"
    message = (
        "Chained member/method access on function return value — "
        "nil pointer dereference risk (CWE-476)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        # Find selector_expression nodes (field/method access like x.Y)
        sel_captures = plugin.captures(
            "(selector_expression) @sel", root
        )
        for sel_node in sel_captures.get("sel", []):
            # The operand is the first child of a selector_expression
            operand = sel_node.child_by_field_name("operand")
            if operand is None:
                continue
            # Flag when the operand is a call_expression (chained access)
            if operand.type == "call_expression":
                # Extract the function name from the call
                func_node = operand.child_by_field_name("function")
                if func_node is None:
                    continue
                func_text = func_node.text.decode("utf-8") if func_node.text else ""
                # Get the last segment of dotted name (e.g., "db.QueryRow" -> "QueryRow")
                func_name = func_text.rsplit(".", 1)[-1] if func_text else ""
                if func_name in _NULLABLE_FUNCS:
                    findings.append(self._make_finding(sel_node, plugin, file_path))

        return findings
