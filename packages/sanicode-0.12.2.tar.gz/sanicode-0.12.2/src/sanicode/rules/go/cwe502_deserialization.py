"""Deserialization detection rules for Go (CWE-502).

SC308 — encoding/gob with interface{} — insecure deserialization    high  CWE-502
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.go._helpers import go_dotted_name
from sanicode.scanner.patterns import Finding


class GoGobDecoderRule(Rule):
    """Detect gob.NewDecoder() — insecure deserialization risk with interface{}."""

    rule_id = "SC308"
    cwe_id = 502
    severity = "high"
    language = "go"
    message = "Use of gob.NewDecoder — insecure deserialization risk (CWE-502)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(call_expression) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue
            if go_dotted_name(func_node) == "gob.NewDecoder":
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
