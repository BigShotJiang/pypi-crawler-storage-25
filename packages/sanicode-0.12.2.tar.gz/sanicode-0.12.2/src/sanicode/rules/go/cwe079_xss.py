"""Cross-site scripting detection rules for Go (CWE-79).

SC304 — text/template instead of html/template    high  CWE-79
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule, _walk
from sanicode.scanner.patterns import Finding


class GoTextTemplateRule(Rule):
    """Detect import of text/template where html/template should be used.

    Using text/template for HTML output disables auto-escaping, creating XSS risk.
    """

    rule_id = "SC304"
    cwe_id = 79
    severity = "high"
    language = "go"
    message = "Import of text/template — use html/template for auto-escaping (CWE-79)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []

        for node in _walk(tree.root_node):
            if node.type == "import_spec":
                path_node = node.child_by_field_name("path")
                if path_node and path_node.text:
                    path_text = path_node.text.decode("utf-8").strip('"').strip('`')
                    if path_text == "text/template":
                        findings.append(self._make_finding(node, plugin, file_path))

        return findings
