"""Sensitive data storage detection rules for Go (CWE-916, CWE-522, CWE-312).

SC329 — Weak hash on password-named variable          high    CWE-916
SC330 — Secret variable written to file/database      medium  CWE-522
SC331 — Sensitive data written to persistent storage   medium  CWE-312
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules._sensitive_patterns import SECRET_VAR_PATTERN
from sanicode.rules.base import Rule, _walk
from sanicode.rules.go._helpers import go_call_arguments, go_dotted_name
from sanicode.scanner.patterns import Finding

# Weak hash function calls
_WEAK_HASH_FUNCS: frozenset[str] = frozenset(
    {
        "md5.Sum",
        "md5.New",
        "sha1.Sum",
        "sha1.New",
    }
)

# File write calls for CWE-522
_FILE_WRITE_FUNCS: frozenset[str] = frozenset(
    {
        "os.WriteFile",
        "ioutil.WriteFile",
    }
)

_DB_FUNCS: frozenset[str] = frozenset(
    {
        "db.Exec",
        "db.Query",
        "db.QueryRow",
        "tx.Exec",
        "stmt.Exec",
    }
)

_WRITE_METHODS: frozenset[str] = frozenset({"Write", "WriteString"})

# Serialization calls for CWE-312
_SERIALIZE_FUNCS: frozenset[str] = frozenset(
    {
        "json.Marshal",
        "json.NewEncoder",
        "yaml.Marshal",
    }
)


def _has_secret_identifier(node, plugin) -> bool:
    """Walk all descendants for an identifier matching SECRET_VAR_PATTERN."""
    for child in _walk(node):
        if child.type == "identifier":
            name = plugin.node_text(child)
            if SECRET_VAR_PATTERN.search(name):
                return True
    return False


class GoWeakPasswordHashRule(Rule):
    """Detect md5.Sum/sha1.Sum with password-named variables."""

    rule_id = "SC329"
    cwe_id = 916
    severity = "high"
    language = "go"
    message = (
        "Weak hash used on password-named variable "
        "\u2014 use bcrypt/scrypt/argon2 (CWE-916)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        captures = plugin.captures("(call_expression) @call", tree.root_node)

        for call_node in captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue

            dotted = go_dotted_name(func_node)

            if dotted in _WEAK_HASH_FUNCS:
                _args = go_call_arguments(call_node)
                args_node = call_node.child_by_field_name("arguments")
                if args_node and _has_secret_identifier(args_node, plugin):
                    findings.append(self._make_finding(call_node, plugin, file_path))

        return findings


class GoUnprotectedPasswordStorageRule(Rule):
    """Detect file writes or DB operations storing secret-named variables."""

    rule_id = "SC330"
    cwe_id = 522
    severity = "medium"
    language = "go"
    message = (
        "Secret-named variable written to file or database "
        "without hashing (CWE-522)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        captures = plugin.captures("(call_expression) @call", tree.root_node)

        for call_node in captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue

            dotted = go_dotted_name(func_node)

            if dotted in _FILE_WRITE_FUNCS or dotted in _DB_FUNCS:
                args_node = call_node.child_by_field_name("arguments")
                if args_node and _has_secret_identifier(args_node, plugin):
                    findings.append(self._make_finding(call_node, plugin, file_path))
                continue

            # method.Write(password) / method.WriteString(secret)
            if func_node.type == "selector_expression":
                field = func_node.child_by_field_name("field")
                if field and field.text:
                    method = field.text.decode("utf-8")
                    if method in _WRITE_METHODS:
                        args_node = call_node.child_by_field_name("arguments")
                        if args_node and _has_secret_identifier(args_node, plugin):
                            findings.append(
                                self._make_finding(call_node, plugin, file_path)
                            )

        return findings


class GoCleartextSecretStorageRule(Rule):
    """Detect sensitive data written to persistent storage in cleartext."""

    rule_id = "SC331"
    cwe_id = 312
    severity = "medium"
    language = "go"
    message = (
        "Sensitive data written to persistent storage "
        "in cleartext (CWE-312)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        captures = plugin.captures("(call_expression) @call", tree.root_node)

        for call_node in captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue

            dotted = go_dotted_name(func_node)

            if dotted in _SERIALIZE_FUNCS:
                args_node = call_node.child_by_field_name("arguments")
                if args_node and _has_secret_identifier(args_node, plugin):
                    findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
