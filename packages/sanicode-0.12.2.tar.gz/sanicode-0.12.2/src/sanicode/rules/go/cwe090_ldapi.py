"""LDAP injection detection for Go (CWE-90).

SC319 — LDAP search with string concatenation/fmt in filter argument.

The go-ldap library's NewSearchRequest takes a filter string that, when
built via concatenation or fmt.Sprintf with untrusted input, enables
LDAP injection attacks.
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.go._helpers import go_call_arguments, go_is_string_concat_or_fmt
from sanicode.scanner.patterns import Finding


class GoLdapInjectionRule(Rule):
    """Detect LDAP search with string concatenation in filter — LDAP injection."""

    rule_id = "SC319"
    cwe_id = 90
    severity = "high"
    language = "go"
    message = "LDAP filter built from string concatenation — LDAP injection risk (CWE-90)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        captures = plugin.captures("(call_expression) @call", tree.root_node)

        for call_node in captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None or func_node.type != "selector_expression":
                continue

            field = func_node.child_by_field_name("field")
            if not field or not field.text:
                continue

            method = field.text.decode("utf-8")
            # go-ldap uses NewSearchRequest; standard LDAP libs use Search
            if method not in ("NewSearchRequest", "Search"):
                continue

            args = go_call_arguments(call_node)
            # NewSearchRequest(BaseDN, Scope, DerefAliases, SizeLimit,
            #                  TimeLimit, TypesOnly, Filter, ...)
            # Filter is at index 6 for NewSearchRequest.
            # For Search, filter could be at different positions; check all args.
            for arg in args:
                if go_is_string_concat_or_fmt(arg):
                    findings.append(self._make_finding(call_node, plugin, file_path))
                    break

        return findings
