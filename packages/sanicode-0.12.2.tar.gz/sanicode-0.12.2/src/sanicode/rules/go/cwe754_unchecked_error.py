"""Unchecked error detection rules for Go (CWE-754).

SC307 — error value assigned to blank identifier _    medium  CWE-754
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule, _walk
from sanicode.scanner.patterns import Finding


class GoUncheckedErrorRule(Rule):
    """Detect error values assigned to blank identifier _ — unchecked error."""

    rule_id = "SC307"
    cwe_id = 754
    severity = "medium"
    language = "go"
    message = "Error assigned to _ — unchecked error return value (CWE-754)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []

        for node in _walk(tree.root_node):
            if node.type != "short_var_declaration":
                continue

            left = node.child_by_field_name("left")
            right = node.child_by_field_name("right")
            if left is None or right is None:
                continue

            # Look for patterns like: result, _ := someFunc()
            # The left side is an expression_list
            identifiers = [
                c for c in left.children
                if c.type == "identifier" and c.text
            ]

            # Check if the last identifier is _ (error is conventionally last)
            if identifiers and identifiers[-1].text == b"_":
                # Verify the right side involves a function call
                for rchild in _walk(right):
                    if rchild.type == "call_expression":
                        findings.append(self._make_finding(node, plugin, file_path))
                        break

        return findings
