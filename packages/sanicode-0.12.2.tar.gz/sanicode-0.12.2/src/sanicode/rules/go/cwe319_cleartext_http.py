"""Cleartext HTTP transmission detection (CWE-319).

SC342 — HTTP request using cleartext http:// URL    medium  CWE-319
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.go._helpers import go_call_arguments, go_dotted_name
from sanicode.scanner.patterns import Finding

_HTTP_FUNCS = frozenset({"http.Get", "http.Post", "http.Head", "http.NewRequest"})

_GO_STRING_TYPES = frozenset({"interpreted_string_literal", "raw_string_literal"})

_LOOPBACK_PREFIXES = (
    "http://localhost",
    "http://127.",
    "http://0.0.0.0",
    "http://[::1]",
)


def _extract_go_string(node) -> str:
    """Extract the raw string content from a Go string literal node."""
    if node.text is None:
        return ""
    text = node.text.decode("utf-8")
    # interpreted_string_literal is wrapped in double quotes
    # raw_string_literal is wrapped in backticks
    if text.startswith('"') and text.endswith('"'):
        return text[1:-1]
    if text.startswith("`") and text.endswith("`"):
        return text[1:-1]
    return text


def _is_cleartext_http_go(node) -> bool:
    """Return True if a Go string literal contains a non-loopback http:// URL."""
    if node.type not in _GO_STRING_TYPES:
        return False
    inner = _extract_go_string(node)
    lower = inner.lower()
    if not lower.startswith("http://"):
        return False
    for prefix in _LOOPBACK_PREFIXES:
        if lower.startswith(prefix):
            return False
    return True


class GoCleartextHttpRule(Rule):
    """Detect net/http calls using a hardcoded cleartext http:// URL.

    Unlike SSRF (CWE-918) which flags non-literal URLs, this rule flags
    literal URLs that use http:// instead of https://, indicating traffic
    is sent in cleartext over the network.
    """

    rule_id = "SC342"
    cwe_id = 319
    severity = "medium"
    language = "go"
    message = "HTTP request uses cleartext http:// URL — use https:// (CWE-319)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(call_expression) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue
            func_name = go_dotted_name(func_node)
            if func_name not in _HTTP_FUNCS:
                continue
            args = go_call_arguments(call_node)
            if not args:
                continue
            # For http.NewRequest the URL is the second argument (index 1);
            # for Get/Post/Head it is the first (index 0).
            url_idx = 1 if func_name == "http.NewRequest" else 0
            if url_idx >= len(args):
                continue
            if _is_cleartext_http_go(args[url_idx]):
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
