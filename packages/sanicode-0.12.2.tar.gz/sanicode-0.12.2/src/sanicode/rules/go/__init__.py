"""Go-specific pattern detection rules."""
