"""Indirect command injection via environment variables for Go (CWE-78).

SC364 — os.Getenv() value used in exec.Command() or exec.CommandContext().

Detects patterns where os.Getenv() flows into exec.Command() or
exec.CommandContext() within the same call expression.
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule, _walk
from sanicode.rules.go._helpers import go_dotted_name
from sanicode.scanner.patterns import Finding

_EXEC_SINKS = frozenset({"exec.Command", "exec.CommandContext"})


def _subtree_has_getenv(node) -> bool:
    """Check if any node in the subtree is an os.Getenv() call."""
    for n in _walk(node):
        if n.type == "call_expression":
            func = n.child_by_field_name("function")
            if func is not None and go_dotted_name(func) == "os.Getenv":
                return True
    return False


class GoEnvCommandInjectionRule(Rule):
    """Detect os.Getenv() values used in exec.Command() calls."""

    rule_id = "SC364"
    cwe_id = 78
    severity = "medium"
    language = "go"
    message = (
        "os.Getenv() used in exec.Command — "
        "indirect command injection risk (CWE-78)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(call_expression) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue

            if go_dotted_name(func_node) in _EXEC_SINKS:
                if _subtree_has_getenv(call_node):
                    findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
