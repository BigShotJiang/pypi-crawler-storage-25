"""Code injection detection rules for Go (CWE-94).

SC306 — reflect.Value.Call — dynamic function invocation    high  CWE-94
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.scanner.patterns import Finding


class GoReflectCallRule(Rule):
    """Detect reflect.Value.Call() — dynamic function invocation risk."""

    rule_id = "SC306"
    cwe_id = 94
    severity = "high"
    language = "go"
    message = "Use of reflect.Value.Call — dynamic function invocation risk (CWE-94)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(call_expression) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None or func_node.type != "selector_expression":
                continue

            field = func_node.child_by_field_name("field")
            if not field or not field.text:
                continue

            method = field.text.decode("utf-8")
            if method != "Call":
                continue

            # Only flag when the receiver name clearly indicates reflect usage.
            # Avoids false positives on generic "value.Call()" patterns.
            operand = func_node.child_by_field_name("operand")
            if operand and operand.text:
                op_text = operand.text.decode("utf-8")
                if "reflect" in op_text or "reflect" in op_text.lower():
                    findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
