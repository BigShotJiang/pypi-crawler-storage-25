"""Weak cryptography detection rules for Go (CWE-327).

SC311 — crypto/md5 or crypto/sha1 import / md5.New()/sha1.New() call    medium  CWE-327
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule, _walk
from sanicode.rules.go._helpers import go_dotted_name
from sanicode.scanner.patterns import Finding

_WEAK_IMPORTS = frozenset({"crypto/md5", "crypto/sha1"})
_WEAK_CALLS = frozenset({"md5.New", "sha1.New", "md5.Sum", "sha1.Sum"})


class GoWeakCryptoRule(Rule):
    """Detect import of crypto/md5 or crypto/sha1, or calls to md5.New()/sha1.New()."""

    rule_id = "SC311"
    cwe_id = 327
    severity = "medium"
    language = "go"
    message = "Use of weak hash algorithm (MD5/SHA1) — use crypto/sha256 or stronger (CWE-327)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []

        for node in _walk(tree.root_node):
            # Import-based detection
            if node.type == "import_spec":
                path_node = node.child_by_field_name("path")
                if path_node and path_node.text:
                    path_text = path_node.text.decode("utf-8").strip('"').strip('`')
                    if path_text in _WEAK_IMPORTS:
                        findings.append(self._make_finding(node, plugin, file_path))
                continue

            # Call-based detection
            if node.type == "call_expression":
                func_node = node.child_by_field_name("function")
                if func_node is None:
                    continue
                dotted = go_dotted_name(func_node)
                if dotted in _WEAK_CALLS:
                    findings.append(self._make_finding(node, plugin, file_path))

        return findings
