"""CWE-242 dangerous function usage for Go.

SC339 — unsafe.Pointer usage    high  CWE-242
"""
from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.go._helpers import go_dotted_name
from sanicode.scanner.patterns import Finding


class GoUnsafePointerRule(Rule):
    """Flag unsafe.Pointer usage — bypasses Go type safety."""

    rule_id = "SC339"
    cwe_id = 242
    severity = "high"
    language = "go"
    message = (
        "unsafe.Pointer usage bypasses Go's type safety — "
        "review for memory safety issues (CWE-242)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []

        # Detect unsafe.Pointer(x) via call_expression — report here.
        call_nodes = plugin.captures("(call_expression) @call", tree.root_node).get("call", [])
        reported_starts: set[tuple[int, int]] = set()
        for node in call_nodes:
            func = node.child_by_field_name("function")
            if func is None:
                continue
            name = go_dotted_name(func)
            if name == "unsafe.Pointer":
                findings.append(self._make_finding(node, plugin, file_path))
                # Track the selector inside so we don't double-report it.
                reported_starts.add((func.start_byte, func.end_byte))

        # Detect bare unsafe.Pointer usage in selector_expression context
        # (e.g. as a type in a cast, not as a call).  Skip if it was already
        # captured as the function child of a call_expression above.
        for node in plugin.captures("(selector_expression) @sel", tree.root_node).get("sel", []):
            name = go_dotted_name(node)
            if name != "unsafe.Pointer":
                continue
            # Skip if this selector is the function part of a call_expression
            # (already reported above).
            if (node.start_byte, node.end_byte) in reported_starts:
                continue
            # Also skip if parent is a call_expression (same guard, belt-and-braces).
            parent = node.parent
            if parent is not None and parent.type == "call_expression":
                func_child = parent.child_by_field_name("function")
                if func_child is not None and func_child.start_byte == node.start_byte:
                    continue
            findings.append(self._make_finding(node, plugin, file_path))

        return findings
