"""Weak cipher detection rules for Go (CWE-328).

SC341 — crypto/des or crypto/rc4 import / des.NewCipher()/rc4.NewCipher() call    medium  CWE-328
"""
from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule, _walk
from sanicode.rules.go._helpers import go_dotted_name
from sanicode.scanner.patterns import Finding

_WEAK_IMPORTS = frozenset({"crypto/des", "crypto/rc4"})
_WEAK_CALLS = frozenset({
    "des.NewCipher", "des.NewTripleDESCipher",
    "rc4.NewCipher",
})


class GoWeakCipherRule(Rule):
    """Detect import of crypto/des or crypto/rc4, or calls to des.NewCipher()/rc4.NewCipher()."""

    rule_id = "SC341"
    cwe_id = 328
    severity = "medium"
    language = "go"
    message = "Use of weak cipher (DES/RC4) — use crypto/aes instead (CWE-328)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []

        for node in _walk(tree.root_node):
            # Import-based detection
            if node.type == "import_spec":
                path_node = node.child_by_field_name("path")
                if path_node and path_node.text:
                    path_text = path_node.text.decode("utf-8").strip('"').strip('`')
                    if path_text in _WEAK_IMPORTS:
                        findings.append(self._make_finding(node, plugin, file_path))
                continue

            # Call-based detection
            if node.type == "call_expression":
                func_node = node.child_by_field_name("function")
                if func_node is None:
                    continue
                dotted = go_dotted_name(func_node)
                if dotted in _WEAK_CALLS:
                    findings.append(self._make_finding(node, plugin, file_path))

        return findings
