"""Public cloud storage resource exposure detection for Go (CWE-668).

SC354 — Cloud storage API call sets public ACL on bucket/object  medium  CWE-668

Detection strategy (two complementary patterns):

1. ``composite_literal`` with a ``keyed_element`` whose key is ``ACL`` and
   value is a public ACL string — covers struct-literal patterns like
   ``s3.PutObjectInput{ACL: "public-read"}``.

2. ``call_expression`` whose function name contains a cloud/storage hint
   *and* has a string literal argument matching a public ACL value — covers
   positional API calls like ``svc.PutObjectAcl("public-read")``.

The function-name hint guard on pattern 2 prevents false positives from
unrelated calls such as ``log.Println("public-read")``.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from tree_sitter import Node, Tree

from sanicode.rules.base import Rule, _walk
from sanicode.rules.go._helpers import go_call_arguments, go_dotted_name
from sanicode.scanner.patterns import Finding

if TYPE_CHECKING:
    from sanicode.scanner.languages.base import TreeSitterPlugin

_PUBLIC_ACLS: frozenset[str] = frozenset({"public-read", "public-read-write"})

# Case-insensitive substrings that indicate a cloud storage function.
_STORAGE_HINTS: tuple[str, ...] = (
    "acl", "bucket", "putobject", "createbucket", "upload", "s3", "storage",
)


def _node_text(node: Node) -> str:
    return node.text.decode("utf-8") if node.text else ""


def _strip_go_string(s: str) -> str:
    if s.startswith('"') and s.endswith('"') and len(s) >= 2:
        return s[1:-1]
    return s


def _is_storage_call(func_node: Node) -> bool:
    """Return True if the function name suggests a cloud storage operation."""
    name = go_dotted_name(func_node).lower()
    return any(hint in name for hint in _STORAGE_HINTS)


def _keyed_element_has_public_acl(node: Node) -> bool:
    """Return True if a ``keyed_element`` has key ``ACL`` with a public value."""
    children = node.children
    if len(children) < 3:
        return False
    # keyed_element: literal_element ":" literal_element
    key_elem = children[0]
    value_elem = children[-1]
    # Key must be the identifier ACL
    key_text = _node_text(key_elem).strip()
    if key_text != "ACL":
        return False
    # Value must be (or contain) a public ACL string literal
    for descendant in _walk(value_elem):
        if descendant.type == "interpreted_string_literal":
            if _strip_go_string(_node_text(descendant)) in _PUBLIC_ACLS:
                return True
    return False


class GoPublicResourceRule(Rule):
    """Detect cloud storage calls that set a public ACL (CWE-668)."""

    rule_id = "SC354"
    cwe_id = 668
    severity = "medium"
    language = "go"
    message = (
        "Public ACL on cloud storage resource "
        "\u2014 review access control (CWE-668)"
    )
    tags = ["cloud", "access_control"]
    domain = "access_control"
    action = "review"

    def check(self, tree: Tree, file_path: Path, plugin: TreeSitterPlugin) -> list[Finding]:
        findings: list[Finding] = []

        for node in _walk(tree.root_node):
            # Pattern 1: struct literal with ACL key.
            if node.type == "keyed_element":
                if _keyed_element_has_public_acl(node):
                    findings.append(self._make_finding(node, plugin, file_path))
                continue

            # Pattern 2: call_expression with storage-hint function name and
            # a public ACL string literal argument.
            if node.type != "call_expression":
                continue
            func = node.child_by_field_name("function")
            if func is None or not _is_storage_call(func):
                continue
            for arg in go_call_arguments(node):
                if arg.type == "interpreted_string_literal":
                    if _strip_go_string(_node_text(arg)) in _PUBLIC_ACLS:
                        findings.append(self._make_finding(node, plugin, file_path))
                        break

        return findings
