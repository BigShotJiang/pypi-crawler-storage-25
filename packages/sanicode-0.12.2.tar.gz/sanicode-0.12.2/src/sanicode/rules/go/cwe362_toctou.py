"""Filesystem TOCTOU race condition detection for Go (CWE-362).

SC348 — os.Stat / os.Lstat    medium  CWE-362
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.go._helpers import go_dotted_name
from sanicode.scanner.patterns import Finding

_TOCTOU_FUNCS = frozenset({"os.Stat", "os.Lstat"})


class GoTOCTOUCheck(Rule):
    """Detect TOCTOU race conditions via os.Stat/os.Lstat check-then-act patterns.

    Calling os.Stat() or os.Lstat() to check whether a file exists before
    acting on it is inherently racy.  The filesystem state can change between
    the check and the subsequent operation.  Prefer opening the file directly
    and handling the resulting error.
    """

    rule_id = "SC348"
    cwe_id = 362
    severity = "medium"
    language = "go"
    message = (
        "Filesystem TOCTOU race — check-then-act on os.Stat/os.Lstat "
        "is inherently racy; open the file directly and handle errors (CWE-362)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for call_node in plugin.captures("(call_expression) @call", tree.root_node).get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue
            if go_dotted_name(func_node) in _TOCTOU_FUNCS:
                findings.append(self._make_finding(call_node, plugin, file_path))
        return findings
