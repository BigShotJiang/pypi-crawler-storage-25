"""Insecure random number generation detection for Go (CWE-330).

SC335 — Use of math/rand — not cryptographically secure    medium  CWE-330
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.go._helpers import go_dotted_name
from sanicode.scanner.patterns import Finding

_RAND_TARGETS = frozenset({
    "rand.Intn", "rand.Int", "rand.Float64", "rand.Float32",
    "rand.Int63", "rand.Int63n", "rand.Int31", "rand.Int31n",
    "rand.Seed", "rand.New", "rand.NewSource",
    "rand.Perm", "rand.Shuffle",
})


class GoInsecureRandomRule(Rule):
    """Detect math/rand function calls — not cryptographically secure."""

    rule_id = "SC335"
    cwe_id = 330
    severity = "medium"
    language = "go"
    message = (
        "Use of math/rand — not cryptographically secure, "
        "use crypto/rand instead (CWE-330)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(call_expression) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue
            dotted = go_dotted_name(func_node)
            if dotted in _RAND_TARGETS:
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
