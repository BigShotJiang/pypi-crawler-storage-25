"""Buffer restriction violation via unsafe.Slice() for Go (CWE-119).

SC346 — unsafe.Slice / unsafe.SliceData    high  CWE-119

Detects calls to ``unsafe.Slice`` and ``unsafe.SliceData`` which create
slices from arbitrary pointers, bypassing Go's memory safety guarantees.
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.go._helpers import go_dotted_name
from sanicode.scanner.patterns import Finding

_UNSAFE_SLICE_FUNCS = frozenset({
    "unsafe.Slice",
    "unsafe.SliceData",
})


class GoUnsafeSliceRule(Rule):
    """Detect unsafe.Slice() — creates slice from arbitrary pointer (CWE-119)."""

    rule_id = "SC346"
    cwe_id = 119
    severity = "high"
    language = "go"
    message = "Use of unsafe.Slice() — creates slice from arbitrary pointer (CWE-119)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(call_expression) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue
            if go_dotted_name(func_node) in _UNSAFE_SLICE_FUNCS:
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
