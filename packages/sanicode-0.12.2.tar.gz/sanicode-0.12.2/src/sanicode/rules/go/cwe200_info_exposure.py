"""Information exposure detection for Go (CWE-200).

SC320 — http.Error() with dynamic error message   medium  CWE-200
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.go._helpers import go_call_arguments, go_dotted_name
from sanicode.scanner.patterns import Finding

_SAFE_STRING_TYPES = frozenset({"interpreted_string_literal", "raw_string_literal"})


class GoInfoExposureRule(Rule):
    """Detect http.Error() with dynamic message — leaks error details to client."""

    rule_id = "SC320"
    cwe_id = 200
    severity = "medium"
    language = "go"
    message = (
        "http.Error() with dynamic error message — "
        "exposes internal error details to client (CWE-200)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        captures = plugin.captures("(call_expression) @call", tree.root_node)

        for call_node in captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue
            if go_dotted_name(func_node) != "http.Error":
                continue

            args = go_call_arguments(call_node)
            if len(args) < 2:
                continue

            # 2nd argument is the error message
            msg_arg = args[1]
            if msg_arg.type in _SAFE_STRING_TYPES:
                continue  # Static string message is safe

            findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
