"""SQL injection detection rules for Go (CWE-89).

SC303 — SQL query with string concatenation/fmt.Sprintf    high  CWE-89
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.go._helpers import go_call_arguments, go_is_string_concat_or_fmt
from sanicode.scanner.patterns import Finding

_SQL_METHODS = frozenset(
    {"Query", "QueryRow", "Exec", "QueryContext", "QueryRowContext", "ExecContext"}
)

# Context variants take ctx as first arg, SQL string as second
_SQL_CONTEXT_METHODS = frozenset(
    {"QueryContext", "QueryRowContext", "ExecContext"}
)


# Backward-compatible alias; new code should import from _helpers directly.
_is_string_concat_or_fmt = go_is_string_concat_or_fmt


class GoSQLInjectionRule(Rule):
    """Detect SQL queries with string concatenation or fmt.Sprintf — SQL injection."""

    rule_id = "SC303"
    cwe_id = 89
    severity = "high"
    language = "go"
    message = "SQL query with string concatenation — SQL injection risk (CWE-89)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(call_expression) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None or func_node.type != "selector_expression":
                continue

            field = func_node.child_by_field_name("field")
            if not field or not field.text:
                continue

            method = field.text.decode("utf-8")
            if method not in _SQL_METHODS:
                continue

            args = go_call_arguments(call_node)
            # Context variants take ctx as arg[0], SQL as arg[1]
            sql_idx = 1 if method in _SQL_CONTEXT_METHODS else 0
            if len(args) > sql_idx and _is_string_concat_or_fmt(args[sql_idx]):
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
