"""Error detail exposure detection for Go (CWE-209).

SC349 — err.Error() called inside if-err-not-nil block    medium  CWE-209
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Node, Tree

from sanicode.rules.base import Rule, _walk
from sanicode.rules.go._helpers import go_dotted_name
from sanicode.scanner.patterns import Finding


def _error_var_from_condition(condition: Node) -> str:
    """Extract the error variable name from a ``X != nil`` binary expression.

    Returns the LHS identifier name, or ``""`` if the condition doesn't match.
    """
    if condition.type != "binary_expression":
        return ""
    lhs: Node | None = None
    has_ne = False
    has_nil = False
    for child in condition.children:
        if child.type == "!=" or (child.text and child.text == b"!="):
            has_ne = True
        elif child.type == "nil":
            has_nil = True
        elif child.type == "identifier" and lhs is None:
            lhs = child
    if has_ne and has_nil and lhs is not None and lhs.text:
        return lhs.text.decode("utf-8")
    return ""


def _block_calls_error_method(block: Node, var_name: str) -> list[Node]:
    """Find ``var_name.Error()`` call_expression nodes inside *block*."""
    hits: list[Node] = []
    if not var_name:
        return hits
    for node in _walk(block):
        if node.type != "call_expression":
            continue
        func = node.child_by_field_name("function")
        if func is None or func.type != "selector_expression":
            continue
        operand = func.child_by_field_name("operand")
        field = func.child_by_field_name("field")
        if operand is None or field is None:
            continue
        operand_name = go_dotted_name(operand)
        field_name = field.text.decode("utf-8") if field.text else ""
        if operand_name == var_name and field_name == "Error":
            hits.append(node)
    return hits


class GoErrorDetailRule(Rule):
    """Detect err.Error() calls inside if-err-not-nil error handlers."""

    rule_id = "SC349"
    cwe_id = 209
    severity = "medium"
    language = "go"
    message = (
        "Error detail exposed in exception handler — "
        "may leak implementation details to users (CWE-209)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in _walk(tree.root_node):
            if node.type != "if_statement":
                continue
            condition = node.child_by_field_name("condition")
            if condition is None:
                continue
            var_name = _error_var_from_condition(condition)
            if not var_name:
                continue
            consequence = node.child_by_field_name("consequence")
            if consequence is None:
                continue
            for hit in _block_calls_error_method(consequence, var_name):
                findings.append(self._make_finding(hit, plugin, file_path))
        return findings
