"""Overly permissive file permissions for Go (CWE-276).

SC344 — os.Chmod / os.MkdirAll / os.OpenFile with world-writable mode    medium  CWE-276

Flags calls to os.Chmod, os.MkdirAll, os.Mkdir, os.OpenFile where the
mode (FileMode) argument is an octal literal in a dangerous set.
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.go._helpers import go_call_arguments, go_dotted_name
from sanicode.scanner.patterns import Finding

# Dangerous mode texts — both old-style 0777 and new-style 0o777 octal forms.
_DANGEROUS_MODE_TEXTS = frozenset({
    "0777", "0o777",
    "0776", "0o776",
    "0766", "0o766",
    "0666", "0o666",
})

# Maps function dotted-name → 0-based index of the mode argument.
# os.Chmod(name, mode)              → mode at index 1
# os.Mkdir(name, perm)              → perm at index 1
# os.MkdirAll(path, perm)           → perm at index 1
# os.OpenFile(name, flag, perm)     → perm at index 2
_TARGETS: dict[str, int] = {
    "os.Chmod": 1,
    "os.Mkdir": 1,
    "os.MkdirAll": 1,
    "os.OpenFile": 2,
}


def _is_dangerous_mode(node) -> bool:
    """Return True if *node* is an int_literal with a dangerous octal mode."""
    if node.type != "int_literal":
        return False
    text = node.text.decode("utf-8") if node.text else ""
    return text in _DANGEROUS_MODE_TEXTS


class GoFilePermissionsRule(Rule):
    """Detect os.Chmod/os.Mkdir/os.OpenFile with overly permissive modes."""

    rule_id = "SC344"
    cwe_id = 276
    severity = "medium"
    language = "go"
    message = (
        "os file operation with overly permissive mode — "
        "files may be world-writable (CWE-276)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for call_node in plugin.captures(
            "(call_expression) @call", tree.root_node
        ).get("call", []):
            func = call_node.child_by_field_name("function")
            if func is None:
                continue
            name = go_dotted_name(func)
            if name not in _TARGETS:
                continue
            mode_idx = _TARGETS[name]
            args = go_call_arguments(call_node)
            if len(args) <= mode_idx:
                continue
            if _is_dangerous_mode(args[mode_idx]):
                findings.append(self._make_finding(call_node, plugin, file_path))
        return findings
