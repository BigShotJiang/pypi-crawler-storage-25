"""Clickjacking protection bypass detection for Go (CWE-1021).

SC361 — X-Frame-Options set to permissive value or removed    medium  CWE-1021
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.go._helpers import go_call_arguments
from sanicode.scanner.patterns import Finding

_HEADER_NAME = "x-frame-options"
_SET_METHODS = frozenset({"Set", "Add"})
# Values that explicitly disable frame protection
_PERMISSIVE_VALUES = frozenset({"ALLOWALL", ""})


def _string_text(node) -> str:
    """Extract unquoted text from a Go string literal."""
    if node.type not in ("interpreted_string_literal", "raw_string_literal"):
        return ""
    text = node.text.decode("utf-8") if node.text else ""
    return text.strip('"`')


def _is_header_chain(call_node) -> bool:
    """Return True if call_node's receiver is a *.Header() call expression."""
    func_node = call_node.child_by_field_name("function")
    if func_node is None or func_node.type != "selector_expression":
        return False
    operand = func_node.child_by_field_name("operand")
    if operand is None or operand.type != "call_expression":
        return False
    inner_func = operand.child_by_field_name("function")
    if inner_func is None or inner_func.type != "selector_expression":
        return False
    field = inner_func.child_by_field_name("field")
    if field is None:
        return False
    return (field.text.decode("utf-8") if field.text else "") == "Header"


class GoClickjackingRule(Rule):
    """Detect permissive or absent X-Frame-Options header configuration in Go."""

    rule_id = "SC361"
    cwe_id = 1021
    severity = "medium"
    language = "go"
    message = (
        "Clickjacking protection disabled or weakened "
        "\u2014 verify X-Frame-Options/CSP configuration (CWE-1021)"
    )
    tags = ["clickjacking", "headers"]
    domain = "web"
    action = "review"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(call_expression) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            if not _is_header_chain(call_node):
                continue

            func_node = call_node.child_by_field_name("function")
            field_node = func_node.child_by_field_name("field")  # type: ignore[union-attr]
            method = field_node.text.decode("utf-8") if (field_node and field_node.text) else ""

            args = go_call_arguments(call_node)

            if method == "Del":
                # Del("X-Frame-Options") — removes frame protection entirely
                if len(args) < 1:
                    continue
                header_text = _string_text(args[0])
                if header_text.lower() == _HEADER_NAME:
                    findings.append(self._make_finding(call_node, plugin, file_path))

            elif method in _SET_METHODS:
                # Set/Add("X-Frame-Options", <permissive_value>)
                if len(args) < 2:
                    continue
                header_text = _string_text(args[0])
                if header_text.lower() != _HEADER_NAME:
                    continue
                value_text = _string_text(args[1]).upper()
                if value_text in _PERMISSIVE_VALUES:
                    findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
