"""Trust boundary violation for Go (CWE-501).

SC359 — Request data stored in session without validation    medium  CWE-501
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule, _walk
from sanicode.rules.go._helpers import go_call_arguments, go_dotted_name
from sanicode.scanner.patterns import Finding

_MESSAGE = (
    "Request data stored in session without validation "
    "\u2014 trust boundary violation (CWE-501)"
)

# Method names that write to a session object.
_SESSION_WRITE_METHODS = frozenset({"Set", "Put", "Save"})

# Substrings that indicate a direct request accessor in Go's net/http.
_REQUEST_ACCESSORS = (
    "r.FormValue(",
    "r.PostFormValue(",
    "r.URL.Query(",
    "r.Header.Get(",
)


def _is_direct_request_accessor(node) -> bool:
    """Return True if *node* is itself a direct request accessor call.

    Checks that the node's type is ``call_expression`` and its function text
    matches a known request accessor.  Wrapping in another function call
    (e.g. ``validate(...)``) means the outer call is the node type, and its
    function text won't start with ``r.``, so it will correctly return False.
    """
    if node.type != "call_expression":
        return False
    func = node.child_by_field_name("function")
    if func is None:
        return False
    func_text = func.text.decode("utf-8") if func.text else ""
    return any(func_text.startswith(pat.rstrip("(")) for pat in _REQUEST_ACCESSORS)


class GoTrustBoundaryRule(Rule):
    """Detect request data stored in session without validation (CWE-501).

    Flags two patterns:
    1. ``session.Set("k", r.FormValue("k"))`` — call to session.Set/Put/Save
       where the value argument is a direct request accessor.
    2. ``session.Values["k"] = r.FormValue("k")`` — subscript assignment on
       ``session.Values`` where the RHS is a direct request accessor.
    """

    rule_id = "SC359"
    cwe_id = 501
    severity = "medium"
    language = "go"
    message = _MESSAGE
    tags = ["input_validation", "session"]
    domain = "web"
    action = "review"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        # Pattern 1: session.Set("k", r.FormValue("k")) style calls.
        call_captures = plugin.captures("(call_expression) @call", root)
        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None or func_node.type != "selector_expression":
                continue
            operand = func_node.child_by_field_name("operand")
            field = func_node.child_by_field_name("field")
            if operand is None or field is None or not field.text:
                continue
            method = field.text.decode("utf-8")
            if method not in _SESSION_WRITE_METHODS:
                continue
            operand_name = go_dotted_name(operand)
            if "session" not in operand_name.lower():
                continue
            # Check that a value argument (2nd arg for Set/Put, or any arg for
            # Save) contains a direct request accessor.  For Set/Put we look at
            # arg index 1; for Save we scan all args.
            args = go_call_arguments(call_node)
            if not args:
                continue
            check_args = args[1:] if method in ("Set", "Put") and len(args) > 1 else args
            for arg in check_args:
                if _is_direct_request_accessor(arg):
                    findings.append(self._make_finding(call_node, plugin, file_path))
                    break

        # Pattern 2: session.Values["k"] = r.FormValue("k")
        for node in _walk(root):
            if node.type != "assignment_statement":
                continue
            left = node.child_by_field_name("left")
            right = node.child_by_field_name("right")
            if left is None or right is None:
                continue
            # left is an expression_list; grab the first expression.
            left_exprs = [c for c in left.children if c.type not in (",",)]
            right_exprs = [c for c in right.children if c.type not in (",",)]
            if not left_exprs or not right_exprs:
                continue
            lhs_text = plugin.node_text(left_exprs[0])
            # LHS must look like a subscript on session.Values.
            if "session.Values[" not in lhs_text and "session.values[" not in lhs_text:
                continue
            rhs_node = right_exprs[0]
            if _is_direct_request_accessor(rhs_node):
                findings.append(self._make_finding(node, plugin, file_path))

        return findings
