"""Command injection detection rules for Go (CWE-78).

SC301 — exec.Command / exec.CommandContext    high  CWE-78
SC302 — syscall.Exec / syscall.ForkExec       high  CWE-78
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.go._helpers import go_dotted_name
from sanicode.scanner.patterns import Finding

_EXEC_FUNCS = frozenset(
    {
        "exec.Command",
        "exec.CommandContext",
    }
)

_SYSCALL_FUNCS = frozenset(
    {
        "syscall.Exec",
        "syscall.ForkExec",
    }
)


class GoExecCommandRule(Rule):
    """Detect exec.Command() and exec.CommandContext() — command injection risk."""

    rule_id = "SC301"
    cwe_id = 78
    severity = "high"
    language = "go"
    message = "Use of exec.Command — command injection risk (CWE-78)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(call_expression) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue
            if go_dotted_name(func_node) in _EXEC_FUNCS:
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings


class GoSyscallExecRule(Rule):
    """Detect syscall.Exec() and syscall.ForkExec() — low-level command execution."""

    rule_id = "SC302"
    cwe_id = 78
    severity = "high"
    language = "go"
    message = "Use of syscall.Exec — low-level command execution risk (CWE-78)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(call_expression) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue
            if go_dotted_name(func_node) in _SYSCALL_FUNCS:
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
