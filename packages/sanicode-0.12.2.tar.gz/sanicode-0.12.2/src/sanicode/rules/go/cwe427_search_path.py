"""Uncontrolled search path detection for Go (CWE-427).

SC347 — exec.Command / os.OpenFile with bare name    medium  CWE-427

Detects ``exec.Command("cmd")`` and ``plugin.Open("...")`` where the
first argument is a string literal without an absolute or explicit-relative
path.  The OS will search ``PATH`` to locate the executable, which can be
hijacked if an attacker controls a directory earlier in ``PATH``.
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.go._helpers import go_call_arguments, go_dotted_name
from sanicode.scanner.patterns import Finding

_GO_STRING_TYPES = frozenset({"interpreted_string_literal", "raw_string_literal"})

# Dotted names we want to flag when the first arg is a bare literal.
_DOTTED_TARGETS = frozenset({
    "exec.Command",
    "exec.CommandContext",
    "plugin.Open",
})


def _is_absolute_or_explicit_relative(text: str) -> bool:
    """Return True if *text* represents an absolute or explicitly relative path."""
    stripped = text.strip('"`')
    return (
        stripped.startswith("/")
        or stripped.startswith("./")
        or stripped.startswith("../")
        or stripped.startswith("\\\\")
        or (len(stripped) >= 3 and stripped[1] == ":" and stripped[2] in ("/", "\\"))
    )


class GoSearchPathRule(Rule):
    """Detect exec.Command / plugin.Open called with a bare (search-path) name.

    A bare name like ``"mycommand"`` relies on ``PATH`` resolution; an
    attacker who controls a directory in ``PATH`` can substitute a
    malicious binary.  Absolute paths or explicit ``./`` prefixes are safe.
    """

    rule_id = "SC347"
    cwe_id = 427
    severity = "medium"
    language = "go"
    message = (
        "Command or plugin loaded via search path \u2014 "
        "uncontrolled search path risk (CWE-427)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        captures = plugin.captures("(call_expression) @call", tree.root_node)

        for call_node in captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue

            dotted = go_dotted_name(func_node)
            if dotted not in _DOTTED_TARGETS:
                continue

            args = go_call_arguments(call_node)
            # exec.CommandContext has ctx as first arg; command is second.
            if dotted == "exec.CommandContext":
                if len(args) < 2:
                    continue
                first = args[1]
            else:
                if not args:
                    continue
                first = args[0]

            if first.type not in _GO_STRING_TYPES:
                continue

            text = plugin.node_text(first)
            if not _is_absolute_or_explicit_relative(text):
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
