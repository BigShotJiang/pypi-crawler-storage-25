"""Sensitive data in GET query string parameters for Go (CWE-598).

SC356 — Sensitive parameter read from GET query string    medium  CWE-598
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules._sensitive_patterns import SECRET_VAR_PATTERN, strip_quotes
from sanicode.rules.base import Rule
from sanicode.rules.go._helpers import go_call_arguments, go_dotted_name
from sanicode.scanner.patterns import Finding

_MESSAGE = (
    "Sensitive parameter read from GET query string "
    "— credentials should not travel in URLs (CWE-598)"
)

# Function name suffixes / substrings that indicate query-string reads in Go.
# Covers net/http (r.URL.Query().Get), Gin (c.Query), chi query helpers.
_QUERY_FUNC_HINTS = ("Query", "FormValue")


class GoGetSensitiveRule(Rule):
    """Detect reading sensitive-named parameters from GET query string sources."""

    rule_id = "SC356"
    cwe_id = 598
    severity = "medium"
    language = "go"
    message = _MESSAGE
    tags = ["info_disclosure"]
    domain = "data_protection"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        captures = plugin.captures("(call_expression) @call", tree.root_node)
        for call_node in captures.get("call", []):
            func = call_node.child_by_field_name("function")
            if func is None:
                continue
            # go_dotted_name handles simple selector_expression chains but
            # stops at call_expression nodes (e.g. returns "Get" for
            # r.URL.Query().Get).  Use the raw node text as a fallback so
            # chained patterns like r.URL.Query().Get are still matched.
            func_name = func.text.decode("utf-8") if func.text else go_dotted_name(func)
            if not any(hint in func_name for hint in _QUERY_FUNC_HINTS):
                continue
            args = go_call_arguments(call_node)
            if not args:
                continue
            key_text = strip_quotes(plugin.node_text(args[0]))
            if SECRET_VAR_PATTERN.search(key_text):
                findings.append(self._make_finding(call_node, plugin, file_path))
        return findings
