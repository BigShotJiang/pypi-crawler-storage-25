"""Shared helpers for Go rule modules.

These mirror the private helpers in ``scanner/languages/go.py`` but
are kept here so rule modules don't need to reach into scanner internals.
"""

from __future__ import annotations

from tree_sitter import Node


def go_dotted_name(node: Node) -> str:
    """Build a dotted name from a Go tree-sitter node.

    Handles ``identifier`` and ``selector_expression`` (Go equivalent of
    JS's ``member_expression``).
    """
    if node.type == "identifier":
        return node.text.decode("utf-8") if node.text else ""
    if node.type == "selector_expression":
        operand = node.child_by_field_name("operand")
        field = node.child_by_field_name("field")
        if operand is None or field is None:
            return ""
        prefix = go_dotted_name(operand)
        suffix = field.text.decode("utf-8") if field.text else ""
        return f"{prefix}.{suffix}" if prefix else suffix
    return ""


def go_call_arguments(call_node: Node) -> list[Node]:
    """Return positional argument nodes from a Go ``call_expression`` node."""
    args_node = call_node.child_by_field_name("arguments")
    if args_node is None:
        return []
    results: list[Node] = []
    for child in args_node.children:
        if child.type in ("(", ")", ",", "variadic_argument"):
            continue
        results.append(child)
    return results


def go_is_string_concat_or_fmt(node: Node) -> bool:
    """Check if a node involves string concatenation or ``fmt.Sprintf``.

    Returns True for:
    - ``binary_expression`` with ``+`` operator (string concatenation)
    - ``call_expression`` to ``fmt.Sprintf`` or ``fmt.Sprint``
    """
    if node.type == "binary_expression":
        for child in node.children:
            if child.type == "+" or (child.text and child.text == b"+"):
                return True
    if node.type == "call_expression":
        func = node.child_by_field_name("function")
        if func:
            name = go_dotted_name(func)
            if name in ("fmt.Sprintf", "fmt.Sprint"):
                return True
    return False
