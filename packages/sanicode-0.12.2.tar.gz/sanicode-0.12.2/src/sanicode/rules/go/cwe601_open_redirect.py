"""Open redirect detection rules for Go (CWE-601).

SC322 -- http.Redirect() or Header().Set("Location", ...) call    medium  CWE-601
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.go._helpers import go_call_arguments, go_dotted_name
from sanicode.scanner.patterns import Finding


class GoOpenRedirectRule(Rule):
    """Detect HTTP redirect calls in Go.

    Flags ``http.Redirect()`` calls and ``w.Header().Set("Location", ...)``
    patterns where the redirect URL could be attacker-controlled.
    """

    rule_id = "SC322"
    cwe_id = 601
    severity = "medium"
    language = "go"
    message = (
        "Redirect call \u2014 verify URL is validated against "
        "an allowlist (CWE-601)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures(
            "(call_expression) @call", tree.root_node
        )

        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue
            dotted = go_dotted_name(func_node)

            # Pattern 1: http.Redirect(w, r, url, code)
            if dotted == "http.Redirect":
                findings.append(self._make_finding(call_node, plugin, file_path))
                continue

            # Pattern 2: w.Header().Set("Location", url)
            # The function node for chained calls like w.Header().Set(...)
            # will be a selector_expression whose text contains "Header" and
            # whose field is "Set".
            if func_node.type == "selector_expression":
                field = func_node.child_by_field_name("field")
                if field and field.text and field.text.decode("utf-8") == "Set":
                    args = go_call_arguments(call_node)
                    if args and self._is_location_header(args[0]):
                        findings.append(
                            self._make_finding(call_node, plugin, file_path)
                        )

        return findings

    @staticmethod
    def _is_location_header(node) -> bool:
        """Check if a node is the string literal "Location"."""
        if node.type in ("interpreted_string_literal", "raw_string_literal"):
            text = node.text.decode("utf-8") if node.text else ""
            # Strip quotes
            inner = text.strip('"').strip("`")
            return inner == "Location"
        return False
