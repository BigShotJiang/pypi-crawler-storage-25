"""Empty error check detection for Go (CWE-390).

SC345 — if err != nil with empty consequence block    medium  CWE-390
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Node, Tree

from sanicode.rules.base import Rule, _walk
from sanicode.scanner.patterns import Finding

# Node types that are structural punctuation — not real statements.
_PUNCTUATION = frozenset({"{", "}", "comment"})


def _condition_is_not_nil_check(condition: Node) -> bool:
    """Return True if the if-condition is a ``X != nil`` binary expression.

    Accepts any variable name on the left-hand side compared to nil.
    """
    if condition.type != "binary_expression":
        return False
    op = None
    right = None
    for child in condition.children:
        if child.type == "!=":
            op = child
        elif child.type == "nil":
            right = child
    return op is not None and right is not None


def _block_is_empty(block: Node) -> bool:
    """Return True if a Go block contains no real statements."""
    for child in block.children:
        if child.type in _PUNCTUATION or child.is_extra:
            continue
        # statement_list means there are actual statements
        if child.type == "statement_list":
            return False
        return False
    return True


class GoEmptyErrorCheckRule(Rule):
    """Detect ``if err != nil { }`` with an empty consequence block."""

    rule_id = "SC345"
    cwe_id = 390
    severity = "medium"
    language = "go"
    message = (
        "Empty error check block — error condition detected but silently ignored, "
        "errors go undetected (CWE-390)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in _walk(tree.root_node):
            if node.type != "if_statement":
                continue

            condition = node.child_by_field_name("condition")
            if condition is None or not _condition_is_not_nil_check(condition):
                continue

            consequence = node.child_by_field_name("consequence")
            if consequence is None:
                continue

            if _block_is_empty(consequence):
                findings.append(self._make_finding(node, plugin, file_path))

        return findings
