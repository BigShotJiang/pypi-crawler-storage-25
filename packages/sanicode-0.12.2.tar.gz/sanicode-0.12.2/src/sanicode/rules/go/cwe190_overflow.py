"""Integer overflow detection for Go (CWE-190).

SC316 — Unchecked integer arithmetic in make() allocation size    medium  CWE-190
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.scanner.patterns import Finding


class GoIntegerOverflowRule(Rule):
    """Detect make() with arithmetic in size argument that may silently overflow."""

    rule_id = "SC316"
    cwe_id = 190
    severity = "medium"
    language = "go"
    message = "Integer arithmetic in allocation size — potential overflow (CWE-190)"

    # Arithmetic operator bytes that indicate a binary expression in the size arg.
    _ARITHMETIC_BYTES = ("*", "+", "-", "<<")

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(call_expression) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue
            func_text = func_node.text.decode("utf-8") if func_node.text else ""
            if func_text != "make":
                continue
            # The full call text contains the size argument; look for arithmetic.
            # This is intentionally broad: any arithmetic inside make(...) is flagged.
            args_node = call_node.child_by_field_name("arguments")
            if args_node is None:
                continue
            args_text = args_node.text.decode("utf-8") if args_node.text else ""
            if any(op in args_text for op in self._ARITHMETIC_BYTES):
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
