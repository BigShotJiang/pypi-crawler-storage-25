"""Path traversal via os file functions (CWE-22).

SC309 — os file access with non-literal path — path traversal risk    high  CWE-22
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.go._helpers import go_call_arguments, go_dotted_name
from sanicode.scanner.patterns import Finding

_OS_FILE_FUNCS = frozenset({
    "os.Open", "os.OpenFile", "os.ReadFile", "os.Create", "os.Remove",
})

_GO_STRING_TYPES = frozenset({"interpreted_string_literal", "raw_string_literal"})


class GoPathTraversalRule(Rule):
    """Detect os file access calls with a non-literal path argument."""

    rule_id = "SC309"
    cwe_id = 22
    severity = "high"
    language = "go"
    message = "os file access with non-literal path — path traversal risk (CWE-22)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(call_expression) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue
            if go_dotted_name(func_node) not in _OS_FILE_FUNCS:
                continue
            args = go_call_arguments(call_node)
            if not args:
                continue
            if args[0].type not in _GO_STRING_TYPES:
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
