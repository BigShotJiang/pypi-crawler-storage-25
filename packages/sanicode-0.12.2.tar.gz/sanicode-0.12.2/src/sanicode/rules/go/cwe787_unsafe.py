"""Unsafe pointer detection rules for Go (CWE-787).

SC305 — unsafe.Pointer type conversion    high  CWE-787
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.go._helpers import go_dotted_name
from sanicode.scanner.patterns import Finding


class GoUnsafePointerRule(Rule):
    """Detect unsafe.Pointer usage — memory safety risk."""

    rule_id = "SC305"
    cwe_id = 787
    severity = "high"
    language = "go"
    message = "Use of unsafe.Pointer — memory safety risk (CWE-787)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(call_expression) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue
            if go_dotted_name(func_node) == "unsafe.Pointer":
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
