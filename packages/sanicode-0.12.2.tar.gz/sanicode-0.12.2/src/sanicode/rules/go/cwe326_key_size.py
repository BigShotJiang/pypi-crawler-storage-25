"""Weak key size detection rules for Go (CWE-326).

SC340 — rsa.GenerateKey(rand, N<2048)    high  CWE-326
"""
from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.go._helpers import go_call_arguments, go_dotted_name
from sanicode.scanner.patterns import Finding


def _int_value(node) -> int | None:
    """Extract integer from a Go int_literal node."""
    if node.type == "int_literal":
        text = node.text.decode("utf-8") if node.text else ""
        try:
            return int(text, 0)
        except ValueError:
            return None
    return None


class GoWeakKeyRule(Rule):
    """Detect rsa.GenerateKey with insufficient key size."""

    rule_id = "SC340"
    cwe_id = 326
    severity = "high"
    language = "go"
    message = "Weak RSA key size \u2014 must be at least 2048 bits (CWE-326)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(call_expression) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue
            if go_dotted_name(func_node) != "rsa.GenerateKey":
                continue
            args = go_call_arguments(call_node)
            if len(args) >= 2:
                val = _int_value(args[1])
                if val is not None and val < 2048:
                    findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
