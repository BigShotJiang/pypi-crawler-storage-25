"""Symlink following detection for Go (CWE-59).

SC350 — os.Symlink / os.Readlink / filepath.EvalSymlinks    medium  CWE-59

Detects symlink creation and resolution calls that may expose the program
to symlink-following attacks when the target path is attacker-controlled.
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.go._helpers import go_dotted_name
from sanicode.scanner.patterns import Finding

_DOTTED_TARGETS = frozenset({"os.Symlink", "os.Readlink", "filepath.EvalSymlinks"})


class GoSymlinkOpsRule(Rule):
    """Detect symlink operations in Go that may allow unauthorized file access.

    Matches:
    - ``os.Symlink(oldname, newname)``
    - ``os.Readlink(name)``
    - ``filepath.EvalSymlinks(path)``
    """

    rule_id = "SC350"
    cwe_id = 59
    severity = "medium"
    language = "go"
    message = (
        "Symlink operation without safety checks — "
        "symlink following may allow unauthorized file access (CWE-59)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        captures = plugin.captures("(call_expression) @call", tree.root_node)

        for call_node in captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue

            dotted = go_dotted_name(func_node)
            if dotted in _DOTTED_TARGETS:
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
