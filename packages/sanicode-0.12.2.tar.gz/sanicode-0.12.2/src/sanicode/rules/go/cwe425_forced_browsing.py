"""Forced browsing / direct request detection for Go (CWE-425).

SC353 — Admin path registered without auth middleware    low    CWE-425

Flags http.HandleFunc / http.Handle / mux.HandleFunc / mux.Handle calls where
the path argument contains an admin-like segment but shows no inline auth check.
Severity is low because middleware may be applied at a higher level.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from tree_sitter import Node, Tree

from sanicode.rules.base import Rule, _walk
from sanicode.rules.go._helpers import go_call_arguments, go_dotted_name
from sanicode.scanner.patterns import Finding

if TYPE_CHECKING:
    from sanicode.scanner.languages.base import TreeSitterPlugin


def _node_text(node: Node) -> str:
    return node.text.decode("utf-8") if node.text else ""


# Handler registration functions to inspect.
_HANDLER_FUNCS = frozenset({
    "http.HandleFunc",
    "http.Handle",
    "mux.HandleFunc",
    "mux.Handle",
})

# Path segments that suggest privileged / admin functionality.
_ADMIN_SEGMENTS = ("/admin", "/manage", "/settings", "/config", "/dashboard")

# Paths that are clearly public and should never be flagged.
_PUBLIC_PATHS = frozenset({
    "/login",
    "/health",
    "/register",
    "/signup",
    "/public",
    "/static",
    "/webhook",
    "/callback",
})


def _is_admin_path(path: str) -> bool:
    """Return True if *path* contains an admin-like segment."""
    lower = path.lower()
    return any(seg in lower for seg in _ADMIN_SEGMENTS)


def _is_public_path(path: str) -> bool:
    """Return True if *path* exactly matches or starts with a known public prefix."""
    lower = path.lower()
    for pub in _PUBLIC_PATHS:
        if lower == pub or lower.startswith(pub + "/"):
            return True
    return False


class GoAdminPathWithoutAuthRule(Rule):
    """Detect admin-path handler registrations without an inline auth check."""

    rule_id = "SC353"
    cwe_id = 425
    severity = "low"
    language = "go"
    message = (
        "Admin path registered without visible auth check — "
        "verify middleware enforces access control (CWE-425)"
    )
    tags = ["auth"]
    domain = "access_control"
    action = "review"

    def check(self, tree: Tree, file_path: Path, plugin: TreeSitterPlugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        for node in _walk(root):
            if node.type != "call_expression":
                continue
            func = node.child_by_field_name("function")
            if func is None:
                continue
            name = go_dotted_name(func)
            if name not in _HANDLER_FUNCS:
                continue
            args = go_call_arguments(node)
            if not args:
                continue
            # First argument is the path string.
            path_text = _node_text(args[0]).strip('"')
            if _is_public_path(path_text):
                continue
            if _is_admin_path(path_text):
                findings.append(self._make_finding(node, plugin, file_path))

        return findings
