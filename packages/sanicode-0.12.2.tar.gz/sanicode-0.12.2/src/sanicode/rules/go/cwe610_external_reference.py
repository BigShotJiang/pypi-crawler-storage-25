"""File operations with externally controlled path (CWE-610).

SC360 — File operation with externally controlled path — medium  CWE-610
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.go._helpers import go_call_arguments, go_dotted_name
from sanicode.scanner.patterns import Finding

_FILE_SINKS = frozenset({
    "os.Open",
    "os.OpenFile",
    "os.ReadFile",
    "os.Create",
    "ioutil.ReadFile",
    "ioutil.ReadAll",
})

_GO_STRING_TYPES = frozenset({"interpreted_string_literal", "raw_string_literal"})


class GoExternalReferenceRule(Rule):
    """Detect file I/O calls where the path argument is not a string literal."""

    rule_id = "SC360"
    cwe_id = 610
    severity = "medium"
    language = "go"
    message = (
        "File operation with externally controlled path \u2014"
        " verify path is validated (CWE-610)"
    )
    tags = ["path_traversal", "file_io"]
    domain = "web"
    action = "review"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(call_expression) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue
            if go_dotted_name(func_node) not in _FILE_SINKS:
                continue
            args = go_call_arguments(call_node)
            if not args:
                continue
            if args[0].type not in _GO_STRING_TYPES:
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
