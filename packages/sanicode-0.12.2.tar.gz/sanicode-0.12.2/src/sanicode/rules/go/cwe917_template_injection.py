"""Template injection detection for Go (CWE-917).

SC336 -- template.Parse with non-literal input    high  CWE-917

Detects calls to the .Parse() method on Go's text/template or html/template
objects where the argument is not a string literal.
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.go._helpers import go_call_arguments
from sanicode.scanner.patterns import Finding

_GO_STRING_TYPES = frozenset({"raw_string_literal", "interpreted_string_literal"})


class GoTemplateInjectionRule(Rule):
    """Detect Go template .Parse() calls with non-literal template strings.

    Both ``text/template`` and ``html/template`` use ``.Parse()``.  When the
    argument is not a string literal the template source may be attacker-
    controlled, enabling server-side template injection.

    Note: ``.Parse()`` is a generic method name that could appear on non-template
    types (e.g. ``url.Parse``).  Without type inference this rule may produce
    false positives, but the combination of ``.Parse(variable)`` (not literal)
    on a selector expression is rare outside template usage in practice.
    """

    rule_id = "SC336"
    cwe_id = 917
    severity = "high"
    language = "go"
    message = (
        "template.Parse with non-literal input \u2014 "
        "template injection risk (CWE-917)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(call_expression) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue

            # Only match selector expressions (.Parse method calls)
            if func_node.type != "selector_expression":
                continue

            field = func_node.child_by_field_name("field")
            if field is None:
                continue
            method_name = field.text.decode("utf-8") if field.text else ""
            if method_name != "Parse":
                continue

            args = go_call_arguments(call_node)
            if not args:
                continue

            # String literals (both raw and interpreted) are safe
            if args[0].type in _GO_STRING_TYPES:
                continue

            findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
