"""Hardcoded credential detection for Go (CWE-798).

SC310 — string literal assigned to a secret-named variable    high  CWE-798
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules._sensitive_patterns import (
    MIN_SECRET_LEN,
    SECRET_VAR_PATTERN,
    is_placeholder,
    strip_quotes,
)
from sanicode.rules.base import Rule, _walk
from sanicode.scanner.patterns import Finding

_STRING_TYPES = frozenset({"interpreted_string_literal", "raw_string_literal"})


def _first_identifier(expr_list_node) -> object | None:
    """Return the first identifier child of an expression_list node."""
    for child in expr_list_node.children:
        if child.type == "identifier":
            return child
    return None


def _first_string_value(expr_list_node) -> object | None:
    """Return the first string literal child of an expression_list node."""
    for child in expr_list_node.children:
        if child.type in _STRING_TYPES:
            return child
    return None


class GoHardcodedCredentialRule(Rule):
    """Detect hardcoded credentials in Go variable declarations and assignments."""

    rule_id = "SC310"
    cwe_id = 798
    severity = "high"
    language = "go"
    message = "Hardcoded credential — secret value in variable (CWE-798)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []

        for node in _walk(tree.root_node):
            if node.type in ("short_var_declaration", "assignment_statement"):
                result = self._check_var_decl_or_assignment(node, plugin, file_path)
                if result is not None:
                    findings.append(result)
            elif node.type == "var_spec":
                result = self._check_var_spec(node, plugin, file_path)
                if result is not None:
                    findings.append(result)

        return findings

    def _check_var_decl_or_assignment(self, node, plugin, file_path: Path):
        """Check short_var_declaration / assignment_statement for hardcoded credential values."""
        left = node.child_by_field_name("left")
        right = node.child_by_field_name("right")
        if left is None or right is None:
            return None

        # left is an expression_list — get the first identifier
        name_node = _first_identifier(left)
        if name_node is None:
            return None

        var_name = plugin.node_text(name_node)
        if not SECRET_VAR_PATTERN.search(var_name):
            return None

        # right is an expression_list — get the first string literal
        value_node = _first_string_value(right)
        if value_node is None:
            return None

        inner = strip_quotes(plugin.node_text(value_node), ("`",))
        if len(inner) < MIN_SECRET_LEN or is_placeholder(inner):
            return None

        return self._make_finding(node, plugin, file_path)

    def _check_var_spec(self, node, plugin, file_path: Path):
        """Handle: var name = "value" (var_spec inside var_declaration)."""
        # var_spec: name field is the identifier, value field is expression_list
        name_node = node.child_by_field_name("name")
        value_node = node.child_by_field_name("value")
        if name_node is None or value_node is None:
            return None

        if name_node.type != "identifier":
            return None

        var_name = plugin.node_text(name_node)
        if not SECRET_VAR_PATTERN.search(var_name):
            return None

        # value may be an expression_list or directly a string literal
        if value_node.type in _STRING_TYPES:
            string_node = value_node
        elif value_node.type == "expression_list":
            string_node = _first_string_value(value_node)
        else:
            string_node = _first_string_value(value_node)

        if string_node is None:
            return None

        inner = strip_quotes(plugin.node_text(string_node), ("`",))
        if len(inner) < MIN_SECRET_LEN or is_placeholder(inner):
            return None

        return self._make_finding(node, plugin, file_path)
