"""Symlink following detection for C++ (CWE-59).

SC827 — symlink() / readlink()    medium  CWE-59
"""

from sanicode.rules._c_shared import _SymlinkOps


class CppSymlinkOps(_SymlinkOps):
    """Detect symlink()/readlink() calls in C++ code."""

    rule_id = "SC827"
    language = "cpp"
