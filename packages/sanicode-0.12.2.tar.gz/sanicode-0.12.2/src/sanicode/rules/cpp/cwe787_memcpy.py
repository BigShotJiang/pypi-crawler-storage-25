"""Out-of-bounds write via memcpy()/memmove()/memset()/strncpy() for C++ (CWE-787).

SC813 — memcpy()/memmove()/memset()/strncpy() OOB write    high  CWE-787
"""

from sanicode.rules._c_shared import _MemcpyMemmove


class CppMemcpyMemmove(_MemcpyMemmove):
    """Detect memcpy()/memmove()/memset()/strncpy() calls in C++ code."""

    rule_id = "SC813"
    language = "cpp"
