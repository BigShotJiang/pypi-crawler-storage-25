"""Unbounded input via gets() for C++ (CWE-242).

SC805 — gets() unbounded input    high  CWE-242
"""

from sanicode.rules._c_shared import _Gets


class CppGets(_Gets):
    """Detect gets() calls in C++ code."""

    rule_id = "SC805"
    language = "cpp"
