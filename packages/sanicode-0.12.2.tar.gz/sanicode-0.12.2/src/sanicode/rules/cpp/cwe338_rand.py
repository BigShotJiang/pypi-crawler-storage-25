"""Weak PRNG via rand()/srand() for C++ (CWE-338).

SC808 — rand()/srand() weak PRNG    medium  CWE-338
"""

from sanicode.rules._c_shared import _WeakPrng


class CppWeakPrng(_WeakPrng):
    """Detect rand()/srand() calls in C++ code."""

    rule_id = "SC808"
    language = "cpp"
