"""Integer overflow in allocation size for C++ (CWE-190).

SC817 — malloc()/calloc() with arithmetic in size    high  CWE-190
"""

from sanicode.rules._c_shared import _MallocOverflow


class CppMallocOverflow(_MallocOverflow):
    """Detect malloc()/calloc() with arithmetic in size argument in C++ code."""

    rule_id = "SC817"
    language = "cpp"
