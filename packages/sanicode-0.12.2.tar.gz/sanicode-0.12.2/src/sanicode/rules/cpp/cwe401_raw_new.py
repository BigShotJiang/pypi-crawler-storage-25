"""Memory leak via raw new expression for C++ (CWE-401).

SC811 — raw new without smart pointer    medium  CWE-401
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.scanner.patterns import Finding


class CppRawNew(Rule):
    """Detect raw ``new`` expressions — prefer smart pointers."""

    rule_id = "SC811"
    cwe_id = 401
    severity = "medium"
    language = "cpp"
    message = "Raw new expression — prefer std::unique_ptr/std::shared_ptr (CWE-401)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node
        new_captures = plugin.captures("(new_expression) @new", root)
        for new_node in new_captures.get("new", []):
            findings.append(self._make_finding(new_node, plugin, file_path))
        return findings
