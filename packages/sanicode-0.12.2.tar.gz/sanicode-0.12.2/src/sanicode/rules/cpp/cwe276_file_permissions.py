"""Overly permissive file permissions for C++ (CWE-276).

SC819 — chmod/fchmod/open/mkdir with world-writable mode    medium  CWE-276
"""

from sanicode.rules._c_shared import _FilePermissions


class CppFilePermissions(_FilePermissions):
    """Detect chmod/fchmod/open/mkdir with dangerous modes in C++ code."""

    rule_id = "SC819"
    language = "cpp"
