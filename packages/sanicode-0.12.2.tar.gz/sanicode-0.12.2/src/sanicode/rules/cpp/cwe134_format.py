"""Format string vulnerability for C++ (CWE-134).

SC806 — printf(var)/fprintf(var) format string    high  CWE-134
"""

from sanicode.rules._c_shared import _FormatString


class CppFormatString(_FormatString):
    """Detect format string vulnerabilities in C++ code."""

    rule_id = "SC806"
    language = "cpp"
