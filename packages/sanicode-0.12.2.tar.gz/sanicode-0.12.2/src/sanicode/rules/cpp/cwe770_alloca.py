"""Stack overflow via alloca() for C++ (CWE-770).

SC810 — alloca() stack overflow risk    medium  CWE-770
"""

from sanicode.rules._c_shared import _Alloca


class CppAlloca(_Alloca):
    """Detect alloca() calls in C++ code."""

    rule_id = "SC810"
    language = "cpp"
