"""Heap buffer overflow via wide-string functions for C++ (CWE-122).

SC823 — wcscpy()/wcscat()/swprintf() wide-string overflow    high  CWE-122
"""

from sanicode.rules._c_shared import _WideStringOverflow


class CppWideStringOverflow(_WideStringOverflow):
    """Detect wide-string overflow functions in C++ code."""

    rule_id = "SC823"
    language = "cpp"
