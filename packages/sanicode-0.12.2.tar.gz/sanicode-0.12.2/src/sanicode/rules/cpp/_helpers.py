"""Shared helpers for C++ rule modules.

Re-exports shared C/C++ helpers under ``cpp_`` prefixed names,
plus C++-specific helpers.
"""

from __future__ import annotations

from tree_sitter import Node

from sanicode.rules._c_shared import (
    _bare_function_name,
    _call_args,
    _is_string_literal,
)


def cpp_function_name(node: Node) -> str:
    """Extract unqualified function name from a ``call_expression``'s function field."""
    return _bare_function_name(node)


def cpp_call_arguments(call_node: Node) -> list[Node]:
    """Return argument nodes from a ``call_expression``'s argument_list."""
    return _call_args(call_node)


def cpp_is_literal_string(node: Node) -> bool:
    """Return True if *node* is a string literal type."""
    return _is_string_literal(node)


def cpp_is_raw_new(node: Node) -> bool:
    """Return True if *node* is a ``new_expression`` — raw heap allocation."""
    return node.type == "new_expression"
