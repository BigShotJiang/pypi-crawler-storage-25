"""Insecure temporary file via mktemp() for C++ (CWE-377).

SC807 — mktemp() insecure temp file    medium  CWE-377
"""

from sanicode.rules._c_shared import _Mktemp


class CppMktemp(_Mktemp):
    """Detect mktemp() calls in C++ code."""

    rule_id = "SC807"
    language = "cpp"
