"""Type confusion via static_cast to pointer type for C++ (CWE-843).

SC824 — static_cast to pointer type    medium  CWE-843

Detects ``static_cast<T*>(expr)`` where the target type is a pointer.
Casting through a pointer type — especially from ``void*`` — is a common
source of type confusion bugs.  Unlike ``reinterpret_cast`` (SC812), which
is always unsafe, ``static_cast`` to a pointer is a subtler code smell
flagged here for manual review.
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Node, Tree

from sanicode.rules._c_shared import _bare_function_name
from sanicode.rules.base import Rule
from sanicode.scanner.patterns import Finding


def _template_arg_is_pointer(func_node: Node) -> bool:
    """Return True if the template argument list contains a pointer type.

    Checks whether the ``template_argument_list`` child of a
    ``template_function`` node contains a ``type_descriptor`` that has an
    ``abstract_pointer_declarator`` (the ``*`` in ``<int*>``).
    """
    targs = func_node.child_by_field_name("arguments")
    if targs is None:
        # Fallback: find template_argument_list by type.
        for child in func_node.children:
            if child.type == "template_argument_list":
                targs = child
                break
    if targs is None:
        return False

    for child in targs.children:
        if child.type == "type_descriptor":
            for grandchild in child.children:
                if grandchild.type == "abstract_pointer_declarator":
                    return True
    return False


class CppVoidCastRule(Rule):
    """Detect static_cast to a pointer type — type confusion risk."""

    rule_id = "SC824"
    cwe_id = 843
    severity = "medium"
    language = "cpp"
    message = "Cast from void* via static_cast — type confusion risk (CWE-843)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node
        call_captures = plugin.captures("(call_expression) @call", root)
        for call_node in call_captures.get("call", []):
            func = call_node.child_by_field_name("function")
            if func is None:
                continue
            if func.type != "template_function":
                continue
            if _bare_function_name(func) != "static_cast":
                continue
            if _template_arg_is_pointer(func):
                findings.append(self._make_finding(call_node, plugin, file_path))
        return findings
