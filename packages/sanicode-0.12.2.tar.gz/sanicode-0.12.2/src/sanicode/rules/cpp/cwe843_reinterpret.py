"""Type confusion via reinterpret_cast for C++ (CWE-843).

SC812 — reinterpret_cast type confusion    medium  CWE-843
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules._c_shared import _bare_function_name
from sanicode.rules.base import Rule
from sanicode.scanner.patterns import Finding


class CppReinterpretCast(Rule):
    """Detect reinterpret_cast usage — type confusion risk."""

    rule_id = "SC812"
    cwe_id = 843
    severity = "medium"
    language = "cpp"
    message = "Use of reinterpret_cast — type confusion risk (CWE-843)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node
        call_captures = plugin.captures("(call_expression) @call", root)
        for call_node in call_captures.get("call", []):
            func = call_node.child_by_field_name("function")
            if func is None:
                continue
            # reinterpret_cast appears as a template_function node
            if func.type == "template_function":
                name = _bare_function_name(func)
                if name == "reinterpret_cast":
                    findings.append(self._make_finding(call_node, plugin, file_path))
        return findings
