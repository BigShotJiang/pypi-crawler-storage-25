"""Command injection via system()/popen() for C++ (CWE-78).

SC801 — system()/popen() command injection    high  CWE-78
"""

from sanicode.rules._c_shared import _SystemPopen


class CppSystemPopen(_SystemPopen):
    """Detect system()/popen() calls in C++ code."""

    rule_id = "SC801"
    language = "cpp"
