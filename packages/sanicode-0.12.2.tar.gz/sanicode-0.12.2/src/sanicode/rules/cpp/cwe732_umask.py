"""Overly permissive umask for C++ (CWE-732).

SC820 — umask() with permissive value    medium  CWE-732
"""

from sanicode.rules._c_shared import _PermissiveUmask


class CppPermissiveUmask(_PermissiveUmask):
    """Detect umask() with permissive values in C++ code."""

    rule_id = "SC820"
    language = "cpp"
