"""Buffer overflow via sprintf()/vsprintf() for C++ (CWE-120).

SC803 — sprintf()/vsprintf() buffer overflow    high  CWE-120
"""

from sanicode.rules._c_shared import _SprintfVsprintf


class CppSprintfVsprintf(_SprintfVsprintf):
    """Detect sprintf()/vsprintf() calls in C++ code."""

    rule_id = "SC803"
    language = "cpp"
