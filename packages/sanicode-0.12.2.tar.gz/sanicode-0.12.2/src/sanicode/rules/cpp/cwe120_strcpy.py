"""Buffer overflow via strcpy()/strcat() for C++ (CWE-120).

SC804 — strcpy()/strcat() buffer overflow    high  CWE-120
"""

from sanicode.rules._c_shared import _StrcpyStrcat


class CppStrcpyStrcat(_StrcpyStrcat):
    """Detect strcpy()/strcat() calls in C++ code."""

    rule_id = "SC804"
    language = "cpp"
