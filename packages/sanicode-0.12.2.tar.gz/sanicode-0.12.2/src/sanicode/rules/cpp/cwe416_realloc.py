"""Use-after-free risk via realloc() for C++ (CWE-416).

SC815 — realloc() use-after-free    high  CWE-416
"""

from sanicode.rules._c_shared import _ReallocUseAfterFree


class CppReallocUseAfterFree(_ReallocUseAfterFree):
    """Detect realloc() calls in C++ code."""

    rule_id = "SC815"
    language = "cpp"
