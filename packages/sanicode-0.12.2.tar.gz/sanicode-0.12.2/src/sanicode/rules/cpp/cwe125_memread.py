"""Out-of-bounds read via memcmp()/memchr()/strncmp() for C++ (CWE-125).

SC814 — memcmp()/memchr()/strncmp() OOB read    medium  CWE-125
"""

from sanicode.rules._c_shared import _MemReadFunctions


class CppMemReadFunctions(_MemReadFunctions):
    """Detect memcmp()/memchr()/strncmp() calls in C++ code."""

    rule_id = "SC814"
    language = "cpp"
