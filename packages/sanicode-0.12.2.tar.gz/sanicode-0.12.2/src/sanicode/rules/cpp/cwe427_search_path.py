"""Uncontrolled search path detection for C++ (CWE-427).

SC825 — dlopen / LoadLibrary with bare name    medium  CWE-427
"""

from sanicode.rules._c_shared import _SearchPathLoad


class CppSearchPathLoadRule(_SearchPathLoad):
    """Detect dlopen/LoadLibrary calls in C++ code with a bare library name."""

    rule_id = "SC825"
    language = "cpp"
