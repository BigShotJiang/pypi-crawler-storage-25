"""Custom rule SDK for YAML-defined regex-based pattern rules.

Complements the existing tree-sitter-based ``custom.py`` (which handles
``call`` pattern types) with a simpler regex-on-source-lines engine.  This
lets organizations ship detection rules without writing Python code.

YAML rule format::

    rule_id: CUSTOM001
    name: "Detect use of deprecated API"
    description: "Flag calls to deprecated_function() removed in v3"
    cwe_id: 477
    severity: medium
    language: python
    pattern: "deprecated_function\\s*\\("
    message: "deprecated_function() is obsolete -- use new_function() instead"
    remediation: "Replace deprecated_function() with new_function()"
    stig_ids:
      - "V-222606"
    nist_controls:
      - "SI-10"
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from fnmatch import fnmatch
from pathlib import Path
from typing import Any

from sanicode.scanner.patterns import Finding

# Extension map used for language-based file filtering.
_LANGUAGE_EXTENSIONS: dict[str, tuple[str, ...]] = {
    "python": (".py",),
    "java": (".java",),
    "javascript": (".js", ".mjs", ".cjs", ".ts", ".tsx"),
    "go": (".go",),
    "csharp": (".cs",),
    "ruby": (".rb",),
    "php": (".php",),
    "rust": (".rs",),
}

_VALID_SEVERITIES = frozenset({"critical", "high", "medium", "low", "info"})


@dataclass
class PatternRuleSpec:
    """A user-defined detection rule parsed from YAML.

    Uses regex matching against individual source lines, as opposed to
    tree-sitter AST queries used by the existing ``CallRule`` system.
    """

    rule_id: str
    name: str
    pattern: str
    cwe_id: int
    severity: str
    language: str
    message: str
    description: str = ""
    remediation: str = ""
    stig_ids: list[str] = field(default_factory=list)
    nist_controls: list[str] = field(default_factory=list)
    exclude_pattern: str | None = None
    file_pattern: str | None = None

    # Compiled regexes -- populated by __post_init__, excluded from
    # repr/comparison to keep dataclass output clean.
    _compiled_pattern: re.Pattern[str] | None = field(
        default=None, repr=False, init=False, compare=False,
    )
    _compiled_exclude: re.Pattern[str] | None = field(
        default=None, repr=False, init=False, compare=False,
    )

    def __post_init__(self) -> None:
        try:
            self._compiled_pattern = re.compile(self.pattern)
        except re.error:
            self._compiled_pattern = None
        if self.exclude_pattern:
            try:
                self._compiled_exclude = re.compile(self.exclude_pattern)
            except re.error:
                self._compiled_exclude = None

    def validate(self) -> list[str]:
        """Validate this rule spec and return a list of error messages.

        An empty list means the rule is valid.
        """
        errors: list[str] = []

        if not self.rule_id:
            errors.append("rule_id is required")
        if not self.name:
            errors.append("name is required")
        if not self.message:
            errors.append("message is required")

        if not self.pattern:
            errors.append("pattern is required")
        else:
            try:
                re.compile(self.pattern)
            except re.error as exc:
                errors.append(f"Invalid pattern regex: {exc}")

        if self.exclude_pattern:
            try:
                re.compile(self.exclude_pattern)
            except re.error as exc:
                errors.append(f"Invalid exclude_pattern regex: {exc}")

        if self.severity not in _VALID_SEVERITIES:
            errors.append(
                f"Invalid severity: {self.severity!r} "
                f"(expected one of {', '.join(sorted(_VALID_SEVERITIES))})"
            )

        if not isinstance(self.cwe_id, int) or self.cwe_id <= 0:
            errors.append(f"Invalid cwe_id: {self.cwe_id} (must be a positive integer)")

        if not self.language:
            errors.append("language is required")

        return errors


def load_pattern_rules(path: Path) -> list[PatternRuleSpec]:
    """Load pattern-based custom rules from a YAML file.

    The file may contain a single rule (dict), a list of rules, or a
    wrapper with a ``rules`` key.

    Args:
        path: Path to the YAML rules file.

    Returns:
        A list of ``PatternRuleSpec`` instances.

    Raises:
        FileNotFoundError: If the file does not exist.
        ValueError: If parsing or validation fails.
    """
    try:
        content = path.read_text(encoding="utf-8")
    except FileNotFoundError:
        raise FileNotFoundError(f"Pattern rules file not found: {path}") from None

    try:
        import yaml
        data = yaml.safe_load(content)
    except ImportError:
        import json
        data = json.loads(content)

    if data is None:
        raise ValueError(f"{path}: file is empty")

    if isinstance(data, dict):
        if "rules" in data:
            data = data["rules"]
        elif "pattern" in data and "rule_id" in data:
            # Single rule document
            data = [data]
        else:
            raise ValueError(
                f"{path}: expected a rule dict (with rule_id + pattern) "
                "or a wrapper with a 'rules' key"
            )

    if not isinstance(data, list):
        raise ValueError(
            f"{path}: expected a list of rules or a single rule mapping, "
            f"got {type(data).__name__}"
        )

    known_fields = set(PatternRuleSpec.__dataclass_fields__.keys())
    rules: list[PatternRuleSpec] = []
    errors: list[str] = []

    for i, entry in enumerate(data):
        if not isinstance(entry, dict):
            errors.append(f"  rules[{i}]: expected a mapping, got {type(entry).__name__}")
            continue

        # Filter to only known fields to avoid TypeError on unknown keys.
        filtered: dict[str, Any] = {
            k: v for k, v in entry.items() if k in known_fields
        }

        try:
            spec = PatternRuleSpec(**filtered)
        except TypeError as exc:
            errors.append(f"  rules[{i}]: {exc}")
            continue

        validation_errors = spec.validate()
        if validation_errors:
            rule_label = filtered.get("rule_id", f"rules[{i}]")
            for err in validation_errors:
                errors.append(f"  {rule_label}: {err}")
            continue

        rules.append(spec)

    if errors:
        raise ValueError(
            f"Found {len(errors)} error(s) in {path}:\n" + "\n".join(errors)
        )

    return rules


def apply_pattern_rules(
    rules: list[PatternRuleSpec],
    file_path: Path,
    content: str,
) -> list[Finding]:
    """Apply pattern-based rules to a source file and return findings.

    Each rule's regex is tested against every line of the file.  Lines
    matching ``exclude_pattern`` are suppressed.

    Args:
        rules: The pattern rule specs to apply.
        file_path: Path to the source file being scanned.
        content: The full text of the source file.

    Returns:
        A list of ``Finding`` instances for all matches.
    """
    findings: list[Finding] = []

    for rule in rules:
        # File pattern filter (glob).
        if rule.file_pattern and not fnmatch(str(file_path), rule.file_pattern):
            continue

        # Language filter by extension.
        if rule.language != "any":
            allowed_exts = _LANGUAGE_EXTENSIONS.get(rule.language, ())
            if allowed_exts and file_path.suffix not in allowed_exts:
                continue

        compiled = rule._compiled_pattern
        if compiled is None:
            continue  # Should never happen after __post_init__

        for line_no, line in enumerate(content.splitlines(), 1):
            if compiled.search(line):
                if rule._compiled_exclude and rule._compiled_exclude.search(line):
                    continue
                findings.append(Finding(
                    file=file_path,
                    line=line_no,
                    column=0,
                    rule_id=rule.rule_id,
                    message=rule.message,
                    severity=rule.severity,  # type: ignore[arg-type]
                    cwe_id=rule.cwe_id,
                ))

    return findings
