"""Graph-aware rule for insufficient data authenticity verification (CWE-345).

SC2111 — HTTP handler input reaches dangerous sink without authenticity checks.

Uses the knowledge graph to trace data from HTTP entry points to high-risk
sinks (eval, command execution, SQL, pickle) and flags cases where no
sanitizer (signature check, HMAC, etc.) is present on the path.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any

from sanicode.rules.base import GraphAwareRule
from sanicode.scanner.patterns import Finding

if TYPE_CHECKING:
    from sanicode.graph.query import GraphQueryHelper

_RISKY_SINK_KINDS: frozenset[str] = frozenset({"eval", "command", "sql", "pickle"})


class DataAuthenticityRule(GraphAwareRule):
    """Detect HTTP input reaching dangerous sinks without authenticity verification.

    Uses the knowledge graph to identify entry points whose ``entry_kind`` is
    ``"http_handler"`` and checks whether data flowing to high-risk sinks
    (eval, command, SQL, pickle) passes through any sanitizer node that would
    represent signature verification, HMAC checks, or similar authenticity
    controls.

    Findings are emitted at the entry point location rather than the sink,
    because the absence of authenticity verification is a property of the
    handler boundary, not the individual sink call.
    """

    rule_id = "SC2111"
    cwe_id = 345
    severity = "high"
    language = "python"
    message = (
        "HTTP input reaches dangerous sink without authenticity verification"
        " \u2014 CWE-345"
    )
    tags = ["data-flow", "authenticity", "verification"]
    domain = "input-validation"
    action = "review"

    def check_graph(
        self,
        graph: GraphQueryHelper,
        file_trees: list[tuple[Path, Any]],
    ) -> list[Finding]:
        """Detect unverified HTTP handler data flows into risky sinks."""
        findings: list[Finding] = []

        for entry in graph.entry_points():
            if entry.extra.get("entry_kind") != "http_handler":
                continue
            if entry.file is None or entry.line is None:
                continue

            for sink in graph.reachable_sinks(entry.node_id):
                if sink.extra.get("sink_kind") not in _RISKY_SINK_KINDS:
                    continue
                if graph.has_sanitizer_on_path(entry.node_id, sink.node_id):
                    continue
                findings.append(
                    Finding(
                        file=entry.file,
                        line=entry.line,
                        column=0,
                        rule_id=self.rule_id,
                        message=self.message,
                        severity=self.severity,
                        cwe_id=self.cwe_id,
                        tags=list(self.tags),
                        domain=self.domain,
                        action=self.action,
                    )
                )
                # One finding per entry point is sufficient — the handler is
                # the remediation point regardless of how many risky sinks are
                # downstream.
                break

        return findings
