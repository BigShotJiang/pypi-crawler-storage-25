"""Graph-aware pattern detection rules.

Rules in this package reason over the knowledge graph for cross-file
data flow context. They subclass ``GraphAwareRule`` and implement
``check_graph()`` rather than per-file ``check()``.
"""
