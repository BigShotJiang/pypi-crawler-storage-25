"""Graph-aware rule for missing encryption of sensitive data (CWE-311).

SC2110 — Sensitive env-var data flows to network/file sink without encryption.

Relies on the knowledge graph to trace data flow from env-var entry points
(likely sensitive by name) to network or file-write sinks, and checks that
at least one sanitizer (encryption) node sits on every such path.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any

from sanicode.rules._sensitive_patterns import PII_VAR_PATTERN, SECRET_VAR_PATTERN
from sanicode.rules.base import GraphAwareRule
from sanicode.rules.graph._ast_helpers import find_sensitive_env_reads
from sanicode.scanner.patterns import Finding

if TYPE_CHECKING:
    from sanicode.graph.query import GraphQueryHelper

_SENSITIVE_SINK_KINDS: frozenset[str] = frozenset({"network", "file_write"})


class SensitiveCleartextRule(GraphAwareRule):
    """Detect sensitive env vars flowing to network/file sinks without encryption.

    Uses the knowledge graph to identify entry points whose ``entry_kind`` is
    ``"env_var"`` and whose variable name matches a secret or PII pattern, then
    checks whether reachable network or file-write sinks are covered by a
    sanitizer node on the data-flow path (representing encryption).
    """

    rule_id = "SC2110"
    cwe_id = 311
    severity = "high"
    language = "python"
    message = (
        "Sensitive data flows to network/file sink without encryption \u2014 CWE-311"
    )
    tags = ["data-flow", "encryption", "sensitive-data"]
    domain = "cryptography"
    action = "review"

    def check_graph(
        self,
        graph: GraphQueryHelper,
        file_trees: list[tuple[Path, Any]],
    ) -> list[Finding]:
        """Detect unencrypted flows from sensitive env vars to dangerous sinks."""
        findings: list[Finding] = []

        for entry in graph.entry_points():
            if entry.extra.get("entry_kind") != "env_var":
                continue

            if not self._is_sensitive_entry(entry, file_trees):
                continue

            for sink in graph.reachable_sinks(entry.node_id):
                if sink.extra.get("sink_kind") not in _SENSITIVE_SINK_KINDS:
                    continue
                if graph.has_sanitizer_on_path(entry.node_id, sink.node_id):
                    continue
                if sink.file is None or sink.line is None:
                    continue
                findings.append(
                    Finding(
                        file=sink.file,
                        line=sink.line,
                        column=0,
                        rule_id=self.rule_id,
                        message=self.message,
                        severity=self.severity,
                        cwe_id=self.cwe_id,
                        tags=list(self.tags),
                        domain=self.domain,
                        action=self.action,
                    )
                )

        return findings

    def _is_sensitive_entry(
        self,
        entry: Any,
        file_trees: list[tuple[Path, Any]],
    ) -> bool:
        """Return True if the entry point looks like a sensitive env var.

        First tries to correlate the entry's source location against AST env
        var reads in the same file. Falls back to checking the entry label
        directly against the sensitive-name patterns.
        """
        if entry.file is not None and entry.line is not None:
            for file_path, tree in file_trees:
                if file_path != entry.file:
                    continue
                reads = find_sensitive_env_reads(tree, file_path)
                for _key_name, line in reads:
                    if line == entry.line:
                        return True

        # Fallback: check whether the label itself looks like a sensitive name.
        label = entry.label or ""
        return bool(
            SECRET_VAR_PATTERN.search(label) or PII_VAR_PATTERN.search(label)
        )
