"""Shared AST helpers for graph-aware rules.

Provides utility functions that inspect tree-sitter parse trees in the context
of graph-level analysis — e.g. finding which env var reads involve sensitive
names, or whether a module uses HMAC verification.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from sanicode.rules._sensitive_patterns import (
    PII_VAR_PATTERN,
    SECRET_VAR_PATTERN,
    strip_quotes,
)
from sanicode.rules.base import _dotted_name, _walk


def find_sensitive_env_reads(tree: Any, file_path: Path) -> list[tuple[str, int]]:
    """Find env var reads whose key matches SECRET_VAR_PATTERN or PII_VAR_PATTERN.

    Walks the tree-sitter parse tree for a single file looking for:
    - ``os.environ[<key>]``       (subscript access)
    - ``os.environ.get(<key>)``   (method call)
    - ``os.getenv(<key>)``        (function call)

    Returns a list of ``(key_name, line_number)`` tuples where *line_number*
    is 1-based (tree-sitter uses 0-based rows internally).

    Args:
        tree: A tree-sitter ``Tree`` object for a Python source file.
        file_path: Path of the source file (unused here but kept for context).

    Returns:
        List of (key_name, line) pairs for sensitive env var reads.
    """
    results: list[tuple[str, int]] = []
    root = tree.root_node

    for node in _walk(root):
        # --- subscript: os.environ["KEY"] ---
        if node.type == "subscript":
            value_node = node.child_by_field_name("value")
            subscript_node = node.child_by_field_name("subscript")
            if value_node is None or subscript_node is None:
                continue
            if _dotted_name(value_node) != "os.environ":
                continue
            key = _extract_string_key(subscript_node)
            if key and _is_sensitive_key(key):
                line = node.start_point.row + 1
                results.append((key, line))
            continue

        # --- call: os.environ.get("KEY") or os.getenv("KEY") ---
        if node.type == "call":
            func_node = node.child_by_field_name("function")
            if func_node is None:
                continue
            dotted = _dotted_name(func_node)
            if dotted not in {"os.environ.get", "os.getenv"}:
                continue
            args_node = node.child_by_field_name("arguments")
            if args_node is None:
                continue
            # First positional argument is the key.
            first_arg = _first_positional_arg(args_node)
            if first_arg is None:
                continue
            key = _extract_string_key(first_arg)
            if key and _is_sensitive_key(key):
                line = node.start_point.row + 1
                results.append((key, line))

    return results


def has_hmac_verification(tree: Any) -> bool:
    """Return True if the module uses HMAC verification primitives.

    Checks for calls to ``hmac.compare_digest(...)`` or ``hmac.new(...)``
    anywhere in the module's parse tree.

    Args:
        tree: A tree-sitter ``Tree`` object for a Python source file.

    Returns:
        True if any HMAC verification call is found, False otherwise.
    """
    root = tree.root_node
    _hmac_targets = {"hmac.compare_digest", "hmac.new"}

    for node in _walk(root):
        if node.type != "call":
            continue
        func_node = node.child_by_field_name("function")
        if func_node is None:
            continue
        if _dotted_name(func_node) in _hmac_targets:
            return True

    return False


# -- internal helpers ----------------------------------------------------------


def _is_sensitive_key(key: str) -> bool:
    """Return True if *key* matches SECRET_VAR_PATTERN or PII_VAR_PATTERN."""
    return bool(SECRET_VAR_PATTERN.search(key) or PII_VAR_PATTERN.search(key))


def _extract_string_key(node: Any) -> str | None:
    """Return the string value from a string literal node, or None.

    Returns None for f-strings (which contain interpolation children)
    since the full key cannot be determined statically.
    """
    if node.type == "string":
        for child in node.children:
            if child.type == "interpolation":
                return None
        raw = node.text.decode("utf-8") if node.text else ""
        return strip_quotes(raw) or None
    return None


def _first_positional_arg(args_node: Any) -> Any | None:
    """Return the first positional (non-keyword) argument node, or None."""
    for child in args_node.children:
        if child.type in ("(", ")", ","):
            continue
        if child.type in ("keyword_argument", "dictionary_splat", "list_splat"):
            continue
        return child
    return None
