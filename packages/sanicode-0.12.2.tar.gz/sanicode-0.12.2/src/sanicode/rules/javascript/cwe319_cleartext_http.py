"""Cleartext HTTP transmission detection (CWE-319).

SC248 — HTTP request using cleartext http:// URL    medium  CWE-319
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.javascript._helpers import js_call_arguments, js_dotted_name
from sanicode.scanner.patterns import Finding

_HTTP_FUNCS = frozenset(
    {
        "axios.get",
        "axios.post",
        "axios.put",
        "axios.delete",
        "axios.patch",
        "axios.request",
        "http.request",
        "http.get",
        "https.request",
        "https.get",
    }
)

_LOOPBACK_PREFIXES = (
    "http://localhost",
    "http://127.",
    "http://0.0.0.0",
    "http://[::1]",
)


def _extract_js_string(node) -> str:
    """Extract inner text from a JS string literal node."""
    if node.text is None:
        return ""
    text = node.text.decode("utf-8")
    if len(text) >= 2 and text[0] in ('"', "'") and text[-1] == text[0]:
        return text[1:-1]
    return text


def _is_cleartext_http_js(node) -> bool:
    """Return True if a JS string/template literal contains a non-loopback http:// URL."""
    if node.type == "string":
        inner = _extract_js_string(node)
    elif node.type == "template_string":
        # Only constant template strings (no substitutions) are considered
        has_substitution = any(
            child.type == "template_substitution" for child in node.children
        )
        if has_substitution:
            return False
        raw = node.text.decode("utf-8") if node.text else ""
        # Strip backticks
        inner = raw[1:-1] if len(raw) >= 2 else raw
    else:
        return False

    lower = inner.lower()
    if not lower.startswith("http://"):
        return False
    for prefix in _LOOPBACK_PREFIXES:
        if lower.startswith(prefix):
            return False
    return True


class JsCleartextHttpRule(Rule):
    """Detect HTTP calls using a hardcoded cleartext http:// URL.

    Unlike SSRF (CWE-918) which flags non-literal URLs, this rule flags
    literal URLs that use http:// instead of https://, indicating traffic
    is sent in cleartext over the network.
    """

    rule_id = "SC248"
    cwe_id = 319
    severity = "medium"
    language = "javascript"
    message = "HTTP request uses cleartext http:// URL — use https:// (CWE-319)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(call_expression) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue

            is_http_call = (
                func_node.type == "identifier"
                and func_node.text is not None
                and func_node.text.decode() == "fetch"
            ) or js_dotted_name(func_node) in _HTTP_FUNCS

            if not is_http_call:
                continue

            args = js_call_arguments(call_node)
            if not args:
                continue

            if _is_cleartext_http_js(args[0]):
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
