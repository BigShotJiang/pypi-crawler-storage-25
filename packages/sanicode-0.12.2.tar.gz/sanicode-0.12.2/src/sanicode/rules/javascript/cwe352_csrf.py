"""CSRF protection bypass detection for JavaScript (CWE-352).

SC214 — CSRF disabled via object property (csrf: false / csrfProtection: false)    medium  CWE-352
SC265 — Cookie without SameSite attribute                                          medium  CWE-352
SC266 — CORS wildcard origin with credentials enabled                              high    CWE-352
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.javascript._helpers import js_call_arguments, js_dotted_name
from sanicode.scanner.patterns import Finding


def _node_text(node) -> str:
    return node.text.decode("utf-8") if node.text else ""


def _is_csrf_false_pair(node) -> bool:
    """Return True if *node* is a pair/property with a csrf-named key set to false."""
    text = _node_text(node).lower()
    return "csrf" in text and "false" in text


class JavaScriptCsrfDisableRule(Rule):
    """Detect CSRF middleware explicitly disabled in Express/Node.js config objects.

    Flags object properties (pairs) where a csrf-named key is set to ``false``,
    covering patterns like ``{ csrf: false }`` and ``{ csrfProtection: false }``.
    """

    rule_id = "SC214"
    cwe_id = 352
    severity = "medium"
    language = "javascript"
    message = "CSRF protection disabled — potential CSRF vulnerability (CWE-352)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        # Detect { csrf: false } or { csrfProtection: false } in object literals.
        pair_captures = plugin.captures("(pair) @pair", root)
        for pair_node in pair_captures.get("pair", []):
            if _is_csrf_false_pair(pair_node):
                findings.append(self._make_finding(pair_node, plugin, file_path))

        return findings


class JSCookieSameSiteRule(Rule):
    """Detect cookies set without SameSite attribute in Express/Node.js.

    Covers:
    - ``res.cookie(name, value, { ... })`` without ``sameSite`` in options
    - ``express-session`` / ``cookie-session`` config without ``cookie.sameSite``
    - ``document.cookie = "..."`` without ``SameSite`` in the string
    """

    rule_id = "SC265"
    cwe_id = 352
    severity = "medium"
    language = "javascript"
    message = (
        "Cookie set without SameSite attribute — "
        "explicit SameSite=Strict or Lax is recommended for CSRF protection (CWE-352)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        # Pattern 1: res.cookie(name, value, options) — check options object
        call_captures = plugin.captures("(call_expression) @call", root)
        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue
            dotted = js_dotted_name(func_node)
            method = dotted.rsplit(".", 1)[-1] if "." in dotted else dotted

            if method == "cookie" and "." in dotted:
                args = js_call_arguments(call_node)
                # res.cookie(name, value) without options object
                if len(args) < 3:
                    findings.append(self._make_finding(call_node, plugin, file_path))
                    continue
                # res.cookie(name, value, { ... }) — check if sameSite is set
                opts = args[2]
                if opts.type == "object":
                    opts_text = _node_text(opts).lower()
                    if "samesite" not in opts_text:
                        findings.append(self._make_finding(call_node, plugin, file_path))
                    elif '"none"' in opts_text or "'none'" in opts_text:
                        findings.append(self._make_finding(call_node, plugin, file_path))

        # Pattern 2: document.cookie = "..." without SameSite
        assign_captures = plugin.captures("(assignment_expression) @assign", root)
        for assign_node in assign_captures.get("assign", []):
            lhs = assign_node.child_by_field_name("left")
            rhs = assign_node.child_by_field_name("right")
            if lhs is None or rhs is None:
                continue
            lhs_text = _node_text(lhs)
            if lhs_text != "document.cookie":
                continue
            rhs_text = _node_text(rhs).lower()
            if "samesite" not in rhs_text:
                findings.append(self._make_finding(assign_node, plugin, file_path))

        return findings


class JSCorsCredentialsRule(Rule):
    """Detect CORS wildcard origin combined with credentials in Express/Node.js.

    Covers:
    - ``cors({ origin: '*', credentials: true })`` or
      ``cors({ origin: true, credentials: true })``
    - ``res.header('Access-Control-Allow-Origin', '*')`` patterns are covered
      separately by CWE-346 rules; this rule focuses on the credentials aspect.
    """

    rule_id = "SC266"
    cwe_id = 352
    severity = "high"
    language = "javascript"
    message = (
        "CORS wildcard origin with credentials enabled — "
        "any site can make credentialed cross-origin requests (CWE-352)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        call_captures = plugin.captures("(call_expression) @call", root)
        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue
            func_text = _node_text(func_node)
            if func_text != "cors":
                continue

            args = js_call_arguments(call_node)
            if not args:
                continue
            # First arg should be an options object
            opts = args[0]
            if opts.type != "object":
                continue
            has_wildcard = False
            has_credentials = False

            # Check pairs for origin: '*' or origin: true
            for child in opts.named_children:
                if child.type != "pair":
                    continue
                key_node = child.child_by_field_name("key")
                value_node = child.child_by_field_name("value")
                if key_node is None or value_node is None:
                    continue
                key_text = _node_text(key_node).strip("'\"")
                val_text = _node_text(value_node)

                if key_text == "origin" and val_text in ("'*'", '"*"', "true"):
                    has_wildcard = True
                if key_text == "credentials" and val_text == "true":
                    has_credentials = True

            if has_wildcard and has_credentials:
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
