"""TLS certificate verification bypass detection for JavaScript (CWE-295).

SC267 — NODE_TLS_REJECT_UNAUTHORIZED = "0" or rejectUnauthorized: false    high  CWE-295
"""
from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule, _walk
from sanicode.rules.javascript._helpers import js_dotted_name
from sanicode.scanner.patterns import Finding


class JavaScriptTLSBypassRule(Rule):
    """Detect TLS verification bypass in JavaScript/Node.js.

    Detects:
    - ``process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0"`` — global TLS bypass
    - ``rejectUnauthorized: false`` in object literals (https options)
    """

    rule_id = "SC267"
    cwe_id = 295
    severity = "high"
    language = "javascript"
    message = "TLS certificate verification disabled (CWE-295)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []

        for node in _walk(tree.root_node):
            # Pattern 1: assignment  process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0"
            if node.type == "assignment_expression":
                left = node.child_by_field_name("left")
                right = node.child_by_field_name("right")
                if left is None or right is None:
                    continue
                left_text = js_dotted_name(left)
                if left_text == "process.env.NODE_TLS_REJECT_UNAUTHORIZED":
                    right_text = plugin.node_text(right).strip("'\"")
                    if right_text == "0":
                        findings.append(self._make_finding(node, plugin, file_path))
                continue

            # Pattern 2: object property  rejectUnauthorized: false
            if node.type == "pair":
                key = node.child_by_field_name("key")
                value = node.child_by_field_name("value")
                if key is None or value is None:
                    continue
                key_text = key.text.decode("utf-8") if key.text else ""
                value_text = value.text.decode("utf-8") if value.text else ""
                if key_text == "rejectUnauthorized" and value_text == "false":
                    findings.append(self._make_finding(node, plugin, file_path))

        return findings
