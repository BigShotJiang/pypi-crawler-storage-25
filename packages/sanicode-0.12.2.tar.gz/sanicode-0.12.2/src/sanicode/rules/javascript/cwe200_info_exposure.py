"""Information exposure detection for JavaScript (CWE-200).

SC219 — process.env whole-object exposure   medium  CWE-200
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.javascript._helpers import js_call_arguments, js_dotted_name
from sanicode.scanner.patterns import Finding


class JsInfoExposureRule(Rule):
    """Detect process.env passed as argument — leaks all env vars."""

    rule_id = "SC219"
    cwe_id = 200
    severity = "medium"
    language = "javascript"
    message = (
        "process.env passed as argument — "
        "exposes all environment variables including secrets (CWE-200)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        captures = plugin.captures("(call_expression) @call", tree.root_node)

        for call_node in captures.get("call", []):
            args = js_call_arguments(call_node)
            for arg in args:
                if arg.type == "member_expression":
                    dotted = js_dotted_name(arg)
                    if dotted == "process.env":
                        findings.append(
                            self._make_finding(call_node, plugin, file_path)
                        )
                        break  # One finding per call

        return findings
