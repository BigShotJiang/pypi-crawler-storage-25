"""JWT signature verification bypass detection for JavaScript (CWE-347).

SC250 — JWT verified with null/empty secret    high  CWE-347
"""
from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.javascript._helpers import js_call_arguments, js_dotted_name
from sanicode.scanner.patterns import Finding


class JsJwtNoVerifyRule(Rule):
    """Detect jsonwebtoken verify calls with null or empty secret."""

    rule_id = "SC250"
    cwe_id = 347
    severity = "high"
    language = "javascript"
    message = "JWT verified with null/empty secret — signature not checked (CWE-347)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(call_expression) @call", tree.root_node)
        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue
            if js_dotted_name(func_node) != "jwt.verify":
                continue
            args = js_call_arguments(call_node)
            if len(args) < 2:
                continue
            secret_arg = args[1]
            # null literal → no verification
            if secret_arg.type == "null":
                findings.append(self._make_finding(call_node, plugin, file_path))
                continue
            # empty string → no verification
            if secret_arg.type == "string":
                text = secret_arg.text.decode() if secret_arg.text else ""
                if text.strip("'\"") == "":
                    findings.append(self._make_finding(call_node, plugin, file_path))
        return findings
