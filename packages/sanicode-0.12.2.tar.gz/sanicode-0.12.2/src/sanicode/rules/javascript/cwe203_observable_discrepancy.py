"""Observable discrepancy detection for JavaScript (CWE-203).

SC260 — Auth function returns distinguishable error messages across if/else
        branches, leaking account existence information.    medium  CWE-203
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Node, Tree

from sanicode.rules.base import Rule, _walk
from sanicode.scanner.patterns import Finding

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_AUTH_KEYWORDS = frozenset(
    {
        "login",
        "authenticate",
        "verify_password",
        "sign_in",
        "check_credentials",
        "check_user",
        "verifypassword",
        "signin",
        "checkcredentials",
        "checkuser",
    }
)

# String content keywords that suggest the error reveals *which* field failed.
_USER_KEYWORDS = frozenset({"user", "account", "not found", "unknown", "does not exist"})
_PASS_KEYWORDS = frozenset({"password", "credentials", "invalid", "wrong", "incorrect"})


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _func_name_is_auth(name: str) -> bool:
    """Return True when *name* (lowercased) contains an auth-related keyword."""
    low = name.lower()
    return any(kw in low for kw in _AUTH_KEYWORDS)


def _collect_strings(node: Node) -> list[str]:
    """Return the text content of all string literals under *node*."""
    results: list[str] = []
    for n in _walk(node):
        if n.type == "string" and n.text:
            raw = n.text.decode("utf-8", errors="replace")
            # Strip surrounding quotes and backtick delimiters.
            results.append(raw.strip("\"'`"))
        elif n.type == "string_fragment" and n.text:
            results.append(n.text.decode("utf-8", errors="replace"))
        elif n.type == "template_string" and n.text:
            # Grab the raw template content (backtick-delimited).
            results.append(n.text.decode("utf-8", errors="replace").strip("`"))
    return results


def _branch_has_keyword(strings: list[str], keywords: frozenset[str]) -> bool:
    combined = " ".join(s.lower() for s in strings)
    return any(kw in combined for kw in keywords)


def _func_node_name(node: Node) -> str | None:
    """Extract the declared name from a JS function/method node, or None."""
    if node.type in ("function_declaration", "method_definition"):
        name_node = node.child_by_field_name("name")
        if name_node and name_node.text:
            return name_node.text.decode("utf-8", errors="replace")
    return None


def _func_body(node: Node) -> Node | None:
    """Return the body (statement_block) of a function/method/arrow node."""
    return node.child_by_field_name("body")


def _check_if_statements(body: Node) -> list[Node]:
    """Return if_statement nodes inside *body* that exhibit observable discrepancy."""
    hits: list[Node] = []
    for node in _walk(body):
        if node.type != "if_statement":
            continue

        consequence = node.child_by_field_name("consequence")
        alternative = node.child_by_field_name("alternative")

        # Must have both branches to compare.
        if consequence is None or alternative is None:
            continue

        # The alternative is an else_clause; its body is the statement_block inside.
        else_body = _else_body(alternative)
        if else_body is None:
            continue

        consequence_strs = _collect_strings(consequence)
        else_strs = _collect_strings(else_body)

        # Flag when one branch reveals a user-not-found error and the other a
        # bad-password error (or vice-versa).
        cons_user = _branch_has_keyword(consequence_strs, _USER_KEYWORDS)
        cons_pass = _branch_has_keyword(consequence_strs, _PASS_KEYWORDS)
        else_user = _branch_has_keyword(else_strs, _USER_KEYWORDS)
        else_pass = _branch_has_keyword(else_strs, _PASS_KEYWORDS)

        # Flag only when one branch is exclusively user-oriented and the other
        # exclusively password-oriented.  A branch that contains *both* types
        # of keywords (e.g. "Invalid username or password") is a generic
        # combined message and should not be treated as distinguishable.
        cons_only_user = cons_user and not cons_pass
        cons_only_pass = cons_pass and not cons_user
        else_only_user = else_user and not else_pass
        else_only_pass = else_pass and not else_user

        if (cons_only_user and else_only_pass) or (cons_only_pass and else_only_user):
            hits.append(node)

    return hits


def _else_body(alternative: Node) -> Node | None:
    """Extract the statement_block from an else_clause node."""
    for child in alternative.children:
        if child.type == "statement_block":
            return child
        # else-if: treat the nested if_statement itself as the else body so
        # string collection still works inside it.
        if child.type == "if_statement":
            return child
    return None


# ---------------------------------------------------------------------------
# Rule
# ---------------------------------------------------------------------------


class JsObservableDiscrepancyRule(Rule):
    """Detect auth functions that reveal account existence via distinct error messages."""

    rule_id = "SC260"
    cwe_id = 203
    severity = "medium"
    language = "javascript"
    message = (
        "Auth function has distinguishable error messages "
        "— may reveal account existence (CWE-203)"
    )
    domain = "authentication"
    action = "review"
    tags: list[str] = ["auth", "info_disclosure"]

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []

        for node in _walk(tree.root_node):
            name = _func_node_name(node)
            if name is None or not _func_name_is_auth(name):
                continue

            body = _func_body(node)
            if body is None:
                continue

            for hit in _check_if_statements(body):
                findings.append(self._make_finding(hit, plugin, file_path))

        return findings
