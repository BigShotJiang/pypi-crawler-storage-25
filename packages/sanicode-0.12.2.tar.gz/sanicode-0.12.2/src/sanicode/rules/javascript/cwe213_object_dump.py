"""Full object serialization without field filtering for JavaScript (CWE-213).

SC257 — Full object dump without field filtering    medium  CWE-213
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.javascript._helpers import js_dotted_name
from sanicode.scanner.patterns import Finding

_DUMP_METHODS: frozenset[str] = frozenset({"toJSON", "toObject"})


class JavaScriptObjectDumpRule(Rule):
    """Detect full object dumps via Mongoose/Sequelize toJSON/toObject methods."""

    rule_id = "SC257"
    cwe_id = 213
    severity = "medium"
    language = "javascript"
    tags = ["info_disclosure"]
    domain = "data_protection"
    message = (
        "Full object serialization without field filtering "
        "— may expose internal state (CWE-213)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        captures = plugin.captures("(call_expression) @call", tree.root_node)
        for call_node in captures.get("call", []):
            func = call_node.child_by_field_name("function")
            if func is None:
                continue
            name = js_dotted_name(func)
            # Extract last segment after the final dot
            last_segment = name.split(".")[-1] if name else ""
            if last_segment in _DUMP_METHODS:
                findings.append(self._make_finding(call_node, plugin, file_path))
        return findings
