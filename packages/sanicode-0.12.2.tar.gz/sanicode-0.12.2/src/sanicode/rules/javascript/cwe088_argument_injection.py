"""Argument injection detection for JavaScript (CWE-88).

SC229 — spawn/execFile with literal command and variable arguments    medium  CWE-88
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.javascript._helpers import js_call_arguments, js_dotted_name
from sanicode.scanner.patterns import Finding

# Functions where the first arg is the command and subsequent args (or an array
# second arg) are the arguments.
_SPAWN_FUNCS_DOTTED = frozenset({
    "child_process.spawn",
    "child_process.spawnSync",
    "child_process.execFile",
    "child_process.execFileSync",
})

# After destructured import: const { spawn } = require('child_process')
_SPAWN_FUNCS_BARE = frozenset({
    "spawn", "spawnSync", "execFile", "execFileSync",
})

# String literal node types in JavaScript tree-sitter grammar.
_STRING_TYPES = frozenset({"string", "template_string"})


def _is_string_literal(node) -> bool:
    """Return True if node is a JS string literal without interpolation."""
    if node.type == "string":
        return True
    if node.type == "template_string":
        # Template strings without substitutions are literals
        for child in node.children:
            if child.type == "template_substitution":
                return False
        return True
    return False


def _array_elements(node) -> list:
    """Extract element nodes from an array literal."""
    return [
        child for child in node.children
        if child.type not in ("[", "]", ",")
    ]


class JSArgumentInjectionRule(Rule):
    """Detect spawn/execFile with literal command and variable arguments."""

    rule_id = "SC229"
    cwe_id = 88
    severity = "medium"
    language = "javascript"
    message = (
        "spawn/execFile with literal command and variable arguments "
        "— potential argument injection (CWE-88)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(call_expression) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue

            matched = False
            dotted = js_dotted_name(func_node)
            if dotted in _SPAWN_FUNCS_DOTTED:
                matched = True
            elif func_node.type == "identifier" and dotted in _SPAWN_FUNCS_BARE:
                matched = True

            if not matched:
                continue

            args = js_call_arguments(call_node)
            if not args:
                continue

            # First arg is the command — must be a string literal
            if not _is_string_literal(args[0]):
                continue

            # Second arg can be an array of arguments
            if len(args) >= 2 and args[1].type == "array":
                elements = _array_elements(args[1])
                if elements:
                    has_variable = any(
                        not _is_string_literal(elem) for elem in elements
                    )
                    if has_variable:
                        findings.append(self._make_finding(call_node, plugin, file_path))
                        continue

            # Also check for spawn("cmd", variable) where second arg is a variable
            if len(args) >= 2:
                second = args[1]
                if second.type not in ("array", "object") and not _is_string_literal(second):
                    # The args parameter is a variable (could be an array variable)
                    findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
