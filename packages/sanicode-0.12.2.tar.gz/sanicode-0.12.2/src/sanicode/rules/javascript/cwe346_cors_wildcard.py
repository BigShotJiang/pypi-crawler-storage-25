"""CORS wildcard origin detection for JavaScript (CWE-346).

SC249 — Access-Control-Allow-Origin set to wildcard *    medium  CWE-346
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.javascript._helpers import js_call_arguments, js_dotted_name
from sanicode.scanner.patterns import Finding

_HEADER_NAME = "access-control-allow-origin"
_SET_METHODS = frozenset({"setHeader", "set", "header", "writeHead"})


def _is_star_string(node) -> bool:
    """Check if node is a string literal containing just '*'."""
    if node.type not in ("string", "template_string"):
        return False
    text = node.text.decode("utf-8") if node.text else ""
    return text.strip("'\"` ") == "*"


def _arg_text(node) -> str:
    """Extract the string content from a JS string node."""
    if node.type not in ("string", "template_string"):
        return ""
    text = node.text.decode("utf-8") if node.text else ""
    return text.strip("'\"` ")


class JSCorsWildcardRule(Rule):
    """Detect res.setHeader/set/header('Access-Control-Allow-Origin', '*') in JavaScript."""

    rule_id = "SC249"
    cwe_id = 346
    severity = "medium"
    language = "javascript"
    message = "Access-Control-Allow-Origin set to wildcard '*' (CWE-346)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(call_expression) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue
            dotted = js_dotted_name(func_node)
            # Extract the method name (last component after the dot)
            method = dotted.rsplit(".", 1)[-1] if "." in dotted else dotted
            if method not in _SET_METHODS:
                continue
            args = js_call_arguments(call_node)
            if len(args) < 2:
                continue
            header_text = _arg_text(args[0])
            if _HEADER_NAME not in header_text.lower():
                continue
            if _is_star_string(args[1]):
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
