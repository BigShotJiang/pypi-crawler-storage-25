"""Command injection detection for JavaScript (CWE-77).

SC217 — setTimeout/setInterval with non-literal string first argument.

These timer APIs accept a string argument and evaluate it as code,
similar to eval(). Arrow functions and function expressions are safe.
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.javascript._helpers import js_call_arguments, js_dotted_name
from sanicode.scanner.patterns import Finding


class JsTimerInjectionRule(Rule):
    """Detect setTimeout/setInterval with non-literal string — code injection."""

    rule_id = "SC217"
    cwe_id = 77
    severity = "high"
    language = "javascript"
    message = "setTimeout/setInterval with non-literal string — code injection risk (CWE-77)"

    _TIMER_FUNCS = frozenset({"setTimeout", "setInterval"})

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        captures = plugin.captures("(call_expression) @call", tree.root_node)

        for call_node in captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue

            name = js_dotted_name(func_node)
            if name not in self._TIMER_FUNCS:
                continue

            # Only flag if first argument is not a safe callable or string literal
            args = js_call_arguments(call_node)
            if not args:
                continue

            first = args[0]
            # Safe: arrow function, function expression, string literal
            if first.type in ("arrow_function", "function_expression", "function", "string"):
                continue

            # Flag: identifier, member_expression, template_string, call_expression, etc.
            findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
