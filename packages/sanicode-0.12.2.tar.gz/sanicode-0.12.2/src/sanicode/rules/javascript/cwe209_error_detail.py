"""Error detail exposure detection for JavaScript (CWE-209).

SC252 — e.message / e.stack / e.toString() in catch handlers    medium  CWE-209
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Node, Tree

from sanicode.rules.base import Rule, _walk
from sanicode.scanner.patterns import Finding

_DETAIL_PROPERTIES = frozenset({"message", "stack"})
_DETAIL_METHODS = frozenset({"toString"})


def _catch_var_name(catch_clause: Node) -> str:
    """Extract the catch parameter identifier name.

    In tree-sitter JavaScript, the catch parameter is a direct ``identifier``
    child between the parentheses.
    """
    found_open = False
    for child in catch_clause.children:
        if child.type == "(":
            found_open = True
            continue
        if child.type == ")" and found_open:
            break
        if found_open and child.type == "identifier" and child.text:
            return child.text.decode("utf-8")
    return ""


def _statement_block_exposes_detail(block: Node, var_name: str) -> list[Node]:
    """Find member_expression or call nodes that expose error detail for *var_name*."""
    hits: list[Node] = []
    if not var_name:
        return hits
    for node in _walk(block):
        if node.type == "member_expression":
            obj = node.child_by_field_name("object")
            prop = node.child_by_field_name("property")
            if obj is None or prop is None:
                continue
            obj_name = obj.text.decode("utf-8") if obj.text else ""
            prop_name = prop.text.decode("utf-8") if prop.text else ""
            if obj_name == var_name and prop_name in _DETAIL_PROPERTIES:
                hits.append(node)
            elif obj_name == var_name and prop_name in _DETAIL_METHODS:
                # e.toString — only flag if called (call_expression wraps it)
                # but also flag the member_expression itself for simplicity
                hits.append(node)
    return hits


class JsErrorDetailRule(Rule):
    """Detect error property/method access (message, stack, toString) in catch blocks."""

    rule_id = "SC252"
    cwe_id = 209
    severity = "medium"
    language = "javascript"
    message = (
        "Error detail exposed in exception handler — "
        "may leak implementation details to users (CWE-209)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in _walk(tree.root_node):
            if node.type != "catch_clause":
                continue
            var_name = _catch_var_name(node)
            for child in node.children:
                if child.type == "statement_block":
                    for hit in _statement_block_exposes_detail(child, var_name):
                        findings.append(self._make_finding(hit, plugin, file_path))
        return findings
