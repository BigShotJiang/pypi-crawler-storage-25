"""Template-engine XSS detection rules for JavaScript (CWE-79).

SC268 -- React dangerouslySetInnerHTML usage    high  CWE-79
SC269 -- Vue v-html directive usage             high  CWE-79
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule, _walk
from sanicode.scanner.patterns import Finding


class ReactDangerouslySetInnerHTMLRule(Rule):
    """Detect dangerouslySetInnerHTML in JSX/React code.

    React's ``dangerouslySetInnerHTML`` bypasses its built-in XSS
    protection by injecting raw HTML into the DOM.  This is flagged
    regardless of the value because even sanitized HTML is risky if
    the sanitization is later removed or bypassed.

    Detection works on both JSX attribute syntax (parsed as JSX by
    tree-sitter) and object-property syntax in createElement calls
    (plain JS objects).
    """

    rule_id = "SC268"
    cwe_id = 79
    severity = "high"
    language = "javascript"
    message = (
        "Use of dangerouslySetInnerHTML \u2014 "
        "bypasses React XSS protection (CWE-79)"
    )

    _TARGET = "dangerouslySetInnerHTML"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []

        for node in _walk(tree.root_node):
            # JSX attribute: <div dangerouslySetInnerHTML={...} />
            if node.type == "jsx_attribute":
                name_node = node.children[0] if node.children else None
                if name_node and plugin.node_text(name_node) == self._TARGET:
                    findings.append(self._make_finding(node, plugin, file_path))
                    continue

            # Object property: { dangerouslySetInnerHTML: ... } in createElement
            if node.type == "pair":
                key = node.child_by_field_name("key")
                if key and plugin.node_text(key) == self._TARGET:
                    findings.append(self._make_finding(node, plugin, file_path))
                    continue

            # String literal containing "dangerouslySetInnerHTML" in template
            # literals or regular strings (catches dynamic usage)
            if node.type in ("string", "template_string"):
                text = plugin.node_text(node)
                if self._TARGET in text:
                    findings.append(self._make_finding(node, plugin, file_path))

        return findings


class VueVHtmlDirectiveRule(Rule):
    """Detect v-html directive usage in Vue component code.

    Vue's ``v-html`` directive renders raw HTML and explicitly opts out
    of Vue's template escaping.  This rule detects ``v-html`` in:

    - Template strings within JS/TS component definitions
    - JSX-style attributes (``v-html={...}``)
    - String literals containing v-html references
    """

    rule_id = "SC269"
    cwe_id = 79
    severity = "high"
    language = "javascript"
    message = (
        "Use of v-html directive \u2014 "
        "renders unescaped HTML in Vue, XSS risk (CWE-79)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []

        for node in _walk(tree.root_node):
            # Template literals: template: `<div v-html="userInput"></div>`
            if node.type == "template_string":
                text = plugin.node_text(node)
                if "v-html" in text:
                    findings.append(self._make_finding(node, plugin, file_path))
                    continue

            # Regular string literals containing v-html
            if node.type == "string":
                text = plugin.node_text(node)
                if "v-html" in text:
                    findings.append(self._make_finding(node, plugin, file_path))
                    continue

            # JSX attribute: <div v-html={...} />
            if node.type == "jsx_attribute":
                name_node = node.children[0] if node.children else None
                if name_node and plugin.node_text(name_node) == "v-html":
                    findings.append(self._make_finding(node, plugin, file_path))

        return findings
