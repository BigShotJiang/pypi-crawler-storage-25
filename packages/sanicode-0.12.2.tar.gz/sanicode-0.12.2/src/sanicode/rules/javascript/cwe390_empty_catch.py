"""Empty catch handler detection for JavaScript (CWE-390).

SC251 — catch clause with empty statement_block body    medium  CWE-390
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Node, Tree

from sanicode.rules.base import Rule, _walk
from sanicode.scanner.patterns import Finding

# Node types that are structural punctuation — not real statements.
_PUNCTUATION = frozenset({"{", "}", "comment"})


def _statement_block_is_empty(block: Node) -> bool:
    """Return True if a statement_block contains no real statements."""
    for child in block.children:
        if child.type in _PUNCTUATION or child.is_extra:
            continue
        return False
    return True


class JsEmptyCatchRule(Rule):
    """Detect catch clauses with an empty statement block."""

    rule_id = "SC251"
    cwe_id = 390
    severity = "medium"
    language = "javascript"
    message = (
        "Empty catch block — exception silently swallowed, "
        "errors go undetected (CWE-390)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in _walk(tree.root_node):
            if node.type != "catch_clause":
                continue
            for child in node.children:
                if child.type == "statement_block" and _statement_block_is_empty(child):
                    findings.append(self._make_finding(node, plugin, file_path))
                    break
        return findings
