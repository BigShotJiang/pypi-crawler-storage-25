"""Indirect command injection via environment variables for JavaScript (CWE-78).

SC270 — process.env.XXX used in child_process.exec() or execSync().

Detects patterns where process.env property access flows into
child_process.exec(), execSync(), or related APIs.
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule, _walk
from sanicode.rules.javascript._helpers import js_dotted_name
from sanicode.scanner.patterns import Finding

_EXEC_SINKS = frozenset({
    "child_process.exec",
    "child_process.execSync",
    "child_process.spawn",
    "child_process.spawnSync",
    "execSync",
    "exec",
})


def _subtree_has_process_env(node) -> bool:
    """Check if any node in the subtree accesses process.env."""
    for n in _walk(node):
        if n.type == "member_expression":
            dotted = js_dotted_name(n)
            if dotted.startswith("process.env."):
                return True
        # Also catch process.env["KEY"] via computed access
        if n.type == "subscript_expression":
            obj = n.child_by_field_name("object")
            if obj is not None and js_dotted_name(obj) == "process.env":
                return True
    return False


class JSEnvCommandInjectionRule(Rule):
    """Detect process.env values used in child_process exec calls."""

    rule_id = "SC270"
    cwe_id = 78
    severity = "medium"
    language = "javascript"
    message = (
        "process.env used in command execution — "
        "indirect command injection risk (CWE-78)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(call_expression) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue

            dotted = js_dotted_name(func_node)
            if dotted in _EXEC_SINKS:
                if _subtree_has_process_env(call_node):
                    findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
