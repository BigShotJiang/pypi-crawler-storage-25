"""Unrestricted file upload detection for JavaScript (CWE-434).

SC215 — multer() without fileFilter / req.file access    medium  CWE-434
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.scanner.patterns import Finding


class JavaScriptFileUploadRule(Rule):
    """Detect file upload handling without type validation in Express/Node.js."""

    rule_id = "SC215"
    cwe_id = 434
    severity = "medium"
    language = "javascript"
    message = "File upload without type validation — unrestricted upload risk (CWE-434)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        call_captures = plugin.captures("(call_expression) @call", root)
        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue
            func_text = func_node.text.decode("utf-8") if func_node.text else ""
            if func_text == "multer":
                full_text = call_node.text.decode("utf-8") if call_node.text else ""
                if "fileFilter" not in full_text:
                    findings.append(self._make_finding(call_node, plugin, file_path))

        # req.file / req.files access
        member_captures = plugin.captures("(member_expression) @mem", root)
        for mem_node in member_captures.get("mem", []):
            text = mem_node.text.decode("utf-8") if mem_node.text else ""
            if text in ("req.file", "req.files"):
                findings.append(self._make_finding(mem_node, plugin, file_path))

        return findings
