"""Prototype pollution detection (CWE-1321).

SC213 — Object.assign / _.merge / computed property assignment    high  CWE-1321
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.javascript._helpers import js_call_arguments, js_dotted_name
from sanicode.scanner.patterns import Finding

# Node types considered safe object/array literals.
_LITERAL_TYPES = frozenset({
    "object", "array", "string", "number", "true", "false", "null",
})

_LODASH_MERGE_FUNCS = frozenset({
    "_.merge",
    "_.defaultsDeep",
    "lodash.merge",
    "lodash.defaultsDeep",
})

# Property names on the prototype chain that are pollution vectors.
_PROTO_PROPERTIES = frozenset({"__proto__", "prototype", "constructor"})


class JsPrototypePollutionRule(Rule):
    """Detect prototype pollution vectors.

    Three detection paths:
    1. Object.assign(target, src) where src is not an object/array literal.
    2. _.merge() / _.defaultsDeep() calls (lodash deep merge).
    3. Bracket-notation assignment that accesses the prototype chain:
       nested subscript (obj[a][b] = c) or property-chain access
       (obj.__proto__[key] = val, obj.prototype[key] = val).
    """

    rule_id = "SC213"
    cwe_id = 1321
    severity = "high"
    language = "javascript"
    message = (
        "Potential prototype pollution — unsafe object merge or computed "
        "property assignment (CWE-1321)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []

        # Patterns 1 & 2: call-based detection.
        call_captures = plugin.captures("(call_expression) @call", tree.root_node)
        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue

            dotted = js_dotted_name(func_node)

            # Pattern 1: Object.assign(target, src)
            if dotted == "Object.assign":
                args = js_call_arguments(call_node)
                if len(args) >= 2:
                    for src_arg in args[1:]:
                        if src_arg.type not in _LITERAL_TYPES:
                            findings.append(self._make_finding(call_node, plugin, file_path))
                            break
                continue

            # Pattern 2: _.merge() / _.defaultsDeep() and lodash equivalents.
            if dotted in _LODASH_MERGE_FUNCS:
                findings.append(self._make_finding(call_node, plugin, file_path))

        # Pattern 3: bracket-notation assignment on the prototype chain.
        # Only flags nested subscript chains (obj[a][b] = c) or direct
        # prototype-chain property access (obj.__proto__[key] = val).
        # Plain obj[key] = val is too broad and produces excessive FPs.
        assign_captures = plugin.captures(
            "(assignment_expression) @assign", tree.root_node
        )
        for assign_node in assign_captures.get("assign", []):
            left = assign_node.child_by_field_name("left")
            if left is None or left.type != "subscript_expression":
                continue
            index_node = left.child_by_field_name("index")
            if index_node is None or index_node.type != "identifier":
                continue
            # Get the object being subscripted.
            obj_node = left.child_by_field_name("object")
            if obj_node is None:
                continue
            # Nested subscript: obj[a][b] = c — classic pollution vector.
            if obj_node.type == "subscript_expression":
                findings.append(self._make_finding(assign_node, plugin, file_path))
                continue
            # Proto-chain property: obj.__proto__[key], obj.prototype[key], etc.
            if obj_node.type == "member_expression":
                prop = obj_node.child_by_field_name("property")
                if prop and prop.text:
                    prop_name = prop.text.decode("utf-8")
                    if prop_name in _PROTO_PROPERTIES:
                        findings.append(self._make_finding(assign_node, plugin, file_path))

        return findings
