"""Direct admin privilege assignment in JavaScript (CWE-266).

SC254 — Assignment of admin/root privileges to an object property  medium  CWE-266
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from tree_sitter import Node, Tree

from sanicode.rules.base import Rule, _walk
from sanicode.scanner.patterns import Finding

if TYPE_CHECKING:
    from sanicode.scanner.languages.base import TreeSitterPlugin

# Property names whose assignment to an admin-like value indicates privilege grant.
_PRIV_PROPS: frozenset[str] = frozenset({"role", "isAdmin", "isSuperuser", "is_admin"})

# Admin-like string values (lower-cased for comparison).
_ADMIN_VALUES: frozenset[str] = frozenset(
    {"admin", "root", "superuser", "administrator"}
)


def _node_text(node: Node) -> str:
    return node.text.decode("utf-8") if node.text else ""


def _strip_quotes(s: str) -> str:
    for q in ('"', "'", "`"):
        if s.startswith(q) and s.endswith(q) and len(s) >= 2:
            return s[1:-1]
    return s


class JSPrivilegeAssignmentRule(Rule):
    """Detect direct assignment of admin/root privileges (CWE-266)."""

    rule_id = "SC254"
    cwe_id = 266
    severity = "medium"
    language = "javascript"
    message = (
        "Direct admin privilege assignment "
        "— review for least privilege (CWE-266)"
    )
    tags = ["auth"]
    domain = "access_control"
    action = "review"

    def check(self, tree: Tree, file_path: Path, plugin: TreeSitterPlugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in _walk(tree.root_node):
            if node.type != "assignment_expression":
                continue
            lhs = node.child_by_field_name("left")
            rhs = node.child_by_field_name("right")
            if lhs is None or rhs is None:
                continue
            if lhs.type != "member_expression":
                continue
            prop = lhs.child_by_field_name("property")
            if prop is None:
                continue
            prop_name = _node_text(prop)
            if prop_name not in _PRIV_PROPS:
                continue

            rhs_text = _node_text(rhs)

            if prop_name == "isAdmin" or prop_name == "isSuperuser" or prop_name == "is_admin":
                # Flag when RHS is the literal `true`.
                if rhs.type == "true":
                    findings.append(self._make_finding(node, plugin, file_path))
            elif prop_name == "role":
                # Flag when RHS is a hardcoded admin-like string.
                if rhs.type == "string":
                    value = _strip_quotes(rhs_text).lower()
                    if value in _ADMIN_VALUES:
                        findings.append(self._make_finding(node, plugin, file_path))

        return findings
