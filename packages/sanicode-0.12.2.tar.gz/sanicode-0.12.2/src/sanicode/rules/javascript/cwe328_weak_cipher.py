"""Weak hash/cipher detection rules for JavaScript (CWE-328).

SC246 — crypto.createHash("md4"), crypto.createCipheriv("des-cbc"/...)    medium  CWE-328
"""
from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.javascript._helpers import js_call_arguments, js_dotted_name
from sanicode.scanner.patterns import Finding

_WEAK_HASH_ALGOS = frozenset({"md4", "md2"})

_CIPHER_TARGETS = frozenset({
    "crypto.createCipheriv",
    "crypto.createCipher",
    "crypto.createDecipheriv",
    "crypto.createDecipher",
})


def _strip_quotes(s: str) -> str:
    for q in ('"""', "'''", "`", '"', "'"):
        if s.startswith(q) and s.endswith(q) and len(s) >= 2 * len(q):
            return s[len(q):-len(q)]
    return s


def _is_weak_cipher_string(algo: str) -> bool:
    """Check if a cipher algorithm string refers to a weak cipher."""
    algo = algo.lower()
    if algo.startswith("des"):
        return True
    if algo in ("rc4", "rc2"):
        return True
    if algo.startswith("rc4") or algo.startswith("rc2"):
        return True
    return False


class JSWeakCipherRule(Rule):
    """Detect crypto.createHash('md4') and crypto.createCipheriv with weak ciphers."""

    rule_id = "SC246"
    cwe_id = 328
    severity = "medium"
    language = "javascript"
    message = "Use of weak hash/cipher (MD2/MD4/DES/RC4/RC2) — use AES or SHA-256+ (CWE-328)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(call_expression) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue

            dotted = js_dotted_name(func_node)

            # crypto.createHash("md4") / crypto.createHash("md2")
            if dotted == "crypto.createHash":
                args = js_call_arguments(call_node)
                if args and args[0].type == "string":
                    algo = _strip_quotes(plugin.node_text(args[0])).lower()
                    if algo in _WEAK_HASH_ALGOS:
                        findings.append(self._make_finding(call_node, plugin, file_path))
                continue

            # crypto.createCipheriv("des-cbc", ...) etc.
            if dotted in _CIPHER_TARGETS:
                args = js_call_arguments(call_node)
                if args and args[0].type == "string":
                    algo = _strip_quotes(plugin.node_text(args[0]))
                    if _is_weak_cipher_string(algo):
                        findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
