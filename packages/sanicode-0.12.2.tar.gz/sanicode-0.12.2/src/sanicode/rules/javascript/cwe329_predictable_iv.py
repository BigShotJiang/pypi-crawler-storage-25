"""Predictable IV detection rules for JavaScript (CWE-329).

SC247 — crypto.createCipheriv("aes-...-cbc", key, Buffer.alloc(N))    high  CWE-329
"""
from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.javascript._helpers import js_call_arguments, js_dotted_name
from sanicode.scanner.patterns import Finding


def _strip_quotes(s: str) -> str:
    for q in ('"""', "'''", "`", '"', "'"):
        if s.startswith(q) and s.endswith(q) and len(s) >= 2 * len(q):
            return s[len(q):-len(q)]
    return s


def _is_buffer_alloc(node) -> bool:
    """Check if a node is Buffer.alloc(N) — which zero-fills."""
    if node.type != "call_expression":
        return False
    func = node.child_by_field_name("function")
    if func is None:
        return False
    return js_dotted_name(func) == "Buffer.alloc"


class JSPredictableIVRule(Rule):
    """Detect crypto.createCipheriv with zero-filled Buffer.alloc IV."""

    rule_id = "SC247"
    cwe_id = 329
    severity = "high"
    language = "javascript"
    message = "Predictable IV — Buffer.alloc() is zero-filled; use crypto.randomBytes() (CWE-329)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(call_expression) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue
            if js_dotted_name(func_node) != "crypto.createCipheriv":
                continue

            args = js_call_arguments(call_node)
            if len(args) < 3:
                continue

            # Check cipher name contains "cbc"
            if args[0].type == "string":
                cipher = _strip_quotes(plugin.node_text(args[0])).lower()
                if "cbc" not in cipher:
                    continue
            else:
                continue

            # Check third arg is Buffer.alloc(N)
            if _is_buffer_alloc(args[2]):
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
