"""Input validation detection for JavaScript (CWE-20).

SC216 — parseInt/parseFloat/Number on untrusted input    medium  CWE-20
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.scanner.patterns import Finding

_PARSE_FUNCS = frozenset({"parseInt", "parseFloat", "Number"})

_EXTERNAL_KEYWORDS = ("req.", "params.", "query.", "body.", "process.argv", "process.env")


class JavaScriptInputValidationRule(Rule):
    """Detect numeric parsing without validation in JavaScript."""

    rule_id = "SC216"
    cwe_id = 20
    severity = "medium"
    language = "javascript"
    message = "Numeric parsing of external input without validation (CWE-20)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node
        call_captures = plugin.captures("(call_expression) @call", root)

        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue
            func_text = func_node.text.decode("utf-8") if func_node.text else ""
            if func_text not in _PARSE_FUNCS:
                continue
            args_text = call_node.text.decode("utf-8") if call_node.text else ""
            if any(kw in args_text for kw in _EXTERNAL_KEYWORDS):
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
