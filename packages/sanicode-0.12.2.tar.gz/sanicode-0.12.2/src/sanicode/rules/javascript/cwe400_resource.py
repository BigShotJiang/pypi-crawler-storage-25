"""ReDoS detection rules for JavaScript (CWE-1333).

SC218 — new RegExp() / String.match/search with non-literal pattern   medium  CWE-1333
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.javascript._helpers import js_call_arguments
from sanicode.scanner.patterns import Finding

# String methods that accept a regex pattern as their first argument.
_STRING_REGEX_METHODS = frozenset({"match", "search", "replace", "replaceAll", "split"})

# Node types considered safe (developer-controlled pattern).
_SAFE_PATTERN_TYPES = frozenset({"string", "regex"})


class JsReDoSRule(Rule):
    """Detect new RegExp() / String regex methods with non-literal pattern."""

    rule_id = "SC218"
    cwe_id = 1333
    severity = "medium"
    language = "javascript"
    message = (
        "Regex compiled with non-literal pattern — "
        "potential ReDoS risk (CWE-1333)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        # 1) new RegExp(dynamic)
        new_captures = plugin.captures("(new_expression) @new", root)
        for new_node in new_captures.get("new", []):
            ctor = new_node.child_by_field_name("constructor")
            if ctor is None:
                continue
            ctor_name = ctor.text.decode("utf-8") if ctor.text else ""
            if ctor_name != "RegExp":
                continue

            args = js_call_arguments(new_node)
            if not args:
                continue
            if args[0].type in _SAFE_PATTERN_TYPES:
                continue

            findings.append(self._make_finding(new_node, plugin, file_path))

        # 2) str.match(dynamic), str.search(dynamic), etc.
        call_captures = plugin.captures("(call_expression) @call", root)
        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None or func_node.type != "member_expression":
                continue

            prop = func_node.child_by_field_name("property")
            if prop is None or not prop.text:
                continue
            method_name = prop.text.decode("utf-8")
            if method_name not in _STRING_REGEX_METHODS:
                continue

            args = js_call_arguments(call_node)
            if not args:
                continue
            if args[0].type in _SAFE_PATTERN_TYPES:
                continue

            findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
