"""SQL injection via dynamic query construction (CWE-89).

SC206 — Database query with template literal or string concatenation    high  CWE-89
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.javascript._helpers import js_call_arguments, js_dotted_name
from sanicode.scanner.patterns import Finding

# Dotted names for database query functions.  Explicit enumeration avoids
# false positives on non-DB objects that happen to have .query()/.raw()
# methods (e.g. cache.query, graphql.raw).
_DB_QUERY_FUNCS = frozenset({
    # Generic / node-postgres / mysql2
    "db.query",
    "connection.query",
    "conn.query",
    "pool.query",
    "client.query",
    # Knex
    "knex.raw",
    "knex.select",
    # Sequelize
    "sequelize.query",
    # Prisma
    "prisma.$queryRaw",
    "prisma.$executeRaw",
    # TypeORM / generic manager
    "manager.query",
    "entityManager.query",
    "dataSource.query",
    # Better-sqlite3 / sql.js
    "database.exec",
    "database.prepare",
})


def _has_template_substitution(node) -> bool:
    """Check if a template_string has ${...} substitutions."""
    return any(child.type == "template_substitution" for child in node.children)


class JsSqliRule(Rule):
    """Detect DB queries with template literals or string concatenation — SQL injection risk.

    Flags calls to known database query functions when the first argument
    is a template string with substitutions or a binary expression
    (concatenation). Suppresses when second arg is an array (parameterized
    query pattern). Only matches explicitly enumerated DB client methods
    to avoid false positives on non-DB .query()/.raw() calls.
    """

    rule_id = "SC206"
    cwe_id = 89
    severity = "high"
    language = "javascript"
    message = "Database query with dynamic string — SQL injection risk (CWE-89)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(call_expression) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue

            dotted = js_dotted_name(func_node)
            if not any(
                dotted == func or dotted.endswith("." + func)
                for func in _DB_QUERY_FUNCS
            ):
                continue

            args = js_call_arguments(call_node)
            if not args:
                continue

            first_arg = args[0]
            is_dynamic = False

            # Template string with interpolation.
            if first_arg.type == "template_string" and _has_template_substitution(first_arg):
                is_dynamic = True
            # String concatenation.
            elif first_arg.type == "binary_expression":
                is_dynamic = True

            if not is_dynamic:
                continue

            # Safe path: second arg is array (parameterized query).
            if len(args) >= 2 and args[1].type == "array":
                continue

            findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
