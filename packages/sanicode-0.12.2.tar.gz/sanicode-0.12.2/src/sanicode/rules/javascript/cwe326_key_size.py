"""Weak key size detection rules for JavaScript (CWE-326).

SC245 — crypto.generateKeyPairSync with modulusLength < 2048    high  CWE-326
"""
from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.javascript._helpers import js_call_arguments, js_dotted_name
from sanicode.scanner.patterns import Finding

_GENERATE_TARGETS = frozenset({
    "crypto.generateKeyPairSync",
    "crypto.generateKeyPair",
})


def _int_value(node) -> int | None:
    """Extract integer from a JS number node."""
    if node.type == "number":
        text = node.text.decode("utf-8") if node.text else ""
        try:
            return int(text)
        except ValueError:
            return None
    return None


def _find_modulus_length(obj_node) -> int | None:
    """Look inside an object literal for modulusLength property value."""
    if obj_node.type != "object":
        return None
    for child in obj_node.children:
        if child.type == "pair":
            key = child.child_by_field_name("key")
            value = child.child_by_field_name("value")
            if key and key.text and key.text.decode("utf-8") == "modulusLength":
                if value:
                    return _int_value(value)
    return None


class JSWeakKeyRule(Rule):
    """Detect crypto.generateKeyPairSync with weak modulusLength."""

    rule_id = "SC245"
    cwe_id = 326
    severity = "high"
    language = "javascript"
    message = "Weak RSA key size \u2014 modulusLength must be at least 2048 bits (CWE-326)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(call_expression) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue
            if js_dotted_name(func_node) not in _GENERATE_TARGETS:
                continue
            args = js_call_arguments(call_node)
            # Look for the options object (typically second arg)
            for arg in args:
                if arg.type == "object":
                    val = _find_modulus_length(arg)
                    if val is not None and val < 2048:
                        findings.append(self._make_finding(call_node, plugin, file_path))
                        break

        return findings
