"""Clickjacking protection disabled or weakened (CWE-1021).

SC263 — X-Frame-Options removed or frameguard disabled    medium  CWE-1021
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.javascript._helpers import js_call_arguments, js_dotted_name
from sanicode.scanner.patterns import Finding

_SECURITY_HEADERS = frozenset({
    "x-frame-options",
    "content-security-policy",
})
_SET_METHODS = frozenset({"set", "header", "setHeader"})


def _str_content(node) -> str:
    """Extract unquoted string content from a JS string node."""
    if node.type not in ("string", "template_string"):
        return ""
    text = node.text.decode("utf-8") if node.text else ""
    return text.strip("'\"` ")


def _object_has_frameguard_false(args_node) -> bool:
    """Check if a JS object expression arg has frameguard: false."""
    if args_node is None:
        return False
    for child in args_node.children:
        if child.type == "object":
            for pair in child.children:
                if pair.type == "pair":
                    key_node = pair.child_by_field_name("key")
                    value_node = pair.child_by_field_name("value")
                    if key_node is None or value_node is None:
                        continue
                    key_text = key_node.text.decode("utf-8") if key_node.text else ""
                    key_text = key_text.strip("'\"")
                    if key_text != "frameguard":
                        continue
                    val_text = value_node.text.decode("utf-8") if value_node.text else ""
                    if val_text == "false":
                        return True
    return False


class JSClickjackingRule(Rule):
    """Detect removeHeader on security headers, helmet frameguard:false, or permissive set."""

    rule_id = "SC263"
    cwe_id = 1021
    severity = "medium"
    language = "javascript"
    message = (
        "Clickjacking protection disabled or weakened "
        "\u2014 verify X-Frame-Options/CSP configuration (CWE-1021)"
    )
    tags = ["clickjacking", "headers"]
    domain = "web"
    action = "review"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(call_expression) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            func_node = call_node.child_by_field_name("function")
            if func_node is None:
                continue
            dotted = js_dotted_name(func_node)
            method = dotted.rsplit(".", 1)[-1] if "." in dotted else dotted
            args = js_call_arguments(call_node)

            # Pattern 1: res.removeHeader("X-Frame-Options") or ("Content-Security-Policy")
            if method == "removeHeader":
                if not args:
                    continue
                header_text = _str_content(args[0]).lower()
                if header_text in _SECURITY_HEADERS:
                    findings.append(self._make_finding(call_node, plugin, file_path))

            # Pattern 2: helmet({ frameguard: false })
            elif method == "helmet":
                args_node = call_node.child_by_field_name("arguments")
                if _object_has_frameguard_false(args_node):
                    findings.append(self._make_finding(call_node, plugin, file_path))

            # Pattern 3: res.set("X-Frame-Options", "ALLOWALL") or res.setHeader(...)
            elif method in _SET_METHODS:
                if len(args) < 2:
                    continue
                header_text = _str_content(args[0]).lower()
                if "x-frame-options" not in header_text:
                    continue
                value_text = _str_content(args[1]).upper()
                if value_text == "ALLOWALL":
                    findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
