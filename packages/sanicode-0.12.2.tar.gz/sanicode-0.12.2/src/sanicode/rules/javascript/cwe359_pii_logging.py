"""PII exposure in log output for JavaScript (CWE-359).

SC253 — Logging call includes PII-named variable    medium  CWE-359
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules._sensitive_patterns import PII_VAR_PATTERN
from sanicode.rules.base import Rule, _walk
from sanicode.rules.javascript._helpers import js_dotted_name
from sanicode.scanner.patterns import Finding

_LOG_DOTTED: frozenset[str] = frozenset(
    {
        "console.log",
        "console.warn",
        "console.error",
        "console.info",
        "console.debug",
        "console.trace",
        "logger.info",
        "logger.debug",
        "logger.warn",
        "logger.error",
        "log.info",
        "log.debug",
        "log.warn",
        "log.error",
    }
)


class JavaScriptPiiLoggingRule(Rule):
    """Detect logging calls that include PII-named variable arguments."""

    rule_id = "SC253"
    cwe_id = 359
    severity = "medium"
    language = "javascript"
    message = (
        "Logging call includes PII-named variable "
        "— may expose personal information in logs (CWE-359)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        captures = plugin.captures("(call_expression) @call", tree.root_node)
        for call_node in captures.get("call", []):
            func = call_node.child_by_field_name("function")
            if func is None:
                continue
            name = js_dotted_name(func)
            if name not in _LOG_DOTTED:
                continue
            if self._has_pii_arg(call_node, plugin):
                findings.append(self._make_finding(call_node, plugin, file_path))
        return findings

    @staticmethod
    def _has_pii_arg(call_node, plugin) -> bool:
        args = call_node.child_by_field_name("arguments")
        if args is None:
            return False
        for child in _walk(args):
            if child.type == "identifier":
                name = plugin.node_text(child)
                if PII_VAR_PATTERN.search(name):
                    return True
        return False
