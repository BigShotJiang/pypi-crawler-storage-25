"""UI misrepresentation via security header removal for JavaScript (CWE-451).

SC264 — res.removeHeader() for security headers    medium  CWE-451

Note: X-Frame-Options and Content-Security-Policy are intentionally excluded
here because CWE-1021 (SC263) already targets those specifically for
clickjacking scenarios.  This rule focuses on the remaining security headers
whose removal misrepresents the overall security posture of the response.
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule, _walk
from sanicode.rules.javascript._helpers import js_call_arguments, js_dotted_name
from sanicode.scanner.patterns import Finding

# Security headers whose removal we flag (lower-cased for comparison).
# X-Frame-Options and Content-Security-Policy are handled by CWE-1021 (SC263).
_SECURITY_HEADERS: frozenset[str] = frozenset(
    {
        "x-content-type-options",
        "strict-transport-security",
        "x-xss-protection",
    }
)


def _strip_quotes(text: str) -> str:
    for q in ('"', "'", "`"):
        if text.startswith(q) and text.endswith(q) and len(text) >= 2:
            return text[1:-1]
    return text


class JSUiMisrepresentationRule(Rule):
    """Detect removal of security-relevant HTTP response headers (CWE-451).

    Explicitly removing headers such as ``X-Content-Type-Options``,
    ``Strict-Transport-Security``, or ``X-XSS-Protection`` weakens the
    browser-enforced security posture and misrepresents the security
    properties of the response to the client.
    """

    rule_id = "SC264"
    cwe_id = 451
    severity = "medium"
    language = "javascript"
    message = (
        "Security response header removed "
        "\u2014 may misrepresent security posture (CWE-451)"
    )
    tags = ["headers", "security_config"]
    domain = "web"
    action = "review"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in _walk(tree.root_node):
            if node.type != "call_expression":
                continue
            func_node = node.child_by_field_name("function")
            if func_node is None:
                continue
            dotted = js_dotted_name(func_node)
            # Match res.removeHeader / response.removeHeader (any object prefix)
            if not dotted.endswith(".removeHeader"):
                continue
            args = js_call_arguments(node)
            if not args:
                continue
            first = args[0]
            if first.type not in ("string", "template_string"):
                continue
            raw = first.text.decode("utf-8") if first.text else ""
            header = _strip_quotes(raw).lower()
            if header in _SECURITY_HEADERS:
                findings.append(self._make_finding(node, plugin, file_path))
        return findings
