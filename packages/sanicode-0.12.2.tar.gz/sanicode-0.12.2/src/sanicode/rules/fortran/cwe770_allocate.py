"""Uncontrolled resource consumption via ALLOCATE with non-literal size (CWE-770).

SC1104 — ALLOCATE with non-literal size    medium  CWE-770
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.fortran._helpers import (
    fortran_has_any_identifier,
    fortran_sized_alloc_exprs,
)
from sanicode.scanner.patterns import Finding


class FortranAllocateRule(Rule):
    """Detect ALLOCATE with non-literal size — uncontrolled resource consumption risk."""

    rule_id = "SC1104"
    cwe_id = 770
    severity = "medium"
    language = "fortran"
    message = "ALLOCATE with non-literal size — uncontrolled resource consumption risk (CWE-770)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if node.type != "allocate_statement":
                continue
            size_exprs = fortran_sized_alloc_exprs(node)
            if any(fortran_has_any_identifier(expr) for expr in size_exprs):
                findings.append(self._make_finding(node, plugin, file_path))
        return findings
