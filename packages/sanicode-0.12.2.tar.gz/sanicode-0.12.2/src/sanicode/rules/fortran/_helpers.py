"""Shared helpers for Fortran rule modules.

These mirror the private helpers in ``scanner/languages/fortran.py`` but
are kept here so rule modules don't need to reach into scanner internals.

.. note:: If you fix a bug in any helper here, also update the
   corresponding private helper in ``scanner/languages/fortran.py``.
"""

from __future__ import annotations

from tree_sitter import Node

# Node type constants for Fortran call forms.
FORTRAN_SUBROUTINE_CALL = "subroutine_call"
FORTRAN_CALL_EXPRESSION = "call_expression"


def fortran_call_name(node: Node) -> str:
    """Extract lowercase callee name from subroutine_call or call_expression.

    Fortran is case-insensitive; always returns a lowercase string.
    """
    if node.type == FORTRAN_SUBROUTINE_CALL:
        for child in node.children:
            if child.type == "identifier":
                return child.text.decode("utf-8").lower() if child.text else ""
        return ""
    if node.type == FORTRAN_CALL_EXPRESSION:
        if node.children and node.children[0].type == "identifier":
            return node.children[0].text.decode("utf-8").lower() if node.children[0].text else ""
        return ""
    return ""


def fortran_call_args(node: Node) -> list[Node]:
    """Get argument nodes from a call, skipping punctuation."""
    for child in node.children:
        if child.type == "argument_list":
            return [c for c in child.children if c.type not in ("(", ")", ",")]
    return []


def fortran_keyword_arg_value(args: list[Node], name: str) -> Node | None:
    """Find value node for a keyword argument by name (case-insensitive).

    Returns the value node if the named keyword argument is present,
    or None if not found.
    """
    target = name.lower()
    for arg in args:
        if arg.type == "keyword_argument":
            kw_name = arg.child_by_field_name("name")
            if kw_name and kw_name.text and kw_name.text.decode("utf-8").lower() == target:
                return arg.child_by_field_name("value")
    return None


def fortran_is_string_literal(node: Node) -> bool:
    """Return True if node is a string literal."""
    return node.type == "string_literal"


def fortran_sized_alloc_exprs(node: Node) -> list[Node]:
    """Extract size expression nodes from an allocate_statement's sized_allocation children."""
    exprs: list[Node] = []
    for child in node.children:
        if child.type == "sized_allocation":
            # The size dimensions are inside a 'size' child
            for sub in child.children:
                if sub.type == "size":
                    for dim in sub.children:
                        if dim.type not in ("(", ")", ","):
                            exprs.append(dim)
    return exprs


def fortran_has_any_identifier(node: Node) -> bool:
    """Return True if node or any descendant contains an identifier (variable reference)."""
    stack = [node]
    while stack:
        current = stack.pop()
        if current.type == "identifier":
            return True
        stack.extend(current.children)
    return False
