"""Command injection via CALL SYSTEM() (CWE-78).

SC1101 — CALL SYSTEM()    high  CWE-78
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.fortran._helpers import FORTRAN_SUBROUTINE_CALL, fortran_call_name
from sanicode.scanner.patterns import Finding


class FortranSystemRule(Rule):
    """Detect CALL SYSTEM() — command injection risk."""

    rule_id = "SC1101"
    cwe_id = 78
    severity = "high"
    language = "fortran"
    message = "Use of CALL SYSTEM() — command injection risk (CWE-78)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if node.type != FORTRAN_SUBROUTINE_CALL:
                continue
            if fortran_call_name(node) == "system":
                findings.append(self._make_finding(node, plugin, file_path))
        return findings
