"""Untrusted code inclusion via INCLUDE statement (CWE-829).

SC1107 — INCLUDE statement    medium  CWE-829
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.scanner.patterns import Finding


class FortranIncludeRule(Rule):
    """Detect INCLUDE statements — untrusted code inclusion risk."""

    rule_id = "SC1107"
    cwe_id = 829
    severity = "medium"
    language = "fortran"
    message = "INCLUDE statement — untrusted code inclusion risk (CWE-829)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if node.type == "include_statement":
                findings.append(self._make_finding(node, plugin, file_path))
        return findings
