"""Fortran-specific pattern detection rules."""
