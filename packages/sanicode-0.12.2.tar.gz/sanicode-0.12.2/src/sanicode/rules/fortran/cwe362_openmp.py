"""OpenMP parallel region detection (CWE-362).

SC1114 -- OpenMP PARALLEL directive    medium  CWE-362
"""

from __future__ import annotations

import re
from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.scanner.patterns import Finding

_OMP_PARALLEL_RE = re.compile(r"!\$omp\s+parallel", re.IGNORECASE)


class FortranOpenMPRule(Rule):
    """Detect OpenMP parallel directives -- potential race condition risk.

    OpenMP ``!$OMP PARALLEL`` directives introduce concurrent execution
    regions that require careful synchronization to avoid data races.
    """

    rule_id = "SC1114"
    cwe_id = 362
    severity = "medium"
    language = "fortran"
    message = "OpenMP PARALLEL directive — potential race condition (CWE-362)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if node.type != "comment":
                continue
            text = plugin.node_text(node)
            if _OMP_PARALLEL_RE.search(text):
                findings.append(self._make_finding(node, plugin, file_path))
        return findings
