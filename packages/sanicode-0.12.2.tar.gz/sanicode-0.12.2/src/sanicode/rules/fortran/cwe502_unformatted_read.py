"""Insecure deserialization via OPEN with FORM='UNFORMATTED' (CWE-502).

SC1106 — OPEN with FORM='UNFORMATTED'    medium  CWE-502
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.fortran._helpers import (
    fortran_is_string_literal,
    fortran_keyword_arg_value,
)
from sanicode.scanner.patterns import Finding


class FortranUnformattedRule(Rule):
    """Detect OPEN with FORM='UNFORMATTED' — insecure deserialization of binary data."""

    rule_id = "SC1106"
    cwe_id = 502
    severity = "medium"
    language = "fortran"
    message = "OPEN with FORM='UNFORMATTED' — insecure deserialization of binary data (CWE-502)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if node.type != "open_statement":
                continue
            kw_args = [c for c in node.children if c.type == "keyword_argument"]
            form_value = fortran_keyword_arg_value(kw_args, "form")
            if form_value is None:
                continue
            if not fortran_is_string_literal(form_value):
                continue
            if form_value.text and "unformatted" in form_value.text.decode("utf-8").lower():
                findings.append(self._make_finding(node, plugin, file_path))
        return findings
