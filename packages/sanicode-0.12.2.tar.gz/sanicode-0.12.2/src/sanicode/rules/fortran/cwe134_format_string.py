"""Non-literal format string in WRITE/PRINT (CWE-134).

SC1113 -- Non-literal format string    medium  CWE-134
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.fortran._helpers import (
    fortran_has_any_identifier,
    fortran_keyword_arg_value,
)
from sanicode.scanner.patterns import Finding


class FortranFormatStringRule(Rule):
    """Detect non-literal format strings in WRITE/PRINT statements.

    Using a variable as a format specifier can lead to format string
    vulnerabilities if the variable is user-controlled.
    """

    rule_id = "SC1113"
    cwe_id = 134
    severity = "medium"
    language = "fortran"
    message = "Non-literal format string in WRITE/PRINT — format string risk (CWE-134)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if node.type not in ("write_statement", "print_statement"):
                continue
            if self._has_variable_format(node, plugin):
                findings.append(self._make_finding(node, plugin, file_path))
        return findings

    @staticmethod
    def _has_variable_format(node, plugin) -> bool:
        """Check whether the format specifier is a variable (non-literal).

        For write_statement: the format is in a format_identifier child
        or a FMT= keyword argument.
        For print_statement: the format is in a format_identifier child.
        """
        # Check for FMT= keyword argument first (explicit keyword form)
        kw_args = [c for c in node.children if c.type == "keyword_argument"]
        fmt_value = fortran_keyword_arg_value(kw_args, "fmt")
        if fmt_value is not None:
            return fortran_has_any_identifier(fmt_value)

        # Check format_identifier child (positional form)
        for child in node.children:
            if child.type == "format_identifier":
                text = plugin.node_text(child)
                # '*' means list-directed (free-format) -- safe
                if text.strip() == "*":
                    return False
                # String literal format -- safe
                if child.child_count > 0 and child.children[0].type == "string_literal":
                    return False
                if text.startswith("'") or text.startswith('"'):
                    return False
                # Otherwise it's a variable reference -- flag it
                return True

        return False
