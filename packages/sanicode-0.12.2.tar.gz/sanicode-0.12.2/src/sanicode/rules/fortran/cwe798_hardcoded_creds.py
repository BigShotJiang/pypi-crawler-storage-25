"""Hardcoded credential detection rules for Fortran (CWE-798).

SC1111 — hardcoded secret in variable assignment    high  CWE-798
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules._sensitive_patterns import (
    MIN_SECRET_LEN,
    SECRET_VAR_PATTERN,
    is_placeholder,
    strip_quotes,
)
from sanicode.rules.base import Rule
from sanicode.scanner.patterns import Finding


class FortranHardcodedCredentialsRule(Rule):
    """Detect hardcoded credentials in Fortran variable assignments.

    Fortran is case-insensitive, so variable names are lowercased before
    pattern matching.  Only string_literal right-hand sides are flagged
    (no expression evaluation is possible in Fortran assignment to a
    character variable at the source level).
    """

    rule_id = "SC1111"
    cwe_id = 798
    severity = "high"
    language = "fortran"
    message = "Hardcoded credential — secret value in variable (CWE-798)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if node.type != "assignment_statement":
                continue
            left = node.child_by_field_name("left")
            right = node.child_by_field_name("right")
            if left is None or right is None:
                continue
            if left.type != "identifier":
                continue
            if right.type != "string_literal":
                continue
            # Fortran is case-insensitive — lowercase before matching.
            var_name = plugin.node_text(left).lower()
            if not SECRET_VAR_PATTERN.search(var_name):
                continue
            raw_value = plugin.node_text(right)
            value = strip_quotes(raw_value)
            if len(value) < MIN_SECRET_LEN or is_placeholder(value):
                continue
            findings.append(self._make_finding(node, plugin, file_path))
        return findings
