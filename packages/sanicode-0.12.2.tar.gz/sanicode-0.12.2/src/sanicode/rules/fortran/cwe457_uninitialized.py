"""INTENT(OUT) parameter detection (CWE-457).

SC1115 -- INTENT(OUT) parameter    medium  CWE-457
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.scanner.patterns import Finding


class FortranIntentOutRule(Rule):
    """Detect INTENT(OUT) parameter declarations.

    INTENT(OUT) parameters are undefined on entry to a subroutine and
    must be assigned before use.  Using them before assignment is
    undefined behavior.  This rule flags the declaration as informational
    to prompt manual review of the subroutine body.
    """

    rule_id = "SC1115"
    cwe_id = 457
    severity = "medium"
    language = "fortran"
    message = "INTENT(OUT) parameter — must be assigned before use (CWE-457)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if node.type != "variable_declaration":
                continue
            if self._has_intent_out(node):
                findings.append(self._make_finding(node, plugin, file_path))
        return findings

    @staticmethod
    def _has_intent_out(node) -> bool:
        """Return True if the declaration has an INTENT(OUT) qualifier."""
        for child in node.children:
            if child.type != "type_qualifier":
                continue
            # Look for intent(...) with 'out' child
            has_intent = False
            has_out = False
            for gc in child.children:
                if gc.type == "intent":
                    has_intent = True
                elif gc.type == "out":
                    has_out = True
            if has_intent and has_out:
                return True
        return False
