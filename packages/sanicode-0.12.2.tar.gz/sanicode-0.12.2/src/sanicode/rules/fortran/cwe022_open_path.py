"""Path traversal via OPEN with non-literal file path (CWE-22).

SC1103 — OPEN with non-literal file= path    high  CWE-22
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.fortran._helpers import (
    fortran_is_string_literal,
    fortran_keyword_arg_value,
)
from sanicode.scanner.patterns import Finding


class FortranOpenPathRule(Rule):
    """Detect OPEN with non-literal file= path — path traversal risk."""

    rule_id = "SC1103"
    cwe_id = 22
    severity = "high"
    language = "fortran"
    message = "OPEN with non-literal file= path — path traversal risk (CWE-22)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if node.type != "open_statement":
                continue
            # Collect keyword args directly from open_statement children
            kw_args = [c for c in node.children if c.type == "keyword_argument"]
            file_value = fortran_keyword_arg_value(kw_args, "file")
            if file_value is not None and not fortran_is_string_literal(file_value):
                findings.append(self._make_finding(node, plugin, file_path))
        return findings
