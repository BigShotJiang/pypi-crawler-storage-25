"""Unsafe type punning via TRANSFER() (CWE-843).

SC1108 — TRANSFER() function    medium  CWE-843
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.fortran._helpers import FORTRAN_CALL_EXPRESSION, fortran_call_name
from sanicode.scanner.patterns import Finding


class FortranTransferRule(Rule):
    """Detect use of TRANSFER() — unsafe type punning."""

    rule_id = "SC1108"
    cwe_id = 843
    severity = "medium"
    language = "fortran"
    message = "Use of TRANSFER() — unsafe type punning (CWE-843)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if node.type != FORTRAN_CALL_EXPRESSION:
                continue
            if fortran_call_name(node) == "transfer":
                findings.append(self._make_finding(node, plugin, file_path))
        return findings
