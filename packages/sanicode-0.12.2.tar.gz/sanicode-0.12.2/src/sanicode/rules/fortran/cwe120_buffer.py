"""ALLOCATE without STAT= error handling (CWE-120).

SC1112 -- ALLOCATE without STAT=    medium  CWE-120
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.fortran._helpers import fortran_keyword_arg_value
from sanicode.scanner.patterns import Finding


class FortranAllocateNoStatRule(Rule):
    """Detect ALLOCATE without STAT= error handling.

    A failed ALLOCATE without STAT= causes immediate program termination.
    Adding STAT= allows the program to handle allocation failures gracefully.
    """

    rule_id = "SC1112"
    cwe_id = 120
    severity = "medium"
    language = "fortran"
    message = "ALLOCATE without STAT= error handling — unhandled allocation failure (CWE-120)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if node.type != "allocate_statement":
                continue
            # Collect keyword args from the allocate_statement children
            kw_args = [c for c in node.children if c.type == "keyword_argument"]
            stat_value = fortran_keyword_arg_value(kw_args, "stat")
            if stat_value is None:
                findings.append(self._make_finding(node, plugin, file_path))
        return findings
