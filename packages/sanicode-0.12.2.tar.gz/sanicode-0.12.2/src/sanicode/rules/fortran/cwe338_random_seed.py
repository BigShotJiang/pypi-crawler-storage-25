"""Weak/predictable randomness via CALL RANDOM_SEED(PUT=...) (CWE-338).

SC1105 — CALL RANDOM_SEED(PUT=...)    medium  CWE-338
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.fortran._helpers import (
    FORTRAN_SUBROUTINE_CALL,
    fortran_call_args,
    fortran_call_name,
    fortran_keyword_arg_value,
)
from sanicode.scanner.patterns import Finding


class FortranRandomSeedRule(Rule):
    """Detect CALL RANDOM_SEED(PUT=...) — weak/predictable randomness risk.

    Bare ``CALL RANDOM_SEED()`` (no PUT= argument) re-seeds from system
    entropy and is safe — only the PUT= form is flagged.
    """

    rule_id = "SC1105"
    cwe_id = 338
    severity = "medium"
    language = "fortran"
    message = "CALL RANDOM_SEED(PUT=...) — weak/predictable randomness (CWE-338)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if node.type != FORTRAN_SUBROUTINE_CALL:
                continue
            if fortran_call_name(node) != "random_seed":
                continue
            args = fortran_call_args(node)
            if fortran_keyword_arg_value(args, "put") is not None:
                findings.append(self._make_finding(node, plugin, file_path))
        return findings
