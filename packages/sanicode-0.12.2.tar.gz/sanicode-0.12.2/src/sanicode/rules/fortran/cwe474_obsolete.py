"""Obsolete memory aliasing constructs EQUIVALENCE/COMMON (CWE-474).

SC1109 — EQUIVALENCE/COMMON    low  CWE-474
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.scanner.patterns import Finding

_OBSOLETE_TYPES = frozenset({"equivalence_statement", "common_statement"})


class FortranObsoleteRule(Rule):
    """Detect EQUIVALENCE/COMMON — obsolete memory aliasing constructs."""

    rule_id = "SC1109"
    cwe_id = 474
    severity = "low"
    language = "fortran"
    message = "EQUIVALENCE/COMMON — obsolete memory aliasing construct (CWE-474)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if node.type in _OBSOLETE_TYPES:
                findings.append(self._make_finding(node, plugin, file_path))
        return findings
