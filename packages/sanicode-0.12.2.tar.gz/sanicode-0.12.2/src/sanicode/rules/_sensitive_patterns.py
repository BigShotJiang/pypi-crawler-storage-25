"""Shared patterns for detecting sensitive variable names and values.

Used by CWE-798, CWE-532, CWE-916/312/522, CWE-359, and other rules that
need to identify credential- or secret-related identifiers.
"""

from __future__ import annotations

import re

# Variable names that strongly suggest a secret value.
SECRET_VAR_PATTERN = re.compile(
    r"(password|passwd|secret|api_key|apikey|api_secret|token|auth_token|"
    r"access_key|private_key|credentials?|db_pass|dbpass)",
    re.IGNORECASE,
)

# Variable names that strongly suggest a PII value.
# Uses compound terms only to avoid false positives on generic words.
PII_VAR_PATTERN = re.compile(
    r"(ssn|social_security|date_of_birth|birth_date|"
    r"credit_card|card_number|phone_number|"
    r"email_address|street_address|"
    r"zip_code|postal_code|driver_license|passport_number)",
    re.IGNORECASE,
)

# String values that are clearly placeholders, not real secrets.
# Compared case-insensitively via ``is_placeholder()``.
PLACEHOLDER_VALUES: frozenset[str] = frozenset(
    {
        "",
        "changeme",
        "change_me",
        "placeholder",
        "todo",
        "fixme",
        "your_secret_here",
    }
)

MIN_SECRET_LEN = 3


def is_placeholder(value: str) -> bool:
    """Return True if *value* is a known placeholder string."""
    return value.lower() in PLACEHOLDER_VALUES


def strip_quotes(s: str, extra_quotes: tuple[str, ...] = ()) -> str:
    """Remove surrounding quote characters from a string literal.

    Checks *extra_quotes* first (for language-specific quotes like
    backticks), then falls back to standard triple-quote and single-quote
    pairs.
    """
    for q in (*extra_quotes, '"""', "'''", '"', "'"):
        if s.startswith(q) and s.endswith(q) and len(s) >= 2 * len(q):
            return s[len(q) : -len(q)]
    return s
