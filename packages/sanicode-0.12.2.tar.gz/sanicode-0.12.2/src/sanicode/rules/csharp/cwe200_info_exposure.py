"""Information exposure detection for C# (CWE-200).

SC618 — .StackTrace property access   medium  CWE-200
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.scanner.patterns import Finding


class CSharpInfoExposureRule(Rule):
    """Detect .StackTrace access — exposes stack trace information."""

    rule_id = "SC618"
    cwe_id = 200
    severity = "medium"
    language = "csharp"
    message = "Stack trace access via .StackTrace — information disclosure risk (CWE-200)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        captures = plugin.captures(
            "(member_access_expression) @access", tree.root_node
        )

        for access_node in captures.get("access", []):
            name_node = access_node.child_by_field_name("name")
            if name_node is None:
                continue
            name_text = name_node.text.decode("utf-8") if name_node.text else ""
            if name_text == "StackTrace":
                findings.append(self._make_finding(access_node, plugin, file_path))

        return findings
