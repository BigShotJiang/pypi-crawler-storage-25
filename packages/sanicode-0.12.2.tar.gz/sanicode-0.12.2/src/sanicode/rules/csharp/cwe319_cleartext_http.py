"""Cleartext HTTP transmission detection (CWE-319).

SC638 — HTTP request using cleartext http:// URL    medium  CWE-319
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.csharp._helpers import csharp_call_arguments, csharp_method_name
from sanicode.scanner.patterns import Finding

_TARGETS: dict[str, frozenset[str]] = {
    "HttpClient": frozenset({"GetAsync", "PostAsync", "SendAsync", "GetStringAsync"}),
    "WebClient": frozenset({"DownloadString", "DownloadData"}),
}

_CS_STRING_TYPES = frozenset({"string_literal", "verbatim_string_literal"})

_LOOPBACK_PREFIXES = (
    "http://localhost",
    "http://127.",
    "http://0.0.0.0",
    "http://[::1]",
)


def _extract_cs_string(node) -> str:
    """Extract inner text from a C# string_literal or verbatim_string_literal node."""
    if node.text is None:
        return ""
    text = node.text.decode("utf-8")
    if node.type == "string_literal":
        # Regular string: wrapped in double quotes
        if len(text) >= 2 and text[0] == '"' and text[-1] == '"':
            return text[1:-1]
    if node.type == "verbatim_string_literal":
        # Verbatim string: wrapped in @"..."
        if text.startswith('@"') and text.endswith('"'):
            return text[2:-1]
    return text


def _normalize_receiver(receiver: str) -> str:
    """Normalize a C# receiver string to extract the type name.

    Handles chained-constructor patterns like ``new HttpClient()`` → ``HttpClient``.
    A plain identifier (``client``) is left as-is since we can't know its type
    statically without type inference.
    """
    # "new TypeName(...)" — extract TypeName
    if receiver.startswith("new "):
        rest = receiver[4:]
        paren_idx = rest.find("(")
        if paren_idx != -1:
            return rest[:paren_idx].strip()
        return rest.strip()
    return receiver


def _is_cleartext_http_cs(node) -> bool:
    """Return True if a C# string literal contains a non-loopback http:// URL."""
    if node.type not in _CS_STRING_TYPES:
        return False
    inner = _extract_cs_string(node)
    lower = inner.lower()
    if not lower.startswith("http://"):
        return False
    for prefix in _LOOPBACK_PREFIXES:
        if lower.startswith(prefix):
            return False
    return True


class CSharpCleartextHttpRule(Rule):
    """Detect C# HttpClient/WebClient calls using a hardcoded cleartext http:// URL.

    Unlike SSRF (CWE-918) which flags non-literal URLs, this rule flags
    literal URLs that use http:// instead of https://, indicating traffic
    is sent in cleartext over the network.
    """

    rule_id = "SC638"
    cwe_id = 319
    severity = "medium"
    language = "csharp"
    message = "HTTP request uses cleartext http:// URL — use https:// (CWE-319)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if node.type != "invocation_expression":
                continue
            receiver, method = csharp_method_name(node)
            targets = _TARGETS.get(_normalize_receiver(receiver))
            if targets is None or method not in targets:
                continue
            args = csharp_call_arguments(node)
            if not args:
                continue
            if _is_cleartext_http_cs(args[0]):
                findings.append(self._make_finding(node, plugin, file_path))
        return findings
