"""NULL pointer dereference detection for C# (CWE-476).

SC616 — Member access on nullable LINQ/environment return    high  CWE-476
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.scanner.patterns import Finding

# Methods that commonly return null in C#/.NET.
_NULLABLE_METHODS = frozenset({
    "FirstOrDefault", "LastOrDefault", "SingleOrDefault",
    "ElementAtOrDefault", "Find", "FindLast",
    "GetValueOrDefault", "GetEnvironmentVariable",
})


class CSharpNullDerefRule(Rule):
    """Detect member access on nullable return value (e.g. list.FirstOrDefault().Length)."""

    rule_id = "SC616"
    cwe_id = 476
    severity = "high"
    language = "csharp"
    message = (
        "Member access on nullable return value — "
        "null pointer dereference risk (CWE-476)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        # Find member_access_expression nodes (e.g., expr.Member)
        ma_captures = plugin.captures(
            "(member_access_expression) @ma", root
        )
        for ma_node in ma_captures.get("ma", []):
            # The "expression" field is the left side (what we access a member on)
            expr = ma_node.child_by_field_name("expression")
            if expr is None or expr.type != "invocation_expression":
                continue
            # Extract the actual method name from the invocation expression.
            # invocation_expression children: member_access_expression + argument_list.
            # The member_access_expression has a "name" field with the method name.
            method_name = self._invocation_method_name(expr)
            if method_name in _NULLABLE_METHODS:
                findings.append(self._make_finding(ma_node, plugin, file_path))

        return findings

    @staticmethod
    def _invocation_method_name(invocation_node) -> str:
        """Extract the method name from an invocation_expression node.

        The structure is: invocation_expression → member_access_expression → name.
        Falls back to full text if the structure doesn't match.
        """
        for child in invocation_node.children:
            if child.type == "member_access_expression":
                name_node = child.child_by_field_name("name")
                if name_node is not None and name_node.text:
                    return name_node.text.decode("utf-8")
        # Fallback: extract the last dotted segment from the text
        text = invocation_node.text.decode("utf-8") if invocation_node.text else ""
        # Strip the argument list
        paren_idx = text.find("(")
        if paren_idx > 0:
            text = text[:paren_idx]
        return text.rsplit(".", 1)[-1] if text else ""
