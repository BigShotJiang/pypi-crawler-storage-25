"""File operations with externally controlled path (CWE-610).

SC650 — File operation with externally controlled path — medium  CWE-610
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.csharp._helpers import (
    csharp_call_arguments,
    csharp_dotted_name,
    csharp_method_name,
)
from sanicode.scanner.patterns import Finding

# Static File.* methods where first arg is the path
_FILE_METHODS = frozenset({
    "ReadAllText",
    "ReadAllLines",
    "ReadAllBytes",
    "Open",
    "OpenRead",
    "OpenText",
    "OpenWrite",
    "Create",
    "AppendAllText",
    "WriteAllText",
    "WriteAllLines",
    "WriteAllBytes",
})

_CS_STRING_TYPES = frozenset({"string_literal", "verbatim_string_literal"})


class CSharpExternalReferenceRule(Rule):
    """Detect File.* calls and StreamReader construction with a non-literal path."""

    rule_id = "SC650"
    cwe_id = 610
    severity = "medium"
    language = "csharp"
    message = (
        "File operation with externally controlled path \u2014"
        " verify path is validated (CWE-610)"
    )
    tags = ["path_traversal", "file_io"]
    domain = "web"
    action = "review"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []

        # Pattern 1: File.ReadAllText(path), File.Open(path), etc.
        for node in plugin.walk(tree.root_node):
            if node.type == "invocation_expression":
                receiver, method = csharp_method_name(node)
                if receiver == "File" and method in _FILE_METHODS:
                    args = csharp_call_arguments(node)
                    if args and args[0].type not in _CS_STRING_TYPES:
                        findings.append(self._make_finding(node, plugin, file_path))

            elif node.type == "object_creation_expression":
                # new StreamReader(path, ...)
                type_node = node.child_by_field_name("type")
                if type_node is None:
                    continue
                type_name = csharp_dotted_name(type_node)
                if type_name != "StreamReader":
                    continue
                args = csharp_call_arguments(node)
                if args and args[0].type not in _CS_STRING_TYPES:
                    findings.append(self._make_finding(node, plugin, file_path))

        return findings
