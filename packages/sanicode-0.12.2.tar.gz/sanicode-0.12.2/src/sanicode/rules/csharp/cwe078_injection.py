"""Command injection detection rules for C# (CWE-78).

SC601 — Process.Start() / new ProcessStartInfo()    high  CWE-78
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.csharp._helpers import csharp_method_name
from sanicode.scanner.patterns import Finding

_PROCESS_RECEIVERS = frozenset({"Process", "System.Diagnostics.Process"})


class CSharpProcessStartRule(Rule):
    """Detect Process.Start() and ProcessStartInfo — command injection risk."""

    rule_id = "SC601"
    cwe_id = 78
    severity = "high"
    language = "csharp"
    message = (
        "Use of Process.Start() or ProcessStartInfo — "
        "command injection risk (CWE-78)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        # Pattern 1: Process.Start(...) invocations
        call_captures = plugin.captures("(invocation_expression) @call", root)
        for call_node in call_captures.get("call", []):
            recv, method = csharp_method_name(call_node)
            if method == "Start" and recv in _PROCESS_RECEIVERS:
                findings.append(self._make_finding(call_node, plugin, file_path))

        # Pattern 2: new ProcessStartInfo(...) object creation
        new_captures = plugin.captures("(object_creation_expression) @new", root)
        for new_node in new_captures.get("new", []):
            type_node = new_node.child_by_field_name("type")
            if type_node and type_node.text:
                type_name = type_node.text.decode("utf-8")
                if type_name == "ProcessStartInfo":
                    findings.append(self._make_finding(new_node, plugin, file_path))

        return findings
