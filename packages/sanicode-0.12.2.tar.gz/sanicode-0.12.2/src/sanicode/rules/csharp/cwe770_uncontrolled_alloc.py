"""CWE-770 uncontrolled resource allocation for C#.

SC634 — array allocation with non-literal size    medium  CWE-770
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.scanner.patterns import Finding

_LITERAL_TYPES = frozenset({"integer_literal", "real_literal"})


class CSharpUncontrolledAllocRule(Rule):
    """Flag array creation with dynamic (non-literal) sizes."""

    rule_id = "SC634"
    cwe_id = 770
    severity = "medium"
    language = "csharp"
    message = (
        "Array allocated with a non-literal size — "
        "an attacker-controlled value can cause excessive memory allocation (CWE-770)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []

        for node in plugin.captures(
            "(array_creation_expression) @n", tree.root_node
        ).get("n", []):
            if self._has_dynamic_size(node):
                findings.append(self._make_finding(node, plugin, file_path))

        return findings

    @staticmethod
    def _has_dynamic_size(node) -> bool:
        """Return True if any rank specifier contains a non-literal expression.

        In the tree-sitter C# grammar, ``array_creation_expression`` has an
        ``array_type`` child, which in turn contains the ``array_rank_specifier``.
        """
        for child in node.children:
            if child.type != "array_type":
                continue
            for rank in child.children:
                if rank.type != "array_rank_specifier":
                    continue
                for expr in rank.children:
                    if expr.type in ("[", "]", ","):
                        continue
                    # An empty rank has no expression children — skip
                    if expr.type not in _LITERAL_TYPES:
                        return True
        return False
