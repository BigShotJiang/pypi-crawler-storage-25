"""ReDoS detection rules for C# (CWE-1333).

SC609 — new Regex() with non-literal pattern   medium  CWE-1333
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.csharp._helpers import csharp_call_arguments
from sanicode.scanner.patterns import Finding

# Node types that represent compile-time constant string patterns — safe to skip.
_LITERAL_STRING_TYPES = frozenset({"string_literal", "verbatim_string_literal"})


class CSharpRegexRule(Rule):
    """Detect new Regex() with a non-literal pattern — potential ReDoS risk."""

    rule_id = "SC609"
    cwe_id = 1333
    severity = "medium"
    language = "csharp"
    message = (
        "Regex constructed with non-literal pattern — "
        "potential ReDoS risk (CWE-1333)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        new_captures = plugin.captures("(object_creation_expression) @new", root)
        for new_node in new_captures.get("new", []):
            type_node = new_node.child_by_field_name("type")
            if type_node is None:
                continue
            type_name = type_node.text.decode("utf-8") if type_node.text else ""
            if type_name != "Regex":
                continue

            args = csharp_call_arguments(new_node)
            if not args:
                continue

            first_arg = args[0]
            # Safe: compile-time string literal — the pattern is fixed and
            # can be reviewed statically.
            if first_arg.type in _LITERAL_STRING_TYPES:
                continue

            findings.append(self._make_finding(new_node, plugin, file_path))

        return findings
