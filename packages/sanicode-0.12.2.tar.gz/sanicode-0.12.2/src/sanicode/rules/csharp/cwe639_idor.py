"""IDOR detection for C# (CWE-639).

SC647 — User input flows directly into database lookup    medium  CWE-639
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.csharp._helpers import csharp_method_name
from sanicode.scanner.patterns import Finding

_DB_METHODS = frozenset({
    "Find",
    "FindAsync",
    "FirstOrDefault",
    "FirstOrDefaultAsync",
    "SingleOrDefault",
    "SingleOrDefaultAsync",
})
_REQUEST_PATTERNS = ("Request.Query", "Request.RouteValues")


class CSharpIdorRule(Rule):
    """Detect EF Core lookups with user-controlled request parameters."""

    rule_id = "SC647"
    cwe_id = 639
    severity = "medium"
    language = "csharp"
    tags = ["auth", "idor"]
    domain = "access_control"
    message = (
        "User input flows directly into database lookup — "
        "potential IDOR vulnerability (CWE-639)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(invocation_expression) @call", tree.root_node)
        for call_node in call_captures.get("call", []):
            _, method = csharp_method_name(call_node)
            if method not in _DB_METHODS:
                continue

            args_node = None
            for child in call_node.children:
                if child.type == "argument_list":
                    args_node = child
                    break
            if args_node is None:
                continue
            args_text = plugin.node_text(args_node)

            if any(pat in args_text for pat in _REQUEST_PATTERNS):
                findings.append(self._make_finding(call_node, plugin, file_path))
        return findings
