"""Sensitive information in log output for C# (CWE-532).

SC619 — Logging call includes secret-named variable    medium  CWE-532
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules._sensitive_patterns import SECRET_VAR_PATTERN
from sanicode.rules.base import Rule, _walk
from sanicode.rules.csharp._helpers import csharp_dotted_name
from sanicode.scanner.patterns import Finding

_LOG_DOTTED: frozenset[str] = frozenset(
    {
        "Console.WriteLine",
        "Console.Write",
        "Debug.WriteLine",
        "Trace.WriteLine",
        "logger.LogInformation",
        "logger.LogDebug",
        "logger.LogWarning",
        "logger.LogError",
        "logger.LogCritical",
        "Logger.LogInformation",
        "Logger.LogDebug",
        "Logger.LogWarning",
        "Logger.LogError",
    }
)


class CSharpLogSecretsRule(Rule):
    """Detect logging calls that include secret-named variable arguments."""

    rule_id = "SC619"
    cwe_id = 532
    severity = "medium"
    language = "csharp"
    message = (
        "Logging call includes secret-named variable "
        "— may expose credentials in logs (CWE-532)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        captures = plugin.captures(
            "(invocation_expression) @call", tree.root_node
        )
        for call_node in captures.get("call", []):
            func = call_node.child_by_field_name("function")
            if func is None:
                continue
            name = csharp_dotted_name(func)
            if name not in _LOG_DOTTED:
                continue
            if self._has_secret_arg(call_node, plugin):
                findings.append(self._make_finding(call_node, plugin, file_path))
        return findings

    @staticmethod
    def _has_secret_arg(call_node, plugin) -> bool:
        args = call_node.child_by_field_name("arguments")
        if args is None:
            return False
        for child in _walk(args):
            if child.type == "identifier":
                name = plugin.node_text(child)
                if SECRET_VAR_PATTERN.search(name):
                    return True
        return False
