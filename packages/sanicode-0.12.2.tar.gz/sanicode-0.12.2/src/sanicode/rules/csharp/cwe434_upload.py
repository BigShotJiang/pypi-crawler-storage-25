"""Unrestricted file upload detection for C# (CWE-434).

SC615 — IFormFile CopyTo/CopyToAsync without validation    medium  CWE-434
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.csharp._helpers import csharp_method_name
from sanicode.scanner.patterns import Finding

_UPLOAD_METHODS = frozenset({"CopyTo", "CopyToAsync", "OpenReadStream"})
_UPLOAD_RECEIVER_KEYWORDS = frozenset({"file", "upload", "form"})


class CSharpFileUploadRule(Rule):
    """Detect IFormFile usage without type validation in ASP.NET."""

    rule_id = "SC615"
    cwe_id = 434
    severity = "medium"
    language = "csharp"
    message = "File upload without type validation — unrestricted upload risk (CWE-434)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        call_captures = plugin.captures("(invocation_expression) @call", root)
        for call_node in call_captures.get("call", []):
            recv, method = csharp_method_name(call_node)
            if method not in _UPLOAD_METHODS:
                continue
            recv_lower = recv.lower()
            if any(kw in recv_lower for kw in _UPLOAD_RECEIVER_KEYWORDS):
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
