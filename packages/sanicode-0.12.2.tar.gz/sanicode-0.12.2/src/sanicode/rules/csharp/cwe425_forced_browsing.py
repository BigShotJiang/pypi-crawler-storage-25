"""Forced browsing / direct request detection for C# (CWE-425).

SC644 — ASP.NET controller action without [Authorize]    medium    CWE-425

Flags action methods in ASP.NET controllers ([ApiController] / [Controller])
that carry an HTTP verb attribute but lack [Authorize] or [AllowAnonymous],
and whose parent class has no class-level [Authorize].
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from tree_sitter import Node, Tree

from sanicode.rules.base import Rule, _walk
from sanicode.rules.csharp._helpers import csharp_dotted_name
from sanicode.scanner.patterns import Finding

if TYPE_CHECKING:
    from sanicode.scanner.languages.base import TreeSitterPlugin


def _node_text(node: Node) -> str:
    return node.text.decode("utf-8") if node.text else ""


_CONTROLLER_ATTRS = frozenset({"ApiController", "Controller"})
_HTTP_VERB_ATTRS = frozenset({"HttpGet", "HttpPost", "HttpPut", "HttpDelete", "HttpPatch"})
_SECURITY_ATTRS = frozenset({"Authorize", "AllowAnonymous"})

# Method names that represent intentionally public endpoints.
_PUBLIC_METHOD_NAMES = frozenset({
    "Login",
    "Register",
    "Health",
    "HealthCheck",
    "Index",
    "Home",
    "Public",
    "Callback",
    "Webhook",
    "Error",
})


def _get_attribute_names(node: Node) -> list[str]:
    """Return all attribute short-names from a class or method declaration node."""
    names: list[str] = []
    for child in node.children:
        if child.type != "attribute_list":
            continue
        for attr_child in child.children:
            if attr_child.type != "attribute":
                continue
            name_node = attr_child.child_by_field_name("name")
            if name_node is not None:
                # Attribute names can be dotted (e.g. Microsoft.AspNetCore.Mvc.HttpGet).
                # We only care about the final segment for matching.
                full = csharp_dotted_name(name_node)
                short = full.rsplit(".", 1)[-1]
                names.append(short)
    return names


def _has_any_attr(node: Node, targets: frozenset[str]) -> bool:
    """Return True if *node* carries at least one attribute in *targets*."""
    return bool(set(_get_attribute_names(node)) & targets)


class CSharpMissingAuthOnActionRule(Rule):
    """Detect ASP.NET action methods exposed without access control."""

    rule_id = "SC644"
    cwe_id = 425
    severity = "medium"
    language = "csharp"
    message = (
        "ASP.NET action method lacks [Authorize] or [AllowAnonymous] — "
        "endpoint may be accessible without authentication (CWE-425)"
    )
    tags = ["auth"]
    domain = "access_control"
    action = "review"

    def check(self, tree: Tree, file_path: Path, plugin: TreeSitterPlugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        for node in _walk(root):
            if node.type != "class_declaration":
                continue
            if not _has_any_attr(node, _CONTROLLER_ATTRS):
                continue
            # Class-level [Authorize] covers all actions — skip the whole class.
            if _has_any_attr(node, _SECURITY_ATTRS):
                continue
            body = node.child_by_field_name("body")
            if body is None:
                continue
            for child in body.children:
                if child.type == "method_declaration":
                    self._check_method(child, plugin, file_path, findings)

        return findings

    def _check_method(
        self,
        method_node: Node,
        plugin: TreeSitterPlugin,
        file_path: Path,
        findings: list[Finding],
    ) -> None:
        # Must be an HTTP endpoint (carry an HTTP verb attribute).
        if not _has_any_attr(method_node, _HTTP_VERB_ATTRS):
            return
        # Skip well-known public endpoints by method name.
        name_node = method_node.child_by_field_name("name")
        if name_node is not None:
            method_name = _node_text(name_node)
            if method_name in _PUBLIC_METHOD_NAMES:
                return
        # If the method itself carries [Authorize] or [AllowAnonymous], it's covered.
        if _has_any_attr(method_node, _SECURITY_ATTRS):
            return
        findings.append(self._make_finding(method_node, plugin, file_path))
