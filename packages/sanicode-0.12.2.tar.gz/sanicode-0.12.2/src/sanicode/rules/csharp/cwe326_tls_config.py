"""TLS misconfiguration detection for C# (CWE-326).

SC655 — Weak TLS protocol (pre-1.2) in SslProtocols    high  CWE-326
"""
from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule, _walk
from sanicode.rules.csharp._helpers import csharp_dotted_name
from sanicode.scanner.patterns import Finding

# Weak SslProtocols enum values (anything below TLS 1.2).
_WEAK_SSL_PROTOCOLS = frozenset({
    "SslProtocols.Ssl3",
    "SslProtocols.Tls",
    "SslProtocols.Tls11",
})


class CSharpTLSConfigRule(Rule):
    """Detect weak TLS protocol versions in C# SslProtocols usage.

    Flags ``SslProtocols.Ssl3``, ``SslProtocols.Tls`` (1.0),
    and ``SslProtocols.Tls11`` — all below the minimum TLS 1.2.
    """

    rule_id = "SC655"
    cwe_id = 326
    severity = "high"
    language = "csharp"
    message = "Weak TLS protocol version (pre-1.2) — use Tls12 or Tls13 (CWE-326)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []

        for node in _walk(tree.root_node):
            if node.type != "member_access_expression":
                continue
            dotted = csharp_dotted_name(node)
            if dotted in _WEAK_SSL_PROTOCOLS:
                findings.append(self._make_finding(node, plugin, file_path))

        return findings
