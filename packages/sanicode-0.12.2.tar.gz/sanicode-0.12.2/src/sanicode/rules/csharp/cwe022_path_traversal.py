"""Path traversal via File/Path API (CWE-22).

SC610 — File access with non-literal path — path traversal risk    high  CWE-22
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.csharp._helpers import (
    csharp_call_arguments,
    csharp_method_name,
)
from sanicode.scanner.patterns import Finding

_TARGETS: dict[str, frozenset[str]] = {
    "File": frozenset({"ReadAllText", "Open", "WriteAllText"}),
    "Path": frozenset({"Combine"}),
}

_CS_STRING_TYPES = frozenset({"string_literal", "verbatim_string_literal"})


class CSharpPathTraversalRule(Rule):
    """Detect File/Path API calls with a non-literal path argument."""

    rule_id = "SC610"
    cwe_id = 22
    severity = "high"
    language = "csharp"
    message = "File access with non-literal path — path traversal risk (CWE-22)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if node.type != "invocation_expression":
                continue
            receiver, method = csharp_method_name(node)
            targets = _TARGETS.get(receiver)
            if targets is None or method not in targets:
                continue
            args = csharp_call_arguments(node)
            if not args:
                continue
            if args[0].type not in _CS_STRING_TYPES:
                findings.append(self._make_finding(node, plugin, file_path))
        return findings
