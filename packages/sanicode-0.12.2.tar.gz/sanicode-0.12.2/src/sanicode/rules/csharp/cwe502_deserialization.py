"""Insecure deserialization detection rules for C# (CWE-502).

SC603 — BinaryFormatter/SoapFormatter/ObjectStateFormatter/
         NetDataContractSerializer/LosFormatter               high  CWE-502
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.csharp._helpers import csharp_method_name
from sanicode.scanner.patterns import Finding

_DANGEROUS_FORMATTERS = frozenset({
    "BinaryFormatter",
    "SoapFormatter",
    "ObjectStateFormatter",
    "NetDataContractSerializer",
    "LosFormatter",
})


class CSharpDeserializationRule(Rule):
    """Detect use of dangerous deserializers — insecure deserialization risk."""

    rule_id = "SC603"
    cwe_id = 502
    severity = "high"
    language = "csharp"
    message = (
        "Use of dangerous deserializer (BinaryFormatter/SoapFormatter/etc.) — "
        "insecure deserialization (CWE-502)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        # Pattern 1: formatter.Deserialize(...) calls
        call_captures = plugin.captures("(invocation_expression) @call", root)
        for call_node in call_captures.get("call", []):
            recv, method = csharp_method_name(call_node)
            if method == "Deserialize":
                for fmt in _DANGEROUS_FORMATTERS:
                    if fmt in recv:
                        findings.append(self._make_finding(call_node, plugin, file_path))
                        break

        # Pattern 2: new BinaryFormatter() / new SoapFormatter() etc.
        new_captures = plugin.captures("(object_creation_expression) @new", root)
        for new_node in new_captures.get("new", []):
            type_node = new_node.child_by_field_name("type")
            if type_node and type_node.text:
                type_name = type_node.text.decode("utf-8")
                if type_name in _DANGEROUS_FORMATTERS:
                    findings.append(self._make_finding(new_node, plugin, file_path))

        return findings
