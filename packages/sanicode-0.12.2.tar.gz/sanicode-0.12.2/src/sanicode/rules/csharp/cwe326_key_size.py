"""Weak key size detection rules for C# (CWE-326).

SC635 — RSA.Create(N<2048) / new RSACryptoServiceProvider(N<2048)    high  CWE-326
"""
from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule, _walk
from sanicode.rules.csharp._helpers import (
    csharp_call_arguments,
    csharp_dotted_name,
    csharp_method_name,
)
from sanicode.scanner.patterns import Finding

_WEAK_CONSTRUCTOR_TYPES = frozenset({
    "RSACryptoServiceProvider",
    "DSACryptoServiceProvider",
})

_FACTORY_RECEIVERS = frozenset({
    "RSA", "DSA",
    "System.Security.Cryptography.RSA",
    "System.Security.Cryptography.DSA",
})


def _int_value(node) -> int | None:
    """Extract integer from a C# integer_literal node."""
    if node.type == "integer_literal":
        text = node.text.decode("utf-8") if node.text else ""
        try:
            return int(text)
        except ValueError:
            return None
    return None


class CSharpWeakKeyRule(Rule):
    """Detect RSA/DSA key creation with insufficient key sizes."""

    rule_id = "SC635"
    cwe_id = 326
    severity = "high"
    language = "csharp"
    message = "Weak key size \u2014 RSA/DSA keys must be at least 2048 bits (CWE-326)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []

        # Pattern 1: RSA.Create(1024) / DSA.Create(1024)
        call_captures = plugin.captures(
            "(invocation_expression) @call", tree.root_node
        )
        for call_node in call_captures.get("call", []):
            receiver, method = csharp_method_name(call_node)
            if method == "Create" and receiver in _FACTORY_RECEIVERS:
                args = csharp_call_arguments(call_node)
                if args:
                    val = _int_value(args[0])
                    if val is not None and val < 2048:
                        findings.append(self._make_finding(call_node, plugin, file_path))

        # Pattern 2: new RSACryptoServiceProvider(1024)
        for node in _walk(tree.root_node):
            if node.type != "object_creation_expression":
                continue
            type_node = node.child_by_field_name("type")
            if type_node is None:
                continue
            type_name = csharp_dotted_name(type_node)
            if type_name in _WEAK_CONSTRUCTOR_TYPES:
                args = csharp_call_arguments(node)
                if args:
                    val = _int_value(args[0])
                    if val is not None and val < 2048:
                        findings.append(self._make_finding(node, plugin, file_path))

        return findings
