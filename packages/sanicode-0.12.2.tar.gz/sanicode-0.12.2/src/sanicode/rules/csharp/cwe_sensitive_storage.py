"""Sensitive data storage detection rules for C# (CWE-916, CWE-522, CWE-312).

SC626 — Weak hash on password-named variable          high    CWE-916
SC627 — Secret variable written to file/database      medium  CWE-522
SC628 — Sensitive data written to persistent storage   medium  CWE-312
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules._sensitive_patterns import SECRET_VAR_PATTERN
from sanicode.rules.base import Rule, _walk
from sanicode.rules.csharp._helpers import (
    csharp_method_name,
)
from sanicode.scanner.patterns import Finding

# MD5.Create(), SHA1.Create() receiver patterns
_WEAK_HASH_RECEIVERS: frozenset[str] = frozenset(
    {"MD5", "SHA1", "MD5CryptoServiceProvider", "SHA1CryptoServiceProvider"}
)

_HASH_METHODS: frozenset[str] = frozenset(
    {"ComputeHash", "TransformBlock", "TransformFinalBlock"}
)

# File write methods for CWE-522
_FILE_WRITE_METHODS: frozenset[str] = frozenset(
    {"WriteAllText", "WriteAllBytes", "AppendAllText", "Write", "WriteLine"}
)

_DB_METHODS: frozenset[str] = frozenset(
    {"ExecuteNonQuery", "ExecuteReader", "ExecuteScalar"}
)

# Config/serialization methods for CWE-312
_CLEARTEXT_METHODS: frozenset[str] = frozenset(
    {"Set", "Add", "SetValue"}
)


def _has_secret_identifier(node, plugin) -> bool:
    """Walk all descendants for an identifier matching SECRET_VAR_PATTERN."""
    for child in _walk(node):
        if child.type == "identifier":
            name = plugin.node_text(child)
            if SECRET_VAR_PATTERN.search(name):
                return True
    return False


class CSharpWeakPasswordHashRule(Rule):
    """Detect MD5.Create()/SHA1.Create() with password-named variables.

    Flags when MD5 or SHA1 hash objects are used with .ComputeHash()
    on password-named data.
    """

    rule_id = "SC626"
    cwe_id = 916
    severity = "high"
    language = "csharp"
    message = (
        "Weak hash used on password-named variable "
        "\u2014 use Rfc2898DeriveBytes/bcrypt (CWE-916)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        captures = plugin.captures(
            "(invocation_expression) @call", tree.root_node
        )

        for call_node in captures.get("call", []):
            receiver, method = csharp_method_name(call_node)

            # MD5.Create() / SHA1.Create() — check enclosing block for
            # .ComputeHash(passwordBytes)
            if method == "Create" and receiver in _WEAK_HASH_RECEIVERS:
                parent = call_node.parent
                if parent is None:
                    continue
                block = parent.parent if parent.parent else parent
                for node in _walk(block):
                    if node.type == "invocation_expression":
                        _, mn = csharp_method_name(node)
                        if mn in _HASH_METHODS:
                            args_node = node.child_by_field_name("arguments")
                            if not args_node:
                                for ch in node.children:
                                    if ch.type == "argument_list":
                                        args_node = ch
                                        break
                            if args_node and _has_secret_identifier(args_node, plugin):
                                findings.append(
                                    self._make_finding(call_node, plugin, file_path)
                                )
                                break

            # Direct .ComputeHash(passwordBytes) on MD5/SHA1 receiver
            if method in _HASH_METHODS and any(
                r.lower() in receiver.lower() for r in ("md5", "sha1")
            ):
                args_node = call_node.child_by_field_name("arguments")
                if not args_node:
                    for ch in call_node.children:
                        if ch.type == "argument_list":
                            args_node = ch
                            break
                if args_node and _has_secret_identifier(args_node, plugin):
                    findings.append(self._make_finding(call_node, plugin, file_path))

        return findings


class CSharpUnprotectedPasswordStorageRule(Rule):
    """Detect file writes or DB operations storing secret-named variables."""

    rule_id = "SC627"
    cwe_id = 522
    severity = "medium"
    language = "csharp"
    message = (
        "Secret-named variable written to file or database "
        "without hashing (CWE-522)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        captures = plugin.captures(
            "(invocation_expression) @call", tree.root_node
        )

        for call_node in captures.get("call", []):
            _, method = csharp_method_name(call_node)

            if method in _FILE_WRITE_METHODS or method in _DB_METHODS:
                args_node = call_node.child_by_field_name("arguments")
                if not args_node:
                    for ch in call_node.children:
                        if ch.type == "argument_list":
                            args_node = ch
                            break
                if args_node and _has_secret_identifier(args_node, plugin):
                    findings.append(self._make_finding(call_node, plugin, file_path))

        return findings


class CSharpCleartextSecretStorageRule(Rule):
    """Detect sensitive data written to persistent storage in cleartext."""

    rule_id = "SC628"
    cwe_id = 312
    severity = "medium"
    language = "csharp"
    message = (
        "Sensitive data written to persistent storage "
        "in cleartext (CWE-312)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        captures = plugin.captures(
            "(invocation_expression) @call", tree.root_node
        )

        for call_node in captures.get("call", []):
            _, method = csharp_method_name(call_node)

            if method in _CLEARTEXT_METHODS:
                args_node = call_node.child_by_field_name("arguments")
                if not args_node:
                    for ch in call_node.children:
                        if ch.type == "argument_list":
                            args_node = ch
                            break
                if args_node and _has_secret_identifier(args_node, plugin):
                    findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
