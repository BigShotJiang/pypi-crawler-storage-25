"""XPath and XML injection detection for C# (CWE-91, CWE-643, CWE-776).

SC623 -- XPath injection via dynamic query             medium  CWE-91
SC624 -- Unsanitized data in XPath expression          medium  CWE-643
SC625 -- XML parser without entity expansion limits    medium  CWE-776
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.csharp._helpers import (
    csharp_call_arguments,
    csharp_method_name,
)
from sanicode.scanner.patterns import Finding

# XPath method names on XPathNavigator, XmlNode, XmlDocument.
_XPATH_METHODS = frozenset({
    "Select", "Evaluate", "SelectNodes", "SelectSingleNode",
})


def _is_csharp_literal(node) -> bool:
    """Return True if node is a C# string literal."""
    return node.type in (
        "string_literal",
        "verbatim_string_literal",
        "raw_string_literal",
    )


def _find_xpath_findings(tree: Tree, file_path: Path, plugin, rule) -> list[Finding]:
    """Shared detection logic for CWE-91 and CWE-643 XPath injection."""
    findings: list[Finding] = []
    captures = plugin.captures("(invocation_expression) @call", tree.root_node)

    for call_node in captures.get("call", []):
        _, method = csharp_method_name(call_node)
        if method not in _XPATH_METHODS:
            continue

        args = csharp_call_arguments(call_node)
        if not args:
            continue

        # The first argument is the XPath expression.
        if _is_csharp_literal(args[0]):
            continue

        findings.append(rule._make_finding(call_node, plugin, file_path))

    return findings


# Legacy XML reader types that are vulnerable to entity expansion.
_LEGACY_XML_TYPES = frozenset({"XmlTextReader"})


class CSharpXPathInjectionRule(Rule):
    """Detect XPath queries built from dynamic input -- XPath injection."""

    rule_id = "SC623"
    cwe_id = 91
    severity = "medium"
    language = "csharp"
    message = (
        "XPath query built from dynamic input "
        "\u2014 potential XPath injection (CWE-91)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        return _find_xpath_findings(tree, file_path, plugin, self)


class CSharpXPathDataInjectionRule(Rule):
    """Detect unsanitized data in XPath expressions -- injection."""

    rule_id = "SC624"
    cwe_id = 643
    severity = "medium"
    language = "csharp"
    message = (
        "XPath expression includes unsanitized data "
        "\u2014 potential injection (CWE-643)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        return _find_xpath_findings(tree, file_path, plugin, self)


class CSharpXMLEntityExpansionRule(Rule):
    """Detect XML reader creation that may allow entity expansion.

    CWE-776 targets recursive internal entity expansion (billion laughs),
    distinct from CWE-611 which targets external entity resolution.
    Flags ``new XmlTextReader()`` (legacy, always vulnerable) and
    ``XmlReader.Create()`` as requiring DTD processing review.
    """

    rule_id = "SC625"
    cwe_id = 776
    severity = "medium"
    language = "csharp"
    message = (
        "XML reader without entity expansion limits "
        "\u2014 potential billion laughs attack (CWE-776)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        # Detect ``new XmlTextReader(...)`` -- legacy, always vulnerable.
        new_captures = plugin.captures(
            "(object_creation_expression) @new", root
        )
        for new_node in new_captures.get("new", []):
            type_node = new_node.child_by_field_name("type")
            if type_node and type_node.text:
                type_name = type_node.text.decode("utf-8")
                if type_name in _LEGACY_XML_TYPES:
                    findings.append(self._make_finding(new_node, plugin, file_path))

        # Detect ``XmlReader.Create(...)`` -- needs DTD processing review.
        inv_captures = plugin.captures(
            "(invocation_expression) @call", root
        )
        for call_node in inv_captures.get("call", []):
            receiver, method = csharp_method_name(call_node)
            if receiver == "XmlReader" and method == "Create":
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
