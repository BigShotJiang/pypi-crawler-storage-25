"""Cross-site scripting detection rules for C# (CWE-79).

SC605 — Html.Raw()        high   CWE-79
SC606 — Response.Write()  medium CWE-79
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.csharp._helpers import csharp_method_name
from sanicode.scanner.patterns import Finding


class CSharpHtmlRawRule(Rule):
    """Detect Html.Raw() — unescaped HTML output risk."""

    rule_id = "SC605"
    cwe_id = 79
    severity = "high"
    language = "csharp"
    message = (
        "Use of Html.Raw() bypasses HTML encoding — "
        "cross-site scripting risk (CWE-79)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        call_captures = plugin.captures("(invocation_expression) @call", root)
        for call_node in call_captures.get("call", []):
            recv, method = csharp_method_name(call_node)
            if method == "Raw" and ("Html" in recv or recv == ""):
                # Bare Raw() calls without a receiver are uncommon but flag them too
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings


class CSharpResponseWriteRule(Rule):
    """Detect Response.Write() — unencoded output to HTTP response."""

    rule_id = "SC606"
    cwe_id = 79
    severity = "medium"
    language = "csharp"
    message = (
        "Use of Response.Write() with unencoded content — "
        "cross-site scripting risk (CWE-79)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        call_captures = plugin.captures("(invocation_expression) @call", root)
        for call_node in call_captures.get("call", []):
            recv, method = csharp_method_name(call_node)
            if method == "Write" and "Response" in recv:
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
