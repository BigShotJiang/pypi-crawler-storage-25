"""Weak cipher detection rules for C# (CWE-328).

SC636 — DES.Create()/RC2.Create()/TripleDES.Create() and provider constructors    medium  CWE-328
"""
from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule, _walk
from sanicode.rules.csharp._helpers import csharp_dotted_name, csharp_method_name
from sanicode.scanner.patterns import Finding

_WEAK_FACTORY_RECEIVERS = frozenset({
    "DES", "RC2", "TripleDES",
    "System.Security.Cryptography.DES",
    "System.Security.Cryptography.RC2",
    "System.Security.Cryptography.TripleDES",
})

_WEAK_CONSTRUCTOR_TYPES = frozenset({
    "DESCryptoServiceProvider",
    "RC2CryptoServiceProvider",
    "TripleDESCryptoServiceProvider",
})


class CSharpWeakCipherRule(Rule):
    """Detect DES.Create()/RC2.Create()/TripleDES.Create() and weak cipher constructors."""

    rule_id = "SC636"
    cwe_id = 328
    severity = "medium"
    language = "csharp"
    message = "Use of weak cipher (DES/RC2/3DES) — use AES instead (CWE-328)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []

        # Pattern 1: Factory calls — DES.Create() / RC2.Create() / TripleDES.Create()
        call_captures = plugin.captures(
            "(invocation_expression) @call", tree.root_node
        )
        for call_node in call_captures.get("call", []):
            receiver, method = csharp_method_name(call_node)
            if method == "Create" and receiver in _WEAK_FACTORY_RECEIVERS:
                findings.append(self._make_finding(call_node, plugin, file_path))

        # Pattern 2: Constructor — new DESCryptoServiceProvider() etc.
        for node in _walk(tree.root_node):
            if node.type != "object_creation_expression":
                continue
            type_node = node.child_by_field_name("type")
            if type_node is None:
                continue
            type_name = csharp_dotted_name(type_node)
            if type_name in _WEAK_CONSTRUCTOR_TYPES:
                findings.append(self._make_finding(node, plugin, file_path))

        return findings
