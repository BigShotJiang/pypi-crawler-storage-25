"""CSRF protection bypass detection for C# (CWE-352).

SC614 — [IgnoreAntiforgeryToken] attribute / anti-forgery filter removal    medium  CWE-352
SC652 — CookieOptions without SameSite set                                  medium  CWE-352
SC653 — CORS AllowAnyOrigin() with AllowCredentials()                       high    CWE-352
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule, _walk
from sanicode.rules.csharp._helpers import csharp_method_name
from sanicode.scanner.patterns import Finding


def _node_text(node) -> str:
    return node.text.decode("utf-8") if node.text else ""


class CSharpCsrfBypassRule(Rule):
    """Detect CSRF protection bypass in ASP.NET controllers and actions.

    Two detection paths:
    1. [IgnoreAntiforgeryToken] attribute on a controller class or action method.
    2. options.Filters.Remove(...AntiforgeryToken...) — programmatic removal
       of the global anti-forgery filter.
    """

    rule_id = "SC614"
    cwe_id = 352
    severity = "medium"
    language = "csharp"
    message = "CSRF protection bypassed — potential CSRF vulnerability (CWE-352)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        # Pattern 1: [IgnoreAntiforgeryToken] attribute
        attr_captures = plugin.captures("(attribute) @attr", root)
        for attr_node in attr_captures.get("attr", []):
            text = attr_node.text.decode("utf-8") if attr_node.text else ""
            if "IgnoreAntiforgeryToken" in text:
                findings.append(self._make_finding(attr_node, plugin, file_path))

        # Pattern 2: Programmatic removal of the anti-forgery filter
        # e.g. options.Filters.Remove(new AutoValidateAntiforgeryTokenAttribute())
        call_captures = plugin.captures("(invocation_expression) @call", root)
        for call_node in call_captures.get("call", []):
            text = call_node.text.decode("utf-8") if call_node.text else ""
            if "Remove" in text and "AntiforgeryToken" in text:
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings


class CSharpCookieSameSiteRule(Rule):
    """Detect CookieOptions without SameSite in ASP.NET.

    Covers:
    - ``new CookieOptions { ... }`` without ``SameSite`` property
    - ``Response.Cookies.Append(name, value, options)`` where options lacks SameSite
    - ``CookieOptions`` with ``SameSite = SameSiteMode.None``
    """

    rule_id = "SC652"
    cwe_id = 352
    severity = "medium"
    language = "csharp"
    message = (
        "CookieOptions without SameSite attribute — "
        "explicit SameSite=Strict or Lax is recommended for CSRF protection (CWE-352)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        # Pattern 1: new CookieOptions { ... } without SameSite
        for node in _walk(root):
            if node.type != "object_creation_expression":
                continue
            type_node = node.child_by_field_name("type")
            if type_node is None:
                continue
            type_text = _node_text(type_node)
            if type_text != "CookieOptions":
                continue
            full_text = _node_text(node)
            if "SameSite" not in full_text:
                findings.append(self._make_finding(node, plugin, file_path))
            elif "SameSiteMode.None" in full_text:
                findings.append(self._make_finding(node, plugin, file_path))

        # Pattern 2: Response.Cookies.Append() — check if it's called with
        # only name + value (no CookieOptions arg)
        call_captures = plugin.captures("(invocation_expression) @call", root)
        for call_node in call_captures.get("call", []):
            _receiver, method = csharp_method_name(call_node)
            if method != "Append":
                continue
            full_text = _node_text(call_node)
            if "Cookies" not in full_text:
                continue
            # If Append is called with just 2 string args and no CookieOptions,
            # SameSite defaults are not explicitly set
            if "CookieOptions" not in full_text and "SameSite" not in full_text:
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings


class CSharpCorsCredentialsRule(Rule):
    """Detect CORS AllowAnyOrigin() combined with AllowCredentials() in ASP.NET.

    The combination of ``AllowAnyOrigin()`` with ``AllowCredentials()`` in a
    CORS policy builder allows any site to make credentialed requests.
    """

    rule_id = "SC653"
    cwe_id = 352
    severity = "high"
    language = "csharp"
    message = (
        "CORS AllowAnyOrigin() with AllowCredentials() — "
        "any site can make credentialed cross-origin requests (CWE-352)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        # Scan lambda bodies and method blocks for the combination.
        # Typical pattern:
        #   builder.AllowAnyOrigin().AllowCredentials()
        # or:
        #   policy.AllowAnyOrigin();
        #   policy.AllowCredentials();
        for node in _walk(root):
            if node.type not in ("block", "lambda_expression", "arrow_expression_clause"):
                continue
            block_text = _node_text(node)
            if "AllowAnyOrigin" in block_text and "AllowCredentials" in block_text:
                # Find the AllowCredentials call for precise location
                call_captures = plugin.captures("(invocation_expression) @call", node)
                for call_node in call_captures.get("call", []):
                    _receiver, method = csharp_method_name(call_node)
                    if method == "AllowCredentials":
                        findings.append(self._make_finding(call_node, plugin, file_path))
                        break
                else:
                    findings.append(self._make_finding(node, plugin, file_path))

        return findings
