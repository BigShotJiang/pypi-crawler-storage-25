"""CORS wildcard origin detection for C# (CWE-346).

SC639 — Access-Control-Allow-Origin set to wildcard * / AllowAnyOrigin()    medium  CWE-346
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.csharp._helpers import csharp_call_arguments, csharp_method_name
from sanicode.scanner.patterns import Finding

_HEADER_NAME = "access-control-allow-origin"
_ADD_METHODS = frozenset({"Add", "Append"})


def _string_text(node) -> str:
    """Extract unquoted text from a C# string literal."""
    if node.type not in ("string_literal", "verbatim_string_literal"):
        return ""
    text = node.text.decode("utf-8") if node.text else ""
    # Strip surrounding double quotes (and @ prefix for verbatim)
    return text.lstrip("@").strip('"')


class CSharpCorsWildcardRule(Rule):
    """Detect CORS wildcard origin in C# — Headers.Add and AllowAnyOrigin()."""

    rule_id = "SC639"
    cwe_id = 346
    severity = "medium"
    language = "csharp"
    message = "Access-Control-Allow-Origin set to wildcard '*' (CWE-346)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(invocation_expression) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            _receiver, method = csharp_method_name(call_node)

            # Pattern 1: AllowAnyOrigin() — CORS policy builder, no args needed
            if method == "AllowAnyOrigin":
                findings.append(self._make_finding(call_node, plugin, file_path))
                continue

            # Pattern 2: Response.Headers.Add("Access-Control-Allow-Origin", "*")
            if method not in _ADD_METHODS:
                continue
            args = csharp_call_arguments(call_node)
            if len(args) < 2:
                continue
            header_text = _string_text(args[0])
            if _HEADER_NAME not in header_text.lower():
                continue
            value_text = _string_text(args[1])
            if value_text == "*":
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
