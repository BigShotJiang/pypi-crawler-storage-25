"""Open redirect detection rules for C# (CWE-601).

SC620 -- Response.Redirect / RedirectToAction / RedirectPermanent    medium  CWE-601
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.csharp._helpers import csharp_method_name
from sanicode.scanner.patterns import Finding

_REDIRECT_METHODS = frozenset({
    "Redirect",
    "RedirectToAction",
    "RedirectPermanent",
})


class CSharpOpenRedirectRule(Rule):
    """Detect redirect calls in C# / ASP.NET.

    Flags ``Response.Redirect()``, ``Redirect()``, ``RedirectToAction()``,
    and ``RedirectPermanent()`` calls where the URL argument could be
    attacker-controlled.
    """

    rule_id = "SC620"
    cwe_id = 601
    severity = "medium"
    language = "csharp"
    message = (
        "Redirect call \u2014 verify URL is validated against "
        "an allowlist (CWE-601)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures(
            "(invocation_expression) @call", tree.root_node
        )

        for call_node in call_captures.get("call", []):
            _recv, method = csharp_method_name(call_node)
            if method in _REDIRECT_METHODS:
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
