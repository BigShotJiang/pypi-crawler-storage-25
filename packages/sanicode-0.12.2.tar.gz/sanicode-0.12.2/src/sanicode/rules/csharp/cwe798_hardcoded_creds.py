"""Hardcoded credential detection for C# (CWE-798).

SC611 — string literal assigned to a secret-named variable    high  CWE-798
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules._sensitive_patterns import (
    MIN_SECRET_LEN,
    SECRET_VAR_PATTERN,
    is_placeholder,
)
from sanicode.rules.base import Rule, _walk
from sanicode.scanner.patterns import Finding

_STRING_TYPES = frozenset({"string_literal", "verbatim_string_literal"})


def _csharp_strip_quotes(s: str) -> str:
    """Remove surrounding quote characters from a C# string literal.

    Handles regular strings, verbatim strings (@"..."), interpolated strings
    ($"..."), and raw string literals.  This is C#-specific because of the
    ``@`` and ``$`` prefixes that the generic ``strip_quotes`` does not cover.
    """
    # Verbatim strings: @"..."
    if s.startswith('@"') and s.endswith('"') and len(s) >= 3:
        return s[2:-1]
    # Interpolated strings: $"..."
    if s.startswith('$"') and s.endswith('"') and len(s) >= 3:
        return s[2:-1]
    # Triple-quoted strings
    if s.startswith('"""') and s.endswith('"""') and len(s) >= 6:
        return s[3:-3]
    # Regular double-quoted strings
    if s.startswith('"') and s.endswith('"') and len(s) >= 2:
        return s[1:-1]
    return s


def _find_string_child(node) -> object | None:
    """Find the first string literal direct child of a node."""
    for child in node.children:
        if child.type in _STRING_TYPES:
            return child
    return None


class CSharpHardcodedCredentialRule(Rule):
    """Detect hardcoded credentials in C# variable declarations and assignments."""

    rule_id = "SC611"
    cwe_id = 798
    severity = "high"
    language = "csharp"
    message = "Hardcoded credential — secret value in variable (CWE-798)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []

        for node in _walk(tree.root_node):
            if node.type == "variable_declarator":
                result = self._check_declarator(node, plugin, file_path)
                if result is not None:
                    findings.append(result)
            elif node.type == "assignment_expression":
                result = self._check_assignment(node, plugin, file_path)
                if result is not None:
                    findings.append(result)

        return findings

    def _check_declarator(self, node, plugin, file_path: Path):
        """Handle: string name = "value";  or  var name = "value";"""
        name_node = node.child_by_field_name("name")
        if name_node is None or name_node.type != "identifier":
            return None

        var_name = plugin.node_text(name_node)
        if not SECRET_VAR_PATTERN.search(var_name):
            return None

        # The string literal is a direct child of variable_declarator in
        # the C# tree-sitter grammar (no equals_value_clause wrapper).
        string_node = _find_string_child(node)
        if string_node is None:
            return None

        inner = _csharp_strip_quotes(plugin.node_text(string_node))
        if len(inner) < MIN_SECRET_LEN or is_placeholder(inner):
            return None

        return self._make_finding(node, plugin, file_path)

    def _check_assignment(self, node, plugin, file_path: Path):
        """Handle: name = "value"; (bare assignment expression)"""
        left = node.child_by_field_name("left")
        right = node.child_by_field_name("right")
        if left is None or right is None:
            return None

        if left.type != "identifier":
            return None

        var_name = plugin.node_text(left)
        if not SECRET_VAR_PATTERN.search(var_name):
            return None

        if right.type not in _STRING_TYPES:
            return None

        inner = _csharp_strip_quotes(plugin.node_text(right))
        if len(inner) < MIN_SECRET_LEN or is_placeholder(inner):
            return None

        return self._make_finding(node, plugin, file_path)
