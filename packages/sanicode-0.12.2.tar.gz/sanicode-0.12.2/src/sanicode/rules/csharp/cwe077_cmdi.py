"""Template/dynamic compilation injection detection for C# (CWE-77).

SC617 — Dynamic code evaluation via scripting/template engines with non-literal input.

CSharpScript.EvaluateAsync(), Engine.Razor.RunCompile(), and similar APIs
execute arbitrary code when passed untrusted strings.
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.csharp._helpers import csharp_call_arguments, csharp_method_name
from sanicode.scanner.patterns import Finding


class CSharpDynamicEvalRule(Rule):
    """Detect dynamic code evaluation with non-literal input — expression injection."""

    rule_id = "SC617"
    cwe_id = 77
    severity = "high"
    language = "csharp"
    message = "Dynamic code evaluation with non-literal input — expression injection risk (CWE-77)"

    _EVAL_METHODS = frozenset({
        "EvaluateAsync", "RunCompile", "CompileRenderString",
        "CompileAndRun",
    })

    _STRING_LITERAL_TYPES = frozenset({
        "string_literal", "verbatim_string_literal", "raw_string_literal",
    })

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        captures = plugin.captures("(invocation_expression) @call", tree.root_node)

        for call_node in captures.get("call", []):
            _, method = csharp_method_name(call_node)
            if method not in self._EVAL_METHODS:
                continue

            args = csharp_call_arguments(call_node)
            if not args:
                continue

            first = args[0]
            if first.type in self._STRING_LITERAL_TYPES:
                continue

            findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
