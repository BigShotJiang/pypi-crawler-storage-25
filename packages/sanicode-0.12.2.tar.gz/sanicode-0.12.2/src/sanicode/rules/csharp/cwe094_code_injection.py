"""Code injection detection rules for C# (CWE-94).

SC604 — Type.GetType()/Assembly.Load*()/Activator.CreateInstance()
         with non-literal arguments                              high  CWE-94
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.csharp._helpers import csharp_call_arguments, csharp_method_name
from sanicode.scanner.patterns import Finding

# Map of receiver fragment → allowed method names
_DYNAMIC_TYPE_CALLS: dict[str, frozenset[str]] = {
    "Type": frozenset({"GetType"}),
    "Assembly": frozenset({"Load", "LoadFrom", "LoadFile"}),
    "Activator": frozenset({"CreateInstance"}),
}


class CSharpDynamicTypeRule(Rule):
    """Detect Type.GetType()/Assembly.Load*()/Activator.CreateInstance() — code injection risk."""

    rule_id = "SC604"
    cwe_id = 94
    severity = "high"
    language = "csharp"
    message = (
        "Use of Type.GetType()/Assembly.Load*()/Activator.CreateInstance() — "
        "dynamic type loading risk (CWE-94)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        call_captures = plugin.captures("(invocation_expression) @call", root)
        for call_node in call_captures.get("call", []):
            recv, method = csharp_method_name(call_node)

            matched = False
            for receiver_fragment, methods in _DYNAMIC_TYPE_CALLS.items():
                if method in methods and receiver_fragment in recv:
                    matched = True
                    break

            if not matched:
                continue

            # Only flag when arguments are present — parameterless calls (e.g.
            # typeof-equivalent patterns) are generally safe.
            args = csharp_call_arguments(call_node)
            if not args:
                continue

            findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
