"""Untrusted inclusion detection for C# (CWE-829).

SC633 — Assembly.Load with non-literal argument    medium  CWE-829
"""
from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.csharp._helpers import csharp_call_arguments, csharp_method_name
from sanicode.scanner.patterns import Finding

_LOAD_METHODS = frozenset({
    "LoadFrom", "LoadFile", "Load", "LoadWithPartialName", "UnsafeLoadFrom",
})

_LITERAL_TYPES = frozenset({
    "string_literal", "verbatim_string_literal",
})


class CSharpUntrustedInclusionRule(Rule):
    """Detect Assembly.Load* calls with non-literal path/name arguments."""

    rule_id = "SC633"
    cwe_id = 829
    severity = "medium"
    language = "csharp"
    message = (
        "Assembly.Load with non-literal argument — "
        "untrusted code inclusion risk (CWE-829)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(invocation_expression) @call", tree.root_node)
        for call_node in call_captures.get("call", []):
            receiver, method = csharp_method_name(call_node)
            if method not in _LOAD_METHODS:
                continue
            if "Assembly" not in receiver:
                continue
            args = csharp_call_arguments(call_node)
            if not args:
                continue
            first = args[0]
            if first.type in _LITERAL_TYPES:
                continue
            findings.append(self._make_finding(call_node, plugin, file_path))
        return findings
