"""Trust boundary violation for C# (CWE-501).

SC649 — Request data stored in session without validation    medium  CWE-501
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.csharp._helpers import (
    csharp_call_arguments,
    csharp_dotted_name,
    csharp_method_name,
)
from sanicode.scanner.patterns import Finding

_MESSAGE = (
    "Request data stored in session without validation "
    "\u2014 trust boundary violation (CWE-501)"
)

# Session write methods on ISession.
_SESSION_WRITE_METHODS = frozenset({"SetString", "SetInt32", "Set"})

# Dotted prefixes for direct HTTP request collection accesses.
_REQUEST_COLLECTIONS = frozenset({"Request.Query", "Request.Form", "Request.Headers"})


def _receiver_is_session(receiver: str) -> bool:
    """Return True if the dotted receiver ends with or contains ``Session``."""
    parts = receiver.split(".")
    return any("Session" in p for p in parts)


def _is_direct_request_element_access(node, plugin) -> bool:
    """Return True if *node* is a direct ``element_access_expression`` on a
    known request collection (e.g. ``Request.Query["x"]``).

    A value wrapped in a function call will be an ``invocation_expression``
    at the top level, so this check will return False for those.
    """
    if node.type != "element_access_expression":
        return False
    expr = node.child_by_field_name("expression")
    if expr is None:
        return False
    name = csharp_dotted_name(expr)
    return name in _REQUEST_COLLECTIONS


class CSharpTrustBoundaryRule(Rule):
    """Detect request data stored in session without validation (CWE-501).

    Flags ``HttpContext.Session.SetString("k", Request.Query["k"])`` and
    similar calls where a value argument is a direct request collection access.
    """

    rule_id = "SC649"
    cwe_id = 501
    severity = "medium"
    language = "csharp"
    message = _MESSAGE
    tags = ["input_validation", "session"]
    domain = "web"
    action = "review"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(invocation_expression) @call", tree.root_node)
        for call_node in call_captures.get("call", []):
            receiver, method = csharp_method_name(call_node)
            if method not in _SESSION_WRITE_METHODS:
                continue
            if not _receiver_is_session(receiver):
                continue
            args = csharp_call_arguments(call_node)
            if not args:
                continue
            # Value argument is at index 1 for SetString/SetInt32/Set.
            # Check all args after the first to handle variadic forms.
            for arg in args[1:]:
                if _is_direct_request_element_access(arg, plugin):
                    findings.append(self._make_finding(call_node, plugin, file_path))
                    break
        return findings
