"""Predictable IV detection rules for C# (CWE-329).

SC637 — .IV = new byte[N] (zero-filled assignment)    high  CWE-329
"""
from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule, _walk
from sanicode.scanner.patterns import Finding


class CSharpPredictableIVRule(Rule):
    """Detect assignment of zero-filled byte array to .IV property."""

    rule_id = "SC637"
    cwe_id = 329
    severity = "high"
    language = "csharp"
    message = "Predictable IV — new byte[N] is zero-filled; use RNGCryptoServiceProvider (CWE-329)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []

        for node in _walk(tree.root_node):
            if node.type != "assignment_expression":
                continue

            left = node.child_by_field_name("left")
            right = node.child_by_field_name("right")
            if left is None or right is None:
                continue

            # Check left side is *.IV (member access ending with IV)
            if left.type == "member_access_expression":
                name_node = left.child_by_field_name("name")
                if name_node and name_node.text and name_node.text.decode("utf-8") == "IV":
                    # new byte[N] is zero-initialized by CLR spec
                    if right.type == "array_creation_expression":
                        findings.append(self._make_finding(node, plugin, file_path))

        return findings
