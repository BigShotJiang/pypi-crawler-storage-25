"""ECB mode detection for C# (CWE-327).

SC654 — CipherMode.ECB usage    high  CWE-327
"""
from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule, _walk
from sanicode.rules.csharp._helpers import csharp_dotted_name
from sanicode.scanner.patterns import Finding


class CSharpECBModeRule(Rule):
    """Detect CipherMode.ECB usage in C#.

    Flags any ``member_access_expression`` that resolves to ``CipherMode.ECB``.
    """

    rule_id = "SC654"
    cwe_id = 327
    severity = "high"
    language = "csharp"
    message = "ECB cipher mode used — ECB does not provide semantic security (CWE-327)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []

        for node in _walk(tree.root_node):
            if node.type != "member_access_expression":
                continue
            dotted = csharp_dotted_name(node)
            if dotted == "CipherMode.ECB":
                findings.append(self._make_finding(node, plugin, file_path))

        return findings
