"""Sensitive data exposure in HTTP response for C# (CWE-201).

SC645 — Response includes sensitive-named variable    medium  CWE-201
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules._sensitive_patterns import PII_VAR_PATTERN, SECRET_VAR_PATTERN
from sanicode.rules.base import Rule, _walk
from sanicode.rules.csharp._helpers import csharp_method_name
from sanicode.scanner.patterns import Finding

# Controller action result methods (bare or on any receiver)
_CONTROLLER_METHODS: frozenset[str] = frozenset({"Ok", "Json", "Content"})

# JsonSerializer.Serialize
_SERIALIZER_RECEIVER = "JsonSerializer"
_SERIALIZER_METHOD = "Serialize"


class CSharpSensitiveResponseRule(Rule):
    """Detect response-building calls that include sensitive-named variable arguments."""

    rule_id = "SC645"
    cwe_id = 201
    severity = "medium"
    language = "csharp"
    tags = ["info_disclosure"]
    domain = "data_protection"
    message = (
        "Response includes sensitive-named variable "
        "— may expose secrets or PII in API response (CWE-201)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        captures = plugin.captures("(invocation_expression) @call", tree.root_node)
        for call_node in captures.get("call", []):
            receiver, method = csharp_method_name(call_node)
            matched = False
            if method in _CONTROLLER_METHODS:
                matched = True
            elif receiver == _SERIALIZER_RECEIVER and method == _SERIALIZER_METHOD:
                matched = True
            if not matched:
                continue
            if self._has_sensitive_arg(call_node, plugin):
                findings.append(self._make_finding(call_node, plugin, file_path))
        return findings

    @staticmethod
    def _has_sensitive_arg(call_node, plugin) -> bool:
        args = call_node.child_by_field_name("arguments")
        if args is None:
            return False
        for child in _walk(args):
            if child.type == "identifier":
                name = plugin.node_text(child)
                if SECRET_VAR_PATTERN.search(name) or PII_VAR_PATTERN.search(name):
                    return True
        return False
