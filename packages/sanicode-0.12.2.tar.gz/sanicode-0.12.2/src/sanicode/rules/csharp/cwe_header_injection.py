"""CRLF and HTTP header injection detection for C# (CWE-93, CWE-113).

SC621 — CRLF injection via header manipulation    medium  CWE-93
SC622 — HTTP response splitting via headers       medium  CWE-113
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.csharp._helpers import csharp_method_name
from sanicode.scanner.patterns import Finding

_HEADER_DOTTED_RECEIVERS = frozenset({
    "Response.Headers",
    "HttpContext.Response.Headers",
})

_HEADER_ADD_METHODS = frozenset({"Add", "Append"})


def _check_header_calls(
    tree: Tree, file_path: Path, plugin, rule: Rule,
) -> list[Finding]:
    """Shared detection logic for C# HTTP header-setting calls."""
    findings: list[Finding] = []
    call_captures = plugin.captures("(invocation_expression) @call", tree.root_node)

    for call_node in call_captures.get("call", []):
        recv, method = csharp_method_name(call_node)
        # Match Response.Headers.Add, Response.Headers.Append,
        # HttpContext.Response.Headers.Add, or bare AddHeader
        if method in _HEADER_ADD_METHODS and any(
            recv.endswith(r) for r in _HEADER_DOTTED_RECEIVERS
        ):
            findings.append(rule._make_finding(call_node, plugin, file_path))
        elif method == "AddHeader":
            findings.append(rule._make_finding(call_node, plugin, file_path))

    return findings


class CRLFInjectionRule(Rule):
    """Detect C# Response.Headers.Add/Append calls — CRLF injection risk."""

    rule_id = "SC621"
    cwe_id = 93
    severity = "medium"
    language = "csharp"
    message = (
        "HTTP header set \u2014 verify value is sanitized against "
        "CRLF injection (CWE-93)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        return _check_header_calls(tree, file_path, plugin, self)


class HeaderInjectionRule(Rule):
    """Detect C# Response.Headers.Add/Append calls — response splitting risk."""

    rule_id = "SC622"
    cwe_id = 113
    severity = "medium"
    language = "csharp"
    message = (
        "HTTP header set \u2014 verify value prevents "
        "response splitting (CWE-113)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        return _check_header_calls(tree, file_path, plugin, self)
