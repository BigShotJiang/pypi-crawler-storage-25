"""Sensitive data in GET query string parameters for C# (CWE-598).

SC646 — Sensitive parameter read from GET query string    medium  CWE-598
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules._sensitive_patterns import SECRET_VAR_PATTERN, strip_quotes
from sanicode.rules.base import Rule, _walk
from sanicode.rules.csharp._helpers import csharp_dotted_name
from sanicode.scanner.patterns import Finding

_QUERY_OBJECTS: frozenset[str] = frozenset(
    {
        "Request.Query",
        "Request.QueryString",
    }
)

_MESSAGE = (
    "Sensitive parameter read from GET query string "
    "— credentials should not travel in URLs (CWE-598)"
)


class CSharpGetSensitiveRule(Rule):
    """Detect reading sensitive-named parameters from Request.Query / QueryString."""

    rule_id = "SC646"
    cwe_id = 598
    severity = "medium"
    language = "csharp"
    message = _MESSAGE
    tags = ["info_disclosure"]
    domain = "data_protection"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in _walk(tree.root_node):
            if node.type != "element_access_expression":
                continue
            expr = node.child_by_field_name("expression")
            if expr is None:
                continue
            name = csharp_dotted_name(expr)
            if name not in _QUERY_OBJECTS:
                continue
            # Search for string literal inside the bracketed argument list
            for child in _walk(node):
                if child.type == "string_literal":
                    key = strip_quotes(plugin.node_text(child))
                    if SECRET_VAR_PATTERN.search(key):
                        findings.append(self._make_finding(node, plugin, file_path))
                        break
        return findings
