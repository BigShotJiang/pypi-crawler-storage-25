"""Session and cookie security detection rules for C# (CWE-614, CWE-384, CWE-613).

SC629 -- Insecure cookie configuration (missing Secure flag)     medium  CWE-614
SC630 -- Session fixation (auth without session regeneration)    medium  CWE-384
SC631 -- Session timeout / cookie integrity                      low     CWE-613
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule, _walk
from sanicode.rules.csharp._helpers import csharp_method_name
from sanicode.scanner.patterns import Finding


class CSharpInsecureCookieRule(Rule):
    """Detect cookie creation without the Secure flag (CWE-614).

    Flags ``Response.Cookies.Append(name, value)`` calls and
    ``new CookieOptions`` creation as requiring Secure flag review.
    """

    rule_id = "SC629"
    cwe_id = 614
    severity = "medium"
    language = "csharp"
    message = "Cookie created \u2014 verify Secure flag is set (CWE-614)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        # Pattern 1: Response.Cookies.Append(name, value)
        call_captures = plugin.captures(
            "(invocation_expression) @call", root
        )
        for call_node in call_captures.get("call", []):
            receiver, method = csharp_method_name(call_node)
            if method == "Append" and "Cookies" in receiver:
                findings.append(self._make_finding(call_node, plugin, file_path))

        # Pattern 2: new CookieOptions { ... }
        new_captures = plugin.captures(
            "(object_creation_expression) @new", root
        )
        for new_node in new_captures.get("new", []):
            type_node = new_node.child_by_field_name("type")
            if type_node is None:
                continue
            type_text = type_node.text.decode("utf-8") if type_node.text else ""
            if type_text == "CookieOptions":
                findings.append(self._make_finding(new_node, plugin, file_path))

        return findings


class CSharpSessionFixationRule(Rule):
    """Detect authentication calls that may lack session regeneration (CWE-384).

    Flags ``SignInAsync()`` and ``PasswordSignInAsync()`` calls as
    requiring session regeneration review.
    """

    rule_id = "SC630"
    cwe_id = 384
    severity = "medium"
    language = "csharp"
    message = (
        "Authentication call \u2014 verify session ID is regenerated after login (CWE-384)"
    )

    _AUTH_METHODS = frozenset({
        "SignInAsync", "PasswordSignInAsync", "SignIn",
        "Login", "Authenticate",
    })

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        call_captures = plugin.captures(
            "(invocation_expression) @call", root
        )
        for call_node in call_captures.get("call", []):
            _, method = csharp_method_name(call_node)
            if method in self._AUTH_METHODS:
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings


class CSharpSessionTimeoutRule(Rule):
    """Detect session misconfiguration: HttpOnly disabled (CWE-613).

    Flags ``HttpOnly = false`` in initializer expressions.
    """

    rule_id = "SC631"
    cwe_id = 613
    severity = "low"
    language = "csharp"
    message = (
        "Session configuration \u2014 verify timeout and integrity settings (CWE-613)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        # Look for HttpOnly = false in assignments or initializer expressions
        for node in _walk(root):
            if node.type != "assignment_expression":
                continue
            left = node.child_by_field_name("left")
            right = node.child_by_field_name("right")
            if left is None or right is None:
                continue
            left_text = left.text.decode("utf-8") if left.text else ""
            right_text = right.text.decode("utf-8") if right.text else ""
            if left_text.endswith("HttpOnly") and right_text == "false":
                findings.append(self._make_finding(node, plugin, file_path))

        return findings
