"""Direct admin privilege assignment in C# (CWE-266).

SC643 — Assignment of admin/root privileges to an object property  medium  CWE-266
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from tree_sitter import Node, Tree

from sanicode.rules.base import Rule, _walk
from sanicode.scanner.patterns import Finding

if TYPE_CHECKING:
    from sanicode.scanner.languages.base import TreeSitterPlugin

# Property names that directly grant elevated boolean status when set to true.
_BOOL_PRIV_PROPS: frozenset[str] = frozenset({"IsAdmin", "IsSuperuser", "IsStaff"})

# Property names whose string value may indicate a privilege level.
_ROLE_PROPS: frozenset[str] = frozenset({"Role", "Privilege"})

# Admin-like string values (lower-cased for comparison).
_ADMIN_VALUES: frozenset[str] = frozenset(
    {"admin", "root", "superuser", "administrator"}
)


def _node_text(node: Node) -> str:
    return node.text.decode("utf-8") if node.text else ""


def _string_literal_value(node: Node) -> str | None:
    """Return the content of a simple C# string_literal (no interpolation)."""
    if node.type != "string_literal":
        return None
    for child in node.children:
        if child.type == "string_literal_content":
            return _node_text(child)
    return None


class CSharpPrivilegeAssignmentRule(Rule):
    """Detect direct assignment of admin/root privileges (CWE-266)."""

    rule_id = "SC643"
    cwe_id = 266
    severity = "medium"
    language = "csharp"
    message = (
        "Direct admin privilege assignment "
        "— review for least privilege (CWE-266)"
    )
    tags = ["auth"]
    domain = "access_control"
    action = "review"

    def check(self, tree: Tree, file_path: Path, plugin: TreeSitterPlugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in _walk(tree.root_node):
            if node.type != "assignment_expression":
                continue
            lhs = node.child_by_field_name("left")
            rhs = node.child_by_field_name("right")
            if lhs is None or rhs is None:
                continue
            if lhs.type != "member_access_expression":
                continue

            # The property name is in the `name` field of member_access_expression.
            name_node = lhs.child_by_field_name("name")
            if name_node is None:
                continue
            prop_name = _node_text(name_node)

            if prop_name in _BOOL_PRIV_PROPS:
                # Flag when RHS is the literal `true`.
                if rhs.type == "boolean_literal" and _node_text(rhs).lower() == "true":
                    findings.append(self._make_finding(node, plugin, file_path))

            elif prop_name in _ROLE_PROPS:
                # Flag when RHS is a hardcoded admin-like string literal.
                value = _string_literal_value(rhs)
                if value is not None and value.lower() in _ADMIN_VALUES:
                    findings.append(self._make_finding(node, plugin, file_path))

        return findings
