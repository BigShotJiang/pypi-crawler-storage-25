"""Insecure random number generation detection for C# (CWE-330).

SC632 — Use of System.Random — not cryptographically secure    medium  CWE-330
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.csharp._helpers import csharp_method_name
from sanicode.scanner.patterns import Finding

_RANDOM_METHODS = frozenset({
    "Next", "NextDouble", "NextBytes", "NextInt64", "NextSingle",
})


class CSharpInsecureRandomRule(Rule):
    """Detect System.Random usage — not cryptographically secure."""

    rule_id = "SC632"
    cwe_id = 330
    severity = "medium"
    language = "csharp"
    message = (
        "Use of System.Random — not cryptographically secure, "
        "use RandomNumberGenerator instead (CWE-330)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []

        # Pattern 1: method calls using Random-specific method names.
        # Without type inference we check that the receiver does NOT contain
        # "NumberGenerator", which excludes obvious RandomNumberGenerator usage.
        call_captures = plugin.captures("(invocation_expression) @call", tree.root_node)
        for call_node in call_captures.get("call", []):
            receiver, method = csharp_method_name(call_node)
            if method not in _RANDOM_METHODS:
                continue
            if "NumberGenerator" in receiver:
                continue
            findings.append(self._make_finding(call_node, plugin, file_path))

        # Pattern 2: new Random() constructor
        new_captures = plugin.captures("(object_creation_expression) @new", tree.root_node)
        for new_node in new_captures.get("new", []):
            type_node = new_node.child_by_field_name("type")
            if type_node is None:
                continue
            type_name = type_node.text.decode("utf-8") if type_node.text else ""
            if type_name == "Random":
                findings.append(self._make_finding(new_node, plugin, file_path))

        return findings
