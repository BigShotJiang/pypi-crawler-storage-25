"""Error detail exposure detection for C# (CWE-209).

SC641 — ex.Message / ex.StackTrace / ex.ToString() in catch    medium  CWE-209
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Node, Tree

from sanicode.rules.base import Rule, _walk
from sanicode.scanner.patterns import Finding

_DETAIL_PROPERTIES = frozenset({"Message", "StackTrace"})
_DETAIL_METHODS = frozenset({"ToString"})


def _catch_var_name(catch_clause: Node) -> str:
    """Extract the exception parameter name from a catch_clause.

    ``catch_declaration`` children: ``(``, type identifier, variable identifier, ``)``.
    The last ``identifier`` child is the variable name.
    """
    for child in catch_clause.children:
        if child.type == "catch_declaration":
            last_ident: str = ""
            for gc in child.children:
                if gc.type == "identifier" and gc.text:
                    last_ident = gc.text.decode("utf-8")
            return last_ident
    return ""


def _block_exposes_detail(block: Node, var_name: str) -> list[Node]:
    """Find member_access_expression and invocation_expression nodes that expose detail."""
    hits: list[Node] = []
    if not var_name:
        return hits
    for node in _walk(block):
        if node.type == "member_access_expression":
            expr = node.child_by_field_name("expression")
            name = node.child_by_field_name("name")
            if expr is None or name is None:
                continue
            expr_text = expr.text.decode("utf-8") if expr.text else ""
            name_text = name.text.decode("utf-8") if name.text else ""
            if expr_text == var_name and name_text in _DETAIL_PROPERTIES:
                hits.append(node)
            elif expr_text == var_name and name_text in _DETAIL_METHODS:
                # e.g. ex.ToString — flag the member_access; the invocation wraps it
                hits.append(node)
    return hits


class CSharpErrorDetailRule(Rule):
    """Detect exception detail property/method access in C# catch blocks."""

    rule_id = "SC641"
    cwe_id = 209
    severity = "medium"
    language = "csharp"
    message = (
        "Error detail exposed in exception handler — "
        "may leak implementation details to users (CWE-209)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in _walk(tree.root_node):
            if node.type != "catch_clause":
                continue
            var_name = _catch_var_name(node)
            for child in node.children:
                if child.type == "block":
                    for hit in _block_exposes_detail(child, var_name):
                        findings.append(self._make_finding(hit, plugin, file_path))
        return findings
