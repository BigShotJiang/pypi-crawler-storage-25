"""Weak cryptography detection rules for C# (CWE-327).

SC612 — MD5.Create()/SHA1.Create()/new MD5CryptoServiceProvider()    medium  CWE-327
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule, _walk
from sanicode.rules.csharp._helpers import csharp_dotted_name, csharp_method_name
from sanicode.scanner.patterns import Finding

_WEAK_FACTORY_RECEIVERS = frozenset({
    "MD5", "SHA1",
    "System.Security.Cryptography.MD5",
    "System.Security.Cryptography.SHA1",
})

_WEAK_CONSTRUCTOR_TYPES = frozenset({
    "MD5CryptoServiceProvider",
    "SHA1CryptoServiceProvider",
    "MD5Managed",
    "SHA1Managed",
})


class CSharpWeakCryptoRule(Rule):
    """Detect MD5.Create()/SHA1.Create() and new MD5CryptoServiceProvider() — weak hash."""

    rule_id = "SC612"
    cwe_id = 327
    severity = "medium"
    language = "csharp"
    message = "Use of weak hash algorithm (MD5/SHA1) — unsuitable for security (CWE-327)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []

        # Pattern 1: Factory calls — MD5.Create() / SHA1.Create()
        call_captures = plugin.captures(
            "(invocation_expression) @call", tree.root_node
        )
        for call_node in call_captures.get("call", []):
            receiver, method = csharp_method_name(call_node)
            if method == "Create" and receiver in _WEAK_FACTORY_RECEIVERS:
                findings.append(self._make_finding(call_node, plugin, file_path))

        # Pattern 2: Constructor — new MD5CryptoServiceProvider() etc.
        for node in _walk(tree.root_node):
            if node.type != "object_creation_expression":
                continue
            type_node = node.child_by_field_name("type")
            if type_node is None:
                continue
            type_name = csharp_dotted_name(type_node)
            if type_name in _WEAK_CONSTRUCTOR_TYPES:
                findings.append(self._make_finding(node, plugin, file_path))

        return findings
