"""Shared helpers for C# rule modules.

These mirror the private helpers in ``scanner/languages/csharp.py`` but
are kept here so rule modules don't need to reach into scanner internals.
"""

from __future__ import annotations

from tree_sitter import Node


def csharp_dotted_name(node: Node) -> str:
    """Build a dotted name from a C# tree-sitter node.

    Handles:
    - ``member_access_expression`` (fields: ``expression``, ``name``)
    - ``qualified_name`` (fields: ``qualifier``, ``name``)
    - ``identifier`` — leaf node
    - ``generic_name`` — fallback to raw text
    """
    if node.type == "identifier":
        return node.text.decode("utf-8") if node.text else ""
    if node.type == "member_access_expression":
        expr = node.child_by_field_name("expression")
        name = node.child_by_field_name("name")
        if expr is None or name is None:
            return node.text.decode("utf-8") if node.text else ""
        prefix = csharp_dotted_name(expr)
        suffix = name.text.decode("utf-8") if name.text else ""
        return f"{prefix}.{suffix}" if prefix else suffix
    if node.type == "qualified_name":
        qualifier = node.child_by_field_name("qualifier")
        name = node.child_by_field_name("name")
        if qualifier is None or name is None:
            return node.text.decode("utf-8") if node.text else ""
        prefix = csharp_dotted_name(qualifier)
        suffix = name.text.decode("utf-8") if name.text else ""
        return f"{prefix}.{suffix}" if prefix else suffix
    # Fallback: return raw text (covers generic_name and unknown node types)
    return node.text.decode("utf-8") if node.text else ""


def csharp_method_name(invocation_node: Node) -> tuple[str, str]:
    """Extract ``(receiver_name, method_name)`` from an ``invocation_expression``.

    Returns ``("", method_name)`` for bare (unqualified) calls.
    The ``function`` field may be:
    - ``member_access_expression`` — dotted call (``foo.Bar()``)
    - ``identifier`` — bare call (``Bar()``)
    """
    func_node = invocation_node.child_by_field_name("function")
    if func_node is None:
        return ("", "")

    if func_node.type == "member_access_expression":
        expr = func_node.child_by_field_name("expression")
        name = func_node.child_by_field_name("name")
        receiver = csharp_dotted_name(expr) if expr is not None else ""
        method = name.text.decode("utf-8") if (name and name.text) else ""
        return (receiver, method)

    if func_node.type == "identifier":
        return ("", func_node.text.decode("utf-8") if func_node.text else "")

    # Generic fallback: treat the whole function node as the method name
    return ("", func_node.text.decode("utf-8") if func_node.text else "")


def csharp_call_arguments(node: Node) -> list[Node]:
    """Extract positional argument nodes from an ``invocation_expression`` or
    ``object_creation_expression`` node.

    Looks for an ``argument_list`` child and skips ``(``, ``)``, and ``,``.
    """
    args_node = node.child_by_field_name("arguments")
    if args_node is None:
        # Fall back to searching children for argument_list
        for child in node.children:
            if child.type == "argument_list":
                args_node = child
                break
    if args_node is None:
        return []

    results: list[Node] = []
    for child in args_node.children:
        if child.type in ("(", ")", ","):
            continue
        if child.type == "argument":
            # C# argument nodes have no named fields; the expression is the
            # first (and typically only) named child.
            named = child.named_children
            if named:
                results.append(named[0])
            else:
                results.append(child)
        else:
            results.append(child)
    return results


def csharp_is_string_concat(node: Node) -> bool:
    """Return True if *node* is a ``+`` binary expression where at least one
    operand is a string literal, verbatim string literal, or interpolated
    string expression.

    Also returns True if *node* is itself an ``interpolated_string_expression``.
    """
    if csharp_has_interpolation(node):
        return True
    if node.type == "binary_expression":
        # Check for + operator
        has_plus = False
        for child in node.children:
            if child.type == "+" or (child.text and child.text == b"+"):
                has_plus = True
                break
        if not has_plus:
            return False
        # At least one operand must be a string literal or interpolated string
        for child in node.children:
            if child.type in (
                "string_literal",
                "verbatim_string_literal",
                "interpolated_string_expression",
            ):
                return True
    return False


def csharp_has_interpolation(node: Node) -> bool:
    """Return True if *node* is or contains an ``interpolated_string_expression``."""
    if node.type == "interpolated_string_expression":
        return True
    for child in node.children:
        if csharp_has_interpolation(child):
            return True
    return False


def csharp_is_unsafe_string_arg(node: Node) -> bool:
    """Return True if the first argument of a call is a string concat or
    interpolated string — the common pattern for SQL/LDAP injection.

    *node* should be an ``invocation_expression`` or
    ``object_creation_expression``.
    """
    args = csharp_call_arguments(node)
    if not args:
        return False
    first = args[0]
    return csharp_is_string_concat(first)
