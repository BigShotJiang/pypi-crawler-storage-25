"""TLS certificate verification bypass detection for C# (CWE-295).

SC656 — ServerCertificateValidationCallback bypass    high  CWE-295
"""
from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule, _walk
from sanicode.scanner.patterns import Finding


class CSharpTLSBypassRule(Rule):
    """Detect ServerCertificateValidationCallback assigned to always-true lambda.

    Flags assignments like:
    ``ServicePointManager.ServerCertificateValidationCallback = (s, c, ch, e) => true``
    or any assignment to a property named ``ServerCertificateValidationCallback``.
    """

    rule_id = "SC656"
    cwe_id = 295
    severity = "high"
    language = "csharp"
    message = (
        "TLS certificate verification bypassed"
        " — ServerCertificateValidationCallback returns true (CWE-295)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []

        for node in _walk(tree.root_node):
            if node.type != "assignment_expression":
                continue
            left = node.child_by_field_name("left")
            if left is None:
                continue
            left_text = plugin.node_text(left)
            if "ServerCertificateValidationCallback" not in left_text:
                continue
            # Any assignment to ServerCertificateValidationCallback is suspicious.
            # In practice it's almost always a bypass lambda.
            right = node.child_by_field_name("right")
            if right is None:
                continue
            right_text = plugin.node_text(right)
            # Flag if the lambda/delegate body returns true or contains "=> true"
            if "true" in right_text.lower():
                findings.append(self._make_finding(node, plugin, file_path))

        return findings
