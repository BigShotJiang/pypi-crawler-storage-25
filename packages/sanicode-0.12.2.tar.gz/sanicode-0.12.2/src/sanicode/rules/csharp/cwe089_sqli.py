"""SQL injection detection rules for C# (CWE-89).

SC602 — SqlCommand/SqlDataAdapter with string concat/interpolation   high  CWE-89
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.csharp._helpers import csharp_is_unsafe_string_arg, csharp_method_name
from sanicode.scanner.patterns import Finding

_SQL_CONSTRUCTORS = frozenset({"SqlCommand", "SqlDataAdapter", "NpgsqlCommand", "MySqlCommand"})

_EF_CORE_METHODS = frozenset({
    "FromSql", "FromSqlRaw", "ExecuteSqlRaw", "ExecuteSqlCommand", "SqlQuery",
})


class CSharpSqlInjectionRule(Rule):
    """Detect SqlCommand/SqlDataAdapter with string concatenation — SQL injection risk."""

    rule_id = "SC602"
    cwe_id = 89
    severity = "high"
    language = "csharp"
    message = (
        "SqlCommand/SqlDataAdapter with string concatenation or interpolation — "
        "SQL injection risk (CWE-89)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        new_captures = plugin.captures("(object_creation_expression) @new", root)
        for new_node in new_captures.get("new", []):
            type_node = new_node.child_by_field_name("type")
            if type_node is None:
                continue
            type_name = type_node.text.decode("utf-8") if type_node.text else ""
            if type_name not in _SQL_CONSTRUCTORS:
                continue
            if csharp_is_unsafe_string_arg(new_node):
                findings.append(self._make_finding(new_node, plugin, file_path))

        # EF Core raw SQL methods: FromSqlRaw, ExecuteSqlRaw, SqlQuery, etc.
        inv_captures = plugin.captures("(invocation_expression) @inv", root)
        for inv_node in inv_captures.get("inv", []):
            _, method = csharp_method_name(inv_node)
            if method not in _EF_CORE_METHODS:
                continue
            if csharp_is_unsafe_string_arg(inv_node):
                findings.append(self._make_finding(inv_node, plugin, file_path))

        return findings
