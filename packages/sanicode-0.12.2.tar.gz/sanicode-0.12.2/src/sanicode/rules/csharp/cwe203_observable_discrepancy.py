"""Observable discrepancy via distinguishable auth error messages for C# (CWE-203).

SC648 — Auth function has distinguishable error messages    medium  CWE-203
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Node, Tree

from sanicode.rules.base import Rule, _walk
from sanicode.scanner.patterns import Finding

# Method name substrings that indicate an auth context.
# Includes both snake_case and lowercased camelCase variants so that names like
# "verifyPassword" (lowercased → "verifypassword") are matched.
_AUTH_KEYWORDS = frozenset(
    {
        "login",
        "authenticate",
        "verify_password",
        "sign_in",
        "check_credentials",
        "check_user",
        "verifypassword",
        "signin",
        "checkcredentials",
        "checkuser",
    }
)

# Keywords that suggest the error is about the user/account side.
_USER_KEYWORDS = frozenset({"user", "account", "not found", "unknown", "does not exist"})

# Keywords that suggest the error is about the credential/password side.
_PASS_KEYWORDS = frozenset({"password", "credentials", "invalid", "wrong", "incorrect"})


def _is_auth_method(name: str) -> bool:
    lowered = name.lower()
    return any(kw in lowered for kw in _AUTH_KEYWORDS)


def _collect_string_literals(node: Node) -> list[str]:
    """Collect all string literal values from a subtree (string_literal and interpolated)."""
    results: list[str] = []
    for n in _walk(node):
        if n.type == "string_literal" and n.text:
            raw = n.text.decode("utf-8")
            results.append(raw.strip('"\'@'))
        elif n.type == "interpolated_string_expression" and n.text:
            raw = n.text.decode("utf-8")
            results.append(raw)
    return results


def _branch_has_keyword(strings: list[str], keywords: frozenset[str]) -> bool:
    combined = " ".join(s.lower() for s in strings)
    return any(kw in combined for kw in keywords)


def _check_if_statement(if_node: Node) -> bool:
    """Return True if the if/else branches have distinguishable user vs password messages.

    Uses the strict exclusive-keyword check: a branch that contains *both* user
    and password keywords (e.g. "Invalid username or password") is a generic
    combined message and must not be treated as distinguishable.
    """
    consequence = if_node.child_by_field_name("consequence")
    alternative = if_node.child_by_field_name("alternative")
    if consequence is None or alternative is None:
        return False

    then_strings = _collect_string_literals(consequence)
    else_strings = _collect_string_literals(alternative)

    if not then_strings or not else_strings:
        return False

    then_user = _branch_has_keyword(then_strings, _USER_KEYWORDS)
    then_pass = _branch_has_keyword(then_strings, _PASS_KEYWORDS)
    else_user = _branch_has_keyword(else_strings, _USER_KEYWORDS)
    else_pass = _branch_has_keyword(else_strings, _PASS_KEYWORDS)

    # Flag only when one branch is exclusively user-oriented and the other
    # exclusively password-oriented.
    then_only_user = then_user and not then_pass
    then_only_pass = then_pass and not then_user
    else_only_user = else_user and not else_pass
    else_only_pass = else_pass and not else_user

    return (then_only_user and else_only_pass) or (then_only_pass and else_only_user)


class CSharpObservableDiscrepancyRule(Rule):
    """Detect auth methods with distinguishable error messages across if/else branches."""

    rule_id = "SC648"
    cwe_id = 203
    severity = "medium"
    language = "csharp"
    tags = ["auth", "info_disclosure"]
    domain = "authentication"
    action = "review"
    message = (
        "Auth function has distinguishable error messages "
        "— may reveal account existence (CWE-203)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in _walk(tree.root_node):
            if node.type != "method_declaration":
                continue
            name_node = node.child_by_field_name("name")
            if name_node is None or not name_node.text:
                continue
            method_name = name_node.text.decode("utf-8")
            if not _is_auth_method(method_name):
                continue
            body = node.child_by_field_name("body")
            if body is None:
                continue
            for child in _walk(body):
                if child.type == "if_statement" and _check_if_statement(child):
                    findings.append(self._make_finding(child, plugin, file_path))
        return findings
