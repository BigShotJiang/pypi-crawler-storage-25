"""Empty catch handler detection for C# (CWE-390).

SC640 — catch clause with empty block body    medium  CWE-390
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Node, Tree

from sanicode.rules.base import Rule, _walk
from sanicode.scanner.patterns import Finding

# Node types that are structural punctuation — not real statements.
_PUNCTUATION = frozenset({"{", "}", "comment"})


def _block_is_empty(block: Node) -> bool:
    """Return True if a C# block contains no real statements."""
    for child in block.children:
        if child.type in _PUNCTUATION or child.is_extra:
            continue
        return False
    return True


class CSharpEmptyCatchRule(Rule):
    """Detect catch clauses with an empty block body."""

    rule_id = "SC640"
    cwe_id = 390
    severity = "medium"
    language = "csharp"
    message = (
        "Empty catch block — exception silently swallowed, "
        "errors go undetected (CWE-390)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in _walk(tree.root_node):
            if node.type != "catch_clause":
                continue
            for child in node.children:
                if child.type == "block" and _block_is_empty(child):
                    findings.append(self._make_finding(node, plugin, file_path))
                    break
        return findings
