"""Clickjacking protection bypass detection for C# (CWE-1021).

SC651 — X-Frame-Options set to permissive value or removed    medium  CWE-1021
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.csharp._helpers import (
    csharp_call_arguments,
    csharp_method_name,
)
from sanicode.scanner.patterns import Finding

_HEADER_NAME = "x-frame-options"
# Values that explicitly disable frame protection
_PERMISSIVE_VALUES = frozenset({"ALLOWALL", ""})


def _string_text(node) -> str:
    """Extract unquoted text from a C# string literal."""
    if node.type not in ("string_literal", "verbatim_string_literal"):
        return ""
    text = node.text.decode("utf-8") if node.text else ""
    return text.lstrip("@").strip('"')


class CSharpClickjackingRule(Rule):
    """Detect permissive or absent X-Frame-Options header configuration in C#."""

    rule_id = "SC651"
    cwe_id = 1021
    severity = "medium"
    language = "csharp"
    message = (
        "Clickjacking protection disabled or weakened "
        "\u2014 verify X-Frame-Options/CSP configuration (CWE-1021)"
    )
    tags = ["clickjacking", "headers"]
    domain = "web"
    action = "review"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(invocation_expression) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            receiver, method = csharp_method_name(call_node)

            if method == "Remove":
                # Response.Headers.Remove("X-Frame-Options") — removes protection
                args = csharp_call_arguments(call_node)
                if len(args) < 1:
                    continue
                header_text = _string_text(args[0])
                if header_text.lower() == _HEADER_NAME:
                    # Require the receiver to reference Headers to avoid false positives
                    # on unrelated Remove() calls
                    if "Headers" in receiver:
                        findings.append(self._make_finding(call_node, plugin, file_path))

            elif method == "Add":
                # Response.Headers.Add("X-Frame-Options", <permissive_value>)
                args = csharp_call_arguments(call_node)
                if len(args) < 2:
                    continue
                header_text = _string_text(args[0])
                if header_text.lower() != _HEADER_NAME:
                    continue
                value_text = _string_text(args[1]).upper()
                if value_text in _PERMISSIVE_VALUES:
                    findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
