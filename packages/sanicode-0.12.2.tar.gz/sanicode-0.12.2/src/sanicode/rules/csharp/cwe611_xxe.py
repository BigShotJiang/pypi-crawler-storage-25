"""XML external entity injection detection rules for C# (CWE-611).

SC608 — XmlDocument/XmlTextReader without safe resolver   high  CWE-611
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.scanner.patterns import Finding

_XXE_TYPES = frozenset({"XmlDocument", "XmlTextReader", "XmlReader"})


class CSharpXxeRule(Rule):
    """Detect XmlDocument/XmlTextReader without a verified safe XmlResolver."""

    rule_id = "SC608"
    cwe_id = 611
    severity = "high"
    language = "csharp"
    message = (
        "XmlDocument/XmlTextReader without verified safe XmlResolver — "
        "XXE risk (CWE-611)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        new_captures = plugin.captures("(object_creation_expression) @new", root)
        for new_node in new_captures.get("new", []):
            type_node = new_node.child_by_field_name("type")
            if type_node and type_node.text:
                type_name = type_node.text.decode("utf-8")
                if type_name in _XXE_TYPES:
                    findings.append(self._make_finding(new_node, plugin, file_path))

        return findings
