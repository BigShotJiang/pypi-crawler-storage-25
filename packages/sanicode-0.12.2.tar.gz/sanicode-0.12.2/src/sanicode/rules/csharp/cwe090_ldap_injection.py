"""LDAP injection detection rules for C# (CWE-90).

SC607 — DirectorySearcher.Filter with string concat/interpolation   high  CWE-90
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.csharp._helpers import csharp_has_interpolation, csharp_is_string_concat
from sanicode.scanner.patterns import Finding


class CSharpLdapInjectionRule(Rule):
    """Detect DirectorySearcher.Filter assignment with string concat — LDAP injection risk."""

    rule_id = "SC607"
    cwe_id = 90
    severity = "high"
    language = "csharp"
    message = (
        "DirectorySearcher.Filter with string concatenation or interpolation — "
        "LDAP injection risk (CWE-90)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        assign_captures = plugin.captures("(assignment_expression) @assign", root)
        for assign_node in assign_captures.get("assign", []):
            left = assign_node.child_by_field_name("left")
            right = assign_node.child_by_field_name("right")
            if left is None or right is None:
                continue

            # Only flag member access expressions (e.g. searcher.Filter = ...)
            if left.type != "member_access_expression":
                continue

            name_node = left.child_by_field_name("name")
            if name_node is None or not name_node.text:
                continue
            if name_node.text.decode("utf-8") != "Filter":
                continue

            if csharp_is_string_concat(right) or csharp_has_interpolation(right):
                findings.append(self._make_finding(assign_node, plugin, file_path))

        return findings
