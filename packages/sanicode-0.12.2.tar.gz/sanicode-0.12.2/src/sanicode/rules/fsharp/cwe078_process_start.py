"""Process.Start() with non-literal argument detection for F# (CWE-78).

SC2001 — Process.Start() with non-literal argument — command injection risk    high  CWE-78
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.fsharp._helpers import (
    fsharp_call_name,
    fsharp_first_arg,
    fsharp_is_const_string,
)
from sanicode.scanner.patterns import Finding


class FSharpProcessStartRule(Rule):
    """Detect Process.Start() called with a non-literal argument."""

    rule_id = "SC2001"
    cwe_id = 78
    severity = "high"
    language = "fsharp"
    message = "Process.Start() with non-literal argument — command injection risk (CWE-78)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if node.type != "application_expression":
                continue
            if fsharp_call_name(node) != "Process.Start":
                continue
            first = fsharp_first_arg(node)
            if first is None:
                continue
            if not fsharp_is_const_string(first):
                findings.append(self._make_finding(node, plugin, file_path))
        return findings
