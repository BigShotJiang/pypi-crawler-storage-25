"""Hardcoded credential detection for F# (CWE-798).

SC2009 — Hardcoded credential in let binding — sensitive data in source    medium  CWE-798
"""

from __future__ import annotations

import re
from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.fsharp._helpers import (
    fsharp_is_const_string,
    fsharp_let_body,
    fsharp_let_name,
)
from sanicode.scanner.patterns import Finding

_CRED_RE = re.compile(
    r"(password|passwd|secret|api_?key|token|credential|auth_?token)",
    re.IGNORECASE,
)


class FSharpHardcodedCredsRule(Rule):
    """Detect let bindings with credential-named identifiers assigned a literal string."""

    rule_id = "SC2009"
    cwe_id = 798
    severity = "medium"
    language = "fsharp"
    message = "Hardcoded credential in let binding — sensitive data in source (CWE-798)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if node.type != "function_or_value_defn":
                continue
            name = fsharp_let_name(node)
            if not name or not _CRED_RE.search(name):
                continue
            body = fsharp_let_body(node)
            if body is not None and fsharp_is_const_string(body):
                findings.append(self._make_finding(node, plugin, file_path))
        return findings
