"""XXE-vulnerable XML parsing detection for F# (CWE-611).

SC2010 — XmlDocument.Load / XDocument.Parse / XmlReader.Create — XXE risk    high  CWE-611
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.fsharp._helpers import fsharp_call_name
from sanicode.scanner.patterns import Finding

_XXE_FUNCS = frozenset({
    "XmlDocument.Load",
    "XmlDocument.LoadXml",
    "XDocument.Load",
    "XDocument.Parse",
    "XmlReader.Create",
})


class FSharpXxeRule(Rule):
    """Detect XXE-vulnerable XML parsing calls — flagged unconditionally."""

    rule_id = "SC2010"
    cwe_id = 611
    severity = "high"
    language = "fsharp"
    message = (
        "XXE-vulnerable XML parsing — external entity processing risk (CWE-611). "
        "Disable DTD processing or use XmlReaderSettings with DtdProcessing.Prohibit."
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if node.type != "application_expression":
                continue
            if fsharp_call_name(node) in _XXE_FUNCS:
                findings.append(self._make_finding(node, plugin, file_path))
        return findings
