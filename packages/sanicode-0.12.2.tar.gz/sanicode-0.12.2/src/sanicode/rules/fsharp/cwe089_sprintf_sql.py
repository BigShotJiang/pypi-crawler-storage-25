"""sprintf/String.Format with SQL keyword detection for F# (CWE-89).

SC2007 — sprintf/String.Format used to build SQL query — SQL injection risk    high  CWE-89
"""

from __future__ import annotations

import re
from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.fsharp._helpers import (
    _node_text,
    fsharp_call_name,
    fsharp_first_arg,
    fsharp_has_concat,
)
from sanicode.scanner.patterns import Finding

_SQL_RE = re.compile(
    r"\b(SELECT|INSERT|UPDATE|DELETE|DROP|ALTER|CREATE|EXEC)\b", re.IGNORECASE
)
_FORMAT_TARGETS = frozenset({"sprintf", "String.Format"})


class FSharpSprintfSqlRule(Rule):
    """Detect sprintf/String.Format and + concatenation building SQL queries."""

    rule_id = "SC2007"
    cwe_id = 89
    severity = "high"
    language = "fsharp"
    message = "sprintf/String.Format used to build SQL query — SQL injection risk (CWE-89)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        seen: set[int] = set()

        for node in plugin.walk(tree.root_node):
            if node.type == "application_expression":
                name = fsharp_call_name(node)
                if name in _FORMAT_TARGETS:
                    first = fsharp_first_arg(node)
                    if first is not None and _SQL_RE.search(_node_text(first)):
                        if id(node) not in seen:
                            seen.add(id(node))
                            findings.append(self._make_finding(node, plugin, file_path))

            if node.type == "infix_expression" and fsharp_has_concat(node):
                if _SQL_RE.search(_node_text(node)):
                    if id(node) not in seen:
                        seen.add(id(node))
                        findings.append(self._make_finding(node, plugin, file_path))

        return findings
