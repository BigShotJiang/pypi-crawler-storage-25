"""Unsafe deserialization detection for F# (CWE-502).

SC2003 — Unsafe deserialization call — untrusted data deserialization risk    high  CWE-502
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.fsharp._helpers import fsharp_call_name
from sanicode.scanner.patterns import Finding

_DESER_TARGETS = frozenset(
    {"JsonConvert.DeserializeObject", "BinaryFormatter.Deserialize"}
)


class FSharpDeserializationRule(Rule):
    """Detect unsafe deserialization calls — flag all uses regardless of argument."""

    rule_id = "SC2003"
    cwe_id = 502
    severity = "high"
    language = "fsharp"
    message = "Unsafe deserialization call — untrusted data deserialization risk (CWE-502)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if node.type != "application_expression":
                continue
            if fsharp_call_name(node) in _DESER_TARGETS:
                findings.append(self._make_finding(node, plugin, file_path))
        return findings
