"""Weak cryptographic algorithm detection for F# (CWE-327).

SC2008 — Weak cryptographic algorithm used — use a stronger alternative    medium  CWE-327
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.fsharp._helpers import fsharp_call_name
from sanicode.scanner.patterns import Finding

_WEAK_CRYPTO_TARGETS = frozenset(
    {"MD5.Create", "SHA1.Create", "DES.Create", "RC2.Create"}
)


class FSharpWeakCryptoRule(Rule):
    """Detect use of known weak cryptographic algorithms."""

    rule_id = "SC2008"
    cwe_id = 327
    severity = "medium"
    language = "fsharp"
    message = "Weak cryptographic algorithm used — use a stronger alternative (CWE-327)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if node.type != "application_expression":
                continue
            if fsharp_call_name(node) in _WEAK_CRYPTO_TARGETS:
                findings.append(self._make_finding(node, plugin, file_path))
        return findings
