"""SqlCommand/SqlDataAdapter with non-literal argument detection for F# (CWE-89).

SC2002 — SqlCommand with non-literal query argument — SQL injection risk    high  CWE-89
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.fsharp._helpers import (
    fsharp_call_name,
    fsharp_first_arg,
    fsharp_is_const_string,
)
from sanicode.scanner.patterns import Finding

_SQL_TARGETS = frozenset({"SqlCommand", "SqlDataAdapter"})


class FSharpSqlCommandRule(Rule):
    """Detect SqlCommand/SqlDataAdapter called with a non-literal query argument."""

    rule_id = "SC2002"
    cwe_id = 89
    severity = "high"
    language = "fsharp"
    message = "SqlCommand with non-literal query argument — SQL injection risk (CWE-89)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if node.type == "application_expression":
                name = fsharp_call_name(node)
                if name in _SQL_TARGETS:
                    first = fsharp_first_arg(node)
                    if first is not None and not fsharp_is_const_string(first):
                        findings.append(self._make_finding(node, plugin, file_path))
            elif node.type == "prefixed_expression":
                # new SqlCommand(...) constructor pattern
                for child in node.children:
                    if child.type == "application_expression":
                        name = fsharp_call_name(child)
                        if name in _SQL_TARGETS:
                            first = fsharp_first_arg(child)
                            if first is not None and not fsharp_is_const_string(first):
                                findings.append(self._make_finding(node, plugin, file_path))
        return findings
