"""HTTP client calls with non-literal URL detection for F# (CWE-918).

SC2005 — HTTP client call with non-literal URL — SSRF risk    medium  CWE-918
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.fsharp._helpers import (
    fsharp_call_name,
    fsharp_first_arg,
    fsharp_is_const_string,
)
from sanicode.scanner.patterns import Finding

_HTTP_TARGETS = frozenset(
    {
        "HttpClient.GetAsync",
        "HttpClient.PostAsync",
        "HttpClient.GetStringAsync",
        "WebRequest.Create",
    }
)


class FSharpSsrfRule(Rule):
    """Detect HTTP client calls with a non-literal URL argument."""

    rule_id = "SC2005"
    cwe_id = 918
    severity = "medium"
    language = "fsharp"
    message = "HTTP client call with non-literal URL — SSRF risk (CWE-918)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if node.type != "application_expression":
                continue
            if fsharp_call_name(node) not in _HTTP_TARGETS:
                continue
            first = fsharp_first_arg(node)
            if first is None:
                continue
            if not fsharp_is_const_string(first):
                findings.append(self._make_finding(node, plugin, file_path))
        return findings
