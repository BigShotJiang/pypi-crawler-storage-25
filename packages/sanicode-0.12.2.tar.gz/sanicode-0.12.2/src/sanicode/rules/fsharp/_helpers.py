"""Shared helpers for F# rule modules."""

from __future__ import annotations

from tree_sitter import Node


def _node_text(node: Node) -> str:
    """Return the UTF-8 source text of *node*."""
    return node.text.decode("utf-8") if node.text else ""


def _collect_long_identifier_parts(node: Node) -> list[str]:
    """Recursively collect identifier text from a long_identifier node."""
    parts: list[str] = []
    for child in node.children:
        if child.type == "identifier":
            parts.append(_node_text(child))
        elif child.type == "long_identifier":
            parts.extend(_collect_long_identifier_parts(child))
    return parts


def fsharp_call_name(node: Node) -> str:
    """Extract the dotted function name from an application_expression callee.

    Child 0 of an application_expression is the callee. Handles:
    - Simple: long_identifier_or_op > long_identifier > identifier+
    - Generic: typed_expression wrapping long_identifier_or_op
    """
    if not node.children:
        return ""
    callee = node.children[0]

    # Unwrap typed_expression (generic calls like JsonConvert.DeserializeObject<T>)
    if callee.type == "typed_expression":
        for child in callee.children:
            if child.type == "long_identifier_or_op":
                callee = child
                break

    if callee.type == "long_identifier_or_op":
        for child in callee.children:
            if child.type == "long_identifier":
                return ".".join(_collect_long_identifier_parts(child))
            if child.type == "identifier":
                return _node_text(child)

    # Fallback: try to read identifier directly
    if callee.type == "identifier":
        return _node_text(callee)

    return ""


def fsharp_call_args(node: Node) -> list[Node]:
    """Return argument nodes from an application_expression, excluding callee and noise."""
    if len(node.children) <= 1:
        return []
    return [
        child for child in node.children[1:]
        if child.type not in ("(", ")", ",", "unit")
    ]


def fsharp_first_arg(node: Node) -> Node | None:
    """Return the first argument node from an application_expression, or None."""
    args = fsharp_call_args(node)
    return args[0] if args else None


def fsharp_is_const_string(node: Node) -> bool:
    """Return True if *node* is a const > string literal (not interpolated)."""
    if node.type != "const":
        return False
    for child in node.children:
        if child.type == "string":
            # Interpolated strings contain format_string > format_string_eval
            for grandchild in child.children:
                if grandchild.type == "format_string":
                    return False
            return True
    return False


def fsharp_has_interpolation(node: Node) -> bool:
    """Return True if *node* or any descendant contains a format_string_eval node."""
    if node.type == "format_string_eval":
        return True
    for child in node.children:
        if fsharp_has_interpolation(child):
            return True
    return False


def fsharp_has_concat(node: Node) -> bool:
    """Return True if *node* is or contains an infix_expression using the + operator."""
    if node.type == "infix_expression":
        for child in node.children:
            if child.type == "infix_op" and _node_text(child) == "+":
                return True
    for child in node.children:
        if fsharp_has_concat(child):
            return True
    return False


def fsharp_let_name(node: Node) -> str:
    """Return the binding name from a function_or_value_defn node.

    Handles both value bindings (value_declaration_left) and function
    bindings (function_declaration_left).
    """
    for child in node.children:
        if child.type == "value_declaration_left":
            for desc in child.children:
                if desc.type == "identifier_pattern":
                    for inner in desc.children:
                        if inner.type == "long_identifier_or_op":
                            for leaf in inner.children:
                                if leaf.type == "identifier":
                                    return _node_text(leaf)
                        if inner.type == "identifier":
                            return _node_text(inner)
        if child.type == "function_declaration_left":
            for desc in child.children:
                if desc.type == "identifier":
                    return _node_text(desc)
    return ""


def fsharp_let_body(node: Node) -> Node | None:
    """Return the body expression from a function_or_value_defn node.

    The body is the last meaningful child — everything after the '=' token.
    """
    last: Node | None = None
    seen_eq = False
    for child in node.children:
        if _node_text(child) == "=":
            seen_eq = True
            continue
        if seen_eq:
            last = child
    return last
