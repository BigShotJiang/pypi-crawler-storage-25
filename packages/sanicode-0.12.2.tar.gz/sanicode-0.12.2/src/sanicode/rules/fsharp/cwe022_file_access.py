"""File access with non-literal path argument detection for F# (CWE-22).

SC2004 — File access with non-literal path — path traversal risk    medium  CWE-22
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.fsharp._helpers import (
    fsharp_call_name,
    fsharp_first_arg,
    fsharp_is_const_string,
)
from sanicode.scanner.patterns import Finding

_FILE_TARGETS = frozenset(
    {"File.ReadAllText", "File.Open", "File.ReadAllLines", "File.WriteAllText"}
)


class FSharpFileAccessRule(Rule):
    """Detect File API calls with a non-literal path argument."""

    rule_id = "SC2004"
    cwe_id = 22
    severity = "medium"
    language = "fsharp"
    message = "File access with non-literal path — path traversal risk (CWE-22)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if node.type != "application_expression":
                continue
            if fsharp_call_name(node) not in _FILE_TARGETS:
                continue
            first = fsharp_first_arg(node)
            if first is None:
                continue
            if not fsharp_is_const_string(first):
                findings.append(self._make_finding(node, plugin, file_path))
        return findings
