"""F#-specific pattern detection rules."""
