"""Dynamic method invocation / reflection detection for F# (CWE-470).

SC2011 — Type.InvokeMember / MethodInfo.Invoke / Activator.CreateInstance
         — reflection risk    high  CWE-470

Note: Assembly.LoadFrom / Assembly.LoadFile are covered by SC2006 (CWE-94).
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.fsharp._helpers import fsharp_call_name
from sanicode.scanner.patterns import Finding

_DYNAMIC_INVOKE_FUNCS = frozenset({
    "Type.InvokeMember",
    "MethodInfo.Invoke",
    "Activator.CreateInstance",
})


class FSharpDynamicInvokeRule(Rule):
    """Detect dynamic method invocation / reflection — flagged unconditionally."""

    rule_id = "SC2011"
    cwe_id = 470
    severity = "high"
    language = "fsharp"
    message = (
        "Dynamic method invocation via reflection — unsafe class instantiation risk (CWE-470). "
        "Validate inputs or use explicit type references."
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if node.type != "application_expression":
                continue
            if fsharp_call_name(node) in _DYNAMIC_INVOKE_FUNCS:
                findings.append(self._make_finding(node, plugin, file_path))
        return findings
