"""Assembly.Load with non-literal argument detection for F# (CWE-94).

SC2006 — Assembly.Load with non-literal argument — code injection risk    high  CWE-94
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.fsharp._helpers import (
    fsharp_call_name,
    fsharp_first_arg,
    fsharp_is_const_string,
)
from sanicode.scanner.patterns import Finding

_ASSEMBLY_TARGETS = frozenset(
    {"Assembly.Load", "Assembly.LoadFrom", "Assembly.LoadFile"}
)


class FSharpAssemblyLoadRule(Rule):
    """Detect Assembly.Load* called with a non-literal argument."""

    rule_id = "SC2006"
    cwe_id = 94
    severity = "high"
    language = "fsharp"
    message = "Assembly.Load with non-literal argument — code injection risk (CWE-94)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if node.type != "application_expression":
                continue
            if fsharp_call_name(node) not in _ASSEMBLY_TARGETS:
                continue
            first = fsharp_first_arg(node)
            if first is None:
                continue
            if not fsharp_is_const_string(first):
                findings.append(self._make_finding(node, plugin, file_path))
        return findings
