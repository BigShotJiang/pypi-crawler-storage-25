"""Dynamic file path in SELECT ASSIGN TO detection for COBOL (CWE-22).

SC2109 — Dynamic file path in SELECT ASSIGN TO — path traversal risk    medium  CWE-22
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.cobol._helpers import (
    COBOL_SELECT_STATEMENT,
    cobol_assign_target,
    cobol_is_literal,
)
from sanicode.scanner.patterns import Finding


class COBOLFilePathRule(Rule):
    """Detect dynamic file path in SELECT ASSIGN TO."""

    rule_id = "SC2109"
    cwe_id = 22
    severity = "medium"
    language = "cobol"
    message = "Dynamic file path in SELECT ASSIGN TO — path traversal risk (CWE-22)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if node.type != COBOL_SELECT_STATEMENT:
                continue
            target = cobol_assign_target(node)
            if target is None:
                continue
            if not cobol_is_literal(target):
                findings.append(self._make_finding(node, plugin, file_path))
        return findings
