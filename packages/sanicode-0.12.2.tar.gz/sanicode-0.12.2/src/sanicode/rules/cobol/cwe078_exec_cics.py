"""EXEC CICS LINK/XCTL with dynamic program detection for COBOL (CWE-78).

SC2106 — EXEC CICS LINK/XCTL with dynamic program name    high  CWE-78
"""

from __future__ import annotations

import re
from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.scanner.patterns import Finding

_EXEC_CICS_CMD_RE = re.compile(
    r"EXEC\s+CICS\s+(?:LINK|XCTL)", re.IGNORECASE | re.DOTALL,
)

_LITERAL_PROGRAM_RE = re.compile(
    r"PROGRAM\s*\(\s*'[^']*'\s*\)", re.IGNORECASE,
)


class COBOLExecCICSRule(Rule):
    """Detect EXEC CICS LINK/XCTL with dynamic (non-literal) program name."""

    rule_id = "SC2106"
    cwe_id = 78
    severity = "high"
    language = "cobol"
    message = "EXEC CICS LINK/XCTL with dynamic program name (CWE-78)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if not node.is_error:
                continue
            if node.text is None:
                continue
            text = node.text.decode("utf-8")
            if not _EXEC_CICS_CMD_RE.search(text):
                continue
            # Flag if program name is not a literal
            if not _LITERAL_PROGRAM_RE.search(text):
                findings.append(self._make_finding(node, plugin, file_path))
        return findings
