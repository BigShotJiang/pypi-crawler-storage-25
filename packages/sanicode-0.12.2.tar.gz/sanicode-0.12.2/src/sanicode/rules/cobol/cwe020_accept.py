"""ACCEPT FROM external source detection for COBOL (CWE-20).

SC2103 — ACCEPT FROM external source — unvalidated input    medium  CWE-20
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.cobol._helpers import (
    _EXTERNAL_ACCEPT_SOURCES,
    COBOL_ACCEPT_STATEMENT,
    _node_text,
)
from sanicode.scanner.patterns import Finding


class COBOLAcceptExternalRule(Rule):
    """Detect ACCEPT FROM external source without validation."""

    rule_id = "SC2103"
    cwe_id = 20
    severity = "medium"
    language = "cobol"
    message = "ACCEPT FROM external source — unvalidated input (CWE-20)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if node.type != COBOL_ACCEPT_STATEMENT:
                continue
            # Check for external source indicators
            from_node = node.child_by_field_name("from")
            if from_node is not None:
                source_text = _node_text(from_node).strip().upper()
                if source_text in _EXTERNAL_ACCEPT_SOURCES:
                    findings.append(self._make_finding(node, plugin, file_path))
                    continue
            # Also check WORD children for source keywords
            for child in node.children:
                if child.type == "WORD":
                    word = _node_text(child).strip().upper()
                    if word in _EXTERNAL_ACCEPT_SOURCES:
                        findings.append(self._make_finding(node, plugin, file_path))
                        break
        return findings
