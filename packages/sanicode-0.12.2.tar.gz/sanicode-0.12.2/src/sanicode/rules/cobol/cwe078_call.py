"""CALL with variable program name detection for COBOL (CWE-78).

SC2102 — CALL with variable program name — command injection risk    high  CWE-78
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.cobol._helpers import (
    COBOL_CALL_STATEMENT,
    cobol_call_target,
    cobol_is_literal,
)
from sanicode.scanner.patterns import Finding


class COBOLCallVariableRule(Rule):
    """Detect CALL with variable (non-literal) program name."""

    rule_id = "SC2102"
    cwe_id = 78
    severity = "high"
    language = "cobol"
    message = "CALL with variable program name — command injection risk (CWE-78)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if node.type != COBOL_CALL_STATEMENT:
                continue
            target = cobol_call_target(node)
            if target is None:
                continue
            if not cobol_is_literal(target):
                findings.append(self._make_finding(node, plugin, file_path))
        return findings
