"""STRING/UNSTRING without ON OVERFLOW detection for COBOL (CWE-120).

SC2107 — STRING/UNSTRING without ON OVERFLOW — buffer overflow risk    medium  CWE-120
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.cobol._helpers import (
    COBOL_STRING_STATEMENT,
    COBOL_UNSTRING_STATEMENT,
    cobol_has_overflow,
)
from sanicode.scanner.patterns import Finding


class COBOLStringOverflowRule(Rule):
    """Detect STRING/UNSTRING without ON OVERFLOW handling."""

    rule_id = "SC2107"
    cwe_id = 120
    severity = "medium"
    language = "cobol"
    message = "STRING/UNSTRING without ON OVERFLOW — buffer overflow risk (CWE-120)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if node.type not in (COBOL_STRING_STATEMENT, COBOL_UNSTRING_STATEMENT):
                continue
            if not cobol_has_overflow(node):
                findings.append(self._make_finding(node, plugin, file_path))
        return findings
