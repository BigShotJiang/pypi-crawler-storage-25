"""File I/O without FILE STATUS detection for COBOL (CWE-252).

SC2105 — SELECT without FILE STATUS — unchecked file I/O    medium  CWE-252
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.cobol._helpers import (
    COBOL_SELECT_STATEMENT,
    cobol_has_file_status,
)
from sanicode.scanner.patterns import Finding


class COBOLFileStatusRule(Rule):
    """Detect SELECT without FILE STATUS — unchecked file I/O."""

    rule_id = "SC2105"
    cwe_id = 252
    severity = "medium"
    language = "cobol"
    message = "SELECT without FILE STATUS — unchecked file I/O (CWE-252)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if node.type != COBOL_SELECT_STATEMENT:
                continue
            if not cobol_has_file_status(node):
                findings.append(self._make_finding(node, plugin, file_path))
        return findings
