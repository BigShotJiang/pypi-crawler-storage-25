"""Shared helpers for COBOL rule modules.

Provides node-type constants and utility functions for navigating
the COBOL tree-sitter grammar.
"""

from __future__ import annotations

import re

from tree_sitter import Node

# ---------------------------------------------------------------------------
# Node type constants
# ---------------------------------------------------------------------------

COBOL_CALL_STATEMENT = "call_statement"
COBOL_ACCEPT_STATEMENT = "accept_statement"
COBOL_DISPLAY_STATEMENT = "display_statement"
COBOL_STRING_STATEMENT = "string_statement"
COBOL_UNSTRING_STATEMENT = "unstring_statement"
COBOL_OPEN_STATEMENT = "open_statement"
COBOL_READ_STATEMENT = "read_statement"
COBOL_DATA_DESCRIPTION = "data_description"
COBOL_SELECT_STATEMENT = "select_statement"

# ---------------------------------------------------------------------------
# Sensitive-name pattern (case-insensitive)
# ---------------------------------------------------------------------------

_SENSITIVE_NAME_RE = re.compile(
    r"(?i)(PASSWORD|PASSWD|SECRET|TOKEN|API[_-]?KEY|SSN|ACCT|CREDIT[_-]?CARD)",
)

# External ACCEPT sources that represent user/environment input
_EXTERNAL_ACCEPT_SOURCES = frozenset({
    "CONSOLE", "COMMAND-LINE", "ENVIRONMENT-NAME", "ENVIRONMENT-VALUE",
    "ARGUMENT-NUMBER", "ARGUMENT-VALUE",
})


# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------


def _node_text(node: Node) -> str:
    """Return the UTF-8 source text of *node*."""
    return node.text.decode("utf-8") if node.text else ""


def cobol_entry_name(node: Node) -> str:
    """Extract the variable name from a ``data_description`` node.

    Looks for the ``entry_name`` child and returns its text.
    """
    for child in node.children:
        if child.type == "entry_name":
            return _node_text(child).strip()
    return ""


def cobol_value_text(node: Node) -> str | None:
    """Extract the literal value from a ``data_description`` node.

    Traverses ``value_clause`` → ``value_item`` → ``string`` to find
    the quoted literal text.  Returns ``None`` when no value is present.
    """
    for child in node.children:
        if child.type == "value_clause":
            for vc_child in child.children:
                if vc_child.type == "value_item":
                    for vi_child in vc_child.children:
                        if vi_child.type == "string":
                            return _node_text(vi_child)
            # Fallback: direct string child of value_clause
            for vc_child in child.children:
                if vc_child.type == "string":
                    return _node_text(vc_child)
    return None


def cobol_call_target(node: Node) -> Node | None:
    """Return the target child (field ``x``) of a ``call_statement`` node.

    The target is a ``string`` (literal program name) or
    ``qualified_word`` (variable program name).
    """
    target = node.child_by_field_name("x")
    if target is not None:
        return target
    # Fallback: first string or qualified_word child after the CALL keyword
    for child in node.children:
        if child.type in ("string", "qualified_word"):
            return child
    return None


def cobol_is_literal(node: Node) -> bool:
    """Return True if *node* is a string literal."""
    return node.type == "string"


def cobol_display_items(node: Node) -> list[Node]:
    """Return all displayable children of a ``display_statement`` node.

    Collects ``qualified_word`` and ``string`` children.
    """
    items: list[Node] = []
    for child in node.children:
        if child.type in ("qualified_word", "string"):
            items.append(child)
    return items


def cobol_has_overflow(node: Node) -> bool:
    """Return True if a string/unstring statement has ON OVERFLOW handling.

    The COBOL grammar places ``on_overflow`` as a sibling of the
    ``string_statement``/``unstring_statement`` node, not as a child.
    This checks both children (in case of grammar variations) and the
    immediately following siblings.
    """
    # Check children first
    for child in node.children:
        if child.type == "on_overflow":
            return True
    # Check following siblings in the parent
    parent = node.parent
    if parent is None:
        return False
    found_self = False
    for sibling in parent.children:
        if sibling == node:
            found_self = True
            continue
        if found_self:
            if sibling.type == "on_overflow":
                return True
            # Stop at the next statement or period
            is_boundary = sibling.type in ("period", ".", "stop_statement")
            if is_boundary or sibling.type.endswith("_statement"):
                break
    return False


def cobol_select_file_name(node: Node) -> str:
    """Extract the file name from a ``select_statement`` node."""
    fn = node.child_by_field_name("file_name")
    if fn is not None:
        return _node_text(fn).strip()
    return ""


def cobol_assign_target(node: Node) -> Node | None:
    """Return the ASSIGN TO target from a ``select_statement`` node.

    Looks for ``assign_clause`` → child with field ``to``.
    """
    for child in node.children:
        if child.type == "assign_clause":
            to_node = child.child_by_field_name("to")
            if to_node is not None:
                return to_node
            # Fallback: first meaningful child after ASSIGN keyword
            for ac_child in child.children:
                if ac_child.type in ("string", "qualified_word", "WORD"):
                    return ac_child
    return None


def cobol_has_file_status(node: Node) -> bool:
    """Return True if a ``select_statement`` has a ``file_status_clause``."""
    for child in node.children:
        if child.type == "file_status_clause":
            return True
    return False


def cobol_enclosing_paragraph(node: Node) -> str | None:
    """Walk up to find the enclosing paragraph name.

    Looks for a preceding ``paragraph_header`` sibling or parent.
    """
    current = node
    while current is not None:
        parent = current.parent
        if parent is None:
            break
        # Check preceding siblings for paragraph_header
        for child in parent.children:
            if child == current:
                break
            if child.type == "paragraph_header":
                # Extract paragraph name from the header
                for hc in child.children:
                    if hc.type in ("qualified_word", "WORD"):
                        return _node_text(hc).strip()
                text = _node_text(child).strip().rstrip(".")
                if text:
                    return text
        current = parent
    return None


def is_sensitive_name(name: str) -> bool:
    """Return True if *name* matches a sensitive credential pattern."""
    return bool(_SENSITIVE_NAME_RE.search(name))
