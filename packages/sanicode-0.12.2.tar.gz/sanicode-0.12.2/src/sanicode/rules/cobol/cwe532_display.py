"""DISPLAY of sensitive variable detection for COBOL (CWE-532).

SC2108 — DISPLAY of sensitive variable — information exposure    medium  CWE-532
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.cobol._helpers import (
    COBOL_DISPLAY_STATEMENT,
    _node_text,
    cobol_display_items,
    is_sensitive_name,
)
from sanicode.scanner.patterns import Finding


class COBOLDisplaySensitiveRule(Rule):
    """Detect DISPLAY of variables with sensitive names."""

    rule_id = "SC2108"
    cwe_id = 532
    severity = "medium"
    language = "cobol"
    message = "DISPLAY of sensitive variable — information exposure (CWE-532)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if node.type != COBOL_DISPLAY_STATEMENT:
                continue
            items = cobol_display_items(node)
            for item in items:
                if item.type != "qualified_word":
                    continue
                name = _node_text(item).strip()
                if is_sensitive_name(name):
                    findings.append(self._make_finding(node, plugin, file_path))
                    break  # One finding per DISPLAY statement
        return findings
