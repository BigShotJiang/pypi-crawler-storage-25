"""COBOL-specific pattern detection rules."""
