"""Hardcoded credentials detection for COBOL (CWE-798).

SC2104 — Hardcoded credentials in VALUE clause    medium  CWE-798
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.cobol._helpers import (
    COBOL_DATA_DESCRIPTION,
    cobol_entry_name,
    cobol_value_text,
    is_sensitive_name,
)
from sanicode.scanner.patterns import Finding


class COBOLHardcodedCredsRule(Rule):
    """Detect hardcoded credentials in COBOL VALUE clauses."""

    rule_id = "SC2104"
    cwe_id = 798
    severity = "medium"
    language = "cobol"
    message = "Hardcoded credential in VALUE clause (CWE-798)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if node.type != COBOL_DATA_DESCRIPTION:
                continue
            name = cobol_entry_name(node)
            if not name or not is_sensitive_name(name):
                continue
            value = cobol_value_text(node)
            if value is not None and value.strip().strip("'\""):
                findings.append(self._make_finding(node, plugin, file_path))
        return findings
