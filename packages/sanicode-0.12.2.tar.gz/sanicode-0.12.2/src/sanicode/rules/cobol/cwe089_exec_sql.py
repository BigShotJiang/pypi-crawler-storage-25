"""EXEC SQL dynamic query detection for COBOL (CWE-89).

SC2101 — EXEC SQL with EXECUTE IMMEDIATE — SQL injection risk    high  CWE-89
"""

from __future__ import annotations

import re
from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.scanner.patterns import Finding

_DYNAMIC_SQL_RE = re.compile(
    r"EXEC\s+SQL\s+.*EXECUTE\s+IMMEDIATE", re.IGNORECASE | re.DOTALL,
)


class COBOLExecSQLRule(Rule):
    """Detect EXEC SQL with EXECUTE IMMEDIATE — dynamic SQL injection risk."""

    rule_id = "SC2101"
    cwe_id = 89
    severity = "high"
    language = "cobol"
    message = "EXEC SQL EXECUTE IMMEDIATE — dynamic SQL injection risk (CWE-89)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in plugin.walk(tree.root_node):
            if not node.is_error:
                continue
            if node.text is None:
                continue
            text = node.text.decode("utf-8")
            if _DYNAMIC_SQL_RE.search(text):
                findings.append(self._make_finding(node, plugin, file_path))
        return findings
