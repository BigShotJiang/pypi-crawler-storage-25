"""ReDoS detection rules for Java (CWE-1333).

SC422 — Pattern.compile / String.matches/split/replaceAll with non-literal pattern  medium  CWE-1333
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.java._helpers import java_call_arguments, java_method_name
from sanicode.scanner.patterns import Finding

# Methods on String that accept a regex pattern as their first argument.
_STRING_REGEX_METHODS = frozenset({"matches", "replaceAll", "replaceFirst", "split"})


class JavaReDoSRule(Rule):
    """Detect Pattern.compile / String regex methods with non-literal pattern."""

    rule_id = "SC422"
    cwe_id = 1333
    severity = "medium"
    language = "java"
    message = (
        "Regex compiled with non-literal pattern — "
        "potential ReDoS risk (CWE-1333)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        captures = plugin.captures("(method_invocation) @call", tree.root_node)

        for call_node in captures.get("call", []):
            obj_name, method = java_method_name(call_node)

            # Pattern.compile(dynamic)
            if obj_name == "Pattern" and method == "compile":
                args = java_call_arguments(call_node)
                if args and args[0].type != "string_literal":
                    findings.append(self._make_finding(call_node, plugin, file_path))
                continue

            # String methods that take a regex as first arg
            if method in _STRING_REGEX_METHODS:
                args = java_call_arguments(call_node)
                if args and args[0].type != "string_literal":
                    findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
