"""Template/expression injection detection for Java (CWE-77).

SC420 — Script engine or template engine eval with non-literal argument.
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.java._helpers import java_call_arguments, java_method_name
from sanicode.scanner.patterns import Finding


class JavaExpressionInjectionRule(Rule):
    """Detect script/template engine eval with non-literal input — expression injection."""

    rule_id = "SC420"
    cwe_id = 77
    severity = "high"
    language = "java"
    message = (
        "Script/template engine eval with non-literal input — expression injection risk (CWE-77)"
    )

    _EVAL_METHODS = frozenset({"eval", "evaluate", "createTemplate", "process"})

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        captures = plugin.captures("(method_invocation) @call", tree.root_node)

        for call_node in captures.get("call", []):
            _, method = java_method_name(call_node)
            if method not in self._EVAL_METHODS:
                continue

            args = java_call_arguments(call_node)
            if not args:
                continue

            first = args[0]
            if first.type == "string_literal":
                continue

            findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
