"""Uncontrolled search path detection for Java (CWE-427).

SC455 — System.loadLibrary / Runtime.exec with search-path name    medium  CWE-427

Detects:
- ``System.loadLibrary("lib")`` — always relies on ``java.library.path``
  search; unlike ``System.load()``, there is no way to pass an absolute path.
- ``Runtime.getRuntime().exec("cmd")`` / ``ProcessBuilder("cmd")`` where
  the first argument is a string literal without an absolute path.
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.java._helpers import java_call_arguments, java_method_name
from sanicode.scanner.patterns import Finding


def _is_absolute_or_explicit_relative(text: str) -> bool:
    """Return True if *text* represents an absolute or explicitly relative path."""
    stripped = text.strip("'\"")
    return (
        stripped.startswith("/")
        or stripped.startswith("./")
        or stripped.startswith("../")
        or stripped.startswith("\\\\")
        or (len(stripped) >= 3 and stripped[1] == ":" and stripped[2] in ("/", "\\"))
    )


class JavaSearchPathRule(Rule):
    """Detect Java APIs that load code via an OS search path.

    ``System.loadLibrary`` always searches ``java.library.path``, making
    it vulnerable to library-path hijacking.  ``Runtime.exec`` and
    ``ProcessBuilder`` with a bare command name search ``PATH``.
    """

    rule_id = "SC455"
    cwe_id = 427
    severity = "medium"
    language = "java"
    message = (
        "Library or command loaded via search path \u2014 "
        "uncontrolled search path risk (CWE-427)"
    )

    # Methods that always use search-path resolution regardless of argument.
    _ALWAYS_FLAG = frozenset({"loadLibrary"})

    # Methods that are only flagged when the first argument is a bare literal.
    _PATH_SENSITIVE = frozenset({"exec"})

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        captures = plugin.captures("(method_invocation) @call", tree.root_node)

        for call_node in captures.get("call", []):
            obj_name, method = java_method_name(call_node)

            if method in self._ALWAYS_FLAG:
                # System.loadLibrary always uses java.library.path search.
                if "System" in obj_name or obj_name == "":
                    findings.append(self._make_finding(call_node, plugin, file_path))
                continue

            if method in self._PATH_SENSITIVE:
                # Runtime.exec / similar: flag when first arg is a bare string.
                args = java_call_arguments(call_node)
                if not args:
                    continue
                first = args[0]
                if first.type != "string_literal":
                    continue
                text = plugin.node_text(first)
                if not _is_absolute_or_explicit_relative(text):
                    findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
