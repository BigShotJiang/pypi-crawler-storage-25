"""IDOR detection for Java (CWE-639).

SC464 — User input flows directly into database lookup    medium  CWE-639
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.java._helpers import java_method_name
from sanicode.scanner.patterns import Finding

_DB_METHODS = frozenset({"findById", "getById", "getReferenceById", "findOne"})


class JavaIdorRule(Rule):
    """Detect JPA/Spring repository lookups with user-controlled request parameters."""

    rule_id = "SC464"
    cwe_id = 639
    severity = "medium"
    language = "java"
    tags = ["auth", "idor"]
    domain = "access_control"
    message = (
        "User input flows directly into database lookup — "
        "potential IDOR vulnerability (CWE-639)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(method_invocation) @call", tree.root_node)
        for call_node in call_captures.get("call", []):
            _, method = java_method_name(call_node)
            if method not in _DB_METHODS:
                continue

            args_node = call_node.child_by_field_name("arguments")
            if args_node is None:
                continue
            args_text = plugin.node_text(args_node)

            # Skip if the argument references the authenticated user
            if "currentUser" in args_text or "getCurrentUser" in args_text:
                continue

            if "getParameter" in args_text:
                findings.append(self._make_finding(call_node, plugin, file_path))
        return findings
