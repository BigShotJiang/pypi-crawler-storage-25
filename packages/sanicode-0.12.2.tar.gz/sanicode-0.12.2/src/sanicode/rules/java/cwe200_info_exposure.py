"""Information exposure detection for Java (CWE-200).

SC423 — printStackTrace() stack trace exposure   medium  CWE-200
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.java._helpers import java_method_name
from sanicode.scanner.patterns import Finding


class JavaInfoExposureRule(Rule):
    """Detect printStackTrace() — exposes stack trace to users."""

    rule_id = "SC423"
    cwe_id = 200
    severity = "medium"
    language = "java"
    message = "printStackTrace() exposes stack trace — information disclosure risk (CWE-200)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        captures = plugin.captures("(method_invocation) @call", tree.root_node)

        for call_node in captures.get("call", []):
            _, method = java_method_name(call_node)
            if method == "printStackTrace":
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
