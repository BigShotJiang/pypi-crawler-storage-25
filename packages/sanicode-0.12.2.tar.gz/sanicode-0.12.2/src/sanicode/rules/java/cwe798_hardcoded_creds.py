"""Hardcoded credential detection for Java (CWE-798).

SC411 — string literal assigned to a secret-named variable    high  CWE-798
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules._sensitive_patterns import (
    MIN_SECRET_LEN,
    SECRET_VAR_PATTERN,
    is_placeholder,
    strip_quotes,
)
from sanicode.rules.base import Rule, _walk
from sanicode.scanner.patterns import Finding


class JavaHardcodedCredentialRule(Rule):
    """Detect hardcoded credentials in Java variable declarations and assignments."""

    rule_id = "SC411"
    cwe_id = 798
    severity = "high"
    language = "java"
    message = "Hardcoded credential — secret value in variable (CWE-798)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []

        for node in _walk(tree.root_node):
            if node.type == "variable_declarator":
                result = self._check_declarator(node, plugin, file_path)
                if result is not None:
                    findings.append(result)
            elif node.type == "assignment_expression":
                result = self._check_assignment(node, plugin, file_path)
                if result is not None:
                    findings.append(result)

        return findings

    def _check_declarator(self, node, plugin, file_path: Path):
        """Handle: String name = "value";"""
        name_node = node.child_by_field_name("name")
        value_node = node.child_by_field_name("value")
        if name_node is None or value_node is None:
            return None

        if name_node.type != "identifier":
            return None

        var_name = plugin.node_text(name_node)
        if not SECRET_VAR_PATTERN.search(var_name):
            return None

        if value_node.type != "string_literal":
            return None

        inner = strip_quotes(plugin.node_text(value_node))
        if len(inner) < MIN_SECRET_LEN or is_placeholder(inner):
            return None

        return self._make_finding(node, plugin, file_path)

    def _check_assignment(self, node, plugin, file_path: Path):
        """Handle: name = "value"; (bare assignment)"""
        left = node.child_by_field_name("left")
        right = node.child_by_field_name("right")
        if left is None or right is None:
            return None

        if left.type != "identifier":
            return None

        var_name = plugin.node_text(left)
        if not SECRET_VAR_PATTERN.search(var_name):
            return None

        if right.type != "string_literal":
            return None

        inner = strip_quotes(plugin.node_text(right))
        if len(inner) < MIN_SECRET_LEN or is_placeholder(inner):
            return None

        return self._make_finding(node, plugin, file_path)
