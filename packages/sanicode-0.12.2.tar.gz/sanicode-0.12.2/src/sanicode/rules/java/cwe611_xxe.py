"""XXE detection rules for Java (CWE-611).

SC409 — XML parser factory/constructor without secure processing    high  CWE-611

Covers factory pattern (.newInstance()) for DocumentBuilderFactory,
SAXParserFactory, XMLInputFactory, TransformerFactory and constructor
pattern (new) for SAXReader, SAXBuilder.
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.java._helpers import java_method_name
from sanicode.scanner.patterns import Finding

_XXE_FACTORY_CLASSES = frozenset({
    "DocumentBuilderFactory",
    "SAXParserFactory",
    "XMLInputFactory",
    "TransformerFactory",
})

_XXE_CONSTRUCTOR_CLASSES = frozenset({
    "SAXReader",
    "SAXBuilder",
})


class JavaXXERule(Rule):
    """Detect XML parser factory/constructor usage without secure processing — XXE risk."""

    rule_id = "SC409"
    cwe_id = 611
    severity = "high"
    language = "java"
    message = (
        "Use of XML parser factory/constructor without secure processing — "
        "XXE vulnerability risk (CWE-611)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(method_invocation) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            obj_name, method_name = java_method_name(call_node)
            if method_name == "newInstance" and any(
                cls in obj_name for cls in _XXE_FACTORY_CLASSES
            ):
                findings.append(self._make_finding(call_node, plugin, file_path))

        new_captures = plugin.captures("(object_creation_expression) @new", tree.root_node)
        for new_node in new_captures.get("new", []):
            type_node = new_node.child_by_field_name("type")
            if type_node is None:
                continue
            type_name = type_node.text.decode("utf-8") if type_node.text else ""
            if type_name in _XXE_CONSTRUCTOR_CLASSES:
                findings.append(self._make_finding(new_node, plugin, file_path))

        return findings
