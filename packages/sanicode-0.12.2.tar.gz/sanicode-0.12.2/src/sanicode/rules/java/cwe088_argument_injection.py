"""Argument injection detection for Java (CWE-88).

SC433 — ProcessBuilder / Runtime.exec with literal command and variable args    medium  CWE-88
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.java._helpers import java_call_arguments, java_method_name
from sanicode.scanner.patterns import Finding

# String literal node types in Java tree-sitter grammar.
_STRING_TYPES = frozenset({"string_literal"})


def _is_string_literal(node) -> bool:
    """Return True if node is a Java string literal."""
    return node.type in _STRING_TYPES


def _check_arg_list(elements: list) -> bool:
    """Check if a list of argument nodes has literal-command + variable-args pattern.

    Returns True if the first element is a string literal and at least one
    subsequent element is not.
    """
    if len(elements) < 2:
        return False
    if not _is_string_literal(elements[0]):
        return False
    return any(not _is_string_literal(elem) for elem in elements[1:])


class JavaArgumentInjectionRule(Rule):
    """Detect ProcessBuilder/Runtime.exec with literal command and variable arguments."""

    rule_id = "SC433"
    cwe_id = 88
    severity = "medium"
    language = "java"
    message = (
        "ProcessBuilder/Runtime.exec with literal command and variable arguments "
        "— potential argument injection (CWE-88)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        # Pattern 1: new ProcessBuilder("cmd", variable, ...)
        new_captures = plugin.captures("(object_creation_expression) @new", root)
        for new_node in new_captures.get("new", []):
            type_node = new_node.child_by_field_name("type")
            if type_node is None:
                continue
            type_text = type_node.text.decode("utf-8") if type_node.text else ""
            if type_text != "ProcessBuilder":
                continue

            # Get constructor arguments
            args_node = new_node.child_by_field_name("arguments")
            if args_node is None:
                continue
            args = [
                child for child in args_node.children
                if child.type not in ("(", ")", ",")
            ]
            if _check_arg_list(args):
                findings.append(self._make_finding(new_node, plugin, file_path))

        # Pattern 2: processBuilder.command("cmd", variable, ...)
        call_captures = plugin.captures("(method_invocation) @call", root)
        for call_node in call_captures.get("call", []):
            obj_name, method_name = java_method_name(call_node)
            if method_name != "command":
                continue
            args = java_call_arguments(call_node)
            if _check_arg_list(args):
                findings.append(self._make_finding(call_node, plugin, file_path))

        # Pattern 3: Runtime.exec(new String[]{"cmd", variable})
        # Look for Runtime.exec() where the argument is an array with literal+variable
        for call_node in call_captures.get("call", []):
            obj_name, method_name = java_method_name(call_node)
            if method_name != "exec":
                continue
            if "Runtime" not in obj_name and "getRuntime" not in obj_name:
                continue
            args = java_call_arguments(call_node)
            if not args:
                continue
            first_arg = args[0]
            # Check for array creation: new String[]{"cmd", var}
            if first_arg.type == "array_creation_expression":
                init = first_arg.child_by_field_name("value")
                if init is not None and init.type == "array_initializer":
                    elements = [
                        child for child in init.children
                        if child.type not in ("{", "}", ",")
                    ]
                    if _check_arg_list(elements):
                        findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
