"""Auth/authz pattern detection rules for Java (SC424-SC428).

Detects missing security annotations, weak auth patterns, hardcoded role
checks, @PermitAll on admin endpoints, and overly broad permissions.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from tree_sitter import Node, Tree

from sanicode.rules.base import Rule
from sanicode.rules.java._helpers import java_call_arguments, java_method_name
from sanicode.scanner.patterns import Finding

if TYPE_CHECKING:
    from sanicode.scanner.languages.base import TreeSitterPlugin


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_CONTROLLER_ANNOTATIONS = frozenset(
    {"Controller", "RestController", "WebServlet"}
)

_HTTP_MAPPING_ANNOTATIONS = frozenset(
    {
        "RequestMapping",
        "GetMapping",
        "PostMapping",
        "PutMapping",
        "DeleteMapping",
        "PatchMapping",
    }
)

_SECURITY_ANNOTATIONS = frozenset(
    {
        "Secured",
        "PreAuthorize",
        "PostAuthorize",
        "RolesAllowed",
        "Authenticated",
        "DenyAll",
        # @PermitAll at class level means the developer has explicitly declared
        # the entire class as publicly accessible; individual methods should not
        # be flagged as missing auth.
        "PermitAll",
    }
)

# Public endpoints that intentionally have no auth requirement.
_PUBLIC_METHOD_NAMES = frozenset(
    {
        "login",
        "logout",
        "register",
        "signup",
        "health",
        "healthCheck",
        "readiness",
        "liveness",
        "index",
        "home",
        "public",
        "callback",
        "webhook",
        "error",
        "handleError",
    }
)

_PASSWORD_KEYWORDS = ("password", "passwd", "pwd")

_HARDCODED_ROLE_METHODS = frozenset(
    {"isUserInRole", "hasRole", "hasAuthority", "hasAnyRole", "hasAnyAuthority"}
)

_ROLE_ANNOTATIONS = frozenset({"Secured", "RolesAllowed", "PreAuthorize"})

_ADMIN_ROLE_PATTERNS = ("admin", "root", "superuser", "administrator")

_ADMIN_ENDPOINT_PATTERNS = (
    "admin",
    "manage",
    "settings",
    "config",
    "dashboard",
    "delete",
    "remove",
    "create",
    "modify",
    "update",
    "userlist",
)

_WILDCARD_ROLE_VALUES = frozenset({"*", "ALL", "ANY"})


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _node_text(node: Node) -> str:
    """Return the UTF-8 text of *node*, or empty string."""
    return node.text.decode("utf-8") if node.text else ""


def _annotation_name(ann_node: Node) -> str:
    """Extract the name from a marker_annotation or annotation node."""
    name_node = ann_node.child_by_field_name("name")
    return _node_text(name_node) if name_node else ""


def _get_annotation_names(modifiers_node: Node) -> list[str]:
    """Return all annotation names from a modifiers node."""
    return [
        _annotation_name(child)
        for child in modifiers_node.children
        if child.type in ("marker_annotation", "annotation")
    ]


def _get_annotations(modifiers_node: Node) -> list[Node]:
    """Return all annotation nodes from a modifiers node."""
    return [
        child
        for child in modifiers_node.children
        if child.type in ("marker_annotation", "annotation")
    ]


def _method_modifiers(method_node: Node) -> Node | None:
    """Find the modifiers child of a method_declaration node."""
    for child in method_node.children:
        if child.type == "modifiers":
            return child
    return None


def _annotation_string_args(ann_node: Node) -> list[str]:
    """Extract string literal values from annotation arguments.

    Handles @Secured("ROLE_ADMIN"), @RolesAllowed({"ROLE_ADMIN", "ROLE_USER"}),
    and @PreAuthorize("hasRole('ADMIN')").
    """
    values: list[str] = []
    # annotation nodes have an `arguments` child (annotation_argument_list)
    args_node = ann_node.child_by_field_name("arguments")
    if args_node is None:
        return values
    _collect_string_literals(args_node, values)
    return values


def _collect_string_literals(node: Node, result: list[str]) -> None:
    """Recursively collect unquoted string literal values under *node*."""
    if node.type == "string_literal":
        raw = _node_text(node)
        # Strip surrounding double-quotes
        if len(raw) >= 2 and raw[0] == '"' and raw[-1] == '"':
            result.append(raw[1:-1])
        else:
            result.append(raw)
        return
    for child in node.children:
        _collect_string_literals(child, result)


def _name_contains_password(name: str) -> bool:
    """Return True if *name* (lowercased) contains a password keyword."""
    lower = name.lower()
    return any(kw in lower for kw in _PASSWORD_KEYWORDS)


def _name_is_admin_like(name: str) -> bool:
    """Return True if *name* (lowercased) matches an admin-like pattern."""
    lower = name.lower()
    return any(pat in lower for pat in _ADMIN_ROLE_PATTERNS)


def _name_is_admin_endpoint(name: str) -> bool:
    """Return True if *name* (lowercased) matches an admin endpoint pattern."""
    lower = name.lower()
    return any(pat in lower for pat in _ADMIN_ENDPOINT_PATTERNS)


def _string_arg_is_admin_like(ann_node: Node) -> bool:
    """Return True if any string arg in an annotation is admin-like."""
    return any(_name_is_admin_like(v) for v in _annotation_string_args(ann_node))


def _string_arg_is_wildcard(ann_node: Node) -> bool:
    """Return True if any annotation arg matches a wildcard role value."""
    for val in _annotation_string_args(ann_node):
        if val in _wildcard_role_values_set():
            return True
        # Also catch hasRole('ADMIN') in PreAuthorize strings for wildcard
        if val in ("permitAll", "hasRole('*')", "hasAuthority('*')"):
            return True
    return False


def _wildcard_role_values_set() -> frozenset[str]:
    return _WILDCARD_ROLE_VALUES


def _call_arg_string_value(call_node: Node) -> list[str]:
    """Return string literal argument values from a method_invocation."""
    values: list[str] = []
    args = java_call_arguments(call_node)
    for arg in args:
        _collect_string_literals(arg, values)
    return values


def _identifier_name(node: Node) -> str:
    """Extract identifier text from an identifier or field_access/etc node."""
    if node.type == "identifier":
        return _node_text(node)
    # For more complex expressions, return raw text for substring checks
    return _node_text(node)


# ---------------------------------------------------------------------------
# SC424 — CWE-306: Controller method without security annotation
# ---------------------------------------------------------------------------


class JavaMissingAuthAnnotationRule(Rule):
    """Detect controller methods without a security annotation (CWE-306)."""

    rule_id = "SC424"
    cwe_id = 306
    severity = "medium"
    language = "java"
    message = (
        "Controller method without security annotation — "
        "missing authentication for critical function (CWE-306)"
    )
    tags = ["auth"]
    domain = "access_control"
    action = "review"

    def check(self, tree: Tree, file_path: Path, plugin: TreeSitterPlugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        class_captures = plugin.captures("(class_declaration) @cls", root)
        for class_node in class_captures.get("cls", []):
            # Check if class has a controller annotation.
            class_mods = _method_modifiers(class_node)
            if class_mods is None:
                continue
            class_ann_names = _get_annotation_names(class_mods)
            if not any(a in _CONTROLLER_ANNOTATIONS for a in class_ann_names):
                continue

            # If class itself has a security annotation, skip all methods.
            if any(a in _SECURITY_ANNOTATIONS for a in class_ann_names):
                continue

            # Check each method in the class body.
            body_node = class_node.child_by_field_name("body")
            if body_node is None:
                continue

            for child in body_node.children:
                if child.type != "method_declaration":
                    continue
                self._check_method(child, plugin, file_path, findings)

        return findings

    def _check_method(
        self,
        method_node: Node,
        plugin: TreeSitterPlugin,
        file_path: Path,
        findings: list[Finding],
    ) -> None:
        name_node = method_node.child_by_field_name("name")
        if name_node is None:
            return
        method_name = _node_text(name_node)

        # Skip known public endpoints.
        if method_name in _PUBLIC_METHOD_NAMES:
            return

        mods = _method_modifiers(method_node)
        if mods is None:
            return
        ann_names = _get_annotation_names(mods)

        # Must have an HTTP mapping annotation to be an endpoint.
        if not any(a in _HTTP_MAPPING_ANNOTATIONS for a in ann_names):
            return

        # Flag if missing a security annotation.
        if not any(a in _SECURITY_ANNOTATIONS for a in ann_names):
            findings.append(self._make_finding(method_node, plugin, file_path))


# ---------------------------------------------------------------------------
# SC425 — CWE-287: Plaintext password comparison
# ---------------------------------------------------------------------------


class JavaPlaintextPasswordRule(Rule):
    """Detect plaintext password comparison via String.equals() (CWE-287)."""

    rule_id = "SC425"
    cwe_id = 287
    severity = "medium"
    language = "java"
    message = "Plaintext password comparison — use BCrypt/SCrypt password hashing (CWE-287)"
    tags = ["auth"]
    domain = "access_control"
    action = "review"

    def check(self, tree: Tree, file_path: Path, plugin: TreeSitterPlugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        call_captures = plugin.captures("(method_invocation) @call", root)
        for call_node in call_captures.get("call", []):
            obj_name, method_name = java_method_name(call_node)
            if method_name != "equals":
                continue

            # Check if the receiver object name is password-like.
            if _name_contains_password(obj_name):
                findings.append(self._make_finding(call_node, plugin, file_path))
                continue

            # Check if any argument identifier name is password-like.
            args = java_call_arguments(call_node)
            for arg in args:
                arg_name = _identifier_name(arg)
                if _name_contains_password(arg_name):
                    findings.append(self._make_finding(call_node, plugin, file_path))
                    break

        return findings


# ---------------------------------------------------------------------------
# SC426 — CWE-269: Hardcoded role checks
# ---------------------------------------------------------------------------


class JavaHardcodedRoleRule(Rule):
    """Detect hardcoded admin/root role strings in security checks (CWE-269)."""

    rule_id = "SC426"
    cwe_id = 269
    severity = "medium"
    language = "java"
    message = "Hardcoded role string in authorization check — use configurable RBAC (CWE-269)"
    tags = ["auth"]
    domain = "access_control"
    action = "review"

    def check(self, tree: Tree, file_path: Path, plugin: TreeSitterPlugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        # Pattern 1: method calls like isUserInRole("admin"), hasRole("ROLE_ADMIN")
        call_captures = plugin.captures("(method_invocation) @call", root)
        for call_node in call_captures.get("call", []):
            _, method_name = java_method_name(call_node)
            if method_name not in _HARDCODED_ROLE_METHODS:
                continue
            string_args = _call_arg_string_value(call_node)
            if any(_name_is_admin_like(v) for v in string_args):
                findings.append(self._make_finding(call_node, plugin, file_path))

        # Pattern 2: security annotations with admin-like string arguments.
        # We need to walk the tree for annotation nodes.
        ann_captures = plugin.captures("(annotation) @ann", root)
        for ann_node in ann_captures.get("ann", []):
            ann_name = _annotation_name(ann_node)
            if ann_name not in _ROLE_ANNOTATIONS:
                continue
            if _string_arg_is_admin_like(ann_node):
                findings.append(self._make_finding(ann_node, plugin, file_path))

        return findings


# ---------------------------------------------------------------------------
# SC427 — CWE-862: @PermitAll on admin-like endpoints
# ---------------------------------------------------------------------------


class JavaPermitAllAdminRule(Rule):
    """Detect @PermitAll on admin-like endpoints (CWE-862)."""

    rule_id = "SC427"
    cwe_id = 862
    severity = "medium"
    language = "java"
    message = "Admin-like endpoint marked @PermitAll — missing authorization (CWE-862)"
    tags = ["auth"]
    domain = "access_control"
    action = "review"

    def check(self, tree: Tree, file_path: Path, plugin: TreeSitterPlugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        method_captures = plugin.captures("(method_declaration) @method", root)
        for method_node in method_captures.get("method", []):
            mods = _method_modifiers(method_node)
            if mods is None:
                continue
            ann_names = _get_annotation_names(mods)

            # Must have @PermitAll.
            if "PermitAll" not in ann_names:
                continue

            # Must also have an HTTP mapping annotation.
            if not any(a in _HTTP_MAPPING_ANNOTATIONS for a in ann_names):
                continue

            # Check method name.
            name_node = method_node.child_by_field_name("name")
            if name_node is None:
                continue
            method_name = _node_text(name_node)

            if _name_is_admin_endpoint(method_name):
                findings.append(self._make_finding(method_node, plugin, file_path))
                continue

            # Also check the path value in HTTP mapping annotations.
            anns = _get_annotations(mods)
            for ann in anns:
                if _annotation_name(ann) not in _HTTP_MAPPING_ANNOTATIONS:
                    continue
                path_values = _annotation_string_args(ann)
                if any(_name_is_admin_endpoint(v) for v in path_values):
                    findings.append(self._make_finding(method_node, plugin, file_path))
                    break

        return findings


# ---------------------------------------------------------------------------
# SC428 — CWE-863: Wildcard or overly broad permissions
# ---------------------------------------------------------------------------


class JavaWildcardPermissionRule(Rule):
    """Detect wildcard or overly broad security roles/permissions (CWE-863)."""

    rule_id = "SC428"
    cwe_id = 863
    severity = "low"
    language = "java"
    message = "Overly broad permission — use specific, least-privilege role names (CWE-863)"
    tags = ["auth"]
    domain = "access_control"
    action = "review"

    def check(self, tree: Tree, file_path: Path, plugin: TreeSitterPlugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        # Pattern 1: @Secured("*"), @RolesAllowed({"*"}), @PreAuthorize("permitAll")
        ann_captures = plugin.captures("(annotation) @ann", root)
        for ann_node in ann_captures.get("ann", []):
            ann_name = _annotation_name(ann_node)
            if ann_name not in _ROLE_ANNOTATIONS:
                continue
            if _string_arg_is_wildcard(ann_node):
                findings.append(self._make_finding(ann_node, plugin, file_path))

        # Pattern 2: marker_annotation @PreAuthorize / @Secured — won't have args,
        # but @RolesAllowed with no args is not a real Java construct, so skip.

        # Pattern 3: method calls hasRole("*"), hasAuthority("ALL")
        call_captures = plugin.captures("(method_invocation) @call", root)
        for call_node in call_captures.get("call", []):
            _, method_name = java_method_name(call_node)
            if method_name not in ("hasRole", "hasAuthority"):
                continue
            string_args = _call_arg_string_value(call_node)
            if any(v in _WILDCARD_ROLE_VALUES for v in string_args):
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
