"""Full object serialization without field filtering for Java (CWE-213).

SC462 — Full object dump without field filtering    medium  CWE-213
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.java._helpers import java_method_name
from sanicode.scanner.patterns import Finding

_JACKSON_METHODS: frozenset[str] = frozenset(
    {"writeValueAsString", "writeValueAsBytes", "writeValue"}
)
_JACKSON_RECEIVERS: frozenset[str] = frozenset(
    {"objectMapper", "mapper", "ObjectMapper"}
)


class JavaObjectDumpRule(Rule):
    """Detect full object serialization via Jackson or BeanUtils without field filtering."""

    rule_id = "SC462"
    cwe_id = 213
    severity = "medium"
    language = "java"
    tags = ["info_disclosure"]
    domain = "data_protection"
    message = (
        "Full object serialization without field filtering "
        "— may expose internal state (CWE-213)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        captures = plugin.captures("(method_invocation) @call", tree.root_node)
        for call_node in captures.get("call", []):
            obj_name, method = java_method_name(call_node)
            # Pattern 1: Jackson writeValueAsString/writeValueAsBytes/writeValue
            if method in _JACKSON_METHODS and obj_name in _JACKSON_RECEIVERS:
                findings.append(self._make_finding(call_node, plugin, file_path))
                continue
            # Pattern 2: BeanUtils.describe(obj)
            if obj_name == "BeanUtils" and method == "describe":
                findings.append(self._make_finding(call_node, plugin, file_path))
        return findings
