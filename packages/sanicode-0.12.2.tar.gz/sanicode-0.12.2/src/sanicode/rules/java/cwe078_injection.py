"""Command injection detection rules for Java (CWE-78).

SC401 — Runtime.exec() / Runtime.getRuntime().exec()    high  CWE-78
SC402 — ProcessBuilder constructor / .start()            high  CWE-78
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.java._helpers import java_method_name
from sanicode.scanner.patterns import Finding


class JavaRuntimeExecRule(Rule):
    """Detect Runtime.exec() calls — command injection risk."""

    rule_id = "SC401"
    cwe_id = 78
    severity = "high"
    language = "java"
    message = "Use of Runtime.exec() — command injection risk (CWE-78)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(method_invocation) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            obj_name, method_name = java_method_name(call_node)
            if method_name != "exec":
                continue
            # Match Runtime.exec() or getRuntime().exec()
            if "Runtime" in obj_name or "getRuntime" in obj_name:
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings


class JavaProcessBuilderRule(Rule):
    """Detect ProcessBuilder constructor and .start() — command injection risk."""

    rule_id = "SC402"
    cwe_id = 78
    severity = "high"
    language = "java"
    message = "Use of ProcessBuilder — command injection risk (CWE-78)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []

        # Pattern 1: processBuilder.start()
        call_captures = plugin.captures("(method_invocation) @call", tree.root_node)
        for call_node in call_captures.get("call", []):
            obj_name, method_name = java_method_name(call_node)
            if method_name == "start" and "ProcessBuilder" in obj_name:
                findings.append(self._make_finding(call_node, plugin, file_path))

        # Pattern 2: new ProcessBuilder(...)
        new_captures = plugin.captures("(object_creation_expression) @new", tree.root_node)
        for new_node in new_captures.get("new", []):
            type_node = new_node.child_by_field_name("type")
            if type_node is None:
                continue
            type_text = type_node.text.decode("utf-8") if type_node.text else ""
            if type_text == "ProcessBuilder":
                findings.append(self._make_finding(new_node, plugin, file_path))

        return findings
