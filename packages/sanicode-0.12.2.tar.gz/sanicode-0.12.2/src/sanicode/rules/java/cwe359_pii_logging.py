"""PII exposure in log output for Java (CWE-359).

SC458 — Logging call includes PII-named variable    medium  CWE-359
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules._sensitive_patterns import PII_VAR_PATTERN
from sanicode.rules.base import Rule, _walk
from sanicode.rules.java._helpers import java_method_name
from sanicode.scanner.patterns import Finding

_LOG_METHODS: frozenset[str] = frozenset(
    {"info", "debug", "warn", "error", "trace", "log"}
)
_LOG_RECEIVERS: frozenset[str] = frozenset(
    {"logger", "Logger", "log", "LOG"}
)
_SYSOUT_METHODS: frozenset[str] = frozenset(
    {"println", "print"}
)
_SYSOUT_RECEIVERS: frozenset[str] = frozenset(
    {"System.out", "System.err"}
)


class JavaPiiLoggingRule(Rule):
    """Detect logging calls that include PII-named variable arguments."""

    rule_id = "SC458"
    cwe_id = 359
    severity = "medium"
    language = "java"
    message = (
        "Logging call includes PII-named variable "
        "— may expose personal information in logs (CWE-359)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        captures = plugin.captures("(method_invocation) @call", tree.root_node)
        for call_node in captures.get("call", []):
            obj_name, method = java_method_name(call_node)
            matched = False
            if method in _LOG_METHODS and obj_name in _LOG_RECEIVERS:
                matched = True
            elif method in _SYSOUT_METHODS and obj_name in _SYSOUT_RECEIVERS:
                matched = True
            if not matched:
                continue
            if self._has_pii_arg(call_node, plugin):
                findings.append(self._make_finding(call_node, plugin, file_path))
        return findings

    @staticmethod
    def _has_pii_arg(call_node, plugin) -> bool:
        args_node = call_node.child_by_field_name("arguments")
        if args_node is None:
            return False
        for child in _walk(args_node):
            if child.type == "identifier":
                name = plugin.node_text(child)
                if PII_VAR_PATTERN.search(name):
                    return True
        return False
