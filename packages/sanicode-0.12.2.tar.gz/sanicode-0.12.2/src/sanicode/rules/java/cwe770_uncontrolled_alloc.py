"""CWE-770 uncontrolled resource allocation for Java.

SC446 — array/buffer allocation with non-literal size    medium  CWE-770
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.java._helpers import java_call_arguments, java_method_name
from sanicode.scanner.patterns import Finding

_LITERAL_TYPES = frozenset({
    "decimal_integer_literal",
    "hex_integer_literal",
    "octal_integer_literal",
    "binary_integer_literal",
    "decimal_floating_point_literal",
})

_ALLOC_TARGETS = frozenset({
    "ByteBuffer",
    "CharBuffer",
    "IntBuffer",
    "ShortBuffer",
    "LongBuffer",
    "FloatBuffer",
    "DoubleBuffer",
})

_ALLOC_METHODS = frozenset({"allocate", "allocateDirect"})


class JavaUncontrolledAllocRule(Rule):
    """Flag array/buffer creation with dynamic (non-literal) sizes."""

    rule_id = "SC446"
    cwe_id = 770
    severity = "medium"
    language = "java"
    message = (
        "Array or buffer allocated with a non-literal size — "
        "an attacker-controlled value can cause excessive memory allocation (CWE-770)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []

        # Detect: new byte[var], new int[var], etc.
        # In the tree-sitter Java grammar, `dimensions_expr` is a direct child of
        # `array_creation_expression` — there is no "dimensions" named field for the
        # size expression (only for extra empty bracket pairs like `new int[n][]`).
        for node in plugin.captures(
            "(array_creation_expression) @n", tree.root_node
        ).get("n", []):
            for child in node.children:
                if child.type != "dimensions_expr":
                    continue
                for inner in child.children:
                    if inner.type in ("[", "]"):
                        continue
                    if inner.type not in _LITERAL_TYPES:
                        findings.append(self._make_finding(node, plugin, file_path))
                        break

        # Detect: ByteBuffer.allocate(var), ByteBuffer.allocateDirect(var), etc.
        for node in plugin.captures(
            "(method_invocation) @call", tree.root_node
        ).get("call", []):
            obj, method = java_method_name(node)
            # obj may be a fully-qualified name like "java.nio.ByteBuffer" — check suffix
            obj_simple = obj.rsplit(".", 1)[-1] if "." in obj else obj
            if obj_simple in _ALLOC_TARGETS and method in _ALLOC_METHODS:
                args = java_call_arguments(node)
                if args and args[0].type not in _LITERAL_TYPES:
                    findings.append(self._make_finding(node, plugin, file_path))

        return findings
