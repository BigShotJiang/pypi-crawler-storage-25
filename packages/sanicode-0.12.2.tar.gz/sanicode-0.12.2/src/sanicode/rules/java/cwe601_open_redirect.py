"""Open redirect detection rules for Java (CWE-601).

SC430 -- Redirect call with potentially unvalidated URL    medium  CWE-601
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.java._helpers import java_method_name
from sanicode.scanner.patterns import Finding


class JavaOpenRedirectRule(Rule):
    """Detect redirect calls that may use unvalidated URLs.

    Flags ``response.sendRedirect()`` where the URL argument could be
    attacker-controlled, enabling open redirect attacks.
    """

    rule_id = "SC430"
    cwe_id = 601
    severity = "medium"
    language = "java"
    message = (
        "Redirect call \u2014 verify URL is validated against "
        "an allowlist (CWE-601)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures(
            "(method_invocation) @call", tree.root_node
        )

        for call_node in call_captures.get("call", []):
            _obj, method = java_method_name(call_node)
            if method == "sendRedirect":
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
