"""Shared helpers for Java rule modules.

These mirror the private helpers in ``scanner/languages/java.py`` but
are kept here so rule modules don't need to reach into scanner internals.
"""

from __future__ import annotations

from tree_sitter import Node


def java_dotted_name(node: Node) -> str:
    """Build a dotted name from a Java tree-sitter node.

    Handles ``identifier`` (base case), ``type_identifier``, ``scoped_identifier``
    (for package-qualified names like ``java.lang.Runtime``), and ``field_access``
    (for instance-field patterns like ``System.out``).
    """
    if node.type in ("identifier", "type_identifier"):
        return node.text.decode("utf-8") if node.text else ""
    if node.type == "scoped_identifier":
        scope = node.child_by_field_name("scope")
        name = node.child_by_field_name("name")
        if scope is None or name is None:
            return ""
        prefix = java_dotted_name(scope)
        suffix = name.text.decode("utf-8") if name.text else ""
        return f"{prefix}.{suffix}" if prefix else suffix
    if node.type == "field_access":
        obj = node.child_by_field_name("object")
        field = node.child_by_field_name("field")
        if obj is None or field is None:
            return ""
        prefix = java_dotted_name(obj)
        suffix = field.text.decode("utf-8") if field.text else ""
        return f"{prefix}.{suffix}" if prefix else suffix
    if node.type == "method_invocation":
        # For chained calls like Runtime.getRuntime(), return the raw text
        # so callers can match substrings (e.g. "Runtime" in obj_name).
        return node.text.decode("utf-8") if node.text else ""
    return ""


def java_method_name(call_node: Node) -> tuple[str, str]:
    """Extract ``(object_name, method_name)`` from a ``method_invocation`` node.

    Returns ``("", method_name)`` for bare (unqualified) method calls.
    """
    obj_node = call_node.child_by_field_name("object")
    name_node = call_node.child_by_field_name("name")
    object_name = java_dotted_name(obj_node) if obj_node is not None else ""
    if name_node is not None and name_node.text:
        method_name = name_node.text.decode("utf-8")
    else:
        method_name = ""
    return (object_name, method_name)


def java_call_arguments(call_node: Node) -> list[Node]:
    """Return positional argument nodes from a ``method_invocation`` node."""
    args_node = call_node.child_by_field_name("arguments")
    if args_node is None:
        return []
    results: list[Node] = []
    for child in args_node.children:
        if child.type in ("(", ")", ","):
            continue
        results.append(child)
    return results


def java_is_string_concat(node: Node) -> bool:
    """Check if a node involves string concatenation.

    Returns ``True`` for a ``binary_expression`` whose operator child is ``+``,
    or when the node is a ``method_invocation`` of ``String.format`` /
    ``String.formatted`` (which concatenates via substitution and is
    similarly dangerous when passed to sinks).
    """
    if node.type == "binary_expression":
        for child in node.children:
            if child.type == "+" or (child.text and child.text == b"+"):
                return True
        return False
    if node.type == "method_invocation":
        obj, method = java_method_name(node)
        if obj == "String" and method in ("format", "formatted"):
            return True
    return False
