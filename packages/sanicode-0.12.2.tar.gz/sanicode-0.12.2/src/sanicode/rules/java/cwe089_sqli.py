"""SQL injection detection rules for Java (CWE-89).

SC403 — SQL query with string concatenation    high  CWE-89
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.java._helpers import (
    java_call_arguments,
    java_is_string_concat,
    java_method_name,
)
from sanicode.scanner.patterns import Finding

_SQL_METHODS = frozenset({
    "executeQuery", "executeUpdate", "execute",
    # Spring JdbcTemplate
    "query", "queryForObject", "queryForList", "queryForMap", "update",
})


class JavaSQLInjectionRule(Rule):
    """Detect SQL queries with string concatenation — SQL injection risk."""

    rule_id = "SC403"
    cwe_id = 89
    severity = "high"
    language = "java"
    message = "SQL query with string concatenation — SQL injection risk (CWE-89)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(method_invocation) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            obj_name, method_name = java_method_name(call_node)
            if method_name not in _SQL_METHODS:
                continue

            # Skip prepared statement calls — they use parameterized queries
            if "PreparedStatement" in obj_name or "prepared" in obj_name.lower():
                continue

            args = java_call_arguments(call_node)
            if args and java_is_string_concat(args[0]):
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
