"""Trust boundary violation for Java (CWE-501).

SC466 — Request data stored in session without validation    medium  CWE-501
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.java._helpers import java_call_arguments, java_method_name
from sanicode.scanner.patterns import Finding

_MESSAGE = (
    "Request data stored in session without validation "
    "\u2014 trust boundary violation (CWE-501)"
)

# Direct request accessor method names on the ``request`` object.
_REQUEST_ACCESSOR_METHODS = frozenset({
    "getParameter",
    "getHeader",
    "getCookies",
})


def _is_direct_request_accessor(node, plugin) -> bool:
    """Return True if *node* is a direct call like ``request.getParameter(...)``.

    We check that:
    1. The node type is ``method_invocation``.
    2. The object part of the call starts with ``request``.
    3. The method name is one of the known request accessor methods.

    A wrapped call like ``validate(request.getParameter("x"))`` will present
    as a ``method_invocation`` where the object is the outer call, not
    ``request``, so it returns False.
    """
    if node.type != "method_invocation":
        return False
    obj_node = node.child_by_field_name("object")
    name_node = node.child_by_field_name("name")
    if obj_node is None or name_node is None:
        return False
    obj_text = plugin.node_text(obj_node)
    method = name_node.text.decode("utf-8") if name_node.text else ""
    return obj_text.startswith("request") and method in _REQUEST_ACCESSOR_METHODS


class JavaTrustBoundaryRule(Rule):
    """Detect request data stored in session without validation (CWE-501).

    Flags ``session.setAttribute("k", request.getParameter("k"))`` where the
    second argument is a direct request accessor rather than a validated value.
    """

    rule_id = "SC466"
    cwe_id = 501
    severity = "medium"
    language = "java"
    message = _MESSAGE
    tags = ["input_validation", "session"]
    domain = "web"
    action = "review"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(method_invocation) @call", tree.root_node)
        for call_node in call_captures.get("call", []):
            obj_name, method = java_method_name(call_node)
            if method != "setAttribute":
                continue
            if "session" not in obj_name.lower():
                continue
            args = java_call_arguments(call_node)
            if len(args) < 2:
                continue
            if _is_direct_request_accessor(args[1], plugin):
                findings.append(self._make_finding(call_node, plugin, file_path))
        return findings
