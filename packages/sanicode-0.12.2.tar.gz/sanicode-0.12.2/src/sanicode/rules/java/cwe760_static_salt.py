"""Static salt detection for Java (CWE-760).

SC473 — Hardcoded salt in PBEKeySpec / SecretKeySpec    high  CWE-760
"""
from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule, _walk
from sanicode.rules.java._helpers import java_call_arguments
from sanicode.scanner.patterns import Finding

# Constructor types where a literal salt/key argument is dangerous.
_TARGET_CONSTRUCTORS = frozenset({"PBEKeySpec", "SecretKeySpec"})


def _is_java_literal(node) -> bool:
    """Return True if the node is a string literal or a .getBytes() call on one."""
    if node.type == "string_literal":
        return True
    # "salt".getBytes()
    if node.type == "method_invocation":
        obj = node.child_by_field_name("object")
        name = node.child_by_field_name("name")
        if (obj and obj.type == "string_literal"
                and name and name.text and name.text.decode("utf-8") == "getBytes"):
            return True
    # new byte[]{0x01, 0x02, ...}  — array_creation_expression
    if node.type == "array_creation_expression":
        return True
    return False


class JavaStaticSaltRule(Rule):
    """Detect hardcoded salt/key bytes in PBEKeySpec and SecretKeySpec constructors.

    Flags:
    - ``new PBEKeySpec(password, "salt".getBytes(), ...)`` with literal salt
    - ``new SecretKeySpec(fixedBytes, ...)`` with inline byte array
    """

    rule_id = "SC473"
    cwe_id = 760
    severity = "high"
    language = "java"
    message = "Hardcoded salt/key bytes — salt must be random per-password (CWE-760)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []

        for node in _walk(tree.root_node):
            if node.type != "object_creation_expression":
                continue

            type_node = node.child_by_field_name("type")
            if type_node is None:
                continue
            type_name = type_node.text.decode("utf-8") if type_node.text else ""

            if type_name not in _TARGET_CONSTRUCTORS:
                continue

            args = java_call_arguments(node)
            if not args:
                continue

            # PBEKeySpec: second arg is salt
            if type_name == "PBEKeySpec" and len(args) >= 2:
                if _is_java_literal(args[1]):
                    findings.append(self._make_finding(node, plugin, file_path))

            # SecretKeySpec: first arg is key bytes
            if type_name == "SecretKeySpec" and len(args) >= 1:
                if _is_java_literal(args[0]):
                    findings.append(self._make_finding(node, plugin, file_path))

        return findings
