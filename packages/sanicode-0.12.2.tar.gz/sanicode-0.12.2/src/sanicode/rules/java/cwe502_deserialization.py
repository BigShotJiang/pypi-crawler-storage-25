"""Insecure deserialization detection rules for Java (CWE-502).

SC405 — ObjectInputStream.readObject()     high  CWE-502
SC408 — XMLDecoder / XStream fromXML()     high  CWE-502
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.java._helpers import java_method_name
from sanicode.scanner.patterns import Finding


class JavaReadObjectRule(Rule):
    """Detect ObjectInputStream.readObject() — insecure deserialization risk."""

    rule_id = "SC405"
    cwe_id = 502
    severity = "high"
    language = "java"
    message = "Use of ObjectInputStream.readObject() — insecure deserialization risk (CWE-502)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(method_invocation) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            _, method_name = java_method_name(call_node)
            if method_name == "readObject":
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings


class JavaXMLDeserializationRule(Rule):
    """Detect XStream.fromXML() and new XMLDecoder() — insecure XML deserialization."""

    rule_id = "SC408"
    cwe_id = 502
    severity = "high"
    language = "java"
    message = (
        "Use of XML deserialization (XStream/XMLDecoder) — "
        "insecure deserialization risk (CWE-502)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []

        # Pattern 1: xstream.fromXML(...)
        call_captures = plugin.captures("(method_invocation) @call", tree.root_node)
        for call_node in call_captures.get("call", []):
            _, method_name = java_method_name(call_node)
            if method_name == "fromXML":
                findings.append(self._make_finding(call_node, plugin, file_path))

        # Pattern 2: new XMLDecoder(...)
        new_captures = plugin.captures("(object_creation_expression) @new", tree.root_node)
        for new_node in new_captures.get("new", []):
            type_node = new_node.child_by_field_name("type")
            if type_node is None:
                continue
            type_text = type_node.text.decode("utf-8") if type_node.text else ""
            if type_text == "XMLDecoder":
                findings.append(self._make_finding(new_node, plugin, file_path))

        return findings
