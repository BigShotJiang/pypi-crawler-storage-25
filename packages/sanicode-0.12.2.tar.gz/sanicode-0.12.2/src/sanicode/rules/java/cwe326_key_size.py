"""Weak key size detection rules for Java (CWE-326).

SC448 — KeyPairGenerator.initialize(N<2048)    high  CWE-326
"""
from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.java._helpers import java_call_arguments, java_method_name
from sanicode.scanner.patterns import Finding


def _int_value(node) -> int | None:
    """Extract integer from a Java integer literal node."""
    if node.type == "decimal_integer_literal":
        text = node.text.decode("utf-8") if node.text else ""
        try:
            return int(text)
        except ValueError:
            return None
    return None


class JavaWeakKeyRule(Rule):
    """Detect KeyPairGenerator.initialize() with insufficient key sizes.

    Only flags ``initialize()`` (specific to ``KeyPairGenerator``) — the generic
    ``init()`` method is shared across too many unrelated classes to flag reliably
    from AST alone.
    """

    rule_id = "SC448"
    cwe_id = 326
    severity = "high"
    language = "java"
    message = "Weak key size — RSA/DSA keys must be at least 2048 bits (CWE-326)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(method_invocation) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            _, method = java_method_name(call_node)

            # KeyPairGenerator.initialize(bits) — specific enough to flag
            if method != "initialize":
                continue

            args = java_call_arguments(call_node)
            if args:
                val = _int_value(args[0])
                if val is not None and val < 2048:
                    findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
