"""Java-specific pattern detection rules."""
