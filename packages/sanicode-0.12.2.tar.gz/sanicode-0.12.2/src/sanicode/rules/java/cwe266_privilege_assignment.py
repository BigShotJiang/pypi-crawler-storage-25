"""Direct admin privilege assignment in Java (CWE-266).

SC459 — setRole/addRole/grantRole called with admin-like string  medium  CWE-266
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from tree_sitter import Node, Tree

from sanicode.rules.base import Rule
from sanicode.rules.java._helpers import java_call_arguments, java_method_name
from sanicode.scanner.patterns import Finding

if TYPE_CHECKING:
    from sanicode.scanner.languages.base import TreeSitterPlugin

# Method names that assign a role/privilege to an object.
_PRIVILEGE_METHODS: frozenset[str] = frozenset(
    {"setRole", "addRole", "grantRole", "setAuthority", "addAuthority"}
)

# Admin-like substrings (lower-cased) to check against string arguments.
_ADMIN_PATTERNS: tuple[str, ...] = ("admin", "root", "superuser", "administrator")


def _node_text(node: Node) -> str:
    return node.text.decode("utf-8") if node.text else ""


def _collect_string_literals(node: Node, result: list[str]) -> None:
    """Recursively collect unquoted string literal values under *node*."""
    if node.type == "string_literal":
        raw = _node_text(node)
        # tree-sitter wraps Java string literals in double-quotes.
        if len(raw) >= 2 and raw[0] == '"' and raw[-1] == '"':
            result.append(raw[1:-1])
        else:
            result.append(raw)
        return
    for child in node.children:
        _collect_string_literals(child, result)


def _is_admin_like(value: str) -> bool:
    lower = value.lower()
    return any(pat in lower for pat in _ADMIN_PATTERNS)


class JavaPrivilegeAssignmentRule(Rule):
    """Detect setRole/addRole/grantRole calls with admin-like strings (CWE-266)."""

    rule_id = "SC459"
    cwe_id = 266
    severity = "medium"
    language = "java"
    message = (
        "Direct admin privilege assignment via role setter "
        "— review for least privilege (CWE-266)"
    )
    tags = ["auth"]
    domain = "access_control"
    action = "review"

    def check(self, tree: Tree, file_path: Path, plugin: TreeSitterPlugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        call_captures = plugin.captures("(method_invocation) @call", root)
        for call_node in call_captures.get("call", []):
            _, method_name = java_method_name(call_node)
            if method_name not in _PRIVILEGE_METHODS:
                continue

            # Collect all string literal arguments.
            string_values: list[str] = []
            for arg in java_call_arguments(call_node):
                _collect_string_literals(arg, string_values)

            if any(_is_admin_like(v) for v in string_values):
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
