"""TLS certificate verification bypass detection for Java (CWE-295).

SC474 — X509TrustManager with empty check methods or always-true HostnameVerifier    high  CWE-295
"""
from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule, _walk
from sanicode.scanner.patterns import Finding

# Interface names that indicate trust/hostname bypass when implemented naively.
_DANGEROUS_INTERFACES = frozenset({"X509TrustManager", "HostnameVerifier"})


def _has_empty_body(method_node) -> bool:
    """Check if a method has an empty body (only whitespace / no statements)."""
    body = method_node.child_by_field_name("body")
    if body is None:
        return False
    # A block with no named children (just braces) is empty
    return len(body.named_children) == 0


def _returns_true_only(method_node) -> bool:
    """Check if a method body is just ``{ return true; }``."""
    body = method_node.child_by_field_name("body")
    if body is None:
        return False
    stmts = body.named_children
    if len(stmts) != 1:
        return False
    stmt = stmts[0]
    if stmt.type != "return_statement":
        return False
    text = stmt.text.decode("utf-8") if stmt.text else ""
    return "true" in text


class JavaTLSBypassRule(Rule):
    """Detect X509TrustManager/HostnameVerifier bypass patterns in Java.

    Flags:
    - Classes implementing ``X509TrustManager`` where ``checkServerTrusted``
      or ``checkClientTrusted`` has an empty body (no-op trust check)
    - Classes implementing ``HostnameVerifier`` where ``verify`` returns ``true``
    """

    rule_id = "SC474"
    cwe_id = 295
    severity = "high"
    language = "java"
    message = (
        "TLS certificate verification bypassed"
        " — trust manager or hostname verifier disabled (CWE-295)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []

        for node in _walk(tree.root_node):
            if node.type != "class_declaration":
                continue

            # Check if class implements a dangerous interface
            interfaces_node = node.child_by_field_name("interfaces")
            if interfaces_node is None:
                continue
            iface_text = interfaces_node.text.decode("utf-8") if interfaces_node.text else ""
            if not any(iface in iface_text for iface in _DANGEROUS_INTERFACES):
                continue

            is_trust_manager = "X509TrustManager" in iface_text
            is_hostname_verifier = "HostnameVerifier" in iface_text

            # Walk methods in this class
            for child in _walk(node):
                if child.type != "method_declaration":
                    continue
                method_name_node = child.child_by_field_name("name")
                if method_name_node is None:
                    continue
                method_name = method_name_node.text.decode("utf-8") if method_name_node.text else ""

                # Empty checkServerTrusted / checkClientTrusted
                if is_trust_manager and method_name in ("checkServerTrusted", "checkClientTrusted"):
                    if _has_empty_body(child):
                        findings.append(self._make_finding(child, plugin, file_path))

                # HostnameVerifier.verify returns true
                if is_hostname_verifier and method_name == "verify":
                    if _returns_true_only(child):
                        findings.append(self._make_finding(child, plugin, file_path))

        return findings
