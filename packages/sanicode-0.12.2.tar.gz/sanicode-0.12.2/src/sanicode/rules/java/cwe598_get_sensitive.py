"""Sensitive data in GET query string parameters for Java (CWE-598).

SC463 — Sensitive parameter read from GET query string    medium  CWE-598
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules._sensitive_patterns import SECRET_VAR_PATTERN, strip_quotes
from sanicode.rules.base import Rule
from sanicode.rules.java._helpers import java_call_arguments, java_method_name
from sanicode.scanner.patterns import Finding

_MESSAGE = (
    "Sensitive parameter read from GET query string "
    "— credentials should not travel in URLs (CWE-598)"
)


class JavaGetSensitiveRule(Rule):
    """Detect reading sensitive-named parameters via HttpServletRequest.getParameter."""

    rule_id = "SC463"
    cwe_id = 598
    severity = "medium"
    language = "java"
    message = _MESSAGE
    tags = ["info_disclosure"]
    domain = "data_protection"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        captures = plugin.captures("(method_invocation) @call", tree.root_node)
        for call_node in captures.get("call", []):
            _, method = java_method_name(call_node)
            if method != "getParameter":
                continue
            args = java_call_arguments(call_node)
            if not args:
                continue
            key_text = strip_quotes(plugin.node_text(args[0]))
            if SECRET_VAR_PATTERN.search(key_text):
                findings.append(self._make_finding(call_node, plugin, file_path))
        return findings
