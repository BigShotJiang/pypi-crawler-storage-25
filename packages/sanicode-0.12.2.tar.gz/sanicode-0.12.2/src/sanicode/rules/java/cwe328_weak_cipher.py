"""Weak hash/cipher detection rules for Java (CWE-328).

SC449 — MessageDigest.getInstance("MD2"/"MD4"), Cipher.getInstance("DES"/...)    medium  CWE-328
"""
from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.java._helpers import java_call_arguments, java_method_name
from sanicode.scanner.patterns import Finding

_WEAK_DIGEST_ALGOS = frozenset({"MD2", "MD4"})
_WEAK_CIPHER_PREFIXES = frozenset({"DES", "RC4", "RC2", "DESEDE"})


def _strip_java_quotes(s: str) -> str:
    if s.startswith('"') and s.endswith('"') and len(s) >= 2:
        return s[1:-1]
    return s


class JavaWeakCipherRule(Rule):
    """Detect MD2/MD4 hashes and DES/RC4/RC2/TripleDES cipher usage."""

    rule_id = "SC449"
    cwe_id = 328
    severity = "medium"
    language = "java"
    message = "Use of weak hash/cipher (MD2/MD4/DES/RC4/RC2/3DES) — use AES or SHA-256+ (CWE-328)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(method_invocation) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            obj_name, method_name = java_method_name(call_node)

            if method_name != "getInstance":
                continue

            args = java_call_arguments(call_node)
            if not args:
                continue
            first = args[0]
            if first.type != "string_literal":
                continue

            algo_str = _strip_java_quotes(plugin.node_text(first))

            # MessageDigest.getInstance("MD2")
            if obj_name == "MessageDigest":
                if algo_str.upper() in _WEAK_DIGEST_ALGOS:
                    findings.append(self._make_finding(call_node, plugin, file_path))
                continue

            # Cipher.getInstance("DES/CBC/PKCS5Padding")
            if obj_name == "Cipher":
                cipher_name = algo_str.split("/")[0].upper()
                if cipher_name in _WEAK_CIPHER_PREFIXES:
                    findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
