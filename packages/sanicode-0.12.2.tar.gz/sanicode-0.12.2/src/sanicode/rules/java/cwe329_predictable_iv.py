"""Predictable IV detection rules for Java (CWE-329).

SC450 — new IvParameterSpec(new byte[N])    high  CWE-329
"""
from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule, _walk
from sanicode.rules.java._helpers import java_call_arguments, java_dotted_name
from sanicode.scanner.patterns import Finding


class JavaPredictableIVRule(Rule):
    """Detect IvParameterSpec initialized with zero-filled byte array."""

    rule_id = "SC450"
    cwe_id = 329
    severity = "high"
    language = "java"
    message = "Predictable IV — new IvParameterSpec(new byte[N]) is zero-filled (CWE-329)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []

        for node in _walk(tree.root_node):
            if node.type != "object_creation_expression":
                continue
            type_node = node.child_by_field_name("type")
            if type_node is None:
                continue
            type_name = java_dotted_name(type_node)
            if type_name != "IvParameterSpec":
                continue

            # Check first argument is `new byte[N]`
            args = java_call_arguments(node)
            if not args:
                continue
            first = args[0]
            if first.type == "array_creation_expression":
                # new byte[16] is zero-initialized by JVM
                findings.append(self._make_finding(node, plugin, file_path))

        return findings
