"""Mass assignment detection for Java (CWE-915).

SC444 — BeanUtils.populate/copyProperties with request data    medium  CWE-915
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.java._helpers import java_method_name
from sanicode.scanner.patterns import Finding

_MASS_ASSIGN_METHODS = frozenset({
    "populate", "copyProperties", "setProperty",
})
_MASS_ASSIGN_RECEIVERS = frozenset({
    "BeanUtils", "PropertyUtils",
})
_MAPPER_METHODS = frozenset({"map"})
_MAPPER_RECEIVERS = frozenset({"ModelMapper", "modelMapper", "mapper"})


class JavaMassAssignmentRule(Rule):
    """Detect BeanUtils/ModelMapper calls that may pass unfiltered request data."""

    rule_id = "SC444"
    cwe_id = 915
    severity = "medium"
    language = "java"
    message = (
        "BeanUtils/ModelMapper with potentially unfiltered input — "
        "mass assignment risk (CWE-915)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(method_invocation) @call", tree.root_node)
        for call_node in call_captures.get("call", []):
            obj_name, method_name = java_method_name(call_node)
            if method_name in _MASS_ASSIGN_METHODS and any(
                r in obj_name for r in _MASS_ASSIGN_RECEIVERS
            ):
                findings.append(self._make_finding(call_node, plugin, file_path))
            elif method_name in _MAPPER_METHODS and any(
                r in obj_name for r in _MAPPER_RECEIVERS
            ):
                findings.append(self._make_finding(call_node, plugin, file_path))
        return findings
