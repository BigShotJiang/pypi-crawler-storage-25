"""JNDI injection detection rules for Java (CWE-917).

SC404 — JNDI lookup()    high  CWE-917
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.java._helpers import java_method_name
from sanicode.scanner.patterns import Finding

_NAMING_PREFIXES = ("javax.naming", "jakarta.naming")


class JavaJNDILookupRule(Rule):
    """Detect JNDI lookup() calls — JNDI injection risk (Log4Shell pattern).

    Import-aware: when a file imports from javax.naming or jakarta.naming,
    ALL lookup() calls are flagged regardless of receiver name. Falls back
    to the "Context" substring check for files without naming imports.
    """

    rule_id = "SC404"
    cwe_id = 917
    severity = "high"
    language = "java"
    message = "Use of JNDI lookup() — JNDI injection risk (CWE-917)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []

        # Check if the file imports from javax.naming or jakarta.naming
        has_naming_import = False
        imports = plugin.detect_imports(tree, file_path)
        for imp in imports:
            if any(imp.module.startswith(prefix) for prefix in _NAMING_PREFIXES):
                has_naming_import = True
                break

        call_captures = plugin.captures("(method_invocation) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            obj_name, method_name = java_method_name(call_node)
            if method_name != "lookup":
                continue
            # With a naming import, flag any lookup() call
            if has_naming_import:
                findings.append(self._make_finding(call_node, plugin, file_path))
            # Without imports, fall back to receiver name heuristic
            elif "Context" in obj_name or "InitialContext" in obj_name:
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
