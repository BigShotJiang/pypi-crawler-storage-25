"""Public cloud storage resource exposure detection for Java (CWE-668).

SC460 — Cloud storage API call sets public ACL on bucket/object  medium  CWE-668

Detects method invocations where any argument contains ``PublicRead`` or
``PublicReadWrite``.  This covers:

- Enum field access: ``CannedAccessControlList.PublicRead``
- Builder method: ``.withCannedAcl(CannedAccessControlList.PublicRead)``
- Any other expression that textually contains the public ACL identifiers.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from tree_sitter import Node, Tree

from sanicode.rules.base import Rule
from sanicode.rules.java._helpers import java_call_arguments
from sanicode.scanner.patterns import Finding

if TYPE_CHECKING:
    from sanicode.scanner.languages.base import TreeSitterPlugin

_PUBLIC_ACL_IDENTIFIERS: tuple[str, ...] = ("PublicRead", "PublicReadWrite")


def _node_text(node: Node) -> str:
    return node.text.decode("utf-8") if node.text else ""


def _contains_public_acl(node: Node) -> bool:
    """Return True if *node*'s text contains a public ACL identifier."""
    text = _node_text(node)
    return any(ident in text for ident in _PUBLIC_ACL_IDENTIFIERS)


class JavaPublicResourceRule(Rule):
    """Detect cloud storage calls that set a public ACL (CWE-668)."""

    rule_id = "SC460"
    cwe_id = 668
    severity = "medium"
    language = "java"
    message = (
        "Public ACL on cloud storage resource "
        "\u2014 review access control (CWE-668)"
    )
    tags = ["cloud", "access_control"]
    domain = "access_control"
    action = "review"

    def check(self, tree: Tree, file_path: Path, plugin: TreeSitterPlugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        call_captures = plugin.captures("(method_invocation) @call", root)
        for call_node in call_captures.get("call", []):
            args = java_call_arguments(call_node)
            if any(_contains_public_acl(arg) for arg in args):
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
