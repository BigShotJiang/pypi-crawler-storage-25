"""Code injection detection rules for Java (CWE-94).

SC406 — Class.forName() — dynamic class loading    high  CWE-94
SC407 — ScriptEngine.eval()                        high  CWE-94
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.java._helpers import java_method_name
from sanicode.scanner.patterns import Finding


class JavaClassForNameRule(Rule):
    """Detect Class.forName() — dynamic class loading risk."""

    rule_id = "SC406"
    cwe_id = 94
    severity = "high"
    language = "java"
    message = "Use of Class.forName() — dynamic class loading risk (CWE-94)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(method_invocation) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            obj_name, method_name = java_method_name(call_node)
            if method_name == "forName" and "Class" in obj_name:
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings


class JavaScriptEngineEvalRule(Rule):
    """Detect ScriptEngine.eval() — dynamic script execution risk."""

    rule_id = "SC407"
    cwe_id = 94
    severity = "high"
    language = "java"
    message = "Use of ScriptEngine.eval() — dynamic script execution risk (CWE-94)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(method_invocation) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            obj_name, method_name = java_method_name(call_node)
            if method_name != "eval":
                continue
            # Flag any eval() call on an object — Java's eval() is almost
            # always ScriptEngine in practice, and variable naming is
            # unreliable for filtering (e.g. "se.eval()", "e.eval()").
            if obj_name:
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
