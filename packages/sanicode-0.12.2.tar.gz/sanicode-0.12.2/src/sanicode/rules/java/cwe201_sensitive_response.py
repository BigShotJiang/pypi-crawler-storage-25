"""Sensitive data exposure in HTTP response for Java (CWE-201).

SC461 — Response includes sensitive-named variable    medium  CWE-201
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules._sensitive_patterns import PII_VAR_PATTERN, SECRET_VAR_PATTERN
from sanicode.rules.base import Rule, _walk
from sanicode.rules.java._helpers import java_method_name
from sanicode.scanner.patterns import Finding

# ResponseEntity / Response builder methods
_RESPONSE_ENTITY_METHODS: frozenset[str] = frozenset({"ok", "body", "status"})
_RESPONSE_ENTITY_RECEIVERS_SUBSTR: tuple[str, ...] = ("ResponseEntity", "Response")

# Servlet response writer methods
_WRITER_METHODS: frozenset[str] = frozenset({"write", "println"})
_WRITER_RECEIVERS_SUBSTR: tuple[str, ...] = ("response", "out", "writer")


class JavaSensitiveResponseRule(Rule):
    """Detect response-building calls that include sensitive-named variable arguments."""

    rule_id = "SC461"
    cwe_id = 201
    severity = "medium"
    language = "java"
    tags = ["info_disclosure"]
    domain = "data_protection"
    message = (
        "Response includes sensitive-named variable "
        "— may expose secrets or PII in API response (CWE-201)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        captures = plugin.captures("(method_invocation) @call", tree.root_node)
        for call_node in captures.get("call", []):
            obj_name, method = java_method_name(call_node)
            matched = False
            if method in _RESPONSE_ENTITY_METHODS and any(
                sub in obj_name for sub in _RESPONSE_ENTITY_RECEIVERS_SUBSTR
            ):
                matched = True
            elif method in _WRITER_METHODS and any(
                sub in obj_name for sub in _WRITER_RECEIVERS_SUBSTR
            ):
                matched = True
            if not matched:
                continue
            if self._has_sensitive_arg(call_node, plugin):
                findings.append(self._make_finding(call_node, plugin, file_path))
        return findings

    @staticmethod
    def _has_sensitive_arg(call_node, plugin) -> bool:
        args_node = call_node.child_by_field_name("arguments")
        if args_node is None:
            return False
        for child in _walk(args_node):
            if child.type == "identifier":
                name = plugin.node_text(child)
                if SECRET_VAR_PATTERN.search(name) or PII_VAR_PATTERN.search(name):
                    return True
        return False
