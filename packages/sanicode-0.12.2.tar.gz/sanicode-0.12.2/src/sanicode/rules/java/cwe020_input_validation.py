"""Input validation detection for Java (CWE-20).

SC417 — Integer.parseInt() / valueOf() on request parameters    medium  CWE-20
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.scanner.patterns import Finding

_PARSE_METHODS = frozenset({
    "parseInt", "parseDouble", "parseLong", "parseFloat",
    "parseShort", "parseByte",
    "valueOf",
})

_PARSE_CLASSES = frozenset({
    "Integer", "Double", "Long", "Float", "Short", "Byte",
})

_EXTERNAL_KEYWORDS = ("getParameter", "getHeader", "getQueryString", "request")


class JavaInputValidationRule(Rule):
    """Detect numeric parsing of request parameters without validation."""

    rule_id = "SC417"
    cwe_id = 20
    severity = "medium"
    language = "java"
    message = "Numeric parsing of external input without validation (CWE-20)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        call_captures = plugin.captures("(method_invocation) @call", root)
        for call_node in call_captures.get("call", []):
            name_node = call_node.child_by_field_name("name")
            if name_node is None or not name_node.text:
                continue
            name = name_node.text.decode("utf-8")
            if name not in _PARSE_METHODS:
                continue
            obj = call_node.child_by_field_name("object")
            if obj is None or not obj.text:
                continue
            obj_text = obj.text.decode("utf-8")
            if obj_text not in _PARSE_CLASSES:
                continue
            full_text = call_node.text.decode("utf-8") if call_node.text else ""
            if any(kw in full_text for kw in _EXTERNAL_KEYWORDS):
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
