"""Server-side request forgery via HTTP client APIs (CWE-918).

SC413 — HTTP request with non-literal URL — potential SSRF    high  CWE-918
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.java._helpers import (
    java_call_arguments,
    java_dotted_name,
    java_method_name,
)
from sanicode.scanner.patterns import Finding

_METHOD_TARGETS: dict[str, frozenset[str]] = {
    "HttpClient": frozenset({"send"}),
    "RestTemplate": frozenset({"getForObject", "postForObject", "exchange"}),
}

_NEW_TARGETS = frozenset({"URL"})


class JavaSsrfRule(Rule):
    """Detect HTTP client calls and URL constructors with a non-literal URL argument."""

    rule_id = "SC413"
    cwe_id = 918
    severity = "high"
    language = "java"
    message = "HTTP request with non-literal URL — potential SSRF (CWE-918)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []

        # Pattern 1: method invocations — HttpClient.send(), RestTemplate.getForObject(), etc.
        call_captures = plugin.captures(
            "(method_invocation) @call", tree.root_node
        )
        for call_node in call_captures.get("call", []):
            obj_name, method = java_method_name(call_node)
            targets = _METHOD_TARGETS.get(obj_name)
            if targets is None or method not in targets:
                continue
            args = java_call_arguments(call_node)
            if not args:
                continue
            if args[0].type != "string_literal":
                findings.append(self._make_finding(call_node, plugin, file_path))

        # Pattern 2: object creation — new URL(dynamicString)
        new_captures = plugin.captures(
            "(object_creation_expression) @new", tree.root_node
        )
        for new_node in new_captures.get("new", []):
            type_node = new_node.child_by_field_name("type")
            if type_node is None:
                continue
            type_text = java_dotted_name(type_node)
            if type_text not in _NEW_TARGETS:
                continue
            args = java_call_arguments(new_node)
            if not args:
                continue
            if args[0].type != "string_literal":
                findings.append(self._make_finding(new_node, plugin, file_path))

        return findings
