"""Sensitive data storage detection rules for Java (CWE-916, CWE-522, CWE-312).

SC437 — Weak hash on password-named variable          high    CWE-916
SC438 — Secret variable written to file/database      medium  CWE-522
SC439 — Sensitive data written to persistent storage   medium  CWE-312
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules._sensitive_patterns import SECRET_VAR_PATTERN
from sanicode.rules.base import Rule, _walk
from sanicode.rules.java._helpers import java_call_arguments, java_method_name
from sanicode.scanner.patterns import Finding

# MessageDigest.getInstance("MD5") / ("SHA-1")
_WEAK_ALGO_NAMES: frozenset[str] = frozenset({"md5", "sha-1", "sha1"})

# File/DB write methods for CWE-522
_WRITE_METHODS: frozenset[str] = frozenset(
    {"write", "append", "println", "print", "setString", "setObject"}
)

# DB execute methods
_DB_METHODS: frozenset[str] = frozenset(
    {"execute", "executeUpdate", "executeQuery"}
)

# Serialization / config methods for CWE-312
_CLEARTEXT_METHODS: frozenset[str] = frozenset(
    {"setProperty", "put", "store", "setAttribute"}
)


def _has_secret_identifier(node, plugin) -> bool:
    """Walk all descendants for an identifier matching SECRET_VAR_PATTERN."""
    for child in _walk(node):
        if child.type == "identifier":
            name = plugin.node_text(child)
            if SECRET_VAR_PATTERN.search(name):
                return True
    return False


def _strip_quotes(s: str) -> str:
    for q in ('"""', "'''", '"', "'"):
        if s.startswith(q) and s.endswith(q) and len(s) >= 2 * len(q):
            return s[len(q):-len(q)]
    return s


class JavaWeakPasswordHashRule(Rule):
    """Detect MessageDigest.getInstance("MD5"/"SHA-1") with password arguments.

    Only flags when the digest is updated with a password-named variable.
    """

    rule_id = "SC437"
    cwe_id = 916
    severity = "high"
    language = "java"
    message = (
        "Weak hash used on password-named variable "
        "\u2014 use bcrypt/scrypt/PBKDF2 (CWE-916)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        captures = plugin.captures("(method_invocation) @call", tree.root_node)

        for call_node in captures.get("call", []):
            obj_name, method_name = java_method_name(call_node)

            # MessageDigest.getInstance("MD5")
            if method_name == "getInstance" and "MessageDigest" in obj_name:
                args = java_call_arguments(call_node)
                if not args:
                    continue
                algo = _strip_quotes(plugin.node_text(args[0])).lower()
                if algo not in _WEAK_ALGO_NAMES:
                    continue
                # Walk up to the enclosing block to find .update()/.digest()
                block = call_node.parent
                while block and block.type not in ("block", "class_body", "program"):
                    block = block.parent
                if block is None:
                    continue
                for node in _walk(block):
                    if node.type == "method_invocation":
                        _, mn = java_method_name(node)
                        if mn in ("update", "digest"):
                            a_node = node.child_by_field_name("arguments")
                            if a_node and _has_secret_identifier(a_node, plugin):
                                findings.append(
                                    self._make_finding(call_node, plugin, file_path)
                                )
                                break

            # DigestUtils.md5Hex(password)
            if method_name in ("md5Hex", "md5", "sha1Hex", "sha1"):
                args_node = call_node.child_by_field_name("arguments")
                if args_node and _has_secret_identifier(args_node, plugin):
                    findings.append(self._make_finding(call_node, plugin, file_path))

        return findings


class JavaUnprotectedPasswordStorageRule(Rule):
    """Detect file writes or DB operations storing secret-named variables."""

    rule_id = "SC438"
    cwe_id = 522
    severity = "medium"
    language = "java"
    message = (
        "Secret-named variable written to file or database "
        "without hashing (CWE-522)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        captures = plugin.captures("(method_invocation) @call", tree.root_node)

        for call_node in captures.get("call", []):
            _, method_name = java_method_name(call_node)

            if method_name in _WRITE_METHODS or method_name in _DB_METHODS:
                args_node = call_node.child_by_field_name("arguments")
                if args_node and _has_secret_identifier(args_node, plugin):
                    findings.append(self._make_finding(call_node, plugin, file_path))

        return findings


class JavaCleartextSecretStorageRule(Rule):
    """Detect sensitive data written to persistent storage in cleartext."""

    rule_id = "SC439"
    cwe_id = 312
    severity = "medium"
    language = "java"
    message = (
        "Sensitive data written to persistent storage "
        "in cleartext (CWE-312)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        captures = plugin.captures("(method_invocation) @call", tree.root_node)

        for call_node in captures.get("call", []):
            _, method_name = java_method_name(call_node)

            if method_name in _CLEARTEXT_METHODS:
                args_node = call_node.child_by_field_name("arguments")
                if args_node and _has_secret_identifier(args_node, plugin):
                    findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
