"""CRLF and HTTP header injection detection for Java (CWE-93, CWE-113).

SC431 — CRLF injection via header manipulation    medium  CWE-93
SC432 — HTTP response splitting via headers       medium  CWE-113
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.java._helpers import java_method_name
from sanicode.scanner.patterns import Finding

_HEADER_METHODS = frozenset({"setHeader", "addHeader"})


def _check_header_calls(
    tree: Tree, file_path: Path, plugin, rule: Rule,
) -> list[Finding]:
    """Shared detection logic for Java HTTP header-setting calls."""
    findings: list[Finding] = []
    call_captures = plugin.captures("(method_invocation) @call", tree.root_node)

    for call_node in call_captures.get("call", []):
        _obj_name, method_name = java_method_name(call_node)
        if method_name not in _HEADER_METHODS:
            continue
        # setHeader/addHeader are specific to HttpServletResponse — flag any call.
        findings.append(rule._make_finding(call_node, plugin, file_path))

    return findings


class CRLFInjectionRule(Rule):
    """Detect HTTP header-setting calls in Java — CRLF injection risk."""

    rule_id = "SC431"
    cwe_id = 93
    severity = "medium"
    language = "java"
    message = (
        "HTTP header set \u2014 verify value is sanitized against "
        "CRLF injection (CWE-93)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        return _check_header_calls(tree, file_path, plugin, self)


class HeaderInjectionRule(Rule):
    """Detect HTTP header-setting calls in Java — response splitting risk."""

    rule_id = "SC432"
    cwe_id = 113
    severity = "medium"
    language = "java"
    message = (
        "HTTP header set \u2014 verify value prevents "
        "response splitting (CWE-113)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        return _check_header_calls(tree, file_path, plugin, self)
