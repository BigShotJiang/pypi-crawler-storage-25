"""LDAP injection detection for Java (CWE-90).

SC421 — LDAP search with string concatenation in filter argument.
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.java._helpers import (
    java_call_arguments,
    java_is_string_concat,
    java_method_name,
)
from sanicode.scanner.patterns import Finding


class JavaLdapInjectionRule(Rule):
    """Detect LDAP search with string concatenation in filter — LDAP injection."""

    rule_id = "SC421"
    cwe_id = 90
    severity = "high"
    language = "java"
    message = "LDAP filter built from string concatenation — LDAP injection risk (CWE-90)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        captures = plugin.captures("(method_invocation) @call", tree.root_node)

        for call_node in captures.get("call", []):
            _, method = java_method_name(call_node)
            if method != "search":
                continue

            args = java_call_arguments(call_node)
            # DirContext.search(name, filter, controls) — filter is arg index 1
            if len(args) >= 2 and java_is_string_concat(args[1]):
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
