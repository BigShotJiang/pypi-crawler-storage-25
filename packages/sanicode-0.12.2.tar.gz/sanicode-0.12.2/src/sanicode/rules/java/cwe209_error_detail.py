"""Error detail exposure detection for Java (CWE-209).

SC457 — getMessage/toString/getStackTrace on caught exception    medium  CWE-209
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Node, Tree

from sanicode.rules.base import Rule, _walk
from sanicode.rules.java._helpers import java_method_name
from sanicode.scanner.patterns import Finding

_DETAIL_METHODS = frozenset({"getMessage", "toString", "getStackTrace"})


def _catch_var_name(catch_clause: Node) -> str:
    """Extract the exception parameter name from a catch_clause node.

    ``catch_formal_parameter`` children: catch_type, identifier (the var).
    """
    for child in catch_clause.children:
        if child.type == "catch_formal_parameter":
            # The last identifier child is the parameter name
            for gc in child.children:
                if gc.type == "identifier" and gc.text:
                    return gc.text.decode("utf-8")
    return ""


def _block_exposes_detail(block: Node, var_name: str) -> list[Node]:
    """Find method_invocation nodes that call a detail method on *var_name*."""
    hits: list[Node] = []
    if not var_name:
        return hits
    for node in _walk(block):
        if node.type != "method_invocation":
            continue
        obj_name, method = java_method_name(node)
        if obj_name == var_name and method in _DETAIL_METHODS:
            hits.append(node)
    return hits


class JavaErrorDetailRule(Rule):
    """Detect exception detail methods (getMessage, toString, getStackTrace) in catch blocks."""

    rule_id = "SC457"
    cwe_id = 209
    severity = "medium"
    language = "java"
    message = (
        "Error detail exposed in exception handler — "
        "may leak implementation details to users (CWE-209)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for node in _walk(tree.root_node):
            if node.type != "catch_clause":
                continue
            var_name = _catch_var_name(node)
            for child in node.children:
                if child.type == "block":
                    for hit in _block_exposes_detail(child, var_name):
                        findings.append(self._make_finding(hit, plugin, file_path))
        return findings
