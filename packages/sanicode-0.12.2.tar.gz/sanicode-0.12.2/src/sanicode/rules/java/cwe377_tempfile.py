"""CWE-377 insecure temporary file for Java.

SC447 — File.createTempFile() usage    low  CWE-377
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.java._helpers import java_method_name
from sanicode.scanner.patterns import Finding

_TEMP_FILE_RECEIVERS = frozenset({"File", "java.io.File"})


class JavaInsecureTempFileRule(Rule):
    """Flag File.createTempFile() — may create files with insecure permissions.

    java.io.File.createTempFile() does not set restrictive permissions on the
    created file, leaving it world-readable on some platforms.  Prefer
    java.nio.file.Files.createTempFile() with explicit PosixFilePermission
    attributes to control access.
    """

    rule_id = "SC447"
    cwe_id = 377
    severity = "low"
    language = "java"
    message = (
        "File.createTempFile() may create temporary files with insecure permissions \u2014 "
        "consider using java.nio.file.Files.createTempFile() with explicit attributes (CWE-377)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []

        for node in plugin.captures("(method_invocation) @call", tree.root_node).get("call", []):
            obj, method = java_method_name(node)
            if method == "createTempFile" and obj in _TEMP_FILE_RECEIVERS:
                findings.append(self._make_finding(node, plugin, file_path))

        return findings
