"""Untrusted inclusion detection for Java (CWE-829).

SC445 — Dynamic class loading with non-literal argument    medium  CWE-829
"""
from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.java._helpers import java_call_arguments, java_method_name
from sanicode.scanner.patterns import Finding

_CLASSLOAD_METHODS = frozenset({
    "forName", "loadClass", "findClass",
})

_CLASSLOAD_RECEIVERS = frozenset({
    "Class", "ClassLoader", "URLClassLoader",
})

# Literal node types that represent a safe, hard-coded class name
_LITERAL_TYPES = frozenset({
    "string_literal", "text_block",
})


class JavaUntrustedInclusionRule(Rule):
    """Detect dynamic class loading with non-literal class name arguments."""

    rule_id = "SC445"
    cwe_id = 829
    severity = "medium"
    language = "java"
    message = (
        "Dynamic class loading with non-literal argument — "
        "untrusted code inclusion risk (CWE-829)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []

        # method_invocation: Class.forName(x), loader.loadClass(x), etc.
        call_captures = plugin.captures("(method_invocation) @call", tree.root_node)
        for call_node in call_captures.get("call", []):
            obj_name, method_name = java_method_name(call_node)
            if method_name not in _CLASSLOAD_METHODS:
                continue
            # Accept if receiver matches a known class loader type, or receiver
            # is an expression that evaluates to a ClassLoader (non-empty obj).
            # Require at least one token from the known set appears in obj_name,
            # or obj_name is non-empty for loadClass/findClass (instance method).
            if method_name == "forName":
                if not any(r in obj_name for r in _CLASSLOAD_RECEIVERS):
                    continue
            # loadClass/findClass: any non-empty receiver is a class loader
            elif not obj_name:
                continue

            args = java_call_arguments(call_node)
            if not args:
                continue
            first = args[0]
            if first.type in _LITERAL_TYPES:
                continue
            findings.append(self._make_finding(call_node, plugin, file_path))

        # object_creation_expression: new URLClassLoader(urls)
        new_captures = plugin.captures("(object_creation_expression) @new", tree.root_node)
        for new_node in new_captures.get("new", []):
            type_node = new_node.child_by_field_name("type")
            if type_node is None:
                continue
            type_name = type_node.text.decode("utf-8") if type_node.text else ""
            if type_name == "URLClassLoader":
                findings.append(self._make_finding(new_node, plugin, file_path))

        return findings
