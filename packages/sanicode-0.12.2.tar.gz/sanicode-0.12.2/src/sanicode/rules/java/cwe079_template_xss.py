"""Spring @ResponseBody XSS via string concatenation (CWE-79).

SC475 -- @ResponseBody returning concatenated HTML    high  CWE-79
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule, _walk
from sanicode.rules.java._helpers import java_is_string_concat
from sanicode.scanner.patterns import Finding

_RESPONSE_ANNOTATIONS = frozenset({"ResponseBody", "RestController"})


class SpringResponseBodyXssRule(Rule):
    """Detect @ResponseBody methods returning concatenated strings.

    In Spring MVC, methods annotated with ``@ResponseBody`` (or in a
    ``@RestController`` class) write the return value directly to the
    HTTP response.  Returning a string built via concatenation or
    ``String.format()`` is a common XSS pattern when user input is
    interpolated without escaping.

    This complements SC414 (print/println/write sinks) by catching the
    Spring-idiomatic pattern where the return value *is* the sink.
    """

    rule_id = "SC475"
    cwe_id = 79
    severity = "high"
    language = "java"
    message = (
        "@ResponseBody method returns concatenated string \u2014 "
        "potential XSS (CWE-79)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []

        # Check for class-level @RestController
        class_has_rest = False
        for node in _walk(tree.root_node):
            if node.type == "class_declaration":
                class_has_rest = self._has_response_annotation(node)
                break

        for node in _walk(tree.root_node):
            if node.type != "method_declaration":
                continue

            has_annotation = class_has_rest or self._has_response_annotation(node)
            if not has_annotation:
                continue

            # Look for return statements with string concatenation
            for child in _walk(node):
                if child.type != "return_statement":
                    continue
                # The return value is the first non-keyword child
                for sub in child.children:
                    if sub.type in ("return", ";"):
                        continue
                    if java_is_string_concat(sub):
                        findings.append(
                            self._make_finding(child, plugin, file_path)
                        )
                    break  # only check first expression

        return findings

    @staticmethod
    def _has_response_annotation(node) -> bool:
        """Check if a declaration node has @ResponseBody or @RestController.

        In Java tree-sitter, annotations live inside a ``modifiers`` node
        that is a direct child of the declaration.
        """
        for child in node.children:
            if child.type == "modifiers":
                for mod_child in child.children:
                    if mod_child.type not in ("marker_annotation", "annotation"):
                        continue
                    text = mod_child.text.decode("utf-8") if mod_child.text else ""
                    for ann in _RESPONSE_ANNOTATIONS:
                        if ann in text:
                            return True
        return False
