"""Indirect command injection via environment variables for Java (CWE-78).

SC476 — System.getenv() value used in Runtime.exec() or ProcessBuilder.

Detects patterns where System.getenv() flows into Runtime.exec() or
ProcessBuilder constructor arguments within the same call expression.
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule, _walk
from sanicode.rules.java._helpers import java_method_name
from sanicode.scanner.patterns import Finding


def _subtree_has_getenv(node) -> bool:
    """Check if any node in the subtree is a System.getenv() call."""
    for n in _walk(node):
        if n.type == "method_invocation":
            obj_name, method_name = java_method_name(n)
            if method_name == "getenv" and "System" in obj_name:
                return True
    return False


class JavaEnvCommandInjectionRule(Rule):
    """Detect System.getenv() values used in Runtime.exec() or ProcessBuilder."""

    rule_id = "SC476"
    cwe_id = 78
    severity = "medium"
    language = "java"
    message = (
        "System.getenv() used in command execution — "
        "indirect command injection risk (CWE-78)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []

        # Pattern 1: Runtime.exec() with getenv in args
        call_captures = plugin.captures("(method_invocation) @call", tree.root_node)
        for call_node in call_captures.get("call", []):
            obj_name, method_name = java_method_name(call_node)
            if method_name == "exec" and ("Runtime" in obj_name or "getRuntime" in obj_name):
                if _subtree_has_getenv(call_node):
                    findings.append(self._make_finding(call_node, plugin, file_path))

        # Pattern 2: new ProcessBuilder(...) with getenv in args
        new_captures = plugin.captures("(object_creation_expression) @new", tree.root_node)
        for new_node in new_captures.get("new", []):
            type_node = new_node.child_by_field_name("type")
            if type_node is None:
                continue
            type_text = type_node.text.decode("utf-8") if type_node.text else ""
            if type_text == "ProcessBuilder":
                if _subtree_has_getenv(new_node):
                    findings.append(self._make_finding(new_node, plugin, file_path))

        return findings
