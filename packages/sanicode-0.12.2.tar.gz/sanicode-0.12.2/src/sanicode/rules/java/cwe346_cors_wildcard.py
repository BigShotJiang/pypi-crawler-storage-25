"""CORS wildcard origin detection for Java (CWE-346).

SC452 — Access-Control-Allow-Origin set to wildcard *    medium  CWE-346
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.java._helpers import java_call_arguments, java_method_name
from sanicode.scanner.patterns import Finding

_HEADER_NAME = "access-control-allow-origin"
_SET_METHODS = frozenset({"setHeader", "addHeader"})


def _string_text(node) -> str:
    """Extract unquoted text from a Java string literal."""
    if node.type != "string_literal":
        return ""
    text = node.text.decode("utf-8") if node.text else ""
    return text.strip('"')


class JavaCorsWildcardRule(Rule):
    """Detect response.setHeader/addHeader('Access-Control-Allow-Origin', '*') in Java."""

    rule_id = "SC452"
    cwe_id = 346
    severity = "medium"
    language = "java"
    message = "Access-Control-Allow-Origin set to wildcard '*' (CWE-346)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(method_invocation) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            _obj, method = java_method_name(call_node)
            if method not in _SET_METHODS:
                continue
            args = java_call_arguments(call_node)
            if len(args) < 2:
                continue
            header_text = _string_text(args[0])
            if _HEADER_NAME not in header_text.lower():
                continue
            value_text = _string_text(args[1])
            if value_text == "*":
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
