"""Session and cookie security detection rules for Java (CWE-614, CWE-384, CWE-613).

SC440 -- Insecure cookie configuration (missing Secure flag)     medium  CWE-614
SC441 -- Session fixation (auth without session regeneration)    medium  CWE-384
SC442 -- Session timeout / cookie integrity                      low     CWE-613
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.java._helpers import java_method_name
from sanicode.scanner.patterns import Finding


class JavaInsecureCookieRule(Rule):
    """Detect Cookie creation without Secure flag (CWE-614).

    Flags ``new Cookie(name, value)`` constructor calls as requiring Secure
    flag review, and explicit ``cookie.setSecure(false)`` calls.
    """

    rule_id = "SC440"
    cwe_id = 614
    severity = "medium"
    language = "java"
    message = "Cookie created \u2014 verify Secure flag is set (CWE-614)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        # Pattern 1: new Cookie(name, value)
        new_captures = plugin.captures(
            "(object_creation_expression) @new", root
        )
        for new_node in new_captures.get("new", []):
            type_node = new_node.child_by_field_name("type")
            if type_node is None:
                continue
            type_text = type_node.text.decode("utf-8") if type_node.text else ""
            if type_text == "Cookie":
                findings.append(self._make_finding(new_node, plugin, file_path))

        # Pattern 2: cookie.setSecure(false)
        call_captures = plugin.captures("(method_invocation) @call", root)
        for call_node in call_captures.get("call", []):
            _, method = java_method_name(call_node)
            if method == "setSecure":
                args_node = call_node.child_by_field_name("arguments")
                if args_node:
                    for child in args_node.children:
                        if child.type in ("false", "boolean_literal"):
                            text = child.text.decode("utf-8") if child.text else ""
                            if text == "false":
                                findings.append(
                                    self._make_finding(call_node, plugin, file_path)
                                )
                                break

        return findings


class JavaSessionFixationRule(Rule):
    """Detect authentication patterns that may lack session regeneration (CWE-384).

    Flags login-related method calls as requiring review to ensure
    ``session.invalidate()`` or ``request.changeSessionId()`` is called.
    """

    rule_id = "SC441"
    cwe_id = 384
    severity = "medium"
    language = "java"
    message = (
        "Authentication call \u2014 verify session ID is regenerated after login (CWE-384)"
    )

    _LOGIN_METHODS = frozenset({
        "authenticate", "login", "doLogin", "processLogin",
        "checkCredentials", "validateUser",
    })

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        call_captures = plugin.captures("(method_invocation) @call", root)
        for call_node in call_captures.get("call", []):
            _, method = java_method_name(call_node)
            if method in self._LOGIN_METHODS:
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings


class JavaSessionTimeoutRule(Rule):
    """Detect session misconfiguration: no timeout or HttpOnly disabled (CWE-613).

    Flags ``session.setMaxInactiveInterval(0)`` or
    ``cookie.setHttpOnly(false)``.
    """

    rule_id = "SC442"
    cwe_id = 613
    severity = "low"
    language = "java"
    message = (
        "Session configuration \u2014 verify timeout and integrity settings (CWE-613)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        call_captures = plugin.captures("(method_invocation) @call", root)
        for call_node in call_captures.get("call", []):
            _, method = java_method_name(call_node)

            if method == "setMaxInactiveInterval":
                # Flag setMaxInactiveInterval(0) or very large values
                args_node = call_node.child_by_field_name("arguments")
                if args_node:
                    for child in args_node.children:
                        if child.type == "decimal_integer_literal":
                            text = child.text.decode("utf-8") if child.text else ""
                            if text == "0":
                                findings.append(
                                    self._make_finding(call_node, plugin, file_path)
                                )
                                break

            elif method == "setHttpOnly":
                args_node = call_node.child_by_field_name("arguments")
                if args_node:
                    for child in args_node.children:
                        if child.type in ("false", "boolean_literal"):
                            text = child.text.decode("utf-8") if child.text else ""
                            if text == "false":
                                findings.append(
                                    self._make_finding(call_node, plugin, file_path)
                                )
                                break

        return findings
