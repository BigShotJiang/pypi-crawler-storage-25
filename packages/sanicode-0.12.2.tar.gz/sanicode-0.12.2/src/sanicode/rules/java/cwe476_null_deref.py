"""NULL pointer dereference detection for Java (CWE-476).

SC419 — Chained method call on nullable return value    high  CWE-476
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.scanner.patterns import Finding

# Methods on collections/maps/queues that commonly return null.
# Excludes first()/last() (throw NoSuchElementException) and remove() (throws
# IndexOutOfBoundsException) — those are not null-return risks.
_NULLABLE_METHODS = frozenset({
    "get", "peek", "poll", "pollFirst", "pollLast",
})


class JavaNullDerefRule(Rule):
    """Detect chained method call on nullable return value (e.g. map.get(k).foo())."""

    rule_id = "SC419"
    cwe_id = 476
    severity = "high"
    language = "java"
    message = (
        "Chained method call on nullable return value — "
        "null pointer dereference risk (CWE-476)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        # Find method_invocation nodes
        call_captures = plugin.captures("(method_invocation) @call", root)
        for call_node in call_captures.get("call", []):
            # The "object" field is what we're calling the method on
            obj = call_node.child_by_field_name("object")
            if obj is None or obj.type != "method_invocation":
                continue
            # The inner call's "name" field is the method being called
            inner_name = obj.child_by_field_name("name")
            if inner_name is None:
                continue
            name_text = inner_name.text.decode("utf-8") if inner_name.text else ""
            if name_text in _NULLABLE_METHODS:
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
