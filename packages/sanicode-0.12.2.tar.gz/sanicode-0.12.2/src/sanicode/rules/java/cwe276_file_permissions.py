"""Overly permissive file permissions for Java (CWE-276).

SC453 — File.setWritable(true, false) / setReadable / setExecutable    medium  CWE-276

Java's ``File.setWritable(writable, ownerOnly)`` with ``ownerOnly=false``
grants the permission to all users, not just the owner.  The second
argument being ``false`` is the dangerous case.
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.java._helpers import java_call_arguments, java_method_name
from sanicode.scanner.patterns import Finding

# Methods that accept (boolean value, boolean ownerOnly) — second arg false = all users.
_PERMISSION_METHODS = frozenset({
    "setWritable",
    "setReadable",
    "setExecutable",
})


def _is_false_literal(node) -> bool:
    """Return True if *node* represents the boolean literal ``false``."""
    return node.type == "false"


class JavaFilePermissionsRule(Rule):
    """Detect File.setWritable/setReadable/setExecutable(true, false) — all-user access."""

    rule_id = "SC453"
    cwe_id = 276
    severity = "medium"
    language = "java"
    message = (
        "File.setWritable/setReadable/setExecutable with ownerOnly=false — "
        "grants permission to all users (CWE-276)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(method_invocation) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            _, method_name = java_method_name(call_node)
            if method_name not in _PERMISSION_METHODS:
                continue
            args = java_call_arguments(call_node)
            # setWritable(true, false): first arg=true (grant permission),
            # second arg=false (to all users — not owner-only).
            # setWritable(false, false) is restrictive, not permissive; skip it.
            if len(args) < 2:
                continue
            if args[0].type == "true" and _is_false_literal(args[1]):
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
