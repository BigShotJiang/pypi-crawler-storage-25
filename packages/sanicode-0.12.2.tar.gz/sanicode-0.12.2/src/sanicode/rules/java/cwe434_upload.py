"""Unrestricted file upload detection for Java (CWE-434).

SC416 — MultipartFile without type validation    medium  CWE-434
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.java._helpers import java_method_name
from sanicode.scanner.patterns import Finding


class JavaFileUploadRule(Rule):
    """Detect MultipartFile.transferTo() and getInputStream() without type validation."""

    rule_id = "SC416"
    cwe_id = 434
    severity = "medium"
    language = "java"
    message = "File upload without type validation \u2014 unrestricted upload risk (CWE-434)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        call_captures = plugin.captures("(method_invocation) @call", root)
        for call_node in call_captures.get("call", []):
            obj_name, method_name = java_method_name(call_node)
            obj_lower = obj_name.lower()

            # transferTo() on an uploaded file object
            if method_name == "transferTo" and (
                "file" in obj_lower or "upload" in obj_lower or "multipart" in obj_lower
            ):
                findings.append(self._make_finding(call_node, plugin, file_path))

            # getInputStream() on a file variable
            elif method_name == "getInputStream" and "file" in obj_lower:
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
