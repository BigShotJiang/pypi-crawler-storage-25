"""Cleartext HTTP transmission detection (CWE-319).

SC451 — HTTP request using cleartext http:// URL    medium  CWE-319
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.java._helpers import java_call_arguments, java_dotted_name
from sanicode.scanner.patterns import Finding

_NEW_TARGETS = frozenset({"URL", "URI"})

_LOOPBACK_PREFIXES = (
    "http://localhost",
    "http://127.",
    "http://0.0.0.0",
    "http://[::1]",
)


def _extract_java_string(node) -> str:
    """Extract inner text from a Java string_literal node."""
    if node.text is None:
        return ""
    text = node.text.decode("utf-8")
    if len(text) >= 2 and text[0] == '"' and text[-1] == '"':
        return text[1:-1]
    return text


def _is_cleartext_http_java(node) -> bool:
    """Return True if a Java string literal contains a non-loopback http:// URL."""
    if node.type != "string_literal":
        return False
    inner = _extract_java_string(node)
    lower = inner.lower()
    if not lower.startswith("http://"):
        return False
    for prefix in _LOOPBACK_PREFIXES:
        if lower.startswith(prefix):
            return False
    return True


class JavaCleartextHttpRule(Rule):
    """Detect URL/URI constructors using cleartext http://.

    Unlike SSRF (CWE-918) which flags non-literal URLs, this rule flags
    literal URLs that use http:// instead of https://, indicating traffic
    is sent in cleartext over the network.
    """

    rule_id = "SC451"
    cwe_id = 319
    severity = "medium"
    language = "java"
    message = "HTTP request uses cleartext http:// URL — use https:// (CWE-319)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []

        new_captures = plugin.captures(
            "(object_creation_expression) @new", tree.root_node
        )
        for new_node in new_captures.get("new", []):
            type_node = new_node.child_by_field_name("type")
            if type_node is None:
                continue
            type_text = java_dotted_name(type_node)
            if type_text not in _NEW_TARGETS:
                continue
            args = java_call_arguments(new_node)
            if not args:
                continue
            if _is_cleartext_http_java(args[0]):
                findings.append(self._make_finding(new_node, plugin, file_path))

        return findings
