"""HTTP request smuggling detection for Java (CWE-444).

SC469 — Both Content-Length and Transfer-Encoding set in the same method scope
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Node, Tree

from sanicode.rules.base import Rule, _walk
from sanicode.rules.java._helpers import java_call_arguments, java_method_name
from sanicode.scanner.patterns import Finding

_CL = "content-length"
_TE = "transfer-encoding"
_HEADER_METHODS = frozenset({"setHeader", "addHeader"})


def _header_name(node: Node) -> str:
    """Extract and normalise a header name from a string_literal node."""
    if node.text is None:
        return ""
    raw = node.text.decode("utf-8").strip()
    for q in ('"', "'"):
        if raw.startswith(q) and raw.endswith(q) and len(raw) >= 2:
            raw = raw[1:-1]
    return raw.lower()


def _scan_method_body(body: Node) -> tuple[bool, bool]:
    """Walk *body* and return (has_content_length, has_transfer_encoding).

    Matches ``response.setHeader("Content-Length", ...)`` and
    ``response.addHeader("Transfer-Encoding", ...)``.
    """
    has_cl = False
    has_te = False

    for node in _walk(body):
        if node.type != "method_invocation":
            continue
        _, method = java_method_name(node)
        if method not in _HEADER_METHODS:
            continue
        args = java_call_arguments(node)
        if not args:
            continue
        first = args[0]
        if first.type != "string_literal":
            continue
        name = _header_name(first)
        if name == _CL:
            has_cl = True
        elif name == _TE:
            has_te = True

    return has_cl, has_te


class JavaHttpSmugglingRule(Rule):
    """Detect HTTP request smuggling via conflicting Content-Length / Transfer-Encoding headers.

    Setting both ``Content-Length`` and ``Transfer-Encoding`` on the same HTTP
    response within a servlet method creates the ambiguity exploited by request
    smuggling attacks (CWE-444).  Only one header should be present per
    RFC 7230; if both appear the Transfer-Encoding value takes precedence and
    Content-Length must be removed.
    """

    rule_id = "SC469"
    cwe_id = 444
    severity = "medium"
    language = "java"
    message = (
        "Both Content-Length and Transfer-Encoding headers set "
        "\u2014 potential HTTP request smuggling (CWE-444)"
    )
    tags = ["http_smuggling", "headers"]
    domain = "web"
    action = "review"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        method_captures = plugin.captures("(method_declaration) @method", tree.root_node)
        for method_node in method_captures.get("method", []):
            body = method_node.child_by_field_name("body")
            if body is None:
                continue
            has_cl, has_te = _scan_method_body(body)
            if has_cl and has_te:
                findings.append(self._make_finding(method_node, plugin, file_path))
        return findings
