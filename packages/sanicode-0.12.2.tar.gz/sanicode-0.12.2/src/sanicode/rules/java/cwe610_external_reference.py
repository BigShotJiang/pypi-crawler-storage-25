"""File operations with externally controlled path (CWE-610).

SC467 — File operation with externally controlled path — medium  CWE-610
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.java._helpers import (
    java_call_arguments,
    java_dotted_name,
    java_method_name,
)
from sanicode.scanner.patterns import Finding

# object_creation_expression types to flag when path arg is non-literal
_NEW_FILE_TYPES = frozenset({"File", "FileInputStream", "FileReader"})

# method_invocation targets: object -> set of methods
_METHOD_SINKS: dict[str, frozenset[str]] = {
    "Paths": frozenset({"get"}),
    "Files": frozenset({"readAllBytes", "readString", "lines", "newInputStream"}),
}


class JavaExternalReferenceRule(Rule):
    """Detect file I/O constructors and static calls with a non-literal path."""

    rule_id = "SC467"
    cwe_id = 610
    severity = "medium"
    language = "java"
    message = (
        "File operation with externally controlled path \u2014"
        " verify path is validated (CWE-610)"
    )
    tags = ["path_traversal", "file_io"]
    domain = "web"
    action = "review"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []

        # Pattern 1: new File(path), new FileInputStream(path), new FileReader(path)
        new_captures = plugin.captures(
            "(object_creation_expression) @new", tree.root_node
        )
        for new_node in new_captures.get("new", []):
            type_node = new_node.child_by_field_name("type")
            if type_node is None:
                continue
            type_name = java_dotted_name(type_node)
            if type_name not in _NEW_FILE_TYPES:
                continue
            args = java_call_arguments(new_node)
            if not args:
                continue
            if args[0].type != "string_literal":
                findings.append(self._make_finding(new_node, plugin, file_path))

        # Pattern 2: Paths.get(path), Files.readAllBytes(path), etc.
        call_captures = plugin.captures(
            "(method_invocation) @call", tree.root_node
        )
        for call_node in call_captures.get("call", []):
            obj_name, method = java_method_name(call_node)
            targets = _METHOD_SINKS.get(obj_name)
            if targets is None or method not in targets:
                continue
            args = java_call_arguments(call_node)
            if not args:
                continue
            if args[0].type != "string_literal":
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
