"""Integer overflow detection for Java (CWE-190).

SC418 — Narrowing integer cast without bounds check    medium  CWE-190
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.scanner.patterns import Finding

# Integral types narrower than int — casting to these from int/long may truncate.
_NARROWING_TYPES = frozenset({"short", "byte", "char"})


class JavaIntegerOverflowRule(Rule):
    """Detect narrowing integer casts that may silently truncate values."""

    rule_id = "SC418"
    cwe_id = 190
    severity = "medium"
    language = "java"
    message = "Narrowing integer cast — potential integer overflow/truncation (CWE-190)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        cast_captures = plugin.captures("(cast_expression) @cast", root)
        for cast_node in cast_captures.get("cast", []):
            type_node = cast_node.child_by_field_name("type")
            if type_node is None:
                continue
            type_text = type_node.text.decode("utf-8") if type_node.text else ""
            if type_text in _NARROWING_TYPES:
                findings.append(self._make_finding(cast_node, plugin, file_path))

        return findings
