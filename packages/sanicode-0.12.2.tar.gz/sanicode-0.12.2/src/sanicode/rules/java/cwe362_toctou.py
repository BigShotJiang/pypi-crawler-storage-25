"""Filesystem TOCTOU race condition detection for Java (CWE-362).

SC456 — File.exists/canRead/canWrite/isFile/isDirectory    medium  CWE-362
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.java._helpers import java_method_name
from sanicode.scanner.patterns import Finding

_TOCTOU_METHODS = frozenset({"exists", "canRead", "canWrite", "isFile", "isDirectory"})


class JavaTOCTOUCheck(Rule):
    """Detect TOCTOU race conditions via File check-then-act patterns.

    Methods such as File.exists(), File.canRead(), File.canWrite(),
    File.isFile(), and File.isDirectory() are inherently racy: the
    filesystem state may change between the check and the subsequent
    operation.  Use try/catch around the operation itself instead.
    """

    rule_id = "SC456"
    cwe_id = 362
    severity = "medium"
    language = "java"
    message = (
        "Filesystem TOCTOU race — check-then-act on File.exists/canRead/canWrite/"
        "isFile/isDirectory is inherently racy; catch the operation exception instead (CWE-362)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        for call_node in plugin.captures("(method_invocation) @call", tree.root_node).get(
            "call", []
        ):
            _, method = java_method_name(call_node)
            if method in _TOCTOU_METHODS:
                findings.append(self._make_finding(call_node, plugin, file_path))
        return findings
