"""Weak cryptography detection rules for Java (CWE-327).

SC412 — MessageDigest.getInstance("MD5"/"SHA-1")    medium  CWE-327
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.java._helpers import java_call_arguments, java_method_name
from sanicode.scanner.patterns import Finding

_WEAK_ALGO_NAMES = frozenset({"MD5", "SHA1", "SHA-1"})


def _strip_java_quotes(s: str) -> str:
    if s.startswith('"') and s.endswith('"') and len(s) >= 2:
        return s[1:-1]
    return s


class JavaWeakCryptoRule(Rule):
    """Detect MessageDigest.getInstance('MD5'/'SHA-1') — weak hash algorithm."""

    rule_id = "SC412"
    cwe_id = 327
    severity = "medium"
    language = "java"
    message = "Use of weak hash algorithm (MD5/SHA1) — unsuitable for security (CWE-327)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(method_invocation) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            obj_name, method_name = java_method_name(call_node)

            if obj_name != "MessageDigest" or method_name != "getInstance":
                continue

            args = java_call_arguments(call_node)
            if not args:
                continue

            first = args[0]
            if first.type != "string_literal":
                continue

            algo = _strip_java_quotes(plugin.node_text(first)).upper()
            if algo in _WEAK_ALGO_NAMES:
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
