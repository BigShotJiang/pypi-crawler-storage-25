"""Clickjacking protection bypass detection for Java (CWE-1021).

SC468 — X-Frame-Options set to permissive value or removed    medium  CWE-1021
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.java._helpers import java_call_arguments, java_method_name
from sanicode.scanner.patterns import Finding

_HEADER_NAME = "x-frame-options"
_SET_METHODS = frozenset({"setHeader", "addHeader"})
# Values that explicitly disable frame protection
_PERMISSIVE_VALUES = frozenset({"ALLOWALL", ""})


def _string_text(node) -> str:
    """Extract unquoted text from a Java string literal."""
    if node.type != "string_literal":
        return ""
    text = node.text.decode("utf-8") if node.text else ""
    return text.strip('"')


class JavaClickjackingRule(Rule):
    """Detect permissive or absent X-Frame-Options header configuration in Java."""

    rule_id = "SC468"
    cwe_id = 1021
    severity = "medium"
    language = "java"
    message = (
        "Clickjacking protection disabled or weakened "
        "\u2014 verify X-Frame-Options/CSP configuration (CWE-1021)"
    )
    tags = ["clickjacking", "headers"]
    domain = "web"
    action = "review"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures("(method_invocation) @call", tree.root_node)

        for call_node in call_captures.get("call", []):
            _obj, method = java_method_name(call_node)
            if method not in _SET_METHODS:
                continue
            args = java_call_arguments(call_node)
            if len(args) < 2:
                continue
            header_text = _string_text(args[0])
            if header_text.lower() != _HEADER_NAME:
                continue
            value_text = _string_text(args[1]).upper()
            if value_text in _PERMISSIVE_VALUES:
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
