"""Insecure random number generation detection for Java (CWE-330).

SC443 — Use of java.util.Random — not cryptographically secure    medium  CWE-330
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.java._helpers import java_method_name
from sanicode.scanner.patterns import Finding

_RANDOM_METHODS = frozenset({
    "nextInt", "nextLong", "nextDouble", "nextFloat",
    "nextBoolean", "nextBytes", "nextGaussian",
})


class JavaInsecureRandomRule(Rule):
    """Detect java.util.Random method calls and constructor — not cryptographically secure."""

    rule_id = "SC443"
    cwe_id = 330
    severity = "medium"
    language = "java"
    message = (
        "Use of java.util.Random — not cryptographically secure, "
        "use SecureRandom instead (CWE-330)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []

        # Pattern 1: method calls using Random-specific method names.
        # Without type inference we check that the receiver name does NOT
        # contain "Secure", which excludes obvious SecureRandom usage while
        # catching bare variable names (rng, r, gen, etc.).
        call_captures = plugin.captures("(method_invocation) @call", tree.root_node)
        for call_node in call_captures.get("call", []):
            obj_name, method_name = java_method_name(call_node)
            if method_name not in _RANDOM_METHODS:
                continue
            if "secure" in obj_name.lower():
                continue
            findings.append(self._make_finding(call_node, plugin, file_path))

        # Pattern 2: new Random() constructor
        new_captures = plugin.captures("(object_creation_expression) @new", tree.root_node)
        for new_node in new_captures.get("new", []):
            type_node = new_node.child_by_field_name("type")
            if type_node is None:
                continue
            type_name = type_node.text.decode("utf-8") if type_node.text else ""
            if type_name == "Random":
                findings.append(self._make_finding(new_node, plugin, file_path))

        return findings
