"""CSRF protection bypass detection for Java (CWE-352).

SC415 — csrf().disable() in Spring Security                  medium  CWE-352
SC470 — Cookie without SameSite / missing setSecure(true)    medium  CWE-352
SC471 — CORS wildcard origin with credentials enabled        high    CWE-352
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule, _walk
from sanicode.rules.java._helpers import java_call_arguments, java_method_name
from sanicode.scanner.patterns import Finding


def _node_text(node) -> str:
    return node.text.decode("utf-8") if node.text else ""


class JavaCsrfDisableRule(Rule):
    """Detect csrf().disable() in Spring Security configuration."""

    rule_id = "SC415"
    cwe_id = 352
    severity = "medium"
    language = "java"
    message = (
        "CSRF protection disabled in Spring Security — potential CSRF vulnerability (CWE-352)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        call_captures = plugin.captures("(method_invocation) @call", root)
        for call_node in call_captures.get("call", []):
            name_node = call_node.child_by_field_name("name")
            if name_node is None or not name_node.text:
                continue
            name = name_node.text.decode("utf-8")

            # Pattern 1: .disable() called on a .csrf() chain
            if name == "disable":
                obj = call_node.child_by_field_name("object")
                if obj is not None and obj.text and b"csrf" in obj.text:
                    findings.append(self._make_finding(call_node, plugin, file_path))
                    continue

            # Pattern 2: .csrf(AbstractHttpConfigurer::disable) or .csrf(csrf -> csrf.disable())
            if name == "csrf":
                text = call_node.text.decode("utf-8") if call_node.text else ""
                if "disable" in text:
                    findings.append(self._make_finding(call_node, plugin, file_path))

        return findings


class JavaCookieSameSiteRule(Rule):
    """Detect cookies created without SameSite or with setSecure(false) in Java.

    Covers:
    - ``cookie.setSecure(false)`` — explicitly disabling secure flag
    - ``new Cookie(...)`` without a subsequent ``setSecure(true)`` in the same
      method body (approximated via text scan of enclosing block)
    """

    rule_id = "SC470"
    cwe_id = 352
    severity = "medium"
    language = "java"
    message = (
        "Cookie created without SameSite attribute or with setSecure(false) — "
        "explicit SameSite and Secure flags are recommended for CSRF protection (CWE-352)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        call_captures = plugin.captures("(method_invocation) @call", root)
        for call_node in call_captures.get("call", []):
            _obj, method = java_method_name(call_node)

            # Pattern 1: cookie.setSecure(false)
            if method == "setSecure":
                args = java_call_arguments(call_node)
                if args and _node_text(args[0]) == "false":
                    findings.append(self._make_finding(call_node, plugin, file_path))

        # Pattern 2: new Cookie(...) — flag object creation expressions
        # In Java tree-sitter, "new Cookie(...)" is an object_creation_expression.
        for node in _walk(root):
            if node.type != "object_creation_expression":
                continue
            type_node = node.child_by_field_name("type")
            if type_node is None:
                continue
            if _node_text(type_node) != "Cookie":
                continue
            # Check if the enclosing block contains setSecure(true) for this cookie
            parent = node.parent
            while parent and parent.type not in (
                "block", "method_declaration", "constructor_declaration"
            ):
                parent = parent.parent
            if parent is not None:
                block_text = _node_text(parent)
                if "setSecure(true)" in block_text:
                    continue
            findings.append(self._make_finding(node, plugin, file_path))

        return findings


class JavaCorsCredentialsRule(Rule):
    """Detect CORS wildcard origin combined with credentials in Spring.

    Covers:
    - ``@CrossOrigin(origins = "*", allowCredentials = "true")``
    - ``CorsConfiguration`` with ``setAllowedOrigins(...)`` containing ``"*"``
      and ``setAllowCredentials(true)``
    """

    rule_id = "SC471"
    cwe_id = 352
    severity = "high"
    language = "java"
    message = (
        "CORS wildcard origin with credentials enabled — "
        "any site can make credentialed cross-origin requests (CWE-352)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        root = tree.root_node

        # Pattern 1: @CrossOrigin annotation with origins="*" and allowCredentials="true"
        annotation_captures = plugin.captures("(annotation) @ann", root)
        for ann_node in annotation_captures.get("ann", []):
            text = _node_text(ann_node)
            if "CrossOrigin" not in text:
                continue
            if '"*"' in text and "allowCredentials" in text and '"true"' in text:
                findings.append(self._make_finding(ann_node, plugin, file_path))

        # Pattern 2: CorsConfiguration with setAllowedOrigins(*) + setAllowCredentials(true)
        # Scan method bodies for the combination.
        for node in _walk(root):
            if node.type not in ("block", "method_declaration"):
                continue
            block_text = _node_text(node)
            if "setAllowedOrigins" not in block_text and "addAllowedOrigin" not in block_text:
                continue
            has_wildcard = '"*"' in block_text and (
                "setAllowedOrigins" in block_text or "addAllowedOrigin" in block_text
            )
            has_credentials = "setAllowCredentials(true)" in block_text
            if has_wildcard and has_credentials:
                # Find the setAllowCredentials call node for precise location
                call_captures = plugin.captures("(method_invocation) @call", node)
                for call_node in call_captures.get("call", []):
                    _obj, method = java_method_name(call_node)
                    if method == "setAllowCredentials":
                        findings.append(self._make_finding(call_node, plugin, file_path))
                        break
                else:
                    findings.append(self._make_finding(node, plugin, file_path))

        return findings
