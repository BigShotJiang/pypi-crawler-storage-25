"""XPath and XML injection detection for Java (CWE-91, CWE-643, CWE-776).

SC434 -- XPath injection via dynamic query             medium  CWE-91
SC435 -- Unsanitized data in XPath expression          medium  CWE-643
SC436 -- XML parser without entity expansion limits    medium  CWE-776
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.java._helpers import (
    java_call_arguments,
    java_method_name,
)
from sanicode.scanner.patterns import Finding

# XPath method names that accept a query/expression argument.
_XPATH_METHODS = frozenset({"evaluate", "compile"})

# Java string literal node type.
_LITERAL_TYPES = frozenset({"string_literal"})


def _is_java_literal(node) -> bool:
    """Return True if node is a Java string literal."""
    return node.type in _LITERAL_TYPES


def _find_xpath_findings(tree: Tree, file_path: Path, plugin, rule) -> list[Finding]:
    """Shared detection logic for CWE-91 and CWE-643 XPath injection."""
    findings: list[Finding] = []
    captures = plugin.captures("(method_invocation) @call", tree.root_node)

    for call_node in captures.get("call", []):
        _, method = java_method_name(call_node)
        if method not in _XPATH_METHODS:
            continue

        args = java_call_arguments(call_node)
        if not args:
            continue

        # The first argument is the XPath expression.
        if _is_java_literal(args[0]):
            continue

        findings.append(rule._make_finding(call_node, plugin, file_path))

    return findings


# XML parser factory classes whose .newInstance() should have entity expansion
# limits configured.  Distinct from CWE-611 which covers secure processing
# features -- CWE-776 focuses on entity expansion (billion laughs).
_XML_FACTORY_CLASSES = frozenset({
    "SAXParserFactory",
    "DocumentBuilderFactory",
})


class JavaXPathInjectionRule(Rule):
    """Detect XPath queries built from dynamic input -- XPath injection."""

    rule_id = "SC434"
    cwe_id = 91
    severity = "medium"
    language = "java"
    message = (
        "XPath query built from dynamic input "
        "\u2014 potential XPath injection (CWE-91)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        return _find_xpath_findings(tree, file_path, plugin, self)


class JavaXPathDataInjectionRule(Rule):
    """Detect unsanitized data in XPath expressions -- injection."""

    rule_id = "SC435"
    cwe_id = 643
    severity = "medium"
    language = "java"
    message = (
        "XPath expression includes unsanitized data "
        "\u2014 potential injection (CWE-643)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        return _find_xpath_findings(tree, file_path, plugin, self)


class JavaXMLEntityExpansionRule(Rule):
    """Detect XML parser factory usage that may allow entity expansion.

    CWE-776 targets recursive internal entity expansion (billion laughs),
    distinct from CWE-611 which targets external entity resolution.
    Flags SAXParserFactory.newInstance() and DocumentBuilderFactory.newInstance()
    as requiring entity expansion configuration review.
    """

    rule_id = "SC436"
    cwe_id = 776
    severity = "medium"
    language = "java"
    message = (
        "XML parser factory without entity expansion limits "
        "\u2014 potential billion laughs attack (CWE-776)"
    )

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        captures = plugin.captures("(method_invocation) @call", tree.root_node)

        for call_node in captures.get("call", []):
            obj_name, method = java_method_name(call_node)
            if method != "newInstance":
                continue
            if any(cls in obj_name for cls in _XML_FACTORY_CLASSES):
                findings.append(self._make_finding(call_node, plugin, file_path))

        return findings
