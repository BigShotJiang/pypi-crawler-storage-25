"""Cross-site scripting via response output with string concatenation (CWE-79).

SC414 — Response output with string concatenation    high  CWE-79
"""

from __future__ import annotations

from pathlib import Path

from tree_sitter import Tree

from sanicode.rules.base import Rule
from sanicode.rules.java._helpers import (
    java_call_arguments,
    java_is_string_concat,
    java_method_name,
)
from sanicode.scanner.patterns import Finding

_OUTPUT_METHODS = frozenset({"print", "println", "write"})


class JavaXssRule(Rule):
    """Detect response output calls with string concatenation — XSS risk.

    Flags print/println/write when the first argument involves string
    concatenation or String.format(). May produce false positives on
    non-response writers (e.g. System.out.println), which is acceptable
    for a conservative first pass.
    """

    rule_id = "SC414"
    cwe_id = 79
    severity = "high"
    language = "java"
    message = "Response output with string concatenation — potential XSS (CWE-79)"

    def check(self, tree: Tree, file_path: Path, plugin) -> list[Finding]:
        findings: list[Finding] = []
        call_captures = plugin.captures(
            "(method_invocation) @call", tree.root_node
        )
        for call_node in call_captures.get("call", []):
            _obj_name, method = java_method_name(call_node)
            if method not in _OUTPUT_METHODS:
                continue
            args = java_call_arguments(call_node)
            if not args:
                continue
            if java_is_string_concat(args[0]):
                findings.append(self._make_finding(call_node, plugin, file_path))
        return findings
