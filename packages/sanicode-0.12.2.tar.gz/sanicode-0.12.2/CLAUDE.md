# Sanicode — Project Context

Sanicode is a PyPI-distributed CLI tool that uses an AI agent (configurable LLM backend) to build a codebase-level knowledge graph, then outputs security/sanitization recommendations mapped to OWASP ASVS, NIST 800-53, and ASD STIG controls. The key differentiator over tools like Bandit or Semgrep is data flow context via LLM reasoning over a knowledge graph, not just AST pattern matching.

See `RESEARCH.md` for the full standards baseline, architecture rationale, and tooling landscape.

## Getting Started

Work from GitHub issues. Before starting any task, check `gh issue list --repo rdwj/sanicode` for open issues. If you notice work that needs doing but isn't going to happen in the current session, create an issue for it rather than leaving it as a mental note or TODO comment.

Before starting work on an issue, verify the work hasn't already been done: check `docs/coverage-scorecard.html` for current rule counts and CWE coverage, and `git log --oneline -20` for recent commits. This avoids duplicate effort across sessions.

Issues have dependency notes in their descriptions — check "blocked by" before starting.

## Tech Stack

- Python 3.10+, package name `sanicode`
- CLI: Typer
- AST parsing: tree-sitter (multi-language via tree-sitter-language-pack)
- Knowledge graph: treeloom (Code Property Graph library, PyPI `treeloom`). KnowledgeGraph inherits from CpgBridge which wraps treeloom's CodePropertyGraph. See `~/Developer/treeloom` for the source and `treeloom` on PyPI for releases.
- LLM integration: LiteLLM (multi-provider, tiered endpoints)
- API server: FastAPI (`sanicode serve`)
- Config: TOML (`sanicode.toml` or `~/.config/sanicode/config.toml`)
- Output formats: Markdown, JSON, SARIF
- Container base: `registry.redhat.io/ubi9/python-311` (UBI9, multi-stage)
- Phase 3 operator: kopf (Python); Phase 4: Go Operator SDK if needed

## Project Structure

```
sanicode/
├── src/sanicode/       # Main package
├── data/               # Compliance cross-reference DB (JSON/TOML)
├── rules/              # Rule definitions (YAML, Bandit-style)
├── prompts/            # Prompt templates (YAML, with {variable} substitution)
├── tests/              # Mirrors src/sanicode/ structure; pytest, 80%+ coverage
└── sanicode.toml       # Project config (or ~/.config/sanicode/)
```

## Phase Structure

- **Phase 1** (starting now): Python package + CLI. Scan → knowledge graph → compliance-mapped report. Local mode + `sanicode serve` API mode.
- **Phase 2**: Containerized deployment on OpenShift. Helm chart, Prometheus metrics, Grafana dashboard, MLflow integration, Tekton task, KFP pipeline.
- **Phase 3**: Lightweight Python Operator via kopf. CRDs: SanicodeConfig, SanicodeScan, SanicodeProfile, SanicodeException. Auto-discover InferenceService CRs.
- **Phase 4**: Production Operator (Go/Operator SDK or Helm-based), OLM packaging, OperatorHub submission.

## CLI Surface

```
sanicode config    # Configure LLM backend (tiered endpoints)
sanicode scan      # Scan codebase, build knowledge graph
sanicode serve     # Start FastAPI server (containerized/remote mode)
sanicode report    # Generate compliance-mapped report
sanicode graph     # Inspect/export the knowledge graph
sanicode diff      # Compare two scans with severity-weighted scoring
```

The CLI operates in three modes: **local** (all in-process), **remote** (thin client to sanicode-api), **hybrid** (AST local, LLM remote).

## Key Architectural Decisions

**Degraded mode is not optional.** With no LLM configured, sanicode must still produce useful output: AST pattern matching, known-bad function detection, data flow graph construction, compliance lookups, and SARIF output. LLM adds context-awareness and false-positive reduction on top.

**Compliance mapping is cross-cutting.** Every finding must carry: CWE ID, OWASP ASVS 5.0 requirement (with L1/L2/L3 level), NIST 800-53 control (SI-10, SI-15, etc.), ASD STIG check ID and CAT level (I/II/III). PCI DSS mapping where applicable.

**Knowledge graph is the differentiator.** Graph nodes: entry points, sanitization points, sink points, trust boundaries. Edges: data flow paths. LLM reasons over the graph to assess whether sanitization actually covers the identified threat.

**API is designed for machine consumption first.** A refactoring agent (Konveyor, custom agent) needs to iterate programmatically. REST endpoints: `POST /api/v1/scan`, `GET /api/v1/scan/{id}`, `GET /api/v1/scan/{id}/findings`, `GET /api/v1/scan/{id}/graph`, `POST /api/v1/analyze`, `GET /api/v1/compliance/map`.

**Offline-native, not offline-compatible.** Zero egress at runtime. All compliance data, rules, and prompt templates ship in the package. Model weights are a separate supply chain artifact (PVC or ModelCar OCI image) — never bundled with sanicode.

**Tiered model support.** `sanicode.toml` allows separate endpoints for fast (classification), analysis (data flow), and reasoning (compliance mapping + report generation) tiers. Recommended: Granite Nano → Granite Code 8B → Llama 3.1 70B.

**Augment/review pipeline replaces tiered LLM stages.** Model Rodeo testing (March 2026) across 13 models showed that a single LLM pass with CPG context dramatically outperforms the previous four-stage pipeline. Two strategies are supported: `augment` (LLM reasons independently with CPG context, best for strong models like Claude Haiku, gpt-oss:20b, granite3.3:8b) and `review` (LLM reviews deterministic findings with CPG context, best for mid-tier models like mistral-nemo and deepseek). Models below ~7B parameters should be avoided — accuracy drops significantly. The graph edge fix in the CPG significantly improved `review` strategy performance across all mid-tier models. When LLM and deterministic analysis disagree, a Pass 3 tiebreaker fires — a second LLM call presents both positions to an independent evaluator, producing a 2-1 majority decision (`source` field: `"2-1 deterministic"` or `"2-1 llm"`). Pass 3 only fires on disagreements (~5-15% of findings), keeping cost overhead at ~10%. Configure via `[llm] preset = "local-medium"` in sanicode.toml. The legacy three-tier system (fast/analysis/reasoning) remains supported for backward compatibility.

## Backlog Discipline

Work backlog items until they are 100% complete. 99% rounds to zero. If during implementation we discover scope that should wait (separate concern, large effort, blocked on something else), the standard procedure is:

1. Create a new backlog issue for the carved-out work, with full context.
2. Update the current issue to document what moved and reference the new issue(s).
3. Only then close the current issue.

This prevents hidden technical debt from accumulating behind "done" items. An agent should never offer to close an item until the carve-out issues exist and the current item's description reflects the reduced scope.

## Releasing

The version lives in two files that must stay in sync:
- `src/sanicode/version.py` — `__version__ = "x.y.z"`
- `pyproject.toml` — `version = "x.y.z"`

To release, run from the project root:

```bash
./scripts/release.sh <version> "<description>"
```

This updates both version files, commits, tags, and pushes. GitHub Actions handles testing, GitHub Release creation, and PyPI publishing via OIDC trusted publishing. See `PUBLISHING.md` for one-time setup steps.

Never update version files manually — always use the release script to ensure consistency.

**Always update README.md before releasing.** The README is rendered as the PyPI package description — an outdated README ships outdated docs to every `pip install` user. Review and update the README as part of every release.

## Integration Tests

PRs that change files under `src/sanicode/graph/`, `src/sanicode/scanner/taint.py`, `src/sanicode/scanner/data_flow.py`, or `src/sanicode/rules/graph/` must either add/update a CPG integration fixture or explain why none is needed.

**Fixture layout:** each subdirectory of `tests/integration/cpg_fixtures/` contains source files and a `fixture.yml` contract declaring expected findings and graph shape. The test harness (`test_cpg_fixtures.py`) auto-discovers fixtures and runs the full scan pipeline in deterministic mode.

**Adding a fixture:**

1. Create `tests/integration/cpg_fixtures/<name>/` with source files and `fixture.yml`.
2. Run `pytest tests/integration/test_cpg_fixtures.py -v` to verify.

**`fixture.yml` schema:**

```yaml
name: Descriptive name
description: What this fixture exercises.

expect:
  findings:
    min_count: 1              # minimum total findings
    max_count: 5              # optional upper bound
    must_include:
      - rule_id: SC006        # must appear
        cwe_id: 89            # optional CWE filter
        file: app.py          # optional file filter (basename)
    must_exclude:
      - rule_id: SC006        # bare string OK
      - rule_id: SC004        # or dict with optional file scope
        file: safe.py

  graph:
    nodes:
      entry_point: {min: 1}           # min/max supported
      sink: {min: 1, max: 3}
      sanitizer: {min: 0, max: 0}     # assert absence
    edges:
      min: 2
```

Valid node kinds: `entry_point`, `sink`, `sanitizer`. Unknown kinds raise an error at test time.

## Coverage Scorecard

After adding, removing, or modifying rules, or after creating/closing coverage-related issues (#79–#110), regenerate the scorecard:

```bash
python scripts/coverage-scorecard.py
```

This updates `docs/coverage-scorecard.html` from the live `RuleRegistry` and `data/planned_coverage.json`. Include the regenerated HTML in the same commit as the rule changes.

When creating or closing a coverage issue, also update `data/planned_coverage.json` to keep the planned-vs-implemented view accurate — add new entries for new issues, remove entries for closed ones.

## Don't Forget

- SARIF output is critical for ecosystem interoperability (GitHub Code Scanning, VS Code, Azure DevOps, Tekton gating). Prioritize this over custom formats.
- OWASP ASVS reference is version **5.0** (released May 2025). 17 chapters, fully reorganized from 4.0. Key chapters: V1 (Encoding/Sanitization), V6 (Authentication), V8 (Authorization), V11 (Cryptography). Use `v5.0.0-X.Y.Z` identifiers where X is the chapter number (e.g., `v5.0.0-1.2.4` for parameterized queries in V1).
- ASD STIG version is **v4 r11**. Key IDs: APSC-DV-002510 (command injection, CAT I), APSC-DV-002520 (XSS, CAT II), APSC-DV-002530 (input validation, CAT II).
- CWE is the lingua franca across all frameworks. Core sanitization CWEs: 20, 77, 78, 79, 89, 94, 116, 918, 1333.
- `SanicodeException` CRs (Phase 3) are critical for ATO workflows — RBAC-controlled, expiring, GitOps-managed risk acceptances.
- Expose `/metrics` (Prometheus) from day one in `sanicode serve`. Compliance score, findings by severity/CWE/namespace, LLM usage.
- For model selection, prefer the augment/review pipeline presets over the legacy three-tier config. See `docs/model-sizing-guide.md` for the Model Rodeo benchmark results and recommended presets.
