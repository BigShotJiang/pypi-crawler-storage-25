# Model Rodeo Summary

Tested **3 models** across **6 conditions** on **70 benchmark samples**.

## Top 5 Models (by average F1)

1. **claude-haiku-4-5** (cloud, general) — F1=0.978
2. **granite3.3:8b** (8B, general) — F1=0.929
3. **mistral-nemo:latest** (12B, general) — F1=0.870

## Key Findings

- Best FP filter rate: **100.0%** by claude-haiku-4-5 (condition C)
- CPG enrichment (C vs A): improved F1 for **0** models, degraded for **0**
- Hinting (B vs A): improved F1 for **0** models, degraded for **0**
- Parse errors: **1** / 420 (0.2%)

## Weight Class Winners

- **12B**: mistral-nemo:latest (F1=0.870)
- **8B**: granite3.3:8b (F1=0.929)
- **cloud**: claude-haiku-4-5 (F1=0.978)
