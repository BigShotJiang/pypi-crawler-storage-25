"""Command injection test cases — all safe."""
import subprocess


def ping_host():
    # Safe: list form, no shell, all literal arguments
    subprocess.run(["ping", "-c", "1", "localhost"], check=True)
