# sanicode Helm Chart

Deploys [Sanicode](https://github.com/rdwj/sanicode) — an AI-assisted code sanitization scanner with compliance mapping to OWASP ASVS 5.0, NIST 800-53, and ASD STIG — on OpenShift.

## Prerequisites

- OpenShift 4.12+
- Helm 3.x
- An image pull secret for `quay.io/wjackson/sanicode` (default: `wjackson-wesjackson-pull-secret`)
- Optional: Grafana Operator (for dashboard CRs), Prometheus Operator (for ServiceMonitor/PrometheusRule)

## Installation

```bash
# Install with defaults into the sanicode namespace
helm install sanicode ./charts/sanicode -n sanicode --create-namespace

# Install with a custom values override
helm install sanicode ./charts/sanicode -n sanicode --create-namespace -f my-values.yaml
```

## Key Configuration Values

| Key | Default | Description |
|-----|---------|-------------|
| `replicaCount` | `1` | Number of API server replicas |
| `image.repository` | `quay.io/wjackson/sanicode` | Container image repository |
| `image.tag` | `0.9.0` | Image tag to deploy |
| `image.pullPolicy` | `IfNotPresent` | Kubernetes image pull policy |
| `resources.requests.memory` | `128Mi` | Memory request |
| `resources.requests.cpu` | `100m` | CPU request |
| `resources.limits.memory` | `512Mi` | Memory limit |
| `resources.limits.cpu` | `500m` | CPU limit |
| `route.enabled` | `true` | Create an OpenShift Route |
| `route.tls.termination` | `edge` | TLS termination strategy |
| `metrics.enabled` | `true` | Expose `/metrics` and deploy ServiceMonitor |
| `metrics.interval` | `30s` | Prometheus scrape interval |
| `alerting.enabled` | `true` | Deploy PrometheusRule with default alerts |
| `grafana.enabled` | `true` | Deploy GrafanaDashboard and GrafanaDatasource CRs |
| `grafana.mlflow.enabled` | `false` | Deploy MLflow Grafana datasource/dashboard |
| `grafana.pipeline.enabled` | `false` | Deploy KFP pipeline health Grafana dashboard |
| `modelStorage.enabled` | `false` | Create a PVC for local model weight storage |
| `modelStorage.size` | `50Gi` | PVC storage request |
| `modelStorage.storageClassName` | `""` | StorageClass name; empty uses cluster default |
| `modelStorage.accessModes` | `[ReadWriteOnce]` | PVC access modes |
| `modelStorage.mountPath` | `/models` | Mount path inside the container |

## Upgrade

```bash
helm upgrade sanicode ./charts/sanicode -n sanicode -f my-values.yaml
```

## Uninstall

```bash
helm uninstall sanicode -n sanicode
```

Note: PVCs are not deleted automatically on uninstall. Remove manually if no longer needed:

```bash
oc delete pvc sanicode-models -n sanicode
```
