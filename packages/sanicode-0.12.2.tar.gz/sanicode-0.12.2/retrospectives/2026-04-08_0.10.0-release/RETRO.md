# Retrospective: sanicode 0.10.0 release

**Date:** 2026-04-08
**Effort:** Bug sweep + release prep for 0.10.0, cutting PyPI publish
**Issues closed:** #207, #209, #216, #219, #220, #222, #223, #226, #227, #228
**Issues filed:** #224, #233, #234, #235
**PRs merged:** #225, #229, #230, #231, #232
**Commit range:** `66bd594` → `f5c13b8` (22 commits)

## What we set out to do

Start from an audit of where the project actually was (uncommitted working tree, stale version at 0.9.0 with no tag, several open bugs labelled "bug"). Decide whether a release was possible. Plan a bug sweep. Execute the sweep as a series of clean commits and PRs. Cut 0.10.0 when the sweep was done.

The agreed-upon sweep targeted six blocker bugs — #207 (CLI stdout), #209 (LLM/litellm stderr), #216 (unimplemented `recommend`), #219 (SC2111 noise), #220 (`links` → `edges` rename), #223 (CPG zero-edges) — plus the already-implemented-but-unreleased work from #222 (augment/review pipeline) and #221 (Model Rodeo).

Mid-effort, the user surfaced the March 2026 litellm supply-chain advisory and the three pre-existing CI failures (#226, #227, #228). Both were folded into scope without derailing the release plan.

## What changed

| Change | Type | Rationale |
|---|---|---|
| Split working tree into 5 sequential commits on main (A) rather than a single PR | Good pivot | Working-tree changes were already load-bearing and had been locally verified; splitting them cleanly gave `git blame` value and set up the bug sweep on solid ground |
| Tiebreaker Pass 3 (#222) carved out to #224 before closing #222 | Scope deferral | #222's three-way vote design wasn't implemented; closing it on the 2-way pipeline would have hidden scope. Carve-out issue was filed *before* #222 was closed per CLAUDE.md backlog discipline |
| litellm security pin added mid-sprint | New requirement | User flagged the March 2026 advisory. Landed as a direct-to-main commit rather than a PR because it was trivial, urgent, and verifiable (tests passed on the upgraded version) |
| Pre-existing CI failures bundled into one PR (#232) with three commits | Good pivot | Issues were independent but all blocked clean CI. Bundling into one PR with per-concern commits kept main history coherent |
| README drift was bigger than expected — ended up rewriting rule count, language list, CWE count, status section, and fixing a license mismatch (Apache-2.0 vs MIT) | Missed requirement | "README checkpoint before release" was technically in CLAUDE.md but I planned for a "review" rather than a "rewrite". The drift was real |
| #218 (cross-version finding comparison) deferred to 0.11+ | Scope deferral | Labelled `enhancement`, not `bug`, and overlaps with #213. Not a 0.10.0 blocker |
| Smoke test for #223 iterated — first fixture produced 0 edges because the SQL sink detector requires the f-string inline at the call site | Missed requirement | The CPG fix worked, but the fixture wasn't exercising the sink registration. Rewrote fixture, caught the constraint, validated the fix end-to-end |

## What went well

- **Research-then-execute pattern.** Initial analysis of the uncommitted working tree and the open-bug survey was delegated to a `claude-worker` subagent, which produced a concrete commit-split plan and bug resolution order. Main thread executed that plan without re-deriving it. Kept context focused on coordination.
- **Commit hygiene.** Five PRs plus a direct-to-main security pin, each with a clean scope, a real test plan in the description, and commit messages that explain "why" not "what". `git blame` will be useful going forward.
- **Security turnaround on litellm.** Advisory read → pin drafted → venv upgraded → IOC check → tests green → committed → pushed, all in under 10 minutes. No drama.
- **Pre-commit checks ran before every commit.** Gitleaks on every commit, ruff on every touched file, targeted tests on every change, full pytest as the final check before commit. No CI-as-debugger.
- **The `/ds` skill decomposition at the top of the session** broke the vague "should we release?" question into deliverable research and plan, which set up the rest of the session to be mostly execution.
- **Every issue closed had a test proving the fix.** The SC2111 dedup PR added 7 unit tests including an end-to-end `run_scan` regression test. The #223 fix had unit coverage in `test_call_graph.py`. The CLI fixes had targeted tests in `test_cli.py` and `test_server.py`.

## Gaps identified

| Gap | Severity | Resolution |
|---|---|---|
| Logger-config change in PR B broke pytest `caplog` in 2 MLflow tests — `propagate = False` disables caplog capture. Caught only after pushing and running the full suite | Process gap | **Lesson:** for changes that touch global state (logging config, import-time side effects, env vars), run the full suite *before* pushing, not after. Directly-affected tests aren't enough. **No action item** — this is a habit to internalize |
| #223 CPG fix had unit tests but no integration test on a realistic multi-function case. The sink-registration constraint was only discovered during manual smoke-testing | Fix-later | **Filed #235** — establish an integration test convention for CPG rule and graph-level changes, with `tests/integration/cpg_fixtures/` + YAML contracts |
| PR #232 merged while its tests were still in progress — ship decision was made on confidence from the previous 2 commits, not on a completed CI run | Accepted for this effort | The release workflow has its own test matrix which then ran to completion. Would have been a problem if CI had flaked. User confirmed admin-override was fine for this sprint; should not become routine |
| README drift (rule count stale by ~680 rules, language list stale by 19 languages, license field mismatch with actual LICENSE file) had been sitting for weeks before 0.10.0 prep surfaced it | Process gap | **Fixed in this effort.** Going forward: README rewrite, not spot-check, as part of every release. Consider adding a release-prep checklist to CLAUDE.md that explicitly calls out "rewrite Current status, verify rule count, verify language count, verify license" |
| Pre-existing CI failures had been red on main for days before 0.10.0 prep started. #226, #227, #228 were not filed as issues until the 0.10.0 work surfaced them | Process gap | **Partially fixed.** Rule for future: main CI should not be red for more than one push cycle without an explicit "tracking, will fix" issue. No action item for now — the current backlog has it all tracked |

## Action items

- [x] File #235 — integration test convention for CPG rule and graph-level changes
- [ ] After 0.10.0: enable GitHub Code Scanning in repo settings (#234) — 1-minute admin toggle
- [ ] After 0.10.0: fix the 2 CWE-390 findings that sanicode's self-scan is tripping on (#233)
- [ ] After 0.10.0: land #224 tiebreaker Pass 3 as 0.11.0's marquee feature
- [ ] Consider adding a release-prep checklist section to CLAUDE.md covering README rewrite, rule count verification, license verification, and coverage scorecard regeneration

## Patterns (first retro in this project — establishing baselines)

**Start:**
- For CPG and graph-level rule changes, require an integration-test fixture under `tests/integration/cpg_fixtures/` (or equivalent) — see #235
- For changes that touch global state (logging, import-time side effects, env vars), run the full pytest suite before pushing, not after
- Treat README as a "rewrite target" not a "spot-check target" during release prep
- File tracking issues for pre-existing CI failures as soon as they're noticed, not when they start blocking a release

**Stop:**
- Asserting that directly-affected-tests coverage is sufficient for global-state changes
- Letting main CI stay red across multiple push cycles without explicit tracking issues

**Continue:**
- Research-then-execute: delegate discovery to a `claude-worker`, execute the returned plan from the main thread
- One PR per concern, separate commits within a PR when the PR bundles related-but-distinct fixes
- `/pre-commit` + local pytest before every commit (not just before push)
- Filing carve-out issues *before* closing parent issues when scope moves
- Smoke-test every CPG-level fix against a realistic fixture, not just unit tests
