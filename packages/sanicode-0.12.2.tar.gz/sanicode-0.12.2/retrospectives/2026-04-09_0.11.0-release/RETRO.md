# Retrospective: sanicode 0.11.0 release

**Date:** 2026-04-09
**Effort:** External feedback triage, three implementations, repo hygiene, release cut
**Issues closed:** #210
**Commits:** `2ea81c2` → `c3a0648` (6 commits)

## What We Set Out To Do

Session started as `/project-setup` — repo hygiene (contributor artifacts, issue templates, PR template). Pivoted when the user shared detailed feedback from another agent that had used sanicode 0.10.0 as part of the code-translation-skills project. Triaged 9 feedback items against current state, found 6 already addressed (Java support, config paths, `--skip-content-policy`, `derived_severity`, and two spec integration notes). Committed to implementing the remaining 3:

1. `--no-llm` CLI flag (#210) — skip all LLM stages for fast deterministic scans
2. CWE-913 compliance data gap — enrichment pipeline producing empty fields for 5 rules across 5 languages
3. `node_ref` field on findings — map each finding to its CPG node ID so downstream tools skip resolution

Additionally: relicense MIT → Apache-2.0 for ecosystem compatibility, and add standard repo artifacts (CONTRIBUTING.md, SECURITY.md, templates).

## What Changed

| Change | Type | Rationale |
|---|---|---|
| #224 (tiebreaker Pass 3) was planned as 0.11.0's marquee feature per the 0.10.0 retro — replaced by external consumer feedback | Good pivot | Real user feedback from a consuming project is higher priority than an internal pipeline optimization. #224 stays in backlog |
| ASVS title on CWE-913 entry corrected during review | Caught in review | Sub-agent used a custom title ("Dynamic code execution prevention") for ASVS v5.0.0-1.2.5 instead of the canonical "OS command injection protection" used by all other entries. Review sub-agent caught the inconsistency |
| SARIF `node_ref` property key changed from `node_ref` to `nodeRef` | Caught in review | Review sub-agent flagged snake_case inconsistency with existing `minorityReport` camelCase convention in SARIF properties |
| License file existed (MIT) when `/project-setup` reported it missing | Skill limitation | Glob search was truncated by .venv LICENSE files. Manual read revealed the MIT LICENSE. User explicitly approved the overwrite |

## What Went Well

- **Feedback-driven prioritization.** External feedback from a real consumer (code-translation-skills agent) produced three concrete, well-scoped items. No ambiguity about what to build or why.
- **Sub-agent coordination pattern.** Items 1 and 2 implemented in parallel by two `claude-worker` sub-agents, followed by a review sub-agent that caught two real issues (ASVS title, SARIF key naming). Item 3 implemented by a third worker, reviewed by a fourth. Main thread coordinated without doing implementation work.
- **Existing infrastructure reuse.** `node_ref` population reused the exact `(file, line) → node_id` index pattern already validated in `_enrich_with_domain_reachability`. The `--no-llm` flag matched the `--no-llm-judge` / `skip_llm_judge` pattern. No new patterns invented.
- **CWE-913 was a pure data fix.** Zero code changes — just a JSON entry in `compliance_db.json`. The enrichment pipeline, compliance mapper, and report generators all consumed it automatically. Good validation that the data-driven architecture works.
- **Release process followed `/create-release` workflow end-to-end.** Full pytest (6980 passed), ruff lint clean, gitleaks clean, scorecard regen, README rewrite (not spot-check), release script, CI monitoring — all 9 workflow jobs green on first attempt. Process from the 0.10.0 retro held.
- **Clean commit history.** Each commit has a single concern: repo artifacts, CWE-913 data, `--no-llm` code, `node_ref` code, docs refresh, release tag. No mixed-concern commits.

## Gaps Identified

| Gap | Severity | Resolution |
|---|---|---|
| 0.10.0 retro action items (#233, #234, #224, #235) all still open | Backlog debt | User confirmed: handle in next session. Not blocking, but 4 open items from the last retro should not grow further |
| `ruff format` has pre-existing drift across 50+ files | Accept | Not introduced by this release. Noted but not blocking. Consider a dedicated formatting commit to clear the baseline |
| No new tests written for the three features | Process gap | `--no-llm` and `node_ref` were verified by running the full suite (6980 tests pass) and manual smoke tests, but no targeted unit tests were added for the new code paths. The `_populate_node_refs` helper and the `skip_llm` branching in `run_scan` should have dedicated test coverage |
| `/project-setup` Glob truncation missed the existing LICENSE file | Skill limitation | The skill's file detection was overwhelmed by `.venv/` LICENSE files. Caught before any damage because the Write tool required a read-first. No action needed — the guardrail worked |
| Direct-to-main commits (no PRs) means no CI ran before push | Accepted | All changes were locally verified (full pytest, ruff, gitleaks). The release workflow's test matrix then validated across Python 3.10-3.13. User confirmed direct-to-main was appropriate for this effort's scope |

## Action Items

- [ ] Next session: address 0.10.0 retro backlog (#233 CWE-390 self-scan, #234 GitHub Code Scanning, #224 tiebreaker Pass 3, #235 CPG integration tests)
- [ ] Add unit tests for `_populate_node_refs` and `skip_llm` branch in `run_scan` — file an issue if not done next session
- [ ] Consider a `chore: apply ruff format` commit to clear the 50+ file formatting drift baseline

## Patterns (cross-referencing 0.10.0 retro)

**Start:**
- When adding new helper functions or branching logic, write targeted tests in the same commit — not just "full suite passes"
- Track retro action items as GitHub issues so they show up in backlog queries, not just in retro docs

**Stop:**
- Nothing new to stop — the 0.10.0 "stop" items (global-state-only testing, letting CI stay red) weren't issues this session

**Continue:**
- Feedback-driven releases over roadmap-driven releases when real consumer input exists
- Sub-agent coordination: implement in parallel, review with a separate agent, main thread synthesizes
- README rewrite (not spot-check) during release prep — this pattern from 0.10.0 retro held and caught CLI table gaps, missing commands, and version references
- Filing carve-out issues before closing parent scope (carried forward from 0.10.0, still holding)
- `/create-release` end-to-end workflow with explicit phase gates — no shortcuts
