# Copyright (c) 2021-2024 litebmc.com
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation; either version 3 of the License, or (at your
# option) any later version.
"""完成rootfs镜像打包."""
import os
import shutil
from concurrent.futures import ThreadPoolExecutor, as_completed
from lbkit.tasks.config import Config
from lbkit.tasks.task import Task
from lbkit.utils.fakeroot import Fakeroot
from lbkit import errors

src_cwd = os.path.split(os.path.realpath(__file__))[0]
IMG_FILE = "rootfs.img"

class TaskClass(Task):
    def __init__(self, config, name):
        super().__init__(config, name)
        # 基础rootfs镜像
        self.rootfs = self.config.get_product_config("rootfs/file")
        # 原始文件系统格式
        self.ori_fstype = self.config.get_manifest_config("rootfs/fstype")
        # 目标文件系统格式
        self.fstype = self.config.get_product_config("rootfs/fstype")
        self.append_files = self.config.get_product_config("rootfs/append_files", [])
        # 目标文件系统大小
        size = self.config.get_product_config("rootfs/size")
        self.size = int(size[:-1])
        if size.endswith("G"):
            self.size *= 1024

        self.work_dir = os.path.join(self.config.temp_path, "make_rootfs")
        os.makedirs(self.work_dir, exist_ok=True)
        self.fakeroot_file = os.path.join(self.work_dir, "fakeroot.db")

    def extract_rootfs_to_staging(self, rootfs_img, staging_dir):
        """使用 debugfs 从基础 rootfs 镜像提取内容到 staging 目录"""
        if not os.path.isfile(rootfs_img):
            raise FileNotFoundError(f"Base rootfs image {rootfs_img} not found")
        self.log.info("Extract base rootfs image %s to %s", rootfs_img, staging_dir)
        cmd = f'debugfs -R "rdump / {staging_dir}" {rootfs_img}'
        self.exec(cmd)

    def _apply_perm(self, path, mode, uid, gid):
        """设置文件权限和属主"""
        if mode is not None:
            self.exec(f"chmod {mode} {path}")
        if uid is not None and gid is not None:
            self.exec(f"chown {uid}:{gid} {path}")

    def do_permission(self, per_file: str):
        """完成组件制品赋权"""
        if not os.path.isfile(per_file):
            return
        self.log.info("Do permission, file: %s", per_file)
        with open(per_file, "r", encoding="utf-8") as fp:
            for line in fp:
                line = line.strip()
                if line.startswith("#") or len(line) == 0:
                    continue
                self.log.debug("Permission line: %s", line)
                chunk = line.split()
                if len(chunk) < 5:
                    raise errors.PermissionFormatError(f"Permission format with error, line: {line}")
                if (chunk[2] != "-" and not chunk[2].isnumeric()):
                    raise errors.PermissionFormatError(f"Permission mode error, must is numeric or '-', get({chunk[2]})")
                if (chunk[3] != "-" and not chunk[3].isnumeric()) or (chunk[4] != "-" and not chunk[4].isnumeric()):
                    raise errors.PermissionFormatError(f"Permission uid or gid error, must is numeric or '-', uid({chunk[3]}), gid({chunk[4]})")
                chunk[0] = chunk[0].lstrip("/")
                file_type = chunk[1]
                if file_type not in ("f", "d", "s", "r", "c", "b", "p"):
                    raise errors.PermissionFormatError(
                        f"Permission type error, only support 'f' 'd' 's' 'r' 'c' 'b' 'p', get({file_type})")
                uid = int(chunk[3]) if chunk[3] != "-" else None
                gid = int(chunk[4]) if chunk[4] != "-" else None
                pri = chunk[2] if chunk[2] != "-" else None
                major = int(chunk[5]) if len(chunk) > 5 and chunk[5] != "-" else None
                minor = int(chunk[6]) if len(chunk) > 6 and chunk[6] != "-" else None
                start = int(chunk[7]) if len(chunk) > 7 and chunk[7] != "-" else 0
                inc = int(chunk[8]) if len(chunk) > 8 and chunk[8] != "-" else 1
                count = int(chunk[9]) if len(chunk) > 9 and chunk[9] != "-" else 0
                # 设备文件：major/minor有效时使用mknod创建，参考busybox makedevs.c
                if file_type in ("c", "b", "p") and major is not None and minor is not None:
                    if count > 0:
                        count -= 1
                    for i in range(start, start + count + 1):
                        if count > 0:
                            name = f"{chunk[0]}{i}"
                        else:
                            name = chunk[0]
                        if file_type == "p":
                            cmd = f"mknod {name} p"
                        else:
                            dev_minor = minor + (i - start) * inc
                            cmd = f"mknod {name} {file_type} {major} {dev_minor}"
                        self.log.info("Create device node: %s", name)
                        self.exec(cmd, ignore_error=True)
                        self._apply_perm(name, pri, uid, gid)
                    continue
                if file_type == "d" and not os.path.isdir(chunk[0]):
                    self.log.error("Permission error, %s is not directory", chunk[0])
                if file_type == "s" and not os.path.islink(chunk[0]):
                    self.log.error("Permission error, %s is not symlink", chunk[0])
                if (file_type == "f" and os.path.isdir(chunk[0])) or file_type == "r":
                    for subf in os.listdir(chunk[0]):
                        file_path = os.path.join(chunk[0], subf)
                        if not os.path.isfile(file_path):
                            continue
                        self.log.debug("set permission for %s", file_path)
                        self._apply_perm(file_path, pri, uid, gid)
                else:
                    self._apply_perm(chunk[0], pri, uid, gid)

    def copy_conan_install(self, src_dir, mnt_path, ref=None):
        src_dir += "/"
        cmd = f"rsync -aHK --exclude '*.hpp' --exclude '*.h'"
        cmd += f" --exclude 'rootfs.tar' --exclude 'u-boot.bin'"
        cmd += f" --exclude 'conanmanifest.txt' --exclude 'conaninfo.txt'"
        cmd += f" --exclude '*.a' {src_dir} {mnt_path}"
        ref_info = f" ({ref})" if ref else ""
        self.log.info("copy %s to %s%s", src_dir, mnt_path, ref_info)
        self.exec(cmd, echo_cmd=False)
        for root, dirs, files in os.walk(src_dir):
            root = root.replace(src_dir, "")
            for file in files:
                name = os.path.join(mnt_path, root, file)
                if not os.path.isfile(name):
                    continue
                if name.find("usr/share") > 0 and name.find("bin") == -1:
                    continue
                suffix = name.split(".")[-1]
                no_need_strip = ["json", "html", "md", "txt", "yaml", "xml"]
                no_need_strip.extend(["yml", "mo", "conf", "gz", "inc", "service", "py"])
                no_need_strip.extend(["m4", "pc", "cmake", "rules", "ts", "js", "png"])
                no_need_strip.extend(["jpg", "jpeg", "mpeg", "c", "h", "hpp", "ko"])
                if suffix != name and suffix in no_need_strip:
                    continue
                strip = self.get_manifest_config("metadata/strip")
                if strip:
                    cmds = [f"file {name}", "grep \"not stripped\"", f"{self.config.strip} -s {name}"]
                    self.pipe(cmds, error_log="", ignore_error=True)

    def apply_permission(self, file, permission):
        chunks = permission.split(" ")
        owner = chunks[0]
        perm = chunks[1]
        cmd = f"chmod {perm} {file}"
        self.exec(cmd)
        cmd = f"chown {owner} {file}"
        self.exec(cmd)

    def append_files_to_rootfs(self, mnt_path):
        """追加文件到rootfs（仅复制，不含赋权）"""
        for file in self.append_files:
            source = file.get("source")
            source = os.path.realpath(source)
            dest = file.get("dest")
            dest = os.path.join(mnt_path, dest)
            if os.path.isfile(source):
                dirname = os.path.dirname(dest)
                if dirname and not os.path.isdir(dirname):
                    os.makedirs(dirname, exist_ok=True)
                cmd = f"cp {source} {dest}"
                self.exec(cmd)
            elif os.path.isdir(source):
                os.makedirs(dest, exist_ok=True)
                for file in os.listdir(source):
                    file = os.path.join(source, file)
                    if os.path.isfile(file):
                        cmd = f"cp {file} {dest}/"
                    else:
                        cmd = f"cp {file} {dest}/ -rf"
                    self.exec(cmd)
            else:
                raise Exception(f"Copy append_files to {dest} failed because source file {source} does not exist")

    def apply_append_files_permission(self, mnt_path):
        """为append_files中的文件和目录设置权限"""
        for file in self.append_files:
            source = file.get("source")
            source = os.path.realpath(source)
            dest = file.get("dest")
            dest = os.path.join(mnt_path, dest)
            file_perm = file.get("files_permission", "0:0 640")
            dir_perm = file.get("dirs_permission", "0:0 750")
            if os.path.isfile(source):
                self.apply_permission(dest, file_perm)
            elif os.path.isdir(source):
                for root, dirs, files in os.walk(source):
                    for file in files:
                        file = os.path.join(root, file)
                        name = file[len(source) + 1:]
                        dest_name = os.path.join(dest, name)
                        self.apply_permission(dest_name, file_perm)
                    for dir in dirs:
                        dir = os.path.join(root, dir)
                        name = dir[len(source) + 1:]
                        dest_name = os.path.join(dest, name)
                        self.apply_permission(dest_name, dir_perm)

    def merge_rootfs(self):
        """将产品依赖的所有组件安装到rootfs镜像中"""
        mnt_path = self.config.mnt_path
        shutil.rmtree(mnt_path, ignore_errors=True)
        os.makedirs(mnt_path)

        # ---- 阶段一：准备 rootfs 目录内容 ----
        # 提取基础镜像
        self.extract_rootfs_to_staging(self.rootfs, mnt_path)

        # 复制组件文件到rootfs
        os.chdir(mnt_path)
        self.log.info("Copy customization rootfs......")
        with ThreadPoolExecutor(max_workers=os.cpu_count()) as executor:
            futures = {
                executor.submit(self.copy_conan_install, src_dir, mnt_path, ref): src_dir
                for src_dir, ref in self.config.conan_install
            }
            for future in as_completed(futures):
                future.result()
        # 复制产品自有rootfs
        product_rootfs = os.path.join(self.config.work_dir, "rootfs")
        if os.path.isdir(product_rootfs):
            self.copy_conan_install(product_rootfs, mnt_path)

        # 追加文件
        self.append_files_to_rootfs(mnt_path)

        # 执行rootfs定制化脚本
        os.chdir(self.config.work_dir)
        hook_name = "hook.post_rootfs"
        self.do_hook(hook_name)

        os.chdir(mnt_path)
        # 清理冗余文件
        if os.path.isdir("include"):
            shutil.rmtree("include")
        if os.path.isfile("permissions"):
            os.unlink("permissions")

        try:
            # ---- 阶段二：在 fakeroot 会话中设置权限 ----
            # 清理旧的 fakeroot 数据库，避免上一次构建的 inode 映射残留导致文件类型错乱
            if os.path.isfile(self.fakeroot_file):
                os.unlink(self.fakeroot_file)
            self.config.fakeroot = Fakeroot(self.fakeroot_file)
            self.config.fakeroot.start()

            # 设置boot目录权限
            self.log.info("设置boot目录权限")
            self.exec(f"chown 0:0 ./ -R")
            self.exec(f"chmod 600 boot/ -R")
            if os.path.isdir("extlinux"):
                self.exec(f"chmod 700 boot/extlinux/")

            # 为组件赋权
            self.log.info("为组件赋权")
            for src_dir, ref in self.config.conan_install:
                per_file = os.path.join(src_dir, "permissions")
                self.do_permission(per_file)
            product_rootfs = os.path.join(self.config.work_dir, "rootfs")
            per_file = os.path.join(product_rootfs, "permissions")
            self.do_permission(per_file)

            # 为追加文件赋权
            self.apply_append_files_permission(mnt_path)

            os.chdir(self.config.output_path)

            # ---- 阶段三：生成 rootfs 镜像 ----
            if self.fstype == "ext4":
                cmd = f"mkfs.ext4 -d {mnt_path} -r 1 -N 0 -m 5 -L \"rootfs\" -O ^64bit {self.config.rootfs_img} \"{self.size}M\""
                self.exec(cmd)
            elif self.fstype == "ubi":
                min_io_size = self.config.get_product_config("rootfs/min_io_size", 2048)
                leb_size = self.config.get_product_config("rootfs/leb_size", 126976)
                max_leb_cnt = self.config.get_product_config("rootfs/max_leb_cnt", 1024)
                cmd = f"mkfs.ubifs -r {mnt_path} -m {min_io_size} -e {leb_size} -c {max_leb_cnt} -o {self.config.rootfs_img} -v"
                self.exec(cmd, verbose=True)
                with open("ubinize.cfg", "w+") as fp:
                    fp.write(f"[ubifs]\n")
                    fp.write(f"mode=ubi\n")
                    fp.write(f"image={self.config.rootfs_img}\n")
                    fp.write(f"vol_id=0\n")
                    fp.write(f"vol_size={self.size * 0x100000}\n")
                    fp.write(f"vol_type=dynamic\n")
                    fp.write(f"vol_name=rootfs\n")
                    fp.write(f"vol_flags=autoresize\n")
                blk_size = 1
                tmp_size = leb_size
                while True:
                    blk_size <<= 1
                    tmp_size >>= 1
                    if tmp_size == 0:
                        break
                cmd = f"ubinize -o ubi.img -m {min_io_size} -p {blk_size} -s 2048 ubinize.cfg -v"
                self.exec(cmd, verbose=True)
                # mkfs.ubifs 已创建 rootfs.img，ubinize 读取后需删除再重命名
                if os.path.exists(self.config.rootfs_img):
                    os.unlink(self.config.rootfs_img)
                cmd = f"mv ubi.img {self.config.rootfs_img}"
                self.exec(cmd)
                stat = os.stat(self.config.rootfs_img)
                if stat.st_size > self.size * 1024 * 1024:
                    raise Exception(f"The size of {self.config.rootfs_img} is {stat.st_size}Bytes, bigger than limit size {self.size * 1024 * 1024}Bytes")
        finally:
            fakeroot = getattr(self.config, 'fakeroot', None)
            if fakeroot:
                fakeroot.stop()
                self.config.fakeroot = None

    def run(self):
        # 任务入口
        self.merge_rootfs()
        self.log.success(f"Create image {self.config.rootfs_img} successfully")
        return 0

if __name__ == "__main__":
    config = Config()
    build = TaskClass(config, "test")
    build.run()
