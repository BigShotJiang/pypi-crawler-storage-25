from __future__ import annotations
from allytools.logger import get_logger
from functools import cached_property
from typing import TYPE_CHECKING
from zemod.core.native_adapter import NativeAdapter
from zemod.zemod_analyses import ZeModAnalyses
from zemod.zemod_analysis import ZeModAnalysis
from zemod.zemod_sd import ZeModSD
from zemod.zemod_lde import ZeModLDE
from zemod.tools.zemod_tools import ZeModTools
from zempy.zosapi.analysis.enums.analysis_idm import AnalysisIDM
from zemod.zemod_mfe import ZeModMFE


if TYPE_CHECKING:
    from zempy.zosapi.system.protocols.i_optical_system import IOpticalSystem


log = get_logger(__name__)
class ZeMod(NativeAdapter["IOpticalSystem"]):
    __slots__ = ()

    @property
    def tools(self) -> ZeModTools:
        return ZeModTools(self.native.Tools)

    @cached_property
    def mfe(self) -> ZeModMFE:
        return ZeModMFE(self.native.MFE)

    @cached_property
    def analyses(self) -> ZeModAnalyses:
        return ZeModAnalyses(self.native.Analyses)

    @cached_property
    def sd(self) -> ZeModSD:
        return ZeModSD(self.native.SystemData)

    @cached_property
    def lde(self) -> ZeModLDE:
        return ZeModLDE(self.native.LDE)

    @classmethod
    def from_optical_system(cls, optical_system: IOpticalSystem) -> ZeMod:
        return cls(optical_system)



    #Short cut for tasks in recipe


    def get_fftpsf(self) -> ZeModAnalysis:
        log.trace("Call get_fftpsf")
        return self.analyses.new_analysis(AnalysisIDM.FftPsf)

    def get_huygens_psf(self) -> ZeModAnalysis:
        log.trace("Call get_huygens_psf")
        return self.analyses.new_analysis(AnalysisIDM.HuygensPsf)

    def get_raytracer(self):
        log.trace("Call get_raytracer")
        return self.tools.get_batch_ray_tracer()

    def get_zernike_standard_coefficients(self) -> ZeModAnalysis:
        log.trace("Call get_zernike_standard_coefficients")
        return self.analyses.new_analysis(AnalysisIDM.ZernikeStandardCoefficients)

    def setup_seq_optimization_wizard(self):
        log.trace("Call setup_seq_optimization_wizard")
        return self.mfe.get_seq_optimization_wizard()


    @property
    def file_name(self)->str:
        return self.native.SystemFile

    @property
    def system_name(self)->str:
        return self.native.SystemName