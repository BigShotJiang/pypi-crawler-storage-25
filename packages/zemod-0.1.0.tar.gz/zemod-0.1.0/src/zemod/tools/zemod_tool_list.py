from enum import Enum
from typing import Optional, Type
from zemod.tools.zemod_tool_settings import ZeModToolSettings
from zemod.tools.zemod_tool import ZeModTool
from zemod.tools.zemod_batch_raytrace import ZeModBatchRayTrace
from zemod.tools.quickfocus_settings import QuickFocusSettings
from zemod.raytrace.raytrace_settings import RayTraceSettings
from zemod.optimization.local_optimization_settings import LocalOptimizationSettings
from zemod.optimization.zemod_local_optimization import ZeModLocalOptimization


class ZeModToolList(Enum):
    QUICK_FOCUS = ("OpenQuickFocus", QuickFocusSettings, ZeModTool)
    BATCH_RAYTRACE = ("OpenBatchRayTrace", RayTraceSettings, ZeModBatchRayTrace)
    LOCAL_OPTIMIZATION = ("OpenLocalOptimization", LocalOptimizationSettings, ZeModLocalOptimization)

    def __init__(
        self,
        method_name: str,
        settings_type: Optional[Type[ZeModToolSettings]],
        tool_cls: Type[ZeModTool],
    ):
        self.method_name = method_name
        self.settings_type = settings_type
        self.tool_cls = tool_cls
