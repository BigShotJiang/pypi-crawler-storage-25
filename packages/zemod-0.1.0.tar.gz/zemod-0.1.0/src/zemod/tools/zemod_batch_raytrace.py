from __future__ import annotations
import time
from typing import Any, Tuple
from allytools.logger import get_logger
from allytools.types.validate_cast import validate_cast
from zemod.tools.zemod_tool import ZeModTool
from zemod.raytrace.raytrace_settings import RayTraceSettings
from zemod.raytrace.rays import Rays
from zempy.zosapi.tools.raytrace.adapters.batch_ray_trace import BatchRayTrace
from zemod.raytrace.get_recipe import get_recipe
from zemod.raytrace.traced_sample_ray import TracedSampleRay
from zemod.raytrace.ray_trace_mode import RayTraceMode
from zemod.raytrace.raytrace_single import raytrace_single
from zemod.raytrace.raytrace_batch import raytrace_batch
from zemod.raytrace.rays_of import ray_class_of
from gosti.tracer.ray_batch import RayBatch
from zemod.raytrace.ray.ray_trace_path_builder import build_ray_batch

log = get_logger(__name__)
class ZeModBatchRayTrace(ZeModTool):
    """
    Specialized ZeModTool subclass for batch ray tracing.
    Wraps GenericRayTracer but fits into the ZeModTools.run_tool pipeline.
    """
    __slots__ = ("settings", "traced_rays", "process_time", "_batch_ray_trace")

    def __init__(self, native_batch_tool:BatchRayTrace):
        super().__init__(native_batch_tool)
        self._batch_ray_trace: BatchRayTrace = validate_cast(native_batch_tool, BatchRayTrace)
        self.settings: RayTraceSettings | None = None
        self.traced_rays: list[TracedSampleRay] | None = None
        self.process_time: float | None = None

    def _require_settings(self) -> RayTraceSettings:
        if self.settings is None:
            raise RuntimeError("ZeModBatchRayTraceTool.run() called without settings")
        return self.settings

    @property
    def batch_ray_trace(self) -> BatchRayTrace:
        return self._batch_ray_trace

    @property
    def rays(self) -> Rays:
        if self.traced_rays is None:
            raise RuntimeError("Ray tracer has not been run yet")
        settings = self._require_settings()
        return Rays.from_records(
            [item.ray for item in self.traced_rays],
            ray_type=ray_class_of(settings.method))

    def apply_settings(self, settings: RayTraceSettings) -> None:
        self.settings = settings # override base apply_settings (which expects ZeModToolSettings.apply_to)

    def change_surfaces(self, surfaces: tuple[int, ...]) -> None:
        settings = self._require_settings()
        self.settings = settings.with_surfaces(surfaces)

    def run_generic_ray_tracer(self) -> list[TracedSampleRay]:
        settings = self._require_settings()
        surface_numbers = settings.require_surface_numbers()
        all_traced: list[TracedSampleRay] = []
        t0 = time.time()
        for surface_number in surface_numbers:
            local_settings = settings.with_current_end_surface(surface_number)
            self.settings = local_settings
            recipe = get_recipe(zemod_tool=self)
            mode = local_settings.raytrace_mode
            if mode is RayTraceMode.SINGLE:
                traced = raytrace_single(zemod_tool=self, settings=local_settings, recipe=recipe)
            elif mode is RayTraceMode.BATCH:
                traced = raytrace_batch(zemod_tool=self, settings=local_settings, recipe=recipe)
            else:
                raise ValueError(f"Unsupported raytrace mode: {mode}")
            all_traced.extend(traced)
        self.process_time = time.time() - t0
        self.traced_rays = all_traced
        return all_traced

    def run_ray_batch(self) -> RayBatch:
        settings = self._require_settings()
        traced_sample_rays = self.run_generic_ray_tracer()
        field_grid = settings.resolved_field_grid()
        if settings.pupil_grid is None:
            raise ValueError("settings.pupil_grid is required to build RayBatch")
        return build_ray_batch(traced_sample_rays=traced_sample_rays, field_grid=field_grid, pupil_grid=settings.pupil_grid, input_polarization=settings.pol)
    # region batch ray tracing methods wrapper

    def run_and_wait_for_completion(self) -> bool:
        return self.batch_ray_trace.RunAndWaitForCompletion()

    def create_norm_unpol(
        self,
        *,
        max_rays: int,
        ray_type: Any,
        to_surface: int,
    ) -> Any:
        return self.batch_ray_trace.CreateNormUnpol(
            max_rays,
            ray_type,
            to_surface,
        )

    def create_direct_unpol(
        self,
        *,
        max_rays: int,
        ray_type: Any,
        start_surface: int,
        to_surface: int,
    ) -> Any:
        return self.batch_ray_trace.CreateDirectUnpol(
            max_rays,
            ray_type,
            start_surface,
            to_surface,
        )

    def create_norm_pol(
        self,
        *,
        max_rays: int,
        ray_type: Any,
        ex: float,
        ey: float,
        pha_x: float,
        pha_y: float,
        to_surface: int,
    ) -> Any:
        return self.batch_ray_trace.CreateNormPol(
            max_rays,
            ray_type,
            ex,
            ey,
            pha_x,
            pha_y,
            to_surface,
        )

    def create_direct_pol(
        self,
        *,
        max_rays: int,
        ray_type: Any,
        ex: float,
        ey: float,
        pha_x: float,
        pha_y: float,
        start_surface: int,
        to_surface: int,
    ) -> Any:
        return self.batch_ray_trace.CreateDirectPol(
            max_rays,
            ray_type,
            ex,
            ey,
            pha_x,
            pha_y,
            start_surface,
            to_surface,
        )

    def create_nsc(
        self,
        *,
        max_rays: int,
        max_segments: int,
        coherence_length: float,
    ) -> Any:
        return self.batch_ray_trace.CreateNSC(
            max_rays,
            max_segments,
            coherence_length,
        )

    def create_nsc_sourcedata(
        self,
        *,
        max_segments: int,
        coherence_length: float,
    ) -> Any:
        return self.batch_ray_trace.CreateNSCSourceData(
            max_segments,
            coherence_length,
        )

    def single_ray_norm_unpol(
        self,
        *,
        ray_type: Any,
        to_surf: int,
        wave_number: int,
        hx: float,
        hy: float,
        px: float,
        py: float,
        calc_opd: bool,
    ) -> Tuple:
        """Returns native tuple:
        (ok, error_code, vignette_code, xo, yo, zo, lo, mo, no,
         l2o, m2o, n2o, opd, intensity)
        """
        return self.batch_ray_trace.SingleRayNormUnpol(
            ray_type,
            to_surf,
            wave_number,
            hx,
            hy,
            px,
            py,
            calc_opd,
        )

    def single_ray_direct_unpol(
        self,
        *,
        ray_type: Any,
        start_surface: int,
        to_surface: int,
        wave_number: int,
        x: float,
        y: float,
        z: float,
        l: float,
        m: float,
        n: float,
    ) -> Tuple:
        """Returns native tuple:
        (ok, error_code, vignette_code, xo, yo, zo, lo, mo, no,
         l2o, m2o, n2o, intensity)
        """
        return self.batch_ray_trace.SingleRayDirectUnpol(
            ray_type,
            start_surface,
            to_surface,
            wave_number,
            x,
            y,
            z,
            l,
            m,
            n,
        )

    def single_ray_norm_pol(
        self,
        *,
        ray_type: Any,
        ex: float,
        ey: float,
        pha_x: float,
        pha_y: float,
        to_surf: int,
        wave_number: int,
        hx: float,
        hy: float,
        px: float,
        py: float,
        exr: float,
        exi: float,
        eyr: float,
        eyi: float,
        ezr: float,
        ezi: float,
    ) -> Tuple:
        """Returns native tuple:
        (ok, error_code, exro, exio, eyro, eyio, ezro, ezio, intensity)
        """
        return self.batch_ray_trace.SingleRayNormPol(
            ray_type,
            ex,
            ey,
            pha_x,
            pha_y,
            to_surf,
            wave_number,
            hx,
            hy,
            px,
            py,
            exr,
            exi,
            eyr,
            eyi,
            ezr,
            ezi,
        )

    def single_ray_norm_pol_full(
        self,
        *,
        ray_type: Any,
        ex: float,
        ey: float,
        pha_x: float,
        pha_y: float,
        to_surf: int,
        wave_number: int,
        hx: float,
        hy: float,
        px: float,
        py: float,
        exr: float,
        exi: float,
        eyr: float,
        eyi: float,
        ezr: float,
        ezi: float,
    ) -> Tuple:
        """Returns native tuple:
        (ok, error_code, xo, yo, zo, lo, mo, no,
         exro, exio, eyro, eyio, ezro, ezio, intensity)
        """
        return self.batch_ray_trace.SingleRayNormPolFull(
            ray_type,
            ex,
            ey,
            pha_x,
            pha_y,
            to_surf,
            wave_number,
            hx,
            hy,
            px,
            py,
            exr,
            exi,
            eyr,
            eyi,
            ezr,
            ezi,
        )

    def single_ray_direct_pol(
        self,
        *,
        ray_type: Any,
        ex: float,
        ey: float,
        pha_x: float,
        pha_y: float,
        start_surface: int,
        to_surface: int,
        wave_number: int,
        x: float,
        y: float,
        z: float,
        l: float,
        m: float,
        n: float,
    ) -> Tuple:
        """Returns native tuple:
        (ok, error_code, vignette_code, exro, exio, eyro, eyio,
         ezro, ezio, intensity)
        """
        return self.batch_ray_trace.SingleRayDirectPol(
            ray_type,
            ex,
            ey,
            pha_x,
            pha_y,
            start_surface,
            to_surface,
            wave_number,
            x,
            y,
            z,
            l,
            m,
            n,
        )

    def single_ray_direct_pol_full(
        self,
        *,
        ray_type: Any,
        ex: float,
        ey: float,
        pha_x: float,
        pha_y: float,
        start_surface: int,
        to_surface: int,
        wave_number: int,
        x: float,
        y: float,
        z: float,
        l: float,
        m: float,
        n: float,
    ) -> Tuple:
        """Returns native tuple:
        (ok, error_code, vignette_code, xo, yo, zo, lo, mo, no,
         exro, exio, eyro, eyio, ezro, ezio, intensity)
        """
        return self.batch_ray_trace.SingleRayDirectPolFull(
            ray_type,
            ex,
            ey,
            pha_x,
            pha_y,
            start_surface,
            to_surface,
            wave_number,
            x,
            y,
            z,
            l,
            m,
            n,
        )

    def get_direct_field_coordinates(
            self,
            *,
            wave_number: int,
            ray_type: Any,
            hx: float,
            hy: float,
            px: float,
            py: float,
    ) -> tuple[bool, float, float, float, float, float, float]:
        """Convert from normalized pupil coordinates to direct XYZ/LMN.

        Returns native tuple: (ok, x, y, z, l, m, n)
        """
        ok, x, y, z, l, m, n = self.batch_ray_trace.GetDirectFieldCoordinates(wave_number,ray_type,hx,hy,px,py)
        if not ok:
            raise RuntimeError("GetDirectFieldCoordinates failed")

        return bool(ok),float(x),float(y),float(z),float(l),float(m),float(n)

    def get_phase(
            self,
            *,
            l: float,
            m: float,
            n: float,
            jx: float,
            jy: float,
            x_phase_deg: float,
            y_phase_deg: float,
            intensity: float,
    ) -> tuple[float, float, float, float, float, float]:
        """Returns native tuple: (exr, exi, eyr, eyi, ezr, ezi)."""
        exr, exi, eyr, eyi, ezr, ezi = self.batch_ray_trace.GetPhase(
            l,
            m,
            n,
            jx,
            jy,
            x_phase_deg,
            y_phase_deg,
            intensity,
        )

        return (
            float(exr),
            float(exi),
            float(eyr),
            float(eyi),
            float(ezr),
            float(ezi),
        )

    # endregion
