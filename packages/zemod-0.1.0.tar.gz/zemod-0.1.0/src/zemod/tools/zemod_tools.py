from __future__ import annotations
from allytools.types.validate_cast import validate_cast
from typing import TYPE_CHECKING, Optional, overload, Literal, cast
from zemod.core.native_adapter import NativeAdapter
from zemod.tools.zemod_tool import ZeModTool
from zemod.tools.zemod_batch_raytrace import ZeModBatchRayTrace
from zemod.tools.zemod_tool_settings import ZeModToolSettings
from zemod.tools.zemod_tool_list import ZeModToolList
from zemod.raytrace.raytrace_settings import RayTraceSettings
from zempy.zosapi.tools.raytrace.adapters.batch_ray_trace import BatchRayTrace
from zemod.optimization.zemod_local_optimization import ZeModLocalOptimization
from zemod.optimization.local_optimization_settings import LocalOptimizationSettings
from zempy.zosapi.tools.optimization.adapters.local_optimization import LocalOptimization
from zemod.tools.quickfocus_settings import QuickFocusSettings

if TYPE_CHECKING:
    from zempy.zosapi.tools.protocols.i_optical_system_tools import IOpticalSystemTools
    from zempy.zosapi.tools.protocols.i_system_tool import ISystemTool

class ZeModTools(NativeAdapter["IOpticalSystemTools"]):
    __slots__ = "_active"

    def __init__(self, native: IOpticalSystemTools) -> None:
        super().__init__(native)
        self._active: Optional[ZeModTool] = None

    def _native_get_current(self) -> ISystemTool:
        return self.native.CurrentTool()

    def status(self) -> str:
        return  self.native.Status

    def progress(self) -> int:
        return  self.native.Progress

    def remove_all_variables(self) -> bool:
        return bool(self.native.RemoveAllVariables())

    def get_local_optimization(self) -> ZeModLocalOptimization:
        native_tool = self.native.OpenLocalOptimization()
        local_optimization = validate_cast(native_tool, LocalOptimization)
        return ZeModLocalOptimization(local_optimization)

    def get_batch_ray_tracer(self) -> ZeModBatchRayTrace:
        native_tool = self.native.OpenBatchRayTrace()
        batch_ray_trace = validate_cast(native_tool, BatchRayTrace)
        return ZeModBatchRayTrace(batch_ray_trace)

    def run_quick_focus(
            self,
            settings: QuickFocusSettings,
    ) -> ZeModTool:
        return self.run_tool(ZeModToolList.QUICK_FOCUS, settings)

    def run_local_optimization(
            self,
            settings: LocalOptimizationSettings | None = None,
    ) -> ZeModLocalOptimization:
        if settings is None:
            settings = LocalOptimizationSettings()

        return cast(
            ZeModLocalOptimization,
            self.run_tool(ZeModToolList.LOCAL_OPTIMIZATION, settings),
        )

    @overload
    def run_tool(
        self,
        tool_type: Literal[ZeModToolList.BATCH_RAYTRACE],
        settings: RayTraceSettings,
    ) -> ZeModBatchRayTrace: ...

    @overload
    def run_tool(
        self,
        tool_type: ZeModToolList,
        settings: ZeModToolSettings,
    ) -> ZeModTool: ...

    def run_tool(self, tool_type: ZeModToolList, settings: ZeModToolSettings) -> ZeModTool:
        expected_type = tool_type.settings_type

        if settings is None:
            raise Exception(f"Cannot run tool {tool_type.method_name} without settings")

        if expected_type is not None and not isinstance(settings, expected_type):
            raise TypeError(
                f"Incorrect settings for tool {tool_type.name}: "
                f"expected {expected_type.__name__}, got {type(settings).__name__}"
            )

        open_method = getattr(self.native, tool_type.method_name)

        native_tool = open_method()

        tool_cls = tool_type.tool_cls
        tool = tool_cls(native_tool)

        with tool:
            tool.apply_settings(settings)
            tool.run_wait_for_completion()
            return tool


