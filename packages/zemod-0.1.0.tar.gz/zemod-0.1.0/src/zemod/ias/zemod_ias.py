from __future__ import annotations
from typing import TYPE_CHECKING, Protocol
from zemod.core.native_adapter import NativeAdapter
if TYPE_CHECKING:
    from zempy.zosapi.analysis.ias.protocols.ias_ import IAS_
    from zemod.zemod import ZeMod


class ZeModIASSettings(Protocol):
    def apply_to(self, ias: ZeModIAS, zemod: ZeMod) -> None: ...


class ZeModIAS(NativeAdapter["IAS_"]):
    __slots__ = ()

    def set_field_number(self, n: int) -> None:
        self.native.Field.SetFieldNumber(n)

    def apply_settings(self, settings: ZeModIASSettings, zemod: ZeMod) -> None:
        settings.apply_to(self, zemod)