from __future__ import annotations
from allytools.logger import get_logger
from dataclasses import dataclass
from typing import Optional, cast, TYPE_CHECKING
from zemod.ias.zemod_ias import ZeModIAS, ZeModIASSettings
from zemod.enums.enums import ZeModSampleSizes

if TYPE_CHECKING:
        from zemod.zemod import ZeMod

log = get_logger(__name__)
@dataclass(frozen=True, slots=True)
class ZeModZernikeStandardSettings(ZeModIASSettings):
    """High-level settings wrapper for Zernike Standard Coefficients IAS."""
    name:str
    field_number: Optional[int] = None
    surface_number: Optional[int] = None
    wavelength_number: Optional[int] = None
    sample_size: Optional[ZeModSampleSizes] = None
    reference_obd_to_vertex: Optional[bool] = None
    sx: Optional[float] = None
    sy: Optional[float] = None
    sr: Optional[float] = None
    epsilon: Optional[float] = None
    maximum_number_of_terms: Optional[int] = None

    def apply_to(self, ias: ZeModIAS, zemod: ZeMod) -> None:
        """Apply stored settings to a concrete IAS_ZernikeStandardCoefficients instance."""
        native = ias.native

        # --- standard IAS selectors ---
        if self.field_number is not None:
            log.trace(f"IAS: field_number = {self.field_number}")
            native.Field.SetFieldNumber(self.field_number)

        if self.wavelength_number is not None:
            log.trace(f"IAS: wavelength_number = {self.wavelength_number}")
            native.Wavelength.SetWavelengthNumber(self.wavelength_number)

        if self.surface_number is not None:
            log.trace(f"IAS: surface_number = {self.surface_number}")
            image_surface_n= zemod.lde.image_surfaces_n
            log.trace("zernike settings image surface number changed %s to %s", self.surface_number, image_surface_n)
            native.Surface.SetSurfaceNumber(image_surface_n)

        # --- Zernike Standard coefficients specific ---
        from zempy.zosapi.analyses.zernike_standard.protocols. \
            ias_zernike_standard_coefficients import IAS_ZernikeStandardCoefficients
        native_zernike = cast(IAS_ZernikeStandardCoefficients, native)

        if self.sample_size is not None:
            log.trace(f"IAS: sample_size = {self.sample_size.value}")
            native_zernike.SampleSize = self.sample_size.value

        if self.reference_obd_to_vertex is not None:
            log.trace("IAS: reference_obd_to_vertex = %s",self.reference_obd_to_vertex)
            native_zernike.ReferenceOBDToVertex = bool(self.reference_obd_to_vertex)

        if self.sx is not None:
            log.trace(f"IAS: sx = {self.sx}")
            native_zernike.Sx = float(self.sx)

        if self.sy is not None:
            log.trace(f"IAS: sy = {self.sy}")
            native_zernike.Sy = float(self.sy)

        if self.sr is not None:
            log.trace(f"IAS: sr = {self.sr}")
            native_zernike.Sr = float(self.sr)

        if self.epsilon is not None:
            log.trace(f"IAS: epsilon = {self.epsilon}")
            native_zernike.Epsilon = float(self.epsilon)

        if self.maximum_number_of_terms is not None:
            log.trace("IAS: maximum_number_of_terms = %s",self.maximum_number_of_terms)
            native_zernike.MaximumNumberOfTerms = int(self.maximum_number_of_terms)


    def __str__(self) -> str:
        def fmt(v):
            if hasattr(v, "name"):  # enums
                return v.name
            return v

        lines = []

        if self.field_number is not None:
            lines.append(f"field_number={self.field_number}")

        if self.surface_number is not None:
            lines.append(f"surface_number={self.surface_number}")

        if self.wavelength_number is not None:
            lines.append(f"wavelength_number={self.wavelength_number}")

        if self.sample_size is not None:
            lines.append(f"sample_size={fmt(self.sample_size)}")

        if self.reference_obd_to_vertex is not None:
            lines.append(f"reference_obd_to_vertex={self.reference_obd_to_vertex}")

        if self.sx is not None:
            lines.append(f"sx={self.sx}")

        if self.sy is not None:
            lines.append(f"sy={self.sy}")

        if self.sr is not None:
            lines.append(f"sr={self.sr}")

        if self.epsilon is not None:
            lines.append(f"epsilon={self.epsilon}")

        if self.maximum_number_of_terms is not None:
            lines.append(f"maximum_number_of_terms={self.maximum_number_of_terms}")

        return "\n".join(lines)

    __repr__ = __str__
