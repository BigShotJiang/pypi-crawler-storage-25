from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, cast, TYPE_CHECKING
from allytools.logger import get_logger
from zemod.ias.zemod_ias import ZeModIAS, ZeModIASSettings
from zemod.enums.enums import ZeModPsfSampling, ZeModPsfRotation, ZeModFftPsfType

if TYPE_CHECKING:
        from zemod.zemod import ZeMod

log = get_logger(__name__)
@dataclass(frozen=True, slots=True)
class ZeModFftPsfSettings(ZeModIASSettings):
    name: str
    field_number: Optional[int] = None
    wavelength_number: Optional[int] = None
    surface_number: Optional[int] = None
    sample_size: Optional[ZeModPsfSampling] = None
    output_size: Optional[ZeModPsfSampling] = None
    rotation: Optional[ZeModPsfRotation] = None
    image_delta: Optional[float] = None
    use_polarization: Optional[bool] = None
    normalize: Optional[bool] = None
    psf_type: Optional[ZeModFftPsfType] = None

    def apply_to(self, ias: ZeModIAS, zemod: ZeMod) -> None:
        native = ias.native

        # --- standard IAS ---
        if self.field_number is not None:
            log.trace(f"IAS: field_number = {self.field_number}")
            native.Field.SetFieldNumber(self.field_number)

        if self.wavelength_number is not None:
            log.trace(f"IAS: wavelength_number = {self.wavelength_number}")
            native.Wavelength.SetWavelengthNumber(self.wavelength_number)

        if self.surface_number is not None:
            log.trace(f"IAS: surface_number = {self.surface_number}")
            native.Surface.SetSurfaceNumber(self.surface_number)

        # --- FFT-PSF specific ---
        from zempy.zosapi.analyses.fftpsf.protocols.ias_fft_psf import IAS_FftPsf
        native_psf = cast(IAS_FftPsf, native)

        if self.sample_size is not None:
            log.trace(f"IAS: sample_size = {self.sample_size.value}")
            native_psf.SampleSize = self.sample_size.value

        if self.output_size is not None:
            log.trace(f"IAS: output_size = {self.output_size.value}")
            native_psf.OutputSize = self.output_size.value

        if self.rotation is not None:
            log.trace(f"IAS: rotation = {self.rotation.value}")
            native_psf.Rotation = self.rotation.value

        if self.image_delta is not None:
            log.trace(f"IAS: image_delta = {self.image_delta}")
            native_psf.ImageDelta = float(self.image_delta)

        if self.use_polarization is not None:
            log.trace(f"IAS: use_polarization = {self.use_polarization}")
            native_psf.UsePolarization = bool(self.use_polarization)

        if self.normalize is not None:
            log.trace(f"IAS: normalize = {self.normalize}")
            native_psf.Normalize = bool(self.normalize)

        if self.psf_type is not None:
            log.trace(f"IAS: psf_type = {self.psf_type.value}")
            native_psf.Type = self.psf_type.value

    def __str__(self) -> str:
        def fmt(v):
            if hasattr(v, "name"):  # enums
                return v.name
            return v

        lines = []

        if self.field_number is not None:
            lines.append(f"field_number={self.field_number}")

        if self.wavelength_number is not None:
            lines.append(f"wavelength_number={self.wavelength_number}")

        if self.surface_number is not None:
            lines.append(f"surface_number={self.surface_number}")

        if self.sample_size is not None:
            lines.append(f"sample_size={fmt(self.sample_size)}")

        if self.output_size is not None:
            lines.append(f"output_size={fmt(self.output_size)}")

        if self.rotation is not None:
            lines.append(f"rotation={fmt(self.rotation)}")

        if self.image_delta is not None:
            lines.append(f"image_delta={self.image_delta}")

        if self.use_polarization is not None:
            lines.append(f"use_polarization={self.use_polarization}")

        if self.normalize is not None:
            lines.append(f"normalize={self.normalize}")

        if self.psf_type is not None:
            lines.append(f"psf_type={fmt(self.psf_type)}")

        return "\n".join(lines)

    __repr__ = __str__
