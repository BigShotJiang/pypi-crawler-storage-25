from enum import Enum


class AnalysisResultType(str, Enum):
    GRID = "Data Grid"
    ZERNIKE = "Zernike"
