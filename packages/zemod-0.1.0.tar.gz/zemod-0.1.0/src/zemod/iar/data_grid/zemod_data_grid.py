from __future__ import annotations
from typing import TYPE_CHECKING, cast, Tuple
import numpy as np
from numpy.typing import NDArray
from dimetra.geo import Length
from zemod.core.native_adapter import NativeAdapter
from zemod.iar.data_grid.i_data_grid import IDataGrid
from zemod.iar.grid_meta import GridMeta
from zemod.iar.base.analysis_result_like import AnalysisResultType

if TYPE_CHECKING:
    from zempy.zosapi.analysis.data.protocols.iar_data_grid import IAR_DataGrid
    from zemod.iar.i_grid_meta import IGridMeta


class ZeModDataGrid(NativeAdapter["IAR_DataGrid"], IDataGrid):
    __slots__ = ("_meta",)

    def __init__(self, native: IAR_DataGrid) -> None:
        super().__init__(native)
        self._meta = GridMeta.from_zempy(native)

    @property
    def result_type(self) -> AnalysisResultType:
        return AnalysisResultType.GRID


    @property
    def values(self) -> NDArray[np.float64]:
        return cast(NDArray[np.float64], self.native.Values)

    @property
    def min_x(self) -> Length:
        return self._meta.min_x

    @property
    def min_y(self) -> Length:
        return self._meta.min_y

    @property
    def dx(self) -> Length:
        return self._meta.dx

    @property
    def dy(self) -> Length:
        return self._meta.dy

    @property
    def shape(self) -> Tuple[int, int]:
        ny = int(self.native.Ny)
        nx = int(self.native.Nx)
        return ny, nx

    @property
    def meta(self) -> IGridMeta:
        return self._meta

    @property
    def description(self) -> str:
        return self._meta.description

    @property
    def x_label(self) -> str:
        return self._meta.x_label

    @property
    def y_label(self) -> str:
        return self._meta.y_label

    @property
    def value_label(self) -> str:
        return self._meta.value_label