from __future__ import annotations
import tempfile
from pathlib import Path
from uuid import uuid4
from gosti.zernike.zernike_report import ZernikeReport
from zemod.parser.parsers.zenike import read_zernike_report
from zemod.iar.zemod_iar import ZeModIAR


def zernike_data_from_iar(result: ZeModIAR) -> ZernikeReport:
    temp_file = Path(tempfile.gettempdir()) / f"zemax_zernike_{uuid4().hex}.txt"
    try:
        ok = result.get_test_file(temp_file)
        if not ok:
            raise RuntimeError("GetTextFile(...) returned False")

        return read_zernike_report(temp_file)
    finally:
        temp_file.unlink(missing_ok=True) # delete temp file