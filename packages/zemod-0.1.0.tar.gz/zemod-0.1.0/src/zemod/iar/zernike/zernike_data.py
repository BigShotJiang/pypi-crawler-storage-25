from __future__ import annotations
import numpy as np
from dataclasses import dataclass
from typing import List, Optional, Sequence
from numpy.typing import NDArray
from zemod.iar.base.analysis_result_like import AnalysisResultLike, AnalysisResultType
from zemod.iar.zernike.zernike_meta import ZernikeMeta
from gosti.zernike.zernike_term import ZernikeTerm


@dataclass(frozen=True)
class ZernikeData(AnalysisResultLike[ZernikeMeta]):

    _terms: List[ZernikeTerm]
    _meta: ZernikeMeta

    @property
    def result_type(self) -> AnalysisResultType:
        return AnalysisResultType.ZERNIKE

    @property
    def shape(self) -> tuple[int, ...]:
        return (len(self._terms),)

    @property
    def meta(self) -> ZernikeMeta:
        return self._meta

    @property
    def terms(self) -> List[ZernikeTerm]:
        return self._terms

    @classmethod
    def from_components(
        cls,
        coefficients: Sequence[float] | NDArray[np.float64],
        meta: ZernikeMeta,
        labels: Optional[Sequence[str]] = None,
    ) -> ZernikeData:
        arr = np.asarray(coefficients, dtype=np.float64)
        if arr.ndim != 1:
            raise ValueError(f"ZernikeData.from_components expects 1D coefficients, got shape {arr.shape}")
        n = arr.shape[0]
        if labels is None:
            labels = [""] * n
        elif len(labels) != n:
            raise ValueError(f"len(labels)={len(labels)} must match number of coefficients={n}")
        terms = [
            ZernikeTerm(index=i + 1, coefficient=float(arr[i]), label=labels[i])
            for i in range(n)]
        return cls(_terms=terms, _meta=meta)

    def __str__(self) -> str:
        lines: list[str] = []
        for t in sorted(self._terms, key=lambda x: x.index):
            if abs(t.coefficient) > 0:  # non-zero only
                label = f"  # {t.label}" if t.label else ""
                lines.append(f"Z {t.index:3d} : {t.coefficient: .8f}{label}")
        if not lines:
            return "ZernikeData: (all coefficients are zero)"
        return ("🌀ℤ Zernike Data\n" +
                "────────────────────────────\n" +
                "\n".join(lines))