import re
from typing import Optional

_number_re = re.compile(r"[+-]?\d*\.?\d+(?:[eE][+-]?\d+)?")

def parse_scalar(line: str) -> Optional[float]:
    """
    Extract first float after ':' from a line like:
        'RMS (to chief) : 1.234567 waves'
    """
    if ":" not in line:
        return None
    part = line.split(":", 1)[1]
    m = _number_re.search(part)
    if not m:
        return None
    try:
        return float(m.group())
    except ValueError:
        return None
