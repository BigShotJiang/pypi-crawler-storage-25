from __future__ import annotations
import re
import numpy as np
from pathlib import Path
from allytools.logger import get_logger
from dimetra.geo import Length
from allytools.files import require_file
from dimetra.geo import LengthUnit, make_length
from zemod.parser.read_zemax_text import read_zemax_text
from gosti.scalar2d.scalar_field2d import ScalarField2D
from gosti.psf.psf_build_info import PSFBuildInfo
from gosti.wavelength.wavelength import Wavelength
from gosti.psf.psf import PSF

def _make_length_or_none(value: float | None, token: str | None):
    if value is None or token is None:
        return None
    return make_length(value, token)

def _make_required_length(value: float | None, token: str | None, name: str) -> Length:
    if value is None or token is None:
        raise ValueError(f"Missing {name}")
    length = make_length(value, token)
    if length is None:
        raise ValueError(f"Failed to parse length for {name}: {value} {token}")
    return length

log = get_logger(__name__)
def parse_zemax_fft_psf_text(text: str) -> PSF:
    description: str | None = None
    spacing_value: float | None = None
    spacing_token: str | None = None
    area_value: float | None = None
    area_token: str | None = None
    nx: int | None = None
    ny: int | None = None
    center_row: int | None = None
    center_col: int | None = None
    wavelength_min_val: float | None = None
    wavelength_max_val: float | None = None
    wl_unit_token: str | None = None
    field_x_val: float | None = None
    field_y_val: float | None = None
    field_unit_token: str | None = None
    data_values: list[float] = []
    in_data = False

    text = text.replace("\x00", "")
    for line in text.splitlines():
        line_stripped = line.strip()
        if not in_data:
            if line_stripped.endswith("FFT PSF"):
                description = line_stripped
                continue
            m = re.search(r"([0-9.+\-Ee]+)\s+to\s+([0-9.+\-Ee]+)\s*([^\s]+)\s+at\s+"
                r"([0-9.+\-Ee]+),\s*([0-9.+\-Ee]+)\s*([^\s]+)",line)
            if m:
                wavelength_min_val = float(m.group(1))
                wavelength_max_val = float(m.group(2))
                wl_unit_token = m.group(3).rstrip(".")
                field_x_val = float(m.group(4))
                field_y_val = float(m.group(5))
                field_unit_token = m.group(6).rstrip(".")
                continue

            m = re.search(r"([0-9.+\-Ee]+)\s+to\s+([0-9.+\-Ee]+)\s*([^\s]+)\s+at\s+"
                r"([0-9.+\-Ee]+)\s*([^\s]+)", line)
            if m:
                wavelength_min_val = float(m.group(1))
                wavelength_max_val = float(m.group(2))
                wl_unit_token = m.group(3).rstrip(".")
                field_x_val = 0.0
                field_y_val = float(m.group(4))
                field_unit_token = m.group(5).rstrip(".")
                continue

            m = re.search(r"Data spacing is\s+([0-9.+\-Ee]+)\s*([^\s]+)", line)
            if m:
                spacing_value = float(m.group(1))
                spacing_token = m.group(2).rstrip(".")
                continue

            m = re.search(r"Data area is\s+([0-9.+\-Ee]+)\s*([^\s]+)\s+wide", line)
            if m:
                area_value = float(m.group(1))
                area_token = m.group(2).rstrip(".")
                continue

            m = re.search(r"Image grid size:\s*(\d+)\s*by\s*(\d+)", line)
            if m:
                nx = int(m.group(1))
                ny = int(m.group(2))
                continue

            m = re.search(r"Center point is:\s*row\s*(\d+),\s*column\s*(\d+)",line)
            if m:
                center_row = int(m.group(1))
                center_col = int(m.group(2))
                continue

            if line_stripped.startswith("Values are not normalized"):
                in_data = True
                continue

            continue

        if not line_stripped:
            continue

        for p in line_stripped.split():
            try:
                data_values.append(float(p))
            except ValueError:
                log.warning("Skipping non-numeric token in data: %r", p)

    missing = []
    if spacing_value is None:
        missing.append("spacing_value")
    if spacing_token is None:
        missing.append("spacing_token")
    if area_value is None:
        missing.append("area_value")
    if area_token is None:
        missing.append("area_token")
    if nx is None:
        missing.append("nx")
    if ny is None:
        missing.append("ny")
    if center_row is None:
        missing.append("center_row")
    if center_col is None:
        missing.append("center_col")
    if wavelength_min_val is None:
        missing.append("wavelength_min_val")
    if wavelength_max_val is None:
        missing.append("wavelength_max_val")
    if wl_unit_token is None:
        missing.append("wl_unit_token")
    if field_x_val is None:
        missing.append("field_x_val")
    if field_y_val is None:
        missing.append("field_y_val")
    if field_unit_token is None:
        missing.append("field_unit_token")

    if missing:
        raise ValueError(f"Failed to parse Zemax FFT PSF header. Missing: {', '.join(missing)}")

    data = np.array(data_values, dtype=float)
    if data.size != nx * ny:
        raise ValueError(f"Unexpected number of data points: got {data.size}, expected {nx * ny} (grid {nx}x{ny})")

    psf = data.reshape(ny, nx)
    spacing_len = make_length(spacing_value, spacing_token)
    assert spacing_len is not None
    spacing_mm = spacing_len.to(LengthUnit.MM)
    row0 = center_row - 1
    col0 = center_col - 1
    min_x_mm = -col0 * spacing_mm
    min_y_mm = -row0 * spacing_mm
    min_x=Length(min_x_mm, LengthUnit.MM)
    min_y=Length(min_y_mm, LengthUnit.MM)
    dx=Length(spacing_mm, LengthUnit.MM)
    dy=Length(spacing_mm, LengthUnit.MM)
    area_len = _make_required_length(area_value, area_token, "area")
    wl_min_len = _make_required_length(wavelength_min_val, wl_unit_token, "wavelength_min")
    wl_max_len = _make_required_length(wavelength_max_val, wl_unit_token, "wavelength_max")
    field_x_len = _make_required_length(field_x_val, field_unit_token, "field_x")
    field_y_len = _make_required_length(field_y_val, field_unit_token, "field_y")
    scalar2d = ScalarField2D(values=np.asarray(psf, dtype=np.float64), min_x=min_x, min_y=min_y, dx=dx, dy=dy)
    build_info = PSFBuildInfo(
        description=description or "from zemax file parser",
        area = area_len,
        nx=nx,
        ny=ny,
        center_col=center_col,
        center_row=center_row,
        field_x=field_x_len,
        field_y=field_y_len,
        wavelength_min=Wavelength(wl_min_len),
        wavelength_max=Wavelength(wl_max_len))
    return PSF(scalar2d=scalar2d, field_x=field_x_len, field_y=field_y_len, build_info=build_info)

def read_zemax_fft_psf(path: Path):
    require_file(path=path)
    text = read_zemax_text(path)
    return parse_zemax_fft_psf_text(text)