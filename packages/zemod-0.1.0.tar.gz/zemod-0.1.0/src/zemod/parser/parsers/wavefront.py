from __future__ import annotations

import re
from pathlib import Path

import numpy as np

from gosti.zemax.read_zemax_text import read_zemax_text


_FLOAT_RE = re.compile(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][-+]?\d+)?")


def parse_zemax_wavefront_map_text(text: str) -> tuple[np.ndarray, dict[str, int | float | str]]:
    """
    Parse Zemax text export: 'Listing of Wavefront Map Data'.

    Returns
    -------
    wavefront : ndarray, shape (ny, nx)
        Wavefront map in waves.
    meta : dict
        Parsed header fields.
    """
    text = text.replace("\x00", "")
    lines = text.splitlines()

    nx: int | None = None
    ny: int | None = None
    center_col: int | None = None
    center_row: int | None = None
    wavelength: float | None = None
    wavelength_unit: str | None = None
    field_x: float | None = None
    field_y: float | None = None
    field_unit: str | None = None
    pv: float | None = None
    rms: float | None = None

    data_start_idx: int | None = None

    for i, raw in enumerate(lines):
        line = raw.strip()
        if not line:
            continue

        m = re.search(
            r"Wavefront Function\s*$",
            line,
        )
        if m:
            continue

        m = re.search(
            r"([0-9.+\-Ee]+)\s*([^\s]+)\s+at\s+([0-9.+\-Ee]+),\s*([0-9.+\-Ee]+)\s*([^\s]+)",
            line,
        )
        if m:
            wavelength = float(m.group(1))
            wavelength_unit = m.group(2).rstrip(".")
            field_x = float(m.group(3))
            field_y = float(m.group(4))
            field_unit = m.group(5).rstrip(".")
            continue

        m = re.search(
            r"Peak to valley\s*=\s*([0-9.+\-Ee]+)\s+waves,\s*RMS\s*=\s*([0-9.+\-Ee]+)\s+waves",
            line,
        )
        if m:
            pv = float(m.group(1))
            rms = float(m.group(2))
            continue

        m = re.search(r"Pupil grid size:\s*(\d+)\s*by\s*(\d+)", line)
        if m:
            nx = int(m.group(1))
            ny = int(m.group(2))
            continue

        m = re.search(r"Center point is:\s*Col\s*(\d+),\s*Row\s*(\d+)", line, flags=re.IGNORECASE)
        if m:
            center_col = int(m.group(1))
            center_row = int(m.group(2))
            data_start_idx = i + 1
            break

    missing = []
    if nx is None:
        missing.append("nx")
    if ny is None:
        missing.append("ny")
    if center_col is None:
        missing.append("center_col")
    if center_row is None:
        missing.append("center_row")
    if wavelength is None:
        missing.append("wavelength")
    if wavelength_unit is None:
        missing.append("wavelength_unit")
    if field_x is None:
        missing.append("field_x")
    if field_y is None:
        missing.append("field_y")
    if field_unit is None:
        missing.append("field_unit")
    if pv is None:
        missing.append("pv")
    if rms is None:
        missing.append("rms")
    if data_start_idx is None:
        missing.append("data_start_idx")

    if missing:
        raise ValueError(
            "Failed to parse Zemax Wavefront Map header. "
            f"Missing: {', '.join(missing)}"
        )

    values: list[float] = []
    for raw in lines[data_start_idx:]:
        nums = _FLOAT_RE.findall(raw)
        if not nums:
            continue
        values.extend(float(v) for v in nums)

    expected = nx * ny
    if len(values) != expected:
        raise ValueError(
            f"Unexpected number of data points: got {len(values)}, expected {expected} "
            f"(grid {nx}x{ny})"
        )

    wavefront = np.array(values, dtype=np.float64).reshape(ny, nx)

    meta = {
        "nx": nx,
        "ny": ny,
        "center_col": center_col,
        "center_row": center_row,
        "wavelength": wavelength,
        "wavelength_unit": wavelength_unit,
        "field_x": field_x,
        "field_y": field_y,
        "field_unit": field_unit,
        "pv": pv,
        "rms": rms,
    }
    return wavefront, meta


def read_zemax_wavefront_map(path: str | Path) -> tuple[np.ndarray, dict[str, int | float | str]]:
    path = Path(path)
    text = read_zemax_text(path)
    return parse_zemax_wavefront_map_text(text)