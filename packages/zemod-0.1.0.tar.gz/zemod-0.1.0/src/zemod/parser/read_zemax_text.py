from __future__ import annotations
from pathlib import Path
from allytools.files import require_file

DEFAULT_ZEMAX_TEXT_ENCODINGS: tuple[str, ...] = ("utf-16", "utf-8-sig", "utf-8")


def read_zemax_text(
    path: Path,
    *,
    suffixes: tuple[str, ...] = (".txt", ".dat"),
    encodings: tuple[str, ...] = DEFAULT_ZEMAX_TEXT_ENCODINGS,
    strip_nuls: bool = True,
) -> str:
    """
    Read a Zemax text export from file and return decoded text.

    Tries common Zemax-related encodings in order.
    """
    require_file(path=path, suffixes=suffixes)

    last_error: UnicodeError | None = None

    for encoding in encodings:
        try:
            text = path.read_text(encoding=encoding)
            return text.replace("\x00", "") if strip_nuls else text
        except UnicodeError as ex:
            last_error = ex

    raise ValueError(f"Failed to decode Zemax text file: {path}") from last_error