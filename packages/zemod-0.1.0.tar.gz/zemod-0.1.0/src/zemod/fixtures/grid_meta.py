from __future__ import annotations
import pytest
from dimetra.geo import Length, LengthUnit
from zemod.iar.grid_meta import GridMeta


@pytest.fixture
def grid_meta_demo() -> GridMeta:
    return GridMeta(
        _min_x=Length(0.0, LengthUnit.UM),
        _min_y=Length(1.0, LengthUnit.UM),
        _dx=Length(2.0, LengthUnit.UM),
        _dy=Length(3.0, LengthUnit.UM),
        _description="demo grid",
        _x_label="x",
        _y_label="y",
        _value_label="value",
    )