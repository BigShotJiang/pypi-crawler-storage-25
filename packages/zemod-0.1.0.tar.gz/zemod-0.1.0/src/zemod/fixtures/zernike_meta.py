from __future__ import annotations
import pytest
from zemod.iar.zernike.zernike_meta import ZernikeMeta


@pytest.fixture
def zernike_meta_demo() -> ZernikeMeta:
    return ZernikeMeta(
        pv_to_chief=1.0,
        pv_to_centroid=1.1,
        rms_to_chief_rays=0.10,
        rms_to_centroid_rays=0.11,
        rms_to_chief_fit=0.20,
        rms_to_centroid_fit=0.21,
        variance_rays=0.30,
        variance_fit=0.31,
        strehl_rays=0.90,
        strehl_fit=0.91,
        rms_fit_error=0.01,
        max_fit_error=0.02,
    )