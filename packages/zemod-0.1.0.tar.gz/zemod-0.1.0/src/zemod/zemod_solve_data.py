from __future__ import annotations

from typing import TYPE_CHECKING

from zemod.core.native_adapter import NativeAdapter
from zempy.zosapi.editors.enums.solve_type import SolveType

if TYPE_CHECKING:
    from zempy.zosapi.editors.adapters.solve_data import SolveData


class ZeModSolveData(NativeAdapter["SolveData"]):
    __slots__ = ()

    @property
    def is_valid(self) -> bool:
        return bool(self.native.IsValid)

    @property
    def type(self) -> SolveType:
        return self.native.Type

    @property
    def f_number(self) -> float:
        return float(self.native._S_FNumber.FNumber)

    @f_number.setter
    def f_number(self, value: float) -> None:
        self.native._S_FNumber.FNumber = float(value)