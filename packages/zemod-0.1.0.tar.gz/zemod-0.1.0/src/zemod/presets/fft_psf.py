from zemod.ias.zemode_fftpsf_settings import ZeModFftPsfSettings
from zemod.enums.enums import ZeModPsfRotation, ZeModFftPsfType, ZeModPsfSampling

fft_psf = ZeModFftPsfSettings(
    name = "fft_psf_128x128_256x256_im0",
    field_number=1,
    wavelength_number=1,
    surface_number=0,
    sample_size=ZeModPsfSampling.PsfS_128x128,
    output_size=ZeModPsfSampling.PsfS_256x256,
    rotation=ZeModPsfRotation.CW0,
    image_delta=0,
    use_polarization=False,
    normalize=False,
    psf_type=ZeModFftPsfType.Linear)


fft_psf_delta_04 = ZeModFftPsfSettings(
    name = "fft_psf_128x128_256x256_im04",
    field_number=1,
    wavelength_number=1,
    surface_number=0,
    sample_size=ZeModPsfSampling.PsfS_128x128,
    output_size=ZeModPsfSampling.PsfS_256x256,
    rotation=ZeModPsfRotation.CW0,
    image_delta=0.4,
    use_polarization=False,
    normalize=False,
    psf_type=ZeModFftPsfType.Linear)