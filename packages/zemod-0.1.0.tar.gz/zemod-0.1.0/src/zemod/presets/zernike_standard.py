from zemod.ias.zemod_zernike_standard import ZeModZernikeStandardSettings
from zemod.enums.enums import ZeModSampleSizes

zernike_standard_37 = ZeModZernikeStandardSettings(
    name="zernike_standard_128x128_37",
    field_number=1,
    wavelength_number=1,
    surface_number=1,
    sample_size=ZeModSampleSizes.S_128x128,
    reference_obd_to_vertex=False,
    sx=0,
    sy=0,
    sr=0,
    maximum_number_of_terms=37)
