from __future__ import annotations
from dataclasses import dataclass
from typing import Any
from gosti.ray.ray_sample_like import RaySampleLike
from gosti.ray.ray_3d import Ray3D


@dataclass(frozen=True, slots=True)
class TracedSampleRay:
    sample: RaySampleLike
    ray: Any
    surface_number: int
    ray_number: int
    input_ray: Ray3D | None = None