from __future__ import annotations
from dataclasses import fields, is_dataclass
from types import SimpleNamespace
from typing import Any, Generic, Iterable, Iterator, Sequence, TypeVar
import importlib

import numpy as np

T_Ray = TypeVar("T_Ray")


def _is_numeric_value(v: Any) -> bool:
    return isinstance(v, (int, float, np.integer, np.floating))


def _field_names_from_item(item: Any) -> tuple[str, ...]:
    if is_dataclass(item):
        names = tuple(f.name for f in fields(item) if _is_numeric_value(getattr(item, f.name)))
        if names:
            return names

    if hasattr(item, "__dict__"):
        names = tuple(k for k, v in vars(item).items() if _is_numeric_value(v))
        if names:
            return names

    slots = getattr(item, "__slots__", None)
    if slots:
        if isinstance(slots, str):
            slots = (slots,)
        names = tuple(k for k in slots if hasattr(item, k) and _is_numeric_value(getattr(item, k)))
        if names:
            return names

    raise ValueError(f"Could not infer numeric fields from ray object of type {type(item)!r}")


def _resolve_type(module_name: str | None, type_name: str | None) -> type[Any] | None:
    if not module_name or not type_name:
        return None
    try:
        mod = importlib.import_module(module_name)
        obj = getattr(mod, type_name, None)
        return obj if isinstance(obj, type) else None
    except Exception:
        return None


class Rays(Sequence[T_Ray], Generic[T_Ray]):
    def __init__(self, items: Iterable[T_Ray], *, ray_type: type[T_Ray] | None = None, field_names: Iterable[str] | None = None) -> None:
        self._items = list(items)

        inferred_type: type[Any] | None = ray_type
        if inferred_type is None and self._items:
            inferred_type = type(self._items[0])

        self._ray_type: type[Any] | None = inferred_type

        if field_names is None:
            if self._items:
                self._field_names = _field_names_from_item(self._items[0])
            else:
                self._field_names = ()
        else:
            self._field_names = tuple(field_names)

    def __len__(self) -> int:
        return len(self._items)

    def __getitem__(self, index: int) -> T_Ray:
        return self._items[index]

    def __iter__(self) -> Iterator[T_Ray]:
        return iter(self._items)

    @property
    def n(self) -> int:
        return len(self._items)

    @property
    def is_empty(self) -> bool:
        return not self._items

    @property
    def ray_type(self) -> type[T_Ray] | None:
        return self._ray_type

    @property
    def type_name(self) -> str:
        return self._ray_type.__name__ if self._ray_type is not None else "UnknownRay"

    @property
    def type_module(self) -> str | None:
        return None if self._ray_type is None else self._ray_type.__module__

    @property
    def field_names(self) -> tuple[str, ...]:
        return self._field_names

    def first(self) -> T_Ray:
        if not self._items:
            raise IndexError("Rays is empty")
        return self._items[0]

    def to_list(self) -> list[T_Ray]:
        return list(self._items)

    def flat(self, attr: str) -> np.ndarray:
        return np.asarray([getattr(r, attr) for r in self._items], dtype=float)

    def vectors_flat(self, *attrs: str) -> dict[str, np.ndarray]:
        return {a: self.flat(a) for a in attrs}

    def as_struct_flat(self, attrs: Iterable[str]) -> dict[str, np.ndarray]:
        return self.vectors_flat(*tuple(attrs))

    def values_matrix(self) -> np.ndarray:
        names = self._field_names
        if not names:
            if self._items:
                raise ValueError("field_names is empty for non-empty Rays")
            return np.empty((0, 0), dtype=float)
        if not self._items:
            return np.empty((0, len(names)), dtype=float)
        data = [[float(getattr(r, f)) for f in names] for r in self._items]
        return np.asarray(data, dtype=float)

    @classmethod
    def from_records(
        cls,
        items: Iterable[T_Ray],
        *,
        ray_type: type[T_Ray] | None = None,
        field_names: Iterable[str] | None = None,
    ) -> Rays[T_Ray]:
        return cls(items, ray_type=ray_type, field_names=field_names)

    @classmethod
    def from_matrix(
        cls,
        values: np.ndarray,
        *,
        field_names: Sequence[str],
        ray_type: type[T_Ray] | None = None,
    ) -> Rays[Any]:
        values = np.asarray(values, dtype=float)

        if values.ndim != 2:
            raise ValueError(f"values must be 2D, got shape={values.shape}")
        if values.shape[1] != len(field_names):
            raise ValueError(f"values columns ({values.shape[1]}) != len(field_names) ({len(field_names)})")
        items: list[Any] = []

        for row in values:
            payload = {k: float(v) for k, v in zip(field_names, row)}

            if ray_type is not None and is_dataclass(ray_type):
                items.append(ray_type(**payload))
            else:
                items.append(SimpleNamespace(**payload))

        return cls(items, ray_type=ray_type, field_names=field_names)

    @classmethod
    def from_h5_payload(
        cls,
        *,
        values: np.ndarray,
        field_names: Sequence[str],
        type_module: str | None,
        type_name: str | None,
    ) -> Rays[Any]:
        ray_type = _resolve_type(type_module, type_name)
        return cls.from_matrix(values, field_names=field_names, ray_type=ray_type)

    def __str__(self) -> str:
        fields_txt = ", ".join(self._field_names) if self._field_names else "–"
        return f"Rays(type={self.type_name}, n={self.n}, fields=[{fields_txt}])"