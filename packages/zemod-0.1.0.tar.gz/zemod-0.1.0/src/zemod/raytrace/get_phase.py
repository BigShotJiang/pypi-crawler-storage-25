from __future__ import annotations
from gosti.polarization.input_polarization import InputPolarization
from zemod.raytrace.aliases import FieldComp
from zempy.zosapi.tools.raytrace.enums import RaysType
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from zemod.tools.zemod_batch_raytrace import ZeModBatchRayTrace


def get_phase_components(
    *,
    zemod_tool: ZeModBatchRayTrace,
    l: float,
    m: float,
    n: float,
    pol: InputPolarization,
) -> FieldComp:
    return zemod_tool.get_phase(
        l=l,
        m=m,
        n=n,
        jx=pol.jx,
        jy=pol.jy,
        x_phase_deg=pol.x_phase_deg,
        y_phase_deg=pol.y_phase_deg,
        intensity=pol.intensity,
    )


def get_norm_phase_components(
    *,
    zemod_tool: ZeModBatchRayTrace,
    wave_number: int,
    rays_type: RaysType,
    hx: float,
    hy: float,
    px: float,
    py: float,
    pol: InputPolarization,
) -> FieldComp:
    ok, _x, _y, _z, l, m, n = zemod_tool.get_direct_field_coordinates(
        wave_number=wave_number,
        ray_type=rays_type,
        hx=hx,
        hy=hy,
        px=px,
        py=py,
    )

    if not ok:
        raise RuntimeError("GetDirectFieldCoordinates failed")

    return get_phase_components(
        zemod_tool=zemod_tool,
        l=l,
        m=m,
        n=n,
        pol=pol,
    )