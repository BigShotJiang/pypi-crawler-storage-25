from __future__ import annotations
from typing import TYPE_CHECKING
from zemod.raytrace.traced_sample_ray import TracedSampleRay
from zemod.raytrace.recipe import Recipe
from zemod.raytrace.build_ray import build_ray

if TYPE_CHECKING:
    from zemod.tools.zemod_batch_raytrace import ZeModBatchRayTrace
    from zemod.raytrace.raytrace_settings import RayTraceSettings

def raytrace_batch(*, zemod_tool: ZeModBatchRayTrace, settings: RayTraceSettings, recipe: Recipe) -> list[TracedSampleRay]:
    if recipe.create is None or recipe.add_one is None or recipe.read_next is None:
        raise RuntimeError(f"Recipe for {settings.method} does not support BATCH mode")
    sample_coordinates = list(recipe.sample_iter())  # [RaySampleLike, CoordTuple]
    batch_data = recipe.create()
    batch_data.ClearData()
    for _, coords in sample_coordinates:
        recipe.add_one(batch_data, coords)
    zemod_tool.run_and_wait_for_completion()
    batch_data.StartReadingResults()
    out: list[TracedSampleRay] = []
    ray_cls = recipe.ray_class
    end_surface = settings.require_current_end_surface_number()
    for ray_number, (sample, coords) in enumerate(sample_coordinates):
        rec = recipe.read_next(batch_data)
        ray = build_ray(ray_cls, rec)
        input_ray = coords.to_input_ray(zemod_tool=zemod_tool, wave_number=settings.wave_number, rays_type=settings.rays_type)
        out.append(TracedSampleRay(sample=sample, ray=ray, surface_number=end_surface, ray_number=ray_number, input_ray=input_ray))
    return out