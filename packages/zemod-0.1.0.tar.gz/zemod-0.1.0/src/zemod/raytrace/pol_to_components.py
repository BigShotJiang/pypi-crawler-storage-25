import  math
from zemod.raytrace.aliases import ZemaxPol, FieldComp
from geopto.primitives.unit_vector3d import UnitVector3D
from gosti.polarization.input_polarization import InputPolarization

def pol_to_components(pol: ZemaxPol) -> FieldComp:

    Ex, Ey, phaX_deg, phaY_deg = pol
    phiX = math.radians(phaX_deg)
    phiY = math.radians(phaY_deg)

    return (
        Ex * math.cos(phiX),
        Ex * math.sin(phiX),
        Ey * math.cos(phiY),
        Ey * math.sin(phiY),
        0.0,
        0.0,
    )




def pol_to_components_for_direction(
    pol: InputPolarization,
    direction: UnitVector3D,
) -> FieldComp:
    e = pol.to_electric_field(direction)

    return (
        e.ex.real,
        e.ex.imag,
        e.ey.real,
        e.ey.imag,
        e.ez.real,
        e.ez.imag,
    )