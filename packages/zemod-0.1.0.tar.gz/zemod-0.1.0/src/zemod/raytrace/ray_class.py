from typing import overload, Literal, Type
from zempy.zosapi.tools.raytrace.results import Ray
from zempy.zosapi.tools.raytrace.results.ray_norm_polarized import RayNormPolarized
from zempy.zosapi.tools.raytrace.results.ray_norm_polarized_full import RayNormPolarizedFull
from zempy.zosapi.tools.raytrace.results.ray_direct_polarized import RayDirectPolarized
from zempy.zosapi.tools.raytrace.results.ray_direct_polarized_full import RayDirectPolarizedFull
from zempy.zosapi.tools.raytrace.results.ray_direct_unpolarized import RayDirectUnpolarized
from zempy.zosapi.tools.raytrace.results.ray_norm_unpolarized import RayNormUnpolarized
from zemod.raytrace.trace_method import TraceMethod


RAY_CLASS_BY_METHOD: dict[TraceMethod, Type[Ray]] = {
    TraceMethod.Normal_Unpolarized: RayNormUnpolarized,
    TraceMethod.Direct_Unpolarized: RayDirectUnpolarized,
    TraceMethod.Normal_Polarized: RayNormPolarized,
    TraceMethod.Direct_Polarized: RayDirectPolarized,
    TraceMethod.Normal_Polarized_Full: RayNormPolarizedFull,
    TraceMethod.Direct_Polarized_Full: RayDirectPolarizedFull,
}

@overload
def ray_class_of(
    method: Literal[TraceMethod.Normal_Unpolarized],
) -> Type[RayNormUnpolarized]: ...
@overload
def ray_class_of(
    method: Literal[TraceMethod.Direct_Unpolarized],
) -> Type[RayDirectUnpolarized]: ...
@overload
def ray_class_of(
    method: Literal[TraceMethod.Normal_Polarized],
) -> Type[RayNormPolarized]: ...
@overload
def ray_class_of(
    method: Literal[TraceMethod.Direct_Polarized],
) -> Type[RayDirectPolarized]: ...
@overload
def ray_class_of(
    method: Literal[TraceMethod.Normal_Polarized_Full],
) -> Type[RayNormPolarizedFull]: ...
@overload
def ray_class_of(
    method: Literal[TraceMethod.Direct_Polarized_Full],
) -> Type[RayDirectPolarizedFull]: ...


def ray_class_of(method: TraceMethod) -> Type[Ray]:
    return RAY_CLASS_BY_METHOD[method]
