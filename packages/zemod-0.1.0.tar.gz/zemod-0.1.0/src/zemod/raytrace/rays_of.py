from __future__ import annotations
from typing import overload, Literal, cast
from zempy.zosapi.tools.raytrace.results import Ray
from zempy.zosapi.tools.raytrace.results.ray_norm_unpolarized import RayNormUnpolarized
from zempy.zosapi.tools.raytrace.results.ray_norm_polarized import RayNormPolarized
from zempy.zosapi.tools.raytrace.results.ray_norm_polarized_full import RayNormPolarizedFull
from zempy.zosapi.tools.raytrace.results.ray_direct_polarized import RayDirectPolarized
from zempy.zosapi.tools.raytrace.results.ray_direct_polarized_full import RayDirectPolarizedFull
from zempy.zosapi.tools.raytrace.results.ray_direct_unpolarized import RayDirectUnpolarized
from zemod.raytrace.trace_method import TraceMethod
from zemod.raytrace.ray_class import ray_class_of

@overload
def rays_of(
    method: Literal[TraceMethod.Normal_Unpolarized],
    rays: list[Ray],
) -> list[RayNormUnpolarized]: ...
@overload
def rays_of(
    method: Literal[TraceMethod.Direct_Unpolarized],
    rays: list[Ray],
) -> list[RayDirectUnpolarized]: ...
@overload
def rays_of(
    method: Literal[TraceMethod.Normal_Polarized],
    rays: list[Ray],
) -> list[RayNormPolarized]: ...
@overload
def rays_of(
    method: Literal[TraceMethod.Direct_Polarized],
    rays: list[Ray],
) -> list[RayDirectPolarized]: ...
@overload
def rays_of(
    method: Literal[TraceMethod.Normal_Polarized_Full],
    rays: list[Ray],
) -> list[RayNormPolarizedFull]: ...
@overload
def rays_of(
    method: Literal[TraceMethod.Direct_Polarized_Full],
    rays: list[Ray],
) -> list[RayDirectPolarizedFull]: ...


def rays_of(method: TraceMethod, rays: list[Ray]) -> list[Ray]:
    cls = ray_class_of(method)
    assert all(isinstance(r, cls) for r in rays), (
        f"Ray list does not match method={method}. "
        f"Expected instances of {cls.__name__}."
    )
    return cast(list[Ray], rays)
