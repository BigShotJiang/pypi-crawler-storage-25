from allytools.logger import get_logger
from typing import Any

log = get_logger(__name__)
def ray_accept_default(rec: Any) -> bool:
    ok = getattr(rec, "ok", True)
    error_code = getattr(rec, "errorCode", 0)
    vignette_code = getattr(rec, "vignetteCode", 0)

    if ok and error_code == 0 and vignette_code == 0:
        return True

    X = getattr(rec, "X", None)
    Y = getattr(rec, "Y", None)
    Z = getattr(rec, "Z", None)
    L = getattr(rec, "L", None)
    M = getattr(rec, "M", None)
    N = getattr(rec, "N", None)

    log.debug(
        "accept_default: REJECTED | ok=%r errorCode=%r vignetteCode=%r "
        "| X=%s Y=%s Z=%s L=%s M=%s N=%s | rec_type=%s",
        ok,
        error_code,
        vignette_code,
        _fmt6(X),
        _fmt6(Y),
        _fmt6(Z),
        _fmt6(L),
        _fmt6(M),
        _fmt6(N),
        type(rec).__name__,
    )

    return False


def ray_accept_strict(rec: Any) -> bool:
    assert hasattr(rec, "ok"), "record has no 'ok'"
    assert hasattr(rec, "errorCode"), "record has no 'errorCode'"
    return rec.ok and rec.errorCode == 0 and getattr(rec, "vignetteCode", 0) == 0

def _fmt6(v: object) -> str:
    try:
        return f"{float(v):.6f}"
    except (TypeError, ValueError):
        return repr(v)