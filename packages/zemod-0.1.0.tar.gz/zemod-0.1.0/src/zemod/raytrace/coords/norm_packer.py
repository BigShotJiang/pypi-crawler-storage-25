from __future__ import annotations
from dataclasses import dataclass
from gosti.ray.ray_sample_like import RaySampleLike
from zemod.raytrace.coords import NormCoord

@dataclass(frozen=True, slots=True)
class NormPacker:
    def pack(self, rc: RaySampleLike) -> NormCoord:
        return NormCoord(
            hx=float(rc.norm_field.hx),
            hy=float(rc.norm_field.hy),
            px=float(rc.norm_pupil.px),
            py=float(rc.norm_pupil.py),
        )