from __future__ import annotations
from dataclasses import dataclass
from typing import TYPE_CHECKING
from gosti.ray.ray_3d import Ray3D
from zempy.zosapi.tools.raytrace.enums import RaysType

if TYPE_CHECKING:
    from zemod.tools.zemod_batch_raytrace import ZeModBatchRayTrace

@dataclass(frozen=True, slots=True)
class DirectCoord:
    x: float
    y: float
    z: float
    l: float
    m: float
    n: float

    def to_input_ray(self, *, zemod_tool: ZeModBatchRayTrace, wave_number: int, rays_type: RaysType) -> Ray3D:
        return Ray3D.from_xyz_lmn(
            x_mm=self.x,
            y_mm=self.y,
            z_mm=self.z,
            l=self.l,
            m=self.m,
            n=self.n)

    def as_zemax_tuple(self) -> tuple[float, float, float, float, float, float]:
        return self.x, self.y, self.z, self.l, self.m, self.n