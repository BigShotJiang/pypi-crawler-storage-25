from __future__ import annotations
from dataclasses import dataclass
from typing import TYPE_CHECKING
from gosti.ray.ray_sample_like import RaySampleLike
from zempy.zosapi.tools.raytrace.enums import RaysType
from zemod.raytrace.coords import DirectCoord
if TYPE_CHECKING:
    from zemod.tools.zemod_batch_raytrace import ZeModBatchRayTrace


@dataclass(frozen=True, slots=True)
class DirectPacker:
    zemod_batch_raytrace: ZeModBatchRayTrace
    wave_number: int
    rays_type: RaysType

    def pack(self, rc: RaySampleLike) -> DirectCoord:
        ok, x, y, z, l, m, n = self.zemod_batch_raytrace.get_direct_field_coordinates(
            wave_number=self.wave_number,
            ray_type=self.rays_type,
            hx=float(rc.norm_field.hx),
            hy=float(rc.norm_field.hy),
            px=float(rc.norm_pupil.px),
            py=float(rc.norm_pupil.py))
        return DirectCoord(x=x, y=y, z=z, l=l, m=m, n=n)