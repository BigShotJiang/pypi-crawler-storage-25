from __future__ import annotations
from typing import Protocol, TYPE_CHECKING
from gosti.ray.ray_3d import Ray3D
from zempy.zosapi.tools.raytrace.enums import RaysType

if TYPE_CHECKING:
    from zemod.tools.zemod_batch_raytrace import ZeModBatchRayTrace

class RayTraceCoord(Protocol):
    def to_input_ray(self, *, zemod_tool: ZeModBatchRayTrace, wave_number: int, rays_type: RaysType) -> Ray3D:
        ...


