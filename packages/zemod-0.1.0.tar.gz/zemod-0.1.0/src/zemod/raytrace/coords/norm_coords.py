from __future__ import annotations
from dataclasses import dataclass
from typing import TYPE_CHECKING
from gosti.ray.ray_3d import Ray3D
from zempy.zosapi.tools.raytrace.enums import RaysType

if TYPE_CHECKING:
    from zemod.tools.zemod_batch_raytrace import ZeModBatchRayTrace

@dataclass(frozen=True, slots=True)
class NormCoord:
    hx: float
    hy: float
    px: float
    py: float

    def to_input_ray(self, *, zemod_tool: ZeModBatchRayTrace, wave_number: int, rays_type: RaysType) -> Ray3D:
        ok, x, y, z, l, m, n = zemod_tool.get_direct_field_coordinates(
            wave_number=wave_number,
            ray_type=rays_type,
            hx=self.hx,
            hy=self.hy,
            px=self.px,
            py=self.py)
        if not ok:
            raise RuntimeError("GetDirectFieldCoordinates failed")
        return Ray3D.from_xyz_lmn(x_mm=x, y_mm=y, z_mm=z, l=l, m=m, n=n)

    def as_zemax_tuple(self) -> tuple[float, float, float, float]:
        return self.hx, self.hy, self.px, self.py