from zemod.raytrace.trace_method import TraceMethod
from gosti.grid import FieldGridRectangle, PupilGridCircle, OnAxisPupil, FieldGridRadial,FieldRectangleMaxX,FieldOnAxis, FieldRectangleMaxXY
from zemod.raytrace.raytrace_settings import RayTraceSettings
from zemod.raytrace.ray_trace_mode import RayTraceMode
from zempy.zosapi.tools.raytrace.enums import OPDMode, RaysType
from gosti.polarization.input_polarization import InputPolarization

opd_radial = RayTraceSettings(
    name="opd_grid_unpolarized_pupil_64x64",
    rays_type=RaysType.Real,
    method=TraceMethod.Normal_Unpolarized,
    wave_number=1,
    field_grid=FieldRectangleMaxX(),
    pupil_grid=PupilGridCircle(64,64),
    raytrace_mode=RayTraceMode.BATCH)

opd_grid = RayTraceSettings(
    name="opd_grid_unpolarized_pupil_64x64",
    rays_type=RaysType.Real,
    method=TraceMethod.Normal_Unpolarized,
    wave_number=1,
    field_grid=FieldRectangleMaxXY(),
    pupil_grid=PupilGridCircle(16,16),
    raytrace_mode=RayTraceMode.BATCH,
    opd=OPDMode.CurrentAndChief)


opd_single = RayTraceSettings(
    name="opd_single_unpolarized_16x16",
    rays_type=RaysType.Real,
    method=TraceMethod.Normal_Unpolarized,
    wave_number=1,
    field_grid=FieldGridRectangle(16,16),
    pupil_grid=PupilGridCircle(16,16),
    raytrace_mode=RayTraceMode.BATCH,
    opd=OPDMode.CurrentAndChief)


chief_sensor = RayTraceSettings(
    name="chief_sensor",
    rays_type=RaysType.Real,
    method=TraceMethod.Normal_Unpolarized,
    wave_number=1,
    use_sensor_grid=True,
    pupil_grid=OnAxisPupil(),
    raytrace_mode=RayTraceMode.BATCH)

batch_sensor_polarized = RayTraceSettings(
    name="tbd",
    rays_type=RaysType.Real,
    method=TraceMethod.Normal_Polarized_Full,
    wave_number=1,
    pupil_grid=PupilGridCircle(16,16),
    raytrace_mode=RayTraceMode.BATCH,
    pol=InputPolarization(1,0,0,0))


single_unpolarized = RayTraceSettings(
    name="SingleUnpolarized",
    method=TraceMethod.Normal_Unpolarized,
    rays_type=RaysType.Real,
    wave_number=1,
    raytrace_mode=RayTraceMode.SINGLE)