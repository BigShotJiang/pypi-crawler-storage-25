from __future__ import annotations
from dataclasses import fields, is_dataclass
from typing import Any, Dict, Type
from zemod.raytrace.aliases import T_Ray


def build_ray(ray_cls: Type[T_Ray], rec: Any) -> T_Ray:
    if not is_dataclass(ray_cls):
        raise TypeError(f"{ray_cls!r} must be a dataclass")
    data: Dict[str, Any] = {}
    for f in fields(ray_cls):
        try:
            data[f.name] = getattr(rec, f.name)
        except AttributeError as e:
            raise AttributeError(f"Record missing attribute '{f.name}' for {ray_cls.__name__}") from e
    return ray_cls(**data)  # type: ignore[arg-type]