from __future__ import annotations

from dataclasses import dataclass, replace

from allytools.logger import get_logger
from gosti.grid.field_grid_like import FieldGridLike
from gosti.grid.field_grid_rectangle import FieldGridRectangle
from gosti.grid.pupil_grid_like import PupilGridLike
from gosti.ray.ray_grid import RayGrid
from gosti.ray.ray_grid_like import RayGridLike
from gosti.ray.ray_sample import RaySample
from gosti.polarization.input_polarization import InputPolarization
from zemod.raytrace.aliases import Grid2D
from zemod.raytrace.ray_trace_mode import RayTraceMode
from zemod.raytrace.trace_method import TraceMethod
from zempy.zosapi.tools.raytrace.enums import OPDMode, RaysType

log = get_logger(__name__)


@dataclass(frozen=True, slots=True)
class RayTraceSettings:
    name: str
    rays_type: RaysType
    method: TraceMethod
    wave_number: int
    raytrace_mode: RayTraceMode
    surface_numbers: tuple[int, ...] | None = None
    current_end_surface_number: int | None = None
    current_start_surface_number: int | None = None
    use_sensor_grid: bool = False
    grid: Grid2D | None = None
    field_grid: FieldGridLike | None = None
    pupil_grid: PupilGridLike | None = None
    ray_grid: RayGridLike[RaySample] | None = None
    opd: OPDMode | None = OPDMode.None_
    pol: InputPolarization | None = None

    def __post_init__(self) -> None:
        if self.surface_numbers == ():
            raise ValueError("surface_numbers must be None or non-empty")

        if self.current_start_surface_number is not None and self.current_start_surface_number < 0:
            raise ValueError(f"current_start_surface_number={self.current_start_surface_number} must be >= 0")

        if self.current_end_surface_number is not None and self.current_end_surface_number < 0:
            raise ValueError(f"current_end_surface_number={self.current_end_surface_number} must be >= 0")

    @property
    def calc_opd_single(self) -> bool:
        return self.opd != OPDMode.None_

    def require_surface_numbers(self) -> tuple[int, ...]:
        if self.surface_numbers is None:
            raise ValueError("surface_numbers are not resolved. Call .with_surfaces before running ray tracer.")
        return self.surface_numbers

    def require_current_end_surface_number(self) -> int:
        if self.current_end_surface_number is None:
            raise ValueError(
                "current_end_surface_number is not set. "
                "Use settings.with_current_end_surface(surface) inside tracer loop."
            )
        return self.current_end_surface_number

    def require_current_start_surface_number(self) -> int:
        return 0 if self.current_start_surface_number is None else self.current_start_surface_number

    def with_surfaces(
        self,
        surfaces: list[int] | tuple[int, ...],
    ) -> RayTraceSettings:
        surface_numbers = tuple(surfaces)
        if not surface_numbers:
            raise ValueError("surfaces must not be empty")

        return replace(
            self,
            surface_numbers=surface_numbers,
            current_end_surface_number=None,
            current_start_surface_number=None,
        )

    def with_current_end_surface(self, surface: int) -> RayTraceSettings:
        return replace(self, current_end_surface_number=surface)

    def with_current_start_surface(self, surface: int) -> RayTraceSettings:
        return replace(self, current_start_surface_number=surface)

    def with_rays(
        self,
        ray_grid: RayGridLike[RaySample],
    ) -> RayTraceSettings:
        return replace(self, ray_grid=ray_grid)

    def add_rays(self, ray_samples: list[RaySample]) -> RayTraceSettings:
        if self.ray_grid is None:
            return replace(self, ray_grid=list(ray_samples))
        return replace(self, ray_grid=list(self.ray_grid) + list(ray_samples))

    def clear_rays(self) -> RayTraceSettings:
        return replace(self, ray_grid=None)

    def with_grid(self, grid: Grid2D) -> RayTraceSettings:
        if not self.use_sensor_grid:
            return self
        return replace(self, grid=grid)

    def resolved_field_grid(self) -> FieldGridLike:
        if self.use_sensor_grid:
            if self.grid is None:
                raise ValueError("Sensor grid mode requires grid to be set.")
            gx, gy = self.grid
            return FieldGridRectangle(gx, gy)

        if self.field_grid is None:
            raise ValueError("Static mode requires field_grid to be provided.")

        return self.field_grid

    def resolved_sampler(self) -> RayGridLike[RaySample]:
        if self.ray_grid is not None:
            log.debug(
                "resolved_sampler: using pre-set ray_grid %r",
                type(self.ray_grid),
            )
            return self.ray_grid

        if self.pupil_grid is None:
            raise ValueError(
                "pupil_grid must be provided "
                "(e.g. OnAxisPupil() or PupilGridCircle(...))."
            )

        field_grid = self.resolved_field_grid()

        log.debug(
            "resolved_sampler: field_grid=%s len=%d | pupil_grid=%s len=%d",
            type(field_grid).__name__,
            len(field_grid),
            type(self.pupil_grid).__name__,
            len(self.pupil_grid),
        )

        return RayGrid(
            field_grid=field_grid,
            pupil_grid=self.pupil_grid,
        )

    def __str__(self) -> str:
        grid_repr = (
            self.grid
            if self.grid is not None
            else ("sensor" if self.use_sensor_grid else None)
        )

        return (
            "RayTraceSettings\n"
            f"  name={self.name!r},\n"
            f"  rays_type={self.rays_type.name},\n"
            f"  method={self.method.name},\n"
            f"  wave_number={self.wave_number},\n"
            f"  raytrace_mode={self.raytrace_mode.name},\n"
            f"  surface_numbers={self.surface_numbers},\n"
            f"  current_end_surface={self.current_end_surface_number},\n"
            f"  current_start_surface={self.current_start_surface_number},\n"
            f"  opd={self.opd.name if self.opd else None},\n"
            f"  pol={self.pol},\n"
            f"  use_sensor_grid={self.use_sensor_grid},\n"
            f"  ray_grid={'set' if self.ray_grid is not None else None},\n"
        )