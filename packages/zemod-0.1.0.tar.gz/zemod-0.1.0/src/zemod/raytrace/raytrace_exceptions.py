from __future__ import annotations

from zemod.raytrace.raytrace_settings import RayTraceSettings


class NoValidRaysError(RuntimeError):
    def __init__(self, *, settings: RayTraceSettings, total_traced: int) -> None:
        self.settings = settings
        self.total_traced = total_traced

        msg = (
            "No valid rays produced: "
            f"method={settings.method.name}, "
            f"wave={settings.wave_number}, "
            f"to_surface={settings.end_surface_number}, "
            f"total_traced={total_traced}"
        )
        super().__init__(msg)