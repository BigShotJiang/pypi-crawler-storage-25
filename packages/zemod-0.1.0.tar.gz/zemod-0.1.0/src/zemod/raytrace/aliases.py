from typing import  TypeVar, Callable, TypeAlias
from zempy.zosapi.tools.raytrace.results import Ray
from gosti.ray.ray_sample_like import RaySampleLike


T_Ray = TypeVar("T_Ray", bound=Ray)

type ZemaxPol = tuple[float, float, float, float]
type FieldComp = tuple[float, float, float, float, float, float]

from zemod.raytrace.coords import RayTraceCoord

PackFn: TypeAlias = Callable[[RaySampleLike], RayTraceCoord]
SampleCoord: TypeAlias = tuple[RaySampleLike, RayTraceCoord]
type Grid2D = tuple[int, int]