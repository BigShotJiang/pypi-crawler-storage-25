from __future__ import annotations
from typing import TYPE_CHECKING
from zemod.raytrace.coords import DirectCoord
from zemod.raytrace.raytrace_settings import RayTraceSettings
from zempy.zosapi.tools.raytrace.results.ray_direct_polarized_full import RayDirectPolarizedFull

if TYPE_CHECKING:
    from zemod.tools.zemod_batch_raytrace import ZeModBatchRayTrace

def single_direct_pol_full_as_ray(
        *,
        raytrace: ZeModBatchRayTrace,
        settings: RayTraceSettings,
        coords: DirectCoord,
        ray_number: int,
) -> RayDirectPolarizedFull:
    x, y, z, l, m, n = coords
    ex, ey, pha_x, pha_y = settings.pol or (1.0, 0.0, 0.0, 0.0)
    end_surface = settings.require_current_end_surface_number()
    start_surface = settings.require_current_start_surface_number()
    (
        ok,
        error_code,
        vignette_code,
        xo,
        yo,
        zo,
        lo,
        mo,
        no,
        exro,
        exio,
        eyro,
        eyio,
        ezro,
        ezio,
        intensity,
    ) = raytrace.single_ray_direct_pol_full(
        ray_type=settings.rays_type,
        ex=ex,
        ey=ey,
        pha_x=pha_x,
        pha_y=pha_y,
        start_surface=start_surface,
        to_surface=end_surface,
        wave_number=settings.wave_number,
        x=x,
        y=y,
        z=z,
        l=l,
        m=m,
        n=n,
    )

    return RayDirectPolarizedFull(
        ok=ok,
        rayNumber=ray_number,
        errorCode=error_code,
        vignetteCode=vignette_code,
        exr=exro,
        exi=exio,
        eyr=eyro,
        eyi=eyio,
        ezr=ezro,
        ezi=ezio,
        intensity=intensity,
        xo=xo,
        yo=yo,
        zo=zo,
        lo=lo,
        mo=mo,
        no=no,
    )