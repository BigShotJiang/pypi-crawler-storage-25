from __future__ import annotations
from typing import TYPE_CHECKING
from zemod.raytrace.coords import DirectCoord
from zemod.raytrace.raytrace_settings import RayTraceSettings
from zempy.zosapi.tools.raytrace.results.ray_direct_unpolarized import RayDirectUnpolarized

if TYPE_CHECKING:
    from zemod.tools.zemod_batch_raytrace import ZeModBatchRayTrace

def single_direct_unpol_as_ray(
        *,
        raytrace: ZeModBatchRayTrace,
        settings: RayTraceSettings,
        coords: DirectCoord,
        ray_number: int,
) -> RayDirectUnpolarized:
    x, y, z, l, m, n = coords
    end_surface = settings.require_current_end_surface_number()
    start_surface = settings.require_current_start_surface_number()
    (
        ok,
        error_code,
        vignette_code,
        xo,
        yo,
        zo,
        lo,
        mo,
        no,
        l2o,
        m2o,
        n2o,
        intensity,
    ) = raytrace.single_ray_direct_unpol(
        ray_type=settings.rays_type,
        start_surface=start_surface,
        to_surface=end_surface,
        wave_number=settings.wave_number,
        x=x,
        y=y,
        z=z,
        l=l,
        m=m,
        n=n,
    )

    return RayDirectUnpolarized(
        ok=ok,
        rayNumber=ray_number,
        errorCode=error_code,
        vignetteCode=vignette_code,
        X=xo,
        Y=yo,
        Z=zo,
        L=lo,
        M=mo,
        N=no,
        l2=l2o,
        m2=m2o,
        n2=n2o,
        intensity=intensity,
    )