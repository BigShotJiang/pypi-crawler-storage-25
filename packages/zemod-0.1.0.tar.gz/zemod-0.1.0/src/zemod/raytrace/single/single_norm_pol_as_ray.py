from __future__ import annotations
from typing import TYPE_CHECKING
from zemod.raytrace.coords import NormCoord
from zemod.raytrace.raytrace_settings import RayTraceSettings
from zempy.zosapi.tools.raytrace.results.ray_norm_polarized import RayNormPolarized

if TYPE_CHECKING:
    from zemod.tools.zemod_batch_raytrace import ZeModBatchRayTrace

def single_norm_pol_as_ray(
        *,
        raytrace: ZeModBatchRayTrace,
        settings: RayTraceSettings,
        coords: NormCoord,
        ecomp: tuple[float, ...],
        ray_number: int,
) -> RayNormPolarized:
    hx, hy, px, py = coords
    ex, ey, pha_x, pha_y = settings.pol or (1.0, 0.0, 0.0, 0.0)
    exr, exi, eyr, eyi, ezr, ezi = ecomp
    end_surface = settings.require_current_end_surface_number()
    (
        ok,
        error_code,
        exro,
        exio,
        eyro,
        eyio,
        ezro,
        ezio,
        intensity,
    ) = raytrace.single_ray_norm_pol(
        ray_type=settings.rays_type,
        ex=ex,
        ey=ey,
        pha_x=pha_x,
        pha_y=pha_y,
        to_surf=end_surface,
        wave_number=settings.wave_number,
        hx=hx,
        hy=hy,
        px=px,
        py=py,
        exr=exr,
        exi=exi,
        eyr=eyr,
        eyi=eyi,
        ezr=ezr,
        ezi=ezi,
    )

    return RayNormPolarized(
        ok=ok,
        rayNumber=ray_number,
        errorCode=error_code,
        exr=exro,
        exi=exio,
        eyr=eyro,
        eyi=eyio,
        ezr=ezro,
        ezi=ezio,
        intensity=intensity,
    )
