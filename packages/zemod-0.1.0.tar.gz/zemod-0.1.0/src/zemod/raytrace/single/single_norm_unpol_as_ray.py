from __future__ import annotations
from typing import TYPE_CHECKING
from zemod.raytrace.coords import NormCoord
from zemod.raytrace.raytrace_settings import RayTraceSettings
from zempy.zosapi.tools.raytrace.results.ray_norm_unpolarized import RayNormUnpolarized

if TYPE_CHECKING:
    from zemod.tools.zemod_batch_raytrace import ZeModBatchRayTrace

def single_norm_unpol_as_ray(
        *,
        raytrace: ZeModBatchRayTrace,
        settings: RayTraceSettings,
        coords: NormCoord,
        ray_number: int,
) -> RayNormUnpolarized:
    hx, hy, px, py = coords
    end_surface = settings.require_current_end_surface_number()
    (
        ok,
        error_code,
        vignette_code,
        xo,
        yo,
        zo,
        lo,
        mo,
        no,
        l2o,
        m2o,
        n2o,
        opd,
        intensity,
    ) = raytrace.single_ray_norm_unpol(
        ray_type=settings.rays_type,
        to_surf=end_surface,
        wave_number=settings.wave_number,
        hx=hx,
        hy=hy,
        px=px,
        py=py,
        calc_opd=settings.calc_opd_single,
    )

    return RayNormUnpolarized(
        ok=ok,
        rayNumber=ray_number,
        errorCode=error_code,
        vignetteCode=vignette_code,
        X=xo,
        Y=yo,
        Z=zo,
        L=lo,
        M=mo,
        N=no,
        l2=l2o,
        m2=m2o,
        n2=n2o,
        intensity=intensity,
        opd=opd,
    )
