from enum import Enum, auto

class RayTraceMode(Enum):
    BATCH = auto()
    SINGLE = auto()
