from enum import IntEnum
from typing import Type
from zempy.zosapi.tools.raytrace.results.ray_norm_polarized import RayNormPolarized
from zempy.zosapi.tools.raytrace.results.ray_norm_polarized_full import RayNormPolarizedFull
from zempy.zosapi.tools.raytrace.results.ray_direct_polarized import RayDirectPolarized
from zempy.zosapi.tools.raytrace.results.ray_direct_polarized_full import RayDirectPolarizedFull
from zempy.zosapi.tools.raytrace.results.ray_direct_unpolarized import RayDirectUnpolarized
from zempy.zosapi.tools.raytrace.results.ray_norm_unpolarized import RayNormUnpolarized
from zempy.zosapi.tools.raytrace.results import Ray

class TraceMethod(IntEnum):
    Normal_Unpolarized = 0
    Direct_Unpolarized = 1
    Normal_Polarized = 2
    Direct_Polarized = 3
    Normal_Polarized_Full = 4
    Direct_Polarized_Full = 5

    @property
    def is_polarized(self) -> bool:
        return self in {
            TraceMethod.Normal_Polarized,
            TraceMethod.Direct_Polarized,
            TraceMethod.Normal_Polarized_Full,
            TraceMethod.Direct_Polarized_Full,
        }

    @property
    def label(self) -> str:
        return {
            TraceMethod.Normal_Unpolarized: "Normal unpolarized",
            TraceMethod.Direct_Unpolarized: "Direct unpolarized",
            TraceMethod.Normal_Polarized: "Normal polarized",
            TraceMethod.Direct_Polarized: "Direct polarized",
            TraceMethod.Normal_Polarized_Full: "Normal polarized full",
            TraceMethod.Direct_Polarized_Full: "Direct polarized full",
        }[self]


RAY_CLASS_BY_METHOD: dict[TraceMethod, Type[Ray]] = {
    TraceMethod.Normal_Unpolarized: RayNormUnpolarized,
    TraceMethod.Direct_Unpolarized: RayDirectUnpolarized,
    TraceMethod.Normal_Polarized: RayNormPolarized,
    TraceMethod.Direct_Polarized: RayDirectPolarized,
    TraceMethod.Normal_Polarized_Full: RayNormPolarizedFull,
    TraceMethod.Direct_Polarized_Full: RayDirectPolarizedFull,
}