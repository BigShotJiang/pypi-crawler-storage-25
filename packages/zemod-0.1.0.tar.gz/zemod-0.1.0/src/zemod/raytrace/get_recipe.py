from __future__ import annotations
from typing import TYPE_CHECKING, cast
from allytools.logger import get_logger
from zemod.raytrace.aliases import ZemaxPol, FieldComp
from zemod.raytrace.ray_class import ray_class_of
from zemod.raytrace.recipe import Recipe
from zemod.raytrace.trace_method import TraceMethod
from zemod.raytrace.coords import DirectPacker, NormPacker, NormCoord, DirectCoord
from zemod.raytrace.coord_iter_from import coord_iter_from
from zemod.raytrace.raytrace_settings import RayTraceSettings
from zemod.raytrace.single.single_direct_pol_as_ray import single_direct_pol_as_ray
from zemod.raytrace.single.single_direct_unpol_as_ray import single_direct_unpol_as_ray
from zemod.raytrace.single.single_norm_pol_as_ray import single_norm_pol_as_ray
from zemod.raytrace.single.single_norm_unpol_as_ray import single_norm_unpol_as_ray
from zemod.raytrace.single.single_direct_pol_full_as_ray import single_direct_pol_full_as_ray
from zemod.raytrace.single.single_norm_pol_full_as_ray import single_norm_pol_full_as_ray
from gosti.polarization.input_polarization import InputPolarization
from zemod.raytrace.get_phase import get_norm_phase_components, get_phase_components


if TYPE_CHECKING:
    from zemod.tools.zemod_batch_raytrace import ZeModBatchRayTrace

log = get_logger(__name__)
def get_recipe(*, zemod_tool: ZeModBatchRayTrace) -> Recipe:
    settings_ = zemod_tool.settings
    if settings_ is None:
        raise RuntimeError("get_recipe called without settings")
    settings: RayTraceSettings = settings_
    trace_method = settings.method
    sampler = settings.resolved_sampler()
    total = len(sampler)
    norm_packer = NormPacker()
    direct_packer = DirectPacker(zemod_batch_raytrace=zemod_tool, wave_number=settings.wave_number,rays_type=settings.rays_type)
    rays_type = settings.rays_type
    end_surface = settings.require_current_end_surface_number()
    start_surface = settings.require_current_start_surface_number()
    wave_number = settings.wave_number
    opd = settings.opd
    pol: ZemaxPol = (1.0, 0.0, 0.0, 0.0)
    input_pol: InputPolarization | None = settings.pol
    active_pol: InputPolarization



    if trace_method.is_polarized:
        if input_pol is None:
            raise RuntimeError(f"{trace_method.label} requires settings.pol")
        active_pol = input_pol
        pol = active_pol.as_zemax_tuple()
    else:
        active_pol = InputPolarization(jx=1.0, jy=0.0)
        pol = (1.0, 0.0, 0.0, 0.0)

    def norm_ecomp(coords: NormCoord) -> FieldComp:
        return get_norm_phase_components(zemod_tool=zemod_tool, wave_number=wave_number, rays_type=rays_type,
                                         hx=coords.hx, hy=coords.hy, px=coords.px, py=coords.py,pol=active_pol)
    def direct_ecomp(coords: DirectCoord) -> FieldComp:
        return get_phase_components(zemod_tool=zemod_tool, l=coords.l, m=coords.m, n=coords.n, pol=active_pol)


    recipes: dict[TraceMethod, Recipe] = {
        TraceMethod.Normal_Unpolarized: Recipe(
            create=lambda: zemod_tool.create_norm_unpol(max_rays=total, ray_type=rays_type, to_surface=end_surface),
            add_one=lambda buf, coords: buf.AddRay(wave_number,*cast(NormCoord, coords).as_zemax_tuple(),opd),
            read_next=lambda buf: buf.ReadNextResult(),
            trace_one=lambda rt, sample, coords, ray_number:
            single_norm_unpol_as_ray(
                raytrace=rt,
                settings=settings,
                coords=cast(NormCoord, coords).as_zemax_tuple(),
                ray_number=ray_number),
            sample_iter=lambda: coord_iter_from(sampler, norm_packer.pack),
            ray_class=ray_class_of(TraceMethod.Normal_Unpolarized),
        ),

        TraceMethod.Direct_Unpolarized: Recipe(
            create=lambda: zemod_tool.create_direct_unpol(
                max_rays=total,
                ray_type=rays_type,
                start_surface=start_surface,
                to_surface=end_surface,
            ),
            add_one=lambda buf, coords: buf.AddRay(
                wave_number,
                *cast(DirectCoord, coords).as_zemax_tuple(),
            ),
            read_next=lambda buf: buf.ReadNextResult(),
            trace_one=lambda rt, sample, coords, ray_number: single_direct_unpol_as_ray(
                raytrace=rt,
                settings=settings,
                coords=cast(DirectCoord, coords).as_zemax_tuple(),
                ray_number=ray_number,
            ),
            sample_iter=lambda: coord_iter_from(sampler, direct_packer.pack),
            ray_class=ray_class_of(TraceMethod.Direct_Unpolarized),
        ),

        TraceMethod.Normal_Polarized: Recipe(
            create=lambda: zemod_tool.create_norm_pol(
                max_rays=total,
                ray_type=rays_type,
                ex=pol[0],
                ey=pol[1],
                pha_x=pol[2],
                pha_y=pol[3],
                to_surface=end_surface,
            ),
            add_one=lambda buf, coords: buf.AddRay(
                wave_number,
                *cast(NormCoord, coords).as_zemax_tuple(),
                *norm_ecomp(cast(NormCoord, coords)),
            ),
            read_next=lambda buf: buf.ReadNextResult(),
            trace_one=lambda rt, sample, coords, ray_number: single_norm_pol_as_ray(
                raytrace=rt,
                settings=settings,
                coords=cast(NormCoord, coords).as_zemax_tuple(),
                ray_number=ray_number,
                ecomp=norm_ecomp(cast(NormCoord, coords)),
            ),
            sample_iter=lambda: coord_iter_from(sampler, norm_packer.pack),
            ray_class=ray_class_of(TraceMethod.Normal_Polarized),
        ),

        TraceMethod.Direct_Polarized: Recipe(
            create=lambda: zemod_tool.create_direct_pol(
                max_rays=total,
                ray_type=rays_type,
                ex=pol[0],
                ey=pol[1],
                pha_x=pol[2],
                pha_y=pol[3],
                start_surface=start_surface,
                to_surface=end_surface,
            ),
            add_one=lambda buf, coords: buf.AddRay(
                wave_number,
                *cast(DirectCoord, coords).as_zemax_tuple(),
                *direct_ecomp(cast(DirectCoord, coords)),
            ),
            read_next=lambda buf: buf.ReadNextResult(),
            trace_one=lambda rt, sample, coords, ray_number: single_direct_pol_as_ray(
                raytrace=rt,
                settings=settings,
                coords=cast(DirectCoord, coords).as_zemax_tuple(),
                ray_number=ray_number,
            ),
            sample_iter=lambda: coord_iter_from(sampler, direct_packer.pack),
            ray_class=ray_class_of(TraceMethod.Direct_Polarized),
        ),

        TraceMethod.Normal_Polarized_Full: Recipe(
            create=lambda: zemod_tool.create_norm_pol(
                max_rays=total,
                ray_type=rays_type,
                ex=pol[0],
                ey=pol[1],
                pha_x=pol[2],
                pha_y=pol[3],
                to_surface=end_surface,
            ),
            add_one=lambda buf, coords: buf.AddRay(
                wave_number,
                *cast(NormCoord, coords).as_zemax_tuple(),
                *norm_ecomp(cast(NormCoord, coords)),
            ),
            read_next=lambda buf: buf.ReadNextResultFull(),
            trace_one=lambda rt, sample, coords, ray_number: single_norm_pol_full_as_ray(
                raytrace=rt,
                settings=settings,
                coords=cast(NormCoord, coords).as_zemax_tuple(),
                ray_number=ray_number,
                ecomp=norm_ecomp(cast(NormCoord, coords)),
            ),
            sample_iter=lambda: coord_iter_from(sampler, norm_packer.pack),
            ray_class=ray_class_of(TraceMethod.Normal_Polarized_Full),
        ),

        TraceMethod.Direct_Polarized_Full: Recipe(
            create=lambda: zemod_tool.create_direct_pol(
                max_rays=total,
                ray_type=rays_type,
                ex=pol[0],
                ey=pol[1],
                pha_x=pol[2],
                pha_y=pol[3],
                start_surface=start_surface,
                to_surface=end_surface,
            ),
            add_one=lambda buf, coords: buf.AddRay(
                wave_number,
                *cast(DirectCoord, coords).as_zemax_tuple(),
                *direct_ecomp(cast(DirectCoord, coords)),
            ),
            read_next=lambda buf: buf.ReadNextResultFull(),
            trace_one=lambda rt, sample, coords, ray_number: single_direct_pol_full_as_ray(
                raytrace=rt,
                settings=settings,
                coords=cast(DirectCoord, coords).as_zemax_tuple(),
                ray_number=ray_number,
            ),
            sample_iter=lambda: coord_iter_from(sampler, direct_packer.pack),
            ray_class=ray_class_of(TraceMethod.Direct_Polarized_Full),
        ),
    }
    try:
        return recipes[trace_method]
    except KeyError as e:
        raise ValueError(f"Unsupported method: {trace_method}") from e