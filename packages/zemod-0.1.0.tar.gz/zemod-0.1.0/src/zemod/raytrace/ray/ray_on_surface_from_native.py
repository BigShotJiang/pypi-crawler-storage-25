from __future__ import annotations
from typing import TypeAlias
from gosti.polarization.traced_polarization_state import TracedPolarizationState
from gosti.ray.ray_3d import Ray3D
from gosti.ray.ray_meta import RayMeta
from gosti.ray.ray_optical_state import RayOpticalState
from gosti.tracer.ray_on_surface import RayOnSurface
from zemod.raytrace.traced_sample_ray import TracedSampleRay
from zempy.zosapi.tools.raytrace.results.ray import Ray
from zempy.zosapi.tools.raytrace.results.ray_direct_polarized import RayDirectPolarized
from zempy.zosapi.tools.raytrace.results.ray_direct_polarized_full import RayDirectPolarizedFull
from zempy.zosapi.tools.raytrace.results.ray_direct_unpolarized import RayDirectUnpolarized
from zempy.zosapi.tools.raytrace.results.ray_norm_polarized import RayNormPolarized
from zempy.zosapi.tools.raytrace.results.ray_norm_polarized_full import RayNormPolarizedFull
from zempy.zosapi.tools.raytrace.results.ray_norm_unpolarized import RayNormUnpolarized
from zempy.zosapi.tools.raytrace.results.ray_polarized import RayPolarized
from zempy.zosapi.tools.raytrace.results.ray_unpolarized import RayUnpolarized


GeometricNativeRay: TypeAlias = (RayUnpolarized | RayNormPolarizedFull | RayDirectPolarizedFull)

NativeSequentialRay: TypeAlias = (  RayNormUnpolarized      | RayDirectUnpolarized  | RayNormPolarized
                                  | RayNormPolarizedFull    | RayDirectPolarized    | RayDirectPolarizedFull)


def ray_meta_from_native(ray: Ray) -> RayMeta:
    return RayMeta(
        ok=ray.ok,
        ray_number=ray.rayNumber,
        error_code=ray.errorCode,
        vignette_code=getattr(ray, "vignetteCode", None),
    )


def ray_optical_state_from_native(ray: NativeSequentialRay) -> RayOpticalState:
    return RayOpticalState(
        intensity=ray.intensity,
        opd=getattr(ray, "opd", None),
    )


def ray3d_from_native(ray: GeometricNativeRay) -> Ray3D:
    if isinstance(ray, RayUnpolarized):
        return Ray3D.from_xyz_lmn(
            x_mm=ray.X,
            y_mm=ray.Y,
            z_mm=ray.Z,
            l=ray.L,
            m=ray.M,
            n=ray.N,
            meta=ray_meta_from_native(ray),
            optical_state=ray_optical_state_from_native(ray),
        )

    return Ray3D.from_xyz_lmn(
        x_mm=ray.xo,
        y_mm=ray.yo,
        z_mm=ray.zo,
        l=ray.lo,
        m=ray.mo,
        n=ray.no,
        meta=ray_meta_from_native(ray),
        optical_state=ray_optical_state_from_native(ray),
    )


def polarization_from_native(ray: NativeSequentialRay) -> TracedPolarizationState | None:
    if not isinstance(ray, RayPolarized):
        return None

    return TracedPolarizationState.from_zemax_ray(ray)


def require_native_sequential_ray(ray: Ray) -> NativeSequentialRay:
    if isinstance(
        ray,
        (
            RayNormUnpolarized,
            RayDirectUnpolarized,
            RayNormPolarized,
            RayNormPolarizedFull,
            RayDirectPolarized,
            RayDirectPolarizedFull,
        ),
    ):
        return ray

    raise TypeError(f"Expected native sequential Ray, got {type(ray)!r}")


def require_geometric_native_ray(ray: NativeSequentialRay) -> GeometricNativeRay:
    if isinstance(ray, (RayUnpolarized, RayNormPolarizedFull,RayDirectPolarizedFull)):
        return ray
    raise TypeError(f"{type(ray).__name__} does not contain XYZ/LMN data. Use RayUnpolarized or full polarized rays.")


def ray_on_surface_from_traced(traced: TracedSampleRay) -> RayOnSurface:
    native = require_native_sequential_ray(traced.ray)
    geometric_ray = require_geometric_native_ray(native)

    return RayOnSurface(
        surface_number=traced.surface_number,
        ray=ray3d_from_native(geometric_ray),
        polarization=polarization_from_native(native),
    )