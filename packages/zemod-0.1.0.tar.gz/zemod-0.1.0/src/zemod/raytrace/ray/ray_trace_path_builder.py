from __future__ import annotations
from collections import defaultdict
from typing import Iterable
from gosti.grid.field_grid_like import FieldGridLike
from gosti.grid.pupil_grid_like import PupilGridLike
from gosti.ray.ray_sample import RaySample
from gosti.tracer.ray_batch import RayBatch
from gosti.tracer.ray_bundle import RayBundle
from gosti.tracer.ray_bundle_builder import RayBundleBuilder
from zemod.raytrace.ray.ray_on_surface_from_native import ray_on_surface_from_traced
from zemod.raytrace.traced_sample_ray import TracedSampleRay
from gosti.polarization.input_polarization import InputPolarization

def group_traced_by_sample(traced: Iterable[TracedSampleRay]) -> dict[RaySample, list[TracedSampleRay]]:
    grouped: dict[RaySample, list[TracedSampleRay]] = defaultdict(list)
    for item in traced:
        if not isinstance(item.sample, RaySample):
            raise TypeError(f"Expected RaySample, got {type(item.sample)!r}")
        grouped[item.sample].append(item)
    return dict(grouped)


def build_ray_bundle(
        *,
        field_point,
        pupil_grid: PupilGridLike,
        grouped: dict[RaySample, list[TracedSampleRay]]) -> RayBundle:
    builder = RayBundleBuilder(field_point=field_point, pupil_grid=pupil_grid)
    for pupil in pupil_grid:
        sample = RaySample(norm_field=field_point, norm_pupil=pupil)
        traced_group = grouped.get(sample)
        if traced_group is None:
            raise KeyError(f"No traced rays for sample {sample}")
        first_traced = traced_group[0]
        builder.register(sample=sample, input_ray=first_traced.input_ray)
        for traced in sorted(traced_group, key=lambda item: item.surface_number):
            builder.add_hit(sample=sample, hit=ray_on_surface_from_traced(traced))
    return builder.build()


def build_ray_batch(
        *,
        traced_sample_rays: Iterable[TracedSampleRay],
        field_grid: FieldGridLike,
        pupil_grid: PupilGridLike,
        input_polarization: InputPolarization | None = None) -> RayBatch:
    grouped = group_traced_by_sample(traced_sample_rays)
    bundles = tuple(build_ray_bundle(field_point=field_point, pupil_grid=pupil_grid, grouped=grouped)
                    for field_point in field_grid)
    return RayBatch(field_grid=field_grid, bundles=bundles, input_polarization=input_polarization)