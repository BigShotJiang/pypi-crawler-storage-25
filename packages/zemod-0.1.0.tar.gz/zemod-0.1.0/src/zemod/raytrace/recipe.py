from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Callable, Iterable, Type, TYPE_CHECKING
from zemod.raytrace.aliases import SampleCoord, RaySampleLike
from zemod.raytrace.coords import RayTraceCoord
from zempy.zosapi.tools.raytrace.results import Ray

if TYPE_CHECKING:
    from zemod.tools.zemod_batch_raytrace import ZeModBatchRayTrace


@dataclass(frozen=True, slots=True)
class Recipe:
    """
    Recipe describes how to run one ray-tracing method.

    It contains:
    - how to create the native batch buffer
    - how to add one ray to the buffer
    - how to read one result from the buffer
    - how to run a single-ray shortcut, if supported
    - how to iterate over input samples and packed coordinates
    - which ZemPy ray result class should be built from native records
    """

    create: Callable[[], Any]
    """Create native batch ray-trace data buffer."""

    add_one: Callable[[Any, RayTraceCoord], Any]
    """Add one packed ray to the native buffer."""

    read_next: Callable[[Any], Any]
    """Read one result record from the native buffer."""

    sample_iter: Callable[[], Iterable[SampleCoord]]
    """Yield pairs: (RaySampleLike, RayTraceCoord)."""

    ray_class: Type[Ray]
    """ZemPy ray result dataclass used by build_ray(...)."""

    trace_one: Callable[[ZeModBatchRayTrace, RaySampleLike, RayTraceCoord, int],Ray,]
    """Run one ray directly without creating a batch buffer."""