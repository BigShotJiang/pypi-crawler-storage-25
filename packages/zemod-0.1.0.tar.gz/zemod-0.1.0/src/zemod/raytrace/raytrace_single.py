from __future__ import annotations

from typing import TYPE_CHECKING

from zemod.raytrace.raytrace_settings import RayTraceSettings
from zemod.raytrace.recipe import Recipe
from zemod.raytrace.traced_sample_ray import TracedSampleRay

if TYPE_CHECKING:
    from zemod.tools.zemod_batch_raytrace import ZeModBatchRayTrace


def raytrace_single(
    *,
    zemod_tool: ZeModBatchRayTrace,
    settings: RayTraceSettings,
    recipe: Recipe,
) -> list[TracedSampleRay]:
    out: list[TracedSampleRay] = []
    items = list(recipe.sample_iter())
    end_surface = settings.require_current_end_surface_number()

    for ray_number, (sample, coords) in enumerate(items):
        ray = recipe.trace_one(zemod_tool, sample, coords, ray_number)

        input_ray = coords.to_input_ray(
            zemod_tool=zemod_tool,
            wave_number=settings.wave_number,
            rays_type=settings.rays_type,
        )

        out.append(
            TracedSampleRay(
                sample=sample,
                ray=ray,
                surface_number=end_surface,
                ray_number=ray_number,
                input_ray=input_ray,
            )
        )

    return out