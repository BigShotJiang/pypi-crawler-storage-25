from typing import Iterable
from allytools.logger import get_logger
from zemod.raytrace.aliases import  PackFn, SampleCoord
from gosti.ray.ray_sample_like import RaySampleLike


log = get_logger(__name__)
def coord_iter_from(sampler: Iterable[RaySampleLike], pack: PackFn) -> list[SampleCoord]:
    out: list[SampleCoord] = []
    for rc in sampler:
        coords = pack(rc)
        log.trace(
            "coord_iter_from: field=(hx=%s, hy=%s), pupil=(px=%s, py=%s) -> packed=%s",
            rc.norm_field.hx,
            rc.norm_field.hy,
            rc.norm_pupil.px,
            rc.norm_pupil.py,
            coords)
        out.append((rc, coords))
    return out