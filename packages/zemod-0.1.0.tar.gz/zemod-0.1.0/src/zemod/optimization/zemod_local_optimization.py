from __future__ import annotations

from typing import TYPE_CHECKING

from zemod.tools.zemod_tool import ZeModTool

if TYPE_CHECKING:
    from zempy.zosapi.tools.optimization.adapters.local_optimization import LocalOptimization


class ZeModLocalOptimization(ZeModTool):
    __slots__ = (
        "_initial_merit_function",
        "_current_merit_function",
        "_targets",
        "_variables",
    )

    native: LocalOptimization

    def __init__(self, native: LocalOptimization) -> None:
        super().__init__(native)
        self._initial_merit_function: float | None = None
        self._current_merit_function: float | None = None
        self._targets: int | None = None
        self._variables: int | None = None

    @property
    def initial_merit_function(self) -> float:
        if self._initial_merit_function is not None:
            return self._initial_merit_function
        return float(self.native.InitialMeritFunction)

    @property
    def current_merit_function(self) -> float:
        if self._current_merit_function is not None:
            return self._current_merit_function
        return float(self.native.CurrentMeritFunction)

    @property
    def targets(self) -> int:
        if self._targets is not None:
            return self._targets
        return int(self.native.Targets)

    @property
    def variables(self) -> int:
        if self._variables is not None:
            return self._variables
        return int(self.native.Variables)

    @property
    def max_cores(self) -> int:
        return int(self.native.MaxCores)

    def run_wait_for_completion(self) -> None:
        self._initial_merit_function = float(self.native.InitialMeritFunction)
        self._targets = int(self.native.Targets)
        self._variables = int(self.native.Variables)

        self.native.RunAndWaitForCompletion()

        self._current_merit_function = float(self.native.CurrentMeritFunction)