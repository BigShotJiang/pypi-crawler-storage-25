from __future__ import annotations

import logging
from dataclasses import dataclass

from allytools.types.validate_cast import validate_cast

from zemod.tools.zemod_tool import ZeModTool
from zemod.tools.zemod_tool_settings import ZeModToolSettings
from zempy.zosapi.tools.optimization.enums.optimization_algorithm import OptimizationAlgorithm
from zempy.zosapi.tools.optimization.enums.optimization_cycles import OptimizationCycles
from zempy.zosapi.tools.optimization.protocols.i_local_optimization import ILocalOptimization

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class LocalOptimizationSettings(ZeModToolSettings):
    algorithm: OptimizationAlgorithm = OptimizationAlgorithm.DampedLeastSquares
    cycles: OptimizationCycles = OptimizationCycles.Automatic
    number_of_cores: int | None = None

    def apply_to(self, tool: ZeModTool) -> None:
        native = validate_cast(tool.native, ILocalOptimization)

        logger.debug("LocalOptimization settings: algorithm=%s", self.algorithm)
        native.Algorithm = self.algorithm

        logger.debug("LocalOptimization settings: cycles=%s", self.cycles)
        native.Cycles = self.cycles

        if self.number_of_cores is not None:
            n = min(int(self.number_of_cores), int(native.MaxCores))
            logger.debug("LocalOptimization settings: number_of_cores=%d", n)
            native.NumberOfCores = n