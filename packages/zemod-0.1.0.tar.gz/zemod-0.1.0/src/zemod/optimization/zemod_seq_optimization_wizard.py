from __future__ import annotations

from typing import TYPE_CHECKING

from zemod.core.native_adapter import NativeAdapter
from zempy.zosapi.tools.optimization.enums.optimization_algorithm import OptimizationAlgorithm
from zempy.zosapi.tools.optimization.enums.optimization_cycles import OptimizationCycles

if TYPE_CHECKING:
    from zempy.zosapi.wizards.protocols.i_seq_optimization_wizard import ISEQOptimizationWizard


class ZeModSEQOptimizationWizard(NativeAdapter["ISEQOptimizationWizard"]):
    __slots__ = ()

    def apply(self) -> None:
        self.native.Apply()

    def ok(self) -> None:
        self.native.OK()

    def initialize(self) -> None:
        self.native.Initialize()

    def save_settings(self) -> None:
        self.native.SaveSettings()

    def load_settings(self) -> None:
        self.native.LoadSettings()

    def reset_settings(self) -> None:
        self.native.ResetSettings()

    def setup_rms_spot_default(
        self,
        *,
        data: int = 1,
        ring: int = 2,
        overall_weight: float = 1.0,
        glass_min: float = 3.0,
        glass_max: float = 15.0,
        glass_edge: float = 3.0,
        air_min: float = 0.5,
        air_max: float = 1000.0,
        air_edge: float = 0.5,
    ) -> None:
        self.native.Data = data
        self.native.Ring = ring
        self.native.OverallWeight = overall_weight

        self.native.IsGlassUsed = True
        self.native.GlassMin = glass_min
        self.native.GlassMax = glass_max
        self.native.GlassEdge = glass_edge

        self.native.IsAirUsed = True
        self.native.AirMin = air_min
        self.native.AirMax = air_max
        self.native.AirEdge = air_edge

    def apply_rms_spot_default(self) -> None:
        self.setup_rms_spot_default()
        self.apply()