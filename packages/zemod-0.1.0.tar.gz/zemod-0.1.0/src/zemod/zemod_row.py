from __future__ import annotations

from typing import TYPE_CHECKING, Any

from zemod.core.native_adapter import NativeAdapter
from zemod.zemod_cell import ZeModCell
from zempy.zosapi.editors.lde.enums.surface_column import SurfaceColumn

if TYPE_CHECKING:
    from zempy.zosapi.editors.lde.protocols.ilde_row import ILDERow


class ZeModRow(NativeAdapter["ILDERow"]):
    __slots__ = ()

    @property
    def thickness(self) -> float:
        return float(self.native.Thickness)

    @thickness.setter
    def thickness(self, value: float) -> None:
        self.native.Thickness = float(value)

    @property
    def radius(self) -> float:
        return float(self.native.Radius)

    @radius.setter
    def radius(self, value: float) -> None:
        self.native.Radius = float(value)

    @property
    def comment(self) -> str:
        return self.native.Comment

    @comment.setter
    def comment(self, comment: str) -> None:
        self.native.Comment = comment

    @property
    def material(self) -> str:
        return self.native.Material

    @material.setter
    def material(self, value: str) -> None:
        self.native.Material = value

    @property
    def radius_cell(self) -> ZeModCell:
        return ZeModCell(self.native.RadiusCell)

    @property
    def thickness_cell(self) -> ZeModCell:
        return ZeModCell(self.native.ThicknessCell)

    @property
    def comment_cell(self) -> ZeModCell:
        return ZeModCell(self.native.CommentCell)

    @property
    def material_cell(self) -> ZeModCell:
        return ZeModCell(self.native.MaterialCell)

    def get_cell(self, column: SurfaceColumn | Any) -> ZeModCell:
        return ZeModCell(self.native.GetSurfaceCell(column))

    def make_radius_variable(self) -> bool:
        return self.radius_cell.make_variable()

    def make_thickness_variable(self) -> bool:
        return self.thickness_cell.make_variable()

    def make_radius_fixed(self) -> bool:
        return self.radius_cell.make_fixed()

    def make_thickness_fixed(self) -> bool:
        return self.thickness_cell.make_fixed()