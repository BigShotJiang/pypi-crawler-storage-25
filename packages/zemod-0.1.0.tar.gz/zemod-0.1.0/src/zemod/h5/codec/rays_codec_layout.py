from __future__ import annotations
from dataclasses import dataclass
from h5kit.codec.h5_codec_layout import H5CodecLayout


@dataclass(frozen=True)
class RaysCodecLayout:
    ray_type_module: str = "ray_type_module"
    ray_type_name: str = "ray_type_name"
    field_names: str = "field_names"
    values: str = "values"

    @property
    def h5_layout(self) -> H5CodecLayout:
        return H5CodecLayout(
            datasets=(self.field_names, self.values),
            attrs=(self.ray_type_module, self.ray_type_name))

RAYS_CODEC_LAYOUT = RaysCodecLayout()