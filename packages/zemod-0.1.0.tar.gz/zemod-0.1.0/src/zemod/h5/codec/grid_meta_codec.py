from __future__ import annotations
from typing import TYPE_CHECKING, ClassVar
from dimetra.geo import Length
from h5kit import codec, H5CodecLike, H5CodecMixin
from zemod.iar.grid_meta import GridMeta
from zemod.h5.codec.grid_meta_codec_layout import GRID_META_CODEC_LAYOUT

if TYPE_CHECKING:
    from h5kit import H5Reader, H5Writer, H5CodecLayout


@codec
class GridMetaCodec(H5CodecMixin, H5CodecLike[GridMeta]):
    PY_TYPE: ClassVar[type[GridMeta]] = GridMeta
    SCHEMA: ClassVar[str] = "zemod.iar.grid_meta.GridMeta"
    VER: ClassVar[int] = 1
    LAYOUT: ClassVar[H5CodecLayout] = GRID_META_CODEC_LAYOUT.h5_layout

    @classmethod
    def write(cls, w: H5Writer, obj: GridMeta) -> None:
        cls.clear_before_write(w)
        cls.write_obj(w, GRID_META_CODEC_LAYOUT.min_x, obj=obj.min_x)
        cls.write_obj(w, GRID_META_CODEC_LAYOUT.min_y, obj=obj.min_y)
        cls.write_obj(w, GRID_META_CODEC_LAYOUT.dx, obj=obj.dx)
        cls.write_obj(w, GRID_META_CODEC_LAYOUT.dy, obj=obj.dy)
        w.attr(GRID_META_CODEC_LAYOUT.description, obj.description)
        w.attr(GRID_META_CODEC_LAYOUT.x_label, obj.x_label)
        w.attr(GRID_META_CODEC_LAYOUT.y_label, obj.y_label)
        w.attr(GRID_META_CODEC_LAYOUT.value_label, obj.value_label)

    @classmethod
    def read(cls, r: H5Reader) -> GridMeta:
        min_x = cls.require_obj_typed(r, GRID_META_CODEC_LAYOUT.min_x, py_type=Length)
        min_y = cls.require_obj_typed(r, GRID_META_CODEC_LAYOUT.min_y, py_type=Length)
        dx = cls.require_obj_typed(r, GRID_META_CODEC_LAYOUT.dx, py_type=Length)
        dy = cls.require_obj_typed(r, GRID_META_CODEC_LAYOUT.dy, py_type=Length)
        description = r.attr(GRID_META_CODEC_LAYOUT.description, transform=str)
        x_label = r.require_attr(GRID_META_CODEC_LAYOUT.x_label, transform=str)
        y_label = r.require_attr(GRID_META_CODEC_LAYOUT.y_label, transform=str)
        value_label  = r.require_attr(GRID_META_CODEC_LAYOUT.value_label, transform=str)
        return GridMeta(
            _min_x= min_x,
            _min_y=min_y,
            _dx=dx,
            _dy=dy,
            _description=description,
            _x_label=x_label,
            _y_label=y_label,
            _value_label=value_label)