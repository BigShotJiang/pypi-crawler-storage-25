from __future__ import annotations
from dataclasses import dataclass
from h5kit.codec.h5_codec_layout import H5CodecLayout


@dataclass(frozen=True)
class RayTraceSettingsCodecLayout:
    name: str = "name"
    wave_number: str = "wave_number"
    use_sensor_grid: str = "use_sensor_grid"
    grid2d: str = "grid2d"

    surface_numbers: str = "surface_numbers"
    current_end_surface_number: str = "current_end_surface_number"
    current_start_surface_number: str = "current_start_surface_number"

    pol4: str = "pol4"
    rays_type: str = "rays_type"
    method: str = "method"
    opd: str = "opd"
    raytrace_mode: str = "raytrace_mode"

    field_grid: str = "field_grid"
    pupil_grid: str = "pupil_grid"
    ray_samples: str = "ray_samples"

    @property
    def h5_layout(self) -> H5CodecLayout:
        return H5CodecLayout(
            attrs=(
                self.name,
                self.wave_number,
                self.use_sensor_grid,
                self.rays_type,
                self.method,
                self.raytrace_mode,
            ),
            datasets=(self.surface_numbers,),
            groups=(self.field_grid, self.pupil_grid),
            optional_attrs=(
                self.grid2d,
                self.current_end_surface_number,
                self.current_start_surface_number,
                self.pol4,
                self.opd,
            ),
            optional_groups=(self.ray_samples,),
        )


RAYTRACE_SETTINGS_CODEC_LAYOUT = RayTraceSettingsCodecLayout()
