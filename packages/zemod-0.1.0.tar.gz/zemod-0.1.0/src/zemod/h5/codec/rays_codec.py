from __future__ import annotations
from typing import TYPE_CHECKING, Any, ClassVar
import numpy as np
from h5kit import codec, H5CodecLike, H5CodecMixin
from zemod.raytrace.rays import Rays
from zemod.h5.codec.rays_codec_layout import RAYS_CODEC_LAYOUT

if TYPE_CHECKING:
    from h5kit import H5Reader, H5Writer, H5CodecLayout


@codec
class RaysCodec(H5CodecMixin, H5CodecLike[Rays[Any]]):
    PY_TYPE: ClassVar[type[Rays]] = Rays
    SCHEMA: ClassVar[str] = "gosti.batch_raytrace.Rays"
    VER: ClassVar[int] = 1
    LAYOUT: ClassVar[H5CodecLayout] = RAYS_CODEC_LAYOUT.h5_layout

    @classmethod
    def write(cls, w: H5Writer, obj: Rays[Any]) -> None:
        if not obj.field_names and obj.n > 0:
            raise ValueError("Cannot write Rays: field_names are empty for non-empty data")
        cls.clear_before_write(w)
        w.strings(RAYS_CODEC_LAYOUT.field_names, obj.field_names)
        w.array(RAYS_CODEC_LAYOUT.values, obj.values_matrix())
        w.attr(RAYS_CODEC_LAYOUT.ray_type_module, obj.type_module)
        w.attr(RAYS_CODEC_LAYOUT.ray_type_name, obj.type_name)

    @classmethod
    def read(cls, r: H5Reader) -> Rays[Any]:
        field_names = r.strings(RAYS_CODEC_LAYOUT.field_names)
        values = np.asarray(r.require_ndarray(RAYS_CODEC_LAYOUT.values),dtype=np.float64)
        type_module = r.require_attr(RAYS_CODEC_LAYOUT.ray_type_module)
        type_name = r.require_attr(RAYS_CODEC_LAYOUT.ray_type_name)
        return Rays.from_h5_payload(values=values, field_names=field_names, type_module=type_module, type_name=type_name)