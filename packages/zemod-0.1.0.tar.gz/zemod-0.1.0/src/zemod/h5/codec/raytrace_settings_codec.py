from __future__ import annotations
from typing import TYPE_CHECKING, Any, ClassVar
import numpy as np
from h5kit import codec, H5CodecLike, H5CodecMixin, h5_index_name
from zempy.zosapi.tools.raytrace.enums import OPDMode, RaysType
from gosti.grid.grid_like_mixin import GridLikeMixin
from gosti.ray.ray_sample import RaySample
from zemod.h5.codec.raytrace_settings_codec_layout import RAYTRACE_SETTINGS_CODEC_LAYOUT
from zemod.raytrace.ray_trace_mode import RayTraceMode
from zemod.raytrace.raytrace_settings import RayTraceSettings
from zemod.raytrace.trace_method import TraceMethod

if TYPE_CHECKING:
    from h5kit import H5Reader, H5Writer, H5CodecLayout


LAYOUT = RAYTRACE_SETTINGS_CODEC_LAYOUT


@codec
class RayTraceSettingsCodec(H5CodecMixin, H5CodecLike[RayTraceSettings]):
    PY_TYPE: ClassVar[type[RayTraceSettings]] = RayTraceSettings
    SCHEMA: ClassVar[str] = "zemod.raytrace.RayTraceSettings"
    VER: ClassVar[int] = 1
    LAYOUT: ClassVar[H5CodecLayout] = LAYOUT.h5_layout

    @classmethod
    def write(cls, w: H5Writer, obj: RayTraceSettings) -> None:
        cls.clear_before_write(w)

        w.attr(LAYOUT.name, obj.name)
        w.attr(LAYOUT.wave_number, int(obj.wave_number))
        w.attr(LAYOUT.use_sensor_grid, bool(obj.use_sensor_grid))
        w.array(LAYOUT.surface_numbers, np.asarray(obj.surface_numbers, dtype=int))
        w.attr(LAYOUT.current_end_surface_number, obj.current_end_surface_number)
        w.attr(LAYOUT.current_start_surface_number, obj.current_start_surface_number)
        w.attr(LAYOUT.rays_type, obj.rays_type.name)
        w.attr(LAYOUT.method, obj.method.name)
        w.attr(LAYOUT.raytrace_mode, obj.raytrace_mode.name)
        w.attr(LAYOUT.grid2d, obj.grid, transform=_to_int2_array)
        w.attr(LAYOUT.pol4, obj.pol, transform=_to_pol4_array)
        w.attr(LAYOUT.opd, obj.opd, transform=lambda x: x.name)
        cls.write_obj(w, key=LAYOUT.field_grid, obj=obj.field_grid, py_type=GridLikeMixin)
        cls.write_obj(w, key=LAYOUT.pupil_grid, obj=obj.pupil_grid, py_type=GridLikeMixin)
        if obj.ray_grid is not None:
            ray_samples_w = w.group(LAYOUT.ray_samples)
            for index, sample in enumerate(obj.ray_grid):
                cls.write_obj(
                    ray_samples_w,
                    h5_index_name(index),
                    obj=sample,
                    py_type=RaySample)

    @classmethod
    def read(cls, r: H5Reader) -> RayTraceSettings:
        name = r.require_attr(LAYOUT.name, transform=str)
        wave_number = r.require_attr(LAYOUT.wave_number, transform=int)
        use_sensor_grid = r.attr(LAYOUT.use_sensor_grid, default=False, transform=bool)
        surface_numbers = r.ndarray(LAYOUT.surface_numbers, transform=lambda x: tuple(int(v) for v in x))
        current_end_surface_number = r.attr(LAYOUT.current_end_surface_number, transform=int)
        current_start_surface_number = r.attr(LAYOUT.current_start_surface_number, transform=int)
        grid = r.attr(LAYOUT.grid2d, transform=_to_int2)
        pol = r.attr(LAYOUT.pol4, transform=_to_pol4)
        rays_type = r.require_attr(LAYOUT.rays_type, transform=lambda x: RaysType[_decode_str(x)])
        method = r.require_attr(LAYOUT.method, transform=lambda x: TraceMethod[_decode_str(x)])
        opd = r.attr(LAYOUT.opd, default=OPDMode.None_, transform=lambda x: OPDMode[_decode_str(x)])
        raytrace_mode = r.require_attr(LAYOUT.raytrace_mode, transform=lambda x: RayTraceMode[_decode_str(x)])
        field_grid = cls.read_obj_typed(r, LAYOUT.field_grid, py_type=GridLikeMixin)
        pupil_grid = cls.read_obj_typed(r, LAYOUT.pupil_grid, py_type=GridLikeMixin)

        ray_grid = None
        ray_samples_r = r.group(LAYOUT.ray_samples)
        if ray_samples_r is not None:
            ray_grid = tuple(
                cls.require_obj_typed(ray_samples_r, key, RaySample)
                for key in sorted(ray_samples_r.grp.keys())
            )

        return RayTraceSettings(
            name=name,
            rays_type=rays_type,
            method=method,
            wave_number=wave_number,
            raytrace_mode=raytrace_mode,
            surface_numbers=surface_numbers,
            current_end_surface_number=current_end_surface_number,
            current_start_surface_number=current_start_surface_number,
            use_sensor_grid=use_sensor_grid,
            grid=grid,
            field_grid=field_grid,
            pupil_grid=pupil_grid,
            ray_grid=ray_grid,
            opd=opd,
            pol=pol,
        )


def _decode_str(v: Any) -> str:
    if isinstance(v, bytes):
        return v.decode("utf-8")
    return str(v)


def _to_int2(v: Any) -> tuple[int, int]:
    if len(v) != 2:
        raise ValueError(f"grid must have 2 elements, got {v!r}")
    return int(v[0]), int(v[1])


def _to_int2_array(v: Any) -> np.ndarray:
    if len(v) != 2:
        raise ValueError(f"grid must have 2 elements, got {v!r}")
    return np.asarray(v, dtype=int)


def _to_pol4_array(v: Any) -> np.ndarray:
    if len(v) != 4:
        raise ValueError(f"pol must have 4 elements, got {v!r}")
    return np.asarray(v, dtype=float)


def _to_pol4(v: Any) -> tuple[float, float, float, float]:
    if len(v) != 4:
        raise ValueError(f"pol must have 4 elements, got {v!r}")
    return float(v[0]), float(v[1]), float(v[2]), float(v[3])
