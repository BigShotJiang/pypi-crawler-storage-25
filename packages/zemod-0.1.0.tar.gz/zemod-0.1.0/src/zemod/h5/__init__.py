from __future__ import annotations
from h5kit.register.codec_registry import CodecRegistry
from zemod.h5.codec.grid_meta_codec import GridMetaCodec
from zemod.h5.codec.zernike_meta_codec import ZernikeMetaCodec
from zemod.h5.codec.rays_codec import RaysCodec
from zemod.h5.codec.raytrace_settings_codec import RayTraceSettingsCodec


def register_codecs(registry: CodecRegistry) -> None:
    registry.register(GridMetaCodec, py_type=GridMetaCodec.PY_TYPE)
    registry.register(ZernikeMetaCodec, py_type=ZernikeMetaCodec.PY_TYPE)
    registry.register(RaysCodec, py_type=RaysCodec.PY_TYPE)
    registry.register(RayTraceSettingsCodec, py_type=RayTraceSettingsCodec.PY_TYPE)