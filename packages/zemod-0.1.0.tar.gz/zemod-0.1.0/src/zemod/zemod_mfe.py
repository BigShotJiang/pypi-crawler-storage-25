from __future__ import annotations

from typing import TYPE_CHECKING

from zemod.core.native_adapter import NativeAdapter
from zemod.optimization.zemod_seq_optimization_wizard import  ZeModSEQOptimizationWizard

if TYPE_CHECKING:
    from zempy.zosapi.editors.mfe.protocols.i_merit_function_editor import IMeritFunctionEditor


class ZeModMFE(NativeAdapter["IMeritFunctionEditor"]):
    __slots__ = ()

    @property
    def n_operands(self) -> int:
        return int(self.native.NumberOfOperands)

    @property
    def merit_function_directory(self) -> str:
        return self.native.MeritFunctionDirectory

    def calculate(self) -> float:
        return float(self.native.CalculateMeritFunction())

    def save(self, file_name: str) -> None:
        self.native.SaveMeritFunction(file_name)

    def load(self, file_name: str) -> None:
        self.native.LoadMeritFunction(file_name)

    def insert(self, file_name: str, operand_number: int) -> int:
        return int(self.native.InsertMeritFunction(file_name, operand_number))

    def get_files(self) -> tuple[str, ...]:
        return tuple(self.native.GetMeritFunctionFiles())

    def get_operand_value(
        self,
        *,
        operand_type,
        surface: int = 0,
        wavelength: int = 0,
        hx: float = 0.0,
        hy: float = 0.0,
        px: float = 0.0,
        py: float = 0.0,
        ex: float = 0.0,
        ey: float = 0.0,
    ) -> float:
        return float(
            self.native.GetOperandValue(
                operand_type,
                surface,
                wavelength,
                hx,
                hy,
                px,
                py,
                ex,
                ey,
            )
        )

    def get_seq_optimization_wizard(self) -> ZeModSEQOptimizationWizard:
        return ZeModSEQOptimizationWizard(self.native.SEQOptimizationWizard)