from __future__ import annotations

from typing import TYPE_CHECKING

from zemod.core.native_adapter import NativeAdapter
from zemod.zemod_solve_data import ZeModSolveData
from zempy.zosapi.editors.enums.solve_type import SolveType

if TYPE_CHECKING:
    from zempy.zosapi.editors.protocols.i_editor_cell import IEditorCell


class ZeModCell(NativeAdapter["IEditorCell"]):
    __slots__ = ()

    @property
    def value(self) -> str:
        return self.native.Value

    @value.setter
    def value(self, value: str) -> None:
        self.native.Value = str(value)

    @property
    def double_value(self) -> float:
        return float(self.native.DoubleValue)

    @double_value.setter
    def double_value(self, value: float) -> None:
        self.native.DoubleValue = float(value)

    @property
    def integer_value(self) -> int:
        return int(self.native.IntegerValue)

    @integer_value.setter
    def integer_value(self, value: int) -> None:
        self.native.IntegerValue = int(value)

    @property
    def header(self) -> str:
        return self.native.Header

    @property
    def is_read_only(self) -> bool:
        return bool(self.native.IsReadOnly)

    @property
    def solve(self) -> SolveType:
        return self.native.Solve

    def make_variable(self) -> bool:
        return bool(self.native.MakeSolveVariable())

    def make_fixed(self) -> bool:
        return bool(self.native.MakeSolveFixed())

    def get_solve_data(self) -> ZeModSolveData:
        return ZeModSolveData(self.native.GetSolveData())

    def create_solve(self, solve_type: SolveType) -> ZeModSolveData:
        return ZeModSolveData(self.native.CreateSolveType(solve_type))

    def set_solve_data(self, solve_data: ZeModSolveData) -> None:
        self.native.SetSolveData(solve_data.native)