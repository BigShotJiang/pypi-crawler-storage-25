"""MCP Server for Wetherspoons API"""

__version__ = "1.2.3"
