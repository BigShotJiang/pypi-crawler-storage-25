from __future__ import annotations

import json

from typer.testing import CliRunner

from oacs.cli.main import app
from oacs.context.capsule import ContextCapsule


def test_cli_init_key_actor_memory(tmp_path):
    db = tmp_path / "oacs.db"
    runner = CliRunner()
    assert runner.invoke(app, ["init", "--db", str(db), "--json"]).exit_code == 0
    assert (
        runner.invoke(
            app, ["key", "init", "--db", str(db), "--passphrase", "pw", "--json"]
        ).exit_code
        == 0
    )
    actor = runner.invoke(
        app, ["actor", "create", "--db", str(db), "--type", "human", "--name", "User", "--json"]
    )
    assert actor.exit_code == 0
    proposed = runner.invoke(
        app,
        [
            "memory",
            "propose",
            "--db",
            str(db),
            "--type",
            "fact",
            "--depth",
            "2",
            "--text",
            "CLI memory",
            "--json",
        ],
    )
    assert proposed.exit_code == 0, proposed.output


def test_cli_capability_and_capsule_round_trip(tmp_path):
    db = tmp_path / "oacs.db"
    runner = CliRunner()
    assert runner.invoke(app, ["init", "--db", str(db), "--json"]).exit_code == 0
    assert (
        runner.invoke(
            app, ["key", "init", "--db", str(db), "--passphrase", "pw", "--json"]
        ).exit_code
        == 0
    )
    caps = runner.invoke(app, ["capability", "list", "--db", str(db), "--json"])
    assert caps.exit_code == 0
    assert "memory.read" in caps.output
    capsule = ContextCapsule(purpose="manual", token_budget=1, permissions={}).seal()
    file = tmp_path / "capsule.json"
    file.write_text(capsule.model_dump_json(), encoding="utf-8")
    validate = runner.invoke(
        app, ["context", "validate", "--db", str(db), "--file", str(file), "--json"]
    )
    assert validate.exit_code == 0, validate.output
    imported = runner.invoke(
        app, ["context", "import", "--db", str(db), "--file", str(file), "--json"]
    )
    assert imported.exit_code == 0, imported.output
    exported = runner.invoke(app, ["capsule", "export", capsule.id, "--db", str(db), "--json"])
    assert exported.exit_code == 0
    assert capsule.id in exported.output
    missing = runner.invoke(app, ["context", "lock", "ctx_missing", "--db", str(db), "--json"])
    assert missing.exit_code != 0


def test_cli_repo_is_not_core_surface():
    result = CliRunner().invoke(app, ["repo", "--help"])
    assert result.exit_code != 0


def test_cli_loop_run_emits_memory_calls(tmp_path):
    db = tmp_path / "oacs.db"
    runner = CliRunner()
    assert runner.invoke(app, ["init", "--db", str(db), "--json"]).exit_code == 0
    assert (
        runner.invoke(
            app, ["key", "init", "--db", str(db), "--passphrase", "pw", "--json"]
        ).exit_code
        == 0
    )
    proposed = runner.invoke(
        app,
        [
            "memory",
            "propose",
            "--db",
            str(db),
            "--type",
            "procedure",
            "--depth",
            "2",
            "--scope",
            "project",
            "--text",
            "Alpha reports use make report-safe.",
            "--json",
        ],
    )
    assert proposed.exit_code == 0, proposed.output
    memory_id = json.loads(proposed.output)["id"]
    committed = runner.invoke(
        app, ["memory", "commit", memory_id, "--db", str(db), "--json"]
    )
    assert committed.exit_code == 0, committed.output

    result = runner.invoke(
        app,
        [
            "loop",
            "run",
            "--db",
            str(db),
            "--request",
            "How do I generate the Alpha report?",
            "--scope",
            "project",
            "--json",
        ],
    )
    assert result.exit_code == 0, result.output
    assert "memory_calls" in result.output
    assert "memory.read" in result.output


def test_cli_grant_shared_memory_enforces_scope(tmp_path):
    db = tmp_path / "oacs.db"
    runner = CliRunner()
    assert runner.invoke(app, ["init", "--db", str(db), "--json"]).exit_code == 0
    assert (
        runner.invoke(
            app, ["key", "init", "--db", str(db), "--passphrase", "pw", "--json"]
        ).exit_code
        == 0
    )
    actor = runner.invoke(
        app,
        ["actor", "create", "--db", str(db), "--type", "agent", "--name", "Subagent", "--json"],
    )
    actor_id = json.loads(actor.output)["id"]
    grant = runner.invoke(
        app,
        [
            "capability",
            "grant-shared-memory",
            "--db",
            str(db),
            "--subject",
            actor_id,
            "--scope",
            "task:allowed",
            "--json",
        ],
    )
    assert grant.exit_code == 0, grant.output
    assert json.loads(grant.output)["grant"]["scope"] == ["task:allowed"]

    allowed = runner.invoke(
        app,
        [
            "memory",
            "propose",
            "--db",
            str(db),
            "--type",
            "fact",
            "--depth",
            "2",
            "--scope",
            "task:allowed",
            "--text",
            "allowed cli memory",
            "--json",
        ],
    )
    other = runner.invoke(
        app,
        [
            "memory",
            "propose",
            "--db",
            str(db),
            "--type",
            "fact",
            "--depth",
            "2",
            "--scope",
            "task:other",
            "--text",
            "other cli memory",
            "--json",
        ],
    )
    allowed_id = json.loads(allowed.output)["id"]
    other_id = json.loads(other.output)["id"]
    assert (
        runner.invoke(app, ["memory", "commit", allowed_id, "--db", str(db), "--json"]).exit_code
        == 0
    )
    assert (
        runner.invoke(app, ["memory", "commit", other_id, "--db", str(db), "--json"]).exit_code
        == 0
    )

    query = runner.invoke(
        app,
        [
            "memory",
            "query",
            "--db",
            str(db),
            "--actor",
            actor_id,
            "--scope",
            "task:allowed",
            "--query",
            "cli memory",
            "--json",
        ],
    )
    assert query.exit_code == 0, query.output
    assert allowed_id in query.output
    assert other_id not in query.output

    denied_read = runner.invoke(
        app,
        ["memory", "read", other_id, "--db", str(db), "--actor", actor_id, "--json"],
    )
    assert denied_read.exit_code != 0
