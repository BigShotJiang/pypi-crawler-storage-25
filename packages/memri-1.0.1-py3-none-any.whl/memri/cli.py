"""memri CLI — init, status, serve, mcp-server, dashboard, ingest."""

from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import Optional

import click
from rich.console import Console
from rich.table import Table

console = Console()


@click.group()
@click.version_option("1.0.0", prog_name="memri")
def main():
    """memri — observational memory for coding agents."""


# ─────────────────────────────── init ──────────────────────────────────


@main.command()
@click.option("--claude-code", "claude_code", is_flag=True, default=False,
              help="Configure memri in Claude Code settings.json")
@click.option("--all-agents", "all_agents", is_flag=True, default=False,
              help="Configure memri for all detected coding agents")
@click.option("--dry-run", is_flag=True, default=False,
              help="Show what would be done without making changes")
def init(claude_code: bool, all_agents: bool, dry_run: bool):
    """Initialize memri: create database, detect agents, configure MCP."""
    from .config import MemriConfig, MEMRI_DIR
    from .ingestion.auto_detect import detect_installed_agents, configure_claude_code

    console.print("\n[bold]memri init[/bold]\n")

    # Create config dir and DB
    MEMRI_DIR.mkdir(parents=True, exist_ok=True)
    config = MemriConfig.load()
    if not dry_run:
        config.save()

    from .storage.sqlite_store import SQLiteStore
    store = SQLiteStore(config.db_path)
    console.print(f"[green]ok[/green] Database: {config.db_path}")

    # Detect agents
    agents = detect_installed_agents()
    if agents:
        console.print(f"[green]ok[/green] Detected agents: {', '.join(agents)}")
    else:
        console.print("[yellow]warn[/yellow] No coding agents detected (Claude Code, Cursor, Codex)")

    # Configure agents
    if claude_code or all_agents or ("claude-code" in agents and not dry_run):
        success, msg = configure_claude_code(dry_run=dry_run)
        icon = "[green]ok[/green]" if success else "[red]err[/red]"
        console.print(f"{icon} Claude Code: {msg}")

    # Auto-detect best available provider if none configured
    import shutil
    from pathlib import Path
    claude_bin = shutil.which("claude")
    gcloud_creds = (
        Path.home() / ".config" / "gcloud" / "application_default_credentials.json"
    )

    no_key = not config.llm_api_key
    no_auth = config.llm_provider not in ("passive", "claude-code", "claude-code-auth", "gemini-adc")

    if no_key and no_auth:
        if claude_bin:
            if not dry_run:
                config.llm_provider = "claude-code"
                config.llm_model = "claude-haiku-4-5-20251001"
                config.save()
            console.print(
                "[green]ok[/green] LLM: Claude Code CLI detected — "
                "using [cyan]claude-code[/cyan] (no API key needed)"
            )
        elif gcloud_creds.exists():
            if not dry_run:
                config.llm_provider = "gemini-adc"
                config.llm_model = "gemini-2.0-flash"
                config.save()
            console.print(
                "[green]ok[/green] LLM: Google credentials detected — "
                "using [cyan]gemini-adc[/cyan] (no API key needed)"
            )
        else:
            console.print(
                "\n[yellow]No API key detected.[/yellow] "
                "Run [cyan]memri auth login[/cyan] to set one up, or:\n\n"
                "  [bold]Claude CLI[/bold]           →  install from claude.ai/code, "
                "run [cyan]claude[/cyan] once to log in\n"
                "  [bold]Google account[/bold]       →  run [cyan]gcloud auth application-default login[/cyan]\n"
                "  [bold]Free Gemini API key[/bold]  →  aistudio.google.com/apikey  (30 seconds, no card)\n"
                "  [bold]Ollama (local)[/bold]       →  ollama.ai  then set [cyan]llm_provider: openai-compatible[/cyan]\n"
                "  [bold]Passive mode[/bold]         →  set [cyan]llm_provider: passive[/cyan] in config\n"
            )
    else:
        console.print(
            "\n[bold]Ready.[/bold] Start the MCP server: [cyan]memri mcp-server[/cyan]\n"
        )


# ────────────────────────────── status ─────────────────────────────────


@main.command()
def status():
    """Show memory stats: sessions, tokens saved, costs."""
    from .config import MemriConfig
    from .core.memory import MemriMemory

    config = MemriConfig.load()
    memory = MemriMemory(config)
    stats = memory.get_stats()

    table = Table(title="Memri Memory Status", show_header=False, box=None,
                  padding=(0, 2))
    table.add_column("Key", style="dim")
    table.add_column("Value", style="bold")

    table.add_row("Threads", str(stats["threads"]))
    table.add_row("Messages", f"{stats['messages']:,}")
    table.add_row("Observation blocks", str(stats["observations"]))
    table.add_row("Tokens saved", f"{stats['tokens_saved']:,}")
    table.add_row("Cost saved (est.)", f"${stats['cost_saved_usd']:.4f}")
    table.add_row("Memri LLM cost", f"${stats['llm_cost_usd']:.4f}")
    net = stats["cost_saved_usd"] - stats["llm_cost_usd"]
    table.add_row("Net savings", f"${net:.4f}")
    if stats.get("oldest_memory"):
        table.add_row("Oldest memory", stats["oldest_memory"][:10])

    if stats.get("graph"):
        g = stats["graph"]
        table.add_row("─── Graph Memory ───", "")
        table.add_row("Facts", str(g["facts"]))
        table.add_row("Entities", str(g["entities"]))
        table.add_row("Reflections", str(g["reflections"]))
        table.add_row("Episodes (Layer 2)", str(g["episodes"]))
        table.add_row("Graph edges", str(g["edges"]))

    console.print(table)


# ──────────────────────────── mcp-server ───────────────────────────────


@main.command("mcp-server")
def mcp_server():
    """Start the MCP server (called by Claude Code / Cursor)."""
    from .mcp.server import run
    run()


# ─────────────────────────────── watch ─────────────────────────────────


@main.command()
@click.option("--path", "extra_paths", multiple=True,
              help="Additional paths to watch (repeatable)")
@click.option("--auto-observe", is_flag=True, default=False,
              help="Run observer automatically when a thread exceeds the threshold")
def watch(extra_paths: tuple, auto_observe: bool):
    """Watch for new coding-agent sessions and ingest them in real time.

    Monitors ~/.claude/projects/ (and Cursor/Codex dirs if present).
    Runs until Ctrl+C.
    """
    from .config import MemriConfig
    from .core.memory import MemriMemory
    from .ingestion.watcher import SessionWatcher, default_watch_paths

    config = MemriConfig.load()
    memory = MemriMemory(config)

    paths = default_watch_paths() + [Path(p) for p in extra_paths]
    if not paths:
        console.print("[red]err[/red] No agent session directories found to watch.")
        console.print("     Pass --path to specify a directory manually.")
        return

    console.print("\n[bold]memri watch[/bold]  (Ctrl+C to stop)\n")
    for p in paths:
        console.print(f"[green]ok[/green] Watching {p}")
    console.print()

    total_ingested = 0

    def on_ingest(path: str, added: int):
        nonlocal total_ingested
        total_ingested += added
        short = Path(path).name
        console.print(f"[green]+{added}[/green] {short}  ({total_ingested:,} total)")

    async def _run():
        watcher = SessionWatcher(memory, paths, on_ingest=on_ingest)

        if auto_observe:
            async def _observer_loop():
                while True:
                    await asyncio.sleep(60)
                    await memory.observe_all()
            asyncio.create_task(_observer_loop())

        await watcher.run_forever()

    try:
        asyncio.run(_run())
    except KeyboardInterrupt:
        console.print(f"\n[dim]Stopped. {total_ingested:,} messages ingested this session.[/dim]")


# ────────────────────────────── dashboard ──────────────────────────────


@main.command()
@click.option("--host", default="127.0.0.1", show_default=True)
@click.option("--port", default=8050, show_default=True)
def dashboard(host: str, port: int):
    """Open the local web dashboard."""
    from .dashboard.app import run
    console.print(f"[green]Dashboard running at[/green] http://{host}:{port}")
    run(host=host, port=port)


# ──────────────────────────── ingest ───────────────────────────────────


@main.command()
@click.option("--agent", default="claude-code",
              type=click.Choice(["claude-code", "cursor", "codex"]),
              show_default=True)
@click.option("--path", "sessions_path", default=None,
              help="Custom path to sessions directory")
def ingest(agent: str, sessions_path: Optional[str]):
    """Ingest existing coding agent sessions into memory."""
    from .config import MemriConfig
    from .core.memory import MemriMemory

    config = MemriConfig.load()
    memory = MemriMemory(config)

    async def _run():
        if agent == "claude-code":
            from .ingestion.claude_code import ingest_all_sessions
            path = Path(sessions_path) if sessions_path else None
            results = await ingest_all_sessions(memory, path)
        elif agent == "cursor":
            from .ingestion.cursor import ingest_all_sessions
            path = Path(sessions_path) if sessions_path else None
            results = await ingest_all_sessions(memory, path)
        else:
            from .ingestion.codex import ingest_all_sessions
            path = Path(sessions_path) if sessions_path else None
            results = await ingest_all_sessions(memory, path)
        return results

    results = asyncio.run(_run())
    total = sum(results.values())
    console.print(
        f"[green]ok[/green] Ingested {total:,} messages from {len(results)} session(s)"
    )


# ────────────────────────────── observe ────────────────────────────────


@main.command()
@click.option("--thread", default=None, help="Only observe a specific thread ID")
def observe(thread: Optional[str]):
    """Run the Observer on all threads with enough unobserved tokens.

    Compresses raw messages into dense observation blocks.
    Safe to run multiple times — skips threads already under the threshold.
    """
    from .config import MemriConfig
    from .core.memory import MemriMemory

    config = MemriConfig.load()
    memory = MemriMemory(config)

    threads = memory.store.list_threads()
    if thread:
        threads = [t for t in threads if t.id == thread]

    total_queued = 0
    for t in threads:
        unobserved = memory.store.get_messages(t.id, unobserved_only=True)
        tok = sum(m.token_count for m in unobserved)
        if tok >= config.observe_threshold:
            total_queued += tok

    if not total_queued:
        console.print("[dim]No threads exceed the observe threshold. Nothing to do.[/dim]")
        return

    console.print(f"Processing {total_queued:,} unobserved tokens across {len(threads)} thread(s)...\n")

    from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn
    import asyncio

    cycles_total = 0

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TaskProgressColumn(),
        console=console,
        transient=True,
    ) as progress:
        task = progress.add_task("Observing...", total=len(threads))

        async def _run():
            nonlocal cycles_total
            for t in threads:
                progress.update(task, description=f"[cyan]{t.id[:8]}[/cyan]")
                cycles = 0
                while True:
                    unobserved = memory.store.get_messages(t.id, unobserved_only=True)
                    tok = sum(m.token_count for m in unobserved)
                    if tok < config.observe_threshold:
                        break
                    await memory._run_observer(t.id, unobserved)
                    cycles += 1
                cycles_total += cycles
                progress.advance(task)

        asyncio.run(_run())

    stats = memory.get_stats()
    console.print(f"[green]ok[/green] {cycles_total} observation cycle(s) completed")
    console.print(f"   Observation blocks: {stats['observations']}")
    console.print(f"   Tokens saved: {stats['tokens_saved']:,}")
    console.print(f"   Cost saved (est.): ${stats['cost_saved_usd']:.4f}")
    console.print(f"   Memri cost: ${stats['llm_cost_usd']:.4f}")


# ─────────────────────────── embed ─────────────────────────────────────


@main.command()
def embed():
    """Build semantic search index from all observation blocks.

    Requires: pip install 'memri[embeddings]'
    """
    from .config import MemriConfig
    from .core.memory import MemriMemory

    config = MemriConfig.load()
    memory = MemriMemory(config)

    if not memory.embedder.available:
        console.print("[red]err[/red] sentence-transformers not installed.")
        console.print("     Run: pip install 'memri[embeddings]'")
        return

    obs_count = len(memory.store.get_all_observations())
    if not obs_count:
        console.print("[dim]No observation blocks to embed. Run `memri observe` first.[/dim]")
        return

    console.print(f"Embedding {obs_count} observation block(s)...")

    count = [0]

    def cb(tid, n):
        count[0] = n
        console.print(f"  [{n}/{obs_count}] {tid[:8]}", end="\r")

    total = memory.build_embeddings(progress_cb=cb)
    console.print(f"\n[green]ok[/green] Built embeddings for {total} observation block(s)")


# ──────────────────────────── auth ─────────────────────────────────────


@main.group()
def auth():
    """Manage LLM authentication."""


@auth.command("login")
@click.option("--provider", default=None,
              type=click.Choice(["claude", "gemini", "anthropic", "openai", "ollama"]),
              help="Provider to configure (auto-detected if omitted)")
def auth_login(provider: Optional[str]):
    """Interactively connect memri to an LLM provider.

    Auto-detects the best option: Claude subscription, Google account,
    free Gemini API, or manual API key entry.
    """
    import shutil
    from pathlib import Path
    from .config import MemriConfig

    config = MemriConfig.load()

    claude_bin = shutil.which("claude")
    gcloud_creds = Path.home() / ".config" / "gcloud" / "application_default_credentials.json"

    if provider in (None, "claude") and claude_bin:
        config.llm_provider = "claude-code"
        config.llm_model = "claude-haiku-4-5-20251001"
        config.save()
        console.print(
            "[green]ok[/green] Configured [cyan]claude-code[/cyan] — "
            "using Claude Code CLI (no API key needed)"
        )
        return

    if provider in (None, "claude") and not claude_bin:
        console.print(
            "[yellow]warn[/yellow] Claude Code CLI not found in PATH.\n"
            "       The CLI is separate from the VS Code extension.\n"
            "       Install from claude.ai/code, run 'claude' once, then re-run this command.\n"
            "       Falling back to other options...\n"
        )

    if provider in (None, "gemini") and gcloud_creds.exists():
        config.llm_provider = "gemini-adc"
        config.llm_model = "gemini-2.0-flash"
        config.save()
        console.print(
            "[green]ok[/green] Configured [cyan]gemini-adc[/cyan] — "
            "using your Google account credentials (no API key needed)"
        )
        return

    # Manual key entry
    console.print("\n[bold]No subscription credentials detected.[/bold]\n")
    console.print("Choose an option:\n")
    console.print("  [cyan]1[/cyan]  Claude subscription  →  run [bold]claude[/bold] once to log in, then re-run this command")
    console.print("  [cyan]2[/cyan]  Google account       →  run [bold]gcloud auth application-default login[/bold], then re-run")
    console.print("  [cyan]3[/cyan]  Free Gemini API key  →  [link=https://aistudio.google.com/apikey]aistudio.google.com/apikey[/link]  (30 sec, no card)")
    console.print("  [cyan]4[/cyan]  Anthropic API key    →  [link=https://console.anthropic.com]console.anthropic.com[/link]")
    console.print("  [cyan]5[/cyan]  Ollama (local)       →  [link=https://ollama.ai]ollama.ai[/link]\n")

    choice = click.prompt("Option", type=click.Choice(["1", "2", "3", "4", "5"]), default="3")

    if choice == "3":
        key = click.prompt("Paste your Gemini API key", hide_input=True)
        env_file = Path.home() / ".memri" / ".env"
        with open(env_file, "a") as f:
            f.write(f"\nGEMINI_API_KEY={key}\n")
        config.llm_provider = "gemini"
        config.llm_model = "gemini-2.0-flash"
        config.save()
        console.print("[green]ok[/green] Gemini API key saved to ~/.memri/.env")

    elif choice == "4":
        key = click.prompt("Paste your Anthropic API key", hide_input=True)
        env_file = Path.home() / ".memri" / ".env"
        with open(env_file, "a") as f:
            f.write(f"\nANTHROPIC_API_KEY={key}\n")
        config.llm_provider = "anthropic"
        config.llm_model = "claude-haiku-4-5-20251001"
        config.save()
        console.print("[green]ok[/green] Anthropic API key saved to ~/.memri/.env")

    elif choice == "5":
        model = click.prompt("Ollama model name", default="llama3")
        config.llm_provider = "openai-compatible"
        config.llm_base_url = "http://localhost:11434/v1"
        config.llm_model = model
        config.save()
        console.print(f"[green]ok[/green] Configured Ollama with model [cyan]{model}[/cyan]")

    else:
        console.print("[dim]Re-run [cyan]memri auth login[/cyan] after completing the step above.[/dim]")
        return

    console.print("\n[bold]Ready.[/bold] Start the MCP server: [cyan]memri mcp-server[/cyan]")


# ─────────────────────────── config ────────────────────────────────────


@main.command("config")
@click.option("--show", is_flag=True, default=False, help="Show current config")
@click.option("--set", "set_kv", nargs=2, metavar="KEY VALUE", multiple=True,
              help="Set a config key (repeatable)")
def config_cmd(show: bool, set_kv: tuple):
    """View or update memri configuration."""
    from .config import MemriConfig

    config = MemriConfig.load()

    if set_kv:
        for key, value in set_kv:
            if hasattr(config, key):
                # Attempt type coercion
                current = getattr(config, key)
                if isinstance(current, int):
                    value = int(value)
                elif isinstance(current, bool):
                    value = value.lower() in ("1", "true", "yes")
                setattr(config, key, value)
                console.print(f"[green]ok[/green] {key} = {value}")
            else:
                console.print(f"[red]err[/red] Unknown config key: {key}")
        config.save()

    if show or not set_kv:
        import dataclasses
        data = dataclasses.asdict(config)
        data.pop("llm_api_key", None)  # Never display API keys
        console.print_json(json.dumps(data, indent=2))
