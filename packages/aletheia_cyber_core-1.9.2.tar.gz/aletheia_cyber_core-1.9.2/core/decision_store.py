from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
import sqlite3
import tempfile
import time
from dataclasses import dataclass

import httpx

from core.config import upstash_configured
from core.persistence import tenant_scope

_logger = logging.getLogger("aletheia.decision_store")

_REDIS_PREFIX = "aletheia:decision:"
_BUNDLE_KEY = "aletheia:policy_bundle"
_DEFAULT_TTL_SECONDS = 3600


@dataclass(frozen=True)
class ReplayCheckResult:
    accepted: bool
    reason: str


class _SQLiteDecisionStore:
    def __init__(self, db_path: str | None = None) -> None:
        self._db_path = db_path or os.getenv(
            "ALETHEIA_DECISION_DB_PATH",
            os.path.join(tempfile.gettempdir(), "aletheia", "decisions.sqlite3"),
        )
        self._lock = asyncio.Lock()
        # Enforce restrictive permissions on decision DB file
        from pathlib import Path as _Path

        db_file = _Path(self._db_path)
        db_file.parent.mkdir(parents=True, exist_ok=True)
        db_file.touch(exist_ok=True)
        try:
            os.chmod(self._db_path, 0o600)
        except OSError:
            pass  # best-effort
        self._init_db()

    @property
    def backend(self) -> str:
        return "sqlite"

    def _init_db(self) -> None:
        conn = sqlite3.connect(self._db_path)
        try:
            cur = conn.cursor()
            cur.execute(
                """
                CREATE TABLE IF NOT EXISTS decision_tokens (
                    token TEXT NOT NULL,
                    tenant_id TEXT NOT NULL DEFAULT 'default',
                    request_id TEXT NOT NULL,
                    issued_at INTEGER NOT NULL,
                    expires_at INTEGER NOT NULL,
                    policy_version TEXT NOT NULL,
                    manifest_hash TEXT NOT NULL,
                    PRIMARY KEY (token, tenant_id)
                )
                """
            )
            cur.execute(
                """
                CREATE TABLE IF NOT EXISTS deployment_bundle (
                    id INTEGER NOT NULL CHECK (id = 1),
                    tenant_id TEXT NOT NULL DEFAULT 'default',
                    policy_version TEXT NOT NULL,
                    manifest_hash TEXT NOT NULL,
                    updated_at INTEGER NOT NULL,
                    PRIMARY KEY (id, tenant_id)
                )
                """
            )
            # Migration: add tenant_id if missing (old single-PK schema)
            try:
                cur.execute(
                    "ALTER TABLE decision_tokens ADD COLUMN tenant_id TEXT NOT NULL DEFAULT 'default'"
                )
            except sqlite3.OperationalError:
                pass
            try:
                cur.execute(
                    "ALTER TABLE deployment_bundle ADD COLUMN tenant_id TEXT NOT NULL DEFAULT 'default'"
                )
            except sqlite3.OperationalError:
                pass
            conn.commit()
        finally:
            conn.close()

    async def claim_token(
        self,
        *,
        token: str,
        request_id: str,
        policy_version: str,
        manifest_hash: str,
        now_ts: int,
        ttl_seconds: int = _DEFAULT_TTL_SECONDS,
        tenant_id: str | None = None,
    ) -> ReplayCheckResult:
        tid = tenant_scope(tenant_id)
        async with self._lock:
            conn = sqlite3.connect(self._db_path)
            try:
                cur = conn.cursor()
                cur.execute(
                    "DELETE FROM decision_tokens WHERE expires_at < ? AND tenant_id = ?",
                    (now_ts, tid),
                )
                try:
                    cur.execute(
                        """
                        INSERT INTO decision_tokens (
                            token, tenant_id, request_id, issued_at, expires_at, policy_version, manifest_hash
                        ) VALUES (?, ?, ?, ?, ?, ?, ?)
                        """,
                        (
                            token,
                            tid,
                            request_id,
                            now_ts,
                            now_ts + ttl_seconds,
                            policy_version,
                            manifest_hash,
                        ),
                    )
                except sqlite3.IntegrityError:
                    return ReplayCheckResult(accepted=False, reason="replay_detected")
                conn.commit()
                return ReplayCheckResult(accepted=True, reason="accepted")
            finally:
                conn.close()

    async def verify_bundle(
        self,
        *,
        policy_version: str,
        manifest_hash: str,
        now_ts: int,
        tenant_id: str | None = None,
    ) -> ReplayCheckResult:
        tid = tenant_scope(tenant_id)
        async with self._lock:
            conn = sqlite3.connect(self._db_path)
            try:
                cur = conn.cursor()
                row = cur.execute(
                    "SELECT policy_version, manifest_hash FROM deployment_bundle WHERE id = 1 AND tenant_id = ?",
                    (tid,),
                ).fetchone()
                if row is None:
                    cur.execute(
                        "INSERT INTO deployment_bundle (id, tenant_id, policy_version, manifest_hash, updated_at) VALUES (1, ?, ?, ?, ?)",
                        (tid, policy_version, manifest_hash, now_ts),
                    )
                    conn.commit()
                    return ReplayCheckResult(accepted=True, reason="bundle_registered")

                existing_version, existing_hash = row
                if existing_version != policy_version or existing_hash != manifest_hash:
                    return ReplayCheckResult(
                        accepted=False, reason="partial_deployment_drift"
                    )
                return ReplayCheckResult(accepted=True, reason="bundle_verified")
            finally:
                conn.close()


class _UpstashDecisionStore:
    def __init__(self) -> None:
        self._url = os.getenv("UPSTASH_REDIS_REST_URL", "").rstrip("/")
        self._token = os.getenv("UPSTASH_REDIS_REST_TOKEN", "")
        self._headers = {
            "Authorization": f"Bearer {self._token}",
            "Content-Type": "application/json",
        }

    @property
    def backend(self) -> str:
        return "upstash"

    async def _pipeline(self, commands: list[list[str]]) -> list[dict]:
        async with httpx.AsyncClient(timeout=2.0) as client:
            resp = await client.post(
                f"{self._url}/pipeline",
                headers=self._headers,
                json=commands,
            )
            resp.raise_for_status()
            return resp.json()

    async def claim_token(
        self,
        *,
        token: str,
        request_id: str,
        policy_version: str,
        manifest_hash: str,
        now_ts: int,
        ttl_seconds: int = _DEFAULT_TTL_SECONDS,
        tenant_id: str | None = None,
    ) -> ReplayCheckResult:
        tid = tenant_scope(tenant_id)
        redis_key = f"tenant:{tid}:decision:{token}"
        value = json.dumps(
            {
                "request_id": request_id,
                "policy_version": policy_version,
                "manifest_hash": manifest_hash,
                "issued_at": now_ts,
            },
            sort_keys=True,
        )
        payload = [
            ["SET", redis_key, value, "NX", "EX", str(ttl_seconds)],
        ]
        result = await self._pipeline(payload)
        accepted = bool(result and result[0].get("result") == "OK")
        if not accepted:
            return ReplayCheckResult(accepted=False, reason="replay_detected")
        return ReplayCheckResult(accepted=True, reason="accepted")

    async def verify_bundle(
        self,
        *,
        policy_version: str,
        manifest_hash: str,
        now_ts: int,
        tenant_id: str | None = None,
    ) -> ReplayCheckResult:
        tid = tenant_scope(tenant_id)
        bundle_key = f"tenant:{tid}:policy_bundle"
        expected = json.dumps(
            {"policy_version": policy_version, "manifest_hash": manifest_hash},
            sort_keys=True,
        )
        result = await self._pipeline(
            [
                ["SET", bundle_key, expected, "NX", "EX", str(24 * 3600)],
                ["GET", bundle_key],
            ]
        )
        current = ""
        if len(result) > 1:
            current = result[1].get("result") or ""
        if current and current != expected:
            return ReplayCheckResult(accepted=False, reason="partial_deployment_drift")
        return ReplayCheckResult(accepted=True, reason="bundle_verified")


class DecisionStore:
    """Distributed replay and deployment-drift guard with fail-closed degraded mode.

    In production (ENVIRONMENT=production), a distributed backend (Upstash Redis)
    is required. SQLite fallback is single-node only and refuses to start in production.
    """

    def __init__(self) -> None:
        self._central_available = upstash_configured()
        if not self._central_available:
            # Refuse SQLite fallback in production
            if os.getenv("ENVIRONMENT", "").lower() == "production":
                _logger.critical(
                    "FATAL: Decision store requires a distributed backend in production. "
                    "Set UPSTASH_REDIS_REST_URL + UPSTASH_REDIS_REST_TOKEN or configure "
                    "PostgreSQL. SQLite fallback is not safe for multi-worker deployments. "
                    "Refusing to start."
                )
                import sys

                sys.exit(1)
        self._store = (
            _UpstashDecisionStore()
            if self._central_available
            else _SQLiteDecisionStore()
        )
        self._degraded = False

    @property
    def backend(self) -> str:
        return self._store.backend

    @property
    def degraded(self) -> bool:
        return self._degraded

    async def verify_policy_bundle(
        self, policy_version: str, manifest_hash: str, *, tenant_id: str | None = None
    ) -> ReplayCheckResult:
        now_ts = int(time.time())
        try:
            return await self._store.verify_bundle(
                policy_version=policy_version,
                manifest_hash=manifest_hash,
                now_ts=now_ts,
                tenant_id=tenant_id,
            )
        except Exception as exc:
            _logger.error("Decision store bundle verification failure: %s", exc)
            self._degraded = True
            return ReplayCheckResult(
                accepted=False, reason="decision_store_unavailable"
            )

    async def claim_decision(
        self,
        *,
        request_id: str,
        timestamp_iso: str,
        policy_version: str,
        manifest_hash: str,
        ttl_seconds: int = _DEFAULT_TTL_SECONDS,
        tenant_id: str | None = None,
    ) -> ReplayCheckResult:
        # Deterministic token binding for replay defense.
        token_src = f"{request_id}|{timestamp_iso}|{policy_version}|{manifest_hash}"
        token = hashlib.sha256(token_src.encode("utf-8")).hexdigest()
        now_ts = int(time.time())
        try:
            return await self._store.claim_token(
                token=token,
                request_id=request_id,
                policy_version=policy_version,
                manifest_hash=manifest_hash,
                now_ts=now_ts,
                ttl_seconds=ttl_seconds,
                tenant_id=tenant_id,
            )
        except Exception as exc:
            _logger.error("Decision store claim failure: %s", exc)
            self._degraded = True
            return ReplayCheckResult(
                accepted=False, reason="decision_store_unavailable"
            )


decision_store = DecisionStore()
