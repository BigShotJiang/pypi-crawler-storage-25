import base64
import hashlib
import json
import os
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import logging as _logging

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)

_signing_logger = _logging.getLogger("aletheia.signing")

# Grace period: manifests within this window of expiry produce a warning
# but are still accepted. Beyond this, they are hard-rejected.
_GRACE_PERIOD_DAYS = 7


class ManifestTamperedError(RuntimeError):
    """Raised when manifest integrity verification fails."""


@dataclass(frozen=True)
class ManifestSignature:
    algorithm: str
    key_id: str
    key_version: str
    manifest_version: str
    payload_sha256: str
    signature_b64: str
    signed_at: str
    expires_at: str

    def as_json(self) -> dict[str, Any]:
        return {
            "algorithm": self.algorithm,
            "key_id": self.key_id,
            "key_version": self.key_version,
            "manifest_version": self.manifest_version,
            "payload_sha256": self.payload_sha256,
            "signature": self.signature_b64,
            "signed_at": self.signed_at,
            "expires_at": self.expires_at,
        }


def _repo_root() -> Path:
    return Path(__file__).resolve().parent.parent


def _resolve_path(path: str | Path) -> Path:
    candidate = Path(path)
    if candidate.is_absolute():
        return candidate
    return _repo_root() / candidate


def _read_bytes(path: Path) -> bytes:
    try:
        return path.read_bytes()
    except FileNotFoundError as exc:
        raise ManifestTamperedError(f"Required file missing: {path}") from exc


def _public_key_id(public_key: Ed25519PublicKey) -> str:
    public_raw = public_key.public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    return hashlib.sha256(public_raw).hexdigest()


def _load_manifest_metadata(payload: bytes) -> tuple[str, str]:
    try:
        data = json.loads(payload.decode("utf-8"))
    except Exception as exc:
        raise ManifestTamperedError("Manifest is not valid JSON.") from exc

    version = str(data.get("version", "")).strip()
    expires_at = str(data.get("expires_at", "")).strip()
    if not version:
        raise ManifestTamperedError("Manifest version is required.")
    if not expires_at:
        raise ManifestTamperedError("Manifest expires_at is required.")
    return version, expires_at


def _load_private_key(private_key_path: Path) -> Ed25519PrivateKey:
    key_bytes = _read_bytes(private_key_path)
    return serialization.load_pem_private_key(key_bytes, password=None)


def _load_public_key(public_key_path: Path) -> Ed25519PublicKey:
    key_bytes = _read_bytes(public_key_path)
    pub_key = serialization.load_pem_public_key(key_bytes)
    if not isinstance(pub_key, Ed25519PublicKey):
        raise ManifestTamperedError("Public key is not Ed25519.")
    return pub_key


def generate_keypair(private_key_path: str | Path, public_key_path: str | Path) -> None:
    private_path = _resolve_path(private_key_path)
    public_path = _resolve_path(public_key_path)
    private_path.parent.mkdir(parents=True, exist_ok=True)
    public_path.parent.mkdir(parents=True, exist_ok=True)

    private_key = Ed25519PrivateKey.generate()
    public_key = private_key.public_key()

    private_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    public_pem = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )

    private_path.write_bytes(private_pem)
    os.chmod(private_path, 0o600)
    public_path.write_bytes(public_pem)


def sign_manifest(
    manifest_path: str | Path,
    signature_path: str | Path,
    private_key_path: str | Path,
    public_key_path: str | Path,
) -> Path:
    manifest = _resolve_path(manifest_path)
    signature = _resolve_path(signature_path)
    private_path = _resolve_path(private_key_path)
    public_path = _resolve_path(public_key_path)

    if not private_path.exists() or not public_path.exists():
        generate_keypair(private_path, public_path)

    payload = _read_bytes(manifest)
    manifest_version, expires_at = _load_manifest_metadata(payload)
    payload_hash = hashlib.sha256(payload).hexdigest()

    private_key = _load_private_key(private_path)
    public_key = _load_public_key(public_path)
    signature_bytes = private_key.sign(payload)

    signed = ManifestSignature(
        algorithm="ed25519",
        key_id=_public_key_id(public_key),
        key_version=os.getenv("ALETHEIA_MANIFEST_KEY_VERSION", "v1"),
        manifest_version=manifest_version,
        payload_sha256=payload_hash,
        signature_b64=base64.b64encode(signature_bytes).decode("ascii"),
        signed_at=datetime.now(timezone.utc).isoformat(),
        expires_at=expires_at,
    )

    signature.write_text(json.dumps(signed.as_json(), indent=2), encoding="utf-8")
    return signature


def verify_manifest_signature(
    manifest_path: str | Path,
    signature_path: str | Path,
    public_key_path: str | Path,
) -> None:
    """Security-critical gate: manifest is rejected if detached signature fails."""
    manifest = _resolve_path(manifest_path)
    signature = _resolve_path(signature_path)
    public_path = _resolve_path(public_key_path)

    payload = _read_bytes(manifest)
    manifest_version, manifest_expires_at = _load_manifest_metadata(payload)
    payload_hash = hashlib.sha256(payload).hexdigest()

    public_key = _load_public_key(public_path)
    expected_key_id = _public_key_id(public_key)

    try:
        signature_data = json.loads(_read_bytes(signature).decode("utf-8"))
    except json.JSONDecodeError as exc:
        raise ManifestTamperedError(
            "Manifest signature file is not valid JSON."
        ) from exc

    required_fields = {
        "algorithm",
        "key_id",
        "key_version",
        "manifest_version",
        "payload_sha256",
        "signature",
        "signed_at",
        "expires_at",
    }
    if not required_fields.issubset(signature_data):
        raise ManifestTamperedError("Manifest signature file missing required fields.")

    if signature_data["algorithm"] != "ed25519":
        raise ManifestTamperedError("Unsupported manifest signature algorithm.")

    if signature_data["key_id"] != expected_key_id:
        raise ManifestTamperedError("Manifest signature key mismatch.")

    expected_key_version = os.getenv("ALETHEIA_MANIFEST_KEY_VERSION", "v1")
    if signature_data["key_version"] != expected_key_version:
        raise ManifestTamperedError("Manifest signature key version mismatch.")

    if signature_data["manifest_version"] != manifest_version:
        raise ManifestTamperedError("Manifest version drift detected.")

    if signature_data["expires_at"] != manifest_expires_at:
        raise ManifestTamperedError("Manifest expiry metadata mismatch.")

    try:
        expiry = datetime.fromisoformat(
            str(signature_data["expires_at"]).replace("Z", "+00:00")
        )
    except Exception as exc:
        raise ManifestTamperedError("Manifest expiry is malformed.") from exc

    now = datetime.now(timezone.utc)
    from datetime import timedelta

    grace_deadline = expiry + timedelta(days=_GRACE_PERIOD_DAYS)

    if now > grace_deadline:
        raise ManifestTamperedError(
            f"Manifest expired on {expiry.isoformat()} and the "
            f"{_GRACE_PERIOD_DAYS}-day grace period has elapsed."
        )
    if now > expiry:
        days_past = (now - expiry).days
        _signing_logger.warning(
            "Manifest expired %d day(s) ago on %s. "
            "Grace period: %d of %d days remaining. "
            "Re-sign the manifest before the grace period ends.",
            days_past,
            expiry.isoformat(),
            _GRACE_PERIOD_DAYS - days_past,
            _GRACE_PERIOD_DAYS,
        )

    if signature_data["payload_sha256"] != payload_hash:
        raise ManifestTamperedError("Manifest hash mismatch; file has been modified.")

    try:
        signature_bytes = base64.b64decode(signature_data["signature"], validate=True)
    except (ValueError, TypeError) as exc:
        raise ManifestTamperedError("Manifest signature encoding is invalid.") from exc

    if len(signature_bytes) != 64:
        raise ManifestTamperedError("Manifest signature length is invalid.")

    try:
        public_key.verify(signature_bytes, payload)
    except Exception as exc:
        raise ManifestTamperedError("Manifest signature verification failed.") from exc
