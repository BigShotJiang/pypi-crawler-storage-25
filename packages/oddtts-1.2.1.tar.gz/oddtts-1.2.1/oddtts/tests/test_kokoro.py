from kokoro import KPipeline
import soundfile as sf
import numpy as np
import torch


def test_kokoro():
    # 初始化中文管线
    pipeline = KPipeline(lang_code='z')

    # 生成语音
    text = "关注我的公众号：奥德元，一起学习 A I，一起追赶时代。"
    generator = pipeline(text, voice='zm_yunyang')

    # 获取生成结果 (这是一个 KPipeline.Result 对象)
    result = next(generator)

    # --- 核心修改：正确提取音频数据 ---

    # 1. 访问 result.output.audio 获取 tensor
    # 根据日志: result.output 是 KModel.Output 对象，里面有个 audio 属性是 tensor
    audio_tensor = result.output.audio

    # 2. 将 PyTorch Tensor 转换为 NumPy 数组
    # .detach() 移除梯度追踪，.cpu() 确保在CPU内存中，.numpy() 转为 numpy
    audio_numpy = audio_tensor.detach().cpu().numpy()

    # 3. 处理维度
    # soundfile 需要 (样本数, 通道数) 的二维数组。
    # Kokoro 输出的通常是 (样本数,) 的一维数组，我们需要变成 (样本数, 1)
    if audio_numpy.ndim == 1:
        audio_numpy = audio_numpy.reshape(-1, 1)

    # 4. 获取采样率
    # Kokoro 的标准采样率通常是 24000，也可以检查是否有属性直接提供
    sample_rate = 24000 

    # 5. 写入文件
    sf.write('output.wav', audio_numpy, sample_rate)

    print(f"音频保存成功！")
    print(f"音频形状: {audio_numpy.shape}")
    print(f"采样率: {sample_rate}")
    print(f"文本内容: {result.graphemes}")
    
if __name__ == '__main__':
    test_kokoro()