"""CLI-level tests for `irc-lens serve`.

Phase 4 only validates the argparse surface and the fail-fast contract
(no AgentIRC server needed). The end-to-end "boot, hit URLs, drive
flow" smoke is tested against the real AgentIRC fixture in Phase 9b.

`cmd_serve` runs everything inside one `asyncio.run(_serve_async(...))`
(so the IRC connection's read task survives until the web server
shuts down). To avoid actually binding ports or blocking on
``asyncio.Event().wait()`` here, the `stub_aiohttp_runtime` fixture
replaces `aiohttp.web.AppRunner`, `aiohttp.web.TCPSite`, and
`asyncio.Event` with no-op shims.
"""

from __future__ import annotations

import asyncio
from pathlib import Path

import pytest

from irc_lens.cli import main
from irc_lens.session import LensConnectionLost


# ---------------------------------------------------------------------------
# Test doubles for the aiohttp runtime (no actual bind)
# ---------------------------------------------------------------------------


class _FakeRunner:
    def __init__(self, app, *_a, **_kw) -> None:
        self.app = app
        self.setup_called = False
        self.cleanup_called = False

    async def setup(self) -> None:
        self.setup_called = True

    async def cleanup(self) -> None:
        self.cleanup_called = True


class _FakeSite:
    def __init__(self, runner, host: str, port: int) -> None:
        self.runner = runner
        self.host = host
        self.port = port

    async def start(self) -> None:
        return None


class _BoomSite(_FakeSite):
    """TCPSite whose start() raises OSError (port-in-use simulation)."""

    async def start(self) -> None:
        raise OSError(98, "Address already in use")


class _ImmediateEvent:
    """`asyncio.Event` replacement whose `wait()` returns immediately.

    Python's default constructor is sufficient — no instance state needed.
    """

    async def wait(self) -> None:
        return None


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture
def stub_aiohttp_runtime(monkeypatch: pytest.MonkeyPatch):
    """Replace aiohttp's runner / site / wait-forever so cmd_serve exits."""
    monkeypatch.setattr("aiohttp.web.AppRunner", _FakeRunner)
    monkeypatch.setattr("aiohttp.web.TCPSite", _FakeSite)
    monkeypatch.setattr("asyncio.Event", _ImmediateEvent)


@pytest.fixture
def dev_config_path(tmp_path: Path) -> Path:
    """Write a minimal valid dev-mode config to a tmp file and return its path."""
    p = tmp_path / "config.yaml"
    p.write_text(
        "auth:\n"
        "  mode: dev\n"
        "  dev:\n"
        "    nick: lens-test\n"
        "    email: dev@local\n"
        "server:\n"
        "  name: spark\n"
        "  host: 127.0.0.1\n"
        "  port: 6667\n"
    )
    return p


@pytest.fixture
def successful_connect(monkeypatch: pytest.MonkeyPatch):
    async def ok(self) -> None:
        return None

    async def welcomed(self) -> None:
        # Mocked alongside connect() — without it, the serve command's
        # `wait_for_welcome` would block on the real welcome Event that
        # nothing sets (no actual transport here), making every test
        # that monkeypatches connect() time out. Yields once so the
        # function isn't a sync-disguised-as-async (sonarcloud S7503).
        await asyncio.sleep(0)

    monkeypatch.setattr("irc_lens.session.Session.connect", ok)
    monkeypatch.setattr("irc_lens.session.Session.wait_for_welcome", welcomed)


# ---------------------------------------------------------------------------
# Argparse surface
# ---------------------------------------------------------------------------


def test_serve_missing_config_errors(
    capsys: pytest.CaptureFixture[str],
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """Bare ``irc-lens serve`` with no --config and no config at the default
    path must exit 1 via the AfiError+hint contract (no argparse traceback).
    The hint must mention ``config init`` so the user knows how to fix it."""
    # Point the default config path at a non-existent location so the test
    # is hermetic regardless of the developer's local config. Use tmp_path
    # so the directory is guaranteed not to exist (created fresh per test).
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / "no-config-dir"))
    rc = main(["serve"])
    assert rc == 1
    err = capsys.readouterr().err
    assert "error:" in err
    assert "hint:" in err
    assert "config init" in err
    assert "Traceback" not in err


def test_serve_help_lists_all_flags(capsys: pytest.CaptureFixture[str]) -> None:
    """Every flag from the spec's CLI shape is registered."""
    with pytest.raises(SystemExit) as exc:
        main(["serve", "--help"])
    assert exc.value.code == 0
    out = capsys.readouterr().out
    for flag in (
        "--host",
        "--port",
        "--nick",
        "--web-port",
        "--bind",
        "--icon",
        "--open",
        "--seed",
        "--log-json",
    ):
        assert flag in out, f"--help missing flag {flag!r}"


def test_serve_help_renders_defaults_from_argparse(
    capsys: pytest.CaptureFixture[str],
) -> None:
    """Help text for each defaulted flag must show the argparse-stored
    default value verbatim. This is the drift-catcher Copilot flagged on
    PR #16: hard-coding the default in the `help=` string makes it
    possible to change `default=` without updating the help — using
    `%(default)s` (or any equivalent) keeps them in lockstep, and this
    test asserts the rendered output proves it.

    Driving the assertion from `parser._actions` rather than the literal
    values means a future bump (e.g. default --port → 6668) only needs
    the `default=` change; the test re-derives the expected help string.
    """
    from irc_lens.cli import _build_parser  # noqa: PLC0415 - local import keeps the test self-contained

    parser = _build_parser()
    serve_parser = parser._subparsers._group_actions[0].choices["serve"]
    expected: dict[str, object] = {
        action.option_strings[0]: action.default
        for action in serve_parser._actions
        if action.option_strings
        and action.default is not None
        and action.default is not False  # store_true flags
        and action.dest != "help"
    }

    with pytest.raises(SystemExit):
        main(["serve", "--help"])
    out = capsys.readouterr().out

    # Every defaulted flag's stored default must surface in the rendered help.
    for flag, default_value in expected.items():
        token = f"(default: {default_value})"
        assert token in out, (
            f"--help text for {flag} is out of sync with argparse default "
            f"{default_value!r}: expected to find {token!r} in output"
        )


# ---------------------------------------------------------------------------
# Lifecycle contracts
# ---------------------------------------------------------------------------


def test_serve_fails_fast_on_unreachable_agentirc(
    capsys: pytest.CaptureFixture[str],
    monkeypatch: pytest.MonkeyPatch,
    dev_config_path: Path,
) -> None:
    """AgentIRC unreachable → exit 1, error + hint on stderr; the aiohttp
    runner is never even constructed (tripwire below)."""

    async def boom(self) -> None:
        raise LensConnectionLost("Cannot connect to IRC server at 127.0.0.1:1")

    monkeypatch.setattr("irc_lens.session.Session.connect", boom)

    def tripwire(*_a, **_kw):  # pragma: no cover - must NOT run
        raise AssertionError("AppRunner must not be constructed on connect failure")

    monkeypatch.setattr("aiohttp.web.AppRunner", tripwire)

    rc = main(["serve", "--config", str(dev_config_path), "--host", "127.0.0.1", "--port", "1", "--nick", "lens"])
    assert rc == 1
    err = capsys.readouterr().err
    assert "error:" in err
    assert "hint:" in err
    assert "AgentIRC" in err
    assert "Traceback" not in err


def test_serve_translates_port_in_use_to_exit_2(
    capsys: pytest.CaptureFixture[str],
    monkeypatch: pytest.MonkeyPatch,
    successful_connect,
    dev_config_path: Path,
) -> None:
    """Web port in use → exit 2 (env error per the policy)."""
    monkeypatch.setattr("aiohttp.web.AppRunner", _FakeRunner)
    monkeypatch.setattr("aiohttp.web.TCPSite", _BoomSite)
    monkeypatch.setattr("asyncio.Event", _ImmediateEvent)

    rc = main(["serve", "--config", str(dev_config_path), "--host", "x", "--port", "1", "--nick", "lens"])
    assert rc == 2
    err = capsys.readouterr().err
    assert "error:" in err
    assert "hint:" in err
    assert "web port" in err.lower()


def test_serve_warns_on_bind_zero(
    capsys: pytest.CaptureFixture[str],
    stub_aiohttp_runtime,
    successful_connect,
    dev_config_path: Path,
) -> None:
    """`--bind 0.0.0.0` prints the loud no-auth warning before binding."""
    rc = main(
        [
            "serve",
            "--config", str(dev_config_path),
            "--host", "x", "--port", "1", "--nick", "lens",
            "--bind", "0.0.0.0",
            "--web-port", "65000",
        ]
    )
    assert rc == 0
    err = capsys.readouterr().err
    assert "0.0.0.0" in err
    assert "no auth" in err.lower() or "no authentication" in err.lower()


def test_serve_displays_routable_url_when_binding_to_zero(
    capsys: pytest.CaptureFixture[str],
    stub_aiohttp_runtime,
    successful_connect,
    dev_config_path: Path,
) -> None:
    """When binding to 0.0.0.0, the printed URL must use 127.0.0.1 — most
    browsers won't navigate to http://0.0.0.0:port/."""
    rc = main(
        [
            "serve",
            "--config", str(dev_config_path),
            "--host", "x", "--port", "1", "--nick", "lens",
            "--bind", "0.0.0.0",
            "--web-port", "65010",
        ]
    )
    assert rc == 0
    err = capsys.readouterr().err
    assert "http://127.0.0.1:65010/" in err
    assert "http://0.0.0.0:" not in err


def test_serve_displays_bind_url_for_localhost(
    capsys: pytest.CaptureFixture[str],
    stub_aiohttp_runtime,
    successful_connect,
    dev_config_path: Path,
) -> None:
    """For non-wildcard binds, the URL uses the bind value as-is."""
    rc = main(
        [
            "serve",
            "--config", str(dev_config_path),
            "--host", "x", "--port", "1", "--nick", "lens",
            "--web-port", "65011",
        ]
    )
    assert rc == 0
    err = capsys.readouterr().err
    assert "http://127.0.0.1:65011/" in err


def test_serve_seed_loads_yaml_fixture(
    capsys: pytest.CaptureFixture[str],
    stub_aiohttp_runtime,
    successful_connect,
    monkeypatch: pytest.MonkeyPatch,
    dev_config_path: Path,
) -> None:
    """Phase 8: `--seed <path>` overlays YAML state onto Session before
    `make_app` runs. Verify by spying on the loader."""
    captured: dict[str, object] = {}

    def fake_apply(session, path):
        captured["session"] = session
        captured["path"] = path

    # Patch at the definition site since serve.py imports
    # `apply_seed` function-locally (see serve.py module top comment
    # — there's a real production-code import cycle to avoid).
    monkeypatch.setattr("irc_lens.seed.apply_seed", fake_apply)
    rc = main(
        [
            "serve",
            "--config", str(dev_config_path),
            "--host", "x", "--port", "1", "--nick", "lens",
            "--seed", "tests/fixtures/basic.yaml",
            "--web-port", "65001",
        ]
    )
    assert rc == 0
    assert str(captured["path"]).endswith("tests/fixtures/basic.yaml")


def test_serve_seed_missing_file_exits_user_error(
    capsys: pytest.CaptureFixture[str],
    stub_aiohttp_runtime,
    successful_connect,
    dev_config_path: Path,
) -> None:
    """A bad --seed path surfaces as `error:`/`hint:` per the rubric;
    no aiohttp bind, no traceback."""
    rc = main(
        [
            "serve",
            "--config", str(dev_config_path),
            "--host", "x", "--port", "1", "--nick", "lens",
            "--seed", "tests/fixtures/does_not_exist.yaml",
            "--web-port", "65001",
        ]
    )
    assert rc == 1
    err = capsys.readouterr().err
    assert "error:" in err
    assert "hint:" in err
    assert "Traceback" not in err


def test_serve_explicit_config_missing_exits_user_error(
    capsys: pytest.CaptureFixture[str],
) -> None:
    """`--config /missing/path` MUST error rather than silently fall
    back to the synthetic dev config — a typo'd path could otherwise
    quietly start an unauthenticated server when a CF deploy was
    intended (Copilot PR #34 review)."""
    rc = main(
        [
            "serve",
            "--config", "/tmp/irc-lens-does-not-exist-12345.yaml",
            "--nick", "lens",
            "--web-port", "65002",
        ]
    )
    assert rc == 1
    err = capsys.readouterr().err
    assert "error:" in err
    assert "does not exist" in err
    assert "hint:" in err
    assert "config init" in err
    assert "Traceback" not in err


def test_serve_uses_config_host_port_when_no_cli_flags(
    capsys: pytest.CaptureFixture[str],
    stub_aiohttp_runtime,
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """When --host / --port are omitted, the server host/port come from the
    config file (sentinel-default fix, FIX A). Uses TEST-NET-1 (RFC 5737)
    to ensure the address cannot accidentally match a real host.

    ``Session.connect`` is patched to capture the (host, port) that were
    passed to the Session constructor; ``wait_for_welcome`` is patched to
    return immediately so the flow doesn't block.
    """
    cfg = tmp_path / "config.yaml"
    cfg.write_text(
        "auth:\n"
        "  mode: dev\n"
        "  dev:\n"
        "    nick: lens-test\n"
        "    email: dev@local\n"
        "server:\n"
        "  name: spark\n"
        "  host: 192.0.2.42\n"
        "  port: 7777\n"
    )

    captured: dict[str, object] = {}

    async def spy_connect(self) -> None:
        captured["host"] = self.host
        captured["port"] = self.port

    async def noop_welcome(self) -> None:
        await asyncio.sleep(0)

    monkeypatch.setattr("irc_lens.session.Session.connect", spy_connect)
    monkeypatch.setattr("irc_lens.session.Session.wait_for_welcome", noop_welcome)

    rc = main(
        [
            "serve",
            "--config", str(cfg),
            # no --host / --port — config values must be used
            "--web-port", "65020",
        ]
    )
    assert rc == 0
    assert captured.get("host") == "192.0.2.42", (
        f"Expected config host 192.0.2.42, got {captured.get('host')!r}"
    )
    assert captured.get("port") == 7777, (
        f"Expected config port 7777, got {captured.get('port')!r}"
    )


def test_serve_warns_on_config_bind_zero(
    capsys: pytest.CaptureFixture[str],
    stub_aiohttp_runtime,
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """When `web.bind: 0.0.0.0` is in the config and --bind is not passed,
    the 0.0.0.0 warning must still fire (FIX C: key off effective config
    bind, not the CLI flag).
    """
    cfg = tmp_path / "config.yaml"
    cfg.write_text(
        "auth:\n"
        "  mode: dev\n"
        "  dev:\n"
        "    nick: lens-test\n"
        "    email: dev@local\n"
        "server:\n"
        "  name: spark\n"
        "  host: 127.0.0.1\n"
        "  port: 6667\n"
        "web:\n"
        "  bind: 0.0.0.0\n"
    )

    async def ok(self) -> None:
        return None

    async def welcomed(self) -> None:
        await asyncio.sleep(0)

    monkeypatch.setattr("irc_lens.session.Session.connect", ok)
    monkeypatch.setattr("irc_lens.session.Session.wait_for_welcome", welcomed)

    rc = main(
        [
            "serve",
            "--config", str(cfg),
            "--web-port", "65030",
            # no --bind: warning must fire from config.web_bind
        ]
    )
    assert rc == 0
    err = capsys.readouterr().err
    assert "0.0.0.0" in err, f"Expected 0.0.0.0 warning in stderr, got: {err!r}"
    assert "no auth" in err.lower() or "no authentication" in err.lower(), (
        f"Expected no-auth warning text in stderr, got: {err!r}"
    )
