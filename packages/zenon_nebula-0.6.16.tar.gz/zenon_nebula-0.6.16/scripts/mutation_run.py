#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Mutation-testing scaffold — task #58 Phase 1 (of #51 meta-testing).

Mutation testing measures the *semantic* strength of the test suite.
A line of code is "covered" if tests execute it, but *mutation*
asks the harder question: if this line were subtly wrong, would a
test fail?

Classical mutmut/cosmic-ray are heavyweight and have Python 3.13
compat history. This Phase 1 ships a stdlib-only mini mutation
tester that demonstrates the principle on a scoped module set:

    * For each target file, apply a set of mutation operators.
    * For each mutation, run the test suite with a short timeout.
    * If the suite still passes, the mutation *survived* — the
      test suite has a semantic gap.
    * If the suite fails, the mutation was *killed* — the test
      suite caught it.

Report: ``survivors / total`` per file, plus a per-mutation summary
for any survivors. A survivor is a concrete signal: write a test
that kills it.

Phase 2 (task #58 follow-up) will graduate to mutmut or cosmic-ray
and run nightly. Phase 1 is proof-of-principle + the operator UX.

Usage:
    python3 scripts/mutation_run.py                    # default targets
    python3 scripts/mutation_run.py core/trust.py     # single file
    python3 scripts/mutation_run.py --max-per-file 5  # cap mutations per file

Exit codes:
    0   all mutations killed — zero survivors.
    1   at least one survivor (a testing gap). Not a ship blocker
        yet; Phase 1 is informational. Phase 3 may promote this to
        a CI gate once we establish a baseline.
    2   bad usage or environment.
"""

from __future__ import annotations

import argparse
import io
import re
import subprocess
import sys
import tokenize
from dataclasses import dataclass, field
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

# Scope Phase 1 to pure-logic modules where mutation testing signal
# is high. DB-heavy and LLM-heavy modules have too much setup to
# mutate cheaply in Phase 1; they're Phase 2 territory.
DEFAULT_TARGETS = [
    "core/trust.py",
    "core/upgrade_check.py",
    "core/universal_http.py",
]

# How long one pytest invocation can take against a mutation. Short
# enough that 20 mutations x 4 targets stays under 10 min total on
# a modest runner. Any test suite that can't run per-mutation in
# this window needs Phase 2 infra (parallel mutation, module-scoped
# test selection).
PYTEST_TIMEOUT_SECONDS = 90

# Mutation operators. Each is (regex, replacement, description).
# Keep the operator set small + high-signal: operators that don't
# produce compilable Python are dead weight.
OPERATORS = [
    (re.compile(r"\breturn True\b"), "return False", "return True → False"),
    (re.compile(r"\breturn False\b"), "return True", "return False → True"),
    # Comparison flips — only match the operator, not the operands,
    # so we don't rewrite numeric literals embedded elsewhere.
    (re.compile(r"(?<=[a-zA-Z0-9_\)\]\s])==(?=[^=])"), "!=", "== → !="),
    (re.compile(r"(?<=[a-zA-Z0-9_\)\]\s])!=(?=[^=])"), "==", "!= → =="),
    (re.compile(r"(?<=[a-zA-Z0-9_\)\]\s])>=(?=[^=])"), "<=", ">= → <="),
    (re.compile(r"(?<=[a-zA-Z0-9_\)\]\s])<=(?=[^=])"), ">=", "<= → >="),
    # Boolean connective flip. Matches isolated `and`/`or` tokens only.
    (re.compile(r"\band\b"), "or", "and → or"),
    (re.compile(r"\bor\b"), "and", "or → and"),
]


@dataclass
class MutationResult:
    """One mutation attempt's outcome."""

    file: str
    line_number: int
    operator: str
    original_line: str
    mutated_line: str
    killed: bool
    notes: str = ""


@dataclass
class FileReport:
    """Aggregate results for one target file."""

    path: str
    total: int = 0
    killed: int = 0
    survivors: list[MutationResult] = field(default_factory=list)


def _mutate_line(line: str, operator_index: int, comment_col: int | None = None) -> str | None:
    """Apply the Nth operator to a line. Return the mutated line, or
    None if the operator didn't match. If ``comment_col`` is set, a
    match whose start position is at or past the comment column is
    treated as a no-match (the pattern hit prose, not code)."""
    pattern, repl, _desc = OPERATORS[operator_index]
    match = pattern.search(line)
    if match is None:
        return None
    if comment_col is not None and match.start() >= comment_col:
        return None
    return line[: match.start()] + repl + line[match.end() :]


def _string_lines(source: str) -> set[int]:
    """Return every 1-indexed line number that falls inside a string
    literal (docstrings, multi-line strings, f-strings, anything that
    ``tokenize`` reports as ``STRING``).

    Needed because a naive line-prefix check only catches the opening
    ``\"\"\"`` of a docstring, not its continuation lines. Mutating
    \"and\" to \"or\" inside a docstring never changes behavior, so
    the pytest run always passes and the mutation gets reported as a
    false-positive \"survivor\". Skipping string-internal lines makes
    the survivor set a real signal.
    """
    inside: set[int] = set()
    try:
        tokens = tokenize.tokenize(io.BytesIO(source.encode("utf-8")).readline)
        for tok in tokens:
            if tok.type == tokenize.STRING:
                start_line, _ = tok.start
                end_line, _ = tok.end
                for ln in range(start_line, end_line + 1):
                    inside.add(ln)
    except tokenize.TokenError:
        # Best-effort: if the file doesn't tokenize cleanly we'd rather
        # over-mutate than silently skip mutations.
        return set()
    return inside


def _comment_start_cols(source: str) -> dict[int, int]:
    """For every line that contains a ``#`` comment, return the byte
    column where the comment starts. Lines without a comment are absent.

    A mutation whose match position on the line is ``>= comment_col``
    is inside the comment and cannot change behavior. Skipping these
    avoids the false-positive class where e.g. ``>=`` in an inline
    comment gets flipped to ``<=`` and the test suite (correctly)
    ignores it.
    """
    cols: dict[int, int] = {}
    try:
        tokens = tokenize.tokenize(io.BytesIO(source.encode("utf-8")).readline)
        for tok in tokens:
            if tok.type == tokenize.COMMENT:
                line, col = tok.start
                # First comment on the line wins (tokenizer emits them
                # left-to-right, and a line has at most one comment
                # start in Python).
                cols.setdefault(line, col)
    except tokenize.TokenError:
        return {}
    return cols


def _run_pytest_against(file_path: Path) -> tuple[bool, str]:
    """Run pytest on the repo state. Return (passed, short_reason).

    Phase 1 runs the whole suite per mutation — simple but slow.
    Phase 2 will scope to the tests that import the target.
    """
    cmd = [
        sys.executable,
        "-m",
        "pytest",
        "tests/",
        "-q",
        "--timeout=60",
        "-x",  # stop at first failure — we only need ONE kill signal
        "--no-header",
        "--no-summary",
    ]
    try:
        proc = subprocess.run(
            cmd,
            cwd=str(ROOT),
            capture_output=True,
            text=True,
            timeout=PYTEST_TIMEOUT_SECONDS,
            check=False,
        )
    except subprocess.TimeoutExpired:
        # Timeout = killed (test suite hung on the mutation). Treat
        # as kill, not survivor — a hung mutation is not a quiet
        # survivor, it's a detectable regression.
        return False, "pytest timed out (mutation killed by hang)"
    except (OSError, subprocess.SubprocessError) as exc:
        return False, f"pytest invocation failed: {exc}"
    passed = proc.returncode == 0
    if not passed:
        # Extract the first failing test name for the report.
        tail = (proc.stdout or "") + (proc.stderr or "")
        hit = re.search(r"FAILED (tests/[\w\-./:]+)", tail)
        reason = f"killed by {hit.group(1)}" if hit else "killed (pytest exit != 0)"
        return False, reason
    return True, "survived"


def mutate_file(path: Path, *, max_mutations: int) -> FileReport:
    """Apply mutations to ``path``, run pytest per mutation, report."""
    report = FileReport(path=str(path.relative_to(ROOT)))
    original = path.read_text(encoding="utf-8")
    lines = original.splitlines(keepends=True)
    string_lines = _string_lines(original)
    comment_cols = _comment_start_cols(original)

    mutations_applied = 0
    for line_no, line in enumerate(lines, start=1):
        # Skip obvious non-code lines — comments-only.
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        # Skip lines that are inside a string literal (docstring,
        # multi-line string, etc.). Mutating prose can never change
        # behavior, so a pytest pass is meaningless.
        if line_no in string_lines:
            continue
        line_comment_col = comment_cols.get(line_no)
        for op_idx, (_pattern, _repl, desc) in enumerate(OPERATORS):
            if mutations_applied >= max_mutations:
                break
            mutated = _mutate_line(line, op_idx, comment_col=line_comment_col)
            if mutated is None or mutated == line:
                continue
            # Swap in the mutation, run pytest, swap back.
            lines[line_no - 1] = mutated
            try:
                path.write_text("".join(lines), encoding="utf-8")
                passed, reason = _run_pytest_against(path)
            finally:
                lines[line_no - 1] = line
                path.write_text(original, encoding="utf-8")

            result = MutationResult(
                file=report.path,
                line_number=line_no,
                operator=desc,
                original_line=line.rstrip("\n"),
                mutated_line=mutated.rstrip("\n"),
                killed=not passed,
                notes=reason,
            )
            report.total += 1
            mutations_applied += 1
            if result.killed:
                report.killed += 1
            else:
                report.survivors.append(result)
        if mutations_applied >= max_mutations:
            break
    return report


def resolve_targets(user_targets: list[str]) -> list[Path]:
    """Resolve operator-supplied paths (or defaults) to concrete Paths."""
    raw = user_targets or DEFAULT_TARGETS
    out: list[Path] = []
    for t in raw:
        p = (ROOT / t).resolve()
        if not p.is_file():
            print(f"mutation_run: target not found: {t}", file=sys.stderr)
            continue
        if p.suffix != ".py":
            print(f"mutation_run: skipping non-Python target: {t}", file=sys.stderr)
            continue
        out.append(p)
    return out


def format_report(reports: list[FileReport]) -> str:
    """Human-readable report."""
    lines = ["Mutation testing — Phase 1 results", "=" * 50]
    total_all = sum(r.total for r in reports)
    killed_all = sum(r.killed for r in reports)
    survivor_count = total_all - killed_all
    for r in reports:
        ratio = f"{r.killed}/{r.total}" if r.total else "0/0"
        lines.append(f"{r.path:40s} killed {ratio}")
        for s in r.survivors:
            lines.append(f"  SURVIVOR line {s.line_number}  [{s.operator}]")
            lines.append(f"    before: {s.original_line.strip()[:80]}")
            lines.append(f"    after:  {s.mutated_line.strip()[:80]}")
    lines.append("=" * 50)
    lines.append(f"Total: {killed_all}/{total_all} killed ({survivor_count} survivors)")
    return "\n".join(lines)


def survivor_key(result: MutationResult) -> str:
    """Canonical allowlist key for a survivor: ``file:line:operator``.

    The allowlist file uses this exact format (see
    ``data/mutation_allowlist.txt``). Keep the format stable — the
    nightly gate's drift detection depends on byte-exact matching."""
    return f"{result.file}:{result.line_number}:{result.operator}"


def parse_allowlist(path: Path) -> set[str]:
    """Read an allowlist file. Returns a set of canonical keys.

    Format: one ``file:line:operator`` entry per line. Blank lines and
    ``#``-prefixed comments are ignored. Unparseable lines raise
    ``ValueError`` so a malformed allowlist fails loud instead of
    silently accepting mutations."""
    if not path.is_file():
        return set()
    keys: set[str] = set()
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        # Validate shape: at least two colons, first two segments
        # non-empty. The operator descriptions contain arrow glyphs
        # and spaces, so colon count alone isn't enough — check the
        # format of the first two segments.
        parts = line.split(":", 2)
        if len(parts) != 3 or not parts[0] or not parts[1].isdigit() or not parts[2]:
            raise ValueError(
                f"mutation_run: malformed allowlist entry: {raw!r} (expected 'file:line:operator')"
            )
        keys.add(line)
    return keys


def gate_result(reports: list[FileReport], allowlist: set[str]) -> tuple[int, list[str]]:
    """Compare current survivors against the allowlist.

    Returns ``(exit_code, messages)``:

    - exit 0: every survivor is allowlisted AND no allowlisted
      mutation got killed (steady state).
    - exit 1: there are new survivors NOT on the allowlist. Fail loud.
    - exit 0 + progress message: some allowlisted mutations got
      killed — tells the operator to shrink the allowlist.
    """
    current = {survivor_key(s) for r in reports for s in r.survivors}
    new_survivors = sorted(current - allowlist)
    killed_allowlisted = sorted(allowlist - current)

    msgs: list[str] = []
    if killed_allowlisted:
        msgs.append(
            f"Progress: {len(killed_allowlisted)} allowlisted mutation(s) now killed. "
            "Remove from data/mutation_allowlist.txt:"
        )
        for k in killed_allowlisted:
            msgs.append(f"  - {k}")

    if new_survivors:
        msgs.append(
            f"FAIL: {len(new_survivors)} new survivor(s) not in allowlist. "
            "Either write a test that kills the mutation, or if the gap "
            "is accepted, add to data/mutation_allowlist.txt with a "
            "rationale comment:"
        )
        for k in new_survivors:
            msgs.append(f"  + {k}")
        return 1, msgs

    return 0, msgs


def main() -> int:
    """Mutation-test entry point."""
    parser = argparse.ArgumentParser(
        description="Phase 1 mutation-testing scaffold for Nebula.",
    )
    parser.add_argument(
        "targets",
        nargs="*",
        help=(
            "Python files to mutate (default: core/trust.py, "
            "core/upgrade_check.py, core/universal_http.py)."
        ),
    )
    parser.add_argument(
        "--max-per-file",
        type=int,
        default=10,
        help=(
            "Max mutations per file. Phase 1 caps this to keep "
            "runtime bounded. Phase 2 will remove the cap."
        ),
    )
    parser.add_argument(
        "--allowlist",
        type=Path,
        default=ROOT / "data" / "mutation_allowlist.txt",
        help=(
            "Path to the mutation allowlist (default: "
            "data/mutation_allowlist.txt). Each line is a known "
            "surviving mutation in canonical 'file:line:operator' "
            "form. Missing file is treated as an empty allowlist."
        ),
    )
    parser.add_argument(
        "--no-gate",
        action="store_true",
        help=(
            "Informational mode (Phase 1 behavior): always exit 0 if "
            "no crashes, even when survivors exist. Overrides the "
            "allowlist check. Use for ad-hoc exploration."
        ),
    )
    args = parser.parse_args()

    if args.max_per_file <= 0:
        print("mutation_run: --max-per-file must be positive", file=sys.stderr)
        return 2

    targets = resolve_targets(args.targets)
    if not targets:
        print("mutation_run: no valid targets", file=sys.stderr)
        return 2

    try:
        allowlist = parse_allowlist(args.allowlist)
    except ValueError as exc:
        print(str(exc), file=sys.stderr)
        return 2

    # Copy the repo into a scratch dir? Not needed — we restore the
    # file in a finally block after every mutation. The try/finally
    # in mutate_file is the rollback guarantee.
    reports: list[FileReport] = []
    for path in targets:
        print(f"Mutating {path.relative_to(ROOT)} (max={args.max_per_file})")
        reports.append(mutate_file(path, max_mutations=args.max_per_file))

    print()
    print(format_report(reports))

    if args.no_gate:
        # Informational mode — return 1 if any survivors, for
        # backward compat with pre-Phase-3 callers.
        survivors = sum(len(r.survivors) for r in reports)
        return 0 if survivors == 0 else 1

    # Gate mode (default, Phase 3+): compare against allowlist.
    exit_code, messages = gate_result(reports, allowlist)
    if messages:
        print()
        print("\n".join(messages))
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
