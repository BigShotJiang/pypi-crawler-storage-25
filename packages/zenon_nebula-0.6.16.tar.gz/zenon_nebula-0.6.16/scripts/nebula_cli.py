#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""
Zenon Nebula — autonomous intelligence for the Network of Momentum.

Usage:
    nebula                    # Run continuously (24/7)
    nebula --cycles 5         # Run 5 cycles then stop
    nebula --budget 10        # Run with $10 budget cap
    nebula --hours 2          # Run for 2 hours
    nebula --domains sec,qual # Run only selected domains

    nebula install            # First-time setup (deps + .env + DB)
    nebula doctor             # Health check
    nebula doctor --fix       # Health check + auto-repair what's fixable
    nebula update             # Safe self-update (git-clone install) with rollback on failure
    nebula update --check     # Check if an update is available (no changes)
    nebula upgrade            # Upgrade the pip-installed zenon-nebula package
    nebula upgrade --rollback # Pin back to the previous pip version
    nebula upgrade --dry-run  # Show what upgrade/rollback would do

    nebula hosts list         # List allowed universal_http hosts
    nebula hosts add HOST     # Add a host to the allowlist
    nebula hosts remove HOST  # Remove a host from the allowlist
    nebula hosts reload       # Force-reload the allowlist file

    nebula tasks              # Show docs/tasks.yaml summary
    nebula tasks pending      # Only pending tasks
    nebula tasks in-progress  # Only in-progress tasks
    nebula tasks N            # Detail for task #N
    nebula version            # Show version info

    nebula config             # List non-secret config values
    nebula config get KEY     # Read a single config value
    nebula config set K V     # Write a config value (persists to .env)
    nebula config unset KEY   # Remove a config value
    nebula config api-key     # Interactively set XAI_API_KEY (hidden input)

    nebula transport          # Show current transport mode + stats
    nebula transport local    # Switch to local (no sharing)
    nebula transport shared   # Switch to file-based sharing
    nebula transport nexus    # Switch to Nexus/SpacetimeDB
    nebula transport sync     # Force publish + pull via current transport
    nebula transport peers    # List configured RPC peers

    nebula status             # Evidence count, hypotheses, collisions
    nebula findings           # Recent findings with lifecycle
    nebula plan               # Latest battle plan
    nebula domains            # List domains and engines (alias: engines)
    nebula hypotheses         # Bayesian hypotheses with confidence
    nebula costs              # LLM cost breakdown
    nebula specs              # Spec coverage matrix
    nebula height             # Evidence chain height
    nebula ask "question"     # Ask Nebula (LLM-powered)

    nebula serve              # Start MCP server for LLM integration
    nebula rpc                # Start JSON-RPC server (localhost:8484)
    nebula snapshot export    # Export evidence snapshot
    nebula snapshot import F  # Import a snapshot
    nebula sync               # Download latest snapshot from peers
    nebula bootstrap URL      # Bootstrap fresh instance from elder peer

    nebula trust-history      # Dynamic trust tiers by repo (alias: trust)
    nebula trust-history REPO # Full quality-score trajectory for one repo

Run `nebula --help` for flags passed through to the autonomous runner.

NOTE ON TIMESTAMPS: Nebula stores all timestamps in UTC (enforced by
architecture audit rule R5). CLI commands show them in BOTH local time
AND UTC where ambiguous, so ad-hoc SQL queries never hit a
local-vs-UTC mismatch. If you query the DB directly, remember the
raw `timestamp` column is UTC — wrap it with
`datetime(timestamp, 'localtime')` for local-zone display.
"""

# ---------------------------------------------------------------------------
# BOOTSTRAP — runs before any 3.10+ syntax is parsed elsewhere.
# Keep this block pure Python 2/3 compatible so that a user on an ancient
# interpreter gets a clean error instead of a SyntaxError.
# ---------------------------------------------------------------------------

import os
import sys

_MIN_PY = (3, 10)
if sys.version_info < _MIN_PY:
    sys.stderr.write(
        f"nebula: Python {_MIN_PY[0]}.{_MIN_PY[1]}+ is required (you have {sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}).\n"
        "        Install a newer Python from https://python.org and retry.\n"
    )
    sys.exit(2)

from pathlib import Path

# ROOT is the repo root — two parents up from scripts/nebula_cli.py
# (i.e. parents[1]). Using `.parent` here would resolve to scripts/
# and break .env / data/ / env.example.txt lookups.
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

# DATA_DIR defaults to <repo>/data/ but operators can redirect it via
# NEBULA_DATA_DIR — needed by scripts/smoke_run.py (Gate A, task #100)
# which runs `./nebula --cycles 1` against a throwaway tmp DB without
# mutating the operator's real evidence store. The env var also lets
# operators run multiple independent Nebula instances on the same
# machine (each with its own DATA_DIR) for Gate C peer-net testing
# (task #102). An unset / empty value is the backwards-compatible
# default.
_data_dir_override = os.environ.get("NEBULA_DATA_DIR", "").strip()
DATA_DIR = Path(_data_dir_override).expanduser() if _data_dir_override else ROOT / "data"
DB = DATA_DIR / "engine.db"
ENV_FILE = ROOT / ".env"
ENV_TEMPLATE = ROOT / "env.example.txt"

# ---------------------------------------------------------------------------
# Tiny stdlib-only helpers used BEFORE any heavy imports. If pip deps are
# missing, the 'install' / 'doctor' / 'help' / 'version' paths must still
# work. Everything below must stay importable with only the stdlib.
# ---------------------------------------------------------------------------

# Dependencies required for the "run" path (nebula, status, findings, etc.).
# Each entry is (import_name, pip_package, required_for).
REQUIRED_DEPS = [
    ("requests", "requests", "HTTP calls"),
    ("dotenv", "python-dotenv", ".env loading"),
    ("networkx", "networkx", "knowledge graph"),
]

# Optional deps that unlock specific features but aren't required.
OPTIONAL_DEPS = [
    ("websocket", "websocket-client", "Zenon node WebSocket RPC"),
]


def _load_env_if_possible() -> None:
    """Populate os.environ from .env using a stdlib parser.

    We deliberately avoid importing python-dotenv here: it may not be
    installed yet (first-run before `nebula install`) and we don't want
    the controller to crash before it can help the user fix that.
    """
    if not ENV_FILE.exists():
        return
    try:
        for raw in ENV_FILE.read_text().splitlines():
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, value = line.partition("=")
            os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))
    except OSError:
        pass


_load_env_if_possible()


def _check_deps(deps):
    """Return a list of missing (import_name, pip_package, purpose) tuples."""
    missing = []
    for import_name, pip_name, purpose in deps:
        try:
            __import__(import_name)
        except ImportError:
            missing.append((import_name, pip_name, purpose))
    return missing


def _has_command(cmd: str) -> bool:
    """Return True if `cmd` is on PATH."""
    from shutil import which

    return which(cmd) is not None


def _in_virtualenv() -> bool:
    return hasattr(sys, "real_prefix") or (
        hasattr(sys, "base_prefix") and sys.base_prefix != sys.prefix
    )


def _pip_install(args, capture: bool = False):
    """Run `python -m pip install <args>` with the active interpreter."""
    import subprocess

    cmd = [sys.executable, "-m", "pip", "install", *args]
    if capture:
        return subprocess.run(cmd, capture_output=True, text=True, check=False)
    return subprocess.run(cmd, check=False)


# ---------------------------------------------------------------------------
# Preflight — runs for every command that needs the DB / deps / workspace.
# Commands that MUST work without deps (install, doctor, version, help) skip
# this check.
# ---------------------------------------------------------------------------

_NO_PREFLIGHT = {"install", "doctor", "version", "help", "-h", "--help", "--version"}


def _preflight(command: str) -> None:
    """Verify deps + data dir exist before running commands that need them.

    If deps are missing, print a clear one-line fix and exit non-zero.
    Never tries to install anything itself — that's the `install` command's
    job. The philosophy: predictable, never surprise the user.
    """
    if command in _NO_PREFLIGHT:
        return

    missing = _check_deps(REQUIRED_DEPS)
    if missing:
        sys.stderr.write("nebula: required dependencies are missing.\n")
        for _import_name, pip_name, purpose in missing:
            sys.stderr.write(f"  - {pip_name} ({purpose})\n")
        sys.stderr.write(
            "\nFix with one of:\n"
            "  ./nebula install          # guided first-time setup\n"
            "  pip install -r requirements.txt\n"
        )
        sys.exit(2)

    # Ensure the data directory exists. Cheap to create, avoids a crash
    # inside the first engine that tries to write a file.
    try:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        sys.stderr.write(f"nebula: cannot create data directory {DATA_DIR}: {exc}\n")
        sys.exit(2)


# ---------------------------------------------------------------------------
# Install — first-time setup. Runs even when deps are missing.
# ---------------------------------------------------------------------------


def _detect_environment() -> dict:
    """Detect the runtime environment for the install flow.

    Returns a dict with:
        os:       "macos" | "linux" | "windows" | "other"
        arch:     "x86_64" | "arm64" | "aarch64" | "armv7l" | "other"
        distro:   short Linux distro name (empty on non-Linux)
        pep668:   True if pip refuses system-Python installs (PEP 668)
        docker:   True if running inside a Docker container
        ci:       True if running in a CI environment (GitHub Actions etc.)
    """
    import platform

    system = platform.system().lower()
    machine = platform.machine().lower()

    if system == "darwin":
        os_name = "macos"
    elif system == "linux":
        os_name = "linux"
    elif system == "windows":
        os_name = "windows"
    else:
        os_name = "other"

    if machine in ("x86_64", "amd64"):
        arch = "x86_64"
    elif machine in ("arm64", "aarch64"):
        arch = "arm64"
    elif machine.startswith("armv"):
        arch = machine  # armv7l, armv6l, etc.
    else:
        arch = "other"

    # Linux distro name (best effort, non-crashing)
    distro = ""
    if os_name == "linux":
        try:
            os_release = Path("/etc/os-release").read_text()
            for line in os_release.splitlines():
                if line.startswith("ID="):
                    distro = line.split("=", 1)[1].strip().strip('"')
                    break
        except (OSError, UnicodeDecodeError):
            pass

    # PEP 668 externally-managed-environment marker
    pep668 = False
    if sys.prefix == sys.base_prefix:  # not in a venv
        # The marker file is placed by the distro; its existence means
        # pip will refuse `pip install ...` without --break-system-packages.
        for candidate in (
            Path(sys.prefix)
            / "lib"
            / f"python{sys.version_info.major}.{sys.version_info.minor}"
            / "EXTERNALLY-MANAGED",
            Path(sys.prefix)
            / f"lib/python{sys.version_info.major}.{sys.version_info.minor}/EXTERNALLY-MANAGED",
        ):
            if candidate.exists():
                pep668 = True
                break

    # Docker detection
    docker = Path("/.dockerenv").exists() or (
        Path("/proc/1/cgroup").exists()
        and any("docker" in line for line in _read_text(Path("/proc/1/cgroup")).splitlines())
    )

    ci = bool(os.environ.get("CI") or os.environ.get("GITHUB_ACTIONS"))

    return {
        "os": os_name,
        "arch": arch,
        "distro": distro,
        "pep668": pep668,
        "docker": docker,
        "ci": ci,
    }


def _read_text(p: Path) -> str:
    """Safely read a file's text, returning empty string on any error."""
    try:
        return p.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return ""


def _create_venv(venv_path: Path) -> bool:
    """Create a virtualenv at ``venv_path``. Returns True on success."""
    import subprocess

    if venv_path.exists():
        return True
    try:
        result = subprocess.run(
            [sys.executable, "-m", "venv", str(venv_path)],
            capture_output=True,
            text=True,
            check=False,
        )
        if result.returncode != 0:
            print(f"  [FAIL] venv creation: {result.stderr.strip()[:400]}")
            return False
        return True
    except (OSError, subprocess.SubprocessError) as exc:
        print(f"  [FAIL] venv creation: {exc}")
        return False


def _venv_python(venv_path: Path) -> str:
    """Return the path to python inside a venv (Windows-aware)."""
    if os.name == "nt":
        return str(venv_path / "Scripts" / "python.exe")
    return str(venv_path / "bin" / "python")


def cmd_install() -> int:
    """Guided first-time setup: deps + .env + data dir + schema.

    Handles three environments automatically:

    1. **Already inside a venv** — install straight in.
    2. **System Python on macOS/Linux (PEP 668)** — create ``.venv/``,
       install inside it, print the activation command.
    3. **CI / Docker / --yes** — install non-interactively; create a
       venv only if PEP 668 is detected.

    Use ``--no-venv`` to force a system-Python install (with
    ``--break-system-packages`` as a last resort). Use ``--yes`` to
    skip all interactive prompts.
    """
    argv = sys.argv[2:]  # skip "install"
    no_venv = "--no-venv" in argv
    force_system = "--force-system" in argv
    yes = "--yes" in argv or "-y" in argv

    print("Nebula install")
    print("=" * 50)

    # 1. Python version (already validated at bootstrap) + environment.
    env = _detect_environment()
    print(
        f"  [OK  ] Python {sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
        f" on {env['os']}/{env['arch']}"
        + (f" ({env['distro']})" if env["distro"] else "")
        + (" [docker]" if env["docker"] else "")
        + (" [ci]" if env["ci"] else "")
    )
    if env["pep668"]:
        print("  [INFO] PEP 668 externally-managed Python detected — will use a venv.")

    # 2. Decide on venv vs direct install.
    in_venv = _in_virtualenv()
    venv_path = ROOT / ".venv"
    python_for_pip = sys.executable  # current interpreter by default

    if in_venv:
        print(f"  [OK  ] running inside virtualenv ({sys.prefix})")
    elif no_venv or force_system:
        print("  [WARN] --no-venv / --force-system set; installing with system Python.")
    else:
        # Auto-create the venv unless the user said no. This is the
        # default path on a fresh clone: you get a working install
        # with one command.
        if venv_path.exists():
            print(f"  [OK  ] reusing existing venv at {venv_path.relative_to(ROOT)}")
        else:
            print(f"  creating venv at {venv_path.relative_to(ROOT)} ...")
            if not _create_venv(venv_path):
                if env["pep668"] and not force_system:
                    print("  [FAIL] venv creation failed on a PEP 668 system.")
                    print("         Install the venv package: apt install python3-venv")
                    print("         (or equivalent for your distro)")
                    return 1
                print("  [WARN] venv creation failed — falling back to system Python.")
                venv_path = None  # signal no venv
        if venv_path and venv_path.exists():
            python_for_pip = _venv_python(venv_path)
            print(f"  [OK  ] venv ready ({python_for_pip})")

    # 3. pip availability via the chosen interpreter.
    import subprocess

    pip_check = subprocess.run(
        [python_for_pip, "-m", "pip", "--version"],
        capture_output=True,
        text=True,
        check=False,
    )
    if pip_check.returncode != 0:
        print("  [FAIL] pip not available for the chosen interpreter.")
        print("         Try: python3 -m ensurepip --upgrade")
        return 2
    print("  [OK  ] pip available")

    # 4. Install requirements into the chosen interpreter.
    req = ROOT / "requirements.txt"
    if not req.exists():
        print(f"  [FAIL] {req} missing")
        return 2
    print(f"  installing from {req.name} ...")

    install_cmd = [python_for_pip, "-m", "pip", "install", "-r", str(req)]
    if force_system and env["pep668"]:
        install_cmd.append("--break-system-packages")
        print("  [WARN] using --break-system-packages (unsafe on managed systems)")

    r = subprocess.run(install_cmd, capture_output=True, text=True, check=False)
    if r.returncode != 0:
        err_text = (r.stderr or r.stdout)[-2500:]
        print("  [FAIL] pip install failed:")
        print(err_text)
        # If PEP 668 blocked us, give a clear escalation path.
        if "externally-managed-environment" in err_text:
            print()
            print("  This is PEP 668 — your system Python refuses direct installs.")
            print("  Options:")
            print("    ./nebula install           # auto-create a .venv (default)")
            print("    ./nebula install --no-venv --force-system  # last resort")
            print("    python3 -m venv .venv && source .venv/bin/activate && ./nebula install")
        return 1
    print("  [OK  ] dependencies installed")

    # 5. .env file.
    if not ENV_FILE.exists():
        if ENV_TEMPLATE.exists():
            try:
                ENV_FILE.write_text(ENV_TEMPLATE.read_text())
                print(f"  [OK  ] created {ENV_FILE.name} from template")
                print(f"         EDIT {ENV_FILE} and set XAI_API_KEY before running.")
            except OSError as exc:
                sys.stderr.write(f"  [FAIL] could not create .env: {exc}\n")
                return 1
        else:
            print("  [WARN] env.example.txt missing; you will need to create .env manually.")
    else:
        print("  [OK  ] .env already exists (kept as-is)")

    # 5b. Transport mode — explicit, informed consent for sharing.
    # In non-interactive mode (--yes / CI / Docker) we default to "local"
    # so nothing phones home without explicit choice. Interactive mode
    # asks the operator; the choice is persisted to .env.
    current_transport = None
    try:
        env_text = ENV_FILE.read_text(encoding="utf-8") if ENV_FILE.exists() else ""
        for line in env_text.splitlines():
            if line.strip().startswith("NEBULA_TRANSPORT="):
                current_transport = line.split("=", 1)[1].strip().strip('"').strip("'")
                break
    except OSError:
        pass

    if current_transport:
        print(f"  [OK  ] transport: {current_transport} (from .env)")
    elif yes or env.get("ci") or env.get("docker") or not sys.stdin.isatty():
        print("  [OK  ] transport: local (default, non-interactive)")
        # Append to .env so it's explicit going forward
        try:
            with ENV_FILE.open("a", encoding="utf-8") as f:
                f.write("\n# Transport mode — choose how findings are shared\n")
                f.write("#   local  — nothing leaves this machine (default)\n")
                f.write("#   shared — file-based sharing via NEBULA_SHARED_DIR\n")
                f.write("#   nexus  — real-time via SpacetimeDB/Nexus\n")
                f.write("NEBULA_TRANSPORT=local\n")
        except OSError:
            pass
    else:
        print()
        print("  Transport: how do you want to share findings with peers?")
        print("    [1] local  — nothing leaves this machine (default, safest)")
        print("    [2] shared — file-based sharing via NEBULA_SHARED_DIR")
        print("                 (fine if you run multiple Nebulas on the same box)")
        print("    [3] nexus  — real-time via Nexus/SpacetimeDB (requires a server)")
        try:
            choice = input("  Choose [1]: ").strip() or "1"
        except EOFError:
            choice = "1"
        mode = {"1": "local", "2": "shared", "3": "nexus"}.get(choice, "local")
        print(f"  [OK  ] transport: {mode}")
        try:
            with ENV_FILE.open("a", encoding="utf-8") as f:
                f.write("\n# Transport mode — set by ./nebula install\n")
                f.write(f"NEBULA_TRANSPORT={mode}\n")
                if mode == "shared":
                    f.write("# NEBULA_SHARED_DIR=/path/to/shared/dir\n")
                elif mode == "nexus":
                    f.write("# NEXUS_URL=ws://your-nexus-host/v1/database\n")
        except OSError:
            pass

    # 6. Data directory.
    try:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        print(f"  [OK] data dir {DATA_DIR.relative_to(ROOT)}")
    except OSError as exc:
        sys.stderr.write(f"  [FAIL] cannot create data dir: {exc}\n")
        return 1

    # 7. Initialize the schema — must run with the interpreter that
    # has the newly-installed dependencies. If we created a venv, use
    # its python to exec a one-shot ensure_schema() so we don't rely
    # on the current interpreter seeing the newly-installed core
    # package imports.
    schema_init_script = f"""\
import sys
sys.path.insert(0, {str(ROOT)!r})
try:
    from core.persistence.schema import ensure_schema
except ImportError:
    from core.persist_to_db import ensure_schema
ensure_schema({str(DB)!r})
print('schema OK')
"""
    r = subprocess.run(
        [python_for_pip, "-c", schema_init_script],
        capture_output=True,
        text=True,
        check=False,
    )
    if r.returncode != 0:
        print("  [FAIL] schema init failed:")
        print((r.stderr or r.stdout)[-1500:])
        return 1
    print("  [OK  ] database schema initialized")

    # 8. Final version echo.
    try:
        from core.version import __version__

        print(f"\nNebula {__version__} installed.")
    except Exception:
        print("\nNebula installed (version unknown).")

    print("\nNext steps:")
    print("  1. Set XAI_API_KEY in .env (get one at https://console.x.ai)")
    if venv_path and venv_path.exists() and not in_venv:
        print(f"  2. Activate the venv:  source {venv_path.relative_to(ROOT)}/bin/activate")
        print("  3. Run a test cycle:   ./nebula --cycles 1 --budget 0.05")
        print("  4. Read the findings:  ./nebula findings")
    else:
        print("  2. Run a test cycle:   ./nebula --cycles 1 --budget 0.05")
        print("  3. Read the findings:  ./nebula findings")
    print("  5. For Claude Code / Cursor: the repo ships a .mcp.json — the MCP")
    print("     server is auto-detected on open.")
    return 0


# ---------------------------------------------------------------------------
# Run / status / findings / etc.
# ---------------------------------------------------------------------------


def cmd_run(args):
    """Delegate to scripts/autonomous.py with all flags forwarded."""
    cmd = [sys.executable, str(ROOT / "scripts" / "autonomous.py")]
    cmd.extend(args)
    os.execvp(sys.executable, cmd)


def cmd_status():
    try:
        from core.banner import kv, print_banner, section

        print_banner(compact=True)
    except Exception:
        pass
    if not DB.exists():
        print("No database yet. Run: ./nebula install  (then ./nebula)")
        return
    import sqlite3

    conn = sqlite3.connect(f"file:{DB}?mode=ro", uri=True)
    try:
        ev = conn.execute("SELECT COUNT(*) FROM evidence").fetchone()[0]
        hy = conn.execute("SELECT COUNT(*) FROM hypotheses").fetchone()[0]
        dm = len(conn.execute("SELECT DISTINCT domain FROM evidence").fetchall())
        try:
            co = conn.execute("SELECT COUNT(*) FROM collisions WHERE resolved=0").fetchone()[0]
        except sqlite3.OperationalError:
            co = 0
        try:
            height = conn.execute("SELECT COALESCE(MAX(id), 0) FROM evidence").fetchone()[0]
        except sqlite3.OperationalError:
            height = 0
        try:
            # v0.5.7 — convert the stored UTC timestamp to local time
            # for display. Every timestamp in the DB is UTC (enforced
            # by architecture audit rule R5), but operator-facing
            # output shows local time + a " UTC" / " local" suffix so
            # timezone ambiguity never bites ad-hoc SQL queries.
            raw_last = conn.execute("SELECT MAX(timestamp) FROM evidence").fetchone()[0] or ""
            if raw_last:
                local_last = conn.execute(
                    "SELECT datetime(MAX(timestamp), 'localtime') FROM evidence"
                ).fetchone()[0]
                last = f"{local_last} local ({raw_last} UTC)"
            else:
                last = "—"
        except sqlite3.OperationalError:
            last = "—"
    finally:
        conn.close()

    try:
        section("Status")
        kv("Evidence", ev)
        kv("Height", height)
        kv("Hypotheses", hy)
        kv("Domains active", dm)
        kv("Open collisions", co)
        kv("Last activity", last)
    except Exception:
        print(f"Evidence:    {ev}")
        print(f"Height:      {height}")
        print(f"Hypotheses:  {hy}")
        print(f"Domains:     {dm}")
        print(f"Collisions:  {co}")
        print(f"Last:        {last}")

    # v0.6.x — task #71. Surface operator-declared research intent if set.
    # Stays silent when no intent.md exists, so the status command's shape
    # doesn't change for operators who haven't opted in. Uses the
    # structured load path so the one-line header carries age + summary
    # without dumping the full body into the banner; body follows below.
    try:
        from core.intent import (
            format_intent_for_status,
            intent_path,
            load_parsed_intent,
        )

        parsed = load_parsed_intent()
        if parsed is not None:
            try:
                section("Operator intent")
                kv("Source", str(intent_path()))
                header = format_intent_for_status(parsed)
                if header:
                    kv("State", header.splitlines()[0])
                    for warn_line in header.splitlines()[1:]:
                        kv("Note", warn_line.lstrip())
            except Exception:
                print(f"\nOperator intent  ({intent_path()}):")
                print(format_intent_for_status(parsed))
            if parsed.body.strip():
                print(parsed.body.rstrip())
    except Exception as exc:
        # Never let an intent-render error mask the rest of status.
        import logging

        logging.getLogger(__name__).debug("intent render failed: %s", exc)

    # v0.6.0 — upgrade notifier. Checks PyPI for a newer release
    # (cached 24h, 5s timeout, opt-out via NEBULA_SKIP_UPGRADE_CHECK=1)
    # and surfaces a one-line banner if an update is available.
    try:
        from core.upgrade_check import check_for_update, format_for_cli

        upgrade_status = check_for_update()
        banner = format_for_cli(upgrade_status)
        if banner:
            print()
            print(banner)
    except Exception as exc:
        # Upgrade check is a nice-to-have; never break ./nebula status
        import logging

        logging.getLogger(__name__).debug("upgrade check failed: %s", exc)


def cmd_specs():
    if not DB.exists():
        print("No database. Run: ./nebula install")
        return
    import sqlite3

    conn = sqlite3.connect(f"file:{DB}?mode=ro", uri=True)
    rows = conn.execute(
        "SELECT spec_name, overall_coverage, go_zenon_status, sdk_dart_status "
        "FROM spec_coverage ORDER BY overall_coverage DESC"
    ).fetchall()
    if not rows:
        print("No spec data yet.")
        return
    print(f"{'Spec':<25} {'Coverage':>8}  {'Go':>5}  {'SDK':>5}")
    print("-" * 50)
    for r in rows:
        cov = f"{r[1] * 100:.0f}%" if r[1] else "0%"
        go = "yes" if r[2] and r[2] != "not_started" else "-"
        sdk = "yes" if r[3] and r[3] != "not_started" else "-"
        print(f"{r[0][:24]:<25} {cov:>8}  {go:>5}  {sdk:>5}")
    conn.close()


def cmd_findings():
    if not DB.exists():
        print("No database. Run: ./nebula install")
        return
    import sqlite3

    # v0.6.6 — `nebula findings --by-provider` groups findings by the
    # api_sources column populated when engines route through the
    # provider registry. Only findings produced after v0.6.6 ship will
    # have non-NULL api_sources; legacy rows are bucketed under
    # "<unattributed>".
    by_provider = "--by-provider" in sys.argv

    conn = sqlite3.connect(f"file:{DB}?mode=ro", uri=True)
    try:
        status_rows = conn.execute(
            "SELECT COALESCE(status, 'open') as s, COUNT(*) FROM evidence GROUP BY s"
        ).fetchall()
        status = {r[0]: r[1] for r in status_rows}
        total = sum(status.values())
        print(
            f"Findings: {total} total - {status.get('open', 0)} open, "
            f"{status.get('resolved', 0)} resolved, {status.get('verified', 0)} verified"
        )
        print()
    except Exception:
        pass

    if by_provider:
        # Group findings by which provider(s) produced them. The
        # api_sources column is a JSON array; we use SQLite's json_each
        # to expand it. Findings without api_sources fall into the
        # "<unattributed>" bucket so legacy rows + filesystem-only
        # engines are still visible.
        try:
            stats = conn.execute(
                """
                SELECT
                    COALESCE(json_each.value, '<unattributed>') AS provider,
                    COUNT(*) AS finding_count,
                    AVG(confidence) AS avg_confidence
                FROM evidence
                LEFT JOIN json_each(evidence.api_sources)
                GROUP BY provider
                ORDER BY finding_count DESC
                """
            ).fetchall()
            print("Findings by provider:")
            print(f"  {'PROVIDER':<25} {'COUNT':>8} {'AVG_CONF':>10}")
            for provider, count, avg_conf in stats:
                avg_pct = f"{(avg_conf or 0) * 100:.0f}%"
                print(f"  {provider:<25} {count:>8} {avg_pct:>10}")
        except sqlite3.Error as exc:
            print(f"Could not group by provider: {exc}")
        conn.close()
        return

    rows = conn.execute(
        "SELECT domain, finding, printf('%.0f%%', confidence*100), "
        "COALESCE(status, 'open') FROM evidence "
        "ORDER BY timestamp DESC LIMIT 20"
    ).fetchall()
    for r in rows:
        marker = "x" if r[3] == "resolved" else "v" if r[3] == "verified" else " "
        finding_preview = (r[1] or "")[:100]
        print(f"[{marker}] [{r[0]:<15}] {r[2]:>4} {finding_preview}")
    conn.close()


def cmd_providers():
    """Dispatch `nebula providers [list|add|remove|test|reload]`.

    v0.6.6 — surfaces the ProviderRegistry so operators can see
    which external services Nebula has wired up, which are reachable,
    and which have actually been called recently.

    v0.6.9 — adds add/remove/test/reload subcommands for user
    provider config (``~/.config/nebula/providers.toml``).
    """
    # Dispatch subcommands via sys.argv so the existing COMMANDS
    # dispatcher shape (nullary callables) stays unchanged.
    args = sys.argv[2:] if len(sys.argv) > 2 else []
    if args and args[0] in ("add", "remove", "test", "reload"):
        return _cmd_providers_subcommand(args[0], args[1:])

    # Default: list all providers (original v0.6.6 behavior)
    from core.providers import get_registry

    registry = get_registry()
    providers = sorted(registry.list_all(), key=lambda p: (p.kind(), p.name()))

    if not providers:
        print("No providers registered.")
        return

    # Try to enrich with telemetry stats from api_call_log if it exists.
    stats_by_name: dict = {}
    if DB.exists():
        try:
            from core.api_telemetry import get_call_stats

            for stat in get_call_stats(db_path=str(DB), since_seconds=86_400):
                stats_by_name[stat["provider_name"]] = stat
        except Exception:
            pass

    print(f"Providers: {len(providers)} registered")
    print()
    print(f"  {'NAME':<18} {'KIND':<14} {'AVAIL':<7} {'CALLS_24H':>10} {'AVG_MS':>8}")
    print(f"  {'-' * 18} {'-' * 14} {'-' * 7} {'-' * 10} {'-' * 8}")
    for provider in providers:
        try:
            avail = "yes" if provider.is_available() else "no"
        except Exception:
            avail = "err"
        stat = stats_by_name.get(provider.name(), {})
        calls = stat.get("total_calls", 0) or 0
        avg_ms = stat.get("avg_latency_ms", 0) or 0
        print(f"  {provider.name():<18} {provider.kind():<14} {avail:<7} {calls:>10} {avg_ms:>8}")

    print()
    print("Run `./nebula findings --by-provider` to see which providers ")
    print("produced which findings.")
    print("Run `./nebula providers reload` to re-read ~/.config/nebula/providers.toml")


def _cmd_providers_subcommand(sub: str, extra: list[str]) -> int:
    """Handle `nebula providers {add|remove|test|reload}`.

    v0.6.9 — user-extensible provider config. Config file lives at
    ``$NEBULA_PROVIDERS_CONFIG`` or ``~/.config/nebula/providers.toml``.
    """
    from core.providers import get_registry

    if sub == "reload":
        registry = get_registry()
        count = registry.reload()
        print(f"Reloaded user providers: {count} user-declared providers registered")
        return 0

    if sub == "test":
        if not extra:
            print("Usage: nebula providers test <name>", file=sys.stderr)
            return 2
        name = extra[0]
        registry = get_registry()
        provider = registry.get(name)
        if provider is None:
            print(f"Unknown provider: {name!r}", file=sys.stderr)
            print(f"Available: {', '.join(sorted(registry.names()))}", file=sys.stderr)
            return 1
        print(f"Provider: {provider.name()}")
        print(f"  kind: {provider.kind()}")
        print(f"  description: {provider.description()}")
        print(f"  trust tier: {provider.trust_tier()}")
        try:
            available = provider.is_available()
        except Exception as exc:
            print(f"  is_available(): ERROR — {exc}")
            return 1
        print(f"  is_available(): {available}")
        if available:
            print("  Status: reachable / ready")
        else:
            print("  Status: not reachable (check env vars / network / subprocess)")
        return 0

    if sub in ("add", "remove"):
        # These subcommands edit ~/.config/nebula/providers.toml
        # directly. For safety we don't write arbitrary TOML from
        # argv — we just open the file for the operator and print
        # the path. The operator edits with their preferred editor
        # and runs `nebula providers reload`.
        from core.providers.loader import _candidate_config_paths, _first_existing_config

        existing = _first_existing_config()
        if existing is None:
            # Default to the XDG path
            candidates = _candidate_config_paths()
            default = candidates[1] if len(candidates) > 1 else candidates[0]
            default.parent.mkdir(parents=True, exist_ok=True)
            if not default.exists():
                default.write_text(
                    "# Nebula user provider config\n"
                    "# See docs/runbooks/user-providers.md for the full schema.\n"
                    "# Edit this file with [[api]] or [[mcp]] blocks, then run:\n"
                    "#   nebula providers reload\n"
                )
            existing = default
        print(f"Config file: {existing}")
        print()
        if sub == "add":
            print("Add a [[api]] or [[mcp]] block to this file, then run:")
            print("  nebula providers reload")
            print()
            print("Example [[api]] block:")
            print("  [[api]]")
            print('  name = "my-api"')
            print('  base_url = "https://api.example.com"')
            print("  [[api.endpoints]]")
            print('  method_name = "ping"')
            print('  http_method = "GET"')
            print('  path = "/ping"')
        else:
            print("Remove the [[api]] or [[mcp]] block with the matching name from")
            print("this file, then run:")
            print("  nebula providers reload")
        return 0

    print(f"Unknown subcommand: {sub!r}", file=sys.stderr)
    print(
        "Available: providers [list] | add | remove <name> | test <name> | reload",
        file=sys.stderr,
    )
    return 2


def cmd_plan():
    if not DB.exists():
        print("No database. Run: ./nebula install")
        return
    import json
    import sqlite3

    conn = sqlite3.connect(f"file:{DB}?mode=ro", uri=True)
    row = conn.execute(
        "SELECT situation_assessment, battle_plan_24h, resource_allocation, timestamp "
        "FROM battle_plans ORDER BY timestamp DESC LIMIT 1"
    ).fetchone()
    conn.close()
    if not row:
        plan_file = DATA_DIR / "battle_plan.json"
        if plan_file.exists():
            plan = json.loads(plan_file.read_text())
            print("Battle Plan")
            print("=" * 50)
            print(json.dumps(plan, indent=2)[:2000])
        else:
            print("No battle plan yet. Run: ./nebula")
        return
    print(f"Battle Plan ({row[3]})")
    print("=" * 50)
    if row[0]:
        print(f"\n{row[0]}\n")
    if row[1]:
        print(f"Focus: {row[1]}\n")
    if row[2]:
        print(f"Resources: {row[2]}")


def cmd_workspace():
    """Dispatch `nebula workspace [list|bootstrap|update|pin]`.

    v0.6.10 task #83 — closes the onboarding gap where
    ``pip install zenon-nebula`` leaves operators with an empty
    workspace. Uses ``data/workspace-manifest.yaml`` as the
    canonical list of Zenon repos a full workspace expects.

    Subcommands:
      list       — show manifest + per-entry clone status
      bootstrap  — clone every required entry. --all for optional
                   repos too. --use-fork for ZenonOrg forks.
      update     — git fetch --all across every cloned entry
      pin        — write current HEAD SHAs to workspace-lock.yaml
    """
    args = sys.argv[2:] if len(sys.argv) > 2 else []
    sub = args[0] if args else "list"
    extra = args[1:] if len(args) > 1 else []

    from core import workspace_manifest as wm

    manifest = wm.load()
    if manifest is None:
        print("No workspace manifest found at data/workspace-manifest.yaml.")
        print("The manifest is a ship artifact — something went wrong with your install.")
        return 1

    root = wm.get_workspace_root_or_warn()

    if sub == "list":
        return _cmd_workspace_list(manifest, root)
    if sub == "bootstrap":
        return _cmd_workspace_bootstrap(manifest, root, extra)
    if sub == "update":
        return _cmd_workspace_update(manifest, root, extra)
    if sub == "pin":
        return _cmd_workspace_pin(manifest, root, extra)

    print(f"Unknown subcommand: {sub}")
    print("Usage: nebula workspace [list|bootstrap|update|pin]")
    return 2


def _cmd_workspace_list(manifest, root):
    """Show every manifest entry with its clone status."""
    from core import workspace_manifest as wm

    print(f"Nebula workspace manifest v{manifest.version} (updated {manifest.updated})")
    print(f"{len(manifest.repos)} entries ({len(manifest.required())} required)")
    if root is None:
        print("Workspace root not set. `export ZENON_WORKSPACE_ROOT=...` to enable status.")
        print()
        for entry in manifest.repos:
            mark = "*" if entry.required else " "
            print(f"  {mark} [{entry.tier:8}] {entry.name:24} {entry.description}")
        return 0

    print(f"Workspace root: {root}")
    print()
    present = 0
    missing = 0
    for entry in manifest.repos:
        status = wm.check_status(entry, root)
        if status.present:
            present += 1
            state_str = f"cloned @ {status.head_sha[:8] if status.head_sha else '?'} ({status.branch or '?'})"
        else:
            missing += 1
            state_str = "MISSING"
        req = "REQUIRED" if entry.required else "optional"
        print(f"  [{entry.tier:8}] {entry.name:24} {req:9} {state_str}")
        print(f"              {entry.description}")
    print()
    print(f"Summary: {present}/{len(manifest.repos)} cloned, {missing} missing")
    if missing > 0:
        print("Run `./nebula workspace bootstrap` to clone missing required entries.")
    return 0


def _cmd_workspace_bootstrap(manifest, root, extra):
    """Clone required (or all) manifest entries to disk."""
    from core import workspace_manifest as wm

    if root is None:
        print("Workspace root not set. `export ZENON_WORKSPACE_ROOT=...` first.")
        return 2

    clone_all = "--all" in extra
    dry_run = "--dry-run" in extra
    prefer_fork = "--use-fork" in extra

    targets = manifest.repos if clone_all else manifest.required()
    print(f"Bootstrapping {len(targets)} entries (dry-run={dry_run}, fork={prefer_fork})")
    print()

    success = 0
    failed = 0
    skipped = 0
    for entry in targets:
        status = wm.check_status(entry, root)
        if status.present:
            skipped += 1
            print(f"  [skip] {entry.name}: already present")
            continue
        ok, msg = wm.clone_entry(entry, root, prefer_fork=prefer_fork, dry_run=dry_run)
        if ok:
            success += 1
            print(f"  [ok]   {msg}")
        else:
            failed += 1
            print(f"  [FAIL] {msg}")

    print()
    print(f"Done: {success} cloned, {skipped} already present, {failed} failed")
    return 0 if failed == 0 else 1


def _cmd_workspace_update(manifest, root, extra):
    """Fetch latest upstream for every cloned manifest entry."""
    import subprocess as _subprocess

    from core import workspace_manifest as wm

    if root is None:
        print("Workspace root not set. `export ZENON_WORKSPACE_ROOT=...` first.")
        return 2

    updated = 0
    errors = 0
    for entry in manifest.repos:
        status = wm.check_status(entry, root)
        if not status.present:
            continue
        target = entry.resolve_target(root)
        try:
            result = _subprocess.run(
                ["git", "fetch", "--all", "--quiet"],
                cwd=str(target),
                timeout=60,
                capture_output=True,
                text=True,
                check=False,
            )
            if result.returncode == 0:
                updated += 1
                print(f"  [ok] {entry.name}: fetched")
            else:
                errors += 1
                print(f"  [ERR] {entry.name}: {result.stderr.strip()[:200]}")
        except (_subprocess.TimeoutExpired, OSError) as exc:
            errors += 1
            print(f"  [ERR] {entry.name}: {exc}")
    print()
    print(f"Done: {updated} updated, {errors} errors")
    return 0 if errors == 0 else 1


def _cmd_workspace_pin(manifest, root, extra):
    """Write current HEAD SHAs to workspace-lock.yaml."""
    from datetime import datetime, timezone

    from core import workspace_manifest as wm

    if root is None:
        print("Workspace root not set. `export ZENON_WORKSPACE_ROOT=...` first.")
        return 2

    lock_path = DATA_DIR / "workspace-lock.yaml"
    lines = [
        "# Nebula workspace lock — HEAD SHA per manifest entry at pin time.",
        "# Generated by `nebula workspace pin`. Do not hand-edit.",
        f"pinned_at: {datetime.now(timezone.utc).isoformat()}",
        f"manifest_version: {manifest.version}",
        f"manifest_updated: {manifest.updated}",
        "repos:",
    ]
    pinned = 0
    for entry in manifest.repos:
        status = wm.check_status(entry, root)
        if not status.present:
            continue
        lines.append(f"  - name: {entry.name}")
        lines.append(f"    head_sha: {status.head_sha or 'unknown'}")
        lines.append(f"    branch: {status.branch or 'unknown'}")
        pinned += 1

    try:
        lock_path.parent.mkdir(parents=True, exist_ok=True)
        lock_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    except OSError as exc:
        print(f"Could not write lock file: {exc}")
        return 1

    print(f"Pinned {pinned} repos to {lock_path}")
    return 0


def cmd_domains():
    """List all registered domains and their engines."""
    import importlib

    from core.domain_registry import DomainRegistry

    DomainRegistry.reset()

    domains_dir = ROOT / "domains"
    for d in sorted(domains_dir.iterdir()):
        if d.is_dir() and (d / "domain.py").exists() and not d.name.startswith("_"):
            try:
                mod = importlib.import_module(f"domains.{d.name}.domain")
                for attr in dir(mod):
                    cls = getattr(mod, attr)
                    if (
                        isinstance(cls, type)
                        and hasattr(cls, "get_engines")
                        and attr not in ("DomainPlugin", "ABC")
                    ):
                        try:
                            instance = cls()
                            engines = instance.get_engines()
                            desc = (
                                instance.get_description()
                                if hasattr(instance, "get_description")
                                else ""
                            )
                            print(f"\n{d.name} ({len(engines)} engines)")
                            if desc:
                                print(f"  {desc[:80]}")
                            for e in engines:
                                print(f"  - {e.name:<30} P{e.priority}  {e.description[:60]}")
                            break
                        except Exception:
                            pass
            except Exception:
                pass

    total_domains = len(
        [d for d in domains_dir.iterdir() if d.is_dir() and (d / "domain.py").exists()]
    )
    print(f"\n{total_domains} domains total")


def cmd_hypotheses():
    if not DB.exists():
        print("No database. Run: ./nebula install")
        return
    import sqlite3

    conn = sqlite3.connect(f"file:{DB}?mode=ro", uri=True)
    rows = conn.execute(
        "SELECT id, domain, printf('%.0f%%', confidence*100), status, title "
        "FROM hypotheses ORDER BY confidence DESC"
    ).fetchall()
    conn.close()
    if not rows:
        print("No hypotheses. Run a few cycles to evolve them.")
        return
    print(f"{'ID':<30} {'Conf':>5} {'Status':<15} Title")
    print("-" * 90)
    for r in rows:
        print(f"{r[0]:<30} {r[2]:>5} {r[3]:<15} {(r[4] or '')[:40]}")


def cmd_costs():
    if not DB.exists():
        print("No database. Run: ./nebula install")
        return
    import sqlite3

    conn = sqlite3.connect(f"file:{DB}?mode=ro", uri=True)
    try:
        rows = conn.execute(
            "SELECT provider || '/' || model, COUNT(*), printf('$%.4f', SUM(cost_usd)) "
            "FROM cost_tracking GROUP BY provider, model ORDER BY SUM(cost_usd) DESC"
        ).fetchall()
        total = conn.execute(
            "SELECT printf('$%.4f', COALESCE(SUM(cost_usd), 0)) FROM cost_tracking"
        ).fetchone()[0]
    except sqlite3.OperationalError:
        print("cost_tracking table missing. Run `./nebula doctor --fix`.")
        conn.close()
        return
    conn.close()
    if not rows:
        print("No LLM costs tracked yet.")
        return
    print(f"{'Provider/Model':<35} {'Calls':>6} {'Total':>10}")
    print("-" * 55)
    for r in rows:
        print(f"{r[0]:<35} {r[1]:>6} {r[2]:>10}")
    print("-" * 55)
    print(f"{'TOTAL':<35} {'':>6} {total:>10}")


def cmd_serve():
    os.execvp(sys.executable, [sys.executable, str(ROOT / "scripts" / "mcp_server.py")])


def cmd_height():
    from core.sync import get_evidence_height

    print(f"Evidence height: {get_evidence_height(str(DB))}")


def cmd_snapshot(args):
    if not args:
        print("Usage: nebula snapshot export | nebula snapshot import FILE")
        return
    subcmd = args[0]
    if subcmd == "export":
        from core.sync import export_snapshot

        print(f"Snapshot exported: {export_snapshot(str(DB))}")
    elif subcmd == "import":
        if len(args) < 2:
            print("Usage: nebula snapshot import FILE")
            return
        from core.sync import import_snapshot

        stats = import_snapshot(str(DB), args[1])
        print(
            f"Evidence imported: {stats['evidence_imported']}  (skipped: {stats['evidence_skipped']})"
        )
        print(
            f"Hypotheses imported: {stats['hypotheses_imported']}  (skipped: {stats['hypotheses_skipped']})"
        )
    else:
        print(f"Unknown snapshot subcommand: {subcmd}")


def cmd_bootstrap(args):
    """Bootstrap a fresh Nebula instance from an elder peer's snapshot.

    Downloads the snapshot at ``args[0]`` (or ``NEBULA_ELDER_URL`` env)
    and imports it. The elder_id stamped on the snapshot (task #73
    Phase 1) auto-credits the elder in the local peer_activity table,
    so the new instance's decay multiplier sees them as known going
    forward.

    Usage:
      nebula bootstrap URL          # explicit URL
      nebula bootstrap              # uses NEBULA_ELDER_URL env var

    The DB must be empty (or nearly so) for bootstrap to make sense.
    This command refuses to run against a non-empty evidence table
    unless --force is passed — guards against accidentally layering
    an elder's full history on top of an active instance's own work.
    """
    import sqlite3

    from core.sync import sync_from_url

    force = "--force" in args
    positional = [a for a in args if not a.startswith("--")]
    url = positional[0] if positional else os.environ.get("NEBULA_ELDER_URL", "").strip()

    if not url:
        print(
            "Usage: nebula bootstrap URL  (or set NEBULA_ELDER_URL env var).",
            file=sys.stderr,
        )
        sys.exit(2)

    # Safety rail: an active instance shouldn't be bootstrapped.
    if DB.exists():
        try:
            conn = sqlite3.connect(f"file:{DB}?mode=ro", uri=True)
            existing = conn.execute("SELECT COUNT(*) FROM evidence").fetchone()[0]
            conn.close()
        except sqlite3.OperationalError:
            existing = 0
        if existing > 0 and not force:
            print(
                f"Refusing to bootstrap: local DB has {existing} evidence row(s). "
                "Bootstrap is for fresh instances. Pass --force if you really "
                "want to layer elder content on top of existing history.",
                file=sys.stderr,
            )
            sys.exit(1)

    print(f"Bootstrap: downloading elder snapshot from {url}")
    result = sync_from_url(str(DB), url=url)
    if "error" in result:
        print(f"Bootstrap failed: {result['error']}", file=sys.stderr)
        sys.exit(1)
    print(
        f"Bootstrap complete. Evidence: {result['evidence_imported']} "
        f"(skipped: {result['evidence_skipped']}). Hypotheses: "
        f"{result['hypotheses_imported']} (skipped: {result['hypotheses_skipped']})."
    )
    # Surface whether an elder was credited so operators know the
    # decay tracking is live for this source.
    try:
        conn = sqlite3.connect(f"file:{DB}?mode=ro", uri=True)
        peer_count = conn.execute("SELECT COUNT(*) FROM peer_activity").fetchone()[0]
        conn.close()
        if peer_count > 0:
            print(f"Elder attribution recorded ({peer_count} peer(s) tracked).")
    except sqlite3.OperationalError:
        pass


def cmd_sync():
    from core.sync import sync_from_url

    result = sync_from_url(str(DB))
    if "error" in result:
        print(f"Sync failed: {result['error']}")
    else:
        print(
            f"Sync complete. Evidence imported: {result['evidence_imported']}  (skipped: {result['evidence_skipped']})"
        )
        print(
            f"Hypotheses imported: {result['hypotheses_imported']}  (skipped: {result['hypotheses_skipped']})"
        )


def cmd_config(args: list[str]):
    """Manage .env config values from the controller.

    Subcommands:
        nebula config                    — list non-secret config keys
        nebula config get KEY            — print a single value
        nebula config set KEY VALUE      — set a value (persists to .env)
        nebula config unset KEY          — remove a key
        nebula config api-key [KEY]      — interactively set XAI_API_KEY

    API keys are NEVER echoed back in full — only first/last 4 chars.
    """

    def _ensure_env() -> None:
        if not ENV_FILE.exists():
            ENV_FILE.write_text("")

    def _parse_env() -> list[tuple[str, str]]:
        if not ENV_FILE.exists():
            return []
        out: list[tuple[str, str]] = []
        for raw in ENV_FILE.read_text(encoding="utf-8").splitlines():
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, _, v = line.partition("=")
            out.append((k.strip(), v.strip().strip('"').strip("'")))
        return out

    def _write_env(pairs: list[tuple[str, str]]) -> None:
        # Preserve comments and blank lines from the original file;
        # only rewrite KEY=VALUE lines for keys we know about.
        existing_lines = (
            ENV_FILE.read_text(encoding="utf-8").splitlines() if ENV_FILE.exists() else []
        )
        known_keys = {k for k, _ in pairs}
        seen: set[str] = set()
        out: list[str] = []
        for raw in existing_lines:
            stripped = raw.strip()
            if not stripped or stripped.startswith("#") or "=" not in stripped:
                out.append(raw)
                continue
            k = stripped.split("=", 1)[0].strip()
            if k in known_keys and k not in seen:
                val = next(v for kk, v in pairs if kk == k)
                out.append(f"{k}={val}")
                seen.add(k)
            elif k not in known_keys:
                out.append(raw)
        # Append any new keys we haven't written yet
        for k, v in pairs:
            if k not in seen:
                out.append(f"{k}={v}")
        ENV_FILE.write_text("\n".join(out) + "\n", encoding="utf-8")

    _SECRET_SUFFIXES = ("_KEY", "_TOKEN", "_SECRET", "_PASSWORD", "_PASS")

    def _is_secret(key: str) -> bool:
        return any(key.upper().endswith(s) for s in _SECRET_SUFFIXES)

    def _redact(val: str) -> str:
        if not val:
            return ""
        if len(val) <= 8:
            return "***"
        return f"{val[:4]}...{val[-4:]}"

    sub = args[0] if args else "list"

    if sub in ("list", "ls", ""):
        pairs = _parse_env()
        if not pairs:
            print("No config set. Run `./nebula install` or `./nebula config set KEY VALUE`.")
            return 0
        print("Config (from .env):")
        for k, v in pairs:
            display = _redact(v) if _is_secret(k) else v
            print(f"  {k:<30} = {display}")
        return 0

    if sub == "get":
        if len(args) < 2:
            print("Usage: nebula config get KEY")
            return 2
        key = args[1]
        pairs = dict(_parse_env())
        if key not in pairs:
            print(f"{key} is not set.")
            return 1
        val = pairs[key]
        if _is_secret(key):
            print(_redact(val))
        else:
            print(val)
        return 0

    if sub == "set":
        if len(args) < 3:
            print("Usage: nebula config set KEY VALUE")
            return 2
        key, val = args[1], " ".join(args[2:])
        _ensure_env()
        current = dict(_parse_env())
        current[key] = val
        _write_env(list(current.items()))
        display = _redact(val) if _is_secret(key) else val
        print(f"  {key} = {display}")
        return 0

    if sub == "unset":
        if len(args) < 2:
            print("Usage: nebula config unset KEY")
            return 2
        key = args[1]
        current = dict(_parse_env())
        if key not in current:
            print(f"{key} is not set.")
            return 0
        del current[key]
        _write_env(list(current.items()))
        print(f"Unset {key}.")
        return 0

    if sub == "api-key":
        # Convenience: set XAI_API_KEY (the only required secret today)
        # with an interactive prompt that doesn't echo the value.
        _ensure_env()
        if len(args) > 1:
            api_key = args[1]
        else:
            import getpass

            print("Paste your xAI API key (hidden input):")
            print("Get one at: https://console.x.ai")
            try:
                api_key = getpass.getpass("  XAI_API_KEY: ").strip()
            except (EOFError, KeyboardInterrupt):
                print("\nAborted.")
                return 1
        if not api_key:
            print("No key provided. Nothing changed.")
            return 1
        if not api_key.startswith("xai-"):
            print("WARNING: key doesn't start with 'xai-' — double-check it's the right key.")
        current = dict(_parse_env())
        current["XAI_API_KEY"] = api_key
        _write_env(list(current.items()))
        print(f"  XAI_API_KEY = {_redact(api_key)}")
        print("Key saved to .env. Run `./nebula doctor` to verify.")
        return 0

    print(f"Unknown config subcommand: {sub}")
    print("Usage: nebula config [list | get KEY | set KEY VALUE | unset KEY | api-key [KEY]]")
    return 2


def cmd_transport(args: list[str]):
    """Manage the evidence transport mode (local / shared / nexus).

    Subcommands:
        nebula transport              — show current mode + stats
        nebula transport status       — same as above
        nebula transport local        — switch to local (no sharing)
        nebula transport shared [DIR] — switch to file-based sharing
        nebula transport nexus [URL]  — switch to Nexus/SpacetimeDB
        nebula transport sync         — force a publish + pull cycle
        nebula transport peers        — list configured peers
    """
    sub = args[0] if args else "status"

    def _read_env_var(key: str) -> str:
        if not ENV_FILE.exists():
            return ""
        for line in ENV_FILE.read_text(encoding="utf-8").splitlines():
            if line.strip().startswith(f"{key}="):
                return line.split("=", 1)[1].strip().strip('"').strip("'")
        return ""

    def _set_env_var(key: str, value: str) -> None:
        """Update or append a KEY=VALUE line in .env."""
        if not ENV_FILE.exists():
            ENV_FILE.write_text("")
        lines = ENV_FILE.read_text(encoding="utf-8").splitlines()
        out: list[str] = []
        updated = False
        for line in lines:
            if line.strip().startswith(f"{key}="):
                out.append(f"{key}={value}")
                updated = True
            else:
                out.append(line)
        if not updated:
            out.append(f"{key}={value}")
        ENV_FILE.write_text("\n".join(out) + "\n")

    if sub in ("status", "show", ""):
        mode = _read_env_var("NEBULA_TRANSPORT") or "local"
        print(f"Transport: {mode}")
        if mode == "shared":
            shared_dir = _read_env_var("NEBULA_SHARED_DIR") or "(default)"
            print(f"  shared_dir: {shared_dir}")
        elif mode == "nexus":
            nexus_url = _read_env_var("NEXUS_URL") or "(unset)"
            print(f"  nexus_url:  {nexus_url}")
        participant = _read_env_var("NEBULA_PARTICIPANT_ID") or "anonymous"
        print(f"  participant: {participant}")
        # Runtime stats: how many findings have we published
        if DB.exists():
            import sqlite3

            conn = sqlite3.connect(f"file:{DB}?mode=ro", uri=True)
            try:
                total = conn.execute("SELECT COUNT(*) FROM evidence").fetchone()[0]
                try:
                    pub = conn.execute(
                        "SELECT COUNT(*) FROM evidence WHERE COALESCE(published, 0) = 1"
                    ).fetchone()[0]
                except Exception:
                    pub = 0
                try:
                    peer = conn.execute(
                        "SELECT COUNT(*) FROM evidence WHERE provenance LIKE 'peer:%'"
                    ).fetchone()[0]
                except Exception:
                    peer = 0
                print(f"  local findings: {total}")
                print(f"  published:      {pub}")
                print(f"  peer findings:  {peer}")
            finally:
                conn.close()
        return 0

    if sub == "local":
        _set_env_var("NEBULA_TRANSPORT", "local")
        print("Transport set to: local (no sharing).")
        return 0

    if sub == "shared":
        shared_dir = args[1] if len(args) > 1 else ""
        _set_env_var("NEBULA_TRANSPORT", "shared")
        if shared_dir:
            _set_env_var("NEBULA_SHARED_DIR", shared_dir)
            print(f"Transport set to: shared ({shared_dir})")
        else:
            print("Transport set to: shared (using default NEBULA_SHARED_DIR)")
        print("Run `./nebula transport sync` to exchange findings with peers.")
        return 0

    if sub == "nexus":
        nexus_url = args[1] if len(args) > 1 else ""
        _set_env_var("NEBULA_TRANSPORT", "nexus")
        if nexus_url:
            _set_env_var("NEXUS_URL", nexus_url)
            print(f"Transport set to: nexus ({nexus_url})")
        else:
            print("Transport set to: nexus. Set NEXUS_URL in .env for the server address.")
        return 0

    if sub == "sync":
        # Trigger a publish + pull cycle via the configured transport.
        mode = _read_env_var("NEBULA_TRANSPORT") or "local"
        if mode == "local":
            print("Transport is 'local' — nothing to sync.")
            print(
                "Run `./nebula transport shared` or `./nebula transport nexus` to enable sharing."
            )
            return 0
        # Reload env so the transport factory sees the current mode
        os.environ["NEBULA_TRANSPORT"] = mode
        if mode == "shared":
            sd = _read_env_var("NEBULA_SHARED_DIR")
            if sd:
                os.environ["NEBULA_SHARED_DIR"] = sd
        try:
            from core.transport import get_transport
        except Exception as exc:
            print(f"Failed to load transport module: {exc}")
            return 1
        t = get_transport(str(DB))
        print(f"Syncing via {mode} transport...")
        try:
            result = t.sync()
        except Exception as exc:
            print(f"Sync failed: {exc}")
            return 1
        pub = result.get("publish", {}).get("published", 0)
        pulled = result.get("pull", {}).get("imported", 0)
        print(f"  published: {pub}")
        print(f"  imported:  {pulled}")
        return 0

    if sub == "peers":
        peers = _read_env_var("NEBULA_RPC_PEERS")
        if not peers:
            print("No peers configured. Set NEBULA_RPC_PEERS=http://peer1:8484,... in .env")
            return 0
        print("Configured peers:")
        for p in peers.split(","):
            p = p.strip()
            if p:
                print(f"  - {p}")
        return 0

    print(f"Unknown transport subcommand: {sub}")
    print("Run `./nebula transport --help` or see docs/operations/transport.md")
    return 2


def cmd_version():
    try:
        from core.version import get_version_info

        info = get_version_info()
        print(f"Nebula {info.get('version', '?')}")
        if info.get("protocol_version") is not None:
            print(f"  protocol:     v{info['protocol_version']}")
        print(f"  build date:   {info.get('build_date', '?')}")
        print(f"  build commit: {info.get('build_commit', '?')}")
        print(f"  python:       {sys.version.split()[0]}")
    except Exception:
        try:
            from core.version import __version__

            print(f"Nebula {__version__}")
        except Exception:
            print("Nebula (version unknown)")


def cmd_update():
    """Safe self-update via scripts/update.py (git-clone install path)."""
    import subprocess

    update_script = ROOT / "scripts" / "update.py"
    if not update_script.exists():
        sys.stderr.write(f"Updater not found at {update_script}\n")
        sys.exit(1)
    forwarded = sys.argv[2:]
    rc = subprocess.run(
        [sys.executable, str(update_script), *forwarded],
        cwd=str(ROOT),
    ).returncode
    sys.exit(rc)


def cmd_upgrade():
    """Upgrade the pip-installed zenon-nebula package.

    Complements ``./nebula update`` (which assumes a git clone and does
    a fast-forward + schema migration + smoke-test loop). This command
    is for operators who installed via ``pip install zenon-nebula`` and
    need to pull a newer wheel from PyPI.

    Flags:
      --rollback   Pin back to the version stamped by the last successful
                   ``./nebula upgrade``. Fails if no stamp exists.
      --dry-run    Print what would happen; don't invoke pip.
      --force      Upgrade even if the target version is listed as broken
                   in ``data/broken_versions.txt``. Use when the operator
                   has verified the broken mark is stale or doesn't
                   apply to their environment.
    """
    args = sys.argv[2:]
    rollback = "--rollback" in args
    dry_run = "--dry-run" in args
    force = "--force" in args

    # Unknown flags → usage and bail. Quiet mode for --help-like probes.
    known_flags = ("--rollback", "--dry-run", "--force", "-h", "--help")
    for a in args:
        if a not in known_flags:
            sys.stderr.write(
                f"Unknown flag: {a}\nUsage: nebula upgrade [--rollback] [--dry-run] [--force]\n"
            )
            sys.exit(2)
    if "-h" in args or "--help" in args:
        print(cmd_upgrade.__doc__)
        return

    from core.upgrade_command import (
        format_result,
        rollback_to_previous,
        upgrade_to_latest,
    )

    if rollback:
        result = rollback_to_previous(dry_run=dry_run)
    else:
        result = upgrade_to_latest(dry_run=dry_run, force=force)
    print(format_result(result))
    sys.exit(0 if result.ok else 1)


def cmd_hosts():
    """Manage the universal_http allowlist — task #67 Phase E.

    The allowlist gates every ``universal_fetch`` call. Edit it with
    these subcommands or by hand in ``data/allowed_api_hosts.txt``
    (format: one host per line, ``#`` starts a comment).

    Subcommands:
      nebula hosts list             Show every listed host.
      nebula hosts add <host>       Add a host. No-op if already listed.
      nebula hosts remove <host>    Remove a host. No-op if not listed.
      nebula hosts reload           Force-reload the file into the
                                    in-process cache (useful after
                                    external edits).

    Redirect the allowlist path via NEBULA_ALLOWED_HOSTS_FILE env.
    """
    args = sys.argv[2:]
    if not args or args[0] in ("-h", "--help"):
        print(cmd_hosts.__doc__)
        return

    from core.universal_http import _allowlist_path, reload_allowlist

    sub = args[0]
    path = _allowlist_path()

    if sub == "list":
        hosts = sorted(reload_allowlist())
        if not hosts:
            print(f"No hosts in {path}")
            return
        print(f"{len(hosts)} host(s) in {path}:")
        for h in hosts:
            print(f"  {h}")
        return

    if sub == "reload":
        hosts = reload_allowlist()
        print(f"Reloaded {len(hosts)} host(s) from {path}")
        return

    if sub in ("add", "remove"):
        if len(args) < 2:
            sys.stderr.write(f"Usage: nebula hosts {sub} <host>\n")
            sys.exit(2)
        host = args[1].strip().lower()
        if not host or "/" in host or " " in host:
            sys.stderr.write(
                f"Invalid host {host!r}. Expected a bare hostname "
                "like 'api.example.com' — no scheme, no path, no spaces.\n"
            )
            sys.exit(2)
        lines = path.read_text(encoding="utf-8").splitlines() if path.exists() else []
        # Split every line into (comment_or_empty, host_if_any).
        parsed = []
        for raw in lines:
            stripped = raw.split("#", 1)[0].strip().lower()
            parsed.append((raw, stripped))
        existing = {h for _, h in parsed if h}

        if sub == "add":
            if host in existing:
                print(f"Already listed: {host}")
                return
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open("a", encoding="utf-8") as f:
                # Ensure the previous line ended with a newline before
                # appending. Rare edge case: hand-edited file without
                # trailing newline.
                if lines and not (path.read_text(encoding="utf-8")).endswith("\n"):
                    f.write("\n")
                f.write(f"{host}\n")
            reload_allowlist()
            print(f"Added: {host}")
            return

        # remove
        if host not in existing:
            print(f"Not listed: {host}")
            return
        kept = [raw for raw, h in parsed if h != host]
        path.write_text("\n".join(kept) + ("\n" if kept else ""), encoding="utf-8")
        reload_allowlist()
        print(f"Removed: {host}")
        return

    sys.stderr.write(f"Unknown subcommand: {sub!r}\nTry: nebula hosts list|add|remove|reload\n")
    sys.exit(2)


def cmd_tasks(args=None):
    """Print a status summary of the docs/tasks.yaml ledger.

    Walks docs/tasks.yaml (the canonical task registry per
    .claude/rules/task-durability.md) and prints counts by status
    + optionally filtered views. Useful for every future session
    that wants to know what's in-progress or pending without
    scrolling the YAML by hand.

    Usage:
      nebula tasks                     Full summary (counts + top rows).
      nebula tasks in-progress         Only in_progress tasks.
      nebula tasks pending             Only pending tasks.
      nebula tasks pending --phase X   Filter pending to a specific phase.
      nebula tasks N                   Show the full entry for task #N.

    Shape is read via a minimal YAML parser (no PyYAML dependency)
    so this command works on the most degraded install — it's a
    session-tool, not engine-critical, and should never fail to
    answer a basic operator question because of a missing dep.
    """
    import re as _re

    if args is None:
        args = sys.argv[2:]

    yaml_path = ROOT / "docs" / "tasks.yaml"
    if not yaml_path.is_file():
        sys.stderr.write(f"tasks: {yaml_path} not found\n")
        sys.exit(2)

    raw = yaml_path.read_text(encoding="utf-8")
    tasks: list[dict] = []
    current: dict | None = None
    for line in raw.splitlines():
        m_id = _re.match(r"^\s{0,2}-\s+id:\s*(\d+)", line)
        if m_id:
            if current is not None:
                tasks.append(current)
            current = {"id": int(m_id.group(1))}
            continue
        if current is None:
            continue
        m_kv = _re.match(r"^\s{4,}(\w+):\s*(.*)", line)
        if m_kv:
            key = m_kv.group(1)
            val = m_kv.group(2).strip().strip('"').strip("'")
            if key not in current and key in ("title", "status", "phase", "opened"):
                current[key] = val
    if current is not None:
        tasks.append(current)

    if not tasks:
        sys.stderr.write("tasks: parser found zero tasks (is the YAML well-formed?)\n")
        sys.exit(1)

    filter_status: str | None = None
    phase_filter: str | None = None
    single_id: int | None = None
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--phase" and i + 1 < len(args):
            phase_filter = args[i + 1]
            i += 2
            continue
        if a in ("pending", "in_progress", "in-progress", "completed"):
            filter_status = a.replace("-", "_")
            i += 1
            continue
        if a.isdigit():
            single_id = int(a)
            i += 1
            continue
        if a in ("-h", "--help"):
            print(cmd_tasks.__doc__)
            return
        sys.stderr.write(f"Unknown argument: {a}\nTry: nebula tasks --help\n")
        sys.exit(2)

    if single_id is not None:
        matches = [t for t in tasks if t["id"] == single_id]
        if not matches:
            sys.stderr.write(f"tasks: no task with id #{single_id}\n")
            sys.exit(1)
        t = matches[0]
        print(f"#{t['id']} — {t.get('title', '(no title)')}")
        for key in ("status", "phase", "opened"):
            if key in t:
                print(f"  {key}: {t[key]}")
        return

    filtered = tasks
    if filter_status is not None:
        filtered = [t for t in filtered if t.get("status") == filter_status]
    if phase_filter is not None:
        filtered = [t for t in filtered if t.get("phase") == phase_filter]

    counts: dict[str, int] = {}
    for t in tasks:
        st = t.get("status", "(unknown)")
        counts[st] = counts.get(st, 0) + 1

    total = len(tasks)
    summary_parts = [f"{status}={count}" for status, count in sorted(counts.items())]
    print(f"docs/tasks.yaml — {total} task(s): {', '.join(summary_parts)}")
    if filter_status or phase_filter:
        filt_desc = []
        if filter_status:
            filt_desc.append(f"status={filter_status}")
        if phase_filter:
            filt_desc.append(f"phase={phase_filter}")
        print(f"filtered: {', '.join(filt_desc)} → {len(filtered)} row(s)")
    print()

    rows_to_show = filtered if filter_status or phase_filter else filtered[:20]
    for t in rows_to_show:
        status = t.get("status", "?")
        title = t.get("title", "(no title)")
        if len(title) > 72:
            title = title[:69] + "..."
        print(f"  #{t['id']:<3}  [{status:<12}]  {title}")
    if not filter_status and not phase_filter and len(tasks) > 20:
        print(f"  ... and {len(tasks) - 20} more. Filter with `nebula tasks pending` etc.")


def cmd_doctor():
    """Health check. With --fix, auto-repair what's fixable."""
    fix = "--fix" in sys.argv[2:]

    all_ok = True
    fixed_any = False

    def report(label: str, passed: bool, detail: str = ""):
        nonlocal all_ok
        mark = "OK  " if passed else "FAIL"
        suffix = f" — {detail}" if detail and not passed else ""
        print(f"  [{mark}] {label}{suffix}")
        if not passed:
            all_ok = False

    print("Nebula Doctor")
    print("=" * 50)

    # Python version (already validated at bootstrap but echo for clarity)
    pyv = sys.version_info
    report(f"Python version ({pyv.major}.{pyv.minor}.{pyv.micro})", pyv >= _MIN_PY)

    # Required dependencies
    missing = _check_deps(REQUIRED_DEPS)
    for import_name, pip_name, _purpose in REQUIRED_DEPS:
        report(f"dependency: {pip_name}", (import_name, pip_name, _purpose) not in missing)
    if missing and fix:
        print("  [FIX] installing missing dependencies ...")
        r = _pip_install(["-r", str(ROOT / "requirements.txt")], capture=True)
        if r.returncode == 0:
            print("  [FIX] dependencies installed")
            fixed_any = True
        else:
            print(f"  [FIX] pip install failed:\n{(r.stderr or r.stdout)[-1200:]}")

    # Optional deps (reported only, never fail)
    for import_name, pip_name, purpose in OPTIONAL_DEPS:
        try:
            __import__(import_name)
            print(f"  [OK  ] optional: {pip_name} ({purpose})")
        except ImportError:
            print(f"  [SKIP] optional: {pip_name} — pip install {pip_name}")

    # Version module
    try:
        from core.version import PROTOCOL_VERSION, __version__

        report(f"core.version importable ({__version__}, protocol v{PROTOCOL_VERSION})", True)
    except Exception as exc:
        report("core.version importable", False, str(exc))

    # .env file
    if ENV_FILE.exists():
        report(".env file present", True)
    else:
        report(".env file present", False, str(ENV_FILE))
        if fix and ENV_TEMPLATE.exists():
            try:
                ENV_FILE.write_text(ENV_TEMPLATE.read_text())
                print(
                    f"  [FIX] created {ENV_FILE.name} from template — edit it and set XAI_API_KEY"
                )
                fixed_any = True
            except OSError as exc:
                print(f"  [FIX] could not create .env: {exc}")

    # XAI_API_KEY (informational — not a hard failure; Nebula degrades gracefully)
    if os.environ.get("XAI_API_KEY"):
        print("  [OK  ] XAI_API_KEY present")
    else:
        print("  [WARN] XAI_API_KEY missing — LLM-powered engines will be skipped")

    # Data dir
    try:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        report(f"data directory ({DATA_DIR.relative_to(ROOT)})", True)
    except OSError as exc:
        report("data directory", False, str(exc))

    # Database
    if DB.exists():
        import sqlite3

        try:
            conn = sqlite3.connect(f"file:{DB}?mode=ro", uri=True)
            n_tables = conn.execute(
                "SELECT COUNT(*) FROM sqlite_master WHERE type='table'"
            ).fetchone()[0]
            conn.close()
            report(f"database ({n_tables} tables)", True)
        except Exception as exc:
            report("database readable", False, str(exc))
    else:
        report("database initialized", False, f"not at {DB} — run: ./nebula install")
        if fix:
            try:
                from core.persistence.schema import ensure_schema

                ensure_schema(str(DB))
                print("  [FIX] database initialized")
                fixed_any = True
            except Exception as exc:
                print(f"  [FIX] database init failed: {exc}")

    # git (only required for `nebula update`)
    if _has_command("git"):
        print("  [OK  ] git available (enables ./nebula update)")
    else:
        print("  [WARN] git not on PATH — ./nebula update will be unavailable")

    # Telemetry status (informational)
    try:
        from core.telemetry import is_enabled

        print(
            f"  [{'OK  ' if is_enabled() else 'SKIP'}] telemetry: {'enabled' if is_enabled() else 'disabled'}"
        )
    except Exception:
        pass  # telemetry module may be absent on legacy installs

    print()
    if all_ok:
        print("All required checks passed.")
        return 0
    if fix and fixed_any:
        print("Some checks were auto-repaired. Re-run ./nebula doctor to confirm.")
    else:
        print("Some checks failed. Fix issues above (or run: ./nebula doctor --fix).")
    return 1


def cmd_trust_history():
    """v0.4.2 — show dynamic trust tiers + quality-score trajectories.

    Usage:
        ./nebula trust-history                  # top 20 repos by trust
        ./nebula trust-history --top 50         # top 50
        ./nebula trust-history <repo-identity>  # full trajectory for one repo
        ./nebula trust-history --all            # every scanned repo

    Reads repo_trust_history (populated by the v0.3.4
    source_quality_scorer engine) and compute_dynamic_trust (v0.4.0
    Phase C) to show the content-based trust state of the workspace.
    No identity columns, no author data — scores only, repo
    identities only, strictly content-derived.
    """
    args = sys.argv[2:]
    db_path = str(DB)

    top_n = 20
    show_all = False
    specific_repo: str | None = None

    i = 0
    while i < len(args):
        arg = args[i]
        if arg == "--top":
            i += 1
            if i < len(args):
                try:
                    top_n = int(args[i])
                except ValueError:
                    print(f"Invalid --top value: {args[i]}")
                    return 1
        elif arg == "--all":
            show_all = True
        elif arg.startswith("-"):
            print(f"Unknown flag: {arg}")
            return 1
        else:
            specific_repo = arg
        i += 1

    import sqlite3

    try:
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
    except Exception as exc:
        print(f"Cannot open database: {exc}")
        return 1

    try:
        # Verify the table exists — pre-v0.3.4 DBs won't have it
        has_table = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='repo_trust_history'"
        ).fetchone()
        if not has_table:
            print("repo_trust_history table not found.")
            print(
                "This feature requires v0.3.4+. Run a few cycles of "
                "`./nebula --cycles 3` to populate the history."
            )
            return 1

        from core.trust import compute_dynamic_trust

        if specific_repo:
            # Show trajectory for one repo
            rows = conn.execute(
                """
                SELECT quality_score, signals_json, files_scanned,
                       bytes_scanned, scanned_at
                FROM repo_trust_history
                WHERE repo_identity = ?
                ORDER BY scanned_at DESC
                LIMIT 50
                """,
                (specific_repo,),
            ).fetchall()

            if not rows:
                print(f"No trust history for `{specific_repo}`.")
                print(
                    "Either the repo hasn't been scanned yet (run a "
                    "few cycles) or the identity doesn't match "
                    "anything in the workspace."
                )
                return 0

            trust = compute_dynamic_trust(specific_repo, db_path=db_path)
            tier_name = _tier_name(trust)
            print()
            print(f"Trust history for: {specific_repo}")
            print("=" * 70)
            print(f"  Current dynamic trust: {trust:.3f}  ({tier_name})")
            print(f"  Scans recorded:        {len(rows)}")
            latest_score = rows[0]["quality_score"]
            print(f"  Latest quality score:  {latest_score:.3f}")
            avg = sum(r["quality_score"] for r in rows) / len(rows)
            print(f"  Rolling avg (last 50): {avg:.3f}")
            print()
            print("Recent scans (most recent first):")
            print(f"  {'When':<20} {'Quality':<10} {'Files':<8} Top signals")
            import json as _json

            for row in rows[:15]:
                when = (row["scanned_at"] or "")[:19]
                score = row["quality_score"]
                files = row["files_scanned"]
                signals_json = row["signals_json"] or "{}"
                try:
                    signals = _json.loads(signals_json)
                    top_3 = sorted(signals.items(), key=lambda kv: -kv[1])[:3]
                    top_str = ", ".join(f"{k}={v:.2f}" for k, v in top_3)
                except Exception:
                    top_str = "(malformed signals_json)"
                print(f"  {when:<20} {score:<10.3f} {files:<8} {top_str[:50]}")
            print()
            return 0

        # List mode: top N by most recent quality_score
        query = """
            SELECT repo_identity,
                   MAX(scanned_at) AS last_scan,
                   AVG(quality_score) AS avg_score,
                   COUNT(*) AS scan_count
            FROM repo_trust_history
            GROUP BY repo_identity
            ORDER BY avg_score DESC
        """
        if not show_all:
            query += f" LIMIT {top_n}"
        rows = conn.execute(query).fetchall()

        if not rows:
            print("No repos scored yet.")
            print(
                "Run `./nebula --cycles 5` to let the source_quality_scorer "
                "engine populate the trust history."
            )
            return 0

        print()
        print("Nebula Trust History")
        print("=" * 70)
        print(f"  {'Repo':<35} {'Trust':<8} {'AvgQ':<8} {'Scans':<8} {'Tier':<10}")
        print("-" * 70)
        for row in rows:
            repo = row["repo_identity"][:34]
            trust = compute_dynamic_trust(row["repo_identity"], db_path=db_path)
            avg = row["avg_score"]
            scans = row["scan_count"]
            tier = _tier_name(trust)
            print(f"  {repo:<35} {trust:<8.3f} {avg:<8.3f} {scans:<8d} {tier:<10}")
        print()
        print(
            f"Showing {len(rows)} repo(s). "
            f"Use `./nebula trust-history <repo>` for detailed trajectory."
        )
        return 0
    finally:
        conn.close()


def _tier_name(trust: float) -> str:
    """Map a numeric trust score to a human-readable tier name."""
    if trust >= 0.90:
        return "core"
    if trust >= 0.70:
        return "trusted"
    if trust >= 0.50:
        return "attested"
    return "default"


# ---------------------------------------------------------------------------
# Dispatch
# ---------------------------------------------------------------------------

COMMANDS = {
    "install": cmd_install,
    "status": cmd_status,
    "specs": cmd_specs,
    "findings": cmd_findings,
    "plan": cmd_plan,
    "domains": cmd_domains,
    "engines": cmd_domains,  # alias
    "hypotheses": cmd_hypotheses,
    "costs": cmd_costs,
    "serve": cmd_serve,
    "height": cmd_height,
    "sync": cmd_sync,
    "bootstrap": cmd_bootstrap,
    "version": cmd_version,
    "update": cmd_update,
    "upgrade": cmd_upgrade,
    "hosts": cmd_hosts,
    "tasks": cmd_tasks,
    "doctor": cmd_doctor,
    "trust-history": cmd_trust_history,
    "trust": cmd_trust_history,  # alias
    # v0.6.6 — provider registry surface
    "providers": cmd_providers,
    # v0.6.10 — workspace manifest + bootstrap
    "workspace": cmd_workspace,
}


def main():
    if len(sys.argv) < 2:
        _preflight("")
        cmd_run([])
        return

    command = sys.argv[1]

    if command in ("-h", "--help", "help"):
        print(__doc__)
        return
    if command in ("--version", "-V"):
        cmd_version()
        return

    _preflight(command)

    if command == "ask":
        question = " ".join(sys.argv[2:])
        if not question:
            print('Usage: nebula ask "your question here"')
            return
        from core.ask import ask

        print(ask(question, db_path=str(DB)))
        return

    if command == "snapshot":
        cmd_snapshot(sys.argv[2:])
        return

    if command == "transport":
        rc = cmd_transport(sys.argv[2:])
        if isinstance(rc, int):
            sys.exit(rc)
        return

    if command == "config":
        rc = cmd_config(sys.argv[2:])
        if isinstance(rc, int):
            sys.exit(rc)
        return

    if command == "rpc":
        from core.nebula_rpc import start_rpc_server

        start_rpc_server(db_path=str(DB))
        return

    if command in COMMANDS:
        rc = COMMANDS[command]()
        if isinstance(rc, int):
            sys.exit(rc)
        return

    if command.startswith("-"):
        cmd_run(sys.argv[1:])
        return

    sys.stderr.write(f"Unknown command: {command}\n")
    sys.stderr.write("Run `./nebula --help` for usage.\n")
    sys.exit(2)


if __name__ == "__main__":
    main()
