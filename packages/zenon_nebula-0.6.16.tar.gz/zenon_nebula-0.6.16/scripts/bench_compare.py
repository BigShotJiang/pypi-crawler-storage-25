#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Perf baseline comparator — task #60.

Runs Nebula's micro-benchmarks and compares each scenario's wall-clock
time against the baseline checked in at ``benchmarks/baselines.json``.

A scenario fails the comparison when ``measured > baseline *
tolerance_factor``. The tolerance factor defaults to 3.0 (generous) so
the gate fires on real regressions, not jitter. Individual scenarios
can override the factor in ``baselines.json``.

By default the script runs in **warn-only** mode: it prints every
scenario's status and exits 0 regardless of regressions. This keeps
the gate from blocking merges while the baseline stabilizes. Pass
``--strict`` to exit non-zero on any regression.

Usage:
    python3 scripts/bench_compare.py                  # warn-only
    python3 scripts/bench_compare.py --strict         # CI gate
    python3 scripts/bench_compare.py --update         # refresh baselines
    python3 scripts/bench_compare.py --json           # machine-readable

The ``--update`` path overwrites the checked-in JSON with the current
measurement; use it only when intentionally accepting a new baseline
(e.g., after an optimization ship, or after upgrading the CI runner
image). Commit the updated file in the same PR as the change that
justifies it.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

REPO_ROOT = Path(__file__).resolve().parents[1]
BASELINES_PATH = REPO_ROOT / "benchmarks" / "baselines.json"

if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

DEFAULT_TOLERANCE_FACTOR = 3.0


def load_baselines(path: Path = BASELINES_PATH) -> dict[str, Any]:
    """Read the checked-in baselines JSON. Skips underscore-prefixed keys."""
    data = json.loads(path.read_text(encoding="utf-8"))
    return {k: v for k, v in data.items() if not k.startswith("_")}


def run_all_benchmarks() -> dict[str, dict[str, float]]:
    """Invoke each bench module's ``run_benchmarks`` and collect results.

    Each module's key is the module's bare name (``bench_persist``,
    ``bench_scheduler``, ...). Scenario names come from the module's
    own return dict.
    """
    # Import lazily so test monkeypatching can intercept.
    from benchmarks import bench_persist, bench_scheduler

    return {
        "bench_persist": bench_persist.run_benchmarks(verbose=False),
        "bench_scheduler": bench_scheduler.run_benchmarks(verbose=False),
    }


def compare(
    measured: dict[str, dict[str, float]],
    baselines: dict[str, Any],
) -> list[dict[str, Any]]:
    """Diff each measurement against its baseline.

    Returns a list of result records, one per (benchmark, scenario),
    each with keys ``benchmark``, ``scenario``, ``measured_seconds``,
    ``baseline_seconds``, ``tolerance_factor``, ``limit_seconds``,
    ``status`` (``ok`` | ``regressed`` | ``missing_baseline``).
    """
    records: list[dict[str, Any]] = []
    for bench_name, scenarios in measured.items():
        bench_baselines = baselines.get(bench_name, {})
        for scenario, seconds in scenarios.items():
            baseline_entry = bench_baselines.get(scenario)
            if baseline_entry is None:
                records.append(
                    {
                        "benchmark": bench_name,
                        "scenario": scenario,
                        "measured_seconds": seconds,
                        "baseline_seconds": None,
                        "tolerance_factor": None,
                        "limit_seconds": None,
                        "status": "missing_baseline",
                    }
                )
                continue
            baseline_seconds = float(baseline_entry["baseline_seconds"])
            tolerance_factor = float(
                baseline_entry.get("tolerance_factor", DEFAULT_TOLERANCE_FACTOR)
            )
            limit_seconds = baseline_seconds * tolerance_factor
            status = "regressed" if seconds > limit_seconds else "ok"
            records.append(
                {
                    "benchmark": bench_name,
                    "scenario": scenario,
                    "measured_seconds": seconds,
                    "baseline_seconds": baseline_seconds,
                    "tolerance_factor": tolerance_factor,
                    "limit_seconds": limit_seconds,
                    "status": status,
                }
            )
    return records


def format_record_line(r: dict[str, Any]) -> str:
    """Render one record as a single human-readable line."""
    if r["status"] == "missing_baseline":
        return (
            f"  [?] {r['benchmark']}::{r['scenario']:<35} "
            f"{r['measured_seconds']:>8.4f} s  (no baseline)"
        )
    mark = "OK " if r["status"] == "ok" else "REG"
    return (
        f"  [{mark}] {r['benchmark']}::{r['scenario']:<35} "
        f"{r['measured_seconds']:>8.4f} s  "
        f"(limit {r['limit_seconds']:.4f}, "
        f"{r['measured_seconds'] / r['baseline_seconds']:.2f}x baseline)"
    )


def update_baselines(
    measured: dict[str, dict[str, float]],
    baselines: dict[str, Any],
    path: Path = BASELINES_PATH,
) -> None:
    """Overwrite baselines.json with the measured times.

    Preserves the ``_comment`` / ``_schema`` header entries and any
    existing ``tolerance_factor`` overrides; only the
    ``baseline_seconds`` values are refreshed.
    """
    existing = json.loads(path.read_text(encoding="utf-8"))
    for bench_name, scenarios in measured.items():
        bench_block = existing.setdefault(bench_name, {})
        for scenario, seconds in scenarios.items():
            entry = bench_block.setdefault(scenario, {})
            entry["baseline_seconds"] = round(seconds, 4)
            entry.setdefault("tolerance_factor", DEFAULT_TOLERANCE_FACTOR)
    _ = baselines  # reserved for future: merge vs. overwrite semantics
    path.write_text(json.dumps(existing, indent=2, sort_keys=False) + "\n", encoding="utf-8")


def main(argv: list[str] | None = None) -> int:
    """CLI entry. Returns exit code (0 ok, 1 regression under --strict)."""
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument(
        "--strict",
        action="store_true",
        help="Exit non-zero on any regression. Default is warn-only.",
    )
    ap.add_argument(
        "--update",
        action="store_true",
        help="Overwrite baselines.json with the current measurements.",
    )
    ap.add_argument(
        "--json",
        action="store_true",
        help="Emit machine-readable JSON instead of human lines.",
    )
    args = ap.parse_args(argv)

    measured = run_all_benchmarks()

    path = BASELINES_PATH

    if args.update:
        baselines = load_baselines(path)
        update_baselines(measured, baselines, path=path)
        try:
            rel = path.relative_to(REPO_ROOT)
        except ValueError:
            rel = path
        print(f"Updated {rel} from current run.")
        return 0

    baselines = load_baselines(path)
    records = compare(measured, baselines)

    if args.json:
        print(json.dumps(records, indent=2))
    else:
        print("\nPerf comparison (scripts/bench_compare.py)")
        print("-" * 70)
        for r in records:
            print(format_record_line(r))
        regressions = [r for r in records if r["status"] == "regressed"]
        missing = [r for r in records if r["status"] == "missing_baseline"]
        if regressions:
            print(f"\n{len(regressions)} regression(s) detected.")
            if not args.strict:
                print("Warn-only mode — exiting 0. Pass --strict to gate on this.")
        if missing:
            print(f"{len(missing)} scenario(s) without baseline — add to baselines.json.")
        if not regressions and not missing:
            print("\nAll scenarios within tolerance.")

    if args.strict and any(r["status"] == "regressed" for r in records):
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
