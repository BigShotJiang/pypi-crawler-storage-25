#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""PR body drafter — task #89 Phase 1.

Scaffold for the autonomous PR drafter (stepping stone toward Phase I
agent swarm, task #68). Phase 1 ships a deterministic string-only
drafter: read a git diff range + commit messages, extract task IDs,
count files/lines, emit a PR body in the repo's established template.

No LLM calls, no network calls — pure git + stdlib. Operators can
pipe the output into ``gh pr create --body-file -`` or paste it.

Phase 2 (task #68 territory) will add an LLM polish pass that
tightens wording + fills the Summary bullets from commit bodies.
This Phase 1 gives the LLM pass a clean scaffold to polish, not a
blank page.

Usage:
    python3 scripts/draft_pr.py                 # main...HEAD
    python3 scripts/draft_pr.py --base v0.6.10  # v0.6.10...HEAD
    python3 scripts/draft_pr.py --tier 2        # force tier classification
    python3 scripts/draft_pr.py --title "feat[x]: ..."
"""

from __future__ import annotations

import argparse
import re
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

# Pattern for task ID mentions. Matches "#N" and "task #N" forms.
# Word boundary prefix prevents false matches inside other numbers.
TASK_ID_RE = re.compile(r"\btask\s+#(\d+)|#(\d+)\b", re.IGNORECASE)

# Files whose touching bumps the suggested tier. Mirrors
# .claude/rules/branching.md Tier 2 list.
TIER2_TOUCHING = (
    "core/persistence/findings.py",
    "core/transport.py",
    "core/trust.py",
    ".github/workflows/release.yml",
    "pyproject.toml",
)


@dataclass
class DiffSummary:
    """Everything the drafter extracts from git."""

    base: str
    head: str
    files_changed: list[str] = field(default_factory=list)
    additions: int = 0
    deletions: int = 0
    commits: list[tuple[str, str]] = field(default_factory=list)  # (sha, subject)
    commit_bodies: list[str] = field(default_factory=list)
    task_ids: set[int] = field(default_factory=set)


def _run_git(*args: str) -> str:
    """Run git with a bounded timeout; return stripped stdout or ''."""
    try:
        proc = subprocess.run(
            ["git", *args],
            cwd=str(ROOT),
            capture_output=True,
            text=True,
            timeout=15,
            check=False,
        )
    except (subprocess.SubprocessError, OSError):
        return ""
    return (proc.stdout or "").strip()


def collect_diff_summary(base: str, head: str = "HEAD") -> DiffSummary:
    """Gather commit log + diffstat for ``base..head``.

    Returns a ``DiffSummary`` dataclass — callers format it. Pure
    read; never modifies the repo.
    """
    summary = DiffSummary(base=base, head=head)
    range_spec = f"{base}..{head}"

    # Changed files.
    files_out = _run_git("diff", "--name-only", range_spec)
    summary.files_changed = [line for line in files_out.splitlines() if line]

    # Additions / deletions.
    stat_out = _run_git("diff", "--shortstat", range_spec)
    m_add = re.search(r"(\d+) insertion", stat_out)
    m_del = re.search(r"(\d+) deletion", stat_out)
    if m_add:
        summary.additions = int(m_add.group(1))
    if m_del:
        summary.deletions = int(m_del.group(1))

    # Commit list (subject line only).
    log_out = _run_git("log", "--format=%h|%s", range_spec)
    for line in log_out.splitlines():
        sha, _, subj = line.partition("|")
        if sha and subj:
            summary.commits.append((sha.strip(), subj.strip()))

    # Commit bodies (for task-ID extraction).
    bodies_out = _run_git("log", "--format=%B%n---COMMIT-END---", range_spec)
    for chunk in bodies_out.split("---COMMIT-END---"):
        body = chunk.strip()
        if body:
            summary.commit_bodies.append(body)

    # Task IDs — pulled from every commit subject + body.
    for text in list(summary.commit_bodies) + [subj for _, subj in summary.commits]:
        for m in TASK_ID_RE.finditer(text):
            # One of the two capture groups will be set.
            n = m.group(1) or m.group(2)
            if n:
                summary.task_ids.add(int(n))

    return summary


def classify_tier(summary: DiffSummary) -> int:
    """Heuristic Tier classification from the diff summary.

    Not authoritative — `/tier-check` is the canonical rule.
    Operator can override with `--tier N`.

    Rules (lifted from .claude/rules/branching.md):
      * 0 files changed → Tier 0 (nothing to ship).
      * Any Tier 2 file touched → Tier 2.
      * More than 5 files changed → Tier 2.
      * Touches `.github/workflows/release.yml` → always Tier 2.
      * Otherwise Tier 1.
    """
    if not summary.files_changed:
        return 0
    for path in summary.files_changed:
        if any(t in path for t in TIER2_TOUCHING):
            return 2
    if len(summary.files_changed) > 5:
        return 2
    return 1


def render_pr_body(summary: DiffSummary, *, tier: int, title: str | None = None) -> str:
    """Render the PR body template operators paste into ``gh pr create``."""
    lines: list[str] = []
    if title:
        lines.append(f"# {title}")
        lines.append("")

    # Summary: first 5 commit subjects (or all if fewer).
    lines.append("## Summary")
    lines.append("")
    if summary.commits:
        for _sha, subj in summary.commits[:5]:
            lines.append(f"- {subj}")
        if len(summary.commits) > 5:
            lines.append(f"- ... and {len(summary.commits) - 5} more commit(s)")
    else:
        lines.append("- (no commits in range)")
    lines.append("")

    # Diff stat.
    lines.append(
        f"**Scope:** {len(summary.files_changed)} file(s), "
        f"+{summary.additions} / -{summary.deletions} lines."
    )
    lines.append("")

    # Task linkage.
    if summary.task_ids:
        task_list = ", ".join(f"#{n}" for n in sorted(summary.task_ids))
        lines.append(f"**Tasks referenced:** {task_list}")
        lines.append("")

    # Test plan (standard template).
    lines.append("## Test plan")
    lines.append("")
    lines.append("- [ ] Full suite: `python3 -m pytest tests/ -q --timeout=60`")
    lines.append("- [ ] Architecture: `python3 scripts/audit_architecture.py`")
    lines.append("- [ ] Dep graph: `python3 scripts/generate_dep_graph.py --check`")
    lines.append("- [ ] Docs regen: `python3 scripts/regen_docs.py --check`")
    lines.append("- [ ] Ruff: `python3 -m ruff check core/ domains/ scripts/ tests/`")
    lines.append("")

    # Attack-vector audit (placeholder — operator fills from the 12-item
    # checklist in .claude/rules/attack-vector-audit.md).
    lines.append("## Attack-vector audit")
    lines.append("")
    lines.append(
        "_Walk the 12-item checklist in `.claude/rules/attack-vector-audit.md`. "
        "Remove this section if no items match._"
    )
    lines.append("")

    # Tier classification.
    lines.append("## Tier")
    lines.append("")
    tier_desc = {
        0: "Tier 0 (typo / regen-only / comment fix — direct to main allowed)",
        1: "Tier 1 (new code + tests — PR + CI green → self-merge)",
        2: "Tier 2 (schema / transport / release.yml / security-sensitive — PR + 1h soak)",
        3: "Tier 3 (release tag — only via `scripts/release.py ship`)",
    }.get(tier, f"Tier {tier}")
    lines.append(tier_desc)
    lines.append("")
    lines.append(
        "_Drafted by `scripts/draft_pr.py` (task #89 Phase 1). "
        "Operator should review every section before submitting._"
    )
    return "\n".join(lines)


_POLISH_SYSTEM_PROMPT = """You polish draft GitHub PR bodies for the Nebula project.

Rules:
- Preserve EVERY section and bullet from the draft. Never drop content.
- Tighten wording. Remove redundancy. Make sentences direct.
- Keep markdown structure (##, bullets, code fences) exactly as given.
- NEVER invent facts not present in the commit text. No made-up test
  counts, no made-up task references, no made-up files.
- If the draft has a placeholder like "Walk the 12-item checklist",
  leave it as a placeholder — you are not a substitute for the
  operator's judgment.
- Output pure markdown. No preamble, no "Here's the polished version:".

Input format: a draft markdown PR body.
Output format: the polished markdown PR body."""


def llm_polish(draft: str, *, budget_usd: float = 0.05) -> tuple[str, dict | None]:
    """Return (polished_body, cost_metadata).

    Best-effort LLM pass via ``core.llm_provider.call_llm``. Returns
    the ORIGINAL draft unchanged on any failure (network down, no
    API key, LLM returns None, response empty, or header dropped) so
    the caller always has a usable result. The cost metadata dict is
    passed through for operator visibility; ``None`` when the LLM
    call wasn't attempted or degraded.

    Safety invariant: every `##` section header present in the draft
    must survive in the polish. An LLM that dropped a section counts
    as corruption, not polish.
    """
    try:
        from core.llm_provider import call_llm
    except Exception:
        return draft, None

    try:
        result = call_llm(
            prompt=draft,
            system=_POLISH_SYSTEM_PROMPT,
            model="auto",
            max_tokens=4000,
            temperature=0.3,
            cache_ttl_seconds=0,
        )
    except Exception:
        return draft, None

    if result is None:
        return draft, None

    polished = result.get("text", "").strip()
    if not polished:
        return draft, None

    # Refuse a polish that lost content catastrophically. Cheap guard:
    # preserve EVERY existing `##` header verbatim.
    for line in draft.splitlines():
        if line.startswith("## ") and line not in polished:
            return draft, None

    if result.get("cost_usd", 0.0) > budget_usd:
        # Budget breach → treat as success but flag it so the
        # operator sees they exceeded the cap.
        return polished, {**result, "budget_exceeded": True}

    return polished, result


def main() -> int:
    """Entry point."""
    parser = argparse.ArgumentParser(
        description="Draft a PR body from a git diff range.",
    )
    parser.add_argument(
        "--base",
        default="main",
        help="Base ref to diff against (default: main).",
    )
    parser.add_argument(
        "--head",
        default="HEAD",
        help="Head ref (default: HEAD).",
    )
    parser.add_argument(
        "--tier",
        type=int,
        choices=[0, 1, 2, 3],
        help="Override the heuristic tier classification.",
    )
    parser.add_argument(
        "--title",
        help="Optional PR title to include as the top-level heading.",
    )
    parser.add_argument(
        "--polish",
        action="store_true",
        help=(
            "Apply an LLM polish pass via core.llm_provider.call_llm. "
            "Preserves every section; tightens wording. Requires "
            "XAI_API_KEY; falls back to the unpolished draft on any "
            "failure."
        ),
    )
    parser.add_argument(
        "--polish-budget",
        type=float,
        default=0.05,
        help="USD budget cap for the polish pass (default: 0.05).",
    )
    args = parser.parse_args()

    summary = collect_diff_summary(args.base, args.head)
    if not summary.commits and not summary.files_changed:
        print(
            f"draft_pr: no commits or file changes in range {args.base}..{args.head}",
            file=sys.stderr,
        )
        return 2

    tier = args.tier if args.tier is not None else classify_tier(summary)
    body = render_pr_body(summary, tier=tier, title=args.title)

    if args.polish:
        polished, meta = llm_polish(body, budget_usd=args.polish_budget)
        if polished != body:
            body = polished
            if meta and meta.get("cost_usd"):
                print(
                    f"draft_pr: polished (cost=${meta['cost_usd']:.4f}"
                    f" model={meta.get('model', 'unknown')})",
                    file=sys.stderr,
                )
        else:
            print(
                "draft_pr: polish pass unavailable or declined; emitting unpolished draft.",
                file=sys.stderr,
            )

    print(body)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
