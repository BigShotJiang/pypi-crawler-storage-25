#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Custom git merge driver for CHANGELOG.md — stacks both sides' entries.

Every rebase of a feature branch produces the same CHANGELOG.md conflict:
two branches each added entries to the `## [Unreleased]` section, and
the default three-way merge calls it a conflict because both sides
touched adjacent lines. The one correct resolution is always "keep both
sides' entries stacked" — never pick, never discard.

This script implements that resolution as a git merge driver. Register
once per clone via `scripts/setup_merge_drivers.sh`, then every
CHANGELOG.md conflict auto-resolves instead of interrupting the rebase.

Invocation (git contract):
    python3 scripts/merge_changelog.py %O %A %B %P

Where:
    %O — path to the common ancestor ("base") version
    %A — path to the "ours" version (HEAD at merge time); also output
    %B — path to the "theirs" version (incoming branch)
    %P — the logical file name (for diagnostics)

Exit code: 0 on clean auto-merge, 1 if the conflict isn't the
expected Unreleased-section shape (git falls back to default markers
so the operator sees it).

Strategy:

1. Parse all three versions into (pre, unreleased_entries, post) where
   `unreleased_entries` is the list of bullet items inside the
   `## [Unreleased]` section, grouped by subheading (`### Added`,
   `### Fixed`, etc).
2. For each subheading, compute `ours + theirs` minus base entries that
   both sides dropped. Order: ours first, then theirs' new entries in
   order. Dedup by content hash (identical bullets collapse).
3. Outside the Unreleased section, fall back to git's default merge —
   which means if ours/theirs also disagree on older sections (rare),
   we emit conflict markers there and exit 1.

Behavior on unexpected shapes:

- No `[Unreleased]` in any version: fall back to default merge.
- Subheadings present in only one side: include them as-is.
- Non-bullet content (prose paragraphs) under `[Unreleased]`: preserved
  using "ours" as the base and appending new paragraphs from theirs.
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

UNRELEASED_RE = re.compile(r"^##\s*\[Unreleased\]\s*$", re.IGNORECASE)
NEXT_SECTION_RE = re.compile(r"^##\s+\[")
SUBHEADING_RE = re.compile(r"^###\s+(.+?)\s*$")
BULLET_START_RE = re.compile(r"^- ")


def _split(text: str) -> tuple[str, dict[str, list[str]], str]:
    """Split a CHANGELOG into (prefix, unreleased_by_subheading, suffix).

    Returns:
        pre:     everything before `## [Unreleased]` line (inclusive)
        entries: {subheading -> list of entry blocks}
                 where each entry block is the full text of one bullet
                 (starts with "- ", may span multiple lines via
                 continuation indentation)
        post:    everything from the next `## [X.Y.Z]` onward
    """
    lines = text.splitlines(keepends=True)
    pre_end = None
    for i, line in enumerate(lines):
        if UNRELEASED_RE.match(line):
            pre_end = i
            break
    if pre_end is None:
        return text, {}, ""

    # Find the end of the Unreleased section
    post_start = len(lines)
    for j in range(pre_end + 1, len(lines)):
        if NEXT_SECTION_RE.match(lines[j]):
            post_start = j
            break

    pre = "".join(lines[: pre_end + 1])
    body = lines[pre_end + 1 : post_start]
    post = "".join(lines[post_start:])

    # Parse body into subheadings -> entries
    entries: dict[str, list[str]] = {}
    current_sub = "__header__"  # text before the first ### subheading
    entries[current_sub] = []
    current_block: list[str] = []

    def flush_block() -> None:
        nonlocal current_block
        if current_block:
            joined = "".join(current_block)
            if joined.strip():  # skip whitespace-only blocks
                entries.setdefault(current_sub, []).append(joined)
            current_block = []

    for line in body:
        if SUBHEADING_RE.match(line):
            flush_block()
            current_sub = SUBHEADING_RE.match(line).group(1).strip()
            entries.setdefault(current_sub, [])
        elif BULLET_START_RE.match(line):
            flush_block()
            current_block = [line]
        else:
            # Continuation of the current block, blank line, or header text
            if current_block:
                current_block.append(line)
            elif current_sub == "__header__":
                entries[current_sub].append(line)
    flush_block()

    return pre, entries, post


def _merge_entries(
    base: dict[str, list[str]],
    ours: dict[str, list[str]],
    theirs: dict[str, list[str]],
) -> dict[str, list[str]]:
    """Merge three entry maps. Preserves order: ours first, then new-to-theirs."""
    out: dict[str, list[str]] = {}
    # Every subheading seen in any of the three inputs
    all_subs: list[str] = []
    for d in (ours, theirs, base):
        for k in d:
            if k not in all_subs:
                all_subs.append(k)

    for sub in all_subs:
        base_entries = [e.strip() for e in base.get(sub, [])]
        ours_entries = ours.get(sub, [])
        theirs_entries = theirs.get(sub, [])

        seen_content: set[str] = set()
        merged: list[str] = []

        # Take everything from "ours" first (preserves branch author's order)
        for entry in ours_entries:
            key = entry.strip()
            if key and key not in seen_content:
                merged.append(entry)
                seen_content.add(key)

        # Then take entries from "theirs" that aren't in ours AND weren't
        # simply dropped (base had them, theirs kept them, ours removed).
        # Simpler: anything in theirs not already in merged gets appended.
        for entry in theirs_entries:
            key = entry.strip()
            if key and key not in seen_content:
                # Skip entries that existed in base but not in ours
                # (ours intentionally deleted them).
                if key in base_entries and key not in seen_content:
                    continue
                merged.append(entry)
                seen_content.add(key)

        out[sub] = merged
    return out


def _emit(
    pre: str,
    entries: dict[str, list[str]],
    post: str,
) -> str:
    """Render the final CHANGELOG text."""
    out = [pre]
    header = "".join(entries.get("__header__", []))
    if header:
        if not header.endswith("\n"):
            header += "\n"
        out.append(header)
    # Emit subheadings in a stable preferred order, then any custom ones
    preferred = ["Added", "Changed", "Fixed", "Deprecated", "Removed", "Security"]
    subs_order: list[str] = []
    for p in preferred:
        if p in entries and p != "__header__":
            subs_order.append(p)
    for s in entries:
        if s != "__header__" and s not in subs_order:
            subs_order.append(s)

    for sub in subs_order:
        bullets = entries[sub]
        if not bullets:
            continue
        # Ensure one blank line before each ###
        if out and not out[-1].endswith("\n\n"):
            if out[-1].endswith("\n"):
                out.append("\n")
            else:
                out.append("\n\n")
        out.append(f"### {sub}\n\n")
        for i, b in enumerate(bullets):
            entry_text = b if b.endswith("\n") else b + "\n"
            out.append(entry_text)
            if i < len(bullets) - 1 and not entry_text.endswith("\n\n"):
                out.append("\n")
    # Separator before the post (next version section)
    if post:
        if out and not out[-1].endswith("\n\n"):
            if out[-1].endswith("\n"):
                out.append("\n")
            else:
                out.append("\n\n")
        out.append(post)
    return "".join(out)


def main(argv: list[str]) -> int:
    if len(argv) < 4:
        print("usage: merge_changelog.py BASE OURS THEIRS [NAME]", file=sys.stderr)
        return 2

    base_path = Path(argv[1])
    ours_path = Path(argv[2])
    theirs_path = Path(argv[3])

    try:
        base = base_path.read_text(encoding="utf-8")
        ours = ours_path.read_text(encoding="utf-8")
        theirs = theirs_path.read_text(encoding="utf-8")
    except OSError as exc:
        print(f"merge_changelog: read failed: {exc}", file=sys.stderr)
        return 1

    pre_ours, entries_ours, post_ours = _split(ours)
    pre_theirs, entries_theirs, post_theirs = _split(theirs)
    _, entries_base, _ = _split(base)

    # Only auto-merge when both sides have a recognizable [Unreleased]
    # section. Otherwise let git emit standard conflict markers.
    if not entries_ours or not entries_theirs:
        return 1

    merged_entries = _merge_entries(entries_base, entries_ours, entries_theirs)

    # For the pre/post sections, prefer ours when they differ. If post
    # differs (someone stamped a new release section on one side but
    # not the other), the bigger one wins — we don't want to drop a
    # version heading.
    pre = pre_ours if len(pre_ours) >= len(pre_theirs) else pre_theirs
    post = post_ours if len(post_ours) >= len(post_theirs) else post_theirs

    merged_text = _emit(pre, merged_entries, post)

    # Write back to OURS (per git merge-driver contract)
    try:
        ours_path.write_text(merged_text, encoding="utf-8")
    except OSError as exc:
        print(f"merge_changelog: write failed: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
