#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""CGC dead-code audit wrapper.

Re-runs CodeGraphContext's ``find_dead_code`` scan against the
Nebula repo and diffs the result against ``data/cgc-ignore.yaml``.

Exit codes:
    0 — Clean. Every flagged function is allowlisted.
    1 — Drift. At least one flag is not on the allowlist. Operator
        must either allowlist it or delete the function.
    2 — Environment error. CGC is not installed or the scan failed.

Usage::

    python3 scripts/cgc_audit.py             # full audit
    python3 scripts/cgc_audit.py --json      # machine-readable
    python3 scripts/cgc_audit.py --strict    # also flag stale entries
                                             # (reviewed >365 days ago)

This tool is deliberately stdlib-only so it runs in CI without
pulling in the full CGC installation. It shells out to ``cgc`` if
available, but also supports reading a pre-generated scan from
``--from-file <path>`` for reproducibility.
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from dataclasses import dataclass, field
from datetime import date, datetime, timezone
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_ALLOWLIST = REPO_ROOT / "data" / "cgc-ignore.yaml"
STALENESS_DAYS = 365

VALID_CATEGORIES = frozenset(
    {
        "dispatch_table",
        "property",
        "library_template",
        "conditional_integration",
        "reexport_shim",
        "public_api",
    }
)


@dataclass
class AllowlistEntry:
    """One entry from ``data/cgc-ignore.yaml``.

    Fields mirror the YAML schema. ``function`` is the dotted path
    (e.g., ``core.hypotheses.engine._pattern_upstream_breaking``).
    """

    function: str
    category: str
    reason: str
    last_reviewed: str

    @property
    def reviewed_date(self) -> date | None:
        """Parse ``last_reviewed`` as a date, or ``None`` on bad input."""
        try:
            return date.fromisoformat(self.last_reviewed)
        except (TypeError, ValueError):
            return None

    def is_stale(self, *, cutoff_days: int = STALENESS_DAYS) -> bool:
        """True when the entry hasn't been reviewed in cutoff_days."""
        reviewed = self.reviewed_date
        if reviewed is None:
            return True
        today = datetime.now(timezone.utc).date()
        return (today - reviewed).days > cutoff_days


@dataclass
class Allowlist:
    """Parsed ``data/cgc-ignore.yaml``."""

    version: int
    updated: str
    entries: list[AllowlistEntry] = field(default_factory=list)

    def functions(self) -> set[str]:
        """Return the set of allowlisted function dotted paths."""
        return {e.function for e in self.entries}

    def by_function(self, function: str) -> AllowlistEntry | None:
        """Return the entry for a given dotted path, or None."""
        for entry in self.entries:
            if entry.function == function:
                return entry
        return None

    def stale_entries(self, *, cutoff_days: int = STALENESS_DAYS) -> list[AllowlistEntry]:
        """Return entries whose last_reviewed is older than cutoff_days."""
        return [e for e in self.entries if e.is_stale(cutoff_days=cutoff_days)]


def load_allowlist(path: Path = DEFAULT_ALLOWLIST) -> Allowlist:
    """Load the allowlist from ``data/cgc-ignore.yaml``.

    Uses PyYAML if available, stdlib fallback parser otherwise. The
    file ships empty by default — an empty allowlist is valid.
    """
    if not path.exists():
        return Allowlist(version=1, updated="", entries=[])

    text = path.read_text(encoding="utf-8")
    data = _parse_yaml(text)
    if data is None:
        return Allowlist(version=1, updated="", entries=[])

    entries = []
    for raw in data.get("entries") or []:
        category = str(raw.get("category", ""))
        if category and category not in VALID_CATEGORIES:
            print(
                f"WARN: allowlist entry {raw.get('function')!r} uses unknown category {category!r}",
                file=sys.stderr,
            )
        entries.append(
            AllowlistEntry(
                function=str(raw.get("function", "")),
                category=category,
                reason=str(raw.get("reason", "")),
                last_reviewed=str(raw.get("last_reviewed", "")),
            )
        )
    return Allowlist(
        version=int(data.get("version", 1)),
        updated=str(data.get("updated", "")),
        entries=entries,
    )


def _parse_yaml(text: str) -> dict | None:
    """Parse YAML, preferring PyYAML, falling back to stdlib subset."""
    try:
        import yaml  # type: ignore[import-untyped]

        return yaml.safe_load(text)
    except ImportError:
        return _stdlib_yaml_parse(text)


def _stdlib_yaml_parse(text: str) -> dict | None:
    """Minimal YAML parser for the cgc-ignore.yaml shape.

    Handles top-level scalars, an ``entries:`` list of dicts, and
    empty-list (``entries: []``). Not a general YAML parser.
    """
    result: dict = {}
    current_list: list | None = None
    current_item: dict | None = None
    list_key: str | None = None

    for raw_line in text.splitlines():
        line = raw_line.rstrip()
        if not line or line.lstrip().startswith("#"):
            continue
        stripped = line.lstrip()
        indent = len(line) - len(stripped)

        if stripped.startswith("- ") and indent == 2:
            if current_item is not None and current_list is not None:
                current_list.append(current_item)
            current_item = {}
            after_dash = stripped[2:]
            if ":" in after_dash:
                key, _, value = after_dash.partition(":")
                current_item[key.strip()] = _coerce_scalar(value.strip())
            continue

        if current_item is not None and indent == 4 and ":" in stripped:
            key, _, value = stripped.partition(":")
            current_item[key.strip()] = _coerce_scalar(value.strip())
            continue

        if indent == 0 and ":" in stripped:
            key, _, value = stripped.partition(":")
            value = value.strip()
            key = key.strip()
            if value == "[]":
                if current_item is not None and current_list is not None:
                    current_list.append(current_item)
                    current_item = None
                current_list = []
                list_key = key
                result[list_key] = current_list
                current_list = None
            elif value:
                result[key] = _coerce_scalar(value)
            else:
                if current_item is not None and current_list is not None:
                    current_list.append(current_item)
                    current_item = None
                current_list = []
                list_key = key
                result[list_key] = current_list
            continue

    if current_item is not None and current_list is not None:
        current_list.append(current_item)

    return result


def _coerce_scalar(value: str):
    """Convert a YAML scalar string to a Python value."""
    if value in ("null", "~", ""):
        return None
    if value in ("true", "True"):
        return True
    if value in ("false", "False"):
        return False
    if value.startswith('"') and value.endswith('"'):
        return value[1:-1]
    if value.startswith("'") and value.endswith("'"):
        return value[1:-1]
    try:
        return int(value)
    except ValueError:
        pass
    return value


def run_cgc_scan(*, from_file: Path | None = None) -> list[dict]:
    """Run ``cgc find_dead_code`` and return the list of findings.

    Each finding is a dict with keys ``function_name``, ``path``,
    ``line_number``. If ``from_file`` is supplied, the scan is read
    from JSON on disk instead — useful for reproducibility tests.

    Returns an empty list when CGC reports no dead code. Raises
    ``RuntimeError`` when CGC isn't installed or the subprocess fails.
    """
    if from_file is not None:
        text = from_file.read_text(encoding="utf-8")
        return json.loads(text)

    # Query CGC via its CLI. The MCP tool isn't callable from a
    # non-MCP context, so we use `cgc` CLI. Note: as of v0.4.2
    # the CLI does not expose find_dead_code directly; callers
    # using the MCP are expected to pipe the JSON result through
    # --from-file. Surface that shape explicitly.
    try:
        result = subprocess.run(
            ["cgc", "list"],
            timeout=30,
            capture_output=True,
            text=True,
            check=False,
        )
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError) as exc:
        raise RuntimeError(f"cgc CLI not available: {exc}") from exc

    if result.returncode != 0:
        raise RuntimeError(f"cgc list exited {result.returncode}: {result.stderr.strip()}")

    # The CLI path today only confirms indexing. For true dead-code
    # scans, callers supply --from-file with a saved MCP response.
    return []


def dotted_path_for(finding: dict) -> str:
    """Convert a CGC finding to the dotted-path we store in allowlist.

    Input shape::

        {
            "function_name": "_pattern_upstream_breaking",
            "path": ".../core/hypotheses/engine.py",
            ...
        }

    Output: ``core.hypotheses.engine._pattern_upstream_breaking``.
    """
    fn_name = finding.get("function_name", "")
    path = finding.get("path", "")
    if not fn_name or not path:
        return fn_name
    # Strip REPO_ROOT prefix and .py suffix; convert / to .
    try:
        rel = Path(path).resolve().relative_to(REPO_ROOT)
    except (ValueError, OSError):
        rel = Path(path)
    parts = list(rel.parts)
    if parts and parts[-1].endswith(".py"):
        parts[-1] = parts[-1][:-3]
    return ".".join([*parts, fn_name])


def audit(
    *,
    allowlist: Allowlist,
    findings: list[dict],
    strict: bool = False,
) -> tuple[int, dict]:
    """Diff CGC findings against the allowlist.

    Returns ``(exit_code, report)``. ``report`` is a dict suitable
    for JSON output; it lists ``drift`` (flagged, not allowlisted)
    and ``stale`` (allowlisted, not reviewed in 365 days).
    """
    allowed = allowlist.functions()
    flagged = {dotted_path_for(f): f for f in findings}
    drift_names = sorted(set(flagged.keys()) - allowed)
    stale = [e.function for e in allowlist.stale_entries()]

    exit_code = 0
    if drift_names:
        exit_code = 1
    if strict and stale:
        exit_code = 1

    return exit_code, {
        "drift": drift_names,
        "drift_detail": [flagged[name] for name in drift_names],
        "stale": stale,
        "allowlist_size": len(allowlist.entries),
        "findings_total": len(findings),
    }


def main() -> int:
    """Run the audit. Returns a UNIX exit code."""
    parser = argparse.ArgumentParser(description="CGC dead-code audit wrapper")
    parser.add_argument(
        "--allowlist",
        type=Path,
        default=DEFAULT_ALLOWLIST,
        help="Path to cgc-ignore.yaml (default: data/cgc-ignore.yaml)",
    )
    parser.add_argument(
        "--from-file",
        type=Path,
        default=None,
        help="Read CGC findings from JSON instead of querying CGC",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Emit machine-readable JSON instead of text",
    )
    parser.add_argument(
        "--strict",
        action="store_true",
        help="Also flag allowlist entries not reviewed in 365 days",
    )
    args = parser.parse_args()

    allowlist = load_allowlist(args.allowlist)

    try:
        findings = run_cgc_scan(from_file=args.from_file)
    except RuntimeError as exc:
        if args.from_file is None:
            print(
                f"CGC scan failed: {exc}\nHint: pass --from-file <path> with a saved MCP response",
                file=sys.stderr,
            )
            return 2
        raise

    exit_code, report = audit(allowlist=allowlist, findings=findings, strict=args.strict)

    if args.json:
        print(json.dumps(report, indent=2, sort_keys=True))
    else:
        _print_text_report(report, exit_code, strict=args.strict)

    return exit_code


def _print_text_report(report: dict, exit_code: int, *, strict: bool) -> None:
    """Human-readable audit report."""
    print(
        f"CGC audit — {report['findings_total']} findings, {report['allowlist_size']} allowlisted"
    )
    if report["drift"]:
        print(f"\nDRIFT ({len(report['drift'])} unrecognized findings):")
        for name in report["drift"]:
            print(f"  - {name}")
        print(
            "\nEach drift entry is either a regression (fix the code "
            "or delete the function) OR an intentional new addition "
            "(add it to data/cgc-ignore.yaml with a category + reason)."
        )
    if strict and report["stale"]:
        print(f"\nSTALE ({len(report['stale'])} allowlist entries over 365 days old):")
        for name in report["stale"]:
            print(f"  - {name}")
        print("\nRe-verify each entry and bump `last_reviewed` to today.")
    if exit_code == 0:
        print("\nClean.")


if __name__ == "__main__":
    raise SystemExit(main())
