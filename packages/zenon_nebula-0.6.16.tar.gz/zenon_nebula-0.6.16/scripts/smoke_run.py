#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Gate A — PR-time runtime smoke test (task #100).

Closes the gap between today's CI (pytest + scenarios pass) and a
real-runtime verification that ``./nebula --cycles 1`` actually
survives end-to-end. The cooldown LIKE-pattern bugs caught in
v0.6.x (``api_awareness``, ``llm_cost_optimizer``,
``llm_model_watcher``) are the reference class: unit + scenario tests
passed; the live run would have flagged them in 60 seconds.

What this script does:

1. Create a throwaway tmp dir and ``data/`` subdir so the smoke run
   doesn't touch the operator's real evidence store.
2. Spawn ``./nebula --cycles 1 --budget 0.01 --db <tmp>/engine.db``
   as a subprocess with ``XAI_API_KEY`` unset and
   ``NEBULA_DATA_DIR=<tmp>`` set. Unset ``XAI_API_KEY`` so LLM-backed
   engines degrade gracefully; the goal is to prove the scheduler +
   persistence + bootstrap paths work, not to exercise Grok.
3. Assert the subprocess exits 0 within ``SMOKE_TIMEOUT`` seconds.
4. Assert the tmp DB has at least one row in ``actions_log`` — proof
   that the cycle actually ran something, not just passed argparse
   and exited.
5. Assert no ``CRITICAL`` log lines in the captured stderr. ``WARN``
   and ``ERROR`` are allowed (engines log them liberally during
   graceful degradation); ``CRITICAL`` means an unrecoverable state.
6. Clean up the tmp dir on both success and failure.

Exit codes:
    0    smoke run passed all assertions.
    1    assertion failed (process exit, DB contents, or CRITICAL
         logs). Stderr tail + assertion details printed to stdout.
    2    bad usage or environment (Python version, missing files).

Usage:
    python3 scripts/smoke_run.py              # standard smoke
    python3 scripts/smoke_run.py --verbose    # keep tmp dir for inspection

Foundation for Gate B (``scripts/soak_run.py``, task #101) which will
be wired into ``scripts/release.py`` as a pre-tag gate with real LLM
budget. This gate is cheap enough to run on every PR; Gate B is too
expensive for per-PR.
"""

from __future__ import annotations

import argparse
import os
import shutil
import sqlite3
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

# Timeout is a wall-clock budget for ONE Nebula cycle with the
# smoke-scoped domain set. Empirically, self_maintenance + quality
# alone complete in ~20s; we budget 120s to absorb CI jitter + cold
# Python startup. If the smoke run consistently bumps this wall, the
# scope is wrong, not the timeout.
SMOKE_TIMEOUT_SECONDS = 120
SMOKE_BUDGET_USD = 0.01
# Scope the cycle to lightweight self-audit domains. These engines
# don't walk the full 160-repo workspace, so the smoke run stays
# deterministic regardless of what's cloned on the CI runner.
SMOKE_DOMAINS = "self_maintenance,quality"


def _run_nebula_cycle(tmp_data_dir: Path, *, verbose: bool = False) -> subprocess.CompletedProcess:
    """Spawn `./nebula --cycles 1` against the sandbox tmp dir.

    Returns the completed process. Never raises on non-zero exit —
    the caller assembles the assertion failure message.
    """
    db_path = tmp_data_dir / "engine.db"
    cli = ROOT / "scripts" / "nebula_cli.py"
    cmd = [
        sys.executable,
        str(cli),
        "--cycles",
        "1",
        "--budget",
        str(SMOKE_BUDGET_USD),
        "--db",
        str(db_path),
        "--domains",
        SMOKE_DOMAINS,
    ]
    env = dict(os.environ)
    # Force the sandbox so any subprocess spawned by the runner
    # (autonomous.py re-imports core.persistence via execvp) also
    # points at the tmp DB.
    env["NEBULA_DATA_DIR"] = str(tmp_data_dir)
    # Unset the LLM key so engines degrade gracefully and the run
    # doesn't burn real Grok budget. `CYCLE` still exercises the
    # scheduler, persistence, and domain dispatch.
    env.pop("XAI_API_KEY", None)
    # Skip the war-room LLM synthesis; pure-Python path is what
    # we're testing here.
    env["NEBULA_SKIP_WAR_ROOM"] = "1"

    if verbose:
        print(f"  CMD: {' '.join(cmd)}", flush=True)
        print(f"  DB:  {db_path}", flush=True)

    try:
        return subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=SMOKE_TIMEOUT_SECONDS,
            check=False,
            cwd=str(ROOT),
            env=env,
        )
    except subprocess.TimeoutExpired as exc:
        # Wrap as a CompletedProcess-like shape for the caller.
        class _TimedOut:
            returncode = 124
            stdout = (
                (exc.stdout or "").decode() if isinstance(exc.stdout, bytes) else (exc.stdout or "")
            )
            stderr = (
                (exc.stderr or "").decode() if isinstance(exc.stderr, bytes) else (exc.stderr or "")
            )
            stderr += f"\n[smoke_run] timeout after {SMOKE_TIMEOUT_SECONDS}s"

        return _TimedOut()  # type: ignore[return-value]


def _assert_db_has_activity(db_path: Path) -> tuple[bool, str]:
    """Return (passed, message). Checks the smoke run actually ran something.

    ``actions_log`` is the canonical audit table; every autonomous
    cycle writes a ``start`` action at minimum, so a cycle that
    completed normally must have at least one row here.
    """
    if not db_path.is_file():
        return False, f"DB not created at {db_path}"
    try:
        conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
    except sqlite3.OperationalError as exc:
        return False, f"DB unreadable: {exc}"
    try:
        try:
            count = conn.execute("SELECT COUNT(*) FROM actions_log").fetchone()[0]
        except sqlite3.OperationalError as exc:
            return False, f"actions_log missing or unreadable: {exc}"
    finally:
        conn.close()
    if count < 1:
        return False, f"actions_log is empty (expected ≥1 row, got {count})"
    return True, f"actions_log has {count} row(s)"


def _assert_no_critical_logs(stderr: str) -> tuple[bool, str]:
    """Return (passed, message). Fails on CRITICAL log lines."""
    lines = [ln for ln in stderr.splitlines() if "[CRITICAL]" in ln or "CRITICAL -" in ln]
    if lines:
        # Keep only the first 3 for the message so we don't blast
        # pages of context at the operator.
        head = "\n    ".join(lines[:3])
        more = f" (+{len(lines) - 3} more)" if len(lines) > 3 else ""
        return False, f"found {len(lines)} CRITICAL log line(s){more}:\n    {head}"
    return True, "no CRITICAL logs"


def main() -> int:
    """Run Gate A. Exit 0 on success, 1 on assertion failure, 2 on bad env."""
    parser = argparse.ArgumentParser(description="Gate A — runtime smoke test for Nebula.")
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Keep the tmp sandbox dir on exit and print extra diagnostics.",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help=(
            "Emit a single-line JSON summary to stdout instead of the "
            "human-readable report. Exit code contract is unchanged. "
            "Useful for CI scripts that want to parse the outcome."
        ),
    )
    args = parser.parse_args()

    import json as _json

    tmp_data_dir = Path(tempfile.mkdtemp(prefix="nebula-smoke-"))
    if not args.json:
        print(f"Gate A — smoke run (sandbox: {tmp_data_dir})", flush=True)

    invariants: list[dict] = []
    rc_final = 0
    try:
        proc = _run_nebula_cycle(tmp_data_dir, verbose=args.verbose and not args.json)

        # Invariant 1: exit code 0.
        exit_ok = proc.returncode == 0
        invariants.append(
            {
                "name": "subprocess_exit_zero",
                "passed": exit_ok,
                "detail": (
                    f"exit 0 within {SMOKE_TIMEOUT_SECONDS}s wall"
                    if exit_ok
                    else f"exit code {proc.returncode}"
                ),
            }
        )
        if not exit_ok:
            rc_final = 1
            if not args.json:
                print(f"  [FAIL] `./nebula --cycles 1` exited with {proc.returncode}")
                print("\n--- stderr tail ---")
                print((proc.stderr or "")[-2000:])
        elif not args.json:
            print(f"  [OK]   subprocess exit 0 (<{SMOKE_TIMEOUT_SECONDS}s wall)")

        # Invariant 2: DB activity.
        db_path = tmp_data_dir / "engine.db"
        passed_db, msg_db = _assert_db_has_activity(db_path)
        invariants.append({"name": "db_activity", "passed": passed_db, "detail": msg_db})
        if exit_ok:
            if not passed_db:
                rc_final = 1
                if not args.json:
                    print(f"  [FAIL] DB activity check: {msg_db}")
                    print("\n--- stderr tail ---")
                    print((proc.stderr or "")[-2000:])
            elif not args.json:
                print(f"  [OK]   DB activity: {msg_db}")

        # Invariant 3: no CRITICAL logs.
        passed_log, msg_log = _assert_no_critical_logs(proc.stderr or "")
        invariants.append({"name": "no_critical_logs", "passed": passed_log, "detail": msg_log})
        if exit_ok and passed_db:
            if not passed_log:
                rc_final = 1
                if not args.json:
                    print(f"  [FAIL] log check: {msg_log}")
            elif not args.json:
                print(f"  [OK]   log check: {msg_log}")

        if args.json:
            summary = {
                "gate": "A",
                "passed": rc_final == 0,
                "invariants": invariants,
                "sandbox": str(tmp_data_dir) if args.verbose else None,
            }
            print(_json.dumps(summary), flush=True)
        elif rc_final == 0:
            print("\nGate A: PASSED")
        return rc_final
    finally:
        if not args.verbose:
            shutil.rmtree(tmp_data_dir, ignore_errors=True)
        elif not args.json:
            print(f"\nSandbox preserved at {tmp_data_dir} (--verbose)")


if __name__ == "__main__":
    raise SystemExit(main())
