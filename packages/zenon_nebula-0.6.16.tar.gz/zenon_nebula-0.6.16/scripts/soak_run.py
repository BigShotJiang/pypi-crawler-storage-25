#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Gate B — RC-time soak test (task #101).

The gap between Gate A (PR-time 60s mocked-LLM smoke, task #100) and
a tag cut: nothing today runs `./nebula` for a sustained window with
real model spend and asserts the findings actually land. An RC that
passes Gate A can still be wrong in a way that only shows up after
10+ cycles of genuine engine work — cost blow-up, silent hang, DB
corruption under sustained writes, LLM-dependent engines failing
uniformly because of a prompt regression.

What this script does:

1. Sandbox a tmp dir and point ``NEBULA_DATA_DIR`` at it so the soak
   run doesn't touch the operator's real evidence store.
2. Spawn ``./nebula`` with ``--max-hours <minutes>/60`` and
   ``--budget <usd>``. Real LLM is used when ``XAI_API_KEY`` is set;
   omit it (or pass ``--mock``) to run against ``NEBULA_MOCK_LLM=1``
   instead — useful when the operator wants a long CI-friendly
   smoke without burning real Grok budget.
3. After the run, read the sandbox DB and assert every invariant:

     * subprocess exit 0 within wall_budget + 2 min grace
     * at least MIN_ACTIONS rows in ``actions_log``
     * at least MIN_FINDINGS rows in ``evidence`` (only asserted in
       real-LLM mode; mock runs degrade the threshold)
     * sqlite ``PRAGMA integrity_check`` returns ``ok``
     * stderr has no ``CRITICAL`` log lines (same invariant as
       Gate A)

4. Tear down the sandbox on success AND failure. Keep the tmp dir
   with ``--verbose`` for post-mortem.

Exit codes:
    0    all invariants held.
    1    at least one invariant failed. Stderr tail + assertion
         details printed.
    2    bad usage or environment.

Usage:
    python3 scripts/soak_run.py --minutes 20 --budget 0.50
    python3 scripts/soak_run.py --minutes 5 --mock
    python3 scripts/soak_run.py --minutes 20 --budget 0.50 --verbose

This Phase 1 ships the standalone script. Phase 2 (wiring into
``scripts/release.py`` as a pre-tag gate) ships separately because
it's Tier 2 per ``.claude/rules/branching.md`` — touches release.py.
"""

from __future__ import annotations

import argparse
import os
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

# Minimum rows we expect per assertion class. Real-LLM runs do far
# more work than mocked ones, so thresholds are asymmetric. A mock
# run still exercises the scheduler + persistence paths; it just
# doesn't generate LLM-backed findings.
MIN_ACTIONS = 5
MIN_FINDINGS_REAL = 10
MIN_FINDINGS_MOCK = 1

# How much slack to grant on top of the requested wall time. The
# autonomous runner respects --max-hours strictly, but its internal
# cycle barrier + teardown can take another minute or two.
WALL_GRACE_SECONDS = 120

# Scope the soak to the same domain set as Gate A. Keeps the test
# deterministic and bounds the cost against 91 engines running at
# full tilt. Operators who want a wider scope can --domains it.
DEFAULT_DOMAINS = "self_maintenance,quality,intelligence,development"


def _run_nebula_soak(
    tmp_data_dir: Path,
    *,
    minutes: float,
    budget: float,
    domains: str,
    mock: bool,
    verbose: bool,
) -> tuple[subprocess.CompletedProcess, float]:
    """Spawn the soak subprocess. Returns (proc, elapsed_seconds)."""
    db_path = tmp_data_dir / "engine.db"
    cli = ROOT / "scripts" / "nebula_cli.py"
    cmd = [
        sys.executable,
        str(cli),
        "--max-hours",
        str(minutes / 60.0),
        "--budget",
        str(budget),
        "--db",
        str(db_path),
        "--domains",
        domains,
    ]
    env = dict(os.environ)
    env["NEBULA_DATA_DIR"] = str(tmp_data_dir)
    env["NEBULA_SKIP_WAR_ROOM"] = "1"

    if mock:
        env.pop("XAI_API_KEY", None)
        env["NEBULA_MOCK_LLM"] = "1"
    elif not env.get("XAI_API_KEY", "").strip():
        # No key + no --mock = can't run a real soak. Short-circuit
        # with a clear error.
        print(
            "soak_run: XAI_API_KEY is not set. Either export it for a real "
            "soak run, or pass --mock to run against the in-process LLM mock.",
            file=sys.stderr,
        )
        sys.exit(2)

    if verbose:
        mode = "mock" if mock else "real-LLM"
        print(f"  MODE: {mode}")
        print(f"  CMD:  {' '.join(cmd)}")
        print(f"  DB:   {db_path}")

    # Wall-clock timeout = minutes + grace. Subprocess hanging past
    # this is a failure, not a success.
    timeout = minutes * 60 + WALL_GRACE_SECONDS
    start = time.monotonic()
    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
            cwd=str(ROOT),
            env=env,
        )
    except subprocess.TimeoutExpired as exc:

        class _TimedOut:
            returncode = 124
            stdout = (
                (exc.stdout or "").decode() if isinstance(exc.stdout, bytes) else (exc.stdout or "")
            )
            stderr = (
                (exc.stderr or "").decode() if isinstance(exc.stderr, bytes) else (exc.stderr or "")
            )
            stderr += f"\n[soak_run] timeout after {timeout:.0f}s (budget was {minutes * 60:.0f}s + {WALL_GRACE_SECONDS}s grace)"

        return _TimedOut(), timeout  # type: ignore[return-value]

    return proc, time.monotonic() - start


def _assert_actions_log(db_path: Path) -> tuple[bool, str]:
    """actions_log must have at least MIN_ACTIONS rows — proof the
    scheduler ran multiple iterations, not just started-and-hung."""
    if not db_path.is_file():
        return False, f"DB not created at {db_path}"
    try:
        conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
    except sqlite3.OperationalError as exc:
        return False, f"DB unreadable: {exc}"
    try:
        try:
            count = conn.execute("SELECT COUNT(*) FROM actions_log").fetchone()[0]
        except sqlite3.OperationalError as exc:
            return False, f"actions_log missing or unreadable: {exc}"
    finally:
        conn.close()
    if count < MIN_ACTIONS:
        return False, f"actions_log has {count} row(s), need ≥{MIN_ACTIONS}"
    return True, f"actions_log has {count} row(s)"


def _assert_findings(db_path: Path, threshold: int) -> tuple[bool, str]:
    """evidence must have at least ``threshold`` rows — proof engines
    actually produced output, not just scheduled actions."""
    try:
        conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
    except sqlite3.OperationalError as exc:
        return False, f"DB unreadable: {exc}"
    try:
        try:
            count = conn.execute("SELECT COUNT(*) FROM evidence").fetchone()[0]
        except sqlite3.OperationalError as exc:
            return False, f"evidence missing or unreadable: {exc}"
    finally:
        conn.close()
    if count < threshold:
        return False, f"evidence has {count} row(s), need ≥{threshold}"
    return True, f"evidence has {count} row(s)"


def _assert_db_integrity(db_path: Path) -> tuple[bool, str]:
    """SQLite integrity_check must return 'ok'. Catches silent
    corruption under sustained parallel-engine writes."""
    try:
        conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
    except sqlite3.OperationalError as exc:
        return False, f"DB unreadable: {exc}"
    try:
        result = conn.execute("PRAGMA integrity_check").fetchone()
    except sqlite3.DatabaseError as exc:
        # Covers both OperationalError (locked/busy) and
        # DatabaseError (file is not a database / corrupted header).
        conn.close()
        return False, f"integrity_check failed: {exc}"
    finally:
        try:
            conn.close()
        except sqlite3.DatabaseError:
            pass
    if result is None or result[0] != "ok":
        return False, f"integrity_check reported: {result}"
    return True, "integrity_check: ok"


def _assert_no_critical_logs(stderr: str) -> tuple[bool, str]:
    """Same invariant as Gate A."""
    lines = [ln for ln in stderr.splitlines() if "[CRITICAL]" in ln or "CRITICAL -" in ln]
    if lines:
        head = "\n    ".join(lines[:3])
        more = f" (+{len(lines) - 3} more)" if len(lines) > 3 else ""
        return False, f"found {len(lines)} CRITICAL log line(s){more}:\n    {head}"
    return True, "no CRITICAL logs"


def main() -> int:
    """Run Gate B. Exit 0 on success, 1 on assertion failure, 2 on bad env."""
    parser = argparse.ArgumentParser(
        description="Gate B — RC-time soak test for Nebula.",
    )
    parser.add_argument(
        "--minutes",
        type=float,
        default=20.0,
        help="Wall-clock budget in minutes (default: 20).",
    )
    parser.add_argument(
        "--budget",
        type=float,
        default=0.50,
        help="LLM spend cap in USD (default: 0.50).",
    )
    parser.add_argument(
        "--domains",
        type=str,
        default=DEFAULT_DOMAINS,
        help=f"Comma-separated domain scope (default: {DEFAULT_DOMAINS}).",
    )
    parser.add_argument(
        "--mock",
        action="store_true",
        help=(
            "Run against the mock LLM instead of real Grok. "
            "Needed for CI envs without XAI_API_KEY. Lowers the findings "
            "threshold so mock runs pass even though they can't "
            "exercise LLM-backed engines."
        ),
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Keep the tmp sandbox on exit and print extra diagnostics.",
    )
    args = parser.parse_args()

    if args.minutes <= 0:
        print("soak_run: --minutes must be positive", file=sys.stderr)
        return 2
    if args.budget <= 0:
        print("soak_run: --budget must be positive", file=sys.stderr)
        return 2

    tmp_data_dir = Path(tempfile.mkdtemp(prefix="nebula-soak-"))
    print(f"Gate B — soak run (sandbox: {tmp_data_dir})")
    print(
        f"  minutes={args.minutes}  budget=${args.budget:.2f}  "
        f"mode={'mock' if args.mock else 'real-LLM'}  domains={args.domains}"
    )

    exit_code = 0
    try:
        proc, elapsed = _run_nebula_soak(
            tmp_data_dir,
            minutes=args.minutes,
            budget=args.budget,
            domains=args.domains,
            mock=args.mock,
            verbose=args.verbose,
        )
        print(f"  subprocess elapsed: {elapsed:.1f}s")

        # Invariant 1: exit code.
        if proc.returncode != 0:
            print(f"  [FAIL] subprocess exit {proc.returncode}")
            print("\n--- stderr tail ---")
            print((proc.stderr or "")[-3000:])
            return 1
        print("  [OK]   subprocess exit 0")

        db_path = tmp_data_dir / "engine.db"

        # Invariant 2: actions_log.
        passed, msg = _assert_actions_log(db_path)
        if not passed:
            print(f"  [FAIL] {msg}")
            exit_code = 1
        else:
            print(f"  [OK]   {msg}")

        # Invariant 3: evidence count (threshold depends on mode).
        threshold = MIN_FINDINGS_MOCK if args.mock else MIN_FINDINGS_REAL
        passed, msg = _assert_findings(db_path, threshold)
        if not passed:
            print(f"  [FAIL] {msg}")
            exit_code = 1
        else:
            print(f"  [OK]   {msg}")

        # Invariant 4: integrity.
        passed, msg = _assert_db_integrity(db_path)
        if not passed:
            print(f"  [FAIL] {msg}")
            exit_code = 1
        else:
            print(f"  [OK]   {msg}")

        # Invariant 5: no CRITICAL logs.
        passed, msg = _assert_no_critical_logs(proc.stderr or "")
        if not passed:
            print(f"  [FAIL] {msg}")
            exit_code = 1
        else:
            print(f"  [OK]   {msg}")

        if exit_code == 0:
            print("\nGate B: PASSED")
        else:
            print("\nGate B: FAILED — at least one invariant broke.")
            print("\n--- stderr tail ---")
            print((proc.stderr or "")[-3000:])

        return exit_code
    finally:
        if args.verbose:
            print(f"\nSandbox preserved at {tmp_data_dir} (--verbose)")
        else:
            shutil.rmtree(tmp_data_dir, ignore_errors=True)


if __name__ == "__main__":
    raise SystemExit(main())
