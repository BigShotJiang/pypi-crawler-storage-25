# SPDX-License-Identifier: MIT
"""
QualityDomain -- DomainPlugin for spec verification and build quality.

Provides engines for ABI spec verification (Go vs Dart byte-level
comparison), multi-language build verification, cross-repo constant
consistency checking, and test coverage gap detection.
"""

import logging

from core.domain_registry import (
    AspirationType,
    CollisionSignal,
    DomainPlugin,
    EngineDefinition,
    HypothesisType,
    WarRoomContribution,
)

logger = logging.getLogger(__name__)


class QualityDomain(DomainPlugin):
    """Quality domain plugin -- spec verification and build quality."""

    def name(self) -> str:
        """Return the domain name identifier."""
        return "quality"

    def get_description(self) -> str:
        """Return a human-readable description of this domain."""
        return (
            "Spec verification, ABI comparison, multi-language build "
            "checks, cross-repo consistency, and test coverage analysis."
        )

    def get_priority(self) -> int:
        """Return the scheduling priority for this domain."""
        return 2  # High priority -- correctness matters

    def get_engines(self) -> list[EngineDefinition]:
        """Return the list of engines this domain provides."""
        return [
            EngineDefinition(
                name="spec_verifier",
                description=(
                    "Reads go-zenon ABI JSON and Dart SDK ABI definition "
                    "string, performs byte-level comparison, and verifies "
                    "Go struct JSON tags match Dart fromJson keys."
                ),
                module_path="domains.quality.engines.spec_verifier",
                priority=1,
                tier=1,
                required_apis=["filesystem"],
                max_runtime_seconds=120,
            ),
            EngineDefinition(
                name="build_verifier",
                description=(
                    "Multi-language build checks: Go build/vet, "
                    "Dart pub get/analyze, TypeScript tsc --noEmit, "
                    "Python py_compile."
                ),
                module_path="domains.quality.engines.build_verifier",
                priority=2,
                tier=1,
                required_apis=["shell"],
                max_runtime_seconds=600,
            ),
            EngineDefinition(
                name="cross_repo_checker",
                description=(
                    "Verifies constants (addresses, ABI method names) "
                    "are identical across go-zenon, Dart SDK, CLI, "
                    "and other repos."
                ),
                module_path="domains.quality.engines.cross_repo_checker",
                priority=3,
                tier=1,
                required_apis=["filesystem"],
                max_runtime_seconds=120,
            ),
            EngineDefinition(
                name="test_coverage",
                description=(
                    "Detects test gaps: counts test functions per "
                    "contract in Go, Dart, etc. and identifies methods "
                    "with zero test coverage."
                ),
                module_path="domains.quality.engines.test_coverage",
                priority=4,
                tier=1,
                required_apis=["filesystem"],
                max_runtime_seconds=120,
            ),
            EngineDefinition(
                name="reference_diff",
                description=(
                    "Diffs consensus-critical primitives (merkle proof "
                    "validation, secp256k1 signature verification) "
                    "between Zenon repos and reference chain repos "
                    "(Bitcoin, Ethereum, etc.) and flags large "
                    "divergences. Activates when a reference chain is "
                    "present in the workspace."
                ),
                module_path="domains.quality.engines.reference_diff",
                priority=5,
                tier=2,
                required_apis=["filesystem"],
                max_runtime_seconds=120,
            ),
        ]

    def get_hypothesis_types(self) -> list[HypothesisType]:
        """Return hypothesis types this domain can generate."""
        return [
            HypothesisType(
                type_id="abi_mismatch",
                label="ABI mismatch detected",
                description=(
                    "The ABI definition in Go does not match the ABI "
                    "definition in the Dart SDK at the byte level."
                ),
                initial_confidence=0.8,
                publishable_threshold=0.95,
            ),
            HypothesisType(
                type_id="build_regression",
                label="Build regression detected",
                description=(
                    "A repository that previously built successfully "
                    "now fails to compile or passes with warnings."
                ),
                initial_confidence=0.9,
                publishable_threshold=0.95,
            ),
            HypothesisType(
                type_id="constant_inconsistency",
                label="Cross-repo constant inconsistency",
                description=(
                    "A constant (address, method name, etc.) differs "
                    "between two or more repositories."
                ),
                initial_confidence=0.7,
                publishable_threshold=0.90,
            ),
            HypothesisType(
                type_id="test_gap",
                label="Test coverage gap",
                description=(
                    "A contract method has zero test coverage in one "
                    "or more language implementations."
                ),
                initial_confidence=0.5,
                publishable_threshold=0.80,
            ),
        ]

    def get_aspiration_types(self) -> list[AspirationType]:
        """Return aspiration types this domain can pursue."""
        return [
            AspirationType(
                type_id="abi_parity",
                label="Full ABI parity",
                description=("All contract ABIs are byte-identical between Go and every SDK."),
                priority=2,
            ),
            AspirationType(
                type_id="green_builds",
                label="All builds green",
                description=(
                    "All repositories compile without errors or warnings "
                    "across all supported languages."
                ),
                priority=2,
                deadline_days=7,
            ),
            AspirationType(
                type_id="full_test_coverage",
                label="Full test coverage",
                description=(
                    "Every contract method has at least one test in every language implementation."
                ),
                priority=3,
                deadline_days=90,
            ),
        ]

    def get_collision_signals(self) -> list[CollisionSignal]:
        """Return signals that trigger cross-domain collisions."""
        return [
            CollisionSignal(
                signal_id="quality_security_overlap",
                label="Quality + security overlap",
                description=(
                    "A quality finding (e.g. ABI mismatch) has security "
                    "implications (e.g. wrong method signature could "
                    "allow fund theft)."
                ),
                source_domains=["quality", "security"],
                convergence_threshold=0.6,
            ),
            CollisionSignal(
                signal_id="quality_dev_divergence",
                label="Quality-development divergence",
                description=(
                    "Quality checks reveal that implementations have diverged from the spec."
                ),
                source_domains=["quality", "development"],
                convergence_threshold=0.7,
            ),
        ]

    def get_war_room_contributions(self) -> list[WarRoomContribution]:
        """Return this domain's war room briefing sections."""
        return [
            WarRoomContribution(
                domain="quality",
                section_title="Quality Status",
                metrics=[
                    "abi_match_pct",
                    "build_pass_rate",
                    "constant_consistency_pct",
                    "test_coverage_pct",
                ],
                recommendations_prompt=(
                    "Based on current quality metrics, what are the "
                    "most urgent quality issues to address?"
                ),
            ),
        ]

    def get_self_improvement_metrics(self) -> dict[str, float]:
        """Return current performance metrics for self-improvement."""
        return {
            "abi_match_pct": 0.0,
            "build_pass_rate": 0.0,
            "constant_consistency_pct": 0.0,
            "test_coverage_pct": 0.0,
        }

    def decide_next_action(self, context: dict, exclude: set[str] | None = None) -> dict | None:
        """Decide the next action, rotating through all 5 quality engines."""
        exclude = exclude or set()
        trigger = context.get("trigger_level", "routine")
        stale = context.get("stale_data", [])
        candidates: list[dict] = []

        if trigger in ("urgent", "critical"):
            candidates.append(
                {
                    "action": "urgent_verify_builds",
                    "reason": "Urgent trigger -- verify all builds pass.",
                    "priority": 2,
                    "engine": "build_verifier",
                }
            )

        if "abi_verification" in stale:
            candidates.append(
                {
                    "action": "verify_abis",
                    "reason": "ABI verification data is stale.",
                    "priority": 3,
                    "engine": "spec_verifier",
                }
            )

        if "cross_repo_check" in stale:
            candidates.append(
                {
                    "action": "check_consistency",
                    "reason": "Cross-repo consistency data is stale.",
                    "priority": 4,
                    "engine": "cross_repo_checker",
                }
            )

        candidates.extend(
            [
                {
                    "action": "routine_test_coverage",
                    "reason": "Routine test coverage analysis.",
                    "priority": 5,
                    "engine": "test_coverage",
                },
                {
                    "action": "routine_spec_verifier",
                    "reason": "Routine spec verifier rotation.",
                    "priority": 6,
                    "engine": "spec_verifier",
                },
                {
                    "action": "routine_build_verifier",
                    "reason": "Routine build verifier rotation.",
                    "priority": 6,
                    "engine": "build_verifier",
                },
                {
                    "action": "routine_cross_repo_check",
                    "reason": "Routine cross-repo consistency rotation.",
                    "priority": 6,
                    "engine": "cross_repo_checker",
                },
                {
                    "action": "routine_reference_diff",
                    "reason": "Routine cross-chain reference diff rotation.",
                    "priority": 7,
                    "engine": "reference_diff",
                },
            ]
        )

        for candidate in candidates:
            key = f"quality:{candidate['action']}"
            if key not in exclude:
                return candidate
        return None

    def get_db_schema_sql(self) -> str:
        """Return domain-specific SQL DDL for additional tables."""
        return """
CREATE TABLE IF NOT EXISTS build_status (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    repo_name TEXT NOT NULL,
    language TEXT NOT NULL,
    build_command TEXT NOT NULL,
    success BOOLEAN NOT NULL,
    output TEXT,
    duration_seconds REAL
);

CREATE TABLE IF NOT EXISTS test_coverage (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    contract_name TEXT NOT NULL,
    language TEXT NOT NULL,
    test_count INTEGER DEFAULT 0,
    methods_tested INTEGER DEFAULT 0,
    methods_total INTEGER DEFAULT 0,
    coverage_pct REAL DEFAULT 0.0
);

CREATE TABLE IF NOT EXISTS consistency_checks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    check_type TEXT NOT NULL,
    contract_name TEXT NOT NULL,
    item_name TEXT NOT NULL,
    repo_a TEXT NOT NULL,
    value_a TEXT,
    repo_b TEXT NOT NULL,
    value_b TEXT,
    match BOOLEAN NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_build_status_repo
    ON build_status(repo_name);
CREATE INDEX IF NOT EXISTS idx_build_status_success
    ON build_status(success);
CREATE INDEX IF NOT EXISTS idx_test_coverage_contract
    ON test_coverage(contract_name);
CREATE INDEX IF NOT EXISTS idx_consistency_match
    ON consistency_checks(match);
"""

    def on_register(self) -> None:
        """Initialize domain-specific resources after registration."""
        logger.info(
            "Quality domain registered with %d engines.",
            len(self.get_engines()),
        )
