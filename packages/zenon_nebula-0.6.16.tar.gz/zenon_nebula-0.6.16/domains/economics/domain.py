# SPDX-License-Identifier: MIT
"""
EconomicsDomain -- DomainPlugin for tokenomics tracking and analysis.

Provides engines for supply tracking (emission, burn, circulating supply),
staking analysis (ratio, delegation, lock durations), liquidity monitoring
(Uniswap pool depth, slippage), and participation funnel tracking.
"""

import logging

from core.domain_registry import (
    AspirationType,
    CollisionSignal,
    DomainPlugin,
    EngineDefinition,
    HypothesisType,
    WarRoomContribution,
)

logger = logging.getLogger(__name__)


class EconomicsDomain(DomainPlugin):
    """Economics domain plugin -- tokenomics and economic health tracking."""

    def name(self) -> str:
        """Return the domain name identifier."""
        return "economics"

    def get_description(self) -> str:
        """Return a human-readable description of this domain."""
        return (
            "Tokenomics tracking: supply emission and burn, staking ratio "
            "and delegation analysis, liquidity monitoring, and participation "
            "funnel tracking from holder to pillar."
        )

    def get_priority(self) -> int:
        """Return the scheduling priority for this domain."""
        return 3

    def get_engines(self) -> list[EngineDefinition]:
        """Return the list of engines this domain provides."""
        return [
            EngineDefinition(
                name="supply_tracker",
                description=(
                    "Track ZNN/QSR emission rate, burn rate, and circulating supply over time."
                ),
                module_path="domains.economics.engines.supply_tracker",
                priority=1,
                tier=1,
                required_apis=["zenonhub"],
                max_runtime_seconds=120,
            ),
            EngineDefinition(
                name="staking_analyzer",
                description=(
                    "Analyze staking ratio, delegation distribution, "
                    "lock durations, and staking concentration."
                ),
                module_path="domains.economics.engines.staking_analyzer",
                priority=2,
                tier=2,
                required_apis=["zenonhub"],
                max_runtime_seconds=120,
            ),
            EngineDefinition(
                name="liquidity_monitor",
                description=(
                    "Monitor Uniswap pool depth, slippage estimation, "
                    "and volume for ZNN/wZNN pairs."
                ),
                module_path="domains.economics.engines.liquidity_monitor",
                priority=3,
                tier=2,
                required_apis=["dexscreener"],
                max_runtime_seconds=60,
            ),
            EngineDefinition(
                name="funnel_tracker",
                description=(
                    "Track participation funnel: holder -> delegator -> "
                    "staker -> LP -> sentinel -> pillar."
                ),
                module_path="domains.economics.engines.funnel_tracker",
                priority=4,
                tier=2,
                required_apis=["zenonhub"],
                max_runtime_seconds=180,
            ),
            EngineDefinition(
                name="whale_watcher",
                description=(
                    "Monitor large token movements, delegation changes, "
                    "whale accumulation/distribution, and anomalous activity."
                ),
                module_path="domains.economics.engines.whale_watcher",
                priority=2,
                tier=1,
                required_apis=["zenonhub"],
                max_runtime_seconds=120,
            ),
            EngineDefinition(
                name="yield_calculator",
                description=(
                    "Calculate real yields from staking, delegation, and "
                    "pillar operation. Compare yields across pillars and "
                    "track yield trends over time."
                ),
                module_path="domains.economics.engines.yield_calculator",
                priority=3,
                tier=1,
                required_apis=["zenonhub"],
                max_runtime_seconds=120,
            ),
        ]

    def get_hypothesis_types(self) -> list[HypothesisType]:
        """Return hypothesis types this domain can generate."""
        return [
            HypothesisType(
                type_id="staking_ratio_50pct",
                label="Staking ratio will exceed 50%",
                description=(
                    "The proportion of total ZNN supply that is staked "
                    "or delegated will surpass 50%."
                ),
                initial_confidence=0.3,
                publishable_threshold=0.80,
            ),
            HypothesisType(
                type_id="pillar_rewards_sustainable",
                label="Pillar rewards sustainable",
                description=(
                    "Current emission rates and pillar reward distribution "
                    "are sustainable for the next 2+ years."
                ),
                initial_confidence=0.3,
                publishable_threshold=0.80,
            ),
            HypothesisType(
                type_id="deflationary_trend",
                label="ZNN trending deflationary",
                description=(
                    "Burn rate is approaching or exceeding emission rate, "
                    "creating deflationary pressure."
                ),
                initial_confidence=0.2,
                publishable_threshold=0.75,
            ),
            HypothesisType(
                type_id="liquidity_adequate",
                label="DEX liquidity adequate for adoption",
                description=(
                    "Uniswap pool depth supports trades up to $10k with less than 5% slippage."
                ),
                initial_confidence=0.2,
                publishable_threshold=0.75,
            ),
            HypothesisType(
                type_id="whale_concentration_risk",
                label="Whale concentration poses sell pressure risk",
                description=(
                    "Top 5 holders control enough ZNN that a coordinated "
                    "sell-off could significantly impact market price."
                ),
                initial_confidence=0.3,
                publishable_threshold=0.75,
            ),
            HypothesisType(
                type_id="delegation_yields_competitive",
                label="Delegation yields competitive with DeFi",
                description=(
                    "Average delegation APR is competitive with comparable L1 staking yields."
                ),
                initial_confidence=0.3,
                publishable_threshold=0.75,
            ),
        ]

    def get_aspiration_types(self) -> list[AspirationType]:
        """Return aspiration types this domain can pursue."""
        return [
            AspirationType(
                type_id="full_supply_model",
                label="Full supply model",
                description=(
                    "Maintain a calibrated model of ZNN/QSR emission, burn, and circulating supply."
                ),
                priority=3,
            ),
            AspirationType(
                type_id="funnel_visibility",
                label="Full funnel visibility",
                description=(
                    "Track every stage of the participation funnel with daily resolution."
                ),
                priority=4,
                deadline_days=60,
            ),
        ]

    def get_collision_signals(self) -> list[CollisionSignal]:
        """Return signals that trigger cross-domain collisions."""
        return [
            CollisionSignal(
                signal_id="economics_governance_overlap",
                label="Economics-governance overlap",
                description=(
                    "Staking/delegation changes intersect with governance voting power dynamics."
                ),
                source_domains=["economics", "governance"],
                convergence_threshold=0.6,
            ),
            CollisionSignal(
                signal_id="economics_network_overlap",
                label="Economics-network overlap",
                description=(
                    "Liquidity or staking changes correlate with bridge TVL or node count changes."
                ),
                source_domains=["economics", "network_health"],
                convergence_threshold=0.6,
            ),
        ]

    def get_war_room_contributions(self) -> list[WarRoomContribution]:
        """Return this domain's war room briefing sections."""
        return [
            WarRoomContribution(
                domain="economics",
                section_title="Tokenomics",
                metrics=[
                    "circulating_supply_znn",
                    "circulating_supply_qsr",
                    "emission_rate_daily",
                    "burn_rate_daily",
                    "staking_ratio_pct",
                    "delegation_concentration",
                    "uniswap_liquidity_usd",
                    "funnel_conversion_rates",
                    "whale_top_5_share_pct",
                    "whale_accumulation_trend",
                    "avg_delegation_apr",
                    "staking_apr_qsr",
                ],
                recommendations_prompt=(
                    "Based on tokenomics trends, what economic risks "
                    "or opportunities should be flagged?"
                ),
            ),
        ]

    def get_self_improvement_metrics(self) -> dict[str, float]:
        """Return current performance metrics for self-improvement."""
        return {
            "supply_data_freshness_hours": 0.0,
            "staking_data_freshness_hours": 0.0,
            "liquidity_checks_per_day": 0.0,
            "funnel_completeness_pct": 0.0,
            "whale_data_freshness_hours": 0.0,
            "yield_data_freshness_hours": 0.0,
        }

    def decide_next_action(self, context: dict, exclude: set[str] | None = None) -> dict | None:
        """Decide the next action, rotating through all 6 economics engines."""
        exclude = exclude or set()
        trigger = context.get("trigger_level", "routine")
        stale = context.get("stale_data", [])
        candidates: list[dict] = []

        if trigger in ("urgent", "critical"):
            candidates.append(
                {
                    "action": "check_liquidity",
                    "reason": "Urgent trigger -- check DEX liquidity.",
                    "priority": 3,
                    "engine": "liquidity_monitor",
                }
            )

        if "supply_data" in stale:
            candidates.append(
                {
                    "action": "refresh_supply",
                    "reason": "Supply data is stale.",
                    "priority": 4,
                    "engine": "supply_tracker",
                }
            )

        if "staking_data" in stale:
            candidates.append(
                {
                    "action": "refresh_staking",
                    "reason": "Staking data is stale.",
                    "priority": 5,
                    "engine": "staking_analyzer",
                }
            )

        if "liquidity_data" in stale:
            candidates.append(
                {
                    "action": "check_liquidity_stale",
                    "reason": "Liquidity data is stale.",
                    "priority": 5,
                    "engine": "liquidity_monitor",
                }
            )

        if "whale_data" in stale:
            candidates.append(
                {
                    "action": "watch_whales",
                    "reason": "Whale activity data is stale.",
                    "priority": 4,
                    "engine": "whale_watcher",
                }
            )

        if "yield_data" in stale:
            candidates.append(
                {
                    "action": "calculate_yields",
                    "reason": "Yield data is stale.",
                    "priority": 5,
                    "engine": "yield_calculator",
                }
            )

        candidates.extend(
            [
                {
                    "action": "routine_track_funnel",
                    "reason": "Routine participation funnel update.",
                    "priority": 6,
                    "engine": "funnel_tracker",
                },
                {
                    "action": "routine_supply_tracker",
                    "reason": "Routine supply tracker rotation.",
                    "priority": 7,
                    "engine": "supply_tracker",
                },
                {
                    "action": "routine_staking_analyzer",
                    "reason": "Routine staking analyzer rotation.",
                    "priority": 7,
                    "engine": "staking_analyzer",
                },
                {
                    "action": "routine_liquidity_monitor",
                    "reason": "Routine liquidity monitor rotation.",
                    "priority": 7,
                    "engine": "liquidity_monitor",
                },
                {
                    "action": "routine_whale_watcher",
                    "reason": "Routine whale watcher rotation.",
                    "priority": 7,
                    "engine": "whale_watcher",
                },
                {
                    "action": "routine_yield_calculator",
                    "reason": "Routine yield calculator rotation.",
                    "priority": 7,
                    "engine": "yield_calculator",
                },
            ]
        )

        for candidate in candidates:
            key = f"economics:{candidate['action']}"
            if key not in exclude:
                return candidate
        return None

    def get_db_schema_sql(self) -> str:
        """Return domain-specific SQL DDL for additional tables."""
        return """
CREATE TABLE IF NOT EXISTS supply_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    znn_total_supply REAL,
    znn_circulating REAL,
    znn_emission_daily REAL,
    znn_burn_daily REAL,
    qsr_total_supply REAL,
    qsr_circulating REAL,
    qsr_emission_daily REAL,
    qsr_burn_daily REAL,
    source TEXT DEFAULT 'zenonhub'
);

CREATE TABLE IF NOT EXISTS staking_metrics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    total_staked_znn REAL DEFAULT 0.0,
    total_delegated_znn REAL DEFAULT 0.0,
    staking_ratio REAL DEFAULT 0.0,
    unique_stakers INTEGER DEFAULT 0,
    unique_delegators INTEGER DEFAULT 0,
    avg_lock_duration_months REAL DEFAULT 0.0,
    delegation_hhi REAL DEFAULT 0.0,
    source TEXT DEFAULT 'zenonhub'
);

CREATE TABLE IF NOT EXISTS liquidity_metrics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    pair_name TEXT DEFAULT 'ZNN/ETH',
    pool_address TEXT,
    liquidity_usd REAL DEFAULT 0.0,
    volume_24h_usd REAL DEFAULT 0.0,
    price_usd REAL DEFAULT 0.0,
    price_change_24h REAL DEFAULT 0.0,
    slippage_1k_usd REAL DEFAULT 0.0,
    slippage_10k_usd REAL DEFAULT 0.0,
    source TEXT DEFAULT 'dexscreener'
);

CREATE INDEX IF NOT EXISTS idx_supply_ts
    ON supply_snapshots(timestamp);
CREATE INDEX IF NOT EXISTS idx_staking_ts
    ON staking_metrics(timestamp);
CREATE INDEX IF NOT EXISTS idx_liquidity_ts
    ON liquidity_metrics(timestamp);
CREATE INDEX IF NOT EXISTS idx_liquidity_pair
    ON liquidity_metrics(pair_name);

CREATE TABLE IF NOT EXISTS whale_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    top_5_share_pct REAL DEFAULT 0.0,
    top_10_share_pct REAL DEFAULT 0.0,
    whale_count INTEGER DEFAULT 0,
    total_held_znn REAL DEFAULT 0.0,
    large_tx_count INTEGER DEFAULT 0,
    delegation_changes_count INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS whale_delegation_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    snapshot_id INTEGER NOT NULL,
    pillar_name TEXT NOT NULL,
    weight REAL DEFAULT 0.0,
    FOREIGN KEY (snapshot_id) REFERENCES whale_snapshots(id)
);

CREATE TABLE IF NOT EXISTS yield_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    avg_delegation_apr REAL DEFAULT 0.0,
    max_delegation_apr REAL DEFAULT 0.0,
    min_delegation_apr REAL DEFAULT 0.0,
    staking_apr_qsr REAL DEFAULT 0.0,
    pillar_apr REAL DEFAULT 0.0,
    pillar_count INTEGER DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_whale_snapshots_ts
    ON whale_snapshots(timestamp);
CREATE INDEX IF NOT EXISTS idx_whale_deleg_snapshot
    ON whale_delegation_snapshots(snapshot_id);
CREATE INDEX IF NOT EXISTS idx_yield_snapshots_ts
    ON yield_snapshots(timestamp);
"""

    def on_register(self) -> None:
        """Initialize domain-specific resources after registration."""
        logger.info(
            "Economics domain registered with %d engines.",
            len(self.get_engines()),
        )
