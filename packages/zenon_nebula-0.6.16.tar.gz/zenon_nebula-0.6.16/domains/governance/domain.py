# SPDX-License-Identifier: MIT
"""
GovernanceDomain -- DomainPlugin for AZ treasury, proposal tracking, and voting analysis.

Provides engines for monitoring Accelerator-Z treasury balance and burn rate,
parsing proposal lifecycles, and analyzing pillar voting behavior.
"""

import logging

from core.domain_registry import (
    AspirationType,
    CollisionSignal,
    DomainPlugin,
    EngineDefinition,
    HypothesisType,
    WarRoomContribution,
)

logger = logging.getLogger(__name__)


class GovernanceDomain(DomainPlugin):
    """Governance domain plugin -- AZ treasury and voting analysis."""

    def name(self) -> str:
        """Return the domain name identifier."""
        return "governance"

    def get_description(self) -> str:
        """Return a human-readable description of this domain."""
        return (
            "Accelerator-Z treasury monitoring, proposal lifecycle tracking, "
            "pillar voting pattern analysis, and governance health scoring."
        )

    def get_priority(self) -> int:
        """Return the scheduling priority for this domain."""
        return 3

    def get_engines(self) -> list[EngineDefinition]:
        """Return the list of engines this domain provides."""
        return [
            EngineDefinition(
                name="treasury_monitor",
                description=(
                    "Track AZ treasury balance, funding rate, burn rate, "
                    "and estimate runway in months."
                ),
                module_path="domains.governance.engines.treasury_monitor",
                priority=1,
                tier=1,
                required_apis=["zenonhub"],
                max_runtime_seconds=120,
            ),
            EngineDefinition(
                name="proposal_analyzer",
                description=(
                    "Parse AZ proposals, track lifecycle from submission "
                    "through voting, funding, and delivery."
                ),
                module_path="domains.governance.engines.proposal_analyzer",
                priority=2,
                tier=2,
                required_apis=["zenonhub"],
                max_runtime_seconds=180,
            ),
            EngineDefinition(
                name="voting_patterns",
                description=(
                    "Analyze pillar voting behavior: participation rates, "
                    "voting concentration, yes/no ratios, abstention."
                ),
                module_path="domains.governance.engines.voting_patterns",
                priority=3,
                tier=2,
                required_apis=["zenonhub"],
                max_runtime_seconds=120,
            ),
            EngineDefinition(
                name="governance_intel",
                description=(
                    "Aggregate governance health: funding rates, stuck "
                    "proposals, voting blocs, treasury runway, and "
                    "outcome predictions for pending proposals."
                ),
                module_path="domains.governance.engines.governance_intel",
                priority=4,
                tier=2,
                required_apis=[],
                max_runtime_seconds=120,
            ),
            EngineDefinition(
                name="pillar_accountability",
                description=(
                    "Score pillars on governance participation, proposal "
                    "sponsorship, uptime, and reward sharing. Composite "
                    "accountability score helps delegators choose wisely."
                ),
                module_path="domains.governance.engines.pillar_accountability",
                priority=3,
                tier=2,
                required_apis=["zenonhub"],
                max_runtime_seconds=180,
            ),
        ]

    def get_hypothesis_types(self) -> list[HypothesisType]:
        """Return hypothesis types this domain can generate."""
        return [
            HypothesisType(
                type_id="treasury_sustainability",
                label="AZ treasury sustainable for 2+ years",
                description=(
                    "Based on current funding rate and emission, the AZ "
                    "treasury can sustain operations for at least 2 years."
                ),
                initial_confidence=0.3,
                publishable_threshold=0.80,
            ),
            HypothesisType(
                type_id="governance_participation_trend",
                label="Governance participation increasing",
                description=(
                    "Pillar voting participation rates are trending upward "
                    "over the trailing 90-day window."
                ),
                initial_confidence=0.2,
                publishable_threshold=0.75,
            ),
            HypothesisType(
                type_id="voting_concentration_risk",
                label="Voting power concentration risk",
                description=(
                    "A small subset of pillars controls the majority of "
                    "governance outcomes, posing centralization risk."
                ),
                initial_confidence=0.3,
                publishable_threshold=0.80,
            ),
            HypothesisType(
                type_id="accountability_improving",
                label="Pillar accountability improving",
                description=(
                    "Mean pillar accountability score is trending upward, "
                    "indicating improving governance engagement."
                ),
                initial_confidence=0.2,
                publishable_threshold=0.75,
            ),
        ]

    def get_aspiration_types(self) -> list[AspirationType]:
        """Return aspiration types this domain can pursue."""
        return [
            AspirationType(
                type_id="full_proposal_coverage",
                label="Full proposal lifecycle coverage",
                description=(
                    "Track every AZ proposal from submission to delivery "
                    "with status updates within 24 hours."
                ),
                priority=3,
            ),
            AspirationType(
                type_id="treasury_runway_model",
                label="Accurate treasury runway model",
                description=(
                    "Maintain a calibrated model that predicts AZ treasury "
                    "depletion date within +/- 30 days."
                ),
                priority=4,
                deadline_days=60,
            ),
        ]

    def get_collision_signals(self) -> list[CollisionSignal]:
        """Return signals that trigger cross-domain collisions."""
        return [
            CollisionSignal(
                signal_id="governance_economics_overlap",
                label="Governance-economics overlap",
                description=(
                    "Treasury outflow rate intersects with emission/burn "
                    "economics, requiring cross-domain analysis."
                ),
                source_domains=["governance", "economics"],
                convergence_threshold=0.6,
            ),
            CollisionSignal(
                signal_id="governance_development_overlap",
                label="Governance-development overlap",
                description=(
                    "A funded proposal targets a spec that the development "
                    "domain is already tracking."
                ),
                source_domains=["governance", "development"],
                convergence_threshold=0.5,
            ),
        ]

    def get_war_room_contributions(self) -> list[WarRoomContribution]:
        """Return this domain's war room briefing sections."""
        return [
            WarRoomContribution(
                domain="governance",
                section_title="AZ Treasury & Governance",
                metrics=[
                    "treasury_znn_balance",
                    "treasury_qsr_balance",
                    "runway_months",
                    "active_proposals",
                    "pillar_participation_rate",
                    "avg_votes_per_proposal",
                    "mean_accountability_score",
                    "exemplary_pillar_count",
                    "poor_pillar_count",
                ],
                recommendations_prompt=(
                    "Based on treasury burn rate and voting patterns, "
                    "what governance risks should be flagged?"
                ),
            ),
        ]

    def get_self_improvement_metrics(self) -> dict[str, float]:
        """Return current performance metrics for self-improvement."""
        return {
            "proposals_tracked": 0.0,
            "treasury_prediction_accuracy": 0.0,
            "voting_data_freshness_hours": 0.0,
            "pillar_coverage_pct": 0.0,
            "accountability_freshness_hours": 0.0,
        }

    def decide_next_action(self, context: dict, exclude: set[str] | None = None) -> dict | None:
        """Decide the next action, rotating through all 5 governance engines."""
        exclude = exclude or set()
        trigger = context.get("trigger_level", "routine")
        stale = context.get("stale_data", [])
        candidates: list[dict] = []

        if trigger in ("urgent", "critical"):
            candidates.append(
                {
                    "action": "refresh_treasury",
                    "reason": "Urgent trigger -- refresh treasury balance.",
                    "priority": 3,
                    "engine": "treasury_monitor",
                }
            )

        if "treasury_balance" in stale:
            candidates.append(
                {
                    "action": "stale_treasury",
                    "reason": "Treasury data is stale.",
                    "priority": 4,
                    "engine": "treasury_monitor",
                }
            )

        if "proposals" in stale:
            candidates.append(
                {
                    "action": "refresh_proposals",
                    "reason": "Proposal data is stale.",
                    "priority": 5,
                    "engine": "proposal_analyzer",
                }
            )

        if "accountability" in stale:
            candidates.append(
                {
                    "action": "score_accountability",
                    "reason": "Pillar accountability data is stale.",
                    "priority": 5,
                    "engine": "pillar_accountability",
                }
            )

        candidates.extend(
            [
                {
                    "action": "routine_voting",
                    "reason": "Routine voting pattern analysis.",
                    "priority": 6,
                    "engine": "voting_patterns",
                },
                {
                    "action": "routine_treasury",
                    "reason": "Routine treasury monitor rotation.",
                    "priority": 7,
                    "engine": "treasury_monitor",
                },
                {
                    "action": "routine_proposals",
                    "reason": "Routine proposal analyzer rotation.",
                    "priority": 7,
                    "engine": "proposal_analyzer",
                },
                {
                    "action": "routine_governance_intel",
                    "reason": "Routine governance intel rotation.",
                    "priority": 7,
                    "engine": "governance_intel",
                },
                {
                    "action": "routine_pillar_accountability",
                    "reason": "Routine pillar accountability scoring.",
                    "priority": 7,
                    "engine": "pillar_accountability",
                },
            ]
        )

        for candidate in candidates:
            key = f"governance:{candidate['action']}"
            if key not in exclude:
                return candidate
        return None

    def get_db_schema_sql(self) -> str:
        """Return domain-specific SQL DDL for additional tables."""
        return """
CREATE TABLE IF NOT EXISTS az_proposals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    proposal_id TEXT UNIQUE NOT NULL,
    title TEXT,
    description TEXT,
    owner_address TEXT,
    znn_requested REAL DEFAULT 0.0,
    qsr_requested REAL DEFAULT 0.0,
    status TEXT DEFAULT 'submitted',
    votes_yes INTEGER DEFAULT 0,
    votes_no INTEGER DEFAULT 0,
    votes_abstain INTEGER DEFAULT 0,
    created_at DATETIME,
    last_updated DATETIME DEFAULT CURRENT_TIMESTAMP,
    funded_at DATETIME,
    delivered_at DATETIME
);

CREATE TABLE IF NOT EXISTS pillar_votes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    proposal_id TEXT NOT NULL,
    pillar_name TEXT NOT NULL,
    vote TEXT NOT NULL,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(proposal_id, pillar_name)
);

CREATE TABLE IF NOT EXISTS treasury_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    znn_balance REAL,
    qsr_balance REAL,
    znn_funded_30d REAL DEFAULT 0.0,
    qsr_funded_30d REAL DEFAULT 0.0,
    runway_months REAL,
    active_proposals INTEGER DEFAULT 0,
    source TEXT DEFAULT 'zenonhub'
);

CREATE INDEX IF NOT EXISTS idx_proposals_status
    ON az_proposals(status);
CREATE INDEX IF NOT EXISTS idx_proposals_owner
    ON az_proposals(owner_address);
CREATE INDEX IF NOT EXISTS idx_votes_proposal
    ON pillar_votes(proposal_id);
CREATE INDEX IF NOT EXISTS idx_votes_pillar
    ON pillar_votes(pillar_name);
CREATE INDEX IF NOT EXISTS idx_treasury_ts
    ON treasury_snapshots(timestamp);

CREATE TABLE IF NOT EXISTS pillar_accountability_scores (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    batch_id INTEGER NOT NULL,
    pillar_name TEXT NOT NULL,
    total_score REAL DEFAULT 0.0,
    voting_score REAL DEFAULT 0.0,
    sponsorship_score REAL DEFAULT 0.0,
    uptime_score REAL DEFAULT 0.0,
    reward_score REAL DEFAULT 0.0
);

CREATE INDEX IF NOT EXISTS idx_accountability_batch
    ON pillar_accountability_scores(batch_id);
CREATE INDEX IF NOT EXISTS idx_accountability_pillar
    ON pillar_accountability_scores(pillar_name);
"""

    def on_register(self) -> None:
        """Initialize domain-specific resources after registration."""
        logger.info(
            "Governance domain registered with %d engines.",
            len(self.get_engines()),
        )
