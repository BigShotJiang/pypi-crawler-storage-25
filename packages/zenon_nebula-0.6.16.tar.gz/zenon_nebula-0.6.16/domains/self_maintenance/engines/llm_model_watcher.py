# SPDX-License-Identifier: MIT
"""LLM model watcher — autonomous xAI catalog monitor.

**Why this exists:** ``core.llm_provider.MODEL_PRICING`` is a hand-
maintained dict. When xAI ships a new Grok model or deprecates an old
one, the dict drifts — and until an operator notices, Nebula either
runs on stale models or misses cheaper/better options.

This engine closes that gap autonomously:

1. Periodically fetches ``/v1/models`` from the xAI API (the only
   call xAI exposes that's free of charge).
2. Diffs the returned catalog against ``MODEL_PRICING`` keys.
3. Surfaces three signal classes:

   - **new_model** — model available on API but not in MODEL_PRICING.
     Recommend adding it (operator must manually look up pricing;
     ``/v1/models`` doesn't return prices).
   - **removed_model** — model in MODEL_PRICING but no longer on API.
     Suggests xAI retired or renamed it — re-check before next cycle.
   - **flagship_shift** — API lists a model whose name sorts higher
     than the current :data:`DEFAULT_BEST`. Recommend operator
     benchmark it.

Sibling to :mod:`llm_cost_optimizer` (task #94) — that one watches
our spend, this one watches xAI's catalog. Both are self-audit
signals surfaced to the war room.

**Discipline:**

- Detection-only. **Never** modifies MODEL_PRICING. The operator
  (or a Phase I executor agent) proposes the code change.
- Confidence capped at :data:`DEFAULT_CONFIDENCE` (0.40) because
  the recommendation is about a future spec — anti-hallucination
  rule #6: trust the API response for detection, not for action.
- Detection costs zero LLM money (``/v1/models`` is free).
- 24h cooldown per (model_id, signal_class) — otherwise a new
  Grok release would flood the war room for days.
- Gracefully degrades when ``XAI_API_KEY`` is unset (returns
  empty summary with ``"reason": "no_api_key"``).

**Safety rails (mechanical):**

- No auto-ship. Every signal surfaces as an evidence row; no code
  write-path touches the wheel.
- Trust cap at 0.40 (see :data:`DEFAULT_CONFIDENCE`).
- Network failures are logged and swallowed — never crash the
  scheduler.

See also ``docs/tasks.yaml`` task #92 for the phased roadmap
(detection-only → benchmark mode → Phase I auto-claim).
"""

from __future__ import annotations

import json
import logging
import os
import sqlite3
import urllib.error
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

from core.llm_provider import DEFAULT_BEST, MODEL_PRICING, XAI_BASE_URL
from core.persist_to_db import DEFAULT_DB, persist_finding
from core.persistence import connect

logger = logging.getLogger(__name__)


# Tunables. Constants so tests can monkeypatch without re-architecting.
FETCH_TIMEOUT_SECONDS = 10
MAX_BYTES = 1 << 18  # 256 KB is plenty for /v1/models
COOLDOWN_HOURS = 24
DEFAULT_CONFIDENCE = 0.40  # anti-hallucination rule #6 — external API only
MAX_FINDINGS_PER_CLASS = 5

# xAI model IDs that look like "grok-X" or "grok-X.Y" — we sort them
# for flagship detection. Anything without that prefix is ignored by
# the flagship detector but still surfaces as new_model.
_GROK_PREFIX = "grok-"


@dataclass(frozen=True)
class ModelSignal:
    """One detected drift between the xAI catalog and MODEL_PRICING."""

    signal_class: str  # "new_model" | "removed_model" | "flagship_shift"
    model_id: str
    detail: dict


def _utc_now() -> datetime:
    """Return the current UTC time as a timezone-aware datetime."""
    return datetime.now(timezone.utc)


def _iso_window(window: timedelta) -> str:
    """Return an ISO-8601 string for ``now - window``."""
    return (_utc_now() - window).strftime("%Y-%m-%d %H:%M:%S")


def fetch_xai_models(
    api_key: str,
    *,
    base_url: str = XAI_BASE_URL,
    timeout: float = FETCH_TIMEOUT_SECONDS,
) -> list[str] | None:
    """Fetch the live model catalog from xAI ``/v1/models``.

    Returns the list of model IDs. Returns ``None`` on any error
    (network, HTTP != 200, malformed JSON). Callers should treat
    ``None`` as "could not determine current catalog, try again
    next cycle" — not as "catalog is empty."

    Response shape per xAI docs::

        {"object": "list", "data": [{"id": "grok-4.20-...", ...}, ...]}
    """
    url = f"{base_url.rstrip('/')}/models"
    req = urllib.request.Request(url, headers={"Authorization": f"Bearer {api_key}"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            if resp.status != 200:
                logger.debug("llm_model_watcher: HTTP %d from /v1/models", resp.status)
                return None
            body = resp.read(MAX_BYTES + 1)
            if len(body) > MAX_BYTES:
                logger.debug("llm_model_watcher: /v1/models response exceeded %d bytes", MAX_BYTES)
                return None
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        logger.debug("llm_model_watcher: fetch failed: %s", exc)
        return None

    try:
        payload = json.loads(body.decode("utf-8"))
    except (ValueError, UnicodeDecodeError) as exc:
        logger.debug("llm_model_watcher: JSON decode failed: %s", exc)
        return None

    data = payload.get("data")
    if not isinstance(data, list):
        logger.debug("llm_model_watcher: unexpected payload shape")
        return None

    ids: list[str] = []
    for entry in data:
        if isinstance(entry, dict):
            model_id = entry.get("id")
            if isinstance(model_id, str) and model_id:
                ids.append(model_id)
    return ids


def _detect_new_models(
    api_models: list[str],
    known_models: set[str],
) -> list[ModelSignal]:
    """Model appears on API but not in MODEL_PRICING."""
    signals: list[ModelSignal] = []
    for model_id in api_models:
        if model_id in known_models:
            continue
        signals.append(
            ModelSignal(
                signal_class="new_model",
                model_id=model_id,
                detail={
                    "known_model_count": len(known_models),
                    "api_model_count": len(api_models),
                },
            )
        )
    return signals


def _detect_removed_models(
    api_models: list[str],
    known_models: set[str],
) -> list[ModelSignal]:
    """Model in MODEL_PRICING but no longer on API."""
    api_set = set(api_models)
    signals: list[ModelSignal] = []
    for model_id in sorted(known_models):
        if model_id in api_set:
            continue
        signals.append(
            ModelSignal(
                signal_class="removed_model",
                model_id=model_id,
                detail={
                    "known_model_count": len(known_models),
                    "api_model_count": len(api_models),
                },
            )
        )
    return signals


def _detect_flagship_shift(
    api_models: list[str],
    current_best: str,
) -> list[ModelSignal]:
    """API lists a Grok model whose ID sorts higher than DEFAULT_BEST.

    String-sort is a heuristic, not a semver parse — but xAI IDs
    follow a stable ``grok-<major>.<minor>-<date>-<tier>`` shape
    where lexicographic sort is a reasonable proxy for "newer."
    If a name sorts above the current best, the operator should
    benchmark it and consider swapping DEFAULT_BEST.
    """
    candidates = [m for m in api_models if m.startswith(_GROK_PREFIX) and m > current_best]
    if not candidates:
        return []
    top = max(candidates)
    return [
        ModelSignal(
            signal_class="flagship_shift",
            model_id=top,
            detail={
                "current_best": current_best,
                "candidate": top,
                "all_candidates": sorted(candidates),
            },
        )
    ]


def _format_signal(s: ModelSignal) -> tuple[str, str, str]:
    """Render a ModelSignal into WHAT / SO WHAT / NOW WHAT strings."""
    if s.signal_class == "new_model":
        what = (
            f"WHAT: xAI catalog lists '{s.model_id}' but it's not in "
            f"core/llm_provider.py MODEL_PRICING."
        )
        so_what = (
            "SO WHAT: Nebula can't route calls to this model until it's "
            "added, so any efficiency/quality gains from the new model "
            "are unreachable."
        )
        now_what = (
            f"NOW WHAT: Look up pricing for '{s.model_id}' in the xAI "
            "console, add the (model_id, (input_$_per_1M, output_$_per_1M)) "
            "entry to MODEL_PRICING, and run benchmarks via an opt-in "
            "NEBULA_MODEL_BENCHMARK_OPT_IN=1 run before shifting "
            "DEFAULT_BEST or DEFAULT_CHEAPEST."
        )
        return what, so_what, now_what

    if s.signal_class == "removed_model":
        what = (
            f"WHAT: Model '{s.model_id}' is in MODEL_PRICING but no longer "
            "appears in the xAI /v1/models response."
        )
        so_what = (
            "SO WHAT: Routing to this model will fail with a 404 from xAI "
            "— any engine that pins it will silently drop calls through "
            "the circuit breaker."
        )
        now_what = (
            f"NOW WHAT: Confirm deprecation in the xAI console. If "
            f"retired, remove '{s.model_id}' from MODEL_PRICING and "
            "audit callers for hard-coded references via "
            f"`grep -rn '{s.model_id}' core/ domains/`."
        )
        return what, so_what, now_what

    if s.signal_class == "flagship_shift":
        current = s.detail.get("current_best", "?")
        what = (
            f"WHAT: xAI lists '{s.model_id}' — a model whose ID sorts "
            f"higher than DEFAULT_BEST ('{current}')."
        )
        so_what = (
            "SO WHAT: Nebula may be running the war-room synthesis on a "
            "stale flagship; a newer Grok could win on both quality and "
            "latency."
        )
        now_what = (
            f"NOW WHAT: Benchmark '{s.model_id}' against '{current}' "
            "using an opt-in NEBULA_MODEL_BENCHMARK_OPT_IN=1 run. If it "
            "wins on the oracle prompt set, update DEFAULT_BEST in "
            "core/llm_provider.py."
        )
        return what, so_what, now_what

    # Defensive fallback — shouldn't happen but avoids surfacing empty strings.
    return (
        f"WHAT: Unrecognized signal class '{s.signal_class}' for model '{s.model_id}'.",
        "SO WHAT: The watcher emitted a signal Nebula doesn't know how to render.",
        "NOW WHAT: Inspect llm_model_watcher._format_signal and the raw detail dict.",
    )


def _was_recently_emitted(
    conn,
    model_id: str,
    signal_class: str,
    cooldown_hours: int = COOLDOWN_HOURS,
) -> bool:
    """True when same (model_id, signal_class) was emitted in cooldown window."""
    cutoff = _iso_window(timedelta(hours=cooldown_hours))
    row = conn.execute(
        """
        SELECT 1 FROM evidence
        WHERE engine = 'llm_model_watcher'
          AND evidence_type = 'llm_model_signal'
          AND timestamp > ?
          AND raw_data LIKE ?
        LIMIT 1
        """,
        (cutoff, f'%"model_id": "{model_id}"%"signal_class": "{signal_class}"%'),
    ).fetchone()
    return row is not None


def run_llm_model_watcher(db_path: str = DEFAULT_DB) -> dict:
    """Entry point. Diffs xAI catalog against MODEL_PRICING, surfaces signals.

    Returns a summary dict::

        {
            "engine": "llm_model_watcher",
            "api_model_count": int,
            "known_model_count": int,
            "signals_detected": int,
            "by_class": {"new_model": int, "removed_model": int, "flagship_shift": int},
            "findings_persisted": int,
            "reason": Optional[str],  # set on no-op paths
        }

    Never raises. Network or DB errors degrade to the summary shape
    with ``reason`` set.
    """
    summary: dict = {
        "engine": "llm_model_watcher",
        "api_model_count": 0,
        "known_model_count": len(MODEL_PRICING),
        "signals_detected": 0,
        "by_class": {"new_model": 0, "removed_model": 0, "flagship_shift": 0},
        "findings_persisted": 0,
    }

    api_key = os.environ.get("XAI_API_KEY")
    if not api_key:
        summary["reason"] = "no_api_key"
        return summary

    api_models = fetch_xai_models(api_key)
    if api_models is None:
        summary["reason"] = "fetch_failed"
        return summary

    summary["api_model_count"] = len(api_models)
    known = set(MODEL_PRICING.keys())

    signals: list[ModelSignal] = []
    signals.extend(_detect_new_models(api_models, known)[:MAX_FINDINGS_PER_CLASS])
    signals.extend(_detect_removed_models(api_models, known)[:MAX_FINDINGS_PER_CLASS])
    signals.extend(_detect_flagship_shift(api_models, DEFAULT_BEST)[:MAX_FINDINGS_PER_CLASS])

    summary["signals_detected"] = len(signals)
    for sig in signals:
        summary["by_class"][sig.signal_class] += 1

    try:
        conn = connect(db_path)
    except (sqlite3.Error, OSError) as exc:
        logger.warning("llm_model_watcher: could not open DB: %s", exc)
        summary["reason"] = "db_unavailable"
        return summary

    try:
        for sig in signals:
            if _was_recently_emitted(conn, sig.model_id, sig.signal_class):
                continue
            what, so_what, now_what = _format_signal(sig)
            try:
                persist_finding(
                    domain="self_maintenance",
                    engine="llm_model_watcher",
                    evidence_type="llm_model_signal",
                    finding=f"{what} {so_what} {now_what}",
                    confidence=DEFAULT_CONFIDENCE,
                    source_repo="nebula",
                    source_file="core/llm_provider.py::MODEL_PRICING",
                    db_path=db_path,
                    tags=["llm_model", "self_audit", sig.signal_class],
                    raw_data={
                        "model_id": sig.model_id,
                        "signal_class": sig.signal_class,
                        **sig.detail,
                    },
                )
                summary["findings_persisted"] += 1
            except Exception as exc:  # pragma: no cover - defensive
                logger.warning(
                    "llm_model_watcher: failed to persist finding for %s/%s: %s",
                    sig.model_id,
                    sig.signal_class,
                    exc,
                )
    finally:
        try:
            conn.close()
        except (sqlite3.Error, AttributeError) as exc:
            logger.debug("llm_model_watcher: conn.close failed: %s", exc)

    return summary
