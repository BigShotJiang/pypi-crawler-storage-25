# SPDX-License-Identifier: MIT
"""Disagreement engine — surface contradictory peer findings (task #69).

Peer corroboration (``core/peer_corroboration.py``) catches the case
where two peers *agree* on a finding: they produce rows with the same
``content_hash`` and the Bayesian-combine path lifts overall confidence.

This engine catches the *opposite* case. Two peers looking at the same
source location (``source_file`` + ``source_line`` + ``source_commit``)
produce findings with **different** ``content_hash`` values — i.e. they
reach different conclusions about the same code. Corroboration doesn't
fire because the hashes don't match; the disagreement stays invisible
unless something surfaces it.

Disagreement is productive friction. When a trusted peer says "this
is a buffer overflow" and another equally-trusted peer says "this is
intentional fixed-width framing" on the exact same line, the operator
is the only one who can adjudicate. This engine raises that question
instead of letting it hide.

**Detection:**

1. Group ``evidence`` rows by ``(source_repo, source_file, source_line,
   source_commit)``. Rows lacking any of those fields are skipped — we
   only surface disagreements at precise code locations.
2. A group disagrees when:
   - ``COUNT(DISTINCT content_hash) >= 2`` (genuine divergence, not
     just corroboration)
   - ``COUNT(DISTINCT discoverer_peer_id) >= 2`` (two different
     peers, not one peer running the same scan twice)
3. For each disagreeing group, emit one ``peer_disagreement`` finding
   that summarizes the split and asks the operator to adjudicate.

**Discipline:**

- Read-only over ``evidence``. Never modifies existing findings.
- 24h cooldown per source location so a long-lived disagreement doesn't
  flood the war room across cycles.
- Confidence 0.50 — moderate, because the "is this really a
  disagreement?" judgment has enough nuance that the operator should
  review. Not a near-certainty like the deterministic signals from
  other self_maintenance engines.
- Tagged ``peer_disagreement`` + ``self_audit`` so war-room aggregation
  surfaces them under self-maintenance.
- Bounded emission: :data:`MAX_DISAGREEMENTS_PER_RUN`. A single bad
  peer or a code hot-spot with many engines scanning it could produce
  dozens; we surface a sample and rely on subsequent cycles to pick
  up the rest after the operator works through the first batch.

**Sibling engines:**

- ``core.peer_corroboration`` (v0.4.0) — the agree side.
- ``llm_cost_optimizer`` / ``api_awareness`` / ``todo_budget_monitor``
  — same telemetry-driven self-audit pattern, different signal.
"""

from __future__ import annotations

import logging
import sqlite3
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

from core.persist_to_db import DEFAULT_DB, persist_finding
from core.persistence import connect

logger = logging.getLogger(__name__)

WINDOW_DAYS = 30
MIN_PEERS_FOR_DISAGREEMENT = 2
MIN_DISTINCT_HASHES_FOR_DISAGREEMENT = 2
MAX_DISAGREEMENTS_PER_RUN = 10
COOLDOWN_HOURS = 24
DEFAULT_CONFIDENCE = 0.50


@dataclass(frozen=True)
class Disagreement:
    """One detected peer-disagreement at a source location."""

    source_repo: str
    source_file: str
    source_line: int
    source_commit: str
    detail: dict


def _utc_now() -> datetime:
    """Return the current UTC time as a timezone-aware datetime."""
    return datetime.now(timezone.utc)


def _iso_window(window: timedelta) -> str:
    """Return an ISO-8601 string for ``now - window``."""
    return (_utc_now() - window).strftime("%Y-%m-%d %H:%M:%S")


def _find_disagreements(conn, *, days: int = WINDOW_DAYS) -> list[Disagreement]:
    """Scan evidence for disagreeing peer findings.

    A disagreement = same source location, different content_hash
    values, different discoverer_peer_id values.
    """
    cutoff = _iso_window(timedelta(days=days))
    rows = conn.execute(
        """
        SELECT
            source_repo,
            source_file,
            source_line,
            source_commit,
            COUNT(DISTINCT content_hash) AS hash_count,
            COUNT(DISTINCT discoverer_peer_id) AS peer_count,
            GROUP_CONCAT(DISTINCT content_hash) AS hashes,
            GROUP_CONCAT(DISTINCT discoverer_peer_id) AS peers,
            GROUP_CONCAT(DISTINCT engine) AS engines
        FROM evidence
        WHERE timestamp > ?
          AND source_repo IS NOT NULL AND source_repo != ''
          AND source_file IS NOT NULL AND source_file != ''
          AND source_line IS NOT NULL
          AND source_commit IS NOT NULL AND source_commit != ''
          AND content_hash IS NOT NULL AND content_hash != ''
          AND discoverer_peer_id IS NOT NULL AND discoverer_peer_id != ''
        GROUP BY source_repo, source_file, source_line, source_commit
        HAVING hash_count >= ? AND peer_count >= ?
        ORDER BY hash_count DESC, peer_count DESC
        LIMIT ?
        """,
        (
            cutoff,
            MIN_DISTINCT_HASHES_FOR_DISAGREEMENT,
            MIN_PEERS_FOR_DISAGREEMENT,
            MAX_DISAGREEMENTS_PER_RUN,
        ),
    ).fetchall()

    out: list[Disagreement] = []
    for row in rows:
        repo, f, line, commit, n_hashes, n_peers, hashes, peers, engines = row
        out.append(
            Disagreement(
                source_repo=repo,
                source_file=f,
                source_line=int(line),
                source_commit=commit,
                detail={
                    "distinct_hashes": int(n_hashes),
                    "distinct_peers": int(n_peers),
                    "content_hashes": sorted(hashes.split(",")) if hashes else [],
                    "peers": sorted(peers.split(",")) if peers else [],
                    "engines": sorted(engines.split(",")) if engines else [],
                    "window_days": days,
                },
            )
        )
    return out


def _format_finding(d: Disagreement) -> tuple[str, str, str]:
    """Render WHAT / SO WHAT / NOW WHAT for a disagreement."""
    loc = f"{d.source_file}:{d.source_line}"
    what = (
        f"WHAT: {d.detail['distinct_peers']} peers produced "
        f"{d.detail['distinct_hashes']} different findings at "
        f"{loc} in {d.source_repo} (commit {d.source_commit[:12]}). "
        f"They agree on WHERE to look; they disagree on WHAT it means."
    )
    so_what = (
        "SO WHAT: Peer corroboration catches agreement and lifts "
        "confidence; disagreement is the inverse signal and it stays "
        "invisible unless something surfaces it. A trusted peer "
        "labelling a line as a security bug while another equally-"
        "trusted peer calls it intentional behavior is exactly the "
        "friction an operator needs to see. Silent disagreement means "
        "at least one of those peers is wrong and nobody's arbitrating."
    )
    peers_str = ", ".join(d.detail["peers"][:5])
    now_what = (
        f"NOW WHAT: Read the source at {loc} in commit "
        f"{d.source_commit[:12]}. Query the evidence table for the "
        f"conflicting findings: "
        f"`SELECT finding, engine, discoverer_peer_id, confidence "
        f"FROM evidence WHERE source_file = {d.source_file!r} AND "
        f"source_line = {d.source_line} AND source_commit = "
        f"{d.source_commit!r}`. Adjudicate: one side is right, the "
        f"other is wrong, or both are describing different aspects "
        f"of the same issue. Peers involved: {peers_str}."
    )
    return what, so_what, now_what


def _was_recently_emitted(
    conn,
    source_file: str,
    source_line: int,
    source_commit: str,
    cooldown_hours: int = COOLDOWN_HOURS,
) -> bool:
    """True when a disagreement at this location was emitted in cooldown window."""
    cutoff = _iso_window(timedelta(hours=cooldown_hours))
    row = conn.execute(
        """
        SELECT 1 FROM evidence
        WHERE engine = 'disagreement_engine'
          AND evidence_type = 'peer_disagreement'
          AND timestamp > ?
          AND source_file = ?
          AND source_line = ?
          AND source_commit = ?
        LIMIT 1
        """,
        (cutoff, source_file, source_line, source_commit),
    ).fetchone()
    return row is not None


def run_disagreement_engine(db_path: str = DEFAULT_DB) -> dict:
    """Entry point. Scan evidence for peer disagreements; surface as findings.

    Returns a summary dict::

        {
            "engine": "disagreement_engine",
            "locations_scanned": int,
            "disagreements_detected": int,
            "findings_persisted": int,
        }

    Never raises. DB errors degrade to an empty summary with ``reason``.
    """
    summary: dict = {
        "engine": "disagreement_engine",
        "locations_scanned": 0,
        "disagreements_detected": 0,
        "findings_persisted": 0,
    }

    try:
        conn = connect(db_path)
    except (sqlite3.Error, OSError) as exc:
        logger.warning("disagreement_engine: could not open DB: %s", exc)
        summary["reason"] = "db_unavailable"
        return summary

    try:
        try:
            disagreements = _find_disagreements(conn)
        except sqlite3.Error as exc:
            logger.debug("disagreement_engine: query failed: %s", exc)
            summary["reason"] = "query_failed"
            return summary

        summary["disagreements_detected"] = len(disagreements)

        for d in disagreements:
            if _was_recently_emitted(conn, d.source_file, d.source_line, d.source_commit):
                continue
            what, so_what, now_what = _format_finding(d)
            try:
                persist_finding(
                    domain="self_maintenance",
                    engine="disagreement_engine",
                    evidence_type="peer_disagreement",
                    finding=f"{what} {so_what} {now_what}",
                    confidence=DEFAULT_CONFIDENCE,
                    source_repo=d.source_repo,
                    source_file=d.source_file,
                    source_line=d.source_line,
                    source_commit=d.source_commit,
                    db_path=db_path,
                    tags=["peer_disagreement", "self_audit"],
                    raw_data={
                        "source_repo": d.source_repo,
                        "source_file": d.source_file,
                        "source_line": d.source_line,
                        "source_commit": d.source_commit,
                        **d.detail,
                    },
                )
                summary["findings_persisted"] += 1
            except Exception as exc:  # pragma: no cover - defensive
                logger.warning(
                    "disagreement_engine: persist failed for %s:%d — %s",
                    d.source_file,
                    d.source_line,
                    exc,
                )
    finally:
        try:
            conn.close()
        except (sqlite3.Error, AttributeError) as exc:
            logger.debug("disagreement_engine: conn.close failed: %s", exc)

    return summary
