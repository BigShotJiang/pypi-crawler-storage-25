# SPDX-License-Identifier: MIT
"""MCP server discovery — surfaces locally-configured MCP servers the
operator could wire into Nebula.

**Why this exists:** Nebula can consume MCP servers as providers
(:mod:`core.providers.mcp_consumer`), but operators typically already
have MCP servers configured for Claude Code / Cursor / other clients.
Re-declaring them in ``~/.config/nebula/providers.toml`` by hand is
friction that bleeds adoption. This engine walks the known MCP config
locations, parses every server declaration it finds, and surfaces
them as findings so the operator can enable the interesting ones with
one command.

**Paths walked (all optional, all read-only):**

1. ``$HOME/.claude/settings.json`` — Claude Code user settings.
2. ``$HOME/.cursor/mcp.json`` — Cursor's MCP config.
3. ``<workspace>/.mcp.json`` — project-level config Claude Code and
   Cursor both read.
4. Any path in the colon-separated ``NEBULA_MCP_DISCOVERY_PATHS`` env
   var (for operators whose tooling stores MCP configs elsewhere).

**Contract:**

- **Read-only.** This engine never modifies any config file and never
  enables a discovered server. Every finding tells the operator the
  exact CLI to run.
- **OPSEC-sanitized.** MCP configs routinely embed secrets in ``env``.
  This engine persists the server name, transport type (stdio/http),
  and a SHA-256 fingerprint of the command+args. It does NOT persist
  env contents, arguments, URLs with tokens, or anything from the
  config file beyond the name.
- **24h cooldown per (config_path, server_name).** A long-standing
  MCP config shouldn't produce a finding every cycle.
- **Hard cap at 10 findings per cycle.** If the operator has 30
  servers configured, surface 10 and let the next cycle pick up
  the rest.
- **Gracefully degrades.** Missing files / malformed JSON / permission
  errors never crash — they're swallowed and the summary reports
  the path as skipped with a reason.

Sibling to :mod:`api_awareness` (task #66 Phase D, already shipped)
and :mod:`api_suggester` (task #66 Phase D2, still pending).
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import sqlite3
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path

from core.persist_to_db import DEFAULT_DB, persist_finding
from core.persistence import connect
from core.workspace import workspace_root

logger = logging.getLogger(__name__)


# Tunables. Module-level so tests can monkeypatch without refactoring.
COOLDOWN_HOURS = 24
DEFAULT_CONFIDENCE = 0.50  # deterministic filesystem scan, mid-tier trust
MAX_FINDINGS_PER_CYCLE = 10
MAX_CONFIG_BYTES = 1 << 18  # 256 KB is plenty for a reasonable MCP config


@dataclass
class DiscoveredServer:
    """One MCP server entry found in a config file.

    ``command_fingerprint`` is a SHA-256 of (command, args) so the
    engine can detect command changes across runs without persisting
    the command itself.
    """

    name: str
    config_path: str
    transport: str  # "stdio" | "http" | "unknown"
    command_fingerprint: str


@dataclass
class ConfigScan:
    """Result of walking one config file."""

    path: str
    servers: list[DiscoveredServer] = field(default_factory=list)
    skipped_reason: str | None = None


def _iso_window(delta: timedelta) -> str:
    """Return the UTC timestamp ``delta`` in the past, ISO-formatted."""
    return (datetime.now(timezone.utc) - delta).strftime("%Y-%m-%dT%H:%M:%fZ")


def _fingerprint_command(command: str | None, args: list | None) -> str:
    """Deterministic hash of a server's invocation. Never logs the
    inputs — they can contain paths, tokens, or auth material."""
    h = hashlib.sha256()
    h.update((command or "").encode("utf-8"))
    for a in args or []:
        h.update(b"\x00")
        h.update(str(a).encode("utf-8"))
    return h.hexdigest()[:16]


def _classify_transport(entry: dict) -> str:
    """Best-effort transport classification for an MCP server entry.

    Handles both the 2024-11-05 schema (``command`` / ``args`` implies
    stdio; ``url`` implies http) and the early-2026 variant that adds
    an explicit ``type`` field. Returns ``"unknown"`` if neither shape
    is detectable — the engine still surfaces the server, it just
    can't describe the wire protocol."""
    explicit = entry.get("type") or entry.get("transport")
    if isinstance(explicit, str):
        lowered = explicit.lower()
        if lowered in {"stdio", "http", "sse", "websocket"}:
            return lowered
    if entry.get("url"):
        return "http"
    if entry.get("command"):
        return "stdio"
    return "unknown"


def _parse_config(path: Path) -> ConfigScan:
    """Read one MCP config file, return a scan with its servers.

    Handles both the top-level ``mcpServers`` key (Claude Code,
    Cursor, project-level ``.mcp.json``) and the alternate
    ``servers`` key some older configs use. Files that don't contain
    either key are reported as skipped with a reason, not treated as
    a failure.
    """
    scan = ConfigScan(path=str(path))
    try:
        if not path.exists():
            scan.skipped_reason = "not_found"
            return scan
        size = path.stat().st_size
        if size > MAX_CONFIG_BYTES:
            scan.skipped_reason = f"too_large ({size} bytes)"
            return scan
        raw = path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError) as exc:
        scan.skipped_reason = f"read_failed: {type(exc).__name__}"
        return scan

    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        scan.skipped_reason = f"parse_failed: line {exc.lineno}"
        return scan

    if not isinstance(data, dict):
        scan.skipped_reason = "root_not_object"
        return scan

    servers = data.get("mcpServers") or data.get("servers")
    if not isinstance(servers, dict):
        scan.skipped_reason = "no_mcp_servers_key"
        return scan

    for name, entry in servers.items():
        if not isinstance(entry, dict):
            continue
        scan.servers.append(
            DiscoveredServer(
                name=str(name),
                config_path=str(path),
                transport=_classify_transport(entry),
                command_fingerprint=_fingerprint_command(entry.get("command"), entry.get("args")),
            )
        )
    return scan


def _candidate_paths() -> list[Path]:
    """Build the candidate path list in precedence order.

    Operators can add custom paths via ``NEBULA_MCP_DISCOVERY_PATHS``
    (colon-separated, like ``$PATH``). The standard locations come
    after to match what the MCP ecosystem documents.
    """
    paths: list[Path] = []
    extra = os.environ.get("NEBULA_MCP_DISCOVERY_PATHS", "")
    for raw in extra.split(":"):
        raw = raw.strip()
        if raw:
            paths.append(Path(raw).expanduser())
    home = Path.home()
    paths.extend(
        [
            home / ".claude" / "settings.json",
            home / ".cursor" / "mcp.json",
        ]
    )
    ws = workspace_root()
    if ws is not None:
        paths.append(ws / ".mcp.json")
    return paths


def _was_recently_emitted(
    conn,
    config_path: str,
    server_name: str,
    cooldown_hours: int = COOLDOWN_HOURS,
) -> bool:
    """True when same (config_path, server_name) was emitted in window."""
    cutoff = _iso_window(timedelta(hours=cooldown_hours))
    row = conn.execute(
        """
        SELECT 1 FROM evidence
        WHERE engine = 'mcp_discovery'
          AND evidence_type = 'mcp_server_discovered'
          AND timestamp > ?
          AND raw_data LIKE ?
        LIMIT 1
        """,
        # NB: LIKE-pattern key order must match the raw_data dict
        # construction order below (server_name first, then config_path).
        # If that order ever changes, this pattern silently stops
        # matching and the cooldown loses all effect — classic bug class.
        (
            cutoff,
            f'%"server_name": "{server_name}"%"config_path": "{config_path}"%',
        ),
    ).fetchone()
    return row is not None


def _format_finding(server: DiscoveredServer) -> tuple[str, str, str]:
    """Render a DiscoveredServer into WHAT / SO WHAT / NOW WHAT."""
    transport_detail = server.transport if server.transport != "unknown" else "transport unknown"
    what = (
        f"WHAT: MCP server '{server.name}' ({transport_detail}) is configured "
        f"in {server.config_path} but not enabled as a Nebula provider."
    )
    so_what = (
        "SO WHAT: Nebula can consume MCP servers as providers via "
        "core.providers.mcp_consumer. Every server the operator has "
        "already vetted for another client is a zero-cost addition to "
        "Nebula's data-source roster — but only if declared in "
        "~/.config/nebula/providers.toml."
    )
    now_what = (
        f"NOW WHAT: If this server is useful to Nebula, copy the "
        f"configuration from {server.config_path} into "
        "~/.config/nebula/providers.toml under the [[providers.mcp]] "
        "block, then run `nebula providers reload`. If it's not useful, "
        "ignore the finding — this engine will re-surface in 24h."
    )
    return what, so_what, now_what


def run_mcp_discovery(db_path: str = DEFAULT_DB) -> dict:
    """Entry point. Walk MCP config paths, surface new servers as findings.

    Returns a summary dict::

        {
            "engine": "mcp_discovery",
            "paths_scanned": int,
            "paths_skipped": int,
            "servers_discovered": int,
            "findings_persisted": int,
            "skipped": {<path>: <reason>, ...},
            "reason": Optional[str],  # set on no-op paths
        }

    Never raises. Filesystem or DB errors degrade to the summary
    shape with ``reason`` set.
    """
    summary: dict = {
        "engine": "mcp_discovery",
        "paths_scanned": 0,
        "paths_skipped": 0,
        "servers_discovered": 0,
        "findings_persisted": 0,
        "skipped": {},
    }

    candidates = _candidate_paths()
    scans: list[ConfigScan] = []
    for path in candidates:
        scan = _parse_config(path)
        scans.append(scan)
        if scan.skipped_reason is None:
            summary["paths_scanned"] += 1
        else:
            summary["paths_skipped"] += 1
            summary["skipped"][str(path)] = scan.skipped_reason

    servers = [s for scan in scans for s in scan.servers]
    summary["servers_discovered"] = len(servers)

    if not servers:
        summary["reason"] = "no_servers_found"
        return summary

    try:
        conn = connect(db_path)
    except (sqlite3.Error, OSError) as exc:
        logger.warning("mcp_discovery: could not open DB: %s", exc)
        summary["reason"] = "db_unavailable"
        return summary

    try:
        emitted = 0
        for srv in servers:
            if emitted >= MAX_FINDINGS_PER_CYCLE:
                break
            if _was_recently_emitted(conn, srv.config_path, srv.name):
                continue
            what, so_what, now_what = _format_finding(srv)
            try:
                persist_finding(
                    domain="self_maintenance",
                    engine="mcp_discovery",
                    evidence_type="mcp_server_discovered",
                    finding=f"{what} {so_what} {now_what}",
                    confidence=DEFAULT_CONFIDENCE,
                    source_repo="nebula",
                    source_file="core/providers/mcp_consumer.py",
                    db_path=db_path,
                    tags=["mcp", "self_audit", "discovery"],
                    raw_data={
                        "server_name": srv.name,
                        "config_path": srv.config_path,
                        "transport": srv.transport,
                        "command_fingerprint": srv.command_fingerprint,
                    },
                )
                summary["findings_persisted"] += 1
                emitted += 1
            except Exception as exc:  # pragma: no cover - defensive
                logger.warning(
                    "mcp_discovery: failed to persist finding for %s@%s: %s",
                    srv.name,
                    srv.config_path,
                    exc,
                )
    finally:
        try:
            conn.close()
        except (sqlite3.Error, AttributeError) as exc:
            logger.debug("mcp_discovery: conn.close failed: %s", exc)

    return summary
