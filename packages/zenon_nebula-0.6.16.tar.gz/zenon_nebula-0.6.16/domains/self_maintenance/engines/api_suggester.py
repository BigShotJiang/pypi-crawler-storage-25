# SPDX-License-Identifier: MIT
"""API suggester — LLM-backed provider-gap detector.

**Why this exists:** Nebula's provider roster starts minimal and grows
as the operator wires in new APIs. But operators don't always know
which APIs would fill their blind spots — they see findings from the
providers they *have*, not what they're *missing*. This engine closes
the gap by asking the LLM: "given what's active, what's failing, and
which domains are starved, what should I look into next?"

Gated on ``XAI_API_KEY``. Without the key, the engine returns a no-op
summary (like every other LLM-gated engine). Proposals surface as
WHAT / SO WHAT / NOW WHAT findings at low confidence (0.30) so they
enter the war room as suggestions, never action items.

**Contract:**

- Detection-only. **Never** auto-installs a provider. The operator
  reads the finding and decides.
- 24h cooldown per suggestion domain (e.g., "blockchain API") so the
  same gap doesn't flood the war room.
- Hard cap: at most 3 proposals per cycle.
- Cost-bounded: one LLM call per cycle, using the cheapest available
  model (``DEFAULT_CHEAPEST``).
- Graceful degradation: missing key → no-op; LLM error → no-op;
  empty telemetry → no-op with reason.

Part of task #66 Phase D (the third and final sub-engine, alongside
:mod:`api_awareness` and :mod:`mcp_discovery`).
"""

from __future__ import annotations

import json
import logging
import os
import sqlite3
from datetime import datetime, timedelta, timezone

from core.persist_to_db import DEFAULT_DB, persist_finding
from core.persistence import connect

logger = logging.getLogger(__name__)

COOLDOWN_HOURS = 24
DEFAULT_CONFIDENCE = 0.30  # LLM-generated suggestion, not verified
MAX_PROPOSALS_PER_CYCLE = 3


def _iso_window(delta: timedelta) -> str:
    return (datetime.now(timezone.utc) - delta).strftime("%Y-%m-%dT%H:%M:%fZ")


def _get_active_providers(conn) -> list[str]:
    """Names of providers that logged at least one call in the last 7 days."""
    cutoff = _iso_window(timedelta(days=7))
    rows = conn.execute(
        "SELECT DISTINCT provider_name FROM api_call_log WHERE timestamp > ? ORDER BY provider_name",
        (cutoff,),
    ).fetchall()
    return [r[0] for r in rows]


def _get_failing_providers(conn) -> list[dict]:
    """Providers with >20% error rate in the last 24h."""
    cutoff = _iso_window(timedelta(hours=24))
    rows = conn.execute(
        """
        SELECT provider_name,
               COUNT(*) AS total,
               SUM(CASE WHEN status != 'ok' THEN 1 ELSE 0 END) AS errors
        FROM api_call_log
        WHERE timestamp > ?
        GROUP BY provider_name
        HAVING total >= 5 AND (CAST(errors AS REAL) / total) > 0.2
        ORDER BY (CAST(errors AS REAL) / total) DESC
        """,
        (cutoff,),
    ).fetchall()
    return [{"name": r[0], "total": r[1], "errors": r[2]} for r in rows]


def _get_starved_domains(conn) -> list[str]:
    """Domains with zero evidence in the last 7 days."""
    cutoff = _iso_window(timedelta(days=7))
    all_rows = conn.execute("SELECT DISTINCT domain FROM evidence").fetchall()
    all_domains = {r[0] for r in all_rows}
    recent_rows = conn.execute(
        "SELECT DISTINCT domain FROM evidence WHERE timestamp > ?",
        (cutoff,),
    ).fetchall()
    recent_domains = {r[0] for r in recent_rows}
    starved = sorted(all_domains - recent_domains)
    return starved


def _was_recently_suggested(conn, suggestion_domain: str) -> bool:
    cutoff = _iso_window(timedelta(hours=COOLDOWN_HOURS))
    row = conn.execute(
        """
        SELECT 1 FROM evidence
        WHERE engine = 'api_suggester'
          AND evidence_type = 'api_suggestion'
          AND timestamp > ?
          AND raw_data LIKE ?
        LIMIT 1
        """,
        (cutoff, f'%"suggestion_domain": "{suggestion_domain}"%'),
    ).fetchone()
    return row is not None


def _build_prompt(
    active: list[str],
    failing: list[dict],
    starved: list[str],
) -> str:
    active_str = ", ".join(active[:20]) if active else "(none)"
    failing_str = (
        "; ".join(f"{f['name']} ({f['errors']}/{f['total']} errors)" for f in failing[:5])
        if failing
        else "(none)"
    )
    starved_str = ", ".join(starved[:10]) if starved else "(none)"

    return f"""You are Nebula's API advisor. Given the operator's current state, suggest 1-3 new external APIs or data sources they should consider adding to improve coverage.

Current active providers (last 7d): {active_str}
Failing providers (>20% error rate, last 24h): {failing_str}
Domains with zero evidence in last 7d: {starved_str}

For each suggestion, respond in this exact JSON format (array of objects):
[
  {{
    "suggestion_domain": "short category like 'blockchain_explorer' or 'market_data'",
    "api_name": "specific API or service name",
    "reason": "one sentence on what gap this fills",
    "setup_hint": "one sentence on how to wire it in (URL, auth type, etc.)"
  }}
]

Rules:
- Only suggest publicly available APIs with free tiers or reasonable pricing.
- Don't suggest APIs the operator already has (check the active providers list).
- Focus on gaps: if a domain is starved, suggest an API that feeds it.
- If everything looks healthy and well-covered, return an empty array [].
- Maximum 3 suggestions."""


def _parse_suggestions(raw: str) -> list[dict]:
    """Extract the JSON array from the LLM response. Tolerant of markdown fences."""
    text = raw.strip()
    if text.startswith("```"):
        lines = text.splitlines()
        text = "\n".join(lines[1:])
        if text.rstrip().endswith("```"):
            text = text.rstrip()[:-3]
    try:
        data = json.loads(text.strip())
    except json.JSONDecodeError:
        return []
    if not isinstance(data, list):
        return []
    return [d for d in data if isinstance(d, dict) and "suggestion_domain" in d][
        :MAX_PROPOSALS_PER_CYCLE
    ]


def run_api_suggester(db_path: str = DEFAULT_DB) -> dict:
    """Entry point. Proposes new APIs to fill coverage gaps.

    Returns a summary dict. Never raises.
    """
    summary: dict = {
        "engine": "api_suggester",
        "active_providers": 0,
        "failing_providers": 0,
        "starved_domains": 0,
        "suggestions_proposed": 0,
        "findings_persisted": 0,
    }

    api_key = os.environ.get("XAI_API_KEY")
    if not api_key:
        summary["reason"] = "no_api_key"
        return summary

    try:
        conn = connect(db_path)
    except (sqlite3.Error, OSError) as exc:
        logger.warning("api_suggester: DB unavailable: %s", exc)
        summary["reason"] = "db_unavailable"
        return summary

    try:
        active = _get_active_providers(conn)
        failing = _get_failing_providers(conn)
        starved = _get_starved_domains(conn)
    except sqlite3.OperationalError as exc:
        logger.debug("api_suggester: query failed (table missing?): %s", exc)
        summary["reason"] = "query_failed"
        try:
            conn.close()
        except (sqlite3.Error, AttributeError):
            logger.debug("api_suggester: conn.close failed")
        return summary

    summary["active_providers"] = len(active)
    summary["failing_providers"] = len(failing)
    summary["starved_domains"] = len(starved)

    if not active and not starved:
        summary["reason"] = "no_telemetry"
        try:
            conn.close()
        except (sqlite3.Error, AttributeError):
            logger.debug("api_suggester: conn.close failed")
        return summary

    prompt = _build_prompt(active, failing, starved)

    try:
        from core.llm_provider import call_llm

        response = call_llm(
            prompt,
            purpose="api_suggester",
            db_path=db_path,
        )
    except Exception as exc:
        logger.warning("api_suggester: LLM call failed: %s", exc)
        summary["reason"] = "llm_failed"
        try:
            conn.close()
        except (sqlite3.Error, AttributeError):
            logger.debug("api_suggester: conn.close failed")
        return summary

    suggestions = _parse_suggestions(response)
    summary["suggestions_proposed"] = len(suggestions)

    try:
        for s in suggestions:
            domain = s.get("suggestion_domain", "unknown")
            if _was_recently_suggested(conn, domain):
                continue
            api_name = s.get("api_name", "?")
            reason = s.get("reason", "")
            hint = s.get("setup_hint", "")
            what = f"WHAT: Consider adding '{api_name}' ({domain}) as a Nebula provider."
            so_what = f"SO WHAT: {reason}"
            now_what = f"NOW WHAT: {hint} Add to ~/.config/nebula/providers.toml, then run `nebula providers reload`."
            try:
                persist_finding(
                    domain="self_maintenance",
                    engine="api_suggester",
                    evidence_type="api_suggestion",
                    finding=f"{what} {so_what} {now_what}",
                    confidence=DEFAULT_CONFIDENCE,
                    source_repo="nebula",
                    source_file="core/providers/",
                    db_path=db_path,
                    tags=["api_suggestion", "self_audit", domain],
                    raw_data={
                        "suggestion_domain": domain,
                        "api_name": api_name,
                        "reason": reason,
                        "setup_hint": hint,
                    },
                )
                summary["findings_persisted"] += 1
            except Exception as exc:
                logger.warning("api_suggester: persist failed for %s: %s", api_name, exc)
    finally:
        try:
            conn.close()
        except (sqlite3.Error, AttributeError):
            logger.debug("api_suggester: conn.close failed")

    return summary
