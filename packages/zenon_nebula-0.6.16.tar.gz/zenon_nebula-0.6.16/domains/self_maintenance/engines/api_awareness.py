# SPDX-License-Identifier: MIT
"""API awareness — deterministic anomaly detection over the api_call_log.

**Why this exists:** Nebula's providers (GitHub, blockchain explorers,
market-data APIs, RPC nodes, MCP servers) silently degrade. Rate
limits tighten, response shapes drift, endpoints disappear. A
provider that worked yesterday and returns 5xx today should be
flagged before its findings start corrupting hypotheses.

The :mod:`core.api_telemetry` module persists every provider call to
the ``api_call_log`` table. This engine reads that table on a rolling
window and applies four deterministic checks:

1. **Error-rate spike** — the provider's recent error rate is
   significantly higher than its baseline (default: >10% recent vs
   <2% baseline over 30 days).
2. **Latency drift** — the provider's recent p95 latency is more
   than 2x its 30-day baseline.
3. **Schema-hash drift** — the provider's most-recent
   ``response_schema_hash`` differs from every hash it returned in
   the prior 30 days. Suggests an API contract change.
4. **Sudden disappearance** — the provider averaged >10 calls/day
   for 30 days, then dropped to zero in the last 24h.

Findings are persisted at confidence 0.75 (deterministic detection,
high signal) tagged ``api_health`` + ``self_audit`` so the war room
surfaces them under the self-maintenance bucket.

**Design discipline:**

- Pure SQL + math. No LLM. No network. Reads only.
- Cooldown: same anomaly class on the same provider only emits one
  finding per 24h to avoid flooding the war room when a provider is
  consistently broken.
- Hard cap: at most 5 findings per cycle per anomaly class.
- Graceful degradation: missing table → empty summary; empty table →
  empty summary; corrupt rows → silently skipped.

**Companion engines (planned):**

- ``api_suggester`` (also task #66) — opt-in LLM engine that proposes
  new APIs to investigate when an existing one is degrading.
- ``llm_cost_optimizer`` (task #94) — same shape but for LLM
  cost-per-finding rather than provider health.
"""

from __future__ import annotations

import logging
import sqlite3
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path

from core.persist_to_db import DEFAULT_DB, persist_finding
from core.persistence import connect

logger = logging.getLogger(__name__)

REPO_ROOT = Path(__file__).resolve().parents[3]

# Detection thresholds. All exposed as module constants so tests
# can monkeypatch them without touching the engine logic.
ERROR_RATE_RECENT_HOURS = 72
ERROR_RATE_BASELINE_DAYS = 30
ERROR_RATE_RECENT_THRESHOLD = 0.10  # 10% recent error rate
ERROR_RATE_BASELINE_CEILING = 0.02  # baseline must stay under 2%
ERROR_RATE_MIN_RECENT_CALLS = 20  # avoid noise from low-volume providers

LATENCY_BASELINE_DAYS = 30
LATENCY_RECENT_HOURS = 72
LATENCY_DRIFT_FACTOR = 2.0  # recent p95 must be 2x the baseline p95
LATENCY_MIN_RECENT_CALLS = 20

SCHEMA_DRIFT_RECENT_HOURS = 24
SCHEMA_DRIFT_BASELINE_DAYS = 30

DISAPPEARANCE_BASELINE_DAYS = 30
DISAPPEARANCE_RECENT_HOURS = 24
DISAPPEARANCE_MIN_BASELINE_CALLS_PER_DAY = 10.0

DEFAULT_CONFIDENCE = 0.75

# Hard caps on findings per cycle per anomaly class — protects the
# war room from getting flooded when a provider is consistently broken.
MAX_FINDINGS_PER_CLASS = 5

# Cooldown: an anomaly of the same class on the same provider isn't
# re-surfaced within this window.
COOLDOWN_HOURS = 24


@dataclass(frozen=True)
class Anomaly:
    """One detected API health anomaly.

    Used as the canonical shape passed to ``_format_*`` helpers.
    """

    provider_name: str
    anomaly_class: str  # "error_rate" | "latency" | "schema" | "disappearance"
    detail: dict


def _utc_now() -> datetime:
    """Return the current UTC time as a timezone-aware datetime."""
    return datetime.now(timezone.utc)


def _iso_window(window: timedelta) -> str:
    """Return an ISO-8601 string for ``now - window``."""
    return (_utc_now() - window).strftime("%Y-%m-%dT%H:%M:%fZ")


def _detect_error_rate_spikes(conn) -> list[Anomaly]:
    """Find providers whose recent error rate exceeds the threshold.

    Returns at most :data:`MAX_FINDINGS_PER_CLASS` anomalies, sorted
    by recent-error-rate descending so the worst offenders win.
    """
    recent_cutoff = _iso_window(timedelta(hours=ERROR_RATE_RECENT_HOURS))
    baseline_cutoff = _iso_window(timedelta(days=ERROR_RATE_BASELINE_DAYS))

    rows = conn.execute(
        """
        SELECT
            provider_name,
            SUM(CASE WHEN status != 'ok' AND timestamp > ? THEN 1 ELSE 0 END) AS recent_errors,
            SUM(CASE WHEN timestamp > ? THEN 1 ELSE 0 END) AS recent_calls,
            SUM(CASE WHEN status != 'ok' AND timestamp > ? AND timestamp <= ? THEN 1 ELSE 0 END) AS baseline_errors,
            SUM(CASE WHEN timestamp > ? AND timestamp <= ? THEN 1 ELSE 0 END) AS baseline_calls
        FROM api_call_log
        WHERE timestamp > ?
        GROUP BY provider_name
        """,
        (
            recent_cutoff,
            recent_cutoff,
            baseline_cutoff,
            recent_cutoff,
            baseline_cutoff,
            recent_cutoff,
            baseline_cutoff,
        ),
    ).fetchall()

    anomalies: list[Anomaly] = []
    for row in rows:
        provider, recent_err, recent_calls, base_err, base_calls = row
        if (recent_calls or 0) < ERROR_RATE_MIN_RECENT_CALLS:
            continue
        recent_rate = (recent_err or 0) / max(recent_calls or 1, 1)
        baseline_rate = (base_err or 0) / max(base_calls or 1, 1)
        if (
            recent_rate >= ERROR_RATE_RECENT_THRESHOLD
            and baseline_rate < ERROR_RATE_BASELINE_CEILING
        ):
            anomalies.append(
                Anomaly(
                    provider_name=provider,
                    anomaly_class="error_rate",
                    detail={
                        "recent_rate": round(recent_rate, 4),
                        "baseline_rate": round(baseline_rate, 4),
                        "recent_calls": recent_calls,
                        "recent_errors": recent_err,
                        "window_hours": ERROR_RATE_RECENT_HOURS,
                    },
                )
            )
    anomalies.sort(key=lambda a: -a.detail["recent_rate"])
    return anomalies[:MAX_FINDINGS_PER_CLASS]


def _detect_latency_drift(conn) -> list[Anomaly]:
    """Find providers whose recent p95 latency exceeds 2x the baseline."""
    recent_cutoff = _iso_window(timedelta(hours=LATENCY_RECENT_HOURS))
    baseline_cutoff = _iso_window(timedelta(days=LATENCY_BASELINE_DAYS))

    rows = conn.execute(
        """
        SELECT provider_name, latency_ms, timestamp
        FROM api_call_log
        WHERE timestamp > ? AND status = 'ok'
        ORDER BY provider_name, timestamp
        """,
        (baseline_cutoff,),
    ).fetchall()

    by_provider_recent: dict[str, list[int]] = defaultdict(list)
    by_provider_baseline: dict[str, list[int]] = defaultdict(list)
    for provider, latency, ts in rows:
        if not provider:
            continue
        if ts > recent_cutoff:
            by_provider_recent[provider].append(latency or 0)
        else:
            by_provider_baseline[provider].append(latency or 0)

    anomalies: list[Anomaly] = []
    for provider, recent_latencies in by_provider_recent.items():
        if len(recent_latencies) < LATENCY_MIN_RECENT_CALLS:
            continue
        baseline_latencies = by_provider_baseline.get(provider, [])
        if len(baseline_latencies) < LATENCY_MIN_RECENT_CALLS:
            continue
        recent_p95 = _percentile(recent_latencies, 95)
        baseline_p95 = _percentile(baseline_latencies, 95)
        if baseline_p95 == 0:
            continue
        if recent_p95 / baseline_p95 >= LATENCY_DRIFT_FACTOR:
            anomalies.append(
                Anomaly(
                    provider_name=provider,
                    anomaly_class="latency",
                    detail={
                        "recent_p95_ms": int(recent_p95),
                        "baseline_p95_ms": int(baseline_p95),
                        "factor": round(recent_p95 / baseline_p95, 2),
                        "recent_calls": len(recent_latencies),
                    },
                )
            )
    anomalies.sort(key=lambda a: -a.detail["factor"])
    return anomalies[:MAX_FINDINGS_PER_CLASS]


def _detect_schema_drift(conn) -> list[Anomaly]:
    """Find providers whose recent schema hash isn't in the baseline set."""
    recent_cutoff = _iso_window(timedelta(hours=SCHEMA_DRIFT_RECENT_HOURS))
    baseline_cutoff = _iso_window(timedelta(days=SCHEMA_DRIFT_BASELINE_DAYS))

    rows = conn.execute(
        """
        SELECT provider_name, response_schema_hash, timestamp
        FROM api_call_log
        WHERE timestamp > ?
          AND response_schema_hash IS NOT NULL
          AND response_schema_hash != ''
        """,
        (baseline_cutoff,),
    ).fetchall()

    recent_hashes: dict[str, set[str]] = defaultdict(set)
    baseline_hashes: dict[str, set[str]] = defaultdict(set)
    for provider, sha, ts in rows:
        if not provider or not sha:
            continue
        if ts > recent_cutoff:
            recent_hashes[provider].add(sha)
        else:
            baseline_hashes[provider].add(sha)

    anomalies: list[Anomaly] = []
    for provider, recent in recent_hashes.items():
        baseline = baseline_hashes.get(provider, set())
        if not baseline:
            continue
        new_hashes = recent - baseline
        if new_hashes:
            anomalies.append(
                Anomaly(
                    provider_name=provider,
                    anomaly_class="schema",
                    detail={
                        "new_hashes": sorted(new_hashes),
                        "baseline_hash_count": len(baseline),
                        "window_hours": SCHEMA_DRIFT_RECENT_HOURS,
                    },
                )
            )
    return anomalies[:MAX_FINDINGS_PER_CLASS]


def _detect_disappearance(conn) -> list[Anomaly]:
    """Find providers that were active 30 days but went silent in 24h."""
    recent_cutoff = _iso_window(timedelta(hours=DISAPPEARANCE_RECENT_HOURS))
    baseline_cutoff = _iso_window(timedelta(days=DISAPPEARANCE_BASELINE_DAYS))

    rows = conn.execute(
        """
        SELECT
            provider_name,
            SUM(CASE WHEN timestamp > ? THEN 1 ELSE 0 END) AS recent_calls,
            SUM(CASE WHEN timestamp > ? AND timestamp <= ? THEN 1 ELSE 0 END) AS baseline_calls
        FROM api_call_log
        WHERE timestamp > ?
        GROUP BY provider_name
        """,
        (recent_cutoff, baseline_cutoff, recent_cutoff, baseline_cutoff),
    ).fetchall()

    anomalies: list[Anomaly] = []
    baseline_days = DISAPPEARANCE_BASELINE_DAYS
    for provider, recent, baseline in rows:
        baseline_per_day = (baseline or 0) / max(baseline_days, 1)
        if (recent or 0) == 0 and baseline_per_day >= DISAPPEARANCE_MIN_BASELINE_CALLS_PER_DAY:
            anomalies.append(
                Anomaly(
                    provider_name=provider,
                    anomaly_class="disappearance",
                    detail={
                        "baseline_calls_per_day": round(baseline_per_day, 1),
                        "recent_calls_24h": 0,
                    },
                )
            )
    anomalies.sort(key=lambda a: -a.detail["baseline_calls_per_day"])
    return anomalies[:MAX_FINDINGS_PER_CLASS]


def _percentile(values: list[int], pct: float) -> float:
    """Return the *pct* percentile of *values*. Empty input returns 0."""
    if not values:
        return 0.0
    ordered = sorted(values)
    k = max(0, min(len(ordered) - 1, round(pct / 100.0 * (len(ordered) - 1))))
    return float(ordered[k])


def _format_anomaly(a: Anomaly) -> tuple[str, str, str]:
    """Render an Anomaly as WHAT / SO WHAT / NOW WHAT text."""
    if a.anomaly_class == "error_rate":
        what = (
            f"Provider `{a.provider_name}` had a "
            f"{a.detail['recent_rate']:.0%} error rate in the last "
            f"{a.detail['window_hours']}h "
            f"({a.detail['recent_errors']}/{a.detail['recent_calls']} calls), "
            f"vs a baseline of {a.detail['baseline_rate']:.1%}."
        )
        so_what = (
            "Engines depending on this provider are producing degraded findings."
            " Either the provider is rate-limiting us or its endpoint contract changed."
        )
        now_what = (
            f"Run `nebula providers diagnose {a.provider_name}` to inspect the "
            f"recent error sample. If rate-limited, check the provider's auth "
            f"env var. If contract drift, the schema-drift detector likely fired too."
        )
    elif a.anomaly_class == "latency":
        what = (
            f"Provider `{a.provider_name}` p95 latency is "
            f"{a.detail['recent_p95_ms']}ms (last 72h), "
            f"{a.detail['factor']}x the baseline of "
            f"{a.detail['baseline_p95_ms']}ms."
        )
        so_what = (
            "Engines making sequential calls to this provider take 2x+ as long "
            "to produce findings. Cycle budget overruns become more likely; "
            "low-priority engines start getting cooldowned."
        )
        now_what = (
            "Check whether the provider added new heavy endpoints or whether "
            "the workspace grew (more repos = more parallel calls). If the "
            "latency is unexpected, file an issue with the provider."
        )
    elif a.anomaly_class == "schema":
        first_hash = a.detail["new_hashes"][0] if a.detail["new_hashes"] else ""
        what = (
            f"Provider `{a.provider_name}` returned "
            f"{len(a.detail['new_hashes'])} new response schema hash(es) "
            f"in the last {a.detail['window_hours']}h that never appeared in "
            f"the prior 30 days (e.g. {first_hash[:8]}...)."
        )
        so_what = (
            "The provider's response shape changed. Engines parsing this "
            "shape may be silently producing wrong findings — every field "
            "they read could now be at a different path or missing entirely."
        )
        now_what = (
            f"Diff a recent response from `{a.provider_name}` against a "
            f"month-old sample. If fields renamed, update the provider's "
            f"wrapper. If fields added, no change needed but worth noting."
        )
    elif a.anomaly_class == "disappearance":
        what = (
            f"Provider `{a.provider_name}` averaged "
            f"{a.detail['baseline_calls_per_day']} calls/day for 30 days, "
            f"then went silent in the last 24h."
        )
        so_what = (
            "Either every engine that uses this provider stopped running, "
            "or the provider returned an unrecoverable error and the "
            "engines are silently degrading. Engines that produced findings "
            "from this provider have effectively lost their data source."
        )
        now_what = (
            f"Check engine_health metrics for engines that listed "
            f"`{a.provider_name}` as a required API. If they're skipping "
            f"due to auth failure, the provider's credentials may have expired."
        )
    else:  # pragma: no cover — defensive
        what = f"Unknown anomaly class {a.anomaly_class!r} on provider {a.provider_name!r}"
        so_what = "Engine bug — anomaly class not handled in _format_anomaly."
        now_what = "File a bug report against api_awareness."
    return what, so_what, now_what


def _was_recently_emitted(
    conn,
    provider: str,
    anomaly_class: str,
    cooldown_hours: int = COOLDOWN_HOURS,
) -> bool:
    """Return True when the same anomaly class for the same provider was
    emitted within ``cooldown_hours``. Prevents flooding the war room
    when a provider is consistently broken.
    """
    cutoff = _iso_window(timedelta(hours=cooldown_hours))
    row = conn.execute(
        """
        SELECT 1 FROM evidence
        WHERE engine = 'api_awareness'
          AND evidence_type = 'api_health_anomaly'
          AND timestamp > ?
          AND raw_data LIKE ?
        LIMIT 1
        """,
        (cutoff, f'%"provider": "{provider}"%"anomaly_class": "{anomaly_class}"%'),
    ).fetchone()
    return row is not None


def run_api_awareness(db_path: str = DEFAULT_DB) -> dict:
    """Entry point. Walks api_call_log, surfaces health anomalies.

    Returns a summary dict suitable for logging:

    .. code-block:: python

        {
            "engine": "api_awareness",
            "anomalies_detected": int,
            "by_class": {
                "error_rate": int,
                "latency": int,
                "schema": int,
                "disappearance": int,
            },
            "findings_persisted": int,
        }

    Never raises. SQL errors (table missing, etc.) degrade to an
    empty summary.
    """
    summary = {
        "engine": "api_awareness",
        "anomalies_detected": 0,
        "by_class": {
            "error_rate": 0,
            "latency": 0,
            "schema": 0,
            "disappearance": 0,
        },
        "findings_persisted": 0,
    }

    try:
        conn = connect(db_path)
    except Exception as exc:
        logger.warning("api_awareness: could not open DB: %s", exc)
        return summary

    try:
        all_anomalies: list[Anomaly] = []
        try:
            all_anomalies.extend(_detect_error_rate_spikes(conn))
        except Exception as exc:
            logger.debug("api_awareness: error_rate detector failed: %s", exc)
        try:
            all_anomalies.extend(_detect_latency_drift(conn))
        except Exception as exc:
            logger.debug("api_awareness: latency detector failed: %s", exc)
        try:
            all_anomalies.extend(_detect_schema_drift(conn))
        except Exception as exc:
            logger.debug("api_awareness: schema detector failed: %s", exc)
        try:
            all_anomalies.extend(_detect_disappearance(conn))
        except Exception as exc:
            logger.debug("api_awareness: disappearance detector failed: %s", exc)

        summary["anomalies_detected"] = len(all_anomalies)
        for a in all_anomalies:
            summary["by_class"][a.anomaly_class] += 1

        for a in all_anomalies:
            if _was_recently_emitted(conn, a.provider_name, a.anomaly_class):
                continue
            what, so_what, now_what = _format_anomaly(a)
            try:
                persist_finding(
                    domain="self_maintenance",
                    engine="api_awareness",
                    evidence_type="api_health_anomaly",
                    finding=f"{what} {so_what} {now_what}",
                    confidence=DEFAULT_CONFIDENCE,
                    source_repo="nebula",
                    source_file="data/engine.db::api_call_log",
                    db_path=db_path,
                    tags=["api_health", "self_audit", a.anomaly_class],
                    raw_data={
                        "provider": a.provider_name,
                        "anomaly_class": a.anomaly_class,
                        **a.detail,
                    },
                )
                summary["findings_persisted"] += 1
            except Exception as exc:  # pragma: no cover - defensive
                logger.warning(
                    "api_awareness: failed to persist finding for %s/%s: %s",
                    a.provider_name,
                    a.anomaly_class,
                    exc,
                )
    finally:
        try:
            conn.close()
        except (sqlite3.Error, AttributeError) as exc:
            logger.debug("api_awareness: conn.close failed: %s", exc)

    return summary
