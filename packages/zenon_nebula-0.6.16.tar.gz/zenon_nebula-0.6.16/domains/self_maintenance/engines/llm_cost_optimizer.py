# SPDX-License-Identifier: MIT
"""LLM cost optimizer — value-per-dollar feedback loop over LLM spend.

**Why this exists:** every LLM call is logged to ``cost_tracking``
(provider, model, module, cost_usd, tokens). Every finding is logged
to ``evidence`` (domain, engine). This engine joins them to compute
**findings-per-dollar per (engine, model)** pairs and surfaces three
classes of optimization signal:

1. **Cost outliers** — engines whose cost-per-finding is more than
   :data:`OUTLIER_FACTOR` (default 5x) the median across engines.
   Recommendation: switch to a cheaper model, batch calls, or trim
   the prompt.
2. **Stagnant spend** — engines that consumed >$X in the last N days
   but produced zero findings. Either degraded silently or running
   on a model that can't answer their question.
3. **Model arbitrage** — when the same engine has historical data on
   two models, surface the one with better findings/$ ratio.

Sibling to :mod:`api_awareness` (task #66) — same telemetry-driven
pattern, different signal. Both are pure SQL + math, no LLM, no
network.

**Discipline:**

- Read-only. Never modifies cost_tracking, never makes LLM calls.
- 24h cooldown per (engine, signal_class) pair to avoid flooding the
  war room when a particular engine stays expensive across cycles.
- Hard cap at :data:`MAX_FINDINGS_PER_CLASS` per cycle per signal
  class so an outage doesn't dump 50 findings at once.
- Findings persisted at confidence 0.70 (deterministic but the
  "switch to model Y" recommendation involves judgment, so slightly
  below api_awareness's 0.75).
- Tagged ``cost_efficiency`` + ``self_audit`` + ``<signal_class>``
  so war room aggregation surfaces them under self-maintenance.

**Companion engines:**

- ``api_awareness`` (task #66) — same shape, provider health side.
- ``llm_model_watcher`` (task #92) — detects new Grok models on the
  xAI side; pairs with model arbitrage findings here.
"""

from __future__ import annotations

import logging
import sqlite3
import statistics
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path

from core.persist_to_db import DEFAULT_DB, persist_finding
from core.persistence import connect

logger = logging.getLogger(__name__)

REPO_ROOT = Path(__file__).resolve().parents[3]

# Detection windows + thresholds. Module constants so tests can
# monkeypatch without touching engine logic.
WINDOW_DAYS = 7
MIN_CALLS_FOR_OUTLIER = 5
MIN_COST_USD_FOR_STAGNANT = 0.50
OUTLIER_FACTOR = 5.0  # cost-per-finding ratio vs median to trigger
ARBITRAGE_FACTOR = 2.0  # model A's findings/$ must be 2x model B's
MIN_FINDINGS_FOR_ARBITRAGE = 3  # require enough samples to be meaningful

DEFAULT_CONFIDENCE = 0.70
MAX_FINDINGS_PER_CLASS = 5
COOLDOWN_HOURS = 24


@dataclass(frozen=True)
class CostSignal:
    """One detected cost-efficiency anomaly.

    Used as the canonical shape passed to the formatter.
    """

    signal_class: str  # "outlier" | "stagnant" | "arbitrage"
    engine_name: str
    detail: dict


def _utc_now() -> datetime:
    """Return the current UTC time as a timezone-aware datetime."""
    return datetime.now(timezone.utc)


def _iso_window(window: timedelta) -> str:
    """Return an ISO-8601 string for ``now - window``."""
    return (_utc_now() - window).strftime("%Y-%m-%d %H:%M:%S")


def _engine_costs(conn, *, days: int = WINDOW_DAYS) -> dict[str, dict]:
    """Aggregate cost_tracking rows by engine over the last *days*.

    Returns a dict::

        {
            "engine_name": {
                "calls": int,
                "cost_usd": float,
                "tokens_input": int,
                "tokens_output": int,
                "models": set[str],
            }, ...
        }

    The ``module`` column on ``cost_tracking`` holds the engine name.
    Empty/null modules are bucketed as ``"_unattributed"`` so the
    operator can spot when calls aren't being attributed at all.
    """
    cutoff = _iso_window(timedelta(days=days))
    rows = conn.execute(
        """
        SELECT
            COALESCE(NULLIF(module, ''), '_unattributed') AS engine,
            model,
            COUNT(*) AS calls,
            SUM(cost_usd) AS cost_usd,
            SUM(tokens_input) AS tokens_input,
            SUM(tokens_output) AS tokens_output
        FROM cost_tracking
        WHERE timestamp > ?
        GROUP BY engine, model
        """,
        (cutoff,),
    ).fetchall()

    result: dict[str, dict] = {}
    for engine, model, calls, cost, tin, tout in rows:
        bucket = result.setdefault(
            engine,
            {
                "calls": 0,
                "cost_usd": 0.0,
                "tokens_input": 0,
                "tokens_output": 0,
                "models": set(),
                "by_model": {},
            },
        )
        bucket["calls"] += calls or 0
        bucket["cost_usd"] += cost or 0.0
        bucket["tokens_input"] += tin or 0
        bucket["tokens_output"] += tout or 0
        if model:
            bucket["models"].add(model)
            bucket["by_model"][model] = {
                "calls": calls or 0,
                "cost_usd": cost or 0.0,
            }
    return result


def _engine_finding_counts(conn, *, days: int = WINDOW_DAYS) -> dict[str, int]:
    """Count distinct findings per engine over the last *days*."""
    cutoff = _iso_window(timedelta(days=days))
    rows = conn.execute(
        """
        SELECT engine, COUNT(*) AS finding_count
        FROM evidence
        WHERE timestamp > ? AND engine IS NOT NULL AND engine != ''
        GROUP BY engine
        """,
        (cutoff,),
    ).fetchall()
    return dict(rows)


def _detect_outliers(
    costs: dict[str, dict],
    findings: dict[str, int],
) -> list[CostSignal]:
    """Engines whose cost-per-finding is far above the median.

    Skips engines below :data:`MIN_CALLS_FOR_OUTLIER` (low-volume
    noise) and engines with zero findings (those go through the
    stagnant detector instead).
    """
    cost_per_finding: dict[str, float] = {}
    for engine, bucket in costs.items():
        if bucket["calls"] < MIN_CALLS_FOR_OUTLIER:
            continue
        finding_count = findings.get(engine, 0)
        if finding_count == 0:
            continue
        cost_per_finding[engine] = bucket["cost_usd"] / finding_count

    if len(cost_per_finding) < 3:
        # Median needs at least a handful of data points to mean
        # anything. Below that, outlier detection is noise.
        return []

    median_cpf = statistics.median(cost_per_finding.values())
    if median_cpf <= 0:
        return []

    signals: list[CostSignal] = []
    for engine, cpf in cost_per_finding.items():
        if cpf >= median_cpf * OUTLIER_FACTOR:
            signals.append(
                CostSignal(
                    signal_class="outlier",
                    engine_name=engine,
                    detail={
                        "cost_per_finding": round(cpf, 4),
                        "median_cost_per_finding": round(median_cpf, 4),
                        "ratio": round(cpf / median_cpf, 2),
                        "total_cost_usd": round(costs[engine]["cost_usd"], 4),
                        "finding_count": findings.get(engine, 0),
                        "calls": costs[engine]["calls"],
                        "models": sorted(costs[engine]["models"]),
                        "window_days": WINDOW_DAYS,
                    },
                )
            )
    signals.sort(key=lambda s: -s.detail["ratio"])
    return signals[:MAX_FINDINGS_PER_CLASS]


def _detect_stagnant_spend(
    costs: dict[str, dict],
    findings: dict[str, int],
) -> list[CostSignal]:
    """Engines that spent >MIN_COST_USD but produced zero findings."""
    signals: list[CostSignal] = []
    for engine, bucket in costs.items():
        if bucket["cost_usd"] < MIN_COST_USD_FOR_STAGNANT:
            continue
        finding_count = findings.get(engine, 0)
        if finding_count > 0:
            continue
        signals.append(
            CostSignal(
                signal_class="stagnant",
                engine_name=engine,
                detail={
                    "cost_usd": round(bucket["cost_usd"], 4),
                    "calls": bucket["calls"],
                    "tokens_input": bucket["tokens_input"],
                    "tokens_output": bucket["tokens_output"],
                    "models": sorted(bucket["models"]),
                    "window_days": WINDOW_DAYS,
                },
            )
        )
    signals.sort(key=lambda s: -s.detail["cost_usd"])
    return signals[:MAX_FINDINGS_PER_CLASS]


def _detect_model_arbitrage(
    costs: dict[str, dict],
    findings: dict[str, int],
) -> list[CostSignal]:
    """When an engine ran on multiple models, surface the cheapest-per-finding.

    Only fires when the engine has enough findings on each model to
    make the comparison meaningful.
    """
    signals: list[CostSignal] = []
    for engine, bucket in costs.items():
        finding_count = findings.get(engine, 0)
        if finding_count < MIN_FINDINGS_FOR_ARBITRAGE:
            continue
        if len(bucket["models"]) < 2:
            continue

        # We have per-model call counts but the evidence table doesn't
        # tell us which model produced which finding. Approximate by
        # assuming findings are produced proportional to calls — same
        # finding-rate per call on each model. This is a lower bound
        # on the real arbitrage signal but stays deterministic.
        total_calls = bucket["calls"]
        if total_calls == 0:
            continue

        per_model: dict[str, dict] = {}
        for model, m_data in bucket["by_model"].items():
            est_findings = finding_count * (m_data["calls"] / total_calls)
            if est_findings <= 0:
                continue
            per_model[model] = {
                "calls": m_data["calls"],
                "cost_usd": m_data["cost_usd"],
                "est_findings": est_findings,
                "est_cost_per_finding": m_data["cost_usd"] / est_findings,
            }
        if len(per_model) < 2:
            continue

        sorted_models = sorted(per_model.items(), key=lambda kv: kv[1]["est_cost_per_finding"])
        cheapest_name, cheapest = sorted_models[0]
        priciest_name, priciest = sorted_models[-1]
        if cheapest["est_cost_per_finding"] <= 0:
            continue
        ratio = priciest["est_cost_per_finding"] / cheapest["est_cost_per_finding"]
        if ratio < ARBITRAGE_FACTOR:
            continue
        signals.append(
            CostSignal(
                signal_class="arbitrage",
                engine_name=engine,
                detail={
                    "cheapest_model": cheapest_name,
                    "cheapest_cost_per_finding": round(cheapest["est_cost_per_finding"], 4),
                    "priciest_model": priciest_name,
                    "priciest_cost_per_finding": round(priciest["est_cost_per_finding"], 4),
                    "savings_ratio": round(ratio, 2),
                    "finding_count": finding_count,
                    "window_days": WINDOW_DAYS,
                },
            )
        )
    signals.sort(key=lambda s: -s.detail["savings_ratio"])
    return signals[:MAX_FINDINGS_PER_CLASS]


def _format_signal(s: CostSignal) -> tuple[str, str, str]:
    """Render a CostSignal as WHAT / SO WHAT / NOW WHAT text."""
    if s.signal_class == "outlier":
        what = (
            f"Engine `{s.engine_name}` cost ${s.detail['cost_per_finding']}/finding "
            f"over the last {s.detail['window_days']}d, "
            f"{s.detail['ratio']}x the median of "
            f"${s.detail['median_cost_per_finding']}/finding across engines. "
            f"Total spend: ${s.detail['total_cost_usd']} for "
            f"{s.detail['finding_count']} findings on "
            f"{s.detail['calls']} calls."
        )
        so_what = (
            "Engines should produce findings at roughly comparable rates per "
            "dollar. A 5x+ outlier means either the prompt is bloated, the "
            "model is overkill, or the engine is filtering too aggressively "
            "and discarding responses."
        )
        models = ", ".join(s.detail["models"]) or "(unknown)"
        now_what = (
            f"Inspect `{s.engine_name}`'s prompt + post-processing. Current "
            f"model(s): {models}. Try a cheaper model in core.model_router "
            f"and compare findings/$ over the next 7 days."
        )
    elif s.signal_class == "stagnant":
        what = (
            f"Engine `{s.engine_name}` spent ${s.detail['cost_usd']} on "
            f"{s.detail['calls']} LLM calls in the last "
            f"{s.detail['window_days']}d but produced zero findings."
        )
        so_what = (
            "The engine is silently degrading. Either the LLM keeps refusing "
            "to commit to an answer (over-aggressive plausibility gate), the "
            "model lacks the knowledge, or the engine's post-processing is "
            "discarding every response."
        )
        models = ", ".join(s.detail["models"]) or "(unknown)"
        now_what = (
            f"Run `nebula findings --engine {s.engine_name} --recent 7d` to "
            f"confirm zero output. Check engine_health for the same engine. "
            f"Models seen: {models}. May need a prompt rewrite or a different "
            f"model tier."
        )
    elif s.signal_class == "arbitrage":
        what = (
            f"Engine `{s.engine_name}` ran on multiple models in the last "
            f"{s.detail['window_days']}d. `{s.detail['cheapest_model']}` "
            f"produced findings at ~${s.detail['cheapest_cost_per_finding']}/finding, "
            f"vs `{s.detail['priciest_model']}` at "
            f"~${s.detail['priciest_cost_per_finding']}/finding "
            f"({s.detail['savings_ratio']}x ratio)."
        )
        so_what = (
            "Switching the engine's primary model to the cheaper option "
            "preserves output volume and slashes spend. Estimated based on "
            "pro-rated finding attribution — verify with a controlled "
            "comparison before pinning."
        )
        now_what = (
            f"Update `core.model_router` to route `{s.engine_name}` to "
            f"`{s.detail['cheapest_model']}` by default. Re-evaluate after "
            f"the next 7 days of telemetry."
        )
    else:  # pragma: no cover — defensive
        what = f"Unknown cost-signal class {s.signal_class!r}"
        so_what = "Engine bug — class not handled in _format_signal."
        now_what = "File a bug against llm_cost_optimizer."
    return what, so_what, now_what


def _was_recently_emitted(
    conn,
    engine: str,
    signal_class: str,
    cooldown_hours: int = COOLDOWN_HOURS,
) -> bool:
    """True when same (engine, signal_class) was emitted in cooldown window."""
    cutoff = _iso_window(timedelta(hours=cooldown_hours))
    row = conn.execute(
        """
        SELECT 1 FROM evidence
        WHERE engine = 'llm_cost_optimizer'
          AND evidence_type = 'cost_efficiency_signal'
          AND timestamp > ?
          AND raw_data LIKE ?
        LIMIT 1
        """,
        (cutoff, f'%"engine_name": "{engine}"%"signal_class": "{signal_class}"%'),
    ).fetchone()
    return row is not None


def run_llm_cost_optimizer(db_path: str = DEFAULT_DB) -> dict:
    """Entry point. Joins cost_tracking + evidence, surfaces signals.

    Returns a summary dict suitable for logging:

    .. code-block:: python

        {
            "engine": "llm_cost_optimizer",
            "engines_analyzed": int,
            "signals_detected": int,
            "by_class": {"outlier": int, "stagnant": int, "arbitrage": int},
            "findings_persisted": int,
        }

    Never raises. SQL errors degrade to an empty summary.
    """
    summary = {
        "engine": "llm_cost_optimizer",
        "engines_analyzed": 0,
        "signals_detected": 0,
        "by_class": {"outlier": 0, "stagnant": 0, "arbitrage": 0},
        "findings_persisted": 0,
    }

    try:
        conn = connect(db_path)
    except Exception as exc:
        logger.warning("llm_cost_optimizer: could not open DB: %s", exc)
        return summary

    try:
        try:
            costs = _engine_costs(conn)
            findings = _engine_finding_counts(conn)
        except Exception as exc:
            logger.debug("llm_cost_optimizer: aggregation failed: %s", exc)
            return summary

        summary["engines_analyzed"] = len(costs)

        signals: list[CostSignal] = []
        try:
            signals.extend(_detect_outliers(costs, findings))
        except Exception as exc:
            logger.debug("llm_cost_optimizer: outlier detector failed: %s", exc)
        try:
            signals.extend(_detect_stagnant_spend(costs, findings))
        except Exception as exc:
            logger.debug("llm_cost_optimizer: stagnant detector failed: %s", exc)
        try:
            signals.extend(_detect_model_arbitrage(costs, findings))
        except Exception as exc:
            logger.debug("llm_cost_optimizer: arbitrage detector failed: %s", exc)

        summary["signals_detected"] = len(signals)
        for sig in signals:
            summary["by_class"][sig.signal_class] += 1

        for sig in signals:
            if _was_recently_emitted(conn, sig.engine_name, sig.signal_class):
                continue
            what, so_what, now_what = _format_signal(sig)
            try:
                # Convert sets to sorted lists for JSON serialization
                detail_json = {
                    k: sorted(v) if isinstance(v, set) else v for k, v in sig.detail.items()
                }
                persist_finding(
                    domain="self_maintenance",
                    engine="llm_cost_optimizer",
                    evidence_type="cost_efficiency_signal",
                    finding=f"{what} {so_what} {now_what}",
                    confidence=DEFAULT_CONFIDENCE,
                    source_repo="nebula",
                    source_file="data/engine.db::cost_tracking+evidence",
                    db_path=db_path,
                    tags=["cost_efficiency", "self_audit", sig.signal_class],
                    raw_data={
                        "engine_name": sig.engine_name,
                        "signal_class": sig.signal_class,
                        **detail_json,
                    },
                )
                summary["findings_persisted"] += 1
            except Exception as exc:  # pragma: no cover - defensive
                logger.warning(
                    "llm_cost_optimizer: failed to persist finding for %s/%s: %s",
                    sig.engine_name,
                    sig.signal_class,
                    exc,
                )
    finally:
        try:
            conn.close()
        except (sqlite3.Error, AttributeError) as exc:
            logger.debug("llm_cost_optimizer: conn.close failed: %s", exc)

    return summary
