# SPDX-License-Identifier: MIT
"""Todo-budget monitor — alarm when tech-debt allowlists fail to shrink.

**Why this exists:** Nebula has several allowlists used by test-smoke files
(``UNREACHABLE_ENGINES_ALLOWLIST``, ``SUBPROCESS_NO_TIMEOUT_ALLOWLIST``,
``URLOPEN_NO_TIMEOUT_ALLOWLIST``, ``EVAL_EXEC_ALLOWLIST``,
``PICKLE_ALLOWLIST``) plus a growing population of ``TODO`` / ``FIXME`` /
``XXX`` comments. Each entry is a tech-debt IOU. Traditional regression
gates catch "this got worse from pass to fail"; they miss "this should
have shrunk by now but didn't."

This engine closes that gap. Every cycle it:

1. Counts TODOs across ``core/``, ``domains/``, ``scripts/`` (test TODOs
   are tolerated as they usually mark intentional holes).
2. Counts members of each named allowlist in ``tests/`` via AST.
3. Writes the snapshot into the ``todo_budget`` table.
4. Compares the current snapshot to the previous one and surfaces
   findings when a source grew or failed to shrink after N
   consecutive snapshots.

Pure AST + grep, zero LLM calls. Matches the pattern established by
``codebase_improvement_auditor`` (task #93), ``llm_cost_optimizer`` (#94),
``llm_model_watcher`` (#92), ``api_awareness`` (#66) — telemetry-driven
self-audit.

**Discipline:**

- Read-only against source. Never modifies TODOs or allowlists.
- 24h cooldown per (source, signal_class) to avoid flood when a source
  stays at the same level across many cycles.
- Confidence 0.70 (deterministic detection; the "should have shrunk"
  judgment is soft).
- Soft-warn only: no CI gate in this phase. After the allowlists have
  trended down for a couple of releases, a follow-up PR can flip the
  signal from advisory to blocking.

Future phases (tracked under task #86):

- Detect ``TODO(#N)`` where the referenced issue is closed on GitHub.
  Requires rate-limited API access + caching; defer until the Phase E
  universal_http lands (task #67).
- Cross-check allowlists against their intended-to-shrink counterparts
  (``UNREACHABLE_ENGINES_ALLOWLIST`` should shrink as engines are wired
  into ``decide_next_action`` rotation).
"""

from __future__ import annotations

import ast
import logging
import re
import sqlite3
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path

from core.persist_to_db import DEFAULT_DB, persist_finding
from core.persistence import connect

logger = logging.getLogger(__name__)

REPO_ROOT = Path(__file__).resolve().parents[3]

# Module-level SCHEMA_SQL picked up by core/schema_registry.py at boot.
# New table owned by this engine; no cross-domain consumers, so it lives
# here rather than core/persistence/schema.py.
SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS todo_budget (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    source TEXT NOT NULL,
    count INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_todo_budget_source_time
    ON todo_budget(source, timestamp DESC);
"""

# Scope directories for TODO scanning. `tests/` is excluded because many
# test-file TODOs mark intentional coverage gaps the operator hasn't
# gotten to — we don't want to double-count them against the budget.
_TODO_SCOPE_DIRS = ("core", "domains", "scripts")

# Regex that matches TODO / FIXME / XXX comments in Python source. Looks
# for the token at a word boundary, followed by `(` or `:` or a space,
# so we skip mentions in docstrings that happen to contain the word.
_TODO_PATTERN = re.compile(r"(?<!\w)(TODO|FIXME|XXX)(?:\(|:|\s)")

# Allowlists we track. Each entry names the file + the variable name.
# The engine parses the file's AST and counts members of the matching
# set / list / frozenset literal. New allowlists can be registered by
# extending this list — they start showing up in findings on the next
# cycle after a snapshot is written.
_ALLOWLIST_TARGETS: list[tuple[str, str]] = [
    ("tests/test_autonomous_cycle_smoke.py", "UNREACHABLE_ENGINES_ALLOWLIST"),
    ("tests/test_attack_vector_smoke.py", "SUBPROCESS_NO_TIMEOUT_ALLOWLIST"),
    ("tests/test_attack_vector_smoke.py", "URLOPEN_NO_TIMEOUT_ALLOWLIST"),
    ("tests/test_attack_vector_smoke.py", "EVAL_EXEC_ALLOWLIST"),
    ("tests/test_attack_vector_smoke.py", "PICKLE_ALLOWLIST"),
]

# Tunables. Module constants so tests can monkeypatch.
COOLDOWN_HOURS = 24
DEFAULT_CONFIDENCE = 0.70
STAGNATION_THRESHOLD_SNAPSHOTS = 5  # flag after N snapshots without shrinkage


@dataclass(frozen=True)
class BudgetSignal:
    """One detected budget-growth or stagnation signal."""

    signal_class: str  # "grew" | "stagnant"
    source: str  # e.g. "todo:core" or "allowlist:UNREACHABLE_ENGINES_ALLOWLIST"
    detail: dict


def _utc_now() -> datetime:
    """Return the current UTC time as a timezone-aware datetime."""
    return datetime.now(timezone.utc)


def _iso_window(window: timedelta) -> str:
    """Return an ISO-8601 string for ``now - window``."""
    return (_utc_now() - window).strftime("%Y-%m-%d %H:%M:%S")


def _count_todos(repo_root: Path | None = None) -> dict[str, int]:
    """Return ``{source: count}`` for TODO/FIXME/XXX across scoped dirs."""
    root = repo_root or REPO_ROOT
    counts: dict[str, int] = {}
    for scope_dir in _TODO_SCOPE_DIRS:
        scope = root / scope_dir
        if not scope.is_dir():
            counts[f"todo:{scope_dir}"] = 0
            continue
        total = 0
        for py_path in scope.rglob("*.py"):
            try:
                text = py_path.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            total += len(_TODO_PATTERN.findall(text))
        counts[f"todo:{scope_dir}"] = total
    return counts


def _count_allowlist_members(
    file_path: Path,
    variable_name: str,
) -> int | None:
    """Parse ``file_path`` via AST; return the number of elements in the
    set/list/frozenset/tuple literal assigned to ``variable_name``.

    Returns ``None`` when the file, variable, or literal shape isn't
    found — callers should treat that as "skip this cycle" rather than
    zero, since a missing file could mean the test suite was restructured
    and the allowlist moved (a zero would falsely trigger a "shrank to 0"
    congratulation on the next run).
    """
    if not file_path.is_file():
        return None
    try:
        tree = ast.parse(file_path.read_text(encoding="utf-8"))
    except (OSError, SyntaxError) as exc:
        logger.debug("todo_budget_monitor: cannot parse %s — %s", file_path, exc)
        return None
    for node in ast.walk(tree):
        if not isinstance(node, ast.Assign):
            continue
        for target in node.targets:
            if isinstance(target, ast.Name) and target.id == variable_name:
                return _count_collection_elements(node.value)
            # Handle annotated pattern too (e.g. `NAME: set[str] = {...}`)
        if (
            isinstance(node, ast.Assign)
            and isinstance(node.value, ast.Call)
            and isinstance(node.value.func, ast.Name)
            and node.value.func.id == "set"
            and not node.value.args
        ):
            # `set()` → size 0
            return 0
    # AnnAssign (annotated) case
    for node in ast.walk(tree):
        if (
            isinstance(node, ast.AnnAssign)
            and isinstance(node.target, ast.Name)
            and node.target.id == variable_name
            and node.value is not None
        ):
            return _count_collection_elements(node.value)
    return None


def _count_collection_elements(expr: ast.expr) -> int | None:
    """Count elements in a literal collection expression."""
    if isinstance(expr, (ast.Set, ast.List, ast.Tuple)):
        return len(expr.elts)
    if (
        isinstance(expr, ast.Call)
        and isinstance(expr.func, ast.Name)
        and expr.func.id in ("set", "frozenset", "list", "tuple")
    ):
        if not expr.args:
            return 0
        inner = expr.args[0]
        if isinstance(inner, (ast.Set, ast.List, ast.Tuple)):
            return len(inner.elts)
    return None


def _count_allowlists(repo_root: Path | None = None) -> dict[str, int]:
    """Return ``{source: count}`` for every configured allowlist."""
    root = repo_root or REPO_ROOT
    out: dict[str, int] = {}
    for rel_path, var_name in _ALLOWLIST_TARGETS:
        n = _count_allowlist_members(root / rel_path, var_name)
        if n is not None:
            out[f"allowlist:{var_name}"] = n
    return out


def _snapshot_all(repo_root: Path | None = None) -> dict[str, int]:
    """Combined current-cycle snapshot across TODOs + allowlists."""
    out = _count_todos(repo_root)
    out.update(_count_allowlists(repo_root))
    return out


def _persist_snapshot(conn, snapshot: dict[str, int]) -> None:
    """Write the current snapshot into ``todo_budget``."""
    for source, count in snapshot.items():
        conn.execute(
            "INSERT INTO todo_budget (source, count) VALUES (?, ?)",
            (source, count),
        )
    conn.commit()


def _recent_history(
    conn,
    source: str,
    *,
    limit: int = STAGNATION_THRESHOLD_SNAPSHOTS,
) -> list[int]:
    """Return the most recent counts for ``source``, newest first."""
    rows = conn.execute(
        """
        SELECT count FROM todo_budget
        WHERE source = ?
        ORDER BY timestamp DESC
        LIMIT ?
        """,
        (source, limit),
    ).fetchall()
    return [row[0] for row in rows]


def _detect_signals(
    current: dict[str, int],
    previous: dict[str, list[int]],
) -> list[BudgetSignal]:
    """Compare current snapshot vs recent history; surface growth + stagnation."""
    signals: list[BudgetSignal] = []
    for source, now in current.items():
        history = previous.get(source, [])
        # `history[0]` is the second-most-recent entry because the current
        # snapshot is written BEFORE this comparison runs. Callers pass
        # history from BEFORE the write.
        if not history:
            continue
        last = history[0]
        if now > last:
            signals.append(
                BudgetSignal(
                    signal_class="grew",
                    source=source,
                    detail={
                        "previous": last,
                        "current": now,
                        "delta": now - last,
                        "history": history,
                    },
                )
            )
            continue
        # Stagnation: no shrinkage across STAGNATION_THRESHOLD_SNAPSHOTS.
        # Only flag once we actually have that many historical points to
        # compare against — otherwise a fresh DB with 1 point would fire
        # every cycle.
        if len(history) >= STAGNATION_THRESHOLD_SNAPSHOTS - 1 and all(h <= now for h in history):
            signals.append(
                BudgetSignal(
                    signal_class="stagnant",
                    source=source,
                    detail={
                        "current": now,
                        "history": history,
                        "snapshots_without_shrink": len(history) + 1,
                    },
                )
            )
    return signals


def _format_signal(s: BudgetSignal) -> tuple[str, str, str]:
    """Render WHAT / SO WHAT / NOW WHAT strings from a BudgetSignal."""
    if s.signal_class == "grew":
        prev = s.detail["previous"]
        now = s.detail["current"]
        delta = s.detail["delta"]
        what = (
            f"WHAT: Budget source {s.source!r} grew from {prev} to {now} "
            f"(+{delta}) since the previous snapshot."
        )
        so_what = (
            "SO WHAT: Every entry on a tech-debt allowlist or TODO is an "
            "IOU against future work. Growth without a corresponding "
            "paydown means the system is accumulating debt faster than it "
            "sheds it. Over enough cycles this compounds into the kind of "
            "stale-test / dead-engine drift the v0.6.x work has been "
            "mechanically closing."
        )
        now_what = (
            "NOW WHAT: Look at what was added since the last cycle (`git "
            "log -p -- <file>`). If the new entry is a deliberate IOU "
            "with a task ID, that's fine — record the task ID in a "
            "comment so future auditors can match it back. If the entry "
            "slipped in without a tracker, either fix the underlying "
            "issue now or file a task and annotate the IOU."
        )
        return what, so_what, now_what

    if s.signal_class == "stagnant":
        now = s.detail["current"]
        snapshots = s.detail["snapshots_without_shrink"]
        what = (
            f"WHAT: Budget source {s.source!r} has held at {now} for "
            f"{snapshots} consecutive snapshots without shrinking."
        )
        so_what = (
            "SO WHAT: The point of a tech-debt allowlist is to trend "
            "toward zero. A source that never shrinks has quietly been "
            "promoted from 'living TODO' to 'load-bearing exemption' — "
            "the same anti-pattern that produced the v0.3.2 "
            "UNREACHABLE_ENGINES_ALLOWLIST drift of 47 entries that "
            "task #84 later had to chase back to zero."
        )
        now_what = (
            f"NOW WHAT: Pick ONE entry on {s.source!r} this cycle and "
            "resolve it. Either fix the underlying issue and remove the "
            "exemption, or split the entry into a tracked task with a "
            "deadline. The engine will auto-resolve this finding on the "
            "next cycle once the count drops."
        )
        return what, so_what, now_what

    return (
        f"WHAT: Unrecognized signal class {s.signal_class!r} for {s.source!r}.",
        "SO WHAT: The monitor emitted a signal the formatter doesn't know.",
        "NOW WHAT: Inspect todo_budget_monitor._format_signal and the raw detail.",
    )


def _was_recently_emitted(
    conn,
    source: str,
    signal_class: str,
    cooldown_hours: int = COOLDOWN_HOURS,
) -> bool:
    """True when same (source, signal_class) was emitted in cooldown window."""
    cutoff = _iso_window(timedelta(hours=cooldown_hours))
    row = conn.execute(
        """
        SELECT 1 FROM evidence
        WHERE engine = 'todo_budget_monitor'
          AND evidence_type = 'todo_budget_signal'
          AND timestamp > ?
          AND raw_data LIKE ?
        LIMIT 1
        """,
        (cutoff, f'%"source": "{source}"%"signal_class": "{signal_class}"%'),
    ).fetchone()
    return row is not None


def run_todo_budget_monitor(
    db_path: str = DEFAULT_DB,
    *,
    repo_root: Path | None = None,
) -> dict:
    """Entry point. Snapshot current budgets + detect growth / stagnation.

    Returns a summary dict::

        {
            "engine": "todo_budget_monitor",
            "sources_tracked": int,
            "signals_detected": int,
            "by_class": {"grew": int, "stagnant": int},
            "findings_persisted": int,
        }

    Never raises. DB errors degrade to an empty summary with ``reason``
    set; scan errors on individual files are logged and skipped.
    """
    summary: dict = {
        "engine": "todo_budget_monitor",
        "sources_tracked": 0,
        "signals_detected": 0,
        "by_class": {"grew": 0, "stagnant": 0},
        "findings_persisted": 0,
    }

    try:
        current = _snapshot_all(repo_root=repo_root)
    except Exception as exc:  # pragma: no cover - defensive
        logger.warning("todo_budget_monitor: snapshot failed: %s", exc)
        summary["reason"] = "snapshot_failed"
        return summary

    summary["sources_tracked"] = len(current)
    if not current:
        summary["reason"] = "empty_snapshot"
        return summary

    try:
        conn = connect(db_path)
    except (sqlite3.Error, OSError) as exc:
        logger.warning("todo_budget_monitor: could not open DB: %s", exc)
        summary["reason"] = "db_unavailable"
        return summary

    try:
        # Gather history BEFORE writing the new snapshot so comparisons
        # compare against the previous cycle, not today's row.
        history = {source: _recent_history(conn, source) for source in current}

        try:
            _persist_snapshot(conn, current)
        except sqlite3.Error as exc:
            logger.debug("todo_budget_monitor: snapshot persist failed: %s", exc)

        signals = _detect_signals(current, history)
        summary["signals_detected"] = len(signals)
        for sig in signals:
            summary["by_class"][sig.signal_class] = summary["by_class"].get(sig.signal_class, 0) + 1

        for sig in signals:
            if _was_recently_emitted(conn, sig.source, sig.signal_class):
                continue
            what, so_what, now_what = _format_signal(sig)
            try:
                persist_finding(
                    domain="self_maintenance",
                    engine="todo_budget_monitor",
                    evidence_type="todo_budget_signal",
                    finding=f"{what} {so_what} {now_what}",
                    confidence=DEFAULT_CONFIDENCE,
                    source_repo="nebula",
                    source_file="data/engine.db::todo_budget",
                    db_path=db_path,
                    tags=["code_quality", "self_audit", sig.signal_class],
                    raw_data={
                        "source": sig.source,
                        "signal_class": sig.signal_class,
                        **sig.detail,
                    },
                )
                summary["findings_persisted"] += 1
            except Exception as exc:  # pragma: no cover - defensive
                logger.warning(
                    "todo_budget_monitor: failed to persist finding for %s/%s: %s",
                    sig.source,
                    sig.signal_class,
                    exc,
                )
    finally:
        try:
            conn.close()
        except (sqlite3.Error, AttributeError) as exc:
            logger.debug("todo_budget_monitor: conn.close failed: %s", exc)

    return summary
