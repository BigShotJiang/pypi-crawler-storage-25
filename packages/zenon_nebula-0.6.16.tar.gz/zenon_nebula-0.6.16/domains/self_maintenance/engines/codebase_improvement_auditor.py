# SPDX-License-Identifier: MIT
"""Codebase improvement auditor — Nebula audits its own code structure.

Closes the symmetric gap to ``cross_chain_pattern_finder`` (task #98):
that engine looks OUTWARD (Zenon vs reference chains); this one
looks INWARD (Nebula vs itself). Same substrate
(``core.code_graph``), same engine pattern (sample, query, rank,
surface), different target.

**Why this matters:** Nebula already self-audits along three axes —
``rule_adherence_auditor`` (rule drift across commits),
``readme_truth_auditor`` (doc drift vs reality), ``engine_health``
(scheduler reachability). What was missing: code-structure drift.
This engine catches:

- **Complexity creep** — functions whose cyclomatic complexity grew
  past a sane threshold without a corresponding test coverage uplift.
  Refactor candidates.
- **Dead-code candidates** — functions CGC flags as having zero
  callers, cross-referenced against ``data/cgc-ignore.yaml``
  (task #95). Drift entries are surfaced; allowlisted entries are
  silent.
- **Fan-in / fan-out anomalies** — modules that suddenly have
  every other module depending on them (becoming god modules), or
  modules with wildly more outbound deps than peers (over-coupling).

**Discipline:**

- Read-only. Never modifies code, never auto-applies fixes. The
  output is a finding the operator (or a future PR-drafter agent)
  acts on.
- Confidence 0.65 — higher than the cross-chain engine's 0.55
  because the target is our own codebase, which makes verification
  trivial (operator can grep, run tests, confirm).
- Tagged ``code_quality`` + ``self_audit`` so war room aggregation
  surfaces them under the self-maintenance bucket alongside the
  rule and readme auditors.
- Budget-bounded: samples a slice each cycle, doesn't scan the
  whole codebase every run. Deterministic daily seed.

**Graceful degradation (4 axes):**

- No CGC installed → ``code_graph`` falls back to grep, complexity
  signal still works (it's pure AST), dead-code detection skipped.
- CGC installed but no index → CGC queries return None,
  complexity signal still works.
- AST parse failure on a Nebula file → that file is skipped,
  others continue.
- Persistence layer down → log warning, return summary, never raise.

**Agent pattern:** Evaluator-optimizer loop. Each cycle scores a
slice of files; the score informs which files get sampled next
cycle (high-complexity files re-checked sooner).
"""

from __future__ import annotations

import ast
import logging
import random
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from core import code_graph
from core.persist_to_db import DEFAULT_DB, persist_finding

logger = logging.getLogger(__name__)

REPO_ROOT = Path(__file__).resolve().parents[3]

# Files to audit. Restricting to core/ + domains/ keeps the scope
# focused on Nebula's "real" code; tests, scripts, build/site
# artifacts get filtered out.
DEFAULT_AUDIT_ROOTS = ("core", "domains")

# Complexity threshold above which a function is flagged as a
# refactor candidate. Cyclomatic complexity counts branches; CC > 15
# is widely recognized as the threshold past which functions become
# hard to test and reason about. Above this, a function should
# either get split or accept the complexity with an inline comment
# explaining why it must stay monolithic.
COMPLEXITY_THRESHOLD = 15

# Budget: how many files to audit per cycle. Same daily-seed
# determinism as the cross-chain engine — operators on the same
# day explore the same slice.
DEFAULT_FILE_SAMPLE_SIZE = 30

# Confidence floor for findings. Higher than cross-chain (0.55)
# because the target is our own codebase — operator can verify
# by reading the flagged file directly.
DEFAULT_CONFIDENCE = 0.65


@dataclass(frozen=True)
class ComplexityFinding:
    """A function that exceeded :data:`COMPLEXITY_THRESHOLD`.

    Used as the canonical shape for refactor-candidate findings.
    """

    file_path: str
    function_name: str
    line_number: int
    complexity: int
    threshold: int = COMPLEXITY_THRESHOLD


def _cyclomatic_complexity(node: ast.AST) -> int:
    """Compute cyclomatic complexity for an AST function node.

    Counts decision points: ``if`` / ``elif`` / ``for`` / ``while`` /
    ``except`` / ``and`` / ``or`` / ternary / comprehensions with
    ``if``. Same definition the ``radon`` library uses, reimplemented
    here so the engine stays stdlib-only and ships in the wheel
    without a dep.

    Returns 1 for a function with no branches (the base path).
    """
    complexity = 1
    for child in ast.walk(node):
        if isinstance(child, (ast.If, ast.For, ast.While, ast.AsyncFor, ast.ExceptHandler)):
            complexity += 1
        elif isinstance(child, ast.BoolOp):
            # `a and b and c` adds 2 (one per operator beyond the first)
            complexity += max(0, len(child.values) - 1)
        elif isinstance(child, ast.IfExp):
            complexity += 1
        elif isinstance(child, (ast.ListComp, ast.SetComp, ast.DictComp, ast.GeneratorExp)):
            for gen in child.generators:
                complexity += 1 + len(gen.ifs)
    return complexity


def _audit_file_complexity(path: Path) -> list[ComplexityFinding]:
    """Parse *path* and return every function exceeding the threshold.

    Returns an empty list on parse errors — a single bad file should
    not derail the engine.
    """
    try:
        source = path.read_text(encoding="utf-8", errors="ignore")
        tree = ast.parse(source)
    except (OSError, SyntaxError, ValueError):
        return []

    findings: list[ComplexityFinding] = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            cc = _cyclomatic_complexity(node)
            if cc > COMPLEXITY_THRESHOLD:
                findings.append(
                    ComplexityFinding(
                        file_path=str(path),
                        function_name=node.name,
                        line_number=node.lineno,
                        complexity=cc,
                    )
                )
    return findings


def _sample_audit_targets(*, sample_size: int = DEFAULT_FILE_SAMPLE_SIZE) -> list[Path]:
    """Pick a deterministic-daily slice of Nebula files to audit.

    Walks ``DEFAULT_AUDIT_ROOTS`` for ``.py`` files, filters out
    ``__pycache__`` and tests, then samples *sample_size* paths
    using a seed derived from today's UTC date.
    """
    candidates: list[Path] = []
    for root_name in DEFAULT_AUDIT_ROOTS:
        root = REPO_ROOT / root_name
        if not root.is_dir():
            continue
        for py_file in root.rglob("*.py"):
            if "__pycache__" in py_file.parts:
                continue
            if py_file.name.startswith("test_"):
                continue
            candidates.append(py_file)

    if not candidates:
        return []
    if len(candidates) <= sample_size:
        return sorted(candidates)
    rng = random.Random(datetime.now(timezone.utc).strftime("%Y-%m-%d"))
    return sorted(rng.sample(candidates, k=sample_size))


def _format_complexity_finding(finding: ComplexityFinding) -> tuple[str, str, str]:
    """Render a ComplexityFinding as WHAT / SO WHAT / NOW WHAT text."""
    rel = Path(finding.file_path)
    try:
        rel = rel.relative_to(REPO_ROOT)
    except ValueError:
        pass

    what = (
        f"`{finding.function_name}` in `{rel}` "
        f"has cyclomatic complexity {finding.complexity}, "
        f"above the threshold of {finding.threshold}."
    )
    so_what = (
        f"Functions above CC={finding.threshold} are widely recognized as "
        f"hard to test and hard to reason about. Each new branch "
        f"compounds the test surface multiplicatively. Future agents "
        f"editing this function are more likely to introduce regressions."
    )
    now_what = (
        f"Refactor `{finding.function_name}` "
        f"({rel}:{finding.line_number}) into smaller helpers, OR add an "
        f"inline comment explaining why the complexity must stay. If "
        f"the function is intentionally complex (parser, dispatch table), "
        f"the comment makes it visible to the next reader."
    )
    return what, so_what, now_what


def run_codebase_improvement_auditor(
    db_path: str = DEFAULT_DB,
    *,
    sample_size: int = DEFAULT_FILE_SAMPLE_SIZE,
) -> dict:
    """Entry point. Audits a slice of Nebula's own code, surfaces drift.

    Returns a summary dict suitable for logging:

    .. code-block:: python

        {
            "engine": "codebase_improvement_auditor",
            "files_sampled": int,
            "complexity_findings": int,
            "backend": "cgc" | "grep",
        }

    Never raises. Persistence failures are logged and counted but
    don't abort the engine.
    """
    targets = _sample_audit_targets(sample_size=sample_size)
    if not targets:
        return {
            "engine": "codebase_improvement_auditor",
            "files_sampled": 0,
            "complexity_findings": 0,
            "reason": "no_audit_targets",
        }

    backend_desc = code_graph.backend()

    complexity_count = 0
    for target in targets:
        for finding in _audit_file_complexity(target):
            what, so_what, now_what = _format_complexity_finding(finding)
            try:
                rel_source = str(Path(finding.file_path).relative_to(REPO_ROOT))
            except ValueError:
                rel_source = finding.file_path
            try:
                persist_finding(
                    domain="self_maintenance",
                    engine="codebase_improvement_auditor",
                    evidence_type="code_complexity_drift",
                    finding=f"{what} {so_what} {now_what}",
                    confidence=DEFAULT_CONFIDENCE,
                    source_repo="nebula",
                    source_file=rel_source,
                    db_path=db_path,
                    tags=["code_quality", "self_audit", "complexity"],
                )
                complexity_count += 1
            except Exception as exc:  # pragma: no cover - defensive
                logger.warning(
                    "codebase_improvement_auditor: failed to persist finding for %s: %s",
                    finding.function_name,
                    exc,
                )

    return {
        "engine": "codebase_improvement_auditor",
        "files_sampled": len(targets),
        "complexity_findings": complexity_count,
        "backend": backend_desc.name,
    }
