# SPDX-License-Identifier: MIT
"""Self-Maintenance Domain — Nebula monitoring and healing itself.

This domain ensures Nebula stays healthy, current, and self-aware.
It watches for: stale engines, dead hypotheses, budget overruns,
test failures, documentation drift, and database bloat.

If Nebula is the brain, this domain is the immune system.
"""

from core.domain_registry import (
    AspirationType,
    CollisionSignal,
    DomainPlugin,
    EngineDefinition,
    HypothesisType,
    WarRoomContribution,
)


class SelfMaintenanceDomain(DomainPlugin):
    """Nebula's immune system — keeps the platform healthy."""

    def name(self) -> str:
        """Return the domain name identifier."""
        return "self_maintenance"

    def get_description(self) -> str:
        """Return a human-readable description of this domain."""
        return "Monitors Nebula's own health: engine performance, data freshness, budget pacing, test coverage, documentation accuracy"

    def get_engines(self) -> list:
        """Return the list of engines this domain provides."""
        return [
            EngineDefinition(
                name="engine_health_monitor",
                module_path="domains.self_maintenance.engines.engine_health",
                priority=9,
                description="Monitors each engine's success rate, error rate, staleness, cost efficiency",
            ),
            EngineDefinition(
                name="config_drift_detector",
                module_path="domains.self_maintenance.engines.config_drift",
                priority=8,
                description="Detects when config files, README, domain count, or engine count drift from reality",
            ),
            EngineDefinition(
                name="rule_adherence_auditor",
                module_path="domains.self_maintenance.engines.rule_adherence_auditor",
                priority=9,
                ships_in_wheel=False,  # fork-dev: audits Nebula's own commits
                description=(
                    "Task #54. Walks the last 30 Nebula commits and "
                    "checks each against the autonomous-quality + "
                    "commit-discipline + anti-hallucination rules. "
                    "Persists WHAT/SO WHAT/NOW WHAT findings for "
                    "every rule drift. Closes the 'rule execution "
                    "is not mechanical' gap — would have caught the "
                    "v0.6.1 continue-on-error hallucination before "
                    "it reached a tag."
                ),
            ),
            EngineDefinition(
                name="readme_truth_auditor",
                module_path="domains.self_maintenance.engines.readme_truth_auditor",
                priority=9,
                ships_in_wheel=False,  # fork-dev: audits Nebula's own README
                description=(
                    "Task #74. Walks docs/claims.yml + CHANGELOG.md "
                    "and runs every claim's executable verifier. "
                    "Surfaces drift, broken claims, and stale "
                    "forward-looking promises (e.g. past CHANGELOG "
                    "entries that promised features for versions "
                    "the plan later moved). README is the main "
                    "selling surface — this engine + the CI gate "
                    "make accuracy a mechanically-enforced property "
                    "of every ship."
                ),
            ),
            EngineDefinition(
                name="codebase_improvement_auditor",
                module_path="domains.self_maintenance.engines.codebase_improvement_auditor",
                priority=9,
                ships_in_wheel=False,  # fork-dev: audits Nebula's own code
                description=(
                    "Task #93. Audits Nebula's own code for "
                    "complexity drift — functions whose cyclomatic "
                    "complexity grew past the threshold (default 15). "
                    "Symmetric to cross_chain_pattern_finder (task "
                    "#98): same code_graph substrate, but pointed "
                    "INWARD at Nebula instead of OUTWARD at Zenon. "
                    "Pure-AST complexity check works without CGC; "
                    "future dead-code + dependency anomaly checks "
                    "use core.code_graph for richer analysis when "
                    "CGC is installed. Closes the self-audit trinity "
                    "(rules + readme + code) so Nebula catches its "
                    "own drift before operators do."
                ),
            ),
            EngineDefinition(
                name="llm_cost_optimizer",
                module_path="domains.self_maintenance.engines.llm_cost_optimizer",
                priority=8,
                description=(
                    "Task #94. Joins cost_tracking + evidence over "
                    "the last 7 days and surfaces three signal "
                    "classes: cost outliers (engines whose cost-per-"
                    "finding is 5x+ the median), stagnant spend "
                    "(engines spending >$0.50 with zero findings), "
                    "and model arbitrage (when an engine has run on "
                    "multiple models, the cheapest-per-finding is "
                    "recommended). Pure SQL + math, no LLM calls. "
                    "24h cooldown per (engine, signal_class) so the "
                    "war room doesn't flood when an outlier persists."
                ),
            ),
            EngineDefinition(
                name="api_awareness",
                module_path="domains.self_maintenance.engines.api_awareness",
                priority=8,
                description=(
                    "Task #66. Reads core.api_telemetry's "
                    "api_call_log table on a rolling window and "
                    "applies four deterministic anomaly checks: "
                    "error-rate spikes (>10% recent vs <2% baseline), "
                    "latency drift (recent p95 >2x baseline), "
                    "schema-hash drift (new response shapes appearing "
                    "in last 24h), and sudden provider disappearance "
                    "(>10 calls/day for 30 days then zero). Pure SQL "
                    "+ math, no LLM, no network. 24h cooldown per "
                    "provider+class pair to avoid flooding the war "
                    "room. Findings tagged api_health + self_audit."
                ),
            ),
            EngineDefinition(
                name="api_suggester",
                module_path="domains.self_maintenance.engines.api_suggester",
                priority=9,
                description=(
                    "Task #66 Phase D. Opt-in LLM engine gated on "
                    "XAI_API_KEY. Reads api_call_log telemetry + "
                    "evidence table to identify: active providers, "
                    "failing providers (>20% error rate), and domains "
                    "starved of evidence (7d silence). Asks the LLM "
                    "to propose 1-3 new APIs the operator should "
                    "consider. Proposals surface as low-confidence "
                    "(0.30) findings, never auto-install. 24h cooldown "
                    "per suggestion domain. One LLM call per cycle "
                    "using DEFAULT_CHEAPEST."
                ),
            ),
            EngineDefinition(
                name="mcp_discovery",
                module_path="domains.self_maintenance.engines.mcp_discovery",
                priority=8,
                description=(
                    "Task #66 Phase D. Walks known MCP config paths "
                    "(Claude Code ~/.claude/settings.json, Cursor "
                    "~/.cursor/mcp.json, project <workspace>/.mcp.json, "
                    "operator-declared NEBULA_MCP_DISCOVERY_PATHS) "
                    "and surfaces every configured MCP server the "
                    "operator could wire into Nebula as a provider. "
                    "Read-only; never modifies any config. "
                    "OPSEC-sanitized: persists server name + transport "
                    "+ sha256 of (command,args) but never the command "
                    "body, args, URLs, or env (MCP configs routinely "
                    "embed secrets). 24h cooldown per (config_path, "
                    "server_name). Confidence 0.50."
                ),
            ),
            EngineDefinition(
                name="llm_model_watcher",
                module_path="domains.self_maintenance.engines.llm_model_watcher",
                priority=8,
                description=(
                    "Task #92. Fetches xAI's /v1/models catalog (free "
                    "endpoint) and diffs it against MODEL_PRICING. "
                    "Surfaces three signals: new_model (API lists a "
                    "model not in MODEL_PRICING), removed_model "
                    "(MODEL_PRICING lists one no longer on API), and "
                    "flagship_shift (API lists a grok-* ID sorting "
                    "higher than DEFAULT_BEST — benchmark candidate). "
                    "Detection-only, never auto-ships a code change. "
                    "Confidence capped at 0.40 per anti-hallucination "
                    "rule #6. 24h cooldown per (model_id, "
                    "signal_class). Sibling to llm_cost_optimizer: "
                    "this one watches xAI's catalog, that one watches "
                    "our spend."
                ),
            ),
            EngineDefinition(
                name="todo_budget_monitor",
                module_path="domains.self_maintenance.engines.todo_budget_monitor",
                priority=8,
                ships_in_wheel=False,  # fork-dev: tracks Nebula's own tech-debt allowlists
                description=(
                    "Task #86. Tracks tech-debt budget trajectory: "
                    "counts TODOs across core/+domains/+scripts/ and "
                    "members of every named tech-debt allowlist "
                    "(UNREACHABLE_ENGINES_ALLOWLIST, "
                    "SUBPROCESS_NO_TIMEOUT_ALLOWLIST, et al), writes "
                    "per-cycle snapshots to todo_budget, and surfaces "
                    "findings when a source grew since the last "
                    "snapshot or has held flat across "
                    "STAGNATION_THRESHOLD_SNAPSHOTS cycles without "
                    "shrinking. Closes the 'allowlist as "
                    "load-bearing exemption' anti-pattern that "
                    "produced the v0.3.2 UNREACHABLE_ENGINES drift "
                    "of 47 entries. Pure AST + grep, zero LLM."
                ),
            ),
            EngineDefinition(
                name="disagreement_engine",
                module_path="domains.self_maintenance.engines.disagreement_engine",
                priority=7,
                description=(
                    "Task #69. Inverse of peer_corroboration: surface "
                    "cases where two peers produce findings at the same "
                    "source location but reach different conclusions "
                    "(distinct content_hash values). Disagreement is "
                    "productive friction that stays invisible otherwise. "
                    "Reads evidence only; 24h cooldown per location; "
                    "bounded emission so a single bad peer or hot-spot "
                    "can't flood the war room. Tagged "
                    "peer_disagreement + self_audit."
                ),
            ),
        ]

    def get_hypothesis_types(self) -> list[HypothesisType]:
        """Return hypothesis types this domain can generate."""
        return [
            HypothesisType(
                type_id="nebula_healthy",
                label="Nebula is healthy",
                description="All engines running, no stale data, tests passing, budget on track",
            ),
            HypothesisType(
                type_id="self_improvement_working",
                label="Self-improvement is working",
                description="System quality metrics improving session over session",
            ),
        ]

    def get_aspiration_types(self) -> list[AspirationType]:
        """Return aspiration types this domain can pursue."""
        return [
            AspirationType(
                type_id="zero_stale_engines",
                label="Zero stale engines",
                description="All engines have run within their expected cadence.",
            ),
            AspirationType(
                type_id="full_test_pass",
                label="100% test pass rate",
                description="All test suites across all domains pass without failure.",
            ),
            AspirationType(
                type_id="doc_matches_reality",
                label="Documentation matches reality",
                description="README claims, domain counts, and engine counts match actual state.",
            ),
        ]

    def get_collision_signals(self) -> list[CollisionSignal]:
        """Return signals that trigger cross-domain collisions."""
        return [
            CollisionSignal(
                signal_id="engine_stall_cascade",
                label="Engine stall cascade",
                description="Multiple engines across different domains are stalled simultaneously",
                source_domains=["self_maintenance"],
            ),
            CollisionSignal(
                signal_id="budget_exhaustion_warning",
                label="Budget exhaustion warning",
                description="Daily budget >80% consumed before end of cycle",
                source_domains=["self_maintenance"],
            ),
        ]

    def get_war_room_contributions(self) -> list[WarRoomContribution]:
        """Return this domain's war room briefing sections."""
        return [
            WarRoomContribution(
                domain="self_maintenance",
                section_title="System Health",
                metrics=[
                    "engine_uptime_pct",
                    "stale_engine_count",
                    "error_rate_24h",
                ],
            ),
            WarRoomContribution(
                domain="self_maintenance",
                section_title="Budget Status",
                metrics=[
                    "budget_spent_today",
                    "budget_remaining",
                    "cost_per_finding",
                ],
            ),
        ]

    def get_self_improvement_metrics(self) -> dict[str, float]:
        """Return current performance metrics for self-improvement."""
        return {
            "engine_uptime_pct": 0.0,
            "test_pass_rate": 0.0,
            "stale_evidence_count": 0.0,
            "db_size_mb": 0.0,
            "budget_accuracy": 0.0,
            "doc_drift_score": 0.0,
        }

    def decide_next_action(self, context: dict, exclude: set[str] | None = None) -> dict | None:
        """Rotate through every self-maintenance engine, honoring exclude.

        Rewritten v0.6.3 (task #54) to support exclude-based rotation
        so the new ``rule_adherence_auditor`` reaches the scheduler
        reliably. Prior to v0.6.3 this method returned the same
        engine_health action on every call when nothing was in
        stale_data — which meant config_drift_detector only fired on
        explicit stale markers and rule_adherence_auditor would have
        been dead on arrival. Same rotation fix applied to the
        investigation domain in v0.3.1 — `exclude` is how the
        scheduler asks for a DIFFERENT action when the first choice
        was already picked this cycle.
        """
        exclude = exclude or set()
        candidates: list[dict] = [
            {
                "action": "check_engine_health",
                "reason": "Routine engine health check.",
                "priority": 8,
                "engine": "engine_health_monitor",
            },
            {
                "action": "check_config_drift",
                "reason": "Configuration drift monitoring.",
                "priority": 9,
                "engine": "config_drift_detector",
            },
            {
                "action": "audit_rule_adherence",
                "reason": (
                    "Walk recent Nebula commits and flag any that "
                    "drifted from the `.claude/rules/` conventions."
                ),
                "priority": 9,
                "engine": "rule_adherence_auditor",
            },
            {
                "action": "audit_readme_truth",
                "reason": (
                    "Verify every README claim against the live code "
                    "and surface drift, broken claims, or stale "
                    "forward-looking promises."
                ),
                "priority": 9,
                "engine": "readme_truth_auditor",
            },
            {
                "action": "audit_codebase_complexity",
                "reason": (
                    "Sample Nebula's own functions for cyclomatic "
                    "complexity drift; flag refactor candidates."
                ),
                "priority": 9,
                "engine": "codebase_improvement_auditor",
            },
            {
                "action": "audit_llm_cost",
                "reason": (
                    "Join cost_tracking + evidence to surface cost outliers, "
                    "stagnant LLM spend, and model arbitrage opportunities."
                ),
                "priority": 8,
                "engine": "llm_cost_optimizer",
            },
            {
                "action": "audit_api_health",
                "reason": (
                    "Detect provider error-rate spikes, latency drift, "
                    "schema drift, and provider disappearance."
                ),
                "priority": 8,
                "engine": "api_awareness",
            },
            {
                "action": "watch_llm_models",
                "reason": (
                    "Diff xAI's /v1/models catalog against MODEL_PRICING; "
                    "flag new models, deprecations, and flagship shifts."
                ),
                "priority": 8,
                "engine": "llm_model_watcher",
            },
            {
                "action": "suggest_new_apis",
                "reason": (
                    "Ask the LLM to propose new APIs that would fill "
                    "coverage gaps — based on active/failing providers "
                    "and domains starved of evidence."
                ),
                "priority": 9,
                "engine": "api_suggester",
            },
            {
                "action": "discover_mcp_servers",
                "reason": (
                    "Walk known MCP config paths and surface servers the "
                    "operator has configured for other clients but not "
                    "yet wired into Nebula."
                ),
                "priority": 8,
                "engine": "mcp_discovery",
            },
            {
                "action": "audit_todo_budget",
                "reason": (
                    "Snapshot TODO + allowlist counts; flag growth or "
                    "stagnation in tech-debt budget sources."
                ),
                "priority": 8,
                "engine": "todo_budget_monitor",
            },
            {
                "action": "audit_peer_disagreement",
                "reason": (
                    "Find source locations where peers reach different "
                    "conclusions — productive friction the operator "
                    "should adjudicate."
                ),
                "priority": 7,
                "engine": "disagreement_engine",
            },
        ]
        # Distribution-scope gate — see .claude/rules/distribution-scope.md.
        # Skip fork-dev-only engines (those with ships_in_wheel=False) unless
        # NEBULA_DEV_ENGINES=1. End-user installs don't waste cycles auditing
        # Nebula's own README, commits, code, or allowlists.
        import os

        from core.domain_registry import EngineDefinition

        dev_engines_enabled = os.environ.get("NEBULA_DEV_ENGINES", "").strip() == "1"
        fork_dev_engines = {
            e.name
            for e in self.get_engines()
            if isinstance(e, EngineDefinition) and not e.ships_in_wheel
        }

        for candidate in candidates:
            key = f"self_maintenance:{candidate['action']}"
            if key in exclude:
                continue
            if candidate["engine"] in fork_dev_engines and not dev_engines_enabled:
                continue
            return candidate
        return None

    def get_db_schema_sql(self) -> str:
        """Return domain-specific SQL DDL for additional tables."""
        return """
        CREATE TABLE IF NOT EXISTS engine_health (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            domain TEXT NOT NULL,
            engine TEXT NOT NULL,
            last_run DATETIME,
            success_count INTEGER DEFAULT 0,
            error_count INTEGER DEFAULT 0,
            cost_total REAL DEFAULT 0.0,
            status TEXT DEFAULT 'unknown'
        );

        CREATE TABLE IF NOT EXISTS maintenance_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            action TEXT NOT NULL,
            target TEXT,
            result TEXT,
            details TEXT
        );
        """
