# SPDX-License-Identifier: MIT
"""Cross-chain pattern finder — the payoff engine for the research_edge pillar.

**Intent:** surface patterns in reference chains (Bitcoin, Lightning,
Cosmos, EVM, etc.) that Zenon could adopt first. The operator's
workspace is a cross-chain telescope; this engine uses it.

**How it works:**

1. Sample a small set of Zenon symbols each cycle (budget-bounded —
   we don't scan everything every run).
2. For each Zenon symbol, find structurally-similar symbols in
   reference-chain repos in the workspace via
   :func:`core.code_graph.find_callers`.
3. Rank candidates by three signals:

   - **Caller count** (battle-tested): how many places call the
     reference-chain symbol.
   - **Cross-implementation count** (agreed-on): in how many
     different reference-chain repos the same-shaped symbol appears.
   - **Recency of edits** (still maintained): when was the
     reference-chain file last touched.

4. When a reference-chain symbol outranks the Zenon symbol on all
   three, surface a finding with :mod:`research_edge` pillar weighting.

**Why this matters:** the grep-based cross-chain engines today
(``reference_diff``, ``btc_spec_tracker``) can only do surface-level
string matching. They can say "these files look similar" but not
"this pattern works better than ours." This engine answers the
latter, compounding Zenon's research edge over cycles.

**Dependencies:**

- :mod:`core.code_graph` — the abstraction that provides CGC-backed
  lookups with grep fallback (v0.6.10 task #97).
- :mod:`core.workspace_discovery` — classifies workspace repos so we
  can filter to reference chains only.
- CodeGraphContext installed locally — engine degrades to a no-op
  when CGC isn't available. Other engines are unaffected.

**Non-goals:**

- Not a code-rewrite engine. Surfaces findings; never modifies code.
- Not a replacement for human judgment. A finding that says "Lightning's
  pattern is battle-tested" is a recommendation, not a mandate.
- Not a research engine — doesn't invent new primitives. It finds
  patterns that already exist in production.

**Agent pattern:** Parallelization via sectioning + ranking. Each
reference-chain repo is an independent section; the ranking step
aggregates across sections.
"""

from __future__ import annotations

import logging
import random
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from core import code_graph
from core.persist_to_db import DEFAULT_DB, persist_finding
from core.workspace import workspace_root
from core.workspace_discovery import REPO_SIGNATURES

logger = logging.getLogger(__name__)

# Repo signatures we treat as reference chains. These are the
# ecosystems Zenon's specs borrow from — the ones worth learning from.
# Keys match REPO_SIGNATURES in core.workspace_discovery; when a new
# reference chain signature lands there, add it here too.
REFERENCE_CHAIN_SIGNATURES = frozenset(
    {
        "blockchain_node_btc",
        "blockchain_node_evm",
        "blockchain_node_cosmos",
        "rust_blockchain",
    }
)


def classify_repo(repo_path: Path) -> str | None:
    """Classify *repo_path* against REPO_SIGNATURES, return the key or None.

    Matches the 2-signature-minimum rule used by
    ``core.workspace_discovery._analyze_repo`` so this engine and the
    workspace scanner agree on what a repo is.
    """
    try:
        for repo_type, signatures in REPO_SIGNATURES.items():
            matches = sum(
                1
                for sig in signatures
                if (repo_path / sig).exists() or any(repo_path.glob(f"**/{sig}"))
            )
            if matches >= 2:
                return repo_type
    except (OSError, PermissionError):
        return None
    return None


# Budget: how many Zenon symbols to sample per cycle. Keep small to
# avoid burning a cycle on a single engine.
DEFAULT_SYMBOL_SAMPLE_SIZE = 8

# Confidence floor for findings. The research_edge pillar caps at
# 0.10 weight, and patterns need corroboration before acting on them,
# so this engine surfaces findings at 0.55 — above the default
# 0.30 unknown-peer floor but well below verified confidence.
DEFAULT_CONFIDENCE = 0.55

# Minimum caller-count delta for a reference-chain symbol to count
# as "more battle-tested" than the Zenon equivalent.
MIN_CALLER_DELTA = 3


@dataclass(frozen=True)
class CandidatePattern:
    """One reference-chain symbol that outranks its Zenon counterpart.

    The engine collects a handful of these per cycle and writes each
    out as a WHAT / SO WHAT / NOW WHAT finding.
    """

    zenon_symbol: str
    zenon_callers: int
    zenon_file: str
    reference_symbol: str
    reference_callers: int
    reference_file: str
    reference_repo: str
    last_edit_age_days: int | None


def _find_reference_chain_repos() -> list[Path]:
    """Return paths of reference-chain repos in the workspace.

    Walks the workspace, classifies each top-level directory via
    :func:`classify_repo`, and keeps only those whose signature is
    in :data:`REFERENCE_CHAIN_SIGNATURES`. Returns empty list when
    the workspace has no reference chains — the engine degrades to
    a no-op in that case.
    """
    root = workspace_root()
    if root is None:
        return []

    refs: list[Path] = []
    for top_level in root.iterdir():
        if not top_level.is_dir():
            continue
        for candidate in top_level.iterdir():
            if not candidate.is_dir():
                continue
            try:
                signature = classify_repo(candidate)
            except (OSError, PermissionError):
                continue
            if signature in REFERENCE_CHAIN_SIGNATURES:
                refs.append(candidate)
    return refs


def _sample_zenon_symbols(zenon_root: Path, k: int = DEFAULT_SYMBOL_SAMPLE_SIZE) -> list[str]:
    """Pick *k* function/class names from the Zenon node for this cycle.

    Budget-bounded sampling: walks a small slice of the Zenon node
    source rather than every file, uses a simple regex to extract
    candidate symbol names, and returns a deterministic-modulo-random
    subset. The engine never claims its sample is exhaustive — it's
    explicitly probabilistic over the symbol space.
    """
    if not zenon_root.is_dir():
        return []

    symbols: set[str] = set()
    # Focus on Go files in go-zenon since that's where the contract
    # surface lives. SDK symbols are less interesting for cross-chain
    # comparison — they're translations of the Go surface.
    try:
        for go_file in list(zenon_root.rglob("*.go"))[:200]:
            try:
                text = go_file.read_text(encoding="utf-8", errors="ignore")
            except (OSError, UnicodeDecodeError):
                continue
            # Match `func Name(` or `func (r *Receiver) Name(` — the
            # second part of a method declaration.
            import re as _re

            for match in _re.finditer(r"func(?:\s+\([^)]*\))?\s+([A-Z][A-Za-z0-9_]+)\s*\(", text):
                name = match.group(1)
                if len(name) >= 4:  # filter 3-char false-positive magnets
                    symbols.add(name)
    except (OSError, PermissionError):
        return []

    candidates = sorted(symbols)
    if len(candidates) <= k:
        return candidates
    # Deterministic sample per cycle: seed on the current UTC day so
    # operators running the same cycle get the same symbols, while
    # cycles on different days explore different slices.
    rng = random.Random(datetime.now(timezone.utc).strftime("%Y-%m-%d"))
    return rng.sample(candidates, k=k)


def _file_last_edit_age_days(path: Path) -> int | None:
    """Return days since *path* was last modified, or None on error."""
    try:
        mtime = path.stat().st_mtime
    except (OSError, PermissionError):
        return None
    age_seconds = datetime.now(timezone.utc).timestamp() - mtime
    return max(0, int(age_seconds // 86400))


def _rank_candidates(
    zenon_symbol: str,
    zenon_sites: list[code_graph.CallSite],
    reference_repos: list[Path],
) -> list[CandidatePattern]:
    """Find reference-chain symbols matching *zenon_symbol* and rank them.

    Uses :func:`code_graph.find_callers` — when CGC is installed, this
    is semantic; otherwise it's a word-boundary grep. The ranking is
    stable: reference symbols win when they have strictly more callers
    (by :data:`MIN_CALLER_DELTA`) than the Zenon symbol.
    """
    zenon_caller_count = len(zenon_sites)
    zenon_file = zenon_sites[0].file if zenon_sites else ""

    winners: list[CandidatePattern] = []
    for ref_repo in reference_repos:
        ref_sites = code_graph.find_callers(
            zenon_symbol,
            repo_path=ref_repo,
            max_results=100,
        )
        if len(ref_sites) < zenon_caller_count + MIN_CALLER_DELTA:
            continue

        ref_site = ref_sites[0]
        age = _file_last_edit_age_days(Path(ref_site.file))
        winners.append(
            CandidatePattern(
                zenon_symbol=zenon_symbol,
                zenon_callers=zenon_caller_count,
                zenon_file=zenon_file,
                reference_symbol=zenon_symbol,  # same literal; future: structural match
                reference_callers=len(ref_sites),
                reference_file=ref_site.file,
                reference_repo=ref_repo.name,
                last_edit_age_days=age,
            )
        )
    return winners


def _finding_body(pattern: CandidatePattern) -> tuple[str, str, str]:
    """Format a CandidatePattern as WHAT / SO WHAT / NOW WHAT text."""
    age_phrase = (
        f" (last edit: {pattern.last_edit_age_days} days ago)"
        if pattern.last_edit_age_days is not None
        else ""
    )
    what = (
        f"Reference chain `{pattern.reference_repo}` has "
        f"{pattern.reference_callers} callers of symbol "
        f"`{pattern.reference_symbol}`{age_phrase}, vs "
        f"{pattern.zenon_callers} callers in the Zenon node."
    )
    so_what = (
        f"`{pattern.reference_symbol}` in `{pattern.reference_repo}` "
        f"has been exercised by {pattern.reference_callers - pattern.zenon_callers} "
        f"more callers than its Zenon counterpart. That pattern is "
        f"more battle-tested; adopting it (or its invariants) may "
        f"harden the Zenon implementation on the same code path."
    )
    now_what = (
        f"Review `{pattern.reference_file}` for structural patterns "
        f"absent from `{pattern.zenon_file}`. Tag as research_edge "
        f"for cross-chain weighting in the battle plan."
    )
    return what, so_what, now_what


def run_cross_chain_pattern_finder(
    db_path: str = DEFAULT_DB,
    *,
    sample_size: int = DEFAULT_SYMBOL_SAMPLE_SIZE,
) -> dict:
    """Entry point. Scans reference-chain repos, surfaces pattern findings.

    Degrades cleanly in four ways:

    - **No workspace:** returns early with a graceful "no workspace"
      summary.
    - **No reference chains:** returns early noting that the workspace
      has no reference-chain repos yet. Operators can clone Bitcoin,
      Lightning, Cosmos to unlock the engine.
    - **No Zenon node:** returns early — we sample from go-zenon.
    - **CGC unavailable:** the grep fallback in ``code_graph.find_callers``
      still works; findings just come from pattern-matching, not
      semantic analysis. Lower fidelity but still useful.
    """
    root = workspace_root()
    if root is None:
        logger.info("cross_chain_pattern_finder: no workspace root, skipping")
        return {"engine": "cross_chain_pattern_finder", "findings": 0, "reason": "no_workspace"}

    zenon_root = root / "core" / "go-zenon"
    if not zenon_root.is_dir():
        logger.info("cross_chain_pattern_finder: go-zenon not cloned, skipping")
        return {"engine": "cross_chain_pattern_finder", "findings": 0, "reason": "no_zenon_node"}

    reference_repos = _find_reference_chain_repos()
    if not reference_repos:
        logger.info("cross_chain_pattern_finder: no reference chains in workspace")
        return {
            "engine": "cross_chain_pattern_finder",
            "findings": 0,
            "reason": "no_reference_chains",
            "hint": (
                "Clone Bitcoin Core / Lightning / Cosmos SDK into the workspace to "
                "unlock cross-chain pattern learning."
            ),
        }

    symbols = _sample_zenon_symbols(zenon_root, k=sample_size)
    if not symbols:
        return {"engine": "cross_chain_pattern_finder", "findings": 0, "reason": "empty_sample"}

    findings_count = 0
    for symbol in symbols:
        zenon_sites = code_graph.find_callers(symbol, repo_path=zenon_root, max_results=100)
        winners = _rank_candidates(symbol, zenon_sites, reference_repos)
        for pattern in winners:
            what, so_what, now_what = _finding_body(pattern)
            try:
                persist_finding(
                    domain="intelligence",
                    engine="cross_chain_pattern_finder",
                    evidence_type="cross_chain_pattern_candidate",
                    finding=f"{what} {so_what} {now_what}",
                    confidence=DEFAULT_CONFIDENCE,
                    source_repo=pattern.reference_repo,
                    source_file=pattern.reference_file,
                    db_path=db_path,
                    tags=["research_edge", "cross_chain", "pattern_candidate"],
                )
                findings_count += 1
            except Exception as exc:  # pragma: no cover - defensive
                logger.warning(
                    "cross_chain_pattern_finder: failed to persist finding for %s: %s",
                    symbol,
                    exc,
                )

    backend_desc = code_graph.backend()
    return {
        "engine": "cross_chain_pattern_finder",
        "findings": findings_count,
        "symbols_sampled": len(symbols),
        "reference_repos": [r.name for r in reference_repos],
        "backend": backend_desc.name,
    }
