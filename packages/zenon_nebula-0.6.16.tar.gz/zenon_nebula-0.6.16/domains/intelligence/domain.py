# SPDX-License-Identifier: MIT
"""
IntelligenceDomain -- DomainPlugin for ecosystem monitoring and signal routing.

Provides engines for upstream repository watching, signal classification,
signal routing via the feedback bus, and ecosystem health metrics.
"""

import logging

from core.domain_registry import (
    AspirationType,
    CollisionSignal,
    DomainPlugin,
    EngineDefinition,
    HypothesisType,
    WarRoomContribution,
)

logger = logging.getLogger(__name__)


class IntelligenceDomain(DomainPlugin):
    """Intelligence domain plugin -- ecosystem monitoring and signal routing."""

    def name(self) -> str:
        """Return the domain name identifier."""
        return "intelligence"

    def get_description(self) -> str:
        """Return a human-readable description of this domain."""
        return (
            "Ecosystem monitoring, upstream commit watching, signal "
            "classification, and cross-domain signal routing."
        )

    def get_priority(self) -> int:
        """Return the scheduling priority for this domain."""
        return 2  # Critical -- feeds data to all other domains

    def get_engines(self) -> list[EngineDefinition]:
        """Return the list of engines this domain provides."""
        return [
            EngineDefinition(
                name="upstream_watcher",
                description=(
                    "Monitors Zenon ecosystem repos for new commits, "
                    "classifies them by type, and persists signals."
                ),
                module_path="domains.intelligence.engines.upstream_watcher",
                priority=1,
                tier=1,
                required_apis=["git"],
                max_runtime_seconds=120,
            ),
            EngineDefinition(
                name="signal_detector",
                description=(
                    "Classifies incoming signals to determine which domain should act on them."
                ),
                module_path="domains.intelligence.engines.signal_detector",
                priority=2,
                tier=2,
                required_apis=[],
                max_runtime_seconds=60,
            ),
            EngineDefinition(
                name="signal_router",
                description=(
                    "Routes classified signals to the correct domain via the feedback bus."
                ),
                module_path="domains.intelligence.engines.signal_router",
                priority=3,
                tier=1,
                required_apis=[],
                max_runtime_seconds=30,
            ),
            EngineDefinition(
                name="ecosystem_health",
                description=(
                    "Queries ecosystem metrics: node count, staking "
                    "ratio, bridge TVL, and other health indicators."
                ),
                module_path="domains.intelligence.engines.ecosystem_health",
                priority=4,
                tier=2,
                required_apis=["zenonhub"],
                max_runtime_seconds=120,
            ),
            EngineDefinition(
                name="repo_relationship_mapper",
                description=(
                    "Builds an inter-repo dependency graph from the "
                    "workspace, detects stale fork sync and version "
                    "drift, and persists WHAT/SO WHAT/NOW WHAT findings."
                ),
                module_path="domains.intelligence.engines.repo_relationship_mapper",
                priority=5,
                tier=2,
                required_apis=["git"],
                max_runtime_seconds=60,
            ),
            EngineDefinition(
                name="branch_watcher",
                description=(
                    "Task #40 — tracks remote branches on workspace "
                    "repos that are ahead of main/master. Surfaces "
                    "'what's being cooked' findings (N commits on "
                    "branch X touching files Y) without leaking "
                    "git-author identity. Confidence capped at 0.60 "
                    "per the anti-hallucination rule because WIP "
                    "code hasn't been reviewed or merged. User "
                    "prefixes in branch names (alice/feature-x) are "
                    "sanitized to <user>/feature-x before surfacing."
                ),
                module_path="domains.intelligence.engines.branch_watcher",
                priority=6,
                tier=2,
                required_apis=["git"],
                max_runtime_seconds=60,
            ),
            EngineDefinition(
                name="cross_chain_pattern_finder",
                description=(
                    "Task #98 — the payoff engine for the research_edge "
                    "pillar. Samples Zenon symbols each cycle, queries "
                    "code_graph for structurally-similar symbols in "
                    "reference-chain repos (Bitcoin, Lightning, Cosmos, "
                    "EVM), ranks by caller count (battle-tested), "
                    "cross-implementation count (agreed-on), and recency "
                    "of edits. Surfaces 'adopt this pattern' findings "
                    "tagged research_edge. Degrades gracefully when CGC "
                    "isn't installed (falls back to grep via code_graph) "
                    "or when no reference chains are in the workspace."
                ),
                module_path="domains.intelligence.engines.cross_chain_pattern_finder",
                priority=7,
                tier=2,
                required_apis=["git"],
                max_runtime_seconds=120,
            ),
        ]

    def get_hypothesis_types(self) -> list[HypothesisType]:
        """Return hypothesis types this domain can generate."""
        return [
            HypothesisType(
                type_id="ecosystem_trend",
                label="Ecosystem trend detected",
                description=(
                    "A pattern in commit activity, contributor behavior, "
                    "or ecosystem metrics suggests a directional trend."
                ),
                initial_confidence=0.2,
                publishable_threshold=0.75,
            ),
            HypothesisType(
                type_id="breaking_change_impact",
                label="Breaking change impact assessment",
                description=(
                    "A breaking change in upstream code may affect "
                    "multiple downstream repositories."
                ),
                initial_confidence=0.3,
                publishable_threshold=0.80,
            ),
        ]

    def get_aspiration_types(self) -> list[AspirationType]:
        """Return aspiration types this domain can pursue."""
        return [
            AspirationType(
                type_id="full_coverage",
                label="Full upstream coverage",
                description="Monitor all active Zenon repositories.",
                priority=3,
            ),
            AspirationType(
                type_id="realtime_signals",
                label="Real-time signal routing",
                description=("Route signals to domains within 5 minutes of detection."),
                priority=4,
                deadline_days=30,
            ),
        ]

    def get_collision_signals(self) -> list[CollisionSignal]:
        """Return signals that trigger cross-domain collisions."""
        return [
            CollisionSignal(
                signal_id="cross_repo_convergence",
                label="Cross-repo convergence",
                description=(
                    "Multiple repos show coordinated changes on the same feature or spec."
                ),
                source_domains=["intelligence", "development"],
                convergence_threshold=0.6,
            ),
            CollisionSignal(
                signal_id="security_breaking_overlap",
                label="Security + breaking change overlap",
                description=(
                    "A change tagged both security_relevant and "
                    "breaking_change warrants immediate review."
                ),
                source_domains=["intelligence", "security"],
                convergence_threshold=0.5,
            ),
        ]

    def get_war_room_contributions(self) -> list[WarRoomContribution]:
        """Return this domain's war room briefing sections."""
        return [
            WarRoomContribution(
                domain="intelligence",
                section_title="Upstream Activity",
                metrics=[
                    "new_commits_24h",
                    "signals_routed_24h",
                    "new_contributors",
                    "repos_with_activity",
                ],
                recommendations_prompt=(
                    "Based on the upstream signals detected in the last "
                    "24 hours, what should the team prioritize?"
                ),
            ),
            WarRoomContribution(
                domain="intelligence",
                section_title="Ecosystem Health",
                metrics=[
                    "node_count",
                    "staking_ratio",
                    "bridge_tvl",
                    "active_pillars",
                ],
                recommendations_prompt=(
                    "Summarize ecosystem health and flag any metrics "
                    "that have changed significantly."
                ),
            ),
        ]

    def get_self_improvement_metrics(self) -> dict[str, float]:
        """Return current performance metrics for self-improvement."""
        return {
            "signals_per_scan": 0.0,
            "routing_accuracy": 0.0,
            "scan_coverage_pct": 0.0,
            "avg_signal_latency_sec": 0.0,
        }

    def decide_next_action(self, context: dict, exclude: set[str] | None = None) -> dict | None:
        """Decide the next action, rotating through all 6 intelligence engines."""
        exclude = exclude or set()
        trigger = context.get("trigger_level", "routine")
        stale = context.get("stale_data", [])
        candidates: list[dict] = []

        if "upstream_commits" in stale or trigger in ("urgent", "critical"):
            candidates.append(
                {
                    "action": "scan_upstream",
                    "reason": "Upstream data is stale or trigger level demands a scan.",
                    "priority": 2,
                    "engine": "upstream_watcher",
                }
            )

        if "ecosystem_metrics" in stale:
            candidates.append(
                {
                    "action": "refresh_ecosystem_health",
                    "reason": "Ecosystem health metrics are stale.",
                    "priority": 4,
                    "engine": "ecosystem_health",
                }
            )

        candidates.extend(
            [
                {
                    "action": "routine_process_signals",
                    "reason": "Routine signal processing.",
                    "priority": 5,
                    "engine": "signal_detector",
                },
                {
                    "action": "routine_signal_router",
                    "reason": "Routine signal routing across domains.",
                    "priority": 6,
                    "engine": "signal_router",
                },
                {
                    "action": "routine_upstream_watcher",
                    "reason": "Routine upstream watcher rotation.",
                    "priority": 6,
                    "engine": "upstream_watcher",
                },
                {
                    "action": "routine_ecosystem_health",
                    "reason": "Routine ecosystem health metrics.",
                    "priority": 7,
                    "engine": "ecosystem_health",
                },
                {
                    "action": "routine_repo_relationship_mapper",
                    "reason": "Routine repo relationship mapping.",
                    "priority": 7,
                    "engine": "repo_relationship_mapper",
                },
                {
                    "action": "routine_branch_watcher",
                    "reason": "Routine remote branch WIP tracking.",
                    "priority": 7,
                    "engine": "branch_watcher",
                },
                {
                    "action": "routine_cross_chain_pattern_finder",
                    "reason": ("Routine cross-chain pattern discovery (research_edge pillar)."),
                    "priority": 8,
                    "engine": "cross_chain_pattern_finder",
                },
            ]
        )

        for candidate in candidates:
            key = f"intelligence:{candidate['action']}"
            if key not in exclude:
                return candidate
        return None

    def get_db_schema_sql(self) -> str:
        """Return domain-specific SQL DDL for additional tables."""
        return """
CREATE TABLE IF NOT EXISTS intelligence_signals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    source TEXT,
    signal_type TEXT,
    details TEXT,
    routed_to_domain TEXT,
    processed BOOLEAN DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS ecosystem_metrics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    metric_name TEXT,
    metric_value REAL,
    source TEXT
);

CREATE INDEX IF NOT EXISTS idx_signals_type
    ON intelligence_signals(signal_type);
CREATE INDEX IF NOT EXISTS idx_signals_processed
    ON intelligence_signals(processed);
CREATE INDEX IF NOT EXISTS idx_signals_source
    ON intelligence_signals(source);
CREATE INDEX IF NOT EXISTS idx_metrics_name
    ON ecosystem_metrics(metric_name);
"""

    def on_register(self) -> None:
        """Initialize domain-specific resources after registration."""
        logger.info(
            "Intelligence domain registered with %d engines.",
            len(self.get_engines()),
        )
