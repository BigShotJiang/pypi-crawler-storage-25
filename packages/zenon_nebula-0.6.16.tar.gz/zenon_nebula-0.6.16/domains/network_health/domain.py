# SPDX-License-Identifier: MIT
"""
NetworkHealthDomain -- DomainPlugin for node census, decentralization scoring, and bridge health.

Provides engines for counting nodes and version distribution, scoring
network decentralization, and monitoring bridge TVL and relayer status.
"""

import logging

from core.domain_registry import (
    AspirationType,
    CollisionSignal,
    DomainPlugin,
    EngineDefinition,
    HypothesisType,
    WarRoomContribution,
)

logger = logging.getLogger(__name__)


class NetworkHealthDomain(DomainPlugin):
    """Network Health domain plugin -- node census and decentralization."""

    def name(self) -> str:
        """Return the domain name identifier."""
        return "network_health"

    def get_description(self) -> str:
        """Return a human-readable description of this domain."""
        return (
            "Network node census, version distribution tracking, "
            "decentralization scoring, and bridge health monitoring."
        )

    def get_priority(self) -> int:
        """Return the scheduling priority for this domain."""
        return 2  # High -- infrastructure health

    def get_engines(self) -> list[EngineDefinition]:
        """Return the list of engines this domain provides."""
        return [
            EngineDefinition(
                name="node_census",
                description=(
                    "Count active nodes, track version distribution, "
                    "and detect version upgrade adoption rates."
                ),
                module_path="domains.network_health.engines.node_census",
                priority=1,
                tier=1,
                required_apis=["zenonhub"],
                max_runtime_seconds=120,
            ),
            EngineDefinition(
                name="decentralization_scorer",
                description=(
                    "Score network decentralization based on pillar "
                    "distribution, hosting provider concentration, "
                    "and geographic spread."
                ),
                module_path="domains.network_health.engines.decentralization_scorer",
                priority=2,
                tier=2,
                required_apis=["zenonhub"],
                max_runtime_seconds=180,
            ),
            EngineDefinition(
                name="bridge_health",
                description=(
                    "Track bridge TVL, relayer count, stuck transactions, "
                    "and bridge operational status."
                ),
                module_path="domains.network_health.engines.bridge_health",
                priority=3,
                tier=2,
                required_apis=["zenonhub"],
                max_runtime_seconds=120,
            ),
            EngineDefinition(
                name="pillar_monitor",
                description=(
                    "Real-time pillar health monitoring: uptime tracking, "
                    "delegation changes, missed momentum alerts, and "
                    "performance quartile comparison."
                ),
                module_path="domains.network_health.engines.pillar_monitor",
                priority=2,
                tier=1,
                required_apis=["zenonhub"],
                max_runtime_seconds=120,
            ),
        ]

    def get_hypothesis_types(self) -> list[HypothesisType]:
        """Return hypothesis types this domain can generate."""
        return [
            HypothesisType(
                type_id="network_decentralized",
                label="Network sufficiently decentralized",
                description=(
                    "The network has enough independent pillars, diverse "
                    "hosting, and geographic spread to resist censorship."
                ),
                initial_confidence=0.3,
                publishable_threshold=0.80,
            ),
            HypothesisType(
                type_id="bridge_relayer_adequate",
                label="Bridge relayer set adequate",
                description=(
                    "The bridge has enough active relayers to ensure "
                    "liveness and timely transaction processing."
                ),
                initial_confidence=0.3,
                publishable_threshold=0.75,
            ),
            HypothesisType(
                type_id="version_adoption_healthy",
                label="Node version adoption is healthy",
                description=(
                    "A majority of nodes are running the latest or recent node software version."
                ),
                initial_confidence=0.2,
                publishable_threshold=0.75,
            ),
            HypothesisType(
                type_id="pillar_uptime_adequate",
                label="Pillar uptime adequate for consensus",
                description=(
                    "Median pillar uptime exceeds 90%, ensuring healthy "
                    "momentum production across the network."
                ),
                initial_confidence=0.3,
                publishable_threshold=0.80,
            ),
        ]

    def get_aspiration_types(self) -> list[AspirationType]:
        """Return aspiration types this domain can pursue."""
        return [
            AspirationType(
                type_id="full_node_visibility",
                label="Full node visibility",
                description="Track all active nodes with version and uptime.",
                priority=3,
            ),
            AspirationType(
                type_id="bridge_monitoring",
                label="Real-time bridge monitoring",
                description=("Detect stuck bridge transactions within 30 minutes."),
                priority=2,
                deadline_days=30,
            ),
        ]

    def get_collision_signals(self) -> list[CollisionSignal]:
        """Return signals that trigger cross-domain collisions."""
        return [
            CollisionSignal(
                signal_id="network_economics_overlap",
                label="Network health-economics overlap",
                description=(
                    "Bridge TVL changes intersect with liquidity metrics, "
                    "requiring cross-domain analysis."
                ),
                source_domains=["network_health", "economics"],
                convergence_threshold=0.6,
            ),
            CollisionSignal(
                signal_id="network_security_overlap",
                label="Network health-security overlap",
                description=(
                    "Low node count or version fragmentation may indicate a security concern."
                ),
                source_domains=["network_health", "security"],
                convergence_threshold=0.5,
            ),
        ]

    def get_war_room_contributions(self) -> list[WarRoomContribution]:
        """Return this domain's war room briefing sections."""
        return [
            WarRoomContribution(
                domain="network_health",
                section_title="Network Health",
                metrics=[
                    "total_nodes",
                    "pillar_count",
                    "sentinel_count",
                    "latest_version_pct",
                    "decentralization_score",
                    "bridge_tvl_usd",
                    "active_relayers",
                    "stuck_transactions",
                    "median_pillar_uptime",
                    "at_risk_pillars",
                    "delegation_drops",
                ],
                recommendations_prompt=(
                    "Based on node census and bridge metrics, what "
                    "infrastructure risks should be flagged?"
                ),
            ),
        ]

    def get_self_improvement_metrics(self) -> dict[str, float]:
        """Return current performance metrics for self-improvement."""
        return {
            "node_coverage_pct": 0.0,
            "census_freshness_hours": 0.0,
            "bridge_check_frequency_hours": 0.0,
            "decentralization_score": 0.0,
            "pillar_monitor_freshness_hours": 0.0,
        }

    def decide_next_action(self, context: dict, exclude: set[str] | None = None) -> dict | None:
        """Decide the next action, rotating through all 4 network_health engines."""
        exclude = exclude or set()
        trigger = context.get("trigger_level", "routine")
        stale = context.get("stale_data", [])
        candidates: list[dict] = []

        if trigger in ("urgent", "critical"):
            candidates.append(
                {
                    "action": "check_bridge_health",
                    "reason": "Urgent trigger -- check bridge for stuck transactions.",
                    "priority": 2,
                    "engine": "bridge_health",
                }
            )

        if "node_census" in stale:
            candidates.append(
                {
                    "action": "run_node_census",
                    "reason": "Node census data is stale.",
                    "priority": 3,
                    "engine": "node_census",
                }
            )

        if "bridge_metrics" in stale:
            candidates.append(
                {
                    "action": "stale_bridge_health",
                    "reason": "Bridge metrics are stale.",
                    "priority": 4,
                    "engine": "bridge_health",
                }
            )

        if "pillar_health" in stale:
            candidates.append(
                {
                    "action": "monitor_pillars",
                    "reason": "Pillar health data is stale.",
                    "priority": 3,
                    "engine": "pillar_monitor",
                }
            )

        candidates.extend(
            [
                {
                    "action": "routine_decentralization",
                    "reason": "Routine decentralization scoring.",
                    "priority": 5,
                    "engine": "decentralization_scorer",
                },
                {
                    "action": "routine_node_census",
                    "reason": "Routine node census rotation.",
                    "priority": 6,
                    "engine": "node_census",
                },
                {
                    "action": "routine_bridge_health",
                    "reason": "Routine bridge health rotation.",
                    "priority": 6,
                    "engine": "bridge_health",
                },
                {
                    "action": "routine_pillar_monitor",
                    "reason": "Routine pillar health rotation.",
                    "priority": 6,
                    "engine": "pillar_monitor",
                },
            ]
        )

        for candidate in candidates:
            key = f"network_health:{candidate['action']}"
            if key not in exclude:
                return candidate
        return None

    def get_db_schema_sql(self) -> str:
        """Return domain-specific SQL DDL for additional tables."""
        return """
CREATE TABLE IF NOT EXISTS node_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    total_nodes INTEGER DEFAULT 0,
    pillar_count INTEGER DEFAULT 0,
    sentinel_count INTEGER DEFAULT 0,
    version_distribution TEXT,
    latest_version TEXT,
    latest_version_pct REAL DEFAULT 0.0,
    source TEXT DEFAULT 'zenonhub'
);

CREATE TABLE IF NOT EXISTS bridge_metrics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    bridge_name TEXT DEFAULT 'orbital',
    tvl_znn REAL DEFAULT 0.0,
    tvl_eth REAL DEFAULT 0.0,
    tvl_usd REAL DEFAULT 0.0,
    active_relayers INTEGER DEFAULT 0,
    total_relayers INTEGER DEFAULT 0,
    stuck_transactions INTEGER DEFAULT 0,
    pending_wraps INTEGER DEFAULT 0,
    pending_unwraps INTEGER DEFAULT 0,
    source TEXT DEFAULT 'zenonhub'
);

CREATE INDEX IF NOT EXISTS idx_node_snapshots_ts
    ON node_snapshots(timestamp);
CREATE INDEX IF NOT EXISTS idx_bridge_metrics_ts
    ON bridge_metrics(timestamp);
CREATE INDEX IF NOT EXISTS idx_bridge_metrics_name
    ON bridge_metrics(bridge_name);

CREATE TABLE IF NOT EXISTS pillar_monitor_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    batch_id INTEGER NOT NULL,
    pillar_name TEXT NOT NULL,
    weight REAL DEFAULT 0.0,
    produced_momentums INTEGER DEFAULT 0,
    expected_momentums INTEGER DEFAULT 0,
    uptime_pct REAL DEFAULT 0.0,
    rank INTEGER DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_pillar_monitor_batch
    ON pillar_monitor_snapshots(batch_id);
CREATE INDEX IF NOT EXISTS idx_pillar_monitor_name
    ON pillar_monitor_snapshots(pillar_name);
"""

    def on_register(self) -> None:
        """Initialize domain-specific resources after registration."""
        logger.info(
            "Network Health domain registered with %d engines.",
            len(self.get_engines()),
        )
