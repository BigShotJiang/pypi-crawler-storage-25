# SPDX-License-Identifier: MIT
"""
DevOpsDomain -- DomainPlugin for devnet management and integration testing.

Provides engines for devnet lifecycle management, RPC client interaction,
integration test orchestration, and test execution across the Zenon stack.
"""

import logging

from core.domain_registry import (
    AspirationType,
    CollisionSignal,
    DomainPlugin,
    EngineDefinition,
    HypothesisType,
    WarRoomContribution,
)

logger = logging.getLogger(__name__)


class DevOpsDomain(DomainPlugin):
    """DevOps domain plugin -- devnet management and integration testing."""

    def name(self) -> str:
        """Return the domain name identifier."""
        return "devops"

    def get_description(self) -> str:
        """Return a human-readable description of this domain."""
        return (
            "Devnet lifecycle management, RPC client interaction, "
            "integration test orchestration, and cross-stack test execution."
        )

    def get_priority(self) -> int:
        """Return the scheduling priority for this domain."""
        return 3  # Same as development -- testing is core

    def get_engines(self) -> list[EngineDefinition]:
        """Return the list of engines this domain provides."""
        return [
            EngineDefinition(
                name="devnet_manager",
                description=(
                    "Manages znnd devnet process: start, stop, reset, "
                    "and status checks using full-devnet genesis config."
                ),
                module_path="domains.devops.engines.devnet_manager",
                priority=1,
                tier=2,
                required_apis=["shell", "znnd"],
                max_runtime_seconds=120,
            ),
            EngineDefinition(
                name="rpc_client",
                description=(
                    "JSON-RPC client for interacting with the devnet "
                    "node: sends transactions, queries state, and "
                    "verifies on-chain results."
                ),
                module_path="domains.devops.engines.rpc_client",
                priority=2,
                tier=2,
                required_apis=["znnd"],
                max_runtime_seconds=60,
            ),
            EngineDefinition(
                name="integration_tests",
                description=(
                    "Orchestrates end-to-end integration tests against "
                    "a running devnet: contract deployment, method calls, "
                    "and state verification."
                ),
                module_path="domains.devops.engines.integration_tests",
                priority=3,
                tier=3,
                required_apis=["znnd"],
                max_runtime_seconds=600,
            ),
            EngineDefinition(
                name="test_runner",
                description=(
                    "Runs unit and integration test suites across Go, "
                    "Dart, and Python repos, collecting results."
                ),
                module_path="domains.devops.engines.test_runner",
                priority=4,
                tier=1,
                required_apis=["shell"],
                max_runtime_seconds=300,
            ),
        ]

    def get_hypothesis_types(self) -> list[HypothesisType]:
        """Return hypothesis types this domain can generate."""
        return [
            HypothesisType(
                type_id="integration_regression",
                label="Integration regression detected",
                description=(
                    "An integration test that previously passed now "
                    "fails, indicating a regression in contract behavior."
                ),
                initial_confidence=0.8,
                publishable_threshold=0.95,
            ),
            HypothesisType(
                type_id="devnet_instability",
                label="Devnet instability",
                description=(
                    "The devnet node is crashing, stalling, or producing inconsistent state."
                ),
                initial_confidence=0.6,
                publishable_threshold=0.85,
            ),
        ]

    def get_aspiration_types(self) -> list[AspirationType]:
        """Return aspiration types this domain can pursue."""
        return [
            AspirationType(
                type_id="full_integration_coverage",
                label="Full integration test coverage",
                description=(
                    "Every embedded contract has integration tests "
                    "that exercise all methods on devnet."
                ),
                priority=3,
                deadline_days=60,
            ),
            AspirationType(
                type_id="automated_devnet_ci",
                label="Automated devnet CI",
                description=(
                    "Devnet spin-up and integration testing runs automatically on every PR."
                ),
                priority=4,
            ),
        ]

    def get_collision_signals(self) -> list[CollisionSignal]:
        """Return signals that trigger cross-domain collisions."""
        return [
            CollisionSignal(
                signal_id="devnet_security_finding",
                label="Devnet reveals security issue",
                description=(
                    "Integration testing on devnet reveals a behavior "
                    "that the security domain should investigate."
                ),
                source_domains=["devops", "security"],
                convergence_threshold=0.5,
            ),
            CollisionSignal(
                signal_id="devnet_spec_violation",
                label="Devnet reveals spec violation",
                description=(
                    "Integration testing on devnet reveals behavior "
                    "that contradicts the spec definition."
                ),
                source_domains=["devops", "development"],
                convergence_threshold=0.6,
            ),
        ]

    def get_war_room_contributions(self) -> list[WarRoomContribution]:
        """Return this domain's war room briefing sections."""
        return [
            WarRoomContribution(
                domain="devops",
                section_title="DevOps & Testing",
                metrics=[
                    "devnet_status",
                    "integration_tests_pass_rate",
                    "unit_test_pass_rate",
                    "contracts_with_integration_tests",
                ],
                recommendations_prompt=(
                    "Based on current devnet status and test results, "
                    "what testing gaps need to be addressed?"
                ),
            ),
        ]

    def get_self_improvement_metrics(self) -> dict[str, float]:
        """Return current performance metrics for self-improvement."""
        return {
            "integration_pass_rate": 0.0,
            "unit_test_pass_rate": 0.0,
            "devnet_uptime_pct": 0.0,
            "contracts_tested": 0.0,
        }

    def decide_next_action(self, context: dict, exclude: set[str] | None = None) -> dict | None:
        """Decide the next action, rotating through all 4 devops engines."""
        exclude = exclude or set()
        trigger = context.get("trigger_level", "routine")
        stale = context.get("stale_data", [])
        candidates: list[dict] = []

        if trigger in ("urgent", "critical"):
            candidates.append(
                {
                    "action": "run_integration_tests",
                    "reason": "Urgent trigger -- verify integration tests.",
                    "priority": 3,
                    "engine": "integration_tests",
                }
            )

        if "devnet_status" in stale:
            candidates.append(
                {
                    "action": "check_devnet",
                    "reason": "Devnet status is stale.",
                    "priority": 4,
                    "engine": "devnet_manager",
                }
            )

        if "test_results" in stale:
            candidates.append(
                {
                    "action": "run_tests",
                    "reason": "Test results are stale.",
                    "priority": 5,
                    "engine": "test_runner",
                }
            )

        candidates.extend(
            [
                {
                    "action": "routine_run_unit_tests",
                    "reason": "Routine test execution.",
                    "priority": 6,
                    "engine": "test_runner",
                },
                {
                    "action": "routine_devnet_check",
                    "reason": "Routine devnet manager check.",
                    "priority": 7,
                    "engine": "devnet_manager",
                },
                {
                    "action": "routine_integration_tests",
                    "reason": "Routine integration test rotation.",
                    "priority": 7,
                    "engine": "integration_tests",
                },
                {
                    "action": "routine_rpc_client",
                    "reason": "Routine RPC client smoke check.",
                    "priority": 7,
                    "engine": "rpc_client",
                },
            ]
        )

        for candidate in candidates:
            key = f"devops:{candidate['action']}"
            if key not in exclude:
                return candidate
        return None

    def get_db_schema_sql(self) -> str:
        """Return domain-specific SQL DDL for additional tables."""
        return """
CREATE TABLE IF NOT EXISTS devnet_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    action TEXT NOT NULL,
    success BOOLEAN NOT NULL,
    duration_seconds REAL,
    details TEXT
);

CREATE TABLE IF NOT EXISTS integration_test_results (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    test_name TEXT NOT NULL,
    contract_name TEXT,
    success BOOLEAN NOT NULL,
    duration_seconds REAL,
    output TEXT,
    error_message TEXT
);

CREATE INDEX IF NOT EXISTS idx_devnet_runs_action
    ON devnet_runs(action);
CREATE INDEX IF NOT EXISTS idx_integration_results_contract
    ON integration_test_results(contract_name);
CREATE INDEX IF NOT EXISTS idx_integration_results_success
    ON integration_test_results(success);
"""

    def on_register(self) -> None:
        """Initialize domain-specific resources after registration."""
        logger.info(
            "DevOps domain registered with %d engines.",
            len(self.get_engines()),
        )
