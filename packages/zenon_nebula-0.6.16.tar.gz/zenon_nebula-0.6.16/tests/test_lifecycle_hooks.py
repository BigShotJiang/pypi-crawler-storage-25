# SPDX-License-Identifier: MIT
"""Tests for core/extensions/hooks.py — task #61 Phase G1 (3/3)."""

from __future__ import annotations

import pytest

from core.extensions.hooks import (
    VALID_EVENTS,
    clear,
    fire,
    get_hooks,
    on,
    register,
)


@pytest.fixture(autouse=True)
def _clean_hooks():
    """Every test starts with a clean hook registry."""
    clear()
    yield
    clear()


class TestRegister:
    def test_register_valid_event(self):
        register("post_cycle", lambda **kw: None)
        assert len(get_hooks("post_cycle")) == 1

    def test_register_invalid_event_raises(self):
        with pytest.raises(ValueError, match="Unknown hook event"):
            register("not_an_event", lambda: None)

    def test_decorator_form(self):
        @on("pre_cycle")
        def my_hook(**kw):
            pass

        assert my_hook in get_hooks("pre_cycle")

    def test_multiple_handlers_ordered(self):
        calls = []
        register("post_cycle", lambda **kw: calls.append("a"))
        register("post_cycle", lambda **kw: calls.append("b"))
        fire("post_cycle")
        assert calls == ["a", "b"]


class TestFire:
    def test_fire_no_handlers_is_noop(self):
        fire("post_cycle")  # should not raise

    def test_fire_passes_kwargs(self):
        received = {}

        def capture(**kw):
            received.update(kw)

        register("post_cycle", capture)
        fire("post_cycle", summary={"cycles": 1})
        assert received == {"summary": {"cycles": 1}}

    def test_handler_exception_logged_not_propagated(self):
        def bad_hook(**kw):
            raise RuntimeError("boom")

        register("post_cycle", bad_hook)
        register("post_cycle", lambda **kw: None)
        fire("post_cycle")  # should not raise

    def test_handler_exception_doesnt_block_subsequent(self):
        calls = []

        def bad(**kw):
            raise RuntimeError("first breaks")

        def good(**kw):
            calls.append("second ran")

        register("post_cycle", bad)
        register("post_cycle", good)
        fire("post_cycle")
        assert calls == ["second ran"]


class TestPreFindingVeto:
    def test_pre_finding_passthrough(self):
        def enrich(finding):
            finding["enriched"] = True
            return finding

        register("pre_finding", enrich)
        result = fire("pre_finding", finding={"type": "test"})
        assert result == {"type": "test", "enriched": True}

    def test_pre_finding_veto_returns_none(self):
        register("pre_finding", lambda finding: None)
        result = fire("pre_finding", finding={"type": "test"})
        assert result is None

    def test_pre_finding_veto_skips_subsequent(self):
        calls = []

        def veto(finding):
            calls.append("veto")
            return None

        def should_not_run(finding):
            calls.append("after_veto")
            return finding

        register("pre_finding", veto)
        register("pre_finding", should_not_run)
        result = fire("pre_finding", finding={"x": 1})
        assert result is None
        assert calls == ["veto"]

    def test_pre_finding_no_handlers_returns_finding(self):
        result = fire("pre_finding", finding={"x": 1})
        assert result == {"x": 1}

    def test_pre_finding_exception_skips_handler(self):
        def broken(finding):
            raise RuntimeError("oops")

        def passthrough(finding):
            return finding

        register("pre_finding", broken)
        register("pre_finding", passthrough)
        result = fire("pre_finding", finding={"x": 1})
        assert result == {"x": 1}


class TestClear:
    def test_clear_all(self):
        register("pre_cycle", lambda **kw: None)
        register("post_cycle", lambda **kw: None)
        clear()
        assert get_hooks("pre_cycle") == []
        assert get_hooks("post_cycle") == []

    def test_clear_specific_event(self):
        register("pre_cycle", lambda **kw: None)
        register("post_cycle", lambda **kw: None)
        clear("pre_cycle")
        assert get_hooks("pre_cycle") == []
        assert len(get_hooks("post_cycle")) == 1


class TestValidEvents:
    def test_all_six_events_present(self):
        expected = {
            "pre_cycle",
            "post_cycle",
            "pre_finding",
            "post_finding",
            "on_collision",
            "on_battle_plan",
        }
        assert expected == VALID_EVENTS
