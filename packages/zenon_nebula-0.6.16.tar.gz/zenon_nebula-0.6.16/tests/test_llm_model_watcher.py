# SPDX-License-Identifier: MIT
"""Tests for domains/self_maintenance/engines/llm_model_watcher.py.

Task #92. Engine diffs xAI /v1/models against MODEL_PRICING and
surfaces three signals: new_model, removed_model, flagship_shift.

Tests use the ``db_path`` fixture plus urlopen + MODEL_PRICING
monkeypatches; no real network calls, no real LLM.
"""

from __future__ import annotations

import inspect
import io
import json
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import patch

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.persistence import connect
from domains.self_maintenance.engines import llm_model_watcher as lmw

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _ts(seconds_ago: int) -> str:
    t = datetime.now(timezone.utc) - timedelta(seconds=seconds_ago)
    return t.strftime("%Y-%m-%d %H:%M:%S")


def _mock_urlopen(payload: dict | None, status: int = 200):
    """Return a context manager mock mimicking urllib.request.urlopen."""
    body = json.dumps(payload).encode("utf-8") if payload is not None else b"not json"

    class _Resp:
        def __init__(self):
            self.status = status
            self._buf = io.BytesIO(body)

        def __enter__(self):
            return self

        def __exit__(self, *a):
            return False

        def read(self, n=-1):
            return self._buf.read(n)

    return _Resp()


# ---------------------------------------------------------------------------
# Import smoke
# ---------------------------------------------------------------------------


class TestImportSmoke:
    def test_module_imports(self):
        assert hasattr(lmw, "run_llm_model_watcher")

    def test_entry_point_zero_required_arg(self):
        sig = inspect.signature(lmw.run_llm_model_watcher)
        required = [
            p
            for p in sig.parameters.values()
            if p.default is inspect.Parameter.empty
            and p.name not in ("self", "db_path")
            and p.kind
            in (
                inspect.Parameter.POSITIONAL_OR_KEYWORD,
                inspect.Parameter.POSITIONAL_ONLY,
            )
        ]
        assert required == []


# ---------------------------------------------------------------------------
# fetch_xai_models
# ---------------------------------------------------------------------------


class TestFetchXaiModels:
    def test_happy_path(self):
        payload = {
            "object": "list",
            "data": [
                {"id": "grok-4.20-0309-reasoning"},
                {"id": "grok-4-1-fast-non-reasoning"},
            ],
        }
        with patch.object(lmw.urllib.request, "urlopen", return_value=_mock_urlopen(payload)):
            result = lmw.fetch_xai_models("fake-key")
        assert result == ["grok-4.20-0309-reasoning", "grok-4-1-fast-non-reasoning"]

    def test_skips_non_string_ids(self):
        payload = {"data": [{"id": "grok-ok"}, {"id": None}, {"no_id": True}]}
        with patch.object(lmw.urllib.request, "urlopen", return_value=_mock_urlopen(payload)):
            result = lmw.fetch_xai_models("fake-key")
        assert result == ["grok-ok"]

    def test_returns_none_on_http_error(self):
        with patch.object(
            lmw.urllib.request, "urlopen", return_value=_mock_urlopen({"data": []}, status=500)
        ):
            assert lmw.fetch_xai_models("fake-key") is None

    def test_returns_none_on_malformed_json(self):
        with patch.object(lmw.urllib.request, "urlopen", return_value=_mock_urlopen(None)):
            assert lmw.fetch_xai_models("fake-key") is None

    def test_returns_none_on_unexpected_shape(self):
        payload = {"object": "list"}  # missing data
        with patch.object(lmw.urllib.request, "urlopen", return_value=_mock_urlopen(payload)):
            assert lmw.fetch_xai_models("fake-key") is None

    def test_returns_none_on_network_error(self):
        import urllib.error

        with patch.object(
            lmw.urllib.request,
            "urlopen",
            side_effect=urllib.error.URLError("boom"),
        ):
            assert lmw.fetch_xai_models("fake-key") is None

    def test_oversized_response_rejected(self):
        # 300 KB of data, over MAX_BYTES
        big_payload = {"data": [{"id": f"grok-{i}"} for i in range(30000)]}
        with patch.object(lmw.urllib.request, "urlopen", return_value=_mock_urlopen(big_payload)):
            assert lmw.fetch_xai_models("fake-key") is None


# ---------------------------------------------------------------------------
# Signal detectors
# ---------------------------------------------------------------------------


class TestDetectNewModels:
    def test_flags_unknown_model(self):
        signals = lmw._detect_new_models(
            ["grok-known", "grok-new-5.0"],
            {"grok-known"},
        )
        assert len(signals) == 1
        assert signals[0].model_id == "grok-new-5.0"
        assert signals[0].signal_class == "new_model"

    def test_no_signals_when_all_known(self):
        signals = lmw._detect_new_models(["grok-a", "grok-b"], {"grok-a", "grok-b"})
        assert signals == []

    def test_empty_api_returns_nothing(self):
        assert lmw._detect_new_models([], {"grok-known"}) == []


class TestDetectRemovedModels:
    def test_flags_missing_model(self):
        signals = lmw._detect_removed_models(
            ["grok-kept"],
            {"grok-kept", "grok-gone"},
        )
        assert len(signals) == 1
        assert signals[0].model_id == "grok-gone"
        assert signals[0].signal_class == "removed_model"

    def test_no_signals_when_superset(self):
        signals = lmw._detect_removed_models(
            ["grok-a", "grok-b", "grok-c"],
            {"grok-a"},
        )
        assert signals == []


class TestDetectFlagshipShift:
    def test_flags_newer_grok(self):
        signals = lmw._detect_flagship_shift(
            ["grok-4.20-0309-reasoning", "grok-5.0-new"],
            current_best="grok-4.20-0309-reasoning",
        )
        assert len(signals) == 1
        assert signals[0].model_id == "grok-5.0-new"
        assert signals[0].signal_class == "flagship_shift"
        assert signals[0].detail["current_best"] == "grok-4.20-0309-reasoning"

    def test_no_shift_when_current_is_highest(self):
        signals = lmw._detect_flagship_shift(
            ["grok-4.20-0309-reasoning", "grok-3.0-old"],
            current_best="grok-4.20-0309-reasoning",
        )
        assert signals == []

    def test_ignores_non_grok_models(self):
        signals = lmw._detect_flagship_shift(
            ["not-a-grok", "zzz-highest"],
            current_best="grok-4.20-0309-reasoning",
        )
        assert signals == []

    def test_picks_highest_when_multiple_candidates(self):
        signals = lmw._detect_flagship_shift(
            ["grok-5.0-a", "grok-5.0-b", "grok-4.99"],
            current_best="grok-4.20",
        )
        assert len(signals) == 1
        # All three sort above grok-4.20
        assert signals[0].model_id == "grok-5.0-b"
        assert len(signals[0].detail["all_candidates"]) == 3


# ---------------------------------------------------------------------------
# Format helper
# ---------------------------------------------------------------------------


class TestFormatSignal:
    def test_new_model_shape(self):
        s = lmw.ModelSignal(
            signal_class="new_model",
            model_id="grok-5.0",
            detail={"known_model_count": 7, "api_model_count": 8},
        )
        what, _so_what, now_what = lmw._format_signal(s)
        assert "grok-5.0" in what
        assert "MODEL_PRICING" in what
        assert "routing" in now_what.lower() or "benchmark" in now_what.lower()

    def test_removed_model_shape(self):
        s = lmw.ModelSignal(
            signal_class="removed_model",
            model_id="grok-old",
            detail={"known_model_count": 7, "api_model_count": 6},
        )
        what, so_what, _now_what = lmw._format_signal(s)
        assert "grok-old" in what
        assert "404" in so_what or "fail" in so_what.lower()

    def test_flagship_shift_shape(self):
        s = lmw.ModelSignal(
            signal_class="flagship_shift",
            model_id="grok-5.0",
            detail={"current_best": "grok-4.20", "candidate": "grok-5.0"},
        )
        what, _, now_what = lmw._format_signal(s)
        assert "grok-5.0" in what
        assert "grok-4.20" in what
        assert "DEFAULT_BEST" in now_what

    def test_unknown_class_fallback(self):
        s = lmw.ModelSignal(
            signal_class="weird",
            model_id="x",
            detail={},
        )
        what, so_what, now_what = lmw._format_signal(s)
        assert all(x for x in (what, so_what, now_what))


# ---------------------------------------------------------------------------
# Cooldown
# ---------------------------------------------------------------------------


class TestCooldown:
    def test_cooldown_skips_recently_emitted(self, db_path):
        conn = connect(db_path)
        conn.execute(
            """
            INSERT INTO evidence
                (timestamp, domain, engine, evidence_type, finding,
                 confidence, raw_data)
            VALUES (?, 'self_maintenance', 'llm_model_watcher',
                    'llm_model_signal', 'WHAT...', 0.40, ?)
            """,
            (
                _ts(3600),
                '{"data": {"model_id": "grok-5.0", "signal_class": "new_model"}, "provenance": "system"}',
            ),
        )
        conn.commit()
        assert lmw._was_recently_emitted(conn, "grok-5.0", "new_model") is True
        assert lmw._was_recently_emitted(conn, "grok-other", "new_model") is False
        assert lmw._was_recently_emitted(conn, "grok-5.0", "removed_model") is False
        conn.close()


# ---------------------------------------------------------------------------
# ModelSignal dataclass
# ---------------------------------------------------------------------------


class TestModelSignal:
    def test_is_frozen(self):
        s = lmw.ModelSignal(
            signal_class="new_model",
            model_id="grok-x",
            detail={},
        )
        from dataclasses import FrozenInstanceError

        with pytest.raises(FrozenInstanceError):
            s.model_id = "y"


# ---------------------------------------------------------------------------
# End-to-end (entry point)
# ---------------------------------------------------------------------------


class TestEndToEnd:
    def test_no_api_key_returns_empty_summary(self, db_path, monkeypatch):
        monkeypatch.delenv("XAI_API_KEY", raising=False)
        result = lmw.run_llm_model_watcher(db_path=db_path)
        assert result["engine"] == "llm_model_watcher"
        assert result["signals_detected"] == 0
        assert result["reason"] == "no_api_key"

    def test_fetch_failure_returns_summary(self, db_path, monkeypatch):
        monkeypatch.setenv("XAI_API_KEY", "fake")
        with patch.object(lmw, "fetch_xai_models", return_value=None):
            result = lmw.run_llm_model_watcher(db_path=db_path)
        assert result["reason"] == "fetch_failed"
        assert result["signals_detected"] == 0

    def test_persists_new_model_finding(self, db_path, monkeypatch):
        monkeypatch.setenv("XAI_API_KEY", "fake")
        api_models = [*list(lmw.MODEL_PRICING.keys()), "grok-7-fresh"]
        with patch.object(lmw, "fetch_xai_models", return_value=api_models):
            result = lmw.run_llm_model_watcher(db_path=db_path)
        assert result["signals_detected"] >= 1
        assert result["by_class"]["new_model"] >= 1
        assert result["findings_persisted"] >= 1

    def test_detects_removed_model(self, db_path, monkeypatch):
        monkeypatch.setenv("XAI_API_KEY", "fake")
        # Return an API catalog missing one known model
        known = list(lmw.MODEL_PRICING.keys())
        api_models = known[1:]  # drop the first
        with patch.object(lmw, "fetch_xai_models", return_value=api_models):
            result = lmw.run_llm_model_watcher(db_path=db_path)
        assert result["by_class"]["removed_model"] >= 1

    def test_cooldown_prevents_duplicate_emission(self, db_path, monkeypatch):
        monkeypatch.setenv("XAI_API_KEY", "fake")
        api_models = [*list(lmw.MODEL_PRICING.keys()), "grok-7-fresh"]
        with patch.object(lmw, "fetch_xai_models", return_value=api_models):
            first = lmw.run_llm_model_watcher(db_path=db_path)
            second = lmw.run_llm_model_watcher(db_path=db_path)
        assert first["findings_persisted"] >= 1
        assert second["findings_persisted"] == 0
